Feature: Rigor Global Configuration
  As a multi-project nWave user
  I want to set a rigor profile once globally
  So that every new project uses my preferred quality settings without per-project configuration

  Background:
    Given the standard rigor defaults are profile "standard", agent_model "sonnet", reviewer_model "haiku"

  # --- US-RGC-01: Config Resolution ---

  Scenario: Project rigor present -- use project, ignore global
    Given Ale has global rigor set to profile "custom" with agent_model "opus"
    And project des-config.json contains rigor with profile "lean" and agent_model "haiku"
    When DESConfig loads rigor configuration
    Then rigor_profile returns "lean"
    And rigor_agent_model returns "haiku"

  Scenario: No project rigor -- cascade to global
    Given project des-config.json exists but has no "rigor" key
    And global-config.json contains rigor with profile "custom" and agent_model "opus"
    When DESConfig loads rigor configuration
    Then rigor_profile returns "custom"
    And rigor_agent_model returns "opus"

  Scenario: No project rigor, no global config -- use defaults
    Given project des-config.json exists but has no "rigor" key
    And global-config.json does not exist
    When DESConfig loads rigor configuration
    Then rigor_profile returns "standard"
    And rigor_agent_model returns "sonnet"

  Scenario: No project rigor, global config has no rigor key -- use defaults
    Given project des-config.json exists but has no "rigor" key
    And global-config.json exists but has no "rigor" key
    When DESConfig loads rigor configuration
    Then rigor_profile returns "standard"

  Scenario: Global config is corrupted JSON -- use defaults silently
    Given project des-config.json exists but has no "rigor" key
    And global-config.json contains invalid JSON
    When DESConfig loads rigor configuration
    Then rigor_profile returns "standard"
    And no exception is raised

  # --- US-RGC-02: Scope Selection ---

  Scenario: Scope question appears before profile selection
    Given Ale runs /nw:rigor in a project with des-config.json present
    When the command starts
    Then the command displays current project profile and current global profile
    And asks where to save with options "Globally" and "This project only"

  Scenario: Global scope writes to global-config.json
    Given Ale selects scope "Globally"
    And Ale selects profile "custom" with agent_model "opus"
    When Ale confirms the profile
    Then global-config.json contains rigor.profile "custom" and rigor.agent_model "opus"
    And project des-config.json rigor key is unchanged

  Scenario: Project scope writes to des-config.json
    Given Priya selects scope "This project only"
    And Priya selects profile "lean"
    When Priya confirms the profile
    Then des-config.json contains rigor.profile "lean"
    And global-config.json is not modified

  Scenario: Quick switch also asks scope
    Given Ale runs /nw:rigor lean
    When the command starts
    Then the command asks scope before showing the diff

  Scenario: Global config directory created if missing
    Given the ~/.nwave/ directory does not exist
    When Ale selects scope "Globally" and confirms profile "standard"
    Then ~/.nwave/ directory is created
    And global-config.json is created with the rigor block

  # --- US-RGC-03: Uninstall Handling ---

  Scenario: Global config found during uninstall -- prompt shown
    Given global-config.json exists with rigor configuration
    When Ale runs nwave-ai uninstall
    Then the uninstaller displays "Global configuration found"
    And asks to keep or delete with options "Keep" and "Delete"

  Scenario: User keeps global config during uninstall
    Given global-config.json exists
    When Ale selects "Keep" during uninstall
    Then global-config.json is not deleted
    And uninstall proceeds normally

  Scenario: User deletes global config during uninstall
    Given global-config.json exists
    When Tomasz selects "Delete" during uninstall
    Then global-config.json is deleted
    And if ~/.nwave/ is empty then it is removed

  Scenario: No global config -- no prompt during uninstall
    Given global-config.json does not exist
    When Priya runs nwave-ai uninstall
    Then no global config prompt is displayed
