# Outcome KPIs: Rigor Global Configuration

## Objective

Eliminate per-project rigor configuration friction so multi-project users set their quality preference once and it applies everywhere.

## Outcome KPIs

| # | Who | Does What | By How Much | Baseline | Measured By | Type |
|---|-----|-----------|-------------|----------|-------------|------|
| 1 | Multi-project nWave users | Stop running `/nw:rigor` in new projects | Zero invocations for projects using global default | 1 invocation per new project | `/nw:rigor` invocation count (self-reported) | Leading |
| 2 | nWave users reinstalling | Retain rigor preferences across install cycles | Zero re-configuration after reinstall | Full reconfiguration required | Global config survives uninstall+reinstall | Leading |

## Metric Hierarchy

- **North Star**: Percentage of new project sessions where rigor is already resolved without user action
- **Leading Indicators**: Global config adoption rate (users who save at least one global profile)
- **Guardrail Metrics**: No regression in project-level rigor override behavior; no silent config resolution errors

## Measurement Plan

| KPI | Data Source | Collection Method | Frequency | Owner |
|-----|------------|-------------------|-----------|-------|
| Global config adoption | `~/.nwave/global-config.json` existence | Manual / survey | Post-release | Product |
| Config resolution correctness | DESConfig unit tests | Automated (CI) | Every commit | Engineering |
| Uninstall data safety | E2E uninstall test | Automated (CI) | Every release | Engineering |

## Hypothesis

We believe that adding global rigor config resolution to DESConfig and a scope question to `/nw:rigor` for multi-project users will achieve zero per-project rigor setup friction. We will know this is true when multi-project users stop running `/nw:rigor` in new projects because their global default applies automatically.
