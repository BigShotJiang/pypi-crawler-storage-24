# Wave Decisions: Rigor Global Configuration

## Discovery Decisions

| Decision | Rationale |
|----------|-----------|
| Global config path: `~/.nwave/global-config.json` | Dedicated nWave namespace; avoids mixing with Claude Code config (`~/.claude/`) or XDG dirs |
| Merge strategy: full block override | Simple, predictable. If project has `rigor` key at all, global is ignored entirely. No per-field merge complexity |
| No production bugs to address | User confirmed zero bugs -- the only pain is friction (per-project setup) |
| JTBD skipped | Motivations are clear (reduce friction), no competing jobs to analyze |

## Architecture Decisions (Carried Forward)

These decisions from the existing nw-rigor feature remain valid:

| ADR | Decision | Impact on this feature |
|-----|----------|----------------------|
| ADR-001 | Rigor is a config concern, not domain logic | Global config is another config source -- no domain changes |
| ADR-002 | Parameterized StepCompletionValidator for TDD phases | Unchanged -- validator reads DESConfig which now cascades |

## Scope Decisions

| In Scope | Out of Scope |
|----------|-------------|
| DESConfig cascade: project -> global -> defaults | Per-field merge between global and project |
| `/nw:rigor` scope question (global vs project) | `/nw:rigor --show` read-only display command |
| Uninstall prompt for global config | Installer creating global config automatically |
| Global config directory auto-creation on save | Global config migration between nWave versions |

## Story Sizing

| Story | Effort | Scenarios | Rationale |
|-------|--------|-----------|-----------|
| US-RGC-01 | 1 day | 5 | Python change to DESConfig: add parameter, modify `_rigor()`, add `_load_global_configuration()` |
| US-RGC-02 | 1-2 days | 5 | Markdown change to rigor.md: add scope question, modify write target logic |
| US-RGC-03 | 1 day | 4 | Python change to nwave_ai/cli.py: add global config check in uninstall |

Total: 3-4 days, 14 scenarios across 3 stories.

## Delivery Order

```
US-RGC-01 (DESConfig cascade)
    |
    v
US-RGC-02 (/nw:rigor scope question)  -- depends on US-RGC-01
    |
    v
US-RGC-03 (Uninstall handling)         -- depends on US-RGC-02
```

US-RGC-01 is the foundation: without runtime resolution, the scope question in US-RGC-02 has nowhere to write to. US-RGC-03 is the lifecycle cleanup that only matters after global config exists.

## DESIGN Wave Handoff Checklist

The solution-architect receives:

- [x] Journey visual with happy path, error paths, and resolution flow
- [x] Story map with walking skeleton and release slicing
- [x] 3 user stories with DoR PASSED
- [x] 14 BDD scenarios across 3 stories
- [x] Shared artifacts registry with integration checkpoints
- [x] Outcome KPIs with measurement plan
- [x] Delivery order with dependency chain

### Questions for DESIGN Wave

1. **DESConfig constructor signature**: Should `global_config_path` be a constructor parameter (injectable for testing) or a class-level constant?
2. **Global config file format**: Same JSON structure as des-config.json (just the `rigor` key), or a dedicated schema with only rigor?
3. **`/nw:rigor` command**: The scope question adds a step to all 3 modes (interactive, quick switch, custom). Should quick switch (`/nw:rigor lean`) default to project scope to minimize friction for the common case?
