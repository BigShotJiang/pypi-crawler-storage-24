# Definition of Ready Validation: Rigor Global Configuration

## Story: US-RGC-01 -- Global Config Resolution in DESConfig

| DoR Item | Status | Evidence |
|----------|--------|----------|
| Problem statement clear | PASS | Multi-project user must re-run /nw:rigor per project; workaround is manual file copy |
| User/persona identified | PASS | Multi-project developer working across 3-5 repos daily |
| 3+ domain examples | PASS | 3 examples: fresh project cascade, project override, no config anywhere |
| UAT scenarios (3-7) | PASS | 5 scenarios covering all resolution paths |
| AC derived from UAT | PASS | 5 AC items map to the 5 scenarios |
| Right-sized (1-3 days) | PASS | 1 day: modify DESConfig._rigor() + add global_config_path + 5 unit tests |
| Technical notes | PASS | DESConfig constructor change, _rigor() cascade, no env var override |
| Dependencies tracked | PASS | No external dependencies; self-contained DESConfig change |
| Outcome KPIs defined | PASS | Zero manual rigor config for projects using global default |

### DoR Status: PASSED

---

## Story: US-RGC-02 -- Scope Selection in /nw:rigor Command

| DoR Item | Status | Evidence |
|----------|--------|----------|
| Problem statement clear | PASS | No way to save rigor globally; must re-run /nw:rigor custom (6 questions) per project |
| User/persona identified | PASS | Multi-project developer setting personal rigor preference |
| 3+ domain examples | PASS | 3 examples: global save, project override of global, quick switch with scope |
| UAT scenarios (3-7) | PASS | 5 scenarios covering scope question, global write, project write, quick switch, directory creation |
| AC derived from UAT | PASS | 6 AC items derived from scenarios |
| Right-sized (1-3 days) | PASS | 1-2 days: modify rigor.md command file (markdown instructions only) |
| Technical notes | PASS | Markdown command file, AskUserQuestion scope prompt, read-modify-write to global path |
| Dependencies tracked | PASS | Depends on US-RGC-01 (DESConfig reads global config for "current global profile" display) |
| Outcome KPIs defined | PASS | 100% of global-scope saves persist across projects |

### DoR Status: PASSED

---

## Story: US-RGC-03 -- Global Config Handling During Uninstall

| DoR Item | Status | Evidence |
|----------|--------|----------|
| Problem statement clear | PASS | Silent deletion of ~/.nwave/ loses global preferences; silent retention risks stale config |
| User/persona identified | PASS | Existing nWave user who uninstalls/reinstalls |
| 3+ domain examples | PASS | 3 examples: keep during reinstall, delete on full uninstall, no global config (skip) |
| UAT scenarios (3-7) | PASS | 4 scenarios covering prompt, keep, delete, no-config-skip |
| AC derived from UAT | PASS | 6 AC items including dry-run |
| Right-sized (1-3 days) | PASS | 1 day: add check + prompt in nwave_ai/cli.py uninstall command |
| Technical notes | PASS | CLI prompt via click, ~/.nwave/ lifecycle, directory cleanup if empty |
| Dependencies tracked | PASS | Depends on US-RGC-02 (global config must exist for this to be relevant) |
| Outcome KPIs defined | PASS | Zero preference loss during reinstall when "Keep" is chosen |

### DoR Status: PASSED

---

## Overall: ALL 3 STORIES PASSED DoR

Ready for handoff to DESIGN wave.
