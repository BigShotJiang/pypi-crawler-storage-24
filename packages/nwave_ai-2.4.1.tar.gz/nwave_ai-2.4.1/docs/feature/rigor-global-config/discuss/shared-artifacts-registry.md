# Shared Artifacts Registry: Rigor Global Configuration

## Artifacts

### global_config_path

- **Source of truth**: `~/.nwave/global-config.json` (hardcoded convention)
- **Consumers**: DESConfig (runtime resolution), `/nw:rigor` (write target), `nwave-ai uninstall` (cleanup prompt)
- **Owner**: rigor-global-config feature
- **Integration risk**: MEDIUM -- path must be consistent across all three consumers
- **Validation**: Unit test verifies DESConfig default global path matches `/nw:rigor` write target

### project_config_path

- **Source of truth**: `.nwave/des-config.json` (existing, relative to project root)
- **Consumers**: DESConfig (primary config), `/nw:rigor` (write target), installer bootstrap, all wave commands
- **Owner**: DES core (existing)
- **Integration risk**: LOW -- already established, no changes to path
- **Validation**: Existing tests cover this path

### rigor_block_schema

- **Source of truth**: `/nw:rigor` command file profile mappings (`nWave/tasks/nw/rigor.md`)
- **Consumers**: DESConfig (reads typed properties), wave commands (read via DESConfig), global-config.json, des-config.json
- **Owner**: nw-rigor feature (existing)
- **Integration risk**: LOW -- schema unchanged, only the location where it can be stored is new
- **Validation**: DESConfig property tests verify all fields have correct defaults

### resolution_precedence

- **Source of truth**: DESConfig._rigor() method (Python code)
- **Consumers**: All rigor_* properties on DESConfig, all wave commands (indirectly)
- **Owner**: rigor-global-config feature
- **Integration risk**: HIGH -- incorrect resolution order silently applies wrong profile
- **Validation**: Unit tests with all 5 resolution scenarios (project present, project absent + global present, both absent, global corrupt, project present + global present)

## Integration Checkpoints

| Checkpoint | Validates | How |
|------------|-----------|-----|
| DESConfig cascade | Project rigor wins over global | Unit test: both present, project returned |
| DESConfig fallback | Global used when project has no rigor | Unit test: no project rigor, global returned |
| DESConfig defaults | Standard defaults when both absent | Unit test: both absent, standard returned |
| /nw:rigor global write | Rigor block written to correct global path | Acceptance test: run command, verify file |
| /nw:rigor project write | Existing behavior preserved | Acceptance test: run command, verify file |
| Uninstall prompt | Global config detected and user prompted | Acceptance test: file exists, prompt shown |
| Uninstall keep | File preserved after "keep" | Acceptance test: file still exists |
| Uninstall delete | File removed after "delete" | Acceptance test: file gone |
