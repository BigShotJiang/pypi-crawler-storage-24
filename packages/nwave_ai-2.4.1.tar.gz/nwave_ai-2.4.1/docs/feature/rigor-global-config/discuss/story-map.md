# Story Map: Rigor Global Configuration

## User: Ale Donnarumma (nWave author, multi-project user)

## Goal: Set rigor once globally, have it apply everywhere, with per-project override

## Backbone

| Configure Scope | Select Profile | Persist Config | Resolve at Runtime | Manage Lifecycle |
|----------------|---------------|----------------|-------------------|-----------------|
| Scope question | Profile select | Write global | Cascade resolution | Uninstall prompt |
| Show current   | Quick switch   | Write project  | Fallback defaults  | |
|                | Custom builder |                |                    | |

---

### Walking Skeleton

The thinnest end-to-end slice that makes global rigor work:

1. **Configure Scope**: `/nw:rigor` asks "global or project?" at the start
2. **Select Profile**: Existing profile selection (unchanged)
3. **Persist Config**: Write rigor block to `~/.nwave/global-config.json` when global selected
4. **Resolve at Runtime**: DESConfig cascades project -> global -> defaults
5. **Manage Lifecycle**: Uninstall asks whether to keep or delete global config

### Release 1: Walking Skeleton (all 5 activities)

| Story | Activity | Rationale |
|-------|----------|-----------|
| US-RGC-01: Global config resolution | Resolve at Runtime | Core behavior -- DESConfig reads global when project has no rigor |
| US-RGC-02: Scope selection in /nw:rigor | Configure Scope + Persist Config | User-facing change -- where to save |
| US-RGC-03: Uninstall global config handling | Manage Lifecycle | Data safety -- user controls their global config |

### Release 2: Polish (deferred -- not required for MVP)

- Show global vs project indicator in `/nw:rigor` status display
- `/nw:rigor --show` to display resolved config without interactive prompt
- Warn when project overrides global (informational, not blocking)
