# Four Forces Analysis: nw-workshopper Agent

## Summary

For the nw-workshopper agent to drive adoption, the combined **Push + Pull** forces must exceed **Anxiety + Habit** forces. This analysis examines forces across all six job stories, identifies the key blockers, and derives design implications.

---

## Forces Analysis by Job Story

### JS-1: Workshop Structure Design

#### Demand-Generating
- **Push**: Workshop design takes 6-12 hours for a competent trainer, 20+ hours for a non-trainer like Sofia. Most people skip proper design and default to lectures. The cost of poor design is invisible until delivery -- glazed eyes, low engagement, poor post-workshop application.
- **Pull**: A complete 4C-structured workshop plan with timed activities, facilitator notes, participant materials, and learning checkpoints. Generated in under 60 minutes. Pedagogically sound by construction -- TBR principles baked in, not bolted on.

#### Demand-Reducing
- **Anxiety**: "Can an AI really understand the nuances of teaching Kubernetes networking to mid-level SREs?" The more technical and specific the domain, the higher the anxiety about generic, surface-level activity suggestions.
- **Habit**: Copy-pasting last quarter's slide deck. Reusing the same workshop structure because "it worked well enough." The sunk cost of existing materials is high -- 50+ slides, polished diagrams, rehearsed delivery.

#### Assessment
- Switch likelihood: **High** -- the time savings alone justify the switch for Marco, and the quality improvement justifies it for Sofia
- Key blocker: **Anxiety** about domain-specific quality -- generic activities are a dealbreaker
- Key enabler: **Push** from time cost -- 6-12 hours is an enormous investment for freelancers billing by the day
- Design implication: The agent must demonstrate domain understanding early in the interaction, producing activities that feel custom and technically accurate, not templated

---

### JS-2: Activity Design for Learning Outcomes

#### Demand-Generating
- **Push**: The "blank page problem" -- staring at a learning outcome like "Participants can explain the CAP theorem and apply it to database selection" and having no idea how to turn that into an engaging 20-minute activity. Generic templates (quiz, discussion, case study) feel lazy and repetitive.
- **Pull**: Activities that are creative, technically relevant, and precisely targeted at the right Bloom's level. Not "discuss in pairs" but "given these three system requirements, each pair selects a database and defends their choice to another pair using CAP theorem constraints."

#### Demand-Reducing
- **Anxiety**: "Will the activities actually work in practice? Will participants find them engaging or confusing? What if the activity falls flat and I have 20 awkward minutes to fill?"
- **Habit**: Using the same 5-6 proven activity formats for every workshop. They are predictable and safe, even if they are boring.

#### Assessment
- Switch likelihood: **High** -- creative block is a universal and deeply frustrating pain point
- Key blocker: **Anxiety** about untested activities -- facilitators need confidence the activity will work
- Key enabler: **Pull** of creative, domain-specific activities that feel impossible to invent alone
- Design implication: Every generated activity must include facilitation tips, timing estimates, group size requirements, and a "what to do if this falls flat" contingency. Activities must feel tested, not experimental.

---

### JS-3: Gamification That Serves Learning

#### Demand-Generating
- **Push**: Stakeholder pressure to "add gamification" resulting in superficial badges and leaderboards that participants see through. Senior engineers feel patronized by childish game mechanics. The trainer knows gamification should work but cannot articulate the design principles connecting game mechanics to learning outcomes.
- **Pull**: Gamification designs where every mechanic is justified by a pedagogical goal. Progression systems that scaffold Bloom's taxonomy. Challenge curves that match Csikszentmihalyi's flow channel. Narrative frames that give context to technical exercises.

#### Demand-Reducing
- **Anxiety**: "Will senior/experienced participants take a gamified workshop seriously?" Fear of the gamification backfiring and being seen as patronizing or childish. "My CTO will think I am turning our architecture training into a video game."
- **Habit**: Throwing a Kahoot quiz at the end of the session and calling it gamification. It is fast, familiar, and participants generally enjoy it even though it only tests recall (Bloom's Level 1).

#### Assessment
- Switch likelihood: **Medium** -- this is a differentiator but not the primary pain point; most people are not actively seeking gamification
- Key blocker: **Anxiety** about audience reception -- fear of looking unserious
- Key enabler: **Push** from stakeholder pressure combined with **Pull** of principled design
- Design implication: The agent must frame gamification choices with explicit pedagogical justification. "This progression system scaffolds from recall to synthesis" not "this makes it fun." Include audience-appropriate framing (the same mechanic described differently for junior developers vs. senior architects).

---

### JS-4: Miro Board Architecture

#### Demand-Generating
- **Push**: Online workshop boards are chaotic. Participants get lost, cannot find the right area, waste 5-10 minutes on navigation, and the facilitator spends more time directing people than teaching. Boards designed on the fly look messy and confuse participants.
- **Pull**: A professional, architect-designed board with clear zones for each workshop phase, intuitive navigation, pre-built participant templates, and visual progress indicators. A board where participants self-navigate without facilitator guidance.

#### Demand-Reducing
- **Anxiety**: "Can an AI design a board I can actually import into Miro? Or will I get a description that takes me 3 hours to build?" The gap between design description and implementable board is significant.
- **Habit**: Using Google Docs for instructions and a simple shared whiteboard. "It is not pretty, but everyone knows how to use a Google Doc."

#### Assessment
- Switch likelihood: **Medium-High** -- critical for online workshops, irrelevant for in-person
- Key blocker: **Anxiety** about the implementation gap -- description vs. usable board
- Key enabler: **Push** from chaotic online sessions losing 15-20% of session time to navigation confusion
- Design implication: The agent must produce actionable board architecture -- zone descriptions with dimensions, color schemes, template specifications that a facilitator can build in 30 minutes or less. Include Miro-specific guidance (frame sizes, sticky note colors, section links).

---

### JS-5: Energy and Timing Management

#### Demand-Generating
- **Push**: Workshops consistently run over time. The "important stuff" gets crammed into the last 30 minutes when attention is at its lowest. Participants are checking phones by hour 2. Breaks are skipped to "make up time," which makes the problem worse. The facilitator is anxious about timing throughout, which reduces their ability to be present.
- **Pull**: A timing plan that works with human attention and energy patterns. Knowing exactly when to shift gear -- energizing activity after a dense concept, reflective activity before a break, contingency buffers for activities that run long. Built-in adaptation points where the facilitator can expand or compress without losing coherence.

#### Demand-Reducing
- **Anxiety**: "What if the group is much slower or faster than the plan assumes? What if an activity bombs and I need to pivot with no backup plan?"
- **Habit**: Linear time-blocking in a spreadsheet (10:00-10:30 Topic A, 10:30-11:00 Topic B). Simple, familiar, and feels "planned" even though it has no adaptation mechanism.

#### Assessment
- Switch likelihood: **High** -- timing anxiety is universal and the current approach (linear spreadsheet) demonstrably fails
- Key blocker: **Anxiety** about rigid plans that do not adapt to real-time dynamics
- Key enabler: **Push** from chronic timing failures combined with **Pull** of energy-aware pacing
- Design implication: The timing plan must include adaptation points with explicit expand/compress options. Not just "20 minutes for activity X" but "20 minutes (can compress to 12 if energy is high, can extend to 25 if group needs more practice; skip if behind schedule without losing learning continuity)."

---

### JS-6: Assessment and Learning Validation

#### Demand-Generating
- **Push**: End-of-session surveys measure satisfaction ("I enjoyed it"), not learning ("I can now do X"). Stakeholders ask "did they actually learn?" and the trainer can only say "I think so, the feedback was positive." No evidence of skill transfer. Repeat bookings are based on entertainment value, not learning effectiveness.
- **Pull**: Embedded formative assessments that make learning visible without feeling like a test. Participants can see their own progression. Facilitator can adjust in real-time. Sponsors get evidence of outcomes tied to specific learning objectives.

#### Demand-Reducing
- **Anxiety**: "Will assessment activities kill the collaborative energy? Will participants feel tested and judged? Will it make the workshop feel like school?"
- **Habit**: One feedback form at the end with 5 Likert scale questions ("Overall, how would you rate this session? 1-5"). Fast, familiar, non-threatening.

#### Assessment
- Switch likelihood: **Medium** -- growing demand from sponsors, but trainers themselves often deprioritize assessment
- Key blocker: **Anxiety** about assessment killing the vibe -- assessment must feel like a learning activity, not a test
- Key enabler: **Push** from sponsor demand for measurable outcomes
- Design implication: Assessment activities must be designed as learning activities that happen to produce evidence. "Teach-back" where pairs explain concepts to each other (validates understanding while reinforcing learning). "Confidence rating" where participants self-assess before and after an activity (non-threatening, produces data).

---

## Cross-Cutting Forces Summary

### Strongest Push Forces (Demand-Generating)
1. Time cost of workshop design (6-12 hours) -- JS-1
2. Creative block on activity design (blank page problem) -- JS-2
3. Chronic timing failures in delivery -- JS-5
4. Default to lecture format because interactive design is hard -- JS-1, JS-2

### Strongest Pull Forces (Demand-Generating)
1. Complete, pedagogically sound workshop plan in under 60 minutes -- JS-1
2. Creative, domain-specific activities impossible to invent alone -- JS-2
3. Energy-aware timing with built-in adaptation -- JS-5
4. Principled gamification with explicit pedagogical justification -- JS-3

### Strongest Anxiety Forces (Demand-Reducing)
1. Domain-specific quality -- will the AI understand my technical topic? -- JS-1, JS-2
2. Untested activities that might fall flat in delivery -- JS-2, JS-3
3. Implementation gap -- design description vs. usable artifact -- JS-4
4. Assessment killing collaborative energy -- JS-6

### Strongest Habit Forces (Demand-Reducing)
1. Reusing existing slide decks and workshop materials -- JS-1
2. Same 5-6 proven activity formats -- JS-2
3. Linear time-blocking in spreadsheets -- JS-5
4. End-of-session satisfaction survey -- JS-6

---

## Design Implications (Agent-Level)

### To Overcome Anxiety (Highest Priority)
1. **Demonstrate domain understanding early**: The agent must produce technically accurate, domain-specific activities in the first interaction. Generic templates are a dealbreaker.
2. **Every activity includes facilitation tips**: Group size, timing, "what if it falls flat" contingency, difficulty adaptation.
3. **Actionable output format**: Activities, board architectures, and timing plans must be implementable within 30 minutes, not just inspirational descriptions.
4. **Audience-appropriate framing**: The same gamification mechanic described differently for junior developers vs. senior architects.

### To Break Habits (Second Priority)
1. **Show the gap**: Help the user see the difference between their current approach (lecture, recycled deck) and the TBR-structured alternative.
2. **Incremental adoption**: Allow users to enhance an existing workshop, not only create from scratch. "Take your current slide deck and show me where to add 4C activities."
3. **Proven over novel**: Activities should feel tested and reliable, with references to methodology (TBR, Bloom's, MDA). Novel activities need explicit "tested with N groups" framing.

### To Amplify Push (Lower Priority -- Already Strong)
1. **Make the cost visible**: "Your current 3-hour lecture has an estimated 35% retention rate. A 4C-structured version with the same content targets 70%."
2. **Highlight delivery risks**: "Without formative assessment checkpoints, you will not know if participants are lost until the final survey."

### To Amplify Pull (Lower Priority -- Already Strong)
1. **Show the before/after**: Generate a comparison between the user's current approach and the agent's proposed redesign.
2. **Quick wins first**: Produce the workshop structure fast, then offer depth (gamification, Miro board, assessment) as opt-in enhancements.
