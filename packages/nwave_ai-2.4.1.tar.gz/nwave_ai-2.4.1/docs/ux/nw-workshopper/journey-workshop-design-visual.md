# Journey: Workshop Design with nw-workshopper

## Journey Overview

**Goal**: Transform a topic + audience + constraints into a complete, facilitator-ready workshop plan
**Persona**: Marco Benedetti (IT Trainer) -- primary; Sofia Rinaldi (Engineering Manager) -- secondary
**Trigger**: Marco has been booked to deliver a 90-minute workshop on "Introduction to Kubernetes Networking" for 16 mid-level DevOps engineers, online via Zoom + Miro, in 10 days.

---

## Emotional Arc

```
Confidence
    ^
    |
    |                                              **** (7) Confident
    |                                         ****      *** (8) Satisfied
    |                                    ****
    |                               **** (5) Energized
    |                          ****
    |                     **** (4) Engaged
    |                ****
    |      **** (2) Guided       (6) Proud
    |  ****                 ****
    | * (1) Overwhelmed ****
    |*             ****
    +---**** (3) Curious --------------------------------------------> Time
         |         |         |         |         |         |         |
       Define    Outcomes   4C Flow  Activities  Timing   Review   Export
```

**Start**: Overwhelmed -- "I have a topic and a date, where do I even begin?"
**Middle**: Engaged -> Energized -- as activities and structure take shape, confidence builds
**End**: Proud -> Satisfied -- "This is the best workshop design I have ever produced"

---

## Journey Flow (ASCII)

```
                                    nw-workshopper Agent Journey
                                    ===========================

  [1] DEFINE CONTEXT          [2] LEARNING OUTCOMES        [3] 4C STRUCTURE
  +-----------------------+   +-----------------------+   +-----------------------+
  | *workshop "K8s Net"   |   | Agent maps outcomes   |   | Agent generates full  |
  | Topic: K8s Networking |-->| to Bloom's levels:    |-->| 4C flow:              |
  | Audience: 16 DevOps   |   | - Remember: terms     |   | - Connections (15m)   |
  | Time: 90 min          |   | - Understand: models   |   | - Concepts (25m)     |
  | Format: Online + Miro |   | - Apply: troubleshoot  |   | - Concrete Prac (35m)|
  +-----------------------+   +-----------------------+   | - Conclusions (15m)  |
                                                          +-----------------------+
         |                           |                           |
    Overwhelmed               Guided, reassured             Curious, excited
    "Where do I start?"       "It knows my domain"          "This structure works"
                                                                  |
                                                                  v
  [6] REVIEW & REFINE        [5] ENERGY & TIMING           [4] ACTIVITIES
  +-----------------------+   +-----------------------+   +-----------------------+
  | Coherence validation: |   | Energy-aware timeline: |   | Domain-specific       |
  | - Bloom's coverage    |<--| - High-energy opener  |<--| activities per 4C:    |
  | - Talk-time ratio     |   | - Deep focus middle   |   | - "Network Bingo"     |
  | - Activity-outcome    |   | - Reflective close    |   | - "Service Mesh       |
  |   alignment           |   | - Expand/compress     |   |    Debate"            |
  | - Timing feasibility  |   |   adaptation points   |   | - "Troubleshoot Lab"  |
  +-----------------------+   +-----------------------+   +-----------------------+
         |                           |                           |
    Proud, confident           Energized, in control       Engaged, creative
    "Every piece connects"     "I can handle any pace"     "These are brilliant"

         |
         v
  [7] EXPORT ARTIFACTS        [OPT-A] GAMIFICATION        [OPT-B] MIRO BOARD
  +-----------------------+   +-----------------------+   +-----------------------+
  | Facilitator Guide     |   | Progression system    |   | Board architecture:   |
  | - Session plan        |   | mapped to Bloom's:    |   | - Zone layout         |
  | - Activity cards      |   | - Level 1: Remember   |   | - Participant frames  |
  | - Timing sheet        |   | - Level 2: Understand  |   | - Navigation flow     |
  | - Participant handout |   | - Level 3: Apply      |   | - Template specs      |
  | - Miro board spec     |   | Challenge curve in    |   | - Color coding        |
  | - Assessment rubric   |   | flow channel          |   | - Facilitator notes   |
  +-----------------------+   +-----------------------+   +-----------------------+
         |                           |                           |
    Satisfied, ready           Creative, confident          Professional, polished
    "I am ready to deliver"    "Gamification with purpose"  "Board IS the workshop"
```

---

## Step Details

### Step 1: Define Context

**Command**: `*workshop "Kubernetes Networking"`
**Agent asks**: Topic, audience proficiency, group size, time slot, format (online/hybrid/in-person), any existing materials

**TUI Interaction**:
```
+-- Workshop Design: Define Context ------------------------------------+
|                                                                       |
|  Let me understand your workshop context.                             |
|                                                                       |
|  Topic: Kubernetes Networking                                         |
|                                                                       |
|  I need to understand a few things before we design:                  |
|                                                                       |
|  1. Who is your audience?                                             |
|     > Mid-level DevOps engineers, 2-3 years experience                |
|                                                                       |
|  2. How many participants?                                            |
|     > 16                                                              |
|                                                                       |
|  3. How much time do you have?                                        |
|     > 90 minutes                                                      |
|                                                                       |
|  4. What format?                                                      |
|     a) Online (Zoom/Teams + Miro)                                     |
|     b) In-person                                                      |
|     c) Hybrid                                                         |
|     > a                                                               |
|                                                                       |
|  5. Do you have existing materials to build on?                       |
|     > I have a 40-slide deck from a previous talk                     |
|                                                                       |
+-----------------------------------------------------------------------+
```

**Emotional State**: Overwhelmed -> Guided
**Integration Checkpoint**: Context object created; all subsequent steps reference this

---

### Step 2: Learning Outcomes

**Agent produces**: 3-5 learning outcomes mapped to Bloom's taxonomy levels, calibrated to audience proficiency and time available

**TUI Output**:
```
+-- Learning Outcomes (Bloom's Calibrated) -----------------------------+
|                                                                       |
|  Based on 90 min with mid-level DevOps engineers:                     |
|                                                                       |
|  LO-1 [Remember] Identify the 4 core K8s networking components       |
|       (Pod network, Service, Ingress, NetworkPolicy)                  |
|                                                                       |
|  LO-2 [Understand] Explain how Pod-to-Pod communication works        |
|       across nodes using CNI plugins                                  |
|                                                                       |
|  LO-3 [Apply] Troubleshoot a broken Service-to-Pod routing           |
|       scenario using kubectl and network diagnostics                  |
|                                                                       |
|  LO-4 [Analyze] Compare CNI plugin approaches (Calico vs Cilium)     |
|       for a given set of network requirements                         |
|                                                                       |
|  Time constraint note: 90 min supports Remember through Analyze.      |
|  Evaluate/Create would need a half-day format.                        |
|                                                                       |
|  Adjust outcomes? [y/n]                                               |
+-----------------------------------------------------------------------+
```

**Emotional State**: Guided -> Reassured
**Design Lever**: Demonstrating domain understanding early builds trust (overcoming Anxiety force)

---

### Step 3: 4C Structure

**Agent produces**: Complete TBR 4C flow with time allocations and phase purposes

**TUI Output**:
```
+-- 4C Workshop Structure (90 min) ------------------------------------+
|                                                                       |
|  CONNECTIONS (15 min) -- Activate prior knowledge                     |
|  "What do you already know? What are you curious about?"              |
|  +-- Activity: Network Bingo (10 min)                                 |
|  +-- Activity: Curiosity Wall (5 min)                                 |
|                                                                       |
|  CONCEPTS (20 min) -- New information, learner-centered               |
|  "Here is what you need to know -- discover it yourselves"            |
|  +-- Activity: Component Card Sort (12 min)                           |
|  +-- Activity: CNI Jigsaw (8 min)                                     |
|                                                                       |
|  CONCRETE PRACTICE (40 min) -- Apply, make mistakes, learn            |
|  "Now DO something with what you learned"                             |
|  +-- Activity: Troubleshooting Lab (25 min)                           |
|  +-- Activity: CNI Debate (15 min)                                    |
|                                                                       |
|  CONCLUSIONS (15 min) -- Synthesize, commit, transfer                 |
|  "What did you learn? What will you do differently?"                  |
|  +-- Activity: Teach-Back Pairs (8 min)                               |
|  +-- Activity: Action Commitment Cards (7 min)                        |
|                                                                       |
|  Facilitator talk time: 14 min / 90 min = 15.5%  [PASS: under 20%]   |
|                                                                       |
+-----------------------------------------------------------------------+
```

**Emotional State**: Curious -> Excited
**Key Moment of Truth**: The 4C structure must feel complete and coherent, not like a list of random activities

---

### Step 4: Activity Design

**Agent produces**: Detailed activity cards for each activity in the 4C flow

**TUI Output (one activity card example)**:
```
+-- Activity Card: Troubleshooting Lab --------------------------------+
|                                                                       |
|  4C Phase: Concrete Practice                                          |
|  Learning Outcome: LO-3 [Apply]                                      |
|  Duration: 25 min (compress: 18 min | extend: 30 min)                |
|  Group Size: Pairs (8 pairs from 16 participants)                     |
|  Format: Miro + shared terminal / sandbox                             |
|                                                                       |
|  SETUP (3 min):                                                       |
|    Each pair receives a pre-configured K8s cluster (sandbox) with     |
|    one broken networking scenario. 4 different scenarios distributed   |
|    across 8 pairs (2 pairs per scenario for comparison).              |
|                                                                       |
|  ACTIVITY (18 min):                                                   |
|    1. Pairs diagnose the issue using kubectl commands                  |
|    2. Document findings on their Miro frame                           |
|    3. Propose and apply a fix                                         |
|    4. Verify the fix works                                            |
|                                                                       |
|  DEBRIEF (4 min):                                                     |
|    One pair per scenario shares their diagnosis approach.              |
|    Facilitator highlights different diagnostic strategies.             |
|                                                                       |
|  FACILITATION TIPS:                                                   |
|    - Circulate between breakout rooms every 3-4 minutes               |
|    - If a pair is stuck for > 5 min, offer one diagnostic hint        |
|    - Common pitfall: pairs fix symptom not cause -- ask "why          |
|      did this break?" not just "how do you fix it?"                   |
|                                                                       |
|  PLAN B (if activity falls flat):                                     |
|    Switch to guided walkthrough: facilitator shares screen,            |
|    participants suggest next diagnostic step. Same learning            |
|    outcome, lower participant autonomy, higher facilitator support.    |
|                                                                       |
|  ASSESSMENT CHECKPOINT:                                               |
|    Can each pair articulate the root cause (not just the fix)?         |
|    If < 50% of pairs identified root cause: extend debrief by 5 min.  |
|                                                                       |
+-----------------------------------------------------------------------+
```

**Emotional State**: Engaged -> Creative
**Design Lever**: Activities that feel custom-designed for the domain, not generic templates

---

### Step 5: Energy and Timing

**Agent produces**: Energy-aware timeline with adaptation points

**TUI Output**:
```
+-- Energy-Aware Timeline (90 min) ------------------------------------+
|                                                                       |
|  Energy                                                               |
|  Level    HIGH |    ***          **                                    |
|           MED  | ***   ***    **  ***          **                      |
|           LOW  |*        ****       ****    **  ****              **   |
|                +--+----+----+----+----+----+----+----+----+----> min   |
|                  0   10   20   30   40   50   60   70   80   90       |
|                  |    |    |    |    |    |    |    |    |    |        |
|                  C1   C1   C2   C2   BR   C3   C3   C3   C4   C4     |
|                                                                       |
|  00-15  CONNECTIONS -- High energy opener                             |
|         Network Bingo (10m) + Curiosity Wall (5m)                     |
|         [Energy: HIGH -- movement, competition, social]               |
|                                                                       |
|  15-35  CONCEPTS -- Focused discovery                                 |
|         Component Card Sort (12m) + CNI Jigsaw (8m)                   |
|         [Energy: MEDIUM -- cognitive load, small group work]          |
|                                                                       |
|  35-40  MICRO-BREAK (5 min)                                          |
|         [Energy: recovery before deep practice]                       |
|                                                                       |
|  40-80  CONCRETE PRACTICE -- Deep engagement                          |
|         Troubleshooting Lab (25m) + CNI Debate (15m)                  |
|         [Energy: LOW->HIGH -- focused work then lively debate]        |
|                                                                       |
|  80-90  CONCLUSIONS -- Reflective close                               |
|         Teach-Back Pairs (8m) + Action Commitment (2m)                |
|         [Energy: MEDIUM -- reflective, personal, forward-looking]     |
|                                                                       |
|  ADAPTATION POINTS:                                                   |
|  @ 35 min: If Concepts ran long, compress break to 3 min             |
|  @ 55 min: If Lab is going well, extend to 30 min, compress Debate   |
|  @ 75 min: If behind, skip Debate -> direct to Conclusions           |
|            (LO-4 becomes take-home reading instead)                   |
|                                                                       |
+-----------------------------------------------------------------------+
```

**Emotional State**: Energized -> In control
**Design Lever**: The timeline is not just a schedule -- it is an energy management plan

---

### Step 6: Review and Validate

**Agent produces**: Coherence validation report

**TUI Output**:
```
+-- Workshop Coherence Review -----------------------------------------+
|                                                                       |
|  LEARNING OUTCOME COVERAGE                                            |
|  LO-1 [Remember]    --> Network Bingo + Card Sort         [COVERED]  |
|  LO-2 [Understand]  --> CNI Jigsaw + Lab context          [COVERED]  |
|  LO-3 [Apply]       --> Troubleshooting Lab               [COVERED]  |
|  LO-4 [Analyze]     --> CNI Debate                        [COVERED]  |
|                                                                       |
|  FACILITATOR TALK TIME                                                |
|  Total facilitator speaking: ~14 min of 90 min = 15.5%    [PASS]     |
|  TBR threshold: < 20%                                                 |
|                                                                       |
|  ACTIVITY-OUTCOME ALIGNMENT                                           |
|  Every activity maps to at least one learning outcome      [PASS]     |
|  No orphan activities (activities without LO connection)   [PASS]     |
|  No orphan outcomes (LOs without activity coverage)        [PASS]     |
|                                                                       |
|  TIMING FEASIBILITY                                                   |
|  Total activity time: 85 min + 5 min break = 90 min       [PASS]     |
|  Buffer via adaptation points: 3 identified                [PASS]     |
|  Contingency for each activity: all have Plan B            [PASS]     |
|                                                                       |
|  BLOOM'S PROGRESSION                                                  |
|  Remember -> Understand -> Apply -> Analyze                [PASS]     |
|  Progressive difficulty, no level skipping                 [PASS]     |
|                                                                       |
|  ASSESSMENT COVERAGE                                                  |
|  Formative checkpoints: 3 embedded (Bingo, Lab, Teach-Back) [PASS]   |
|  Summative: Action Commitment Cards (self-assessment)      [PASS]     |
|                                                                       |
|  Overall: WORKSHOP DESIGN VALIDATED                                   |
|                                                                       |
+-----------------------------------------------------------------------+
```

**Emotional State**: Proud -> Confident
**Key Moment of Truth**: Validation must show all pieces connect -- this is where the user feels "this is real, not just a plan"

---

### Step 7: Export Artifacts

**Agent produces**: Complete facilitator package

**TUI Output**:
```
+-- Export: Facilitator Package ----------------------------------------+
|                                                                       |
|  Generated artifacts:                                                 |
|                                                                       |
|  1. facilitator-guide.md                                              |
|     Complete session plan with minute-by-minute instructions,          |
|     facilitator notes, and adaptation decision points.                |
|                                                                       |
|  2. activity-cards/                                                   |
|     Individual activity cards (6 activities) with setup,              |
|     instructions, facilitation tips, Plan B, and timing.              |
|                                                                       |
|  3. timing-sheet.md                                                   |
|     Energy-aware timeline with adaptation points and                  |
|     expand/compress guidance per activity.                            |
|                                                                       |
|  4. participant-handout.md                                            |
|     Pre-workshop prep + post-workshop reference + action              |
|     commitment template.                                              |
|                                                                       |
|  5. miro-board-spec.md                                                |
|     Board architecture with zone descriptions, frame sizes,           |
|     color coding, and participant template specifications.            |
|                                                                       |
|  6. assessment-rubric.md                                              |
|     Formative assessment checkpoints with observable indicators       |
|     and adjustment triggers.                                          |
|                                                                       |
|  All artifacts saved to: docs/workshops/k8s-networking/               |
|                                                                       |
+-----------------------------------------------------------------------+
```

**Emotional State**: Satisfied -> Ready
**Design Lever**: Tangible, usable output -- not "ideas" but a complete package the facilitator can use tomorrow

---

## Optional Enhancement Steps

### OPT-A: Gamification Layer

**Command**: `*gamify` (within workshop context)

The agent designs a gamification system mapped to the existing 4C structure:
- Progression: participants unlock "levels" as they complete each 4C phase (Bloom's as difficulty curve)
- Challenge: Troubleshooting Lab has difficulty tiers (easy/medium/hard scenarios)
- Narrative: participants are "Network Engineers" called in to fix a production incident (context for all activities)
- Feedback: visible progress on Miro board (team markers advance through zones)
- MDA justification provided for every mechanic

### OPT-B: Miro Board Architecture

**Command**: `*miro-board` (within workshop context)

The agent designs the board architecture with:
- 4 main zones (one per C), connected by navigation arrows
- Participant frames within each zone
- Color coding: blue (Connections), green (Concepts), orange (Practice), purple (Conclusions)
- Timer/progress section visible at all times
- Facilitator-only notes section (hidden from participants during session)

---

## Shared Artifacts

| Artifact | Source | Consumers | Risk |
|----------|--------|-----------|------|
| Workshop context (topic, audience, time, format) | Step 1 input | All subsequent steps | HIGH -- context mismatch cascades |
| Learning outcomes (LO-1 through LO-4) | Step 2 output | Steps 3, 4, 5, 6 (alignment) | HIGH -- orphan outcomes = failed workshop |
| 4C structure | Step 3 output | Steps 4 (activities), 5 (timing), 6 (validation) | HIGH -- structure change requires cascade update |
| Activity cards | Step 4 output | Steps 5 (timing), 6 (validation), 7 (export) | MEDIUM -- individual card changes are isolated |
| Energy timeline | Step 5 output | Step 6 (validation), 7 (export) | MEDIUM |
| Coherence report | Step 6 output | Step 7 (export), user decision to iterate | LOW -- read-only |
