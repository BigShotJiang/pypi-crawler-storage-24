# JTBD Job Stories: nw-workshopper Agent

## Job Classification

**Type**: Greenfield (Job 1 -- Build Something New)
**Domain**: AI-assisted workshop design for IT training, gamification, and facilitation
**Agent Category**: CROSS_WAVE specialist

---

## Personas

### Persona 1: Marco Benedetti -- IT Trainer (Freelance)

**Who**: Freelance IT trainer delivering 3-4 workshops per month on cloud, DevOps, and development topics
**Demographics**:
- High technical proficiency, moderate pedagogical training (learned on the job)
- Designs 2-3 new workshops per quarter, iterates on existing ones weekly
- Works remotely, delivers online workshops via Zoom + Miro
- Motivated by participant satisfaction scores and repeat bookings

**Pain Points**:
- Spends 6-12 hours designing a 4-hour workshop from scratch
- Defaults to lecture-heavy format because interactive activities take too long to design
- Knows about TBR and active learning but struggles to apply them consistently
- Miro boards feel empty and unstructured -- participants get lost

**Success Metrics**:
- Workshop design completed in under 2 hours
- Facilitator talk time under 20% of total session
- Participant engagement score above 4.2/5.0

### Persona 2: Sofia Rinaldi -- Engineering Manager

**Who**: Engineering manager at a mid-size SaaS company, responsible for onboarding and upskilling a team of 12 developers
**Demographics**:
- Strong technical background, minimal training/facilitation experience
- Designs 1-2 internal workshops per quarter (onboarding, tech adoption)
- In-person team setting, occasionally hybrid
- Motivated by reducing onboarding time and increasing team autonomy

**Pain Points**:
- Has domain expertise but no idea how to structure it into a learning experience
- Previous internal trainings devolved into 3-hour lectures with glazed eyes
- Does not know how to gauge whether participants actually learned anything
- Feels like an impostor as a "trainer" -- she is a manager who needs to teach

**Success Metrics**:
- New hire productive within 2 weeks instead of 4
- Team members can explain concepts to each other after the workshop
- Workshop feels professional despite being designed by a non-trainer

### Persona 3: Kenji Takahashi -- Agile Coach

**Who**: Agile coach facilitating retrospectives, team-building, and process workshops across 4 teams
**Demographics**:
- Expert facilitator, strong in group dynamics and process design
- Runs 6-8 facilitated sessions per month
- Mix of in-person, remote, and hybrid
- Motivated by team psychological safety and continuous improvement

**Pain Points**:
- Retrospective formats get stale -- teams disengage after the 10th "Start/Stop/Continue"
- Needs fresh activity designs but finds it time-consuming to research and adapt them
- Gamification ideas from the internet feel gimmicky and disconnected from learning goals
- Wants to measure whether facilitated sessions actually improve team performance

**Success Metrics**:
- Teams rate sessions as "valuable" at 4.0/5.0 or higher
- New activity formats introduced every 2 weeks
- Measurable improvement in team health metrics after facilitated sessions

### Persona 4: Aisha Okonkwo -- Developer Advocate

**Who**: Developer advocate at a cloud platform company, designing hands-on labs and community workshops
**Demographics**:
- Deep technical expertise, strong presentation skills
- Designs 2-3 workshops per quarter for conferences and community events
- Large groups (30-100 participants), time-constrained (45-90 minutes)
- Motivated by participant completion rates and community engagement

**Pain Points**:
- Conference workshops have brutal time constraints -- 60 minutes for complex topics
- Hands-on labs need precise timing or participants fall behind and disengage
- Scaling workshops to 50+ participants requires self-paced elements but loses the collaborative energy
- Post-workshop follow-up materials are an afterthought, reducing long-term impact

**Success Metrics**:
- 80%+ of participants complete the hands-on exercise within time
- Workshop rated 4.5/5.0 at conference feedback
- Follow-up materials drive measurable community engagement (repo stars, discussion posts)

---

## Job Stories

### Job Story 1: Workshop Structure Design

**When** I have a technical topic I need to teach and a target audience in mind,
**I want to** get a complete, time-boxed workshop structure with activities mapped to learning outcomes,
**so I can** have a facilitator-ready session plan without spending days on instructional design.

#### Functional Job
Transform a topic + audience + time constraint into a structured learning experience using proven pedagogical frameworks (TBR 4Cs, Bloom's taxonomy).

#### Emotional Job
Feel confident that the workshop structure is pedagogically sound, not just "slides with exercises bolted on."

#### Social Job
Be seen as a facilitator who delivers engaging, well-structured sessions -- not someone who reads slides for 3 hours.

#### Forces Analysis
- **Push**: Designing a good interactive workshop takes 6-12 hours; most people default to lecture because it is faster to prepare
- **Pull**: A complete 4C-structured plan with timed activities, facilitator notes, and learning checkpoints in under an hour
- **Anxiety**: "Will the AI understand my specific technical domain well enough to design meaningful activities?"
- **Habit**: Copy-pasting last quarter's workshop deck and changing the title

---

### Job Story 2: Activity Design for Learning Outcomes

**When** I know what participants need to learn (a specific skill, concept, or mental model) and how much time I have,
**I want to** get creative, engaging activities that are specifically designed to produce that learning outcome,
**so I can** replace passive lectures with activities where participants discover and practice the material.

#### Functional Job
Generate activities that map to specific levels of Bloom's taxonomy (remember, understand, apply, analyze, evaluate, create) for a given learning outcome.

#### Emotional Job
Feel creative and inspired rather than stuck staring at a blank page trying to invent exercises.

#### Social Job
Be recognized by participants as someone who makes learning genuinely fun, not someone who forces awkward "icebreakers."

#### Forces Analysis
- **Push**: Generic activity templates (Kahoot quiz, group discussion, case study) feel repetitive and disconnected from the specific technical content
- **Pull**: Activities that feel custom-designed for the topic, that make participants go "that was clever"
- **Anxiety**: "Will the activities actually work with my group size and format, or will they fall flat?"
- **Habit**: Recycling the same 5 activities (quiz, pair programming, group discussion, demo, Q&A) for every workshop

---

### Job Story 3: Gamification That Serves Learning

**When** I want to increase engagement and motivation in a workshop without cheapening the learning experience,
**I want to** apply game mechanics (progression, challenge, narrative, feedback loops) that are specifically designed to scaffold difficulty and reinforce learning outcomes,
**so I can** make the workshop feel rewarding and motivating without participants feeling like they are playing a pointless game.

#### Functional Job
Design gamification layers (point systems, progression mechanics, narrative arcs, challenge curves) that map to specific pedagogical goals.

#### Emotional Job
Feel that the gamification is elegant and purposeful, not bolted-on decoration.

#### Social Job
Be seen as an innovative facilitator who uses game design thoughtfully, not as someone who cheapened a serious topic with gimmicks.

#### Forces Analysis
- **Push**: "Add gamification" pressure from stakeholders who think points and badges automatically equal engagement; participants see through shallow gamification
- **Pull**: A gamification design where every mechanic serves a learning outcome -- progression scaffolds Bloom's levels, challenges match the flow channel, narrative frames the learning journey
- **Anxiety**: "Will senior engineers take a gamified workshop seriously, or will they feel patronized?"
- **Habit**: Adding a Kahoot quiz at the end and calling it "gamification"

---

### Job Story 4: Miro Board Architecture

**When** I am designing an online or hybrid workshop and need participants to collaborate visually,
**I want to** get a complete Miro board architecture with zones, flows, templates, and facilitator guides,
**so I can** run a session where the board itself guides participants through the learning journey without constant facilitator direction.

#### Functional Job
Design a Miro board layout with distinct zones for each 4C phase (Connections, Concepts, Concrete Practice, Conclusions), with participant templates, navigation cues, and timing markers.

#### Emotional Job
Feel that the board is a crafted learning environment, not a random collection of sticky notes.

#### Social Job
Be seen as a facilitator who runs seamless online workshops where participants are never confused about "where to click."

#### Forces Analysis
- **Push**: Online workshops feel chaotic -- participants get lost on the Miro board, cannot find the right area, spend 5 minutes figuring out how to use sticky notes instead of learning
- **Pull**: A board architecture so intuitive that participants self-navigate through the workshop phases, with the board itself serving as both workspace and progress indicator
- **Anxiety**: "Will participants with different Miro experience levels be able to use the board, or will I lose 15 minutes to technical difficulties?"
- **Habit**: Sharing a Google Doc with instructions and hoping people follow along

---

### Job Story 5: Energy and Timing Management

**When** I have a fixed time slot (45 minutes, 90 minutes, half-day, full-day) and a set of learning outcomes to achieve,
**I want to** get a timing plan that manages participant energy through deliberate pacing -- high-energy openers, focused deep-dives, reflective closes, and strategic breaks,
**so I can** maximize learning effectiveness by working with human attention and energy patterns, not against them.

#### Functional Job
Create a session timeline with activity types matched to energy levels, including transitions, breaks, and contingency buffers for activities that run long or short.

#### Emotional Job
Feel in control of the session timing and confident that the pacing will feel natural, not rushed or dragging.

#### Social Job
Be seen as a facilitator who "reads the room" -- sessions that feel perfectly paced, never death-by-PowerPoint.

#### Forces Analysis
- **Push**: Workshops consistently run over time, the last 30 minutes are always rushed, participants are checking phones by hour 2, the "important stuff" gets crammed into the end when attention is lowest
- **Pull**: A timing plan with built-in energy management -- knowing exactly when to shift gear, when to break, when to energize, with contingency plans for each segment
- **Anxiety**: "What if the group is slower/faster than planned? What if an activity bombs and I need to pivot?"
- **Habit**: Writing "10:00-10:30 Topic A, 10:30-11:00 Topic B" in a spreadsheet and hoping it works out

---

### Job Story 6: Assessment and Learning Validation

**When** I have delivered a workshop and need to know whether participants actually learned what I intended,
**I want to** have embedded assessment checkpoints throughout the workshop (not just an end-of-session survey) that validate learning at each stage,
**so I can** adjust in real-time during the session and demonstrate measurable learning outcomes to stakeholders.

#### Functional Job
Design formative assessment activities (knowledge checks, skill demonstrations, peer teaching) woven into the workshop flow at each learning stage.

#### Emotional Job
Feel confident that learning actually happened, not just "people seemed engaged."

#### Social Job
Demonstrate to sponsors and stakeholders that the workshop produced measurable outcomes, not just positive vibes.

#### Forces Analysis
- **Push**: End-of-session "How was it?" surveys measure satisfaction, not learning; stakeholders ask "did they actually learn?" and the trainer can only say "I think so"
- **Pull**: Embedded checkpoints that make learning visible -- participants can see their own progression, facilitator can adjust in real-time, sponsors get evidence of outcomes
- **Anxiety**: "Will assessment activities feel like a test and kill the collaborative energy?"
- **Habit**: One feedback form at the end with 5 Likert scale questions

---

## 8-Step Universal Job Map: "Design a Technical Workshop"

| Step | Description | Key Activities | Pain Points |
|------|-------------|----------------|-------------|
| 1. **Define** | Clarify learning goals, audience, constraints | Specify topic scope, audience proficiency, time slot, format (online/hybrid/in-person), group size | "I have a vague idea of what to teach but cannot articulate specific learning outcomes" |
| 2. **Locate** | Gather content, references, existing materials | Find relevant content sources, prior workshop materials, domain examples, reference architectures | "I have expertise but no structured content; or I have slides but no activities" |
| 3. **Prepare** | Structure content into learning experience | Apply 4C framework, map content to Bloom's levels, design activities, create Miro board architecture | "This is where I get stuck -- turning knowledge into a structured learning experience" |
| 4. **Confirm** | Validate design before delivery | Check timing feasibility, validate activity-to-outcome alignment, dry-run critical activities | "I never validate my workshop design; I just wing it and hope for the best" |
| 5. **Execute** | Deliver the workshop | Follow facilitator guide, manage timing, adapt to group dynamics | "I lose track of time, skip activities, and revert to lecture when uncertain" |
| 6. **Monitor** | Assess learning during delivery | Run formative assessments, read the room, check participant progress | "I have no idea if participants are learning until I ask at the end" |
| 7. **Modify** | Adapt workshop in real-time | Extend or cut activities based on energy and comprehension, handle unexpected group dynamics | "When something goes wrong, I do not know how to recover gracefully" |
| 8. **Conclude** | Wrap up and capture outcomes | Run Conclusions activities (4th C), collect feedback, produce post-workshop materials, document what to improve | "Conclusions are always rushed; follow-up materials never get created" |

---

## Job Story Traceability

| Job Story | Primary Personas | Job Map Steps Covered | Priority Signal |
|-----------|-----------------|----------------------|-----------------|
| JS-1: Workshop Structure Design | Marco, Sofia | 1 (Define), 3 (Prepare) | Highest frequency, highest pain |
| JS-2: Activity Design | Marco, Kenji, Aisha | 3 (Prepare), 5 (Execute) | Creative block is universal |
| JS-3: Gamification | Marco, Aisha | 3 (Prepare), 5 (Execute) | Differentiator, but niche |
| JS-4: Miro Board Architecture | Marco, Aisha | 3 (Prepare), 4 (Confirm) | Critical for online format |
| JS-5: Energy and Timing | All four personas | 4 (Confirm), 5 (Execute), 7 (Modify) | Universal pain |
| JS-6: Assessment | Sofia, Aisha | 6 (Monitor), 8 (Conclude) | Growing demand from sponsors |
