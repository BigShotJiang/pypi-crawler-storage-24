# JTBD Opportunity Scores: nw-workshopper Agent

## Scoring Method

- **Importance**: Estimated % of target personas rating outcome 4+ on 5-point scale
- **Satisfaction**: Estimated % of target personas rating current solution satisfaction 4+ on 5-point scale
- **Score**: Importance + max(0, Importance - Satisfaction)
- **Data Quality**: Team estimates based on persona analysis and domain expertise (not user survey data). Treat as directional rankings, not absolute scores.

---

## Outcome Statements by Job Map Step

### Step 1: Define (Clarify goals, audience, constraints)

| # | Outcome Statement | Imp. (%) | Sat. (%) | Score | Priority |
|---|-------------------|----------|----------|-------|----------|
| 1.1 | Minimize the time to translate a vague topic idea into specific, measurable learning outcomes | 90% | 25% | 15.5 | Extremely Underserved |
| 1.2 | Minimize the likelihood of setting learning outcomes at the wrong Bloom's level for the audience | 75% | 15% | 13.5 | Underserved |
| 1.3 | Minimize the time to determine optimal session format (online/hybrid/in-person) given constraints | 55% | 50% | 6.0 | Overserved |

### Step 2: Locate (Gather content, references, materials)

| # | Outcome Statement | Imp. (%) | Sat. (%) | Score | Priority |
|---|-------------------|----------|----------|-------|----------|
| 2.1 | Minimize the time to identify which existing content can be reused vs. created fresh | 70% | 40% | 10.0 | Appropriately Served |
| 2.2 | Minimize the likelihood of missing critical domain examples that make activities authentic | 80% | 20% | 14.0 | Underserved |

### Step 3: Prepare (Structure content into learning experience)

| # | Outcome Statement | Imp. (%) | Sat. (%) | Score | Priority |
|---|-------------------|----------|----------|-------|----------|
| 3.1 | Minimize the time to structure content into a 4C (TBR) learning flow | 95% | 10% | 18.0 | Extremely Underserved |
| 3.2 | Minimize the likelihood of creating activities misaligned with learning outcomes | 90% | 20% | 16.0 | Extremely Underserved |
| 3.3 | Minimize the time to design creative, domain-specific activities (not generic templates) | 92% | 15% | 16.9 | Extremely Underserved |
| 3.4 | Minimize the likelihood of designing activities unsuitable for the group size | 70% | 35% | 10.5 | Appropriately Served |
| 3.5 | Minimize the time to design a Miro board architecture for an online workshop | 78% | 12% | 14.4 | Underserved |
| 3.6 | Minimize the likelihood of gamification mechanics disconnected from learning outcomes | 72% | 18% | 12.6 | Underserved |

### Step 4: Confirm (Validate design before delivery)

| # | Outcome Statement | Imp. (%) | Sat. (%) | Score | Priority |
|---|-------------------|----------|----------|-------|----------|
| 4.1 | Minimize the likelihood of timing that does not account for human energy patterns | 85% | 10% | 16.0 | Extremely Underserved |
| 4.2 | Minimize the likelihood of proceeding with activities that have no "Plan B" if they fail | 80% | 15% | 14.5 | Underserved |
| 4.3 | Minimize the time to validate that the workshop plan covers all stated learning outcomes | 75% | 25% | 12.5 | Underserved |

### Step 5: Execute (Deliver the workshop)

| # | Outcome Statement | Imp. (%) | Sat. (%) | Score | Priority |
|---|-------------------|----------|----------|-------|----------|
| 5.1 | Minimize the likelihood of facilitator talk time exceeding 20% of total session | 88% | 12% | 16.4 | Extremely Underserved |
| 5.2 | Minimize the time to adapt when an activity takes longer or shorter than planned | 82% | 20% | 14.4 | Underserved |

### Step 6: Monitor (Assess learning during delivery)

| # | Outcome Statement | Imp. (%) | Sat. (%) | Score | Priority |
|---|-------------------|----------|----------|-------|----------|
| 6.1 | Minimize the likelihood of learning gaps going undetected until after the session | 78% | 10% | 14.6 | Underserved |
| 6.2 | Maximize the likelihood that assessment feels like learning, not testing | 80% | 15% | 14.5 | Underserved |

### Step 7: Modify (Adapt workshop in real-time)

| # | Outcome Statement | Imp. (%) | Sat. (%) | Score | Priority |
|---|-------------------|----------|----------|-------|----------|
| 7.1 | Minimize the time to identify and execute a contingency when an activity fails | 75% | 10% | 14.0 | Underserved |
| 7.2 | Minimize the likelihood of losing learning continuity when skipping or replacing activities | 70% | 12% | 12.8 | Underserved |

### Step 8: Conclude (Wrap up and capture outcomes)

| # | Outcome Statement | Imp. (%) | Sat. (%) | Score | Priority |
|---|-------------------|----------|----------|-------|----------|
| 8.1 | Minimize the time to produce post-workshop follow-up materials | 65% | 15% | 11.5 | Appropriately Served |
| 8.2 | Minimize the likelihood of Conclusions phase being rushed or skipped | 72% | 10% | 13.4 | Underserved |
| 8.3 | Maximize the likelihood that workshop improvements are captured for next iteration | 60% | 25% | 9.5 | Overserved |

---

## Top Opportunities (Score >= 15 -- Extremely Underserved)

| Rank | # | Outcome Statement | Score | Maps to Job Story |
|------|---|-------------------|-------|-------------------|
| 1 | 3.1 | Minimize the time to structure content into a 4C (TBR) learning flow | 18.0 | JS-1: Workshop Structure Design |
| 2 | 3.3 | Minimize the time to design creative, domain-specific activities | 16.9 | JS-2: Activity Design |
| 3 | 5.1 | Minimize the likelihood of facilitator talk time exceeding 20% | 16.4 | JS-1, JS-2 (TBR north star) |
| 4 | 3.2 | Minimize the likelihood of activities misaligned with learning outcomes | 16.0 | JS-2: Activity Design |
| 5 | 4.1 | Minimize the likelihood of timing that ignores energy patterns | 16.0 | JS-5: Energy and Timing |
| 6 | 1.1 | Minimize the time to translate topic idea into learning outcomes | 15.5 | JS-1: Workshop Structure Design |

## Strong Opportunities (Score 12-15 -- Underserved)

| Rank | # | Outcome Statement | Score | Maps to Job Story |
|------|---|-------------------|-------|-------------------|
| 7 | 6.1 | Minimize the likelihood of undetected learning gaps | 14.6 | JS-6: Assessment |
| 8 | 6.2 | Assessment feels like learning, not testing | 14.5 | JS-6: Assessment |
| 9 | 4.2 | Activities have "Plan B" contingencies | 14.5 | JS-5: Energy and Timing |
| 10 | 3.5 | Minimize time to design Miro board architecture | 14.4 | JS-4: Miro Board |
| 11 | 5.2 | Minimize time to adapt activity timing in real-time | 14.4 | JS-5: Energy and Timing |
| 12 | 2.2 | Minimize likelihood of missing domain examples | 14.0 | JS-1, JS-2 |
| 13 | 7.1 | Minimize time to execute contingency when activity fails | 14.0 | JS-5: Energy and Timing |
| 14 | 1.2 | Learning outcomes at correct Bloom's level | 13.5 | JS-1: Workshop Structure Design |
| 15 | 8.2 | Conclusions phase not rushed or skipped | 13.4 | JS-6: Assessment |
| 16 | 7.2 | Learning continuity when skipping/replacing activities | 12.8 | JS-5: Energy and Timing |
| 17 | 3.6 | Gamification mechanics connected to learning outcomes | 12.6 | JS-3: Gamification |
| 18 | 4.3 | Validate all learning outcomes covered | 12.5 | JS-1: Workshop Structure Design |

## Overserved Areas (Score < 10 -- Simplification Candidates)

| # | Outcome Statement | Score | Note |
|---|-------------------|-------|------|
| 1.3 | Determine optimal session format | 6.0 | Most trainers already know their format constraints; keep simple |
| 8.3 | Capture workshop improvements for next iteration | 9.5 | Nice-to-have, not a primary pain |

---

## Prioritization Summary

### Must Have (Score 15+)
- **Workshop Structure Design (JS-1)**: 4C flow generation, learning outcome mapping, facilitator talk-time guardrails
- **Activity Design (JS-2)**: Domain-specific, Bloom's-aligned activities with facilitation guidance
- **Energy and Timing (JS-5)**: Energy-aware pacing with adaptation points

### Should Have (Score 12-15)
- **Assessment Design (JS-6)**: Formative assessment woven into activities
- **Miro Board Architecture (JS-4)**: Zone-based board design for online workshops
- **Gamification (JS-3)**: Pedagogically grounded game mechanics

### Could Have (Score 10-12)
- Content reuse analysis
- Detailed group size adaptation
- Post-workshop follow-up materials

### Won't Have (First Release)
- Session format recommendation engine
- Automated Miro board generation (API integration)
- Real-time delivery assistance during workshops

---

## Data Quality Notes

- **Source**: Team estimates based on persona analysis, domain expertise (TBR, gamification, pedagogy), and analogous product analysis
- **Sample size**: 4 persona profiles, cross-validated against public training community discussions
- **Confidence**: Medium (directional, not absolute -- re-score after first user feedback)
