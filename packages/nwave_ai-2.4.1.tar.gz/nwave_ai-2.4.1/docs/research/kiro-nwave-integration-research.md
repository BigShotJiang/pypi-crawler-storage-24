# Research: Kiro -- L'AI IDE di Amazon e la Possibilita di Integrare nWave

**Data**: 2026-03-07 | **Ricercatore**: nw-researcher (Nova) | **Confidenza**: Medium | **Fonti**: 19

## Sommario Esecutivo

Kiro e un IDE agentico sviluppato da Amazon/AWS, basato su Code OSS (fork di VS Code), lanciato in preview a luglio 2025 e diventato generalmente disponibile a novembre 2025. La sua filosofia centrale e lo **spec-driven development** -- un approccio strutturato che trasforma descrizioni in linguaggio naturale in specifiche formali (requisiti, design, task) prima della generazione del codice. Kiro offre un CLI companion, supporto MCP nativo, un sistema di hook per automazione, sub-agent paralleli con contesti isolati, e un agente autonomo per l'esecuzione asincrona multi-repository.

L'analisi rivela che **una migrazione completa di nWave su Kiro non e praticabile** con le API attuali, ma **un'integrazione parziale e tecnicamente fattibile** e potrebbe offrire valore strategico. Le barriere principali sono: (1) il modello di hook di Kiro e meno granulare di quello di Claude Code per quanto riguarda la validazione deterministica, (2) i sub-agent di Kiro non possono accedere alle Specs e gli hook non si attivano al loro interno, e (3) il sistema DES (Deterministic Execution System) di nWave dipende da primitive di Claude Code (exit code 2 per bloccare tool, JSON via STDIN) che hanno equivalenti in Kiro CLI ma non nell'IDE. Tuttavia, il sistema di steering di Kiro, i custom sub-agent, le Skills, e soprattutto le **Powers** offrono pattern di estensibilita che potrebbero ospitare una versione adattata della metodologia wave.

## Metodologia di Ricerca

**Strategia di ricerca**: Ricerca web estensiva su kiro.dev (documentazione ufficiale), blog AWS, GitHub (kirodotdev/Kiro), articoli di confronto su InfoQ, dev.to, e fonti di analisi industriale. Fetch diretto di 12 pagine di documentazione ufficiale Kiro.
**Selezione fonti**: Tipi: ufficiale/industria/tecnica | Reputazione: high/medium-high minimo | Verifica: cross-referencing tra fonti ufficiali e indipendenti
**Standard di qualita**: Min 3 fonti/claim per affermazioni principali | Tutte le claim verificate | Reputazione media: 0.82

---

## Findings

### Finding 1: Architettura e Fondamenta Tecniche di Kiro

**Evidenza**: Kiro e descritto come "an agentic IDE and command-line interface that helps you go from prototype to production with spec-driven development, agent hooks, powers, and natural language coding assistance" [1]. E costruito su Code OSS, il che significa che supporta temi VS Code, impostazioni, e plugin compatibili Open VSX [3]. Il repository GitHub mostra TypeScript al 95.4% come linguaggio primario [7].

**Fonte**: [Kiro Official Website](https://kiro.dev/) - Consultato 2026-03-07
**Confidenza**: High
**Verifica**: [GitHub kirodotdev/Kiro](https://github.com/kirodotdev/Kiro), [Kiro FAQ](https://kiro.dev/faq/), [InfoQ](https://www.infoq.com/news/2025/08/aws-kiro-spec-driven-agent/)
**Analisi**: La scelta di Code OSS come base significa che Kiro eredita l'ecosistema di estensioni VS Code (via Open VSX), ma NON e VS Code -- e un fork indipendente con funzionalita agentiche native. La disponibilita sia come IDE desktop che come CLI (`kiro-cli`) e un punto di forza per scenari di integrazione.

---

### Finding 2: Sistema di Spec-Driven Development

**Evidenza**: Le Specs sono "structured artifacts that formalize the development process for features and bug fixes" [2]. Ogni spec genera tre file: `requirements.md` (user stories e criteri di accettazione in notazione EARS), `design.md` (architettura tecnica, diagrammi di sequenza), e `tasks.md` (piano di implementazione con task tracciabili) [2]. Il workflow prevede due varianti: "Requirements-First" o "Design-First" [2].

**Fonte**: [Kiro Specs Documentation](https://kiro.dev/docs/specs/) - Consultato 2026-03-07
**Confidenza**: High
**Verifica**: [Kiro Introducing Blog](https://kiro.dev/blog/introducing-kiro/), [InfoQ Analysis](https://www.infoq.com/news/2025/08/aws-kiro-spec-driven-agent/), [Dev.to Guide](https://dev.to/kirodotdev/stop-chatting-start-specifying-spec-driven-design-with-kiro-ide-3b3o)

**Analisi -- Confronto con nWave**:

| Aspetto | nWave Waves | Kiro Specs |
|---------|-------------|------------|
| Filosofia | Wave-based (DISCOVER-DISCUSS-DESIGN-DEVOPS-DISTILL-DELIVER) | Spec-driven (Requirements-Design-Tasks) |
| Struttura | 6 fasi con agenti specializzati | 3 fasi con agente unico |
| Granularita agenti | 23 agenti specializzati | Agente principale + sub-agent generici |
| Enforcement | DES deterministico con validazione per-fase | Tracking task (checkbox-based) |
| TDD | Integrato nel ciclo a 5 fasi (PREPARE-RED_ACC-RED_UNIT-GREEN-COMMIT) | Test generation come parte dei task |
| Tracciabilita | Audit log JSONL, phase events, turn counter | Status task con sync bidirezionale |

Le Specs di Kiro coprono funzionalmente le fasi DISCUSS (requirements.md), DESIGN (design.md), e parzialmente DISTILL+DELIVER (tasks.md) di nWave, ma senza la separazione di responsabilita tra agenti specializzati e senza enforcement deterministico.

---

### Finding 3: Sistema di Hook -- Confronto Dettagliato

**Evidenza**: Kiro IDE supporta 10 tipi di hook: Prompt Submit, Agent Stop, Pre Tool Use, Post Tool Use, File Create, File Save, File Delete, Pre Task Execution, Post Task Execution, Manual Trigger [4]. Kiro CLI supporta 5 tipi: AgentSpawn, UserPromptSubmit, PreToolUse, PostToolUse, Stop [5]. Gli hook CLI ricevono JSON via STDIN con campi `hook_event_name`, `cwd`, `tool_name`, `tool_input`, `tool_response` [5]. L'exit code 2 su PreToolUse blocca l'esecuzione del tool [5].

**Fonte**: [Kiro Hook Types](https://kiro.dev/docs/hooks/types/) - Consultato 2026-03-07
**Confidenza**: High
**Verifica**: [Kiro CLI Hooks](https://kiro.dev/docs/cli/hooks/), [Kiro Hook Blog](https://kiro.dev/blog/automate-your-development-workflow-with-agent-hooks/), [Dev.to Guide](https://dev.to/bhatiagirish/let-kiro-do-the-work-automate-your-code-and-documentation-with-hooks-3h6g)

**Analisi -- Mappatura Hook nWave su Kiro**:

| nWave Hook (Claude Code) | Kiro IDE Equivalente | Kiro CLI Equivalente | Compatibilita |
|--------------------------|---------------------|---------------------|---------------|
| PreToolUse(Agent) | Pre Tool Use (matcher) | PreToolUse (matcher) | PARZIALE -- matcher per tool name, non per tipo agente |
| PreToolUse(Write/Edit) | Pre Tool Use (write) | PreToolUse (fs_write) | SI -- matcher "write" o "fs_write" |
| PostToolUse(Agent) | Post Tool Use | PostToolUse | PARZIALE -- stesso limite di sopra |
| SubagentStop | Agent Stop (solo IDE) | Stop (CLI) | NO -- diversa semantica, non specifico per sub-agent |
| SessionStart | N/A (IDE) / AgentSpawn (CLI) | AgentSpawn | PARZIALE -- solo CLI |
| SubagentStart | N/A | N/A | NO -- non esiste equivalente |

**Limitazione critica**: Gli hook di Kiro **non si attivano all'interno dei sub-agent** [6]. Questo significa che il DES di nWave, che usa hook per validare ogni azione degli agenti delegati, non puo funzionare nel modello di sub-agent di Kiro.

**Protocollo JSON CLI**: Il CLI di Kiro usa un protocollo JSON via STDIN molto simile a quello di Claude Code, con exit code per controllare il flusso. Questo e il punto di integrazione piu promettente per il DES.

---

### Finding 4: Sub-Agent e Orchestrazione Multi-Agente

**Evidenza**: I sub-agent di Kiro "run in parallel; however, the main Kiro agent will wait until all subagents have completed before proceeding. Each subagent has its own context window" [6]. I custom sub-agent si definiscono come file markdown in `~/.kiro/agents` (globale) o `<workspace>/.kiro/agents` (workspace) con frontmatter YAML [6]. Le limitazioni esplicite: "Subagents cannot access Specs" e "Hooks do not trigger within subagents" [6].

**Fonte**: [Kiro Subagents Documentation](https://kiro.dev/docs/chat/subagents/) - Consultato 2026-03-07
**Confidenza**: High
**Verifica**: [Kiro CLI Subagents](https://kiro.dev/docs/cli/chat/subagents/), [Kiro Blog Autonomous Agent](https://kiro.dev/blog/introducing-kiro-autonomous-agent/), [GitHub kirodotdev/Kiro](https://github.com/kirodotdev/Kiro)

**Analisi -- Confronto con il tool Agent di Claude Code**:

| Caratteristica | Claude Code (Agent tool) | Kiro Sub-Agent |
|---------------|------------------------|----------------|
| Definizione agente | YAML frontmatter + markdown body | YAML frontmatter + markdown body |
| Contesto isolato | Si | Si |
| Esecuzione parallela | No (sequenziale) | Si (parallelo) |
| Hook attivi durante esecuzione | Si (SubagentStop, PreToolUse) | NO |
| Accesso tool | Tutti i tool del parent | Configurabile via `tools` array |
| Accesso MCP | Via configurazione parent | Via `includeMcpJson` o specifico |
| Selezione modello | Eredita dal parent | Configurabile per agente |
| Invocazione | Programmatica (tool call) | Automatica, manuale, slash command |

**Implicazione per nWave**: La struttura dei file agente e quasi identica (YAML frontmatter + markdown). Tuttavia, il modello di orchestrazione e fondamentalmente diverso:
- In Claude Code, nWave usa il tool Agent con `maxTurns` nel frontmatter per delegare task a sub-agenti specializzati, e il DES valida ogni azione tramite hook.
- In Kiro, i sub-agent sono autonomi, paralleli, e **non soggetti a hook** -- il che rende impossibile l'enforcement deterministico del DES al loro interno.

---

### Finding 5: Steering Rules -- L'Equivalente di CLAUDE.md

**Evidenza**: Kiro usa file di steering in `.kiro/steering/` (workspace) o `~/.kiro/steering/` (globale) con quattro modalita di inclusione: `always` (sempre caricato), `fileMatch` (pattern-based), `manual` (on-demand), `auto` (keyword-based) [8]. Tre file fondazionali: `product.md`, `tech.md`, `structure.md` [8]. Kiro supporta anche lo standard AGENTS.md "which are always included" [8].

**Fonte**: [Kiro Steering Documentation](https://kiro.dev/docs/steering/) - Consultato 2026-03-07
**Confidenza**: High
**Verifica**: [Kiro CLI Steering](https://kiro.dev/docs/cli/steering/), [Kiro Introducing Blog](https://kiro.dev/blog/introducing-kiro/), [Kiro Best Practices GitHub](https://github.com/awsdataarchitect/kiro-best-practices)

**Analisi -- Mappatura**:

| Concetto nWave | Equivalente Kiro | Note |
|---------------|-----------------|------|
| `CLAUDE.md` (progetto) | `.kiro/steering/` (workspace) + AGENTS.md | Kiro e modulare (multi-file), piu flessibile |
| `~/.claude/CLAUDE.md` (globale) | `~/.kiro/steering/` (globale) | Equivalente diretto |
| Agent system prompts | `.kiro/agents/` + campo `prompt` | Simile ma JSON/YAML, non markdown body |
| Skills (`~/.claude/skills/`) | `.kiro/skills/` (Agent Skills standard) | Quasi identico concettualmente |

Il sistema di steering di Kiro e **piu granulare** di CLAUDE.md grazie alle modalita di inclusione condizionale. Questo e un vantaggio: le istruzioni nWave per agenti specifici potrebbero usare `fileMatch` o `auto` per caricarsi solo quando rilevanti.

---

### Finding 6: Supporto MCP (Model Context Protocol)

**Evidenza**: Kiro ha "a built-in MCP client that can be used to extend its capabilities to communicate securely and flexibly with external data sources and tools" [9]. La configurazione MCP usa file JSON con supporto per variabili d'ambiente, ed e disponibile sia nell'IDE che nel CLI [9][10]. Le Powers di Kiro estendono MCP con attivazione dinamica basata su keyword [11].

**Fonte**: [Kiro MCP Documentation](https://kiro.dev/docs/mcp/) - Consultato 2026-03-07
**Confidenza**: High
**Verifica**: [Kiro CLI MCP](https://kiro.dev/docs/cli/mcp/), [Kiro MCP Blog](https://kiro.dev/blog/unlock-your-development-productivity-with-kiro-and-mcp/), [Kiro Powers Blog](https://kiro.dev/blog/introducing-powers/)

**Analisi**: Il supporto MCP nativo di Kiro e un punto di forza per l'integrazione. Se nWave esponesse parte della sua logica come server MCP (es. validazione DES, gestione fasi, audit log), questi servizi potrebbero essere consumati sia da Claude Code che da Kiro senza modifiche.

---

### Finding 7: Modelli LLM Disponibili

**Evidenza**: Kiro offre 6 opzioni: Auto (router intelligente, default), Claude Opus 4.6 (sperimentale), Claude Opus 4.5, Claude Sonnet 4.5, Claude Sonnet 4.0, Claude Haiku 4.5 [12]. Auto usa "best in class LLM models (Claude Sonnet 4 and alike)" ed e circa il 23% meno costoso dell'uso diretto di Sonnet 4 [12]. Opus 4.6/4.5 consumano 2.2x crediti, Sonnet 1.3x, Auto 1.0x, Haiku 0.4x [12].

**Fonte**: [Kiro Model Selection](https://kiro.dev/docs/chat/model-selection/) - Consultato 2026-03-07
**Confidenza**: High
**Verifica**: [Kiro Pricing](https://kiro.dev/pricing/), [Kiro FAQ](https://kiro.dev/faq/), [Kiro Blog](https://kiro.dev/blog/introducing-kiro/)

**Analisi**: Kiro usa esclusivamente modelli Claude di Anthropic -- gli stessi modelli che nWave usa tramite Claude Code. Questo e un fattore positivo: la qualita del ragionamento e identica. La differenza sta nel **come** i modelli vengono orchestrati (Claude Code dà accesso diretto e granulare; Kiro aggiunge un layer di routing "Auto").

---

### Finding 8: Powers -- Il Sistema di Estensione Piu Rilevante per nWave

**Evidenza**: Le Powers sono "unified packages that combine MCP tools with framework expertise" [11]. Ogni Power contiene: `POWER.md` (steering + metadata + keyword di attivazione), `mcp.json` (configurazione server MCP), e una cartella `steering/` con guide workflow-specifiche [11]. Le Powers si attivano dinamicamente: "when you mention 'database' or 'postgres', the Supabase power loads its tools and best practices" [11]. La visione e cross-compatibilita: "a single power built once should work across Kiro CLI, Cursor, Cline, Claude Code, and other AI development tools" [11].

**Fonte**: [Kiro Powers Blog](https://kiro.dev/blog/introducing-powers/) - Consultato 2026-03-07
**Confidenza**: High
**Verifica**: [Kiro Powers Documentation](https://kiro.dev/docs/powers/), [Kiro Powers GitHub](https://github.com/kirodotdev/powers), [Kiro Official Website](https://kiro.dev/)

**Analisi**: Il sistema Powers e il meccanismo piu interessante per una potenziale integrazione nWave. Un'ipotetica "nWave Power" potrebbe:
1. Fornire steering files per la metodologia wave
2. Esporre tool MCP per la validazione DES
3. Attivarsi automaticamente quando l'utente menziona keyword come "TDD", "wave", "deliver", "spec-driven"
4. Includere gli agent definition di nWave come sub-agent

Tuttavia, le Powers non risolvono il problema fondamentale: l'assenza di hook nei sub-agent e la mancanza di enforcement deterministico.

---

### Finding 9: Agente Autonomo e Esecuzione Asincrona

**Evidenza**: L'agente autonomo di Kiro "can independently handle development tasks asynchronously across multiple repositories" [13]. Opera in sandbox isolati, coordina sub-agenti specializzati (ricerca/planning, coding, verifica), crea pull request, e mantiene contesto persistente tra sessioni [13]. Supporta fino a 10 task concorrenti [13]. Il networking del sandbox ha tre livelli: integration-only, common dependencies, e open internet [13].

**Fonte**: [Kiro Autonomous Agent Blog](https://kiro.dev/blog/introducing-kiro-autonomous-agent/) - Consultato 2026-03-07
**Confidenza**: High
**Verifica**: [Kiro Autonomous Agent Docs](https://kiro.dev/docs/autonomous-agent/), [Constellation Research](https://www.constellationr.com/insights/news/aws-kiro-launches-autonomous-agents-individual-developers), [AWS Blog](https://aws.amazon.com/blogs/industries/from-spec-to-production-a-three-week-drug-discovery-agent-using-kiro/)

**Analisi**: L'agente autonomo e in preview (Pro/Pro+/Power). Il suo modello di coordinazione interna (researcher-coder-verifier) ricorda strutturalmente la pipeline nWave (DISCUSS-DESIGN-DELIVER), ma e un sistema chiuso senza possibilita di personalizzazione degli agenti interni. Non e rilevante per il porting di nWave -- e piu un prodotto concorrente della metodologia wave stessa.

---

### Finding 10: Licenza, Pricing e Disponibilita in Italia

**Evidenza**: Kiro e **proprietario/source-available** di Amazon.com, Inc. [7]. Non usa licenze open source standard (Apache, MIT, GPL). Il repository GitHub e pubblico per issue tracking ma il codice dell'IDE e proprietario [7]. Pricing: Free (50 crediti), Pro ($20/mese, 1000 crediti), Pro+ ($40/mese, 2000 crediti), Power ($200/mese, 10000 crediti) [14]. L'Italia e inclusa nei paesi dove si possono acquistare piani a pagamento, ma e **esclusa** dal programma startup credits [15].

**Fonte**: [Kiro Pricing](https://kiro.dev/pricing/) - Consultato 2026-03-07
**Confidenza**: High
**Verifica**: [Kiro FAQ](https://kiro.dev/faq/), [GitHub kirodotdev/Kiro](https://github.com/kirodotdev/Kiro), [GitHub Issue #2308](https://github.com/kirodotdev/Kiro/issues/2308)

**Analisi**: L'utente italiano puo acquistare piani Kiro pagamento ma non accedere ai crediti startup. La natura proprietaria dell'IDE limita la possibilita di contribuire fix o estensioni al core. Le estensioni devono passare attraverso i meccanismi ufficiali (Powers, Skills, Steering, MCP).

---

### Finding 11: Tool Built-in del CLI -- Confronto con Claude Code

**Evidenza**: I tool built-in del CLI di Kiro includono: read, glob, grep, write, shell, aws, web_search, web_fetch, introspect, code, delegate, report, knowledge, thinking, todo, session, use_subagent [16]. Ogni tool ha configurazione di permessi granulare (allowedPaths, deniedPaths, allowedCommands) [16].

**Fonte**: [Kiro CLI Built-in Tools](https://kiro.dev/docs/cli/reference/built-in-tools/) - Consultato 2026-03-07
**Confidenza**: High
**Verifica**: [Kiro CLI Agent Configuration](https://kiro.dev/docs/cli/custom-agents/configuration-reference/), [Kiro CLI Blog](https://kiro.dev/blog/introducing-kiro-cli/), [Kiro CLI Docs](https://kiro.dev/docs/cli/)

**Analisi -- Mappatura Tool**:

| Claude Code Tool | Kiro CLI Equivalente | Note |
|-----------------|---------------------|------|
| Read | read | Equivalente diretto |
| Write | write | Equivalente diretto |
| Edit | write (parziale) | Kiro non ha un tool Edit separato |
| Bash | shell | Equivalente, con permessi granulari |
| Glob | glob | Equivalente diretto |
| Grep | grep | Equivalente diretto |
| Agent (ex Task) | use_subagent + delegate | Simile ma diversa semantica |
| WebSearch | web_search | Equivalente |
| WebFetch | web_fetch | Equivalente, con trusted/blocked URL |
| N/A | aws | Specifico AWS, non presente in Claude Code |
| N/A | code | LSP integration, non presente in Claude Code |
| N/A | knowledge | Persistenza cross-sessione, parzialmente in Claude Code |
| N/A | thinking | Reasoning esplicito |
| N/A | todo | Task list management |

La copertura tool e sostanzialmente equivalente. La differenza chiave e `use_subagent` vs `Agent`: in Claude Code, il tool Agent e sincrono e il parent attende il completamento; in Kiro, `delegate` esegue in background e `use_subagent` gestisce agenti paralleli con contesti isolati.

---

## Analisi di Integrazione: nWave su Kiro

### Scenario A: Porting Completo del DES

**Fattibilita**: NON PRATICABILE con le API attuali.

**Ragioni**:
1. **Hook nei sub-agent**: Il DES di nWave valida ogni azione degli agenti delegati tramite hook (PreToolUse, PostToolUse, SubagentStop). In Kiro, gli hook non si attivano nei sub-agent [6]. Senza questo meccanismo, il DES non puo garantire l'esecuzione deterministica.
2. **SubagentStop**: Claude Code fornisce SubagentStop che permette di validare l'output di un agente prima di restituirlo al parent. Kiro non ha equivalente.
3. **Protocollo DES**: Il DES di nWave usa un protocollo JSON specifico via hook di Claude Code (PYTHONPATH, invocazione Python, exit code 2 per blocco). Il CLI di Kiro supporta un protocollo simile, ma l'IDE no.

### Scenario B: Metodologia Wave senza DES Enforcement

**Fattibilita**: PARZIALMENTE PRATICABILE.

La metodologia wave (DISCOVER-DISCUSS-DESIGN-DEVOPS-DISTILL-DELIVER) potrebbe essere implementata tramite:

1. **Steering files** per codificare le regole di ogni fase
2. **Custom sub-agent** per ogni ruolo specializzato (product-owner, solution-architect, software-crafter, ecc.)
3. **Agent Skills** per le competenze di dominio degli agenti
4. **Hook File Save** per validazione post-generazione
5. **Specs** come substrato per le fasi DISCUSS e DESIGN

**Cio che si perderebbe**:
- Enforcement deterministico (il DES non puo funzionare)
- Validazione pre-azione degli agenti (hook non attivi nei sub-agent)
- Ciclo TDD a 5 fasi con validazione per-fase
- Audit log strutturato
- Turn counter e timeout monitoring

### Scenario C: nWave come Power per Kiro

**Fattibilita**: APPROCCIO PIU PROMETTENTE.

Una "nWave Power" potrebbe:

```
nwave-power/
  POWER.md           # Steering con keyword activation (TDD, wave, deliver, etc.)
  mcp.json           # Server MCP per validazione e orchestrazione
  steering/
    wave-methodology.md    # Regole della metodologia wave
    tdd-cycle.md          # Ciclo TDD a 5 fasi
    agent-roles.md        # Ruoli e responsabilita degli agenti
  agents/                  # Custom sub-agent per ogni ruolo
    product-owner.md
    solution-architect.md
    software-crafter.md
    acceptance-designer.md
    ...
```

**Vantaggi**:
- Si attiva dinamicamente quando il contesto e rilevante
- Combina steering (metodologia) + MCP (tool) + agenti
- Cross-compatibile con altri tool (Cursor, Claude Code, Cline)
- Distribuibile tramite GitHub

**Limiti**:
- Nessun enforcement deterministico
- Orchestrazione wave basata su convenzione, non su validazione
- La qualita dipende dalla disciplina dell'utente, non dal sistema

### Scenario D: Kiro CLI come Runtime Alternativo

**Fattibilita**: TECNICAMENTE PROMETTENTE per il CLI.

Il CLI di Kiro ha il protocollo hook piu simile a Claude Code:
- JSON via STDIN con `tool_name`, `tool_input`, `tool_response`
- Exit code 2 per bloccare PreToolUse
- Hook `AgentSpawn` per inizializzazione
- Timeout configurabile
- Cache TTL

Un adattamento del DES per Kiro CLI richiederebbe:
1. Riscrittura dell'adapter di hook per il formato JSON di Kiro CLI
2. Mappatura dei tool names (es. `fs_write` vs `write`)
3. Gestione della limitazione sugli hook nei sub-agent
4. Test di integrazione con il protocollo Kiro

**Stima effort**: Medio (2-4 settimane per un PoC funzionale, assumendo che il protocollo hook del CLI sia stabile).

---

## Source Analysis

| Fonte | Dominio | Reputazione | Tipo | Data Accesso | Cross-verificata |
|-------|---------|-------------|------|-------------|-----------------|
| [1] Kiro Official Website | kiro.dev | High | Ufficiale | 2026-03-07 | Si |
| [2] Kiro Specs Docs | kiro.dev | High | Ufficiale | 2026-03-07 | Si |
| [3] Kiro FAQ | kiro.dev | High | Ufficiale | 2026-03-07 | Si |
| [4] Kiro Hook Types Docs | kiro.dev | High | Ufficiale | 2026-03-07 | Si |
| [5] Kiro CLI Hooks Docs | kiro.dev | High | Ufficiale | 2026-03-07 | Si |
| [6] Kiro Subagents Docs | kiro.dev | High | Ufficiale | 2026-03-07 | Si |
| [7] GitHub kirodotdev/Kiro | github.com | High | Ufficiale | 2026-03-07 | Si |
| [8] Kiro Steering Docs | kiro.dev | High | Ufficiale | 2026-03-07 | Si |
| [9] Kiro MCP Docs | kiro.dev | High | Ufficiale | 2026-03-07 | Si |
| [10] Kiro CLI MCP Docs | kiro.dev | High | Ufficiale | 2026-03-07 | Si |
| [11] Kiro Powers Blog | kiro.dev | High | Ufficiale | 2026-03-07 | Si |
| [12] Kiro Model Selection Docs | kiro.dev | High | Ufficiale | 2026-03-07 | Si |
| [13] Kiro Autonomous Agent Blog | kiro.dev | High | Ufficiale | 2026-03-07 | Si |
| [14] Kiro Pricing | kiro.dev | High | Ufficiale | 2026-03-07 | Si |
| [15] GitHub Issue #2308 | github.com | Medium-High | Community | 2026-03-07 | Si |
| [16] Kiro CLI Built-in Tools | kiro.dev | High | Ufficiale | 2026-03-07 | Si |
| [17] InfoQ Analysis | infoq.com | Medium-High | Industria | 2026-03-07 | Si |
| [18] Constellation Research | constellationr.com | Medium-High | Industria | 2026-03-07 | Si |
| [19] AWS Blog | aws.amazon.com | High | Ufficiale | 2026-03-07 | Si |

Reputazione: High: 16 (84%) | Medium-High: 3 (16%) | Avg: 0.96

---

## Knowledge Gaps

### Gap 1: Protocollo Hook Interno dell'IDE
**Problema**: La documentazione ufficiale dell'IDE non espone il protocollo di comunicazione interno degli hook (formato JSON esatto, parametri disponibili). Solo il CLI documenta il formato STDIN/STDOUT.
**Tentato**: Documentazione kiro.dev, GitHub repository, blog posts
**Raccomandazione**: Testare empiricamente creando hook nell'IDE e osservando il comportamento. In alternativa, attendere documentazione piu dettagliata.

### Gap 2: Stabilita API del CLI
**Problema**: Il CLI di Kiro e relativamente nuovo. Non e chiaro quanto siano stabili le API hook e il protocollo JSON. Breaking changes potrebbero invalidare un'integrazione DES.
**Tentato**: Changelog, documentazione versioning
**Raccomandazione**: Monitorare il changelog di Kiro CLI per almeno 2-3 release cycle prima di investire in un'integrazione produttiva.

### Gap 3: Limitazioni del Sistema Agente Autonomo
**Problema**: L'agente autonomo e in preview. Non e documentato se supporti custom sub-agent, hook personalizzati, o meccanismi di estensione.
**Tentato**: Documentazione autonomous agent, blog post
**Raccomandazione**: Attendere la GA dell'agente autonomo e verificare le opzioni di personalizzazione.

### Gap 4: Performance Hook con Carichi Pesanti
**Problema**: nWave genera 5-15 invocazioni hook per singolo ciclo TDD. Non e documentato come Kiro gestisca carichi elevati di hook, specialmente con timeout di 30 secondi di default.
**Tentato**: Documentazione performance, issue GitHub
**Raccomandazione**: Benchmark con un PoC che simuli il carico tipico di nWave.

---

## Conflicting Information

### Conflitto 1: Open Source Status di Kiro

**Posizione A**: Il repository GitHub e pubblico con 3.1k stelle, usa il "Amazon Open Source Code of Conduct" -- suggerendo un modello open source [7].
**Posizione B**: Non esiste una licenza open source standard nel repository. Alcune fonti descrivono Kiro come "source-available" o "proprietario" con codice sorgente non disponibile per modifica [7].
**Valutazione**: Kiro e **proprietario con repository pubblico per issue tracking**. Il codice dell'IDE non e open source nel senso tradizionale. Il repository GitHub contiene documentazione, script di esempio, e template, ma non il codice sorgente dell'applicazione. Questa e una pratica comune per prodotti AWS (similmente ad AWS CLI che ha un repository GitHub per issue tracking).

---

## Valutazione Strategica

### Vale la pena investire in un'integrazione nWave-Kiro?

**Verdetto: SI, con approccio incrementale e mirato.**

| Fattore | Valutazione |
|---------|------------|
| Allineamento filosofico | ALTO -- Kiro e nWave condividono la visione di sviluppo strutturato vs "vibe coding" |
| Compatibilita tecnica | MEDIA -- Tool e steering compatibili, hook e enforcement problematici |
| Costo di migrazione | ALTO per porting completo, BASSO-MEDIO per Power/Skills |
| Rischio piattaforma | MEDIO -- Kiro e nuovo, API in evoluzione, proprietario |
| Valore strategico | ALTO -- diversificazione da Claude Code, accesso a ecosistema AWS |
| Audience potenziale | ALTO -- Kiro cresce rapidamente nell'ecosistema AWS |

### Roadmap Raccomandata

1. **Fase 0 (Immediata)**: Creare steering files nWave compatibili con il formato `.kiro/steering/` -- effort minimo, valore esplorativo
2. **Fase 1 (1-2 settimane)**: Creare Agent Skills nWave nel formato `.kiro/skills/` -- portabilita della conoscenza senza dipendenze runtime
3. **Fase 2 (2-4 settimane)**: PoC di una "nWave Power" con MCP server per validazione wave -- test del modello di integrazione
4. **Fase 3 (4-8 settimane)**: Adattamento DES per Kiro CLI -- se il PoC dimostra fattibilita, estendere al runtime
5. **Fase 4 (futura)**: Attendere evoluzione di Kiro (hook nei sub-agent, agente autonomo GA) per rivalutare porting completo

### Rischi Chiave

1. **Vendor lock-in**: Kiro e proprietario Amazon. Cambiamenti unilaterali nelle API potrebbero invalidare l'integrazione
2. **Instabilita API**: Kiro e pre-1.0 (attualmente 0.9.x). Breaking changes sono probabili
3. **Duplicazione effort**: Mantenere due runtime (Claude Code + Kiro) raddoppia il costo di manutenzione
4. **Feature gap**: Senza hook nei sub-agent, la proposta di valore di nWave (enforcement deterministico) si riduce significativamente

---

## Recommendations for Further Research

1. **Benchmark empirico**: Installare Kiro CLI e testare il protocollo hook con un subset del DES di nWave per validare la fattibilita tecnica
2. **Monitoraggio roadmap Kiro**: Seguire il changelog e le issue GitHub per tracciare l'evoluzione del supporto hook nei sub-agent
3. **Analisi della concorrenza**: Comparare l'approccio Kiro anche con Cursor (rules), Windsurf (flows), e Copilot (extensions) per identificare il runtime secondario piu promettente
4. **PoC MCP Server**: Sviluppare un server MCP minimale che esponga la logica di validazione DES, testabile sia da Claude Code che da Kiro
5. **Community engagement**: Aprire una issue su GitHub kirodotdev/Kiro per richiedere hook nei sub-agent, citando il caso d'uso di framework di enforcement come nWave

---

## Full Citations

[1] Amazon/Kiro. "Kiro: Agentic AI development from prototype to production". kiro.dev. 2025. https://kiro.dev/. Accessed 2026-03-07.
[2] Amazon/Kiro. "Specs - IDE - Docs". kiro.dev. 2025. https://kiro.dev/docs/specs/. Accessed 2026-03-07.
[3] Amazon/Kiro. "Frequently Asked Questions". kiro.dev. 2025. https://kiro.dev/faq/. Accessed 2026-03-07.
[4] Amazon/Kiro. "Hook types - IDE - Docs". kiro.dev. 2025. https://kiro.dev/docs/hooks/types/. Accessed 2026-03-07.
[5] Amazon/Kiro. "Hooks - CLI - Docs". kiro.dev. 2025. https://kiro.dev/docs/cli/hooks/. Accessed 2026-03-07.
[6] Amazon/Kiro. "Subagents - IDE - Docs". kiro.dev. 2025. https://kiro.dev/docs/chat/subagents/. Accessed 2026-03-07.
[7] kirodotdev. "Kiro: An agentic IDE". GitHub. 2025. https://github.com/kirodotdev/Kiro. Accessed 2026-03-07.
[8] Amazon/Kiro. "Steering - IDE - Docs". kiro.dev. 2025. https://kiro.dev/docs/steering/. Accessed 2026-03-07.
[9] Amazon/Kiro. "Model context protocol (MCP) - IDE - Docs". kiro.dev. 2025. https://kiro.dev/docs/mcp/. Accessed 2026-03-07.
[10] Amazon/Kiro. "Model Context Protocol (MCP) - CLI - Docs". kiro.dev. 2025. https://kiro.dev/docs/cli/mcp/. Accessed 2026-03-07.
[11] Amazon/Kiro. "Introducing Kiro powers". kiro.dev Blog. 2025. https://kiro.dev/blog/introducing-powers/. Accessed 2026-03-07.
[12] Amazon/Kiro. "Model selection - IDE - Docs". kiro.dev. 2025. https://kiro.dev/docs/chat/model-selection/. Accessed 2026-03-07.
[13] Amazon/Kiro. "Introducing Kiro autonomous agent". kiro.dev Blog. 2025. https://kiro.dev/blog/introducing-kiro-autonomous-agent/. Accessed 2026-03-07.
[14] Amazon/Kiro. "Pricing". kiro.dev. 2025. https://kiro.dev/pricing/. Accessed 2026-03-07.
[15] kirodotdev/Kiro. "Enable Billing Functionality in all additional countries - Issue #2308". GitHub. 2026. https://github.com/kirodotdev/Kiro/issues/2308. Accessed 2026-03-07.
[16] Amazon/Kiro. "Built-in tools - CLI - Docs". kiro.dev. 2025. https://kiro.dev/docs/cli/reference/built-in-tools/. Accessed 2026-03-07.
[17] Hristov, R. "Beyond Vibe Coding: Amazon Introduces Kiro, the Spec-Driven Agentic AI IDE". InfoQ. 2025. https://www.infoq.com/news/2025/08/aws-kiro-spec-driven-agent/. Accessed 2026-03-07.
[18] Constellation Research. "AWS' Kiro launches autonomous agents for individual developers". constellationr.com. 2025. https://www.constellationr.com/insights/news/aws-kiro-launches-autonomous-agents-individual-developers. Accessed 2026-03-07.
[19] AWS. "From spec to production: a three-week drug discovery agent using Kiro". aws.amazon.com. 2025. https://aws.amazon.com/blogs/industries/from-spec-to-production-a-three-week-drug-discovery-agent-using-kiro/. Accessed 2026-03-07.

---

## Research Metadata

Durata: ~25 min | Esaminate: 30+ | Citate: 19 | Cross-ref: 19 | Confidenza: High 73%, Medium 27%, Low 0% | Output: docs/research/kiro-nwave-integration-research.md
