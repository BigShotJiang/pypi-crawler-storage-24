# Research Gap Analysis: nw-workshopper Agent

**Date**: 2026-02-26
**Researcher**: nw-researcher (Nova)
**Purpose**: Pre-DESIGN wave planning — identify knowledge domains missing from the 4 commissioned research tasks
**Status**: Complete — ready for DESIGN wave consumption

---

## Context: What Is Already Being Researched

The following 4 domains are already covered by active research tasks and should NOT be repeated:

| Research Task | Key Concepts Covered |
|---|---|
| TBR (Train from the Back of the Room) | 4C framework (Connections, Concepts, Concrete Practice, Conclusions), talk time <20%, spaced practice, Bowman methodology |
| Bloom + Andragogy + COM-B/Fogg | Bloom's taxonomy (all 6 levels), Knowles' adult learning principles, COM-B behavioral model, Fogg Behavior Model, behavioral change design |
| Gamification | MDA framework, Bartle player types, Csikszentmihalyi flow theory, WOW/AHA moment design, extrinsic vs. intrinsic motivation |
| Online Facilitation | Miro board architecture, Zoom fatigue, energy management (online-specific), virtual engagement patterns |

---

## Coverage Assessment of Evaluated Domains

### Domain Assessment Table

| Domain | Covered by Existing Research | Assessment | Notes |
|---|---|---|---|
| Cognitive Load Theory (Sweller) | Partially — Bloom's research touches cognitive demands | GAP | Intrinsic/extraneous/germane load distinctions, element interactivity, worked examples effect not covered |
| Backward Design / UbD (Wiggins & McTighe) | Not covered | GAP | 3-stage backward design process is the design methodology the agent implicitly uses but never names |
| Liberating Structures | Partially — online facilitation may touch some | GAP | 33 microstructures not systematically catalogued for agent use |
| Neuroscience of Learning | Partially — energy management touches attention | GAP | Primacy/recency effect, interleaving, retrieval practice, sleep/consolidation not covered |
| Psychological Safety (Edmondson) | Not covered | GAP | Critical for workshop facilitation conditions — not in any of the 4 areas |
| IT-Specific Pedagogy | Not covered | GAP | Coding katas, TDD workshops, pair/mob as learning techniques — foundational for IT trainer users |
| Curriculum / Learning Arc Design | Not covered | GAP | Spiral curriculum, multi-session arc, prerequisite mapping — critical for C-02 (series support) constraint |
| Facilitation Techniques Beyond TBR | Partially — online facilitation may include some | GAP | World Cafe, Open Space Technology, Fishbowl, Socratic questioning not catalogued |
| Assessment Design (Kirkpatrick) | Not covered | GAP | Level 1-4, ROI, formative vs. summative — directly required by JS-6 and C-05 |
| Learner Experience Design (LXD) | Not covered | LOW PRIORITY — see analysis below |  |
| Problem-Based Learning / Case-Based Learning | Partially — activity design for IT implies PBL | PARTIAL | Core PBL principles not formally covered; recoverable within IT pedagogy research |

---

## Priority Gap Analysis

### HIGH Priority — Agent Cannot Function Well Without These

---

#### GAP-1: Cognitive Load Theory (Sweller)

**Domain**: Cognitive Load Theory — intrinsic, extraneous, and germane load; element interactivity; worked examples effect; expertise reversal effect.

**Why it matters**: The agent designs activities for technically complex topics (Kubernetes, TDD, cloud architecture). Without CLT, it cannot calibrate information density, sequence new concepts appropriately, or avoid the worked-example pitfall of over-explaining to advanced learners. The expertise reversal effect is especially relevant: what works for novices actively hinders experts, and the agent serves both profiles.

**Key concepts the agent needs**:
- Three load types: intrinsic (inherent complexity), extraneous (presentation-imposed), germane (schema formation)
- Element interactivity: high-interactivity content (K8s networking) requires chunking and scaffolding; low-interactivity content can be presented more densely
- Worked examples effect: novices learn better from worked examples; experts learn better from problem-solving
- Expertise reversal effect: instructional methods optimized for novices degrade performance for experts
- Split-attention effect: simultaneous presentation of related information reduces load vs. sequential
- Redundancy principle: duplicate information (same concept in text + diagram) increases extraneous load for experts
- Practical implications: activity design, concept chunking, sequencing, dual-channel consideration (visual + auditory)

**Priority**: HIGH
**Estimated Research Size**: SMALL (1 skill file)

---

#### GAP-2: Backward Design / Understanding by Design (Wiggins & McTighe)

**Domain**: 3-stage backward design process; enduring understandings; essential questions; transfer goals vs. acquisition goals.

**Why it matters**: The agent's entire design flow (learning outcomes → structure → activities → assessment) IS backward design — but without the formal framework, it lacks the vocabulary and validation logic to distinguish terminal outcomes (enduring understandings) from enabling knowledge. C-05 (behavioral change as north star) is directly an expression of UbD's "transfer" concept. Without UbD, the agent cannot explain WHY it starts from outcomes, or detect when a trainer is confusing coverage with understanding.

**Key concepts the agent needs**:
- Stage 1 (Identify Desired Results): Wiggins-McTighe enduring understanding filter — what should participants STILL know in 5 years? What is worth "being familiar with" vs. truly mastering?
- Stage 2 (Acceptable Evidence): assessment task design before activity design; performance tasks vs. knowledge checks
- Stage 3 (Learning Experience): activities and sequence as evidence-gathering, not content delivery
- Transfer goals: participants apply learning in NEW contexts not taught in the workshop (C-05 behavioral transfer)
- Essential questions: open-ended questions that organize the entire session and recur throughout
- The "twin sins" of curriculum design: coverage (marching through content) and activity for activity's sake (hands-on but mindless)

**Priority**: HIGH
**Estimated Research Size**: SMALL (1 skill file)

---

#### GAP-3: IT-Specific Pedagogy

**Domain**: Coding katas, TDD workshop facilitation, pair programming as learning (driver/navigator), mob/ensemble programming, Coding Dojo formats, kata libraries.

**Why it matters**: The agent explicitly serves IT trainers teaching TDD, clean code, architecture, and DevOps. Without IT-specific pedagogy knowledge, the agent can only generate generic activities. With it, the agent can suggest Randori katas for TDD skeptics, recommend appropriate kata difficulty for team skill level, structure a mob programming session as a learning technique (not just a work method), and distinguish coding dojo formats (prepared kata vs. randori vs. kata-per-pair). This is the domain that separates generic instructional design from IT-specific excellence.

**Key concepts the agent needs**:
- Coding kata: structure, purpose, repetition as mastery tool, selection criteria (problem size, constraint richness)
- Kata formats: classical (solo repetition), prepared kata (facilitator demos, group observes), randori (pairs rotate at keyboard), Cyber-Dojo (online kata platform)
- TDD workshop design: Red-Green-Refactor cycle as learning arc, baby steps constraint, test list management, "walking skeleton" kata
- Pair programming as pedagogy: driver/navigator roles, ping-pong pairing (A writes test, B makes it pass, swap), strong-style pairing (whoever has keyboard cannot have idea)
- Mob/ensemble programming: navigator/driver/rest-of-team roles, rotation intervals, mob programming as learning amplifier for team codebases
- Coding Dojo structure: kata selection → demonstration → practice → retrospective
- Applicable for: TDD workshops, clean code, refactoring, SOLID, design patterns, DevOps scripting

**Priority**: HIGH
**Estimated Research Size**: MEDIUM (1-2 skill files)

---

#### GAP-4: Assessment Design — Kirkpatrick Model

**Domain**: Kirkpatrick 4-level evaluation model; formative vs. summative assessment; embedded assessment techniques; Level 3 behavioral follow-up; ROI methodology.

**Why it matters**: C-05 (behavioral change as north star) and JS-6 (Assessment and Learning Validation) explicitly require the agent to design for measurable behavioral change. Without Kirkpatrick, the agent cannot design coherent assessment chains from Level 1 (satisfaction) through Level 4 (business results). The agent needs to embed Level 2 (learning) and Level 3 (behavioral transfer — the 30-day commitment in C-05) checkpoints into activity design and export artifacts. The assessment rubric in US-WS-007 is a Kirkpatrick Level 2 instrument.

**Key concepts the agent needs**:
- Level 1 (Reaction): satisfaction surveys — easy, but insufficient; design them to capture specific facilitation quality signals, not just happiness
- Level 2 (Learning): knowledge/skill acquisition measured during the session; formative assessment techniques that feel like activities (teach-back, peer review, skill demo)
- Level 3 (Behavior): behavioral transfer post-workshop; 30-90 day measurement window; the 30-day commitment (C-05) is a Level 3 design instrument
- Level 4 (Results): business impact; rare but powerful for corporate training — links to sponsors' language
- Formative assessment techniques: knowledge check without "quiz feel" — think-pair-share, gallery walk, teach-back, fist-to-five
- Assessment as activity design principle: every assessment checkpoint is also a learning activity (no wasted time on pure testing)
- New World Kirkpatrick: working backward from Level 4 to design training — directly aligns with C-05 and UbD

**Priority**: HIGH
**Estimated Research Size**: SMALL (1 skill file)

---

### MEDIUM Priority — Agent Quality Significantly Improved With These

---

#### GAP-5: Curriculum / Learning Arc Design

**Domain**: Spiral curriculum (Bruner); learning arc design for multi-session programs; prerequisite mapping; inter-session reinforcement; bloom progression across a series.

**Why it matters**: C-02 (Workshop Series Support) is a mandatory constraint — the agent must design 6×4h and 12×2h series. Without curriculum arc design knowledge, the agent has no framework for how to distribute Bloom's levels across sessions, how to revisit concepts with increasing complexity (spiral), or how to structure prerequisite dependencies. The arc-level vs. session-level outcome hierarchy (C-02) is exactly spiral curriculum applied to corporate training.

**Key concepts the agent needs**:
- Bruner's spiral curriculum: three principles (revisit, increasing complexity, connection to prior learning)
- Arc design: learning progression across sessions; how to plan what gets introduced when and how it deepens
- Prerequisite mapping: identifying conceptual dependencies before sequencing (e.g., "must understand Pod networking before Service routing")
- Inter-session reinforcement: spaced repetition across sessions (supports neuroscience gap too); "bridging" activities that connect last session to this one
- Session N → Session N+1 handoff design: closing rituals that set up opening of next session
- Scope and sequence chart: the planning tool for multi-session programs

**Priority**: MEDIUM
**Estimated Research Size**: SMALL (1 skill file)

**Note**: This gap is primarily triggered by C-02 (series support). If the DESIGN wave de-scopes series support for v1, this gap becomes LOW priority.

---

#### GAP-6: Facilitation Techniques Beyond TBR — Liberating Structures + Large-Group Methods

**Domain**: Liberating Structures (33 microstructures); World Cafe; Open Space Technology; Fishbowl; Socratic questioning; large-group facilitation for 30-100 participants.

**Why it matters**: The agent's activity design (US-WS-004) draws from a repertoire of facilitation techniques. Currently the agent relies on TBR patterns. Liberating Structures provides 33 ready-to-use microstructures that are well-documented and IT-community-adopted (1-2-4-All, TRIZ, Troika Consulting, What-So What-Now What). Persona 4 (Aisha Okonkwo, developer advocate) runs workshops for 30-100 participants — TBR was designed for groups of 10-30. World Cafe and Open Space Technology scale to large groups in ways TBR does not.

**Key concepts the agent needs**:
- Core Liberating Structures: 1-2-4-All (inclusive convergence), TRIZ (creative destruction of bad habits), Troika Consulting (peer coaching), What-So What-Now What (structured reflection), Wise Crowds (parallel consulting), 15% Solutions (finding traction without resources)
- String design: combining microstructures into a workshop sequence
- Large-group facilitation: World Cafe (rotating conversations, 4-5 per table, harvesting across rounds); Open Space Technology (emergent agenda, law of two feet); Fishbowl (structured expert dialogue)
- Socratic questioning: question types that generate insight without giving answers; applicable to Concepts phase of TBR
- Selection heuristics: which technique for which purpose, group size, and time constraint

**Priority**: MEDIUM
**Estimated Research Size**: MEDIUM (1-2 skill files)

---

#### GAP-7: Psychological Safety (Edmondson)

**Domain**: Amy Edmondson's psychological safety framework; conditions for learning and risk-taking in workshop settings; facilitation behaviors that build vs. destroy safety.

**Why it matters**: AHA! moments (C-04) require participants to surface confusion, make mistakes, and expose mental models — all of which require psychological safety. The agent's activity design creates conditions for learning, but without psychological safety knowledge, it cannot distinguish activity designs that risk psychological exposure from those that are safe, or recommend facilitator behaviors (inclusive framing, mistake normalization, grading-free environments) that establish the right conditions. Particularly relevant for Persona 2 (Sofia, engineering manager) where the workshop is with her own direct reports — the power dynamic is an active safety threat.

**Key concepts the agent needs**:
- Definition: shared belief that the team is safe for interpersonal risk taking (Edmondson 1999)
- 4 steps to build safety: frame work as learning opportunity, acknowledge own fallibility, model curiosity, use direct invitations ("What am I missing?")
- Facilitation behaviors that destroy safety: calling on people without warning, public failure without reframe, grades/competition that penalize mistakes, facilitator sarcasm
- Facilitation behaviors that build safety: "no wrong answer" framing, mistake celebration, anonymous input (sticky notes, Miro, polls), explicit "it's okay not to know"
- Workshop-specific application: activity designs that expose participants (live coding, answering questions) require explicit safety framing before execution
- Power dynamics: facilitator-participant + manager-report dynamics; how to flatten hierarchy in workshop settings

**Priority**: MEDIUM
**Estimated Research Size**: SMALL (1 skill file)

---

#### GAP-8: Neuroscience of Learning

**Domain**: Primacy/recency effect; interleaving vs. blocked practice; retrieval practice (testing effect); sleep and consolidation; desirable difficulties.

**Why it matters**: The energy management story (US-WS-005) and multi-session arc design (C-02) both benefit from neuroscience principles. The TBR research may touch attention patterns, but the primacy/recency effect directly justifies WHY important content goes in the first 15 minutes and in the closing, not the middle. Retrieval practice justifies the Conclusions phase structure. Interleaving justifies mixing activity types. For series design, sleep and consolidation justify the spacing between sessions. These are the "why it works" foundations that allow the agent to explain pedagogical choices to trainers rather than just asserting them.

**Key concepts the agent needs**:
- Primacy effect: items presented first are remembered best; critical placement of key concepts in workshop openers
- Recency effect: items presented last are remembered second-best; critical placement of key commitments in Conclusions
- Forgetting curve (Ebbinghaus): 70% of new information lost within 24 hours without reinforcement; justifies spaced practice and inter-session bridging
- Retrieval practice (testing effect): being asked to recall information strengthens memory more than re-reading; every Conclusions activity should trigger retrieval
- Interleaving vs. blocked practice: mixing topic types within a session improves retention vs. blocking all of one type; has direct implications for multi-topic workshops
- Desirable difficulties: making learning slightly harder (spaced practice, interleaving, retrieval) improves long-term retention despite reducing short-term performance
- Sleep and consolidation: new skills consolidate during sleep; for series, this supports overnight spacing between sessions and justifies NOT cramming topics

**Priority**: MEDIUM
**Estimated Research Size**: SMALL (1 skill file)

---

### LOW Priority — Useful But Not Critical for v1

---

#### GAP-9: Learner Experience Design (LXD)

**Domain**: UX principles applied to learning journeys; learner-centered design; journey mapping for learning experiences.

**Why it matters (limited)**: LXD is a useful framing lens but most of its practical substance is already covered by the combination of TBR (learner-centered design), Bloom's (outcome specification), and the UX/journey work already done for the agent (JTBD, journey maps). The agent's design process already IS learner experience design. The marginal value of explicit LXD research is low for v1.

**Priority**: LOW
**Estimated Research Size**: SMALL (1 skill file)
**Recommendation**: Skip for DESIGN wave; revisit for v2 if trainer personas request richer personalization features.

---

#### GAP-10: Problem-Based Learning (PBL) / Case-Based Learning

**Domain**: Open-ended problem structures; case design; scaffolding ill-structured problems; facilitator role in PBL.

**Why it matters (limited)**: PBL principles are largely expressed within the IT-specific pedagogy domain (GAP-3) — coding katas are structured PBL for software. Separate PBL research would add theoretical depth but minimal new practical capability for the agent. The core PBL insight (authentic, real-world problems as the organizing structure) is already embedded in C-05 and US-WS-004's requirement for domain-specific, realistic scenarios.

**Priority**: LOW
**Estimated Research Size**: SMALL (1 skill file)
**Recommendation**: Fold key PBL principles into GAP-3 (IT-Specific Pedagogy) rather than a separate research task.

---

## Synthesis: Coverage Map

```
AGENT CAPABILITY AREA           | RESEARCH COVERAGE
--------------------------------|--------------------------------------------------
Why design from outcomes        | PARTIAL — Bloom's covered; UbD missing (GAP-2)
How to structure a session      | COVERED — TBR 4C is primary framework
How to design activities        | PARTIAL — TBR patterns covered; IT-specific missing (GAP-3)
How to manage cognitive load    | NOT COVERED — CLT missing (GAP-1)
How to assess learning          | NOT COVERED — Kirkpatrick missing (GAP-4)
How to facilitate effectively   | COVERED (TBR) + PARTIAL (Liberating Structures missing, GAP-6)
How to design for engagement    | COVERED — Gamification + flow
How to design online/hybrid     | COVERED — Online facilitation + Miro
How to manage energy            | COVERED (TBR/energy) + PARTIAL (neuroscience missing, GAP-8)
How to create safety for AHA    | NOT COVERED — Psychological safety missing (GAP-7)
How to design a series          | NOT COVERED — Learning arc design missing (GAP-5)
How to explain the "why"        | PARTIAL — behavioral change covered; neuroscience missing (GAP-8)
```

---

## Recommended Research Plan

### Research NOW (Before DESIGN Wave)

These gaps leave the agent unable to handle core user stories or mandatory constraints without them.

| Priority | Gap | Rationale | Size |
|---|---|---|---|
| 1 | GAP-1: Cognitive Load Theory | Activity design quality; calibrating complexity for IT topics | SMALL |
| 2 | GAP-2: Backward Design (UbD) | The agent's implicit design methodology made explicit; C-05 alignment | SMALL |
| 3 | GAP-3: IT-Specific Pedagogy | Core differentiator for IT trainer users; no substitutes | MEDIUM |
| 4 | GAP-4: Assessment Design (Kirkpatrick) | Required by C-05, JS-6, US-WS-007 assessment rubric | SMALL |

### Research BEFORE First Delivery Sprint (Can be Parallel)

These improve quality significantly but do not block DESIGN wave.

| Priority | Gap | Rationale | Size |
|---|---|---|---|
| 5 | GAP-5: Curriculum Arc Design | Required by C-02 (series support); can be parallelized with DESIGN | SMALL |
| 6 | GAP-6: Liberating Structures + Large-Group | Activity repertoire expansion; Aisha persona coverage | MEDIUM |
| 7 | GAP-7: Psychological Safety | AHA! moment enabling conditions; C-04 support | SMALL |
| 8 | GAP-8: Neuroscience of Learning | Theoretical foundation for energy management; "why it works" explanations | SMALL |

### Defer to v2

| Priority | Gap | Rationale |
|---|---|---|
| 9 | GAP-9: Learner Experience Design | Largely redundant with existing coverage |
| 10 | GAP-10: PBL / Case-Based Learning | Fold into IT Pedagogy research (GAP-3) |

---

## Summary Counts

| Category | Count |
|---|---|
| Total domains evaluated | 12 |
| Already covered by commissioned research | 4 |
| HIGH priority gaps (research before DESIGN) | 4 |
| MEDIUM priority gaps (research before first delivery sprint) | 4 |
| LOW priority gaps (defer to v2) | 2 |
| **Total additional research tasks recommended** | **8** |
| **Recommended before DESIGN wave** | **4** |

---

## Research Methodology Note

This gap analysis is based on:
1. Deep reading of all existing nw-workshopper artifacts (user stories, constraints, JTBD, journey map, acceptance criteria)
2. Web search against 12 candidate domains using academic and practitioner sources
3. Analytical cross-referencing of domain scope against specific agent capabilities required by each user story and constraint
4. Priority scoring weighted by: (a) agent capability blocked without domain, (b) frequency of domain concept in user stories/constraints, (c) availability of substitute coverage in existing research

Sources consulted (selected):
- Kirkpatrick Partners: [The Kirkpatrick Model](https://www.kirkpatrickpartners.com/the-kirkpatrick-model/)
- Wiggins & McTighe: [UbD White Paper — ASCD](https://files.ascd.org/staticfiles/ascd/pdf/siteASCD/publications/UbD_WhitePaper0312.pdf)
- Liberating Structures: [liberatingstructures.com](https://www.liberatingstructures.com/)
- Edmondson (1999): [Psychological Safety and Learning Behavior — SAGE](https://journals.sagepub.com/doi/10.2307/2666999)
- Sweller CLT: [Cognitive Load Theory — pressbooks](https://pressbooks.pub/learningenvironmentsdesign/chapter/sweller-cognitive-load-theory-learning-difficulty-and-instructional-design/)
- Bruner Spiral Curriculum: [Structural Learning overview](https://www.structural-learning.com/post/the-spiral-curriculum-a-teachers-guide)
- Nature Reviews Psychology: [Science of effective learning — spaced + retrieval practice](https://www.nature.com/articles/s44159-022-00089-1)
- Agile Alliance: [Mob Programming — Woody Zuill](https://agilealliance.org/resources/experience-reports/mob-programming-agile2014/)
