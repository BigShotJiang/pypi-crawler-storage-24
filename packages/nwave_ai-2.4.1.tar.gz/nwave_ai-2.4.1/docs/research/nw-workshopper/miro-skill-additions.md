# Miro Skill Additions — Ready to Insert into online-facilitation-miro-boards.md

**Date**: 2026-02-26
**Research basis**: miro-4c-series-architecture.md (Findings 19, 20, 21)
**Target file**: nWave/skills/nw-workshopper/online-facilitation-miro-boards.md
**Confidence**: Medium (practitioner-synthesized; see research document for full evidence chain)

---

## Instructions for Insertion

Insert the three sections below into the skill file at these positions:

1. **"4C Workshop Structure — Zone Mapping"** — insert after the "Color Zone Semantics" table (currently at line 147-158 of the skill file), before the "Facilitator-Only Content" section.
2. **"Series Board Architecture"** — insert after the "Board Build Time Estimates" table (currently at line 174-183), before the "Modality Selection" section.
3. **"Mixed-Modality Frame Sizing"** rule — insert at the end of the "Breakout Group Frame Sizing" section (currently ending at line 145), as a standalone rule.

---

## Section 1: 4C Workshop Structure — Zone Mapping

Insert after the Color Zone Semantics table.

---

### 4C Workshop Structure — Zone Mapping

When a workshop follows the TBR (Training from the Back of the Room) 4C model, each phase maps to a distinct Miro frame archetype, color convention, and feature set.

| Phase | Time Proportion | Frame Archetype | Color | Miro Features | Participant Interaction |
|-------|----------------|----------------|-------|---------------|------------------------|
| C1 — Connections | 10-15% of session | Sticky note activation wall or "What I know / What I wonder" dual-column frame | Purple/violet header | Private Mode (prevent anchoring), voting, per-person sticky colors | Individual first, then pair or gallery walk |
| C2 — Concepts | 15-25% of session | Content frame divided horizontally by chunk (max 10 min per chunk) | Blue/teal header | Hide/Reveal (reveal each chunk on cue), Presentation Mode, embedded images | Passive receive → "chunk + check" rhythm; camera on during delivery |
| C3 — Concrete Practice | 50-60% of session | Breakout group frames (one per group) + Full-Group Synthesis frame | Green header (breakout) / Yellow header (synthesis) | Zoom Breakout Rooms synced with Miro frames; voting dots on synthesis frame | Active: hands-on practice, teach-back, simulation, active review |
| C4 — Conclusions | 10-15% of session | Individual Reflection frame + commitment template | Purple/violet header (mirrors C1 for visual closure) | Individual sticky columns, "Exit Ticket" template | Individual reflection → optional pair share → one-sentence public commitment |

**Board real estate rule**: C3 should occupy 40-60% of total frame count. A well-proportioned 90-minute board has: 1 C1 frame + 1-2 C2 frames + 3-5 C3 frames (breakouts + synthesis) + 1 C4 frame.

**Non-linear sequencing**: The 4C model supports micro-cycles — a 10-minute C2 chunk followed immediately by a 10-minute C3 practice activity, repeated 3-4 times within a session, rather than one large C2 block followed by one large C3 block. In this pattern, C2 and C3 frames alternate on the board rather than grouping all C3 frames together.

**Time proportion caveat**: These percentages are practitioner-consensus heuristics (Bowman's official TBR material does not specify percentages). Adjust based on topic complexity: more conceptual topics may need more C2; more skill-based topics should maximize C3.

---

## Section 2: Series Board Architecture

Insert after the "Board Build Time Estimates" table, before the "Modality Selection" section.

---

### Series Board Architecture

For training programs with multiple sessions (e.g., 6 sessions × 4 hours), use a one-board-per-session architecture organized within a Miro Space, with a dedicated Series Index Board as the navigation hub.

#### When to Use One Board Per Session vs. Consolidated Board

| Approach | Use When | Advantage | Risk |
|----------|---------|-----------|------|
| One board per session + INDEX | 4+ sessions; participants new to Miro | Focused cognitive load per session; easier access control | Board sprawl; cross-session navigation requires discipline |
| Consolidated multi-session board | 2-3 sessions; participants experienced with Miro | Simpler management; everything in one place | Board grows large; participants navigate to wrong session |

For programs of 4+ sessions or mixed Miro experience levels, use one board per session.

#### Naming Convention

```
[ProgramCode] S[NN] — [Topic Short Title]
```

Examples:
```
AGILE101 S01 — Foundations and Team Agreements
AGILE101 S02 — Agile Values and Principles
AGILE101 INDEX — Program Navigation Hub
```

Rules:
- Program code first — enables search discovery across teams
- Session number zero-padded to two digits (S01, S02... S10) — ensures correct alphabetical sort order
- Dash separator before topic title
- INDEX board uses same prefix for co-location in search results

#### Miro Space Structure

Create one Miro Space per cohort, with Sections grouping boards by module or week. Create Sections in intended display order (Sections are ordered by creation time and cannot currently be reordered through the standard UI).

```
Space: [Program Name] — [Cohort Identifier]
  Section: Navigation
    Board: [CODE] INDEX — Program Navigation Hub
  Section: Module 1 — [Module Name]
    Board: [CODE] S01 — [Topic]
    Board: [CODE] S02 — [Topic]
  Section: Module 2 — [Module Name]
    Board: [CODE] S03 — [Topic]
    [...]
```

#### Series Index Board (Navigation Hub)

Every series must have one INDEX board. Required elements:

1. **Program header**: program name, cohort dates, facilitator names
2. **Visual progress map**: all sessions as linked cards in a horizontal row; completed sessions marked with green "Complete" sticky; current session highlighted
3. **Participant roster**: participant names with dot-voting attendance tracker (one column per session)
4. **"How to use Miro" reference frame**: sticky note instructions, zoom controls, navigation tips
5. **Next session details**: date, time, Zoom link — updated before each session

Each session card links to its session board using an external URL (copy board link). Update next/previous navigation manually after creating each new board.

#### Per-Session Board Structure

Every session board after Session 1 must begin with a **"Previous Session Summary" frame** as Frame 1:

```
┌──────────────────────────────────────────────────────────────────┐
│  PREVIOUS SESSION: [Title of S[NN-1]]                            │
│  [3-5 key takeaways — pre-populated by facilitator]             │
│                                                                  │
│  [Prompt sticky area]: "One thing I remember from last session:" │
│                                                                  │
│  [Back to INDEX] button    [View S[NN-1] Board] button          │
└──────────────────────────────────────────────────────────────────┘
```

Color convention: Grey/neutral header — this is reference/orientation content, not an activity.

#### Navigation Strip (Every Session Board)

Include a persistent navigation strip as Frame 0 (before the Previous Session Summary) or as a locked sidebar element:

```
[Home: INDEX Board] | Session N of M | [← Previous Session] | [Next Session →]
```

- "Home" and "Previous" buttons: external links to those boards
- "Next" button: absent on the current session board — add after the next board exists
- Session counter: text element, e.g., "Session 3 of 6"

#### Template Duplication — Critical Technical Rule

When creating a new session board by duplicating a template or previous board:
- Use **"Link to"** (not **"Insert link"**) for internal cross-frame navigation within a board — these links survive duplication
- External links (to INDEX, to adjacent sessions) always reference the original board after duplication — update them manually immediately after duplication
- Lock the navigation strip frame after updating links to prevent accidental edits

#### Archive Convention

At session close:
1. Export the completed board as PDF (File → Export → PDF)
2. Attach the PDF to the INDEX board as a linked card or embed
3. Add a "Complete" banner frame to the top of the session board (locked, colored overlay stating "Session Complete — [date]")
4. Participants retain the PDF as their session artifact — they do not need ongoing Miro access to review completed content

---

## Section 3: Mixed-Modality Frame Sizing Rule

Insert at the end of the "Breakout Group Frame Sizing (Practitioner Convention)" section, as a final rule.

---

**Mixed-modality rule**: When a single activity frame contains both individual work zones and group synthesis zones, size to the largest group activity within that frame, not the individual work section. An activity where 4 individuals each write independently, then synthesize together, needs a quad-width frame (3840px) — not four individual-width frames (4 × 960px) — because the synthesis phase uses the full width.

**Decision rule**:

| Activity structure | Frame sizing basis |
|-------------------|--------------------|
| Pure individual work | Per-person: 960px × number of participants |
| Breakout group only | Group dimension: see table above |
| Individual → group synthesis | Group dimension (largest phase drives size) |
| Full-group plenary with individual input columns | 6000-8000px; divide into labeled participant columns |
