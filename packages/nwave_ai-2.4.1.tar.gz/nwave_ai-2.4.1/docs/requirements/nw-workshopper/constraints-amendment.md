# Constraints Amendment: nw-workshopper

> **Status**: Addendum to DISCUSS wave artifacts
> **Date**: 2026-02-26
> **Source**: Product owner constraints provided during DISCUSS wave (post-Luna)

These 5 constraints are mandatory and override or extend any conflicting assumptions in the base user stories.

---

## C-01: Single Multi-Phase Command (NOT a pipeline)

**Constraint**: The agent exposes a **single command** that guides the user through all design phases in one interactive session — like `/nw:discuss` which refines across phases, not a sequence of separate commands like `*workshop → *review → *export`.

**What this means for DESIGN**:
- The agent maintains an internal state machine across phases
- Phases are: Discovery → Outcomes → Structure → Activities → Timing → Validation → Export
- The user navigates phases through conversational turns, not by invoking separate commands
- Optional tools (`*gamify`, `*miro-board`) can still exist as distinct augmentation commands, but the core journey is a single guided flow

**Impact on US-WS-001 through US-WS-007**: The `*workshop`, `*review`, `*export` commands described in the cross-cutting scenarios should be treated as optional aliases/shortcuts, not the primary interaction model. The primary model is a continuous guided conversation.

---

## C-02: Workshop Series Support

**Constraint**: The agent must support not only **single workshops** but also **workshop series**:
- Series of **6 sessions × 4 hours** each (full-day program, e.g., 6-week course)
- Series of **12 sessions × 2 hours** each (intensive program, e.g., 3-month bi-weekly)
- Any N×D format where N = number of sessions, D = duration per session

**What this means for DESIGN**:
- The workshop context (US-WS-001) must capture `series: true/false`, and if true: `session_count` and `session_duration`
- For series, the agent must design **arc-level learning outcomes** (across sessions) AND **session-level learning outcomes**
- 4C structure applies per session, but the Bloom's progression must arc across the series (lower levels early, higher levels late)
- Miro board architecture becomes a board *per session* with consistent navigation conventions across the series
- Energy management applies both within a session AND across the arc (session N opening energy, session N-1 closing energy)

**New scenario**:
```gherkin
Scenario: Series mode context capture
  Given Marco invokes *workshop "Clean Code Mastery" as a series
  And specifies 6 sessions of 4 hours each
  Then the agent captures arc-level context:
    | total_sessions | 6          |
    | session_duration | 4 hours  |
    | delivery_frequency | weekly |
  And generates 3-5 arc-level outcomes spanning the series
  And generates 2-4 session-level outcomes per session
  And the arc outcomes follow Bloom's progression from Remember (session 1) to Create (session 6)
```

---

## C-03: Mandatory WOW Moment Per Session

**Constraint**: Every session (whether standalone or part of a series) **must contain at least one WOW moment** — a designed experience of surprise, delight, or unexpected insight that breaks the expected pattern and creates emotional memory.

**Definition**: A WOW moment is:
- **Surprising**: participants did not expect it
- **Memorable**: creates an emotional anchor for the learning content
- **Intentional**: designed explicitly, not hoped to happen organically
- **Examples**: a live demo that "fails" deliberately to reveal a lesson, a shocking statistic revealed at the right moment, a physical/virtual constraint that forces a breakthrough, a role reversal where participants teach each other

**What this means for DESIGN**:
- Workshop coherence validation (US-WS-006) **must include**: "WOW moment designed and mapped to learning outcome: PASS/FAIL"
- Activity design (US-WS-004) must have a `wow_moment: true/false` field in activity cards
- The agent must suggest WOW moments if none are present in the design and block export if missing
- WOW moments must be tied to a specific learning outcome — surprise for its own sake is insufficient

**New validation scenario**:
```gherkin
Scenario: Missing WOW moment blocks export
  Given a complete workshop design for "Kubernetes Networking"
  And no activity is marked as a WOW moment
  When the agent runs coherence validation
  Then "WOW moment coverage" reports FAIL
  And the failure identifies: "No WOW moment designed"
  And suggests: "Consider making the 'Service selector mismatch' troubleshooting scenario the WOW by revealing the bug live instead of describing it"
  And blocks export until a WOW moment is designated
```

---

## C-04: Mandatory AHA! Moment Per Session

**Constraint**: Every session **must contain at least one AHA! moment** — a designed experience of insight where participants make a connection they did not make before, resulting in a visible shift in understanding.

**Definition**: An AHA! moment is:
- **Insight-driven**: the participant connects new information to existing knowledge
- **Participant-generated**: the facilitator creates conditions for the insight, but the participant has it themselves
- **Verifiable**: the facilitator can observe the AHA! (body language, verbal acknowledgment, quality of work product)
- **Examples**: a debrief question that leads participants to articulate a principle, a "before/after" comparison that makes a pattern visible, a peer review that reveals a blind spot, a failing test that finally passes and "clicks"

**Relationship to WOW**: A WOW moment creates emotional surprise. An AHA! moment creates cognitive insight. They can overlap (e.g., the WOW surprise triggers the AHA! insight) but must be explicitly designed as separate intentions.

**What this means for DESIGN**:
- Workshop coherence validation **must include**: "AHA! moment designed and verifiable: PASS/FAIL"
- Activity cards must have: `aha_moment_trigger` (what the facilitator does), `aha_moment_indicator` (what to observe)
- The agent must verify that at least one activity is explicitly designed to trigger an AHA!
- AHA! moments must be connected to the highest-Bloom's learning outcome of the session

**New validation scenario**:
```gherkin
Scenario: AHA! moment designed with observable indicator
  Given an activity "The Broken Service" is designated as the AHA! moment
  When the agent validates the AHA! design
  Then the activity card includes:
    | aha_trigger   | "Ask pairs: 'What does this error tell you about how routing works?'" |
    | aha_indicator | "Pairs stop debugging and start discussing the mental model"          |
    | aha_lo        | "LO-3: Analyze service routing failures"                              |
```

---

## C-05: Behavioral Change as Core Success Metric

**Constraint**: The north star metric for workshop success is **behavioral change**, not knowledge acquisition. "Participants can recall X" or "Participants understand Y" are insufficient outcomes. The goal is "Participants do Z differently after the workshop."

**What this means for every learning outcome**:
- All learning outcomes must have a **behavioral transfer statement**: "After this workshop, participants will [observable behavior change] when [real-world trigger]"
- Bloom's levels Apply, Analyze, Evaluate, Create are acceptable (they involve doing)
- Bloom's levels Remember and Understand are acceptable only as stepping stones, not terminal outcomes
- Coherence validation must check: "Does every session have at least one Apply-or-higher outcome with a behavioral transfer statement?"

**What this means for activity design**:
- Every Concrete Practice activity must be designed around a **real-world scenario** that mirrors actual work
- Activities at Remember/Understand level must explicitly scaffold toward a higher-level activity
- The export package must include a **30-day behavioral commitment** section: a specific practice the participant commits to doing in the next 30 days

**New acceptance criteria**:
```gherkin
Scenario: Learning outcomes include behavioral transfer statements
  Given a workshop on "Kubernetes Networking"
  When the agent generates learning outcomes
  Then each outcome at Apply level or above includes:
    | Field              | Example                                                             |
    | bloom_level        | Apply                                                               |
    | knowledge_outcome  | "Configure a NetworkPolicy to restrict Pod-to-Pod communication"    |
    | behavioral_transfer | "When a security incident requires network isolation, you will reach for NetworkPolicy rather than application-level auth" |
  And the agent explicitly states: "This workshop succeeds when participants change how they work, not just what they know"

Scenario: 30-day commitment included in export
  Given a validated workshop design
  When the agent generates the facilitator package
  Then participant-handout.md includes a "30-Day Commitment" section
  And the commitment is specific, measurable, and tied to the highest-Bloom's outcome
  And the commitment uses "I will..." format with a real-world context
  Example: "I will write a NetworkPolicy for the next service I deploy, even if the security requirement is not yet formally specified"
```

---

## Impact Summary for DESIGN Wave

| Constraint | Impacts |
|------------|---------|
| C-01: Single command | Agent architecture (state machine), skill structure, command interface |
| C-02: Series support | Context model (session vs. arc), outcome hierarchy, board architecture |
| C-03: WOW moment | Activity card schema, coherence validation (7th dimension), export gate |
| C-04: AHA! moment | Activity card schema, coherence validation (8th dimension), facilitator guide |
| C-05: Behavioral change | Outcome schema (behavioral transfer field), export artifacts (30-day commitment) |

**Updated coherence validation: 8 dimensions** (was 6):

| Dimension | Added by |
|-----------|----------|
| Learning outcome coverage | Original |
| Facilitator talk time | Original |
| Activity-outcome alignment | Original |
| Timing feasibility | Original |
| Bloom's progression | Original |
| Assessment coverage | Original |
| WOW moment coverage | C-03 |
| AHA! moment coverage | C-04 |
