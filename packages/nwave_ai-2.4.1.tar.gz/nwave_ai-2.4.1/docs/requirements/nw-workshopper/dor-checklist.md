# Definition of Ready Checklist: nw-workshopper Agent

## DoR Validation Summary

| Story | DoR Status | Notes |
|-------|-----------|-------|
| US-WS-001: Workshop Context Discovery | PASSED | All 8 items satisfied |
| US-WS-002: Learning Outcome Generation | PASSED | All 8 items satisfied |
| US-WS-003: 4C Workshop Structure | PASSED | All 8 items satisfied |
| US-WS-004: Domain-Specific Activity Design | PASSED | All 8 items satisfied |
| US-WS-005: Energy-Aware Timing | PASSED | All 8 items satisfied |
| US-WS-006: Workshop Coherence Validation | PASSED | All 8 items satisfied |
| US-WS-007: Facilitator Package Export | PASSED | All 8 items satisfied |
| US-WS-008: Pedagogical Gamification Design | PASSED | All 8 items satisfied |
| US-WS-009: Miro Board Architecture | PASSED | All 8 items satisfied |

**Overall DoR Status: PASSED -- all 9 stories ready for DESIGN wave**

---

## Detailed Validation: US-WS-001 (Workshop Context Discovery)

| DoR Item | Status | Evidence |
|----------|--------|---------|
| 1. Problem statement clear, domain language | PASS | "Marco Benedetti is a freelance IT trainer who finds it overwhelming to start designing a new workshop from scratch" -- specific person, specific pain, domain language |
| 2. User/persona identified with characteristics | PASS | Marco Benedetti: freelance IT trainer, 3-4 workshops/month, technical topics, online delivery via Zoom + Miro |
| 3. 3+ domain examples with real data | PASS | 3 examples: Marco (online, existing slides), Sofia (greenfield, no materials), Kenji (incomplete information) |
| 4. UAT scenarios in Given/When/Then (3-7) | PASS | 4 scenarios: complete capture, missing info, greenfield, re-confirmation |
| 5. AC derived from UAT | PASS | 4 AC items derived from the 4 scenarios |
| 6. Right-sized (1-3 days, 3-7 scenarios) | PASS | 1-2 days effort, 4 scenarios, single discoverable feature |
| 7. Technical notes identify constraints | PASS | Context as shared artifact, format detection driving downstream, greenfield vs enhancement |
| 8. Dependencies resolved or tracked | PASS | No dependencies (entry point) |

---

## Detailed Validation: US-WS-002 (Learning Outcome Generation)

| DoR Item | Status | Evidence |
|----------|--------|---------|
| 1. Problem statement clear, domain language | PASS | "struggles to articulate specific, measurable learning outcomes at the right difficulty level" -- specific pedagogical pain |
| 2. User/persona identified | PASS | Marco Benedetti (primary), Sofia Rinaldi (secondary -- "never written a learning outcome") |
| 3. 3+ domain examples | PASS | K8s networking 90 min (4 outcomes), cloud security 6 hrs (6 outcomes), 45-min overload (rejection) |
| 4. UAT scenarios (3-7) | PASS | 4 scenarios: calibrated outcomes, full-day, too many outcomes, user adjustment |
| 5. AC derived from UAT | PASS | 5 AC items covering Bloom's mapping, calibration, adjustment |
| 6. Right-sized | PASS | 1-2 days effort, 4 scenarios |
| 7. Technical notes | PASS | Bloom's levels listed, time heuristics, shared artifact dependency |
| 8. Dependencies | PASS | Depends on US-WS-001 (context) -- tracked |

---

## Detailed Validation: US-WS-003 (4C Workshop Structure)

| DoR Item | Status | Evidence |
|----------|--------|---------|
| 1. Problem statement clear | PASS | "difficult to apply the 4C framework consistently... always drifts toward lecture" |
| 2. User/persona identified | PASS | Marco (knows TBR but cannot apply), Sofia (does not know TBR) |
| 3. 3+ domain examples | PASS | 90-min structure, 45-min compression, 50% lecture request |
| 4. UAT scenarios (3-7) | PASS | 4 scenarios: TBR-compliant, short session, long session with breaks, excessive lecture |
| 5. AC derived from UAT | PASS | 5 AC items: 4 phases present, Concrete Practice largest, talk time, breaks, duration sum |
| 6. Right-sized | PASS | 1-2 days effort, 4 scenarios |
| 7. Technical notes | PASS | TBR framework explained, 20% threshold as guideline, user override path |
| 8. Dependencies | PASS | Depends on US-WS-002 -- tracked |

---

## Detailed Validation: US-WS-004 (Domain-Specific Activity Design)

| DoR Item | Status | Evidence |
|----------|--------|---------|
| 1. Problem statement clear | PASS | "blank page problem -- staring at a learning outcome and having no idea how to turn that into an engaging activity" |
| 2. User/persona identified | PASS | Marco (creative block), Sofia (non-trainer designing activities) |
| 3. 3+ domain examples | PASS | Troubleshooting Lab (K8s), Red-Green Refactor Relay (TDD), format incompatibility detection |
| 4. UAT scenarios (3-7) | PASS | 5 scenarios: domain-specific, complete card, Plan B, format detection, assessment checkpoint |
| 5. AC derived from UAT | PASS | 5 AC items: domain content, outcome mapping, card completeness, format compatibility, no generics |
| 6. Right-sized | PASS | 2-3 days effort, 5 scenarios -- at the upper bound but acceptable given this is the highest-value story |
| 7. Technical notes | PASS | Highest opportunity score (16.9), Plan B addresses anxiety force, assessment checkpoints embedded |
| 8. Dependencies | PASS | Depends on US-WS-003 and US-WS-002 -- tracked |

---

## Detailed Validation: US-WS-005 (Energy-Aware Timing)

| DoR Item | Status | Evidence |
|----------|--------|---------|
| 1. Problem statement clear | PASS | "workshops consistently run over time... important stuff crammed into last 30 minutes" |
| 2. User/persona identified | PASS | Marco (chronic timing failures), applies to all 4 personas |
| 3. 3+ domain examples | PASS | 90-min timeline, half-day multi-cycle, all-high-energy detection |
| 4. UAT scenarios (3-7) | PASS | 4 scenarios: energy annotations, adaptation points, break placement, multi-cycle |
| 5. AC derived from UAT | PASS | 6 AC items: annotations, energy pattern, adaptation, skip impact, breaks, multi-cycle |
| 6. Right-sized | PASS | 1-2 days effort, 4 scenarios |
| 7. Technical notes | PASS | Human attention heuristics, adaptation points as differentiator |
| 8. Dependencies | PASS | Depends on US-WS-004 -- tracked |

---

## Detailed Validation: US-WS-006 (Workshop Coherence Validation)

| DoR Item | Status | Evidence |
|----------|--------|---------|
| 1. Problem statement clear | PASS | "never validates workshop design before delivery... problems only surface during delivery" |
| 2. User/persona identified | PASS | Marco (wings it), Sofia (needs confidence as non-trainer) |
| 3. 3+ domain examples | PASS | All pass, orphan outcome detected, talk time exceeds threshold |
| 4. UAT scenarios (3-7) | PASS | 5 scenarios: all pass, orphan LO, talk time, Bloom's gap, iteration |
| 5. AC derived from UAT | PASS | 5 AC items: 6 dimensions, PASS/FAIL with evidence, remediation, iteration, status |
| 6. Right-sized | PASS | 1-2 days effort, 5 scenarios |
| 7. Technical notes | PASS | Auto-trigger before export, moment of truth for confidence arc |
| 8. Dependencies | PASS | Depends on US-WS-005 -- tracked |

---

## Detailed Validation: US-WS-007 (Facilitator Package Export)

| DoR Item | Status | Evidence |
|----------|--------|---------|
| 1. Problem statement clear | PASS | "spends 2-3 hours producing facilitator materials... single Google Doc that tries to serve all purposes" |
| 2. User/persona identified | PASS | Marco (tedious formatting), Sofia (wants professional output) |
| 3. 3+ domain examples | PASS | Complete online package, in-person adaptation, export before validation |
| 4. UAT scenarios (3-7) | PASS | 5 scenarios: complete package, consistency, in-person adaptation, validation block, no unresolved vars |
| 5. AC derived from UAT | PASS | 5 AC items: artifact types, consistency, separation, validation gate, no placeholders |
| 6. Right-sized | PASS | 1-2 days effort, 5 scenarios |
| 7. Technical notes | PASS | Markdown format, output directory, final step of core journey |
| 8. Dependencies | PASS | Depends on US-WS-006 -- tracked |

---

## Detailed Validation: US-WS-008 (Pedagogical Gamification Design)

| DoR Item | Status | Evidence |
|----------|--------|---------|
| 1. Problem statement clear | PASS | "impossible to design game mechanics that serve pedagogical goals rather than just adding superficial fun" |
| 2. User/persona identified | PASS | Marco (stakeholder pressure), Aisha (conference engagement) |
| 3. 3+ domain examples | PASS | Progression system (K8s), senior audience adaptation, gamification without justification flagged |
| 4. UAT scenarios (3-7) | PASS | 5 scenarios: justification, progression-Bloom's, audience adaptation, flow channel, decoration flag |
| 5. AC derived from UAT | PASS | 5 AC items: justification, audience adaptation, challenge curves, narrative, no decoration |
| 6. Right-sized | PASS | 2 days effort, 5 scenarios |
| 7. Technical notes | PASS | MDA framework, Bartle types note, optional enhancement status |
| 8. Dependencies | PASS | Depends on US-WS-006 -- tracked |

---

## Detailed Validation: US-WS-009 (Miro Board Architecture)

| DoR Item | Status | Evidence |
|----------|--------|---------|
| 1. Problem statement clear | PASS | "participants get lost on the Miro board... creating the board on the fly wastes 10-15 minutes" |
| 2. User/persona identified | PASS | Marco (online workshops), Aisha (large conference workshops) |
| 3. 3+ domain examples | PASS | K8s board architecture, hybrid split, in-person redirect |
| 4. UAT scenarios (3-7) | PASS | 5 scenarios: 4C zones, participant frames, buildable in 30 min, in-person redirect, facilitator notes |
| 5. AC derived from UAT | PASS | 5 AC items: zones, color/navigation, participant frames, build time, format-appropriate |
| 6. Right-sized | PASS | 2 days effort, 5 scenarios |
| 7. Technical notes | PASS | Miro-specific guidance, "board IS the workshop" principle, auto-suggest for online format |
| 8. Dependencies | PASS | Depends on US-WS-006 + format = online/hybrid -- tracked |

---

## Handoff Readiness

### Artifacts Produced

| Phase | Artifact | Location |
|-------|----------|----------|
| JTBD Analysis | Job Stories (6 jobs, 4 personas) | `docs/ux/nw-workshopper/jtbd-job-stories.md` |
| JTBD Analysis | Four Forces Analysis | `docs/ux/nw-workshopper/jtbd-four-forces.md` |
| JTBD Analysis | Opportunity Scores (22 outcomes scored) | `docs/ux/nw-workshopper/jtbd-opportunity-scores.md` |
| Journey Design | Visual Journey Map | `docs/ux/nw-workshopper/journey-workshop-design-visual.md` |
| Journey Design | Structured Journey Schema | `docs/ux/nw-workshopper/journey-workshop-design.yaml` |
| Requirements | User Stories (9 stories) | `docs/requirements/nw-workshopper/user-stories.md` |
| Requirements | Acceptance Criteria (Gherkin) | `docs/requirements/nw-workshopper/acceptance-criteria.md` |
| Requirements | DoR Checklist (this document) | `docs/requirements/nw-workshopper/dor-checklist.md` |

### Downstream Dependencies

| Consumer | What They Receive | Purpose |
|----------|-------------------|---------|
| solution-architect (DESIGN wave) | All artifacts above | Agent architecture design, skill extraction, command structure |
| acceptance-designer (DISTILL wave) | Journey schema + Gherkin scenarios | Executable acceptance test design |
| agent-builder (DELIVER wave) | User stories + AC + journey | Agent definition creation (200-400 line target) |

### Risks

| Risk | Probability | Impact | Mitigation |
|------|-------------|--------|------------|
| Domain-specific activity quality depends on LLM knowledge depth | Medium | High | Agent should acknowledge domain limits and ask user to validate technical accuracy |
| Miro board architecture description-to-implementation gap | Medium | Medium | Include step-by-step build guide with Miro-specific dimensions and colors |
| Gamification may feel patronizing to senior audiences | Low | High | Agent-level audience detection with automatic framing adjustment |
| 20% talk-time rule too rigid for some contexts | Low | Medium | Rule framed as guideline with explicit override path and trade-off disclosure |

### Open Questions (Red Cards)

None remaining -- all questions resolved during analysis. Key decisions made:
1. Core journey (7 Must Have stories) vs. enhancements (2 Should Have)
2. 4C structure is non-negotiable (TBR north star)
3. Gamification requires pedagogical justification (no decoration)
4. Miro board architecture is format-dependent (online/hybrid only)
5. Assessment is embedded in activities, not a separate phase
