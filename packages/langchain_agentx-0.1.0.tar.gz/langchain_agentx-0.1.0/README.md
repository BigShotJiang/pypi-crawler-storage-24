# langchain_agentx

`langchain_agentx` 是一组基于 LangChain / LangGraph 的“代码智能体”工具函数，帮助你在自己的项目里快速集成：

- OpenCode 风格的 LangGraph Agent（代码理解、重构、分析）
- DeepAgent 兼容的 Agent 工厂
- 上下文感知中间件、性能监控等基础设施

## 安装

发布到 PyPI 后，你可以直接通过 pip 安装：

```bash
pip install langchain-agentx
```

## 快速上手

```python
from langchain_agentx import create_opencode_style_agent, create_opencode_style_deepagent

# 这里省略 LangChain / LangGraph 相关模型与工具配置
agent = create_opencode_style_agent(...)
deep_agent = create_opencode_style_deepagent(...)
```

具体的能力和使用方式可以参考源码中的 docstring 以及各模块下的 `README.md`。
