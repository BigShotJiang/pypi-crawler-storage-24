"""
Provider layer for langchain_agentx.

目前仅导出 CompatibleChatOpenAI：
- 在不 fork `langchain-openai` 的前提下，支持 OpenAI 兼容服务的 `reasoning_content` 字段，
  将其注入 LangChain 标准的 `AIMessageChunk.additional_kwargs["reasoning_content"]`。
"""

from .compatible_chat_openai import CompatibleChatOpenAI

__all__ = ["CompatibleChatOpenAI"]

