"""
与 workspace 相关的简单文件写入工具。

注意：
- 这是 `langchain_agentx` 内部使用的实现，不对外暴露到包根。
- 语义与 `tools.common_tools.write_to_workspace` 保持一致，但去掉了
  对本工程其它模块（如 logging_config、common_tools）的依赖。
"""

from __future__ import annotations

import datetime
from pathlib import Path
from typing import Any


def _write_file(file_path: Path, content: str) -> None:
    """最小实现的文件写入，供 write_to_workspace 使用。"""
    file_path.parent.mkdir(parents=True, exist_ok=True)
    with file_path.open("w", encoding="utf-8", errors="ignore") as f:
        f.write(content)


def write_to_workspace(prompt: Any, path_name: str = "prompt", file_name: str = "prompt") -> Path:
    """
    将数据写到 workspace 目录下的指定子目录中。

    行为与原 `tools.common_tools.write_to_workspace` 保持兼容：
    - 根目录固定为 `workspace/`
    - 子目录为 `workspace/{path_name}`
    - 文件名为 `{file_name}-{YYYYMMDDHHMMSS}.txt`

    Args:
        prompt: 要写入的内容（会被转换为字符串）
        path_name: 子目录名称
        file_name: 基础文件名

    Returns:
        实际写入的文件路径（Path 对象）
    """
    base_dir = Path("workspace") / path_name
    base_dir.mkdir(parents=True, exist_ok=True)

    now = datetime.datetime.now()
    time_str = now.strftime("%Y%m%d%H%M%S")
    full_path = base_dir / f"{file_name}-{time_str}.txt"

    _write_file(full_path, str(prompt))
    return full_path

