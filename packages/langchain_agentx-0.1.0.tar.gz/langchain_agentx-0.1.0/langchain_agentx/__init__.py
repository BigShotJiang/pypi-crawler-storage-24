"""
LangChain-based agent utilities for CodeBaseX.

This package provides:
- OpenCode-style LangGraph agent factory (`opencode_style_agent`)
- OpenCode-style DeepAgent-compatible factory (`opencode_style_deep_agent`)
- Optional context-aware middleware for LLM calls (`middleware`)

Typical usage:

```python
from langchain_agentx import create_opencode_style_agent, create_opencode_style_deepagent
```
"""

__version__ = "0.1.0"

from .opencode_style_agent import (  # noqa: F401
    create_opencode_style_agent,
)
from .opencode_style_deep_agent import (  # noqa: F401
    create_opencode_style_deepagent,
)

from .monitoring import (  # noqa: F401
    PerformanceMonitor,
    LlmCallback,
    ToolCallRecord,
    PerformanceMetrics,
)
from .middleware import (  # noqa: F401
    ContextMonitor,
    ContextAwareMiddleware,
    Warning as ContextWarning,
    ServerSkillsMiddleware,
)
from .agent import (  # noqa: F401
    PerformanceEventInjector,
    create_performance_event_injector,
    EVENT_TYPE_PERFORMANCE,
)
from .provider import CompatibleChatOpenAI  # noqa: F401

__all__ = [
    "create_opencode_style_agent",
    "create_opencode_style_deepagent",
    "PerformanceMonitor",
    "LlmCallback",
    "ToolCallRecord",
    "PerformanceMetrics",
    "ContextMonitor",
    "ContextAwareMiddleware",
    "ContextWarning",
    "ServerSkillsMiddleware",
    "PerformanceEventInjector",
    "create_performance_event_injector",
    "EVENT_TYPE_PERFORMANCE",
    "CompatibleChatOpenAI",
]

