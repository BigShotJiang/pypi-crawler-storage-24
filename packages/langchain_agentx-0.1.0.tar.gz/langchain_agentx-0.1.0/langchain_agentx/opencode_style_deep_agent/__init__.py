"""
OpenCode Style Deep Agent

DeepAgent 的 OpenCode Style 版本，使用 finish_reason 驱动的退出逻辑。

与 deepagents.create_deep_agent 接口完全兼容，但底层使用
create_opencode_style_agent 而非 create_agent。
"""

from .graph import create_opencode_style_deepagent

__all__ = [
    "create_opencode_style_deepagent",
]
