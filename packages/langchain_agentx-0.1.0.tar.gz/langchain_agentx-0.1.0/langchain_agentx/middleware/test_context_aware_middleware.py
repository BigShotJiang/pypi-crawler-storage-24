"""
上下文感知（重复调用检测）单元测试
================================

只保留纯单元测试，不依赖真实模型/Agent。
"""

def test_rule_engine_duplicate_detection():
    """单元测试：DuplicateCallsRule 重复调用检测（阈值=3）"""
    from langchain_agentx.middleware.context_rule_engine import DuplicateCallsRule
    from dataclasses import dataclass

    @dataclass
    class MockRecord:
        tool_name: str
        start_time: float
        input_args: dict = None

    @dataclass
    class MockMetrics:
        context_tokens: int = 0

    rule = DuplicateCallsRule()

    records = [
        MockRecord("read_file", 1.0, {"path": "/a.py"}),
        MockRecord("read_file", 2.0, {"path": "/a.py"}),
        MockRecord("read_file", 3.0, {"path": "/a.py"}),  # 重复（3次，达到阈值）
    ]
    warnings = rule.check(records, MockMetrics())
    assert len(warnings) >= 1
    assert any(w.warning_type == "duplicate_calls" for w in warnings)


def test_context_monitor_detect_empty():
    """单元测试：ContextMonitor 无工具调用时返回空"""
    from langchain_agentx.middleware.context_monitor import ContextMonitor
    from langchain_agentx import LlmCallback

    callback = LlmCallback(enable_performance_monitor=True)
    monitor = ContextMonitor(callback)
    warnings = monitor.detect()
    assert warnings == []

