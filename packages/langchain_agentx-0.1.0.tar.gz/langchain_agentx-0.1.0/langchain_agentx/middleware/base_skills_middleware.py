"""
BaseSkillsMiddleware - 技能中间件基类

最小化抽象接口，只保留两个子类真正需要的共同抽象。
具体实现逻辑由子类自行决定。

本模块为 langchain_agentx 内部实现，不依赖 langchain_agentx 以外的代码。
"""
from abc import ABC, abstractmethod
from pathlib import Path
from typing import TypedDict, NotRequired, List, Optional

from langchain.agents.middleware.types import AgentMiddleware, AgentState

import logging

logger = logging.getLogger(__name__)


class SkillMetadata(TypedDict):
    """通用技能元数据类型（精简版），供 SkillsState 使用。

    注意：这里不再依赖 server_skill_loader 的具体实现，仅保留类型结构：
    - name: 技能名称
    - description: 技能描述
    - path: SKILL.md 路径或其他标识
    具体字段解释由各子类自行约定。
    """

    name: str
    description: str
    path: str


class SkillsState(AgentState):
    """技能中间件的状态（两个子类都可能使用）"""
    skills_metadata: NotRequired[List[SkillMetadata]]


class SkillsStateUpdate(TypedDict):
    """技能中间件的状态更新（两个子类都可能使用）"""
    skills_metadata: List[SkillMetadata]


class BaseSkillsMiddleware(AgentMiddleware, ABC):
    """
    技能中间件基类（最小化抽象）

    只保留一个抽象接口：
    1. _get_skills_dir()：获取技能目录路径

    其他所有实现逻辑（工具创建、before_agent、wrap_model_call 等）由子类自行决定。
    """

    state_schema = SkillsState

    def __init__(
        self,
        *,
        enabled_skills: Optional[List[str]] = None,
    ):
        """
        初始化技能中间件（最小化实现）

        Args:
            enabled_skills: 技能白名单（子类自行解释含义）
        """
        self.enabled_skills = enabled_skills

        # 子类实现：设置技能目录
        self.skills_dir = self._get_skills_dir()

        logger.info(f"初始化 {self.__class__.__name__}")
        logger.info(f"  技能目录: {self.skills_dir}")
        if enabled_skills is not None:
            logger.info(f"  启用技能白名单: {enabled_skills}")
        else:
            logger.info(f"  启用所有技能")

    @abstractmethod
    def _get_skills_dir(self) -> Path:
        """获取技能目录路径（子类必须实现）"""
        pass
