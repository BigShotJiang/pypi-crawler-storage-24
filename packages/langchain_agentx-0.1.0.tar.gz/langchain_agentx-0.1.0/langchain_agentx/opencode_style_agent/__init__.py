"""
OpenCode Style Agent - 基于 LangGraph 实现的 OpenCode 风格 Agent

核心特性：
1. 使用原生 finish_reason 判断退出（与 OpenCode 一致）
2. 与 LangGraph 生态完全兼容
3. 解决 create_agent 的"工具调用噩梦"

使用方式：
```python
from langchain_agentx.opencode_style_agent import create_opencode_style_agent

agent = create_opencode_style_agent(
    model="anthropic:claude-sonnet-4-5-20250929",
    tools=[check_weather],
    system_prompt="You are a helpful assistant",
    max_steps=50,
)

for chunk in agent.stream({"messages": [{"role": "user", "content": "Hello"}]}):
    print(chunk)
```

参考设计文档：
- .claude/design/lowest-layer-opencode-style-agent-design.md（原理和问题）
- .claude/design/create-opencode-style-agent-design.md（实现方案）
"""

# 主要导出
from .factory import (
    create_opencode_style_agent,
)

__all__ = [
    # 主要接口
    "create_opencode_style_agent",
]
