#!/usr/bin/env bash
# Remove dist folder as it will be generated again in the next step with a new build.
if [ -d "dist" ]
then
echo "Deleting dist directory"
rm -r dist
fi
# Install/update needed tools
python -m pip install --upgrade twine build
# Create new build
pipenv run python -m build
# Upload new build to pypi using twine
python -m twine upload --respository pypi dist/* --verbose