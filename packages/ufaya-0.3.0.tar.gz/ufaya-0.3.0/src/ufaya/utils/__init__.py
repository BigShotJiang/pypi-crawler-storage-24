"""Utility helpers for ufaya."""
