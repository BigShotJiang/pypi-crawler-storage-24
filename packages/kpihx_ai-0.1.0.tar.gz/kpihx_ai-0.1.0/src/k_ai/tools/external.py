# src/k_ai/tools/external.py
"""
External tools: exa search, Python execution, shell execution.

All external tools with side effects require user approval.
"""
import asyncio
import ast
import json
from contextlib import suppress
from pathlib import Path
from typing import Any, Dict, List

from ..models import ToolResult
from ..secrets import resolve_secret
from ..tool_capabilities import capability_enabled
from ..ui_theme import resolve_syntax_theme
from .base import InternalTool, ToolContext, ToolRegistry


class ExaSearchTool(InternalTool):
    name = "exa_search"
    display_name = "Web Search"
    category = "web"
    danger_level = "low"
    accent_color = "cyan"
    description = "Search the web using the Exa semantic search API."
    parameters_schema = {
        "type": "object",
        "properties": {
            "query": {
                "type": "string",
                "description": "The search query.",
            },
            "num_results": {
                "type": "integer",
                "description": "Number of results (default from config tools.exa.num_results).",
            },
        },
        "required": ["query"],
    }
    requires_approval = False

    async def execute(self, arguments: Dict[str, Any], ctx: ToolContext) -> ToolResult:
        tool_cfg = ctx.config.get_nested("tools", "exa", default={})
        if not capability_enabled(ctx.config, "exa"):
            return ToolResult(success=False, message="exa_search is disabled in config.")

        api_key_var = tool_cfg.get("api_key_env_var", "EXA_API_KEY")
        api_key, _ = resolve_secret(api_key_var)
        if not api_key:
            return ToolResult(success=False, message=f"{api_key_var} not found.")

        query = arguments.get("query", "")
        num_results = arguments.get("num_results", tool_cfg.get("num_results", 5))

        try:
            import httpx
            async with httpx.AsyncClient(timeout=15.0) as client:
                resp = await client.post(
                    "https://api.exa.ai/search",
                    headers={"x-api-key": api_key, "Content-Type": "application/json"},
                    json={
                        "query": query,
                        "num_results": num_results,
                        "use_autoprompt": True,
                    },
                )
                resp.raise_for_status()
                data = resp.json()
                results = data.get("results", [])
                lines = []
                for r in results:
                    title = r.get("title", "No title")
                    url = r.get("url", "")
                    lines.append(f"- {title}\n  {url}")
                return ToolResult(
                    success=True,
                    message="\n".join(lines) if lines else "No results found.",
                    data=results,
                )
        except Exception as e:
            return ToolResult(success=False, message=f"Exa search failed: {e}")


class PythonExecTool(InternalTool):
    name = "python_exec"
    display_name = "Run Python"
    category = "execution"
    danger_level = "high"
    accent_color = "yellow"
    description = (
        "Execute Python code in a sandboxed environment with scientific libraries "
        "(numpy, sympy, scipy, pandas, matplotlib, seaborn, scikit-learn). "
        "Use for calculations, data processing, plotting, or quick scripts."
    )
    parameters_schema = {
        "type": "object",
        "properties": {
            "code": {
                "type": "string",
                "description": "The Python code to execute.",
            },
        },
        "required": ["code"],
    }
    requires_approval = True

    _FALLBACK_DEFAULT_PACKAGES = [
        "numpy", "sympy", "scipy", "pandas",
        "matplotlib", "seaborn", "scikit-learn",
    ]
    _PROTECTED_PACKAGES = {"pip", "setuptools", "wheel"}

    @staticmethod
    def _prepare_code(code: str) -> str:
        """
        Make python_exec behave more like a REPL:
        if the last statement is an expression, print its repr().
        """
        try:
            tree = ast.parse(code, mode="exec")
        except SyntaxError:
            return code

        if not tree.body or not isinstance(tree.body[-1], ast.Expr):
            return code

        last_expr = tree.body[-1].value
        assign = ast.Assign(
            targets=[ast.Name(id="__k_ai_result", ctx=ast.Store())],
            value=last_expr,
        )
        print_call = ast.Expr(
            value=ast.Call(
                func=ast.Name(id="print", ctx=ast.Load()),
                args=[ast.Call(
                    func=ast.Name(id="repr", ctx=ast.Load()),
                    args=[ast.Name(id="__k_ai_result", ctx=ast.Load())],
                    keywords=[],
                )],
                keywords=[],
            )
        )
        tree.body[-1] = assign
        tree.body.append(print_call)
        ast.fix_missing_locations(tree)
        return ast.unparse(tree)

    def proposal_sections(self, arguments: Dict[str, Any], ctx: ToolContext) -> list[tuple[str, Any]]:
        from rich.syntax import Syntax

        code = arguments.get("code", "")
        syntax_theme = resolve_syntax_theme(ctx.config.get_nested("cli", "theme", default="default"))
        return [("Python Code", Syntax(code, "python", theme=syntax_theme, line_numbers=True, word_wrap=True))]

    def result_renderable(self, result: ToolResult, max_display_length: int, ctx: ToolContext) -> Any:
        from rich.syntax import Syntax

        msg = result.message
        if len(msg) > max_display_length:
            msg = msg[:max_display_length] + "\n...(truncated)"
        lexer = "text" if result.success else "pytb"
        syntax_theme = resolve_syntax_theme(ctx.config.get_nested("cli", "theme", default="default"))
        return Syntax(msg or "(no output)", lexer, theme=syntax_theme, word_wrap=True)

    @staticmethod
    def _sandbox_dir(ctx: ToolContext) -> str:
        return str(ctx.config.get_nested(
            "tools", "python", "sandbox_dir",
            default="~/.k-ai/sandbox",
        ))

    @classmethod
    def _default_packages(cls, ctx: ToolContext) -> List[str]:
        raw = ctx.config.get_nested("tools", "python", "default_packages", default=cls._FALLBACK_DEFAULT_PACKAGES)
        if not isinstance(raw, list):
            return list(cls._FALLBACK_DEFAULT_PACKAGES)
        packages: List[str] = []
        for item in raw:
            text = str(item or "").strip()
            if text and text not in packages:
                packages.append(text)
        return packages or list(cls._FALLBACK_DEFAULT_PACKAGES)

    @staticmethod
    def _pip_path(sandbox_dir: str) -> str:
        return str(Path(sandbox_dir).expanduser() / "bin" / "pip")

    @staticmethod
    async def _wait_for_process(proc, timeout: int, ctx: ToolContext):
        task = asyncio.create_task(proc.communicate())
        loop = asyncio.get_running_loop()
        deadline = loop.time() + timeout
        try:
            while True:
                done, _ = await asyncio.wait({task}, timeout=0.1)
                if task in done:
                    return task.result()
                if ctx.is_interrupt_requested and ctx.is_interrupt_requested():
                    with suppress(ProcessLookupError):
                        proc.terminate()
                    try:
                        await asyncio.wait_for(proc.wait(), timeout=2)
                    except asyncio.TimeoutError:
                        with suppress(ProcessLookupError):
                            proc.kill()
                    task.cancel()
                    with suppress(Exception):
                        await task
                    raise KeyboardInterrupt
                if loop.time() >= deadline:
                    with suppress(ProcessLookupError):
                        proc.terminate()
                    task.cancel()
                    with suppress(Exception):
                        await task
                    raise asyncio.TimeoutError
        finally:
            if not task.done():
                task.cancel()
                with suppress(Exception):
                    await task

    @staticmethod
    async def _ensure_sandbox(sandbox_dir: str, ctx: ToolContext) -> str:
        """Ensure the sandbox venv exists with scientific libs. Returns python path."""
        venv_path = Path(sandbox_dir).expanduser()
        python = venv_path / "bin" / "python"

        if python.exists():
            return str(python)

        # Create venv
        proc = await asyncio.create_subprocess_exec(
            "python3", "-m", "venv", str(venv_path),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        _, stderr = await PythonExecTool._wait_for_process(proc, timeout=30, ctx=ctx)
        if proc.returncode != 0:
            err = stderr.decode("utf-8", errors="replace").strip()
            raise RuntimeError(f"Failed to create sandbox venv: {err or f'exit code {proc.returncode}'}")

        # Install scientific packages
        pip = venv_path / "bin" / "pip"
        proc = await asyncio.create_subprocess_exec(
            str(pip), "install", "-q", *PythonExecTool._default_packages(ctx),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        _, stderr = await PythonExecTool._wait_for_process(proc, timeout=120, ctx=ctx)
        if proc.returncode != 0:
            err = stderr.decode("utf-8", errors="replace").strip()
            raise RuntimeError(f"Failed to install sandbox packages: {err or f'exit code {proc.returncode}'}")

        return str(python)

    async def execute(self, arguments: Dict[str, Any], ctx: ToolContext) -> ToolResult:
        tool_cfg = ctx.config.get_nested("tools", "python", default={})
        if not capability_enabled(ctx.config, "python"):
            return ToolResult(success=False, message="python_exec is disabled in config.")

        code = arguments.get("code", "")
        if not code.strip():
            return ToolResult(success=False, message="No code provided.")

        timeout = int(tool_cfg.get("timeout", 30))

        try:
            # Use sandbox venv with scientific libs
            sandbox_dir = self._sandbox_dir(ctx)
            python = await self._ensure_sandbox(sandbox_dir, ctx)

            prepared_code = self._prepare_code(code)
            proc = await asyncio.create_subprocess_exec(
                python, "-c", prepared_code,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await self._wait_for_process(proc, timeout=timeout, ctx=ctx)
            output = stdout.decode("utf-8", errors="replace")
            errors = stderr.decode("utf-8", errors="replace")
            if proc.returncode == 0:
                return ToolResult(
                    success=True,
                    message=output if output else "(no output)",
                    data={"returncode": 0, "stdout": output, "stderr": errors},
                )
            return ToolResult(
                success=False,
                message=f"Exit code {proc.returncode}\n{errors}",
                data={"returncode": proc.returncode, "stdout": output, "stderr": errors},
            )
        except asyncio.TimeoutError:
            return ToolResult(success=False, message=f"Execution timed out after {timeout}s.")
        except Exception as e:
            return ToolResult(success=False, message=f"Execution failed: {e}")


class PythonSandboxPackagesTool(InternalTool):
    category = "execution"
    accent_color = "yellow"

    @staticmethod
    async def _ensure_ready(ctx: ToolContext) -> tuple[str, str]:
        sandbox_dir = PythonExecTool._sandbox_dir(ctx)
        python = await PythonExecTool._ensure_sandbox(sandbox_dir, ctx)
        pip = PythonExecTool._pip_path(sandbox_dir)
        return python, pip

    @staticmethod
    async def _run_pip(ctx: ToolContext, args: List[str], timeout: int | None = None) -> tuple[int, str, str]:
        _, pip = await PythonSandboxPackagesTool._ensure_ready(ctx)
        effective_timeout = int(timeout or ctx.config.get_nested("tools", "python", "install_timeout", default=300))
        proc = await asyncio.create_subprocess_exec(
            pip, *args,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr = await PythonExecTool._wait_for_process(proc, timeout=effective_timeout, ctx=ctx)
        return proc.returncode, stdout.decode("utf-8", errors="replace"), stderr.decode("utf-8", errors="replace")

    @staticmethod
    def _normalize_packages(arguments: Dict[str, Any]) -> List[str]:
        raw = arguments.get("packages", [])
        if isinstance(raw, str):
            raw = [part.strip() for part in raw.split() if part.strip()]
        packages: List[str] = []
        for item in raw or []:
            name = str(item or "").strip()
            if name and name not in packages:
                packages.append(name)
        return packages


class PythonSandboxListPackagesTool(PythonSandboxPackagesTool):
    name = "python_sandbox_list_packages"
    display_name = "List Python Sandbox Packages"
    danger_level = "low"
    description = "List installed packages inside the dedicated python_exec sandbox."
    parameters_schema = {"type": "object", "properties": {}, "required": []}
    requires_approval = False

    async def execute(self, arguments: Dict[str, Any], ctx: ToolContext) -> ToolResult:
        tool_cfg = ctx.config.get_nested("tools", "python", default={})
        if not capability_enabled(ctx.config, "python"):
            return ToolResult(success=False, message="python_exec is disabled in config.")
        try:
            code, stdout, stderr = await self._run_pip(ctx, ["list", "--format=json"])
            if code != 0:
                return ToolResult(success=False, message=stderr.strip() or stdout.strip() or f"pip list failed with code {code}")
            packages = json.loads(stdout or "[]")
            lines = [f"- {pkg['name']}=={pkg['version']}" for pkg in packages]
            return ToolResult(success=True, message="\n".join(lines) if lines else "No packages installed.", data=packages)
        except Exception as e:
            return ToolResult(success=False, message=f"Could not list sandbox packages: {e}")


class PythonSandboxInstallPackagesTool(PythonSandboxPackagesTool):
    name = "python_sandbox_install_packages"
    display_name = "Install Python Sandbox Packages"
    danger_level = "high"
    description = "Install one or more packages into the dedicated python_exec sandbox."
    parameters_schema = {
        "type": "object",
        "properties": {
            "packages": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Package specifiers to install into the sandbox.",
            },
        },
        "required": ["packages"],
    }
    requires_approval = True

    async def execute(self, arguments: Dict[str, Any], ctx: ToolContext) -> ToolResult:
        packages = self._normalize_packages(arguments)
        if not packages:
            return ToolResult(success=False, message="No packages provided.")
        try:
            code, stdout, stderr = await self._run_pip(ctx, ["install", *packages])
            if code != 0:
                message = stderr.strip() or stdout.strip() or f"pip install failed with code {code}"
                return ToolResult(success=False, message=message)
            return ToolResult(success=True, message=f"Installed into sandbox: {', '.join(packages)}")
        except Exception as e:
            return ToolResult(success=False, message=f"Could not install sandbox packages: {e}")

    def proposal_sections(self, arguments: Dict[str, Any], ctx: ToolContext) -> list[tuple[str, Any]]:
        packages = self._normalize_packages(arguments)
        return [("Packages", [("Install", ", ".join(packages) or "-")])]


class PythonSandboxRemovePackagesTool(PythonSandboxPackagesTool):
    name = "python_sandbox_remove_packages"
    display_name = "Remove Python Sandbox Packages"
    danger_level = "high"
    description = "Uninstall one or more non-core packages from the dedicated python_exec sandbox."
    parameters_schema = {
        "type": "object",
        "properties": {
            "packages": {
                "type": "array",
                "items": {"type": "string"},
                "description": "Installed package names to remove from the sandbox.",
            },
        },
        "required": ["packages"],
    }
    requires_approval = True

    async def execute(self, arguments: Dict[str, Any], ctx: ToolContext) -> ToolResult:
        packages = self._normalize_packages(arguments)
        if not packages:
            return ToolResult(success=False, message="No packages provided.")
        forbidden = [pkg for pkg in packages if pkg.lower() in PythonExecTool._PROTECTED_PACKAGES]
        if forbidden:
            return ToolResult(success=False, message=f"Refusing to remove protected sandbox packages: {', '.join(forbidden)}")
        try:
            code, stdout, stderr = await self._run_pip(ctx, ["uninstall", "-y", *packages])
            if code != 0:
                message = stderr.strip() or stdout.strip() or f"pip uninstall failed with code {code}"
                return ToolResult(success=False, message=message)
            return ToolResult(success=True, message=f"Removed from sandbox: {', '.join(packages)}")
        except Exception as e:
            return ToolResult(success=False, message=f"Could not remove sandbox packages: {e}")

    def proposal_sections(self, arguments: Dict[str, Any], ctx: ToolContext) -> list[tuple[str, Any]]:
        packages = self._normalize_packages(arguments)
        return [("Packages", [("Remove", ", ".join(packages) or "-")])]


class ShellExecTool(InternalTool):
    name = "shell_exec"
    display_name = "Run Shell Command"
    category = "execution"
    danger_level = "high"
    accent_color = "red"
    description = "Execute a shell command and return stdout/stderr."
    parameters_schema = {
        "type": "object",
        "properties": {
            "command": {
                "type": "string",
                "description": "The shell command to execute.",
            },
        },
        "required": ["command"],
    }
    requires_approval = True

    def proposal_sections(self, arguments: Dict[str, Any], ctx: ToolContext) -> list[tuple[str, Any]]:
        from rich.syntax import Syntax

        command = arguments.get("command", "")
        syntax_theme = resolve_syntax_theme(ctx.config.get_nested("cli", "theme", default="default"))
        return [("Shell Command", Syntax(command, "bash", theme=syntax_theme, line_numbers=False, word_wrap=True))]

    def result_renderable(self, result: ToolResult, max_display_length: int, ctx: ToolContext) -> Any:
        from rich.syntax import Syntax

        msg = result.message
        if len(msg) > max_display_length:
            msg = msg[:max_display_length] + "\n...(truncated)"
        syntax_theme = resolve_syntax_theme(ctx.config.get_nested("cli", "theme", default="default"))
        return Syntax(msg or "(no output)", "text", theme=syntax_theme, word_wrap=True)

    async def execute(self, arguments: Dict[str, Any], ctx: ToolContext) -> ToolResult:
        tool_cfg = ctx.config.get_nested("tools", "shell", default={})
        if not capability_enabled(ctx.config, "shell"):
            return ToolResult(success=False, message="shell_exec is disabled in config.")

        command = arguments.get("command", "")
        if not command.strip():
            return ToolResult(success=False, message="No command provided.")

        timeout = int(tool_cfg.get("timeout", 30))
        try:
            proc = await asyncio.create_subprocess_shell(
                command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await PythonExecTool._wait_for_process(proc, timeout=timeout, ctx=ctx)
            output = stdout.decode("utf-8", errors="replace")
            errors = stderr.decode("utf-8", errors="replace")
            combined = output
            if errors:
                combined += f"\n--- stderr ---\n{errors}"
            return ToolResult(
                success=proc.returncode == 0,
                message=combined if combined.strip() else "(no output)",
                data={"returncode": proc.returncode, "stdout": output, "stderr": errors},
            )
        except asyncio.TimeoutError:
            return ToolResult(success=False, message=f"Command timed out after {timeout}s.")
        except KeyboardInterrupt:
            return ToolResult(success=False, message="Command interrupted by user.", data={"interrupted": True})
        except Exception as e:
            return ToolResult(success=False, message=f"Command failed: {e}")


def register_external_tools(registry: ToolRegistry, ctx: ToolContext) -> None:
    for tool_cls in [
        ExaSearchTool,
        PythonExecTool,
        PythonSandboxListPackagesTool,
        PythonSandboxInstallPackagesTool,
        PythonSandboxRemovePackagesTool,
        ShellExecTool,
    ]:
        registry.register(tool_cls())
