"""Tests for git_cmd module."""

from unittest.mock import MagicMock, patch

from git_insights.git_cmd import (
    _parse_log,
    get_current_branch,
    get_repo_name,
    is_git_repo,
)


class TestIsGitRepo:
    @patch("git_insights.git_cmd.subprocess.run")
    def test_valid_repo(self, mock_run):
        mock_run.return_value = MagicMock(returncode=0)
        assert is_git_repo("/some/path") is True

    @patch("git_insights.git_cmd.subprocess.run")
    def test_not_a_repo(self, mock_run):
        mock_run.return_value = MagicMock(returncode=128)
        assert is_git_repo("/some/path") is False

    @patch("git_insights.git_cmd.subprocess.run")
    def test_exception(self, mock_run):
        mock_run.side_effect = Exception("timeout")
        assert is_git_repo("/some/path") is False


class TestGetRepoName:
    @patch("git_insights.git_cmd.subprocess.run")
    def test_success(self, mock_run):
        mock_run.return_value = MagicMock(returncode=0, stdout="/home/user/my-project\n")
        assert get_repo_name("/some/path") == "my-project"

    @patch("git_insights.git_cmd.subprocess.run")
    def test_fallback(self, mock_run):
        mock_run.return_value = MagicMock(returncode=1)
        assert get_repo_name("/some/path") == "path"


class TestGetCurrentBranch:
    @patch("git_insights.git_cmd.subprocess.run")
    def test_success(self, mock_run):
        mock_run.return_value = MagicMock(returncode=0, stdout="main\n")
        assert get_current_branch("/some/path") == "main"

    @patch("git_insights.git_cmd.subprocess.run")
    def test_fallback(self, mock_run):
        mock_run.return_value = MagicMock(returncode=1)
        assert get_current_branch("/some/path") == "unknown"


class TestParseLog:
    def test_single_commit(self):
        log = (
            "a" * 40 + "|John Doe|john@test.com|2025-01-15T10:30:00+00:00|Initial commit\n"
            "10\t5\tsrc/main.py\n"
            "3\t0\tREADME.md\n"
        )
        commits = _parse_log(log)
        assert len(commits) == 1
        assert commits[0].author_name == "John Doe"
        assert commits[0].insertions == 13
        assert commits[0].deletions == 5
        assert commits[0].files_changed == 2

    def test_multiple_commits(self):
        h1 = "a" * 40
        h2 = "c" * 40
        log = (
            f"{h1}|Alice|alice@test.com|2025-01-15T10:30:00+00:00|First commit\n"
            "10\t5\tfile1.py\n"
            "\n"
            f"{h2}|Bob|bob@test.com|2025-01-16T11:00:00+00:00|Second commit\n"
            "20\t3\tfile2.py\n"
        )
        commits = _parse_log(log)
        assert len(commits) == 2
        assert commits[0].author_name == "Alice"
        assert commits[1].author_name == "Bob"

    def test_empty_log(self):
        commits = _parse_log("")
        assert len(commits) == 0

    def test_merge_commit(self):
        log = "a" * 40 + "|John|john@test.com|2025-01-15T10:30:00+00:00|Merge branch 'feature'\n"
        commits = _parse_log(log)
        assert len(commits) == 1
        assert commits[0].is_merge is True

    def test_binary_file_numstat(self):
        log = (
            "a" * 40 + "|John|john@test.com|2025-01-15T10:30:00+00:00|Add image\n"
            "-\t-\timage.png\n"
        )
        commits = _parse_log(log)
        assert len(commits) == 1
        assert commits[0].insertions == 0
        assert commits[0].deletions == 0
        assert commits[0].files_changed == 1
