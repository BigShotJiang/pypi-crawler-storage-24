"""Tests for data models."""

from datetime import datetime, timezone

from git_insights.models import (
    CommitInfo,
    ContributorStats,
    DayStats,
    FileStats,
    HourStats,
    RepoInsights,
)


class TestCommitInfo:
    def test_net_lines(self):
        c = CommitInfo(
            hash="a" * 40, author_name="Test", author_email="test@test.com",
            date=datetime.now(timezone.utc), message="test",
            insertions=100, deletions=30,
        )
        assert c.net_lines == 70

    def test_churn(self):
        c = CommitInfo(
            hash="a" * 40, author_name="Test", author_email="test@test.com",
            date=datetime.now(timezone.utc), message="test",
            insertions=100, deletions=30,
        )
        assert c.churn == 130

    def test_is_merge(self):
        c = CommitInfo(
            hash="a" * 40, author_name="Test", author_email="test@test.com",
            date=datetime.now(timezone.utc), message="Merge branch 'feature'",
        )
        assert c.is_merge is True

    def test_not_merge(self):
        c = CommitInfo(
            hash="a" * 40, author_name="Test", author_email="test@test.com",
            date=datetime.now(timezone.utc), message="Add new feature",
        )
        assert c.is_merge is False

    def test_short_hash(self):
        c = CommitInfo(
            hash="abcdef1234567890abcdef1234567890abcdef12",
            author_name="Test", author_email="test@test.com",
            date=datetime.now(timezone.utc), message="test",
        )
        assert c.short_hash == "abcdef1"

    def test_weekday(self):
        # Jan 6, 2025 is a Monday
        c = CommitInfo(
            hash="a" * 40, author_name="Test", author_email="test@test.com",
            date=datetime(2025, 1, 6, 12, 0, tzinfo=timezone.utc), message="test",
        )
        assert c.weekday == "Monday"

    def test_hour(self):
        c = CommitInfo(
            hash="a" * 40, author_name="Test", author_email="test@test.com",
            date=datetime(2025, 1, 1, 14, 30, tzinfo=timezone.utc), message="test",
        )
        assert c.hour == 14


class TestContributorStats:
    def test_avg_commit_size(self):
        s = ContributorStats(
            name="Test", email="test@test.com",
            total_commits=10, insertions=500, deletions=200,
        )
        assert s.avg_commit_size == 70.0

    def test_avg_commit_size_zero(self):
        s = ContributorStats(name="Test", email="test@test.com")
        assert s.avg_commit_size == 0

    def test_net_lines(self):
        s = ContributorStats(
            name="Test", email="test@test.com",
            insertions=500, deletions=200,
        )
        assert s.net_lines == 300


class TestFileStats:
    def test_churn_score(self):
        f = FileStats(path="test.py", total_changes=100, commit_count=10)
        assert f.churn_score == 1000

    def test_churn_score_zero(self):
        f = FileStats(path="test.py")
        assert f.churn_score == 0


class TestDayStats:
    def test_creation(self):
        d = DayStats(day="Monday", commit_count=15)
        assert d.day == "Monday"
        assert d.commit_count == 15


class TestHourStats:
    def test_creation(self):
        h = HourStats(hour=14, commit_count=5)
        assert h.hour == 14
        assert h.commit_count == 5


class TestRepoInsights:
    def test_empty(self):
        r = RepoInsights()
        assert r.total_commits == 0
        assert r.net_lines == 0
        assert r.repo_age_days == 0

    def test_health_score_base(self):
        r = RepoInsights()
        assert r.health_score >= 0
        assert r.health_score <= 100

    def test_health_grade(self):
        r = RepoInsights()
        assert r.health_grade in ("A+", "A", "B", "C", "D", "F")

    def test_repo_age(self):
        r = RepoInsights(
            first_commit_date=datetime(2024, 1, 1, tzinfo=timezone.utc),
            last_commit_date=datetime(2024, 7, 1, tzinfo=timezone.utc),
        )
        assert r.repo_age_days == 182

    def test_net_lines(self):
        r = RepoInsights(total_insertions=1000, total_deletions=300)
        assert r.net_lines == 700
