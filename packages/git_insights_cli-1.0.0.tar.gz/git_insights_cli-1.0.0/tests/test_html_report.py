"""Tests for HTML report generation."""

from datetime import datetime, timezone

from git_insights.models import (
    ContributorStats,
    DayStats,
    FileStats,
    HourStats,
    RepoInsights,
)
from git_insights.output.html_report import export_html


def _mock_insights():
    return RepoInsights(
        repo_name="test-repo",
        branch="main",
        total_commits=50,
        total_authors=2,
        total_insertions=3000,
        total_deletions=1000,
        first_commit_date=datetime(2024, 6, 1, tzinfo=timezone.utc),
        last_commit_date=datetime(2025, 1, 1, tzinfo=timezone.utc),
        avg_commits_per_day=0.23,
        avg_commit_size=80.0,
        bus_factor=2,
        analysis_time_ms=100,
        contributors=[
            ContributorStats(name="Alice", email="a@t.com", total_commits=35, insertions=2000, deletions=600, active_days=30),
            ContributorStats(name="Bob", email="b@t.com", total_commits=15, insertions=1000, deletions=400, active_days=12),
        ],
        day_distribution=[DayStats(day=d, commit_count=i * 3) for i, d in enumerate(["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"])],
        hour_distribution=[HourStats(hour=h, commit_count=max(0, 5 - abs(h - 14))) for h in range(24)],
        file_hotspots=[
            FileStats(path="main.py", total_changes=300, commit_count=15, contributors=2),
        ],
        monthly_commits={"2024-10": 10, "2024-11": 15, "2024-12": 12},
        top_file_types={".py": 2000, ".md": 300},
    )


class TestHtmlReport:
    def test_generates_html(self, tmp_path):
        out = tmp_path / "report.html"
        export_html(_mock_insights(), str(out))
        assert out.exists()
        html = out.read_text(encoding="utf-8")
        assert "git-insights" in html
        assert "test-repo" in html

    def test_contains_contributors(self, tmp_path):
        out = tmp_path / "report.html"
        export_html(_mock_insights(), str(out))
        html = out.read_text(encoding="utf-8")
        assert "Alice" in html
        assert "Bob" in html

    def test_contains_hotspots(self, tmp_path):
        out = tmp_path / "report.html"
        export_html(_mock_insights(), str(out))
        html = out.read_text(encoding="utf-8")
        assert "main.py" in html

    def test_empty_insights(self, tmp_path):
        out = tmp_path / "empty.html"
        export_html(RepoInsights(repo_name="empty"), str(out))
        assert out.exists()
        html = out.read_text(encoding="utf-8")
        assert "empty" in html

    def test_creates_parent_dirs(self, tmp_path):
        out = tmp_path / "sub" / "report.html"
        export_html(_mock_insights(), str(out))
        assert out.exists()

    def test_health_grade(self, tmp_path):
        out = tmp_path / "grade.html"
        export_html(_mock_insights(), str(out))
        html = out.read_text(encoding="utf-8")
        # Should contain a health grade
        assert any(g in html for g in ("A+", "A", "B", "C", "D", "F"))
