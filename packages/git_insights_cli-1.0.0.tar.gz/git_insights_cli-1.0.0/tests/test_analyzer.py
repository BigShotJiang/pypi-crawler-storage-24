"""Tests for the core analyzer."""

from datetime import datetime, timezone

from git_insights.analyzers.core import (
    _analyze_contributors,
    _analyze_day_distribution,
    _analyze_file_types,
    _analyze_hour_distribution,
    _analyze_monthly_trend,
    _calculate_bus_factor,
)
from git_insights.models import CommitInfo, ContributorStats


def _make_commit(
    author="Alice", email="alice@test.com",
    date=None, msg="test", ins=10, dels=5, files=1,
):
    if date is None:
        date = datetime(2025, 1, 6, 14, 0, tzinfo=timezone.utc)  # Monday
    return CommitInfo(
        hash="a" * 40, author_name=author, author_email=email,
        date=date, message=msg, insertions=ins, deletions=dels,
        files_changed=files,
    )


class TestAnalyzeContributors:
    def test_single_author(self):
        commits = [_make_commit() for _ in range(5)]
        contributors = _analyze_contributors(commits)
        assert len(contributors) == 1
        assert contributors[0].total_commits == 5
        assert contributors[0].name == "Alice"

    def test_multiple_authors(self):
        commits = [
            _make_commit(author="Alice", email="alice@test.com"),
            _make_commit(author="Alice", email="alice@test.com"),
            _make_commit(author="Bob", email="bob@test.com"),
        ]
        contributors = _analyze_contributors(commits)
        assert len(contributors) == 2
        assert contributors[0].name == "Alice"  # Most commits first
        assert contributors[0].total_commits == 2

    def test_empty(self):
        assert _analyze_contributors([]) == []


class TestDayDistribution:
    def test_basic(self):
        commits = [_make_commit()]  # Monday
        days = _analyze_day_distribution(commits)
        assert len(days) == 7
        monday = next(d for d in days if d.day == "Monday")
        assert monday.commit_count == 1

    def test_weekend(self):
        sat = datetime(2025, 1, 4, 12, 0, tzinfo=timezone.utc)  # Saturday
        commits = [_make_commit(date=sat)]
        days = _analyze_day_distribution(commits)
        saturday = next(d for d in days if d.day == "Saturday")
        assert saturday.commit_count == 1


class TestHourDistribution:
    def test_basic(self):
        commits = [_make_commit()]  # 14:00
        hours = _analyze_hour_distribution(commits)
        assert len(hours) == 24
        assert hours[14].commit_count == 1
        assert hours[0].commit_count == 0


class TestMonthlyTrend:
    def test_basic(self):
        commits = [
            _make_commit(date=datetime(2025, 1, 1, tzinfo=timezone.utc)),
            _make_commit(date=datetime(2025, 1, 15, tzinfo=timezone.utc)),
            _make_commit(date=datetime(2025, 2, 1, tzinfo=timezone.utc)),
        ]
        monthly = _analyze_monthly_trend(commits)
        assert monthly["2025-01"] == 2
        assert monthly["2025-02"] == 1


class TestBusFactor:
    def test_single_contributor(self):
        contribs = [ContributorStats(name="A", email="a@a.com", total_commits=100)]
        assert _calculate_bus_factor(contribs) == 1

    def test_two_equal(self):
        contribs = [
            ContributorStats(name="A", email="a@a.com", total_commits=50),
            ContributorStats(name="B", email="b@b.com", total_commits=50),
        ]
        assert _calculate_bus_factor(contribs) == 1

    def test_three_contributors(self):
        contribs = [
            ContributorStats(name="A", email="a@a.com", total_commits=40),
            ContributorStats(name="B", email="b@b.com", total_commits=35),
            ContributorStats(name="C", email="c@c.com", total_commits=25),
        ]
        assert _calculate_bus_factor(contribs) >= 1

    def test_empty(self):
        assert _calculate_bus_factor([]) == 0


class TestFileTypes:
    def test_basic(self):
        changes = {
            "src/main.py": {"changes": 100, "commits": 5, "authors": {"A"}},
            "src/utils.py": {"changes": 50, "commits": 3, "authors": {"A"}},
            "README.md": {"changes": 20, "commits": 2, "authors": {"A"}},
        }
        types = _analyze_file_types(changes)
        assert ".py" in types
        assert ".md" in types
        assert types[".py"] == 150
