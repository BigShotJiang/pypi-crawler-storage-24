"""Tests for CLI commands."""

import json
from unittest.mock import patch

from click.testing import CliRunner

from git_insights.cli import cli
from git_insights.models import RepoInsights


@patch("git_insights.cli.is_git_repo", return_value=True)
@patch("git_insights.cli.analyze_repo")
class TestAnalyzeCommand:
    def test_analyze_basic(self, mock_analyze, mock_is_git):
        mock_analyze.return_value = _mock_insights()
        runner = CliRunner()
        result = runner.invoke(cli, ["analyze", "."])
        assert result.exit_code == 0

    def test_analyze_json(self, mock_analyze, mock_is_git, tmp_path):
        mock_analyze.return_value = _mock_insights()
        runner = CliRunner()
        out = tmp_path / "report.json"
        result = runner.invoke(cli, ["analyze", ".", "-j", str(out)])
        assert result.exit_code == 0
        assert out.exists()
        data = json.loads(out.read_text())
        assert "total_commits" in data

    def test_analyze_html(self, mock_analyze, mock_is_git, tmp_path):
        mock_analyze.return_value = _mock_insights()
        runner = CliRunner()
        out = tmp_path / "report.html"
        result = runner.invoke(cli, ["analyze", ".", "--html", str(out)])
        assert result.exit_code == 0
        assert out.exists()

    def test_analyze_no_commits(self, mock_analyze, mock_is_git):
        mock_analyze.return_value = RepoInsights()
        runner = CliRunner()
        result = runner.invoke(cli, ["analyze", "."])
        assert result.exit_code == 0


@patch("git_insights.cli.is_git_repo", return_value=False)
class TestNotGitRepo:
    def test_analyze_not_repo(self, mock_is_git):
        runner = CliRunner()
        result = runner.invoke(cli, ["analyze", "."])
        assert result.exit_code != 0

    def test_contributors_not_repo(self, mock_is_git):
        runner = CliRunner()
        result = runner.invoke(cli, ["contributors", "."])
        assert result.exit_code != 0

    def test_hotspots_not_repo(self, mock_is_git):
        runner = CliRunner()
        result = runner.invoke(cli, ["hotspots", "."])
        assert result.exit_code != 0


@patch("git_insights.cli.is_git_repo", return_value=True)
@patch("git_insights.cli.analyze_repo")
class TestSubCommands:
    def test_contributors(self, mock_analyze, mock_is_git):
        mock_analyze.return_value = _mock_insights()
        runner = CliRunner()
        result = runner.invoke(cli, ["contributors", "."])
        assert result.exit_code == 0

    def test_hotspots(self, mock_analyze, mock_is_git):
        mock_analyze.return_value = _mock_insights()
        runner = CliRunner()
        result = runner.invoke(cli, ["hotspots", "."])
        assert result.exit_code == 0

    def test_activity(self, mock_analyze, mock_is_git):
        mock_analyze.return_value = _mock_insights()
        runner = CliRunner()
        result = runner.invoke(cli, ["activity", "."])
        assert result.exit_code == 0

    def test_summary(self, mock_analyze, mock_is_git):
        mock_analyze.return_value = _mock_insights()
        runner = CliRunner()
        result = runner.invoke(cli, ["summary", "."])
        assert result.exit_code == 0


class TestVersionCommand:
    def test_version(self):
        runner = CliRunner()
        result = runner.invoke(cli, ["--version"])
        assert "1.0.0" in result.output


def _mock_insights():
    from datetime import datetime, timezone

    from git_insights.models import ContributorStats, DayStats, FileStats, HourStats

    return RepoInsights(
        repo_name="test-repo",
        branch="main",
        total_commits=100,
        total_authors=3,
        total_insertions=5000,
        total_deletions=2000,
        total_files_changed=50,
        first_commit_date=datetime(2024, 1, 1, tzinfo=timezone.utc),
        last_commit_date=datetime(2025, 1, 1, tzinfo=timezone.utc),
        avg_commits_per_day=0.27,
        avg_commit_size=70.0,
        merge_commit_ratio=0.15,
        bus_factor=2,
        analysis_time_ms=150,
        contributors=[
            ContributorStats(name="Alice", email="alice@test.com", total_commits=60, insertions=3000, deletions=1000, active_days=45),
            ContributorStats(name="Bob", email="bob@test.com", total_commits=30, insertions=1500, deletions=700, active_days=25),
            ContributorStats(name="Charlie", email="charlie@test.com", total_commits=10, insertions=500, deletions=300, active_days=8),
        ],
        day_distribution=[
            DayStats(day="Monday", commit_count=20),
            DayStats(day="Tuesday", commit_count=18),
            DayStats(day="Wednesday", commit_count=22),
            DayStats(day="Thursday", commit_count=15),
            DayStats(day="Friday", commit_count=12),
            DayStats(day="Saturday", commit_count=8),
            DayStats(day="Sunday", commit_count=5),
        ],
        hour_distribution=[HourStats(hour=h, commit_count=max(0, 10 - abs(h - 14))) for h in range(24)],
        file_hotspots=[
            FileStats(path="src/main.py", total_changes=500, commit_count=20, contributors=3),
            FileStats(path="src/utils.py", total_changes=200, commit_count=10, contributors=2),
        ],
        monthly_commits={"2024-06": 15, "2024-07": 20, "2024-08": 18},
        top_file_types={".py": 3000, ".md": 500, ".yml": 200},
    )
