"""Tests for console output rendering."""

from datetime import datetime, timezone

from git_insights.models import (
    ContributorStats,
    DayStats,
    FileStats,
    HourStats,
    RepoInsights,
)
from git_insights.output.console import render_insights


def _mock_insights():
    return RepoInsights(
        repo_name="test-repo",
        branch="main",
        total_commits=50,
        total_authors=2,
        total_insertions=3000,
        total_deletions=1000,
        first_commit_date=datetime(2024, 6, 1, tzinfo=timezone.utc),
        last_commit_date=datetime(2025, 1, 1, tzinfo=timezone.utc),
        avg_commits_per_day=0.23,
        avg_commit_size=80.0,
        bus_factor=2,
        analysis_time_ms=100,
        contributors=[
            ContributorStats(name="Alice", email="a@t.com", total_commits=35, insertions=2000, deletions=600, active_days=30),
        ],
        day_distribution=[DayStats(day=d, commit_count=5) for d in ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]],
        hour_distribution=[HourStats(hour=h, commit_count=3) for h in range(24)],
        file_hotspots=[FileStats(path="main.py", total_changes=300, commit_count=15, contributors=2)],
        monthly_commits={"2024-10": 10, "2024-11": 15},
        top_file_types={".py": 2000},
    )


class TestRenderInsights:
    def test_renders_without_error(self, capsys):
        render_insights(_mock_insights())
        captured = capsys.readouterr()
        assert len(captured.out) > 0

    def test_empty_insights(self, capsys):
        render_insights(RepoInsights(repo_name="empty"))
        captured = capsys.readouterr()
        assert len(captured.out) > 0
