"""Data models for git-insights."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum


class AnalysisScope(str, Enum):
    """Scope of analysis."""
    FULL = "full"
    LAST_30_DAYS = "30d"
    LAST_90_DAYS = "90d"
    LAST_YEAR = "1y"
    CUSTOM = "custom"


@dataclass
class CommitInfo:
    """A single git commit."""
    hash: str
    author_name: str
    author_email: str
    date: datetime
    message: str
    files_changed: int = 0
    insertions: int = 0
    deletions: int = 0

    @property
    def net_lines(self) -> int:
        return self.insertions - self.deletions

    @property
    def churn(self) -> int:
        return self.insertions + self.deletions

    @property
    def is_merge(self) -> bool:
        return self.message.lower().startswith("merge")

    @property
    def short_hash(self) -> str:
        return self.hash[:7]

    @property
    def weekday(self) -> str:
        return self.date.strftime("%A")

    @property
    def hour(self) -> int:
        return self.date.hour


@dataclass
class ContributorStats:
    """Stats for a single contributor."""
    name: str
    email: str
    total_commits: int = 0
    insertions: int = 0
    deletions: int = 0
    files_touched: int = 0
    first_commit: datetime | None = None
    last_commit: datetime | None = None
    active_days: int = 0

    @property
    def net_lines(self) -> int:
        return self.insertions - self.deletions

    @property
    def churn(self) -> int:
        return self.insertions + self.deletions

    @property
    def avg_commit_size(self) -> float:
        if self.total_commits == 0:
            return 0
        return self.churn / self.total_commits


@dataclass
class FileStats:
    """Stats for a single file."""
    path: str
    total_changes: int = 0
    total_insertions: int = 0
    total_deletions: int = 0
    commit_count: int = 0
    contributors: int = 0

    @property
    def churn_score(self) -> float:
        """Higher score = more churn = potential hotspot."""
        return self.total_changes * self.commit_count


@dataclass
class DayStats:
    """Commit stats by day of week."""
    day: str
    commit_count: int = 0
    insertions: int = 0
    deletions: int = 0


@dataclass
class HourStats:
    """Commit stats by hour."""
    hour: int
    commit_count: int = 0


@dataclass
class RepoInsights:
    """Full repo analysis results."""
    repo_path: str = ""
    repo_name: str = ""
    analysis_time_ms: int = 0
    branch: str = "main"

    # Summary
    total_commits: int = 0
    total_authors: int = 0
    total_files_changed: int = 0
    total_insertions: int = 0
    total_deletions: int = 0
    first_commit_date: datetime | None = None
    last_commit_date: datetime | None = None

    # Detailed
    commits: list[CommitInfo] = field(default_factory=list)
    contributors: list[ContributorStats] = field(default_factory=list)
    file_hotspots: list[FileStats] = field(default_factory=list)
    day_distribution: list[DayStats] = field(default_factory=list)
    hour_distribution: list[HourStats] = field(default_factory=list)

    # Trends
    monthly_commits: dict[str, int] = field(default_factory=dict)
    weekly_commits: dict[str, int] = field(default_factory=dict)

    # Computed
    avg_commits_per_day: float = 0.0
    avg_commit_size: float = 0.0
    merge_commit_ratio: float = 0.0
    bus_factor: int = 0
    top_file_types: dict[str, int] = field(default_factory=dict)

    @property
    def net_lines(self) -> int:
        return self.total_insertions - self.total_deletions

    @property
    def repo_age_days(self) -> int:
        if not self.first_commit_date or not self.last_commit_date:
            return 0
        return max(1, (self.last_commit_date - self.first_commit_date).days)

    @property
    def health_score(self) -> int:
        """Repository health score (0-100)."""
        score = 50  # Base

        # Active contributors bonus
        if self.total_authors >= 3:
            score += 10
        elif self.total_authors >= 2:
            score += 5

        # Recent activity bonus
        if self.last_commit_date:
            from datetime import timezone
            now = datetime.now(timezone.utc)
            last = self.last_commit_date
            if last.tzinfo is None:
                from datetime import timezone as tz
                last = last.replace(tzinfo=tz.utc)
            days_since = (now - last).days
            if days_since < 7:
                score += 15
            elif days_since < 30:
                score += 10
            elif days_since < 90:
                score += 5

        # Bus factor bonus
        if self.bus_factor >= 3:
            score += 10
        elif self.bus_factor >= 2:
            score += 5

        # Commit frequency
        if self.avg_commits_per_day >= 1:
            score += 10
        elif self.avg_commits_per_day >= 0.3:
            score += 5

        # Low merge ratio = better (direct commits, CI)
        if 0.1 <= self.merge_commit_ratio <= 0.5:
            score += 5

        return min(100, max(0, score))

    @property
    def health_grade(self) -> str:
        s = self.health_score
        if s >= 90:
            return "A+"
        if s >= 80:
            return "A"
        if s >= 70:
            return "B"
        if s >= 60:
            return "C"
        if s >= 50:
            return "D"
        return "F"
