"""Git command wrapper for extracting repo data."""

from __future__ import annotations

import os
import subprocess
from datetime import datetime, timezone
from pathlib import Path

from .models import CommitInfo


def is_git_repo(path: str) -> bool:
    """Check if path is inside a git repository."""
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--is-inside-work-tree"],
            cwd=path, capture_output=True, text=True, timeout=10,
        )
        return result.returncode == 0
    except Exception:
        return False


def get_repo_name(path: str) -> str:
    """Get the repository name from the path."""
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--show-toplevel"],
            cwd=path, capture_output=True, text=True, timeout=10,
        )
        if result.returncode == 0:
            return Path(result.stdout.strip()).name
    except Exception:
        pass
    return Path(path).name


def get_current_branch(path: str) -> str:
    """Get current branch name."""
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            cwd=path, capture_output=True, text=True, timeout=10,
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except Exception:
        pass
    return "unknown"


def get_commit_log(path: str, since: str | None = None, until: str | None = None) -> list[CommitInfo]:
    """Parse git log into CommitInfo objects."""
    # Format: hash|author_name|author_email|date_iso|message
    fmt = "%H|%aN|%aE|%aI|%s"
    cmd = ["git", "log", f"--format={fmt}", "--numstat"]

    if since:
        cmd.append(f"--since={since}")
    if until:
        cmd.append(f"--until={until}")

    try:
        result = subprocess.run(
            cmd, cwd=path, capture_output=True, text=True, timeout=60,
            env={**os.environ, "GIT_TERMINAL_PROMPT": "0"},
        )
        if result.returncode != 0:
            return []
    except Exception:
        return []

    return _parse_log(result.stdout)


def _parse_log(log_output: str) -> list[CommitInfo]:
    """Parse git log output into CommitInfo objects."""
    commits: list[CommitInfo] = []
    lines = log_output.strip().split("\n")

    current_commit = None
    insertions = 0
    deletions = 0
    files_changed = 0

    for line in lines:
        line = line.strip()
        if not line:
            continue

        parts = line.split("|", 4)
        if len(parts) == 5 and len(parts[0]) == 40:
            # Save previous commit
            if current_commit is not None:
                current_commit.insertions = insertions
                current_commit.deletions = deletions
                current_commit.files_changed = files_changed
                commits.append(current_commit)

            # Parse new commit
            hash_val, name, email, date_str, message = parts
            try:
                date = datetime.fromisoformat(date_str)
                if date.tzinfo is None:
                    date = date.replace(tzinfo=timezone.utc)
            except (ValueError, TypeError):
                date = datetime.now(timezone.utc)

            current_commit = CommitInfo(
                hash=hash_val,
                author_name=name,
                author_email=email,
                date=date,
                message=message,
            )
            insertions = 0
            deletions = 0
            files_changed = 0
        else:
            # Numstat line: insertions\tdeletions\tfilename
            numstat_parts = line.split("\t")
            if len(numstat_parts) >= 3:
                try:
                    ins = int(numstat_parts[0]) if numstat_parts[0] != "-" else 0
                    dels = int(numstat_parts[1]) if numstat_parts[1] != "-" else 0
                    insertions += ins
                    deletions += dels
                    files_changed += 1
                except ValueError:
                    pass

    # Don't forget the last commit
    if current_commit is not None:
        current_commit.insertions = insertions
        current_commit.deletions = deletions
        current_commit.files_changed = files_changed
        commits.append(current_commit)

    return commits


def get_file_changes(path: str, since: str | None = None) -> dict[str, dict]:
    """Get file-level change stats from git log."""
    cmd = ["git", "log", "--numstat", "--format=%H|%aN"]
    if since:
        cmd.append(f"--since={since}")

    try:
        result = subprocess.run(
            cmd, cwd=path, capture_output=True, text=True, timeout=60,
            env={**os.environ, "GIT_TERMINAL_PROMPT": "0"},
        )
        if result.returncode != 0:
            return {}
    except Exception:
        return {}

    file_stats: dict[str, dict] = {}
    current_author = None

    for line in result.stdout.strip().split("\n"):
        line = line.strip()
        if not line:
            continue

        if "|" in line and len(line.split("|")) == 2:
            parts = line.split("|")
            if len(parts[0]) == 40:
                current_author = parts[1]
                continue

        parts = line.split("\t")
        if len(parts) >= 3:
            try:
                ins = int(parts[0]) if parts[0] != "-" else 0
                dels = int(parts[1]) if parts[1] != "-" else 0
                fname = parts[2]
                if fname not in file_stats:
                    file_stats[fname] = {
                        "insertions": 0,
                        "deletions": 0,
                        "changes": 0,
                        "commits": 0,
                        "authors": set(),
                    }
                file_stats[fname]["insertions"] += ins
                file_stats[fname]["deletions"] += dels
                file_stats[fname]["changes"] += ins + dels
                file_stats[fname]["commits"] += 1
                if current_author:
                    file_stats[fname]["authors"].add(current_author)
            except ValueError:
                pass

    return file_stats
