"""Core analyzer — converts raw git data into insights."""

from __future__ import annotations

import time
from collections import Counter
from pathlib import Path

from ..git_cmd import get_commit_log, get_current_branch, get_file_changes, get_repo_name
from ..models import (
    CommitInfo,
    ContributorStats,
    DayStats,
    FileStats,
    HourStats,
    RepoInsights,
)


def analyze_repo(
    path: str,
    since: str | None = None,
    until: str | None = None,
) -> RepoInsights:
    """Analyze a git repository and return insights."""
    start = time.time()
    insights = RepoInsights(
        repo_path=path,
        repo_name=get_repo_name(path),
        branch=get_current_branch(path),
    )

    # Get commits
    commits = get_commit_log(path, since=since, until=until)
    if not commits:
        insights.analysis_time_ms = int((time.time() - start) * 1000)
        return insights

    insights.commits = commits
    insights.total_commits = len(commits)

    # Summary stats
    insights.total_insertions = sum(c.insertions for c in commits)
    insights.total_deletions = sum(c.deletions for c in commits)
    insights.total_files_changed = sum(c.files_changed for c in commits)

    dates = [c.date for c in commits]
    insights.first_commit_date = min(dates)
    insights.last_commit_date = max(dates)

    # Contributor analysis
    insights.contributors = _analyze_contributors(commits)
    insights.total_authors = len(insights.contributors)

    # Day distribution
    insights.day_distribution = _analyze_day_distribution(commits)

    # Hour distribution
    insights.hour_distribution = _analyze_hour_distribution(commits)

    # File hotspots
    file_changes = get_file_changes(path, since=since)
    insights.file_hotspots = _analyze_file_hotspots(file_changes)

    # Trends
    insights.monthly_commits = _analyze_monthly_trend(commits)
    insights.weekly_commits = _analyze_weekly_trend(commits)

    # Computed metrics
    repo_age = insights.repo_age_days
    insights.avg_commits_per_day = round(insights.total_commits / max(1, repo_age), 2)
    total_churn = insights.total_insertions + insights.total_deletions
    insights.avg_commit_size = round(total_churn / max(1, insights.total_commits), 1)

    merge_count = sum(1 for c in commits if c.is_merge)
    insights.merge_commit_ratio = round(merge_count / max(1, insights.total_commits), 3)

    # Bus factor
    insights.bus_factor = _calculate_bus_factor(insights.contributors)

    # Top file types
    insights.top_file_types = _analyze_file_types(file_changes)

    insights.analysis_time_ms = int((time.time() - start) * 1000)
    return insights


def _analyze_contributors(commits: list[CommitInfo]) -> list[ContributorStats]:
    """Aggregate per-contributor statistics."""
    author_map: dict[str, ContributorStats] = {}

    for c in commits:
        key = c.author_email.lower()
        if key not in author_map:
            author_map[key] = ContributorStats(
                name=c.author_name,
                email=c.author_email,
            )
        stats = author_map[key]
        stats.total_commits += 1
        stats.insertions += c.insertions
        stats.deletions += c.deletions
        stats.files_touched += c.files_changed

        if stats.first_commit is None or c.date < stats.first_commit:
            stats.first_commit = c.date
        if stats.last_commit is None or c.date > stats.last_commit:
            stats.last_commit = c.date

    # Calculate active days
    for key in author_map:
        author_commits = [c for c in commits if c.author_email.lower() == key]
        unique_days = {c.date.date() for c in author_commits}
        author_map[key].active_days = len(unique_days)

    # Sort by commits descending
    return sorted(author_map.values(), key=lambda s: s.total_commits, reverse=True)


def _analyze_day_distribution(commits: list[CommitInfo]) -> list[DayStats]:
    """Commits by day of week."""
    days_order = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    day_map: dict[str, DayStats] = {d: DayStats(day=d) for d in days_order}

    for c in commits:
        day = c.weekday
        if day in day_map:
            day_map[day].commit_count += 1
            day_map[day].insertions += c.insertions
            day_map[day].deletions += c.deletions

    return [day_map[d] for d in days_order]


def _analyze_hour_distribution(commits: list[CommitInfo]) -> list[HourStats]:
    """Commits by hour of day."""
    hour_map = {h: HourStats(hour=h) for h in range(24)}
    for c in commits:
        hour_map[c.hour].commit_count += 1
    return [hour_map[h] for h in range(24)]


def _analyze_file_hotspots(file_changes: dict[str, dict]) -> list[FileStats]:
    """Identify file hotspots (most churned files)."""
    hotspots = []
    for fname, stats in file_changes.items():
        hotspots.append(FileStats(
            path=fname,
            total_changes=stats["changes"],
            total_insertions=stats["insertions"],
            total_deletions=stats["deletions"],
            commit_count=stats["commits"],
            contributors=len(stats.get("authors", set())),
        ))
    # Sort by churn score
    hotspots.sort(key=lambda f: f.churn_score, reverse=True)
    return hotspots[:30]  # Top 30


def _analyze_monthly_trend(commits: list[CommitInfo]) -> dict[str, int]:
    """Commits per month."""
    counter: Counter[str] = Counter()
    for c in commits:
        key = c.date.strftime("%Y-%m")
        counter[key] += 1
    return dict(sorted(counter.items()))


def _analyze_weekly_trend(commits: list[CommitInfo]) -> dict[str, int]:
    """Commits per week (last 12 weeks)."""
    counter: Counter[str] = Counter()
    for c in commits:
        key = c.date.strftime("%Y-W%U")
        counter[key] += 1
    # Keep last 12 weeks
    sorted_weeks = sorted(counter.items())
    return dict(sorted_weeks[-12:])


def _calculate_bus_factor(contributors: list[ContributorStats]) -> int:
    """Calculate bus factor: how many contributors cover 50% of commits."""
    if not contributors:
        return 0
    total = sum(c.total_commits for c in contributors)
    if total == 0:
        return 0

    cumulative = 0
    for i, c in enumerate(contributors):
        cumulative += c.total_commits
        if cumulative >= total * 0.5:
            return i + 1
    return len(contributors)


def _analyze_file_types(file_changes: dict[str, dict]) -> dict[str, int]:
    """Count file changes by extension."""
    ext_counter: Counter[str] = Counter()
    for fname in file_changes:
        ext = Path(fname).suffix.lower()
        if ext:
            ext_counter[ext] += file_changes[fname]["changes"]
    return dict(ext_counter.most_common(15))
