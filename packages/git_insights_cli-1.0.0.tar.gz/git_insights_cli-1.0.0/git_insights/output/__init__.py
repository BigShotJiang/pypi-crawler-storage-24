"""git-insights output renderers."""
