"""Rich console output for git-insights."""

from __future__ import annotations

from rich import box
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from ..models import RepoInsights

console = Console()

_GRADE_COLORS = {
    "A+": "bold green",
    "A": "green",
    "B": "yellow",
    "C": "dark_orange",
    "D": "red",
    "F": "bold red",
}


def render_insights(insights: RepoInsights) -> None:
    """Render full repo insights."""
    console.print()

    # Header
    grade_style = _GRADE_COLORS.get(insights.health_grade, "white")
    console.print(
        Panel(
            f"[bold]git-insights[/] — Repository Analytics\n"
            f"[dim]Repo:[/] {insights.repo_name}  [dim]Branch:[/] {insights.branch}  "
            f"[dim]Health:[/] [{grade_style}]{insights.health_grade}[/] ({insights.health_score}/100)",
            style="bold blue",
            padding=(0, 2),
        )
    )

    # Summary
    _render_summary(insights)

    # Contributors
    if insights.contributors:
        _render_contributors(insights)

    # Day distribution
    if insights.day_distribution:
        _render_day_distribution(insights)

    # Hour heatmap
    if insights.hour_distribution:
        _render_hour_distribution(insights)

    # File hotspots
    if insights.file_hotspots:
        _render_hotspots(insights)

    # Monthly trend
    if insights.monthly_commits:
        _render_monthly_trend(insights)

    # File types
    if insights.top_file_types:
        _render_file_types(insights)

    console.print(f"\n  [dim]Analysis completed in {insights.analysis_time_ms}ms[/]\n")


def _render_summary(insights: RepoInsights) -> None:
    """Render summary stats."""
    table = Table(box=box.SIMPLE, show_header=False, padding=(0, 2))
    table.add_column("Key", style="bold")
    table.add_column("Value")

    table.add_row("Total commits", f"[bold]{insights.total_commits:,}[/]")
    table.add_row("Contributors", f"[bold]{insights.total_authors}[/]")
    table.add_row("Lines added", f"[green]+{insights.total_insertions:,}[/]")
    table.add_row("Lines deleted", f"[red]-{insights.total_deletions:,}[/]")
    table.add_row("Net change", f"[bold]{insights.net_lines:,}[/]")
    table.add_row("Files changed", f"{insights.total_files_changed:,}")

    if insights.first_commit_date:
        table.add_row("First commit", insights.first_commit_date.strftime("%Y-%m-%d"))
    if insights.last_commit_date:
        table.add_row("Last commit", insights.last_commit_date.strftime("%Y-%m-%d"))
    table.add_row("Repo age", f"{insights.repo_age_days} days")
    table.add_row("Avg commits/day", f"{insights.avg_commits_per_day}")
    table.add_row("Avg commit size", f"{insights.avg_commit_size:.0f} lines")
    table.add_row("Merge ratio", f"{insights.merge_commit_ratio:.1%}")
    table.add_row("Bus factor", f"[bold]{insights.bus_factor}[/]")

    console.print(Panel(table, title="[bold]Summary[/]", border_style="blue"))


def _render_contributors(insights: RepoInsights) -> None:
    """Render contributor table."""
    table = Table(
        title="[bold]Top Contributors[/]",
        box=box.ROUNDED,
        expand=True,
    )
    table.add_column("#", width=3, justify="right")
    table.add_column("Author", ratio=1)
    table.add_column("Commits", justify="right", width=8)
    table.add_column("Added", justify="right", width=8, style="green")
    table.add_column("Deleted", justify="right", width=8, style="red")
    table.add_column("Avg Size", justify="right", width=8)
    table.add_column("Active Days", justify="right", width=10)

    for i, c in enumerate(insights.contributors[:15], 1):
        table.add_row(
            str(i),
            c.name,
            str(c.total_commits),
            f"+{c.insertions:,}",
            f"-{c.deletions:,}",
            f"{c.avg_commit_size:.0f}",
            str(c.active_days),
        )

    console.print(table)


def _render_day_distribution(insights: RepoInsights) -> None:
    """Render commits by day of week with bar chart."""
    max_count = max((d.commit_count for d in insights.day_distribution), default=1)

    table = Table(title="[bold]Commits by Day[/]", box=box.SIMPLE, expand=True)
    table.add_column("Day", width=10)
    table.add_column("Commits", justify="right", width=7)
    table.add_column("Distribution", ratio=1)

    for d in insights.day_distribution:
        bar_len = int(d.commit_count / max(1, max_count) * 30)
        bar = "█" * bar_len
        style = "bright_green" if d.day in ("Saturday", "Sunday") else "blue"
        table.add_row(d.day[:3], str(d.commit_count), f"[{style}]{bar}[/]")

    console.print(table)


def _render_hour_distribution(insights: RepoInsights) -> None:
    """Render commits by hour heatmap."""
    max_count = max((h.commit_count for h in insights.hour_distribution), default=1)

    parts = []
    for h in insights.hour_distribution:
        intensity = h.commit_count / max(1, max_count)
        if intensity > 0.7:
            block = "[bold red]█[/]"
        elif intensity > 0.4:
            block = "[yellow]▓[/]"
        elif intensity > 0.1:
            block = "[blue]▒[/]"
        elif h.commit_count > 0:
            block = "[dim]░[/]"
        else:
            block = "[dim]·[/]"
        parts.append(block)

    heatmap = " ".join(parts)
    hours_label = " ".join(f"{h:02d}" for h in range(24))

    console.print(Panel(
        f"{heatmap}\n[dim]{hours_label}[/]",
        title="[bold]Activity Heatmap (by hour)[/]",
        border_style="blue",
    ))


def _render_hotspots(insights: RepoInsights) -> None:
    """Render file hotspots."""
    table = Table(
        title="[bold]File Hotspots (most churned)[/]",
        box=box.ROUNDED,
        expand=True,
    )
    table.add_column("#", width=3, justify="right")
    table.add_column("File", ratio=1)
    table.add_column("Changes", justify="right", width=8)
    table.add_column("Commits", justify="right", width=7)
    table.add_column("Authors", justify="right", width=7)
    table.add_column("Churn Score", justify="right", width=10)

    for i, f in enumerate(insights.file_hotspots[:15], 1):
        score_style = "red" if f.churn_score > 1000 else "yellow" if f.churn_score > 100 else "green"
        table.add_row(
            str(i),
            _truncate(f.path, 50),
            f"{f.total_changes:,}",
            str(f.commit_count),
            str(f.contributors),
            Text(f"{f.churn_score:,.0f}", style=score_style),
        )

    console.print(table)


def _render_monthly_trend(insights: RepoInsights) -> None:
    """Render monthly commit trend."""
    if not insights.monthly_commits:
        return

    max_count = max(insights.monthly_commits.values(), default=1)
    table = Table(title="[bold]Monthly Trend[/]", box=box.SIMPLE, expand=True)
    table.add_column("Month", width=8)
    table.add_column("Commits", justify="right", width=7)
    table.add_column("Trend", ratio=1)

    # Show last 12 months
    months = list(insights.monthly_commits.items())[-12:]
    for month, count in months:
        bar_len = int(count / max(1, max_count) * 30)
        bar = "█" * bar_len
        table.add_row(month, str(count), f"[cyan]{bar}[/]")

    console.print(table)


def _render_file_types(insights: RepoInsights) -> None:
    """Render file type breakdown."""
    table = Table(title="[bold]File Types (by changes)[/]", box=box.SIMPLE)
    table.add_column("Extension", width=10)
    table.add_column("Changes", justify="right", width=10)

    for ext, count in list(insights.top_file_types.items())[:10]:
        table.add_row(ext, f"{count:,}")

    console.print(table)


def _truncate(text: str, max_len: int) -> str:
    if len(text) <= max_len:
        return text
    return "…" + text[-(max_len - 1):]
