"""HTML report generator for git-insights."""

from __future__ import annotations

import html as _html
from pathlib import Path

from ..models import RepoInsights

_GRADE_COLORS = {
    "A+": "#22c55e", "A": "#22c55e", "B": "#eab308",
    "C": "#f97316", "D": "#ef4444", "F": "#dc2626",
}


def _css() -> str:
    return """
    :root { --bg: #0f172a; --surface: #1e293b; --border: #334155; --text: #e2e8f0; --muted: #94a3b8; --accent: #3b82f6; }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: 'Segoe UI', system-ui, sans-serif; background: var(--bg); color: var(--text); padding: 2rem; }
    .container { max-width: 1200px; margin: 0 auto; }
    h1 { font-size: 1.8rem; margin-bottom: .3rem; }
    h2 { font-size: 1.2rem; margin: 1.6rem 0 .7rem; color: var(--accent); }
    .subtitle { color: var(--muted); margin-bottom: 1.5rem; }
    .cards { display: grid; grid-template-columns: repeat(auto-fit, minmax(140px, 1fr)); gap: .8rem; margin-bottom: 1.5rem; }
    .card { background: var(--surface); border: 1px solid var(--border); border-radius: .75rem; padding: 1rem; text-align: center; }
    .card .value { font-size: 1.8rem; font-weight: 700; }
    .card .label { color: var(--muted); font-size: .8rem; margin-top: .2rem; }
    table { width: 100%; border-collapse: collapse; margin-bottom: 1.2rem; }
    th { background: var(--surface); text-align: left; padding: .5rem .7rem; font-size: .78rem; text-transform: uppercase; color: var(--muted); border-bottom: 2px solid var(--border); }
    td { padding: .45rem .7rem; border-bottom: 1px solid var(--border); font-size: .88rem; }
    tr:hover td { background: rgba(59,130,246,.06); }
    .grade { display: inline-block; padding: 4px 14px; border-radius: 8px; font-size: 1.2rem; font-weight: 700; color: #fff; }
    .bar { height: 18px; border-radius: 3px; display: inline-block; }
    .green { color: #22c55e; } .red { color: #ef4444; } .blue { color: #3b82f6; } .muted { color: var(--muted); }
    .heatmap { display: flex; gap: 3px; justify-content: center; margin: .8rem 0; }
    .heat-cell { width: 28px; height: 28px; border-radius: 4px; display: flex; align-items: center; justify-content: center; font-size: .65rem; color: #fff; }
    .section { margin-bottom: 1.6rem; }
    .footer { text-align: center; color: var(--muted); font-size: .78rem; margin-top: 2rem; padding-top: 1rem; border-top: 1px solid var(--border); }
    .two-col { display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; }
    @media (max-width: 768px) { .two-col { grid-template-columns: 1fr; } }
    """


def export_html(insights: RepoInsights, output_path: str) -> str:
    """Generate HTML report."""
    gc = _GRADE_COLORS.get(insights.health_grade, "#6b7280")

    # Summary cards
    cards = f"""
    <div class="cards">
        <div class="card"><div class="value">{insights.total_commits:,}</div><div class="label">Commits</div></div>
        <div class="card"><div class="value">{insights.total_authors}</div><div class="label">Contributors</div></div>
        <div class="card"><div class="value green">+{insights.total_insertions:,}</div><div class="label">Lines Added</div></div>
        <div class="card"><div class="value red">-{insights.total_deletions:,}</div><div class="label">Lines Deleted</div></div>
        <div class="card"><div class="value">{insights.repo_age_days}</div><div class="label">Repo Age (days)</div></div>
        <div class="card"><div class="value">{insights.bus_factor}</div><div class="label">Bus Factor</div></div>
        <div class="card"><div class="value">{insights.avg_commits_per_day}</div><div class="label">Commits/Day</div></div>
        <div class="card"><div class="grade" style="background:{gc}">{insights.health_grade}</div><div class="label">Health ({insights.health_score}/100)</div></div>
    </div>
    """

    # Contributors table
    contrib_rows = ""
    for i, c in enumerate(insights.contributors[:15], 1):
        contrib_rows += f"""<tr>
            <td>{i}</td>
            <td><b>{_html.escape(c.name)}</b></td>
            <td>{c.total_commits}</td>
            <td class="green">+{c.insertions:,}</td>
            <td class="red">-{c.deletions:,}</td>
            <td>{c.avg_commit_size:.0f}</td>
            <td>{c.active_days}</td>
        </tr>"""

    contributors_html = f"""
    <div class="section">
        <h2>Top Contributors</h2>
        <table>
            <thead><tr><th>#</th><th>Author</th><th>Commits</th><th>Added</th><th>Deleted</th><th>Avg Size</th><th>Active Days</th></tr></thead>
            <tbody>{contrib_rows}</tbody>
        </table>
    </div>""" if insights.contributors else ""

    # Day distribution
    day_html = ""
    if insights.day_distribution:
        max_d = max((d.commit_count for d in insights.day_distribution), default=1)
        day_rows = ""
        for d in insights.day_distribution:
            pct = d.commit_count / max(1, max_d) * 100
            color = "#22c55e" if d.day in ("Saturday", "Sunday") else "#3b82f6"
            day_rows += f"""<tr>
                <td>{d.day[:3]}</td>
                <td>{d.commit_count}</td>
                <td><div class="bar" style="width:{pct}%;background:{color}">&nbsp;</div></td>
            </tr>"""
        day_html = f"""<div>
            <h2>Commits by Day</h2>
            <table><thead><tr><th>Day</th><th>Commits</th><th>Distribution</th></tr></thead>
            <tbody>{day_rows}</tbody></table>
        </div>"""

    # Hour heatmap
    hour_html = ""
    if insights.hour_distribution:
        cells = ""
        max_h = max((h.commit_count for h in insights.hour_distribution), default=1)
        for h in insights.hour_distribution:
            intensity = h.commit_count / max(1, max_h)
            if intensity > 0.7:
                bg = "#ef4444"
            elif intensity > 0.4:
                bg = "#eab308"
            elif intensity > 0.1:
                bg = "#3b82f6"
            elif h.commit_count > 0:
                bg = "#334155"
            else:
                bg = "#1e293b"
            cells += f'<div class="heat-cell" style="background:{bg}" title="{h.hour}:00 — {h.commit_count} commits">{h.hour}</div>'
        hour_html = f"""<div>
            <h2>Activity Heatmap (by hour)</h2>
            <div class="heatmap">{cells}</div>
        </div>"""

    # File hotspots
    hotspot_rows = ""
    for i, f in enumerate(insights.file_hotspots[:15], 1):
        score_color = "#ef4444" if f.churn_score > 1000 else "#eab308" if f.churn_score > 100 else "#22c55e"
        hotspot_rows += f"""<tr>
            <td>{i}</td>
            <td>{_html.escape(f.path)}</td>
            <td>{f.total_changes:,}</td>
            <td>{f.commit_count}</td>
            <td>{f.contributors}</td>
            <td style="color:{score_color}">{f.churn_score:,.0f}</td>
        </tr>"""

    hotspots_html = f"""
    <div class="section">
        <h2>File Hotspots</h2>
        <table>
            <thead><tr><th>#</th><th>File</th><th>Changes</th><th>Commits</th><th>Authors</th><th>Churn Score</th></tr></thead>
            <tbody>{hotspot_rows}</tbody>
        </table>
    </div>""" if insights.file_hotspots else ""

    # Monthly trend
    monthly_html = ""
    if insights.monthly_commits:
        max_m = max(insights.monthly_commits.values(), default=1)
        m_rows = ""
        for month, count in list(insights.monthly_commits.items())[-12:]:
            pct = count / max(1, max_m) * 100
            m_rows += f"""<tr>
                <td>{month}</td><td>{count}</td>
                <td><div class="bar" style="width:{pct}%;background:#06b6d4">&nbsp;</div></td>
            </tr>"""
        monthly_html = f"""<div class="section">
            <h2>Monthly Trend</h2>
            <table><thead><tr><th>Month</th><th>Commits</th><th>Trend</th></tr></thead>
            <tbody>{m_rows}</tbody></table>
        </div>"""

    # File types
    types_html = ""
    if insights.top_file_types:
        t_rows = ""
        for ext, count in list(insights.top_file_types.items())[:10]:
            t_rows += f"<tr><td>{_html.escape(ext)}</td><td>{count:,}</td></tr>"
        types_html = f"""<div>
            <h2>File Types</h2>
            <table><thead><tr><th>Extension</th><th>Changes</th></tr></thead>
            <tbody>{t_rows}</tbody></table>
        </div>"""

    # Assemble
    two_col = f'<div class="two-col">{day_html}{hour_html}</div>' if day_html or hour_html else ""
    two_col2 = f'<div class="two-col">{monthly_html}{types_html}</div>' if monthly_html or types_html else ""

    dates_info = ""
    if insights.first_commit_date:
        dates_info = f" · {insights.first_commit_date.strftime('%Y-%m-%d')} → {insights.last_commit_date.strftime('%Y-%m-%d') if insights.last_commit_date else 'now'}"

    page = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
    <title>git-insights · {_html.escape(insights.repo_name)}</title>
    <style>{_css()}</style>
</head>
<body>
<div class="container">
    <h1>📊 git-insights</h1>
    <p class="subtitle">{_html.escape(insights.repo_name)} · {insights.branch}{dates_info}</p>
    {cards}
    {contributors_html}
    {two_col}
    {hotspots_html}
    {two_col2}
    <div class="footer">Generated by git-insights · Repository Analytics</div>
</div>
</body>
</html>"""

    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    Path(output_path).write_text(page, encoding="utf-8")
    return output_path
