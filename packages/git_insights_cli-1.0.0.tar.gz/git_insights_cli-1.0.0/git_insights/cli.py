"""CLI entry point for git-insights."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import click
from rich.console import Console

from . import __version__
from .analyzers.core import analyze_repo
from .git_cmd import is_git_repo
from .output.console import render_insights
from .output.html_report import export_html

console = Console()


def _insights_to_dict(insights) -> dict:
    """Convert RepoInsights to serializable dict."""
    return {
        "repo_name": insights.repo_name,
        "branch": insights.branch,
        "total_commits": insights.total_commits,
        "total_authors": insights.total_authors,
        "total_insertions": insights.total_insertions,
        "total_deletions": insights.total_deletions,
        "net_lines": insights.net_lines,
        "total_files_changed": insights.total_files_changed,
        "first_commit": insights.first_commit_date.isoformat() if insights.first_commit_date else None,
        "last_commit": insights.last_commit_date.isoformat() if insights.last_commit_date else None,
        "repo_age_days": insights.repo_age_days,
        "avg_commits_per_day": insights.avg_commits_per_day,
        "avg_commit_size": insights.avg_commit_size,
        "merge_commit_ratio": insights.merge_commit_ratio,
        "bus_factor": insights.bus_factor,
        "health_score": insights.health_score,
        "health_grade": insights.health_grade,
        "analysis_time_ms": insights.analysis_time_ms,
        "contributors": [
            {
                "name": c.name,
                "email": c.email,
                "commits": c.total_commits,
                "insertions": c.insertions,
                "deletions": c.deletions,
                "active_days": c.active_days,
            }
            for c in insights.contributors
        ],
        "file_hotspots": [
            {
                "path": f.path,
                "changes": f.total_changes,
                "commits": f.commit_count,
                "contributors": f.contributors,
                "churn_score": f.churn_score,
            }
            for f in insights.file_hotspots[:20]
        ],
        "monthly_commits": insights.monthly_commits,
        "day_distribution": {d.day: d.commit_count for d in insights.day_distribution},
        "top_file_types": insights.top_file_types,
    }


@click.group()
@click.version_option(__version__, prog_name="git-insights")
def cli():
    """📊 git-insights — Git Repository Analytics & Insights.

    Analyze git repositories to discover commit patterns, contributor stats,
    code churn hotspots, team productivity metrics, and health scores.
    """


@cli.command()
@click.argument("path", type=click.Path(exists=True), default=".")
@click.option("--since", help="Start date (e.g., '2024-01-01', '6 months ago')")
@click.option("--until", help="End date (e.g., '2024-12-31')")
@click.option("--html", type=click.Path(), help="Export HTML dashboard report")
@click.option("--json-output", "-j", "json_out", type=click.Path(), help="Export JSON report")
def analyze(path: str, since: str | None, until: str | None, html: str | None, json_out: str | None):
    """Analyze a git repository.

    Examples:

        git-insights analyze .

        git-insights analyze /path/to/repo --html report.html

        git-insights analyze . --since "6 months ago"

        git-insights analyze . -j insights.json
    """
    if not is_git_repo(path):
        console.print(f"[red]Error: '{path}' is not a git repository[/]")
        sys.exit(1)

    insights = analyze_repo(path, since=since, until=until)

    if insights.total_commits == 0:
        console.print("[yellow]No commits found in the specified range.[/]")
        return

    render_insights(insights)

    if json_out:
        Path(json_out).write_text(
            json.dumps(_insights_to_dict(insights), indent=2, default=str),
            encoding="utf-8",
        )
        console.print(f"[green]JSON report → {json_out}[/]")

    if html:
        export_html(insights, html)
        console.print(f"[green]HTML report → {html}[/]")


@cli.command()
@click.argument("path", type=click.Path(exists=True), default=".")
@click.option("--top", default=10, help="Number of contributors to show")
def contributors(path: str, top: int):
    """Show contributor leaderboard.

    Examples:

        git-insights contributors .

        git-insights contributors /path/to/repo --top 20
    """
    if not is_git_repo(path):
        console.print(f"[red]Error: '{path}' is not a git repository[/]")
        sys.exit(1)

    insights = analyze_repo(path)
    if not insights.contributors:
        console.print("[yellow]No contributors found.[/]")
        return

    from .output.console import _render_contributors
    console.print()
    _render_contributors(insights)


@cli.command()
@click.argument("path", type=click.Path(exists=True), default=".")
@click.option("--top", default=15, help="Number of hotspots to show")
def hotspots(path: str, top: int):
    """Show file hotspots (most churned files).

    Examples:

        git-insights hotspots .

        git-insights hotspots /path/to/repo --top 20
    """
    if not is_git_repo(path):
        console.print(f"[red]Error: '{path}' is not a git repository[/]")
        sys.exit(1)

    insights = analyze_repo(path)
    if not insights.file_hotspots:
        console.print("[yellow]No file hotspots found.[/]")
        return

    from .output.console import _render_hotspots
    console.print()
    _render_hotspots(insights)


@cli.command()
@click.argument("path", type=click.Path(exists=True), default=".")
def activity(path: str):
    """Show commit activity patterns (day/hour distribution).

    Examples:

        git-insights activity .
    """
    if not is_git_repo(path):
        console.print(f"[red]Error: '{path}' is not a git repository[/]")
        sys.exit(1)

    insights = analyze_repo(path)

    from .output.console import _render_day_distribution, _render_hour_distribution
    console.print()
    if insights.day_distribution:
        _render_day_distribution(insights)
    if insights.hour_distribution:
        _render_hour_distribution(insights)


@cli.command()
@click.argument("path", type=click.Path(exists=True), default=".")
def summary(path: str):
    """Show quick repo summary with health score.

    Examples:

        git-insights summary .
    """
    if not is_git_repo(path):
        console.print(f"[red]Error: '{path}' is not a git repository[/]")
        sys.exit(1)

    insights = analyze_repo(path)
    from .output.console import _render_summary
    console.print()

    grade_colors = {"A+": "bold green", "A": "green", "B": "yellow", "C": "dark_orange", "D": "red", "F": "bold red"}
    grade_style = grade_colors.get(insights.health_grade, "white")
    console.print(
        f"  [bold]{insights.repo_name}[/] · {insights.branch} · "
        f"Health: [{grade_style}]{insights.health_grade}[/] ({insights.health_score}/100)\n"
    )
    _render_summary(insights)
