"""git-insights — Git repository analytics & insights CLI."""

__version__ = "1.0.0"
