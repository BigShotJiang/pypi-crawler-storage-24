"""Allow running as python -m git_insights."""

from .cli import cli

cli()
