__version__ = "1.0.6"
__author__ = "Meepo Team"
__email__ = "echo_now@163.com"
__website__ = "https://meepoquant.com"
