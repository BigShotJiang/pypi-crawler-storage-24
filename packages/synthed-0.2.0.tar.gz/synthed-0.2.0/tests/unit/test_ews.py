"""Tests for EWS synthetic data generator."""

import shutil
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

from synthed.ews.constants import ARCHETYPES, PERIODS
from synthed.ews.firm_pool import generate_firm_pool
from synthed.ews.generator import generate_ews_data
from synthed.ews.score_engine import generate_scores


def test_firm_pool_count():
    rng = np.random.default_rng(42)
    firms = generate_firm_pool(rng, 100)
    assert len(firms) == 100


def test_firm_pool_unique_mutas():
    rng = np.random.default_rng(42)
    firms = generate_firm_pool(rng, 100)
    mutas = [f.muta for f in firms]
    assert len(set(mutas)) == 100


def test_firm_pool_archetypes():
    rng = np.random.default_rng(42)
    firms = generate_firm_pool(rng, 1000)
    from collections import Counter
    counts = Counter(f.archetype for f in firms)
    for atype, expected in ARCHETYPES.items():
        assert counts[atype] == expected, f"{atype}: got {counts[atype]}, expected {expected}"


def test_score_generation():
    rng = np.random.default_rng(42)
    firms = generate_firm_pool(rng, 50)
    records = generate_scores(firms, rng)
    assert len(records) == 50 * len(PERIODS)


def test_score_yi_exists():
    rng = np.random.default_rng(42)
    firms = generate_firm_pool(rng, 1000)
    records = generate_scores(firms, rng)
    yi_records = [r for r in records if r.is_yi]
    assert len(yi_records) > 0, "Should have YI records"


def test_score_eus_yis_split():
    rng = np.random.default_rng(42)
    firms = generate_firm_pool(rng, 1000)
    records = generate_scores(firms, rng)
    period_records = [r for r in records if r.period == PERIODS[0]]
    eus_count = sum(1 for r in period_records if r.eus_skor is not None and not r.is_yi)
    yis_count = sum(1 for r in period_records if r.yis_skor is not None and not r.is_yi)
    assert eus_count > 50, f"Expected >50 EUS firms, got {eus_count}"
    assert yis_count > 50, f"Expected >50 YIS firms, got {yis_count}"


def test_full_generation(tmp_path: Path):
    generate_ews_data(tmp_path, seed=42, n_firms=50)
    ext = tmp_path / "external_data"
    assert ext.exists()
    assert (ext / "kik_data_ham_csv").exists()
    assert (ext / "yis_tahmin_data").exists()
    assert (ext / "eus_tahmin_data").exists()
    assert (ext / "kredi_db").exists()
    assert (ext / "statik_db").exists()
    assert (ext / "eus_hedef_muta").exists()
    assert (ext / "yis_train_data").exists()


def test_kik_csv_format(tmp_path: Path):
    generate_ews_data(tmp_path, seed=42, n_firms=50, skip_edge_cases=True)
    kik_dir = tmp_path / "external_data" / "kik_data_ham_csv"
    files = list(kik_dir.glob("*.csv"))
    assert len(files) == 4
    df = pd.read_csv(files[0], sep=";", encoding="cp1254")
    assert "Must No" in df.columns
    assert "Risk Bky Tl" in df.columns
    # Turkish number format check
    sample_risk = df["Risk Bky Tl"].iloc[0]
    assert "," in str(sample_risk), "Should use Turkish number format"


def test_reproducibility(tmp_path: Path):
    out1 = tmp_path / "run1"
    out2 = tmp_path / "run2"
    generate_ews_data(out1, seed=99, n_firms=50)
    generate_ews_data(out2, seed=99, n_firms=50)

    kik1 = pd.read_csv(
        out1 / "external_data/kik_data_ham_csv/Izleme Kriterleri Kurumsal 20250302.csv",
        sep=";", encoding="cp1254",
    )
    kik2 = pd.read_csv(
        out2 / "external_data/kik_data_ham_csv/Izleme Kriterleri Kurumsal 20250302.csv",
        sep=";", encoding="cp1254",
    )
    pd.testing.assert_frame_equal(kik1, kik2)
