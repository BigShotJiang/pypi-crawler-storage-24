"""Edge case injection for EWS synthetic data."""

from __future__ import annotations

import numpy as np
import pandas as pd

from synthed.ews.constants import EDGE_CASES


def inject_edge_cases(
    records: list,
    firms: list,
    rng: np.random.Generator,
) -> tuple[list, list]:
    """Inject edge cases into records and firms (in-place mutations)."""
    n_records = len(records)
    n_firms = len(firms)

    # NaN score (%2 random cells)
    nan_count = max(1, int(n_records * EDGE_CASES["nan_score_ratio"]))
    nan_indices = rng.choice(n_records, size=nan_count, replace=False)
    for idx in nan_indices:
        r = records[idx]
        if r.yis_skor is not None:
            r.yis_skor = float("nan")
        if r.eus_skor is not None:
            r.eus_skor = float("nan")

    # Float score (%5) — add fractional part to integer scores
    float_count = max(1, int(n_records * EDGE_CASES["float_score_ratio"]))
    float_indices = rng.choice(n_records, size=float_count, replace=False)
    for idx in float_indices:
        r = records[idx]
        frac = rng.uniform(0.1, 0.9)
        if r.yis_skor is not None and not np.isnan(r.yis_skor):
            r.yis_skor = round(r.yis_skor + frac, 1)
        if r.eus_skor is not None and not np.isnan(r.eus_skor):
            r.eus_skor = round(r.eus_skor + frac, 1)

    # Empty/None name (%3)
    name_count = max(1, int(n_firms * EDGE_CASES["empty_name_ratio"]))
    name_indices = rng.choice(n_firms, size=name_count, replace=False)
    for idx in name_indices:
        firms[idx].name = rng.choice(["", "None", " "])

    # Whitespace MUTA (%2)
    ws_count = max(1, int(n_records * EDGE_CASES["whitespace_muta_ratio"]))
    ws_indices = rng.choice(n_records, size=ws_count, replace=False)
    for idx in ws_indices:
        r = records[idx]
        r.muta = f"  {r.muta}  "

    # NULL bolge_kodu / sube_kodu (%5)
    region_count = max(1, int(n_firms * EDGE_CASES["null_region_ratio"]))
    region_indices = rng.choice(n_firms, size=region_count, replace=False)
    for idx in region_indices:
        firms[idx].bolge_kodu = ""
        firms[idx].bolge_adi = ""
        firms[idx].sube_kodu = ""
        firms[idx].sube_adi = ""

    # Empty/zero risk (%3)
    risk_count = max(1, int(n_records * EDGE_CASES["empty_risk_ratio"]))
    risk_indices = rng.choice(n_records, size=risk_count, replace=False)
    for idx in risk_indices:
        r = records[idx]
        r.risk_bky_tl = 0.0 if rng.random() < 0.5 else float("nan")

    # "nan" string ykn_izl_flag (%1)
    flag_count = max(1, int(n_records * EDGE_CASES["nan_flag_ratio"]))
    flag_indices = rng.choice(n_records, size=flag_count, replace=False)
    for idx in flag_indices:
        records[idx].ykn_izl_flag = "nan"

    # Empty rating/tarih (%3)
    rating_count = max(1, int(n_records * EDGE_CASES["empty_rating_ratio"]))
    rating_indices = rng.choice(n_records, size=rating_count, replace=False)
    for idx in rating_indices:
        r = records[idx]
        r.rating_kod = ""
        r.rating_tar = ""

    return records, firms
