"""EWS domain constants."""

from __future__ import annotations

# Periods to generate (YYMM format)
PERIODS = ["2503", "2506", "2509", "2512"]

# Total firms
N_FIRMS = 1000

# Archetype distribution
ARCHETYPES = {
    "fast_rising": 50,
    "persistent_high": 30,
    "regime_change": 20,
    "early_signal": 30,
    "yi_transition": 50,
    "caught_yi": 50,
    "missed_yi": 50,
    "normal": 720,
}

# EWS score bands
BAND_YI = "YI"
BAND_EUS_RANGE = (0, 500)
BAND_YIS_RANGE = (500, 1000)

# Edge case ratios
EDGE_CASES = {
    "nan_score_ratio": 0.02,
    "float_score_ratio": 0.05,
    "empty_name_ratio": 0.03,
    "whitespace_muta_ratio": 0.02,
    "null_region_ratio": 0.05,
    "empty_risk_ratio": 0.03,
    "nan_flag_ratio": 0.01,
    "empty_rating_ratio": 0.03,
}

# Region/branch structure
REGIONS = {
    "01": {"name": "Marmara Bölgesi", "branches": {"0101": "İstanbul Merkez", "0102": "Bursa", "0103": "Kocaeli", "0104": "Tekirdağ"}},
    "02": {"name": "Ege Bölgesi", "branches": {"0201": "İzmir Merkez", "0202": "Denizli", "0203": "Manisa"}},
    "03": {"name": "İç Anadolu Bölgesi", "branches": {"0301": "Ankara Merkez", "0302": "Konya", "0303": "Kayseri", "0304": "Eskişehir"}},
    "04": {"name": "Akdeniz Bölgesi", "branches": {"0401": "Antalya", "0402": "Adana", "0403": "Mersin"}},
    "05": {"name": "Karadeniz Bölgesi", "branches": {"0501": "Trabzon", "0502": "Samsun", "0503": "Zonguldak"}},
    "06": {"name": "Güneydoğu Bölgesi", "branches": {"0601": "Gaziantep", "0602": "Şanlıurfa", "0603": "Diyarbakır"}},
}

# Segment types (one-hot)
SEGMENTS = ["ESKK", "KOBI", "KUR-TIC", "MIKRO"]
SEGMENT_WEIGHTS = [0.15, 0.35, 0.30, 0.20]

# Rating codes
RATING_CODES = ["AA", "A", "BBB", "BB", "B", "CCC", "CC", "C", "D"]

# Firm type codes
FIRM_TYPE_CODES = ["01", "02", "03", "04"]

# File naming templates
FILE_TEMPLATES = {
    "kik": "Izleme Kriterleri Kurumsal 20{period}02.csv",
    "yis": "{year}_{month:02d}_{day:02d}_pred_n_scor.csv",
    "eus": "{year}_{month:02d}_{day:02d}_pred_n_scor.csv",
    "risk": "kurumsal_risk_{period}.parquet",
    "static": "statik_bilgiler_{period}.txt",
    "eus_hedef": "eus_hedef_MUTA_{period}.csv",
    "eus_kapsam": "eus_kapsam_MUTA_{period}.csv",
    "training": "yis_21_v21_{period}.parquet",
}

# Output directories
OUTPUT_DIRS = {
    "kik": "kik_data_ham_csv",
    "yis": "yis_tahmin_data",
    "eus": "eus_tahmin_data",
    "risk": "kredi_db",
    "static": "statik_db",
    "eus_hedef": "eus_hedef_muta",
    "eus_kapsam": "eus_sql_kapsam_muta",
    "training": "yis_train_data",
}
