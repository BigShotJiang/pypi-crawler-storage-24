"""EWS pipeline synthetic data generator."""
