"""Firm pool generation — MUTAs, segments, regions, archetypes."""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd

from synthed.ews.constants import (
    ARCHETYPES,
    FIRM_TYPE_CODES,
    N_FIRMS,
    REGIONS,
    SEGMENTS,
    SEGMENT_WEIGHTS,
)


@dataclass
class Firm:
    """A single firm with its attributes."""

    muta: str
    name: str
    archetype: str
    segment: str
    bolge_kodu: str
    bolge_adi: str
    sube_kodu: str
    sube_adi: str
    must_tip_kodu: str
    grup_kodu: str
    grup_tanimi: str
    firma_otorize_kodu: str
    aksiyon_sahibi: str
    kri_bolum: str


def generate_firm_pool(rng: np.random.Generator, n: int = N_FIRMS) -> list[Firm]:
    """Generate a pool of firms with assigned archetypes and attributes."""
    # Generate unique MUTAs (8-digit strings)
    mutas = [f"{10000000 + i:08d}" for i in range(n)]

    # Assign archetypes
    archetypes = _assign_archetypes(rng, n)

    # Assign segments
    segments = rng.choice(SEGMENTS, size=n, p=SEGMENT_WEIGHTS)

    # Assign regions/branches
    region_keys = list(REGIONS.keys())
    region_assignments = rng.choice(region_keys, size=n)

    # Generate Turkish company names
    name_prefixes = [
        "Anadolu", "Ege", "Marmara", "Karadeniz", "Akdeniz", "Trakya",
        "Doğu", "Batı", "Kuzey", "Güney", "Merkez", "Yıldız", "Atlas",
        "Delta", "Alfa", "Beta", "Omega", "Vega", "Nova", "Pera",
    ]
    name_suffixes = [
        "Tekstil A.Ş.", "Gıda San. Tic. Ltd.", "İnşaat A.Ş.", "Otomotiv San.",
        "Enerji A.Ş.", "Makina San.", "Kimya Ltd.", "Metal San. Tic.",
        "Plastik A.Ş.", "Lojistik Ltd.", "Bilişim A.Ş.", "Tarım San.",
        "İlaç A.Ş.", "Elektronik Ltd.", "Maden San. Tic.", "Turizm A.Ş.",
    ]

    firms: list[Firm] = []
    for i in range(n):
        region_key = region_assignments[i]
        region = REGIONS[region_key]
        branch_keys = list(region["branches"].keys())
        branch_key = rng.choice(branch_keys)

        prefix = rng.choice(name_prefixes)
        suffix = rng.choice(name_suffixes)
        name = f"{prefix} {suffix}"

        grup_no = f"G{rng.integers(100, 999):03d}"

        firms.append(Firm(
            muta=mutas[i],
            name=name,
            archetype=archetypes[i],
            segment=str(segments[i]),
            bolge_kodu=region_key,
            bolge_adi=region["name"],
            sube_kodu=branch_key,
            sube_adi=region["branches"][branch_key],
            must_tip_kodu=str(rng.choice(FIRM_TYPE_CODES)),
            grup_kodu=grup_no,
            grup_tanimi=f"Grup {grup_no}",
            firma_otorize_kodu=f"OT{rng.integers(10, 99)}",
            aksiyon_sahibi=rng.choice(["KRY", "OPR", "TIC", "RYN"]),
            kri_bolum=rng.choice(["KRI-1", "KRI-2", "KRI-3"]),
        ))

    return firms


def _assign_archetypes(rng: np.random.Generator, n: int) -> list[str]:
    """Assign archetypes to firms based on distribution."""
    archetypes: list[str] = []
    for atype, count in ARCHETYPES.items():
        archetypes.extend([atype] * count)

    # Pad or trim to n
    if len(archetypes) < n:
        archetypes.extend(["normal"] * (n - len(archetypes)))
    elif len(archetypes) > n:
        archetypes = archetypes[:n]

    rng.shuffle(archetypes)
    return archetypes
