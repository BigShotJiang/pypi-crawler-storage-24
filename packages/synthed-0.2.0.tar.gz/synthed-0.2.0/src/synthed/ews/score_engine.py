"""Score engine — generate EWS score trajectories per archetype."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np

from synthed.ews.constants import PERIODS
from synthed.ews.firm_pool import Firm


@dataclass
class FirmPeriodRecord:
    """Score data for one firm in one period."""

    muta: str
    period: str
    ews_score: float | None  # 0-1000 or None for YI
    is_yi: bool  # True if firm is YI this period
    ews_source: str  # "yis" or "eus"
    yis_skor: float | None
    eus_skor: float | None
    yis_label: int  # 0 or 1
    eus_label: int  # 0 or 1
    yis_ihtimal: float
    eus_ihtimal: float
    ykn_izl_flag: str  # "0" or "1"
    risk_bky_tl: float
    rating_kod: str
    rating_tar: str


def generate_scores(
    firms: list[Firm],
    rng: np.random.Generator,
    periods: list[str] | None = None,
) -> list[FirmPeriodRecord]:
    """Generate score trajectories for all firms across all periods."""
    periods = periods or PERIODS
    records: list[FirmPeriodRecord] = []

    for firm in firms:
        trajectory = _generate_trajectory(firm, rng, periods)
        records.extend(trajectory)

    return records


def _generate_trajectory(
    firm: Firm,
    rng: np.random.Generator,
    periods: list[str],
) -> list[FirmPeriodRecord]:
    """Generate score trajectory for a single firm."""
    n = len(periods)
    archetype = firm.archetype

    if archetype == "fast_rising":
        scores = _fast_rising(rng, n)
    elif archetype == "persistent_high":
        scores = _persistent_high(rng, n)
    elif archetype == "regime_change":
        scores = _regime_change(rng, n)
    elif archetype == "early_signal":
        scores = _early_signal(rng, n)
    elif archetype == "yi_transition":
        scores = _yi_transition(rng, n)
    elif archetype == "caught_yi":
        scores = _caught_yi(rng, n)
    elif archetype == "missed_yi":
        scores = _missed_yi(rng, n)
    else:
        scores = _normal(rng, n)

    records: list[FirmPeriodRecord] = []
    base_risk = rng.uniform(100_000, 50_000_000)

    from synthed.ews.constants import RATING_CODES
    rating = str(rng.choice(RATING_CODES))

    for i, period in enumerate(periods):
        ews = scores[i]["ews"]
        is_yi = scores[i]["yi"]

        # Determine source and reverse-engineer raw scores
        if is_yi:
            # YI: set flags
            yis_skor = float(rng.integers(0, 1000))
            eus_skor = float(rng.integers(0, 1000))
            yis_label = 1
            eus_label = 0
            ykn_izl = "1" if rng.random() < 0.5 else "0"
            ews_source = "yis"
            yis_ihtimal = rng.uniform(0.6, 0.99)
            eus_ihtimal = rng.uniform(0.1, 0.5)
        elif ews is not None and ews >= 500:
            # YIS band: ews_skor = yis_skor/2 + 500
            yis_skor = (ews - 500) * 2
            yis_skor = max(0, min(1000, yis_skor + rng.normal(0, 5)))
            eus_skor = None
            yis_label = 0
            eus_label = 0
            ykn_izl = "0"
            ews_source = "yis"
            yis_ihtimal = rng.uniform(0.01, 0.4)
            eus_ihtimal = 0.0
        else:
            # EUS band: ews_skor = eus_skor/2
            eus_skor = ews * 2 if ews is not None else float(rng.integers(0, 1000))
            eus_skor = max(0, min(1000, eus_skor + rng.normal(0, 5)))
            yis_skor = None
            yis_label = 0
            eus_label = 0
            ykn_izl = "0"
            ews_source = "eus"
            yis_ihtimal = 0.0
            eus_ihtimal = rng.uniform(0.01, 0.4)

        # Risk varies slightly each period
        risk = base_risk * rng.uniform(0.8, 1.2)

        # Rating date
        year = 2000 + int(period[:2])
        month = int(period[2:])
        rating_tar = f"{year}-{month:02d}-01"

        records.append(FirmPeriodRecord(
            muta=firm.muta,
            period=period,
            ews_score=ews,
            is_yi=is_yi,
            ews_source=ews_source,
            yis_skor=yis_skor,
            eus_skor=eus_skor,
            yis_label=yis_label,
            eus_label=eus_label,
            yis_ihtimal=yis_ihtimal,
            eus_ihtimal=eus_ihtimal,
            ykn_izl_flag=ykn_izl,
            risk_bky_tl=risk,
            rating_kod=rating,
            rating_tar=rating_tar,
        ))

    return records


def _fast_rising(rng: np.random.Generator, n: int) -> list[dict]:
    """5% — Each period has increasing score: ~200→400→600→800."""
    start = rng.integers(100, 324)
    end = rng.integers(825, 950)
    targets = np.linspace(start, end, n)
    return [{"ews": float(max(0, min(1000, t + rng.normal(0, 20)))), "yi": False} for t in targets]


def _persistent_high(rng: np.random.Generator, n: int) -> list[dict]:
    """3% — All periods score >= 700."""
    return [{"ews": float(rng.integers(700, 950)), "yi": False} for _ in range(n)]


def _regime_change(rng: np.random.Generator, n: int) -> list[dict]:
    """2% — First half <500, second half >=500."""
    mid = n // 2
    results = []
    for i in range(n):
        if i < mid:
            results.append({"ews": float(rng.integers(100, 450)), "yi": False})
        else:
            results.append({"ews": float(rng.integers(500, 850)), "yi": False})
    return results


def _early_signal(rng: np.random.Generator, n: int) -> list[dict]:
    """3% — Low score (<500) but >100 point increase over last 3 periods."""
    base = rng.integers(150, 300)
    results = []
    for i in range(n):
        score = base + i * rng.integers(35, 55)
        score = min(score, 499)
        results.append({"ews": float(score), "yi": False})
    return results


def _yi_transition(rng: np.random.Generator, n: int) -> list[dict]:
    """5% — Normal periods 1..n-1, then YI in last period."""
    results = []
    for i in range(n - 1):
        results.append({"ews": float(rng.integers(200, 700)), "yi": False})
    results.append({"ews": None, "yi": True})
    return results


def _caught_yi(rng: np.random.Generator, n: int) -> list[dict]:
    """5% — Score >= 825 in period n-1, then YI in last period."""
    results = []
    for i in range(n - 2):
        # Mix of EUS and YIS band scores
        results.append({"ews": float(rng.integers(200, 800)), "yi": False})
    # Period before last: high score (system would have flagged)
    results.append({"ews": float(rng.integers(825, 980)), "yi": False})
    # Last period: YI
    results.append({"ews": None, "yi": True})
    return results


def _missed_yi(rng: np.random.Generator, n: int) -> list[dict]:
    """5% — Score < 825 in period n-1, then YI in last period."""
    results = []
    for i in range(n - 2):
        # Keep in low-mid range (EUS band likely)
        results.append({"ews": float(rng.integers(100, 500)), "yi": False})
    # Period before last: low score (system missed)
    results.append({"ews": float(rng.integers(200, 600)), "yi": False})
    # Last period: YI
    results.append({"ews": None, "yi": True})
    return results


def _normal(rng: np.random.Generator, n: int) -> list[dict]:
    """72% — Random scores, mild random walk. ~50% EUS band, ~50% YIS band."""
    # Anchor in either EUS (0-500) or YIS (500-1000) band
    if rng.random() < 0.5:
        base = rng.integers(100, 400)  # EUS band center
    else:
        base = rng.integers(550, 850)  # YIS band center
    results = []
    score = float(base)
    for _ in range(n):
        score = max(50, min(950, score + rng.normal(0, 40)))
        results.append({"ews": float(score), "yi": False})
    return results
