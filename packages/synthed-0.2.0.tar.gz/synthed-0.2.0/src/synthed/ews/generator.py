"""EWS synthetic data generator — orchestrator."""

from __future__ import annotations

from pathlib import Path

import numpy as np

from synthed.ews.constants import PERIODS
from synthed.ews.edge_cases import inject_edge_cases
from synthed.ews.file_writers import write_all
from synthed.ews.firm_pool import generate_firm_pool
from synthed.ews.score_engine import generate_scores
from synthed.utils.logging import get_logger

logger = get_logger("ews.generator")


def generate_ews_data(
    output_dir: Path,
    seed: int = 42,
    n_firms: int = 1000,
    periods: list[str] | None = None,
    skip_edge_cases: bool = False,
) -> None:
    """Generate full EWS synthetic dataset.

    Args:
        output_dir: Directory to write external_data/ into.
        seed: Random seed for reproducibility.
        n_firms: Number of firms to generate.
        periods: List of YYMM periods. Defaults to 4 quarters.
        skip_edge_cases: If True, skip edge case injection (clean data).
    """
    periods = periods or PERIODS
    rng = np.random.default_rng(seed)

    logger.info("Generating EWS data: %d firms, %d periods, seed=%d", n_firms, len(periods), seed)

    # Step 1: Generate firm pool
    firms = generate_firm_pool(rng, n_firms)
    logger.info("Generated %d firms", len(firms))

    # Step 2: Generate score trajectories
    records = generate_scores(firms, rng, periods)
    logger.info("Generated %d period-records", len(records))

    # Step 3: Inject edge cases
    if not skip_edge_cases:
        records, firms = inject_edge_cases(records, firms, rng)
        logger.info("Injected edge cases")

    # Step 4: Write all output files
    ext_dir = output_dir / "external_data"
    write_all(records, firms, ext_dir, periods)

    logger.info("EWS data generation complete. Output: %s", ext_dir)
