"""File writers for 7 EWS output formats."""

from __future__ import annotations

import math
from pathlib import Path

import numpy as np
import pandas as pd

from synthed.ews.constants import FILE_TEMPLATES, OUTPUT_DIRS, PERIODS
from synthed.ews.firm_pool import Firm
from synthed.ews.score_engine import FirmPeriodRecord
from synthed.utils.logging import get_logger

logger = get_logger("ews.writers")


def write_all(
    records: list[FirmPeriodRecord],
    firms: list[Firm],
    output_dir: Path,
    periods: list[str] | None = None,
) -> None:
    """Write all 7 file types for all periods."""
    periods = periods or PERIODS
    output_dir.mkdir(parents=True, exist_ok=True)

    firm_map = {f.muta.strip(): f for f in firms}

    for period in periods:
        period_records = [r for r in records if r.period == period]
        logger.info("Writing period %s: %d records", period, len(period_records))

        write_kik_csv(period_records, firm_map, output_dir, period)
        write_yis_csv(period_records, output_dir, period)
        write_eus_csv(period_records, output_dir, period)
        write_risk_parquet(period_records, output_dir, period)
        write_static_txt(period_records, firm_map, output_dir, period)
        write_eus_hedef_kapsam(period_records, output_dir, period)
        write_training_parquet(period_records, firm_map, output_dir, period)


def _format_turkish_number(val: float) -> str:
    """Format number as Turkish: 1.234.567,89"""
    if math.isnan(val):
        return ""
    # Format with 2 decimal places
    formatted = f"{val:,.2f}"
    # Swap: comma→temp, dot→comma, temp→dot
    formatted = formatted.replace(",", "X").replace(".", ",").replace("X", ".")
    return formatted


def _period_to_date(period: str) -> tuple[int, int, int]:
    """Convert YYMM to (year, month, day=2)."""
    year = 2000 + int(period[:2])
    month = int(period[2:])
    return year, month, 2


def _ensure_dir(output_dir: Path, subdir: str) -> Path:
    d = output_dir / subdir
    d.mkdir(parents=True, exist_ok=True)
    return d


# === 1. KIK İzleme CSV (cp1254, semicolon) ===

def write_kik_csv(
    records: list[FirmPeriodRecord],
    firm_map: dict[str, Firm],
    output_dir: Path,
    period: str,
) -> None:
    """Write KIK izleme CSV with cp1254 encoding and semicolon delimiter."""
    d = _ensure_dir(output_dir, OUTPUT_DIRS["kik"])
    filename = FILE_TEMPLATES["kik"].format(period=period)

    rows = []
    for r in records:
        muta_clean = r.muta.strip()
        firm = firm_map.get(muta_clean)
        name = firm.name if firm else ""
        rows.append({
            "Must No": r.muta,
            "Must Ad": name,
            "Risk Bky Tl": _format_turkish_number(r.risk_bky_tl),
            "Ykn Izl Flag": r.ykn_izl_flag,
            "Rtng Kod": r.rating_kod,
            "Rating Tar": r.rating_tar,
        })

    df = pd.DataFrame(rows)
    df.to_csv(d / filename, sep=";", index=False, encoding="cp1254", errors="replace")
    logger.info("Wrote KIK: %s (%d rows)", filename, len(df))


# === 2. YIS Tahmin CSV ===

def write_yis_csv(
    records: list[FirmPeriodRecord],
    output_dir: Path,
    period: str,
) -> None:
    """Write YIS prediction CSV."""
    d = _ensure_dir(output_dir, OUTPUT_DIRS["yis"])
    year, month, day = _period_to_date(period)
    filename = FILE_TEMPLATES["yis"].format(year=year, month=month, day=day)

    yis_records = [r for r in records if r.yis_skor is not None or r.yis_label == 1]
    rows = []
    for r in yis_records:
        rows.append({
            "MUTA": r.muta,
            "yis_skor": r.yis_skor,
            "label": r.yis_label,
            "ihtimal": round(r.yis_ihtimal, 6),
        })

    df = pd.DataFrame(rows)
    df.to_csv(d / filename, index=False, encoding="utf-8")
    logger.info("Wrote YIS: %s (%d rows)", filename, len(df))


# === 3. EUS Tahmin CSV ===

def write_eus_csv(
    records: list[FirmPeriodRecord],
    output_dir: Path,
    period: str,
) -> None:
    """Write EUS prediction CSV."""
    d = _ensure_dir(output_dir, OUTPUT_DIRS["eus"])
    year, month, day = _period_to_date(period)
    filename = FILE_TEMPLATES["eus"].format(year=year, month=month, day=day)

    eus_records = [r for r in records if r.eus_skor is not None or r.eus_label == 1]
    rows = []
    for r in eus_records:
        rows.append({
            "MUTA": r.muta,
            "eus_skor": r.eus_skor,
            "eus_ihtimal": round(r.eus_ihtimal, 6),
            "label": r.eus_label,
        })

    if not rows:
        rows = []  # Empty but columns still written
    df = pd.DataFrame(rows, columns=["MUTA", "eus_skor", "eus_ihtimal", "label"])
    df.to_csv(d / filename, index=False, encoding="utf-8")
    logger.info("Wrote EUS: %s (%d rows)", filename, len(df))


# === 4. Kredi Risk Parquet ===

def write_risk_parquet(
    records: list[FirmPeriodRecord],
    output_dir: Path,
    period: str,
) -> None:
    """Write risk parquet file."""
    d = _ensure_dir(output_dir, OUTPUT_DIRS["risk"])
    filename = FILE_TEMPLATES["risk"].format(period=period)

    rows = [{"MUTA": r.muta, "Risk_Bky_Tl": r.risk_bky_tl} for r in records]
    df = pd.DataFrame(rows)
    df.to_parquet(d / filename, index=False)
    logger.info("Wrote Risk: %s (%d rows)", filename, len(df))


# === 5. Statik Bilgiler TXT (cp1254, semicolon) ===

def write_static_txt(
    records: list[FirmPeriodRecord],
    firm_map: dict[str, Firm],
    output_dir: Path,
    period: str,
) -> None:
    """Write static info TXT with cp1254 encoding."""
    d = _ensure_dir(output_dir, OUTPUT_DIRS["static"])
    filename = FILE_TEMPLATES["static"].format(period=period)

    seen_mutas = set()
    rows = []
    for r in records:
        muta_clean = r.muta.strip()
        if muta_clean in seen_mutas:
            continue
        seen_mutas.add(muta_clean)
        firm = firm_map.get(muta_clean)
        if not firm:
            continue
        rows.append({
            "muta": r.muta,
            "bolge_kodu": firm.bolge_kodu,
            "bolge_adi": firm.bolge_adi,
            "sube_kodu": firm.sube_kodu,
            "sube_adi": firm.sube_adi,
            "must_tip_kodu": firm.must_tip_kodu,
            "grup_kodu": firm.grup_kodu,
            "grup_tanimi": firm.grup_tanimi,
            "firma_otorize_kodu": firm.firma_otorize_kodu,
            "aksiyon_sahibi": firm.aksiyon_sahibi,
            "kri_bolum": firm.kri_bolum,
        })

    df = pd.DataFrame(rows)
    df.to_csv(d / filename, sep=";", index=False, encoding="cp1254", errors="replace")
    logger.info("Wrote Static: %s (%d rows)", filename, len(df))


# === 6. EUS Hedef/Kapsam CSV ===

def write_eus_hedef_kapsam(
    records: list[FirmPeriodRecord],
    output_dir: Path,
    period: str,
) -> None:
    """Write EUS hedef and kapsam MUTA lists."""
    eus_mutas = list({r.muta for r in records if r.eus_skor is not None})

    # Hedef: ~80% of EUS firms
    n_hedef = max(1, int(len(eus_mutas) * 0.8))
    hedef_mutas = eus_mutas[:n_hedef]

    # Kapsam: ~90% of EUS firms
    n_kapsam = max(1, int(len(eus_mutas) * 0.9))
    kapsam_mutas = eus_mutas[:n_kapsam]

    d_hedef = _ensure_dir(output_dir, OUTPUT_DIRS["eus_hedef"])
    d_kapsam = _ensure_dir(output_dir, OUTPUT_DIRS["eus_kapsam"])

    fn_hedef = FILE_TEMPLATES["eus_hedef"].format(period=period)
    fn_kapsam = FILE_TEMPLATES["eus_kapsam"].format(period=period)

    pd.DataFrame({"MUTA": hedef_mutas}).to_csv(d_hedef / fn_hedef, index=False)
    pd.DataFrame({"MUTA": kapsam_mutas}).to_csv(d_kapsam / fn_kapsam, index=False)
    logger.info("Wrote EUS hedef: %d, kapsam: %d for %s", len(hedef_mutas), len(kapsam_mutas), period)


# === 7. Training Parquet ===

def write_training_parquet(
    records: list[FirmPeriodRecord],
    firm_map: dict[str, Firm],
    output_dir: Path,
    period: str,
) -> None:
    """Write training parquet with segment one-hot columns."""
    d = _ensure_dir(output_dir, OUTPUT_DIRS["training"])
    filename = FILE_TEMPLATES["training"].format(period=period)

    seen_mutas = set()
    rows = []
    for r in records:
        muta_clean = r.muta.strip()
        if muta_clean in seen_mutas:
            continue
        seen_mutas.add(muta_clean)
        firm = firm_map.get(muta_clean)
        if not firm:
            continue
        rows.append({
            "MUTA": r.muta,
            "Sgmnt_Kod_ESKK": firm.segment == "ESKK",
            "Sgmnt_Kod_KOBI": firm.segment == "KOBI",
            "Sgmnt_Kod_KUR-TIC": firm.segment == "KUR-TIC",
            "Sgmnt_Kod_MIKRO": firm.segment == "MIKRO",
        })

    df = pd.DataFrame(rows)
    df.to_parquet(d / filename, index=False)
    logger.info("Wrote Training: %s (%d rows)", filename, len(df))
