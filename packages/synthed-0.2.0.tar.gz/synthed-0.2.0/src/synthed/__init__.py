"""Synthed — Privacy-first synthetic data blueprint generator."""

__version__ = "0.2.0"

PRIVACY_DISCLAIMER = (
    "This tool reduces privacy risk but does not automatically establish "
    "legal anonymization. Users are responsible for compliance with applicable "
    "data protection regulations."
)
