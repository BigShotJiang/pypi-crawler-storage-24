# Synthed — Proje Kuralları

## Dil
- Türkçe cevap ver (kod/değişken İngilizce)

## Aktif Task

**EWS Pipeline Sentetik Data** — Detay: `.claude/ews_pipeline_data_request.md`

İki script yazılacak:

### 1. `ews_profile_extract.py` (prod'da çalışır)
- Girdi: DuckDB dosyası (`db/ews.duckdb`) — `ews_scoreboard` pipeline'ının ürettiği
- Çıktı: `ews_data_profile.json` — kişisel veri İÇERMEZ, sadece istatistikler
- Tablolar: `fact_periodic`, `dim_entity`, `map_identity`, `ref_sube_bolge`
- En kritik çıktı: **EWS band geçiş matrisi** (Markov chain için)
- Detaylı profil şeması `.claude/ews_pipeline_data_request.md` içinde

### 2. `ews_synth_generate.py` (dev'de çalışır)
- Girdi: `ews_data_profile.json`
- Çıktı: `external_data/` altında 7 klasör, pipeline'a doğrudan beslenebilir
- Geçiş matrisini Markov chain olarak kullanarak dönemler arası skor zaman serisi üret
- Dosya formatları: KIK CSV (cp1254, semicolon), YIS/EUS CSV, risk parquet, statik TXT
- EWS skor mantığı: YI > EUS(0-500) > YIS(500-1000), YIS-band firmalar EUS'tan çıkarılmalı

### Bağımlılıklar
- `duckdb` (profil çıkartma için)
- `pandas`, `numpy`, `pyarrow` (her iki script)
- `ews_scoreboard` paketi gerekmez — scriptler bağımsız

### Test
- Üretilen data ile `ews_scoreboard` pipeline çalıştırılır
- Trending listelerinde her 6 kategoride firma olmalı
- EWS band dağılımı profile yakın olmalı
