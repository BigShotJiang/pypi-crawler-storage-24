# EWS Pipeline — Sentetik Data Üretimi (2 Aşamalı)

## Genel Bakış

`ews_scoreboard` pipeline'ı için gerçekçi sentetik data üretmek istiyoruz.
Gerçek veri prod ortamından çıkamaz. Bunun yerine:

1. **Profil çıkartma** (prod'da çalışır) → `ews_data_profile.json`
2. **Sentetik üretim** (dev'de çalışır) → `external_data/` dosyaları

Profil dosyasında kişisel veri YOKTUR — sadece istatistikler, dağılımlar, sayılar.

---

## AŞAMA 1: Profil Çıkartma (prod ortamında çalıştırılacak)

`ews_profile_extract.py` scripti. Girdi: DuckDB dosyası (`db/ews.duckdb`).
Çıktı: `ews_data_profile.json` (güvenle taşınabilir).

### Çıkartılacak profil bilgileri:

```python
{
  "meta": {
    "n_entities": int,           # toplam firma sayısı
    "n_periods": int,            # dönem sayısı
    "periods": ["2403", "2406", ...],  # dönem kodları
    "entities_per_period": {     # dönem başına firma sayısı
      "2403": 5200, ...
    }
  },

  "scores": {
    "yis_skor": {
      "histogram": [             # 20 bin (0-50, 50-100, ..., 950-1000)
        {"bin_min": 0, "bin_max": 50, "count": 1234}, ...
      ],
      "null_count": int,
      "quantiles": {"p10": x, "p25": x, "p50": x, "p75": x, "p90": x}
    },
    "eus_skor": {                # aynı format
      "histogram": [...],
      "null_count": int,
      "quantiles": {...},
      "coverage_pct": float      # firmaların yüzde kaçında EUS verisi var
    },
    "yis_label": {
      "rate": float,             # label=1 oranı (ör. 0.03)
      "count_1": int,
      "count_0": int
    },
    "ykn_izl_flag": {
      "rate": float,
      "count_1": int
    }
  },

  "ews_computed": {
    "band_distribution": {       # pipeline hesapladıktan sonra
      "0-324": {"count": int, "pct": float},
      "325-499": {"count": int, "pct": float},
      "500-824": {"count": int, "pct": float},
      "825-999": {"count": int, "pct": float},
      "YI": {"count": int, "pct": float},
      "NULL": {"count": int, "pct": float}
    },
    "transition_matrix": {       # 6x6: dönemden döneme geçiş
      "from_band → to_band": count
      # bands: "0-324", "325-499", "500-824", "825+", "YI", "NULL"
      # Örnek: {"0-324 → 0-324": 4500, "0-324 → 325-499": 120, ...}
    },
    "ews_kaynak_distribution": {
      "eus": {"count": int, "pct": float},
      "yis": {"count": int, "pct": float},
      "yi": {"count": int, "pct": float},
      "null": {"count": int, "pct": float}
    }
  },

  "risk": {
    "kombine_risk": {
      "quantiles": {"min": x, "p10": x, "p25": x, "p50": x, "p75": x, "p90": x, "p95": x, "max": x},
      "null_pct": float,
      "by_segment": {            # segment başına risk quantile
        "KUR-TIC": {"p25": x, "p50": x, "p75": x},
        "ESKK": {...}, ...
      }
    },
    "risk_degisim": {
      "quantiles": {"min": x, "p10": x, "p25": x, "p50": x, "p75": x, "p90": x, "max": x}
    }
  },

  "segments": {
    "distribution": {            # segment → firma sayısı
      "KUR-TIC": int, "ESKK": int, "KOBI": int, "MIKRO": int, "NULL": int
    },
    "segment_x_ews_mean": {      # segment başına ortalama EWS
      "KUR-TIC": float, "ESKK": float, ...
    }
  },

  "geography": {
    "n_bolge": int,
    "n_sube": int,
    "bolge_sizes": [             # bölge başına firma sayıları (sıralı, isim yok)
      450, 380, 320, ...
    ],
    "sube_per_bolge": {          # bölge başına şube sayısı dağılımı
      "min": int, "max": int, "mean": float
    }
  },

  "yi_profile": {
    "prev_score_when_yi": {      # YI olan firmaların bir önceki dönem skoru
      "histogram": [             # aynı 20-bin format
        {"bin_min": 0, "bin_max": 50, "count": x}, ...
      ]
    },
    "yi_duration": {             # ardışık YI dönem sayısı dağılımı
      "1_period": int, "2_periods": int, "3_periods": int, "4+_periods": int
    },
    "new_yi_rate": float,        # her dönemde yeni YI olan firma oranı
    "caught_vs_missed": {        # önceki skor >=825 vs <825
      "caught_count": int,       # önceki skor >= 825
      "missed_count": int        # önceki skor < 825
    }
  },

  "rating": {
    "unique_codes": int,         # kaç farklı rating kodu
    "top_codes": [               # en yaygın 10 rating (kod, sayı)
      ["A1", 1200], ["B2", 980], ...
    ],
    "null_pct": float
  },

  "correlations": {
    "ews_score_x_risk": float,   # pearson korelasyon
    "ews_score_x_ykn_flag": float
  }
}
```

### Profil Çıkartma SQL'leri

Tüm sorgular `fact_periodic` + `dim_entity` tablolarından çalışır.
DuckDB bağlantısı: `duckdb.connect("db/ews.duckdb", read_only=True)`

**Geçiş matrisi** (en kritik sorgu):
```sql
WITH scored AS (
    SELECT entity_id, donem,
        CASE
            WHEN ews_skor = 'YI' THEN 'YI'
            WHEN ews_skor IS NULL THEN 'NULL'
            WHEN CAST(ews_skor AS INT) >= 825 THEN '825+'
            WHEN CAST(ews_skor AS INT) >= 500 THEN '500-824'
            WHEN CAST(ews_skor AS INT) >= 325 THEN '325-499'
            ELSE '0-324'
        END AS band
    FROM fact_periodic
),
transitions AS (
    SELECT
        a.band AS from_band,
        b.band AS to_band,
        COUNT(*) AS cnt
    FROM scored a
    JOIN scored b ON a.entity_id = b.entity_id
    JOIN (
        SELECT donem, LEAD(donem) OVER (ORDER BY donem) AS next_donem
        FROM (SELECT DISTINCT donem FROM fact_periodic ORDER BY donem)
    ) p ON a.donem = p.donem AND b.donem = p.next_donem
    GROUP BY a.band, b.band
)
SELECT * FROM transitions ORDER BY from_band, to_band
```

---

## AŞAMA 2: Sentetik Data Üretimi (dev ortamında çalıştırılacak)

`ews_synth_generate.py` scripti. Girdi: `ews_data_profile.json`.
Çıktı: `external_data/` altında pipeline'a beslenebilir dosyalar.

### Üretim mantığı:

1. **Firma havuzu oluştur**: `n_entities` kadar MUTA, segment ve bölge ata (profildeki dağılıma göre)
2. **Skor zaman serisi üret**: Geçiş matrisini Markov chain olarak kullan
   - İlk dönem: `band_distribution`'a göre başlangıç bandı seç
   - Sonraki dönemler: `transition_matrix` olasılıklarına göre geçiş yap
   - Band içinde exact skor: ilgili histogramdan sample
3. **YI ata**: `yis_label` rate'ine göre + geçiş matrisindeki YI geçişlerine göre
4. **EUS/YIS ayır**: `ews_kaynak_distribution`'a göre firmaları EUS veya YIS'e ata
5. **Risk ata**: Segment bazlı risk quantile'larından sample, dönemler arası risk_degisim dağılımıyla değiştir
6. **Reverse-engineer raw scores**: EWS target → eus_skor veya yis_skor/yis_label (mevcut `_ews_to_raw()` mantığı)
7. **Edge case'leri serpştir**: NULL'lar, float'lar, whitespace, boş unvanlar

### Çıktı dosya formatları:

```
external_data/
├── kik_data_ham_csv/
│   └── Izleme Kriterleri Kurumsal 20YYMM02.csv  (× dönem sayısı)
├── yis_tahmin_data/
│   └── YYYY_MM_DD_pred_n_scor.csv
├── eus_tahmin_data/
│   └── YYYY_MM_DD_pred_n_scor.csv
├── kredi_db/
│   └── kurumsal_risk_YYMM.parquet
├── statik_db/
│   └── statik_bilgiler_YYMM.txt
├── eus_hedef_muta/
│   └── eus_hedef_MUTA_YYMM.csv
├── eus_sql_kapsam_muta/
│   └── eus_kapsam_MUTA_YYMM.csv
└── yis_train_data/
    └── yis_21_v21_YYMM.parquet
```

### Encoding/format kuralları:
- KIK CSV: `cp1254`, semicolon-delimited, risk format: "1.234.567,89" (Turkish number)
- Statik TXT: `cp1254`, semicolon-delimited
- YIS/EUS CSV: `utf-8`, comma-delimited
- Risk Parquet: standart pyarrow parquet
- EUS hedef/kapsam CSV: `utf-8`, tek MUTA kolonu

---

## Pipeline Girdi Formatları (referans)

### 1. KIK İzleme CSV (cp1254, semicolon-delimited)
- Dosya adı: `Izleme Kriterleri Kurumsal 20YYMM02.csv`
- Kolonlar: `Must No` (8-digit str), `Must Ad` (str), `Risk Bky Tl` (Turkish number), `Ykn Izl Flag` ("0"/"1"), `Rtng Kod` (rating str), `Rating Tar` (date str)

### 2. YIS Tahmin CSV
- Dosya adı: `YYYY_MM_DD_pred_n_scor.csv`
- Kolonlar: `MUTA` (str), `yis_skor` (0-1000), `label` (0/1), `ihtimal` (0-1)

### 3. EUS Tahmin CSV
- Dosya adı: `YYYY_MM_DD_pred_n_scor.csv`
- Kolonlar: `MUTA` (str), `eus_skor` (0-1000), `eus_ihtimal` (0-1), `label` (0/1)

### 4. Kredi Risk Parquet
- Dosya adı: `kurumsal_risk_YYMM.parquet`
- Kolonlar: `MUTA` (str), `Risk_Bky_Tl` (float)

### 5. Statik Bilgiler TXT (cp1254, semicolon)
- Dosya adı: `statik_bilgiler_YYMM.txt`
- 11 kolon: muta, bolge_kodu, bolge_adi, sube_kodu, sube_adi, must_tip_kodu, grup_kodu, grup_tanimi, firma_otorize_kodu, aksiyon_sahibi, kri_bolum

### 6. EUS Hedef/Kapsam CSV
- `eus_hedef_MUTA_YYMM.csv` / `eus_kapsam_MUTA_YYMM.csv` — tek kolon MUTA

### 7. Training Parquet
- `yis_21_v21_YYMM.parquet`
- Kolonlar: MUTA + Sgmnt_Kod_ESKK/KOBI/KUR-TIC/MIKRO (bool one-hot)

---

## EWS Skor Hesaplama Mantığı (önemli)

Pipeline'ın `transform.py` adımı:
1. **YI** (en yüksek öncelik): `yis_label=1 OR ykn_izl_flag=1` → `ews_skor='YI'`
2. **EUS bandı**: `eus_skor IS NOT NULL` → `ews_skor = ROUND(eus_skor/2)` (0-500 arası)
3. **YIS bandı**: EUS yoksa → `ews_skor = ROUND(yis_skor/2) + 500` (500-1000 arası)

Dolayısıyla sentetik data üretirken:
- YIS-band olması istenen firmalar EUS prediction'dan ÇIKARILMALI
- yis_label=1 olan firmalar otomatik YI olur, skor'dan bağımsız
- EUS olan firmada yis_skor da olabilir ama EUS önceliklidir

---

## Kullanım Senaryosu

```
PROD (hedef bilgisayar):
  $ python ews_profile_extract.py --db db/ews.duckdb --output ews_data_profile.json
  → JSON dosyasını USB/email ile dev'e taşı

DEV (geliştirme bilgisayarı):
  $ python ews_synth_generate.py --profile ews_data_profile.json --output external_data/
  → Pipeline'a beslenebilir sentetik data hazır
  $ ews-scoreboard run
```
