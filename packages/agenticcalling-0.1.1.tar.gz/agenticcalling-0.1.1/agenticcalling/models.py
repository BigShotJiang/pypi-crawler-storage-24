"""Response models for the SDK."""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any


@dataclass
class CallResponse:
    call_id: str
    status: str
    to: str
    objective: str
    created_at: str
    # Optional fields
    from_number: str | None = None
    context: str | None = None
    playbook_id: str | None = None
    persona_id: str | None = None
    batch_id: str | None = None
    attempt_number: int = 0
    max_attempts: int = 3
    duration_seconds: int | None = None
    cost: float | None = None
    structured_data: dict[str, Any] | None = None
    summary: str | None = None
    transcript_url: str | None = None
    recording_url: str | None = None
    failure_reason: str | None = None
    error_code: str | None = None
    connected_at: str | None = None
    ended_at: str | None = None

    @classmethod
    def from_dict(cls, data: dict) -> "CallResponse":
        return cls(
            call_id=data.get("call_id") or data.get("id", ""),
            status=data["status"],
            to=data.get("to") or data.get("to_number", ""),
            objective=data.get("objective", ""),
            created_at=data.get("created_at", ""),
            from_number=data.get("from") or data.get("from_line_id"),
            context=data.get("context"),
            playbook_id=data.get("playbook_id"),
            persona_id=data.get("persona_id"),
            batch_id=data.get("batch_id"),
            attempt_number=data.get("attempt_number", 0),
            max_attempts=data.get("max_attempts", 3),
            duration_seconds=data.get("duration_seconds"),
            cost=data.get("cost"),
            structured_data=data.get("structured_data"),
            summary=data.get("summary"),
            transcript_url=data.get("transcript_url"),
            recording_url=data.get("recording_url"),
            failure_reason=data.get("failure_reason"),
            error_code=data.get("error_code"),
            connected_at=data.get("connected_at"),
            ended_at=data.get("ended_at"),
        )


@dataclass
class BatchCallResponse:
    batch_id: str
    status: str
    total: int
    completed: int = 0
    failed: int = 0
    in_progress: int = 0
    calls: list[CallResponse] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict) -> "BatchCallResponse":
        calls = [CallResponse.from_dict(c) for c in data.get("calls", [])]
        return cls(
            batch_id=data["batch_id"],
            status=data["status"],
            total=data["total"],
            completed=data.get("completed", 0),
            failed=data.get("failed", 0),
            in_progress=data.get("in_progress", 0),
            calls=calls,
        )


@dataclass
class TranscriptTurn:
    speaker: str  # "agent" or "human"
    text: str
    timestamp: str | None = None


@dataclass
class TranscriptResponse:
    call_id: str
    turns: list[TranscriptTurn]
    structured_data: dict[str, Any] | None = None
    summary: str | None = None

    @classmethod
    def from_dict(cls, data: dict) -> "TranscriptResponse":
        turns = [
            TranscriptTurn(
                speaker=t["speaker"],
                text=t["text"],
                timestamp=t.get("timestamp"),
            )
            for t in data.get("turns", [])
        ]
        return cls(
            call_id=data["call_id"],
            turns=turns,
            structured_data=data.get("structured_data"),
            summary=data.get("summary"),
        )


@dataclass
class PhoneLineResponse:
    line_id: str
    phone_number: str
    country: str
    display_name: str | None = None
    sms_enabled: bool = True
    is_active: bool = True
    created_at: str | None = None

    @classmethod
    def from_dict(cls, data: dict) -> "PhoneLineResponse":
        return cls(
            line_id=data["line_id"],
            phone_number=data["phone_number"],
            country=data["country"],
            display_name=data.get("display_name"),
            sms_enabled=data.get("sms_enabled", True),
            is_active=data.get("is_active", True),
            created_at=data.get("created_at"),
        )


@dataclass
class PlaybookResponse:
    playbook_id: str
    name: str
    tier: str
    playbook_type: str
    strategy: str
    created_at: str | None = None

    @classmethod
    def from_dict(cls, data: dict) -> "PlaybookResponse":
        return cls(
            playbook_id=data["playbook_id"],
            name=data["name"],
            tier=data["tier"],
            playbook_type=data["playbook_type"],
            strategy=data["strategy"],
            created_at=data.get("created_at"),
        )


@dataclass
class SMSResponse:
    sms_id: str
    status: str
    to: str
    cost: float | None = None

    @classmethod
    def from_dict(cls, data: dict) -> "SMSResponse":
        return cls(
            sms_id=data["sms_id"],
            status=data["status"],
            to=data["to"],
            cost=data.get("cost"),
        )


@dataclass
class UsageResponse:
    plan: str
    minutes_used: float
    minutes_limit: float | None
    minutes_remaining: float | None
    sms_sent: int
    sms_limit: int | None
    resets_at: str

    @classmethod
    def from_dict(cls, data: dict) -> "UsageResponse":
        return cls(
            plan=data["plan"],
            minutes_used=data.get("minutes_used") or data.get("minutes_used_this_month", 0),
            minutes_limit=data.get("minutes_limit"),
            minutes_remaining=data.get("minutes_remaining"),
            sms_sent=data.get("sms_sent") or data.get("sms_sent_this_month", 0),
            sms_limit=data.get("sms_limit"),
            resets_at=data.get("resets_at") or data.get("billing_reset_at", ""),
        )


@dataclass
class ListResponse:
    """Generic paginated list response."""

    data: list
    count: int
    next_page_token: str | None = None
