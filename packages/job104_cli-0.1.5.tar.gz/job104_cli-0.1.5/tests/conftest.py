"""Shared test fixtures for job104 CLI tests."""

from __future__ import annotations

import pytest
from click.testing import CliRunner


@pytest.fixture
def runner() -> CliRunner:
    """Click CLI test runner."""
    return CliRunner()


SAMPLE_SEARCH_RESPONSE = {
    "data": [
        {
            "jobNo": 15077397,
            "jobName": "Python 後端工程師",
            "link": {"job": "https://www.104.com.tw/job/abc123", "cust": "https://www.104.com.tw/company/xyz789"},
            "custNo": "xyz789",
            "custName": "範例科技股份有限公司",
            "coIndustryDesc": "軟體及網路相關業",
            "salaryLow": 50000,
            "salaryHigh": 70000,
            "jobAddrNoDesc": "台北市信義區",
            "appearDate": "2026/03/14",
            "optionEdu": [4, 5],
            "optionExp": "3年以上",
            "tags": {"skill1": {"desc": "Python"}, "skill2": {"desc": "Django"}, "skill3": {"desc": "PostgreSQL"}},
            "applyCnt": 15,
            "remoteWorkType": 0,
        },
        {
            "jobNo": 15077398,
            "jobName": "全端工程師",
            "link": {"job": "https://www.104.com.tw/job/def456"},
            "custName": "測試公司",
            "salaryLow": 60000,
            "salaryHigh": 90000,
            "jobAddrNoDesc": "台北市中山區",
            "optionEdu": [4],
            "optionExp": "5年以上",
            "tags": {"skill1": {"desc": "React"}, "skill2": {"desc": "Node.js"}},
        },
    ],
    "metadata": {
        "pagination": {"total": 150, "lastPage": 8, "currentPage": 1, "count": 20},
    },
}

SAMPLE_DETAIL_RESPONSE = {
    "data": {
        "header": {
            "jobName": "Python 後端工程師",
            "custName": "範例科技股份有限公司",
            "salaryDesc": "月薪 50,000~70,000元",
            "coIndustryDesc": "軟體及網路相關業",
        },
        "jobDetail": {
            "jobDescription": "我們正在尋找有經驗的 Python 後端工程師...",
            "jobCategory": [{"code": "2007001004", "desc": "軟體設計工程師"}],
            "addressRegion": "台北市",
            "addressDetail": "信義區信義路五段7號",
        },
        "condition": {
            "workExp": "3年以上",
            "edu": "大學",
            "specialty": [{"code": "1", "desc": "Python"}, {"code": "2", "desc": "Django"}],
        },
        "welfare": {"welfare": "三節獎金、年終獎金、員工旅遊"},
    },
}
