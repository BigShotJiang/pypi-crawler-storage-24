"""Scenario tests — simulate users from multiple domains/professions using job104 CLI.

Each test class represents a persona (nurse, teacher, data scientist, finance pro,
scholar, mechanical engineer, etc.) using the CLI to search for jobs in their field.

All tests use mocked HTTP responses so they run offline and fast.
"""

from __future__ import annotations

import json
from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner

from job104_cli.cli import cli
from job104_cli.client import Job104Client, resolve_area
from job104_cli.constants import AREA_CODES, EDU_CODES, EXP_CODES, INDCAT_CODES, JOBCAT_CODES
from job104_cli.models import Job


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _mock_search_response(jobs: list[dict], total: int = 0, page: int = 1) -> MagicMock:
    """Build a mock httpx.Response for a search API call."""
    total = total or len(jobs)
    last_page = max(1, (total + 19) // 20)
    body = {
        "data": jobs,
        "metadata": {
            "pagination": {"total": total, "lastPage": last_page, "currentPage": page, "count": len(jobs)},
        },
    }
    resp = MagicMock()
    resp.status_code = 200
    resp.text = json.dumps(body)
    resp.json.return_value = body
    resp.cookies = {}
    return resp


def _mock_detail_response(detail: dict) -> MagicMock:
    """Build a mock httpx.Response for a job detail API call."""
    body = {"data": detail}
    resp = MagicMock()
    resp.status_code = 200
    resp.text = json.dumps(body)
    resp.json.return_value = body
    resp.cookies = {}
    return resp


def _patch_client():
    """Context-manager that patches Job104Client to return a controllable mock."""
    return patch.object(Job104Client, "_build_client")


def _setup_mock(mock_build, response):
    """Wire a mock_build to return `response` for both .request() and .get()."""
    mock_http = MagicMock()
    mock_http.request.return_value = response
    mock_http.get.return_value = response  # CF warmup
    mock_http.cookies = MagicMock()
    mock_build.return_value = mock_http
    return mock_http


# ---------------------------------------------------------------------------
# Sample job factories for each domain
# ---------------------------------------------------------------------------


def _nurse_job(idx: int = 1) -> dict:
    return {
        "jobNo": 20000000 + idx,
        "jobName": "護理師" if idx % 2 else "急診護理師",
        "link": {"job": f"https://www.104.com.tw/job/nurse{idx:03d}"},
        "custName": f"台大醫院附設{idx}病房",
        "coIndustryDesc": "醫療服務業",
        "salaryLow": 38000,
        "salaryHigh": 55000,
        "jobAddrNoDesc": "台北市中正區",
        "optionEdu": [3, 4],
        "optionExp": "1年以上",
        "tags": {"s1": {"desc": "護理"}, "s2": {"desc": "急救"}},
        "applyCnt": 5,
    }


def _teacher_job(idx: int = 1) -> dict:
    return {
        "jobNo": 21000000 + idx,
        "jobName": "國小教師" if idx % 2 else "英文老師",
        "link": {"job": f"https://www.104.com.tw/job/teach{idx:03d}"},
        "custName": f"台北市立{idx}國小",
        "coIndustryDesc": "教育服務業",
        "salaryLow": 45000,
        "salaryHigh": 70000,
        "jobAddrNoDesc": "台北市大安區",
        "optionEdu": [4, 5],
        "optionExp": "不限",
        "tags": {"s1": {"desc": "教學"}, "s2": {"desc": "班級經營"}},
    }


def _data_scientist_job(idx: int = 1) -> dict:
    return {
        "jobNo": 22000000 + idx,
        "jobName": "資料科學家" if idx % 2 else "機器學習工程師",
        "link": {"job": f"https://www.104.com.tw/job/ds{idx:03d}"},
        "custName": "台灣大哥大" if idx % 2 else "Google_美商科高國際有限公司",
        "coIndustryDesc": "軟體及網路相關業",
        "salaryLow": 70000,
        "salaryHigh": 150000,
        "jobAddrNoDesc": "台北市信義區",
        "optionEdu": [5, 6],
        "optionExp": "3年以上",
        "tags": {"s1": {"desc": "Python"}, "s2": {"desc": "Machine Learning"}, "s3": {"desc": "SQL"}},
    }


def _finance_job(idx: int = 1) -> dict:
    return {
        "jobNo": 23000000 + idx,
        "jobName": "財務分析師" if idx % 2 else "會計師",
        "link": {"job": f"https://www.104.com.tw/job/fin{idx:03d}"},
        "custName": "勤業眾信聯合會計師事務所" if idx % 2 else "台北富邦銀行",
        "coIndustryDesc": "金融機構及其相關業",
        "salaryLow": 55000,
        "salaryHigh": 100000,
        "jobAddrNoDesc": "台北市松山區",
        "optionEdu": [4, 5],
        "optionExp": "3-5年",
        "tags": {"s1": {"desc": "財務報表"}, "s2": {"desc": "Excel"}, "s3": {"desc": "ERP"}},
    }


def _scholar_job(idx: int = 1) -> dict:
    return {
        "jobNo": 24000000 + idx,
        "jobName": "助理教授" if idx % 2 else "博士後研究員",
        "link": {"job": f"https://www.104.com.tw/job/acad{idx:03d}"},
        "custName": "國立台灣大學" if idx % 2 else "中央研究院",
        "coIndustryDesc": "教育服務業",
        "salaryLow": 75000,
        "salaryHigh": 110000,
        "jobAddrNoDesc": "台北市大安區",
        "optionEdu": [6],
        "optionExp": "不限",
        "tags": {"s1": {"desc": "研究"}, "s2": {"desc": "論文撰寫"}},
    }


def _mech_engineer_job(idx: int = 1) -> dict:
    return {
        "jobNo": 25000000 + idx,
        "jobName": "機械工程師" if idx % 2 else "機構工程師",
        "link": {"job": f"https://www.104.com.tw/job/mech{idx:03d}"},
        "custName": "台積電" if idx % 2 else "鴻海精密",
        "coIndustryDesc": "半導體業",
        "salaryLow": 55000,
        "salaryHigh": 90000,
        "jobAddrNoDesc": "新竹市",
        "optionEdu": [4, 5],
        "optionExp": "3-5年",
        "tags": {"s1": {"desc": "AutoCAD"}, "s2": {"desc": "SolidWorks"}},
    }


def _chef_job(idx: int = 1) -> dict:
    return {
        "jobNo": 26000000 + idx,
        "jobName": "西餐廚師" if idx % 2 else "主廚",
        "link": {"job": f"https://www.104.com.tw/job/chef{idx:03d}"},
        "custName": "晶華酒店" if idx % 2 else "鼎泰豐",
        "coIndustryDesc": "餐飲業",
        "salaryLow": 35000,
        "salaryHigh": 65000,
        "jobAddrNoDesc": "台北市中山區",
        "optionEdu": [1, 2],
        "optionExp": "3年以上",
        "tags": {"s1": {"desc": "烹飪"}, "s2": {"desc": "食品安全"}},
    }


def _designer_job(idx: int = 1) -> dict:
    return {
        "jobNo": 27000000 + idx,
        "jobName": "UI設計師" if idx % 2 else "UX設計師",
        "link": {"job": f"https://www.104.com.tw/job/design{idx:03d}"},
        "custName": "LINE Taiwan" if idx % 2 else "趨勢科技",
        "coIndustryDesc": "軟體及網路相關業",
        "salaryLow": 50000,
        "salaryHigh": 85000,
        "jobAddrNoDesc": "台北市內湖區",
        "optionEdu": [4],
        "optionExp": "3年以上",
        "tags": {"s1": {"desc": "Figma"}, "s2": {"desc": "Adobe XD"}, "s3": {"desc": "設計思考"}},
    }


def _lawyer_job(idx: int = 1) -> dict:
    return {
        "jobNo": 28000000 + idx,
        "jobName": "律師" if idx % 2 else "法務人員",
        "link": {"job": f"https://www.104.com.tw/job/law{idx:03d}"},
        "custName": "理律法律事務所" if idx % 2 else "國際通商法律事務所",
        "coIndustryDesc": "法律服務業",
        "salaryLow": 60000,
        "salaryHigh": 120000,
        "jobAddrNoDesc": "台北市大安區",
        "optionEdu": [5],
        "optionExp": "1-3年",
        "tags": {"s1": {"desc": "公司法"}, "s2": {"desc": "合約審閱"}},
    }


def _remote_dev_job(idx: int = 1) -> dict:
    return {
        "jobNo": 29000000 + idx,
        "jobName": "全端工程師 (Remote)" if idx % 2 else "後端工程師 (WFH)",
        "link": {"job": f"https://www.104.com.tw/job/remote{idx:03d}"},
        "custName": "Appier" if idx % 2 else "PicCollage",
        "coIndustryDesc": "軟體及網路相關業",
        "salaryLow": 80000,
        "salaryHigh": 160000,
        "jobAddrNoDesc": "台北市信義區",
        "optionEdu": [4, 5],
        "optionExp": "5年以上",
        "tags": {"s1": {"desc": "Python"}, "s2": {"desc": "Kubernetes"}, "s3": {"desc": "AWS"}},
        "remoteWorkType": 1,
    }


# ===========================================================================
# SCENARIO 1: Nurse searching for healthcare jobs
# ===========================================================================


class TestNurseScenario:
    """A nurse in Taipei searching for nursing positions in hospitals."""

    @pytest.fixture
    def runner(self) -> CliRunner:
        return CliRunner()

    def test_search_nurse_keyword(self, runner: CliRunner) -> None:
        """Search for '護理師' with JSON output."""
        jobs = [_nurse_job(i) for i in range(1, 4)]
        resp = _mock_search_response(jobs, total=85)

        with _patch_client() as mock_build:
            _setup_mock(mock_build, resp)
            result = runner.invoke(cli, ["search", "護理師", "--json"])

        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["ok"] is True
        assert len(data["data"]["list"]) == 3

    def test_search_nurse_with_area_and_indcat(self, runner: CliRunner) -> None:
        """Nurse filters by area=台北市 and indcat=醫療服務業."""
        jobs = [_nurse_job(1)]
        resp = _mock_search_response(jobs, total=42)

        with _patch_client() as mock_build:
            _setup_mock(mock_build, resp)
            result = runner.invoke(
                cli,
                [
                    "search",
                    "護理師",
                    "--area",
                    "台北市",
                    "--indcat",
                    "醫療服務業",
                    "--json",
                ],
            )

        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["ok"] is True

    def test_nurse_jobcat_code_resolution(self) -> None:
        """Verify '護理師及護士' resolves to a valid jobcat code."""
        assert "護理師及護士" in JOBCAT_CODES
        assert JOBCAT_CODES["護理師及護士"] == "2015001004"

    def test_nurse_indcat_resolution(self) -> None:
        """Verify '醫療服務業' resolves to a valid indcat code."""
        assert "醫療服務業" in INDCAT_CODES
        assert INDCAT_CODES["醫療服務業"] == "1012001000"

    def test_nurse_job_model(self) -> None:
        """Nurse job normalizes correctly through the Job model."""
        job = Job.from_search_result(_nurse_job(1))
        assert job.job_name == "護理師"
        assert job.industry == "醫療服務業"
        assert job.edu_desc == "專科/大學"
        assert "護理" in job.tags


# ===========================================================================
# SCENARIO 2: Teacher searching for education jobs
# ===========================================================================


class TestTeacherScenario:
    """A teacher looking for positions in education sector."""

    @pytest.fixture
    def runner(self) -> CliRunner:
        return CliRunner()

    def test_search_teacher_keyword(self, runner: CliRunner) -> None:
        jobs = [_teacher_job(i) for i in range(1, 3)]
        resp = _mock_search_response(jobs, total=200)

        with _patch_client() as mock_build:
            _setup_mock(mock_build, resp)
            result = runner.invoke(cli, ["search", "教師", "--json"])

        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["ok"] is True

    def test_search_teacher_with_edu_filter(self, runner: CliRunner) -> None:
        """Teacher requires master's degree positions only."""
        jobs = [_teacher_job(1)]
        resp = _mock_search_response(jobs, total=30)

        with _patch_client() as mock_build:
            _setup_mock(mock_build, resp)
            result = runner.invoke(
                cli,
                [
                    "search",
                    "教師",
                    "--edu",
                    "碩士",
                    "--indcat",
                    "教育服務業",
                    "--json",
                ],
            )

        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["ok"] is True

    def test_teacher_jobcat_resolution(self) -> None:
        assert "英文老師" in JOBCAT_CODES
        assert "教授／副教授／助理教授" in JOBCAT_CODES
        assert "補習班導師／管理人員" in JOBCAT_CODES

    def test_teacher_indcat_resolution(self) -> None:
        assert "教育服務業" in INDCAT_CODES
        assert INDCAT_CODES["教育服務業"] == "1005001000"

    def test_teacher_job_model(self) -> None:
        job = Job.from_search_result(_teacher_job(1))
        assert "教師" in job.job_name or "老師" in job.job_name
        assert job.industry == "教育服務業"


# ===========================================================================
# SCENARIO 3: Data Scientist / ML Engineer
# ===========================================================================


class TestDataScientistScenario:
    """A data scientist looking for AI/ML roles at tech companies."""

    @pytest.fixture
    def runner(self) -> CliRunner:
        return CliRunner()

    def test_search_ai_engineer(self, runner: CliRunner) -> None:
        jobs = [_data_scientist_job(i) for i in range(1, 5)]
        resp = _mock_search_response(jobs, total=120)

        with _patch_client() as mock_build:
            _setup_mock(mock_build, resp)
            result = runner.invoke(cli, ["search", "AI工程師", "--json"])

        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["ok"] is True
        assert len(data["data"]["list"]) == 4

    def test_search_ds_with_salary_filter(self, runner: CliRunner) -> None:
        """Data scientist filtering for monthly salary > 80K."""
        jobs = [_data_scientist_job(1)]
        resp = _mock_search_response(jobs, total=50)

        with _patch_client() as mock_build:
            _setup_mock(mock_build, resp)
            result = runner.invoke(
                cli,
                [
                    "search",
                    "資料科學家",
                    "--salary-type",
                    "月薪",
                    "--salary-low",
                    "80000",
                    "--edu",
                    "碩士",
                    "--json",
                ],
            )

        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["ok"] is True

    def test_search_ds_with_jobcat(self, runner: CliRunner) -> None:
        """Search using the jobcat filter for data scientist title."""
        jobs = [_data_scientist_job(1)]
        resp = _mock_search_response(jobs, total=30)

        with _patch_client() as mock_build:
            _setup_mock(mock_build, resp)
            result = runner.invoke(
                cli,
                [
                    "search",
                    "Python",
                    "--jobcat",
                    "資料科學家",
                    "--json",
                ],
            )

        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["ok"] is True

    def test_ds_jobcat_codes(self) -> None:
        assert "資料科學家" in JOBCAT_CODES
        assert "機器學習工程師" in JOBCAT_CODES
        assert "AI工程師" in JOBCAT_CODES
        assert "數據分析師" in JOBCAT_CODES

    def test_ds_job_model_high_salary(self) -> None:
        job = Job.from_search_result(_data_scientist_job(1))
        assert job.salary_low >= 70000
        assert "Python" in job.tags
        assert job.edu_desc == "碩士/博士"


# ===========================================================================
# SCENARIO 4: Finance professional
# ===========================================================================


class TestFinanceScenario:
    """A finance professional (accountant, financial analyst) searching for jobs."""

    @pytest.fixture
    def runner(self) -> CliRunner:
        return CliRunner()

    def test_search_accountant(self, runner: CliRunner) -> None:
        jobs = [_finance_job(i) for i in range(1, 3)]
        resp = _mock_search_response(jobs, total=90)

        with _patch_client() as mock_build:
            _setup_mock(mock_build, resp)
            result = runner.invoke(cli, ["search", "會計師", "--json"])

        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["ok"] is True

    def test_search_finance_with_indcat_and_exp(self, runner: CliRunner) -> None:
        """Finance professional filtering by industry and experience."""
        jobs = [_finance_job(1)]
        resp = _mock_search_response(jobs, total=25)

        with _patch_client() as mock_build:
            _setup_mock(mock_build, resp)
            result = runner.invoke(
                cli,
                [
                    "search",
                    "財務分析師",
                    "--indcat",
                    "金融機構及其相關業",
                    "--exp",
                    "3-5年",
                    "--json",
                ],
            )

        assert result.exit_code == 0

    def test_finance_jobcat_codes(self) -> None:
        assert "會計師" in JOBCAT_CODES
        assert "財務分析／財務人員" in JOBCAT_CODES
        assert "稽核人員" in JOBCAT_CODES

    def test_finance_indcat_codes(self) -> None:
        assert "金融機構及其相關業" in INDCAT_CODES
        assert "銀行業" in INDCAT_CODES
        assert "保險業" in INDCAT_CODES

    def test_finance_job_model(self) -> None:
        job = Job.from_search_result(_finance_job(1))
        assert "財務" in job.job_name or "會計" in job.job_name
        assert job.salary_low >= 55000


# ===========================================================================
# SCENARIO 5: Scholar / Academic researcher
# ===========================================================================


class TestScholarScenario:
    """A PhD scholar looking for academic positions (professor, postdoc)."""

    @pytest.fixture
    def runner(self) -> CliRunner:
        return CliRunner()

    def test_search_professor(self, runner: CliRunner) -> None:
        jobs = [_scholar_job(i) for i in range(1, 3)]
        resp = _mock_search_response(jobs, total=15)

        with _patch_client() as mock_build:
            _setup_mock(mock_build, resp)
            result = runner.invoke(cli, ["search", "助理教授", "--edu", "博士", "--json"])

        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["ok"] is True

    def test_search_postdoc_with_indcat(self, runner: CliRunner) -> None:
        """Scholar searches for postdoc in education industry."""
        jobs = [_scholar_job(2)]
        resp = _mock_search_response(jobs, total=10)

        with _patch_client() as mock_build:
            _setup_mock(mock_build, resp)
            result = runner.invoke(
                cli,
                [
                    "search",
                    "博士後研究",
                    "--indcat",
                    "教育服務業",
                    "--edu",
                    "博士",
                    "--json",
                ],
            )

        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["ok"] is True

    def test_search_scholar_in_specific_area(self, runner: CliRunner) -> None:
        """Scholar looks for positions at specific locations."""
        jobs = [_scholar_job(1)]
        resp = _mock_search_response(jobs, total=5)

        with _patch_client() as mock_build:
            _setup_mock(mock_build, resp)
            result = runner.invoke(
                cli,
                [
                    "search",
                    "研究員",
                    "--area",
                    "台北市",
                    "--edu",
                    "博士",
                    "--json",
                ],
            )

        assert result.exit_code == 0

    def test_scholar_jobcat_resolution(self) -> None:
        assert "教授／副教授／助理教授" in JOBCAT_CODES
        assert "學術研究類人員" in JOBCAT_CODES

    def test_scholar_edu_code_phd(self) -> None:
        """PhD filter resolves correctly."""
        assert EDU_CODES["博士"] == "6"

    def test_scholar_job_model(self) -> None:
        job = Job.from_search_result(_scholar_job(1))
        assert "教授" in job.job_name or "研究" in job.job_name
        assert job.edu_desc == "博士"
        assert job.option_edu == [6]


# ===========================================================================
# SCENARIO 6: Mechanical engineer in semiconductor
# ===========================================================================


class TestMechEngineerScenario:
    """A mechanical / structural engineer looking for jobs in semiconductor."""

    @pytest.fixture
    def runner(self) -> CliRunner:
        return CliRunner()

    def test_search_mech_engineer(self, runner: CliRunner) -> None:
        jobs = [_mech_engineer_job(i) for i in range(1, 4)]
        resp = _mock_search_response(jobs, total=200)

        with _patch_client() as mock_build:
            _setup_mock(mock_build, resp)
            result = runner.invoke(cli, ["search", "機械工程師", "--area", "新竹市", "--json"])

        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["ok"] is True

    def test_search_mech_with_indcat_semiconductor(self, runner: CliRunner) -> None:
        """Mech engineer filtering by semiconductor industry."""
        jobs = [_mech_engineer_job(1)]
        resp = _mock_search_response(jobs, total=50)

        with _patch_client() as mock_build:
            _setup_mock(mock_build, resp)
            result = runner.invoke(
                cli,
                [
                    "search",
                    "機構工程師",
                    "--indcat",
                    "半導體業",
                    "--area",
                    "新竹市",
                    "--exp",
                    "3-5年",
                    "--json",
                ],
            )

        assert result.exit_code == 0

    def test_mech_jobcat_codes(self) -> None:
        assert "機械工程師" in JOBCAT_CODES
        assert "機構工程師" in JOBCAT_CODES
        assert "半導體工程師" in JOBCAT_CODES

    def test_mech_area_hsinchu(self) -> None:
        assert "新竹市" in AREA_CODES
        assert resolve_area("新竹市") == "6001006000"

    def test_mech_job_model(self) -> None:
        job = Job.from_search_result(_mech_engineer_job(1))
        assert "機械" in job.job_name or "機構" in job.job_name
        assert job.location == "新竹市"
        assert "AutoCAD" in job.tags


# ===========================================================================
# SCENARIO 7: Chef / Restaurant worker
# ===========================================================================


class TestChefScenario:
    """A chef looking for culinary positions in restaurants and hotels."""

    @pytest.fixture
    def runner(self) -> CliRunner:
        return CliRunner()

    def test_search_chef(self, runner: CliRunner) -> None:
        jobs = [_chef_job(i) for i in range(1, 3)]
        resp = _mock_search_response(jobs, total=60)

        with _patch_client() as mock_build:
            _setup_mock(mock_build, resp)
            result = runner.invoke(cli, ["search", "廚師", "--json"])

        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["ok"] is True

    def test_search_chef_with_indcat(self, runner: CliRunner) -> None:
        """Chef filtering by restaurant industry."""
        jobs = [_chef_job(1)]
        resp = _mock_search_response(jobs, total=30)

        with _patch_client() as mock_build:
            _setup_mock(mock_build, resp)
            result = runner.invoke(
                cli,
                [
                    "search",
                    "主廚",
                    "--indcat",
                    "餐飲業",
                    "--area",
                    "台北市",
                    "--json",
                ],
            )

        assert result.exit_code == 0

    def test_chef_jobcat_codes(self) -> None:
        assert "西餐廚師" in JOBCAT_CODES
        assert "中餐廚師" in JOBCAT_CODES
        assert "咖啡師" in JOBCAT_CODES

    def test_chef_indcat_codes(self) -> None:
        assert "餐飲業" in INDCAT_CODES
        assert "餐館業" in INDCAT_CODES

    def test_chef_edu_low(self) -> None:
        """Chef jobs often accept lower education levels."""
        job = Job.from_search_result(_chef_job(1))
        assert job.edu_desc == "高中以下/高中職"


# ===========================================================================
# SCENARIO 8: UI/UX Designer
# ===========================================================================


class TestDesignerScenario:
    """A designer searching for UI/UX positions at tech companies."""

    @pytest.fixture
    def runner(self) -> CliRunner:
        return CliRunner()

    def test_search_ui_designer(self, runner: CliRunner) -> None:
        jobs = [_designer_job(i) for i in range(1, 3)]
        resp = _mock_search_response(jobs, total=75)

        with _patch_client() as mock_build:
            _setup_mock(mock_build, resp)
            result = runner.invoke(cli, ["search", "UI設計師", "--json"])

        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["ok"] is True

    def test_designer_jobcat_codes(self) -> None:
        assert "UI設計師" in JOBCAT_CODES
        assert "UX設計師" in JOBCAT_CODES
        assert "視覺設計師" in JOBCAT_CODES
        assert "網頁設計師" in JOBCAT_CODES

    def test_designer_job_model(self) -> None:
        job = Job.from_search_result(_designer_job(1))
        assert "設計師" in job.job_name
        assert "Figma" in job.tags


# ===========================================================================
# SCENARIO 9: Lawyer / Legal professional
# ===========================================================================


class TestLawyerScenario:
    """A lawyer searching for legal positions."""

    @pytest.fixture
    def runner(self) -> CliRunner:
        return CliRunner()

    def test_search_lawyer(self, runner: CliRunner) -> None:
        jobs = [_lawyer_job(i) for i in range(1, 3)]
        resp = _mock_search_response(jobs, total=40)

        with _patch_client() as mock_build:
            _setup_mock(mock_build, resp)
            result = runner.invoke(cli, ["search", "律師", "--json"])

        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["ok"] is True

    def test_search_lawyer_with_indcat(self, runner: CliRunner) -> None:
        jobs = [_lawyer_job(1)]
        resp = _mock_search_response(jobs, total=15)

        with _patch_client() as mock_build:
            _setup_mock(mock_build, resp)
            result = runner.invoke(
                cli,
                [
                    "search",
                    "法務",
                    "--indcat",
                    "法律服務業",
                    "--json",
                ],
            )

        assert result.exit_code == 0

    def test_lawyer_jobcat_codes(self) -> None:
        assert "律師" in JOBCAT_CODES
        assert "法務" in JOBCAT_CODES
        assert "法遵人員" in JOBCAT_CODES

    def test_lawyer_indcat_codes(self) -> None:
        assert "法律服務業" in INDCAT_CODES

    def test_lawyer_job_model(self) -> None:
        job = Job.from_search_result(_lawyer_job(1))
        assert "律師" in job.job_name or "法務" in job.job_name
        assert "公司法" in job.tags or "合約審閱" in job.tags


# ===========================================================================
# SCENARIO 10: Remote-first developer (cross-domain filter test)
# ===========================================================================


class TestRemoteDeveloperScenario:
    """A developer specifically looking for remote work opportunities."""

    @pytest.fixture
    def runner(self) -> CliRunner:
        return CliRunner()

    def test_search_remote_full(self, runner: CliRunner) -> None:
        """Search with remote=完全遠端 filter."""
        jobs = [_remote_dev_job(i) for i in range(1, 3)]
        resp = _mock_search_response(jobs, total=35)

        with _patch_client() as mock_build:
            _setup_mock(mock_build, resp)
            result = runner.invoke(
                cli,
                [
                    "search",
                    "工程師",
                    "--remote",
                    "完全遠端",
                    "--json",
                ],
            )

        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["ok"] is True

    def test_search_remote_with_salary_and_exp(self, runner: CliRunner) -> None:
        """Remote developer filtering by salary, experience, and remote."""
        jobs = [_remote_dev_job(1)]
        resp = _mock_search_response(jobs, total=10)

        with _patch_client() as mock_build:
            _setup_mock(mock_build, resp)
            result = runner.invoke(
                cli,
                [
                    "search",
                    "後端工程師",
                    "--remote",
                    "完全遠端",
                    "--exp",
                    "5-10年",
                    "--salary-type",
                    "月薪",
                    "--salary-low",
                    "100000",
                    "--json",
                ],
            )

        assert result.exit_code == 0

    def test_search_remote_at_foreign_company(self, runner: CliRunner) -> None:
        """Remote developer at foreign companies."""
        jobs = [_remote_dev_job(1)]
        resp = _mock_search_response(jobs, total=8)

        with _patch_client() as mock_build:
            _setup_mock(mock_build, resp)
            result = runner.invoke(
                cli,
                [
                    "search",
                    "全端工程師",
                    "--remote",
                    "完全遠端",
                    "--company-type",
                    "外商",
                    "--json",
                ],
            )

        assert result.exit_code == 0


# ===========================================================================
# CROSS-DOMAIN: detail, show, and export commands
# ===========================================================================


class TestCrossDomainDetailAndExport:
    """Test detail/show/export work for jobs from different domains."""

    @pytest.fixture
    def runner(self) -> CliRunner:
        return CliRunner()

    def test_detail_nurse_job(self, runner: CliRunner) -> None:
        detail = {
            "header": {"jobName": "護理師", "custName": "台大醫院", "salaryDesc": "月薪 38,000~55,000元", "coIndustryDesc": "醫療服務業"},
            "jobDetail": {
                "jobDescription": "負責病患照護...",
                "jobCategory": [{"code": "2015001004", "desc": "護理師及護士"}],
                "addressRegion": "台北市",
            },
            "condition": {"workExp": "1年以上", "edu": "專科", "specialty": [{"desc": "護理"}]},
            "welfare": {"welfare": "三節獎金、輪班津貼"},
        }
        resp = _mock_detail_response(detail)

        with _patch_client() as mock_build:
            _setup_mock(mock_build, resp)
            result = runner.invoke(cli, ["detail", "nurse001", "--json"])

        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["ok"] is True
        assert data["data"]["header"]["jobName"] == "護理師"

    def test_detail_scholar_job(self, runner: CliRunner) -> None:
        detail = {
            "header": {"jobName": "助理教授", "custName": "國立台灣大學", "salaryDesc": "月薪 75,000~110,000元"},
            "jobDetail": {"jobDescription": "進行學術研究與教學...", "jobCategory": [{"desc": "教授"}], "addressRegion": "台北市"},
            "condition": {"workExp": "不限", "edu": "博士", "specialty": [{"desc": "研究方法"}]},
            "welfare": {"welfare": "學術研究補助"},
        }
        resp = _mock_detail_response(detail)

        with _patch_client() as mock_build:
            _setup_mock(mock_build, resp)
            result = runner.invoke(cli, ["detail", "acad001", "--json"])

        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["data"]["condition"]["edu"] == "博士"

    def test_show_command_with_cached_results(self, runner: CliRunner, tmp_path, monkeypatch) -> None:
        """Simulate: search nurse jobs, then show #1."""
        monkeypatch.setattr("job104_cli.index_cache.CONFIG_DIR", tmp_path)
        monkeypatch.setattr("job104_cli.index_cache.INDEX_CACHE_FILE", tmp_path / "index_cache.json")

        # Populate the cache
        from job104_cli.index_cache import save_index

        jobs = [_nurse_job(1), _nurse_job(2)]
        save_index(jobs, source="test:nurse")

        detail = {
            "header": {"jobName": "護理師", "custName": "台大醫院", "salaryDesc": "月薪 38,000~55,000元"},
            "jobDetail": {"jobDescription": "護理工作...", "addressRegion": "台北市"},
            "condition": {"workExp": "1年以上", "edu": "專科"},
            "welfare": {"welfare": ""},
        }
        resp = _mock_detail_response(detail)

        with _patch_client() as mock_build:
            mock_http = _setup_mock(mock_build, resp)
            # show mixes rich summary (stderr) with JSON (stdout); just verify it runs
            result = runner.invoke(cli, ["show", "1"])

        assert result.exit_code == 0
        # Verify the HTTP client was actually called to fetch detail
        assert mock_http.request.called

    def test_export_finance_jobs_csv(self, runner: CliRunner) -> None:
        """Finance professional exports jobs to CSV."""
        jobs = [_finance_job(i) for i in range(1, 4)]
        resp = _mock_search_response(jobs, total=3)

        with _patch_client() as mock_build:
            _setup_mock(mock_build, resp)
            result = runner.invoke(cli, ["export", "會計師", "--format", "csv", "-n", "3"])

        assert result.exit_code == 0
        assert "職缺" in result.output  # CSV header
        assert "財務分析師" in result.output or "會計師" in result.output

    def test_export_data_scientist_jobs_json(self, runner: CliRunner, tmp_path) -> None:
        """Data scientist exports jobs to JSON file."""
        jobs = [_data_scientist_job(i) for i in range(1, 3)]
        resp = _mock_search_response(jobs, total=2)
        out_file = str(tmp_path / "ds_jobs.json")

        with _patch_client() as mock_build:
            _setup_mock(mock_build, resp)
            result = runner.invoke(cli, ["export", "資料科學家", "--format", "json", "-n", "2", "-o", out_file])

        assert result.exit_code == 0
        data = json.loads(open(out_file, encoding="utf-8").read())
        assert isinstance(data, list)
        assert len(data) == 2


# ===========================================================================
# CROSS-DOMAIN: Verify filter combinations work together
# ===========================================================================


class TestFilterCombinations:
    """Test that multiple filters (area + edu + exp + indcat + jobcat + salary + remote) combine correctly."""

    @pytest.fixture
    def runner(self) -> CliRunner:
        return CliRunner()

    @pytest.mark.parametrize(
        "keyword,area,edu,exp,indcat,jobcat",
        [
            ("護理師", "台北市", "專科", "1年以下", "醫療服務業", None),
            ("軟體工程師", "新竹市", "碩士", "3-5年", "半導體業", "軟體工程師"),
            ("會計師", "台北市", "大學", "3-5年", "金融機構及其相關業", None),
            ("教師", "台中市", "碩士", "不限", "教育服務業", None),
            ("機械工程師", "新竹市", "大學", "3-5年", "半導體業", "機械工程師"),
            ("律師", "台北市", "碩士", "1-3年", "法律服務業", "律師"),
            ("廚師", "高雄市", "高中/高職", "3-5年", "餐飲業", "西餐廚師"),
            ("UI設計師", "台北市", "大學", "3-5年", "軟體及網路相關業", "UI設計師"),
        ],
    )
    def test_multi_filter_search(
        self,
        runner: CliRunner,
        keyword,
        area,
        edu,
        exp,
        indcat,
        jobcat,
    ) -> None:
        resp = _mock_search_response([], total=0)

        args = ["search", keyword, "--area", area, "--edu", edu, "--exp", exp, "--indcat", indcat, "--json"]
        if jobcat:
            args.extend(["--jobcat", jobcat])

        with _patch_client() as mock_build:
            _setup_mock(mock_build, resp)
            result = runner.invoke(cli, args)

        assert result.exit_code == 0, f"Failed for {keyword}: {result.output}"
        data = json.loads(result.output)
        assert data["ok"] is True

    def test_all_edu_levels_are_valid_choices(self) -> None:
        """Every EDU_CODES key can be used as --edu filter."""
        for label in EDU_CODES:
            assert isinstance(EDU_CODES[label], str)

    def test_all_exp_levels_are_valid_choices(self) -> None:
        """Every EXP_CODES key can be used as --exp filter."""
        for label in EXP_CODES:
            assert isinstance(EXP_CODES[label], str)

    def test_all_major_cities_are_resolvable(self) -> None:
        """All major Taiwan cities resolve to valid codes."""
        for city in ["台北市", "新北市", "桃園市", "台中市", "台南市", "高雄市", "新竹市"]:
            code = resolve_area(city)
            assert code, f"Failed to resolve area: {city}"
            assert len(code) == 10


# ===========================================================================
# CROSS-DOMAIN: Rich output (table rendering, no --json)
# ===========================================================================


class TestRichOutput:
    """Verify that table rendering works for all domains without --json."""

    @pytest.fixture
    def runner(self) -> CliRunner:
        return CliRunner()

    @pytest.mark.parametrize(
        "job_factory,keyword",
        [
            (_nurse_job, "護理師"),
            (_teacher_job, "教師"),
            (_data_scientist_job, "AI工程師"),
            (_finance_job, "會計師"),
            (_scholar_job, "助理教授"),
            (_mech_engineer_job, "機械工程師"),
            (_chef_job, "廚師"),
            (_designer_job, "UI設計師"),
            (_lawyer_job, "律師"),
        ],
    )
    def test_rich_table_renders(self, runner: CliRunner, job_factory, keyword) -> None:
        """Each domain's search results render as a table without errors."""
        jobs = [job_factory(i) for i in range(1, 4)]
        resp = _mock_search_response(jobs, total=50)

        with _patch_client() as mock_build:
            _setup_mock(mock_build, resp)
            # Rich table goes to stderr, so we capture mix_stderr=False
            result = runner.invoke(cli, ["search", keyword], catch_exceptions=False)

        assert result.exit_code == 0


# ===========================================================================
# Edge case: job model normalizes all domain-specific data correctly
# ===========================================================================


class TestJobModelCrossDomain:
    """Verify Job.from_search_result handles data from every domain."""

    @pytest.mark.parametrize(
        "factory,expected_tags",
        [
            (_nurse_job, ["護理", "急救"]),
            (_teacher_job, ["教學", "班級經營"]),
            (_data_scientist_job, ["Python", "Machine Learning", "SQL"]),
            (_finance_job, ["財務報表", "Excel", "ERP"]),
            (_scholar_job, ["研究", "論文撰寫"]),
            (_mech_engineer_job, ["AutoCAD", "SolidWorks"]),
            (_chef_job, ["烹飪", "食品安全"]),
            (_designer_job, ["Figma", "Adobe XD", "設計思考"]),
            (_lawyer_job, ["公司法", "合約審閱"]),
            (_remote_dev_job, ["Python", "Kubernetes", "AWS"]),
        ],
    )
    def test_tags_extracted_correctly(self, factory, expected_tags) -> None:
        job = Job.from_search_result(factory(1))
        for tag in expected_tags:
            assert tag in job.tags, f"Missing tag {tag!r} in {job.tags}"

    @pytest.mark.parametrize(
        "factory",
        [
            _nurse_job,
            _teacher_job,
            _data_scientist_job,
            _finance_job,
            _scholar_job,
            _mech_engineer_job,
            _chef_job,
            _designer_job,
            _lawyer_job,
            _remote_dev_job,
        ],
    )
    def test_to_dict_has_required_fields(self, factory) -> None:
        job = Job.from_search_result(factory(1))
        d = job.to_dict()
        for key in ("jobNo", "jobId", "jobName", "salary", "edu", "exp", "location", "tags"):
            assert key in d, f"Missing key {key!r} in to_dict()"

    @pytest.mark.parametrize(
        "factory",
        [
            _nurse_job,
            _teacher_job,
            _data_scientist_job,
            _finance_job,
            _scholar_job,
            _mech_engineer_job,
            _chef_job,
            _designer_job,
            _lawyer_job,
            _remote_dev_job,
        ],
    )
    def test_job_id_extracted_from_link(self, factory) -> None:
        job = Job.from_search_result(factory(1))
        assert job.job_id, f"job_id is empty for {factory.__name__}"

    @pytest.mark.parametrize(
        "factory,expected_edu",
        [
            (_nurse_job, "專科/大學"),
            (_scholar_job, "博士"),
            (_chef_job, "高中以下/高中職"),
            (_data_scientist_job, "碩士/博士"),
        ],
    )
    def test_edu_display_correct(self, factory, expected_edu) -> None:
        job = Job.from_search_result(factory(1))
        assert job.edu_desc == expected_edu
