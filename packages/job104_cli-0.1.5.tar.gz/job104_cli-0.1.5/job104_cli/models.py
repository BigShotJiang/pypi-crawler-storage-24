"""Normalized data models for 104 Job Bank API responses."""

from __future__ import annotations

from dataclasses import dataclass, field

from .constants import EDU_DISPLAY


@dataclass
class Job:
    """Normalized job data — stable interface regardless of API version."""

    job_no: str = ""
    job_id: str = ""
    job_name: str = ""
    job_url: str = ""
    cust_name: str = ""
    cust_no: str = ""
    salary_low: int = 0
    salary_high: int = 0
    salary_desc: str = ""
    option_edu: list[int] = field(default_factory=list)
    edu_desc: str = ""
    option_exp: str = ""
    location: str = ""
    industry: str = ""
    tags: list[str] = field(default_factory=list)
    description: str = ""
    appear_date: str = ""
    apply_cnt: int = 0
    remote_work_type: int = 0
    employee_count: int = 0

    @classmethod
    def from_search_result(cls, raw: dict) -> Job:
        """Normalize a raw search API response item."""
        link = raw.get("link", {})
        job_url = link.get("job", "") if isinstance(link, dict) else ""
        job_id = job_url.rstrip("/").split("/")[-1] if job_url else ""

        low = raw.get("salaryLow", 0)
        high = raw.get("salaryHigh", 0)
        if low and high:
            salary_desc = f"{low:,} ~ {high:,}"
        elif low:
            salary_desc = f"{low:,} 以上"
        else:
            salary_desc = raw.get("salaryDesc", "面議")

        raw_edu = raw.get("optionEdu", [])
        if isinstance(raw_edu, list):
            edu_desc = "/".join(EDU_DISPLAY.get(e, str(e)) for e in raw_edu)
            option_edu = raw_edu
        else:
            edu_desc = str(raw_edu) if raw_edu else ""
            option_edu = []

        raw_tags = raw.get("tags", {})
        if isinstance(raw_tags, dict):
            tags = [t.get("desc", k) for k, t in raw_tags.items() if t.get("desc")]
        elif isinstance(raw_tags, list):
            tags = raw_tags
        else:
            tags = []

        return cls(
            job_no=str(raw.get("jobNo", "")),
            job_id=job_id,
            job_name=raw.get("jobName", ""),
            job_url=job_url,
            cust_name=raw.get("custName", ""),
            cust_no=str(raw.get("custNo", "")),
            salary_low=low,
            salary_high=high,
            salary_desc=salary_desc,
            option_edu=option_edu,
            edu_desc=edu_desc,
            option_exp=str(raw.get("optionExp", raw.get("period", "")) or ""),
            location=str(raw.get("jobAddrNoDesc", "") or ""),
            industry=str(raw.get("coIndustryDesc", "") or ""),
            tags=tags[:6],
            description=raw.get("description", ""),
            appear_date=raw.get("appearDate", ""),
            apply_cnt=raw.get("applyCnt", 0) or 0,
            remote_work_type=raw.get("remoteWorkType", 0) or 0,
            employee_count=raw.get("employeeCount", 0) or 0,
        )

    def to_dict(self) -> dict:
        """Serialize for JSON/YAML structured output."""
        return {
            "jobNo": self.job_no,
            "jobId": self.job_id,
            "jobName": self.job_name,
            "jobUrl": self.job_url,
            "custName": self.cust_name,
            "salary": self.salary_desc,
            "salaryLow": self.salary_low,
            "salaryHigh": self.salary_high,
            "edu": self.edu_desc,
            "exp": self.option_exp,
            "location": self.location,
            "industry": self.industry,
            "tags": self.tags,
            "description": self.description,
            "appearDate": self.appear_date,
            "applyCnt": self.apply_cnt,
            "remoteWorkType": self.remote_work_type,
            "employeeCount": self.employee_count,
        }
