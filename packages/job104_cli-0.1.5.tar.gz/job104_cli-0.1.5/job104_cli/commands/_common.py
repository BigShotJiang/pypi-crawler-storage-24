"""Common helpers for job104 CLI commands."""

from __future__ import annotations

import json
import os
import sys
from collections.abc import Callable
from datetime import datetime
from pathlib import Path
from typing import Any, TypeVar

import click
from rich.console import Console

from ..client import Job104Client
from ..constants import BACKUP_DIR
from ..exceptions import Job104ApiError, error_code_for_exception

T = TypeVar("T")

# Rich output -> stderr (so structured JSON/YAML stays clean on stdout)
console = Console(stderr=True)

# -- Schema envelope version -------------------------------------------------
SCHEMA_VERSION = "1"


def get_client(credential: object | None = None) -> Job104Client:
    """Create a Job104Client with optional credential."""
    return Job104Client(credential)


def _wrap_envelope(data: Any, *, ok: bool = True, error: dict | None = None) -> dict:
    """Wrap data in the standard output envelope."""
    envelope: dict[str, Any] = {
        "ok": ok,
        "schema_version": SCHEMA_VERSION,
    }
    if ok:
        envelope["data"] = data
    else:
        envelope["data"] = None
        envelope["error"] = error or {}
    return envelope


def _output_structured(data: Any, *, as_json: bool, as_yaml: bool) -> None:
    """Output data wrapped in envelope as JSON or YAML."""
    envelope = _wrap_envelope(data)
    if as_json:
        click.echo(json.dumps(envelope, indent=2, ensure_ascii=False))
    elif as_yaml or not sys.stdout.isatty():
        try:
            import yaml

            click.echo(yaml.dump(envelope, allow_unicode=True, default_flow_style=False))
        except ImportError:
            click.echo(json.dumps(envelope, indent=2, ensure_ascii=False))


def handle_command(
    *,
    action: Callable[[Job104Client], T],
    render: Callable[[T], None] | None = None,
    render_md: Callable[[T], None] | None = None,
    as_json: bool = False,
    as_yaml: bool = False,
    as_md: bool = False,
    credential: object | None = None,
) -> T | None:
    """Run a client action with structured output support.

    - If --md is set and render_md provided, call render_md (plain Markdown)
    - If --json is set, print JSON envelope to stdout
    - If --yaml is set, print YAML envelope to stdout
    - If non-TTY and neither flag, auto YAML envelope
    - Otherwise, call render() for rich output
    """
    try:
        with get_client(credential) as client:
            data = action(client)

        if as_md and render_md:
            render_md(data)
            return data

        if as_json or as_yaml or not sys.stdout.isatty():
            _output_structured(data, as_json=as_json, as_yaml=as_yaml)
            return data

        if render:
            render(data)
        return data

    except Job104ApiError as exc:
        _print_error(exc, as_json=as_json, as_yaml=as_yaml)
        raise SystemExit(1) from None


def _print_error(exc: Job104ApiError, *, as_json: bool = False, as_yaml: bool = False) -> None:
    """Print formatted error message, with envelope if structured output."""
    code = error_code_for_exception(exc)
    if as_json or as_yaml or not sys.stdout.isatty():
        envelope = _wrap_envelope(None, ok=False, error={"code": code, "message": str(exc)})
        if as_json:
            click.echo(json.dumps(envelope, indent=2, ensure_ascii=False))
        else:
            try:
                import yaml

                click.echo(yaml.dump(envelope, allow_unicode=True, default_flow_style=False))
            except ImportError:
                click.echo(json.dumps(envelope, indent=2, ensure_ascii=False))
    else:
        console.print(f"[red][{code}] {exc}[/red]")


def require_auth() -> object:
    """Get credential or print error and exit."""
    from ..auth import get_credential

    cred = get_credential()
    if not cred:
        console.print("[red]未登入，請先使用 [bold]job104 login[/bold] 登入[/red]")
        raise SystemExit(1)
    return cred


def structured_output_options(command: Callable) -> Callable:
    """Add --json/--yaml/--md options to a Click command."""
    command = click.option("--md", "as_md", is_flag=True, help="以 Markdown 格式輸出")(command)
    command = click.option("--yaml", "as_yaml", is_flag=True, help="以 YAML 格式輸出")(command)
    command = click.option("--json", "as_json", is_flag=True, help="以 JSON 格式輸出")(command)
    return command


# -- Resume write helpers ----------------------------------------------------


def backup_resume(client: Job104Client, vno: str) -> Path | None:
    """Backup current resume to ~/.config/104-cli/backups/ before write.

    Returns the backup file path, or None if backup failed.
    Keeps the most recent 10 backups per VNO.
    """
    try:
        data = client.get_resume_detail(vno)
        BACKUP_DIR.mkdir(parents=True, exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%dT%H%M%S")
        backup_path = BACKUP_DIR / f"{vno}_{timestamp}.json"
        backup_path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        os.chmod(backup_path, 0o600)

        # Prune old backups: keep only the latest 10 per VNO
        pattern = f"{vno}_*.json"
        backups = sorted(BACKUP_DIR.glob(pattern), key=lambda p: p.stat().st_mtime, reverse=True)
        for old in backups[10:]:
            old.unlink(missing_ok=True)

        console.print(f"[dim]已備份履歷至 {backup_path}[/dim]")
        return backup_path
    except Exception as exc:
        console.print(f"[yellow]備份失敗（繼續執行）: {exc}[/yellow]")
        return None


def confirm_write(message: str, *, yes: bool = False) -> bool:
    """Ask user to confirm a write operation.

    Args:
        message: Description of the change.
        yes: If True, skip confirmation and return True.
    """
    if yes:
        return True
    return click.confirm(f"\n{message}\n確認執行？", default=False)


def resolve_vno(client: Job104Client, vno: str | None) -> str:
    """Resolve VNO — use provided value or default to the first (master) resume."""
    if vno:
        return vno
    overview = client.get_resume_overview()
    resumes = overview.get("data", {}).get("formData", {}).get("overview", [])
    if not resumes:
        console.print("[red]找不到任何履歷[/red]")
        raise SystemExit(1)
    return resumes[0]["versionNo"]


def handle_write_command(
    *,
    action: Callable[[Job104Client], T],
    as_json: bool = False,
    as_yaml: bool = False,
    credential: object | None = None,
) -> T | None:
    """Run a client write action with structured output support.

    Similar to handle_command but does not have render — write operations
    output the result envelope directly.
    """
    try:
        with get_client(credential) as client:
            data = action(client)

        if as_json or as_yaml or not sys.stdout.isatty():
            _output_structured(data, as_json=as_json, as_yaml=as_yaml)
            return data

        # For TTY, print a brief success message
        console.print("[green]操作成功[/green]")
        return data

    except Job104ApiError as exc:
        _print_error(exc, as_json=as_json, as_yaml=as_yaml)
        raise SystemExit(1) from None
