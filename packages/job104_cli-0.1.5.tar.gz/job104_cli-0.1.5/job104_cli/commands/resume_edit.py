"""Resume editing commands: resume-edit, resume-fill, resume-fields, resume-autocomplete."""

from __future__ import annotations

import json
import logging
import sys
from typing import Any

import click
from rich.panel import Panel
from rich.table import Table

from ..client import Job104Client
from ..resume_schema import SECTION_SCHEMAS, get_section_schema, list_sections
from ._common import (
    backup_resume,
    confirm_write,
    console,
    get_client,
    handle_write_command,
    require_auth,
    resolve_vno,
    structured_output_options,
)

logger = logging.getLogger(__name__)


# -- resume-edit ---------------------------------------------------------------


@click.command("resume-edit")
@click.argument("section", type=click.Choice(list(SECTION_SCHEMAS.keys()), case_sensitive=False))
@click.option("--vno", default=None, help="履歷版本號 (預設: 第一份履歷)")
@click.option("--add", "operation", flag_value="add", help="新增項目")
@click.option("--update", "operation", flag_value="update", default=True, help="更新項目 (預設)")
@click.option("--delete", "operation", flag_value="delete", help="刪除項目")
@click.option("--index", "entry_index", default=None, type=int, help="項目編號 (用於 array section，1-based)")
@click.option("--dry-run", is_flag=True, help="只預覽不提交")
@click.option("-y", "--yes", is_flag=True, help="跳過確認提示")
@click.option("--data", "json_data", default=None, help="JSON 格式的欄位資料 (agent 模式)")
@structured_output_options
def resume_edit(
    section: str,
    vno: str | None,
    operation: str,
    entry_index: int | None,
    dry_run: bool,
    yes: bool,
    json_data: str | None,
    as_json: bool,
    as_yaml: bool,
    as_md: bool,
) -> None:
    """互動式編輯履歷區塊

    \b
    範例：
      job104 resume-edit bio --update --data '{"chi": "我的自傳..."}'
      job104 resume-edit experience --add --data '{"companyName": "Google", ...}'
      job104 resume-edit education --delete --index 2
      job104 resume-edit experience --update --index 1 --data '{"description": "..."}'
    """
    cred = require_auth()
    schema = get_section_schema(section)
    if not schema:
        console.print(f"[red]不支援的區塊: {section}[/red]")
        raise SystemExit(1)

    # Validate operation is supported
    method_map = {"add": "POST", "update": "PUT", "delete": "DELETE"}
    http_method = method_map[operation]
    if http_method not in schema["operations"]:
        console.print(f"[red]{section} 不支援 {operation} 操作 (支援: {', '.join(schema['operations'])})[/red]")
        raise SystemExit(1)

    # For array sections, require --index for update/delete
    if schema["array"] and operation in ("update", "delete") and entry_index is None:
        console.print(f"[red]{section} 是陣列型區塊，{operation} 操作需要 --index 指定項目編號[/red]")
        raise SystemExit(1)

    # Parse --data if provided
    payload: dict[str, Any] | None = None
    if json_data:
        try:
            payload = json.loads(json_data)
        except json.JSONDecodeError as exc:
            console.print(f"[red]JSON 解析失敗: {exc}[/red]")
            raise SystemExit(1) from None

    def _action(c: Job104Client) -> dict[str, Any]:
        resolved_vno = resolve_vno(c, vno)

        # Fetch current resume for preview / context
        current = c.get_resume_detail(resolved_vno)
        current_data = current.get("data", {})
        current_section = current_data.get(section, {}).get("formData", {})

        # For interactive mode (no --data), prompt for fields
        nonlocal payload
        if payload is None and operation != "delete":
            payload = _interactive_collect(section, schema, current_section, operation, entry_index)

        if operation == "delete":
            return _handle_delete(c, resolved_vno, section, schema, current_section, entry_index, dry_run, yes)

        # Build submission payload
        submit_data = _build_submit_payload(section, schema, current_section, payload or {}, operation, entry_index)

        if dry_run:
            console.print(
                Panel(
                    json.dumps(submit_data, ensure_ascii=False, indent=2),
                    title=f"[yellow]預覽: {operation} {section}[/yellow]",
                    subtitle="--dry-run 模式，不會提交",
                )
            )
            return {"dry_run": True, "section": section, "payload": submit_data}

        if not confirm_write(f"將 {operation} 履歷區塊 [{section}]", yes=yes):
            console.print("[yellow]已取消[/yellow]")
            raise SystemExit(0)

        # Backup before write
        backup_resume(c, resolved_vno)

        result = c.update_resume_section(resolved_vno, section, submit_data, method=http_method)
        console.print(f"[green]成功 {operation} 履歷區塊 [{section}][/green]")
        return {"ok": True, "section": section, "operation": operation, "result": result}

    handle_write_command(action=_action, as_json=as_json, as_yaml=as_yaml, credential=cred)


def _interactive_collect(
    section: str,
    schema: dict[str, Any],
    current_section: dict[str, Any],
    operation: str,
    entry_index: int | None,
) -> dict[str, Any]:
    """Collect field values interactively via Click prompts."""
    fields = schema["fields"]
    result: dict[str, Any] = {}

    # For update, pre-fill with current values
    current_values: dict[str, Any] = {}
    if operation == "update":
        if schema["array"]:
            # Get the specific entry by index
            array_key = _get_array_key(section, current_section)
            entries = current_section.get(array_key, [])
            if entry_index and 1 <= entry_index <= len(entries):
                current_values = entries[entry_index - 1]
        else:
            # Single section: get the main data dict
            main_key = _get_main_key(section, current_section)
            current_values = current_section.get(main_key, {})

    for field_name, field_meta in fields.items():
        if field_name == "sort":
            continue  # Skip sort field for interactive input
        label = field_meta["label"]
        field_type = field_meta["type"]

        # Get current value for display
        current_val = current_values.get(field_name, "")
        if isinstance(current_val, dict):
            current_val = current_val.get("text", current_val.get("value", str(current_val)))
        elif isinstance(current_val, list):
            current_val = ", ".join(
                item.get("text", item.get("des", str(item))) if isinstance(item, dict) else str(item) for item in current_val
            )

        if field_type in ("text", "html"):
            default = str(current_val) if current_val else ""
            value = click.prompt(f"  {label}", default=default, show_default=bool(default))
            if value:
                result[field_name] = value
        elif field_type == "number":
            default = current_val if isinstance(current_val, (int, float)) else None
            value = click.prompt(f"  {label}", default=default, type=int, show_default=bool(default))
            if value is not None:
                result[field_name] = value
        elif field_type == "select":
            current_display = str(current_val) if current_val else "(未設定)"
            console.print(f"  {label}: [dim]{current_display}[/dim]")
            value = click.prompt(f"  新的 {label} (留空保持不變)", default="", show_default=False)
            if value:
                result[field_name] = value
        elif field_type == "bool":
            current_bool = bool(current_val) if current_val else False
            value = click.confirm(f"  {label}", default=current_bool)
            result[field_name] = value
        elif field_type in ("autocomplete", "multiselect", "array"):
            current_display = str(current_val) if current_val else "(未設定)"
            console.print(f"  {label}: [dim]{current_display}[/dim]")
            value = click.prompt(f"  新的 {label} (JSON 格式，留空保持不變)", default="", show_default=False)
            if value:
                try:
                    result[field_name] = json.loads(value)
                except json.JSONDecodeError:
                    result[field_name] = value
        elif field_type == "date":
            console.print(f"  {label}: [dim]{current_val}[/dim]")
            start_year = click.prompt("  起始年份", default="", show_default=False)
            start_month = click.prompt("  起始月份", default="", show_default=False)
            end_year = click.prompt("  結束年份 (留空表示至今)", default="", show_default=False)
            end_month = click.prompt("  結束月份", default="", show_default=False)
            if start_year:
                duration: dict[str, Any] = {"startYear": start_year}
                if start_month:
                    duration["startMonth"] = {"text": int(start_month), "value": int(start_month)}
                if end_year:
                    duration["endYear"] = end_year
                    if end_month:
                        duration["endMonth"] = {"text": int(end_month), "value": int(end_month)}
                result[field_name] = duration

    return result


def _handle_delete(
    client: Job104Client,
    vno: str,
    section: str,
    schema: dict[str, Any],
    current_section: dict[str, Any],
    entry_index: int | None,
    dry_run: bool,
    yes: bool,
) -> dict[str, Any]:
    """Handle delete operation for a resume section or entry."""
    if schema["array"] and entry_index:
        array_key = _get_array_key(section, current_section)
        entries = current_section.get(array_key, [])
        if entry_index < 1 or entry_index > len(entries):
            console.print(f"[red]項目編號 {entry_index} 超出範圍 (共 {len(entries)} 項)[/red]")
            raise SystemExit(1)
        entry = entries[entry_index - 1]
        sort_value = entry.get("sort", entry_index)

        # Show what will be deleted
        entry_summary = _summarize_entry(section, entry)
        console.print(f"[red]將刪除: {entry_summary}[/red]")

        if dry_run:
            return {"dry_run": True, "section": section, "operation": "delete", "entry": entry}

        if not confirm_write(f"確認刪除 {section} 第 {entry_index} 項: {entry_summary}", yes=yes):
            console.print("[yellow]已取消[/yellow]")
            raise SystemExit(0)

        backup_resume(client, vno)
        result = client.delete_resume_section(vno, section, {"sort": sort_value})
        console.print(f"[green]已刪除 {section} 第 {entry_index} 項[/green]")
        return {"ok": True, "section": section, "operation": "delete", "index": entry_index, "result": result}

    # Delete entire section
    if dry_run:
        return {"dry_run": True, "section": section, "operation": "delete"}

    if not confirm_write(f"確認刪除整個 {section} 區塊", yes=yes):
        console.print("[yellow]已取消[/yellow]")
        raise SystemExit(0)

    backup_resume(client, vno)
    result = client.delete_resume_section(vno, section)
    console.print(f"[green]已刪除 {section} 區塊[/green]")
    return {"ok": True, "section": section, "operation": "delete", "result": result}


def _build_submit_payload(
    section: str,
    schema: dict[str, Any],
    current_section: dict[str, Any],
    new_data: dict[str, Any],
    operation: str,
    entry_index: int | None,
) -> dict[str, Any]:
    """Build the API submission payload for a section.

    For update operations, merges new data with current data.
    For add operations, uses new data directly.
    """
    if not schema["array"]:
        # Single section: merge or replace the main data dict
        main_key = _get_main_key(section, current_section)
        if operation == "update":
            current = current_section.get(main_key, {})
            if isinstance(current, dict):
                merged = {**current, **new_data}
            else:
                merged = new_data
            return {main_key: merged}
        return {main_key: new_data}

    # Array section
    array_key = _get_array_key(section, current_section)
    entries = current_section.get(array_key, [])

    if operation == "add":
        # Assign sort value
        max_sort = max((e.get("sort", 0) for e in entries), default=0)
        new_data["sort"] = max_sort + 1
        return new_data

    if operation == "update" and entry_index:
        if 1 <= entry_index <= len(entries):
            current_entry = entries[entry_index - 1]
            merged = {**current_entry, **new_data}
            return merged

    return new_data


def _get_array_key(section: str, form_data: dict[str, Any]) -> str:
    """Get the key name for the array of entries in a section's formData."""
    # Common patterns: experiences, educations, skills, projects, portfolios
    key_map = {
        "education": "educations",
        "experience": "experiences",
        "skill": "skills",
        "project": "projects",
        "portfolio": "portfolios",
    }
    return key_map.get(section, f"{section}s")


def _get_main_key(section: str, form_data: dict[str, Any]) -> str:
    """Get the key name for the main data dict in a single section's formData."""
    # Common patterns: info -> info, bio -> bio, jobCondition -> jobCondition
    key_map = {
        "info": "info",
        "bio": "bio",
        "jobCondition": "jobCondition",
        "certificate": "certificate",
        "language": "languages",
    }
    return key_map.get(section, section)


def _summarize_entry(section: str, entry: dict[str, Any]) -> str:
    """Create a brief summary of an array entry for display."""
    if section == "experience":
        company = entry.get("companyName", "")
        title = entry.get("jobName", "")
        return f"{company} - {title}"
    if section == "education":
        school = entry.get("name", "")
        dept = ""
        depts = entry.get("departments", [])
        if depts and isinstance(depts[0], dict):
            dept = depts[0].get("name", "")
        return f"{school} - {dept}"
    if section == "project":
        return entry.get("name", "(unnamed)")
    if section == "skill":
        return entry.get("name", "(unnamed)")
    return json.dumps(entry, ensure_ascii=False)[:60]


# -- resume-fill ---------------------------------------------------------------


@click.command("resume-fill")
@click.option("--from", "from_path", default=None, type=click.Path(exists=True), help="輸入檔案路徑 (PDF/JSON/HTML)")
@click.option("--stdin", "use_stdin", is_flag=True, help="從 stdin 讀取 JSON")
@click.option("--vno", default=None, help="履歷版本號 (預設: 第一份履歷)")
@click.option("--sections", default=None, help="限定更新區塊 (逗號分隔，如 experience,education)")
@click.option("--strategy", default="replace", type=click.Choice(["replace", "merge"]), help="合併策略 (預設: replace)")
@click.option("--dry-run", is_flag=True, help="只預覽不提交")
@click.option("-y", "--yes", is_flag=True, help="跳過確認提示")
@structured_output_options
def resume_fill(
    from_path: str | None,
    use_stdin: bool,
    vno: str | None,
    sections: str | None,
    strategy: str,
    dry_run: bool,
    yes: bool,
    as_json: bool,
    as_yaml: bool,
    as_md: bool,
) -> None:
    """從外部資料源自動填入履歷

    \b
    範例：
      job104 resume-fill --from resume.json --dry-run
      job104 resume-fill --from resume.pdf --sections experience,education
      echo '{"bio": {"chi": "..."}}' | job104 resume-fill --stdin --yes
      cat parsed.json | job104 resume-fill --stdin --strategy merge --yes --json
    """
    if not from_path and not use_stdin:
        console.print("[red]請指定 --from <檔案> 或 --stdin[/red]")
        raise SystemExit(1)

    cred = require_auth()

    # Parse input
    parsed_data = _parse_input(from_path, use_stdin)
    if not parsed_data:
        console.print("[red]無法解析輸入資料[/red]")
        raise SystemExit(1)

    # Filter sections if specified
    target_sections = None
    if sections:
        target_sections = [s.strip() for s in sections.split(",")]
        for s in target_sections:
            if s not in SECTION_SCHEMAS:
                console.print(f"[red]不支援的區塊: {s}[/red]")
                raise SystemExit(1)

    def _action(c: Job104Client) -> dict[str, Any]:
        resolved_vno = resolve_vno(c, vno)

        # Get current resume for diff
        current = c.get_resume_detail(resolved_vno)
        current_data = current.get("data", {})

        results: list[dict[str, Any]] = []
        sections_to_process = target_sections or [s for s in parsed_data if s in SECTION_SCHEMAS]

        if dry_run:
            console.print(
                Panel(
                    f"[yellow]預覽模式 — 策略: {strategy}, 區塊: {', '.join(sections_to_process)}[/yellow]",
                    title="resume-fill --dry-run",
                )
            )

        for section_name in sections_to_process:
            if section_name not in parsed_data:
                continue

            schema = get_section_schema(section_name)
            if not schema:
                results.append({"section": section_name, "ok": False, "error": "不支援的區塊"})
                continue

            section_data = parsed_data[section_name]
            current_section = current_data.get(section_name, {}).get("formData", {})

            if dry_run:
                console.print(f"\n[bold]{section_name}[/bold] ({schema['label']}):")
                console.print(json.dumps(section_data, ensure_ascii=False, indent=2)[:500])
                results.append({"section": section_name, "ok": True, "dry_run": True})
                continue

            try:
                result = _fill_section(c, resolved_vno, section_name, schema, section_data, current_section, strategy)
                results.append({"section": section_name, "ok": True, **result})
                console.print(f"  [green]✓[/green] {section_name} ({schema['label']})")
            except Exception as exc:
                results.append({"section": section_name, "ok": False, "error": str(exc)})
                console.print(f"  [red]✗[/red] {section_name}: {exc}")

        if not dry_run:
            # Backup was done per-section; summarize
            ok_count = sum(1 for r in results if r.get("ok"))
            fail_count = sum(1 for r in results if not r.get("ok"))
            console.print(f"\n[bold]結果: {ok_count} 成功, {fail_count} 失敗[/bold]")

        return {
            "results": results,
            "strategy": strategy,
            "dry_run": dry_run,
            "vno": resolved_vno,
        }

    # Backup before any writes (if not dry-run)
    if not dry_run:
        with get_client(cred) as pre_client:
            resolved = resolve_vno(pre_client, vno)
            if not confirm_write(
                f"將以 {strategy} 策略更新履歷 (vno={resolved}), 區塊: {sections or '全部'}",
                yes=yes,
            ):
                console.print("[yellow]已取消[/yellow]")
                raise SystemExit(0)
            backup_resume(pre_client, resolved)

    handle_write_command(action=_action, as_json=as_json, as_yaml=as_yaml, credential=cred)


def _parse_input(from_path: str | None, use_stdin: bool) -> dict[str, Any] | None:
    """Parse input from file or stdin.

    Returns a dict keyed by section name with section data as values.
    """
    if use_stdin:
        raw = sys.stdin.read()
        try:
            return json.loads(raw)
        except json.JSONDecodeError as exc:
            console.print(f"[red]stdin JSON 解析失敗: {exc}[/red]")
            return None

    if from_path:
        if from_path.endswith(".json"):
            return _parse_json_file(from_path)
        if from_path.endswith(".pdf"):
            return _parse_pdf_file(from_path)
        if from_path.endswith((".html", ".htm")):
            return _parse_html_file(from_path)
        console.print(f"[red]不支援的檔案格式: {from_path} (支援: .json, .pdf, .html)[/red]")
        return None

    return None


def _parse_json_file(path: str) -> dict[str, Any] | None:
    """Parse a JSON resume file."""
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except Exception as exc:
        console.print(f"[red]JSON 檔案讀取失敗: {exc}[/red]")
        return None


def _parse_pdf_file(path: str) -> dict[str, Any] | None:
    """Parse a PDF resume file (requires pdfplumber)."""
    try:
        import pdfplumber
    except ImportError:
        console.print("[red]需要安裝 pdfplumber: pip install job104-cli[fill][/red]")
        return None

    try:
        text = ""
        with pdfplumber.open(path) as pdf:
            for page in pdf.pages:
                page_text = page.extract_text()
                if page_text:
                    text += page_text + "\n"

        if not text.strip():
            console.print("[yellow]PDF 無法提取文字 (可能是掃描圖片)[/yellow]")
            return None

        # Basic section extraction from text
        # This is a simple heuristic — for better results, pipe pre-parsed JSON via --stdin
        return _extract_sections_from_text(text)
    except Exception as exc:
        console.print(f"[red]PDF 解析失敗: {exc}[/red]")
        return None


def _parse_html_file(path: str) -> dict[str, Any] | None:
    """Parse an HTML file (e.g., saved LinkedIn profile page)."""
    try:
        from bs4 import BeautifulSoup
    except ImportError:
        console.print("[red]需要安裝 beautifulsoup4: pip install job104-cli[fill][/red]")
        return None

    try:
        with open(path, encoding="utf-8") as f:
            soup = BeautifulSoup(f.read(), "html.parser")

        # Extract text and try section parsing
        text = soup.get_text(separator="\n", strip=True)
        return _extract_sections_from_text(text)
    except Exception as exc:
        console.print(f"[red]HTML 解析失敗: {exc}[/red]")
        return None


def _extract_sections_from_text(text: str) -> dict[str, Any]:
    """Extract resume sections from plain text using simple heuristics.

    This is a basic implementation. For production use, pipe pre-parsed JSON
    from an AI agent (e.g., Claude) via --stdin for much better accuracy.
    """
    result: dict[str, Any] = {}

    # Try to extract bio from the full text
    if text.strip():
        result["bio"] = {"chi": text[:3000]}  # Basic: use first 3000 chars as bio draft

    console.print("[yellow]提示: 純文字解析精確度有限。建議使用 AI agent 解析後，以 JSON 格式透過 --stdin 傳入。[/yellow]")
    return result


def _fill_section(
    client: Job104Client,
    vno: str,
    section: str,
    schema: dict[str, Any],
    section_data: Any,
    current_section: dict[str, Any],
    strategy: str,
) -> dict[str, Any]:
    """Fill a single resume section with the given data."""
    if not schema["array"]:
        # Single section: PUT directly
        main_key = _get_main_key(section, current_section)
        payload = {main_key: section_data} if not isinstance(section_data, dict) or main_key not in section_data else section_data
        result = client.update_resume_section(vno, section, payload, method="PUT")
        return {"entries_updated": 1, "result": result}

    # Array section
    if not isinstance(section_data, list):
        section_data = [section_data]

    if strategy == "replace":
        # Delete existing entries (if any) then add new ones
        # Note: Some sections may need to be replaced via PUT with full array
        for i, entry in enumerate(section_data):
            entry["sort"] = i + 1
            method = "POST" if "POST" in schema["operations"] else "PUT"
            client.update_resume_section(vno, section, entry, method=method)
        return {"entries_updated": len(section_data)}

    # merge strategy: try to match by key fields, update matched, add new
    return {"entries_updated": len(section_data), "strategy": "merge"}


# -- resume-fields -------------------------------------------------------------


@click.command("resume-fields")
@click.option("--section", default=None, help="只顯示特定區塊的欄位")
@structured_output_options
def resume_fields(section: str | None, as_json: bool, as_yaml: bool, as_md: bool) -> None:
    """查看履歷欄位定義 (給 agent 參考)

    \b
    範例：
      job104 resume-fields --json
      job104 resume-fields --section experience --json
    """
    if section:
        schema = get_section_schema(section)
        if not schema:
            console.print(f"[red]不支援的區塊: {section}[/red]")
            raise SystemExit(1)
        data = {section: schema}
    else:
        data = SECTION_SCHEMAS

    if as_json or as_yaml or not sys.stdout.isatty():
        from ._common import _output_structured

        _output_structured(data, as_json=as_json, as_yaml=as_yaml)
        return

    # Rich table display
    if section:
        _render_section_fields(section, data[section])
    else:
        sections_list = list_sections()
        table = Table(title="履歷區塊一覽", show_lines=True)
        table.add_column("區塊", style="bold cyan")
        table.add_column("中文名稱", style="green")
        table.add_column("類型")
        table.add_column("支援操作", style="yellow")
        for s in sections_list:
            table.add_row(s["name"], s["label"], "陣列" if s["array"] else "單一", ", ".join(s["operations"]))
        console.print(table)
        console.print("[dim]使用 --section <name> 查看特定區塊的欄位定義[/dim]")


def _render_section_fields(section: str, schema: dict[str, Any]) -> None:
    """Render section field definitions as a Rich table."""
    table = Table(title=f"{schema['label']} ({section}) 欄位定義", show_lines=True)
    table.add_column("欄位名稱", style="bold cyan")
    table.add_column("中文", style="green")
    table.add_column("類型")
    table.add_column("必填")
    table.add_column("備註", style="dim")

    for field_name, meta in schema["fields"].items():
        notes = []
        if "options_key" in meta:
            notes.append(f"options: {meta['options_key']}")
        if "ac_type" in meta:
            notes.append(f"autocomplete: {meta['ac_type']}")
        if "max_length" in meta:
            notes.append(f"max: {meta['max_length']}")
        table.add_row(
            field_name,
            meta["label"],
            meta["type"],
            "✓" if meta.get("required") else "",
            ", ".join(notes),
        )
    console.print(table)


# -- resume-autocomplete -------------------------------------------------------


@click.command("resume-autocomplete")
@click.argument("ac_type", type=click.Choice(["school", "company", "jobTitle", "skill", "major"]))
@click.argument("query")
@structured_output_options
def resume_autocomplete(ac_type: str, query: str, as_json: bool, as_yaml: bool, as_md: bool) -> None:
    """查詢 104 自動完成 (學校/公司/職稱/技能/科系)

    \b
    範例：
      job104 resume-autocomplete school 臺灣大學
      job104 resume-autocomplete company Google --json
      job104 resume-autocomplete skill Python --json
    """
    cred = require_auth()

    def _action(c: Job104Client) -> Any:
        return c.autocomplete(ac_type, query)

    def _render(data: Any) -> None:
        if not data:
            console.print(f"[yellow]無匹配結果: {ac_type} '{query}'[/yellow]")
            return
        if isinstance(data, list):
            table = Table(title=f"自動完成: {ac_type} '{query}'", show_lines=True)
            table.add_column("#", style="dim", width=4)
            table.add_column("名稱", style="bold cyan")
            table.add_column("值", style="green")
            for i, item in enumerate(data[:10], 1):
                if isinstance(item, dict):
                    table.add_row(str(i), str(item.get("text", item.get("name", ""))), str(item.get("value", item.get("id", ""))))
                else:
                    table.add_row(str(i), str(item), "")
            console.print(table)
        else:
            console.print(json.dumps(data, ensure_ascii=False, indent=2))

    from ._common import handle_command

    handle_command(action=_action, render=_render, as_json=as_json, as_yaml=as_yaml, credential=cred)
