"""Personal center commands: applied, saved, interviews, resume, viewers, follows, history, recommend."""

from __future__ import annotations

import logging
import re

import click
from rich.panel import Panel
from rich.table import Table

from ..index_cache import save_index
from ._common import console, handle_command, require_auth, structured_output_options

logger = logging.getLogger(__name__)


# -- applied -----------------------------------------------------------------


@click.command()
@click.option("-p", "--page", default=1, type=int, help="頁碼 (預設: 1)")
@click.option(
    "-s",
    "--status",
    default="all",
    type=click.Choice(["all", "read", "replied", "closed"], case_sensitive=False),
    help="篩選狀態 (預設: all)",
)
@structured_output_options
def applied(page: int, status: str, as_json: bool, as_yaml: bool, as_md: bool) -> None:
    """查看已應徵的職缺"""
    cred = require_auth()

    # Map user-friendly status names to API values
    status_map = {"all": "all", "read": "all", "replied": "all", "closed": "off"}
    api_status = status_map.get(status, "all")

    def _action(c):
        return c.get_applied_jobs(page=page, status=api_status)

    def _render(data: dict) -> None:
        records = data.get("data", data.get("list", []))
        if isinstance(records, dict):
            records = records.get("list", [])
        if not records:
            console.print("[yellow]暫無應徵紀錄[/yellow]")
            return

        _save_job_index(records, source="applied")

        title = "已應徵的職缺"
        if status != "all":
            title += f" ({status})"
        table = Table(title=title, show_lines=True)
        table.add_column("#", style="dim", width=4)
        table.add_column("職缺", style="bold cyan", max_width=30)
        table.add_column("公司", style="green", max_width=20)
        table.add_column("薪資", style="yellow")
        table.add_column("狀態")
        table.add_column("應徵日期", style="dim")

        for i, rec in enumerate(records, 1):
            table.add_row(
                str(i),
                rec.get("jobName", rec.get("job", {}).get("jobName", "")),
                rec.get("custName", rec.get("company", {}).get("name", "")),
                rec.get("salaryDesc", rec.get("salary", "")),
                rec.get("status", rec.get("applyStatus", "")),
                rec.get("applyDate", rec.get("createDate", "")),
            )
        console.print(table)
        console.print("  [dim]使用 job104 show <編號> 查看職缺詳情[/dim]")

        _print_pagination_hint(data, page, "applied")

    handle_command(action=_action, render=_render, as_json=as_json, as_yaml=as_yaml, credential=cred)


# -- saved -------------------------------------------------------------------


@click.command()
@click.option("-p", "--page", default=1, type=int, help="頁碼 (預設: 1)")
@click.option("--not-applied", is_flag=True, help="只顯示儲存但未應徵的職缺")
@structured_output_options
def saved(page: int, not_applied: bool, as_json: bool, as_yaml: bool, as_md: bool) -> None:
    """查看收藏的職缺"""
    cred = require_auth()
    status = "notApply" if not_applied else "all"

    def _action(c):
        return c.get_saved_jobs(page=page, status=status)

    def _render(data: dict) -> None:
        jobs = data.get("data", data.get("list", []))
        if isinstance(jobs, dict):
            jobs = jobs.get("list", [])
        if not jobs:
            msg = "暫無儲存未應徵的職缺" if not_applied else "暫無收藏職缺"
            console.print(f"[yellow]{msg}[/yellow]")
            return

        _save_job_index(jobs, source="saved")

        title = "儲存未應徵的職缺" if not_applied else "收藏的職缺"
        table = Table(title=title, show_lines=True)
        table.add_column("#", style="dim", width=4)
        table.add_column("職缺", style="bold cyan", max_width=30)
        table.add_column("公司", style="green", max_width=20)
        table.add_column("薪資", style="yellow")
        table.add_column("地區", style="blue")
        table.add_column("收藏日期", style="dim")

        for i, job in enumerate(jobs, 1):
            table.add_row(
                str(i),
                job.get("jobName", ""),
                job.get("custName", job.get("company", {}).get("name", "")),
                job.get("salaryDesc", ""),
                job.get("jobAddrNoDesc", job.get("area", "")),
                job.get("saveDate", job.get("createDate", "")),
            )
        console.print(table)
        console.print("  [dim]使用 job104 show <編號> 查看職缺詳情[/dim]")

        _print_pagination_hint(data, page, "saved")

    handle_command(action=_action, render=_render, as_json=as_json, as_yaml=as_yaml, credential=cred)


# -- interviews --------------------------------------------------------------


@click.command()
@structured_output_options
def interviews(as_json: bool, as_yaml: bool, as_md: bool) -> None:
    """查看面試邀請"""
    cred = require_auth()

    def _action(c):
        return c.get_interviews()

    def _render(data: dict) -> None:
        items = data.get("data", data.get("list", []))
        if isinstance(items, dict):
            items = items.get("list", [])
        if not items:
            console.print("[yellow]暫無面試邀請[/yellow]")
            return

        table = Table(title="面試邀請", show_lines=True)
        table.add_column("#", style="dim", width=4)
        table.add_column("職缺", style="bold cyan", max_width=30)
        table.add_column("公司", style="green", max_width=20)
        table.add_column("面試時間", style="yellow")
        table.add_column("地點", style="blue")
        table.add_column("狀態")

        for i, item in enumerate(items, 1):
            table.add_row(
                str(i),
                item.get("jobName", item.get("job", {}).get("jobName", "")),
                item.get("custName", item.get("company", {}).get("name", "")),
                item.get("interviewDate", item.get("date", "")),
                item.get("address", item.get("location", "")),
                item.get("status", ""),
            )
        console.print(table)

    handle_command(action=_action, render=_render, as_json=as_json, as_yaml=as_yaml, credential=cred)


# -- resume ------------------------------------------------------------------


@click.command()
@structured_output_options
def resume(as_json: bool, as_yaml: bool, as_md: bool) -> None:
    """查看履歷列表"""
    cred = require_auth()

    def _action(c):
        return c.get_resume_overview()

    def _render(data: dict) -> None:
        from datetime import datetime

        inner = data.get("data", data)
        if isinstance(inner, dict):
            form_data = inner.get("formData", inner)
        else:
            form_data = inner
        overview = form_data.get("overview", []) if isinstance(form_data, dict) else []

        if not overview:
            console.print("[yellow]暫無履歷資料[/yellow]")
            return

        table = Table(title="履歷列表", show_lines=True)
        table.add_column("#", style="dim", width=4)
        table.add_column("履歷名稱", style="bold cyan")
        table.add_column("VNO", style="dim")
        table.add_column("類型", style="green")
        table.add_column("狀態", style="yellow")
        table.add_column("完整度")
        table.add_column("最後修改", style="dim")

        for i, r in enumerate(overview, 1):
            modified = r.get("lastModified", 0)
            mod_str = datetime.fromtimestamp(modified).strftime("%Y/%m/%d") if modified else "-"

            resume_type = r.get("resumeType", "-")
            type_text = resume_type.get("text", "-") if isinstance(resume_type, dict) else str(resume_type)

            pub_status = r.get("publicStatus", "-")
            status_text = pub_status.get("text", "-") if isinstance(pub_status, dict) else str(pub_status)

            table.add_row(
                str(i),
                r.get("title", "-"),
                r.get("vno", r.get("versionNo", "-")),
                type_text,
                status_text,
                "[green]完整[/green]" if r.get("isCompleted") else "[red]未完成[/red]",
                mod_str,
            )
        console.print(table)
        console.print("  [dim]使用 job104 resume-show <VNO> 查看完整履歷內容[/dim]")

    handle_command(action=_action, render=_render, as_json=as_json, as_yaml=as_yaml, credential=cred)


# -- resume-show -------------------------------------------------------------


@click.command("resume-show")
@click.argument("vno", required=False)
@structured_output_options
def resume_show(vno: str | None, as_json: bool, as_yaml: bool, as_md: bool) -> None:
    """查看履歷完整內容（工作經歷、學歷、技能等）"""
    cred = require_auth()

    def _action(c):
        target_vno = vno
        if not target_vno or (target_vno.isdigit() and int(target_vno) <= 20):
            overview = c.get_resume_overview()
            inner = overview.get("data", overview)
            if isinstance(inner, dict):
                form_data = inner.get("formData", inner)
            else:
                form_data = inner
            items = form_data.get("overview", []) if isinstance(form_data, dict) else []
            if not items:
                return {"_error": "no_resume"}
            if target_vno and target_vno.isdigit():
                idx = int(target_vno) - 1
                if idx < 0 or idx >= len(items):
                    return {"_error": "bad_index", "_count": len(items)}
                target_vno = items[idx].get("vno", items[idx].get("versionNo", ""))
            else:
                target_vno = items[0].get("vno", items[0].get("versionNo", ""))
        return c.get_resume_detail(target_vno)

    def _render(data: dict) -> None:
        if data.get("_error") == "no_resume":
            console.print("[yellow]暫無履歷資料[/yellow]")
            return
        if data.get("_error") == "bad_index":
            console.print(f"[red]編號超出範圍，共 {data['_count']} 份履歷[/red]")
            return

        d = data.get("data", data)

        # Resume header
        resume_info = d.get("resume", {})
        progress = d.get("progress", 0)
        name = resume_info.get("name", "履歷")
        console.print(Panel(f"[bold]{name}[/bold]  完成度: {progress}%", style="cyan"))

        # Personal info — merge ACData for name/email/gender
        info = d.get("info", {}).get("formData", {}).get("info", {})
        ac_info = d.get("ACData", {}).get("info", {})
        if info or ac_info:
            table = Table(title="個人資訊", show_lines=True)
            table.add_column("欄位", style="bold", width=12)
            table.add_column("內容")
            _add_info_row(table, "姓名", ac_info.get("name"))
            _add_info_row(table, "Email", ac_info.get("email"))
            _add_info_row(table, "性別", _extract_text(ac_info.get("gender")))
            _add_info_row(table, "求職狀態", _extract_text(info.get("jobStatus")))
            _add_info_row(table, "年齡", info.get("age"))
            _add_info_row(table, "城市", _extract_text(info.get("city")))
            _add_info_row(table, "手機", info.get("cellphone"))
            _add_info_row(table, "座右銘", info.get("motto"))
            _add_info_row(table, "人格特質", info.get("trait"))
            for n in range(1, 4):
                url = info.get(f"personalLink{n}Url")
                if url:
                    link_type = info.get(f"personalLink{n}Type", "")
                    _add_info_row(table, f"連結{n}", f"{link_type}: {url}" if link_type else url)
            console.print(table)

        # Work experience
        exps = d.get("experience", {}).get("formData", {}).get("experiences", [])
        if exps:
            seniority = d.get("experience", {}).get("formData", {}).get("seniority", {})
            title = f"工作經歷 ({len(exps)})"
            if seniority:
                sen_text = seniority.get("text", "")
                if sen_text:
                    title += f"  年資: {sen_text}"
                else:
                    total = seniority.get("total", {})
                    if total:
                        title += f"  年資: {total.get('year', 0)}年{total.get('month', 0)}月"
            table = Table(title=title, show_lines=True)
            table.add_column("#", style="dim", width=3)
            table.add_column("公司", style="green", max_width=22)
            table.add_column("職稱", style="bold cyan", max_width=22)
            table.add_column("期間", width=18)
            table.add_column("描述", max_width=40)

            for i, exp in enumerate(exps, 1):
                period = _format_duration(exp.get("duration", {}), exp.get("stillWork"))
                desc = _strip_html(exp.get("description") or "")[:80]
                table.add_row(
                    str(i),
                    exp.get("companyName", ""),
                    exp.get("jobName", ""),
                    period,
                    desc,
                )
            console.print(table)

        # Education
        edus = d.get("education", {}).get("formData", {}).get("educations", [])
        if edus:
            table = Table(title=f"學歷 ({len(edus)})", show_lines=True)
            table.add_column("學校", style="bold", max_width=20)
            table.add_column("科系", max_width=20)
            table.add_column("學位")
            table.add_column("期間")
            table.add_column("狀態")

            for edu in edus:
                dur = edu.get("duration", {})
                depts = edu.get("departments", [])
                dept_name = depts[0].get("name", "") if depts else ""
                sy = dur.get("startYear", "")
                ey = dur.get("endYear", "")
                period = f"{sy}-{ey}" if sy or ey else ""
                status = edu.get("status", {})
                status_text = status.get("text", "") if isinstance(status, dict) else str(status)
                highest = edu.get("highest", {})
                highest_text = highest.get("text", "") if isinstance(highest, dict) else str(highest)
                table.add_row(edu.get("name", ""), dept_name, highest_text, period, status_text)
            console.print(table)

        # Skills — handle both old format and API format with `tag` key
        skills_data = d.get("skill", {}).get("formData", {}).get("skills", [])
        if skills_data:
            skills_list = skills_data if isinstance(skills_data, list) else list(skills_data.values())
            if skills_list:
                table = Table(title="技能", show_lines=True)
                table.add_column("類別", style="bold")
                table.add_column("技能", style="cyan")
                for group in skills_list:
                    if isinstance(group, dict):
                        cat = group.get("category", group.get("name", ""))
                        items = group.get("items", group.get("skills", group.get("tag", [])))
                        if isinstance(items, list):
                            names = ", ".join(i.get("name", i.get("text", str(i))) if isinstance(i, dict) else str(i) for i in items)
                        else:
                            names = str(items)
                        if cat or names:
                            table.add_row(str(cat), names)
                            # Also render desc if present
                        desc = group.get("desc", "")
                        if desc:
                            table.add_row("", _strip_html(str(desc)))
                console.print(table)

        # Certificates
        cert_data = d.get("certificate", {}).get("formData", {}).get("certificate", {})
        if isinstance(cert_data, dict):
            cert_list = cert_data.get("certificates", [])
            cert_others = cert_data.get("others", "")
        elif isinstance(cert_data, list):
            cert_list = cert_data
            cert_others = ""
        else:
            cert_list = []
            cert_others = str(cert_data) if cert_data else ""
        has_certs = cert_list or cert_others
        if has_certs:
            table = Table(title="證照", show_lines=True)
            table.add_column("證照名稱", style="bold cyan")
            table.add_column("發照單位")
            table.add_column("取得日期", style="dim")
            for cert in cert_list:
                if isinstance(cert, dict):
                    table.add_row(
                        cert.get("name", ""),
                        cert.get("issuer", cert.get("org", "")),
                        cert.get("date", ""),
                    )
                else:
                    table.add_row(str(cert), "", "")
            if cert_others:
                for line in str(cert_others).strip().splitlines():
                    line = line.strip()
                    if line:
                        table.add_row(line, "", "")
            console.print(table)

        # Languages — handle dict format {foreign: [...], local: [...]}
        lang_data = d.get("language", {}).get("formData", {}).get("languages", {})
        langs: list = []
        if isinstance(lang_data, dict):
            langs = lang_data.get("foreign", []) + lang_data.get("local", [])
        elif isinstance(lang_data, list):
            langs = lang_data
        if langs:
            table = Table(title=f"語言能力 ({len(langs)})", show_lines=True)
            table.add_column("語言", style="bold")
            table.add_column("聽", width=6)
            table.add_column("說", width=6)
            table.add_column("讀", width=6)
            table.add_column("寫", width=6)
            for lang in langs:
                if isinstance(lang, dict):
                    # API format: type.text for name; also support old format
                    name = lang.get("type", lang.get("language", lang.get("name", "")))
                    if isinstance(name, dict):
                        name = name.get("text", str(name))
                    # For local languages, use level instead of LSRW
                    level = lang.get("level")
                    if level is not None and not any(lang.get(k) for k in ("listening", "speaking", "reading", "writing")):
                        level_text = _level_text(level)
                        table.add_row(str(name), level_text, level_text, level_text, level_text)
                    else:
                        table.add_row(
                            str(name),
                            _level_text(lang.get("listening")),
                            _level_text(lang.get("speaking")),
                            _level_text(lang.get("reading")),
                            _level_text(lang.get("writing")),
                        )
                else:
                    table.add_row(str(lang), "", "", "", "")
            console.print(table)

        # Job conditions
        jc = d.get("jobCondition", {}).get("formData", {}).get("jobCondition", {})
        if jc:
            table = Table(title="求職條件", show_lines=True)
            table.add_column("欄位", style="bold", width=12)
            table.add_column("內容")
            _add_info_row(table, "工作類型", _extract_text(jc.get("jobTimeType")))
            _add_info_row(table, "上班時段", _extract_text(jc.get("jobTimePeriod")))
            # Salary — handle complex nested structure
            salary = jc.get("salary", {})
            if salary:
                sal_text = _format_salary(jc)
                _add_info_row(table, "期望薪資", sal_text)
            # preferArea — check both `name` and `des` keys
            areas = jc.get("preferArea", [])
            if areas:
                area_names = ", ".join((a.get("name") or a.get("des") or str(a)) if isinstance(a, dict) else str(a) for a in areas)
                _add_info_row(table, "期望地區", area_names)
            # preferJobTitle — may be string or list
            titles = jc.get("preferJobTitle", [])
            if titles:
                if isinstance(titles, str):
                    title_names = titles
                elif isinstance(titles, list):
                    title_names = ", ".join(t.get("name", str(t)) if isinstance(t, dict) else str(t) for t in titles)
                else:
                    title_names = str(titles)
                _add_info_row(table, "期望職稱", title_names)
            _add_info_row(table, "遠端工作", _extract_text(jc.get("remoteWork")))
            console.print(table)

        # Bio / autobiography — handle {chi: "...", eng: "..."} format
        bio_raw = d.get("bio", {}).get("formData", {}).get("bio", "")
        if isinstance(bio_raw, dict):
            bio = bio_raw.get("chi", "") or bio_raw.get("eng", "")
        else:
            bio = bio_raw or ""
        if bio:
            console.print(Panel(_strip_html(str(bio))[:500], title="自傳", style="dim"))

        # Projects — API uses `introduction` not `description`, `isInProgress` for ongoing
        projects = d.get("project", {}).get("formData", {}).get("projects", [])
        if projects:
            table = Table(title=f"專案作品 ({len(projects)})", show_lines=True)
            table.add_column("名稱", style="bold cyan", max_width=25)
            table.add_column("期間")
            table.add_column("連結", max_width=30)
            table.add_column("描述", max_width=40)
            for proj in projects:
                period = _format_duration(
                    proj.get("duration", {}),
                    proj.get("isInProgress", proj.get("stillWork")),
                )
                intro = _strip_html(proj.get("introduction") or proj.get("description") or "")[:80]
                table.add_row(proj.get("name", ""), period, proj.get("url", ""), intro)
            console.print(table)

        # Portfolio — may have attach.url for file downloads
        portfolios = d.get("portfolio", {}).get("formData", {}).get("portfolios", [])
        if portfolios:
            table = Table(title=f"作品集 ({len(portfolios)})", show_lines=True)
            table.add_column("標題", style="bold cyan", max_width=25)
            table.add_column("檔案名稱", max_width=30)
            table.add_column("下載連結", max_width=55)
            for pf in portfolios:
                title = pf.get("name") or pf.get("title") or ""
                attach = pf.get("attach", {})
                if isinstance(attach, dict) and attach.get("url"):
                    file_name = attach.get("name", "")
                    dl_url = attach["url"]
                    if dl_url.startswith("/"):
                        dl_url = f"https://pda.104.com.tw{dl_url}"
                    table.add_row(title, file_name, dl_url)
                else:
                    url = pf.get("url", "")
                    table.add_row(title, "", url)
            console.print(table)

        # Custom sections (custom1, custom2, custom3) — patents, publications, etc.
        for key in ("custom1", "custom2", "custom3"):
            custom = d.get(key, {}).get("formData", {}).get("custom", {})
            if not custom:
                continue
            section_name = custom.get("name", "")
            contents = custom.get("content", [])
            if not section_name and not contents:
                continue
            table = Table(title=section_name or "自訂區塊", show_lines=True)
            table.add_column("期間", width=18)
            table.add_column("說明", max_width=50)
            table.add_column("連結", max_width=35)
            for item in contents:
                period = _format_duration(
                    item.get("duration", {}),
                    "1" in (item.get("isInProgress") or []),
                )
                intro = _strip_html(item.get("introduction") or "")[:120]
                url = item.get("url", "")
                table.add_row(period, intro, url)
            console.print(table)

    def _render_md(data: dict) -> None:
        if data.get("_error") == "no_resume":
            click.echo("*暫無履歷資料*")
            return
        if data.get("_error") == "bad_index":
            click.echo(f"編號超出範圍，共 {data['_count']} 份履歷")
            return

        d = data.get("data", data)
        lines: list[str] = []

        # Header
        resume_info = d.get("resume", {})
        progress = d.get("progress", 0)
        name = resume_info.get("name", "履歷")
        lines.append(f"# {name}")
        lines.append(f"完成度: {progress}%")
        lines.append("")

        # Personal info
        info = d.get("info", {}).get("formData", {}).get("info", {})
        ac_info = d.get("ACData", {}).get("info", {})
        if info or ac_info:
            lines.append("## 個人資訊")
            lines.append("")
            _md_bullet(lines, "姓名", ac_info.get("name"))
            _md_bullet(lines, "Email", ac_info.get("email"))
            _md_bullet(lines, "性別", _extract_text(ac_info.get("gender")))
            _md_bullet(lines, "求職狀態", _extract_text(info.get("jobStatus")))
            _md_bullet(lines, "年齡", info.get("age"))
            _md_bullet(lines, "城市", _extract_text(info.get("city")))
            _md_bullet(lines, "手機", info.get("cellphone"))
            _md_bullet(lines, "座右銘", info.get("motto"))
            _md_bullet(lines, "人格特質", info.get("trait"))
            for n in range(1, 4):
                url = info.get(f"personalLink{n}Url")
                if url:
                    link_type = info.get(f"personalLink{n}Type", "")
                    _md_bullet(lines, f"連結{n}", f"{link_type}: {url}" if link_type else url)
            lines.append("")

        # Work experience
        exps = d.get("experience", {}).get("formData", {}).get("experiences", [])
        if exps:
            seniority = d.get("experience", {}).get("formData", {}).get("seniority", {})
            title = "工作經歷"
            if seniority:
                sen_text = seniority.get("text", "")
                if sen_text:
                    title += f" (年資: {sen_text})"
                else:
                    total = seniority.get("total", {})
                    if total:
                        title += f" (年資: {total.get('year', 0)}年{total.get('month', 0)}月)"
            lines.append(f"## {title}")
            lines.append("")
            for exp in exps:
                job_title = exp.get("jobName", "")
                company = exp.get("companyName", "")
                period = _format_duration(exp.get("duration", {}), exp.get("stillWork"))
                lines.append(f"### {job_title} @ {company}")
                if period:
                    lines.append(f"*{period}*")
                lines.append("")
                desc = _strip_html(exp.get("description") or "")
                if desc:
                    lines.append(desc)
                    lines.append("")

        # Education
        edus = d.get("education", {}).get("formData", {}).get("educations", [])
        if edus:
            lines.append("## 學歷")
            lines.append("")
            for edu in edus:
                dur = edu.get("duration", {})
                depts = edu.get("departments", [])
                dept_name = depts[0].get("name", "") if depts else ""
                sy = dur.get("startYear", "")
                ey = dur.get("endYear", "")
                period = f"{sy}-{ey}" if sy or ey else ""
                status = edu.get("status", {})
                status_text = status.get("text", "") if isinstance(status, dict) else str(status)
                highest = edu.get("highest", {})
                highest_text = highest.get("text", "") if isinstance(highest, dict) else str(highest)
                parts = [edu.get("name", "")]
                if dept_name:
                    parts.append(dept_name)
                if highest_text:
                    parts.append(highest_text)
                if period:
                    parts.append(period)
                if status_text:
                    parts.append(status_text)
                lines.append(f"- {' / '.join(p for p in parts if p)}")
            lines.append("")

        # Skills
        skills_data = d.get("skill", {}).get("formData", {}).get("skills", [])
        if skills_data:
            skills_list = skills_data if isinstance(skills_data, list) else list(skills_data.values())
            if skills_list:
                lines.append("## 技能")
                lines.append("")
                for group in skills_list:
                    if isinstance(group, dict):
                        cat = group.get("category", group.get("name", ""))
                        items = group.get("items", group.get("skills", group.get("tag", [])))
                        if isinstance(items, list):
                            names = ", ".join(i.get("name", i.get("text", str(i))) if isinstance(i, dict) else str(i) for i in items)
                        else:
                            names = str(items)
                        if cat or names:
                            lines.append(f"- **{cat}**: {names}")
                        desc = group.get("desc", "")
                        if desc:
                            lines.append(f"  {_strip_html(str(desc))}")
                lines.append("")

        # Certificates
        cert_data = d.get("certificate", {}).get("formData", {}).get("certificate", {})
        if isinstance(cert_data, dict):
            cert_list = cert_data.get("certificates", [])
            cert_others = cert_data.get("others", "")
        elif isinstance(cert_data, list):
            cert_list = cert_data
            cert_others = ""
        else:
            cert_list = []
            cert_others = str(cert_data) if cert_data else ""
        if cert_list or cert_others:
            lines.append("## 證照")
            lines.append("")
            for cert in cert_list:
                if isinstance(cert, dict):
                    name_str = cert.get("name", "")
                    issuer = cert.get("issuer", cert.get("org", ""))
                    date = cert.get("date", "")
                    parts = [name_str]
                    if issuer:
                        parts.append(issuer)
                    if date:
                        parts.append(date)
                    lines.append(f"- {' / '.join(p for p in parts if p)}")
                else:
                    lines.append(f"- {cert}")
            if cert_others:
                for line in str(cert_others).strip().splitlines():
                    line = line.strip()
                    if line:
                        lines.append(f"- {line}")
            lines.append("")

        # Languages
        lang_data = d.get("language", {}).get("formData", {}).get("languages", {})
        langs: list = []
        if isinstance(lang_data, dict):
            langs = lang_data.get("foreign", []) + lang_data.get("local", [])
        elif isinstance(lang_data, list):
            langs = lang_data
        if langs:
            lines.append("## 語言能力")
            lines.append("")
            for lang in langs:
                if isinstance(lang, dict):
                    lang_name = lang.get("type", lang.get("language", lang.get("name", "")))
                    if isinstance(lang_name, dict):
                        lang_name = lang_name.get("text", str(lang_name))
                    level = lang.get("level")
                    if level is not None and not any(lang.get(k) for k in ("listening", "speaking", "reading", "writing")):
                        level_text = _level_text(level)
                        lines.append(f"- **{lang_name}**: {level_text}")
                    else:
                        listen = _level_text(lang.get("listening"))
                        speak = _level_text(lang.get("speaking"))
                        read = _level_text(lang.get("reading"))
                        write = _level_text(lang.get("writing"))
                        lines.append(f"- **{lang_name}**: 聽{listen} / 說{speak} / 讀{read} / 寫{write}")
                else:
                    lines.append(f"- {lang}")
            lines.append("")

        # Job conditions
        jc = d.get("jobCondition", {}).get("formData", {}).get("jobCondition", {})
        if jc:
            lines.append("## 求職條件")
            lines.append("")
            _md_bullet(lines, "工作類型", _extract_text(jc.get("jobTimeType")))
            _md_bullet(lines, "上班時段", _extract_text(jc.get("jobTimePeriod")))
            salary = jc.get("salary", {})
            if salary:
                _md_bullet(lines, "期望薪資", _format_salary(jc))
            areas = jc.get("preferArea", [])
            if areas:
                area_names = ", ".join((a.get("name") or a.get("des") or str(a)) if isinstance(a, dict) else str(a) for a in areas)
                _md_bullet(lines, "期望地區", area_names)
            titles = jc.get("preferJobTitle", [])
            if titles:
                if isinstance(titles, str):
                    title_names = titles
                elif isinstance(titles, list):
                    title_names = ", ".join(t.get("name", str(t)) if isinstance(t, dict) else str(t) for t in titles)
                else:
                    title_names = str(titles)
                _md_bullet(lines, "期望職稱", title_names)
            _md_bullet(lines, "遠端工作", _extract_text(jc.get("remoteWork")))
            lines.append("")

        # Bio
        bio_raw = d.get("bio", {}).get("formData", {}).get("bio", "")
        if isinstance(bio_raw, dict):
            bio = bio_raw.get("chi", "") or bio_raw.get("eng", "")
        else:
            bio = bio_raw or ""
        if bio:
            lines.append("## 自傳")
            lines.append("")
            lines.append(_strip_html(str(bio)))
            lines.append("")

        # Projects
        projects = d.get("project", {}).get("formData", {}).get("projects", [])
        if projects:
            lines.append("## 專案作品")
            lines.append("")
            for proj in projects:
                lines.append(f"### {proj.get('name', '')}")
                period = _format_duration(
                    proj.get("duration", {}),
                    proj.get("isInProgress", proj.get("stillWork")),
                )
                if period:
                    lines.append(f"*{period}*")
                url = proj.get("url", "")
                if url:
                    lines.append(f"連結: {url}")
                lines.append("")
                intro = _strip_html(proj.get("introduction") or proj.get("description") or "")
                if intro:
                    lines.append(intro)
                    lines.append("")

        # Portfolio
        portfolios = d.get("portfolio", {}).get("formData", {}).get("portfolios", [])
        if portfolios:
            lines.append("## 作品集")
            lines.append("")
            for pf in portfolios:
                title = pf.get("name") or pf.get("title") or ""
                attach = pf.get("attach", {})
                if isinstance(attach, dict) and attach.get("url"):
                    file_name = attach.get("name", "") or title
                    dl_url = attach["url"]
                    if dl_url.startswith("/"):
                        dl_url = f"https://pda.104.com.tw{dl_url}"
                    lines.append(f"- [{file_name}]({dl_url})")
                else:
                    url = pf.get("url", "")
                    if url:
                        lines.append(f"- [{title}]({url})")
                    else:
                        lines.append(f"- {title}")
            lines.append("")

        # Custom sections
        for key in ("custom1", "custom2", "custom3"):
            custom = d.get(key, {}).get("formData", {}).get("custom", {})
            if not custom:
                continue
            section_name = custom.get("name", "")
            contents = custom.get("content", [])
            if not section_name and not contents:
                continue
            lines.append(f"## {section_name or '自訂區塊'}")
            lines.append("")
            for item in contents:
                period = _format_duration(
                    item.get("duration", {}),
                    "1" in (item.get("isInProgress") or []),
                )
                intro = _strip_html(item.get("introduction") or "")
                url = item.get("url", "")
                if period:
                    lines.append(f"*{period}*")
                if intro:
                    lines.append(intro)
                if url:
                    lines.append(f"連結: {url}")
                lines.append("")

        click.echo("\n".join(lines))

    handle_command(action=_action, render=_render, render_md=_render_md, as_json=as_json, as_yaml=as_yaml, as_md=as_md, credential=cred)


# -- viewers -----------------------------------------------------------------


@click.command()
@structured_output_options
def viewers(as_json: bool, as_yaml: bool, as_md: bool) -> None:
    """查看誰看過我的履歷"""
    cred = require_auth()

    def _action(c):
        return c.get_viewers()

    def _render(data: dict) -> None:
        items = data.get("data", [])
        if not items:
            console.print("[yellow]暫無公司瀏覽紀錄[/yellow]")
            return

        table = Table(title=f"誰看過我 ({len(items)})", show_lines=True)
        table.add_column("#", style="dim", width=4)
        table.add_column("公司", style="bold cyan", max_width=25)
        table.add_column("產業", style="green", max_width=20)
        table.add_column("地區", style="blue")
        table.add_column("職缺數", justify="right")
        table.add_column("瀏覽日期", style="dim")
        table.add_column("福利", max_width=30)

        for i, item in enumerate(items, 1):
            tags = item.get("tagNames", [])
            tag_text = ", ".join(tags[:3]) if tags else ""
            if len(tags) > 3:
                tag_text += f" +{len(tags) - 3}"
            table.add_row(
                str(i),
                item.get("custName", ""),
                item.get("industryDesc", ""),
                item.get("areaDesc", ""),
                str(item.get("jobCount", 0)),
                item.get("browseDate", ""),
                tag_text,
            )
        console.print(table)

    handle_command(action=_action, render=_render, as_json=as_json, as_yaml=as_yaml, credential=cred)


# -- follows -----------------------------------------------------------------


@click.command()
@structured_output_options
def follows(as_json: bool, as_yaml: bool, as_md: bool) -> None:
    """查看關注的公司"""
    cred = require_auth()

    def _action(c):
        return c.get_followed_companies()

    def _render(data: dict) -> None:
        items = data.get("data", [])
        if not items:
            console.print("[yellow]暫無關注的公司[/yellow]")
            return

        table = Table(title=f"我的關注 ({len(items)})", show_lines=True)
        table.add_column("#", style="dim", width=4)
        table.add_column("公司", style="bold cyan", max_width=25)
        table.add_column("產業", style="green", max_width=20)
        table.add_column("地區", style="blue")
        table.add_column("員工規模")
        table.add_column("職缺數", justify="right")
        table.add_column("關注職缺", justify="right")
        table.add_column("備註", style="dim", max_width=15)

        for i, item in enumerate(items, 1):
            table.add_row(
                str(i),
                item.get("custName", ""),
                item.get("industryDesc", ""),
                item.get("areaDesc", ""),
                item.get("employeeCountDesc", ""),
                str(item.get("jobCount", 0)),
                str(item.get("followedJobCount", 0)),
                item.get("memo", "") or "",
            )
        console.print(table)

    handle_command(action=_action, render=_render, as_json=as_json, as_yaml=as_yaml, credential=cred)


# -- history -----------------------------------------------------------------


@click.command()
@click.option("-p", "--page", default=1, type=int, help="頁碼 (預設: 1)")
@structured_output_options
def history(page: int, as_json: bool, as_yaml: bool, as_md: bool) -> None:
    """查看瀏覽過的職缺"""
    cred = require_auth()

    def _action(c):
        return c.get_browsing_history(page=page)

    def _render(data: dict) -> None:
        records = data.get("data", [])
        if isinstance(records, dict):
            records = records.get("list", [])
        if not records:
            console.print("[yellow]暫無瀏覽紀錄[/yellow]")
            return

        _save_job_index(records, source="history")

        table = Table(title="瀏覽紀錄", show_lines=True)
        table.add_column("#", style="dim", width=4)
        table.add_column("職缺", style="bold cyan", max_width=30)
        table.add_column("公司", style="green", max_width=20)
        table.add_column("地區", style="blue")
        table.add_column("瀏覽日期", style="dim")
        table.add_column("狀態")

        for i, rec in enumerate(records, 1):
            status_parts = []
            if rec.get("isApplied"):
                status_parts.append("[green]已應徵[/green]")
            if rec.get("isSaved"):
                status_parts.append("[cyan]已收藏[/cyan]")
            status_text = " ".join(status_parts) if status_parts else "-"

            table.add_row(
                str(i),
                rec.get("jobName", ""),
                rec.get("custName", ""),
                rec.get("areaDesc", ""),
                rec.get("viewDate", ""),
                status_text,
            )
        console.print(table)
        console.print("  [dim]使用 job104 show <編號> 查看職缺詳情[/dim]")

        _print_pagination_hint(data, page, "history")

    handle_command(action=_action, render=_render, as_json=as_json, as_yaml=as_yaml, credential=cred)


# -- recommend ---------------------------------------------------------------


@click.command()
@click.option("-p", "--page", default=1, type=int, help="頁碼 (預設: 1)")
@click.option(
    "-g",
    "--group",
    default="recommend",
    type=click.Choice(["recommend", "highchance"], case_sensitive=False),
    help="推薦類型 (預設: recommend)",
)
@structured_output_options
def recommend(page: int, group: str, as_json: bool, as_yaml: bool, as_md: bool) -> None:
    """查看專屬推薦工作"""
    cred = require_auth()

    def _action(c):
        return c.get_recommended_jobs(group=group, page=page)

    def _render(data: dict) -> None:
        jobs = data.get("data", [])
        if isinstance(jobs, dict):
            jobs = jobs.get("list", [])
        if not jobs:
            console.print("[yellow]暫無推薦工作[/yellow]")
            return

        _save_job_index(jobs, source="recommend")

        group_label = "AI 推薦" if group == "recommend" else "高度適配"
        pagination = data.get("metadata", {}).get("pagination", {})
        total = pagination.get("total", 0)
        title = f"專屬工作 - {group_label}"
        if total:
            title += f" (共 {total} 筆)"

        table = Table(title=title, show_lines=True)
        table.add_column("#", style="dim", width=4)
        table.add_column("職缺", style="bold cyan", max_width=30)
        table.add_column("公司", style="green", max_width=20)
        table.add_column("地區", style="blue")
        table.add_column("應徵人數", justify="right")
        table.add_column("狀態")

        for i, job in enumerate(jobs, 1):
            status_parts = []
            if job.get("isApplied"):
                status_parts.append("[green]已應徵[/green]")
            if job.get("isSave"):
                status_parts.append("[cyan]已收藏[/cyan]")
            status_text = " ".join(status_parts) if status_parts else "-"

            table.add_row(
                str(i),
                job.get("jobName", ""),
                job.get("custName", ""),
                job.get("jobAddrNoDesc", ""),
                str(job.get("applyCnt", "")),
                status_text,
            )
        console.print(table)
        console.print("  [dim]使用 job104 show <編號> 查看職缺詳情[/dim]")

        last_page = pagination.get("lastPage", 1)
        if page < last_page:
            console.print(f"  [dim]下一頁: job104 recommend -p {page + 1}[/dim]")

    handle_command(action=_action, render=_render, as_json=as_json, as_yaml=as_yaml, credential=cred)


# -- helpers -----------------------------------------------------------------


def _print_pagination_hint(data: dict, page: int, cmd: str) -> None:
    """Print pagination hint if more pages available."""
    pagination = data.get("metadata", {}).get("pagination", {})
    if pagination:
        last_page = pagination.get("lastPage", 1)
        if page < last_page:
            console.print(f"  [dim]下一頁: job104 {cmd} -p {page + 1}[/dim]")
            return
    total = data.get("totalCount", data.get("totalPage", 0))
    if total and page * 20 < (total if isinstance(total, int) else 999):
        console.print(f"  [dim]下一頁: job104 {cmd} -p {page + 1}[/dim]")


def _format_duration(dur: dict, still_work: bool | None = None) -> str:
    """Format a duration dict to 'YYYY/MM ~ YYYY/MM' or '~ 至今'."""
    if not dur:
        return ""

    def _month_val(m: object) -> str:
        """Extract month number from int or dict like {'des': '3月', 'no': 3}."""
        if isinstance(m, dict):
            m = m.get("no", m.get("des", ""))
        return f"{m:>02}" if isinstance(m, int) else str(m)

    start = f"{dur.get('startYear', '')}/{_month_val(dur.get('startMonth', ''))}" if dur.get("startYear") else ""
    if still_work:
        return f"{start} ~ 至今"
    end = f"{dur.get('endYear', '')}/{_month_val(dur.get('endMonth', ''))}" if dur.get("endYear") else ""
    return f"{start} ~ {end}" if start else end


def _add_info_row(table: Table, label: str, value: object) -> None:
    """Add a row to an info table, skipping empty values."""
    if value is None or value == "" or value == []:
        return
    text = _extract_text(value)
    if text:
        table.add_row(label, text)


def _extract_text(val: object) -> str | None:
    """Extract display text from a value that may be a dict with 'text'/'des' key."""
    if val is None:
        return None
    if isinstance(val, dict):
        return val.get("text") or val.get("des") or str(val)
    if isinstance(val, list):
        parts = []
        for v in val:
            if isinstance(v, dict):
                parts.append(v.get("text") or v.get("des") or str(v))
            else:
                parts.append(str(v))
        return ", ".join(parts)
    return str(val) if val else None


def _strip_html(text: str) -> str:
    """Strip HTML tags from text for terminal display."""
    if not text:
        return ""
    # Replace block-level tags with newlines
    text = re.sub(r"<br\s*/?>", "\n", text, flags=re.IGNORECASE)
    text = re.sub(r"</(?:p|div|li|tr|h[1-6])>", "\n", text, flags=re.IGNORECASE)
    # Remove all remaining HTML tags
    text = re.sub(r"<[^>]+>", "", text)
    # Decode common HTML entities
    text = text.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
    text = text.replace("&nbsp;", " ").replace("&quot;", '"')
    # Collapse multiple blank lines
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def _format_salary(jc: dict) -> str:
    """Format salary from job condition, handling complex nested structures."""
    salary = jc.get("salary", {})
    if not salary:
        return ""
    # Simple min/max format
    if isinstance(salary, dict) and ("min" in salary or "max" in salary):
        return f"{salary.get('min', '')}-{salary.get('max', '')}"
    # Complex API format: salary.text + salaryOfMonth
    sal_text = _extract_text(salary) if isinstance(salary, dict) else str(salary)
    salary_of_month = jc.get("salaryOfMonth", {})
    if isinstance(salary_of_month, dict):
        ten_k = salary_of_month.get("unitOfTenThousand", {})
        thousand = salary_of_month.get("unitOfThousand", {})
        parts = []
        if isinstance(ten_k, dict) and ten_k.get("text"):
            parts.append(ten_k["text"])
        if isinstance(thousand, dict) and thousand.get("text") and thousand["text"] != "0千":
            parts.append(thousand["text"])
        if parts:
            return "".join(parts)
    period = jc.get("salaryPeriod", {})
    if isinstance(period, dict) and period.get("text"):
        return f"{period['text']} {sal_text}"
    return sal_text or ""


def _md_bullet(lines: list[str], label: str, value: object) -> None:
    """Append a Markdown bullet if value is non-empty."""
    if value is None or value == "" or value == []:
        return
    text = _extract_text(value)
    if text:
        lines.append(f"- **{label}**: {text}")


def _level_text(val: object) -> str:
    """Convert a language proficiency level to display text."""
    if val is None:
        return "-"
    if isinstance(val, dict):
        return val.get("text", str(val.get("value", "-")))
    return str(val)


def _save_job_index(records: list[dict], source: str) -> None:
    """Save job records to index cache, normalizing field names as needed."""
    normalized = []
    for rec in records:
        job_id = rec.get("jobId", "")
        if not job_id:
            link = rec.get("link", {})
            if isinstance(link, dict):
                job_url = link.get("job", "")
                if job_url:
                    job_id = job_url.rstrip("/").split("/")[-1]
        if not job_id:
            job_no = rec.get("jobNo", "")
            if job_no:
                job_id = str(job_no)

        normalized.append(
            {
                "jobId": job_id,
                "jobNo": str(rec.get("jobNo", "")),
                "jobName": rec.get("jobName", rec.get("job", {}).get("jobName", "")),
                "custName": rec.get("custName", rec.get("company", {}).get("name", "")),
                "salaryLow": rec.get("salaryLow", 0),
                "salaryHigh": rec.get("salaryHigh", 0),
                "salaryDesc": rec.get("salaryDesc", ""),
                "jobAddrNoDesc": rec.get("jobAddrNoDesc", ""),
                "optionEdu": rec.get("optionEdu", []),
                "optionExp": rec.get("optionExp", ""),
                "tags": rec.get("tags", {}),
            }
        )

    if normalized:
        save_index(normalized, source=source)
