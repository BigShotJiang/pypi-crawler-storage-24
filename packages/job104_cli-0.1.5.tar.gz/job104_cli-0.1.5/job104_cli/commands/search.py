"""Search and browse commands: search, detail, show, export, areas."""

from __future__ import annotations

import csv
import io
import json
import logging

import click
from rich.panel import Panel
from rich.table import Table

from ..client import Job104Client, list_areas, resolve_area
from ..constants import (
    COMPANY_ZONE_CODES,
    EDU_CODES,
    EDU_DISPLAY,
    EXP_CODES,
    INDCAT_CODES,
    ISNEW_CODES,
    JOB_TYPE_CODES,
    JOBCAT_CODES,
    MATCH_MODE_CODES,
    ORDER_CODES,
    REMOTE_CODES,
    ROSTATUS_CODES,
    SALARY_TYPE_CODES,
    SCHEDULE_CODES,
)
from ..exceptions import Job104ApiError
from ..index_cache import get_index_info, get_job_by_index, save_index
from ..models import Job
from ._common import console, handle_command, structured_output_options

logger = logging.getLogger(__name__)


# -- Helper: format fields for display ---------------------------------------


def _format_salary(job: dict) -> str:
    """Format salary from new API fields (salaryLow/salaryHigh)."""
    low = job.get("salaryLow", 0)
    high = job.get("salaryHigh", 0)
    if low and high:
        return f"{low:,} ~ {high:,}"
    elif low:
        return f"{low:,} 以上"
    return job.get("salaryDesc", "面議")


def _format_tags(job: dict) -> str:
    """Format tags from new API format (dict or list)."""
    raw_tags = job.get("tags", {})
    if isinstance(raw_tags, dict):
        return ", ".join(t.get("desc", k) for k, t in list(raw_tags.items())[:4])
    elif isinstance(raw_tags, list):
        return ", ".join(raw_tags[:4])
    return "-"


def _format_edu(job: dict) -> str:
    """Format education from new API format (list of ints)."""
    raw_edu = job.get("optionEdu", "-")
    if isinstance(raw_edu, list):
        return "/".join(EDU_DISPLAY.get(e, str(e)) for e in raw_edu)
    elif isinstance(raw_edu, str):
        return raw_edu
    return "-"


def _resolve_cat_code(value: str, lookup: dict[str, str], label: str) -> str:
    """Resolve a category label to its code, or passthrough if numeric."""
    if value.isdigit():
        return value
    code = lookup.get(value)
    if not code:
        console.print(f"[yellow]找不到{label}: {value!r}。使用 job104 categories / industries 查看可用選項。[/yellow]")
        raise SystemExit(1)
    return code


def _extract_job_id(job: dict) -> str:
    """Extract URL hash ID from job link (e.g. '8z5sl')."""
    link = job.get("link", {})
    job_url = link.get("job", "") if isinstance(link, dict) else ""
    if job_url:
        return job_url.rstrip("/").split("/")[-1]
    return ""


# -- Helper: render job table ------------------------------------------------


def _to_jobs(raw_list: list[dict]) -> list[Job]:
    """Convert raw API dicts to Job model instances."""
    return [Job.from_search_result(r) for r in raw_list]


def _render_job_table(
    job_list: list[dict],
    title: str,
    page: int = 1,
    hint_next: str = "",
) -> None:
    """Render a list of jobs as a rich table and save to index cache."""
    if not job_list:
        console.print("[yellow]沒有找到符合的職缺[/yellow]")
        return

    jobs = _to_jobs(job_list)
    save_index([j.to_dict() for j in jobs], source=title[:30])

    table = Table(title=f"{title} — {len(jobs)} 筆結果", show_lines=True)
    table.add_column("#", style="dim", width=3)
    table.add_column("職缺", style="bold cyan", max_width=30)
    table.add_column("公司", style="green", max_width=20)
    table.add_column("薪資", style="yellow", max_width=16)
    table.add_column("經驗", max_width=10)
    table.add_column("學歷", max_width=8)
    table.add_column("地區", style="blue", max_width=15)
    table.add_column("技能", style="dim", max_width=25)

    for i, job in enumerate(jobs, 1):
        table.add_row(
            str(i),
            job.job_name or "-",
            job.cust_name or "-",
            job.salary_desc or "面議",
            job.option_exp or "-",
            job.edu_desc or "-",
            job.location or "-",
            ", ".join(job.tags[:4]) if job.tags else "-",
        )

    console.print(table)
    console.print("  [dim]使用 job104 show <編號> 查看職缺詳情[/dim]")

    if hint_next:
        console.print(f"  [dim]{hint_next}[/dim]")


# -- search ------------------------------------------------------------------


@click.command()
@click.argument("keyword")
@click.option("-a", "--area", default="全部", help="地區名稱或代碼 (預設: 全部)")
@click.option("-p", "--page", default=1, type=int, help="頁碼 (預設: 1)")
@click.option("--order", type=click.Choice(list(ORDER_CODES.keys())), default=None, help="排序方式")
@click.option("--exp", type=click.Choice(list(EXP_CODES.keys())), default=None, help="工作經驗篩選")
@click.option("--edu", type=click.Choice(list(EDU_CODES.keys())), default=None, help="學歷篩選")
@click.option("--salary-type", type=click.Choice(list(SALARY_TYPE_CODES.keys())), default=None, help="薪資類型 (月薪/時薪/日薪)")
@click.option("--salary-low", type=int, default=None, help="最低薪資")
@click.option("--salary-high", type=int, default=None, help="最高薪資")
@click.option("--salary-strict", is_flag=True, default=False, help="僅顯示有明確薪資的職缺")
@click.option("--exclude-negotiable", is_flag=True, default=False, help="排除面議薪資的職缺")
@click.option("--isnew", type=click.Choice(list(ISNEW_CODES.keys())), default=None, help="刊登天數")
@click.option("--remote", type=click.Choice(list(REMOTE_CODES.keys())), default=None, help="遠端工作")
@click.option("--company-type", type=click.Choice(list(ROSTATUS_CODES.keys())), default=None, help="公司類型 (外商/上市上櫃)")
@click.option("--job-type", type=click.Choice(list(JOB_TYPE_CODES.keys())), default=None, help="職缺類型 (全職/兼職/高階/派遣)")
@click.option("--match-mode", type=click.Choice(list(MATCH_MODE_CODES.keys())), default=None, help="關鍵字比對模式 (僅標題/標題+描述/廣泛)")
@click.option(
    "--schedule", type=click.Choice(list(SCHEDULE_CODES.keys())), multiple=True, help="班別 (可多選: --schedule 日班 --schedule 夜班)"
)
@click.option("--exclude-kw", multiple=True, help="排除關鍵字 (可多選: --exclude-kw 管理 --exclude-kw 行政)")
@click.option("--exclude-indcat", multiple=True, help="排除產業類別 (名稱或代碼，可多選)")
@click.option("--jobcat", default=None, help="職務類別 (e.g. 軟體工程師, 資訊軟體系統類, or numeric code)")
@click.option("--indcat", default=None, help="產業類別 (e.g. 半導體業, 軟體及網路相關業, or numeric code)")
@structured_output_options
def search(
    keyword: str,
    area: str,
    page: int,
    order: str | None,
    exp: str | None,
    edu: str | None,
    salary_type: str | None,
    salary_low: int | None,
    salary_high: int | None,
    salary_strict: bool,
    exclude_negotiable: bool,
    isnew: str | None,
    remote: str | None,
    company_type: str | None,
    job_type: str | None,
    match_mode: str | None,
    schedule: tuple[str, ...],
    exclude_kw: tuple[str, ...],
    exclude_indcat: tuple[str, ...],
    jobcat: str | None,
    indcat: str | None,
    as_json: bool,
    as_yaml: bool,
    as_md: bool,
) -> None:
    """搜尋職缺 (例: job104 search Python --area 台北市)"""
    area_code = resolve_area(area)
    order_code = ORDER_CODES.get(order, "1") if order else "1"
    exp_code = EXP_CODES.get(exp) if exp else None
    edu_code = EDU_CODES.get(edu) if edu else None
    salary_type_code = SALARY_TYPE_CODES.get(salary_type) if salary_type else None
    isnew_code = ISNEW_CODES.get(isnew) if isnew else None
    remote_code = REMOTE_CODES.get(remote) if remote else None
    rostatus_code = ROSTATUS_CODES.get(company_type) if company_type else None
    kwop_code = MATCH_MODE_CODES.get(match_mode, "7") if match_mode else "7"
    ro_code = JOB_TYPE_CODES.get(job_type, "0") if job_type else "0"
    jobcat_code = _resolve_cat_code(jobcat, JOBCAT_CODES, "職務類別") if jobcat else None
    indcat_code = _resolve_cat_code(indcat, INDCAT_CODES, "產業類別") if indcat else None

    # Compute schedule as comma-separated values (API rejects bitmask OR)
    s9_code: str | None = None
    if schedule:
        s9_code = ",".join(SCHEDULE_CODES[s] for s in schedule)

    # Resolve exclude keywords and industry codes
    exclude_kw_str = ",".join(exclude_kw) if exclude_kw else None
    exclude_indcat_codes: list[str] = []
    for ei in exclude_indcat:
        exclude_indcat_codes.append(_resolve_cat_code(ei, INDCAT_CODES, "排除產業類別"))
    exclude_indcat_str = ",".join(exclude_indcat_codes) if exclude_indcat_codes else None

    def _action(c: Job104Client) -> dict:
        return c.search_jobs(
            keyword=keyword,
            area=area_code,
            page=page,
            order=order_code,
            jobexp=exp_code,
            edu=edu_code,
            salary_type=salary_type_code,
            salary_low=salary_low,
            salary_high=salary_high,
            isnew=isnew_code,
            remote=remote_code,
            rostatus=rostatus_code,
            jobcat=jobcat_code,
            indcat=indcat_code,
            kwop=kwop_code,
            ro=ro_code,
            s9=s9_code,
            scstrict=salary_strict,
            scneg=exclude_negotiable,
            exclude_kw=exclude_kw_str,
            exclude_indcat=exclude_indcat_str,
        )

    def _render(data: dict) -> None:
        job_list = data.get("list", [])

        filters = [area]
        for f in (exp, edu, salary_type, isnew, remote, job_type, match_mode):
            if f:
                filters.append(f)
        if schedule:
            filters.append("/".join(schedule))
        if salary_strict:
            filters.append("明確薪資")
        if exclude_negotiable:
            filters.append("排除面議")
        filter_str = " / ".join(filters)

        total = data.get("totalCount", "?")
        total_page = data.get("totalPage", "?")

        _render_job_table(
            job_list,
            title=f"搜尋: {keyword} ({filter_str}) [第 {page}/{total_page} 頁, 共 {total} 筆]",
            page=page,
            hint_next=f'更多結果: job104 search "{keyword}" --area {area} -p {page + 1}' if page < (data.get("totalPage") or 1) else "",
        )

    handle_command(action=_action, render=_render, as_json=as_json, as_yaml=as_yaml, as_md=as_md)


# -- detail ------------------------------------------------------------------


@click.command()
@click.argument("job_id")
@structured_output_options
def detail(job_id: str, as_json: bool, as_yaml: bool, as_md: bool) -> None:
    """查看職缺詳情 (使用 URL hash，例: job104 detail 8z5sl)"""

    def _action(c: Job104Client) -> dict:
        return c.get_job_detail(job_id=job_id)

    handle_command(action=_action, render=_render_detail, as_json=as_json, as_yaml=as_yaml, as_md=as_md)


# -- show (short-index) ------------------------------------------------------


@click.command()
@click.argument("index", type=int)
@structured_output_options
def show(index: int, as_json: bool, as_yaml: bool, as_md: bool) -> None:
    """按搜尋結果編號查看職缺詳情 (例: job104 show 3)

    使用 search 命令後，可用編號快速查看詳情。
    """
    job = get_job_by_index(index)
    if not job:
        info = get_index_info()
        if not info.get("exists"):
            console.print("[yellow]暫無快取的搜尋結果，請先執行 job104 search[/yellow]")
        else:
            console.print(f"[yellow]編號 {index} 超出範圍 (共 {info.get('count', 0)} 筆結果)[/yellow]")
        return

    job_id = job.get("jobId", "")
    if not job_id:
        # Fallback: try extracting from link
        job_id = _extract_job_id(job)
    if not job_id:
        console.print("[red]該職缺缺少 jobId (URL hash)[/red]")
        return

    salary_str = job.get("salary", "") or _format_salary(job)
    console.print(
        f"  [dim]#{index}[/dim] [cyan]{job.get('jobName', '-')}[/cyan] @ "
        f"[green]{job.get('custName', '-')}[/green]  "
        f"[yellow]{salary_str}[/yellow]"
    )
    console.print()

    def _action(c: Job104Client) -> dict:
        return c.get_job_detail(job_id=job_id)

    handle_command(action=_action, render=_render_detail, as_json=as_json, as_yaml=as_yaml, as_md=as_md)


def _render_detail(data: dict) -> None:
    """Render job detail panel (shared by detail and show commands)."""
    header = data.get("header", {})
    job_detail = data.get("jobDetail", {})
    condition = data.get("condition", {})
    welfare = data.get("welfare", {})

    title = header.get("jobName", "-")
    salary = header.get("salaryDesc", "-")
    company = header.get("custName", "-")

    exp = condition.get("workExp", "-")
    edu = condition.get("edu", "-")
    region = job_detail.get("addressRegion", "-")
    address = job_detail.get("addressDetail", "")

    categories = job_detail.get("jobCategory", [])
    cat_str = ", ".join(c.get("desc", "") for c in categories) if categories else "-"

    specialties = condition.get("specialty", [])
    spec_str = ", ".join(s.get("desc", "") for s in specialties) if specialties else "-"

    desc = job_detail.get("jobDescription", "")
    welfare_text = welfare.get("welfare", "")

    # Build industry/scale from header if available
    industry = data.get("industry", header.get("coIndustryDesc", "-"))
    if isinstance(industry, list):
        industry = ", ".join(industry)

    panel_text = (
        f"[bold cyan]{title}[/bold cyan]  [yellow]{salary}[/yellow]\n"
        f"經驗: {exp} / 學歷: {edu} / 地區: {region}\n"
        f"地址: {address}\n"
        f"職務類別: {cat_str}\n"
        f"專長技能: {spec_str}\n"
        f"\n"
        f"[bold green]公司:[/bold green] {company}\n"
        f"產業: {industry}\n"
    )

    if desc:
        if len(desc) > 800:
            desc = desc[:800] + "..."
        panel_text += f"\n[bold]職缺描述:[/bold]\n{desc}"

    if welfare_text:
        if len(welfare_text) > 300:
            welfare_text = welfare_text[:300] + "..."
        panel_text += f"\n\n[bold]福利制度:[/bold]\n{welfare_text}"

    panel = Panel(panel_text, title="職缺詳情", border_style="cyan")
    console.print(panel)


# -- export ------------------------------------------------------------------


@click.command()
@click.argument("keyword")
@click.option("-a", "--area", default="全部", help="地區名稱或代碼")
@click.option("-n", "--count", default=30, type=int, help="匯出數量 (預設: 30)")
@click.option("--order", type=click.Choice(list(ORDER_CODES.keys())), default=None, help="排序方式")
@click.option("--exp", type=click.Choice(list(EXP_CODES.keys())), default=None, help="工作經驗篩選")
@click.option("--edu", type=click.Choice(list(EDU_CODES.keys())), default=None, help="學歷篩選")
@click.option("--salary-type", type=click.Choice(list(SALARY_TYPE_CODES.keys())), default=None, help="薪資類型 (月薪/時薪/日薪)")
@click.option("--salary-low", type=int, default=None, help="最低薪資")
@click.option("--salary-high", type=int, default=None, help="最高薪資")
@click.option("--salary-strict", is_flag=True, default=False, help="僅顯示有明確薪資的職缺")
@click.option("--exclude-negotiable", is_flag=True, default=False, help="排除面議薪資的職缺")
@click.option("--isnew", type=click.Choice(list(ISNEW_CODES.keys())), default=None, help="刊登天數")
@click.option("--remote", type=click.Choice(list(REMOTE_CODES.keys())), default=None, help="遠端工作")
@click.option("--company-type", type=click.Choice(list(ROSTATUS_CODES.keys())), default=None, help="公司類型 (外商/上市上櫃)")
@click.option("--job-type", type=click.Choice(list(JOB_TYPE_CODES.keys())), default=None, help="職缺類型 (全職/兼職/高階/派遣)")
@click.option("--match-mode", type=click.Choice(list(MATCH_MODE_CODES.keys())), default=None, help="關鍵字比對模式")
@click.option("--schedule", type=click.Choice(list(SCHEDULE_CODES.keys())), multiple=True, help="班別 (可多選)")
@click.option("--exclude-kw", multiple=True, help="排除關鍵字 (可多選)")
@click.option("--exclude-indcat", multiple=True, help="排除產業類別 (名稱或代碼，可多選)")
@click.option("--jobcat", default=None, help="職務類別 (e.g. 軟體工程師, or numeric code)")
@click.option("--indcat", default=None, help="產業類別 (e.g. 半導體業, or numeric code)")
@click.option("-o", "--output", "output_file", default=None, help="輸出檔案路徑 (預設: stdout)")
@click.option("--format", "fmt", type=click.Choice(["csv", "json"]), default="csv", help="輸出格式")
def export(
    keyword: str,
    area: str,
    count: int,
    order: str | None,
    exp: str | None,
    edu: str | None,
    salary_type: str | None,
    salary_low: int | None,
    salary_high: int | None,
    salary_strict: bool,
    exclude_negotiable: bool,
    isnew: str | None,
    remote: str | None,
    company_type: str | None,
    job_type: str | None,
    match_mode: str | None,
    schedule: tuple[str, ...],
    exclude_kw: tuple[str, ...],
    exclude_indcat: tuple[str, ...],
    jobcat: str | None,
    indcat: str | None,
    output_file: str | None,
    fmt: str,
) -> None:
    """匯出搜尋結果為 CSV 或 JSON

    例: job104 export "Python" --area 台北市 -n 50 -o jobs.csv
    """
    area_code = resolve_area(area)
    order_code = ORDER_CODES.get(order, "1") if order else "1"
    exp_code = EXP_CODES.get(exp) if exp else None
    edu_code = EDU_CODES.get(edu) if edu else None
    salary_type_code = SALARY_TYPE_CODES.get(salary_type) if salary_type else None
    isnew_code = ISNEW_CODES.get(isnew) if isnew else None
    remote_code = REMOTE_CODES.get(remote) if remote else None
    rostatus_code = ROSTATUS_CODES.get(company_type) if company_type else None
    kwop_code = MATCH_MODE_CODES.get(match_mode, "7") if match_mode else "7"
    ro_code = JOB_TYPE_CODES.get(job_type, "0") if job_type else "0"
    jobcat_code = _resolve_cat_code(jobcat, JOBCAT_CODES, "職務類別") if jobcat else None
    indcat_code = _resolve_cat_code(indcat, INDCAT_CODES, "產業類別") if indcat else None

    s9_code: str | None = None
    if schedule:
        s9_code = ",".join(SCHEDULE_CODES[s] for s in schedule)

    exclude_kw_str = ",".join(exclude_kw) if exclude_kw else None
    exclude_indcat_codes: list[str] = []
    for ei in exclude_indcat:
        exclude_indcat_codes.append(_resolve_cat_code(ei, INDCAT_CODES, "排除產業類別"))
    exclude_indcat_str = ",".join(exclude_indcat_codes) if exclude_indcat_codes else None

    all_jobs: list[dict] = []
    page_size = 20
    pages_needed = (count + page_size - 1) // page_size

    try:
        with Job104Client() as client:
            for pg in range(1, pages_needed + 1):
                data = client.search_jobs(
                    keyword=keyword,
                    area=area_code,
                    page=pg,
                    order=order_code,
                    jobexp=exp_code,
                    edu=edu_code,
                    salary_type=salary_type_code,
                    salary_low=salary_low,
                    salary_high=salary_high,
                    isnew=isnew_code,
                    remote=remote_code,
                    rostatus=rostatus_code,
                    jobcat=jobcat_code,
                    indcat=indcat_code,
                    kwop=kwop_code,
                    ro=ro_code,
                    s9=s9_code,
                    scstrict=salary_strict,
                    scneg=exclude_negotiable,
                    exclude_kw=exclude_kw_str,
                    exclude_indcat=exclude_indcat_str,
                )
                job_list = data.get("list", [])
                all_jobs.extend(job_list)
                console.print(f"  [dim]第 {pg} 頁: {len(job_list)} 筆職缺 (累計: {len(all_jobs)})[/dim]")

                total_page = data.get("totalPage", 1)
                if pg >= total_page or len(all_jobs) >= count:
                    break

        all_jobs = all_jobs[:count]
        jobs = _to_jobs(all_jobs)

        if fmt == "json":
            output_text = json.dumps([j.to_dict() for j in jobs], indent=2, ensure_ascii=False)
        else:
            buf = io.StringIO()
            fieldnames = [
                "職缺",
                "公司",
                "產業",
                "薪資",
                "薪資下限",
                "薪資上限",
                "經驗",
                "學歷",
                "地區",
                "技能",
                "應徵人數",
                "職缺連結",
                "jobNo",
            ]
            writer = csv.DictWriter(buf, fieldnames=fieldnames, extrasaction="ignore")
            writer.writeheader()
            for job in jobs:
                writer.writerow(
                    {
                        "職缺": job.job_name,
                        "公司": job.cust_name,
                        "產業": job.industry,
                        "薪資": job.salary_desc,
                        "薪資下限": job.salary_low or "",
                        "薪資上限": job.salary_high or "",
                        "經驗": job.option_exp,
                        "學歷": job.edu_desc,
                        "地區": job.location,
                        "技能": ", ".join(job.tags) if job.tags else "",
                        "應徵人數": job.apply_cnt or "",
                        "職缺連結": job.job_url,
                        "jobNo": job.job_no,
                    }
                )
            output_text = buf.getvalue()

        if output_file:
            with open(output_file, "w", encoding="utf-8-sig" if fmt == "csv" else "utf-8") as f:
                f.write(output_text)
            console.print(f"\n[green]已匯出 {len(all_jobs)} 筆職缺到 {output_file}[/green]")
        else:
            click.echo(output_text)

    except Job104ApiError as exc:
        console.print(f"[red]匯出失敗: {exc}[/red]")
        raise SystemExit(1) from None


# -- company -----------------------------------------------------------------


@click.command()
@click.argument("keyword", default="")
@click.option("-a", "--area", default="全部", help="地區名稱或代碼")
@click.option("--zone", type=click.Choice(list(COMPANY_ZONE_CODES.keys())), default=None, help="公司類型 (外商/上市上櫃)")
@click.option("-p", "--page", default=1, type=int, help="頁碼")
@structured_output_options
def company(keyword: str, area: str, zone: str | None, page: int, as_json: bool, as_yaml: bool, as_md: bool) -> None:
    """搜尋公司 (例: job104 company "Google" --zone 外商)"""
    area_code = resolve_area(area)
    zone_code = COMPANY_ZONE_CODES.get(zone) if zone else ""

    def _action(c: Job104Client) -> dict:
        return c.search_companies(
            keyword=keyword,
            zone=zone_code,
            area=area_code,
            page=page,
        )

    def _render(data: dict) -> None:
        companies = data.get("data", [])
        pagination = data.get("metadata", {}).get("pagination", {})
        total = pagination.get("total", len(companies))

        if not companies:
            console.print("[yellow]沒有找到符合的公司[/yellow]")
            return

        table = Table(title=f"公司搜尋: {keyword or '(全部)'} — 共 {total} 筆", show_lines=True)
        table.add_column("#", style="dim", width=3)
        table.add_column("公司名稱", style="bold cyan", max_width=35)
        table.add_column("產業", style="green", max_width=20)
        table.add_column("位置", max_width=12)
        table.add_column("員工數", max_width=10)
        table.add_column("資本額", max_width=12)
        table.add_column("職缺", max_width=6)
        table.add_column("公司頁面", style="dim", max_width=50)

        for i, co in enumerate(companies, 1):
            cust_no = co.get("encodedCustNo", "")
            company_url = f"https://www.104.com.tw/company/{cust_no}" if cust_no else "-"
            table.add_row(
                str(i),
                co.get("name", "-"),
                co.get("industryDesc", "-"),
                co.get("areaDesc", "-"),
                co.get("employeeCountDesc", "-"),
                co.get("capitalDesc", "-"),
                str(co.get("jobCount", 0)),
                company_url,
            )

        console.print(table)

    handle_command(action=_action, render=_render, as_json=as_json, as_yaml=as_yaml, as_md=as_md)


# -- suggest -----------------------------------------------------------------


@click.command()
@click.argument("keyword")
@structured_output_options
def suggest(keyword: str, as_json: bool, as_yaml: bool, as_md: bool) -> None:
    """關鍵字自動完成建議 (例: job104 suggest 軟體)"""
    if not keyword.strip():
        console.print("[yellow]請提供搜尋關鍵字[/yellow]")
        return

    def _action(c: Job104Client) -> dict:
        return c.suggest_keywords(keyword=keyword)

    def _render(data: dict) -> None:
        # Response may contain keyword suggestions and company suggestions
        kw_list = data.get("keywordList", data.get("keywords", []))
        co_list = data.get("companyList", data.get("companies", []))

        if not kw_list and not co_list:
            console.print(f"[yellow]找不到「{keyword}」的建議[/yellow]")
            return

        if kw_list:
            table = Table(title=f"關鍵字建議: {keyword}", show_lines=False)
            table.add_column("#", style="dim", width=3)
            table.add_column("關鍵字", style="cyan", max_width=40)
            for i, kw in enumerate(kw_list, 1):
                name = kw.get("keyword", kw) if isinstance(kw, dict) else str(kw)
                table.add_row(str(i), name)
            console.print(table)

        if co_list:
            table = Table(title=f"公司建議: {keyword}", show_lines=False)
            table.add_column("#", style="dim", width=3)
            table.add_column("公司名稱", style="green", max_width=40)
            for i, co in enumerate(co_list, 1):
                name = co.get("name", co) if isinstance(co, dict) else str(co)
                table.add_row(str(i), name)
            console.print(table)

    handle_command(action=_action, render=_render, as_json=as_json, as_yaml=as_yaml, as_md=as_md)


# -- categories --------------------------------------------------------------


@click.command()
@click.option("--all", "show_all", is_flag=True, default=False, help="顯示全部類別（含子分類與職稱）")
def categories(show_all: bool) -> None:
    """列出支援的職務類別代碼"""
    table = Table(title="支援的職務類別", show_lines=False)
    table.add_column("類別", style="cyan", max_width=30)
    table.add_column("代碼", style="dim", width=14)
    table.add_column("層級", style="dim", width=4)

    for name, code in JOBCAT_CODES.items():
        if code.endswith("000000"):
            table.add_row(f"[bold]{name}[/bold]", code, "L0")
        elif code.endswith("000"):
            if show_all:
                table.add_row(f"  {name}", code, "L1")
        else:
            if show_all:
                table.add_row(f"    {name}", code, "L2")

    console.print(table)
    l0_count = sum(1 for c in JOBCAT_CODES.values() if c.endswith("000000"))
    console.print(f"\n  [dim]共 {len(JOBCAT_CODES)} 個類別 ({l0_count} 大類)。[/dim]")
    if not show_all:
        console.print("  [dim]使用 --all 顯示全部子分類與職稱[/dim]")
    console.print('  [dim]使用: job104 search "Python" --jobcat 軟體工程師[/dim]')


@click.command()
@click.option("--all", "show_all", is_flag=True, default=False, help="顯示全部類別（含子分類）")
def industries(show_all: bool) -> None:
    """列出支援的產業類別代碼"""
    table = Table(title="支援的產業類別", show_lines=False)
    table.add_column("產業", style="cyan", max_width=30)
    table.add_column("代碼", style="dim", width=14)
    table.add_column("層級", style="dim", width=4)

    for name, code in INDCAT_CODES.items():
        if code.endswith("000000"):
            table.add_row(f"[bold]{name}[/bold]", code, "L0")
        elif code.endswith("000"):
            if show_all:
                table.add_row(f"  {name}", code, "L1")
        else:
            if show_all:
                table.add_row(f"    {name}", code, "L2")

    console.print(table)
    l0_count = sum(1 for c in INDCAT_CODES.values() if c.endswith("000000"))
    console.print(f"\n  [dim]共 {len(INDCAT_CODES)} 個類別 ({l0_count} 大類)。[/dim]")
    if not show_all:
        console.print("  [dim]使用 --all 顯示全部子分類[/dim]")
    console.print('  [dim]使用: job104 search "Python" --indcat 半導體業[/dim]')


# -- areas -------------------------------------------------------------------


@click.command()
def areas() -> None:
    """列出支援的地區代碼"""
    codes = list_areas()
    table = Table(title="支援的地區", show_lines=False)
    table.add_column("地區", style="cyan", width=10)
    table.add_column("代碼", style="dim", width=14)

    for name, code in codes.items():
        if code:
            table.add_row(name, code)
        else:
            table.add_row(name, "(全部)")

    console.print(table)
    console.print(f'\n  [dim]共 {len(codes)} 個地區。使用: job104 search "Python" --area 台北市[/dim]')
