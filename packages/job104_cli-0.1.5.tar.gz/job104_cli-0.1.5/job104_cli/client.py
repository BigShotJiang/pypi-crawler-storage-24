"""API client for 104 Job Bank with rate limiting, retry, and anti-detection."""

from __future__ import annotations

import logging
import random
import time
from collections import deque
from typing import Any

import httpx

from .constants import (
    AREA_CODES,
    BASE_URL,
    COMPANY_SEARCH_URL,
    DEFAULT_SEARCH_PARAMS,
    HEADERS,
    JOB_DETAIL_URL,
    JOB_REFERER,
    KEYWORD_SUGGEST_URL,
    PDA_AC_COMPANY,
    PDA_AC_JOB_TITLE,
    PDA_AC_MAJOR,
    PDA_AC_SCHOOL,
    PDA_AC_SKILL,
    PDA_BASE_URL,
    PDA_RESUME_BLOCK,
    PDA_RESUME_INPUT_FIELD,
    PDA_RESUME_OPTIONS,
    SEARCH_REFERER,
    SEARCH_URL,
)
from .exceptions import Job104ApiError, ResumeWriteError

logger = logging.getLogger(__name__)


def _extract_option_text(val: object) -> str | None:
    """Extract display text from a 104 API option value (may be dict with 'text'/'des')."""
    if val is None:
        return None
    if isinstance(val, dict):
        return val.get("text") or val.get("des") or str(val)
    if isinstance(val, list):
        parts = [_extract_option_text(v) for v in val]
        return ", ".join(p for p in parts if p) or None
    return str(val)


class Job104Client:
    """104 Job Bank API client with Gaussian jitter, exponential backoff, and browser-like identity.

    Anti-detection strategy:
    - Gaussian jitter delay between requests (~1s mean, sigma=0.3)
    - 5% chance of a random long pause (2-5s) to mimic reading behavior
    - Exponential backoff on HTTP 429/5xx (up to 3 retries)
    - Correct Referer header (critical for 104)
    - Response cookies merged back into session jar
    """

    def __init__(
        self,
        credential: object | None = None,
        timeout: float = 30.0,
        request_delay: float = 1.0,
        max_retries: int = 3,
    ):
        self.credential = credential
        self._timeout = timeout
        self._request_delay = request_delay
        self._base_request_delay = request_delay
        self._max_retries = max_retries
        self._last_request_time = 0.0
        self._request_count = 0
        self._rate_limit_count = 0
        self._recent_request_times: deque[float] = deque(maxlen=12)
        self._http: httpx.Client | None = None
        self._cf_warmed: bool = False

    def _build_client(self) -> httpx.Client:
        cookies = {}
        if self.credential and hasattr(self.credential, "cookies"):
            cookies = self.credential.cookies
        return httpx.Client(
            base_url=BASE_URL,
            headers=dict(HEADERS),
            cookies=cookies,
            follow_redirects=True,
            timeout=httpx.Timeout(self._timeout),
        )

    @property
    def client(self) -> httpx.Client:
        if not self._http:
            raise RuntimeError("Client not initialized. Use 'with Job104Client() as client:'")
        return self._http

    def __enter__(self) -> Job104Client:
        self._http = self._build_client()
        return self

    def __exit__(self, *args: Any) -> None:
        if self._http:
            self._http.close()
            self._http = None

    # -- Rate limiting -------------------------------------------------------

    def _rate_limit_delay(self) -> None:
        """Enforce minimum delay with Gaussian jitter to mimic human browsing."""
        if self._request_delay <= 0:
            return
        elapsed = time.time() - self._last_request_time
        if elapsed < self._request_delay:
            jitter = max(0, random.gauss(0.3, 0.15))
            if random.random() < 0.05:
                jitter += random.uniform(2.0, 5.0)
            sleep_time = self._request_delay - elapsed + jitter
            logger.debug("Rate-limit delay: %.2fs", sleep_time)
            time.sleep(sleep_time)

        burst_penalty = self._burst_penalty_delay()
        if burst_penalty > 0:
            logger.debug("Burst penalty delay: %.2fs", burst_penalty)
            time.sleep(burst_penalty)

    def _burst_penalty_delay(self) -> float:
        """Add extra delay when a burst pattern looks less like human browsing."""
        if not self._recent_request_times:
            return 0.0

        now = time.time()
        recent_15s = sum(1 for ts in self._recent_request_times if now - ts <= 15)
        recent_45s = sum(1 for ts in self._recent_request_times if now - ts <= 45)

        if recent_45s >= 6:
            return random.uniform(4.0, 7.0)
        if recent_15s >= 3:
            return random.uniform(1.2, 2.8)
        return 0.0

    def _mark_request(self) -> None:
        now = time.time()
        self._last_request_time = now
        self._request_count += 1
        self._recent_request_times.append(now)

    # -- Cloudflare warmup ---------------------------------------------------

    def _ensure_cf_cookies(self) -> None:
        """Lazy Cloudflare warmup — visit search page to acquire CF cookies."""
        if self._cf_warmed:
            return
        self._rate_limit_delay()
        try:
            resp = self.client.get(
                "/jobs/search/",
                headers={**dict(HEADERS), "Referer": f"{BASE_URL}/"},
            )
            self._merge_response_cookies(resp)
        except Exception:
            logger.debug("CF warmup request failed, proceeding anyway")
        self._mark_request()
        self._cf_warmed = True

    # -- Response handling ---------------------------------------------------

    def _merge_response_cookies(self, resp: httpx.Response) -> None:
        """Persist response Set-Cookie headers back into the session jar."""
        for name, value in resp.cookies.items():
            if value:
                self.client.cookies.set(name, value)

    def _headers_for_request(self, url: str) -> dict[str, str]:
        """Build browser-like headers with endpoint-specific Referer."""
        headers = dict(HEADERS)
        if url.startswith(PDA_BASE_URL):
            # PDA subdomain: set Referer based on path
            path = url[len(PDA_BASE_URL) :]
            if path.startswith("/applyRecord"):
                headers["Referer"] = f"{PDA_BASE_URL}/applyRecord/"
            elif path.startswith("/work/jobStore"):
                headers["Referer"] = f"{PDA_BASE_URL}/work/jobStore/"
            elif path.startswith("/profile"):
                headers["Referer"] = f"{PDA_BASE_URL}/profile/"
            elif path.startswith("/viewjobRecord"):
                headers["Referer"] = f"{PDA_BASE_URL}/work/jobBrowse/"
            else:
                headers["Referer"] = f"{PDA_BASE_URL}/"
        elif url == SEARCH_URL:
            headers["Referer"] = SEARCH_REFERER
        elif url.startswith("/job/"):
            headers["Referer"] = JOB_REFERER
        elif url.startswith("/apis/my/"):
            headers["Referer"] = f"{BASE_URL}/my/104profile/"
        else:
            headers["Referer"] = f"{BASE_URL}/"
        return headers

    # -- Request with retry --------------------------------------------------

    def _request(self, method: str, url: str, **kwargs: Any) -> httpx.Response:
        """Execute HTTP request with rate-limit delay, retry, and cookie merge."""
        self._ensure_cf_cookies()
        self._rate_limit_delay()
        last_exc: Exception | None = None
        merged_headers = self._headers_for_request(url)
        request_headers = kwargs.pop("headers", None)
        if request_headers:
            merged_headers.update(request_headers)

        for attempt in range(self._max_retries):
            t0 = time.time()
            try:
                resp = self.client.request(method, url, headers=merged_headers, **kwargs)
                elapsed = time.time() - t0
                self._merge_response_cookies(resp)
                self._mark_request()

                logger.info(
                    "[#%d] %s %s -> %d (%.2fs)",
                    self._request_count,
                    method,
                    url[:60],
                    resp.status_code,
                    elapsed,
                )

                if resp.status_code in (429, 500, 502, 503, 504):
                    wait = (2**attempt) + random.uniform(0, 1)
                    logger.warning(
                        "HTTP %d from %s, retrying in %.1fs (attempt %d/%d)",
                        resp.status_code,
                        url[:80],
                        wait,
                        attempt + 1,
                        self._max_retries,
                    )
                    if resp.status_code == 429:
                        self._rate_limit_count += 1
                    time.sleep(wait)
                    continue

                resp.raise_for_status()
                return resp

            except (httpx.TimeoutException, httpx.NetworkError) as exc:
                last_exc = exc
                wait = (2**attempt) + random.uniform(0, 1)
                logger.warning(
                    "[#%d] %s %s -> Network error: %s, retrying in %.1fs (attempt %d/%d)",
                    self._request_count + 1,
                    method,
                    url[:60],
                    exc,
                    wait,
                    attempt + 1,
                    self._max_retries,
                )
                time.sleep(wait)

        if last_exc:
            raise Job104ApiError(f"請求失敗（重試 {self._max_retries} 次後）: {last_exc}") from last_exc
        raise Job104ApiError(f"請求失敗（重試 {self._max_retries} 次後）")

    def _get_json(self, url: str, params: dict[str, Any] | None = None, action: str = "") -> dict[str, Any]:
        """GET request that returns parsed JSON."""
        resp = self._request("GET", url, params=params)
        text = resp.text
        if text.startswith("<"):
            raise Job104ApiError(f"收到 HTML 而非 JSON（可能需要驗證）: {action}")
        try:
            return resp.json()
        except Exception as exc:
            raise Job104ApiError(f"JSON 解析失敗: {action}") from exc

    # -- Job Search & Browse -------------------------------------------------

    def search_jobs(
        self,
        keyword: str,
        area: str = "",
        page: int = 1,
        page_size: int = 20,
        order: str = "1",
        jobexp: str | None = None,
        edu: str | None = None,
        salary_type: str | None = None,
        salary_low: int | None = None,
        salary_high: int | None = None,
        isnew: str | None = None,
        remote: str | None = None,
        jobcat: str | None = None,
        indcat: str | None = None,
        rostatus: str | None = None,
        kwop: str = "7",
        ro: str = "0",
        s9: str | None = None,
        scstrict: bool = False,
        scneg: bool = False,
        exclude_kw: str | None = None,
        exclude_indcat: str | None = None,
        wf: str | None = None,
    ) -> dict[str, Any]:
        """Search jobs on 104.

        Returns normalized dict: {list, totalCount, totalPage, currentPage}.
        """
        params: dict[str, Any] = {
            **DEFAULT_SEARCH_PARAMS,
            "keyword": keyword,
            "kwop": kwop,
            "ro": ro,
            "order": order,
            "asc": "0",
            "page": page,
            "pagesize": page_size,
        }
        if area:
            params["area"] = area
        if jobexp and jobexp != "0":
            params["jobexp"] = jobexp
        if edu and edu != "0":
            params["edu"] = edu
        if salary_type:
            params["sctp"] = salary_type
        if salary_low is not None:
            params["scmin"] = salary_low
        if salary_high is not None:
            params["scmax"] = salary_high
        if isnew:
            params["isnew"] = isnew
        if remote:
            params["remoteWork"] = remote
        if jobcat:
            params["jobcat"] = jobcat
        if indcat:
            params["indcat"] = indcat
        if rostatus:
            params["rostatus"] = rostatus
        if s9:
            params["s9"] = s9
        if scstrict:
            params["scstrict"] = "1"
        if scneg:
            params["scneg"] = "1"
        if exclude_kw:
            params["excludeKw"] = exclude_kw
        if exclude_indcat:
            params["excludeIndustryCat"] = exclude_indcat
        if wf:
            params["wf"] = wf

        resp = self._get_json(SEARCH_URL, params=params, action="搜尋職缺")
        # New API: {data: [...jobs], metadata: {pagination: {total, lastPage, ...}}}
        pagination = resp.get("metadata", {}).get("pagination", {})
        job_list = resp.get("data", [])

        # Client-side salary filter: 104 API doesn't fully respect scneg/scstrict
        if scneg or scstrict:
            job_list = [j for j in job_list if j.get("salaryLow", 0) or j.get("salaryHigh", 0)]

        return {
            "list": job_list,
            "totalCount": pagination.get("total", 0),
            "totalPage": pagination.get("lastPage", 1),
            "currentPage": pagination.get("currentPage", 1),
        }

    def get_job_detail(self, job_id: str) -> dict[str, Any]:
        """Get detailed information for a specific job.

        Args:
            job_id: URL hash from the job link (e.g. '8z5sl'), NOT numeric jobNo.
        """
        url = JOB_DETAIL_URL.format(job_id=job_id)
        data = self._get_json(url, action="職缺詳情")
        return data.get("data", data)

    def search_companies(
        self,
        keyword: str = "",
        zone: str = "",
        area: str = "",
        page: int = 1,
        page_size: int = 20,
    ) -> dict[str, Any]:
        """Search companies on 104.

        Args:
            zone: Company type zone code (e.g. '4,5' for foreign companies).
        """
        params: dict[str, Any] = {"page": page, "pagesize": page_size}
        if keyword:
            params["keyword"] = keyword
        if zone:
            params["zone"] = zone
        if area:
            params["area"] = area
        return self._get_json(COMPANY_SEARCH_URL, params=params, action="搜尋公司")

    def suggest_keywords(self, keyword: str, count: int = 5) -> dict[str, Any]:
        """Get keyword and company suggestions for autocomplete.

        Args:
            keyword: Search term for suggestions.
            count: Max number of suggestions per category (default 5).
        """
        params = {"scope": "com", "count": count, "kw": keyword}
        return self._get_json(KEYWORD_SUGGEST_URL, params=params, action="關鍵字建議")

    def get_profile(self) -> dict[str, Any]:
        """Get the authenticated user's profile information.

        Uses resume overview + detail endpoints which reliably return
        account-level data (name, email, gender) via the ACData field.
        Falls back gracefully when endpoints return empty data or HTML.
        """
        # Strategy 1: Get master resume detail via overview → resumeByBlock
        # The resumeByBlock response includes ACData with real profile info.
        try:
            overview = self._pda_get_json("profile/ajax/overview", action="個人資料")
            inner = overview.get("data", overview)
            form_data = inner.get("formData", inner) if isinstance(inner, dict) else inner
            items = form_data.get("overview", []) if isinstance(form_data, dict) else []
            if items:
                master_vno = items[0].get("vno", items[0].get("versionNo", ""))
                if master_vno:
                    detail = self._pda_get_json(
                        "profile/ajax/resumeByBlock",
                        params={"vno": master_vno},
                        action="個人資料(履歷)",
                    )
                    d = detail.get("data", detail)
                    ac_data = d.get("ACData", {}).get("info", {})
                    info = d.get("info", {}).get("formData", {}).get("info", {})
                    if ac_data or info:
                        return {
                            "_source": "resume_detail",
                            "name": ac_data.get("name", ""),
                            "email": ac_data.get("email", ""),
                            "gender": _extract_option_text(ac_data.get("gender")),
                            "jobStatus": _extract_option_text(info.get("jobStatus")),
                            "age": info.get("age"),
                            "city": _extract_option_text(info.get("city")),
                            "resumeCount": len(items),
                            "_raw_overview": items,
                        }
        except Job104ApiError:
            logger.debug("resume overview/detail failed, trying fallback")

        # Strategy 2: derive basic presence from applied records
        try:
            resp = self._pda_get_json(
                "applyRecord/ajax/list",
                params={"page": 1},
                action="個人資料(應徵紀錄)",
            )
            return {"_source": "applied_fallback", "_raw": resp}
        except Job104ApiError:
            logger.debug("Applied records fallback also failed")

        # Last resort: authenticated but no profile data available
        return {"_source": "none", "authenticated": True}

    # -- PDA subdomain requests (pda.104.com.tw) ----------------------------

    def _pda_get_json(
        self,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        action: str = "",
    ) -> dict[str, Any]:
        """GET JSON from pda.104.com.tw using absolute URL.

        Referer is set automatically by _headers_for_request() based on path.
        """
        url = f"{PDA_BASE_URL}/{path.lstrip('/')}"
        return self._get_json(url, params=params, action=action)

    # -- PDA write methods (POST / PUT / DELETE) --------------------------------

    def _pda_write_request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json_data: dict[str, Any] | None = None,
        action: str = "",
    ) -> dict[str, Any]:
        """Execute a write (POST/PUT/DELETE) request to pda.104.com.tw.

        Write operations use more conservative rate limiting (1.5x delay)
        and only retry on 5xx errors (not 4xx). DELETE is never retried.
        """
        url = f"{PDA_BASE_URL}/{path.lstrip('/')}"

        # More conservative delay for write operations
        original_delay = self._request_delay
        self._request_delay = self._base_request_delay * 1.5

        # Fewer retries for writes; DELETE gets no retry
        original_retries = self._max_retries
        if method == "DELETE":
            self._max_retries = 1
        else:
            self._max_retries = 2

        try:
            kwargs: dict[str, Any] = {}
            if params:
                kwargs["params"] = params
            if json_data is not None:
                kwargs["json"] = json_data
            resp = self._request(method, url, **kwargs)
            text = resp.text
            if text.startswith("<"):
                raise Job104ApiError(f"收到 HTML 而非 JSON（可能需要驗證）: {action}")
            try:
                return resp.json()
            except Exception as exc:
                raise Job104ApiError(f"JSON 解析失敗: {action}") from exc
        finally:
            self._request_delay = original_delay
            self._max_retries = original_retries

    def _pda_post_json(
        self,
        path: str,
        *,
        json_data: dict[str, Any],
        params: dict[str, Any] | None = None,
        action: str = "",
    ) -> dict[str, Any]:
        """POST JSON to pda.104.com.tw."""
        return self._pda_write_request("POST", path, json_data=json_data, params=params, action=action)

    def _pda_put_json(
        self,
        path: str,
        *,
        json_data: dict[str, Any],
        params: dict[str, Any] | None = None,
        action: str = "",
    ) -> dict[str, Any]:
        """PUT JSON to pda.104.com.tw."""
        return self._pda_write_request("PUT", path, json_data=json_data, params=params, action=action)

    def _pda_delete(
        self,
        path: str,
        *,
        json_data: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
        action: str = "",
    ) -> dict[str, Any]:
        """DELETE request to pda.104.com.tw."""
        return self._pda_write_request("DELETE", path, json_data=json_data, params=params, action=action)

    # -- Resume write operations ------------------------------------------------

    def update_resume_section(
        self,
        vno: str,
        section: str,
        data: dict[str, Any],
        *,
        method: str = "PUT",
    ) -> dict[str, Any]:
        """Create or update a resume section.

        Args:
            vno: Resume version number.
            section: Section name (info, bio, education, experience, etc.).
            data: Section payload to submit.
            method: HTTP method — POST for create, PUT for update.
        """
        path = f"{PDA_RESUME_BLOCK}/{section}"
        action = f"履歷寫入 {section}"
        fn = self._pda_post_json if method == "POST" else self._pda_put_json
        try:
            return fn(path, json_data=data, params={"vno": vno}, action=action)
        except Job104ApiError as exc:
            raise ResumeWriteError(section, str(exc)) from exc

    def delete_resume_section(
        self,
        vno: str,
        section: str,
        data: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Delete a resume section or entry.

        Args:
            vno: Resume version number.
            section: Section name.
            data: Optional payload (e.g. sort value for array entries).
        """
        path = f"{PDA_RESUME_BLOCK}/{section}"
        try:
            return self._pda_delete(path, json_data=data, params={"vno": vno}, action=f"履歷刪除 {section}")
        except Job104ApiError as exc:
            raise ResumeWriteError(section, str(exc)) from exc

    # -- Resume metadata endpoints ----------------------------------------------

    def get_resume_options(self) -> dict[str, Any]:
        """Get all dropdown options for resume fields."""
        return self._pda_get_json(PDA_RESUME_OPTIONS, action="履歷選項")

    def get_resume_input_fields(self) -> dict[str, Any]:
        """Get field validation constraints for resume sections."""
        return self._pda_get_json(PDA_RESUME_INPUT_FIELD, action="履歷欄位規則")

    # -- Autocomplete endpoints -------------------------------------------------

    def autocomplete(self, ac_type: str, query: str) -> list[dict[str, Any]]:
        """Query 104 autocomplete endpoint.

        Args:
            ac_type: One of 'school', 'major', 'company', 'jobTitle', 'skill'.
            query: Search term.

        Returns:
            List of matching items (format varies by type).
        """
        path_map = {
            "school": PDA_AC_SCHOOL,
            "major": PDA_AC_MAJOR,
            "company": PDA_AC_COMPANY,
            "jobTitle": PDA_AC_JOB_TITLE,
            "skill": PDA_AC_SKILL,
        }
        path = path_map.get(ac_type)
        if not path:
            raise Job104ApiError(f"不支援的自動完成類型: {ac_type}")
        try:
            resp = self._pda_get_json(path, params={"term": query}, action=f"自動完成 {ac_type}")
            return resp.get("data", resp) if isinstance(resp, dict) else resp
        except Job104ApiError:
            logger.debug("Autocomplete %s failed for query=%s", ac_type, query)
            return []

    def get_applied_jobs(self, page: int = 1, status: str = "all") -> dict[str, Any]:
        """Get applied job records from pda.104.com.tw.

        Args:
            status: 'all' for all records, 'off' for closed jobs.
        """
        return self._pda_get_json(
            "applyRecord/ajax/list",
            params={"page": page, "status": status},
            action="應徵紀錄",
        )

    def get_saved_jobs(self, page: int = 1, status: str = "all") -> dict[str, Any]:
        """Get saved/bookmarked jobs from pda.104.com.tw.

        Args:
            page: Page number (default 1).
            status: Filter — "all" for all saved jobs, "off" for closed jobs only.
        """
        return self._pda_get_json(
            "work/jobStore/ajax/list",
            params={"page": page, "status": status},
            action="收藏職缺",
        )

    def get_interviews(self) -> dict[str, Any]:
        """Get interview invitations from pda.104.com.tw."""
        return self._pda_get_json("api/interviews", action="面試邀請")

    def get_resume_overview(self) -> dict[str, Any]:
        """Get resume overview from pda.104.com.tw."""
        return self._pda_get_json("profile/ajax/overview", action="履歷概覽")

    def get_resume_detail(self, vno: str) -> dict[str, Any]:
        """Get full resume data by version number (vno).

        Returns detailed sections: info, experience, education, skill,
        certificate, language, jobCondition, bio, project, portfolio, etc.
        """
        return self._pda_get_json(
            "profile/ajax/resumeByBlock",
            params={"vno": vno},
            action="履歷詳情",
        )

    def get_viewers(self) -> dict[str, Any]:
        """Get companies that viewed your resume."""
        return self._pda_get_json("api/peruse-record/companies", action="誰看過我")

    def get_followed_companies(self) -> dict[str, Any]:
        """Get followed/tracked companies."""
        return self._pda_get_json("api/follow-company/companies", action="關注公司")

    def get_browsing_history(self, page: int = 1) -> dict[str, Any]:
        """Get job browsing history."""
        return self._pda_get_json(
            "viewjobRecord/ajax/list",
            params={"page": page},
            action="瀏覽紀錄",
        )

    def get_recommended_jobs(
        self,
        group: str = "recommend",
        page: int = 1,
        page_size: int = 20,
    ) -> dict[str, Any]:
        """Get personalized recommended jobs.

        Args:
            group: 'recommend' (AI推薦) or 'highchance' (高度適配).
        """
        return self._pda_get_json(
            "api/jobs/personal-recommend-jobs",
            params={"group": group, "page": page, "pageSize": page_size},
            action="專屬工作",
        )


# -- Area resolution ---------------------------------------------------------


def resolve_area(name: str) -> str:
    """Resolve area name to code, passthrough if already a code."""
    if name.isdigit() and len(name) >= 6:
        return name
    code = AREA_CODES.get(name)
    if code is None and name != "全部":
        import sys

        print(f"[warning] 找不到地區: {name!r}。使用 job104 areas 查看可用地區。", file=sys.stderr)
        return ""
    return code or ""


def list_areas() -> dict[str, str]:
    """Return all supported area name -> code mappings."""
    return dict(AREA_CODES)
