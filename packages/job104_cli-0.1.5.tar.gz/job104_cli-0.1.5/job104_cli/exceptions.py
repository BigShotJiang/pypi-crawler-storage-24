"""Custom exceptions for job104 CLI API client."""

from __future__ import annotations


class Job104ApiError(Exception):
    """Base exception for 104 Job Bank API errors."""

    def __init__(self, message: str, code: int | str | None = None, response: dict | None = None):
        super().__init__(message)
        self.code = code
        self.response = response


class AuthRequiredError(Job104ApiError):
    """Raised when user is not logged in but auth is required."""

    def __init__(self):
        super().__init__("未登入，請先使用 job104 login 登入")


class SessionExpiredError(Job104ApiError):
    """Raised when session cookie has expired."""

    def __init__(self):
        super().__init__("登入已過期，請重新登入: job104 logout && job104 login")


class RateLimitError(Job104ApiError):
    """Raised when too many requests are made."""

    def __init__(self):
        super().__init__("請求過於頻繁，請稍後再試")


class ParamError(Job104ApiError):
    """Raised when API reports missing or invalid parameters."""

    def __init__(self, message: str, code: int | None = None):
        super().__init__(f"參數錯誤: {message}", code=code)


class CloudflareBlockError(Job104ApiError):
    """Raised when Cloudflare blocks the request (302 to error/challenge)."""

    def __init__(self):
        super().__init__("Cloudflare 阻擋，請稍後再試或更換 User-Agent")


class ResumeWriteError(Job104ApiError):
    """Raised when a resume write operation (POST/PUT/DELETE) fails."""

    def __init__(self, section: str, message: str, code: int | str | None = None):
        super().__init__(f"履歷寫入失敗 [{section}]: {message}", code=code)
        self.section = section


class ValidationError(Job104ApiError):
    """Raised when input data fails client-side validation."""

    def __init__(self, field: str, message: str):
        super().__init__(f"驗證失敗 [{field}]: {message}")
        self.field = field


def error_code_for_exception(exc: Exception) -> str:
    """Map domain exceptions to stable error code strings."""
    if isinstance(exc, (AuthRequiredError, SessionExpiredError)):
        return "not_authenticated"
    if isinstance(exc, RateLimitError):
        return "rate_limited"
    if isinstance(exc, ParamError):
        return "invalid_params"
    if isinstance(exc, CloudflareBlockError):
        return "cloudflare_blocked"
    if isinstance(exc, ResumeWriteError):
        return "resume_write_error"
    if isinstance(exc, ValidationError):
        return "validation_error"
    if isinstance(exc, Job104ApiError):
        return "api_error"
    return "unknown_error"
