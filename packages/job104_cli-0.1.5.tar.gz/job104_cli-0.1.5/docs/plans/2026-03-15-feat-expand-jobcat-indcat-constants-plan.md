---
title: "feat: Expand JOBCAT & INDCAT constants to cover all industries"
type: feat
date: 2026-03-15
---

# Expand JOBCAT & INDCAT Constants to Cover All Industries

## Overview

擴充 `constants.py` 中的職務類別 (`JOBCAT_CODES`) 與產業類別 (`INDCAT_CODES`)，使 job104 CLI 不再侷限於資訊產業，能涵蓋 90%+ 的台灣就業市場需求。所有代碼均取自 104 官方 CDN（`static.104.com.tw`），非幻覺產生。

## Problem Statement

原先 `JOBCAT_CODES` 僅有 16 筆 IT 相關條目，且部分代碼有誤（如 AI 工程師、前端工程師代碼對調）。產業分類 (`INDCAT_CODES`) 完全缺失。對於非資訊產業使用者（金融、醫療、教育、製造、餐飲等），幾乎無法使用 `--jobcat` 篩選。

## Data Source (Verified)

- **職務類別**: `https://static.104.com.tw/category-tool/json/JobCat.json`
  - Saved locally: `docs/refs/jobcat.json`
  - 18 top-level (L0), 36 sub-categories (L1), 616 leaf items (L2)

- **產業類別**: `https://static.104.com.tw/category-tool/json/Indust.json`
  - Saved locally: `docs/refs/indust.json`
  - 16 top-level (L0), 59 sub-categories (L1), 350+ leaf items (L2)

## Proposed Solution

### Phase 1: Constants Expansion (✅ DONE)

`constants.py` has already been updated with verified codes:

- [x] **`JOBCAT_CODES`**: Expanded from 16 → 165 entries
  - 18 L0 main categories (全部 18 大職類)
  - 36 L1 sub-categories
  - 111 popular L2 leaf-level job titles (across ALL industries)
  - Fixed incorrect codes (AI工程師, 前端工程師, 後端工程師 etc.)

- [x] **`INDCAT_CODES`**: Created with 101 entries
  - 16 L0 main industry categories
  - 59 L1 sub-categories
  - 26 popular L2 leaf-level industries

### Phase 2: Wire `--indcat` CLI Option

The client already accepts `indcat` parameter (`client.py:245`), but it's not exposed as a CLI option.

- [x] Add `--indcat` option to `search` command (`commands/search.py`)
  - Lookup logic: same as `--jobcat` — resolve label → code, passthrough if numeric
  - Import `INDCAT_CODES` from constants
- [x] Add `--indcat` option to `export` command
- [x]Pass `indcat` to `client.search_jobs()` call

```python
# commands/search.py — add to search command
@click.option("--indcat", default=None, help="產業類別 (e.g. 半導體業, 軟體及網路相關業)")
```

### Phase 3: Add `industries` Listing Command

- [x] Add `industries` command (similar to existing `areas` and `categories` commands)
  - Lists all INDCAT_CODES grouped by L0 category
  - Shows code for each entry
- [x]Register in `cli.py`

```python
# commands/search.py
@click.command()
def industries() -> None:
    """List supported industry categories (產業類別)."""
    # Group INDCAT_CODES by L0 prefix, display in Rich table
```

### Phase 4: Improve `categories` Command

- [x]Update `categories` to show entry count: "165 job categories available"
- [x]Group display by L0 category for readability (currently flat list)

### Phase 5: Raw Code Passthrough

- [x]For `--jobcat` and `--indcat`, if the value is already a numeric code (e.g. `2007001020`), pass it through directly without lookup
  - This allows users to use specific L2 leaf codes not in the lookup table
  - Already partially implemented for `--jobcat`; ensure consistent for `--indcat`

### Phase 6: Tests

- [x]Test `INDCAT_CODES` has expected top-level keys (16 L0 categories)
- [x]Test `JOBCAT_CODES` has expected count (165+)
- [x]Test `--indcat` option on search command (mocked)
- [x]Test `industries` command exits cleanly
- [x]Test raw code passthrough for both `--jobcat` and `--indcat`

## Acceptance Criteria

- [x]`job104 search "護理師" --indcat 醫療服務業` works correctly
- [x]`job104 search "會計" --jobcat 財務／會計／稅務類 --indcat 金融機構及其相關業` works
- [x]`job104 search "Python" --jobcat 2007001020` (raw code) works
- [x]`job104 industries` lists all industry categories
- [x]`job104 categories` shows all 165 job categories
- [x]All tests pass (`pytest`)
- [x]Ruff clean

## References

- `job104_cli/constants.py` — All lookup tables
- `job104_cli/client.py:245-279` — `indcat` param already wired in client
- `job104_cli/commands/search.py:134` — search command definition
- `job104_cli/commands/search.py:433` — categories command
- `docs/refs/jobcat.json` — Verified job category data from 104 CDN
- `docs/refs/indust.json` — Verified industry category data from 104 CDN
