---
title: "refactor: Migrate to new 104 API + add company type/category filters"
type: refactor
date: 2026-03-14
---

# refactor: Migrate to new 104 API + add company type/category filters

## Overview

During actual usage of job104_cli to search for senior AI/agentic engineer jobs at foreign companies in Taipei, **all core functionality was found to be broken** due to 104 Job Bank migrating their API endpoints and response schemas. Additionally, critical search filters needed for real-world job searching (company type, job category, industry) are missing.

This plan addresses 3 categories of issues discovered from hands-on usage:
1. **Critical fixes** — API endpoint migration, response parsing, session warmup (currently 100% broken)
2. **Data model** — response normalization layer to isolate future API changes
3. **Missing filters** — company type (外商), job/industry category, enriched export

## Problem Statement

### What's broken (everything)

| Issue | Severity | Root Cause |
|-------|----------|------------|
| Search returns 0 results or HTML error | Critical | Endpoint `/jobs/search/list` → now `/jobs/search/api/jobs` |
| Job detail returns 404 | Critical | Uses numeric `jobNo` but API needs URL hash (e.g., `8z5sl`) |
| All API calls fail without browser visit first | Critical | Cloudflare requires `__cf_bm`/`_cfuvid` cookies from page visit |
| Salary shows "-" | High | `salaryDesc` field removed; now `salaryLow`/`salaryHigh` integers |
| Tags crash with TypeError | High | `tags` changed from `list[str]` to `dict[str, obj]` |
| Education shows raw array | High | `optionEdu` changed from `str` to `list[int]` |
| Pagination stops at page 1 | High | `totalPage` → `metadata.pagination.lastPage` |

### What's missing

| Feature | Impact |
|---------|--------|
| Company type filter (`--company-type 外商`) | Cannot filter foreign companies |
| Company search command (`job104 company`) | Cannot browse companies by type/zone |
| Job category filter (`--jobcat`) | Parameter wired in client but no CLI option or code table |
| Industry category filter (`--indcat`) | Same — wired but not exposed |
| Export: job URL, industry, salary range, chinaCorp | Exported data is shallow |
| Data normalization layer | Every API change requires shotgun surgery across 5+ files |

## Proposed Solution

### Architecture: Add a normalization layer

```
104 API (raw JSON)
    ↓
client.py (HTTP + retry + rate limit)
    ↓
models.py (NEW — normalize raw API → stable dataclass)
    ↓
commands/*.py (consume normalized models only)
    ↓
index_cache.py (cache normalized models)
```

This isolates API schema changes to a single file (`models.py`), preventing the cascade of breaks we just experienced.

## Technical Approach

### Phase 1: Critical Fixes (unblock all functionality)

#### 1.1 Migrate search endpoint + response parsing

**`constants.py`** — Update endpoint URL:

```python
# constants.py:11 — BEFORE
SEARCH_URL = "/jobs/search/list"

# AFTER
SEARCH_URL = "/jobs/search/api/jobs"
```

**`client.py`** — Update `search_jobs()` return value handling:

```python
# client.py:search_jobs() — BEFORE
data = self._get_json(SEARCH_URL, params=params, action="搜尋職缺")
return data.get("data", data)

# AFTER — return the full response (data + metadata)
resp = self._get_json(SEARCH_URL, params=params, action="搜尋職缺")
# New API: {data: [...jobs], metadata: {pagination: {total, lastPage, currentPage, count}}}
return {
    "list": resp.get("data", []),
    "totalCount": resp.get("metadata", {}).get("pagination", {}).get("total", 0),
    "totalPage": resp.get("metadata", {}).get("pagination", {}).get("lastPage", 1),
    "currentPage": resp.get("metadata", {}).get("pagination", {}).get("currentPage", 1),
}
```

This maintains backward compatibility with existing command code that reads `data.get("list")`.

#### 1.2 Add Cloudflare session warmup

**`client.py`** — Add lazy warmup in the client:

```python
class Job104Client:
    def __init__(self, ...):
        ...
        self._cf_warmed = False

    def __enter__(self):
        self._http = self._build_client()
        return self

    def _ensure_cf_cookies(self) -> None:
        """Lazy Cloudflare warmup — visit search page to acquire CF cookies."""
        if self._cf_warmed:
            return
        self._rate_limit_delay()
        self.client.get(
            "/jobs/search/",
            headers={**dict(HEADERS), "Referer": f"{BASE_URL}/"},
        )
        self._mark_request()
        self._cf_warmed = True

    def _request(self, method, url, **kwargs):
        self._ensure_cf_cookies()  # <-- ADD this line at the top
        # ... existing retry logic
```

#### 1.3 Fix job detail ID resolution

**`constants.py`**:

```python
# BEFORE
JOB_DETAIL_URL = "/job/ajax/content/{job_no}"

# AFTER
JOB_DETAIL_URL = "/job/ajax/content/{job_id}"
```

**`client.py`** — Rename parameter for clarity:

```python
def get_job_detail(self, job_id: str) -> dict:
    """Get detailed information. job_id is the URL hash (e.g., '8z5sl'), NOT numeric jobNo."""
    url = JOB_DETAIL_URL.format(job_id=job_id)
    ...
```

**`index_cache.py`** — Store URL hash alongside jobNo:

```python
def _extract_job_id(job: dict) -> str:
    """Extract the URL hash ID from a job's link field."""
    link = job.get("link", {})
    job_url = link.get("job", "") if isinstance(link, dict) else ""
    if job_url:
        return job_url.rstrip("/").split("/")[-1]
    return ""
```

Update `save_index()` to store `jobId` (URL hash) alongside `jobNo`.
Update `show` command to use `jobId` for detail lookups.

#### 1.4 Fix response field mappings

**Salary** — handle `salaryLow`/`salaryHigh`:

```python
# In _render_job_table and export
def format_salary(job: dict) -> str:
    low = job.get("salaryLow", 0)
    high = job.get("salaryHigh", 0)
    if low and high:
        return f"{low:,} ~ {high:,}"
    elif low:
        return f"{low:,} 以上"
    return job.get("salaryDesc", "面議")  # fallback for old API
```

**Tags** — handle dict format:

```python
# BEFORE
tags = job.get("tags", [])
tag_str = ", ".join(tags[:4])

# AFTER
raw_tags = job.get("tags", {})
if isinstance(raw_tags, dict):
    tag_str = ", ".join(t.get("desc", k) for k, t in list(raw_tags.items())[:4])
elif isinstance(raw_tags, list):
    tag_str = ", ".join(raw_tags[:4])  # backward compat
else:
    tag_str = "-"
```

**optionEdu** — handle list of ints:

```python
EDU_DISPLAY = {1: "高中以下", 2: "高中職", 3: "專科", 4: "大學", 5: "碩士", 6: "博士"}

raw_edu = job.get("optionEdu", "-")
if isinstance(raw_edu, list):
    edu_str = "/".join(EDU_DISPLAY.get(e, str(e)) for e in raw_edu)
elif isinstance(raw_edu, str):
    edu_str = raw_edu
else:
    edu_str = "-"
```

### Phase 2: Data Normalization Layer

#### 2.1 Create `models.py`

**New file: `job104_cli/models.py`**

```python
from __future__ import annotations
from dataclasses import dataclass, field

@dataclass
class Job:
    """Normalized job data — stable interface regardless of API version."""
    job_no: str = ""
    job_id: str = ""          # URL hash for detail API
    job_name: str = ""
    job_url: str = ""
    cust_name: str = ""
    cust_no: str = ""
    cust_url: str = ""
    salary_low: int = 0
    salary_high: int = 0
    salary_desc: str = ""     # computed: "50,000 ~ 70,000" or "面議"
    option_edu: list[int] = field(default_factory=list)
    edu_desc: str = ""        # computed: "大學/碩士"
    option_exp: str = ""
    location: str = ""
    industry: str = ""
    tags: list[str] = field(default_factory=list)
    description: str = ""
    china_corp: bool = False
    appear_date: str = ""

    @classmethod
    def from_search_result(cls, raw: dict) -> Job:
        """Normalize a raw search API response item."""
        link = raw.get("link", {})
        job_url = link.get("job", "") if isinstance(link, dict) else ""
        job_id = job_url.rstrip("/").split("/")[-1] if job_url else ""

        # Salary
        low = raw.get("salaryLow", 0)
        high = raw.get("salaryHigh", 0)
        if low and high:
            salary_desc = f"{low:,} ~ {high:,}"
        elif low:
            salary_desc = f"{low:,} 以上"
        else:
            salary_desc = raw.get("salaryDesc", "面議")

        # Education
        raw_edu = raw.get("optionEdu", [])
        edu_map = {1: "高中以下", 2: "高中職", 3: "專科", 4: "大學", 5: "碩士", 6: "博士"}
        if isinstance(raw_edu, list):
            edu_desc = "/".join(edu_map.get(e, str(e)) for e in raw_edu)
        else:
            edu_desc = str(raw_edu) if raw_edu else ""

        # Tags
        raw_tags = raw.get("tags", {})
        if isinstance(raw_tags, dict):
            tags = [t.get("desc", k) for k, t in raw_tags.items() if t.get("desc")]
        elif isinstance(raw_tags, list):
            tags = raw_tags
        else:
            tags = []

        return cls(
            job_no=str(raw.get("jobNo", "")),
            job_id=job_id,
            job_name=raw.get("jobName", ""),
            job_url=job_url,
            cust_name=raw.get("custName", ""),
            cust_no=str(raw.get("custNo", "")),
            cust_url=(link.get("cust", "") if isinstance(link, dict) else ""),
            salary_low=low,
            salary_high=high,
            salary_desc=salary_desc,
            option_edu=raw_edu if isinstance(raw_edu, list) else [],
            edu_desc=edu_desc,
            option_exp=raw.get("optionExp", raw.get("period", "")),
            location=raw.get("jobAddrNoDesc", ""),
            industry=raw.get("coIndustryDesc", ""),
            tags=tags[:6],
            description=raw.get("description", ""),
            appear_date=raw.get("appearDate", ""),
        )

    def to_dict(self) -> dict:
        """Serialize for JSON/YAML output."""
        ...
```

#### 2.2 Migrate all consumers to use `Job` model

- `commands/search.py` — `_render_job_table()` consumes `list[Job]`
- `commands/search.py` — `export()` serializes `list[Job]` to CSV
- `index_cache.py` — `save_index()` stores `Job.to_dict()`
- `commands/_common.py` — structured output wraps `[job.to_dict() for job in jobs]`

### Phase 3: New Filters & Company Search

#### 3.1 Add company type constants and search filter

**`constants.py`** — Add company type codes:

```python
# Company type / rostatus codes (for job search API)
ROSTATUS_CODES: dict[str, str] = {
    "外商": "4",
    "上市上櫃": "16",
}

# Company zone codes (for company search API)
COMPANY_ZONE_CODES: dict[str, str] = {
    "外商": "4,5",          # 4=外商資訊, 5=外商一般
    "上市上櫃": "16",
}

# Company search API endpoint
COMPANY_SEARCH_URL = "/company/ajax/list"
```

**`commands/search.py`** — Add `--company-type` to search and export:

```python
@click.option("--company-type", type=click.Choice(list(ROSTATUS_CODES.keys())),
              default=None, help="公司類型 (外商/上市上櫃)")
```

**`client.py`** — Wire `rostatus` param in `search_jobs()`:

```python
def search_jobs(self, ..., rostatus: str | None = None, ...):
    ...
    if rostatus:
        params["rostatus"] = rostatus
```

#### 3.2 Add company search command

**`client.py`** — New method:

```python
def search_companies(
    self,
    keyword: str = "",
    zone: str = "",
    area: str = "",
    page: int = 1,
    page_size: int = 20,
) -> dict:
    """Search companies on 104."""
    params = {"page": page, "pagesize": page_size}
    if keyword:
        params["keyword"] = keyword
    if zone:
        params["zone"] = zone
    if area:
        params["area"] = area
    return self._get_json(COMPANY_SEARCH_URL, params=params, action="搜尋公司")
```

**`commands/search.py`** — New `company` command:

```python
@click.command()
@click.argument("keyword", default="")
@click.option("-a", "--area", default="全部", help="地區")
@click.option("--zone", type=click.Choice(list(COMPANY_ZONE_CODES.keys())),
              default=None, help="公司類型 (外商/上市上櫃)")
@click.option("-p", "--page", default=1, type=int, help="頁碼")
@structured_output_options
def company(keyword, area, zone, page, as_json, as_yaml):
    """搜尋公司 (例: job104 company "Google" --zone 外商)"""
    ...
```

#### 3.3 Add jobcat/indcat filter support

**`constants.py`** — Add top categories:

```python
JOBCAT_CODES: dict[str, str] = {
    "軟體工程師": "2007001004",
    "AI工程師": "2007001022",
    "資料工程師": "2007001020",
    "資料科學家": "2007001021",
    "前端工程師": "2007001006",
    "後端工程師": "2007001005",
    "全端工程師": "2007001019",
    "MIS工程師": "2007002001",
    # ... top 20-30 categories
}
```

Wire `--jobcat` and `--indcat` as CLI options on `search` and `export`.

#### 3.4 Enrich export

**`commands/search.py`** — Update CSV fields and add `--enrich` flag:

```python
# New default fields
EXPORT_FIELDS = ["職缺", "公司", "產業", "薪資", "薪資下限", "薪資上限",
                 "經驗", "學歷", "地區", "技能", "職缺連結", "jobNo"]

# With --enrich (fetches detail for each job)
EXPORT_FIELDS_ENRICHED = [*EXPORT_FIELDS, "職缺描述", "chinaCorp", "專長技能"]
```

### Phase 4: Error Handling & Resilience

#### 4.1 Cloudflare-specific error detection

**`exceptions.py`**:

```python
class CloudflareBlockError(Job104ApiError):
    """Raised when Cloudflare blocks the request."""
    pass
```

**`client.py`** — Detect CF redirects:

```python
def _build_client(self) -> httpx.Client:
    return httpx.Client(
        ...,
        follow_redirects=False,  # <-- Change: don't auto-follow
    )

def _request(self, ...):
    ...
    if resp.status_code in (301, 302):
        location = resp.headers.get("location", "")
        if "error" in location or "challenge" in location:
            self._cf_warmed = False  # Force re-warmup
            raise CloudflareBlockError("Cloudflare 阻擋，正在重新建立連線...")
        # Follow legitimate redirects manually
        ...
```

#### 4.2 Response schema validation

**`client.py`** — Validate response shape:

```python
def _get_json(self, url, ...):
    resp = self._request("GET", url, ...)
    ...
    data = resp.json()
    # Validate expected top-level structure
    if url == SEARCH_URL:
        if "data" not in data or "metadata" not in data:
            raise Job104ApiError(f"API 回應格式異常（可能 API 已更新）: 缺少 data/metadata 欄位")
    return data
```

#### 4.3 Update test fixtures

**`tests/conftest.py`** — Update `SAMPLE_SEARCH_RESPONSE` to new API format:

```python
SAMPLE_SEARCH_RESPONSE = {
    "data": [
        {
            "jobNo": "15077397",
            "jobName": "Senior AI Engineer",
            "custName": "Google_美商科高國際有限公司",
            "salaryLow": 80000,
            "salaryHigh": 150000,
            "optionEdu": [4, 5],
            "tags": {"skill1": {"desc": "Python", "param": "skill1"}},
            "link": {"job": "https://www.104.com.tw/job/8z5sl"},
            ...
        }
    ],
    "metadata": {
        "pagination": {"total": 100, "lastPage": 5, "currentPage": 1, "count": 20}
    }
}
```

Add contract test with real API snapshot.

### Phase 5: Cleanup

- Remove standalone `search_ai_jobs.py` and `taipei_senior_ai_foreign_jobs.csv` (or `.gitignore` them)
- Consolidate duplicate `_extract_job_no` (in both `index_cache.py:23` and `search.py:25`) into a single location
- Add `testpaths = ["tests"]` to `pyproject.toml` to prevent boss-cli reference tests from being collected
- Update User-Agent string to a current Chrome version
- Update README with new commands/filters

## Acceptance Criteria

### Functional Requirements

- [x] `job104 search "AI engineer" --area 台北市` returns results (not 0 or HTML error)
- [x] `job104 show 3` opens the correct job detail (using URL hash, not numeric jobNo)
- [x] `job104 search "AI" --company-type 外商` filters for foreign company jobs
- [x] `job104 company "Google" --zone 外商 --area 台北市` lists foreign companies
- [x] `job104 export "AI" --area 台北市 -n 20 -o jobs.csv` produces CSV with job URL, salary range, industry
- [ ] `job104 export "AI" --area 台北市 --enrich -n 10 -o jobs.csv` includes detail-level data (description, chinaCorp, skills)
- [x] `job104 search "Python" --jobcat 軟體工程師` filters by job category
- [x] `job104 categories` lists supported job categories
- [x] `--json` output uses the normalized `Job` model with stable field names
- [x] Salary displays as "80,000 ~ 150,000" not "-"
- [x] Tags display as "Python, AI, LLM" not crash with TypeError

### Non-Functional Requirements

- [x] All existing tests pass after migration (updated fixtures)
- [x] New tests cover: CF warmup, new response parsing, Job model normalization, company search
- [ ] No Cloudflare blocks during normal usage (lazy warmup works transparently)
- [ ] Export of 50 jobs completes without CF cookie expiry (auto re-warmup)
- [ ] Response schema validation catches future API changes with clear error messages

### Quality Gates

- [x] `ruff check` passes
- [x] All tests pass (`pytest -m "not smoke"`)
- [x] No duplicate utility functions across files

## Implementation Phases

### Phase 1: Critical Fixes (unblock functionality)
- Files: `constants.py`, `client.py`, `index_cache.py`, `commands/search.py`
- Effort: Core — must be done first
- Success: `job104 search` and `job104 show` work again

### Phase 2: Data Normalization
- Files: NEW `models.py`, `commands/search.py`, `index_cache.py`, `commands/_common.py`
- Effort: Medium
- Success: All consumers use `Job` dataclass, not raw dicts

### Phase 3: New Filters & Company Search
- Files: `constants.py`, `client.py`, `commands/search.py`, `cli.py`
- Effort: Medium
- Success: `--company-type`, `--jobcat`, `job104 company` all work

### Phase 4: Error Handling & Resilience
- Files: `exceptions.py`, `client.py`
- Effort: Small
- Success: CF blocks are detected, schema changes raise clear errors

### Phase 5: Tests & Cleanup
- Files: `tests/conftest.py`, `tests/test_cli.py`, `pyproject.toml`, `README.md`
- Effort: Small
- Success: All tests pass with new fixtures, no regressions

## Risk Analysis & Mitigation

| Risk | Likelihood | Impact | Mitigation |
|------|-----------|--------|------------|
| 104 changes API again | Medium | High | Normalization layer in Phase 2 isolates changes to `models.py` |
| `rostatus` param rejected by new API | Medium | Medium | Fallback to company search cross-reference approach |
| CF warmup adds noticeable latency | Low | Low | Lazy warmup only on first request; ~1-2s one-time cost |
| Job category codes incomplete | Medium | Low | Allow raw code passthrough for codes not in our table |

## References

### Internal References

- Current search endpoint: `job104_cli/constants.py:11` — `SEARCH_URL`
- Current detail endpoint: `job104_cli/constants.py:12` — `JOB_DETAIL_URL`
- Client with rate limiting: `job104_cli/client.py` — `Job104Client`
- Index cache: `job104_cli/index_cache.py` — stores jobNo for `show` command
- Duplicate `_extract_job_no`: `job104_cli/index_cache.py:23` AND `job104_cli/commands/search.py:25`
- Export command: `job104_cli/commands/search.py:252-325`
- Test fixtures: `tests/conftest.py:15-53` — `SAMPLE_SEARCH_RESPONSE`
- Proof-of-concept script: `search_ai_jobs.py` — working code using new API

### External References

- New search API: `GET /jobs/search/api/jobs` — returns `{data: [...], metadata: {pagination: {...}}}`
- Company search API: `GET /company/ajax/list` — supports `zone=4,5` for foreign companies
- Job detail API: `GET /job/ajax/content/{urlHash}` — uses URL hash, not numeric jobNo
- Cloudflare cookies required: `__cf_bm`, `_cfuvid` — set by visiting any 104 HTML page
