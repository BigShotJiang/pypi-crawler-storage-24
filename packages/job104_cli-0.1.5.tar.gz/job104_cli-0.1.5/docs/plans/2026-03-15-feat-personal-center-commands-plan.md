---
title: "feat: Add Personal Center Commands (applied, saved, interviews, resume)"
type: feat
date: 2026-03-15
phase: 3
---

# feat: Add Personal Center Commands (applied, saved, interviews, resume)

## Overview

實作 Phase 3 個人中心功能，讓已登入使用者可以透過 CLI 查看應徵紀錄、收藏職缺、面試邀請和履歷資料。Phase 1（公開搜尋）和 Phase 2（認證系統）已完成，所有必要的基礎設施（HTTP 客戶端、Cookie 認證、速率限制、結構化輸出）都已到位。

## Problem Statement

使用者登入後目前只能透過 `job104 me` 查看基本個人資料。無法在 CLI 中查看應徵紀錄、收藏的職缺、面試邀請或完整履歷，需要回到瀏覽器操作。

## Proposed Solution

新增四個認證命令：

| 命令 | 用途 |
|------|------|
| `job104 applied` | 查看已應徵的職缺清單 |
| `job104 saved` | 查看收藏的職缺清單 |
| `job104 interviews` | 查看面試邀請 |
| `job104 resume` | 查看履歷資料（比 `me` 更完整） |

所有命令遵循現有模式：`--json`/`--yaml` 結構化輸出、Rich 表格到 stderr、分頁支援、index cache 整合。

## Technical Approach

### API Endpoints (Reverse-Engineered from 104 JS Bundles)

**Base URL:** `https://pda.104.com.tw/`

104 的個人中心 API 全部位於 `pda.104.com.tw` 子域名，與搜尋 API（`www.104.com.tw`）不同。

#### Applied Jobs (已應徵)

| 端點 | 方法 | 用途 |
|------|------|------|
| `pda.104.com.tw/applyRecord/ajax/list` | GET | 應徵紀錄列表（主要端點） |
| `pda.104.com.tw/applyRecord/ajax/records` | GET | 應徵紀錄詳情 |
| `pda.104.com.tw/applyRecord/ajax/reminder` | GET | 應徵提醒 |
| `pda.104.com.tw/applyRecord/ajax/recommendJobs` | POST | 基於應徵歷史的推薦 |
| `pda.104.com.tw/api/apply/record-reports` | GET | 應徵報告（BFF） |
| `pda.104.com.tw/api/apply/report` | GET | 應徵成效分析（BFF） |
| `pda.104.com.tw/api/apply/report/effectiveness-flag` | GET | 應徵成效旗標（BFF） |

**主要使用：** `/applyRecord/ajax/list` 作為 `job104 applied` 的資料來源。

#### Saved Jobs (收藏職缺)

| 端點 | 方法 | 用途 |
|------|------|------|
| `pda.104.com.tw/work/jobStore/ajax/list` | GET | 收藏職缺列表 |
| `pda.104.com.tw/work/jobStore/ajax/folder` | GET/POST | 資料夾管理 |
| `pda.104.com.tw/work/jobStore/ajax/folder/{id}` | GET/PUT | 特定資料夾 |
| `pda.104.com.tw/work/jobStore/ajax/memo` | PUT | 職缺備註 |
| `pda.104.com.tw/work/jobStore/ajax/applyTime` | GET | 應徵時間 |
| `pda.104.com.tw/work/jobStore/ajax/recommendJobs` | GET | 基於收藏的推薦 |

**主要使用：** `/work/jobStore/ajax/list` 作為 `job104 saved` 的資料來源。

#### Interviews (面試邀請)

| 端點 | 方法 | 用途 |
|------|------|------|
| `pda.104.com.tw/api/interviews` | GET | 面試邀請列表 |
| `pda.104.com.tw/work/message/ajax/interview` | DELETE | 刪除面試 |

**主要使用：** `/api/interviews` 作為 `job104 interviews` 的資料來源。

#### Resume/Profile (履歷)

| 端點 | 方法 | 用途 |
|------|------|------|
| `pda.104.com.tw/profile/ajax/overview` | GET | 履歷概覽 |
| `pda.104.com.tw/profile/ajax/resumeByBlock` | GET | 履歷區塊資料 |
| `pda.104.com.tw/profile/ajax/completeResumeList` | GET | 完整履歷列表 |
| `pda.104.com.tw/api/user-resumes/completed` | GET | 已完成的履歷（BFF） |
| `pda.104.com.tw/api/resume-settings` | GET | 履歷設定 |
| `pda.104.com.tw/api/resume-settings/visibility` | GET/PUT | 履歷可見度 |
| `pda.104.com.tw/profile/ajax/privacy-setting` | GET/PUT | 隱私設定 |

**主要使用：** `/profile/ajax/overview` + `/profile/ajax/resumeByBlock` 組合成完整履歷。

#### Other Useful Endpoints

| 端點 | 方法 | 用途 |
|------|------|------|
| `pda.104.com.tw/api/user/status` | GET | 使用者登入狀態 |
| `pda.104.com.tw/api/user` | GET | 使用者資料（目前 `me` 使用） |
| `pda.104.com.tw/api/peruse-record/companies` | GET | 瀏覽過你履歷的公司 |
| `pda.104.com.tw/api/follow-company/companies` | GET | 關注的公司列表 |
| `pda.104.com.tw/api/notification-settings` | GET/PATCH | 通知設定 |
| `pda.104.com.tw/api/messages/chatrooms` | GET | 訊息聊天室 |
| `pda.104.com.tw/viewjobRecord/ajax/list` | GET | 職缺瀏覽紀錄 |

### Architecture

```
job104_cli/
├── client.py             # 新增: PDA_BASE_URL, _pda_request(), 4 個新方法
├── constants.py          # 新增: PDA_BASE_URL, PDA_REFERER 常數
├── commands/
│   ├── _common.py        # 新增: require_auth() helper
│   └── personal.py       # 新檔案: applied, saved, interviews, resume 命令
└── cli.py                # 修改: 註冊 personal 命令
tests/
└── test_personal.py      # 新檔案: 個人中心命令測試
```

### Implementation Phases

#### Phase 3a: 基礎設施 + applied 命令

**目標：** 建立 pda 子域名支援，實作第一個個人中心命令。

- [x] `constants.py`: 新增 `PDA_BASE_URL = "https://pda.104.com.tw"` 和 Referer 常數
- [x] `client.py`: 新增 `_pda_request()` 方法處理 pda 子域名請求（正確 Referer、Cookie 傳遞）
- [x] `client.py`: 新增 `get_applied_jobs(page=1)` 方法
- [x] `commands/_common.py`: 新增 `require_auth()` helper
- [x] `commands/personal.py`: 實作 `applied` 命令含 Rich 表格和分頁
- [x] `cli.py`: 註冊 `applied` 命令
- [ ] 手動測試以捕獲實際 API 回應 schema（需要使用者登入 104）
- [x] `tests/test_personal.py`: `applied` 命令測試

<details>
<summary>client.py: _pda_request() 方法設計</summary>

```python
# job104_cli/client.py

PDA_BASE_URL = "https://pda.104.com.tw"

def _pda_request(self, method: str, path: str, *, params: dict | None = None,
                  data: dict | None = None, action: str = "") -> httpx.Response:
    """Make a request to pda.104.com.tw subdomain.

    Uses absolute URL to bypass the www base_url. Sets correct Referer for pda.
    """
    url = f"{PDA_BASE_URL}/{path.lstrip('/')}"
    headers = dict(HEADERS)
    headers["Referer"] = f"{PDA_BASE_URL}/"
    return self._request(method, url, params=params, data=data,
                         extra_headers=headers, action=action)
```

</details>

<details>
<summary>commands/_common.py: require_auth() helper</summary>

```python
# job104_cli/commands/_common.py

def require_auth():
    """取得認證或顯示錯誤並退出。"""
    from ..auth import get_credential
    cred = get_credential()
    if not cred:
        console.print("[red]未登入，請先使用 [bold]job104 login[/bold] 登入[/red]")
        raise SystemExit(1)
    return cred
```

</details>

<details>
<summary>commands/personal.py: applied 命令骨架</summary>

```python
# job104_cli/commands/personal.py
"""個人中心命令：applied, saved, interviews, resume。"""
from __future__ import annotations

import logging
import click
from rich.table import Table

from ._common import console, handle_command, require_auth, structured_output_options

logger = logging.getLogger(__name__)


@click.command()
@click.option("-p", "--page", default=1, type=int, help="頁碼 (預設: 1)")
@structured_output_options
def applied(page: int, as_json: bool, as_yaml: bool) -> None:
    """查看已應徵的職缺"""
    cred = require_auth()

    def _action(c):
        return c.get_applied_jobs(page=page)

    def _render(data: dict) -> None:
        records = data.get("data", [])
        if not records:
            console.print("[yellow]暫無應徵紀錄[/yellow]")
            return
        table = Table(title="已應徵的職缺", show_lines=True)
        table.add_column("#", style="dim", width=4)
        table.add_column("職缺", style="bold", max_width=30)
        table.add_column("公司", max_width=20)
        table.add_column("薪資")
        table.add_column("狀態")
        table.add_column("應徵日期", style="dim")
        for i, rec in enumerate(records, 1):
            table.add_row(
                str(i),
                rec.get("jobName", ""),
                rec.get("custName", ""),
                rec.get("salaryDesc", ""),
                rec.get("status", ""),
                rec.get("applyDate", ""),
            )
        console.print(table)
        # 分頁提示 - 欄位名稱需根據實際回應調整
        total = data.get("totalCount") or data.get("totalPage")
        if total and page * 20 < (total if isinstance(total, int) else 999):
            console.print(f"[dim]下一頁: job104 applied -p {page + 1}[/dim]")

    handle_command(action=_action, render=_render,
                   as_json=as_json, as_yaml=as_yaml, credential=cred)
```

</details>

**交付物：**
- `job104 applied` 可查看應徵紀錄
- `job104 applied --json` 輸出結構化資料
- `job104 applied -p 2` 分頁

#### Phase 3b: saved + interviews 命令

- [x] `client.py`: 新增 `get_saved_jobs(page=1)` 方法
- [x] `client.py`: 新增 `get_interviews()` 方法
- [x] `commands/personal.py`: 實作 `saved` 命令含 Rich 表格
- [x] `commands/personal.py`: 實作 `interviews` 命令含 Rich 表格
- [x] `cli.py`: 註冊 `saved` 和 `interviews` 命令
- [x] `tests/test_personal.py`: 新增 saved/interviews 測試

<details>
<summary>commands/personal.py: saved + interviews 命令骨架</summary>

```python
@click.command()
@click.option("-p", "--page", default=1, type=int, help="頁碼 (預設: 1)")
@structured_output_options
def saved(page: int, as_json: bool, as_yaml: bool) -> None:
    """查看收藏的職缺"""
    cred = require_auth()

    def _action(c):
        return c.get_saved_jobs(page=page)

    def _render(data: dict) -> None:
        jobs = data.get("data", [])
        if not jobs:
            console.print("[yellow]暫無收藏職缺[/yellow]")
            return
        table = Table(title="收藏的職缺", show_lines=True)
        table.add_column("#", style="dim", width=4)
        table.add_column("職缺", style="bold", max_width=30)
        table.add_column("公司", max_width=20)
        table.add_column("薪資")
        table.add_column("地區")
        table.add_column("收藏日期", style="dim")
        for i, job in enumerate(jobs, 1):
            table.add_row(
                str(i),
                job.get("jobName", ""),
                job.get("custName", ""),
                job.get("salaryDesc", ""),
                job.get("jobAddrNoDesc", ""),
                job.get("saveDate", ""),
            )
        console.print(table)

    handle_command(action=_action, render=_render,
                   as_json=as_json, as_yaml=as_yaml, credential=cred)


@click.command()
@structured_output_options
def interviews(as_json: bool, as_yaml: bool) -> None:
    """查看面試邀請"""
    cred = require_auth()

    def _action(c):
        return c.get_interviews()

    def _render(data: dict) -> None:
        items = data.get("data", [])
        if not items:
            console.print("[yellow]暫無面試邀請[/yellow]")
            return
        table = Table(title="面試邀請", show_lines=True)
        table.add_column("#", style="dim", width=4)
        table.add_column("職缺", style="bold", max_width=30)
        table.add_column("公司", max_width=20)
        table.add_column("面試時間")
        table.add_column("地點")
        table.add_column("狀態")
        for i, item in enumerate(items, 1):
            table.add_row(
                str(i),
                item.get("jobName", ""),
                item.get("custName", ""),
                item.get("interviewDate", ""),
                item.get("address", ""),
                item.get("status", ""),
            )
        console.print(table)

    handle_command(action=_action, render=_render,
                   as_json=as_json, as_yaml=as_yaml, credential=cred)
```

</details>

**交付物：**
- `job104 saved` 可查看收藏職缺
- `job104 interviews` 可查看面試邀請

#### Phase 3c: resume 命令 + index cache 整合

- [x] `client.py`: 新增 `get_resume_overview()` 方法
- [ ] `client.py`: 新增 `get_resume_blocks()` 方法
- [x] `commands/personal.py`: 實作 `resume` 命令含 Rich Panel
- [x] `cli.py`: 註冊 `resume` 命令
- [x] `commands/personal.py`: 在 `applied`/`saved` 中整合 index cache（讓 `job104 show N` 可用）
- [x] `tests/test_personal.py`: 新增 resume 和 index cache 整合測試

**交付物：**
- `job104 resume` 可查看完整履歷
- `job104 applied` / `job104 saved` 結果可透過 `job104 show N` 快速查看詳情

### Technical Considerations

#### pda.104.com.tw 子域名處理

**問題：** 現有 `Job104Client` 的 `base_url` 是 `www.104.com.tw`，Phase 3 的 API 全部在 `pda.104.com.tw`。

**方案：** 沿用 `get_profile()` 的模式，使用絕對 URL。新增 `_pda_request()` helper 方法：
- 自動拼接 `https://pda.104.com.tw/` 前綴
- 設定正確的 Referer（`https://pda.104.com.tw/`）
- 複用現有的速率限制和重試邏輯

**為何不建立獨立客戶端：** Cookie 是 domain-scoped（`.104.com.tw`），兩個子域名共用同一組 Cookie。共用客戶端避免 Cookie 同步問題。

#### Cloudflare 預熱

**已知：** `www.104.com.tw` 需要 CF 預熱（`_ensure_cf_cookies()`）。

**未知：** `pda.104.com.tw` 是否需要獨立的 CF 預熱。

**策略：** 先嘗試不做額外預熱。如果遇到 403，新增 `_ensure_pda_cf_cookies()` 方法，訪問 `https://pda.104.com.tw/` 取得 CF Cookie。

#### Referer 標頭

根據 JS 分析，pda 端點的 Referer 規則：
- `applyRecord/*` → `https://pda.104.com.tw/applyRecord/`
- `work/jobStore/*` → `https://pda.104.com.tw/work/jobStore/`
- `profile/*` → `https://pda.104.com.tw/profile/`
- `api/*`（BFF 端點） → `https://pda.104.com.tw/`

需在實際測試中驗證。

#### Session 過期處理

**問題：** 個人中心 API 返回 session 過期的方式未知。

**策略：** 檢測以下情況：
1. HTTP 401 → 顯示「Cookie 已過期，請重新 `job104 login`」
2. HTTP 302 重導向到 `signin.104.com.tw` → 同上
3. HTML 回應（非 JSON） → 可能是登入頁面重導向
4. JSON 回應含 error code → 解析並顯示

#### API 回應 Schema 的不確定性

**重要：** Phase 3 的 API 回應 schema 尚未確認（JS 只有端點 URL，沒有回應格式）。

**策略：**
1. 實作時先使用寬鬆的欄位存取（`.get()` with 預設值）
2. 第一次手動測試時記錄實際回應格式
3. 根據實際格式調整 Rich 表格的欄位名稱

## Acceptance Criteria

### Functional Requirements

- [x] `job104 applied [-p PAGE]` 可查看已應徵職缺清單
- [x] `job104 saved [-p PAGE]` 可查看收藏的職缺清單
- [x] `job104 interviews` 可查看面試邀請
- [x] `job104 resume` 可查看履歷資料
- [x] 所有命令支援 `--json` / `--yaml` 結構化輸出
- [x] 所有命令在未登入時顯示明確的錯誤訊息
- [x] `applied`/`saved` 命令結果整合 index cache（`job104 show N` 可用）
- [x] 分頁提示（如 `下一頁: job104 applied -p 2`）
- [x] 空結果時顯示友善提示（如 `暫無應徵紀錄`）

### Non-Functional Requirements

- [x] 使用 `pda.104.com.tw` 子域名的正確 Referer 標頭
- [x] Cookie 正確傳遞到 pda 子域名
- [x] 速率限制沿用現有 Gaussian jitter 機制
- [x] 所有 UI 文字使用繁體中文 (zh-TW)

### Quality Gates

- [x] 所有新命令有單元測試覆蓋
- [x] `ruff check` 通過
- [x] `--help` 所有命令可用且描述正確

## Dependencies & Prerequisites

- Phase 2 認證系統已完成 ✅
- 使用者需在瀏覽器中登入 104.com.tw 以使用 Cookie 認證
- **API 回應 schema 需在實作時透過手動測試確認**

## Risk Analysis & Mitigation

| 風險 | 影響 | 緩解策略 |
|------|------|----------|
| pda 子域名需要獨立 CF 預熱 | 403 錯誤 | 測試後按需新增 pda 預熱 |
| API 回應格式與預期不同 | 表格欄位錯位 | 使用 `.get()` 寬鬆存取，手動測試後調整 |
| pda 端點的 Referer 驗證更嚴格 | 請求被拒 | 根據 JS 分析設定端點特定 Referer |
| Session 過期信號不同於 www | 錯誤處理失敗 | 多重檢測機制（401/302/HTML） |
| 某些端點需要額外參數 | API 返回錯誤 | 手動測試時記錄必要參數 |

## Scope Decisions

### In Scope (Phase 3)
- 四個唯讀命令：applied, saved, interviews, resume
- 分頁支援
- 結構化輸出
- Index cache 整合

### Out of Scope (Future Phases)
- 寫入操作：save/unsave 職缺、投遞
- Saved jobs 資料夾篩選（`--folder`）
- 應徵狀態篩選（`--status viewed`）
- 瀏覽紀錄（`viewjobRecord`）
- 關注公司列表（`follow-company`）
- 訊息/聊天功能（`messages/chatrooms`）
- 通知設定管理

## Files to Create/Modify

### New Files
- `job104_cli/commands/personal.py` — 四個個人中心命令
- `tests/test_personal.py` — 個人中心命令測試

### Modified Files
- `job104_cli/client.py` — 新增 `_pda_request()` 和 4 個 API 方法
- `job104_cli/constants.py` — 新增 `PDA_BASE_URL`, `PDA_REFERER` 常數
- `job104_cli/commands/_common.py` — 新增 `require_auth()` helper
- `job104_cli/cli.py` — 註冊 personal 命令

## References & Research

### API Discovery (Reverse-Engineered)

API 端點從以下 JS bundle 中擷取：
- `cdn.104.com.tw/pda/cmy104/assets/js/chunk-common.z7KGcgrY.js` — 完整端點定義
- `cdn.104.com.tw/pda/cmy104/assets/js/chunk-stores.CQ6Txr97.js` — Store 配置
- `cdn.104.com.tw/pda/cmy104/assets/js/cmy104-applyRecord.DQwVmota.js` — Applied page Vue app

**Base URL 環境變數（來自 JS）：**
- `VUE_APP_MY104_API` = `//pda.104.com.tw/`
- `VUE_APP_PDABFF_API` = `//pda.104.com.tw/`
- `VUE_APP_CINDEX_API` = `//www.104.com.tw/`
- `VUE_APP_CMAIN_API` = `//www.104.com.tw/jobs/main/`

### Internal References

- 既有命令模式: `job104_cli/commands/search.py`
- 認證命令模式: `job104_cli/commands/auth.py:127-171` (`me` 命令)
- Handle command: `job104_cli/commands/_common.py:57-86`
- HTTP 客戶端: `job104_cli/client.py:40-68` (client init), `153-164` (Referer routing)
- Boss-cli personal 參考: `docs/refs/boss-cli/boss_cli/commands/personal.py`
- 原始 Phase 3 規劃: `docs/plans/2026-03-14-feat-104-cli-job-search-tool-plan.md:246-255`
