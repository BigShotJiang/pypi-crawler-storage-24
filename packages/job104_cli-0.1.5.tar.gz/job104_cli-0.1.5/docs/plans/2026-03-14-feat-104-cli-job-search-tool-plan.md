---
title: "feat: Build job104_cli — Taiwan 104 Job Bank CLI Tool"
type: feat
date: 2026-03-14
---

# feat: Build job104_cli — Taiwan 104 Job Bank CLI Tool

## Overview

建立台灣 104 人力銀行的 CLI 工具，讓 AI coding agent（如 Claude Code）和開發者可以在終端機中搜尋職缺、查看詳情、管理應徵紀錄。架構參考 [boss-cli](https://github.com/jackwener/boss-cli)，完整對齊其功能設計。

## Problem Statement

台灣最大的求職平台 104 人力銀行目前沒有 CLI 工具。求職者無法透過終端機或 AI agent 來程式化地搜尋、篩選和管理職缺資訊。現有的開源專案（如 job104_spider、scraper_104_1111）都是一次性爬蟲腳本，缺乏完整的 CLI 設計、結構化輸出和 agent 友善介面。

## Proposed Solution

以 Python 建立 `job104` CLI 工具（套件名 `job104-cli`），沿用 boss-cli 的架構模式：

- **Click** 作為 CLI 框架
- **httpx** 作為 HTTP 客戶端（含速率限制、重試、反偵測）
- **Rich** 作為終端機 UI（表格、面板、進度條）
- **browser-cookie3** 自動提取瀏覽器 Cookie
- 結構化 JSON/YAML 輸出（agent 友善）
- 透過 `uv tool install` / `pipx` 安裝

### 為何選用 `job104` 作為指令名稱

`104` 以數字開頭，在部分 shell 環境中可能造成解析問題，且無法作為 Python 識別符。`job104` 簡短易記、語意清楚，同時避免技術限制。

## Technical Approach

### Architecture

```
job104_cli/
├── __init__.py           # 套件版本
├── cli.py                # Click 進入點（輕量，add_command only）
├── client.py             # API 客戶端（速率限制、冷卻、重試、反偵測）
├── auth.py               # 認證（瀏覽器 Cookie 提取、TTL 刷新）
├── constants.py          # URL、標頭、地區代碼、篩選枚舉
├── exceptions.py         # 結構化例外（Job104ApiError 層級）
├── index_cache.py        # 短編號快取（job104 show）
└── commands/
    ├── __init__.py
    ├── _common.py        # SCHEMA envelope、handle_command、stderr console
    ├── auth.py           # login、logout、status、me
    ├── search.py         # search、detail、show、export、areas
    └── personal.py       # applied、saved、interviews
```

### 104 API 端點（已驗證）

| 功能 | 端點 | 認證 |
|------|------|------|
| 職缺搜尋 | `GET /jobs/search/list` | 不需要（公開） |
| 職缺詳情 | `GET /job/ajax/content/{jobId}` | 不需要（公開） |
| 登入 | `signin.104.com.tw` | Cookie-based |
| 個人資料 | 待逆向工程 | 需要 |
| 已應徵 | 待逆向工程 | 需要 |
| 收藏職缺 | 待逆向工程 | 需要 |
| 面試邀請 | 待逆向工程 | 需要 |

**關鍵差異：104 的搜尋和詳情 API 是公開的（不需要登入），這與 BOSS 直聘不同。**

### 104 搜尋 API 參數

```
GET https://www.104.com.tw/jobs/search/list

必要標頭：
  Referer: https://www.104.com.tw/jobs/search/

參數：
  keyword     - 搜尋關鍵字
  area        - 地區代碼（如 6001001000=台北市），可逗號分隔多個
  order       - 排序：1=符合度, 2=日期, 11=刊登日, 12=推薦, 13=薪資, 14=規模
  asc         - 排序方向：0=降序, 1=升序
  page        - 頁碼（1-indexed，最多 150 頁）
  pagesize    - 每頁筆數（預設 20）
  sctp        - 薪資類型：M=月薪, H=時薪, D=日薪
  scmin/scmax - 薪資範圍（數字）
  jobexp      - 經驗：1=1年以下, 3=1-3年, 5=3-5年, 10=5-10年, 99=10年以上
  edu         - 學歷：1=高中以下, 2=高中, 3=專科, 4=大學, 5=碩士, 6=博士
  jobcat      - 職務類別代碼（10位數，如 2007001004=軟體設計工程師）
  indcat      - 產業類別代碼（10位數）
  isnew       - 刊登天數：3, 7, 14, 30
  remoteWork  - 遠端：1=完全遠端, 2=部分遠端
  ro          - 結果類型：0=一般
  kwop        - 關鍵字搜尋範圍：7=全部欄位
  mode        - 搜尋模式：s
  jobsource   - 來源標識：2018indexpoc
```

### 104 搜尋回應結構

```json
{
  "data": {
    "totalCount": 1523,
    "totalPage": 77,
    "pageNo": 1,
    "pageSize": 20,
    "list": [
      {
        "jobNo": "abc123def",
        "jobName": "Python Backend Engineer",
        "link": {
          "job": "//www.104.com.tw/job/abc123def",
          "cust": "//www.104.com.tw/company/xyz789"
        },
        "custNo": "xyz789",
        "custName": "範例科技股份有限公司",
        "coIndustry": "軟體及網路相關業",
        "salaryLow": 50000,
        "salaryHigh": 70000,
        "salaryDesc": "月薪 50,000~70,000元",
        "jobAddrNoDesc": "台北市信義區",
        "appearDate": "2026/03/14",
        "optionEdu": "大學以上",
        "optionExp": "3年以上",
        "tags": ["Python", "Django", "PostgreSQL"],
        "applyCnt": 15,
        "remoteWorkType": 0
      }
    ]
  }
}
```

### 104 職缺詳情回應結構

```json
{
  "data": {
    "header": {
      "jobName": "Software Engineer",
      "custName": "Company Name",
      "salaryDesc": "月薪 50,000~70,000元"
    },
    "jobDetail": {
      "jobDescription": "完整職缺描述...",
      "jobCategory": [{"code": "2007001004", "desc": "軟體設計工程師"}],
      "addressRegion": "台北市",
      "addressDetail": "..."
    },
    "condition": {
      "workExp": "3年以上",
      "edu": "大學",
      "specialty": [{"code": "...", "desc": "Python"}]
    },
    "welfare": { "welfare": "三節獎金..." },
    "contact": { "hrName": "...", "email": "..." }
  }
}
```

### Implementation Phases

#### Phase 0: API 探索與資料收集

在正式開發前，需先完成 104 API 的逆向工程與資料收集。

- [ ] 使用瀏覽器 DevTools 擷取 104 的實際 API 請求和回應
- [ ] 記錄所有認證用 Cookie 名稱和範圍（domain: `.104.com.tw`）
- [ ] 收集完整的地區代碼對照表（城市 + 行政區）
- [ ] 收集職務類別代碼（`jobcat`）
- [ ] 收集產業類別代碼（`indcat`）
- [ ] 驗證搜尋 API 回應的欄位名稱和格式
- [ ] 探索個人中心的 API 端點（profile、applied、saved、interviews）
- [ ] 測試 104 的速率限制行為和錯誤回應格式
- [ ] 將結果記錄到 `docs/api-reference.md`

**交付物:** `docs/api-reference.md` 包含所有端點、參數、回應 schema 和 Cookie 資訊

#### Phase 1: 基礎建設 + 公開搜尋（無需認證）

核心架構和公開 API 功能。因為 104 的搜尋不需要認證，可以先完成這部分。

- [x] 建立專案結構（`pyproject.toml`、套件目錄）
- [x] 實作 `constants.py`：API URL、標頭、地區代碼、篩選枚舉
- [x] 實作 `exceptions.py`：Job104ApiError 層級
- [x] 實作 `client.py`：HTTP 客戶端含速率限制、Referer 標頭、重試邏輯
- [x] 實作 `commands/_common.py`：SCHEMA envelope、handle_command、stderr console
- [x] 實作 `commands/search.py`：
  - `job104 search <keyword>` 含所有篩選器
  - `job104 detail <jobId>` 查看職缺詳情
  - `job104 show <index>` 短編號導航
  - `job104 export <keyword>` CSV/JSON 匯出
  - `job104 areas` 列出支援的地區
- [x] 實作 `index_cache.py`：搜尋結果快取
- [x] 實作 `cli.py`：Click 進入點
- [x] 撰寫基礎測試

**交付物:**
- 可使用 `job104 search "Python" --area 台北` 搜尋職缺
- 可使用 `job104 show 3` 快速查看詳情
- 可使用 `job104 export "Python" -n 50 -o jobs.csv` 匯出
- 所有指令支援 `--json` / `--yaml` 結構化輸出

**檔案清單:**

```
job104_cli/__init__.py
job104_cli/cli.py
job104_cli/client.py
job104_cli/constants.py
job104_cli/exceptions.py
job104_cli/index_cache.py
job104_cli/commands/__init__.py
job104_cli/commands/_common.py
job104_cli/commands/search.py
pyproject.toml
tests/__init__.py
tests/conftest.py
tests/test_cli.py
```

#### Phase 2: 認證系統

瀏覽器 Cookie 提取和認證管理。

- [x] 實作 `auth.py`：
  - `Credential` 資料類別
  - `extract_browser_credential()`：從 Chrome/Firefox/Edge/Brave/Arc/Safari 提取 `.104.com.tw` Cookie
  - `save_credential()` / `load_credential()` / `clear_credential()`
  - Cookie TTL 自動刷新（預設 7 天）
  - `verify_credential()`：透過認證端點驗證 Cookie 有效性
- [x] 實作 `commands/auth.py`：
  - `job104 login`：自動偵測瀏覽器 Cookie
  - `job104 login --cookie-source chrome`：指定瀏覽器
  - `job104 login --cookie-file <path>`：手動匯入 Cookie 檔案
  - `job104 logout`：清除已存 Cookie
  - `job104 status`：檢查登入狀態（含 `--json`）
  - `job104 me`：查看個人資料
- [x] 撰寫認證相關測試

**交付物:**
- 可使用 `job104 login` 透過瀏覽器 Cookie 登入
- 可使用 `job104 status --json` 檢查登入狀態
- 認證 Cookie 安全儲存於 `~/.config/104-cli/credential.json`（權限 0o600）

#### Phase 3: 個人中心（需認證）

需要逆向工程 104 的個人中心 API 後才能實作。

- [ ] 實作 `commands/personal.py`：
  - `job104 applied`：查看已應徵職缺
  - `job104 saved`：查看收藏的職缺
  - `job104 interviews`：查看面試邀請
  - 查看目前已經填寫的履歷資料
- [ ] 所有指令支援分頁和結構化輸出
- [ ] 撰寫個人中心相關測試

**交付物:** 完整的個人中心功能

#### Phase 4: Agent 整合與文件

讓 AI agent 可以無縫使用此工具。

- [ ] 撰寫 `SKILL.md`：agent 使用指南（參考 boss-cli）
- [ ] 撰寫 `SCHEMA.md`：結構化輸出文件
- [ ] 撰寫 `README.md`：使用說明
- [ ] 設定 CI/CD（GitHub Actions）
- [ ] 發布到 PyPI（`job104-cli`）
- [ ] 支援 Skills CLI 安裝（`npx skills add`）

**交付物:** 完整的文件和 PyPI 發布

## Acceptance Criteria

### Functional Requirements

- [ ] `job104 search <keyword>` 可搜尋職缺，支援 `--area`、`--salary`、`--exp`、`--edu`、`--industry`、`--category`、`--isnew`、`--remote` 篩選
- [ ] `job104 detail <jobId>` 可查看職缺詳情
- [ ] `job104 show <index>` 可透過編號快速查看詳情
- [ ] `job104 export <keyword>` 可匯出 CSV/JSON
- [ ] `job104 areas` 可列出所有支援的地區代碼
- [ ] `job104 login` 可自動提取瀏覽器 Cookie
- [ ] `job104 login --cookie-source <browser>` 可指定瀏覽器
- [ ] `job104 login --cookie-file <path>` 可手動匯入 Cookie
- [ ] `job104 status` 可檢查登入狀態
- [ ] `job104 me` 可查看個人資料
- [ ] `job104 applied` 可查看已應徵職缺
- [ ] `job104 saved` 可查看收藏職缺
- [ ] `job104 interviews` 可查看面試邀請
- [ ] 所有指令支援 `--json` / `--yaml` 結構化輸出
- [ ] 非 TTY 環境自動使用 YAML 輸出
- [ ] Rich 輸出寫入 stderr，結構化資料寫入 stdout
- [ ] 所有使用者介面文字使用繁體中文 (zh-TW)

### Non-Functional Requirements

- [ ] 請求間加入高斯隨機延遲（~1-2s mean, σ=0.3）
- [ ] HTTP 429/5xx 自動重試含指數退避（最多 3 次）
- [ ] 正確的 Referer 標頭（104 的主要反爬蟲措施）
- [ ] Cookie 安全儲存（檔案權限 0o600）
- [ ] 支援 Python 3.10+
- [ ] 可透過 `uv tool install job104-cli` 安裝

### Quality Gates

- [ ] 核心功能有單元測試覆蓋
- [ ] `ruff check` 通過
- [ ] SKILL.md、SCHEMA.md、README.md 文件完整

## Key Constants (constants.py)

### 地區代碼（已知）

```python
AREA_CODES: dict[str, str] = {
    "全部": "",
    # 北部
    "台北市": "6001001000",
    "新北市": "6001002000",
    "基隆市": "6001004000",
    "桃園市": "6001005000",
    "新竹市": "6001006000",
    "苗栗縣": "6001007000",
    "宜蘭縣": "6001003000",
    # 中部
    "台中市": "6001008000",
    "彰化縣": "6001010000",
    # 南部
    "嘉義市": "6001012000",
    "台南市": "6001014000",
    "高雄市": "6001016000",
    "屏東縣": "6001018000",
    # 需補充: 南投、雲林、花蓮、台東、澎湖、金門、連江等
}
```

### 經驗代碼

```python
EXP_CODES: dict[str, str] = {
    "不限": "0",
    "1年以下": "1",
    "1-3年": "3",
    "3-5年": "5",
    "5-10年": "10",
    "10年以上": "99",
}
```

### 學歷代碼

```python
EDU_CODES: dict[str, str] = {
    "不限": "0",
    "高中以下": "1",
    "高中/高職": "2",
    "專科": "3",
    "大學": "4",
    "碩士": "5",
    "博士": "6",
}
```

## CLI 指令對照表

| boss-cli | job104_cli (job104) | 說明 |
|----------|------------------|------|
| `boss login` | `job104 login` | 登入 |
| `boss login --qrcode` | N/A | 104 無 QR 登入 |
| `boss login --cookie-source` | `job104 login --cookie-source` | 指定瀏覽器 |
| N/A | `job104 login --cookie-file` | 手動匯入 Cookie |
| `boss status` | `job104 status` | 登入狀態 |
| `boss logout` | `job104 logout` | 登出 |
| `boss search` | `job104 search` | 搜尋（104 不需認證） |
| `boss show` | `job104 show` | 短編號查看 |
| `boss detail` | `job104 detail` | 職缺詳情 |
| `boss export` | `job104 export` | 匯出 CSV/JSON |
| `boss recommend` | N/A（待探索） | 推薦職缺 |
| `boss history` | N/A（待探索） | 瀏覽歷史 |
| `boss me` | `job104 me` | 個人資料 |
| `boss applied` | `job104 applied` | 已應徵 |
| `boss interviews` | `job104 interviews` | 面試邀請 |
| `boss chat` | N/A | 104 無 chat 功能 |
| `boss greet` | N/A（待探索） | 打招呼/投遞 |
| `boss batch-greet` | N/A（待探索） | 批量投遞 |
| `boss cities` | `job104 areas` | 地區列表 |
| N/A | `job104 saved` | 收藏職缺（104 特有） |

## 與 boss-cli 的關鍵差異

| 面向 | BOSS 直聘 (boss-cli) | 104 人力銀行 (job104_cli) |
|------|---------------------|----------------------|
| Base URL | `www.zhipin.com` | `www.104.com.tw` |
| 搜尋認證 | 需要 | **不需要**（公開 API） |
| 反爬蟲關鍵 | `__zp_stoken__` | **Referer 標頭**驗證 |
| 登入方式 | Cookie + QR 掃碼 | Cookie only（無 QR） |
| 登入域名 | 同域名 | 獨立 `signin.104.com.tw` |
| 回應格式 | `zpData.jobList` | `data.list` |
| 職缺 ID | `securityId` | `jobNo`（從 link URL 提取） |
| 搜尋上限 | 未知 | ~3,000 筆（150 頁 x 20） |
| 語言 | 簡體中文 | **繁體中文** |
| Chat | MQTT/Protobuf | N/A |
| 貨幣 | CNY（人民幣） | **TWD（新台幣）** |

## Dependencies & Prerequisites

### Python 套件

```toml
[project]
dependencies = [
    "click>=8.0",
    "rich>=13.0",
    "httpx>=0.27",
    "browser-cookie3>=0.19",
    "pyyaml>=6.0",  # 列為正式依賴（agent 友善）
]

[project.optional-dependencies]
dev = [
    "pytest>=8.0",
    "ruff>=0.11.0",
]
```

### 前置條件

- Phase 0（API 探索）必須在 Phase 1 開始前完成
- 使用者需在瀏覽器中登入 104.com.tw 才能使用認證功能
- 需要 Python 3.10+

## Risk Analysis & Mitigation

| 風險 | 影響 | 緩解策略 |
|------|------|----------|
| 104 API 結構變更 | 搜尋功能中斷 | 結構化錯誤處理 + 版本化 schema |
| 104 加強反爬蟲 | 請求被封鎖 | 高斯延遲 + 指數退避 + 正確 Referer |
| 個人中心 API 難以逆向 | Phase 3 延遲 | Phase 1-2 可獨立運作 |
| Cookie 認證失效快 | 使用者體驗差 | TTL 自動刷新 + 明確錯誤訊息 |
| 104 使用 CAPTCHA | 自動化失敗 | 偵測 HTML 回應 + 提示使用者手動操作 |

## Limitations（已知限制）

- **無聊天訊息功能** — 104 的即時訊息無法透過 API 操作
- **無 QR 掃碼登入** — 104 不支援此功能
- **搜尋結果上限** — API 限制最多 150 頁（約 3,000 筆）
- **單一帳號** — 同一時間僅支援一組 Cookie
- **無投遞功能**（初期）— 需進一步探索 104 的投遞 API 是否可用
- **個人中心 API 待探索** — Phase 0 完成前無法確認所有端點

## References & Research

### Internal References

- boss-cli 參考架構: `docs/refs/boss-cli/`
- boss-cli CLI 進入點: `docs/refs/boss-cli/boss_cli/cli.py`
- boss-cli API 客戶端: `docs/refs/boss-cli/boss_cli/client.py`
- boss-cli 認證模組: `docs/refs/boss-cli/boss_cli/auth.py`
- boss-cli 常數定義: `docs/refs/boss-cli/boss_cli/constants.py`
- boss-cli SKILL.md: `docs/refs/boss-cli/SKILL.md`

### External References

- [blog.jiatool.com — 104 爬蟲教學](https://blog.jiatool.com/posts/job104_spider/) — 最詳細的 API 技術參考
- [mobiledev.tw — 聰明找工作!善用104人力銀行API](https://mobiledev.tw/104api/) — API 實用指南
- [GitHub: it-jia/job104_spider](https://github.com/it-jia/job104_spider) — 完整的 104 爬蟲專案
- [GitHub: SuYenTing/Python-web-crawler](https://github.com/SuYenTing/Python-web-crawler) — 104 搜尋爬蟲腳本
- [GitHub: yichenlai16/104-job-scraper](https://github.com/yichenlai16/104-job-scraper) — Scrapy 實作，記錄 150 頁限制
- [GitHub: kobojp/scraper_104_1111](https://github.com/kobojp/scraper_104_1111) — 104/1111 爬蟲含 Pandas
- [104 Developer Center](https://developers.104.com.tw/) — 官方企業 API（非公開求職者 API）
