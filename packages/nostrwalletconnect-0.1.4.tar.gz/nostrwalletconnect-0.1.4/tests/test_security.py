"""Security tests for NWC — secret redaction, input validation."""

import pytest

from nostrwalletconnect.connection import NWCConnection


# Valid test data
VALID_PUBKEY = "a" * 64
VALID_SECRET = "b" * 64
VALID_RELAY = "wss://relay.example.com"
VALID_URI = f"nostr+walletconnect://{VALID_PUBKEY}?relay={VALID_RELAY}&secret={VALID_SECRET}"


# ── Repr redaction ───────────────────────────────────────────


def test_connection_repr_redacts_secret():
    conn = NWCConnection.parse(VALID_URI)
    r = repr(conn)
    assert VALID_SECRET not in r
    assert "***" in r


def test_connection_repr_truncates_pubkey():
    conn = NWCConnection.parse(VALID_URI)
    r = repr(conn)
    # Full pubkey should not appear
    assert VALID_PUBKEY not in r
    # But first 8 chars should
    assert VALID_PUBKEY[:8] in r


def test_connection_format_redacts():
    conn = NWCConnection.parse(VALID_URI)
    s = f"Connection: {conn!r}"
    assert VALID_SECRET not in s


def test_connection_str_redacts():
    """str() falls back to repr for frozen dataclasses — verify it's safe."""
    conn = NWCConnection.parse(VALID_URI)
    # Even if someone does print(conn), the secret shouldn't appear
    r = repr(conn)
    assert VALID_SECRET not in r


# ── Input validation ─────────────────────────────────────────


def test_parse_rejects_empty_string():
    with pytest.raises(ValueError, match="non-empty"):
        NWCConnection.parse("")


def test_parse_rejects_whitespace():
    with pytest.raises(ValueError, match="non-empty"):
        NWCConnection.parse("   ")


def test_parse_rejects_wrong_scheme():
    with pytest.raises(ValueError, match="nostr\\+walletconnect://"):
        NWCConnection.parse("https://example.com")


def test_parse_error_doesnt_leak_uri():
    """Error message should NOT include the connection string content."""
    bad_uri = "http://secret-stuff-here"
    with pytest.raises(ValueError) as exc_info:
        NWCConnection.parse(bad_uri)
    assert "secret-stuff" not in str(exc_info.value)


def test_parse_rejects_invalid_pubkey():
    uri = f"nostr+walletconnect://tooshort?relay={VALID_RELAY}&secret={VALID_SECRET}"
    with pytest.raises(ValueError, match="64 hex"):
        NWCConnection.parse(uri)


def test_parse_rejects_invalid_secret():
    uri = f"nostr+walletconnect://{VALID_PUBKEY}?relay={VALID_RELAY}&secret=tooshort"
    with pytest.raises(ValueError, match="64 hex"):
        NWCConnection.parse(uri)


def test_parse_rejects_missing_relay():
    uri = f"nostr+walletconnect://{VALID_PUBKEY}?secret={VALID_SECRET}"
    with pytest.raises(ValueError, match="relay"):
        NWCConnection.parse(uri)


def test_parse_rejects_missing_secret():
    uri = f"nostr+walletconnect://{VALID_PUBKEY}?relay={VALID_RELAY}"
    with pytest.raises(ValueError, match="secret"):
        NWCConnection.parse(uri)


# ── to_uri still works (functional) ─────────────────────────


def test_roundtrip():
    conn = NWCConnection.parse(VALID_URI)
    reparsed = NWCConnection.parse(conn.to_uri())
    assert reparsed.wallet_pubkey == conn.wallet_pubkey
    assert reparsed.secret == conn.secret
    assert reparsed.relay == conn.relay


# ── Immutability ─────────────────────────────────────────────


def test_frozen():
    conn = NWCConnection.parse(VALID_URI)
    with pytest.raises(AttributeError):
        conn.secret = "changed"
