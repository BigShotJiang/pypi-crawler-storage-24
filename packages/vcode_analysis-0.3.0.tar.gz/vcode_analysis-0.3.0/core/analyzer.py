"""分析引擎核心

负责协调文件扫描、解析和各类分析器
"""

import fnmatch
from pathlib import Path
from dataclasses import dataclass, field
from typing import Optional, Iterator, Callable, Any
from concurrent.futures import ThreadPoolExecutor, as_completed
from .config import Config
from .git_handler import GitHandler
from .llm_client import LLMClient


@dataclass
class FileInfo:
    """文件信息"""
    path: Path
    relative_path: str
    extension: str
    size: int
    language: str
    content: Optional[str] = None


@dataclass
class AnalysisResult:
    """分析结果"""
    file_path: str
    analyzer: str
    success: bool
    content: str
    errors: list[str] = field(default_factory=list)
    metadata: dict = field(default_factory=dict)


class Analyzer:
    """分析引擎"""

    # 语言映射
    LANGUAGE_MAP = {
        ".py": "Python",
        ".java": "Java",
        ".kt": "Kotlin",
        ".kts": "Kotlin",
        ".js": "JavaScript",
        ".ts": "TypeScript",
        ".jsx": "JSX",
        ".tsx": "TSX",
        ".vue": "Vue",
        ".c": "C",
        ".h": "C",
        ".cpp": "C++",
        ".hpp": "C++",
        ".cc": "C++",
        ".cxx": "C++",
        ".go": "Go",
        ".rs": "Rust",
        ".rb": "Ruby",
        ".php": "PHP",
        ".cs": "C#",
        ".swift": "Swift",
        ".json": "JSON",
        ".yaml": "YAML",
        ".yml": "YAML",
        ".md": "Markdown",
        ".xml": "XML",
        ".properties": "Properties",
        ".gradle": "Gradle",
        ".sh": "Shell",
        ".bash": "Shell",
        ".sql": "SQL",
    }

    def __init__(self, config: Config):
        self.config = config
        self._llm_client: Optional[LLMClient] = None
        self._git_handler: Optional[GitHandler] = None

    @property
    def llm(self) -> LLMClient:
        """获取 LLM 客户端（懒加载）"""
        if self._llm_client is None:
            self._llm_client = LLMClient(
                base_url=self.config.llm.base_url,
                api_key=self.config.llm.api_key,
                model=self.config.llm.model,
                temperature=self.config.llm.temperature,
                max_tokens=self.config.llm.max_tokens,
                timeout=self.config.llm.timeout,
            )
        return self._llm_client

    @property
    def git(self) -> Optional[GitHandler]:
        """获取 Git 处理器（懒加载）"""
        if self._git_handler is None and self.config.target_path:
            handler = GitHandler(self.config.target_path)
            if handler.is_valid_repo():
                self._git_handler = handler
        return self._git_handler

    def _should_ignore(self, path: Path) -> bool:
        """检查是否应该忽略该路径"""
        path_str = str(path)
        for pattern in self.config.analysis.ignore_patterns:
            if fnmatch.fnmatch(path_str, pattern) or fnmatch.fnmatch(path.name, pattern):
                return True
        return False

    def _is_supported(self, path: Path) -> bool:
        """检查是否为支持的文件类型"""
        return path.suffix in self.config.analysis.supported_extensions

    def scan_files(self, target_path: str) -> Iterator[FileInfo]:
        """扫描目录获取文件列表"""
        root = Path(target_path)

        if not root.exists():
            raise FileNotFoundError(f"路径不存在: {target_path}")

        if root.is_file():
            # 单文件
            yield self._create_file_info(root, root.parent)
            return

        # 目录扫描
        for file_path in root.rglob("*"):
            if not file_path.is_file():
                continue
            if self._should_ignore(file_path):
                continue
            if not self._is_supported(file_path):
                continue

            yield self._create_file_info(file_path, root)

    def _create_file_info(self, file_path: Path, root: Path) -> FileInfo:
        """创建文件信息"""
        stat = file_path.stat()
        return FileInfo(
            path=file_path,
            relative_path=str(file_path.relative_to(root)),
            extension=file_path.suffix,
            size=stat.st_size,
            language=self.LANGUAGE_MAP.get(file_path.suffix, "Unknown"),
        )

    def read_file_content(self, file_info: FileInfo) -> str:
        """读取文件内容"""
        if file_info.content is not None:
            return file_info.content

        if file_info.size > self.config.analysis.max_file_size:
            raise ValueError(f"文件过大: {file_info.relative_path} ({file_info.size} bytes)")

        content = file_info.path.read_text(encoding="utf-8", errors="ignore")
        file_info.content = content
        return content

    def analyze_file(
        self,
        file_info: FileInfo,
        prompt_template: str,
        **extra_context
    ) -> AnalysisResult:
        """分析单个文件"""
        try:
            content = self.read_file_content(file_info)

            # 构建提示词
            prompt = prompt_template.format(
                file_path=file_info.relative_path,
                language=file_info.language,
                content=content,
                **extra_context,
            )

            response = self.llm.simple_chat(prompt)

            return AnalysisResult(
                file_path=file_info.relative_path,
                analyzer="generic",
                success=True,
                content=response,
            )

        except Exception as e:
            return AnalysisResult(
                file_path=file_info.relative_path,
                analyzer="generic",
                success=False,
                content="",
                errors=[str(e)],
            )

    def analyze_files_batch(
        self,
        file_infos: list[FileInfo],
        analyze_func: Callable[[FileInfo], AnalysisResult],
        progress_callback: Optional[Callable[[int, int, str], None]] = None,
    ) -> list[AnalysisResult]:
        """并发分析多个文件

        Args:
            file_infos: 文件信息列表
            analyze_func: 分析函数，接收 FileInfo 返回 AnalysisResult
            progress_callback: 进度回调函数 (current, total, file_path)

        Returns:
            分析结果列表
        """
        total = len(file_infos)
        results: list[AnalysisResult] = [None] * total  # type: ignore
        max_workers = self.config.analysis.max_workers

        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            # 提交所有任务，保存 future 和索引的映射
            future_to_index = {
                executor.submit(analyze_func, file_info): i
                for i, file_info in enumerate(file_infos)
            }

            # 收集结果
            completed = 0
            for future in as_completed(future_to_index):
                index = future_to_index[future]
                try:
                    result = future.result()
                    results[index] = result
                except Exception as e:
                    file_info = file_infos[index]
                    results[index] = AnalysisResult(
                        file_path=file_info.relative_path,
                        analyzer="generic",
                        success=False,
                        content="",
                        errors=[str(e)],
                    )

                completed += 1
                if progress_callback:
                    progress_callback(completed, total, file_infos[index].relative_path)

        return results

    def close(self) -> None:
        """释放资源"""
        if self._llm_client:
            self._llm_client.close()
            self._llm_client = None

    def __enter__(self) -> "Analyzer":
        return self

    def __exit__(self, *args) -> None:
        self.close()
