#!/usr/bin/env python3

"""
moontrack.py - generate a list of Moon azimuth and elevation records
for a period starting at a specified time. This is intended as input
to the skynoise function which generates sky noise temperatures
behind the Moon.

Copyright John C Sager 2026 - see LICENCE file
"""

import sys, math
import argparse
import tomllib
from astronomy import Observer, Time, Body, Equator, Horizon, Refraction

HR12 = 0.5 # days
LAT_DEFAULT = 52.2
LON_DEFAULT = 1.4


def getargs():
  parser = argparse.ArgumentParser(
    prog='moontrack',
    description='Generate a list of Moon azimuth and elevation')
  parser.add_argument('-l','--locfile',type=str,
    help='File with location information')
  parser.add_argument('-i','--interval',type=str, default='15',
    help='Interval between records. Default = 15 minutes')
  parser.add_argument('-p','--period',type=str, default='31',
    help='Period of records, Default = 31 days')
  parser.add_argument('-e','--minelevation',type=str, default='10.0',
    help='Minimum Elevation to track, Default = 10.0 degrees')
  parser.add_argument('latlon',nargs='?', type=str,
    help='Latitude & Longitude in the form lat:lon, Default = 52.2:1.4')
  parser.add_argument('starttime')
  return parser.parse_args() # from sys.argv

def main():

  try:
    args = getargs()
  except Exception as e:
    print("Failure getting arguments:",e, file=sys.stderr)
    sys.exit(1)

  Latitude = LAT_DEFAULT
  Longitude = LON_DEFAULT
  
  if args.locfile:
    try:
      lf = open(args.locfile,'rb')
    except OSError as e:
      print(f'Error opening file "{args.locfile:s}"',e, file=sys.stderr)
      sys.exit(1)

    loc = tomllib.load(lf)
    lf.close()
    
    Latitude = loc['Location']['Lat']
    Longitude = loc['Location']['Lon']
  else: # Lat:Lon must be on cmdline
    if args.latlon:
      try:
        lat,lon = args.latlon.split(':')
        Latitude = float(lat)
        Longitude = float(lon)
      except Exception as e:
        print('latlon error:',e, file=sys.stderr)
        sys.exit(1)


  Stime = args.starttime
  Interval = float(args.interval)/1440.0 # convert minutes to days
  Period = int(args.period)
  Minel = float(args.minelevation)
  
  body = Body.Moon

  observer = Observer(Latitude,Longitude,0.0)

  time = Time.Parse(Stime)

  dtime = 0.0

  alt = -1.0
  t = time
  while dtime < Period:
    while alt < Minel:
      dtime += Interval
      t = time.AddDays(dtime)
      eod = Equator(body,t,observer,ofdate=True,aberration=True)
      hor = Horizon(t,observer,eod.ra,eod.dec,Refraction.Airless)
      alt = hor.altitude

    while alt >= Minel:
      s = str(t) + f' {hor.ra*15:9.3f} {hor.dec:8.3f} {hor.azimuth:9.3f} {hor.altitude:8.3f}'
      print(s)
      dtime += Interval
      t = time.AddDays(dtime)
      eod = Equator(body,t,observer,ofdate=True,aberration=True)
      hor = Horizon(t,observer,eod.ra,eod.dec,Refraction.Airless)
      alt = hor.altitude
    dtime += HR12
#    print('')

if __name__ == "__main__":
  
  main()



