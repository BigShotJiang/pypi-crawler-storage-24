#!/usr/bin/python3

"""
skynoise.py - generate a noise temperature for an antenna by summing
the contributions of ground noise and sky noise over the gain pattern
of the antenna. Points on a sphere are modelled to approximate the
coverage of n x n degree patches covering the sphere.
Inputs to the program are a default configuration, A data file of
sky temperature at the frequency of interest, and the antenna model
from NEC2. The default configuration includes antenna location and
observation data to point the antenna under test to a low noise
part of the sky in the Northern Hemisphere. Optionally a secondary
configuration can be used to provide specific location and observation
information overriding the default values.

Copyright John C Sager 2025-2026 - see LICENCE file
"""


import sys, math
import importlib.resources as resources
from datetime import datetime
import numpy as np
import tomllib
import argparse
from astropy.io import fits
import astropy.units as u
from astropy_healpix import HEALPix as hp


# various constants
D2R = math.pi/180.0
R2D = 180.0/math.pi
AS2D = 1.0/3600.0 # convert arcsec to degrees

# constants for calculating sidereal time from USNO Circular 179
# Kaplan, 2005, Equations 2.11 and 2.12
# Just Y0, Y1 and Y2 give sufficient accuracy
X0 = 0.7790572732640
X1 = 0.00273781191135448
Y0 = 0.014506
Y1 = 4612.156534
Y2 = 1.3915817
Y3 = -0.00000044
Y4 = -0.000029956
Y5 = -0.0000000368

# Ground temperature

TGROUND = 290.0 # Kelvin

class Skynoise(object):
  """
  This class encapsulates all the functions required to calculate an
  average antenna temperature from a NEC2 or NEC4 model and a file of
  sky noise temperature data.
  """
  
  def __init__(self, conf):
    self.thrange = 180 # assumed
    self.phrange = 360 # assumed
    self.numth = None
    self.numph = None
    self.interval = None
    self.vecs = None # XYZ unit vectors of points
    self.rvecs = None # rotated XYZ vectors of points
    self.lmst = None # Local Mean Sidereal Time in degrees
    self.BScount = None # to index boresight vectors
    self.config = conf
    # Global config
    self.J2000tt = conf['Global']['J2000tt']
    self.J2000u = datetime(2000,1,1,12,0,0)
    # QTH
    self.LatD = conf['Location']['Lat']
    self.LonD = conf['Location']['Lon']
    self.LatR = self.LatD*D2R
    self.LonR = self.LonD*D2R
    # Observation direction at time
    self.Azimuth = conf['Observation']['Azimuth']
    self.Elevation = conf['Observation']['Elevation']
    self.ObTime = conf['Observation']['ObTime']

  def setTempFileName(self, name):
    self.Tempfile = self.config['Global'][name]
    return self.get_fits() # load the sky temperature data

  def get_fits(self):
    """
    Read the sky noise temperature data from the fits file. There
    are 196608 points in HEALPix format.
    """
    tfile = resources.files('skynoise').joinpath(self.Tempfile)
    try:
      hdulist = fits.open(tfile)
    except Exception as e:
      return f'Sky Temperature file failure: {e}'

    self.Healpix = hp.from_header(hdulist[1]) 
    self.Tempdata = hdulist[1].data['TEMPERATURE']
    hdulist.close()
    return None
  
  # utility functions

  def setxyz(self,idx,xyz,vecs):
    vecs[0][idx] = xyz[0]
    vecs[1][idx] = xyz[1]
    vecs[2][idx] = xyz[2]

  def getline(self,line, count):
    """
    Parse a radiation pattern line to extract theta, phi and
    gain. This needs to cope with negative theta, courtesy of
    4NEC2's perverse patterns where theta goes from -180 to 0
    rather than the more normal 0 to 180. The solution for
    negative theta values is to make theta positive and add
    180.0 to phi modulo 360.0.
    Fill in entries in self vecsn, self.gainarrn & self.sinarrn
    used later to calculate the average temperature.
    """
    
    if len(line) == 0: # assumes line is already stripped
      return None # end of data
    field = line.split(maxsplit=5)
    ths = field[0]
    phs = field[1]
    th = float(ths)
    ph = float(phs)
    dbs = float(field[4])
    if ph >= 359.99:
      return None # data beyond phi=359 we don't need
    if th < 0.0:
      # bloody 4NEC2! Move to positive theta domain
      th = -th
      ph += 180.0
      if ph >= 360.0:
        ph -= 360.0
    
    thr = th*D2R
    phr = ph*D2R
    if ths in self.scthetan:
      sth = self.scthetan[ths][0]
      cth = self.scthetan[ths][1]
    else:
      sth = math.sin(thr)
      cth = math.cos(thr)
      self.scthetan[ths] = (sth,cth)
    if phs in self.scphin:
      sph = self.scphin[phs][0]
      cph = self.scphin[phs][1]
    else:
      sph = math.sin(phr)
      cph = math.cos(phr)
      self.scphin[phs] = (sph,cph)
    x = sth*cph
    y = sth*sph
    z = cth
    db = float(dbs)
    lin = pow(10.0,db/10.0)
    self.gsarrn[count] = lin*sth
    self.sinaccn += sth
    self.gsaccn += lin*sth
    thi = int(th+0.1)
    if int(ph+0.1) == 0: # save specific gains
      if thi == 0:
        self.GZplusn = lin
      elif thi == 90:
        self.GXplusn = lin # boresight gain
        self.BScountn = count
      elif thi == 180:
        self.GZminusn = lin
    if thi == 0 or thi == 180: # ignore when filling arrays
      return 2
    self.setxyz(count,(x,y,z),self.vecsn)
    return 1

  def loadmodel(self,f):
    """
    Load the antenna model gains from a NEC2/4 output file and
    generate a np.array of XYZ coordinates to perform rotation
    of the pattern. The data is accumulated in temporary variables
    (with the suffix 'n') and the real ones updated if the read
    is successful.
    """
    state = 0
    while True:
      line = f.readline()
      ll = len(line)
      if ll == 0: # EOF
        break
      line = line.strip()
      # put state 4 first as it occurs most often
      if state == 4:
        d = self.getline(line,count)
        if d == None: # end of data
          state = 5
        if d == 1:
          count += 1
      elif state == 0: # ignore anything until radiation data
        if "RADIATION PATTERNS" in line:
          state = 1
          lcount = 0
        else:
          continue
      elif state == 1: # eat 3 lines
        if lcount >= 3:
          state = 2
          lcount = 0
        else:
          lcount += 1
          continue
      elif state == 2: # first pattern line
        firstline = line
        state = 3
      elif state == 3: # second pattern line
        # now process the first two lines
        ph0 = float(firstline.split(maxsplit=1)[0])
        ph1 = float(line.split(maxsplit=1)[0])
        interval = ph1-ph0
        numth = int(self.thrange/interval)+1
        numph = int(self.phrange/interval)
        cols = int((numth-2)*numph) # don't include redundant 0 & 180
        # array of point vectors to be rotated
        self.vecsn = np.empty((3,cols+2))
        self.gsarrn = np.empty(cols+2)
        self.sinaccn = 0.0
        self.gsaccn = 0.0
        self.scphin = {}
        self.scthetan = {}
        count = 0
        for l in [firstline, line]:
          d = self.getline(l,count)
          if d == 1:
            count += 1
        state = 4
      elif state == 5: # end of data, do some checks
        if count == cols:
          break
        else: # bad data read
          return 1
      
    # end of while loop
    if state == 5:
      # new model is OK, update all the instance variables to new model
      self.interval = interval
      self.numth = numth
      self.numph = numph
      self.vecs = self.vecsn
      self.gsarr = self.gsarrn
      self.sinacc = self.sinaccn
      self.gsacc = self.gsaccn
      self.scphi = self.scphin
      self.sctheta = self.scthetan
      self.GZplus = self.GZplusn
      self.GZminus = self.GZminusn
      self.GXplus = self.GXplusn
      self.BScount = self.BScountn
      #add + & - Z axis gains
      z = 1.0
      for gain in [self.GZplus,self.GZminus]:
        self.gsarr[count] = gain
        self.gsacc += gain
        # x, y not quite zero to avoid divide by zero errors
        self.setxyz(count,(1e-12,1e-12,z),self.vecs)
        z = -z
        count += 1
      # now calculate gainavg from the data just loaded
      self.gainavg = self.gsacc/self.sinacc
      return 0
    else:
      return 1

  def calclmst(self):
    """
    Calculate Local Mean Sidereal Time by reference to the J2000
    epoch. This uses constants X0, X1 and Y0 to Y2 defined at the
    beginning of this file. Kaplan equation 2.12 includes more terms
    but the accuracy just using Y0-Y2 is sufficient.
    """
    
    ddtt = self.ObTime-self.J2000tt
    ddut = self.ObTime-self.J2000u
    dtt = ddtt.days + (ddtt.microseconds/1000000.0+ddtt.seconds)/86400.0
    tc = dtt/36525.0
    h = (ddut.microseconds/1000000.0+ddut.seconds)/86400.0
    dut = ddut.days + h
    # equations 2.11 & 2.12 from Kaplan, 2005
    thetak = X0 + dut*X1 + h
    thetaki = int(thetak)
    thetakd = (thetak - thetaki)*360.0 # fraction of a day in degrees
    # ttcorr increases about 46 arcsec per year ~1200 arcsec in Jan 2026
#   ttcorrd = (((((tc*Y5+Y4)*tc+Y3)*tc+Y2)*tc+Y1)*tc+Y0)*AS2D
#   ttcorrd = ((((Y4*tc+Y3)*tc+Y2)*tc+Y1)*tc+Y0)*AS2D
#   ttcorrd = (((Y3*tc+Y2)*tc+Y1)*tc+Y0)*AS2D
    ttcorrd = ((Y2*tc+Y1)*tc+Y0)*AS2D # degrees
    gmstd = thetakd + ttcorrd # in degrees - may be >= 360!
    lmst = gmstd + self.LonD # lmst in degrees
    # reduce to 0.0 <= lmst < 360.0
    if lmst >= 360.0:
      lmst -= 360.0
    elif lmst < 0.0:
      lmst += 360.0
    self.lmst = lmst
  
  def model2had(self):
    """
    The antenna model has been converted to an array of unit vectors
    self.vecs, in loadmodel(). The antenna boresight is along the +X
    axis. In terms of geographical coordinates this is due South at
    zero degrees elevation. To rotate that vector to point to the
    given azimuth and elevation, rotate on the Y axis by the elevation
    angle, then rotate about the Z axis to move the elevated vector to
    point in the azimuth direction. The rotation angle is negative if
    clockwise (in the antenna coordinate system). The matrix below
    combines both rotations into one. The rotated vectors, self.rvecs,
    are then converted to Hour Angle (HA) and Declination arrays in the
    Celestial coordinate system using latitude and longitude of the
    observing location. HA and Declination only need to be recalculated
    if antenna latitude or antenna pointing (Az, El) are changed.
    """

    elr = self.Elevation*D2R
    zrot = (180.0-self.Azimuth)*D2R

    cz = math.cos(zrot)
    sz = math.sin(zrot)
    ce = math.cos(elr)
    se = math.sin(elr)

    rm = np.array(((cz*ce,-sz,-cz*se),(sz*ce,cz,-sz*se),(se,0.0,ce)))
    # @ is matrix multiplication operator in numpy
    self.rvecs = rm @ self.vecs

    # calculate dec and ha from xyz & latitude

    sla = math.sin(self.LatR)
    cla = math.cos(self.LatR)
    
    x = self.rvecs[0]
    y = self.rvecs[1]
    z = self.rvecs[2]
    h = np.sqrt(x*x+y*y)
    h2 = np.sqrt(h*h+z*z)
    caz = -x/h
    sel = z/h2
    cel = h/h2
    sde = sel*sla+cla*cel*caz
    sde2 = np.where(sde>1.0,1.0,sde) # avoid math errors
    sde = np.where(sde2<-1.0,-1.0,sde2) # avoid math errors
    dec = np.arcsin(sde)
    cde = np.cos(dec)
    cha = (sel-sla*sde)/(cla*cde)
    cha2 = np.where(cha>1.0,1.0,cha) # avoid math errors
    cha = np.where(cha2<-1.0,-1.0,cha2) # avoid math errors
    ha1 = np.arccos(cha)
    self.HAarr = np.where(y>=0.0,math.tau-ha1,ha1) * R2D # Hour Angle in degrees
    self.Decarr = dec * R2D

  def had2temp(self):
    """
    This is run if time or longitude change to calculate the Right Ascension
    array and then from that and the Declination array the sky
    temperature at each vector is interpolated from the sky temperature
    data.
    """
    
    ra = self.lmst-self.HAarr # RA in degrees
    ra[ra < 0.0] += 360.0
    ra[ra >= 360.0] -= 360.0
    self.RAarr = ra
    self.Temparr = self.Healpix.interpolate_bilinear_lonlat(
      ra*u.degree,self.Decarr*u.degree,self.Tempdata)
  
  def boresight(self):
    """
    Return boresight ra, dec
    """
    return (self.RAarr[self.BScount], self.Decarr[self.BScount])

  def patsum(self):
    """
    Generate an array of temperatures as seen by the antenna. Points
    on and below the horizon have a standard temperature (TGROUND).
    Using the previously computed gain*sin(theta) array,
    average temperature is sum(temperature*gain')/sum(gain').
    """
    
    if self.BScount == None:
      return None # no data
    
    z = self.rvecs[2] # to test for horizon or below
    temp = np.where(z<=0.0,TGROUND,self.Temparr)
    tempgain = self.gsarr*temp
    tgsum = np.sum(tempgain)

# moon noise test
#    gain = self.GXplus
#    temp = 25 # 100K divide by 4 as moon is only 1/2 degree across
#    tgsum += temp*gain
    
    self.tempavg = tgsum/self.gsacc
    return (self.tempavg,self.gsacc,self.gainavg)

  def runtrack(self, f):
    """
    Read time, azimuth, elevation from file, then calculate lmst,
    rotate NEC vectors, calculate ra/dec & then find temperature
    """
    print('   Date     Time             RA       Dec       Az       El     Temperature')

    while True:
      line = f.readline()
      ll = len(line)
      if ll == 0: # EOF
        break
      line = line.strip()
      if len(line) == 0: # blank
        print('')
        continue
      if line[0] != '2': # time is first field - 20xx
        continue
      field = line.split()
      if len(field) != 5:
        continue
      try:
        time = datetime.fromisoformat(field[0][:-1])
      except ValueError as e:
        print(e, file=sys.stderr)
        continue
      self.ObTime = time
      self.Azimuth = float(field[3])
      self.Elevation = float(field[4])
#      ra = float(field[1])
#      dec = float(field[2])
      self.calclmst()
      self.model2had()
      self.had2temp()
      d = self.patsum()
      print(line + f'   {d[0]:8.3f}')

# end of Skynoise class

def getargs():
  parser = argparse.ArgumentParser(
    prog='skynoise',
    description='Calculate the Antenna temperature from the input model')
  parser.add_argument('-c','--conf',type=str,
    help='Additional configuration file')
  parser.add_argument('-f','--freq',type=str, default='144',
    help='Sky temperature to use 144 or 432. Default=144')
  parser.add_argument('-t','--tfile',type=str,
    help='Tracking file - for temperature of moon positions')
  parser.add_argument('modelfile')
  return parser.parse_args() # from sys.argv

def main():
  try:
    args = getargs()
  except Exception as e:
    print("Failure getting arguments:",e, file=sys.stderr)
    sys.exit(1)
  
  cfile = resources.files('skynoise').joinpath('config.toml')
  try:
    cf = cfile.open('rb')
  except OSError as e:
    print(f'Error opening file "config.toml"',e, file=sys.stderr)
    sys.exit(1)

  config = tomllib.load(cf)
  cf.close()
  
  if args.conf:
    try:
      cf = open(args.conf, 'rb')
    except OSError as e:
      print(f'Error opening file {args.conf:s}',e, file=sys.stderr)
      sys.exit(1)

    config2 = tomllib.load(cf)
    cf.close()
    # assume only 1 level of descent required
    for k0 in config.keys():
      if k0 in config2:
        config[k0].update(config2[k0])

  if args.freq not in ['144','432']:
    print(f'Error in frequency - must be 144 or 432', file=sys.stderr)
    sys.exit(1)
  
  if args.tfile: # list of moon positions
    try:
      tracfile = open(args.tfile, 'rt')
    except OSError as e:
      print(f'Error opening file {args.tfile:s}',e, file=sys.stderr)
      sys.exit(1)


  try:
    # NEC2/4 produce ASCII output, not UTF-8
    modfile = open(args.modelfile, 'rt', encoding='ascii')
  except OSError as e:
    print(f'Error opening file {args.modelfile:s}',e, file=sys.stderr)
    sys.exit(1)

  
  sn = Skynoise(config)
  ret = sn.setTempFileName('Temp' + args.freq)
  if ret != None: # temp file error
    print(ret, file=sys.stderr)
    sys.exit(1)

  if sn.loadmodel(modfile) != 0:
    print("Problem with radiation pattern data", file=sys.stderr)
    sys.exit(1)
  modfile.close()
  if args.tfile: # run tracking instead
    sn.runtrack(tracfile)
    tracfile.close()
    sys.exit(0)

  sn.calclmst()
  # rotate model vectors then calculate Hour Angle & Declination
  sn.model2had()
  # get sky temperature array from Hour Angle, Declination & lmst
  sn.had2temp()

  # calculate antenna temperature from gain and sky temps
  d = sn.patsum()
  if d == None:
    print("Error: antenna model not loaded", file=sys.stderr)
    sys.exit(1)

  ra,dec = sn.boresight()
  print(f'Boresight RA,Dec: {ra:.3f} {dec:.3f}')
  print(f'Average Temperature: {d[0]:.3f}K')
  print(f'Gain Average: {d[2]:.3f}')

if __name__ == "__main__":
  
  main()
