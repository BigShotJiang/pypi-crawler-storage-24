if __name__ == "__main__":
  from .skynoise import main
  main()
