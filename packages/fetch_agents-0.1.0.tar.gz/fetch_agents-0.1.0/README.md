# fetch-agents

Python client for the [AgentsLab](https://agentslab.duckdns.org) AI agent services.

Three agents, one SDK:
- **Code Context Agent** — slim, map, extract, mark code layers
- **Context Doctor** — compress, analyze, optimize LLM context windows
- **AI Teleporter** — teleport, search, merge chat export knowledge bases

## Install

```bash
pip install fetch-agents
```

## Quick Start

```python
from fetch_agents import FetchAgents

# Register once (free, no email required)
info = FetchAgents.register(name="myapp")
api_key = info["api_key"]  # save this

client = FetchAgents(api_key=api_key)

# Slim a code file to only the layers relevant to your task
result = client.slim(
    url="https://raw.githubusercontent.com/you/repo/main/app.py",
    task="fix the auth handler"
)
print(result["context"])

# Compress LLM context to reduce tokens
result = client.compress(text="...long assistant output...", max_length=200)
print(result["compressed"])

# Teleport a chat export into a searchable knowledge base
with open("chatgpt_export.json") as f:
    data = f.read()
index = client.teleport(data)
hits = client.search(index["index_id"], query="how do I fix auth?")
```

## API Key via Environment

```bash
export FETCH_API_KEY=fak_xxx
```

```python
client = FetchAgents()  # picks up FETCH_API_KEY automatically
```

## Free Tier

50 requests/day per key, no credit card needed. For higher volume, top up with crypto:

```python
invoice = client.topup(amount_usd=5, currency="btc")
print(invoice["pay_url"])  # pay this address
```

Supported: BTC, LTC, BCH, DOGE, TRX, ETH, BNB, USDT, USDC, and more.

## All Methods

| Method | Agent | Description |
|--------|-------|-------------|
| `register(name)` | — | Self-service registration, returns API key |
| `me()` | — | Quota + balance |
| `topup(amount_usd, currency)` | — | Create crypto invoice |
| `topup_status(invoice_id)` | — | Check invoice status |
| `currencies()` | — | List supported currencies |
| `slim(url, task)` | Code Context | Relevant layers only |
| `map(url)` | Code Context | List all LAYER sections |
| `extract(url, layer)` | Code Context | Extract one layer |
| `mark(url)` | Code Context | Auto-insert LAYER markers |
| `compress(text, max_length)` | Context Doctor | Token-compress text |
| `analyze(messages)` | Context Doctor | Score messages by importance |
| `optimize(messages)` | Context Doctor | Remove noise, compress verbose turns |
| `extract_memory(messages)` | Context Doctor | Extract structured facts |
| `teleport(data)` | AI Teleporter | Upload chat export, create index |
| `search(index_id, query, top_k)` | AI Teleporter | Semantic search |
| `merge(index_ids)` | AI Teleporter | Merge indexes |
| `formats()` | AI Teleporter | List supported export formats |

## Links

- Website & docs: https://agentslab.duckdns.org
- Issues: https://github.com/SoftwareValete/fetch-agents/issues
