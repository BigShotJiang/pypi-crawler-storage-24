"""fetch-agents Python client."""
import os
import time
import json
from typing import Any, Optional, Union

import httpx

from .exceptions import (
    AuthError, PaymentError, RateLimitError, NotFoundError, ServerError, FetchAgentsError
)

DEFAULT_BASE_URL = "https://agentslab.duckdns.org"
_MAX_RETRIES = 3
_RETRY_DELAY = 1.0  # seconds, doubled each retry


class FetchAgents:
    """
    Client for the fetch.ai agents REST API.

    Usage:
        client = FetchAgents(api_key="fak_xxx")
        result = client.slim(url="https://raw.githubusercontent.com/.../app.py", task="fix auth")

    The api_key can also be set via the FETCH_API_KEY environment variable.
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = 30.0,
    ):
        self._api_key = api_key or os.getenv("FETCH_API_KEY", "")
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._http = httpx.Client(timeout=timeout)

    def _headers(self) -> dict:
        h = {"Content-Type": "application/json"}
        if self._api_key:
            h["X-API-Key"] = self._api_key
        return h

    def _raise_for_status(self, resp: httpx.Response) -> None:
        if resp.status_code == 200:
            return
        try:
            detail = resp.json().get("detail", resp.text)
        except Exception:
            detail = resp.text
        sc = resp.status_code
        if sc in (401, 403):
            raise AuthError(detail, status_code=sc)
        if sc == 402:
            raise PaymentError(detail, topup_url="/topup")
        if sc == 404:
            raise NotFoundError(detail, status_code=404)
        if sc == 429:
            raise RateLimitError(detail, status_code=429)
        if sc >= 500:
            raise ServerError(detail, status_code=sc)
        raise FetchAgentsError(detail, status_code=sc)

    def _post(self, path: str, payload: dict) -> dict:
        """POST with auto-retry on 429."""
        delay = _RETRY_DELAY
        for attempt in range(_MAX_RETRIES):
            try:
                resp = self._http.post(
                    f"{self._base_url}{path}",
                    json=payload,
                    headers=self._headers(),
                )
                if resp.status_code == 429 and attempt < _MAX_RETRIES - 1:
                    time.sleep(delay)
                    delay *= 2
                    continue
                self._raise_for_status(resp)
                return resp.json()
            except (AuthError, PaymentError, NotFoundError, ServerError, FetchAgentsError):
                raise
            except httpx.TimeoutException:
                if attempt == _MAX_RETRIES - 1:
                    raise FetchAgentsError("Request timed out")
                time.sleep(delay)
                delay *= 2
        raise FetchAgentsError("Max retries exceeded")

    def _get(self, path: str, params: Optional[dict] = None) -> dict:
        resp = self._http.get(
            f"{self._base_url}{path}",
            params=params,
            headers=self._headers(),
        )
        self._raise_for_status(resp)
        return resp.json()

    # ── Account ──────────────────────────────────────────────────────────

    @staticmethod
    def register(name: str = "", base_url: str = DEFAULT_BASE_URL) -> dict:
        """
        Self-service registration. No API key required.
        Returns {"api_key": "fak_xxx", "user_id": ..., "free_requests_per_day": 50, ...}
        """
        resp = httpx.post(
            f"{base_url.rstrip('/')}/register",
            json={"name": name},
            headers={"Content-Type": "application/json"},
            timeout=15,
        )
        if resp.status_code == 429:
            raise RateLimitError(resp.json().get("detail", "Too many registrations"), status_code=429)
        resp.raise_for_status()
        return resp.json()

    def me(self) -> dict:
        """Return current user quota and balance.
        Returns {"user_id": ..., "free_remaining_today": N, "balance_fet": F}
        """
        return self._get("/code/me")

    def topup(self, amount_usd: float, currency: str) -> dict:
        """Create a crypto top-up invoice.
        Returns {"invoice_id": ..., "pay_url": ..., "address": ..., "fet_credits": F, ...}
        """
        return self._post("/code/topup", {"amount_usd": amount_usd, "currency": currency})

    def topup_status(self, invoice_id: str) -> dict:
        """Check a top-up invoice status."""
        return self._get(f"/code/topup/{invoice_id}")

    def currencies(self) -> dict:
        """List supported cryptocurrencies and FET rate."""
        return self._get("/code/currencies")

    # ── Code Context Agent ────────────────────────────────────────────────

    def map(self, url: str) -> dict:
        """List all LAYER sections in a code file.
        Args:
            url: Raw URL to the code file (e.g. raw GitHub URL)
        """
        return self._post("/code/map", {"url": url})

    def slim(self, url: str, task: str) -> dict:
        """Return only layers relevant to a task — reduces tokens dramatically.
        Args:
            url: Raw URL to the code file
            task: What you're trying to do (e.g. "fix the auth handler")
        """
        return self._post("/code/slim", {"url": url, "task": task})

    def extract(self, url: str, layer: str) -> dict:
        """Extract one named LAYER section from a code file.
        Args:
            url: Raw URL to the code file
            layer: Layer name (case-insensitive, e.g. "AUTH")
        """
        return self._post("/code/extract", {"url": url, "layer": layer})

    def mark(self, url: str) -> dict:
        """Auto-insert LAYER markers into unmarked code.
        Args:
            url: Raw URL to the code file
        """
        return self._post("/code/mark", {"url": url})

    # ── Context Doctor ────────────────────────────────────────────────────

    def compress(self, text: str, max_length: int = 500) -> dict:
        """Compress a text block to reduce tokens.
        Args:
            text: Text to compress
            max_length: Target length in words (default 500)
        """
        return self._post("/context/compress", {"text": text, "max_length": max_length})

    def analyze(self, messages: list[dict[str, Any]]) -> dict:
        """Score each message by importance (0-100). Identify noise and waste.
        Args:
            messages: List of {"role": "user"/"assistant", "content": "..."} dicts
        """
        return self._post("/context/analyze", {"messages": messages})

    def optimize(self, messages: list[dict[str, Any]]) -> dict:
        """Remove low-value messages and compress verbose turns.
        Args:
            messages: List of {"role": ..., "content": ...} dicts
        """
        return self._post("/context/optimize", {"messages": messages})

    def extract_memory(self, messages: list[dict[str, Any]]) -> dict:
        """Extract structured facts, preferences, events, and knowledge.
        Args:
            messages: List of {"role": ..., "content": ...} dicts
        """
        return self._post("/context/extract-memory", {"messages": messages})

    # ── AI Teleporter ─────────────────────────────────────────────────────

    def teleport(self, data: Union[str, dict]) -> dict:
        """Upload a chat export and create a searchable knowledge base.
        Args:
            data: Chat export JSON — either a string or a dict (auto-serialized)
        Supports: ChatGPT, Claude, GitHub Copilot, Cursor, generic exports.
        """
        if isinstance(data, dict):
            data = json.dumps(data)
        return self._post("/teleport/teleport", {"data": data})

    def search(self, index_id: str, query: str, top_k: int = 5) -> dict:
        """Semantic search across a teleported knowledge base.
        Args:
            index_id: Index ID returned by teleport()
            query: Natural language search query
            top_k: Number of results (default 5, max 20)
        """
        return self._post("/teleport/search", {"index_id": index_id, "query": query, "top_k": top_k})

    def merge(self, index_ids: list[str]) -> dict:
        """Merge multiple indexes into one.
        Args:
            index_ids: List of index IDs to merge
        """
        return self._post("/teleport/merge", {"index_ids": index_ids})

    def formats(self) -> dict:
        """List supported chat export formats (no auth required)."""
        return self._get("/teleport/formats")

    def __repr__(self) -> str:
        masked = self._api_key[:12] + "..." if self._api_key else "(no key)"
        return f"FetchAgents(api_key={masked}, base_url={self._base_url!r})"
