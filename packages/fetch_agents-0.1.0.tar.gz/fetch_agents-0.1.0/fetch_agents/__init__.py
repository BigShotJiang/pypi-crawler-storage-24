"""fetch-agents: Python client for fetch.ai AI agent services."""
from .client import FetchAgents
from .exceptions import (
    FetchAgentsError,
    AuthError,
    PaymentError,
    RateLimitError,
    NotFoundError,
    ServerError,
)

__version__ = "0.1.0"
__all__ = [
    "FetchAgents",
    "FetchAgentsError",
    "AuthError",
    "PaymentError",
    "RateLimitError",
    "NotFoundError",
    "ServerError",
]
