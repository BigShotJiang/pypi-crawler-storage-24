"""Typed exceptions for the fetch-agents SDK."""


class FetchAgentsError(Exception):
    """Base exception for all fetch-agents errors."""
    def __init__(self, message: str, status_code: int = 0):
        super().__init__(message)
        self.status_code = status_code


class AuthError(FetchAgentsError):
    """Raised on 401 (missing/invalid key) or 403 (disabled key)."""
    pass


class PaymentError(FetchAgentsError):
    """Raised on 402 (free tier exhausted and no balance).

    Attributes:
        topup_url: relative path to create a topup invoice (e.g. '/topup')
        detail: full error message from the server
    """
    def __init__(self, message: str, topup_url: str = "/topup"):
        super().__init__(message, status_code=402)
        self.topup_url = topup_url
        self.detail = message


class RateLimitError(FetchAgentsError):
    """Raised on 429 (too many requests). SDK auto-retries 3x before raising."""
    pass


class NotFoundError(FetchAgentsError):
    """Raised on 404."""
    pass


class ServerError(FetchAgentsError):
    """Raised on 5xx responses."""
    pass
