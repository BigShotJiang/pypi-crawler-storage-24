"""
Type annotations for storagegateway service client paginators.

[Documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_storagegateway/paginators/)

Copyright 2026 Vlad Emelianov

Usage::

    ```python
    from aiobotocore.session import get_session

    from types_aiobotocore_storagegateway.client import StorageGatewayClient
    from types_aiobotocore_storagegateway.paginator import (
        DescribeTapeArchivesPaginator,
        DescribeTapeRecoveryPointsPaginator,
        DescribeTapesPaginator,
        DescribeVTLDevicesPaginator,
        ListCacheReportsPaginator,
        ListFileSharesPaginator,
        ListFileSystemAssociationsPaginator,
        ListGatewaysPaginator,
        ListTagsForResourcePaginator,
        ListTapePoolsPaginator,
        ListTapesPaginator,
        ListVolumesPaginator,
    )

    session = get_session()
    with session.create_client("storagegateway") as client:
        client: StorageGatewayClient

        describe_tape_archives_paginator: DescribeTapeArchivesPaginator = client.get_paginator("describe_tape_archives")
        describe_tape_recovery_points_paginator: DescribeTapeRecoveryPointsPaginator = client.get_paginator("describe_tape_recovery_points")
        describe_tapes_paginator: DescribeTapesPaginator = client.get_paginator("describe_tapes")
        describe_vtl_devices_paginator: DescribeVTLDevicesPaginator = client.get_paginator("describe_vtl_devices")
        list_cache_reports_paginator: ListCacheReportsPaginator = client.get_paginator("list_cache_reports")
        list_file_shares_paginator: ListFileSharesPaginator = client.get_paginator("list_file_shares")
        list_file_system_associations_paginator: ListFileSystemAssociationsPaginator = client.get_paginator("list_file_system_associations")
        list_gateways_paginator: ListGatewaysPaginator = client.get_paginator("list_gateways")
        list_tags_for_resource_paginator: ListTagsForResourcePaginator = client.get_paginator("list_tags_for_resource")
        list_tape_pools_paginator: ListTapePoolsPaginator = client.get_paginator("list_tape_pools")
        list_tapes_paginator: ListTapesPaginator = client.get_paginator("list_tapes")
        list_volumes_paginator: ListVolumesPaginator = client.get_paginator("list_volumes")
    ```
"""

from __future__ import annotations

import sys
from typing import TYPE_CHECKING

from aiobotocore.paginate import AioPageIterator, AioPaginator

from .type_defs import (
    DescribeTapeArchivesInputPaginateTypeDef,
    DescribeTapeArchivesOutputTypeDef,
    DescribeTapeRecoveryPointsInputPaginateTypeDef,
    DescribeTapeRecoveryPointsOutputTypeDef,
    DescribeTapesInputPaginateTypeDef,
    DescribeTapesOutputTypeDef,
    DescribeVTLDevicesInputPaginateTypeDef,
    DescribeVTLDevicesOutputTypeDef,
    ListCacheReportsInputPaginateTypeDef,
    ListCacheReportsOutputTypeDef,
    ListFileSharesInputPaginateTypeDef,
    ListFileSharesOutputTypeDef,
    ListFileSystemAssociationsInputPaginateTypeDef,
    ListFileSystemAssociationsOutputTypeDef,
    ListGatewaysInputPaginateTypeDef,
    ListGatewaysOutputTypeDef,
    ListTagsForResourceInputPaginateTypeDef,
    ListTagsForResourceOutputTypeDef,
    ListTapePoolsInputPaginateTypeDef,
    ListTapePoolsOutputTypeDef,
    ListTapesInputPaginateTypeDef,
    ListTapesOutputTypeDef,
    ListVolumesInputPaginateTypeDef,
    ListVolumesOutputTypeDef,
)

if sys.version_info >= (3, 12):
    from typing import Unpack
else:
    from typing_extensions import Unpack

__all__ = (
    "DescribeTapeArchivesPaginator",
    "DescribeTapeRecoveryPointsPaginator",
    "DescribeTapesPaginator",
    "DescribeVTLDevicesPaginator",
    "ListCacheReportsPaginator",
    "ListFileSharesPaginator",
    "ListFileSystemAssociationsPaginator",
    "ListGatewaysPaginator",
    "ListTagsForResourcePaginator",
    "ListTapePoolsPaginator",
    "ListTapesPaginator",
    "ListVolumesPaginator",
)

if TYPE_CHECKING:
    _DescribeTapeArchivesPaginatorBase = AioPaginator[DescribeTapeArchivesOutputTypeDef]
else:
    _DescribeTapeArchivesPaginatorBase = AioPaginator  # type: ignore[assignment]

class DescribeTapeArchivesPaginator(_DescribeTapeArchivesPaginatorBase):
    """
    [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/storagegateway/paginator/DescribeTapeArchives.html#StorageGateway.Paginator.DescribeTapeArchives)
    [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_storagegateway/paginators/#describetapearchivespaginator)
    """
    def paginate(  # type: ignore[override]
        self, **kwargs: Unpack[DescribeTapeArchivesInputPaginateTypeDef]
    ) -> AioPageIterator[DescribeTapeArchivesOutputTypeDef]:
        """
        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/storagegateway/paginator/DescribeTapeArchives.html#StorageGateway.Paginator.DescribeTapeArchives.paginate)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_storagegateway/paginators/#describetapearchivespaginator)
        """

if TYPE_CHECKING:
    _DescribeTapeRecoveryPointsPaginatorBase = AioPaginator[DescribeTapeRecoveryPointsOutputTypeDef]
else:
    _DescribeTapeRecoveryPointsPaginatorBase = AioPaginator  # type: ignore[assignment]

class DescribeTapeRecoveryPointsPaginator(_DescribeTapeRecoveryPointsPaginatorBase):
    """
    [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/storagegateway/paginator/DescribeTapeRecoveryPoints.html#StorageGateway.Paginator.DescribeTapeRecoveryPoints)
    [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_storagegateway/paginators/#describetaperecoverypointspaginator)
    """
    def paginate(  # type: ignore[override]
        self, **kwargs: Unpack[DescribeTapeRecoveryPointsInputPaginateTypeDef]
    ) -> AioPageIterator[DescribeTapeRecoveryPointsOutputTypeDef]:
        """
        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/storagegateway/paginator/DescribeTapeRecoveryPoints.html#StorageGateway.Paginator.DescribeTapeRecoveryPoints.paginate)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_storagegateway/paginators/#describetaperecoverypointspaginator)
        """

if TYPE_CHECKING:
    _DescribeTapesPaginatorBase = AioPaginator[DescribeTapesOutputTypeDef]
else:
    _DescribeTapesPaginatorBase = AioPaginator  # type: ignore[assignment]

class DescribeTapesPaginator(_DescribeTapesPaginatorBase):
    """
    [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/storagegateway/paginator/DescribeTapes.html#StorageGateway.Paginator.DescribeTapes)
    [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_storagegateway/paginators/#describetapespaginator)
    """
    def paginate(  # type: ignore[override]
        self, **kwargs: Unpack[DescribeTapesInputPaginateTypeDef]
    ) -> AioPageIterator[DescribeTapesOutputTypeDef]:
        """
        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/storagegateway/paginator/DescribeTapes.html#StorageGateway.Paginator.DescribeTapes.paginate)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_storagegateway/paginators/#describetapespaginator)
        """

if TYPE_CHECKING:
    _DescribeVTLDevicesPaginatorBase = AioPaginator[DescribeVTLDevicesOutputTypeDef]
else:
    _DescribeVTLDevicesPaginatorBase = AioPaginator  # type: ignore[assignment]

class DescribeVTLDevicesPaginator(_DescribeVTLDevicesPaginatorBase):
    """
    [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/storagegateway/paginator/DescribeVTLDevices.html#StorageGateway.Paginator.DescribeVTLDevices)
    [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_storagegateway/paginators/#describevtldevicespaginator)
    """
    def paginate(  # type: ignore[override]
        self, **kwargs: Unpack[DescribeVTLDevicesInputPaginateTypeDef]
    ) -> AioPageIterator[DescribeVTLDevicesOutputTypeDef]:
        """
        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/storagegateway/paginator/DescribeVTLDevices.html#StorageGateway.Paginator.DescribeVTLDevices.paginate)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_storagegateway/paginators/#describevtldevicespaginator)
        """

if TYPE_CHECKING:
    _ListCacheReportsPaginatorBase = AioPaginator[ListCacheReportsOutputTypeDef]
else:
    _ListCacheReportsPaginatorBase = AioPaginator  # type: ignore[assignment]

class ListCacheReportsPaginator(_ListCacheReportsPaginatorBase):
    """
    [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/storagegateway/paginator/ListCacheReports.html#StorageGateway.Paginator.ListCacheReports)
    [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_storagegateway/paginators/#listcachereportspaginator)
    """
    def paginate(  # type: ignore[override]
        self, **kwargs: Unpack[ListCacheReportsInputPaginateTypeDef]
    ) -> AioPageIterator[ListCacheReportsOutputTypeDef]:
        """
        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/storagegateway/paginator/ListCacheReports.html#StorageGateway.Paginator.ListCacheReports.paginate)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_storagegateway/paginators/#listcachereportspaginator)
        """

if TYPE_CHECKING:
    _ListFileSharesPaginatorBase = AioPaginator[ListFileSharesOutputTypeDef]
else:
    _ListFileSharesPaginatorBase = AioPaginator  # type: ignore[assignment]

class ListFileSharesPaginator(_ListFileSharesPaginatorBase):
    """
    [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/storagegateway/paginator/ListFileShares.html#StorageGateway.Paginator.ListFileShares)
    [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_storagegateway/paginators/#listfilesharespaginator)
    """
    def paginate(  # type: ignore[override]
        self, **kwargs: Unpack[ListFileSharesInputPaginateTypeDef]
    ) -> AioPageIterator[ListFileSharesOutputTypeDef]:
        """
        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/storagegateway/paginator/ListFileShares.html#StorageGateway.Paginator.ListFileShares.paginate)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_storagegateway/paginators/#listfilesharespaginator)
        """

if TYPE_CHECKING:
    _ListFileSystemAssociationsPaginatorBase = AioPaginator[ListFileSystemAssociationsOutputTypeDef]
else:
    _ListFileSystemAssociationsPaginatorBase = AioPaginator  # type: ignore[assignment]

class ListFileSystemAssociationsPaginator(_ListFileSystemAssociationsPaginatorBase):
    """
    [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/storagegateway/paginator/ListFileSystemAssociations.html#StorageGateway.Paginator.ListFileSystemAssociations)
    [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_storagegateway/paginators/#listfilesystemassociationspaginator)
    """
    def paginate(  # type: ignore[override]
        self, **kwargs: Unpack[ListFileSystemAssociationsInputPaginateTypeDef]
    ) -> AioPageIterator[ListFileSystemAssociationsOutputTypeDef]:
        """
        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/storagegateway/paginator/ListFileSystemAssociations.html#StorageGateway.Paginator.ListFileSystemAssociations.paginate)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_storagegateway/paginators/#listfilesystemassociationspaginator)
        """

if TYPE_CHECKING:
    _ListGatewaysPaginatorBase = AioPaginator[ListGatewaysOutputTypeDef]
else:
    _ListGatewaysPaginatorBase = AioPaginator  # type: ignore[assignment]

class ListGatewaysPaginator(_ListGatewaysPaginatorBase):
    """
    [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/storagegateway/paginator/ListGateways.html#StorageGateway.Paginator.ListGateways)
    [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_storagegateway/paginators/#listgatewayspaginator)
    """
    def paginate(  # type: ignore[override]
        self, **kwargs: Unpack[ListGatewaysInputPaginateTypeDef]
    ) -> AioPageIterator[ListGatewaysOutputTypeDef]:
        """
        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/storagegateway/paginator/ListGateways.html#StorageGateway.Paginator.ListGateways.paginate)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_storagegateway/paginators/#listgatewayspaginator)
        """

if TYPE_CHECKING:
    _ListTagsForResourcePaginatorBase = AioPaginator[ListTagsForResourceOutputTypeDef]
else:
    _ListTagsForResourcePaginatorBase = AioPaginator  # type: ignore[assignment]

class ListTagsForResourcePaginator(_ListTagsForResourcePaginatorBase):
    """
    [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/storagegateway/paginator/ListTagsForResource.html#StorageGateway.Paginator.ListTagsForResource)
    [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_storagegateway/paginators/#listtagsforresourcepaginator)
    """
    def paginate(  # type: ignore[override]
        self, **kwargs: Unpack[ListTagsForResourceInputPaginateTypeDef]
    ) -> AioPageIterator[ListTagsForResourceOutputTypeDef]:
        """
        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/storagegateway/paginator/ListTagsForResource.html#StorageGateway.Paginator.ListTagsForResource.paginate)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_storagegateway/paginators/#listtagsforresourcepaginator)
        """

if TYPE_CHECKING:
    _ListTapePoolsPaginatorBase = AioPaginator[ListTapePoolsOutputTypeDef]
else:
    _ListTapePoolsPaginatorBase = AioPaginator  # type: ignore[assignment]

class ListTapePoolsPaginator(_ListTapePoolsPaginatorBase):
    """
    [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/storagegateway/paginator/ListTapePools.html#StorageGateway.Paginator.ListTapePools)
    [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_storagegateway/paginators/#listtapepoolspaginator)
    """
    def paginate(  # type: ignore[override]
        self, **kwargs: Unpack[ListTapePoolsInputPaginateTypeDef]
    ) -> AioPageIterator[ListTapePoolsOutputTypeDef]:
        """
        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/storagegateway/paginator/ListTapePools.html#StorageGateway.Paginator.ListTapePools.paginate)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_storagegateway/paginators/#listtapepoolspaginator)
        """

if TYPE_CHECKING:
    _ListTapesPaginatorBase = AioPaginator[ListTapesOutputTypeDef]
else:
    _ListTapesPaginatorBase = AioPaginator  # type: ignore[assignment]

class ListTapesPaginator(_ListTapesPaginatorBase):
    """
    [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/storagegateway/paginator/ListTapes.html#StorageGateway.Paginator.ListTapes)
    [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_storagegateway/paginators/#listtapespaginator)
    """
    def paginate(  # type: ignore[override]
        self, **kwargs: Unpack[ListTapesInputPaginateTypeDef]
    ) -> AioPageIterator[ListTapesOutputTypeDef]:
        """
        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/storagegateway/paginator/ListTapes.html#StorageGateway.Paginator.ListTapes.paginate)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_storagegateway/paginators/#listtapespaginator)
        """

if TYPE_CHECKING:
    _ListVolumesPaginatorBase = AioPaginator[ListVolumesOutputTypeDef]
else:
    _ListVolumesPaginatorBase = AioPaginator  # type: ignore[assignment]

class ListVolumesPaginator(_ListVolumesPaginatorBase):
    """
    [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/storagegateway/paginator/ListVolumes.html#StorageGateway.Paginator.ListVolumes)
    [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_storagegateway/paginators/#listvolumespaginator)
    """
    def paginate(  # type: ignore[override]
        self, **kwargs: Unpack[ListVolumesInputPaginateTypeDef]
    ) -> AioPageIterator[ListVolumesOutputTypeDef]:
        """
        [Show boto3 documentation](https://boto3.amazonaws.com/v1/documentation/api/latest/reference/services/storagegateway/paginator/ListVolumes.html#StorageGateway.Paginator.ListVolumes.paginate)
        [Show types-aiobotocore documentation](https://youtype.github.io/types_aiobotocore_docs/types_aiobotocore_storagegateway/paginators/#listvolumespaginator)
        """
