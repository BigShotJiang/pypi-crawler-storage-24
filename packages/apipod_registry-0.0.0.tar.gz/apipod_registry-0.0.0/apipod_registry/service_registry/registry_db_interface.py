from abc import ABC, abstractmethod
from typing import Dict, Any, List, Optional


class RegistryDBInterface(ABC):
    """Internal database interface specialized for service registry needs.

    This interface exposes simple, explicit methods used by the registry:
    upsert, lookup by id/name, delete, list and get_version_index.
    Implementations should operate on plain serializable dictionaries.
    """

    @abstractmethod
    def upsert_service(self, service_dict: Dict[str, Any]) -> None:
        """Insert or update a service record represented as a dict."""

    @abstractmethod
    def get_service_by_id(self, service_id: str) -> Optional[Dict[str, Any]]:
        """Return a service record by id or None."""

    @abstractmethod
    def delete_service(self, service_id: str) -> None:
        """Delete a service record by id."""

    @abstractmethod
    def list_services(self) -> List[Dict[str, Any]]:
        """Return all service records as a list of dicts."""

    @abstractmethod
    def get_version_index(self) -> Dict[str, str]:
        """Return a mapping {service_id: version} for all services."""

    @abstractmethod
    def close(self) -> None:
        """Cleanup any held resources (connections, etc.)."""
