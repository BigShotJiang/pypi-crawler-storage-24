from .registry import Registry, create_service_manager_with_supabase
from .definitions.service_definitions import (
    EndpointDefinition,
    ModelDefinition,
    ServiceCategory,
    ServiceDefinition,
    ServiceFamily,
)

# Backward compatibility for older imports.
ServiceManager = Registry

__all__ = [
    "Registry",
    "ServiceManager",
    "ServiceDefinition",
    "ServiceCategory",
    "ServiceFamily",
    "EndpointDefinition",
    "ModelDefinition",
    "create_service_manager_with_supabase",
]
