from typing import Dict, Optional, Union, Any, List, Iterator
import uuid
import logging

from apipod_registry.definitions.service_definitions import (
    ServiceDefinition, ModelDefinition, ServiceCategory, ServiceFamily, EndpointDefinition
)

from apipod_registry.service_registry.service_registry_interface import IServiceRegistry
from apipod_registry.utils.normalization import normalize_name_for_py

logger = logging.getLogger(__name__)


class Registry:
    """
    Central manager for all service-related entities.
    Handles both raw database dictionaries and Pydantic objects safely.
    """
    def __init__(self, service_store: IServiceRegistry = None):
        self.service_store = service_store

        self._services: Dict[str, ServiceDefinition] = {}
        self._categories: Dict[str, ServiceCategory] = {}
        self._families: Dict[str, ServiceFamily] = {}
        self._models: Dict[str, ModelDefinition] = {}
        
        self._service_names: Dict[str, str] = {}
        self._category_names: Dict[str, str] = {}
        self._family_names: Dict[str, str] = {}
        self._model_names: Dict[str, str] = {}

        if self.service_store:
            raw_services = self.service_store.list_services()
            logger.info(f"Registry found {len(raw_services)} service records. Beginning processing...")
            
            for service_data in raw_services:
                try:
                    # Convert to proper object if it's still a dict
                    service_obj = self._ensure_service_object(service_data)
                    self.add_service(service_obj, persist=False)
                except Exception as e:
                    # TYPE-SAFE ID FETCH for error logging
                    sid = getattr(service_data, 'id', None) if not isinstance(service_data, dict) else service_data.get('id')
                    logger.error(f"Critical failure mapping service data for ID [{sid}]: {e}", exc_info=True)
                    # Fallback storage for debugging
                    if sid:
                        self._services[sid] = service_data

    def _ensure_service_object(self, data: Union[dict, ServiceDefinition]) -> ServiceDefinition:
        """Helper to recursively cast dictionaries into Pydantic models."""
        if isinstance(data, ServiceDefinition):
            return data
            
        if not isinstance(data, dict):
            raise ValueError(f"Expected dict or ServiceDefinition, got {type(data)}")

        # 1. Handle nested Endpoints
        if "endpoints" in data and isinstance(data["endpoints"], list):
            data["endpoints"] = [
                EndpointDefinition(**ep) if isinstance(ep, dict) else ep 
                for ep in data["endpoints"]
            ]
        
        # 2. Handle nested ServiceAddress
        if "service_address" in data and isinstance(data["service_address"], dict):
            from apipod_registry.definitions.service_definitions import ServiceAddress
            data["service_address"] = ServiceAddress(**data["service_address"])

        # 3. Instantiate main object
        return ServiceDefinition(**data)

    def add_service(self, service_def: ServiceDefinition, persist: bool = True) -> ServiceDefinition:
        if not isinstance(service_def, ServiceDefinition):
            service_def = self._ensure_service_object(service_def)
        
        if not service_def.id:
            service_def.id = "gen-" + str(uuid.uuid4())
        
        if service_def.id in self._services and persist:
            raise ValueError(f"Service '{service_def.id}' is already registered")
        
        if not service_def.display_name:
            service_def.display_name = "unnamed_service_" + service_def.id

        normalized = normalize_name_for_py(service_def.display_name)
        self._service_names[normalized] = service_def.id

        # Store in-memory
        self._services[service_def.id] = service_def

        if persist and self.service_store:
            self.service_store.save_service(service_def)

        self._link_service_dependencies(service_def)
        return service_def

    def _link_service_dependencies(self, service_def: ServiceDefinition):
        """Helper to link service to existing families and register its models."""
        # Categories
        if service_def.category:
            for category_id in service_def.category:
                if category_id not in self._categories:
                    self._categories[category_id] = ServiceCategory(id=category_id)
                    self._category_names[normalize_name_for_py(f"Category {category_id}")] = category_id

        # Models
        if service_def.used_models:
            for model_info in service_def.used_models:
                # TYPE-SAFE attribute access
                m_id = getattr(model_info, 'id', None) if not isinstance(model_info, dict) else model_info.get('id')
                m_name = getattr(model_info, 'display_name', None) if not isinstance(model_info, dict) else model_info.get('display_name')
                
                if m_id and m_id not in self._models:
                    model_def = ModelDefinition(id=m_id, display_name=m_name or f"Model {m_id}")
                    self._models[m_id] = model_def
                    if model_def.display_name:
                        self._model_names[normalize_name_for_py(model_def.display_name)] = m_id

    def get_service(self, id_or_name: str) -> Optional[ServiceDefinition]:
        """
        Get a service definition by its ID or display name.
        Precondition: the service must have been added to the ServiceManager/ServiceStore previously.
        First checks the in-memory cache, then falls back to the ServiceStore if available.
        
        Args:
            id_or_name: Service ID or display name
            
        Returns:
            ServiceDefinition if found, None otherwise
        """
        # Direct ID lookup in cache
        if id_or_name in self._services:
            return self._services[id_or_name]
        
        # Normalized name lookup in cache
        normalized = normalize_name_for_py(id_or_name)
        if normalized in self._service_names:
            service_id = self._service_names[normalized]
            return self._services[service_id]
        
        # If not found in cache and service store is available, try loading from service store
        if self.service_store:
            service = self.service_store.load_service(id_or_name)
            if service:
                # Add to memory without re-persisting
                return self.add_service(service, persist=False)

            # Try loading by normalized name if direct ID lookup failed
            if normalized != id_or_name:
                service = self.service_store.load_service(normalized)
                if service:
                    return self.add_service(service, persist=False)
        
        return None
    
    def update_service(
        self,
        id_or_name: str,
        persist_changes: bool = True,
        **kwargs
    ) -> Optional[ServiceDefinition]:
        """
        Update a service definition's attributes.
        
        Args:
            id_or_name: Service ID or display name
            persist_changes: If True, the changes will be saved to the service store.
            **kwargs: Attributes to update
            
        Returns:
            Updated ServiceDefinition if found, None otherwise
        """
        service = self.get_service(id_or_name)
        if not service:
            return None
        
        # Update attributes
        for key, value in kwargs.items():
            if hasattr(service, key):
                if key == 'service_address':
                    # service.service_address = create_service_address(value)
                    service.service_address = value
                elif key == 'display_name':
                    # Remove old normalized name mapping
                    if service.display_name:
                        oldnormalized = normalize_name_for_py(service.display_name)
                        self._service_names.pop(oldnormalized, None)
                    # Add new normalized name mapping and set the value
                    normalized = normalize_name_for_py(value)
                    self._service_names[normalized] = service.id
                    service.display_name = value
                else:
                    setattr(service, key, value)
        
        self._services[service.id] = service
        if persist_changes and self.service_store:
            self.service_store.save_service(service)

        return service
    
    def remove_service(self, id_or_name: str) -> bool:
        """
        Remove a service definition.
        
        Args:
            id_or_name: Service ID or display name
            
        Returns:
            True if removed, False if not found
        """
        service = self.get_service(id_or_name)
        if not service:
            return False
        
        # Remove from mappings
        self._services.pop(service.id)
        
        # Remove from store if available
        if self.service_store:
            self.service_store.delete_service(service.id)
        
        if service.display_name:
            normalized = normalize_name_for_py(service.display_name)
            self._service_names.pop(normalized, None)
        
        return True
    
    def list_services(self) -> List[ServiceDefinition]:
        """Returns the list of proper Dataclass objects."""
        return list(self._services.values())

    def filter_services(self, **kwargs) -> List[ServiceDefinition]:
        """
        Filter services by their attributes.
        
        Args:
            **kwargs: Attribute name and value pairs to filter by
            
        Returns:
            List of matching services
        """
        result = []
        for service in self._services.values():
            match = True
            for attr, value in kwargs.items():
                if not hasattr(service, attr):
                    match = False
                    break
                
                attr_value = getattr(service, attr)
                if attr_value != value:
                    match = False
                    break
            
            if match:
                result.append(service)
        
        return result
    
    def get_services_by_family(self, family_id_or_name: str) -> List[ServiceDefinition]:
        """
        Get all services belonging to a specific family.
        
        Args:
            family_id_or_name: Family ID or display name
            
        Returns:
            List of services in the family
        """
        family = self.get_family(family_id_or_name)
        if not family:
            return []
        
        return [s for s in self._services.values() if s.family_id == family.id]
    
    def get_services_by_category(self, category_id_or_name: str) -> List[ServiceDefinition]:
        """
        Get all services belonging to a specific category.
        
        Args:
            category_id_or_name: Category ID or display name
            
        Returns:
            List of services in the category
        """
        category = self.get_category(category_id_or_name)
        if not category:
            return []
        
        return [s for s in self._services.values() if category.id in (s.category or [])]
    
    # ---- Service Category Methods ----
    
    def add_category(self, category: ServiceCategory) -> ServiceCategory:
        """
        Add a new service category.
        
        Args:
            category: ServiceCategory object
            
        Returns:
            Added ServiceCategory
            
        Raises:
            ValueError: If the category has no ID or is already registered
        """
        if not category.id:
            raise ValueError("Category must have an ID")
        
        if category.id in self._categories:
            raise ValueError(f"Category '{category.id}' is already registered")
        
        self._categories[category.id] = category
        
        if category.display_name:
            normalized = normalize_name_for_py(category.display_name)
            self._category_names[normalized] = category.id
        
        return category
    
    def get_category(self, id_or_name: str) -> Optional[ServiceCategory]:
        """
        Get a service category by its ID or display name.
        
        Args:
            id_or_name: Category ID or display name
            
        Returns:
            ServiceCategory if found, None otherwise
        """
        # Direct ID lookup
        if id_or_name in self._categories:
            return self._categories[id_or_name]
        
        # Normalized name lookup
        normalized = normalize_name_for_py(id_or_name)
        if normalized in self._category_names:
            category_id = self._category_names[normalized]
            return self._categories[category_id]
        
        return None
    
    def list_categories(self) -> List[ServiceCategory]:
        """List all service categories."""
        return list(self._categories.values())
    
    # ---- Service Family Methods ----
    
    def add_family(self, family: ServiceFamily) -> ServiceFamily:
        """
        Add a new service family.
        
        Args:
            family: ServiceFamily object
            
        Returns:
            Added ServiceFamily
            
        Raises:
            ValueError: If the family has no ID or is already registered
        """
        if not family.id:
            raise ValueError("Family must have an ID")
        
        if family.id in self._families:
            raise ValueError(f"Family '{family.id}' is already registered")
        
        self._families[family.id] = family
        
        if family.display_name:
            normalized = normalize_name_for_py(family.display_name)
            self._family_names[normalized] = family.id
        
        return family
    
    def get_family(self, id_or_name: str) -> Optional[ServiceFamily]:
        """
        Get a service family by its ID or display name.
        
        Args:
            id_or_name: Family ID or display name
            
        Returns:
            ServiceFamily if found, None otherwise
        """
        # Direct ID lookup
        if id_or_name in self._families:
            return self._families[id_or_name]
        
        # Normalized name lookup
        normalized = normalize_name_for_py(id_or_name)
        if normalized in self._family_names:
            family_id = self._family_names[normalized]
            return self._families[family_id]
        
        return None
    
    def list_families(self) -> List[ServiceFamily]:
        """List all service families."""
        return list(self._families.values())
    
    # ---- Model Definition Methods ----
    
    def add_model(self, model: ModelDefinition) -> ModelDefinition:
        """
        Add a new model definition.
        
        Args:
            model: ModelDefinition object
            
        Returns:
            Added ModelDefinition
            
        Raises:
            ValueError: If the model has no ID or is already registered
        """
        if not model.id:
            raise ValueError("Model must have an ID")
        
        if model.id in self._models:
            raise ValueError(f"Model '{model.id}' is already registered")
        
        self._models[model.id] = model
        
        if model.display_name:
            normalized = normalize_name_for_py(model.display_name)
            self._model_names[normalized] = model.id
        
        return model
    
    def get_endpoint(self, service_id_or_name: str, endpoint_id_or_name: str) -> Optional[EndpointDefinition]:
        service_def = self.get_service(service_id_or_name)
        if not service_def:
            return None

        # Clean path for lookup
        probable_path = endpoint_id_or_name if endpoint_id_or_name.startswith('/') else f"/{endpoint_id_or_name}"

        return next((ep for ep in service_def.endpoints if ep.id == endpoint_id_or_name or ep.path == probable_path), None)

    def get_model(self, id_or_name: str) -> Optional[ModelDefinition]:
        """
        Get a model definition by its ID or display name.
        
        Args:
            id_or_name: Model ID or display name
            
        Returns:
            ModelDefinition if found, None otherwise
        """
        # Direct ID lookup
        if id_or_name in self._models:
            return self._models[id_or_name]
        
        # Normalized name lookup
        normalized = normalize_name_for_py(id_or_name)
        if normalized in self._model_names:
            model_id = self._model_names[normalized]
            return self._models[model_id]
        
        return None
    
    def list_models(self) -> List[ModelDefinition]:
        """List all model definitions."""
        return list(self._models.values())
    
    # ---- Dict-like interface ----
    
    def __getitem__(self, id_or_name: str) -> ServiceDefinition:
        service = self.get_service(id_or_name)
        if service is None:
            raise KeyError(f"Service '{id_or_name}' not found")
        return service
    
    def __setitem__(self, id_or_name: str, value: Union[ServiceDefinition, Dict[str, Any]]) -> None:
        svc_obj = self._ensure_service_object(value)
        if not svc_obj.id:
            svc_obj.id = id_or_name
        self.add_service(svc_obj)

    def __iter__(self) -> Iterator[str]:
        """
        Iterate over service IDs.
        
        Returns:
            Iterator of service IDs
        """
        return iter(self._services.keys())
    
    def __len__(self) -> int:
        """
        Get the number of services.
        
        Returns:
            Number of services
        """
        return len(self._services)
    
    def pop(self, id_or_name: str, default: Any = None) -> Optional[ServiceDefinition]:
        """
        Remove and return a service.
        
        Args:
            id_or_name: Service ID or display name
            default: Default value to return if service not found
            
        Returns:
            Removed ServiceDefinition or default value
        """
        service = self.get_service(id_or_name)
        if service is None:
            return default
        
        # Remove from mappings
        self._services.pop(service.id)
        
        # Remove from store if available
        if self.service_store:
            self.service_store.delete_service(service.id)
        
        if service.display_name:
            normalized = normalize_name_for_py(service.display_name)
            self._service_names.pop(normalized, None)
        
        return service
    
    def pretty_print(self, indent: int = 2) -> str:
        """
        Generate a pretty-printed representation of the services using Pydantic model serialization.
        
        Args:
            indent: Number of spaces for indentation
            
        Returns:
            Pretty-printed JSON string
        """
        # Create a dictionary to hold all entities
        result = {
            "services": {},
            "categories": {},
            "families": {},
            "models": {}
        }
        
        # Add services using model's model_dump method for serialization
        for service_id, service in self._services.items():
            result["services"][service_id] = service.model_dump(exclude_none=True)
        
        # Add categories
        for category_id, category in self._categories.items():
            result["categories"][category_id] = category.model_dump(exclude_none=True)
        
        # Add families
        for family_id, family in self._families.items():
            result["families"][family_id] = family.model_dump(exclude_none=True)
        
        # Add models
        for model_id, model in self._models.items():
            result["models"][model_id] = model.model_dump(exclude_none=True)
        
        # Use json dumps for pretty printing
        from json import dumps
        return dumps(result, indent=indent, sort_keys=True)


def create_service_manager_with_supabase(url: str = None, key: str = None, table: str = "services") -> Registry:
    """Convenience helper to create a `ServiceManager` wired to Supabase-backed registry.

    Reads `SUPABASE_URL`/`SUPABASE_KEY` from env when `url`/`key` are not provided.
    """
    try:
        from apipod_registry.service_registry.supabase_registry import SupabaseRegistryDB
        from apipod_registry.service_registry.db_registry import DBServiceStore
    except Exception:
        raise

    db = SupabaseRegistryDB(url=url, key=key, table=table)
    store = DBServiceStore(db=db, table=table)
    return Registry(service_store=store)


# Backward compatibility for older imports.
ServiceManager = Registry
