"""TAPDB Admin API endpoints."""
