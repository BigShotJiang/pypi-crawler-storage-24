from dataclasses import dataclass
from os import name
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from astropy.io import fits
from matplotlib.path import Path
from matplotlib.widgets import PolygonSelector, Slider


@dataclass
class GTIFile:
    gti_array: np.ndarray
    primary_header: fits.Header
    stdgti_header: fits.Header

    def inspect(self, max_rows: int = 10) -> None:  #  (fold)
        print("GTIFile")
        print("-------")

        # GTI array
        if self.gti_array is None:
            print("gti_array: None")
        else:
            print(
                f"gti_array: shape={self.gti_array.shape}, dtype={self.gti_array.dtype}"
            )
            rows = min(len(self.gti_array), max_rows)
            print(f"gti_array (first {rows} rows):")
            print(self.gti_array[:rows])
            if len(self.gti_array) > rows:
                print(f"... ({len(self.gti_array) - rows} more rows)")

        print()

        # Primary header
        print("primary_header:")
        if self.primary_header is None:
            print("  None")
        else:
            for k, v in self.primary_header.items():
                print(f"  {k} = {v}")

        print()

        # STDGTI header
        print("stdgti_header:")
        if self.stdgti_header is None:
            print("  None")
        else:
            for k, v in self.stdgti_header.items():
                print(f"  {k} = {v}")  # (end)


class CCI_Analyzer:
    """
    The CCI_Analyzer class allows for interactive creation of colour/colour- and
    colour/intensity plots, as well as convenient selection/grouping of
    data, on one of these plots into branches.
    There exist several ways to provide the necessary information to perform
    analysis. Below you can find how to load the required data first, followed
    by optional information used to fine-tune the analysis.

    Required data:
    1) Event-data:
        Loaded using load_dataframe(). Expects a dataframe with the following
        columns:
        df = {
            "mjd"       : float
            "energy"   : int
        }
        (When handling ninjaSat-Data, you can directly read the event and rmf
        fits-file paths using read_ninjaSat_evt_and_rmf().)

    2) Colorbands-dictionary:
        Loaded using set_colorbands(). Expects a dictionary of the form:
        colorbands = {
            "soft": (lower:float, higher:float),
            "med": (lower:float, higher:float),
            "hard": (lower:float, higher:float),
        }.
        Event data will be tuncated accorting to the lower boundary in the
        soft band, as well as the higher boundary in the hard band.

    From these data, the software will try to create sensible parameters for
    analysis. The two analysis steps can now be performed by calling:
        - select_bins_and_colors()
        - select_branches()
    It is recommended to use the both functions in conjunction, starting with
    select_bins_and_colors(). This enables the selection of branches on
    sensibly binned plots

    If this yielded unsatisfactory results, you will have to set some of the
    parameters yourself in order to improve results. To do this use the
    functions below:

    3) Binsize and bin array:
        To use specific bins during analysis, provide the desired values via:
        - set_binsize() -> calculates a bin array from specified parameters
        - load_bin_array() -> loads a bin array and infers binsize
        Please be aware that the binning behaviour depends on the presence of
        a gti array (see calculate_bin_array()).

    4) Interavtive slider boundaries:
        Adjustmend may be necessary to allow for fine-tuning of slider values.
        Can be set with set_interactive_bin_bounds()

    5) Error threshold for colour values:
        Can be set with set_color_ratio_error_threshold() to omit datapoints
        with errors larger than the specified threshold

    6) GTI information:
        Can be provided in two ways:
        - load_gti_from_array()
            enables the use of filter_good_time() (masks events outside gti)
        - load_gti_from_file()
            further enables exporting 'branch-gti' fits files via:
            write_branched_stdgti()
            This can be used in xselect, if absolute precision over lightcurve
            extraction is necessary (see NOTE)

    NOTE:
    A lot of effort has gone into recreating xselects lightcurve extraction
    behaviour. However, some differences still remain.
    Instead of trying to perfectly recreate xselects lightcurve extracor,
    the author has decided that if xselects accuracy should be required
    by the user, xselect itself should be used.
    For everyone wanting xselects extraction behaviour and still use the by-hand
    selection of branches offered by the CCI-Analyzer,
    the following solution has been implemented:
    Reading a gti-file using load_gti_from_file() allows for the creation of
    one to three per-branch gti-fits-files via write_branched_stdgti() after
    selection.
    Each per-branch gti contains concatinated time-bins of points that were
    assigned to that branch by the user. This means the resulting gtis are
    depended on the bin size. An overview over the gti arrays created,
    can be plotted with plot_branched_lcs().
    """

    def __init__(self) -> None:  # (fold)
        # DataFrames
        self._event_data: pd.DataFrame | None = None
        self._colorbanded_event_data: pd.DataFrame | None = None
        self._lightcurve_data: pd.DataFrame | None = None
        self._color_data: pd.DataFrame | None = None
        # Bins and Colors util
        self._colorbands: dict | None = None
        self._gti_array: np.ndarray | None = None
        self._bin_array: np.ndarray | None = None
        self.binsize_upper_threshold: int | None = None
        self.binsize_lower_threshold: int | None = None
        self.use_gti_binning: bool = True
        self._color_ratio_error_threshold: float | None = None
        self._binsize_sec: float | None = None
        self._binsize_day: float | None = None
        self.markers = {
            "Horizontal": "^",
            "Normal": "s",
            "Flaring": "o",
            "unclassified": "x",
        }
        self.branch_colors = {
            "Horizontal": "tab:blue",
            "Normal": "tab:green",
            "Flaring": "tab:red",
            "unclassified": "gray",
        }
        self._branch_gti: dict | None = None
        # Information
        self._num_events: int | None = None
        self._num_total_events: int | None = None
        self._num_good_events: int | None = None
        # GTIFile
        self._stdgti_file_data: GTIFile | None = None
        self._mission_tstart: float | None = None

        print(40 * "#")
        print("Welcome to the CCI_Analyzer!")

    # (end)

    # Properties
    # (fold)
    @property
    def stdgti_file_data(self):
        """
        Dataclass containing information about a gti fits file.
        see Class GTIFile for more information.
        Set via load_gti_from_file().
        """
        if self._stdgti_file_data is None:
            raise RuntimeError(
                "No stdgti file data loaded yet! Load with load_gti_from_file()."
            )
        return self._stdgti_file_data

    @property
    def mission_tstart(self):
        """
        Time value associated with TSTART in a fits header.
        Used for proper alignment of the bin edges.
        Set via load_gti_from_file() or set_observation_start_time()
        """
        if self._mission_tstart is None:
            raise RuntimeError(
                "No mission_tstart loaded yet. Please read a gti fits file with load_gti_from_file() or set it manually using set_observation_start_time()"
            )
        return self._mission_tstart

    @mission_tstart.setter
    def set_observation_start_time(self, value):
        if value is None:
            raise ValueError("mission_tstart cannot be None")
        if value < 0:
            raise ValueError("mission_tstart must be non-negative")
        self._mission_tstart = float(value)

    @property
    def event_data(self):
        """
        Raw event/energy data.
        Strucure is a pandas DataFrame:
        df = {
            "mjd"       : float
            "energy"   : int
        }
        Set by load_dataframe() or read_ninjaSat_evt_and_rmf().
        """
        if self._event_data is None:
            raise RuntimeError(
                "No event data loaded yet! Please load data using load_dataframe() or read_ninjaSat_evt_and_rmf()."
            )
        return self._event_data

    @property
    def num_events(self):
        """
        Total event count.
        Set internally when loading event-data.
        """
        if self._num_events is None:
            raise RuntimeError("No data loaded yet!")
        return self._num_events

    @property
    def num_good_events(self):
        """
        Event count after filtering (by colorbands or gti).
        Set/updated internally after applying filters.
        """
        if self._num_good_events is None:
            raise RuntimeError("No data loaded yet!")
        return self._num_good_events

    @property
    def num_total_events(self):
        """
        Event count after filtering (by colorbands or gti).
        Set/updated internally after applying filters.
        """
        if self._num_total_events is None:
            raise RuntimeError("No data loaded yet!")
        return self._num_total_events

    @property
    def colorbands(self):
        """
        Colorband dictionary.
        Set via set_colorbands().
        """
        if self._colorbands is None:
            raise RuntimeError("No colorbands loaded yet!")
        return self._colorbands

    @property
    def color_ratio_error_threshold(self):
        """
        Error threshold for masking bad datapoints.
        Set with set_color_ratio_error_threshold().
        """
        if self._color_ratio_error_threshold is None:
            raise RuntimeError("No error_threshold set yet!")
        return self._color_ratio_error_threshold

    @color_ratio_error_threshold.setter
    def color_ratio_error_threshold(self, value):
        if value is None:
            raise ValueError("error_threshold cannot be None")
        if value < 0:
            raise ValueError("error_threshold must be non-negative")
        self._color_ratio_error_threshold = float(value)

    @property
    def binsize_sec(self):
        """
        Binsize (in seconds) to use when calculating countrates.
        Set via set_binsize() or interavtively using select_bins_and_colors().
        Automatically prompts creation of a new bin_array.
        """
        if self._binsize_sec is None:
            raise RuntimeError("No binsize specified yet")
        return self._binsize_sec

    @property
    def binsize_day(self):
        """
        Binsize (in days) to use when calculating countrates.
        Set via set_binsize().
        Automatically prompts creation of a new bin_array.
        """
        if self._binsize_day is None:
            raise RuntimeError(
                "No binsize specified yet! Please set bia set_binsize() or choose interavtively via select_bins_and_colors()"
            )
        return self._binsize_day

    @property
    def bin_array(self):
        """
        Bin-edge array dictating the countrate calculation.
        Automatically created when setting binsize with set_binsize(), or
        interavtively when using select_bins_and_colors().
        """
        if self._bin_array is None:
            raise RuntimeError(
              "Bin array not loaded yet! Please call set_binsize() to create one or set manually using load_bin_array() "
            )
        return self._bin_array

    @property
    def colorbanded_event_data(self):
        """
        Dataset containing event data, each point associated with a colourband.
        Set internally after runnung set_colorbands()
        """
        if self._colorbanded_event_data is None:
            raise RuntimeError(
                "No Colorbands have been assigned yet! Please run set_colorbands() first."
            )
        return self._colorbanded_event_data

    @property
    def exposure(self):
        """
        Exposure time in seconds, of each bin with respect to gti.
        Calculated in self.compute_exposure().
        """
        if self._exposure is None:
            raise RuntimeError(
                "Exposure has not been calculated yet! Please run compute_exposure() first."
            )
        return self._exposure

    @property
    def lightcurve_data(self):
        """
        Data containing lightcurve information.
        Set internally when running extract_countrates().
        """
        if self._lightcurve_data is None:
            raise RuntimeError(
                "No countrates have been calculated yet! Please run extract_countrates() first."
            )
        return self._lightcurve_data

    @property
    def gti_array(self):
        """
        Numpy ndarray containing gti information.
        Has shape (N, 2):
        [ [start0, stop0], [start1, stop1], ... ]
        """
        if self._gti_array is None:
            raise RuntimeError(
                "No gti array loaded yet! Please set with load_gti_from_file() or load_gti_from_array()."
            )
        return self._gti_array

    @property
    def branch_gti(self):
        """
        Dictionary containing one to three gti arrays associated with a branch.
        All datapoints in one of these gti belong on the specified branch.
        """
        if self._branch_gti is None:
            raise RuntimeError(
                "No branch gti array calculated yet! Please create with build_branch_gti()."
            )
        return self._branch_gti

    @property
    def color_data(self):
        """
        Data containing color information. Every point on the lightcurve has
        associated colour data. Calculated by calculate_color_ratios().
        """
        if self._color_data is None:
            raise RuntimeError(
                "Colour-data has not been calculated yet! Please run calculate_color_ratios()."
            )
        return self._color_data

    # (end)

    ######################
    #### DATA LOADING ####
    ######################

    def load_dataframe(self, df: pd.DataFrame) -> None:  # (fold)
        """
        Load the data that is to be analyzed in form of a dataframe.
        Expected format:
        df = {
            "mjd"       : float
            "energy"   : int
        }
        """
        missing = {"mjd", "energy"} - set(df.columns)
        if missing:
            raise ValueError(f"The provided DataFrame has missing columns: {missing}")
        print("~ loading event data")
        print(f" -> total events: {len(df)}")
        self._event_data = df
        self._num_events = len(df)
        self._num_total_events = len(df)  # (end)

    def read_ninjaSat_evt_and_rmf(self, evt_path: str, rmf_path: str) -> None:  # (fold)
        """
        Extracts time [MJD] and channel information of all photon events inside
        a fits-file at evt_path, as well as energy [keV] and channel info from
        another fits-file at rmf_path. Then combines their data into a single
        dataframe and loads it.
        """
        with fits.open(evt_path) as hdul:
            evt = hdul["EVENTS"].data
            hdr = hdul["EVENTS"].header

            mjdref = hdr.get("MJDREFI", 0) + hdr.get("MJDREFF", 0.0)
            time = evt["TIME"]
            channel = evt["PIch1"]

        time_mjd = mjdref + time / 86400.0  # seconds → days

        evt_df = pd.DataFrame(
            {
                "mjd": np.array(time_mjd).astype(float),
                "ch": np.array(channel).astype(int),
            }
        )

        with fits.open(rmf_path) as hdul:
            ebounds = hdul["EBOUNDS"].data
            channel = ebounds["CHANNEL"]
            e_min = ebounds["E_MIN"]
            e_max = ebounds["E_MAX"]

        e_center = 0.5 * (e_min + e_max)

        rmf_df = pd.DataFrame(
            {
                "ch": np.array(channel).astype(int),
                "energy": np.array(e_center).astype(float),
                "e_lo": np.array(e_min).astype(float),
                "e_hi": np.array(e_max).astype(float),
            }
        )

        raw_df = evt_df.merge(rmf_df[["ch", "energy"]], on="ch", how="left")

        self.load_dataframe(raw_df)

    # (end)

    def load_gti_from_array(self, gti_array: np.ndarray):  # (fold)
        """
        Load gti-information as np.ndarray.
        Expected format:
        2D array of shape (N, 2)
        - Column 0 : start times
        - Column 1 : stop times
        """
        if not isinstance(gti_array, np.ndarray):
            raise TypeError("gti has to be of type numpy.ndarray")

        if gti_array.ndim != 2:
            raise ValueError(f"gti_array must be 2D, got ndim={gti_array.ndim}")

        if gti_array.shape[1] != 2:
            raise ValueError(f"gti_array must have shape (N, 2), got {gti_array.shape}")
        print("~ loading gti array")
        self._gti_array = gti_array  # (end)

    def load_gti_from_file(self, gti_path: str):  # (fold)
        """
        Load a ninjaSat specific STDGTI fits-file.
        Using this function stores header information and enables creation
        of a branch specific gti-file after successfull branch selection.
        """
        with fits.open(gti_path) as hdul:
            primary_hdu = hdul[0]

            gti_hdu = hdul["STDGTI"]

            mjdref = gti_hdu.header["MJDREF"]

            t_start = gti_hdu.header["TSTART"] / 86400 + mjdref

            start = np.array(gti_hdu.data["START"])
            stop = np.array(gti_hdu.data["STOP"])

            intervals = np.column_stack((start, stop))

            mjd_intervals = intervals / 86400 + mjdref

            self.load_gti_from_array(mjd_intervals)

            primary_header = primary_hdu.header.copy()
            gti_header = gti_hdu.header.copy()

        self._stdgti_file_data = GTIFile(
            gti_array=intervals,
            primary_header=primary_header,
            stdgti_header=gti_header,
        )
        self._mission_tstart = t_start
        # (end)

    ###################
    #### FILTERING ####
    ###################

    def refine_gti(self, verbose=True): # (fold)
        """
        Refine GTI intervals by removing leading/trailing 0-count regions.
        The function looks for the first and last registered event inside each
        GTI and adjusts the edges accordingly.
        This prevents systematically lower countrates at GTI edges.
        """
        if verbose:
            print("~ refining gti")
        evt_times = self.event_data["mjd"].to_numpy()
        gti_array = self.gti_array
        new_gtis = []

        for start, stop in gti_array:
            # Select events in this GTI
            mask = (evt_times >= start) & (evt_times <= stop)
            times = evt_times[mask]

            if len(times) == 0:
                continue  # skip empty GTIs

            new_start = times.min()
            new_stop = times.max()
            new_gtis.append((new_start, new_stop))

            if len(new_gtis) == 0:
                raise RuntimeError("Got empty GTI-array after refining.")

        self._gti_array = np.array(new_gtis) # (end)

    def select_good_time(self, strictness:float | None = None):  # (fold)
        """
        Select events inside event_data that lie inside the gti intervals.
        NOTE: Run this BEFORE doing any calculations for the filter to take
        effect!
        """
        time = self.event_data["mjd"].to_numpy()
        mask = np.zeros(len(time), dtype=bool)

        for start, stop in self.gti_array:
            if strictness is not None:
                pad = (stop-start)*strictness
                start_p = start + pad
                stop_p = stop - pad
            else:
                start_p = start
                stop_p = stop
            mask |= (time >= start_p) & (time <= stop_p)
        n_kept = mask.sum()
        n_total = len(self.event_data)
        n_dropped = n_total - n_kept

        print(f"~ dropping {n_dropped} points outside gti. (-{(n_dropped/n_total*100):.0f}%)")
        self._event_data = self.event_data.loc[mask]
        self._num_events = len(self._event_data)
        # (end)

    ################################
    ####  PREPARATION (SETTERS) ####
    ################################

    def set_interactive_bin_bounds(self, lower: int, upper: int):  # (fold)
        """
        Set boundaries for the binsize-slider in the interactive window.
        Values should be provided in seconds.
        If none are set, a default interval of [60, 2000] is used.
        """
        self.binsize_lower_threshold = lower
        self.binsize_upper_threshold = upper
        # (end)

    def set_color_ratio_error_threshold(self, threshold):  # (fold)
        """
        Set the error threshold for the color_ratio data points.
        Any points that have error values exceeding the threshold will be
        dropped from the set.
        """
        self.color_ratio_error_threshold = threshold
        # (end)

    def set_colorbands(self, colorbands: dict, verbose=True) -> None:  # (fold)
        """
        Set a colorbands dictionary. The lower value of the soft band
        and the higher value of the hard band will be used as the hard boundaries
        for the band-selection sliders, selecting the outer
        energy boundaries for the entire dataset.
        Expected units: keV

        Expected format:
        colorbands = {
            "soft": (lower:float, higher:float),
            "med": (lower:float, higher:float),
            "hard": (lower:float, higher:float),
        }
        """
        missing = {"soft", "hard", "med"} - colorbands.keys()
        if missing:
            raise ValueError(
                f"The provided colorbands-dict has missing items: {missing}"
            )
        self._colorbands = colorbands
          # (end)

    def set_binsize(  # (fold)
        self,
        binsize_sec: float | None = None,
        binsize_day: float | None = None,
        mission_tstart: float | None = None,
        verbose=True,
    ):
        """
        Set the bin size using either days or seconds as the unit.
        Optionally set the
        """

        if (binsize_sec is None) == (binsize_day is None):
            raise ValueError("Provide exactly one of binsize_sec or binsize_day")

        if binsize_sec is not None:
            binsize_day = binsize_sec / 86400
        if binsize_day is not None:
            binsize_sec = binsize_day * 86400

        if verbose:
            print(f"~ setting time bins (binsize: {binsize_sec:.0f} sec)")

        self._binsize_sec = binsize_sec
        self._binsize_day = binsize_day
        # (end)

    def load_bin_array(self, bin_array: np.ndarray) -> None:  # (fold)
        """
        Load a bin-array (np.ndarray) to be used for lightcurve calculation.
        Time format has to be mjd.
        Infers binsize as the mean distance between bin edges.
        """
        if not isinstance(bin_array, np.ndarray):
            raise TypeError("bin array must be a numpy ndarray")
        print("~ using external bin array")
        self._bin_array = bin_array
        self._binsize_day = float(np.mean(np.diff(bin_array)))
        self._binsize_sec = self.binsize_day * 86400
        # (end)

    ##################
    #### ANALYSIS ####
    ##################

    def apply_colorbands(self, verbose=True): # (fold)
        """
        Apply the colorbands loaded in set_colorbands() and discard datapoints
        that lie outside of the specified energy range (lower val. in soft band
        to higher val. in hard band).
        NOTE: To keep the original data intact, the function uses a separate
        dataframe (colorbanded_event_data) to store the colorband information.
        This means, that any filtering applied to the event_data dataframe
        carries over to the new colorbanded_event_data dataframe as well. In
        turn, applying filters to the new dataframe will not persist if
        colorbands are reapplied.
        """
        df = self.event_data.copy()
        df["colorband"] = pd.NA
        for name, (e_lo, e_hi) in self.colorbands.items():
            mask = (df["energy"] > e_lo) & (df["energy"] <= e_hi)
            df.loc[mask, "colorband"] = name
        # check unassigned events
        outside_bands = df["colorband"].isna()
        drp_bins = sorted(
            set([drp_bin for band in self.colorbands.values() for drp_bin in band])
        )
        drp_bins = np.insert(drp_bins, 0, 0)
        drp_bins = np.append(drp_bins, 500)
        n_dropped, _ = np.histogram(df.loc[outside_bands, "energy"], drp_bins)
        self._num_good_events = self.num_events - outside_bands.sum()
        if verbose:
            print("~ assigning colorbands")
            print(
                f" -> dropping {outside_bands.sum()} (-{(outside_bands.sum() / self.num_events *
                100):.0f}%) events ({n_dropped[0]} below, {n_dropped[-1]} above band-energy-range)."
            )
            print(
                f" -> {self.num_good_events} events remain. ({(self.num_good_events/self.num_total_events*100):.0f}% of total events)"
            )
        df = df.dropna(subset=["colorband"])
        self._colorbanded_event_data = df.copy() # (end)

    def create_bin_array(self, verbose=True): # (fold)
        """
        This function features two possible methods for creating time bins.
        Using the specified bin size, either the whole time-axis, or just the
        valid segments as specified by the gti array are binned. If no gti
        array is found, the former method will be used. If a gti array is
        found, the latter method will be used.

        This behaviour can be overwritten by setting self.use_gti_binning to
        False.

        NOTE: To obtain bin arrays identical to those of xselect, the function
        needs the `mission_tstart` parameter. It can be obtained with the
        extract_tstart_tstop() function in the fits_util module, or by loading
        a gti array via load_gti_from_file().
        In case mission_tstart is unavailable, the smallest time in the
        event data is used instead.
        """
        if self._gti_array is not None and self.use_gti_binning:
            if verbose:
                print(" -> binning inside gti valid segments")
            edges = []
            for idx, (start, end) in enumerate(self.gti_array):
                # Insert gap between GTIs as one big bin
                if idx > 0:
                    prev_end = self.gti_array[idx - 1, 1]
                    if start > prev_end:
                        # Add the gap as a single bin
                        edges.append(prev_end)
                        edges.append(start)
                # Make fine bins inside the GTI
                interval_edges = np.arange(start, end, self.binsize_day)
                # Ensure last edge is exactly the GTI end
                if interval_edges[-1] != end:
                    interval_edges = np.append(interval_edges, end)
                edges.extend(interval_edges)
            # Remove duplicates from gap insertion
            bins = np.unique(np.array(edges))
            self._bin_array = bins
        else:
            if verbose:
                print(" binning whole time axis (gti insensitive)")
            evt_times = self.event_data["mjd"].to_numpy()
            t_start = evt_times.min()
            t_stop = evt_times.max()
            if self._mission_tstart is None:
                mission_tstart = t_start
            else:
                mission_tstart = self.mission_tstart

            binsize_day = self.binsize_day


            n_start = int(np.floor((t_start - mission_tstart) / binsize_day))
            n_stop = int(np.floor((t_stop - mission_tstart) / binsize_day))
            bins = mission_tstart + np.arange(n_start, n_stop + 1) * binsize_day
            self._bin_array = bins

        if verbose:
            print(f" -> binning yielded {len(self.bin_array)} bins") # (end)

    def compute_exposure(self): # (fold)
        """
        Compute absolute exposure time per bin (in seconds),
        with respect to gti intervals.
        """
        bins = self.bin_array
        gti = self.gti_array

        bin_left = bins[:-1]
        bin_right = bins[1:]

        exposure = np.zeros_like(bin_left, dtype=float)

        for start, stop in gti:
            overlap = np.minimum(bin_right, stop) - np.maximum(bin_left, start)
            overlap = np.clip(overlap, 0.0, None)
            exposure += overlap

        # convert days → seconds
        exposure *= 86400.0

        self._exposure = exposure # (end)

    def extract_countrates( # (fold)
        self,
        exposure_threshold_sec: float | None = None,
        verbose=True
    ):
        """
        Compute countrates in each colorband using a predefined bin array.

        This method bins event times into the existing bin_array and
        computes counts per bin for each colorband. Countrates are then derived
        either using GTI-aware exposure (if GTIs are available) or using the
        geometric bin widths.

        Two operation modes exist:

        1) GTI-aware mode (preferred):
           If a GTI array is present, exposure is computed per bin via
           `compute_exposure()`. Countrates are calculated as:
                rate = counts / exposure
           Only bins whose exposure matches `exposure_threshold_sec` are
           retained. By default, this selects only fully exposed bins (i.e.
           exposure equal to the nominal binsize), excluding partially covered
           bins at GTI edges.

        2) No-GTI mode:
           If no GTIs are loaded, countrates are computed using the bin widths:
                rate = counts / bin_width
           where bin widths may vary depending on the binning scheme.

        Results are stored in `self._lightcurve_data` as a pandas DataFrame with
        the following columns:
            df = {
                - "colorband"
                - "mjd" (bin centers)
                - "counts"
                - "count_error"
                - "countrate"
                - "countrate_error"
                - "exposure" (only available when using GTI-aware mode)
            }
        """
        if verbose:
            print("~ extracting countrates")

        df = self.colorbanded_event_data
        bins = self.bin_array

        all_centers = 0.5 * (bins[:-1] + bins[1:])
        rows = []

        if self._gti_array is not None:
            if verbose:
                print(" -> using exposure to calculate count rates")
            self.compute_exposure()
            if exposure_threshold_sec is None:
                exposure_threshold_sec = self.binsize_sec
            if verbose:
                print(f" -> applying exposure threshold of {exposure_threshold_sec} ({exposure_threshold_sec/self.binsize_sec*100:.0f}% of binsize)")

            for band, g in df.groupby("colorband"):
                evt_times = g["mjd"].to_numpy()

                counts, _ = np.histogram(evt_times, bins=bins)
                valid_bins = np.isclose(self.exposure, exposure_threshold_sec)

                exposure = self.exposure[valid_bins]
                counts = counts[valid_bins]
                centers = all_centers[valid_bins]

                rate = counts / exposure
                rate_err = np.sqrt(counts) / exposure

                band_df = pd.DataFrame({
                    "colorband": band,
                    "mjd": centers,
                    "counts": counts,
                    "count_error": np.sqrt(counts),
                    "countrate": rate,
                    "countrate_error": rate_err,
                    "exposure": exposure
                })

                rows.append(band_df)
        else:
            if verbose:
                print(" -> using individual bin_widths to calculate count rates")
            bin_width_day = np.diff(bins)
            bin_width_sec = bin_width_day * 86400

            for band, g in df.groupby("colorband"):
                evt_times = g["mjd"].to_numpy()
                counts, _ = np.histogram(evt_times, bins=bins)

                rate = counts / bin_width_sec
                rate_err = np.sqrt(counts) / bin_width_sec

                band_df = pd.DataFrame({
                    "colorband": band,
                    "mjd": all_centers,
                    "counts": counts,
                    "count_error": np.sqrt(counts),
                    "countrate": rate,
                    "countrate_error": rate_err,
                })

                rows.append(band_df)

        self._lightcurve_data = pd.concat(rows, ignore_index=True)

        if verbose:
            print(f" -> extraction yielded {len(self._lightcurve_data)} valid datapoints.") # (end)

    def calculate_color_ratios(  # (fold)
        self, error_threshold: float | None = None, verbose=True
    ) -> None:
        """
        This function calculates the color ratios
         - soft_color = med_counts/soft_counts
         - hard_color = hard_counts/med_counts
        with their respective errors and formats a dataframe containing all
        relevant data for creating the color-color and color-intensity plots.
        If error_threshold is provided, the function further filters all events
        with errors larger than the specified threshold. Results are stored in
        the self.color_data, using the following structure:
        df = {
            "mjd"
            "soft_intensity"
            "hard_intensity"
            "soft_intensity_error"
            "hard_intensity_error"
            "soft_color"
            "hard_color"
            "soft_color_error"
            "hard_color_error"
            "countrate"
            "countrate_error"
        }
        """
        df = self.lightcurve_data
        missing = {"colorband"} - set(df.columns)
        if missing:
            raise RuntimeError(
                f"The data has no assigned colorbands yet! Please use set_colorbands() to assign colorbands first"
            )

        def pick(band, col):
            return df.loc[df["colorband"] == band, col].to_numpy()

        soft_c = pick("soft", "counts")
        med_c = pick("med", "counts")
        hard_c = pick("hard", "counts")
        soft_err = pick("soft", "count_error")
        med_err = pick("med", "count_error")
        hard_err = pick("hard", "count_error")
        soft_intensity = pick("soft", "countrate")
        hard_intensity = pick("hard", "countrate")
        soft_intensity_error = pick("soft", "countrate_error")
        hard_intensity_error = pick("hard", "countrate_error")
        total_cr = (
            pick("soft", "countrate")
            + pick("med", "countrate")
            + pick("hard", "countrate")
        )
        total_cr_err = np.sqrt(
            pick("soft", "countrate_error") ** 2
            + pick("med", "countrate_error") ** 2
            + pick("hard", "countrate_error") ** 2
        )
        mjd = pick("soft", "mjd")
        if not (len(med_c) == len(soft_c) == len(hard_c)):
            raise ValueError(
                f"Bad Binsize: produced mismatched arrays "
                f"(med={len(med_c)}, soft={len(soft_c)}, hard={len(hard_c)}). "
                "Please try a different binsize."
            )
        if verbose:
            print("~ calculating color-ratios")
        soft_ok = soft_c > 0
        med_ok = med_c > 0
        soft_color = np.divide(
            med_c,
            soft_c,
            out=np.full_like(med_c, np.nan, dtype=float),
            where=soft_ok,
        )
        hard_color = np.divide(
            hard_c,
            med_c,
            out=np.full_like(hard_c, np.nan, dtype=float),
            where=med_ok,
        )
        # propagate errors:
        soft_color_error = np.divide(
            np.sqrt((soft_c * med_err) ** 2 + (med_c * soft_err) ** 2),
            soft_c**2,
            out=np.full_like(soft_c, np.nan, dtype=float),
            where=soft_ok,
        )
        hard_color_error = np.divide(
            np.sqrt((hard_c * med_err) ** 2 + (med_c * hard_err) ** 2),
            med_c**2,
            out=np.full_like(med_c, np.nan, dtype=float),
            where=med_ok,
        )
        if self._color_ratio_error_threshold is not None:
            error_threshold = self.color_ratio_error_threshold

        if error_threshold:  # (fold)
            stacked = np.column_stack(
                [
                    soft_color,
                    soft_color_error,
                    hard_color,
                    hard_color_error,
                    soft_intensity,
                    soft_intensity_error,
                    hard_intensity,
                    hard_intensity_error,
                    total_cr,
                    total_cr_err,
                    mjd,
                ]
            )
            mask = (
                (stacked[:, 1] < error_threshold)
                & (stacked[:, 3] < error_threshold)
                & (stacked[:, 5] < error_threshold)
                & (stacked[:, 7] < error_threshold)
                & (stacked[:, 9] < error_threshold)
            )
            if verbose:
                print(
                    f" -> removing {mask.sum()} datapoints with large errors (threshold: {error_threshold} keV)"
                )
            stacked = stacked[mask]
            (
                soft_color,
                soft_color_error,
                hard_color,
                hard_color_error,
                soft_intensity,
                soft_intensity_error,
                hard_intensity,
                hard_intensity_error,
                total_cr,
                total_cr_err,
                mjd,
            ) = stacked.T
        # (end)
        if verbose:
            print(" -> event count per band:")
            for band, (e_lo, e_hi) in self.colorbands.items():
                count = df.loc[df["colorband"] == band, "counts"]
                print(
                    f"    {band}  \t({e_lo} - {e_hi}) keV\t events: {count.sum()}; Avg counts/bin: {count[count > 0].mean():.2f}"
                )
        data = {
            "mjd": mjd,
            "soft_intensity": soft_intensity,
            "hard_intensity": hard_intensity,
            "soft_intensity_error": soft_intensity_error,
            "hard_intensity_error": hard_intensity_error,
            "soft_color": soft_color,
            "hard_color": hard_color,
            "soft_color_error": soft_color_error,
            "hard_color_error": hard_color_error,
            "countrate": total_cr,
            "countrate_error": total_cr_err,
        }
        self._color_data = pd.DataFrame(data)  # (end)

    def select_bins_and_colors(self) -> None:  # (fold)
        """
        Interactively select the binsize (in seconds) and colorband-boundaries
        using sliders on a matplotlib figure.
        Once the desired values are dialed in, close the matplotlib window to
        accept them.
        """

        def draw_plots():  # (fold)
            df = self.color_data

            for ax in axs:
                ax.clear()

            # Common marker style for dense plots
            marker_kw = dict(
                fmt="o",
                markersize=2.5,
                alpha=0.5,
                elinewidth=0.6,
                capsize=0,
            )

            # Softness–Intensity
            axs[0].errorbar(
                df["soft_intensity"],
                df["soft_color"],
                xerr=df["soft_intensity_error"],
                yerr=df["soft_color_error"],
                **marker_kw,
            )
            axs[0].set_ylabel("soft color", labelpad=2)
            axs[0].set_xlabel("soft count rate [1/s]", labelpad=2)
            # axs[0].set_title("Softness–Intensity", fontsize=9)
            axs[0].tick_params(labelsize=8)

            # Hardness–Intensity
            axs[1].errorbar(
                df["hard_intensity"],
                df["hard_color"],
                xerr=df["hard_intensity_error"],
                yerr=df["hard_color_error"],
                **marker_kw,
            )
            axs[1].set_ylabel("hard color", labelpad=2)
            axs[1].set_xlabel("hard count rate [1/s]", labelpad=2)
            # axs[1].set_title("Hardness–Intensity", fontsize=9)
            axs[1].tick_params(labelsize=8)

            # Color–Color
            axs[2].errorbar(
                df["soft_color"],
                df["hard_color"],
                xerr=df["soft_color_error"],
                yerr=df["hard_color_error"],
                **marker_kw,
            )
            axs[2].set_xlabel("soft color", labelpad=2)
            axs[2].set_ylabel("hard color", labelpad=2)
            # axs[2].set_title("Color–Color", fontsize=9)
            axs[2].tick_params(labelsize=8)  # (end)

        # called by on_slider_change
        def refresh(val=None):  # (fold)
            self.set_binsize(int(slider_bins.val), verbose=False)
            new_bands = {
                "soft": (self.colorbands["soft"][0], slider_soft_med.val),
                "med": (slider_soft_med.val, slider_med_hard.val),
                "hard": (slider_med_hard.val, self.colorbands["hard"][1]),
            }
            self.create_bin_array(verbose=False)
            self.set_colorbands(new_bands)
            self.apply_colorbands(verbose=False)
            self.extract_countrates(verbose=False)
            self.calculate_color_ratios(error_threshold=0.5, verbose=False)
            draw_plots()
            fig.canvas.draw_idle()
            # (end)

        # set colorbands to slider values on plot_close
        def on_close(event=None):  # (fold)
            self._colorbands = {
                "soft": (self.colorbands["soft"][0], slider_soft_med.val),
                "med": (slider_soft_med.val, slider_med_hard.val),
                "hard": (slider_med_hard.val, self.colorbands["hard"][1]),
            }
            self._binsize_sec = int(slider_bins.val)
            print("~ saving final values:")
            print(" -> final binsize:", self.binsize_sec, "sec")
            print(" -> final amount of valid datapoints:", len(self.lightcurve_data))

            print(" -> final colorband:")
            for band, (e_lo, e_hi) in self.colorbands.items():
                count = self.lightcurve_data.loc[self.lightcurve_data["colorband"] == band, "counts"]
                print(
                    f"    {band}  \t({e_lo:.2f} - {e_hi:.2f}) keV\t events: {count.sum()}; Avg counts/bin: {count[count > 0].mean():.2f}"
                )
            # (end)

        def on_key(event):  # (fold)
            if event.key == "enter":
                on_close()          # apply final values
                plt.close(fig)      # close window
            # (end)

        # Initialize selection plot
        if self.binsize_upper_threshold is None or self.binsize_lower_threshold is None:
            lower = float(
                np.mean(np.diff(self.event_data["mjd"].to_numpy())) 
                * 20 * 86400
            )
            upper = float(
                (self.event_data["mjd"].max() - self.event_data["mjd"].min())
                / 100
                * 86400
            )
            self.set_interactive_bin_bounds(lower, upper)

        if self._binsize_day is None:
            std_binsize = (
                self.event_data["mjd"].max() - self.event_data["mjd"].min()
            ) / 500
            std_binsize_sec = std_binsize * 86400
            self.set_binsize(binsize_sec=std_binsize_sec)
        if self._bin_array is None:
            self.create_bin_array()

        self.apply_colorbands()
        self.extract_countrates()
        self.calculate_color_ratios()  # initial calculation
        fig, axs = plt.subplots(1, 3, figsize=(15, 5))
        fig.subplots_adjust(bottom=0.25)
        fig.text(
            0.5,
            0.01,
            "[ENTER] accept values",
            ha="center",
            va="bottom",
            fontsize=10,
        )
        draw_plots()
        axcolor = "steelblue"
        ax_soft_med = plt.axes([0.15, 0.1, 0.65, 0.03], facecolor=axcolor)
        ax_med_hard = plt.axes([0.15, 0.05, 0.65, 0.03], facecolor=axcolor)
        slider_ax = plt.axes([0.15, 0.15, 0.65, 0.03], facecolor=axcolor)

        slider_soft_med = Slider(
            ax_soft_med,
            "soft-med (keV)",
            valmin=self.colorbands["soft"][0],
            valmax=self.colorbands["med"][1],
            valinit=self.colorbands["soft"][1],
        )

        slider_med_hard = Slider(
            ax_med_hard,
            "med-hard (keV)",
            valmin=self.colorbands["med"][0],
            valmax=self.colorbands["hard"][1],
            valinit=self.colorbands["med"][1],
        )

        slider_bins = Slider(
            slider_ax,
            "binsize (sec)",
            valmin=self.binsize_lower_threshold,
            valmax=self.binsize_upper_threshold,
            valstep=1,
            valinit=self.binsize_sec,
        )

        slider_bins.on_changed(refresh)
        slider_soft_med.on_changed(refresh)
        slider_med_hard.on_changed(refresh)
        fig.canvas.mpl_connect("close_event", on_close)
        fig.canvas.mpl_connect("key_press_event", on_key)
        plt.show()
        # (end)

    def select_branches_in_cc(self, selector: str | None = None): # (fold)


        if self._color_data is None:
            self.calculate_color_ratios()

        df = self.color_data
        next_view = "CC"

        match selector:
            case "HI":
                x = df["hard_intensity"].to_numpy()
                y = df["hard_color"].to_numpy()
                xlabel, ylabel = "hard count rate [1/s]", "hard color"
            case "SI":
                x = df["soft_intensity"].to_numpy()
                y = df["soft_color"].to_numpy()
                xlabel, ylabel = "soft count rate [1/s]", "soft color"
            case _:
                x = df["soft_color"].to_numpy()
                y = df["hard_color"].to_numpy()
                xlabel, ylabel = "soft color", "hard color"

        points = np.vstack([x, y]).T

        if "branch" not in df.columns:
            df["branch"] = "unclassified"

        key_to_branch = {
            "h": "Horizontal",
            "n": "Normal",
            "f": "Flaring",
        }

        current_branch = None

        fig, ax = plt.subplots()
        fig.canvas.mpl_disconnect(fig.canvas.manager.key_press_handler_id)

        def draw():
            ax.clear()

            for branch, color in self.branch_colors.items():
                mask = df["branch"] == branch
                if mask.any():
                    ax.scatter(
                        x[mask],
                        y[mask],
                        color=color,
                        marker=self.markers[branch],
                        alpha=0.6,
                        label=branch,
                    )

            ax.set_xlabel(xlabel)
            ax.set_ylabel(ylabel)

            if current_branch is None:
                ax.set_title(
                    "[h/n/f] select branch   |   [TAB] switch view   |   [ENTER] finish"
                )
            else:
                ax.set_title(
                    f"Branch: {current_branch}   |   draw polygon   |   [ENTER] finish"
                )

            ax.legend()

        def onselect(verts):
            nonlocal current_branch

            if current_branch is None:
                return

            path = Path(verts)
            mask = path.contains_points(points)
            indices = np.where(mask)[0]

            if len(indices) == 0:
                return

            df.loc[indices, "branch"] = current_branch

            current_branch = None

            polygon_selector.clear()
            polygon_selector.set_active(False)

            draw()
            fig.canvas.draw_idle()

        def on_key(event):
            nonlocal current_branch, next_view

            key = event.key.lower() if event.key else ""

            if key in key_to_branch:
                current_branch = key_to_branch[key]
                polygon_selector.set_active(True)

            elif key == "enter":
                plt.close(fig)
                return

            elif key == "tab":
                next_view = "LC"
                plt.close(fig)
                return

            elif key == "q":
                next_view = "quit"
                plt.close(fig)
                return

            draw()
            fig.canvas.draw_idle()

        polygon_selector = PolygonSelector(
            ax,
            onselect,
            useblit=True,
            props=dict(color="black", linestyle="--", linewidth=1),
        )

        polygon_selector.set_active(False)

        fig.canvas.mpl_connect("key_press_event", on_key)

        draw()
        plt.show()

        return next_view # (end)

    def select_branches_in_lc(self): # (fold)


        if self._color_data is None:
            self.calculate_color_ratios()

        df = self.color_data
        next_view = "LC"

        if "branch" not in df.columns:
            df["branch"] = "unclassified"

        key_to_branch = {
            "h": "Horizontal",
            "n": "Normal",
            "f": "Flaring",
        }

        current_branch = None
        mjd = df["mjd"].to_numpy()

        fig, ax = plt.subplots(figsize=(10, 5))
        fig.canvas.mpl_disconnect(fig.canvas.manager.key_press_handler_id)

        plt.subplots_adjust(bottom=0.25)

        def draw():
            ax.clear()

            for branch, color in self.branch_colors.items():
                mask = df["branch"] == branch
                if mask.any():
                    ax.scatter(
                        df["mjd"][mask],
                        df["countrate"][mask],
                        color=color,
                        marker=self.markers[branch],
                        alpha=0.7,
                        label=branch,
                    )

            ax.axvline(slider_left.val, linestyle="--")
            ax.axvline(slider_right.val, linestyle="--")

            ax.set_xlabel("MJD")
            ax.set_ylabel("count rate [1/s]")

            if current_branch is None:
                ax.set_title(
                    "[h/n/f] select branch   |   adjust sliders   |   [TAB] switch view   |   [ENTER] finish"
                )
            else:
                ax.set_title(
                    f"Branch: {current_branch}   |   [SPACE] apply selection   |   [ENTER] finish"
                )

            ax.legend()

        def update(val=None):
            draw()
            fig.canvas.draw_idle()

        def confirm():
            nonlocal current_branch

            if current_branch is None:
                return

            mask = (mjd >= slider_left.val) & (mjd <= slider_right.val)
            df.loc[mask, "branch"] = current_branch

            current_branch = None

            draw()
            fig.canvas.draw_idle()


        def on_key(event):
            nonlocal current_branch, next_view

            key = event.key.lower() if event.key else ""

            if key in key_to_branch:
                current_branch = key_to_branch[key]

            elif key == " ":
                confirm()

            elif key == "enter":
                next_view = "quit"
                plt.close(fig)
                return

            elif key == "tab":
                next_view = "CC"
                plt.close(fig)
                return

            elif key == "q":
                next_view = "quit"
                plt.close(fig)
                return

            draw()
            fig.canvas.draw_idle()

        ax_left = plt.axes([0.15, 0.1, 0.65, 0.03])
        ax_right = plt.axes([0.15, 0.05, 0.65, 0.03])

        slider_left = Slider(ax_left, "Left", mjd.min(), mjd.max(), valinit=mjd.min())
        slider_right = Slider(ax_right, "Right", mjd.min(), mjd.max(), valinit=mjd.max())

        slider_left.on_changed(update)
        slider_right.on_changed(update)

        fig.canvas.mpl_connect("key_press_event", on_key)

        draw()
        plt.show()

        return next_view # (end)

    def select_branches(self): # (fold)
        """
        Helper function to enable 'simultaneous' use of the two 
        select_branches_in_...() functions.
        This is the preferred method.
        """
        view = "CC"

        while view != "quit":

            if view == "CC":
                view = self.select_branches_in_cc()

            elif view == "LC":
                view = self.select_branches_in_lc() # (end)

    def build_branch_gti(self) -> dict[str, np.ndarray]:  # (fold)
        """
        If branches have been selected, return a 'gti'-array for each branch,
        packed into a python dict.
        The intervals correspond to the bins that the data has been binned into
        prior to calling this function.
        """

        df = self.color_data

        if "branch" not in df.columns:
            raise RuntimeError(
                "No branch information found. Run select_branches() first."
            )

        if self._binsize_day is None:
            raise RuntimeError("Binsize not known. Cannot construct GTIs.")

        half = 0.5 * self.binsize_day
        branch_gti = {}

        for branch in df["branch"].unique():
            if branch == "unclassified":
                continue

            sub = df[df["branch"] == branch].sort_values("mjd")
            if sub.empty:
                continue

            # Convert bin centers to intervals
            starts = sub["mjd"].to_numpy() - half
            stops = sub["mjd"].to_numpy() + half

            intervals = []
            cur_start = starts[0]
            cur_stop = stops[0]

            for s, e in zip(starts[1:], stops[1:]):
                # contiguous or overlapping bins
                if s <= cur_stop:
                    cur_stop = max(cur_stop, e)
                else:
                    intervals.append((cur_start, cur_stop))
                    cur_start, cur_stop = s, e

            intervals.append((cur_start, cur_stop))
            branch_gti[branch] = np.array(intervals)

        self._branch_gti = branch_gti
        return branch_gti  # (end)


    ##################
    #### PLOTTING ####
    ##################

    def _plot_ci(  # (fold)
        self, ax, x, xerr, y, yerr, colors, ylabel, title, marker_size=40
    ):
        """
        Internal helper function to plot color-intensity data.
        """
        ax.errorbar(
            x,
            y,
            xerr=xerr,
            yerr=yerr,
            fmt="none",
            ecolor="gray",
            alpha=0.6,
            capsize=2,
            zorder=1,
        )

        # scatter points (branch-separated)
        if "branch" in self.color_data:
            last_scatter = None
            for branch, marker in self.markers.items():
                mask = self.color_data["branch"] == branch
                last_scatter = ax.scatter(
                    x[mask],
                    y[mask],
                    c=colors[mask],
                    cmap="viridis",
                    s=marker_size,
                    marker=marker,
                    edgecolors="k",
                    alpha=0.8,
                    label=branch,
                    zorder=2,
                )
        else:
            last_scatter = ax.scatter(
                x,
                y,
                c=colors,
                cmap="viridis",
                s=marker_size,
                edgecolors="k",
                alpha=0.8,
                zorder=2,
            )

        ax.set_xlabel("intensity [counts/sec]")
        ax.set_ylabel(ylabel)
        ax.set_title(title, y=1.05)
        ax.legend(title="Branch")
        ax.grid(True, alpha=0.3)

        return ax, last_scatter

    # (end)

    def plot_softness_intensity(self, ax=None):  # (fold)
        """
        Plot the softness_intensty diagram.
        """

        df = self.color_data
        plot_self = False
        if ax is None:
            plot_self = True
            fig, ax = plt.subplots(figsize=(6, 5))

        ax, sc = self._plot_ci(
            ax,
            x=df["soft_intensity"],
            xerr=df["soft_intensity_error"],
            y=df["soft_color"],
            colors=df["mjd"],
            yerr=df["soft_color_error"],
            ylabel="soft color (M/S)",
            title="Softness-Intensity",
            marker_size=40,
        )

        if sc is not None:
            cbar = plt.colorbar(sc, ax=ax)
            cbar.set_label("MJD")

        if plot_self:
            plt.show()
        else:
            return ax

    # (end)

    def plot_hardness_intensity(self, ax=None):  # (fold)
        """
        Plot the hardness_intensty diagram.
        """

        df = self.color_data
        plot_self = False
        if ax is None:
            plot_self = True
            fig, ax = plt.subplots(figsize=(6, 5))

        ax, sc = self._plot_ci(
            ax,
            x=df["hard_intensity"],
            xerr=df["hard_intensity_error"],
            y=df["hard_color"],
            colors=df["mjd"],
            yerr=df["hard_color_error"],
            ylabel="hard color (M/S)",
            title="Hardness-Intensity",
            marker_size=40,
        )

        if sc is not None:
            cbar = plt.colorbar(sc, ax=ax)
            cbar.set_label("MJD")

        if plot_self:
            plt.show()
        else:
            return ax

    # (end)

    def plot_color_color(self, ax=None):  # (fold)
        """
        Plot the color-color diagram.
        """

        df = self.color_data
        plot_self = True
        if ax is None:
            plot_self = True
            fig, ax = plt.subplots(figsize=(6, 5))

        x = df["soft_color"]
        y = df["hard_color"]
        xerr = df["soft_color_error"]
        yerr = df["hard_color_error"]
        c = df["mjd"]

        ax.errorbar(
            x,
            y,
            xerr=xerr,
            yerr=yerr,
            fmt="none",  # don't draw additional points
            ecolor="gray",  # color of the errorbars
            alpha=0.6,  # transparency
            capsize=2,  # small caps at ends
            zorder=1,
        )

        if "branch" in df.columns:
            for branch, marker in self.markers.items():
                mask = self.color_data["branch"] == branch
                sc = ax.scatter(
                    x[mask],
                    y[mask],
                    c=c[mask],
                    cmap="viridis",
                    s=40,
                    marker=marker,
                    edgecolors="k",
                    alpha=0.8,
                    label=branch,
                    zorder=2,
                )
        else:
            sc = ax.scatter(
                x,
                y,
                c=c,
                cmap="viridis",
                s=40,
                edgecolors="k",
                alpha=0.8,
                zorder=2,
            )

        cbar = plt.colorbar(sc, ax=ax)
        cbar.set_label("MJD")

        ax.set_xlabel("soft color (M/S)")
        ax.set_ylabel("hard color (H/M)")
        if "branch" in df.columns:
            ax.legend(title="Branch")
        ax.set_title("Color–Color")
        ax.grid(True, alpha=0.3)

        plt.show()

        # (end)

    def plot_color_intensity(self):  # (fold)
        """
        Plot both color_intensty diagrams.
        """
        fig, axs = plt.subplots(1, 2, figsize=(12, 4))
        self.plot_softness_intensity(ax=axs[0])
        self.plot_hardness_intensity(ax=axs[1])
        plt.show()

    # (end)

    def plot_branched_lcs(self, ax=None, show_gti=True):  # (fold)
        """
        Plot lightcurves split by branch, optionally with branch-GTIs overlaid.
        Can be given an ax-instance to embedd the graph in larger figures.
        Assumes branches have already been selected.
        """


        branched = self.get_color_data()

        if ax is None:
            fig, ax = plt.subplots(figsize=(10, 5))
            axpassed = False
        else:
            fig = ax.figure

        for branch, color in self.branch_colors.items():
            mask = branched["branch"] == branch
            if not mask.any():
                continue

            df = branched.loc[mask, ["mjd", "countrate", "countrate_error"]]
            label = f"{branch} branch" if branch != "unclassified" else "unclassified"

            ax.errorbar(
                df["mjd"],
                df["countrate"],
                yerr=df["countrate_error"],
                fmt="o",
                ms=4,
                color=color,
                label=label,
            )

        branch_gti = self.build_branch_gti()

        if show_gti:
            for branch, intervals in branch_gti.items():
                color = self.branch_colors.get(branch, "gray")

                for i, (start, stop) in enumerate(intervals):
                    ax.axvspan(
                        start,
                        stop,
                        color=color,
                        alpha=0.3,
                        label=branch if i == 0 else "_nolegend_",
                    )

        ax.set_xlabel("MJD")
        ax.set_ylabel("count rate [1/s]")
        ax.legend()

        if not axpassed:
            plt.show()

        return fig, ax  # (end)

    ############
    #### IO ####
    ############

    def write_branched_stdgti(self, save_location_dir: str):  # (fold)
        """
        Save the branch-gti into a fits file with identical specification as
        the one that was used to load the gti data. Requires previous loading
        of gti data via load_gti_from_file().
        NOTE: overwrites any existing files with the same path!
        Paths are as follows:
            filename = f"{save_location_dir}_{branch}-branch.gti"
        """

        if self._branch_gti is None:
            try:
                self.build_branch_gti()
            except RuntimeError as e:
                raise RuntimeError(
                    "Branched GTI has not been calculated yet. "
                    "Please select branches first."
                ) from e

        branch_gti = self.branch_gti
        gti_file = self.stdgti_file_data
        mjdref = gti_file.stdgti_header["MJDREF"]

        for branch, gti in branch_gti.items():

            filename = f"{save_location_dir}_{branch}-branch.gti"

            start = ((gti[:, 0] - mjdref) * 86400.0).astype("float64")
            stop = ((gti[:, 1] - mjdref) * 86400.0).astype("float64")

            cols = fits.ColDefs(
                [
                    fits.Column(name="START", format="1D", unit="sec", array=start),
                    fits.Column(name="STOP", format="1D", unit="sec", array=stop),
                ]
            )

            # rebuild gti_file
            stdgti_header = gti_file.stdgti_header.copy()
            gti_hdu = fits.BinTableHDU.from_columns(cols, header=stdgti_header)

            gti_hdu.header["TSTART"] = start.min()
            gti_hdu.header["TSTOP"] = stop.max()
            gti_hdu.header.add_history("GTI regenerated from branched GTI")

            # primary hdu
            primary_hdu = fits.PrimaryHDU(header=gti_file.primary_header.copy())
            primary_hdu.header["TSTART"] = start.min()
            primary_hdu.header["TSTOP"] = start.max()
            hdul = fits.HDUList([primary_hdu, gti_hdu])

            hdul.writeto(filename, overwrite=True)
            # (end)

    def get_event_data(self) -> pd.DataFrame:
        """
        Returns the event data.
        """
        return self.event_data

    def get_colourband_data(self) -> pd.DataFrame:
        """
        Returns the event data, with associated colourbands.
        """
        return self.colorbanded_event_data

    def get_lightcurve_data(self) -> pd.DataFrame:
        """
        Returns the lightcurve data with associated colourbands.
        """
        return self.lightcurve_data

    def get_color_data(self) -> pd.DataFrame:
        """
        Returns the colour data. Every bin in the lightcurve has additional
        colour data.
        """
        return self.color_data
