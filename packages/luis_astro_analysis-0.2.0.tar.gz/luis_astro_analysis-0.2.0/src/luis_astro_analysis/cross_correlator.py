import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from astropy.io import fits
from matplotlib.widgets import RadioButtons, Slider
from scipy.interpolate import interp1d


class Cross_Correlator:
    """
    The Cross_Correlator class allows for the calculation of the
    cross-correlation and lag analysis in unevenly sampled astronomical light
    curves. It is capable of calculating the direct cross correlation function
    (dccf) introduced by Edelson and Krolik (1988), as well as the traditional
    cross correlation via the integral.

    The Cross_Correlator operates on two light curves loaded into fixed slots:

        - slot 1 (lc1): reference light curve
        - slot 2 (lc2): comparison light curve

    Lightcurves (in the form of pandas.DataFrame) can be loaded into each slot
    via load_dataframe().

    The lag tau is then defined such that:

        tau > 0  ⇒  lc2 is delayed with respect to lc1 (features in lc1 occur
        earlier than the corresponding features in lc2)

        tau < 0  ⇒  lc2 leads lc1 (features in lc2 occur earlier than those in
        lc1)

    Provided, two lightcurves have been loaded, the dccf can be calculated
    using either calculate_dccf() (this method uses a global normalization) or
    dccf_local_norm() (uses local normalization). If ideal tau values
    (necessary for cc-calculation) are not known, the user can use
    interactive_dccf() to search for ideal values with sliders. The function
    will create initial values by itself if none are provided.

    While the dccf method is recommended, the classical cross-correlation is 
    also available via cross_correlate(). This method relies on both lcs to 
    lie on the same time grid. If this is not the case, the user can rebin the
    lcs onto the same timegrid using rebin_lightcurves().

    In addition, the user can provide Good Time Intervals (GTI) in the form of
    a FITS file with the STDGTI format, or a NumPy array (see load_gti()). This
    information can be used to filter one or both of the lightcurves loaded,
    before calculating the cross-correlation. 

    The resulting cross-correlation can be retured as a DataFrame by accessing
    either self.cross-correlation() or self.dccf(), depending on what method
    has been used.
    """

    def __init__(self) -> None:  # (fold)
        # data
        self._lc_1_data: pd.DataFrame | None = None
        self._lc_2_data: pd.DataFrame | None = None
        # filters
        self._gti: np.ndarray | None = None
        self._bins: np.ndarray | None = None
        self._cc: pd.DataFrame | None = None
        self._dccf: pd.DataFrame | None = None
        # (end)

    # Properties
    # (fold)
    @property
    def lc1(self):
        if self._lc_1_data is None:
            raise RuntimeError("No lightcurve-data loaded in slot 1")
        return self._lc_1_data

    @lc1.setter
    def lc1(self, df: pd.DataFrame):
        self._lc_1_data = df

    @property
    def lc2(self):
        if self._lc_2_data is None:
            raise RuntimeError("No lightcurve-data loaded in slot 2")
        return self._lc_2_data

    @lc2.setter
    def lc2(self, df: pd.DataFrame):
        self._lc_2_data = df

    @property
    def gti(self):
        if self._gti is None:
            raise RuntimeError("No gti-data loaded yet")
        return self._gti

    @property
    def bins(self):
        if self._bins is None:
            raise RuntimeError("No bins-data loaded yet")
        return self._bins

    @property
    def cross_correlation(self):
        if self._cc is None:
            raise RuntimeError("Cross Correlation hasn't been calculated yet")
        return self._cc

    @property
    def dccf(self):
        if self._dccf is None:
            raise RuntimeError("Cross Correlation hasn't been calculated yet")
        return self._dccf
    # (end)

    #################
    #### HELPERS ####
    #################

    def ensure_both_lcs_loaded(self) -> None:  # (fold)
        if self._lc_1_data is None or self._lc_2_data is None:
            raise RuntimeError(
                "Please load lightcurve-data in both slots for this operation"
            )
            # (end)

    def ensure_atleast_one_lc_loaded(self) -> None:  # (fold)
        if self._lc_1_data is None and self._lc_2_data is None:
            raise RuntimeError("Please load at least one lightcurve for this operation")
            # (end)

    ######################
    #### DATA LOADING ####
    ######################

    def load_dataframe(self, df: pd.DataFrame, identifier: str, slot: int) -> None:  # (fold)
        """
        Load the lightcurve data that is to be analyzed in form of a pandas DataFrame.
        Please load one DataFrame into each slot.
        Necessary fields:
            df = {
                "mjd"   : float
                "countrate"    : float
                "countrate_error": float
            }
        Optional fields:
            "id"    : str (``identifier`` will become id. Can be set manually as well)
            "branch": str
        """
        df["id"] = identifier
        missing = {"mjd", "countrate", "countrate_error"} - set(df.columns)
        if missing:
            raise ValueError(f"The provided DataFrame has missing columns: {missing}")
        print(f"loading data: '{identifier}' into slot {slot}.")
        if slot == 1:
            if self._lc_1_data is None:
                self._lc_1_data = df
            else:
                raise RuntimeError("Slot 1 data already assigned.")
        elif slot == 2:
            if self._lc_2_data is None:
                self._lc_2_data = df
            else:
                raise RuntimeError("Slot 2 data already assigned.")
        else:
            raise ValueError("Only two slots available")
        # (end)

    def load_gti(  # (fold)
        self, gti_path: str | None = None, gti_arr: np.ndarray | None = None
    ) -> None:
        """
        Load Good Time Intervals (GTIs) and store them internally in MJD units.
        GTIs may be provided either via a FITS file (STDGTI) or
        directly as a NumPy array. The np.array must have shape (N, 2):
        [ [start0, stop0], [start1, stop1], ...] (Timeunit is MJD).
        """
        if gti_path is not None:
            with fits.open(gti_path) as hdul:
                gti = hdul["STDGTI"]
                mjdref = gti.header["MJDREF"]  # type: ignore
                start = np.array(gti.data["START"])  # type: ignore
                stop = np.array(gti.data["STOP"])  # type: ignore
            intervals = np.column_stack((start, stop))
            mjd_intervals = intervals / (60 * 60 * 24) + mjdref
            self._gti = mjd_intervals
        if gti_arr is not None:
            self._gti = gti_arr
        # (end)

    def select_good_time(self, selector: int | None = None):  # (fold)
        """
        Filter one or both loaded light curves so onlydata points within the
        GTIs are retained. ``selector`` selects the lightcurve to act upon.
        (If ``selector`` is None, filtering is applied to both lcs; otherwise
        applies to lc1 (1) or lc2 (2)).
        """
        if selector is None:
            self.ensure_both_lcs_loaded()
            for name in ["lc1", "lc2"]:
                df = getattr(self, name)
                print(f"selecting good time for {name} ({df["id"].unique()})")
                mask = np.zeros(len(df), dtype=bool)
                mjd = df["mjd"].to_numpy()
                for start, stop in self.gti:
                    mask |= (mjd >= start) & (mjd <= stop)
                setattr(self, name, df[mask])
                dropped = len(df) - len(df[mask])
                print(f" ~ found and dropped {dropped} events outside gti")
                print(
                    f" ~ {len(df[mask])} events remain ({(len(df[mask])/len(df) * 100):.0f}%)"
                )
        else:
            if selector == 1:
                df = self.lc1
                name = "lc1"
            elif selector == 2:
                df = self.lc2
                name = "lc2"
            else:
                raise ValueError("Please select a valid slot number (1 or 2)")

            print(f"selecting good time for {name} ({df["id"].unique()})")
            mask = np.zeros(len(df), dtype=bool)
            mjd = df["mjd"].to_numpy()
            for start, stop in self.gti:
                mask |= (mjd >= start) & (mjd <= stop)
            setattr(self, name, df[mask])
            dropped = len(df) - len(df[mask])
            print(f" ~ found and dropped {dropped} events outside gti")
            print(
                f" ~ {len(df[mask])} events remain ({(len(df[mask])/len(df) * 100):.0f}%)"
            )
        # (end)

    def rebin_lightcurves(  # (fold)
        self,
        bins: np.ndarray,
        selector: int | None = None,
        keep_only_simultaneous=False,
    ):
        """
        Rebin one or both light curves onto a specified time grid (``bins``)
        using inverse-variance weighting. Used when calculating the cross
        correlation via the integral method (i.e. cross_correlate()).
        Expects a 1D np.ndarray with the time-bin-edges.
        (see i.e. fits_util.make_time_bins()) If ``selector`` is None,
        filtering is applied to both lcs;
        otherwise applies to lc1 (1) or lc2 (2).
        Optionally only retain bins with simultaneous measurements in both
        light curves.
        """
        self._bins = bins

        if selector == 1:
            names = ["lc1"]

        elif selector == 2:
            names = ["lc2"]

        elif selector is None:
            self.ensure_both_lcs_loaded()
            names = ["lc1", "lc2"]

        else:
            raise ValueError("Unexpected selector, please choose one of 1, 2, None")

        bin_centers = 0.5 * (bins[:-1] + bins[1:])
        nbins = len(bin_centers)

        if nbins > len(self.lc1) or nbins > len(self.lc2):
            print(" ~ WARNING: bin-array is finer than the lcs")

        print(f" ~ binning into {nbins} bins")

        for name in names:

            print(f"rebinning lightcurve {name}.")
            df = getattr(self, name)
            id_ = df["id"].iloc[0]

            # assign bins
            bin_idx = np.digitize(df["mjd"].to_numpy(), bins) - 1
            df = df.assign(_bin=bin_idx)

            # keep only valid rows
            valid = (
                np.isfinite(df["countrate"])
                & np.isfinite(df["countrate_error"])
                & (df["countrate_error"] > 0)
                & (df["_bin"] >= 0)
                & (df["_bin"] < nbins)
            )
            df = df.loc[valid]

            if len(df) == 0:
                out = pd.DataFrame(
                    {
                        "id": id_,
                        "mjd": bin_centers,
                        "countrate": np.nan,
                        "countrate_error": np.nan,
                    }
                )
                setattr(self, name, out)
                continue

            w = 1.0 / (df["countrate_error"] ** 2)
            df = df.assign(_w=w, _wcr=w * df["countrate"])

            g = df.groupby("_bin", sort=False)

            cr = g["_wcr"].sum() / g["_w"].sum()
            cr_err = np.sqrt(1.0 / g["_w"].sum())

            out = pd.DataFrame(
                {
                    "id": id_,
                    "mjd": bin_centers,
                    "countrate": cr.reindex(range(nbins)).to_numpy(),
                    "countrate_error": cr_err.reindex(range(nbins)).to_numpy(),
                }
            )

            setattr(self, name, out)

        if keep_only_simultaneous:
            mask = ~(self.lc1["countrate"].isna() | self.lc2["countrate"].isna())
            self._lc_1_data = self.lc1.loc[mask].reset_index(drop=True)
            self._lc_2_data = self.lc2.loc[mask].reset_index(drop=True)
        # (end)

    def cross_correlate(  # (fold)
        self,
        tau_range: tuple[int, int],
        n_tau: int,
        single_gti: tuple | None = None,
        min_pairs: int = 5,
    ):
        """
        Compute the interpolated cross-correlation between two light curves on
        the same time-grid. The range of the lag, as well as the number of
        individual lag times has to be specified in seconds. The correlation is
        optionally restricted to a single time interval (`single_gti`, originaly
        for debug reasons). `min_pairs` sets the minimal amount of datapoints
        that should be available for any tau lag. If less than `min_pairs` pairs
        exist, the datapoint will be omitted.

        Assumes:
        - lightcurves are already on the same time grid (-> rebin_lightcurves())
        - `single_gti` is a single (t0, t1) tuple in MJD
        """

        SEC_PER_DAY = 86400.0

        taus = np.linspace(tau_range[0], tau_range[1], n_tau)
        cc = np.full_like(taus, np.nan, dtype=float)

        mjd = self.lc1["mjd"].to_numpy()
        cr1 = self.lc1["countrate"].to_numpy().astype(float)
        cr2 = self.lc2["countrate"].to_numpy().astype(float)

        if not np.allclose(mjd, self.lc2["mjd"].to_numpy()):
            raise ValueError(
                "Lightcurves must be on identical grids. Try using rebin_lightcurves() to achieve this."
            )

        if len(cr1) < 2:
            return taus, cc

        if single_gti is not None:
            t0, t1 = single_gti
            single_gti_mask = (mjd >= t0) & (mjd <= t1)
        else:
            single_gti_mask = np.ones_like(mjd, dtype=bool)

        if np.sum(single_gti_mask) < 3:
            return taus, cc

        mjd = mjd[single_gti_mask]
        cr1 = cr1[single_gti_mask]
        cr2 = cr2[single_gti_mask]

        t_sec = (mjd - mjd[0]) * SEC_PER_DAY

        # Mean subtraction
        cr1 -= np.mean(cr1)
        cr2 -= np.mean(cr2)

        interp_cr2 = interp1d(
            t_sec,
            cr2,
            kind="linear",
            bounds_error=False,
            fill_value=np.nan,
        )

        for i, tau in enumerate(taus):
            cr2_shift = interp_cr2(t_sec + tau)
            valid = np.isfinite(cr2_shift)

            if np.sum(valid) < min_pairs:
                continue

            f1 = cr1[valid]
            f2 = cr2_shift[valid]

            num = np.sum(f1 * f2)
            den = np.sqrt(np.sum(f1**2) * np.sum(f2**2))

            if den > 0:
                cc[i] = num / den

        self._tau = taus
        self._cc = cc

        return taus, cc  # (end)

    def _bin_udcf(self, udcf, dt, tau_bins, dtau, min_pairs=20):  # (fold)
        """
        Helper function that applies time binning to the udcf matrix.
        (global normalization)
        """
        print(" ~ binning udcf matrix")

        half = 0.5 * dtau
        nbins = len(tau_bins)

        # map each pair to a bin index
        k = np.floor((dt - (tau_bins[0] - half)) / dtau).astype(int)

        valid = (k >= 0) & (k < nbins) & np.isfinite(udcf)
        k = k[valid]
        u = udcf[valid]

        # counts
        n = np.bincount(k, minlength=nbins)

        # sums and squared sums
        s1 = np.bincount(k, weights=u, minlength=nbins)
        s2 = np.bincount(k, weights=u * u, minlength=nbins)

        out = np.full(nbins, np.nan)
        err = np.full(nbins, np.nan)

        good = n >= min_pairs
        out[good] = s1[good] / n[good]

        # std / sqrt(n)
        var = (s2[good] - s1[good] ** 2 / n[good]) / (n[good] - 1)
        err[good] = np.sqrt(var) / np.sqrt(n[good])

        return out, err, n  # (end)

    def _bin_udcf_per_lag(  # (fold)
        self,
        udcf,
        dt,
        tau_bins,
        dtau,
        *,
        a,
        b,
        ia,
        ib,
        min_pairs=20,
    ):
        """
        Helper function to apply time binning to the udcf per lag bin.
        (local normalization)
        """
        print(" ~ binning udcf matrix (per-lag normalization)")

        nbins = len(tau_bins)
        half = 0.5 * dtau

        # map each pair to a τ-bin index
        k = np.floor((dt - (tau_bins[0] - half)) / dtau).astype(int)

        valid = (k >= 0) & (k < nbins) & np.isfinite(udcf)
        k = k[valid]

        ia = ia[valid]
        ib = ib[valid]

        out = np.full(nbins, np.nan)
        err = np.full(nbins, np.nan)
        n = np.bincount(k, minlength=nbins)

        # print("τ-bin definition:")
        # print(f"  dtau = {dtau}")
        # print(f"  τ range = [{tau_bins[0]}, {tau_bins[-1]}]")
        # print(f"  nbins {nbins}")
        # print(f"  bins with ≥{min_pairs} pairs: {(n >= min_pairs).sum()}")
        #
        for bin_idx in range(nbins):
            mask = k == bin_idx
            npairs = mask.sum()

            if npairs < min_pairs:
                continue

            ak = a[ia[mask]]
            bk = b[ib[mask]]

            ma = ak.mean()
            mb = bk.mean()

            va = ak.var(ddof=1)
            vb = bk.var(ddof=1)

            # print(f"τ-bin {bin_idx:3d} ")
            # print(f"(τ≈{tau_bins[bin_idx]:7.1f}s): ")
            # print(f"N={npairs:5d}, ")
            # print(f"<a>={ma:+.5e}, <b>={mb:+.5e}, ")
            # print(f"Var(a)={va:.5e}, Var(b)={vb:.5e}")

            if va <= 0 or vb <= 0:
                continue

            dcfs = (ak - ma) * (bk - mb) / np.sqrt(va * vb)

            out[bin_idx] = dcfs.mean()
            err[bin_idx] = dcfs.std(ddof=1) / np.sqrt(dcfs.size)

            # print(f"    → CC={out[bin_idx]:+.4f}, ")
            # print(f"      σ_CC={err[bin_idx]:.4f}")
            # print()

        return out, err, n  # (end)

    def dccf_local_norm(self, tau_max, d_tau):  # (fold)
        """
        Compute the discrete cross-correlation function (DCCF) between two
        light curves using a local normalization method (per tau-bin).
        The function needs the maximum (absolute) tau that should be calculated
        (edges of the graph), as well as the tau-step provided in seconds.
        In case the optimal values are unkown, use either the interactive_dccf()
        function to find optimal values by hand or the
        suggest_dccf_tau_params(), to get a set of suggested values.
        """
        print("calculating dccf.")

        lc1 = self.lc1.dropna()
        lc2 = self.lc2.dropna()

        a = lc1["countrate"].to_numpy()
        b = lc2["countrate"].to_numpy()
        ae = lc1["countrate_error"].to_numpy()
        be = lc2["countrate_error"].to_numpy()
        ta = lc1["mjd"].to_numpy() * 86400.0
        tb = lc2["mjd"].to_numpy() * 86400.0

        if len(a) < 2 or len(b) < 2:
            raise ValueError(f"found no countrate data in one of the lcs provided")

        a_vec = a[:, np.newaxis]
        b_vec = b[np.newaxis, :]
        ta_vec = ta[:, np.newaxis]
        tb_vec = tb[np.newaxis, :]

        print(" ~ calculating udcf matrix")
        udcf_ij = a_vec * b_vec

        print(" ~ calculating dt matrix")
        dt_ij = tb_vec - ta_vec

        # flatten for vectorized calculation
        dt = dt_ij.ravel()
        udcf = udcf_ij.ravel()
        valid = np.isfinite(dt) & np.isfinite(udcf)

        n_valid = (~valid).sum()
        if n_valid > 0:
            print(f" ~ dropping {n_valid} unusable matrix entries.")

        dt = dt[valid]
        udcf = udcf[valid]

        ia, ib = np.indices((len(a), len(b)))
        ia = ia.ravel()
        ib = ib.ravel()

        tau_bins = np.arange(-tau_max, tau_max + d_tau, d_tau)
        tau_centers = tau_bins

        dccf, err, M = self._bin_udcf_per_lag(
            udcf, dt, tau_bins, d_tau, a=a, b=b, ia=ia, ib=ib
        )

        df = pd.DataFrame(
            {
                "tau": tau_centers,
                "cc": dccf,
                "cc_err": err,
                "counts": M,
            }
        )

        # reject all bins with less than min_pairs datapoints
        min_pairs = 5
        mask = (df["counts"] >= min_pairs) & np.isfinite(df["cc"])
        if not np.any(mask):
            raise RuntimeError("No DCCF bins pass the minimum-pairs criterion")

        dfv = df.loc[mask]
        print(
            f" ~ rejecting {(~mask).sum()} datapoints due to having less than the minimum-pairs criterion"
        )

        self._dccf = dfv

        # statistics
        i_peak = dfv["cc"].idxmax()
        tau_peak = dfv.at[i_peak, "tau"]
        cc_peak = dfv.at[i_peak, "cc"]
        M_peak = dfv.at[i_peak, "counts"]

        print()
        print("DCCF summary")
        print("-" * 40)
        print(f"Delta τ           : {d_tau} s")
        print(f"Peak τ            : {tau_peak:.2f} s")
        print(f"Peak CC           : {cc_peak:.3f}")
        print(f"Pairs at peak     : {M_peak:d}")
        print(f"Usable τ bins     : {len(dfv)} / {len(df)}")
        print(f"Median pairs/bin  : {int(np.median(dfv['counts']))}")
        print(f"Max pairs/bin     : {int(dfv['counts'].max())}")

        if tau_peak < 0:
            print(
                f"Interpretation    : lc1 ({lc1["id"].iloc[0]}) leads lc2 ({lc2["id"].iloc[0]}) by {abs(tau_peak):.2f} s"
            )
        elif tau_peak > 0:
            print(f"Interpretation    : lc1 lags lc2 by {tau_peak:.2f} s")
        else:
            print("Interpretation    : no measurable lag")

        if dfv["counts"].median() < 20:
            print(
                "Warning           : low pair statistics (consider rebinning or zDCF)"
            )
        return dfv
        # (end)

    def calculate_dccf(self, tau_max, d_tau, verbose=True):  # (fold)
        """
        Compute the discrete cross-correlation function (DCCF) between two
        light curves using global normalization. The function needs the maximum
        (absolute) tau that should be calculated (edges of the graph), as well
        as the tau-step provided in seconds. In case the optimal values are
        unkown, use either the interactive_dccf() function to find optimal
        values by hand or the suggest_dccf_tau_params(), to get a set of
        suggested values.
        """

        print("calculating dccf.")

        lc1 = self.lc1.dropna()
        lc2 = self.lc2.dropna()

        a = lc1["countrate"].to_numpy()
        b = lc2["countrate"].to_numpy()
        ae = lc1["countrate_error"].to_numpy()
        be = lc2["countrate_error"].to_numpy()
        ta = lc1["mjd"].to_numpy() * 86400.0
        tb = lc2["mjd"].to_numpy() * 86400.0

        if len(a) < 2 or len(b) < 2:
            raise ValueError(f"found no countrate data in one of the lcs provided")

        a = a - np.nanmean(a)
        b = b - np.nanmean(b)

        s_a2 = np.nanvar(a, ddof=1)
        s_b2 = np.nanvar(b, ddof=1)

        e_a2 = np.nanmean(ae**2)
        e_b2 = np.nanmean(be**2)

        norm = np.sqrt((s_a2 - e_a2) * (s_b2 - e_b2))
        if norm <= 0:
            norm = np.sqrt(s_a2 * s_b2)  # fallback to standard normalization


        a_vec = a[:, np.newaxis]
        b_vec = b[np.newaxis, :]
        ta_vec = ta[:, np.newaxis]
        tb_vec = tb[np.newaxis, :]

        if verbose:
            print(" ~ calculating udcf matrix")
        udcf_ij = a_vec * b_vec / norm

        if verbose:
            print(" ~ calculating dt matrix")
        dt_ij = tb_vec - ta_vec

        dt = dt_ij.ravel()
        udcf = udcf_ij.ravel()

        valid = np.isfinite(dt) & np.isfinite(udcf)
        dt = dt[valid]
        udcf = udcf[valid]

        tau_bins = np.arange(-tau_max, tau_max + d_tau, d_tau)
        tau_centers = tau_bins

        dccf, err, M = self._bin_udcf(udcf, dt, tau_bins, d_tau)

        self._dccf = pd.DataFrame(
            {
                "tau": tau_centers,
                "cc": dccf,
                "cc_err": err,
                "counts": M,
            }
        )
        df = self._dccf

        # reject less than min_pairs
        min_pairs = 5
        mask = (df["counts"] >= min_pairs) & np.isfinite(df["cc"])
        if not np.any(mask):
            raise RuntimeError("No DCCF bins pass the minimum-pairs criterion")

        # statistics
        dfv = df.loc[mask]

        i_peak = dfv["cc"].idxmax()
        tau_peak = dfv.at[i_peak, "tau"]
        cc_peak = dfv.at[i_peak, "cc"]
        M_peak = dfv.at[i_peak, "counts"]

        if verbose:
            print("DCCF summary")
            print("-" * 40)
            print(f"Delta τ           : {d_tau} s")
            print(f"Peak τ            : {tau_peak:.2f} s")
            print(f"Peak CC           : {cc_peak:.3f}")
            print(f"Pairs at peak     : {M_peak:d}")
            print(f"Usable τ bins     : {len(dfv)} / {len(df)}")
            print(f"Median pairs/bin  : {int(np.median(dfv['counts']))}")
            print(f"Max pairs/bin     : {int(dfv['counts'].max())}")

        if tau_peak < 0:
            print(
                f"Interpretation    : lc1 ({lc1["id"].iloc[0]}) is delayed wrt. lc2 ({lc2["id"].iloc[0]}) by {abs(tau_peak):.2f} s"
            )
        elif tau_peak > 0:
            print(
                f"Interpretation    : lc2 ({lc2["id"].iloc[0]}) is delayed wrt. lc1 ({lc1["id"].iloc[0]}) by {abs(tau_peak):.2f} s"
            )
        else:
            print("Interpretation    : no measurable lag")

        if dfv["counts"].median() < 20:
            print(
                "Warning           : low pair statistics (consider rebinning or zDCF)"
            )
        return dfv
        # (end)

    def interactive_dccf(  # (fold)
        self,
        tau_max_init: float | None = None,
        d_tau_init: float | None = None,
        norm: str = "global",
    ):
        """
        Interactive DCCF exploration tool.

        Allows interactive control over:
        - maximum lag |τ|max
        - lag bin width Δτ
        - normalization mode (global vs per-bin)

        Positive τ means lc2 lags lc1.
        """


        init_dict = self.suggest_dccf_tau_params(verbose=False)

        if tau_max_init is None:
            tau_max_init = init_dict.get("tau_max")  # seconds

        if d_tau_init is None:
            d_tau_init = init_dict.get("d_tau")

        def calc_dccf(tau_max, d_tau, norm):
            if norm == "global":
                df = self.calculate_dccf(
                    tau_max=tau_max,
                    d_tau=d_tau,
                )
            elif norm == "local":
                df = self.dccf_local_norm(
                    tau_max=tau_max,
                    d_tau=d_tau,
                )
            else:
                raise ValueError("unexpected norm. please use 'global' or 'local'.")

            return df

        # initialize values
        df = calc_dccf(tau_max_init, d_tau_init, norm)

        fig, ax = plt.subplots(figsize=(8, 4))
        fig.subplots_adjust(bottom=0.3)

        (line,) = ax.plot(df["tau"], df["cc"], drawstyle="steps")
        ax.set_xlabel("Lag τ [s]")
        ax.set_ylabel("Cross-correlation")
        ax.axhline(0, color="gray", lw=0.8)
        ax.grid(alpha=0.3)

        # sliders
        ax_tau = plt.axes([0.15, 0.18, 0.65, 0.03])
        ax_dt = plt.axes([0.15, 0.13, 0.65, 0.03])

        slider_tau = Slider(
            ax_tau,
            "|τ|max (s)",
            valmin=1,
            valmax=2 * tau_max_init,
            valinit=tau_max_init,
            valstep=tau_max_init / 100,
        )

        slider_dt = Slider(
            ax_dt,
            "Δτ (s)",
            valmin=1,
            valmax=2 * d_tau_init,
            valinit=d_tau_init,
            valstep=d_tau_init / 50,
        )

        ax_radio = plt.axes([0.82, 0.24, 0.14, 0.10])
        radio = RadioButtons(
            ax_radio,
            ["Global", "Local"],
            active=0 if norm == "global" else 1,
        )

        # update logic
        def refresh(val=None):
            tau_max = slider_tau.val
            d_tau = slider_dt.val
            # norm = "global" if check.get_status()[0] else "local"
            norm = radio.value_selected.lower()

            df_new = calc_dccf(
                tau_max=tau_max,
                d_tau=d_tau,
                norm=norm,
            )

            line.set_data(df_new["tau"], df_new["cc"])
            ax.set_xlim(df_new["tau"].min(), df_new["tau"].max())
            ax.relim()
            ax.autoscale_view(scaley=True)

            ax.set_title(f"DCCF ({norm} normalization)")

            fig.canvas.draw_idle()

        def on_close(event):
            tau_max_final = slider_tau.val
            d_tau_final = slider_dt.val
            norm_final = radio.value_selected.lower()

            print("Final DCCF parameters:")
            print(f"  |τ|max = {tau_max_final}")
            print(f"  Δτ     = {d_tau_final}")
            print(f"  norm   = {norm_final}")

        fig.canvas.mpl_connect("close_event", on_close)

        slider_tau.on_changed(refresh)
        slider_dt.on_changed(refresh)
        radio.on_clicked(refresh)

        plt.show()
        # (end)

    def plot_dccf(self, ax=None):  # (fold)
        """
        Plot the internally stored DCCF result.
        """

        axpassed = True
        if ax is None:
            fig, ax = plt.subplots(figsize=(10, 5))
            axpassed = False

        if self._dccf is None:
            raise RuntimeError("No DCCF result found: self._dccf is None")

        df = self.dccf

        required = {"tau", "cc", "counts"}
        missing = required - set(df.columns)
        if missing:
            raise RuntimeError(f"DCCF DataFrame missing columns: {missing}")

        tau = df["tau"].to_numpy()
        cc = df["cc"].to_numpy()
        err = df["cc_err"].to_numpy() if "cc_err" in df else None

        ax.plot(tau, cc, lw=1.8, label="DCCF")

        if err is not None and np.any(np.isfinite(err)):
            ax.fill_between(
                tau,
                cc - err,
                cc + err,
                alpha=0.3,
                label="1σ",
            )

        ax.axhline(0.0, ls="--", lw=1)
        ax.set_xlabel("Lag τ [s]")
        ax.set_ylabel("Cross-correlation")
        ax.set_title("Discrete Cross-Correlation Function")
        ax.legend()
        ax.grid(True)

        plt.tight_layout()
        if not axpassed:
            plt.show()
        else:
            return ax
            # (end)

    def plot_lc(  # (fold)
        self, lc1: bool = True, lc2: bool = True, gti: bool = False, ax=None
    ):
        """
        Plot one or both of the lightcurves in their current state*. Optionally
        plot the GTIs as orange regions. An ax object can be passed in case the
        user whishes to embed the graph in a larger figure.

        (*When using rebin_lightcurves() or select_good_time() before calling
        this function, the changes made by these functions will be visible in
        the graph. If you whish to compare the lcs before and after, you can
        call this function twice.)
        """

        axpassed = True
        if ax is None:
            fig, ax = plt.subplots(figsize=(10, 5))
            axpassed = False
        if lc1:
            df = self.lc1
            ax.errorbar(
                df["mjd"],
                df["countrate"],
                yerr=df["countrate_error"],
                label=df["id"].iloc[0],
                fmt=".",
                alpha=0.5,
            )
        if lc2:
            df = self.lc2
            ax.errorbar(
                df["mjd"],
                df["countrate"],
                yerr=df["countrate_error"],
                label=df["id"].iloc[0],
                fmt=".",
                alpha=0.5,
            )
        if gti and hasattr(self, "gti"):
            for i, (start, stop) in enumerate(self.gti):
                plt.axvspan(
                    start,
                    stop,
                    color="orange",
                    alpha=0.3,
                    label="GTI" if i == 0 else "_nolegend_",
                )
        ax.set_xlabel("Time [mjd]")
        ax.set_ylabel("Count Rate [events/s]")
        ax.legend()

        if not axpassed:
            plt.show()
        else:
            return fig, ax
            # (end)

    def suggest_dccf_tau_params(self, min_pairs_target=20, verbose=True):  # (fold)
        """
        Inspect lc1 / lc2 sampling and GTI if provided and prints suggested
        DCCF tau parameters. Can be given min_pairs_target (target amount of
        pairs that exist per tau bin).
        Returns results in a dict:
        suggested_values = {
            "d_tau": d_tau,
            "tau_max": tau_max,
            "tau_range": (-tau_max, tau_max),
            "estimated_pairs_per_bin": expected_pairs_per_bin,
        }
        """

        SEC_PER_DAY = 86400.0
        time_col = "mjd"

        lc1 = self.lc1
        lc2 = self.lc2

        if lc1 is None or lc2 is None:
            raise RuntimeError("Both lightcurves must be loaded before calling this.")

        # seconds
        t1 = np.sort(lc1[time_col].to_numpy()) * SEC_PER_DAY
        t2 = np.sort(lc2[time_col].to_numpy()) * SEC_PER_DAY

        if len(t1) < 2 or len(t2) < 2:
            raise ValueError("Not enough data points in one of the lightcurves.")

        dt1 = np.diff(t1)
        dt2 = np.diff(t2)

        med_dt1 = np.median(dt1)
        med_dt2 = np.median(dt2)

        d_tau = max(med_dt1, med_dt2)

        if self._gti is not None:
            gti_sec = np.asarray(self.gti) * SEC_PER_DAY
            gti_lengths = gti_sec[:, 1] - gti_sec[:, 0]
            t_len = np.median(gti_lengths)
            source = "GTI median length"
            tau_max = 0.5 * np.median(gti_lengths)
        else:
            t_start = max(t1.min(), t2.min())
            t_end = min(t1.max(), t2.max())
            t_len = t_end - t_start
            source = "full overlap length"
            tau_max = 0.5 * t_len

        expected_pairs_per_bin = (len(t1) * len(t2)) * (d_tau / (2 * tau_max))

        if expected_pairs_per_bin < min_pairs_target:
            tau_max *= expected_pairs_per_bin / min_pairs_target

        tau_max = max(tau_max, d_tau)

        if verbose:
            print("\nDCCF τ-parameter suggestion")
            print("-" * 40)
            print(f"LC1 median cadence     : {med_dt1:.2f} s")
            print(f"LC2 median cadence     : {med_dt2:.2f} s")
            print(f"Suggested Δτ           : {d_tau:.2f} s")
            print(f"Typical segment length : {t_len:.1f} s ({source})")
            print(f"Suggested τ_max        : {tau_max:.1f} s")
            print(f"Suggested τ range      : [{-tau_max:.1f}, {tau_max:.1f}] s")
            print(f"Estimated pairs / bin  : {expected_pairs_per_bin:.1f}")
            print("-" * 40)

        return {
            "d_tau": d_tau,
            "tau_max": tau_max,
            "tau_range": (-tau_max, tau_max),
            "estimated_pairs_per_bin": expected_pairs_per_bin,
        }


# (end)
