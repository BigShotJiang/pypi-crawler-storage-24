import numpy as np
import pandas as pd
from astropy.io import fits


def extract_lightcurve(path, gti: np.ndarray | None = None) -> pd.DataFrame:
    """
    Extracts the lightcurve from a TESS fits file.
    """
    with fits.open(path) as hdul:
        evt = hdul["LIGHTCURVE"].data
        hdr = hdul["LIGHTCURVE"].header

        bjd = evt["TIME"]

        flux = evt["PDCSAP_FLUX"]
        flux_err = evt["PDCSAP_FLUX_ERR"]
        qlty = evt["QUALITY"]

    # drop bad events (quality != 0):
    mask = qlty == 0

    flux = flux[mask]
    flux_err = flux_err[mask]
    bjd = bjd[mask]

    mjdrefi = hdr["BJDREFI"]
    mjdreff = hdr["BJDREFF"]

    mjd = bjd + mjdrefi + mjdreff - 2400000.5

    df = pd.DataFrame(
        {
            "mjd": mjd.astype(np.float64),
            "countrate": flux.astype(np.float64),
            "countrate_error": flux_err.astype(np.float64),
        }
    )

    if gti is not None:
        t = df["mjd"].values
        inside = np.zeros(len(t), dtype=bool)
        for start, stop in gti:
            inside |= (t >= start) & (t <= stop)

        df = df[inside].reset_index(drop=True)

    return df
