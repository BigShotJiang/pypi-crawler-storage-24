from ctypes import ArgumentError
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from astropy.io import fits


def read_evt_mjd(path: str, evt_hdu: str = "EVENTS") -> np.ndarray:  # (fold)
    """
    Extracts mjd-time of all photon events from a fits file at path

    Returns
    -------
    numpy.ndarray
        1D array containing event times in mjd format
    """
    with fits.open(path) as hdul:
        evt = hdul[evt_hdu].data
        hdr = hdul[evt_hdu].header

    mjdref = hdr["MJDREF"]
    time = evt["TIME"]
    time_mjd = mjdref + time / 86400.0  # sec -> day

    return time_mjd
    # (end)


def read_evt_med(path: str, evt_hdu: str = "EVENTS") -> np.ndarray:  # (fold)
    """
    Extracts met-time (seconds) of all photon events from a fits file at path

    Returns
    -------
    numpy.ndarray
        1D array containing event times in met format
    """
    with fits.open(path) as hdul:
        evt = hdul[evt_hdu].data

    time = evt["TIME"]

    return time
    # (end)


def read_lc(lc_path:str) -> pd.DataFrame: # (fold)
    """
    Extract lightcurve data from a FITS file.

    Returns
    -------
    pd.DataFrame
        Columns:
        - "t" : time (seconds)
        - "mjd" : time in MJD
        - "countrate" : count rate
        - "countrate_error" : count rate error
    """
    with fits.open(lc_path) as hdul:
        lc = hdul["RATE"].data
        hdr = hdul["RATE"].header

        t = lc["TIME"].astype(float)
        cr = lc["RATE"].astype(float)
        cr_err = lc["ERROR"].astype(float)

        t_start = hdr["TSTART"]
        mjd_ref = hdr["MJDREF"]

        mjd = mjd_ref + (t_start + t) / 86400

        return pd.DataFrame(
            {
                "t": t + t_start,
                "mjd": mjd,
                "countrate": cr,
                "countrate_error": cr_err,
            }
        ) # (end)


def read_rmf_ebounds(rmf_path) -> pd.DataFrame:  # (fold)
    """
    Extracts the energy boundaries for each detector channel from the rmf-fits
    file at rmf_path

    Returns
    -------
    pd.DataFrame
        Columns:
        - "channel" : int
        - "energy"  : float (in keV)
        - "e_lo"    : float
        - "e_hi"    : float
    """
    with fits.open(rmf_path) as hdul:
        ebounds = hdul["EBOUNDS"].data
        channel = ebounds["CHANNEL"]
        e_min = ebounds["E_MIN"]
        e_max = ebounds["E_MAX"]

    e_center = 0.5 * (e_min + e_max)

    df = pd.DataFrame(
        {
            "channel": np.array(channel).astype(int),
            "energy": np.array(e_center).astype(float),
            "e_lo": np.array(e_min).astype(float),
            "e_hi": np.array(e_max).astype(float),
        }
    )

    return df  # (end)


def extract_spectrum( # (fold)
    spec_path,
    bckgrnd_path="",
    arf_path="",
    rmf_path="",
    model=False,
    plot=False
    ) -> pd.DataFrame:
    """
    Extract spectrum and optionally apply background correction and response.

    Returns
    -------
    pd.DataFrame
        Columns:
        - "channel" : detector channel
        - "cr_raw" : raw count rate
        - "cr_bck_corr" : background-corrected count rate (if available)
        - "energy" : energy (if rmf provided without model)
    """
    final_df = pd.DataFrame()
    with fits.open(spec_path) as hdul:
        spec = hdul["SPECTRUM"].data
        hd_s = hdul["SPECTRUM"].header

        counts_spec = spec["COUNTS"]
        channels = spec["CHANNEL"]
        expo_spec = hd_s["EXPOSURE"]

        cr_spec = counts_spec / expo_spec

        final_df["cr_raw"] = cr_spec
        final_df["channel"] = channels

    if bckgrnd_path != "":
        with fits.open(bckgrnd_path) as hdul:
            back = hdul["SPECTRUM"].data
            hd_b = hdul["SPECTRUM"].header

            counts_back = back["COUNTS"]
            expo_back = hd_b["EXPOSURE"]

            cr_back = counts_back / expo_back

            cr_b_corr = counts_spec / expo_spec - counts_back / expo_back

            final_df["cr_bck_corr"] = cr_b_corr

    if model:
        if rmf_path != "":
            with fits.open(rmf_path) as hdul:
                ebounds = hdul["EBOUNDS"].data
                matrix = hdul["MATRIX"].data

            n_energy = len(matrix)
            n_channels = len(ebounds)

            e_lo = matrix["ENERG_LO"]
            e_hi = matrix["ENERG_HI"]

            # decompress rmf matrix
            R = np.zeros((n_energy, n_channels), dtype=np.float32)

            for i, row in enumerate(matrix):
                n_grp = row["N_GRP"]
                f_chan = np.atleast_1d(row["F_CHAN"])  # ensure array
                n_chan = np.atleast_1d(row["N_CHAN"])
                vals = row["MATRIX"]

                offset = 0
                for g in range(n_grp):
                    start = f_chan[g] - 1  # FITS uses 1-based indexing
                    end = start + n_chan[g]
                    R[i, start:end] = vals[offset : offset + n_chan[g]]
                    offset += n_chan[g]

            # PLOT RMF(fold)
            # plt.imshow(R, origin="lower", aspect="auto",
            #            extent=[0, n_channels, 0, n_energy])
            # plt.xlabel("Channel")
            # plt.ylabel("Energy bin")
            # plt.title("Redistribution Matrix (RMF)")
            # plt.colorbar(label="Response probability")
            # plt.show()(end)

            if arf_path != "":
                with fits.open(arf_path) as hdul:
                    arf = hdul["SPECRESP"].data

                energy_lo = arf["ENERG_LO"]
                energy_hi = arf["ENERG_HI"]
                eff_area = arf["SPECRESP"]

                # PLOT EFF AREA(fold)
                # energy_mid = 0.5 * (energy_lo + energy_hi)
                # plt.figure(figsize=(7, 4))
                # plt.plot(energy_mid, area, lw=1.2)
                # plt.xlabel("Energy (keV)")
                # plt.ylabel("Effective Area (cm²)")
                # plt.title("Auxiliary Response (ARF)")
                # plt.grid(alpha=0.3)
                # plt.tight_layout()
                # plt.show()(end)

                # combine eff_area and rmf
                R_full = R * eff_area[:, np.newaxis]

                # PLOT EFF AREA + RESPONSE(fold)
            # plt.imshow(R_full, origin="lower", aspect="auto", extent=[0, n_channels, 0, n_energy])
            # plt.xlabel("Channel")
            # plt.ylabel("Energy bin")
            # plt.title("Full Response (ARF × RMF)")
            # plt.colorbar(label="Effective response")
            # plt.show()(end)

    else:
        if rmf_path != "":
            with fits.open(rmf_path) as hdul:
                ebounds = hdul["EBOUNDS"].data

            ch = ebounds["CHANNEL"]
            e_lo = ebounds["E_MIN"]
            e_hi = ebounds["E_MAX"]

            e_mid = 0.5 * (e_lo + e_hi)

            final_df["energy"] = e_mid

            # ch_min, ch_max = 20, 200
            #
            # ch_start = spec["CHANNEL"][0]  # e.g. 1
            # e_mid_cut = e_mid[(20 - ch_start) : (200 - ch_start + 1)]
            # counts_cut = cr_spec[(20 - ch_start) : (200 - ch_start + 1)]

            if plot:

                plt.figure()
                sns.set_style("whitegrid")
                plt.step(e_mid_cut, counts_cut, where="mid", label="countrate")

                if bckgrnd_path != "":
                    bckgnd_cut = cr_back[(20 - ch_start) : (200 - ch_start + 1)]
                    corr_cut = cr_b_corr[(20 - ch_start) : (200 - ch_start + 1)]
                    plt.step(e_mid_cut, bckgnd_cut, where="mid", label="background")
                    plt.step(e_mid_cut, corr_cut, where="mid", label="corrected")

                plt.xlabel("Energy (keV)")
                plt.ylabel("Counts")
                # plt.xscale("log")   # optional
                # plt.yscale("log")   # optional
                plt.title("observed spectrum vs. energy")
                plt.show()

    def p():
        plt.figure(figsize=(8, 5))

        plt.step(channels[20:200], cr_spec[20:200], where="mid")
        if bckgrnd_path != "":
            plt.step(channels[20:200], cr_back[20:200], where="mid")
            plt.step(channels[20:200], cr_b_corr[20:200], where="mid")

        plt.xlabel("PI channel")
        plt.ylabel("Counts")
        plt.title("Spectrum")
        plt.grid(True)
        plt.legend()
        plt.show()

    if plot:
        # p()
        pass

    return final_df


# (end)


def read_mjd_channel(path: str) -> pd.DataFrame:  # (fold)
    """
    Extracts mjd-time and channel of all photon events from a fits file at path

    Returns
    -------
    pd.DataFrame
        Columns:
        - "mjd" : float
        - "channel" : int
    """
    with fits.open(path) as hdul:
        evt = hdul["EVENTS"].data
        hdr = hdul["EVENTS"].header

        mjdref = hdr.get("MJDREFI", 0) + hdr.get("MJDREFF", 0.0)
        time = evt["TIME"]
        channel = evt["PIch1"]

    time_mjd = mjdref + time / 86400.0  # seconds → days

    df = pd.DataFrame(
        {
            "mjd": np.array(time_mjd).astype(float),
            "channel": np.array(channel).astype(int),
        }
    )

    return df  # (end)


def read_med_channel(path: str) -> pd.DataFrame:  # (fold)
    """
    Extracts mission-time (med) (in seconds) and channel info of all photon
    events from a fits file at path

    Returns
    -------
    pd.DataFrame
        Columns:
        - "med" : float
        - "channel" : int
    """
    with fits.open(path) as hdul:
        evt = hdul["EVENTS"].data
        hdr = hdul["EVENTS"].header

        time = evt["TIME"]
        channel = evt["PIch1"]

    df = pd.DataFrame(
        {
            "med": np.array(time).astype(float),
            "channel": np.array(channel).astype(int),
        }
    )
    print("TODO: add mission start time as reference")

    return df  # (end)


def read_stdgti_mjd(path: str) -> np.ndarray:  # (fold)
    """
    Extracts the gti (good-time-intervals) im mjd-format
    from the fits file at path.

    Returns
    -------
    numpy.ndarray
        2D array of shape (N, 2)
        - Column 0: start times
        - Column 1: stop times
    """
    with fits.open(path) as hdul:
        gti = hdul["STDGTI"]

        mjdref = gti.header["MJDREF"]

        start = np.array(gti.data["START"])
        stop = np.array(gti.data["STOP"])

        intervals = np.column_stack((start, stop))
        mjd_intervals = intervals / (60 * 60 * 24) + mjdref

        return mjd_intervals
        # (end)


def read_stdgti_med(path: str) -> np.ndarray:  # (fold)
    """
    Extracts the gti (good-time-intervals) im met-format (sec)
    from the fits file at path.

    Returns
    -------
    numpy.ndarray
        2D array of shape (N, 2)
        - Column 0: start times
        - Column 1: stop times
    """
    with fits.open(path) as hdul:
        gti = hdul["STDGTI"]

        start = np.array(gti.data["START"])
        stop = np.array(gti.data["STOP"])

        intervals = np.column_stack((start, stop))

        return intervals
    # (end)


def select_good_time(time: np.ndarray, gti: np.ndarray) -> np.ndarray:  # (fold)
    """
    Extract event-times that lie inside the good-time-intervals.

    Returns
    -------
    numpy.ndarray
        Boolean mask selecting valid times
    """
    mask = np.zeros(len(time), dtype=bool)
    for start, stop in gti:
        mask |= (time >= start) & (time <= stop)

    return mask


# (end)


def refine_gti( # (fold)
    evt_times: np.ndarray,
    gti_array: np.ndarray,
) -> np.ndarray:
    """
    Refine GTIs by removing leading/trailing zero-count regions.

    Returns
    -------
    np.ndarray
        Refined GTI array
    """
    new_gtis = []

        for start, stop in gti_array:
            # Select events in this GTI
            mask = (evt_times >= start) & (evt_times <= stop)
            times = evt_times[mask]

            if len(times) == 0:
                continue  # skip empty GTIs

            new_start = times.min()
            new_stop = times.max()
            new_gtis.append((new_start, new_stop))

    return np.array(new_gtis) # (end)


def make_time_bins(  # (fold)
    binsize: float,
    mission_tstart: float,
    evt_times: np.ndarray | None = None,
    t_start: float | None = None,
    t_stop: float | None = None,
    ) -> np.ndarray:
    """
    Create globally aligned time-bin edges anchored to mission_tstart.

    Reproduces the default binning behavior of xselect.
    """
    t_start = mission_tstart

    if evt_times is not None:
        t_start = evt_times.min()
        t_stop = evt_times.max()

    if t_stop is None or t_start is None:
        raise ArgumentError(
            "Missing t_start or t_stop! Please provide one of the following: t_start and t_stop or evt_times"
        )

    n_start = int(np.floor((t_start - mission_tstart) / binsize))
    n_stop = int(np.floor((t_stop - mission_tstart) / binsize))
    bins = mission_tstart + np.arange(n_start, n_stop) * binsize

    return bins
    # (end)


def read_observation_start_stop(fits_path: str) -> Tuple[float, float]:  # (fold)
    """
    Extract TSTART and TSTOP from a FITS file.

    Priority:
    1) EVENTS extension header (if present)
    2) Primary header

    Returns
    -------
    (tstart, tstop) : tuple of float
    """
    with fits.open(fits_path) as hdul:
        primary = hdul[0].header
        mjdref = primary["MJDREF"]

        t_start = primary["TSTART"] / 86400 + mjdref
        t_stop = primary["TSTOP"] / 86400 + mjdref

        return t_start, t_stop

    raise KeyError("TSTART/TSTOP not found in FITS file")
    # (end)


def compute_exposure_rel(  # (fold)
    bins: np.ndarray,
    gti: np.ndarray,
) -> np.ndarray:
    """
    Compute relative exposure per bin (0..1).

    Returns
    -------
    np.ndarray
        Relative exposure per bin
    """

    bin_left = bins[:-1]
    bin_right = bins[1:]
    bin_width = bin_right - bin_left

    exposure = np.zeros_like(bin_left, dtype=float)

    for start, stop in gti:
        overlap = np.minimum(bin_right, stop) - np.maximum(bin_left, start)
        overlap = np.clip(overlap, 0.0, None)
        exposure += overlap

    # normalize to fraction of bin
    exposure /= bin_width

    # numerical safety
    exposure = np.clip(exposure, 0.0, 1.0)

    return exposure
    # (end)


def compute_exposure(# (fold)
	bins: np.ndarray,
	gti: np.ndarray,
) -> np.ndarray:
    """
    Compute absolute exposure time per bin (in seconds).

    Returns
    -------
    np.ndarray
        Exposure time per bin (seconds)
    """

	bin_left = bins[:-1]
	bin_right = bins[1:]

	exposure = np.zeros_like(bin_left, dtype=float)

	for start, stop in gti:
		overlap = np.minimum(bin_right, stop) - np.maximum(bin_left, start)
		overlap = np.clip(overlap, 0.0, None)
		exposure += overlap

	# convert days → seconds
	exposure *= 86400.0

	return exposure# (end)


def extract_lc_mjd( # (fold)
    evt_times: np.ndarray,
    bins: np.ndarray,
    gti: np.ndarray | None = None,
    keep_zero_countrate=False,
    tolerance: float | None = 0.85
) -> pd.DataFrame:
    """
    Extract lightcurve by binning event times in MJD.

    Returns
    -------
    pd.DataFrame
        Columns:
        - "mjd" : bin centers
        - "countrate" : count rate
        - "countrate_error" : Poisson error
    """

    binsize_day = float(np.mean(np.diff(bins)))
    binsize_sec = binsize_day * 86400

    counts, edges = np.histogram(evt_times, bins=bins)

    bin_centers = 0.5 * (edges[:-1] + edges[1:])
    # bin_centers = edges[:-1]

    if gti is not None:
        exposure = compute_exposure(bins, gti) 
        
        # mask = exposure > (tolerance * binsize_sec)
        mask = exposure >= tolerance * binsize_sec
        exposure = exposure[mask]
        counts = counts[mask]
        bin_centers = bin_centers[mask]

        rate = counts / exposure
        rate_err = np.sqrt(counts) / exposure

    else: 
        rate = counts / binsize_sec
        rate_err = np.sqrt(counts) / binsize_sec

    lc = pd.DataFrame({
        "mjd": bin_centers,
        "countrate": rate,
        "countrate_error": rate_err
    })

    if keep_zero_countrate:
        return lc

    return lc.loc[lc["countrate"] != 0] # (end)


def rebin_lightcurve(df, binsize_sec): # (fold)
    """
    Rebin a lightcurve to a new binsize.

    Returns
    -------
    pd.DataFrame
        Rebinned lightcurve with same columns
    """
    t_sec = (df["mjd"] - df["mjd"].iloc[0]) * 86400.0

    # Original counts per bin (assuming cr = counts/sec)
    dt_orig = np.median(np.diff(t_sec))  # original bin width in seconds
    counts = df["countrate"] * dt_orig
    counts_err = df["countrate_error"] * dt_orig

    # Determine new bin edges
    t_start = t_sec[0]
    t_stop = t_sec.iloc[-1] + dt_orig
    nbins = int(np.ceil((t_stop - t_start) / binsize_sec))
    bin_edges = t_start + np.arange(nbins + 1) * binsize_sec

    # Digitize original times into bins
    bin_idx = np.digitize(t_sec, bin_edges) - 1  # 0-based

    rebinned_mjd = []
    rebinned_cr = []
    rebinned_err = []

    for i in range(nbins):
        mask = bin_idx == i
        if not np.any(mask):
            continue
        counts_sum = counts[mask].sum()
        err_sum = np.sqrt((counts_err[mask] ** 2).sum())
        rebinned_mjd.append(df["mjd"].iloc[mask].mean())
        rebinned_cr.append(counts_sum / binsize_sec)
        rebinned_err.append(err_sum / binsize_sec)

    rebinned_df = pd.DataFrame(
        {"mjd": rebinned_mjd, "countrate": rebinned_cr, "countrate_error": rebinned_err}
    )

    return rebinned_df # (end)


### DEPRECATED

def extract_lightcurve(  # (fold)
    evt_times: np.ndarray,
    mission_tstart: float | None = None,
    binsize_sec: float | None = None,
    bin_array_mjd: np.ndarray | None = None,
    gti: np.ndarray | None = None,
    drop_exposure_smaller_than: float | None = None,
    keep_zero_countrate=False,
):
    """
    DEPRECATED! Use extract_lc_mjd instead.
    Compute count_rate and poisson error for event times, by binning the whole time axis.
    Can be given a a gti-array, shape (N,2). Then, target exposure is calculated from the gti and
    the count rate is calculated from exposure instead of binsize.
    Results are returned as a DataFrame

    Returns
    -------
    pd.DataFrame
        Columns:
        - "mjd"   : time-centers of bins (mjd)
        - "countrate"  : count rate inside each bin
        - "countrate_error" : Poisson error of the count rate
    """
    if bin_array_mjd is not None:
        if binsize_sec is None:
            binsize_day = float(np.mean(np.diff(bin_array_mjd)))
            binsize_sec = binsize_day * 86400
        else:
            binsize_day = binsize_sec / 86400

        half_bin = binsize_day / 2
        bins = bin_array_mjd + half_bin

    elif binsize_sec is not None:
        if mission_tstart is None:
            raise ArgumentError(
                "No mission_tstart time provided. If no explicit bin array is provided, the mission_tstart time is necessary to create an appropriate bin array."
            )
        binsize_day = binsize_sec / 86400

        if gti is not None:
            bins = make_time_bins(binsize_day, mission_tstart, gti=gti)
        else:
            bins = make_time_bins(
                binsize_day,
                mission_tstart,
                t_start=evt_times.min(),
                t_stop=evt_times.max(),
            )
    else:
        raise ArgumentError(
            "Neither bin array nor binsize were passed. Please pass one of these."
        )

    bin_centers = 0.5 * (bins[:-1] + bins[1:]) - binsize_day / 2
    counts, _ = np.histogram(evt_times, bins=bins)

    if gti is not None:
        exposure = compute_exposure(bins, gti)

        eff_time = exposure * binsize_sec

        rate = np.divide(
            counts,
            eff_time,
            out=np.full_like(counts, np.nan, dtype=float),
            where=eff_time > 0,
        )

        rate_err = np.divide(
            np.sqrt(counts),
            eff_time,
            out=np.full_like(counts, np.nan, dtype=float),
            where=eff_time > 0,
        )

        lc = pd.DataFrame(
            {
                "mjd": bin_centers,
                "countrate": rate,
                "countrate_error": rate_err,
                "exposure": exposure,
            }
        )

        if drop_exposure_smaller_than is not None:
            if not (0.0 < drop_exposure_smaller_than <= 1.0):
                raise ValueError(
                    f"drop_exposure_smaller_than must be in (0, 1], got {drop_exposure_smaller_than}"
                )

            valid = exposure >= drop_exposure_smaller_than
            lc.loc[~valid, ["countrate", "countrate_error"]] = np.nan

    else:
        rate = counts / binsize_sec
        rate_err = np.sqrt(counts) / binsize_sec

        lc = pd.DataFrame(
            {"mjd": bin_centers, "countrate": rate, "countrate_error": rate_err}
        )

    if keep_zero_countrate:
        return lc

    return lc.loc[lc["countrate"] != 0]

    # (end)


def bin_lightcurve_old(  # (fold)
    evt_times: np.ndarray, binsize_sec: int, gti: np.ndarray | None = None
) -> pd.DataFrame:
    """
    DEPRECATED! Use extract_lc_mjd() instead.
    Compute count_rate and poisson error for event times.
    Can be given a a gti-array, shape (N,2), to select only gti-valid events.
    Pack the results into a pandas DataFrame.

    Returns
    -------
    pd.DataFrame
        Columns:
        - "t"   : time-centers of bins
        - "cr"  : count rate inside each bin
        - "err" : Poisson error of the count rate
    """
    binsize_day = binsize_sec / 86400

    if gti is not None:
        mask = select_good_time(evt_times, gti)
        good_mjd = evt_times[mask]
        print(
            f"Total events: {len(evt_times)}, Inside GTI: {len(good_mjd)} ({(len(good_mjd)/len(evt_times) * 100):.0f}%)"
        )
        mjd = good_mjd

        bins = bin_gti(gti, binsize_day)

        durations = gti[:, 1] - gti[:, 0]
        print(f"Total good time: {durations.sum()}")
        print(f"Average gti-size: {durations.sum()/len(gti)}")
        print(f"expected amount of bins in gti: {durations.sum()/len(gti)/binsize_day}")

    else:
        mjd = evt_times
        t_min, t_max = mjd.min(), mjd.max()
        bins = np.arange(t_min, t_max + binsize_day, binsize_day)

    # NOTE: np.histogram() doesn't know about the gti, so it also counts
    # inbeween the gti. This is not gave however, since we omitted all counts
    # outside the gti, so the counts there will just total to zero and can be
    # masked easily.
    counts, edges = np.histogram(mjd, bins=bins)
    mjd_center = 0.5 * (edges[1:] + edges[:-1])

    # handle uneven bins (in case of gti)
    bin_widths = np.diff(edges)
    bin_widths_sec = bin_widths * 86400

    # mask zero-events ()
    mask_zero = counts > 0
    counts = counts[mask_zero]
    bin_widths_sec = bin_widths_sec[mask_zero]
    mjd_center = mjd_center[mask_zero]

    rate = counts / bin_widths_sec
    rate_err = np.sqrt(counts) / bin_widths_sec

    df = pd.DataFrame({"t": mjd_center, "cr": rate, "err": rate_err}).astype(float)
    return df  # (end)


def bin_lightcurve(  # (fold)
    evt_times: np.ndarray,
    binsize_sec: float,
    mission_tstart: float | None = None,
    gti: np.ndarray | None = None,
):
    """
    DEPRECATED! Use extract_lc_mjd() instead.
    Compute count_rate and poisson error for event times, by binning the whole time axis.
    Can be given a a gti-array, shape (N,2). Then, target exposure is calculated from the gti and
    the count rate is calculated from exposure instead of binsize.
    Results are returned as a DataFrame

    Returns
    -------
    pd.DataFrame
        Columns:
        - "mjd"   : time-centers of bins (in MJD)
        - "countrate"  : count rate inside each bin
        - "countrate_error" : Poisson error of the count rate
    """
    if mission_tstart is None:
        obs_start = evt_times.min()
    else:
        obs_start = mission_tstart

    binsize_day = binsize_sec / 86400

    if gti is not None:
        bins = make_time_bins(binsize_day, mission_tstart=obs_start, gti=gti)
    else:
        t_start = evt_times.min()
        t_stop = evt_times.max()
        bins = make_time_bins(
            binsize_day, mission_tstart=obs_start, t_start=t_start, t_stop=t_stop
        )

    bin_centers = 0.5 * (bins[:-1] + bins[1:])
    counts, _ = np.histogram(evt_times, bins=bins)

    if gti is not None:
        exposure = compute_exposure(bins, gti)

        rate = np.divide(
            counts,
            exposure,
            out=np.full_like(counts, np.nan, dtype=float),
            where=exposure > 0,
        )
        rate_err = np.divide(
            np.sqrt(counts),
            exposure,
            out=np.full_like(counts, np.nan, dtype=float),
            where=exposure > 0,
        )

        lc = pd.DataFrame(
            {
                "mjd": bin_centers,
                "countrate": rate,
                "countrate_error": rate_err,
                "exposure": exposure,
            }
        )

    else:
        rate = counts / binsize_sec
        rate_err = np.sqrt(counts) / binsize_sec

        lc = pd.DataFrame(
            {"mjd": bin_centers, "countrate": rate, "countrate_error": rate_err}
        )

    return lc

    # (end)


def shrink_gti(gti: ndarray, percent: float = 0.05) -> np.ndarray:  # (fold)
    """
    DEPRECATED! (used in the passt for testing)
    Takes a gti array and shrinks each interval by a given percentage.
    """
    new_start = []
    new_stop = []
    for start, stop in gti:
        reduce = (stop - start) * percent
        new_start.append(start + reduce)
        new_stop.append(stop - reduce)

    return np.column_stack((new_start, new_stop))
    # (end)


def trim_lc_edges_per_gti(  # (fold)
    lc: pd.DataFrame,
    gti: np.ndarray,
    n: int,
    time_col: str = "mjd",
) -> pd.DataFrame:
    """
    DEPRECATED! Use refine_gti instead!
    Remove exactly `n` bins from start and end inside each GTI.
    """

    if n <= 0:
        return lc.copy()

    mask = np.zeros(len(lc), dtype=bool)
    times = lc[time_col].values

    for start, stop in gti:
        idx = np.where((times >= start) & (times < stop))[0]

        if len(idx) > 2 * n:
            # keep the middle bins, drop n from each side
            mask[idx[n:-n]] = True
        # if len(idx) <= 2*n, all points are dropped (mask remains False)

    return lc.loc[mask].reset_index(drop=True)
    # (end)


def plot_med_lightcurve(df, t_start=None, t_stop=None, ax=None):  # (fold)
    """
    Plot lightcurve in mission elapsed time (MET).

    Returns
    -------
    matplotlib.axes.Axes or None
    """
    noax = False
    if t_start:
        if t_start >= df["t"].min():
            df = df[df["t"] >= t_start]

    if t_stop:
        if t_stop <= df["t"].max():
            df = df[df["t"] <= t_stop]

    if ax is None:
        noax = True
        fig, ax = plt.subplots(figsize=(8, 4))

    sns.lineplot(data=df)
    ax.set_ylabel("Counts [s]")
    ax.set_xlabel("Time [met]")

    if noax:
        plt.show()
    else:
        return ax
# (end)


def set_colorbands(df: pd.DataFrame, colorbands: dict) -> pd.DataFrame:  # (fold)
    """
    Load a colorbands dict and apply it to the df provieded.
    Df needs "energy" col.
    Expected format:
    colorbands = {
        "soft": (lower:float, higher:float),
        "med": (lower:float, higher:float),
        "hard": (lower:float, higher:float),
    }
    """
    missing = {"soft", "hard", "med"} - colorbands.keys()
    if missing:
        raise ValueError(f"The provided colorbands-dict has missing items: {missing}")
    df["colorband"] = pd.NA
    for name, (e_lo, e_hi) in colorbands.items():
        mask = (df["energy"] > e_lo) & (df["energy"] <= e_hi)
        df.loc[mask, "colorband"] = name
    return df  # (end)


### TESTING

def housekeeping_gti(housekeeping_path): # (fold)
    """
    Load and combine GTIs from housekeeping files in a directory.

    Returns
    -------
    np.ndarray
        Combined GTI array of shape (N, 2)
    """

    path = Path(housekeeping_path)
    gti = []

    for file in sorted(path.glob("*.gti")):
        with fits.open(file) as hdul:
            gti_table = hdul["GTI"].data
            starts = gti_table["START"]
            stops = gti_table["STOP"]

            gti.append(np.column_stack((starts, stops)))

    if not gti:
        raise RuntimeError(f"No GTI files found in {path}")

    return np.vstack(gti) # (end)


def gti_intersection(gti1: np.ndarray, gti2: np.ndarray) -> np.ndarray: # (fold)
    """
    Compute the strict intersection of two GTI arrays.

    Parameters
    ----------
    gti1, gti2 : np.ndarray, shape (N,2)
        Arrays of GTIs: each row = [start, stop]

    Returns
    -------
    gti_out : np.ndarray, shape (M,2)
        New GTI array containing only times valid in both inputs.
    """
    result = []

    # sort GTIs just in case
    gti1 = gti1[np.argsort(gti1[:, 0])]
    gti2 = gti2[np.argsort(gti2[:, 0])]

    i, j = 0, 0
    while i < len(gti1) and j < len(gti2):
        start1, stop1 = gti1[i]
        start2, stop2 = gti2[j]

        # find overlap
        start_overlap = max(start1, start2)
        stop_overlap = min(stop1, stop2)

        if start_overlap < stop_overlap:
            result.append([start_overlap, stop_overlap])

        # advance the GTI that ends first
        if stop1 < stop2:
            i += 1
        else:
            j += 1

    if result:
        return np.array(result, dtype=float)
    else:
        return np.zeros((0, 2), dtype=float) # (end)
