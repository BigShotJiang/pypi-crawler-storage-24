import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns


def read(fname: str, colmap: dict, verbose=False) -> pd.DataFrame:

    with open(fname, "r") as f:
        lines = f.readlines()

    # To skip header, find first data-row
    data_start = 0
    for i, line in enumerate(lines):
        # Skip comment, QDP commands, and blank lines
        if line.startswith("!") and lines[i + 1].startswith("!"):
            data_start = i + 2

    # Read data from that line onward
    df = pd.read_csv(
        fname,
        sep=r"\s+",
        comment="!",
        skiprows=data_start,
        header=None,
    )

    df = df.iloc[:-1].astype(float)

    df.columns = colmap2header(colmap)

    if verbose:
        print(df)
    return df


def colmap2header(colmap):
    columns = [key for key, val in colmap.items() if isinstance(val, int)]
    columns.remove("n_bands")
    return sorted(columns, key=lambda k: colmap[k])


def get_binsize(df):
    if df.shape[0] < 2:
        raise ValueError("DataFrame must have at least 2 rows to calculate binsize.")

    time = df.iloc[:, 0].values
    binsize = time[1] - time[0]
    if time[1] + binsize == time[2]:
        return binsize
    else:
        raise ValueError




def plot_lightcurve_df(df):
    """
    Quick-look plot for a lightcurve DataFrame.

    Requires columns:
            'mjd', 'cr'
    Optional:
            'cr_err'
    """

    x = df["mjd"].to_numpy()
    y = df["cr"].to_numpy()
    yerr = df["cr_err"].to_numpy() if "cr_err" in df else None

    plt.figure(figsize=(8, 3))

    if yerr is not None:
        plt.errorbar(x, y, yerr=yerr, fmt="o", ms=3, lw=1)
    else:
        plt.plot(x, y, "o-", ms=3, lw=1)

    plt.xlabel("Time [MJD]")
    plt.ylabel("Count rate")
    plt.grid(True)
    plt.tight_layout()
    plt.show()


def read_qdp_lightcurve(
    fname: str,
    colmap: dict,
    band: str | None = None,
    verbose: bool = False,
) -> pd.DataFrame:
    """
    Read a QDP lightcurve file and return a tidy pandas DataFrame.

    Parameters
    ----------
    fname : str
            Path to QDP file
    colmap : dict
            QDP column mapping (same structure you already use)
    band : str or None
            Energy band to extract (e.g. "2-20 keV").
            If None and n_bands > 1, raises an error.
    verbose : bool
            Print basic info

    Returns
    -------
    pd.DataFrame with columns:
            ['mjd', 'mjd_err_neg', 'mjd_err_pos', 'cr', 'cr_err']
    """

    # -----------------------------
    # Read raw QDP (skip commands)
    # -----------------------------
    with open(fname) as f:
        lines = f.readlines()

    data_start = 0
    for i, line in enumerate(lines[:-1]):
        if line.startswith("!") and lines[i + 1].startswith("!"):
            data_start = i + 2

    df = pd.read_csv(
        fname,
        sep=r"\s+",
        comment="!",
        skiprows=data_start,
        header=None,
    ).iloc[:-1]

    df = df.astype(float)

    # -----------------------------
    # Assign column names
    # -----------------------------
    def colmap2header(colmap):
        keys = [k for k, v in colmap.items() if isinstance(v, int)]
        keys.remove("n_bands")
        return sorted(keys, key=lambda k: colmap[k])

    df.columns = colmap2header(colmap)

    # -----------------------------
    # Handle bands
    # -----------------------------
    n_bands = colmap["n_bands"]

    if n_bands > 1:
        if band is None:
            raise ValueError("Multiple bands present; specify `band=...`")

        band_map = {colmap[f"cr{i}_band"]: i for i in range(1, n_bands + 1)}

        if band not in band_map:
            raise ValueError(f"Band '{band}' not found in QDP")

        i = band_map[band]

        cr = df[f"cr{i}"].to_numpy()
        cr_err = df[f"cr{i}_err"].to_numpy()

    else:
        cr = df["cr"].to_numpy()
        cr_err = df["cr_err"].to_numpy()

    # -----------------------------
    # Build output DataFrame
    # -----------------------------
    out = pd.DataFrame(
        {
            "mjd": df["t"].to_numpy(),
            "mjd_err_neg": df["t_err_neg"].to_numpy(),
            "mjd_err_pos": df["t_err_pos"].to_numpy(),
            "cr": cr,
            "cr_err": cr_err,
        }
    )

    out = out.replace([np.inf, -np.inf], np.nan).dropna()

    if verbose:
        print(f"Loaded {len(out)} bins from {fname}")
        print(out.head())

    return out


def to_seaborn(df, colmap) -> pd.DataFrame:
    out = pd.DataFrame()

    for i in range(1, colmap["n_bands"] + 1):
        tmp = pd.DataFrame(
            {
                "mjd": df["t"],
                "t_err_pos": df["t_err_pos"],
                "t_err_neg": df["t_err_neg"],
                "cr": df[f"cr{i}"],
                "err": df[f"cr{i}_err"],
                "band": colmap[f"cr{i}_band"],
            }
        )
        out = pd.concat([out, tmp], ignore_index=True)

    return out


def plot(df, t_start=None, t_stop=None, fig=None, axes=None):

    if t_start:
        if t_start >= df["t"].min():
            df = df[df["t"] >= t_start]

    if t_stop:
        if t_stop <= df["t"].max():
            df = df[df["t"] <= t_stop]

    n_series = df["band"].nunique()

    if axes is not None:
        fig, axes = plt.subplots(n_series, 1, figsize=(8, 2 * n_series), sharex=True)

    for i, (series, group) in enumerate(df.groupby("band")):
        ax = axes[i] if n_series > 1 else axes  # if only 1 series, axes is not a list
        sns.lineplot(data=group, x="t", y="cr", ax=ax)
        ax.fill_between(
            group["t"],
            group["cr"] - group["err"],
            group["cr"] + group["err"],
            alpha=0.3,
        )
        ax.set_title(f"Band {group['band'].iloc[0]}")
        ax.set_ylabel("Counts [s]")

    return fig, axes


if __name__ == "__main__":
    colmap = {
        "n_bands": 4,
        "t": 0,
        "t_err_pos": 1,
        "t_err_neg": 2,
        "cr1": 3,
        "cr1_err": 4,
        "cr1_band": "2-20 keV",
        "cr2": 5,
        "cr2_err": 6,
        "cr2_band": "2-4 keV",
        "cr3": 7,
        "cr3_err": 8,
        "cr2_band": "4-10 keV",
        "cr4": 9,
        "cr4_err": 10,
        "cr4_band": "10-20 keV",
    }
    df = read("../data/CygnusX-2/Maxi/glcscan_lcbg_gsc0124578.qdp", colmap)
    print(df)
