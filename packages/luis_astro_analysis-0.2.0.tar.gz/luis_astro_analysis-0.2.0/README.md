# The `fits_util` library

## Introduction

This package exists to streamline certain parts of astronomical X-ray data
analysis. For now, the main focus lies on the creation of Colour-Colour /
Colour-Intensity plots from raw photon event data, as well as the successive
(interactive) categorization of these data into branches, using the plots
mentioned. Furthermore, the package features a method to effortlessly calculate
the cross-correlation curve from two light curves.

Lastly, the package features a collection of useful functions, mostly made for
data-extraction of satellite data contained inside fits-files. For now, the
scope of this project remains rather compact, featuring support for
`.evt`-files, `.pha`-files and the `qdp`-format.

As the data-extraction differs from mission to mission, higher level functions
have been prepared in mission-specific files (i.e. ninja.py, tess.py).
These will be expanded as my need for them arises.

Examples of how to use the most important features of this package are shown
below.

## Dependencies

This Package depends on the following:

- astropy
- numpy
- pandas
- matplotlib
- seaborn

## Documentation

As of now, there is no documentation apart from the doc strings.
I did my best to briefly state what each function does, for any further
information The user is encouraged to look into the source code himself.

## Examples

### CCI_Analyzer

Below I have provided the method I currently use to analyse NinjaSat data:

```
from luis_astro_analysis import cci_analyzer as cci
from luis_astro_analysis import fits_util as f

ninja_path = "/path/to/ninja.evt"
gti_path = "/path/to/ninja.gti"
rmf_path = "/path/to/ninja.rmf"

ninja_bands = {
    "soft": (2, 4),
    "med": (4, 8),
    "hard": (8, 20),
}

# Load and format event data using fits_util
ninja_evts = f.read_mjd_channel(ninja_path)
ninja_rmf = f.read_rmf_ebounds(rmf_path)
ninja_evts = ninja_evts.merge(ninja_rmf, on="channel", how="left")

# initialize CCI_Analyzer
CCI = cci.CCI_Analyzer()

# load data
CCI.load_dataframe(ninja_evts)
CCI.load_gti_from_file(gti_path)

# set analysis parameters
CCI.set_colorbands(ninja_bands) # initial colorbands
CCI.set_binsize(binsize_sec=600) # initial binsize
CCI.set_interactive_bin_bounds(1, 1000) # boundaries for binsize (sec)
CCI.set_color_ratio_error_threshold(0.5) # error threshold for color data

# gti filtering
CCI.refine_gti() #recommended for NinjaSat data
CCI.select_good_time()

# interactive selection
CCI.select_bins_and_colors()
CCI.select_branches()

# results
CCI.plot_color_intensity()
CCI.plot_color_color()
```

### Cross-Correlator

Below is an example of how to calculate the direct cross-correlation of two
lightcurves using the Cross-Correlator class:

```
from luis_astro_analysis import Cross-Correlator as croco
from luis_astro_analysis import fits_util as f
from luis_astro_analysis import ninja
from luis_astro_analysis import tess

ninja_path = "/path/to/ninja.evt"
gti_path = "/path/to/ninja.gti"
rmf_path = "/path/to/ninja.rmf"
tess_path = "/path/to/tess.evt"

binsize_sec = 20 # same as TESS

gti = f.read_stdgti_mjd(gti_path)
gti = f.refine_gti(gti, f.read_evt_mjd(ninja_path))

ninja_lc = ninja.extract_lightcurve(ninja_path, binsize_sec, gti=gti, rmf=rmf, drop_zeros=True)

tess_lc = tess.extract_lightcurve(tess_path)
tess_lc = tess_lc.loc[tess_lc["mjd"] > ninja_lc["mjd"].min()]

CC = croco.Cross_Correlator()

CC.load_dataframe(tess_lc, "Tess", 1)
CC.load_dataframe(ninja_lc, "Ninja", 2)
CC.load_gti(gti)
df = CC.interactive_dccf(tau_max_init=5000, d_tau_init=20)
```
