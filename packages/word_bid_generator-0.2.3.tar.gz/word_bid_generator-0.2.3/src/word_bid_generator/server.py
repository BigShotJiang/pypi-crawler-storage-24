
import os
import uuid
import datetime
import logging
import sys

# ⚠️ 所有日志强制输出到 stderr，绝对不能污染 stdout
logging.basicConfig(level=logging.WARNING, stream=sys.stderr)

from mcp.server.fastmcp import FastMCP
from docx import Document
from docx.shared import Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH

# 变量名必须是 mcp、server 或 app 之一，这里用 mcp
mcp = FastMCP("word-bid-generator")


@mcp.tool()
def generate_bid_document(project_name: str, document_content: dict) -> str:
    """
    根据投标书结构化内容生成Word格式(.docx)的投标响应文件，返回OSS下载链接。

    Args:
        project_name: 招标项目名称
        document_content: 投标书各章节内容的JSON结构，格式为：
                          {"sections": [{"title": "章节标题", "level": 1, "content": "章节内容"}, ...]}
    """
    import oss2

    # ── 创建 Word 文档 ──────────────────────────────────────────
    doc = Document()

    # 设置默认字体
    style = doc.styles['Normal']
    style.font.name = '宋体'
    style.font.size = Pt(12)

    # 封面
    title = doc.add_heading(project_name, 0)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER

    subtitle = doc.add_heading("投标响应文件", 1)
    subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
    doc.add_page_break()

    # 各章节内容
    for section in document_content.get("sections", []):
        doc.add_heading(section["title"], level=section.get("level", 1))
        doc.add_paragraph(section["content"])

    # ── 保存到临时文件 ────────────────────────────────────────
    today = datetime.date.today().strftime("%Y%m%d")
    filename = f"{project_name}_投标响应文件_{today}.docx"
    tmp_path = f"/tmp/{filename}"
    doc.save(tmp_path)

    # ── 上传到 OSS ────────────────────────────────────────────
    access_key = os.environ.get('OSS_ACCESS_KEY')
    secret_key = os.environ.get('OSS_SECRET_KEY')
    endpoint   = os.environ.get('OSS_ENDPOINT')
    bucket_name = os.environ.get('OSS_BUCKET')

    if not all([access_key, secret_key, endpoint, bucket_name]):
        raise ValueError("OSS 环境变量未配置，请检查 OSS_ACCESS_KEY / OSS_SECRET_KEY / OSS_ENDPOINT / OSS_BUCKET")

    auth = oss2.Auth(access_key, secret_key)
    bucket = oss2.Bucket(auth, endpoint, bucket_name)

    oss_key = f"bid-documents/{uuid.uuid4()}/{filename}"
    bucket.put_object_from_file(oss_key, tmp_path)

    # 生成 1 小时有效的签名下载链接
    download_url = bucket.sign_url('GET', oss_key, 3600)

    return (
        f"✅ Word文档已生成！\n"
        f"文件名：{filename}\n"
        f"下载链接（1小时有效）：{download_url}"
    )


def main():
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
