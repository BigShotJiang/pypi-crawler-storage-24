"""sfdc-mcp: Production-grade Salesforce MCP server."""
__version__ = "0.1.0"
