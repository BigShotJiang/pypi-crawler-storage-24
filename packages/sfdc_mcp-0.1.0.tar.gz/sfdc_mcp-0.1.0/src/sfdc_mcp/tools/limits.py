"""Tool: salesforce_get_limits — fetch current org governor limit usage."""
from __future__ import annotations

import json
from typing import Any

from ..client.salesforce import SalesforceClient
from ..utils.error_handler import enrich_error


async def handle_get_limits(client: SalesforceClient, args: dict[str, Any]) -> str:
    """
    Return current Salesforce org governor limit usage.

    Highlights any limits above 80% (warning) or 95% (critical).
    Results cached for 60 seconds.
    """
    try:
        limits = await client.get_limits()

        warnings = [v for v in limits.values() if v["status"] in ("warning", "critical")]
        critical = [v for v in limits.values() if v["status"] == "critical"]

        return json.dumps(
            {
                "limits": limits,
                "warnings": warnings,
                "critical": critical,
                "summary": (
                    f"{len(critical)} critical, {len(warnings) - len(critical)} warnings, "
                    f"{len(limits) - len(warnings)} ok"
                ),
            },
            default=str,
        )
    except Exception as exc:
        return json.dumps(enrich_error(exc))
