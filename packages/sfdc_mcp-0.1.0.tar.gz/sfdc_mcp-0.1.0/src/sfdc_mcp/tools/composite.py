"""Tool: salesforce_composite — Batch multiple API calls in one round trip."""
from __future__ import annotations

import json
from typing import Any

from ..client.composite import CompositeClient
from ..client.salesforce import SalesforceClient
from ..utils.error_handler import enrich_error


async def handle_composite(client: SalesforceClient, args: dict[str, Any]) -> str:
    """
    Execute multiple Salesforce API sub-requests in a single HTTP round trip.

    Use Composite API to chain dependent requests — reference results from earlier
    sub-requests using @{referenceId.field} syntax.

    Args:
        requests: List of sub-request dicts, each with:
            - reference_id: Unique string ID for referencing this response (e.g. 'NewAccount')
            - method: GET | POST | PATCH | DELETE
            - url: Relative Salesforce REST API URL
              e.g. '/services/data/v59.0/sobjects/Account/'
            - body: Request body dict (for POST/PATCH)
        all_or_none: Rollback all if any sub-request fails (default false)
        collate_subrequests: Allow Salesforce to reorder independent requests (default true)

    Example — create Account then Contact linked to it:
        requests:
          - reference_id: NewAccount
            method: POST
            url: /services/data/v59.0/sobjects/Account/
            body: {Name: "Acme Corp"}
          - reference_id: NewContact
            method: POST
            url: /services/data/v59.0/sobjects/Contact/
            body: {LastName: "Smith", AccountId: "@{NewAccount.id}"}

    Max 25 sub-requests per call.
    """
    try:
        raw_requests: list[dict] = args.get("requests", [])
        if not raw_requests:
            return json.dumps({"error": True, "message": "requests list is required"})

        # Normalize request format
        subrequests = []
        for r in raw_requests:
            sub: dict[str, Any] = {
                "referenceId": r.get("reference_id", r.get("referenceId", "")),
                "method": r.get("method", "GET").upper(),
                "url": r.get("url", ""),
            }
            if not sub["referenceId"]:
                return json.dumps(
                    {"error": True, "message": f"Each request must have a reference_id: {r}"}
                )
            if not sub["url"]:
                return json.dumps(
                    {"error": True, "message": f"Each request must have a url: {r}"}
                )
            if "body" in r:
                sub["body"] = r["body"]
            if "httpHeaders" in r:
                sub["httpHeaders"] = r["httpHeaders"]
            subrequests.append(sub)

        all_or_none = args.get("all_or_none", False)
        collate = args.get("collate_subrequests", True)

        session = await client._auth.get_session()
        composite = CompositeClient(session=session, api_version=client.api_version)
        result = await composite.execute(
            subrequests=subrequests,
            all_or_none=all_or_none,
            collate_subrequests=collate,
        )

        composite_responses = result.get("compositeResponse", [])
        success_count = sum(1 for r in composite_responses if 200 <= r.get("httpStatusCode", 0) < 300)
        error_count = len(composite_responses) - success_count

        return json.dumps(
            {
                "total_requests": len(subrequests),
                "success_count": success_count,
                "error_count": error_count,
                "responses": composite_responses,
            },
            default=str,
        )

    except Exception as exc:
        return json.dumps(enrich_error(exc))
