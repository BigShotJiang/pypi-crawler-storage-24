"""Tool: salesforce_manage_field — create/update custom fields via Metadata API."""
from __future__ import annotations

import io
import json
import zipfile
from typing import Any

from ..client.metadata import MetadataClient
from ..client.salesforce import SalesforceClient
from ..utils.error_handler import enrich_error
from ..utils.validators import validate_api_name

SUPPORTED_TYPES = {
    "Text", "Number", "Currency", "Date", "DateTime", "Time",
    "Phone", "Email", "Url", "Checkbox", "Percent",
    "Picklist", "MultiselectPicklist",
    "TextArea", "LongTextArea", "Html",
    "Lookup", "MasterDetail",
    "Formula", "Rollup",
    "ExternalLookup", "IndirectLookup",
}

DELETE_CONSTRAINTS = {"SetNull", "Restrict", "Cascade"}


def _build_field_xml(args: dict[str, Any], api_version: str) -> str:
    field_type = args["type"]
    api_name = args["api_name"]
    label = args.get("label", api_name.replace("__c", "").replace("_", " "))
    description = args.get("description", "")
    required = args.get("required", False)
    unique = args.get("unique", False)
    external_id = args.get("external_id", False)

    extra_xml = ""

    if field_type == "Text":
        length = args.get("length", 255)
        extra_xml = f"<length>{length}</length>"

    elif field_type in ("Number", "Currency", "Percent"):
        precision = args.get("precision", 18)
        scale = args.get("scale", 2)
        extra_xml = f"<precision>{precision}</precision><scale>{scale}</scale>"

    elif field_type in ("LongTextArea", "Html"):
        length = args.get("length", 32768)
        visible_lines = args.get("visible_lines", 10)
        extra_xml = f"<length>{length}</length><visibleLines>{visible_lines}</visibleLines>"

    elif field_type == "TextArea":
        extra_xml = ""

    elif field_type in ("Picklist", "MultiselectPicklist"):
        values: list = args.get("picklist_values", [])
        if not values:
            raise ValueError("picklist_values is required for Picklist/MultiselectPicklist fields")
        value_items = ""
        for v in values:
            val = v if isinstance(v, str) else v.get("value", "")
            default = "true" if (isinstance(v, dict) and v.get("default")) else "false"
            value_items += f"<values><fullName>{val}</fullName><default>{default}</default></values>"
        extra_xml = f"""<valueSet>
            <valueSetDefinition>
                <sorted>false</sorted>
                {value_items}
            </valueSetDefinition>
        </valueSet>"""
        if field_type == "MultiselectPicklist":
            visible_lines = args.get("visible_lines", 4)
            extra_xml += f"<visibleLines>{visible_lines}</visibleLines>"

    elif field_type in ("Lookup", "MasterDetail"):
        reference_to = args.get("reference_to", "")
        if not reference_to:
            raise ValueError(f"reference_to is required for {field_type} fields")
        rel_label = args.get("relationship_label", f"{label}s")
        rel_name = args.get("relationship_name", api_name.replace("__c", ""))
        delete_constraint = args.get("delete_constraint", "SetNull")
        if delete_constraint not in DELETE_CONSTRAINTS:
            delete_constraint = "SetNull"
        extra_xml = (
            f"<referenceTo>{reference_to}</referenceTo>"
            f"<relationshipLabel>{rel_label}</relationshipLabel>"
            f"<relationshipName>{rel_name}</relationshipName>"
        )
        if field_type == "Lookup":
            extra_xml += f"<deleteConstraint>{delete_constraint}</deleteConstraint>"

    elif field_type == "Formula":
        formula = args.get("formula", "")
        formula_type = args.get("formula_return_type", "Text")
        if not formula:
            raise ValueError("formula is required for Formula fields")
        extra_xml = f"<formula>{formula}</formula><formulaTreatBlanksAs>BlankAsZero</formulaTreatBlanksAs>"
        field_type = formula_type  # Salesforce uses return type as the field type for formula

    elif field_type == "Rollup":
        rollup_fn = args.get("rollup_function", "COUNT")
        related_object = args.get("related_object", "")
        related_field = args.get("related_field", "")
        filter_crit = args.get("filter_criteria", "")
        if not related_object or not related_field:
            raise ValueError("related_object and related_field are required for Rollup fields")
        extra_xml = f"""<summarizedField>{related_field}</summarizedField>
        <summaryForeignKey>{related_object}.{args.get('summary_foreign_key', 'Id')}</summaryForeignKey>
        <summaryOperation>{rollup_fn}</summaryOperation>
        <summaryObject>{related_object}</summaryObject>"""
        if filter_crit:
            extra_xml += f"<filterItems>{filter_crit}</filterItems>"

    return f"""<?xml version="1.0" encoding="UTF-8"?>
<CustomField xmlns="http://soap.sforce.com/2006/04/metadata">
    <fullName>{api_name}</fullName>
    <label>{label}</label>
    <type>{field_type}</type>
    <description>{description}</description>
    <required>{str(required).lower()}</required>
    <unique>{str(unique).lower()}</unique>
    <externalId>{str(external_id).lower()}</externalId>
    {extra_xml}
</CustomField>"""


async def handle_manage_field(client: SalesforceClient, args: dict[str, Any]) -> str:
    """
    Create or update a custom field on a Salesforce object.

    Args:
        operation: create | update
        object_api_name: Parent object API name (e.g. Account, MyObject__c)
        api_name: Field API name (without __c; will be added automatically)
        type: Text | Number | Currency | Date | DateTime | Phone | Email | Url |
              Checkbox | Percent | Picklist | MultiselectPicklist | TextArea |
              LongTextArea | Html | Lookup | MasterDetail | Formula | Rollup
        label: Field label
        description: Optional field description
        required: Whether the field is required (default false)
        unique: Whether values must be unique (default false)
        external_id: Mark as external ID for upsert (default false)
        length: Text/LongTextArea max length
        precision / scale: For Number/Currency/Percent
        picklist_values: List of strings or {value, default} dicts
        reference_to: Target object for Lookup/MasterDetail
        relationship_label / relationship_name: For Lookup/MasterDetail
        delete_constraint: SetNull | Restrict | Cascade (Lookup only)
        formula: Formula expression (Formula fields)
        formula_return_type: Return type for Formula fields (Text, Number, Date, etc.)
    """
    try:
        operation = args.get("operation", "create").lower()
        object_api_name = args.get("object_api_name", "").strip()
        if not object_api_name:
            return json.dumps({"error": True, "message": "object_api_name is required"})

        api_name = args.get("api_name", "").strip()
        if not api_name:
            return json.dumps({"error": True, "message": "api_name is required"})
        if not api_name.endswith("__c"):
            api_name = f"{api_name}__c"

        field_type = args.get("type", "").strip()
        if field_type not in SUPPORTED_TYPES:
            return json.dumps(
                {
                    "error": True,
                    "message": f"Unsupported field type '{field_type}'. Supported: {', '.join(sorted(SUPPORTED_TYPES))}",
                }
            )

        args["api_name"] = api_name
        field_xml = _build_field_xml(args, client.api_version)

        # Full name for the field in metadata = ObjectName.FieldName
        full_name = f"{object_api_name}.{api_name}"

        zip_buffer = io.BytesIO()
        with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zf:
            package_xml = f"""<?xml version="1.0" encoding="UTF-8"?>
<Package xmlns="http://soap.sforce.com/2006/04/metadata">
    <types>
        <members>{full_name}</members>
        <name>CustomField</name>
    </types>
    <version>{client.api_version}</version>
</Package>"""
            zf.writestr("package.xml", package_xml)
            # Metadata API expects field file at fields/ inside the object folder
            zf.writestr(f"objects/{object_api_name}/fields/{api_name}.field-meta.xml", field_xml)

        sf = await client._ensure_connected()
        meta_client = MetadataClient(sf=sf, session=client.session, api_version=client.api_version)
        raw_result = await meta_client.deploy_metadata(zip_buffer.getvalue())

        return json.dumps(
            {
                "operation": operation,
                "object": object_api_name,
                "field": api_name,
                "full_name": full_name,
                "type": field_type,
                "raw_response": raw_result.get("raw_response", ""),
            },
            default=str,
        )

    except Exception as exc:
        return json.dumps(enrich_error(exc))
