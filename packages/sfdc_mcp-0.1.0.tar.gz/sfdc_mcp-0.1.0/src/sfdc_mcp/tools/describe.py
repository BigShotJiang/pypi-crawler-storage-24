"""Object schema inspection — describe a single object or search across all of them."""
from __future__ import annotations

import fnmatch
import json
from typing import Any

from ..client.salesforce import SalesforceClient
from ..utils.error_handler import enrich_error


async def handle_describe_object(client: SalesforceClient, args: dict[str, Any]) -> str:
    object_name = args.get("object_name", "").strip()
    if not object_name:
        return json.dumps({"error": True, "message": "object_name is required"})

    include_fields = args.get("include_fields", True)
    include_relationships = args.get("include_relationships", True)
    include_record_types = args.get("include_record_types", False)
    field_filter = args.get("field_filter", "").strip()
    field_type_filter = {t.strip().lower() for t in args.get("field_type_filter", "").split(",") if t.strip()}
    custom_fields_only = args.get("custom_fields_only", False)
    fields_limit = args.get("fields_limit")
    fields_offset = args.get("fields_offset", 0)

    try:
        raw = await client.describe_object(object_name)

        result: dict[str, Any] = {
            "name": raw.get("name"),
            "label": raw.get("label"),
            "label_plural": raw.get("labelPlural"),
            "api_accessible": raw.get("queryable", False),
            "createable": raw.get("createable", False),
            "updateable": raw.get("updateable", False),
            "deletable": raw.get("deletable", False),
            "custom": raw.get("custom", False),
        }

        if include_fields:
            fields = []
            for f in raw.get("fields", []):
                fname: str = f.get("name", "")
                ftype: str = f.get("type", "")

                # apply any filters the caller passed
                if field_filter and not fnmatch.fnmatch(fname.lower(), field_filter.lower()):
                    continue
                if field_type_filter and ftype.lower() not in field_type_filter:
                    continue
                if custom_fields_only and not f.get("custom", False):
                    continue

                field_entry: dict[str, Any] = {
                    "name": fname,
                    "label": f.get("label"),
                    "type": ftype,
                    "length": f.get("length"),
                    "required": not f.get("nillable", True) and not f.get("defaultedOnCreate", False),
                    "nillable": f.get("nillable"),
                    "unique": f.get("unique"),
                    "externalId": f.get("externalId"),
                    "custom": f.get("custom"),
                    "updateable": f.get("updateable"),
                    "createable": f.get("createable"),
                }
                if ftype in ("picklist", "multipicklist"):
                    field_entry["picklist_values"] = [
                        {"value": pv.get("value"), "label": pv.get("label"), "active": pv.get("active")}
                        for pv in f.get("picklistValues", [])
                    ]
                if ftype == "reference":
                    field_entry["reference_to"] = f.get("referenceTo", [])
                    field_entry["relationship_name"] = f.get("relationshipName")
                fields.append(field_entry)

            total_fields = len(fields)
            # slice after filtering so the total count stays accurate
            if fields_offset:
                fields = fields[fields_offset:]
            if fields_limit is not None:
                fields = fields[:fields_limit]

            result["fields"] = fields
            result["field_count"] = total_fields
            result["fields_returned"] = len(fields)
            result["fields_offset"] = fields_offset
            if fields_limit is not None:
                result["has_more"] = (fields_offset + len(fields)) < total_fields

        if include_relationships:
            result["child_relationships"] = [
                {
                    "child_object": cr.get("childSObject"),
                    "field": cr.get("field"),
                    "relationship_name": cr.get("relationshipName"),
                    "cascadeDelete": cr.get("cascadeDelete"),
                }
                for cr in raw.get("childRelationships", [])
                if cr.get("relationshipName")  # unnamed relationships are less useful
            ]

        if include_record_types:
            result["record_types"] = [
                {"id": rt.get("recordTypeId"), "name": rt.get("name"), "default": rt.get("defaultRecordTypeMapping")}
                for rt in raw.get("recordTypeInfos", [])
            ]

        return json.dumps(result, default=str)

    except Exception as exc:
        return json.dumps(enrich_error(exc))


async def handle_search_objects(client: SalesforceClient, args: dict[str, Any]) -> str:
    # matches by API name or label, glob patterns work (e.g. '*Account*', 'Custom__c')
    pattern = args.get("search_pattern", "*").strip()
    include_standard = args.get("include_standard", True)
    include_custom = args.get("include_custom", True)
    queryable_only = args.get("queryable_only", True)

    try:
        raw = await client.describe_global()
        sobjects = raw.get("sobjects", [])

        matches = []
        for obj in sobjects:
            name: str = obj.get("name", "")
            if not fnmatch.fnmatch(name.lower(), pattern.lower()):
                # no API name match — try the label too
                label: str = obj.get("label", "")
                if not fnmatch.fnmatch(label.lower(), pattern.lower()):
                    continue

            if queryable_only and not obj.get("queryable", False):
                continue
            if not include_standard and not obj.get("custom", False):
                continue
            if not include_custom and obj.get("custom", False):
                continue

            matches.append(
                {
                    "name": name,
                    "label": obj.get("label"),
                    "label_plural": obj.get("labelPlural"),
                    "custom": obj.get("custom", False),
                    "queryable": obj.get("queryable"),
                    "createable": obj.get("createable"),
                    "updateable": obj.get("updateable"),
                    "deletable": obj.get("deletable"),
                }
            )

        return json.dumps(
            {
                "pattern": pattern,
                "match_count": len(matches),
                "objects": matches,
            },
            default=str,
        )

    except Exception as exc:
        return json.dumps(enrich_error(exc))
