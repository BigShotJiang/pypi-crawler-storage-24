"""Tool: salesforce_bulk_job — manage Bulk API v2.0 jobs directly."""
from __future__ import annotations

import json
from typing import Any

from ..client.bulk import BulkV2Client
from ..client.salesforce import SalesforceClient
from ..utils.error_handler import enrich_error


async def handle_bulk_job(client: SalesforceClient, args: dict[str, Any]) -> str:
    """
    Create and manage Salesforce Bulk API v2.0 ingest jobs.

    Sub-commands via `action`:
      - run: Create job, upload records, poll until complete, return results.
      - status: Get status of an existing job by job_id.
      - results: Fetch successful/failed results for a completed job.
      - abort: Abort an in-progress job.

    Args (for `run`):
        operation: insert | update | delete | upsert | hardDelete
        object_name: SObject API name
        records: List of record dicts (will be converted to CSV)
        external_id_field: Required for upsert
        poll_interval: Seconds between polls (default 5)

    Args (for `status` / `results` / `abort`):
        job_id: The Bulk v2.0 job ID
    """
    action = args.get("action", "run").lower()

    try:
        session = await client._auth.get_session()
        bulk = BulkV2Client(session=session, api_version=client.api_version)

        if action == "run":
            operation = args.get("operation", "insert").lower()
            object_name = args.get("object_name", "").strip()
            records: list[dict] = args.get("records", [])
            external_id_field = args.get("external_id_field")
            poll_interval = float(args.get("poll_interval", 5.0))

            if not object_name:
                return json.dumps({"error": True, "message": "object_name is required"})
            if not records:
                return json.dumps({"error": True, "message": "records list is empty"})

            result = await bulk.run_job(
                operation=operation,
                object_name=object_name,
                records=records,
                external_id_field=external_id_field,
                poll_interval=poll_interval,
            )
            return json.dumps(
                {
                    "job_id": result.job_id,
                    "state": result.state,
                    "operation": result.operation,
                    "object_name": result.object_name,
                    "records_processed": result.records_processed,
                    "records_failed": result.records_failed,
                    "failed_records": result.failed_results[:100],
                    "error_message": result.error_message,
                },
                default=str,
            )

        elif action == "status":
            job_id = args.get("job_id", "").strip()
            if not job_id:
                return json.dumps({"error": True, "message": "job_id is required for status action"})
            status = await bulk.get_job_status(job_id)
            return json.dumps(status, default=str)

        elif action == "results":
            job_id = args.get("job_id", "").strip()
            if not job_id:
                return json.dumps({"error": True, "message": "job_id is required for results action"})
            successful = await bulk.get_successful_results(job_id)
            failed = await bulk.get_failed_results(job_id)
            return json.dumps(
                {
                    "job_id": job_id,
                    "successful_count": len(successful),
                    "failed_count": len(failed),
                    "successful_results": successful[:500],
                    "failed_results": failed,
                },
                default=str,
            )

        elif action == "abort":
            job_id = args.get("job_id", "").strip()
            if not job_id:
                return json.dumps({"error": True, "message": "job_id is required for abort action"})
            await bulk.abort_job(job_id)
            return json.dumps({"job_id": job_id, "state": "Aborted"})

        else:
            return json.dumps(
                {"error": True, "message": f"Unknown action '{action}'. Use: run | status | results | abort"}
            )

    except Exception as exc:
        return json.dumps(enrich_error(exc))
