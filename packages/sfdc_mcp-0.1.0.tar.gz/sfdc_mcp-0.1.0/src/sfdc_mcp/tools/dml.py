"""DML handler — picks REST Collections or Bulk API depending on how many records you're sending."""
from __future__ import annotations

import json
import os
from typing import Any, Literal

from ..client.bulk import BulkV2Client
from ..client.salesforce import SalesforceClient
from ..utils.error_handler import enrich_error

DMLOperation = Literal["insert", "update", "delete", "upsert"]

# anything at or above this goes to Bulk API — bump it if REST is working fine for your use case
_BULK_THRESHOLD = int(os.environ.get("SALESFORCE_BULK_THRESHOLD", "200"))


async def handle_dml_records(client: SalesforceClient, args: dict[str, Any]) -> str:
    try:
        operation: DMLOperation = args.get("operation", "").lower()
        if operation not in ("insert", "update", "delete", "upsert"):
            return json.dumps({"error": True, "message": f"Invalid operation '{operation}'. Must be insert|update|delete|upsert"})

        object_name: str = args.get("object_name", "").strip()
        if not object_name:
            return json.dumps({"error": True, "message": "object_name is required"})

        records: list[dict] = args.get("records", [])
        if not records:
            return json.dumps({"error": True, "message": "records list is empty"})

        external_id_field: str | None = args.get("external_id_field")
        if operation == "upsert" and not external_id_field:
            return json.dumps({"error": True, "message": "external_id_field is required for upsert"})

        all_or_none: bool = args.get("all_or_none", False)
        threshold = args.get("bulk_threshold", _BULK_THRESHOLD)
        poll_interval = float(args.get("poll_interval", 5.0))

        use_bulk = len(records) >= threshold

        if use_bulk:
            # too many records for REST — hand it off to Bulk API
            session = await client._auth.get_session()
            bulk = BulkV2Client(session=session, api_version=client.api_version)
            result = await bulk.run_job(
                operation=operation,
                object_name=object_name,
                records=records,
                external_id_field=external_id_field,
                poll_interval=poll_interval,
            )
            return json.dumps(
                {
                    "mode": "bulk_v2",
                    "job_id": result.job_id,
                    "state": result.state,
                    "operation": result.operation,
                    "object_name": result.object_name,
                    "records_submitted": len(records),
                    "records_processed": result.records_processed,
                    "records_failed": result.records_failed,
                    "success_count": result.records_processed - result.records_failed,
                    "failure_count": result.records_failed,
                    "failed_records": result.failed_results[:50],  # truncate large failures
                    "error_message": result.error_message,
                },
                default=str,
            )

        else:
            # small enough to go through REST collections
            results = await client.collections_dml(
                operation=operation,
                object_name=object_name,
                records=records,
                external_id_field=external_id_field,
                all_or_none=all_or_none,
            )

            successes = [r for r in results if r.get("success", False)]
            failures = [r for r in results if not r.get("success", False)]

            return json.dumps(
                {
                    "mode": "rest_collections",
                    "operation": operation,
                    "object_name": object_name,
                    "records_submitted": len(records),
                    "success_count": len(successes),
                    "failure_count": len(failures),
                    "results": results,
                    "errors": [
                        {
                            "index": i,
                            "id": r.get("id"),
                            "errors": r.get("errors", []),
                        }
                        for i, r in enumerate(results)
                        if not r.get("success", False)
                    ],
                },
                default=str,
            )

    except Exception as exc:
        return json.dumps(enrich_error(exc))
