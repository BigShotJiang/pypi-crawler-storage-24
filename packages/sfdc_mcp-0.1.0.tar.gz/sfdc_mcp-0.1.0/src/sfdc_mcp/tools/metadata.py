"""Tools: salesforce_metadata_read, salesforce_metadata_deploy, salesforce_metadata_list."""
from __future__ import annotations

import io
import json
import zipfile
from typing import Any

from ..client.metadata import MetadataClient
from ..client.salesforce import SalesforceClient
from ..utils.error_handler import enrich_error


async def _get_metadata_client(client: SalesforceClient) -> MetadataClient:
    sf = await client._ensure_connected()
    session = client.session
    return MetadataClient(sf=sf, session=session, api_version=client.api_version)


async def handle_metadata_list(client: SalesforceClient, args: dict[str, Any]) -> str:
    """
    List metadata components by type.

    Args:
        metadata_types: List of metadata type names, e.g.
          ["CustomObject", "ApexClass", "Flow", "CustomField", "ValidationRule"]
    """
    metadata_types: list[str] = args.get("metadata_types", [])
    if not metadata_types:
        return json.dumps(
            {
                "error": True,
                "message": "metadata_types is required. Examples: CustomObject, ApexClass, Flow, Layout, Profile",
            }
        )

    try:
        meta_client = await _get_metadata_client(client)
        components = await meta_client.list_metadata(metadata_types)

        # Normalize to list of dicts
        result_list = []
        for comp in components:
            if hasattr(comp, "_fields"):  # OrderedDict from zeep
                comp = dict(comp)
            result_list.append(
                {
                    "full_name": comp.get("fullName", comp.get("full_name", "")),
                    "type": comp.get("type", ""),
                    "last_modified_by": comp.get("lastModifiedByName", ""),
                    "last_modified_date": str(comp.get("lastModifiedDate", "")),
                    "created_by": comp.get("createdByName", ""),
                    "created_date": str(comp.get("createdDate", "")),
                    "namespace": comp.get("namespacePrefix", ""),
                }
            )

        return json.dumps(
            {"count": len(result_list), "components": result_list},
            default=str,
        )

    except Exception as exc:
        return json.dumps(enrich_error(exc))


async def handle_metadata_read(client: SalesforceClient, args: dict[str, Any]) -> str:
    """
    Read raw metadata for specific components.

    Args:
        metadata_type: e.g. "CustomObject", "ApexClass", "Flow"
        full_names: List of component full names, e.g. ["Account", "MyClass"]
    """
    metadata_type: str = args.get("metadata_type", "").strip()
    full_names: list[str] = args.get("full_names", [])

    if not metadata_type:
        return json.dumps({"error": True, "message": "metadata_type is required"})
    if not full_names:
        return json.dumps({"error": True, "message": "full_names list is required"})

    try:
        meta_client = await _get_metadata_client(client)
        components = await meta_client.read_metadata(metadata_type, full_names)
        return json.dumps(
            {"metadata_type": metadata_type, "count": len(components), "components": components},
            default=str,
        )
    except Exception as exc:
        return json.dumps(enrich_error(exc))


async def handle_metadata_deploy(client: SalesforceClient, args: dict[str, Any]) -> str:
    """
    Deploy metadata components to Salesforce.

    Accepts pre-built components as a list of {type, full_name, metadata_xml} dicts.
    Packages them into a zip and deploys via Metadata API.

    Args:
        components: List of {type, full_name, metadata_xml} dicts
        check_only: If true, validate but don't save (default false)
        run_tests: List of Apex test class names to run during deploy
    """
    components: list[dict] = args.get("components", [])
    check_only: bool = args.get("check_only", False)
    run_tests: list[str] | None = args.get("run_tests")

    if not components:
        return json.dumps({"error": True, "message": "components list is required"})

    try:
        # Build a minimal Salesforce metadata package zip
        zip_buffer = io.BytesIO()
        with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zf:
            # package.xml
            types_xml = ""
            type_map: dict[str, list[str]] = {}
            for comp in components:
                t = comp.get("type", "")
                fn = comp.get("full_name", "")
                type_map.setdefault(t, []).append(fn)

            for t, names in type_map.items():
                members = "".join(f"<members>{n}</members>" for n in names)
                types_xml += f"<types>{members}<name>{t}</name></types>"

            package_xml = f"""<?xml version="1.0" encoding="UTF-8"?>
<Package xmlns="http://soap.sforce.com/2006/04/metadata">
    {types_xml}
    <version>{client.api_version}</version>
</Package>"""
            zf.writestr("package.xml", package_xml)

            # Individual component XML files
            for comp in components:
                meta_type = comp.get("type", "")
                full_name = comp.get("full_name", "")
                xml_content = comp.get("metadata_xml", "")
                # Determine file extension by type
                ext_map = {
                    "ApexClass": "cls",
                    "ApexTrigger": "trigger",
                    "ApexPage": "page",
                    "ApexComponent": "component",
                    "Flow": "flow",
                    "CustomObject": "object",
                    "CustomField": "field",
                    "Layout": "layout",
                    "Profile": "profile",
                    "PermissionSet": "permissionset",
                }
                ext = ext_map.get(meta_type, "xml")
                folder = meta_type[0].lower() + meta_type[1:] + "s"
                zf.writestr(f"{folder}/{full_name}.{ext}-meta.xml", xml_content)

        zip_bytes = zip_buffer.getvalue()

        meta_client = await _get_metadata_client(client)
        raw_result = await meta_client.deploy_metadata(
            zip_bytes=zip_bytes,
            check_only=check_only,
            run_tests=run_tests,
        )

        return json.dumps(
            {
                "check_only": check_only,
                "components_submitted": len(components),
                "raw_response": raw_result.get("raw_response", ""),
                "hint": "Use salesforce_metadata_deploy_status with the deploy_id to poll for completion.",
            },
            default=str,
        )

    except Exception as exc:
        return json.dumps(enrich_error(exc))
