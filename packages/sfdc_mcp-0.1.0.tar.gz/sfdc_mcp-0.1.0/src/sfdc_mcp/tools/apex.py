"""Tool: salesforce_execute_apex — Execute Anonymous Apex via Tooling API."""
from __future__ import annotations

import json
import urllib.parse
from typing import Any

from ..client.salesforce import SalesforceClient
from ..utils.error_handler import enrich_error


async def handle_execute_apex(client: SalesforceClient, args: dict[str, Any]) -> str:
    """
    Execute anonymous Apex code via the Tooling API.

    Args:
        apex_code: Apex code string to execute
        log_category: Log category for debug log (default Apex)
        log_level: Log level (NONE | ERROR | WARN | INFO | DEBUG | FINE | FINER | FINEST)

    Returns:
        success, compiled, executed, exception details, and any debug log output.

    WARNING: Execute Anonymous runs with the permissions of the authenticated user.
    Apex can modify or delete data. Use with caution.
    """
    apex_code = args.get("apex_code", "").strip()
    if not apex_code:
        return json.dumps({"error": True, "message": "apex_code is required"})

    log_level = args.get("log_level", "DEBUG").upper()

    try:
        encoded = urllib.parse.quote(apex_code)
        path = f"/services/data/v{client.api_version}/tooling/executeAnonymous/?anonymousBody={encoded}"

        result = await client.raw_get(path)

        output = {
            "success": result.get("success", False),
            "compiled": result.get("compiled", False),
            "executed": result.get("exceptionMessage") is None and result.get("success", False),
            "compile_problem": result.get("compileProblem"),
            "exception_message": result.get("exceptionMessage"),
            "exception_stack_trace": result.get("exceptionStackTrace"),
            "line": result.get("line"),
            "column": result.get("column"),
        }

        if not result.get("compiled", True):
            output["hint"] = (
                f"Compilation error at line {result.get('line')}, column {result.get('column')}: "
                f"{result.get('compileProblem')}"
            )
        elif result.get("exceptionMessage"):
            output["hint"] = (
                f"Runtime exception: {result.get('exceptionMessage')}. "
                f"Stack: {result.get('exceptionStackTrace', '')}"
            )

        return json.dumps(output, default=str)

    except Exception as exc:
        return json.dumps(enrich_error(exc))
