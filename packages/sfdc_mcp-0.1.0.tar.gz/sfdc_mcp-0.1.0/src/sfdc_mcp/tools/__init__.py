"""MCP tool handlers."""
from .apex import handle_execute_apex
from .bulk import handle_bulk_job
from .composite import handle_composite
from .describe import handle_describe_object, handle_search_objects
from .dml import handle_dml_records
from .limits import handle_get_limits
from .manage_field import handle_manage_field
from .manage_object import handle_manage_object
from .metadata import handle_metadata_deploy, handle_metadata_list, handle_metadata_read
from .query import handle_query_records, handle_query_next_page
from .search import handle_search_all

__all__ = [
    "handle_query_records",
    "handle_query_next_page",
    "handle_search_all",
    "handle_dml_records",
    "handle_bulk_job",
    "handle_describe_object",
    "handle_search_objects",
    "handle_metadata_list",
    "handle_metadata_read",
    "handle_metadata_deploy",
    "handle_manage_object",
    "handle_manage_field",
    "handle_execute_apex",
    "handle_composite",
    "handle_get_limits",
]
