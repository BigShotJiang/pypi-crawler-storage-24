"""SOQL query handler with pagination support."""
from __future__ import annotations

import json
from typing import Any

from ..client.salesforce import SalesforceClient
from ..utils.error_handler import enrich_error
from ..utils.soql_builder import build_soql


async def handle_query_records(client: SalesforceClient, args: dict[str, Any]) -> str:
    # accepts either a raw soql string or structured params (object, fields, where, etc.)
    try:
        if "soql" in args and args["soql"]:
            soql = args["soql"]
        else:
            soql = build_soql(
                object_name=args["object_name"],
                fields=args.get("fields"),
                where=args.get("where"),
                order_by=args.get("order_by"),
                limit=args.get("limit"),
                offset=args.get("offset"),
            )

        result = await client.query(soql)

        records = result.get("records", [])
        # SF adds these internally, they just clutter the response
        for r in records:
            r.pop("attributes", None)

        output: dict[str, Any] = {
            "soql": soql,
            "total_size": result.get("totalSize", len(records)),
            "done": result.get("done", True),
            "record_count": len(records),
            "records": records,
        }

        # more pages available — give the caller a token to continue
        if not result.get("done", True):
            output["next_page_token"] = result.get("nextRecordsUrl", "")
            output["pagination_hint"] = (
                "More records available. Call salesforce_query_records with "
                f"next_page_token='{output['next_page_token']}' to fetch the next page."
            )

        return json.dumps(output, default=str)

    except Exception as exc:
        return json.dumps(enrich_error(exc))


async def handle_query_next_page(client: SalesforceClient, args: dict[str, Any]) -> str:
    try:
        token = args["next_page_token"]
        result = await client.query_more(token, identifier_is_url=True)

        records = result.get("records", [])
        for r in records:
            r.pop("attributes", None)

        output = {
            "done": result.get("done", True),
            "record_count": len(records),
            "records": records,
        }
        if not result.get("done", True):
            output["next_page_token"] = result.get("nextRecordsUrl", "")

        return json.dumps(output, default=str)

    except Exception as exc:
        return json.dumps(enrich_error(exc))
