"""Tool: salesforce_manage_object — create/update custom Salesforce objects."""
from __future__ import annotations

import io
import json
import zipfile
from typing import Any

from ..client.metadata import MetadataClient
from ..client.salesforce import SalesforceClient
from ..utils.error_handler import enrich_error
from ..utils.validators import validate_api_name

SHARING_MODELS = {"ReadWrite", "Read", "Private", "ControlledByParent", "ControlledByLeadOrContact"}
NAME_FIELD_TYPES = {"Text", "AutoNumber"}


async def handle_manage_object(client: SalesforceClient, args: dict[str, Any]) -> str:
    """
    Create or update a custom Salesforce object via Metadata API.

    Args:
        operation: create | update
        api_name: Object API name (without __c suffix; it will be added automatically)
        label: Singular label
        plural_label: Plural label
        description: Optional object description
        name_field_label: Label for the standard Name field (default 'Name')
        name_field_type: Text | AutoNumber (default Text)
        auto_number_format: Format string for AutoNumber fields, e.g. 'ACC-{0000}'
        sharing_model: ReadWrite | Read | Private | ControlledByParent (default ReadWrite)
        enable_activities: Enable activity tracking (default false)
        enable_history: Enable field history tracking (default false)
        enable_reports: Enable reports (default true)
        enable_search: Enable search (default true)
    """
    try:
        operation = args.get("operation", "create").lower()
        api_name = args.get("api_name", "").strip()
        if not api_name:
            return json.dumps({"error": True, "message": "api_name is required"})

        # Auto-append __c if not present
        if not api_name.endswith("__c"):
            api_name = f"{api_name}__c"
        validate_api_name(api_name)

        label = args.get("label", api_name.replace("__c", "").replace("_", " "))
        plural_label = args.get("plural_label", f"{label}s")
        description = args.get("description", "")
        name_field_label = args.get("name_field_label", "Name")
        name_field_type = args.get("name_field_type", "Text")
        auto_number_format = args.get("auto_number_format", "")
        sharing_model = args.get("sharing_model", "ReadWrite")

        if sharing_model not in SHARING_MODELS:
            return json.dumps(
                {"error": True, "message": f"Invalid sharing_model. Options: {', '.join(SHARING_MODELS)}"}
            )
        if name_field_type not in NAME_FIELD_TYPES:
            return json.dumps(
                {"error": True, "message": f"Invalid name_field_type. Options: {', '.join(NAME_FIELD_TYPES)}"}
            )

        enable_activities = args.get("enable_activities", False)
        enable_history = args.get("enable_history", False)
        enable_reports = args.get("enable_reports", True)
        enable_search = args.get("enable_search", True)

        # Build name field XML
        if name_field_type == "AutoNumber":
            name_field_xml = f"""<nameField>
        <displayFormat>{auto_number_format or 'REC-{0000}'}</displayFormat>
        <label>{name_field_label}</label>
        <type>AutoNumber</type>
    </nameField>"""
        else:
            name_field_xml = f"""<nameField>
        <label>{name_field_label}</label>
        <type>Text</type>
    </nameField>"""

        object_xml = f"""<?xml version="1.0" encoding="UTF-8"?>
<CustomObject xmlns="http://soap.sforce.com/2006/04/metadata">
    <label>{label}</label>
    <pluralLabel>{plural_label}</pluralLabel>
    <description>{description}</description>
    {name_field_xml}
    <sharingModel>{sharing_model}</sharingModel>
    <deploymentStatus>Deployed</deploymentStatus>
    <enableActivities>{str(enable_activities).lower()}</enableActivities>
    <enableHistory>{str(enable_history).lower()}</enableHistory>
    <enableReports>{str(enable_reports).lower()}</enableReports>
    <enableSearch>{str(enable_search).lower()}</enableSearch>
</CustomObject>"""

        # Package and deploy
        zip_buffer = io.BytesIO()
        with zipfile.ZipFile(zip_buffer, "w", zipfile.ZIP_DEFLATED) as zf:
            package_xml = f"""<?xml version="1.0" encoding="UTF-8"?>
<Package xmlns="http://soap.sforce.com/2006/04/metadata">
    <types>
        <members>{api_name}</members>
        <name>CustomObject</name>
    </types>
    <version>{client.api_version}</version>
</Package>"""
            zf.writestr("package.xml", package_xml)
            zf.writestr(f"objects/{api_name}.object-meta.xml", object_xml)

        sf = await client._ensure_connected()
        meta_client = MetadataClient(sf=sf, session=client.session, api_version=client.api_version)
        raw_result = await meta_client.deploy_metadata(zip_buffer.getvalue())

        return json.dumps(
            {
                "operation": operation,
                "api_name": api_name,
                "label": label,
                "raw_response": raw_result.get("raw_response", ""),
                "hint": "Check deploy status in Setup > Deployment Status, or poll with the deploy ID.",
            },
            default=str,
        )

    except Exception as exc:
        return json.dumps(enrich_error(exc))
