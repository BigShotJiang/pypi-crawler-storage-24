"""Tool: salesforce_search_all — SOSL cross-object search."""
from __future__ import annotations

import json
from typing import Any

from ..client.salesforce import SalesforceClient
from ..utils.error_handler import enrich_error
from ..utils.validators import validate_sosl_term, validate_limit


_SEARCH_IN_OPTIONS = {"ALL FIELDS", "NAME FIELDS", "EMAIL FIELDS", "PHONE FIELDS", "SIDEBAR FIELDS"}


async def handle_search_all(client: SalesforceClient, args: dict[str, Any]) -> str:
    """
    Execute a SOSL search across one or more Salesforce objects.

    Args:
        search_term: The text to search for. Supports wildcards (* and ?).
        search_in: Scope — ALL FIELDS | NAME FIELDS | EMAIL FIELDS | PHONE FIELDS | SIDEBAR FIELDS
        objects: List of {name, fields[], limit} dicts. Empty = search all searchable objects.
        limit: Max results per object (default 200, max 2000).
    """
    try:
        raw_term = args.get("search_term", "")
        if not raw_term:
            return json.dumps({"error": True, "message": "search_term is required"})

        # Escape special chars unless wildcards are intentional
        auto_escape = args.get("escape", True)
        term = validate_sosl_term(raw_term) if auto_escape else raw_term

        search_in = args.get("search_in", "ALL FIELDS").upper()
        if search_in not in _SEARCH_IN_OPTIONS:
            search_in = "ALL FIELDS"

        objects: list[dict] = args.get("objects", [])
        global_limit = validate_limit(args.get("limit"), default=200, max_val=2000)

        # Build SOSL: FIND {term} IN FIELDS RETURNING obj1(fields LIMIT n), ...
        sosl = f"FIND {{{term}}} IN {search_in}"

        if objects:
            returning_parts = []
            for obj in objects:
                obj_name = obj["name"]
                fields = obj.get("fields", ["Id", "Name"])
                obj_limit = validate_limit(obj.get("limit"), default=global_limit)
                field_str = ", ".join(fields)
                returning_parts.append(f"{obj_name}({field_str} LIMIT {obj_limit})")
            sosl += " RETURNING " + ", ".join(returning_parts)
        else:
            sosl += f" LIMIT {global_limit}"

        result = await client.search(sosl)
        raw_records = result.get("searchRecords", [])

        # Group by object type
        grouped: dict[str, list] = {}
        for record in raw_records:
            attrs = record.pop("attributes", {})
            obj_type = attrs.get("type", "Unknown")
            grouped.setdefault(obj_type, []).append(record)

        return json.dumps(
            {
                "sosl": sosl,
                "total_found": len(raw_records),
                "search_results": grouped,
            },
            default=str,
        )

    except Exception as exc:
        return json.dumps(enrich_error(exc))
