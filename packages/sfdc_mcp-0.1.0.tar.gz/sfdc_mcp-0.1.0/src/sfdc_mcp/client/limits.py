"""Governor limits — fetch, surface warnings, and track the ones that actually matter."""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any

import httpx

logger = logging.getLogger(__name__)

WARN_PCT = 80.0
CRITICAL_PCT = 95.0


@dataclass
class LimitEntry:
    name: str
    max: int
    remaining: int

    @property
    def used(self) -> int:
        return self.max - self.remaining

    @property
    def used_pct(self) -> float:
        if self.max == 0:
            return 0.0
        return (self.used / self.max) * 100.0

    @property
    def is_warning(self) -> bool:
        return self.used_pct >= WARN_PCT

    @property
    def is_critical(self) -> bool:
        return self.used_pct >= CRITICAL_PCT

    def as_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "max": self.max,
            "remaining": self.remaining,
            "used": self.used,
            "used_pct": round(self.used_pct, 1),
            "status": "critical" if self.is_critical else ("warning" if self.is_warning else "ok"),
        }


class GovernorLimitsTracker:
    # SF exposes 80+ limits — we only track the ones that actually bite
    TRACKED_LIMITS = {
        "DailyApiRequests",
        "DailyBulkApiRequests",
        "DailyBulkV2QueryFileStorageMB",
        "DailyGenericStreamingApiEvents",
        "DailyWorkflowEmails",
        "DataStorageMB",
        "FileStorageMB",
        "HourlyAsyncReportRuns",
        "HourlyDashboardRefreshes",
        "HourlyODataCallout",
        "HourlySyncReportRuns",
        "HourlyTimeBasedWorkflow",
        "MassEmail",
        "SingleEmail",
        "StreamingApiConcurrentClients",
    }

    def __init__(self, instance_url: str, access_token: str, api_version: str = "59.0") -> None:
        self.instance_url = instance_url.rstrip("/")
        self.access_token = access_token
        self.api_version = api_version
        self._limits: dict[str, LimitEntry] = {}

    async def fetch(self) -> dict[str, LimitEntry]:
        url = f"{self.instance_url}/services/data/v{self.api_version}/limits"
        async with httpx.AsyncClient() as client:
            resp = await client.get(
                url,
                headers={"Authorization": f"Bearer {self.access_token}"},
                timeout=15,
            )
        resp.raise_for_status()
        raw: dict[str, dict] = resp.json()

        self._limits = {
            name: LimitEntry(name=name, max=vals.get("Max", 0), remaining=vals.get("Remaining", 0))
            for name, vals in raw.items()
            if name in self.TRACKED_LIMITS
        }
        self._check_warnings()
        return self._limits

    def _check_warnings(self) -> None:
        for entry in self._limits.values():
            if entry.is_critical:
                logger.error(
                    "CRITICAL: Salesforce governor limit '%s' at %.1f%% (%d/%d used)",
                    entry.name, entry.used_pct, entry.used, entry.max,
                )
            elif entry.is_warning:
                logger.warning(
                    "WARNING: Salesforce governor limit '%s' at %.1f%% (%d/%d used)",
                    entry.name, entry.used_pct, entry.used, entry.max,
                )

    def get_summary(self) -> list[dict[str, Any]]:
        return [e.as_dict() for e in sorted(self._limits.values(), key=lambda e: -e.used_pct)]

    def get_warnings(self) -> list[dict[str, Any]]:
        return [e.as_dict() for e in self._limits.values() if e.is_warning or e.is_critical]
