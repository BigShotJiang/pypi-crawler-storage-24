"""Composite API client — batch up to 25 sub-requests in one round trip."""
from __future__ import annotations

import logging
from typing import Any

import httpx

from ..auth.base import SalesforceSession
from ..middleware.rate_limiter import throttle

logger = logging.getLogger(__name__)

MAX_SUBREQUESTS = 25


class CompositeClient:
    def __init__(self, session: SalesforceSession, api_version: str = "59.0") -> None:
        self.session = session
        self.api_version = api_version

    async def execute(
        self,
        subrequests: list[dict[str, Any]],
        all_or_none: bool = False,
        collate_subrequests: bool = True,
    ) -> dict[str, Any]:
        if len(subrequests) > MAX_SUBREQUESTS:
            raise ValueError(
                f"Composite API allows at most {MAX_SUBREQUESTS} sub-requests; "
                f"got {len(subrequests)}. Split into multiple calls."
            )

        body = {
            "allOrNone": all_or_none,
            "collateSubrequests": collate_subrequests,
            "compositeRequest": subrequests,
        }

        await throttle()
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                f"{self.session.instance_url}/services/data/v{self.api_version}/composite",
                headers={
                    "Authorization": self.session.auth_header,
                    "Content-Type": "application/json",
                },
                json=body,
                timeout=120,
            )
        resp.raise_for_status()
        return resp.json()
