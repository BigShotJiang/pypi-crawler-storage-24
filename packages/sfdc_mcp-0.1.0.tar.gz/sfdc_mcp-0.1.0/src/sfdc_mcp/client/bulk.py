"""Bulk API v2.0 ingest client — create job, upload CSV, poll until done, fetch results."""
from __future__ import annotations

import asyncio
import csv
import io
import logging
import time
from dataclasses import dataclass
from typing import Any, Literal

import httpx

from ..auth.base import SalesforceSession
from ..middleware.rate_limiter import throttle

logger = logging.getLogger(__name__)

BulkOperation = Literal["insert", "update", "delete", "upsert", "hardDelete"]
JobState = Literal["Open", "UploadComplete", "InProgress", "JobComplete", "Failed", "Aborted"]


@dataclass
class BulkJobResult:
    job_id: str
    state: JobState
    operation: str
    object_name: str
    records_processed: int
    records_failed: int
    successful_results: list[dict]
    failed_results: list[dict]
    error_message: str | None = None


class BulkV2Client:
    """Salesforce Bulk API v2.0 ingest client."""

    CHUNK_SIZE = 10_000  # records per upload chunk
    MAX_POLL_ATTEMPTS = 60
    DEFAULT_POLL_INTERVAL = 5.0  # seconds

    def __init__(self, session: SalesforceSession, api_version: str = "59.0") -> None:
        self.session = session
        self.api_version = api_version
        self._base = f"{session.instance_url}/services/data/v{api_version}/jobs/ingest"

    @property
    def _headers(self) -> dict[str, str]:
        return {
            "Authorization": session.auth_header if (session := self.session) else "",
            "Content-Type": "application/json",
            "Accept": "application/json",
        }


    async def create_job(
        self,
        operation: BulkOperation,
        object_name: str,
        external_id_field: str | None = None,
        line_ending: str = "LF",
    ) -> dict[str, Any]:
        body: dict[str, Any] = {
            "operation": operation,
            "object": object_name,
            "contentType": "CSV",
            "lineEnding": line_ending,
        }
        if external_id_field:
            body["externalIdFieldName"] = external_id_field

        await throttle()
        async with httpx.AsyncClient() as client:
            resp = await client.post(self._base, headers=self._headers, json=body, timeout=30)
        resp.raise_for_status()
        return resp.json()

    async def upload_data(self, job_id: str, csv_data: str) -> None:
        url = f"{self._base}/{job_id}/batches"
        await throttle()
        async with httpx.AsyncClient() as client:
            resp = await client.put(
                url,
                headers={**self._headers, "Content-Type": "text/csv"},
                content=csv_data.encode("utf-8"),
                timeout=120,
            )
        resp.raise_for_status()

    async def close_job(self, job_id: str) -> dict[str, Any]:
        url = f"{self._base}/{job_id}"
        await throttle()
        async with httpx.AsyncClient() as client:
            resp = await client.patch(
                url,
                headers=self._headers,
                json={"state": "UploadComplete"},
                timeout=30,
            )
        resp.raise_for_status()
        return resp.json()

    async def abort_job(self, job_id: str) -> None:
        url = f"{self._base}/{job_id}"
        async with httpx.AsyncClient() as client:
            await client.patch(url, headers=self._headers, json={"state": "Aborted"}, timeout=15)

    async def get_job_status(self, job_id: str) -> dict[str, Any]:
        url = f"{self._base}/{job_id}"
        await throttle()
        async with httpx.AsyncClient() as client:
            resp = await client.get(url, headers=self._headers, timeout=15)
        resp.raise_for_status()
        return resp.json()

    async def get_successful_results(self, job_id: str) -> list[dict]:
        url = f"{self._base}/{job_id}/successfulResults"
        async with httpx.AsyncClient() as client:
            resp = await client.get(url, headers=self._headers, timeout=60)
        resp.raise_for_status()
        return list(csv.DictReader(io.StringIO(resp.text)))

    async def get_failed_results(self, job_id: str) -> list[dict]:
        url = f"{self._base}/{job_id}/failedResults"
        async with httpx.AsyncClient() as client:
            resp = await client.get(url, headers=self._headers, timeout=60)
        resp.raise_for_status()
        return list(csv.DictReader(io.StringIO(resp.text)))


    async def poll_until_done(
        self, job_id: str, poll_interval: float = DEFAULT_POLL_INTERVAL
    ) -> dict[str, Any]:
        terminal = {"JobComplete", "Failed", "Aborted"}
        for attempt in range(self.MAX_POLL_ATTEMPTS):
            await asyncio.sleep(poll_interval)
            status = await self.get_job_status(job_id)
            state = status.get("state", "")
            logger.debug("Bulk job %s state: %s (attempt %d)", job_id, state, attempt + 1)
            if state in terminal:
                return status
        raise TimeoutError(
            f"Bulk job {job_id} did not complete after "
            f"{self.MAX_POLL_ATTEMPTS * poll_interval:.0f}s"
        )

    @staticmethod
    def records_to_csv(records: list[dict]) -> str:
        if not records:
            return ""
        buf = io.StringIO()
        writer = csv.DictWriter(buf, fieldnames=list(records[0].keys()))
        writer.writeheader()
        writer.writerows(records)
        return buf.getvalue()

    async def run_job(
        self,
        operation: BulkOperation,
        object_name: str,
        records: list[dict],
        external_id_field: str | None = None,
        poll_interval: float = DEFAULT_POLL_INTERVAL,
    ) -> BulkJobResult:
        # full cycle: create → upload → close → poll → fetch results
        csv_data = self.records_to_csv(records)
        job = await self.create_job(operation, object_name, external_id_field)
        job_id: str = job["id"]
        logger.info("Created Bulk v2 job %s (%s on %s)", job_id, operation, object_name)

        try:
            await self.upload_data(job_id, csv_data)
            await self.close_job(job_id)
            final_status = await self.poll_until_done(job_id, poll_interval)
        except Exception:
            await self.abort_job(job_id)
            raise

        successful = await self.get_successful_results(job_id)
        failed = await self.get_failed_results(job_id)

        return BulkJobResult(
            job_id=job_id,
            state=final_status["state"],
            operation=operation,
            object_name=object_name,
            records_processed=int(final_status.get("numberRecordsProcessed", 0)),
            records_failed=int(final_status.get("numberRecordsFailed", 0)),
            successful_results=successful,
            failed_results=failed,
            error_message=final_status.get("errorMessage"),
        )
