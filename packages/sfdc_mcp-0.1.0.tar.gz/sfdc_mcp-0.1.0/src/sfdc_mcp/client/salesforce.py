"""Async wrapper around simple-salesforce — everything runs in an executor since simple-salesforce is sync-only."""
from __future__ import annotations

import asyncio
import logging
import os
from functools import partial
from typing import Any

from simple_salesforce import Salesforce
from simple_salesforce.exceptions import SalesforceError

from ..auth.base import AuthProvider, SalesforceSession
from ..middleware.cache import (
    _describe_cache,
    _global_cache,
    _limits_cache,
    get_or_set,
)
from ..middleware.rate_limiter import throttle
from ..middleware.retry import sf_retry
from .limits import GovernorLimitsTracker

logger = logging.getLogger(__name__)


class SalesforceClient:

    def __init__(self, auth_provider: AuthProvider, api_version: str | None = None) -> None:
        self._auth = auth_provider
        self.api_version = api_version or os.environ.get("SALESFORCE_API_VERSION", "59.0")
        self._sf: Salesforce | None = None
        self._session: SalesforceSession | None = None
        self._limits_tracker: GovernorLimitsTracker | None = None
        self._init_lock = asyncio.Lock()


    async def _ensure_connected(self) -> Salesforce:
        if self._sf is not None:
            return self._sf
        async with self._init_lock:
            if self._sf is not None:
                return self._sf
            session = await self._auth.get_session()
            self._session = session
            loop = asyncio.get_running_loop()
            self._sf = await loop.run_in_executor(
                None,
                partial(
                    Salesforce,
                    instance_url=session.instance_url,
                    session_id=session.access_token,
                    version=self.api_version,
                ),
            )
            self._limits_tracker = GovernorLimitsTracker(
                instance_url=session.instance_url,
                access_token=session.access_token,
                api_version=self.api_version,
            )
            logger.info("Connected to Salesforce: %s", session.instance_url)
        return self._sf

    async def _reconnect(self) -> Salesforce:
        # called when SF returns INVALID_SESSION_ID — drop everything and start fresh
        logger.info("Session expired — re-authenticating...")
        async with self._init_lock:
            self._sf = None
            self._session = None
            await self._auth.refresh()
        return await self._ensure_connected()

    async def _run(self, func, *args, **kwargs) -> Any:
        await throttle()
        sf = await self._ensure_connected()
        loop = asyncio.get_running_loop()
        try:
            return await loop.run_in_executor(None, partial(func, *args, **kwargs))
        except SalesforceError as exc:
            content = getattr(exc, "content", None)
            if isinstance(content, list) and any(
                e.get("errorCode") == "INVALID_SESSION_ID" for e in content
            ):
                sf = await self._reconnect()
                return await loop.run_in_executor(None, partial(func, *args, **kwargs))
            raise


    @sf_retry
    async def query(self, soql: str) -> dict[str, Any]:
        sf = await self._ensure_connected()
        return await self._run(sf.query, soql)

    @sf_retry
    async def query_more(self, next_records_url: str, identifier_is_url: bool = True) -> dict[str, Any]:
        sf = await self._ensure_connected()
        return await self._run(sf.query_more, next_records_url, identifier_is_url)

    @sf_retry
    async def query_all(self, soql: str) -> dict[str, Any]:
        # pulls everything into memory — use with caution on large result sets
        sf = await self._ensure_connected()
        return await self._run(sf.query_all, soql)


    @sf_retry
    async def search(self, sosl: str) -> dict[str, Any]:
        sf = await self._ensure_connected()
        return await self._run(sf.search, sosl)


    @sf_retry
    async def create(self, object_name: str, data: dict[str, Any]) -> dict[str, Any]:
        sf = await self._ensure_connected()
        obj = getattr(sf, object_name)
        return await self._run(obj.create, data)

    @sf_retry
    async def update(self, object_name: str, record_id: str, data: dict[str, Any]) -> int:
        sf = await self._ensure_connected()
        obj = getattr(sf, object_name)
        return await self._run(obj.update, record_id, data)

    @sf_retry
    async def delete(self, object_name: str, record_id: str) -> int:
        sf = await self._ensure_connected()
        obj = getattr(sf, object_name)
        return await self._run(obj.delete, record_id)

    @sf_retry
    async def upsert(self, object_name: str, record_id: str, data: dict[str, Any], external_id_field: str = "Id") -> dict[str, Any]:
        sf = await self._ensure_connected()
        obj = getattr(sf, object_name)
        return await self._run(obj.upsert, record_id, data, external_id_field=external_id_field)


    @sf_retry
    async def collections_create(self, object_name: str, records: list[dict]) -> list[dict]:
        sf = await self._ensure_connected()
        payload = [{"attributes": {"type": object_name}, **r} for r in records]
        return await self._run(sf.bulk2.__getattr__(object_name).insert, payload)

    async def collections_dml(
        self,
        operation: str,
        object_name: str,
        records: list[dict],
        external_id_field: str | None = None,
        all_or_none: bool = False,
    ) -> list[dict]:
        # SObject Collections API — handles up to 200 records per request
        sf = await self._ensure_connected()
        session = self._session
        import httpx

        chunk_size = 200
        results: list[dict] = []
        for i in range(0, len(records), chunk_size):
            chunk = records[i : i + chunk_size]
            typed = [{"attributes": {"type": object_name}, **r} for r in chunk]
            url_path = f"/services/data/v{self.api_version}/composite/sobjects"
            if operation == "update":
                method = "PATCH"
                body = {"allOrNone": all_or_none, "records": typed}
            elif operation == "delete":
                method = "DELETE"
                ids = ",".join(r["Id"] for r in chunk)
                url_path += f"?ids={ids}&allOrNone={str(all_or_none).lower()}"
                body = None
            elif operation == "upsert":
                method = "PATCH"
                url_path += f"/{object_name}/{external_id_field}"
                body = {"allOrNone": all_or_none, "records": typed}
            else:  # insert
                method = "POST"
                body = {"allOrNone": all_or_none, "records": typed}

            await throttle()
            async with httpx.AsyncClient() as client:
                req_kwargs: dict = {
                    "method": method,
                    "url": f"{session.instance_url}{url_path}",
                    "headers": {
                        "Authorization": session.auth_header,
                        "Content-Type": "application/json",
                    },
                    "timeout": 60,
                }
                if body is not None:
                    req_kwargs["json"] = body
                resp = await client.request(**req_kwargs)
            resp.raise_for_status()
            results.extend(resp.json() if isinstance(resp.json(), list) else [resp.json()])
        return results


    async def describe_object(self, object_name: str) -> dict[str, Any]:
        session = await self._auth.get_session()
        key = (session.instance_url, object_name.lower())

        async def _fetch():
            sf = await self._ensure_connected()
            loop = asyncio.get_running_loop()
            obj = getattr(sf, object_name)
            return await loop.run_in_executor(None, obj.describe)

        return await get_or_set(_describe_cache, key, _fetch)

    async def describe_global(self) -> dict[str, Any]:
        session = await self._auth.get_session()
        key = (session.instance_url, "global")

        async def _fetch():
            sf = await self._ensure_connected()
            loop = asyncio.get_running_loop()
            return await loop.run_in_executor(None, sf.describe)

        return await get_or_set(_global_cache, key, _fetch)


    async def get_limits(self) -> dict:
        session = await self._auth.get_session()
        key = (session.instance_url, "limits")
        tracker = self._limits_tracker

        async def _fetch():
            if tracker is None:
                await self._ensure_connected()
            return await self._limits_tracker.fetch()

        entries = await get_or_set(_limits_cache, key, _fetch)
        return {name: e.as_dict() for name, e in entries.items()}

    # raw HTTP helpers — used by Tooling API, Composite, Metadata, and anything else that bypasses simple-salesforce

    async def raw_get(self, path: str, params: dict | None = None) -> Any:
        session = await self._auth.get_session()
        await throttle()
        import httpx
        async with httpx.AsyncClient() as client:
            resp = await client.get(
                f"{session.instance_url}{path}",
                headers={"Authorization": session.auth_header},
                params=params,
                timeout=60,
            )
        resp.raise_for_status()
        return resp.json()

    async def raw_post(self, path: str, body: Any, content_type: str = "application/json") -> Any:
        session = await self._auth.get_session()
        await throttle()
        import httpx
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                f"{session.instance_url}{path}",
                headers={
                    "Authorization": session.auth_header,
                    "Content-Type": content_type,
                },
                json=body if content_type == "application/json" else None,
                content=body if content_type != "application/json" else None,
                timeout=120,
            )
        resp.raise_for_status()
        return resp.json() if resp.content else {}

    async def raw_patch(self, path: str, body: Any) -> Any:
        session = await self._auth.get_session()
        await throttle()
        import httpx
        async with httpx.AsyncClient() as client:
            resp = await client.patch(
                f"{session.instance_url}{path}",
                headers={
                    "Authorization": session.auth_header,
                    "Content-Type": "application/json",
                },
                json=body,
                timeout=60,
            )
        resp.raise_for_status()
        return resp.json() if resp.content else {}

    @property
    def session(self) -> SalesforceSession | None:
        return self._session

    @property
    def instance_url(self) -> str | None:
        return self._session.instance_url if self._session else None
