"""Salesforce Metadata API client (SOAP-based via simple-salesforce)."""
from __future__ import annotations

import asyncio
import logging
from functools import partial
from typing import Any

from simple_salesforce import Salesforce

from ..auth.base import SalesforceSession
from ..middleware.rate_limiter import throttle

logger = logging.getLogger(__name__)


class MetadataClient:
    """Wraps simple-salesforce's metadata API in async calls."""

    def __init__(self, sf: Salesforce, session: SalesforceSession, api_version: str = "59.0") -> None:
        self._sf = sf
        self.session = session
        self.api_version = api_version

    async def _run(self, func, *args, **kwargs) -> Any:
        await throttle()
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, partial(func, *args, **kwargs))

    async def list_metadata(self, metadata_types: list[str]) -> list[dict]:
        """List all components of the given metadata types."""
        queries = [{"type": t} for t in metadata_types]
        result = await self._run(self._sf.mdapi.list_metadata, queries, self.api_version)
        if result is None:
            return []
        if isinstance(result, dict):
            return [result]
        return list(result)

    async def read_metadata(self, metadata_type: str, full_names: list[str]) -> list[dict]:
        """Read metadata components by full name."""
        result = await self._run(self._sf.mdapi.retrieve_zip, None)
        # simple-salesforce mdapi.read returns OrderedDict or list
        # Use direct HTTP SOAP call instead for more reliable behaviour
        import httpx

        soap_body = self._build_read_soap(metadata_type, full_names)
        await throttle()
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                f"{self.session.instance_url}/services/Soap/m/{self.api_version}",
                headers={
                    "Authorization": f"Bearer {self.session.access_token}",
                    "Content-Type": "text/xml; charset=UTF-8",
                    "SOAPAction": "readMetadata",
                },
                content=soap_body.encode("utf-8"),
                timeout=60,
            )
        resp.raise_for_status()
        return self._parse_read_response(resp.text)

    def _build_read_soap(self, metadata_type: str, full_names: list[str]) -> str:
        names_xml = "".join(f"<fullNames>{n}</fullNames>" for n in full_names)
        return f"""<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope
    xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
    xmlns:met="http://soap.sforce.com/2006/04/metadata">
  <soapenv:Header>
    <met:CallOptions><met:client>sfdc-mcp</met:client></met:CallOptions>
    <met:SessionHeader><met:sessionId>{self.session.access_token}</met:sessionId></met:SessionHeader>
  </soapenv:Header>
  <soapenv:Body>
    <met:readMetadata>
      <met:type>{metadata_type}</met:type>
      {names_xml}
    </met:readMetadata>
  </soapenv:Body>
</soapenv:Envelope>"""

    def _parse_read_response(self, xml_text: str) -> list[dict]:
        """Very basic XML → dict extraction (returns raw XML per component)."""
        import xml.etree.ElementTree as ET
        root = ET.fromstring(xml_text)
        ns = {"met": "http://soap.sforce.com/2006/04/metadata"}
        results = []
        for record in root.iter("{http://soap.sforce.com/2006/04/metadata}records"):
            results.append({"raw_xml": ET.tostring(record, encoding="unicode")})
        return results

    async def deploy_metadata(
        self,
        zip_bytes: bytes,
        check_only: bool = False,
        run_tests: list[str] | None = None,
    ) -> dict[str, Any]:
        """Deploy a metadata zip package. Returns deploy result."""
        import base64
        import httpx

        b64_zip = base64.b64encode(zip_bytes).decode("ascii")
        test_level = "RunSpecifiedTests" if run_tests else "NoTestRun"
        tests_xml = "".join(f"<runTests>{t}</runTests>" for t in (run_tests or []))
        soap_body = f"""<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope
    xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
    xmlns:met="http://soap.sforce.com/2006/04/metadata">
  <soapenv:Header>
    <met:SessionHeader><met:sessionId>{self.session.access_token}</met:sessionId></met:SessionHeader>
    <met:CallOptions><met:client>sfdc-mcp</met:client></met:CallOptions>
  </soapenv:Header>
  <soapenv:Body>
    <met:deploy>
      <met:ZipFile>{b64_zip}</met:ZipFile>
      <met:DeployOptions>
        <met:allowMissingFiles>false</met:allowMissingFiles>
        <met:autoUpdatePackage>false</met:autoUpdatePackage>
        <met:checkOnly>{str(check_only).lower()}</met:checkOnly>
        <met:ignoreWarnings>false</met:ignoreWarnings>
        <met:performRetrieve>false</met:performRetrieve>
        <met:purgeOnDelete>false</met:purgeOnDelete>
        <met:rollbackOnError>true</met:rollbackOnError>
        <met:testLevel>{test_level}</met:testLevel>
        {tests_xml}
      </met:DeployOptions>
    </met:deploy>
  </soapenv:Body>
</soapenv:Envelope>"""

        await throttle()
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                f"{self.session.instance_url}/services/Soap/m/{self.api_version}",
                headers={
                    "Content-Type": "text/xml; charset=UTF-8",
                    "SOAPAction": "deploy",
                },
                content=soap_body.encode("utf-8"),
                timeout=120,
            )
        resp.raise_for_status()
        return {"raw_response": resp.text}

    async def check_deploy_status(self, deploy_id: str, include_details: bool = True) -> dict:
        import httpx
        soap_body = f"""<?xml version="1.0" encoding="UTF-8"?>
<soapenv:Envelope
    xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/"
    xmlns:met="http://soap.sforce.com/2006/04/metadata">
  <soapenv:Header>
    <met:SessionHeader><met:sessionId>{self.session.access_token}</met:sessionId></met:SessionHeader>
  </soapenv:Header>
  <soapenv:Body>
    <met:checkDeployStatus>
      <met:asyncProcessId>{deploy_id}</met:asyncProcessId>
      <met:includeDetails>{str(include_details).lower()}</met:includeDetails>
    </met:checkDeployStatus>
  </soapenv:Body>
</soapenv:Envelope>"""

        await throttle()
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                f"{self.session.instance_url}/services/Soap/m/{self.api_version}",
                headers={
                    "Content-Type": "text/xml; charset=UTF-8",
                    "SOAPAction": "checkDeployStatus",
                },
                content=soap_body.encode("utf-8"),
                timeout=30,
            )
        resp.raise_for_status()
        return {"raw_response": resp.text}
