"""Auth base — session dataclass and the abstract provider all strategies inherit from."""
from __future__ import annotations

import asyncio
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class SalesforceSession:
    access_token: str
    instance_url: str
    org_id: str = ""
    token_type: str = "Bearer"
    issued_at: Optional[str] = None  # ISO-8601; None = unknown/non-expiring

    @property
    def auth_header(self) -> str:
        return f"{self.token_type} {self.access_token}"


class AuthProvider(ABC):

    _session: Optional[SalesforceSession] = None
    _lock: asyncio.Lock = field(default_factory=asyncio.Lock)

    def __init__(self) -> None:
        self._session = None
        self._lock = asyncio.Lock()

    @abstractmethod
    async def _do_auth(self) -> SalesforceSession: ...

    async def get_session(self) -> SalesforceSession:
        if self._session is None:
            async with self._lock:
                if self._session is None:  # double-checked locking
                    self._session = await self._do_auth()
        return self._session

    async def refresh(self) -> SalesforceSession:
        async with self._lock:
            self._session = await self._do_auth()
        return self._session

    async def invalidate(self) -> None:
        async with self._lock:
            self._session = None
