"""OAuth2 Authorization Code + PKCE flow — opens browser, catches redirect, swaps code for token."""
from __future__ import annotations

import asyncio
import base64
import hashlib
import os
import secrets
import urllib.parse
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from threading import Thread

import httpx

from .base import AuthProvider, SalesforceSession


class OAuthWebFlowAuth(AuthProvider):
    def __init__(
        self,
        client_id: str | None = None,
        client_secret: str | None = None,
        redirect_port: int | None = None,
        instance_url: str | None = None,
        api_version: str | None = None,
    ) -> None:
        super().__init__()
        self.client_id = client_id or os.environ["SALESFORCE_CLIENT_ID"]
        self.client_secret = client_secret or os.environ.get("SALESFORCE_CLIENT_SECRET", "")
        self.redirect_port = redirect_port or int(
            os.environ.get("SALESFORCE_REDIRECT_PORT", "8788")
        )
        self.instance_url = instance_url or os.environ.get(
            "SALESFORCE_INSTANCE_URL", "https://login.salesforce.com"
        )
        self.api_version = api_version or os.environ.get("SALESFORCE_API_VERSION", "59.0")

    def _pkce_pair(self) -> tuple[str, str]:
        verifier = base64.urlsafe_b64encode(secrets.token_bytes(32)).rstrip(b"=").decode()
        digest = hashlib.sha256(verifier.encode()).digest()
        challenge = base64.urlsafe_b64encode(digest).rstrip(b"=").decode()
        return verifier, challenge

    async def _do_auth(self) -> SalesforceSession:
        verifier, challenge = self._pkce_pair()
        state = secrets.token_hex(16)
        redirect_uri = f"http://localhost:{self.redirect_port}/callback"

        auth_url = (
            f"{self.instance_url}/services/oauth2/authorize?"
            + urllib.parse.urlencode(
                {
                    "response_type": "code",
                    "client_id": self.client_id,
                    "redirect_uri": redirect_uri,
                    "state": state,
                    "code_challenge": challenge,
                    "code_challenge_method": "S256",
                }
            )
        )

        # tiny one-shot server — its only job is to catch the OAuth redirect
        auth_code_future: asyncio.Future[str] = asyncio.get_running_loop().create_future()

        class _Handler(BaseHTTPRequestHandler):
            def do_GET(self):  # noqa: N802
                parsed = urllib.parse.urlparse(self.path)
                params = dict(urllib.parse.parse_qsl(parsed.query))
                if params.get("state") != state:
                    self.send_response(400)
                    self.end_headers()
                    self.wfile.write(b"State mismatch - possible CSRF.")
                    return
                code = params.get("code", "")
                self.send_response(200)
                self.end_headers()
                self.wfile.write(b"Auth complete. You can close this tab.")
                asyncio.get_event_loop().call_soon_threadsafe(
                    auth_code_future.set_result, code
                )

            def log_message(self, *args):  # suppress server logs
                pass

        server = HTTPServer(("localhost", self.redirect_port), _Handler)
        thread = Thread(target=server.handle_request, daemon=True)
        thread.start()

        print(f"\nOpening browser for Salesforce OAuth login...\n{auth_url}\n")
        webbrowser.open(auth_url)

        auth_code = await asyncio.wait_for(auth_code_future, timeout=120)
        server.server_close()

        # swap the auth code for an actual access token
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                f"{self.instance_url}/services/oauth2/token",
                data={
                    "grant_type": "authorization_code",
                    "client_id": self.client_id,
                    "client_secret": self.client_secret,
                    "redirect_uri": redirect_uri,
                    "code": auth_code,
                    "code_verifier": verifier,
                },
                timeout=30,
            )
        if resp.status_code != 200:
            raise RuntimeError(f"OAuth2 token exchange failed [{resp.status_code}]: {resp.text}")

        data = resp.json()
        return SalesforceSession(
            access_token=data["access_token"],
            instance_url=data["instance_url"],
            org_id=data.get("id", "").split("/")[-2],
            issued_at=data.get("issued_at"),
        )
