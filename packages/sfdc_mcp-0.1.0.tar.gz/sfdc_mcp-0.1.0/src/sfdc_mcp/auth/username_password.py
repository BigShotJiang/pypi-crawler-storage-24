"""Username + password + security token auth via simple_salesforce."""
from __future__ import annotations

import asyncio
import os
from functools import partial
from urllib.parse import urlparse

from simple_salesforce import Salesforce, SalesforceAuthenticationFailed

from .base import AuthProvider, SalesforceSession


class UsernamePasswordAuth(AuthProvider):
    def __init__(
        self,
        username: str | None = None,
        password: str | None = None,
        security_token: str | None = None,
        instance_url: str | None = None,
        api_version: str | None = None,
    ) -> None:
        super().__init__()
        self.username = username or os.environ["SALESFORCE_USERNAME"]
        self.password = password or os.environ["SALESFORCE_PASSWORD"]
        self.security_token = security_token or os.environ.get("SALESFORCE_SECURITY_TOKEN", "")
        self.instance_url = (instance_url or os.environ.get(
            "SALESFORCE_INSTANCE_URL", "https://login.salesforce.com"
        )).rstrip("/")
        self.api_version = api_version or os.environ.get("SALESFORCE_API_VERSION", "59.0")

    def _domain(self) -> str:
        # simple_salesforce builds https://{domain}.salesforce.com as the SOAP endpoint.
        # We derive the domain from whatever URL the user configured so that orgs with
        # My Domain Login Enforcement work — they reject logins via login/test.salesforce.com.
        #   https://login.salesforce.com                  → 'login'
        #   https://myorg.my.salesforce.com               → 'myorg.my'
        #   https://myorg--uat.sandbox.my.salesforce.com  → 'myorg--uat.sandbox.my'
        hostname = urlparse(self.instance_url).hostname or "login.salesforce.com"
        if hostname.endswith(".salesforce.com"):
            return hostname[: -len(".salesforce.com")]
        # gov cloud or non-standard host — best we can do is fall back
        return "login"

    @staticmethod
    def _friendly_auth_error(exc: SalesforceAuthenticationFailed, instance_url: str) -> str:
        # SF's raw errors are often vague; this adds context the user actually needs
        code = getattr(exc, "code", "") or ""
        msg = getattr(exc, "auth_message", str(exc))

        is_generic_login = instance_url.rstrip("/") in (
            "https://login.salesforce.com",
            "https://test.salesforce.com",
        )

        hints: list[str] = []

        if "INVALID_LOGIN" in code or "invalid" in msg.lower():
            hints.append("Wrong username, password, or security token.")
            hints.append("Security token is separate from your password — reset it in Setup > My Personal Info > Reset Security Token.")
            if is_generic_login:
                hints.append(
                    "If your org enforces My Domain Login (common in enterprise orgs), "
                    "set SALESFORCE_INSTANCE_URL to your My Domain URL "
                    "(e.g. https://mycompany.my.salesforce.com) instead of login.salesforce.com."
                )
        elif "MUST_USE_ORG_DOMAIN" in code or "custom domain" in msg.lower() or "my domain" in msg.lower():
            hints.append(
                "This org enforces My Domain Login. "
                "Set SALESFORCE_INSTANCE_URL to your My Domain URL "
                "(e.g. https://mycompany.my.salesforce.com or "
                "https://mycompany--sandbox.sandbox.my.salesforce.com)."
            )
        elif "INACTIVE_USER" in code or "locked" in msg.lower():
            hints.append("User account is inactive or locked. Contact your Salesforce administrator.")
        elif "PASSWORD_LOCKOUT" in code or "too many" in msg.lower():
            hints.append("Account locked due to too many failed login attempts. Reset via Salesforce login page.")
        elif "UNSUPPORTED_CLIENT" in code:
            hints.append("IP restriction may be blocking this connection. Check trusted IP ranges in Setup > Network Access.")

        hint_text = " | ".join(hints) if hints else ""
        return (
            f"Salesforce authentication failed [{code}]: {msg}"
            + (f"\nHint: {hint_text}" if hint_text else "")
            + f"\nLogin URL used: {instance_url}"
        )

    async def _do_auth(self) -> SalesforceSession:
        loop = asyncio.get_running_loop()
        domain = self._domain()
        try:
            sf = await loop.run_in_executor(
                None,
                partial(
                    Salesforce,
                    username=self.username,
                    password=self.password,
                    security_token=self.security_token,
                    domain=domain,
                    version=self.api_version,
                ),
            )
        except SalesforceAuthenticationFailed as exc:
            raise RuntimeError(self._friendly_auth_error(exc, self.instance_url)) from exc
        except Exception as exc:
            # can't even reach the endpoint
            msg = str(exc)
            if "getaddrinfo" in msg or "NameResolutionError" in msg:
                raise RuntimeError(
                    f"Cannot reach Salesforce login endpoint: {self.instance_url}\n"
                    "Check that SALESFORCE_INSTANCE_URL is a valid, reachable Salesforce URL."
                ) from exc
            raise

        # simple_salesforce returns a bare hostname, not a full URL
        hostname = sf.sf_instance
        instance_url = hostname if hostname.startswith("https://") else f"https://{hostname}"
        return SalesforceSession(
            access_token=sf.session_id,
            instance_url=instance_url,
            org_id=hostname.split(".")[0],
        )
