"""JWT Bearer (Connected App) auth — RS256 assertion flow."""
from __future__ import annotations

import os
import time
from pathlib import Path

import httpx
import jwt  # PyJWT

from .base import AuthProvider, SalesforceSession


class JWTBearerAuth(AuthProvider):
    def __init__(
        self,
        client_id: str | None = None,
        username: str | None = None,
        private_key_path: str | None = None,
        private_key_pem: str | None = None,
        instance_url: str | None = None,
        api_version: str | None = None,
    ) -> None:
        super().__init__()
        self.client_id = client_id or os.environ["SALESFORCE_CLIENT_ID"]
        self.username = username or os.environ["SALESFORCE_USERNAME"]
        self.instance_url = (instance_url or os.environ.get(
            "SALESFORCE_INSTANCE_URL", "https://login.salesforce.com"
        )).rstrip("/")
        self.api_version = api_version or os.environ.get("SALESFORCE_API_VERSION", "59.0")

        # PEM string takes precedence over file path
        if private_key_pem:
            self._private_key = private_key_pem
        elif private_key_path:
            self._private_key = Path(private_key_path).read_text()
        elif "SALESFORCE_PRIVATE_KEY_PATH" in os.environ:
            self._private_key = Path(os.environ["SALESFORCE_PRIVATE_KEY_PATH"]).read_text()
        elif "SALESFORCE_PRIVATE_KEY_PEM" in os.environ:
            self._private_key = os.environ["SALESFORCE_PRIVATE_KEY_PEM"]
        else:
            raise ValueError(
                "JWT Bearer auth requires SALESFORCE_PRIVATE_KEY_PATH or SALESFORCE_PRIVATE_KEY_PEM"
            )

    def _auth_server_url(self) -> str:
        # JWT `aud` must be login or test — never a My Domain URL.
        # Using a custom domain here fails with invalid_client_id even if everything else is right.
        url = self.instance_url.lower().rstrip("/")
        if "sandbox" in url or "test.salesforce.com" in url:
            return "https://test.salesforce.com"
        return "https://login.salesforce.com"

    def _build_assertion(self) -> str:
        now = int(time.time())
        payload = {
            "iss": self.client_id,
            "sub": self.username,
            "aud": self._auth_server_url(),
            "exp": now + 300,  # 5 minutes is the max SF allows
        }
        return jwt.encode(payload, self._private_key, algorithm="RS256")

    async def _do_auth(self) -> SalesforceSession:
        assertion = self._build_assertion()
        token_url = f"{self.instance_url}/services/oauth2/token"
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                token_url,
                data={
                    "grant_type": "urn:ietf:params:oauth:grant-type:jwt-bearer",
                    "assertion": assertion,
                },
                timeout=30,
            )
        if resp.status_code != 200:
            try:
                err = resp.json()
                code = err.get("error", "")
                detail = err.get("error_description", resp.text)
            except Exception:
                code, detail = "", resp.text

            hints: list[str] = []
            if code == "invalid_client_id":
                hints.append("Connected App consumer key is wrong or the app is not active.")
            elif code == "invalid_grant":
                if "user hasn't approved" in detail.lower():
                    hints.append("User is not pre-authorized. Add the user's profile/permission set to the Connected App.")
                elif "ip restricted" in detail.lower():
                    hints.append("IP restriction — add the server IP to the Connected App's trusted IP ranges.")
                else:
                    hints.append("Connected App may not have 'Authorize pre-approved users' enabled, or the user is inactive.")
            elif code == "invalid_client":
                hints.append("Private key does not match the certificate uploaded to the Connected App.")
            elif "must_use_org_domain" in detail.lower() or "custom domain" in detail.lower():
                hints.append(
                    "Org enforces My Domain Login. Set SALESFORCE_INSTANCE_URL to your "
                    "My Domain URL (e.g. https://mycompany.my.salesforce.com)."
                )

            hint_text = (" | ".join(hints)) if hints else ""
            raise RuntimeError(
                f"JWT Bearer auth failed [{resp.status_code}] {code}: {detail}"
                + (f"\nHint: {hint_text}" if hint_text else "")
                + f"\nToken URL: {token_url}"
            )
        data = resp.json()
        return SalesforceSession(
            access_token=data["access_token"],
            instance_url=data["instance_url"],
            org_id=data.get("id", "").split("/")[-2],
            issued_at=data.get("issued_at"),
        )
