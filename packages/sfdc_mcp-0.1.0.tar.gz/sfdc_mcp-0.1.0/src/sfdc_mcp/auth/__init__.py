"""Auth factory — selects provider based on SALESFORCE_AUTH_TYPE env var."""
from __future__ import annotations

import os

from .access_token import AccessTokenAuth
from .base import AuthProvider, SalesforceSession
from .jwt_bearer import JWTBearerAuth
from .oauth_web import OAuthWebFlowAuth
from .username_password import UsernamePasswordAuth

__all__ = [
    "AuthProvider",
    "SalesforceSession",
    "UsernamePasswordAuth",
    "JWTBearerAuth",
    "OAuthWebFlowAuth",
    "AccessTokenAuth",
    "create_auth_provider",
]

_AUTH_TYPES: dict[str, type[AuthProvider]] = {
    "username_password": UsernamePasswordAuth,
    "jwt_bearer": JWTBearerAuth,
    "oauth_web": OAuthWebFlowAuth,
    "access_token": AccessTokenAuth,
}


def create_auth_provider(auth_type: str | None = None) -> AuthProvider:
    """Instantiate the appropriate AuthProvider from env config."""
    resolved = (auth_type or os.environ.get("SALESFORCE_AUTH_TYPE", "username_password")).lower()
    cls = _AUTH_TYPES.get(resolved)
    if cls is None:
        raise ValueError(
            f"Unknown SALESFORCE_AUTH_TYPE '{resolved}'. "
            f"Valid options: {', '.join(_AUTH_TYPES)}"
        )
    return cls()
