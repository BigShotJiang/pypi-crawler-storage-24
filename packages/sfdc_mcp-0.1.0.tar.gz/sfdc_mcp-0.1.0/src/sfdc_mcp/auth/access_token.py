"""Direct access token authentication — for tooling / pre-authenticated contexts."""
from __future__ import annotations

import os

from .base import AuthProvider, SalesforceSession


class AccessTokenAuth(AuthProvider):
    def __init__(
        self,
        access_token: str | None = None,
        instance_url: str | None = None,
    ) -> None:
        super().__init__()
        self._token = access_token or os.environ["SALESFORCE_ACCESS_TOKEN"]
        self._instance_url = (instance_url or os.environ["SALESFORCE_INSTANCE_URL"]).rstrip("/")

    async def _do_auth(self) -> SalesforceSession:
        # No network call — token is provided directly
        return SalesforceSession(
            access_token=self._token,
            instance_url=self._instance_url,
        )
