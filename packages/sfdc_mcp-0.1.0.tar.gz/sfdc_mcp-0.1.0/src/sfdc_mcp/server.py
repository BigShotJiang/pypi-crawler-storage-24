"""MCP server — registers all tools and wires them up to the Salesforce client."""
from __future__ import annotations

import logging
import os

from dotenv import load_dotenv
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

from .auth import create_auth_provider
from .client.salesforce import SalesforceClient
from .tools import (
    handle_bulk_job,
    handle_composite,
    handle_describe_object,
    handle_dml_records,
    handle_execute_apex,
    handle_get_limits,
    handle_manage_field,
    handle_manage_object,
    handle_metadata_deploy,
    handle_metadata_list,
    handle_metadata_read,
    handle_query_next_page,
    handle_query_records,
    handle_search_all,
    handle_search_objects,
)

load_dotenv()
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger("sfdc-mcp")

TOOLS: list[Tool] = [
    Tool(
        name="salesforce_query_records",
        description=(
            "Execute a SOQL query against Salesforce. Supports pagination, relationship queries "
            "(parent-to-child and child-to-parent), and aggregate functions. "
            "Provide either a raw `soql` string or structured params."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "soql": {"type": "string", "description": "Raw SOQL query string (alternative to structured params)"},
                "object_name": {"type": "string", "description": "Salesforce object API name (e.g. Account, Contact)"},
                "fields": {"type": "array", "items": {"type": "string"}, "description": "Field API names to select"},
                "where": {"type": "string", "description": "WHERE clause (without the WHERE keyword)"},
                "order_by": {"type": "string", "description": "ORDER BY clause (without ORDER BY keyword)"},
                "limit": {"type": "integer", "description": "Max records to return"},
                "offset": {"type": "integer", "description": "Number of records to skip (pagination)"},
                "next_page_token": {"type": "string", "description": "Token from previous call to fetch next page"},
            },
        },
    ),
    Tool(
        name="salesforce_search_all",
        description=(
            "Search across multiple Salesforce objects using SOSL. "
            "Supports wildcards (* and ?) in search terms."
        ),
        inputSchema={
            "type": "object",
            "required": ["search_term"],
            "properties": {
                "search_term": {"type": "string", "description": "Text to search for (supports * and ? wildcards)"},
                "search_in": {
                    "type": "string",
                    "enum": ["ALL FIELDS", "NAME FIELDS", "EMAIL FIELDS", "PHONE FIELDS", "SIDEBAR FIELDS"],
                    "description": "Search scope (default: ALL FIELDS)",
                },
                "objects": {
                    "type": "array",
                    "description": "Objects to search in (empty = all searchable objects)",
                    "items": {
                        "type": "object",
                        "properties": {
                            "name": {"type": "string"},
                            "fields": {"type": "array", "items": {"type": "string"}},
                            "limit": {"type": "integer"},
                        },
                        "required": ["name"],
                    },
                },
                "limit": {"type": "integer", "description": "Max results per object (default 200)"},
                "escape": {"type": "boolean", "description": "Auto-escape special SOSL chars (default true)"},
            },
        },
    ),
    Tool(
        name="salesforce_dml_records",
        description=(
            "Insert, update, delete, or upsert Salesforce records. "
            "Automatically uses REST Collections API for <200 records and Bulk API v2.0 for ≥200 records."
        ),
        inputSchema={
            "type": "object",
            "required": ["operation", "object_name", "records"],
            "properties": {
                "operation": {
                    "type": "string",
                    "enum": ["insert", "update", "delete", "upsert"],
                    "description": "DML operation to perform",
                },
                "object_name": {"type": "string", "description": "Salesforce object API name"},
                "records": {
                    "type": "array",
                    "items": {"type": "object"},
                    "description": "Records to process. update/delete require 'Id' field.",
                },
                "external_id_field": {"type": "string", "description": "Field for upsert matching (required for upsert)"},
                "all_or_none": {"type": "boolean", "description": "Roll back all on any failure (REST only, default false)"},
                "bulk_threshold": {"type": "integer", "description": "Override bulk switch threshold (default 200)"},
                "poll_interval": {"type": "number", "description": "Bulk job poll interval in seconds (default 5)"},
            },
        },
    ),
    Tool(
        name="salesforce_bulk_job",
        description="Create and manage Salesforce Bulk API v2.0 ingest jobs directly.",
        inputSchema={
            "type": "object",
            "required": ["action"],
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["run", "status", "results", "abort"],
                    "description": "run: execute full job | status: check job state | results: get results | abort: cancel job",
                },
                "operation": {"type": "string", "enum": ["insert", "update", "delete", "upsert", "hardDelete"]},
                "object_name": {"type": "string"},
                "records": {"type": "array", "items": {"type": "object"}},
                "external_id_field": {"type": "string"},
                "poll_interval": {"type": "number"},
                "job_id": {"type": "string", "description": "Required for status/results/abort actions"},
            },
        },
    ),
    Tool(
        name="salesforce_describe_object",
        description=(
            "Get full schema metadata for a Salesforce object: all fields with types, "
            "labels, constraints, picklist values, and child relationships. Results are cached 5 minutes."
        ),
        inputSchema={
            "type": "object",
            "required": ["object_name"],
            "properties": {
                "object_name": {"type": "string", "description": "Salesforce object API name (e.g. Account)"},
                "include_fields": {"type": "boolean", "description": "Include field details (default true)"},
                "include_relationships": {"type": "boolean", "description": "Include child relationships (default true)"},
                "include_record_types": {"type": "boolean", "description": "Include record type info (default false)"},
                "field_filter": {"type": "string", "description": "Glob pattern to filter fields by API name (e.g. 'Email*', '*Address*', 'Custom__c')"},
                "field_type_filter": {"type": "string", "description": "Comma-separated field types to include (e.g. 'string,email,phone' or 'reference,picklist')"},
                "custom_fields_only": {"type": "boolean", "description": "Return only custom fields (default false)"},
                "fields_limit": {"type": "integer", "description": "Max number of fields to return (default: all)"},
                "fields_offset": {"type": "integer", "description": "Skip first N fields — use with fields_limit for pagination (default 0)"},
            },
        },
    ),
    Tool(
        name="salesforce_search_objects",
        description=(
            "Search for Salesforce objects by name or label pattern. "
            "Supports glob wildcards (* and ?). Results cached 10 minutes."
        ),
        inputSchema={
            "type": "object",
            "properties": {
                "search_pattern": {"type": "string", "description": "Pattern to match (e.g. '*Account*', 'Custom__c')"},
                "include_standard": {"type": "boolean", "description": "Include standard objects (default true)"},
                "include_custom": {"type": "boolean", "description": "Include custom objects (default true)"},
                "queryable_only": {"type": "boolean", "description": "Only return queryable objects (default true)"},
            },
        },
    ),
    Tool(
        name="salesforce_metadata_list",
        description="List Salesforce metadata components by type (e.g. CustomObject, ApexClass, Flow, Layout).",
        inputSchema={
            "type": "object",
            "required": ["metadata_types"],
            "properties": {
                "metadata_types": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Metadata type names, e.g. [\"CustomObject\", \"ApexClass\", \"Flow\"]",
                },
            },
        },
    ),
    Tool(
        name="salesforce_metadata_read",
        description="Read raw metadata XML for specific Salesforce metadata components.",
        inputSchema={
            "type": "object",
            "required": ["metadata_type", "full_names"],
            "properties": {
                "metadata_type": {"type": "string", "description": "Metadata type, e.g. CustomObject"},
                "full_names": {"type": "array", "items": {"type": "string"}, "description": "Component API names"},
            },
        },
    ),
    Tool(
        name="salesforce_metadata_deploy",
        description=(
            "Deploy metadata components to Salesforce via Metadata API. "
            "Packages provided XML components into a zip and deploys."
        ),
        inputSchema={
            "type": "object",
            "required": ["components"],
            "properties": {
                "components": {
                    "type": "array",
                    "items": {
                        "type": "object",
                        "required": ["type", "full_name", "metadata_xml"],
                        "properties": {
                            "type": {"type": "string"},
                            "full_name": {"type": "string"},
                            "metadata_xml": {"type": "string"},
                        },
                    },
                },
                "check_only": {"type": "boolean", "description": "Validate only, don't save (default false)"},
                "run_tests": {"type": "array", "items": {"type": "string"}, "description": "Apex test class names to run"},
            },
        },
    ),
    Tool(
        name="salesforce_manage_object",
        description="Create or update a custom Salesforce object via Metadata API.",
        inputSchema={
            "type": "object",
            "required": ["operation", "api_name", "label"],
            "properties": {
                "operation": {"type": "string", "enum": ["create", "update"]},
                "api_name": {"type": "string", "description": "Object API name (without __c; it will be added)"},
                "label": {"type": "string"},
                "plural_label": {"type": "string"},
                "description": {"type": "string"},
                "name_field_label": {"type": "string", "description": "Label for standard Name field"},
                "name_field_type": {"type": "string", "enum": ["Text", "AutoNumber"]},
                "auto_number_format": {"type": "string", "description": "e.g. REC-{0000}"},
                "sharing_model": {
                    "type": "string",
                    "enum": ["ReadWrite", "Read", "Private", "ControlledByParent"],
                },
                "enable_activities": {"type": "boolean"},
                "enable_history": {"type": "boolean"},
                "enable_reports": {"type": "boolean"},
                "enable_search": {"type": "boolean"},
            },
        },
    ),
    Tool(
        name="salesforce_manage_field",
        description=(
            "Create or update a custom field on a Salesforce object. "
            "Supports Text, Number, Currency, Date, Picklist, Lookup, MasterDetail, Formula, and more."
        ),
        inputSchema={
            "type": "object",
            "required": ["operation", "object_api_name", "api_name", "type", "label"],
            "properties": {
                "operation": {"type": "string", "enum": ["create", "update"]},
                "object_api_name": {"type": "string", "description": "Parent object API name"},
                "api_name": {"type": "string", "description": "Field API name (without __c)"},
                "type": {
                    "type": "string",
                    "description": "Field type",
                    "enum": [
                        "Text", "Number", "Currency", "Date", "DateTime", "Time",
                        "Phone", "Email", "Url", "Checkbox", "Percent",
                        "Picklist", "MultiselectPicklist", "TextArea", "LongTextArea", "Html",
                        "Lookup", "MasterDetail", "Formula", "Rollup",
                    ],
                },
                "label": {"type": "string"},
                "description": {"type": "string"},
                "required": {"type": "boolean"},
                "unique": {"type": "boolean"},
                "external_id": {"type": "boolean"},
                "length": {"type": "integer"},
                "precision": {"type": "integer"},
                "scale": {"type": "integer"},
                "picklist_values": {
                    "type": "array",
                    "description": "For Picklist/MultiselectPicklist",
                    "items": {"oneOf": [{"type": "string"}, {"type": "object"}]},
                },
                "reference_to": {"type": "string", "description": "Target object for Lookup/MasterDetail"},
                "relationship_label": {"type": "string"},
                "relationship_name": {"type": "string"},
                "delete_constraint": {"type": "string", "enum": ["SetNull", "Restrict", "Cascade"]},
                "formula": {"type": "string", "description": "Formula expression"},
                "formula_return_type": {"type": "string", "description": "Return type for Formula fields"},
            },
        },
    ),
    Tool(
        name="salesforce_execute_apex",
        description=(
            "Execute anonymous Apex code via the Tooling API. "
            "WARNING: Apex runs with full user permissions and can modify data. Use carefully."
        ),
        inputSchema={
            "type": "object",
            "required": ["apex_code"],
            "properties": {
                "apex_code": {"type": "string", "description": "Apex code to execute"},
                "log_level": {
                    "type": "string",
                    "enum": ["NONE", "ERROR", "WARN", "INFO", "DEBUG", "FINE", "FINER", "FINEST"],
                    "description": "Debug log level (default DEBUG)",
                },
            },
        },
    ),
    Tool(
        name="salesforce_composite",
        description=(
            "Execute up to 25 Salesforce API sub-requests in a single round trip. "
            "Chain requests using @{referenceId.field} syntax. "
            "Ideal for creating related records atomically."
        ),
        inputSchema={
            "type": "object",
            "required": ["requests"],
            "properties": {
                "requests": {
                    "type": "array",
                    "maxItems": 25,
                    "items": {
                        "type": "object",
                        "required": ["reference_id", "method", "url"],
                        "properties": {
                            "reference_id": {"type": "string", "description": "Unique ID for this sub-request"},
                            "method": {"type": "string", "enum": ["GET", "POST", "PATCH", "DELETE"]},
                            "url": {"type": "string", "description": "Relative SF REST API URL"},
                            "body": {"type": "object", "description": "Request body for POST/PATCH"},
                        },
                    },
                },
                "all_or_none": {"type": "boolean", "description": "Roll back all on any failure (default false)"},
                "collate_subrequests": {"type": "boolean", "description": "Allow Salesforce to reorder requests (default true)"},
            },
        },
    ),
    Tool(
        name="salesforce_get_limits",
        description=(
            "Get current Salesforce org governor limit usage. "
            "Highlights limits above 80% (warning) and 95% (critical). Cached 60 seconds."
        ),
        inputSchema={"type": "object", "properties": {}},
    ),
]

_HANDLERS = {
    "salesforce_query_records": handle_query_records,
    "salesforce_search_all": handle_search_all,
    "salesforce_dml_records": handle_dml_records,
    "salesforce_bulk_job": handle_bulk_job,
    "salesforce_describe_object": handle_describe_object,
    "salesforce_search_objects": handle_search_objects,
    "salesforce_metadata_list": handle_metadata_list,
    "salesforce_metadata_read": handle_metadata_read,
    "salesforce_metadata_deploy": handle_metadata_deploy,
    "salesforce_manage_object": handle_manage_object,
    "salesforce_manage_field": handle_manage_field,
    "salesforce_execute_apex": handle_execute_apex,
    "salesforce_composite": handle_composite,
    "salesforce_get_limits": handle_get_limits,
}


def create_server() -> Server:
    server = Server("sfdc-mcp")
    auth_provider = create_auth_provider()
    sf_client = SalesforceClient(auth_provider=auth_provider)

    @server.list_tools()
    async def list_tools() -> list[Tool]:
        return TOOLS

    @server.call_tool()
    async def call_tool(name: str, arguments: dict) -> list[TextContent]:
        handler = _HANDLERS.get(name)
        if handler is None:
            return [TextContent(type="text", text=f'{{"error": true, "message": "Unknown tool: {name}"}}')]

        # next_page_token on query_records means "give me the next batch"
        if name == "salesforce_query_records" and arguments.get("next_page_token"):
            result = await handle_query_next_page(sf_client, arguments)
        else:
            result = await handler(sf_client, arguments)

        return [TextContent(type="text", text=result)]

    return server


async def _run() -> None:
    server = create_server()
    logger.info("sfdc-mcp server starting (auth_type=%s)", os.environ.get("SALESFORCE_AUTH_TYPE", "username_password"))
    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream, server.create_initialization_options())


def main() -> None:
    import asyncio
    asyncio.run(_run())


if __name__ == "__main__":
    main()
