"""Turn raw SF errors into something a human (or LLM) can actually act on."""
from __future__ import annotations

from typing import Any

_ERROR_HINTS: dict[str, str] = {
    "INVALID_SESSION_ID": "Session expired. Re-authenticate and retry.",
    "INVALID_FIELD": "One or more field names are invalid. Use salesforce_describe_object to verify field API names.",
    "INVALID_TYPE": "Object name is invalid. Use salesforce_search_objects to find the correct API name.",
    "REQUIRED_FIELD_MISSING": "A required field is missing from the record. Check the object's required fields with salesforce_describe_object.",
    "FIELD_INTEGRITY_EXCEPTION": "A field value violates an integrity constraint (e.g. picklist value not in allowed list).",
    "DUPLICATE_VALUE": "A record with this value already exists. Check uniqueness constraints.",
    "STRING_TOO_LONG": "A field value exceeds the maximum length. Check field length limits with salesforce_describe_object.",
    "CANNOT_INSERT_UPDATE_ACTIVATE_ENTITY": "A trigger or validation rule blocked this operation. Check the org's Apex triggers.",
    "UNABLE_TO_LOCK_ROW": "Record locked by another process. Retry after a brief delay.",
    "REQUEST_LIMIT_EXCEEDED": "API request limit reached. Use salesforce_get_limits to check remaining quota.",
    "QUERY_TIMEOUT": "SOQL query timed out (>120s). Add a WHERE clause or index to reduce result set.",
    "MALFORMED_QUERY": "The SOQL query is syntactically invalid. Check field names, operators, and quote escaping.",
    "INSUFFICIENT_ACCESS_ON_CROSS_REFERENCE_ENTITY": "Insufficient access to a related record. Check object/field permissions.",
    "ENTITY_IS_DELETED": "The target record has been deleted. Query with ALL ROWS to include deleted records.",
    "INVALID_CROSS_REFERENCE_KEY": "An ID field references a non-existent or inaccessible record.",
}


def enrich_error(exc: Exception) -> dict[str, Any]:
    from simple_salesforce.exceptions import SalesforceError

    if isinstance(exc, SalesforceError):
        content = getattr(exc, "content", None)
        if isinstance(content, list) and content:
            code = content[0].get("errorCode", "UNKNOWN")
            message = content[0].get("message", str(exc))
            fields = content[0].get("fields", [])
        else:
            code = "UNKNOWN"
            message = str(exc)
            fields = []

        hint = _ERROR_HINTS.get(code, "")
        return {
            "error": True,
            "error_code": code,
            "message": message,
            "fields": fields,
            "hint": hint,
        }

    return {
        "error": True,
        "error_code": type(exc).__name__,
        "message": str(exc),
        "fields": [],
        "hint": "",
    }
