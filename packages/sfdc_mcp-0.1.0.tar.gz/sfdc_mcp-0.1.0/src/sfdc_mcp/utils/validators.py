"""Input validation helpers — catch bad values before they hit the SF API."""
from __future__ import annotations

import re

_API_NAME_RE = re.compile(r"^[A-Za-z][A-Za-z0-9_]*(__c|__mdt|__e|__b|__x|__kav)?$")


def validate_api_name(name: str, label: str = "API name") -> str:
    if not _API_NAME_RE.match(name):
        raise ValueError(
            f"Invalid {label} '{name}'. Must start with a letter, contain only "
            "alphanumeric/underscore chars, and optionally end with a Salesforce suffix "
            "(__c, __mdt, __e, __b, __x, __kav)."
        )
    return name


def validate_sosl_term(term: str) -> str:
    """Escape special SOSL characters in search terms."""
    # SOSL special chars: ? & | ! { } [ ] ( ) ^ ~ * : \ " ' + -
    special = r'?&|!{}[]()^~*:\"+\-'
    escaped = ""
    for ch in term:
        if ch in special:
            escaped += "\\" + ch
        else:
            escaped += ch
    return escaped


def validate_limit(value: int | None, default: int = 200, max_val: int = 2000) -> int:
    if value is None:
        return default
    if not isinstance(value, int) or value < 1:
        raise ValueError(f"limit must be a positive integer, got {value!r}")
    if value > max_val:
        raise ValueError(f"limit {value} exceeds maximum allowed {max_val}")
    return value
