"""SOQL builder — validates field names and escapes values so we don't accidentally inject anything."""
from __future__ import annotations

import re
from typing import Any


_ALLOWED_OPS = frozenset(["=", "!=", "<", "<=", ">", ">=", "LIKE", "IN", "NOT IN", "INCLUDES", "EXCLUDES"])

# field names: letters/digits/underscores, up to 5 levels of dot notation for relationships
_FIELD_RE = re.compile(r"^[A-Za-z][A-Za-z0-9_]*(\.[A-Za-z][A-Za-z0-9_]*){0,5}$")

_SUBQUERY_RE = re.compile(r"^\(SELECT .+ FROM .+\)$", re.IGNORECASE)


def escape_string(value: str) -> str:
    """Escape single quotes in SOQL string literals."""
    return value.replace("\\", "\\\\").replace("'", "\\'")


def validate_field_name(field: str) -> str:
    """Validate a field name or relationship path. Raises ValueError on invalid input."""
    if _SUBQUERY_RE.match(field.strip()):
        return field  # subqueries pass through as-is
    if not _FIELD_RE.match(field):
        raise ValueError(
            f"Invalid SOQL field name: '{field}'. "
            "Field names must match [A-Za-z][A-Za-z0-9_]* with optional dot-notation depth ≤5."
        )
    return field


def build_soql(
    object_name: str,
    fields: list[str] | None = None,
    where: str | None = None,
    order_by: str | None = None,
    limit: int | None = None,
    offset: int | None = None,
) -> str:
    if not object_name or not re.match(r"^[A-Za-z][A-Za-z0-9_]*$", object_name):
        raise ValueError(f"Invalid object name: '{object_name}'")

    select_fields = ", ".join(validate_field_name(f) for f in (fields or ["Id"]))
    soql = f"SELECT {select_fields} FROM {object_name}"

    if where:
        soql += f" WHERE {where}"

    if order_by:
        # validate field names only — strip ASC/DESC/NULLS FIRST/LAST before checking
        parts = [p.strip() for p in order_by.split(",")]
        validated_parts = []
        for part in parts:
            tokens = part.split()
            field = tokens[0]
            validate_field_name(field)
            validated_parts.append(part)
        soql += f" ORDER BY {', '.join(validated_parts)}"

    if limit is not None:
        if not isinstance(limit, int) or limit < 1:
            raise ValueError(f"LIMIT must be a positive integer, got {limit!r}")
        soql += f" LIMIT {limit}"

    if offset is not None:
        if not isinstance(offset, int) or offset < 0:
            raise ValueError(f"OFFSET must be a non-negative integer, got {offset!r}")
        soql += f" OFFSET {offset}"

    return soql


def format_value(value: Any) -> str:
    """Format a Python value as a SOQL literal."""
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (int, float)):
        return str(value)
    if isinstance(value, list):
        formatted = ", ".join(format_value(v) for v in value)
        return f"({formatted})"
    return f"'{escape_string(str(value))}'"
