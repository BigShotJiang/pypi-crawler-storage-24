"""Token bucket rate limiter — keeps us from hammering the SF API limit."""
from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field


@dataclass
class TokenBucket:

    rate_per_minute: float = 100.0
    burst: float = 15.0
    _tokens: float = field(init=False)
    _last_refill: float = field(init=False)
    _lock: asyncio.Lock = field(init=False)

    def __post_init__(self) -> None:
        self._tokens = self.burst
        self._last_refill = time.monotonic()
        self._lock = asyncio.Lock()

    def _refill(self) -> None:
        now = time.monotonic()
        elapsed = now - self._last_refill
        refill = elapsed * (self.rate_per_minute / 60.0)
        self._tokens = min(self.burst, self._tokens + refill)
        self._last_refill = now

    async def acquire(self, tokens: float = 1.0) -> None:
        while True:
            async with self._lock:
                self._refill()
                if self._tokens >= tokens:
                    self._tokens -= tokens
                    return
                deficit = tokens - self._tokens
                wait_secs = deficit / (self.rate_per_minute / 60.0)

            await asyncio.sleep(wait_secs)


# one shared bucket for the whole process
_default_bucket: TokenBucket | None = None


def get_bucket() -> TokenBucket:
    global _default_bucket
    if _default_bucket is None:
        import os
        rpm = float(os.environ.get("SALESFORCE_RATE_LIMIT_PER_MINUTE", "100"))
        _default_bucket = TokenBucket(rate_per_minute=rpm, burst=min(rpm, 15))
    return _default_bucket


async def throttle(tokens: float = 1.0) -> None:
    await get_bucket().acquire(tokens)
