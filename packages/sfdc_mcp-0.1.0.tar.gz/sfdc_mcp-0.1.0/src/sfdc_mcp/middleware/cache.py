"""TTL caches — describe results stay fresh for 5 min, limits for 1 min."""
from __future__ import annotations

import asyncio
from typing import Any, Callable

from cachetools import TTLCache

# different TTLs because describe rarely changes, limits flip every minute
_describe_cache: TTLCache = TTLCache(maxsize=256, ttl=300)   # 5 min
_global_cache: TTLCache = TTLCache(maxsize=4, ttl=600)       # 10 min
_limits_cache: TTLCache = TTLCache(maxsize=4, ttl=60)        # 1 min

_cache_lock = asyncio.Lock()


async def get_or_set(cache: TTLCache, key: Any, factory: Callable) -> Any:
    async with _cache_lock:
        if key in cache:
            return cache[key]
    # run the factory outside the lock — no point blocking the whole cache for a slow SF call
    value = await factory()
    async with _cache_lock:
        cache[key] = value
    return value


def invalidate_describe(org_id: str, object_name: str) -> None:
    key = (org_id, object_name.lower())
    _describe_cache.pop(key, None)


def invalidate_global(org_id: str) -> None:
    key = (org_id, "global")
    _global_cache.pop(key, None)


def invalidate_all(org_id: str) -> None:
    invalidate_global(org_id)
    # cachetools doesn't support prefix deletes, so we filter manually
    stale = [k for k in _describe_cache if k[0] == org_id]
    for k in stale:
        _describe_cache.pop(k, None)
