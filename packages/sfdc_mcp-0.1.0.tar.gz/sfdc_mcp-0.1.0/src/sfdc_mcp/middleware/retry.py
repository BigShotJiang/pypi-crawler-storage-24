"""Retry with exponential backoff — only for errors that are actually worth retrying."""
from __future__ import annotations

import logging
from typing import Any, Callable

from tenacity import (
    RetryCallState,
    retry,
    retry_if_exception,
    stop_after_attempt,
    wait_exponential_jitter,
)

logger = logging.getLogger(__name__)

# safe to retry — these are transient
_RETRYABLE_SF_CODES = frozenset(
    [
        "REQUEST_LIMIT_EXCEEDED",
        "RATE_LIMIT_EXCEEDED",
        "SERVER_UNAVAILABLE",
        "UNABLE_TO_LOCK_ROW",
        "QUERY_TIMEOUT",
        "STORAGE_LIMIT_EXCEEDED",  # rare but transient in multi-tenant
    ]
)

# retrying these is pointless — the error won't go away on its own
_PERMANENT_SF_CODES = frozenset(
    [
        "INVALID_FIELD",
        "INVALID_TYPE",
        "REQUIRED_FIELD_MISSING",
        "FIELD_INTEGRITY_EXCEPTION",
        "DUPLICATE_VALUE",
        "ENTITY_IS_DELETED",
        "INVALID_ID_FIELD",
        "MALFORMED_ID",
        "INVALID_QUERY_FILTER_OPERATOR",
    ]
)


def _is_retryable(exc: BaseException) -> bool:
    """Return True if exception represents a transient Salesforce error."""
    import httpx
    from simple_salesforce.exceptions import SalesforceError

    # HTTP 429 / 503
    if isinstance(exc, httpx.HTTPStatusError):
        return exc.response.status_code in (429, 503, 502, 504)

    if isinstance(exc, SalesforceError):
        content = getattr(exc, "content", None)
        if isinstance(content, list) and content:
            code = content[0].get("errorCode", "")
            if code in _PERMANENT_SF_CODES:
                return False
            if code in _RETRYABLE_SF_CODES:
                return True
        return False

    # Network-level transient errors
    if isinstance(exc, (ConnectionError, TimeoutError)):
        return True

    return False


def _log_retry(state: RetryCallState) -> None:
    exc = state.outcome.exception() if state.outcome else None
    logger.warning(
        "Retrying SF call (attempt %d): %s",
        state.attempt_number,
        exc,
    )


def sf_retry(func: Callable[..., Any]) -> Callable[..., Any]:
    return retry(
        retry=retry_if_exception(_is_retryable),
        stop=stop_after_attempt(3),
        wait=wait_exponential_jitter(initial=1, max=30, jitter=2),
        before_sleep=_log_retry,
        reraise=True,
    )(func)
