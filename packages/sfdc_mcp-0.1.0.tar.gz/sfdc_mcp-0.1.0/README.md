# sfdc-mcp

Salesforce MCP server built in Python.

## Installation

```bash
pip install sfdc-mcp
```

Or with uvx (no permanent install):
```bash
uvx sfdc-mcp
```

---

## Configuration

Set credentials as environment variables or create a `.env` file in your working directory.

**If you cloned the repo:**
```bash
cp .env.example .env
# then edit .env with your credentials
```

**If you installed via pip/uvx:**

Create a `.env` file in the directory where you'll run `sfdc-mcp`:

macOS / Linux:
```bash
touch .env
open .env        # or use: nano .env
```

Windows:
```powershell
notepad .env
```

Then paste your credentials (see auth types below) and save. Alternatively, skip the `.env` file and pass credentials directly as environment variables (see the [Claude Desktop](#claude-desktop) section for an example).

### Auth types

**Username + Password + Security Token**
```env
SALESFORCE_AUTH_TYPE=username_password
SALESFORCE_USERNAME=user@example.com
SALESFORCE_PASSWORD=yourpassword
SALESFORCE_SECURITY_TOKEN=yourtoken
SALESFORCE_INSTANCE_URL=https://login.salesforce.com
```

> If your org enforces My Domain Login, set `SALESFORCE_INSTANCE_URL` to your My Domain URL:
> ```
> SALESFORCE_INSTANCE_URL=https://mycompany.my.salesforce.com
> # sandbox:
> SALESFORCE_INSTANCE_URL=https://mycompany--sandbox.sandbox.my.salesforce.com
> ```
> The server authenticates via the URL you configure — it does not fall back to `login.salesforce.com`.

**JWT Bearer** (no user interaction — suitable for CI/CD)
```env
SALESFORCE_AUTH_TYPE=jwt_bearer
SALESFORCE_CLIENT_ID=your_connected_app_consumer_key
SALESFORCE_PRIVATE_KEY_PATH=/path/to/server.key
SALESFORCE_USERNAME=user@example.com
SALESFORCE_INSTANCE_URL=https://mycompany.my.salesforce.com
```

Requires a Connected App with `Authorize pre-approved users` enabled and the user's profile added to the app.

**OAuth2 Web Flow** (interactive browser auth)
```env
SALESFORCE_AUTH_TYPE=oauth_web
SALESFORCE_CLIENT_ID=your_connected_app_consumer_key
SALESFORCE_CLIENT_SECRET=your_secret
SALESFORCE_INSTANCE_URL=https://login.salesforce.com
```

**Direct Access Token**
```env
SALESFORCE_AUTH_TYPE=access_token
SALESFORCE_ACCESS_TOKEN=00D...
SALESFORCE_INSTANCE_URL=https://yourorg.my.salesforce.com
```

### Additional settings

```env
SALESFORCE_API_VERSION=59.0           # default: 59.0
SALESFORCE_BULK_THRESHOLD=200         # records at or above this go to Bulk API v2.0
SALESFORCE_RATE_LIMIT_PER_MINUTE=100  # API calls per minute
```

---

## Testing your connection

If you cloned the repo, run the included test script:

```bash
python test_connection.py
```

Runs four checks: authentication, governor limits, object describe (Account), and a basic SOQL query.

If you installed via pip, you can verify the connection by running the server directly — Claude Desktop or any MCP client will show an error on startup if credentials are wrong.

---

## Claude Desktop

Add to `~/Library/Application Support/Claude/claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "sfdc-mcp": {
      "command": "uvx",
      "args": ["sfdc-mcp"],
      "env": {
        "SALESFORCE_AUTH_TYPE": "username_password",
        "SALESFORCE_USERNAME": "user@example.com",
        "SALESFORCE_PASSWORD": "yourpassword",
        "SALESFORCE_SECURITY_TOKEN": "yourtoken",
        "SALESFORCE_INSTANCE_URL": "https://mycompany.my.salesforce.com"
      }
    }
  }
}
```

Restart Claude Desktop after editing the config.

---

## Tools

| Tool | Description |
|---|---|
| `salesforce_query_records` | SOQL with pagination — raw or structured (`object + fields + where + order_by + limit + offset`) |
| `salesforce_search_all` | SOSL cross-object full-text search |
| `salesforce_dml_records` | Insert / update / delete / upsert — auto-switches to Bulk API at threshold |
| `salesforce_bulk_job` | Manage Bulk API v2.0 jobs directly (create / poll / results / abort) |
| `salesforce_describe_object` | Object schema: fields, relationships, picklists — with filtering and pagination |
| `salesforce_search_objects` | Find objects by name or label pattern |
| `salesforce_metadata_list` | List metadata components by type |
| `salesforce_metadata_read` | Read raw metadata XML |
| `salesforce_metadata_deploy` | Deploy metadata components |
| `salesforce_manage_object` | Create / update custom objects |
| `salesforce_manage_field` | Create / update custom fields (18 types incl. Formula, Rollup, DependentPicklist) |
| `salesforce_execute_apex` | Execute Anonymous Apex via Tooling API |
| `salesforce_composite` | Batch up to 25 API calls in one round trip with cross-request references |
| `salesforce_get_limits` | View current org governor limit usage |

### `salesforce_describe_object` parameters

| Parameter | Type | Description |
|---|---|---|
| `object_name` | string | API name of the object (required) |
| `field_filter` | string | Glob pattern on field API names (e.g. `*Address*`, `LILT_*`) |
| `field_type_filter` | string | Comma-separated field types (e.g. `reference,picklist`) |
| `custom_fields_only` | boolean | Return only `__c` fields |
| `fields_limit` | integer | Max fields to return |
| `fields_offset` | integer | Skip N fields (for pagination) |

---

## Bulk API

DML operations automatically route based on record count:

| Record count | API |
|---|---|
| < 200 | REST Collections API (synchronous) |
| ≥ 200 | Bulk API v2.0 (asynchronous) |

Override the threshold via `SALESFORCE_BULK_THRESHOLD` or the `bulk_threshold` parameter per call.

---

## Governor Limits

The server tracks org limits and warns when approaching them (warning at 80%, critical at 95%). Use `salesforce_get_limits` to check current usage.

---

## Authentication errors

Common errors and the hints the server returns:

| Error | Hint |
|---|---|
| `INVALID_LOGIN` | Wrong credentials or security token; My Domain suggestion if using generic login URL |
| `MUST_USE_ORG_DOMAIN` | Set `SALESFORCE_INSTANCE_URL` to your My Domain URL |
| `INACTIVE_USER` | Account locked — contact your Salesforce admin |
| `PASSWORD_LOCKOUT` | Too many failed attempts — reset via the SF login page |
| `invalid_client_id` (JWT) | Connected App consumer key is wrong or the app is inactive |
| `invalid_grant` (JWT) | User not pre-authorized — add profile/permission set to the Connected App |
| `invalid_client` (JWT) | Private key does not match the certificate uploaded to the Connected App |

---

## Local LLM (Ollama)

Chat with your Salesforce org using a local model.

### Setup

1. Install [Ollama](https://ollama.com/)
2. Pull a model: `ollama pull llama3.1:8b`
3. Install extras: `pip install -e '.[local_llm]'`
4. Configure credentials in `.env` (see [Configuration](#configuration))

### Run

```bash
python local_llm/chat.py                       # llama3.1:8b by default
python local_llm/chat.py --model qwen2.5-coder:7b
```

The client starts the sfdc-mcp server as a subprocess, converts all 14 tools to Ollama function-calling format, and shows tool calls in real time.

### Recommended models

| Model | Notes |
|---|---|
| `llama3.1:8b` | Good general-purpose tool calling |
| `qwen2.5-coder:7b` | Better for Apex and SOQL |
| `mistral-nemo` | Faster responses |

---

## Development

```bash
git clone https://github.com/pdpraful/sfdc-mcp
cd sfdc-mcp
pip install -e '.[dev]'
pytest
```

---

## Comparison

| Area | Other | sfdc-mcp |
|---|---|---|
| Language | TypeScript | Python |
| SF library | jsforce (unmaintained) | simple-salesforce |
| Auth methods | 2 | 4 |
| My Domain Login Enforcement | Fails | Supported |
| Pagination | No | Yes |
| Bulk API | No | Bulk API v2.0, auto-switch |
| Rate limiting | No | Token bucket |
| Retry | No | Exponential backoff (tenacity) |
| Describe caching | No | TTL cache (5 min) |
| Governor limit tracking | No | Yes — warns at 80%/95% |
| SOQL injection protection | No | Parameterized builder |
| Metadata API | Basic | Full (list / read / deploy) |
| Execute Apex | No | Yes (Tooling API) |
| Composite API | No | Yes (up to 25 sub-requests) |
| Local LLM | No | Ollama bridge |
| Tools | 7 | 14 |
