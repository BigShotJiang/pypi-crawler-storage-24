"""
Quick connection test — run this to verify your Salesforce credentials work
before wiring up the full MCP server.

Usage:
    python3 test_connection.py
"""
import asyncio
import json
import os
import sys

from dotenv import load_dotenv

load_dotenv()

sys.path.insert(0, "src")


async def main():
    from sfdc_mcp.auth import create_auth_provider
    from sfdc_mcp.client.salesforce import SalesforceClient

    print("=" * 55)
    print("  sfdc-mcp connection test")
    print("=" * 55)

    auth_type = os.environ.get("SALESFORCE_AUTH_TYPE", "username_password")
    print(f"\nAuth type   : {auth_type}")
    print(f"Instance URL: {os.environ.get('SALESFORCE_INSTANCE_URL', 'https://login.salesforce.com')}")
    print(f"Username    : {os.environ.get('SALESFORCE_USERNAME', '(not set)')}")
    print()

    # ── Step 1: Auth ──────────────────────────────────────────────────────────
    print("[ 1/4 ] Authenticating...", end=" ", flush=True)
    try:
        auth = create_auth_provider()
        session = await auth.get_session()
        print("OK")
        print(f"         Instance : {session.instance_url}")
        print(f"         Token    : {session.access_token[:8]}...{session.access_token[-4:]}")
    except Exception as e:
        print(f"FAILED\n\n  Error: {e}")
        print("\n  Tips:")
        print("  - Check SALESFORCE_USERNAME / PASSWORD / SECURITY_TOKEN in .env")
        print("  - For sandbox use SALESFORCE_INSTANCE_URL=https://test.salesforce.com")
        print("  - Security token is separate from password — check Setup > My Personal Info > Reset Security Token")
        sys.exit(1)

    client = SalesforceClient(auth_provider=auth)

    # ── Step 2: Governor limits ───────────────────────────────────────────────
    print("\n[ 2/4 ] Fetching governor limits...", end=" ", flush=True)
    try:
        limits = await client.get_limits()
        daily = limits.get("DailyApiRequests", {})
        print("OK")
        print(f"         Daily API requests: {daily.get('used', '?')} / {daily.get('max', '?')} used ({daily.get('used_pct', '?')}%)")
        warnings = [v for v in limits.values() if v.get("status") in ("warning", "critical")]
        if warnings:
            for w in warnings:
                print(f"         ⚠️  {w['name']}: {w['used_pct']}% used")
        else:
            print("         All limits healthy")
    except Exception as e:
        print(f"FAILED — {e}")

    # ── Step 3: Describe a standard object ───────────────────────────────────
    print("\n[ 3/4 ] Describing Account object...", end=" ", flush=True)
    try:
        from sfdc_mcp.tools.describe import handle_describe_object
        result = json.loads(await handle_describe_object(client, {"object_name": "Account", "include_relationships": False}))
        if result.get("error"):
            print(f"FAILED — {result['message']}")
        else:
            print("OK")
            print(f"         Label      : {result['label']}")
            print(f"         Fields     : {result['field_count']}")
            print(f"         Createable : {result['createable']}")
    except Exception as e:
        print(f"FAILED — {e}")

    # ── Step 4: Run a simple SOQL query ──────────────────────────────────────
    print("\n[ 4/4 ] Running test SOQL query...", end=" ", flush=True)
    try:
        from sfdc_mcp.tools.query import handle_query_records
        result = json.loads(await handle_query_records(client, {
            "object_name": "User",
            "fields": ["Id", "Name", "Username"],
            "where": "IsActive = true",
            "limit": 3,
        }))
        if result.get("error"):
            print(f"FAILED — {result['message']}")
        else:
            print("OK")
            print(f"         Total active users: {result['total_size']}")
            for r in result["records"]:
                print(f"           • {r.get('Name')} ({r.get('Username')})")
    except Exception as e:
        print(f"FAILED — {e}")

    print("\n" + "=" * 55)
    print("  Connection test complete — ready to use with Claude!")
    print("=" * 55)
    print()
    print("Next: add this to your Claude Desktop config:")
    print()
    print('  "salesforce": {')
    print('    "command": "sfdc-mcp",')
    print(f'    "env": {{ "SALESFORCE_AUTH_TYPE": "{auth_type}", ... }}')
    print("  }")
    print()


if __name__ == "__main__":
    asyncio.run(main())
