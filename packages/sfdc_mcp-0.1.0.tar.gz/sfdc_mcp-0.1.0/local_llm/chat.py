"""
Chat with Salesforce using a local Ollama model.

Starts sfdc-mcp as a subprocess, hands the tools to Ollama, and runs
an interactive loop so the model can query your org without sending data anywhere.

Usage:
    python3 chat.py
    python3 chat.py --model llama3.1:8b
    python3 chat.py --model gpt-oss:20b
"""
from __future__ import annotations

import argparse
import asyncio
import json
import os
import sys

import ollama
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

DEFAULT_MODEL = "llama3.1:8b"

SYSTEM_PROMPT = """You are a Salesforce assistant with access to live Salesforce data.
Use the available tools to answer questions accurately. When querying data:
- Always use the describe tool first if you're unsure of field names
- Be concise but complete in your responses
- Format results as clean tables or lists when appropriate"""

ENV = {
    "SALESFORCE_AUTH_TYPE": os.environ.get("SALESFORCE_AUTH_TYPE", "username_password"),
    "SALESFORCE_USERNAME": os.environ.get("SALESFORCE_USERNAME", ""),
    "SALESFORCE_PASSWORD": os.environ.get("SALESFORCE_PASSWORD", ""),
    "SALESFORCE_SECURITY_TOKEN": os.environ.get("SALESFORCE_SECURITY_TOKEN", ""),
    "SALESFORCE_INSTANCE_URL": os.environ.get("SALESFORCE_INSTANCE_URL", "https://login.salesforce.com"),
    "SALESFORCE_API_VERSION": os.environ.get("SALESFORCE_API_VERSION", "59.0"),
    "SALESFORCE_BULK_THRESHOLD": os.environ.get("SALESFORCE_BULK_THRESHOLD", "200"),
    "SALESFORCE_RATE_LIMIT_PER_MINUTE": os.environ.get("SALESFORCE_RATE_LIMIT_PER_MINUTE", "100"),
}


def mcp_tool_to_ollama(tool) -> dict:
    return {
        "type": "function",
        "function": {
            "name": tool.name,
            "description": tool.description or "",
            "parameters": tool.inputSchema or {"type": "object", "properties": {}},
        },
    }


def _extract_tool_calls(msg, tool_names: set[str]) -> list | None:
    # some models (llama3.1:8b) dump tool calls as JSON in content instead of tool_calls
    # this handles both so we don't have to care which format we got
    if msg.tool_calls:  # lucky path — proper tool_calls structure
        return [(tc.function.name, tc.function.arguments) for tc in msg.tool_calls]

    # fallback: try parsing content as a JSON tool call
    content = (msg.content or "").strip()
    if not content:
        return None

    # some models wrap the JSON in markdown fences
    if content.startswith("```"):
        content = "\n".join(
            line for line in content.splitlines()
            if not line.strip().startswith("```")
        ).strip()

    try:
        parsed = json.loads(content)
    except (json.JSONDecodeError, ValueError):
        return None

    # Single tool call: {"name": "...", "parameters": {...}}
    if isinstance(parsed, dict):
        name = parsed.get("name") or parsed.get("function")
        args = parsed.get("parameters") or parsed.get("arguments") or parsed.get("args") or {}
        if name and name in tool_names:
            return [(name, args)]

    # List of tool calls
    if isinstance(parsed, list):
        calls = []
        for item in parsed:
            name = item.get("name") or item.get("function")
            args = item.get("parameters") or item.get("arguments") or item.get("args") or {}
            if name and name in tool_names:
                calls.append((name, args))
        return calls if calls else None

    return None


async def chat(model: str) -> None:
    server_params = StdioServerParameters(
        command=sys.executable,
        args=["-m", "sfdc_mcp.server"],
        env={**os.environ, **ENV},
    )

    print(f"\n  sfdc-mcp  ×  Ollama ({model})")
    print("  Type your question, or 'quit' to exit.\n")

    async with stdio_client(server_params) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()

            tools_response = await session.list_tools()
            ollama_tools = [mcp_tool_to_ollama(t) for t in tools_response.tools]
            tool_names = {t.name for t in tools_response.tools}

            print(f"  Connected — {len(ollama_tools)} tools available:")
            for t in tools_response.tools:
                print(f"    • {t.name}")
            print()

            messages = [{"role": "system", "content": SYSTEM_PROMPT}]
            client = ollama.AsyncClient()

            while True:
                try:
                    user_input = input("You: ").strip()
                except (EOFError, KeyboardInterrupt):
                    print("\nGoodbye.")
                    break

                if not user_input or user_input.lower() in ("quit", "exit", "q"):
                    print("Goodbye.")
                    break

                messages.append({"role": "user", "content": user_input})

                # keep cycling until the model stops calling tools
                while True:
                    response = await client.chat(
                        model=model,
                        messages=messages,
                        tools=ollama_tools,
                    )

                    msg = response.message
                    tool_calls = _extract_tool_calls(msg, tool_names)

                    # if content was just a JSON blob (not real text), don't store it
                    stored_content = msg.content or ""
                    if tool_calls and not msg.tool_calls:
                        stored_content = ""  # was a JSON tool call, not real text
                    messages.append({"role": "assistant", "content": stored_content, "tool_calls": msg.tool_calls})

                    if not tool_calls:
                        print(f"\nAssistant: {msg.content}\n")
                        break

                    # run through MCP and feed the result back into the conversation
                    for name, args in tool_calls:
                        if isinstance(args, str):
                            try:
                                args = json.loads(args)
                            except json.JSONDecodeError:
                                args = {}
                        args_str = json.dumps(args, ensure_ascii=False)
                        print(f"  [tool] {name}({args_str[:120]}{'...' if len(args_str) > 120 else ''})")
                        if name not in tool_names:
                            tool_result = json.dumps({"error": True, "message": f"Unknown tool: {name}"})
                        else:
                            result = await session.call_tool(name, args)
                            tool_result = result.content[0].text if result.content else "{}"

                        messages.append({"role": "tool", "content": tool_result})


def main() -> None:
    parser = argparse.ArgumentParser(description="Chat with Salesforce via local LLM")
    parser.add_argument("--model", default=DEFAULT_MODEL, help="Ollama model name")
    args = parser.parse_args()

    # pick up credentials from a local .env if running standalone
    env_path = os.path.join(os.path.dirname(__file__), ".env")
    if os.path.exists(env_path):
        with open(env_path) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    k, _, v = line.partition("=")
                    os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))

    asyncio.run(chat(args.model))


if __name__ == "__main__":
    main()
