"""
Phase 3: Ollama Bridge
Connects to Ollama's OpenAI-compatible API and routes tool calls to the MCP server.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
from typing import Any

import httpx

logger = logging.getLogger(__name__)

OLLAMA_BASE_URL = os.environ.get("OLLAMA_BASE_URL", "http://localhost:11434")
OLLAMA_MODEL = os.environ.get("OLLAMA_MODEL", "llama3.1:8b")


# ─── MCP tool → OpenAI tool schema conversion ─────────────────────────────────

def mcp_tools_to_openai_format(mcp_tools: list[dict]) -> list[dict]:
    """Convert MCP tool definitions to OpenAI tool schema format."""
    openai_tools = []
    for tool in mcp_tools:
        openai_tools.append(
            {
                "type": "function",
                "function": {
                    "name": tool["name"],
                    "description": tool.get("description", ""),
                    "parameters": tool.get("inputSchema", {"type": "object", "properties": {}}),
                },
            }
        )
    return openai_tools


# ─── Ollama API client ────────────────────────────────────────────────────────

class OllamaBridge:
    """
    Connects to Ollama via its OpenAI-compatible endpoint.

    Flow:
      1. Send user message + available tools to Ollama
      2. If Ollama returns tool_calls, route each to the MCP server
      3. Feed tool results back to Ollama for final answer
      4. Repeat until no more tool calls
    """

    def __init__(
        self,
        mcp_caller,
        model: str = OLLAMA_MODEL,
        base_url: str = OLLAMA_BASE_URL,
    ) -> None:
        self.mcp_caller = mcp_caller  # MCPToolCaller instance
        self.model = model
        self.base_url = base_url.rstrip("/")
        self._openai_tools: list[dict] | None = None

    async def initialize(self) -> None:
        """Load MCP tool definitions and convert to OpenAI format."""
        mcp_tools = await self.mcp_caller.list_tools()
        self._openai_tools = mcp_tools_to_openai_format(mcp_tools)
        logger.info("Loaded %d tools from MCP server", len(self._openai_tools))

    async def chat(
        self,
        messages: list[dict],
        max_tool_rounds: int = 10,
        on_tool_call=None,  # Optional callback(tool_name, args) -> None
        on_tool_result=None,  # Optional callback(tool_name, result) -> None
    ) -> str:
        """
        Run a full conversation turn with tool calling loop.

        Returns the final text response.
        """
        if self._openai_tools is None:
            await self.initialize()

        conversation = list(messages)
        for round_num in range(max_tool_rounds):
            response = await self._call_ollama(conversation)
            message = response["choices"][0]["message"]

            # No tool calls — we have the final answer
            if not message.get("tool_calls"):
                return message.get("content", "")

            # Append assistant's tool call message
            conversation.append(message)

            # Execute all tool calls in this response
            for tool_call in message["tool_calls"]:
                fn = tool_call["function"]
                tool_name = fn["name"]
                try:
                    args = json.loads(fn.get("arguments", "{}"))
                except json.JSONDecodeError:
                    args = {}

                if on_tool_call:
                    on_tool_call(tool_name, args)

                tool_result = await self.mcp_caller.call_tool(tool_name, args)

                if on_tool_result:
                    on_tool_result(tool_name, tool_result)

                # Append tool result message
                conversation.append(
                    {
                        "role": "tool",
                        "tool_call_id": tool_call["id"],
                        "content": tool_result,
                    }
                )

        return "Reached maximum tool call rounds without a final answer."

    async def _call_ollama(self, messages: list[dict]) -> dict:
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                f"{self.base_url}/v1/chat/completions",
                json={
                    "model": self.model,
                    "messages": messages,
                    "tools": self._openai_tools,
                    "stream": False,
                },
                timeout=120,
            )
        if resp.status_code != 200:
            raise RuntimeError(
                f"Ollama API error [{resp.status_code}]: {resp.text}\n"
                f"Is Ollama running? Try: ollama serve\n"
                f"Model available? Try: ollama pull {self.model}"
            )
        return resp.json()
