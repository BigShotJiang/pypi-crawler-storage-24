"""
Phase 3: MCP Tool Caller
Spawns the sfdc-mcp server as a subprocess and routes tool calls to it via stdio transport.
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import sys
from typing import Any

logger = logging.getLogger(__name__)

MCP_SERVER_CMD = os.environ.get("MCP_SERVER_CMD", "python -m sfdc_mcp")


class MCPToolCaller:
    """
    Communicates with sfdc-mcp server via stdio MCP protocol.

    The server process is started once and kept alive for the session duration.
    """

    def __init__(self, cmd: str = MCP_SERVER_CMD, env: dict | None = None) -> None:
        self.cmd = cmd
        self.env = {**os.environ, **(env or {})}
        self._process: asyncio.subprocess.Process | None = None
        self._request_id = 0
        self._pending: dict[int, asyncio.Future] = {}
        self._reader_task: asyncio.Task | None = None
        self._initialized = False

    async def start(self) -> None:
        """Start the MCP server subprocess and perform MCP initialization."""
        parts = self.cmd.split()
        self._process = await asyncio.create_subprocess_exec(
            *parts,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            env=self.env,
        )
        logger.info("Started MCP server: %s (pid=%d)", self.cmd, self._process.pid)

        # Start background reader
        self._reader_task = asyncio.create_task(self._read_responses())

        # MCP initialization handshake
        init_result = await self._send_request(
            "initialize",
            {
                "protocolVersion": "2024-11-05",
                "capabilities": {"tools": {}},
                "clientInfo": {"name": "sfdc-mcp-phase3", "version": "0.1.0"},
            },
        )
        logger.debug("MCP init result: %s", init_result)
        await self._send_notification("notifications/initialized", {})
        self._initialized = True

    async def stop(self) -> None:
        if self._process and self._process.returncode is None:
            self._process.terminate()
            await self._process.wait()
        if self._reader_task:
            self._reader_task.cancel()

    async def list_tools(self) -> list[dict]:
        result = await self._send_request("tools/list", {})
        tools = result.get("tools", [])
        return [
            {
                "name": t["name"],
                "description": t.get("description", ""),
                "inputSchema": t.get("inputSchema", {}),
            }
            for t in tools
        ]

    async def call_tool(self, name: str, arguments: dict) -> str:
        result = await self._send_request(
            "tools/call",
            {"name": name, "arguments": arguments},
        )
        # MCP returns content as list of {type, text} items
        content = result.get("content", [])
        if content:
            return content[0].get("text", json.dumps(result))
        return json.dumps(result)

    # ─── Internal MCP JSON-RPC over stdio ─────────────────────────────────────

    def _next_id(self) -> int:
        self._request_id += 1
        return self._request_id

    async def _send_request(self, method: str, params: dict, timeout: float = 60.0) -> dict:
        req_id = self._next_id()
        future: asyncio.Future = asyncio.get_running_loop().create_future()
        self._pending[req_id] = future

        message = json.dumps(
            {"jsonrpc": "2.0", "id": req_id, "method": method, "params": params}
        ) + "\n"
        self._process.stdin.write(message.encode())
        await self._process.stdin.drain()

        try:
            result = await asyncio.wait_for(future, timeout=timeout)
        finally:
            self._pending.pop(req_id, None)

        if "error" in result:
            raise RuntimeError(f"MCP error for {method}: {result['error']}")
        return result.get("result", {})

    async def _send_notification(self, method: str, params: dict) -> None:
        message = json.dumps(
            {"jsonrpc": "2.0", "method": method, "params": params}
        ) + "\n"
        self._process.stdin.write(message.encode())
        await self._process.stdin.drain()

    async def _read_responses(self) -> None:
        """Background task: read lines from MCP server stdout and resolve pending futures."""
        try:
            while True:
                line = await self._process.stdout.readline()
                if not line:
                    break
                try:
                    msg = json.loads(line.decode().strip())
                except json.JSONDecodeError:
                    continue

                req_id = msg.get("id")
                if req_id is not None and req_id in self._pending:
                    self._pending[req_id].set_result(msg)
        except asyncio.CancelledError:
            pass
        except Exception as exc:
            logger.error("MCP reader error: %s", exc)
