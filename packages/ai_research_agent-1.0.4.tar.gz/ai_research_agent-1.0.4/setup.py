from setuptools import setup, find_packages

setup(
    name="ai-research-agent",
    version="1.0.4",

    author="Mahdi Haqiqat",
    author_email="mahdihaqiqat55@gmail.com",
    maintainer="Mahdi Haqiqat",
    maintainer_email="mahdihaqiqat@outlook.com",

    packages=find_packages(),
    include_package_data=True,

    install_requires=[
        "ollama",
        "python-dotenv",
        "ddgs",
        "httpx",
        "questionary",
        "python-docx",
        "reportlab",
        "arabic-reshaper",
        "python-bidi",
        "pathlib",
    ],

    entry_points={
        "console_scripts": [
            "ai-research=ai_research_agent.main:main",
        ],
    },

    package_data={
        "ai_research_agent": ["DejaVuSans.ttf", ".env"],
    },

    python_requires=">=3.9",
)