"""Integration tests for OSA."""
