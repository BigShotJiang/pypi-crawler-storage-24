# TLM — AI Tech Lead for Claude Code

> The annoying agent that makes Claude do the right thing.

TLM sits inside [Claude Code](https://claude.ai/code) and enforces TDD, tests, and spec compliance — automatically. It scans your project, identifies gaps, and hooks into Claude to enforce quality.

## Quick Start

```bash
pipx install tlm-cli
tlm auth <your-api-key>
cd your-project
tlm install
```

That's it. Open Claude Code and start working — TLM activates automatically.

## What Happens

1. **`tlm auth <key>`** — Save your API key (one-time)
2. **`tlm install`** — Scans your project, sends to server for assessment, shows gaps, selects quality tier, installs Claude Code hooks
3. **Work in Claude Code** — TLM interviews you before features, enforces TDD, blocks deploys, warns on gaps

## How It Works

TLM scans your project and sends the file tree + samples to the server for assessment. The server returns recommendations (gaps) ranked by severity:

```
Phase 5: Project Gaps (4 found)
┌──────────────────────────────────────────┐
│ critical  CI/CD      No CI/CD pipeline   │
│ critical  Testing    No tests found      │
│ high      Infra      No staging env      │
│ medium    Ops        No monitoring       │
└──────────────────────────────────────────┘
```

You choose a quality tier (high/standard/relaxed) and TLM enforces accordingly.

## Commands

| Command | What it does |
|---------|-------------|
| `tlm auth <key>` | Authenticate with TLM. Shows status if already logged in. |
| `tlm install` | Install TLM in a project: scan, configure, and set up hooks. |
| `tlm scan` | Re-scan project and show updated recommendations. |
| `tlm gaps` | Show active project gaps and their severity. |
| `tlm fix [gap_id]` | Fix a project gap: interview, plan, execute, review. |
| `tlm review spec <path>` | Review a spec/plan file. |
| `tlm review code [commit]` | Review staged changes or a specific commit. |
| `tlm status` | Show TLM project status: config, gaps, enforcement. |
| `tlm logout` | Remove stored TLM credentials. |
| `tlm uninstall` | Remove TLM from this project. |
| `tlm upgrade` | Upgrade TLM CLI to the latest version. |

## Quality Tiers

| Tier | Behavior |
|------|----------|
| **HIGH** | Block on any gap. Spec review required. Multi-model code review. |
| **STANDARD** | Block on critical gaps. Spec review on blockers. Single-model review. |
| **RELAXED** | Warn only. No spec blocking. Mechanical checks only. |

## Hooks

TLM installs 6 Claude Code hooks:

- **session_start** — Loads project context, gaps, quality rules
- **prompt_submit** — Phase-specific guidance, gap warnings
- **guard** (Write/Edit) — Blocks code during interview, enforces TDD
- **compliance** (Bash) — Review gate on git commit
- **deployment** (Bash) — Always blocks deploys until `tlm check` passes
- **stop** — Session cleanup

## License

MIT
