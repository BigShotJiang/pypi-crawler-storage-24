"""Tests for real-time prompt learning + TDD plan enforcement + session learning bug fix.

Covers:
- hook_plan_approved TDD highlighting
- hook_prompt_submit prompt learning (background call + insight injection)
- _learn_prompt_bg CLI dispatch
- client.learn_prompt() method
- _run_session_learning bug fix (wrong argument names)
- Removal of file-level TDD blocking from hook_guard
- settings.json wiring
"""

import json
import time
import pytest
from pathlib import Path
from unittest.mock import patch, MagicMock

from tlm.hooks import (
    hook_auto_interviewer_plan,
    hook_prompt_submit,
    hook_guard,
    hook_stop,
    _run_session_learning,
)
from tlm.state import write_state, read_state
from tlm.config import save_project_config


@pytest.fixture
def tlm_project(tmp_path):
    """Create a project with TLM initialized."""
    tlm_dir = tmp_path / ".tlm"
    tlm_dir.mkdir()
    (tlm_dir / "specs").mkdir()
    (tlm_dir / "cache").mkdir()
    write_state(str(tmp_path), {"phase": "idle"})
    save_project_config(str(tmp_path), {
        "quality_control": "standard",
        "project_id": 42,
    })
    return tmp_path


# ── Step 1: settings.json wiring ─────────────────────────────


class TestSettingsJsonWiring:
    """Verify build_all_hooks() produces the correct hook map."""

    def test_has_core_event_types(self):
        from tlm.hooks_format import build_all_hooks
        hooks = build_all_hooks()
        assert "PreToolUse" in hooks
        assert "PostToolUse" in hooks
        assert "Stop" in hooks

    def test_pre_tool_use_has_bash_firewall(self):
        from tlm.hooks_format import build_all_hooks
        hooks = build_all_hooks()
        pre_entries = hooks["PreToolUse"]
        matchers = {e.get("matcher") for e in pre_entries}
        assert "Bash" in matchers

    def test_post_tool_use_has_plan_review(self):
        from tlm.hooks_format import build_all_hooks
        hooks = build_all_hooks()
        post_entries = hooks["PostToolUse"]
        matchers = {e.get("matcher") for e in post_entries}
        assert "ExitPlanMode" in matchers


# ── Step 2: TDD enforcement at plan level ─────────────────────


class TestPlanApprovedTddHighlight:
    """When server review returns TDD-related issues, hook highlights them."""

    def _mock_client(self, mock_client_fn, review_response):
        mock_client = MagicMock()
        mock_client.review_plan_or_diff.return_value = review_response
        mock_client_fn.return_value = mock_client

    def test_tdd_gap_highlighted_in_plan_review(self, tlm_project, tmp_path):
        """TDD issues from server review should be prominently shown."""
        plans_dir = tmp_path / "plans"
        plans_dir.mkdir()
        (plans_dir / "feature.md").write_text("# Plan\nNo tests mentioned.")

        with patch("tlm.hooks._get_review_client") as mock_client_fn:
            self._mock_client(mock_client_fn, {
                "decision": "pass",
                "reason": "Plan is acceptable",
                "issues": ["Plan does not follow TDD — write tests first"],
            })
            result = hook_auto_interviewer_plan(str(tlm_project), {}, plans_dir=plans_dir)

        ctx = result.get("additionalContext", "")
        assert "TDD" in ctx.upper() or "tdd" in ctx.lower()

    def test_plan_without_tdd_gaps_shows_approved(self, tlm_project, tmp_path):
        """Plans without TDD issues should show normal approved message."""
        plans_dir = tmp_path / "plans"
        plans_dir.mkdir()
        (plans_dir / "feature.md").write_text("# Plan with TDD\nWrite tests first.")

        with patch("tlm.hooks._get_review_client") as mock_client_fn:
            self._mock_client(mock_client_fn, {"decision": "pass", "reason": "Good plan", "issues": []})
            result = hook_auto_interviewer_plan(str(tlm_project), {}, plans_dir=plans_dir)

        ctx = result.get("additionalContext", "")
        assert "Plan Approved" in ctx

    def test_plan_review_shows_reviewing_message(self, tlm_project, tmp_path):
        """Plan review should show a 'reviewing' message to the user."""
        plans_dir = tmp_path / "plans"
        plans_dir.mkdir()
        (plans_dir / "feature.md").write_text("# Plan\nThis is a plan with enough content to pass the minimum length check.")

        with patch("tlm.hooks._get_review_client") as mock_client_fn:
            self._mock_client(mock_client_fn, {"decision": "pass", "reason": "OK", "issues": []})
            result = hook_auto_interviewer_plan(str(tlm_project), {}, plans_dir=plans_dir)

        ctx = result.get("additionalContext", "")
        assert "TLM" in ctx


# ── Step 3: Real-time prompt learning ─────────────────────────


class TestPromptLearningBackgroundCall:
    """hook_prompt_submit should fire background learning call."""

    def test_prompt_captured_to_session_prompts(self, tlm_project):
        """Prompts should be captured to session_prompts.jsonl."""
        hook_prompt_submit(str(tlm_project), "Use PostgreSQL not SQLite")

        prompts_file = tlm_project / ".tlm" / "session_prompts.jsonl"
        assert prompts_file.exists()
        lines = prompts_file.read_text().strip().split("\n")
        entry = json.loads(lines[-1])
        assert entry["prompt"] == "Use PostgreSQL not SQLite"

    @patch("tlm.hooks._fire_prompt_learning_bg")
    def test_background_learning_fired_on_prompt(self, mock_fire, tlm_project):
        """Background prompt learning should be fired when prompt is submitted."""
        hook_prompt_submit(str(tlm_project), "Always use dark mode")
        mock_fire.assert_called_once()

    @patch("tlm.hooks._fire_prompt_learning_bg")
    def test_background_learning_not_fired_without_prompt(self, mock_fire, tlm_project):
        """No background learning when prompt is empty."""
        hook_prompt_submit(str(tlm_project), "")
        mock_fire.assert_not_called()

    def test_background_learning_rate_limited(self, tlm_project):
        """Background calls should be rate-limited (max 1 per 5 seconds)."""
        import tlm.hooks as hooks_mod
        original_ts = hooks_mod._last_prompt_learn_ts

        try:
            # Reset cooldown
            hooks_mod._last_prompt_learn_ts = 0.0

            with patch("tlm.hooks.subprocess.Popen") as mock_popen:
                # First call: should fire
                hooks_mod._last_prompt_learn_ts = 0.0
                hook_prompt_submit(str(tlm_project), "first prompt")
                first_count = mock_popen.call_count

                # Second call immediately: should be rate-limited
                hook_prompt_submit(str(tlm_project), "second prompt immediately")
                second_count = mock_popen.call_count

                assert second_count == first_count  # No additional call
        finally:
            hooks_mod._last_prompt_learn_ts = original_ts


class TestPromptLearningInsightInjection:
    """Cached insights should be injected into subsequent prompts."""

    def test_correction_shown_as_learned(self, tlm_project):
        """New corrections should show LEARNED FROM YOUR FEEDBACK."""
        cache_dir = tlm_project / ".tlm" / "cache"
        cache_dir.mkdir(exist_ok=True)
        insights_file = cache_dir / "realtime_insights.json"
        insights_file.write_text(json.dumps({
            "corrections": [
                {"correction": "Use PostgreSQL, not SQLite", "timestamp": time.time()}
            ],
            "rules": [],
            "shown_corrections": [],
        }))

        result = hook_prompt_submit(str(tlm_project), "What database should I use?")
        ctx = result.get("additionalContext", "")
        assert "LEARNED" in ctx or "PostgreSQL" in ctx

    def test_accumulated_rules_injected_as_context(self, tlm_project):
        """Accumulated learned rules should be injected as additionalContext."""
        cache_dir = tlm_project / ".tlm" / "cache"
        cache_dir.mkdir(exist_ok=True)
        insights_file = cache_dir / "realtime_insights.json"
        insights_file.write_text(json.dumps({
            "corrections": [],
            "rules": [
                {"rule": "Always use PostgreSQL", "confidence": "high"},
                {"rule": "Run tests before committing", "confidence": "high"},
            ],
            "shown_corrections": [],
        }))

        result = hook_prompt_submit(str(tlm_project), "Let's build the DB")
        ctx = result.get("additionalContext", "")
        assert "PostgreSQL" in ctx or "TLM" in ctx


# ── Step 3b: Client method ────────────────────────────────────


class TestClientLearnPrompt:
    """TLMClient.learn_prompt() method."""

    def test_learn_prompt_method_exists(self):
        from tlm.client import TLMClient
        client = TLMClient(server_url="http://test", api_key="test")
        assert hasattr(client, "learn_prompt")

    @patch("httpx.post")
    def test_learn_prompt_calls_correct_endpoint(self, mock_post):
        from tlm.client import TLMClient
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = {
            "quick_insights": [],
            "corrections_detected": [],
            "is_correction": False,
        }
        mock_post.return_value = mock_resp

        client = TLMClient(server_url="http://test:8003", api_key="tlm_sk_abc")
        result = client.learn_prompt(prompt="Use PostgreSQL", project_id=42)

        mock_post.assert_called_once()
        call_url = mock_post.call_args[0][0]
        assert "/api/v2/learn/prompt" in call_url


# ── Step 3d: CLI dispatch ─────────────────────────────────────


class TestCLILearnPromptBg:
    """CLI should dispatch _learn_prompt_bg hook."""

    def test_learn_prompt_bg_dispatch_exists(self):
        """The _learn_prompt_bg hook name should be handled in cli.py."""
        # We test this by importing and checking the hook_dispatch command handles it
        from click.testing import CliRunner
        from tlm.cli import main

        runner = CliRunner()
        # Running with non-existent hook should fail
        result = runner.invoke(main, ["_hook", "nonexistent_hook"])
        assert result.exit_code != 0

        # Running _learn_prompt_bg should not raise "Unknown hook"
        # (it may fail for other reasons like missing stdin, but not "Unknown hook")
        result = runner.invoke(main, ["_hook", "_learn_prompt_bg"], input="{}")
        assert "Unknown hook" not in (result.output or "")


# ── Step 4: Session learning bug fix ──────────────────────────


class TestSessionLearningBugFix:
    """_run_session_learning should use sync_session correctly."""

    @patch("tlm.hooks._get_review_client")
    def test_calls_sync_session_with_summary(self, mock_get_client, tlm_project):
        """Should call client.sync_session(project_id, summary_str)."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client

        prompts = [
            {"prompt": "Add auth", "timestamp": 1000, "phase": "idle"},
            {"prompt": "Use JWT", "timestamp": 1001, "phase": "idle"},
        ]

        _run_session_learning(str(tlm_project), prompts)

        mock_client.sync_session.assert_called_once()
        args = mock_client.sync_session.call_args[0]
        # First arg is project_id, second is summary string
        assert isinstance(args[1], str)
        assert "Add auth" in args[1]
        assert "Use JWT" in args[1]

    @patch("tlm.hooks._get_review_client")
    def test_session_learning_doesnt_crash(self, mock_get_client, tlm_project):
        """Session learning should not crash on errors."""
        mock_client = MagicMock()
        mock_client.sync_session.side_effect = Exception("Network error")
        mock_get_client.return_value = mock_client

        prompts = [{"prompt": "test", "timestamp": 1000, "phase": "idle"}]

        # Should not raise
        _run_session_learning(str(tlm_project), prompts)


# ── Step 5: Remove file-level TDD blocking ───────────────────


class TestFileLevelTddRemoved:
    """hook_guard should NOT block source writes based on test file tracking."""

    def test_implementation_allows_source_without_tests(self, tlm_project):
        """In implementation+approved, source writes should NOT be blocked by TDD check."""
        write_state(str(tlm_project), {
            "phase": "implementation",
            "spec_review_status": "approved",
        })

        # Write source directly without writing tests first
        result = hook_guard(str(tlm_project), {
            "tool_name": "Write",
            "tool_input": {"file_path": str(tlm_project / "app.py")},
        })

        # Should NOT block (file-level TDD removed, TDD enforced at plan level)
        assert result.get("decision") != "block"

    def test_implementation_still_checks_spec_approval(self, tlm_project):
        """In implementation WITHOUT spec approval, source writes should still be blocked."""
        write_state(str(tlm_project), {
            "phase": "implementation",
            "spec_review_status": "rejected",
        })

        result = hook_guard(str(tlm_project), {
            "tool_name": "Write",
            "tool_input": {"file_path": str(tlm_project / "app.py")},
        })

        assert result.get("decision") == "block"
        assert "SPEC" in result.get("reason", "").upper()


# ── SPEC_REVIEW prompt TDD criterion ─────────────────────────


class TestSpecReviewTddCriterion:
    """SPEC_REVIEW prompt should include TDD as a mandatory review criterion."""

    def test_spec_review_mentions_tdd(self):
        """The SPEC_REVIEW prompt in server should include TDD criterion."""
        prompts_path = Path(__file__).parent.parent.parent / "server" / "app" / "llm" / "prompts.py"
        content = prompts_path.read_text()
        # Find the SPEC_REVIEW section
        start = content.find('SPEC_REVIEW = """')
        end = content.find('"""', start + 17)
        spec_review = content[start:end]
        assert "tdd" in spec_review.lower() or "test-driven" in spec_review.lower()
