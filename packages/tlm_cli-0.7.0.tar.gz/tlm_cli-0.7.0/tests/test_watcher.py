"""Tests for conversation JSONL watcher daemon."""

import json
import os
import time
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest


# Sample JSONL entries mimicking Claude Code conversation files
SAMPLE_USER_ENTRY = json.dumps({
    "type": "user",
    "message": {
        "role": "user",
        "content": [{"type": "text", "text": "No, use bun not npm"}],
    },
    "uuid": "msg-001",
    "timestamp": "2026-03-07T10:00:00.000Z",
    "sessionId": "session-abc",
})

SAMPLE_ASSISTANT_ENTRY = json.dumps({
    "type": "assistant",
    "message": {
        "role": "assistant",
        "content": [
            {"type": "text", "text": "Got it, switching to bun."},
            {"type": "tool_use", "name": "Bash", "input": {"command": "bun install"}},
        ],
    },
    "uuid": "msg-002",
    "timestamp": "2026-03-07T10:00:01.000Z",
    "sessionId": "session-abc",
})

SAMPLE_FILE_HISTORY_ENTRY = json.dumps({
    "type": "file-history-snapshot",
    "messageId": "msg-002",
    "snapshot": {},
})

SAMPLE_PROGRESS_ENTRY = json.dumps({
    "type": "progress",
    "data": {"type": "hook_progress"},
})

SAMPLE_LONG_ASSISTANT = json.dumps({
    "type": "assistant",
    "message": {
        "role": "assistant",
        "content": [{"type": "text", "text": "x" * 3000}],
    },
    "uuid": "msg-003",
    "timestamp": "2026-03-07T10:00:02.000Z",
    "sessionId": "session-abc",
})


class TestExtractTurns:
    def test_user_message(self):
        from tlm.watcher import _extract_turns
        entries = [json.loads(SAMPLE_USER_ENTRY)]
        turns = _extract_turns(entries)
        assert len(turns) == 1
        assert turns[0]["role"] == "user"
        assert turns[0]["text"] == "No, use bun not npm"

    def test_assistant_message(self):
        from tlm.watcher import _extract_turns
        entries = [json.loads(SAMPLE_ASSISTANT_ENTRY)]
        turns = _extract_turns(entries)
        assert len(turns) == 1
        assert turns[0]["role"] == "assistant"
        assert "Got it, switching to bun." in turns[0]["text"]

    def test_skips_file_history_snapshot(self):
        from tlm.watcher import _extract_turns
        entries = [json.loads(SAMPLE_FILE_HISTORY_ENTRY)]
        turns = _extract_turns(entries)
        assert turns == []

    def test_skips_progress_entries(self):
        from tlm.watcher import _extract_turns
        entries = [json.loads(SAMPLE_PROGRESS_ENTRY)]
        turns = _extract_turns(entries)
        assert turns == []

    def test_caps_text_at_2000_chars(self):
        from tlm.watcher import _extract_turns
        entries = [json.loads(SAMPLE_LONG_ASSISTANT)]
        turns = _extract_turns(entries)
        assert len(turns) == 1
        assert len(turns[0]["text"]) <= 2000

    def test_skips_tool_result_entries(self):
        """Tool result entries (user role with tool_result content) are skipped."""
        from tlm.watcher import _extract_turns
        tool_result = {
            "type": "user",
            "message": {
                "role": "user",
                "content": [{"type": "tool_result", "tool_use_id": "t1", "content": "file data"}],
            },
            "uuid": "msg-tr",
        }
        turns = _extract_turns([tool_result])
        assert turns == []


class TestFileWatching:
    def test_read_new_entries_tracks_byte_offset(self, tmp_path):
        from tlm.watcher import _read_new_entries
        f = tmp_path / "session.jsonl"
        f.write_text(SAMPLE_USER_ENTRY + "\n")

        entries, new_offset = _read_new_entries(str(f), 0)
        assert len(entries) == 1
        assert new_offset > 0

        # No new data
        entries2, new_offset2 = _read_new_entries(str(f), new_offset)
        assert entries2 == []
        assert new_offset2 == new_offset

    def test_read_new_entries_returns_empty_when_no_change(self, tmp_path):
        from tlm.watcher import _read_new_entries
        f = tmp_path / "session.jsonl"
        f.write_text(SAMPLE_USER_ENTRY + "\n")
        size = f.stat().st_size

        entries, offset = _read_new_entries(str(f), size)
        assert entries == []
        assert offset == size

    def test_read_new_entries_reads_appended_data(self, tmp_path):
        from tlm.watcher import _read_new_entries
        f = tmp_path / "session.jsonl"
        f.write_text(SAMPLE_USER_ENTRY + "\n")
        offset = f.stat().st_size

        # Append new entry
        with open(f, "a") as fp:
            fp.write(SAMPLE_ASSISTANT_ENTRY + "\n")

        entries, new_offset = _read_new_entries(str(f), offset)
        assert len(entries) == 1
        assert new_offset > offset


class TestProjectDiscovery:
    def test_decode_project_path(self):
        from tlm.watcher import _decode_project_path
        encoded = "-home-thegpc806-myproject"
        result = _decode_project_path(encoded)
        assert result == "/home/thegpc806/myproject"

    def test_decode_project_path_root(self):
        from tlm.watcher import _decode_project_path
        encoded = "-home-user-code-app"
        result = _decode_project_path(encoded)
        assert result == "/home/user/code/app"

    def test_find_active_session(self, tmp_path):
        from tlm.watcher import _find_active_session
        # Create two JSONL files with different mtimes
        old = tmp_path / "old-session.jsonl"
        old.write_text(SAMPLE_USER_ENTRY + "\n")

        import time as _t
        _t.sleep(0.1)

        new = tmp_path / "new-session.jsonl"
        new.write_text(SAMPLE_ASSISTANT_ENTRY + "\n")

        result = _find_active_session(str(tmp_path))
        assert result == str(new)


class TestBufferingAndCooldown:
    def test_should_analyze_five_exchanges(self):
        from tlm.watcher import _should_analyze
        state = {
            "buffer": [{"role": "user"}, {"role": "assistant"}] * 5,
            "last_analysis_ts": 0,
        }
        assert _should_analyze(state) is True

    def test_should_analyze_timeout(self):
        from tlm.watcher import _should_analyze
        state = {
            "buffer": [{"role": "user"}, {"role": "assistant"}],
            "last_analysis_ts": time.time() - 70,  # > 60s ago
        }
        assert _should_analyze(state) is True

    def test_should_not_analyze_empty_buffer(self):
        from tlm.watcher import _should_analyze
        state = {
            "buffer": [],
            "last_analysis_ts": time.time(),
        }
        assert _should_analyze(state) is False

    def test_cooldown_prevents_rapid_analysis(self):
        from tlm.watcher import _should_analyze
        state = {
            "buffer": [{"role": "user"}, {"role": "assistant"}] * 5,
            "last_analysis_ts": time.time() - 5,  # < 10s ago
        }
        assert _should_analyze(state) is False


class TestMemoryStorage:
    def test_store_memories_writes_to_knowledge_db(self, tmp_path):
        from tlm.watcher import _store_memories
        tlm_dir = tmp_path / ".tlm"
        tlm_dir.mkdir()

        mock_client = MagicMock()
        mock_client.embed.return_value = {"embeddings": [[0.1, 0.2, 0.3]]}

        memories = [{"text": "Use bun", "confidence": "high", "tags": ["tooling"]}]
        _store_memories(str(tmp_path), memories, mock_client)

        # Check knowledge.db was created and has the rule
        from tlm.knowledge_db import KnowledgeDB
        db = KnowledgeDB(str(tlm_dir))
        rules = db.list_rules()
        assert len(rules) >= 1
        assert any("Use bun" in r["rule_text"] for r in rules)
        db.close()

    def test_store_memories_updates_json_cache(self, tmp_path):
        from tlm.watcher import _store_memories
        tlm_dir = tmp_path / ".tlm"
        tlm_dir.mkdir()

        mock_client = MagicMock()
        mock_client.embed.return_value = {"embeddings": [[0.1, 0.2, 0.3]]}

        memories = [{"text": "Use bun", "confidence": "high", "tags": ["tooling"]}]
        _store_memories(str(tmp_path), memories, mock_client)

        cache = tlm_dir / "cache" / "realtime_insights.json"
        assert cache.exists()
        data = json.loads(cache.read_text())
        assert any("Use bun" in c.get("correction", "") for c in data.get("corrections", []))

    def test_store_memories_embeds_via_server(self, tmp_path):
        from tlm.watcher import _store_memories
        tlm_dir = tmp_path / ".tlm"
        tlm_dir.mkdir()

        mock_client = MagicMock()
        mock_client.embed.return_value = {"embeddings": [[0.1, 0.2, 0.3]]}

        memories = [{"text": "Use bun", "confidence": "high", "tags": ["tooling"]}]
        _store_memories(str(tmp_path), memories, mock_client)

        mock_client.embed.assert_called_once()


class TestServerCommunication:
    def test_send_delta_calls_server(self):
        from tlm.watcher import _send_to_server
        mock_client = MagicMock()
        mock_client.learn_conversation.return_value = {
            "memories": [{"text": "Use bun", "confidence": "high", "tags": []}],
            "model_used": "gemini-2.5-flash",
        }

        result = _send_to_server(
            mock_client,
            project_id=1,
            session_id="session-abc",
            new_turns=SAMPLE_NEW_TURNS,
        )

        mock_client.learn_conversation.assert_called_once_with(
            project_id=1,
            session_id="session-abc",
            new_turns=SAMPLE_NEW_TURNS,
        )
        assert len(result["memories"]) == 1

    def test_full_flow_jsonl_to_memory(self, tmp_path):
        """End-to-end: JSONL entry -> parse -> turns -> store."""
        from tlm.watcher import _read_new_entries, _extract_turns, _store_memories

        # Write JSONL
        f = tmp_path / "session.jsonl"
        f.write_text(SAMPLE_USER_ENTRY + "\n" + SAMPLE_ASSISTANT_ENTRY + "\n")

        # Read entries
        entries, offset = _read_new_entries(str(f), 0)
        assert len(entries) == 2

        # Extract turns
        turns = _extract_turns(entries)
        assert len(turns) == 2
        assert turns[0]["role"] == "user"
        assert turns[1]["role"] == "assistant"

        # Store memories
        tlm_dir = tmp_path / ".tlm"
        tlm_dir.mkdir()

        mock_client = MagicMock()
        mock_client.embed.return_value = {"embeddings": [[0.1] * 768]}

        memories = [{"text": "Use bun not npm", "confidence": "high", "tags": ["tooling"]}]
        _store_memories(str(tmp_path), memories, mock_client)

        from tlm.knowledge_db import KnowledgeDB
        db = KnowledgeDB(str(tlm_dir))
        rules = db.list_rules()
        assert any("bun" in r["rule_text"] for r in rules)
        db.close()


SAMPLE_NEW_TURNS = [
    {"role": "user", "text": "No, use bun not npm"},
    {"role": "assistant", "text": "Got it, switching to bun."},
]
