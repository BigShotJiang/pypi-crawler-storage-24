"""Tests for hooks_format — hook entry builder and format abstraction."""

import pytest

from tlm.hooks_format import build_hook_entry, build_all_hooks


class TestBuildHookEntry:
    def test_basic_hook(self):
        """Build a hook with just a command (no matcher)."""
        entry = build_hook_entry("tlm _hook stop")
        assert entry == {
            "hooks": [{"type": "command", "command": "tlm _hook stop"}],
        }

    def test_hook_with_matcher(self):
        """Build a hook with a tool matcher."""
        entry = build_hook_entry("tlm _hook bash_firewall", matcher="Bash")
        assert entry == {
            "matcher": "Bash",
            "hooks": [{"type": "command", "command": "tlm _hook bash_firewall"}],
        }

    def test_hook_without_matcher_has_no_matcher_key(self):
        """When matcher is None, entry should not have matcher key."""
        entry = build_hook_entry("tlm _hook stop")
        assert "matcher" not in entry


class TestBuildAllHooks:
    def test_returns_dict(self):
        """build_all_hooks should return a dict keyed by event name."""
        hooks = build_all_hooks()
        assert isinstance(hooks, dict)

    def test_has_five_events(self):
        """Should have exactly 5 event types: PreToolUse, PostToolUse, Stop, SessionStart, UserPromptSubmit."""
        hooks = build_all_hooks()
        assert set(hooks.keys()) == {"PreToolUse", "PostToolUse", "Stop", "SessionStart", "UserPromptSubmit"}

    def test_has_pre_tool_use(self):
        """Should include PreToolUse event."""
        hooks = build_all_hooks()
        assert "PreToolUse" in hooks

    def test_has_post_tool_use(self):
        """Should include PostToolUse event."""
        hooks = build_all_hooks()
        assert "PostToolUse" in hooks

    def test_has_stop(self):
        """Should include Stop event."""
        hooks = build_all_hooks()
        assert "Stop" in hooks

    def test_pre_tool_use_has_bash_firewall(self):
        """PreToolUse should include Bash firewall hook."""
        hooks = build_all_hooks()
        bash_hooks = [h for h in hooks["PreToolUse"] if h.get("matcher") == "Bash"]
        assert len(bash_hooks) == 1
        assert "bash_firewall" in bash_hooks[0]["hooks"][0]["command"]

    def test_pre_tool_use_has_three_entries(self):
        """PreToolUse should have 3 entries (Bash, Write, Edit)."""
        hooks = build_all_hooks()
        assert len(hooks["PreToolUse"]) == 3

    def test_pre_tool_use_has_write_guard(self):
        """PreToolUse should include Write guard hook."""
        hooks = build_all_hooks()
        write_hooks = [h for h in hooks["PreToolUse"] if h.get("matcher") == "Write"]
        assert len(write_hooks) == 1
        assert "guard" in write_hooks[0]["hooks"][0]["command"]

    def test_pre_tool_use_has_edit_guard(self):
        """PreToolUse should include Edit guard hook."""
        hooks = build_all_hooks()
        edit_hooks = [h for h in hooks["PreToolUse"] if h.get("matcher") == "Edit"]
        assert len(edit_hooks) == 1
        assert "guard" in edit_hooks[0]["hooks"][0]["command"]

    def test_has_session_start(self):
        """Should include SessionStart event with 1 entry."""
        hooks = build_all_hooks()
        assert "SessionStart" in hooks
        assert len(hooks["SessionStart"]) == 1

    def test_has_user_prompt_submit(self):
        """Should include UserPromptSubmit event with 1 entry."""
        hooks = build_all_hooks()
        assert "UserPromptSubmit" in hooks
        assert len(hooks["UserPromptSubmit"]) == 1

    def test_post_tool_use_has_exit_plan_mode(self):
        """PostToolUse should include ExitPlanMode auto-interviewer hook."""
        hooks = build_all_hooks()
        epm_hooks = [h for h in hooks["PostToolUse"] if h.get("matcher") == "ExitPlanMode"]
        assert len(epm_hooks) == 1
        assert "auto_interviewer" in epm_hooks[0]["hooks"][0]["command"]

    def test_post_tool_use_has_one_entry(self):
        """PostToolUse should have exactly one entry (ExitPlanMode)."""
        hooks = build_all_hooks()
        assert len(hooks["PostToolUse"]) == 1

    def test_stop_has_one_entry(self):
        """Stop should have exactly one entry."""
        hooks = build_all_hooks()
        assert len(hooks["Stop"]) == 1
        assert "stop" in hooks["Stop"][0]["hooks"][0]["command"]

    def test_stop_has_no_matcher(self):
        """Stop entries should not have matcher key."""
        hooks = build_all_hooks()
        for entry in hooks["Stop"]:
            assert "matcher" not in entry

    def test_all_hooks_have_correct_structure(self):
        """Every hook entry should have hooks list with command type."""
        hooks = build_all_hooks()
        for event, entries in hooks.items():
            assert isinstance(entries, list), f"{event} should be a list"
            for entry in entries:
                assert "hooks" in entry
                assert isinstance(entry["hooks"], list)
                assert len(entry["hooks"]) == 1
                assert entry["hooks"][0]["type"] == "command"
                assert entry["hooks"][0]["command"].startswith("tlm _hook")
