"""CLI entry point — tlm auth, install, scan, gaps, fix, review, status, logout, uninstall, upgrade."""

import atexit
import functools
import json
import logging
import shutil
import subprocess
import sys
from pathlib import Path

import click
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from tlm.config import (
    get_server_url,
    get_api_key,
    save_credentials,
    load_project_config,
)
from tlm.client import (
    TLMClient,
    TLMCreditsError,
    TLMAuthError,
    TLMProjectLimitError,
    TLMServerError,
    TLMConnectionError,
)
from tlm.installer import Installer
from tlm.gaps import load_gaps, get_active_gaps, get_gap_by_id, update_gap_status, build_fix_brief, GapStatus, extract_gaps_from_profile
from tlm.state import read_state, write_state, set_phase
from tlm.hooks import (
    hook_stop,
    hook_auto_interviewer_plan,
    hook_bash_firewall,
    hook_session_start,
    hook_prompt_submit,
    hook_guard,
)
from tlm.output import start_recording, save_output

console = Console()


def _table_width() -> int:
    """Terminal width for tables — use OS detection with 160-col fallback."""
    return shutil.get_terminal_size(fallback=(160, 24)).columns


# ── Terminal state management ────────────────────────────────

_saved_termios = None


def _save_terminal():
    """Save terminal state so we can restore on messy exit."""
    global _saved_termios
    try:
        import termios
        _saved_termios = termios.tcgetattr(sys.stdin.fileno())
    except Exception:
        pass


def _restore_terminal():
    """Restore terminal to saved state + show cursor. Called via atexit."""
    global _saved_termios
    try:
        import termios
        if _saved_termios is not None:
            termios.tcsetattr(sys.stdin.fileno(), termios.TCSANOW, _saved_termios)
    except Exception:
        pass
    # Always try to show cursor (Rich may have hidden it)
    try:
        sys.stderr.write("\033[?25h")  # ANSI: show cursor
        sys.stderr.flush()
    except (OSError, ValueError):
        pass


# ── Error handling ───────────────────────────────────────────

def _setup_logger() -> logging.Logger:
    """Configure logger that writes to .tlm/tlm.log. Never writes to terminal."""
    _logger = logging.getLogger("tlm")
    if not _logger.handlers:
        tlm_dir = Path(".tlm")
        if tlm_dir.exists():
            handler = logging.FileHandler(tlm_dir / "tlm.log")
            handler.setFormatter(logging.Formatter(
                "%(asctime)s %(levelname)s %(name)s: %(message)s"
            ))
            _logger.addHandler(handler)
        _logger.setLevel(logging.DEBUG)
    return _logger


def _log_error(e: Exception):
    """Log exception with full traceback to .tlm/tlm.log. Never to terminal."""
    logger = _setup_logger()
    logger.error("%s: %s", type(e).__name__, e, exc_info=True)


def _handle_api_errors(f):
    """Decorator: catch TLM API exceptions → friendly messages, never stacktraces."""
    @functools.wraps(f)
    def wrapper(*args, **kwargs):
        try:
            return f(*args, **kwargs)
        except KeyboardInterrupt:
            _restore_terminal()
            console.print("\n[yellow]Interrupted.[/yellow]")
            raise SystemExit(130)
        except TLMCreditsError as e:
            _log_error(e)
            detail = e.args[0] if e.args else {}
            tier = detail.get("tier", "free") if isinstance(detail, dict) else "free"
            upgrade_url = detail.get("upgrade_url", "https://tlmforge.dev/#pricing") if isinstance(detail, dict) else "https://tlmforge.dev/#pricing"
            console.print(f"\n[red bold]You've used all {tier} credits.[/red bold]")
            console.print(f"[dim]Upgrade at: {upgrade_url}[/dim]")
            raise SystemExit(1)
        except TLMProjectLimitError as e:
            _log_error(e)
            detail = e.args[0] if e.args else {}
            if isinstance(detail, dict):
                max_allowed = detail.get("max_allowed", 1)
                tier = detail.get("tier", "free")
            else:
                max_allowed = 1
                tier = "free"
            console.print(f"\n[red bold]Project limit reached. Your {tier} plan allows {max_allowed} project(s).[/red bold]")
            console.print("[dim]Upgrade your plan to add more projects.[/dim]")
            raise SystemExit(1)
        except TLMAuthError as e:
            _log_error(e)
            console.print("\n[red bold]Authentication failed.[/red bold]")
            console.print("[dim]Run 'tlm auth' to re-authenticate.[/dim]")
            raise SystemExit(1)
        except TLMConnectionError as e:
            _log_error(e)
            console.print("\n[red bold]Cannot reach TLM server.[/red bold]")
            console.print("[dim]Check your internet connection and try again.[/dim]")
            raise SystemExit(1)
        except KeyboardInterrupt:
            # Defense-in-depth: catch here too in case exception chain mutates
            _restore_terminal()
            console.print("\n[yellow]Interrupted.[/yellow]")
            raise SystemExit(130)
        except (TLMServerError, Exception) as e:
            _log_error(e)
            console.print("\n[red bold]Internal error. Please try again later.[/red bold]")
            console.print("[dim]Details logged to .tlm/tlm.log[/dim]")
            raise SystemExit(1)
    return wrapper

def _save_output(command_name):
    """Decorator: record console output and save to .tlm/output/ on completion."""
    def decorator(f):
        @functools.wraps(f)
        def wrapper(*args, **kwargs):
            start_recording(console)
            try:
                return f(*args, **kwargs)
            finally:
                save_output(console, command_name, kwargs.get("path", "."))
        return wrapper
    return decorator


AUTH_URL = "https://tlmforge.dev/auth"


def _is_firebase_token(token: str) -> bool:
    """Detect if a token is a Firebase JWT (3-part dot-separated, >100 chars)."""
    parts = token.split(".")
    return len(parts) == 3 and len(token) > 100


@click.group()
def main():
    """TLM — Tech Lead & Manager for your codebase."""
    _save_terminal()
    atexit.register(_restore_terminal)


# ── Version ───────────────────────────────────────────────────

@main.command()
def version():
    """Show TLM version."""
    from importlib.metadata import version as pkg_version
    console.print(f"tlm-cli {pkg_version('tlm-cli')}")


# ── Auth ──────────────────────────────────────────────────────

@main.command()
@click.argument("token", required=False, default=None)
@click.option("--server", default=None, help="TLM server URL")
def auth(token: str, server: str):
    """Authenticate with TLM. Shows status if already logged in."""
    server_url = server or get_server_url()

    # Pre-check: already logged in?
    if token is None:
        existing_key = get_api_key()
        if existing_key:
            try:
                client = TLMClient(server_url=server_url, api_key=existing_key)
                user = client.me()
                email = user.get("email", user.get("user_id", "unknown"))
                console.print(f"[green]Already authenticated as {email}[/green]")
                console.print("[dim]Run 'tlm logout' to switch accounts.[/dim]")
                return
            except Exception:
                pass  # stale creds, fall through to interactive prompt

    # Interactive mode: no token provided
    if token is None:
        console.print(f"\n1. Open: [bold]{AUTH_URL}[/bold]")
        console.print("2. Sign in with Google or email")
        console.print("3. Copy your token and paste it below\n")
        token = click.prompt("Paste your token").strip()

    client = TLMClient(server_url=server_url, api_key="")

    if token.startswith("tlm_sk_"):
        # Direct API key — save first, then verify
        save_credentials(server_url, token)
        client.api_key = token
        try:
            user = client.me()
            console.print(f"[green]Authenticated as {user.get('email', user.get('user_id', 'unknown'))}[/green]")
        except Exception:
            console.print("[yellow]Warning: could not verify credentials, but saved.[/yellow]")

    elif _is_firebase_token(token):
        # Firebase JWT — exchange for API key
        try:
            result = (client.exchange_firebase_token(token))
        except Exception as e:
            console.print(f"[red]Token exchange failed: {e}[/red]")
            raise SystemExit(1)
        api_key = result["api_key"]
        save_credentials(server_url, api_key)
        console.print(f"[green]Authenticated as {result.get('email', result.get('user_id', 'unknown'))}[/green]")

    else:
        console.print("[red]Invalid token. Expected a TLM API key (tlm_sk_...) or a Firebase token.[/red]")
        raise SystemExit(1)

    console.print("Credentials saved to ~/.tlm/credentials.json")


# ── Install ───────────────────────────────────────────────────

def _display_config(config: dict):
    """Display enforcement config as a Rich table."""
    table = Table(title="Enforcement Config", border_style="cyan")
    table.add_column("Section", style="bold")
    table.add_column("Details")

    for check in config.get("checks", []):
        blocker = "[red]BLOCKER[/red]" if check.get("blocker") else "[yellow]warning[/yellow]"
        table.add_row(f"Check: {check['name']}", f"{blocker} — {check.get('command', '?')}")

    for name, env in config.get("environments", {}).items():
        table.add_row(f"Env: {name}", env.get("deploy_command", "?"))

    cov = config.get("coverage", {})
    if cov:
        table.add_row("Coverage", f"min {cov.get('min_line_coverage', '?')}%")

    console.print(table)


def _validate_install_directory(path: str) -> Path:
    """Validate target directory is suitable for TLM installation."""
    resolved = Path(path).resolve()

    # 1. Warn if Claude Code not detected (non-blocking)
    if not (resolved / ".claude").exists():
        console.print("[yellow]Claude Code not detected in this directory.[/yellow]")
        console.print("[dim]  TLM works best with Claude Code. Run `claude` here first.[/dim]\n")

    # 2. Show directory info and confirm
    console.print(f"  [bold cyan]Directory:[/bold cyan] {resolved}")
    console.print(f"  [bold cyan]Project:[/bold cyan]   {resolved.name}\n")
    try:
        if not click.confirm("Install TLM here?", default=True):
            console.print("[yellow]Cancelled.[/yellow]")
            raise SystemExit(1)
    except (KeyboardInterrupt, EOFError):
        console.print("\n[yellow]Cancelled.[/yellow]")
        raise SystemExit(1)

    return resolved


@main.command()
@click.option("--path", default=".", help="Project root path")
@click.pass_context
@_save_output("install")
@_handle_api_errors
def install(ctx, path: str):
    """Install TLM in a project: scan, configure, and set up hooks."""
    _validate_install_directory(path)

    server_url = get_server_url()
    api_key = get_api_key()

    # 1. Auto-auth if not authenticated
    if not api_key:
        console.print("[yellow]Not authenticated. Starting auth...[/yellow]")
        ctx.invoke(auth)
        api_key = get_api_key()
        if not api_key:
            console.print("[red]Authentication failed. Cannot install.[/red]")
            raise SystemExit(1)

    # 2. Welcome banner
    logo = Text()
    logo.append("████████╗██╗     ███╗   ███╗\n", style="bold cyan")
    logo.append("╚══██╔══╝██║     ████╗ ████║\n", style="bold cyan")
    logo.append("   ██║   ██║     ██╔████╔██║\n", style="bold cyan")
    logo.append("   ██║   ██║     ██║╚██╔╝██║\n", style="bold cyan")
    logo.append("   ██║   ███████╗██║ ╚═╝ ██║\n", style="bold cyan")
    logo.append("   ╚═╝   ╚══════╝╚═╝     ╚═╝\n", style="bold cyan")
    logo.append("  The annoying agent that makes you ship better code", style="dim")
    console.print(Panel(logo, border_style="cyan", padding=(1, 4)))

    installer = Installer(path, server_url=server_url, api_key=api_key)

    # 3. Init + ensure project on server
    with console.status("[cyan]Scanning your project...[/cyan]", spinner="dots"):
        installer.init_project_dir()
        project_id = installer.ensure_project()
        scan_data = installer.scan_project()
    console.print("  [green]✓[/green] Project structure analyzed")

    # 4. Assess + error handling
    with console.status("[cyan]Analyzing project...[/cyan]", spinner="dots"):
        result = installer.assess(scan_data)

    profile = result.get("profile", {})

    # Handle parse errors with retry
    if profile.get("parse_error"):
        console.print(f"  [red]⚠ Assessment failed:[/red] {profile['parse_error']}")
        while True:
            choice = click.prompt(
                "[R]etry / [S]kip / [Q]uit",
                default="r",
                show_default=False,
            ).strip().lower()

            if choice in ("r", "retry"):
                installer.clear_assess_cache()
                with console.status("[cyan]Retrying analysis...[/cyan]", spinner="dots"):
                    result = installer.assess(scan_data)
                profile = result.get("profile", {})
                if not profile.get("parse_error"):
                    break
                console.print(f"  [red]⚠ Still failing:[/red] {profile['parse_error']}")
            elif choice in ("s", "skip"):
                break
            elif choice in ("q", "quit"):
                raise SystemExit(0)

    if not profile.get("parse_error"):
        console.print("  [green]✓[/green] Analysis complete")
        if profile:
            console.print(f"  [dim]Stack: {profile.get('stack', 'unknown')}[/dim]")

    # 5. Gap detection + display
    recommendations = result.get("recommendations", [])

    if recommendations and not profile.get("parse_error"):
        console.print(f"\n[yellow]⚠[/yellow] [bold]{len(recommendations)} gap(s) found[/bold]")

        table = Table(
            padding=(0, 1, 1, 1),
            show_lines=True,
            width=_table_width(),
        )
        table.add_column("Sev", style="bold", width=8)
        table.add_column("Category", max_width=18, overflow="ellipsis")
        table.add_column("Description", overflow="fold")

        severity_colors = {
            "critical": "red",
            "high": "yellow",
            "medium": "blue",
            "low": "dim",
        }

        for rec in recommendations:
            sev = rec.get("severity", "medium")
            color = severity_colors.get(sev, "white")
            table.add_row(
                f"[{color}]{sev}[/{color}]",
                rec.get("category", ""),
                rec.get("description", ""),
            )

        console.print(table)
        installer.populate_gaps(recommendations)
    elif not profile.get("parse_error"):
        console.print("\n[green]✓ No gaps detected![/green]")

    # 6. Install hooks
    installer.install_full()
    console.print("  [green]✓[/green] Hooks installed")

    # 7. Final message
    console.print("\n[green bold]✓ TLM is active. Plans and commands are guarded.[/green bold]")
    console.print("\n[bold]Next step:[/bold] restart Claude Code so hooks take effect.")
    console.print("[dim]  Press [bold]q[/bold] or [bold]Ctrl+C[/bold] to exit, then:[/dim]")
    console.print("[dim]  • [bold]claude[/bold]                        → start fresh[/dim]")
    console.print("[dim]  • [bold]claude --continue[/bold]             → resume last conversation[/dim]")
    console.print("[dim]  • [bold]claude --resume <session_id>[/bold]  → resume a specific session[/dim]")


# ── Fix ──────────────────────────────────────────────────────

@main.command()
@click.argument("gap_id", required=False, default=None)
@click.option("--path", default=".", help="Project root path")
@_save_output("fix")
@_handle_api_errors
def fix(gap_id: str, path: str):
    """Fix a project gap: launch interactive Claude Code session."""
    api_key = get_api_key()
    if not api_key:
        console.print("[red]Not authenticated. Run 'tlm auth' first.[/red]")
        raise SystemExit(1)

    active = get_active_gaps(path)
    if not active:
        console.print("[green]No active gaps to fix.[/green]")
        return

    # Gap selection — accept numeric index (#) or string gap_id
    if gap_id:
        if gap_id.isdigit():
            idx = int(gap_id)
            if idx < 1 or idx > len(active):
                console.print(f"[red]Gap #{gap_id} out of range (1-{len(active)}).[/red]")
                raise SystemExit(1)
            gap = active[idx - 1]
            gap_id = gap["id"]
        else:
            gap = get_gap_by_id(path, gap_id)
            if not gap:
                console.print(f"[red]Gap '{gap_id}' not found.[/red]")
                raise SystemExit(1)
    else:
        console.print("[bold]Active gaps:[/bold]")
        for i, g in enumerate(active, 1):
            console.print(f"  {i}. [{g['severity']}] {g['id']} — {g['description']}")

        choice = click.prompt("Select gap to fix", type=int)
        if choice < 1 or choice > len(active):
            console.print("[red]Invalid selection.[/red]")
            raise SystemExit(1)
        gap = active[choice - 1]
        gap_id = gap["id"]

    # Build fix brief
    brief_path = build_fix_brief(path, gap_id)
    console.print(f"\n[bold]Fixing gap: {gap_id}[/bold]")

    # Set state before launching Claude
    write_state(path, {
        "phase": "tlm_active",
        "activity_type": "gap_fix",
        "active_gap_id": gap_id,
    })

    try:
        # Launch interactive Claude Code
        result = subprocess.run(
            ["claude", "--permission-mode", "plan",
             f"Read {brief_path} and fix the gap described there."],
            cwd=path,
        )

        if result.returncode == 0:
            update_gap_status(path, gap_id, GapStatus.RESOLVED)
            console.print(f"\n[green]Gap '{gap_id}' resolved.[/green]")
        else:
            console.print(f"\n[yellow]Gap '{gap_id}' not resolved — Claude exited with code {result.returncode}.[/yellow]")
    except KeyboardInterrupt:
        console.print("\n[yellow]Interrupted. Gap not resolved.[/yellow]")
    except OSError as e:
        console.print(f"\n[red]Failed to launch Claude: {e}[/red]")
        console.print("[dim]Ensure Claude Code is installed and on your PATH.[/dim]")
    finally:
        set_phase(path, "idle")


# ── Scan ──────────────────────────────────────────────────────

@main.command()
@click.option("--path", default=".", help="Project root path")
@_save_output("scan")
@_handle_api_errors
def scan(path: str):
    """Re-scan project and show updated recommendations."""
    server_url = get_server_url()
    api_key = get_api_key()

    if not api_key:
        console.print("[red]Not authenticated. Run 'tlm auth' first.[/red]")
        raise SystemExit(1)

    installer = Installer(path, server_url=server_url, api_key=api_key)
    installer.init_project_dir()
    installer.ensure_project()

    scan_data = installer.scan_project()
    result = installer.assess(scan_data)

    recommendations = result.get("recommendations", [])
    if not recommendations:
        console.print("[green]No issues found![/green]")
        return

    table = Table(title="Project Recommendations")
    table.add_column("ID", style="cyan")
    table.add_column("Category", style="white")
    table.add_column("Severity", style="bold")
    table.add_column("Description")

    severity_colors = {
        "critical": "red",
        "high": "yellow",
        "medium": "blue",
        "low": "dim",
    }

    for rec in recommendations:
        sev = rec["severity"]
        color = severity_colors.get(sev, "white")
        table.add_row(
            rec["id"],
            rec["category"],
            f"[{color}]{sev}[/{color}]",
            rec["description"],
        )

    console.print(table)


# ── Gaps ──────────────────────────────────────────────────────

@main.command()
@click.option("--path", default=".", help="Project root path")
@_save_output("gaps")
def gaps(path: str):
    """Show active project gaps and their severity."""
    active = get_active_gaps(path)

    if not active:
        console.print("[green]No active gaps. Project is clean.[/green]")
        return

    table = Table(
        title=f"Active Gaps ({len(active)})",
        padding=(0, 1, 1, 1),
        show_lines=True,
        width=_table_width(),
    )
    table.add_column("#", style="cyan", width=4, justify="right")
    table.add_column("Sev", style="bold", width=8)
    table.add_column("Category", max_width=18, overflow="ellipsis")
    table.add_column("Description", overflow="fold")
    table.add_column("Status", width=8)

    severity_colors = {
        "critical": "red",
        "high": "yellow",
        "medium": "blue",
        "low": "dim",
    }

    for i, gap in enumerate(active, 1):
        sev = gap["severity"]
        color = severity_colors.get(sev, "white")
        table.add_row(
            str(i),
            f"[{color}]{sev}[/{color}]",
            gap.get("category", ""),
            gap["description"],
            gap["status"],
        )

    console.print(table)
    console.print("\n[bold bright_cyan]Fix a gap:[/bold bright_cyan] [white]tlm fix <#>[/white]\n")


# ── Review ───────────────────────────────────────────────────

@main.group(invoke_without_command=True)
@click.option("--show-last", is_flag=True, default=False, help="Display cached last review result")
@click.option("--path", default=".", help="Project root path")
@click.pass_context
def review(ctx, show_last: bool, path: str):
    """Review specs or staged code against TLM server."""
    ctx.ensure_object(dict)
    ctx.obj["path"] = path

    if not show_last and ctx.invoked_subcommand is not None:
        return

    if show_last:
        cache_file = Path(path) / ".tlm" / "cache" / "last_review.json"
        if cache_file.exists():
            try:
                data = json.loads(cache_file.read_text())
                severity = data.get("severity", data.get("combined_verdict", "unknown"))
                console.print(f"[bold]Last review result:[/bold] {severity}")

                gaps = data.get("gaps", [])
                if gaps:
                    console.print(f"\nGaps ({len(gaps)}):")
                    for gap in gaps:
                        console.print(f"  [{gap.get('severity', 'medium')}] {gap.get('description', '')}")

                issues = data.get("issues", [])
                if issues:
                    console.print(f"\nIssues ({len(issues)}):")
                    for issue in issues:
                        console.print(f"  [{issue.get('severity', 'medium')}] {issue.get('description', '')}")

                questions = data.get("follow_up_questions", [])
                if questions:
                    console.print("\nFollow-up questions:")
                    for q in questions:
                        console.print(f"  - {q}")
            except (json.JSONDecodeError, OSError):
                console.print("[red]Cannot read cached review.[/red]")
        else:
            console.print("[dim]No cached review found. Run 'tlm review spec' or 'tlm review code' first.[/dim]")


@review.command(name="spec")
@click.argument("spec_path")
@click.option("--path", default=".", help="Project root path")
@_save_output("review_spec")
def review_spec(spec_path: str, path: str):
    """Review a spec/plan file. Pass the file path as argument."""
    api_key = get_api_key()

    if not api_key:
        console.print("[red]Not authenticated. Run 'tlm auth' first.[/red]")
        raise SystemExit(1)

    # Read spec
    try:
        spec_content = Path(spec_path).read_text()
    except OSError:
        console.print(f"[red]Cannot read spec: {spec_path}[/red]")
        raise SystemExit(1)

    # Load config
    config = load_project_config(path)
    project_id = config.get("project_id", 0)
    quality = config.get("quality_control", "standard")

    # Read knowledge
    knowledge = ""
    knowledge_path = Path(path) / ".tlm" / "knowledge.md"
    if knowledge_path.exists():
        try:
            knowledge = knowledge_path.read_text()
        except OSError:
            pass

    # Call server
    server_url = get_server_url()
    client = TLMClient(server_url=server_url, api_key=api_key)

    console.print("[dim]Reviewing spec...[/dim]")
    try:
        result = (client.review_spec(
            project_id=project_id,
            spec=spec_content,
            project_knowledge=knowledge,
            quality_level=quality,
        ))
    except Exception as e:
        console.print(f"[red]Review failed: {e}[/red]")
        raise SystemExit(1)

    # Cache result
    cache_dir = Path(path) / ".tlm" / "cache"
    cache_dir.mkdir(parents=True, exist_ok=True)
    (cache_dir / "last_review.json").write_text(json.dumps(result, indent=2))

    # Display
    severity = result.get("severity", "unknown")
    severity_colors = {"pass": "green", "warn": "yellow", "fail": "red"}
    color = severity_colors.get(severity, "white")
    console.print(f"\n[bold]Spec Review: [{color}]{severity.upper()}[/{color}][/bold]")

    gaps = result.get("gaps", [])
    if gaps:
        table = Table(
            title=f"Gaps ({len(gaps)})",
            padding=(1, 2),
            show_lines=True,
            width=min(console.width, 120),
        )
        table.add_column("Severity", style="bold")
        table.add_column("Description", max_width=60, overflow="fold")
        for gap in gaps:
            table.add_row(gap.get("severity", "medium"), gap.get("description", ""))
        console.print(table)

    questions = result.get("follow_up_questions", [])
    if questions:
        console.print("\n[bold]Follow-up questions:[/bold]")
        for q in questions:
            console.print(f"  - {q}")


@review.command(name="code")
@click.argument("commit", required=False, default=None)
@click.option("--path", default=".", help="Project root path")
@_save_output("review_code")
def review_code(commit: str, path: str):
    """Review staged changes or a specific commit against the active spec."""
    api_key = get_api_key()

    if not api_key:
        console.print("[red]Not authenticated. Run 'tlm auth' first.[/red]")
        raise SystemExit(1)

    # Get git diff
    try:
        if commit:
            diff_cmd = ["git", "diff", f"{commit}~1", commit]
            names_cmd = ["git", "diff", f"{commit}~1", commit, "--name-only"]
        else:
            diff_cmd = ["git", "diff", "--cached"]
            names_cmd = ["git", "diff", "--cached", "--name-only"]

        diff_result = subprocess.run(
            diff_cmd,
            capture_output=True, text=True, cwd=path, timeout=10,
        )
        names_result = subprocess.run(
            names_cmd,
            capture_output=True, text=True, cwd=path, timeout=10,
        )
    except (subprocess.TimeoutExpired, OSError) as e:
        console.print(f"[red]git diff failed: {e}[/red]")
        raise SystemExit(1)

    diff_text = diff_result.stdout.strip()
    files_changed = [f for f in names_result.stdout.strip().split("\n") if f]

    if not diff_text:
        if commit:
            console.print(f"[yellow]No changes in commit {commit}.[/yellow]")
        else:
            console.print("[yellow]No staged changes to review. Stage changes with 'git add' first.[/yellow]")
        raise SystemExit(1)

    # Load active spec
    state = read_state(path)
    active_spec = state.get("active_spec")
    spec_content = ""
    if active_spec:
        try:
            spec_content = Path(active_spec).read_text()
        except OSError:
            pass

    if not spec_content:
        console.print("[yellow]No active spec found. Run 'tlm review spec' first.[/yellow]")
        raise SystemExit(1)

    # Read knowledge
    knowledge = ""
    knowledge_path = Path(path) / ".tlm" / "knowledge.md"
    if knowledge_path.exists():
        try:
            knowledge = knowledge_path.read_text()
        except OSError:
            pass

    config = load_project_config(path)
    project_id = config.get("project_id", 0)

    server_url = get_server_url()
    client = TLMClient(server_url=server_url, api_key=api_key)

    console.print(f"[dim]Reviewing {len(files_changed)} changed file(s)...[/dim]")
    try:
        result = (client.review_code(
            project_id=project_id,
            spec=spec_content,
            code=diff_text,
            files_changed=files_changed,
            project_knowledge=knowledge,
        ))
    except Exception as e:
        console.print(f"[red]Code review failed: {e}[/red]")
        raise SystemExit(1)

    # Cache result
    cache_dir = Path(path) / ".tlm" / "cache"
    cache_dir.mkdir(parents=True, exist_ok=True)
    (cache_dir / "last_review.json").write_text(json.dumps(result, indent=2))

    # Display
    verdict = result.get("combined_verdict", "unknown")
    verdict_colors = {"pass": "green", "warn": "yellow", "fail": "red"}
    color = verdict_colors.get(verdict, "white")
    console.print(f"\n[bold]Code Review: [{color}]{verdict.upper()}[/{color}][/bold]")

    issues = result.get("issues", [])
    if issues:
        table = Table(title=f"Issues ({len(issues)})")
        table.add_column("Severity", style="bold")
        table.add_column("Description")
        for issue in issues:
            table.add_row(issue.get("severity", "medium"), issue.get("description", ""))
        console.print(table)

    reviews = result.get("reviews", [])
    if reviews:
        console.print("\n[bold]Model reviews:[/bold]")
        for r in reviews:
            console.print(f"  {r.get('model', 'unknown')}: {r.get('verdict', 'unknown')}")


# ── Logout ────────────────────────────────────────────────────

@main.command()
def logout():
    """Remove stored TLM credentials."""
    creds_file = Path.home() / ".tlm" / "credentials.json"
    if creds_file.exists():
        creds_file.unlink()
        console.print("[green]Credentials removed.[/green]")
    else:
        console.print("[dim]No credentials found.[/dim]")


# ── Uninstall ─────────────────────────────────────────────────

@main.command()
@click.option("--path", default=".", help="Project root path")
@click.option("--yes", "-y", is_flag=True, help="Skip confirmation")
def uninstall(path: str, yes: bool):
    """Remove TLM from this project (config, hooks, rules)."""
    tlm_dir = Path(path) / ".tlm"
    if not tlm_dir.exists():
        console.print("[dim]TLM is not installed in this project.[/dim]")
        return

    if not yes:
        warning = Text()
        warning.append("WARNING: This will permanently remove:\n\n", style="bold red")
        warning.append("  - .tlm/ directory (config, specs, gaps, enforcement)\n")
        warning.append("  - .claude/settings.json hook entries\n")
        warning.append("  - .claude/hooks/tlm-* wrapper scripts\n")
        warning.append("  - .claude/rules/tlm-*.md rule files\n")
        warning.append("  - .git/hooks/post-commit (TLM learner)\n")
        warning.append("  - CLAUDE.md TLM section (if present)\n\n")
        warning.append("This cannot be undone. You will need to run 'tlm install' again.", style="dim")
        console.print(Panel(warning, border_style="red", title="[red bold]Uninstall TLM[/red bold]"))

        confirm = click.prompt(
            'Type "UNINSTALL" to confirm',
            default="",
            show_default=False,
        ).strip()
        if confirm != "UNINSTALL":
            console.print("[dim]Cancelled.[/dim]")
            return

    installer = Installer(path)
    installer.uninstall()

    console.print("  [green]✓[/green] Hook entries removed from .claude/settings.json")
    console.print("  [green]✓[/green] Hook scripts removed")
    console.print("  [green]✓[/green] Rule files removed")
    console.print("  [green]✓[/green] Git hooks removed")
    console.print("  [green]✓[/green] .tlm/ directory removed")
    console.print("\n[green bold]TLM fully removed.[/green bold]")
    console.print("[dim]To reinstall: tlm install[/dim]")


# ── Status ────────────────────────────────────────────────────

@main.command()
@click.option("--path", default=".", help="Project root path")
@_save_output("status")
def status(path: str):
    """Show TLM project status: config, gaps, enforcement."""
    tlm_dir = Path(path) / ".tlm"

    if not tlm_dir.exists():
        console.print("[yellow]TLM not installed in this project. Run 'tlm install' first.[/yellow]")
        return

    config = load_project_config(path)
    state = read_state(path)

    table = Table(title="TLM Status")
    table.add_column("Property", style="bold")
    table.add_column("Value")

    table.add_row("Project", config.get("project_name", Path(path).resolve().name))
    table.add_row("Phase", state.get("phase", "unknown"))
    table.add_row("Quality Tier", config.get("quality_control", "not set"))
    table.add_row("Project ID", str(config.get("project_id", "not set")))

    # Gaps
    active = get_active_gaps(path)
    table.add_row("Active Gaps", str(len(active)))

    # Specs
    specs_dir = tlm_dir / "specs"
    spec_count = len(list(specs_dir.glob("*.md"))) if specs_dir.exists() else 0
    table.add_row("Specs", str(spec_count))

    # Enforcement
    enforcement = tlm_dir / "enforcement.json"
    if enforcement.exists():
        try:
            ec = json.loads(enforcement.read_text())
            table.add_row("Enforcement", "approved" if ec.get("approved") else "draft")
        except json.JSONDecodeError:
            table.add_row("Enforcement", "invalid")
    else:
        table.add_row("Enforcement", "not configured")

    console.print(table)


# ── Upgrade ───────────────────────────────────────────────────

@main.command()
def upgrade():
    """Upgrade TLM CLI to the latest version via pipx or pip."""
    import subprocess as sp
    console.print("[dim]Upgrading tlm-cli...[/dim]")
    try:
        result = sp.run(
            ["pipx", "upgrade", "tlm-cli"],
            capture_output=True, text=True, timeout=60,
        )
        if result.returncode == 0:
            console.print(f"[green]{result.stdout.strip()}[/green]")
        else:
            # Try pip as fallback
            result = sp.run(
                ["pip", "install", "--upgrade", "tlm-cli"],
                capture_output=True, text=True, timeout=60,
            )
            if result.returncode == 0:
                console.print("[green]Upgraded successfully.[/green]")
            else:
                console.print(f"[red]Upgrade failed: {result.stderr.strip()}[/red]")
    except FileNotFoundError:
        console.print("[red]Neither pipx nor pip found. Install manually.[/red]")
    except sp.TimeoutExpired:
        console.print("[red]Upgrade timed out.[/red]")


# ── Sync ──────────────────────────────────────────────────────

@main.command()
@click.option("--path", default=".", help="Project root path")
@_save_output("sync")
@_handle_api_errors
def sync(path: str):
    """Manually sync session transcript to TLM server."""
    tlm_dir = Path(path) / ".tlm"
    if not tlm_dir.exists():
        console.print("[red]TLM not initialized. Run `tlm install` first.[/red]")
        raise SystemExit(1)

    config = load_project_config(path)
    project_id = config.get("project_id")
    if not project_id:
        console.print("[red]No project ID found. Run `tlm install` first.[/red]")
        raise SystemExit(1)

    prompts_file = tlm_dir / "session_prompts.jsonl"
    if not prompts_file.exists():
        console.print("[dim]No session data to sync.[/dim]")
        return

    prompt_texts = []
    try:
        for line in prompts_file.read_text().strip().split("\n"):
            if line.strip():
                entry = json.loads(line)
                prompt_texts.append(entry.get("prompt", ""))
    except (json.JSONDecodeError, OSError):
        console.print("[red]Cannot read session data.[/red]")
        raise SystemExit(1)

    if not prompt_texts:
        console.print("[dim]No session data to sync.[/dim]")
        return

    summary = "\n".join(f"- {t}" for t in prompt_texts if t)

    server_url = get_server_url()
    api_key = get_api_key()
    client = TLMClient(server_url=server_url, api_key=api_key)

    with console.status("[cyan]Syncing session...[/cyan]", spinner="dots"):
        result = client.sync_session(project_id, summary, timeout=120.0)

    rules_count = result.get("rules_learned", 0)
    if rules_count > 0:
        console.print(f"[green]Synced. {rules_count} rule(s) learned.[/green]")
    else:
        console.print("[green]Synced. No new rules inferred.[/green]")


# ── Rules ─────────────────────────────────────────────────────

@main.group(invoke_without_command=True)
@click.option("--path", default=".", help="Project root path")
@click.pass_context
@_save_output("rules")
@_handle_api_errors
def rules(ctx, path: str):
    """Display all active TLM rules for this project."""
    if ctx.invoked_subcommand is not None:
        ctx.ensure_object(dict)
        ctx.obj["path"] = path
        return

    config = load_project_config(path)
    project_id = config.get("project_id")
    if not project_id:
        console.print("[red]No project ID found. Run `tlm install` first.[/red]")
        raise SystemExit(1)

    server_url = get_server_url()
    api_key = get_api_key()
    client = TLMClient(server_url=server_url, api_key=api_key)

    with console.status("[cyan]Loading rules...[/cyan]", spinner="dots"):
        result = client.get_rules(project_id)

    rule_list = result.get("rules", [])
    if not rule_list:
        console.print("[dim]No active rules for this project.[/dim]")
        return

    table = Table()
    table.add_column("ID", style="bold", width=5)
    table.add_column("Source", width=18)
    table.add_column("Rule")

    for rule in rule_list:
        source = rule.get("source", "unknown")
        source_colors = {
            "session_learning": "cyan",
            "assess": "yellow",
            "manual": "green",
        }
        color = source_colors.get(source, "white")
        table.add_row(
            str(rule.get("id", "")),
            f"[{color}]{source}[/{color}]",
            rule.get("rule_text", ""),
        )

    console.print(table)


main.add_command(rules)


@rules.command("remove")
@click.argument("rule_id", type=int)
@click.option("--path", default=".", help="Project root path")
@_handle_api_errors
def rules_remove(rule_id: int, path: str):
    """Remove a learned rule. Usage: tlm rules remove 4"""
    config = load_project_config(path)
    project_id = config.get("project_id")
    if not project_id:
        console.print("[red]No project ID found. Run `tlm install` first.[/red]")
        raise SystemExit(1)

    server_url = get_server_url()
    api_key = get_api_key()
    client = TLMClient(server_url=server_url, api_key=api_key)

    result = client.delete_rule(project_id, rule_id)
    console.print(f"[green]Rule #{rule_id} removed.[/green]")


# ── Hook dispatch ─────────────────────────────────────────────

@main.command(name="_hook", hidden=True)
@click.argument("hook_name")
@click.option("--path", default=".", help="Project root path")
def hook_dispatch(hook_name: str, path: str):
    """Internal: dispatch to hook handlers. Called by Claude Code hooks."""
    if hook_name == "auto_interviewer":
        tool_input = {}
        if not sys.stdin.isatty():
            try:
                tool_input = json.loads(sys.stdin.read())
            except (json.JSONDecodeError, IOError):
                pass

        result = hook_auto_interviewer_plan(path, tool_input)
        print(json.dumps(result))

    elif hook_name == "bash_firewall":
        tool_input = {}
        if not sys.stdin.isatty():
            try:
                tool_input = json.loads(sys.stdin.read())
            except (json.JSONDecodeError, IOError):
                pass

        result = hook_bash_firewall(path, tool_input)
        print(json.dumps(result))

    elif hook_name == "stop":
        result = hook_stop(path)
        print(json.dumps(result))

    elif hook_name == "session_start":
        result = hook_session_start(path)
        print(result)

    elif hook_name == "prompt_submit":
        stdin_data = {}
        if not sys.stdin.isatty():
            try:
                stdin_data = json.loads(sys.stdin.read())
            except (json.JSONDecodeError, IOError):
                pass
        prompt_text = stdin_data.get("user_prompt", "")
        result = hook_prompt_submit(path, prompt_text)
        print(json.dumps(result))

    elif hook_name == "guard":
        tool_input = {}
        if not sys.stdin.isatty():
            try:
                tool_input = json.loads(sys.stdin.read())
            except (json.JSONDecodeError, IOError):
                pass
        result = hook_guard(path, tool_input)
        print(json.dumps(result))

    elif hook_name == "_learn_prompt_bg":
        from tlm.hooks import learn_prompt_bg
        learn_prompt_bg(path)

    elif hook_name == "_watcher":
        from tlm.watcher import main as watcher_main
        watcher_main()

    else:
        console.print(f"[red]Unknown hook: {hook_name}[/red]")
        raise SystemExit(1)


# ── Setup Watcher ────────────────────────────────────────────

@main.command(name="setup-watcher")
def setup_watcher():
    """Install the TLM conversation watcher as a systemd user service."""
    import subprocess as sp

    systemd_dir = Path.home() / ".config" / "systemd" / "user"
    systemd_dir.mkdir(parents=True, exist_ok=True)

    # Find the tlm binary
    tlm_bin = shutil.which("tlm") or str(Path.home() / ".local" / "bin" / "tlm")

    service_content = f"""[Unit]
Description=TLM Conversation Watcher
After=default.target

[Service]
Type=simple
ExecStart={tlm_bin} _hook _watcher
Restart=on-failure
RestartSec=10
Environment=HOME={Path.home()}

[Install]
WantedBy=default.target
"""

    service_file = systemd_dir / "tlm-watcher.service"
    service_file.write_text(service_content)
    console.print(f"  [green]✓[/green] Service file written to {service_file}")

    # Ensure ~/.tlm/ exists for log file
    (Path.home() / ".tlm").mkdir(exist_ok=True)

    # Reload and enable
    for cmd, desc in [
        (["systemctl", "--user", "daemon-reload"], "Reloading systemd"),
        (["systemctl", "--user", "enable", "tlm-watcher"], "Enabling service"),
        (["systemctl", "--user", "start", "tlm-watcher"], "Starting watcher"),
    ]:
        try:
            result = sp.run(cmd, capture_output=True, text=True, timeout=10)
            if result.returncode == 0:
                console.print(f"  [green]✓[/green] {desc}")
            else:
                console.print(f"  [yellow]⚠[/yellow] {desc}: {result.stderr.strip()}")
        except (OSError, sp.TimeoutExpired) as e:
            console.print(f"  [yellow]⚠[/yellow] {desc}: {e}")

    console.print("\n[green bold]TLM Watcher is running.[/green bold]")
    console.print("[dim]It monitors your Claude Code conversations for learning.[/dim]")
    console.print("[dim]Check status: systemctl --user status tlm-watcher[/dim]")
    console.print("[dim]View logs: tail -f ~/.tlm/watcher.log[/dim]")


@main.command(name="sync")
def sync_memories():
    """Pull memories from server (user + project) without full reinstall."""
    api_key = get_api_key()
    server_url = get_server_url()

    if not api_key:
        console.print("[red]Not authenticated. Run `tlm auth` first.[/red]")
        raise SystemExit(1)

    config = load_project_config(".")
    project_id = config.get("project_id", 0)

    client = TLMClient(server_url=server_url, api_key=api_key)
    installer = Installer(".", server_url=server_url, api_key=api_key)

    try:
        pull_response = client.pull_memories(project_id=int(project_id) if project_id else 0)
        installer.pull_memories(int(project_id) if project_id else 0, pull_response)

        user_count = len(pull_response.get("user_memories", []))
        project_count = len(pull_response.get("project_memories", []))

        console.print(f"[green]Synced {user_count} user memor{'y' if user_count == 1 else 'ies'}, "
                      f"{project_count} project memor{'y' if project_count == 1 else 'ies'}.[/green]")
    except TLMConnectionError:
        console.print("[red]Cannot reach TLM server.[/red]")
        raise SystemExit(1)
    except Exception as e:
        console.print(f"[red]Sync failed: {e}[/red]")
        raise SystemExit(1)


if __name__ == "__main__":
    main()
