"""Hook format abstraction — centralizes Claude Code hook entry format.

Claude Code hook format has changed before (commit 0952734) and will change again.
This module ensures future format changes only require updating ONE function.

Current format (2026-02): hooks is a dict keyed by event name, with matcher
as a top-level string (not nested object).
"""


def build_hook_entry(command: str, matcher: str | None = None) -> dict:
    """Build a single hook entry in whatever format Claude Code currently expects.

    Centralizes format so future changes require updating ONE function.
    """
    entry = {"hooks": [{"type": "command", "command": command}]}
    if matcher:
        entry["matcher"] = matcher
    return entry


def build_all_hooks() -> dict:
    """Build the complete TLM hook dict, keyed by event name.

    Five event types:
    - SessionStart → branding banner + project context
    - UserPromptSubmit → phase context, gap warnings, enforcement
    - PreToolUse(Bash) → bash firewall (regex + server review)
    - PreToolUse(Write/Edit) → guard (blocks source writes during interview)
    - PostToolUse(ExitPlanMode) → auto-interviewer (plan review)
    - Stop → session sync
    """
    return {
        "SessionStart": [
            build_hook_entry("tlm _hook session_start"),
        ],
        "UserPromptSubmit": [
            build_hook_entry("tlm _hook prompt_submit"),
        ],
        "PreToolUse": [
            build_hook_entry("tlm _hook bash_firewall", matcher="Bash"),
            build_hook_entry("tlm _hook guard", matcher="Write"),
            build_hook_entry("tlm _hook guard", matcher="Edit"),
        ],
        "PostToolUse": [
            build_hook_entry("tlm _hook auto_interviewer", matcher="ExitPlanMode"),
        ],
        "Stop": [
            build_hook_entry("tlm _hook stop"),
        ],
    }
