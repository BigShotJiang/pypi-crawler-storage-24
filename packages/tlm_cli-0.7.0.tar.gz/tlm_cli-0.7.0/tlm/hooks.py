"""
TLM Hook Handlers — Interceptor hooks for Claude Code.

Server-backed intelligence with graceful degradation.

Active hooks (registered via build_all_hooks()):
    hook_bash_firewall          — PreToolUse (Bash): local regex + server review
    hook_auto_interviewer_plan  — PostToolUse (ExitPlanMode): plan review
    hook_stop                   — Stop: session cleanup + session learning
"""

import json
import re
import subprocess
import sys
import time as _time
from pathlib import Path

import httpx

from tlm.state import read_state, write_state
from tlm.config import load_project_config, get_api_key, get_server_url
from tlm.client import TLMClient
from tlm.gaps import get_active_gaps

# Global TLM dir for user-scoped memories
GLOBAL_TLM_DIR = Path.home() / ".tlm"

# ANSI colors
_C = "\033[36m"   # cyan
_G = "\033[32m"   # green
_Y = "\033[33m"   # amber
_R = "\033[31m"   # red
_B = "\033[1m"    # bold
_D = "\033[2m"    # dim
_X = "\033[0m"    # reset


def _print_status(icon: str, title: str, detail: str = "", color: str = _C):
    """Print colored TLM status to stderr (visible in Claude Code terminal)."""
    bar = f"{color}{'━' * 52}{_X}"
    sys.stderr.write(f"\n{bar}\n{color}{_B}  {icon} TLM — {title}{_X}\n{bar}\n")
    if detail:
        sys.stderr.write(f"\n  {detail}\n\n{bar}\n")
    sys.stderr.write("\n")
    sys.stderr.flush()


def _tlm_block(title: str, detail: str) -> dict:
    """Red stop — tool is blocked, reason shown to user directly."""
    bar = f"{_R}{'━' * 52}{_X}"
    return {
        "decision": "block",
        "reason": f"\n{bar}\n{_R}{_B}  ■ TLM — {title}{_X}\n{bar}\n\n{detail}\n\n{bar}\n",
    }


def _tlm_caution(title: str, detail: str) -> dict:
    """Yellow caution — Claude relays to user."""
    bar = f"{_Y}{'━' * 52}{_X}"
    visual = f"\n{bar}\n{_Y}{_B}  ▲ TLM — {title}{_X}\n{bar}\n\n{detail}\n\n{bar}\n"
    return {
        "additionalContext": (
            f"IMPORTANT — Display this TLM status to the user BEFORE your response:\n"
            f"```\n▲ TLM — {title}\n{detail}\n```\n"
            f"Then continue with your response.\n\n"
            f"Internal context: {visual}"
        ),
    }


def _tlm_ok(title: str, detail: str) -> dict:
    """Green OK — Claude relays to user."""
    bar = f"{_G}{'━' * 52}{_X}"
    visual = f"\n{bar}\n{_G}{_B}  ✓ TLM — {title}{_X}\n{bar}\n\n{detail}\n\n{bar}\n"
    return {
        "additionalContext": (
            f"IMPORTANT — Display this TLM status to the user BEFORE your response:\n"
            f"```\n✓ TLM — {title}\n{detail}\n```\n"
            f"Then continue with your response.\n\n"
            f"Internal context: {visual}"
        ),
    }


# ---------------------------------------------------------------------------
# Hook A — Auto-Interviewer (plan review + pre-commit diff review)
# ---------------------------------------------------------------------------

def hook_session_start(project_root: str) -> str:
    """SessionStart hook: inject project context into Claude's session."""
    root = Path(project_root)
    tlm_dir = root / ".tlm"

    if not tlm_dir.exists():
        return "TLM is not initialized in this project. Run `tlm install` to set up."

    state = read_state(project_root)
    phase = state.get("phase", "idle")
    activity = state.get("activity_type")
    config = load_project_config(project_root)
    quality = config.get("quality_control", "standard")

    bar = f"{_C}{'━' * 52}{_X}"
    parts = [
        "",
        bar,
        f"{_C}{_B}  TLM — Tech Lead & Manager{_X}{'':>16}{_G}{_B}ACTIVE{_X}",
        bar,
        "",
        f"  {_B}Quality:{_X}  {quality.upper():<14} {_B}Phase:{_X}  {phase}",
    ]
    if activity:
        parts.append(f"  {_B}Activity:{_X} {activity}")

    parts.append("")
    if quality == "high":
        parts.append(f"  {_R}{_B}ENFORCEMENT RULES:{_X}")
        parts.append(f"    {_R}\u25a0{_X} Source code writes   {_R}BLOCKED{_X}  (interview required)")
        parts.append(f"    {_R}\u25a0{_X} Git commits          {_R}BLOCKED{_X}  (during interview)")
        parts.append(f"    {_R}\u25a0{_X} Deployments          {_R}BLOCKED{_X}  (quality gates)")
        parts.append(f"    {_Y}\u25a0{_X} TDD                  {_Y}ENFORCED{_X} (tests first)")
    elif quality == "standard":
        parts.append(f"  {_Y}{_B}ENFORCEMENT RULES:{_X}")
        parts.append(f"    {_Y}\u25b2{_X} Source code writes   {_Y}WARNED{_X}   (interview recommended)")
        parts.append(f"    {_R}\u25a0{_X} Deployments          {_R}BLOCKED{_X}  (quality gates)")
        parts.append(f"    {_Y}\u25b2{_X} Code review          {_Y}WARNED{_X}   (on commit)")
        parts.append(f"    {_Y}\u25a0{_X} TDD                  {_Y}ENFORCED{_X} (tests first)")
    elif quality == "relaxed":
        parts.append(f"  {_D}Advisory mode — minimal enforcement{_X}")

    active = get_active_gaps(project_root)
    if active:
        parts.append("")
        parts.append(f"  {_Y}Gaps ({len(active)}):{_X}")
        for g in active[:3]:
            parts.append(f"    {_Y}\u2022{_X} {g['description']}")
        if len(active) > 3:
            parts.append(f"    {_D}... +{len(active) - 3} more{_X}")

    knowledge_file = tlm_dir / "knowledge.md"
    if knowledge_file.exists():
        try:
            knowledge = knowledge_file.read_text()
            facts = [l.strip() for l in knowledge.split("\n")
                     if l.strip() and not l.startswith(("#", "_", "---"))]
            if facts:
                parts.append("")
                parts.append(f"  {_G}Knowledge ({len(facts)} facts){_X}")
                for fact in facts[:5]:
                    parts.append(f"    {_D}{fact}{_X}")
        except OSError:
            pass

    # Load learned rules from knowledge.db
    db_rules = _load_knowledge_db_rules(str(tlm_dir))
    if db_rules:
        parts.append("")
        parts.append(f"  {_G}Learned rules ({len(db_rules)}){_X}")
        for rule in db_rules[:5]:
            parts.append(f"    {_D}{rule['rule_text']}{_X}")
        if len(db_rules) > 5:
            parts.append(f"    {_D}... +{len(db_rules) - 5} more{_X}")

    parts.extend([
        "",
        f"  {_D}Read CLAUDE.md for full TLM rules.{_X}",
        f"  {_D}Attribute knowledge: 'Based on TLM analysis, [fact].'{_X}",
        "",
        bar,
        "",
    ])

    return "\n".join(parts)


def hook_prompt_submit(project_root: str, prompt_text: str = "") -> dict:
    """UserPromptSubmit hook: phase-specific context + gap warnings + prompt capture + learning."""
    state = read_state(project_root)
    phase = state.get("phase", "idle")
    activity = state.get("activity_type")

    # Capture prompt for session learning
    if prompt_text:
        _capture_prompt(project_root, prompt_text, phase)

    # Accept risks: clear plan_review_pending and transition to implementation
    if state.get("plan_review_pending") and prompt_text:
        if re.search(r"accept\s+risks?", prompt_text, re.IGNORECASE):
            state["plan_review_pending"] = False
            state["phase"] = "implementation"
            state["spec_review_status"] = "approved"
            write_state(project_root, state)
            return _tlm_ok("RISKS ACCEPTED", "Phase: implementation. TDD is mandatory.")

    # Escape hatch: if user says "just do it" / "skip interview" while in
    # tlm_active, auto-reset to idle so they can work without the spec flow.
    if phase == "tlm_active" and prompt_text:
        skip_patterns = re.compile(
            r"(?:just do it|skip (?:interview|tlm|spec)|do it anyway|"
            r"skip the interview|no interview|no spec|just fix|just change)",
            re.IGNORECASE,
        )
        if skip_patterns.search(prompt_text):
            write_state(project_root, {"phase": "idle", "activity_type": None, "active_spec": None})
            phase = "idle"
            sys.stderr.write(
                f"\n{_C}{_B}[TLM]{_X} Interview skipped. Working in idle mode.\n\n"
            )
            sys.stderr.flush()

    context_parts = []

    # Load cached realtime insights and inject
    insight_ctx = _load_and_inject_insights(project_root)
    if insight_ctx:
        context_parts.append(insight_ctx)

    # Phase-specific context
    config = load_project_config(project_root)
    quality = config.get("quality_control", "standard")

    if phase == "idle":
        if quality == "high":
            caution = _tlm_caution(
                "ENFORCEMENT ACTIVE",
                "  Source code writes are BLOCKED until you classify this\n"
                "  request and complete the discovery interview.\n"
                "  Check Tier 1 / Tier 2 in CLAUDE.md.\n"
                "  Start with 'TLM > [reason]. Let me refine your requirements first.'\n"
                "  Config files, docs, and tests are allowed."
            )
            context_parts.append(caution["additionalContext"])
        elif quality == "standard":
            context_parts.append(
                "[TLM] Before responding, classify this request: "
                "Is it a significant engineering activity? "
                "Check Tier 1 (always activate) and Tier 2 (self-classify) "
                "in CLAUDE.md. If significant, enter interview mode first. "
                "If activating TLM, start your response with "
                "'TLM > [reason]. Let me refine your requirements first.'\n\n"
                "IMPORTANT: Do NOT activate TLM for small/trivial tasks. These should "
                "be done directly WITHOUT interview or spec:\n"
                "- Bug fixes under ~20 lines\n"
                "- Config changes, env var updates, dependency bumps\n"
                "- Renaming, reformatting, typo fixes\n"
                "- Adding/editing a single function or method\n"
                "- Quick scripts, one-off commands\n"
                "- Anything the user explicitly says is small or quick\n"
                "When in doubt, just do the task. Only activate TLM for genuinely "
                "complex multi-file features, architecture decisions, or deployments."
            )
        # Relaxed: no idle context injection
    elif phase == "tlm_active":
        context_parts.append(
            f"[TLM] You are in interview mode (activity: {activity or 'unknown'}). "
            "Continue asking questions one at a time. "
            "Do not write code until the interview is complete and spec is generated."
        )
    elif phase == "implementation":
        active_spec = state.get("active_spec")
        spec_note = f" Active spec: {active_spec}." if active_spec else ""
        context_parts.append(
            f"[TLM] Implementation phase.{spec_note} "
            "TDD is mandatory: write tests first, verify they fail, "
            "then implement, then verify they pass."
        )
    elif phase == "deployment":
        context_parts.append(
            "[TLM] Deployment phase. Follow the deployment pipeline. Never skip environments."
        )

    # Gap warnings: check if prompt mentions a known gap
    if prompt_text:
        active = get_active_gaps(project_root)
        for gap in active:
            gap_keywords = _gap_keywords(gap)
            prompt_lower = prompt_text.lower()
            if any(kw in prompt_lower for kw in gap_keywords):
                context_parts.append(
                    f"\n[TLM Warning] '{gap['category']}' is flagged as a gap in this project. "
                    f"Description: {gap['description']}. "
                    f"Status: {gap['status']}. "
                    "Consider fixing this gap properly with `tlm gaps` before proceeding."
                )
                break  # Only show one gap warning per prompt

    # Fire background prompt learning (rate-limited)
    if prompt_text:
        _fire_prompt_learning_bg(project_root, prompt_text, phase)

    return {"additionalContext": "\n".join(context_parts)}


def hook_guard(project_root: str, tool_input: dict) -> dict:
    """PreToolUse hook for Write/Edit: blocks during interview, enforces TDD."""
    tool_name = tool_input.get("tool_name", "")
    file_input = tool_input.get("tool_input", {})
    file_path = file_input.get("file_path", "")

    if tool_name not in ("Write", "Edit"):
        return {}

    # Allow writes outside the project root (plan files, global configs, etc.)
    if file_path and not file_path.startswith(project_root) and not file_path.startswith("./"):
        return {}

    state = read_state(project_root)
    phase = state.get("phase", "idle")

    is_tlm_file = "/.tlm/" in file_path or file_path.startswith(".tlm/")
    is_test_file = _is_test_file(file_path)

    # During interview: block source writes
    if phase == "tlm_active" and not is_test_file and not is_tlm_file:
        return _tlm_block(
            "INTERVIEW MODE",
            "  Complete the discovery interview and get spec approval\n"
            "  before writing code."
        )

    # During implementation: spec approval check (TDD enforced at plan level, not file level)
    if phase == "implementation" and not is_test_file and not is_tlm_file:
        # Check spec approval
        spec_status = state.get("spec_review_status", "none")
        if spec_status != "approved":
            return _tlm_block(
                "SPEC NOT APPROVED",
                "  Spec has not been reviewed/approved yet.\n"
                "  Save the spec to .tlm/specs/ to trigger review."
            )

    # Idle phase: quality-tier-aware enforcement
    if phase == "idle" and not is_tlm_file and not is_test_file:
        is_source = _is_likely_source_code(file_path)
        config = load_project_config(project_root)
        quality = config.get("quality_control", "standard")

        if quality == "high" and is_source:
            # Auto-transition to tlm_active and block
            state["phase"] = "tlm_active"
            write_state(project_root, state)
            return _tlm_block(
                "INTERVIEW REQUIRED",
                "  Source code writes are BLOCKED in idle+HIGH.\n"
                "  Classify this request and start the discovery interview first."
            )
        elif quality == "standard" and is_source:
            # Warn but don't block
            return _tlm_caution(
                "NO INTERVIEW",
                "  You're writing source code without completing the\n"
                "  interview process. Consider classifying this request and\n"
                "  entering interview mode first (TLM > reason)."
            )

    # Gap warning on related files (non-blocking, idle only)
    if phase == "idle" and not is_tlm_file:
        gap_ctx = _check_gap_file_warning(project_root, file_path)
        if gap_ctx:
            return gap_ctx

    return {}


def hook_compliance_gate(project_root: str, tool_input: dict) -> dict:
    """PreToolUse hook for Bash: compliance gate on git commit + deploy commands."""
    command = tool_input.get("command", "")

    # Deployment gate: always block deploy commands
    if _is_deploy_command(command):
        root = Path(project_root)
        if (root / ".tlm").exists():
            return _tlm_block(
                "DEPLOYMENT GATE",
                "  Run `tlm check` before deploying.\n"
                "  All quality gates must pass before deployment to any environment."
            )

    if not _is_git_commit(command):
        return {}

    root = Path(project_root)
    tlm_dir = root / ".tlm"
    if not tlm_dir.exists():
        return {}

    config = load_project_config(project_root)
    quality = config.get("quality_control", "standard")
    state = read_state(project_root)
    phase = state.get("phase", "idle")
    active_spec = state.get("active_spec")

    # Phase gate: block commits during interview (all tiers except relaxed)
    if phase == "tlm_active" and quality != "relaxed":
        return _tlm_block(
            "INTERVIEW IN PROGRESS",
            "  Complete the discovery interview and get spec approval\n"
            "  before committing code.\n\n"
            f"  Current phase: tlm_active\n"
            f"  Next step: Write spec to .tlm/specs/ to trigger review."
        )

    # Build baseline text context
    parts = [
        "[TLM] COMPLIANCE CHECK before commit:",
        "Tell the user: 'TLM > Running compliance check before commit.'",
    ]

    if active_spec:
        parts.append(f"\n1. Verify changes against spec: {active_spec}")
        parts.append("   - Are ALL spec items implemented?")
        parts.append("   - Are ALL specified test cases written and passing?")

    parts.append("\nEnsure all tests pass before committing.")

    # Mechanical enforcement checks (if enforcement.json exists)
    enforcement_result = _run_enforcement_checks(project_root)
    if enforcement_result:
        if not enforcement_result["passed"]:
            failed = [r for r in enforcement_result["results"] if not r["passed"]]
            has_blocker = any(r.get("blocker") for r in failed)

            if has_blocker and quality == "high":
                fail_details = "\n".join(
                    f"  [{r['name']}] {r.get('output', 'FAILED')}" for r in failed
                )
                return _tlm_block(
                    "ENFORCEMENT CHECKS FAILED",
                    f"  Blocker checks failed:\n{fail_details}"
                )

            # Add failures to context
            for r in failed:
                parts.append(f"\n[TLM] Enforcement check FAILED: {r['name']} — {r.get('output', '')}")

    # Relaxed: text-only, no server call
    if quality == "relaxed":
        return {"additionalContext": "\n".join(parts)}

    # Standard/High: attempt server code review
    review_result = _run_code_review(project_root, command)

    if "error" in review_result:
        # Degrade to text-only
        parts.append(f"\n[TLM Warning] Server review unavailable: {review_result['error']}")
        return _tlm_caution(
            "REVIEW UNAVAILABLE",
            "\n".join(parts)
        )

    verdict = review_result.get("combined_verdict", "pass")
    review_context = _format_review_context(review_result, "code")

    if verdict in ("pass", "warn"):
        return _tlm_ok("CODE REVIEW PASSED", review_context)
    elif verdict == "fail" and quality == "high":
        issues = review_result.get("issues", [])
        issue_summary = "; ".join(
            i.get("description", "Unknown issue") for i in issues[:5]
        )
        return _tlm_block(
            "CODE REVIEW FAILED",
            f"  Issues: {issue_summary or 'Review failed'}"
        )
    else:
        # Standard + fail: warn but don't block
        return _tlm_caution("CODE REVIEW ISSUES", review_context)


def hook_deployment_gate(project_root: str, tool_input: dict) -> dict:
    """PreToolUse hook for Bash: ALWAYS blocks deploy commands."""
    command = tool_input.get("command", "")

    if not _is_deploy_command(command):
        return {}

    root = Path(project_root)
    if not (root / ".tlm").exists():
        return {}

    return _tlm_block(
        "DEPLOYMENT GATE",
        "  Run `tlm check` before deploying.\n"
        "  All quality gates must pass before deployment to any environment."
    )


def hook_spec_review(project_root: str, tool_input: dict) -> dict:
    """PostToolUse hook for Write: server-backed spec review."""
    file_input = tool_input.get("tool_input", {})
    file_path = file_input.get("file_path", "")

    if not _is_spec_file(file_path):
        return {}

    root = Path(project_root)
    tlm_dir = root / ".tlm"
    if not tlm_dir.exists():
        return {}

    config = load_project_config(project_root)
    quality = config.get("quality_control", "standard")

    # Relaxed: auto-approve, no server call
    if quality == "relaxed":
        state = read_state(project_root)
        state["spec_review_status"] = "approved"
        state["active_spec"] = file_path
        if state.get("phase") == "tlm_active":
            state["phase"] = "implementation"
        write_state(project_root, state)
        return _tlm_ok("SPEC AUTO-APPROVED", "Relaxed quality tier — no server review.")

    # Call server for review
    review_result = _run_spec_review(project_root, file_path)

    # Update state based on result
    state = read_state(project_root)
    state["active_spec"] = file_path

    if "error" in review_result:
        # Degrade gracefully: approve with warning
        state["spec_review_status"] = "approved"
        if state.get("phase") == "tlm_active":
            state["phase"] = "implementation"
        write_state(project_root, state)
        context = _format_review_context(review_result, "spec")
        return _tlm_caution("REVIEW UNAVAILABLE", context)

    severity = review_result.get("severity", "pass")
    if severity in ("pass", "warn"):
        state["spec_review_status"] = "approved"
        if state.get("phase") == "tlm_active":
            state["phase"] = "implementation"
    else:
        state["spec_review_status"] = "rejected"
    write_state(project_root, state)

    # Cache result
    cache_dir = tlm_dir / "cache"
    cache_dir.mkdir(parents=True, exist_ok=True)
    cache_file = cache_dir / "last_review.json"
    cache_file.write_text(json.dumps(review_result, indent=2))

    context = _format_review_context(review_result, "spec")
    if severity in ("pass", "warn"):
        return _tlm_ok("SPEC APPROVED", context)
    else:
        return _tlm_caution("SPEC NEEDS WORK", context)


_PLANS_DIR = Path.home() / ".claude" / "plans"


def _find_latest_plan(plans_dir: Path = _PLANS_DIR) -> Path | None:
    """Find the most recently modified .md file in the plans directory."""
    if not plans_dir.exists():
        return None
    plan_files = sorted(plans_dir.glob("*.md"), key=lambda f: f.stat().st_mtime, reverse=True)
    return plan_files[0] if plan_files else None


def hook_auto_interviewer_plan(project_root: str, tool_input: dict, plans_dir: Path = _PLANS_DIR) -> dict:
    """PostToolUse on ExitPlanMode: review the approved plan before Claude writes code."""
    root = Path(project_root)
    if not (root / ".tlm").exists():
        return {}

    # Find the latest plan file
    plan_file = _find_latest_plan(plans_dir)
    if not plan_file:
        return {}

    try:
        plan_content = plan_file.read_text()
    except OSError:
        return {}

    if not plan_content or len(plan_content.strip()) < 20:
        return {}

    client = _get_review_client(project_root)
    if not client:
        return {}

    config = load_project_config(project_root)
    project_id = config.get("project_id", 0)

    # Show user that TLM is reviewing
    sys.stderr.write(f"\n{_C}{_B}  \u25ce TLM is reviewing your plan...{_X}\n")
    sys.stderr.flush()

    _print_status("\u23f3", "Reviewing Plan...", color=_C)

    try:
        result = client.review_plan_or_diff(
            project_id,
            content=plan_content,
            review_type="plan",
            timeout=60,
        )
    except Exception:
        _print_status("\u25b2", "Review Timed Out", "Allowing Claude to proceed.", color=_Y)
        return _tlm_caution("Review Timed Out", "Server didn't respond in 60s.")

    reason = result.get("reason", "")

    # Check for TDD-related issues in the review result
    issues = result.get("issues", [])
    tdd_issues = [
        i for i in issues
        if isinstance(i, str) and (
            "tdd" in i.lower()
            or "test-driven" in i.lower()
            or ("test" in i.lower() and "first" in i.lower())
        )
    ]

    if result.get("decision") == "pass":
        _print_status("\u2713", "Plan Approved", reason, color=_G)
        # Highlight TDD gaps even on pass
        if tdd_issues:
            tdd_msg = tdd_issues[0] if tdd_issues else "Include TDD: write tests first \u2192 verify fail \u2192 implement \u2192 verify pass."
            return _tlm_caution(
                "PLAN APPROVED \u2014 TDD MISSING",
                f"{reason}\n\n"
                "\u25b2 TLM \u2014 PLAN NEEDS TDD\n"
                "  Your plan does not include a Test-Driven Development approach.\n"
                "  TLM requires plans to include: write tests first \u2192 verify they fail \u2192\n"
                "  implement \u2192 verify they pass.\n"
                f"  {tdd_msg}\n"
                "  Revise the plan to include TDD before proceeding."
            )
        return _tlm_ok("Plan Approved", reason)

    # REJECT — return additionalContext that forces Claude to stop and clarify
    issue_text = "\n".join(f"  - {i}" for i in issues) if issues else f"  - {reason or 'Plan needs clarification.'}"

    _print_status("\u25a0", "Plan Rejected", issue_text, color=_R)

    # Highlight TDD gaps prominently on rejection
    tdd_extra = ""
    if tdd_issues:
        tdd_msg = tdd_issues[0] if tdd_issues else "Include TDD: write tests first \u2192 verify fail \u2192 implement \u2192 verify pass."
        tdd_extra = (
            "\n\n\u25b2 TLM \u2014 PLAN NEEDS TDD\n"
            f"  {tdd_msg}"
        )

    return {
        "additionalContext": (
            f"[TLM REJECT]: Do not write code yet. The plan has issues:\n"
            f"{issue_text}{tdd_extra}\n\n"
            f"Ask the user for clarification on these before proceeding."
        )
    }


def _get_staged_diff(project_root: str) -> str | None:
    """Get the staged git diff. Returns None on failure."""
    try:
        result = subprocess.run(
            ["git", "diff", "--cached"],
            capture_output=True, text=True, cwd=project_root, timeout=10,
        )
        return result.stdout.strip() if result.returncode == 0 else None
    except (subprocess.TimeoutExpired, OSError):
        return None


def _review_diff_before_commit(project_root: str, command: str) -> dict:
    """Hook A trigger 2: send diff to server for senior staff review before commit."""
    diff = _get_staged_diff(project_root)
    if not diff or len(diff.strip()) < 10:
        return {}

    client = _get_review_client(project_root)
    if not client:
        return {}

    config = load_project_config(project_root)
    project_id = config.get("project_id", 0)

    sys.stderr.write("[TLM] Reviewing diff before commit...\n")

    try:
        result = client.review_plan_or_diff(
            project_id,
            content=diff,
            review_type="diff",
            timeout=10,
        )
    except Exception:
        sys.stderr.write("[TLM] Server timeout on pre-commit review. Allowing commit.\n")
        return {}

    if result.get("decision") == "pass":
        sys.stderr.write("[TLM] Diff approved.\n")
        return {}

    # REJECT — block the commit
    reason = result.get("reason", "Code review found issues.")
    issues = result.get("issues", [])
    issue_text = "\n".join(f"  - {i}" for i in issues) if issues else f"  - {reason}"

    return _tlm_block(
        "PRE-COMMIT REVIEW FAILED",
        f"  Issues found:\n{issue_text}\n\n  Fix these before committing."
    )


# ---------------------------------------------------------------------------
# Hook B — Execution Firewall
# ---------------------------------------------------------------------------

_RISKY_PATTERNS = [
    # Deploy/publish
    r'\b(firebase|vercel|netlify|fly|railway|render|heroku)\s+deploy\b',
    r'\b(eb|sam|serverless|cdk)\s+deploy\b',
    r'\bgcloud\s+app\s+deploy\b',
    r'\bkubectl\s+(apply|delete|replace)\b',
    r'\bdocker\s+push\b',
    r'\bhelm\s+(install|upgrade|delete)\b',
    r'\bgit\s+push\s+.*\b(prod|production|main|master)\b',
    r'\bterraform\s+(apply|destroy)\b',
    # Destructive
    r'\brm\s+-[rRfF]*[rRfF]\b',
    r'\brm\s+--force\b',
    r'\bdrop\s+(database|table|schema)\b',
    r'\btruncate\s+table\b',
    # Risky keywords in scripts/ or bin/ paths
    r'(scripts|bin)/\S*(deploy|release|publish)',
]

_COMPILED_RISKY = [re.compile(p, re.IGNORECASE) for p in _RISKY_PATTERNS]


def _matches_risky_pattern(command: str) -> bool:
    """Check if command matches any risky regex pattern."""
    for pattern in _COMPILED_RISKY:
        if pattern.search(command):
            return True
    return False


def _load_permanent_overrides(project_root: str) -> list[str]:
    """Load permanently overridden commands from .tlm/permanent_overrides.json."""
    overrides_file = Path(project_root) / ".tlm" / "permanent_overrides.json"
    if not overrides_file.exists():
        return []
    try:
        data = json.loads(overrides_file.read_text())
        return data.get("commands", [])
    except (json.JSONDecodeError, OSError):
        return []


def _is_permanently_overridden(project_root: str, command: str) -> bool:
    """Check if a command has been permanently overridden."""
    overrides = _load_permanent_overrides(project_root)
    return command.strip() in overrides


def _add_permanent_override(project_root: str, command: str):
    """Add a command to the permanent overrides list."""
    overrides_file = Path(project_root) / ".tlm" / "permanent_overrides.json"
    overrides = _load_permanent_overrides(project_root)
    cmd = command.strip()
    if cmd not in overrides:
        overrides.append(cmd)
    overrides_file.write_text(json.dumps({"commands": overrides}, indent=2))


def _log_override(project_root: str, command: str, reason: str, action: str):
    """Append override event to .tlm/overrides.log."""
    import datetime
    ts = datetime.datetime.now().isoformat(timespec="seconds")
    try:
        with open(Path(project_root) / ".tlm" / "overrides.log", "a") as f:
            f.write(f"{ts} | {action} | {command} | {reason}\n")
    except OSError:
        pass


def _handle_block_with_override(project_root: str, command: str, reason: str) -> dict:
    """Display block UI with override options. Returns {} to allow or block dict."""
    sys.stderr.write(f"\n{'━' * 52}\n")
    sys.stderr.write(f"  ■ TLM — COMMAND BLOCKED\n")
    sys.stderr.write(f"{'━' * 52}\n\n")
    sys.stderr.write(f"  Command: {command}\n")
    sys.stderr.write(f"  Reason:  {reason}\n\n")
    sys.stderr.write(f"  [1] Override once\n")
    sys.stderr.write(f"  [2] Override always (never block this again)\n")
    sys.stderr.write(f"  [N] Block (default)\n\n")

    try:
        choice = input("  Choice: ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        choice = "n"

    if choice == "1":
        _log_override(project_root, command, reason, "OVERRIDE_ONCE")
        return {}  # allow

    if choice == "2":
        _log_override(project_root, command, reason, "OVERRIDE_ALWAYS")
        _add_permanent_override(project_root, command)
        return {}  # allow + remember

    _log_override(project_root, command, reason, "BLOCKED")
    return _tlm_block("COMMAND BLOCKED", f"  {reason}")


def _is_git_commit(command: str) -> bool:
    """Check if a shell command is a git commit."""
    return bool(re.search(r'\bgit\s+commit\b', command))


def hook_bash_firewall(project_root: str, tool_input: dict) -> dict:
    """PreToolUse on Bash: local regex pre-filter + server escalation."""
    command = tool_input.get("command", "")
    root = Path(project_root)
    if not (root / ".tlm").exists():
        return {}

    # Hook A: git commit → separate review path (10s timeout)
    if _is_git_commit(command):
        return _review_diff_before_commit(project_root, command)

    # Check permanent overrides
    if _is_permanently_overridden(project_root, command):
        return {}

    # Step 1: Local regex pre-filter (< 500ms)
    if not _matches_risky_pattern(command):
        return {}  # safe command, pass instantly

    # Step 2: Server escalation (10s timeout)
    client = _get_review_client(project_root)
    if not client:
        return {}  # no auth, fail-open

    config = load_project_config(project_root)
    project_id = config.get("project_id", 0)

    sys.stderr.write("[TLM] Reviewing command...\n")

    try:
        result = client.review_command(
            project_id, command, timeout=10,
        )
    except Exception:
        sys.stderr.write("[TLM] Server timeout on command review. Allowing command to proceed.\n")
        return {}  # fail-open on timeout

    if result.get("decision") == "pass":
        sys.stderr.write("[TLM] Command approved.\n")
        return {}

    # BLOCKED — interactive override
    reason = result.get("reason", "Command flagged as risky.")
    return _handle_block_with_override(project_root, command, reason)


# ---------------------------------------------------------------------------
# Stop — session cleanup + session learning
# ---------------------------------------------------------------------------

def hook_stop(project_root: str) -> dict:
    """Stop hook: session cleanup + session learning."""
    root = Path(project_root)
    tlm_dir = root / ".tlm"

    if not tlm_dir.exists():
        return {}

    # Session learning: analyze captured prompts before cleanup
    prompts_file = tlm_dir / "session_prompts.jsonl"
    if prompts_file.exists():
        try:
            prompts = []
            for line in prompts_file.read_text().strip().split("\n"):
                if line.strip():
                    prompts.append(json.loads(line))
            if prompts:
                try:
                    _run_session_learning(project_root, prompts)
                except Exception:
                    pass  # Never crash on learning failure
        except (json.JSONDecodeError, OSError):
            pass
        # Clean up prompts file
        prompts_file.unlink(missing_ok=True)

    # Reset tlm_active to idle (interview didn't complete this session)
    state = read_state(project_root)
    state.pop("plan_review_pending", None)
    if state.get("phase") == "tlm_active":
        state["phase"] = "idle"
    write_state(project_root, state)

    return {}


# ─── Internal helpers ─────────────────────────────────────────

def _gap_keywords(gap: dict) -> list[str]:
    """Extract keywords from a gap for prompt matching."""
    keywords = []
    gap_id = gap.get("id", "").lower()
    gap_type = gap.get("type", "").lower()
    category = gap.get("category", "").lower()
    description = gap.get("description", "").lower()

    keywords.append(gap_id)
    if gap_type and gap_type != gap_id:
        keywords.append(gap_type)
    if category:
        keywords.extend(category.lower().split("/"))

    # Extract significant words from description
    for word in description.split():
        if len(word) > 4 and word not in ("detected", "pipeline", "implemented", "project"):
            keywords.append(word)

    return [k for k in keywords if k]


_SOURCE_EXTENSIONS = {
    ".py", ".js", ".ts", ".jsx", ".tsx", ".mjs", ".cjs",
    ".go", ".rs", ".rb", ".java", ".kt", ".scala",
    ".c", ".cpp", ".h", ".hpp", ".cs", ".swift",
    ".php", ".lua", ".dart", ".vue", ".svelte",
    ".sh", ".bash", ".zsh", ".sql",
    ".ex", ".exs", ".zig", ".nim",
}


def _is_likely_source_code(file_path: str) -> bool:
    """Check if a file path looks like source code (not config/docs)."""
    ext = Path(file_path).suffix.lower()
    if not ext:
        return False
    return ext in _SOURCE_EXTENSIONS


def _is_test_file(file_path: str) -> bool:
    """Check if a file path is a test file."""
    parts = Path(file_path).parts
    if not parts:
        return False
    filename = parts[-1].lower()

    if (filename.startswith("test_") or filename.startswith("test.")
            or "_test." in filename or ".test." in filename
            or "_spec." in filename or ".spec." in filename):
        return True

    test_dirs = {"tests", "test", "spec", "specs", "__tests__"}
    return any(part.lower() in test_dirs for part in parts[:-1])


def _check_gap_file_warning(project_root: str, file_path: str) -> dict | None:
    """Warn if writing to a file related to a known gap."""
    active = get_active_gaps(project_root)
    if not active:
        return None

    filename = Path(file_path).stem.lower()
    for gap in active:
        gap_id = gap.get("id", "").lower()
        gap_type = gap.get("type", "").lower()
        if gap_id in filename or gap_type in filename:
            return {
                "additionalContext": (
                    f"[TLM] You're modifying '{Path(file_path).name}', but "
                    f"'{gap['category']}' is flagged as a gap ({gap['status']}). "
                    "Consider fixing this gap properly first."
                ),
            }

    return None


def _is_deploy_command(command: str) -> bool:
    """Check if a shell command is a deployment command."""
    deploy_patterns = [
        r'\bgit\s+push\s+.*\b(prod|production|main|master)\b',
        r'\b(eb|firebase|fly|sam|serverless)\s+deploy\b',
        r'\bkubectl\s+apply\b.*\b(prod|production)\b',
        r'\bdocker\s+push\b',
        r'\bhelm\s+(install|upgrade)\b',
    ]
    for pattern in deploy_patterns:
        if re.search(pattern, command, re.IGNORECASE):
            return True
    return False


def _is_spec_file(file_path: str) -> bool:
    """Check if a file path is in .tlm/specs/."""
    return "/.tlm/specs/" in file_path or file_path.startswith(".tlm/specs/")


def _get_review_client(project_root: str) -> TLMClient | None:
    """Create a TLMClient from saved credentials. Returns None if not authenticated."""
    api_key = get_api_key()
    if not api_key:
        return None
    server_url = get_server_url()
    return TLMClient(server_url=server_url, api_key=api_key)


def _run_spec_review(project_root: str, spec_path: str) -> dict:
    """Call server for spec review. Returns result or {error: ...}."""
    client = _get_review_client(project_root)
    if not client:
        return {"error": "Not authenticated — skipping server review"}

    config = load_project_config(project_root)
    project_id = config.get("project_id", 0)
    quality = config.get("quality_control", "standard")

    # Read spec content
    try:
        spec_content = Path(spec_path).read_text()
    except OSError:
        return {"error": f"Cannot read spec file: {spec_path}"}

    # Read knowledge if available
    knowledge = ""
    knowledge_path = Path(project_root) / ".tlm" / "knowledge.md"
    if knowledge_path.exists():
        try:
            knowledge = knowledge_path.read_text()
        except OSError:
            pass

    try:
        result = client.review_spec(
            project_id=project_id,
            spec=spec_content,
            project_knowledge=knowledge,
            quality_level=quality,
            timeout=60,
        )
        return result
    except httpx.TimeoutException:
        return {"error": "Server review timed out"}
    except httpx.HTTPError as e:
        return {"error": f"Server review failed: {e}"}
    except Exception as e:
        return {"error": f"Unexpected error during spec review: {type(e).__name__}: {e}"}


def _run_code_review(project_root: str, command: str) -> dict:
    """Run git diff and call server for code review. Returns result or {error: ...}."""
    client = _get_review_client(project_root)
    if not client:
        return {"error": "Not authenticated — skipping server review"}

    # Get git diff
    try:
        diff_result = subprocess.run(
            ["git", "diff", "--cached"],
            capture_output=True, text=True, cwd=project_root, timeout=10,
        )
        names_result = subprocess.run(
            ["git", "diff", "--cached", "--name-only"],
            capture_output=True, text=True, cwd=project_root, timeout=10,
        )
    except (subprocess.TimeoutExpired, OSError) as e:
        return {"error": f"git diff failed: {e}"}

    diff_text = diff_result.stdout.strip()
    files_changed = [f for f in names_result.stdout.strip().split("\n") if f]

    if not diff_text:
        return {"error": "No staged changes to review"}

    # Load active spec
    state = read_state(project_root)
    active_spec = state.get("active_spec")
    spec_content = ""
    if active_spec:
        try:
            spec_content = Path(active_spec).read_text()
        except OSError:
            pass

    if not spec_content:
        return {"error": "No active spec — skipping server code review"}

    # Read knowledge
    knowledge = ""
    knowledge_path = Path(project_root) / ".tlm" / "knowledge.md"
    if knowledge_path.exists():
        try:
            knowledge = knowledge_path.read_text()
        except OSError:
            pass

    config = load_project_config(project_root)
    project_id = config.get("project_id", 0)

    try:
        result = client.review_code(
            project_id=project_id,
            spec=spec_content,
            code=diff_text,
            files_changed=files_changed,
            project_knowledge=knowledge,
            timeout=90,
        )
        return result
    except httpx.TimeoutException:
        return {"error": "Server code review timed out"}
    except httpx.HTTPError as e:
        return {"error": f"Server code review failed: {e}"}
    except Exception as e:
        return {"error": f"Unexpected error during code review: {type(e).__name__}: {e}"}


def _format_review_context(result: dict, review_type: str) -> str:
    """Format review results as readable context for Claude."""
    if "error" in result:
        return (
            f"[TLM Warning] Server {review_type} review unavailable: {result['error']}. "
            "Proceeding with local checks only."
        )

    parts = []

    if review_type == "spec":
        severity = result.get("severity", "unknown")
        status_map = {"pass": "APPROVED", "warn": "APPROVED (with warnings)", "fail": "REJECTED"}
        parts.append(f"[TLM Spec Review] Status: {status_map.get(severity, severity.upper())}")

        gaps = result.get("gaps", [])
        if gaps:
            parts.append(f"\nGaps found ({len(gaps)}):")
            for gap in gaps[:5]:
                desc = gap.get("description", "Unknown")
                sev = gap.get("severity", "medium")
                parts.append(f"  [{sev}] {desc}")

        questions = result.get("follow_up_questions", [])
        if questions:
            parts.append("\nFollow-up questions:")
            for q in questions[:3]:
                parts.append(f"  - {q}")

    elif review_type == "code":
        verdict = result.get("combined_verdict", "unknown")
        verdict_map = {"pass": "PASSED", "warn": "PASSED (with warnings)", "fail": "FAILED"}
        parts.append(f"[TLM Code Review] Verdict: {verdict_map.get(verdict, verdict.upper())}")

        issues = result.get("issues", [])
        if issues:
            parts.append(f"\nIssues ({len(issues)}):")
            for issue in issues[:5]:
                desc = issue.get("description", "Unknown")
                sev = issue.get("severity", "medium")
                parts.append(f"  [{sev}] {desc}")

        reviews = result.get("reviews", [])
        if reviews:
            parts.append("\nModel reviews:")
            for review in reviews:
                model = review.get("model", "unknown")
                rv = review.get("verdict", "unknown")
                parts.append(f"  {model}: {rv}")

    return "\n".join(parts)


# ─── Merged features from MVP ────────────────────────────────

def _load_knowledge_db_rules(tlm_dir: str) -> list[dict]:
    """Load learned rules from knowledge.db. Returns empty list on failure."""
    try:
        from tlm.knowledge_db import KnowledgeDB
        db_path = Path(tlm_dir) / "knowledge.db"
        if not db_path.exists():
            return []
        db = KnowledgeDB(tlm_dir)
        rules = db.list_rules()
        db.close()
        return rules
    except Exception:
        return []


def _capture_prompt(project_root: str, prompt_text: str, phase: str):
    """Capture user prompt to session_prompts.jsonl for session learning."""
    tlm_dir = Path(project_root) / ".tlm"
    if not tlm_dir.exists():
        return

    prompts_file = tlm_dir / "session_prompts.jsonl"
    entry = {
        "prompt": prompt_text,
        "timestamp": _time.time(),
        "phase": phase,
    }
    try:
        with open(prompts_file, "a") as f:
            f.write(json.dumps(entry) + "\n")
    except OSError:
        pass


# ─── Real-time prompt learning ────────────────────────────────

_last_prompt_learn_ts: float = 0.0
_PROMPT_LEARN_COOLDOWN = 5.0  # seconds


def _fire_prompt_learning_bg(project_root: str, prompt_text: str, phase: str):
    """Fire a background subprocess to analyze the prompt. Rate-limited."""
    global _last_prompt_learn_ts
    now = _time.time()
    if now - _last_prompt_learn_ts < _PROMPT_LEARN_COOLDOWN:
        return  # Rate limited
    _last_prompt_learn_ts = now

    try:
        subprocess.Popen(
            ["tlm", "_hook", "_learn_prompt_bg", "--path", project_root],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
    except (OSError, FileNotFoundError):
        pass  # Best effort — never crash on learning failure


def learn_prompt_bg(project_root: str):
    """Background entry point: read last prompt, send to server, cache result."""
    tlm_dir = Path(project_root) / ".tlm"
    prompts_file = tlm_dir / "session_prompts.jsonl"
    if not prompts_file.exists():
        return

    # Read last prompt
    try:
        lines = prompts_file.read_text().strip().split("\n")
        last = json.loads(lines[-1]) if lines else {}
    except (json.JSONDecodeError, OSError, IndexError):
        return

    prompt_text = last.get("prompt", "")
    phase = last.get("phase", "")
    if not prompt_text:
        return

    client = _get_review_client(project_root)
    if not client:
        return

    config = load_project_config(project_root)
    project_id = config.get("project_id", 0)

    try:
        result = client.learn_prompt(
            prompt=prompt_text,
            project_id=project_id,
            phase=phase,
            timeout=15,
        )
    except Exception:
        return

    # Cache result
    cache_dir = tlm_dir / "cache"
    cache_dir.mkdir(parents=True, exist_ok=True)
    insights_file = cache_dir / "realtime_insights.json"

    # Load existing insights
    existing = {"corrections": [], "rules": [], "shown_corrections": []}
    if insights_file.exists():
        try:
            existing = json.loads(insights_file.read_text())
        except (json.JSONDecodeError, OSError):
            pass

    # Merge new corrections
    for corr in result.get("corrections_detected", []):
        existing["corrections"].append({
            "correction": corr.get("correction", ""),
            "timestamp": _time.time(),
        })

    # Merge new rules
    for rule in result.get("rules_detected", []):
        existing["rules"].append(rule)

    # Keep last 20 corrections and 50 rules
    existing["corrections"] = existing["corrections"][-20:]
    existing["rules"] = existing["rules"][-50:]

    try:
        insights_file.write_text(json.dumps(existing, indent=2))
    except OSError:
        pass


def _load_and_inject_insights(project_root: str) -> str | None:
    """Load cached realtime insights + knowledge.db learned rules and return context string."""
    tlm_dir = Path(project_root) / ".tlm"
    cache_dir = tlm_dir / "cache"
    insights_file = cache_dir / "realtime_insights.json"

    parts = []

    # ── 0. Global user-scoped memories from ~/.tlm/knowledge.db ──
    global_db_path = GLOBAL_TLM_DIR / "knowledge.db"
    global_user_texts = set()
    if global_db_path.exists():
        try:
            from tlm.knowledge_db import KnowledgeDB
            gdb = KnowledgeDB(str(GLOBAL_TLM_DIR))
            user_rules = gdb.list_rules()
            gdb.close()

            if user_rules:
                rule_texts = [r["rule_text"] for r in user_rules if r.get("rule_text")]
                global_user_texts = set(rule_texts)
                if rule_texts:
                    parts.append(
                        "[TLM — Your preferences (apply to all projects)]\n"
                        "Based on TLM's analysis of your preferences:\n"
                        + "\n".join(f"  - {r}" for r in rule_texts[-10:])
                    )
                    sys.stderr.write(
                        f"{_C}{_B}[TLM]{_X} Injecting {len(rule_texts[-10:])} user-level preference(s)\n"
                    )
                    for r in rule_texts[-10:]:
                        sys.stderr.write(f"  {_D}-{_X} {r[:100]}\n")
                    sys.stderr.write("\n")
                    sys.stderr.flush()
        except Exception:
            pass

    # ── 1. Knowledge.db watcher-learned rules (project-scoped) ──
    db_path = tlm_dir / "knowledge.db"
    if db_path.exists():
        try:
            from tlm.knowledge_db import KnowledgeDB
            db = KnowledgeDB(str(tlm_dir))
            learned_rules = db.list_rules(source_prefix="watcher_learned")
            db.close()

            if learned_rules:
                # Filter out user-scoped rules (already injected from global DB)
                rule_texts = [
                    r["rule_text"] for r in learned_rules
                    if r.get("rule_text")
                    and r.get("source") != "watcher_learned_user"
                    and r["rule_text"] not in global_user_texts
                ]
                if rule_texts:
                    parts.append(
                        "[TLM — Learned from conversation history]\n"
                        "Based on TLM's analysis of your past conversations:\n"
                        + "\n".join(f"  - {r}" for r in rule_texts[-10:])
                    )
                    sys.stderr.write(
                        f"{_C}{_B}[TLM]{_X} Injecting {len(rule_texts[-10:])} learned rule(s) from conversation history\n"
                    )
                    for r in rule_texts[-10:]:
                        sys.stderr.write(f"  {_D}-{_X} {r[:100]}\n")
                    sys.stderr.write("\n")
                    sys.stderr.flush()
        except Exception:
            pass

    # ── 2. Realtime insights JSON cache ──
    if not insights_file.exists():
        return "\n\n".join(parts) if parts else None

    try:
        data = json.loads(insights_file.read_text())
    except (json.JSONDecodeError, OSError):
        return "\n\n".join(parts) if parts else None

    # Show new corrections (not yet shown)
    shown = set(data.get("shown_corrections", []))
    corrections = data.get("corrections", [])
    new_corrections = [c for c in corrections if c.get("correction") and c["correction"] not in shown]

    if new_corrections:
        corr_text = new_corrections[0]["correction"]
        parts.append(
            f"[TLM — LEARNED FROM YOUR FEEDBACK]\n"
            f"  \"{corr_text}\"\n"
            f"  Apply this preference in your response."
        )
        sys.stderr.write(
            f"\n{_C}{_B}[TLM]{_X} Learned from your feedback:\n"
            f"  {_D}-{_X} {corr_text[:100]}\n\n"
        )
        sys.stderr.flush()
        shown.add(corr_text)
        data["shown_corrections"] = list(shown)[-50:]
        try:
            insights_file.write_text(json.dumps(data, indent=2))
        except OSError:
            pass

    # Inject accumulated rules from JSON cache
    rules = data.get("rules", [])
    if rules:
        rule_lines = [r.get("rule", "") for r in rules if r.get("rule")]
        if rule_lines:
            parts.append(
                "[TLM — Learned preferences]\n"
                "Based on TLM's analysis of your preferences:\n"
                + "\n".join(f"  - {r}" for r in rule_lines[:5])
            )
            sys.stderr.write(
                f"{_C}{_B}[TLM]{_X} Injecting {len(rule_lines[:5])} learned rule(s)\n"
            )
            for r in rule_lines[:5]:
                sys.stderr.write(f"  {_D}-{_X} {r[:100]}\n")
            sys.stderr.write("\n")
            sys.stderr.flush()

    return "\n\n".join(parts) if parts else None


def _run_enforcement_checks(project_root: str) -> dict | None:
    """Run mechanical enforcement checks from enforcement.json.

    Returns:
        {"passed": bool, "results": [...]} or None if no enforcement config.
    """
    tlm_dir = Path(project_root) / ".tlm"
    config_file = tlm_dir / "enforcement.json"
    if not config_file.exists():
        return None

    try:
        config = json.loads(config_file.read_text())
    except (json.JSONDecodeError, OSError):
        return None

    checks = config.get("checks", [])
    if not checks:
        return None

    results = []
    all_passed = True

    for check in checks:
        name = check.get("name", "Unknown")
        command = check.get("command", "")
        blocker = check.get("blocker", False)

        if not command:
            continue

        try:
            proc = subprocess.run(
                command, shell=True, capture_output=True, text=True,
                cwd=project_root, timeout=60,
            )
            passed = proc.returncode == 0
            output = proc.stdout.strip() or proc.stderr.strip() or ""
        except (subprocess.TimeoutExpired, OSError) as e:
            passed = False
            output = str(e)

        if not passed:
            all_passed = False

        results.append({
            "name": name,
            "passed": passed,
            "blocker": blocker,
            "output": output[:500],
        })

    return {"passed": all_passed, "results": results}


def _run_session_learning(project_root: str, prompts: list[dict]):
    """Run session learning: send transcript to server. Rules stored server-side only."""
    client = _get_review_client(project_root)
    if not client:
        return

    # Build session summary dict from prompts
    prompt_texts = [p.get("prompt", "") for p in prompts if p.get("prompt")]
    session_summary = {
        "user_prompts": prompt_texts,
        "phase_flow": prompts[-1].get("phase", "idle") if prompts else "idle",
    }

    # Read knowledge for context
    knowledge = ""
    knowledge_path = Path(project_root) / ".tlm" / "knowledge.md"
    if knowledge_path.exists():
        try:
            knowledge = knowledge_path.read_text()
        except OSError:
            pass

    # Build summary string for sync_session
    config = load_project_config(project_root)
    project_id = config.get("project_id", 0)
    summary = json.dumps(session_summary)
    if knowledge:
        summary = f"[Knowledge]\n{knowledge}\n\n[Session]\n{summary}"

    # Inject gap metadata for gap_fix sessions
    state = read_state(project_root)
    if state.get("activity_type") == "gap_fix" and state.get("active_gap_id"):
        gap_id = state["active_gap_id"]
        from tlm.gaps import get_gap_by_id
        gap = get_gap_by_id(project_root, gap_id)
        if gap:
            summary = (
                f"[Gap Fix Session: {gap_id}]\n"
                f"Category: {gap.get('category', '')}\n"
                f"Description: {gap.get('description', '')}\n\n"
                f"{summary}"
            )

    try:
        client.sync_session(project_id, summary)  # fire and forget
    except Exception:
        pass  # never crash on learning failure
