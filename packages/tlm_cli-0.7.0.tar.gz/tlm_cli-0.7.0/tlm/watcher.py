"""TLM Conversation Watcher — monitors Claude Code JSONL files for learning.

Watches ~/.claude/projects/*/ for new conversation turns, buffers them,
and periodically sends batches to the TLM server for analysis.
Results are stored in knowledge.db and realtime_insights.json for injection.
"""

import json
import logging
import os
import sys
import time
from pathlib import Path

logger = logging.getLogger("tlm.watcher")

# Global TLM dir for user-scoped memories
GLOBAL_TLM_DIR = Path.home() / ".tlm"

# Minimum seconds between Gemini analyses per project
_COOLDOWN_SEC = 10
# Number of exchange pairs before triggering analysis
_EXCHANGE_THRESHOLD = 5
# Seconds of inactivity before triggering analysis (if buffer non-empty)
_TIMEOUT_SEC = 60


def _extract_turns(entries: list[dict]) -> list[dict]:
    """Parse JSONL entries into {role, text} turns. Text-only, 2000 char cap."""
    turns = []
    for entry in entries:
        entry_type = entry.get("type")
        if entry_type not in ("user", "assistant"):
            continue

        message = entry.get("message", {})
        role = message.get("role")
        if role not in ("user", "assistant"):
            continue

        content = message.get("content", [])
        if isinstance(content, str):
            text = content[:2000]
        elif isinstance(content, list):
            # Check if this is a tool_result (skip those)
            if content and isinstance(content[0], dict) and content[0].get("type") == "tool_result":
                continue

            text_parts = []
            for item in content:
                if isinstance(item, dict) and item.get("type") == "text":
                    text_parts.append(item.get("text", ""))
            text = "\n".join(text_parts)[:2000]
        else:
            continue

        if text.strip():
            turns.append({"role": role, "text": text})

    return turns


def _read_new_entries(file_path: str, offset: int) -> tuple[list[dict], int]:
    """Read new JSONL entries from file starting at byte offset.

    Returns (entries, new_offset).
    """
    try:
        file_size = os.path.getsize(file_path)
    except OSError:
        return [], offset

    if file_size <= offset:
        return [], offset

    entries = []
    try:
        with open(file_path, "r") as f:
            f.seek(offset)
            new_data = f.read()
            new_offset = f.tell()

        for line in new_data.strip().split("\n"):
            line = line.strip()
            if not line:
                continue
            try:
                entries.append(json.loads(line))
            except json.JSONDecodeError:
                continue

    except OSError:
        return [], offset

    return entries, new_offset


def _decode_project_path(encoded_name: str) -> str:
    """Convert encoded dir name back to absolute path.

    ~/.claude/projects/-home-user-myproject/ -> /home/user/myproject
    """
    # The encoding replaces / with - and prepends -
    return "/" + encoded_name.lstrip("-").replace("-", "/")


def _find_active_session(project_dir: str) -> str | None:
    """Returns the most recently modified JSONL file in the project dir."""
    p = Path(project_dir)
    jsonl_files = list(p.glob("*.jsonl"))
    if not jsonl_files:
        return None
    return str(max(jsonl_files, key=lambda f: f.stat().st_mtime))


def _should_analyze(state: dict) -> bool:
    """True if buffer has enough data and cooldown has passed."""
    buffer = state.get("buffer", [])
    if not buffer:
        return False

    last_ts = state.get("last_analysis_ts", 0)
    now = time.time()

    # Hard cooldown
    if now - last_ts < _COOLDOWN_SEC:
        return False

    # Count exchange pairs (user+assistant)
    pairs = len(buffer) // 2
    if pairs >= _EXCHANGE_THRESHOLD:
        return True

    # Timeout trigger
    if now - last_ts >= _TIMEOUT_SEC:
        return True

    return False


def _store_memories(project_root: str, memories: list[dict], client) -> None:
    """Store memories in knowledge.db (scope-aware) and update JSON cache."""
    if not memories:
        return

    tlm_dir = Path(project_root) / ".tlm"
    if not tlm_dir.exists():
        tlm_dir.mkdir(parents=True, exist_ok=True)

    # 1. Get embeddings from server
    texts = [m.get("text", "") for m in memories]
    embeddings = []
    try:
        embed_result = client.embed(texts)
        embeddings = embed_result.get("embeddings", [])
    except Exception:
        pass

    # 2. Store in project knowledge.db (all memories, with scope-aware source)
    from tlm.knowledge_db import KnowledgeDB
    project_db = KnowledgeDB(str(tlm_dir))
    project_db.init_db()

    user_memories = []
    for i, mem in enumerate(memories):
        emb = embeddings[i] if i < len(embeddings) else None
        tags = mem.get("tags", [])
        scope = mem.get("scope", "project")
        source = "watcher_learned_user" if scope == "user" else "watcher_learned_project"
        project_db.add_rule(
            text=mem.get("text", ""),
            source=source,
            tags=tags,
            embedding=emb,
        )
        if scope == "user":
            user_memories.append((mem, emb))
    project_db.close()

    # 3. Store user-scoped memories in global ~/.tlm/knowledge.db
    if user_memories:
        global_dir = GLOBAL_TLM_DIR
        global_dir.mkdir(parents=True, exist_ok=True)
        global_db = KnowledgeDB(str(global_dir))
        global_db.init_db()
        for mem, emb in user_memories:
            global_db.add_rule(
                text=mem.get("text", ""),
                source="watcher_learned_user",
                tags=mem.get("tags", []),
                embedding=emb,
            )
        global_db.close()

    # 4. Update JSON cache for immediate injection
    cache_dir = tlm_dir / "cache"
    cache_dir.mkdir(parents=True, exist_ok=True)
    insights_file = cache_dir / "realtime_insights.json"

    existing = {"corrections": [], "rules": [], "shown_corrections": []}
    if insights_file.exists():
        try:
            existing = json.loads(insights_file.read_text())
        except (json.JSONDecodeError, OSError):
            pass

    for mem in memories:
        existing["corrections"].append({
            "correction": mem.get("text", ""),
            "timestamp": time.time(),
        })

    existing["corrections"] = existing["corrections"][-30:]

    try:
        insights_file.write_text(json.dumps(existing, indent=2))
    except OSError:
        pass


def _send_to_server(client, project_id: int, session_id: str,
                    new_turns: list[dict]) -> dict:
    """Send new turns to server for analysis."""
    return client.learn_conversation(
        project_id=project_id,
        session_id=session_id,
        new_turns=new_turns,
    )


class ConversationWatcher:
    """Main watcher daemon — monitors all projects' Claude Code JSONL files."""

    def __init__(self):
        self.project_states: dict[str, dict] = {}
        self.claude_projects_dir = Path.home() / ".claude" / "projects"

    def scan_all_projects(self):
        """Iterate all project dirs under ~/.claude/projects/."""
        if not self.claude_projects_dir.exists():
            return

        for project_dir in self.claude_projects_dir.iterdir():
            if not project_dir.is_dir():
                continue
            # Skip memory/config dirs
            if project_dir.name.startswith("."):
                continue
            self._check_project(project_dir)

    def _check_project(self, project_dir: Path):
        """Find active session, read new bytes, buffer turns."""
        project_key = project_dir.name
        project_root = _decode_project_path(project_key)

        # Check if project has .tlm/ config
        tlm_config = Path(project_root) / ".tlm" / "config.json"
        if not tlm_config.exists():
            return

        # Initialize state for this project
        if project_key not in self.project_states:
            self.project_states[project_key] = {
                "buffer": [],
                "last_analysis_ts": 0,
                "file_offset": 0,
                "session_file": None,
                "project_root": project_root,
            }

        state = self.project_states[project_key]

        # Find active session file
        active_session = _find_active_session(str(project_dir))
        if not active_session:
            return

        # If session file changed, reset offset
        if active_session != state["session_file"]:
            state["session_file"] = active_session
            state["file_offset"] = 0

        # Read new entries
        entries, new_offset = _read_new_entries(active_session, state["file_offset"])
        state["file_offset"] = new_offset

        if entries:
            turns = _extract_turns(entries)
            state["buffer"].extend(turns)

        # Check if we should analyze
        if _should_analyze(state):
            self._flush_and_analyze(project_root, project_key,
                                     Path(active_session).stem)

    def _flush_and_analyze(self, project_root: str, project_key: str,
                           session_id: str):
        """Send buffered turns to server, store results, clear buffer."""
        state = self.project_states[project_key]
        buffer = state["buffer"]
        if not buffer:
            return

        from tlm.config import load_project_config, get_api_key, get_server_url
        from tlm.client import TLMClient

        config = load_project_config(project_root)
        project_id = config.get("project_id")
        if not project_id:
            return

        api_key = get_api_key()
        server_url = get_server_url()
        if not api_key:
            return

        client = TLMClient(server_url=server_url, api_key=api_key)

        try:
            result = _send_to_server(
                client,
                project_id=project_id,
                session_id=session_id,
                new_turns=buffer,
            )
            memories = result.get("memories", [])
            if memories:
                _store_memories(project_root, memories, client)
                logger.info("Stored %d memories for %s", len(memories), project_key)
        except Exception as e:
            logger.warning("Failed to analyze conversation for %s: %s",
                          project_key, e)

        # Clear buffer and update timestamp
        state["buffer"] = []
        state["last_analysis_ts"] = time.time()

    def run_forever(self, poll_interval: float = 3.0):
        """Main loop — poll for changes every N seconds."""
        logger.info("TLM Watcher started. Monitoring %s", self.claude_projects_dir)
        while True:
            try:
                self.scan_all_projects()
            except Exception as e:
                logger.error("Watcher scan error: %s", e)
            time.sleep(poll_interval)


def main():
    """Entry point for the watcher daemon."""
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
        handlers=[
            logging.StreamHandler(sys.stderr),
            logging.FileHandler(
                Path.home() / ".tlm" / "watcher.log",
                mode="a",
            ),
        ],
    )

    watcher = ConversationWatcher()
    watcher.run_forever()


if __name__ == "__main__":
    main()
