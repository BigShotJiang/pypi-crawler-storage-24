"""Gap lifecycle — detect, fix, defer, dismiss, re-detect.

Gaps are stored in .tlm/gaps.json as a list of gap dicts.
Each gap has: id, type, category, severity, description, status,
dismiss_reason, detected_at, resolved_at.
"""

import re
import json
import datetime
from enum import Enum
from pathlib import Path


class GapStatus(str, Enum):
    DETECTED = "detected"
    FIXING = "fixing"
    RESOLVED = "resolved"
    DEFERRED = "deferred"
    DISMISSED = "dismissed"


def load_gaps(project_root: str) -> list[dict]:
    """Load gaps from .tlm/gaps.json. Returns [] if missing."""
    gaps_path = Path(project_root) / ".tlm" / "gaps.json"
    if not gaps_path.exists():
        return []
    try:
        return json.loads(gaps_path.read_text())
    except (json.JSONDecodeError, OSError):
        return []


def save_gaps(project_root: str, gaps: list[dict]):
    """Save gaps to .tlm/gaps.json."""
    gaps_path = Path(project_root) / ".tlm" / "gaps.json"
    gaps_path.parent.mkdir(parents=True, exist_ok=True)
    gaps_path.write_text(json.dumps(gaps, indent=2))


def add_gap(project_root: str, gap_data: dict):
    """Add a gap. Deduplicates by ID — won't add if ID already exists."""
    gaps = load_gaps(project_root)

    # Check for existing gap with same ID
    for existing in gaps:
        if existing["id"] == gap_data["id"]:
            return  # Already exists, don't duplicate

    gap = {
        "id": gap_data["id"],
        "type": gap_data.get("type", gap_data["id"]),
        "category": gap_data.get("category", ""),
        "severity": gap_data.get("severity", "medium"),
        "description": gap_data.get("description", ""),
        "status": GapStatus.DETECTED.value,
        "dismiss_reason": None,
        "detected_at": datetime.date.today().isoformat(),
        "resolved_at": None,
    }

    gaps.append(gap)
    save_gaps(project_root, gaps)


def update_gap_status(project_root: str, gap_id: str, status: GapStatus, reason: str = None):
    """Update a gap's status. Sets resolved_at when resolving, dismiss_reason when dismissing."""
    gaps = load_gaps(project_root)

    for gap in gaps:
        if gap["id"] == gap_id:
            gap["status"] = status.value
            if status == GapStatus.RESOLVED:
                gap["resolved_at"] = datetime.date.today().isoformat()
            if status == GapStatus.DISMISSED and reason:
                gap["dismiss_reason"] = reason
            break

    save_gaps(project_root, gaps)


def get_active_gaps(project_root: str) -> list[dict]:
    """Get gaps that are not resolved or dismissed."""
    gaps = load_gaps(project_root)
    return [g for g in gaps if g["status"] not in (GapStatus.RESOLVED.value, GapStatus.DISMISSED.value)]


def get_gap_by_id(project_root: str, gap_id: str) -> dict | None:
    """Get a specific gap by ID. Returns None if not found."""
    gaps = load_gaps(project_root)
    for gap in gaps:
        if gap["id"] == gap_id:
            return gap
    return None


# --- Gap Extraction from Profile ---

# Severity keywords: category substrings -> severity level
_HIGH_KEYWORDS = ["security", "ci/cd", "cicd", "backup", "ssl", "tls", "auth"]
_MEDIUM_KEYWORDS = ["logging", "monitoring", "rate limit", "health", "performance"]

# Prerequisite gap IDs — these block feature work at high/standard quality
_PREREQUISITE_GAP_IDS = {
    "no-test-environment",
    "no-testing",
    "no-test-framework",
    "no-environment-promotion",
    "no-environments",
}

# Broader prerequisite keywords — if gap id contains these, it's prerequisite
_PREREQUISITE_KEYWORDS = [
    "test-environment", "test-framework", "testing-framework",
    "environment-promotion", "no-environments",
]


def is_prerequisite_gap(gap: dict) -> bool:
    """Check if a gap is a prerequisite that blocks feature work."""
    gap_id = gap.get("id", "")
    if gap_id in _PREREQUISITE_GAP_IDS:
        return True
    return any(kw in gap_id for kw in _PREREQUISITE_KEYWORDS)


def build_fix_brief(project_root: str, gap_id: str) -> Path:
    """Build a Claude-readable fix brief for a gap and write to .tlm/fix_brief.md.

    Returns the Path to the written file.
    """
    from tlm.config import load_project_config

    gap = get_gap_by_id(project_root, gap_id)
    config = load_project_config(project_root)
    stack = config.get("stack", "unknown")

    brief = f"""# Fix Gap: {gap_id}

## Gap Details
- **ID:** {gap_id}
- **Category:** {gap.get("category", "")}
- **Severity:** {gap.get("severity", "medium")}
- **Description:** {gap.get("description", "")}

## Project Context
- **Stack:** {stack}

## Instructions
Start in plan mode. Read the codebase to understand the project structure, then create a plan to fix the gap described above. Get the plan approved before implementing.
"""

    brief_path = Path(project_root) / ".tlm" / "fix_brief.md"
    brief_path.write_text(brief)
    return brief_path


def extract_gaps_from_profile(profile_text: str) -> list[dict]:
    """Parse the ## Gaps section from a profile markdown and return structured gap data.

    Returns list of dicts with: id, category, description, severity, dismissed.
    """
    if not profile_text:
        return []

    # Find the ## Gaps section
    match = re.search(r'^## Gaps\s*\n(.*?)(?=^## |\Z)', profile_text, re.MULTILINE | re.DOTALL)
    if not match:
        return []

    gaps_text = match.group(1).strip()
    if not gaps_text:
        return []

    gaps = []
    for line in gaps_text.split("\n"):
        line = line.strip()
        # Match "- **Category**: description"
        m = re.match(r'^-\s+\*\*(.+?)\*\*:\s*(.+)$', line)
        if not m:
            continue

        category = m.group(1).strip()
        description = m.group(2).strip()

        # Generate stable ID from category
        gap_id = "no-" + re.sub(r'[^a-z0-9]+', '-', category.lower()).strip('-')

        # Assign severity based on keywords
        cat_lower = category.lower()
        desc_lower = description.lower()
        combined = cat_lower + " " + desc_lower

        if any(kw in combined for kw in _HIGH_KEYWORDS):
            severity = "high"
        elif any(kw in combined for kw in _MEDIUM_KEYWORDS):
            severity = "medium"
        else:
            severity = "low"

        gaps.append({
            "id": gap_id,
            "category": category,
            "description": description,
            "severity": severity,
            "dismissed": False,
        })

    return gaps
