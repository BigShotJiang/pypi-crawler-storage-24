"""TLM — AI Tech Lead that enforces TDD, tests, and spec compliance in Claude Code."""

from importlib.metadata import version as _pkg_version

__version__ = _pkg_version("tlm-cli")
