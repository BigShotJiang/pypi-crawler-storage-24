from __future__ import annotations

import json
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

import cloudpickle

from refiner.worker.context import RunHandle
from refiner.pipeline.planning import PlannedStage
from refiner.worker.lifecycle import LocalRuntimeLifecycle
from refiner.worker.resources.cpu import build_cpu_sets
from refiner.worker.workdir import resolve_workdir

from refiner.launchers.base import BaseLauncher

if TYPE_CHECKING:
    from refiner.pipeline import RefinerPipeline
    from refiner.pipeline.data.shard import Shard


@dataclass(frozen=True, slots=True)
class LaunchStats:
    job_id: str
    workers: int
    claimed: int
    completed: int
    failed: int
    output_rows: int


class LocalLauncher(BaseLauncher):
    def __init__(
        self,
        *,
        pipeline: RefinerPipeline,
        name: str,
        num_workers: int = 1,
        workdir: str | None = None,
        heartbeat_interval_seconds: int = 30,
        cpus_per_worker: int | None = None,
        runtime_backend: str = "auto",
    ):
        super().__init__(
            pipeline=pipeline,
            name=name,
            num_workers=num_workers,
            heartbeat_interval_seconds=heartbeat_interval_seconds,
            cpus_per_worker=cpus_per_worker,
        )
        if runtime_backend not in {"auto", "platform", "file"}:
            raise ValueError("runtime_backend must be one of: auto, platform, file")
        self.workdir = resolve_workdir(workdir)
        self.runtime_backend = runtime_backend

    def _launcher_run_dir(self) -> Path:
        return Path(self.workdir) / "runs" / self.job_id / "launcher"

    def _stage_run_dir(self, stage_index: int) -> Path:
        return self._launcher_run_dir() / f"stage-{stage_index}"

    def _pipeline_payload_path(self, stage_index: int) -> Path:
        return self._stage_run_dir(stage_index) / "pipeline.cloudpickle"

    def _serialize_pipeline_payload(self, pipeline: RefinerPipeline) -> bytes:
        return cloudpickle.dumps(pipeline)

    def _write_pipeline_payload(
        self, *, stage_index: int, pipeline: RefinerPipeline
    ) -> Path:
        run_dir = self._stage_run_dir(stage_index)
        run_dir.mkdir(parents=True, exist_ok=True)
        payload_path = self._pipeline_payload_path(stage_index)
        payload_path.write_bytes(self._serialize_pipeline_payload(pipeline))
        return payload_path

    def _seed_file_runtime_shards(
        self, *, stage_index: int, shards: list["Shard"]
    ) -> None:
        LocalRuntimeLifecycle(
            run=RunHandle(job_id=self.job_id, stage_index=stage_index),
            workdir=self.workdir,
        ).seed_shards(shards)

    def _resolve_platform_context(
        self, *, stages: list[PlannedStage]
    ) -> RunHandle | None:
        if self.runtime_backend == "file":
            return None
        return self._create_platform_run(
            plan=self._compiled_plan(stages),
            stages=stages,
            fail_open=self.runtime_backend != "platform",
        )

    def _effective_runtime_backend(self, *, platform_run: RunHandle | None) -> str:
        if self.runtime_backend != "auto":
            return self.runtime_backend
        return "platform" if platform_run is not None else "file"

    def _log_tracking_url(self, platform_run: RunHandle | None) -> None:
        if platform_run is None or platform_run.client is None:
            self._info(
                f"Local launch running without platform integration (job_id={self.job_id})"
            )
            return
        tracking_url = self._job_tracking_url(
            client=platform_run.client,
            job_id=platform_run.job_id,
            workspace_slug=platform_run.workspace_slug,
        )
        self._info(f"Track job here: {tracking_url}")

    def _worker_command(
        self,
        *,
        stage_index: int,
        rank: int,
        payload_path: Path,
        runtime_backend: str,
        cpu_ids: list[int] | None,
        platform_run: RunHandle | None,
    ) -> list[str]:
        command = [
            # Use `uv run` so worker subprocesses import the current checkout/worktree
            # instead of an installed `refiner` package from some other environment.
            "uv",
            "run",
            "python",
            "-m",
            "refiner.worker.entrypoint",
            "--job-id",
            self.job_id,
            "--workdir",
            self.workdir,
            "--heartbeat-interval-seconds",
            str(self.heartbeat_interval_seconds),
            "--runtime-backend",
            runtime_backend,
            "--pipeline-payload",
            str(payload_path),
            "--cpu-ids",
            ",".join(str(cpu_id) for cpu_id in cpu_ids or []),
        ]
        command.extend(["--stage-index", str(stage_index)])
        if runtime_backend == "platform" and platform_run is not None:
            command.extend(
                [
                    "--worker-name",
                    f"stage-{stage_index}-rank-{rank}",
                ]
            )
        return command

    def _read_worker_stats(
        self,
        *,
        rank: int,
        process: subprocess.Popen[str],
    ) -> tuple[int, int, int, int]:
        stdout_text, stderr_text = process.communicate()
        return_code = process.returncode
        stats_line = ""
        for line in reversed(stdout_text.splitlines()):
            if line.strip():
                stats_line = line
                break
        if not stats_line:
            message = (stderr_text or "").strip() or f"exit code {return_code}"
            raise RuntimeError(f"worker {rank}: missing stats output ({message})")
        try:
            stats = json.loads(stats_line)
        except json.JSONDecodeError as err:
            raise RuntimeError(f"worker {rank}: invalid stats output ({err})") from err

        if return_code != 0 or "error" in stats:
            stats_error = str(stats.get("error") or "").strip()
            stderr_lines = [line for line in stderr_text.splitlines() if line.strip()]
            stderr_tail = "\n".join(stderr_lines[-20:])
            parts = [part for part in (stats_error, stderr_tail) if part]
            if len(parts) == 2 and parts[0] == parts[1]:
                parts.pop()
            if not parts:
                parts = [f"exit code {return_code}"]
            raise RuntimeError(f"worker {rank}: {'; '.join(parts)}")

        return (
            int(stats["claimed"]),
            int(stats["completed"]),
            int(stats["failed"]),
            int(stats["output_rows"]),
        )

    def _collect_worker_stats(
        self,
        *,
        stage_workers: int,
        processes: list[subprocess.Popen[str]],
    ) -> LaunchStats:
        claimed = 0
        completed = 0
        failed = 0
        output_rows = 0
        errors: list[str] = []

        for rank, process in enumerate(processes):
            try:
                worker_claimed, worker_completed, worker_failed, worker_output_rows = (
                    self._read_worker_stats(rank=rank, process=process)
                )
            except RuntimeError as err:
                errors.append(str(err))
                continue
            claimed += worker_claimed
            completed += worker_completed
            failed += worker_failed
            output_rows += worker_output_rows

        if errors:
            raise RuntimeError("; ".join(errors))

        return LaunchStats(
            job_id=self.job_id,
            workers=stage_workers,
            claimed=claimed,
            completed=completed,
            failed=failed,
            output_rows=output_rows,
        )

    def _launch_stage(
        self,
        *,
        stage: PlannedStage,
        runtime_backend: str,
        platform_run: RunHandle | None,
    ) -> LaunchStats:
        cpu_sets = (
            build_cpu_sets(
                num_workers=stage.compute.num_workers,
                cpus_per_worker=self.cpus_per_worker,
            )
            if self.cpus_per_worker is not None
            else [None] * stage.compute.num_workers
        )
        shards = list(stage.pipeline.list_shards())
        stage_run = self._stage_run(platform_run, stage_index=stage.index)
        if runtime_backend == "platform":
            self._seed_platform_stage(stage_run, stage_index=stage.index, shards=shards)
        else:
            self._seed_file_runtime_shards(stage_index=stage.index, shards=shards)

        payload_path = self._write_pipeline_payload(
            stage_index=stage.index,
            pipeline=stage.pipeline,
        )
        processes = [
            subprocess.Popen(
                self._worker_command(
                    stage_index=stage.index,
                    rank=rank,
                    payload_path=payload_path,
                    runtime_backend=runtime_backend,
                    cpu_ids=cpu_sets[rank],
                    platform_run=stage_run,
                ),
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
            )
            for rank in range(stage.compute.num_workers)
        ]
        return self._collect_worker_stats(
            stage_workers=stage.compute.num_workers,
            processes=processes,
        )

    def launch(self) -> LaunchStats:
        stages = self._planned_stages()
        platform_run = self._resolve_platform_context(stages=stages)
        runtime_backend = self._effective_runtime_backend(platform_run=platform_run)
        if runtime_backend == "platform" and platform_run is None:
            raise RuntimeError("runtime_backend=platform requires a platform context")

        self._log_tracking_url(platform_run)
        totals = LaunchStats(
            job_id=self.job_id,
            workers=0,
            claimed=0,
            completed=0,
            failed=0,
            output_rows=0,
        )
        try:
            for stage in stages:
                stage_stats = self._launch_stage(
                    stage=stage,
                    runtime_backend=runtime_backend,
                    platform_run=platform_run,
                )
                totals = LaunchStats(
                    job_id=self.job_id,
                    workers=totals.workers + stage_stats.workers,
                    claimed=totals.claimed + stage_stats.claimed,
                    completed=totals.completed + stage_stats.completed,
                    failed=totals.failed + stage_stats.failed,
                    output_rows=totals.output_rows + stage_stats.output_rows,
                )
                if stage_stats.failed > 0:
                    raise RuntimeError(
                        f"stage {stage.index} failed with {stage_stats.failed} failed shard(s)"
                    )
        except Exception:
            raise

        return totals


__all__ = ["LocalLauncher", "LaunchStats"]
