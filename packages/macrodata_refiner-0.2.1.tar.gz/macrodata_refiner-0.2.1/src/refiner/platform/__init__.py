"""Macrodata platform integration package."""
