"""Macrodata CLI package."""
