"""Execution operator internals."""
