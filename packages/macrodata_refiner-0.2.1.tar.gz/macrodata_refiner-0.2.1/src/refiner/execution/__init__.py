"""Execution internals."""
