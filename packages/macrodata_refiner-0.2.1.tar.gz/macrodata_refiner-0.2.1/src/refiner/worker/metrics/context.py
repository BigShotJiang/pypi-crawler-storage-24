from __future__ import annotations

from contextlib import contextmanager
from contextvars import ContextVar, Token
from collections.abc import Callable
from typing import Generator, Protocol


class UserMetricsEmitter(Protocol):
    def emit_user_counter(
        self,
        *,
        label: str,
        value: float,
        shard_id: str,
        step_index: int | None,
        unit: str | None,
    ) -> None: ...

    def emit_user_gauge(
        self,
        *,
        label: str,
        value: float,
        kind: str | None,
        step_index: int | None,
        unit: str | None,
    ) -> None: ...

    def register_user_gauge(
        self,
        *,
        label: str,
        callback: Callable[[], float | int],
        kind: str | None,
        step_index: int | None,
        unit: str | None,
    ) -> None: ...

    def emit_user_histogram(
        self,
        *,
        label: str,
        value: float,
        shard_id: str,
        per: str,
        step_index: int | None,
        unit: str | None,
    ) -> None: ...

    def force_flush_user_metrics(self) -> None: ...

    def force_flush_resource_metrics(self) -> None: ...

    def force_flush_logs(self) -> None: ...

    def shutdown(self) -> None: ...


class _NoopUserMetricsEmitter(UserMetricsEmitter):
    def emit_user_counter(
        self,
        *,
        label: str,
        value: float,
        shard_id: str,
        step_index: int | None,
        unit: str | None,
    ) -> None:
        pass

    def register_user_gauge(
        self,
        *,
        label: str,
        callback: Callable[[], float | int],
        kind: str | None,
        step_index: int | None,
        unit: str | None,
    ) -> None:
        del label, callback, kind, step_index, unit
        return None

    def emit_user_gauge(
        self,
        *,
        label: str,
        value: float,
        kind: str | None,
        step_index: int | None,
        unit: str | None,
    ) -> None:
        pass

    def emit_user_histogram(
        self,
        *,
        label: str,
        value: float,
        shard_id: str,
        per: str,
        step_index: int | None,
        unit: str | None,
    ) -> None:
        pass

    def force_flush_user_metrics(self) -> None:
        return None

    def force_flush_resource_metrics(self) -> None:
        return None

    def force_flush_logs(self) -> None:
        return None

    def shutdown(self) -> None:
        return None


NOOP_USER_METRICS_EMITTER: UserMetricsEmitter = _NoopUserMetricsEmitter()
_ACTIVE_USER_METRICS_EMITTER: ContextVar[UserMetricsEmitter] = ContextVar(
    "refiner_active_user_metrics_emitter",
    default=NOOP_USER_METRICS_EMITTER,
)


def get_active_user_metrics_emitter() -> UserMetricsEmitter:
    return _ACTIVE_USER_METRICS_EMITTER.get()


@contextmanager
def set_active_user_metrics_emitter(
    emitter: UserMetricsEmitter,
) -> Generator[None, None, None]:
    token: Token[UserMetricsEmitter] = _ACTIVE_USER_METRICS_EMITTER.set(emitter)
    try:
        yield
    finally:
        _ACTIVE_USER_METRICS_EMITTER.reset(token)


__all__ = [
    "UserMetricsEmitter",
    "NOOP_USER_METRICS_EMITTER",
    "get_active_user_metrics_emitter",
    "set_active_user_metrics_emitter",
]
