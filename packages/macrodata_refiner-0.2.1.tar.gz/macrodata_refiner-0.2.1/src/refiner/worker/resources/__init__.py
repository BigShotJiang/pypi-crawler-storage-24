"""Worker resource helpers."""
