use std::collections::HashMap;
use crate::signal::{Logic, SignalValue};
use crate::trace::Trace;
use rayon::prelude::*;

pub struct SignalStats {
    pub min: u64,
    pub max: u64,
    pub sum: u64,
    pub count: usize,
    pub num_transitions: usize,
    pub num_x: usize,
    pub num_z: usize,
}

impl SignalStats {
    pub fn mean(&self) -> f64 {
        if self.count == 0 { 0.0 } else { self.sum as f64 / self.count as f64 }
    }

    pub fn toggle_rate(&self, clock_edges: usize) -> f64 {
        if clock_edges == 0 { 0.0 }
        else { self.num_transitions as f64 / (2.0 * clock_edges as f64) }
    }
}

/// Compute stats for a single signal. Uses signal_value_by_id for O(1) access.
pub fn compute_stats(trace: &dyn Trace, name: &str) -> SignalStats {
    let mut stats = SignalStats {
        min: u64::MAX, max: 0, sum: 0, count: 0,
        num_transitions: 0, num_x: 0, num_z: 0,
    };

    let id = match trace.signal_id(name) {
        Some(id) => id,
        None => { stats.min = 0; return stats; }
    };

    let mut prev = SignalValue::Unknown;
    for idx in 0..=trace.max_index() {
        let val = trace.signal_value_by_id(id, idx);
        match &val {
            SignalValue::Scalar(v) => {
                stats.count += 1;
                stats.sum += v;
                stats.min = stats.min.min(*v);
                stats.max = stats.max.max(*v);
            }
            SignalValue::FourState(bits) => {
                for b in bits {
                    match b {
                        Logic::X => stats.num_x += 1,
                        Logic::Z => stats.num_z += 1,
                        _ => {}
                    }
                }
            }
            SignalValue::Unknown => stats.num_x += 1,
            _ => {}
        }
        if val != prev && idx > 0 {
            stats.num_transitions += 1;
        }
        prev = val;
    }
    if stats.count == 0 {
        stats.min = 0;
    }
    stats
}

/// Compute stats for all signals in parallel using rayon.
pub fn compute_all_stats(trace: &dyn Trace) -> HashMap<String, SignalStats> {
    trace.signal_names()
        .par_iter()
        .map(|name| (name.clone(), compute_stats(trace, name)))
        .collect()
}
