use crate::eval::expr::{eval_bool, Expr};
use crate::signal::SignalValue;
use crate::trace::Trace;
use rayon::prelude::*;

/// Find all timestep indices where the expression evaluates to true.
pub fn find(trace: &dyn Trace, expr: &Expr) -> Vec<usize> {
    (0..=trace.max_index())
        .filter(|&idx| eval_bool(trace, expr, idx))
        .collect()
}

/// Find all matching indices using rayon parallel iteration.
pub fn parallel_find(trace: &dyn Trace, expr: &Expr) -> Vec<usize> {
    let max = trace.max_index();
    let mut results: Vec<usize> = (0..=max)
        .into_par_iter()
        .filter(|&idx| eval_bool(trace, expr, idx))
        .collect();
    results.sort_unstable();
    results
}

/// Count matching indices in parallel.
pub fn parallel_count(trace: &dyn Trace, expr: &Expr) -> usize {
    let max = trace.max_index();
    (0..=max)
        .into_par_iter()
        .filter(|&idx| eval_bool(trace, expr, idx))
        .count()
}

/// Find all signals that changed value at a specific index.
/// Uses signal_value_by_id for O(1) access instead of name-based lookup.
pub fn changed_at(trace: &dyn Trace, index: usize) -> Vec<(String, SignalValue, SignalValue)> {
    if index == 0 {
        return Vec::new();
    }
    trace.signal_names()
        .par_iter()
        .filter_map(|name| {
            if let Some(id) = trace.signal_id(name) {
                let old = trace.signal_value_by_id(id, index - 1);
                let new = trace.signal_value_by_id(id, index);
                if old != new {
                    return Some((name.clone(), old, new));
                }
            }
            None
        })
        .collect()
}

/// Find all signals that changed at index, within a scope prefix.
/// Uses signal_value_by_id and rayon parallel iteration.
pub fn changed_at_scope(
    trace: &dyn Trace, index: usize, scope: &str,
) -> Vec<(String, SignalValue, SignalValue)> {
    if index == 0 {
        return Vec::new();
    }
    let prefix = format!("{}.", scope);
    trace.signal_names()
        .par_iter()
        .filter_map(|name| {
            if !name.starts_with(&prefix) {
                return None;
            }
            if let Some(id) = trace.signal_id(name) {
                let old = trace.signal_value_by_id(id, index - 1);
                let new = trace.signal_value_by_id(id, index);
                if old != new {
                    return Some((name.clone(), old, new));
                }
            }
            None
        })
        .collect()
}

/// Find the first index where a signal equals a target value, searching forward.
/// Uses signal_value_by_id for O(1) per-step access.
pub fn first_where_value(
    trace: &dyn Trace, name: &str, target: &SignalValue, start: usize,
) -> Option<usize> {
    let id = trace.signal_id(name)?;
    for idx in start..=trace.max_index() {
        if trace.signal_value_by_id(id, idx) == *target {
            return Some(idx);
        }
    }
    None
}

/// Find the last index where a signal equals a target value, searching backward.
/// Uses signal_value_by_id for O(1) per-step access.
pub fn last_where_value(
    trace: &dyn Trace, name: &str, target: &SignalValue, end: usize,
) -> Option<usize> {
    let id = trace.signal_id(name)?;
    for idx in (0..=end).rev() {
        if trace.signal_value_by_id(id, idx) == *target {
            return Some(idx);
        }
    }
    None
}

/// Get all transition points for a signal: (index, old_value, new_value).
/// Uses signal_value_by_id for O(1) per-step access.
pub fn transitions(trace: &dyn Trace, name: &str) -> Vec<(usize, SignalValue, SignalValue)> {
    let id = match trace.signal_id(name) {
        Some(id) => id,
        None => return Vec::new(),
    };
    let mut result = Vec::new();
    let mut prev = trace.signal_value_by_id(id, 0);
    for idx in 1..=trace.max_index() {
        let curr = trace.signal_value_by_id(id, idx);
        if curr != prev {
            result.push((idx, prev, curr.clone()));
        }
        prev = curr;
    }
    result
}

/// Find signals matching a substring (case-insensitive).
pub fn find_signals_containing(trace: &dyn Trace, substring: &str) -> Vec<String> {
    let lower = substring.to_lowercase();
    trace
        .signal_names()
        .iter()
        .filter(|name| name.to_lowercase().contains(&lower))
        .cloned()
        .collect()
}

/// Find signals matching a glob pattern (* and ?).
pub fn find_signals_glob(trace: &dyn Trace, pattern: &str) -> Vec<String> {
    let regex_str = format!(
        "^{}$",
        pattern
            .replace('.', "\\.")
            .replace('*', ".*")
            .replace('?', ".")
    );
    trace
        .signal_names()
        .iter()
        .filter(|name| {
            // Simple glob matching without regex crate
            glob_match(pattern, name)
        })
        .cloned()
        .collect()
}

fn glob_match(pattern: &str, text: &str) -> bool {
    let mut pi = 0usize;
    let mut ti = 0usize;
    let pb = pattern.as_bytes();
    let tb = text.as_bytes();
    let mut star_pi = usize::MAX;
    let mut star_ti = 0usize;

    while ti < tb.len() {
        if pi < pb.len() && (pb[pi] == b'?' || pb[pi] == tb[ti]) {
            pi += 1;
            ti += 1;
        } else if pi < pb.len() && pb[pi] == b'*' {
            star_pi = pi;
            star_ti = ti;
            pi += 1;
        } else if star_pi != usize::MAX {
            pi = star_pi + 1;
            star_ti += 1;
            ti = star_ti;
        } else {
            return false;
        }
    }
    while pi < pb.len() && pb[pi] == b'*' {
        pi += 1;
    }
    pi == pb.len()
}
