"""Shared data structures for eWAL.

Pure dataclasses — no ewal imports to avoid circular dependencies.
Every module that produces these types imports from here.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Optional, Callable
from collections import Counter
import json


# ── Snapshot ──

@dataclass
class Snapshot:
    """Immutable snapshot of all signal values at a specific index."""
    index: int
    timestamp: int
    values: dict[str, Any]
    _changes: list[tuple[str, Any, Any]] = field(default_factory=list, repr=False)

    def __getitem__(self, key: str):
        if key in self.values:
            return self.values[key]
        for full_name, val in self.values.items():
            if full_name.endswith(f".{key}"):
                return val
        raise KeyError(f"Signal '{key}' not found in snapshot")

    @property
    def signals(self) -> list[str]:
        return list(self.values.keys())

    def changed(self, scope: str = None) -> list[tuple[str, Any, Any]]:
        changes = self._changes
        if scope:
            prefix = f"{scope}."
            changes = [(s, o, n) for s, o, n in changes if s.startswith(prefix)]
        return changes

    def to_dict(self, scope: str = None) -> dict:
        if scope:
            prefix = f"{scope}."
            return {k[len(prefix):]: v for k, v in self.values.items()
                    if k.startswith(prefix)}
        return dict(self.values)

    def to_dataframe(self, signals: list[str] = None):
        import pandas as pd
        data = {s: self.values.get(s) for s in signals} if signals else self.values
        return pd.DataFrame([data], index=[self.index])


# ── Change / ExplainResult ──

@dataclass
class Change:
    signal: str
    old_value: Any
    new_value: Any
    index: int


@dataclass
class ExplainResult:
    """Result of t.explain(index)."""
    index: int
    timestamp: int
    signals_that_changed: list[Change]
    _recent: list[tuple[int, str, Any, Any]] = field(default_factory=list, repr=False)
    _upcoming: list[tuple[int, str, Any, Any]] = field(default_factory=list, repr=False)

    def recent_changes(self, n: int = 10) -> list[tuple[int, str, Any, Any]]:
        return self._recent[:n]

    def upcoming_changes(self, n: int = 5) -> list[tuple[int, str, Any, Any]]:
        return self._upcoming[:n]


# ── SearchHit ──

@dataclass
class SearchHit:
    """A matched index with lazy value access."""
    index: int
    timestamp: int
    _trace: Any = field(default=None, repr=False)

    def __getitem__(self, signal) -> Any:
        path = signal._path if hasattr(signal, '_path') else str(signal)
        return self._trace._get_signal_value(path, self.index)

    def changed(self) -> list[tuple[str, Any, Any]]:
        return self._trace._core.changed_at(self._trace._core, self.index) if self._trace else []

    @property
    def ts(self):
        return self.timestamp


# ── Timeline ──

@dataclass
class Timeline:
    """Compact representation of signal values over a time range."""
    start: int
    end: int
    signals: list[str]
    rows: list[dict[str, Any]]

    def to_dataframe(self):
        import pandas as pd
        return pd.DataFrame(self.rows)

    def to_string(self) -> str:
        if not self.rows:
            return "(empty timeline)"
        short = [s.split(".")[-1][:15] for s in self.signals]
        header = f"{'index':>6} | " + " | ".join(f"{n:>15}" for n in short)
        sep = "-" * len(header)
        lines = [header, sep]
        for row in self.rows:
            vals = " | ".join(f"{str(row.get(s, '')):>15}" for s in self.signals)
            lines.append(f"{row.get('index', ''):>6} | {vals}")
        return "\n".join(lines)

    def __str__(self):
        return self.to_string()


# ── TimeSeries ──

class TimeSeries:
    """A signal's values over time as a first-class object."""

    def __init__(self, values, timestamps, indices, name: str = ""):
        import numpy as np
        self._values = np.asarray(values, dtype=np.uint64)
        self._timestamps = np.asarray(timestamps, dtype=np.uint64)
        self._indices = np.asarray(indices, dtype=np.uint64)
        self.name = name

    @property
    def values(self):
        return self._values

    @property
    def timestamps(self):
        return self._timestamps

    @property
    def indices(self):
        return self._indices

    def __len__(self):
        return len(self._values)

    def __getitem__(self, key):
        import numpy as np
        if isinstance(key, slice):
            start = key.start or 0
            stop = key.stop or len(self._values)
            mask = (self._indices >= start) & (self._indices < stop)
            return TimeSeries(self._values[mask], self._timestamps[mask],
                              self._indices[mask], self.name)
        return self._values[key]

    def mean(self) -> float:
        return float(self._values.mean())

    def max(self) -> int:
        return int(self._values.max())

    def min(self) -> int:
        return int(self._values.min())

    def std(self) -> float:
        return float(self._values.std())

    def histogram(self, bins=16):
        import numpy as np
        return np.histogram(self._values, bins=bins)

    def transitions(self) -> list[tuple[int, int, int]]:
        import numpy as np
        changes = np.where(np.diff(self._values) != 0)[0]
        return [(int(self._indices[i + 1]), int(self._values[i]),
                 int(self._values[i + 1])) for i in changes]

    def num_transitions(self) -> int:
        import numpy as np
        return int(np.sum(np.diff(self._values) != 0))

    def toggle_rate(self) -> float:
        n = len(self._values)
        return self.num_transitions() / (n - 1) if n > 1 else 0.0

    def first_divergence(self, other: "TimeSeries") -> Optional[int]:
        import numpy as np
        min_len = min(len(self._values), len(other._values))
        diff = np.where(self._values[:min_len] != other._values[:min_len])[0]
        return int(self._indices[diff[0]]) if len(diff) > 0 else None

    def correlate(self, other: "TimeSeries", max_lag: int = 20) -> dict:
        import numpy as np
        a = self._values.astype(float)
        b = other._values.astype(float)
        n = min(len(a), len(b))
        a, b = a[:n], b[:n]
        sa, sb = a.std(), b.std()
        if sa == 0 or sb == 0:
            return {"peak_lag": 0, "peak_r": 0.0}
        a = (a - a.mean()) / sa
        b = (b - b.mean()) / sb
        best_lag, best_r = 0, 0.0
        for lag in range(-max_lag, max_lag + 1):
            if lag >= 0:
                r = float(np.mean(a[lag:] * b[:n - lag]))
            else:
                r = float(np.mean(a[:n + lag] * b[-lag:]))
            if abs(r) > abs(best_r):
                best_r, best_lag = r, lag
        return {"peak_lag": best_lag, "peak_r": best_r}

    def to_dataframe(self):
        import pandas as pd
        return pd.DataFrame({"index": self._indices, "timestamp": self._timestamps,
                              self.name: self._values})


# ── EventLog ──

@dataclass
class Event:
    index: int
    timestamp: int = 0
    label: str = ""
    data: dict[str, Any] = field(default_factory=dict)

    def __repr__(self):
        d = ", ".join(f"{k}={v}" for k, v in self.data.items())
        return f"Event({self.index}, '{self.label}'{', ' + d if d else ''})"


class EventLog:
    """Structured, chronological event log."""

    def __init__(self):
        self._events: list[Event] = []

    def add(self, index: int, label: str, data: dict = None, timestamp: int = 0):
        self._events.append(Event(index=index, timestamp=timestamp,
                                   label=label, data=data or {}))
        self._events.sort(key=lambda e: e.index)

    def add_events(self, condition_or_indices, label: str, capture: dict = None,
                   trace=None):
        if isinstance(condition_or_indices, list):
            indices = condition_or_indices
        elif trace is not None:
            indices = trace.find(condition_or_indices)
        else:
            indices = []
        for idx in indices:
            data = {}
            if capture and trace:
                old = trace._index
                trace._index = idx
                trace._virtual_cache.clear()
                for k, sig in capture.items():
                    data[k] = sig.value
                trace._index = old
            self.add(idx, label, data, trace._core.timestamp(idx) if trace else 0)

    def add_fsm_transitions(self, fsm, label_prefix="fsm"):
        for edge in fsm.transitions:
            src = getattr(edge, 'src_name', str(edge.src))
            dst = getattr(edge, 'dst_name', str(edge.dst))
            self.add(edge.first_seen, f"{label_prefix}: {src} -> {dst}",
                     {"src": edge.src, "dst": edge.dst, "count": edge.count})

    def add_transactions(self, decoder, label_prefix="txn"):
        if hasattr(decoder, 'write_transactions'):
            for txn in decoder.write_transactions():
                resp = getattr(txn, 'resp_name', str(getattr(txn, 'resp', '')))
                self.add(txn.start, f"{label_prefix}_write",
                         {"addr": txn.addr, "data": txn.data, "resp": resp})
        if hasattr(decoder, 'read_transactions'):
            for txn in decoder.read_transactions():
                self.add(txn.start, f"{label_prefix}_read",
                         {"addr": txn.addr, "data": txn.data})
        if hasattr(decoder, 'transactions'):
            for txn in decoder.transactions():
                self.add(txn.start, f"{label_prefix}", getattr(txn, 'data', {}))

    @property
    def events(self) -> list[Event]:
        return sorted(self._events, key=lambda e: e.index)

    def events_between(self, start: int, end: int) -> list[Event]:
        return [e for e in self._events if start <= e.index <= end]

    def events_of_type(self, label: str) -> list[Event]:
        return [e for e in self._events if label in e.label]

    def events_near(self, index: int, window: int = 100) -> list[Event]:
        return self.events_between(index - window, index + window)

    def narrative(self, start: int = 0, end: int = None) -> str:
        evts = self.events_between(start, end if end is not None else 10**18)
        lines = []
        for e in evts:
            d = ", ".join(f"{k}={v}" for k, v in e.data.items())
            lines.append(f"Cycle {e.index}: {e.label}" + (f" ({d})" if d else ""))
        return "\n".join(lines)

    def to_dataframe(self):
        import pandas as pd
        rows = [{"index": e.index, "timestamp": e.timestamp, "label": e.label,
                 **e.data} for e in self.events]
        return pd.DataFrame(rows)

    def to_json(self, path: str):
        data = [{"index": e.index, "timestamp": e.timestamp, "label": e.label,
                 **e.data} for e in self.events]
        with open(path, "w") as f:
            json.dump(data, f, indent=2, default=str)

    def __len__(self):
        return len(self._events)


# ── CausalChain ──

@dataclass
class Cause:
    signal: str
    diverged_at: int
    golden_value: Any = None
    failing_value: Any = None
    decoded_golden: str = ""
    decoded_failing: str = ""
    caused_by: str = ""
    reason: str = ""


@dataclass
class CausalChain:
    causes: list[Cause]

    @property
    def root_cause(self) -> Optional[Cause]:
        return self.causes[-1] if self.causes else None

    @property
    def symptom(self) -> Optional[Cause]:
        return self.causes[0] if self.causes else None

    def summary(self) -> str:
        if not self.causes:
            return "No causal chain found."
        lines = []
        for i, c in enumerate(self.causes):
            indent = "  " * i
            val = c.decoded_failing or str(c.failing_value)
            lines.append(f"{indent}{c.signal} = {val} at cycle {c.diverged_at}")
            if c.reason:
                lines.append(f"{indent}  because: {c.reason}")
        return "\n".join(lines)

    def to_json(self, path: str = None):
        data = [{"signal": c.signal, "diverged_at": c.diverged_at,
                 "golden": c.golden_value, "failing": c.failing_value,
                 "reason": c.reason} for c in self.causes]
        if path:
            with open(path, "w") as f:
                json.dump(data, f, indent=2, default=str)
        return data


# ── TransactionQuery ──

class TransactionQuery:
    """Lazy, chainable query builder for protocol transactions."""

    def __init__(self, transactions: list):
        self._txns = list(transactions)
        self._filters: list[Callable] = []

    def _apply(self) -> list:
        result = self._txns
        for f in self._filters:
            result = [t for t in result if f(t)]
        return result

    def to_addr(self, start: int, end: int = None) -> "TransactionQuery":
        q = TransactionQuery(self._txns)
        q._filters = list(self._filters)
        if end is None:
            q._filters.append(lambda t: t.addr == start)
        else:
            q._filters.append(lambda t: start <= t.addr < end)
        return q

    def with_resp(self, resp: int) -> "TransactionQuery":
        q = TransactionQuery(self._txns)
        q._filters = list(self._filters)
        q._filters.append(lambda t: t.resp == resp)
        return q

    def with_errors(self) -> "TransactionQuery":
        q = TransactionQuery(self._txns)
        q._filters = list(self._filters)
        q._filters.append(lambda t: t.resp != 0)
        return q

    def between(self, cycle_start: int = 0, cycle_end: int = 10**18) -> "TransactionQuery":
        q = TransactionQuery(self._txns)
        q._filters = list(self._filters)
        q._filters.append(lambda t: cycle_start <= t.start <= cycle_end)
        return q

    def after(self, cycle: int) -> "TransactionQuery":
        q = TransactionQuery(self._txns)
        q._filters = list(self._filters)
        q._filters.append(lambda t: t.start > cycle)
        return q

    def before(self, cycle: int) -> "TransactionQuery":
        q = TransactionQuery(self._txns)
        q._filters = list(self._filters)
        q._filters.append(lambda t: t.start < cycle)
        return q

    def first(self):
        r = self._apply()
        return r[0] if r else None

    def last(self):
        r = self._apply()
        return r[-1] if r else None

    def all(self) -> list:
        return self._apply()

    def count(self) -> int:
        return len(self._apply())

    def at_cycle(self, cycle: int):
        for t in self._txns:
            if t.start <= cycle <= t.end:
                return t
        return None

    def to_dataframe(self):
        import pandas as pd
        txns = self._apply()
        if not txns:
            return pd.DataFrame()
        rows = []
        for t in txns:
            row = {}
            for k, v in vars(t).items():
                if not k.startswith('_'):
                    row[k] = v
            rows.append(row)
        return pd.DataFrame(rows)

    def stats(self):
        txns = self._apply()
        if not txns:
            return TransactionStats()
        resp_counts = Counter(getattr(t, 'resp', 0) for t in txns)
        return TransactionStats(
            total=len(txns),
            by_resp=dict(resp_counts),
            addr_range=(min(t.addr for t in txns), max(t.addr for t in txns)),
            avg_latency=sum(t.end - t.start for t in txns) / len(txns),
        )

    def __len__(self):
        return self.count()

    def __iter__(self):
        return iter(self._apply())


@dataclass
class TransactionStats:
    total: int = 0
    by_resp: dict = field(default_factory=dict)
    addr_range: tuple = (0, 0)
    avg_latency: float = 0.0


# ── HierarchyNode ──

class HierarchyNode:
    """Node in the signal hierarchy tree."""

    def __init__(self, name: str, full_path: str = ""):
        self.name = name
        self.full_path = full_path
        self.children: dict[str, "HierarchyNode"] = {}
        self._signals: list[str] = []

    @property
    def signals(self) -> list[str]:
        return list(self._signals)

    def __getitem__(self, path: str) -> "HierarchyNode":
        parts = path.split(".", 1)
        if parts[0] in self.children:
            child = self.children[parts[0]]
            if len(parts) == 1:
                return child
            return child[parts[1]]
        raise KeyError(f"Scope '{parts[0]}' not found")

    def print(self, indent: int = 0):
        prefix = "  " * indent + ("└── " if indent > 0 else "")
        sig_count = len(self._signals)
        child_count = len(self.children)
        info = f" [{sig_count} signals]" if sig_count > 0 else ""
        print(f"{prefix}{self.name}{info}")
        for child in sorted(self.children.values(), key=lambda c: c.name):
            child.print(indent + 1)


# ── SignalInfo ──

@dataclass
class SignalInfo:
    name: str
    full_path: str
    scope: str
    width: int
    has_x: bool = False
    has_z: bool = False
    first_change: int = 0
    last_change: int = 0
    total_transitions: int = 0
