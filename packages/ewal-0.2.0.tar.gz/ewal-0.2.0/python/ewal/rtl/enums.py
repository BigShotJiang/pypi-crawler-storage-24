"""Enum type extraction from pyslang AST."""

from __future__ import annotations
from typing import Any, Optional


def extract_enum(compilation, signal_path: str) -> Optional[dict[int, str]]:
    """Get the enum mapping for a specific signal.

    Checks typedef enum first, then falls back to localparam constants
    in the same scope that share a common prefix pattern (e.g., S_RED, S_GREEN).
    """
    try:
        import pyslang
        parts = signal_path.split(".")
        # Navigate to the containing scope
        root = compilation.getRoot()
        current = None
        for inst in root.topInstances:
            current = _navigate(inst, parts[:-1])
            if current is not None:
                break
        if current is None and root.topInstances:
            current = root.topInstances[0]

        sig_name = parts[-1]
        for member in current.body:
            if hasattr(member, 'name') and member.name == sig_name:
                enum_map = _type_to_enum(member.type)
                if enum_map:
                    return enum_map

        # Fallback: collect localparam constants in the same scope
        return _collect_localparams(current)

    except (ImportError, AttributeError, IndexError, UnicodeDecodeError):
        pass
    return None


def extract_all_enums(compilation) -> dict[str, dict[int, str]]:
    """Find all enum types and localparam groups in the design."""
    enums = {}
    try:
        import pyslang
        root = compilation.getRoot()
        for inst in root.topInstances:
            _walk_enums(inst, "", enums)
    except ImportError:
        pass
    return enums


def decode_value(compilation, signal_path: str, value: int) -> Optional[str]:
    """Decode an integer value to its enum name."""
    enum = extract_enum(compilation, signal_path)
    if enum:
        return enum.get(value)
    return None


def _navigate(inst, parts):
    """Navigate through instance hierarchy to find a scope."""
    try:
        import pyslang
        if not parts:
            return inst
        if inst.name == parts[0]:
            if len(parts) == 1:
                return inst
            for member in inst.body:
                if member.kind == pyslang.ast.SymbolKind.Instance:
                    result = _navigate(member, parts[1:])
                    if result is not None:
                        return result
            return inst  # partial match
        # Try matching child instances
        for member in inst.body:
            if member.kind == pyslang.ast.SymbolKind.Instance:
                result = _navigate(member, parts)
                if result is not None:
                    return result
    except (ImportError, AttributeError, UnicodeDecodeError):
        pass
    return None


def _type_to_enum(var_type) -> Optional[dict[int, str]]:
    """Convert a pyslang type to an enum dict if it's an enum."""
    try:
        if hasattr(var_type, 'members'):
            enum_map = {}
            for em in var_type.members:
                try:
                    val = int(em.value.value)
                    enum_map[val] = em.name
                except (AttributeError, TypeError, ValueError):
                    try:
                        val = int(em.value.integer)
                        enum_map[val] = em.name
                    except (AttributeError, TypeError, ValueError):
                        pass
            return enum_map if enum_map else None
    except (AttributeError, TypeError):
        pass
    return None


def _collect_localparams(inst) -> Optional[dict[int, str]]:
    """Collect localparam constants as pseudo-enum mapping.

    Looks for Parameter symbols with integer values. Groups them
    if they share a common prefix (e.g., S_RED, S_GREEN, S_YELLOW).
    """
    try:
        import pyslang
        params = {}
        for member in inst.body:
            if member.kind == pyslang.ast.SymbolKind.Parameter:
                try:
                    # pyslang v10: member.value is ConstantValue,
                    # .value gives SVInt, int() converts
                    sv = member.value.value
                    val = int(sv)
                    params[val] = member.name
                except (AttributeError, TypeError, ValueError, UnicodeDecodeError):
                    pass

        if len(params) >= 2:
            return params
    except (ImportError, AttributeError, UnicodeDecodeError):
        pass
    return None


def _walk_enums(inst, path, enums):
    try:
        import pyslang
        module_path = f"{path}.{inst.name}" if path else inst.name

        for member in inst.body:
            if member.kind == pyslang.ast.SymbolKind.TypeAlias:
                target = member.targetType
                enum_map = _type_to_enum(target)
                if enum_map:
                    enums[member.name] = enum_map
            elif member.kind == pyslang.ast.SymbolKind.Variable:
                enum_map = _type_to_enum(member.type)
                if enum_map and hasattr(member.type, 'name'):
                    enums[member.type.name] = enum_map
            elif member.kind == pyslang.ast.SymbolKind.Instance:
                # Check for localparams in this instance
                lp = _collect_localparams(member)
                if lp:
                    enums[f"{module_path}.{member.name}"] = lp
                _walk_enums(member, module_path, enums)
    except (ImportError, AttributeError, UnicodeDecodeError):
        pass
