"""Auto-detect bus interfaces from RTL port patterns."""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Optional


@dataclass
class Interface:
    instance: str
    protocol: str
    prefix: str = ""
    port_names: set = field(default_factory=set)
    role: str = ""  # "master" or "slave"


AXI4_REQUIRED = {"awvalid", "awready", "wvalid", "wready", "bvalid", "bready"}
APB_REQUIRED = {"psel", "penable", "pready"}
WB_REQUIRED = {"cyc", "stb", "ack"}
AVALON_REQUIRED = {"read", "write", "address"}


def detect_interfaces(compilation, mapping=None) -> list[Interface]:
    """Detect all bus interfaces by port naming patterns.

    Deduplicates: if a child instance matches the same protocol as its
    parent (due to signal aliasing), only the deepest match is kept.
    """
    raw = []
    try:
        import pyslang
        root = compilation.getRoot()
        for inst in root.topInstances:
            _detect_in_instance(inst, "", raw)
    except ImportError:
        pass

    # Deduplicate: remove parents if a child matches same protocol
    interfaces = []
    for iface in raw:
        is_parent = any(
            other.instance.startswith(iface.instance + ".") and other.protocol == iface.protocol
            for other in raw if other is not iface
        )
        if not is_parent:
            interfaces.append(iface)
    return interfaces


def _detect_in_instance(inst, path, interfaces):
    try:
        import pyslang
        module_path = f"{path}.{inst.name}" if path else inst.name

        port_names = set()
        for member in inst.body:
            if member.kind in (pyslang.ast.SymbolKind.Port,
                               pyslang.ast.SymbolKind.Net,
                               pyslang.ast.SymbolKind.Variable):
                port_names.add(member.name.lower())

        for prefix in ["", "s_", "m_", "axi_", "s_axi_", "m_axi_"]:
            if {f"{prefix}{s}" for s in AXI4_REQUIRED}.issubset(port_names):
                interfaces.append(Interface(
                    instance=module_path, protocol="axi4", prefix=prefix,
                    port_names=port_names))
                break

        for prefix in ["", "apb_", "p"]:
            if {f"{prefix}{s}" for s in APB_REQUIRED}.issubset(port_names):
                interfaces.append(Interface(
                    instance=module_path, protocol="apb", prefix=prefix))
                break

        for prefix in ["", "wb_", "wbs_", "wbm_"]:
            if {f"{prefix}{s}" for s in WB_REQUIRED}.issubset(port_names):
                interfaces.append(Interface(
                    instance=module_path, protocol="wishbone", prefix=prefix))
                break

        for prefix in ["", "avm_", "avs_"]:
            if {f"{prefix}{s}" for s in AVALON_REQUIRED}.issubset(port_names):
                interfaces.append(Interface(
                    instance=module_path, protocol="avalon", prefix=prefix))
                break

        for member in inst.body:
            if member.kind == pyslang.ast.SymbolKind.Instance:
                _detect_in_instance(member, module_path, interfaces)
    except (ImportError, AttributeError, UnicodeDecodeError):
        pass


def create_protocol_decoders(interfaces: list[Interface], trace) -> dict:
    """Create bound protocol decoders for detected interfaces."""
    from ewal.protocol import axi4, apb, wishbone, avalon

    decoders = {}
    for iface in interfaces:
        scope = iface.instance
        prefix = iface.prefix
        try:
            if iface.protocol == "axi4":
                decoders[scope] = axi4.auto_bind(trace, scope=scope, prefix=prefix)
            elif iface.protocol == "apb":
                decoders[scope] = apb.auto_bind(trace, scope=scope, prefix=prefix) if hasattr(apb, 'auto_bind') else None
            elif iface.protocol == "wishbone":
                decoders[scope] = wishbone.auto_bind(trace, scope=scope, prefix=prefix) if hasattr(wishbone, 'auto_bind') else None
            elif iface.protocol == "avalon":
                decoders[scope] = avalon.auto_bind(trace, scope=scope, prefix=prefix) if hasattr(avalon, 'auto_bind') else None
        except Exception:
            pass

    return {k: v for k, v in decoders.items() if v is not None}
