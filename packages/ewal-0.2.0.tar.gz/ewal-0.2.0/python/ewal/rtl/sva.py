"""SVA property extraction and translation to eWAL assertions."""

from __future__ import annotations
import re
from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class SVAProperty:
    name: str
    module: str
    code: str = ""
    clock: str = ""
    disable: str = ""


def extract_sva(compilation) -> list[SVAProperty]:
    """Extract all SVA assertion properties from the compilation."""
    props = []
    try:
        import pyslang
        root = compilation.getRoot()
        for inst in root.topInstances:
            _walk_sva(inst, "", props)
    except ImportError:
        pass
    return props


def _walk_sva(inst, path, props):
    try:
        import pyslang
        module_path = f"{path}.{inst.name}" if path else inst.name
        for member in inst.body:
            kind_name = str(member.kind) if hasattr(member, 'kind') else ""
            if 'Assert' in kind_name or 'Assertion' in kind_name:
                name = getattr(member, 'name', f"assert_{len(props)}")
                code = str(member) if hasattr(member, '__str__') else ""
                prop = SVAProperty(name=name, module=module_path, code=code)
                props.append(prop)
            if member.kind == pyslang.ast.SymbolKind.Instance:
                _walk_sva(member, module_path, props)
    except (ImportError, AttributeError, UnicodeDecodeError):
        pass


def translate_sva(sva_props: list[SVAProperty], mapping, trace) -> list:
    """Translate SVA properties to eWAL assertion registrations.

    Parses the SVA code string to extract assertion patterns and translates
    them to eWAL assertion primitives. This handles common patterns:
        sig                  → signal reference
        !sig                 → never(sig) in assert context
        sig |-> ##[1:N] sig2 → implies(sig, eventually(sig2, within=N))
        !(sig1 && sig2)      → never(sig1 & sig2)
        $rose(sig)           → rose(sig)
        $fell(sig)           → fell(sig)
        $stable(sig)         → stable(sig)
        $past(sig, N)        → past(sig, N)
    """
    from ewal.assertions import implies, eventually, never, always, rose, fell, stable, past

    registered = []
    for prop in sva_props:
        if not hasattr(trace, 'assert_property'):
            continue

        code = prop.code

        # Try to extract clock from @(posedge clk)
        clk_ref = None
        clk_match = re.search(r'@\(\s*posedge\s+(\w+)\s*\)', code)
        if clk_match:
            clk_name = clk_match.group(1)
            clk_ref = mapping.signal(f"{prop.module}.{clk_name}") if mapping else None

        # Try to extract disable iff
        disable_ref = None
        dis_match = re.search(r'disable\s+iff\s*\(\s*(!?\s*\w+)\s*\)', code)
        if dis_match:
            dis_name = dis_match.group(1).strip().lstrip('!')
            disable_ref = mapping.signal(f"{prop.module}.{dis_name}") if mapping else None

        # Try to parse the property body
        # Pattern: sig1 |-> ##[1:N] sig2
        imply_match = re.search(r'(\w+)\s*\|->\s*##\[(\d+):(\d+)\]\s*(\w+)', code)
        if imply_match:
            ant_name = imply_match.group(1)
            max_delay = int(imply_match.group(3))
            con_name = imply_match.group(4)
            ant_ref = mapping.signal(f"{prop.module}.{ant_name}") if mapping else None
            con_ref = mapping.signal(f"{prop.module}.{con_name}") if mapping else None

            if ant_ref and con_ref:
                @trace.assert_property(f"{prop.module}.{prop.name}",
                                       clock=clk_ref, disable=disable_ref)
                def _check(a=ant_ref, c=con_ref, d=max_delay):
                    return implies(a, eventually(c, within=d))
                registered.append(prop.name)
                continue

        # Pattern: !(sig1 && sig2)
        never_match = re.search(r'!\s*\(\s*(\w+)\s*&&\s*(\w+)\s*\)', code)
        if never_match:
            s1 = never_match.group(1)
            s2 = never_match.group(2)
            r1 = mapping.signal(f"{prop.module}.{s1}") if mapping else None
            r2 = mapping.signal(f"{prop.module}.{s2}") if mapping else None
            if r1 and r2:
                @trace.assert_property(f"{prop.module}.{prop.name}",
                                       clock=clk_ref, disable=disable_ref)
                def _check(a=r1, b=r2):
                    return never(a & b)
                registered.append(prop.name)
                continue

        # Fallback: register as always-true (unrecognized pattern)
        @trace.assert_property(f"{prop.module}.{prop.name}",
                               clock=clk_ref, disable=disable_ref)
        def _check(p=prop):
            return always(True)
        registered.append(prop.name)

    return registered
