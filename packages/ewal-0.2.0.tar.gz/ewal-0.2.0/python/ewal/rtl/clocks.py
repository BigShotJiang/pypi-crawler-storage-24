"""Clock domain extraction from pyslang AST."""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Optional


@dataclass
class ClockDomain:
    name: str
    signal: Any = None  # SignalRef
    vcd_path: str = ""
    driven_signals: list[str] = field(default_factory=list)


@dataclass
class CDCCrossing:
    signal: str
    src_domain: str
    dst_domain: str


class ClockDomainMap:
    """Maps signals to their clock domains."""

    def __init__(self):
        self.domains: dict[str, ClockDomain] = {}
        self._signal_to_clock: dict[str, str] = {}

    def clock_for(self, signal_path: str) -> Optional[Any]:
        """Get the clock SignalRef for a signal."""
        # Try exact match first
        domain_name = self._signal_to_clock.get(signal_path)
        if domain_name and domain_name in self.domains:
            return self.domains[domain_name].signal

        # Try suffix match: "tb_fsm.dut.state" matches if "state" is registered
        short = signal_path.rsplit(".", 1)[-1] if "." in signal_path else signal_path
        for sig, dn in self._signal_to_clock.items():
            if sig.endswith(f".{short}") or sig == short:
                if dn in self.domains:
                    return self.domains[dn].signal

        return None

    def cdc_signals(self) -> list[CDCCrossing]:
        """Find signals that cross between clock domains."""
        crossings = []
        driven_by_domain: dict[str, set[str]] = {}
        for sig, domain in self._signal_to_clock.items():
            driven_by_domain.setdefault(domain, set()).add(sig)

        for sig, domain in self._signal_to_clock.items():
            for other_name, other_sigs in driven_by_domain.items():
                if other_name != domain and sig in other_sigs:
                    crossings.append(CDCCrossing(
                        signal=sig, src_domain=domain, dst_domain=other_name))
        return crossings


def extract_clocks(compilation, mapping) -> ClockDomainMap:
    """Extract clock domains from pyslang compilation."""
    clock_map = ClockDomainMap()

    try:
        import pyslang
        root = compilation.getRoot()
        raw_domains = {}  # clock_name -> list of (module_path, signal_name)

        for inst in root.topInstances:
            _walk_for_clocks(inst, "", raw_domains)

        for clk_name, driven in raw_domains.items():
            # The clock name is short (e.g. "clk"). Find its VCD path by
            # looking in the module that uses it.
            clk_vcd = None
            clk_sig = None
            if mapping and driven:
                # Try: module_path.clk_name
                first_mod = driven[0][0]
                candidate = f"{first_mod}.{clk_name}"
                clk_vcd = mapping.to_vcd(candidate)
                if clk_vcd:
                    clk_sig = mapping.signal(candidate)
                else:
                    # Try searching VCD signals for anything ending in .clk_name
                    for vcd_s in mapping._vcd_signals:
                        if vcd_s.endswith(f".{clk_name}"):
                            clk_vcd = vcd_s
                            from ewal.signal import SignalRef
                            clk_sig = SignalRef(mapping._trace, vcd_s)
                            break

            driven_vcd = []
            for mod, s in driven:
                vcd = mapping.to_vcd(f"{mod}.{s}") if mapping else f"{mod}.{s}"
                if vcd:
                    driven_vcd.append(vcd)

            domain = ClockDomain(
                name=clk_name,
                signal=clk_sig,
                vcd_path=clk_vcd or clk_name,
                driven_signals=driven_vcd,
            )
            clock_map.domains[clk_name] = domain
            for vcd_path in driven_vcd:
                clock_map._signal_to_clock[vcd_path] = clk_name

    except ImportError:
        pass

    return clock_map


def _walk_for_clocks(inst, path, domains):
    try:
        import pyslang
        module_path = f"{path}.{inst.name}" if path else inst.name

        for member in inst.body:
            if member.kind == pyslang.ast.SymbolKind.ProceduralBlock:
                if member.procedureKind in (
                    pyslang.ast.ProceduralBlockKind.AlwaysFF,
                    pyslang.ast.ProceduralBlockKind.Always,
                ):
                    clock = _extract_clock(member)
                    if clock:
                        if clock not in domains:
                            domains[clock] = []
                        assigned = _find_assigned(member.body)
                        for sig in assigned:
                            domains[clock].append((module_path, sig))
            elif member.kind == pyslang.ast.SymbolKind.Instance:
                _walk_for_clocks(member, module_path, domains)
    except (ImportError, AttributeError, UnicodeDecodeError):
        pass


def _extract_clock(proc_block):
    try:
        import pyslang
        body = proc_block.body
        if body.kind == pyslang.ast.StatementKind.Timed:
            timing = body.timing
            if timing.kind == pyslang.ast.TimingControlKind.SignalEvent:
                if timing.edge == pyslang.ast.EdgeKind.PosEdge:
                    return _expr_name(timing.expr)
            elif timing.kind == pyslang.ast.TimingControlKind.EventList:
                for event in timing.events:
                    if event.edge == pyslang.ast.EdgeKind.PosEdge:
                        return _expr_name(event.expr)
    except (ImportError, AttributeError, UnicodeDecodeError):
        pass
    return None


def _expr_name(expr):
    try:
        import pyslang
        if expr.kind == pyslang.ast.ExpressionKind.NamedValue:
            return expr.symbol.name
    except (ImportError, AttributeError, UnicodeDecodeError):
        pass
    return None


def _find_assigned(stmt):
    """Find all signal names assigned in a statement using visit()."""
    assigned = set()
    try:
        import pyslang
        def visitor(node):
            if hasattr(node, 'kind') and node.kind == pyslang.ast.ExpressionKind.Assignment:
                name = _expr_name(node.left)
                if name:
                    assigned.add(name)
            return None
        stmt.visit(visitor)
    except (ImportError, AttributeError, UnicodeDecodeError):
        pass
    return assigned
