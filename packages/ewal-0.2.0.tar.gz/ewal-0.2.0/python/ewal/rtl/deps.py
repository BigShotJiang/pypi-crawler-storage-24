"""Dependency graph from pyslang driver analysis."""

from __future__ import annotations
from collections import deque
from typing import Optional


class DependencyGraph:
    """Directed graph of signal dependencies."""

    def __init__(self):
        self._edges: dict[str, set[str]] = {}      # driver -> {driven}
        self._reverse: dict[str, set[str]] = {}     # driven -> {drivers}

    def add_edge(self, driver: str, driven: str):
        self._edges.setdefault(driver, set()).add(driven)
        self._reverse.setdefault(driven, set()).add(driver)

    def drivers_of(self, signal: str) -> list[str]:
        return list(self._reverse.get(signal, set()))

    def fanout_of(self, signal: str) -> list[str]:
        return list(self._edges.get(signal, set()))

    def fanin_of(self, signal: str, max_depth: int = 10) -> list[str]:
        visited = set()
        queue = [signal]
        depth = 0
        while queue and depth < max_depth:
            next_q = []
            for sig in queue:
                if sig in visited:
                    continue
                visited.add(sig)
                for d in self._reverse.get(sig, set()):
                    if d not in visited:
                        next_q.append(d)
            queue = next_q
            depth += 1
        visited.discard(signal)
        return list(visited)

    def fanout_cone(self, signal: str, max_depth: int = 10) -> list[str]:
        visited = set()
        queue = [signal]
        depth = 0
        while queue and depth < max_depth:
            next_q = []
            for sig in queue:
                if sig in visited:
                    continue
                visited.add(sig)
                for d in self._edges.get(sig, set()):
                    if d not in visited:
                        next_q.append(d)
            queue = next_q
            depth += 1
        visited.discard(signal)
        return list(visited)

    def path_between(self, source: str, target: str, max_depth: int = 20) -> list[str]:
        queue = deque([(source, [source])])
        visited = {source}
        while queue:
            current, path = queue.popleft()
            if len(path) > max_depth:
                break
            for driven in self._edges.get(current, set()):
                if driven == target:
                    return path + [driven]
                if driven not in visited:
                    visited.add(driven)
                    queue.append((driven, path + [driven]))
        return []

    def to_dot(self, center: str = None, depth: int = 3) -> str:
        lines = ["digraph deps {", "  rankdir=LR;"]
        if center:
            relevant = set(self.fanin_of(center, depth))
            relevant.update(self.fanout_cone(center, depth))
            relevant.add(center)
            for driver, driven_set in self._edges.items():
                for driven in driven_set:
                    if driver in relevant and driven in relevant:
                        sd = driver.split(".")[-1]
                        sv = driven.split(".")[-1]
                        lines.append(f'  "{sd}" -> "{sv}";')
            sc = center.split(".")[-1]
            lines.append(f'  "{sc}" [style=filled, fillcolor=red];')
        else:
            for driver, driven_set in self._edges.items():
                for driven in driven_set:
                    lines.append(f'  "{driver}" -> "{driven}";')
        lines.append("}")
        return "\n".join(lines)


def build_dependency_graph(compilation, analysis_manager, mapping) -> DependencyGraph:
    """Build dependency graph from pyslang driver analysis."""
    graph = DependencyGraph()
    try:
        import pyslang
        root = compilation.getRoot()
        for inst in root.topInstances:
            _build_deps(inst, "", compilation, analysis_manager, mapping, graph)
    except ImportError:
        pass
    return graph


def _build_deps(inst, path, comp, am, mapping, graph):
    try:
        import pyslang
        module_path = f"{path}.{inst.name}" if path else inst.name

        for member in inst.body:
            if member.kind in (pyslang.ast.SymbolKind.Variable,
                               pyslang.ast.SymbolKind.Net):
                vcd_path = mapping.to_vcd(f"{module_path}.{member.name}")
                if not vcd_path:
                    continue
                try:
                    for driver, bounds in am.getDrivers(member):
                        container = driver.containingSymbol
                        if container.kind == pyslang.ast.SymbolKind.ContinuousAssign:
                            rhs_sigs = _extract_refs(container.assignment.right)
                            for r in rhs_sigs:
                                r_vcd = mapping.to_vcd(f"{module_path}.{r}")
                                if r_vcd:
                                    graph.add_edge(r_vcd, vcd_path)
                        elif container.kind == pyslang.ast.SymbolKind.ProceduralBlock:
                            reads = _find_reads(container.body)
                            for r in reads:
                                r_vcd = mapping.to_vcd(f"{module_path}.{r}")
                                if r_vcd and r_vcd != vcd_path:
                                    graph.add_edge(r_vcd, vcd_path)
                except (RuntimeError, AttributeError):
                    pass
            elif member.kind == pyslang.ast.SymbolKind.Instance:
                _build_deps(member, module_path, comp, am, mapping, graph)
    except (ImportError, AttributeError, UnicodeDecodeError):
        pass


def _extract_refs(expr):
    refs = set()
    try:
        import pyslang
        if expr is None:
            return refs
        if expr.kind == pyslang.ast.ExpressionKind.NamedValue:
            refs.add(expr.symbol.name)
        if hasattr(expr, 'left'):
            refs.update(_extract_refs(expr.left))
            refs.update(_extract_refs(expr.right))
        if hasattr(expr, 'operand'):
            refs.update(_extract_refs(expr.operand))
    except (ImportError, AttributeError, UnicodeDecodeError):
        pass
    return refs


def _find_reads(stmt):
    """Find all signal names read in a statement using visit()."""
    reads = set()
    try:
        import pyslang

        def visitor(node):
            if hasattr(node, 'kind'):
                if node.kind == pyslang.ast.ExpressionKind.Assignment:
                    reads.update(_extract_refs(node.right))
                elif node.kind == pyslang.ast.ExpressionKind.NamedValue:
                    reads.add(node.symbol.name)
            return None

        stmt.visit(visitor)
    except (ImportError, AttributeError, UnicodeDecodeError):
        pass
    return reads
