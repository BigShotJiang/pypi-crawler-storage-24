"""DesignContext — unified interface for RTL + waveform analysis.

The single object an agent needs. Everything else is derived automatically.

Usage:
    ctx = ewal.rtl.DesignContext(rtl_paths=["rtl/"], trace_path="sim/fail.vcd")
    ctx.signal("u_pmu.power_state")
    ctx.clock_for("u_pmu.power_state")
    ctx.fsms()
    ctx.interfaces()
    ctx.why(signal="u_axi.bresp", value=3, at=8234)
"""

from __future__ import annotations
from typing import Any, Optional


class DesignContext:
    """Unified design context: pyslang compilation + eWAL trace."""

    def __init__(self, rtl_paths: list[str] = None, trace_path: str = None,
                 vcd_prefix: str = None, compilation=None, trace=None):
        import ewal

        # Load trace
        if trace is not None:
            self.trace = trace
        elif trace_path:
            self.trace = ewal.load(trace_path)
        else:
            self.trace = None

        # Compile RTL
        if compilation is not None:
            self.compilation = compilation
        elif rtl_paths:
            self.compilation = self._compile_rtl(rtl_paths)
        else:
            self.compilation = None

        # Build mapping
        from ewal.rtl.hierarchy import HierarchyMap
        self.mapping = HierarchyMap(self.compilation, self.trace,
                                     vcd_prefix=vcd_prefix or "")
        if vcd_prefix is None and self.compilation:
            self.mapping.auto_detect_prefix()

        # Extract clock domains
        from ewal.rtl.clocks import extract_clocks
        self.clocks = extract_clocks(self.compilation, self.mapping) if self.compilation else None

        # Extract enums
        from ewal.rtl.enums import extract_all_enums
        self.enums = extract_all_enums(self.compilation) if self.compilation else {}

        # Lazy: dependency graph (expensive, built on demand)
        self._deps = None
        self._am = None

    def _compile_rtl(self, paths: list[str]):
        """Compile RTL files using pyslang."""
        try:
            import pyslang
            driver = pyslang.driver.Driver()
            driver.addStandardArgs()
            for p in paths:
                driver.sourceLoader.addFiles(p)
            driver.parseAllSources()
            driver.processOptions()
            comp = driver.createCompilation()
            comp.getAllDiagnostics()
            self._am = driver.runAnalysis(comp) if hasattr(driver, 'runAnalysis') else None
            return comp
        except ImportError:
            return None

    @property
    def deps(self):
        """Dependency graph (built on first access)."""
        if self._deps is None and self.compilation:
            from ewal.rtl.deps import build_dependency_graph
            if self._am is None:
                try:
                    import pyslang
                    self._am = pyslang.analysis.AnalysisManager()
                    self._am.analyze(self.compilation)
                except (ImportError, RuntimeError):
                    pass
            if self._am:
                self._deps = build_dependency_graph(
                    self.compilation, self._am, self.mapping)
        return self._deps

    # ── Convenience accessors ──

    def signal(self, rtl_path: str):
        """Get a SignalRef for an RTL path."""
        return self.mapping.signal(rtl_path)

    def clock_for(self, signal_path: str):
        """Get the clock for a signal."""
        if self.clocks:
            vcd = self.mapping.to_vcd(signal_path) or signal_path
            return self.clocks.clock_for(vcd)
        return None

    def enum_for(self, signal_path: str) -> Optional[dict]:
        """Get enum mapping for a signal."""
        if self.compilation:
            from ewal.rtl.enums import extract_enum
            return extract_enum(self.compilation, signal_path)
        return None

    def drivers_of(self, signal_path: str) -> list[str]:
        if self.deps:
            vcd = self.mapping.to_vcd(signal_path) or signal_path
            return self.deps.drivers_of(vcd)
        return []

    def fanin_of(self, signal_path: str) -> list[str]:
        if self.deps:
            vcd = self.mapping.to_vcd(signal_path) or signal_path
            return self.deps.fanin_of(vcd)
        return []

    # ── Auto-extraction ──

    def fsms(self) -> dict:
        """Extract all FSMs with names and clocks."""
        if not self.compilation:
            return {}
        from ewal.rtl.fsm_detect import extract_all_fsms
        return extract_all_fsms(self.compilation, self.mapping, self.trace)

    def interfaces(self) -> dict:
        """Detect all bus interfaces and create decoders."""
        if not self.compilation:
            return {}
        from ewal.rtl.interfaces import detect_interfaces, create_protocol_decoders
        ifaces = detect_interfaces(self.compilation, self.mapping)
        return create_protocol_decoders(ifaces, self.trace)

    def sva_assertions(self) -> list:
        """Extract all SVA properties."""
        if not self.compilation:
            return []
        from ewal.rtl.sva import extract_sva
        return extract_sva(self.compilation)

    def cdc_crossings(self) -> list:
        """Find all CDC crossings."""
        if self.clocks:
            return self.clocks.cdc_signals()
        return []

    def pipelines(self) -> dict:
        """Detect all pipelines from RTL and create analyzers."""
        if not self.compilation:
            return {}
        from ewal.rtl.pipeline_detect import detect_pipeline, create_pipeline
        pipe_def = detect_pipeline(self.compilation)
        if pipe_def:
            pipe = create_pipeline(pipe_def, self.mapping, self.trace)
            return {pipe_def.module: pipe}
        return {}

    def power_analysis(self):
        """Toggle-based power estimation with RTL module breakdown."""
        from ewal.power import TogglePowerEstimator

        # Find a clock from RTL
        clk_ref = None
        if self.clocks and self.clocks.domains:
            first_domain = next(iter(self.clocks.domains.values()))
            clk_ref = first_domain.signal

        if clk_ref is None:
            # Fallback: find any signal named *clk*
            clk_sigs = self.trace.find_signals("clk")
            if clk_sigs:
                from ewal.signal import SignalRef
                clk_ref = SignalRef(self.trace, clk_sigs[0])

        if clk_ref is None:
            return None

        power = TogglePowerEstimator(clock=clk_ref, clock_freq_hz=100e6)
        rates = power.toggle_rates(self.trace)
        est = power.estimate(self.trace)

        # Group by module using mapping
        by_module = {}
        for sig, mw in est.per_signal.items():
            # Extract module from signal path
            parts = sig.split(".")
            if len(parts) >= 2:
                module = ".".join(parts[:-1])
            else:
                module = "top"
            by_module[module] = by_module.get(module, 0) + mw

        # Group by clock domain
        by_clock = {}
        if self.clocks:
            for sig, mw in est.per_signal.items():
                domain = self.clocks._signal_to_clock.get(sig, "unknown")
                by_clock[domain] = by_clock.get(domain, 0) + mw

        return {
            "total_mw": est.total_mw,
            "by_module": by_module,
            "by_clock_domain": by_clock,
            "top_signals": est.top_consumers(20),
            "glitches": power.find_glitches(self.trace),
        }

    def cdc_analysis(self):
        """Cross-clock domain analysis using RTL-derived clock domains."""
        from ewal.cdc import CDCAnalyzer

        if not self.clocks or len(self.clocks.domains) < 2:
            return {"crossings": [], "issues": []}

        domains = list(self.clocks.domains.values())
        crossings = self.cdc_crossings()
        results = {"crossings": [], "issues": []}

        # For each CDC crossing, verify synchronizer if possible
        for crossing in crossings:
            src_domain = self.clocks.domains.get(crossing.src_domain)
            dst_domain = self.clocks.domains.get(crossing.dst_domain)
            if src_domain and dst_domain and src_domain.signal and dst_domain.signal:
                cdc = CDCAnalyzer(clk_a=src_domain.signal, clk_b=dst_domain.signal)
                # Check for synchronizer stages
                sig_path = crossing.signal
                sync_ff1 = self.trace.find_signals(f"*sync*{sig_path.split('.')[-1]}*ff1*")
                sync_ff2 = self.trace.find_signals(f"*sync*{sig_path.split('.')[-1]}*ff2*")

                entry = {
                    "signal": crossing.signal,
                    "src_clock": crossing.src_domain,
                    "dst_clock": crossing.dst_domain,
                    "synchronizer_type": "2ff" if sync_ff1 and sync_ff2 else "unknown",
                }
                results["crossings"].append(entry)

                if not sync_ff1 and not sync_ff2:
                    results["issues"].append({
                        "signal": crossing.signal,
                        "issue": "No synchronizer detected",
                        "severity": "critical",
                    })

        return results

    def auto_annotate(self):
        """Auto-generate markers from RTL knowledge."""
        from ewal.markers import Markers

        markers = Markers()

        # Annotate FSM transitions
        for name, fsm in self.fsms().items():
            for edge in fsm.transitions:
                markers.add(edge.first_seen,
                           f"FSM {name}: {edge.src_name} -> {edge.dst_name}",
                           color="blue", signal=name)

        # Annotate protocol transactions
        for iface_name, decoder in self.interfaces().items():
            if hasattr(decoder, 'write_transactions'):
                for txn in decoder.write_transactions():
                    resp = getattr(txn, 'resp_name', str(getattr(txn, 'resp', '')))
                    color = "red" if getattr(txn, 'resp', 0) != 0 else "green"
                    markers.add(txn.start,
                               f"{iface_name} write @0x{txn.addr:x} [{resp}]",
                               color=color, signal=iface_name)

        # Annotate error signals
        error_sigs = self.trace.find_signals("error")
        for sig in error_sigs:
            from ewal.signal import SignalRef
            ref = SignalRef(self.trace, sig)
            for idx in self.trace.find(ref.rising()):
                markers.add(idx, f"ERROR: {sig}", color="red", signal=sig)

        return markers

    # ── Agent workflows ──

    def why(self, signal: str, value=None, at: int = None):
        """One-shot debug: why did signal have this value at this time?"""
        from ewal.types import CausalChain, Cause

        vcd_sig = self.mapping.to_vcd(signal) or signal
        causes = []

        # Step 1: what is the value at this cycle?
        actual_val = self.trace._get_signal_value(vcd_sig, at) if at else None

        # Step 2: what changed at/before this cycle?
        if at:
            changes = self.trace._core.changed_at(at)
            relevant = [(n, o, v) for n, o, v in changes if n == vcd_sig]
            if relevant:
                _, old, new = relevant[0]
                causes.append(Cause(
                    signal=vcd_sig, diverged_at=at,
                    golden_value=old, failing_value=new,
                ))

        # Step 3: trace backward using dependencies
        if self.deps and causes:
            current = vcd_sig
            for _ in range(10):
                drivers = self.deps.drivers_of(current)
                if not drivers:
                    break
                # Find which driver changed most recently before the effect
                target_idx = causes[-1].diverged_at
                best_driver = None
                best_idx = -1
                for d in drivers:
                    trans = self.trace._core.transitions(d)
                    for idx, old, new in reversed(trans):
                        if idx < target_idx:
                            if idx > best_idx:
                                best_idx = idx
                                best_driver = d
                            break
                if best_driver and best_idx >= 0:
                    val = self.trace._get_signal_value(best_driver, best_idx)
                    causes.append(Cause(
                        signal=best_driver, diverged_at=best_idx,
                        failing_value=val,
                        caused_by=current,
                    ))
                    current = best_driver
                else:
                    break

        chain = CausalChain(causes=causes)
        return chain

    def regression_diff(self, golden_path: str):
        """Full regression diff against a golden trace."""
        import ewal
        golden = ewal.load(golden_path, tid="golden_diff")
        d = ewal.diff(golden, self.trace)
        return d

    def coverage_report(self):
        """Generate a unified coverage report."""
        report = {}

        # FSM coverage
        fsms = self.fsms()
        report["fsm_coverage"] = {}
        for name, fsm in fsms.items():
            expected = getattr(fsm, '_expected', None)
            if expected:
                report["fsm_coverage"][name] = fsm.coverage(expected)

        # Assertion coverage
        if hasattr(self.trace, '_properties') and self.trace._properties:
            results = self.trace.check_assertions()
            report["assertion_coverage"] = results.coverage()

        return report

    def check_protocol_compliance(self) -> dict:
        """Check all interfaces for protocol compliance."""
        decoders = self.interfaces()
        results = {}
        for name, decoder in decoders.items():
            if hasattr(decoder, 'check'):
                violations = decoder.check()
                results[name] = {
                    "protocol": "axi4",
                    "violations": violations,
                    "num_transactions": (
                        len(decoder.write_transactions()) + len(decoder.read_transactions())
                        if hasattr(decoder, 'write_transactions') else 0
                    ),
                }
        return results

    def check_sva_assertions(self):
        """Extract SVA from RTL and check against waveform."""
        props = self.sva_assertions()
        if props:
            from ewal.rtl.sva import translate_sva
            translate_sva(props, self.mapping, self.trace)
        return self.trace.check_assertions()

    def snapshot(self, index: int):
        return self.trace.snapshot(index)

    def find(self, condition, **kwargs):
        return self.trace.find(condition, **kwargs)

    def diff(self, other_path: str):
        return self.regression_diff(other_path)

    # ── Query interface ──

    def query(self, query_type: str, **kwargs):
        """Structured query interface for agents."""
        if query_type == "value":
            sig = self.signal(kwargs["signal"]) or kwargs["signal"]
            at = kwargs.get("at", 0)
            val = self.trace._get_signal_value(
                sig._path if hasattr(sig, '_path') else str(sig), at)
            decoded = None
            enum = self.enum_for(kwargs["signal"])
            if enum and isinstance(val, int):
                decoded = enum.get(val)
            return {"signal": kwargs["signal"], "value": val,
                    "decoded": decoded, "index": at}

        elif query_type == "when":
            sig = self.signal(kwargs["signal"])
            if sig is not None:
                target = kwargs.get("value")
                result = sig.first_where(lambda v: v == target)
                return result

        elif query_type == "changed_at":
            return self.trace._core.changed_at(kwargs["index"])

        elif query_type == "fsm":
            fsms = self.fsms()
            module = kwargs.get("module", "")
            for name, fsm in fsms.items():
                if module in name:
                    return fsm
            return None

        elif query_type == "why":
            return self.why(**kwargs)

        return None
