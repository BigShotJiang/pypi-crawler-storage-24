"""eWAL + pyslang integration layer.

Bridges pyslang's structural RTL analysis with eWAL's behavioral waveform
analysis. Provides automatic hierarchy mapping, clock domain extraction,
enum decoding, protocol detection, FSM detection, dependency graphs,
SVA translation, and the unified DesignContext object.

pyslang is an optional dependency — import-guarded throughout.
"""

from ewal.rtl.hierarchy import HierarchyMap
from ewal.rtl.clocks import ClockDomainMap, extract_clocks
from ewal.rtl.enums import extract_enum, extract_all_enums, decode_value
from ewal.rtl.interfaces import detect_interfaces, create_protocol_decoders
from ewal.rtl.fsm_detect import detect_fsms, extract_all_fsms, FSMDefinition
from ewal.rtl.deps import DependencyGraph, build_dependency_graph
from ewal.rtl.sva import extract_sva, translate_sva
from ewal.rtl.pipeline_detect import detect_pipeline, create_pipeline, PipelineDefinition
from ewal.rtl.context import DesignContext

__all__ = [
    "HierarchyMap", "ClockDomainMap", "extract_clocks",
    "extract_enum", "extract_all_enums", "decode_value",
    "detect_interfaces", "create_protocol_decoders",
    "detect_fsms", "extract_all_fsms", "FSMDefinition",
    "DependencyGraph", "build_dependency_graph",
    "extract_sva", "translate_sva",
    "DesignContext",
]
