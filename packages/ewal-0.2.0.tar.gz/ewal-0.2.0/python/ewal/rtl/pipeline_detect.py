"""Auto-detect pipeline stages from pyslang AST.

Detects pipeline structures by finding chains of valid/pc registers
across sequential logic stages.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Optional


@dataclass
class PipelineDefinition:
    module: str = ""
    clock: str = ""
    stages: list[dict] = field(default_factory=list)
    # Each stage: {"name": str, "valid": str, "pc": str, "stall": str, "flush": str, "retire": str}


def detect_pipeline(compilation, module: str = "") -> Optional[PipelineDefinition]:
    """Detect pipeline stages from RTL by finding stage register patterns.

    Looks for signals matching patterns like:
      fetch_valid, decode_valid, execute_valid, writeback_valid
      fetch_pc, decode_pc, execute_pc, writeback_pc
      decode_stall, execute_stall
      decode_flush, execute_flush
      writeback_fire / writeback_retire
    """
    try:
        import pyslang
        root = compilation.getRoot()
        for inst in root.topInstances:
            result = _find_pipeline_in(inst, "", module)
            if result:
                return result
    except ImportError:
        pass
    return None


def _find_pipeline_in(inst, path, target_module):
    try:
        import pyslang
        module_path = f"{path}.{inst.name}" if path else inst.name

        if target_module and target_module not in module_path:
            # Recurse into children
            for member in inst.body:
                if member.kind == pyslang.ast.SymbolKind.Instance:
                    result = _find_pipeline_in(member, module_path, target_module)
                    if result:
                        return result
            return None

        # Collect all signal names in this module
        sig_names = set()
        for member in inst.body:
            if member.kind in (pyslang.ast.SymbolKind.Port,
                               pyslang.ast.SymbolKind.Net,
                               pyslang.ast.SymbolKind.Variable):
                sig_names.add(member.name)

        # Common pipeline stage name patterns
        STAGE_NAMES = [
            "fetch", "decode", "execute", "exec", "memory", "mem", "writeback", "wb",
            "if", "id", "ex", "ma", "wb",
            "stage0", "stage1", "stage2", "stage3", "stage4",
            "s0", "s1", "s2", "s3", "s4",
        ]

        detected_stages = []
        for stage_name in STAGE_NAMES:
            stage = {"name": stage_name}
            found_any = False

            for suffix, role in [("_valid", "valid"), ("_pc", "pc"),
                                  ("_stall", "stall"), ("_flush", "flush"),
                                  ("_fire", "retire"), ("_retire", "retire")]:
                candidate = f"{stage_name}{suffix}"
                if candidate in sig_names:
                    stage[role] = candidate
                    found_any = True

            if found_any and "valid" in stage:
                detected_stages.append(stage)

        if len(detected_stages) >= 2:
            # Find clock
            clock = ""
            from ewal.rtl.clocks import _extract_clock
            for member in inst.body:
                if member.kind == pyslang.ast.SymbolKind.ProceduralBlock:
                    if member.procedureKind == pyslang.ast.ProceduralBlockKind.AlwaysFF:
                        clock = _extract_clock(member) or ""
                        if clock:
                            break

            return PipelineDefinition(
                module=module_path, clock=clock, stages=detected_stages)

        # Recurse
        for member in inst.body:
            if member.kind == pyslang.ast.SymbolKind.Instance:
                result = _find_pipeline_in(member, module_path, target_module)
                if result:
                    return result
    except (ImportError, AttributeError, UnicodeDecodeError):
        pass
    return None


def create_pipeline(pipe_def: PipelineDefinition, mapping, trace):
    """Create an eWAL Pipeline object from a detected pipeline definition."""
    from ewal.pipeline import Pipeline, Stage

    stages = []
    for sdef in pipe_def.stages:
        kwargs = {"name": sdef["name"]}
        for role in ["valid", "pc", "stall", "flush", "retire"]:
            if role in sdef:
                sig = mapping.signal(f"{pipe_def.module}.{sdef[role]}")
                if sig is not None:
                    kwargs[role] = sig
        stages.append(Stage(**kwargs))

    clk_sig = mapping.signal(f"{pipe_def.module}.{pipe_def.clock}") if pipe_def.clock else None

    return Pipeline(clock=clk_sig, stages=stages)
