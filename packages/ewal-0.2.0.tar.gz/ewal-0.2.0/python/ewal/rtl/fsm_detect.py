"""Auto-detect FSMs from pyslang AST (always_ff + case statements)."""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Optional


@dataclass
class FSMDefinition:
    module: str = ""
    state_signal: str = ""
    state_type: str = ""
    enum_map: dict = field(default_factory=dict)
    clock: str = ""
    reset: str = ""
    rtl_states: set = field(default_factory=set)
    rtl_transitions: set = field(default_factory=set)

    @property
    def expected(self):
        return {"states": self.rtl_states, "transitions": self.rtl_transitions}


def detect_fsms(compilation) -> list[FSMDefinition]:
    """Find all FSM-like structures in the design."""
    fsm_defs = []
    try:
        import pyslang
        root = compilation.getRoot()
        for inst in root.topInstances:
            _walk_for_fsms(inst, "", compilation, fsm_defs)
    except ImportError:
        pass
    return fsm_defs


def extract_all_fsms(compilation, mapping, trace) -> dict:
    """Extract all FSMs from waveform using RTL-detected definitions."""
    from ewal.rtl.enums import extract_enum
    from ewal.rtl.clocks import extract_clocks

    fsm_defs = detect_fsms(compilation)
    clocks = extract_clocks(compilation, mapping)
    results = {}

    for fdef in fsm_defs:
        sig_ref = mapping.signal(f"{fdef.module}.{fdef.state_signal}")
        clk_ref = clocks.clock_for(
            mapping.to_vcd(f"{fdef.module}.{fdef.state_signal}") or "")
        if clk_ref is None:
            clk_ref = mapping.signal(f"{fdef.module}.{fdef.clock}") if fdef.clock else None

        if sig_ref is not None:
            fsm = trace.extract_fsm(
                state_signal=sig_ref,
                clock=clk_ref,
                state_names=fdef.enum_map if fdef.enum_map else None,
            )
            key = f"{fdef.module}.{fdef.state_signal}"
            fsm._expected = fdef.expected
            results[key] = fsm

    return results


def _walk_for_fsms(inst, path, comp, fsm_defs):
    try:
        import pyslang
        module_path = f"{path}.{inst.name}" if path else inst.name

        for member in inst.body:
            if member.kind == pyslang.ast.SymbolKind.ProceduralBlock:
                if member.procedureKind in (
                    pyslang.ast.ProceduralBlockKind.AlwaysFF,
                    pyslang.ast.ProceduralBlockKind.Always,
                ):
                    fsm = _check_fsm(member, module_path, comp)
                    if fsm:
                        fsm_defs.append(fsm)
            elif member.kind == pyslang.ast.SymbolKind.Instance:
                _walk_for_fsms(member, module_path, comp, fsm_defs)
    except (ImportError, AttributeError, UnicodeDecodeError):
        pass


def _check_fsm(proc_block, module_path, comp):
    try:
        import pyslang
        from ewal.rtl.clocks import _extract_clock
        from ewal.rtl.enums import extract_enum

        clock = _extract_clock(proc_block)
        if not clock:
            return None

        body = proc_block.body
        if body.kind == pyslang.ast.StatementKind.Timed:
            body = body.stmt

        case_stmt = _find_case(body)
        if not case_stmt:
            return None

        state_name = _expr_name(case_stmt.expr)
        if not state_name:
            return None

        # Verify this is an FSM: state variable is assigned in case branches
        from ewal.rtl.clocks import _find_assigned
        for item in case_stmt.items:
            assigned = _find_assigned(item.stmt)
            if state_name in assigned:
                fsm = FSMDefinition()
                fsm.module = module_path
                fsm.state_signal = state_name
                fsm.clock = clock

                enum = extract_enum(comp, f"{module_path}.{state_name}")
                if enum:
                    fsm.enum_map = enum
                    fsm.state_type = "enum"
                else:
                    fsm.state_type = "integer"

                return fsm
    except (ImportError, AttributeError, UnicodeDecodeError):
        pass
    return None


def _find_case(stmt):
    """Find a case statement using pyslang's visit() walker."""
    try:
        import pyslang
        found = [None]
        def visitor(node):
            if found[0] is not None:
                return pyslang.ast.VisitAction.Interrupt
            if hasattr(node, 'kind') and node.kind == pyslang.ast.StatementKind.Case:
                found[0] = node
                return pyslang.ast.VisitAction.Interrupt
            return None
        stmt.visit(visitor)
        return found[0]
    except (ImportError, AttributeError, UnicodeDecodeError):
        pass
    return None


def _expr_name(expr):
    try:
        import pyslang
        if expr.kind == pyslang.ast.ExpressionKind.NamedValue:
            return expr.symbol.name
    except (ImportError, AttributeError, UnicodeDecodeError):
        pass
    return None
