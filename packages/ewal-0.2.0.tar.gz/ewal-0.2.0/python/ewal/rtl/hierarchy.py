"""Hierarchy mapping: RTL paths <-> VCD paths."""

from __future__ import annotations
from typing import Any, Optional


class HierarchyMap:
    """Maps between pyslang RTL paths and eWAL VCD paths."""

    def __init__(self, compilation=None, trace=None, vcd_prefix: str = ""):
        self._comp = compilation
        self._trace = trace
        self._prefix = vcd_prefix
        self._rtl_signals: list[str] = []
        self._vcd_signals: set[str] = set()

        if trace:
            self._vcd_signals = set(trace._core.signal_names())

        if compilation:
            self._extract_rtl_signals()

    def _extract_rtl_signals(self):
        """Walk pyslang compilation to get all signal paths."""
        try:
            import pyslang
            root = self._comp.getRoot()
            for inst in root.topInstances:
                self._walk_signals(inst, "")
        except (ImportError, AttributeError, UnicodeDecodeError):
            pass

    def _walk_signals(self, inst, path):
        try:
            import pyslang
            module_path = f"{path}.{inst.name}" if path else inst.name
            for member in inst.body:
                if member.kind in (pyslang.ast.SymbolKind.Port,
                                   pyslang.ast.SymbolKind.Net,
                                   pyslang.ast.SymbolKind.Variable):
                    self._rtl_signals.append(f"{module_path}.{member.name}")
                elif member.kind == pyslang.ast.SymbolKind.Instance:
                    self._walk_signals(member, module_path)
        except (ImportError, AttributeError, UnicodeDecodeError):
            pass

    def auto_detect_prefix(self) -> str:
        """Auto-detect the VCD prefix by matching signal names."""
        if not self._rtl_signals or not self._vcd_signals:
            return ""
        # Try common prefixes
        candidates = ["", "tb.", "tb.dut.", "tb.soc.", "tb.top."]
        # Also try first scope from VCD
        scopes = self._trace._core.scopes() if self._trace else []
        for s in scopes:
            candidates.append(f"{s}.")

        best_prefix = ""
        best_count = 0
        for prefix in candidates:
            count = sum(1 for s in self._rtl_signals
                        if f"{prefix}{s}" in self._vcd_signals)
            if count > best_count:
                best_count = count
                best_prefix = prefix

        self._prefix = best_prefix
        return best_prefix

    def to_vcd(self, rtl_path: str) -> Optional[str]:
        """Map an RTL path to a VCD path."""
        vcd = f"{self._prefix}{rtl_path}"
        if vcd in self._vcd_signals:
            return vcd
        return None

    def to_rtl(self, vcd_path: str) -> Optional[str]:
        """Map a VCD path to an RTL path."""
        if vcd_path.startswith(self._prefix):
            return vcd_path[len(self._prefix):]
        return None

    def vcd_signals(self, rtl_module: str) -> list[str]:
        """Get all VCD signals for an RTL module."""
        prefix = f"{self._prefix}{rtl_module}."
        return [s for s in self._vcd_signals if s.startswith(prefix)]

    def observable_signals(self, rtl_module: str) -> list[str]:
        """Signals in both RTL and VCD."""
        return [s for s in self._rtl_signals
                if s.startswith(f"{rtl_module}.") and self.to_vcd(s)]

    def unobservable_signals(self, rtl_module: str) -> list[str]:
        """Signals in RTL but not in VCD."""
        return [s for s in self._rtl_signals
                if s.startswith(f"{rtl_module}.") and not self.to_vcd(s)]

    def signal(self, rtl_path: str):
        """Get a SignalRef for an RTL path.

        Tries exact prefix match first, then suffix match against all
        known RTL signals (so "dut.state" matches "tb_fsm.dut.state").
        """
        from ewal.signal import SignalRef
        # Exact match
        vcd = self.to_vcd(rtl_path)
        if vcd and self._trace:
            return SignalRef(self._trace, vcd)

        # Suffix match: find RTL signal ending with rtl_path
        suffix = f".{rtl_path}"
        for s in self._rtl_signals:
            if s.endswith(suffix) or s == rtl_path:
                vcd = self.to_vcd(s)
                if vcd and self._trace:
                    return SignalRef(self._trace, vcd)

        # Direct VCD check (user may pass full VCD path)
        if rtl_path in self._vcd_signals and self._trace:
            return SignalRef(self._trace, rtl_path)

        return None

    def signals(self, rtl_module: str) -> dict:
        """Get all SignalRefs for an RTL module."""
        from ewal.signal import SignalRef
        result = {}
        for vcd_path in self.vcd_signals(rtl_module):
            short = vcd_path.split(".")[-1]
            result[short] = SignalRef(self._trace, vcd_path)
        return result

    def report(self) -> str:
        """Report mapping status."""
        matched = len([s for s in self._rtl_signals if self.to_vcd(s)])
        lines = [
            f"Hierarchy mapping: vcd_prefix='{self._prefix}'",
            f"  RTL signals: {len(self._rtl_signals)}",
            f"  VCD signals: {len(self._vcd_signals)}",
            f"  Observable:  {matched}",
            f"  RTL-only:    {len(self._rtl_signals) - matched}",
            f"  VCD-only:    {len(self._vcd_signals) - matched}",
        ]
        return "\n".join(lines)
