"""eWAL error types for agent-native diagnostics."""


class EwalError(Exception):
    """Base exception for eWAL."""
    pass


class SignalNotFoundError(EwalError):
    """Raised when a signal path doesn't exist in the trace."""

    def __init__(self, path: str, suggestions: list[str] = None):
        self.path = path
        self.suggestions = suggestions or []
        parts = [f"Signal '{path}' not found in trace."]
        if self.suggestions:
            parts.append("Did you mean:")
            for s in self.suggestions[:5]:
                parts.append(f"  {s}")
        super().__init__("\n".join(parts))


class IndexOutOfRangeError(EwalError):
    """Raised when an index is beyond the trace bounds."""

    def __init__(self, index: int, max_index: int):
        self.index = index
        self.max_index = max_index
        super().__init__(f"Index {index} out of range [0, {max_index}].")


class Config:
    """Global eWAL configuration."""
    strict_signals: bool = False


config = Config()
