from edm98 import __version__


def test_version_exists() -> None:
    assert __version__
