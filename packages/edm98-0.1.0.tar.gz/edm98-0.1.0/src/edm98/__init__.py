"""EDM-98 dataset and inference package."""

__all__ = ["__version__"]

__version__ = "0.1.0"
