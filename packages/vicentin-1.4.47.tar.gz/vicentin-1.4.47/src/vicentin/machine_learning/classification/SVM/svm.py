from typing import Any, Optional

from vicentin.kernels import Kernel, LinearKernel
from vicentin.utils import Dispatcher

disp_svm = Dispatcher()
disp_predict = Dispatcher()
disp_l2_svm = Dispatcher()

try:
    from .svm_np import SVM as SVM_np, predict as predict_np
    from .l2_svm_np import L2_SVM as L2_SVM_np

    disp_svm.register("numpy", SVM_np)
    disp_predict.register("numpy", predict_np)
    disp_l2_svm.register("numpy", L2_SVM_np)
except ModuleNotFoundError:
    pass

try:
    from .svm_torch import SVM as SVM_torch, predict as predict_torch
    from .l2_svm_torch import L2_SVM as L2_SVM_torch

    disp_svm.register("torch", SVM_torch)
    disp_predict.register("torch", predict_torch)
    disp_l2_svm.register("torch", L2_SVM_torch)
except ModuleNotFoundError:
    pass


class SVMClassifier:
    def __init__(
        self,
        kernel: Optional[Kernel] = None,
        loss: str = "hinge",
        C: float = 1,
        lambda_: Optional[float] = None,
        strategy: str = "ovo",
        smo_threshold: int = 10_000,
        backend: Optional[str] = None,
        **kwargs,
    ):
        if kernel is None:
            kernel = LinearKernel()
        self.kernel = kernel

        self.loss = loss
        self.lambda_ = lambda_
        self.C = C
        self.strategy = strategy
        self.smo_threshold = smo_threshold

        self._model_data = None
        self._kwargs = kwargs
        self._backend = backend

        if self.C is None and self.lambda_ == 0:
            self.C = float("inf")

    def fit(self, X: Any, y: Any):
        """Fits the SVM model according to the given training data."""

        if self.loss == "hinge":
            disp = disp_svm
        elif self.loss == "squared_hinge":
            disp = disp_l2_svm
        else:
            raise ValueError("loss must be 'hinge' or 'squared_hinge'")

        disp.detect_backend(X, self._backend)
        X, y = disp.cast_values(X, y)

        self.kernel.set_X(X)

        self._model_data = disp(
            self.kernel,
            y,
            self.lambda_,
            self.C,
            self.strategy,
            self.smo_threshold,
            **self._kwargs,
        )

        return self

    def predict(self, X: Any) -> Any:
        """Evaluates the decision function on X."""
        if self._model_data is None or self.kernel is None:
            raise RuntimeError("Model is not fitted yet.")

        disp_predict.detect_backend(X, self._backend)
        X = disp_predict.cast_values(X)

        return disp_predict(self._model_data, self.kernel, X)
