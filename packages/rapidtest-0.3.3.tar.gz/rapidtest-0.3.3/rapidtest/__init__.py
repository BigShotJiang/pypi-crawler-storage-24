"""
RapidTest: A library for simplifying REST API testing.
"""

from .RapidTest import Test as Test
from .RapidData import data as data
from .Performance import Performance as Performance
from .types import StatusCode as StatusCode
from .Utils import StatusCode as StatusCode


