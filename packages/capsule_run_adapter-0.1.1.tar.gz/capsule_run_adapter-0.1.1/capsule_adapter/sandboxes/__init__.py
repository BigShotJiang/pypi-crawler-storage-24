"""WebAssembly sandbox binaries."""
