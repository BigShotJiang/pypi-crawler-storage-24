#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
═══════════════════════════════════════════════════════════════════════════════
 ARGUS — Configuration centralisée
 Constantes partagées par les moteurs et scripts de validation
═══════════════════════════════════════════════════════════════════════════════
"""

from pathlib import Path

# ═══════════════════════════════════════════════════════════════════════════════
#  PATHS
# ═══════════════════════════════════════════════════════════════════════════════

PROJECT_ROOT = Path(__file__).resolve().parent.parent
MEMORY_DIR = PROJECT_ROOT / "memory"

# ═══════════════════════════════════════════════════════════════════════════════
#  DECAY ENGINE
#  Règles d'oubli contrôlé (persona: memory.operations.forgetting)
#  Un pattern non renforcé perd progressivement en confidence
# ═══════════════════════════════════════════════════════════════════════════════

# Confidence perdue par mois sans renforcement (cas standard)
# À ce rythme, un pattern atteint le seuil de suppression en ~6 mois d'inactivité
DECAY_RATE = 0.05

# Decay ralenti pour les patterns avec des occurrences réelles
# (observés dans des incidents ou analyses, pas seulement théoriques)
DECAY_RATE_REINFORCED = 0.02

# En-dessous de ce seuil, le pattern est signalé pour review/suppression
DECAY_THRESHOLD = 0.20

# Période de grâce après la dernière observation (aucun decay pendant ce délai)
DECAY_GRACE_DAYS = 60

# Catégories immunes au decay (la sécurité ne s'oublie jamais)
PROTECTED_CATEGORIES = {"security", "critical"}

# ═══════════════════════════════════════════════════════════════════════════════
#  CONSOLIDATION ENGINE
#  Renforcement de la mémoire sémantique depuis les épisodes
#  (persona: memory.operations.consolidation)
# ═══════════════════════════════════════════════════════════════════════════════

# Boost de confidence par type d'épisode source
# Un incident réel poids plus qu'une simple mention dans une analyse
CONFIDENCE_BOOST = {
    "incident_match": 0.03,
    "analysis_finding": 0.02,
    "heuristic_applied": 0.01,
}

# ═══════════════════════════════════════════════════════════════════════════════
#  REFLECTION ENGINE
#  Seuils d'auto-diagnostic de la santé mémoire
#  (persona: memory.operations.reflection)
# ═══════════════════════════════════════════════════════════════════════════════

# Un pattern en-dessous de ce seuil de confidence déclenche un warning
LOW_CONFIDENCE = 0.40

# Nombre d'épisodes non consolidés avant déclenchement d'un warning
# (indique que la consolidation n'a pas été lancée depuis trop longtemps)
CONSOLIDATION_LAG_THRESHOLD = 5

# ═══════════════════════════════════════════════════════════════════════════════
#  RISK SCORING
# ═══════════════════════════════════════════════════════════════════════════════

VALID_MULTIPLIER_SOURCES = {"data_integrity", "security", "performance", "regression", "api"}
CRITICAL_THRESHOLD = 15.0
HIGH_THRESHOLD = 8.0
SCORE_TOLERANCE = 0.01
