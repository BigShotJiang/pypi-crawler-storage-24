#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
═══════════════════════════════════════════════════════════════════════════════
 ARGUS MCP — Data Directory Resolution
 Résout et initialise le répertoire de données Argus
═══════════════════════════════════════════════════════════════════════════════

 Priorité de résolution :
   1. Variable d'environnement ARGUS_DATA_DIR (tests, setups custom)
   2. ./memory/ dans le CWD (mode dev / clone git)
   3. ~/.argus/memory/ (données utilisateur, initialisé au premier lancement)
"""

import os
import shutil
from importlib import resources
from pathlib import Path


def get_data_dir() -> Path:
    """Résout le répertoire de données Argus.

    Returns:
        Chemin vers le dossier memory/ contenant les données Argus.
    """
    # 1. Variable d'environnement (priorité absolue)
    if env := os.environ.get("ARGUS_DATA_DIR"):
        return Path(env)

    # 2. Répertoire local ./memory/ (mode dev / clone)
    local = Path.cwd() / "memory"
    if local.is_dir() and (local / "_index.yaml").is_file():
        return local

    # 3. Répertoire utilisateur ~/.argus/memory/
    user_dir = Path.home() / ".argus" / "memory"
    if not user_dir.is_dir():
        _initialize_user_data(user_dir)
    return user_dir


def get_project_root() -> Path:
    """Résout la racine du projet Argus (parent du dossier memory/)."""
    return get_data_dir().parent


def _initialize_user_data(target: Path) -> None:
    """Initialise ~/.argus/ avec les données par défaut du package.

    Crée la structure complète des répertoires et copie les fichiers
    sémantiques de base (patterns, heuristiques, profils de contexte).
    """
    argus_home = target.parent  # ~/.argus/

    # Créer la structure de répertoires
    dirs = [
        target / "semantic",
        target / "episodic" / "analyses",
        target / "episodic" / "decisions",
        target / "episodic" / "incidents",
        target / "episodic" / "executions",
        target / "projects",
        target / "relational",
        target / "working",
        target / "deliverables",
    ]
    for d in dirs:
        d.mkdir(parents=True, exist_ok=True)

    # Copier les fichiers sémantiques par défaut depuis le package
    _copy_package_defaults(target)

    # Générer un _index.yaml par défaut
    _create_default_index(target)

    # Générer une persona par défaut
    _create_default_persona(argus_home)


def _copy_package_defaults(target: Path) -> None:
    """Copie les fichiers par défaut embarqués dans le package."""
    defaults_pkg = resources.files("mcp_server.defaults")

    # Copier les fichiers sémantiques
    semantic_src = defaults_pkg / "semantic"
    semantic_dst = target / "semantic"
    _copy_resource_dir(semantic_src, semantic_dst)

    # Copier les templates de deliverables
    deliverables_src = defaults_pkg / "deliverables"
    deliverables_dst = target / "deliverables"
    _copy_resource_dir(deliverables_src, deliverables_dst)


def _copy_resource_dir(src, dst: Path) -> None:
    """Copie récursivement les fichiers d'une ressource de package vers un dossier."""
    dst.mkdir(parents=True, exist_ok=True)
    try:
        for item in src.iterdir():
            item_name = item.name
            if item_name.startswith("__"):  # skip __init__.py, __pycache__
                continue
            dest_file = dst / item_name
            if not dest_file.exists():
                content = item.read_text(encoding="utf-8")
                dest_file.write_text(content, encoding="utf-8")
    except (TypeError, AttributeError, FileNotFoundError):
        # Ressources non disponibles (ex: import depuis source sans package)
        pass


def _create_default_index(target: Path) -> None:
    """Crée un _index.yaml par défaut."""
    index_path = target / "_index.yaml"
    if index_path.exists():
        return

    # Compter les patterns et heuristiques copiés
    index_content = """\
version: 1.0.0
last_updated: '2026-01-01'
episodic:
  analyses:
    count: 0
    latest: null
    path: memory/episodic/analyses/
  decisions:
    count: 0
    latest: null
    path: memory/episodic/decisions/
  incidents:
    count: 0
    latest: null
    path: memory/episodic/incidents/
  executions:
    count: 0
    latest: null
    path: memory/episodic/executions/
semantic:
  defect_patterns:
    count: 46
    categories: 12
    path: memory/semantic/defect_patterns.yaml
  testing_heuristics:
    count: 62
    categories: 17
    path: memory/semantic/testing_heuristics.yaml
  technology_knowledge:
    path: memory/semantic/technology_knowledge.yaml
  istqb_knowledge:
    path: memory/semantic/istqb_knowledge.yaml
  context_profiles:
    count: 8
    path: memory/semantic/context_profiles.yaml
projects:
  count: 0
  path: memory/projects/
relational:
  path: memory/relational/associations.yaml
deliverables:
  templates:
  - test_plan
  - traceability_matrix
  - exploratory_charter
statistics:
  totals:
    episodes: 0
    patterns: 46
    heuristics: 62
    projects: 0
sequences:
  analysis: 0
  decision: 0
  incident: 0
  execution: 0
  pattern: 46
  heuristic: 62
"""
    index_path.write_text(index_content, encoding="utf-8")


def _create_default_persona(argus_home: Path) -> None:
    """Crée un fichier persona par défaut."""
    persona_path = argus_home / "argus.persona.yaml"
    if persona_path.exists():
        return

    persona_content = """\
# Argus QA Orchestrator — User Persona
# Customize this file to adapt Argus to your context
version: '0.10.0'
last_updated: '2026-01-01'
evolution_cycle: 0
identity:
  name: Argus
  role: QA Orchestrator
  tagline: "Celui aux cent yeux qui voit ce que d'autres ne voient pas"
"""
    persona_path.write_text(persona_content, encoding="utf-8")
