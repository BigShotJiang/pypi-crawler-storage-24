# Argus MCP Server — Default data (factory knowledge base)
