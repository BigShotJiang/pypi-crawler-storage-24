#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Entry point pour lancer le serveur MCP Argus : python -m mcp_server"""

from .server import main

main()
