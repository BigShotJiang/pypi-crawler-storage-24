import asyncio
import pytest
import json
import tempfile
import os
from adaptive_harmony import StringThread
from adaptive_harmony.parameters import Dataset, dataset_kinds
from adaptive_harmony.runtime.context import RecipeContext
from unittest.mock import AsyncMock, Mock


@pytest.fixture
def mock_ctx():
    """Create a mock RecipeContext for testing."""
    ctx = Mock(spec=RecipeContext)
    ctx.file_storage = Mock()
    ctx.file_storage.mk_url = Mock(return_value="file://test_file.jsonl")
    ctx.control_plane = None  # Use local file path branch in Dataset.load()

    ctx.client = Mock()
    return ctx


def create_temp_dataset_file(data, mock_ctx):
    """Helper function to create a temporary dataset file and configure the mock."""
    if isinstance(data, list):
        content = "\n".join(json.dumps(item) for item in data) + "\n"
    else:
        content = json.dumps(data) + "\n"

    with tempfile.NamedTemporaryFile(mode="w", delete=False, suffix=".jsonl") as f:
        f.write(content)
        temp_file = f.name

    # Configure mock to return file content
    mock_ctx.file_storage.read.return_value = content.encode("utf-8")

    return temp_file


class TestAdaptiveDatasetLoadDataset:

    def test_load_dataset_prompt_format(self, mock_ctx):
        prompt_data = {
            "prompt": [
                ["user", "What is the capital of France?"],
                ["assistant", "The capital of France is Paris."],
            ],
            "metadata": {
                "id": "b2761a88-0662-453b-aba7-27846434dc55",
                "created_at": 1234567890,
                "external_data": {"source": "test"}
            },
        }

        temp_file = create_temp_dataset_file(prompt_data, mock_ctx)
        try:
            dataset = Dataset[dataset_kinds.Prompt](dataset_key="test_prompt", local_file_path=temp_file)
            threads = asyncio.run(dataset.load(mock_ctx))

            assert len(threads) == 1
            assert isinstance(threads[0], StringThread)
            # System fields (id, created_at) are not in thread.metadata
            # Only external_data fields are present
            assert threads[0].metadata["source"] == "test"
        finally:
            os.unlink(temp_file)

    def test_load_dataset_completion_format_as_prompt(self, mock_ctx):
        """Loading completion-format data as Prompt should drop the completion."""
        completion_data = {
            "prompt": [["user", "Write a haiku about coding."]],
            "completion": ["assistant", "Code flows like water,\nBugs hide in silent corners,\nDebug light reveals."],
            "metadata": {
                "id": "b2761a88-0662-453b-aba7-27846434dc56",
                "created_at": 1234567890,
                "external_data": {"category": "poetry"}
            },
        }

        temp_file = create_temp_dataset_file(completion_data, mock_ctx)
        try:
            dataset = Dataset[dataset_kinds.Prompt](dataset_key="test_completion", local_file_path=temp_file)
            threads = asyncio.run(dataset.load(mock_ctx))

            assert len(threads) == 1
            assert isinstance(threads[0], StringThread)
            assert threads[0].metadata["category"] == "poetry"
            # Completion should be dropped for Prompt kind
            assert "Write a haiku" in threads[0].last_content()
            assert "Code flows like water" not in threads[0].last_content()
        finally:
            os.unlink(temp_file)

    def test_load_dataset_completion_format_as_completion(self, mock_ctx):
        """Loading completion-format data as Completion should keep the completion."""
        completion_data = {
            "prompt": [["user", "Write a haiku about coding."]],
            "completion": ["assistant", "Code flows like water,\nBugs hide in silent corners,\nDebug light reveals."],
            "metadata": {
                "id": "b2761a88-0662-453b-aba7-27846434dc56",
                "created_at": 1234567890,
                "external_data": {"category": "poetry"}
            },
        }

        temp_file = create_temp_dataset_file(completion_data, mock_ctx)
        try:
            dataset = Dataset[dataset_kinds.Completion](dataset_key="test_completion", local_file_path=temp_file)
            threads = asyncio.run(dataset.load(mock_ctx))

            assert len(threads) == 1
            assert isinstance(threads[0], StringThread)
            assert threads[0].metadata["category"] == "poetry"
            assert "Code flows like water" in threads[0].last_content()
        finally:
            os.unlink(temp_file)

    def test_load_dataset_metric_format(self, mock_ctx):
        metric_data = {
            "prompt": [["user", "Rate this response quality."]],
            "completion": ["assistant", "This is a high-quality response."],
            "metrics": {"quality_score": 0.95, "helpfulness": 0.88},
            "metadata": {
                "id": "b2761a88-0662-453b-aba7-27846434dc57",
                "created_at": 1234567890,
                "external_data": {"annotator": "expert_1"},
            },
        }

        temp_file = create_temp_dataset_file(metric_data, mock_ctx)
        try:
            dataset = Dataset[dataset_kinds.Metric](
                dataset_key="test_metric", local_file_path=temp_file, feedback_key="quality_score"
            )
            threads = asyncio.run(dataset.load(mock_ctx))

            assert len(threads) == 1
            assert isinstance(threads[0], StringThread)
            assert threads[0].metadata["annotator"] == "expert_1"
            assert threads[0].metadata["res"] == 0.95
        finally:
            os.unlink(temp_file)

    def test_load_dataset_preference_format(self, mock_ctx):
        preference_data = {
            "prompt": [["user", "Explain quantum computing."]],
            "good_completion": ["assistant", "Quantum computing uses quantum mechanical phenomena..."],
            "bad_completion": ["assistant", "I don't know."],
            "metadata": {
                "id": "b2761a88-0662-453b-aba7-27846434dc58",
                "created_at": 1234567890,
                "external_data": {"preference_strength": "strong"},
            },
        }

        temp_file = create_temp_dataset_file(preference_data, mock_ctx)
        try:
            dataset = Dataset[dataset_kinds.Preference](dataset_key="test_preference", local_file_path=temp_file)
            threads = asyncio.run(dataset.load(mock_ctx))

            assert len(threads) == 1
            assert isinstance(threads[0], StringThread)
            assert threads[0].metadata["preference_strength"] == "strong"
            assert "Quantum computing uses" in threads[0].metadata["preferred_completion"]
            assert "I don't know" in threads[0].metadata["other_completion"]
        finally:
            os.unlink(temp_file)

    def test_load_dataset_external_format_as_prompt(self, mock_ctx):
        """Loading external format as Prompt should strip trailing assistant turns and completion."""
        external_data = {
            "messages": [
                {"role": "user", "content": "Hello, how are you?"},
                {"role": "assistant", "content": "I'm doing well, thank you!"},
            ],
            "completion": "What a nice day",
            "metadata": {"source": "external_dataset", "quality": "high"},
        }

        temp_file = create_temp_dataset_file(external_data, mock_ctx)
        try:
            dataset = Dataset[dataset_kinds.Prompt](dataset_key="test_external", local_file_path=temp_file)
            threads = asyncio.run(dataset.load(mock_ctx))

            assert len(threads) == 1
            assert isinstance(threads[0], StringThread)
            assert threads[0].metadata["source"] == "external_dataset"
            assert threads[0].metadata["quality"] == "high"
            # Trailing assistant turn and completion should be stripped for Prompt kind
            assert "Hello, how are you?" in threads[0].last_content()
            assert "I'm doing well" not in threads[0].last_content()
        finally:
            os.unlink(temp_file)

    def test_load_dataset_external_format_as_completion(self, mock_ctx):
        """Loading external format as Completion should keep the completion."""
        external_data = {
            "messages": [
                {"role": "user", "content": "Hello, how are you?"},
                {"role": "assistant", "content": "I'm doing well, thank you!"},
            ],
            "completion": "What a nice day",
            "metadata": {"source": "external_dataset", "quality": "high"},
        }

        temp_file = create_temp_dataset_file(external_data, mock_ctx)
        try:
            dataset = Dataset[dataset_kinds.Completion](dataset_key="test_external", local_file_path=temp_file)
            threads = asyncio.run(dataset.load(mock_ctx))

            assert len(threads) == 1
            assert isinstance(threads[0], StringThread)
            assert threads[0].metadata["source"] == "external_dataset"
            assert "What a nice day" in threads[0].last_content()
        finally:
            os.unlink(temp_file)

    def test_load_dataset_external_format_with_preferences(self, mock_ctx):
        """Test loading dataset with external format including preference data."""
        external_data = {
            "messages": [{"role": "user", "content": "Tell me about AI."}],
            "other_completion": "AI is bad.",
            "preferred_completion": "AI is a powerful technology that can help solve complex problems.",
            "metadata": {"topic": "AI_discussion"},
        }

        temp_file = create_temp_dataset_file(external_data, mock_ctx)
        try:
            dataset = Dataset[dataset_kinds.Preference](dataset_key="test_external_pref", local_file_path=temp_file)
            threads = asyncio.run(dataset.load(mock_ctx))

            assert len(threads) == 1
            assert isinstance(threads[0], StringThread)
            assert threads[0].metadata["topic"] == "AI_discussion"
            assert threads[0].metadata["other_completion"] == "AI is bad."
            assert (
                threads[0].metadata["preferred_completion"]
                == "AI is a powerful technology that can help solve complex problems."
            )
        finally:
            os.unlink(temp_file)

    def test_load_dataset_multiple_lines(self, mock_ctx):
        """Test loading dataset with multiple lines."""
        data_lines = [
            {"input": [{"role": "user", "content": "Question 1?"}], "completion": "Answer 1", "metadata": {"id": 1}},
            {"input": [{"role": "user", "content": "Question 2?"}], "completion": "Answer 2", "metadata": {"id": 2}},
        ]

        temp_file = create_temp_dataset_file(data_lines, mock_ctx)
        try:
            dataset = Dataset[dataset_kinds.Completion](dataset_key="test_multiple", local_file_path=temp_file)
            threads = asyncio.run(dataset.load(mock_ctx))

            assert len(threads) == 2
            assert all(isinstance(thread, StringThread) for thread in threads)
            assert threads[0].metadata["id"] == 1
            assert threads[1].metadata["id"] == 2
            assert "Answer 1" in threads[0].last_content()
            assert "Answer 2" in threads[1].last_content()
        finally:
            os.unlink(temp_file)

    def test_load_dataset_no_valid_samples_raises_error(self, mock_ctx):
        """Test that loading a dataset with no valid samples raises ValueError."""
        empty_content = "\n   \n"  # Only empty lines

        with tempfile.NamedTemporaryFile(mode="w", delete=False, suffix=".jsonl") as f:
            f.write(empty_content)
            temp_file = f.name

        try:
            dataset = Dataset[dataset_kinds.Prompt](dataset_key="test_empty", local_file_path=temp_file)

            with pytest.raises(ValueError, match="Did not find any valid format samples in the dataset"):
                asyncio.run(dataset.load(mock_ctx))
        finally:
            os.unlink(temp_file)

    def test_load_dataset_external_metadata_with_external_data(self, mock_ctx):
        """Test that external_data fields are properly loaded into thread.metadata."""
        internal_data = {
            "prompt": [["user", "Test prompt"]],
            "metadata": {
                "id": "b2761a88-0662-453b-aba7-27846434dc59",
                "created_at": 1234567890,
                "external_data": {"source_dataset": "custom", "annotation_quality": "high"},
            },
        }

        temp_file = create_temp_dataset_file(internal_data, mock_ctx)
        try:
            dataset = Dataset[dataset_kinds.Prompt](dataset_key="test_external_data", local_file_path=temp_file)
            threads = asyncio.run(dataset.load(mock_ctx))

            assert len(threads) == 1
            # System fields should not be in thread.metadata
            assert "id" not in threads[0].metadata
            assert "created_at" not in threads[0].metadata
            # Only external_data fields should be present
            assert threads[0].metadata["source_dataset"] == "custom"
            assert threads[0].metadata["annotation_quality"] == "high"
        finally:
            os.unlink(temp_file)

    def test_load_dataset_any_format(self, mock_ctx):
        data_lines = [
            {"input": [{"role": "user", "content": "Question 1?"}], "completion": "Answer 1", "metadata": {"id": 1}},
            {"input": [{"role": "user", "content": "Question 2?"}], "completion": "Answer 2", "metadata": {"id": 2}},
        ]

        temp_file = create_temp_dataset_file(data_lines, mock_ctx)
        try:
            dataset = Dataset(dataset_key="test_external_data", local_file_path=temp_file)
            threads = asyncio.run(dataset.load(mock_ctx))

            assert len(threads) == 2
            assert all(isinstance(thread, StringThread) for thread in threads)
            assert threads[0].metadata["id"] == 1
            assert threads[1].metadata["id"] == 2
            assert "Answer 1" in threads[0].last_content()
            assert "Answer 2" in threads[1].last_content()
        finally:
            os.unlink(temp_file)

    def test_load_dataset_external_format_with_fragment_content(self, mock_ctx):
        """Test loading dataset with external format where content is a list of fragment dicts.

        This tests the fix for parse_external_format using StringThread.from_dataset()
        instead of StringThread() constructor, which enables fragment-based content.
        """
        external_data = {
            "messages": [
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": "What do you see in this image?"},
                    ],
                },
                {
                    "role": "assistant",
                    "content": [
                        {"type": "text", "text": "I can see a beautiful landscape."},
                    ],
                },
            ],
            "metadata": {"source": "fragment_test"},
        }

        temp_file = create_temp_dataset_file(external_data, mock_ctx)
        try:
            dataset = Dataset[dataset_kinds.Completion](dataset_key="test_fragment_external", local_file_path=temp_file)
            threads = asyncio.run(dataset.load(mock_ctx))

            assert len(threads) == 1
            assert isinstance(threads[0], StringThread)
            assert threads[0].metadata["source"] == "fragment_test"
            # Verify the content was properly parsed from fragments
            fragments = threads[0].get_fragments()
            assert len(fragments) == 2  # Two turns
            assert fragments[0][0] == "user"
            assert fragments[1][0] == "assistant"
        finally:
            os.unlink(temp_file)

    def test_load_dataset_external_format_with_mixed_string_and_fragment_content(self, mock_ctx):
        """Test loading dataset where some messages have string content and others have fragments.

        StringThread.from_dataset() should handle both cases.
        Uses Completion kind to verify both turns are preserved.
        """
        external_data = {
            "messages": [
                {
                    "role": "user",
                    "content": "Plain string content",  # String content
                },
                {
                    "role": "assistant",
                    "content": [
                        {"type": "text", "text": "Fragment-based content"},
                    ],  # Fragment content
                },
            ],
            "metadata": {"source": "mixed_content_test"},
        }

        temp_file = create_temp_dataset_file(external_data, mock_ctx)
        try:
            dataset = Dataset[dataset_kinds.Completion](dataset_key="test_mixed_content", local_file_path=temp_file)
            threads = asyncio.run(dataset.load(mock_ctx))

            assert len(threads) == 1
            assert isinstance(threads[0], StringThread)
            assert threads[0].metadata["source"] == "mixed_content_test"
        finally:
            os.unlink(temp_file)

    def test_metadata_no_duplication_on_round_trip(self, mock_ctx):
        """Test that metadata doesn't duplicate when doing save → load → save cycles.

        This is a regression test for the bug where external_data fields were being
        spread to the top level of thread.metadata, causing duplication on each
        save → load cycle.

        Example of the bug:
        1. Save thread with metadata: {"field_a": "...", "field_b": "..."}
        2. Load dataset, get: {"id": "...", "external_data": {...}, "field_a": "...", ...}
        3. Save again, get: {"external_data": {"field_a": "...", "id": "...", "external_data": {...}}}
        """
        # Create a dataset with custom metadata in external_data
        internal_data = {
            "prompt": [["user", "Test prompt"]],
            "metadata": {
                "id": "b2761a88-0662-453b-aba7-27846434dc59",
                "created_at": 1234567890,
                "external_data": {
                    "source": "original_dataset",
                    "category": "test_category",
                    "version": "v1.0"
                },
            },
        }

        temp_file = create_temp_dataset_file(internal_data, mock_ctx)
        try:
            # Load the dataset
            dataset = Dataset[dataset_kinds.Prompt](dataset_key="test_no_dup", local_file_path=temp_file)
            threads = asyncio.run(dataset.load(mock_ctx))

            assert len(threads) == 1
            thread = threads[0]

            # Verify external_data fields are accessible in thread.metadata
            assert thread.metadata["source"] == "original_dataset"
            assert thread.metadata["category"] == "test_category"
            assert thread.metadata["version"] == "v1.0"

            # Verify system fields are NOT in thread.metadata (they're metadata ABOUT the sample)
            assert "id" not in thread.metadata
            assert "created_at" not in thread.metadata
            assert "model_id" not in thread.metadata

            # Most importantly: external_data should not be nested in thread.metadata
            assert "external_data" not in thread.metadata

            # Add new metadata fields (simulating processing)
            thread.metadata["score"] = 0.95
            thread.metadata["quality"] = "high"

            # If we were to save this again, thread.metadata should only contain user fields
            # No duplication should occur
            expected_metadata = {
                "source": "original_dataset",
                "category": "test_category",
                "version": "v1.0",
                "score": 0.95,
                "quality": "high"
            }
            assert thread.metadata == expected_metadata
        finally:
            os.unlink(temp_file)
