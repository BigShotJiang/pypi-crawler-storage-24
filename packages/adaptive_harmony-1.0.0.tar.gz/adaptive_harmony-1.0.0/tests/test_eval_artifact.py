import json
import shutil
import tempfile
from dataclasses import dataclass
from pathlib import Path
from unittest.mock import Mock

import pytest

from adaptive_harmony import EvalSample
from harmony_client.artifacts import BaseArtifact
from adaptive_harmony import EvalSampleInteraction, Grade, StringThread
from adaptive_harmony.evaluation.evaluation_artifact import EvaluationArtifact
from adaptive_harmony.runtime.context import RecipeContext


@dataclass
class MockPendingArtifact:
    """Mock PendingArtifact for testing."""

    artifact: BaseArtifact
    uri: str


@pytest.fixture
def mock_ctx():
    """Create a mock RecipeContext for testing."""
    ctx = Mock(spec=RecipeContext)

    # Mock config
    ctx.config = Mock()
    ctx.config.job_id = "test-job-id"

    # Create a temporary artifact directory
    artifacts_dir = Path(tempfile.mkdtemp(prefix="test_artifacts_"))
    ctx.artifacts_dir = artifacts_dir

    # Mock job with pending artifacts tracking
    ctx.job = Mock()
    ctx.job._pending_artifacts = []
    ctx.job.add_pending_artifact = Mock(
        side_effect=lambda artifact, uri: ctx.job._pending_artifacts.append(MockPendingArtifact(artifact=artifact, uri=uri))
    )
    ctx.job.finalize_artifact = Mock()

    return ctx


@pytest.fixture(autouse=True)
def cleanup_test_files(mock_ctx):
    """Clean up test files after each test"""
    yield
    # Remove test artifact directory if it exists
    if hasattr(mock_ctx, "artifacts_dir") and mock_ctx.artifacts_dir.exists():
        shutil.rmtree(mock_ctx.artifacts_dir)


def test_eval_artifact_base_creation(mock_ctx):
    # Test creating the base artifact
    eval_artifact = EvaluationArtifact(name="test-artifact", ctx=mock_ctx)
    assert eval_artifact.name == "test-artifact"
    assert eval_artifact.kind == "eval"
    assert eval_artifact.file_path.parent == mock_ctx.artifacts_dir
    assert eval_artifact.file_path.suffix == ".jsonl"
    print(f"Created artifact: {eval_artifact}")


def test_record_samples(mock_ctx):
    eval_artifact = EvaluationArtifact(name="test-artifact", ctx=mock_ctx)

    sample = EvalSample(
        interaction=EvalSampleInteraction(thread=StringThread(turns=[("user", "Hello, how are you?")])),
        grades=[Grade(value=0.95, grader_key="test-grader", reasoning="Test reasoning")],
        dataset_key="test-dataset",
    )

    eval_artifact.add_samples([sample])

    # Check the file was created and written to
    assert eval_artifact.file_path.exists()
    assert eval_artifact.sample_count == 1
    assert eval_artifact.name == "test-artifact"
    assert eval_artifact.kind == "eval"
    print(f"Created artifact: {eval_artifact}")


def test_metadata_persisted_in_saved_json(mock_ctx):
    eval_artifact = EvaluationArtifact(name="test-artifact", ctx=mock_ctx)

    thread = StringThread(turns=[("user", "Hello, world!")])
    original_metadata = {
        "foo": "bar",
        "num": 42,
        "flag": True,
        "arr": [1, 2],
        "none": None,
        "nested": {"a": 1, "b": {"c": "deep"}},
    }
    thread.metadata = original_metadata

    sample = EvalSample(
        interaction=EvalSampleInteraction(thread=thread),
        grades=[Grade(value=1.0, grader_key="grader")],
        dataset_key="dataset-key",
    )
    eval_artifact.add_samples([sample])

    # Read the file directly and check the content
    with open(eval_artifact.file_path, "r", encoding="utf-8") as f:
        json_str = f.read().strip()
    obj = json.loads(json_str)

    interaction = obj.get("interaction")
    assert interaction is not None

    metadata = None
    if isinstance(interaction, dict) and "New" in interaction:
        thread_obj = interaction["New"]
        metadata = thread_obj.get("metadata")
    elif isinstance(interaction, dict) and "metadata" in interaction:
        metadata = interaction.get("metadata")

    assert metadata == original_metadata


def test_pending_artifact_added(mock_ctx):
    """Test that artifact is added to pending artifacts on creation."""
    eval_artifact = EvaluationArtifact(name="test-artifact", ctx=mock_ctx)

    # Check add_pending_artifact was called
    assert mock_ctx.job.add_pending_artifact.called
    assert len(mock_ctx.job._pending_artifacts) == 1
    pending = mock_ctx.job._pending_artifacts[0]
    assert pending.artifact.id == eval_artifact.id
    assert pending.uri == str(eval_artifact.file_path)


def test_finalize_removes_from_pending(mock_ctx):
    """Test that finalize removes artifact from pending list."""
    eval_artifact = EvaluationArtifact(name="test-artifact", ctx=mock_ctx)

    # Add a sample so there's data to finalize
    sample = EvalSample(
        interaction=EvalSampleInteraction(thread=StringThread(turns=[("user", "test")])),
        grades=[Grade(value=1.0, grader_key="grader")],
        dataset_key="dataset",
    )
    eval_artifact.add_samples([sample])

    # Finalize
    eval_artifact.finalize()

    # Check finalize_artifact was called
    assert mock_ctx.job.finalize_artifact.called
