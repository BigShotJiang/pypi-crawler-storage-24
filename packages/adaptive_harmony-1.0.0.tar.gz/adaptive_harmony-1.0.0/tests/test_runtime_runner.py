import json
import os
import sys
import tempfile
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, Mock, patch

import pytest
from adaptive_harmony.runtime.context import RecipeConfig, RecipeContext
from adaptive_harmony.runtime.data import InputConfig
from adaptive_harmony.runtime.runner import _load_and_run_recipe, _parse_script_metadata


@pytest.fixture
def mock_context():
    ctx = Mock(spec=RecipeContext)

    ctx.config = Mock(spec=RecipeConfig)
    ctx.config.job_id = "test-job-123"
    ctx.config.project = "test-project"
    ctx.config.user_input_file = None

    ctx.job = Mock()
    ctx.job.report_error = Mock()
    ctx.job.start_heartbeat = Mock()
    ctx.job.stop_heartbeat = Mock()
    ctx.job.complete = Mock()
    ctx.job.finalize_pending_artifacts = Mock()

    ctx.client = Mock()
    ctx.client.close = Mock()

    return ctx


@pytest.fixture
def mock_context_manager(mock_context):
    """Create a mock that works as an async context manager returning mock_context.

    This fixture simulates the real RecipeContextManager behavior:
    - __aenter__ returns the context (after _initialize would have been called)
    - __aexit__ calls job.complete() on success, or handles errors on failure
    """

    class MockContextManager:
        async def __aenter__(self):
            # Simulate that _initialize was called (which calls start_heartbeat)
            mock_context.job.start_heartbeat()
            return mock_context

        async def __aexit__(self, exc_type, exc_val, exc_tb):
            # Simulate the real __aexit__ behavior
            if exc_type is None:
                # Success path: finalize artifacts then complete
                # (real job.complete() calls finalize_pending_artifacts internally)
                mock_context.job.finalize_pending_artifacts()
                mock_context.job.complete()
            else:
                # Error path: finalize artifacts and report error
                mock_context.job.finalize_pending_artifacts()
                mock_context.job.report_error(str(exc_val))
            mock_context.job.stop_heartbeat()
            mock_context.client.close()
            return None

    return MockContextManager()


@pytest.fixture
def temp_recipe_file():
    content = """
from adaptive_harmony.runtime.decorators import recipe_main
from adaptive_harmony.runtime.context import RecipeContext

@recipe_main
def test_recipe(context: RecipeContext):
    print(f"Test recipe executed with job_id: {context.config.job_id}")
    return "test_success"
"""

    with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
        f.write(content)
        temp_path = f.name

    yield temp_path
    os.unlink(temp_path)


@pytest.fixture
def temp_user_input_file():
    input_data = {"name": "test_user", "value": 42}

    with tempfile.NamedTemporaryFile(mode="w", suffix=".json", delete=False) as f:
        json.dump(input_data, f)
        temp_path = f.name

    yield temp_path
    os.unlink(temp_path)


class TestLoadAndRunRecipe:
    @pytest.mark.asyncio
    async def test_load_nonexistent_file(self, mock_context):
        with pytest.raises(FileNotFoundError, match="No such file or directory"):
            await _load_and_run_recipe(mock_context, "/nonexistent/recipe.py")

    @pytest.mark.asyncio
    async def test_load_recipe_with_temp_file(self, mock_context, temp_recipe_file):
        with patch("builtins.print") as mock_print:
            await _load_and_run_recipe(mock_context, temp_recipe_file)
            mock_print.assert_any_call(f"Test recipe executed with job_id: {mock_context.config.job_id}")


class DummyInputConfig(InputConfig):
    name: str = "default"
    value: int = 0


class TestDownloadRecipeFromControlPlane:
    """Tests for downloading recipes from the control plane."""

    @patch("adaptive_harmony.runtime.runner.RecipeContext.from_config")
    def test_main_with_recipe_key(self, mock_from_config, mock_context, mock_context_manager):
        """Test downloading and running a recipe using --recipe-key."""
        import shutil
        import zipfile

        # Setup mock context with control_plane
        mock_control_plane = Mock()
        mock_context.control_plane = mock_control_plane

        # Mock job methods
        mock_context.job.start_heartbeat = Mock()
        mock_context.job.stop_heartbeat = Mock()
        mock_context.job.complete = Mock()

        mock_from_config.return_value = mock_context_manager

        # Create a temporary zip file with main.py
        with tempfile.TemporaryDirectory() as temp_dir:
            # Set recipes_dir to a real Path in the temp directory
            recipes_dir = Path(temp_dir) / "recipes"
            recipes_dir.mkdir(parents=True, exist_ok=True)
            mock_context.recipes_dir = recipes_dir

            main_py_content = """
from adaptive_harmony.runtime.decorators import recipe_main
from adaptive_harmony.runtime.context import RecipeContext

@recipe_main
def main_recipe(context: RecipeContext):
    print(f"Recipe from control plane executed with job_id: {context.config.job_id}")
    return "control_plane_success"
"""
            # Create the zip file
            zip_path = os.path.join(temp_dir, "recipe.zip")
            with zipfile.ZipFile(zip_path, "w") as zf:
                zf.writestr("main.py", main_py_content)

            # Mock control_plane.get_recipe_download_url
            mock_control_plane.get_recipe_download_url.return_value = "https://api.example.com/recipes/test-recipe/download"

            # Mock control_plane.download_file to copy our zip file
            def mock_download_file(url, dest_path):
                shutil.copy2(zip_path, dest_path)

            mock_control_plane.download_file.side_effect = mock_download_file

            test_argv = [
                "runner.py",
                "--recipe-key",
                "test-recipe",
                "--job-id",
                "test-control-plane-job",
                "--harmony-url",
                "ws://localhost:12345",
            ]

            with patch.object(sys, "argv", test_argv):
                with patch("builtins.print") as mock_print:
                    from adaptive_harmony.runtime.runner import main

                    try:
                        main()
                    except SystemExit:
                        pass

                    # Verify control plane methods were called
                    mock_control_plane.get_recipe_download_url.assert_called_once_with("test-recipe")
                    mock_control_plane.download_file.assert_called_once()

                    # Verify the download URL was passed correctly
                    download_call_args = mock_control_plane.download_file.call_args
                    assert download_call_args[0][0] == "https://api.example.com/recipes/test-recipe/download"

                    # Verify the recipe executed
                    mock_print.assert_any_call("Recipe from control plane executed with job_id: test-job-123")

                    # Verify job lifecycle methods were called
                    mock_context.job.start_heartbeat.assert_called_once()
                    mock_context.job.finalize_pending_artifacts.assert_called_once()
                    mock_context.job.complete.assert_called_once()
                    mock_context.job.stop_heartbeat.assert_called_once()

    @patch("adaptive_harmony.runtime.runner.RecipeContext.from_config")
    def test_main_with_recipe_key_multi_file(self, mock_from_config, mock_context, mock_context_manager):
        """Test downloading and running a multi-file recipe using --recipe-key."""
        import shutil
        import zipfile

        # Setup mock context with control_plane
        mock_control_plane = Mock()
        mock_context.control_plane = mock_control_plane

        # Mock job methods
        mock_context.job.start_heartbeat = Mock()
        mock_context.job.stop_heartbeat = Mock()
        mock_context.job.complete = Mock()

        mock_from_config.return_value = mock_context_manager

        # Create a temporary zip file with main.py and helper.py
        with tempfile.TemporaryDirectory() as temp_dir:
            # Set recipes_dir to a real Path in the temp directory
            recipes_dir = Path(temp_dir) / "recipes"
            recipes_dir.mkdir(parents=True, exist_ok=True)
            mock_context.recipes_dir = recipes_dir

            helper_py_content = """
def get_greeting():
    return "Hello from helper module"
"""
            main_py_content = """
from adaptive_harmony.runtime.decorators import recipe_main
from adaptive_harmony.runtime.context import RecipeContext
from .helper import get_greeting

@recipe_main
def main_recipe(context: RecipeContext):
    greeting = get_greeting()
    print(f"Multi-file recipe executed: {greeting}")
    return "multi_file_success"
"""
            # Create the zip file
            zip_path = os.path.join(temp_dir, "recipe.zip")
            with zipfile.ZipFile(zip_path, "w") as zf:
                zf.writestr("main.py", main_py_content)
                zf.writestr("helper.py", helper_py_content)

            # Mock control_plane methods
            mock_control_plane.get_recipe_download_url.return_value = "https://api.example.com/recipes/multi-file-recipe/download"

            def mock_download_file(url, dest_path):
                shutil.copy2(zip_path, dest_path)

            mock_control_plane.download_file.side_effect = mock_download_file

            test_argv = [
                "runner.py",
                "--recipe-key",
                "multi-file-recipe",
                "--job-id",
                "test-multi-file-job",
                "--harmony-url",
                "ws://localhost:12345",
            ]

            with patch.object(sys, "argv", test_argv):
                with patch("builtins.print") as mock_print:
                    from adaptive_harmony.runtime.runner import main

                    try:
                        main()
                    except SystemExit:
                        pass

                    # Verify control plane methods were called
                    mock_control_plane.get_recipe_download_url.assert_called_once_with("multi-file-recipe")

                    # Verify the recipe executed with the helper module
                    mock_print.assert_any_call("Multi-file recipe executed: Hello from helper module")

                    # Verify job lifecycle methods were called
                    mock_context.job.start_heartbeat.assert_called_once()
                    mock_context.job.finalize_pending_artifacts.assert_called_once()
                    mock_context.job.complete.assert_called_once()
                    mock_context.job.stop_heartbeat.assert_called_once()

    @patch("adaptive_harmony.runtime.runner.RecipeContext.from_config")
    def test_main_without_control_plane_raises_error(self, mock_from_config, mock_context, mock_context_manager):
        """Test that missing control_plane raises an error."""
        # Setup mock context WITHOUT control_plane
        mock_context.control_plane = None

        mock_from_config.return_value = mock_context_manager

        test_argv = [
            "runner.py",
            "--recipe-key",
            "test-recipe",
            "--job-id",
            "test-job",
            "--harmony-url",
            "ws://localhost:12345",
        ]

        with patch.object(sys, "argv", test_argv):
            from adaptive_harmony.runtime.runner import main

            with pytest.raises(SystemExit):
                main()

            # Verify error was reported via the context manager's __aexit__
            # Pending artifacts should be finalized even on error
            mock_context.job.finalize_pending_artifacts.assert_called_once()
            mock_context.job.report_error.assert_called_once()
            mock_context.job.stop_heartbeat.assert_called_once()
            mock_context.client.close.assert_called_once()


class TestParseScriptMetadata:
    """Tests for _parse_script_metadata function."""

    def test_parse_script_metadata_with_valid_metadata(self):
        """Test parsing a script with valid adaptive metadata block."""
        content = """
# /// adaptive
# dependencies = [
#   "numpy>=1.20.0",
#   "pandas>=1.3.0",
#   "requests",
# ]
# ///

from adaptive_harmony.runtime.decorators import recipe_main

@recipe_main
def main():
    print("Hello, world!")
"""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
            f.write(content)
            f.flush()
            temp_path = f.name

        try:
            result = _parse_script_metadata(Path(temp_path))
            assert result is not None
            assert isinstance(result, list)
            assert len(result) == 3
            assert "numpy>=1.20.0" in result
            assert "pandas>=1.3.0" in result
            assert "requests" in result
        finally:
            os.unlink(temp_path)

    def test_parse_script_metadata_without_metadata(self):
        """Test parsing a script without metadata block."""
        content = """from adaptive_harmony.runtime.decorators import recipe_main

@recipe_main
def main():
    print("Hello, world!")
"""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
            f.write(content)
            f.flush()
            temp_path = f.name

        try:
            result = _parse_script_metadata(Path(temp_path))
            assert result is None
        finally:
            os.unlink(temp_path)

    def test_parse_script_metadata_with_no_dependencies_field(self):
        """Test parsing a script with metadata but no dependencies field."""
        content = """
# /// adaptive
# version = "1.0.0"
# ///

from adaptive_harmony.runtime.decorators import recipe_main

@recipe_main
def main():
    print("Hello, world!")
"""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
            f.write(content)
            f.flush()
            temp_path = f.name

        try:
            result = _parse_script_metadata(Path(temp_path))
            assert result is None
        finally:
            os.unlink(temp_path)

    def test_parse_script_metadata_with_complex_dependencies(self):
        """Test parsing a script with complex dependency specifications."""
        content = """
# /// adaptive
# dependencies = [
#   "numpy>=1.20.0,<2.0.0",
#   "pandas[excel]>=1.3.0",
#   "requests~=2.28.0",
#   "scipy==1.7.3",
# ]
# ///

from adaptive_harmony.runtime.decorators import recipe_main

@recipe_main
def main():
    print("Hello, world!")
"""
        with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False) as f:
            f.write(content)
            f.flush()
            temp_path = f.name

        try:
            result = _parse_script_metadata(Path(temp_path))
            assert result is not None
            assert isinstance(result, list)
            assert len(result) == 4
            assert "numpy>=1.20.0,<2.0.0" in result
            assert "pandas[excel]>=1.3.0" in result
            assert "requests~=2.28.0" in result
            assert "scipy==1.7.3" in result
        finally:
            os.unlink(temp_path)
