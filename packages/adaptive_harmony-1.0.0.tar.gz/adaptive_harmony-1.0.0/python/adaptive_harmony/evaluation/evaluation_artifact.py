# Re-export from harmony_client for backwards compatibility
from harmony_client.artifacts.evaluation_artifact import EvaluationArtifact

__all__ = ["EvaluationArtifact"]
