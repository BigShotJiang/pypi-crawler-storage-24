import os
from typing import Callable, Sequence

from loguru import logger as log
from tqdm.auto import tqdm

from adaptive_harmony import (
    CosineScheduler,
    DataSet,
    Logger,
    StageNotifier,
    StdoutJobNotifier,
    StringThread,
    TrainingModel,
)
from adaptive_harmony.common.callbacks import RecipeCallback, invoke_callbacks
from adaptive_harmony.common.checkpointing import CheckpointManager
from adaptive_harmony.core.losses import train_sft_tangents
from adaptive_harmony.core.utils import async_map_batch, hash_hyperparams, log_args
from adaptive_harmony.metric_logger import StdoutLogger

SFT_HYPERPARAMS = {
    "lr",
    "lr_scheduler",
    "samples_per_batch",
    "max_grad_norm",
    "epochs",
    "weight_decay",
    "skip_nan_gradients",
    "use_tangents",
}


def _check_dataset_weights(dataset: list[StringThread]):
    user_weighted = False
    assistant_unweighted = False

    for thread in dataset:
        thread_has_user_weight = False
        thread_has_assistant_weight = False
        for turn, weight in zip(thread.get_turns(), thread.get_turn_weights()):
            if weight > 0 and turn.role == "user":
                thread_has_user_weight = True
            if weight > 0 and turn.role == "assistant":
                thread_has_assistant_weight = True
        if thread_has_user_weight:
            user_weighted = True
        if not thread_has_assistant_weight:
            assistant_unweighted = True

        if user_weighted and assistant_unweighted:
            break

    if user_weighted:
        log.warning("Some samples have non-zero weight on user turns: you may be training on user messages !!!")
    if assistant_unweighted:
        log.warning("Some samples have zero weight on assistant turns — they won't contribute to training.")


class SFT:
    @log_args
    @hash_hyperparams(include=SFT_HYPERPARAMS)
    def __init__(
        self,
        dataset: list[StringThread],
        model: TrainingModel,
        logger: Logger = StdoutLogger(),
        stage_notifier: StageNotifier = StdoutJobNotifier().stage_notifier("SFT Training"),
        callbacks: Sequence[RecipeCallback] = [],
        lr: float = 1e-5,
        lr_scheduler: Callable[[float], float] | None = None,
        samples_per_batch=512,  # axel magic number: "pretty well validated across different scales"
        max_grad_norm=1.0,
        epochs: int = 1,
        weight_decay: float = 0,
        skip_nan_gradients: bool = False,
        restart_from_checkpoint: str | None = None,
        checkpoint_frequency: float = 0.2,
        data_seed: int = 42,
        use_tangents: bool = False,
    ):
        _check_dataset_weights(dataset)  # Check dataset weights and log warnings if they seem unusual
        self.dataset = DataSet(dataset, allow_looping=epochs != 1, seed=data_seed)
        self.use_tangents = use_tangents
        self.lr_schedule = lr_scheduler or CosineScheduler(lr)
        self.model = model
        self.logger = logger
        self.stage_notifier = stage_notifier
        self.callbacks = callbacks
        self.samples_per_batch = samples_per_batch
        self.max_grad_norm = max_grad_norm
        self.epochs = epochs
        self.weight_decay = weight_decay
        self.skip_nan_gradients = skip_nan_gradients

        self.checkpoint_manager = CheckpointManager(
            recipe_name="SFT",
            dataset=self.dataset,
            threads_dataset=dataset,
            callbacks=self.callbacks,
            hyperparams_hash=self._hyperparams_hash,  # type: ignore
            job_id=os.environ.get("HARMONY_JOB_ID"),
            checkpoint_frequency=checkpoint_frequency,
            restart_from_checkpoint=restart_from_checkpoint,
        )

    @property
    def training_completion_percentage(self):
        return self.dataset.completion_percentage() / self.epochs

    async def _recipe_specific_checkpoint_loading(self, checkpoint_data: dict) -> None:
        model_checkpoint_name = checkpoint_data["model_checkpoint_name"]
        await self.model.load(f"model_registry://{model_checkpoint_name}")
        self.model.set_optim_step(checkpoint_data["optim_step"])

    async def _recipe_specific_checkpoint_saving(self) -> dict:
        progress_pct = int(self.training_completion_percentage * 100)
        model_checkpoint_name = (
            f"checkpoint-{self.checkpoint_manager.job_id}-{progress_pct}{self.checkpoint_manager.stage_suffix}"
        )
        model_checkpoint_name = await self.model.save(model_checkpoint_name, inference_only=False)

        return {
            "model_checkpoint_name": model_checkpoint_name,
            "optim_step": self.model.get_optim_step(),
        }

    async def run(self):
        await self.checkpoint_manager.maybe_restore_checkpoint(self._recipe_specific_checkpoint_loading)

        tot_num_samples = len(self.dataset) * self.epochs

        self.stage_notifier.report_progress(
            tot_num_samples=tot_num_samples,
            processed_num_samples=self.dataset.idx,
            monitoring_link=self.logger.training_monitoring_link,
        )

        with tqdm(total=100) as pbar:
            if logs := await invoke_callbacks(self.callbacks, self.training_completion_percentage):
                self.logger(logs)
            while self.training_completion_percentage < 1.0:
                self.stage_notifier.report_progress(
                    tot_num_samples=tot_num_samples,
                    processed_num_samples=self.dataset.idx,
                    monitoring_link=self.logger.training_monitoring_link,
                )

                if self.use_tangents:
                    all_metrics = await async_map_batch(
                        lambda thread: train_sft_tangents(self.model, thread),
                        self.dataset,
                        self.samples_per_batch,
                    )
                    # Aggregate metrics
                    total_logprob = sum(m["logprob"] for m in all_metrics)
                    total_tokens = sum(m["num_tokens"] for m in all_metrics)
                    avg_metrics = {
                        "policy/loss": -total_logprob / total_tokens if total_tokens > 0 else 0.0,
                        "policy/num_tokens": total_tokens,
                    }
                else:
                    await async_map_batch(self.model.train_language_modelling, self.dataset, self.samples_per_batch)
                    avg_metrics = {}

                cp = self.training_completion_percentage
                current_lr = self.lr_schedule(cp)
                pbar.update(cp * 100.0 - pbar.n)

                logs = await self.model.optim_step(
                    current_lr,
                    wd=self.weight_decay,
                    max_grad_norm=self.max_grad_norm,
                    skip_nan_gradients=self.skip_nan_gradients,
                )

                callback_logs = await invoke_callbacks(self.callbacks, self.training_completion_percentage)

                self.logger(logs | avg_metrics | callback_logs | dict(completion_percentage=cp))

                self.stage_notifier.report_progress(
                    tot_num_samples=tot_num_samples,
                    processed_num_samples=self.dataset.idx,
                    monitoring_link=self.logger.training_monitoring_link,
                )

                if await self.checkpoint_manager.maybe_checkpoint(cp, self._recipe_specific_checkpoint_saving):
                    break
