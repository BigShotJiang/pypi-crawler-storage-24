import os
from dataclasses import dataclass
from functools import partial
from itertools import repeat
from typing import Callable, Sequence

import numpy as np

from adaptive_harmony import (
    CosineScheduler,
    DataSet,
    Logger,
    StageNotifier,
    StdoutJobNotifier,
    StringThread,
    TokenizedThread,
    TrainingModel,
)
from adaptive_harmony.common import RecipeCallback
from adaptive_harmony.common.callbacks import invoke_callbacks
from adaptive_harmony.common.checkpointing import CheckpointManager
from adaptive_harmony.core.losses import train_grpo_tangents
from adaptive_harmony.core.utils import async_map, async_map_batch, get_minibatches, hash_hyperparams, log_args
from adaptive_harmony.environment.environment import EnvironmentFactory, TrajectoryHistory, get_reward_statistics
from adaptive_harmony.metric_logger import StdoutLogger


def flatten[T](nested_lists: list[list[T]]) -> list[T]:
    return [elem for inner_list in nested_lists for elem in inner_list]


@dataclass
class Sample:
    threads: list[TokenizedThread]
    logprobs: list[list[float]]
    ref_logprobs: list[list[float]]
    advantage: list[list[float]]
    kl_div: list[np.ndarray]
    cumulative_score: float
    cumulative_gen_len: float


ENVGRPO_HYPERPARAMS = {
    "max_num_grpo_steps",
    "completions_per_sample",
    "lr",
    "lr_scheduler",
    "samples_per_batch",
    "samples_per_mini_batch",
    "mini_epochs_per_batch",
    "max_grad_norm",
    "clip_range",
    "kl_beta",
    "weight_decays",
    "skip_nan_gradients",
}


class ENVGRPO:
    @log_args
    @hash_hyperparams(include=ENVGRPO_HYPERPARAMS)
    def __init__(
        self,
        dataset: list[StringThread],
        model: TrainingModel,
        environment_factory: EnvironmentFactory,
        logger: Logger = StdoutLogger(),
        stage_notifier: StageNotifier = StdoutJobNotifier().stage_notifier("ENVGRPO Training"),
        callbacks: Sequence[RecipeCallback] = [],
        max_num_grpo_steps: int | None = None,
        completions_per_sample=8,
        lr: float = 7.5e-7,
        lr_scheduler: Callable[[float], float] | None = None,
        samples_per_batch=128,
        samples_per_mini_batch=128,
        mini_epochs_per_batch=1,
        max_grad_norm=1.0,
        clip_range=0.1,
        kl_beta=0.1,
        weight_decays: float = 0.0,
        skip_nan_gradients: bool = False,
        restart_from_checkpoint: str | None = None,
        checkpoint_frequency: float = 0.2,
        data_seed: int = 42,
        use_tangents: bool = False,
    ):
        # Core components
        self.dataset = DataSet(dataset, allow_looping=True, seed=data_seed)
        self.model = model
        self.logger = logger
        self.stage_notifier = stage_notifier
        self.sample_index_counter = 0
        self.skip_nan_gradients = skip_nan_gradients
        # GRPO HP's
        self.max_num_batches = max_num_grpo_steps
        self.completions_per_sample = completions_per_sample
        self.lr_schedule = lr_scheduler or CosineScheduler(lr)
        self.samples_per_batch = samples_per_batch // completions_per_sample
        self.samples_per_mini_batch = samples_per_mini_batch
        self.total_num_samples = (
            self.max_num_batches * self.samples_per_batch if self.max_num_batches else len(self.dataset)
        )
        self.max_grad_norm = max_grad_norm
        self.environment_factory = environment_factory
        self.clip_range = clip_range
        self.kl_beta = kl_beta
        self.weight_decays = weight_decays
        self.mini_epochs_per_batch = mini_epochs_per_batch
        self.use_tangents = use_tangents

        self.num_batches_processed = 0
        self.callbacks = callbacks

        self.checkpoint_manager = CheckpointManager(
            recipe_name="ENVGRPO",
            dataset=self.dataset,
            threads_dataset=dataset,
            callbacks=self.callbacks,
            hyperparams_hash=self._hyperparams_hash,  # type: ignore
            job_id=os.environ.get("HARMONY_JOB_ID"),
            checkpoint_frequency=checkpoint_frequency,
            restart_from_checkpoint=restart_from_checkpoint,
        )

    @property
    def training_completion_percentage(self):
        return (
            self.dataset.completion_percentage()
            if self.max_num_batches is None
            else min(self.num_batches_processed / self.max_num_batches, 1.0)
        )

    async def gen_data(self, sample: StringThread) -> list[Sample]:
        async def generate_trajectory(
            prompt: StringThread,
        ) -> tuple[list[TokenizedThread], TrajectoryHistory]:
            # this create the environment for the first turn.
            environment = self.environment_factory.create_environment(prompt.metadata)
            all_threads, score = await environment.generate_trajectory_and_grade(self.model, prompt)
            tokenized_trajectories = await async_map(self.model.tokenize_thread, all_threads)
            return tokenized_trajectories, score

        async def create_samples_for_trajectory(
            t: tuple[list[TokenizedThread], TrajectoryHistory], reward_mean: float, reward_std: float
        ) -> Sample:
            tokenized_threads, traj_score = t
            logprobs = await async_map(self.model.logprobs_per_token, tokenized_threads)
            ref_logprobs = await async_map(self.model_ref.logprobs_per_token, tokenized_threads)
            kl = [
                np.array(lp, dtype=np.float32) - np.array(ref_lp, dtype=np.float32)
                for lp, ref_lp in zip(logprobs, ref_logprobs)
            ]
            advantages = await traj_score.get_advantage_for_grpo(
                reward_mean=reward_mean, reward_std=reward_std, tokenized_threads=tokenized_threads, model=self.model
            )

            return Sample(
                threads=tokenized_threads,
                logprobs=logprobs,
                ref_logprobs=ref_logprobs,
                advantage=advantages,
                kl_div=kl,
                cumulative_score=traj_score.get_cumulative_reward(),
                cumulative_gen_len=sum(len(thread_advantage) for thread_advantage in advantages),
            )

        assert self.model_ref is not None, "Calling `gen_data` before reference model has been set"

        trajs_and_scores = await async_map_batch(
            generate_trajectory, repeat(sample), batch_size=self.completions_per_sample
        )
        batch_mean, batch_std = get_reward_statistics([s for _, s in trajs_and_scores])
        return await async_map(
            partial(create_samples_for_trajectory, reward_mean=batch_mean, reward_std=batch_std), trajs_and_scores
        )

    async def train_sample(self, sample: Sample) -> list[dict]:
        async def train_thread(idx: int):
            if self.use_tangents:
                return await train_grpo_tangents(
                    self.model,
                    sample.threads[idx],
                    sample.logprobs[idx],
                    sample.ref_logprobs[idx],
                    sample.advantage[idx],
                    self.clip_range,
                    self.kl_beta,
                    use_sequence_lps=False,
                )
            else:
                await self.model.train_grpo(
                    sample.threads[idx],
                    sample.logprobs[idx],
                    sample.ref_logprobs[idx],
                    sample.advantage[idx],
                    self.clip_range,
                    self.kl_beta,
                )
                return {}

        return await async_map(train_thread, range(len(sample.threads)))

    async def _recipe_specific_checkpoint_loading(self, checkpoint_data: dict) -> None:
        self.num_batches_processed = checkpoint_data["num_batches_processed"]

        model_checkpoint_name = checkpoint_data["model_checkpoint_name"]
        model_checkpoint_name = await self.model.load(f"model_registry://{model_checkpoint_name}")

        self.sample_index_counter = checkpoint_data.get("sample_index_counter", 0)

        self.model.set_optim_step(checkpoint_data["optim_step"])

    async def _recipe_specific_checkpoint_saving(self) -> dict:
        progress_pct = int(self.training_completion_percentage * 100)
        model_checkpoint_name = (
            f"checkpoint-{self.checkpoint_manager.job_id}-{progress_pct}{self.checkpoint_manager.stage_suffix}-policy"
        )
        await self.model.save(model_checkpoint_name, inference_only=False)

        return {
            "num_batches_processed": self.num_batches_processed,
            "model_checkpoint_name": model_checkpoint_name,
            "sample_index_counter": self.sample_index_counter,
            "optim_step": self.model.get_optim_step(),
        }

    async def run(self):
        self.model_ref = await self.model.clone_inf()
        await self.checkpoint_manager.maybe_restore_checkpoint(self._recipe_specific_checkpoint_loading)

        self.stage_notifier.report_progress(
            tot_num_samples=self.total_num_samples,
            processed_num_samples=self.num_batches_processed * self.samples_per_batch,
            monitoring_link=self.logger.training_monitoring_link,
        )

        if logs := await invoke_callbacks(self.callbacks, self.training_completion_percentage):
            self.logger(logs)

        while self.training_completion_percentage < 1.0:
            self.num_batches_processed += 1

            # Generate training samples
            data = await async_map_batch(self.gen_data, self.dataset, self.samples_per_batch)
            flattened_data = sum([inner_list for inner_list in data], start=[])

            completion_percentage = (
                self.dataset.completion_percentage()
                if self.max_num_batches is None
                else min(self.num_batches_processed / self.max_num_batches, 1.0)
            )
            current_lr = self.lr_schedule(completion_percentage)

            scorer_logs = {}
            for key, value in self.environment_factory.get_logs(clear=True).items():
                if "/" not in key:
                    key = f"environment/{key}"
                scorer_logs[key] = value
            batch_logs = {
                **scorer_logs,
                **self.get_train_batch_logs(flattened_data),
            }

            current_lr = self.lr_schedule(self.training_completion_percentage)

            # Train on generated samples
            minibatches = get_minibatches(flattened_data, self.samples_per_mini_batch, self.mini_epochs_per_batch)
            for idx, mini_batch in enumerate(minibatches):
                tangent_metrics_list = flatten(await async_map(self.train_sample, mini_batch))

                optim_logs = await self.model.optim_step(
                    current_lr, wd=0.0, max_grad_norm=self.max_grad_norm, skip_nan_gradients=self.skip_nan_gradients
                )

                if tangent_metrics_list and tangent_metrics_list[0]:
                    for key in tangent_metrics_list[0]:
                        optim_logs[f"policy/{key}"] = np.mean([m[key] for m in tangent_metrics_list]).item()

                if idx == len(minibatches) - 1:
                    # only log tables and full batch-related logs on the final minibatch
                    self.logger(optim_logs | batch_logs)
                else:
                    self.logger(optim_logs | dict(completion_percentage=self.training_completion_percentage))

            if callback_logs := await invoke_callbacks(self.callbacks, self.training_completion_percentage):
                self.logger(callback_logs)

            self.stage_notifier.report_progress(
                tot_num_samples=self.total_num_samples,
                processed_num_samples=self.num_batches_processed * self.samples_per_batch,
                monitoring_link=self.logger.training_monitoring_link,
            )

            if await self.checkpoint_manager.maybe_checkpoint(
                self.training_completion_percentage, self._recipe_specific_checkpoint_saving
            ):
                break

    def get_train_batch_logs(self, data: list[Sample]) -> dict:
        return {
            **dict(
                completion_percentage=self.training_completion_percentage,
                score_mean=np.mean([s.cumulative_score for s in data]).item(),
                score_std=np.std([s.cumulative_score for s in data]).item(),
                generation_length=np.mean([s.cumulative_gen_len for s in data]).item(),
                # we also check for envgspo format where you have a single advantage
                percentage_no_advantages=np.mean(
                    [
                        sample.advantage[0][0] == 0 if isinstance(sample.advantage, list) else sample.advantage == 0
                        for sample in data
                    ]
                ).item(),
                kl_div=np.mean([np.concatenate(s.kl_div).mean() for s in data]).item(),
            ),
        }
