from dataclasses import dataclass
from functools import partial
from itertools import repeat
from typing import Callable, Sequence, TypeAlias

import numpy as np
from numpy.typing import NDArray

from adaptive_harmony import (
    Logger,
    StageNotifier,
    StdoutJobNotifier,
    StringThread,
    TokenizedThread,
    TrainingModel,
)
from adaptive_harmony.common import RecipeCallback
from adaptive_harmony.common.env_grpo import ENVGRPO
from adaptive_harmony.core.losses import train_grpo_tangents
from adaptive_harmony.core.utils import (
    async_map,
    async_map_batch,
    hash_hyperparams,
    log_args,
)
from adaptive_harmony.environment import EnvironmentFactory, TrajectoryHistory, get_reward_statistics
from adaptive_harmony.metric_logger import StdoutLogger

FloatArray: TypeAlias = NDArray[np.float32]


@dataclass
class Sample:
    threads: list[TokenizedThread]
    logprobs: list[list[float]]
    ref_logprobs: list[list[float]]
    advantage: float
    kl_div: list[np.ndarray]
    # for logging
    cumulative_score: float
    cumulative_gen_len: float


ENVGSPO_HYPERPARAMS = {
    "max_num_grpo_steps",
    "completions_per_sample",
    "lr",
    "lr_scheduler",
    "samples_per_batch",
    "samples_per_mini_batch",
    "mini_epochs_per_batch",
    "max_grad_norm",
    "clip_range",
    "kl_beta",
    "weight_decays",
    "skip_nan_gradients",
}


class ENVGSPO(ENVGRPO):
    @log_args
    @hash_hyperparams(include=ENVGSPO_HYPERPARAMS)
    def __init__(
        self,
        dataset: list[StringThread],
        model: TrainingModel,
        environment_factory: EnvironmentFactory,
        logger: Logger = StdoutLogger(),
        stage_notifier: StageNotifier = StdoutJobNotifier().stage_notifier("ENVGSPO Training"),
        callbacks: Sequence[RecipeCallback] = [],
        max_num_grpo_steps: int | None = None,
        completions_per_sample=8,
        lr: float = 7.5e-7,
        lr_scheduler: Callable[[float], float] | None = None,
        samples_per_batch=128,
        samples_per_mini_batch=128,
        mini_epochs_per_batch=1,
        max_grad_norm=1.0,
        clip_range=0.01,
        kl_beta=0.1,
        weight_decays: float = 0.0,
        skip_nan_gradients: bool = False,
        restart_from_checkpoint: str | None = None,
        checkpoint_frequency: float = 0.2,
        data_seed: int = 42,
        use_tangents: bool = False,
    ):
        super().__init__(
            dataset,
            model,
            environment_factory,
            logger,
            stage_notifier,
            callbacks,
            max_num_grpo_steps=max_num_grpo_steps,
            completions_per_sample=completions_per_sample,
            lr=lr,
            lr_scheduler=lr_scheduler,
            samples_per_batch=samples_per_batch,
            samples_per_mini_batch=samples_per_mini_batch,
            mini_epochs_per_batch=mini_epochs_per_batch,
            max_grad_norm=max_grad_norm,
            clip_range=clip_range,
            kl_beta=kl_beta,
            weight_decays=weight_decays,
            skip_nan_gradients=skip_nan_gradients,
            restart_from_checkpoint=restart_from_checkpoint,
            checkpoint_frequency=checkpoint_frequency,
            data_seed=data_seed,
            use_tangents=use_tangents,
        )

    async def gen_data(self, sample: StringThread) -> list[Sample]:
        # need to override gen data due to the single reward check
        async def generate_trajectory(
            prompt: StringThread,
        ) -> tuple[list[TokenizedThread], TrajectoryHistory]:
            # this create the environment for the first turn.
            environment = self.environment_factory.create_environment(prompt.metadata)
            all_threads, score = await environment.generate_trajectory_and_grade(self.model, prompt)
            tokenized_trajectories = await async_map(self.model.tokenize_thread, all_threads)
            return tokenized_trajectories, score

        async def create_samples_for_trajectory(
            t: tuple[list[TokenizedThread], TrajectoryHistory], reward_mean: float, reward_std: float
        ) -> Sample:
            tokenized_threads, traj_score = t
            logprobs = await async_map(self.model.logprobs_per_token, tokenized_threads)
            ref_logprobs = await async_map(self.model_ref.logprobs_per_token, tokenized_threads)
            kl = [
                np.array(lp, dtype=np.float32) - np.array(ref_lp, dtype=np.float32)
                for lp, ref_lp in zip(logprobs, ref_logprobs)
            ]
            advantage = await traj_score.get_advantage_for_gspo(reward_mean=reward_mean, reward_std=reward_std)

            return Sample(
                threads=tokenized_threads,
                logprobs=logprobs,
                ref_logprobs=ref_logprobs,
                advantage=advantage,
                kl_div=kl,
                cumulative_score=traj_score.get_cumulative_reward(),
                cumulative_gen_len=sum(len(logprob) for logprob in logprobs),
            )

        assert self.model_ref is not None, "Calling `gen_data` before reference model has been set"

        trajs_and_scores = await async_map_batch(
            generate_trajectory, repeat(sample), batch_size=self.completions_per_sample
        )
        batch_mean, batch_std = get_reward_statistics([s for _, s in trajs_and_scores])
        return await async_map(
            partial(create_samples_for_trajectory, reward_mean=batch_mean, reward_std=batch_std), trajs_and_scores
        )

    async def train_sample(self, sample: Sample) -> list[dict]:
        async def train_thread(idx: int):
            if self.use_tangents:
                return await train_grpo_tangents(
                    model=self.model,
                    sample=sample.threads[idx],
                    trajectory_logprobs=sample.logprobs[idx],
                    ref_logprobs=sample.ref_logprobs[idx],
                    advantages=[sample.advantage],
                    clip_range=self.clip_range,
                    kl_beta=self.kl_beta,
                    use_sequence_lps=True,
                )
            else:
                await self.model.train_gspo(
                    thread=sample.threads[idx],
                    trajectory_logprobs=sample.logprobs[idx],
                    reference_logprobs=sample.ref_logprobs[idx],
                    advantage=[sample.advantage],
                    left_clip=self.clip_range,
                    right_clip=self.clip_range,
                    kl_beta=self.kl_beta,
                )
                return {}

        return await async_map(train_thread, range(len(sample.threads)))
