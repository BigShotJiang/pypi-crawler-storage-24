class IgnoreGradeException(Exception):
    """
    Exception to indicate that a grade should be ignored/is not applicable.
    Accepts a custom message explaining why the score was ignored.
    """

    default_ignore_score_message = (
        "Grade should be ignored. Typically raised when a judge grader makes a mistake, "
        "or the grading criteria/methodology is not applicable to the particular sample being graded. Under these circumstances, "
        "it would be wrong to penalize the input itself (which would reflect in a lower eval score, or a negative reward in training)."
    )

    def __init__(self, message: str | None = None):
        error_message = self.default_ignore_score_message
        if message:
            error_message += f" Error details: {message}"

        super().__init__(error_message)
        self.message = error_message
