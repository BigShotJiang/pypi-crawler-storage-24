from __future__ import annotations

from abc import ABC, abstractmethod
from collections import defaultdict
from functools import partial
from itertools import groupby
from numbers import Number
from typing import Any, Callable

import numpy as np

from adaptive_harmony import Grade, InferenceModel, StringThread, TokenizedThread
from adaptive_harmony.core.utils import async_map
from adaptive_harmony.logging_table import Table

GradeAggregator = Callable[[list[Grade]], float]
"""Callable that reduces a list of Grade objects into a single float reward for training."""


def sum_of_grade_values(grades: list[Grade]) -> float:
    return sum(g.value for g in grades)


def mean_of_grade_values(grades: list[Grade]) -> float:
    return sum(g.value for g in grades) / len(grades) if grades else 0.0


def get_reward_statistics(scores: list[TrajectoryHistory]):
    """
    Compute mean and standard deviation of aggregated rewards across multiple trajectories.

    Each TrajectoryHistory uses its own aggregator to convert list[Grade] to float.

    Args:
        scores: List of TrajectoryHistory objects

    Returns:
        Tuple of (mean, std+epsilon) where epsilon=1e-8 prevents division by zero
    """
    flat_rewards = sum((traj.get_raw_rewards_for_stats() for traj in scores), [])
    flat_rewards_array = np.asanyarray(flat_rewards)
    return np.mean(flat_rewards_array).item(), np.std(flat_rewards).item() + 1e-8


class ThreadScore:
    """
    Tracks grades for a single conversation thread.

    A thread represents one continuous conversation segment. Each model generation
    turn either receives a list of Grade objects or None if no grading occurred.

    Attributes:
        grades: List of grade lists, one per turn. grades[i] is either a list[Grade]
            or None if turn i received no grades. Length equals number of turns.
        environment_snapshots: List of Environment snapshots for Monte Carlo rollouts in vine methods
    """

    def __init__(self) -> None:
        self.grades: list[list[Grade] | None] = []
        self.environment_snapshots: list[Environment] = []

    def add_turn(self, grades: list[Grade] | None):
        self.grades.append(grades)

    def get_all_grades(self) -> list[list[Grade]]:
        """Return all non-None grade lists."""
        return [g for g in self.grades if g is not None]

    def get_all_rewards(self, aggregator: GradeAggregator) -> list[float]:
        """Aggregate each non-None grade list into a float using the provided aggregator."""
        return [aggregator(g) for g in self.grades if g is not None]

    def store_environment_snapshot(self, environment: Environment):
        self.environment_snapshots.append(environment)


class TrajectoryHistory:
    """
    Manages grading across multiple conversation threads in a trajectory.

    A trajectory is a sequence of threads (conversation segments). Stores a list[Grade]
    per turn, and provides both:
    - Training-facing methods that aggregate grades into floats via a GradeAggregator
    - Evaluation-facing methods that preserve raw Grade objects for per-grader analysis

    Attributes:
        thread_scores: List of ThreadScore objects, one per conversation segment
        total_number_of_turns_generated: Total count of model generations across all threads
    """

    def __init__(self, aggregator: GradeAggregator = mean_of_grade_values) -> None:
        self.thread_scores: list[ThreadScore] = []
        self.total_number_of_turns_generated = 0
        self._aggregator = aggregator

    def add_new_thread(self):
        self.thread_scores.append(ThreadScore())

    def add_turn(self, grades: list[Grade] | None):
        self.thread_scores[-1].add_turn(grades)
        self.total_number_of_turns_generated += 1

    # ── Training-facing methods (aggregate grades → floats) ──────────────

    def get_raw_rewards_for_stats(self) -> list[float]:
        return [r for thread_score in self.thread_scores for r in thread_score.get_all_rewards(self._aggregator)]

    def _compute_turn_level_advantages(self, reward_mean: float, reward_std: float) -> list[list[float]]:
        result: list[list[float]] = []
        cumulative_future_reward = 0.0

        for thread_score in reversed(self.thread_scores):
            thread_advantages: list[float] = []

            for grades in reversed(thread_score.grades):
                if grades is not None:
                    reward = self._aggregator(grades)
                    cumulative_future_reward += (reward - reward_mean) / reward_std
                thread_advantages.append(cumulative_future_reward)

            result.append(thread_advantages[::-1])

        return result[::-1]

    async def count_weighted_tokens_per_turn(self, thread: TokenizedThread, model: InferenceModel) -> list[int]:
        weights = (await model.serialize_tokenized_thread(thread))[2]
        return [len(list(group)) for key, group in groupby(weights, key=bool) if key]

    async def get_advantage_for_grpo(
        self,
        reward_mean: float,
        reward_std: float,
        tokenized_threads: list[TokenizedThread],
        model: InferenceModel,
    ) -> list[list[float]]:
        """
        Compute token-level advantages for Group Relative Policy Optimization (GRPO).

        Computes cumulative future rewards (advantages) for each token in the trajectory,
        normalized by reward_mean and reward_std. Grades are aggregated via the aggregator,
        then propagated backward through turns and repeated for each weighted token in
        assistant turns.

        Args:
            reward_mean: Mean reward for normalization
            reward_std: Standard deviation of rewards for normalization
            tokenized_threads: List of tokenized conversation threads
            model: Inference model used to determine token weights per turn

        Returns:
            List of lists where each inner list contains per-token advantages for one thread
        """
        turn_level_advantages = self._compute_turn_level_advantages(reward_mean, reward_std)

        assert all(
            len(thread_avantages) == sum(1 if w else 0 for w in thread.get_turn_weights())
            for thread_avantages, thread in zip(turn_level_advantages, tokenized_threads, strict=True)
        ), "Missmatch between rewards and thread weights"

        token_counts_per_thread = await async_map(
            partial(self.count_weighted_tokens_per_turn, model=model), tokenized_threads
        )

        return [
            np.repeat(turn_advs, token_counts).tolist()
            for turn_advs, token_counts in zip(turn_level_advantages, token_counts_per_thread, strict=True)
        ]

    async def get_advantage_for_gspo(self, reward_mean: float, reward_std: float) -> float:
        """
        Compute normalized advantage for Group Sampling Policy Optimization (GSPO).

        GSPO currently only supports a single reward per trajectory. This method
        returns the normalized (mean-centered, std-scaled) reward value.

        Args:
            reward_mean: Mean reward for normalization
            reward_std: Standard deviation of rewards for normalization

        Returns:
            Normalized advantage value (single float)

        Raises:
            AssertionError: If trajectory contains more than one reward
        """
        assert len(self.get_raw_rewards_for_stats()) == 1, "Gspo currently only supports single reward per trajectory"
        return (self.get_raw_rewards_for_stats()[0] - reward_mean) / reward_std

    async def get_advantage_for_ppo(
        self,
        model: InferenceModel,
        tokenized_threads: list[TokenizedThread],
        value_preds: list[list[float]],
        kl_divs: list[list[float]],
        kl_beta: float,
        gae_lambda: float,
        gae_gamma: float,
    ) -> tuple[list[list[float]], list[list[float]]]:
        previous_gaelam = 0.0
        next_value = 0.0
        return_of_future_turns: float = 0.0

        token_counts_per_thread = await async_map(
            partial(self.count_weighted_tokens_per_turn, model=model), tokenized_threads
        )

        advantages: list[list[float]] = []
        returns: list[list[float]] = []

        for (
            thread_score,
            thread_kl,
            thread_values,
            thread_token_count,
        ) in zip(
            reversed(self.thread_scores),
            reversed(kl_divs),
            reversed(value_preds),
            reversed(token_counts_per_thread),
            strict=True,
        ):
            thread_reward_list = []
            for grades, count in zip(thread_score.grades, thread_token_count):
                turn_reward = [0.0] * count
                if grades is not None:
                    turn_reward[-1] = self._aggregator(grades)
                thread_reward_list.append(np.array(turn_reward))

            thread_rewards = np.concatenate(thread_reward_list)

            thread_rewards += np.asarray(thread_kl) * kl_beta

            thread_returns = [0.0] * len(thread_rewards)
            thread_returns[-1] = thread_rewards[-1] + gae_gamma * return_of_future_turns
            for t in reversed(range(len(thread_rewards) - 1)):
                thread_returns[t] = thread_rewards[t] + gae_gamma * thread_returns[t + 1]
            return_of_future_turns = thread_returns[0]

            thread_advantages = [0.0] * len(thread_rewards)
            for t in reversed(range(len(thread_rewards))):
                delta = thread_rewards[t] + gae_gamma * next_value - thread_values[t]
                previous_gaelam = delta + gae_gamma * gae_lambda * previous_gaelam
                next_value = thread_values[t]
                thread_advantages[t] = previous_gaelam

            advantages.insert(0, thread_advantages)
            returns.insert(0, thread_returns)

        return advantages, returns

    def get_cumulative_reward(self) -> float:
        """Sum of all aggregated rewards across all threads."""
        return sum(sum(thread_score.get_all_rewards(self._aggregator)) for thread_score in self.thread_scores)

    # ── Evaluation-facing methods (preserve raw Grade objects) ───────────

    def get_all_grades_flat(self) -> list[Grade]:
        """Return all individual Grade objects across all threads and turns."""
        return [
            grade
            for thread_score in self.thread_scores
            for grade_list in thread_score.get_all_grades()
            for grade in grade_list
        ]

    def get_grades_by_grader_key(self) -> dict[str, list[Grade]]:
        """Group all grades by their grader_key across the entire trajectory."""
        result: dict[str, list[Grade]] = defaultdict(list)
        for grade in self.get_all_grades_flat():
            result[grade.grader_key].append(grade)
        return dict(result)

    def get_mean_score_per_grader(self) -> dict[str, float]:
        """Compute mean grade value for each grader_key across the trajectory."""
        by_key = self.get_grades_by_grader_key()
        return {key: np.mean([g.value for g in grades]).item() for key, grades in by_key.items()}

    def get_averaged_grades(self) -> list[Grade]:
        """Return one Grade per grader_key with the mean value across the trajectory.

        Useful for evaluation artifacts that expect a single Grade per grader_key
        rather than per-turn grades.
        """
        by_key = self.get_grades_by_grader_key()
        return [
            Grade(value=np.mean([g.value for g in grades]).item(), grader_key=key) for key, grades in by_key.items()
        ]

    def get_grades_per_turn(self) -> list[list[Grade] | None]:
        """Return grades in turn order across all threads (for detailed inspection)."""
        return [grades for thread_score in self.thread_scores for grades in thread_score.grades]


class Environment(ABC):
    """
    Abstract base class for interactive environments that provide feedback to a language model.

    Environments implement the logic for evaluating model outputs, returning Grade objects
    that can be used for both training (aggregated into floats via a GradeAggregator) and
    evaluation (individual grades with grader_keys preserved for per-grader analysis).

    Subclasses must implement the react_to() method.
    """

    def __init__(self, logging_function: Callable):
        """
        Initialize the environment with a logging function.

        Args:
            logging_function: Callable for logging environment events and metrics
        """
        self.logging_function = logging_function

    @abstractmethod
    async def react_to(self, thread: StringThread) -> tuple[StringThread | None, list[Grade] | None]:
        """
        React to the model's latest generation and determine next steps.

        This method is called after each model generation to:
            1. Evaluate the model's output (optionally assigning a reward)
            2. Decide whether to continue the current conversation, terminate the trajectory,
            or move to the next conversation segment with a new prompt
            3. Provide the next thread state if continuing

        Args:
            thread: Current conversation thread including the model's latest generation

        Returns:
            Tuple of (next_thread, grades) where:
            - next_thread: None to terminate trajectory, or StringThread to continue.
              If continuing, can either extend the current thread (append user/tool messages)
              or start a new segment (return a fresh thread with new prompt).
            - grades: List of Grade objects, or None if no grading this turn.
              **IMPORTANT**: When next_thread is None (terminating), grades MUST NOT be None.
              All trajectories must receive at least one set of grades.

         Note:
            The caller will automatically detect whether next_thread is a new segment or
            an extension by checking if the current thread is a prefix of next_thread.

        Raises:
            ValueError: If next_thread is None but reward is also None (enforced by caller)
        """
        pass

    async def initialize_state(self, thread: StringThread) -> StringThread:
        """
        Pre-process the initial thread before starting trajectory generation.

        Override this method to modify the initial prompt, add system messages,
        or perform other setup before the model begins generating.

        Args:
            thread: Initial thread provided to generate_trajectory_and_grade

        Returns:
            Processed thread to use as starting point for generation
        """
        return thread

    async def generate_trajectory_and_grade(
        self,
        model: InferenceModel,
        initial_thread: StringThread,
        aggregator: GradeAggregator = mean_of_grade_values,
    ) -> tuple[list[StringThread], TrajectoryHistory]:
        all_threads: list[StringThread] = []
        current_thread = await self.initialize_state(initial_thread)
        preexisting_assistant_turns = sum(1 for role, _ in current_thread.get_turns() if role == "assistant")
        trajectory_history = TrajectoryHistory(aggregator=aggregator)
        trajectory_history.add_new_thread()

        def is_prefix(prefix_thread: StringThread, full_thread: StringThread) -> bool:
            """Check if prefix_thread is a prefix of full_thread."""
            prefix_turns = prefix_thread.get_turns()
            full_turns = full_thread.get_turns()

            if len(prefix_turns) > len(full_turns):
                return False

            for prefix_turn, full_turn in zip(prefix_turns, full_turns):
                if prefix_turn.role != full_turn.role or prefix_turn.content != full_turn.content:
                    return False

            return True

        while True:
            current_thread = await model.generate(current_thread)

            thread_from_env, grades_from_env = await self.react_to(current_thread)

            trajectory_history.add_turn(grades_from_env)

            if thread_from_env is None:
                if grades_from_env is None:
                    raise ValueError(
                        "Environment terminated trajectory without providing grades. "
                        "All trajectories must receive at least one set of grades to be useful for training. "
                        "If you end without giving grades we do not know what to do with the final assistant turn"
                    )
                all_threads.append(current_thread.with_weight_assistant_turns_from_index(preexisting_assistant_turns))
                return all_threads, trajectory_history
            else:
                is_new_prompt = not is_prefix(current_thread, thread_from_env)

                if is_new_prompt:
                    all_threads.append(
                        current_thread.with_weight_assistant_turns_from_index(preexisting_assistant_turns)
                    )
                    trajectory_history.add_new_thread()
                    preexisting_assistant_turns = sum(
                        1 for role, _ in thread_from_env.get_turns() if role == "assistant"
                    )
                current_thread = thread_from_env


class EnvironmentFactory(ABC):
    """
    Abstract factory for creating Environment instances.

    Each trajectory requires its own unique Environment instance to maintain independent
    state. This factory pattern enables creating multiple environment instances with
    shared configuration while aggregating logs across all created environments.

    Subclasses must implement create_environment() to define how to instantiate
    environment instances from metadata.
    """

    def __init__(self, logging_name: str | None = None):
        """
        Initialize the environment factory with optional logging name.

        Args:
            logging_name: Optional name for identifying logs from this factory
        """
        self._logs: dict[str, list] = defaultdict(list)
        self.logging_name = logging_name

    def add_log(self, key, new_value) -> None:
        """
        Add a log entry to the factory's log collection.

        Environments created by this factory can call this method (via their
        logging_function) to aggregate metrics across all trajectories.

        Args:
            key: Log key/name for grouping related values
            new_value: Value to log (numeric, Table, or other supported type)
        """
        self._logs[key].append(new_value)

    def get_logs(self, clear: bool = False) -> dict[str, float | Table]:
        """
        Get aggregated logs from all environments created by this factory.

        Aggregates logged values based on type:
        - Numeric values: Returns mean across all values
        - Table values: Concatenates all rows into a single table
        - Other types: Raises ValueError

        Args:
            clear: If True, clears logs after retrieval

        Returns:
            Dictionary mapping log keys to aggregated values (float or Table)
        """
        if not self._logs:
            return {}

        logs = {}
        for k, v in self._logs.items():
            if isinstance(v[0], Number):
                logs[k] = np.asarray(v).mean()
            elif isinstance(v[0], Table):
                headers = v[0].headers
                assert all(table.headers == headers for table in v)
                overall_table = Table(headers)
                for table in v:
                    overall_table.add_rows(table.rows)
                logs[k] = overall_table
            else:
                raise ValueError(f"Unknown type: {type(v[0])}")

        if clear:
            self.clear_logs()
        return logs

    def clear_logs(self) -> None:
        """
        Clear all accumulated logs from this factory.

        Useful for resetting metrics between training iterations or evaluation runs.
        """
        self._logs.clear()

    @abstractmethod
    def create_environment(self, metadata: Any) -> Environment:
        """
        Create a new Environment instance for a trajectory.

        Args:
            metadata: Configuration or context data for creating the environment

        Returns:
            New Environment instance with its own independent state
        """
        ...
