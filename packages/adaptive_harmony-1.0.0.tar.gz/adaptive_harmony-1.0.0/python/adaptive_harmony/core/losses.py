import asyncio

import numpy as np

from adaptive_harmony import StringThread, TokenizedThread, TrainingModel


async def train_sft_tangents(model: TrainingModel, thread: StringThread) -> dict:
    """Train with SFT using tangents instead of the built-in train_language_modelling."""
    lp, (tokens, image_tokens, weights) = await asyncio.gather(
        model.logprobs(thread),
        model.serialize_thread(thread),
    )

    inp_tokens = tokens[:-1]
    tgt_tokens = tokens[1:]
    tangents = list(weights[1:])

    await model.train_tangents(inp_tokens, image_tokens, tangents, tgt_tokens)

    num_tokens = sum(weights)
    return {
        "logprob": lp,
        "num_tokens": num_tokens,
        "loss": -lp / num_tokens if num_tokens > 0 else 0.0,
    }


async def train_grpo_tangents(
    model: TrainingModel,
    sample: TokenizedThread,
    trajectory_logprobs: list[float],
    ref_logprobs: list[float],
    advantages: list[float],
    clip_range: float,
    kl_beta: float,
    use_sequence_lps: bool,  # for gspo
):
    """Train with GRPO using tangents instead of the built-in train_grpo."""
    # Get current policy logprobs
    current_logprobs = np.array(await model.logprobs_per_token(sample), dtype=np.float32)
    trajectory_logprobs_arr = np.array(trajectory_logprobs, dtype=np.float32)
    ref_logprobs_arr = np.array(ref_logprobs, dtype=np.float32)
    advantages_arr = np.array(advantages, dtype=np.float32)

    # Compute tangents
    tangents, metrics = grpo_loss(
        logprobs=current_logprobs,
        trajectory_logprobs=trajectory_logprobs_arr,
        reference_logprobs=ref_logprobs_arr,
        advantages=advantages_arr,
        clip_range=clip_range,
        kl_beta=kl_beta,
        use_sequence_lps=use_sequence_lps,
    )

    # Get tokens and weights for train_tangents
    tokens, image_tokens, weights = await model.serialize_tokenized_thread(sample)
    inp_tokens = tokens[:-1]
    tgt_tokens = tokens[1:]
    weights = np.array(weights[1:])

    # Expand tangents to full length using weights mask
    full_tangents = np.zeros_like(weights, dtype=np.float32)
    full_tangents[weights > 0] = tangents

    await model.train_tangents(inp_tokens, image_tokens, full_tangents.tolist(), tgt_tokens)

    return metrics


# note for ppo we just set kl_beta to 0.
def grpo_loss(
    logprobs,  # (seq_len,) per-token log probs from current policy
    trajectory_logprobs,  # (seq_len,) per-token log probs from behavior policy
    reference_logprobs,  # (seq_len,) per-token log probs from reference model
    advantages,  # (seq_len,) per-token advantages
    clip_range,  # scalar, e.g. 0.2
    kl_beta,  # scalar, KL penalty coefficient
    use_sequence_lps=False,  # gspo
):
    if use_sequence_lps:
        logprob_diff = np.mean(logprobs - trajectory_logprobs)
    else:
        logprob_diff = logprobs - trajectory_logprobs

    ratio = np.exp(logprob_diff)

    ref_logratio = reference_logprobs - logprobs
    Dkl = np.exp(ref_logratio) - ref_logratio - 1

    d_Dkl = 1 - np.exp(ref_logratio)

    large_change = np.abs(ratio - 1) > clip_range
    beneficial_change = np.sign(advantages) == np.sign(logprob_diff)

    clipped = large_change * beneficial_change
    d_policy = (1 - clipped) * (-advantages * ratio)

    d_logprobs = d_policy + kl_beta * d_Dkl

    metrics = {
        "pg_clipfrac": np.mean(clipped.astype(float)),
        "inner_kl_div": np.mean(0.5 * (logprobs - trajectory_logprobs) ** 2),
        "Dkl": np.mean(Dkl),
    }

    return -d_logprobs, metrics
