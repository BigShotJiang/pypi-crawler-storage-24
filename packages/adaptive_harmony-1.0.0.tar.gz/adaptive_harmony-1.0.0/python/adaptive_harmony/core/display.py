import textwrap

from rich.console import Console
from rich.table import Table
from rich.text import Text

from adaptive_harmony import StringThread, TokenizedThread


def _stringthread_repr(self: StringThread) -> str:
    """Rich-based __repr__ for StringThread."""
    turns = self.get_turns()
    weights = self.get_turn_weights()

    table = Table(show_header=False, show_edge=False, box=None, padding=(0, 1))
    table.add_column("Role", no_wrap=True, justify="right")
    table.add_column("Content", overflow="fold")

    wrap_width = 90

    for turn, weight in zip(turns, weights):
        trained = weight > 0.0
        if wrap_width > 0 and turn.content:
            wrapped_lines = []
            for line in turn.content.split("\n"):
                if line:
                    wrapped = textwrap.fill(line, width=wrap_width)
                    wrapped_lines.append(wrapped)
                else:
                    wrapped_lines.append("")
            content = "\n".join(wrapped_lines)
        else:
            content = turn.content

        role_style = "bold green" if trained else "bold blue"
        content_style = "green" if trained else ""
        table.add_row(
            Text(turn.role.upper(), style=role_style),
            Text(content, style=content_style),
        )

    from io import StringIO

    buffer = StringIO()
    console = Console(file=buffer, width=120, force_terminal=True)

    max_role_len = max(len(turn.role) for turn in turns) if turns else 0
    total_width = max_role_len + 2 + wrap_width
    separator = "─" * total_width

    buffer.write(separator + "\n")
    console.print(table)
    if self.metadata:
        buffer.write(f"Metadata={self.metadata}\n")
    buffer.write(separator + "\n")

    return buffer.getvalue().rstrip()


def _tokenizedthread_repr(self: TokenizedThread) -> str:
    """Rich-based __repr__ for TokenizedThread."""
    turns = self.get_turns()
    weights = self.get_turn_weights()

    table = Table(show_header=False, show_edge=False, box=None, padding=(0, 1))
    table.add_column("Role", no_wrap=True, justify="right")
    table.add_column("Tokens", overflow="fold")

    for turn, weight in zip(turns, weights):
        tokens_str = " ".join(str(t) for t in turn.content)
        trained = weight > 0.0

        role_style = "bold green" if trained else "bold blue"
        content_style = "green" if trained else ""
        table.add_row(
            Text(turn.role.upper(), style=role_style),
            Text(tokens_str, style=content_style),
        )

    from io import StringIO

    buffer = StringIO()
    console = Console(file=buffer, width=120, force_terminal=True)

    max_role_len = max(len(turn.role) for turn in turns) if turns else 0
    total_width = max_role_len + 2 + 90
    separator = "─" * total_width

    buffer.write(separator + "\n")
    console.print(table)
    buffer.write(separator + "\n")

    return buffer.getvalue().rstrip()
