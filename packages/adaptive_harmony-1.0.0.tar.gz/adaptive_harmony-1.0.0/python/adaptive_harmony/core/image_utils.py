import base64
import html
import io
import os
from pathlib import Path

from PIL import Image

from adaptive_harmony import StringThread


def _resize_if_needed(image: Image.Image, longest_side_max_size: int) -> Image.Image:
    width, height = image.size
    max_dimension = max(width, height)
    if max_dimension > longest_side_max_size:
        scale = longest_side_max_size / max_dimension
        new_size = (int(width * scale), int(height * scale))
        exif = image.getexif()
        exif[0xA002] = width
        exif[0xA003] = height
        image = image.resize(new_size)
        image.info["exif"] = exif.tobytes()
    return image


def pil_to_base64(
    image: Image.Image, format: str = "PNG", longest_side_max_size: int | None = None, black_and_white: bool = False
) -> str:
    if image.mode in ("RGBA", "LA") or (image.mode == "P" and "transparency" in image.info):
        image = image.convert("RGB")

    if longest_side_max_size is not None:
        image = _resize_if_needed(image, longest_side_max_size)

    if black_and_white:
        image = image.convert("L")

    buffered = io.BytesIO()
    image.save(buffered, format=format)
    img_bytes = buffered.getvalue()
    return base64.b64encode(img_bytes).decode("utf-8")


def image_to_base64(
    image_path: str | Path, format: str = "PNG", longest_side_max_size: int | None = None, black_and_white: bool = False
) -> str:
    image = Image.open(image_path)
    return pil_to_base64(
        image, format=format, longest_side_max_size=longest_side_max_size, black_and_white=black_and_white
    )


def save_inlined_string_to_png(image_str: str, path_to_save: str | Path):
    _, base64_str = image_str.split(",")
    image_data = base64.b64decode(base64_str)
    image = Image.open(io.BytesIO(image_data))
    image.save(path_to_save)


def save_string_thread_to_markdown_dir(thread: StringThread, directory_path: str | Path):
    all_fragments = thread.get_fragments()

    os.makedirs(directory_path, exist_ok=True)
    image_counter = 0
    with open(os.path.join(directory_path, "main.md"), "w") as w:
        for role, fragments in all_fragments:
            w.write(f"# {role}\n")
            for fragment in fragments:
                if fragment["type"] == "text":
                    w.write(fragment["text"])
                else:
                    assert fragment["type"] == "image"
                    filename = f"image_{image_counter}.jpeg"
                    image_path = os.path.join(directory_path, filename)
                    save_inlined_string_to_png(fragment["url"], image_path)
                    w.write(f"![image info]({filename})\n")


def string_thread_to_html_string(thread: StringThread) -> str:
    """
    Converts a StringThread into a single, valid HTML string.
    Text is converted to paragraphs, and images are embedded directly
    using their base64 data URIs. Trained turns (weight > 0) are highlighted in green.
    """
    html_parts = []
    all_fragments = thread.get_fragments()
    weights = thread.get_turn_weights()

    for (role, fragments), weight in zip(all_fragments, weights):
        trained = weight > 0.0
        color = "#2e7d32" if trained else "#000000"
        html_parts.append(f'<h2 style="color: {color};">{role.capitalize()}</h2>')
        for fragment in fragments:
            style = f' style="color: {color};"' if trained else ""
            if fragment["type"] == "text":
                text_content = html.escape(fragment["text"])
                html_parts.append(f"<p{style}>{text_content}</p>")
            elif fragment["type"] == "image":
                image_url = fragment["url"]
                border_color = "#2e7d32" if trained else "#ddd"
                html_parts.append(
                    f'<img src="{image_url}" alt="Embedded image content" style="max-width: 500px; height: auto; display: block; margin: 10px 0; border-color: {border_color};">'
                )

    # Combine all parts into a single string
    body_content = "\n".join(html_parts)

    # Wrap the content in a complete, styled HTML document
    return f"""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>StringThread Conversation</title>
    <style>
        body {{
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            line-height: 1.6;
            color: #000000; 
            margin: 20px auto;
            padding: 0 20px;
        }}
        h2 {{
            border-bottom: 2px solid #eee;
            padding-bottom: 10px;
            margin-top: 40px;
            margin-left: 40px;
            width: 600px;
            color: #000000; 
        }}
        p {{
            width: 600px;
            margin: 16px 0;
            margin-left: 40px;
            word-break: break-word; /* Helps with breaking long words if needed */
            white-space: pre-wrap; /* Preserve newlines and wrap long lines */
        }}
        img {{
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 5px;
            background-color: #ffffff; /* Changed to white */
        }}
    </style>
</head>
<body>
    <div style="background-color: #ffffff; width: 680px;">
        <h1>Conversation Thread</h1>
        {body_content}
    </div>
</body>
</html>
"""
