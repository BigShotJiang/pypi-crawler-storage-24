"""
setup.py — NexusLoRA
Eski pip / araçlar için uyumluluk katmanı.
Asıl konfigürasyon pyproject.toml içindedir.
"""
from setuptools import setup

if __name__ == "__main__":
    setup()
