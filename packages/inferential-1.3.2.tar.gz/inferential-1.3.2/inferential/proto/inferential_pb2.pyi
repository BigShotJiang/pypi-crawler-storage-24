from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class DType(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    DTYPE_UNSPECIFIED: _ClassVar[DType]
    FLOAT16: _ClassVar[DType]
    FLOAT32: _ClassVar[DType]
    FLOAT64: _ClassVar[DType]
    BFLOAT16: _ClassVar[DType]
    UINT8: _ClassVar[DType]
    INT32: _ClassVar[DType]
    INT64: _ClassVar[DType]
    BOOL: _ClassVar[DType]

class Encoding(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    ENCODING_UNSPECIFIED: _ClassVar[Encoding]
    RAW: _ClassVar[Encoding]
    JPEG: _ClassVar[Encoding]
    PNG: _ClassVar[Encoding]
DTYPE_UNSPECIFIED: DType
FLOAT16: DType
FLOAT32: DType
FLOAT64: DType
BFLOAT16: DType
UINT8: DType
INT32: DType
INT64: DType
BOOL: DType
ENCODING_UNSPECIFIED: Encoding
RAW: Encoding
JPEG: Encoding
PNG: Encoding

class Client(_message.Message):
    __slots__ = ("id", "type")
    ID_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    id: str
    type: str
    def __init__(self, id: _Optional[str] = ..., type: _Optional[str] = ...) -> None: ...

class Tensor(_message.Message):
    __slots__ = ("key", "dtype", "shape", "byte_offset", "byte_length", "timestamp_ns", "encoding")
    KEY_FIELD_NUMBER: _ClassVar[int]
    DTYPE_FIELD_NUMBER: _ClassVar[int]
    SHAPE_FIELD_NUMBER: _ClassVar[int]
    BYTE_OFFSET_FIELD_NUMBER: _ClassVar[int]
    BYTE_LENGTH_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_NS_FIELD_NUMBER: _ClassVar[int]
    ENCODING_FIELD_NUMBER: _ClassVar[int]
    key: str
    dtype: DType
    shape: _containers.RepeatedScalarFieldContainer[int]
    byte_offset: int
    byte_length: int
    timestamp_ns: int
    encoding: Encoding
    def __init__(self, key: _Optional[str] = ..., dtype: _Optional[_Union[DType, str]] = ..., shape: _Optional[_Iterable[int]] = ..., byte_offset: _Optional[int] = ..., byte_length: _Optional[int] = ..., timestamp_ns: _Optional[int] = ..., encoding: _Optional[_Union[Encoding, str]] = ...) -> None: ...

class Observation(_message.Message):
    __slots__ = ("client", "timestamp_ns", "urgency", "tensors", "model_id", "steps_remaining", "metadata", "priority")
    class MetadataEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    CLIENT_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_NS_FIELD_NUMBER: _ClassVar[int]
    URGENCY_FIELD_NUMBER: _ClassVar[int]
    TENSORS_FIELD_NUMBER: _ClassVar[int]
    MODEL_ID_FIELD_NUMBER: _ClassVar[int]
    STEPS_REMAINING_FIELD_NUMBER: _ClassVar[int]
    METADATA_FIELD_NUMBER: _ClassVar[int]
    PRIORITY_FIELD_NUMBER: _ClassVar[int]
    client: Client
    timestamp_ns: int
    urgency: float
    tensors: _containers.RepeatedCompositeFieldContainer[Tensor]
    model_id: str
    steps_remaining: int
    metadata: _containers.ScalarMap[str, str]
    priority: int
    def __init__(self, client: _Optional[_Union[Client, _Mapping]] = ..., timestamp_ns: _Optional[int] = ..., urgency: _Optional[float] = ..., tensors: _Optional[_Iterable[_Union[Tensor, _Mapping]]] = ..., model_id: _Optional[str] = ..., steps_remaining: _Optional[int] = ..., metadata: _Optional[_Mapping[str, str]] = ..., priority: _Optional[int] = ...) -> None: ...

class ModelResponse(_message.Message):
    __slots__ = ("client", "response_id", "timestamp_ns", "tensors", "inference_latency_ms", "model_id", "metadata")
    class MetadataEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: str
        def __init__(self, key: _Optional[str] = ..., value: _Optional[str] = ...) -> None: ...
    CLIENT_FIELD_NUMBER: _ClassVar[int]
    RESPONSE_ID_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_NS_FIELD_NUMBER: _ClassVar[int]
    TENSORS_FIELD_NUMBER: _ClassVar[int]
    INFERENCE_LATENCY_MS_FIELD_NUMBER: _ClassVar[int]
    MODEL_ID_FIELD_NUMBER: _ClassVar[int]
    METADATA_FIELD_NUMBER: _ClassVar[int]
    client: Client
    response_id: str
    timestamp_ns: int
    tensors: _containers.RepeatedCompositeFieldContainer[Tensor]
    inference_latency_ms: float
    model_id: str
    metadata: _containers.ScalarMap[str, str]
    def __init__(self, client: _Optional[_Union[Client, _Mapping]] = ..., response_id: _Optional[str] = ..., timestamp_ns: _Optional[int] = ..., tensors: _Optional[_Iterable[_Union[Tensor, _Mapping]]] = ..., inference_latency_ms: _Optional[float] = ..., model_id: _Optional[str] = ..., metadata: _Optional[_Mapping[str, str]] = ...) -> None: ...
