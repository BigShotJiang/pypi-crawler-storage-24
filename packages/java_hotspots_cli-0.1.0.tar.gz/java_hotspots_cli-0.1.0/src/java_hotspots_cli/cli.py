from __future__ import annotations

import argparse
import csv
import json
import logging
import math
import os
import subprocess
from collections import defaultdict
from dataclasses import dataclass, asdict
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

import requests

from .i18n import I18N

try:
    import lizard
except ImportError:
    lizard = None

LOGGER = logging.getLogger("java_hotspots_cli")


@dataclass
class FileMetrics:
    repo: str
    path: str
    churn_commits_360d: int = 0
    loc: int = 0
    functions: int = 0
    max_ccn: int = 0
    avg_ccn: float = 0.0
    risk_score: float = 0.0
    llm_summary: str = ""


def configure_logging(level: str) -> None:
    numeric_level = getattr(logging, level.upper(), logging.INFO)
    logging.basicConfig(
        level=numeric_level,
        format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    )


def run_cmd(cmd: list[str], cwd: Optional[str] = None) -> tuple[int, str, str]:
    p = subprocess.Popen(
        cmd, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True
    )
    out, err = p.communicate()
    return p.returncode, out, err


def is_git_repo(path: str) -> bool:
    code, _, _ = run_cmd(["git", "rev-parse", "--is-inside-work-tree"], cwd=path)
    return code == 0


def list_java_files(repo_path: str, exclude_dirs: list[str]) -> list[str]:
    java_files: list[str] = []
    for root, dirs, files in os.walk(repo_path):
        dirs[:] = [
            d for d in dirs if d not in exclude_dirs and not d.startswith(".git")
        ]
        for f in files:
            if f.endswith(".java"):
                full = os.path.join(root, f)
                rel = os.path.relpath(full, repo_path)
                java_files.append(rel)
    return java_files


def compute_churn_commits(repo_path: str, file_rel_path: str, since_days: int) -> int:
    since_date = (datetime.now() - timedelta(days=since_days)).strftime("%Y-%m-%d")
    cmd = [
        "git",
        "log",
        f"--since={since_date}",
        "--pretty=oneline",
        "--",
        file_rel_path,
    ]
    code, out, _ = run_cmd(cmd, cwd=repo_path)
    if code != 0:
        return 0
    return len([ln for ln in out.splitlines() if ln.strip()])


def compute_complexity(
    repo_path: str, file_rel_path: str
) -> tuple[int, int, int, float]:
    if lizard is None:
        return (0, 0, 0, 0.0)

    full_path = os.path.join(repo_path, file_rel_path)
    try:
        analysis = lizard.analyze_file(full_path)
        funcs = analysis.function_list or []
        if not funcs:
            return (analysis.nloc, 0, 0, 0.0)

        ccn_values = [fn.cyclomatic_complexity for fn in funcs]
        return (
            analysis.nloc,
            len(funcs),
            max(ccn_values),
            sum(ccn_values) / len(ccn_values),
        )
    except Exception as exc:
        LOGGER.warning("Complexity analysis failed for %s: %s", full_path, exc)
        return (0, 0, 0, 0.0)


def normalize(values: list[float]) -> list[float]:
    if not values:
        return []
    mn = min(values)
    mx = max(values)
    if math.isclose(mx, mn):
        return [0.0 for _ in values]
    return [(v - mn) / (mx - mn) for v in values]


def compute_risk_scores(
    items: list[FileMetrics], w_complexity: float, w_churn: float
) -> None:
    if not items:
        return

    churns = [float(x.churn_commits_360d) for x in items]
    complexities = [float(x.max_ccn) for x in items]

    n_churn = normalize(churns)
    n_comp = normalize(complexities)

    for i, fm in enumerate(items):
        fm.risk_score = (w_complexity * n_comp[i]) + (w_churn * n_churn[i])


def call_completion_api(
    class_code: str,
    t,
    model: str,
    temperature: float = 0.2,
    max_tokens: int = 512,
) -> str | None:
    url = os.getenv("LITELLM_COMPLETION_URL", "http://localhost:11434/v1/completions")
    api_key = os.getenv("LITELLM_API_KEY", "")
    certificate_path = os.getenv("SSL_CERT_FILE")

    headers = {"Content-Type": "application/json"}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"

    prompt = t("llm_completion_prompt", code=class_code[:4000])
    data = {
        "model": model,
        "prompt": prompt,
        "temperature": temperature,
        "max_tokens": max_tokens,
        "stream": False,
    }

    response = None
    try:
        verify = certificate_path if certificate_path else True
        response = requests.post(
            url, headers=headers, data=json.dumps(data), verify=verify, timeout=90
        )
        response.raise_for_status()
        payload = response.json()
        choices = payload.get("choices", [])
        if choices:
            return (choices[0].get("text") or "").strip()

        LOGGER.error(t("error_no_choices"))
        return None
    except requests.exceptions.RequestException as exc:
        LOGGER.error(t("error_calling_api", error=exc))
        if response is not None:
            LOGGER.debug(t("response_content", content=response.text))
        return None
    except json.JSONDecodeError as exc:
        LOGGER.error(t("error_decoding_json", error=exc))
        if response is not None:
            LOGGER.debug(t("response_content", content=response.text))
        return None


def package_of(path: str, t) -> str:
    parts = path.split(os.sep)
    if len(parts) <= 1:
        return t("root")
    return parts[0]


def write_markdown_report(
    path: Path,
    all_rows: list[FileMetrics],
    filtered_rows: list[FileMetrics],
    top_n: int,
    since_days: int,
    min_ccn: int,
    min_churn: int,
    t,
) -> None:
    all_sorted = sorted(all_rows, key=lambda x: x.risk_score, reverse=True)
    filtered_sorted = sorted(filtered_rows, key=lambda x: x.risk_score, reverse=True)
    top = filtered_sorted[:top_n]

    pkg_stats: dict[str, list[float]] = defaultdict(list)
    for r in filtered_sorted:
        pkg_stats[package_of(r.path, t)].append(r.risk_score)

    pkg_summary = [
        (pkg, sum(vals) / len(vals), len(vals)) for pkg, vals in pkg_stats.items()
    ]
    pkg_summary.sort(key=lambda x: x[1], reverse=True)

    with open(path, "w", encoding="utf-8") as f:
        f.write(f"# {t('app_title')}\n\n")
        f.write(
            f"**{t('generated_at')}:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n"
        )

        f.write(f"## {t('section_1')}\n\n")
        f.write(f"- {t('analysis_window')}: {t('last_n_days', days=since_days)}\n")
        f.write(f"- {t('total_java_files')}: **{len(all_rows)}**\n")
        f.write(f"- {t('risky_files')}: **{len(filtered_rows)}**\n")
        f.write(f"- {t('min_complexity_threshold')}: **{min_ccn}**\n")
        f.write(f"- {t('min_churn_threshold')}: **{min_churn} {t('commits')}**\n\n")

        if filtered_rows:
            top1 = filtered_sorted[0]
            f.write(f"### {t('most_critical_file')}\n\n")
            f.write(
                "- "
                + t(
                    "critical_file_line",
                    path=top1.path,
                    risk=top1.risk_score,
                    churn=top1.churn_commits_360d,
                    max_ccn=top1.max_ccn,
                )
                + "\n\n"
            )

        f.write(f"## {t('section_2')}\n\n")
        f.write(
            f"| # | {t('repo')} | {t('file')} | {t('churn')} | {t('loc')} | "
            f"{t('functions')} | {t('max_ccn')} | {t('avg_ccn')} | {t('risk')} |\n"
        )
        f.write("|---:|---|---|---:|---:|---:|---:|---:|---:|\n")
        for i, r in enumerate(top, 1):
            f.write(
                f"| {i} | {r.repo} | `{r.path}` | {r.churn_commits_360d} | "
                f"{r.loc} | {r.functions} | {r.max_ccn} | "
                f"{r.avg_ccn:.1f} | {r.risk_score:.3f} |\n"
            )
        f.write("\n")

        if pkg_summary:
            f.write(f"## {t('section_3')}\n\n")
            f.write(f"| {t('package')} | {t('average_risk')} | {t('file_count')} |\n")
            f.write("|---|---:|---:|\n")
            for pkg, avg_risk, count in pkg_summary[:20]:
                f.write(f"| `{pkg}` | {avg_risk:.3f} | {count} |\n")
            f.write("\n")

        llm_rows = [x for x in top if x.llm_summary]
        if llm_rows:
            f.write(f"## {t('section_4')}\n\n")
            for r in llm_rows:
                f.write(f"### `{r.path}`\n\n{r.llm_summary}\n\n")

        f.write(f"## {t('section_5')}\n\n")
        f.write(
            f"| {t('repo')} | {t('file')} | {t('churn')} | {t('loc')} | "
            f"{t('functions')} | {t('max_ccn')} | {t('avg_ccn')} | {t('risk')} |\n"
        )
        f.write("|---|---|---:|---:|---:|---:|---:|---:|\n")
        for r in all_sorted:
            f.write(
                f"| {r.repo} | `{r.path}` | {r.churn_commits_360d} | "
                f"{r.loc} | {r.functions} | {r.max_ccn} | "
                f"{r.avg_ccn:.1f} | {r.risk_score:.3f} |\n"
            )


def write_csv_report(path: Path, rows: list[FileMetrics]) -> None:
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=[
                "repo",
                "path",
                "churn_commits_360d",
                "loc",
                "functions",
                "max_ccn",
                "avg_ccn",
                "risk_score",
                "llm_summary",
            ],
        )
        writer.writeheader()
        for row in sorted(rows, key=lambda x: x.risk_score, reverse=True):
            writer.writerow(asdict(row))


def write_json_report(
    path: Path, rows: list[FileMetrics], filtered_rows: list[FileMetrics], args
) -> None:
    payload = {
        "generated_at": datetime.now().isoformat(),
        "parameters": {
            "repos": args.repos,
            "since_days": args.since_days,
            "min_ccn": args.min_ccn,
            "min_churn": args.min_churn,
            "top_n": args.top_n,
            "lang": args.lang,
            "ollama": args.ollama,
        },
        "summary": {
            "total_files": len(rows),
            "filtered_files": len(filtered_rows),
        },
        "rows": [
            asdict(r) for r in sorted(rows, key=lambda x: x.risk_score, reverse=True)
        ],
    }
    with open(path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2, ensure_ascii=False)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(prog="java-hotspots")
    parser.add_argument(
        "--repos", nargs="+", required=True, help="One or more Git repository paths"
    )
    parser.add_argument("--since-days", type=int, default=360)
    parser.add_argument("--min-ccn", type=int, default=15)
    parser.add_argument("--min-churn", type=int, default=10)
    parser.add_argument("--top-n", type=int, default=30)
    parser.add_argument("--lang", choices=["en", "tr"], default="en")
    parser.add_argument(
        "--out",
        default="output/java_hotspots",
        help="Output base path without extension",
    )
    parser.add_argument(
        "--ollama", action="store_true", help="Call completion API for top risky files"
    )
    parser.add_argument(
        "--ollama-model", default="Qwen3-Coder-30B-A3B-Instruct-lao01vllm"
    )
    parser.add_argument(
        "--log-level",
        default="INFO",
        choices=["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"],
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    configure_logging(args.log_level)

    i18n = I18N(args.lang)
    t = i18n.t

    all_metrics: list[FileMetrics] = []
    repo_paths = [os.path.abspath(repo) for repo in args.repos]
    repo_lookup = {os.path.basename(rp): rp for rp in repo_paths}

    for repo in repo_paths:
        if not is_git_repo(repo):
            LOGGER.warning(t("invalid_git_repo", repo=repo))
            continue

        repo_name = os.path.basename(repo)
        java_files = list_java_files(repo, ["target", "build", "out"])
        LOGGER.info(t("found_java_files", count=len(java_files)))

        for rel in java_files:
            churn = compute_churn_commits(repo, rel, args.since_days)
            loc, fn, max_ccn, avg_ccn = compute_complexity(repo, rel)

            all_metrics.append(
                FileMetrics(
                    repo=repo_name,
                    path=rel,
                    churn_commits_360d=churn,
                    loc=loc,
                    functions=fn,
                    max_ccn=max_ccn,
                    avg_ccn=avg_ccn,
                )
            )

    compute_risk_scores(all_metrics, 0.6, 0.4)

    filtered = [
        x
        for x in all_metrics
        if x.max_ccn >= args.min_ccn and x.churn_commits_360d >= args.min_churn
    ]

    if args.ollama:
        for r in filtered[: args.top_n]:
            repo_root = repo_lookup.get(r.repo)
            if not repo_root:
                continue
            try:
                with open(
                    os.path.join(repo_root, r.path),
                    "r",
                    encoding="utf-8",
                    errors="ignore",
                ) as f:
                    code = f.read()
                r.llm_summary = (
                    call_completion_api(
                        class_code=code,
                        t=t,
                        model=args.ollama_model,
                    )
                    or ""
                )
            except Exception as exc:
                LOGGER.warning("LLM summary failed for %s: %s", r.path, exc)

    out_base = Path(args.out)
    out_base.parent.mkdir(parents=True, exist_ok=True)

    md_path = out_base.with_suffix(".md")
    csv_path = out_base.with_suffix(".csv")
    json_path = out_base.with_suffix(".json")

    write_markdown_report(
        path=md_path,
        all_rows=all_metrics,
        filtered_rows=filtered,
        top_n=args.top_n,
        since_days=args.since_days,
        min_ccn=args.min_ccn,
        min_churn=args.min_churn,
        t=t,
    )
    write_csv_report(csv_path, all_metrics)
    write_json_report(json_path, all_metrics, filtered, args)

    LOGGER.info(t("report_written", path=str(md_path)))
    LOGGER.info("CSV report written -> %s", csv_path)
    LOGGER.info("JSON report written -> %s", json_path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
