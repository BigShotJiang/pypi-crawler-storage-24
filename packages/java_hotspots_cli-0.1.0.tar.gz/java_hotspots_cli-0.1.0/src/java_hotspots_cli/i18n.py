from __future__ import annotations

import json
from pathlib import Path

try:
    import yaml  # type: ignore
except Exception:
    yaml = None

DEFAULT_LANG = "en"


class I18N:
    def __init__(self, lang: str = DEFAULT_LANG, translations_dir: str | Path | None = None):
        self.lang = lang or DEFAULT_LANG
        self.translations_dir = Path(translations_dir) if translations_dir else Path(__file__).parent / "translations"
        self.default_translations = self._load_language(DEFAULT_LANG)
        self.translations = self._load_language(self.lang)

    def _load_language(self, lang: str) -> dict:
        json_path = self.translations_dir / f"{lang}.json"
        yaml_path = self.translations_dir / f"{lang}.yaml"
        yml_path = self.translations_dir / f"{lang}.yml"

        if json_path.exists():
            with open(json_path, "r", encoding="utf-8") as f:
                return json.load(f)

        for path in (yaml_path, yml_path):
            if path.exists():
                if yaml is None:
                    raise RuntimeError(
                        f"YAML translation file found for '{lang}' but PyYAML is not installed."
                    )
                with open(path, "r", encoding="utf-8") as f:
                    return yaml.safe_load(f) or {}

        if lang == DEFAULT_LANG:
            return {}
        return self.default_translations.copy()

    def t(self, key: str, **kwargs) -> str:
        text = self.translations.get(key, self.default_translations.get(key, key))
        try:
            return text.format(**kwargs)
        except Exception:
            return text
