"""Constants for foundation schema."""

# Color mapping from old foundation
DEFAULT_COLORS = {
    "red": [1, 0, 0],
    "green": [0, 1, 0],
    "blue": [0, 0, 1],
    "yellow": [1, 1, 0],
    "cyan": [0, 1, 1],
    "magenta": [1, 0, 1],
    "black": [0, 0, 0],
    "white": [1, 1, 1],
    "grey": [0.5, 0.5, 0.5],
    "orange": [1, 0.5, 0],
    "purple": [0.5, 0, 0.5],
    "brown": [0.5, 0.25, 0],
    "pink": [1, 0.75, 0.8],
    "light_blue": [0.68, 0.85, 0.9],
    "light_green": [0.56, 0.93, 0.56],
    "dark_green": [0, 0.39, 0],
    "dark_grey": [0.25, 0.25, 0.25],
    "light_grey": [0.75, 0.75, 0.75],
    "dark_red": [0.5, 0, 0],
    "dark_blue": [0, 0, 0.5],
    "dark_yellow": [0.5, 0.5, 0],
    "dark_cyan": [0, 0.5, 0.5],
    "dark_magenta": [0.5, 0, 0.5],
    "dark_orange": [1, 0.5, 0],
    "dark_purple": [0.5, 0, 0.5],
    "dark_brown": [0.25, 0.12, 0],
    "dark_pink": [1, 0.75, 0.8],
    "beige": [0.96, 0.96, 0.86],
    "plywood": [0.73, 0.54, 0.38],
}

# Valid types for DAG serialization
DEFAULT_VALID_TYPES = [
    "Part",
    "Assembly",
    "Extrusion",
    "Sketch",
    "Point",
    "Plane",
    "Frame",
    "Line",
    "FloatParameter",
    "IntParameter",
    "BoolParameter",
    "StringParameter",
    "SketchOrigin",
    "PartRoot",
    "AssemblyRoot",
    "Circle",
    "Rectangle",
    "Square",
    "Polygon",
    "Hole",
    "Material",
    "Ellipse",
    "Lathe",
    "Axis",
    "Hexagon",
    "Fillet",
    "Chamfer",
    "Loft",
    "Shell",
    "CustomClosedShape",
    "Arc",
    "SVGShape",
    "Helix3D",
    "Sweep",
    "Point3D",
]

DEFAULT_TYPE_REGISTRY = {
    type_name: i for i, type_name in enumerate[str](DEFAULT_VALID_TYPES)
}  # we use the type_registry to get the valid types

# Plane configurations: maps plane name to (xDir, normal) vectors

PLANES_CONFIG = {
    "xy": ([1, 0, 0], [0, 0, 1]),
    "yx": ([0, 1, 0], [0, 0, -1]),
    "xz": ([1, 0, 0], [0, -1, 0]),
    "zx": ([0, 0, 1], [0, 1, 0]),
    "yz": ([0, 1, 0], [1, 0, 0]),
    "zy": ([0, 0, 1], [-1, 0, 0]),
}
