from __future__ import annotations
from typing import List, Optional, Any, Dict, Union, Iterable
from pydantic import BaseModel, Field, model_validator
from ..runtime import Computable, _eval_expr, run_method
from cadbuildr.foundation.mixin.sketch_mixin import SketchElementMixin
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .float_parameter import FloatParameter
    from .point import Point
    from .sketch import Sketch


class Arc(SketchElementMixin, BaseModel, Computable):
    """Generated from GraphQL object Arc."""

    # --- Positional-argument constructor shim --------------------- #
    def __init__(self, *args, **kwargs):
        """
        Allow instantiation like  SugarAmount(12.5)  or  SugarAmount("12.5").
        If both positional *and* keyword data are supplied we keep Pydantic's
        normal rules: positional is ignored and Pydantic will raise.
        """
        from ..runtime.init_helpers import _init_with_cast

        use_normal, processed_kwargs = _init_with_cast(
            self.__class__,
            args,
            kwargs,
            cast_info=None,
            field_order=["p1", "p2", "p3"],
            list_fields=None,
        )
        if use_normal:
            super().__init__(*args, **kwargs)
        else:
            super().__init__(**processed_kwargs)

    @staticmethod
    def from_two_points_and_radius(p1, p2, radius) -> Optional[Arc]:
        # Build local namespace with parameters for static method
        _locals = {"p1": p1, "p2": p2, "radius": radius}
        return _eval_expr(
            None,
            "ArcFromTwoPointsAndRadius(p1=p1, p2=p2, radius=radius, sketch=p1.sketch).expand()",
            _locals,
        )

    def translate(self, dx: float, dy: float) -> Optional[Arc]:
        # Build local namespace with parameters for method function
        _locals = {"dx": dx, "dy": dy}
        return run_method(self, "arc_translate", _locals)

    def rotate(self, angle: float, center: Optional[Point] = None) -> Optional[Arc]:
        # Build local namespace with parameters for method function
        _locals = {"angle": angle, "center": center}
        return run_method(self, "arc_rotate", _locals)

    def tangent(self) -> Optional[List[float]]:
        return run_method(self, "arc_tangent")

    p1: Point = Field(...)
    p2: Point = Field(...)
    p3: Point = Field(...)
    sketch: Optional[Sketch] = Field(
        default=None, json_schema_extra={"compute": {"expr": "p1.sketch"}}
    )

    model_config = {"protected_namespaces": (), "extra": "allow"}  # Pydantic v2 config
