from __future__ import annotations
from typing import List, Optional, Any, Dict, Union, Iterable
from pydantic import BaseModel, Field, model_validator
from ..runtime import _eval_expr, run_method
from cadbuildr.foundation.mixin.sketch_mixin import SketchElementMixin
from cadbuildr.foundation.gen.runtime.parameter_fields_mixin import ParameterFieldsMixin
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .float_parameter import FloatParameter
    from .sketch import Sketch


class Point(SketchElementMixin, ParameterFieldsMixin, BaseModel):
    """Generated from GraphQL object Point."""

    # --- Positional-argument constructor shim --------------------- #
    def __init__(self, *args, **kwargs):
        """
        Allow instantiation like  SugarAmount(12.5)  or  SugarAmount("12.5").
        If both positional *and* keyword data are supplied we keep Pydantic's
        normal rules: positional is ignored and Pydantic will raise.
        """
        from ..runtime.init_helpers import _init_with_cast

        use_normal, processed_kwargs = _init_with_cast(
            self.__class__,
            args,
            kwargs,
            cast_info=None,
            field_order=["sketch", "x", "y"],
            list_fields=None,
        )
        if use_normal:
            super().__init__(*args, **kwargs)
        else:
            super().__init__(**processed_kwargs)

    @staticmethod
    def midpoint(p1, p2) -> Optional[Point]:
        return run_method(None, "point_midpoint")

    @staticmethod
    def distance_between_points(p1, p2) -> Optional[float]:
        return run_method(None, "point_distance_between_points")

    def translate(self, dx: float, dy: float) -> Optional[Point]:
        # Build local namespace with parameters for method function
        _locals = {"dx": dx, "dy": dy}
        return run_method(self, "point_translate", _locals)

    def rotate(self, angle: float, center: Optional[Point] = None) -> Optional[Point]:
        # Build local namespace with parameters for method function
        _locals = {"angle": angle, "center": center}
        return run_method(self, "point_rotate", _locals)

    sketch: Sketch = Field(...)
    x: FloatParameter = Field(...)
    y: FloatParameter = Field(...)

    model_config = {"protected_namespaces": ()}  # Pydantic v2 config
