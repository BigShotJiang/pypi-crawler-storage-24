from __future__ import annotations
from typing import List, Optional, Any, Dict, Union, Iterable
from pydantic import BaseModel, Field, model_validator
from ..runtime import Computable, _eval_expr, run_method
from cadbuildr.foundation.mixin.sketch_mixin import SketchElementMixin
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .line import Line
    from .point import Point
    from .sketch import Sketch


class Polygon(SketchElementMixin, BaseModel, Computable):
    """Generated from GraphQL object Polygon."""

    # --- Positional-argument constructor shim --------------------- #
    def __init__(self, *args, **kwargs):
        """
        Allow instantiation like  SugarAmount(12.5)  or  SugarAmount("12.5").
        If both positional *and* keyword data are supplied we keep Pydantic's
        normal rules: positional is ignored and Pydantic will raise.
        """
        from ..runtime.init_helpers import _init_with_cast

        use_normal, processed_kwargs = _init_with_cast(
            self.__class__,
            args,
            kwargs,
            cast_info=None,
            field_order=["lines"],
            list_fields={"lines"},
        )
        if use_normal:
            super().__init__(*args, **kwargs)
        else:
            super().__init__(**processed_kwargs)

    def translate(self, dx: float, dy: float) -> Optional[Polygon]:
        # Build local namespace with parameters for method function
        _locals = {"dx": dx, "dy": dy}
        return run_method(self, "polygon_translate", _locals)

    def rotate(self, angle: float, center: Optional[Point] = None) -> Optional[Polygon]:
        # Build local namespace with parameters for method function
        _locals = {"angle": angle, "center": center}
        return run_method(self, "polygon_rotate", _locals)

    lines: List[Line] = Field(...)
    sketch: Optional[Sketch] = Field(
        default=None,
        json_schema_extra={"compute": {"expr": "lines[0].sketch if lines else None"}},
    )

    model_config = {"protected_namespaces": (), "extra": "allow"}  # Pydantic v2 config
