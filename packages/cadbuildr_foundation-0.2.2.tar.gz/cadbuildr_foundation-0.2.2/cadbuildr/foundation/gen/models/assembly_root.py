from __future__ import annotations
from typing import List, Optional, Any, Dict, Union, Iterable
from pydantic import BaseModel, Field, model_validator
from cadbuildr.foundation.gen.runtime.parameter_fields_mixin import ParameterFieldsMixin
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .frame import Frame
    from .material import Material
    from .string_parameter import StringParameter
    from .unions import ComponentRoot


class AssemblyRoot(ParameterFieldsMixin, BaseModel):
    """Generated from GraphQL object AssemblyRoot."""

    frame: Frame = Field(...)
    name: StringParameter = Field(...)
    components: List[ComponentRoot] = Field(...)
    material: Optional[Material] = Field(default=None)

    model_config = {"protected_namespaces": ()}  # Pydantic v2 config
