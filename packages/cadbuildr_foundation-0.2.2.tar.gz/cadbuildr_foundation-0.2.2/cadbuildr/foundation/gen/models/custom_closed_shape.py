from __future__ import annotations
from typing import List, Optional, Any, Dict, Union, Iterable
from pydantic import BaseModel, Field, model_validator
from ..runtime import Computable, _eval_expr, run_method
from cadbuildr.foundation.mixin.sketch_mixin import SketchElementMixin
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .point import Point
    from .sketch import Sketch
    from .unions import BoundaryElement2D


class CustomClosedShape(SketchElementMixin, BaseModel, Computable):
    """Generated from GraphQL object CustomClosedShape."""

    # --- Positional-argument constructor shim --------------------- #
    def __init__(self, *args, **kwargs):
        """
        Allow instantiation like  SugarAmount(12.5)  or  SugarAmount("12.5").
        If both positional *and* keyword data are supplied we keep Pydantic's
        normal rules: positional is ignored and Pydantic will raise.
        """
        from ..runtime.init_helpers import _init_with_cast

        use_normal, processed_kwargs = _init_with_cast(
            self.__class__,
            args,
            kwargs,
            cast_info=None,
            field_order=["primitives"],
            list_fields={"primitives"},
        )
        if use_normal:
            super().__init__(*args, **kwargs)
        else:
            super().__init__(**processed_kwargs)

    def translate(self, dx: float, dy: float) -> Optional[CustomClosedShape]:
        # Build local namespace with parameters for method function
        _locals = {"dx": dx, "dy": dy}
        return run_method(self, "custom_closed_shape_translate", _locals)

    def rotate(
        self, angle: float, center: Optional[Point] = None
    ) -> Optional[CustomClosedShape]:
        # Build local namespace with parameters for method function
        _locals = {"angle": angle, "center": center}
        return run_method(self, "custom_closed_shape_rotate", _locals)

    primitives: List[BoundaryElement2D] = Field(...)
    sketch: Optional[Sketch] = Field(
        default=None,
        json_schema_extra={
            "compute": {"expr": "primitives[0].sketch if primitives else None"}
        },
    )

    model_config = {"protected_namespaces": (), "extra": "allow"}  # Pydantic v2 config
