from __future__ import annotations
from typing import List, Optional, Any, Dict, Union, Iterable
from pydantic import BaseModel, Field, model_validator
from ..runtime import Computable, Expandable, _eval_expr, run_method
from cadbuildr.foundation.mixin.sketch_mixin import SketchElementMixin
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .float_parameter import FloatParameter
    from .line import Line
    from .point import Point
    from .polygon import Polygon
    from .sketch import Sketch


class Square(SketchElementMixin, BaseModel, Computable, Expandable):
    """Generated from GraphQL object Square."""

    # --- Positional-argument constructor shim --------------------- #
    def __init__(self, *args, **kwargs):
        """
        Allow instantiation like  SugarAmount(12.5)  or  SugarAmount("12.5").
        If both positional *and* keyword data are supplied we keep Pydantic's
        normal rules: positional is ignored and Pydantic will raise.
        """
        from ..runtime.init_helpers import _init_with_cast

        use_normal, processed_kwargs = _init_with_cast(
            self.__class__,
            args,
            kwargs,
            cast_info=None,
            field_order=["p1", "p2", "p3", "p4"],
            list_fields={"lines"},
        )
        if use_normal:
            super().__init__(*args, **kwargs)
        else:
            super().__init__(**processed_kwargs)

    @staticmethod
    def from_center_and_side(center, size) -> Optional[Square]:
        # Build local namespace with parameters for static method
        _locals = {"center": center, "size": size}
        return _eval_expr(
            None,
            "SquareFromCenterAndSide(center=center, size=size, sketch=center.sketch).expand()",
            _locals,
        )

    def get_points(self) -> Optional[List[Point]]:
        # Build local namespace with parameters for instance method
        _locals = None
        return _eval_expr(self, "[p1, p2, p3, p4]", _locals)

    p1: Point = Field(...)
    p2: Point = Field(...)
    p3: Point = Field(...)
    p4: Point = Field(...)
    sketch: Optional[Sketch] = Field(
        default=None, json_schema_extra={"compute": {"expr": "p1.sketch"}}
    )
    lines: Optional[List[Line]] = Field(
        default=None,
        json_schema_extra={
            "compute": {
                "expr": "[Line(p1=p1, p2=p2), Line(p1=p2, p2=p3), Line(p1=p3, p2=p4), Line(p1=p4, p2=p1)]",
                "includeInDag": True,
            }
        },
    )
    result: Optional[Polygon] = Field(
        default=None, json_schema_extra={"expand": {"into": {"lines": "$lines"}}}
    )

    model_config = {"protected_namespaces": (), "extra": "allow"}  # Pydantic v2 config
