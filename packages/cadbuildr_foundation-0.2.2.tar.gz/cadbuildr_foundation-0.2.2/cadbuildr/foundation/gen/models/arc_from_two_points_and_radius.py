from __future__ import annotations
from typing import List, Optional, Any, Dict, Union, Iterable
from pydantic import BaseModel, Field, model_validator
from ..runtime import Computable, Expandable, _eval_expr, run_method
from cadbuildr.foundation.gen.runtime.parameter_fields_mixin import ParameterFieldsMixin
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .arc import Arc
    from .float_parameter import FloatParameter
    from .point import Point
    from .sketch import Sketch


class ArcFromTwoPointsAndRadius(
    ParameterFieldsMixin, BaseModel, Computable, Expandable
):
    """Generated from GraphQL object ArcFromTwoPointsAndRadius."""

    # --- Positional-argument constructor shim --------------------- #
    def __init__(self, *args, **kwargs):
        """
        Allow instantiation like  SugarAmount(12.5)  or  SugarAmount("12.5").
        If both positional *and* keyword data are supplied we keep Pydantic's
        normal rules: positional is ignored and Pydantic will raise.
        """
        from ..runtime.init_helpers import _init_with_cast

        use_normal, processed_kwargs = _init_with_cast(
            self.__class__,
            args,
            kwargs,
            cast_info=None,
            field_order=["p1", "p2", "radius", "sketch"],
            list_fields=None,
        )
        if use_normal:
            super().__init__(*args, **kwargs)
        else:
            super().__init__(**processed_kwargs)

    p1: Point = Field(...)
    p2: Point = Field(...)
    radius: FloatParameter = Field(...)
    sketch: Sketch = Field(...)
    control_point: Optional[Point] = Field(
        default=None, json_schema_extra={"compute": {"fn": "compute_arc_control_point"}}
    )
    result: Optional[Arc] = Field(
        default=None,
        json_schema_extra={
            "expand": {"into": {"p1": "$p1", "p2": "$control_point", "p3": "$p2"}}
        },
    )

    model_config = {"protected_namespaces": (), "extra": "allow"}  # Pydantic v2 config
