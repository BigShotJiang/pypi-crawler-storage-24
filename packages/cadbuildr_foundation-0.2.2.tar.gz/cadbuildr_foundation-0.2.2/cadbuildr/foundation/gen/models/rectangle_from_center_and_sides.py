from __future__ import annotations
from typing import List, Optional, Any, Dict, Union, Iterable
from pydantic import BaseModel, Field, model_validator
from ..runtime import Computable, Expandable, _eval_expr, run_method
from cadbuildr.foundation.mixin.sketch_mixin import SketchElementMixin
from cadbuildr.foundation.gen.runtime.parameter_fields_mixin import ParameterFieldsMixin
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .float_parameter import FloatParameter
    from .point import Point
    from .rectangle import Rectangle
    from .sketch import Sketch


class RectangleFromCenterAndSides(
    SketchElementMixin, ParameterFieldsMixin, BaseModel, Computable, Expandable
):
    """Generated from GraphQL object RectangleFromCenterAndSides."""

    # --- Positional-argument constructor shim --------------------- #
    def __init__(self, *args, **kwargs):
        """
        Allow instantiation like  SugarAmount(12.5)  or  SugarAmount("12.5").
        If both positional *and* keyword data are supplied we keep Pydantic's
        normal rules: positional is ignored and Pydantic will raise.
        """
        from ..runtime.init_helpers import _init_with_cast

        use_normal, processed_kwargs = _init_with_cast(
            self.__class__,
            args,
            kwargs,
            cast_info=None,
            field_order=["center", "length", "width", "sketch"],
            list_fields=None,
        )
        if use_normal:
            super().__init__(*args, **kwargs)
        else:
            super().__init__(**processed_kwargs)

    center: Point = Field(...)
    length: FloatParameter = Field(...)
    width: FloatParameter = Field(...)
    sketch: Sketch = Field(...)
    p1: Optional[Point] = Field(
        default=None,
        json_schema_extra={
            "compute": {
                "expr": "Point(sketch=sketch, x=FloatParameter(value=center.x.value - length.value / 2), y=FloatParameter(value=center.y.value - width.value / 2))"
            }
        },
    )
    p2: Optional[Point] = Field(
        default=None,
        json_schema_extra={
            "compute": {
                "expr": "Point(sketch=sketch, x=FloatParameter(value=center.x.value + length.value / 2), y=FloatParameter(value=center.y.value - width.value / 2))"
            }
        },
    )
    p3: Optional[Point] = Field(
        default=None,
        json_schema_extra={
            "compute": {
                "expr": "Point(sketch=sketch, x=FloatParameter(value=center.x.value + length.value / 2), y=FloatParameter(value=center.y.value + width.value / 2))"
            }
        },
    )
    p4: Optional[Point] = Field(
        default=None,
        json_schema_extra={
            "compute": {
                "expr": "Point(sketch=sketch, x=FloatParameter(value=center.x.value - length.value / 2), y=FloatParameter(value=center.y.value + width.value / 2))"
            }
        },
    )
    result: Optional[Rectangle] = Field(
        default=None,
        json_schema_extra={
            "expand": {"into": {"p1": "$p1", "p2": "$p2", "p3": "$p3", "p4": "$p4"}}
        },
    )

    model_config = {"protected_namespaces": (), "extra": "allow"}  # Pydantic v2 config
