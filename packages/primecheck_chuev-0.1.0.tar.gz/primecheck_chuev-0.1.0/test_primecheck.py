import pytest
import primecheck_chuev

def test_is_prime_basic():
    assert primecheck_chuev.is_prime(2) == True
    assert primecheck_chuev.is_prime(3) == True
    assert primecheck_chuev.is_prime(17) == True

def test_is_not_prime():
    assert primecheck_chuev.is_prime(0) == False
    assert primecheck_chuev.is_prime(1) == False
    assert primecheck_chuev.is_prime(4) == False
    assert primecheck_chuev.is_prime(100) == False

def test_primes_up_to():
    assert primecheck_chuev.primes_up_to(10) == [2, 3, 5, 7]
    assert primecheck_chuev.primes_up_to(2) == [2]
    assert primecheck_chuev.primes_up_to(1) == []

def test_large_prime():
    assert primecheck_chuev.is_prime(999983) == True

def test_large_not_prime():
    assert primecheck_chuev.is_prime(999981) == False