"""
Soflytics — Zero-config data quality for humans.

Usage:
    import soflytics
    report = soflytics.audit(df)
    report.show()
"""

__version__ = "0.1.0"

from soflytics.core import audit

__all__ = ["audit", "__version__"]
