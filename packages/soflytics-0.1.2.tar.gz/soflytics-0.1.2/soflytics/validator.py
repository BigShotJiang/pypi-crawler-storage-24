"""
Validation runner — execute rules against data and collect results.
"""

import re
from typing import List

import pandas as pd

from soflytics.profiler.stats import PATTERNS
from soflytics.rules.models import Rule, RuleType, RuleResult, ValidationResult


def validate(df: pd.DataFrame, rules: List[Rule]) -> ValidationResult:
    """
    Execute a list of rules against a DataFrame and return aggregated results.
    """
    result = ValidationResult()
    enabled_rules = [r for r in rules if r.enabled]
    result.total_rules = len(enabled_rules)

    for rule in enabled_rules:
        rule_result = _execute_rule(df, rule)
        result.results.append(rule_result)

        if rule_result.passed:
            result.passed_count += 1
        else:
            result.failed_count += 1

    # Calculate health score based on pass ratio
    if result.total_rules > 0:
        result.health_score = round((result.passed_count / result.total_rules) * 100, 1)
    else:
        result.health_score = 100.0

    # Grade
    if result.health_score >= 90:
        result.health_grade = "A"
    elif result.health_score >= 80:
        result.health_grade = "B"
    elif result.health_score >= 70:
        result.health_grade = "C"
    elif result.health_score >= 60:
        result.health_grade = "D"
    else:
        result.health_grade = "F"

    return result


def _execute_rule(df: pd.DataFrame, rule: Rule) -> RuleResult:
    """Execute a single rule and return the result."""
    try:
        if rule.rule_type == RuleType.NOT_NULL:
            return _check_not_null(df, rule)
        elif rule.rule_type == RuleType.UNIQUE:
            return _check_unique(df, rule)
        elif rule.rule_type == RuleType.RANGE:
            return _check_range(df, rule)
        elif rule.rule_type == RuleType.ENUM:
            return _check_enum(df, rule)
        elif rule.rule_type == RuleType.TYPE:
            return _check_type(df, rule)
        elif rule.rule_type == RuleType.PATTERN:
            return _check_pattern(df, rule)
        elif rule.rule_type == RuleType.NO_DUPLICATES:
            return _check_no_duplicates(df, rule)
        else:
            return RuleResult(rule=rule, passed=True, message="Unknown rule type, skipped")
    except Exception as e:
        return RuleResult(rule=rule, passed=False, message=f"Error executing rule: {str(e)}")


def _check_not_null(df: pd.DataFrame, rule: Rule) -> RuleResult:
    col = rule.column
    null_mask = df[col].isna()
    failed = null_mask.sum()
    failing_rows = list(df.index[null_mask].tolist()[:100])
    return RuleResult(
        rule=rule,
        passed=failed == 0,
        total_checked=len(df),
        failed_count=int(failed),
        failed_percent=(failed / len(df) * 100) if len(df) > 0 else 0,
        message=f"{'✅ No nulls found' if failed == 0 else f'❌ {failed} null values found'}",
        failing_rows=failing_rows,
    )


def _check_unique(df: pd.DataFrame, rule: Rule) -> RuleResult:
    col = rule.column
    non_null = df[col].dropna()
    duplicated = non_null.duplicated(keep=False)
    failed = duplicated.sum()
    failing_rows = list(df.index[df[col].duplicated(keep=False) & df[col].notna()].tolist()[:100])
    return RuleResult(
        rule=rule,
        passed=failed == 0,
        total_checked=len(non_null),
        failed_count=int(failed),
        failed_percent=(failed / len(non_null) * 100) if len(non_null) > 0 else 0,
        message=f"{'✅ All values unique' if failed == 0 else f'❌ {failed} duplicate values found'}",
        failing_rows=failing_rows,
    )


def _check_range(df: pd.DataFrame, rule: Rule) -> RuleResult:
    col = rule.column
    min_val = rule.params.get("min")
    max_val = rule.params.get("max")
    series = pd.to_numeric(df[col], errors="coerce").dropna()
    out_of_range = (series < min_val) | (series > max_val)
    failed = int(out_of_range.sum())
    failing_rows = list(series.index[out_of_range].tolist()[:100])
    return RuleResult(
        rule=rule,
        passed=failed == 0,
        total_checked=len(series),
        failed_count=failed,
        failed_percent=(failed / len(series) * 100) if len(series) > 0 else 0,
        message=f"{'✅ All values in range' if failed == 0 else f'❌ {failed} values out of range [{min_val}, {max_val}]'}",
        failing_rows=failing_rows,
    )


def _check_enum(df: pd.DataFrame, rule: Rule) -> RuleResult:
    col = rule.column
    allowed = rule.params.get("allowed", [])
    non_null = df[col].dropna()
    invalid = ~non_null.isin(allowed)
    failed = int(invalid.sum())
    failing_rows = list(non_null.index[invalid].tolist()[:100])
    return RuleResult(
        rule=rule,
        passed=failed == 0,
        total_checked=len(non_null),
        failed_count=failed,
        failed_percent=(failed / len(non_null) * 100) if len(non_null) > 0 else 0,
        message=f"{'✅ All values in allowed set' if failed == 0 else f'❌ {failed} unexpected values found'}",
        failing_rows=failing_rows,
    )


def _check_type(df: pd.DataFrame, rule: Rule) -> RuleResult:
    col = rule.column
    non_null = df[col].dropna()
    types = non_null.apply(type).value_counts()
    dominant_type = types.index[0] if len(types) > 0 else str
    mismatched = non_null.apply(lambda x: not isinstance(x, dominant_type))
    failed = int(mismatched.sum())
    failing_rows = list(non_null.index[mismatched].tolist()[:100])
    return RuleResult(
        rule=rule,
        passed=failed == 0,
        total_checked=len(non_null),
        failed_count=failed,
        failed_percent=(failed / len(non_null) * 100) if len(non_null) > 0 else 0,
        message=f"{'✅ Consistent types' if failed == 0 else f'❌ {failed} values with unexpected type'}",
        failing_rows=failing_rows,
    )


def _check_pattern(df: pd.DataFrame, rule: Rule) -> RuleResult:
    col = rule.column
    pattern_name = rule.params.get("pattern", "")
    regex = PATTERNS.get(pattern_name)
    if regex is None:
        return RuleResult(rule=rule, passed=True, message=f"Unknown pattern: {pattern_name}")

    non_null = df[col].dropna().astype(str)
    mismatched = ~non_null.str.match(regex)
    failed = int(mismatched.sum())
    failing_rows = list(non_null.index[mismatched].tolist()[:100])
    pass_msg = "✅ All values match pattern"
    fail_msg = f"❌ {failed} values do not match {pattern_name} pattern"
    return RuleResult(
        rule=rule,
        passed=failed == 0,
        total_checked=len(non_null),
        failed_count=failed,
        failed_percent=(failed / len(non_null) * 100) if len(non_null) > 0 else 0,
        message=pass_msg if failed == 0 else fail_msg,
        failing_rows=failing_rows,
    )


def _check_no_duplicates(df: pd.DataFrame, rule: Rule) -> RuleResult:
    duplicated = df.duplicated(keep=False)
    failed = int(duplicated.sum())
    failing_rows = list(df.index[duplicated].tolist()[:100])
    return RuleResult(
        rule=rule,
        passed=failed == 0,
        total_checked=len(df),
        failed_count=failed,
        failed_percent=(failed / len(df) * 100) if len(df) > 0 else 0,
        message=f"{'✅ No duplicate rows' if failed == 0 else f'❌ {failed} rows are duplicates'}",
        failing_rows=failing_rows,
    )
