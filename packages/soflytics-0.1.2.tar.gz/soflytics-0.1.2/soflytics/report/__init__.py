"""
Report package — AuditReport class and output formatters.
"""

from soflytics.report.audit_report import AuditReport

__all__ = ["AuditReport"]
