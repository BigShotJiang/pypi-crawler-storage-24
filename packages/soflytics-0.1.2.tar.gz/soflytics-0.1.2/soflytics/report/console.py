"""
Console report — pretty terminal output via Rich.
"""

from typing import List, Optional

from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.text import Text
from rich.columns import Columns
from rich import box

from soflytics.profiler.models import ProfileResult
from soflytics.rules.models import Rule, ValidationResult


GRADE_COLORS = {
    "A": "bold green",
    "B": "bold cyan",
    "C": "bold yellow",
    "D": "bold dark_orange",
    "F": "bold red",
}


def print_report(
    profile: ProfileResult,
    rules: Optional[List[Rule]] = None,
    validation: Optional[ValidationResult] = None,
):
    """Print a beautiful report to the terminal."""
    console = Console()

    # Header
    console.print()
    grade_color = GRADE_COLORS.get(profile.health_grade, "white")
    header = Text()
    header.append("  🩺 Soflytics Audit Report  ", style="bold white on blue")
    console.print(header)
    console.print()

    # Overview cards
    _print_overview(console, profile)

    # Column details table
    _print_columns(console, profile)

    # Rule suggestions
    if rules:
        _print_rules(console, rules)

    # Validation results
    if validation:
        _print_validation(console, validation)

    console.print()


def _print_overview(console: Console, profile: ProfileResult):
    """Print overview stats."""
    grade_color = GRADE_COLORS.get(profile.health_grade, "white")

    overview = Table(box=box.ROUNDED, show_header=False, padding=(0, 2))
    overview.add_column("Metric", style="dim")
    overview.add_column("Value", justify="right")

    overview.add_row("📊 Rows", f"{profile.row_count:,}")
    overview.add_row("📋 Columns", f"{profile.column_count}")
    overview.add_row("🎯 Health Score", f"[{grade_color}]{profile.health_score}/100[/]")
    overview.add_row("📝 Health Grade", f"[{grade_color}]{profile.health_grade}[/]")
    overview.add_row("🔄 Duplicate Rows", f"{profile.duplicate_row_count:,} ({profile.duplicate_row_percent:.1f}%)")
    overview.add_row("⚠️  Issues Found", f"{profile.total_issues}")
    overview.add_row("💾 Memory", f"{profile.memory_usage_bytes / 1024:.1f} KB")

    console.print(Panel(overview, title="[bold]Dataset Overview[/]", border_style="blue"))
    console.print()


def _print_columns(console: Console, profile: ProfileResult):
    """Print column quality table."""
    table = Table(
        title="Column Quality",
        box=box.ROUNDED,
        show_lines=True,
        header_style="bold cyan",
    )

    table.add_column("Column", style="bold white", max_width=20)
    table.add_column("Type", style="dim", max_width=12)
    table.add_column("Grade", justify="center", max_width=5)
    table.add_column("Nulls", justify="right", max_width=12)
    table.add_column("Unique", justify="right", max_width=12)
    table.add_column("Issues", max_width=40)

    for name, col in profile.columns.items():
        grade_color = GRADE_COLORS.get(col.health_grade, "white")
        null_str = f"{col.null_count} ({col.null_percent:.1f}%)"
        unique_str = f"{col.unique_count}"
        issues_str = ", ".join(col.issues[:3]) if col.issues else "✅ Clean"

        table.add_row(
            name,
            col.dtype,
            f"[{grade_color}]{col.health_grade}[/]",
            null_str,
            unique_str,
            issues_str,
        )

    console.print(table)
    console.print()


def _print_rules(console: Console, rules: List[Rule]):
    """Print suggested rules."""
    table = Table(
        title="💡 Suggested Rules",
        box=box.ROUNDED,
        header_style="bold magenta",
    )

    table.add_column("#", style="dim", max_width=4)
    table.add_column("Rule", max_width=30)
    table.add_column("Severity", justify="center", max_width=10)
    table.add_column("Description", max_width=60)

    severity_icons = {
        "error": "[red]🔴 ERROR[/]",
        "warning": "[yellow]🟡 WARN[/]",
        "info": "[blue]🔵 INFO[/]",
    }

    for i, rule in enumerate(rules, 1):
        table.add_row(
            str(i),
            rule.name,
            severity_icons.get(rule.severity.value, rule.severity.value),
            rule.description,
        )

    console.print(table)
    console.print()


def _print_validation(console: Console, validation: ValidationResult):
    """Print validation results."""
    grade_color = GRADE_COLORS.get(validation.health_grade, "white")

    console.print(Panel(
        f"[{grade_color}]Validation Score: {validation.health_score}/100 ({validation.health_grade})[/]\n"
        f"✅ Passed: {validation.passed_count}  ❌ Failed: {validation.failed_count}  "
        f"Total: {validation.total_rules}",
        title="[bold]Validation Results[/]",
        border_style="green" if validation.failed_count == 0 else "red",
    ))

    if validation.results:
        table = Table(box=box.SIMPLE, header_style="bold")
        table.add_column("Rule")
        table.add_column("Status", justify="center")
        table.add_column("Details")

        for r in validation.results:
            status = "[green]✅ PASS[/]" if r.passed else "[red]❌ FAIL[/]"
            table.add_row(r.rule.name, status, r.message)

        console.print(table)
    console.print()
