"""
AuditReport — the main return object from soflytics.audit().
Ties together profiling, rule suggestions, validation, and output.
"""

import json
from typing import List, Optional, Union

import pandas as pd

from soflytics.profiler.models import ProfileResult
from soflytics.rules.models import Rule, ValidationResult
from soflytics.rules.suggester import suggest
from soflytics.validator import validate


class AuditReport:
    """
    The main report object returned by soflytics.audit().

    Usage:
        report = soflytics.audit(df)
        report.to_console()       # Pretty terminal output
        report.show()             # Browser dashboard
        report.to_html("out.html") # Standalone HTML
        report.to_json()          # JSON string

        rules = report.suggest()
        result = report.validate(rules)
    """

    def __init__(self, df: pd.DataFrame, profile_result: ProfileResult):
        self._df = df
        self._profile = profile_result
        self._suggested_rules: Optional[List[Rule]] = None
        self._validation_result: Optional[ValidationResult] = None

    @property
    def profile(self) -> ProfileResult:
        """Get the profile result."""
        return self._profile

    @property
    def health_score(self) -> float:
        return self._profile.health_score

    @property
    def health_grade(self) -> str:
        return self._profile.health_grade

    def suggest(self) -> List[Rule]:
        """Auto-generate validation rules based on profiling results."""
        if self._suggested_rules is None:
            self._suggested_rules = suggest(self._profile)
        return self._suggested_rules

    def validate(self, rules: Optional[List[Rule]] = None) -> ValidationResult:
        """Run validation rules against the data."""
        if rules is None:
            rules = self.suggest()
        self._validation_result = validate(self._df, rules)
        return self._validation_result

    def to_console(self):
        """Print pretty report to terminal using Rich."""
        from soflytics.report.console import print_report
        print_report(self._profile, self._suggested_rules, self._validation_result)

    def to_json(self) -> str:
        """Return report as JSON string."""
        data = {
            "profile": self._profile.to_dict(),
            "rules": [r.to_dict() for r in self.suggest()],
        }
        if self._validation_result:
            data["validation"] = self._validation_result.to_dict()
        return json.dumps(data, indent=2, default=str)

    def to_html(self, path: str = "soflytics_report.html"):
        """Generate standalone HTML report."""
        from soflytics.report.html import generate_html
        html = generate_html(self._profile, self.suggest(), self._validation_result)
        with open(path, "w", encoding="utf-8") as f:
            f.write(html)
        return path

    def show(self, port: int = 8765):
        """Launch interactive browser dashboard."""
        from soflytics.dashboard.server import launch
        launch(self, port=port)
