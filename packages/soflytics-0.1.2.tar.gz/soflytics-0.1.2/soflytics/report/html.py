"""
HTML report — generate a standalone HTML file with embedded CSS/JS.
"""

import json
from typing import List, Optional

from soflytics.profiler.models import ProfileResult
from soflytics.rules.models import Rule, ValidationResult


def generate_html(
    profile: ProfileResult,
    rules: Optional[List[Rule]] = None,
    validation: Optional[ValidationResult] = None,
) -> str:
    """Generate a self-contained HTML report."""
    profile_json = json.dumps(profile.to_dict(), default=str)
    rules_json = json.dumps([r.to_dict() for r in rules] if rules else [], default=str)
    validation_json = json.dumps(validation.to_dict() if validation else None, default=str)

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Soflytics Report — Health Grade: {profile.health_grade}</title>
<style>
{_get_css()}
</style>
</head>
<body>
<div class="app">
  <header class="header">
    <div class="logo">🩺 <span>Soflytics</span></div>
    <div class="subtitle">Data Quality Report</div>
  </header>

  <div id="dashboard"></div>
</div>

<script>
const PROFILE = {profile_json};
const RULES = {rules_json};
const VALIDATION = {validation_json};

{_get_js()}
</script>
</body>
</html>"""


def _get_css() -> str:
    return """
:root {
  --bg-primary: #0f1117;
  --bg-secondary: #1a1d29;
  --bg-card: #242836;
  --bg-hover: #2d3247;
  --text-primary: #e8eaed;
  --text-secondary: #9aa0a6;
  --text-dim: #6b7280;
  --accent: #6c63ff;
  --accent-glow: rgba(108, 99, 255, 0.3);
  --green: #34d399;
  --yellow: #fbbf24;
  --orange: #f97316;
  --red: #ef4444;
  --blue: #60a5fa;
  --border: rgba(255,255,255,0.06);
  --radius: 12px;
  --font: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
}

@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');

* { margin: 0; padding: 0; box-sizing: border-box; }

body {
  background: var(--bg-primary);
  color: var(--text-primary);
  font-family: var(--font);
  line-height: 1.6;
  min-height: 100vh;
}

.app { max-width: 1200px; margin: 0 auto; padding: 24px; }

.header {
  text-align: center;
  padding: 32px 0;
  margin-bottom: 32px;
}

.logo {
  font-size: 2rem; font-weight: 700;
  background: linear-gradient(135deg, var(--accent), #a78bfa);
  -webkit-background-clip: text; -webkit-text-fill-color: transparent;
}

.subtitle { color: var(--text-secondary); font-size: 0.9rem; margin-top: 4px; }

.overview-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
  gap: 16px;
  margin-bottom: 32px;
}

.stat-card {
  background: var(--bg-card);
  border: 1px solid var(--border);
  border-radius: var(--radius);
  padding: 20px;
  text-align: center;
  transition: transform 0.2s, box-shadow 0.2s;
}

.stat-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 24px rgba(0,0,0,0.3);
}

.stat-card .icon { font-size: 1.5rem; margin-bottom: 8px; }
.stat-card .value { font-size: 1.8rem; font-weight: 700; }
.stat-card .label { font-size: 0.75rem; color: var(--text-secondary); text-transform: uppercase; letter-spacing: 0.05em; }

.grade-badge {
  display: inline-flex; align-items: center; justify-content: center;
  width: 56px; height: 56px; border-radius: 50%;
  font-size: 1.8rem; font-weight: 800;
  margin-bottom: 8px;
}

.grade-A { background: rgba(52,211,153,0.15); color: var(--green); border: 2px solid var(--green); }
.grade-B { background: rgba(96,165,250,0.15); color: var(--blue); border: 2px solid var(--blue); }
.grade-C { background: rgba(251,191,36,0.15); color: var(--yellow); border: 2px solid var(--yellow); }
.grade-D { background: rgba(249,115,22,0.15); color: var(--orange); border: 2px solid var(--orange); }
.grade-F { background: rgba(239,68,68,0.15); color: var(--red); border: 2px solid var(--red); }

.section { margin-bottom: 32px; }
.section-title {
  font-size: 1.2rem; font-weight: 600; margin-bottom: 16px;
  display: flex; align-items: center; gap: 8px;
}

.heatmap-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));
  gap: 8px;
}

.heatmap-cell {
  background: var(--bg-card);
  border: 1px solid var(--border);
  border-radius: 8px;
  padding: 12px;
  text-align: center;
  cursor: pointer;
  transition: all 0.2s;
  position: relative;
  overflow: hidden;
}

.heatmap-cell:hover { transform: scale(1.03); }
.heatmap-cell .col-name { font-size: 0.8rem; font-weight: 500; margin-bottom: 4px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.heatmap-cell .col-grade { font-size: 1.4rem; font-weight: 800; }
.heatmap-cell .col-score { font-size: 0.7rem; color: var(--text-secondary); }
.heatmap-cell::before {
  content: ''; position: absolute; top: 0; left: 0; right: 0; height: 3px;
}
.heatmap-cell.grade-A::before { background: var(--green); }
.heatmap-cell.grade-B::before { background: var(--blue); }
.heatmap-cell.grade-C::before { background: var(--yellow); }
.heatmap-cell.grade-D::before { background: var(--orange); }
.heatmap-cell.grade-F::before { background: var(--red); }

.column-detail {
  background: var(--bg-card);
  border: 1px solid var(--border);
  border-radius: var(--radius);
  margin-bottom: 12px;
  overflow: hidden;
}

.column-detail-header {
  padding: 16px 20px;
  display: flex; align-items: center; justify-content: space-between;
  cursor: pointer;
  transition: background 0.2s;
}

.column-detail-header:hover { background: var(--bg-hover); }
.column-detail-body { padding: 0 20px 20px; }

.stats-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));
  gap: 12px;
}

.stat-item {
  background: var(--bg-secondary);
  border-radius: 8px;
  padding: 12px;
}

.stat-item .stat-label { font-size: 0.7rem; color: var(--text-secondary); text-transform: uppercase; }
.stat-item .stat-value { font-size: 1rem; font-weight: 600; margin-top: 2px; }

.top-values-list { margin-top: 12px; }
.top-value-row {
  display: flex; align-items: center; gap: 8px;
  padding: 6px 0;
  border-bottom: 1px solid var(--border);
  font-size: 0.85rem;
}

.top-value-bar {
  height: 6px; border-radius: 3px; background: var(--accent);
  transition: width 0.5s ease;
}

.rules-table {
  width: 100%;
  border-collapse: collapse;
}

.rules-table th {
  text-align: left; padding: 10px 12px;
  font-size: 0.75rem; text-transform: uppercase; color: var(--text-secondary);
  border-bottom: 1px solid var(--border);
}

.rules-table td {
  padding: 12px;
  border-bottom: 1px solid var(--border);
  font-size: 0.85rem;
}

.severity-badge {
  display: inline-block; padding: 2px 8px; border-radius: 4px;
  font-size: 0.7rem; font-weight: 600; text-transform: uppercase;
}

.severity-error { background: rgba(239,68,68,0.15); color: var(--red); }
.severity-warning { background: rgba(251,191,36,0.15); color: var(--yellow); }
.severity-info { background: rgba(96,165,250,0.15); color: var(--blue); }

.issues-list { list-style: none; }
.issues-list li { padding: 4px 0; font-size: 0.85rem; color: var(--text-secondary); }
.issues-list li::before { content: '⚠️ '; }

@keyframes fadeIn { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: translateY(0); } }
.animate-in { animation: fadeIn 0.4s ease forwards; }
"""


def _get_js() -> str:
    return """
function gradeColor(grade) {
  const colors = { A: '#34d399', B: '#60a5fa', C: '#fbbf24', D: '#f97316', F: '#ef4444' };
  return colors[grade] || '#9aa0a6';
}

function render() {
  const dashboard = document.getElementById('dashboard');
  let html = '';

  // Overview cards
  html += '<div class="overview-grid animate-in">';
  html += `<div class="stat-card">
    <div class="grade-badge grade-${PROFILE.health_grade}">${PROFILE.health_grade}</div>
    <div class="label">Health Grade</div>
  </div>`;
  html += `<div class="stat-card"><div class="icon">📊</div><div class="value">${PROFILE.row_count.toLocaleString()}</div><div class="label">Rows</div></div>`;
  html += `<div class="stat-card"><div class="icon">📋</div><div class="value">${PROFILE.column_count}</div><div class="label">Columns</div></div>`;
  html += `<div class="stat-card"><div class="icon">🎯</div><div class="value">${PROFILE.health_score}</div><div class="label">Score / 100</div></div>`;
  html += `<div class="stat-card"><div class="icon">🔄</div><div class="value">${PROFILE.duplicate_row_count}</div><div class="label">Duplicates</div></div>`;
  html += `<div class="stat-card"><div class="icon">⚠️</div><div class="value">${PROFILE.total_issues}</div><div class="label">Issues</div></div>`;
  html += '</div>';

  // Column heatmap
  html += '<div class="section animate-in"><div class="section-title">🗺️ Column Quality Heatmap</div>';
  html += '<div class="heatmap-grid">';
  for (const [name, col] of Object.entries(PROFILE.columns)) {
    html += `<div class="heatmap-cell grade-${col.health_grade}" onclick="toggleDetail('${name}')">
      <div class="col-name" title="${name}">${name}</div>
      <div class="col-grade" style="color:${gradeColor(col.health_grade)}">${col.health_grade}</div>
      <div class="col-score">${col.health_score}/100</div>
    </div>`;
  }
  html += '</div></div>';

  // Column details
  html += '<div class="section animate-in"><div class="section-title">📋 Column Details</div>';
  for (const [name, col] of Object.entries(PROFILE.columns)) {
    html += renderColumnDetail(name, col);
  }
  html += '</div>';

  // Rules
  if (RULES && RULES.length > 0) {
    html += '<div class="section animate-in"><div class="section-title">💡 Suggested Rules</div>';
    html += '<table class="rules-table"><thead><tr><th>Rule</th><th>Severity</th><th>Description</th></tr></thead><tbody>';
    for (const rule of RULES) {
      html += `<tr>
        <td style="font-weight:500">${rule.name}</td>
        <td><span class="severity-badge severity-${rule.severity}">${rule.severity}</span></td>
        <td style="color:var(--text-secondary)">${rule.description}</td>
      </tr>`;
    }
    html += '</tbody></table></div>';
  }

  dashboard.innerHTML = html;
}

function renderColumnDetail(name, col) {
  let stats = `
    <div class="stat-item"><div class="stat-label">Type</div><div class="stat-value">${col.dtype}</div></div>
    <div class="stat-item"><div class="stat-label">Nulls</div><div class="stat-value">${col.null_count} (${col.null_percent}%)</div></div>
    <div class="stat-item"><div class="stat-label">Unique</div><div class="stat-value">${col.unique_count}</div></div>
  `;

  if (col.is_numeric) {
    if (col.mean !== null) stats += `<div class="stat-item"><div class="stat-label">Mean</div><div class="stat-value">${col.mean}</div></div>`;
    if (col.median !== null) stats += `<div class="stat-item"><div class="stat-label">Median</div><div class="stat-value">${col.median}</div></div>`;
    if (col.min_value !== null) stats += `<div class="stat-item"><div class="stat-label">Min</div><div class="stat-value">${col.min_value}</div></div>`;
    if (col.max_value !== null) stats += `<div class="stat-item"><div class="stat-label">Max</div><div class="stat-value">${col.max_value}</div></div>`;
    if (col.outlier_count > 0) stats += `<div class="stat-item"><div class="stat-label">Outliers</div><div class="stat-value" style="color:var(--orange)">${col.outlier_count}</div></div>`;
  }

  if (col.is_string) {
    if (col.min_length !== null) stats += `<div class="stat-item"><div class="stat-label">Min Length</div><div class="stat-value">${col.min_length}</div></div>`;
    if (col.max_length !== null) stats += `<div class="stat-item"><div class="stat-label">Max Length</div><div class="stat-value">${col.max_length}</div></div>`;
    if (col.detected_pattern) stats += `<div class="stat-item"><div class="stat-label">Pattern</div><div class="stat-value" style="color:var(--accent)">${col.detected_pattern}</div></div>`;
  }

  // Top values
  let topValuesHtml = '';
  if (col.top_values && col.top_values.length > 0) {
    const maxCount = col.top_values[0].count;
    topValuesHtml = '<div class="top-values-list"><div style="font-size:0.75rem;color:var(--text-secondary);margin-bottom:8px;">TOP VALUES</div>';
    for (const tv of col.top_values.slice(0, 5)) {
      const pct = (tv.count / maxCount * 100);
      topValuesHtml += `<div class="top-value-row">
        <span style="min-width:100px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${tv.value ?? 'null'}</span>
        <div style="flex:1"><div class="top-value-bar" style="width:${pct}%"></div></div>
        <span style="color:var(--text-secondary);font-size:0.75rem">${tv.count} (${tv.percent}%)</span>
      </div>`;
    }
    topValuesHtml += '</div>';
  }

  // Issues
  let issuesHtml = '';
  if (col.issues && col.issues.length > 0) {
    issuesHtml = '<ul class="issues-list" style="margin-top:12px">';
    for (const issue of col.issues) {
      issuesHtml += `<li>${issue}</li>`;
    }
    issuesHtml += '</ul>';
  }

  return `<div class="column-detail" id="detail-${name}">
    <div class="column-detail-header" onclick="toggleDetail('${name}')">
      <div style="display:flex;align-items:center;gap:12px">
        <span style="font-weight:600">${name}</span>
        <span style="font-size:0.75rem;color:var(--text-secondary)">${col.dtype}</span>
      </div>
      <div style="display:flex;align-items:center;gap:12px">
        <span style="color:${gradeColor(col.health_grade)};font-weight:700">${col.health_grade}</span>
        <span style="font-size:0.8rem;color:var(--text-secondary)">${col.health_score}/100</span>
        <span class="chevron" style="color:var(--text-dim)">▼</span>
      </div>
    </div>
    <div class="column-detail-body" style="display:none">
      <div class="stats-grid">${stats}</div>
      ${topValuesHtml}
      ${issuesHtml}
    </div>
  </div>`;
}

function toggleDetail(name) {
  const el = document.getElementById('detail-' + name);
  const body = el.querySelector('.column-detail-body');
  const chevron = el.querySelector('.chevron');
  if (body.style.display === 'none') {
    body.style.display = 'block';
    chevron.textContent = '▲';
  } else {
    body.style.display = 'none';
    chevron.textContent = '▼';
  }
}

render();
"""
