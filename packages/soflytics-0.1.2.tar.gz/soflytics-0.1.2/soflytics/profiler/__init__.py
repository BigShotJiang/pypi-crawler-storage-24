"""
Profiler package — auto-profile any dataset.
"""

from soflytics.profiler.stats import profile

__all__ = ["profile"]
