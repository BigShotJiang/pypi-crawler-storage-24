"""
Profiler engine — compute per-column statistics and detect data quality issues.
"""

import re
from typing import Dict, List

import pandas as pd
import numpy as np

from soflytics.profiler.models import ColumnProfile, ProfileResult

# Regex patterns for common data formats
PATTERNS = {
    "email": re.compile(r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"),
    "phone": re.compile(r"^[\+]?[(]?[0-9]{1,4}[)]?[-\s\./0-9]{7,15}$"),
    "uuid": re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$", re.I),
    "url": re.compile(r"^https?://[^\s/$.?#].[^\s]*$", re.I),
    "ip_address": re.compile(r"^(?:\d{1,3}\.){3}\d{1,3}$"),
    "date_iso": re.compile(r"^\d{4}-\d{2}-\d{2}$"),
}


def profile(df: pd.DataFrame) -> ProfileResult:
    """
    Profile a DataFrame — compute per-column stats, detect issues, and calculate health scores.
    """
    result = ProfileResult(
        row_count=len(df),
        column_count=len(df.columns),
        memory_usage_bytes=int(df.memory_usage(deep=True).sum()),
    )

    # Detect duplicate rows
    dup_count = int(df.duplicated().sum())
    result.duplicate_row_count = dup_count
    result.duplicate_row_percent = (dup_count / len(df) * 100) if len(df) > 0 else 0.0

    # Profile each column
    all_issues = 0
    health_scores = []

    for col_name in df.columns:
        col_profile = _profile_column(df[col_name], col_name, len(df))
        result.columns[col_name] = col_profile
        all_issues += len(col_profile.issues)
        health_scores.append(col_profile.health_score)

    # Overall health
    result.total_issues = all_issues
    if health_scores:
        result.health_score = round(sum(health_scores) / len(health_scores), 1)
    else:
        result.health_score = 100.0

    if result.health_score >= 90:
        result.health_grade = "A"
    elif result.health_score >= 80:
        result.health_grade = "B"
    elif result.health_score >= 70:
        result.health_grade = "C"
    elif result.health_score >= 60:
        result.health_grade = "D"
    else:
        result.health_grade = "F"

    return result


def _profile_column(series: pd.Series, name: str, total_rows: int) -> ColumnProfile:
    """Profile a single column."""
    cp = ColumnProfile(name=name, dtype=str(series.dtype), total_count=total_rows)
    issues: List[str] = []

    # --- Null analysis ---
    cp.null_count = int(series.isna().sum())
    cp.null_percent = (cp.null_count / total_rows * 100) if total_rows > 0 else 0.0
    if cp.null_percent > 0:
        issues.append(f"{cp.null_percent:.1f}% null values")

    # --- Unique / cardinality ---
    non_null = series.dropna()
    cp.unique_count = int(non_null.nunique())
    non_null_count = len(non_null)
    cp.cardinality_ratio = (cp.unique_count / non_null_count) if non_null_count > 0 else 0.0

    # --- Type detection ---
    cp.is_numeric = pd.api.types.is_numeric_dtype(series)
    cp.is_boolean = pd.api.types.is_bool_dtype(series)
    cp.is_datetime = pd.api.types.is_datetime64_any_dtype(series)
    cp.is_string = pd.api.types.is_string_dtype(series) or pd.api.types.is_object_dtype(series)

    # Mixed type check for object columns
    if pd.api.types.is_object_dtype(series) and non_null_count > 0:
        types_found = non_null.apply(type).nunique()
        cp.has_mixed_types = types_found > 1
        if cp.has_mixed_types:
            issues.append("Mixed data types detected")

    # --- Numeric stats ---
    if cp.is_numeric and not cp.is_boolean:
        _compute_numeric_stats(cp, non_null, issues)

    # --- String stats ---
    if cp.is_string and non_null_count > 0:
        _compute_string_stats(cp, non_null, issues)

    # --- Datetime stats ---
    if cp.is_datetime and non_null_count > 0:
        cp.min_value = str(non_null.min())
        cp.max_value = str(non_null.max())

    # --- Top values ---
    if non_null_count > 0:
        value_counts = non_null.value_counts().head(10)
        cp.top_values = [
            {
                "value": _safe_value(val),
                "count": int(cnt),
                "percent": round(cnt / total_rows * 100, 2),
            }
            for val, cnt in value_counts.items()
        ]

    # --- Health score ---
    cp.issues = issues
    cp.health_score = _calculate_column_health(cp)

    return cp


def _compute_numeric_stats(cp: ColumnProfile, non_null: pd.Series, issues: List[str]):
    """Compute numeric-specific statistics."""
    if len(non_null) == 0:
        return

    cp.min_value = float(non_null.min())
    cp.max_value = float(non_null.max())
    cp.mean = float(non_null.mean())
    cp.median = float(non_null.median())
    cp.std_dev = float(non_null.std()) if len(non_null) > 1 else 0.0

    # Quartiles & IQR for outlier detection
    cp.q1 = float(non_null.quantile(0.25))
    cp.q3 = float(non_null.quantile(0.75))
    cp.iqr = cp.q3 - cp.q1

    if cp.iqr > 0:
        lower_bound = cp.q1 - 1.5 * cp.iqr
        upper_bound = cp.q3 + 1.5 * cp.iqr
        outliers = ((non_null < lower_bound) | (non_null > upper_bound)).sum()
        cp.outlier_count = int(outliers)
        cp.outlier_percent = (cp.outlier_count / len(non_null) * 100) if len(non_null) > 0 else 0.0
        if cp.outlier_count > 0:
            issues.append(f"{cp.outlier_count} outliers ({cp.outlier_percent:.1f}%)")


def _compute_string_stats(cp: ColumnProfile, non_null: pd.Series, issues: List[str]):
    """Compute string-specific statistics and pattern detection."""
    str_series = non_null.astype(str)
    lengths = str_series.str.len()

    cp.min_length = int(lengths.min())
    cp.max_length = int(lengths.max())
    cp.avg_length = float(lengths.mean())

    # Pattern detection — sample for performance
    sample = str_series.head(min(1000, len(str_series)))
    for pattern_name, regex in PATTERNS.items():
        matches = sample.str.match(regex)
        match_pct = matches.sum() / len(sample) * 100 if len(sample) > 0 else 0
        if match_pct > 80:  # >80% match → likely this pattern
            cp.detected_pattern = pattern_name
            cp.pattern_match_percent = round(match_pct, 2)
            break


def _calculate_column_health(cp: ColumnProfile) -> float:
    """Calculate a 0-100 health score for a column based on detected issues."""
    score = 100.0

    # Null penalty (heavy for >50%, moderate for >10%)
    if cp.null_percent > 50:
        score -= 30
    elif cp.null_percent > 10:
        score -= 15
    elif cp.null_percent > 0:
        score -= 5

    # Outlier penalty
    if cp.outlier_percent > 10:
        score -= 20
    elif cp.outlier_percent > 5:
        score -= 10
    elif cp.outlier_count > 0:
        score -= 3

    # Mixed types penalty
    if cp.has_mixed_types:
        score -= 15

    # Very low cardinality on non-boolean (possible data issue)
    if cp.unique_count == 1 and cp.total_count > 10 and not cp.is_boolean:
        score -= 10

    return max(0, round(score, 1))


def _safe_value(val) -> str:
    """Convert a value to a JSON-safe string."""
    if isinstance(val, (np.integer,)):
        return int(val)
    if isinstance(val, (np.floating,)):
        return round(float(val), 4)
    if isinstance(val, (np.bool_,)):
        return bool(val)
    if pd.isna(val):
        return None
    return str(val)
