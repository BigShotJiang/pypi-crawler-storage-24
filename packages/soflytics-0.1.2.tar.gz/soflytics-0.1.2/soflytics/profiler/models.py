"""
Profiler data models — dataclasses for column and table profiles.
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class ColumnProfile:
    """Profile statistics for a single column."""

    name: str
    dtype: str  # inferred dtype string
    total_count: int = 0
    null_count: int = 0
    null_percent: float = 0.0
    unique_count: int = 0
    cardinality_ratio: float = 0.0  # unique / non-null

    # Numeric stats
    min_value: Optional[float] = None
    max_value: Optional[float] = None
    mean: Optional[float] = None
    median: Optional[float] = None
    std_dev: Optional[float] = None
    q1: Optional[float] = None
    q3: Optional[float] = None
    iqr: Optional[float] = None
    outlier_count: int = 0
    outlier_percent: float = 0.0

    # String stats
    min_length: Optional[int] = None
    max_length: Optional[int] = None
    avg_length: Optional[float] = None

    # Pattern detection
    detected_pattern: Optional[str] = None  # email, phone, uuid, url, etc.
    pattern_match_percent: float = 0.0

    # Value distributions
    top_values: List[Dict[str, Any]] = field(default_factory=list)  # [{"value": x, "count": n, "percent": p}]
    is_numeric: bool = False
    is_string: bool = False
    is_boolean: bool = False
    is_datetime: bool = False
    has_mixed_types: bool = False

    # Health
    health_score: float = 100.0  # 0-100
    issues: List[str] = field(default_factory=list)

    @property
    def health_grade(self) -> str:
        """Letter grade A-F based on health score."""
        if self.health_score >= 90:
            return "A"
        elif self.health_score >= 80:
            return "B"
        elif self.health_score >= 70:
            return "C"
        elif self.health_score >= 60:
            return "D"
        else:
            return "F"


@dataclass
class ProfileResult:
    """Complete profile result for a dataset."""

    row_count: int = 0
    column_count: int = 0
    duplicate_row_count: int = 0
    duplicate_row_percent: float = 0.0
    memory_usage_bytes: int = 0
    columns: Dict[str, ColumnProfile] = field(default_factory=dict)

    # Overall health
    health_score: float = 100.0
    health_grade: str = "A"
    total_issues: int = 0

    def to_dict(self) -> dict:
        """Convert to JSON-serializable dict."""
        return {
            "row_count": self.row_count,
            "column_count": self.column_count,
            "duplicate_row_count": self.duplicate_row_count,
            "duplicate_row_percent": round(self.duplicate_row_percent, 2),
            "memory_usage_bytes": self.memory_usage_bytes,
            "health_score": round(self.health_score, 1),
            "health_grade": self.health_grade,
            "total_issues": self.total_issues,
            "columns": {
                name: {
                    "name": col.name,
                    "dtype": col.dtype,
                    "total_count": col.total_count,
                    "null_count": col.null_count,
                    "null_percent": round(col.null_percent, 2),
                    "unique_count": col.unique_count,
                    "cardinality_ratio": round(col.cardinality_ratio, 2),
                    "min_value": col.min_value,
                    "max_value": col.max_value,
                    "mean": round(col.mean, 4) if col.mean is not None else None,
                    "median": col.median,
                    "std_dev": round(col.std_dev, 4) if col.std_dev is not None else None,
                    "q1": col.q1,
                    "q3": col.q3,
                    "outlier_count": col.outlier_count,
                    "outlier_percent": round(col.outlier_percent, 2),
                    "min_length": col.min_length,
                    "max_length": col.max_length,
                    "avg_length": round(col.avg_length, 1) if col.avg_length is not None else None,
                    "detected_pattern": col.detected_pattern,
                    "pattern_match_percent": round(col.pattern_match_percent, 2),
                    "top_values": col.top_values[:10],
                    "is_numeric": col.is_numeric,
                    "is_string": col.is_string,
                    "is_boolean": col.is_boolean,
                    "is_datetime": col.is_datetime,
                    "has_mixed_types": col.has_mixed_types,
                    "health_score": round(col.health_score, 1),
                    "health_grade": col.health_grade,
                    "issues": col.issues,
                }
                for name, col in self.columns.items()
            },
        }
