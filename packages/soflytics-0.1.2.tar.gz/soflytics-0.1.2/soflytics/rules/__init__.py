"""
Rules package — auto-suggest and manage validation rules.
"""

from soflytics.rules.suggester import suggest
from soflytics.rules.models import Rule, RuleType, RuleResult, ValidationResult, Severity

__all__ = ["suggest", "Rule", "RuleType", "RuleResult", "ValidationResult", "Severity"]
