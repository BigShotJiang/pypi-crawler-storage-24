"""
Rule models — dataclasses for validation rules and results.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Dict, List, Optional


class RuleType(str, Enum):
    NOT_NULL = "not_null"
    UNIQUE = "unique"
    RANGE = "range"
    ENUM = "enum"
    TYPE = "type"
    PATTERN = "pattern"
    NO_DUPLICATES = "no_duplicates"
    CUSTOM = "custom"


class Severity(str, Enum):
    ERROR = "error"      # Definite data quality issue
    WARNING = "warning"  # Potential issue, worth checking
    INFO = "info"        # Informational suggestion


@dataclass
class Rule:
    """A validation rule suggested or defined for a column."""

    name: str
    column: Optional[str]  # None for table-level rules
    rule_type: RuleType
    description: str  # Plain English description
    severity: Severity = Severity.WARNING
    params: Dict[str, Any] = field(default_factory=dict)
    enabled: bool = True

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "column": self.column,
            "rule_type": self.rule_type.value,
            "description": self.description,
            "severity": self.severity.value,
            "params": self.params,
            "enabled": self.enabled,
        }


@dataclass
class RuleResult:
    """Result of running a single rule against data."""

    rule: Rule
    passed: bool
    total_checked: int = 0
    failed_count: int = 0
    failed_percent: float = 0.0
    message: str = ""
    failing_rows: List[int] = field(default_factory=list)  # Row indices (first 100)

    def to_dict(self) -> dict:
        return {
            "rule": self.rule.to_dict(),
            "passed": self.passed,
            "total_checked": self.total_checked,
            "failed_count": self.failed_count,
            "failed_percent": round(self.failed_percent, 2),
            "message": self.message,
            "failing_rows_sample": self.failing_rows[:20],
        }


@dataclass
class ValidationResult:
    """Aggregated result of all validation rules."""

    results: List[RuleResult] = field(default_factory=list)
    total_rules: int = 0
    passed_count: int = 0
    failed_count: int = 0
    warning_count: int = 0
    health_score: float = 100.0
    health_grade: str = "A"

    def to_dict(self) -> dict:
        return {
            "total_rules": self.total_rules,
            "passed_count": self.passed_count,
            "failed_count": self.failed_count,
            "warning_count": self.warning_count,
            "health_score": round(self.health_score, 1),
            "health_grade": self.health_grade,
            "results": [r.to_dict() for r in self.results],
        }
