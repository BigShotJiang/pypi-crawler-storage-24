"""
Rule suggester — auto-generate validation rules from a profile result.
"""

from typing import List

from soflytics.profiler.models import ColumnProfile, ProfileResult
from soflytics.rules.models import Rule, RuleType, Severity


def suggest(profile_result: ProfileResult) -> List[Rule]:
    """
    Analyze a profile result and suggest validation rules.
    Returns a list of Rule objects with plain-English descriptions.
    """
    rules: List[Rule] = []

    # Table-level rules
    if profile_result.duplicate_row_count > 0:
        rules.append(Rule(
            name="No duplicate rows",
            column=None,
            rule_type=RuleType.NO_DUPLICATES,
            description=f"Found {profile_result.duplicate_row_count} duplicate rows "
                        f"({profile_result.duplicate_row_percent:.1f}%) — enforce uniqueness?",
            severity=Severity.WARNING,
        ))

    # Column-level rules
    for col_name, col in profile_result.columns.items():
        rules.extend(_suggest_column_rules(col))

    return rules


def _suggest_column_rules(col: ColumnProfile) -> List[Rule]:
    """Suggest rules for a single column based on its profile."""
    rules: List[Rule] = []

    # NOT NULL — if column is <5% null
    if 0 < col.null_percent < 5:
        rules.append(Rule(
            name=f"'{col.name}' should not be null",
            column=col.name,
            rule_type=RuleType.NOT_NULL,
            description=f"'{col.name}' is {col.null_percent:.1f}% null — enforce NOT NULL?",
            severity=Severity.WARNING,
        ))
    elif col.null_percent == 0:
        rules.append(Rule(
            name=f"'{col.name}' is never null",
            column=col.name,
            rule_type=RuleType.NOT_NULL,
            description=f"'{col.name}' has zero nulls — keep it that way?",
            severity=Severity.INFO,
        ))

    # UNIQUE — if cardinality ratio >95%
    if col.cardinality_ratio > 0.95 and col.unique_count > 1:
        rules.append(Rule(
            name=f"'{col.name}' looks unique",
            column=col.name,
            rule_type=RuleType.UNIQUE,
            description=f"'{col.name}' has {col.cardinality_ratio * 100:.0f}% unique values — enforce uniqueness?",
            severity=Severity.INFO,
        ))

    # RANGE — min/max bounds for numerics
    if col.is_numeric and col.min_value is not None and col.max_value is not None:
        # Add IQR padding for reasonable bounds
        if col.iqr and col.iqr > 0:
            suggested_min = col.q1 - 1.5 * col.iqr
            suggested_max = col.q3 + 1.5 * col.iqr
        else:
            suggested_min = col.min_value
            suggested_max = col.max_value

        rules.append(Rule(
            name=f"'{col.name}' value range",
            column=col.name,
            rule_type=RuleType.RANGE,
            description=f"'{col.name}' ranges from {col.min_value} to {col.max_value} — "
                        f"enforce bounds [{suggested_min:.1f}, {suggested_max:.1f}]?",
            severity=Severity.WARNING if col.outlier_count > 0 else Severity.INFO,
            params={"min": suggested_min, "max": suggested_max},
        ))

    # ENUM — if cardinality <10
    if 1 < col.unique_count <= 10 and not col.is_numeric:
        enum_values = [v["value"] for v in col.top_values[:10]]
        rules.append(Rule(
            name=f"'{col.name}' allowed values",
            column=col.name,
            rule_type=RuleType.ENUM,
            description=f"'{col.name}' has only {col.unique_count} unique values — "
                        f"enforce allowed set {enum_values}?",
            severity=Severity.INFO,
            params={"allowed": enum_values},
        ))

    # TYPE — if mixed types detected
    if col.has_mixed_types:
        rules.append(Rule(
            name=f"'{col.name}' has mixed types",
            column=col.name,
            rule_type=RuleType.TYPE,
            description=f"'{col.name}' contains mixed data types — enforce consistent type?",
            severity=Severity.ERROR,
            params={"expected_type": col.dtype},
        ))

    # PATTERN — if regex pattern detected
    if col.detected_pattern:
        rules.append(Rule(
            name=f"'{col.name}' matches {col.detected_pattern} pattern",
            column=col.name,
            rule_type=RuleType.PATTERN,
            description=f"'{col.name}' looks like {col.detected_pattern} "
                        f"({col.pattern_match_percent:.0f}% match) — enforce pattern?",
            severity=Severity.WARNING,
            params={"pattern": col.detected_pattern},
        ))

    # HIGH NULL — warning for >50% nulls
    if col.null_percent >= 50:
        rules.append(Rule(
            name=f"'{col.name}' is mostly null",
            column=col.name,
            rule_type=RuleType.NOT_NULL,
            description=f"'{col.name}' is {col.null_percent:.1f}% null — consider dropping or investigating?",
            severity=Severity.ERROR,
        ))

    return rules
