/* ===========================================
   Soflytics Dashboard — Interactive Frontend
   =========================================== */

// ---- Grade helpers ----
function gradeColor(grade) {
  const map = { A: 'var(--green)', B: 'var(--blue)', C: 'var(--yellow)', D: 'var(--orange)', F: 'var(--red)' };
  return map[grade] || 'var(--text-secondary)';
}

function gradeClass(grade) {
  return 'grade-' + (grade || 'F');
}

// ---- Formatter ----
function formatNum(val) {
  if (typeof val === 'number') {
    return Number.isInteger(val) ? val.toLocaleString() : val.toLocaleString(undefined, { maximumFractionDigits: 2 });
  }
  return val;
}

// ---- Render Overview Cards ----
function renderOverview() {
  const grid = document.getElementById('overview-grid');
  const cards = [
    { html: `<div class="grade-ring ${gradeClass(PROFILE.health_grade)}">${PROFILE.health_grade}</div>`, label: 'HEALTH GRADE' },
    { icon: '📊', value: PROFILE.row_count.toLocaleString(), label: 'ROWS' },
    { icon: '📋', value: PROFILE.column_count, label: 'COLUMNS' },
    { icon: '🎯', value: PROFILE.health_score, label: 'SCORE / 100' },
    { icon: '🔄', value: PROFILE.duplicate_row_count, label: 'DUPLICATES' },
    { icon: '⚠️', value: PROFILE.total_issues, label: 'ISSUES' },
  ];

  grid.innerHTML = cards.map((c, i) => `
    <div class="stat-card animate-in animate-in-delay-${i + 1}">
      ${c.html ? c.html : `<span class="icon">${c.icon}</span><div class="value">${c.value}</div>`}
      <div class="label">${c.label}</div>
    </div>
  `).join('');
}

// ---- Render Heatmap ----
function renderHeatmap() {
  const grid = document.getElementById('heatmap-grid');
  const cols = Object.entries(PROFILE.columns);

  grid.innerHTML = cols.map(([name, col]) => `
    <div class="heatmap-cell hm-${col.health_grade}" onclick="scrollToColumn('${name}')" title="${name}: ${col.health_score}/100">
      <div class="hm-name">${name}</div>
      <div class="hm-grade">${col.health_grade}</div>
      <div class="hm-score">${col.health_score}/100</div>
    </div>
  `).join('');
}

// ---- Render Column Details ----
function renderColumnDetails() {
  const container = document.getElementById('column-details');
  const cols = Object.entries(PROFILE.columns);

  container.innerHTML = cols.map(([name, col]) => {
    let statsHtml = `
      <div class="stat-pill"><div class="stat-pill-label">Type</div><div class="stat-pill-value">${col.dtype}</div></div>
      <div class="stat-pill"><div class="stat-pill-label">Nulls</div><div class="stat-pill-value">${col.null_count} (${col.null_percent}%)</div></div>
      <div class="stat-pill"><div class="stat-pill-label">Unique</div><div class="stat-pill-value">${col.unique_count}</div></div>
      <div class="stat-pill"><div class="stat-pill-label">Cardinality</div><div class="stat-pill-value">${(col.cardinality_ratio * 100).toFixed(0)}%</div></div>
    `;

    if (col.is_numeric) {
      if (col.mean !== null) statsHtml += `<div class="stat-pill"><div class="stat-pill-label">Mean</div><div class="stat-pill-value">${formatNum(col.mean)}</div></div>`;
      if (col.median !== null) statsHtml += `<div class="stat-pill"><div class="stat-pill-label">Median</div><div class="stat-pill-value">${formatNum(col.median)}</div></div>`;
      if (col.std_dev !== null) statsHtml += `<div class="stat-pill"><div class="stat-pill-label">Std Dev</div><div class="stat-pill-value">${formatNum(col.std_dev)}</div></div>`;
      if (col.min_value !== null) statsHtml += `<div class="stat-pill"><div class="stat-pill-label">Min</div><div class="stat-pill-value">${formatNum(col.min_value)}</div></div>`;
      if (col.max_value !== null) statsHtml += `<div class="stat-pill"><div class="stat-pill-label">Max</div><div class="stat-pill-value">${formatNum(col.max_value)}</div></div>`;
      if (col.outlier_count > 0) statsHtml += `<div class="stat-pill"><div class="stat-pill-label">Outliers</div><div class="stat-pill-value" style="color:var(--orange)">${col.outlier_count.toLocaleString()} (${col.outlier_percent}%)</div></div>`;
    }

    if (col.is_string) {
      if (col.min_length !== null) statsHtml += `<div class="stat-pill"><div class="stat-pill-label">Min Len</div><div class="stat-pill-value">${col.min_length}</div></div>`;
      if (col.max_length !== null) statsHtml += `<div class="stat-pill"><div class="stat-pill-label">Max Len</div><div class="stat-pill-value">${col.max_length}</div></div>`;
      if (col.avg_length != null) statsHtml += `<div class="stat-pill"><div class="stat-pill-label">Avg Len</div><div class="stat-pill-value">${col.avg_length}</div></div>`;
      if (col.detected_pattern) statsHtml += `<div class="stat-pill"><div class="stat-pill-label">Pattern</div><div class="stat-pill-value" style="color:var(--accent)">${col.detected_pattern} (${col.pattern_match_percent}%)</div></div>`;
    }

    // Top values
    let topHtml = '';
    if (col.top_values && col.top_values.length > 0) {
      const maxCount = col.top_values[0].count;
      topHtml = '<div style="margin-top:16px"><div class="top-values-title">Top Values</div>';
      col.top_values.slice(0, 6).forEach(tv => {
        const pct = maxCount > 0 ? (tv.count / maxCount * 100) : 0;
        topHtml += `<div class="tv-row">
          <span class="tv-name" title="${tv.value}">${formatNum(tv.value) ?? 'null'}</span>
          <div class="tv-bar-wrap"><div class="tv-bar" style="width:${pct}%"></div></div>
          <span class="tv-count">${tv.count.toLocaleString()} (${tv.percent}%)</span>
        </div>`;
      });
      topHtml += '</div>';
    }

    // Issues
    let issuesHtml = '';
    if (col.issues && col.issues.length > 0) {
      issuesHtml = '<ul class="issues-list">' + col.issues.map(i => `<li>${i}</li>`).join('') + '</ul>';
    }

    return `<div class="col-card" id="col-${CSS.escape(name)}">
      <div class="col-card-header" onclick="toggleCol(this)">
        <div class="col-card-left">
          <span class="col-card-name">${name}</span>
          <span class="col-card-type">${col.dtype}</span>
        </div>
        <div class="col-card-right">
          <span class="col-card-grade" style="color:${gradeColor(col.health_grade)}">${col.health_grade}</span>
          <span class="col-card-score">${col.health_score}/100</span>
          <span class="col-card-chevron">▼</span>
        </div>
      </div>
      <div class="col-card-body">
        <div class="stats-grid">${statsHtml}</div>
        ${topHtml}
        ${issuesHtml}
      </div>
    </div>`;
  }).join('');
}

function toggleCol(header) {
  const card = header.closest('.col-card');
  card.classList.toggle('open');
}

function scrollToColumn(name) {
  const el = document.getElementById('col-' + CSS.escape(name));
  if (el) {
    el.scrollIntoView({ behavior: 'smooth', block: 'center' });
    el.classList.add('open');
  }
}

// ---- Render Rules ----
function renderRules() {
  const container = document.getElementById('rules-container');

  if (!RULES || RULES.length === 0) {
    container.innerHTML = '<p style="color:var(--text-dim)">No rules suggested — your data looks great! 🎉</p>';
    return;
  }

  let html = '<table class="rules-table"><thead><tr><th>#</th><th>Rule</th><th>Column</th><th>Severity</th><th>Description</th></tr></thead><tbody>';
  RULES.forEach((rule, i) => {
    html += `<tr>
      <td style="color:var(--text-dim)">${i + 1}</td>
      <td style="font-weight:500">${rule.name}</td>
      <td style="color:var(--text-secondary)">${rule.column || '—'}</td>
      <td><span class="sev-badge sev-${rule.severity}">${rule.severity}</span></td>
      <td style="color:var(--text-secondary)">${rule.description}</td>
    </tr>`;
  });
  html += '</tbody></table>';
  container.innerHTML = html;
}

// ---- Run Validation ----
async function runValidation() {
  const btn = document.getElementById('btn-validate');
  btn.innerHTML = '<span class="spinner"></span> Validating...';
  btn.disabled = true;

  try {
    const res = await fetch('/api/validate', { method: 'POST' });
    const data = await res.json();

    const section = document.getElementById('validation-section');
    section.style.display = 'block';

    const container = document.getElementById('validation-container');
    let html = '<div class="validation-summary">';
    html += `<div class="val-stat"><div class="val-stat-value" style="color:var(--green)">${data.passed_count}</div><div class="val-stat-label">Passed</div></div>`;
    html += `<div class="val-stat"><div class="val-stat-value" style="color:var(--red)">${data.failed_count}</div><div class="val-stat-label">Failed</div></div>`;
    html += `<div class="val-stat"><div class="val-stat-value">${data.health_score}</div><div class="val-stat-label">Score / 100</div></div>`;
    html += `<div class="val-stat"><div class="val-stat-value" style="color:${gradeColor(data.health_grade)}">${data.health_grade}</div><div class="val-stat-label">Grade</div></div>`;
    html += '</div>';

    if (data.results) {
      data.results.forEach(r => {
        html += `<div class="val-result-row">
          <div>
            <div style="font-weight:500">${r.rule.name}</div>
            <div style="font-size:0.78rem;color:var(--text-secondary)">${r.message}</div>
          </div>
          <span class="val-status ${r.passed ? 'val-pass' : 'val-fail'}">${r.passed ? '✅ PASS' : '❌ FAIL'}</span>
        </div>`;
      });
    }

    container.innerHTML = html;
    section.scrollIntoView({ behavior: 'smooth' });
  } catch (e) {
    console.error('Validation error:', e);
  } finally {
    btn.innerHTML = '<span>🔍</span> Run Validation';
    btn.disabled = false;
  }
}

// ---- Export ----
function exportReport() {
  window.print();
}

// ---- Initialize ----
document.addEventListener('DOMContentLoaded', () => {
  renderOverview();
  renderHeatmap();
  renderColumnDetails();
  renderRules();
});
