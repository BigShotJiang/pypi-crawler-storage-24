"""
Dashboard package — serves the interactive browser UI.
"""

from soflytics.dashboard.server import launch

__all__ = ["launch"]
