"""
Dashboard — app module (re-exports for convenience).
"""

from soflytics.dashboard.server import server_app, launch

__all__ = ["server_app", "launch"]
