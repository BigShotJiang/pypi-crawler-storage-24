"""
Dashboard server — FastAPI app and launch function.
"""

import json
import os
import threading
import time
import webbrowser
from typing import TYPE_CHECKING

import uvicorn
from fastapi import FastAPI
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

if TYPE_CHECKING:
    from soflytics.report.audit_report import AuditReport

# Global reference for the current report
_current_report = None

server_app = FastAPI(title="Soflytics Dashboard")

# Mount static files
_static_dir = os.path.join(os.path.dirname(__file__), "static")
server_app.mount("/static", StaticFiles(directory=_static_dir), name="static")


@server_app.get("/", response_class=HTMLResponse)
async def dashboard():
    """Serve the main dashboard page."""
    index_path = os.path.join(_static_dir, "index.html")

    with open(index_path, "r", encoding="utf-8") as f:
        html = f.read()

    # Inject profile data into the HTML
    if _current_report:
        profile_json = json.dumps(_current_report.profile.to_dict(), default=str)
        rules_json = json.dumps(
            [r.to_dict() for r in _current_report.suggest()], default=str
        )
        html = html.replace("__PROFILE_DATA__", profile_json)
        html = html.replace("__RULES_DATA__", rules_json)

    return HTMLResponse(content=html)


@server_app.get("/api/profile")
async def get_profile():
    """Return profile data as JSON."""
    if _current_report:
        return JSONResponse(content=_current_report.profile.to_dict())
    return JSONResponse(content={}, status_code=404)


@server_app.get("/api/rules")
async def get_rules():
    """Return suggested rules as JSON."""
    if _current_report:
        return JSONResponse(
            content=[r.to_dict() for r in _current_report.suggest()]
        )
    return JSONResponse(content=[], status_code=404)


@server_app.post("/api/validate")
async def run_validation():
    """Run validation with suggested rules and return results."""
    if _current_report:
        result = _current_report.validate()
        # Use json.dumps/loads to ensure numpy types are serializable
        content = json.loads(json.dumps(result.to_dict(), default=str))
        return JSONResponse(content=content)
    return JSONResponse(content={}, status_code=404)


def launch(report: "AuditReport", port: int = 8765):
    """Launch the dashboard server and open the browser."""
    global _current_report
    _current_report = report

    def open_browser():
        time.sleep(1.2)
        webbrowser.open(f"http://localhost:{port}")

    threading.Thread(target=open_browser, daemon=True).start()

    print(f"\n  🩺 Soflytics Dashboard running at http://localhost:{port}")
    print(f"  Press Ctrl+C to stop.\n")

    uvicorn.run(server_app, host="127.0.0.1", port=port, log_level="warning")
