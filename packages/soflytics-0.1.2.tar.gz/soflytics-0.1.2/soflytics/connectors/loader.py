"""
Data source loader — auto-detect and load any supported data source into a Pandas DataFrame.
"""

import os
from typing import Optional, Union

import pandas as pd


# Known database URL prefixes
_DB_PREFIXES = (
    "sqlite:///",
    "postgresql://",
    "postgres://",
    "mysql://",
    "mysql+pymysql://",
    "mssql://",
    "mssql+pyodbc://",
    "mssql+pymssql://",
)


def load(
    source: Union[str, pd.DataFrame, "polars.DataFrame"],
    table: Optional[str] = None,
    query: Optional[str] = None,
) -> pd.DataFrame:
    """
    Load a data source into a Pandas DataFrame.

    Supported sources:
        - pandas.DataFrame (pass-through)
        - polars.DataFrame (auto-convert)
        - str: file path to CSV, Parquet, JSON, Excel
        - str: database connection string (sqlite:///..., postgresql://..., mysql://...)

    Args:
        source: Data source — DataFrame, file path, or database URL.
        table: Table name to read (for database sources). If omitted, reads the first table found.
        query: SQL query to execute instead of reading a full table.
    """
    # Already a Pandas DataFrame
    if isinstance(source, pd.DataFrame):
        return source

    # Polars DataFrame — convert
    try:
        import polars as pl

        if isinstance(pl.DataFrame, type) and isinstance(source, pl.DataFrame):
            return source.to_pandas()
    except ImportError:
        pass

    # String — auto-detect: database URL or file path
    if isinstance(source, str):
        if any(source.startswith(prefix) for prefix in _DB_PREFIXES):
            return _load_database(source, table=table, query=query)
        return _load_file(source)

    raise ValueError(
        f"Unsupported data source type: {type(source).__name__}. "
        f"Pass a DataFrame, file path (CSV/Parquet/JSON), or database URL (sqlite:///...)."
    )


def _load_database(
    url: str,
    table: Optional[str] = None,
    query: Optional[str] = None,
) -> pd.DataFrame:
    """Load data from a database via SQLAlchemy."""
    try:
        from sqlalchemy import create_engine, inspect
    except ImportError:
        raise ImportError(
            "SQLAlchemy is required for database connections. "
            "Install it with: pip install sqlalchemy"
        )

    # Auto-fallback to pymssql for SQL Server to avoid ODBC driver issues
    if url.startswith("mssql://"):
        url = url.replace("mssql://", "mssql+pymssql://", 1)
        print("  💡 Auto-switching to pymssql driver for SQL Server (no ODBC needed).")

    engine = create_engine(url)

    # If a custom SQL query is provided, run it directly
    if query:
        return pd.read_sql_query(query, engine)

    # If no table name given, auto-detect the first table
    if not table:
        inspector = inspect(engine)
        tables = inspector.get_table_names()
        if not tables:
            raise ValueError(f"No tables found in database: {url}")
        table = tables[0]
        print(f"  📋 Auto-selected table: '{table}' (found {len(tables)} tables)")

    return pd.read_sql_table(table, engine)


def _load_file(path: str) -> pd.DataFrame:
    """Load a file into a DataFrame based on extension."""
    if not os.path.exists(path):
        raise FileNotFoundError(f"File not found: {path}")

    ext = os.path.splitext(path)[1].lower()

    if ext == ".csv":
        return pd.read_csv(path)
    elif ext == ".tsv":
        return pd.read_csv(path, sep="\t")
    elif ext in (".parquet", ".pq"):
        return pd.read_parquet(path)
    elif ext == ".json":
        return pd.read_json(path)
    elif ext in (".xlsx", ".xls"):
        return pd.read_excel(path)
    elif ext in (".db", ".sqlite", ".sqlite3"):
        # Auto-detect SQLite file and load via SQLAlchemy
        return _load_database(f"sqlite:///{os.path.abspath(path)}")
    else:
        # Try CSV as fallback
        try:
            return pd.read_csv(path)
        except Exception:
            raise ValueError(
                f"Unsupported file format: {ext}. "
                f"Supported: .csv, .tsv, .parquet, .json, .xlsx, .db"
            )

