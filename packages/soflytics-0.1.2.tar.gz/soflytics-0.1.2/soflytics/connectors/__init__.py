"""
Connectors package — auto-detect and load data sources.
"""

from soflytics.connectors.loader import load

__all__ = ["load"]
