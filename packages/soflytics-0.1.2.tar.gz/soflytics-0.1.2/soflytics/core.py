"""
Core module — the main audit() entry point.
"""

from typing import Optional, Union

import pandas as pd

from soflytics.connectors import load
from soflytics.profiler import profile
from soflytics.report.audit_report import AuditReport


def audit(
    source: Union[str, pd.DataFrame],
    table: Optional[str] = None,
    query: Optional[str] = None,
) -> AuditReport:
    """
    Audit any data source — profile it, detect issues, suggest rules.

    Usage:
        report = soflytics.audit("data.csv")
        report = soflytics.audit(df)
        report = soflytics.audit("sqlite:///my.db", table="users")
        report = soflytics.audit("postgresql://localhost/mydb", query="SELECT * FROM orders")

        report.to_console()       # Terminal output
        report.show()             # Browser dashboard
        rules = report.suggest()  # Auto-generated rules
    """
    # Load data into a DataFrame
    df = load(source, table=table, query=query)

    # Profile the data
    profile_result = profile(df)

    # Return an AuditReport
    return AuditReport(df=df, profile_result=profile_result)

