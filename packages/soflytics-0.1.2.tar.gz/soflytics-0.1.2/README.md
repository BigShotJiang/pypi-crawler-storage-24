<div align="center">
  <h1>🩺 Soflytics</h1>
  <p><b>Zero-config data quality for humans.</b></p>
  
  [![PyPI - Version](https://img.shields.io/pypi/v/soflytics.svg)](https://pypi.org/project/soflytics)
  [![Python Versions](https://img.shields.io/pypi/pyversions/soflytics.svg)](https://pypi.org/project/soflytics/)
  [![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

</div>

---

**Soflytics** is a radically simple data profiling and validation tool. 

Point it at any data source — a DataFrame, a CSV, or a SQL Database — and get instant profiling, smart validation rules, and a gorgeous visual health report. No YAML, no boilerplate, no configuration needed. Just plug and play.

## 🚀 Installation

```bash
# Basic installation (Files & Pandas)
pip install soflytics

# With Database Support (SQL Server, Postgres, MySQL)
pip install "soflytics[db]"
```

---

## 💻 Quickstart (Python API)

Soflytics exposes a beautifully simple API. One function does it all: `soflytics.audit()`.

```python
import soflytics

# 1. Audit any data source!
report = soflytics.audit("data.csv")                    # Local file
report = soflytics.audit(df)                            # Pandas DataFrame
report = soflytics.audit("sqlite:///users.db")          # SQLite Database
report = soflytics.audit("mssql://user:pass@host/db")   # SQL Server (No ODBC driver needed!)

# 2. View the results your way
report.to_console()              # A beautiful, rich terminal output
report.show()                    # Opens a premium interactive browser dashboard
report.to_html("report.html")    # Save as a standalone HTML file

# 3. Generate and run smart rules
rules = report.suggest()         # Auto-generates rules based on your data shape
result = report.validate(rules)  # Runs validation and scores the dataset
```

---

## 🛠️ Command Line Interface (CLI)

Prefer the terminal? Soflytics comes with a powerful CLI.

**Audit a file and see results in the terminal:**
```bash
soflytics audit data.csv
```

**Launch the interactive web dashboard:**
```bash
soflytics dashboard data.csv
```

**Connect directly to a database:**
```bash
soflytics dashboard "postgresql://user:password@localhost:5432/mydb" --table employees
```

---

## ✨ Features & What You Get

- **🧠 Auto-Profiling**: Instantly detects nulls, duplicates, outliers, type mismatches, and specific text patterns (like emails/phone numbers).
- **🤖 Smart Rules**: Generates plain-English validation rules automatically. (e.g., *"Age must be between 18 and 65"*, *"Email must match pattern"*).
- **📊 Visual Dashboard**: A premium, dark-themed local browser dashboard with per-column health grades, quality heatmaps, and drill-down details.
- **🔌 Universal Connectors**: Seamlessly handles Pandas, Polars, CSV, TSV, Parquet, JSON, Excel, SQLite, SQL Server, PostgreSQL, and MySQL.
- **⚡ Dead Simple**: Absolutely no setup required.

---

## 🤝 Contributing

Pull requests are welcome! For major changes, please open an issue first to discuss what you would like to change.

To set up a local development environment:
```bash
git clone https://github.com/Shammyhero/soflytics.git
cd soflytics
pip install -e ".[dev,db]"
```

## 📜 License

This project is licensed under the MIT License - see the LICENSE file for details.
