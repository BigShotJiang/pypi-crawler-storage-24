import os
import sqlite3
import pandas as pd
import pytest

from soflytics.connectors import load


@pytest.fixture
def sample_df():
    """Returns a simple DataFrame for testing."""
    return pd.DataFrame({
        "id": [1, 2, 3],
        "name": ["Alice", "Bob", "Charlie"],
        "age": [25, 30, 35]
    })


@pytest.fixture
def files_dir(tmp_path, sample_df):
    """Creates temporary files of various formats."""
    # CSV
    csv_path = tmp_path / "data.csv"
    sample_df.to_csv(csv_path, index=False)

    # TSV
    tsv_path = tmp_path / "data.tsv"
    sample_df.to_csv(tsv_path, sep="\t", index=False)

    # JSON
    json_path = tmp_path / "data.json"
    sample_df.to_json(json_path, orient="records")

    # Parquet
    parquet_path = tmp_path / "data.parquet"
    sample_df.to_parquet(parquet_path, index=False)

    # Excel
    excel_path = tmp_path / "data.xlsx"
    sample_df.to_excel(excel_path, index=False)

    # SQLite
    sqlite_path = tmp_path / "data.db"
    conn = sqlite3.connect(sqlite_path)
    sample_df.to_sql("users", conn, index=False)
    conn.close()

    return tmp_path


def test_load_pandas_df(sample_df):
    """Test loading an existing Pandas DataFrame."""
    df = load(sample_df)
    assert len(df) == 3
    assert list(df.columns) == ["id", "name", "age"]


def test_load_csv(files_dir):
    """Test loading a CSV file."""
    df = load(str(files_dir / "data.csv"))
    assert len(df) == 3
    assert df["name"][0] == "Alice"


def test_load_tsv(files_dir):
    """Test loading a TSV file."""
    df = load(str(files_dir / "data.tsv"))
    assert len(df) == 3
    assert df["name"][1] == "Bob"


def test_load_json(files_dir):
    """Test loading a JSON file."""
    df = load(str(files_dir / "data.json"))
    assert len(df) == 3
    assert df["name"][2] == "Charlie"


def test_load_parquet(files_dir):
    """Test loading a Parquet file."""
    df = load(str(files_dir / "data.parquet"))
    assert len(df) == 3


def test_load_excel(files_dir):
    """Test loading an Excel file."""
    df = load(str(files_dir / "data.xlsx"))
    assert len(df) == 3


def test_load_sqlite_file(files_dir):
    """Test auto-detecting a .db file and loading via SQLAlchemy."""
    db_path = str(files_dir / "data.db")
    df = load(db_path)
    assert len(df) == 3
    assert list(df.columns) == ["id", "name", "age"]


def test_load_sqlite_url(files_dir):
    """Test loading an SQLite URL."""
    db_path = str(files_dir / "data.db")
    url = f"sqlite:///{db_path}"
    df = load(url, table="users")
    assert len(df) == 3


def test_load_sqlite_url_auto_table(files_dir):
    """Test loading an SQLite URL with table auto-detection."""
    db_path = str(files_dir / "data.db")
    url = f"sqlite:///{db_path}"
    df = load(url)
    assert len(df) == 3


def test_load_sqlite_query(files_dir):
    """Test loading data using a custom SQL query."""
    db_path = str(files_dir / "data.db")
    url = f"sqlite:///{db_path}"
    df = load(url, query="SELECT * FROM users WHERE age > 30")
    assert len(df) == 1
    assert df["name"].iloc[0] == "Charlie"


def test_load_unsupported_file():
    """Test loading an unsupported file format."""
    with pytest.raises(FileNotFoundError):
        load("does_not_exist.txt")


def test_mssql_fallback_logic(mocker):
    """Test that mssql:// URLs automatically switch to mssql+pymssql://."""
    from soflytics.connectors.loader import _load_database

    # Mock create_engine and inspect so we don't actually connect
    mocker.patch("sqlalchemy.create_engine")
    mocker.patch("sqlalchemy.inspect")
    mock_read_sql = mocker.patch("pandas.read_sql_table")

    # Assuming we pass a plain mssql:// url
    _load_database("mssql://user:pass@localhost/db", table="test")
    
    # Check that create_engine was called with the fallback URL
    import sqlalchemy
    sqlalchemy.create_engine.assert_called_once_with("mssql+pymssql://user:pass@localhost/db")

