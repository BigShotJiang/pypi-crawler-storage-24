"""
The "Schizophrenic Artificial Intelligence" is a module used to invoke the Frankenstein and its submodels,
as well as other models of various distinct architectures, through the categorization of the loaded models and the user's inputs.
In this way, it selects the most appropriate and compatible model for each type of situation and returns the corresponding outputs,
derived from the inference of the current input converted into the output of the computed tokens.
"""
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
from setuptools import setup, find_packages
package_name = 'schizophrenic_artificial_intelligence'
version = '1.1.7'
setup(
    name=package_name,
    version=version,
    author='SAPIENS TECHNOLOGY',
    packages=find_packages(),
    install_requires=[
        'torch==2.4.1',
        'utilities-nlp',
        'semantic-comparison',
        'gptmodel',
        'sapiens-gpt',
        'sapiens-bert',
        'hurmodel',
        'INFINITE-CONTEXT-WINDOW',
        'sapiens-model',
        'sapiens-loader',
        'FRANKENSTEIN-MODEL'
    ],
    url='https://github.com/sapiens-technology/schizophrenic_artificial_intelligence',
    license='Proprietary Software'
)
"""
The "Schizophrenic Artificial Intelligence" is a module used to invoke the Frankenstein and its submodels,
as well as other models of various distinct architectures, through the categorization of the loaded models and the user's inputs.
In this way, it selects the most appropriate and compatible model for each type of situation and returns the corresponding outputs,
derived from the inference of the current input converted into the output of the computed tokens.
"""
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
