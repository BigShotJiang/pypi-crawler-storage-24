"""
The "Schizophrenic Artificial Intelligence" is a module used to invoke the Frankenstein and its submodels,
as well as other models of various distinct architectures, through the categorization of the loaded models and the user's inputs.
In this way, it selects the most appropriate and compatible model for each type of situation and returns the corresponding outputs,
derived from the inference of the current input converted into the output of the computed tokens.
"""
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
from .schizophrenic_artificial_intelligence import *
"""
The "Schizophrenic Artificial Intelligence" is a module used to invoke the Frankenstein and its submodels,
as well as other models of various distinct architectures, through the categorization of the loaded models and the user's inputs.
In this way, it selects the most appropriate and compatible model for each type of situation and returns the corresponding outputs,
derived from the inference of the current input converted into the output of the computed tokens.
"""
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
