# MDMP

MDMP is an open protocol for dataset quality and AI training provenance.

Tagline: **Know what your AI learned from.**

## What MDMP does

- Defines a dataset contract (`schema` + `consent`)
- Validates data and assigns a deterministic grade
- Generates immutable dataset fingerprints (`sha256:...`)
- Tracks model lineage and stale status when data changes/expires
- Produces audit-ready JSON/HTML artifacts

## Install

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -U pip
pip install -e .
```

## 60-second quickstart

```bash
mdmp init --flavor health --output contracts/mdmp_contract.yaml
mdmp validate contracts/mdmp_contract.yaml data/demo_cgm.csv --output-json results/mdmp_report.json
mdmp report results/mdmp_report.json --output-html results/mdmp_dashboard.html
```

## High-impact commands

```bash
# lineage + staleness
mdmp fingerprint-record data/demo_cgm.csv --output-json results/fingerprint.json --expires-days 365
mdmp lineage-card --model glucose_forecaster_v2 --dataset data/demo_cgm.csv --contract contracts/health_demo.yaml --output results/mdmp_model_card.yaml
mdmp lineage-card-refresh results/mdmp_model_card.yaml

# quality + audit
mdmp diff data/baseline.csv data/candidate.csv --output-json results/mdmp_diff.json
mdmp compare results/a.json results/b.json --output-json results/mdmp_compare.json
mdmp audit results/mdmp_report.json --output-json results/mdmp_audit.json --output-html results/mdmp_audit.html

# registry + federation
mdmp registry init --registry registry/mdmp_registry.json
mdmp registry push --registry registry/mdmp_registry.json --report results/mdmp_report.json --visibility public
mdmp registry export-public --registry registry/mdmp_registry.json --output-json registry/public_bundle.json
```

## Integrations

- `mdmp integrations dvc-stage`
- `mdmp integrations mlflow-log`
- `mdmp integrations wandb-log`
- Reusable GitHub Action: `action.yml`

## Documentation

- Full manual: `docs/manual/complete-manual.md`
- CLI reference: `docs/reference/cli.md`
- Spec: `MDMP_SPEC.md` (`v0.2-draft`)
- Launch checklist: `docs/launch/launch-checklist.md`
- Public docs site: [python35.github.io/MDMP](https://python35.github.io/MDMP/)

## Release and governance

- Current version: `0.2.0`
- Changelog: `CHANGELOG.md`
- Contributing: `CONTRIBUTING.md`
- License: `Apache-2.0`

## Safety note

MDMP provides provenance and data-quality metadata. It is not clinical decision support and not a medical device.
