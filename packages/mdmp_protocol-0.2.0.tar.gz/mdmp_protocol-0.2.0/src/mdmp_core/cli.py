from __future__ import annotations

from pathlib import Path
import json

import pandas as pd
import typer
import yaml

from mdmp_ai import LineageTracker, load_lineage_card
from mdmp_core.audit import build_audit_from_sources, build_audit_html
from mdmp_core.bias_hooks import run_bias_hooks
from mdmp_core.certification import create_certificate
from mdmp_core.compare import compare_reports
from mdmp_core.contracts import load_contract, parse_contract, save_contract
from mdmp_core.diffing import compare_datasets
from mdmp_core.fingerprint import check_fingerprint, compute_fingerprint
from mdmp_core.fingerprint_store import FingerprintStore
from mdmp_core.hf import build_hf_mdmp_section, load_report
from mdmp_core.llm_provenance import build_llm_training_card
from mdmp_core.registry import (
    export_public_bundle,
    import_public_bundle,
    init_registry,
    list_records,
    lookup_record,
    sync_public_bundle_from_url,
    upsert_record,
)
from mdmp_core.synthetic import build_synthetic_metadata
from mdmp_core.runner import ContractRunner, dataframe_fingerprint
from mdmp_core.visualizer import build_dashboard_html
from mdmp_integrations.dvc import build_dvc_stage, write_dvc_stage
from mdmp_integrations.mlflow import log_mdmp_artifact_to_mlflow
from mdmp_integrations.wandb import log_mdmp_artifact_to_wandb
from mdmp_flavors import BUILTIN_TEMPLATES, available_flavors, get_template, load_external_templates


app = typer.Typer(help="MDMP CLI - contracts, grading, fingerprints, and lineage")
registry_app = typer.Typer(help="MDMP registry scaffold commands")
flavors_app = typer.Typer(help="Flavor templates (built-in + plugin)")
integrations_app = typer.Typer(help="Integration helpers (MLflow, W&B, DVC)")
app.add_typer(registry_app, name="registry")
app.add_typer(flavors_app, name="flavors")
app.add_typer(integrations_app, name="integrations")


@app.command("init")
def init_contract(
    output: Path = typer.Option(Path("mdmp_contract.yaml"), help="Output contract file"),
    flavor: str = typer.Option("health", help="Template flavor: health|finance|industrial"),
) -> None:
    try:
        payload = get_template(flavor)
    except KeyError as exc:
        raise typer.BadParameter(str(exc))
    contract = parse_contract(payload)
    save_contract(output, contract)
    typer.echo(f"Created contract: {output}")


@flavors_app.command("list")
def flavors_list() -> None:
    all_flavors = available_flavors()
    built_in = sorted(BUILTIN_TEMPLATES.keys())
    external = load_external_templates()
    payload = {
        "flavors": all_flavors,
        "built_in": built_in,
        "external_plugins": sorted(external.keys()),
    }
    typer.echo(json.dumps(payload, indent=2))


@app.command("validate")
def validate(
    contract_path: Path,
    dataset_csv: Path,
    output_json: Path = typer.Option(Path("results/mdmp_report.json"), help="Output report JSON"),
    fingerprint_store: Path | None = typer.Option(
        None,
        help="Optional fingerprint store JSON for stale/expiry checks",
    ),
) -> None:
    contract = load_contract(contract_path)
    df = pd.read_csv(dataset_csv)
    result = ContractRunner(contract).run(df)
    payload = result.to_dict()
    payload["effective_grade"] = payload.get("grade")
    payload["effective_grade_reason"] = "base_grade"

    if fingerprint_store is not None:
        store = FingerprintStore(fingerprint_store)
        stored = store.get_by_dataset(str(dataset_csv))
        if stored is not None:
            staleness = check_fingerprint(stored, data_path=dataset_csv)
            payload["staleness"] = staleness
            warnings = payload.setdefault("warnings", [])
            if staleness.get("status") == "stale":
                reason = staleness.get("stale_reason", "unknown")
                warnings.append(
                    f"Dataset fingerprint is stale ({reason}). Re-grade required before AI training."
                )
                payload["effective_grade"] = "draft"
                payload["effective_grade_reason"] = f"stale_fingerprint_{reason}"

    output_json.parent.mkdir(parents=True, exist_ok=True)
    output_json.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    typer.echo(f"Saved report: {output_json}")
    typer.echo(f"Grade: {payload.get('effective_grade')} (base={result.grade}) | Compliance: {result.compliance_score}%")
    if payload.get("staleness", {}).get("status") == "stale":
        typer.echo(f"Staleness: STALE ({payload['staleness'].get('stale_reason')})")


@app.command("grade")
def grade(contract_path: Path, dataset_csv: Path) -> None:
    contract = load_contract(contract_path)
    df = pd.read_csv(dataset_csv)
    result = ContractRunner(contract).run(df)
    typer.echo(result.grade)


@app.command("fingerprint")
def fingerprint(dataset_csv: Path) -> None:
    df = pd.read_csv(dataset_csv)
    typer.echo(f"sha256:{dataframe_fingerprint(df)}")


@app.command("fingerprint-record")
def fingerprint_record(
    dataset_path: Path,
    output_json: Path = typer.Option(Path("results/fingerprint.json"), help="Output fingerprint JSON"),
    expires_days: int = typer.Option(365, help="Validity period in days"),
    fingerprint_store: Path | None = typer.Option(
        None,
        help="Optional fingerprint store JSON to upsert this record",
    ),
) -> None:
    record = compute_fingerprint(dataset_path, expires_days=expires_days)
    output_json.parent.mkdir(parents=True, exist_ok=True)
    output_json.write_text(json.dumps(record, indent=2), encoding="utf-8")
    typer.echo(f"Saved fingerprint record: {output_json}")
    typer.echo(f"Fingerprint: {record['fingerprint']}")
    typer.echo(f"Expires: {record['expires']}")

    if fingerprint_store is not None:
        store = FingerprintStore(fingerprint_store)
        store.upsert(dataset_path=str(dataset_path), record=record)
        typer.echo(f"Updated fingerprint store: {fingerprint_store}")


@app.command("fingerprint-check")
def fingerprint_check(
    fingerprint_json: Path,
    dataset_path: Path,
    output_json: Path | None = typer.Option(None, help="Optional output path for check result"),
) -> None:
    stored = json.loads(fingerprint_json.read_text(encoding="utf-8"))
    checked = check_fingerprint(stored, data_path=dataset_path)
    typer.echo(f"Fingerprint: {checked.get('fingerprint')}")
    typer.echo(f"Status: {str(checked.get('status', '')).upper()}")
    typer.echo(f"Reason: {checked.get('stale_reason')}")
    typer.echo(f"Created: {checked.get('created')}")
    typer.echo(f"Expires: {checked.get('expires')}")
    typer.echo(f"Checked at: {checked.get('checked_at')}")

    if output_json is not None:
        output_json.parent.mkdir(parents=True, exist_ok=True)
        output_json.write_text(json.dumps(checked, indent=2), encoding="utf-8")
        typer.echo(f"Saved check result: {output_json}")


@app.command("report")
def report(
    report_json: Path,
    output_html: Path = typer.Option(Path("results/mdmp_dashboard.html"), help="Output dashboard HTML"),
    title: str = typer.Option("MDMP Dashboard", help="HTML title"),
) -> None:
    payload = json.loads(report_json.read_text(encoding="utf-8"))
    html = build_dashboard_html(payload, title=title)
    output_html.parent.mkdir(parents=True, exist_ok=True)
    output_html.write_text(html, encoding="utf-8")
    typer.echo(f"Saved dashboard: {output_html}")


@app.command("diff")
def diff(
    baseline_csv: Path,
    candidate_csv: Path,
    contract_path: Path | None = typer.Option(None, help="Optional contract for bounds-aware diff"),
    output_json: Path = typer.Option(Path("results/mdmp_diff.json"), help="Output diff JSON"),
) -> None:
    baseline_df = pd.read_csv(baseline_csv)
    candidate_df = pd.read_csv(candidate_csv)
    contract = load_contract(contract_path) if contract_path is not None else None
    payload = compare_datasets(baseline_df, candidate_df, contract=contract)
    payload["baseline_csv"] = str(baseline_csv)
    payload["candidate_csv"] = str(candidate_csv)

    output_json.parent.mkdir(parents=True, exist_ok=True)
    output_json.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    typer.echo(f"Saved diff report: {output_json}")
    typer.echo(f"Changed: {payload['has_changes']}")
    typer.echo(f"Row delta: {payload['row_count']['delta']}")


@app.command("compare")
def compare(
    baseline_report_json: Path,
    candidate_report_json: Path,
    output_json: Path = typer.Option(Path("results/mdmp_compare.json"), help="Output comparison JSON"),
) -> None:
    baseline = json.loads(baseline_report_json.read_text(encoding="utf-8"))
    candidate = json.loads(candidate_report_json.read_text(encoding="utf-8"))
    payload = compare_reports(baseline=baseline, candidate=candidate)
    output_json.parent.mkdir(parents=True, exist_ok=True)
    output_json.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    typer.echo(f"Saved comparison: {output_json}")
    typer.echo(
        f"Grade delta rank: {payload['delta']['grade_rank']} | Score delta: {payload['delta']['compliance_score']}"
    )


@app.command("audit")
def audit(
    report_json: Path,
    lineage_card: Path | None = typer.Option(None, help="Optional lineage card (.yaml/.json)"),
    fingerprint_json: Path | None = typer.Option(None, help="Optional fingerprint record JSON"),
    registry_json: Path | None = typer.Option(None, help="Optional registry JSON"),
    validated_by: str = typer.Option("unknown", help="Actor/user that performed validation"),
    output_json: Path = typer.Option(Path("results/mdmp_audit.json"), help="Output audit JSON"),
    output_html: Path = typer.Option(Path("results/mdmp_audit.html"), help="Output audit HTML"),
) -> None:
    payload = build_audit_from_sources(
        report_json=report_json,
        lineage_card=lineage_card,
        fingerprint_json=fingerprint_json,
        registry_json=registry_json,
        validated_by=validated_by,
    )

    output_json.parent.mkdir(parents=True, exist_ok=True)
    output_json.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    output_html.parent.mkdir(parents=True, exist_ok=True)
    output_html.write_text(build_audit_html(payload), encoding="utf-8")

    typer.echo(f"Saved audit JSON: {output_json}")
    typer.echo(f"Saved audit HTML: {output_html}")
    typer.echo(f"Audit fingerprint: {payload.get('audit_fingerprint')}")


@app.command("bias-run")
def bias_run(
    report_json: Path,
    output_json: Path = typer.Option(Path("results/mdmp_bias_hooks.json"), help="Output hook results JSON"),
) -> None:
    report_payload = json.loads(report_json.read_text(encoding="utf-8"))
    payload = run_bias_hooks(report_payload)
    output_json.parent.mkdir(parents=True, exist_ok=True)
    output_json.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    typer.echo(f"Saved bias hook output: {output_json}")
    typer.echo(f"Hooks executed: {payload.get('hook_count', 0)}")


@app.command("certify")
def certify(
    report_json: Path,
    issued_by: str = typer.Option(..., help="Issuer id (team/user/system)"),
    level: str = typer.Option("research_grade", help="Certificate level"),
    output_json: Path = typer.Option(Path("results/mdmp_certificate.json"), help="Output certificate JSON"),
) -> None:
    report_payload = json.loads(report_json.read_text(encoding="utf-8"))
    payload = create_certificate(report_payload, issued_by=issued_by, level=level)
    output_json.parent.mkdir(parents=True, exist_ok=True)
    output_json.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    typer.echo(f"Saved certificate: {output_json}")
    typer.echo(f"Signature: {payload.get('signature_sha256')}")


@app.command("synthetic-track")
def synthetic_track(
    source_fingerprint: str = typer.Option(..., help="Source dataset fingerprint sha256:..."),
    generator: str = typer.Option(..., help="Generator model/system"),
    method: str = typer.Option("ctgan", help="Generation method"),
    privacy_epsilon: float | None = typer.Option(None, help="Optional DP epsilon"),
    notes: str | None = typer.Option(None, help="Optional notes"),
    output_json: Path = typer.Option(Path("results/mdmp_synthetic_metadata.json"), help="Output metadata JSON"),
) -> None:
    payload = build_synthetic_metadata(
        generator=generator,
        source_fingerprint=source_fingerprint,
        method=method,
        privacy_epsilon=privacy_epsilon,
        notes=notes,
    )
    output_json.parent.mkdir(parents=True, exist_ok=True)
    output_json.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    typer.echo(f"Saved synthetic metadata: {output_json}")


@app.command("llm-card")
def llm_card(
    model_name: str = typer.Option(..., help="Model name"),
    corpora_json: Path = typer.Option(..., help="JSON file with list of corpora entries"),
    tokenizer: str = typer.Option(..., help="Tokenizer id"),
    pretraining_tokens: int = typer.Option(..., help="Pretraining token count"),
    fine_tune_tokens: int = typer.Option(0, help="Fine-tune token count"),
    output: Path = typer.Option(Path("results/mdmp_llm_card.yaml"), help="Output LLM provenance card"),
) -> None:
    corpora = json.loads(corpora_json.read_text(encoding="utf-8"))
    if not isinstance(corpora, list):
        raise typer.BadParameter("corpora_json must contain a JSON list")
    payload = build_llm_training_card(
        model_name=model_name,
        corpora=corpora,
        tokenizer=tokenizer,
        pretraining_tokens=pretraining_tokens,
        fine_tune_tokens=fine_tune_tokens,
    )
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.suffix.lower() in {".yaml", ".yml"}:
        output.write_text(yaml.safe_dump(payload, sort_keys=False), encoding="utf-8")
    else:
        output.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    typer.echo(f"Saved LLM provenance card: {output}")


@app.command("lineage-card")
def lineage_card(
    model: str = typer.Option(..., help="Model name"),
    dataset: Path = typer.Option(..., help="Dataset CSV path"),
    contract: Path = typer.Option(..., help="Contract YAML path"),
    output: Path = typer.Option(Path("results/mdmp_model_card.yaml"), help="Output model card (.yaml/.json)"),
    expires_days: int = typer.Option(365, help="Validity period for dataset fingerprint in days"),
    fingerprint_store: Path | None = typer.Option(
        None,
        help="Optional fingerprint store JSON to persist lineage dataset fingerprints",
    ),
) -> None:
    tracker = LineageTracker()
    record = tracker.register_dataset(dataset, contract=contract, expires_days=expires_days)
    tracker.attach_to_model(model)
    card = tracker.export_card(output)

    typer.echo(f"Dataset registered: {record['fingerprint']} ({record['grade']})")
    typer.echo(f"Saved model card: {output}")
    typer.echo(yaml.safe_dump(card, sort_keys=False))

    if fingerprint_store is not None:
        store = FingerprintStore(fingerprint_store)
        store.upsert(
            dataset_path=str(dataset),
            record={
                "fingerprint": record["fingerprint"],
                "created": record["date_validated"],
                "expires": record["expires"],
                "source_path": str(dataset),
                "status": record.get("status", "valid"),
                "stale_reason": record.get("stale_reason"),
            },
        )
        typer.echo(f"Updated fingerprint store: {fingerprint_store}")


@app.command("lineage-card-refresh")
def lineage_card_refresh(
    card_path: Path,
    output: Path | None = typer.Option(None, help="Optional output path (default: overwrite input card)"),
    data_dir: Path | None = typer.Option(None, help="Optional data directory for resolving relative dataset paths"),
) -> None:
    card = load_lineage_card(card_path)
    card.refresh(data_dir=data_dir)

    destination = output or card_path
    payload = card.export(destination)
    stale = payload.get("model", {}).get("stale_datasets", [])
    typer.echo(f"Model: {payload.get('model', {}).get('name')}")
    typer.echo(f"Lineage status: {payload.get('model', {}).get('lineage_status')}")
    typer.echo(f"Stale datasets: {len(stale)}")
    typer.echo(f"Saved lineage card: {destination}")


@registry_app.command("init")
def registry_init(
    registry: Path = typer.Option(Path("registry/mdmp_registry.json"), help="Registry JSON path"),
) -> None:
    payload = init_registry(registry)
    typer.echo(f"Initialized registry: {registry}")
    typer.echo(f"Version: {payload['version']}")


@registry_app.command("push")
def registry_push(
    registry: Path = typer.Option(Path("registry/mdmp_registry.json"), help="Registry JSON path"),
    fingerprint: str | None = typer.Option(None, help="Dataset fingerprint (sha256:...)"),
    report: Path | None = typer.Option(None, help="Optional MDMP report JSON to ingest"),
    grade: str | None = typer.Option(None, help="Optional grade override"),
    source: str | None = typer.Option(None, help="Optional source label (dataset/report name)"),
    visibility: str = typer.Option("private", help="Record visibility: private|public"),
    model_id: list[str] = typer.Option([], help="Model id(s) using this dataset"),
    expires: str | None = typer.Option(None, help="Optional expires timestamp"),
    status: str | None = typer.Option(None, help="Optional status override: valid|stale"),
    stale_reason: str | None = typer.Option(None, help="Optional stale reason"),
    metadata_json: Path | None = typer.Option(None, help="Optional metadata JSON file"),
) -> None:
    report_payload = None
    if report is not None:
        report_payload = json.loads(report.read_text(encoding="utf-8"))
    metadata = None
    if metadata_json is not None:
        metadata = json.loads(metadata_json.read_text(encoding="utf-8"))
        if not isinstance(metadata, dict):
            raise typer.BadParameter("metadata_json must contain a JSON object")

    record = upsert_record(
        registry,
        fingerprint=fingerprint,
        report=report_payload,
        grade=grade,
        source=source,
        visibility=visibility,
        used_in_models=model_id,
        expires=expires,
        status=status,
        stale_reason=stale_reason,
        metadata=metadata,
    )
    typer.echo(f"Registry updated: {registry}")
    typer.echo(f"Fingerprint: {record['fingerprint']}")
    typer.echo(f"Grade: {record['grade']} | Status: {record['status']} | Visibility: {record['visibility']}")


@registry_app.command("lookup")
def registry_lookup(
    fingerprint: str,
    registry: Path = typer.Option(Path("registry/mdmp_registry.json"), help="Registry JSON path"),
    output_json: Path | None = typer.Option(None, help="Optional output JSON path"),
) -> None:
    record = lookup_record(registry, fingerprint)
    if record is None:
        typer.echo(f"Fingerprint not found: {fingerprint}")
        raise typer.Exit(code=1)
    text = json.dumps(record, indent=2)
    typer.echo(text)
    if output_json is not None:
        output_json.parent.mkdir(parents=True, exist_ok=True)
        output_json.write_text(text, encoding="utf-8")
        typer.echo(f"Saved lookup: {output_json}")


@registry_app.command("list")
def registry_list(
    registry: Path = typer.Option(Path("registry/mdmp_registry.json"), help="Registry JSON path"),
    grade: str | None = typer.Option(None, help="Filter by grade"),
    visibility: str | None = typer.Option(None, help="Filter by visibility"),
    status: str | None = typer.Option(None, help="Filter by status"),
    limit: int = typer.Option(20, help="Maximum rows"),
    output_json: Path | None = typer.Option(None, help="Optional output JSON path"),
) -> None:
    records = list_records(
        registry,
        grade=grade,
        visibility=visibility,
        status=status,
        limit=limit,
    )
    payload = {"count": len(records), "records": records}
    text = json.dumps(payload, indent=2)
    typer.echo(text)
    if output_json is not None:
        output_json.parent.mkdir(parents=True, exist_ok=True)
        output_json.write_text(text, encoding="utf-8")
        typer.echo(f"Saved list: {output_json}")


@registry_app.command("export-public")
def registry_export_public(
    registry: Path = typer.Option(Path("registry/mdmp_registry.json"), help="Registry JSON path"),
    output_json: Path = typer.Option(Path("registry/public_bundle.json"), help="Output public bundle JSON"),
) -> None:
    payload = export_public_bundle(registry, output_json)
    typer.echo(f"Exported public bundle: {output_json}")
    typer.echo(f"Public records: {len(payload.get('records', {}))}")


@registry_app.command("import-public")
def registry_import_public(
    bundle_json: Path,
    registry: Path = typer.Option(Path("registry/mdmp_registry.json"), help="Registry JSON path"),
    source: str = typer.Option("bundle", help="Source label for imported records"),
) -> None:
    payload = import_public_bundle(registry, bundle_json, source=source)
    typer.echo(f"Imported records: {payload['imported']}")
    typer.echo(f"Registry: {payload['registry']}")


@registry_app.command("sync-url")
def registry_sync_url(
    url: str = typer.Option(..., help="Public bundle URL (JSON)"),
    registry: Path = typer.Option(Path("registry/mdmp_registry.json"), help="Registry JSON path"),
    source: str = typer.Option("remote", help="Source label for imported records"),
) -> None:
    payload = sync_public_bundle_from_url(registry, url, source=source)
    typer.echo(f"Synced records: {payload['imported']}")
    typer.echo(f"Registry: {payload['registry']}")


@integrations_app.command("dvc-stage")
def integration_dvc_stage(
    contract_path: str = typer.Option(..., help="Contract path used in mdmp validate"),
    dataset_path: str = typer.Option(..., help="Dataset path used in mdmp validate"),
    report_path: str = typer.Option("results/mdmp_report.json", help="Validation output report path"),
    stage_name: str = typer.Option("mdmp_validate", help="DVC stage name"),
    output_yaml: Path = typer.Option(Path("dvc.yaml"), help="Output dvc.yaml path"),
) -> None:
    payload = build_dvc_stage(
        stage_name=stage_name,
        contract_path=contract_path,
        dataset_path=dataset_path,
        report_path=report_path,
    )
    write_dvc_stage(output_yaml, payload)
    typer.echo(f"Saved DVC stage: {output_yaml}")


@integrations_app.command("mlflow-log")
def integration_mlflow_log(
    artifact_path: Path = typer.Option(..., help="Artifact file to log"),
    target_path: str = typer.Option("mdmp", help="MLflow artifact path"),
) -> None:
    status = log_mdmp_artifact_to_mlflow(artifact_path, artifact_path=target_path)
    typer.echo(f"MLflow status: {status}")


@integrations_app.command("wandb-log")
def integration_wandb_log(
    artifact_path: Path = typer.Option(..., help="Artifact file to log"),
    name: str = typer.Option("mdmp-artifact", help="W&B artifact name"),
) -> None:
    status = log_mdmp_artifact_to_wandb(artifact_path, name=name)
    typer.echo(f"W&B status: {status}")


@app.command("hf-export")
def hf_export(
    dataset_id: str = typer.Option(..., help="Hugging Face dataset id (e.g. owner/name)"),
    report_json: Path | None = typer.Option(None, help="Optional MDMP report JSON"),
    fingerprint: str | None = typer.Option(None, help="Optional dataset fingerprint (sha256:...)"),
    grade: str | None = typer.Option(None, help="Optional grade override"),
    output_md: Path = typer.Option(Path("results/mdmp_hf_section.md"), help="Output Markdown path"),
    registry_url: str | None = typer.Option(None, help="Optional registry URL"),
) -> None:
    report = load_report(report_json) if report_json is not None else {}

    resolved_grade = grade or str(report.get("grade", report.get("mdmp_grade", "draft")))
    if fingerprint:
        resolved_fp = fingerprint
    else:
        fp_raw = report.get("dataset_fingerprint_sha256")
        if not fp_raw:
            raise typer.BadParameter("Provide --fingerprint or --report-json with dataset_fingerprint_sha256")
        resolved_fp = f"sha256:{fp_raw}" if not str(fp_raw).startswith("sha256:") else str(fp_raw)

    contract_fp_raw = report.get("contract_fingerprint_sha256")
    contract_fp = None
    if contract_fp_raw:
        contract_fp = (
            f"sha256:{contract_fp_raw}" if not str(contract_fp_raw).startswith("sha256:") else str(contract_fp_raw)
        )

    score = report.get("compliance_score")
    protocol = report.get("protocol_version", report.get("mdmp_protocol_version"))
    section = build_hf_mdmp_section(
        dataset_id=dataset_id,
        grade=resolved_grade,
        fingerprint=resolved_fp,
        contract_fingerprint=contract_fp,
        compliance_score=float(score) if score is not None else None,
        protocol_version=str(protocol) if protocol is not None else None,
        registry_url=registry_url,
    )
    output_md.parent.mkdir(parents=True, exist_ok=True)
    output_md.write_text(section, encoding="utf-8")
    typer.echo(f"Saved HF MDMP section: {output_md}")


if __name__ == "__main__":
    app()
