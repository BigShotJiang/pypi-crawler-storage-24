from __future__ import annotations

from pathlib import Path
import json

from typer.testing import CliRunner

from mdmp_core.cli import app
from mdmp_core.registry import lookup_record


def test_registry_init_push_lookup_roundtrip(tmp_path: Path) -> None:
    runner = CliRunner()
    registry = tmp_path / "registry.json"
    out_json = tmp_path / "lookup.json"

    result_init = runner.invoke(app, ["registry", "init", "--registry", str(registry)])
    assert result_init.exit_code == 0
    assert registry.is_file()

    result_push = runner.invoke(
        app,
        [
            "registry",
            "push",
            "--registry",
            str(registry),
            "--fingerprint",
            "sha256:abc123",
            "--grade",
            "ai_ready",
            "--source",
            "unit-test",
            "--visibility",
            "public",
            "--model-id",
            "model_v1",
        ],
    )
    assert result_push.exit_code == 0

    result_lookup = runner.invoke(
        app,
        [
            "registry",
            "lookup",
            "sha256:abc123",
            "--registry",
            str(registry),
            "--output-json",
            str(out_json),
        ],
    )
    assert result_lookup.exit_code == 0
    payload = json.loads(out_json.read_text(encoding="utf-8"))
    assert payload["fingerprint"] == "sha256:abc123"
    assert payload["grade"] == "ai_ready"
    assert payload["visibility"] == "public"


def test_registry_push_from_report_and_list_filter(tmp_path: Path) -> None:
    runner = CliRunner()
    registry = tmp_path / "registry.json"
    report = tmp_path / "report.json"
    list_json = tmp_path / "list.json"

    report.write_text(
        json.dumps(
            {
                "grade": "clinical_grade",
                "protocol_version": "1.0",
                "dataset_fingerprint_sha256": "deadbeef",
                "contract_fingerprint_sha256": "cafebabe",
                "row_count": 123,
                "consent_verified": True,
                "compliance_score": 98.2,
            }
        ),
        encoding="utf-8",
    )

    result_push = runner.invoke(
        app,
        [
            "registry",
            "push",
            "--registry",
            str(registry),
            "--report",
            str(report),
            "--visibility",
            "private",
        ],
    )
    assert result_push.exit_code == 0

    record = lookup_record(registry, "sha256:deadbeef")
    assert record is not None
    assert record["grade"] == "clinical_grade"
    assert record["consent_verified"] is True

    result_list = runner.invoke(
        app,
        [
            "registry",
            "list",
            "--registry",
            str(registry),
            "--grade",
            "clinical_grade",
            "--output-json",
            str(list_json),
        ],
    )
    assert result_list.exit_code == 0
    payload = json.loads(list_json.read_text(encoding="utf-8"))
    assert payload["count"] == 1
    assert payload["records"][0]["fingerprint"] == "sha256:deadbeef"
