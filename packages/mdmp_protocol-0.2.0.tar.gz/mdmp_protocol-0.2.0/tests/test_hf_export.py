from __future__ import annotations

from pathlib import Path
import json

from typer.testing import CliRunner

from mdmp_core.cli import app


def test_hf_export_from_report(tmp_path: Path) -> None:
    runner = CliRunner()
    report = tmp_path / "report.json"
    out_md = tmp_path / "hf.md"

    report.write_text(
        json.dumps(
            {
                "grade": "ai_ready",
                "dataset_fingerprint_sha256": "deadbeef",
                "contract_fingerprint_sha256": "cafebabe",
                "compliance_score": 100.0,
                "protocol_version": "1.0",
            }
        ),
        encoding="utf-8",
    )

    result = runner.invoke(
        app,
        [
            "hf-export",
            "--dataset-id",
            "python35/demo-cgm",
            "--report-json",
            str(report),
            "--output-md",
            str(out_md),
        ],
    )
    assert result.exit_code == 0
    text = out_md.read_text(encoding="utf-8")
    assert "## MDMP" in text
    assert "python35/demo-cgm" in text
    assert "sha256:deadbeef" in text
