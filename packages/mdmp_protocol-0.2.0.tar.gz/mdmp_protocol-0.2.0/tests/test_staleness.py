from __future__ import annotations

from pathlib import Path
import json

import pandas as pd

from mdmp_ai import LineageTracker, load_lineage_card
from mdmp_core.fingerprint import check_fingerprint, compute_fingerprint
from mdmp_core.fingerprint_store import FingerprintStore


def _write_csv(path: Path, values: list[float]) -> None:
    df = pd.DataFrame(
        {
            "timestamp": [f"2026-03-01T00:{idx:02d}:00Z" for idx in range(len(values))],
            "glucose": values,
        }
    )
    df.to_csv(path, index=False)


def test_fingerprint_valid_when_data_unchanged(tmp_path: Path) -> None:
    data = tmp_path / "data.csv"
    _write_csv(data, [110.0, 112.0, 115.0])
    record = compute_fingerprint(data, expires_days=30)

    checked = check_fingerprint(record, data_path=data)
    assert checked["status"] == "valid"
    assert checked["stale_reason"] is None


def test_fingerprint_stale_when_data_changes(tmp_path: Path) -> None:
    data = tmp_path / "data.csv"
    _write_csv(data, [110.0, 112.0, 115.0])
    record = compute_fingerprint(data, expires_days=30)

    _write_csv(data, [150.0, 151.0, 153.0])
    checked = check_fingerprint(record, data_path=data)
    assert checked["status"] == "stale"
    assert checked["stale_reason"] == "data_changed"


def test_fingerprint_stale_when_expired(tmp_path: Path) -> None:
    data = tmp_path / "data.csv"
    _write_csv(data, [110.0, 112.0, 115.0])
    record = compute_fingerprint(data, expires_days=30)
    record["expires"] = "2000-01-01T00:00:00Z"

    checked = check_fingerprint(record, data_path=data)
    assert checked["status"] == "stale"
    assert checked["stale_reason"] == "expired"


def test_lineage_card_propagates_stale_status(tmp_path: Path) -> None:
    root = Path(__file__).resolve().parents[1]
    contract = root / "contracts" / "health_demo.yaml"
    data = tmp_path / "data.csv"
    card_path = tmp_path / "lineage.yaml"

    _write_csv(data, [110.0, 112.0, 115.0])
    tracker = LineageTracker()
    tracker.register_dataset(data, contract=contract, expires_days=30)
    tracker.attach_to_model("demo_model")
    tracker.export_card(card_path)

    _write_csv(data, [180.0, 185.0, 190.0])
    card = load_lineage_card(card_path)
    card.refresh()
    payload = card.to_dict()

    assert payload["model"]["lineage_status"] == "stale"
    assert payload["model"]["stale_lineage"] is True
    assert len(payload["model"]["stale_datasets"]) == 1


def test_fingerprint_store_upsert_and_lookup(tmp_path: Path) -> None:
    data = tmp_path / "data.csv"
    store_path = tmp_path / "store.json"
    _write_csv(data, [110.0, 112.0, 115.0])

    record = compute_fingerprint(data, expires_days=30)
    store = FingerprintStore(store_path)
    store.upsert(dataset_path=str(data), record=record)

    by_dataset = store.get_by_dataset(str(data))
    by_fingerprint = store.get_by_fingerprint(record["fingerprint"])
    assert by_dataset is not None
    assert by_fingerprint is not None
    assert by_dataset["fingerprint"] == record["fingerprint"]

    payload = json.loads(store_path.read_text(encoding="utf-8"))
    assert "datasets" in payload
    assert "fingerprints" in payload
