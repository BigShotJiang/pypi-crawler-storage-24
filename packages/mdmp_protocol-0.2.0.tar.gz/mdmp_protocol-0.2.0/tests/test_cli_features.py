from __future__ import annotations

from pathlib import Path
import json

import pandas as pd
from typer.testing import CliRunner

from mdmp_core.cli import app
from mdmp_core.fingerprint import compute_fingerprint


def test_diff_command_reports_dataset_changes(tmp_path: Path) -> None:
    runner = CliRunner()
    baseline = tmp_path / "baseline.csv"
    candidate = tmp_path / "candidate.csv"
    output = tmp_path / "diff.json"

    pd.DataFrame(
        {
            "timestamp": ["2026-03-01T00:00:00Z", "2026-03-01T00:05:00Z"],
            "glucose": [110.0, 112.0],
        }
    ).to_csv(baseline, index=False)
    pd.DataFrame(
        {
            "timestamp": ["2026-03-01T00:00:00Z", "2026-03-01T00:05:00Z", "2026-03-01T00:10:00Z"],
            "glucose": [110.0, 118.0, 121.0],
        }
    ).to_csv(candidate, index=False)

    result = runner.invoke(
        app,
        ["diff", str(baseline), str(candidate), "--output-json", str(output)],
    )
    assert result.exit_code == 0

    payload = json.loads(output.read_text(encoding="utf-8"))
    assert payload["has_changes"] is True
    assert payload["row_count"]["delta"] == 1


def test_audit_command_generates_json_and_html(tmp_path: Path) -> None:
    runner = CliRunner()
    report = tmp_path / "report.json"
    fp_file = tmp_path / "fingerprint.json"
    output_json = tmp_path / "audit.json"
    output_html = tmp_path / "audit.html"
    data = tmp_path / "data.csv"

    pd.DataFrame(
        {
            "timestamp": ["2026-03-01T00:00:00Z", "2026-03-01T00:05:00Z"],
            "glucose": [110.0, 112.0],
        }
    ).to_csv(data, index=False)
    report.write_text(
        json.dumps(
            {
                "created_utc": "2026-03-01T12:00:00Z",
                "protocol_version": "1.0",
                "grade": "ai_ready",
                "grade_reason": "all_checks_passed_with_valid_consent",
                "dataset_fingerprint_sha256": "deadbeef",
                "contract_fingerprint_sha256": "cafebabe",
                "compliance_score": 99.0,
                "consent_verified": True,
                "consent_context": {"jurisdiction": "GDPR"},
            }
        ),
        encoding="utf-8",
    )
    fp_file.write_text(json.dumps(compute_fingerprint(data, expires_days=365)), encoding="utf-8")

    result = runner.invoke(
        app,
        [
            "audit",
            str(report),
            "--fingerprint-json",
            str(fp_file),
            "--validated-by",
            "ci-bot",
            "--output-json",
            str(output_json),
            "--output-html",
            str(output_html),
        ],
    )
    assert result.exit_code == 0
    payload = json.loads(output_json.read_text(encoding="utf-8"))
    assert payload["validated_by"] == "ci-bot"
    assert str(payload["audit_fingerprint"]).startswith("sha256:")
    assert output_html.is_file()


def test_compare_and_certify_commands(tmp_path: Path) -> None:
    runner = CliRunner()
    a = tmp_path / "a.json"
    b = tmp_path / "b.json"
    compare_out = tmp_path / "compare.json"
    cert_out = tmp_path / "cert.json"

    a.write_text(
        json.dumps({"grade": "research_grade", "compliance_score": 88.0, "dataset_fingerprint_sha256": "aaa"}),
        encoding="utf-8",
    )
    b.write_text(
        json.dumps(
            {
                "grade": "clinical_grade",
                "compliance_score": 96.5,
                "dataset_fingerprint_sha256": "bbb",
                "grade_reason": "all_checks_passed_with_valid_consent",
            }
        ),
        encoding="utf-8",
    )

    result_compare = runner.invoke(
        app,
        ["compare", str(a), str(b), "--output-json", str(compare_out)],
    )
    assert result_compare.exit_code == 0
    payload_compare = json.loads(compare_out.read_text(encoding="utf-8"))
    assert payload_compare["summary"]["better_grade"] is True

    result_cert = runner.invoke(
        app,
        ["certify", str(b), "--issued-by", "qa-team", "--output-json", str(cert_out)],
    )
    assert result_cert.exit_code == 0
    payload_cert = json.loads(cert_out.read_text(encoding="utf-8"))
    assert payload_cert["issued_by"] == "qa-team"
    assert len(payload_cert["signature_sha256"]) == 64


def test_registry_export_import_public_bundle(tmp_path: Path) -> None:
    runner = CliRunner()
    registry = tmp_path / "registry.json"
    bundle = tmp_path / "bundle.json"
    mirror_registry = tmp_path / "mirror_registry.json"

    runner.invoke(app, ["registry", "init", "--registry", str(registry)])
    push = runner.invoke(
        app,
        [
            "registry",
            "push",
            "--registry",
            str(registry),
            "--fingerprint",
            "sha256:pub1",
            "--grade",
            "research_grade",
            "--visibility",
            "public",
        ],
    )
    assert push.exit_code == 0

    export = runner.invoke(
        app,
        ["registry", "export-public", "--registry", str(registry), "--output-json", str(bundle)],
    )
    assert export.exit_code == 0
    payload_bundle = json.loads(bundle.read_text(encoding="utf-8"))
    assert "sha256:pub1" in payload_bundle["records"]

    import_result = runner.invoke(
        app,
        [
            "registry",
            "import-public",
            str(bundle),
            "--registry",
            str(mirror_registry),
            "--source",
            "unit-test",
        ],
    )
    assert import_result.exit_code == 0
    mirror = json.loads(mirror_registry.read_text(encoding="utf-8"))
    assert mirror["records"]["sha256:pub1"]["federated_source"] == "unit-test"


def test_flavors_llm_and_synthetic_commands(tmp_path: Path) -> None:
    runner = CliRunner()
    out_synth = tmp_path / "synthetic.json"
    corpora = tmp_path / "corpora.json"
    llm = tmp_path / "llm.yaml"

    result_flavors = runner.invoke(app, ["flavors", "list"])
    assert result_flavors.exit_code == 0
    payload = json.loads(result_flavors.stdout)
    assert "health" in payload["flavors"]
    assert "llm" in payload["flavors"]

    result_synth = runner.invoke(
        app,
        [
            "synthetic-track",
            "--source-fingerprint",
            "sha256:abc",
            "--generator",
            "ctgan-v1",
            "--output-json",
            str(out_synth),
        ],
    )
    assert result_synth.exit_code == 0
    synth_payload = json.loads(out_synth.read_text(encoding="utf-8"))
    assert synth_payload["synthetic"] is True

    corpora.write_text(
        json.dumps(
            [
                {"name": "corpus-a", "license": "cc-by", "tokens": 1000},
                {"name": "corpus-b", "license": "mit", "tokens": 2000},
            ]
        ),
        encoding="utf-8",
    )
    result_llm = runner.invoke(
        app,
        [
            "llm-card",
            "--model-name",
            "demo-llm",
            "--corpora-json",
            str(corpora),
            "--tokenizer",
            "bpe-demo",
            "--pretraining-tokens",
            "3000",
            "--output",
            str(llm),
        ],
    )
    assert result_llm.exit_code == 0
    assert llm.is_file()
