from __future__ import annotations

from pathlib import Path

import pandas as pd

from mdmp_core.contracts import load_contract, parse_contract
from mdmp_core.runner import ContractRunner, dataframe_fingerprint


def test_runner_grades_demo_dataset() -> None:
    root = Path(__file__).resolve().parents[1]
    contract = load_contract(root / "contracts" / "health_demo.yaml")
    df = pd.read_csv(root / "data" / "demo_cgm.csv")
    result = ContractRunner(contract).run(df)

    assert result.is_compliant is True
    assert result.grade in {"clinical_grade", "ai_ready"}
    assert isinstance(result.grade_reason, str) and len(result.grade_reason) > 0
    assert result.row_count == 5


def test_fingerprint_is_stable() -> None:
    root = Path(__file__).resolve().parents[1]
    df = pd.read_csv(root / "data" / "demo_cgm.csv")
    fp1 = dataframe_fingerprint(df)
    fp2 = dataframe_fingerprint(df)
    assert fp1 == fp2


def test_expired_consent_auto_downgrades_grade() -> None:
    contract = parse_contract(
        {
            "schema": {
                "name": "demo",
                "version": "1.0",
                "industry": "health",
                "columns": [
                    {"name": "timestamp", "type": "datetime", "required": True},
                    {"name": "glucose", "type": "float", "bounds": [40, 400], "required": True},
                ],
            },
            "consent": {
                "ai_training_allowed": True,
                "jurisdiction": "GDPR",
                "anonymized": True,
                "consent_date": "2025-01-01T00:00:00Z",
                "expiry": "2020-01-01T00:00:00Z",
            },
        }
    )
    df = pd.DataFrame(
        {
            "timestamp": ["2026-03-01T00:00:00Z", "2026-03-01T00:05:00Z"],
            "glucose": [110.0, 112.0],
        }
    )
    result = ContractRunner(contract).run(df)
    assert result.is_compliant is True
    assert result.consent_verified is False
    assert result.grade == "research_grade"
    assert result.grade_reason == "consent_window_not_valid"
