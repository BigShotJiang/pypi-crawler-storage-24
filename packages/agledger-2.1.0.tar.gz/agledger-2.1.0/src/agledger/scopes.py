"""
AGLedger SDK — API Key Scopes

Patent Pending. Copyright 2026 AGLedger LLC. All rights reserved.

Scopes narrow what a key can do within its role's ceiling.
null scopes = full access for the role (backward compat).
"""

from __future__ import annotations

from typing import Literal, TypedDict


class Scopes:
    """API key scope constants."""

    # Mandate lifecycle
    MANDATES_READ: str = "mandates:read"
    MANDATES_WRITE: str = "mandates:write"

    # Receipts
    RECEIPTS_READ: str = "receipts:read"
    RECEIPTS_WRITE: str = "receipts:write"

    # Webhooks
    WEBHOOKS_READ: str = "webhooks:read"
    WEBHOOKS_MANAGE: str = "webhooks:manage"

    # Audit & compliance
    AUDIT_READ: str = "audit:read"
    AUDIT_ANALYZE: str = "audit:analyze"
    COMPLIANCE_READ: str = "compliance:read"
    COMPLIANCE_WRITE: str = "compliance:write"

    # Agents
    AGENTS_READ: str = "agents:read"
    AGENTS_MANAGE: str = "agents:manage"

    # Disputes
    DISPUTES_READ: str = "disputes:read"
    DISPUTES_MANAGE: str = "disputes:manage"

    # Dashboard & events
    DASHBOARD_READ: str = "dashboard:read"
    EVENTS_READ: str = "events:read"
    SIGNALS_READ: str = "signals:read"
    REPUTATION_READ: str = "reputation:read"

    # Schemas
    SCHEMAS_READ: str = "schemas:read"
    SCHEMAS_WRITE: str = "schemas:write"
    SCHEMAS_ADMIN: str = "schemas:admin"
    SCHEMAS_PUBLISH: str = "schemas:publish"

    # Administration
    ADMIN_KEYS: str = "admin:keys"
    ADMIN_SYSTEM: str = "admin:system"
    ADMIN_TRUST: str = "admin:trust"


class ScopeProfile(TypedDict):
    """Scope profile definition."""

    name: str
    description: str
    scopes: tuple[str, ...]


ScopeProfileName = Literal[
    "sidecar",
    "dashboard",
    "iac-pipeline",
    "agent-full",
    "agent-readonly",
    "schema-manager",
]

SCOPE_PROFILES: dict[ScopeProfileName, ScopeProfile] = {
    "sidecar": {
        "name": "sidecar",
        "description": "Governance sidecar — mandate and receipt operations",
        "scopes": (
            Scopes.MANDATES_READ,
            Scopes.MANDATES_WRITE,
            Scopes.RECEIPTS_WRITE,
            Scopes.WEBHOOKS_MANAGE,
        ),
    },
    "dashboard": {
        "name": "dashboard",
        "description": "Read-only monitoring and audit",
        "scopes": (
            Scopes.DASHBOARD_READ,
            Scopes.AUDIT_READ,
            Scopes.EVENTS_READ,
            Scopes.SIGNALS_READ,
            Scopes.DISPUTES_READ,
            Scopes.REPUTATION_READ,
            Scopes.SCHEMAS_READ,
        ),
    },
    "iac-pipeline": {
        "name": "iac-pipeline",
        "description": "Infrastructure provisioning — agents, webhooks, keys",
        "scopes": (
            Scopes.AGENTS_MANAGE,
            Scopes.WEBHOOKS_MANAGE,
            Scopes.ADMIN_KEYS,
            Scopes.SCHEMAS_WRITE,
            Scopes.SCHEMAS_ADMIN,
        ),
    },
    "agent-full": {
        "name": "agent-full",
        "description": "Standard agent — mandate and receipt operations",
        "scopes": (
            Scopes.MANDATES_READ,
            Scopes.MANDATES_WRITE,
            Scopes.RECEIPTS_WRITE,
        ),
    },
    "agent-readonly": {
        "name": "agent-readonly",
        "description": "Read-only agent — view mandate history",
        "scopes": (
            Scopes.MANDATES_READ,
            Scopes.RECEIPTS_READ,
        ),
    },
    "schema-manager": {
        "name": "schema-manager",
        "description": "Schema registry management — create, version, deprecate custom types",
        "scopes": (
            Scopes.SCHEMAS_READ,
            Scopes.SCHEMAS_WRITE,
            Scopes.SCHEMAS_ADMIN,
        ),
    },
}
