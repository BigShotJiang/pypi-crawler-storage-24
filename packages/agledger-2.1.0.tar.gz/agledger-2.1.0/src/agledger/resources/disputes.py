"""Disputes resource."""

from __future__ import annotations

from typing import Any

from agledger._http import AsyncHttpClient, HttpClient
from agledger.types import Dispute, Page


class DisputesResource:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def create(self, mandate_id: str, receipt_id: str, *, grounds: str, context: str | None = None) -> Dispute:
        body: dict[str, Any] = {"grounds": grounds}
        if context is not None: body["context"] = context
        return Dispute.model_validate(self._http.post(f"/v1/mandates/{mandate_id}/receipts/{receipt_id}/disputes", json=body))

    def get(self, dispute_id: str) -> Dispute:
        return Dispute.model_validate(self._http.get(f"/v1/disputes/{dispute_id}"))

    def list(self, mandate_id: str) -> Page[Dispute]:
        raw = self._http.get_page(f"/v1/mandates/{mandate_id}/disputes")
        raw["data"] = [Dispute.model_validate(d) for d in raw.get("data", [])]
        return Page[Dispute].model_validate(raw)

    def resolve(self, dispute_id: str, *, resolution: str, amount: float | None = None) -> Dispute:
        body: dict[str, Any] = {"resolution": resolution}
        if amount is not None: body["amount"] = amount
        return Dispute.model_validate(self._http.post(f"/v1/disputes/{dispute_id}/resolve", json=body))


class AsyncDisputesResource:
    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def create(self, mandate_id: str, receipt_id: str, *, grounds: str, context: str | None = None) -> Dispute:
        body: dict[str, Any] = {"grounds": grounds}
        if context is not None: body["context"] = context
        return Dispute.model_validate(await self._http.post(f"/v1/mandates/{mandate_id}/receipts/{receipt_id}/disputes", json=body))

    async def get(self, dispute_id: str) -> Dispute:
        return Dispute.model_validate(await self._http.get(f"/v1/disputes/{dispute_id}"))

    async def list(self, mandate_id: str) -> Page[Dispute]:
        raw = await self._http.get_page(f"/v1/mandates/{mandate_id}/disputes")
        raw["data"] = [Dispute.model_validate(d) for d in raw.get("data", [])]
        return Page[Dispute].model_validate(raw)

    async def resolve(self, dispute_id: str, *, resolution: str, amount: float | None = None) -> Dispute:
        body: dict[str, Any] = {"resolution": resolution}
        if amount is not None: body["amount"] = amount
        return Dispute.model_validate(await self._http.post(f"/v1/disputes/{dispute_id}/resolve", json=body))
