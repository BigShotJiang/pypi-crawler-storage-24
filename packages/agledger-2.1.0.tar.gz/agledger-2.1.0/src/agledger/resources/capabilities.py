"""Capabilities resource."""

from __future__ import annotations

from typing import Any

from agledger._http import AsyncHttpClient, HttpClient


class CapabilitiesResource:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def get(self, agent_id: str) -> dict[str, Any]:
        return self._http.get(f"/v1/agents/{agent_id}/capabilities")

    def set(self, agent_id: str, *, capabilities: list[str]) -> dict[str, Any]:
        return self._http.put(f"/v1/agents/{agent_id}/capabilities", json={"capabilities": capabilities}) if hasattr(self._http, "put") else self._http.patch(f"/v1/agents/{agent_id}/capabilities", json={"capabilities": capabilities})


class AsyncCapabilitiesResource:
    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def get(self, agent_id: str) -> dict[str, Any]:
        return await self._http.get(f"/v1/agents/{agent_id}/capabilities")

    async def set(self, agent_id: str, *, capabilities: list[str]) -> dict[str, Any]:
        return await self._http.patch(f"/v1/agents/{agent_id}/capabilities", json={"capabilities": capabilities})
