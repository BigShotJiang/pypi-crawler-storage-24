"""Health resource."""

from __future__ import annotations
from agledger._http import AsyncHttpClient, HttpClient
from agledger.types import HealthResponse


class HealthResource:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def check(self) -> HealthResponse:
        return HealthResponse.model_validate(self._http.get("/v1/health"))


class AsyncHealthResource:
    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def check(self) -> HealthResponse:
        return HealthResponse.model_validate(await self._http.get("/v1/health"))
