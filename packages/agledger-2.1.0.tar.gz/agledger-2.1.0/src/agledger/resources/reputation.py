"""Reputation resource."""

from __future__ import annotations
from typing import Any
from agledger._http import AsyncHttpClient, HttpClient
from agledger.types import ReputationScore


class ReputationResource:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def get_agent(self, agent_id: str) -> ReputationScore:
        data = self._http.get(f"/v1/reputation/{agent_id}")
        return ReputationScore.model_validate(data)


class AsyncReputationResource:
    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def get_agent(self, agent_id: str) -> ReputationScore:
        data = await self._http.get(f"/v1/reputation/{agent_id}")
        return ReputationScore.model_validate(data)
