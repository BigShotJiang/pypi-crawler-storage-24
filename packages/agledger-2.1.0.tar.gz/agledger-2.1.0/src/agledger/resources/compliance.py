"""Compliance resource."""

from __future__ import annotations

from typing import Any

from agledger._http import AsyncHttpClient, HttpClient


class ComplianceResource:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def export(self, **params: Any) -> dict[str, Any]:
        return self._http.post("/v1/compliance/export", json=params)

    def get_export(self, export_id: str) -> dict[str, Any]:
        return self._http.get(f"/v1/compliance/export/{export_id}")

    def get_ai_act_report(self, enterprise_id: str) -> dict[str, Any]:
        return self._http.get(f"/v1/compliance/eu-ai-act/{enterprise_id}")


class AsyncComplianceResource:
    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def export(self, **params: Any) -> dict[str, Any]:
        return await self._http.post("/v1/compliance/export", json=params)

    async def get_export(self, export_id: str) -> dict[str, Any]:
        return await self._http.get(f"/v1/compliance/export/{export_id}")

    async def get_ai_act_report(self, enterprise_id: str) -> dict[str, Any]:
        return await self._http.get(f"/v1/compliance/eu-ai-act/{enterprise_id}")
