"""Webhooks resource."""

from __future__ import annotations
from typing import Any
from agledger._http import AsyncHttpClient, HttpClient
from agledger.types import Page, Webhook


class WebhooksResource:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def create(self, **params: Any) -> Webhook:
        data = self._http.post("/v1/webhooks", json=params)
        return Webhook.model_validate(data)

    def get(self, webhook_id: str) -> Webhook:
        data = self._http.get(f"/v1/webhooks/{webhook_id}")
        return Webhook.model_validate(data)

    def list(self, **params: Any) -> Page:
        return Page.model_validate(self._http.get_page("/v1/webhooks", params=params))

    def delete(self, webhook_id: str) -> None:
        self._http.delete(f"/v1/webhooks/{webhook_id}")


class AsyncWebhooksResource:
    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def create(self, **params: Any) -> Webhook:
        data = await self._http.post("/v1/webhooks", json=params)
        return Webhook.model_validate(data)

    async def get(self, webhook_id: str) -> Webhook:
        data = await self._http.get(f"/v1/webhooks/{webhook_id}")
        return Webhook.model_validate(data)

    async def list(self, **params: Any) -> Page:
        return Page.model_validate(await self._http.get_page("/v1/webhooks", params=params))

    async def delete(self, webhook_id: str) -> None:
        await self._http.delete(f"/v1/webhooks/{webhook_id}")
