"""Registration resource."""

from __future__ import annotations

from typing import Any

from agledger._http import AsyncHttpClient, HttpClient
from agledger.types import AccountProfile, RegisterResult


class RegistrationResource:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def register(self, *, account_type: str, email: str, legal_name: str, contact_email: str | None = None) -> RegisterResult:
        body: dict[str, Any] = {"accountType": account_type, "email": email, "legalName": legal_name}
        if contact_email is not None: body["contactEmail"] = contact_email
        return RegisterResult.model_validate(self._http.post("/v1/register", json=body))

    def get_me(self) -> AccountProfile:
        return AccountProfile.model_validate(self._http.get("/v1/auth/me"))


class AsyncRegistrationResource:
    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def register(self, *, account_type: str, email: str, legal_name: str, contact_email: str | None = None) -> RegisterResult:
        body: dict[str, Any] = {"accountType": account_type, "email": email, "legalName": legal_name}
        if contact_email is not None: body["contactEmail"] = contact_email
        return RegisterResult.model_validate(await self._http.post("/v1/register", json=body))

    async def get_me(self) -> AccountProfile:
        return AccountProfile.model_validate(await self._http.get("/v1/auth/me"))
