"""Proxy resource — governance sidecar sessions, tool calls, sidecar mandates, receipts, tool catalog, analytics."""

from __future__ import annotations

from typing import Any

from agledger._http import AsyncHttpClient, HttpClient


class ProxyResource:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    # -- Sessions --

    def create_session(self, **params: Any) -> dict[str, Any]:
        """Create a new proxy session."""
        body = _to_camel(params)
        return self._http.post("/v1/proxy/sessions", json=body)

    def get_session(self, session_id: str) -> dict[str, Any]:
        """Get a proxy session by ID."""
        return self._http.get(f"/v1/proxy/sessions/{session_id}")

    def list_sessions(self, **params: Any) -> dict[str, Any]:
        """List proxy sessions."""
        return self._http.get_page("/v1/proxy/sessions", params=_to_camel(params))

    def sync_session(self, **params: Any) -> dict[str, Any]:
        """Unified sync: session + tool calls + sidecar mandates + sidecar receipts + tool catalog in a single request."""
        body = _to_camel(params)
        return self._http.post("/v1/proxy/sync", json=body)

    # -- Tool Calls --

    def ingest_tool_calls(self, session_id: str, items: list[dict[str, Any]]) -> dict[str, Any]:
        """Ingest a batch of tool calls for a session."""
        return self._http.post(f"/v1/proxy/sessions/{session_id}/tool-calls", json={"items": items})

    def list_tool_calls(self, session_id: str, **params: Any) -> dict[str, Any]:
        """List tool calls for a session."""
        return self._http.get_page(f"/v1/proxy/sessions/{session_id}/tool-calls", params=_to_camel(params))

    # -- Sidecar Mandates --

    def ingest_sidecar_mandates(self, session_id: str, items: list[dict[str, Any]]) -> dict[str, Any]:
        """Ingest a batch of sidecar mandates for a session."""
        return self._http.post(f"/v1/proxy/sessions/{session_id}/sidecar-mandates", json={"items": items})

    def list_sidecar_mandates(self, **params: Any) -> dict[str, Any]:
        """List sidecar mandates across sessions, optionally filtered by session_id."""
        return self._http.get_page("/v1/proxy/sidecar-mandates", params=_to_camel(params))

    def list_sidecar_mandates_by_session(self, session_id: str, **params: Any) -> dict[str, Any]:
        """List sidecar mandates for a specific session."""
        return self._http.get_page(f"/v1/proxy/sessions/{session_id}/sidecar-mandates", params=_to_camel(params))

    def update_sidecar_mandate(self, mandate_id: str, **params: Any) -> dict[str, Any]:
        """Update a sidecar mandate (e.g., formalize or dismiss)."""
        body = _to_camel(params)
        return self._http.patch(f"/v1/proxy/sidecar-mandates/{mandate_id}", json=body)

    def formalize_sidecar_mandate(self, mandate_id: str, formalized_mandate_id: str) -> dict[str, Any]:
        """Formalize a sidecar mandate by linking it to a backend mandate ID."""
        return self.update_sidecar_mandate(mandate_id, status="FORMALIZED", formalized_mandate_id=formalized_mandate_id)

    def dismiss_sidecar_mandate(self, mandate_id: str) -> dict[str, Any]:
        """Dismiss a sidecar mandate (mark as not actionable)."""
        return self.update_sidecar_mandate(mandate_id, status="DISMISSED")

    # -- Sidecar Receipts --

    def ingest_sidecar_receipts(self, session_id: str, items: list[dict[str, Any]]) -> dict[str, Any]:
        """Ingest a batch of sidecar receipts for a session."""
        return self._http.post(f"/v1/proxy/sessions/{session_id}/sidecar-receipts", json={"items": items})

    def list_sidecar_receipts_by_session(self, session_id: str, **params: Any) -> dict[str, Any]:
        """List sidecar receipts for a specific session."""
        return self._http.get_page(f"/v1/proxy/sessions/{session_id}/sidecar-receipts", params=_to_camel(params))

    # -- Tool Catalog --

    def ingest_tool_catalog(self, session_id: str, items: list[dict[str, Any]]) -> dict[str, Any]:
        """Ingest a batch of tool catalog entries for a session."""
        return self._http.post(f"/v1/proxy/sessions/{session_id}/tool-catalog", json={"items": items})

    def list_tool_catalog(self, session_id: str) -> dict[str, Any]:
        """List tool catalog entries for a session."""
        return self._http.get_page(f"/v1/proxy/sessions/{session_id}/tool-catalog", params={})

    # -- Analytics --

    def get_session_analytics(self, session_id: str) -> dict[str, Any]:
        """Get analytics for a specific session."""
        return self._http.get(f"/v1/proxy/sessions/{session_id}/analytics")

    def get_analytics_summary(self, **params: Any) -> dict[str, Any]:
        """Get aggregated analytics summary across sessions."""
        return self._http.get("/v1/proxy/analytics", params=_to_camel(params))

    def get_mandate_summary(self, session_id: str) -> dict[str, Any]:
        """Get mandate summary for a session (detected vs formalized counts)."""
        return self._http.get(f"/v1/proxy/sessions/{session_id}/mandate-summary")

    def get_alignment(self, session_id: str) -> dict[str, Any]:
        """Get alignment analysis for a session (coverage gaps, missing categories)."""
        return self._http.get(f"/v1/proxy/sessions/{session_id}/alignment")


class AsyncProxyResource:
    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    # -- Sessions --

    async def create_session(self, **params: Any) -> dict[str, Any]:
        """Create a new proxy session."""
        body = _to_camel(params)
        return await self._http.post("/v1/proxy/sessions", json=body)

    async def get_session(self, session_id: str) -> dict[str, Any]:
        """Get a proxy session by ID."""
        return await self._http.get(f"/v1/proxy/sessions/{session_id}")

    async def list_sessions(self, **params: Any) -> dict[str, Any]:
        """List proxy sessions."""
        return await self._http.get_page("/v1/proxy/sessions", params=_to_camel(params))

    async def sync_session(self, **params: Any) -> dict[str, Any]:
        """Unified sync: session + tool calls + sidecar mandates + sidecar receipts + tool catalog in a single request."""
        body = _to_camel(params)
        return await self._http.post("/v1/proxy/sync", json=body)

    # -- Tool Calls --

    async def ingest_tool_calls(self, session_id: str, items: list[dict[str, Any]]) -> dict[str, Any]:
        """Ingest a batch of tool calls for a session."""
        return await self._http.post(f"/v1/proxy/sessions/{session_id}/tool-calls", json={"items": items})

    async def list_tool_calls(self, session_id: str, **params: Any) -> dict[str, Any]:
        """List tool calls for a session."""
        return await self._http.get_page(f"/v1/proxy/sessions/{session_id}/tool-calls", params=_to_camel(params))

    # -- Sidecar Mandates --

    async def ingest_sidecar_mandates(self, session_id: str, items: list[dict[str, Any]]) -> dict[str, Any]:
        """Ingest a batch of sidecar mandates for a session."""
        return await self._http.post(f"/v1/proxy/sessions/{session_id}/sidecar-mandates", json={"items": items})

    async def list_sidecar_mandates(self, **params: Any) -> dict[str, Any]:
        """List sidecar mandates across sessions, optionally filtered by session_id."""
        return await self._http.get_page("/v1/proxy/sidecar-mandates", params=_to_camel(params))

    async def list_sidecar_mandates_by_session(self, session_id: str, **params: Any) -> dict[str, Any]:
        """List sidecar mandates for a specific session."""
        return await self._http.get_page(f"/v1/proxy/sessions/{session_id}/sidecar-mandates", params=_to_camel(params))

    async def update_sidecar_mandate(self, mandate_id: str, **params: Any) -> dict[str, Any]:
        """Update a sidecar mandate (e.g., formalize or dismiss)."""
        body = _to_camel(params)
        return await self._http.patch(f"/v1/proxy/sidecar-mandates/{mandate_id}", json=body)

    async def formalize_sidecar_mandate(self, mandate_id: str, formalized_mandate_id: str) -> dict[str, Any]:
        """Formalize a sidecar mandate by linking it to a backend mandate ID."""
        return await self.update_sidecar_mandate(mandate_id, status="FORMALIZED", formalized_mandate_id=formalized_mandate_id)

    async def dismiss_sidecar_mandate(self, mandate_id: str) -> dict[str, Any]:
        """Dismiss a sidecar mandate (mark as not actionable)."""
        return await self.update_sidecar_mandate(mandate_id, status="DISMISSED")

    # -- Sidecar Receipts --

    async def ingest_sidecar_receipts(self, session_id: str, items: list[dict[str, Any]]) -> dict[str, Any]:
        """Ingest a batch of sidecar receipts for a session."""
        return await self._http.post(f"/v1/proxy/sessions/{session_id}/sidecar-receipts", json={"items": items})

    async def list_sidecar_receipts_by_session(self, session_id: str, **params: Any) -> dict[str, Any]:
        """List sidecar receipts for a specific session."""
        return await self._http.get_page(f"/v1/proxy/sessions/{session_id}/sidecar-receipts", params=_to_camel(params))

    # -- Tool Catalog --

    async def ingest_tool_catalog(self, session_id: str, items: list[dict[str, Any]]) -> dict[str, Any]:
        """Ingest a batch of tool catalog entries for a session."""
        return await self._http.post(f"/v1/proxy/sessions/{session_id}/tool-catalog", json={"items": items})

    async def list_tool_catalog(self, session_id: str) -> dict[str, Any]:
        """List tool catalog entries for a session."""
        return await self._http.get_page(f"/v1/proxy/sessions/{session_id}/tool-catalog", params={})

    # -- Analytics --

    async def get_session_analytics(self, session_id: str) -> dict[str, Any]:
        """Get analytics for a specific session."""
        return await self._http.get(f"/v1/proxy/sessions/{session_id}/analytics")

    async def get_analytics_summary(self, **params: Any) -> dict[str, Any]:
        """Get aggregated analytics summary across sessions."""
        return await self._http.get("/v1/proxy/analytics", params=_to_camel(params))

    async def get_mandate_summary(self, session_id: str) -> dict[str, Any]:
        """Get mandate summary for a session (detected vs formalized counts)."""
        return await self._http.get(f"/v1/proxy/sessions/{session_id}/mandate-summary")

    async def get_alignment(self, session_id: str) -> dict[str, Any]:
        """Get alignment analysis for a session (coverage gaps, missing categories)."""
        return await self._http.get(f"/v1/proxy/sessions/{session_id}/alignment")


def _to_camel(d: dict[str, Any]) -> dict[str, Any]:
    """Convert snake_case keys to camelCase for API."""
    result: dict[str, Any] = {}
    for k, v in d.items():
        if v is None:
            continue
        parts = k.split("_")
        key = parts[0] + "".join(p.capitalize() for p in parts[1:])
        result[key] = v
    return result
