"""Admin resource — platform-level operations."""

from __future__ import annotations

from typing import Any

from agledger._http import AsyncHttpClient, HttpClient


class AdminResource:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def list_enterprises(self, **params: Any) -> dict[str, Any]:
        return self._http.get_page("/v1/admin/enterprises", params=params)

    def list_agents(self, **params: Any) -> dict[str, Any]:
        return self._http.get_page("/v1/admin/agents", params=params)

    def update_trust_level(self, entity_id: str, *, trust_level: str) -> dict[str, Any]:
        return self._http.patch(f"/v1/admin/entities/{entity_id}/trust", json={"trustLevel": trust_level})

    def get_system_health(self) -> dict[str, Any]:
        return self._http.get("/v1/admin/health")


class AsyncAdminResource:
    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def list_enterprises(self, **params: Any) -> dict[str, Any]:
        return await self._http.get_page("/v1/admin/enterprises", params=params)

    async def list_agents(self, **params: Any) -> dict[str, Any]:
        return await self._http.get_page("/v1/admin/agents", params=params)

    async def update_trust_level(self, entity_id: str, *, trust_level: str) -> dict[str, Any]:
        return await self._http.patch(f"/v1/admin/entities/{entity_id}/trust", json={"trustLevel": trust_level})

    async def get_system_health(self) -> dict[str, Any]:
        return await self._http.get("/v1/admin/health")
