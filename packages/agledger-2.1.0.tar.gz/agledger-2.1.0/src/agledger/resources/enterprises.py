"""Enterprises resource — agent approval registry."""

from __future__ import annotations

from typing import Any

from agledger._http import AsyncHttpClient, HttpClient
from agledger.types import EnterpriseAgentRecord, Page


class EnterprisesResource:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def approve_agent(self, enterprise_id: str, agent_id: str, **params: Any) -> EnterpriseAgentRecord:
        return EnterpriseAgentRecord.model_validate(self._http.post(f"/v1/enterprises/{enterprise_id}/agents/{agent_id}/approve", json=params))

    def revoke_agent(self, enterprise_id: str, agent_id: str) -> None:
        self._http.post(f"/v1/enterprises/{enterprise_id}/agents/{agent_id}/revoke", json={})

    def list_agents(self, enterprise_id: str, **params: Any) -> Page[EnterpriseAgentRecord]:
        raw = self._http.get_page(f"/v1/enterprises/{enterprise_id}/agents", params=params)
        raw["data"] = [EnterpriseAgentRecord.model_validate(a) for a in raw.get("data", [])]
        return Page[EnterpriseAgentRecord].model_validate(raw)

    def get_agent(self, enterprise_id: str, agent_id: str) -> EnterpriseAgentRecord:
        return EnterpriseAgentRecord.model_validate(self._http.get(f"/v1/enterprises/{enterprise_id}/agents/{agent_id}"))

    def update_agent_status(self, enterprise_id: str, agent_id: str, *, status: str, reason: str | None = None) -> EnterpriseAgentRecord:
        body: dict[str, Any] = {"status": status}
        if reason is not None:
            body["reason"] = reason
        return EnterpriseAgentRecord.model_validate(self._http.patch(f"/v1/enterprises/{enterprise_id}/agents/{agent_id}", json=body))

    def bulk_approve(self, enterprise_id: str, agent_ids: list[str]) -> dict[str, Any]:
        return self._http.post(f"/v1/enterprises/{enterprise_id}/agents/bulk", json={"agentIds": agent_ids})

    def get_approval_config(self, enterprise_id: str) -> dict[str, Any]:
        return self._http.get(f"/v1/enterprises/{enterprise_id}/approval-config")

    def set_approval_config(self, enterprise_id: str, **kwargs: Any) -> dict[str, Any]:
        return self._http.put(f"/v1/enterprises/{enterprise_id}/approval-config", json=kwargs)


class AsyncEnterprisesResource:
    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def approve_agent(self, enterprise_id: str, agent_id: str, **params: Any) -> EnterpriseAgentRecord:
        return EnterpriseAgentRecord.model_validate(await self._http.post(f"/v1/enterprises/{enterprise_id}/agents/{agent_id}/approve", json=params))

    async def revoke_agent(self, enterprise_id: str, agent_id: str) -> None:
        await self._http.post(f"/v1/enterprises/{enterprise_id}/agents/{agent_id}/revoke", json={})

    async def list_agents(self, enterprise_id: str, **params: Any) -> Page[EnterpriseAgentRecord]:
        raw = await self._http.get_page(f"/v1/enterprises/{enterprise_id}/agents", params=params)
        raw["data"] = [EnterpriseAgentRecord.model_validate(a) for a in raw.get("data", [])]
        return Page[EnterpriseAgentRecord].model_validate(raw)

    async def get_agent(self, enterprise_id: str, agent_id: str) -> EnterpriseAgentRecord:
        return EnterpriseAgentRecord.model_validate(await self._http.get(f"/v1/enterprises/{enterprise_id}/agents/{agent_id}"))

    async def update_agent_status(self, enterprise_id: str, agent_id: str, *, status: str, reason: str | None = None) -> EnterpriseAgentRecord:
        body: dict[str, Any] = {"status": status}
        if reason is not None:
            body["reason"] = reason
        return EnterpriseAgentRecord.model_validate(await self._http.patch(f"/v1/enterprises/{enterprise_id}/agents/{agent_id}", json=body))

    async def bulk_approve(self, enterprise_id: str, agent_ids: list[str]) -> dict[str, Any]:
        return await self._http.post(f"/v1/enterprises/{enterprise_id}/agents/bulk", json={"agentIds": agent_ids})

    async def get_approval_config(self, enterprise_id: str) -> dict[str, Any]:
        return await self._http.get(f"/v1/enterprises/{enterprise_id}/approval-config")

    async def set_approval_config(self, enterprise_id: str, **kwargs: Any) -> dict[str, Any]:
        return await self._http.put(f"/v1/enterprises/{enterprise_id}/approval-config", json=kwargs)
