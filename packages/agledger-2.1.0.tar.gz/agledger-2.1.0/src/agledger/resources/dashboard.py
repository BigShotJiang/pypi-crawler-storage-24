"""Dashboard resource."""

from __future__ import annotations

from typing import Any

from agledger._http import AsyncHttpClient, HttpClient
from agledger.types import DashboardSummary


class DashboardResource:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def get_summary(self, enterprise_id: str) -> DashboardSummary:
        return DashboardSummary.model_validate(self._http.get(f"/v1/dashboard/{enterprise_id}"))

    def get_metrics(self, enterprise_id: str, **params: Any) -> dict[str, Any]:
        return self._http.get(f"/v1/dashboard/{enterprise_id}/metrics", params=params)


class AsyncDashboardResource:
    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def get_summary(self, enterprise_id: str) -> DashboardSummary:
        return DashboardSummary.model_validate(await self._http.get(f"/v1/dashboard/{enterprise_id}"))

    async def get_metrics(self, enterprise_id: str, **params: Any) -> dict[str, Any]:
        return await self._http.get(f"/v1/dashboard/{enterprise_id}/metrics", params=params)
