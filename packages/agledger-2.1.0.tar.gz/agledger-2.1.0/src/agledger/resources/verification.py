"""Verification resource."""

from __future__ import annotations
from typing import Any, Optional
from agledger._http import AsyncHttpClient, HttpClient
from agledger.types import VerificationResult


class VerificationResource:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def verify(self, mandate_id: str, receipt_ids: Optional[list[str]] = None) -> VerificationResult:
        body: dict[str, Any] = {}
        if receipt_ids:
            body["receiptIds"] = receipt_ids
        data = self._http.post(f"/v1/mandates/{mandate_id}/verify", json=body)
        return VerificationResult.model_validate(data)


class AsyncVerificationResource:
    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def verify(self, mandate_id: str, receipt_ids: Optional[list[str]] = None) -> VerificationResult:
        body: dict[str, Any] = {}
        if receipt_ids:
            body["receiptIds"] = receipt_ids
        data = await self._http.post(f"/v1/mandates/{mandate_id}/verify", json=body)
        return VerificationResult.model_validate(data)
