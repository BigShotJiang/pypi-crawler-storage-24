"""Notarize resource — agent-to-agent agreement notarization (OpenClaw flow)."""

from __future__ import annotations
from typing import Any, Optional
from agledger._http import AsyncHttpClient, HttpClient


class NotarizeResource:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def create_mandate(self, **params: Any) -> dict[str, Any]:
        return self._http.post("/v1/notarize/mandates", json=params)

    def get_mandate(self, mandate_id: str) -> dict[str, Any]:
        return self._http.get(f"/v1/notarize/mandates/{mandate_id}")

    def accept_mandate(self, mandate_id: str) -> dict[str, Any]:
        return self._http.post(f"/v1/notarize/mandates/{mandate_id}/accept")

    def submit_receipt(self, mandate_id: str, **params: Any) -> dict[str, Any]:
        return self._http.post(f"/v1/notarize/mandates/{mandate_id}/receipts", json=params)

    def render_verdict(self, mandate_id: str, verdict: str, reason: Optional[str] = None) -> dict[str, Any]:
        body: dict[str, Any] = {"verdict": verdict}
        if reason:
            body["reason"] = reason
        return self._http.post(f"/v1/notarize/mandates/{mandate_id}/verdict", json=body)

    def get_history(self, mandate_id: str) -> dict[str, Any]:
        return self._http.get(f"/v1/notarize/mandates/{mandate_id}/history")


class AsyncNotarizeResource:
    def __init__(self, http: AsyncHttpClient) -> None:
        self._http = http

    async def create_mandate(self, **params: Any) -> dict[str, Any]:
        return await self._http.post("/v1/notarize/mandates", json=params)

    async def get_mandate(self, mandate_id: str) -> dict[str, Any]:
        return await self._http.get(f"/v1/notarize/mandates/{mandate_id}")

    async def accept_mandate(self, mandate_id: str) -> dict[str, Any]:
        return await self._http.post(f"/v1/notarize/mandates/{mandate_id}/accept")

    async def submit_receipt(self, mandate_id: str, **params: Any) -> dict[str, Any]:
        return await self._http.post(f"/v1/notarize/mandates/{mandate_id}/receipts", json=params)

    async def render_verdict(self, mandate_id: str, verdict: str, reason: Optional[str] = None) -> dict[str, Any]:
        body: dict[str, Any] = {"verdict": verdict}
        if reason:
            body["reason"] = reason
        return await self._http.post(f"/v1/notarize/mandates/{mandate_id}/verdict", json=body)

    async def get_history(self, mandate_id: str) -> dict[str, Any]:
        return await self._http.get(f"/v1/notarize/mandates/{mandate_id}/history")
