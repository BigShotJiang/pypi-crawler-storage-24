"""
AGLedger SDK — Webhook signature verification.
Mirrors the TypeScript SDK's webhooks/verify.ts.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import time
from typing import Any, Optional, Union

MAX_TOLERANCE_SECONDS = 300


def sign_payload(raw_body: str, secret: str, timestamp: Optional[int] = None) -> dict[str, Any]:
    """Sign a payload (for testing). Returns header, timestamp, signature."""
    ts = timestamp or int(time.time())
    signed_payload = f"{ts}.{raw_body}"
    signature = hmac.new(secret.encode(), signed_payload.encode(), hashlib.sha256).hexdigest()
    return {
        "header": f"t={ts},v1={signature}",
        "timestamp": ts,
        "signature": signature,
    }


def _parse_header(header: str) -> Optional[dict[str, Any]]:
    ts: Optional[int] = None
    signatures: list[str] = []
    for part in header.split(","):
        kv = part.split("=", 1)
        if len(kv) != 2:
            return None
        key, value = kv[0].strip(), kv[1].strip()
        if key == "t":
            try:
                ts = int(value)
            except ValueError:
                return None
        elif key == "v1":
            signatures.append(value)
    if ts is None or not signatures:
        return None
    return {"timestamp": ts, "signatures": signatures}


def verify_signature(
    raw_body: str,
    header: str,
    secrets: Union[str, list[str]],
    tolerance_seconds: int = MAX_TOLERANCE_SECONDS,
) -> bool:
    """Verify a webhook signature. Supports key rotation via list of secrets."""
    parsed = _parse_header(header)
    if not parsed:
        return False

    tolerance = min(tolerance_seconds, MAX_TOLERANCE_SECONDS)
    now = int(time.time())
    if abs(now - parsed["timestamp"]) > tolerance:
        return False

    secret_list = [secrets] if isinstance(secrets, str) else secrets
    signed_payload = f"{parsed['timestamp']}.{raw_body}"

    for secret in secret_list:
        expected = hmac.new(secret.encode(), signed_payload.encode(), hashlib.sha256).hexdigest()
        for sig in parsed["signatures"]:
            if hmac.compare_digest(sig, expected):
                return True

    return False


def construct_event(
    raw_body: str,
    header: str,
    secrets: Union[str, list[str]],
    tolerance_seconds: int = MAX_TOLERANCE_SECONDS,
) -> dict[str, Any]:
    """Verify signature and parse the webhook payload in one step.

    Raises ValueError if signature is invalid.
    """
    if not verify_signature(raw_body, header, secrets, tolerance_seconds):
        raise ValueError("Webhook signature verification failed")
    parsed = json.loads(raw_body)
    return {
        "type": parsed.get("type") or parsed.get("event", "unknown"),
        "data": parsed.get("data") or parsed.get("payload", parsed),
        "timestamp": parsed.get("timestamp") or parsed.get("created_at", ""),
        "id": parsed.get("id") or parsed.get("event_id"),
    }
