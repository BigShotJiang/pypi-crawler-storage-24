"""
AGLedger SDK — Accountability and audit infrastructure for agentic systems.

Patent Pending. Copyright 2026 AGLedger LLC. All rights reserved.
"""

from agledger._client import AgledgerClient, AsyncAgledgerClient
from agledger._errors import (
    AgledgerError,
    APIConnectionError,
    APIError,
    APITimeoutError,
    AuthenticationError,
    BadRequestError,
    NotFoundError,
    PermissionDeniedError,
    RateLimitError,
    UnprocessableError,
)
from agledger.scopes import (
    SCOPE_PROFILES,
    ScopeProfile,
    ScopeProfileName,
    Scopes,
)
from agledger.types import (
    AccountProfile,
    AuditChain,
    ContractType,
    DashboardSummary,
    Dispute,
    DisputeStatus,
    EnterpriseAgentRecord,
    Event,
    HealthResponse,
    Mandate,
    MandateStatus,
    MandateTransitionAction,
    OperatingMode,
    Page,
    Receipt,
    ReceiptStatus,
    RegisterResult,
    ReputationScore,
    VerificationMode,
    VerificationOutcome,
    VerificationResult,
    Webhook,
    WebhookEventType,
)

__version__ = "2.1.0"
__all__ = [
    "AgledgerClient",
    "AsyncAgledgerClient",
    # Errors
    "AgledgerError",
    "APIError",
    "AuthenticationError",
    "PermissionDeniedError",
    "NotFoundError",
    "BadRequestError",
    "UnprocessableError",
    "RateLimitError",
    "APIConnectionError",
    "APITimeoutError",
    # Scopes
    "Scopes",
    "ScopeProfile",
    "SCOPE_PROFILES",
    "ScopeProfileName",
    # Types
    "Mandate",
    "MandateStatus",
    "MandateTransitionAction",
    "Receipt",
    "ReceiptStatus",
    "ContractType",
    "OperatingMode",
    "VerificationMode",
    "VerificationOutcome",
    "VerificationResult",
    "Dispute",
    "DisputeStatus",
    "Webhook",
    "WebhookEventType",
    "ReputationScore",
    "Event",
    "AuditChain",
    "DashboardSummary",
    "AccountProfile",
    "RegisterResult",
    "EnterpriseAgentRecord",
    "HealthResponse",
    "Page",
]
