"""
AGLedger SDK — Type definitions.
Mirrors the TypeScript SDK types. All models are Pydantic v2.
"""

from __future__ import annotations

from typing import Any, Generic, Literal, Optional, TypeVar

from pydantic import BaseModel, ConfigDict, Field


# ---------------------------------------------------------------------------
# Contract Types
# ---------------------------------------------------------------------------

ContractType = Literal[
    "ACH-PROC-v1",
    "ACH-DLVR-v1",
    "ACH-DATA-v1",
    "ACH-TXN-v1",
    "ACH-ORCH-v1",
    "ACH-COMM-v1",
    "ACH-AUTH-v1",
    "ACH-INFRA-v1",
    "ACH-DEL-v1",
    "ACH-ANALYZE-v1",
    "ACH-COORD-v1",
]

# ---------------------------------------------------------------------------
# Mandate
# ---------------------------------------------------------------------------

MandateStatus = Literal[
    "DRAFT",
    "PROPOSED",
    "ACCEPTED",
    "COUNTER_PROPOSED",
    "REJECTED",
    "REGISTERED",
    "ACTIVE",
    "PENDING_VERIFICATION",
    "FULFILLED",
    "FAILED",
    "DISPUTED",
    "CANCELLED",
    "REMEDIATED",
    "EXPIRED",
    "RECEIPT_INVALID",
    "RECEIPT_ACCEPTED",
    "VERIFYING",
    "VERIFIED_PASS",
    "VERIFIED_FAIL",
    "CANCELLED_DRAFT",
    "CANCELLED_PRE_WORK",
    "CANCELLED_IN_PROGRESS",
    "REVISION_REQUESTED",
]

MandateTransitionAction = Literal["register", "activate", "settle", "cancel", "refund"]

OperatingMode = Literal["standard", "encrypted", "cleartext"]
VerificationMode = Literal["auto", "principal", "gated"]
RiskClassification = Literal["unacceptable", "high", "limited", "minimal", "unclassified"]


class Mandate(BaseModel):
    """A mandate — a registered commitment between a principal and a performer."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    id: str
    """Unique mandate ID (UUID)."""
    enterprise_id: str = Field(alias="enterpriseId")
    """Enterprise that owns this mandate."""
    agent_id: str | None = Field(None, alias="agentId")
    """Agent assigned to this mandate."""
    contract_type: str = Field(alias="contractType")
    """Agentic Contract Specification type (e.g., 'ACH-PROC-v1')."""
    contract_version: str = Field(alias="contractVersion")
    """Version of the contract schema."""
    platform: str
    """Platform where this mandate operates."""
    platform_ref: str | None = Field(None, alias="platformRef")
    """External reference ID on the platform."""
    status: MandateStatus | str
    """Current lifecycle status."""
    criteria: dict[str, Any]
    """Acceptance criteria — what the performer must deliver."""
    tolerance: dict[str, Any] | None = None
    """Tolerance bands for numeric criteria."""
    deadline: str | None = None
    """ISO 8601 deadline for completion."""
    commission_pct: float | None = Field(None, alias="commissionPct")
    """Commission percentage for the performing agent."""
    operating_mode: OperatingMode | str | None = Field(None, alias="operatingMode")
    """Operating mode: standard, encrypted, or cleartext."""
    verification_mode: VerificationMode | str | None = Field(None, alias="verificationMode")
    """Verification mode: auto, principal, or gated."""
    risk_classification: RiskClassification | str | None = Field(None, alias="riskClassification")
    """EU AI Act risk classification."""
    eu_ai_act_domain: str | None = Field(None, alias="euAiActDomain")
    """EU AI Act domain."""
    human_oversight: dict[str, Any] | None = Field(None, alias="humanOversight")
    """Human oversight configuration for EU AI Act compliance."""
    acceptance_status: Literal["PENDING", "ACCEPTED", "REJECTED", "COUNTER_PROPOSED"] | None = Field(None, alias="acceptanceStatus")
    """Performer's response to a proposed mandate."""
    project_ref: str | None = Field(None, alias="projectRef")
    """Project grouping reference for related mandates."""
    parent_mandate_id: str | None = Field(None, alias="parentMandateId")
    """Parent mandate ID in a delegation chain."""
    root_mandate_id: str | None = Field(None, alias="rootMandateId")
    """Root mandate ID at the top of the delegation chain."""
    chain_depth: int | None = Field(None, alias="chainDepth")
    """Depth in the delegation chain (0 = root)."""
    last_transition_reason: str | None = Field(None, alias="lastTransitionReason")
    """Reason provided for the last state transition."""
    last_transition_by: str | None = Field(None, alias="lastTransitionBy")
    """Actor who triggered the last state transition."""
    submission_count: int = Field(alias="submissionCount")
    """Number of receipt submissions so far."""
    max_submissions: int | None = Field(None, alias="maxSubmissions")
    """Maximum allowed submissions, or None for unlimited."""
    version: int
    """Optimistic concurrency version."""
    created_at: str = Field(alias="createdAt")
    """ISO 8601 creation timestamp."""
    updated_at: str = Field(alias="updatedAt")
    """ISO 8601 last update timestamp."""
    activated_at: str | None = Field(None, alias="activatedAt")
    """ISO 8601 timestamp when the mandate was activated."""
    fulfilled_at: str | None = Field(None, alias="fulfilledAt")
    """ISO 8601 timestamp when the mandate was fulfilled."""


# ---------------------------------------------------------------------------
# Receipt
# ---------------------------------------------------------------------------

ReceiptStatus = Literal["SUBMITTED", "ACCEPTED", "REJECTED", "INVALID"]

VerificationOutcome = Literal["PASS", "FAIL", "REVIEW_REQUIRED"]


class Receipt(BaseModel):
    """A receipt — structured evidence submitted by a performer."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    id: str
    """Unique receipt ID."""
    mandate_id: str = Field(alias="mandateId")
    """Mandate this receipt is for."""
    agent_id: str = Field(alias="agentId")
    """Agent that submitted the receipt."""
    status: ReceiptStatus | str
    """Receipt processing status."""
    evidence: dict[str, Any]
    """Evidence of completion."""
    evidence_hash: str | None = Field(None, alias="evidenceHash")
    """SHA-256 hash of the evidence payload."""
    notes: str | None = None
    """Free-text notes from the performer."""
    verification_phase: str | None = Field(None, alias="verificationPhase")
    verification_result: dict[str, Any] | None = Field(None, alias="verificationResult")
    verification_outcome: VerificationOutcome | str | None = Field(None, alias="verificationOutcome")
    """Overall verification outcome: PASS, FAIL, or REVIEW_REQUIRED."""
    verification_completed_at: str | None = Field(None, alias="verificationCompletedAt")
    validation_errors: list[str] | None = Field(None, alias="validationErrors")
    mandate_status: MandateStatus | str | None = Field(None, alias="mandateStatus")
    idempotency_key: str | None = Field(None, alias="idempotencyKey")
    created_at: str = Field(alias="createdAt")
    """ISO 8601 creation timestamp."""
    updated_at: str | None = Field(None, alias="updatedAt")


# ---------------------------------------------------------------------------
# Verification
# ---------------------------------------------------------------------------


class VerificationResult(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    mandate_id: str = Field(alias="mandateId")
    receipts: list[dict[str, Any]] = Field(default_factory=list)
    overall_status: str = Field(alias="overallStatus")


# ---------------------------------------------------------------------------
# Disputes
# ---------------------------------------------------------------------------

DisputeStatus = Literal[
    "OPEN", "TIER_1_REVIEW", "EVIDENCE_WINDOW", "TIER_2_REVIEW",
    "ESCALATED", "TIER_3_ARBITRATION", "RESOLVED", "WITHDRAWN",
]


class Dispute(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    id: str
    mandate_id: str = Field(alias="mandateId")
    receipt_id: str = Field(alias="receiptId")
    status: DisputeStatus | str
    reason: str
    evidence: dict[str, Any] | None = None
    current_tier: int = Field(alias="currentTier")
    resolution: str | None = None
    amount: float | None = None
    created_at: str = Field(alias="createdAt")
    updated_at: str | None = Field(None, alias="updatedAt")
    resolved_at: str | None = Field(None, alias="resolvedAt")


# ---------------------------------------------------------------------------
# Webhooks
# ---------------------------------------------------------------------------

WebhookEventType = Literal[
    "receipt.submitted",
    "receipt.verified",
    "receipt.accepted",
    "receipt.rejected",
    "mandate.created",
    "mandate.registered",
    "mandate.activated",
    "mandate.fulfilled",
    "mandate.failed",
    "mandate.cancelled",
    "mandate.delegated",
    "mandate.released",
    "mandate.revision_requested",
    "dispute.created",
    "dispute.resolved",
    "signal.emitted",
    "verification.complete",
]


class Webhook(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    id: str
    url: str
    events: list[str]
    secret: str | None = None
    created_at: str = Field(alias="createdAt")
    last_triggered_at: str | None = Field(None, alias="lastTriggeredAt")
    failure_count: int | None = Field(None, alias="failureCount")


# ---------------------------------------------------------------------------
# Reputation
# ---------------------------------------------------------------------------


class ReputationScore(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    agent_id: str = Field(alias="agentId")
    score: float
    tier: str
    completion_rate: float = Field(alias="completionRate")
    on_time_rate: float = Field(alias="onTimeRate")
    dispute_rate: float = Field(alias="disputeRate")
    last_updated_at: str = Field(alias="lastUpdatedAt")
    factors_breakdown: dict[str, Any] | None = Field(None, alias="factorsBreakdown")


# ---------------------------------------------------------------------------
# Events
# ---------------------------------------------------------------------------


class Event(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    id: str
    mandate_id: str = Field(alias="mandateId")
    event_type: str = Field(alias="eventType")
    actor: str
    actor_id: str | None = Field(None, alias="actorId")
    timestamp: str
    changes: dict[str, Any] | None = None
    details: dict[str, Any] | None = None


class AuditChain(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    mandate_id: str = Field(alias="mandateId")
    chain_start: str = Field(alias="chainStart")
    entries: list[dict[str, Any]] = Field(default_factory=list)
    is_valid: bool = Field(alias="isValid")


# ---------------------------------------------------------------------------
# Dashboard
# ---------------------------------------------------------------------------


class DashboardSummary(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    total_mandates: int = Field(alias="totalMandates")
    active_count: int = Field(alias="activeCount")
    fulfilled_count: int = Field(alias="fulfilledCount")
    disputed_count: int = Field(alias="disputedCount")


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

AccountType = Literal["enterprise", "agent", "platform"]


class AccountProfile(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    id: str
    account_type: AccountType | str = Field(alias="accountType")
    display_name: str | None = Field(None, alias="displayName")
    trust_level: str | None = Field(None, alias="trustLevel")
    enterprise_id: str | None = Field(None, alias="enterpriseId")
    sandbox_mode: bool | None = Field(None, alias="sandboxMode")
    created_at: str = Field(alias="createdAt")


class RegisterResult(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    api_key: str = Field(alias="apiKey")
    sandbox_mode: bool = Field(alias="sandboxMode")
    verification_required: str = Field(alias="verificationRequired")


# ---------------------------------------------------------------------------
# Enterprise Agent Approval
# ---------------------------------------------------------------------------


class EnterpriseAgentRecord(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    id: str
    enterprise_id: str = Field(alias="enterpriseId")
    agent_id: str = Field(alias="agentId")
    display_name: str | None = Field(None, alias="displayName")
    status: str
    created_at: str = Field(alias="createdAt")
    updated_at: str | None = Field(None, alias="updatedAt")


# ---------------------------------------------------------------------------
# Pagination
# ---------------------------------------------------------------------------

T = TypeVar("T")


class Page(BaseModel, Generic[T]):
    """Unified page type for all list endpoints."""

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    data: list[T]  # type: ignore[type-var]
    has_more: bool = Field(alias="hasMore")
    next_cursor: str | None = Field(None, alias="nextCursor")
    total: int | None = None


# ---------------------------------------------------------------------------
# Health
# ---------------------------------------------------------------------------


class HealthResponse(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    status: str
    version: str | None = None
    uptime: float | None = None
    database: str | None = None
    timestamp: str


# ---------------------------------------------------------------------------
# A2A Protocol
# ---------------------------------------------------------------------------


class AgentCard(BaseModel):
    model_config = ConfigDict(extra="allow", populate_by_name=True)

    name: str
    description: str | None = None
    url: str
    capabilities: dict[str, Any] | None = None
    skills: list[dict[str, Any]] | None = None
