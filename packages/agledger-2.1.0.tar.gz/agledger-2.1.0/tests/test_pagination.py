"""Tests for auto-pagination."""

import httpx
import respx

from agledger import AgledgerClient, Mandate


MANDATE_1 = {
    "id": "mnd-1", "enterpriseId": "ent-1", "agentId": None,
    "contractType": "ACH-PROC-v1", "contractVersion": "1", "platform": "test",
    "status": "ACTIVE", "criteria": {}, "submissionCount": 0, "maxSubmissions": None,
    "version": 1, "createdAt": "2026-03-16T00:00:00Z", "updatedAt": "2026-03-16T00:00:00Z",
}
MANDATE_2 = {**MANDATE_1, "id": "mnd-2"}
MANDATE_3 = {**MANDATE_1, "id": "mnd-3"}


@respx.mock
def test_list_all_multi_page():
    route = respx.get("https://api.agledger.ai/v1/mandates")
    route.side_effect = [
        httpx.Response(200, json={"data": [MANDATE_1, MANDATE_2], "hasMore": True, "nextCursor": "cur-2"}),
        httpx.Response(200, json={"data": [MANDATE_3], "hasMore": False}),
    ]
    client = AgledgerClient(api_key="test-key")
    mandates = list(client.mandates.list_all(enterprise_id="ent-1"))
    assert len(mandates) == 3
    assert all(isinstance(m, Mandate) for m in mandates)
    assert [m.id for m in mandates] == ["mnd-1", "mnd-2", "mnd-3"]
    assert len(route.calls) == 2


@respx.mock
def test_list_all_empty():
    respx.get("https://api.agledger.ai/v1/mandates").mock(
        return_value=httpx.Response(200, json={"data": [], "hasMore": False})
    )
    client = AgledgerClient(api_key="test-key")
    mandates = list(client.mandates.list_all(enterprise_id="ent-1"))
    assert mandates == []


@respx.mock
def test_list_all_single_page():
    respx.get("https://api.agledger.ai/v1/mandates").mock(
        return_value=httpx.Response(200, json={"data": [MANDATE_1], "hasMore": False})
    )
    client = AgledgerClient(api_key="test-key")
    mandates = list(client.mandates.list_all(enterprise_id="ent-1"))
    assert len(mandates) == 1
