"""Tests for AgledgerClient — resources, auth, context manager, typed kwargs."""

import httpx
import pytest
import respx

from agledger import AgledgerClient, AsyncAgledgerClient, Mandate, AuthenticationError


MANDATE_JSON = {
    "id": "mnd-123",
    "enterpriseId": "ent-1",
    "agentId": None,
    "contractType": "ACH-PROC-v1",
    "contractVersion": "1",
    "platform": "test",
    "status": "DRAFT",
    "criteria": {"item": "widgets"},
    "submissionCount": 0,
    "maxSubmissions": None,
    "version": 1,
    "createdAt": "2026-03-16T00:00:00Z",
    "updatedAt": "2026-03-16T00:00:00Z",
}


@respx.mock
def test_mandates_create_typed_kwargs():
    respx.post("https://api.agledger.ai/v1/mandates").mock(
        return_value=httpx.Response(200, json=MANDATE_JSON)
    )
    client = AgledgerClient(api_key="test-key")
    mandate = client.mandates.create(
        enterprise_id="ent-1",
        contract_type="ACH-PROC-v1",
        contract_version="1",
        platform="test",
        criteria={"item": "widgets"},
        max_submissions=3,
    )
    assert isinstance(mandate, Mandate)
    assert mandate.id == "mnd-123"
    assert mandate.status == "DRAFT"
    # Verify camelCase was sent to API
    body = respx.calls[0].request.content
    import json
    sent = json.loads(body)
    assert sent["enterpriseId"] == "ent-1"
    assert sent["contractType"] == "ACH-PROC-v1"
    assert sent["maxSubmissions"] == 3


@respx.mock
def test_mandates_get():
    respx.get("https://api.agledger.ai/v1/mandates/mnd-123").mock(
        return_value=httpx.Response(200, json=MANDATE_JSON)
    )
    client = AgledgerClient(api_key="test-key")
    mandate = client.mandates.get("mnd-123")
    assert mandate.id == "mnd-123"
    assert mandate.contract_type == "ACH-PROC-v1"


@respx.mock
def test_mandates_list_with_status_filter():
    respx.get("https://api.agledger.ai/v1/mandates").mock(
        return_value=httpx.Response(200, json={"data": [MANDATE_JSON], "hasMore": False})
    )
    client = AgledgerClient(api_key="test-key")
    page = client.mandates.list(enterprise_id="ent-1", status="DRAFT")
    assert len(page.data) == 1
    assert page.has_more is False
    assert isinstance(page.data[0], Mandate)


@respx.mock
def test_mandates_transition():
    activated = {**MANDATE_JSON, "status": "ACTIVE"}
    respx.post("https://api.agledger.ai/v1/mandates/mnd-123/transition").mock(
        return_value=httpx.Response(200, json=activated)
    )
    client = AgledgerClient(api_key="test-key")
    mandate = client.mandates.transition("mnd-123", "activate")
    assert mandate.status == "ACTIVE"


@respx.mock
def test_mandates_request_revision():
    revised = {**MANDATE_JSON, "status": "REVISION_REQUESTED"}
    respx.post("https://api.agledger.ai/v1/mandates/mnd-123/revision").mock(
        return_value=httpx.Response(200, json=revised)
    )
    client = AgledgerClient(api_key="test-key")
    mandate = client.mandates.request_revision("mnd-123", "please fix X")
    assert mandate.status == "REVISION_REQUESTED"


@respx.mock
def test_receipt_submit_typed_kwargs():
    receipt_json = {
        "id": "rct-1", "mandateId": "mnd-123", "agentId": "agent-1",
        "status": "SUBMITTED", "evidence": {"delivered": True},
        "createdAt": "2026-03-16T00:00:00Z",
    }
    respx.post("https://api.agledger.ai/v1/mandates/mnd-123/receipts").mock(
        return_value=httpx.Response(200, json=receipt_json)
    )
    client = AgledgerClient(api_key="test-key")
    receipt = client.receipts.submit("mnd-123", agent_id="agent-1", evidence={"delivered": True})
    assert receipt.id == "rct-1"


@respx.mock
def test_auth_header():
    route = respx.get("https://api.agledger.ai/v1/mandates/mnd-123").mock(
        return_value=httpx.Response(200, json=MANDATE_JSON)
    )
    client = AgledgerClient(api_key="ach_ent_test123")
    client.mandates.get("mnd-123")
    assert route.calls[0].request.headers["authorization"] == "Bearer ach_ent_test123"


@respx.mock
def test_user_agent_header():
    route = respx.get("https://api.agledger.ai/v1/mandates/mnd-123").mock(
        return_value=httpx.Response(200, json=MANDATE_JSON)
    )
    client = AgledgerClient(api_key="test-key")
    client.mandates.get("mnd-123")
    assert "agledger-python/" in route.calls[0].request.headers["user-agent"]


@respx.mock
def test_idempotency_key_on_post():
    route = respx.post("https://api.agledger.ai/v1/mandates").mock(
        return_value=httpx.Response(200, json=MANDATE_JSON)
    )
    client = AgledgerClient(api_key="test-key")
    client.mandates.create(enterprise_id="e", contract_type="ACH-PROC-v1", contract_version="1", platform="t", criteria={})
    assert "idempotency-key" in route.calls[0].request.headers


@respx.mock
def test_no_idempotency_key_on_get():
    route = respx.get("https://api.agledger.ai/v1/mandates/mnd-123").mock(
        return_value=httpx.Response(200, json=MANDATE_JSON)
    )
    client = AgledgerClient(api_key="test-key")
    client.mandates.get("mnd-123")
    assert "idempotency-key" not in route.calls[0].request.headers


@respx.mock
def test_no_content_type_on_get():
    route = respx.get("https://api.agledger.ai/v1/mandates/mnd-123").mock(
        return_value=httpx.Response(200, json=MANDATE_JSON)
    )
    client = AgledgerClient(api_key="test-key")
    client.mandates.get("mnd-123")
    assert "content-type" not in route.calls[0].request.headers


@respx.mock
def test_context_manager():
    respx.get("https://api.agledger.ai/v1/mandates/mnd-123").mock(
        return_value=httpx.Response(200, json=MANDATE_JSON)
    )
    with AgledgerClient(api_key="test-key") as client:
        mandate = client.mandates.get("mnd-123")
        assert mandate.id == "mnd-123"


def test_env_var_fallback(monkeypatch):
    monkeypatch.setenv("AGLEDGER_API_KEY", "ach_ent_from_env")
    client = AgledgerClient()
    # Client should have been created successfully with env var
    assert client._http._api_key == "ach_ent_from_env"


def test_no_api_key_raises(monkeypatch):
    monkeypatch.delenv("AGLEDGER_API_KEY", raising=False)
    with pytest.raises(AuthenticationError, match="No API key"):
        AgledgerClient()


@respx.mock
def test_populate_by_name():
    """Verify Pydantic models can be constructed with snake_case names."""
    m = Mandate(
        id="mnd-1",
        enterprise_id="ent-1",
        contract_type="ACH-PROC-v1",
        contract_version="1",
        platform="test",
        status="DRAFT",
        criteria={},
        submission_count=0,
        max_submissions=None,
        version=1,
        created_at="2026-01-01T00:00:00Z",
        updated_at="2026-01-01T00:00:00Z",
    )
    assert m.enterprise_id == "ent-1"
    assert m.contract_type == "ACH-PROC-v1"
    assert m.submission_count == 0


@respx.mock
def test_has_18_resources():
    """Verify client has all 18 resource sub-clients."""
    client = AgledgerClient(api_key="test-key")
    resources = [
        "mandates", "receipts", "verification", "disputes", "webhooks",
        "reputation", "events", "schemas", "dashboard", "compliance",
        "registration", "health", "admin", "a2a", "capabilities",
        "notarize", "enterprises",
    ]
    for r in resources:
        assert hasattr(client, r), f"Missing resource: {r}"


# --- Async tests ---

@respx.mock
@pytest.mark.asyncio
async def test_async_mandates_get():
    respx.get("https://api.agledger.ai/v1/mandates/mnd-123").mock(
        return_value=httpx.Response(200, json=MANDATE_JSON)
    )
    async with AsyncAgledgerClient(api_key="test-key") as client:
        mandate = await client.mandates.get("mnd-123")
        assert mandate.id == "mnd-123"
        assert isinstance(mandate, Mandate)


@respx.mock
@pytest.mark.asyncio
async def test_async_context_manager():
    respx.get("https://api.agledger.ai/v1/mandates/mnd-123").mock(
        return_value=httpx.Response(200, json=MANDATE_JSON)
    )
    async with AsyncAgledgerClient(api_key="test-key") as client:
        mandate = await client.mandates.get("mnd-123")
        assert mandate.id == "mnd-123"
