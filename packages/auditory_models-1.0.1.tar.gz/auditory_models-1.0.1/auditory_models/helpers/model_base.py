# This file is part of auditory_models
# Copyright (C) 2026 Max Zimmermann
#
# auditory_models is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# auditory_models is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with auditory_models.  If not, see <https://www.gnu.org/licenses/>.


from numpy.typing import NDArray
from typing import Any


class AuditoryModel:
    def __init__(self, *args, **kwargs):
        pass

    def process(self, reference: NDArray, degraded: NDArray, sample_rate: float) -> Any:
        raise NotImplementedError()

    def frontend(self, reference: NDArray, degraded: NDArray, sample_rate: float) -> Any:
        raise NotImplementedError()

    def backend(self, *args, **kwargs) -> Any:
        raise NotImplementedError()

    def export_config(self) -> dict:
        """
        Return the input parameters that were passed upon instantiation as dictionary
        :return: dictionary containing the passed input parameters with their respective names as keys
        """
        return {}
