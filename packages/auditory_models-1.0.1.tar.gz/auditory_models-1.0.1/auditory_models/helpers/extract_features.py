# This file is part of auditory_models
# Copyright (C) 2026 Max Zimmermann
#
# auditory_models is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# auditory_models is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with auditory_models.  If not, see <https://www.gnu.org/licenses/>.


import json
import numpy as np
from numpy.typing import NDArray
import os
from parse import parse
from pathlib import Path
from scipy.io import loadmat
import soundfile as sf

from auditory_models import BAMQ, GPSMq


def prepare_audio_file(file_path: Path, target_dBfs: float = -35) -> tuple[NDArray, float]:
    """
    Read audio file, check dimensions, cut to a maximum length of 2s and calibrate global RMS to given dB FS value.

    :param file_path: Path to audio file
    :param target_dBfs: Target dB FS value of global RMS of audio data
    :return: array containing the audio data and a scalar of the sampling frequency
    """
    audio, fs = sf.read(file_path)
    if audio.ndim == 2 and audio.shape[0] > audio.shape[1]:
        audio = np.transpose(audio)
    # max_len = min(audio.shape[-1], 2 * fs)
    # audio = audio[..., 0:max_len]
    rms_audio = np.sqrt(np.mean(np.square(audio), axis=-1))
    if audio.ndim == 1:
        audio *= 10 ** (target_dBfs / 20) / rms_audio
    elif audio.ndim == 2:
        for channel in range(audio.shape[0]):
            audio[channel, :] *= 10 ** (target_dBfs / 20) / rms_audio[channel]
    else:
        raise RuntimeError(f"Audio array with number of dimensions of {audio.ndim} is not supported.")
    return audio, fs


def flessner2017_fname_to_pair_path(fname: str) -> tuple[Path, Path]:
    parsed_fname = parse("{sig}_{algo}.wav", fname)
    base_path = Path("signals") / parsed_fname["sig"]
    ref_path = base_path / "reference" / (parsed_fname["sig"] + "_ref.wav")
    if parsed_fname["algo"] == "anchor":
        dgr_path = base_path / "anchor" / fname
    else:
        dgr_path = base_path / fname
    return ref_path, dgr_path


def main():
    base_path_repo = Path(__file__).parent.parent.parent
    base_path_data = base_path_repo / "tests" / "_data"
    target_path = Path(__file__).parent.parent.parent.parent / "_data"
    experiment_db = ["Nordholm2018"] #"Goessling2020", "Flessner2017", "Schepker2019", "Schepker2020"] # "Nordholm2018",
    features = {"GPSMq": []}#, "BAMQ": []}
    gpsmq = GPSMq(n_chan=1)
    bamq = BAMQ()
    for exp in experiment_db:
        file_counter = 0
        exp_path = base_path_data / exp
        file_pairs = []
        if not exp_path.is_dir():
            raise RuntimeError(f"Experiment {exp} does not exist.")
        # extract file pair paths
        if exp == "Flessner2017":
            dgr_files = loadmat(exp_path / f"{exp}_labels.mat")["data"]["audio_file_name"][0, 0][:, 0]
            file_pairs = [flessner2017_fname_to_pair_path(str(f[0])) for f in dgr_files]
        else:
            for root, dirs, files in os.walk(exp_path):
                for name in files:
                    if name.endswith(".pairlist"):
                        # print(root, dirs, name)
                        with open(Path(root) / name, "r") as f:
                            file_pairs += [line.rstrip().split()[1:3] for line in f if line.rstrip() != ""]
        for ref_path, dgr_path in file_pairs:
            file_counter += 1
            if not (exp_path / dgr_path).exists():
                print(f"Audio file {dgr_path} does not exist -> skipping...")
                continue
            data = {"reference": str((exp_path / ref_path).relative_to(base_path_repo.parent)),
                    "degraded": str((exp_path / dgr_path).relative_to(base_path_repo.parent))}
            reference, fs_ref = prepare_audio_file(exp_path / ref_path)
            degraded, fs_dgr = prepare_audio_file(exp_path / dgr_path)
            if fs_dgr != fs_ref:
                raise RuntimeError(f"Sample rates not identical ({fs_ref}, {fs_dgr}) for audio files {ref_path} and {dgr_path}.")
            label = loadmat(exp_path / f"{exp}_labels.mat")
            if exp == "Schepker2020":
                target_file = str(Path(Path(dgr_path).parent.name) / Path(dgr_path).name)
            elif exp == "Goessling2020":
                target_file = str((Path(Path(dgr_path).parent.name) / Path(dgr_path).name).as_posix())
            elif exp == "Flessner2017":
                target_file = dgr_path.name
            else:
                target_file = dgr_path
            matching = target_file == label["data"]["audio_file_name"][0, 0][:, 0]
            if np.sum(matching) == 0:
                print(f"Skipping {dgr_path} because no matching label was found.")
                continue
            elif np.sum(matching) == 1:
                data["label"] = label["data"]["measured_mean"][0, 0][matching, 0][0]
            else:
                raise RuntimeError(f"Feature extraction for experiment {exp} and file name {dgr_path} failed "
                                   f"because {np.sum(matching)} matching file(s) name were found.")
            print(f"{file_counter}, {exp}, {fs_dgr}, {round(degraded.shape[-1] / fs_dgr, 1)}, {Path(dgr_path).parent}/{Path(dgr_path).name}")
            for mod in features.keys():
                if mod == "GPSMq":
                    frontend_features = gpsmq.frontend(reference, degraded, fs_dgr)
                    model_output = gpsmq.backend(frontend_features["snr_inc_epsm"],
                                                  frontend_features["snr_inc_psm"],
                                                  frontend_features["snr_dec_epsm"],
                                                  frontend_features["snr_dec_psm"],
                                                  frontend_features["corr_mat"])
                elif mod == "BAMQ":
                    frontend_features = bamq.frontend(reference, degraded, fs_dgr)
                    model_output = bamq.backend(frontend_features["ref_itd"],
                                                 frontend_features["ref_ic"],
                                                 frontend_features["ref_ild"],
                                                 frontend_features["ref_pow"],
                                                 frontend_features["dgr_itd"],
                                                 frontend_features["dgr_ic"],
                                                 frontend_features["dgr_ild"],
                                                 frontend_features["dgr_pow"])
                else:
                    raise NotImplementedError(f"Feature extraction for model {mod} not implemented.")
                for key, val in frontend_features.items():
                    if isinstance(val, np.ndarray):
                        frontend_features[key] = val.tolist()
                for key, val in model_output.items():
                    if isinstance(val, np.ndarray):
                        model_output[key] = val.tolist()
                data["frontend_features"] = frontend_features
                data["model_output"] = model_output

                feature_dir = Path(target_path / exp / "features" / mod)
                feature_dir.mkdir(parents=True, exist_ok=True)
                with open(feature_dir / f"{exp}_{mod}_features{file_counter:05d}.json", "w", encoding="utf-8") as jf:
                    json.dump(data, jf, ensure_ascii=False, indent=4)



if __name__ == "__main__":
    main()
