# This file is part of auditory_models
# Copyright (C) 2025 Max Zimmermann
#
# auditory_models is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# auditory_models is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with auditory_models.  If not, see <https://www.gnu.org/licenses/>.


import numpy as np
from numpy.typing import NDArray
from scipy.signal import butter, firwin, sosfilt

from auditory_models.helpers.filterbank import GammatoneFilterbank
from auditory_models.helpers.model_base import AuditoryModel
from auditory_models.helpers.utils import MatlabResample


class BAMQ(AuditoryModel):
    """
    Implements the BAMQ auditory model.
    Translated to Python from the original Matlab implementation written by Jan-Hendrik Flessner.
    Reference:
        Flessner, Jan-Hendrik / Huber, Rainer / Ewert, Stephan
        Assessment and Prediction of Binaural Aspects of Audio Quality
        2017-11
        Journal of the Audio Engineering Society , Vol. 65, No. 11
        Audio Engineering Society
        p. 929-942
    """
    def __init__(self):
        super().__init__()
        self._sample_rate_base = 44100
        self._sample_rate_new = 6000
        self._middle_ear_bp = butter(1, [500, 2000], btype="bandpass", output="sos", fs=self._sample_rate_base)
        self._haircell_lp = butter(5, 770, btype="low", output="sos", fs=self._sample_rate_base)
        self._gtfb = GammatoneFilterbank(sample_rate=self._sample_rate_base, normfreq=700., freq_range=(50., 14000.))
        self._gtfb_fine = GammatoneFilterbank(sample_rate=self._sample_rate_base,
                                              cf=self._gtfb.cf[self._gtfb.cf < 1400])
        self._mod_low1 = butter(2, 500, btype="low", output="sos", fs=self._sample_rate_base)
        self._mod_low2 = butter(10, 600, btype="low", output="sos", fs=self._sample_rate_base)
        mod_cf = 300 * np.ones(self._gtfb.n_filters - self._gtfb_fine.n_filters)
        self._gtfb_mod = GammatoneFilterbank(sample_rate=self._sample_rate_base, order=1, cf=mod_cf, bandwidths=mod_cf)
        self._ild_low = butter(2, 30, btype="low", output="sos", fs=self._sample_rate_new)
        # cutoff frequency for decimation filter is computed with the decimation factor and an extra factor for the
        # filter to be effective at the new nyquist frequency
        self._decimation_factor = round(self._sample_rate_base / self._sample_rate_new)
        cutoff = self._sample_rate_base / (2 * self._decimation_factor) * (5 / 6)
        decimation_order = 20 * self._decimation_factor
        self.decimation_filter = firwin(decimation_order + 1, cutoff, fs=self._sample_rate_base, window=("kaiser", 5.),
                                        pass_zero=True)
        self._m_in_sig_resample = None
        self._m_resample = MatlabResample(self._sample_rate_new, self._sample_rate_base)

        self._compr_power = 0.4
        self._tau_cycles = 5 / np.concatenate((self._gtfb_fine.cf, self._gtfb_mod.cf))
        self._ic_coeff = np.zeros((self._tau_cycles.size, 1, 6))
        for idx, tau in enumerate(self._tau_cycles):
            coeff = np.exp(-1 / (self._sample_rate_new * self._tau_cycles))
            self._ic_coeff[idx, :, :] = np.array([[1 - coeff[idx], 0., 0., 1., -coeff[idx], 0.]])

        self._block_len_sec = 0.4
        self._block_len = round(self._block_len_sec * self._sample_rate_new)
        self._ivs_thres = 0.98
        self._k = 2 / (1 + np.exp(0.0012 * (self._gtfb.cf - 666))) + 0.023
        self._n = 3.17 / (1 + np.exp(-0.0015 * (self._gtfb.cf - 560))) - 2.75

    def _recompute_properties(self, sample_rate: float) -> None:
        self._m_in_sig_resample = MatlabResample(self._sample_rate_base, round(sample_rate))

    def process(self, reference: NDArray, degraded: NDArray, sample_rate: float) -> dict:
        """
        Process a reference and a degraded signal. An amplitude of 0dB FS shall correspond to 115dB SPL.
        :param reference: reference signal with shape (2, sig_len)
        :param degraded: degraded signal with shape (2, sig_len)
        :param sample_rate: sampling rate of reference and degraded in Hz, during processing both signals will be
            resampled to 44100 Hz
            NOTE: `sample_rate` will be rounded to the nearest integer!
        :return: dictionary containing the following keys:
            - bin_q: binaural perceptual quality value
            - ild_diff: intermediate ILD measure
            - itd_diff: intermediate ITD measure (can be 0 if ITDs are not evaluable)
            - ivs_diff: intermediate IVS measure
        """

        frontend_features = self.frontend(reference, degraded, sample_rate)

        return self.backend(frontend_features["ref_itd"],
                            frontend_features["ref_ic"],
                            frontend_features["ref_ild"],
                            frontend_features["ref_pow"],
                            frontend_features["dgr_itd"],
                            frontend_features["dgr_ic"],
                            frontend_features["dgr_ild"],
                            frontend_features["dgr_pow"])

    def frontend(self, reference: NDArray, degraded: NDArray, sample_rate: float) -> dict:
        """
        Frontend of the BAMQ-processing. An amplitude of 0dB FS shall correspond to 115dB SPL.
        :param reference: reference signal with shape (2, sig_len)
        :param degraded: degraded signal with shape (2, sig_len)
        :param sample_rate: sampling rate of reference and degraded in Hz, during processing both signals will be
            resampled to 44100 Hz
            NOTE: `sample_rate` will be rounded to the nearest integer!
        :return: dictionary containing the following keys:
            - ref_itd: interaural time difference of reference signal
            - ref_ic: interaural correlation of reference signal
            - ref_ild: interaural level difference of reference signal
            - ref_pow: power of reference signal
            - dgr_itd: interaural time difference of degraded signal
            - dgr_ic: interaural correlation of degraded signal
            - dgr_ild: interaural level difference of degraded signal
            - dgr_pow: power of degraded signal
        """
        # check signal shapes
        if reference.ndim != 2:
            raise ValueError(f"reference must have two dimensions, currently: {reference.ndim}")
        if reference.shape[0] != 2:
            raise ValueError(f"reference must have a size of 2 in first dimension, currently shape is: "
                             f"{reference.shape}")
        if degraded.ndim != 2:
            raise ValueError(f"degraded must have two dimensions, currently: {degraded.ndim}")
        if degraded.shape[0] != 2:
            raise ValueError(f"degraded must have a size of 2 in first dimension, currently shape is: "
                             f"{degraded.shape}")
        if reference.shape[1] != degraded.shape[1]:
            raise ValueError(f"reference and degraded must have same signal lengths, currently "
                             f"{reference.shape[1]} and {degraded.shape[1]}.")
        if reference.shape[1] < int(sample_rate * 0.4):
            raise ValueError(f"Signals need to be at least 0.4s long, currently: "
                             f"{round(reference.shape[1] / sample_rate, 3)}")

        # resample signals to 44100 Hz
        if self._sample_rate_base != round(sample_rate):
            if self._m_in_sig_resample is None or self._m_in_sig_resample.current_fs != round(sample_rate):
                self._recompute_properties(sample_rate)
            reference = self._m_in_sig_resample.process(reference)
            degraded = self._m_in_sig_resample.process(degraded)

        ref_itd, ref_ic, ref_ild, ref_pow = self._frontend(reference)
        dgr_itd, dgr_ic, dgr_ild, dgr_pow = self._frontend(degraded)

        return {"ref_itd": ref_itd, "ref_ic": ref_ic, "ref_ild": ref_ild, "ref_pow": ref_pow,
                "dgr_itd": dgr_itd, "dgr_ic": dgr_ic, "dgr_ild": dgr_ild, "dgr_pow": dgr_pow}

    def _frontend(self, signal: NDArray) -> tuple[NDArray, NDArray, NDArray, NDArray]:
        # avoid NaNs in IVS calculation
        signal = np.concatenate(([[1e-5], [1e-5]], signal[:, :-1]), axis=1)

        # middle ear bandpass filter
        signal = sosfilt(self._middle_ear_bp, signal).astype(np.complex128)
        # signal = lfilter(self._middle_ear_bp[0], self._middle_ear_bp[1], signal).astype(np.complex128)

        # gammatone filterbank
        sig_fb = np.zeros((2, self._gtfb.n_filters, signal.shape[1]))
        sig_fb[0, :, :] = np.real(self._gtfb.process(signal[0, :], save_state=False))
        sig_fb[1, :, :] = np.real(self._gtfb.process(signal[1, :], save_state=False))
        sig_fb = np.pow(np.fmax(sig_fb, 0.), self._compr_power)
        # sig_fb = np.fmax(sig_fb, 0.)

        # audio signal power calculation
        sig_res = self._m_resample.process(sig_fb)

        sig_pow = np.pow(np.abs(sig_res), 2 / self._compr_power)

        # ILD
        ild = np.fmax(sosfilt(self._ild_low, np.fmax(sig_res, 0.)), 1e-4)
        ild = 20 * np.log10(ild[1, :, :] / ild[0, :, :]) / self._compr_power

        # haircell processing
        sig_fb = sosfilt(self._haircell_lp, sig_fb).astype(np.complex128)

        # fine structure filter
        sig_fb[0, 0:self._gtfb_fine.n_filters, :] = self._gtfb_fine.process(sig_fb[0, 0:self._gtfb_fine.n_filters, :],
                                                                            save_state=False)
        sig_fb[1, 0:self._gtfb_fine.n_filters, :] = self._gtfb_fine.process(sig_fb[1, 0:self._gtfb_fine.n_filters, :],
                                                                            save_state=False)

        # modulation filter part 1, derivation to remove DC
        dc_filter = np.array([[1., -1., 0, 1., 0., 0.]])
        sig_fb[:, self._gtfb_fine.n_filters::, :] = sosfilt(dc_filter, sig_fb[:, self._gtfb_fine.n_filters::, :])

        # modulation filter part 2
        sig_fb[:, self._gtfb_fine.n_filters::, :] = sosfilt(self._mod_low1, sig_fb[:, self._gtfb_fine.n_filters::, :])
        sig_fb[:, self._gtfb_fine.n_filters::, :] = sosfilt(self._mod_low2, sig_fb[:, self._gtfb_fine.n_filters::, :])
        sig_fb[0, self._gtfb_fine.n_filters::, :] = self._gtfb_mod.process(sig_fb[0, self._gtfb_fine.n_filters::, :],
                                                                           save_state=False)
        sig_fb[1, self._gtfb_fine.n_filters::, :] = self._gtfb_mod.process(sig_fb[1, self._gtfb_fine.n_filters::, :],
                                                                           save_state=False)

        # calculation of interaural functions from haircell fine structure
        sig_fine_mod = self._m_resample.process(sig_fb)

        sig_itf = sig_fine_mod[1, :, :] * np.conj(sig_fine_mod[0, :, :])
        ipd = np.angle(sig_itf)

        # interaural coherence
        ic = np.zeros(sig_itf.shape)
        f_inst = sig_fine_mod / (np.abs(sig_fine_mod) + 1e-30)
        f_inst[:, :, 1::] = np.conj(f_inst[:, :, 1::]) * f_inst[:, :, :-1]
        f_inst[:, :, 0] = 0. + 0j
        for idx, ic_coeff in enumerate(self._ic_coeff):
            ic[idx, :] = (np.abs(sosfilt(ic_coeff, sig_itf[idx, :])) /
                          np.abs(sosfilt(ic_coeff, np.abs(sig_itf[idx, :]))))
            f_inst[:, idx, :] = sosfilt(ic_coeff, f_inst[:, idx, :])
        f_inst = np.angle(np.conj(f_inst)) * self._sample_rate_new / (2 * np.pi)
        f_inst = np.fmax(1e-30, np.mean(f_inst, axis=0))

        # avoid division by zero
        f_inst[:, 0:10] = np.repeat(np.concatenate((self._gtfb_fine.cf, self._gtfb_mod.cf))[:, np.newaxis], 10,
                                    1)

        # ITD
        itd = ipd / (2 * np.pi * f_inst)

        return itd, ic, ild, sig_pow

    def backend(self, ref_itd: NDArray, ref_ic: NDArray, ref_ild: NDArray, ref_pow: NDArray, dgr_itd: NDArray,
                 dgr_ic: NDArray, dgr_ild: NDArray, dgr_pow: NDArray) -> dict:
        """
        Backend part of BAMQ-processing.
        :param ref_itd: interaural time difference of reference signal
        :param ref_ic: interaural correlation of reference signal
        :param ref_ild: interaural level difference of reference signal
        :param ref_pow: power of reference signal
        :param dgr_itd: interaural time difference of degraded signal
        :param dgr_ic: interaural correlation of degraded signal
        :param dgr_ild: interaural level difference of degraded signal
        :param dgr_pow: power of degraded signal
        :return: see process()
        """
        resi_samples = ref_itd.shape[-1] % self._block_len
        nblocks = int(ref_itd.shape[-1] / self._block_len) + int(resi_samples > 0)
        ild_diffs = []
        ivs_diffs = []
        itd_diffs = []

        for idx in range(nblocks):
            sample_slice = slice(idx * self._block_len, (idx + 1) * self._block_len)
            ref_mean_pow = np.mean(ref_pow[:, :, sample_slice], axis=-1)
            dgr_mean_pow = np.mean(dgr_pow[:, :, sample_slice], axis=-1)
            ref_max_pow = np.max(ref_mean_pow)
            dgr_max_pow = np.max(dgr_mean_pow)
            idx_high_pow_bands = np.array(list(
                set(np.argwhere(ref_mean_pow > (ref_max_pow / 10))[:, -1]).union(
                set(np.argwhere(dgr_mean_pow > (dgr_max_pow / 10))[:, -1]))))

            # ILD diff
            ref_ild_band = ref_ild[idx_high_pow_bands, sample_slice]
            dgr_ild_band = dgr_ild[idx_high_pow_bands, sample_slice]
            ref_ild_band = np.fmin(np.fmax(ref_ild_band, -10), 10)
            dgr_ild_band = np.fmin(np.fmax(dgr_ild_band, -10), 10)
            ref_ild_pos = np.sum(np.fmax(ref_ild_band, 0.), axis=-1)
            ref_ild_neg = np.abs(np.sum(np.fmin(ref_ild_band, 0.), axis=-1))
            dgr_ild_pos = np.sum(np.fmax(dgr_ild_band, 0.), axis=-1)
            dgr_ild_neg = np.abs(np.sum(np.fmin(dgr_ild_band, 0.), axis=-1))
            ild_diff_band = np.abs(ref_ild_pos - dgr_ild_pos) + np.abs(ref_ild_neg - dgr_ild_neg)

            if idx >= nblocks - 1 and resi_samples > 0:
                ild_diff_band *= self._block_len / resi_samples

            ild_diffs += ild_diff_band.tolist()

            # ITD diff part 1
            ref_itd_band = ref_itd[idx_high_pow_bands, sample_slice]
            dgr_itd_band = dgr_itd[idx_high_pow_bands, sample_slice]
            ref_valid = np.abs(ref_itd_band) < 7e-4
            dgr_valid = np.abs(dgr_itd_band) < 7e-4

            for idx2, band in enumerate(idx_high_pow_bands):
                # IVS diff
                neighbors = np.argwhere(np.abs(idx_high_pow_bands - band) <= 1)[:, 0]
                ref_ic_band = np.mean(ref_ic[idx_high_pow_bands[neighbors], sample_slice], axis=0)
                dgr_ic_band = np.mean(dgr_ic[idx_high_pow_bands[neighbors], sample_slice], axis=0)
                ivs_diffs.append(np.abs(np.mean(np.exp(self._k[band] + self._n[band]) -
                                                np.exp(self._k[band] * ref_ic_band + self._n[band])) -
                                        np.mean(np.exp(self._k[band] + self._n[band]) -
                                                np.exp(self._k[band] * dgr_ic_band + self._n[band]))))

                # ITD diff part 2
                ref_valid_tmp = np.logical_and(np.logical_and(ref_ic_band > self._ivs_thres,
                                                              np.append(np.diff(ref_ic_band) >= 0., 0)),
                                               ref_valid[idx2, :])
                dgr_valid_tmp = np.logical_and(np.logical_and(dgr_ic_band > self._ivs_thres,
                                                              np.append(np.diff(dgr_ic_band) >= 0., 0)),
                                               dgr_valid[idx2, :])
                # TODO: discuss denominator for final block
                ref_itd_pos = (np.sum(np.fmax(ref_itd_band[idx2, ref_valid_tmp], 0.)) /
                               (self._block_len - np.sum(np.logical_not(ref_valid_tmp)) + 1e-30))
                ref_itd_neg = (np.sum(np.abs(np.fmin(ref_itd_band[idx2, ref_valid_tmp], 0.))) /
                               (self._block_len - np.sum(np.logical_not(ref_valid_tmp)) + 1e-30))
                dgr_itd_pos = (np.sum(np.fmax(dgr_itd_band[idx2, dgr_valid_tmp], 0.)) /
                               (self._block_len - np.sum(np.logical_not(dgr_valid_tmp)) + 1e-30))
                dgr_itd_neg = (np.sum(np.abs(np.fmin(dgr_itd_band[idx2, dgr_valid_tmp], 0.))) /
                               (self._block_len - np.sum(np.logical_not(dgr_valid_tmp)) + 1e-30))
                itd_diff_band = np.abs(ref_itd_pos - dgr_itd_pos) + np.abs(ref_itd_neg - dgr_itd_neg)

                if idx >= nblocks - 1 and resi_samples > 0:
                    itd_diff_band *= self._block_len / resi_samples

                itd_diffs.append(itd_diff_band)

        ild_diff = np.mean(ild_diffs)
        itd_diff = np.mean(itd_diffs)
        ivs_diff = np.mean(ivs_diffs)

        # binQ calculation
        ## ILD diff
        if ild_diff <= 1129.2:
            f1 = 0
            f2 = 2258.4 - ild_diff
        elif 1129.2 < ild_diff < 6147.2:
            p1_1 = (2 * 6147.2 + 1129.2 - 3 * 2258.4) / (6147.2 - 1129.2) ** 2
            r1_1 = (2 * 2258.4 - 6147.2 - 1129.2) / (6147.2 - 1129.2) ** 3
            f1 = p1_1 * (ild_diff - 1129.2) ** 2 + r1_1 * (ild_diff - 1129.2) ** 3
            p2_1 = (3 * 2258.4 - 2 * 1129.2 - 6147.2) / (1129.2 - 6147.2) ** 2
            r2_1 = (1129.2 + 6147.2 - 2 * 2258.4) / (1129.2 - 6147.2) ** 3
            f2 = p2_1 * (ild_diff - 6147.2) ** 2 + r2_1 * (ild_diff - 6147.2) ** 3
        else:
            f1 = ild_diff - 2258.4
            f2 = 0

        ## IVS diff
        if ivs_diff <= 0.055351:
            f3 = 0.1107 - ivs_diff
        elif 0.055351 < ivs_diff < 0.21385:
            p3_1 = (3 * 0.1107 - 2 * 0.055351 - 0.21385) / (0.055351 - 0.21385) ** 2
            r3_1 = (0.055351 + 0.21385 - 2 * 0.1107) / (0.055351 - 0.21385) ** 3
            f3 = p3_1 * (ivs_diff - 0.21385) ** 2 + r3_1 * (ivs_diff - 0.21385) ** 3
        else:
            f3 = 0

        ## ITD diff
        if itd_diff <= 3.8116e-5:
            f4 = 0
        elif 3.8116e-5 < itd_diff < 0.00018021:
            p4_2 = (2 * 0.00018021 + 3.8116e-5 - 3 * 7.6232e-5) / (0.00018021 - 3.8116e-5) ** 2
            r4_2 = (2 * 7.6232e-5 - 0.00018021 - 3.8116e-5) / (0.00018021 - 3.8116e-5) ** 3
            f4 = p4_2 * (itd_diff - 3.8116e-5) ** 2 + r4_2 * (itd_diff - 3.8116e-5) ** 3
        else:
            f4 = itd_diff - 7.6232e-5

        bin_q = np.clip(round(np.ceil(38.228 - 0.0054695 * f1 + 0.0047733 * f2 + f3 * (455.08 - 1.6949e6 * f4))),
                        a_min=0, a_max=100)

        return {"bin_q": bin_q, "ild_diff": ild_diff, "itd_diff": itd_diff, "ivs_diff": ivs_diff}
