# This file is part of auditory_models
# Copyright (C) 2025 Max Zimmermann
#
# auditory_models is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# auditory_models is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with auditory_models.  If not, see <https://www.gnu.org/licenses/>.


import numpy as np
from numpy.typing import NDArray
from scipy.signal import stft
import warnings

from auditory_models import AuditoryModel
from auditory_models.helpers import utils


class STOI(AuditoryModel):
    """
    Reference
        [1] C.H.Taal, R.C.Hendriks, R.Heusdens, J.Jensen 'A Short-Time Objective Intelligibility Measure for
            Time-Frequency Weighted Noisy Speech', ICASSP 2010, Texas, Dallas.
        [2] C.H.Taal, R.C.Hendriks, R.Heusdens, J.Jensen 'An Algorithm for Intelligibility Prediction of Time-Frequency
            Weighted Noisy Speech', IEEE Transactions on Audio, Speech, and Language Processing, 2011.
    """
    def __init__(self, sample_rate: int = 10000, block_size: int = 256, nfft: int = 512, min_freq: int = 150,
                 max_freq: int | None = None, n_segmentation: int = 30, beta: float = -15.0, dyn_range: float = 40.0) \
            -> None:
        """
        Short term objective intelligibility
        Computes the STOI (See [1][2]) of a denoised signal compared to a clean
        signal, The output is expected to have a monotonic relation with the
        subjective speech-intelligibility, where a higher score denotes better
        speech intelligibility.
        ==NOTE!==: The third-octave bands now have fixed center frequencies (as defined by IEC 61260-1:2014) that do not
            change with 'min_freq'. The number of bands is determined by 'min_freq', which defines the lowest possible
            center frequency and 'max_freq', which defines the highest possible center frequency. If 'max_freq' is not
            provided, it will default to the Nyquist-frequency.
        :param sample_rate: Sampling frequency, if not integer it will be rounded to the nearest
        :param block_size: Block size in samples for STFT
        :param nfft: Number of FFT-bins per block
        :param min_freq: Minimum center frequency of third octave bands
        :param max_freq: Maximum center frequency of third octave bands
        :param n_segmentation: Number of blocks that will be grouped together
        :param beta: Lower signal-to-distortion bound
        :param dyn_range: Dynamic range with respect to the block with maximum energy. All blocks below that range are
        treated as silent and will be removed from further computation.
        """
        super().__init__()
        self._sample_rate = round(sample_rate)
        self._block_size = block_size
        self._nfft = nfft
        self._min_freq = min_freq
        self._max_freq = np.min((max_freq, round(self._sample_rate / 2))) if max_freq else round(self._sample_rate / 2)
        # Get 1/3 octave band matrix
        self._obm, self._cf = utils.thirdoct(self._sample_rate, self._nfft, min_freq=self._min_freq, max_freq=self._max_freq)
        self._n_segmentation = n_segmentation
        self._beta = beta
        self._dyn_range = dyn_range
        self.resampler = utils.ResampleOct(target_fs=self._sample_rate)
        self._m_in_sig_resample = None
        self.name = "STOI"
        self.unit = ""

    def _recompute_properties(self, sample_rate: float) -> None:
        self._m_in_sig_resample = utils.MatlabResample(self._sample_rate, round(sample_rate))

    def process(self, reference: NDArray, degraded: NDArray, fs_sig: int) -> float:
        """
        Compute the STOI from two input signals and their sampling frequency.

        :param reference: clean original signal
        :param degraded: degraded signal
        :param fs_sig: sampling rate of reference and degraded
        :return: float: Short time objective intelligibility measure between clean and degraded

        # Acknowledgment
            This method is a modified version from the pystoi implementation by Manuel Pariente
            (https://github.com/mpariente/pystoi), for previous licensing see file LICENSE.old in the same directory as
            this file.
        """
        return self.backend(self.frontend(reference, degraded, fs_sig))

    def frontend(self, reference: NDArray, degraded: NDArray, sample_rate: int) -> NDArray:
        """
        Frontend of STOI.

        :param reference: clean original signal
        :param degraded: degraded signal
        :param sample_rate: sampling rate of reference and degraded, if not integer it will be rounded to the nearest
        :return: float: Short time objective intelligibility measure between clean and degraded
        """
        reference = np.squeeze(reference)
        degraded = np.squeeze(degraded)
        if reference.shape != degraded.shape:
            raise ValueError(f"reference and degraded should have the same length, found {reference.shape} and "
                             f"{degraded.shape}")
        if reference.ndim != 1:
            raise ValueError(f"STOI is made for single channel audio, array of shape {reference.shape} entered...")

        # resample signals to 10000 Hz
        if self._sample_rate != round(sample_rate):
            if self._m_in_sig_resample is None or self._m_in_sig_resample.current_fs != round(sample_rate):
                self._recompute_properties(sample_rate)
            reference = self._m_in_sig_resample.process(reference)
            degraded = self._m_in_sig_resample.process(degraded)
        # if sample_rate != self._sample_rate:
        #     self.resampler.current_fs = sample_rate
        #     reference = self.resampler.process(reference)
        #     degraded = self.resampler.process(degraded)

        # Remove silent frames
        reference, degraded = utils.remove_silent_frames(reference, degraded, self._dyn_range, self._block_size,
                                                         round(self._block_size / 2))

        # Take STFT
        ref_spec = stft(reference, fs=self._sample_rate, window="hann", nperseg=self._block_size, nfft=self._nfft, axis=0)[2]
        dgr_spec = stft(degraded, fs=self._sample_rate, window="hann", nperseg=self._block_size, nfft=self._nfft, axis=0)[2]

        # Ensure at least 30 frames for intermediate intelligibility
        if ref_spec.shape[-1] < self._n_segmentation:
            warnings.warn("Not enough STFT frames to compute intermediate intelligibility measure after "
                          "removing silent frames. Returning 1e-5. Please check your audio data", RuntimeWarning)
            return np.array([1e-5])

        # Apply OB matrix to the spectrograms as in Eq. (1)
        ref_tob = np.sqrt(np.matmul(self._obm, np.square(np.abs(ref_spec))))
        dgr_tob = np.sqrt(np.matmul(self._obm, np.square(np.abs(dgr_spec))))

        # For some values of fs, nfft, and min_freq the resulting obm has third-octave bands (in lower frequencies) that
        # do not include any frequency bins, so these bands will only hold zeros. To prevent an influence on the
        # mean correlation we remove the zero rows from further computation here.
        delete_zero_rows = np.logical_not(np.any(self._obm, axis=1))
        ref_tob = np.delete(ref_tob, delete_zero_rows, 0)
        dgr_tob = np.delete(dgr_tob, delete_zero_rows, 0)

        # Take segments of ref_tob, dgr_tob
        ref_segments = np.array(
            [ref_tob[:, m - self._n_segmentation:m] for m in range(self._n_segmentation, ref_tob.shape[1] + 1)])
        dgr_segments = np.array(
            [dgr_tob[:, m - self._n_segmentation:m] for m in range(self._n_segmentation, ref_tob.shape[1] + 1)])

        # Find normalization constants and normalize
        normalization_consts = (
                np.linalg.norm(ref_segments, axis=2, keepdims=True) /
                (np.linalg.norm(dgr_segments, axis=2, keepdims=True) + utils.EPS))
        dgr_segments_normalized = dgr_segments * normalization_consts

        # Clip as described in [1]
        clip_value = 10 ** (-self._beta / 20)
        dgr_primes = np.minimum(dgr_segments_normalized, ref_segments * (1 + clip_value))

        # Subtract mean vectors
        dgr_primes = dgr_primes - np.mean(dgr_primes, axis=2, keepdims=True)
        ref_segments = ref_segments - np.mean(ref_segments, axis=2, keepdims=True)

        # Get intermediate intelligibility in [1] eq. 5
        correlations_components = np.sum(dgr_primes * ref_segments, axis=2) / (
                np.linalg.norm(dgr_primes, axis=2) * np.linalg.norm(ref_segments, axis=2) + utils.EPS)

        return correlations_components

    def backend(self, correlations_components: NDArray) -> float:
        """
        Backend of STOI.

        :param correlations_components: matrix of the correlation coefficients per time-frequency index
        :return: STOI measure
        """
        # Find the mean of all correlations as in [1], eq.6
        return np.mean(correlations_components).astype(float)

    def export_config(self) -> dict:
        """
        Export the parameters as dictionary.
        :return: Dictionary containing parameters
        """
        out_config = super().export_config()
        out_config.update(dict(
            fs=int(self._sample_rate),
            block_size=int(self._block_size),
            nfft=int(self._nfft),
            min_freq=int(self._min_freq),
            max_freq=int(self._max_freq),
            n_segmentation=int(self._n_segmentation),
            beta=float(self._beta),
            dyn_range=float(self._dyn_range)))
        return out_config
