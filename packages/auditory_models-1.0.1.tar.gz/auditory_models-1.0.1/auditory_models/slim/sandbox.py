# This file is part of auditory_models
# Copyright (C) 2025 Max Zimmermann
#
# auditory_models is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# auditory_models is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with auditory_models.  If not, see <https://www.gnu.org/licenses/>.


import librosa
import numpy as np
import scipy.signal
from numpy.typing import NDArray
from scipy.signal import stft, spectrogram, correlate2d
import warnings

from auditory_models.helpers import utils
from auditory_models.helpers.filterbank import BandpassFilterbank, frequencies_auditory_filter, GammatoneFilterbank
from sink import matrix_plot, plot


class Sandbox:
    def __init__(self, fs: int = 44100, block_size: int | None = None, nfft: int | None = None,
                 min_freq: int | None = None, max_freq: int | None = None, n_segmentation: int | None = None,
                 beta: float | None = None, dyn_range: float | None = None,
                 steps: tuple = ("resample", "remove_silence", "stft", "check_length", "apply_tob_matrix",
                                 "segmentation", "normalization", "clipping", "subtract_mean", "correlation",
                                 "mean_all")) -> None:
        """
        Sandbox to test different things
        :param fs: Sampling frequency
        :param block_size: Block size in samples for STFT
        :param nfft: Number of FFT-bins per block
        :param min_freq: Minimum center frequency of third octave bands
        :param max_freq: Maximum center frequency of third octave bands
        :param n_segmentation: Number of blocks that will be grouped together
        :param beta: Lower signal-to-distortion bound
        :param dyn_range: Dynamic range with respect to the block with maximum energy. All blocks below that range are
        treated as silent and will be removed from further computation.
        :param steps: tuple of strings containing the calculation steps in the order they should be executed

        # Reference
            [1] C.H.Taal, R.C.Hendriks, R.Heusdens, J.Jensen 'A Short-Time
                Objective Intelligibility Measure for Time-Frequency Weighted Noisy
                Speech', ICASSP 2010, Texas, Dallas.
            [2] C.H.Taal, R.C.Hendriks, R.Heusdens, J.Jensen 'An Algorithm for
                Intelligibility Prediction of Time-Frequency Weighted Noisy Speech',
                IEEE Transactions on Audio, Speech, and Language Processing, 2011.
        """
        self._fs = fs
        self._block_size = block_size
        self._nfft = nfft
        self._min_freq = min_freq
        self._max_freq = np.min((max_freq, round(self._fs / 2))) if max_freq else round(self._fs / 2)
        self._n_segmentation = n_segmentation
        self._beta = beta
        self._dyn_range = dyn_range
        self._steps = steps
        self.resampler = utils.ResampleOct(target_fs=self._fs)
        cf = frequencies_auditory_filter(0, 33, 50, 1.)
        self.bpfb = BandpassFilterbank(cf, self._fs, dc_lowpass=False)
        self.gtfb = GammatoneFilterbank(sample_rate=self._fs, cf=cf)
        self.name = ""
        self.unit = ""

    def process(self, target: NDArray, mixture: NDArray, fs_sig: int) -> float | NDArray:
        """
        Compute an answer if the target is part of mixture.

        :param target: clean original speech
        :param mixture: denoised speech
        :param fs_sig: sampling rate of target and mixture
        :return: float: Short time objective intelligibility measure between clean and denoised speech
            NDArray of floats if `variation`="pre-mean"

        # Raises
            AssertionError : if x and y have different lengths

        # Acknowledgment
            This method is a modified version from the pystoi implementation by Manuel Pariente
            (https://github.com/mpariente/pystoi), for previous licensing see file auditory_models/stoi/LICENSE.old .
        """
        assert target.shape == mixture.shape, f"x and y should have the same length, found {target.shape} and {mixture.shape}"
        assert len(target.shape) == 1, f"STOI is made for single channel audio, array of shape {target.shape} entered..."

        # nbins = round(np.floor(12 * np.log2(self._max_freq / (32.7 + 1e-30))))
        # target_vqt = 20*np.log10(np.abs(librosa.vqt(target, sr=self._fs, hop_length=round(self._block_size / 2), fmin=32.7,
        #                             n_bins=nbins)) + 1e-6)
        # mixture_vqt = 20*np.log10(np.abs(librosa.vqt(mixture, sr=self._fs, hop_length=round(self._block_size / 2), fmin=32.7,
        #                              n_bins=nbins)) + 1e-6)
        # matrix_plot(target_vqt)
        # matrix_plot(mixture_vqt)

        result = 0.
        for idx, step in enumerate(self._steps):
            if step == "resample":
                target, mixture = self._resample_to_new_fs(target, mixture, fs_sig)
            elif step == "time_align":
                target, mixture = self._time_align(target, mixture)
            elif step == "remove_silence":
                target, mixture = self._remove_silent_frames(target, mixture)
            elif step == "blockwise":
                target = self._blockwise(target)
                mixture = self._blockwise(mixture)
            elif step == "stft":
                target, mixture = self._stft(target, mixture)
            elif step == "vqt":
                target, mixture = self._vqt(target, mixture)
            elif step == "chromagram":
                target = np.abs(librosa.feature.chroma_vqt(y=target, sr=fs_sig, hop_length=round(self._block_size / 2), fmin=30, intervals="equal"))
                mixture = np.abs(librosa.feature.chroma_vqt(y=mixture, sr=fs_sig, hop_length=round(self._block_size / 2), fmin=30, intervals="equal"))
            elif step == "check_length":
                if target.shape[-1] < self._n_segmentation:
                    warnings.warn("Not enough STFT frames to compute intermediate "
                                  "intelligibility measure after removing silent "
                                  "frames. Returning 1e-5. Please check your wav files",
                                  RuntimeWarning)
                    return 1e-5
            elif step == "apply_tob_matrix":
                target, mixture = self._apply_tob_matrix(target, mixture)
            elif step == "segmentation":
                target, mixture = self._segmentation(target, mixture)
            elif step == "normalization":
                mixture = self._normalization(target, mixture)
            elif step == "normalize_rms":
                target, mixture = self._normalize_rms(target, mixture)
            elif step == "clipping":
                mixture = self._clipping(target, mixture)
            elif step == "subtract_mean":
                target, mixture = self._subtract_mean(target, mixture)
            elif step == "correlation":
                result = self._correlation(target, mixture)
            elif step == "correlation2d":
                result = correlate2d(target, mixture, mode="same") / np.sqrt(np.sum(np.square(target)) *
                                                                             np.sum(np.square(mixture)))
            elif step == "corr_coef":
                result = self._corr_coef(target, mixture)
            elif step == "xcorr":
                result = np.correlate(target, mixture, mode="same")
            elif step == "time_freq_corr_coef":
                result, target, mixture = self._time_freq_corr_coef(target, mixture)
            elif step == "time_freq_corr_coef_gamma":
                result, target, mixture = self._time_freq_corr_coef_gamma(target, mixture)
            elif step == "correlate_spectrograms":
                result = self._correlate_spectrograms(target, mixture)
            elif step == "combined_correlation1":
                result = self._combined_correlation1(target, mixture)
            elif step == "modulation_spectrum":
                target, mixture = self._modulation_spectrum(target, mixture)
            elif step == "harmonic_components":
                target, mixture = self._harmonic_components(target, mixture)
            elif step == "percussive_components":
                target, mixture = self._percussive_components(target, mixture)
            elif step == "spectral_weight_mean":
                result = self._spectral_weight_mean(result, target)
            elif step == "absolute":
                target = np.abs(target)
                mixture = np.abs(mixture)
                result = np.abs(result)
            elif step == "log10":
                target = 20 * np.log10(target + 1e-30)
                mixture = 20 * np.log10(mixture + 1e-30)
                result = 20 * np.log10(result + 1e-30)
            elif step == "mean_all":
                result = np.mean(result)
            elif step == "90_percentile":
                result = result[result > np.percentile(result, 90)]
            elif step == "99_percentile":
                result = result[result > np.percentile(result, 99)]
            elif step == "high_corr_ratio":
                result = np.sum(result > 0.9) / result.size
            elif step == "inv_frobenius_norm":
                result = 1 - np.linalg.norm(target - mixture, "fro") / target.size
            else:
                raise ValueError(f"'{step}' is not a valid step!")
        return result

    def _remove_silent_frames(self, target: NDArray, mixture: NDArray) -> tuple[NDArray, NDArray]:
        return utils.remove_silent_frames(target, mixture, self._dyn_range, self._block_size, round(self._block_size / 2))

    def _resample_to_new_fs(self, target: NDArray, mixture: NDArray, fs_sig: float) -> tuple[NDArray, NDArray]:
        if fs_sig != self._fs:
            self.resampler.current_fs = fs_sig
            target = self.resampler.process(target)
            mixture = self.resampler.process(mixture)
        return target, mixture

    def _stft(self, target: NDArray, mixture: NDArray) -> tuple[NDArray, NDArray]:
        target = stft(target, fs=self._fs, window="hann", nperseg=self._block_size, nfft=self._nfft, axis=0)[2]
        mixture = stft(mixture, fs=self._fs, window="hann", nperseg=self._block_size, nfft=self._nfft, axis=0)[2]
        return target, mixture

    def _vqt(self, target: NDArray, mixture: NDArray) -> tuple[NDArray, NDArray]:
        nbins = round(np.floor(12 * np.log2(self._max_freq / (self._min_freq + 1e-30))))
        target = np.abs(librosa.vqt(target, sr=self._fs, hop_length=round(self._block_size / 2), fmin=self._min_freq,
                                    n_bins=nbins))
        mixture = np.abs(librosa.vqt(mixture, sr=self._fs, hop_length=round(self._block_size / 2), fmin=self._min_freq,
                                     n_bins=nbins))
        return target, mixture


    def _apply_tob_matrix(self, target: NDArray, mixture: NDArray) -> tuple[NDArray, NDArray]:
        target = np.sqrt(np.matmul(self._obm, np.square(np.abs(target))))
        mixture = np.sqrt(np.matmul(self._obm, np.square(np.abs(mixture))))
        # For some values of fs, nfft, and min_freq the resulting obm has third-octave bands (in lower frequencies) that
        # do not include any frequency bins, so these bands will only hold zeros. To prevent an influence on the
        # mean correlation we remove the zero rows from further computation here.
        delete_zero_rows = np.logical_not(np.any(self._obm, axis=1))
        target = np.delete(target, delete_zero_rows, 0)
        mixture = np.delete(mixture, delete_zero_rows, 0)
        return target, mixture

    def _segmentation(self, target: NDArray, mixture: NDArray) -> tuple[NDArray, NDArray]:
        target = np.array(
            [target[:, m - self._n_segmentation:m] for m in range(self._n_segmentation, target.shape[1] + 1)])
        mixture = np.array(
            [mixture[:, m - self._n_segmentation:m] for m in range(self._n_segmentation, mixture.shape[1] + 1)])
        return target, mixture

    @staticmethod
    def _normalize_rms(target: NDArray, mixture: NDArray) -> tuple[NDArray, NDArray]:
        target /= np.sqrt(np.mean(np.square(target), axis=-1))
        mixture /= np.sqrt(np.mean(np.square(mixture), axis=-1))
        return target, mixture

    @staticmethod
    def _normalization(target: NDArray, mixture: NDArray) -> NDArray:
        normalization_consts = (np.linalg.norm(target, axis=2, keepdims=True) /
                                (np.linalg.norm(mixture, axis=2, keepdims=True) + utils.EPS))
        mixture *= normalization_consts
        return mixture

    def _clipping(self, target: NDArray, mixture: NDArray) -> NDArray:
        clip_value = 10 ** (-self._beta / 20)
        mixture = np.minimum(mixture, target * (1 + clip_value))
        return mixture

    @staticmethod
    def _subtract_mean(target: NDArray, mixture: NDArray) -> tuple[NDArray, NDArray]:
        mixture -= np.mean(mixture, axis=2, keepdims=True)
        target -= np.mean(target, axis=2, keepdims=True)
        return target, mixture

    @staticmethod
    def _correlation(target: NDArray, mixture: NDArray) -> NDArray:
        return np.sum(mixture * target, axis=2) / (
                np.linalg.norm(mixture, axis=2) * np.linalg.norm(target, axis=2) + utils.EPS)

    def _blockwise(self, signal: NDArray) -> NDArray:
        hop_size = round(self._block_size / 2)
        window = np.hanning(self._block_size)
        blocks = round(np.ceil(signal.size / hop_size))
        signal = np.pad(signal, (0, (blocks + 1) * hop_size - signal.size))
        return np.array([window * signal[idx * hop_size:idx * hop_size + self._block_size] for idx in range(blocks)])

    @staticmethod
    def _corr_coef(target: NDArray, mixture: NDArray) -> float | NDArray:
        if target.ndim == 2:
            result = []
            for tar, mix in zip(target, mixture):
                result.append(np.corrcoef(tar, mix)[0, 1])
            result = np.array(result)
            result[np.isnan(result)] = 0.
        else:
            result = np.corrcoef(target, mixture)[0, 1]
            if np.isnan(result):
                result = 0.
        return result

    def _time_freq_corr_coef(self, target: NDArray, mixture: NDArray) -> tuple[NDArray, NDArray, NDArray]:
        target = self.bpfb.process(target, save_state=False)
        mixture = self.bpfb.process(mixture, save_state=False)
        tf_corrcoef = np.zeros((self.bpfb.cf.size, round(np.ceil(target.shape[1] / round(self._block_size / 2)))))
        for idx, (t_band, m_band) in enumerate(zip(target, mixture)):
            tf_corrcoef[idx, :] = self._corr_coef(self._blockwise(t_band), self._blockwise(m_band))
        # matrix_plot(tf_corrcoef)
        return tf_corrcoef, target, mixture

    def _time_freq_corr_coef_gamma(self, target: NDArray, mixture: NDArray) -> tuple[NDArray, NDArray, NDArray]:
        # target_orig = target
        # mixture_orig = mixture
        target = np.real(self.gtfb.process(target.astype(np.complex128), save_state=False))
        mixture = np.real(self.gtfb.process(mixture.astype(np.complex128), save_state=False))
        tf_corrcoef = np.zeros((self.gtfb.cf.size, round(np.ceil(target.shape[1] / round(self._block_size / 2)))))
        for idx, (t_band, m_band) in enumerate(zip(target, mixture)):
            tf_corrcoef[idx, :] = self._corr_coef(self._blockwise(t_band), self._blockwise(m_band))
        # matrix_plot(tf_corrcoef)
        return tf_corrcoef, target, mixture

    @staticmethod
    def _spectral_weight_mean(result: NDArray, target: NDArray) -> float:
        rms_target = np.sqrt(np.mean(np.square(target), axis=-1))
        rms_norm = (rms_target - np.min(rms_target)) / (np.max(rms_target) - np.min(rms_target))
        return np.mean(result * rms_norm.reshape(rms_norm.size, 1)) / np.mean(rms_norm)

    @staticmethod
    def _time_align(target: NDArray, mixture: NDArray) -> tuple[NDArray, NDArray]:
        min_len = np.minimum(target.size, mixture.size)
        target = target[0:min_len]
        mixture = mixture[0:min_len]
        crit_idx = np.argmax(np.correlate(mixture, target, mode="full")) + 1
        if crit_idx <= min_len:
            target = target[-crit_idx::]
            mixture = mixture[0:target.size]
        else:
            mixture = mixture[crit_idx - mixture.size::]
            target = target[0:mixture.size]
        return target, mixture

    def _modulation_spectrum(self, target: NDArray, mixture: NDArray) -> tuple[NDArray, NDArray]:
        hop_size = round(self._block_size / 2)
        _, _, target = spectrogram(target, fs=self._fs, window="hann", nperseg=self._block_size,
                                   noverlap=self._block_size - hop_size, nfft=self._nfft)
        _, _, mixture = spectrogram(mixture, fs=self._fs, window="hann", nperseg=self._block_size,
                                    noverlap=self._block_size - hop_size, nfft=self._nfft)
        target_mod = np.fft.fft2(target)
        mixture_mod = np.fft.fft2(mixture)
        target_mod = 20*np.log10(np.abs(target_mod[0:round(target_mod.shape[0] / 2 + 1), 0:round(target_mod.shape[1] / 2 + 1)])).ravel()
        mixture_mod = 20*np.log10(np.abs(mixture_mod[0:round(mixture_mod.shape[0] / 2 + 1), 0:round(mixture_mod.shape[1] / 2 + 1)])).ravel()
        return target_mod, mixture_mod

    @staticmethod
    def _harmonic_components(target: NDArray, mixture: NDArray) -> tuple[NDArray, NDArray]:
        target = librosa.effects.harmonic(target)
        mixture = librosa.effects.harmonic(mixture)
        return target, mixture

    @staticmethod
    def _percussive_components(target: NDArray, mixture: NDArray) -> tuple[NDArray, NDArray]:
        target = librosa.effects.percussive(target)
        mixture = librosa.effects.percussive(mixture)
        return target, mixture

    @staticmethod
    def _correlate_spectrograms(target: NDArray, mixture: NDArray) -> NDArray:
        result = np.zeros((target.shape[1], mixture.shape[1]))
        t_norm = np.linalg.norm(target, 2, axis=0)
        m_norm = np.linalg.norm(mixture, 2, axis=0)
        for idx_t in range(target.shape[1]):
            for idx_m in range(mixture.shape[1]):
                result[idx_t, idx_m] = np.dot(target[:, idx_t], mixture[:, idx_m])
        result /= t_norm[:, np.newaxis] * m_norm[np.newaxis, :]
        result[np.isnan(result)] = 0.0
        # matrix_plot(target)
        # matrix_plot(mixture)
        # matrix_plot(result)
        return result

    def _combined_correlation1(self, target: NDArray, mixture: NDArray) -> float:
        corr1 = np.mean(self._time_freq_corr_coef(target, mixture)[0])
        target, mixture = self._stft(target, mixture)
        corr2 = np.mean(self._correlate_spectrograms(np.abs(target), np.abs(mixture)))
        return (corr1 + corr2) / 2

    def export_config(self) -> dict:
        """
        Export the parameters as dictionary.
        :return: Dictionary containing parameters
        """
        out_config = dict(
            fs=int(self._fs),
            block_size=self._block_size,
            nfft=self._nfft,
            min_freq=self._min_freq,
            max_freq=int(self._max_freq),
            n_segmentation=self._n_segmentation,
            beta=self._beta,
            dyn_range=self._dyn_range,
            steps=self._steps)
        return out_config
