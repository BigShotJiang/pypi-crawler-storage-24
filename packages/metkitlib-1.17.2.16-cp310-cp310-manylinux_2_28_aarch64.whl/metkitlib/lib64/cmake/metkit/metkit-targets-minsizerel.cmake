#----------------------------------------------------------------
# Generated CMake target import file for configuration "MinSizeRel".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "metkit" for configuration "MinSizeRel"
set_property(TARGET metkit APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(metkit PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/lib64/libmetkit.so"
  IMPORTED_SONAME_MINSIZEREL "libmetkit.so"
  )

list(APPEND _cmake_import_check_targets metkit )
list(APPEND _cmake_import_check_files_for_metkit "${_IMPORT_PREFIX}/lib64/libmetkit.so" )

# Import target "parse-mars-request" for configuration "MinSizeRel"
set_property(TARGET parse-mars-request APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(parse-mars-request PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/bin/parse-mars-request"
  )

list(APPEND _cmake_import_check_targets parse-mars-request )
list(APPEND _cmake_import_check_files_for_parse-mars-request "${_IMPORT_PREFIX}/bin/parse-mars-request" )

# Import target "grib-to-request" for configuration "MinSizeRel"
set_property(TARGET grib-to-request APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(grib-to-request PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/bin/grib-to-request"
  )

list(APPEND _cmake_import_check_targets grib-to-request )
list(APPEND _cmake_import_check_files_for_grib-to-request "${_IMPORT_PREFIX}/bin/grib-to-request" )

# Import target "bufr-sanity-check" for configuration "MinSizeRel"
set_property(TARGET bufr-sanity-check APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(bufr-sanity-check PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/bin/bufr-sanity-check"
  )

list(APPEND _cmake_import_check_targets bufr-sanity-check )
list(APPEND _cmake_import_check_files_for_bufr-sanity-check "${_IMPORT_PREFIX}/bin/bufr-sanity-check" )

# Import target "mars-archive-script" for configuration "MinSizeRel"
set_property(TARGET mars-archive-script APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(mars-archive-script PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/bin/mars-archive-script"
  )

list(APPEND _cmake_import_check_targets mars-archive-script )
list(APPEND _cmake_import_check_files_for_mars-archive-script "${_IMPORT_PREFIX}/bin/mars-archive-script" )

# Import target "check-mars2conf" for configuration "MinSizeRel"
set_property(TARGET check-mars2conf APPEND PROPERTY IMPORTED_CONFIGURATIONS MINSIZEREL)
set_target_properties(check-mars2conf PROPERTIES
  IMPORTED_LOCATION_MINSIZEREL "${_IMPORT_PREFIX}/bin/check-mars2conf"
  )

list(APPEND _cmake_import_check_targets check-mars2conf )
list(APPEND _cmake_import_check_files_for_check-mars2conf "${_IMPORT_PREFIX}/bin/check-mars2conf" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
