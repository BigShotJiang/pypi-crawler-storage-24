#ifndef metkit_version_h
#define metkit_version_h

#define metkit_VERSION_STR "1.17.2"
#define metkit_VERSION     "1.17.2"

#define metkit_VERSION_MAJOR 1
#define metkit_VERSION_MINOR 17
#define metkit_VERSION_PATCH 2

#define metkit_GIT_SHA1 "b9da50c4cd5ffcad8fe6eea10b257cfbe0bb2efa"

#ifdef __cplusplus
extern "C" {
#endif

const char * metkit_version();

unsigned int metkit_version_int();

const char * metkit_version_str();

const char * metkit_git_sha1();

#ifdef __cplusplus
}
#endif


#endif // metkit_version_h
