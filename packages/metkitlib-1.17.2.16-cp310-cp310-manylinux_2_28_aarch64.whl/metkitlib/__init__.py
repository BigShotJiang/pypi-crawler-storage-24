__version__ = '1.17.2.16'
__commit_hash__ = 'b9da50c4cd5ffcad8fe6eea10b257cfbe0bb2efa'
findlibs_dependencies = ["eckitlib", "eccodeslib"]
