"""OpenAI example package placeholder."""
