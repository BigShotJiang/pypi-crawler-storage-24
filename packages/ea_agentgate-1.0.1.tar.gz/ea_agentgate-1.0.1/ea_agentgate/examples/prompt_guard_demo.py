"""Prompt guard demo placeholder."""
