"""Tests for agentgate package."""
