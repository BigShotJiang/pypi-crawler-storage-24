"""MCP policy adapter package."""
