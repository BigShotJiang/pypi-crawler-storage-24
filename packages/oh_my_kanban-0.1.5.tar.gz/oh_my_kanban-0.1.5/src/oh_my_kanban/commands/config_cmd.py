"""설정 관리 커맨드: config init/show/set/profile."""

from __future__ import annotations

import os
import re

import click

from oh_my_kanban.config import (
    _ALLOWED_CONFIG_KEYS,
    SOURCE_LABELS,
    CONFIG_FILE,
    Config,
    list_profiles,
    load_config,
    save_config,
)

# plane.so 클라우드 API URL
_CLOUD_API_URL = "https://api.plane.so"

# save_config()의 허용 키와 동일한 화이트리스트 사용 (동기화 보장)
_ALLOWED_KEYS = _ALLOWED_CONFIG_KEYS


def _mask_email(email: str) -> str:
    """이메일을 마스킹한다. 짧은 주소는 '확인됨'으로 대체한다."""
    if "@" in email and len(email) > 5:
        local, domain = email.split("@", 1)
        return f"{local[:2]}***@{domain}"
    return "확인됨"


def _save_config_safe(data: dict, profile: str = "default") -> None:
    """save_config 호출 실패를 Click 친화적 UsageError로 변환한다."""
    try:
        save_config(data, profile=profile)
    except (OSError, ValueError) as e:
        raise click.UsageError(str(e)) from e


def _extract_slug_from_url(url: str) -> str:
    """URL에서 워크스페이스 슬러그를 추출한다.

    지원 형식:
      https://app.plane.so/my-workspace/
      https://app.plane.so/my-workspace/projects/...
      https://plane.example.com/my-workspace/
    """
    # URL에서 호스트 다음 첫 번째 경로 세그먼트 추출
    match = re.search(r"https?://[^/]+/([^/?#\s]+)", url)
    if match:
        return match.group(1)
    return ""


@click.group()
def config() -> None:
    """설정 파일 관리."""
    pass


def _run_plane_healthcheck(base_url: str, api_key: str) -> None:
    """Plane API 연결 헬스체크. 실패 시 경고만 출력한다."""
    try:
        import httpx
    except ImportError:
        click.echo("  경고: httpx 미설치로 헬스체크를 건너뜁니다.", err=True)
        return
    try:
        from oh_my_kanban.hooks.http_client import build_plane_headers
    except ImportError:
        click.echo("  경고: http_client 모듈을 로드할 수 없어 헬스체크를 건너뜁니다.", err=True)
        return

    # base_url에 이미 /api 또는 /api/v1이 포함된 경우 정규화
    normalized = re.sub(r"/api(?:/v1)?$", "", base_url.rstrip("/"))
    url = f"{normalized}/api/v1/users/me/"
    headers = build_plane_headers(api_key)
    try:
        with httpx.Client(timeout=httpx.Timeout(5.0, connect=3.0), follow_redirects=False) as client:
            resp = client.get(url, headers=headers)
            if resp.status_code == 200:
                data = resp.json()
                email = data.get("email", "")
                click.echo(f"  Plane API 연결 확인: {_mask_email(email)}")
            elif resp.status_code == 401:
                click.echo("  경고: API 키가 유효하지 않습니다 (401). 설정은 저장되었습니다.", err=True)
            elif resp.status_code == 403:
                click.echo("  경고: API 접근 권한이 부족합니다 (403). 설정은 저장되었습니다.", err=True)
            else:
                click.echo(f"  경고: Plane API 응답 HTTP {resp.status_code}. 설정은 저장되었습니다.", err=True)
    except (httpx.TimeoutException, httpx.NetworkError) as e:
        click.echo(f"  경고: Plane API 연결 실패 ({type(e).__name__}). 설정은 저장되었습니다.", err=True)
    except Exception as e:
        click.echo(f"  경고: 헬스체크 중 예외 ({type(e).__name__}). 설정은 저장되었습니다.", err=True)


def _run_linear_healthcheck(api_key: str) -> None:
    """Linear API 연결 헬스체크 (viewer { id }). 실패 시 경고만 출력한다."""
    try:
        import httpx
    except ImportError:
        click.echo("  경고: httpx 미설치로 헬스체크를 건너뜁니다.", err=True)
        return
    url = "https://api.linear.app/graphql"
    try:
        with httpx.Client(timeout=httpx.Timeout(5.0, connect=3.0)) as client:
            resp = client.post(
                url,
                headers={"Authorization": api_key, "Content-Type": "application/json"},
                json={"query": "{ viewer { id email } }"},
            )
            if resp.status_code == 200:
                data = resp.json()
                if errors := data.get("errors"):
                    click.echo(f"  경고: Linear GraphQL 오류: {errors[0].get('message', '알 수 없음')}. 설정은 저장되었습니다.", err=True)
                else:
                    viewer = data.get("data", {}).get("viewer", {})
                    email = viewer.get("email", "")
                    click.echo(f"  Linear API 연결 확인: {_mask_email(email)}")
            elif resp.status_code == 401:
                click.echo("  경고: Linear API 키가 유효하지 않습니다 (401). 설정은 저장되었습니다.", err=True)
            else:
                click.echo(f"  경고: Linear API 응답 HTTP {resp.status_code}. 설정은 저장되었습니다.", err=True)
    except (httpx.TimeoutException, httpx.NetworkError) as e:
        click.echo(f"  경고: Linear API 연결 실패 ({type(e).__name__}). 설정은 저장되었습니다.", err=True)
    except Exception as e:
        click.echo(f"  경고: 헬스체크 중 예외 ({type(e).__name__}). 설정은 저장되었습니다.", err=True)


@config.command("init")
def config_init() -> None:
    """대화형으로 ~/.config/oh-my-kanban/config.toml을 생성한다.

    \b
    환경변수로도 설정 가능합니다 (AI 에이전트 자동화 용도):
      PLANE_BASE_URL        - API 서버 URL
      PLANE_API_KEY         - API 키
      PLANE_WORKSPACE_SLUG  - 워크스페이스 슬러그
    """
    click.echo("oh-my-kanban 초기 설정을 시작합니다.")
    click.echo(f"설정 파일 위치: {CONFIG_FILE}")
    click.echo()

    # 환경변수에서 미리 값 가져오기
    env_base_url = os.environ.get("PLANE_BASE_URL", "")
    env_api_key = os.environ.get("PLANE_API_KEY", "")
    env_workspace_slug = os.environ.get("PLANE_WORKSPACE_SLUG", "")

    # 환경변수로 모든 값이 설정된 경우 대화형 없이 바로 저장
    if env_api_key and env_workspace_slug:
        base_url = env_base_url or _CLOUD_API_URL
        click.echo("환경변수에서 설정을 읽었습니다:")
        click.echo(f"  PLANE_BASE_URL        = {base_url}")
        click.echo(f"  PLANE_API_KEY         = {'*' * 8}")
        click.echo(f"  PLANE_WORKSPACE_SLUG  = {env_workspace_slug}")
        _save_config_safe(
            {
                "base_url": base_url,
                "api_key": env_api_key,
                "workspace_slug": env_workspace_slug,
            },
            profile="default",
        )
        click.echo()
        click.echo(f"설정이 저장되었습니다: {CONFIG_FILE}")
        # 헬스체크 (실패해도 설정은 이미 저장됨)
        _run_plane_healthcheck(base_url, env_api_key)
        return

    # 기존 설정 로드 (있으면 기본값으로 사용)
    existing = load_config()

    # 1단계: cloud vs self-hosted 선택
    click.echo("어떤 Plane 서버를 사용하시나요?")
    click.echo("  1) plane.so 클라우드 (https://app.plane.so)")
    click.echo("  2) 직접 설치한 서버 (self-hosted)")
    click.echo()

    server_type = click.prompt(
        "서버 종류 선택",
        type=click.Choice(["1", "2"]),
        default="1",
        show_choices=False,
    )

    if server_type == "1":
        # plane.so 클라우드
        base_url = _CLOUD_API_URL
        click.echo()
        click.echo("plane.so 클라우드를 사용합니다.")
        click.echo("  API 키: https://app.plane.so/profile/api-tokens/ 에서 발급")
        click.echo()
    else:
        # self-hosted
        click.echo()
        click.echo("self-hosted 서버 URL을 입력하세요.")
        click.echo("예) https://plane.example.com")
        click.echo()
        server_url = click.prompt(
            "서버 URL",
            default=existing.base_url if existing.base_url != _CLOUD_API_URL else "",
        )
        # self-hosted는 /api/v1 경로를 포함한 API URL 구성
        server_url = server_url.rstrip("/")
        # 이미 /api 가 포함되어 있으면 그대로, 아니면 그대로 사용 (SDK가 경로 처리)
        base_url = server_url

    # 2단계: API 키
    api_key = click.prompt(
        "API 키",
        default=env_api_key or existing.api_key or "",
        prompt_suffix=" (PLANE_API_KEY): ",
    )

    if not api_key:
        raise click.UsageError("API 키는 필수입니다.")

    # 3단계: 워크스페이스 슬러그
    click.echo()
    click.echo("워크스페이스를 확인하려면 로그인 후 주소창의 URL을 복사해서 붙여넣으세요.")
    if server_type == "1":
        click.echo("예) https://app.plane.so/my-workspace/")
    else:
        click.echo("예) https://plane.example.com/my-workspace/")
    click.echo("또는 슬러그를 직접 입력하세요 (예: my-workspace)")
    click.echo()

    workspace_input = click.prompt(
        "워크스페이스 URL 또는 슬러그",
        default=env_workspace_slug or existing.workspace_slug or "",
        prompt_suffix=" (PLANE_WORKSPACE_SLUG): ",
    )

    # URL인 경우 슬러그 추출
    if workspace_input.startswith("http"):
        workspace_slug = _extract_slug_from_url(workspace_input)
        if not workspace_slug:
            raise click.UsageError(
                f"URL에서 워크스페이스 슬러그를 찾을 수 없습니다: {workspace_input}\n"
                "슬러그를 직접 입력해주세요 (예: my-workspace)"
            )
        click.echo(f"  → 슬러그 추출: {workspace_slug}")
    else:
        workspace_slug = workspace_input.strip()

    if not workspace_slug:
        raise click.UsageError("워크스페이스 슬러그는 필수입니다.")

    _save_config_safe(
        {
            "base_url": base_url,
            "api_key": api_key,
            "workspace_slug": workspace_slug,
        },
        profile="default",
    )

    click.echo()
    click.echo(f"설정이 저장되었습니다: {CONFIG_FILE}")
    # 헬스체크 (실패해도 설정은 이미 저장됨)
    _run_plane_healthcheck(base_url, api_key)
    click.echo()
    click.echo("설정 확인: omk config show")


@config.command("show")
@click.option("--profile", default="default", help="조회할 프로필")
def config_show(profile: str) -> None:
    """현재 설정을 출력한다. API 키는 마스킹 처리된다."""
    cfg = load_config(profile)

    # API 키 마스킹: pl_...xxxx 형식
    raw_key = cfg.api_key
    if raw_key and len(raw_key) > 8:
        masked_key = raw_key[:4] + "..." + raw_key[-4:]
    elif raw_key:
        masked_key = "****"
    else:
        masked_key = "(미설정)"

    click.echo(f"프로필      : {cfg.profile}")
    click.echo(f"base_url    : {cfg.base_url}")
    click.echo(f"api_key     : {masked_key}")
    click.echo(f"workspace   : {cfg.workspace_slug or '(미설정)'}")
    # project_id 소스 표시 (config.py의 SOURCE_LABELS 사용)
    pid_display = cfg.project_id or "(미설정)"
    if cfg.project_id and cfg.project_id_source:
        source_label = SOURCE_LABELS.get(cfg.project_id_source, cfg.project_id_source)
        pid_display = f"{cfg.project_id} ({source_label})"
    click.echo(f"project_id  : {pid_display}")
    click.echo(f"output      : {cfg.output}")
    click.echo(f"설정 파일   : {CONFIG_FILE if CONFIG_FILE.exists() else str(CONFIG_FILE) + ' (없음)'}")
    click.echo()
    click.echo("환경변수로 덮어쓰기 가능:")
    click.echo("  PLANE_BASE_URL, PLANE_API_KEY, PLANE_WORKSPACE_SLUG, PLANE_PROJECT_ID")

    # Linear 설정 섹션
    click.echo()
    click.echo("--- Linear ---")
    linear_key = cfg.linear_api_key
    if linear_key and len(linear_key) > 8:
        masked_linear_key = linear_key[:8] + "***"
    elif linear_key:
        masked_linear_key = "****"
    else:
        masked_linear_key = "(미설정)"
    click.echo(f"linear_api_key  : {masked_linear_key}")
    click.echo(f"linear_team_id  : {cfg.linear_team_id or '(미설정)'}")


@config.command("set")
@click.argument("key")
@click.argument("value")
@click.option("--profile", default="default", help="대상 프로필")
def config_set(key: str, value: str, profile: str) -> None:
    """설정 값을 변경한다.

    \b
    사용 가능한 키:
      base_url, api_key, workspace_slug, project_id, output
    """
    if key not in _ALLOWED_KEYS:
        raise click.UsageError(
            f"알 수 없는 키: '{key}'\n허용 키: {', '.join(sorted(_ALLOWED_KEYS))}"
        )

    if key == "output" and value not in ("json", "table", "plain"):
        raise click.UsageError("output 값은 json, table, plain 중 하나여야 합니다.")

    _save_config_safe({key: value}, profile=profile)
    masked = value if key not in ("api_key", "linear_api_key") else "****"
    click.echo(f"[{profile}] {key} = {masked} 저장 완료")

    # project_id를 전역 config에 저장할 때 로컬 바인딩 안내
    if key == "project_id":
        click.echo()
        click.echo("팁: 프로젝트별 설정은 'omk project bind'를 권장합니다.")
        click.echo("  전역 config.toml의 project_id는 다중 프로젝트 개발 시 충돌할 수 있습니다.")

    # 헬스체크 (실패해도 설정은 이미 저장됨)
    if key in ("api_key", "base_url"):
        cfg = load_config(profile)
        if cfg.base_url and cfg.api_key:
            _run_plane_healthcheck(cfg.base_url, cfg.api_key)
    elif key == "linear_api_key" and value:
        _run_linear_healthcheck(value)


@config.group("profile")
def config_profile() -> None:
    """프로필 관리."""
    pass


@config_profile.command("list")
def profile_list() -> None:
    """저장된 프로필 목록을 출력한다."""
    profiles = list_profiles()
    if not profiles:
        click.echo("저장된 프로필이 없습니다. 'omk config init'으로 설정하세요.")
        return

    click.echo("저장된 프로필:")
    for p in profiles:
        click.echo(f"  - {p}")


@config_profile.command("use")
@click.argument("name")
def profile_use(name: str) -> None:
    """기본 프로필을 변경한다.

    NAME: 사용할 프로필 이름
    """
    profiles = list_profiles()
    if name not in profiles:
        available = ", ".join(profiles) if profiles else "(없음)"
        raise click.UsageError(
            f"프로필 '{name}'이 존재하지 않습니다. 사용 가능한 프로필: {available}"
        )

    # 기본 프로필 정보를 'active_profile' 키로 저장
    _save_config_safe({"active_profile": name}, profile="_meta")
    click.echo(f"기본 프로필이 '{name}'으로 변경되었습니다.")
    click.echo("다음 실행 시 '--profile' 옵션 또는 PLANE_PROFILE 환경변수로 적용하세요.")
