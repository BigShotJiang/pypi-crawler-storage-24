"""
CLI context management for database connections and DAL access.

This module provides a unified interface for CLI commands to access the database,
using infra.Database for AlloyDB (dev/prod) and direct asyncpg for test/CI.

Usage:
    # Simple connection (most commands)
    async with get_connection(settings) as conn:
        result = await conn.fetch("SELECT 1")

    # With DAL context (for commands that use DAL functions)
    async with get_cli_context(settings) as (db, ctx):
        clips = await data.core.clips.list_(ctx, limit=10)

    # For raw SQL commands, use get_connection()
    # For commands that benefit from DAL, use get_cli_context()
"""

import os
from contextlib import asynccontextmanager
from typing import AsyncGenerator, TYPE_CHECKING

import asyncpg

from infra import Database, get_logger
from infra.settings import Settings, get_settings

if TYPE_CHECKING:
    from data.context import Context

logger = get_logger(__name__)

# Environment variable to force local PostgreSQL (for test/CI)
USE_LOCAL_DB = os.getenv("USE_LOCAL_DB", "false").lower() == "true"


@asynccontextmanager
async def get_connection(
    settings: Settings | None = None,
) -> AsyncGenerator[asyncpg.Connection, None]:
    """
    Get a database connection for CLI commands.

    Handles routing between:
    - AlloyDB (development/production) - via infra.Database
    - Local PostgreSQL (test/CI) - direct asyncpg

    Args:
        settings: Optional Settings instance. Uses cached settings if not provided.

    Yields:
        asyncpg.Connection for executing queries

    Usage:
        async with get_connection(settings) as conn:
            result = await conn.fetch("SELECT 1")
    """
    if settings is None:
        settings = get_settings()

    if USE_LOCAL_DB or settings.is_test:
        # Test/CI: use local PostgreSQL
        async with _local_connection(settings) as conn:
            yield conn
    else:
        # Development/Production: use AlloyDB via infra.Database
        db = Database.from_settings(settings)
        try:
            await db.connect()
            yield db.conn
        finally:
            await db.close()


@asynccontextmanager
async def _local_connection(
    settings: Settings,
) -> AsyncGenerator[asyncpg.Connection, None]:
    """
    Connect to local PostgreSQL (for test/CI environments).

    Uses environment variables for connection parameters:
    - DB_HOST (default: localhost)
    - DB_PORT (default: 5432)
    - DB_USER (falls back to settings.db_user)
    - DB_PASSWORD (falls back to "postgres")
    - DB_NAME (falls back to settings.db_name) - FIX: respect env var for CI
    """
    conn = await asyncpg.connect(
        host=os.getenv("DB_HOST", "localhost"),
        port=int(os.getenv("DB_PORT", "5432")),
        user=os.getenv("DB_USER", settings.db_user),
        password=settings.db_password or os.getenv("DB_PASSWORD", "postgres"),
        database=os.getenv("DB_NAME", settings.db_name),  # Respect DB_NAME env var for CI
        statement_cache_size=0,
    )
    try:
        yield conn
    finally:
        await conn.close()


@asynccontextmanager
async def get_cli_context(
    settings: Settings | None = None,
    *,
    profile: str | None = None,
) -> AsyncGenerator[tuple[Database | None, "Context"], None]:
    """
    Get a database connection AND DAL context for CLI commands.

    This is for commands that want to use DAL functions instead of raw SQL.
    The context is scoped by CLI profile (default: internal_viewer).

    Args:
        settings: Optional Settings instance. Uses cached settings if not provided.

    Yields:
        Tuple of (Database instance or None, Context for DAL operations)
        - For test/CI: Database is None, Context wraps the raw connection
        - For dev/prod: Database is the infra.Database instance

    Usage:
        async with get_cli_context(settings) as (db, ctx):
            clips = await data.core.clips.list_(ctx, limit=10)
    """
    from data.context import Context
    from cli.config import resolve_cli_profile

    if settings is None:
        settings = get_settings()
    resolved_profile = resolve_cli_profile(profile)

    if USE_LOCAL_DB or settings.is_test:
        # Test/CI: wrap local connection in context
        async with _local_connection(settings) as conn:
            ctx = await Context.for_cli_profile(conn, profile=resolved_profile)
            yield None, ctx
    else:
        # Development/Production: use infra.Database
        db = Database.from_settings(settings)
        try:
            await db.connect()
            ctx = await Context.for_cli_profile(db, profile=resolved_profile)
            yield db, ctx
        finally:
            await db.close()
