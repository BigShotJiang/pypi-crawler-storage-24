"""CLI commands for jobs (SDK-backed data-plane)."""

from __future__ import annotations

import itertools
import time
from typing import Any

import typer

from cli.console import error, info, success, warning
from cli.output import Format, format_option, output
from cli.sdk_client import get_sdk_client

app = typer.Typer(
    name="jobs",
    help="Manage processing jobs.",
    no_args_is_help=True,
)

DEFAULT_INFER_MODEL = "gemini-3-flash-preview"
DEFAULT_INFER_PROMPT = """This image is from a head-strapped GoPro on a manual worker (forehead mount, 45° downward tilt). Classify into ONE category:
- "working": actively doing work
- "not_on_person": device not being worn (on table, ground, lens covered)
- "taking_break": wearing device but not working (resting, eating, chatting)
Respond with JSON: {"category":"working"} or {"category":"not_on_person"} or {"category":"taking_break"}"""
DEFAULT_INFER_SCHEMA: dict[str, Any] = {
    "type": "object",
    "properties": {
        "category": {
            "type": "string",
            "enum": ["working", "not_on_person", "taking_break"],
        }
    },
    "required": ["category"],
    "additionalProperties": False,
}


def _job_row(job: Any) -> dict[str, Any]:
    return {
        "job_id": job.job_id,
        "job_type": job.job_type,
        "status": job.status,
        "progress_pct": getattr(job, "progress_pct", 0.0),
        "total_items": getattr(job, "total_items", None),
        "chunk_count": getattr(job, "chunk_count", None),
        "created_at": getattr(job, "created_at", None),
    }


def _parse_exists_filter(raw: str) -> dict[str, Any]:
    """Parse --exists flag value like 'predictions:prediction_type_id=activity_v1,label=working'."""
    if ":" not in raw:
        raise typer.BadParameter(f"Invalid --exists format: {raw!r}. Expected 'source:col=val,...'")
    source, rest = raw.split(":", 1)
    conditions: dict[str, str | list[str]] = {}
    for pair in rest.split(","):
        if "=" not in pair:
            raise typer.BadParameter(f"Invalid condition in --exists: {pair!r}. Expected 'col=val'")
        col, val = pair.split("=", 1)
        col = col.strip()
        val = val.strip()
        if col in conditions:
            existing = conditions[col]
            if isinstance(existing, list):
                existing.append(val)
            else:
                conditions[col] = [existing, val]
        else:
            conditions[col] = val
    return {"source": source.strip(), "conditions": conditions}


def _query(
    *,
    factory: str | None,
    collection: str | None,
    worker_ids: list[str] | None,
    limit: int | None,
    exists: list[str] | None = None,
    where: list[str] | None = None,
) -> dict[str, Any]:
    q: dict[str, Any] = {}
    if factory:
        q["factory_id"] = factory
    if collection:
        q["collection_id"] = collection
    if worker_ids:
        q["worker_ids"] = worker_ids
    if limit is not None:
        q["limit"] = limit
    if exists:
        q["exists"] = [_parse_exists_filter(e) for e in exists]
    if where:
        q["where"] = where
    return q


# Backward compat
_selector = _query


def _launch_job(
    client: Any,
    job_id: str,
    *,
    max_tasks: int,
    spot: bool,
    platform: str,
    region: str | None,
    cpu: str,
    memory: str,
) -> Any:
    return client.jobs.submit(
        job_id,
        max_tasks=max_tasks,
        spot=spot,
        platform=platform,
        region=region,
        cpu=cpu,
        memory=memory,
    )


def _watch_job(client: Any, job_id: str, *, interval: float) -> None:
    last_line: str | None = None
    while True:
        progress = client.jobs.progress(job_id)
        line = (
            f"{progress.status} "
            f"chunks={progress.chunks_succeeded + progress.chunks_failed}/{progress.total_chunks} "
            f"items={progress.items_succeeded} ok/{progress.items_failed} failed "
            f"items_per_sec={progress.items_per_second} "
            f"chunks_per_sec={progress.chunks_per_second} "
            f"eta_s={progress.eta_seconds}"
        )
        if line != last_line:
            info(f"{job_id}: {line}")
            last_line = line
        if progress.status in {"succeeded", "failed", "cancelled"}:
            if progress.status != "succeeded":
                failures = client.jobs.failures(job_id, page_size=5)
                if failures.data:
                    for failure in failures.data:
                        warning(
                            f"{failure.entity_id} | {failure.error_code or 'error'} | {failure.error_message or ''}"
                        )
            return
        time.sleep(interval)


@app.command("list")
def jobs_list(
    status: str | None = typer.Option(None, "--status", "-s", help="Filter by status"),
    type: str | None = typer.Option(None, "--type", "-t", help="Filter by job type"),
    limit: int = typer.Option(20, "--limit", "-n"),
    format: Format | None = format_option(),
) -> None:
    """List processing jobs."""
    client = get_sdk_client()
    results = list(
        itertools.islice(
            client.jobs.iter(status=status, type=type),
            limit,
        )
    )
    output(
        [_job_row(job) for job in results],
        format=format,
        columns=["job_id", "job_type", "status", "progress_pct", "total_items", "chunk_count"],
    )


@app.command("get")
def jobs_get(
    job_id: str = typer.Argument(..., help="Manifest ID"),
    format: Format | None = format_option(),
) -> None:
    """Get details for a single job."""
    client = get_sdk_client()
    job = client.jobs.get(job_id)
    output(job, format=format)


@app.command("submit")
def jobs_submit(
    ctx: typer.Context,
    job_id: str = typer.Argument(..., help="Manifest ID"),
    max_tasks: int = typer.Option(750, "--max-tasks"),
    spot: bool = typer.Option(True, "--spot/--no-spot"),
    platform: str = typer.Option("auto", "--platform"),
    region: str | None = typer.Option(None, "--region"),
    cpu: str = typer.Option("8", "--cpu"),
    memory: str = typer.Option("8Gi", "--memory"),
    watch: bool = typer.Option(False, "--watch"),
    interval: float = typer.Option(5.0, "--interval"),
) -> None:
    """Submit an existing manifest to execution."""
    del ctx  # API enforces permissions via token scope
    client = get_sdk_client()
    result = _launch_job(
        client,
        job_id,
        max_tasks=max_tasks,
        spot=spot,
        platform=platform,
        region=region,
        cpu=cpu,
        memory=memory,
    )
    success(
        f"Submitted {job_id} on {result.platform} as {result.batch_job_name} with {result.task_count} tasks"
    )
    if watch:
        _watch_job(client, job_id, interval=interval)


@app.command("watch")
def jobs_watch(
    job_id: str = typer.Argument(..., help="Manifest ID"),
    interval: float = typer.Option(5.0, "--interval"),
) -> None:
    """Watch a job until completion."""
    client = get_sdk_client()
    _watch_job(client, job_id, interval=interval)


@app.command("backlog")
def jobs_backlog(
    job_type: str = typer.Argument(..., help="extract-iframes | infer-frames"),
    factory: str | None = typer.Option(None, "--factory"),
    collection: str | None = typer.Option(None, "--collection", "-c"),
    prediction_type: str = typer.Option(
        "activity_v1",
        "--prediction-type",
        help="Prediction type to measure dedupe/coverage against for infer-frames.",
    ),
    format: Format | None = format_option(),
) -> None:
    """Inspect extractor or inference backlog."""
    client = get_sdk_client()
    if job_type == "extract-iframes":
        backlog = client.jobs.extract_iframes_backlog(factory_id=factory, collection_id=collection)
    elif job_type == "infer-frames":
        backlog = client.jobs.infer_frames_rt_backlog(
            factory_id=factory,
            collection_id=collection,
            prediction_type_id=prediction_type,
        )
    else:
        error(f"Unknown backlog type: {job_type}")
        raise typer.Exit(1)
    output(backlog, format=format)


@app.command("extract-iframes")
def jobs_extract_iframes(
    ctx: typer.Context,
    factory: str | None = typer.Option(None, "--factory"),
    collection: str | None = typer.Option(None, "--collection", "-c"),
    worker_ids: list[str] | None = typer.Option(None, "--worker-id"),
    limit: int | None = typer.Option(None, "--limit"),
    exists: list[str] | None = typer.Option(
        None, "--exists", help="EXISTS filter (source:col=val,...)"
    ),
    where: list[str] | None = typer.Option(None, "--where", help="Raw SQL WHERE fragment"),
    chunk_size: int | None = typer.Option(None, "--chunk-size"),
    frame_extraction_timeout_sec: int = typer.Option(300, "--timeout-sec"),
    num_frames: int = typer.Option(10, "--num-frames"),
    frame_height: int = typer.Option(256, "--frame-height"),
    frame_jpeg_quality: int = typer.Option(4, "--frame-jpeg-quality"),
    max_downloads_per_worker: int = typer.Option(3, "--max-downloads-per-worker"),
    max_clips_in_flight: int = typer.Option(4, "--max-clips-in-flight"),
    max_seek_ffmpeg_processes_per_clip: int = typer.Option(
        8, "--max-seek-ffmpeg-processes-per-clip"
    ),
    max_uploads_per_clip: int = typer.Option(10, "--max-uploads-per-clip"),
    ffmpeg_threads_per_process: int = typer.Option(1, "--ffmpeg-threads-per-process"),
    launch: bool = typer.Option(True, "--launch/--no-launch"),
    max_tasks: int = typer.Option(20, "--max-tasks"),
    spot: bool = typer.Option(False, "--spot/--no-spot"),
    platform: str = typer.Option("batch", "--platform"),
    region: str | None = typer.Option(None, "--region"),
    cpu: str = typer.Option("8", "--cpu"),
    memory: str = typer.Option("8Gi", "--memory"),
    watch: bool = typer.Option(True, "--watch"),
    interval: float = typer.Option(5.0, "--interval"),
) -> None:
    """Queue canonical frame extraction, optionally launch immediately."""
    del ctx  # API enforces permissions via token scope
    client = get_sdk_client()
    backlog = client.jobs.extract_iframes_backlog(factory_id=factory, collection_id=collection)
    info(
        f"Extractor backlog clips={backlog.total_clips} active_manifest={backlog.active_manifest_id}"
    )
    # Build exists filters from CLI format
    exists_filters = [_parse_exists_filter(e) for e in exists] if exists else None
    job = client.jobs.submit_extract_iframes(
        factory_id=factory,
        collection_id=collection,
        worker_ids=worker_ids,
        limit=limit,
        exists_filters=exists_filters,
        where_clauses=where,
        chunk_size=chunk_size,
        frame_extraction_timeout_sec=frame_extraction_timeout_sec,
        num_frames=num_frames,
        frame_height=frame_height,
        frame_jpeg_quality=frame_jpeg_quality,
        max_downloads_per_worker=max_downloads_per_worker,
        max_clips_in_flight=max_clips_in_flight,
        max_seek_ffmpeg_processes_per_clip=max_seek_ffmpeg_processes_per_clip,
        max_uploads_per_clip=max_uploads_per_clip,
        ffmpeg_threads_per_process=ffmpeg_threads_per_process,
    )
    success(f"Queued extractor manifest {job.job_id}")
    if not launch:
        return
    result = _launch_job(
        client,
        job.job_id,
        max_tasks=max_tasks,
        spot=spot,
        platform=platform,
        region=region,
        cpu=cpu,
        memory=memory,
    )
    success(
        f"Submitted extractor {job.job_id} on {result.platform} as {result.batch_job_name} with {result.task_count} tasks"
    )
    if watch:
        _watch_job(client, job.job_id, interval=interval)


@app.command("infer-frames")
def jobs_infer_frames(
    ctx: typer.Context,
    factory: str | None = typer.Option(None, "--factory"),
    collection: str | None = typer.Option(None, "--collection", "-c"),
    worker_ids: list[str] | None = typer.Option(None, "--worker-id"),
    limit: int | None = typer.Option(None, "--limit"),
    exists: list[str] | None = typer.Option(
        None, "--exists", help="EXISTS filter (source:col=val,...)"
    ),
    where: list[str] | None = typer.Option(None, "--where", help="Raw SQL WHERE fragment"),
    prediction_type: str = typer.Option(
        ...,
        "--prediction-type",
        help=(
            "Prediction type name to write. Reuse only when model, prompt, system instruction, "
            "and response schema are exactly the same."
        ),
    ),
    model: str = typer.Option(DEFAULT_INFER_MODEL, "--model"),
    prompt_text: str = typer.Option(DEFAULT_INFER_PROMPT, "--prompt"),
    requests_per_minute: int = typer.Option(600, "--requests-per-minute"),
    batch_size: int = typer.Option(8, "--batch-size"),
    permit_lease_size: int = typer.Option(16, "--permit-lease-size"),
    max_parallel_requests_per_worker: int = typer.Option(8, "--max-parallel-requests-per-worker"),
    max_attempts_per_request: int = typer.Option(4, "--max-attempts-per-request"),
    temperature: float = typer.Option(0.0, "--temperature"),
    chunk_size: int | None = typer.Option(None, "--chunk-size"),
    preferred_platform: str = typer.Option("cloudrun", "--preferred-platform"),
    preferred_region: str | None = typer.Option(None, "--preferred-region"),
    launch: bool = typer.Option(True, "--launch/--no-launch"),
    max_tasks: int = typer.Option(20, "--max-tasks"),
    spot: bool = typer.Option(False, "--spot/--no-spot"),
    platform: str = typer.Option("cloudrun", "--platform"),
    region: str | None = typer.Option(None, "--region"),
    cpu: str = typer.Option("8", "--cpu"),
    memory: str = typer.Option("8Gi", "--memory"),
    watch: bool = typer.Option(True, "--watch"),
    interval: float = typer.Option(5.0, "--interval"),
) -> None:
    """Queue realtime frame inference on the canonical near-90s frame."""
    del ctx  # API enforces permissions via token scope
    client = get_sdk_client()
    selector = _query(
        factory=factory,
        collection=collection,
        worker_ids=worker_ids,
        limit=limit,
        exists=exists,
        where=where,
    )
    backlog = client.jobs.infer_frames_rt_backlog(
        factory_id=factory,
        collection_id=collection,
        prediction_type_id=prediction_type,
        asset_type_id="frame-jpg",
    )
    info(
        f"Inference backlog type={prediction_type} "
        f"pending_clips={backlog.pending_clips} pending_frames={backlog.pending_frames} "
        f"coverage_pct={backlog.coverage_pct} active_manifest={backlog.active_manifest_id}"
    )
    validation = client.jobs.validate_infer_frames_rt(
        selector=selector,
        prediction_type_id=prediction_type,
        model=model,
        prompt_text=prompt_text,
        response_json_schema=DEFAULT_INFER_SCHEMA,
        temperature=temperature,
        batch_size=batch_size,
        requests_per_minute=requests_per_minute,
        permit_lease_size=permit_lease_size,
        max_parallel_requests_per_worker=max_parallel_requests_per_worker,
        max_attempts_per_request=max_attempts_per_request,
        asset_type_id="frame-jpg",
        preferred_platform=preferred_platform,
        preferred_region=preferred_region,
        chunk_size=chunk_size,
    )
    info(
        f"Inference validation type={validation.prediction_type_id} "
        f"clips={validation.selected_clips} frames={validation.selected_frames} "
        f"requests={validation.estimated_requests} chunks={validation.estimated_chunk_count}"
    )
    for msg in validation.warnings:
        warning(msg)
    job = client.jobs.submit_infer_frames_rt(
        selector=selector,
        prediction_type_id=prediction_type,
        model=model,
        prompt_text=prompt_text,
        response_json_schema=DEFAULT_INFER_SCHEMA,
        temperature=temperature,
        batch_size=batch_size,
        requests_per_minute=requests_per_minute,
        permit_lease_size=permit_lease_size,
        max_parallel_requests_per_worker=max_parallel_requests_per_worker,
        max_attempts_per_request=max_attempts_per_request,
        asset_type_id="frame-jpg",
        preferred_platform=preferred_platform,
        preferred_region=preferred_region,
        chunk_size=chunk_size,
    )
    success(f"Queued inference manifest {job.job_id}")
    if not launch:
        return
    result = _launch_job(
        client,
        job.job_id,
        max_tasks=max_tasks,
        spot=spot,
        platform=platform,
        region=region,
        cpu=cpu,
        memory=memory,
    )
    success(
        f"Submitted inference {job.job_id} on {result.platform} as {result.batch_job_name} with {result.task_count} tasks"
    )
    if watch:
        _watch_job(client, job.job_id, interval=interval)


@app.command("retry")
def jobs_retry(
    ctx: typer.Context,
    job_id: str = typer.Argument(..., help="Manifest ID"),
    dry_run: bool = typer.Option(False, "--dry-run"),
) -> None:
    """Retry a failed job."""
    if dry_run:
        info(f"Would retry job {job_id}")
        return

    del ctx  # API enforces permissions via token scope
    client = get_sdk_client()
    client.jobs.retry(job_id)
    success(f"Retried job {job_id}")


@app.command("cancel")
def jobs_cancel(
    ctx: typer.Context,
    job_id: str = typer.Argument(..., help="Manifest ID"),
    dry_run: bool = typer.Option(False, "--dry-run"),
) -> None:
    """Cancel a running job."""
    if dry_run:
        info(f"Would cancel job {job_id}")
        return

    del ctx  # API enforces permissions via token scope
    client = get_sdk_client()
    client.jobs.cancel(job_id)
    success(f"Cancelled job {job_id}")
