# Build AI CLI

Applies to `apps/buildai-cli/`.

Read first:

- [../../CLAUDE.md](../../CLAUDE.md)
- [../../core/CLAUDE.md](../../core/CLAUDE.md)

## Mental Model

The CLI has two planes:

- **data plane**: API-backed commands (all top-level commands). Works with a standalone `buildai-cli` install. Auth is credential-only — no profiles, no DB connection needed.
- **ops plane**: DB-backed commands under the `admin` namespace. Requires repo-local `ops` extras and gcloud IAM for DB access. This plane still carries a DB-backed CLI profile concept used for permissioning and write guards.

## Hard Rules

1. Data-plane commands go through the API. No DB imports.
2. Ops-plane commands live under `buildai admin ...` and require DB access.
3. Mutations need `--write` on the ops plane.
4. The `query` command (data plane) stays read-safe by default.
5. Do not pull `infra` imports into CLI module scope where they affect startup.
6. Data-plane auth is resolved from credentials only. Ops-plane auth still threads a CLI profile through DB-backed commands.

## Verify Instead Of Infer

- Verify whether a command belongs in the data plane (top-level) or the ops plane (`admin` namespace).
- Verify whether the command should work in standalone mode or only in the workspace install.
- Verify registration in `cli/main.py`.
- Verify whether auth behavior belongs in `auth_lite` (data plane credential flow) or ops-plane auth/profile handling.

## Install

```bash
# Standalone Python tool install
uv tool install buildai-cli

# Workspace install (for ops-plane / admin commands)
uv pip install -e "apps/buildai-cli[ops]" -e core -e services -e apps/buildai-sdk
```

PyPI via `uv` is the only supported standalone distribution path for `buildai-cli`. Do not add or
document Homebrew-based install or upgrade flows for the CLI.

## Auth

```bash
# Interactive device flow (opens browser)
buildai login

# Token from stdin (CI)
echo "$TOKEN" | buildai login --token

# Environment variables (no login needed)
export BUILDAI_TOKEN=...    # or BUILDAI_API_KEY=...

# Check resolved identity
buildai whoami

# Remove stored credential
buildai logout
```

Credential resolution order: `BUILDAI_TOKEN` > `BUILDAI_API_KEY` > `~/.buildai/credentials.json`

## Canonical Commands

```bash
# Data plane (API-backed, standalone)
buildai query "SELECT count(*) FROM core.clips"
buildai clips list --factory <uuid>
buildai clips get <clip_id>
buildai clips search "some query"
buildai jobs list
buildai jobs get <job_id>
buildai predictions types
buildai predictions list --factory <uuid>
buildai predictions summary --factory <uuid>
buildai assets list --clip-id <uuid>
buildai assets sign <asset_id>

# Ops plane (DB-backed, workspace install required)
buildai admin query "SELECT count(*) FROM core.clips"
buildai admin schema tables
buildai admin stats overview
```

## Output Formats

Auto-detects: **table** in terminal, **JSON** when piped. Override with `-o`.

| Format | Flag | Behavior |
|--------|------|----------|
| `table` | `-o table` | Rich table to terminal. Default when interactive. |
| `json` | `-o json` | Pretty-printed JSON array. Default when piped. |
| `jsonl` | `-o jsonl` | One JSON object per line. Streams without buffering. Best for large exports. |
| `csv` | `-o csv` | CSV with header row. Good for spreadsheets and pandas. |

Machine-readable formats (json, jsonl, csv) write raw text to stdout — no ANSI codes, no Rich markup. Status messages go to stderr so they never pollute piped output.

```bash
# Interactive — table
buildai query "SELECT id, factory_id FROM core.clips LIMIT 10"

# Pipe to jq — auto-switches to JSON
buildai query "SELECT id, factory_id FROM core.clips LIMIT 10" | jq '.[].id'

# Export to JSON file
buildai query "SELECT * FROM core.clips" -o json > clips.json

# Stream large export as JSONL (auto-paginates, no memory buffering)
buildai query "SELECT * FROM core.clips" -o jsonl > all_clips.jsonl

# CSV export for pandas / spreadsheets
buildai query "SELECT * FROM core.clips" -o csv > clips.csv

# Large export with row cap
buildai query "SELECT * FROM observations.predictions" -o jsonl --max-rows 500000 > predictions.jsonl

# Predictions to JSON
buildai predictions list --factory <uuid> -o json | jq '.[] | {clip: .clip_id, label: .label}'

# Signed URL — bare URL when piped
buildai assets sign <asset_id> | pbcopy
```

### Query auto-pagination

The `query` command auto-paginates for streaming formats (jsonl, csv) and piped JSON. It fetches `--limit` rows per API request (default 500) and continues until all results are returned or `--max-rows` is reached (default 100,000). Set `--max-rows 0` for unlimited.

```bash
# Fetch up to 100k rows in pages of 500
buildai query "SELECT * FROM core.clips" -o jsonl > clips.jsonl

# Fetch everything (no cap)
buildai query "SELECT * FROM core.clips" -o jsonl --max-rows 0 > all_clips.jsonl

# Larger pages for faster throughput
buildai query "SELECT * FROM core.clips" --limit 2000 -o csv > clips.csv
```

## Common Traps

- `buildai` failing after a pull usually means the workspace install needs refreshing: `uv pip install -e "apps/buildai-cli[ops]" -e core -e services -e apps/buildai-sdk`
- Data-plane commands need API auth (credential), not DB creds.
- Ops-plane commands (`admin ...`) need DB access plus the `ops` extras.
- Top-level data-plane commands do not use profiles.
- Ops-plane `buildai admin ...` still accepts `--profile` and uses it for DB-backed permissioning and write guards.
- `buildai query` hits the API. `buildai admin query` hits the DB directly.
- `assets sign` outputs the bare URL when piped (non-TTY), table when interactive.

## Done Means

- the command is in the correct plane (top-level = data, `admin` = ops)
- registration is correct in `cli/main.py`
- safety flags are explicit for mutations
- command output behaves correctly for TTY and non-TTY use

## Related Docs

- [../../README.md](../../README.md)
- [../../core/CLAUDE.md](../../core/CLAUDE.md)
- [../../docs/gotchas.md](../../docs/gotchas.md)
