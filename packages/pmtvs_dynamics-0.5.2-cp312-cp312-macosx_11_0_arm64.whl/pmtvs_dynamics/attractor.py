"""
Attractor Analysis

Functions for characterizing strange attractors and
computing attractor dimensions.
"""

import numpy as np
from typing import Optional, Tuple

from pmtvs_dynamics._core import (
    correlation_dimension_rust,
    kaplan_yorke_dimension_rust,
    attractor_reconstruction_rust,
)


def correlation_dimension(
    trajectory: np.ndarray,
    r_values: Optional[np.ndarray] = None,
    n_reference: int = 500
) -> float:
    """
    Compute correlation dimension using Grassberger-Procaccia algorithm.

    Parameters
    ----------
    trajectory : np.ndarray
        State-space trajectory of shape (n_points, n_dims)
    r_values : np.ndarray, optional
        Radius values to use (default: log-spaced)
    n_reference : int
        Number of reference points to use

    Returns
    -------
    float
        Correlation dimension estimate
    """
    trajectory = np.asarray(trajectory, dtype=np.float64)
    if trajectory.ndim == 1:
        trajectory = trajectory.reshape(-1, 1)
    trajectory = np.ascontiguousarray(trajectory)
    return float(correlation_dimension_rust(trajectory, n_reference))


def attractor_reconstruction(
    signal: np.ndarray,
    dim: int = 3,
    tau: int = 1
) -> np.ndarray:
    """
    Reconstruct attractor using time-delay embedding.

    Parameters
    ----------
    signal : np.ndarray
        Input time series
    dim : int
        Embedding dimension
    tau : int
        Time delay

    Returns
    -------
    np.ndarray
        Reconstructed attractor trajectory
    """
    signal = np.ascontiguousarray(np.asarray(signal, dtype=np.float64).flatten())
    return np.asarray(attractor_reconstruction_rust(signal, dim, tau))


def kaplan_yorke_dimension(lyapunov_spectrum: np.ndarray) -> float:
    """
    Compute Kaplan-Yorke (Lyapunov) dimension.

    Parameters
    ----------
    lyapunov_spectrum : np.ndarray
        Lyapunov exponents (sorted descending)

    Returns
    -------
    float
        Kaplan-Yorke dimension
    """
    spectrum = np.ascontiguousarray(np.asarray(lyapunov_spectrum, dtype=np.float64).flatten())
    return float(kaplan_yorke_dimension_rust(spectrum))
