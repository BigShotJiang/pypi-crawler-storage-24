"""
Recurrence Quantification Analysis (RQA)

Functions for computing recurrence plots and RQA measures
that characterize dynamical system structure.
"""

import numpy as np
from typing import Optional

from pmtvs_dynamics._core import (
    recurrence_matrix_rust,
    recurrence_rate_rust,
    determinism_rust,
    laminarity_rust,
    trapping_time_rust,
    entropy_recurrence_rust,
    max_diagonal_line_rust,
)


def recurrence_matrix(
    trajectory: np.ndarray,
    threshold: Optional[float] = None,
    threshold_percentile: float = 10.0
) -> np.ndarray:
    """
    Compute recurrence matrix.

    Parameters
    ----------
    trajectory : np.ndarray
        State-space trajectory of shape (n_points, n_dims) or 1D signal
    threshold : float, optional
        Distance threshold (if None, uses percentile of distances)
    threshold_percentile : float
        Percentile of distances to use as threshold (default: 10%)

    Returns
    -------
    np.ndarray
        Binary recurrence matrix
    """
    trajectory = np.asarray(trajectory, dtype=np.float64)
    if trajectory.ndim == 1:
        trajectory = trajectory.reshape(-1, 1)
    trajectory = np.ascontiguousarray(trajectory)

    thresh = threshold if threshold is not None else -1.0
    return np.asarray(recurrence_matrix_rust(trajectory, thresh, threshold_percentile)).astype(int)


def recurrence_rate(R: np.ndarray) -> float:
    """
    Compute recurrence rate (RR).

    Parameters
    ----------
    R : np.ndarray
        Recurrence matrix

    Returns
    -------
    float
        Recurrence rate in [0, 1]
    """
    R = np.ascontiguousarray(np.asarray(R, dtype=np.float64))
    if R.ndim < 2:
        return np.nan
    return float(recurrence_rate_rust(R))


def determinism(R: np.ndarray, min_line_length: int = 2) -> float:
    """
    Compute determinism (DET).

    Parameters
    ----------
    R : np.ndarray
        Recurrence matrix
    min_line_length : int
        Minimum diagonal line length to count

    Returns
    -------
    float
        Determinism in [0, 1]
    """
    R = np.ascontiguousarray(np.asarray(R, dtype=np.float64))
    if R.ndim < 2:
        return np.nan
    return float(determinism_rust(R, min_line_length))


def laminarity(R: np.ndarray, min_line_length: int = 2) -> float:
    """
    Compute laminarity (LAM).

    Parameters
    ----------
    R : np.ndarray
        Recurrence matrix
    min_line_length : int
        Minimum vertical line length to count

    Returns
    -------
    float
        Laminarity in [0, 1]
    """
    R = np.ascontiguousarray(np.asarray(R, dtype=np.float64))
    if R.ndim < 2:
        return np.nan
    return float(laminarity_rust(R, min_line_length))


def trapping_time(R: np.ndarray, min_line_length: int = 2) -> float:
    """
    Compute trapping time (TT).

    Parameters
    ----------
    R : np.ndarray
        Recurrence matrix
    min_line_length : int
        Minimum vertical line length to count

    Returns
    -------
    float
        Average trapping time
    """
    R = np.ascontiguousarray(np.asarray(R, dtype=np.float64))
    if R.ndim < 2:
        return np.nan
    return float(trapping_time_rust(R, min_line_length))


def entropy_recurrence(R: np.ndarray, min_line_length: int = 2) -> float:
    """
    Compute entropy of diagonal line length distribution (ENTR).

    Parameters
    ----------
    R : np.ndarray
        Recurrence matrix
    min_line_length : int
        Minimum diagonal line length to count

    Returns
    -------
    float
        Shannon entropy of line length distribution
    """
    R = np.ascontiguousarray(np.asarray(R, dtype=np.float64))
    if R.ndim < 2:
        return np.nan
    return float(entropy_recurrence_rust(R, min_line_length))


def max_diagonal_line(R: np.ndarray, min_line: int = 2) -> int:
    """
    Compute maximum diagonal line length (L_max).

    Parameters
    ----------
    R : np.ndarray
        Recurrence matrix
    min_line : int
        Minimum diagonal line length

    Returns
    -------
    int
        Maximum diagonal line length
    """
    R = np.ascontiguousarray(np.asarray(R, dtype=np.float64))
    if R.ndim < 2:
        return 0
    return int(max_diagonal_line_rust(R, min_line))


def divergence_rqa(R: np.ndarray, min_line: int = 2) -> float:
    """
    Compute divergence (1 / L_max).

    Parameters
    ----------
    R : np.ndarray
        Recurrence matrix
    min_line : int
        Minimum diagonal line length

    Returns
    -------
    float
        Divergence measure
    """
    l_max = max_diagonal_line(R, min_line)
    if l_max == 0:
        return np.nan
    return float(1.0 / l_max)


def determinism_from_signal(
    signal: np.ndarray,
    dimension: int = 3,
    delay: int = 1,
    threshold_percentile: float = 10.0,
    min_line_length: int = 2,
) -> float:
    """
    Compute determinism directly from a signal.

    Parameters
    ----------
    signal : np.ndarray
        Input time series
    dimension : int
        Embedding dimension
    delay : int
        Time delay
    threshold_percentile : float
        Percentile for recurrence threshold
    min_line_length : int
        Minimum diagonal line length

    Returns
    -------
    float
        Determinism in [0, 1]
    """
    signal = np.asarray(signal).flatten()
    signal = signal[~np.isnan(signal)]

    if len(signal) < dimension * delay + min_line_length:
        return np.nan

    n = len(signal)
    n_points = n - (dimension - 1) * delay
    if n_points < 10:
        return np.nan

    embedded = np.zeros((n_points, dimension))
    for d in range(dimension):
        embedded[:, d] = signal[d * delay:d * delay + n_points]

    if n_points > 200:
        idx = np.linspace(0, n_points - 1, 200, dtype=int)
        embedded = embedded[idx]

    R = recurrence_matrix(embedded, threshold_percentile=threshold_percentile)
    return determinism(R, min_line_length)


def rqa_metrics(
    signal: np.ndarray,
    dimension: int = 3,
    delay: int = 1,
    threshold_percentile: float = 10.0,
    min_line_length: int = 2,
) -> dict:
    """
    Compute all RQA metrics from a signal.

    Parameters
    ----------
    signal : np.ndarray
        Input time series
    dimension : int
        Embedding dimension
    delay : int
        Time delay
    threshold_percentile : float
        Percentile for recurrence threshold
    min_line_length : int
        Minimum line length

    Returns
    -------
    dict
        recurrence_rate, determinism, laminarity, trapping_time,
        entropy, max_diagonal_line, divergence
    """
    signal = np.asarray(signal).flatten()
    signal = signal[~np.isnan(signal)]
    n = len(signal)

    nan_result = {
        'recurrence_rate': np.nan, 'determinism': np.nan,
        'laminarity': np.nan, 'trapping_time': np.nan,
        'entropy': np.nan, 'max_diagonal_line': 0, 'divergence': np.nan,
    }

    n_points = n - (dimension - 1) * delay
    if n_points < 10:
        return nan_result

    embedded = np.zeros((n_points, dimension))
    for d in range(dimension):
        embedded[:, d] = signal[d * delay:d * delay + n_points]

    if n_points > 200:
        idx = np.linspace(0, n_points - 1, 200, dtype=int)
        embedded = embedded[idx]

    R = recurrence_matrix(embedded, threshold_percentile=threshold_percentile)

    return {
        'recurrence_rate': recurrence_rate(R),
        'determinism': determinism(R, min_line_length),
        'laminarity': laminarity(R, min_line_length),
        'trapping_time': trapping_time(R, min_line_length),
        'entropy': entropy_recurrence(R, min_line_length),
        'max_diagonal_line': max_diagonal_line(R, min_line_length),
        'divergence': divergence_rqa(R, min_line_length),
    }
