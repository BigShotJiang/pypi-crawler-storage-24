"""Tests for recipe store."""

import os
from pathlib import Path

from datarep.db import get_connection
from datarep.recipes import RecipeStore
from datarep.registry import SourceRegistry


def _make_store(tmp_path: Path):
    db_path = tmp_path / "test.db"
    os.environ["DATAREP_HOME"] = str(tmp_path)
    conn = get_connection(db_path)
    registry = SourceRegistry(conn)
    registry.add("test_src", "local_db", {"path": "/tmp/test.db"})
    return RecipeStore(conn), conn


def test_save_and_get(tmp_path):
    store, _ = _make_store(tmp_path)
    result = store.save("recipe_1", "test_src", "print('hello')", "Test recipe")
    assert result["id"] == "recipe_1"

    recipe = store.get("recipe_1")
    assert recipe is not None
    assert recipe["code"] == "print('hello')"
    assert recipe["description"] == "Test recipe"
    assert recipe["source_name"] == "test_src"


def test_list(tmp_path):
    store, _ = _make_store(tmp_path)
    store.save("r1", "test_src", "code1", "Recipe 1")
    store.save("r2", "test_src", "code2", "Recipe 2")
    recipes = store.list()
    assert len(recipes) == 2


def test_list_by_source(tmp_path):
    store, conn = _make_store(tmp_path)
    registry = SourceRegistry(conn)
    registry.add("other_src", "rest_api", {"base_url": "https://example.com"})
    store.save("r1", "test_src", "code1")
    store.save("r2", "other_src", "code2")
    recipes = store.list(source_name="test_src")
    assert len(recipes) == 1
    assert recipes[0]["id"] == "r1"


def test_record_use(tmp_path):
    store, _ = _make_store(tmp_path)
    store.save("r1", "test_src", "code")
    assert store.get("r1")["times_used"] == 0
    store.record_use("r1")
    assert store.get("r1")["times_used"] == 1
    store.record_use("r1")
    assert store.get("r1")["times_used"] == 2


def test_delete(tmp_path):
    store, _ = _make_store(tmp_path)
    store.save("r1", "test_src", "code")
    assert store.delete("r1") is True
    assert store.get("r1") is None
    assert store.delete("r1") is False


def test_find_for_source(tmp_path):
    store, _ = _make_store(tmp_path)
    store.save("r1", "test_src", "code1", "First")
    store.save("r2", "test_src", "code2", "Second")
    store.record_use("r1")
    result = store.find_for_source("test_src")
    assert result is not None
    assert result["id"] == "r1"


def test_file_saved(tmp_path):
    store, _ = _make_store(tmp_path)
    store.save("my_recipe", "test_src", "print('hi')", "A recipe")
    recipe_file = tmp_path / "recipes" / "my_recipe.py"
    assert recipe_file.exists()
    content = recipe_file.read_text()
    assert "print('hi')" in content
    assert "my_recipe" in content
