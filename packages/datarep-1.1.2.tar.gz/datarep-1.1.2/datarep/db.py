"""SQLite database setup and migrations for datarep."""

from __future__ import annotations

import sqlite3
from pathlib import Path

from datarep.config import get_db_path, ensure_home

_SCHEMA_VERSION = 1

_MIGRATIONS: list[str] = [
    # Version 1: initial schema
    """
    CREATE TABLE IF NOT EXISTS sources (
        name TEXT PRIMARY KEY,
        source_type TEXT NOT NULL,
        config TEXT NOT NULL DEFAULT '{}',
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS credentials (
        source_name TEXT PRIMARY KEY,
        cred_type TEXT NOT NULL,
        encrypted_data BLOB NOT NULL,
        expires_at TEXT,
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        updated_at TEXT NOT NULL DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS recipes (
        id TEXT PRIMARY KEY,
        source_name TEXT NOT NULL,
        description TEXT,
        code TEXT NOT NULL,
        last_used_at TEXT,
        times_used INTEGER DEFAULT 0,
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        FOREIGN KEY (source_name) REFERENCES sources(name)
    );

    CREATE TABLE IF NOT EXISTS sync_state (
        source_name TEXT NOT NULL,
        recipe_id TEXT NOT NULL,
        last_cursor TEXT,
        last_status TEXT,
        last_run_at TEXT,
        items_retrieved INTEGER,
        PRIMARY KEY (source_name, recipe_id)
    );

    CREATE TABLE IF NOT EXISTS apps (
        app_id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        api_key_hash TEXT NOT NULL,
        allowed_sources TEXT,
        created_at TEXT NOT NULL DEFAULT (datetime('now')),
        last_used_at TEXT,
        revoked_at TEXT
    );

    CREATE TABLE IF NOT EXISTS audit_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        app_id TEXT NOT NULL,
        action TEXT NOT NULL,
        source_name TEXT,
        status TEXT NOT NULL,
        timestamp TEXT NOT NULL DEFAULT (datetime('now')),
        details TEXT
    );

    CREATE TABLE IF NOT EXISTS schema_version (
        version INTEGER PRIMARY KEY
    );
    INSERT OR REPLACE INTO schema_version (version) VALUES (1);
    """,
]


def get_connection(db_path: Path | None = None) -> sqlite3.Connection:
    """Open a connection to the datarep database, running migrations as needed."""
    if db_path is None:
        ensure_home()
        db_path = get_db_path()

    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")

    current_version = _get_schema_version(conn)
    for i in range(current_version, len(_MIGRATIONS)):
        conn.executescript(_MIGRATIONS[i])

    return conn


def _get_schema_version(conn: sqlite3.Connection) -> int:
    try:
        row = conn.execute("SELECT version FROM schema_version").fetchone()
        return row["version"] if row else 0
    except sqlite3.OperationalError:
        return 0
