"""Claude-powered retrieval agent with tool use — the core of datarep."""

from __future__ import annotations

import json
import logging
import os
import shutil
import sqlite3
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable, Awaitable

import anthropic

from datarep.config import get_anthropic_api_key, get_anthropic_base_url, get_anthropic_model, get_logs_dir
from datarep.credentials import CredentialStore
from datarep.recipes import RecipeStore
from datarep.registry import SourceRegistry
from datarep.sandbox import execute_code, SandboxResult
from datarep.sync_state import SyncStateManager

logger = logging.getLogger("datarep.agent")

EventCallback = Callable[[str, dict[str, Any]], Awaitable[None]]


def _summarize_tool_input(tool_name: str, tool_input: dict) -> dict[str, Any]:
    """Create a concise summary of tool input for event logging."""
    if tool_name == "run_code":
        code = tool_input.get("code", "")
        return {"source_name": tool_input.get("source_name", ""), "code_lines": code.count('\n') + 1}
    if tool_name == "query_source_db":
        return {"source_name": tool_input.get("source_name", ""), "sql": tool_input.get("sql", "")}
    if tool_name == "save_recipe":
        return {"recipe_id": tool_input.get("recipe_id", ""), "source_name": tool_input.get("source_name", "")}
    return tool_input


def _summarize_tool_result(tool_name: str, result: Any) -> dict[str, Any]:
    """Create a concise summary of tool result for event logging."""
    if isinstance(result, str):
        return {"length": len(result)}
    if not isinstance(result, dict):
        return {"type": type(result).__name__}
    if tool_name == "run_code":
        return {
            "success": result.get("success"),
            "stdout_lines": len(result.get("stdout", "").strip().split('\n')) if result.get("stdout", "").strip() else 0,
            "has_review": "review" in result,
        }
    if tool_name == "query_source_db":
        return {"rows": result.get("count", 0), "truncated": result.get("truncated", False)}
    if "error" in result:
        return {"error": result["error"]}
    if "message" in result:
        return {"message": result["message"]}
    return {"keys": list(result.keys())}


AGENT_TOOLS = [
    {
        "name": "list_sources",
        "description": "List all registered data sources and their types.",
        "input_schema": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "query_source_db",
        "description": (
            "Run read-only SQL against a local SQLite source database. "
            "Only SELECT, PRAGMA, and WITH statements are allowed. "
            "The database is copied to a temp location first for macOS TCC safety."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "source_name": {"type": "string", "description": "Name of the local_db source."},
                "sql": {"type": "string", "description": "SQL query to run (read-only)."},
            },
            "required": ["source_name", "sql"],
        },
    },
    {
        "name": "run_code",
        "description": (
            "Execute Python code in a sandboxed subprocess. Credentials for the source are injected "
            "as environment variables (DATAREP_ACCESS_TOKEN, DATAREP_API_KEY, DATAREP_CRED_JSON). "
            "Output data by printing JSON lines to stdout. DATAREP_OUTPUT_FILE is also available "
            "as an alternative output path. Network access is restricted to the source's registered domains."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "code": {"type": "string", "description": "Python code to execute."},
                "source_name": {
                    "type": "string",
                    "description": "Source name (for credential injection and network allow-list).",
                },
            },
            "required": ["code", "source_name"],
        },
    },
    {
        "name": "get_sync_state",
        "description": "Get the last sync cursor/timestamp for a source.",
        "input_schema": {
            "type": "object",
            "properties": {
                "source_name": {"type": "string"},
            },
            "required": ["source_name"],
        },
    },
    {
        "name": "set_sync_state",
        "description": "Update the sync cursor after a successful retrieval.",
        "input_schema": {
            "type": "object",
            "properties": {
                "source_name": {"type": "string"},
                "recipe_id": {"type": "string"},
                "cursor": {"description": "Opaque cursor value (timestamp, offset, page token, etc.)"},
                "items_retrieved": {"type": "integer"},
            },
            "required": ["source_name", "recipe_id"],
        },
    },
    {
        "name": "save_recipe",
        "description": "Save working retrieval code as a reusable recipe.",
        "input_schema": {
            "type": "object",
            "properties": {
                "recipe_id": {"type": "string", "description": "Unique ID like 'imessage_messages_v1'."},
                "source_name": {"type": "string"},
                "code": {"type": "string", "description": "The Python code that worked."},
                "description": {"type": "string", "description": "What this recipe does."},
            },
            "required": ["recipe_id", "source_name", "code"],
        },
    },
    {
        "name": "load_recipe",
        "description": "Load a previously saved recipe by ID.",
        "input_schema": {
            "type": "object",
            "properties": {
                "recipe_id": {"type": "string"},
            },
            "required": ["recipe_id"],
        },
    },
]

SYSTEM_PROMPT = """\
You are datarep, a data retrieval agent. Your job is to get data from sources on behalf of \
downstream applications. You have tools to query databases, run Python code, \
and save working recipes.

## RULES (must always follow)

1. Never use regex to parse structured or binary formats. If data has a defined format \
with a parsing library (plist, protobuf, JSON, XML, base64, serialized objects, etc.), \
use that library. Regex is only for pattern matching on plain text strings AFTER you have \
properly decoded the container format.

2. Never generate placeholder text like "[Special content]" or "[Unknown]" in output. \
When your code encounters data it cannot parse, output null for that field and log the \
issue to stderr. Placeholders pollute downstream data and hide extraction bugs.

3. Never give up after a fixed number of retries. Every failure is information to adapt \
from. The only reasons to stop are: credentials missing/invalid (return action_required), \
source does not exist, source genuinely has no matching data, or user cancels.

4. Always verify output quality before saving a recipe (see step 7 in Workflow).

5. Always use read-only access on source databases.

## WORKFLOW

1. Check if a recipe already exists for this source (load_recipe or check sync_state).
2. If a recipe exists, try running it. If it works, you're done.
3. If no recipe or the recipe fails: explore the source yourself. Use list_sources to get \
the source config (type, path, etc.), then investigate with the tools you have: \
   - For local databases: use query_source_db to run PRAGMA table_info, sample rows, \
     inspect column types, and examine raw data including BLOBs (e.g. SELECT hex(col), \
     typeof(col), length(col)). Understand what each column actually contains before \
     writing extraction code. \
   - For REST APIs: review the config, then use run_code to explore endpoints. \
   - For local files: use run_code to list and examine files.
4. Plan your parsing approach BEFORE writing code. State what data formats you found \
(plist, protobuf, base64, JSON, XML, serialized objects, etc.) and which Python library \
you will use for each. If a column contains a structured or binary format, name the \
specific library (e.g. plistlib for plist/NSKeyedArchiver, google.protobuf for protobuf, \
base64+json for base64-encoded JSON). Do not write extraction code until you have \
committed to a library for every non-trivial format. Regex is never the right choice \
here — if you are tempted to use regex on a structured format, stop and find the \
correct library.
5. Write Python retrieval code and execute it with run_code.
6. If execution fails, READ THE ERROR, adapt your code, and try again.
7. On success: VERIFY the quality of the extracted data before saving. \
   - Examine the output rows. Do all fields contain real data extracted from the source? \
   - If any field contains values YOUR CODE generated as fallbacks, your extraction is \
     incomplete. Use query_source_db to inspect the raw source data for those rows and \
     understand the real format. Fix your code and re-run. \
   - Cross-reference: pick a few rows and verify the extracted values match what's \
     actually in the source. Spot-check fields that required non-trivial parsing. \
   - Only save the recipe once you've verified output quality. When you call save_recipe, \
     briefly explain what you checked.
8. Save the recipe, update sync state, and return the data.

## CONTEXT (how things work)

Output format:
- Print retrieved data as JSON lines to stdout (one JSON object per line).
- Print progress messages to stderr so they don't mix with data output.

Credentials:
- Injected as environment variables: DATAREP_ACCESS_TOKEN, DATAREP_API_KEY, \
DATAREP_CRED_JSON (full credential JSON).
- For OAuth APIs, use DATAREP_ACCESS_TOKEN as a Bearer token.
- For API key sources, use DATAREP_API_KEY.

Local databases:
- For macOS protected databases (iMessage, etc.), copy the DB to a temp location first \
using shutil.copy2() to bypass TCC restrictions.\
"""


class RetrievalAgent:
    """The core datarep agent that inspects sources and writes retrieval code."""

    def __init__(
        self,
        conn: sqlite3.Connection,
        registry: SourceRegistry | None = None,
        cred_store: CredentialStore | None = None,
        recipe_store: RecipeStore | None = None,
        sync_state: SyncStateManager | None = None,
    ):
        self._conn = conn
        self._registry = registry or SourceRegistry(conn)
        self._creds = cred_store or CredentialStore(conn)
        self._recipes = recipe_store or RecipeStore(conn)
        self._sync_state = sync_state or SyncStateManager(conn)

        api_key = get_anthropic_api_key()
        if not api_key:
            raise ValueError("ANTHROPIC_API_KEY environment variable is required.")
        base_url = get_anthropic_base_url()
        self._client = anthropic.Anthropic(api_key=api_key, base_url=base_url)
        self._model = get_anthropic_model()

    async def run(
        self,
        source_name: str,
        query: str,
        on_event: EventCallback | None = None,
    ) -> dict[str, Any]:
        """Run a retrieval request. Returns the result or an action_required response."""
        request_id = f"{source_name}_{int(time.time())}"
        log_file = self._open_request_log(request_id, source_name, query)

        async def emit(event_type: str, data: dict[str, Any]) -> None:
            event = {
                "event": event_type,
                "timestamp": datetime.now(timezone.utc).isoformat(),
                **data,
            }
            logger.info("[%s] %s: %s", request_id, event_type, json.dumps(data, default=str))
            if log_file:
                log_file.write(json.dumps(event, default=str) + "\n")
                log_file.flush()
            if on_event:
                await on_event(event_type, data)

        await emit("started", {"source": source_name, "query": query})

        action_needed = self._creds.needs_action(source_name)
        if action_needed:
            await emit("complete", {"status": "action_required"})
            self._close_request_log(log_file)
            return action_needed

        source = self._registry.get(source_name)
        if source is None:
            await emit("complete", {"status": "error", "error": f"Source '{source_name}' not found."})
            self._close_request_log(log_file)
            return {
                "status": "error",
                "error": f"Source '{source_name}' not found.",
            }

        user_message = self._build_user_message(source, query)
        messages: list[dict[str, Any]] = [{"role": "user", "content": user_message}]

        max_turns = 50
        for turn in range(max_turns):
            await emit("llm_call", {"turn": turn + 1, "model": self._model})

            response = self._client.messages.create(
                model=self._model,
                max_tokens=8192,
                system=SYSTEM_PROMPT,
                tools=AGENT_TOOLS,
                messages=messages,
            )

            if response.stop_reason == "end_turn":
                final_text = ""
                for block in response.content:
                    if block.type == "text":
                        final_text += block.text
                await emit("complete", {"status": "success", "turns": turn + 1})
                self._close_request_log(log_file)
                return {"status": "success", "result": final_text}

            if response.stop_reason == "tool_use":
                for block in response.content:
                    if block.type == "text" and block.text.strip():
                        await emit("thinking", {"text": block.text.strip()})

                messages.append({"role": "assistant", "content": response.content})
                tool_results = []
                for block in response.content:
                    if block.type == "tool_use":
                        await emit("tool_call", {
                            "tool": block.name,
                            "input": _summarize_tool_input(block.name, block.input),
                        })

                        t0 = time.monotonic()
                        result = await self._handle_tool(block.name, block.input)
                        elapsed_ms = int((time.monotonic() - t0) * 1000)

                        if isinstance(result, dict) and result.get("status") == "action_required":
                            await emit("complete", {"status": "action_required"})
                            self._close_request_log(log_file)
                            return result

                        await emit("tool_result", {
                            "tool": block.name,
                            "elapsed_ms": elapsed_ms,
                            "summary": _summarize_tool_result(block.name, result),
                        })

                        if isinstance(result, str):
                            content_str = result
                        else:
                            content_str = json.dumps(result, default=str)
                        tool_results.append({
                            "type": "tool_result",
                            "tool_use_id": block.id,
                            "content": content_str,
                        })
                messages.append({"role": "user", "content": tool_results})
            else:
                await emit("complete", {"status": "error", "error": f"Unexpected stop reason: {response.stop_reason}"})
                self._close_request_log(log_file)
                return {"status": "error", "error": f"Unexpected stop reason: {response.stop_reason}"}

        await emit("complete", {"status": "error", "error": "Agent exceeded maximum turn limit."})
        self._close_request_log(log_file)
        return {"status": "error", "error": "Agent exceeded maximum turn limit."}

    def _open_request_log(self, request_id: str, source: str, query: str) -> Any:
        """Open a per-request log file in ~/.datarep/logs/."""
        try:
            logs_dir = get_logs_dir()
            logs_dir.mkdir(parents=True, exist_ok=True)
            log_path = logs_dir / f"{request_id}.jsonl"
            return open(log_path, "w")
        except Exception:
            return None

    def _close_request_log(self, log_file: Any) -> None:
        if log_file:
            try:
                log_file.close()
            except Exception:
                pass

    async def run_recipe(self, recipe_id: str) -> dict[str, Any]:
        """Run a saved recipe directly (no LLM call)."""
        recipe = self._recipes.get(recipe_id)
        if recipe is None:
            return {"status": "error", "error": f"Recipe '{recipe_id}' not found."}

        source_name = recipe["source_name"]
        source = self._registry.get(source_name)
        if source is None:
            return {"status": "error", "error": f"Source '{source_name}' not found."}

        action_needed = self._creds.needs_action(source_name)
        if action_needed:
            return action_needed

        cred_env = self._creds.get_for_injection(source_name)
        allowed_domains = self._registry.get_allowed_domains(source_name)
        source_path = source["config"].get("path")

        result = await execute_code(
            code=recipe["code"],
            env=cred_env,
            allowed_domains=allowed_domains,
            source_path=source_path,
        )

        self._recipes.record_use(recipe_id)

        if result.success:
            self._sync_state.set(
                source_name=source_name,
                recipe_id=recipe_id,
                status="success",
            )
            return {"status": "success", "stdout": result.stdout, "stderr": result.stderr}
        else:
            return {
                "status": "error",
                "error": result.stderr or f"Recipe exited with code {result.exit_code}",
                "stdout": result.stdout,
            }

    def _build_user_message(self, source: dict[str, Any], query: str) -> str:
        parts = [
            f"Retrieve data from source '{source['name']}' (type: {source['source_type']}).",
            f"Request: {query}",
            f"Source config: {json.dumps(source['config'], indent=2)}",
        ]

        state = self._sync_state.get(source["name"])
        if state:
            parts.append(f"Last sync state: {json.dumps(state)}")

        existing_recipe = self._recipes.find_for_source(source["name"])
        if existing_recipe:
            parts.append(
                f"Existing recipe '{existing_recipe['id']}' available "
                f"(used {existing_recipe['times_used']} times). "
                f"Try loading and running it first."
            )

        return "\n\n".join(parts)

    async def _handle_tool(self, tool_name: str, tool_input: dict[str, Any]) -> Any:
        handler = {
            "list_sources": self._tool_list_sources,
            "query_source_db": self._tool_query_source_db,
            "run_code": self._tool_run_code,
            "get_sync_state": self._tool_get_sync_state,
            "set_sync_state": self._tool_set_sync_state,
            "save_recipe": self._tool_save_recipe,
            "load_recipe": self._tool_load_recipe,
        }.get(tool_name)

        if handler is None:
            return {"error": f"Unknown tool: {tool_name}"}
        return await handler(tool_input)

    async def _tool_list_sources(self, _input: dict) -> Any:
        return self._registry.list()

    async def _tool_query_source_db(self, tool_input: dict) -> Any:
        name = tool_input["source_name"]
        sql = tool_input["sql"]

        sql_upper = sql.strip().upper()
        if not any(sql_upper.startswith(kw) for kw in ("SELECT", "PRAGMA", "WITH")):
            return {"error": "Only SELECT, PRAGMA, and WITH statements are allowed."}

        source = self._registry.get(name)
        if source is None:
            return {"error": f"Source '{name}' not found."}
        if source["source_type"] != "local_db":
            return {"error": f"Source '{name}' is not a local_db."}

        db_path = os.path.expanduser(source["config"].get("path", ""))
        try:
            tmp_path = _copy_db_to_temp(db_path)
            conn = sqlite3.connect(tmp_path)
            conn.row_factory = sqlite3.Row
            rows = conn.execute(sql).fetchall()
            result = [dict(r) for r in rows[:500]]
            conn.close()
            os.unlink(tmp_path)
            return {"rows": result, "count": len(result), "truncated": len(rows) > 500}
        except Exception as e:
            if "Operation not permitted" in str(e):
                return {
                    "status": "action_required",
                    "action_type": "os_permission",
                    "source": name,
                    "explanation": f"Cannot read database. macOS Full Disk Access is required.",
                    "retryable": True,
                    "context": {"error": str(e)},
                }
            return {"error": str(e)}

    async def _tool_run_code(self, tool_input: dict) -> Any:
        code = tool_input["code"]
        source_name = tool_input.get("source_name", "")

        env = {}
        source_path = None
        allowed_domains: list[str] = []

        if source_name:
            env = self._creds.get_for_injection(source_name)
            source = self._registry.get(source_name)
            if source:
                source_path = source["config"].get("path")
                if source_path:
                    source_path = os.path.expanduser(source_path)
                allowed_domains = self._registry.get_allowed_domains(source_name)
                env["DATAREP_SOURCE_CONFIG"] = json.dumps(source["config"])

        result = await execute_code(
            code=code,
            env=env,
            allowed_domains=allowed_domains,
            source_path=source_path,
        )
        result_dict = result.to_dict()
        if result.success and result.stdout.strip():
            line_count = len([l for l in result.stdout.strip().split('\n') if l.strip()])
            result_dict["review"] = (
                f"Code ran successfully and produced {line_count} lines of output. "
                "Before saving this as a recipe, you MUST verify TWO things:\n"
                "1. OUTPUT QUALITY: examine sample rows, check that all fields contain "
                "real extracted data (not placeholder values your code generated), and "
                "cross-reference a few rows against the source using query_source_db.\n"
                "2. METHOD COMPLIANCE: verify your code uses proper parsing libraries "
                "for any structured or binary data (plistlib for plist/NSKeyedArchiver, "
                "xml.etree for XML, json for JSON, base64 for base64, etc.). "
                "If you used regex to parse a structured or binary format, the recipe is "
                "WRONG even if the output looks correct — rewrite with the correct "
                "library before saving. Regex is a latent bug on structured data."
            )
        return result_dict

    async def _tool_get_sync_state(self, tool_input: dict) -> Any:
        state = self._sync_state.get(tool_input["source_name"])
        return state or {"message": "No sync state found for this source."}

    async def _tool_set_sync_state(self, tool_input: dict) -> Any:
        self._sync_state.set(
            source_name=tool_input["source_name"],
            recipe_id=tool_input["recipe_id"],
            cursor=tool_input.get("cursor"),
            items_retrieved=tool_input.get("items_retrieved", 0),
        )
        return {"message": "Sync state updated."}

    async def _tool_save_recipe(self, tool_input: dict) -> Any:
        return self._recipes.save(
            recipe_id=tool_input["recipe_id"],
            source_name=tool_input["source_name"],
            code=tool_input["code"],
            description=tool_input.get("description"),
        )

    async def _tool_load_recipe(self, tool_input: dict) -> Any:
        recipe = self._recipes.get(tool_input["recipe_id"])
        return recipe or {"error": f"Recipe '{tool_input['recipe_id']}' not found."}


def _copy_db_to_temp(db_path: str) -> str:
    """Copy a database file to /tmp for TCC-safe read access."""
    tmp_dir = tempfile.mkdtemp(prefix="datarep_db_")
    basename = os.path.basename(db_path)
    tmp_path = os.path.join(tmp_dir, basename)
    shutil.copy2(db_path, tmp_path)
    wal_path = db_path + "-wal"
    if os.path.exists(wal_path):
        shutil.copy2(wal_path, tmp_path + "-wal")
    shm_path = db_path + "-shm"
    if os.path.exists(shm_path):
        shutil.copy2(shm_path, tmp_path + "-shm")
    return tmp_path
