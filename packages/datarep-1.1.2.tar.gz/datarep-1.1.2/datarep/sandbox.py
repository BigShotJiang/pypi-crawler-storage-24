"""Sandboxed Python code execution with network allow-list and credential injection."""

from __future__ import annotations

import asyncio
import json
import os
import platform
import tempfile
from pathlib import Path
from typing import Any


_SANDBOX_PROFILE_TEMPLATE = """\
(version 1)
(deny default)
(allow process-exec)
(allow process-fork)
(allow sysctl-read)
(allow file-read*)
(allow file-write* (subpath "{workdir}"))
(allow file-write* (subpath "/private/tmp"))
(allow file-write* (subpath "/private/var/folders"))
{source_read_rule}
{network_rules}
"""


def _build_macos_sandbox_profile(
    workdir: str,
    allowed_domains: list[str],
    source_path: str | None = None,
) -> str | None:
    """Build a macOS sandbox-exec profile. Returns None if not on macOS."""
    if platform.system() != "Darwin":
        return None

    source_read_rule = ""
    if source_path:
        source_read_rule = f'(allow file-read* (subpath "{source_path}"))'

    if allowed_domains:
        network_rules = "(allow network-outbound (remote tcp))"
    else:
        network_rules = ""

    return _SANDBOX_PROFILE_TEMPLATE.format(
        workdir=workdir,
        source_read_rule=source_read_rule,
        network_rules=network_rules,
    )


class SandboxResult:
    """Result of a sandboxed code execution."""

    def __init__(self, stdout: str, stderr: str, exit_code: int | None, timed_out: bool = False):
        self.stdout = stdout
        self.stderr = stderr
        self.exit_code = exit_code
        self.timed_out = timed_out

    @property
    def success(self) -> bool:
        return self.exit_code == 0 and not self.timed_out

    def to_dict(self) -> dict[str, Any]:
        return {
            "stdout": self.stdout,
            "stderr": self.stderr,
            "exit_code": self.exit_code,
            "timed_out": self.timed_out,
            "success": self.success,
        }


async def execute_code(
    code: str,
    env: dict[str, str] | None = None,
    timeout_seconds: int = 300,
    allowed_domains: list[str] | None = None,
    source_path: str | None = None,
) -> SandboxResult:
    """Execute Python code in a sandboxed subprocess.

    Args:
        code: Python source code to execute.
        env: Additional environment variables to inject (credentials, etc.).
        timeout_seconds: Maximum execution time.
        allowed_domains: Network domains the code is allowed to contact.
        source_path: Path to the source data (read-only access granted).
    """
    env = env or {}
    allowed_domains = allowed_domains or []

    with tempfile.TemporaryDirectory(prefix="datarep_sandbox_") as workdir:
        script_path = os.path.join(workdir, "script.py")
        with open(script_path, "w") as f:
            f.write(code)

        output_path = os.path.join(workdir, "output.jsonl")

        process_env = {
            **os.environ,
            **env,
            "DATAREP_WORKDIR": workdir,
            "DATAREP_OUTPUT_FILE": output_path,
        }

        sandbox_profile = _build_macos_sandbox_profile(workdir, allowed_domains, source_path)

        if sandbox_profile:
            profile_path = os.path.join(workdir, "sandbox.sb")
            with open(profile_path, "w") as f:
                f.write(sandbox_profile)
            cmd = ["sandbox-exec", "-f", profile_path, "python3", "-u", script_path]
        else:
            cmd = ["python3", "-u", script_path]

        try:
            process = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env=process_env,
                cwd=workdir,
            )

            try:
                stdout_bytes, stderr_bytes = await asyncio.wait_for(
                    process.communicate(), timeout=timeout_seconds
                )
                return SandboxResult(
                    stdout=stdout_bytes.decode("utf-8", errors="replace"),
                    stderr=stderr_bytes.decode("utf-8", errors="replace"),
                    exit_code=process.returncode,
                )
            except asyncio.TimeoutError:
                process.kill()
                await process.communicate()
                return SandboxResult(
                    stdout="",
                    stderr=f"Execution timed out after {timeout_seconds} seconds.",
                    exit_code=None,
                    timed_out=True,
                )
        except Exception as e:
            return SandboxResult(
                stdout="",
                stderr=f"Failed to start sandbox: {e}",
                exit_code=None,
            )
