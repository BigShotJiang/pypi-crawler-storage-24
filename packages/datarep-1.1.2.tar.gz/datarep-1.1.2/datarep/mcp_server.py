"""MCP server — native interface for agentic apps to use datarep."""

from __future__ import annotations

import json
from typing import Any

from mcp.server.fastmcp import FastMCP

from datarep.config import ensure_home
from datarep.db import get_connection
from datarep.agent import RetrievalAgent
from datarep.credentials import CredentialStore
from datarep.recipes import RecipeStore
from datarep.registry import SourceRegistry
from datarep.sync_state import SyncStateManager

mcp = FastMCP("datarep", instructions=(
    "datarep is a data retrieval service. Use these tools to get data from registered sources. "
    "When a tool returns status='action_required', explain the situation to the user "
    "conversationally and guide them through the required steps. "
    "After the user completes the action, retry the original request."
))

_conn = None
_agent = None
_registry = None
_recipe_store = None
_sync_state = None
_cred_store = None


def _init():
    global _conn, _agent, _registry, _recipe_store, _sync_state, _cred_store
    if _conn is not None:
        return
    ensure_home()
    _conn = get_connection()
    _registry = SourceRegistry(_conn)
    _cred_store = CredentialStore(_conn)
    _recipe_store = RecipeStore(_conn)
    _sync_state = SyncStateManager(_conn)
    try:
        _agent = RetrievalAgent(
            _conn,
            registry=_registry,
            cred_store=_cred_store,
            recipe_store=_recipe_store,
            sync_state=_sync_state,
        )
    except ValueError:
        _agent = None


@mcp.tool()
async def datarep_get(source: str, query: str) -> str:
    """Retrieve data from a registered source using an agent-driven approach.

    The agent inspects the source, writes retrieval code, executes it, and returns results.
    If permissions or auth are needed, returns an action_required response with
    instructions the consuming agent can relay to the user.

    Args:
        source: Name of the registered data source.
        query: Natural language description of what data to retrieve.
    """
    _init()
    if _agent is None:
        return json.dumps({"status": "error", "error": "Agent not available. Check ANTHROPIC_API_KEY."})
    result = await _agent.run(source, query)
    return json.dumps(result)


@mcp.tool()
async def datarep_sync(source: str, query: str = "") -> str:
    """Run an incremental sync for a source, picking up where the last sync left off.

    Args:
        source: Name of the registered data source.
        query: Optional description of what to sync (defaults to full incremental sync).
    """
    _init()
    if _agent is None:
        return json.dumps({"status": "error", "error": "Agent not available. Check ANTHROPIC_API_KEY."})
    query = query or f"Incremental sync for {source}"
    result = await _agent.run(source, query)
    return json.dumps(result)


@mcp.tool()
async def datarep_list_sources() -> str:
    """List all registered data sources and their current sync status."""
    _init()
    sources = _registry.list()
    for s in sources:
        s["sync_state"] = _sync_state.get(s["name"])
    return json.dumps({"sources": sources})


@mcp.tool()
async def datarep_run_recipe(recipe_id: str) -> str:
    """Run a previously saved retrieval recipe (no LLM call — fast path).

    Args:
        recipe_id: The ID of the recipe to run.
    """
    _init()
    if _agent is None:
        return json.dumps({"status": "error", "error": "Agent not available. Check ANTHROPIC_API_KEY."})
    result = await _agent.run_recipe(recipe_id)
    return json.dumps(result)


@mcp.tool()
async def datarep_list_recipes(source: str = "") -> str:
    """List saved retrieval recipes, optionally filtered by source.

    Args:
        source: Optional source name to filter recipes.
    """
    _init()
    recipes = _recipe_store.list(source_name=source or None)
    return json.dumps({"recipes": recipes})


@mcp.tool()
async def datarep_initiate_oauth(source: str) -> str:
    """Start an OAuth authorization flow for a source.

    Opens the user's browser to the provider's consent screen.
    Call this after explaining to the user what's about to happen.

    Args:
        source: Name of the source to authenticate with.
    """
    _init()
    src = _registry.get(source)
    if src is None:
        return json.dumps({"status": "error", "error": f"Source '{source}' not found."})

    config = src["config"]
    required = ["auth_url", "token_url", "client_id", "client_secret"]
    missing = [k for k in required if k not in config]
    if missing:
        return json.dumps({"status": "error", "error": f"Source config missing: {', '.join(missing)}"})

    from datarep.credentials import OAuthFlow
    flow = OAuthFlow(
        auth_url=config["auth_url"],
        token_url=config["token_url"],
        client_id=config["client_id"],
        client_secret=config["client_secret"],
        scopes=config.get("scopes", []),
    )
    try:
        tokens = flow.run()
        _cred_store.store(source, "oauth2", {
            **tokens,
            "client_id": config["client_id"],
            "client_secret": config["client_secret"],
            "token_url": config["token_url"],
        })
        return json.dumps({"status": "success", "message": f"OAuth flow completed for '{source}'."})
    except Exception as e:
        return json.dumps({"status": "error", "error": str(e)})


@mcp.tool()
async def datarep_check_permission(source: str) -> str:
    """Check if a source is accessible before attempting retrieval.

    Returns OK if the source is ready, or action_required if user action is needed.

    Args:
        source: Name of the source to check.
    """
    _init()
    src = _registry.get(source)
    if src is None:
        return json.dumps({"status": "error", "error": f"Source '{source}' not found."})

    action_needed = _cred_store.needs_action(source)
    if action_needed:
        return json.dumps(action_needed)

    return json.dumps({"status": "ok", "source": source, "type": src["source_type"]})


@mcp.resource("datarep://sources")
async def resource_sources() -> str:
    """List of registered data sources and their types."""
    _init()
    sources = _registry.list()
    return json.dumps(sources)


@mcp.resource("datarep://recipes")
async def resource_recipes() -> str:
    """List of saved retrieval recipes."""
    _init()
    recipes = _recipe_store.list()
    return json.dumps(recipes)


def run_mcp_server():
    """Entry point for running the MCP server standalone."""
    _init()
    mcp.run()
