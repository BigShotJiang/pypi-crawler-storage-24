"""Recipe store — save, load, and replay working retrieval code."""

from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from datarep.config import get_recipes_dir


class RecipeStore:
    """Manages saved retrieval recipes."""

    def __init__(self, conn: sqlite3.Connection):
        self._conn = conn

    def save(
        self,
        recipe_id: str,
        source_name: str,
        code: str,
        description: str | None = None,
    ) -> dict[str, Any]:
        now = datetime.now(timezone.utc).isoformat()
        self._conn.execute(
            """INSERT OR REPLACE INTO recipes
               (id, source_name, description, code, created_at)
               VALUES (?, ?, ?, ?, ?)""",
            (recipe_id, source_name, description, code, now),
        )
        self._conn.commit()

        recipes_dir = get_recipes_dir()
        recipes_dir.mkdir(parents=True, exist_ok=True)
        recipe_file = recipes_dir / f"{recipe_id}.py"
        header = f'# Recipe: {recipe_id}\n# Source: {source_name}\n# Description: {description or "N/A"}\n# Created: {now}\n\n'
        recipe_file.write_text(header + code)

        return {
            "id": recipe_id,
            "source_name": source_name,
            "description": description,
            "created_at": now,
        }

    def get(self, recipe_id: str) -> dict[str, Any] | None:
        row = self._conn.execute(
            "SELECT id, source_name, description, code, last_used_at, times_used, created_at FROM recipes WHERE id = ?",
            (recipe_id,),
        ).fetchone()
        if row is None:
            return None
        return {
            "id": row["id"],
            "source_name": row["source_name"],
            "description": row["description"],
            "code": row["code"],
            "last_used_at": row["last_used_at"],
            "times_used": row["times_used"],
            "created_at": row["created_at"],
        }

    def list(self, source_name: str | None = None) -> list[dict[str, Any]]:
        if source_name:
            rows = self._conn.execute(
                "SELECT id, source_name, description, last_used_at, times_used, created_at FROM recipes WHERE source_name = ?",
                (source_name,),
            ).fetchall()
        else:
            rows = self._conn.execute(
                "SELECT id, source_name, description, last_used_at, times_used, created_at FROM recipes"
            ).fetchall()
        return [
            {
                "id": r["id"],
                "source_name": r["source_name"],
                "description": r["description"],
                "last_used_at": r["last_used_at"],
                "times_used": r["times_used"],
                "created_at": r["created_at"],
            }
            for r in rows
        ]

    def record_use(self, recipe_id: str) -> None:
        now = datetime.now(timezone.utc).isoformat()
        self._conn.execute(
            "UPDATE recipes SET last_used_at = ?, times_used = times_used + 1 WHERE id = ?",
            (now, recipe_id),
        )
        self._conn.commit()

    def delete(self, recipe_id: str) -> bool:
        cursor = self._conn.execute("DELETE FROM recipes WHERE id = ?", (recipe_id,))
        self._conn.commit()
        recipe_file = get_recipes_dir() / f"{recipe_id}.py"
        if recipe_file.exists():
            recipe_file.unlink()
        return cursor.rowcount > 0

    def find_for_source(self, source_name: str) -> dict[str, Any] | None:
        """Find the most recently used recipe for a source."""
        row = self._conn.execute(
            """SELECT id, source_name, description, code, last_used_at, times_used, created_at
               FROM recipes WHERE source_name = ?
               ORDER BY COALESCE(last_used_at, created_at) DESC LIMIT 1""",
            (source_name,),
        ).fetchone()
        if row is None:
            return None
        return {
            "id": row["id"],
            "source_name": row["source_name"],
            "description": row["description"],
            "code": row["code"],
            "last_used_at": row["last_used_at"],
            "times_used": row["times_used"],
            "created_at": row["created_at"],
        }
