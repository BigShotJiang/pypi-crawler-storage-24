# datarep

Your app's data rep.

A **rep** is someone you send to go get something on your behalf. You don't tell them how — you tell them what you need, and they figure it out. They show up, assess the situation, adapt to whatever they find, and come back with the goods.

That's what datarep does. Your app says "get me the user's recent iMessages" and datarep handles it — explores the database schema, identifies the data formats, picks the right parsing libraries, writes the extraction code, tests it, and delivers the data. No one wrote an iMessage integration. The rep wrote one at runtime.

And like a good rep, it learns. Working code is saved as **recipes** so next time it doesn't have to figure it out again. First request takes seconds. Every request after that is instant.

## Why this exists

Every app that needs user data today has to build and maintain its own integrations — or depend on a cloud service that proxies the user's data through someone else's servers. datarep is a different approach: a local agent runtime that synthesizes integrations on demand, runs on the user's machine, and never sends their data anywhere.

There isn't really a category for this yet. It's not a connector (those are pre-built by humans), not an ETL pipeline, not an SDK. It's an autonomous agent that *becomes* a connector — for any source, on the fly.

## Quick start

```bash
pip install -e ".[dev]"
datarep init
export ANTHROPIC_API_KEY="sk-ant-..."
datarep start
```

Register your app and get an API key:

```bash
datarep app register my-app
```

Retrieve data:

```bash
curl -X POST http://127.0.0.1:7080/get \
  -H "Authorization: Bearer dr_<your-api-key>" \
  -H "Content-Type: application/json" \
  -d '{"source": "my_source", "query": "get recent records"}'
```

## How it works

Your app tells datarep what data it needs. datarep's agent:

1. **Explores the source** — inspects schemas, samples data, identifies formats
2. **Writes retrieval code** — picks the right parsing libraries, handles edge cases
3. **Executes in a sandbox** — network and filesystem restrictions via macOS `sandbox-exec`
4. **Validates the output** — verifies data quality and method correctness before delivering
5. **Saves a recipe** — working code is cached for instant, deterministic replay

Credentials are encrypted at rest. Apps authenticate with per-app API keys. Users grant trust once (to datarep) and every consuming app gets safe data access through it.

## Interfaces

| Interface | Use case |
|-----------|----------|
| **HTTP API** (`localhost:7080`) | Primary interface for all apps. Bearer token auth. |
| **MCP server** | Native interface for agentic/LLM-powered apps. |
| **CLI** (`datarep`) | Setup, source management, debugging. |

## Source types

| Type | Example | Sandbox |
|------|---------|---------|
| `local_db` | iMessage `chat.db`, WhatsApp, any SQLite | No network. Read-only DB access. |
| `rest_api` | Square, Gmail, Quickbooks | Network restricted to source domain. |
| `local_files` | Photos, documents, exports | No network. Read-only directory access. |

## Integration guide

See **[docs/integration-guide.md](docs/integration-guide.md)** for the full walkthrough: API reference, authentication, handling permissions, MCP setup, recipes, and code examples.

## Development

```bash
pip install -e ".[dev]"
pytest
```
