"""GNU Radio MCP Server — Bridge an LLM to a live GNU Radio SDR flowgraph."""

__version__ = "0.1.0"

from .server import mcp  # noqa: F401

__all__ = ["mcp", "__version__"]
