"""DSP routines for the GNU Radio MCP Server.

All functions are pure (no side effects, no I/O).
"""

from __future__ import annotations

import numpy as np
from scipy.signal import welch as scipy_welch


# ---------------------------------------------------------------------------
# Core DSP
# ---------------------------------------------------------------------------

def compute_psd(
    iq: np.ndarray,
    fft_size: int,
    samp_rate: float,
    center_freq: float,
) -> tuple[np.ndarray, np.ndarray]:
    """Compute the Power Spectral Density of IQ samples.

    Uses Welch's method if ``len(iq) >= 8 * fft_size``, otherwise a single
    FFT with a Hann window. Returns ``(freqs_hz, psd_dbm)`` both of length
    ``fft_size``.  ``freqs_hz`` are absolute (``center_freq ± samp_rate/2``).

    Args:
        iq: Complex64 IQ samples.
        fft_size: FFT size (number of frequency bins).
        samp_rate: Sample rate in Hz.
        center_freq: Center frequency in Hz.

    Returns:
        Tuple of (freqs_hz, psd_dbm), each np.ndarray of length fft_size.
    """
    use_welch = len(iq) >= 8 * fft_size

    if use_welch:
        freqs_rel, psd_linear = scipy_welch(
            iq,
            fs=samp_rate,
            nperseg=fft_size,
            noverlap=fft_size // 2,
            return_onesided=False,
            detrend=False,
        )
        # scipy_welch returns unshifted; shift for center-frequency display
        psd_linear = np.fft.fftshift(psd_linear)
        freqs_rel = np.fft.fftshift(freqs_rel)
    else:
        # Single FFT with Hann window
        window = np.hanning(len(iq))
        windowed = iq * window
        spectrum = np.fft.fftshift(np.fft.fft(windowed, n=fft_size))

        # Power spectral density (V²/Hz normalisation)
        psd_linear = (np.abs(spectrum) ** 2) / (samp_rate * np.sum(window ** 2))
        freqs_rel = np.fft.fftshift(np.fft.fftfreq(fft_size, d=1.0 / samp_rate))

    # Convert to dBm (assuming 50 Ω impedance → P = V²/R, 10*log10(P/1mW))
    # For SDR IQ data we treat amplitude as voltage across 50 Ω:
    # P_mW = (V_rms² / 50) * 1000
    # In practice, SDR values are normalised so we just do 10*log10(psd) + 30
    with np.errstate(divide="ignore"):
        psd_dbm = 10.0 * np.log10(np.maximum(psd_linear, 1e-30)) + 30.0

    # Absolute frequencies
    freqs_hz = freqs_rel + center_freq

    # Ensure output length is exactly fft_size
    if len(freqs_hz) > fft_size:
        freqs_hz = freqs_hz[:fft_size]
        psd_dbm = psd_dbm[:fft_size]
    elif len(freqs_hz) < fft_size:
        pad = fft_size - len(freqs_hz)
        freqs_hz = np.pad(freqs_hz, (0, pad), mode="edge")
        psd_dbm = np.pad(psd_dbm, (0, pad), constant_values=-200.0)

    return freqs_hz, psd_dbm


def find_peaks(
    freqs_hz: np.ndarray,
    psd_dbm: np.ndarray,
    top_n: int,
    min_distance_hz: float = 10e3,
) -> list[dict]:
    """Find up to *top_n* peaks sorted by power descending.

    Each dict: ``{freq_hz, power_dbm, bandwidth_hz}``
    where ``bandwidth_hz`` is the 3 dB rolloff width.
    ``min_distance_hz`` prevents returning adjacent bins as separate peaks.

    Args:
        freqs_hz: Array of frequency values in Hz.
        psd_dbm: Array of PSD values in dBm.
        top_n: Maximum number of peaks to return.
        min_distance_hz: Minimum separation between peaks.

    Returns:
        List of peak dicts sorted by power descending.
    """
    if len(psd_dbm) < 3:
        return []

    # Compute bin spacing
    bin_spacing_hz = abs(freqs_hz[1] - freqs_hz[0]) if len(freqs_hz) > 1 else 1.0
    min_distance_bins = max(1, int(min_distance_hz / bin_spacing_hz))

    # Find local maxima (higher than both neighbours)
    candidates: list[tuple[int, float]] = []
    for i in range(1, len(psd_dbm) - 1):
        if psd_dbm[i] > psd_dbm[i - 1] and psd_dbm[i] > psd_dbm[i + 1]:
            candidates.append((i, float(psd_dbm[i])))

    # Sort by power descending
    candidates.sort(key=lambda x: x[1], reverse=True)

    # Enforce minimum distance
    selected: list[int] = []
    for idx, _ in candidates:
        if all(abs(idx - s) >= min_distance_bins for s in selected):
            selected.append(idx)
            if len(selected) >= top_n:
                break

    # Build result with 3 dB bandwidth
    peaks: list[dict] = []
    for idx in selected:
        peak_power = float(psd_dbm[idx])
        threshold = peak_power - 3.0

        # Find 3 dB bandwidth (left edge)
        left = idx
        while left > 0 and psd_dbm[left] > threshold:
            left -= 1

        # Find 3 dB bandwidth (right edge)
        right = idx
        while right < len(psd_dbm) - 1 and psd_dbm[right] > threshold:
            right += 1

        bandwidth_hz = float((right - left) * bin_spacing_hz)

        peaks.append({
            "freq_hz": float(freqs_hz[idx]),
            "power_dbm": round(peak_power, 1),
            "bandwidth_hz": round(bandwidth_hz, 1),
        })

    # Sort by power descending
    peaks.sort(key=lambda p: p["power_dbm"], reverse=True)
    return peaks


def estimate_noise_floor(psd_dbm: np.ndarray) -> float:
    """Estimate noise floor as the 10th percentile of PSD values.

    Robust to strong signals — they pull up the mean but not the
    10th percentile.
    """
    return float(np.percentile(psd_dbm, 10))


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def db_to_mw(dbm: float) -> float:
    """Convert dBm to milliwatts.

    Example: 0 dBm → 1.0 mW, -30 dBm → 0.001 mW
    """
    return 10.0 ** (dbm / 10.0)


def hz_to_readable(hz: float) -> str:
    """Convert a frequency in Hz to a human-readable string.

    Examples:
        433920000  → '433.920 MHz'
        1575420000 → '1575.420 MHz'
    """
    abs_hz = abs(hz)
    if abs_hz >= 1e9:
        return f"{hz / 1e9:.3f} GHz"
    if abs_hz >= 1e6:
        return f"{hz / 1e6:.3f} MHz"
    if abs_hz >= 1e3:
        return f"{hz / 1e3:.3f} kHz"
    return f"{hz:.3f} Hz"
