"""FastMCP server with all 13 GNU Radio tools.

Entry point: ``main()`` (called via ``gnuradio-mcp`` console script).
"""

from __future__ import annotations

import asyncio
import json
import sys
import time
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from typing import Any

import numpy as np

from mcp.server.fastmcp import Context, FastMCP

from .config import Settings
from .dsp import compute_psd, estimate_noise_floor, find_peaks
from .exceptions import (
    GNURadioError,
    GRHardwareError,
    GROfflineError,
    GRVariableError,
)
from .models import (
    CaptureInput,
    GetVariableInput,
    ResponseFormat,
    SetFrequencyInput,
    SetGainInput,
    SetSampleRateInput,
    SetVariableInput,
    SpectrumInput,
    SweepInput,
)
from .utils import db_to_str, hz_to_readable, sps_to_readable
from .xmlrpc_client import call_rpc, list_methods, _clear_methods_cache
from .zmq_client import get_context as get_zmq_ctx, recv_samples

# ---------------------------------------------------------------------------
# Settings & Lifespan
# ---------------------------------------------------------------------------

settings = Settings()


@asynccontextmanager
async def lifespan(server: FastMCP) -> AsyncIterator[dict]:
    """Manage ZMQ context lifecycle."""
    zmq_ctx = get_zmq_ctx()
    try:
        yield {"zmq_ctx": zmq_ctx}
    finally:
        zmq_ctx.term()


mcp = FastMCP("gnuradio_mcp", lifespan=lifespan)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _error_response(exc: GNURadioError) -> str:
    """Format an exception as a structured JSON error string."""
    return json.dumps(exc.to_dict(), indent=2)


def _json_response(data: dict) -> str:
    """Serialise a dict response to pretty-printed JSON."""
    return json.dumps(data, indent=2)


# ---------------------------------------------------------------------------
# Tool 01 — gnuradio_flowgraph_start
# ---------------------------------------------------------------------------

@mcp.tool(
    name="gnuradio_flowgraph_start",
    annotations={
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def gnuradio_flowgraph_start() -> str:
    """Start the GNU Radio flowgraph via XML-RPC.

    If the flowgraph is already running, returns ``already_running``
    status instead of an error.

    Returns:
        JSON with ``{status, host, xmlrpc_port}``.

    Error Handling:
        Returns structured error if GNU Radio is not reachable.
    """
    try:
        # Check if already running
        try:
            list_methods(settings)
            # If we can list methods, the flowgraph is reachable
            try:
                call_rpc("run", settings=settings)
            except GNURadioError:
                # Already running — some flowgraphs raise on duplicate run()
                pass
            return _json_response({
                "status": "already_running",
                "host": settings.gr_host,
                "xmlrpc_port": settings.gr_xmlrpc_port,
            })
        except GROfflineError:
            pass

        call_rpc("run", settings=settings)
        _clear_methods_cache()
        return _json_response({
            "status": "running",
            "host": settings.gr_host,
            "xmlrpc_port": settings.gr_xmlrpc_port,
        })
    except GNURadioError as exc:
        return _error_response(exc)


# ---------------------------------------------------------------------------
# Tool 02 — gnuradio_flowgraph_stop
# ---------------------------------------------------------------------------

@mcp.tool(
    name="gnuradio_flowgraph_stop",
    annotations={
        "readOnlyHint": False,
        "destructiveHint": True,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def gnuradio_flowgraph_stop() -> str:
    """Stop the GNU Radio flowgraph via XML-RPC.

    Returns:
        JSON with ``{status: "stopped"}``.
    """
    try:
        call_rpc("stop", settings=settings)
        _clear_methods_cache()
        return _json_response({"status": "stopped"})
    except GNURadioError as exc:
        return _error_response(exc)


# ---------------------------------------------------------------------------
# Tool 03 — gnuradio_flowgraph_status
# ---------------------------------------------------------------------------

@mcp.tool(
    name="gnuradio_flowgraph_status",
    annotations={
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def gnuradio_flowgraph_status() -> str:
    """Get the current status of the GNU Radio flowgraph.

    Pings XML-RPC, reads known variables (freq, samp_rate, gain)
    if available.

    Returns:
        JSON with ``{running, freq_hz, freq_readable, samp_rate, gain_db, host, xmlrpc_port}``.
    """
    result: dict[str, Any] = {
        "running": False,
        "host": settings.gr_host,
        "xmlrpc_port": settings.gr_xmlrpc_port,
    }

    try:
        list_methods(settings)
        result["running"] = True
    except GNURadioError:
        return _json_response(result)

    # Read known variables — skip gracefully if not present
    for var_name, key, formatter in [
        ("freq", "freq_hz", None),
        ("samp_rate", "samp_rate", None),
        ("gain", "gain_db", None),
    ]:
        try:
            val = call_rpc(f"get_{var_name}", settings=settings)
            result[key] = val
        except GNURadioError:
            pass

    if "freq_hz" in result:
        result["freq_readable"] = hz_to_readable(result["freq_hz"])

    return _json_response(result)


# ---------------------------------------------------------------------------
# Tool 04 — gnuradio_set_center_frequency
# ---------------------------------------------------------------------------

@mcp.tool(
    name="gnuradio_set_center_frequency",
    annotations={
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def gnuradio_set_center_frequency(frequency_hz: float) -> str:
    """Set the center frequency of the SDR.

    Args:
        frequency_hz: Center frequency in Hz.
            Examples: 433.92e6 for 433 MHz ISM, 1575.42e6 for GPS L1,
            88.5e6 for FM radio.

    Returns:
        JSON with ``{ok, requested_hz, actual_hz, requested_readable, actual_readable}``.

    Error Handling:
        Returns error if frequency is outside hardware range.
    """
    try:
        # Bounds validation
        if not (settings.freq_min_hz <= frequency_hz <= settings.freq_max_hz):
            raise GRHardwareError(
                message=(
                    f"Frequency {frequency_hz / 1e6:.3f} MHz out of range "
                    f"[{settings.freq_min_hz / 1e6:.0f}–{settings.freq_max_hz / 1e6:.0f} MHz]"
                ),
                suggestion="Check GNURADIO_FREQ_MIN_HZ / GNURADIO_FREQ_MAX_HZ settings.",
            )

        call_rpc("set_freq", frequency_hz, settings=settings)

        # Settling delay for PLL lock
        await asyncio.sleep(0.05)

        # Read back actual frequency
        try:
            actual = call_rpc("get_freq", settings=settings)
        except GNURadioError:
            actual = frequency_hz

        return _json_response({
            "ok": True,
            "requested_hz": frequency_hz,
            "actual_hz": actual,
            "requested_readable": hz_to_readable(frequency_hz),
            "actual_readable": hz_to_readable(actual),
        })
    except GNURadioError as exc:
        return _error_response(exc)


# ---------------------------------------------------------------------------
# Tool 05 — gnuradio_set_sample_rate
# ---------------------------------------------------------------------------

@mcp.tool(
    name="gnuradio_set_sample_rate",
    annotations={
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": False,
        "openWorldHint": False,
    },
)
async def gnuradio_set_sample_rate(samp_rate: float) -> str:
    """Set the sample rate of the SDR.

    Args:
        samp_rate: Sample rate in samples/sec.
            HackRF max: 20e6. RTL-SDR max: ~3.2e6. Example: 2e6 for 2 Msps.

    Returns:
        JSON with ``{ok, requested_sps, actual_sps, note}``.
    """
    try:
        # Bounds validation
        if not (settings.samp_rate_min <= samp_rate <= settings.samp_rate_max):
            raise GRHardwareError(
                message=(
                    f"Sample rate {samp_rate / 1e6:.3f} Msps out of range "
                    f"[{settings.samp_rate_min / 1e6:.1f}–{settings.samp_rate_max / 1e6:.1f} Msps]"
                ),
                suggestion="Check GNURADIO_SAMP_RATE_MIN / GNURADIO_SAMP_RATE_MAX settings.",
            )

        call_rpc("set_samp_rate", samp_rate, settings=settings)

        # Update in-memory default for DSP tools
        settings.default_samp_rate = samp_rate

        # Read back
        try:
            actual = call_rpc("get_samp_rate", settings=settings)
        except GNURadioError:
            actual = samp_rate

        return _json_response({
            "ok": True,
            "requested_sps": samp_rate,
            "actual_sps": actual,
            "note": "Some hardware requires flowgraph restart for sample rate changes.",
        })
    except GNURadioError as exc:
        return _error_response(exc)


# ---------------------------------------------------------------------------
# Tool 06 — gnuradio_set_gain
# ---------------------------------------------------------------------------

@mcp.tool(
    name="gnuradio_set_gain",
    annotations={
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def gnuradio_set_gain(gain_db: float, stage: str = "if") -> str:
    """Set the gain of the SDR.

    Args:
        gain_db: Gain in dB. Typical range 0–62 dB.
        stage: Gain stage: 'if' (default), 'rf', or 'bb'.

    Returns:
        JSON with ``{ok, stage, requested_db, actual_db}``.
    """
    try:
        # Bounds validation
        if not (settings.gain_min_db <= gain_db <= settings.gain_max_db):
            raise GRHardwareError(
                message=(
                    f"Gain {gain_db:.1f} dB out of range "
                    f"[{settings.gain_min_db:.0f}–{settings.gain_max_db:.0f} dB]"
                ),
                suggestion="Check GNURADIO_GAIN_MIN_DB / GNURADIO_GAIN_MAX_DB settings.",
            )

        # Map stage to GNU Radio variable names
        stage_map = {"if": "set_if_gain", "rf": "set_rf_gain", "bb": "set_bb_gain"}
        stage_get_map = {"if": "get_if_gain", "rf": "get_rf_gain", "bb": "get_bb_gain"}

        rpc_method = stage_map.get(stage, "set_if_gain")
        rpc_get = stage_get_map.get(stage, "get_if_gain")

        try:
            call_rpc(rpc_method, gain_db, settings=settings)
        except GRVariableError:
            # Fall back to generic set_gain
            call_rpc("set_gain", gain_db, settings=settings)
            rpc_get = "get_gain"

        # Read back
        try:
            actual = call_rpc(rpc_get, settings=settings)
        except GNURadioError:
            actual = gain_db

        return _json_response({
            "ok": True,
            "stage": stage,
            "requested_db": gain_db,
            "actual_db": actual,
        })
    except GNURadioError as exc:
        return _error_response(exc)


# ---------------------------------------------------------------------------
# Tool 07 — gnuradio_set_variable
# ---------------------------------------------------------------------------

@mcp.tool(
    name="gnuradio_set_variable",
    annotations={
        "readOnlyHint": False,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def gnuradio_set_variable(name: str, value: float) -> str:
    """Set an arbitrary flowgraph variable via XML-RPC.

    Args:
        name: Flowgraph variable name as exposed by XML-RPC,
            e.g. 'freq', 'samp_rate', 'gain'.
        value: New value to set.

    Returns:
        JSON with ``{ok, name, previous_value, new_value}``.

    Error Handling:
        Returns GRVariableError if the variable does not exist.
    """
    try:
        # Verify variable exists
        methods = list_methods(settings)
        setter = f"set_{name}"
        if setter not in methods:
            raise GRVariableError(
                message=f"Variable '{name}' is not settable — 'set_{name}' not found.",
                suggestion="Call gnuradio_list_variables to see available variable names.",
            )

        # Read previous value
        previous_value = None
        getter = f"get_{name}"
        if getter in methods:
            try:
                previous_value = call_rpc(getter, settings=settings)
            except GNURadioError:
                pass

        # Set new value
        call_rpc(setter, value, settings=settings)

        return _json_response({
            "ok": True,
            "name": name,
            "previous_value": previous_value,
            "new_value": value,
        })
    except GNURadioError as exc:
        return _error_response(exc)


# ---------------------------------------------------------------------------
# Tool 08 — gnuradio_get_variable
# ---------------------------------------------------------------------------

@mcp.tool(
    name="gnuradio_get_variable",
    annotations={
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def gnuradio_get_variable(name: str) -> str:
    """Read an arbitrary flowgraph variable via XML-RPC.

    Args:
        name: Flowgraph variable name to read.

    Returns:
        JSON with ``{name, value, type}``.
    """
    try:
        methods = list_methods(settings)
        getter = f"get_{name}"
        if getter not in methods:
            raise GRVariableError(
                message=f"Variable '{name}' is not readable — 'get_{name}' not found.",
                suggestion="Call gnuradio_list_variables to see available variable names.",
            )

        value = call_rpc(getter, settings=settings)
        return _json_response({
            "name": name,
            "value": value,
            "type": type(value).__name__,
        })
    except GNURadioError as exc:
        return _error_response(exc)


# ---------------------------------------------------------------------------
# Tool 09 — gnuradio_list_variables
# ---------------------------------------------------------------------------

@mcp.tool(
    name="gnuradio_list_variables",
    annotations={
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def gnuradio_list_variables() -> str:
    """List all flowgraph variables accessible via XML-RPC.

    Returns:
        JSON with ``{count, variables: [{name, value, setter_available}]}``.
    """
    try:
        methods = list_methods(settings)

        # Variables are those with get_ prefix
        getters = [m for m in methods if m.startswith("get_")]
        variables: list[dict] = []

        for getter in getters:
            var_name = getter[4:]  # strip "get_"
            setter_name = f"set_{var_name}"

            value = None
            try:
                value = call_rpc(getter, settings=settings)
            except GNURadioError:
                pass

            variables.append({
                "name": var_name,
                "value": value,
                "setter_available": setter_name in methods,
            })

        return _json_response({
            "count": len(variables),
            "variables": variables,
        })
    except GNURadioError as exc:
        return _error_response(exc)


# ---------------------------------------------------------------------------
# Tool 10 — gnuradio_capture_samples
# ---------------------------------------------------------------------------

@mcp.tool(
    name="gnuradio_capture_samples",
    annotations={
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": False,
        "openWorldHint": False,
    },
)
async def gnuradio_capture_samples(n_samples: int = 4096) -> str:
    """Capture IQ samples and return a summary (never raw floats).

    Args:
        n_samples: Number of IQ samples to capture (256–1048576).
            Default 4096. Warns above 65536 about large context size.

    Returns:
        JSON summary with mean/peak power, RMS amplitude, timestamp.
    """
    try:
        result: dict[str, Any] = {}

        if n_samples > 65536:
            result["warning"] = (
                "Large capture — response may be truncated in LLM context. "
                "Consider gnuradio_get_spectrum_snapshot instead."
            )

        iq = await recv_samples(n_samples, settings)

        # Read current center freq
        center_freq = 0.0
        try:
            center_freq = float(call_rpc("get_freq", settings=settings))
        except GNURadioError:
            pass

        # Read current sample rate
        samp_rate = settings.default_samp_rate
        try:
            samp_rate = float(call_rpc("get_samp_rate", settings=settings))
        except GNURadioError:
            pass

        # Compute statistics — no raw IQ in response
        power = np.abs(iq) ** 2
        mean_power_w = float(np.mean(power))
        peak_power_w = float(np.max(power))
        rms_amp = float(np.sqrt(mean_power_w))

        # Convert to dBm (50 Ω assumed)
        mean_power_dbm = 10.0 * np.log10(max(mean_power_w, 1e-30)) + 30.0
        peak_power_dbm = 10.0 * np.log10(max(peak_power_w, 1e-30)) + 30.0

        result.update({
            "n_samples": n_samples,
            "center_freq_hz": center_freq,
            "samp_rate": samp_rate,
            "mean_power_dbm": round(float(mean_power_dbm), 1),
            "peak_power_dbm": round(float(peak_power_dbm), 1),
            "rms_amplitude": round(rms_amp, 6),
            "timestamp_utc": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        })

        return _json_response(result)
    except GNURadioError as exc:
        return _error_response(exc)


# ---------------------------------------------------------------------------
# Tool 11 — gnuradio_get_spectrum_snapshot
# ---------------------------------------------------------------------------

@mcp.tool(
    name="gnuradio_get_spectrum_snapshot",
    annotations={
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": False,
        "openWorldHint": False,
    },
)
async def gnuradio_get_spectrum_snapshot(
    fft_size: int = 1024,
    top_n: int = 5,
    n_samples: int = 8192,
    response_format: str = "markdown",
) -> str:
    """Capture IQ samples, compute PSD, and return peak analysis.

    Args:
        fft_size: FFT size (64–65536, power of 2). Default 1024.
        top_n: Number of strongest peaks (1–20). Default 5.
        n_samples: Samples to capture before FFT (1024–131072). Default 8192.
        response_format: 'markdown' (default) or 'json'.

    Returns:
        Spectrum snapshot with peaks in Markdown or JSON format.
    """
    try:
        iq = await recv_samples(n_samples, settings)

        # Get current center freq
        center_freq = 0.0
        freq_note = ""
        try:
            center_freq = float(call_rpc("get_freq", settings=settings))
        except GNURadioError:
            freq_note = " (center freq unknown — using 0 Hz)"

        samp_rate = settings.default_samp_rate
        try:
            samp_rate = float(call_rpc("get_samp_rate", settings=settings))
        except GNURadioError:
            pass

        freqs_hz, psd_dbm = compute_psd(iq, fft_size, samp_rate, center_freq)
        peaks = find_peaks(freqs_hz, psd_dbm, top_n)
        noise_floor = estimate_noise_floor(psd_dbm)

        if response_format == "json":
            return _json_response({
                "center_freq_hz": center_freq,
                "center_freq_readable": hz_to_readable(center_freq),
                "samp_rate": samp_rate,
                "fft_size": fft_size,
                "noise_floor_dbm": round(noise_floor, 1),
                "peaks": peaks,
            })

        # Markdown format
        lines = [
            f"## Spectrum Snapshot @ {hz_to_readable(center_freq)}{freq_note}",
            f"Sample rate : {sps_to_readable(samp_rate)}",
            f"FFT size    : {fft_size}",
            f"Noise floor : {db_to_str(noise_floor)}",
            "",
        ]

        if peaks:
            lines.append(f"### Top {len(peaks)} Peaks")
            lines.append("| # | Frequency | Power | Bandwidth |")
            lines.append("|---|-----------|-------|-----------|")
            for i, p in enumerate(peaks, 1):
                lines.append(
                    f"| {i} | {hz_to_readable(p['freq_hz'])} "
                    f"| {db_to_str(p['power_dbm'])} "
                    f"| {hz_to_readable(p['bandwidth_hz'])} |"
                )
        else:
            lines.append("_No peaks detected above noise floor._")

        return "\n".join(lines)
    except GNURadioError as exc:
        return _error_response(exc)


# ---------------------------------------------------------------------------
# Tool 12 — gnuradio_detect_signals
# ---------------------------------------------------------------------------

@mcp.tool(
    name="gnuradio_detect_signals",
    annotations={
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": False,
        "openWorldHint": False,
    },
)
async def gnuradio_detect_signals(
    freq_start_hz: float,
    freq_end_hz: float,
    step_hz: float = 1e6,
    dwell_ms: int = 50,
    threshold_dbm: float = -70.0,
    ctx: Context | None = None,
) -> str:
    """Sweep a frequency range and detect active signals.

    This is the most complex tool — it tunes to each frequency, dwells,
    captures samples, and checks for signals above the threshold.

    Args:
        freq_start_hz: Sweep start frequency in Hz. e.g. 430e6
        freq_end_hz: Sweep end frequency in Hz. e.g. 440e6
        step_hz: Step size between dwell frequencies. Default 1 MHz.
        dwell_ms: Milliseconds to dwell at each frequency (10–2000). Default 50.
        threshold_dbm: Signals above this power are reported. Default -70.0.
        ctx: MCP Context for progress reporting.

    Returns:
        JSON with sweep results including active signals found.
    """
    try:
        # Validate
        if freq_end_hz <= freq_start_hz:
            raise GRHardwareError(
                message="freq_end_hz must be greater than freq_start_hz",
                suggestion="Swap start and end frequencies.",
            )

        frequencies = np.arange(freq_start_hz, freq_end_hz + step_hz, step_hz)

        if len(frequencies) > 100:
            raise GRHardwareError(
                message=f"Sweep has {len(frequencies)} steps (max 100). Increase step_hz.",
                suggestion=f"Try step_hz={((freq_end_hz - freq_start_hz) / 50):.0f} Hz.",
            )

        # Save original frequency to restore later
        original_freq = None
        try:
            original_freq = call_rpc("get_freq", settings=settings)
        except GNURadioError:
            pass

        samp_rate = settings.default_samp_rate
        try:
            samp_rate = float(call_rpc("get_samp_rate", settings=settings))
        except GNURadioError:
            pass

        active_signals: list[dict] = []
        t_start = time.monotonic()

        for i, freq in enumerate(frequencies):
            freq = float(freq)

            # Report progress
            if ctx is not None:
                try:
                    await ctx.report_progress(
                        progress=i / len(frequencies),
                        total=1.0,
                        message=f"Scanning {hz_to_readable(freq)}",
                    )
                except Exception:
                    pass

            # Tune
            try:
                call_rpc("set_freq", freq, settings=settings)
            except GNURadioError:
                continue

            # Dwell
            await asyncio.sleep(dwell_ms / 1000.0)

            # Capture & analyse
            try:
                iq = await recv_samples(2048, settings)
                freqs_hz, psd_dbm = compute_psd(iq, 1024, samp_rate, freq)
                peaks = find_peaks(freqs_hz, psd_dbm, top_n=1)

                if peaks and peaks[0]["power_dbm"] > threshold_dbm:
                    active_signals.append({
                        "freq_hz": freq,
                        "freq_readable": hz_to_readable(freq),
                        "peak_power_dbm": peaks[0]["power_dbm"],
                    })
            except GNURadioError:
                continue

        scan_duration = time.monotonic() - t_start

        # Restore original frequency
        if original_freq is not None:
            try:
                call_rpc("set_freq", original_freq, settings=settings)
            except GNURadioError:
                pass

        return _json_response({
            "sweep_range": f"{hz_to_readable(freq_start_hz)}–{hz_to_readable(freq_end_hz)}",
            "step_mhz": step_hz / 1e6,
            "dwell_ms": dwell_ms,
            "threshold_dbm": threshold_dbm,
            "active_signals": active_signals,
            "total_steps": len(frequencies),
            "scan_duration_s": round(scan_duration, 2),
        })
    except GNURadioError as exc:
        # Restore frequency even on error
        if original_freq is not None:
            try:
                call_rpc("set_freq", original_freq, settings=settings)
            except GNURadioError:
                pass
        return _error_response(exc)


# ---------------------------------------------------------------------------
# Tool 13 — gnuradio_ping
# ---------------------------------------------------------------------------

@mcp.tool(
    name="gnuradio_ping",
    annotations={
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": True,
        "openWorldHint": False,
    },
)
async def gnuradio_ping() -> str:
    """Lightweight health check — does NOT require flowgraph to be running.

    Attempts XML-RPC connection and ZMQ context creation.
    This tool NEVER raises an exception.

    Returns:
        JSON with ``{xmlrpc_reachable, zmq_context_ok, config}``.
    """
    xmlrpc_reachable = False
    zmq_context_ok = False

    # Test XML-RPC
    try:
        list_methods(settings)
        xmlrpc_reachable = True
    except Exception:
        pass

    # Test ZMQ context
    try:
        zmq_ctx = get_zmq_ctx()
        zmq_context_ok = zmq_ctx is not None and not zmq_ctx.closed
    except Exception:
        pass

    return _json_response({
        "xmlrpc_reachable": xmlrpc_reachable,
        "zmq_context_ok": zmq_context_ok,
        "config": {
            "host": settings.gr_host,
            "xmlrpc_port": settings.gr_xmlrpc_port,
            "zmq_port": settings.gr_zmq_port,
            "hardware": settings.hardware,
            "transport": settings.transport,
        },
    })


# ---------------------------------------------------------------------------
# Main Entry Point
# ---------------------------------------------------------------------------

def main() -> None:
    """Start the MCP server with the configured transport."""
    if settings.transport == "streamable_http":
        mcp.run(transport="streamable-http", port=settings.http_port)
    else:
        mcp.run()  # stdio


if __name__ == "__main__":
    main()
