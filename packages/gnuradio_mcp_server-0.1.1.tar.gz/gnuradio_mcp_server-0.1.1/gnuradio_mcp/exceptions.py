"""Custom exception hierarchy for the GNU Radio MCP Server.

Every exception carries:
- message: str — human-readable, LLM-safe (no stack traces)
- suggestion: str — what to try next
"""


class GNURadioError(Exception):
    """Base exception for all GNU Radio MCP errors."""

    def __init__(self, message: str, suggestion: str = "") -> None:
        self.message = message
        self.suggestion = suggestion
        super().__init__(message)

    def to_dict(self) -> dict:
        """Return a structured error dict suitable for tool responses."""
        d: dict = {"error": True, "message": self.message}
        if self.suggestion:
            d["suggestion"] = self.suggestion
        return d


class GROfflineError(GNURadioError):
    """XML-RPC connection refused or timeout — GNU Radio is not reachable."""
    pass


class GRTimeoutError(GNURadioError):
    """ZMQ recv timeout — no data received within the configured window."""
    pass


class GRVariableError(GNURadioError):
    """Attempted set/get of an unknown flowgraph variable."""
    pass


class GRHardwareError(GNURadioError):
    """Hardware parameter out-of-range or driver failure."""
    pass


class GRFlowgraphError(GNURadioError):
    """Flowgraph in bad state (already running, failed to start, etc.)."""
    pass
