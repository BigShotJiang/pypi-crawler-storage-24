"""Pydantic v2 input/output models for all GNU Radio MCP tools.

Every model uses ``extra='forbid'`` and every Field has ``description=``.
"""

from enum import Enum

from pydantic import BaseModel, ConfigDict, Field


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class GainStage(str, Enum):
    """Gain stage selector for multi-stage SDR front-ends."""

    IF = "if"
    RF = "rf"
    BB = "bb"


class ResponseFormat(str, Enum):
    """Output format selector for tools that support both JSON and Markdown."""

    MARKDOWN = "markdown"
    JSON = "json"


# ---------------------------------------------------------------------------
# Input Models
# ---------------------------------------------------------------------------

class SetFrequencyInput(BaseModel):
    """Input for gnuradio_set_center_frequency."""

    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    frequency_hz: float = Field(
        ...,
        description=(
            "Center frequency in Hz. Examples: 433.92e6 for 433 MHz ISM, "
            "1575.42e6 for GPS L1, 88.5e6 for FM radio."
        ),
    )


class SetSampleRateInput(BaseModel):
    """Input for gnuradio_set_sample_rate."""

    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    samp_rate: float = Field(
        ...,
        description=(
            "Sample rate in samples/sec. HackRF max: 20e6. "
            "RTL-SDR max: ~3.2e6. Example: 2e6 for 2 Msps."
        ),
    )


class SetGainInput(BaseModel):
    """Input for gnuradio_set_gain."""

    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    gain_db: float = Field(
        ...,
        description="Gain in dB. Typical range 0–62 dB.",
    )
    stage: GainStage = Field(
        GainStage.IF,
        description="Gain stage: 'if' (default), 'rf', or 'bb'.",
    )


class SetVariableInput(BaseModel):
    """Input for gnuradio_set_variable."""

    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    name: str = Field(
        ...,
        description=(
            "Flowgraph variable name as exposed by XML-RPC, "
            "e.g. 'freq', 'samp_rate', 'gain'."
        ),
    )
    value: float = Field(..., description="New value to set.")


class GetVariableInput(BaseModel):
    """Input for gnuradio_get_variable."""

    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    name: str = Field(
        ...,
        description="Flowgraph variable name to read.",
    )


class CaptureInput(BaseModel):
    """Input for gnuradio_capture_samples."""

    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    n_samples: int = Field(
        4096,
        ge=256,
        le=1_048_576,
        description=(
            "Number of IQ samples to capture. Must be a power of 2. "
            "Default 4096. Max 1M (warns about large context size above 65536)."
        ),
    )


class SpectrumInput(BaseModel):
    """Input for gnuradio_get_spectrum_snapshot."""

    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    fft_size: int = Field(
        1024,
        ge=64,
        le=65536,
        description="FFT size. Must be power of 2. Default 1024.",
    )
    top_n: int = Field(
        5,
        ge=1,
        le=20,
        description="Number of strongest peaks to return.",
    )
    n_samples: int = Field(
        8192,
        ge=1024,
        le=131072,
        description="IQ samples to capture before FFT. Default 8192.",
    )
    response_format: ResponseFormat = Field(
        ResponseFormat.MARKDOWN,
        description="Output format: 'markdown' (default) or 'json'.",
    )


class SweepInput(BaseModel):
    """Input for gnuradio_detect_signals."""

    model_config = ConfigDict(str_strip_whitespace=True, extra="forbid")

    freq_start_hz: float = Field(
        ...,
        description="Sweep start frequency in Hz. e.g. 430e6",
    )
    freq_end_hz: float = Field(
        ...,
        description="Sweep end frequency in Hz. e.g. 440e6",
    )
    step_hz: float = Field(
        1e6,
        description="Step size between dwell frequencies. Default 1 MHz.",
    )
    dwell_ms: int = Field(
        50,
        ge=10,
        le=2000,
        description="Milliseconds to dwell at each frequency. Default 50ms.",
    )
    threshold_dbm: float = Field(
        -70.0,
        description="Signals above this power level are reported as active.",
    )
