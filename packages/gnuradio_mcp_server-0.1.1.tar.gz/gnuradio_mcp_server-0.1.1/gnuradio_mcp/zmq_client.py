"""Async-safe ZMQ SUB wrapper for receiving IQ samples from GNU Radio.

Uses a thread executor to avoid blocking the asyncio event loop.
A module-level ZMQ Context is initialised once at import time.

Public interface:
    get_context() -> zmq.Context
    recv_samples(n, settings) -> np.ndarray[np.complex64]   (async)
"""

from __future__ import annotations

import asyncio
import logging
from concurrent.futures import ThreadPoolExecutor
from typing import TYPE_CHECKING

import numpy as np
import zmq

from .config import Settings
from .exceptions import GRHardwareError, GRTimeoutError

if TYPE_CHECKING:
    pass

logger = logging.getLogger(__name__)

# Module-level ZMQ Context — created once at import time.
_zmq_ctx: zmq.Context | None = None

# Thread pool for running blocking ZMQ recv in async context
_executor = ThreadPoolExecutor(max_workers=2, thread_name_prefix="zmq_recv")


def get_context() -> zmq.Context:
    """Return the module-level ZMQ Context, creating it on first call."""
    global _zmq_ctx
    if _zmq_ctx is None or _zmq_ctx.closed:
        _zmq_ctx = zmq.Context()
    return _zmq_ctx


def _recv_blocking(n: int, settings: Settings) -> np.ndarray:
    """Blocking ZMQ receive — runs in a thread executor.

    Opens a fresh SUB socket per call, sets RCVTIMEO, subscribes to all
    topics, receives raw bytes, and parses as complex64.
    """
    ctx = get_context()
    sock = ctx.socket(zmq.SUB)
    try:
        sock.setsockopt(zmq.RCVTIMEO, settings.gr_zmq_timeout_ms)
        sock.setsockopt(zmq.SUBSCRIBE, b"")
        sock.setsockopt(zmq.LINGER, 0)
        endpoint = f"tcp://{settings.gr_host}:{settings.gr_zmq_port}"
        sock.connect(endpoint)

        # Accumulate enough bytes for n complex64 samples (8 bytes each)
        needed_bytes = n * 8
        chunks: list[bytes] = []
        total = 0

        while total < needed_bytes:
            try:
                raw = sock.recv()
            except zmq.error.Again as exc:
                raise GRTimeoutError(
                    message=(
                        f"ZMQ receive timed out after {settings.gr_zmq_timeout_ms}ms — "
                        f"no IQ data from tcp://{settings.gr_host}:{settings.gr_zmq_port}"
                    ),
                    suggestion=(
                        "Ensure the GNU Radio flowgraph is running with a ZMQ PUB Sink "
                        f"on port {settings.gr_zmq_port}. Call gnuradio_flowgraph_start first."
                    ),
                ) from exc

            # Validate alignment
            if len(raw) % 8 != 0:
                raise GRHardwareError(
                    message=(
                        f"Misaligned IQ data — received {len(raw)} bytes "
                        f"(not a multiple of 8). Check ZMQ sink dtype."
                    ),
                    suggestion="Ensure the ZMQ PUB Sink is outputting complex64 (8 bytes per sample).",
                )

            chunks.append(raw)
            total += len(raw)

        # Concatenate and parse
        all_bytes = b"".join(chunks)
        samples = np.frombuffer(all_bytes, dtype=np.complex64)

        # Trim or pad to exactly n samples
        if len(samples) >= n:
            return samples[:n]
        else:
            logger.warning(
                "Received %d samples but requested %d — padding with zeros",
                len(samples),
                n,
            )
            padded = np.zeros(n, dtype=np.complex64)
            padded[: len(samples)] = samples
            return padded
    finally:
        sock.close()


async def recv_samples(n: int, settings: Settings) -> np.ndarray:
    """Async interface — captures *n* IQ samples via ZMQ SUB.

    Runs the blocking recv in a thread executor so the asyncio event loop
    is never blocked.

    Args:
        n: Number of complex64 samples to capture.
        settings: Server settings (host, port, timeout).

    Returns:
        numpy array of shape (n,) with dtype complex64.

    Raises:
        GRTimeoutError: No data received within ``settings.gr_zmq_timeout_ms``.
        GRHardwareError: Misaligned IQ data from ZMQ sink.
    """
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(_executor, _recv_blocking, n, settings)
