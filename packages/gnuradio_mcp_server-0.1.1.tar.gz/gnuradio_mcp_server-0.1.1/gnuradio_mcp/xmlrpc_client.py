"""XML-RPC proxy factory and retry logic for communicating with GNU Radio.

Public interface:
    call_rpc(method, *args, settings) -> Any
    list_methods(settings) -> list[str]
"""

from __future__ import annotations

import socket
import xmlrpc.client
from typing import Any

from tenacity import (
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
)

from .config import Settings
from .exceptions import GRFlowgraphError, GROfflineError, GRVariableError


def get_proxy(settings: Settings) -> xmlrpc.client.ServerProxy:
    """Create a **new** ``ServerProxy`` per call (not a shared singleton).

    ``ServerProxy`` is not thread/async safe, so we always create a fresh one.
    """
    url = f"http://{settings.gr_host}:{settings.gr_xmlrpc_port}"
    transport = xmlrpc.client.Transport()
    transport.timeout = settings.gr_xmlrpc_timeout  # type: ignore[attr-defined]
    return xmlrpc.client.ServerProxy(url, transport=transport, allow_none=True)


# Session-level cache for list_methods
_methods_cache: list[str] | None = None


def _clear_methods_cache() -> None:
    """Clear the method cache (useful for tests)."""
    global _methods_cache
    _methods_cache = None


@retry(
    stop=stop_after_attempt(3),
    wait=wait_exponential(multiplier=0.3, min=0.3, max=2),
    retry=retry_if_exception_type(GROfflineError),
    reraise=True,
)
def _call_rpc_inner(method: str, *args: Any, settings: Settings) -> Any:
    """Execute a single XML-RPC call with error translation."""
    proxy = get_proxy(settings)
    try:
        func = getattr(proxy, method)
        return func(*args)
    except ConnectionRefusedError as exc:
        raise GROfflineError(
            message=f"Cannot connect to GNU Radio XML-RPC at "
                    f"{settings.gr_host}:{settings.gr_xmlrpc_port}",
            suggestion=(
                f"Ensure GNU Radio flowgraph is running with an XMLRPC Server "
                f"block on port {settings.gr_xmlrpc_port}."
            ),
        ) from exc
    except (socket.timeout, TimeoutError) as exc:
        raise GROfflineError(
            message=f"XML-RPC connection timed out after {settings.gr_xmlrpc_timeout}s",
            suggestion=(
                f"Ensure GNU Radio flowgraph is running with an XMLRPC Server "
                f"block on port {settings.gr_xmlrpc_port}."
            ),
        ) from exc
    except xmlrpc.client.Fault as exc:
        # Fault usually means the method exists but the call failed
        if "method" in str(exc).lower() and "not found" in str(exc).lower():
            raise GRVariableError(
                message=f"XML-RPC method '{method}' not found on the flowgraph",
                suggestion="Call gnuradio_list_variables to see available variable names.",
            ) from exc
        raise GROfflineError(
            message=f"XML-RPC fault: {exc.faultString}",
            suggestion="Check that the flowgraph is in a valid state.",
        ) from exc
    except xmlrpc.client.Error as exc:
        raise GRFlowgraphError(
            message=f"XML-RPC error: {exc}",
            suggestion="Check GNU Radio flowgraph state and XML-RPC configuration.",
        ) from exc
    except OSError as exc:
        raise GROfflineError(
            message=f"Network error reaching GNU Radio: {exc}",
            suggestion=(
                f"Ensure GNU Radio flowgraph is running with an XMLRPC Server "
                f"block on port {settings.gr_xmlrpc_port}."
            ),
        ) from exc


def call_rpc(method: str, *args: Any, settings: Settings) -> Any:
    """Single public interface: proxy lookup + call + error translation.

    Retries up to 3 times with exponential backoff on ``GROfflineError``.
    Does NOT retry ``GRVariableError``.
    """
    return _call_rpc_inner(method, *args, settings=settings)


def list_methods(settings: Settings) -> list[str]:
    """List all XML-RPC methods exposed by the flowgraph.

    Results are cached for the session. Call ``_clear_methods_cache()``
    to force a refresh.
    """
    global _methods_cache
    if _methods_cache is not None:
        return _methods_cache

    try:
        result = call_rpc("system.listMethods", settings=settings)
        _methods_cache = list(result) if result else []
        return _methods_cache
    except GROfflineError:
        raise
    except Exception as exc:
        raise GRFlowgraphError(
            message=f"Failed to list XML-RPC methods: {exc}",
            suggestion="Check that the flowgraph has an XMLRPC Server block.",
        ) from exc
