"""Shared helper utilities for the GNU Radio MCP Server."""

from __future__ import annotations


def hz_to_readable(hz: float) -> str:
    """Convert a frequency in Hz to a human-readable string.

    Examples:
        433920000  → '433.920 MHz'
        1575420000 → '1575.420 MHz'
        2400000    → '2.400 MHz'
        500        → '500.000 Hz'
    """
    abs_hz = abs(hz)
    if abs_hz >= 1e9:
        return f"{hz / 1e9:.3f} GHz"
    if abs_hz >= 1e6:
        return f"{hz / 1e6:.3f} MHz"
    if abs_hz >= 1e3:
        return f"{hz / 1e3:.3f} kHz"
    return f"{hz:.3f} Hz"


def format_freq(hz: float) -> str:
    """Alias for :func:`hz_to_readable`."""
    return hz_to_readable(hz)


def db_to_str(db: float) -> str:
    """Format a dBm value for display.

    Example: -42.345 → '-42.3 dBm'
    """
    return f"{db:.1f} dBm"


def sps_to_readable(sps: float) -> str:
    """Convert a sample rate in samples/sec to a readable string.

    Example: 2000000 → '2.000 Msps'
    """
    if sps >= 1e6:
        return f"{sps / 1e6:.3f} Msps"
    if sps >= 1e3:
        return f"{sps / 1e3:.3f} ksps"
    return f"{sps:.0f} sps"
