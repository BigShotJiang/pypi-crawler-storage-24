"""Configuration for the GNU Radio MCP Server.

All values overridable via GNURADIO_* environment variables.
Defaults work with simulation_mcp.grc on localhost.
"""

from pydantic import Field
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """GNU Radio MCP Server settings.

    Every field can be overridden by setting the corresponding environment
    variable with the ``GNURADIO_`` prefix, e.g. ``GNURADIO_GR_HOST=192.168.1.10``.
    """

    model_config = {"env_prefix": "GNURADIO_", "env_file": ".env"}

    # -- Network --
    gr_host: str = Field("127.0.0.1", description="GNU Radio host")
    gr_xmlrpc_port: int = Field(8080, description="XML-RPC port")
    gr_zmq_port: int = Field(5555, description="ZMQ PUB port")
    gr_xmlrpc_timeout: int = Field(5, description="XML-RPC timeout (s)")
    gr_zmq_timeout_ms: int = Field(3000, description="ZMQ RCVTIMEO (ms)")

    # -- Hardware limits (used for input validation) --
    hardware: str = Field(
        "hackrf",
        description="Hardware type: hackrf | rtlsdr | usrp | simulation",
    )
    freq_min_hz: float = Field(1e6, description="Min tunable frequency (Hz)")
    freq_max_hz: float = Field(6e9, description="Max tunable frequency (Hz)")
    gain_min_db: float = Field(0.0, description="Min gain (dB)")
    gain_max_db: float = Field(62.0, description="Max gain (dB)")
    samp_rate_min: float = Field(1e5, description="Min sample rate (sps)")
    samp_rate_max: float = Field(20e6, description="Max sample rate (sps)")
    default_samp_rate: float = Field(2e6, description="Assumed samp_rate for DSP")

    # -- Transport --
    transport: str = Field(
        "stdio",
        description="MCP transport: stdio | streamable_http",
    )
    http_port: int = Field(8000, description="Port for HTTP transport")
