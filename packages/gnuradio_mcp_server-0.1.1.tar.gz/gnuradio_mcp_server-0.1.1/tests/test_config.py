"""Tests for config.py — env-var overrides and bounds validation."""

import os

import pytest


class TestSettings:
    """Test Settings class."""

    def test_defaults(self):
        """Default settings should work for simulation on localhost."""
        from gnuradio_mcp.config import Settings

        s = Settings()
        assert s.gr_host == "127.0.0.1"
        assert s.gr_xmlrpc_port == 8080
        assert s.gr_zmq_port == 5555
        assert s.hardware == "hackrf"
        assert s.transport == "stdio"
        assert s.default_samp_rate == 2e6
        assert s.freq_min_hz == 1e6
        assert s.freq_max_hz == 6e9

    def test_env_override(self, monkeypatch):
        """Environment variables with GNURADIO_ prefix should override defaults."""
        monkeypatch.setenv("GNURADIO_GR_HOST", "192.168.1.100")
        monkeypatch.setenv("GNURADIO_GR_XMLRPC_PORT", "9090")
        monkeypatch.setenv("GNURADIO_HARDWARE", "rtlsdr")
        monkeypatch.setenv("GNURADIO_TRANSPORT", "streamable_http")

        from gnuradio_mcp.config import Settings

        s = Settings()
        assert s.gr_host == "192.168.1.100"
        assert s.gr_xmlrpc_port == 9090
        assert s.hardware == "rtlsdr"
        assert s.transport == "streamable_http"

    def test_freq_bounds(self):
        """Frequency bounds should be configurable."""
        from gnuradio_mcp.config import Settings

        s = Settings(freq_min_hz=24e6, freq_max_hz=1766e6)
        assert s.freq_min_hz == 24e6
        assert s.freq_max_hz == 1766e6

    def test_gain_bounds(self):
        """Gain bounds should be configurable."""
        from gnuradio_mcp.config import Settings

        s = Settings(gain_min_db=0.0, gain_max_db=49.6)
        assert s.gain_min_db == 0.0
        assert s.gain_max_db == 49.6

    def test_sample_rate_bounds(self):
        """Sample rate bounds should be configurable."""
        from gnuradio_mcp.config import Settings

        s = Settings(samp_rate_min=2e5, samp_rate_max=3.2e6)
        assert s.samp_rate_min == 2e5
        assert s.samp_rate_max == 3.2e6
