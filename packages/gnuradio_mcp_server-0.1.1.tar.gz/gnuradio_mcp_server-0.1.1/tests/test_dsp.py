"""Tests for dsp.py — FFT correctness, peak detection accuracy."""

import numpy as np
import pytest

from gnuradio_mcp.dsp import (
    compute_psd,
    db_to_mw,
    estimate_noise_floor,
    find_peaks,
    hz_to_readable,
)


class TestComputePsd:
    """Test PSD computation."""

    def _make_tone(self, freq_offset: float, samp_rate: float = 2e6, n: int = 8192):
        """Create a complex tone at a given offset from center."""
        t = np.arange(n) / samp_rate
        return (0.5 * np.exp(2j * np.pi * freq_offset * t)).astype(np.complex64)

    def test_output_shape(self):
        """PSD output should match fft_size."""
        iq = self._make_tone(10e3)
        freqs, psd = compute_psd(iq, 1024, 2e6, 100e6)
        assert len(freqs) == 1024
        assert len(psd) == 1024

    def test_peak_at_expected_frequency(self):
        """Strongest PSD bin should be near the tone frequency."""
        iq = self._make_tone(10e3, samp_rate=2e6, n=8192)
        freqs, psd = compute_psd(iq, 1024, 2e6, 100e6)
        peak_idx = np.argmax(psd)
        peak_freq = freqs[peak_idx]
        # Should be within a few bins of 100.010 MHz
        assert abs(peak_freq - 100.010e6) < 5e3

    def test_welch_used_for_long_signals(self):
        """Welch's method should be used when len(iq) >= 8*fft_size."""
        iq = self._make_tone(10e3, n=16384)
        freqs, psd = compute_psd(iq, 1024, 2e6, 100e6)
        assert len(freqs) == 1024

    def test_single_fft_for_short_signals(self):
        """Single FFT should be used for short signals."""
        iq = self._make_tone(10e3, n=1024)
        freqs, psd = compute_psd(iq, 1024, 2e6, 100e6)
        assert len(freqs) == 1024


class TestFindPeaks:
    """Test peak detection."""

    def test_finds_strong_peak(self):
        """Should find at least one peak for a tone."""
        samp_rate = 2e6
        t = np.arange(8192) / samp_rate
        iq = (0.5 * np.exp(2j * np.pi * 10e3 * t)).astype(np.complex64)
        freqs, psd = compute_psd(iq, 1024, samp_rate, 100e6)
        peaks = find_peaks(freqs, psd, top_n=5)
        assert len(peaks) >= 1
        assert peaks[0]["power_dbm"] > -100  # should be a real signal

    def test_finds_two_tones(self):
        """Should find two peaks for two tones."""
        samp_rate = 2e6
        t = np.arange(8192) / samp_rate
        iq = (
            0.5 * np.exp(2j * np.pi * 10e3 * t)
            + 0.3 * np.exp(2j * np.pi * 50e3 * t)
        ).astype(np.complex64)
        freqs, psd = compute_psd(iq, 1024, samp_rate, 100e6)
        peaks = find_peaks(freqs, psd, top_n=5, min_distance_hz=20e3)
        assert len(peaks) >= 2

    def test_sorted_by_power(self):
        """Peaks should be sorted by power descending."""
        samp_rate = 2e6
        t = np.arange(8192) / samp_rate
        iq = (
            0.5 * np.exp(2j * np.pi * 10e3 * t)
            + 0.1 * np.exp(2j * np.pi * 50e3 * t)
        ).astype(np.complex64)
        freqs, psd = compute_psd(iq, 1024, samp_rate, 100e6)
        peaks = find_peaks(freqs, psd, top_n=5, min_distance_hz=20e3)
        if len(peaks) >= 2:
            assert peaks[0]["power_dbm"] >= peaks[1]["power_dbm"]

    def test_bandwidth_positive(self):
        """Bandwidth should be positive."""
        samp_rate = 2e6
        t = np.arange(8192) / samp_rate
        iq = (0.5 * np.exp(2j * np.pi * 10e3 * t)).astype(np.complex64)
        freqs, psd = compute_psd(iq, 1024, samp_rate, 100e6)
        peaks = find_peaks(freqs, psd, top_n=1)
        if peaks:
            assert peaks[0]["bandwidth_hz"] > 0


class TestEstimateNoiseFloor:
    """Test noise floor estimation."""

    def test_noise_floor_below_signal(self):
        """Noise floor should be well below the signal peak."""
        samp_rate = 2e6
        t = np.arange(8192) / samp_rate
        iq = (
            0.5 * np.exp(2j * np.pi * 10e3 * t)
            + 0.01 * (np.random.randn(8192) + 1j * np.random.randn(8192))
        ).astype(np.complex64)
        freqs, psd = compute_psd(iq, 1024, samp_rate, 100e6)
        noise_floor = estimate_noise_floor(psd)
        peak_power = float(np.max(psd))
        assert noise_floor < peak_power - 10  # at least 10 dB below


class TestHelpers:
    """Test helper functions."""

    def test_db_to_mw_zero(self):
        """0 dBm = 1 mW."""
        assert abs(db_to_mw(0) - 1.0) < 1e-10

    def test_db_to_mw_negative(self):
        """-30 dBm = 0.001 mW."""
        assert abs(db_to_mw(-30) - 0.001) < 1e-6

    def test_hz_to_readable_mhz(self):
        """Should format MHz correctly."""
        assert hz_to_readable(433920000) == "433.920 MHz"

    def test_hz_to_readable_ghz(self):
        """Should format GHz correctly."""
        assert hz_to_readable(2.4e9) == "2.400 GHz"

    def test_hz_to_readable_khz(self):
        """Should format kHz correctly."""
        assert hz_to_readable(10e3) == "10.000 kHz"
