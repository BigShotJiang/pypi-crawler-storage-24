"""Tests for zmq_client.py — sample capture, dtype handling, timeout."""

import numpy as np
import pytest

from gnuradio_mcp.config import Settings
from gnuradio_mcp.exceptions import GRTimeoutError
from gnuradio_mcp.zmq_client import recv_samples, get_context


@pytest.mark.asyncio
class TestRecvSamples:
    """Test recv_samples with mock ZMQ publisher."""

    async def test_capture_returns_correct_count(self, mock_settings):
        """Should return exactly the requested number of samples."""
        samples = await recv_samples(1024, mock_settings)
        assert len(samples) == 1024
        assert samples.dtype == np.complex64

    async def test_capture_non_zero(self, mock_settings):
        """Captured samples should not be all zeros (mock publishes tones)."""
        samples = await recv_samples(2048, mock_settings)
        assert np.any(samples != 0)

    async def test_timeout_on_dead_port(self):
        """Should raise GRTimeoutError when no ZMQ publisher is running."""
        dead_settings = Settings(
            gr_host="127.0.0.1",
            gr_zmq_port=19998,
            gr_zmq_timeout_ms=500,
        )
        with pytest.raises(GRTimeoutError):
            await recv_samples(256, dead_settings)


class TestGetContext:
    """Test ZMQ context management."""

    def test_get_context_returns_valid(self):
        """Should return a valid ZMQ context."""
        ctx = get_context()
        assert ctx is not None
        assert not ctx.closed
