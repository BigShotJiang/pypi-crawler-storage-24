"""End-to-end tool tests via mock servers.

Tests the MCP tool functions directly (not via MCP protocol transport).
"""

from __future__ import annotations

import json
from unittest.mock import patch

import pytest

from gnuradio_mcp.xmlrpc_client import _clear_methods_cache


def _patch_settings(mock_settings):
    """Return a patch context manager that replaces the server module's settings."""
    return patch("gnuradio_mcp.server.settings", mock_settings)


@pytest.mark.asyncio
class TestPing:
    """Test gnuradio_ping tool."""

    async def test_ping_reachable(self, mock_settings):
        """Should return xmlrpc_reachable=True when mock is running."""
        from gnuradio_mcp.server import gnuradio_ping

        _clear_methods_cache()
        with _patch_settings(mock_settings):
            result = json.loads(await gnuradio_ping())
        assert result["xmlrpc_reachable"] is True
        assert result["zmq_context_ok"] is True

    async def test_ping_unreachable(self):
        """Should return xmlrpc_reachable=False when mock is NOT running."""
        from gnuradio_mcp.config import Settings
        from gnuradio_mcp.server import gnuradio_ping

        _clear_methods_cache()
        dead_settings = Settings(
            gr_host="127.0.0.1",
            gr_xmlrpc_port=19999,
            gr_xmlrpc_timeout=1,
            gr_zmq_port=19998,
        )
        with _patch_settings(dead_settings):
            result = json.loads(await gnuradio_ping())
        assert result["xmlrpc_reachable"] is False

    async def test_ping_never_raises(self):
        """gnuradio_ping should NEVER raise an exception."""
        from gnuradio_mcp.config import Settings
        from gnuradio_mcp.server import gnuradio_ping

        _clear_methods_cache()
        dead_settings = Settings(
            gr_host="127.0.0.1",
            gr_xmlrpc_port=19999,
            gr_xmlrpc_timeout=1,
        )
        with _patch_settings(dead_settings):
            result_str = await gnuradio_ping()
        # Should not raise, should return valid JSON
        result = json.loads(result_str)
        assert isinstance(result, dict)


@pytest.mark.asyncio
class TestFlowgraphStatus:
    """Test gnuradio_flowgraph_status tool."""

    async def test_status_running(self, mock_settings):
        """Should return running=True with mock running."""
        from gnuradio_mcp.server import gnuradio_flowgraph_status

        _clear_methods_cache()
        with _patch_settings(mock_settings):
            result = json.loads(await gnuradio_flowgraph_status())
        assert result["running"] is True


@pytest.mark.asyncio
class TestSetCenterFrequency:
    """Test gnuradio_set_center_frequency tool."""

    async def test_set_in_range(self, mock_settings):
        """Should succeed for in-range frequency."""
        from gnuradio_mcp.server import gnuradio_set_center_frequency

        _clear_methods_cache()
        with _patch_settings(mock_settings):
            result = json.loads(await gnuradio_set_center_frequency(433.92e6))
        assert result["ok"] is True
        assert result["requested_hz"] == 433.92e6

    async def test_set_out_of_range(self, mock_settings):
        """Should return error for out-of-range frequency."""
        from gnuradio_mcp.server import gnuradio_set_center_frequency

        _clear_methods_cache()
        with _patch_settings(mock_settings):
            result = json.loads(await gnuradio_set_center_frequency(100e12))
        assert result.get("error") is True


@pytest.mark.asyncio
class TestListVariables:
    """Test gnuradio_list_variables tool."""

    async def test_list_variables(self, mock_settings):
        """Should return freq, samp_rate, gain."""
        from gnuradio_mcp.server import gnuradio_list_variables

        _clear_methods_cache()
        with _patch_settings(mock_settings):
            result = json.loads(await gnuradio_list_variables())
        var_names = [v["name"] for v in result["variables"]]
        assert "freq" in var_names
        assert "samp_rate" in var_names
        assert "gain" in var_names


@pytest.mark.asyncio
class TestSetVariable:
    """Test gnuradio_set_variable tool."""

    async def test_set_existing(self, mock_settings):
        """Should succeed for existing variable."""
        from gnuradio_mcp.server import gnuradio_set_variable

        _clear_methods_cache()
        with _patch_settings(mock_settings):
            result = json.loads(await gnuradio_set_variable("freq", 100e6))
        assert result["ok"] is True

    async def test_set_nonexistent(self, mock_settings):
        """Should return error for nonexistent variable."""
        from gnuradio_mcp.server import gnuradio_set_variable

        _clear_methods_cache()
        with _patch_settings(mock_settings):
            result = json.loads(await gnuradio_set_variable("nonexistent", 1.0))
        assert result.get("error") is True


@pytest.mark.asyncio
class TestGetSpectrumSnapshot:
    """Test gnuradio_get_spectrum_snapshot tool."""

    async def test_snapshot_has_peaks(self, mock_settings):
        """Should return at least 1 peak with mock ZMQ data."""
        from gnuradio_mcp.server import gnuradio_get_spectrum_snapshot

        _clear_methods_cache()
        with _patch_settings(mock_settings):
            result = json.loads(
                await gnuradio_get_spectrum_snapshot(
                    fft_size=1024, top_n=5, n_samples=4096, response_format="json"
                )
            )
        assert len(result["peaks"]) >= 1


@pytest.mark.asyncio
class TestCaptureSamples:
    """Test gnuradio_capture_samples tool."""

    async def test_capture_returns_summary(self, mock_settings):
        """Should return a summary dict, not raw IQ."""
        from gnuradio_mcp.server import gnuradio_capture_samples

        _clear_methods_cache()
        with _patch_settings(mock_settings):
            result = json.loads(await gnuradio_capture_samples(n_samples=1024))
        assert "n_samples" in result
        assert "mean_power_dbm" in result
        assert "peak_power_dbm" in result
        assert "rms_amplitude" in result
        # Should NOT contain raw IQ data
        assert "iq" not in result
        assert "samples" not in result
