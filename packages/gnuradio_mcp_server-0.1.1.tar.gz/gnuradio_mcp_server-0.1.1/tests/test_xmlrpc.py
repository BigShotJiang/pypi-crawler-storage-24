"""Tests for xmlrpc_client.py — proxy factory, retry, offline behaviour."""

import pytest

from gnuradio_mcp.config import Settings
from gnuradio_mcp.exceptions import GROfflineError
from gnuradio_mcp.xmlrpc_client import call_rpc, list_methods, _clear_methods_cache


class TestCallRpc:
    """Test call_rpc with mock XML-RPC server."""

    def test_get_freq(self, mock_settings):
        """Should read the current frequency from the mock server."""
        _clear_methods_cache()
        result = call_rpc("get_freq", settings=mock_settings)
        assert result == 100e6

    def test_set_freq(self, mock_settings):
        """Should set and return the new frequency."""
        _clear_methods_cache()
        call_rpc("set_freq", 433.92e6, settings=mock_settings)
        result = call_rpc("get_freq", settings=mock_settings)
        assert result == 433.92e6

    def test_get_samp_rate(self, mock_settings):
        """Should read the current sample rate."""
        _clear_methods_cache()
        result = call_rpc("get_samp_rate", settings=mock_settings)
        assert result == 2e6

    def test_offline_raises(self):
        """Should raise GROfflineError when server is not running."""
        _clear_methods_cache()
        offline_settings = Settings(
            gr_host="127.0.0.1",
            gr_xmlrpc_port=19999,  # unlikely to be running
            gr_xmlrpc_timeout=1,
        )
        with pytest.raises(GROfflineError):
            call_rpc("get_freq", settings=offline_settings)


class TestListMethods:
    """Test list_methods with mock XML-RPC server."""

    def test_list_methods(self, mock_settings):
        """Should return a list of method names from the mock server."""
        _clear_methods_cache()
        methods = list_methods(mock_settings)
        assert isinstance(methods, list)
        assert "get_freq" in methods
        assert "set_freq" in methods
        assert "get_samp_rate" in methods

    def test_list_methods_cached(self, mock_settings):
        """Second call should use cache."""
        _clear_methods_cache()
        methods1 = list_methods(mock_settings)
        methods2 = list_methods(mock_settings)
        assert methods1 == methods2

    def test_list_methods_offline(self):
        """Should raise GROfflineError when server is not running."""
        _clear_methods_cache()
        offline_settings = Settings(
            gr_host="127.0.0.1",
            gr_xmlrpc_port=19999,
            gr_xmlrpc_timeout=1,
        )
        with pytest.raises(GROfflineError):
            list_methods(offline_settings)
