"""Pytest fixtures for GNU Radio MCP Server tests.

Provides:
    - mock_xmlrpc_server: SimpleXMLRPCServer with standard flowgraph methods
    - mock_zmq_pub: ZMQ PUB socket publishing synthetic IQ data
    - mock_settings: Settings instance pointing to mock server ports
"""

from __future__ import annotations

import threading
import time
from xmlrpc.server import SimpleXMLRPCServer

import numpy as np
import pytest
import zmq


# ---------------------------------------------------------------------------
# Mock XML-RPC Server
# ---------------------------------------------------------------------------

class MockFlowgraph:
    """Simulates a GNU Radio flowgraph's XML-RPC interface."""

    def __init__(self) -> None:
        self._freq: float = 100e6
        self._samp_rate: float = 2e6
        self._gain: float = 30.0
        self._running: bool = True

    def run(self) -> bool:
        self._running = True
        return True

    def stop(self) -> bool:
        self._running = False
        return True

    def get_freq(self) -> float:
        return self._freq

    def set_freq(self, v: float) -> float:
        self._freq = float(v)
        return self._freq

    def get_samp_rate(self) -> float:
        return self._samp_rate

    def set_samp_rate(self, v: float) -> float:
        self._samp_rate = float(v)
        return self._samp_rate

    def get_gain(self) -> float:
        return self._gain

    def set_gain(self, v: float) -> float:
        self._gain = float(v)
        return self._gain


@pytest.fixture()
def mock_xmlrpc_server():
    """Spin up a SimpleXMLRPCServer on a random port with flowgraph methods.

    Yields (host, port).
    """
    fg = MockFlowgraph()
    server = SimpleXMLRPCServer(("127.0.0.1", 0), logRequests=False, allow_none=True)
    server.register_instance(fg)
    server.register_introspection_functions()

    host, port = server.server_address
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()

    yield (host, port)

    server.shutdown()
    server.server_close()


# ---------------------------------------------------------------------------
# Mock ZMQ PUB Publisher
# ---------------------------------------------------------------------------

@pytest.fixture()
def mock_zmq_pub():
    """Open a ZMQ PUB socket and publish synthetic IQ data.

    Yields the port number.
    """
    ctx = zmq.Context()
    sock = ctx.socket(zmq.PUB)
    sock.setsockopt(zmq.LINGER, 0)
    port = sock.bind_to_random_port("tcp://127.0.0.1")

    stop_event = threading.Event()

    def publisher():
        samp_rate = 2e6
        t = np.arange(4096) / samp_rate
        # Tone at 10 kHz + small noise
        tone_10k = 0.5 * np.exp(2j * np.pi * 10e3 * t).astype(np.complex64)
        tone_50k = 0.3 * np.exp(2j * np.pi * 50e3 * t).astype(np.complex64)
        noise = 0.01 * (np.random.randn(4096) + 1j * np.random.randn(4096)).astype(np.complex64)
        iq = tone_10k + tone_50k + noise

        while not stop_event.is_set():
            sock.send(iq.tobytes())
            time.sleep(0.01)

    thread = threading.Thread(target=publisher, daemon=True)
    thread.start()

    # Give publisher time to start
    time.sleep(0.1)

    yield port

    stop_event.set()
    thread.join(timeout=2)
    sock.close()
    ctx.term()


# ---------------------------------------------------------------------------
# Mock Settings
# ---------------------------------------------------------------------------

@pytest.fixture()
def mock_settings(mock_xmlrpc_server, mock_zmq_pub):
    """Return a Settings instance pointing to the mock servers."""
    from gnuradio_mcp.config import Settings

    host, xmlrpc_port = mock_xmlrpc_server
    zmq_port = mock_zmq_pub

    return Settings(
        gr_host=host,
        gr_xmlrpc_port=xmlrpc_port,
        gr_zmq_port=zmq_port,
        gr_xmlrpc_timeout=5,
        gr_zmq_timeout_ms=3000,
        hardware="simulation",
        freq_min_hz=1e6,
        freq_max_hz=6e9,
        gain_min_db=0.0,
        gain_max_db=62.0,
        samp_rate_min=1e5,
        samp_rate_max=20e6,
        default_samp_rate=2e6,
        transport="stdio",
    )
