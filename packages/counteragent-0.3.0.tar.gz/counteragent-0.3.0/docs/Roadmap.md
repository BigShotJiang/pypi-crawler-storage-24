## Vision
An offensive security suite for Agentic AI — a complete research program and toolkit for testing attack chains targeting autonomous AI agents, with proof-of-exploitation and practical defensive guidance.

---
## Ecosystem Context

CounterAgent is the **protocol & system** arm of the Agentic AI Security ecosystem under [richardspicer.io](https://richardspicer.io). It tests MCP servers, tool trust boundaries, and agent delegation chains.

The **[CounterSignal](https://github.com/richardspicer/countersignal)** program (IPI, CXP, RXP) is the sister program handling **content & supply chain** — indirect prompt injection detection, coding assistant context poisoning, and RAG retrieval poisoning.

---
## The Problem
- AI agents are being deployed with access to tools, data, and systems — often with excessive trust
- MCP adoption is exploding (Claude, ChatGPT, Cursor, Gemini, VS Code) but security tooling hasn't kept pace
- 43% of tested MCP implementations contain command injection flaws
- Only 6% of organizations have an advanced AI security framework
- There is almost no open source offensive tooling purpose-built for agentic AI security testing
- Current tools (Garak, PyRIT) focus on LLM output analysis, not agent action exploitation

### Competitive Landscape

| Tool | Approach | CounterAgent Differentiator |
|------|----------|---------------------------|
| Garak (NVIDIA) | LLM vulnerability scanning, output analysis | Tests agent infrastructure, not just models |
| PyRIT (Microsoft) | Multi-turn red teaming | Maps to OWASP MCP Top 10, tests MCP protocol |
| Invariant MCP-Scan | CLI scanner for tool description attacks | Full OWASP MCP Top 10 coverage, not just tool descriptions |
| ScanMCP.com | Cloud-based scanner + dashboard | Open source, local execution, SARIF for CI/CD |
| Equixly CLI | Commercial MCP security testing | Free and community-extensible |
| MCP Guardian (EQTY Lab) | Runtime security proxy | Complementary — guardian is runtime, counteragent audit is pre-deployment |
| Levo MCP Security | Enterprise platform | Open source alternative |
| Docker MCP Toolkit | Secure distribution (containerized) | Complementary — Docker solves deployment, counteragent audit audits code |

## The Solution
Four modules, building on each other: audit MCP servers → manually explore findings → test agent trust boundaries → chain vulnerabilities into full attack paths.

---
## Module Dependencies

Modules are not sequential phases — they are independent tools with dependency relationships:

```
audit ──► inject ──► chain
  │                    ▲
  └──► proxy           │
         └─────────────┘
```

- **inject** uses audit findings as delivery mechanisms. Vulnerabilities discovered by audit and proxy become the entry points for inject payloads.
- **chain** composes audit entry points with inject techniques into end-to-end attack paths.
- **proxy** is orthogonal — it operates at the protocol level and supports manual exploration of findings from any module.

### Cross-Tool Integration ([Mutual Dissent](https://github.com/q-uestionable-AI/mutual-dissent))

The inject module's multi-vendor payload testing (Anthropic, OpenAI, Gemini, Grok) overlaps with Mutual Dissent's provider routing and transcript capture. Rather than building parallel API integration, inject should consume Mutual Dissent's provider abstraction for cross-model effectiveness testing.

The chain module and Mutual Dissent have **different execution models** — chain is a sequential attack path executor (ordered steps through trust boundaries), while Mutual Dissent is a parallel debate orchestrator (fan-out → reflection → synthesis). Chain does not need Mutual Dissent's orchestrator. Cross-tool research questions (e.g., "can injected payloads survive multi-model reflection rounds?") are tracked separately in the research documentation, not built into either tool's architecture.

---
## Pre-Release Security Review (before each module release)

### Static Analysis (SAST)
- `bandit` — Python security linter
- `semgrep` — custom rules for project patterns
- Run in CI on every PR

### CI Testing Matrix
- Cross-platform: `ubuntu-latest` + `windows-latest`
- Python versions: `["3.11", "3.13", "3.14"]` — floor, near-ceiling, and forward-compatibility
- `requires-python = ">=3.11"` means the floor must always be tested

### Dependency Scanning
- `pip-audit` — check against PyPI advisory database
- GitHub Dependabot for ongoing monitoring

### Manual Review Focus
| Area | Check |
|------|-------|
| Path operations | Output paths constrained, no traversal |
| URL validation | Target URLs validated, blocking where appropriate |
| Input handling | All user inputs sanitized |
| Error handling | No sensitive data in error messages |

### Exit Criteria
- Zero high/critical findings from SAST
- No known CVEs in dependencies
- SECURITY.md documents trust boundaries and limitations

---
## Development Standards

### Vulnerability Research & Disclosure
- Continuously test public MCP server implementations
- Monitor MCP spec changes for new attack surface
- Responsible disclosure pipeline — document, report, wait for fix, then publish
- Track and catalog CVEs related to agentic AI — monthly review via GitHub Advisory Database REST API with NVD and OWASP cross-reference (see `docs/github-advisory-integration.md`)

### Community & Visibility
- richardspicer.io blog — module writeups + shorter posts on individual findings
- GitHub — well-documented repos, contribution guides, issue templates
- OWASP engagement — contribute findings back to MCP Top 10 and Agentic AI Top 10
- LinkedIn — quality posts on key findings

### Framework Mapping

| Framework | Usage |
|-----------|-------|
| OWASP MCP Top 10 | Primary vulnerability taxonomy for audit scanners |
| OWASP Top 10 for Agentic AI | Attack pattern classification for inject and chain modules |
| OWASP Top 10 for LLM Applications 2025 | Cross-reference for LLM-specific findings |
| MITRE ATLAS | Adversarial ML technique mapping |
| NIST AI RMF | Risk management context |
| NIST Cybersecurity Framework Profile for AI (NISTIR 8596) | Defensive recommendation alignment |

---
## v1.0 Exit Criteria

SemVer 1.0 is a public commitment to interface stability. After 1.0, breaking changes to CLI commands, report formats, data models, or YAML schemas require a major version bump.

### Capability Readiness

| Module | Gate |
|--------|------|
| audit | ≥3 distinct MCP server targets scanned with findings documented in Research Log |
| proxy | ≥1 end-to-end intercept session captured and replayed against a live MCP server |
| inject | ≥1 campaign run against a real LLM endpoint with scoring results in Research Log |
| chain | ≥1 chain template executed end-to-end against real targets with step evidence in Research Log |

### Interface Stability

**CLI commands** (as documented at [docs.counteragent.dev](https://docs.counteragent.dev)):

| Module | Implemented & frozen | Documented stubs (not yet frozen) |
|--------|---------------------|-----------------------------------|
| audit | `scan`, `enumerate`, `list-checks`, `report` | — |
| proxy | `start`, `replay`, `export`, `inspect` | — |
| inject | `serve`, `campaign`, `list-payloads`, `report` | — |
| chain | `validate`, `list-templates`, `run` | `blast-radius`, `detect` |

Command names, required arguments, and option flags for implemented commands are frozen at 1.0. Stub commands (`blast-radius`, `detect`) are not frozen until implemented — their signatures may change, but they will not be removed.

**Data models:**

| Module | Frozen models |
|--------|---------------|
| core | `Finding`, `ScanContext`, `Severity`, `Transport`, `Direction` |
| proxy | `ProxyMessage`, `ProxySession`, `HeldMessage`, `InterceptAction` |
| inject | `Campaign`, `PayloadTemplate`, `InjectionResult`, `InjectionTechnique`, `InjectionOutcome` |
| chain | `ChainDefinition`, `ChainStep`, `ChainResult` |

**Protocols and ABCs:**

| Surface | Commitment |
|---------|------------|
| `BaseScanner` ABC | `async scan(context: ScanContext) -> list[Finding]` — frozen |
| `TransportAdapter` protocol | `read()`, `write()`, `close()` — frozen |
| Scanner registry | Scanner name → class mapping stable; new scanners additive only |

**Report and schema formats:**

| Format | Commitment |
|--------|------------|
| HTML, SARIF, JSON scan reports | Schema documented; breaking changes require major bump |
| Inject YAML payload templates | Schema validated by loader; breaking changes require major bump |
| Chain YAML templates | Schema validated by loader; breaking changes require major bump |

### Research Validation

- ≥1 publishable finding from inject or chain campaigns (MCP-NNN in Findings)
- OWASP MCP Top 10 mapping validated against real scan results

### Explicitly Post-1.0

- **Proxy client-facing HTTP adapters** — proxy currently operates as a subprocess (stdio client-facing). Standalone network service mode is post-1.0.
- **Chain `blast-radius` and `detect` commands** — stubs ship at 1.0; implementation is post-1.0.

---
## Goals

### Audit Module
- counteragent audit scans a live MCP server and produces a SARIF report
- At least 5 OWASP MCP Top 10 categories have working scanner modules
- Tool validates against intentionally vulnerable fixtures

### Proxy Module
- `counteragent proxy` intercepts and displays live MCP traffic across all three transports
- Intercept mode allows modification of in-flight JSON-RPC messages
- Replay mode re-sends captured tool calls with modified arguments
- Session export produces JSON evidence suitable for bounty submissions

### Inject Module
- The inject module delivers payloads that successfully manipulate agent behavior
- Effectiveness scoring produces measurable results across 3+ agent configurations
- Responsible disclosure for any novel bypasses

### Chain Module
- At least 3 documented novel attack chains
- Defensive playbook generated from findings
- Conference CFP submission (stretch goal)

### Portfolio
- 50+ GitHub stars on counteragent within 3 months
- At least one responsible disclosure accepted
- Project referenced in job applications and interviews

---
## Reference Links
- OWASP MCP Top 10: https://owasp.org/www-project-mcp-top-10/
- OWASP Top 10 for Agentic AI: https://genai.owasp.org/
- MCP Specification: https://modelcontextprotocol.io/
- MCP Python SDK: https://github.com/modelcontextprotocol/python-sdk
- FastMCP: https://gofastmcp.com/
- MITRE ATLAS: https://atlas.mitre.org/
- Garak: https://github.com/NVIDIA/garak
- PyRIT: https://github.com/Azure/PyRIT
