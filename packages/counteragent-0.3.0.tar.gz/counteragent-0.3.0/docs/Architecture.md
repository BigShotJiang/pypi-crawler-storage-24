# CounterAgent Architecture

## Overview

CounterAgent is a unified monorepo consolidating MCP security tools into one Python package with a shared CLI. It provides automated security scanning (audit) and interactive traffic interception (proxy) for MCP servers.

---

## Package Layout

```
src/counteragent/
├── __init__.py                    # Package version
├── __main__.py                    # python -m counteragent support
├── cli.py                         # Root Typer app — mounts audit, proxy, inject, chain
├── core/                          # Shared models, connection, transport
│   ├── __init__.py
│   ├── models.py                  # Data models (Finding, ScanContext, Severity, Transport, Direction)
│   ├── connection.py              # MCP connection management
│   ├── discovery.py               # Server enumeration, capability discovery
│   ├── evidence.py                # Evidence collection and reporting
│   ├── owasp.py                   # OWASP MCP Top 10 category definitions
│   └── transport.py               # Transport abstractions (stdio, SSE, Streamable HTTP)
├── audit/                         # MCP server security scanner
│   ├── cli.py                     # audit subcommand CLI (scan, list-checks, enumerate, report)
│   ├── orchestrator.py            # ScanResult + run_scan() entry point
│   ├── scanner/                   # Scanner modules (one per OWASP category)
│   │   ├── base.py                # BaseScanner ABC + re-exports from core.models
│   │   ├── registry.py            # Scanner registry and lookup
│   │   ├── injection.py           # MCP05 — Command Injection
│   │   ├── auth.py                # MCP07 — Authentication/Authorization
│   │   ├── token_exposure.py      # MCP01 — Token Mismanagement
│   │   ├── permissions.py         # MCP02 — Privilege Escalation
│   │   ├── tool_poisoning.py      # MCP03 — Tool Poisoning
│   │   ├── supply_chain.py        # MCP04 — Supply Chain & Integrity
│   │   ├── prompt_injection.py    # MCP06 — Indirect Prompt Injection
│   │   ├── audit_telemetry.py     # MCP08 — Audit & Telemetry
│   │   ├── shadow_servers.py      # MCP09 — Shadow MCP Servers
│   │   └── context_sharing.py     # MCP10 — Context Over-Sharing
│   ├── payloads/                  # Injection payload generators
│   ├── reporting/                 # Report generation (HTML, SARIF, JSON)
│   ├── mcp_client/                # Re-export shims → core.connection, core.discovery
│   └── utils/                     # Scan-specific utilities
├── proxy/                         # MCP traffic interceptor
│   ├── cli.py                     # proxy subcommand CLI (start, replay, export, inspect)
│   ├── models.py                  # ProxyMessage, ProxySession, HeldMessage, InterceptAction
│   ├── pipeline.py                # Message pipeline (bidirectional forwarding loops)
│   ├── intercept.py               # InterceptEngine (hold/release/breakpoint logic)
│   ├── session_store.py           # SessionStore (capture, save/load, export)
│   ├── replay.py                  # ReplayEngine (re-send captured messages)
│   ├── correlation.py             # Request-response correlation by JSON-RPC id
│   ├── exporting/                 # Session export formats
│   ├── adapters/                  # Transport adapters
│   │   ├── __init__.py            # TransportAdapter protocol + exports
│   │   ├── stdio.py               # StdioServerAdapter, StdioClientAdapter
│   │   ├── sse.py                 # SseServerAdapter
│   │   └── streamable_http.py     # StreamableHttpServerAdapter
│   └── tui/                       # Textual TUI
│       ├── app.py                 # ProxyApp — main Textual application
│       ├── messages.py            # Custom Textual messages (MessageReceived, etc.)
│       └── widgets/               # TUI widgets
│           ├── message_list.py    # Message list panel
│           ├── message_detail.py  # Message detail/edit panel
│           └── status_bar.py      # Proxy status bar
├── inject/                        # Tool poisoning & prompt injection
│   ├── cli.py                     # Typer subcommands (serve, campaign, list-payloads, report)
│   ├── models.py                  # Data models (PayloadTemplate, Campaign, InjectionResult, enums)
│   ├── campaign.py                # Campaign executor — Anthropic tool-use API integration
│   ├── scoring.py                 # Response outcome scorer (heuristic classifier)
│   ├── server.py                  # FastMCP server builder — dynamic tool registration
│   └── payloads/
│       ├── loader.py              # YAML discovery, loading, and filtering
│       └── templates/             # Built-in payload YAML files (3 files, 13 payloads)
└── chain/                         # Multi-agent attack chains
    ├── cli.py                     # Typer subcommands (validate, list-templates, run, blast-radius, detect)
    ├── models.py                  # Data models (ChainDefinition, ChainStep, ChainResult, ChainCategory, TraceResult)
    ├── loader.py                  # YAML discovery, parsing, and structural validation
    ├── validator.py               # Semantic validation — module refs, graph analysis, cycle detection
    ├── tracer.py                  # Dry-run tracer — walks success path, tracks trust boundaries
    ├── executor.py                # Live execution engine
    ├── executor_models.py         # StepOutput, TargetConfig
    ├── artifacts.py               # Artifact extraction
    ├── variables.py               # Variable resolution
    └── templates/                 # Built-in chain YAML files (3 templates)
```

---

## Shared Core (`core/`)

The core module provides types and utilities shared across all submodules:

- **`models.py`** — `Severity` enum, `Finding` dataclass, `ScanContext`, `Transport` enum, `Direction` enum
- **`connection.py`** — `MCPConnection` class for establishing MCP client connections
- **`discovery.py`** — `enumerate_server()` for capability discovery
- **`transport.py`** — Transport type abstractions
- **`evidence.py`** — Evidence collection for reporting
- **`owasp.py`** — OWASP MCP Top 10 category definitions and metadata

---

## Audit Module

**Data flow:** CLI → `run_scan()` (orchestrator) → `enumerate_server()` (discovery) → scanner registry → each scanner's `scan()` → aggregate `ScanResult` → JSON report

**Key abstractions:**

- **`BaseScanner`** ABC in `scanner/base.py` — every scanner extends this and implements `async scan(context: ScanContext) -> list[Finding]`
- Scanner registry (`audit/scanner/registry.py`) maintains a static mapping of scanner names to scanner classes
- Import convention: shared types from `counteragent.audit.scanner.base` (re-exports from core)
- `mcp_client/` contains backward-compatibility shims pointing to `core.connection` and `core.discovery`

10 scanner modules, one per OWASP MCP Top 10 category. See `docs/owasp_mapping.md` for detailed coverage.

---

## Proxy Module

**Design principle:** SDK for transport, raw for messages. Uses MCP SDK transport functions for connection setup but operates on raw `JSONRPCMessage` objects.

**Data flow:** CLI → TUI App (Textual Worker) → Pipeline → Transport Adapters → Target Server

```
┌──────────────┐         ┌─────────────────────────────────────┐         ┌──────────────┐
│  MCP Client  │         │           counteragent proxy        │         │  MCP Server  │
│  (Claude,    │  stdio  │  ┌────────┐  ┌─────────┐  ┌──────┐  │  stdio  │  (target     │
│   Cursor,    │◄───────►│  │Client  │  │Message  │  │Server│  │◄───────►│   server)    │
│   etc.)      │  SSE    │  │Adapter │◄►│Pipeline │◄►│Adapt.│  │  SSE    │              │
│              │  HTTP   │  └────────┘  └─────────┘  └──────┘  │  HTTP   │              │
└──────────────┘         │       ▲       ▲   │    ▲            │         └──────────────┘
                         │       │       │   ▼    │            │
                         │       │  ┌─────────┐   │            │
                         │       │  │Intercept│   │            │
                         │       │  │Engine   │   │            │
                         │       │  └─────────┘   │            │
                         │       │       │   ▲    │            │
                         │       │       ▼   │    │            │
                         │  ┌────────┐ ┌─────────┐ ┌────────┐  │
                         │  │Session │ │ Replay  │ │Textual │  │
                         │  │Store   │ │ Engine  │ │  TUI   │  │
                         │  └────────┘ └─────────┘ └────────┘  │
                         └─────────────────────────────────────┘
```

**Key abstractions:**

- **`TransportAdapter`** protocol — `read()`, `write()`, `close()`
- **`InterceptEngine`** — hold/release messages via `asyncio.Event`, FORWARD/MODIFY/DROP actions
- **`SessionStore`** — ordered `ProxyMessage` sequence, save/load JSON
- **`ProxyMessage`** — envelope wrapping JSON-RPC message with metadata (direction, timestamp, sequence, correlation)
- asyncio primary, anyio only at SDK boundary inside transport adapters

**Transport coverage:** Server-facing adapters support all three MCP transports (stdio, SSE, Streamable HTTP). Client-facing adapters currently support stdio only — the proxy runs as a subprocess of the MCP client. Client-facing HTTP adapters (proxy as a standalone network service) are planned.

---

## Inject Module

Tool poisoning and prompt injection testing against AI agents. Serves configurable payloads through purpose-built malicious MCP servers.

**Data flow:** `CLI (list-payloads)` → `loader.load_payloads()` → filter by technique → display. `CLI (serve)` → `loader.load_payloads()` → `build_server()` → FastMCP server → transport (stdio/streamable-http).

**Key abstractions:**

- **`build_server()`** uses `exec()` to construct typed handler functions — FastMCP requires named parameters, not `**kwargs`. Parameter names validated via regex + `keyword.iskeyword()`.
- **YAML payload templates** define tool name, description, parameters, and response content per technique category (description poisoning, output injection, cross-tool escalation).
- **`loader.py`** discovers, parses, and filters YAML templates with multi-format error handling. Supports technique and target agent filtering.
- Reuses `core.connection` / `core.discovery` for integration testing.

**Test targets:**

- **llmster** (`http://inference-server:1234`) — local Anthropic-compatible endpoint (phi-4). Use for baseline campaign testing before escalating to cloud models. No payload leakage, full request/response visibility. See `lab/docs/inference-stack.md`.
- **AnythingLLM** (`http://inference-server:3001`) — MCP agent mode. Compare payload handling with LibreChat and Dify.
- **LibreChat / Dify** — native MCP clients on inference-server. See Research board for investigation items.

**CLI subcommands:**

- `serve` — Start a malicious MCP server serving configurable poisoned tool descriptions and injection payloads
- `campaign` — Run systematic injection testing against a target agent
- `list-payloads` — List available injection payload templates, filterable by technique and target agent
- `report` — Generate reports from campaign results

**Data models** (`inject/models.py`):

- `InjectionTechnique` — enum: description poisoning, output injection, cross-tool escalation
- `InjectionOutcome` — graded scoring: full compliance → clean refusal
- `PayloadTemplate` — reusable payload definition with OWASP mapping
- `InjectionResult` — single attempt result with evidence
- `Campaign` — aggregate campaign with ordered results

**Test layout:**

```
tests/inject/
├── test_cli.py                # 19 tests — CLI registration, config, serve wiring
├── test_loader.py             # 18 tests — loader discovery, parsing, filtering
├── test_models.py             # 2 tests — model construction
├── test_server.py             # 11 tests — server builder, handler generation
└── test_serve_integration.py  # 4 tests — stdio lifecycle
```

---

## Chain Module

Declarative framework for defining and tracing multi-step attack paths that link audit scanners and inject techniques into exploitation sequences across trust boundaries.

**Data flow (dry-run):** CLI → `load_chain()` (loader) → `validate_chain()` (validator) → `trace_chain()` (tracer) → JSON output

**Data flow (live):** CLI → `load_chain()` → `validate_chain()` → `TargetConfig.from_yaml()` → `execute_chain()` (executor) → per-step dispatch (`run_scan()` / `run_campaign()`) → `write_chain_report()` → JSON output

**Key abstractions:**

- **`ChainDefinition`** / **`ChainStep`** (`models.py`) — chain metadata and ordered steps, each referencing a module (`audit` or `inject`), technique, trust boundary, and routing (`on_success`/`on_failure`)
- **`ChainCategory`** enum — four architecture patterns: `rag_pipeline`, `agent_delegation`, `mcp_ecosystem`, `hybrid`
- **Loader** (`loader.py`) — YAML discovery and parsing with structural validation (required fields, category enum, step ID uniqueness)
- **Validator** (`validator.py`) — six-pass semantic validation: module refs, technique refs (cross-checks audit scanner registry and inject technique enum), graph refs, cycle detection (DFS three-color), reachability (BFS from first step), terminal step check
- **Tracer** (`tracer.py`) — dry-run walker that follows the success path without network calls, producing a `TraceResult` with step sequence and trust boundaries crossed
- **Executor** (`executor.py`) — live execution engine that dispatches audit steps to `run_scan()` and inject steps to `run_campaign()` with single-payload first-match selection
- **`TargetConfig`** (`executor_models.py`) — target configuration loaded from `chain-targets.yaml` with CLI overrides
- **`StepOutput`** (`executor_models.py`) — per-step result with artifacts for downstream variable resolution via `$step_id.artifact_name` references

**Current state:** Validation, dry-run tracing, and live execution all work. The executor dispatches audit steps to `run_scan()` and inject steps to `run_campaign()` with single-payload first-match selection. Target configuration via `chain-targets.yaml` with CLI overrides. Variable resolution passes artifacts between steps via `$step_id.artifact_name` references.

**CLI subcommands:**

- `validate` — Load and validate a chain definition
- `list-templates` — List built-in chain templates
- `run` — Execute chain (dry-run tracing or live execution against configured targets)
- `blast-radius` — Analyze blast radius from a completed chain execution (JSON/HTML output)
- `detect` — Generate detection rules (Sigma/Wazuh) from observed attack patterns

3 built-in YAML templates: delegation hijack, MCP server compromise, RAG trust escalation.

---

## CLI Hierarchy

Root `cli.py` creates a Typer app and mounts subcommands:

- `counteragent audit ...` → `audit/cli.py` (scan, list-checks, enumerate, report)
- `counteragent proxy ...` → `proxy/cli.py` (start, replay, export, inspect)
- `counteragent inject ...` → `inject/cli.py` (serve, campaign, list-payloads, report)
- `counteragent chain ...` → `chain/cli.py` (run, list-templates, validate, blast-radius, detect)

---

## Test Layout

```
tests/
├── audit/                    # Audit module tests
│   ├── test_scanner/         # Per-scanner unit tests
│   ├── test_mcp_client/      # MCP client tests
│   ├── test_orchestrator.py
│   └── test_cli.py
├── proxy/                    # Proxy module tests
│   ├── test_tui/             # TUI app and widget tests
│   ├── test_pipeline.py
│   ├── test_intercept.py
│   ├── test_session_store.py
│   ├── test_replay.py
│   └── test_cli.py
├── inject/                   # Inject module tests
│   ├── test_cli.py
│   ├── test_loader.py
│   ├── test_models.py
│   ├── test_server.py
│   └── test_serve_integration.py
├── chain/                    # Chain module tests
│   └── test_cli.py
├── core/                     # Core module tests
└── conftest.py               # Shared fixtures
fixtures/vulnerable_servers/  # Intentionally vulnerable MCP servers for integration testing
```

---

## Technology Stack

| Component | Technology | Rationale |
|-----------|-----------|-----------|
| Language | Python >=3.11 | Async-native, rich ecosystem for security tooling |
| MCP SDK | mcp v1.x | Official SDK, stable API |
| CLI | Typer | Declarative CLI with auto-generated help |
| TUI | Textual 8.x | Async-native terminal UI framework |
| Async | asyncio (stdlib), anyio at SDK boundary | Standard library async, anyio for MCP SDK compatibility |
| Serialization | Pydantic | Type-safe data models with validation |
| Testing | pytest + pytest-asyncio | Async test support, fixture-based |
| Linting | ruff | Fast, unified linter and formatter |
| Type checking | mypy | Static type verification |
| Packaging | hatchling + uv | Modern Python packaging with fast dependency resolution |
