"""Shared fixtures for core test suite."""

from __future__ import annotations

import sys
from pathlib import Path

import pytest_asyncio

from counteragent.core.connection import MCPConnection
from counteragent.core.discovery import enumerate_server
from counteragent.core.models import ScanContext

# Path to the FastMCP fixture server
FIXTURE_PATH = str(
    Path(__file__).resolve().parent.parent.parent
    / "fixtures"
    / "vulnerable_servers"
    / "vuln_injection.py"
)


@pytest_asyncio.fixture(scope="module", loop_scope="module")
async def scan_context() -> ScanContext:
    """Module-scoped ScanContext from enumerating the fixture server.

    Opens a connection, enumerates the server, closes the connection,
    and returns the ScanContext. All discovery tests share this single
    result instead of each spawning a subprocess.
    """
    async with MCPConnection.stdio(sys.executable, [FIXTURE_PATH]) as conn:
        return await enumerate_server(conn)
