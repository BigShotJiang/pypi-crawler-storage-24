"""Tests for MCPConnection: lifecycle, error handling, and properties.

Launches the vuln_injection fixture server via stdio to verify real
connection behaviour. Uses the same subprocess pattern as the proxy
integration tests.
"""

from __future__ import annotations

import sys

import pytest

from counteragent.core.connection import MCPConnection

from .conftest import FIXTURE_PATH


class TestStdioLifecycle:
    """Verify stdio connection lifecycle: connect, use, disconnect."""

    @pytest.mark.timeout(30)
    async def test_connect_and_session_populated(self) -> None:
        """Session and init_result are populated after entering context."""
        async with MCPConnection.stdio(sys.executable, [FIXTURE_PATH]) as conn:
            assert conn.session is not None
            assert conn.init_result is not None
            assert conn.transport_type == "stdio"

    @pytest.mark.timeout(30)
    async def test_list_tools_returns_results(self) -> None:
        """list_tools succeeds on a live connection."""
        async with MCPConnection.stdio(sys.executable, [FIXTURE_PATH]) as conn:
            result = await conn.session.list_tools()
            assert len(result.tools) > 0

    @pytest.mark.timeout(30)
    async def test_clean_shutdown(self) -> None:
        """Exiting the context manager completes without error."""
        async with MCPConnection.stdio(sys.executable, [FIXTURE_PATH]) as conn:
            assert conn.session is not None
        # If we reach here, shutdown was clean (no hanging processes)


class TestConnectionErrors:
    """Verify error handling for bad connection parameters."""

    @pytest.mark.timeout(30)
    async def test_nonexistent_command_raises(self) -> None:
        with pytest.raises(ConnectionError):
            async with MCPConnection.stdio("nonexistent_command", []):
                pass  # pragma: no cover

    @pytest.mark.timeout(30)
    async def test_nonexistent_script_raises(self) -> None:
        with pytest.raises(ConnectionError):
            async with MCPConnection.stdio(sys.executable, ["nonexistent_script.py"]):
                pass  # pragma: no cover


class TestConnectionUrl:
    """Verify connection_url property for different transports."""

    def test_stdio_returns_none(self) -> None:
        conn = MCPConnection.stdio(sys.executable, [FIXTURE_PATH])
        assert conn.connection_url is None

    def test_sse_returns_url(self) -> None:
        conn = MCPConnection.sse("http://localhost:8080/sse")
        assert conn.connection_url == "http://localhost:8080/sse"

    def test_streamable_http_returns_url(self) -> None:
        conn = MCPConnection.streamable_http("http://localhost:8080/mcp")
        assert conn.connection_url == "http://localhost:8080/mcp"


class TestTransportType:
    """Verify transport_type is set correctly by each factory method."""

    def test_stdio_transport_type(self) -> None:
        conn = MCPConnection.stdio(sys.executable, [])
        assert conn.transport_type == "stdio"

    def test_sse_transport_type(self) -> None:
        conn = MCPConnection.sse("http://localhost:8080/sse")
        assert conn.transport_type == "sse"

    def test_streamable_http_transport_type(self) -> None:
        conn = MCPConnection.streamable_http("http://localhost:8080/mcp")
        assert conn.transport_type == "streamable-http"
