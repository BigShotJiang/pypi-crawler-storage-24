"""Tests for enumerate_server: enumeration, tool shape, and defaults.

Connects to the vuln_injection fixture server via MCPConnection,
then calls enumerate_server() to verify the returned ScanContext.
"""

from __future__ import annotations

import pytest

from counteragent.core.models import ScanContext

pytestmark = pytest.mark.asyncio(loop_scope="module")

# Tools registered by the vuln_injection fixture server
EXPECTED_TOOLS = {"file_search", "run_diagnostics", "safe_echo", "list_processes"}


class TestBasicEnumeration:
    """Verify enumerate_server returns a well-populated ScanContext."""

    @pytest.mark.timeout(30)
    async def test_tools_discovered(self, scan_context: ScanContext) -> None:
        """enumerate_server finds tools on the fixture server."""
        assert len(scan_context.tools) > 0

    @pytest.mark.timeout(30)
    async def test_server_name_populated(self, scan_context: ScanContext) -> None:
        """Server name is populated (not 'unknown')."""
        assert scan_context.server_info["name"] != "unknown"
        assert scan_context.server_info["name"]  # not empty

    @pytest.mark.timeout(30)
    async def test_protocol_version_populated(self, scan_context: ScanContext) -> None:
        """Protocol version is present in server_info."""
        assert scan_context.server_info["protocolVersion"]

    @pytest.mark.timeout(30)
    async def test_transport_type_is_stdio(self, scan_context: ScanContext) -> None:
        """Transport type matches the connection transport."""
        assert scan_context.transport_type == "stdio"


class TestToolDictShape:
    """Verify tool dicts have the expected keys and match fixture tools."""

    @pytest.mark.timeout(30)
    async def test_tool_dict_has_required_keys(self, scan_context: ScanContext) -> None:
        """Each tool dict has name, description, and inputSchema."""
        for tool in scan_context.tools:
            assert "name" in tool
            assert "description" in tool
            assert "inputSchema" in tool

    @pytest.mark.timeout(30)
    async def test_tool_names_match_fixture(self, scan_context: ScanContext) -> None:
        """Discovered tool names match what the fixture server registers."""
        tool_names = {t["name"] for t in scan_context.tools}
        assert tool_names == EXPECTED_TOOLS


class TestCapabilitiesAndTransport:
    """Verify server_info includes capabilities and transport metadata."""

    @pytest.mark.timeout(30)
    async def test_capabilities_is_bool_dict(self, scan_context: ScanContext) -> None:
        """capabilities is a dict with boolean values."""
        caps = scan_context.server_info["capabilities"]
        assert isinstance(caps, dict)
        for value in caps.values():
            assert isinstance(value, bool)

    @pytest.mark.timeout(30)
    async def test_transport_matches_transport_type(self, scan_context: ScanContext) -> None:
        """server_info['transport'] matches ctx.transport_type."""
        assert scan_context.server_info["transport"] == scan_context.transport_type


class TestEmptyCapabilities:
    """Verify resources and prompts default to empty lists when unsupported."""

    @pytest.mark.timeout(30)
    async def test_resources_empty_list(self, scan_context: ScanContext) -> None:
        """Resources is an empty list when server doesn't expose them."""
        assert scan_context.resources == []

    @pytest.mark.timeout(30)
    async def test_prompts_empty_list(self, scan_context: ScanContext) -> None:
        """Prompts is an empty list when server doesn't expose them."""
        assert scan_context.prompts == []
