"""Tests for core data models: Finding, Severity, ScanContext, Direction, Transport."""

from __future__ import annotations

from datetime import UTC, datetime

from counteragent.core.models import (
    Direction,
    Finding,
    ScanContext,
    Severity,
    Transport,
)


class TestSeverityEnum:
    """Verify all CVSS-aligned severity levels exist and are strings."""

    def test_all_five_levels_exist(self) -> None:
        levels = [s.value for s in Severity]
        assert levels == ["critical", "high", "medium", "low", "info"]

    def test_values_are_strings(self) -> None:
        for level in Severity:
            assert isinstance(level.value, str)


class TestFinding:
    """Verify Finding construction and default behaviour."""

    def test_required_fields(self) -> None:
        finding = Finding(
            rule_id="MCP05-001",
            owasp_id="MCP05",
            title="Test finding",
            description="A test vulnerability",
            severity=Severity.HIGH,
        )
        assert finding.rule_id == "MCP05-001"
        assert finding.owasp_id == "MCP05"
        assert finding.title == "Test finding"
        assert finding.description == "A test vulnerability"
        assert finding.severity is Severity.HIGH

    def test_timestamp_auto_populated(self) -> None:
        before = datetime.now(UTC)
        finding = Finding(
            rule_id="MCP01-001",
            owasp_id="MCP01",
            title="Timestamp test",
            description="Check auto timestamp",
            severity=Severity.INFO,
        )
        after = datetime.now(UTC)
        assert before <= finding.timestamp <= after

    def test_metadata_defaults_to_empty_dict(self) -> None:
        finding = Finding(
            rule_id="MCP01-001",
            owasp_id="MCP01",
            title="Metadata test",
            description="Check default metadata",
            severity=Severity.LOW,
        )
        assert finding.metadata == {}
        assert isinstance(finding.metadata, dict)

    def test_optional_fields_defaults(self) -> None:
        finding = Finding(
            rule_id="MCP01-001",
            owasp_id="MCP01",
            title="Defaults test",
            description="Check defaults",
            severity=Severity.MEDIUM,
        )
        assert finding.evidence == ""
        assert finding.remediation == ""
        assert finding.tool_name is None


class TestScanContext:
    """Verify ScanContext default construction."""

    def test_defaults(self) -> None:
        ctx = ScanContext()
        assert ctx.server_info == {}
        assert ctx.tools == []
        assert ctx.resources == []
        assert ctx.prompts == []
        assert ctx.transport_type == "stdio"
        assert ctx.connection_url is None
        assert ctx.session is None
        assert ctx.config == {}

    def test_empty_lists_not_shared(self) -> None:
        ctx1 = ScanContext()
        ctx2 = ScanContext()
        ctx1.tools.append({"name": "test"})
        assert ctx2.tools == []


class TestDirectionEnum:
    """Verify Direction enum values."""

    def test_client_to_server(self) -> None:
        assert Direction.CLIENT_TO_SERVER == "client_to_server"

    def test_server_to_client(self) -> None:
        assert Direction.SERVER_TO_CLIENT == "server_to_client"


class TestTransportEnum:
    """Verify Transport enum values."""

    def test_stdio(self) -> None:
        assert Transport.STDIO == "stdio"

    def test_sse(self) -> None:
        assert Transport.SSE == "sse"

    def test_streamable_http(self) -> None:
        assert Transport.STREAMABLE_HTTP == "streamable-http"
