"""Tests for chain detection rule generation."""

from __future__ import annotations

import json
import re
from pathlib import Path

from typer.testing import CliRunner

from counteragent.chain.cli import app
from counteragent.chain.detection import generate_detection_rules, write_detection_rules

runner = CliRunner()


def _strip_ansi(text: str) -> str:
    """Remove ANSI escape sequences from text."""
    return re.sub(r"\x1b\[[0-9;]*m", "", text)


def _make_result(
    step_outputs: list[dict] | None = None,
    trust_boundaries: list[str] | None = None,
    success: bool = True,
    target_config: dict | None = None,
) -> dict:
    """Build a minimal chain result dict for testing."""
    return {
        "chain_id": "test-chain",
        "chain_name": "Test Chain",
        "target_config": target_config or {"audit_transport": "stdio"},
        "step_outputs": step_outputs or [],
        "trust_boundaries_crossed": trust_boundaries or [],
        "started_at": "2026-01-01T00:00:00+00:00",
        "finished_at": "2026-01-01T00:01:00+00:00",
        "dry_run": False,
        "success": success,
    }


def _successful_audit_step(
    step_id: str = "scan-injection",
    technique: str = "injection",
) -> dict:
    """Build a successful audit step output dict."""
    return {
        "step_id": step_id,
        "module": "audit",
        "technique": technique,
        "success": True,
        "status": "success",
        "artifacts": {
            "vulnerable_tool": "get_weather",
            "vulnerability_type": "MCP05",
            "finding_count": "3",
        },
        "started_at": "2026-01-01T00:00:00+00:00",
        "finished_at": "2026-01-01T00:00:30+00:00",
        "error": None,
    }


def _successful_inject_step(
    step_id: str = "poison-tool",
    technique: str = "description_poisoning",
) -> dict:
    """Build a successful inject step output dict."""
    return {
        "step_id": step_id,
        "module": "inject",
        "technique": technique,
        "success": True,
        "status": "success",
        "artifacts": {
            "best_outcome": "full_compliance",
            "working_payload": "exfil_via_important_tag",
            "working_technique": "description_poisoning",
            "compliance_rate": "75",
        },
        "started_at": "2026-01-01T00:00:30+00:00",
        "finished_at": "2026-01-01T00:01:00+00:00",
        "error": None,
    }


def _failed_step(step_id: str = "failed-step", module: str = "inject") -> dict:
    """Build a failed step output dict."""
    return {
        "step_id": step_id,
        "module": module,
        "technique": "output_injection",
        "success": False,
        "status": "failed",
        "artifacts": {},
        "started_at": "2026-01-01T00:00:30+00:00",
        "finished_at": "2026-01-01T00:01:00+00:00",
        "error": "Campaign failed: model refused",
    }


# ---------------------------------------------------------------------------
# Sigma rule generation
# ---------------------------------------------------------------------------


class TestSigmaRuleGeneration:
    """Tests for Sigma rule generation."""

    def test_audit_step_produces_sigma_rule(self) -> None:
        """A successful audit step produces a valid Sigma rule."""
        result = _make_result(step_outputs=[_successful_audit_step()])
        rules = generate_detection_rules(result, format="sigma")

        assert len(rules) == 1
        rule = rules[0]
        assert "title: MCP Command Execution Detected - get_weather" in rule
        assert "status: experimental" in rule
        assert "level: high" in rule
        assert "product: mcp-server" in rule
        assert "tool_name: get_weather" in rule
        assert "technique: injection" in rule
        assert "attack.execution" in rule
        assert "attack.t1059" in rule
        assert "test-chain" in rule
        assert "scan-injection" in rule

    def test_inject_step_produces_sigma_rule(self) -> None:
        """A successful inject step produces a valid Sigma rule."""
        result = _make_result(step_outputs=[_successful_inject_step()])
        rules = generate_detection_rules(result, format="sigma")

        assert len(rules) == 1
        rule = rules[0]
        assert "title: MCP Tool Poisoning Detected - description_poisoning" in rule
        assert "level: critical" in rule
        assert "product: mcp-agent" in rule
        assert "technique: description_poisoning" in rule
        assert "full_compliance" in rule
        assert "attack.defense_evasion" in rule
        assert "attack.t1036" in rule
        assert "test-chain" in rule
        assert "poison-tool" in rule

    def test_multiple_steps(self) -> None:
        """Multiple successful steps produce multiple rules."""
        result = _make_result(step_outputs=[_successful_audit_step(), _successful_inject_step()])
        rules = generate_detection_rules(result, format="sigma")
        assert len(rules) == 2

    def test_failed_steps_produce_no_rules(self) -> None:
        """Failed steps are skipped — no rules generated."""
        result = _make_result(step_outputs=[_failed_step()])
        rules = generate_detection_rules(result, format="sigma")
        assert len(rules) == 0

    def test_mixed_success_and_failure(self) -> None:
        """Only successful steps generate rules."""
        result = _make_result(
            step_outputs=[
                _successful_audit_step(),
                _failed_step(),
                _successful_inject_step(),
            ]
        )
        rules = generate_detection_rules(result, format="sigma")
        assert len(rules) == 2

    def test_empty_chain_result(self) -> None:
        """Empty chain result produces no rules."""
        result = _make_result(step_outputs=[])
        rules = generate_detection_rules(result, format="sigma")
        assert len(rules) == 0

    def test_rule_contains_uuid(self) -> None:
        """Each rule has a generated UUID."""
        result = _make_result(step_outputs=[_successful_audit_step()])
        rules = generate_detection_rules(result, format="sigma")
        # UUID pattern
        assert re.search(
            r"id: [0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}",
            rules[0],
        )

    def test_inject_output_injection_mitre(self) -> None:
        """output_injection technique maps to T1059.006."""
        result = _make_result(step_outputs=[_successful_inject_step("oi-step", "output_injection")])
        rules = generate_detection_rules(result, format="sigma")
        assert "attack.t1059.006" in rules[0]

    def test_inject_cross_tool_escalation_mitre(self) -> None:
        """cross_tool_escalation technique maps to T1570."""
        result = _make_result(
            step_outputs=[_successful_inject_step("cte-step", "cross_tool_escalation")]
        )
        rules = generate_detection_rules(result, format="sigma")
        assert "attack.t1570" in rules[0]

    def test_owasp_reference(self) -> None:
        """Rules reference OWASP MCP Top 10."""
        result = _make_result(step_outputs=[_successful_audit_step()])
        rules = generate_detection_rules(result, format="sigma")
        assert "owasp.org/www-project-mcp-top-10" in rules[0]


# ---------------------------------------------------------------------------
# Wazuh rule generation
# ---------------------------------------------------------------------------


class TestWazuhRuleGeneration:
    """Tests for Wazuh rule generation."""

    def test_audit_step_produces_wazuh_rule(self) -> None:
        """A successful audit step produces a valid Wazuh XML rule."""
        result = _make_result(step_outputs=[_successful_audit_step()])
        rules = generate_detection_rules(result, format="wazuh")

        assert len(rules) == 1
        rule = rules[0]
        assert "<rule id=" in rule
        assert 'level="10"' in rule
        assert "get_weather" in rule
        assert "injection" in rule
        assert "<mitre>" in rule
        assert "T1059" in rule
        assert "</rule>" in rule

    def test_inject_step_produces_wazuh_rule(self) -> None:
        """A successful inject step produces a valid Wazuh XML rule."""
        result = _make_result(step_outputs=[_successful_inject_step()])
        rules = generate_detection_rules(result, format="wazuh")

        assert len(rules) == 1
        rule = rules[0]
        assert "<rule id=" in rule
        assert 'level="12"' in rule
        assert "description_poisoning" in rule
        assert "full_compliance" in rule
        assert "T1036" in rule

    def test_failed_steps_produce_no_rules(self) -> None:
        """Failed steps produce no Wazuh rules."""
        result = _make_result(step_outputs=[_failed_step()])
        rules = generate_detection_rules(result, format="wazuh")
        assert len(rules) == 0

    def test_multiple_rules_have_unique_ids(self) -> None:
        """Multiple Wazuh rules get unique rule IDs."""
        result = _make_result(step_outputs=[_successful_audit_step(), _successful_inject_step()])
        rules = generate_detection_rules(result, format="wazuh")
        assert len(rules) == 2
        # Extract rule IDs
        ids = re.findall(r'rule id="(\d+)"', "\n".join(rules))
        assert len(set(ids)) == 2


# ---------------------------------------------------------------------------
# write_detection_rules
# ---------------------------------------------------------------------------


class TestWriteDetectionRules:
    """Tests for write_detection_rules function."""

    def test_write_sigma_to_file(self, tmp_path: Path) -> None:
        """Writing Sigma rules to a file concatenates with ---."""
        result = _make_result(step_outputs=[_successful_audit_step(), _successful_inject_step()])
        rules = generate_detection_rules(result, format="sigma")
        out = tmp_path / "rules.yml"
        write_detection_rules(rules, out, format="sigma")

        assert out.exists()
        content = out.read_text(encoding="utf-8")
        assert "---" in content
        assert "MCP Command Execution" in content
        assert "MCP Tool Poisoning" in content

    def test_write_wazuh_to_file(self, tmp_path: Path) -> None:
        """Writing Wazuh rules to a file wraps in <group>."""
        result = _make_result(step_outputs=[_successful_audit_step(), _successful_inject_step()])
        rules = generate_detection_rules(result, format="wazuh")
        out = tmp_path / "rules.xml"
        write_detection_rules(rules, out, format="wazuh")

        assert out.exists()
        content = out.read_text(encoding="utf-8")
        assert '<group name="counteragent">' in content
        assert "</group>" in content

    def test_write_to_directory(self, tmp_path: Path) -> None:
        """Writing to a directory creates one file per rule."""
        result = _make_result(step_outputs=[_successful_audit_step(), _successful_inject_step()])
        rules = generate_detection_rules(result, format="sigma")
        out_dir = tmp_path / "rules_dir"
        write_detection_rules(rules, out_dir, format="sigma")

        assert out_dir.is_dir()
        files = sorted(out_dir.iterdir())
        assert len(files) == 2
        assert files[0].suffix == ".yml"
        assert files[1].suffix == ".yml"

    def test_write_wazuh_to_directory(self, tmp_path: Path) -> None:
        """Writing Wazuh to directory creates .xml files."""
        result = _make_result(step_outputs=[_successful_audit_step()])
        rules = generate_detection_rules(result, format="wazuh")
        out_dir = tmp_path / "wazuh_rules"
        write_detection_rules(rules, out_dir, format="wazuh")

        files = list(out_dir.iterdir())
        assert len(files) == 1
        assert files[0].suffix == ".xml"
        content = files[0].read_text(encoding="utf-8")
        assert "<rule" in content
        assert "</rule>" in content

    def test_creates_parent_dirs(self, tmp_path: Path) -> None:
        """Creates parent directories if they don't exist."""
        result = _make_result(step_outputs=[_successful_audit_step()])
        rules = generate_detection_rules(result, format="sigma")
        out = tmp_path / "sub" / "dir" / "rules.yml"
        write_detection_rules(rules, out, format="sigma")
        assert out.exists()


# ---------------------------------------------------------------------------
# CLI integration
# ---------------------------------------------------------------------------


class TestDetectCLI:
    """Tests for chain detect CLI command."""

    def test_help(self) -> None:
        """Help text includes --results option."""
        result = runner.invoke(app, ["detect", "--help"])
        assert result.exit_code == 0
        assert "--results" in _strip_ansi(result.output)

    def test_missing_file(self, tmp_path: Path) -> None:
        """Nonexistent results file exits 1."""
        missing = tmp_path / "nonexistent.json"
        result = runner.invoke(app, ["detect", "--results", str(missing)])
        assert result.exit_code == 1
        assert "not found" in result.output.lower()

    def test_invalid_json(self, tmp_path: Path) -> None:
        """Invalid JSON exits 1."""
        bad = tmp_path / "bad.json"
        bad.write_text("not json", encoding="utf-8")
        result = runner.invoke(app, ["detect", "--results", str(bad)])
        assert result.exit_code == 1
        assert "error" in result.output.lower()

    def test_invalid_format(self, tmp_path: Path) -> None:
        """Invalid format exits 1."""
        data = _make_result(step_outputs=[_successful_audit_step()])
        infile = tmp_path / "result.json"
        infile.write_text(json.dumps(data), encoding="utf-8")

        result = runner.invoke(
            app,
            ["detect", "--results", str(infile), "--format", "sarif"],
        )
        assert result.exit_code == 1
        assert "invalid format" in result.output.lower()

    def test_sigma_stdout(self, tmp_path: Path) -> None:
        """Without --output, prints Sigma rules to stdout."""
        data = _make_result(step_outputs=[_successful_audit_step()])
        infile = tmp_path / "result.json"
        infile.write_text(json.dumps(data), encoding="utf-8")

        result = runner.invoke(app, ["detect", "--results", str(infile)])
        assert result.exit_code == 0
        assert "MCP Command Execution Detected" in result.output
        assert "get_weather" in result.output

    def test_wazuh_stdout(self, tmp_path: Path) -> None:
        """--format wazuh prints Wazuh XML rules to stdout."""
        data = _make_result(step_outputs=[_successful_inject_step()])
        infile = tmp_path / "result.json"
        infile.write_text(json.dumps(data), encoding="utf-8")

        result = runner.invoke(
            app,
            ["detect", "--results", str(infile), "--format", "wazuh"],
        )
        assert result.exit_code == 0
        assert "<rule id=" in result.output
        assert "description_poisoning" in result.output

    def test_sigma_to_file(self, tmp_path: Path) -> None:
        """--output writes Sigma rules to file."""
        data = _make_result(step_outputs=[_successful_audit_step()])
        infile = tmp_path / "result.json"
        infile.write_text(json.dumps(data), encoding="utf-8")
        outfile = tmp_path / "rules.yml"

        result = runner.invoke(
            app,
            ["detect", "--results", str(infile), "--output", str(outfile)],
        )
        assert result.exit_code == 0
        assert outfile.exists()
        content = outfile.read_text(encoding="utf-8")
        assert "MCP Command Execution" in content

    def test_wazuh_to_file(self, tmp_path: Path) -> None:
        """--format wazuh --output writes Wazuh XML to file."""
        data = _make_result(step_outputs=[_successful_inject_step()])
        infile = tmp_path / "result.json"
        infile.write_text(json.dumps(data), encoding="utf-8")
        outfile = tmp_path / "rules.xml"

        result = runner.invoke(
            app,
            [
                "detect",
                "--results",
                str(infile),
                "--format",
                "wazuh",
                "--output",
                str(outfile),
            ],
        )
        assert result.exit_code == 0
        assert outfile.exists()
        content = outfile.read_text(encoding="utf-8")
        assert "<group" in content

    def test_empty_results_no_rules(self, tmp_path: Path) -> None:
        """Empty chain result with no successful steps exits cleanly."""
        data = _make_result(step_outputs=[_failed_step()])
        infile = tmp_path / "result.json"
        infile.write_text(json.dumps(data), encoding="utf-8")

        result = runner.invoke(app, ["detect", "--results", str(infile)])
        assert result.exit_code == 0
        assert "no" in result.output.lower()

    def test_no_not_yet_implemented(self, tmp_path: Path) -> None:
        """No 'not yet implemented' message anywhere."""
        data = _make_result(step_outputs=[_successful_audit_step()])
        infile = tmp_path / "result.json"
        infile.write_text(json.dumps(data), encoding="utf-8")

        result = runner.invoke(app, ["detect", "--results", str(infile)])
        assert "not yet implemented" not in result.output.lower()
