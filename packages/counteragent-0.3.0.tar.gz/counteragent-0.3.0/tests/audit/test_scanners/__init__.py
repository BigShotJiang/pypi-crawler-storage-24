"""Tests for scanner modules."""
