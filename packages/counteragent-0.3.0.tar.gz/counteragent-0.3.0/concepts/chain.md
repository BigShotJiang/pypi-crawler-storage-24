# chain

> Sequential multi-step attack path executor — composing audit findings and inject techniques into end-to-end exploitation chains.

## Purpose

The audit and inject modules test individual components — a single MCP server, a single agent's trust in tool output. The chain module tests the *system*: how vulnerabilities compose when agents collaborate, delegate tasks, and share context. A command injection in one tool, combined with excessive permissions on a delegated agent, combined with a RAG pipeline that trusts agent-written content, creates an attack path far more dangerous than any individual flaw. No existing tool models or tests these composed attack paths. The chain module makes multi-step agentic exploitation systematic, repeatable, and visible.

## Program Context

The chain module consumes findings and techniques from both upstream modules:
- audit identifies server-level entry points
- inject provides single-step exploitation techniques
- chain composes these into end-to-end attack paths and measures blast radius

This is the capstone module — it demonstrates why individual vulnerabilities matter by showing what happens when they're chained together in realistic architectures.

## Execution Model

Chain is a **sequential attack path executor**. It walks through an ordered sequence of steps — each step references an audit finding or inject technique, takes inputs from prior steps, and produces outputs for subsequent steps. Steps execute in order with conditional branching based on success/failure.

This is fundamentally different from Mutual Dissent's **parallel debate orchestrator**, which fans a single query out to multiple models simultaneously, collects competing responses, and runs reflection rounds. Different execution models, different purposes:

| | Chain | Mutual Dissent |
|---|---|---|
| **Execution** | Sequential steps through architecture | Parallel fan-out to models |
| **Purpose** | Trace attack paths across trust boundaries | Surface disagreements across training data |
| **Unit of work** | One step = one module action (audit check, inject payload) | One round = all models respond + reflect |
| **Branching** | Conditional on step outcome (success/failure) | No branching — all models always participate |
| **Output** | Blast radius analysis, exfil channel map, detection rules | Synthesized consensus answer, debate transcript |

Chain does NOT need Mutual Dissent's orchestrator. Cross-tool research (e.g., "does consensus poisoning via inject payloads survive Mutual Dissent reflection rounds?") is tracked separately in `Lab/Cross-Tool Research Directions.md`.

## Chain Template Structure

Attack chains are defined declaratively in YAML. Each template specifies an ordered sequence of steps with dependency metadata:

```yaml
name: rag-trust-escalation
description: Command injection → delegated agent → RAG poisoning
entry_point:
  module: audit
  finding: MCP05  # Command injection
steps:
  - id: inject-tool-description
    module: inject
    technique: description_poisoning
    inputs:
      target_tool: "{{ entry_point.tool_name }}"
    trust_boundary: agent-to-tool
    on_success: delegate-to-agent
    on_failure: abort

  - id: delegate-to-agent
    module: inject
    technique: cross_tool_escalation
    inputs:
      payload: "{{ steps.inject-tool-description.output }}"
    trust_boundary: agent-to-agent
    on_success: poison-rag
    on_failure: abort

  - id: poison-rag
    module: inject
    technique: output_injection
    inputs:
      context: "{{ steps.delegate-to-agent.output }}"
    trust_boundary: agent-to-data
    on_success: exfiltrate
    on_failure: report-partial

  - id: exfiltrate
    module: chain
    technique: exfil_channel_scan
    inputs:
      access_level: "{{ steps.poison-rag.permissions }}"
    terminal: true
```

Steps reference payload templates by name (declarative), not campaign results. Whether a step succeeds is determined at execution time.

## Core Capabilities

- Define multi-step attack chains declaratively — specify entry point, exploitation steps, and target outcome as structured YAML sequences.
- Trace attack paths through agent architectures — model trust relationships, delegation patterns, and data flows at each step.
- Ship pre-built chain templates for common architectures: RAG pipelines, multi-agent task delegation, MCP tool ecosystems, and hybrid setups.
- Reference real CVEs as chain entry points — pull known MCP vulnerabilities from GitHub Advisory Database to ground chain templates in actual exploitable conditions.
- Measure blast radius — given a successful chain, quantify what the attacker can reach (data, systems, actions, persistence).
- Map exfiltration channels post-compromise — enumerate available paths (HTTP to allowlisted domains, DNS, tool-mediated file writes, rendering-based visual exfil).
- Visualize attack chains — render the path from entry to impact for reports and presentations.
- Generate defensive playbooks from findings — each successful chain produces specific detection and mitigation recommendations.
- Generate detection rules (Sigma/Wazuh) from observed attack patterns.

## Key Design Decisions

- **Monorepo module** (`src/counteragent/chain/`). CLI: `counteragent chain`. Shares core models, transport, and evidence formats with audit, proxy, and inject modules.
- **Declarative chain definitions.** Attack chains are specified as YAML data, not imperative scripts. This makes them shareable, reproducible, and diffable.
- **Dry-run default, live execution opt-in.** The primary mode validates chain structure and traces the logical path without executing against real targets. Live execution requires explicit opt-in and isolation. This keeps the tool safe by default.
- **Sequential execution with conditional branching.** Steps execute in order. Each step's outcome determines the next step (on_success/on_failure). This is NOT parallel fan-out.
- **Exfil channel mapping is a blast radius module**, not a standalone tool. It answers "what can the attacker do after gaining access?" as part of the chain analysis.
- **Detection rule generation is a first-class output.** Every successful attack chain should produce at least one detection rule. This closes the loop: "If I can break it, I should be able to detect it."
- **Cross-platform** — must run on Windows, macOS, and Linux. No platform-specific shell commands in source or test fixtures.

## Open Questions

- **Step references:** Chain steps reference payload templates by name (declarative). Step success is determined at execution time. Open extension: optional campaign-result binding for evidence-backed chains (e.g., "use the result from campaign X that achieved outcome Y").
- **MVP execution scope:** Should the first implementation support only dry-run trace validation (parse YAML, verify step dependencies, check module references), or include live execution capability from the start? Dry-run first is safer and independently useful for template authoring.
- **Trust boundary metadata:** How to represent trust boundary transitions (agent-to-tool, agent-to-agent, agent-to-data) in a way that's both precise enough for blast radius analysis and simple enough to author? The YAML template structure above is a starting point.
- **Scope boundary with inject:** Where does "single-step injection with multi-tool side effects" (inject) end and "multi-step chain across agents" (chain) begin? Decision rule: if it requires multiple sequential steps with different module references or trust boundary transitions, it's chain.

## Artifacts

- Attack chain YAML templates (declarative, shareable, version-controlled).
- Chain execution reports — step-by-step trace with evidence at each stage.
- Blast radius analysis — what the attacker reached, through which path, with what permissions.
- Exfil channel inventory — available post-compromise channels with feasibility ratings.
- Attack chain visualizations — renderable diagrams for reports and presentations.
- Defensive playbooks — per-chain mitigation and detection recommendations.
- Detection rules (Sigma, Wazuh) generated from observed attack patterns.

## Relation to Other Tools

- **audit** finds individual server vulnerabilities. Chain uses those as entry points in composed attack paths.
- **inject** tests single-step agent exploitation. Chain composes inject techniques into multi-step sequences across trust boundaries.
- **proxy** operates at the protocol level. Chain operates at the architecture level — it models how agents interact across steps, not how individual messages flow.
- **Mutual Dissent** is a parallel debate orchestrator for multi-model consensus research. Chain is a sequential attack path executor. Different execution models. Cross-tool research (e.g., injecting payloads into debate context) is tracked in `Lab/Cross-Tool Research Directions.md`, not built into chain's architecture.
- **Drongo** (CounterSignal program) handles RAG retrieval poisoning. Chain may incorporate RAG poisoning as a step in broader chains but does not implement the retrieval optimization itself.

---

*This is a concept doc, not an architecture doc. It captures intent and constraints. The full Architecture doc gets written when development begins.*
