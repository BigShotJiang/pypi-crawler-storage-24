"""Root CLI for CounterAgent — mounts all subcommand apps."""

import typer

from counteragent.audit.cli import app as audit_app
from counteragent.chain.cli import app as chain_app
from counteragent.inject.cli import app as inject_app
from counteragent.proxy.cli import app as proxy_app


def _parse_version(v: str) -> tuple[int, ...]:
    """Parse a version string into a comparable tuple.

    Args:
        v: Version string (e.g. "0.2.1").

    Returns:
        Tuple of integers (e.g. (0, 2, 1)).
    """
    try:
        return tuple(int(x) for x in v.split("."))
    except ValueError:
        return (0,)


def _check_for_update(package_name: str) -> None:
    """Non-blocking background PyPI version check.

    Spawns a daemon thread that fetches the latest version from PyPI
    and prints a one-liner to stderr if a newer version is available.
    Silent on any network or parse failure.

    Args:
        package_name: PyPI package name (e.g. "counteragent").
    """
    import json
    import sys
    import threading
    from importlib.metadata import version
    from urllib.request import urlopen

    def _check() -> None:
        try:
            current = version(package_name)
            url = f"https://pypi.org/pypi/{package_name}/json"
            with urlopen(url, timeout=3) as resp:  # noqa: S310  # nosec B310
                data = json.loads(resp.read())
            latest = data["info"]["version"]
            if _parse_version(latest) > _parse_version(current):
                print(
                    f"Update available: {package_name} {current} \u2192 {latest}  "
                    f"(pip install --upgrade {package_name})",
                    file=sys.stderr,
                )
        except Exception:  # noqa: BLE001, S110  # nosec B110
            pass

    threading.Thread(target=_check, daemon=True).start()


app = typer.Typer(
    name="counteragent",
    help="AI Agent Red Team Platform — OWASP MCP Top 10",
    no_args_is_help=True,
)


@app.callback()
def _on_startup() -> None:
    """Run pre-invocation hooks."""
    _check_for_update("counteragent")


app.add_typer(audit_app, name="audit", help="Audit MCP servers for vulnerabilities")
app.add_typer(proxy_app, name="proxy", help="Intercept and replay MCP traffic")
app.add_typer(inject_app, name="inject", help="Tool poisoning & prompt injection")
app.add_typer(chain_app, name="chain", help="Multi-agent attack chains")
