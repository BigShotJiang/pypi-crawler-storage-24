"""Injection payload library — Phase 2.

Payload templates for tool poisoning and prompt injection testing.
"""
