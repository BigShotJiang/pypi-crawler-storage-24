"""CounterAgent — AI Agent Red Team Platform."""

__version__ = "0.2.0"
