# Changelog

All notable changes to CounterAgent are documented here.
Format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).
This project uses [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.3.0] — 2026-03-08

Chain execution engine with live attack chain testing, blast-radius analysis,
and detection rule generation. Configurable model selection, CLI version checks,
and AI-evaluation prompts embedded in all report formats.

### Added

#### Chain Module — Live Execution
- Execution engine data contract with chain result model and step artifacts
- Audit and inject dispatchers for real campaign execution
- CLI wiring: `chain run` with `--targets` and `--inject-model` flags
- Interpret prompt embedded in chain results for AI evaluation
- `chain blast-radius` — attack path analysis from chain execution JSON
- `chain detect` — Sigma and Wazuh detection rule generation from chain results

#### Configurable Model
- `COUNTERAGENT_MODEL` env var replaces all hardcoded model IDs
- Resolution order: CLI `--model` → env var → clear error (no silent fallback)

#### CLI
- Non-blocking PyPI version check on CLI startup
- AI-evaluation prompt embedded in all report formats (JSON + SARIF)

#### Testing
- Core module test suite: connection, discovery, and models

### Fixed
- Chain executor cross-platform path handling (Windows compatibility)
- Server info metadata: capabilities and transport now included
- Telemetry scanner checks capability values, not just key presence

### Changed

#### CI & Configuration
- Cross-repo config audit alignment (pre-commit revs, CI action versions, dep floors)
- pytest-asyncio dev dependency bumped to >=1.3.0
- actions/upload-artifact bumped to v7
- CodeRabbit configuration tuned (disabled overlapping CI checks)

#### Documentation
- Mintlify docs: module overview pages for audit, proxy, inject, and chain
- 13 stub pages filled with complete content across 3 doc expansion PRs
- Architecture.md updated for blast-radius and detect implementations
- v1.0 exit criteria added to Roadmap
- Interpret concept doc added and archived

## [0.2.0] — 2026-03-04

Expand platform to full four-module coverage: prompt injection framework, multi-agent attack
chain engine, and proxy transport extensions. Includes Mintlify documentation site and
security hardening in CI.

### Added

#### Inject Module
- 13 YAML payload templates across 3 technique categories (tool description poisoning,
  response manipulation, cross-tool escalation)
- MCP server builder with dynamic tool registration and configurable transport
- `inject serve` — launch a poisoned MCP server (stdio or streamable-http)
- `inject run` — execute a campaign against a target using the Anthropic tool-use API
- `inject list-payloads` — list available payload templates with metadata
- `inject score` — evaluate a response transcript against heuristic classifiers
- JSON campaign reports with per-turn scoring and summary statistics

#### Chain Module
- YAML chain loader and schema validator
- Cross-module validator: checks against audit scanner registry and inject technique enum
- Dry-run tracer with step-by-step execution preview
- 3 built-in attack chain templates: delegation hijack, MCP server compromise,
  RAG trust escalation
- `chain validate` — validate a chain YAML file
- `chain list-templates` — list available built-in templates
- `chain run --dry-run` — trace a chain without executing

#### Proxy Module Extensions
- SSE server-facing transport adapter
- Streamable HTTP server-facing transport adapter

#### Documentation
- Mintlify docs site expanded from 4 to 24 pages across 7 nav groups
- Inject module architecture and CLI reference
- Chain module architecture and CLI reference
- Demo GIF for inject and chain workflows

#### CI & Security
- `security-scan` job: bandit SAST + pip-audit dependency audit
- Bumped `actions/checkout` to v6

## [0.1.0] — 2026-03-02

First public release. MCP security audit scanner and traffic proxy, with full
OWASP MCP Top 10 coverage.

### Added

#### Audit Module
- 10 scanner modules covering the complete OWASP MCP Top 10 (MCP01–MCP10)
- Transport support: stdio, SSE, and Streamable HTTP
- `audit scan` — run security scanners against live MCP servers
- `audit enumerate` — list server capabilities without scanning
- `audit list-checks` — show available scanner modules and OWASP mappings
- `audit report` — convert saved scan JSON to other formats
- SARIF 2.1.0 report output (`--format sarif`) for GitHub Code Scanning integration
- JSON report output with finding deduplication and severity mapping

#### Proxy Module
- Interactive MCP traffic interceptor with TUI (Textual)
- `proxy start` — launch intercepting proxy with live message inspection
- `proxy replay` — replay captured sessions against live servers
- `proxy export` — export sessions to JSON
- `proxy inspect` — print session contents to stdout
- Intercept mode for message modification and forwarding
- Session recording and auto-save

#### Infrastructure
- Unified CLI via Typer (`counteragent audit ...`, `counteragent proxy ...`)
- CI pipeline: ruff lint/format, mypy, pytest on Ubuntu + Windows (Python 3.11–3.14)
- Pre-commit hooks: ruff, gitleaks, trailing whitespace, merge conflict detection
- 558 tests passing across Ubuntu and Windows
- Dependabot for GitHub Actions and pip ecosystem monitoring
- SECURITY.md with vulnerability reporting contact

#### Documentation
- Mintlify docs site at [docs.counteragent.dev](https://docs.counteragent.dev)
- Quickstart guide with install and first scan walkthrough
- CLI reference for all audit and proxy commands
- Scanner coverage page with OWASP MCP Top 10 mapping table

[0.3.0]: https://github.com/q-uestionable-AI/counteragent/releases/tag/v0.3.0
[0.2.0]: https://github.com/q-uestionable-AI/counteragent/releases/tag/v0.2.0
[0.1.0]: https://github.com/q-uestionable-AI/counteragent/releases/tag/v0.1.0
