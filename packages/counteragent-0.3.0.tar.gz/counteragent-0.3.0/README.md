# CounterAgent

[![CI](https://github.com/q-uestionable-AI/counteragent/actions/workflows/ci.yml/badge.svg)](https://github.com/q-uestionable-AI/counteragent/actions/workflows/ci.yml)
[![CodeQL](https://github.com/q-uestionable-AI/counteragent/actions/workflows/codeql.yml/badge.svg)](https://github.com/q-uestionable-AI/counteragent/actions/workflows/codeql.yml)
[![Python 3.11+](https://img.shields.io/badge/python-3.11+-blue.svg)](https://www.python.org/downloads/)
[![License: Apache 2.0](https://img.shields.io/badge/License-Apache_2.0-blue.svg)](https://opensource.org/licenses/Apache-2.0)
[![pre-commit](https://img.shields.io/badge/pre--commit-enabled-brightgreen?logo=pre-commit&logoColor=white)](https://github.com/pre-commit/pre-commit)
[![Docs](https://img.shields.io/badge/docs-counteragent.dev-8b5cf6)](https://docs.counteragent.dev)

**Open source AI agent red team platform for testing MCP server security, intercepting agent traffic, and mapping vulnerabilities to OWASP frameworks.**

Covers MCP server vulnerabilities, tool poisoning, prompt injection via tools, and agent-to-agent exploitation. Maps findings to [OWASP MCP Top 10](https://owasp.org/www-project-mcp-top-10/) and [OWASP Top 10 for Agentic AI](https://genai.owasp.org/).

> Research program by [Richard Spicer](https://richardspicer.io) · [GitHub](https://github.com/richardspicer)

---

## Install

```bash
pip install counteragent
```

Or from source:

```bash
git clone https://github.com/q-uestionable-AI/counteragent.git
cd counteragent
uv sync --group dev
```

---

## Usage

```bash
# Audit — scan an MCP server against the OWASP MCP Top 10
counteragent audit scan --transport stdio --command "python my_server.py"

# Proxy — intercept MCP traffic between client and server
counteragent proxy start --transport stdio --target-command "python my_server.py"

# Inject — list available poisoning payloads / serve a malicious MCP server
counteragent inject list-payloads
counteragent inject serve --transport stdio

# Chain — validate and trace multi-agent attack chains
counteragent chain list-templates
counteragent chain validate --chain-file chain.yaml
counteragent chain run --chain-file chain.yaml --dry-run
```

Full documentation at [docs.counteragent.dev](https://docs.counteragent.dev).

---

## Legal

All tools are intended for authorized security testing only. Only test systems you own, control, or have explicit permission to test. Responsible disclosure for all vulnerabilities discovered.

## License

[Apache 2.0](https://www.apache.org/licenses/LICENSE-2.0)

## AI Disclosure

This project uses a human-led, AI-augmented workflow. See [AI-STATEMENT.md](AI-STATEMENT.md).
