"""
Core benchmark runner — executes a single sample through a framework adapter.

No timeouts — every framework pipeline (including ARGUS multi-round debate)
runs to full completion regardless of how long it takes.
"""

import time
import threading
import psutil
from datetime import datetime
from .scorer import SCORER_MAP


def run_single(sample: dict, framework_fn, framework_name: str, model_name: str) -> dict:
    """
    Run one sample through *framework_fn* and return a metrics record.

    Parameters
    ----------
    sample : dict
        Must contain at least ``question``, ``answer``, ``dataset``,
        ``task_type``.  May also have ``choices`` (TruthfulQA).
    framework_fn : callable(sample_dict) -> dict
        Adapter that accepts the full sample dict and returns
        ``{"answer": str, "error": str}``.
    framework_name : str
    model_name : str
    """
    start_time = time.time()

    # ── Safe extraction ───────────────────────────────────────────
    sample_id    = sample.get("id", "unknown")
    dataset      = sample.get("dataset", "unknown")
    question     = sample.get("question", "")
    ground_truth = sample.get("answer", "")
    task_type    = sample.get("task_type", "classification")

    if not question:
        return _skip_record(sample_id, dataset, framework_name, model_name,
                            ground_truth, task_type, "Empty question")

    # ── System metrics before ─────────────────────────────────────
    proc = psutil.Process()
    ram_before = proc.memory_info().rss / (1024 * 1024)

    # ── Run framework — NO timeout, wait for full completion ──────
    result_holder = {}
    error_holder  = {}

    def _target():
        try:
            result_holder["out"] = framework_fn(sample)
        except Exception as exc:
            error_holder["err"] = str(exc)

    t = threading.Thread(target=_target, daemon=True)
    t.start()
    t.join()   # ← no timeout argument: waits forever until done

    latency = time.time() - start_time
    ram_after = proc.memory_info().rss / (1024 * 1024)
    ram_delta = max(0.0, ram_after - ram_before)
    cpu_pct   = psutil.cpu_percent(interval=None)

    # Thread is always done here (timed_out is always False)
    success = "err" not in error_holder

    # ── Extract answer ────────────────────────────────────────────
    answer = _extract_answer(result_holder, success)

    # ── Score ─────────────────────────────────────────────────────
    score = 0.0
    if success and answer and answer != "ERROR":
        scorer_fn = SCORER_MAP.get(task_type)
        if scorer_fn:
            try:
                score = scorer_fn(answer, ground_truth)
            except Exception:
                score = 0.0

    # ── Truncate question for storage ─────────────────────────────
    display_q = (question[:300] + "...") if len(question) > 300 else question

    return {
        "sample_id":    sample_id,
        "dataset":      dataset,
        "framework":    framework_name,
        "model":        model_name,
        "question":     display_q,
        "expected":     ground_truth,
        "answer":       answer,
        "score":        score,
        "task_type":    task_type,
        "latency_sec":  round(latency, 4),
        "ram_delta_mb": round(ram_delta, 2),
        "cpu_percent":  round(cpu_pct, 1),
        "success":      success,
        "timed_out":    False,          # never times out now
        "error":        error_holder.get("err", ""),
        "timestamp":    datetime.now().isoformat(),
    }


# ── helpers ───────────────────────────────────────────────────────────

def _extract_answer(result_holder: dict, success: bool) -> str:
    if not success:
        return "ERROR"
    out = result_holder.get("out")
    if isinstance(out, dict):
        return str(out.get("answer", "")).strip()
    if isinstance(out, str):
        return out.strip()
    return str(out).strip() if out is not None else ""


def _skip_record(sid, ds, fw, model, gt, tt, reason):
    return {
        "sample_id": sid, "dataset": ds, "framework": fw, "model": model,
        "question": "", "expected": gt, "answer": "SKIPPED", "score": 0.0,
        "task_type": tt, "latency_sec": 0.0, "ram_delta_mb": 0.0,
        "cpu_percent": 0.0, "success": False, "timed_out": False,
        "error": reason, "timestamp": datetime.now().isoformat(),
    }
