"""
Prompt templates for benchmark tasks.

Each dataset gets a concise, task-specific system prompt that guides the LLM
to produce a short, parseable answer — critical for throughput on local models.
"""

# ── System prompts keyed by dataset name ──────────────────────────────
# These are deliberately short to minimize input tokens on a 3B model.

SYSTEM_PROMPTS = {
    "fever": (
        "You are a fact-verification classifier. "
        "Given a claim, respond with ONLY one label: SUPPORTS, REFUTES, or NOT ENOUGH INFO. "
        "Do not explain."
    ),
    "boolq": (
        "Read the passage and answer the question. "
        "Respond with ONLY True or False. Do not explain."
    ),
    "arc": (
        "Answer the multiple-choice question. "
        "Respond with ONLY the letter of the correct answer (A, B, C, or D). "
        "Do not explain."
    ),
    "truthful_qa": (
        "Choose the correct answer from the numbered options. "
        "Respond with ONLY the index number (0, 1, 2, ...) of the correct answer. "
        "Do not explain."
    ),
    "multi_nli": (
        "Determine the logical relationship between the premise and the hypothesis. "
        "Respond with ONLY one of: entailment, neutral, contradiction. "
        "Do not explain."
    ),
}

# Fallback for unknown datasets
_DEFAULT_SYSTEM = "Answer the following question as concisely as possible."


def build_prompt(sample: dict) -> tuple:
    """
    Build (system_prompt, user_prompt) for a sample.

    Args:
        sample: dict with keys  id, question, answer, dataset, task_type,
                and optionally  choices  (for truthful_qa).

    Returns:
        (system_prompt: str, user_prompt: str)
    """
    dataset = sample.get("dataset", "")
    question = sample.get("question", "")
    choices = sample.get("choices", [])

    system = SYSTEM_PROMPTS.get(dataset, _DEFAULT_SYSTEM)

    # For TruthfulQA, append the numbered choices to the user prompt
    if dataset == "truthful_qa" and choices:
        choices_text = "\n".join(f"  {i}: {c}" for i, c in enumerate(choices))
        user = f"{question}\n\nOptions:\n{choices_text}"
    else:
        user = question

    return system, user
