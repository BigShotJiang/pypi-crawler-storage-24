import json
import os
import random
import requests
import tempfile
from datasets import load_dataset
from config import MAX_SAMPLES

DATA_DIR = "data"


def save_jsonl(data, filename):
    os.makedirs(DATA_DIR, exist_ok=True)
    filepath = os.path.join(DATA_DIR, filename)
    with open(filepath, 'w', encoding='utf-8') as f:
        for item in data:
            f.write(json.dumps(item) + '\n')
    print(f"Saved {len(data)} items to {filepath}")


# ─────────────────────────────────────────────
# FEVER  — script-based HF dataset is broken;
#          download directly from fever.ai instead
# ─────────────────────────────────────────────
FEVER_URLS = {
    "paper_test":  "https://fever.ai/download/fever/paper_test.jsonl",
    "paper_dev":   "https://fever.ai/download/fever/paper_dev.jsonl",
}

LABEL_MAP = {
    "SUPPORTS":     "SUPPORTS",
    "REFUTES":      "REFUTES",
    "NOT ENOUGH INFO": "NOT ENOUGH INFO",
    # numeric variants from some mirrors
    0: "SUPPORTS",
    1: "REFUTES",
    2: "NOT ENOUGH INFO",
}


def load_fever(split: str = "paper_test") -> list[dict]:
    print("Loading FEVER (direct download from fever.ai)...")
    url = FEVER_URLS.get(split)
    if not url:
        raise ValueError(f"Unknown FEVER split '{split}'. Choose from: {list(FEVER_URLS)}")

    response = requests.get(url, timeout=60)
    response.raise_for_status()

    data = []
    for i, line in enumerate(response.text.strip().splitlines()):
        row = json.loads(line)
        label = LABEL_MAP.get(row.get("label", ""), row.get("label", ""))
        data.append({
            "id":        f"fever_{i}",
            "question":  row["claim"],
            "answer":    label,
            "dataset":   "fever",
            "task_type": "classification",
        })

    print(f"  Loaded {len(data)} FEVER rows from '{split}'")
    return data


# ─────────────────────────────────────────────
# TruthfulQA
# ─────────────────────────────────────────────
def load_truthful_qa() -> list[dict]:
    print("Loading TruthfulQA...")
    ds = load_dataset("truthful_qa", "multiple_choice", split="validation")
    data = []
    for i, row in enumerate(ds):
        labels: list = row["mc1_targets"]["labels"]
        try:
            correct_idx = labels.index(1)
        except ValueError:
            correct_idx = 0          # fallback: shouldn't happen in clean data
        data.append({
            "id":        f"truthful_qa_{i}",
            "question":  row["question"],
            "answer":    str(correct_idx),
            "choices":   row["mc1_targets"]["choices"],   # keep for eval context
            "dataset":   "truthful_qa",
            "task_type": "mcq",
        })
    return data


# ─────────────────────────────────────────────
# BoolQ
# ─────────────────────────────────────────────
def load_boolq() -> list[dict]:
    print("Loading BoolQ...")
    ds = load_dataset("google/boolq", split="validation")
    data = []
    for i, row in enumerate(ds):
        data.append({
            "id":        f"boolq_{i}",
            "question":  f"Passage: {row['passage']}\nQuestion: {row['question']}?",
            "answer":    str(row["answer"]),
            "dataset":   "boolq",
            "task_type": "classification",
        })
    return data


# ─────────────────────────────────────────────
# ARC
# ─────────────────────────────────────────────
def load_arc() -> list[dict]:
    print("Loading ARC...")
    ds = load_dataset("allenai/ai2_arc", "ARC-Easy", split="test")
    data = []
    for i, row in enumerate(ds):
        choices_text = "\n".join(
            f"{label}: {text}"
            for label, text in zip(row["choices"]["label"], row["choices"]["text"])
        )
        data.append({
            "id":        f"arc_{i}",
            "question":  f"{row['question']}\nChoices:\n{choices_text}",
            "answer":    row["answerKey"],
            "dataset":   "arc",
            "task_type": "mcq",
        })
    return data


# ─────────────────────────────────────────────
# MultiNLI
# ─────────────────────────────────────────────
NLI_LABEL_MAP = {0: "entailment", 1: "neutral", 2: "contradiction"}


def load_multi_nli() -> list[dict]:
    print("Loading MultiNLI...")
    ds = load_dataset("nyu-mll/multi_nli", split="validation_matched")
    data = []
    for i, row in enumerate(ds):
        data.append({
            "id":        f"multi_nli_{i}",
            "question":  f"Premise: {row['premise']}\nHypothesis: {row['hypothesis']}",
            "answer":    NLI_LABEL_MAP.get(row["label"], str(row["label"])),
            "dataset":   "multi_nli",
            "task_type": "classification",
        })
    return data


# ─────────────────────────────────────────────
# Main
# ─────────────────────────────────────────────
def main():
    loaders = {
        "fever":       load_fever,
        "truthful_qa": load_truthful_qa,
        "boolq":       load_boolq,
        "arc":         load_arc,
        "multi_nli":   load_multi_nli,
    }

    for name, loader in loaders.items():
        try:
            data = loader()
        except Exception as exc:
            print(f"[{name}] ❌ Failed to load: {exc}")
            continue

        random.seed(42)
        random.shuffle(data)

        limit = MAX_SAMPLES.get(name, 0)
        if limit > 0:
            data = data[:limit]

        save_jsonl(data, f"{name}.jsonl")
        print(f"[{name}] ✅ Total saved: {len(data)}\n")


if __name__ == "__main__":
    main()