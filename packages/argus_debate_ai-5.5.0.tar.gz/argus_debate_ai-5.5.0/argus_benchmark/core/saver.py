import os
import json
from config import RESULTS_DIR


def save_raw_results(timestamp, model_name, dataset_name, records, framework_name, n_samples):
    safe_model = model_name.replace(":", "_").replace("/", "_")
    safe_fw = framework_name.replace(" ", "_")
    dir_path = os.path.join(RESULTS_DIR, safe_model, "raw")
    os.makedirs(dir_path, exist_ok=True)

    # Include framework name in filename to avoid overwrites
    filename = f"{timestamp}_{safe_model}_{safe_fw}_{dataset_name}.json"
    filepath = os.path.join(dir_path, filename)

    data = {
        "meta": {
            "timestamp": timestamp,
            "model": model_name,
            "dataset": dataset_name,
            "framework": framework_name,
            "n_samples": n_samples,
        },
        "records": records
    }

    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, default=str)


def save_final_summary(timestamp, model_name, summary_data):
    safe_model = model_name.replace(":", "_").replace("/", "_")
    dir_path = os.path.join(RESULTS_DIR, safe_model)
    os.makedirs(dir_path, exist_ok=True)

    filename = f"{timestamp}_{safe_model}_FINAL.json"
    filepath = os.path.join(dir_path, filename)

    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(summary_data, f, indent=2, default=str)
