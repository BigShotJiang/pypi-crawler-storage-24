# config.py
# ── LLM Configuration ─────────────────────────────────────────────────
# Local llama-server (OpenAI-compatible) running at:
#   D:\llama_bin\llama-server.exe -m D:\models\qwen2.5-3b\... --host 0.0.0.0 --port 8080

LLM_BASE_URL = "http://localhost:8080/v1"   # OpenAI-compatible endpoint
LLM_API_KEY  = "not-needed"                 # local server, no key required
LLM_MODEL    = "qwen2.5-3b"                # display/model name sent to server
LLM_TIMEOUT  = None   # No timeout — let every LLM call run to completion

AVAILABLE_MODELS = [
    "qwen2.5-3b",
]

# ── Task-specific max_tokens (huge perf win on local models) ──────────
# Classification tasks only need a single label word: "SUPPORTS", "True", etc.
# MCQ tasks only need a single letter/number: "A", "0", etc.
MAX_TOKENS_BY_TASK = {
    "classification": 15,   # e.g. "NOT ENOUGH INFO" = ~4 tokens + safety
    "mcq":            10,   # e.g. "A" or "0" = 1 token + safety
    "qa":             256,  # free-form answer
}

# ── Concurrency ───────────────────────────────────────────────────────
# Number of concurrent requests to llama-server.
# llama-server with -np 1 (default) handles 1 at a time;
# set higher if you launched with -np 2 or more.
CONCURRENT_WORKERS = 1

# ── Incremental save interval ────────────────────────────────────────
# Save partial results every N samples to avoid data loss on crash
SAVE_EVERY_N = 5    # flush full JSON every 5 samples; JSONL written per-record

# ── Sampling (0 = all) ───────────────────────────────────────────────
MAX_SAMPLES = {
    "fever":       0,
    "truthful_qa": 0,
    "boolq":       0,
    "arc":         0,
    "multi_nli":   0,
}

# No timeout — let the full framework pipeline run to completion.
# ARGUS runs a multi-round debate (5+ chained LLM calls) that can take
# many minutes per sample on a local 3B model.
QUERY_TIMEOUT_SEC = None

# Frameworks to benchmark against ARGUS
COMPETITOR_FRAMEWORKS = ["LangChain", "AutoGen", "CrewAI", "LangGraph"]

# Results output directory
RESULTS_DIR = "results"
REPORTS_DIR = "reports"
