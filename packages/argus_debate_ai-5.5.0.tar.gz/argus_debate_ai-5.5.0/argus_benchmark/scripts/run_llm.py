"""
Main benchmark driver — runs all frameworks across all datasets.

Optimised for 8 GB RAM laptops:
  • Stratified subset sampling (--subset N) preserving label distribution.
  • Incremental saves every SAVE_EVERY_N samples (no data loss on crash).
  • gc.collect() between framework runs to free memory.
  • Lazy framework imports — only loaded when actually used.
  • Running accuracy display in progress bar.
  • Time estimation before running.
"""

import argparse
import gc
import json
import math
import os
import random
import time
from collections import Counter, defaultdict
from datetime import datetime, timedelta

from tqdm import tqdm

from config import COMPETITOR_FRAMEWORKS, SAVE_EVERY_N
from core.dataset_loader import DATA_DIR
from core.benchmark_runner import run_single
from core.saver import save_raw_results, save_final_summary


# ── Lazy framework loader ─────────────────────────────────────────────

def _load_framework(name: str):
    """Import framework runner lazily and return its .run function."""
    try:
        if name == "ARGUS":
            import frameworks.argus_runner as m
        elif name == "LangChain":
            import frameworks.langchain_runner as m
        elif name == "AutoGen":
            import frameworks.autogen_runner as m
        elif name == "CrewAI":
            import frameworks.crewai_runner as m
        elif name == "LangGraph":
            import frameworks.langgraph_runner as m
        else:
            return None
        return m.run
    except ImportError as e:
        print(f"  ⚠️  Cannot import {name}: {e}")
        return None


# ── JSONL loader ──────────────────────────────────────────────────────

def load_jsonl(filename: str) -> list[dict]:
    filepath = os.path.join(DATA_DIR, filename)
    if not os.path.exists(filepath):
        print(f"  ❌ File not found: {filepath}. Run core/dataset_loader.py first.")
        return []

    data = []
    with open(filepath, "r", encoding="utf-8") as f:
        for line_num, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            try:
                row = json.loads(line)
            except json.JSONDecodeError:
                continue
            if "question" not in row or "answer" not in row:
                continue
            row.setdefault("task_type", "classification")
            row.setdefault("dataset", filename.replace(".jsonl", ""))
            row.setdefault("id", f"sample_{line_num}")
            data.append(row)
    return data


# ── Stratified subset sampler ─────────────────────────────────────────

def stratified_sample(data: list[dict], n: int, seed: int = 42) -> list[dict]:
    """
    Draw *n* samples from *data* preserving the label distribution
    of the ``answer`` field (stratified sampling).

    If a label's proportional share rounds to 0, it still gets 1 sample
    so that no class is lost entirely.
    """
    if n >= len(data):
        return data

    rng = random.Random(seed)

    # Group samples by label
    buckets: dict[str, list[dict]] = defaultdict(list)
    for row in data:
        buckets[str(row.get("answer", ""))].append(row)

    total = len(data)

    # Calculate how many samples each label gets (proportional)
    allocation: dict[str, int] = {}
    allocated = 0
    for label, items in sorted(buckets.items(), key=lambda x: -len(x[1])):
        share = len(items) / total * n
        count = max(1, round(share))  # at least 1 per label
        allocation[label] = count
        allocated += count

    # Adjust if we over-allocated (trim from the largest buckets)
    while allocated > n:
        largest = max(allocation, key=lambda k: allocation[k])
        if allocation[largest] > 1:
            allocation[largest] -= 1
            allocated -= 1
        else:
            break

    # Adjust if we under-allocated (add to the largest buckets)
    while allocated < n:
        largest = max(allocation, key=lambda k: len(buckets[k]))
        allocation[largest] += 1
        allocated += 1

    # Draw stratified random samples
    subset = []
    for label, count in allocation.items():
        pool = buckets[label]
        rng.shuffle(pool)
        subset.extend(pool[:count])

    rng.shuffle(subset)
    return subset


# ── Estimated times per framework (seconds per sample) ────────────────
# Based on local 3B model @ Q4_K_M with max_tokens=15 for classification.

_EST_SECS = {
    "LangChain": 2.0,     # 1 LLM call
    "AutoGen":   5.0,     # 2 multi-agent calls
    "CrewAI":    8.0,     # 2-3 agent calls
    "LangGraph": 5.0,     # 2 graph steps
    "ARGUS":     120.0,   # full 5-layer debate pipeline
}


def _estimate_time(frameworks: list[str], n_samples_per_ds: int,
                   n_datasets: int) -> str:
    """Return a human-readable ETA string."""
    total_secs = 0
    for fw in frameworks:
        per_sample = _EST_SECS.get(fw, 5.0)
        total_secs += per_sample * n_samples_per_ds * n_datasets

    td = timedelta(seconds=int(total_secs))
    hours, remainder = divmod(td.seconds + td.days * 86400, 3600)
    minutes, secs = divmod(remainder, 60)

    parts = []
    if hours:
        parts.append(f"{hours}h")
    if minutes:
        parts.append(f"{minutes}m")
    if secs or not parts:
        parts.append(f"{secs}s")
    return " ".join(parts)


# ── Metrics helpers ───────────────────────────────────────────────────

_ZERO = {"accuracy": 0.0, "avg_latency": 0.0, "avg_ram": 0.0, "success_rate": 0.0}


def _calc_averages(records: list[dict]) -> dict:
    if not records:
        return dict(_ZERO)

    ok = [r for r in records if r.get("success")]
    n_ok = len(ok)
    n_total = len(records)

    if n_ok == 0:
        return {**_ZERO, "success_rate": 0.0}

    return {
        "accuracy":     round(sum(r["score"]        for r in ok) / n_ok, 4),
        "avg_latency":  round(sum(r["latency_sec"]  for r in ok) / n_ok, 4),
        "avg_ram":      round(sum(r["ram_delta_mb"] for r in ok) / n_ok, 4),
        "success_rate": round(n_ok / n_total, 4),
    }


# ── Pretty-print summary ─────────────────────────────────────────────

def _print_summary(summary_data: dict) -> None:
    try:
        from tabulate import tabulate
    except ImportError:
        tabulate = None

    rows = []
    for fw, ds_data in summary_data.get("summary", {}).items():
        for ds, m in ds_data.items():
            if ds == "overall" or not isinstance(m, dict):
                continue
            rows.append([
                fw, ds,
                f'{m.get("accuracy",0):.4f}',
                f'{m.get("avg_latency",0):.1f}s',
                f'{m.get("avg_ram",0):.0f}MB',
                f'{m.get("success_rate",0):.0%}',
            ])

    if not rows:
        print("\n  No results to display.")
        return

    header = ["Framework", "Dataset", "Accuracy", "Latency", "RAM", "Success"]
    if tabulate:
        print("\n" + tabulate(rows, headers=header, tablefmt="grid"))
    else:
        print(f"\n{'  '.join(f'{h:<12}' for h in header)}")
        for r in rows:
            print("  ".join(f"{c:<12}" for c in r))


# ── Main driver ───────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="ARGUS Benchmark Runner")
    parser.add_argument("--model", required=True,
                        help="Model name sent to the local OpenAI-compatible server")
    parser.add_argument("--datasets", nargs="+",
                        default=["fever", "truthful_qa", "boolq", "arc", "multi_nli"])
    parser.add_argument("--frameworks", nargs="+",
                        default=["ARGUS"] + COMPETITOR_FRAMEWORKS)
    parser.add_argument("--dry-run", action="store_true",
                        help="Only 3 samples per dataset")
    parser.add_argument("--subset", type=int, default=0,
                        help="Stratified subset size per dataset (0 = all). "
                             "e.g. --subset 100 draws 100 samples preserving "
                             "original label distribution.")
    args = parser.parse_args()

    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    model = args.model

    summary = {
        "meta": {"timestamp": ts, "model": model,
                 "frameworks": args.frameworks, "datasets": args.datasets,
                 "subset_per_dataset": args.subset or "all"},
        "summary": {fw: {} for fw in args.frameworks},
    }

    # ── Load all datasets first to show time estimate ─────────────
    all_data: dict[str, list[dict]] = {}
    for ds_name in args.datasets:
        raw = load_jsonl(f"{ds_name}.jsonl")
        if args.dry_run:
            raw = raw[:3]
        elif args.subset > 0:
            raw = stratified_sample(raw, args.subset)
        all_data[ds_name] = raw

    # ── Show plan + time estimate ─────────────────────────────────
    total_samples = sum(len(v) for v in all_data.values())
    samples_per_ds = total_samples // max(len(args.datasets), 1)
    eta = _estimate_time(args.frameworks, samples_per_ds, len(args.datasets))

    print(f"\n📋 Benchmark Plan:")
    print(f"   Model:      {model}")
    print(f"   Frameworks: {', '.join(args.frameworks)}")
    print(f"   Datasets:   {', '.join(args.datasets)}")
    for ds_name, ds_data in all_data.items():
        dist = Counter(str(row.get("answer", "")) for row in ds_data)
        dist_str = ", ".join(f"{lbl}={cnt}" for lbl, cnt in dist.most_common(6))
        print(f"     {ds_name:15s}: {len(ds_data):>5d} samples  [{dist_str}]")
    print(f"   Total LLM calls: {total_samples} × {len(args.frameworks)} = "
          f"{total_samples * len(args.frameworks)}")
    print(f"   ⏱  Estimated time: ~{eta}")
    print()

    # ── Run benchmarks ────────────────────────────────────────────
    run_start = time.time()

    for ds_name in args.datasets:
        data = all_data[ds_name]
        print(f"\n{'='*60}")
        print(f"  Dataset: {ds_name}  ({len(data)} samples)")
        print(f"{'='*60}")

        if not data:
            print(f"  ⚠️  No data, skipping.")
            for fw in args.frameworks:
                summary["summary"][fw][ds_name] = dict(_ZERO)
            continue

        for fw_name in args.frameworks:
            print(f"\n  ── {fw_name} ──")
            fw_fn = _load_framework(fw_name)
            if fw_fn is None:
                print(f"    ⚠️  Skipped (not available)")
                summary["summary"][fw_name][ds_name] = dict(_ZERO)
                continue

            # Bind fn + model via default-arg to avoid late-binding closure
            def _make_adapter(fn=fw_fn, m=model):
                return lambda sample: fn(sample, m)
            adapter = _make_adapter()

            records: list[dict] = []
            running_correct = 0
            running_total   = 0

            # ── JSONL stream file: one line written per record immediately ──
            safe_model = model.replace(":", "_").replace("/", "_")
            safe_fw    = fw_name.replace(" ", "_")
            stream_dir = os.path.join("results", safe_model, "stream")
            os.makedirs(stream_dir, exist_ok=True)
            stream_path = os.path.join(
                stream_dir,
                f"{ts}_{safe_model}_{safe_fw}_{ds_name}.jsonl"
            )
            stream_fh = open(stream_path, "a", encoding="utf-8")

            desc = f"    [{fw_name}|{ds_name}]"
            with tqdm(total=len(data), desc=desc, unit="q",
                      bar_format="{desc} {percentage:3.0f}%|{bar}| {n_fmt}/{total_fmt} "
                                 "[{elapsed}<{remaining}, {rate_fmt}] acc={postfix}") as pbar:
                pbar.set_postfix_str("—")

                for i, sample in enumerate(data):
                    try:
                        record = run_single(sample, adapter, fw_name, model)
                    except Exception as exc:
                        record = {
                            "sample_id": sample.get("id", "?"),
                            "dataset": ds_name, "framework": fw_name,
                            "model": model, "question": "",
                            "expected": sample.get("answer", ""),
                            "answer": "ERROR", "score": 0.0,
                            "task_type": sample.get("task_type", "?"),
                            "latency_sec": 0.0, "ram_delta_mb": 0.0,
                            "cpu_percent": 0.0, "success": False,
                            "timed_out": False, "error": str(exc),
                            "timestamp": datetime.now().isoformat(),
                        }
                    records.append(record)

                    # ① Append this record to JSONL stream immediately
                    stream_fh.write(json.dumps(record, default=str) + "\n")
                    stream_fh.flush()

                    # Running accuracy display
                    if record.get("success"):
                        running_total += 1
                        running_correct += record.get("score", 0)
                    acc_str = (f"{running_correct/running_total:.2%}"
                               if running_total else "—")
                    pbar.set_postfix_str(acc_str)
                    pbar.update(1)

                    # ② Full JSON flush every SAVE_EVERY_N records
                    if (i + 1) % SAVE_EVERY_N == 0:
                        save_raw_results(ts, model, ds_name, records,
                                         fw_name, len(data))

            stream_fh.close()

            # Final full JSON save for this (framework, dataset)
            save_raw_results(ts, model, ds_name, records, fw_name, len(data))
            metrics = _calc_averages(records)
            summary["summary"][fw_name][ds_name] = metrics

            ok = sum(1 for r in records if r.get("success"))
            print(f"    ✅ {ok}/{len(records)} succeeded  |  "
                  f"acc={metrics['accuracy']:.4f}  |  "
                  f"lat={metrics['avg_latency']:.1f}s")
            print(f"    💾 Stream saved: {stream_path}")

            # Free heavy framework objects between runs
            del records, adapter
            gc.collect()

    # ── Overall averages ──────────────────────────────────────────
    for fw in args.frameworks:
        fw_data = summary["summary"].get(fw, {})
        ds_list = [v for k, v in fw_data.items()
                   if k != "overall" and isinstance(v, dict)]
        if ds_list:
            n = len(ds_list)
            summary["summary"][fw]["overall"] = {
                "accuracy":     round(sum(m.get("accuracy", 0)     for m in ds_list) / n, 4),
                "avg_latency":  round(sum(m.get("avg_latency", 0)  for m in ds_list) / n, 4),
                "avg_ram":      round(sum(m.get("avg_ram", 0)      for m in ds_list) / n, 4),
                "success_rate": round(sum(m.get("success_rate", 0) for m in ds_list) / n, 4),
            }
        else:
            summary["summary"][fw]["overall"] = dict(_ZERO)

    elapsed = time.time() - run_start
    elapsed_str = str(timedelta(seconds=int(elapsed)))

    save_final_summary(ts, model, summary)
    _print_summary(summary)
    print(f"\n⏱  Total wall-clock time: {elapsed_str}")
    print(f"🎉 Done.  Results in results/{model.replace(':','_')}/")


if __name__ == "__main__":
    main()
