import os
import json
import glob
from collections import defaultdict
import numpy as np

def load_results():
    results_dir = os.path.join(os.path.dirname(__file__), "..", "results")
    if not os.path.exists(results_dir):
        print(f"Results directory not found at {results_dir}")
        return []
    
    data = []
    # Search all subdirectories matching *FINAL.json
    for root, _, files in os.walk(results_dir):
        for f in files:
             if f.endswith("FINAL.json"):
                 with open(os.path.join(root, f), 'r', encoding='utf-8') as file:
                     data.append(json.load(file))
    return data

def generate_table_generic(title, metric_key, data, filename):
    frameworks = ["ARGUS", "LangChain", "AutoGen", "CrewAI", "LangGraph"]
    datasets = ["fever", "truthful_qa", "boolq", "arc", "multi_nli"]
    
    # Structure: stats[framework][dataset] = [val1, val2, ...]
    stats = defaultdict(lambda: defaultdict(list))
    for run in data:
         for fw in frameworks:
             if fw not in run["summary"]: continue
             for ds in datasets:
                  if ds in run["summary"][fw] and metric_key in run["summary"][fw][ds]:
                      stats[fw][ds].append(run["summary"][fw][ds][metric_key])
             
             if "overall" in run["summary"][fw] and metric_key in run["summary"][fw]["overall"]:
                 stats[fw]["overall"].append(run["summary"][fw]["overall"][metric_key])

    table_data = []
    
    # Calculate means and formats
    for fw in frameworks:
        row = [fw]
        for col in datasets + ["overall"]:
            vals = stats[fw][col]
            if not vals:
                 row.append("-")
            else:
                 mean = np.mean(vals)
                 std = np.std(vals, ddof=1) if len(vals) > 1 else 0.0
                 row.append(f"{mean:.2f} \\pm {std:.2f}")
        table_data.append(row)
        
    latex = "\\begin{table}[h]\n"
    latex += "\\centering\n"
    latex += f"\\caption{{{title}}}\n"
    latex += "\\begin{tabular}{l" + "c" * (len(datasets)) + "|c}\n"
    latex += "\\toprule\n"
    latex += "Framework & FEVER & TruthfulQA & BoolQ & ARC & MultiNLI & Overall \\\\\n"
    latex += "\\midrule\n"
    
    for row in table_data:
        # Simple string join
        latex += " & ".join([str(x).replace("+-", "\\pm") for x in row]) + " \\\\\n"
    
    latex += "\\bottomrule\n"
    latex += "\\end{tabular}\n"
    latex += "\\end{table}\n"
    
    reports_dir = os.path.join(os.path.dirname(__file__), "..", "reports")
    os.makedirs(reports_dir, exist_ok=True)
    
    with open(os.path.join(reports_dir, filename), "w") as f:
         f.write(latex)
    
    print(f"Generated {filename}")

if __name__ == "__main__":
    data = load_results()
    if not data:
         print("No data found to generate tables.")
         exit()
         
    generate_table_generic("Accuracy Comparison Across Frameworks and Benchmarks", "accuracy", data, "table_accuracy.tex")
    generate_table_generic("Latency Comparison Across Frameworks and Benchmarks (seconds)", "avg_latency", data, "table_latency.tex")
