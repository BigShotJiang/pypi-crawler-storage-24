import os
import json
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from collections import defaultdict

FRAMEWORK_COLORS = {
    "ARGUS":      "#1f77b4",
    "LangChain":  "#ff7f0e",
    "AutoGen":    "#2ca02c",
    "CrewAI":     "#d62728",
    "LangGraph":  "#9467bd",
}

def load_results():
    results_dir = os.path.join(os.path.dirname(__file__), "..", "results")
    if not os.path.exists(results_dir): return []
    data = []
    for root, _, files in os.walk(results_dir):
        for f in files:
             if f.endswith("FINAL.json"):
                 with open(os.path.join(root, f), 'r', encoding='utf-8') as file:
                     data.append(json.load(file))
    return data

def plot_accuracy_bar(data, reports_dir):
    frameworks = list(FRAMEWORK_COLORS.keys())
    datasets = ["fever", "truthful_qa", "boolq", "arc", "multi_nli"]
    
    # [framework][dataset] = [acc_model1, acc_model2, ...]
    stats = defaultdict(lambda: defaultdict(list))
    for run in data:
         for fw in frameworks:
             if fw in run.get("summary", {}):
                 for ds in datasets:
                     if ds in run["summary"][fw] and "accuracy" in run["summary"][fw][ds]:
                          stats[fw][ds].append(run["summary"][fw][ds]["accuracy"])
                          
    x = np.arange(len(datasets))
    width = 0.15
    fig, ax = plt.subplots(figsize=(12, 6))

    for i, fw in enumerate(frameworks):
        means = [np.mean(stats[fw][ds]) if stats[fw][ds] else 0 for ds in datasets]
        stds = [np.std(stats[fw][ds], ddof=1) if len(stats[fw][ds]) > 1 else 0 for ds in datasets]
        ax.bar(x + i*width, means, width, label=fw, yerr=stds, capsize=3, color=FRAMEWORK_COLORS[fw])

    ax.set_ylabel('Accuracy')
    ax.set_title('Accuracy Comparison: ARGUS vs Competitor Frameworks')
    ax.set_xticks(x + width * 2)
    ax.set_xticklabels([d.upper() for d in datasets])
    ax.legend(title='Frameworks')
    
    plt.tight_layout()
    plt.savefig(os.path.join(reports_dir, 'plot_accuracy_bar.png'), dpi=200)
    plt.close()

def plot_latency_heatmap(data, reports_dir):
    frameworks = list(FRAMEWORK_COLORS.keys())
    models = sorted(list(set(run["meta"]["model"] for run in data)))
    
    if not models: return

    heatmap_data = np.zeros((len(frameworks), len(models)))
    
    for i, fw in enumerate(frameworks):
        for j, model in enumerate(models):
             # Find runs for this model
             model_runs = [r for r in data if r["meta"]["model"] == model]
             lats = []
             for mr in model_runs:
                  if fw in mr.get("summary", {}) and "overall" in mr["summary"][fw]:
                       lats.append(mr["summary"][fw]["overall"].get("avg_latency", 0))
             heatmap_data[i, j] = np.mean(lats) if lats else 0
             
    fig, ax = plt.subplots(figsize=(10, 8))
    sns.heatmap(heatmap_data, annot=True, fmt=".1f", xticklabels=models, yticklabels=frameworks, cmap="YlOrRd", ax=ax)
    ax.set_title('Average Query Latency (seconds) — Framework × Model')
    plt.tight_layout()
    plt.savefig(os.path.join(reports_dir, 'plot_latency_heatmap.png'), dpi=200)
    plt.close()

def plot_efficiency_scatter(data, reports_dir):
    frameworks = list(FRAMEWORK_COLORS.keys())
    models = sorted(list(set(run["meta"]["model"] for run in data)))
    
    fig, ax = plt.subplots(figsize=(10, 8))
    
    markers = ['o', 's', '^', 'D', 'v', '<', '>']
    model_marker = {m: markers[i % len(markers)] for i, m in enumerate(models)}

    for fw in frameworks:
        for model in models:
            model_runs = [r for r in data if r["meta"]["model"] == model]
            accs = []
            lats = []
            for mr in model_runs:
                if fw in mr.get("summary", {}) and "overall" in mr["summary"][fw]:
                    accs.append(mr["summary"][fw]["overall"].get("accuracy", 0))
                    lats.append(mr["summary"][fw]["overall"].get("avg_latency", 0))
            if accs and lats:
                ax.scatter(np.mean(lats), np.mean(accs), 
                           c=[FRAMEWORK_COLORS[fw]], 
                           marker=model_marker[model], 
                           s=100,
                           label=f"{fw} ({model})" if (model == models[0]) else "")
                ax.annotate(f"{fw}\n{model}", (np.mean(lats), np.mean(accs)), fontsize=8, alpha=0.7)

    ax.set_xlabel('Average Latency (sec)')
    ax.set_ylabel('Average Accuracy')
    ax.set_title('Accuracy vs Latency — Efficiency Frontier')
    plt.tight_layout()
    plt.savefig(os.path.join(reports_dir, 'plot_efficiency_scatter.png'), dpi=200)
    plt.close()


def main():
    data = load_results()
    if not data:
        print("No data found to generate plots.")
        return

    reports_dir = os.path.join(os.path.dirname(__file__), "..", "reports")
    os.makedirs(reports_dir, exist_ok=True)

    try:
        plt.style.use("seaborn-v0_8-whitegrid")
    except OSError:
        try:
            plt.style.use("seaborn-whitegrid")
        except OSError:
            pass  # use default matplotlib style
    
    plot_accuracy_bar(data, reports_dir)
    plot_latency_heatmap(data, reports_dir)
    plot_efficiency_scatter(data, reports_dir)
    print("Generated plot_accuracy_bar.png, plot_latency_heatmap.png, plot_efficiency_scatter.png")

if __name__ == "__main__":
    main()
