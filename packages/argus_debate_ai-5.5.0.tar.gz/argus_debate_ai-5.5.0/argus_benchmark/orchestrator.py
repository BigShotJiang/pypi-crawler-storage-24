"""
ARGUS Benchmarking Orchestrator.

Checks that the local LLM server is reachable, then dispatches
the benchmark run and report generation.
"""

import sys
import subprocess
import argparse
import json
import urllib.request
from config import AVAILABLE_MODELS, LLM_BASE_URL


def check_llm_server() -> bool:
    """Verify the local OpenAI-compatible server is running."""
    try:
        req = urllib.request.Request(f"{LLM_BASE_URL}/models", method="GET")
        with urllib.request.urlopen(req, timeout=5) as resp:
            data = json.loads(resp.read().decode())
            models = [m.get("id", "?") for m in data.get("data", [])]
            if models:
                print(f"✅ LLM server OK — models: {', '.join(models)}")
            else:
                print("✅ LLM server OK (no models listed)")
            return True
    except Exception:
        pass

    print(
        f"❌ LLM server not reachable at {LLM_BASE_URL}\n"
        "   Start llama-server first, e.g.:\n"
        "   D:\\llama_bin\\llama-server.exe "
        "-m D:\\models\\qwen2.5-3b\\qwen2.5-3b-instruct-q4_k_m.gguf "
        "--host 0.0.0.0 --port 8080 -c 8192 -n 2048 -t 4"
    )
    return False


def main():
    parser = argparse.ArgumentParser(description="ARGUS Benchmarking Orchestrator")
    parser.add_argument("--dry-run", action="store_true",
                        help="Only 3 samples per dataset")
    parser.add_argument("--models", nargs="+", default=AVAILABLE_MODELS)
    parser.add_argument("--frameworks", nargs="+", default=None,
                        help="Subset of frameworks to run (default: all)")
    parser.add_argument("--subset", type=int, default=0,
                        help="Stratified subset per dataset (e.g. --subset 100)")
    args = parser.parse_args()

    if not check_llm_server():
        return

    print("\n🚀 ARGUS Benchmarking Orchestrator")
    print(f"   Models:     {args.models}")
    print(f"   Frameworks: {args.frameworks or 'all'}")
    if args.dry_run:
        print("   ⚠️  DRY RUN — 3 samples per dataset\n")

    for model in args.models:
        print(f"\n{'━'*60}")
        print(f"  Benchmarking model: {model}")
        print(f"{'━'*60}")

        cmd = [sys.executable, "-m", "scripts.run_llm", "--model", model]
        if args.dry_run:
            cmd.append("--dry-run")
        if args.subset > 0:
            cmd.extend(["--subset", str(args.subset)])
        if args.frameworks:
            cmd.extend(["--frameworks"] + args.frameworks)

        result = subprocess.run(cmd)
        if result.returncode == 0:
            print(f"\n✅ {model} complete.")
        else:
            print(f"\n❌ {model} had errors. Continuing...")

    print("\n📊 Generating reports...")
    subprocess.run([sys.executable, "-m", "scripts.generate_latex"])
    subprocess.run([sys.executable, "-m", "scripts.generate_plots"])

    print("\n🎉 All done. Check results/ and reports/ folders.")


if __name__ == "__main__":
    main()
