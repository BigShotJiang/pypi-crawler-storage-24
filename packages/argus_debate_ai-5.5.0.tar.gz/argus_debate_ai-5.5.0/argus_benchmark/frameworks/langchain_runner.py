"""
LangChain benchmark runner — baseline single-call with proper prompts.

Uses a singleton OpenAI client so the TCP connection is reused across
all samples (critical for throughput on a local llama-server).
"""

from openai import OpenAI
from config import LLM_BASE_URL, LLM_API_KEY, LLM_TIMEOUT, MAX_TOKENS_BY_TASK
from core.prompts import build_prompt

# ── Singleton client (connection pooling) ─────────────────────────────
_client = None

def _get_client() -> OpenAI:
    global _client
    if _client is None:
        _client = OpenAI(
            base_url=LLM_BASE_URL,
            api_key=LLM_API_KEY,
            timeout=LLM_TIMEOUT,
            max_retries=2,
        )
    return _client


def run(sample: dict, model_name: str) -> dict:
    """
    Single LLM call with task-specific prompt.

    Parameters
    ----------
    sample : dict  — full sample with question, dataset, task_type, choices, etc.
    model_name : str
    """
    try:
        task_type = sample.get("task_type", "classification")
        max_tok = MAX_TOKENS_BY_TASK.get(task_type, 256)

        system_prompt, user_prompt = build_prompt(sample)

        client = _get_client()
        response = client.chat.completions.create(
            model=model_name,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user",   "content": user_prompt},
            ],
            temperature=0.0,
            max_tokens=max_tok,
        )

        answer = (response.choices[0].message.content or "").strip()

        return {"answer": answer, "error": ""}

    except Exception as e:
        return {"answer": "ERROR", "error": str(e)}
