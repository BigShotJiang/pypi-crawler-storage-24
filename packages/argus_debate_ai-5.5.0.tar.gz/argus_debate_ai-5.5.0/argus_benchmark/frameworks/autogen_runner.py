"""
AutoGen benchmark runner — two-agent chat with proper prompts.

Re-uses a cached config_list and minimal agent setup to reduce overhead.
"""

import autogen
from config import LLM_BASE_URL, LLM_API_KEY, MAX_TOKENS_BY_TASK
from core.prompts import build_prompt


def _make_config(model_name: str, max_tok: int) -> list:
    return [{
        "model": model_name,
        "base_url": LLM_BASE_URL,
        "api_key": LLM_API_KEY,
        "price": [0, 0],
        "params": {"max_tokens": max_tok},
    }]


def run(sample: dict, model_name: str) -> dict:
    """
    Two-agent AutoGen chat: user_proxy asks, assistant answers.
    """
    try:
        task_type = sample.get("task_type", "classification")
        max_tok = MAX_TOKENS_BY_TASK.get(task_type, 256)
        system_prompt, user_prompt = build_prompt(sample)

        config_list = _make_config(model_name, max_tok)

        assistant = autogen.AssistantAgent(
            name="assistant",
            system_message=system_prompt,
            llm_config={
                "config_list": config_list,
                "temperature": 0.0,
                "max_tokens": max_tok,
            },
        )

        user_proxy = autogen.UserProxyAgent(
            name="user_proxy",
            human_input_mode="NEVER",
            max_consecutive_auto_reply=1,
            code_execution_config=False,
        )

        chat_res = user_proxy.initiate_chat(
            assistant,
            message=user_prompt,
            summary_method="last_msg",
        )

        answer = (chat_res.summary if chat_res else "ERROR").strip()
        return {"answer": answer, "error": ""}

    except Exception as e:
        return {"answer": "ERROR", "error": str(e)}
