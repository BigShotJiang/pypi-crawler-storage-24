"""
LangGraph benchmark runner — two-step graph (reason → answer) with prompts.

The compiled graph is cached per (model, max_tokens) to avoid re-compilation.
"""

from typing import TypedDict
from langgraph.graph import StateGraph, END
from langchain_openai import ChatOpenAI
from config import LLM_BASE_URL, LLM_API_KEY, LLM_TIMEOUT, MAX_TOKENS_BY_TASK
from core.prompts import build_prompt


class GraphState(TypedDict):
    system_prompt: str
    question: str
    reasoning: str
    answer: str


def _build_graph(model_name: str, max_tok: int):
    llm = ChatOpenAI(
        model=model_name,
        base_url=LLM_BASE_URL,
        api_key=LLM_API_KEY,
        temperature=0.0,
        max_tokens=max_tok,
        timeout=LLM_TIMEOUT,
    )

    def reason(state: GraphState):
        q = state["question"]
        sys = state.get("system_prompt", "")
        prompt = f"Think step by step to answer: {q}"
        from langchain_core.messages import SystemMessage, HumanMessage
        msgs = []
        if sys:
            msgs.append(SystemMessage(content=sys))
        msgs.append(HumanMessage(content=prompt))
        resp = llm.invoke(msgs)
        return {"reasoning": resp.content if hasattr(resp, "content") else str(resp)}

    def answer(state: GraphState):
        q   = state["question"]
        r   = state["reasoning"]
        sys = state.get("system_prompt", "")
        prompt = f"Question: {q}\nReasoning: {r}\nFinal answer:"
        from langchain_core.messages import SystemMessage, HumanMessage
        msgs = []
        if sys:
            msgs.append(SystemMessage(content=sys))
        msgs.append(HumanMessage(content=prompt))
        resp = llm.invoke(msgs)
        return {"answer": resp.content if hasattr(resp, "content") else str(resp)}

    wf = StateGraph(GraphState)
    wf.add_node("reason_node", reason)
    wf.add_node("answer_node", answer)
    wf.set_entry_point("reason_node")
    wf.add_edge("reason_node", "answer_node")
    wf.add_edge("answer_node", END)
    return wf.compile()


# Graph cache keyed by (model, max_tok) — avoids rebuilding every call
_GRAPH_CACHE: dict = {}


def run(sample: dict, model_name: str) -> dict:
    """
    Two-step LangGraph pipeline: reason → answer.
    """
    try:
        task_type = sample.get("task_type", "classification")
        max_tok = MAX_TOKENS_BY_TASK.get(task_type, 256)
        system_prompt, user_prompt = build_prompt(sample)

        cache_key = (model_name, max_tok)
        if cache_key not in _GRAPH_CACHE:
            _GRAPH_CACHE[cache_key] = _build_graph(model_name, max_tok)

        app = _GRAPH_CACHE[cache_key]
        result = app.invoke({
            "system_prompt": system_prompt,
            "question": user_prompt,
        })

        return {"answer": str(result.get("answer", "")).strip(), "error": ""}

    except Exception as e:
        return {"answer": "ERROR", "error": str(e)}
