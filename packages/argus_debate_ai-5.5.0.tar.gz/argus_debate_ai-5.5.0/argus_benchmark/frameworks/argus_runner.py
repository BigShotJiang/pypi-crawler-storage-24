"""
ARGUS benchmark runner — native ARGUS debate pipeline.

Uses the real ARGUS agent stack:
  Round 0: 3 domain Specialists gather evidence (no index — LLM synthetic evidence)
  Round 1: 1 Refuter challenges the gathered evidence
  Round 2: Jury evaluates the C-DAG and renders a verdict

 Zero timeouts — every step runs to completion.
Pipeline: Specialist×3 → Refuter → Jury → verdict label
"""

import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))

from config import LLM_BASE_URL, LLM_API_KEY

# ── Singleton LLM cache ───────────────────────────────────────────────
_llm_cache: dict = {}


def _get_llm(model_name: str):
    """Return a cached OpenAILLM instance for this model (no timeout)."""
    if model_name not in _llm_cache:
        from argus.core.llm.openai import OpenAILLM
        _llm_cache[model_name] = OpenAILLM(
            model=model_name,
            base_url=LLM_BASE_URL,
            api_key=LLM_API_KEY,
            max_tokens=512,     # enough for evidence + verdicts, not bloated
        )
    return _llm_cache[model_name]


# ── Verdict → benchmark label mapping ────────────────────────────────
# Maps jury verdict labels to the label formats the scorer expects.
_VERDICT_MAP = {
    # FEVER classification
    "supported":  "SUPPORTS",
    "rejected":   "REFUTES",
    "undecided":  "NOT ENOUGH INFO",
    # BoolQ
    "supported":  "True",
    "rejected":   "False",
}

_TASK_VERDICT_MAP = {
    "classification": {
        "fever": {
            "supported": "SUPPORTS",
            "rejected": "REFUTES",
            "undecided": "NOT ENOUGH INFO",
        },
        "multi_nli": {
            "supported": "entailment",
            "rejected": "contradiction",
            "undecided": "neutral",
        },
        "boolq": {
            "supported": "True",
            "rejected": "False",
            "undecided": "False",
        },
        "default": {
            "supported": "True",
            "rejected": "False",
            "undecided": "False",
        },
    },
    "mcq": {
        # For MCQ the jury needs to reason about the answer choice directly;
        # we extract the letter from the jury reasoning text instead.
        "default": {}
    },
}


def _map_verdict(label: str, dataset: str, task_type: str) -> str:
    """Convert jury verdict label to the expected benchmark label."""
    task_map = _TASK_VERDICT_MAP.get(task_type, {})
    ds_map = task_map.get(dataset, task_map.get("default", {}))
    return ds_map.get(label.lower(), label)


# ── Core debate pipeline ─────────────────────────────────────────────

def _run_debate(question: str, dataset: str, task_type: str,
                choices: list | None, model_name: str) -> dict:
    """
    Run one round of the ARGUS debate pipeline.

    Structure
    ---------
    1. Build a C-DAG with the question as the proposition.
    2. Three Specialists (logic, factual, contextual) gather synthetic evidence.
    3. One Refuter challenges the gathered evidence.
    4. Jury renders a verdict and reasoning.
    5. Return {answer, error}.
    """
    from argus.cdag.graph import CDAG
    from argus.cdag.nodes import Proposition
    from argus.agents.specialist import Specialist, SpecialistConfig
    from argus.agents.refuter import Refuter, RefuterConfig
    from argus.agents.jury import Jury, JuryConfig

    llm = _get_llm(model_name)

    # ── Build proposition ─────────────────────────────────────────
    prop_text = question
    if task_type == "mcq" and choices:
        choice_str = "\n".join(
            f"  {chr(65+i)}) {c}" for i, c in enumerate(choices)
        )
        prop_text = f"{question}\nChoices:\n{choice_str}"

    graph = CDAG(name=f"debate_{dataset}")
    prop = Proposition(text=prop_text, prior=0.5)
    prop_id = graph.add_proposition(prop)

    # ── Specialists ───────────────────────────────────────────────
    domains = ["logical reasoning", "factual accuracy", "contextual analysis"]
    for domain in domains:
        cfg = SpecialistConfig(
            max_evidence_per_query=2,   # 2 per specialist = 6 total = fast
            min_confidence_threshold=0.2,
        )
        spec = Specialist(llm=llm, config=cfg, domain=domain)
        spec.gather_evidence(graph, prop_id)   # no index → LLM synthetic

    # ── Refuter ───────────────────────────────────────────────────
    ref_cfg = RefuterConfig(max_rebuttals_per_round=2, min_rebuttal_strength=0.3)
    refuter = Refuter(llm=llm, config=ref_cfg)
    refuter.generate_rebuttals(graph, prop_id)

    # ── Jury ──────────────────────────────────────────────────────
    jury_cfg = JuryConfig(decision_threshold=0.6, use_llm_reasoning=True)
    jury = Jury(llm=llm, config=jury_cfg)
    verdict = jury.evaluate(graph, prop_id)

    # ── Map verdict to expected benchmark format ──────────────────
    raw_label = verdict.label.lower()    # "supported" | "rejected" | "undecided"

    if task_type == "mcq":
        # For MCQ, ask the jury's reasoning which letter it picked
        answer = _extract_mcq_from_reasoning(verdict.reasoning, choices or [])
    else:
        answer = _map_verdict(raw_label, dataset, task_type)

    return {
        "answer": answer,
        "error": "",
        "metadata": {
            "posterior":   round(verdict.posterior, 4),
            "verdict":     raw_label,
            "confidence":  round(verdict.confidence, 4),
            "nodes":       graph.num_nodes,
            "edges":       graph.num_edges,
        },
    }


def _extract_mcq_from_reasoning(reasoning: str, choices: list) -> str:
    """Pull the answer letter from jury reasoning for MCQ tasks."""
    import re
    # Look for "answer is A", "(B)", "option C", etc.
    patterns = [
        r"\banswer[:\s]+([A-E])\b",
        r"\(([A-E])\)",
        r"\boption\s+([A-E])\b",
        r"^([A-E])[).\s]",
    ]
    for pat in patterns:
        m = re.search(pat, reasoning, re.IGNORECASE | re.MULTILINE)
        if m:
            return m.group(1).upper()
    # Fallback — check if reasoning contains a full choice text
    for i, choice in enumerate(choices):
        if choice.lower()[:30] in reasoning.lower():
            return chr(65 + i)
    return "A"   # last-resort default


# ── Public entry point ────────────────────────────────────────────────

def run(sample: dict, model_name: str) -> dict:
    """
    Benchmark adapter — called by run_single() in benchmark_runner.py.

    Parameters
    ----------
    sample : dict
        Full sample dict from the JSONL data file.
    model_name : str
        Model name to pass to the LLM client.

    Returns
    -------
    dict with keys: answer (str), error (str)
    """
    question  = sample.get("question", "")
    dataset   = sample.get("dataset", "unknown")
    task_type = sample.get("task_type", "classification")
    choices   = sample.get("choices")    # TruthfulQA / ARC

    if not question:
        return {"answer": "SKIPPED", "error": "Empty question"}

    try:
        return _run_debate(question, dataset, task_type, choices, model_name)
    except Exception as exc:
        return {"answer": "ERROR", "error": str(exc)}
