"""
CrewAI benchmark runner — two-agent crew with proper prompts.

Researcher analyses, Answerer produces final label.  Both share the same
local LLM via ChatOpenAI pointed at llama-server.
"""

from crewai import Agent, Task, Crew, Process
from langchain_openai import ChatOpenAI
from config import LLM_BASE_URL, LLM_API_KEY, LLM_TIMEOUT, MAX_TOKENS_BY_TASK
from core.prompts import build_prompt

# ── Singleton LLM (connection reuse) ─────────────────────────────────
_llm_cache: dict = {}

def _get_llm(model_name: str, max_tok: int) -> ChatOpenAI:
    key = (model_name, max_tok)
    if key not in _llm_cache:
        _llm_cache[key] = ChatOpenAI(
            model=model_name,
            base_url=LLM_BASE_URL,
            api_key=LLM_API_KEY,
            temperature=0.0,
            max_tokens=max_tok,
            timeout=LLM_TIMEOUT,
        )
    return _llm_cache[key]


def run(sample: dict, model_name: str) -> dict:
    """
    Two-agent CrewAI pipeline: Researcher → Answerer.
    """
    try:
        task_type = sample.get("task_type", "classification")
        max_tok = MAX_TOKENS_BY_TASK.get(task_type, 256)
        system_prompt, user_prompt = build_prompt(sample)

        llm = _get_llm(model_name, max_tok)

        researcher = Agent(
            role="Researcher",
            goal="Analyse the input and identify the key facts needed to answer.",
            backstory=system_prompt,
            verbose=False,
            allow_delegation=False,
            llm=llm,
        )

        answerer = Agent(
            role="Answerer",
            goal="Provide the final answer in the exact required format.",
            backstory=system_prompt,
            verbose=False,
            allow_delegation=False,
            llm=llm,
        )

        task1 = Task(
            description=f"Analyse: {user_prompt}",
            expected_output="Key facts and reasoning in one short paragraph.",
            agent=researcher,
        )

        task2 = Task(
            description="Based on the analysis, give the final answer in the exact format requested.",
            expected_output="The final answer label/letter/index only.",
            agent=answerer,
        )

        crew = Crew(
            agents=[researcher, answerer],
            tasks=[task1, task2],
            verbose=False,
            process=Process.sequential,
        )

        result = crew.kickoff()
        return {"answer": str(result).strip(), "error": ""}

    except Exception as e:
        return {"answer": "ERROR", "error": str(e)}
