from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np

import witwin.maxwell as mw
from benchmark.metrics import align_arrays, align_plane_fields, plane_coord_keys
from benchmark.paths import ensure_directories, scenario_plot_dir
from benchmark.tidy3d_scene import benchmark_physical_bounds
from witwin.maxwell.fdtd.excitation.spatial import resolve_injection_axis, soft_plane_wave_index
from witwin.maxwell.scene import prepare_scene
from witwin.maxwell.sources import PlaneWave, PointDipole


AXIS_INDEX = {"x": 0, "y": 1, "z": 2}
PLOT_AXES = ("x", "y", "z")
FIELD_COMPONENTS = ("Ex", "Ey", "Ez")
PLANE_COORD_NAMES = {
    "x": ("y", "z"),
    "y": ("x", "z"),
    "z": ("x", "y"),
}


def plane_axes(axis: str) -> tuple[str, str]:
    if axis == "x":
        return "y", "z"
    if axis == "y":
        return "x", "z"
    return "x", "y"


def plane_slice_coords(scene: mw.Scene, axis: str) -> tuple[np.ndarray, np.ndarray]:
    scene = prepare_scene(scene)
    coord_names = plane_axes(axis)
    coord_map = {
        "x": scene.x.detach().cpu().numpy(),
        "y": scene.y.detach().cpu().numpy(),
        "z": scene.z.detach().cpu().numpy(),
    }
    return coord_map[coord_names[0]], coord_map[coord_names[1]]


def get_plane_slice_with_coords(
    scene: mw.Scene,
    *,
    axis: str,
    position: float,
    values,
) -> tuple[np.ndarray, tuple[np.ndarray, np.ndarray]]:
    scene = prepare_scene(scene)
    axis_idx = AXIS_INDEX[axis]
    coords = {
        "x": scene.x.detach().cpu().numpy(),
        "y": scene.y.detach().cpu().numpy(),
        "z": scene.z.detach().cpu().numpy(),
    }
    plane_index = int(np.argmin(np.abs(coords[axis] - float(position))))
    array = np.asarray(values)
    coord_names = plane_axes(axis)
    if axis_idx == 0:
        return np.asarray(array[plane_index, :, :]), (coords[coord_names[0]], coords[coord_names[1]])
    if axis_idx == 1:
        return np.asarray(array[:, plane_index, :]), (coords[coord_names[0]], coords[coord_names[1]])
    return np.asarray(array[:, :, plane_index]), (coords[coord_names[0]], coords[coord_names[1]])


def get_plane_slice(scene: mw.Scene, *, axis: str, position: float, values) -> np.ndarray:
    plane_slice, _ = get_plane_slice_with_coords(scene, axis=axis, position=position, values=values)
    return plane_slice


def dominant_source_component(scene: mw.Scene) -> str:
    source = scene.sources[0]
    if isinstance(source, (PointDipole, PlaneWave)):
        component_index = max(range(3), key=lambda idx: abs(source.polarization[idx]))
        return FIELD_COMPONENTS[component_index]
    return "Ez"


def source_plane_map(scene: mw.Scene, *, axis: str, position: float, component: str) -> np.ndarray:
    scene = prepare_scene(scene)
    values = np.zeros((scene.Nx, scene.Ny, scene.Nz), dtype=np.float64)
    source = scene.sources[0]
    target_axis = component[-1].lower()
    if isinstance(source, PointDipole):
        width = max(float(source.width), min(scene.dx, scene.dy, scene.dz))
        xx = scene.xx.detach().cpu().numpy()
        yy = scene.yy.detach().cpu().numpy()
        zz = scene.zz.detach().cpu().numpy()
        profile = np.exp(
            -(
                (xx - source.position[0]) ** 2
                + (yy - source.position[1]) ** 2
                + (zz - source.position[2]) ** 2
            )
            / (2.0 * width * width)
        )
        component_index = max(range(3), key=lambda idx: abs(source.polarization[idx]))
        if target_axis == "xyz"[component_index]:
            values = profile
    elif isinstance(source, PlaneWave):
        inject_axis = resolve_injection_axis(source.direction, source.injection_axis)
        direction_component = float(source.direction[AXIS_INDEX[inject_axis]])
        plane_idx = soft_plane_wave_index(scene, inject_axis, direction_component)
        if inject_axis == "x":
            values[plane_idx, :, :] = 1.0
        elif inject_axis == "y":
            values[:, plane_idx, :] = 1.0
        else:
            values[:, :, plane_idx] = 1.0
        component_index = max(range(3), key=lambda idx: abs(source.polarization[idx]))
        if target_axis != "xyz"[component_index]:
            values.fill(0.0)
    return get_plane_slice(scene, axis=axis, position=position, values=values)


def _crop_pair(a: np.ndarray, b: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    a, b = align_arrays(np.asarray(a), np.asarray(b))
    return np.asarray(a), np.asarray(b)


def _align_plane_pair(
    source_values: np.ndarray,
    reference_values: np.ndarray,
    *,
    source_coords: tuple[np.ndarray, np.ndarray],
    reference_coords: tuple[np.ndarray, np.ndarray],
) -> tuple[np.ndarray, np.ndarray]:
    try:
        aligned_source, aligned_reference, _ = align_plane_fields(
            source_values,
            reference_values,
            source_coords=source_coords,
            reference_coords=reference_coords,
        )
        return np.asarray(aligned_source), np.asarray(aligned_reference)
    except ValueError:
        return _crop_pair(source_values, reference_values)


def _align_monitor_pair(
    maxwell_monitor: dict,
    tidy3d_monitor: dict,
    *,
    component: str,
    maxwell_field: np.ndarray,
    tidy3d_field: np.ndarray,
    maxwell_coords: tuple[np.ndarray, np.ndarray] | None = None,
    tidy3d_coords: tuple[np.ndarray, np.ndarray] | None = None,
) -> tuple[np.ndarray, np.ndarray]:
    try:
        if maxwell_coords is None:
            maxwell_coords = _component_plane_coords(maxwell_monitor, component)
        if tidy3d_coords is None:
            tidy3d_coords = _component_plane_coords(tidy3d_monitor, component)
        if maxwell_coords is None or tidy3d_coords is None:
            raise ValueError("Missing plane coordinates.")
        maxwell_coord_keys = PLANE_COORD_NAMES.get(maxwell_monitor.get("axis"), tuple())
        tidy3d_coord_keys = PLANE_COORD_NAMES.get(tidy3d_monitor.get("axis"), tuple())
        if not maxwell_coord_keys:
            maxwell_coord_keys = plane_coord_keys(maxwell_monitor)
        if not tidy3d_coord_keys:
            tidy3d_coord_keys = plane_coord_keys(tidy3d_monitor)
        if maxwell_coord_keys == tidy3d_coord_keys:
            aligned_maxwell, aligned_tidy3d, _ = align_plane_fields(
                maxwell_field,
                tidy3d_field,
                source_coords=maxwell_coords,
                reference_coords=tidy3d_coords,
            )
            return np.asarray(aligned_maxwell), np.asarray(aligned_tidy3d)
    except ValueError:
        pass
    return _crop_pair(maxwell_field, tidy3d_field)


def _component_plane_coords(monitor_data: dict, component: str) -> tuple[np.ndarray, np.ndarray] | None:
    field_coords = monitor_data.get("field_coords", {})
    component_coords = field_coords.get(component)
    if component_coords is not None:
        if "axis" in component_coords and component_coords["axis"] in PLANE_COORD_NAMES:
            coord_keys = PLANE_COORD_NAMES[component_coords["axis"]]
        else:
            coord_keys = plane_coord_keys(component_coords)
        return tuple(np.asarray(component_coords[key], dtype=np.float64) for key in coord_keys)

    axis = monitor_data.get("axis")
    if axis in PLANE_COORD_NAMES:
        coord_keys = PLANE_COORD_NAMES[axis]
        if all(key in monitor_data for key in coord_keys):
            return tuple(np.asarray(monitor_data[key], dtype=np.float64) for key in coord_keys)
        return None

    try:
        coord_keys = plane_coord_keys(monitor_data)
    except ValueError:
        return None
    return tuple(np.asarray(monitor_data[key], dtype=np.float64) for key in coord_keys)


def _select_plot_field(monitor_data: dict, component: str, field_values, *, freq_index: int = 0) -> np.ndarray:
    array = np.asarray(field_values).squeeze()
    if array.ndim == 2:
        return array
    if array.ndim != 3:
        raise TypeError(f"Expected a 2D plane field or stacked multi-frequency planes, got shape {array.shape}.")

    index = int(freq_index)
    coords = _component_plane_coords(monitor_data, component)
    plane_shape = tuple(coord.size for coord in coords) if coords is not None else None
    frequencies = tuple(float(freq) for freq in monitor_data.get("frequencies", ()))

    if plane_shape is not None:
        if array.shape[-2:] == plane_shape:
            if index < 0 or index >= array.shape[0]:
                raise IndexError(f"freq_index {index} is out of range for field shape {array.shape}.")
            return np.asarray(array[index])
        if array.shape[:2] == plane_shape:
            if index < 0 or index >= array.shape[-1]:
                raise IndexError(f"freq_index {index} is out of range for field shape {array.shape}.")
            return np.asarray(array[..., index])

    if frequencies:
        if array.shape[0] == len(frequencies):
            return np.asarray(array[index])
        if array.shape[-1] == len(frequencies):
            return np.asarray(array[..., index])

    if 0 <= index < array.shape[0]:
        return np.asarray(array[index])
    if 0 <= index < array.shape[-1]:
        return np.asarray(array[..., index])

    raise TypeError(
        "Unable to identify the frequency axis for plane field "
        f"shape {array.shape} and component {component!r}."
    )


def _plot_triplet(ax_left, ax_mid, ax_right, *, left, mid, title_prefix: str, cmap: str) -> None:
    left = np.asarray(left)
    mid = np.asarray(mid)
    diff = np.abs(left - mid)
    vmax = max(float(np.max(np.abs(left))), float(np.max(np.abs(mid))), 1e-12)
    diff_max = max(float(np.max(diff)), 1e-12)

    image_left = ax_left.imshow(np.abs(left).T, origin="lower", cmap=cmap, aspect="equal", vmin=0.0, vmax=vmax)
    ax_left.set_title(f"{title_prefix} Maxwell", fontsize=8)
    plt.colorbar(image_left, ax=ax_left, shrink=0.72)

    image_mid = ax_mid.imshow(np.abs(mid).T, origin="lower", cmap=cmap, aspect="equal", vmin=0.0, vmax=vmax)
    ax_mid.set_title(f"{title_prefix} Tidy3D", fontsize=8)
    plt.colorbar(image_mid, ax=ax_mid, shrink=0.72)

    image_diff = ax_right.imshow(diff.T, origin="lower", cmap="viridis", aspect="equal", vmin=0.0, vmax=diff_max)
    ax_right.set_title(f"{title_prefix} |Δ|", fontsize=8)
    plt.colorbar(image_diff, ax=ax_right, shrink=0.72)


def _take_plane_window(values, indices_a: np.ndarray, indices_b: np.ndarray) -> np.ndarray:
    array = np.asarray(values)
    windowed = np.take(array, indices_a, axis=-2)
    windowed = np.take(windowed, indices_b, axis=-1)
    return windowed


def _crop_monitor_field_to_physical_bounds(
    scene: mw.Scene,
    *,
    axis: str,
    values,
    coords: tuple[np.ndarray, np.ndarray] | None,
):
    if coords is None:
        return np.asarray(values), coords

    coord_names = PLANE_COORD_NAMES[axis]
    physical_bounds = benchmark_physical_bounds(scene)
    tangential_bounds = tuple(physical_bounds["xyz".index(coord_name)] for coord_name in coord_names)
    coords_a = np.asarray(coords[0], dtype=np.float64)
    coords_b = np.asarray(coords[1], dtype=np.float64)
    mask_a = (coords_a >= tangential_bounds[0][0] - 1e-12) & (coords_a <= tangential_bounds[0][1] + 1e-12)
    mask_b = (coords_b >= tangential_bounds[1][0] - 1e-12) & (coords_b <= tangential_bounds[1][1] + 1e-12)
    if not np.any(mask_a) or not np.any(mask_b):
        return np.asarray(values), (coords_a, coords_b)

    indices_a = np.flatnonzero(mask_a)
    indices_b = np.flatnonzero(mask_b)
    return _take_plane_window(values, indices_a, indices_b), (coords_a[indices_a], coords_b[indices_b])


def save_material_source_plot(*, scene: mw.Scene, tidy_scene: mw.Scene, scenario_name: str) -> Path:
    scene = prepare_scene(scene)
    tidy_scene = prepare_scene(tidy_scene)
    ensure_directories()
    scenario_dir = scenario_plot_dir(scenario_name)
    scenario_dir.mkdir(parents=True, exist_ok=True)
    output_path = scenario_dir / "material_source.png"

    maxwell_eps = scene.permittivity.detach().cpu().numpy()
    tidy_eps = tidy_scene.permittivity.detach().cpu().numpy()
    source_component = dominant_source_component(scene)

    fig, axes = plt.subplots(len(PLOT_AXES), 6, figsize=(24, 12))
    fig.suptitle(f"{scenario_name}: permittivity and source comparison", fontsize=16)

    for row, axis in enumerate(PLOT_AXES):
        maxwell_eps_slice, maxwell_eps_coords = get_plane_slice_with_coords(
            scene,
            axis=axis,
            position=0.0,
            values=maxwell_eps,
        )
        tidy_eps_slice, tidy_eps_coords = get_plane_slice_with_coords(
            tidy_scene,
            axis=axis,
            position=0.0,
            values=tidy_eps,
        )
        maxwell_eps_slice, tidy_eps_slice = _align_plane_pair(
            maxwell_eps_slice,
            tidy_eps_slice,
            source_coords=maxwell_eps_coords,
            reference_coords=tidy_eps_coords,
        )

        maxwell_source_slice = source_plane_map(scene, axis=axis, position=0.0, component=source_component)
        maxwell_source_coords = plane_slice_coords(scene, axis)
        tidy_source_slice = source_plane_map(tidy_scene, axis=axis, position=0.0, component=source_component)
        tidy_source_coords = plane_slice_coords(tidy_scene, axis)
        maxwell_source_slice, tidy_source_slice = _align_plane_pair(
            maxwell_source_slice,
            tidy_source_slice,
            source_coords=maxwell_source_coords,
            reference_coords=tidy_source_coords,
        )

        _plot_triplet(
            axes[row, 0],
            axes[row, 1],
            axes[row, 2],
            left=maxwell_eps_slice,
            mid=tidy_eps_slice,
            title_prefix=f"{axis}=0 eps_r",
            cmap="viridis",
        )
        _plot_triplet(
            axes[row, 3],
            axes[row, 4],
            axes[row, 5],
            left=maxwell_source_slice,
            mid=tidy_source_slice,
            title_prefix=f"{axis}=0 source({source_component})",
            cmap="magma",
        )

        axis_a, axis_b = plane_axes(axis)
        for col in range(6):
            axes[row, col].set_xlabel(axis_a)
            axes[row, col].set_ylabel(axis_b)

    fig.tight_layout(rect=[0, 0, 1, 0.97])
    fig.savefig(output_path, dpi=160, bbox_inches="tight")
    plt.close(fig)
    return output_path


def save_field_comparison_plot(
    *,
    scenario_name: str,
    maxwell_monitors: dict[str, dict],
    tidy3d_monitors: dict[str, dict],
    scene: mw.Scene | None = None,
) -> Path:
    ensure_directories()
    scenario_dir = scenario_plot_dir(scenario_name)
    scenario_dir.mkdir(parents=True, exist_ok=True)
    output_path = scenario_dir / "field_comparison.png"

    fig, axes = plt.subplots(len(PLOT_AXES), len(FIELD_COMPONENTS) * 3, figsize=(30, 12))
    fig.suptitle(f"{scenario_name}: Ex/Ey/Ez on x/y/z planes", fontsize=16)

    for row, axis in enumerate(PLOT_AXES):
        monitor_name = f"plot_field_{axis}"
        axis_a, axis_b = plane_axes(axis)
        for component_index, component in enumerate(FIELD_COMPONENTS):
            col = component_index * 3
            maxwell_monitor = maxwell_monitors[monitor_name]
            tidy3d_monitor = tidy3d_monitors[monitor_name]
            maxwell_field = _select_plot_field(
                maxwell_monitor,
                component,
                maxwell_monitor["fields"][component],
                freq_index=0,
            )
            tidy3d_field = _select_plot_field(
                tidy3d_monitor,
                component,
                tidy3d_monitor["fields"][component],
                freq_index=0,
            )
            maxwell_coords = _component_plane_coords(maxwell_monitor, component)
            tidy3d_coords = _component_plane_coords(tidy3d_monitor, component)
            if scene is not None:
                maxwell_field, maxwell_coords = _crop_monitor_field_to_physical_bounds(
                    scene,
                    axis=axis,
                    values=maxwell_field,
                    coords=maxwell_coords,
                )
                tidy3d_field, tidy3d_coords = _crop_monitor_field_to_physical_bounds(
                    scene,
                    axis=axis,
                    values=tidy3d_field,
                    coords=tidy3d_coords,
                )
            maxwell_field, tidy3d_field = _align_monitor_pair(
                maxwell_monitor=maxwell_monitor,
                tidy3d_monitor=tidy3d_monitor,
                component=component,
                maxwell_field=maxwell_field,
                tidy3d_field=tidy3d_field,
                maxwell_coords=maxwell_coords,
                tidy3d_coords=tidy3d_coords,
            )
            _plot_triplet(
                axes[row, col],
                axes[row, col + 1],
                axes[row, col + 2],
                left=maxwell_field,
                mid=tidy3d_field,
                title_prefix=f"{axis}=0 {component}",
                cmap="hot",
            )
            for idx in range(3):
                axes[row, col + idx].set_xlabel(axis_a)
                axes[row, col + idx].set_ylabel(axis_b)

    fig.tight_layout(rect=[0, 0, 1, 0.97])
    fig.savefig(output_path, dpi=160, bbox_inches="tight")
    plt.close(fig)
    return output_path
