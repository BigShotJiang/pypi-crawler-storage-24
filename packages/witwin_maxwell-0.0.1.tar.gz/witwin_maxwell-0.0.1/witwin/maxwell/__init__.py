from witwin.core import Box, Cone, Cylinder, Ellipsoid, HollowBox, Mesh, Prism, Pyramid, Sphere, Structure, Torus
from .media import DebyePole, DiagonalTensor3, DrudePole, LorentzPole, Material, Tensor3x3
from .monitors import ClosedSurfaceMonitor, FinitePlaneMonitor, FluxMonitor, ModeMonitor, PlaneMonitor, PointMonitor
from .ports import ModePort
from . import postprocess
from .result import Result
from .scene import BoundaryKind, BoundarySpec, Domain, GridSpec, MaterialRegion, Scene, SceneModule
from .sources import CW, GaussianBeam, GaussianPulse, ModeSource, PlaneWave, PointDipole, RickerWavelet, TFSF
from .simulation import (
    AbsorberKind,
    FDFDConfig,
    FDTDConfig,
    GMRES,
    Simulation,
    SimulationMethod,
    SpectralSampler,
    SpectralWindowKind,
    TimeConfig,
    run,
)

__all__ = [
    "BoundarySpec",
    "BoundaryKind",
    "Box",
    "ClosedSurfaceMonitor",
    "Cone",
    "CW",
    "Cylinder",
    "DebyePole",
    "Domain",
    "DrudePole",
    "Ellipsoid",
    "FluxMonitor",
    "FDFDConfig",
    "FDTDConfig",
    "FinitePlaneMonitor",
    "GaussianBeam",
    "GaussianPulse",
    "GMRES",
    "GridSpec",
    "HollowBox",
    "LorentzPole",
    "Material",
    "MaterialRegion",
    "Mesh",
    "ModeMonitor",
    "ModePort",
    "ModeSource",
    "PlaneMonitor",
    "PlaneWave",
    "PointDipole",
    "PointMonitor",
    "postprocess",
    "Prism",
    "Pyramid",
    "Result",
    "RickerWavelet",
    "Scene",
    "SceneModule",
    "Simulation",
    "SimulationMethod",
    "SpectralSampler",
    "SpectralWindowKind",
    "Sphere",
    "Structure",
    "Tensor3x3",
    "TimeConfig",
    "TFSF",
    "Torus",
    "DiagonalTensor3",
    "AbsorberKind",
    "run",
]


def __getattr__(name):
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
