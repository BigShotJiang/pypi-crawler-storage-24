"""Testes para descoberta de skills."""

import pytest
from pathlib import Path

from skillserver.discovery import SkillDiscovery
from skillserver.models import Skill


@pytest.fixture
def skills_dir(tmp_path):
    """Cria diretório temporário com skills de teste."""
    # Skill básica
    skill1 = tmp_path / "basic.md"
    skill1.write_text("""---
name: basic-skill
title: Basic Skill
description: A basic skill
---
# Basic Skill
This is a basic skill.""")
    
    # Skill com frontmatter mais completo
    skill2 = tmp_path / "advanced.md"
    skill2.write_text("""---
name: advanced-skill
title: Advanced Skill
description: An advanced skill
version: 1.0
author: Test
---
# Advanced Skill
This is an advanced skill.""")
    
    # Skill em subdiretório
    subdir = tmp_path / "category"
    subdir.mkdir()
    skill3 = subdir / "nested.md"
    skill3.write_text("""---
title: Nested Skill
---
# Nested Skill
Nested content.""")
    
    return tmp_path


def test_discovery_init(skills_dir):
    """Testa inicialização do discovery."""
    discovery = SkillDiscovery(skills_dir)
    assert discovery.skills_dir == skills_dir


def test_discovery_init_invalid_path():
    """Testa que diretório inválido levanta ValueError."""
    with pytest.raises(ValueError, match="not found"):
        SkillDiscovery("/path/does/not/exist")


def test_discovery_init_not_a_directory(tmp_path):
    """Testa que arquivo ao invés de diretório levanta ValueError."""
    file_path = tmp_path / "file.txt"
    file_path.write_text("test")
    
    with pytest.raises(ValueError, match="not a directory"):
        SkillDiscovery(file_path)


def test_discover_skills(skills_dir):
    """Testa descoberta de skills."""
    discovery = SkillDiscovery(skills_dir)
    skills = discovery.discover_skills()
    
    assert len(skills) == 3
    
    # Verifica que todas são objetos Skill
    for skill in skills:
        assert isinstance(skill, Skill)
    
    # Verifica nomes das skills
    skill_names = {s.name for s in skills}
    assert "basic-skill" in skill_names
    assert "advanced-skill" in skill_names
    assert "nested" in skill_names


def test_discover_empty_directory(tmp_path):
    """Testa descoberta em diretório vazio."""
    discovery = SkillDiscovery(tmp_path)
    skills = discovery.discover_skills()
    
    assert skills == []


def test_discover_resources(skills_dir, tmp_path):
    """Testa descoberta de recursos."""
    # Cria skill com recursos
    skill_file = tmp_path / "with-resources.md"
    skill_file.write_text("""---
name: test-skill
---
# Test""")
    
    # Cria recursos no mesmo diretório
    resource1 = tmp_path / "image.png"
    resource1.write_bytes(b"fake image")
    
    resource2 = tmp_path / "data.json"
    resource2.write_text('{"test": true}')
    
    # Descobre skill
    discovery = SkillDiscovery(tmp_path)
    skills = discovery.discover_skills()
    skill = skills[0]
    
    # Descobre recursos
    resources = discovery.discover_resources(skill)
    
    assert len(resources) >= 2
    resource_names = {r.name for r in resources}
    assert "image.png" in resource_names
    assert "data.json" in resource_names
