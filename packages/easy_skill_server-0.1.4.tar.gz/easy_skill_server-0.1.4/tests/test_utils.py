"""Testes para funções utilitárias."""

import pytest
from pathlib import Path

from skillserver.utils import (
    parse_frontmatter,
    get_mime_type,
    is_text_file,
    generate_skill_name,
)


def test_parse_frontmatter_with_yaml():
    """Testa parsing de frontmatter YAML."""
    content = """---
title: Test Skill
description: A test
version: 1.0
---
# Content
This is the body"""
    
    metadata, body = parse_frontmatter(content)
    
    assert metadata["title"] == "Test Skill"
    assert metadata["description"] == "A test"
    assert metadata["version"] == 1.0
    assert body.strip() == "# Content\nThis is the body"


def test_parse_frontmatter_without_yaml():
    """Testa parsing de conteúdo sem frontmatter."""
    content = "# Just Content\nNo frontmatter here"
    
    metadata, body = parse_frontmatter(content)
    
    assert metadata == {}
    assert body == content


def test_parse_frontmatter_invalid_yaml():
    """Testa que YAML inválido levanta ValueError."""
    content = """---
invalid: yaml: here:
---
Content"""
    
    with pytest.raises(ValueError, match="Invalid YAML"):
        parse_frontmatter(content)


def test_get_mime_type():
    """Testa detecção de tipo MIME."""
    assert get_mime_type(Path("file.txt")) == "text/plain"
    assert get_mime_type(Path("file.html")) == "text/html"
    assert get_mime_type(Path("file.json")) == "application/json"
    assert get_mime_type(Path("file.png")) == "image/png"
    assert get_mime_type(Path("file.unknown")) == "application/octet-stream"


def test_is_text_file():
    """Testa detecção de arquivo de texto."""
    assert is_text_file(Path("file.txt")) is True
    assert is_text_file(Path("file.md")) is True
    assert is_text_file(Path("file.json")) is True
    assert is_text_file(Path("file.xml")) is True
    assert is_text_file(Path("file.png")) is False
    assert is_text_file(Path("file.bin")) is False


def test_generate_skill_name():
    """Testa geração de nome de skill."""
    assert generate_skill_name(Path("Hello World.md")) == "hello-world"
    assert generate_skill_name(Path("my_skill.md")) == "my-skill"
    assert generate_skill_name(Path("Test-123.md")) == "test-123"
    assert generate_skill_name(Path(" spaces .md")) == "spaces"
