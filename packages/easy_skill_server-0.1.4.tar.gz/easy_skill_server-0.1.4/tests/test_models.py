"""Testes para os modelos de dados."""

import pytest
from pathlib import Path

from skillserver.models import Skill, SkillResource


def test_skill_creation():
    """Testa criação básica de uma Skill."""
    skill = Skill(
        name="test-skill",
        title="Test Skill",
        description="A test skill",
        instructions="# Test\nInstructions here",
        file_path=Path("test.md"),
    )
    
    assert skill.name == "test-skill"
    assert skill.title == "Test Skill"
    assert skill.description == "A test skill"
    assert skill.instructions == "# Test\nInstructions here"


def test_skill_empty_name_raises():
    """Testa que skill sem nome levanta ValueError."""
    with pytest.raises(ValueError, match="name cannot be empty"):
        Skill(
            name="",
            title="Test",
            description="Test",
            instructions="Test",
            file_path=Path("test.md"),
        )


def test_skill_auto_title():
    """Testa geração automática de título."""
    skill = Skill(
        name="my-test-skill",
        title="",
        description="Desc",
        instructions="Test",
        file_path=Path("test.md"),
    )
    
    assert skill.title == "My Test Skill"


def test_skill_auto_description():
    """Testa geração automática de descrição."""
    skill = Skill(
        name="test",
        title="My Title",
        description="",
        instructions="Test",
        file_path=Path("test.md"),
    )
    
    assert skill.description == "My Title"


def test_skill_resource_creation(tmp_path):
    """Testa criação de SkillResource."""
    # Cria arquivo temporário
    test_file = tmp_path / "image.png"
    test_file.write_bytes(b"fake image data")
    
    resource = SkillResource(
        uri="skill://test/image.png",
        name="image.png",
        skill_name="test",
        file_path=test_file,
        mime_type="image/png",
    )
    
    assert resource.uri == "skill://test/image.png"
    assert resource.name == "image.png"
    assert resource.skill_name == "test"
    assert resource.mime_type == "image/png"


def test_skill_resource_invalid_uri():
    """Testa que URI inválida levanta ValueError."""
    with pytest.raises(ValueError, match="URI must start with"):
        SkillResource(
            uri="http://invalid",
            name="test.png",
            skill_name="test",
            file_path=Path("/fake/path.png"),
        )


def test_skill_resource_missing_file():
    """Testa que arquivo inexistente levanta FileNotFoundError."""
    with pytest.raises(FileNotFoundError):
        SkillResource(
            uri="skill://test/missing.png",
            name="missing.png",
            skill_name="test",
            file_path=Path("/path/does/not/exist.png"),
        )
