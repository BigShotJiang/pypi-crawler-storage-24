"""
Descoberta de Skills no sistema de arquivos.

Seguindo o princípio Single Responsibility (SOLID), esta classe tem
apenas a responsabilidade de descobrir e carregar skills do disco.

A lógica de descoberta está isolada e pode ser facilmente testada
ou substituída por outra implementação (Open/Closed Principle).

Suporta dois formatos:
1. Padrão agentskills.io: Diretórios com SKILL.md + references/ + scripts/ + assets/
2. Formato simples: Arquivos .md soltos (fallback)
"""

import logging
from pathlib import Path
from typing import Iterator

from .models import Skill, SkillResource
from .utils import generate_skill_name, get_mime_type, parse_frontmatter

logger = logging.getLogger(__name__)


class SkillDiscovery:
    """
    Responsável por descobrir e carregar Agent Skills de um diretório.
    
    Esta classe implementa o padrão Repository, abstraindo a forma
    como as skills são armazenadas e carregadas.
    
    Suporta o padrão agentskills.io:
    - skills/nome-da-skill/SKILL.md (obrigatório)
    - skills/nome-da-skill/references/ (opcional)
    - skills/nome-da-skill/scripts/ (opcional)
    - skills/nome-da-skill/assets/ (opcional)
    """
    
    # Diretórios de recursos padrão do agentskills.io
    RESOURCE_DIRS = ["references", "scripts", "assets"]
    
    def __init__(self, skills_dir: Path):
        """
        Inicializa o discovery com um diretório de skills.
        
        Args:
            skills_dir: Diretório raiz contendo as skills
            
        Raises:
            ValueError: Se o diretório não existir
        """
        self.skills_dir = Path(skills_dir)
        if not self.skills_dir.exists():
            raise ValueError(f"Skills directory not found: {self.skills_dir}")
        if not self.skills_dir.is_dir():
            raise ValueError(f"Path is not a directory: {self.skills_dir}")
    
    def discover_skills(self) -> list[Skill]:
        """
        Descobre todas as skills no diretório configurado.
        
        Procura primeiro por diretórios com SKILL.md (padrão agentskills.io).
        Se não encontrar nenhum, procura por arquivos .md soltos (fallback).
        
        Returns:
            Lista de objetos Skill descobertos
            
        Note:
            Prioriza o padrão de diretórios sobre arquivos soltos para
            compatibilidade com agentskills.io.
        """
        skills = []
        
        # Primeiro tenta o padrão agentskills.io: diretórios com SKILL.md
        skill_dirs = self._find_skill_directories()
        
        if skill_dirs:
            logger.info(f"Using agentskills.io pattern (SKILL.md in directories)")
            for skill_dir in skill_dirs:
                try:
                    skill_file = skill_dir / "SKILL.md"
                    skill = self._load_skill(skill_file)
                    skills.append(skill)
                    logger.info(f"Discovered skill: {skill.name} (from {skill_dir.name}/)")
                except Exception as e:
                    logger.error(f"Failed to load skill from {skill_dir}: {e}")
                    continue
        else:
            # Fallback: busca arquivos .md soltos
            logger.info(f"No SKILL.md found, trying simple .md files pattern")
            for skill_file in self.skills_dir.rglob("*.md"):
                # Ignora arquivos SKILL.md órfãos 
                if skill_file.name == "SKILL.md":
                    continue
                    
                try:
                    skill = self._load_skill(skill_file)
                    skills.append(skill)
                    logger.info(f"Discovered skill: {skill.name}")
                except Exception as e:
                    logger.error(f"Failed to load skill {skill_file}: {e}")
                    continue
        
        if not skills:
            logger.warning(f"No skills found in {self.skills_dir}")
        
        return skills
    
    def _find_skill_directories(self) -> list[Path]:
        """
        Encontra diretórios que contêm SKILL.md.
        
        Returns:
            Lista de diretórios que contêm um arquivo SKILL.md
        """
        skill_dirs = []
        
        # Busca recursivamente por arquivos SKILL.md
        for skill_file in self.skills_dir.rglob("SKILL.md"):
            skill_dir = skill_file.parent
            # Evita diretórios escondidos ou especiais
            if not any(part.startswith('.') or part.startswith('_') 
                      for part in skill_dir.relative_to(self.skills_dir).parts):
                skill_dirs.append(skill_dir)
        
        return skill_dirs
    
    def discover_resources(self, skill: Skill) -> list[SkillResource]:
        """
        Descobre recursos estáticos associados a uma skill.
        
        Segue o padrão agentskills.io:
        - references/: Documentação de referência, APIs, esquemas
        - scripts/: Scripts executáveis (Python, Bash, etc)
        - assets/: Templates, ícones, arquivos base
        
        Args:
            skill: Skill para buscar recursos
            
        Returns:
            Lista de recursos descobertos
        """
        resources = []
        skill_dir = skill.file_path.parent
        
        # Busca nos diretórios padrão do agentskills.io
        for resource_dir_name in self.RESOURCE_DIRS:
            resource_dir = skill_dir / resource_dir_name
            
            if resource_dir.exists() and resource_dir.is_dir():
                # Busca recursivamente todos os arquivos
                for file_path in resource_dir.rglob("*"):
                    if file_path.is_file():
                        try:
                            resource = self._create_resource(
                                skill, 
                                file_path, 
                                resource_type=resource_dir_name
                            )
                            resources.append(resource)
                            logger.debug(
                                f"Discovered {resource_dir_name} resource: "
                                f"{file_path.name} for skill {skill.name}"
                            )
                        except Exception as e:
                            logger.error(f"Failed to load resource {file_path}: {e}")
        
        # Também busca arquivos soltos no diretório da skill (exceto SKILL.md)
        for file_path in skill_dir.iterdir():
            if (file_path.is_file() and 
                file_path.name != "SKILL.md" and 
                file_path.suffix != ".md"):
                try:
                    resource = self._create_resource(skill, file_path)
                    resources.append(resource)
                except Exception as e:
                    logger.error(f"Failed to load resource {file_path}: {e}")
        
        if resources:
            logger.info(f"Discovered {len(resources)} resources for skill {skill.name}")
        
        return resources
    
    def _load_skill(self, file_path: Path) -> Skill:
        """
        Carrega uma skill de um arquivo markdown.
        
        Args:
            file_path: Caminho do arquivo .md
            
        Returns:
            Objeto Skill carregado
            
        Raises:
            ValueError: Se o arquivo não puder ser parseado
        """
        # Lê o conteúdo do arquivo
        content = file_path.read_text(encoding="utf-8")
        
        # Parse frontmatter e conteúdo
        metadata, instructions = parse_frontmatter(content)
        
        # Extrai informações da skill
        skill_name = metadata.get("name") or generate_skill_name(file_path)
        title = metadata.get("title") or skill_name.replace("-", " ").title()
        description = metadata.get("description") or title
        
        # Cria objeto Skill
        return Skill(
            name=skill_name,
            title=title,
            description=description,
            instructions=instructions.strip(),
            file_path=file_path,
            metadata=metadata,
        )
    
    def _create_resource(
        self, 
        skill: Skill, 
        file_path: Path,
        resource_type: str | None = None
    ) -> SkillResource:
        """
        Cria um objeto SkillResource para um arquivo.
        
        Args:
            skill: Skill dona do recurso
            file_path: Caminho do arquivo do recurso
            resource_type: Tipo do recurso (references, scripts, assets) ou None
            
        Returns:
            Objeto SkillResource criado
        """
        skill_dir = skill.file_path.parent
        
        # Gera URI única para o recurso
        relative_path = file_path.relative_to(skill_dir)
        uri = f"skill://{skill.name}/{relative_path}"
        
        # Determina tipo MIME
        mime_type = get_mime_type(file_path)
        
        # Gera descrição baseada no tipo de recurso
        if resource_type == "references":
            description = f"Reference documentation: {file_path.name}"
        elif resource_type == "scripts":
            description = f"Script: {file_path.name}"
        elif resource_type == "assets":
            description = f"Asset file: {file_path.name}"
        else:
            description = f"Resource for {skill.title}: {file_path.name}"
        
        return SkillResource(
            uri=uri,
            name=file_path.name,
            skill_name=skill.name,
            file_path=file_path,
            mime_type=mime_type,
            description=description,
        )
