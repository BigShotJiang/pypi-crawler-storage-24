"""
Ponto de entrada principal para execução do módulo skillserver.

Permite executar o servidor com:
    python -m skillserver

Todas as configurações são lidas de variáveis de ambiente:
    SKILLS_DIR: Diretório das skills (padrão: ./skills)
    SERVER_HOST: Host para bind (padrão: 0.0.0.0)
    SERVER_PORT: Porta do servidor (padrão: 8000)
    SERVER_NAME: Nome do servidor (padrão: SkillServer)
    SERVER_VERSION: Versão do servidor (padrão: 0.1.0)
    LOG_LEVEL: Nível de log (padrão: INFO)
"""

from .server import create_server

if __name__ == "__main__":
    # create_server() lê automaticamente as variáveis de ambiente
    create_server()
