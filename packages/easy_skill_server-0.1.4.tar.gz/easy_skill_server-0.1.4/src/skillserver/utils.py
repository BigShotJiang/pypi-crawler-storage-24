"""
Funções utilitárias para parsing e manipulação de arquivos.

Seguindo o princípio Single Responsibility, cada função tem uma
responsabilidade específica e bem definida.
"""

import mimetypes
import re
from pathlib import Path
from typing import Any

import yaml


def parse_frontmatter(content: str) -> tuple[dict[str, Any], str]:
    """
    Extrai frontmatter YAML e conteúdo markdown de um arquivo.
    
    Args:
        content: Conteúdo completo do arquivo markdown
        
    Returns:
        Tupla com (metadados, conteúdo_markdown)
        
    Example:
        >>> content = '''---
        ... title: My Skill
        ... ---
        ... # Content here'''
        >>> metadata, body = parse_frontmatter(content)
        >>> metadata['title']
        'My Skill'
    """
    # Regex para capturar frontmatter YAML
    pattern = r'^---\s*\n(.*?)\n---\s*\n(.*)$'
    match = re.match(pattern, content, re.DOTALL)
    
    if not match:
        return {}, content
    
    yaml_content = match.group(1)
    markdown_content = match.group(2)
    
    try:
        metadata = yaml.safe_load(yaml_content) or {}
    except yaml.YAMLError as e:
        raise ValueError(f"Invalid YAML frontmatter: {e}")
    
    return metadata, markdown_content


def get_mime_type(file_path: Path) -> str:
    """
    Determina o tipo MIME de um arquivo baseado na extensão.
    
    Args:
        file_path: Caminho do arquivo
        
    Returns:
        String com o tipo MIME (ex: "image/png", "text/plain")
        
    Example:
        >>> get_mime_type(Path("image.png"))
        'image/png'
    """
    mime_type, _ = mimetypes.guess_type(str(file_path))
    return mime_type or "application/octet-stream"


def is_text_file(file_path: Path) -> bool:
    """
    Verifica se um arquivo é de texto ou binário.
    
    Args:
        file_path: Caminho do arquivo
        
    Returns:
        True se for arquivo de texto, False caso contrário
    """
    mime_type = get_mime_type(file_path)
    return mime_type.startswith("text/") or mime_type in [
        "application/json",
        "application/xml",
        "application/javascript",
    ]


def generate_skill_name(file_path: Path) -> str:
    """
    Gera um nome único para a skill baseado no caminho do arquivo.
    
    Args:
        file_path: Caminho do arquivo da skill
        
    Returns:
        Nome da skill (ex: "hello-world", "category/advanced-skill")
        
    Example:
        >>> generate_skill_name(Path("skills/hello-world.md"))
        'hello-world'
    """
    # Remove extensão e normaliza o nome
    name = file_path.stem
    # Converte para kebab-case
    name = re.sub(r'[^a-z0-9]+', '-', name.lower())
    name = name.strip('-')
    return name or "unnamed-skill"
