"""
SkillServer MCP - Biblioteca para servir Agent Skills via Model Context Protocol.

Esta biblioteca permite que qualquer pessoa suba um servidor de skills
facilmente usando MCP (Model Context Protocol) da Anthropic.

Exemplo de uso:
    ```python
    from skillserver import create_server
    
    # Criar e iniciar servidor
    create_server(
        skills_dir="./skills",
        host="0.0.0.0",
        port=8000
    )
    ```
"""

from .models import Skill, SkillResource
from .server import SkillServer, create_server

__version__ = "0.1.0"

__all__ = [
    "Skill",
    "SkillResource",
    "SkillServer",
    "create_server",
]
