"""
Ferramentas MCP para interação com Agent Skills.

Seguindo o princípio Single Responsibility, esta classe é responsável
apenas por registrar as ferramentas (tools) do MCP que permitem
aos agentes interagirem com as skills.

Dependency Inversion: Esta classe depende de abstrações (Skill, SkillResource)
ao invés de implementações concretas.
"""

import logging
from pathlib import Path
from typing import Any

from fastmcp import FastMCP

from .models import Skill, SkillResource

logger = logging.getLogger(__name__)


class SkillTools:
    """
    Registra e gerencia as ferramentas MCP para acesso às skills.
    
    Esta classe segue o padrão Strategy, encapsulando a lógica de
    registro de ferramentas e permitindo que seja facilmente testada
    ou substituída.
    """
    
    def __init__(self, mcp: FastMCP):
        """
        Inicializa o gerenciador de ferramentas.
        
        Args:
            mcp: Instância do FastMCP onde registrar as ferramentas
        """
        self.mcp = mcp
        self.skills: dict[str, Skill] = {}
        self.resources: dict[str, SkillResource] = {}
    
    def register_skills(self, skills: list[Skill]) -> None:
        """
        Registra uma lista de skills e suas ferramentas.
        
        Args:
            skills: Lista de skills a serem registradas
        """
        for skill in skills:
            self.skills[skill.name] = skill
        
        self._register_tools()
        logger.info(f"Registered {len(skills)} skills with MCP tools")
    
    def register_resources(self, resources: list[SkillResource]) -> None:
        """
        Registra recursos estáticos das skills.
        
        Args:
            resources: Lista de recursos a serem registrados
        """
        for resource in resources:
            self.resources[resource.uri] = resource
            # Registra cada recurso como um MCP resource
            self._register_resource(resource)
        
        logger.info(f"Registered {len(resources)} skill resources")
    
    def _register_tools(self) -> None:
        """Registra as ferramentas MCP principais."""
        
        @self.mcp.tool()
        def list_skills() -> list[dict[str, str]]:
            """
            Lista todas as Agent Skills disponíveis.
            
            Returns:
                Lista de skills com name, title e description
            """
            return [
                {
                    "name": skill.name,
                    "title": skill.title,
                    "description": skill.description,
                }
                for skill in self.skills.values()
            ]
        
        @self.mcp.tool()
        def get_skill_instructions(skill_name: str) -> str:
            """
            Obtém as instruções completas de uma skill específica.
            
            Args:
                skill_name: Nome da skill (ex: "hello-world")
                
            Returns:
                Instruções em markdown da skill
                
            Raises:
                ValueError: Se a skill não existir
            """
            skill = self.skills.get(skill_name)
            if not skill:
                available = ", ".join(self.skills.keys())
                raise ValueError(
                    f"Skill '{skill_name}' not found. "
                    f"Available skills: {available}"
                )
            
            return skill.instructions
        
        @self.mcp.tool()
        def search_skills(query: str) -> list[dict[str, str]]:
            """
            Busca skills por palavra-chave no título ou descrição.
            
            Args:
                query: Texto para buscar
                
            Returns:
                Lista de skills que correspondem à busca
            """
            query_lower = query.lower()
            results = []
            
            for skill in self.skills.values():
                if (query_lower in skill.title.lower() or
                    query_lower in skill.description.lower() or
                    query_lower in skill.name.lower()):
                    results.append({
                        "name": skill.name,
                        "title": skill.title,
                        "description": skill.description,
                    })
            
            return results
        
        @self.mcp.tool()
        def get_skill_metadata(skill_name: str) -> dict[str, Any]:
            """
            Obtém metadados completos de uma skill.
            
            Args:
                skill_name: Nome da skill
                
            Returns:
                Dicionário com todos os metadados da skill
            """
            skill = self.skills.get(skill_name)
            if not skill:
                raise ValueError(f"Skill '{skill_name}' not found")
            
            return {
                "name": skill.name,
                "title": skill.title,
                "description": skill.description,
                "file_path": str(skill.file_path),
                "metadata": skill.metadata,
            }
    
    def _register_resource(self, resource: SkillResource) -> None:
        """
        Registra um recurso individual como MCP resource.
        
        Args:
            resource: Recurso a ser registrado
        """
        # Para recursos de texto, podemos disponibilizar o conteúdo diretamente
        if resource.mime_type.startswith("text/"):
            @self.mcp.resource(resource.uri)
            def get_text_resource() -> str:
                """Retorna conteúdo de recurso de texto."""
                return resource.file_path.read_text(encoding="utf-8")
        else:
            # Para recursos binários, disponibilizamos metadados
            @self.mcp.resource(resource.uri)
            def get_binary_resource() -> dict[str, str]:
                """Retorna metadados de recurso binário."""
                return {
                    "uri": resource.uri,
                    "name": resource.name,
                    "mime_type": resource.mime_type,
                    "description": resource.description,
                    "note": "Binary resource - download via file system or API",
                }
