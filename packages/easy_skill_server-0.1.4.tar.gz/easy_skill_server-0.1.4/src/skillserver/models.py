"""
Modelos de dados para Skills e Resources.

Seguindo o princípio Single Responsibility (SOLID), este módulo contém
apenas as definições de dados, sem lógica de negócio.
"""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass
class Skill:
    """
    Representa uma Agent Skill descoberta no sistema.
    
    Attributes:
        name: Nome único da skill (ex: "hello-world")
        title: Título legível da skill
        description: Descrição breve da skill
        instructions: Instruções completas em markdown
        file_path: Caminho do arquivo da skill
        metadata: Metadados adicionais do frontmatter YAML
    """
    name: str
    title: str
    description: str
    instructions: str
    file_path: Path
    metadata: dict[str, Any] = field(default_factory=dict)
    
    def __post_init__(self):
        """Valida e normaliza os dados após inicialização."""
        if not self.name:
            raise ValueError("Skill name cannot be empty")
        if not self.title:
            self.title = self.name.replace("-", " ").title()
        if not self.description:
            self.description = self.title


@dataclass
class SkillResource:
    """
    Representa um recurso estático associado a uma skill.
    
    Resources podem ser imagens, arquivos de dados, ou qualquer outro
    arquivo que a skill precise disponibilizar para o agente.
    
    Attributes:
        uri: URI única do recurso (ex: "skill://hello-world/image.png")
        name: Nome do arquivo
        skill_name: Nome da skill dona do recurso
        file_path: Caminho físico do arquivo
        mime_type: Tipo MIME do recurso
        description: Descrição opcional do recurso
    """
    uri: str
    name: str
    skill_name: str
    file_path: Path
    mime_type: str = "application/octet-stream"
    description: str = ""
    
    def __post_init__(self):
        """Valida os dados após inicialização."""
        if not self.uri.startswith("skill://"):
            raise ValueError(f"Resource URI must start with 'skill://': {self.uri}")
        if not self.file_path.exists():
            raise FileNotFoundError(f"Resource file not found: {self.file_path}")
