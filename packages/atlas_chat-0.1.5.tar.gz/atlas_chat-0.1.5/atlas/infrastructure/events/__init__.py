"""Infrastructure event implementations."""
