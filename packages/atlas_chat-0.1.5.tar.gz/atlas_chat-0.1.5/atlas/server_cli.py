"""
Atlas Server CLI - Start the Atlas backend server.

Usage:
    atlas-server                              # Start with defaults
    atlas-server --port 8000                  # Custom port
    atlas-server --env /path/to/.env          # Custom env file
    atlas-server --config-folder /path/to/config  # Custom config folder
"""

import argparse
import os
import sys
from pathlib import Path


def _apply_env_file(env_path: Path) -> None:
    """Load environment variables from a .env file."""
    from dotenv import load_dotenv

    if not env_path.exists():
        print(f"Error: env file not found: {env_path}", file=sys.stderr)
        sys.exit(2)

    load_dotenv(dotenv_path=str(env_path))


def _apply_config_folder(config_folder: Path) -> None:
    """Set up config folder as the user config directory."""
    if not config_folder.exists():
        print(f"Error: config folder not found: {config_folder}", file=sys.stderr)
        sys.exit(2)

    os.environ["APP_CONFIG_DIR"] = str(config_folder.resolve())


def build_parser() -> argparse.ArgumentParser:
    """Build argument parser for atlas-server CLI."""
    parser = argparse.ArgumentParser(
        prog="atlas-server",
        description="Start the Atlas backend server with MCP integration.",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=None,
        help="Port to run the server on (default: 8000 or PORT env var).",
    )
    parser.add_argument(
        "--host",
        default=None,
        help="Host to bind to (default: 127.0.0.1 or ATLAS_HOST env var).",
    )
    parser.add_argument(
        "--env",
        dest="env_file",
        default=None,
        help="Path to .env file (default: .env in current directory or package root).",
    )
    parser.add_argument(
        "--config-folder",
        dest="config_folder",
        default=None,
        help="Path to config folder (sets APP_CONFIG_DIR).",
    )
    parser.add_argument(
        "--reload",
        action="store_true",
        help="Enable auto-reload for development (not recommended for production).",
    )
    parser.add_argument(
        "--workers",
        type=int,
        default=1,
        help="Number of worker processes (default: 1).",
    )
    parser.add_argument(
        "--version",
        action="store_true",
        help="Print version and exit.",
    )
    return parser


def run_server(args: argparse.Namespace) -> int:
    """Run the Atlas server with the given arguments."""
    import uvicorn

    # Determine host and port
    host = args.host if args.host is not None else os.getenv("ATLAS_HOST", "127.0.0.1")
    port = args.port if args.port is not None else int(os.getenv("PORT", "8000"))

    # Import the FastAPI app
    from atlas.main import app

    print(f"Starting Atlas server on {host}:{port}")

    if args.reload:
        print("Warning: --reload is enabled. This is not recommended for production.")
        uvicorn.run(
            "atlas.main:app",
            host=host,
            port=port,
            reload=True,
            workers=1,  # reload doesn't support multiple workers
        )
    else:
        uvicorn.run(
            app,
            host=host,
            port=port,
            workers=args.workers,
        )

    return 0


def main() -> None:
    """Main entry point for atlas-server CLI."""
    parser = build_parser()
    args = parser.parse_args()

    if args.version:
        from atlas.version import VERSION
        print(f"atlas-server version {VERSION}")
        sys.exit(0)

    # Apply env file first (before any other imports that might use env vars)
    env_dir = None
    if args.env_file:
        env_path = Path(args.env_file).expanduser()
        _apply_env_file(env_path)
        env_dir = env_path.resolve().parent
    else:
        # Try to find .env in current directory or package root
        cwd_env = Path.cwd() / ".env"
        if cwd_env.exists():
            _apply_env_file(cwd_env)
            env_dir = cwd_env.resolve().parent
        else:
            # Check package root (parent of atlas/)
            pkg_root_env = Path(__file__).resolve().parents[1] / ".env"
            if pkg_root_env.exists():
                _apply_env_file(pkg_root_env)
                env_dir = pkg_root_env.resolve().parent

    # Apply config folder if specified
    if args.config_folder:
        _apply_config_folder(Path(args.config_folder).expanduser())
    elif not os.environ.get("APP_CONFIG_DIR") and env_dir is not None:
        # Auto-detect config/ next to the .env that was loaded
        config_candidate = env_dir / "config"
        if config_candidate.is_dir():
            resolved = str(config_candidate.resolve())
            os.environ["APP_CONFIG_DIR"] = resolved
            print(f"Auto-detected config directory: {resolved}")

    sys.exit(run_server(args))


if __name__ == "__main__":
    main()
