"""
merge_cli/cli.py
CLI 入口，四条主命令：
  merge config   — 配置 API 地址和 Token
  merge predict  — 单变异预测
  merge batch    — 批量 VCF 提交
  merge status   — 查询批量任务进度
"""
import sys
import click
from rich.console import Console

from . import api, output
from .config import get_api_url, get_token, set_api_url, set_token, show_config

console = Console()

# ── 全局模型开关选项（两条命令共用）────────────────────────────
_MODEL_OPTIONS = [
    click.option("--no-alphagenome",   is_flag=True, default=False, help="跳过 AlphaGenome"),
    click.option("--no-hyenadna",      is_flag=True, default=False, help="跳过 HyenaDNA"),
    click.option("--no-nt",            is_flag=True, default=False, help="跳过 Nucleotide Transformer"),
    click.option("--no-alphamissense", is_flag=True, default=False, help="跳过 AlphaMissense"),
    click.option("--no-esm1b",         is_flag=True, default=False, help="跳过 ESM1b"),
    click.option("--no-gpn-msa",       is_flag=True, default=False, help="跳过 GPN-MSA"),
    click.option("--no-popeve",        is_flag=True, default=False, help="跳过 popEVE"),
    click.option("--no-evo2",          is_flag=True, default=False, help="跳过 Evo2"),
    click.option("--no-evo1",          is_flag=True, default=False, help="跳过 Evo1"),
]

def _add_model_options(f):
    for opt in reversed(_MODEL_OPTIONS):
        f = opt(f)
    return f

def _model_flags(**kwargs) -> dict:
    """把 --no-xxx 转成 use_xxx=True/False 传给 api 层。"""
    return {
        "use_alphagenome":   not kwargs.get("no_alphagenome",   False),
        "use_hyenadna":      not kwargs.get("no_hyenadna",      False),
        "use_nt":            not kwargs.get("no_nt",            False),
        "use_alphamissense": not kwargs.get("no_alphamissense", False),
        "use_esm1b":         not kwargs.get("no_esm1b",         False),
        "use_gpn_msa":       not kwargs.get("no_gpn_msa",       False),
        "use_popeve":        not kwargs.get("no_popeve",        False),
        "use_evo2":          not kwargs.get("no_evo2",          False),
        "use_evo1":          not kwargs.get("no_evo1",          False),
    }


# ─────────────────────────────────────────────────────────────
# 根命令
# ─────────────────────────────────────────────────────────────
@click.group()
@click.version_option("1.0.0", prog_name="merge")
def cli():
    """MERGE 变异致病性预测 CLI

    快速开始：

    \b
      merge config set-url https://your-server.com
      merge config set-token YOUR_API_TOKEN
      merge predict --chrom chr17 --pos 43092919 --ref A --alt G
    """


# ─────────────────────────────────────────────────────────────
# merge config
# ─────────────────────────────────────────────────────────────
@cli.group()
def config():
    """管理 API 地址和认证 Token。"""


@config.command("set-url")
@click.argument("url")
def config_set_url(url: str):
    """设置 API 服务器地址，例如 https://your-server.com"""
    set_api_url(url)
    console.print(f"[green]✓[/green] API 地址已保存：{url}")


@config.command("set-token")
@click.argument("token")
def config_set_token(token: str):
    """设置 API 认证 Token（保存在系统 keyring，不写入配置文件）"""
    set_token(token)
    console.print("[green]✓[/green] Token 已保存。")


@config.command("show")
def config_show():
    """查看当前配置。"""
    info = show_config()
    console.print(f"  API 地址    : [bold]{info['api_url']}[/bold]")
    console.print(f"  Token       : [bold]{info['token']}[/bold]")
    console.print(f"  配置文件    : [dim]{info['config_file']}[/dim]")


# ─────────────────────────────────────────────────────────────
# merge predict
# ─────────────────────────────────────────────────────────────
@cli.command()
@click.option("--chrom",   required=True,  help="染色体，如 chr17 或 17")
@click.option("--pos",     required=True,  type=int, help="变异位置（1-based）")
@click.option("--ref",     required=True,  help="参考碱基，如 A")
@click.option("--alt",     required=True,  help="突变碱基，如 G")
@click.option("--genome",  default="hg38", show_default=True,
              type=click.Choice(["hg38", "hg19"]), help="参考基因组版本")
@click.option("--format",  "fmt",
              default="table", show_default=True,
              type=click.Choice(["table", "json", "tsv"]),
              help="输出格式：table（彩色表格）/ json / tsv")
@click.option("--no-ensemble", is_flag=True, default=False,
              help="跳过 MERGE 集成打分（只返回各模型原始分数）")
@_add_model_options
def predict(chrom, pos, ref, alt, genome, fmt, no_ensemble, **kwargs):
    """单变异致病性预测。

    \b
    示例：
      merge predict --chrom chr17 --pos 43092919 --ref A --alt G
      merge predict --chrom chr17 --pos 43092919 --ref A --alt G --genome hg19
      merge predict --chrom chr1  --pos 100000   --ref C --alt T --no-evo2 --no-evo1
      merge predict --chrom chr1  --pos 100000   --ref C --alt T --format json > result.json
      merge predict --chrom chr1  --pos 100000   --ref C --alt T --format tsv  >> results.tsv
    """
    flags = _model_flags(**kwargs)

    # 规范化 chrom（兼容用户输入 17 或 chr17）
    if not chrom.startswith("chr"):
        chrom = "chr" + chrom

    with console.status("[bold cyan]正在预测…[/bold cyan]"):
        try:
            resp = api.predict_single(chrom, pos, ref, alt, genome, **flags)
        except Exception as e:
            console.print(f"[red]预测失败：{e}[/red]")
            sys.exit(1)

    if not resp.get("success"):
        console.print(f"[red]服务端错误：{resp.get('error')}[/red]")
        details = resp.get("details", {})
        for src, msg in details.items():
            console.print(f"  [dim]{src}: {msg}[/dim]")
        sys.exit(1)

    prediction = resp["prediction"]
    ensemble   = None

    if not no_ensemble:
        with console.status("[bold cyan]正在计算 MERGE 集成分数…[/bold cyan]"):
            try:
                # 用 dbnsfp 构造最简单的 all_transcripts
                dbnsfp = prediction.get("dbnsfp") or {}
                transcripts = [dbnsfp] if dbnsfp else []
                ens_resp = api.predict_ensemble(prediction, transcripts)
                if ens_resp.get("success"):
                    ensemble = ens_resp
            except Exception as e:
                console.print(f"[yellow]MERGE 集成分数获取失败（不影响原始分数）：{e}[/yellow]")

    output.render_single(prediction, ensemble, fmt=fmt, errors=prediction.get("errors"))


# ─────────────────────────────────────────────────────────────
# merge batch
# ─────────────────────────────────────────────────────────────
@cli.command()
@click.argument("vcf_file", type=click.Path(exists=True))
@click.option("--email",    required=True,  help="结果发送邮箱（必填）")
@click.option("--genome",   default="hg38", show_default=True,
              type=click.Choice(["hg38", "hg19"]))
@_add_model_options
def batch(vcf_file, email, genome, **kwargs):
    """批量 VCF 文件预测（异步，结果通过邮件发送）。

    \b
    服务器限制（由 views.py 中 RATE_LIMIT_CONFIG 控制）：
      - 每个 IP 每日最多 5 次异步任务
      - 同一邮箱两次提交间隔 ≥ 1 小时
      - 单次最多 2000 个变异

    \b
    示例：
      merge batch variants.vcf --email you@example.com
      merge batch variants.vcf.gz --email you@example.com --genome hg19 --no-evo2
    """
    flags = _model_flags(**kwargs)

    with console.status("[bold cyan]上传 VCF 文件…[/bold cyan]"):
        try:
            resp = api.submit_batch(vcf_file, email, genome, **flags)
        except Exception as e:
            console.print(f"[red]提交失败：{e}[/red]")
            sys.exit(1)

    if not resp.get("success"):
        console.print(f"[red]提交失败：{resp.get('error')}[/red]")
        sys.exit(1)

    output.render_batch_submitted(resp["job_id"], email)


# ─────────────────────────────────────────────────────────────
# merge register
# ─────────────────────────────────────────────────────────────
@cli.command()
@click.option("--username", prompt="用户名", help="3-30 位，字母/数字/_/-/.")
@click.option("--email",    prompt="邮箱")
@click.option("--password", prompt="密码", hide_input=True, confirmation_prompt="再次输入密码确认")
def register(username, email, password):
    """注册账号并自动保存 Token，注册后即可直接使用。

    \b
    示例：
      merge register
      merge register --username alice --email alice@lab.com --password MyPass123!
    """
    if not get_api_url():
        console.print("[red]错误：请先配置服务器地址：[/red]")
        console.print("  merge config set-url https://your-server.com")
        raise SystemExit(1)

    with console.status("[bold cyan]注册中…[/bold cyan]"):
        try:
            resp = api.register(username, email, password)
        except Exception as e:
            console.print(f"[red]注册失败：{e}[/red]")
            raise SystemExit(1)

    if not resp.get("success"):
        console.print(f"[red]注册失败：{resp.get('error')}[/red]")
        raise SystemExit(1)

    # 自动保存 Token，用户无需手动 set-token
    token = resp["token"]
    set_token(token)

    console.print(f"\n[bold green]✓ 注册成功！[/bold green]")
    console.print(f"  用户名 : [bold]{username}[/bold]")
    console.print(f"  Token  : [dim]{token[:8]}…[/dim]（已自动保存）")
    console.print(f"\n现在可以直接开始使用：")
    console.print(f"  [bold]merge predict --chrom chr17 --pos 43092919 --ref A --alt G[/bold]")


# ─────────────────────────────────────────────────────────────
# merge login  （已有账号，重新获取 Token）
# ─────────────────────────────────────────────────────────────
@cli.command()
@click.option("--username", prompt="用户名")
@click.option("--password", prompt="密码", hide_input=True)
def login(username, password):
    """已有账号时重新获取并保存 Token。

    \b
    示例：
      merge login
      merge login --username alice --password MyPass123!
    """
    if not get_api_url():
        console.print("[red]错误：请先配置服务器地址：[/red]")
        console.print("  merge config set-url https://your-server.com")
        raise SystemExit(1)

    with console.status("[bold cyan]登录中…[/bold cyan]"):
        try:
            resp = api.login(username, password)
        except Exception as e:
            console.print(f"[red]登录失败：{e}[/red]")
            raise SystemExit(1)

    if not resp.get("success"):
        console.print(f"[red]登录失败：{resp.get('error')}[/red]")
        raise SystemExit(1)

    set_token(resp["token"])
    console.print(f"[bold green]✓ 登录成功，Token 已更新。[/bold green]")


# ─────────────────────────────────────────────────────────────
# merge status
# ─────────────────────────────────────────────────────────────
@cli.command()
@click.argument("job_id")
@click.option("--watch", is_flag=True, default=False,
              help="每 30 秒轮询一次，直到任务完成")
def status(job_id, watch):
    """查询批量任务状态。

    \b
    示例：
      merge status A3F2C1B0
      merge status A3F2C1B0 --watch
    """
    import time

    def _poll():
        try:
            data = api.get_batch_status(job_id)
        except Exception as e:
            console.print(f"[red]查询失败：{e}[/red]")
            return None
        output.render_status(data)
        return data

    data = _poll()
    if not watch or not data:
        return

    while data and data.get("status") == "processing":
        console.print("\n[dim]30 秒后再次查询… Ctrl+C 退出[/dim]")
        try:
            time.sleep(30)
        except KeyboardInterrupt:
            break
        data = _poll()
