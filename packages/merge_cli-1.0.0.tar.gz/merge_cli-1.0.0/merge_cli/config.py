"""
merge_cli/config.py
管理 API 地址和 Token 的持久化存储。
Token 优先级：命令行 --token > 环境变量 MERGE_API_TOKEN > keyring 存储
"""
import os
import json
from pathlib import Path

import keyring

_SERVICE = "merge-cli"
_CONFIG_FILE = Path.home() / ".config" / "merge-cli" / "config.json"


def _load_file() -> dict:
    if _CONFIG_FILE.exists():
        try:
            return json.loads(_CONFIG_FILE.read_text())
        except Exception:
            pass
    return {}


def _save_file(data: dict) -> None:
    _CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
    _CONFIG_FILE.write_text(json.dumps(data, indent=2))


def get_api_url() -> str:
    env = os.environ.get("MERGE_API_URL")
    if env:
        return env.rstrip("/")
    cfg = _load_file()
    return cfg.get("api_url", "").rstrip("/")


def set_api_url(url: str) -> None:
    cfg = _load_file()
    cfg["api_url"] = url.rstrip("/")
    _save_file(cfg)


def get_token() -> str:
    env = os.environ.get("MERGE_API_TOKEN")
    if env:
        return env
    try:
        tok = keyring.get_password(_SERVICE, "token")
        return tok or ""
    except Exception:
        cfg = _load_file()
        return cfg.get("token", "")


def set_token(token: str) -> None:
    try:
        keyring.set_password(_SERVICE, "token", token)
    except Exception:
        # keyring 不可用时回退到配置文件
        cfg = _load_file()
        cfg["token"] = token
        _save_file(cfg)


def show_config() -> dict:
    return {
        "api_url": get_api_url() or "(未设置)",
        "token":   ("***" + get_token()[-4:]) if get_token() else "(未设置)",
        "config_file": str(_CONFIG_FILE),
    }
