"""
merge_cli/output.py
把 API 返回的原始 JSON 渲染成三种格式：
  - table  : Rich 彩色表格（终端默认）
  - json   : 紧凑 JSON（管道/脚本用）
  - tsv    : 制表符分隔（直接导入 Excel / R / Python）
字段来源完全对应 views.py 里 batch_predictions.csv 的列定义。
"""
import json as _json
import sys
from typing import Optional

from rich.console import Console
from rich.table import Table
from rich import box
from rich.text import Text

console = Console()


# ─── 颜色映射（对应 ensemble_predict.py: interpret_score 返回的 label）───
_LABEL_STYLE = {
    "Pathogenic":         "bold red",
    "Likely Pathogenic":  "red",
    "Uncertain":          "yellow",
    "Likely Benign":      "green",
    "Benign":             "bold green",
}


def _fmt(val, decimals: int = 4) -> str:
    """把 None / 'N/A' / float 统一格式化为字符串。"""
    if val is None or val in ("N/A", ".", ""):
        return "-"
    try:
        return f"{float(val):.{decimals}f}"
    except (ValueError, TypeError):
        return str(val)


def _score_text(score: Optional[float], label: Optional[str]) -> Text:
    """把 MERGE 分数 + 解读标签合并成带颜色的 Rich Text。"""
    if score is None:
        return Text("-", style="dim")
    pct = f"{score * 100:.1f}%"
    style = _LABEL_STYLE.get(label or "", "white")
    t = Text(pct, style=style)
    if label:
        t.append(f"  {label}", style=style)
    return t


def _extract_flat(prediction: dict, ensemble: Optional[dict] = None) -> dict:
    """
    把 /predict/ + /ensemble/ 的嵌套 JSON 压平成一行字典，
    字段顺序与 batch_predictions.csv 的列头一致。
    """
    inp   = prediction.get("input", {})
    db    = prediction.get("dbnsfp") or {}
    ann   = db.get("annotations") or {}
    dlm   = db.get("dl_models") or {}
    ag    = prediction.get("alphagenome") or {}
    hy    = prediction.get("hyenadna") or {}
    nt    = prediction.get("nt") or {}
    gpn   = prediction.get("gpn_msa") or {}
    pop   = prediction.get("popeve") or {}
    evo2  = prediction.get("evo2") or {}
    evo1  = prediction.get("evo1") or {}

    # ensemble 分数
    ens_score = ens_label = ens_model = None
    if ensemble:
        for _key, _val in ensemble.get("ensemble_results", {}).items():
            ens_score = _val.get("score")
            ens_label = (_val.get("interpretation") or {}).get("label")
            ens_model = _key
            break

    return {
        "Chr":                inp.get("chrom", ann.get("chr", "-")),
        "Pos":                inp.get("pos", ann.get("pos", "-")),
        "Ref":                inp.get("ref", ann.get("ref", "-")),
        "Alt":                inp.get("alt", ann.get("alt", "-")),
        "Gene":               ann.get("genename", "-"),
        "Transcript":         ann.get("Ensembl_transcriptid", "-"),
        "MERGE_Score":        ens_score,
        "MERGE_Label":        ens_label,
        "MERGE_Model":        ens_model,
        # dbNSFP 里的 DL 模型（来自 DL_MODELS 字典，col 132/129）
        "AlphaMissense":      (dlm.get("AlphaMissense") or {}).get("score"),
        "ESM1b":              (dlm.get("ESM1b") or {}).get("score"),
        # 独立模型
        "GPN_MSA":            gpn.get("score"),
        "popEVE":             pop.get("score"),
        "AlphaGenome_Mean":   (ag.get("statistics") or {}).get("raw_score_mean"),
        "HyenaDNA":           hy.get("score"),
        "NT":                 nt.get("score"),
        "Evo2_LLR":           evo2.get("llr_score"),
        "Evo2_Ref":           evo2.get("ref_score"),
        "Evo2_Var":           evo2.get("var_score"),
        "Evo2_Interp":        evo2.get("interpretation"),
        "Evo1_Delta":         evo1.get("evo1_delta_score"),
        "Evo1_Ref":           evo1.get("ref_score"),
        "Evo1_Var":           evo1.get("var_score"),
    }


# ─────────────────────────────────────────────────────────────
# 公开接口
# ─────────────────────────────────────────────────────────────

def render_single(prediction: dict, ensemble: Optional[dict],
                  fmt: str = "table", errors: dict = None) -> None:
    """渲染单变异预测结果。"""
    flat = _extract_flat(prediction, ensemble)

    if fmt == "json":
        _json.dump({"prediction": prediction, "ensemble": ensemble}, sys.stdout, indent=2, ensure_ascii=False)
        print()
        return

    if fmt == "tsv":
        print("\t".join(flat.keys()))
        print("\t".join(_fmt(v) for v in flat.values()))
        return

    # ── Rich table ──────────────────────────────────────────
    t = Table(box=box.ROUNDED, show_header=True, header_style="bold cyan",
              title="MERGE 预测结果", title_style="bold")
    t.add_column("项目",     style="dim", no_wrap=True, min_width=18)
    t.add_column("结果",     min_width=30)

    # 变异基本信息
    t.add_section()
    t.add_row("变异位点",
              f"[bold]{flat['Chr']}:{flat['Pos']}  {flat['Ref']} → {flat['Alt']}[/bold]")
    t.add_row("基因 / 转录本",
              f"{_fmt(flat['Gene'])}  /  {_fmt(flat['Transcript'])}")

    # MERGE 集成分数
    t.add_section()
    t.add_row("MERGE 致病性",
              _score_text(flat["MERGE_Score"], flat["MERGE_Label"]))
    t.add_row("使用模型", _fmt(flat["MERGE_Model"]))

    # 各模型分数
    t.add_section()
    for label, key in [
        ("AlphaMissense",  "AlphaMissense"),
        ("ESM1b",          "ESM1b"),
        ("GPN-MSA",        "GPN_MSA"),
        ("popEVE",         "popEVE"),
        ("AlphaGenome",    "AlphaGenome_Mean"),
        ("HyenaDNA",       "HyenaDNA"),
        ("NT",             "NT"),
        ("Evo2 LLR",       "Evo2_LLR"),
        ("Evo1 Delta",     "Evo1_Delta"),
    ]:
        val = flat[key]
        t.add_row(label, _fmt(val))

    console.print(t)

    # 警告/错误
    if errors:
        console.print("\n[yellow]部分模型未返回结果：[/yellow]")
        for src, msg in errors.items():
            console.print(f"  [dim]{src}:[/dim] {msg}")


def render_batch_submitted(job_id: str, email: str) -> None:
    console.print(f"\n[bold green]✓ 批量任务已提交[/bold green]")
    console.print(f"  Job ID : [bold]{job_id}[/bold]")
    console.print(f"  邮箱   : {email}")
    console.print(f"  完成后结果将发送至邮箱（附件含 3 个文件）")
    console.print(f"\n查询进度：[bold]merge status {job_id}[/bold]")


def render_status(status_data: dict) -> None:
    """渲染批量任务状态。"""
    if not status_data.get("found"):
        console.print(f"[red]任务不存在或服务已重启。[/red]")
        return

    state = status_data.get("status", "unknown")
    color = {"processing": "yellow", "complete": "green", "error": "red"}.get(state, "white")

    t = Table(box=box.SIMPLE, show_header=False)
    t.add_column("key",   style="dim")
    t.add_column("value")
    t.add_row("状态",       f"[{color}]{state}[/{color}]")
    t.add_row("提交时间",   status_data.get("submitted_at", "-"))
    t.add_row("成功变异数", str(status_data.get("n_ok", "-")))
    t.add_row("警告/错误",  str(status_data.get("n_err", "-")))
    t.add_row("邮件已发送", "是" if status_data.get("mail_sent") else "否")
    console.print(t)

    logs = status_data.get("log", [])
    if logs:
        console.print("\n[dim]── 任务日志 ──────────────────────────[/dim]")
        for line in logs[-20:]:   # 最多显示最后 20 行
            console.print(f"  [dim]{line}[/dim]")
