# MERGE CLI

MERGE 变异致病性预测命令行工具。所有计算在服务器端完成，本地只需 Python 3.9+。

## 安装

```bash
pip install merge-cli
```

## 快速开始

```bash
# 1. 配置服务器地址（只需配置一次）
merge config set-url https://your-server.com
merge config set-token YOUR_API_TOKEN

# 2. 单变异预测
merge predict --chrom chr17 --pos 43092919 --ref A --alt G

# 3. 批量预测（上传 VCF，结果发邮件）
merge batch my_variants.vcf --email you@example.com
```

## 命令详解

### `merge predict` — 单变异预测

```
选项：
  --chrom     染色体（chr17 或 17 均可）   [必填]
  --pos       变异位置（1-based）           [必填]
  --ref       参考碱基                      [必填]
  --alt       突变碱基                      [必填]
  --genome    hg38 / hg19                  [默认: hg38]
  --format    table / json / tsv           [默认: table]
  --no-ensemble   跳过 MERGE 集成打分
  --no-alphagenome / --no-hyenadna / --no-nt
  --no-alphamissense / --no-esm1b / --no-gpn-msa
  --no-popeve / --no-evo2 / --no-evo1
```

**输出示例（table 模式）：**

```
╭──────────────────────────────────────────╮
│          MERGE 预测结果                   │
├──────────────────┬───────────────────────┤
│ 变异位点         │ chr17:43092919 A → G  │
│ 基因 / 转录本    │ BRCA1 / ENST00000357654│
├──────────────────┼───────────────────────┤
│ MERGE 致病性     │ 87.3%  Likely Pathogenic│
│ 使用模型         │ ClinVar               │
├──────────────────┼───────────────────────┤
│ AlphaMissense    │ 0.9341                │
│ ESM1b            │ -3.2180               │
│ GPN-MSA          │ -1.4420               │
│ popEVE           │ 0.8812                │
│ AlphaGenome      │ 0.0234                │
│ HyenaDNA         │ -2.1100               │
│ NT               │ -1.8830               │
│ Evo2 LLR         │ -4.2210               │
│ Evo1 Delta       │ -3.9910               │
╰──────────────────┴───────────────────────╯
```

**管道输出（TSV 模式，方便写脚本）：**

```bash
merge predict --chrom chr17 --pos 43092919 --ref A --alt G --format tsv >> results.tsv
```

**脚本批量调用单变异（小于 20 个时比上传 VCF 更快）：**

```bash
while IFS=$'\t' read -r chrom pos ref alt; do
    merge predict --chrom "$chrom" --pos "$pos" --ref "$ref" --alt "$alt" --format tsv
done < variants.tsv >> results.tsv
```

---

### `merge batch` — 批量 VCF 预测

```bash
merge batch variants.vcf --email you@example.com
merge batch variants.vcf.gz --email you@example.com --genome hg19 --no-evo2
```

任务提交成功后返回 Job ID，结果通过邮件发送，附件包含：
- `batch_predictions.csv`  — 所有模型分数汇总（可直接用 Excel 打开）
- `batch_predictions.vcf`  — 标准 VCF 格式，含 MERGE 及各模型分数
- `imputation_details.csv` — MERGE 各特征缺失填补情况

服务端限制：每 IP 每日 5 次，同一邮箱间隔 1 小时，单次最多 2000 个变异。

---

### `merge status` — 查询批量任务

```bash
merge status A3F2C1B0          # 查看一次
merge status A3F2C1B0 --watch  # 每 30 秒轮询
```

---

## 环境变量（适合 CI / 服务器环境）

```bash
export MERGE_API_URL=https://your-server.com
export MERGE_API_TOKEN=your-token
merge predict --chrom chr1 --pos 100000 --ref C --alt T
```
