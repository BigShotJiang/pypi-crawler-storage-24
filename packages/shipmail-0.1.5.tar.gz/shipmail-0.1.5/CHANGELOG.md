# Changelog

## [0.1.5](https://github.com/jcoulaud/ShipMail/compare/shipmail-python-v0.1.4...shipmail-python-v0.1.5) (2026-03-25)


### Bug Fixes

* sync SDK types and OpenAPI spec with actual API responses ([#234](https://github.com/jcoulaud/ShipMail/issues/234)) ([4e628e8](https://github.com/jcoulaud/ShipMail/commit/4e628e80876c7012e9f97c5a1bf424805c0880e3))

## [0.1.4](https://github.com/jcoulaud/ShipMail/compare/shipmail-python-v0.1.3...shipmail-python-v0.1.4) (2026-03-17)


### Features

* add attachment support to API send endpoint ([#199](https://github.com/jcoulaud/ShipMail/issues/199)) ([5d684c1](https://github.com/jcoulaud/ShipMail/commit/5d684c14afd9a119cc058f0fe7cac547b5785df9))

## [0.1.3](https://github.com/jcoulaud/ShipMail/compare/shipmail-python-v0.1.2...shipmail-python-v0.1.3) (2026-03-15)


### Features

* improve API developer experience ([#191](https://github.com/jcoulaud/ShipMail/issues/191)) ([ed5eeb0](https://github.com/jcoulaud/ShipMail/commit/ed5eeb04e6e5f4cc7e1cb8fdfe1a0c437c35b1df))

## [0.1.2](https://github.com/jcoulaud/ShipMail/compare/shipmail-python-v0.1.1...shipmail-python-v0.1.2) (2026-03-14)


### Features

* auto-reply / out-of-office vacation responder ([#174](https://github.com/jcoulaud/ShipMail/issues/174)) ([3ea6d89](https://github.com/jcoulaud/ShipMail/commit/3ea6d89624d0a5dceb1592abbdb82350dc572035))

## [0.1.1](https://github.com/jcoulaud/ShipMail/compare/shipmail-python-v0.1.0...shipmail-python-v0.1.1) (2026-03-14)


### Features

* Python SDK with sync and async clients ([#171](https://github.com/jcoulaud/ShipMail/issues/171)) ([77cf188](https://github.com/jcoulaud/ShipMail/commit/77cf18832bafed9a2b15b261786f4e2529a9b794))

## 0.1.0 (Unreleased)

Initial release of the ShipMail Python SDK.

- Sync client (`ShipMail`) and async client (`AsyncShipMail`)
- All API resources: Domains, Mailboxes, Messages, Threads, Webhooks, Suppressions, Status
- Cursor-based auto-pagination (sync and async iterators)
- Webhook signature verification with HMAC-SHA256
- Typed error hierarchy matching API error responses
- Automatic retries with exponential backoff on 5xx and 429 responses
- Context manager support for client lifecycle
- PEP 561 typed package
