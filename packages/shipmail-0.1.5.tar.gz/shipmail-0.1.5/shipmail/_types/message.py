from __future__ import annotations

from typing import Literal, TypedDict, Union

from .common import EmailRecipient, EmailRecipientInput, MessageSource, MessageStatus, PaginationParams


class AttachmentMetadata(TypedDict):
    filename: str
    size: int
    content_type: str


class Message(TypedDict):
    object: Literal["message"]
    id: str
    mailbox_id: str
    thread_id: str | None
    subject: str | None
    from_address: str | None
    to_addresses: list[EmailRecipient] | None
    cc_addresses: list[EmailRecipient] | None
    bcc_addresses: list[EmailRecipient] | None
    attachments: list[AttachmentMetadata] | None
    source: MessageSource
    status: MessageStatus
    created_at: str
    updated_at: str


class _AttachmentRequired(TypedDict):
    filename: str
    content: str


class Attachment(_AttachmentRequired, total=False):
    content_type: str


class _SendMessageRequired(TypedDict):
    to: list[EmailRecipientInput]
    subject: str


class SendMessageParams(_SendMessageRequired, total=False):
    mailbox_id: str
    cc: list[EmailRecipientInput]
    bcc: list[EmailRecipientInput]
    reply_to: EmailRecipientInput
    html: str
    text: str
    in_reply_to: str
    references: list[str]
    attachments: list[Attachment]


# Allow specifying from as a key (reserved word in Python, but valid in TypedDict)
SendMessageParamsWithFrom = Union[SendMessageParams, dict[str, object]]


class _ListMessagesRequired(TypedDict):
    mailbox_id: str


class ListMessagesParams(_ListMessagesRequired, PaginationParams, total=False):
    pass


class _ReplyToMessageRequired(TypedDict):
    to: list[EmailRecipientInput]


class ReplyToMessageParams(_ReplyToMessageRequired, total=False):
    html: str
    text: str
    cc: list[EmailRecipientInput]
