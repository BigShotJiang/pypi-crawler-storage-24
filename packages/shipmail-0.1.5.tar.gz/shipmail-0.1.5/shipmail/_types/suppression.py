from __future__ import annotations

from typing import Literal, TypedDict

from .common import PaginationParams


class Suppression(TypedDict):
    object: Literal["suppression"]
    email_address: str
    reason: str
    created_at: str


ListSuppressionsParams = PaginationParams
