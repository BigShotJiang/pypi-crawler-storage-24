from __future__ import annotations

from typing import Any, Literal, TypedDict

from .common import PaginationParams, WebhookDeliveryStatus, WebhookEventType


class Webhook(TypedDict):
    object: Literal["webhook"]
    id: str
    url: str
    events: list[WebhookEventType]
    active: bool
    description: str | None
    created_at: str
    updated_at: str


class WebhookWithSecret(Webhook):
    secret: str


class _CreateWebhookParamsRequired(TypedDict):
    url: str
    events: list[WebhookEventType]


class CreateWebhookParams(_CreateWebhookParamsRequired, total=False):
    description: str


class UpdateWebhookParams(TypedDict, total=False):
    url: str
    events: list[WebhookEventType]
    description: str | None
    active: bool


ListWebhooksParams = PaginationParams


class RotateSecretResponse(TypedDict):
    secret: str
    previous_secret_expires_at: str


class TestWebhookResponse(TypedDict):
    event_id: str


class WebhookDelivery(TypedDict):
    object: Literal["webhook_delivery"]
    id: str
    event_id: str
    event_type: WebhookEventType
    status: WebhookDeliveryStatus
    attempts: int
    last_status_code: int | None
    last_error: str | None
    created_at: str
    delivered_at: str | None


class ListDeliveriesParams(PaginationParams, total=False):
    status: WebhookDeliveryStatus
    event_type: WebhookEventType


class WebhookEvent(TypedDict):
    event_id: str
    event_type: WebhookEventType
    created_at: str
    data: Any
