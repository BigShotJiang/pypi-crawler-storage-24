from __future__ import annotations

from typing import TypedDict

from .common import EmailRecipientInput, PaginationParams


class ListThreadsParams(PaginationParams, total=False):
    mailbox_id: str


class GetThreadParams(TypedDict, total=False):
    cursor: str
    limit: int


class ReplyToThreadParams(TypedDict, total=False):
    html: str
    text: str
    to: list[EmailRecipientInput]
    cc: list[EmailRecipientInput]
