from __future__ import annotations

from typing import Literal, TypedDict

from .common import DomainStatus, PaginationParams


class _DomainRequired(TypedDict):
    object: Literal["domain"]
    id: str
    name: str
    status: DomainStatus
    managed_by: Literal["external", "namecom"]
    dns_provider: str | None
    mx_verified: bool
    spf_verified: bool
    dkim_verified: bool
    outbound_verified: bool
    catch_all_mailbox_id: str | None
    verified_at: str | None
    created_at: str
    updated_at: str


class Domain(_DomainRequired, total=False):
    registration: DomainRegistrationInfo


class CreateDomainParams(TypedDict):
    name: str


class UpdateDomainParams(TypedDict, total=False):
    catch_all_mailbox_id: str | None


ListDomainsParams = PaginationParams


class DomainVerificationRecords(TypedDict):
    mx: bool
    spf: bool
    dkim: bool


class DomainVerificationResult(TypedDict):
    all_verified: bool
    records: DomainVerificationRecords
    outbound_verified: bool
    outbound_error: bool
    existing_spf: str | None
    suggested_spf: str | None
    conflicting_mx: list[str]


class DomainSearchResult(TypedDict):
    domain_name: str
    available: bool
    purchase_price: float | None
    renewal_price: float | None
    currency: str
    premium: bool


class SearchDomainsParams(TypedDict):
    keyword: str


class _RegistrationContactRequired(TypedDict):
    first_name: str
    last_name: str
    address1: str
    city: str
    zip: str
    country: str
    phone: str
    email: str


class RegistrationContact(_RegistrationContactRequired, total=False):
    address2: str
    state: str


class _RegisterDomainParamsRequired(TypedDict):
    name: str
    contact: RegistrationContact


class RegisterDomainParams(_RegisterDomainParamsRequired, total=False):
    years: int


class DomainRegistrationInfo(TypedDict):
    expires_at: str
    auto_renew: bool
    renewal_price: float
    privacy_enabled: bool
    currency: str
    registered_at: str


class DomainSearchResponse(TypedDict):
    results: list[DomainSearchResult]


