"""Deploy proxy server — interactive wizard and provisioner execution."""

from __future__ import annotations

import subprocess
from pathlib import Path

from meridian.commands.resolve import (
    ensure_server_connection,
    fetch_credentials,
    resolve_server,
)
from meridian.config import CREDS_BASE, SERVERS_FILE, is_ipv4
from meridian.console import confirm, err_console, fail, info, line, ok, prompt
from meridian.credentials import ServerCredentials
from meridian.servers import ServerEntry, ServerRegistry


def run(
    ip: str = "",
    domain: str = "",
    email: str = "",
    sni: str = "",
    xhttp: bool = False,
    name: str = "",
    user: str = "root",
    yes: bool = False,
    requested_server: str = "",
    legacy: bool = False,
) -> None:
    """Deploy a VLESS+Reality proxy server."""
    registry = ServerRegistry(SERVERS_FILE)
    server_ip = ip
    ansible_user = user

    # --server flag: resolve from registry
    if requested_server:
        if server_ip:
            fail("Cannot use both positional IP and --server flag", hint_type="user")
        entry = registry.find(requested_server)
        if not entry:
            if is_ipv4(requested_server):
                server_ip = requested_server
            else:
                fail(
                    f"Server '{requested_server}' not found",
                    hint="See registered servers: meridian server list",
                    hint_type="user",
                )
        else:
            server_ip = entry.host
            if user == "root" and entry.user:
                ansible_user = entry.user

    # Interactive wizard if no IP given
    if not server_ip:
        sni_display = sni or "www.microsoft.com"
        err_console.print("  Deploy a private internet connection that censors can't detect.")
        err_console.print(f"  Your server will impersonate [dim]{sni_display}[/dim] — probes")
        err_console.print("  get a real TLS certificate back. Takes ~2 minutes. Safe to re-run.")
        err_console.print()
        line()
        err_console.print()
        err_console.print("  [bold]Where is the server?[/bold]\n")

        detected_ip = _detect_public_ip()

        while True:
            server_ip = prompt("IP address", default=detected_ip)
            if is_ipv4(server_ip):
                break
            err_console.print("  [error]Enter a valid IPv4 address (e.g. 123.45.67.89)[/error]")

        ansible_user = prompt("SSH user", default="root")
        if ansible_user != "root":
            err_console.print("  [dim](sudo will be used for privileged operations)[/dim]")

        err_console.print()
        err_console.print("  [bold]Optional — CDN fallback:[/bold]\n")

        # Suggest domain from saved credentials
        suggested_domain = ""
        creds_dir = CREDS_BASE / server_ip
        if (creds_dir / "proxy.yml").exists():
            saved_creds = ServerCredentials.load(creds_dir / "proxy.yml")
            suggested_domain = saved_creds.server.domain or ""

        if suggested_domain:
            err_console.print(f"  [dim]Detected: {suggested_domain}[/dim]")

        domain = prompt("Domain", default=suggested_domain or "skip")
        if domain in ("skip", ""):
            domain = ""

        err_console.print()
        line()
        err_console.print()
        err_console.print("  [bold]Summary[/bold]\n")
        err_console.print(f"  Target:  [ok]{ansible_user}@{server_ip}[/ok]")
        if domain:
            err_console.print(f"  Domain:  [ok]{domain}[/ok]")
            err_console.print("  Mode:    Reality + CDN fallback")
        else:
            err_console.print("  Domain:  [dim](none)[/dim]")
            err_console.print("  Mode:    Standalone (Reality only)")
        err_console.print()
        line()

        if not yes:
            confirm(f"Deploy to {ansible_user}@{server_ip}?")
        err_console.print()

    # Validate IP
    if not is_ipv4(server_ip):
        fail(
            f"Invalid IP address: {server_ip}",
            hint="Enter a valid IPv4 address (e.g. meridian setup 123.45.67.89)",
            hint_type="user",
        )

    # Resolve and prepare
    resolved = resolve_server(
        registry,
        explicit_ip=server_ip,
        user=ansible_user,
    )

    resolved = ensure_server_connection(resolved)
    fetch_credentials(resolved)

    # Migrate v1 credentials to v2
    proxy_file = resolved.creds_dir / "proxy.yml"
    if proxy_file.exists():
        creds = ServerCredentials.load(proxy_file)
        if creds.has_credentials:
            creds.save(proxy_file)  # Re-save as v2 if loaded from v1

    # Suggest scanned SNI if available and no --sni was given
    if not sni:
        proxy_file = resolved.creds_dir / "proxy.yml"
        if proxy_file.exists():
            creds = ServerCredentials.load(proxy_file)
            if creds.server.scanned_sni:
                info(f"Detected optimal SNI from scan: {creds.server.scanned_sni}")
                if yes:
                    sni = creds.server.scanned_sni
                else:
                    answer = prompt(f"Use {creds.server.scanned_sni} as SNI target? (Y/n)")
                    if answer.lower() != "n":
                        sni = creds.server.scanned_sni

    # Route to legacy Ansible or new Python provisioner
    if legacy:
        _run_ansible(resolved, domain, email, sni, name, xhttp)
    else:
        _run_provisioner(resolved, domain, sni, name, xhttp)

    # Register server
    registry.add(ServerEntry(host=resolved.ip, user=resolved.user))

    # Success output
    _print_success(resolved, name, domain)


def _run_provisioner(
    resolved: object,  # ResolvedServer
    domain: str,
    sni: str,
    name: str,
    xhttp: bool,
) -> None:
    """Run the Python provisioner pipeline."""
    from meridian.provision import ProvisionContext, Provisioner, build_setup_steps

    ctx = ProvisionContext(
        ip=resolved.ip,  # type: ignore[attr-defined]
        user=resolved.user,  # type: ignore[attr-defined]
        domain=domain,
        sni=sni or "www.microsoft.com",
        xhttp_enabled=xhttp or True,  # default on
        creds_dir=str(resolved.creds_dir),  # type: ignore[attr-defined]
    )

    # Compute ports deterministically (matching group_vars/all.yml seed pattern)
    import hashlib

    seed = int(hashlib.md5(ctx.ip.encode()).hexdigest()[:8], 16)  # noqa: S324
    ctx.panel_port = 2000 + (seed % 1000)
    ctx.xhttp_port = 30000 + ((seed + 1) % 10000)
    ctx.reality_port = (10000 + (seed + 2) % 1000) if ctx.domain_mode else 443

    # Load existing credentials into context if available
    proxy_file = Path(ctx.creds_dir) / "proxy.yml"
    if proxy_file.exists():
        from meridian.credentials import ServerCredentials

        creds = ServerCredentials.load(proxy_file)
        ctx["credentials"] = creds
        if creds.panel.username and creds.panel.password:
            ctx["panel_configured"] = True
            ctx["panel_username"] = creds.panel.username
            ctx["panel_password"] = creds.panel.password
            ctx["web_base_path"] = creds.panel.web_base_path or ""
            ctx["info_page_path"] = creds.panel.info_page_path or ""
            # Use saved panel port (not computed) for re-runs
            if creds.panel.port:
                ctx.panel_port = creds.panel.port

    # First client name
    ctx["first_client_name"] = name or "default"

    err_console.print()
    info(f"Configuring server at {ctx.ip}...")
    if domain:
        info(f"Domain: {domain}")
    if xhttp:
        info("XHTTP: enabled (enhanced stealth)")
    err_console.print()

    steps = build_setup_steps(ctx)
    provisioner = Provisioner(steps)

    from meridian.ssh import ServerConnection

    conn = resolved.conn  # type: ignore[attr-defined]
    if not isinstance(conn, ServerConnection):
        fail("No SSH connection available", hint_type="bug")

    results = provisioner.run(conn, ctx)

    # Check for failures
    failed = [r for r in results if r.status == "failed"]
    if failed:
        fail(
            "Setup failed",
            hint=f"Step '{failed[0].name}' failed: {failed[0].detail}\nRun: meridian check {ctx.ip}",
            hint_type="system",
        )

    err_console.print()
    ok("All steps completed successfully")


def _run_ansible(
    resolved: object,  # ResolvedServer
    domain: str,
    email: str,
    sni: str,
    name: str,
    xhttp: bool,
) -> None:
    """Legacy: run Ansible playbook."""
    from meridian.ansible import ensure_ansible, ensure_collections, ensure_qrencode, get_playbooks_dir, run_playbook

    ensure_ansible()
    ensure_qrencode()
    playbooks_dir = get_playbooks_dir()
    ensure_collections(playbooks_dir)

    extra_vars: dict[str, str] = {}
    if domain:
        extra_vars["domain"] = domain
    if email:
        extra_vars["email"] = email
    if sni:
        extra_vars["reality_sni"] = sni
    if name:
        extra_vars["first_client_name"] = name
    if xhttp:
        extra_vars["xhttp_enabled"] = "true"

    err_console.print()
    info(f"Configuring server at {resolved.ip}...")  # type: ignore[attr-defined]
    if domain:
        info(f"Domain: {domain}")
    if xhttp:
        info("XHTTP: enabled (enhanced stealth)")
    err_console.print()

    rc = run_playbook(
        "playbook.yml",
        ip=resolved.ip,  # type: ignore[attr-defined]
        creds_dir=resolved.creds_dir,  # type: ignore[attr-defined]
        extra_vars=extra_vars,
        local_mode=resolved.local_mode,  # type: ignore[attr-defined]
        user=resolved.user,  # type: ignore[attr-defined]
    )
    if rc != 0:
        fail(
            "Setup playbook failed",
            hint="Check server IP and SSH access. Run: meridian check " + resolved.ip,  # type: ignore[attr-defined]
            hint_type="system",
        )


def _print_success(resolved: object, name: str, domain: str) -> None:
    """Print success output after deployment."""
    client_label = name or "default"
    creds_dir = resolved.creds_dir  # type: ignore[attr-defined]
    html_files = list(creds_dir.glob(f"*-{client_label}-connection-info.html"))
    txt_files = list(creds_dir.glob("*-connection-info.txt"))

    err_console.print("\n  [ok][bold]Done![/bold][/ok]\n")
    err_console.print("  [bold]Next steps:[/bold]\n")

    if html_files:
        err_console.print("  [ok]1.[/ok] Send this file to whoever needs access:")
        err_console.print(f"     [bold]{html_files[0]}[/bold]")
        err_console.print("     [dim](They open it, scan the QR code, and connect)[/dim]\n")

    if txt_files:
        err_console.print("  [ok]2.[/ok] View connection details:")
        err_console.print(f"     [info]cat {txt_files[0]}[/info]\n")

    err_console.print("  [ok]3.[/ok] Test that the proxy works:")
    server_ip = resolved.ip  # type: ignore[attr-defined]
    err_console.print(f"     [info]meridian ping {server_ip}[/info]")
    ping_url = f"https://meridian.msu.rocks/ping?ip={server_ip}"
    if domain:
        ping_url += f"&domain={domain}"
    err_console.print(f"     [dim]Or from browser: {ping_url}[/dim]\n")

    err_console.print("  [ok]4.[/ok] Share access with friends:")
    err_console.print("     [info]meridian client add alice[/info]")
    err_console.print("     [info]meridian client list[/info]\n")

    err_console.print()
    line()
    err_console.print("\n  [dim]Feedback & issues: https://github.com/uburuntu/meridian/issues[/dim]\n")


def _detect_public_ip() -> str:
    """Detect the machine's public IPv4 address."""
    for url in ("https://ifconfig.me", "https://api.ipify.org"):
        try:
            result = subprocess.run(
                ["curl", "-4", "-s", "--max-time", "3", url],
                capture_output=True,
                text=True,
                timeout=5,
                stdin=subprocess.DEVNULL,
            )
            ip = result.stdout.strip()
            if is_ipv4(ip):
                return ip
        except (subprocess.TimeoutExpired, FileNotFoundError):
            continue
    return ""
