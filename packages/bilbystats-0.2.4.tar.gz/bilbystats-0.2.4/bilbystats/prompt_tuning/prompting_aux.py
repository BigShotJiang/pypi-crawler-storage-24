#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Aug 12 23:07:36 2025

@author: samd
"""

def labels2output(labels):
    setoflabels = ''
    for i in range(len(labels)):
        setoflabels += ',' + str(labels[i])
        
    setoflabels = setoflabels[1:]
    
    out = '''
Expected output format:
{
  "label": "<one of: '''
    out += setoflabels
    out += '''>"
}

- Output ONLY the JSON object, nothing else
- Do NOT use markdown code blocks or backticks
- Start your response directly with the opening brace {'''
                                                       
    return out  

def cat2output(cats: list[str], descriptions: list[str], 
               addjsoninstructions: bool = False, addchecks: bool = False) -> str:
    """
    Generate a JSON-like output string mapping categories to descriptions.

    This function creates a string formatted as a JSON object, where each 
    category from `cats` is mapped to its corresponding description from 
    `descriptions`. Optional flags allow adding instructions for JSON formatting 
    or surrounding each description with angle brackets for validation checks.

    ---------------------------------------------------------------------------
    ARGUMENTS:
    cats : list of str
        List of category names to be used as JSON keys.
    descriptions : list of str
        List of descriptions corresponding to each category.
    addjsoninstructions : bool, optional (default=False)
        If True, prepend JSON formatting instructions to the output and 
        append rules about JSON-only responses.
    addchecks : bool, optional (default=False)
        If True, wrap each description in angle brackets ("<description>").
    
    ---------------------------------------------------------------------------
    OUTPUT:
    out : str
        A formatted string representation of the categories-to-descriptions 
        mapping, optionally including JSON instructions and checks.
    ---------------------------------------------------------------------------
    AUTHORS: Samuel Davenport
    ---------------------------------------------------------------------------
    """
    if addjsoninstructions:
        out = 'Expected output format:\n'
    else:
        out = ''
        
    if addchecks:
        check1 = '<'
        check2 = '>'
    else:
        check1 = ''
        check2 = ''
        
    out += '''{
'''
    for i in range(len(cats)):
        out += ' "' + str(cats[i]) + '": ' + '"' + check1 + str(descriptions[i]) + check2 + '"'
        if i < (len(cats)-1):
            out += ',\n'
        else:
            out += '\n'
    
    out += '}'
    
    if addjsoninstructions:
        out = out + '''

- Output ONLY the JSON object, nothing else
- Do NOT use markdown code blocks or backticks
- Start your response directly with the opening brace {'''
                                                       
    return out  
                      
def combine_messages(user_messages, chat_messages, user_prefix = '', chat_prefix = '', user_suffix = '', chat_suffix = ''):
    """
    Interleave two lists of messages: first a user message, then a chat message, and so on.
    Stops when the shorter list ends.

    Args:
        user_msgs (list): List of user messages (strings or dicts).
        chat_msgs (list): List of chat messages (strings or dicts).

    Returns:
        list: Interleaved list of messages.
    """
    interleaved = []
    for u, c in zip(user_messages, chat_messages):
        interleaved.append({"role": "user","content": user_prefix + str(u) + user_suffix})
        interleaved.append({"role": "assistant","content": chat_prefix + str(c) + chat_suffix})
    return interleaved  

def multiple_cats(cats: list[str], list_of_descriptions: list[list[str]]) -> list[str]:
    """
    Generate multiple JSON-like output strings for different sets of descriptions.

    This function takes a list of category names and a list of multiple description 
    lists. It generates a formatted JSON-like string for each set of descriptions 
    using the same set of category keys.

    ---------------------------------------------------------------------------
    ARGUMENTS:
    cats : list of str
        List of category names to be used as JSON keys.
    list_of_descriptions : list of list of str
        A list where each element is a list of descriptions corresponding 
        to the categories in `cats`.
    
    ---------------------------------------------------------------------------
    OUTPUT:
    list_of_cats : list of str
        A list of formatted JSON-like strings, each representing a mapping 
        from `cats` to one set of descriptions.
    ---------------------------------------------------------------------------
    AUTHORS: Samuel Davenport
    ---------------------------------------------------------------------------
    """
    list_of_cats = []
    for i in range(len(list_of_descriptions)):
        new_cat = cat2output(cats, list_of_descriptions[i])
        list_of_cats.append(new_cat)
        
    return list_of_cats
    