#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Sep 15 10:40:37 2025

@author: samd
"""

import requests
import json
import bilbystats as bs


api_key = bs.read_api_key('openrouter')

response = requests.get(
  url="https://openrouter.ai/api/v1/key",
  headers={
    "Authorization": "Bearer " +api_key
  }
)

print(json.dumps(response.json(), indent=2))

# %%
import requests
import json

def extract_model_info(model):
    """Extract relevant cost and model information"""
    return {
        'name': model.get('id', 'N/A'),
        'prompt_cost': model.get('pricing', {}).get('prompt', 'N/A'),
        'completion_cost': model.get('pricing', {}).get('completion', 'N/A'),
        'context_length': model.get('context_length', 'N/A'),
        'description': model.get('description', 'N/A')
    }

def display_costs(costs_data, limit=10):
    """Display costs in a formatted way"""
    if isinstance(costs_data, dict) and 'name' in costs_data:
        # Single model
        print(f"\n--- {costs_data['name']} ---")
        print(f"Prompt cost: ${costs_data['prompt_cost']} per token")
        print(f"Completion cost: ${costs_data['completion_cost']} per token")
        print(f"Context length: {costs_data['context_length']}")
        print(f"Description: {costs_data['description']}")
    else:
        # Multiple models
        print(f"\n--- OpenRouter Model Costs (showing first {limit}) ---")
        for i, (model_id, info) in enumerate(costs_data.items()):
            if i >= limit:
                break
            print(f"\n{i+1}. {info['name']}")
            print(f"   Prompt: ${info['prompt_cost']} | Completion: ${info['completion_cost']}")
            print(f"   Context: {info['context_length']}")

# Example usage
if __name__ == "__main__":
    # Get costs for a specific model
    costs = or_costs("meta-llama/llama-3.1-8b-instruct")
    display_costs(costs)
