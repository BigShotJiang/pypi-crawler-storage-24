import pandas as pd
from typing import List

def read_parquet(file_paths: List[str]) -> pd.DataFrame:
    """
    Reads a list of parquet files, concatenates them,
    and resets the index.
    """
    if not file_paths:
        raise ValueError("The file_paths list is empty.")

    dfs = [pd.read_parquet(path) for path in file_paths]
    combined_df = pd.concat(dfs)
    
    # Explicit index reset
    combined_df = combined_df.reset_index(drop=True)
    
    return combined_df