#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Nov 17 15:06:19 2025

@author: samd
"""

"""Diff generation and change detection."""

import difflib
import bilbystats as bs

def compute_diff(
    old_text: str,
    new_text: str,
    old_label: str = "Previous",
    new_label: str = "Current",
) -> str:
    """
    Generate a unified diff between two text versions.

    Args:
        old_text: Previous version of the text
        new_text: Current version of the text
        old_label: Label for the old version
        new_label: Label for the new version

    Returns:
        Unified diff as a string (Unix diff format)
    """
    # Split texts into lines for comparison
    #old_lines = bs.get_sentences_orig(old_text, minlen=1, language='English', preserve_spaces=True)
    #new_lines = bs.get_sentences_orig(new_text, minlen=1, language='English', preserve_spaces=True)
    old_lines = old_text.splitlines(keepends=True)
    new_lines = new_text.splitlines(keepends=True)
    
    # Generate unified diff
    diff = difflib.unified_diff(old_lines, new_lines, fromfile=old_label, tofile=new_label, lineterm="")

    return "".join(diff)

