def show_html(html_string, width=800, height=600, title="HTML Preview"):
    import tempfile
    import webbrowser
    """
    Display HTML content in a popup window.
    
    Args:
        html_string (str): The HTML content to display
        width (int): Window width in pixels (default: 800)
        height (int): Window height in pixels (default: 600)
        title (str): Window title (default: "HTML Preview")
    """
    # Create a temporary HTML file
    with tempfile.NamedTemporaryFile(mode='w', suffix='.html', delete=False) as f:
        f.write(html_string)
        temp_file = f.name
    
    # Open in default browser (simple approach)
    webbrowser.open('file://' + temp_file)
    
    # Optional: Clean up the temp file after a delay
    # (You might want to handle this differently in production)