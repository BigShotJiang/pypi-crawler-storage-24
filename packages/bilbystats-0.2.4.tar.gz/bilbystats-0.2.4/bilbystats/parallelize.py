#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Nov 18 14:47:50 2025

@author: samd
"""
import bilbystats as bs
from joblib import Parallel, delayed
from tqdm import tqdm


def parallelize_dep(funinput, fun, njobs = -1):
    def process_article(i, input4fun):
        out = fun(input4fun)
        return out

    parallel_output = Parallel(n_jobs=njobs)(
        delayed(process_article)(i, funinput[i]) 
        for i in tqdm(range(len(funinput)), leave=False)
        )
    
    return parallel_output

def parallelize_dep2(funinput, fun, njobs=-1):
    items = list(range(len(funinput)))  # Materialize the range
    
    results = Parallel(n_jobs=njobs)(
        delayed(fun)(funinput[i]) 
        for i in tqdm(items, desc="Processing")
    )
    return results

def parallelize(funinput, fun, njobs=-1):
    with tqdm(total=len(funinput), desc="Processing") as pbar:
        results = []
        for result in Parallel(n_jobs=njobs, return_as='generator')(
            delayed(fun)(funinput[i]) for i in range(len(funinput))
        ):
            results.append(result)
            pbar.update(1)
    return results