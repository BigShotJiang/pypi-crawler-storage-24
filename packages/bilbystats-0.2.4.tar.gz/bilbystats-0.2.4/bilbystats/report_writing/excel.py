import pandas as pd
from openpyxl.styles import Font

def write2excel(df, saveloc, bold_columns = []):
    """
    Write a DataFrame to Excel with specified columns in bold.
    
    Parameters:
    -----------
    df : pandas.DataFrame
        The dataframe to write to Excel
    bold_columns : list
        List of column names to make bold
    save_location : str
        File path where the Excel file should be saved
    """
    with pd.ExcelWriter(saveloc, engine='openpyxl') as writer:
        df.to_excel(writer, index=False, sheet_name='Sheet1')
        
        workbook = writer.book
        worksheet = writer.sheets['Sheet1']
        
        bold_font = Font(bold=True)
        
        # Get column indices for bold columns
        bold_indices = [df.columns.get_loc(col) for col in bold_columns if col in df.columns]
        
        # Apply bold to specified columns
        for row in worksheet.iter_rows(min_row=1, max_row=len(df)+1):
            for idx in bold_indices:
                row[idx].font = bold_font


