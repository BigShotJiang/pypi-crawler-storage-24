def important_articles_doc(df, col2print, addons, save_path, importance=None, importance_filter='importance', title=None):
    """
    Create a Word document containing important articles, or append to an existing document.
    
    Parameters:
    -----------
    df : pandas.DataFrame
        DataFrame containing articles with 'importance' column and columns specified in col2print
    col2print : list
        List of column names to print. First column is treated as bold title,
        second as the main body text, rest are treated as labeled fields.
    addons : dict
        Dictionary mapping column names to their labels (e.g., {'newspaper': 'Source', 'id': 'Link'})
    save_path : str
        Full path where the document should be saved. If file exists, content is appended.
    importance : int
        Importance level to filter by
    importance_filter : str
        Column name to use for filtering by importance
    title : str, optional
        Title to add at the beginning of the new content (default: None)
    
    Returns:
    --------
    None
    """
    from docx import Document
    from docx.shared import Pt
    import os
    
    # Load existing document or create new one
    if os.path.exists(save_path):
        doc = Document(save_path)
    else:
        doc = Document()
    
    if importance is None:
        important_articles = df
    else:
        important_articles = df[df[importance_filter] == importance]
    
    # Add title if provided
    if title is not None:
        title_para = doc.add_paragraph()
        title_run = title_para.add_run(title)
        title_run.bold = True
        title_run.font.size = Pt(16)
        title_para.paragraph_format.space_after = Pt(12)
    
    for idx, row in important_articles.iterrows():
        for i, col in enumerate(col2print):
            para = doc.add_paragraph()
            
            if i == 0:
                # First column: bold title
                run = para.add_run(str(row[col]))
                run.bold = True
                
            elif col in addons:
                # Columns with labels
                label_run = para.add_run(f"{addons[col]}: ")
                label_run.bold = True
                para.add_run(str(row[col]))
                
            else:
                # Plain text (e.g., summary)
                para.add_run(str(row[col]))
            
            # Set spacing: larger space after last item, none after others
            if i == len(col2print) - 1:
                para.paragraph_format.space_after = Pt(18)
            else:
                para.paragraph_format.space_after = Pt(0)
    
    doc.save(save_path)