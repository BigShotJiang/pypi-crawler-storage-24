#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Sep 22 11:19:03 2025

@author: samd
"""

import re

def classify_plc(title: str) -> int:
    """
    Classify the stage of a document title based on regex indicators.
    
    Returns:
        3, 4, 5, 6, or 0 (for 'other')
    """
    # Stage 3 (Formulation)
    if re.search(r'草案|征求意见|讨论稿|征求.*意见|意见征求|公开征求', title):
        return 3

    # Stage 4 (Resolving Fragmentation)
    if re.search(r'联合|共同|协调|统筹|会议纪要|纪要|多部门', title):
        return 4

    # Stage 5 (Response & Action)
    if re.search(r'报告|请示|批复|实施方案|工作方案|贯彻落实|执行情况|进展情况', title):
        return 5

    # Stage 6 (Enforcement)
    if re.search(r'决议|决定|命令|公报|公告|条例|办法|规定|通报|现予公布|自.*起施行', title):
        return 6

    # Stage 2 (Initiation)
    if re.search(r'重要讲话|工作部署|专项行动|重点工作|优先事项', title):
        return 2  # I kept 2 here even though your text said return 0 for other.

    # Other
    return 0
