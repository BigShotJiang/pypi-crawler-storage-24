import math
import numpy as np


def nan2zeros(values: list | np.ndarray) -> list | np.ndarray:
    """
    Convert NaN values in a list or numpy array to zeros.

    This function replaces any NaN (Not a Number) values with zero. For numpy
    arrays, it uses np.nan_to_num. For lists, it iterates and replaces NaNs.

    ---------------------------------------------------------------------------
    ARGUMENTS:
    values : list | np.ndarray
        A list or numpy array where NaN entries should be converted to zeros.

    ---------------------------------------------------------------------------
    OUTPUT:
    result : list | np.ndarray
        A new list or array with NaN values replaced by zeros. Returns the
        same type as the input.
    ---------------------------------------------------------------------------
    AUTHORS: Samuel Davenport
    ---------------------------------------------------------------------------
    """
    if isinstance(values, np.ndarray):
        return np.nan_to_num(values, nan=0.0, posinf=np.inf, neginf=-np.inf)

    result = []
    for val in values:
        try:
            if math.isnan(val):
                result.append(0)
            else:
                result.append(val)
        except (TypeError, ValueError):
            # Not a numeric type, keep original value
            result.append(val)
    return result
