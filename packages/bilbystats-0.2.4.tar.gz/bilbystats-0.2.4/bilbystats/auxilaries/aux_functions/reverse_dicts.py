

def reverse_dicts(dict_list):
    """
    Reverse each dictionary in a list of dictionaries.
    Groups keys by their values when duplicates exist.

    Args:
        dict_list (list[dict]): A list of dictionaries to reverse.

    Returns:
        list[dict]: A list of reversed dictionaries.
    """
    reversed_list = []
    
    for d in dict_list:
        reversed_dict = {}
        for key, value in d.items():
            reversed_dict.setdefault(value, []).append(key)
        reversed_list.append(reversed_dict)
    
    return reversed_list