def list2str(list2convert):
    out = [str(elem) for elem in list2convert]
    return out