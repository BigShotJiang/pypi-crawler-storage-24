import math


def find_nans(values: list) -> list:
    """
    Find the indices of NaN values in a list.

    This function iterates through a list and returns the indices of all
    elements that are NaN (Not a Number).

    ---------------------------------------------------------------------------
    ARGUMENTS:
    values : list
        A list of values to search for NaN entries.

    ---------------------------------------------------------------------------
    OUTPUT:
    nan_indices : list
        A list of integer indices where NaN values occur in the input list.
    ---------------------------------------------------------------------------
    AUTHORS: Samuel Davenport
    ---------------------------------------------------------------------------
    """
    nan_indices = []
    for i, val in enumerate(values):
        try:
            if math.isnan(val):
                nan_indices.append(i)
        except (TypeError, ValueError):
            # Not a numeric type, skip
            pass
    return nan_indices
