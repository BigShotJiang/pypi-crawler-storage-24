

def modul(iterand, niterand=100):
    """
    Print the value of `iterand` if it is divisible by `niterand`.

    This function checks whether `iterand` is evenly divisible by `niterand`.
    If the condition is met, it prints the value of `iterand`.

    ---------------------------------------------------------------------------
    ARGUMENTS:
    iterand : int
        The number to be tested for divisibility.
    niterand : int, optional (default=100)
        The number to divide by.

    ---------------------------------------------------------------------------
    OUTPUT:
    None

    ---------------------------------------------------------------------------
    AUTHORS: Samuel Davenport
    ---------------------------------------------------------------------------
    """
    if iterand % niterand == 0:
        print(iterand)