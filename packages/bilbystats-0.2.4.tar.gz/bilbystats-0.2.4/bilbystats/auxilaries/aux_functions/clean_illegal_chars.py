import re

def clean_illegal_chars(x):
    illegal_chars = re.compile(r'[\x00-\x08\x0B\x0C\x0E-\x1F]')
    if isinstance(x, str):
        return illegal_chars.sub("", x)
    return x