import numpy as np


def choose_random_indices(n1, n2, n3, index1, index2, index3):
    """
    Randomly select indices from three separate index arrays.

    This function samples a specified number of unique indices from three given 
    index arrays without replacement. The selected indices from each array are 
    then concatenated into a single combined array.

    ---------------------------------------------------------------------------
    ARGUMENTS:
    n1 : int
        Number of indices to select from `index1`.
    n2 : int
        Number of indices to select from `index2`.
    n3 : int
        Number of indices to select from `index3`.
    index1 : array-like, shape (n_samples1,)
        Array of indices to sample from for the first selection.
    index2 : array-like, shape (n_samples2,)
        Array of indices to sample from for the second selection.
    index3 : array-like, shape (n_samples3,)
        Array of indices to sample from for the third selection.

    ---------------------------------------------------------------------------
    OUTPUT:
    combined_indices : ndarray, shape (n1 + n2 + n3,)
        Concatenated array of all selected indices from the three input arrays.
    random_indices1 : ndarray, shape (n1,)
        Randomly selected indices from `index1`.
    random_indices2 : ndarray, shape (n2,)
        Randomly selected indices from `index2`.
    random_indices3 : ndarray, shape (n3,)
        Randomly selected indices from `index3`.
    ---------------------------------------------------------------------------
    AUTHORS: Samuel Davenport
    ---------------------------------------------------------------------------
    """
    random_indices1 = np.random.choice(index1, size=n1, replace=False)
    random_indices2 = np.random.choice(index2, size=n2, replace=False)
    random_indices3 = np.random.choice(index3, size=n3, replace=False)
    combined_indices = np.concatenate(
        [random_indices1, random_indices2, random_indices3])
    # np.random.shuffle(combined_indices)
    return combined_indices, random_indices1, random_indices2, random_indices3