import numpy as np


def eval_list(list2eval):
    out = []
    fail_indices = []
    for i in range(len(list2eval)):
        try:
            attempt = eval(list2eval[i])
            fail_indices.append(0)
        except: 
            attempt = {}
            fail_indices.append(1)
        
        out.append(attempt)
        
    fail_indices = np.array(fail_indices)
    return out, fail_indices