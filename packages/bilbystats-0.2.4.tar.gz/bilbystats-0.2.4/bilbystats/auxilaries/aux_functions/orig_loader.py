import numpy as np
import sys


def orig_loader(I, totalI):
    """
    Display a progress bar in the console.

    This function updates a text-based progress bar in the console based on the 
    current progress `I` out of the total iterations `totalI`. It overwrites the 
    same line to give a real-time progress update.

    ---------------------------------------------------------------------------
    ARGUMENTS:
    I : int
        The current iteration or progress count.
    totalI : int
        The total number of iterations or steps to complete.

    ---------------------------------------------------------------------------
    OUTPUT:
    None
        This function only updates the console output and does not return any value.
    ---------------------------------------------------------------------------
    AUTHORS: Samuel Davenport
    ---------------------------------------------------------------------------
    """
    progress = 100*I/totalI
    sys.stdout.write('\r')
    sys.stdout.write("[%-20s] %d%%" %
                     ('='*int(np.floor(progress/5)), progress))
    sys.stdout.flush()