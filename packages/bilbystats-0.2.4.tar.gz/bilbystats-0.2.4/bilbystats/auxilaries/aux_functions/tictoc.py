import time

# Global variable to store the start time
_start_time = None

def tic():
    """Start timer"""
    global _start_time
    _start_time = time.time()

def toc(do_print = True):
    global _start_time
    """Print and return elapsed time since last tic()"""
    if _start_time is None:
        print("tic() has not been called yet.")
        return None
    elapsed_time = time.time() - _start_time
    if do_print:
        print(f"Elapsed time: {elapsed_time:.6f} seconds")
    return elapsed_time