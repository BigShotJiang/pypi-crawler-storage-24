import tkinter as tk
from tkinter import ttk
import tempfile
import webbrowser
import os

def testfn1(html_string, width=800, height=600, title="HTML Preview"):
    """
    Display HTML content in a popup window.
    
    Args:
        html_string (str): The HTML content to display
        width (int): Window width in pixels (default: 800)
        height (int): Window height in pixels (default: 600)
        title (str): Window title (default: "HTML Preview")
    """
    # Create a temporary HTML file
    with tempfile.NamedTemporaryFile(mode='w', suffix='.html', delete=False) as f:
        f.write(html_string)
        temp_file = f.name
    
    # Open in default browser (simple approach)
    webbrowser.open('file://' + temp_file)
    
    # Optional: Clean up the temp file after a delay
    # (You might want to handle this differently in production)
    
def testfn2(model):
    """Extract relevant cost and model information"""
    return {
        'name': model.get('id', 'N/A'),
        'prompt_cost': model.get('pricing', {}).get('prompt', 'N/A'),
        'completion_cost': model.get('pricing', {}).get('completion', 'N/A'),
        'context_length': model.get('context_length', 'N/A'),
        'description': model.get('description', 'N/A')
    }
