# CAIRO SDK — Output-Logic pillar (output validation, guardrails, EU AI Act 2026, ISO A.8.5)
from cairo_sdk.output_logic.validator import (  # noqa: F401
    TRANSPARENCY_BANNER_HIGH_RISK,
    is_high_risk_interaction,
    append_transparency_banner_if_high_risk,
)
from cairo_sdk.output_logic.compliance import (  # noqa: F401
    CompliancePassport,
    ForensicChecksum,
    ControlRecord,
    EuAiActRecord,
    build_compliance_passport,
    generate_forensic_checksum,
    ISO_TAG,
    DOCUMENT_TYPE,
    SCHEMA_VERSION,
)
