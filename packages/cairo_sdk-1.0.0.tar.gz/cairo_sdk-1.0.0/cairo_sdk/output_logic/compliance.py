"""
Pillar 5 — Output-Logic: Compliance Passport Engine.

Implements ISO 42001 A.8.5 (Documented Information / Evidence of Controls Applied)
for every AI interaction processed by the CAIRO Armor middleware.

Responsibilities
────────────────
1. ForensicChecksum — deterministic SHA-256 over (request_id, compliance_tags, timestamp_utc).
   Provides a tamper-evident fingerprint for each interaction.  The preimage is
   included in the passport so any auditor can independently verify the digest.

2. CompliancePassport — structured JSON document that lists every NIST AI RMF and
   ISO 42001 control applied during the interaction.  This is the machine-readable
   basis for the CAIRO Shield Forensic Integrity Document (FID).

3. build_compliance_passport() — factory that accepts runtime data (request_id,
   risk tier, pillar results, EU AI Act label status) and returns a fully-populated
   CompliancePassport ready for export as JSON.

ISO 42001 A.8.5 mapping: "The organisation shall create and update documented
information as evidence of conformity with requirements."  Each passport is that
documented evidence for one AI invocation.

CAIRO Protocol Technical Architecture v1.0.
"""

from __future__ import annotations

import datetime
import hashlib
import json
from typing import Any

from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# ISO tag
# ---------------------------------------------------------------------------

ISO_TAG: str = "ISO 42001 A.8.5"
DOCUMENT_TYPE: str = "CAIRO_Compliance_Passport"
SCHEMA_VERSION: str = "1.0"


# ---------------------------------------------------------------------------
# Default control registry — every NIST/ISO/EU/CAIRO control wired into armor
# ---------------------------------------------------------------------------

DEFAULT_APPLIED_CONTROLS: list[dict[str, str]] = [
    {
        "control_id": "NIST_AI_RMF_GOVERN_1.2",
        "framework": "NIST_AI_RMF",
        "function": "GOVERN",
        "description": "Pillar 1 — Containment: prompt injection / system override blocking",
    },
    {
        "control_id": "NIST_AI_RMF_MAP_1.1",
        "framework": "NIST_AI_RMF",
        "function": "MAP",
        "description": "Pillar 1 — Containment: request scope / size / action boundary checks",
    },
    {
        "control_id": "NIST_AI_RMF_MEASURE_2.1",
        "framework": "NIST_AI_RMF",
        "function": "MEASURE",
        "description": "Pillar 3 — Interception: Golden Path drift detection and corrective constraints",
    },
    {
        "control_id": "ISO_42001_A.8.2",
        "framework": "ISO_42001",
        "function": "GOVERN",
        "description": "Pillar 2 — Attestation: tenant identity and user-role validation",
    },
    {
        "control_id": "ISO_42001_A.8.4",
        "framework": "ISO_42001",
        "function": "RESPOND",
        "description": "Pillar 4 — Resilience: PII scrubbing and ISO incident communication",
    },
    {
        "control_id": "ISO_42001_A.8.5",
        "framework": "ISO_42001",
        "function": "GOVERN",
        "description": "Pillar 5 — Output-Logic: documented evidence of controls applied (this passport)",
    },
    {
        "control_id": "ISO_42001_A.9.4",
        "framework": "ISO_42001",
        "function": "MAP",
        "description": "Pillar 2 — Attestation: purpose_declaration validation (Intended Use)",
    },
    {
        "control_id": "EU_AI_Act_Article_50",
        "framework": "EU_AI_Act_2026",
        "function": "TRANSPARENCY",
        "description": "Pillar 5 — Output-Logic: perceptible AI-generated label for high-risk and limited-risk interactions",
    },
    {
        "control_id": "CAIRO_Pillar_1_Containment",
        "framework": "CAIRO",
        "function": "ENFORCE",
        "description": "Scope / size / keyword / injection enforcement before agent invocation",
    },
    {
        "control_id": "CAIRO_Pillar_2_Attestation",
        "framework": "CAIRO",
        "function": "ENFORCE",
        "description": "Identity, role, and purpose binding with unique attestation_id",
    },
    {
        "control_id": "CAIRO_Pillar_3_Interception",
        "framework": "CAIRO",
        "function": "ENFORCE",
        "description": "LangGraph node transition monitoring and corrective constraint injection",
    },
    {
        "control_id": "CAIRO_Pillar_4_Resilience",
        "framework": "CAIRO",
        "function": "ENFORCE",
        "description": "Schema validation, retry / fallback, and PII scrubbing on final output",
    },
    {
        "control_id": "CAIRO_Pillar_5_OutputLogic",
        "framework": "CAIRO",
        "function": "ENFORCE",
        "description": "Output guardrails, EU AI Act label injection, and compliance passport generation",
    },
]


# ---------------------------------------------------------------------------
# Pydantic models
# ---------------------------------------------------------------------------

class ControlRecord(BaseModel):
    """A single applied control recorded in the passport."""
    control_id: str = Field(description="Unique control identifier (e.g. NIST_AI_RMF_GOVERN_1.2)")
    framework: str = Field(description="Governing framework: NIST_AI_RMF | ISO_42001 | EU_AI_Act_2026 | CAIRO")
    function: str = Field(description="RMF function or category: GOVERN | MAP | MEASURE | MANAGE | RESPOND | ENFORCE | TRANSPARENCY")
    description: str = Field(description="Human-readable description of what was enforced")

    model_config = {"extra": "forbid"}


class ForensicChecksum(BaseModel):
    """
    Tamper-evident SHA-256 fingerprint for a single AI interaction.
    The preimage_json field contains the exact UTF-8 string that was hashed,
    allowing any auditor to independently verify the digest.
    """
    algorithm: str = Field(default="SHA-256")
    digest: str = Field(description="Lowercase hex SHA-256 digest")
    input_fields: list[str] = Field(
        default_factory=lambda: ["request_id", "compliance_tags", "timestamp_utc"],
        description="Fields from the passport that were hashed",
    )
    preimage_json: str = Field(
        description="Exact JSON string fed to SHA-256 (UTF-8 encoded) — for independent verification"
    )

    model_config = {"extra": "forbid"}


class EuAiActRecord(BaseModel):
    """EU AI Act Article 50 enforcement record."""
    article: str = Field(default="50")
    regulation: str = Field(default="EU AI Act 2026")
    risk_tier: str | None = Field(description="high-risk | limited | minimal | None (not applicable)")
    label_applied: bool = Field(description="True iff the Article 50 label was injected into the output")
    label_text: str | None = Field(default=None, description="Exact label text injected, if any")

    model_config = {"extra": "forbid"}


class CompliancePassport(BaseModel):
    """
    ISO 42001 A.8.5 — Forensic Integrity Document.

    Machine-readable summary of every NIST AI RMF and ISO 42001 control that was
    applied during a single AI interaction.  Signed with a SHA-256 forensic
    checksum for tamper evidence.

    This document is the basis for the CAIRO Shield Forensic Integrity Document (FID)
    and can be exported directly to JSON for audit, regulatory submission, or
    enterprise dashboard ingestion.
    """
    document_type: str = Field(default=DOCUMENT_TYPE)
    schema_version: str = Field(default=SCHEMA_VERSION)
    iso_control: str = Field(default=ISO_TAG)

    request_id: str = Field(description="correlation_id from the AgentRequest")
    timestamp_utc: str = Field(description="ISO-8601 UTC timestamp of passport generation")

    applied_controls: list[ControlRecord] = Field(
        description="Every NIST/ISO/EU/CAIRO control applied during this interaction",
    )
    compliance_tags: list[str] = Field(
        description="Flat list of control_ids for fast lookup and checksum input",
    )

    eu_ai_act: EuAiActRecord = Field(description="EU AI Act Article 50 enforcement record")

    pillar_summary: dict[str, Any] = Field(
        default_factory=dict,
        description="Runtime results per pillar (from PillarContext.pillar_results)",
    )

    forensic_checksum: ForensicChecksum = Field(
        description="SHA-256 fingerprint over request_id + compliance_tags + timestamp_utc",
    )

    model_config = {"extra": "forbid"}

    def to_json(self, indent: int = 2) -> str:
        """Serialize to a pretty-printed JSON string for export / filing."""
        return self.model_dump_json(indent=indent)

    def to_dict(self) -> dict[str, Any]:
        """Return as a plain dict for embedding in response metadata."""
        return self.model_dump()


# ---------------------------------------------------------------------------
# Checksum computation
# ---------------------------------------------------------------------------

def generate_forensic_checksum(
    request_id: str,
    compliance_tags: list[str],
    timestamp_utc: str,
) -> ForensicChecksum:
    """
    Compute a deterministic SHA-256 over (request_id, sorted compliance_tags, timestamp_utc).

    Tags are sorted before hashing to ensure the digest is independent of insertion order.
    The preimage_json is included in the result for independent verification.
    """
    payload = {
        "request_id": request_id,
        "compliance_tags": sorted(compliance_tags),
        "timestamp_utc": timestamp_utc,
    }
    preimage = json.dumps(payload, separators=(",", ":"), sort_keys=True, ensure_ascii=True)
    digest = hashlib.sha256(preimage.encode("utf-8")).hexdigest()
    return ForensicChecksum(
        digest=digest,
        preimage_json=preimage,
    )


# ---------------------------------------------------------------------------
# Passport factory
# ---------------------------------------------------------------------------

def build_compliance_passport(
    request_id: str,
    eu_ai_act_risk_tier: str | None = None,
    eu_ai_act_label_applied: bool = False,
    eu_ai_act_label_text: str | None = None,
    pillar_summary: dict[str, Any] | None = None,
    extra_controls: list[dict[str, str]] | None = None,
    timestamp_utc: str | None = None,
) -> CompliancePassport:
    """
    Build a fully-populated CompliancePassport for one AI interaction.

    Parameters
    ----------
    request_id
        The correlation_id from the originating AgentRequest.
    eu_ai_act_risk_tier
        "high-risk" | "limited" | "minimal" | None.
    eu_ai_act_label_applied
        True iff the Article 50 label was injected into the final output.
    eu_ai_act_label_text
        The exact label string injected, if any.
    pillar_summary
        Dict from PillarContext.pillar_results (containment, attestation, …).
    extra_controls
        Additional ControlRecord dicts to append to the default registry.
    timestamp_utc
        ISO-8601 UTC string; defaults to `datetime.datetime.now(utc).isoformat()`.
    """
    if timestamp_utc is None:
        timestamp_utc = (
            datetime.datetime.now(datetime.timezone.utc)
            .isoformat(timespec="milliseconds")
        )

    raw_controls = list(DEFAULT_APPLIED_CONTROLS)
    if extra_controls:
        raw_controls.extend(extra_controls)

    controls = [ControlRecord(**c) for c in raw_controls]
    compliance_tags = [c.control_id for c in controls]

    checksum = generate_forensic_checksum(request_id, compliance_tags, timestamp_utc)

    eu_record = EuAiActRecord(
        risk_tier=eu_ai_act_risk_tier,
        label_applied=eu_ai_act_label_applied,
        label_text=eu_ai_act_label_text,
    )

    return CompliancePassport(
        request_id=request_id,
        timestamp_utc=timestamp_utc,
        applied_controls=controls,
        compliance_tags=compliance_tags,
        eu_ai_act=eu_record,
        pillar_summary=pillar_summary or {},
        forensic_checksum=checksum,
    )
