"""
Pillar 2 — Attestation Policy.
Validates request.metadata has a valid tenant_id, user_role, and purpose_declaration.
Includes IsoValidator (ISO 42001 A.9.4 Intended Use enforcement) and PolicyViolationError.
Failure → pre_check returns (False, reason) → SecurityViolationError + agent task cancel.
CAIRO Protocol Technical Architecture v1.0.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Allowed roles (override at runtime via AttestationPolicy)
# ---------------------------------------------------------------------------

DEFAULT_ALLOWED_ROLES: list[str] = [
    "admin",
    "operator",
    "analyst",
    "auditor",
    "service_account",
    "developer",
    "user",
]

# ---------------------------------------------------------------------------
# Default Intended Use declarations (ISO 42001 A.9.4)
# Override via IsoPolicy.intended_uses
# ---------------------------------------------------------------------------

DEFAULT_INTENDED_USES: list[str] = [
    "customer_support",
    "document_summarisation",
    "data_analysis",
    "code_review",
    "content_moderation",
    "compliance_audit",
    "internal_query",
    "research",
    "translation",
    "classification",
]


# ---------------------------------------------------------------------------
# PolicyViolationError — raised when purpose deviates from Intended Use
# ---------------------------------------------------------------------------

class PolicyViolationError(Exception):
    """
    Raised when request.metadata.purpose_declaration does not match any Intended Use
    defined under ISO 42001 A.9.4. Serialisable to JSON for audit trail.
    """

    def __init__(
        self,
        declared_purpose: str,
        intended_uses: list[str],
        iso_control: str = "ISO 42001 A.9.4",
        tenant_id: str | None = None,
        correlation_id: str | None = None,
    ) -> None:
        self.declared_purpose = declared_purpose
        self.intended_uses = intended_uses
        self.iso_control = iso_control
        self.tenant_id = tenant_id
        self.correlation_id = correlation_id
        super().__init__(
            f"[{iso_control}] purpose_declaration '{declared_purpose}' is not in Intended Use: {intended_uses}"
        )

    def to_dict(self) -> dict[str, Any]:
        """JSON-serialisable representation for audit metadata."""
        return {
            "error": "PolicyViolationError",
            "iso_control": self.iso_control,
            "declared_purpose": self.declared_purpose,
            "intended_uses": self.intended_uses,
            "tenant_id": self.tenant_id,
            "correlation_id": self.correlation_id,
        }


# ---------------------------------------------------------------------------
# Policy schemas
# ---------------------------------------------------------------------------

class AttestationPolicy(BaseModel):
    """Policy for Pillar 2 pre-flight check: tenant, role, and purpose requirements."""

    require_tenant_id: bool = Field(
        default=True,
        description="Fail if tenant_id is absent or empty in request.metadata",
    )
    require_user_role: bool = Field(
        default=True,
        description="Fail if user_role is absent in request.metadata",
    )
    allowed_roles: list[str] = Field(
        default_factory=lambda: list(DEFAULT_ALLOWED_ROLES),
        description="Role must be in this list when require_user_role=True and list is non-empty",
    )
    tenant_id_min_length: int = Field(
        default=3,
        ge=1,
        description="Minimum length for tenant_id string",
    )

    model_config = {"extra": "forbid"}


class IsoPolicy(BaseModel):
    """ISO 42001 A.9.4 Intended Use policy: governs purpose_declaration validation."""

    require_purpose_declaration: bool = Field(
        default=True,
        description="Fail if purpose_declaration is absent in request.metadata",
    )
    intended_uses: list[str] = Field(
        default_factory=lambda: list(DEFAULT_INTENDED_USES),
        description="Allowed purpose values under ISO 42001 A.9.4 Intended Use",
    )
    iso_control_reference: str = Field(
        default="ISO 42001 A.9.4",
        description="ISO control reference tag for audit trail",
    )

    model_config = {"extra": "forbid"}


class PolicyCheckResult(BaseModel):
    """Result of attestation policy check."""

    passed: bool
    reason: str | None = None
    violation: dict[str, Any] | None = Field(
        default=None,
        description="Serialised PolicyViolationError dict when a purpose violation occurs",
    )

    model_config = {"extra": "forbid"}


# ---------------------------------------------------------------------------
# AttestationPolicyValidator — tenant_id + user_role (unchanged)
# ---------------------------------------------------------------------------

class AttestationPolicyValidator:
    """
    Validates request.metadata contains a valid tenant_id and user_role.
    Used inside AttestationPillar.pre_check() to fail-fast before agent invocation.
    """

    def __init__(self, policy: AttestationPolicy | None = None) -> None:
        self.policy = policy or AttestationPolicy()

    def validate(self, metadata: Any) -> PolicyCheckResult:
        """Check metadata for tenant_id and user_role. Returns PolicyCheckResult on any failure."""
        if not isinstance(metadata, dict):
            return PolicyCheckResult(passed=False, reason="request.metadata must be a dict")

        if self.policy.require_tenant_id:
            tenant_id = metadata.get("tenant_id")
            if not tenant_id or not isinstance(tenant_id, str):
                return PolicyCheckResult(
                    passed=False,
                    reason="metadata.tenant_id is required and must be a non-empty string",
                )
            if len(tenant_id.strip()) < self.policy.tenant_id_min_length:
                return PolicyCheckResult(
                    passed=False,
                    reason=f"metadata.tenant_id must be at least {self.policy.tenant_id_min_length} characters",
                )

        if self.policy.require_user_role:
            user_role = metadata.get("user_role")
            if not user_role or not isinstance(user_role, str):
                return PolicyCheckResult(
                    passed=False,
                    reason="metadata.user_role is required and must be a non-empty string",
                )
            if self.policy.allowed_roles and user_role not in self.policy.allowed_roles:
                return PolicyCheckResult(
                    passed=False,
                    reason=f"metadata.user_role '{user_role}' is not in allowed_roles: {self.policy.allowed_roles}",
                )

        return PolicyCheckResult(passed=True)


# ---------------------------------------------------------------------------
# IsoValidator — ISO 42001 A.9.4 purpose_declaration enforcement
# ---------------------------------------------------------------------------

class IsoValidator:
    """
    ISO 42001 A.9.4 Intended Use validator.
    Checks request.metadata for:
      - tenant_id      (identity traceability)
      - user_role      (access control)
      - purpose_declaration (Intended Use under ISO 42001 A.9.4)

    If purpose_declaration does not match any Intended Use, raises PolicyViolationError.
    """

    def __init__(self, policy: IsoPolicy | None = None) -> None:
        self.policy = policy or IsoPolicy()

    def validate(
        self,
        metadata: Any,
        correlation_id: str | None = None,
    ) -> PolicyCheckResult:
        """
        Validate metadata.purpose_declaration against ISO 42001 A.9.4 Intended Use list.
        Raises PolicyViolationError if purpose deviates from intended use.
        Returns PolicyCheckResult for pre_check() integration.
        """
        if not isinstance(metadata, dict):
            return PolicyCheckResult(passed=False, reason="request.metadata must be a dict for ISO 42001 A.9.4 check")

        if self.policy.require_purpose_declaration:
            purpose = metadata.get("purpose_declaration")
            if not purpose or not isinstance(purpose, str) or not purpose.strip():
                return PolicyCheckResult(
                    passed=False,
                    reason=(
                        f"[{self.policy.iso_control_reference}] metadata.purpose_declaration is required "
                        "for Intended Use validation"
                    ),
                )

            if purpose.strip() not in self.policy.intended_uses:
                tenant_id = metadata.get("tenant_id")
                err = PolicyViolationError(
                    declared_purpose=purpose.strip(),
                    intended_uses=self.policy.intended_uses,
                    iso_control=self.policy.iso_control_reference,
                    tenant_id=tenant_id,
                    correlation_id=correlation_id,
                )
                raise err

        return PolicyCheckResult(passed=True)
