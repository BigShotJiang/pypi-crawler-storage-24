"""
Pillar 3 — Interception: LogicDriftDetector with Corrective Constraint Injection.

Tracks the AI agent's actual node traversal path, detects two classes of drift:
  LOOP      — a node is visited more than once (circular execution risk).
  DEVIATION — the transition does not match the pre-approved Golden Path.
  OVERSHOOT — the path is longer than the Golden Path.

On any drift, synthesises a 'Corrective Constraint' string that can be injected
into the agent's system prompt to steer it back to the approved path.

NIST AI RMF mapping: MEASURE 2.1 — Evaluating AI systems in context
  (identifies risks arising from the AI's actual deployment behaviour).

CAIRO Protocol Technical Architecture v1.0.
"""

from __future__ import annotations

import datetime
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field

# ---------------------------------------------------------------------------
# NIST tag
# ---------------------------------------------------------------------------

NIST_TAG: str = "NIST_MEASURE_2.1"


# ---------------------------------------------------------------------------
# Enumerations
# ---------------------------------------------------------------------------

class DriftType(str, Enum):
    """Categorises the reason for a detected drift event."""
    LOOP = "loop"             # node visited more than once
    DEVIATION = "deviation"   # node does not match golden path
    OVERSHOOT = "overshoot"   # path exceeds golden path length


# ---------------------------------------------------------------------------
# Pydantic result models
# ---------------------------------------------------------------------------

class CorrectiveConstraint(BaseModel):
    """
    A natural-language constraint to be injected into the agent's system prompt.
    Steering message surfaces the Golden Path violation and directs the agent back.
    """
    text: str = Field(description="System-prompt text to inject")
    drift_type: DriftType = Field(description="Class of drift that triggered this constraint")
    looped_node: str | None = Field(default=None, description="Node ID that looped (LOOP drift only)")
    expected_next: str | None = Field(default=None, description="Expected next node (DEVIATION / OVERSHOOT)")
    nist_tag: str = Field(default=NIST_TAG)

    model_config = {"extra": "forbid"}


class MonitorResult(BaseModel):
    """Full result from a single observe_transition() call."""
    drift_detected: bool = Field(description="True iff any drift class was found")
    drift_type: DriftType | None = Field(default=None)
    actual_path: list[str] = Field(default_factory=list)
    expected_next: str | None = Field(default=None)
    looped_node: str | None = Field(default=None)
    corrective_constraint: CorrectiveConstraint | None = Field(default=None)
    nist_tag: str = Field(default=NIST_TAG)
    reason: str | None = Field(default=None)

    model_config = {"extra": "forbid"}


# ---------------------------------------------------------------------------
# Detector
# ---------------------------------------------------------------------------

class LogicDriftDetector:
    """
    Stateful detector that tracks the actual sequence of LangGraph node transitions
    for a single agent run and compares each step against the pre-approved Golden Path.

    State is scoped per agent run — call `reset()` at the start of each new run.

    Corrective Constraints
    ~~~~~~~~~~~~~~~~~~~~~~
    When drift is detected, `observe_transition()` returns a `MonitorResult` with a
    `CorrectiveConstraint.text` suitable for prepending to the agent's system prompt:

      request.payload.setdefault("messages", []).insert(0, {
          "role": "system",
          "content": result.corrective_constraint.text,
      })

    The caller is responsible for deciding whether to inject synchronously (pre-hook)
    or hand the constraint back to the agent on its next invocation cycle.
    """

    def __init__(
        self,
        golden_path: list[str] | None = None,
        telemetry_stream: Any = None,
    ) -> None:
        self.golden_path: list[str] = list(golden_path or [])
        self.telemetry_stream = telemetry_stream
        self._actual_path: list[str] = []
        self._visited: dict[str, int] = {}   # node -> visit count

    # ------------------------------------------------------------------
    # State management
    # ------------------------------------------------------------------

    def set_golden_path(self, path: list[str]) -> None:
        self.golden_path = list(path)

    def reset(self) -> None:
        """Reset per-run state. Call before each new agent execution."""
        self._actual_path = []
        self._visited = {}

    @property
    def current_path(self) -> list[str]:
        return list(self._actual_path)

    # ------------------------------------------------------------------
    # Core detection
    # ------------------------------------------------------------------

    def observe_transition(
        self,
        from_node: str,
        to_node: str,
        correlation_id: str | None = None,
    ) -> MonitorResult:
        """
        Record a LangGraph edge (from_node -> to_node) and evaluate drift.

        Returns MonitorResult.  If drift_detected is True, the result includes
        a CorrectiveConstraint ready for system-prompt injection.
        """
        # Ensure from_node is in the path
        if not self._actual_path or self._actual_path[-1] != from_node:
            self._actual_path.append(from_node)
            self._visited[from_node] = self._visited.get(from_node, 0) + 1

        # Check LOOP before appending to_node
        if self._visited.get(to_node, 0) >= 1:
            self._actual_path.append(to_node)
            self._visited[to_node] = self._visited.get(to_node, 0) + 1
            constraint = self._build_constraint(DriftType.LOOP, looped_node=to_node)
            reason = f"node '{to_node}' has already been visited (loop detected)"
            self._emit(from_node, to_node, reason, correlation_id)
            return MonitorResult(
                drift_detected=True,
                drift_type=DriftType.LOOP,
                actual_path=list(self._actual_path),
                looped_node=to_node,
                corrective_constraint=constraint,
                reason=reason,
            )

        # Append to_node to actual path
        self._actual_path.append(to_node)
        self._visited[to_node] = self._visited.get(to_node, 0) + 1

        # If no golden path defined, no drift possible
        if not self.golden_path:
            return MonitorResult(
                drift_detected=False,
                actual_path=list(self._actual_path),
            )

        path_len = len(self._actual_path)
        golden_len = len(self.golden_path)

        # Check OVERSHOOT
        if path_len > golden_len:
            expected_next = None  # golden path already exhausted
            constraint = self._build_constraint(
                DriftType.OVERSHOOT, expected_next=expected_next
            )
            reason = (
                f"actual path length {path_len} exceeds golden path length {golden_len}"
            )
            self._emit(from_node, to_node, reason, correlation_id)
            return MonitorResult(
                drift_detected=True,
                drift_type=DriftType.OVERSHOOT,
                actual_path=list(self._actual_path),
                corrective_constraint=constraint,
                reason=reason,
            )

        # Check DEVIATION at the current index
        idx = path_len - 1  # index of to_node just appended
        if self._actual_path[idx] != self.golden_path[idx]:
            expected_next = self.golden_path[idx]
            constraint = self._build_constraint(
                DriftType.DEVIATION, expected_next=expected_next
            )
            reason = (
                f"deviation at index {idx}: expected '{self.golden_path[idx]}', "
                f"got '{self._actual_path[idx]}'"
            )
            self._emit(from_node, to_node, reason, correlation_id)
            return MonitorResult(
                drift_detected=True,
                drift_type=DriftType.DEVIATION,
                actual_path=list(self._actual_path),
                expected_next=expected_next,
                corrective_constraint=constraint,
                reason=reason,
            )

        # No drift
        expected_next = (
            self.golden_path[path_len] if path_len < golden_len else None
        )
        return MonitorResult(
            drift_detected=False,
            actual_path=list(self._actual_path),
            expected_next=expected_next,
        )

    # ------------------------------------------------------------------
    # Corrective constraint builder
    # ------------------------------------------------------------------

    def _build_constraint(
        self,
        drift_type: DriftType,
        looped_node: str | None = None,
        expected_next: str | None = None,
    ) -> CorrectiveConstraint:
        """Return a natural-language constraint for system-prompt injection."""
        if drift_type == DriftType.LOOP:
            text = (
                f"[CAIRO CORRECTIVE CONSTRAINT — {NIST_TAG}] "
                f"You have already visited node '{looped_node}'. "
                "Circular execution is not permitted on the approved Golden Path. "
                "Do not return to this node. Proceed only to the next authorised step."
            )
        elif drift_type == DriftType.DEVIATION:
            if expected_next:
                text = (
                    f"[CAIRO CORRECTIVE CONSTRAINT — {NIST_TAG}] "
                    f"Your current execution path deviates from the approved Golden Path. "
                    f"You must proceed to '{expected_next}' as the next authorised step. "
                    "Unauthorised node transitions are prohibited."
                )
            else:
                text = (
                    f"[CAIRO CORRECTIVE CONSTRAINT — {NIST_TAG}] "
                    "Your current execution path deviates from the approved Golden Path. "
                    "Return to the last approved node and follow the authorised sequence."
                )
        else:  # OVERSHOOT
            text = (
                f"[CAIRO CORRECTIVE CONSTRAINT — {NIST_TAG}] "
                "Your execution has exceeded the approved Golden Path length. "
                "Stop processing immediately. Return a final response without "
                "initiating any further node transitions."
            )
        return CorrectiveConstraint(
            text=text,
            drift_type=drift_type,
            looped_node=looped_node,
            expected_next=expected_next,
        )

    # ------------------------------------------------------------------
    # Telemetry emit (non-blocking best-effort)
    # ------------------------------------------------------------------

    def _emit(
        self,
        from_node: str,
        to_node: str,
        reason: str,
        correlation_id: str | None,
    ) -> None:
        if self.telemetry_stream is None:
            return
        try:
            if hasattr(self.telemetry_stream, "emit_logic_drift_red"):
                self.telemetry_stream.emit_logic_drift_red(
                    from_node=from_node,
                    to_node=to_node,
                    path_so_far=list(self._actual_path),
                    reason=reason,
                    correlation_id=correlation_id,
                    iso_control_reference="ISO 42001 A.8.2",
                    nist_function=NIST_TAG,
                )
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Convenience: inject constraint into request payload
# ---------------------------------------------------------------------------

def inject_corrective_constraint(
    request_payload: dict[str, Any],
    constraint: CorrectiveConstraint,
) -> dict[str, Any]:
    """
    Inject a CorrectiveConstraint into an agent request payload.

    Supports two payload shapes:
      - {"messages": [...]}  — prepends a {"role": "system", "content": ...} entry
      - {"prompt": "..."}    — prepends the constraint text to the existing prompt
      - any other shape      — inserts {"_corrective_constraint": ...}
    """
    payload = dict(request_payload)
    if "messages" in payload and isinstance(payload["messages"], list):
        payload["messages"] = [
            {"role": "system", "content": constraint.text}
        ] + list(payload["messages"])
    elif "prompt" in payload and isinstance(payload["prompt"], str):
        payload["prompt"] = f"{constraint.text}\n\n{payload['prompt']}"
    else:
        payload["_corrective_constraint"] = constraint.text
    return payload
