"""
Deterministic Interception — Logic Drift Sentinel.
Compares current LangGraph node transition against golden_path; on deviation emits logic_drift_red to telemetry.
CAIRO Protocol Technical Architecture v1.0.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class LogicDriftDetector(BaseModel):
    """
    Deterministic Interception: compares current path to pre-approved golden_path.
    If the current LangGraph node transition deviates, emits logic_drift_red pulse to the telemetry stream.
    Every emitted pulse includes iso_control_reference and nist_function (telemetry precision).
    """

    golden_path: list[str] = Field(default_factory=list, description="Pre-approved ordered node IDs")
    telemetry_stream: Any = Field(default=None, description="TelemetryStream to emit logic_drift_red")

    model_config = {"arbitrary_types_allowed": True, "extra": "forbid"}

    def set_golden_path(self, path: list[str]) -> None:
        self.golden_path = list(path)

    def check_drift(self, path_so_far: list[str]) -> tuple[bool, str | None]:
        """
        Returns (has_drift, reason).
        Drift = current path is not a valid prefix of golden path.
        """
        if not self.golden_path:
            return False, None
        golden = self.golden_path
        current = path_so_far
        for i, node in enumerate(current):
            if i >= len(golden):
                return True, f"path exceeds golden path length at node '{node}'"
            if node != golden[i]:
                return True, f"deviation at index {i}: expected '{golden[i]}', got '{node}'"
        return False, None

    def check_transition(
        self,
        from_node: str,
        to_node: str,
        path_so_far: list[str] | None = None,
        correlation_id: str | None = None,
        iso_control_reference: str = "ISO 42001 A.8.2",
        nist_function: str = "GOVERN",
    ) -> bool:
        """
        Compare current LangGraph node transition (from_node -> to_node) against golden_path.
        If it deviates, emit logic_drift_red pulse to the telemetry stream and return True (drift).
        Returns False if on path. Every pulse includes iso_control_reference and nist_function.
        """
        path = list(path_so_far or [])
        if not path or path[-1] != from_node:
            path.append(from_node)
        path.append(to_node)
        has_drift, reason = self.check_drift(path)
        if not has_drift:
            return False
        if self.telemetry_stream is not None and hasattr(self.telemetry_stream, "emit_logic_drift_red"):
            try:
                self.telemetry_stream.emit_logic_drift_red(
                    from_node=from_node,
                    to_node=to_node,
                    path_so_far=path,
                    reason=reason,
                    correlation_id=correlation_id,
                    iso_control_reference=iso_control_reference,
                    nist_function=nist_function,
                )
            except Exception:
                pass
        return True
