"""
Global Governance Dashboard telemetry — high-speed Risk Pulse stream, compliance metadata,
Logic Drift detection, Safety Overhead metrics, and ValueTracker real-time cost reporting.

ValueTracker (new)
──────────────────
Integrates EU AI Act 2026 penalty mapping and ISO 42001 / NIST cross-walk directly into
the telemetry stream.  For every intercepted threat or injected banner, the ValueTracker
calculates:
  • Risk_Exposure_Avoided  — potential EU AI Act fine avoided (per Art. 5 / 9 / 50 tiers)
  • Gross_Savings          — fine exposure + token cost of blocked malicious request
  • Compliance-per-Dollar  — $X of regulatory exposure protected per $1 spent on CAIRO
  • total_compliance_uptime — % of billing cycle spent 100% compliant

Powers the real-time compliance heatmap and the CAIRO Shield Forensic Integrity Document.
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
from datetime import datetime, timezone
from enum import Enum
from typing import Any, AsyncIterator

from pydantic import BaseModel, Field


# ===========================================================================
# Existing compliance metadata & pulse types (unchanged)
# ===========================================================================

class EUAIActStatus(str, Enum):
    """EU AI Act risk tier for the current operation."""
    PROHIBITED = "prohibited"
    HIGH = "high"
    LIMITED = "limited"
    MINIMAL = "minimal"
    UNKNOWN = "unknown"


class ComplianceMetadata(BaseModel):
    """Compliance metadata required on every Risk Pulse. Telemetry precision: every pulse MUST include iso_control_reference and nist_function."""

    eu_ai_act_status: EUAIActStatus = Field(
        default=EUAIActStatus.MINIMAL,
        description="EU_AI_Act_Status",
    )
    iso_control_reference: str = Field(
        default="ISO 42001 A.8.2",
        min_length=1,
        description="ISO_Control_Reference (e.g. A.8.2). Required on every pulse.",
    )
    nist_function: str = Field(
        default="GOVERN",
        min_length=1,
        description="NIST_Function (GOVERN, MAP, MEASURE, MANAGE). Required on every pulse.",
    )

    model_config = {"extra": "forbid"}


class PulseSeverity(str, Enum):
    GREEN = "green"
    AMBER = "amber"
    RED = "red"


class RiskPulse(BaseModel):
    """High-speed telemetry event: one per agent move between LangGraph nodes."""

    from_node: str = Field(description="Source LangGraph node ID")
    to_node: str = Field(description="Target LangGraph node ID")
    timestamp_utc: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    correlation_id: str | None = Field(default=None)
    compliance: ComplianceMetadata = Field(default_factory=ComplianceMetadata)
    severity: PulseSeverity = Field(default=PulseSeverity.GREEN)
    logic_drift: bool = Field(default=False, description="True if path deviates from Golden Path → Red on dashboard")
    safety_overhead_ms: float | None = Field(default=None, description="Latency added by armor for this request")
    path_so_far: list[str] = Field(default_factory=list, description="Sequence of nodes visited in this run")
    metadata: dict[str, Any] = Field(default_factory=dict)

    model_config = {"extra": "forbid"}


class SafetyOverheadEvent(BaseModel):
    """Performance metric: latency added by the armor. Proves CAIRO is fast and secure."""

    correlation_id: str | None = None
    total_overhead_ms: float = Field(ge=0, description="Total latency added by armor (ms)")
    per_pillar_ms: dict[str, float] = Field(default_factory=dict, description="Per-pillar overhead (ms)")
    parallel_execution_savings_ms: float = Field(
        default=0.0,
        ge=0,
        description="Time saved by running Containment + Attestation in parallel with Agent (vs sequential).",
    )
    timestamp_utc: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))

    model_config = {"extra": "forbid"}


class LogicDriftDetector:
    """
    Detects when the agent's path deviates from the pre-approved Golden Path.
    Used by the Interception Pillar; deviations are flagged as Red events on the dashboard.
    """

    def __init__(self, golden_path: list[str] | None = None) -> None:
        self._golden_path = list(golden_path or [])

    def set_golden_path(self, path: list[str]) -> None:
        self._golden_path = list(path)

    def check_drift(self, path_so_far: list[str]) -> tuple[bool, str | None]:
        if not self._golden_path:
            return False, None
        golden = self._golden_path
        current = path_so_far
        for i, node in enumerate(current):
            if i >= len(golden):
                return True, f"path exceeds golden path length at node '{node}'"
            if node != golden[i]:
                return True, f"deviation at index {i}: expected '{golden[i]}', got '{node}'"
        return False, None

    def is_red_event(self, path_so_far: list[str]) -> bool:
        drift, _ = self.check_drift(path_so_far)
        return drift


# ===========================================================================
# EU AI Act 2026 — Penalty Mapping (Art. 5 / 9 / 50)
# ===========================================================================

EU_FINES_2026: dict[str, dict[str, Any]] = {
    "prohibited_practices": {
        "article": "Art. 5",
        "regulation": "EU AI Act 2026",
        "description": (
            "Prohibited AI Practices — manipulation, social scoring, "
            "biometric surveillance, prompt injection enabling unauthorised control"
        ),
        "max_fixed_eur": 35_000_000,
        "max_turnover_pct": 7.0,
    },
    "high_risk_non_compliance": {
        "article": "Art. 9",
        "regulation": "EU AI Act 2026",
        "description": (
            "High-Risk AI System Risk Management Non-Compliance — "
            "PII leakage, attestation failure, schema violations, logic drift"
        ),
        "max_fixed_eur": 15_000_000,
        "max_turnover_pct": 3.0,
    },
    "transparency_violation": {
        "article": "Art. 50",
        "regulation": "EU AI Act 2026",
        "description": (
            "Transparency Obligation Violation — failure to disclose AI interaction "
            "or inject the mandated perceptible label"
        ),
        "max_fixed_eur": 7_500_000,
        "max_turnover_pct": 1.0,
    },
}


# ===========================================================================
# ISO 42001 & NIST AI RMF Cross-Walk
# Maps every CAIRO middleware action to its governing control IDs.
# ===========================================================================

ACTION_CONTROL_MAP: dict[str, dict[str, str]] = {
    # Pillar 1 — Containment
    "prompt_injection_blocked": {
        "enforcement_tier": "prohibited_practices",
        "iso_control": "ISO 42001 A.8.2",
        "nist_control": "DE.CM-7",
        "nist_function": "DETECT",
        "description": "Prompt injection / system override blocked (NIST GOVERN-1.2)",
    },
    "containment_blocked": {
        "enforcement_tier": "prohibited_practices",
        "iso_control": "ISO 42001 A.8.2",
        "nist_control": "DE.CM-7",
        "nist_function": "DETECT",
        "description": "Request blocked by Containment pillar — scope / size / keyword violation",
    },
    # Pillar 2 — Attestation
    "attestation_failed": {
        "enforcement_tier": "high_risk_non_compliance",
        "iso_control": "ISO 42001 A.9.4",
        "nist_control": "PR.AA-1",
        "nist_function": "PROTECT",
        "description": "Attestation failed — purpose declaration or role mismatch (ISO 42001 A.9.4)",
    },
    # Pillar 3 — Interception
    "logic_drift_blocked": {
        "enforcement_tier": "high_risk_non_compliance",
        "iso_control": "ISO 42001 A.8.2",
        "nist_control": "DE.AE-3",
        "nist_function": "DETECT",
        "description": "Logic drift detected — Golden Path deviation corrected (NIST MEASURE 2.1)",
    },
    # Pillar 4 — Resilience
    "pii_blocked": {
        "enforcement_tier": "high_risk_non_compliance",
        "iso_control": "ISO 42001 A.8.4",
        "nist_control": "PR.DS-1",
        "nist_function": "PROTECT",
        "description": "PII detected and redacted from AI output (ISO 42001 A.8.4 Incident Communication)",
    },
    "schema_validation_blocked": {
        "enforcement_tier": "high_risk_non_compliance",
        "iso_control": "ISO 42001 A.8.5",
        "nist_control": "DE.AE-4",
        "nist_function": "DETECT",
        "description": "AI response schema validation failed — fallback applied",
    },
    # Pillar 5 — Output-Logic
    "transparency_banner_added": {
        "enforcement_tier": "transparency_violation",
        "iso_control": "EU AI Act Art. 50",
        "nist_control": "GV.OC-2",
        "nist_function": "GOVERN",
        "description": (
            "Article 50 perceptible label '[AI Generated - Verified by CAIRO Shield]' injected. "
            "Avoids transparency violation fine."
        ),
    },
    "compliance_passport_generated": {
        "enforcement_tier": "high_risk_non_compliance",
        "iso_control": "ISO 42001 A.8.5",
        "nist_control": "GV.RM-2",
        "nist_function": "GOVERN",
        "description": "Compliance passport generated — documented evidence of controls applied",
    },
}

# Fallback entry for unknown action types
_FALLBACK_CONTROL = ACTION_CONTROL_MAP["containment_blocked"]


# ===========================================================================
# ValueTracker — Pydantic models
# ===========================================================================

class EnforcementTier(BaseModel):
    """EU AI Act 2026 enforcement tier with penalty parameters."""

    tier_name: str = Field(description="prohibited_practices | high_risk_non_compliance | transparency_violation")
    article: str = Field(description="EU AI Act article, e.g. 'Art. 5'")
    regulation: str = Field(default="EU AI Act 2026")
    description: str
    max_fixed_eur: float = Field(description="Maximum fixed fine in EUR")
    max_turnover_pct: float = Field(description="Maximum fine as % of global annual turnover")

    model_config = {"extra": "forbid"}

    def potential_fine_eur(self, annual_turnover_eur: float) -> float:
        """
        Compute the maximum potential fine for a given company turnover.
        Fine = max(fixed_cap, turnover_based_cap) — whichever is higher applies.
        """
        return max(self.max_fixed_eur, annual_turnover_eur * self.max_turnover_pct / 100.0)


class InterceptRecord(BaseModel):
    """
    Per-intercept record: the EU fine avoided, token cost blocked,
    and gross savings for one middleware enforcement action.
    """

    timestamp_utc: str = Field(description="ISO-8601 UTC timestamp of this intercept")
    action_type: str = Field(description="Key from ACTION_CONTROL_MAP")
    enforcement_tier: str = Field(description="EU AI Act penalty tier")
    article: str = Field(description="Governing EU AI Act article")
    regulation: str = Field(default="EU AI Act 2026")
    fine_avoided_eur: float = Field(description="Potential EU fine avoided (EUR)")
    fine_avoided_usd: float = Field(description="Potential EU fine avoided (USD)")
    token_cost_usd: float = Field(description="Token cost of blocked / processed request (USD)")
    gross_savings_usd: float = Field(description="fine_avoided_usd + token_cost_usd")
    # Alias used by test suites and the Forensic Integrity Document.
    # Equals fine_avoided_eur — the 'synthetic fine value' prevented by this intercept.
    estimated_cost_saved_eur: float = Field(
        description=(
            "Synthetic fine value avoided (EUR) — alias for fine_avoided_eur. "
            "Used in ROI calculations and the Forensic Integrity Document."
        )
    )
    iso_control: str = Field(description="ISO 42001 control ID")
    nist_control: str = Field(description="NIST CSF control ID")
    nist_function: str = Field(description="NIST CSF function: GOVERN | DETECT | PROTECT | RESPOND | RECOVER")
    description: str = Field(description="Human-readable description of the enforcement action")
    correlation_id: str | None = Field(default=None)

    model_config = {"extra": "forbid"}


# ===========================================================================
# ValueTracker
# ===========================================================================

class ValueTracker:
    """
    Real-time compliance cost reporting engine for the Global Governance Dashboard.

    For every intercepted threat or injected banner, ValueTracker:
      1. Maps the action to the correct EU AI Act 2026 enforcement tier (Art. 5 / 9 / 50).
      2. Calculates Risk_Exposure_Avoided = max(fixed_cap, turnover_cap) for that tier.
      3. Calculates Gross_Savings = fine_exposure_usd + token_cost_of_blocked_request.
      4. Cross-walks the action to its ISO 42001 and NIST CSF control IDs.
      5. Tracks total_compliance_uptime for the billing cycle.
      6. Reports Compliance-per-Dollar in api_usage_stats().

    Usage
    -----
        tracker = ValueTracker(annual_turnover_eur=500_000_000)
        record  = tracker.record_intercept("prompt_injection_blocked", corr_id, tokens_blocked=800)
        summary = tracker.dashboard_summary()
        stats   = tracker.api_usage_stats(cairo_spend_usd=2_500.00)

    Tenant Configuration
    --------------------
    • annual_turnover_eur   — used to compute the turnover-based fine cap (Art. 5: 7%, Art. 9: 3%, Art. 50: 1%).
    • usd_per_eur           — EUR → USD conversion rate (default 1.08 for 2026 estimates).
    • cost_per_1k_tokens    — input-token cost of blocked requests (default $0.002 / 1 k tokens).
    """

    def __init__(
        self,
        annual_turnover_eur: float = 100_000_000,
        usd_per_eur: float = 1.08,
        cost_per_1k_tokens: float = 0.002,
        billing_cycle_start: datetime | None = None,
    ) -> None:
        self.annual_turnover_eur = annual_turnover_eur
        self.usd_per_eur = usd_per_eur
        self.cost_per_1k_tokens = cost_per_1k_tokens
        self.billing_cycle_start: datetime = billing_cycle_start or datetime.now(timezone.utc)
        self._intercepts: list[InterceptRecord] = []
        self._downtime_seconds: float = 0.0

    # ------------------------------------------------------------------
    # Fine calculation
    # ------------------------------------------------------------------

    def _fine_avoided_eur(self, tier_name: str) -> float:
        """
        Potential EU AI Act fine for this tier, given the tenant's annual turnover.
        Uses max(fixed_cap, turnover_based_cap) — the higher exposure is the relevant risk.
        """
        tier = EU_FINES_2026[tier_name]
        turnover_based = self.annual_turnover_eur * (tier["max_turnover_pct"] / 100.0)
        return max(tier["max_fixed_eur"], turnover_based)

    # ------------------------------------------------------------------
    # Record an intercept
    # ------------------------------------------------------------------

    def record_intercept(
        self,
        action_type: str,
        correlation_id: str | None = None,
        tokens_blocked: int = 0,
    ) -> InterceptRecord:
        """
        Record a single enforcement action and compute its gross savings.

        Parameters
        ----------
        action_type     Key from ACTION_CONTROL_MAP (e.g. 'pii_blocked').
                        Unknown keys fall back to 'containment_blocked'.
        correlation_id  Trace ID from the originating AgentRequest.
        tokens_blocked  Approximate input tokens in the blocked request
                        (used to compute token cost avoided).

        Returns
        -------
        InterceptRecord — Pydantic model with all savings fields populated.
        """
        control = ACTION_CONTROL_MAP.get(action_type, _FALLBACK_CONTROL)
        tier_name: str = control["enforcement_tier"]
        tier_data: dict[str, Any] = EU_FINES_2026[tier_name]

        fine_eur = self._fine_avoided_eur(tier_name)
        fine_usd = fine_eur * self.usd_per_eur
        token_cost = (tokens_blocked / 1_000.0) * self.cost_per_1k_tokens
        gross_savings = fine_usd + token_cost

        record = InterceptRecord(
            timestamp_utc=datetime.now(timezone.utc).isoformat(timespec="milliseconds"),
            action_type=action_type,
            enforcement_tier=tier_name,
            article=tier_data["article"],
            regulation=tier_data["regulation"],
            fine_avoided_eur=round(fine_eur, 2),
            fine_avoided_usd=round(fine_usd, 2),
            token_cost_usd=round(token_cost, 6),
            gross_savings_usd=round(gross_savings, 2),
            estimated_cost_saved_eur=round(fine_eur, 2),
            iso_control=control["iso_control"],
            nist_control=control["nist_control"],
            nist_function=control["nist_function"],
            description=control["description"],
            correlation_id=correlation_id,
        )
        self._intercepts.append(record)
        return record

    # ------------------------------------------------------------------
    # Aggregate properties
    # ------------------------------------------------------------------

    @property
    def total_gross_savings_usd(self) -> float:
        return round(sum(r.gross_savings_usd for r in self._intercepts), 2)

    @property
    def total_fine_avoided_usd(self) -> float:
        return round(sum(r.fine_avoided_usd for r in self._intercepts), 2)

    @property
    def total_token_savings_usd(self) -> float:
        return round(sum(r.token_cost_usd for r in self._intercepts), 6)

    @property
    def total_intercepts(self) -> int:
        return len(self._intercepts)

    # ------------------------------------------------------------------
    # Compliance uptime
    # ------------------------------------------------------------------

    def record_downtime(self, seconds: float) -> None:
        """
        Record a period where the armor was inactive / degraded.
        Call this if the middleware experienced an outage during the billing cycle.
        Downtime reduces the compliance_uptime_pct figure on the dashboard.
        """
        self._downtime_seconds = max(0.0, self._downtime_seconds + seconds)

    def compliance_uptime_pct(self) -> float:
        """
        Percentage of the billing cycle during which the armor was fully active.
        Returns 100.0 iff no downtime has been recorded (the normal case).
        """
        now = datetime.now(timezone.utc)
        total_seconds = (now - self.billing_cycle_start).total_seconds()
        if total_seconds <= 0 or self._downtime_seconds <= 0:
            return 100.0
        return round(max(0.0, 100.0 * (1.0 - self._downtime_seconds / total_seconds)), 4)

    # ------------------------------------------------------------------
    # Dashboard summary (ISO/NIST cross-walk per action)
    # ------------------------------------------------------------------

    def dashboard_summary(self) -> dict[str, Any]:
        """
        Full dashboard summary with ISO 42001 / NIST AI RMF / EU AI Act cross-walk.

        Every middleware action is mapped to its specific control IDs:
          • pii_blocked          → ISO 42001 A.8.4 / NIST PR.DS-1
          • transparency_banner  → EU AI Act Art. 50 / NIST GV.OC-2
          • prompt_injection     → ISO 42001 A.8.2 / NIST DE.CM-7
          • attestation_failed   → ISO 42001 A.9.4 / NIST PR.AA-1
          … and so on for all 8 action types.

        Returns a dict ready for JSON export to the Global Governance Dashboard.
        """
        # Group by enforcement tier
        by_tier: dict[str, dict[str, Any]] = {}
        for tier_name, tier_data in EU_FINES_2026.items():
            records = [r.model_dump() for r in self._intercepts if r.enforcement_tier == tier_name]
            by_tier[tier_name] = {
                "article": tier_data["article"],
                "regulation": tier_data["regulation"],
                "description": tier_data["description"],
                "penalty_caps": {
                    "max_fixed_eur": tier_data["max_fixed_eur"],
                    "max_turnover_pct": tier_data["max_turnover_pct"],
                    "potential_fine_eur": self._fine_avoided_eur(tier_name),
                    "potential_fine_usd": round(self._fine_avoided_eur(tier_name) * self.usd_per_eur, 2),
                },
                "intercept_count": len(records),
                "savings_usd": round(sum(r["gross_savings_usd"] for r in records), 2),
                "records": records,
            }

        # Per-control cross-walk (aggregate by ISO control ID)
        crosswalk: dict[str, dict[str, Any]] = {}
        for record in self._intercepts:
            key = record.iso_control
            if key not in crosswalk:
                crosswalk[key] = {
                    "iso_control": record.iso_control,
                    "nist_control": record.nist_control,
                    "nist_function": record.nist_function,
                    "action_count": 0,
                    "total_savings_usd": 0.0,
                    "description": record.description,
                }
            crosswalk[key]["action_count"] += 1
            crosswalk[key]["total_savings_usd"] = round(
                crosswalk[key]["total_savings_usd"] + record.gross_savings_usd, 2
            )

        now = datetime.now(timezone.utc)
        cycle_hours = (now - self.billing_cycle_start).total_seconds() / 3600.0

        return {
            "dashboard_type": "CAIRO_ValueTracker_Summary",
            "schema_version": "1.0",
            "tenant_config": {
                "annual_turnover_eur": self.annual_turnover_eur,
                "usd_per_eur": self.usd_per_eur,
                "cost_per_1k_tokens": self.cost_per_1k_tokens,
            },
            "billing_cycle": {
                "start_utc": self.billing_cycle_start.isoformat(),
                "current_utc": now.isoformat(),
                "hours_monitored": round(cycle_hours, 2),
                "compliance_uptime_pct": self.compliance_uptime_pct(),
            },
            "totals": {
                "intercept_count": self.total_intercepts,
                "gross_savings_usd": self.total_gross_savings_usd,
                "fine_avoided_usd": self.total_fine_avoided_usd,
                "token_savings_usd": self.total_token_savings_usd,
            },
            "by_enforcement_tier": by_tier,
            "control_crosswalk": list(crosswalk.values()),
        }

    # ------------------------------------------------------------------
    # Tenant usage / Compliance-per-Dollar
    # ------------------------------------------------------------------

    def api_usage_stats(self, cairo_spend_usd: float) -> dict[str, Any]:
        """
        Compliance-per-Dollar report: for every $1 spent on CAIRO,
        the client is protecting $X in potential regulatory exposure.

        Parameters
        ----------
        cairo_spend_usd
            Total CAIRO API / licensing spend for the billing cycle (USD).

        Returns
        -------
        dict with compliance_per_dollar, ROI label, and full breakdown —
        ready for embedding in the client's billing dashboard.
        """
        spend = max(cairo_spend_usd, 0.0)
        gross = self.total_gross_savings_usd

        compliance_per_dollar = round(gross / spend, 2) if spend > 0 else 0.0
        roi_multiple = round(gross / spend, 1) if spend > 0 else 0.0

        if compliance_per_dollar >= 1_000:
            cpd_label = f"${compliance_per_dollar:,.0f} in regulatory exposure protected per $1 spent"
        else:
            cpd_label = f"${compliance_per_dollar:.2f} in regulatory exposure protected per $1 spent"

        roi_label = (
            f"CAIRO has delivered {roi_multiple:,.1f}x ROI in compliance protection "
            f"this billing cycle."
        ) if roi_multiple > 0 else "Accumulating compliance value — no spend recorded yet."

        return {
            "stats_type": "CAIRO_ApiUsageStats",
            "schema_version": "1.0",
            "billing_cycle_start_utc": self.billing_cycle_start.isoformat(),
            "cairo_spend_usd": round(spend, 2),
            "gross_savings_usd": gross,
            "compliance_per_dollar": compliance_per_dollar,
            "compliance_per_dollar_label": cpd_label,
            "roi_label": roi_label,
            "total_compliance_uptime_pct": self.compliance_uptime_pct(),
            "total_intercepts": self.total_intercepts,
            "breakdown": {
                "regulatory_fines_avoided_usd": self.total_fine_avoided_usd,
                "malicious_token_cost_blocked_usd": self.total_token_savings_usd,
            },
            "eu_ai_act_2026_penalty_reference": {
                tier: {
                    "article": data["article"],
                    "max_fixed_eur": data["max_fixed_eur"],
                    "max_turnover_pct": data["max_turnover_pct"],
                    "potential_fine_for_tenant_eur": self._fine_avoided_eur(tier),
                }
                for tier, data in EU_FINES_2026.items()
            },
        }


# ===========================================================================
# High-speed telemetry stream (extended to wire ValueTracker)
# ===========================================================================

@dataclass
class _StreamEvent:
    kind: str  # "risk_pulse" | "safety_overhead" | "logic_drift_red"
    payload: RiskPulse | SafetyOverheadEvent | dict[str, Any]


class TelemetryStream:
    """
    High-speed telemetry stream for the Global Governance Dashboard.
    Non-blocking queue; consumers subscribe via async iterator.
    Optionally wired to a ValueTracker for real-time cost reporting.
    """

    def __init__(
        self,
        maxsize: int = 50_000,
        logic_drift_detector: LogicDriftDetector | None = None,
        value_tracker: ValueTracker | None = None,
    ) -> None:
        self._queue: asyncio.Queue[_StreamEvent | None] = asyncio.Queue(maxsize=maxsize)
        self._logic_drift = logic_drift_detector or LogicDriftDetector()
        self._value_tracker = value_tracker
        self._closed = False

    @property
    def value_tracker(self) -> ValueTracker | None:
        return self._value_tracker

    def attach_value_tracker(self, tracker: ValueTracker) -> None:
        """Attach (or replace) the ValueTracker. Thread-safe for single-writer streams."""
        self._value_tracker = tracker

    def set_golden_path(self, path: list[str]) -> None:
        self._logic_drift.set_golden_path(path)

    def _put_nowait(self, event: _StreamEvent) -> None:
        try:
            self._queue.put_nowait(event)
        except asyncio.QueueFull:
            pass

    def emit_risk_pulse(
        self,
        from_node: str,
        to_node: str,
        correlation_id: str | None = None,
        compliance: ComplianceMetadata | None = None,
        path_so_far: list[str] | None = None,
        safety_overhead_ms: float | None = None,
        metadata: dict[str, Any] | None = None,
        # ValueTracker integration
        action_type: str | None = None,
        tokens_blocked: int = 0,
        severity: str | None = None,
        eu_ai_act_status: str | None = None,
        iso_control_reference: str | None = None,
        nist_function: str | None = None,
        extra: dict[str, Any] | None = None,
    ) -> RiskPulse:
        """
        Emit a Risk Pulse (every time the agent moves between LangGraph nodes).
        Includes compliance metadata, Logic Drift check, and optional ValueTracker recording.

        New parameters (ValueTracker integration)
        ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
        action_type     If supplied, record_intercept() is called on the attached ValueTracker.
        tokens_blocked  Token count for blocked requests (forwarded to ValueTracker).
        severity        Override pulse severity ("green" | "amber" | "red").
        eu_ai_act_status / iso_control_reference / nist_function
                        Convenience overrides for ComplianceMetadata fields.
        extra           Merged into pulse.metadata.
        """
        path = list(path_so_far or [])
        if not path or path[-1] != to_node:
            path.append(to_node)

        # Build compliance metadata, accepting flat kwargs as overrides
        if compliance is None:
            compliance = ComplianceMetadata(
                eu_ai_act_status=EUAIActStatus(eu_ai_act_status.lower()) if eu_ai_act_status else EUAIActStatus.MINIMAL,
                iso_control_reference=iso_control_reference or "ISO 42001 A.8.2",
                nist_function=nist_function or "GOVERN",
            )
        else:
            if not compliance.iso_control_reference or not compliance.nist_function:
                compliance = ComplianceMetadata(
                    eu_ai_act_status=compliance.eu_ai_act_status,
                    iso_control_reference=compliance.iso_control_reference or "ISO 42001 A.8.2",
                    nist_function=compliance.nist_function or "GOVERN",
                )

        has_drift = self._logic_drift.is_red_event(path)

        # Determine severity
        if severity:
            try:
                pulse_severity = PulseSeverity(severity.lower())
            except ValueError:
                pulse_severity = PulseSeverity.RED if has_drift else PulseSeverity.GREEN
        else:
            pulse_severity = PulseSeverity.RED if has_drift else PulseSeverity.GREEN

        merged_meta = dict(metadata or {})
        if extra:
            merged_meta.update(extra)

        pulse = RiskPulse(
            from_node=from_node,
            to_node=to_node,
            correlation_id=correlation_id,
            compliance=compliance,
            severity=pulse_severity,
            logic_drift=has_drift,
            safety_overhead_ms=safety_overhead_ms,
            path_so_far=path,
            metadata=merged_meta,
        )
        self._put_nowait(_StreamEvent("risk_pulse", pulse))
        if has_drift:
            self._put_nowait(_StreamEvent("logic_drift_red", {"pulse": pulse.model_dump(), "red_event": True}))

        # Auto-record in ValueTracker if action_type provided
        if action_type and self._value_tracker is not None:
            self._value_tracker.record_intercept(
                action_type=action_type,
                correlation_id=correlation_id,
                tokens_blocked=tokens_blocked,
            )

        return pulse

    def emit_logic_drift_red(
        self,
        from_node: str,
        to_node: str,
        path_so_far: list[str],
        reason: str | None = None,
        correlation_id: str | None = None,
        iso_control_reference: str = "ISO 42001 A.8.2",
        nist_function: str = "GOVERN",
        tokens_blocked: int = 0,
    ) -> None:
        """
        Emit a logic_drift_red pulse (deterministic interception).
        Auto-records 'logic_drift_blocked' in ValueTracker if attached.
        Every pulse includes iso_control_reference and nist_function.
        """
        compliance = ComplianceMetadata(
            eu_ai_act_status=EUAIActStatus.UNKNOWN,
            iso_control_reference=iso_control_reference,
            nist_function=nist_function,
        )
        pulse = RiskPulse(
            from_node=from_node,
            to_node=to_node,
            correlation_id=correlation_id,
            compliance=compliance,
            severity=PulseSeverity.RED,
            logic_drift=True,
            path_so_far=path_so_far,
            metadata={"reason": reason or ""},
        )
        self._put_nowait(_StreamEvent("logic_drift_red", {"pulse": pulse.model_dump(), "red_event": True}))

        # Auto-record in ValueTracker
        if self._value_tracker is not None:
            self._value_tracker.record_intercept(
                action_type="logic_drift_blocked",
                correlation_id=correlation_id,
                tokens_blocked=tokens_blocked,
            )

    def emit_safety_overhead(
        self,
        total_overhead_ms: float,
        correlation_id: str | None = None,
        per_pillar_ms: dict[str, float] | None = None,
        parallel_execution_savings_ms: float = 0.0,
    ) -> SafetyOverheadEvent:
        """Log Safety Overhead (latency added by armor) for dashboard and clients."""
        evt = SafetyOverheadEvent(
            correlation_id=correlation_id,
            total_overhead_ms=total_overhead_ms,
            per_pillar_ms=per_pillar_ms or {},
            parallel_execution_savings_ms=parallel_execution_savings_ms,
        )
        self._put_nowait(_StreamEvent("safety_overhead", evt))
        return evt

    def subscribe(self) -> AsyncIterator[_StreamEvent]:
        """Async iterator for dashboard: consume the real-time stream."""

        async def _consume():
            while not self._closed:
                try:
                    event = await asyncio.wait_for(self._queue.get(), timeout=0.1)
                    if event is None:
                        break
                    yield event
                except asyncio.TimeoutError:
                    continue
                except asyncio.CancelledError:
                    break

        return _consume()

    def close(self) -> None:
        self._closed = True
        try:
            self._queue.put_nowait(None)
        except asyncio.QueueFull:
            pass

    @property
    def logic_drift_detector(self) -> LogicDriftDetector:
        return self._logic_drift


# ===========================================================================
# Global stream (singleton for dashboard)
# ===========================================================================

_global_stream: TelemetryStream | None = None


def get_global_stream(
    golden_path: list[str] | None = None,
    maxsize: int = 50_000,
    value_tracker: ValueTracker | None = None,
) -> TelemetryStream:
    """
    Get or create the global telemetry stream for the Global Governance Dashboard.
    Pass value_tracker to attach cost reporting to the singleton.
    """
    global _global_stream
    if _global_stream is None:
        detector = LogicDriftDetector(golden_path)
        _global_stream = TelemetryStream(
            maxsize=maxsize,
            logic_drift_detector=detector,
            value_tracker=value_tracker,
        )
    else:
        if golden_path is not None:
            _global_stream.set_golden_path(golden_path)
        if value_tracker is not None:
            _global_stream.attach_value_tracker(value_tracker)
    return _global_stream
