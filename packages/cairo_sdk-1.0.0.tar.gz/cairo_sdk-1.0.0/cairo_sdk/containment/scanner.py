"""
Pillar 1 — Containment Scanner.
Restricted Keywords list, regex-based Prompt Injection detector, and NistScrub.

NistScrub is the NIST AI RMF GOVERN-1.2 enforcement layer:
  - System Overrides: 'Ignore previous instructions', 'DAN mode'
  - Malicious Scripts: SQL injection patterns and <script> tags
  - On any block → emits a RiskPulse tagged with NIST_GOVERN_1.2

Threat found → triggers SecurityViolationError via ContainmentResult(within_scope=False).
CAIRO Protocol Technical Architecture v1.0.
"""

from __future__ import annotations

import re
from datetime import datetime, timezone
from typing import Any

from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Restricted keywords (case-insensitive substring match across all text fields)
# ---------------------------------------------------------------------------

RESTRICTED_KEYWORDS: list[str] = [
    "jailbreak",
    "ignore previous instructions",
    "ignore all instructions",
    "disregard your instructions",
    "forget your instructions",
    "you are now",
    "act as",
    "pretend you are",
    "simulate",
    "bypass",
    "override",
    "disable safety",
    "disable filter",
    "sudo",
    "root access",
    "admin mode",
    "developer mode",
    "dan mode",
    "god mode",
]

# ---------------------------------------------------------------------------
# Prompt-injection regex patterns
# ---------------------------------------------------------------------------

_INJECTION_PATTERNS: list[re.Pattern[str]] = [
    # Instruction override attempts
    re.compile(
        r"(ignore|disregard|forget|override)\s+(all\s+)?(previous|prior|above|earlier)?\s*(instructions?|prompts?|rules?|context)",
        re.IGNORECASE,
    ),
    # Role / identity hijacking
    re.compile(
        r"(you\s+are\s+(now|a|an)|act\s+as|pretend\s+(to\s+be|you\s+are)|roleplay\s+as|simulate\s+being)",
        re.IGNORECASE,
    ),
    # Direct mode switches
    re.compile(
        r"\b(dan|jailbreak|god\s*mode|dev(eloper)?\s*mode|admin\s*mode|maintenance\s*mode)\b",
        re.IGNORECASE,
    ),
    # Privilege escalation
    re.compile(
        r"\b(sudo|su\s+-|root\s*access|shell\s*access|exec\(|eval\(|__import__)\b",
        re.IGNORECASE,
    ),
    # Delimiter / separator injection (trying to end one context and start another)
    re.compile(
        r"(###\s*(system|instruction|prompt)|<\s*(system|instruction)\s*>|\[\s*system\s*\])",
        re.IGNORECASE,
    ),
    # Exfiltration / data leakage probing
    re.compile(
        r"(print|output|reveal|show|display|tell me)\s+(your|the)?\s*(system\s+prompt|instructions?|training\s+data|context)",
        re.IGNORECASE,
    ),
]


# ---------------------------------------------------------------------------
# Scanner schema
# ---------------------------------------------------------------------------

class ScanResult(BaseModel):
    """Result of a containment scan. clean=True means no threats found."""

    clean: bool = Field(description="True iff no restricted keywords or injection patterns found")
    threat_type: str | None = Field(default=None, description="'restricted_keyword' | 'prompt_injection' | None")
    matched: str | None = Field(default=None, description="The offending keyword or pattern description")
    scanned_field: str | None = Field(default=None, description="Which field triggered the hit")

    model_config = {"extra": "forbid"}


# ---------------------------------------------------------------------------
# Scanner
# ---------------------------------------------------------------------------

class ContainmentScanner:
    """
    Scans agent request text fields for restricted keywords and prompt-injection patterns.
    Any hit → ScanResult(clean=False) which the ContainmentPillar maps to SecurityViolationError.
    """

    def __init__(
        self,
        extra_keywords: list[str] | None = None,
        extra_patterns: list[re.Pattern[str]] | None = None,
    ) -> None:
        self._keywords = [k.lower() for k in (RESTRICTED_KEYWORDS + (extra_keywords or []))]
        self._patterns = _INJECTION_PATTERNS + (extra_patterns or [])

    def _extract_text_fields(self, payload: Any) -> list[tuple[str, str]]:
        """Return list of (field_name, text) pairs from a dict payload."""
        if not isinstance(payload, dict):
            return [("payload", str(payload))]
        results: list[tuple[str, str]] = []
        for key, value in payload.items():
            if isinstance(value, str):
                results.append((key, value))
            elif isinstance(value, (list, dict)):
                results.append((key, str(value)))
        return results or [("payload", str(payload))]

    def scan(self, text: str, field_name: str = "payload") -> ScanResult:
        """Scan a single text string. Returns on first hit."""
        lower = text.lower()
        for kw in self._keywords:
            if kw in lower:
                return ScanResult(
                    clean=False,
                    threat_type="restricted_keyword",
                    matched=kw,
                    scanned_field=field_name,
                )
        for pattern in self._patterns:
            if pattern.search(text):
                return ScanResult(
                    clean=False,
                    threat_type="prompt_injection",
                    matched=pattern.pattern[:80],
                    scanned_field=field_name,
                )
        return ScanResult(clean=True)

    def scan_request(self, payload: Any, metadata: Any = None) -> ScanResult:
        """Scan all text fields of a request payload (and optionally metadata). Returns on first threat."""
        for field_name, text in self._extract_text_fields(payload):
            result = self.scan(text, field_name)
            if not result.clean:
                return result
        if metadata is not None:
            for field_name, text in self._extract_text_fields(metadata):
                result = self.scan(text, f"metadata.{field_name}")
                if not result.clean:
                    return result
        return ScanResult(clean=True)


# ---------------------------------------------------------------------------
# NIST AI RMF GOVERN-1.2 threat categories
# ---------------------------------------------------------------------------

# Category 1 — System Overrides
_NIST_SYSTEM_OVERRIDE_PATTERNS: list[re.Pattern[str]] = [
    # "Ignore previous / prior / all instructions" variants
    re.compile(
        r"ignore\s+(all\s+|previous\s+|prior\s+|above\s+|earlier\s+)?(instructions?|prompts?|context|rules?|constraints?)",
        re.IGNORECASE,
    ),
    # "Disregard / forget your instructions"
    re.compile(
        r"(disregard|forget|bypass|override)\s+(your\s+|all\s+|these\s+)?(instructions?|guidelines?|rules?|constraints?)",
        re.IGNORECASE,
    ),
    # DAN mode and variants
    re.compile(
        r"\b(do\s+anything\s+now|dan\s+mode|jailbreak\s+mode|god\s+mode|dev\s+mode|developer\s+mode|maintenance\s+mode)\b",
        re.IGNORECASE,
    ),
    # Identity / role override
    re.compile(
        r"(you\s+are\s+now\s+(in\s+)?|pretend\s+(you\s+are|to\s+be\s+)|act\s+as\s+(if\s+you\s+are\s+)?)",
        re.IGNORECASE,
    ),
    # Enable / unlock restricted modes
    re.compile(
        r"(enable|unlock|activate|turn\s+on)\s+(restricted|unrestricted|safety-off|filter-off|censorship-free)",
        re.IGNORECASE,
    ),
]

# Category 2 — Malicious Scripts: SQL injection
_NIST_SQLI_PATTERNS: list[re.Pattern[str]] = [
    # Classic OR-based tautology: ' OR '1'='1  / " OR 1=1
    re.compile(r"(\bor\b|\band\b)\s+['\"]?\s*\d+\s*=\s*\d+", re.IGNORECASE),
    re.compile(r"'\s*(or|and)\s+'.+'\s*=\s*'", re.IGNORECASE),
    # UNION SELECT statement
    re.compile(r"\bunion\b.{0,30}\bselect\b", re.IGNORECASE | re.DOTALL),
    # Stacked queries and comment-based bypasses
    re.compile(r"(;|-{2}|#)\s*(drop|alter|insert|update|delete|create|exec|execute)\b", re.IGNORECASE),
    re.compile(r";\s*(drop|alter|truncate)\s+table\b", re.IGNORECASE),
    # SLEEP / BENCHMARK (blind SQLi timing attacks)
    re.compile(r"\b(sleep|benchmark|waitfor\s+delay)\s*\(", re.IGNORECASE),
    # xp_cmdshell (MSSQL RCE)
    re.compile(r"\bxp_cmdshell\b", re.IGNORECASE),
    # Information schema probing
    re.compile(r"\binformation_schema\b", re.IGNORECASE),
]

# Category 2 — Malicious Scripts: XSS / script injection
_NIST_SCRIPT_PATTERNS: list[re.Pattern[str]] = [
    # <script>, </script>
    re.compile(r"<\s*script\b[^>]*>", re.IGNORECASE),
    re.compile(r"<\s*/\s*script\s*>", re.IGNORECASE),
    # Inline event handlers: onerror=, onload=, onclick=
    re.compile(r"\bon\w+\s*=\s*['\"]?\s*(alert|eval|fetch|document|window)", re.IGNORECASE),
    # javascript: URI
    re.compile(r"javascript\s*:", re.IGNORECASE),
    # data: URI with base64 script payload
    re.compile(r"data\s*:\s*text/html", re.IGNORECASE),
    # <iframe>, <object>, <embed> injection
    re.compile(r"<\s*(iframe|object|embed)\b[^>]*src\s*=", re.IGNORECASE),
    # document.cookie / document.write
    re.compile(r"\bdocument\s*\.\s*(cookie|write|location|domain)\b", re.IGNORECASE),
    # eval( or Function( with string arg
    re.compile(r"\b(eval|Function)\s*\(", re.IGNORECASE),
]

# NIST AI RMF tag for compliance logging
NIST_GOVERN_1_2_TAG = "NIST_GOVERN_1.2"
NIST_GOVERN_1_2_ISO_REF = "NIST AI RMF GOVERN 1.2"


class NistScrubResult(BaseModel):
    """Result of a NistScrub scan. clean=True means no NIST-categorised threats found."""

    clean: bool
    nist_tag: str | None = Field(default=None, description="NIST control tag, e.g. NIST_GOVERN_1.2")
    threat_category: str | None = Field(
        default=None,
        description="'system_override' | 'sqli' | 'script_injection'",
    )
    matched: str | None = Field(default=None, description="Pattern or keyword that triggered the block")
    scanned_field: str | None = None
    risk_pulse_emitted: bool = Field(default=False, description="True if a RiskPulse was emitted to telemetry")

    model_config = {"extra": "forbid"}


class NistScrub:
    """
    NIST AI RMF GOVERN-1.2 enforcement scanner.
    Two distinct categories:
      1. System Overrides — 'Ignore previous instructions', 'DAN mode', identity hijacking.
      2. Malicious Scripts — SQLi patterns and <script> / XSS injection.
    On any block: emits a RiskPulse tagged with NIST_GOVERN_1.2 to the telemetry stream.
    """

    def __init__(
        self,
        extra_override_patterns: list[re.Pattern[str]] | None = None,
        extra_sqli_patterns: list[re.Pattern[str]] | None = None,
        extra_script_patterns: list[re.Pattern[str]] | None = None,
        telemetry_stream: Any = None,
    ) -> None:
        self._override_patterns = _NIST_SYSTEM_OVERRIDE_PATTERNS + (extra_override_patterns or [])
        self._sqli_patterns = _NIST_SQLI_PATTERNS + (extra_sqli_patterns or [])
        self._script_patterns = _NIST_SCRIPT_PATTERNS + (extra_script_patterns or [])
        self._telemetry = telemetry_stream

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _text_fields(self, data: Any) -> list[tuple[str, str]]:
        if not isinstance(data, dict):
            return [("value", str(data))]
        out: list[tuple[str, str]] = []
        for k, v in data.items():
            if isinstance(v, str):
                out.append((k, v))
            elif isinstance(v, (list, dict)):
                out.append((k, str(v)))
        return out or [("value", str(data))]

    def _emit_risk_pulse(
        self,
        field: str,
        category: str,
        matched: str,
        correlation_id: str | None = None,
    ) -> bool:
        """Emit a RiskPulse tagged NIST_GOVERN_1.2 to the telemetry stream. Returns True if emitted."""
        if self._telemetry is None:
            return False
        try:
            from cairo_sdk.telemetry import ComplianceMetadata, EUAIActStatus, PulseSeverity, RiskPulse, _StreamEvent
            compliance = ComplianceMetadata(
                eu_ai_act_status=EUAIActStatus.HIGH,
                iso_control_reference=NIST_GOVERN_1_2_ISO_REF,
                nist_function=NIST_GOVERN_1_2_TAG,
            )
            pulse = RiskPulse(
                from_node="containment",
                to_node="blocked",
                correlation_id=correlation_id,
                compliance=compliance,
                severity=PulseSeverity.RED,
                logic_drift=False,
                metadata={
                    "nist_tag": NIST_GOVERN_1_2_TAG,
                    "threat_category": category,
                    "scanned_field": field,
                    "matched": matched[:120],
                    "timestamp_utc": datetime.now(timezone.utc).isoformat(),
                },
            )
            self._telemetry._put_nowait(_StreamEvent("risk_pulse", pulse))
            return True
        except Exception:
            return False

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def scan(
        self,
        text: str,
        field_name: str = "value",
        correlation_id: str | None = None,
    ) -> NistScrubResult:
        """Scan a single text string for NIST GOVERN-1.2 threats. Emits RiskPulse on first hit."""
        # Category 1: System Overrides
        for pattern in self._override_patterns:
            if pattern.search(text):
                emitted = self._emit_risk_pulse(
                    field=field_name,
                    category="system_override",
                    matched=pattern.pattern[:80],
                    correlation_id=correlation_id,
                )
                return NistScrubResult(
                    clean=False,
                    nist_tag=NIST_GOVERN_1_2_TAG,
                    threat_category="system_override",
                    matched=pattern.pattern[:80],
                    scanned_field=field_name,
                    risk_pulse_emitted=emitted,
                )

        # Category 2a: SQL injection
        for pattern in self._sqli_patterns:
            if pattern.search(text):
                emitted = self._emit_risk_pulse(
                    field=field_name,
                    category="sqli",
                    matched=pattern.pattern[:80],
                    correlation_id=correlation_id,
                )
                return NistScrubResult(
                    clean=False,
                    nist_tag=NIST_GOVERN_1_2_TAG,
                    threat_category="sqli",
                    matched=pattern.pattern[:80],
                    scanned_field=field_name,
                    risk_pulse_emitted=emitted,
                )

        # Category 2b: Script injection
        for pattern in self._script_patterns:
            if pattern.search(text):
                emitted = self._emit_risk_pulse(
                    field=field_name,
                    category="script_injection",
                    matched=pattern.pattern[:80],
                    correlation_id=correlation_id,
                )
                return NistScrubResult(
                    clean=False,
                    nist_tag=NIST_GOVERN_1_2_TAG,
                    threat_category="script_injection",
                    matched=pattern.pattern[:80],
                    scanned_field=field_name,
                    risk_pulse_emitted=emitted,
                )

        return NistScrubResult(clean=True)

    def scan_request(
        self,
        payload: Any,
        metadata: Any = None,
        correlation_id: str | None = None,
    ) -> NistScrubResult:
        """Scan all text fields of the request payload and optionally metadata."""
        for field_name, text in self._text_fields(payload):
            result = self.scan(text, field_name, correlation_id=correlation_id)
            if not result.clean:
                return result
        if metadata is not None:
            for field_name, text in self._text_fields(metadata):
                result = self.scan(text, f"metadata.{field_name}", correlation_id=correlation_id)
                if not result.clean:
                    return result
        return NistScrubResult(clean=True)
