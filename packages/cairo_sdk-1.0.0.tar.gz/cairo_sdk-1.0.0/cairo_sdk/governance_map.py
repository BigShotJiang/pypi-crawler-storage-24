"""
cairo_sdk/governance_map.py — AXON Compliance Engine: Regulatory Governance Map

Single source of truth that maps every CAIRO pillar and every middleware
action_type to its exact regulatory controls:

  ┌─────────────────────────────────────────────────────────────────────────┐
  │  NIST AI RMF        → Function + Categories (Govern 1.2, Measure 2.1…) │
  │  ISO 42001          → Clauses (8.1) + Annex A controls (A.8, A.9…)     │
  │  EU AI Act 2026     → Articles (Art. 5, Art. 9, Art. 15, Art. 50)      │
  │  Risk Level         → Low / Medium / High per threat severity           │
  │  Risk Mitigation $  → Representative per-incident "Saved Fine" in USD  │
  └─────────────────────────────────────────────────────────────────────────┘

Design principles
─────────────────
• All data is typed via Pydantic — zero-trust, no raw dicts shipped to DynamoDB.
• Two lookup surfaces:
    - PILLAR_GOVERNANCE_MAP   keyed by pillar name ("containment", "attestation"…)
    - ACTION_RISK_MAP         keyed by action_type (mirrors ACTION_CONTROL_MAP in
                              telemetry.py, but focuses on regulatory metadata)
• resolve_regulatory_tags()  one-shot helper used by CairoAnalyticsLogger.log_request().

CAIRO Protocol Technical Architecture v1.0.
"""

from __future__ import annotations

from enum import Enum
from typing import Any

from pydantic import BaseModel, Field


# ===========================================================================
# Risk Level
# ===========================================================================

class RiskLevel(str, Enum):
    """
    Three-tier threat severity classification used by the AXON Compliance Engine.

    Levels align with EU AI Act 2026 enforcement tiers and drive both the
    dashboard heatmap colour (red / amber / green) and the per-incident
    ``risk_mitigation_value_usd`` stored in DynamoDB.

    Attributes
    ----------
    HIGH   : "High"
        Critical threat blocked.  Mapped to EU AI Act ``prohibited_practices``
        (Art. 5) or ``high_risk_non_compliance`` (Art. 9).  Representative
        saved fine: $35 k – $50 k per incident.
    MEDIUM : "Medium"
        Significant anomaly corrected.  Mapped to Art. 9 high-risk tier or
        Art. 50 transparency tier.  Representative saved fine: $15 k – $25 k.
    LOW    : "Low"
        Routine enforcement action (schema fix, passport generation).
        Mapped to Art. 9 / Art. 50.  Representative saved fine: $2.5 k – $5 k.
    """

    LOW    = "Low"
    MEDIUM = "Medium"
    HIGH   = "High"


# ===========================================================================
# Regulatory control models — typed, validated, DynamoDB-serialisable
# ===========================================================================

class NistAiRmfEntry(BaseModel):
    """
    NIST AI Risk Management Framework (AI RMF 1.0) controls for one pillar.

    Functions map to the four core NIST AI RMF functions:
      GOVERN  — policies, accountability, culture
      MAP     — categorising AI risk context
      MEASURE — analysing, tracking, evaluating AI risk
      MANAGE  — prioritising, responding to, recovering from AI risk

    Categories use the dot notation from the NIST AI RMF Playbook
    (e.g. "Govern 1.2" = subcategory 1.2 within the GOVERN function).
    """

    functions: list[str] = Field(
        description="NIST AI RMF core functions engaged by this pillar (GOVERN/MAP/MEASURE/MANAGE)."
    )
    categories: list[str] = Field(
        description=(
            "NIST AI RMF category identifiers, e.g. 'Govern 1.2', 'Measure 2.1'. "
            "From the AI RMF Playbook subcategory numbering."
        )
    )
    subcategories: list[str] = Field(
        description="NIST CSF 2.0 subcategory IDs cross-walked to AI RMF, e.g. 'DE.CM-7', 'GV.RR-1'."
    )
    playbook_reference: str = Field(
        description="Human-readable reference to the NIST AI RMF Playbook action(s)."
    )

    model_config = {"extra": "forbid"}


class Iso42001Entry(BaseModel):
    """
    ISO/IEC 42001:2023 — Artificial Intelligence Management System controls.

    Clauses reference the normative body of the standard (§8 = Operation).
    Annex A controls reference the AI-specific control set in Annex A.
    """

    clauses: list[str] = Field(
        description="ISO 42001 normative clause references, e.g. 'Clause 8.1 Operational planning'."
    )
    annex_controls: list[str] = Field(
        description="ISO 42001 Annex A control identifiers, e.g. 'Annex A.8.2', 'Annex A.9.4'."
    )
    control_objective: str = Field(
        description="Plain-language statement of the ISO 42001 control objective."
    )

    model_config = {"extra": "forbid"}


class EuAiActEntry(BaseModel):
    """
    EU AI Act 2026 — enforceable articles applicable to this pillar.

    Article 5  — Prohibited practices (highest fine tier: €35M or 7% turnover).
    Article 9  — Risk management for high-risk AI systems (€15M or 3%).
    Article 15 — Accuracy, robustness & cybersecurity for high-risk AI.
    Article 50 — Transparency obligations (€7.5M or 1%).
    """

    articles: list[str] = Field(
        description="Applicable EU AI Act articles, e.g. ['Article 5', 'Article 15']."
    )
    enforcement_tier: str = Field(
        description=(
            "Maps to EU_FINES_2026 key in telemetry.py: "
            "'prohibited_practices' | 'high_risk_non_compliance' | 'transparency_violation'."
        )
    )
    fine_summary: str = Field(
        description="One-line summary of the applicable penalty cap."
    )

    model_config = {"extra": "forbid"}


class PillarGovernanceEntry(BaseModel):
    """
    Full regulatory governance record for one CAIRO pillar.
    Stored in PILLAR_GOVERNANCE_MAP and exported to every DynamoDB log entry
    that names a pillar (via CairoAnalyticsLogger.log_request).
    """

    pillar: str = Field(description="CAIRO pillar identifier.")
    description: str = Field(description="What this pillar enforces.")
    nist_ai_rmf: NistAiRmfEntry
    iso_42001: Iso42001Entry
    eu_ai_act: EuAiActEntry
    risk_level: RiskLevel = Field(
        description="Default risk level for threats handled by this pillar."
    )
    risk_mitigation_value_usd: float = Field(
        description=(
            "Representative 'Saved Fine' in USD for a single incident blocked by this pillar. "
            "Derived from EU AI Act per-incident enforcement guidance (not the annual cap). "
            "Used in DynamoDB log entries as risk_mitigation_value."
        )
    )

    model_config = {"extra": "forbid"}


class ActionRiskEntry(BaseModel):
    """
    Per-action-type risk configuration — more granular than the pillar-level entry.
    ACTION_RISK_MAP is keyed by action_type (same keys as ACTION_CONTROL_MAP in telemetry.py).
    """

    action_type: str
    pillar: str
    risk_level: RiskLevel
    risk_mitigation_value_usd: float = Field(
        description="Representative per-incident 'Saved Fine' in USD for this specific action."
    )
    nist_categories: list[str] = Field(
        description="Most specific NIST AI RMF category IDs for this action."
    )
    iso_annex_controls: list[str] = Field(
        description="Most specific ISO 42001 Annex A control IDs for this action."
    )
    eu_articles: list[str] = Field(
        description="Most specific EU AI Act articles for this action."
    )
    rationale: str = Field(
        description="Why this risk level and mitigation value were chosen."
    )

    model_config = {"extra": "forbid"}


class RegulatoryTags(BaseModel):
    """
    Resolved set of regulatory tags that is attached to every DynamoDB log entry
    produced by CairoAnalyticsLogger.log_request().

    Fields map directly to top-level DynamoDB attributes for easy querying:
      GSI on risk_level   → "give me all HIGH events this week"
      GSI on eu_article   → "show Art. 50 incidents for audit"
    """

    pillar: str | None = Field(default=None)
    action_type: str | None = Field(default=None)

    # NIST AI RMF
    nist_functions: list[str] = Field(default_factory=list)
    nist_categories: list[str] = Field(
        default_factory=list,
        description="e.g. ['Govern 1.2', 'Measure 2.1']",
    )
    nist_subcategories: list[str] = Field(
        default_factory=list,
        description="e.g. ['DE.CM-7', 'GV.RR-1']",
    )

    # ISO 42001
    iso_clauses: list[str] = Field(
        default_factory=list,
        description="e.g. ['Clause 8.1']",
    )
    iso_annex_controls: list[str] = Field(
        default_factory=list,
        description="e.g. ['Annex A.8.2', 'Annex A.8.4']",
    )

    # EU AI Act
    eu_articles: list[str] = Field(
        default_factory=list,
        description="e.g. ['Article 5', 'Article 15']",
    )
    eu_enforcement_tier: str = Field(default="high_risk_non_compliance")

    # AXON risk signal
    risk_level: str = Field(
        default=RiskLevel.MEDIUM,
        description="'Low' | 'Medium' | 'High' — used for dashboard heatmap colouring.",
    )
    risk_mitigation_value_usd: float = Field(
        default=0.0,
        description="Representative 'Saved Fine' in USD for this single incident.",
    )

    model_config = {"extra": "forbid"}


# ===========================================================================
# PILLAR_GOVERNANCE_MAP — keyed by CAIRO pillar name
# ===========================================================================

PILLAR_GOVERNANCE_MAP: dict[str, PillarGovernanceEntry] = {

    # ── Pillar 1: Containment ──────────────────────────────────────────────
    "containment": PillarGovernanceEntry(
        pillar="containment",
        description=(
            "Prompt injection detection and restricted keyword blocking. "
            "Prevents adversarial inputs from overriding system instructions or "
            "extracting confidential data."
        ),
        nist_ai_rmf=NistAiRmfEntry(
            functions=["GOVERN", "DETECT"],
            categories=["Govern 1.2", "Measure 2.1"],
            subcategories=["GV.RR-1", "DE.CM-7"],
            playbook_reference=(
                "NIST AI RMF Playbook — GOVERN 1.2: Establish policies for identifying "
                "and managing risks from adversarial inputs. "
                "MEASURE 2.1: Evaluate AI systems in deployment context for injection risk."
            ),
        ),
        iso_42001=Iso42001Entry(
            clauses=["Clause 8.1"],
            annex_controls=["Annex A.8.2"],
            control_objective=(
                "Clause 8.1 (Operational planning and control): Implement controls to "
                "manage risks during AI system operation. "
                "Annex A.8.2: AI system development and acquisition — integrity controls "
                "preventing manipulation of system prompts."
            ),
        ),
        eu_ai_act=EuAiActEntry(
            articles=["Article 5", "Article 15"],
            enforcement_tier="prohibited_practices",
            fine_summary=(
                "Article 5 — Prohibited AI Practices: up to €35M or 7% of global annual turnover. "
                "Article 15 — Accuracy, robustness & cybersecurity for high-risk AI systems."
            ),
        ),
        risk_level=RiskLevel.HIGH,
        risk_mitigation_value_usd=50_000.0,
    ),

    # ── Pillar 2: Attestation ──────────────────────────────────────────────
    "attestation": PillarGovernanceEntry(
        pillar="attestation",
        description=(
            "Validates tenant_id, user_role, and request purpose declaration. "
            "Enforces zero-trust access control before any agent execution."
        ),
        nist_ai_rmf=NistAiRmfEntry(
            functions=["GOVERN", "PROTECT"],
            categories=["Govern 1.2", "Measure 2.1"],
            subcategories=["GV.RR-1", "PR.AA-1"],
            playbook_reference=(
                "NIST AI RMF Playbook — GOVERN 1.2: Define and enforce roles and "
                "responsibilities for AI system access. "
                "MEASURE 2.1: Assess trustworthiness of AI system access paths."
            ),
        ),
        iso_42001=Iso42001Entry(
            clauses=["Clause 8.1"],
            annex_controls=["Annex A.8", "Annex A.9.4"],
            control_objective=(
                "Clause 8.1: Controls for AI system access lifecycle. "
                "Annex A.8 (AI system impact assessment): Validate requester context before execution. "
                "Annex A.9.4: Access control — restrict AI capability to authorised roles only."
            ),
        ),
        eu_ai_act=EuAiActEntry(
            articles=["Article 9", "Article 15"],
            enforcement_tier="high_risk_non_compliance",
            fine_summary=(
                "Article 9 — Risk management for high-risk AI systems: up to €15M or 3% turnover. "
                "Article 15 — Cybersecurity requirements for high-risk AI."
            ),
        ),
        risk_level=RiskLevel.HIGH,
        risk_mitigation_value_usd=35_000.0,
    ),

    # ── Pillar 3: Interception ─────────────────────────────────────────────
    "interception": PillarGovernanceEntry(
        pillar="interception",
        description=(
            "Logic Drift Detector — monitors the agent's LangGraph node path against "
            "the pre-approved Golden Path. Injects corrective constraints on deviation."
        ),
        nist_ai_rmf=NistAiRmfEntry(
            functions=["MEASURE", "MANAGE"],
            categories=["Measure 2.1", "Govern 1.2"],
            subcategories=["DE.AE-3", "RS.MI-1"],
            playbook_reference=(
                "NIST AI RMF Playbook — MEASURE 2.1: Evaluate AI systems in context; "
                "detect when the system deviates from expected behaviour. "
                "MANAGE 2.4: Apply corrective constraints in response to detected drift."
            ),
        ),
        iso_42001=Iso42001Entry(
            clauses=["Clause 8.1"],
            annex_controls=["Annex A.8", "Annex A.8.2"],
            control_objective=(
                "Clause 8.1: Operational monitoring of AI system execution paths. "
                "Annex A.8: AI system impact assessment during runtime. "
                "Annex A.8.2: Controls to ensure AI behaves within approved boundaries."
            ),
        ),
        eu_ai_act=EuAiActEntry(
            articles=["Article 9", "Article 15"],
            enforcement_tier="high_risk_non_compliance",
            fine_summary=(
                "Article 9 — Ongoing risk management obligation for high-risk AI. "
                "Article 15 — Robustness and reliability requirements."
            ),
        ),
        risk_level=RiskLevel.MEDIUM,
        risk_mitigation_value_usd=25_000.0,
    ),

    # ── Pillar 4: Resilience ───────────────────────────────────────────────
    "resilience": PillarGovernanceEntry(
        pillar="resilience",
        description=(
            "PII scrubber (AuditReadyScrubber) — detects and redacts SSN, credit cards, "
            "emails, and Indian phone numbers from AI outputs before delivery. "
            "Also performs schema validation and system-string hardening."
        ),
        nist_ai_rmf=NistAiRmfEntry(
            functions=["GOVERN", "PROTECT"],
            categories=["Govern 1.2", "Measure 2.1"],
            subcategories=["PR.DS-1", "DE.AE-4"],
            playbook_reference=(
                "NIST AI RMF Playbook — GOVERN 1.2: Data protection policies for AI outputs. "
                "MEASURE 2.1: Assess and verify that AI outputs meet privacy requirements."
            ),
        ),
        iso_42001=Iso42001Entry(
            clauses=["Clause 8.1"],
            annex_controls=["Annex A.8", "Annex A.8.4"],
            control_objective=(
                "Clause 8.1: Operational controls to prevent PII leakage in AI outputs. "
                "Annex A.8 (AI system impact assessment): Evaluate data handling risks. "
                "Annex A.8.4: Incident communication — log every PII redaction as a "
                "security alert tagged for ISO 42001 audit."
            ),
        ),
        eu_ai_act=EuAiActEntry(
            articles=["Article 9", "Article 15"],
            enforcement_tier="high_risk_non_compliance",
            fine_summary=(
                "Article 9 — Risk management including data integrity for high-risk AI. "
                "Article 15 — Accuracy and data quality obligations."
            ),
        ),
        risk_level=RiskLevel.HIGH,
        risk_mitigation_value_usd=50_000.0,
    ),

    # ── Pillar 5: Output-Logic ─────────────────────────────────────────────
    "output_logic": PillarGovernanceEntry(
        pillar="output_logic",
        description=(
            "EU AI Act Art. 50 transparency label injection. Generates forensic SHA-256 "
            "compliance passport. Enforces output schema and perceptible AI disclosure."
        ),
        nist_ai_rmf=NistAiRmfEntry(
            functions=["GOVERN", "MANAGE"],
            categories=["Govern 1.2", "Measure 2.1"],
            subcategories=["GV.OC-2", "GV.RM-2"],
            playbook_reference=(
                "NIST AI RMF Playbook — GOVERN 1.2: Transparency and explainability policies "
                "for AI-generated outputs delivered to end users. "
                "MEASURE 2.1: Evidence collection for audit and accountability."
            ),
        ),
        iso_42001=Iso42001Entry(
            clauses=["Clause 8.1"],
            annex_controls=["Annex A.8", "Annex A.8.5"],
            control_objective=(
                "Clause 8.1: Operational controls for AI system output transparency. "
                "Annex A.8 (AI system impact assessment): Ensure outputs are identifiable "
                "as AI-generated. "
                "Annex A.8.5: Documented proof of controls applied per interaction "
                "(the $5,000 Forensic Integrity Document)."
            ),
        ),
        eu_ai_act=EuAiActEntry(
            articles=["Article 15", "Article 50"],
            enforcement_tier="transparency_violation",
            fine_summary=(
                "Article 50 — Transparency obligation: disclose AI interaction to end users; "
                "up to €7.5M or 1% of global annual turnover. "
                "Article 15 — Output accuracy and cybersecurity for high-risk AI."
            ),
        ),
        risk_level=RiskLevel.MEDIUM,
        risk_mitigation_value_usd=15_000.0,
    ),
}


# ===========================================================================
# ACTION_RISK_MAP — per-action granularity (keyed by action_type)
# Mirrors ACTION_CONTROL_MAP in telemetry.py — adds risk signal fields.
# ===========================================================================

ACTION_RISK_MAP: dict[str, ActionRiskEntry] = {

    # Pillar 1 — Containment
    "prompt_injection_blocked": ActionRiskEntry(
        action_type="prompt_injection_blocked",
        pillar="containment",
        risk_level=RiskLevel.HIGH,
        risk_mitigation_value_usd=50_000.0,
        nist_categories=["Govern 1.2", "Measure 2.1"],
        iso_annex_controls=["Annex A.8.2"],
        eu_articles=["Article 5", "Article 15"],
        rationale=(
            "Prompt injection enabling unauthorised system override is a Prohibited Practice "
            "under EU AI Act Art. 5 — single-incident exposure up to €35M."
        ),
    ),
    "containment_blocked": ActionRiskEntry(
        action_type="containment_blocked",
        pillar="containment",
        risk_level=RiskLevel.HIGH,
        risk_mitigation_value_usd=50_000.0,
        nist_categories=["Govern 1.2", "Measure 2.1"],
        iso_annex_controls=["Annex A.8.2"],
        eu_articles=["Article 5", "Article 15"],
        rationale=(
            "Scope/keyword/size violation blocked — same prohibited-practice tier as "
            "prompt injection: Art. 5 maximum fine applies."
        ),
    ),

    # Pillar 2 — Attestation
    "attestation_failed": ActionRiskEntry(
        action_type="attestation_failed",
        pillar="attestation",
        risk_level=RiskLevel.HIGH,
        risk_mitigation_value_usd=35_000.0,
        nist_categories=["Govern 1.2", "Measure 2.1"],
        iso_annex_controls=["Annex A.8", "Annex A.9.4"],
        eu_articles=["Article 9", "Article 15"],
        rationale=(
            "Identity/role mismatch on a high-risk AI system access path. "
            "Art. 9 mandates continuous risk management; a breach triggers up to €15M."
        ),
    ),

    # Pillar 3 — Interception
    "logic_drift_blocked": ActionRiskEntry(
        action_type="logic_drift_blocked",
        pillar="interception",
        risk_level=RiskLevel.MEDIUM,
        risk_mitigation_value_usd=25_000.0,
        nist_categories=["Measure 2.1", "Govern 1.2"],
        iso_annex_controls=["Annex A.8", "Annex A.8.2"],
        eu_articles=["Article 9", "Article 15"],
        rationale=(
            "Golden Path deviation detected and corrected — potential Art. 9 high-risk "
            "non-compliance prevented. Medium risk: drift detected early before output stage."
        ),
    ),

    # Pillar 4 — Resilience
    "pii_blocked": ActionRiskEntry(
        action_type="pii_blocked",
        pillar="resilience",
        risk_level=RiskLevel.HIGH,
        risk_mitigation_value_usd=50_000.0,
        nist_categories=["Govern 1.2", "Measure 2.1"],
        iso_annex_controls=["Annex A.8", "Annex A.8.4"],
        eu_articles=["Article 9", "Article 15"],
        rationale=(
            "PII (SSN / credit card / phone number) in AI output constitutes a data breach "
            "under GDPR and Indian DPDP Act. Art. 9 high-risk AI data quality obligation "
            "breached — €50 k is a conservative per-incident estimate."
        ),
    ),
    "schema_validation_blocked": ActionRiskEntry(
        action_type="schema_validation_blocked",
        pillar="resilience",
        risk_level=RiskLevel.LOW,
        risk_mitigation_value_usd=5_000.0,
        nist_categories=["Measure 2.1", "Govern 1.2"],
        iso_annex_controls=["Annex A.8", "Annex A.8.5"],
        eu_articles=["Article 9", "Article 15"],
        rationale=(
            "Schema/integrity violation — fallback applied. Low severity because content "
            "was not delivered; saved fine reflects avoided reliability non-compliance."
        ),
    ),

    # Pillar 5 — Output-Logic
    "transparency_banner_added": ActionRiskEntry(
        action_type="transparency_banner_added",
        pillar="output_logic",
        risk_level=RiskLevel.MEDIUM,
        risk_mitigation_value_usd=15_000.0,
        nist_categories=["Govern 1.2", "Measure 2.1"],
        iso_annex_controls=["Annex A.8", "Annex A.8.5"],
        eu_articles=["Article 15", "Article 50"],
        rationale=(
            "Art. 50 perceptible label injected — avoids transparency violation. "
            "€7.5M is the Art. 50 cap; $15 k is a conservative per-interaction estimate "
            "used for dashboard display."
        ),
    ),
    "compliance_passport_generated": ActionRiskEntry(
        action_type="compliance_passport_generated",
        pillar="output_logic",
        risk_level=RiskLevel.LOW,
        risk_mitigation_value_usd=2_500.0,
        nist_categories=["Govern 1.2", "Measure 2.1"],
        iso_annex_controls=["Annex A.8", "Annex A.8.5"],
        eu_articles=["Article 15", "Article 50"],
        rationale=(
            "Forensic Integrity Document generated — evidences all controls applied. "
            "Saves legal costs in audit / enforcement proceedings."
        ),
    ),
}

# Fallback used when an unknown action_type / pillar is supplied.
_FALLBACK_PILLAR = "containment"
_FALLBACK_ACTION = ACTION_RISK_MAP["containment_blocked"]


# ===========================================================================
# resolve_regulatory_tags() — one-shot lookup for CairoAnalyticsLogger
# ===========================================================================

def resolve_regulatory_tags(
    pillar: str | None = None,
    action_type: str | None = None,
) -> RegulatoryTags:
    """
    Resolve the full set of regulatory tags for a given pillar or action_type.

    This is the single entry point used by ``CairoAnalyticsLogger.log_request()``
    to auto-populate every DynamoDB compliance event with its exact NIST AI RMF,
    ISO 42001, and EU AI Act control identifiers.

    An external auditor reading a CairoAnalytics DynamoDB item can use the
    ``regulatory_tags`` dict (produced by this function) to trace every
    enforcement action back to its specific regulatory control — without
    needing access to the CAIRO source code.

    Resolution Precedence
    ---------------------
    1. ``action_type`` known in ``ACTION_RISK_MAP``
           Uses the most granular, action-specific control set.
           Example: ``"pii_blocked"`` → ``Annex A.8.4``, ``Article 9``, ``$50 k``.
    2. ``pillar`` known in ``PILLAR_GOVERNANCE_MAP``
           Falls back to the pillar-level defaults (broader ISO controls).
           Example: ``pillar="resilience"`` → ``Annex A.8``, ``Article 9``, ``$50 k``.
    3. Neither supplied or both unknown
           Absolute fallback: containment-pillar defaults.  Should never be
           reached in normal middleware operation.

    Parameters
    ----------
    pillar : str or None
        CAIRO pillar identifier: ``"containment"`` | ``"attestation"`` |
        ``"interception"`` | ``"resilience"`` | ``"output_logic"``.
        Ignored if a matching ``action_type`` is found in step 1.
    action_type : str or None
        Action key from ``ACTION_RISK_MAP`` (e.g. ``"prompt_injection_blocked"``,
        ``"pii_blocked"``, ``"transparency_banner_added"``).

    Returns
    -------
    RegulatoryTags
        Validated Pydantic model containing all NIST / ISO / EU fields, risk
        level, and the representative per-incident ``risk_mitigation_value_usd``.
        Call ``.model_dump()`` to serialise for DynamoDB storage.

    Examples
    --------
    >>> tags = resolve_regulatory_tags(action_type="pii_blocked")
    >>> tags.risk_level
    'High'
    >>> tags.iso_annex_controls
    ['Annex A.8', 'Annex A.8.4']
    >>> tags.eu_articles
    ['Article 9', 'Article 15']
    >>> tags.risk_mitigation_value_usd
    50000.0

    >>> tags = resolve_regulatory_tags(pillar="output_logic")
    >>> tags.eu_articles
    ['Article 15', 'Article 50']
    """
    action_entry: ActionRiskEntry | None = ACTION_RISK_MAP.get(action_type or "")
    pillar_entry: PillarGovernanceEntry | None = PILLAR_GOVERNANCE_MAP.get(
        pillar or (action_entry.pillar if action_entry else ""),
        PILLAR_GOVERNANCE_MAP[_FALLBACK_PILLAR],
    )

    if action_entry is not None:
        return RegulatoryTags(
            pillar=action_entry.pillar,
            action_type=action_entry.action_type,
            nist_functions=pillar_entry.nist_ai_rmf.functions,
            nist_categories=action_entry.nist_categories,
            nist_subcategories=pillar_entry.nist_ai_rmf.subcategories,
            iso_clauses=pillar_entry.iso_42001.clauses,
            iso_annex_controls=action_entry.iso_annex_controls,
            eu_articles=action_entry.eu_articles,
            eu_enforcement_tier=pillar_entry.eu_ai_act.enforcement_tier,
            risk_level=action_entry.risk_level.value,
            risk_mitigation_value_usd=action_entry.risk_mitigation_value_usd,
        )

    if pillar_entry is not None:
        return RegulatoryTags(
            pillar=pillar_entry.pillar,
            action_type=action_type,
            nist_functions=pillar_entry.nist_ai_rmf.functions,
            nist_categories=pillar_entry.nist_ai_rmf.categories,
            nist_subcategories=pillar_entry.nist_ai_rmf.subcategories,
            iso_clauses=pillar_entry.iso_42001.clauses,
            iso_annex_controls=pillar_entry.iso_42001.annex_controls,
            eu_articles=pillar_entry.eu_ai_act.articles,
            eu_enforcement_tier=pillar_entry.eu_ai_act.enforcement_tier,
            risk_level=pillar_entry.risk_level.value,
            risk_mitigation_value_usd=pillar_entry.risk_mitigation_value_usd,
        )

    # Absolute fallback — should never be reached in normal operation.
    fallback = PILLAR_GOVERNANCE_MAP[_FALLBACK_PILLAR]
    return RegulatoryTags(
        pillar=_FALLBACK_PILLAR,
        action_type=action_type,
        nist_functions=fallback.nist_ai_rmf.functions,
        nist_categories=fallback.nist_ai_rmf.categories,
        nist_subcategories=fallback.nist_ai_rmf.subcategories,
        iso_clauses=fallback.iso_42001.clauses,
        iso_annex_controls=fallback.iso_42001.annex_controls,
        eu_articles=fallback.eu_ai_act.articles,
        eu_enforcement_tier=fallback.eu_ai_act.enforcement_tier,
        risk_level=fallback.risk_level.value,
        risk_mitigation_value_usd=fallback.risk_mitigation_value_usd,
    )


def all_pillar_names() -> list[str]:
    """
    Return all registered CAIRO pillar identifiers in definition order.

    Intended for use in dashboard dropdowns, validation logic, and automated
    compliance checklists.  The returned list always matches the keys of
    ``PILLAR_GOVERNANCE_MAP``.

    Returns
    -------
    list[str]
        e.g. ``["containment", "attestation", "interception",
        "resilience", "output_logic"]``.

    Examples
    --------
    >>> "containment" in all_pillar_names()
    True
    >>> len(all_pillar_names())
    5
    """
    return list(PILLAR_GOVERNANCE_MAP.keys())


def all_action_types() -> list[str]:
    """
    Return all registered ``action_type`` keys in definition order.

    Use this to validate that a given ``action_type`` string is known before
    passing it to ``resolve_regulatory_tags()``.  Unknown action types trigger
    the containment fallback, which may be intentional but is worth an audit log.

    Returns
    -------
    list[str]
        e.g. ``["prompt_injection_blocked", "containment_blocked",
        "attestation_failed", "logic_drift_blocked", "pii_blocked",
        "schema_validation_blocked", "transparency_banner_added",
        "compliance_passport_generated"]``.

    Examples
    --------
    >>> "pii_blocked" in all_action_types()
    True
    >>> len(all_action_types())
    8
    """
    return list(ACTION_RISK_MAP.keys())


def governance_report() -> dict[str, Any]:
    """
    Return the complete AXON governance map as a JSON-serialisable dict.

    Suitable for embedding in the Forensic Integrity Document, exposing via
    the ``GET /dashboard`` FastAPI endpoint, or exporting as a standalone
    compliance evidence artefact.

    An external auditor can use this output to verify:
      * Which CAIRO pillars are active and what each enforces.
      * The exact NIST AI RMF, ISO 42001, and EU AI Act controls they defend.
      * The risk classification and representative fine value for each action.

    Returns
    -------
    dict
        Top-level keys:

        ``schema_version``
            Semantic version of this report format (currently ``"1.0"``).
        ``description``
            Human-readable label.
        ``frameworks_covered``
            List of regulatory frameworks enforced.
        ``pillars``
            ``{pillar_name: PillarGovernanceEntry.model_dump()}`` for all 5 pillars.
        ``action_risk_map``
            ``{action_type: ActionRiskEntry.model_dump()}`` for all 8 action types.

    Examples
    --------
    >>> report = governance_report()
    >>> report["schema_version"]
    '1.0'
    >>> list(report["pillars"].keys())
    ['containment', 'attestation', 'interception', 'resilience', 'output_logic']
    """
    return {
        "schema_version": "1.0",
        "description": "AXON Compliance Engine — CAIRO Pillar Regulatory Governance Map",
        "frameworks_covered": [
            "NIST AI RMF 1.0",
            "ISO/IEC 42001:2023",
            "EU AI Act 2026",
            "Indian DPDP Act (via Pillar 4 Resilience)",
        ],
        "pillars": {
            name: entry.model_dump()
            for name, entry in PILLAR_GOVERNANCE_MAP.items()
        },
        "action_risk_map": {
            action: entry.model_dump()
            for action, entry in ACTION_RISK_MAP.items()
        },
    }
