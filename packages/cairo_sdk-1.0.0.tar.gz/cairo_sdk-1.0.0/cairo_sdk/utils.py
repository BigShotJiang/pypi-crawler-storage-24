"""
cairo_sdk/utils.py — AXON Shared Formatting Utilities

Single source of truth for constants and pure-function helpers used by
dash_app.py, reports.py, and analytics.py.

Moving this logic here breaks the implicit coupling where each file maintained
its own copy of the conversion rate, pillar ordering, and string-formatting
rules — which could silently drift out of sync in production.

Public symbols
──────────────
  Constants
    USD_TO_INR_RATE     Exchange rate used for INR display (update quarterly).
    PILLAR_ORDER        Canonical display order for CAIRO pillars.
    RISK_COLOURS_HEX    Hex colour strings for High / Medium / Low risk badges
                        (Dash dashboard, HTML, and any web output).

  Formatting helpers (all are pure functions — no side effects, no I/O)
    format_pillar_name(pillar)        "output_logic"  → "Output Logic"
    format_action_type(action)        "pii_blocked"   → "Pii Blocked"
    format_timestamp_short(ts)        ISO-8601        → "YYYY-MM-DD HH:MM:SS"
    format_usd(amount)                50000.0         → "$50,000"
    format_inr(amount_usd)            50000.0         → "₹41.75 L"
    join_tags(items, sep)             ["A", "B"]      → "A | B"
    risk_level_colour(risk)           "High"          → "#b91c1c"

CAIRO Protocol Technical Architecture v1.0.
"""

from __future__ import annotations

# ===========================================================================
# Constants
# ===========================================================================

USD_TO_INR_RATE: float = 83.5
"""
USD → INR conversion rate used throughout the AXON dashboard and reports.

This is a representative rate; update quarterly to keep INR figures accurate
for client-facing Forensic Integrity Documents.
"""

PILLAR_ORDER: list[str] = [
    "Containment",
    "Attestation",
    "Interception",
    "Resilience",
    "Output Logic",
]
"""
Canonical display order for the five CAIRO pillars.

Used by the dashboard bar chart and the PDF Pillar Analysis table so that
pillars always appear in architectural execution order (pre-agent → post-agent).
"""

RISK_COLOURS_HEX: dict[str, str] = {
    "High":   "#b91c1c",   # Tailwind red-700
    "Medium": "#d97706",   # Tailwind amber-600
    "Low":    "#166534",   # Tailwind green-800
}
"""
Hex colour strings for the three AXON risk levels.

Chosen from the Tailwind CSS palette to be distinguishable on both light and
dark backgrounds and to meet WCAG 2.1 AA contrast ratios against white text.
These values are the single source of truth — dash_app.py, reports.py, and
any future web output should import from here rather than re-defining colours.
"""


# ===========================================================================
# Formatting helpers
# ===========================================================================

def format_pillar_name(pillar: str) -> str:
    """
    Convert an internal pillar identifier to a human-readable display name.

    Parameters
    ----------
    pillar : str
        Snake-case pillar identifier as stored in DynamoDB, e.g.
        ``"containment"``, ``"output_logic"``.

    Returns
    -------
    str
        Title-cased, space-separated name, e.g. ``"Output Logic"``.

    Examples
    --------
    >>> format_pillar_name("output_logic")
    'Output Logic'
    >>> format_pillar_name("containment")
    'Containment'
    """
    return pillar.replace("_", " ").title()


def format_action_type(action: str) -> str:
    """
    Convert an internal action_type key to a human-readable label.

    Parameters
    ----------
    action : str
        Snake-case action type as stored in DynamoDB, e.g.
        ``"prompt_injection_blocked"``, ``"pii_blocked"``.

    Returns
    -------
    str
        Title-cased, space-separated label truncated to 40 characters to fit
        dashboard table cells, e.g. ``"Prompt Injection Blocked"``.

    Examples
    --------
    >>> format_action_type("prompt_injection_blocked")
    'Prompt Injection Blocked'
    >>> format_action_type("transparency_banner_added")
    'Transparency Banner Added'
    """
    return action.replace("_", " ").title()[:40]


def format_timestamp_short(ts: str) -> str:
    """
    Shorten an ISO-8601 timestamp to a display-friendly ``YYYY-MM-DD HH:MM:SS``
    string.

    Parameters
    ----------
    ts : str
        ISO-8601 timestamp, e.g. ``"2026-03-07T10:30:00.000+00:00"``.
        Empty strings and ``None``-like values return the fallback ``"—"``.

    Returns
    -------
    str
        First 19 characters of the timestamp with the ``T`` separator replaced
        by a space, e.g. ``"2026-03-07 10:30:00"``.

    Examples
    --------
    >>> format_timestamp_short("2026-03-07T10:30:00.000+00:00")
    '2026-03-07 10:30:00'
    >>> format_timestamp_short("")
    '\u2014'
    """
    if not ts:
        return "\u2014"
    return ts[:19].replace("T", " ")


def format_usd(amount: float) -> str:
    """
    Format a USD monetary amount as a human-readable string.

    Parameters
    ----------
    amount : float
        Amount in US dollars, e.g. ``50000.0``.

    Returns
    -------
    str
        Comma-separated integer representation prefixed with ``$``,
        e.g. ``"$50,000"``.

    Examples
    --------
    >>> format_usd(50000.0)
    '$50,000'
    >>> format_usd(7_500_000)
    '$7,500,000'
    """
    return f"${amount:,.0f}"


def format_inr(amount_usd: float, rate: float = USD_TO_INR_RATE) -> str:
    """
    Convert a USD amount to INR and format using Indian number system notation.

    Notation thresholds
    -------------------
    ≥ 1 Crore  (10,000,000 INR)  → ``"₹X.X Cr"``
    ≥ 1 Lakh   (100,000 INR)     → ``"₹X.X L"``
    < 1 Lakh                      → ``"₹X,XXX"``

    Parameters
    ----------
    amount_usd : float
        Amount in US dollars to convert.
    rate : float, optional
        USD → INR conversion rate.  Defaults to ``USD_TO_INR_RATE`` (83.5).

    Returns
    -------
    str
        INR-formatted string, e.g. ``"₹41.75 L"`` for $50,000 at 83.5 rate.

    Examples
    --------
    >>> format_inr(50_000)
    '₹41.8 L'
    >>> format_inr(500_000)
    '₹4.2 Cr'
    """
    inr = amount_usd * rate
    if inr >= 1_00_00_000:                # 1 crore
        return f"\u20b9{inr / 1_00_00_000:.1f} Cr"
    if inr >= 1_00_000:                    # 1 lakh
        return f"\u20b9{inr / 1_00_000:.1f} L"
    return f"\u20b9{inr:,.0f}"


def join_tags(items: list[str] | None, sep: str = " | ") -> str:
    """
    Join a list of regulatory tag strings for single-cell display.

    Parameters
    ----------
    items : list[str] or None
        Tag strings, e.g. ``["Article 5", "Article 15"]``.
        Returns ``"—"`` for empty lists and ``None``.
    sep : str, optional
        Separator between items.  Defaults to ``" | "``.

    Returns
    -------
    str
        Joined string, e.g. ``"Article 5 | Article 15"``, or ``"—"`` if empty.

    Examples
    --------
    >>> join_tags(["Govern 1.2", "Measure 2.1"])
    'Govern 1.2 | Measure 2.1'
    >>> join_tags([])
    '\u2014'
    >>> join_tags(None)
    '\u2014'
    """
    if not items:
        return "\u2014"
    return sep.join(items)


def risk_level_colour(risk: str) -> str:
    """
    Return the hex colour string for a given risk level.

    Parameters
    ----------
    risk : str
        ``"High"``, ``"Medium"``, or ``"Low"``.  Unknown values return the
        muted grey fallback ``"#64748b"``.

    Returns
    -------
    str
        Hex colour, e.g. ``"#b91c1c"`` for ``"High"``.

    Examples
    --------
    >>> risk_level_colour("High")
    '#b91c1c'
    >>> risk_level_colour("unknown")
    '#64748b'
    """
    return RISK_COLOURS_HEX.get(risk, "#64748b")
