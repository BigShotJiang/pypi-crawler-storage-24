"""
Pillar 4 — Resilience Hardening.
Schema Validator: ensures AI response is not empty and does not contain
sensitive system strings (DEBUG:, INTERNAL_ERROR, and others).
Failures activate fallback / fail-closed logic in the ResiliencePillar.
CAIRO Protocol Technical Architecture v1.0.
"""

from __future__ import annotations

import re
from typing import Any

from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Default blocked system strings (exact substring match, case-sensitive)
# ---------------------------------------------------------------------------

DEFAULT_BLOCKED_SYSTEM_STRINGS: list[str] = [
    "DEBUG:",
    "INTERNAL_ERROR",
    "INTERNAL ERROR",
    "Traceback (most recent call last)",
    "Traceback:",
    "Stack trace:",
    "SQLException",
    "NullPointerException",
    "System.Exception",
    "FATAL:",
    "CRITICAL:",
    "SECRET_KEY",
    "API_KEY=",
    "Authorization: Bearer",
    "-----BEGIN",          # Private key / cert headers
    "Password=",
    "password=",
]

# Regex patterns for structured leaks (env vars, connection strings, etc.)
_LEAK_PATTERNS: list[re.Pattern[str]] = [
    re.compile(r"\b[A-Z_]{4,}=([\'\"])[^\1]{6,}\1", re.IGNORECASE),   # KEY='value'
    re.compile(r"(jdbc|mysql|postgres|mongodb|redis)://\S+", re.IGNORECASE),
    re.compile(r"Bearer\s+[A-Za-z0-9\-_\.]{20,}", re.IGNORECASE),     # Bearer tokens
    re.compile(r"\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b"),                  # IP addresses in responses
]


# ---------------------------------------------------------------------------
# Schema
# ---------------------------------------------------------------------------

class ResponseValidationResult(BaseModel):
    """Result of the response schema validation."""

    valid: bool = Field(description="True iff response passes all schema checks")
    reason: str | None = Field(default=None)
    violated_check: str | None = Field(default=None, description="Name of the check that failed")

    model_config = {"extra": "forbid"}


class HardeningPolicy(BaseModel):
    """Policy for resilience hardening: empty-check, blocked strings, leak patterns."""

    allow_empty_payload: bool = Field(
        default=False,
        description="If False, reject responses that have an empty payload dict",
    )
    blocked_system_strings: list[str] = Field(
        default_factory=lambda: list(DEFAULT_BLOCKED_SYSTEM_STRINGS),
        description="Substrings that must never appear in any response text field",
    )
    enable_leak_pattern_scan: bool = Field(
        default=True,
        description="Run regex-based leak-pattern scan on response text fields",
    )
    scan_metadata: bool = Field(
        default=False,
        description="Also scan response.metadata fields (default: only payload)",
    )

    model_config = {"extra": "forbid"}


# ---------------------------------------------------------------------------
# Validator
# ---------------------------------------------------------------------------

class ResponseSchemaValidator:
    """
    Validates the AI agent's response before it leaves the armor.
    - Ensures the response is not empty.
    - Ensures it does not contain sensitive system strings (DEBUG:, INTERNAL_ERROR, …).
    Used by ResiliencePillar to decide retry / fallback.
    """

    def __init__(self, policy: HardeningPolicy | None = None) -> None:
        self.policy = policy or HardeningPolicy()

    def _text_fields(self, data: Any) -> list[tuple[str, str]]:
        """Extract (field_name, text) from a dict, recursing one level."""
        if not isinstance(data, dict):
            return [("value", str(data))]
        fields: list[tuple[str, str]] = []
        for k, v in data.items():
            if isinstance(v, str):
                fields.append((k, v))
            elif isinstance(v, (list, dict)):
                fields.append((k, str(v)))
        return fields

    def validate(self, response: Any) -> ResponseValidationResult:
        """
        Run all hardening checks against the response object.
        Returns ResponseValidationResult(valid=False, reason=...) on failure.
        """
        payload = getattr(response, "payload", None)

        # ——— Check 1: Not empty ———
        if not self.policy.allow_empty_payload:
            if payload is None or (isinstance(payload, dict) and len(payload) == 0):
                return ResponseValidationResult(
                    valid=False,
                    reason="Response payload is empty",
                    violated_check="empty_payload",
                )
            if not payload:
                return ResponseValidationResult(
                    valid=False,
                    reason="Response payload is falsy",
                    violated_check="empty_payload",
                )

        # ——— Fields to scan ———
        fields_to_scan = self._text_fields(payload)
        if self.policy.scan_metadata:
            metadata = getattr(response, "metadata", None)
            if metadata:
                fields_to_scan += [("metadata." + k, v) for k, v in self._text_fields(metadata)]

        for field_name, text in fields_to_scan:
            # ——— Check 2: Blocked system strings ———
            for blocked in self.policy.blocked_system_strings:
                if blocked in text:
                    return ResponseValidationResult(
                        valid=False,
                        reason=f"Response contains blocked system string: '{blocked}' in field '{field_name}'",
                        violated_check="blocked_system_string",
                    )
            # ——— Check 3: Leak patterns ———
            if self.policy.enable_leak_pattern_scan:
                for pattern in _LEAK_PATTERNS:
                    if pattern.search(text):
                        return ResponseValidationResult(
                            valid=False,
                            reason=f"Response contains potential data leak pattern in field '{field_name}'",
                            violated_check="leak_pattern",
                        )

        return ResponseValidationResult(valid=True)
