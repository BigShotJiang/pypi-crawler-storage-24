"""
Pillar 4 — Resilience: AuditReadyScrubber.

Scans the final AI response for PII before it leaves the armor:
  - Social Security Numbers (SSN):  XXX-XX-XXXX / XXXXXXXXX
  - Credit Card numbers:            major card formats (Visa, MC, Amex, Discover, …)
  - Email addresses

Any PII found is redacted in-place and a structured SecurityAlert is emitted,
tagged with ISO 42001 A.8.4 (Incident Communication).

ISO 42001 A.8.4 requires timely, documented communication of AI-system incidents;
this scrubber constitutes the automated detection-and-notification leg of that control.

CAIRO Protocol Technical Architecture v1.0.
"""

from __future__ import annotations

import datetime
import re
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# ISO tag
# ---------------------------------------------------------------------------

ISO_TAG: str = "ISO 42001 A.8.4"


# ---------------------------------------------------------------------------
# PII regex patterns
# ---------------------------------------------------------------------------

_SSN_PATTERN: re.Pattern[str] = re.compile(
    r"\b(?!000|666|9\d{2})\d{3}[- ]?(?!00)\d{2}[- ]?(?!0000)\d{4}\b"
)

# Luhn-aware regex covers most 13-16 digit card formats (Visa, MC, Amex, Discover, JCB)
_CREDIT_CARD_PATTERN: re.Pattern[str] = re.compile(
    r"\b(?:"
    r"4[0-9]{12}(?:[0-9]{3})?"                     # Visa 13 or 16 digits
    r"|(?:5[1-5][0-9]{2}|222[1-9]|22[3-9][0-9]|2[3-6][0-9]{2}|27[01][0-9]|2720)[0-9]{12}"  # MC
    r"|3[47][0-9]{13}"                              # Amex 15 digits
    r"|3(?:0[0-5]|[68][0-9])[0-9]{11}"             # Diners 14 digits
    r"|6(?:011|5[0-9]{2})[0-9]{12}"                # Discover
    r"|(?:2131|1800|35\d{3})\d{11}"                # JCB
    r")\b"
)

# Generic 16-digit card in groups of 4 separated by dashes or spaces
# Catches formats like 1234-5678-9012-3456 that don't match a known BIN prefix.
_GENERIC_CARD_DASHED_PATTERN: re.Pattern[str] = re.compile(
    r"\b\d{4}[-\s]\d{4}[-\s]\d{4}[-\s]\d{4}\b"
)

_EMAIL_PATTERN: re.Pattern[str] = re.compile(
    r"\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b"
)

# Indian mobile numbers — DPDP Act (Digital Personal Data Protection Act 2023)
# Format: +91 followed by optional separator and a 10-digit number starting with 6-9.
_INDIA_PHONE_PATTERN: re.Pattern[str] = re.compile(
    r"\+91[-\s]?[6-9]\d{9}\b"
)


# ---------------------------------------------------------------------------
# Enumerations & Pydantic models
# ---------------------------------------------------------------------------

class PiiType(str, Enum):
    SSN = "ssn"
    CREDIT_CARD = "credit_card"
    EMAIL = "email"
    PHONE = "phone"          # Indian DPDP + general international phone numbers


_REDACTION_LABELS: dict[PiiType, str] = {
    PiiType.SSN: "[REDACTED-SSN]",
    PiiType.CREDIT_CARD: "[REDACTED-CC]",
    PiiType.EMAIL: "[REDACTED-EMAIL]",
    PiiType.PHONE: "[REDACTED-PHONE]",
}


class PiiMatch(BaseModel):
    """Record of a single PII instance found and redacted."""
    pii_type: PiiType
    field: str = Field(description="Payload field where the PII was found")
    redaction_label: str = Field(description="Token used to replace the PII value")
    preview: str = Field(description="First 3 chars of original value followed by ***")

    model_config = {"extra": "forbid"}


class SecurityAlert(BaseModel):
    """
    Structured incident report for ISO 42001 A.8.4 (Incident Communication).
    Logged on every scrub run that finds and redacts PII.
    """
    iso_control: str = Field(default=ISO_TAG, description="Governing ISO 42001 control")
    alert_type: str = Field(default="PII_DETECTED")
    pii_found: list[PiiMatch] = Field(default_factory=list)
    pii_count: int = Field(description="Total number of PII instances redacted")
    correlation_id: str | None = Field(default=None)
    timestamp_utc: str = Field(
        description="ISO-8601 UTC timestamp of detection",
    )
    action_taken: str = Field(default="redacted", description="What was done: redacted | blocked")
    severity: str = Field(default="HIGH", description="Incident severity for the dashboard")

    model_config = {"extra": "forbid"}


class ScrubResult(BaseModel):
    """Result returned by AuditReadyScrubber.scrub()."""
    scrubbed: bool = Field(description="True if any PII was found and redacted")
    redacted_payload: dict[str, Any] = Field(default_factory=dict)
    alerts: list[SecurityAlert] = Field(default_factory=list)
    pii_count: int = Field(default=0)

    model_config = {"extra": "forbid"}


# ---------------------------------------------------------------------------
# Scrubber
# ---------------------------------------------------------------------------

_PII_SCANS: list[tuple[PiiType, re.Pattern[str]]] = [
    # Phone first — avoids misclassifying numeric segments of phone numbers as card digits
    (PiiType.PHONE, _INDIA_PHONE_PATTERN),
    (PiiType.SSN, _SSN_PATTERN),
    # Specific BIN-range card patterns before generic fallback
    (PiiType.CREDIT_CARD, _CREDIT_CARD_PATTERN),
    # Generic 4x4 dashed/spaced card (catches non-standard BIN prefixes e.g. 1234-5678-…)
    (PiiType.CREDIT_CARD, _GENERIC_CARD_DASHED_PATTERN),
    (PiiType.EMAIL, _EMAIL_PATTERN),
]


class AuditReadyScrubber:
    """
    Final-output PII scrubber for Pillar 4 (Resilience).

    Scans all string fields in an AgentResponse payload (and optionally metadata)
    for SSNs, credit card numbers, and email addresses. Redacts each match
    in-place and raises a SecurityAlert tagged ISO 42001 A.8.4.

    Usage
    -----
        scrubber = AuditReadyScrubber(telemetry_stream=stream)
        result = scrubber.scrub(agent_response, correlation_id="abc-123")
        if result.scrubbed:
            # Use result.redacted_payload — PII has been removed
            agent_response.payload = result.redacted_payload
    """

    def __init__(
        self,
        telemetry_stream: Any = None,
        scan_metadata: bool = False,
    ) -> None:
        self.telemetry_stream = telemetry_stream
        self.scan_metadata = scan_metadata

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def scrub(
        self,
        response: Any,
        correlation_id: str | None = None,
    ) -> ScrubResult:
        """
        Scrub `response.payload` (and optionally `response.metadata`) for PII.

        Returns a ScrubResult with a fully-redacted copy of the payload.
        Any found PII is recorded in SecurityAlert(s) and forwarded to
        the telemetry_stream (if configured).
        """
        payload: Any = getattr(response, "payload", None) or {}
        metadata: Any = getattr(response, "metadata", None) or {}

        redacted_payload = self._deep_copy_dict(payload)
        all_matches: list[PiiMatch] = []

        # Scrub payload
        all_matches += self._scrub_dict(redacted_payload, prefix="")

        # Optionally scrub metadata (non-destructive — metadata copy only for reporting)
        if self.scan_metadata and isinstance(metadata, dict):
            redacted_metadata = self._deep_copy_dict(metadata)
            meta_matches = self._scrub_dict(redacted_metadata, prefix="metadata.")
            all_matches += meta_matches

        if not all_matches:
            return ScrubResult(
                scrubbed=False,
                redacted_payload=redacted_payload,
            )

        alert = SecurityAlert(
            pii_found=all_matches,
            pii_count=len(all_matches),
            correlation_id=correlation_id,
            timestamp_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        )

        self._emit_alert(alert)

        return ScrubResult(
            scrubbed=True,
            redacted_payload=redacted_payload,
            alerts=[alert],
            pii_count=len(all_matches),
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _scrub_dict(
        self,
        data: dict[str, Any],
        prefix: str,
    ) -> list[PiiMatch]:
        """Mutate `data` in-place, replacing PII. Returns list of PiiMatch records."""
        matches: list[PiiMatch] = []
        for key, value in list(data.items()):
            field_name = f"{prefix}{key}"
            if isinstance(value, str):
                redacted, field_matches = self._scrub_string(value, field_name)
                if field_matches:
                    data[key] = redacted
                    matches.extend(field_matches)
            elif isinstance(value, dict):
                matches.extend(self._scrub_dict(value, prefix=f"{field_name}."))
            elif isinstance(value, list):
                matches.extend(self._scrub_list(value, field_name))
        return matches

    def _scrub_list(
        self,
        items: list[Any],
        field_name: str,
    ) -> list[PiiMatch]:
        matches: list[PiiMatch] = []
        for i, item in enumerate(items):
            if isinstance(item, str):
                redacted, item_matches = self._scrub_string(item, f"{field_name}[{i}]")
                if item_matches:
                    items[i] = redacted
                    matches.extend(item_matches)
            elif isinstance(item, dict):
                matches.extend(self._scrub_dict(item, prefix=f"{field_name}[{i}]."))
        return matches

    def _scrub_string(
        self,
        text: str,
        field_name: str,
    ) -> tuple[str, list[PiiMatch]]:
        """Return (redacted_text, list[PiiMatch]) for all PII found in text."""
        matches: list[PiiMatch] = []
        result = text

        for pii_type, pattern in _PII_SCANS:
            label = _REDACTION_LABELS[pii_type]
            found = pattern.findall(result)
            if found:
                for raw in set(found):  # deduplicate per pattern
                    preview = (raw[:3] + "***") if len(raw) > 3 else "***"
                    matches.append(
                        PiiMatch(
                            pii_type=pii_type,
                            field=field_name,
                            redaction_label=label,
                            preview=preview,
                        )
                    )
                result = pattern.sub(label, result)

        return result, matches

    @staticmethod
    def _deep_copy_dict(data: Any) -> dict[str, Any]:
        """Shallow-enough copy to avoid mutating the original payload."""
        import copy
        if isinstance(data, dict):
            return copy.deepcopy(data)
        return {}

    # ------------------------------------------------------------------
    # Telemetry / alert emission
    # ------------------------------------------------------------------

    def _emit_alert(self, alert: SecurityAlert) -> None:
        """
        Emit the SecurityAlert to the telemetry stream (best-effort, non-blocking).
        Passes action_type="pii_blocked" so the ValueTracker records the event
        and the dashboard cross-walk shows ISO 42001 A.8.4 / NIST PR.DS-1.
        """
        if self.telemetry_stream is None:
            return
        try:
            if hasattr(self.telemetry_stream, "emit_risk_pulse"):
                self.telemetry_stream.emit_risk_pulse(
                    from_node="output_scrubber",
                    to_node="pii_redacted",
                    severity="RED",
                    eu_ai_act_status="HIGH",
                    iso_control_reference=ISO_TAG,
                    nist_function="PROTECT",
                    correlation_id=alert.correlation_id,
                    # action_type triggers ValueTracker.record_intercept("pii_blocked")
                    action_type="pii_blocked",
                    extra={
                        "alert_type": alert.alert_type,
                        "pii_count": alert.pii_count,
                        "action_taken": alert.action_taken,
                        "pii_types": [m.pii_type.value for m in alert.pii_found],
                    },
                )
        except Exception:
            pass
