# CAIRO Protocol SDK

**Forensic AI governance for agentic systems** — deterministic interception, real-time telemetry, and EU AI Act 2026 enforcement.

## Install
```bash
pip install cairo-sdk
```

## Quick Start
```python
from cairo_sdk import TelemetryStream, ValueTracker, RiskPulse

# Initialize telemetry
stream = TelemetryStream(
    value_tracker=ValueTracker(
        annual_turnover_eur=500_000_000,
        usd_per_eur=1.08,
    )
)

# Emit a risk pulse
pulse = RiskPulse(
    pillar="Containment",
    component="prompt_injection",
    sub_component="boundary_check",
    risk_level=0.7,
    eu_ai_act_status="high",
)
stream.emit(pulse)

# Get dashboard summary
summary = stream.value_tracker.dashboard_summary()
print(f"Total intercepts: {summary['total_intercepts']}")
print(f"Risk exposure avoided: ${summary['total_risk_usd']:,.2f}")
```

## Five CAIRO Pillars

| Pillar | Purpose | Module |
|--------|---------|--------|
| **Containment** | Boundaries, scope lits, sandboxing | `cairo_sdk.containment` |
| **Attestation** | Compliance proof, audit trail | `cairo_sdk.attestation` |
| **Interception** | Pre/post request hooks, middleware | `cairo_sdk.interception` |
| **Resilience** | Fault handling, retries, fallback | `cairo_sdk.resilience` |
| **Output-Logic** | Output validation, guardrails | `cairo_sdk.output_logic` |

## Key Features

- **ValueTracker** — real-time EU AI Act fine-avoidance calculation
- **TelemetryStream** — high-speed forensic event streaming
- **LogicDriftDetector** — behavioral drift detection across agent sessions
- **Deterministic interception** — zero-trust validation at every CAIRO pillar
- **Compliance metadata** — NIST AI RMF, ISO 42001, EU AI Act mapping

## Requirements

- Python 3.9+
- pydantic >= 2.0

## Documentation

- [SDK Quickstart](https://cairoprotocol.com/docs/sdk-quickstart)
- [Integration Guides](https://cairoprotocol.com/docs/integration-guides)
- [API Reference](https://cairoprotocol.com/docs/api-reference)

#
Proprietary — XSData Factory Private Limited. See [cairoprotocol.com/trust](https://cairoprotocol.com/trust) for terms.
