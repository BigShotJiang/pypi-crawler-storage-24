"""
MaterialClient —— SDK 统一入口

用法:
    from gravity_material_upload import MaterialClient

    client = MaterialClient(app_key="your_app_key")
    client.upload_material("./assets", recursive=True)
"""

from pathlib import Path
from typing import Union, List, Tuple, Optional, runtime_checkable
from typing_extensions import Protocol

from .file_scanner import FileScanner
from .file_upload import FileUploader


@runtime_checkable
class IMaterialClient(Protocol):
    """素材上传客户端的公开接口，仅暴露 upload_material 方法。"""

    def upload_material(
        self,
        source_paths: Union[str, List[str]] = ".",
        recursive: bool = True,
        allowed_extensions: Tuple[str, ...] = None,
        max_workers: int = 5,
        base_dir: Union[str, Path, None] = "__caller__",
        upload_config: Optional[dict] = None,
    ) -> None: ...


class _MaterialClient:
    """
    素材上传客户端（内部实现）。

    将文件扫描和上传整合为一个方法调用，简化 SDK 使用流程。
    """

    def __init__(self, app_key: str):
        """
        Args:
            app_key: 引力申请的开发者应用 KEY
        """
        self._scanner = FileScanner()
        self._uploader = FileUploader(app_key=app_key)

    def upload_material(
        self,
        source_paths: Union[str, List[str]] = ".",
        recursive: bool = True,
        allowed_extensions: Tuple[str, ...] = None,
        max_workers: int = 5,
        base_dir: Union[str, Path, None] = "__caller__",
        upload_config: Optional[dict] = None,
    ) -> None:
        """
        一站式素材上传：扫描目标路径中的媒体文件并上传。

        Args:
            source_paths: 目标路径，支持文件、目录、通配符，也可传列表
            recursive:    是否递归搜索子目录，默认 True
            allowed_extensions: 自定义文件后缀白名单，例如 (".png", ".mp4")
            max_workers:  最大并发上传数，默认 5
            base_dir: 相对路径的基准目录，有三种用法：
                - "__caller__" (默认): 自动检测调用方脚本所在目录
                - str 或 Path: 显式指定基准目录
                - None: 使用当前工作目录 (cwd)，即原始行为
            upload_config: 自定义上传配置参数，合并到接口根层级
        """
        files = self._scanner.scan(
            source_paths=source_paths,
            recursive=recursive,
            allowed_extensions=allowed_extensions,
            base_dir=base_dir,
        )
        self._uploader.upload(
            files,
            max_workers=max_workers,
            upload_config=upload_config,
        )


def MaterialClient(app_key: str) -> IMaterialClient:
    """
    创建素材上传客户端。

    Args:
        app_key: 引力申请的开发者应用 KEY

    Returns:
        IMaterialClient: 仅暴露 upload_material 方法的客户端接口
    """
    return _MaterialClient(app_key=app_key)
