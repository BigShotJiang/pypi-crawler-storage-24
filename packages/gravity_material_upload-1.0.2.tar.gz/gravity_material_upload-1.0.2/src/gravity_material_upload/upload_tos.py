import time
import urllib.parse
from typing import Optional

import requests
import tos
from tos.utils import SizeAdapter
from .token import create_authorization, get_sign
from .token import create_authorization
from .config import HOST

# 默认分片大小: 8MB（与 JS 端保持一致）
DEFAULT_PART_SIZE = 8 * 1024 * 1024


def _default_progress_callback(bytes_uploaded: int, total_bytes: int):
    """默认进度回调（静默）"""
    pass


def get_full_url(full_name_url: str) -> str:
    """拼接完整的文件 URL"""
    return f"https://tos-accelerate.gravity-engine.com/{full_name_url}"


class TosUploader:
    """
    TOS 分片上传器。

    通过 STS 临时凭证进行鉴权，自动管理凭证的初始化和刷新。
    模仿 JavaScript 端 useTos() 的逻辑。

    用法示例:
        uploader = TosUploader()
        url = uploader.upload_with_progress(
            file_name="uploads/video.mp4",
            file_path="/path/to/video.mp4",
        )
    """

    def __init__(
        self,
        app_key: str,
    ):
        """
        Args:
            app_key: 引力申请的开发者应用 KEY
        """
        self._app_key = app_key

        # 内部状态
        self._client: Optional[tos.TosClientV2] = None
        self._refresh_time: float = 0
        self._auth = {
            "region": "",
            "end_point": "",
            "access_key_id": "",
            "secret_access_key": "",
            "session_token": "",
            "bucket": "",
            "expires": 3600,  # 单位：秒，默认 1 小时
            "root": "",
        }

    # ──────────────────── 公开属性 ────────────────────

    @property
    def root(self) -> str:
        return self._auth["root"]

    @property
    def bucket(self) -> str:
        return self._auth["bucket"]

    # ──────────────────── 内部方法 ────────────────────

    def _get_client_data(self) -> Optional[dict]:
        """调用 API 获取 STS 临时凭证"""
        try:
            headers = {"Authorization": create_authorization({}, self._app_key)}
            url = f"{HOST}/asset/tos/authorization/"
            resp = requests.post(
                url,
                headers=headers,
                timeout=10,
                json={"sign": get_sign({}, self._app_key)},
            )
            resp.raise_for_status()
            result = resp.json()
            # API 返回格式: {"data": {"region": ..., ...}, "code": 0, "msg": "成功"}
            data = result.get("data", {}) if isinstance(result, dict) else {}
            # 假定：有 region 则为正确数据
            if isinstance(data, dict) and data.get("region"):
                return data
            return None
        except requests.exceptions.JSONDecodeError:
            # print(f"获取 TOS 凭证请求失败: 接口返回了非预期的格式 (状态码: {resp.status_code})")
            return None
        except requests.exceptions.RequestException as e:
            # print(f"获取 TOS 凭证请求失败: {e}")
            return None
        except Exception as e:
            # print(f"获取 TOS 凭证发生未知错误: {e}")
            return None

    def _set_client(self):
        """获取凭证并初始化 / 刷新 TOS 客户端"""
        res = self._get_client_data()
        if res is None:
            return
        self._auth = {
            "region": res.get("region", ""),
            "end_point": res.get("end_point", ""),
            "access_key_id": res.get("access_key_id", ""),
            "secret_access_key": res.get("secret_access_key", ""),
            "session_token": res.get("session_token", ""),
            "bucket": res.get("bucket", ""),
            "expires": res.get("expires", 3600),
            "root": res.get("root"),
        }

        endpoint = self._auth["end_point"] or f"tos-{self._auth['region']}.volces.com"
        self._client = tos.TosClientV2(
            ak=self._auth["access_key_id"],
            sk=self._auth["secret_access_key"],
            endpoint=endpoint,
            region=self._auth["region"],
            security_token=self._auth["session_token"],
        )
        self._refresh_time = time.time()

    def _try_refresh_client(self):
        """如果凭证即将过期（过期前 20 分钟），自动刷新"""
        if self._client is None:
            return
        buffer_seconds = 20 * 60  # 20 分钟缓冲
        is_expired = time.time() > self._refresh_time + (
            self._auth["expires"] - buffer_seconds
        )
        if is_expired:
            self._set_client()

    # ──────────────────── 公开方法 ────────────────────

    def init(self) -> bool:
        """初始化客户端（懒初始化，首次调用时获取凭证）"""
        if self._client is None:
            self._set_client()
        else:
            self._try_refresh_client()
        return self._client is not None

    def upload_with_progress(
        self,
        file_name: str,
        file_path: str,
        part_size: int = DEFAULT_PART_SIZE,
    ) -> str:
        """
        分片上传文件。

        Args:
            file_name:    对象存储中的目标路径（key），例如 "uploads/video.mp4"
            file_path:    本地文件完整路径
            part_size:    分片大小（字节），默认 8MB

        Returns:
            上传成功后的文件完整 URL

        Raises:
            RuntimeError: 客户端未初始化或上传失败
        """

        if not self.init():
            raise RuntimeError("TOS 客户端未初始化，请检查鉴权 API 是否正常")

        # 去掉开头的 /
        if file_name.startswith("/"):
            file_name = file_name[1:]

        upload_id = None

        try:
            import os

            total_size = os.path.getsize(file_path)

            # 1. 初始化分片上传
            multi_result = self._client.create_multipart_upload(
                bucket=self._auth["bucket"],
                key=file_name,
                content_disposition=f'inline; filename="{urllib.parse.quote(os.path.basename(file_path))}"',
            )
            upload_id = multi_result.upload_id

            parts = []

            # 2. 串行上传每个分片
            with open(file_path, "rb") as f:
                part_number = 1
                offset = 0
                while offset < total_size:
                    num_to_upload = min(part_size, total_size - offset)
                    out = self._client.upload_part(
                        self._auth["bucket"],
                        file_name,
                        upload_id,
                        part_number,
                        content=SizeAdapter(f, num_to_upload, init_offset=offset),
                    )
                    parts.append(out)
                    offset += num_to_upload

                    part_number += 1

            # 3. 完成分片上传
            self._client.complete_multipart_upload(
                self._auth["bucket"],
                file_name,
                upload_id,
                parts,
            )

            # 拼接 URL（TOS 返回结果不包含最终 URL）
            return get_full_url(full_name_url=file_name)

        except Exception as err:
            # 出错后取消分片上传，清理碎片
            if upload_id and self._client:
                try:
                    self._client.abort_multipart_upload(
                        self._auth["bucket"],
                        file_name,
                        upload_id,
                    )
                except Exception:
                    pass
            raise RuntimeError(f"TOS 上传失败: {err}") from err
