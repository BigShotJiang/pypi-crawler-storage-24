"""
递归获取脚本同目录内的所有图片/视频
"""

import glob
import inspect
from pathlib import Path
from typing import Union, List, Optional, Set, Tuple


class FileScanner:
    def __init__(self):
        # 默认只允许图片和视频的后缀（全部小写）
        self.default_extensions = (
            ".png",
            ".jpg",
            ".jpeg",
            ".gif",  # 图片
            ".mp4",
            ".3gp",
            ".avi",
            ".mov",  # 视频
        )

    def _filter_and_collect(
        self,
        source_paths: Union[str, List[str]],
        recursive: bool,
        extensions: Tuple[str, ...],
        base_dir: Optional[Path] = None,
    ) -> List[Path]:
        """
        核心逻辑：解析用户输入的混合路径，过滤并返回去重后的绝对路径列表
        """
        # 1. 统一格式：将单字符串转换为列表，方便统一遍历
        if isinstance(source_paths, str):
            source_paths = [source_paths]

        # 使用 set 存储解析结果，自动利用绝对路径进行“去重”
        valid_files: Set[Path] = set()

        # 将允许的后缀统一转为小写，方便后续做大小写不敏感的匹配 (例如同时支持 .JPG 和 .jpg)
        allowed_exts = {ext.lower() for ext in extensions}

        def _add_if_valid(file_path: Path):
            """内部校验函数：判断是否为文件，且后缀是否在白名单内"""
            if file_path.is_file() and file_path.suffix.lower() in allowed_exts:
                valid_files.add(file_path.resolve())  # resolve() 获取绝对路径

        # 2. 遍历所有传入的路径
        for path_str in source_paths:
            # 场景 A: 处理通配符 (例如 './assets/**/*.mp4')
            # 对于字符串通配符，使用标准库的 glob.glob 最健壮
            if any(char in path_str for char in ["*", "?", "["]):
                # 如果有 base_dir 且通配符是相对路径，则基于 base_dir 展开
                glob_pattern = path_str
                if base_dir and not Path(path_str).is_absolute():
                    glob_pattern = str(base_dir / path_str)
                for matched_str in glob.glob(glob_pattern, recursive=recursive):
                    _add_if_valid(Path(matched_str))
                continue

            p = Path(path_str)
            # 如果是相对路径且指定了 base_dir，则基于 base_dir 解析
            if base_dir and not p.is_absolute():
                p = base_dir / p

            if not p.exists():
                print(f"[Warning] {path_str}路径不存在，已跳过")
                continue

            # 场景 B: 处理具体的单个文件
            if p.is_file():
                _add_if_valid(p)

            # 场景 C: 处理文件夹
            elif p.is_dir():
                # 如果开启递归使用 '**/*'，否则只获取当前层级 '*'
                search_pattern = "**/*" if recursive else "*"
                for child_file in p.glob(search_pattern):
                    _add_if_valid(child_file)

        # 转换回列表输出
        return list(valid_files)

    @staticmethod
    def _resolve_base_dir(base_dir: Union[str, Path, None] = "__caller__") -> Optional[Path]:
        """
        解析 base_dir 参数，返回用于相对路径解析的基准目录。

        Args:
            base_dir: 相对路径的基准目录，有三种用法：
                - "__caller__" (默认): 自动检测调用方脚本所在目录
                - str 或 Path: 显式指定基准目录
                - None: 使用当前工作目录 (cwd)，即原始行为

        Returns:
            解析后的 Path 对象，或 None（表示使用 cwd）
        """
        if base_dir is None:
            return None

        if base_dir == "__caller__":
            # 向上遍历调用栈，找到第一个不属于本包的外部调用者
            for frame_info in inspect.stack():
                caller_file = frame_info.filename
                # 跳过本文件及本包内部的调用
                if caller_file == __file__:
                    continue
                caller_path = Path(caller_file)
                # 判断是否是本包内部的模块（同一个父目录）
                if caller_path.parent == Path(__file__).parent:
                    continue
                return caller_path.parent.resolve()
            # 兜底：如果找不到外部调用者，使用 cwd
            return None

        # 用户显式传入了一个路径
        return Path(base_dir).resolve()

    def scan(
        self,
        source_paths: Union[str, List[str]] = ".",
        recursive: bool = True,
        allowed_extensions: Tuple[str, ...] = None,
        base_dir: Union[str, Path, None] = "__caller__",
    ) -> List[Path]:
        """
        供用户调用的主干 API
        返回符合条件的文件列表 (List[Path])，用于后续解析 md5 等操作

        Args:
            source_paths: 目标路径，支持文件、目录、通配符，可以使用相对路径
            recursive: 是否递归搜索子目录
            allowed_extensions: 自定义文件后缀白名单
            base_dir: 相对路径的基准目录，有三种用法：
                - "__caller__" (默认): 自动检测调用方脚本所在目录
                - str 或 Path: 显式指定基准目录
                - None: 使用当前工作目录 (cwd)，即原始行为
        """
        # 解析 base_dir
        resolved_base_dir = self._resolve_base_dir(base_dir)

        # 确定使用的文件后缀白名单
        if allowed_extensions:
            # 将 default_extensions 转为小写 set，用于快速查找
            allowed = {ext.lower() for ext in self.default_extensions}
            # 过滤掉不在 default_extensions 中的后缀
            invalid = [ext for ext in allowed_extensions if ext.lower() not in allowed]
            if invalid:
                print(f"[Warning] 以下自定义后缀不在支持列表中，已自动移除: {invalid}")
            exts = tuple(ext for ext in allowed_extensions if ext.lower() in allowed)
            if not exts:
                print("[Warning] 过滤后没有剩余的有效后缀，将使用默认后缀列表。")
                exts = self.default_extensions
        else:
            exts = self.default_extensions

        # 获取所有符合条件的待上传文件
        files_to_upload = self._filter_and_collect(
            source_paths, recursive, exts, resolved_base_dir
        )

        if len(files_to_upload):
            print(f"准备上传 {len(files_to_upload)} 个文件...")
        else:
            print("[End] 没有找到符合条件的图片或视频文件，上传取消。")

        return files_to_upload
