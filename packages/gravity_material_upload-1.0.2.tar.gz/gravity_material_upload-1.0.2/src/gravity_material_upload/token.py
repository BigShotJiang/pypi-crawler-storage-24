import hashlib
import json

import jwt


def get_sign(params: dict, app_key: str) -> str:
    """
    根据请求参数和 app_key 生成签名字符串。

    将 params 中除 "sign" 以外的所有字段按 key 排序后拼接，
    再附加 app_key，最终计算 MD5 作为签名。

    @param params: 接口请求参数字典（不含 sign 字段）
    @param app_key: 引力申请的开发者应用 KEY
    @return: MD5 签名字符串
    """
    param_list = []
    for k, v in params.items():
        if k == "sign":
            continue
        param_list.append(f"{k}={json.dumps(v, sort_keys=True)}")
    param_list.sort()
    sb = "&".join(param_list) + app_key
    current_str = sb.replace("\"", "").replace(" ", "")
    return hashlib.md5(current_str.encode("utf-8")).hexdigest()


def get_authorization(sign: str, app_key: str) -> str:
    """
    使用签名和 app_key 生成 JWT Authorization 字符串。

    @param sign: 由 get_sign 生成的签名
    @param app_key: 引力申请的开发者应用 KEY
    @return: JWT 编码后的 Authorization 字符串
    """
    return jwt.encode({"app_key": app_key}, sign, algorithm="HS256")


def create_authorization(params: dict, app_key: str) -> str:
    """
    根据请求参数和 app_key 一步生成 JWT Authorization 字符串。

    内部依次调用 get_sign 和 get_authorization。

    @param params: 接口请求参数字典（不含 sign 字段）
    @param app_key: 引力申请的开发者应用 KEY
    @return: JWT 编码后的 Authorization 字符串
    """
    sign = get_sign(params, app_key)
    return get_authorization(sign, app_key)
