import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from queue import Queue
from typing import List, Optional

import requests
from tqdm import tqdm

from . import tools
from .token import create_authorization, get_sign
from .upload_tos import TosUploader
from .config import HOST


class FileUploader:
    def __init__(
        self,
        app_key: str,
    ):
        """
        Args:
            app_key: 引力申请的开发者应用 KEY
        """

        self._app_key = app_key
        self._session = requests.Session()
        self._tos = TosUploader(
            app_key=app_key,
        )

    # ──────────────────── 内部方法 ────────────────────

    def _check_material(self, file_md5: str) -> bool:
        """检查素材是否已存在。返回 True 表示已存在，False 表示不存在。"""
        payload = {"file_md5": file_md5}
        payload["sign"] = get_sign(payload, self._app_key)
        headers = {"Authorization": create_authorization(payload, self._app_key)}
        try:
            resp = self._session.post(
                f"{HOST}/asset/material/manage/local/check/",
                headers=headers,
                json=payload,
                timeout=30,
            )
            resp.raise_for_status()
            result = resp.json()

        except requests.exceptions.JSONDecodeError:
            raise RuntimeError(f"[接口调用异常JSONDecodeError]调用引力查重接口失败")
        except requests.exceptions.RequestException as e:
            raise RuntimeError(
                f"[接口调用异常RequestException]调用引力查重接口失败: {e}"
            )

        if result.get("code") != 0:
            raise RuntimeError(f"调用引力查重接口失败: {result.get('msg', '未知错误')}")

        return result.get("data").get("data") is not None

    def _register_material(
        self, file_data: dict, upload_config: Optional[dict] = None
    ) -> None:
        """调用后端接口注册素材，注册失败则抛出异常。"""
        payload = {
            "file_data": file_data,
            "file_uid": int(time.time() * 1000),
        }

        if upload_config:
            payload.update(upload_config)
        payload["sign"] = get_sign(payload, self._app_key)
        headers = {"Authorization": create_authorization(payload, self._app_key)}
        try:
            resp = self._session.post(
                f"{HOST}/asset/material/manage/local/upload/",
                headers=headers,
                json=payload,
                timeout=30,
            )
            resp.raise_for_status()
            result = resp.json()
        except requests.exceptions.JSONDecodeError:
            raise RuntimeError(f"[接口调用异常JSONDecodeError]调用引力上传接口请求失败")
        except requests.exceptions.RequestException as e:
            raise RuntimeError(
                f"[接口调用异常RequestException]调用引力上传接口失败: {e}"
            )

        if result.get("code") != 0:
            error = result.get("extra", {}).get("error", "参数错误")
            raise RuntimeError(f"调用引力上传接口失败: {error}")

    # ──────────────────── 公开方法 ────────────────────

    def upload(
        self,
        files: List[Path],
        max_workers: int = 5,
        upload_config: Optional[dict] = None,
    ):
        """
        并发上传文件列表。

        Args:
            files:        待上传文件列表
            max_workers:  最大并发上传数，默认 5
            upload_config: 自定义上传配置参数，合并到接口根层级
        """
        if len(files) == 0:
            return

        if not self._tos.init():
            print("[接口调用异常]获取上传配置信息失败，请重试或联系引力处理")
            return

        # 实际并发数不超过文件数
        workers = min(max_workers, len(files))

        # ── 进度条 ──
        # position=0: 总文件进度
        file_bar = tqdm(
            total=len(files),
            desc="文件进度",
            bar_format="{desc}: {percentage:3.0f}%|{bar}| {n_fmt}/{total_fmt}",
            position=0,
            leave=True,
        )
        file_bar_lock = threading.Lock()

        # position=1..workers: 每个并发槽位的字节进度条
        # 使用队列管理可用槽位
        slot_queue: Queue[int] = Queue()
        for i in range(workers):
            slot_queue.put(i + 1)  # 槽位编号 1 ~ workers

        # 预创建所有槽位的占位进度条（避免闪烁）
        slot_bars: dict[int, tqdm] = {}
        for slot in range(1, workers + 1):
            bar = tqdm(
                total=0,
                desc="  ↳ 等待中...",
                unit="B",
                unit_scale=True,
                unit_divisor=1024,
                bar_format="{desc}",
                position=slot,
                leave=False,
            )
            slot_bars[slot] = bar

        def _upload_one(file: Path) -> None:
            """单文件上传（在线程中执行）"""
            # 获取一个可用槽位
            slot = slot_queue.get()
            byte_bar = slot_bars[slot]

            try:
                # 提示正在获取元数据
                byte_bar.set_description(f"  ↳ [获取元数据] {file.name}")
                byte_bar.refresh()

                # 准备文件元数据
                width, height, duration = tools.get_media_info(file)
                file_extension = file.suffix[1:]
                file_type = tools.get_file_type(file_extension)
                file_size = file.stat().st_size

                # 校验文件大小，超出不计算md5直接退出
                if file_type == "image" and file_size > 8 * 1024 * 1024:
                    error_msg = f"文件 {file.name} 上传失败: 图片大小不能超过8MB"
                    print(error_msg)
                    raise RuntimeError(error_msg)
                elif file_type == "video" and file_size > 500 * 1024 * 1024:
                    error_msg = f"文件 {file.name} 上传失败: 视频大小不能超过500MB"
                    print(error_msg)
                    raise RuntimeError(error_msg)

                # 提示正在计算MD5
                byte_bar.set_description(f"  ↳ [计算MD5] {file.name}")
                byte_bar.refresh()
                file_md5 = tools.get_file_md5(file)

                # 提示正在查重
                byte_bar.set_description(f"  ↳ [查重中] {file.name}")
                byte_bar.refresh()
                if self._check_material(file_md5):
                    raise RuntimeError("[引力提示] 素材已存在")

                file_data = {
                    "width": width,
                    "height": height,
                    "aspect_ratio_int": int(round((width / height) * 100, 0)),
                    "file_extension": file_extension,
                    "file_md5": file_md5,
                    "file_name": file.stem,
                    "file_size": file_size,
                    "file_type": file_type,
                    "video_duration_second": duration,
                    "file_url": "",
                    "thumbnail_url": "",
                    "thumbnail_url_size": 0,
                }

                # 拼接对象存储路径
                full_name_url = (
                    f"{self._tos.root}{file_type}/{file_md5}.{file_extension}"
                )

                # 重置字节进度条
                byte_bar.bar_format = (
                    "{desc}: {percentage:3.0f}%|{bar}| {n_fmt}/{total_fmt} [{rate_fmt}]"
                )
                byte_bar.reset(total=file_size)
                byte_bar.set_description(f"  ↳ [上传中] {file.name}")

                # 分片上传到 TOS
                file_url = self._tos.upload_with_progress(
                    file_name=full_name_url,
                    file_path=str(file),
                )
                file_data["file_url"] = file_url

                # 更新字节进度条到 100%
                byte_bar.n = file_size
                byte_bar.set_description(f"  ↳ [处理中] {file.name}")
                byte_bar.refresh()

                # 生成缩略图信息
                thumbnail_info = tools.get_thumbnail(file_data)
                file_data["thumbnail_url"] = thumbnail_info["thumbnail_url"]
                file_data["thumbnail_url_size"] = thumbnail_info["thumbnail_url_size"]

                # 调用后端接口注册素材
                self._register_material(file_data, upload_config=upload_config)

            finally:
                # 恢复为等待状态，隐藏进度条
                byte_bar.bar_format = "{desc}"
                byte_bar.set_description("  ↳ 等待中...")
                byte_bar.refresh()

                # 更新总进度
                with file_bar_lock:
                    file_bar.update(1)
                # 归还槽位
                slot_queue.put(slot)

        # ── 并发执行 ──
        with ThreadPoolExecutor(max_workers=workers) as executor:
            futures = {executor.submit(_upload_one, f): f for f in files}
            # 等待所有任务完成，收集异常
            errors = []
            for future in as_completed(futures):
                exc = future.exception()
                if exc is not None:
                    failed_file = futures[future]
                    errors.append((failed_file, exc))

        # ── 清理进度条 ──
        for bar in slot_bars.values():
            bar.close()

        file_bar.bar_format = "{desc}: {percentage:3.0f}%|{bar}| {n_fmt}/{total_fmt}"
        file_bar.refresh()
        file_bar.close()

        if errors:
            tqdm.write(
                f"⚠ 上传完成（{len(files) - len(errors)} 成功，{len(errors)} 失败）"
            )
            for f, e in errors:
                tqdm.write(f"  ✗ {f.name}: {e}")
        else:
            tqdm.write(f"✔ 上传完成: {len(files)} 个文件全部上传成功")
