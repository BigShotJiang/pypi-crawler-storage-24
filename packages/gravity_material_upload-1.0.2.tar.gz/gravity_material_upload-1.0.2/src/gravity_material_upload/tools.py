import hashlib
from pathlib import Path
import os
import cv2
from PIL import Image

# 默认分块大小: 8MB
DEFAULT_CHUNK_SIZE = 8 * 1024 * 1024

# 图片后缀集合
IMAGE_EXTENSIONS = {"png", "jpg", "jpeg", "gif"}


def get_file_md5(file_path: Path, chunk_size: int = DEFAULT_CHUNK_SIZE) -> str:
    """
    计算文件的 MD5 哈希值（分块读取，避免大文件占用过多内存）。

    Args:
        file_path: 文件路径
        chunk_size: 每次读取的字节数，默认 8MB

    Returns:
        文件的 MD5 哈希值（32位小写十六进制字符串）
    """
    md5_hash = hashlib.md5()

    with open(file_path, "rb") as f:
        while True:
            chunk = f.read(chunk_size)
            if not chunk:
                break
            md5_hash.update(chunk)

    return md5_hash.hexdigest()


def get_file_type(file_extension: str) -> str:
    # image或video
    if file_extension in IMAGE_EXTENSIONS:
        return "image"
    else:
        return "video"


def get_media_info(file_path: Path):
    """
    获取媒体文件的宽度、高度和时长
    :param file_path: 文件路径
    :return: (width, height, duration) 均为 int 类型
    """
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"文件未找到: {file_path}")

    # 获取后缀名并转为小写
    ext = os.path.splitext(file_path)[1].lower()

    # 定义常见格式
    img_exts = {".png", ".jpg", ".jpeg", ".gif"}
    vid_exts = {".mp4", ".3gp", ".avi", ".mov"}

    width, height, duration = 0, 0, 0

    try:
        if ext in img_exts:
            # 处理图片
            with Image.open(file_path) as img:
                width, height = img.size
                duration = 0  # 图片没有时长

        elif ext in vid_exts:
            # 处理视频
            cap = cv2.VideoCapture(file_path)
            if cap.isOpened():
                width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
                height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
                fps = cap.get(cv2.CAP_PROP_FPS)
                frames = cap.get(cv2.CAP_PROP_FRAME_COUNT)

                if fps > 0:
                    # 使用 round 保证四舍五入的准确性
                    duration = int(round(frames / fps))
                cap.release()
            else:
                print(f"警告: 无法打开视频文件 {file_path}")

        else:
            print(f"不支持的文件格式: {ext}")

    except Exception as e:
        print(f"处理文件时出错: {e}")

    return int(width), int(height), int(duration)


def get_file_urll(file_path: Path):

    pass


def get_thumbnail(file_data):
    if file_data["file_type"] == "image":
        return {
            "thumbnail_url": file_data["file_url"] + "?x-tos-process=image/resize,p_40",
            "thumbnail_url_size": 0,
        }

    thumbnail_url = f"{file_data['file_url']}?x-oss-process=video/snapshot,t_0,w_{file_data['width']},h_{file_data['height']},f_jpg"

    return {
        "thumbnail_url": thumbnail_url,
        "thumbnail_url_size": 111,
    }
