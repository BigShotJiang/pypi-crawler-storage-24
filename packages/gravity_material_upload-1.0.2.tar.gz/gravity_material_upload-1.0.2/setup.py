import re
from os import path

from setuptools import setup, find_packages


def read(*paths):
    filename = path.join(path.abspath(path.dirname(__file__)), *paths)
    with open(filename, 'r') as f:
        return f.read()


def find_version(*paths):
    contents = read(*paths)
    match = re.search(r'^__version__ = [\'"]([^\'"]+)[\'"]', contents, re.M)
    if not match:
        raise RuntimeError('Unable to find version string.')
    return match.group(1)


setup(
    name='GravityEngine',
    version='1.0.2',
    description='Python SDK for material upload',
    long_description=read('README.md'),
    long_description_content_type='text/markdown',
    url='',
    license='Apache',
    author='GEData',
    author_email='pony@gravity-engine.com',
    packages=find_packages(where='src'),
    package_dir={'': 'src'},
    platforms=["all"],
    install_requires=["Pillow>=9.0",
                      "tos>=2.6.0",
                      "requests>=2.20.0",
                      "opencv-python>=4.5.0",
                      "tqdm>=4.60.0",
                      "typing_extensions>=3.7",
                      "PyJWT>=2.0.0",
                      ],

    classifiers=[
        'License :: OSI Approved :: Apache Software License',
        'Operating System :: OS Independent',
        'Intended Audience :: Developers',
        'Programming Language :: Python :: 3',
        'Topic :: Software Development :: Libraries'
    ],
)
