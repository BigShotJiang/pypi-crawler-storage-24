# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ResetAccountPasswordRequestBody:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'vendor': 'str',
        'resource_provider': 'str',
        'resource_type': 'str',
        'instance_type': 'str',
        'accounts_password_change_status': 'list[str]',
        'resources_id': 'list[str]'
    }

    attribute_map = {
        'vendor': 'vendor',
        'resource_provider': 'resource_provider',
        'resource_type': 'resource_type',
        'instance_type': 'instance_type',
        'accounts_password_change_status': 'accounts_password_change_status',
        'resources_id': 'resources_id'
    }

    def __init__(self, vendor=None, resource_provider=None, resource_type=None, instance_type=None, accounts_password_change_status=None, resources_id=None):
        r"""ResetAccountPasswordRequestBody

        The model defined in huaweicloud sdk

        :param vendor: 云服务厂商
        :type vendor: str
        :param resource_provider: 云服务
        :type resource_provider: str
        :param resource_type: 资源类型
        :type resource_type: str
        :param instance_type: 实例类型
        :type instance_type: str
        :param accounts_password_change_status: 需要改密的账号的状态，枚举值  TO_BE_CHANGED：待改密 FAILED：改密失败 SUCCESSFUL：改密成功 PROCESSING：改密中  不传默认修改所有状态的账号
        :type accounts_password_change_status: list[str]
        :param resources_id: 实例id列表
        :type resources_id: list[str]
        """
        
        

        self._vendor = None
        self._resource_provider = None
        self._resource_type = None
        self._instance_type = None
        self._accounts_password_change_status = None
        self._resources_id = None
        self.discriminator = None

        self.vendor = vendor
        self.resource_provider = resource_provider
        self.resource_type = resource_type
        self.instance_type = instance_type
        if accounts_password_change_status is not None:
            self.accounts_password_change_status = accounts_password_change_status
        self.resources_id = resources_id

    @property
    def vendor(self):
        r"""Gets the vendor of this ResetAccountPasswordRequestBody.

        云服务厂商

        :return: The vendor of this ResetAccountPasswordRequestBody.
        :rtype: str
        """
        return self._vendor

    @vendor.setter
    def vendor(self, vendor):
        r"""Sets the vendor of this ResetAccountPasswordRequestBody.

        云服务厂商

        :param vendor: The vendor of this ResetAccountPasswordRequestBody.
        :type vendor: str
        """
        self._vendor = vendor

    @property
    def resource_provider(self):
        r"""Gets the resource_provider of this ResetAccountPasswordRequestBody.

        云服务

        :return: The resource_provider of this ResetAccountPasswordRequestBody.
        :rtype: str
        """
        return self._resource_provider

    @resource_provider.setter
    def resource_provider(self, resource_provider):
        r"""Sets the resource_provider of this ResetAccountPasswordRequestBody.

        云服务

        :param resource_provider: The resource_provider of this ResetAccountPasswordRequestBody.
        :type resource_provider: str
        """
        self._resource_provider = resource_provider

    @property
    def resource_type(self):
        r"""Gets the resource_type of this ResetAccountPasswordRequestBody.

        资源类型

        :return: The resource_type of this ResetAccountPasswordRequestBody.
        :rtype: str
        """
        return self._resource_type

    @resource_type.setter
    def resource_type(self, resource_type):
        r"""Sets the resource_type of this ResetAccountPasswordRequestBody.

        资源类型

        :param resource_type: The resource_type of this ResetAccountPasswordRequestBody.
        :type resource_type: str
        """
        self._resource_type = resource_type

    @property
    def instance_type(self):
        r"""Gets the instance_type of this ResetAccountPasswordRequestBody.

        实例类型

        :return: The instance_type of this ResetAccountPasswordRequestBody.
        :rtype: str
        """
        return self._instance_type

    @instance_type.setter
    def instance_type(self, instance_type):
        r"""Sets the instance_type of this ResetAccountPasswordRequestBody.

        实例类型

        :param instance_type: The instance_type of this ResetAccountPasswordRequestBody.
        :type instance_type: str
        """
        self._instance_type = instance_type

    @property
    def accounts_password_change_status(self):
        r"""Gets the accounts_password_change_status of this ResetAccountPasswordRequestBody.

        需要改密的账号的状态，枚举值  TO_BE_CHANGED：待改密 FAILED：改密失败 SUCCESSFUL：改密成功 PROCESSING：改密中  不传默认修改所有状态的账号

        :return: The accounts_password_change_status of this ResetAccountPasswordRequestBody.
        :rtype: list[str]
        """
        return self._accounts_password_change_status

    @accounts_password_change_status.setter
    def accounts_password_change_status(self, accounts_password_change_status):
        r"""Sets the accounts_password_change_status of this ResetAccountPasswordRequestBody.

        需要改密的账号的状态，枚举值  TO_BE_CHANGED：待改密 FAILED：改密失败 SUCCESSFUL：改密成功 PROCESSING：改密中  不传默认修改所有状态的账号

        :param accounts_password_change_status: The accounts_password_change_status of this ResetAccountPasswordRequestBody.
        :type accounts_password_change_status: list[str]
        """
        self._accounts_password_change_status = accounts_password_change_status

    @property
    def resources_id(self):
        r"""Gets the resources_id of this ResetAccountPasswordRequestBody.

        实例id列表

        :return: The resources_id of this ResetAccountPasswordRequestBody.
        :rtype: list[str]
        """
        return self._resources_id

    @resources_id.setter
    def resources_id(self, resources_id):
        r"""Sets the resources_id of this ResetAccountPasswordRequestBody.

        实例id列表

        :param resources_id: The resources_id of this ResetAccountPasswordRequestBody.
        :type resources_id: list[str]
        """
        self._resources_id = resources_id

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ResetAccountPasswordRequestBody):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
