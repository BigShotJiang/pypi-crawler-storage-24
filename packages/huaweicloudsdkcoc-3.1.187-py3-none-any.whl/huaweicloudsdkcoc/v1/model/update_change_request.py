# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class UpdateChangeRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'change_id': 'str',
        'body': 'CocUpdateChangeRequestBodyV2'
    }

    attribute_map = {
        'change_id': 'change_id',
        'body': 'body'
    }

    def __init__(self, change_id=None, body=None):
        r"""UpdateChangeRequest

        The model defined in huaweicloud sdk

        :param change_id: 变更单id
        :type change_id: str
        :param body: Body of the UpdateChangeRequest
        :type body: :class:`huaweicloudsdkcoc.v1.CocUpdateChangeRequestBodyV2`
        """
        
        

        self._change_id = None
        self._body = None
        self.discriminator = None

        self.change_id = change_id
        if body is not None:
            self.body = body

    @property
    def change_id(self):
        r"""Gets the change_id of this UpdateChangeRequest.

        变更单id

        :return: The change_id of this UpdateChangeRequest.
        :rtype: str
        """
        return self._change_id

    @change_id.setter
    def change_id(self, change_id):
        r"""Sets the change_id of this UpdateChangeRequest.

        变更单id

        :param change_id: The change_id of this UpdateChangeRequest.
        :type change_id: str
        """
        self._change_id = change_id

    @property
    def body(self):
        r"""Gets the body of this UpdateChangeRequest.

        :return: The body of this UpdateChangeRequest.
        :rtype: :class:`huaweicloudsdkcoc.v1.CocUpdateChangeRequestBodyV2`
        """
        return self._body

    @body.setter
    def body(self, body):
        r"""Sets the body of this UpdateChangeRequest.

        :param body: The body of this UpdateChangeRequest.
        :type body: :class:`huaweicloudsdkcoc.v1.CocUpdateChangeRequestBodyV2`
        """
        self._body = body

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, UpdateChangeRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
