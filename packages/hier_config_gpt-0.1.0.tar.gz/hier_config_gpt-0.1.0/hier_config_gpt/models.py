from hier_config.models import MatchRule
from pydantic import BaseModel


class GPTRemediationExample(BaseModel):
    running_config: str
    remediation_config: str


class GPTRemediationRule(BaseModel):
    description: str
    lineage: tuple[MatchRule, ...]
    example: GPTRemediationExample


class GPTRemediationContext(BaseModel):
    description: str
    running_config: str
    generated_config: str
    example: GPTRemediationExample
