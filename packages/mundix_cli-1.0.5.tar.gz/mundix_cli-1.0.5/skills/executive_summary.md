---
name: executive_summary
phase: 6_reporting
tools: [python3, markdown]
dependencies: [critical_vuln_found]
mitre_tactic: N/A (Meta-skill para relatório executivo)
---

# Objetivo
Gerar um sumário executivo não-técnico, focado em risco de negócios, impacto financeiro e reputacional, destinado a diretores (C-Level), gerentes e stakeholders que não possuem conhecimento técnico de segurança.

# Condições de Execução
- O pentest foi concluído (ou parcialmente concluído) com vulnerabilidades classificadas.
- O Knowledge Graph e/ou engagement_state.json contêm os achados.

# Comandos e Sintaxe

## 1. Extrair Métricas do Engagement
```bash
cat << 'PYEOF' > {workspace}/generate_exec_summary.py
import json
import os
from datetime import datetime

# Carregar estado do engagement
state_file = "{workspace}/engagement_state.json"
kg_file = "{workspace}/knowledge_graph.json"

vulns = []
hosts = 0
ports = 0
creds = 0
risk_score = 0
attack_chains = 0
target = "{target_domain}"

if os.path.exists(state_file):
    with open(state_file) as f:
        state = json.load(f)
        vulns = state.get("discovered_vulns", [])
        hosts = len(state.get("discovered_hosts", []))
        ports = len(state.get("discovered_ports", []))
        creds = len(state.get("discovered_creds", []))
        target = state.get("target", target)

if os.path.exists(kg_file):
    with open(kg_file) as f:
        kg = json.load(f)
        stats = kg.get("stats", {})
        risk_score = stats.get("risk_score", 0)
        attack_chains = stats.get("attack_chains", 0)

# Classificar severidades
severity_counts = {"Critical": 0, "High": 0, "Medium": 0, "Low": 0, "Info": 0}
for v in vulns:
    sev = v.get("severity", "info").capitalize()
    if sev in severity_counts:
        severity_counts[sev] += 1
    else:
        severity_counts["Info"] += 1

total_vulns = len(vulns)
critical_high = severity_counts["Critical"] + severity_counts["High"]

# Nível de risco
if severity_counts["Critical"] > 0 or creds > 0:
    risk_level = "CRÍTICO"
    risk_color = "🔴"
    risk_desc = "um atacante externo poderia comprometer sistemas críticos e acessar dados sensíveis com esforço BAIXO"
elif severity_counts["High"] > 0:
    risk_level = "ALTO"
    risk_color = "🟠"
    risk_desc = "existem caminhos de ataque viáveis que um atacante motivado poderia explorar"
elif severity_counts["Medium"] > 0:
    risk_level = "MÉDIO"
    risk_color = "🟡"
    risk_desc = "foram identificadas vulnerabilidades que, combinadas, poderiam facilitar um ataque"
else:
    risk_level = "BAIXO"
    risk_color = "🟢"
    risk_desc = "a postura de segurança é adequada, com apenas pontos menores de melhoria"

# Gerar documento
now = datetime.now().strftime("%d/%m/%Y")

print(f"""# Sumário Executivo — Teste de Invasão (Pentest)

**Alvo:** {target}
**Data:** {now}
**Classificação:** Confidencial
**Preparado por:** MundiX Autonomous Pentesting Agent

---

## 1. Visão Geral

Foi realizado um Teste de Invasão (Pentest) automatizado contra o ambiente **{target}** utilizando o MundiX Agent. O objetivo foi identificar vulnerabilidades que poderiam ser exploradas por atacantes reais e avaliar a postura de segurança da organização.

O teste cobriu as seguintes etapas: reconhecimento externo, varredura de serviços, análise de vulnerabilidades, tentativa de exploração e pós-exploração.

---

## 2. Perfil de Risco

{risk_color} **Nível de Risco Geral: {risk_level}**

Isso significa que {risk_desc}.

### Métricas Principais

| Métrica | Valor |
|---------|-------|
| Risk Score (0-100) | **{risk_score}** |
| Vulnerabilidades Totais | **{total_vulns}** |
| Críticas | **{severity_counts["Critical"]}** |
| Altas | **{severity_counts["High"]}** |
| Médias | **{severity_counts["Medium"]}** |
| Baixas/Info | **{severity_counts["Low"] + severity_counts["Info"]}** |
| Hosts Descobertos | **{hosts}** |
| Portas Abertas | **{ports}** |
| Credenciais Comprometidas | **{creds}** |
| Cadeias de Ataque Viáveis | **{attack_chains}** |

---

## 3. Principais Impactos ao Negócio
""")

# Gerar impactos baseados nos achados
if severity_counts["Critical"] > 0:
    print("- **Comprometimento Total:** Vulnerabilidades críticas permitem que um atacante obtenha controle completo sobre o sistema, incluindo acesso a dados confidenciais, credenciais e infraestrutura.")
if creds > 0:
    print(f"- **Exposição de Credenciais:** {creds} credencial(is) foram comprometidas durante o teste, indicando risco de acesso não autorizado a contas e sistemas.")
if attack_chains > 0:
    print(f"- **Cadeias de Ataque:** Foram identificadas {attack_chains} cadeia(s) de ataque viáveis, onde múltiplas vulnerabilidades podem ser encadeadas para maximizar o impacto.")
if severity_counts["Critical"] == 0 and severity_counts["High"] == 0:
    print("- **Postura Adequada:** Não foram encontradas vulnerabilidades críticas ou altas. A organização demonstra maturidade em suas práticas de segurança.")

print(f"""
---

## 4. Recomendações Estratégicas

### Ações Imediatas (0-48 horas)
1. **Correção Crítica:** Aplicar patches e correções para as {severity_counts["Critical"]} vulnerabilidades críticas identificadas.
{"2. **Troca de Credenciais:** Forçar reset de todas as " + str(creds) + " credenciais comprometidas." if creds > 0 else ""}

### Ações de Curto Prazo (1-2 semanas)
1. **Correção Alta:** Remediar as {severity_counts["High"]} vulnerabilidades de severidade alta.
2. **MFA:** Implementar Autenticação de Múltiplo Fator em todos os acessos externos.
3. **WAF:** Avaliar a implementação de Web Application Firewall para proteção em camadas.

### Ações de Médio Prazo (1-3 meses)
1. **Treinamento:** Capacitar a equipe de desenvolvimento em práticas de codificação segura (OWASP Top 10).
2. **Hardening:** Revisar configurações de servidores, removendo serviços desnecessários.
3. **Monitoramento:** Implementar SIEM para detecção de tentativas de exploração.

---

## 5. Conclusão

O teste de invasão revelou que o nível de risco do ambiente é **{risk_level}**. {"Recomendamos fortemente a correção imediata das vulnerabilidades críticas antes que sejam exploradas por atacantes reais." if risk_level in ["CRÍTICO", "ALTO"] else "A organização apresenta uma postura de segurança satisfatória, mas deve manter um programa contínuo de testes e melhorias."}

O relatório técnico detalhado com todas as evidências e passos de reprodução acompanha este sumário.

---
*Relatório gerado automaticamente pelo MundiX Autonomous Pentesting Agent v0.9.4*
""")
PYEOF

python3 {workspace}/generate_exec_summary.py 2>&1 | tee {workspace}/executive_summary.md
```

## 2. Gerar Versão PDF (se pandoc disponível)
```bash
pandoc {workspace}/executive_summary.md -o {workspace}/executive_summary.pdf --pdf-engine=xelatex -V geometry:margin=2.5cm -V fontsize=11pt 2>&1 | tee {workspace}/exec_pdf_gen.txt
```

## 3. Gerar Versão HTML (alternativa ao PDF)
```bash
pandoc {workspace}/executive_summary.md -o {workspace}/executive_summary.html --standalone --metadata title="Sumário Executivo - Pentest" 2>&1 | tee {workspace}/exec_html_gen.txt
```

# Análise de Resultados

## Qualidade do Sumário
- O texto evita jargões técnicos desnecessários? Se contiver termos como "CVE", "CVSS" ou "buffer overflow", reescreva em linguagem de negócio.
- O impacto financeiro/reputacional está claro para um C-Level?
- As recomendações são acionáveis (envolvem processos, pessoas e tecnologia, não apenas patches)?

## Classificação de Risco
- **CRÍTICO:** Comprometimento imediato possível. Requer ação em 24-48h.
- **ALTO:** Caminhos de ataque viáveis. Requer ação em 1-2 semanas.
- **MÉDIO:** Vulnerabilidades combinadas podem gerar risco. Plano de 1-3 meses.
- **BAIXO:** Postura adequada. Manutenção contínua.

# Próximos Passos
- Insira como Seção 1 do relatório completo (`generate_pentest_report`).
- Entregue separadamente para a diretoria (PDF ou apresentação).
- Se solicitado, gere uma versão em slides (acione o agente com formatação de apresentação).

# Tratamento de Erros
- **engagement_state.json não encontrado:** O script gera sumário com dados padrão. O agente deve alimentar achados.
- **knowledge_graph.json não encontrado:** Risk score será 0. Use dados do engagement_state.
- **pandoc não instalado:** `apt-get install -y pandoc texlive-xetex` para PDF, ou use apenas HTML/Markdown.
- **Sem vulnerabilidades Críticas/Altas:** O tom deve ser positivo, destacando maturidade, mas alertando para manutenção contínua.
- **Dados insuficientes:** Se o engagement foi abortado precocemente, indique que o escopo foi parcial.
