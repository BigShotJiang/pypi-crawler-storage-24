"""Intent-to-REST bridge scaffolding for company agent proxies."""

from .adapter import RESTIntentAdapter
from .proxy import CompanyAgentProxy
from .registry import AdapterRegistry
from .types import AdapterCall, AdapterResult, B2AIntent

__all__ = [
    "AdapterCall",
    "AdapterRegistry",
    "AdapterResult",
    "B2AIntent",
    "CompanyAgentProxy",
    "RESTIntentAdapter",
]
