"""Built-in adapter examples."""

from .acme_orders import AcmeOrdersAdapter

__all__ = ["AcmeOrdersAdapter"]
