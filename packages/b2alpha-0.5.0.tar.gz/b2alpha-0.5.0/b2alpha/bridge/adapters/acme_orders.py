"""Example adapter mapping B2A intents to a third-party orders REST API."""

from __future__ import annotations

from ..adapter import RESTIntentAdapter
from ..types import AdapterCall, B2AIntent


class AcmeOrdersAdapter(RESTIntentAdapter):
    """Example adapter with two intent mappings:

    - `order.create` -> `POST /orders`
    - `order.status` -> `GET /orders/{order_id}`
    """

    name = "acme-orders"
    intent_patterns = ("order.create", "order.status")

    def build_call(self, intent: B2AIntent) -> AdapterCall:
        api_key = str(intent.metadata.get("acme_api_key", "")).strip()
        headers = {"X-API-Key": api_key} if api_key else {}

        if intent.intent == "order.create":
            sku = str(intent.params.get("sku", "")).strip()
            quantity = int(intent.params.get("quantity", 1))
            customer_id = str(intent.params.get("customer_id", "")).strip()
            if not sku:
                raise ValueError("order.create requires param 'sku'")
            return AdapterCall(
                method="POST",
                path="/orders",
                headers=headers,
                json_body={
                    "sku": sku,
                    "quantity": quantity,
                    "customer_id": customer_id or None,
                },
            )

        if intent.intent == "order.status":
            order_id = str(intent.params.get("order_id", "")).strip()
            if not order_id:
                raise ValueError("order.status requires param 'order_id'")
            return AdapterCall(
                method="GET",
                path=f"/orders/{order_id}",
                headers=headers,
            )

        raise ValueError(f"unsupported intent '{intent.intent}' for {self.name}")

