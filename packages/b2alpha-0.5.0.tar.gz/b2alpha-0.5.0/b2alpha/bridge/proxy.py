"""Company-agent proxy dispatcher."""

from __future__ import annotations

from typing import Any, Mapping

from .registry import AdapterRegistry
from .types import AdapterResult, B2AIntent


class CompanyAgentProxy:
    """Dispatches B2A intents through the adapter bridge."""

    def __init__(
        self,
        *,
        base_url: str,
        registry: AdapterRegistry,
        default_headers: Mapping[str, str] | None = None,
    ) -> None:
        self.base_url = base_url
        self.registry = registry
        self.default_headers = dict(default_headers or {})

    def dispatch(
        self,
        intent: str,
        params: Mapping[str, Any] | None = None,
        metadata: Mapping[str, Any] | None = None,
    ) -> AdapterResult:
        adapter = self.registry.resolve(intent)
        message = B2AIntent(
            intent=intent,
            params=dict(params or {}),
            metadata=dict(metadata or {}),
        )
        return adapter.execute(
            message,
            base_url=self.base_url,
            shared_headers=self.default_headers,
        )

