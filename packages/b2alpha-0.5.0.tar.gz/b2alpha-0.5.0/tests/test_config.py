"""Tests for b2alpha.config – local state management."""

from __future__ import annotations

import json

import pytest


class TestLoadSaveJson:
    def test_load_missing_file_returns_empty(self, tmp_path):
        from b2alpha.config import load_json
        assert load_json(tmp_path / "nope.json") == {}

    def test_save_and_load_roundtrip(self, tmp_path, monkeypatch):
        import b2alpha.config as cfg
        monkeypatch.setattr(cfg, "B2A_DIR", tmp_path)
        monkeypatch.setattr(cfg, "KEYS_DIR", tmp_path / "keys")

        from b2alpha.config import save_json, load_json
        path = tmp_path / "test.json"
        data = {"foo": "bar", "n": 42}
        save_json(path, data)
        assert load_json(path) == data

    def test_save_creates_parent_dirs(self, tmp_path, monkeypatch):
        import b2alpha.config as cfg
        nested = tmp_path / "deep" / "nested"
        monkeypatch.setattr(cfg, "B2A_DIR", nested)
        monkeypatch.setattr(cfg, "KEYS_DIR", nested / "keys")

        from b2alpha.config import save_json
        save_json(nested / "data.json", {"ok": True})
        assert (nested / "data.json").exists()


class TestEnvConfig:
    def test_defaults(self):
        from b2alpha.config import load_env_config
        url, key = load_env_config()
        assert url.startswith("https://")
        assert len(key) > 0

    def test_env_override(self, monkeypatch):
        monkeypatch.setenv("B2A_SUPABASE_URL", "https://test.supabase.co")
        monkeypatch.setenv("B2A_SUPABASE_ANON_KEY", "test-key-123")

        from b2alpha.config import load_env_config
        url, key = load_env_config()
        assert url == "https://test.supabase.co"
        assert key == "test-key-123"


class TestAccessors:
    def test_get_access_token_when_missing(self, tmp_path, monkeypatch):
        import b2alpha.config as cfg
        monkeypatch.setattr(cfg, "AUTH_FILE", tmp_path / "auth.json")

        from b2alpha.config import get_access_token
        assert get_access_token() is None

    def test_get_access_token_when_present(self, tmp_path, monkeypatch):
        import b2alpha.config as cfg
        auth_file = tmp_path / "auth.json"
        auth_file.write_text(json.dumps({"access_token": "tok123"}))
        monkeypatch.setattr(cfg, "AUTH_FILE", auth_file)

        from b2alpha.config import get_access_token
        assert get_access_token() == "tok123"

    def test_get_active_did_when_missing(self, tmp_path, monkeypatch):
        import b2alpha.config as cfg
        monkeypatch.setattr(cfg, "PROFILE_FILE", tmp_path / "profile.json")

        from b2alpha.config import get_active_did
        assert get_active_did() is None

    def test_get_active_did_when_present(self, tmp_path, monkeypatch):
        import b2alpha.config as cfg
        pf = tmp_path / "profile.json"
        pf.write_text(json.dumps({"did": "did:b2a:zTest"}))
        monkeypatch.setattr(cfg, "PROFILE_FILE", pf)

        from b2alpha.config import get_active_did
        assert get_active_did() == "did:b2a:zTest"

    def test_get_profile(self, tmp_path, monkeypatch):
        import b2alpha.config as cfg
        pf = tmp_path / "profile.json"
        pf.write_text(json.dumps({"did": "did:b2a:zX", "display_name": "Bot"}))
        monkeypatch.setattr(cfg, "PROFILE_FILE", pf)

        from b2alpha.config import get_profile
        p = get_profile()
        assert p["did"] == "did:b2a:zX"
        assert p["display_name"] == "Bot"
