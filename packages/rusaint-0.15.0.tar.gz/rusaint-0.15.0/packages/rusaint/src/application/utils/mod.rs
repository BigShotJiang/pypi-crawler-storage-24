pub(crate) mod de_with;
pub(crate) mod input_field;
pub(crate) mod oz;
pub(crate) mod popup;
pub(crate) mod sap_table;
pub(crate) mod semester;
