#%%
import jzukaku
# %%
jzukaku.latlon_to_zukaku(43.068564, 141.350726, 12).code
# %%
jzukaku.latlon_to_zukaku(44.068564, 141.350726, 12).code
# %%
bounds = [43.068564, 141.350726, 44.068564, 141.350726]
bbox = jzukaku.bbox_to_zukaku(bounds)
# %%
bbox
# %%
