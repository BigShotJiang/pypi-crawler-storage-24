# Exceptions

::: boostylib.http.exceptions.BoostyError

::: boostylib.http.exceptions.BoostyAuthError

::: boostylib.http.exceptions.BoostyForbiddenError

::: boostylib.http.exceptions.BoostyNotFoundError

::: boostylib.http.exceptions.BoostyRateLimitError

::: boostylib.http.exceptions.BoostyServerError

::: boostylib.http.exceptions.BoostyNetworkError
