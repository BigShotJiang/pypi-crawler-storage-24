# Events

## EventDispatcher

::: boostylib.events.dispatcher.EventDispatcher

## EventPoller

::: boostylib.events.poller.EventPoller

## Event Models

### Event (base)

::: boostylib.events.models.Event

### DonationEvent

::: boostylib.events.models.DonationEvent

### SubscriptionEvent

::: boostylib.events.models.SubscriptionEvent

### CommentEvent

::: boostylib.events.models.CommentEvent

## EventType Enum

::: boostylib.enums.EventType
