# PostBuilder

::: boostylib.builders.post_builder.PostBuilder
    options:
      members:
        - __init__
        - title
        - text
        - image
        - video
        - audio
        - file
        - link
        - free
        - access_level
        - minimum_donation
        - subscribers_only
        - tags
        - teaser
        - scheduled_at
        - build
