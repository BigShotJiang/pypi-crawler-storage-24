"""Synchronous wrapper for BoostyClient."""

from boostylib.sync.client import SyncBoostyClient

__all__ = ["SyncBoostyClient"]
