from __future__ import annotations
import json
from typing import Any, Optional
from IPython.display import HTML, display


# =====================================================================
#  GLOBAL CSS + JS  (injected once per render)
# =====================================================================
STYLE = """
<style>
/* ── base font ── */
.eco-wrap * { box-sizing:border-box; }
.eco-wrap {
  font-family:system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;
  font-size:14px; color:#e8ffe8;
}

/* ── pill bar ── */
.eco-pill-row {
  display:flex; gap:10px; align-items:center; margin-top:8px; flex-wrap:wrap;
}
.eco-pill {
  display:inline-flex; align-items:center; gap:8px;
  background:linear-gradient(135deg,#0f2010,#182818);
  border:1px solid #2a4a2a; padding:7px 16px; border-radius:24px;
  cursor:pointer; transition:all .18s;
  box-shadow:0 2px 8px rgba(0,0,0,.4);
}
.eco-pill:hover { border-color:#3effaa; transform:translateY(-1px); }
.eco-pill:active { transform:scale(.97); opacity:.8; }
.eco-pill.warn  { border-color:#c9a400!important; }
.eco-pill.hot   { border-color:#e74c3c!important; }

.eco-pill-icon {
  width:22px; height:22px; border-radius:50%;
  display:flex; align-items:center; justify-content:center;
  font-size:14px; background:#1a5c2a; flex-shrink:0;
}
.eco-pill.warn .eco-pill-icon  { background:#5c4a00; }
.eco-pill.hot  .eco-pill-icon  { background:#5c1a00; }

.eco-pill-label { font-weight:700; font-size:13px; }
.eco-pill-hint  { font-size:11px; opacity:.55; }

/* ── expandable box ── */
.eco-box {
  border-radius:12px; background:#0c1a0c;
  border:1px solid #1e3a1e; padding:16px;
  display:none; margin-top:6px;
  box-shadow:inset 0 1px 0 rgba(255,255,255,.04);
}

/* ── section header ── */
.eco-sec-title {
  font-size:11px; font-weight:700; letter-spacing:.08em;
  text-transform:uppercase; color:#3effaa;
  margin:0 0 10px; opacity:.8;
}

/* ── metric table ── */
.eco-tbl {
  width:100%; border-collapse:collapse; font-size:13px;
}
.eco-tbl td {
  padding:5px 4px; border-bottom:1px solid #1a2e1a;
  vertical-align:middle;
}
.eco-tbl tr:last-child td { border-bottom:none; }
.eco-tbl td:first-child { color:#7ab87a; font-weight:500; width:44%; }
.eco-tbl td:last-child  { font-weight:600; }

/* ── eco score bar ── */
.eco-score-wrap { margin-top:12px; }
.eco-score-label { font-size:12px; color:#7ab87a; margin-bottom:4px; }
.eco-score-track {
  height:7px; background:#1a2e1a; border-radius:10px; overflow:hidden;
}
.eco-score-fill {
  height:100%; width:0%;
  background:linear-gradient(90deg,#12ff6e,#00d4aa);
  border-radius:10px; transition:width .4s ease;
}

/* ── confidence badge ── */
.eco-conf {
  display:inline-block; padding:1px 8px; border-radius:999px;
  font-size:11px; font-weight:700; margin-left:6px; vertical-align:2px;
}
.eco-conf-high { background:#0d2a0d; color:#4eff91; border:1px solid #2ecc71; }
.eco-conf-med  { background:#2a2000; color:#f1c40f; border:1px solid #c9a400; }
.eco-conf-low  { background:#2a0000; color:#ff7070; border:1px solid #e74c3c; }

/* ── compare modal overlay ── */
.eco-modal-overlay {
  display:none; position:fixed; inset:0; z-index:99999;
  background:rgba(0,0,0,.75); backdrop-filter:blur(4px);
  align-items:center; justify-content:center;
}
.eco-modal-overlay.open { display:flex; }

.eco-modal {
  background:#0d1d0d; border:1px solid #2a4a2a; border-radius:16px;
  padding:24px; width:min(700px,94vw); max-height:88vh; overflow-y:auto;
  box-shadow:0 24px 64px rgba(0,0,0,.7);
  font-family:system-ui,-apple-system,sans-serif; color:#e8ffe8;
  animation: ecoModalIn .22s ease;
}
@keyframes ecoModalIn {
  from { transform:translateY(20px); opacity:0; }
  to   { transform:translateY(0);    opacity:1; }
}

.eco-modal-title {
  font-size:17px; font-weight:700; margin:0 0 18px; color:#3effaa;
  display:flex; align-items:center; gap:10px;
}
.eco-modal-close {
  margin-left:auto; cursor:pointer; font-size:20px;
  color:#7ab87a; line-height:1; background:none; border:none;
  padding:0 2px;
}
.eco-modal-close:hover { color:#fff; }

/* ── comparison columns ── */
.eco-cmp-grid {
  display:grid; grid-template-columns:1fr 1fr; gap:16px;
  margin-bottom:18px;
}
.eco-cmp-col {
  background:#121f12; border-radius:10px; padding:14px;
  border:1px solid #1e3a1e;
}
.eco-cmp-col.winner { border-color:#2ecc71; background:#0c1e0c; }
.eco-cmp-col-title {
  font-size:13px; font-weight:700; margin:0 0 10px;
  display:flex; align-items:center; gap:6px;
}
.eco-badge-win {
  font-size:10px; background:#2ecc71; color:#001a00;
  border-radius:999px; padding:1px 7px; font-weight:700;
}

/* ── bar comparison rows ── */
.eco-bar-row { margin-bottom:10px; }
.eco-bar-label { font-size:11px; color:#7ab87a; margin-bottom:3px; }
.eco-bar-track {
  height:8px; background:#1a2e1a; border-radius:6px; overflow:hidden;
}
.eco-bar-fill {
  height:100%; border-radius:6px; transition:width .6s ease;
}
.eco-bar-val { font-size:12px; font-weight:700; margin-top:3px; }

/* winner bar = green, loser = amber */
.eco-bar-fill.good { background:linear-gradient(90deg,#12ff6e,#00d4aa); }
.eco-bar-fill.warn { background:linear-gradient(90deg,#f1c40f,#e67e00); }

/* ── savings banner ── */
.eco-savings-banner {
  background:linear-gradient(135deg,#0a2a0a,#122012);
  border:1px solid #2ecc71; border-radius:10px; padding:14px 18px;
  display:flex; align-items:center; gap:14px; margin-bottom:16px;
}
.eco-savings-banner .eco-s-icon { font-size:28px; }
.eco-savings-banner .eco-s-text { font-size:13px; line-height:1.5; }
.eco-savings-banner .eco-s-text strong { color:#3effaa; font-size:15px; }

/* ── compare trigger btn ── */
.eco-cmp-btn {
  display:inline-flex; align-items:center; gap:6px;
  margin-top:10px; padding:6px 14px; border-radius:999px;
  background:#121f12; border:1px solid #2a4a2a;
  font-size:12px; cursor:pointer; color:#7ab87a;
  transition:all .18s;
}
.eco-cmp-btn:hover { border-color:#3effaa; color:#3effaa; }
</style>

<script>
/* global toggle for metric boxes */
if(!window._ecoToggle){
  window._ecoToggle = function(id, fillId, score){
    const box  = document.getElementById(id);
    const fill = document.getElementById(fillId);
    if(!box) return;
    const isOpen = box.style.display === 'block';
    box.style.display = isOpen ? 'none' : 'block';
    if(fill) fill.style.width = isOpen ? '0%' : score + '%';
  };
}

/* compare modal */
if(!window._ecoOpenCompare){
  window._ecoOpenCompare = function(cid){
    const overlay = document.getElementById('eco-modal-' + cid);
    if(overlay){ overlay.classList.add('open'); }
  };
  window._ecoCloseCompare = function(cid){
    const overlay = document.getElementById('eco-modal-' + cid);
    if(overlay){ overlay.classList.remove('open'); }
  };
}

/* animate bars after modal open */
if(!window._ecoAnimateBars){
  window._ecoAnimateBars = function(cid){
    window._ecoOpenCompare(cid);
    setTimeout(function(){
      document.querySelectorAll('#eco-modal-' + cid + ' .eco-bar-fill').forEach(function(el){
        el.style.width = el.dataset.pct + '%';
      });
    }, 80);
  };
}
</script>
"""


# =====================================================================
def _fmt(x, d=3):
    try: return f"{float(x):.{d}f}"
    except: return "—"


def _eco_score(cpu, gpu, gpu_temp, cpu_temp, runtime, ram_pct, co2_g) -> int:
    import math
    score = 100.0
    score -= min(20, cpu  * 0.20)
    score -= min(20, gpu  * 0.20)
    score -= min(15, max(0, max(gpu_temp, cpu_temp) - 70))
    if runtime > 1:
        score -= min(15, math.log(runtime) * 3)
    score -= min(10, max(0, ram_pct - 70) * 0.5)
    score -= min(15, max(0, co2_g - 1.0) * 2)
    return max(0, min(100, int(score)))


def _conf_badge(confidence) -> str:
    try:
        c = float(confidence)
    except:
        return ""
    if c >= 0.80:
        return f"<span class='eco-conf eco-conf-high'>{c:.0%}</span>"
    elif c >= 0.55:
        return f"<span class='eco-conf eco-conf-med'>{c:.0%}</span>"
    else:
        return f"<span class='eco-conf eco-conf-low'>{c:.0%}</span>"


def _compare_modal(cid: int, cmp: dict) -> str:
    """Render CPU vs GPU compare modal with an animated Canvas bar chart."""
    if not cmp:
        return ""

    import json as _json

    cur_hw  = cmp.get("current_hw", "CPU")
    alt_hw  = cmp.get("alt_hw",    "GPU")
    speedup = float(cmp.get("speedup", 1.0))
    saved   = float(cmp.get("co2_saved_pct", 0.0))

    cur_runtime = float(cmp.get("current_runtime", 1) or 1)
    alt_runtime = float(cmp.get("alt_runtime",     1) or 1)
    cur_wins    = cur_runtime <= alt_runtime

    if not cur_wins:
        savings_text = (
            f"<strong>Switching to {alt_hw} saves ~{abs(saved):.0f}% CO\u2082</strong> "
            f"and makes training <strong>~{speedup:.0f}\u00d7 faster</strong> "
            f"for image / deep-learning workloads."
        )
        savings_icon = "\U0001f680"
    else:
        savings_text = (
            f"Your current <strong>{cur_hw} setup is optimal</strong> for this workload. "
            f"{alt_hw} would be <strong>{speedup:.0f}\u00d7 slower</strong>."
        )
        savings_icon = "\u2705"

    # chart data serialised for JS
    chart_data = _json.dumps({
        "labels":   ["Runtime (s)", "Energy (mWh)", "CO\u2082 (mg)", "Power (W)"],
        "cur_hw":   cur_hw,
        "alt_hw":   alt_hw + " (est.)",
        "cur_vals": [
            round(float(cmp.get("current_runtime",   0) or 0), 4),
            round(float(cmp.get("current_energy_wh", 0) or 0) * 1000, 4),
            round(float(cmp.get("current_co2_g",     0) or 0) * 1000, 6),
            round(float(cmp.get("current_power_w",   0) or 0), 2),
        ],
        "alt_vals": [
            round(float(cmp.get("alt_runtime",   0) or 0), 4),
            round(float(cmp.get("alt_energy_wh", 0) or 0) * 1000, 4),
            round(float(cmp.get("alt_co2_g",     0) or 0) * 1000, 6),
            round(float(cmp.get("alt_power_w",   0) or 0), 2),
        ],
    })

    canvas_id = f"eco-chart-{cid}"

    # NOTE: double {{ }} inside f-string escapes to literal { } for JS
    return f"""
<div class='eco-modal-overlay' id='eco-modal-{cid}'
     onclick='if(event.target===this)_ecoCloseCompare({cid})'>
  <div class='eco-modal'>

    <div class='eco-modal-title'>
      \U0001f4ca {cur_hw} vs {alt_hw} \u2014 Performance Comparison
      <button class='eco-modal-close' onclick='_ecoCloseCompare({cid})'>\u2715</button>
    </div>

    <div class='eco-savings-banner'>
      <div class='eco-s-icon'>{savings_icon}</div>
      <div class='eco-s-text'>{savings_text}</div>
    </div>

    <canvas id='{canvas_id}' width='620' height='300'
      style='width:100%;height:auto;display:block;border-radius:8px;
             margin:0 auto 6px;background:#0c1a0c'></canvas>

    <div style='display:flex;gap:20px;justify-content:center;
                margin-bottom:10px;font-size:12px;color:#c0e0c0'>
      <span><span style='display:inline-block;width:12px;height:12px;border-radius:3px;
        background:linear-gradient(135deg,#12ff6e,#00d4aa);margin-right:5px;
        vertical-align:-2px'></span>{cur_hw}</span>
      <span><span style='display:inline-block;width:12px;height:12px;border-radius:3px;
        background:linear-gradient(135deg,#f1c40f,#e67e00);margin-right:5px;
        vertical-align:-2px'></span>{alt_hw} (est.)</span>
    </div>

    <div style='font-size:11px;opacity:.4;line-height:1.5;text-align:center'>
      \u24d8 Estimates assume ~{speedup:.0f}\u00d7 GPU speedup for CNN / image-classification workloads.
    </div>
  </div>
</div>

<script>
(function(){{
  var DATA = {chart_data};
  var canvas = document.getElementById('{canvas_id}');
  if(!canvas) return;
  var ctx = canvas.getContext('2d');
  var W = canvas.width, H = canvas.height;

  var labels  = DATA.labels;
  var curV    = DATA.cur_vals;
  var altV    = DATA.alt_vals;
  var n       = labels.length;

  var PAD_L = 46, PAD_R = 18, PAD_T = 36, PAD_B = 52;
  var cW = W - PAD_L - PAD_R;
  var cH = H - PAD_T - PAD_B;

  var groupW = cW / n;
  var barW   = groupW * 0.28;
  var gap    = groupW * 0.07;

  var GREEN1 = '#12ff6e', GREEN2 = '#00d4aa';
  var AMBER1 = '#f1c40f', AMBER2 = '#e67e00';
  var TEXT   = 'rgba(200,255,200,0.85)';
  var GRID   = 'rgba(255,255,255,0.06)';

  var prog = 0;

  function draw(p) {{
    ctx.clearRect(0, 0, W, H);

    // grid
    for(var g = 0; g <= 4; g++) {{
      var gy = PAD_T + cH - cH * g / 4;
      ctx.strokeStyle = GRID;
      ctx.lineWidth = 1;
      ctx.beginPath(); ctx.moveTo(PAD_L, gy); ctx.lineTo(PAD_L + cW, gy); ctx.stroke();
    }}

    for(var i = 0; i < n; i++) {{
      var mx = Math.max(curV[i], altV[i], 1e-12);
      var cx = PAD_L + i * groupW + groupW / 2;
      var x1 = cx - gap / 2 - barW;   // current hw bar
      var x2 = cx + gap / 2;           // alt hw bar

      var hA = (curV[i] / mx) * cH * p;
      var hB = (altV[i] / mx) * cH * p;
      var yA = PAD_T + cH - hA;
      var yB = PAD_T + cH - hB;

      // current wins if it has lower value (runtime/energy/co2/power)
      var curWins = curV[i] <= altV[i];

      // bar A
      var gA = ctx.createLinearGradient(x1, yA, x1, PAD_T + cH);
      gA.addColorStop(0, curWins ? GREEN1 : AMBER1);
      gA.addColorStop(1, curWins ? GREEN2 : AMBER2);
      ctx.fillStyle = gA;
      ctx.beginPath();
      if(ctx.roundRect) ctx.roundRect(x1, yA, barW, hA, [4,4,0,0]);
      else ctx.rect(x1, yA, barW, hA);
      ctx.fill();

      // bar B
      var gB = ctx.createLinearGradient(x2, yB, x2, PAD_T + cH);
      gB.addColorStop(0, curWins ? AMBER1 : GREEN1);
      gB.addColorStop(1, curWins ? AMBER2 : GREEN2);
      ctx.fillStyle = gB;
      ctx.beginPath();
      if(ctx.roundRect) ctx.roundRect(x2, yB, barW, hB, [4,4,0,0]);
      else ctx.rect(x2, yB, barW, hB);
      ctx.fill();

      // value labels (only when nearly done)
      if(p >= 0.97) {{
        ctx.fillStyle = '#e8ffe8';
        ctx.font = 'bold 10px system-ui,sans-serif';
        ctx.textAlign = 'center';
        var va = curV[i], vb = altV[i];
        ctx.fillText(va >= 1 ? va.toFixed(2) : va.toExponential(1), x1 + barW/2, yA - 5);
        ctx.fillText(vb >= 1 ? vb.toFixed(2) : vb.toExponential(1), x2 + barW/2, yB - 5);
      }}

      // x-axis label
      ctx.fillStyle = 'rgba(180,240,180,0.7)';
      ctx.font = '11px system-ui,sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(labels[i], cx, PAD_T + cH + 20);
    }}

    // baseline
    ctx.strokeStyle = 'rgba(255,255,255,0.15)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(PAD_L, PAD_T + cH); ctx.lineTo(PAD_L + cW, PAD_T + cH);
    ctx.stroke();

    // chart title
    ctx.fillStyle = 'rgba(62,255,170,0.7)';
    ctx.font = 'bold 11px system-ui,sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText(DATA.cur_hw + '  vs  ' + DATA.alt_hw, PAD_L + cW/2, 18);
  }}

  function step() {{
    prog = Math.min(prog + 0.05, 1);
    draw(prog);
    if(prog < 1) requestAnimationFrame(step);
  }}

  setTimeout(step, 80);
}})();
</script>
"""


# =====================================================================
#  CELL HOOK
# =====================================================================
class CellHook:
    def __init__(self, tracker, recommender: Optional[Any] = None):
        self.tracker     = tracker
        self.recommender = recommender

    def register(self):
        from IPython import get_ipython
        sh = get_ipython()
        if not sh:
            print("⚠ Not inside IPython – UI disabled")
            return
        sh.events.register("pre_run_cell",  self._pre)
        sh.events.register("post_run_cell", self._post)
        print("EcoML UI CellHook Registered ✓")

    def _pre(self, *_):
        try: self.tracker.start_cell()
        except: pass

    def _post(self, result):
        code  = getattr(result.info, "raw_cell", None)
        error = result.error_in_exec if result.error_in_exec else None

        try:
            rec = self.tracker.end_cell(
                recommender=self.recommender,
                error=error,
                code=code
            )
        except Exception as e:
            display(HTML(f"<div style='color:#ff4444;font-family:monospace'>EcoML Error: {e}</div>"))
            return

        if not rec:
            return

        # ── pull metrics ──────────────────────────────────────
        runtime    = float(rec.get("runtime_sec",        0) or 0)
        cpu        = float(rec.get("cpu_util_avg",       0) or 0)
        gpu        = float(rec.get("gpu_util_avg",       0) or 0)
        cpu_temp   = float(rec.get("cpu_temp_c",         0) or 0)
        gpu_temp   = float(rec.get("gpu_temp_c",         0) or 0)
        ram_pct    = float(rec.get("ram_used_pct",       0) or 0)
        ram_mb     = float(rec.get("ram_used_mb",        0) or 0)
        vram_pct   = float(rec.get("gpu_mem_used_pct",   0) or 0)
        co2        = float(rec.get("co2_g",              0) or 0)
        energy     = float(rec.get("energy_kwh",         0) or 0)
        confidence = rec.get("recommended_confidence")
        rec_hw     = rec.get("recommended_hardware", "Unknown")
        reasons    = rec.get("recommended_reasons",  "")
        cmp        = rec.get("comparison", {})
        cid        = int(rec.get("cell_id", 0))

        if isinstance(reasons, list):
            reasons = " | ".join(reasons)

        box1  = f"eco-box-co2-{cid}"
        box2  = f"eco-box-rec-{cid}"
        fill1 = f"eco-fill-co2-{cid}"
        fill2 = f"eco-fill-rec-{cid}"

        max_temp = max(gpu_temp, cpu_temp)
        pill_cls = "hot" if max_temp > 90 else ("warn" if max_temp > 75 else "")
        score    = _eco_score(cpu, gpu, gpu_temp, cpu_temp, runtime, ram_pct, co2)

        # ── insights ─────────────────────────────────────────
        insights_html = ""
        if reasons:
            insights_html = "<div class='eco-sec-title'>💡 Insights</div>"
            for line in reasons.split(" | "):
                if line.strip():
                    insights_html += (
                        f"<div style='font-size:12px;margin:4px 0;padding-left:8px;"
                        f"border-left:2px solid #2ecc71;opacity:.9'>{line}</div>"
                    )

        # ── metrics table ────────────────────────────────────
        def row(icon, label, val):
            return f"<tr><td>{icon} {label}</td><td>{val}</td></tr>"

        tbl1 = f"""
        <div class='eco-sec-title'>⚡ Live Metrics</div>
        <table class='eco-tbl'>
          {row("⏱", "Runtime",  _fmt(runtime) + " s")}
          {row("⚡", "Energy",   _fmt(energy, 6) + " kWh")}
          {row("🖥", "CPU",      _fmt(cpu,1) + "%")}
          {row("🎮", "GPU",      _fmt(gpu,1) + "%")}
          {row("🌡️", "CPU Temp", _fmt(cpu_temp,1) + " °C")}
          {row("🌡️", "GPU Temp", _fmt(gpu_temp,1) + " °C")}
          {row("💾", "RAM",      _fmt(ram_pct,1) + f"% ({_fmt(ram_mb,0)} MB)")}
          {row("📦", "VRAM",     _fmt(vram_pct,1) + "%")}
        </table>
        """

        conf_badge = _conf_badge(confidence)
        conf_val   = _fmt(confidence, 2) if confidence is not None else "—"

        tbl2 = f"""
        <div class='eco-sec-title'>🔧 Recommendation</div>
        <table class='eco-tbl'>
          {row("🔧", "Hardware",   f"<b>{rec_hw}</b>{conf_badge}")}
          {row("♻",  "CO₂",       _fmt(co2, 6) + " g")}
          {row("⏱",  "Runtime",   _fmt(runtime) + " s")}
          {row("🎯",  "Confidence", conf_val)}
        </table>
        """

        # ── eco score ────────────────────────────────────────
        score_html = f"""
        <div class='eco-score-wrap'>
          <div class='eco-score-label'>Eco Score &nbsp;<b style='color:#3effaa'>{score}/100</b></div>
          <div class='eco-score-track'>
            <div class='eco-score-fill' id='{fill1}'></div>
          </div>
        </div>
        """

        score_html2 = score_html.replace(fill1, fill2)

        # ── compare button + modal ───────────────────────────
        cmp_modal = _compare_modal(cid, cmp)
        cmp_btn   = (
            f"<button class='eco-cmp-btn' onclick='_ecoAnimateBars({cid})'>"
            f"📊 Compare CPU vs GPU</button>"
        ) if cmp else ""

        # ── full render ───────────────────────────────────────
        html = f"""
{STYLE}
{cmp_modal}

<div class='eco-wrap'>

  <div class='eco-pill-row'>
    <div class='eco-pill {pill_cls}' onclick="_ecoToggle('{box1}','{fill1}',{score})">
      <div class='eco-pill-icon'>🌿</div>
      <div>
        <div class='eco-pill-label'>{_fmt(co2,4)} g CO₂</div>
        <div class='eco-pill-hint'>click for metrics</div>
      </div>
    </div>

    <div class='eco-pill {pill_cls}' onclick="_ecoToggle('{box2}','{fill2}',{score})">
      <div class='eco-pill-icon'>⚙️</div>
      <div>
        <div class='eco-pill-label'>{rec_hw}</div>
        <div class='eco-pill-hint'>click for recommendation</div>
      </div>
    </div>
  </div>

  <div style='display:flex;gap:14px;margin-top:8px;align-items:flex-start;flex-wrap:wrap'>

    <div class='eco-box' id='{box1}' style='flex:1;min-width:240px'>
      {insights_html}
      {tbl1}
      {score_html}
    </div>

    <div class='eco-box' id='{box2}' style='flex:1;min-width:240px'>
      {tbl2}
      {score_html2}
      {cmp_btn}
    </div>

  </div>

</div>
"""
        display(HTML(html))
