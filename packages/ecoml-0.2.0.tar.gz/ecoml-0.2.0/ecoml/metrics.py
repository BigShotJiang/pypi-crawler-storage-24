import psutil

try:
    import GPUtil as _GPUtil
except ImportError:
    _GPUtil = None



# ──────────────────────────────────────────────────────────────
# GPU TEMPERATURE FALLBACK (Windows WMI / OpenHardwareMonitor)
# ──────────────────────────────────────────────────────────────
def _read_gpu_temp_wmi() -> float | None:
    """
    Windows WMI GPU temperature reader.
    Works with NZXT CAM / Open Hardware Monitor running in background.
    """
    try:
        import wmi
        w = wmi.WMI(namespace="root\\OpenHardwareMonitor")
        for sensor in w.Sensor():
            if sensor.SensorType == "Temperature" and "gpu" in sensor.Name.lower():
                return float(sensor.Value)
    except:
        return None


# ──────────────────────────────────────────────────────────────
def get_metrics() -> dict:
    """
    Safe system metric snapshot.
    ALWAYS returns a complete dict so the UI never crashes.

    Keys returned:
        cpu_util_avg      – CPU utilisation %
        cpu_temp_c        – CPU temperature °C (0 if unsupported)
        cpu_power_w       – estimated CPU power (W)
        ram_used_pct      – system RAM used %
        ram_used_mb       – system RAM used MB
        ram_total_mb      – total system RAM MB

        gpu_util_avg      – GPU utilisation %  (0 if no GPU)
        gpu_temp_c        – GPU temperature °C
        gpu_power_w       – GPU power (W, 0 if GPUtil can't read)
        gpu_mem_used_mb   – GPU VRAM used MB
        gpu_mem_free_mb   – GPU VRAM free MB
        gpu_mem_total_mb  – GPU VRAM total MB
        gpu_mem_used_pct  – GPU VRAM used %

        hardware_type     – "GPU" | "CPU"
        hardware_name     – friendly device name
    """

    m: dict = {}

    # ══════════════════════════════════════════════════════════
    # CPU UTILISATION
    # ══════════════════════════════════════════════════════════
    try:
        m["cpu_util_avg"] = float(psutil.cpu_percent(interval=None))
    except:
        m["cpu_util_avg"] = 0.0

    # ══════════════════════════════════════════════════════════
    # CPU TEMPERATURE  (Linux coretemp; may be 0 on Windows)
    # ══════════════════════════════════════════════════════════
    try:
        temps = psutil.sensors_temperatures()
        if temps and "coretemp" in temps:
            m["cpu_temp_c"] = float(temps["coretemp"][0].current)
        else:
            m["cpu_temp_c"] = 0.0
    except:
        m["cpu_temp_c"] = 0.0

    # ══════════════════════════════════════════════════════════
    # RAM (system memory)
    # ══════════════════════════════════════════════════════════
    try:
        vm = psutil.virtual_memory()
        m["ram_used_pct"]  = float(vm.percent)
        m["ram_used_mb"]   = float(vm.used  / 1_048_576)
        m["ram_total_mb"]  = float(vm.total / 1_048_576)
    except:
        m["ram_used_pct"] = 0.0
        m["ram_used_mb"]  = 0.0
        m["ram_total_mb"] = 0.0

    # ══════════════════════════════════════════════════════════
    # GPU (primary: GPUtil)
    # ══════════════════════════════════════════════════════════
    try:
        if _GPUtil is None:
            raise ImportError("GPUtil not available")
        gpus = _GPUtil.getGPUs()
        if gpus:
            gpu = gpus[0]
            vram_total = float(gpu.memoryTotal) if gpu.memoryTotal else 0.0
            vram_used  = float(gpu.memoryUsed)  if gpu.memoryUsed  else 0.0
            vram_pct   = round(vram_used / vram_total * 100, 1) if vram_total > 0 else 0.0

            m.update({
                "gpu_util_avg":     float(gpu.load * 100),
                "gpu_temp_c":       float(gpu.temperature),
                "gpu_power_w":      0.0,               # GPUtil doesn't expose power
                "gpu_mem_used_mb":  vram_used,
                "gpu_mem_free_mb":  float(gpu.memoryFree) if gpu.memoryFree else 0.0,
                "gpu_mem_total_mb": vram_total,
                "gpu_mem_used_pct": vram_pct,
                "hardware_type":    "GPU",
                "hardware_name":    gpu.name,
            })
        else:
            raise ValueError("No GPU detected by GPUtil")

    except:
        pass   # fall through to CPU-only defaults

    # ══════════════════════════════════════════════════════════
    # GPU TEMP FALLBACK  (WMI / OpenHardwareMonitor)
    # ══════════════════════════════════════════════════════════
    if m.get("gpu_temp_c", 0) in (None, 0.0):
        wmi_temp = _read_gpu_temp_wmi()
        if wmi_temp:
            m["gpu_temp_c"] = wmi_temp

    # ══════════════════════════════════════════════════════════
    # CPU-ONLY FALLBACK
    # ══════════════════════════════════════════════════════════
    if "hardware_type" not in m:
        m.update({
            "gpu_util_avg":     0.0,
            "gpu_temp_c":       0.0,
            "gpu_power_w":      0.0,
            "gpu_mem_used_mb":  0.0,
            "gpu_mem_free_mb":  0.0,
            "gpu_mem_total_mb": 0.0,
            "gpu_mem_used_pct": 0.0,
            "hardware_type":    "CPU",
            "hardware_name":    "CPU Only",
        })

    # ══════════════════════════════════════════════════════════
    # CPU POWER ESTIMATE  (TDP-scaled heuristic)
    # ══════════════════════════════════════════════════════════
    try:
        # Base idle ~2 W; scales to ~35 W at 100% for a typical laptop CPU
        m["cpu_power_w"] = max(2.0, m["cpu_util_avg"] * 0.35)
    except:
        m["cpu_power_w"] = 3.0

    return m
