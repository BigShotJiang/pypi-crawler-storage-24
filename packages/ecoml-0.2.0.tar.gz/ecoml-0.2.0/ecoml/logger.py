import logging
import sys

def setup_logging(log_file_name=None):
    """
    Sets up a basic logger that prints to the console.
    
    Later, we can extend this to write to 'log_file_name' if needed.
    """
    
    # Get the root logger
    logger = logging.getLogger()
    
    # Check if handlers are already configured
    if not logger.hasHandlers():
        logger.setLevel(logging.INFO) # Set the root logger level
        
        # Configure the console handler
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(logging.INFO) # Set console handler level
        
        # Create formatter
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        console_handler.setFormatter(formatter)
        
        # Add handler to the logger
        logger.addHandler(console_handler)
        
        logger.info("Logger initialized.")

    # Return a named logger for the specific module
    return logging.getLogger(log_file_name)

# Initialize a default logger for any module that just imports this
setup_logging()