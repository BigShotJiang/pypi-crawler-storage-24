import os
from pathlib import Path
from dotenv import load_dotenv

try:
    import google.generativeai as genai
except:
    genai = None


class GeminiAdvisor:

    def __init__(self):
        root = Path(__file__).resolve().parents[1]
        load_dotenv(root / ".env")

        key = os.getenv("GEMINI_API_KEY")
        if not key:
            print("⚠ Gemini disabled – no API key found")
            self.enabled = False
            return

        if not genai:
            print("⚠ Gemini client missing (pip install google-generativeai)")
            self.enabled = False
            return

        genai.configure(api_key=key)
        self.model = genai.GenerativeModel("gemini-2.0-flash")
        self.enabled = True
        print("🤖 Gemini Enabled ✓")

    # ----------------------------------------------------------
    def ask(self, prompt: str) -> str | None:
        """Generic single-prompt call."""
        try:
            return self.model.generate_content(prompt).text.strip()
        except:
            return None

    # ----------------------------------------------------------
    def ask_rich(self, metrics: dict, error=None) -> str | None:
        """
        Rich context-aware prompt:
        passes all key metrics + detected workload type
        so Gemini can give a targeted, actionable 1-sentence tip.
        """
        cpu      = metrics.get("cpu_util_avg",    0)
        gpu      = metrics.get("gpu_util_avg",    0)
        cpu_temp = metrics.get("cpu_temp_c",      0)
        gpu_temp = metrics.get("gpu_temp_c",      0)
        ram_pct  = metrics.get("ram_used_pct",    0)
        vram_pct = metrics.get("gpu_mem_used_pct",0)
        energy   = float(metrics.get("energy_kwh", 0)) * 1000   # mWh
        co2      = metrics.get("co2_g",           0)
        runtime  = metrics.get("runtime_sec",     0)
        hw_type  = metrics.get("hardware_type",  "CPU")
        hw_name  = metrics.get("hardware_name",  "Unknown")

        error_line = f"\nRuntime error: {str(error)[:200]}" if error else ""

        prompt = f"""You are an expert ML efficiency advisor for a Jupyter notebook energy tracker called EcoML.

System snapshot:
  Hardware : {hw_name} ({hw_type})
  CPU util : {cpu:.1f}%
  GPU util : {gpu:.1f}%
  CPU temp : {cpu_temp:.1f}°C
  GPU temp : {gpu_temp:.1f}°C
  RAM used : {ram_pct:.1f}%
  VRAM used: {vram_pct:.1f}%
  Runtime  : {runtime:.2f}s
  Energy   : {energy:.4f} mWh
  CO₂      : {co2:.4f}g{error_line}

Give ONE specific, actionable sentence of advice to improve efficiency or reduce energy consumption.
Do NOT repeat the numbers. Focus on what the developer should DO next.
"""
        return self.ask(prompt)

    # ----------------------------------------------------------
    def generate_fix(self, err: Exception, code: str | None) -> str | None:
        """Generate 1-line fix suggestion for a runtime error."""
        code_snippet = (code or "")[:600]
        prompt = f"""You are a senior Python/ML debugger.

Error:
{err}

Relevant code:
{code_snippet}

Reply with ONE concise fix in plain text (no markdown, no code block). Max 120 characters.
"""
        return self.ask(prompt)
