import psutil
import GPUtil
import platform
from ecoml.logger import setup_logging # We'll create this next

# Set up logging for this module
logger = setup_logging('hardware_scanner.log')

class HardwareScanner:
    """
    Scans and retrieves hardware information: CPU, GPU, and Memory.
    
    This class provides a snapshot of the hardware specifications, which is
    essential for estimating energy consumption.
    """

    def __init__(self):
        """Initializes the scanner and gathers basic info."""
        logger.info("Initializing HardwareScanner...")
        self.system_info = {}
        self.scan_all()

    def get_cpu_info(self):
        """Retrieves detailed CPU information."""
        try:
            cpu_info = {
                "cpu_name": platform.processor(),
                "cpu_cores_physical": psutil.cpu_count(logical=False),
                "cpu_cores_logical": psutil.cpu_count(logical=True),
                "cpu_freq_max_mhz": psutil.cpu_freq().max if psutil.cpu_freq() else "N/A",
            }
            logger.info(f"CPU Info: {cpu_info['cpu_name']}, {cpu_info['cpu_cores_physical']} physical cores")
            return cpu_info
        except Exception as e:
            logger.error(f"Error getting CPU info: {e}")
            return {"cpu_name": "N/A"}

    def get_gpu_info(self):
        """Retrieves detailed GPU information using GPUtil."""
        try:
            gpus = GPUtil.getGPUs()
            if not gpus:
                logger.info("No NVIDIA GPU detected.")
                return {"gpu_name": "N/A", "gpu_count": 0}

            gpu_info = {
                "gpu_count": len(gpus),
                "gpu_name": gpus[0].name,
                "gpu_vram_mb": gpus[0].memoryTotal,
            }
            logger.info(f"GPU Info: {gpu_info['gpu_count']}x {gpu_info['gpu_name']}, {gpu_info['gpu_vram_mb']}MB VRAM")
            return gpu_info
        except Exception as e:
            logger.error(f"Error getting GPU info (is NVIDIA driver installed?): {e}")
            return {"gpu_name": "N/A", "gpu_count": 0}

    def get_memory_info(self):
        """Retrieves total system RAM."""
        try:
            memory = psutil.virtual_memory()
            mem_gb = round(memory.total / (1024**3), 2)
            mem_info = {
                "ram_total_gb": mem_gb
            }
            logger.info(f"Memory Info: {mem_info['ram_total_gb']} GB total RAM")
            return mem_info
        except Exception as e:
            logger.error(f"Error getting memory info: {e}")
            return {"ram_total_gb": 0}

    def scan_all(self):
        """Runs all scans and stores results in system_info."""
        logger.info("Starting full hardware scan...")
        self.system_info.update(self.get_cpu_info())
        self.system_info.update(self.get_gpu_info())
        self.system_info.update(self.get_memory_info())
        logger.info("Full hardware scan complete.")
        return self.system_info

    def get_hardware_profile(self):
        """Returns the full hardware profile."""
        return self.system_info

# To allow testing this file directly
if __name__ == "__main__":
    print("Running Hardware Scanner directly for testing...")
    scanner = HardwareScanner()
    profile = scanner.get_hardware_profile()
    
    print("\n--- Hardware Profile ---")
    for key, value in profile.items():
        print(f"{key.replace('_', ' ').title()}: {value}")
    print("------------------------")