from IPython.core.magic import register_line_magic
from IPython import get_ipython
from ecoml.hardware_scanner import HardwareScanner
from ecoml.emission_tracker import EmissionTracker
from ecoml.logger import setup_logging
import json

logger = setup_logging('autotracker.log')

# --- Global objects to hold our tracker and hardware info ---
# This allows them to persist between cell executions
ECOM_TRACKER = None
ECOM_HARDWARE = None

def load_ecoml_globals():
    """Initializes the global tracker and hardware objects."""
    global ECOM_HARDWARE, ECOM_TRACKER
    if ECOM_HARDWARE is None:
        logger.info("AutoTracker: Initializing HardwareScanner.")
        ECOM_HARDWARE = HardwareScanner().get_hardware_profile()
    if ECOM_TRACKER is None:
        logger.info("AutoTracker: Initializing EmissionTracker.")
        ECOM_TRACKER = EmissionTracker(hardware_profile=ECOM_HARDWARE)

# --- Define our hook functions ---

def pre_run_cell_hook(info):
    """
    Called by IPython *before* a cell is executed.
    Starts the emission tracker.
    """
    global ECOM_TRACKER
    if ECOM_TRACKER:
        logger.info(f"--- Cell {info.cell_id} Pre-Run ---")
        ECOM_TRACKER.start()

def post_run_cell_hook(result):
    """
    Called by IPython *after* a cell is executed.
    Stops the tracker and prints the CO2 results.
    """
    global ECOM_TRACKER
    if ECOM_TRACKER and ECOM_TRACKER._is_running:
        logger.info(f"--- Cell {result.info.cell_id} Post-Run ---")
        results = ECOM_TRACKER.stop()
        
        # --- This is where we print the output! ---
        if results and results.get("total_co2_g", 0) > 0:
            print("-----------------------------------------------------------------")
            print(f"🌿 EcoML Report:")
            print(f"   CO2 Emitted: {results.get('total_co2_g', 0):.6f} g")
            print(f"   Energy:      {results.get('total_energy_kwh', 0):.6f} kWh")
            print(f"   Duration:    {results.get('duration_s', 0):.2f} s")
            print("-----------------------------------------------------------------")
        else:
            logger.info("Cell ran too fast or produced no emissions, skipping report.")


# --- Define the "magic" functions to turn tracking on/off ---

@register_line_magic
def start_ecoml_tracking(line):
    """
    Line magic %start_ecoml_tracking
    Registers the pre/post run cell hooks.
    """
    global ECOM_TRACKER
    ip = get_ipython()
    if not ip:
        print("EcoML Error: Must be run in an IPython environment.")
        return
        
    # Initialize the tracker if it hasn't been
    load_ecoml_globals()
    ECOM_TRACKER._is_running = False # Reset state just in case
    
    # Register the hooks
    ip.events.register('pre_run_cell', pre_run_cell_hook)
    ip.events.register('post_run_cell', post_run_cell_hook)
    
    print("🌿 EcoML Automatic Tracking is [ON]. All cells will now be monitored.")
    logger.info("EcoML hooks registered.")

@register_line_magic
def stop_ecoml_tracking(line):
    """
    Line magic %stop_ecoml_tracking
    Unregisters the pre/post run cell hooks.
    """
    global ECOM_TRACKER
    ip = get_ipython()
    if not ip:
        return
        
    # Unregister the hooks
    try:
        ip.events.unregister('pre_run_cell', pre_run_cell_hook)
        ip.events.unregister('post_run_cell', post_run_cell_hook)
        ECOM_TRACKER = None # Clear the tracker
        print("🌿 EcoML Automatic Tracking is [OFF].")
        logger.info("EcoML hooks unregistered.")
    except KeyError:
        print("🌿 EcoML Tracking was not active.")  