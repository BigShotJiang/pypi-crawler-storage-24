import time
import threading
import psutil
import GPUtil
import pandas as pd
from ecoml.hardware_scanner import HardwareScanner
from ecoml.logger import setup_logging

logger = setup_logging('emission_tracker.log')

# --- Our Emission Model Constants ---
# Power Usage Effectiveness (PUE) - Google's avg is 1.10, global avg is ~1.58
PUE = 1.58
# Carbon Intensity (gCO2/kWh) - global average
CARBON_INTENSITY_G_PER_KWH = 475
# Default CPU TDP (Thermal Design Power) in Watts
DEFAULT_CPU_TDP = 45
# Default RAM Power in Watts (approx. 5W per 16GB)
DEFAULT_RAM_POWER_W = 5
# ------------------------------------

class EmissionTracker:
    """
    Tracks energy consumption and CO2 emissions for a block of code.
    
    Uses threading to monitor CPU, GPU, and RAM usage in the background.
    """

    def __init__(self, hardware_profile=None):
        logger.info("Initializing EmissionTracker...")
        self.hardware = hardware_profile or HardwareScanner().get_hardware_profile()
        
        # Monitoring state
        self._is_running = False
        self._monitor_thread = None
        
        # Data storage
        self.usage_data = [] # Stores (timestamp, cpu_%, gpu_power_w) tuples
        self.results = {}
        
        # Timing
        self.start_time = None
        self.end_time = None

    def _monitor_usage(self, interval=0.5):
        """
        The background worker function that runs in a separate thread.
        Polls hardware usage at a set interval.
        """
        logger.info("Monitoring thread started.")
        gpu_power_w = 0.0
        
        while self._is_running:
            try:
                # 1. Get CPU %
                cpu_percent = psutil.cpu_percent(interval=None)
                
                # 2. Get GPU Power (if available)
                if self.hardware.get("gpu_count", 0) > 0:
                    gpus = GPUtil.getGPUs()
                    gpu_power_w = sum(g.powerDraw for g in gpus)
                else:
                    gpu_power_w = 0.0
                    
                # 3. Store data
                timestamp = time.time()
                self.usage_data.append({
                    "timestamp": timestamp,
                    "cpu_percent": cpu_percent,
                    "gpu_power_w": gpu_power_w
                })
                
                time.sleep(interval)
                
            except Exception as e:
                logger.error(f"Error in monitoring thread: {e}")
                # Don't stop the thread, just log and continue
                pass
        
        logger.info("Monitoring thread stopped.")

    def start(self):
        """Starts the emission tracking."""
        if self._is_running:
            logger.warning("Tracker is already running.")
            return

        logger.info("Starting tracker...")
        self.start_time = time.time()
        self.usage_data = []
        self.results = {}
        
        self._is_running = True
        self._monitor_thread = threading.Thread(target=self._monitor_usage, daemon=True)
        self._monitor_thread.start()

    def stop(self):
        """Stops the tracking and calculates results."""
        if not self._is_running:
            logger.warning("Tracker is not running.")
            return

        self.end_time = time.time()
        self._is_running = False
        self._monitor_thread.join() # Wait for the thread to finish
        
        logger.info("Tracker stopped. Calculating emissions...")
        self._calculate_emissions()
        return self.results

    def _calculate_emissions(self):
        """Calculates total energy and CO2 based on collected data."""
        duration_s = self.end_time - self.start_time
        if duration_s == 0 or not self.usage_data:
            logger.warning("No data collected or duration was zero. Skipping calculation.")
            return

        # Convert list of dicts to pandas DataFrame for easy analysis
        df = pd.DataFrame(self.usage_data)
        
        # 1. Calculate Average Usages
        avg_cpu_percent = df['cpu_percent'].mean()
        avg_gpu_power_w = df['gpu_power_w'].mean()

        # 2. Calculate Energy in Watt-seconds (Ws)
        # Using our TDP-based proxy model
        cpu_power_w = (avg_cpu_percent / 100) * DEFAULT_CPU_TDP
        ram_power_w = DEFAULT_RAM_POWER_W # Constant for now
        
        total_power_w = cpu_power_w + avg_gpu_power_w + ram_power_w
        
        total_energy_ws = total_power_w * duration_s

        # 3. Convert to kWh
        total_energy_kwh = total_energy_ws / (1000 * 3600) # Ws -> Wh -> kWh

        # 4. Calculate CO2
        # CO2 (g) = Energy (kWh) * PUE * Carbon Intensity (g/kWh)
        total_co2_g = total_energy_kwh * PUE * CARBON_INTENSITY_G_PER_KWH

        self.results = {
            "duration_s": round(duration_s, 2),
            "avg_cpu_percent": round(avg_cpu_percent, 2),
            "avg_gpu_power_w": round(avg_gpu_power_w, 2),
            "total_energy_kwh": round(total_energy_kwh, 6),
            "total_co2_g": round(total_co2_g, 6),
            "hardware_profile": self.hardware
        }
        
        logger.info(f"Calculation complete: {self.results['total_co2_g']}g CO2")

# To allow testing this file directly
if __name__ == "__main__":
    print("Running Emission Tracker directly for testing...")
    
    scanner = HardwareScanner()
    tracker = EmissionTracker(hardware_profile=scanner.get_hardware_profile())
    
    print("--- Starting 5-second test burn ---")
    tracker.start()
    
    # Simulate a heavy workload
    start_burn = time.time()
    while time.time() - start_burn < 5:
        # Some dummy computation
        _ = [x*x for x in range(1000)]
        pass
        
    results = tracker.stop()
    print("--- Test complete ---")
    
    import json
    print("\n--- Results ---")
    print(json.dumps(results, indent=2))
    print("---------------")