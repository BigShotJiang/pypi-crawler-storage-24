class MLRecommender:
    def suggest(self, runtime_sec, emission_gco2):
        if runtime_sec > 60:
            return ("Use GPU or optimize loops/vectorize", 0.25)
        if runtime_sec > 10:
            return ("Use multiprocessing or reduce algorithm complexity", 0.15)
        if emission_gco2 < 0.1:
            return ("Emission is already very low", 0.0)
        return ("Use efficient libraries (NumPy, Pandas)", 0.05)
