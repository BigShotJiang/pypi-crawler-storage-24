from setuptools import setup, find_packages

setup(
    name="ecoml",
    version="0.2.0",
    packages=find_packages(),
    description="EcoML – Track, analyse and reduce ML carbon emissions inside Jupyter notebooks.",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="EcoML Team",
    python_requires=">=3.10",
    install_requires=[
        "psutil",
        "GPUtil",
        "pandas",
        "scikit-learn",
        "ipython",
        "python-dotenv",
        "google-generativeai>=0.8.0",
    ],
    extras_require={
        "gpu": ["wmi"],          # Windows WMI GPU temp (optional)
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: System :: Monitoring",
    ],
)