from ecoml import track_emissions

def test_emission_tracker():
    @track_emissions
    def small():
        return sum(range(1000))

    result, metrics = small()
    assert "runtime_sec" in metrics
    assert metrics["runtime_sec"] > 0
