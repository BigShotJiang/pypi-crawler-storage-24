"""
The module to include classes related to the
rendering context.
"""
from yta_validation.parameter import ParameterValidator


class RenderContext:
    """
    A context that will be used along a rendering
    process, to be able to access to different
    resources, providers, etc.
    """

    def __init__(
        self,
        # TODO: Maybe rename to 'config'
        render_config: 'RenderConfig',
        # TODO: Maybe rename to 'resources'
        # TODO: Maybe rename to 'render_resources_handler'
        render_resources: 'RenderResources'
    ):
        ParameterValidator.validate_mandatory_instance_of('render_config', render_config, 'RenderConfig')
        ParameterValidator.validate_mandatory_instance_of('render_resources', render_resources, 'RenderResources')

        self.render_config: 'RenderConfig' = render_config
        """
        The configuration of the rendering process.
        """
        self.render_resources: 'RenderResources' = render_resources
        """
        The handler of the rendering process resources.
        """

    def deactivate_gpu(
        self
    ) -> 'RenderContext':
        """
        Deactivate the GPU by setting the `do_use_gpu`
        parameter to `False`, if needed.
        """
        self.render_config.deactivate_gpu()

        return self

    def activate_gpu(
        self
    ) -> 'RenderContext':
        """
        Activate the GPU by setting the `do_use_gpu`
        parameter to `True`, if needed.
        """
        self.render_config.activate_gpu()

        return self