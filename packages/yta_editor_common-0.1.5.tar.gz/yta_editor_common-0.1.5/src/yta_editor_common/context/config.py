from dataclasses import dataclass

        
@dataclass
class RenderConfig:
    """
    The configuration of the rendering process,
    which includes information such as:
    - The `size` we want for the output
    - The `fps` we want for the output
    - If we want to use GPU or not
    """

    def __init__(
        self,
        size:  tuple[int, int],
        fps: float,
        do_use_gpu: bool
    ):
        self.size: tuple[int, int] = size
        """
        The size that will be used for the output of the
        rendering process.
        """
        self.fps: float = fps
        """
        The fps for the output of the rendering process.
        """
        self.do_use_gpu: bool = do_use_gpu
        """
        Flag to indicate if processing the rendering with
        GPU (if `True`) or with CPU (if `False`).
        """

    def deactivate_gpu(
        self
    ) -> 'RenderConfig':
        """
        Deactivate the GPU by setting the `do_use_gpu`
        parameter to `False`, if needed.
        """
        self.do_use_gpu = False

        return self

    def activate_gpu(
        self
    ) -> 'RenderConfig':
        """
        Activate the GPU by setting the `do_use_gpu`
        parameter to `True`, if needed.
        """
        self.do_use_gpu = True

        return self