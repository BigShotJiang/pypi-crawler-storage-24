﻿from .autopost import SotiAutopost
from .client import Soti
from .exceptions import SotiAPIError, SotiConnectionError, SotiError, SotiValidationError
from .models import Bot, BotList

__version__ = "2.0.0"
__author__ = "Soti Team"

__all__ = [
    "Soti",
    "SotiAutopost",
    "Bot",
    "BotList",
    "SotiError",
    "SotiValidationError",
    "SotiAPIError",
    "SotiConnectionError",
]
