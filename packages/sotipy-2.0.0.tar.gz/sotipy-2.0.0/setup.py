﻿from setuptools import find_packages, setup

with open("README.md", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="sotipy",
    version="2.0.0",
    author="Soti Team",
    description="Official Python SDK for Soti Discord Bot Catalog API",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/soti/sotipy",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Operating System :: OS Independent",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    python_requires=">=3.9",
)
