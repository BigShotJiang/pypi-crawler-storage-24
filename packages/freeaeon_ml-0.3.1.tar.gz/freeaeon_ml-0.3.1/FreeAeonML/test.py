import cv2
import argparse
import matplotlib.pyplot as plt
from tqdm import tqdm
import pandas as pd
import numpy as np
import seaborn as sns
from scipy.stats import zscore

from FreeAeonFractal.FAImageFourier import CFAImageFourier
from FreeAeonFractal.FAImage import CFAImage
from FreeAeonFractal.FAImageLacunarity import CFAImageLacunarity

#CPU version
from FreeAeonFractal.FAImageDimension import CFAImageDimension
from FreeAeonFractal.FA2DMFS import CFA2DMFS

#GPU version
#from FreeAeonFractal.FAImageDimensionGPU import CFAImageDimensionGPU as CFAImageDimension
#from FreeAeonFractal.FA2DMFSGPU import CFA2DMFSGPU as CFA2DMFS

from FreeAeonFractal.FA1DMFS import CFA1DMFS

from scipy.optimize import curve_fit

class CurveFitter:
    def __init__(self, x_data, y_data):
        self.x_data = x_data
        self.y_data = y_data
        self.params = None
        self.model_func = None

    @staticmethod
    def linear(x, a, b):
        return a * x + b

    @staticmethod
    def polynomial(x, *coeffs):
        return sum(c * x**i for i, c in enumerate(coeffs))

    @staticmethod
    def exponential(x, a, b):
        return a * np.exp(b * x)
    
    @staticmethod
    def get_data(x_data,params,model_type='linear'):
        model_func = None
        if model_type == 'linear':
            model_func = CurveFitter.linear
        elif model_type == 'polynomial':
            model_func = CurveFitter.polynomial
        elif model_type == 'exponential':
            model_func = CurveFitter.exponential
        return model_func(x_data, params)
    
    #linear,polynomial,exponential
    def fit(self, model_type='linear', degree=2):
        if model_type == 'linear':
            self.params, _ = curve_fit(self.linear, self.x_data, self.y_data)
            self.model_func = self.linear
        elif model_type == 'polynomial':
            self.params, _ = curve_fit(self.polynomial, self.x_data, self.y_data, p0=[1]*degree)
            self.model_func = self.polynomial
        elif model_type == 'exponential':
            self.params, _ = curve_fit(self.exponential, self.x_data, self.y_data)
            self.model_func = self.exponential
        else:
            raise ValueError("Unsupported model type. Choose 'linear', 'polynomial', or 'exponential'.")
        return self.params

def get_fit_data(x,coefficients):
    return CurveFitter.get_data(x,coefficients,model_type = 'linear')

def get_fit_params(x,y):
    fit = CurveFitter(x,y)
    return fit.fit(model_type = 'linear')

def get_normal(df_data,hue = 'kind'):
    columns_to_standardize = df_data.select_dtypes(include=[np.number]).columns.tolist()
    df_standardized = df_data.copy()
    df_standardized[columns_to_standardize] = df_data.groupby(hue)[columns_to_standardize].transform(zscore)
    return df_standardized

#频谱图中心是低频（轮廓），外围是高频（噪声细节）
#以中心为原点，取半价小于r的低频区域
def get_high_pass_mask(shape, low_freq_r):
    h, w = shape[:2]
    cy, cx = h // 2, w // 2
    Y, X = np.ogrid[:h, :w]
    dist = np.sqrt((Y - cy)**2 + (X - cx)**2)
    return dist < float(low_freq_r)

#0.25 512 0.5 256 1 128 2 64 4 32 8 16
def get_fourier_image(gray_image, step=8):
    fourier = CFAImageFourier(gray_image)
    mag, phase = fourier.get_raw_spectrum()
    h, w = mag[0].shape
    #max_r = min(h, w) / 2.0

    rs = np.arange(2, 32, 0.125/2)  
    result = []
    for r in rs:
        mask = get_high_pass_mask(gray_image.shape, r)
        reconstructed = fourier.extract_by_freq_mask(mask)
        result.append((r,reconstructed))
    return result

def get_lacunarity(img):
    bin_img,threshold = CFAImage.otsu_binarize(img)
    lac = CFAImageLacunarity(bin_img,max_size=256,max_scales=64,with_progress=False,scales_mode="logspace")
    res = lac.get_lacunarity(corp_type=-1, use_binary_mass=True, include_zero=True)
    df1 = pd.DataFrame()
    df1['scales'] = pd.Series(res['scales'])
    df1['lacunarity'] = pd.Series(res['lacunarity'])
    df1['img'] = 'bin'

    img0 = img.astype(np.float64)
    img0 = img0 - img0.mean()
    img_mass = np.abs(img0)
    lac = CFAImageLacunarity(img_mass,max_size=256,max_scales=64,with_progress=False,scales_mode="logspace")
    res = lac.get_lacunarity(corp_type=-1, use_binary_mass=False, include_zero=True)
    df2 = pd.DataFrame()
    df2['scales'] = pd.Series(res['scales'])
    df2['lacunarity'] = pd.Series(res['lacunarity'])
    df2['img'] = 'gray'
    return pd.concat([df1,df2],ignore_index=True).reset_index(drop = True)

def get_mfs(img):
    MFS = CFA2DMFS(img,
                   with_progress = False,
                   q_list=np.linspace(-3, 8, 61),
                   bg_reverse=False,
                   bg_threshold=0,
                   bg_otsu=False,
                   mu_floor=1e-12)

    df_mass, df_fit, df_spec = MFS.get_mfs(max_size=256,
                                           max_scales=64,
                                           min_points=5,
                                           use_middle_scales=False,
                                           if_auto_line_fit=False,
                                           fit_scale_frac=(0.3, 0.7),
                                           auto_fit_min_len_ratio=0.6,
                                           cap_d0_at_2=False)

    df_spec = df_spec.rename(columns={'tau':'t(q)','Dq': 'd(q)', 'alpha': 'a(q)', 'f_alpha':'f(a)'})
    if not df_spec.empty:
        del df_spec['D1']
    return df_spec

def get_fd(image_path):
    rgb_image = cv2.imread(image_path)
    if rgb_image is None:
        raise FileNotFoundError(f"Cannot load image")
    file = image_path.split("/")[-2]+image_path.split("/")[-1]

    gray_image = cv2.cvtColor(rgb_image, cv2.COLOR_BGR2GRAY)
    imgs = get_fourier_image(gray_image,step=4)
    r_list = []
    img_list = []
    fd_list = []
    lac_list = []
    mfs_list = []

    for i in tqdm(range(len(imgs)),desc=image_path.split("/")[-1]):
        r = imgs[i][0]
        img = imgs[i][1]
        r_list.append(r)
        img_list.append(img)

        fd_dbc = CFAImageDimension(img,with_progress = False).get_dbc_fd(corp_type=-1)
        df_tmp_fd = pd.DataFrame([{"r":r,"fd":fd_dbc['fd']}])
        df_tmp_fd['file'] = file
        fd_list.append(df_tmp_fd)

        df_tmp_lac = get_lacunarity(img)
        df_tmp_lac['r'] = r
        df_tmp_lac['file'] = file
        lac_list.append(df_tmp_lac)

        df_tmp_mfs = get_mfs(img)
        df_tmp_mfs['r'] = r
        df_tmp_mfs['file'] = file
        mfs_list.append(df_tmp_mfs)
    
    df_fd = pd.concat(fd_list,ignore_index = True).reset_index(drop = True)
    df_lac = pd.concat(lac_list,ignore_index = True).reset_index(drop = True)
    df_mfs = pd.concat(mfs_list,ignore_index = True).reset_index(drop = True)

    return r_list,img_list,df_fd,df_lac,df_mfs

def show_images(r_list,img_list):
    sqrt_ceil = int(np.ceil(np.sqrt(len(img_list))))
    fig, axs = plt.subplots(sqrt_ceil, sqrt_ceil, figsize=(8, 8))
    axes = axs.flatten()
    for i in tqdm(range(len(r_list)),desc="total"):
        r = r_list[i]
        img = img_list[i]
        axes[i].imshow(img, cmap='gray',vmin=0, vmax=255)
        axes[i].axis('off')
        axes[i].set_title('%0.2f'%r)
    plt.tight_layout()
    plt.show()

def show_fd():
    df_data = pd.read_csv("./fd.csv",index_col=0)
    df_tmp = df_data[df_data['r'] < 16]
    df_tmp = df_data.groupby(['file']).mean() 
    sns.lineplot(data=df_tmp, x='r', y='fd', hue='file', palette='coolwarm')
    #sns.histplot(data=df_tmp, x='fd', hue='file', palette='coolwarm',bins=100)
    plt.show()
    print(df_tmp)

def show_lac():
    df_data = pd.read_csv("./lac.csv", index_col=0)
    df_tmp = df_data[df_data['img'] == 'gray'].reset_index(drop=True)
    del df_tmp['img']
    all_data = []
    for file,df_t0 in df_tmp.groupby("file"):
        for r,df_t1 in df_t0.groupby("r"):
            x = df_t1['scales'].values
            y = df_t1['lacunarity'].values
            params = get_fit_params(x,y)
            tmp = {}
            tmp['file'] = file
            tmp['r'] = r
            for i in range(len(params)):
                tmp['p%d'%i] = params[i]
            all_data.append(tmp)
    df_tmp = pd.DataFrame(all_data)
    print(df_tmp)
    #return
    #df_tmp = df_tmp[df_tmp['r'] > 8]
    #df_tmp = df_tmp[df_tmp['scales'] < 128]
    # 创建图形
    plt.figure(figsize=(12, 8))

    # 绘制 p0
    #sns.scatterplot(data=df_tmp, x='r', y='p0', hue='file', style='file', s=30, palette='coolwarm', marker='o')
    # 绘制 p1
    #sns.scatterplot(data=df_tmp, x='r', y='p1', hue='file', style='file', s=30, palette='coolwarm', marker='s')
    # 绘制 p2
    #sns.scatterplot(data=df_tmp, x='r', y='p2', hue='file', style='file', s=30, palette='coolwarm', marker='^')

    # 添加图例和标题
    plt.title('Parameter Values by File and r')
    plt.xlabel('r')
    plt.ylabel('Parameter Values (p0, p1, p2)')
    plt.legend(title='File')
    plt.grid()
    plt.show()

def demo():
    file_list = [
        "/Users/jim_xie/Desktop/Research/deepfake/png/train/1.png",
        "/Users/jim_xie/Desktop/Research/deepfake/png/train/2.png",
        "/Users/jim_xie/Desktop/Research/deepfake/png/train/3.png",
        "/Users/jim_xie/Desktop/Research/deepfake/png/test/1.png",
        "/Users/jim_xie/Desktop/Research/deepfake/png/test/2.png",
        "/Users/jim_xie/Desktop/Research/deepfake/png/test/3.png",
        "/Users/jim_xie/Desktop/Research/deepfake/png/fake/1.png",
        "/Users/jim_xie/Desktop/Research/deepfake/png/fake/2.png",
        "/Users/jim_xie/Desktop/Research/deepfake/png/fake/3.png"
    ]
    fd_list = []
    lac_list = []
    mfs_list = []
    for file in tqdm(file_list,desc= "total"):        
        r_list,img_list,df_fd,df_lac,df_mfs = get_fd(file)
        fd_list.append(df_fd)
        lac_list.append(df_lac)
        mfs_list.append(df_mfs)

    df_fd = pd.concat(fd_list,ignore_index = True).reset_index(drop = True)
    df_lac = pd.concat(lac_list,ignore_index = True).reset_index(drop = True)
    df_mfs = pd.concat(mfs_list,ignore_index = True).reset_index(drop = True)

    df_fd.to_csv("./df.csv")
    df_lac.to_csv("./lac.csv")
    df_mfs.to_csv("./mfs.csv")

def fit(x,y):
    params = get_fit_params(x,y)  
    y_fit =  get_fit_data(x,params) 
    plt.scatter(x, y, label='Data points', color='blue', alpha=0.5)
    plt.plot(x, y_fit, label=f'Polynomial fit (degree {2})', color='red')
    plt.title('Polynomial Fitting Example')
    plt.xlabel('x')
    plt.ylabel('y')
    plt.legend()
    plt.grid()
    plt.show()

def main():
    #demo()
    #show_fd()
    show_lac()
    return
    df_data = pd.read_csv("./lac.csv",index_col=0)
    df_tmp = df_data[df_data['img']=='gray'].reset_index(drop = True)
    del df_tmp['img']
    df_tmp = df_tmp[df_tmp['r'] > 8]
    df_tmp = df_tmp[df_tmp['scales'] < 128]

    df_tmp = df_tmp.groupby(['scales',"file"]).max() / df_tmp.groupby(['scales',"file"]).std() 
    #df_tmp['df_tmp'] = np.log(df_tmp['lacunarity'])
    df_tmp = df_tmp.reset_index()
    df_tmp = df_tmp[~df_tmp['lacunarity'].isin([np.inf, -np.inf])]
    #sns.lineplot(data=df_tmp, x='scales', y='lacunarity', hue='file', palette='coolwarm')
    #sns.histplot(data=df_tmp, x='lacunarity', hue='file', palette='coolwarm',bins=100)
    #plt.show()
    print(df_tmp)
    fit(df_tmp['scales'],df_tmp["lacunarity"])

if __name__ == "__main__":
    main()
