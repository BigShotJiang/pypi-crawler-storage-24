#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
import time

import numpy as np

from scipy.optimize import minimize
from scipy.optimize import Bounds

from aps.beamline_driver.beam_management.facade import IBeamManager
from aps.beamline_driver.motion_management.facade import IMotionManager
from aps.ai.beamline_controller.agent.facade import IAgentListener
from aps.ai.beamline_controller.agent.optimization.facade import WarmStartDataType, OptimizationType
from aps.ai.beamline_controller.agent.optimization.soo.nonlinear.facade import NonlinearOptimizationResult, NonlinearOptimizationResultItem
from aps.ai.beamline_controller.agent.optimization.soo.nonlinear.abstract_optimizer import AbstractNonlinearOptimizer
from aps.ai.beamline_controller.agent.optimization.soo.nonlinear.scipy.hypervolume_manager import AbstractScipyHypervolumeManager

class ScipyOptimizationModel:
    UNCONSTRAINED_MULTIVARIATE_SCALAR_NELDER_MEAD                                         = "Nelder-Mead"
    UNCONSTRAINED_MULTIVARIATE_SCALAR_BROYDEN_FLETCHER_GOLDFARB_SHANNO                    = "BFGS"
    UNCONSTRAINED_MULTIVARIATE_SCALAR_NEWTON_CONJUGATE_GRADIENT                           = "Newton-CG"
    UNCONSTRAINED_MULTIVARIATE_SCALAR_TRUST_REGION_NEWTON_CONJUGATE_GRADIENT              = "trust-ncg"
    UNCONSTRAINED_MULTIVARIATE_SCALAR_TRUST_REGION_TRUNCATED_GENERALIZED_LANCZOS_GRADIENT = "trust-krylov"
    UNCONSTRAINED_MULTIVARIATE_SCALAR_TRUST_REGION_NEARLY_EXACT                           = "trust-exact"
    CONSTRAINED_MULTIVARIATE_SCALAR_TRUST_REGION_CONSTRAINED                              = "trust-constr"
    CONSTRAINED_MULTIVARIATE_SCALAR_SEQUENTIAL_LEAST_SQUARES_PROGRAMMING                  = "SLSQP"

class BestBeamCriteria:
    LOWEST_LOSS = 'lowest_loss'

class ExitStrategyException(StopIteration):
    def __init__(self, optimized_motors_positions, loss):
        self.__optimized_motors_positions = optimized_motors_positions
        self.__loss = loss

        super(ExitStrategyException, self).__init__("Exit strategy matched")

    @property
    def optimized_motors_positions(self): return self.__optimized_motors_positions
    @property
    def loss(self): return self.__loss



class ScipyOptimizer(AbstractNonlinearOptimizer):
    def __init__(self, optimization_listener : IAgentListener, **kwargs):
        super(ScipyOptimizer, self).__init__(optimization_listener, **kwargs)

    def initialize(self,
                   beam_manager       : IBeamManager,
                   motion_manager     : IMotionManager,
                   hypervolume_manager: AbstractScipyHypervolumeManager = None,
                   **kwargs):
        super(ScipyOptimizer, self).initialize(beam_manager, motion_manager, hypervolume_manager, **kwargs)

    def initialize_driver(self,
                          beam_manager : IBeamManager,
                          motion_manager : IMotionManager):
        super(ScipyOptimizer, self).initialize_driver(beam_manager, motion_manager)

        if self.requires_run_engine(): setattr(self, "_optimize", self.__optimize_generator)
        else:                          setattr(self, "_optimize", self.__optimize)

    def requires_run_engine(self): return False

    # -----------------------------------------------------------------------
    # -----------------------------------------------------------------------
    # -----------------------------------------------------------------------
    # BLUESKY DYNAMIC MANAGEMENT -> PRIVATE METHODS
    # -----------------------------------------------------------------------
    # -----------------------------------------------------------------------
    # -----------------------------------------------------------------------

    def __nl_optimize_init(self):
        execution_parameters = self._execution_parameters
        input_parameters = self._input_parameters

        if execution_parameters.optimization_type == OptimizationType.WARM_START_SAME_DETECTOR:
            if execution_parameters.warm_start_data_type == WarmStartDataType.PRETRAINED_MODEL:
                raise NotImplementedError("Pretrained Model are not supported by this optimizer, yet")

            warm_start_search_space = self._warm_start_data.get_warm_start_search_ranges()

        self._current_trial_index = 0
        self._current_optimization_result = NonlinearOptimizationResult()

        initial_values = []
        lower_bounds = []
        upper_bounds = []

        for motor_id in input_parameters.motors_to_optimize:
            initial_values.append(self._motion_manager.get_motor_position(motor_id))
            if execution_parameters.optimization_type == OptimizationType.WARM_START_SAME_DETECTOR:
                search_range = warm_start_search_space[motor_id]
            else:
                search_range = self._motion_manager.get_motors_info().get_motor_info(motor_id).search_range_by_key(beam_manager_type=input_parameters.beam_manager_type,
                                                                                                                          platform=input_parameters.platform,
                                                                                                                          beam_manager_id=input_parameters.beam_manager_id)
            lower_bounds.append(search_range[0])
            upper_bounds.append(search_range[1])

        initial_values = np.array(initial_values)
        lower_bounds = np.array(lower_bounds)
        upper_bounds = np.array(upper_bounds)

        np.random.seed(input_parameters.random_seed)

        self._beam_manager.set_initial_flux()

        return initial_values, lower_bounds, upper_bounds

    def __nl_optimize_end(self, final_loss, optimized_motor_positions):
        self._optimization_listener.feedback(None, None, None, None, None, message=["*****************************************************",
                                                                                    "* Final optimized results:",
                                                                                    "*****************************************************"])
        self._optimization_listener.feedback(trial_index=self._current_trial_index,
                                             motors_to_optimize=self._input_parameters.motors_to_optimize,
                                             suggested_motor_positions=optimized_motor_positions,
                                             actual_motor_positions=optimized_motor_positions,
                                             current_loss=final_loss)
        return self._current_optimization_result

    def __optimize(self, **kwargs):
        input_parameters                           = self._input_parameters
        initial_values, lower_bounds, upper_bounds = self.__nl_optimize_init()

        # TODO: ADD CurrentRawDAta to save the beams

        try:
            best_trial_data = minimize(fun      = self.__evaluation_function,
                                       x0       = initial_values,
                                       method   = input_parameters.method,
                                       bounds   = Bounds(lb=lower_bounds, ub=upper_bounds),
                                       options  = {'xatol'  : input_parameters.get_parameter("x_absolute_change", 1e-8),
                                                   'fatol'  : input_parameters.get_parameter("f_absolute_change", 1e-8),
                                                   'maxiter': input_parameters.max_iteration,
                                                   'disp'   : input_parameters.get_parameter("verbose", True)})
            motors_info = self._motion_manager.get_motors_info()

            optimized_motor_positions = {motor_id : motors_info.get_motor_info(motor_id).apply_resolution(motor_position) for motor_id, motor_position in zip(self._input_parameters.motors_to_optimize, best_trial_data.x)}
            final_loss                = best_trial_data.fun
        except ExitStrategyException as e:
            print(e)
            optimized_motor_positions = e.optimized_motors_positions
            final_loss                = e.loss

        return self.__nl_optimize_end(final_loss, optimized_motor_positions)

    def __optimize_generator(self, **kwargs): raise NotImplementedError("Bluesky is not supported by Scipy optimizer")

    def _manage_transfer_learning_input(self, **kwargs):
        if self._execution_parameters.optimization_type == OptimizationType.WARM_START_SAME_DETECTOR: raise NotImplementedError("BlopTools does not support warm start")
        else: self._warm_start_data = None

    # -----------------------------------------------------------------------
    # MINIMIZATION FUNCTION
    # -----------------------------------------------------------------------

    def __manage_error(self, trial_index, optimization_criteria, motors_to_optimize, suggested_motor_positions, current_motors_positions, error_message, beam):
        error_loss = self._hypervolume_manager.get_error_loss_function(optimization_criteria)
        self._optimization_listener.feedback(trial_index=trial_index,
                                             motors_to_optimize=motors_to_optimize,
                                             suggested_motor_positions=suggested_motor_positions,
                                             actual_motor_positions=current_motors_positions,
                                             current_loss=error_loss)
        return error_loss, error_message, beam

    def __evaluation_function(self, suggested_motor_positions: np.ndarray) -> float:
        start_time = time.time()

        optimization_criteria     = self._optimization_criteria
        execution_parameters      = self._execution_parameters
        motors_to_optimize        = self._input_parameters.motors_to_optimize
        motors_info               = self._motion_manager.get_motors_info()

        # discrete search space is not possible, so the best we can do is to apply the motor resolution
        suggested_motor_positions = {motor_id: motors_info.get_motor_info(motor_id).apply_resolution(suggested_motor_position) \
                                     for motor_id, suggested_motor_position in zip(motors_to_optimize, suggested_motor_positions)}

        self._current_trial_index += 1

        def get_current_loss_function(trial_index):
            try:
                self._move_motors(suggested_motor_positions)
                current_motors_positions = self._get_current_motors_positions()

                motor_ok, error_message = self._check_motor_positions(suggested_motor_positions, current_motors_positions)

                if not motor_ok: return self.__manage_error(trial_index,
                                                            optimization_criteria,
                                                            motors_to_optimize,
                                                            suggested_motor_positions,
                                                            current_motors_positions,
                                                            error_message,
                                                            None)
            except Exception as e:
                return self.__manage_error(trial_index,
                                           optimization_criteria,
                                           motors_to_optimize,
                                           suggested_motor_positions,
                                           None,
                                           "Unexpected error while setting motors: " + str(e),
                                           None)
            try:
                beam            = self._beam_manager.get_beam()
                beam_properties = self._beam_manager.get_beam_properties(beam)

                if beam_properties.get_parameter("is_empty_beam", False): return self.__manage_error(trial_index,
                                                                                                                          optimization_criteria,
                                                                                                                          motors_to_optimize,
                                                                                                                          suggested_motor_positions,
                                                                                                                          current_motors_positions,
                                                                                                              "Beam is Empty",
                                                                                                                          beam)

                loss_function, error, message = self._hypervolume_manager.evaluate_loss_function(beam_properties, optimization_criteria)

                if error > 0:
                    return self.__manage_error(trial_index,
                                               optimization_criteria,
                                               motors_to_optimize,
                                               suggested_motor_positions,
                                               current_motors_positions,
                                               message,
                                               beam)
                else:
                    self._optimization_listener.feedback(trial_index=trial_index,
                                                         motors_to_optimize=motor_ids_to_optimize,
                                                         suggested_motor_positions=suggested_motor_positions,
                                                         actual_motor_positions=current_motors_positions,
                                                         current_loss=loss_function)
                    return loss_function, current_motors_positions, beam
            except Exception as e:
                return self.__manage_error(trial_index,
                                           optimization_criteria,
                                           motors_to_optimize,
                                           suggested_motor_positions,
                                           current_motors_positions,
                                           "Unexpected error: " + str(e),
                                           None)

        loss_function, current_motor_positions, beam = get_current_loss_function(self._current_trial_index)

        exit_strategy_fulfilled = False
        if execution_parameters.use_exit_strategy:
            exit_loss_function = execution_parameters.exit_loss_function
            exit_strategy_fulfilled = True
            if type(exit_loss_function) == float:
                exit_strategy_fulfilled = loss_function["scalar_loss"] < exit_loss_function
            elif type(exit_loss_function) == dict:
                for optimization_criterion in loss_function.keys():
                    if optimization_criterion == "scalar_loss": continue
                    elif loss_function[optimization_criterion] > execution_parameters.exit_loss_function[optimization_criterion]:
                        exit_strategy_fulfilled = False
                        break

        if self.interrupt or exit_strategy_fulfilled: raise ExitStrategyException(optimized_motors_positions=current_motor_positions,
                                                                                  loss=loss_function["scalar_loss"])

        self._current_optimization_result.add_optimization_item(
            NonlinearOptimizationResultItem(trial_number=self._current_trial_index,
                                            start_time=start_time,
                                            end_time=time.time(),
                                            motor_positions=suggested_motor_positions,
                                            loss=loss_function["scalar_loss"],
                                            loss_function={key : loss_function[key] for key in loss_function.keys() if key not in ["scalar_loss"]},
                                            beam_string=None if beam is None else beam.serialize())
        )

        return loss_function["scalar_loss"]

    # ------------------------------------------------------------------------------
    #  POST-PROCESSING
    # ------------------------------------------------------------------------------

    def _get_result_file_prefix(self): return "scipy_experiment"

