#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
import abc

from aps.beamline_driver.beam_management.facade import IBeamManager, BeamProperties
from aps.beamline_driver.motion_management.facade import IMotionManager
from aps.ai.beamline_controller.agent.optimization.facade import OptimizationCriteria, OptimizationType
from aps.ai.beamline_controller.agent.optimization.abstract_optimizer import AbstractOptimizer
from aps.ai.beamline_controller.agent.facade import IAgentListener
from aps.ai.beamline_controller.agent.optimization.common.bayesian.facade import BayesianOptimizationResult, BayesianOptimizationResultItem, BayesianOptimizationInputParameters, BayesianOptimizationExecutionParameters
from aps.ai.beamline_controller.agent.optimization.common.bayesian.abstract_hypervolume_manager import IBayesianHypervolumeManager, TrialNumbersFilter

class IBayesianOptimizer:
    # ---------------------------------------------------------------------
    # WARM-START
    # ---------------------------------------------------------------------
    @classmethod
    @abc.abstractmethod
    def get_warm_start_data(cls,
                            optimization_criteria : OptimizationCriteria,
                            execution_parameters: BayesianOptimizationExecutionParameters,
                            input_parameters : BayesianOptimizationInputParameters,
                            default_search_space: dict = {},
                            **kwargs): raise NotImplementedError

# -------------------------------------------------------------
# ABSTRACT CLASS
# -------------------------------------------------------------

class AbstractBayesianOptimizer(AbstractOptimizer, IBayesianOptimizer):
    def __init__(self,  optimization_listener : IAgentListener, **kwargs):
        AbstractOptimizer.__init__(self, optimization_listener, **kwargs)

    def initialize_driver(self,
                          beam_manager : IBeamManager,
                          motion_manager : IMotionManager):
        super(AbstractBayesianOptimizer, self).initialize_driver(beam_manager, motion_manager)

        if self.requires_run_engine(): setattr(self, "_optimize", self.__optimize_generator)
        else:                          setattr(self, "_optimize", self.__optimize)


    def initialize_optimization(self,
                                hypervolume_manager: IBayesianHypervolumeManager = None,
                                **kwargs):
        super(AbstractBayesianOptimizer, self).initialize_optimization(hypervolume_manager, **kwargs)

        self._optimization_agent       = None
        self._current_number_of_trials = 0

    # -----------------------------------------------------------------------
    # -----------------------------------------------------------------------
    # -----------------------------------------------------------------------
    # BLUESKY DYNAMIC MANAGEMENT -> PRIVATE METHODS
    # -----------------------------------------------------------------------
    # -----------------------------------------------------------------------
    # -----------------------------------------------------------------------

    def _bo_optimize_init(self, **kwargs):
        execution_parameters: BayesianOptimizationExecutionParameters = self._execution_parameters

        self._optimization_agent = self._create_optimization_agent(**kwargs)

        if execution_parameters.optimization_type == OptimizationType.WARM_START_SAME_DETECTOR: self._attach_warm_start_data(**kwargs)

    # -----------------------------------------------------------------------

    def _bo_optimize_end(self, **kwargs) -> BayesianOptimizationResult:
        optimization_criteria = self._optimization_criteria
        execution_parameters: BayesianOptimizationExecutionParameters = self._execution_parameters

        if execution_parameters.optimization_type == OptimizationType.WARM_START_SAME_DETECTOR:  warm_start_trial_numbers = self._warm_start_data.get_trial_numbers()
        else:                                                                                    warm_start_trial_numbers = None

        optimization_result: BayesianOptimizationResult = self._hypervolume_manager.extract_optimization_result_data(self._optimization_agent,
                                                                                                                     optimization_criteria,
                                                                                                                     trial_numbers=warm_start_trial_numbers,
                                                                                                                     trial_numbers_filter=TrialNumbersFilter.EXCLUDE)

        return optimization_result

    # -----------------------------------------------------------------------

    def _get_best_trial_data_after_optimization(self,
                                                optimization_result: BayesianOptimizationResult,
                                                execution_parameters: BayesianOptimizationExecutionParameters): raise NotImplementedError

    def __optimize(self, **kwargs) -> BayesianOptimizationResult:
        execution_parameters: BayesianOptimizationExecutionParameters = self._execution_parameters

        self._bo_optimize_init(**kwargs)
        self._beam_manager.set_initial_flux(**kwargs)

        if not self.interrupt:
            self._current_number_of_trials, \
            self._current_timestamps, \
            self._current_raw_data = self._run_optimization(**kwargs)

        optimization_result = self._bo_optimize_end(**kwargs)

        try:
            if execution_parameters.move_motors_on_best_trial:
                best_trial_data, _ = self._get_best_trial_data_after_optimization(optimization_result, execution_parameters)

                self._move_motors(best_trial_data.motor_positions)

                print("Motors has been moved to the selected best trial")
        except Exception as e:
            print("Motors has not been moved to the selected best trial for the following exception:\n" + str(e))

        return optimization_result
    # -----------------------------------------------------------------------

    def __optimize_generator(self, **kwargs) -> BayesianOptimizationResult:
        execution_parameters: BayesianOptimizationExecutionParameters = self._execution_parameters

        self._bo_optimize_init(**kwargs)
        yield from self._beam_manager.set_initial_flux(**kwargs)

        if not self.interrupt:
            self._current_number_of_trials, \
            self._current_timestamps, \
            self._current_raw_data = yield from self._run_optimization(**kwargs)

        optimization_result = self._bo_optimize_end(**kwargs)

        try:
            if execution_parameters.move_motors_on_best_trial:
                best_trial_data, _ = self._get_best_trial_data_after_optimization(optimization_result, execution_parameters)

                yield from self._move_motors(best_trial_data.motor_positions)

                print("Motors has been moved to the selected best trial")
        except Exception as e:
            print("Motors has not been moved to the selected best trial for the following exception:\n" + str(e))

        return optimization_result

    # -----------------------------------------------------------------------
    # -----------------------------------------------------------------------
    # -----------------------------------------------------------------------

    # ---------------------------------------------------------------------
    # EXECUTION METHODS
    # ---------------------------------------------------------------------

    @abc.abstractmethod
    def _create_optimization_agent(self, **kwargs): raise NotImplementedError

    @abc.abstractmethod
    def _run_optimization(self, **kwargs) -> (int, dict): raise NotImplementedError

    # ---------------------------------------------------------------------
    # POST-PROCESSING
    # ---------------------------------------------------------------------

    def get_optimization_result_data(self, **kwargs) -> BayesianOptimizationResult:
        return super(AbstractBayesianOptimizer, self).get_optimization_result_data(**kwargs)

    def get_trial_data(self, trial_index: int, **kwargs) -> (BayesianOptimizationResultItem, BeamProperties):
        return super(AbstractBayesianOptimizer, self).get_trial_data(trial_index, **kwargs)

    def get_best_trial_data(self, optimization_result : BayesianOptimizationResult = None, **kwargs) -> (BayesianOptimizationResultItem, BeamProperties): raise NotImplementedError

    @abc.abstractmethod
    def _get_result_file_prefix(self): raise NotImplementedError

    # ---------------------------------------------------------------------
    # WARM-START
    # ---------------------------------------------------------------------

    @abc.abstractmethod
    def _attach_warm_start_data(self, **kwargs): raise NotImplementedError
