#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #

from typing import Tuple
from aps.beamline_driver.beam_management.abstract_beam_manager import WavefrontAnalysisProperties
from aps.ai.beamline_controller.agent.optimization.facade import OptimizationDirection
from aps.ai.beamline_controller.agent.facade import ERROR_LOSS

from aps.ai.beamline_controller.agent.optimization.decorators.abstract_hypervolume_manager_decorator import AbstractHyperVolumeManagerDecorator

class WavefrontAnalysisOptimizationCriteria():
    INTENSITY_CENTROID_H              = WavefrontAnalysisProperties.INTENSITY_CENTROID_H            
    INTENSITY_CENTROID_V              = WavefrontAnalysisProperties.INTENSITY_CENTROID_V            
    INTENSITY_CENTROID_SPHERICAL      = WavefrontAnalysisProperties.INTENSITY_CENTROID_V[:-2] + "_spherical"            
    INTENSITY_FWHM_H                  = WavefrontAnalysisProperties.INTENSITY_FWHM_H
    INTENSITY_FWHM_V                  = WavefrontAnalysisProperties.INTENSITY_FWHM_V                
    INTENSITY_FWHM_SPHERICAL          = WavefrontAnalysisProperties.INTENSITY_FWHM_V[:-2] + "_spherical"                
    INTENSITY_FWHM_CONVOLUTION        = WavefrontAnalysisProperties.INTENSITY_FWHM_V[:-2] + "_convolution"                
    INTENSITY_SIGMA_H                 = WavefrontAnalysisProperties.INTENSITY_SIGMA_H               
    INTENSITY_SIGMA_V                 = WavefrontAnalysisProperties.INTENSITY_SIGMA_V               
    INTENSITY_SIGMA_SPHERICAL         = WavefrontAnalysisProperties.INTENSITY_SIGMA_V[:-2] + "_spherical"                
    INTENSITY_SIGMA_CONVOLUTION       = WavefrontAnalysisProperties.INTENSITY_SIGMA_V[:-2] + "_convolution"                
    NEGATIVE_LOG_INTENSITY_MAXIMUM    = "negative-log-" + WavefrontAnalysisProperties.INTENSITY_MAXIMUM               
    LOG_WEIGHTED_INTENSITY_INTEGRAL   = "log-weighted-" + WavefrontAnalysisProperties.INTENSITY_INTEGRAL              
    FOCUS_Z_POSITION_H                = WavefrontAnalysisProperties.FOCUS_Z_POSITION_H
    FOCUS_Z_POSITION_V                = WavefrontAnalysisProperties.FOCUS_Z_POSITION_V
    
    __list = [INTENSITY_CENTROID_H,             
              INTENSITY_CENTROID_V,             
              INTENSITY_CENTROID_SPHERICAL,     
              INTENSITY_FWHM_H,
              INTENSITY_FWHM_V,                 
              INTENSITY_FWHM_SPHERICAL,         
              INTENSITY_FWHM_CONVOLUTION,       
              INTENSITY_SIGMA_H,                
              INTENSITY_SIGMA_V,                
              INTENSITY_SIGMA_SPHERICAL,        
              INTENSITY_SIGMA_CONVOLUTION,      
              NEGATIVE_LOG_INTENSITY_MAXIMUM,   
              LOG_WEIGHTED_INTENSITY_INTEGRAL,  
              FOCUS_Z_POSITION_H,
              FOCUS_Z_POSITION_V]

    @classmethod
    def to_list(cls): return cls.__list

    @classmethod
    def get_optimization_directions(cls):
        return { k : OptimizationDirection.MINIMIZE for k in cls.to_list()}


class WavefrontAnalysisHyperVolumeManagerDecorator(AbstractHyperVolumeManagerDecorator):
    def _get_managed_optimization_criteria(self) -> Tuple[list, dict]:
        return WavefrontAnalysisOptimizationCriteria.to_list(), WavefrontAnalysisOptimizationCriteria.get_optimization_directions()

    def _is_logarithmic_criterion(self, optimization_criterion : str) -> bool:
        return optimization_criterion in [WavefrontAnalysisOptimizationCriteria.NEGATIVE_LOG_INTENSITY_MAXIMUM,
                                          WavefrontAnalysisOptimizationCriteria.LOG_WEIGHTED_INTENSITY_INTEGRAL]

    def _initialize_optimization_criteria_functions(self, error_loss=ERROR_LOSS):
        def intensity_centroid_h(beam_properties):
            return self._get_value_from_beam(beam_properties, WavefrontAnalysisOptimizationCriteria.INTENSITY_CENTROID_H, absolute=True, error_loss=error_loss)
        def intensity_centroid_v(beam_properties):
            return self._get_value_from_beam(beam_properties, WavefrontAnalysisOptimizationCriteria.INTENSITY_CENTROID_V, absolute=True, error_loss=error_loss)
        def intensity_fwhm_h(beam_properties):
            return self._get_value_from_beam(beam_properties, WavefrontAnalysisOptimizationCriteria.INTENSITY_FWHM_H, error_loss=error_loss)
        def intensity_fwhm_v(beam_properties):
            return self._get_value_from_beam(beam_properties, WavefrontAnalysisOptimizationCriteria.INTENSITY_FWHM_V, error_loss=error_loss)
        def intensity_sigma_h(beam_properties):
            return self._get_value_from_beam(beam_properties, WavefrontAnalysisOptimizationCriteria.INTENSITY_SIGMA_H, error_loss=error_loss)
        def intensity_sigma_v(beam_properties):
            return self._get_value_from_beam(beam_properties, WavefrontAnalysisOptimizationCriteria.INTENSITY_SIGMA_V, error_loss=error_loss)
        def focus_z_position_h(beam_properties):
            return self._get_value_from_beam(beam_properties, WavefrontAnalysisOptimizationCriteria.FOCUS_Z_POSITION_H, absolute=True, error_loss=error_loss)
        def focus_z_position_v(beam_properties):
            return self._get_value_from_beam(beam_properties, WavefrontAnalysisOptimizationCriteria.FOCUS_Z_POSITION_V, absolute=True, error_loss=error_loss)
        def negative_log_intensity_maximum(beam_properties):
            return self._get_negative_log_peak_intensity(beam_properties, error_loss=error_loss)
        def log_weighted_intensity_integral(beam_properties):
            return self._get_log_weighted_integral_intensity(beam_properties, error_loss=error_loss)
        def centroid_spherical(beam_properties):
            return self._get_spherical_value(self._get_value_from_beam(beam_properties, WavefrontAnalysisOptimizationCriteria.INTENSITY_CENTROID_H, error_loss=error_loss),
                                             self._get_value_from_beam(beam_properties, WavefrontAnalysisOptimizationCriteria.INTENSITY_CENTROID_V, error_loss=error_loss))
        def fwhm_spherical(beam_properties):
            return self._get_spherical_value(self._get_value_from_beam(beam_properties, WavefrontAnalysisOptimizationCriteria.INTENSITY_FWHM_H, error_loss=error_loss),
                                             self._get_value_from_beam(beam_properties, WavefrontAnalysisOptimizationCriteria.INTENSITY_FWHM_V, error_loss=error_loss))
        def sigma_spherical(beam_properties):
            return self._get_spherical_value(self._get_value_from_beam(beam_properties, WavefrontAnalysisOptimizationCriteria.INTENSITY_SIGMA_H, error_loss=error_loss),
                                             self._get_value_from_beam(beam_properties, WavefrontAnalysisOptimizationCriteria.INTENSITY_SIGMA_V, error_loss=error_loss))
        def fwhm_convolution(beam_properties):
            return self._get_convolution_value(self._get_value_from_beam(beam_properties, WavefrontAnalysisOptimizationCriteria.INTENSITY_FWHM_H, error_loss=error_loss),
                                               self._get_value_from_beam(beam_properties, WavefrontAnalysisOptimizationCriteria.INTENSITY_FWHM_V, error_loss=error_loss))
        def sigma_convolution(beam_properties):
            return self._get_convolution_value(self._get_value_from_beam(beam_properties, WavefrontAnalysisOptimizationCriteria.INTENSITY_SIGMA_H, error_loss=error_loss),
                                               self._get_value_from_beam(beam_properties, WavefrontAnalysisOptimizationCriteria.INTENSITY_SIGMA_V, error_loss=error_loss))

        return {WavefrontAnalysisOptimizationCriteria.INTENSITY_CENTROID_H: intensity_centroid_h,
                WavefrontAnalysisOptimizationCriteria.INTENSITY_CENTROID_V: intensity_centroid_v,
                WavefrontAnalysisOptimizationCriteria.INTENSITY_CENTROID_SPHERICAL: centroid_spherical,
                WavefrontAnalysisOptimizationCriteria.INTENSITY_FWHM_H: intensity_fwhm_h,
                WavefrontAnalysisOptimizationCriteria.INTENSITY_FWHM_V: intensity_fwhm_v,
                WavefrontAnalysisOptimizationCriteria.INTENSITY_FWHM_SPHERICAL: fwhm_spherical,
                WavefrontAnalysisOptimizationCriteria.INTENSITY_FWHM_CONVOLUTION: fwhm_convolution,
                WavefrontAnalysisOptimizationCriteria.INTENSITY_SIGMA_H: intensity_sigma_h,
                WavefrontAnalysisOptimizationCriteria.INTENSITY_SIGMA_V: intensity_sigma_v,
                WavefrontAnalysisOptimizationCriteria.INTENSITY_SIGMA_SPHERICAL: sigma_spherical,
                WavefrontAnalysisOptimizationCriteria.INTENSITY_SIGMA_CONVOLUTION: sigma_convolution,
                WavefrontAnalysisOptimizationCriteria.FOCUS_Z_POSITION_H: focus_z_position_h,
                WavefrontAnalysisOptimizationCriteria.FOCUS_Z_POSITION_V: focus_z_position_v,
                WavefrontAnalysisOptimizationCriteria.NEGATIVE_LOG_INTENSITY_MAXIMUM: negative_log_intensity_maximum,
                WavefrontAnalysisOptimizationCriteria.LOG_WEIGHTED_INTENSITY_INTEGRAL: log_weighted_intensity_integral}