#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
import os
from typing import List
from time import time
import numpy as np
import multiprocessing

from aps.ai.beamline_controller.agent.optimization.facade import WarmStartDataType, WarmStartStrategy, Beam, OptimizationType
from aps.ai.beamline_controller.agent.facade import Fidelity

from aps.ai.beamline_controller.agent.optimization.common.bayesian.facade import \
    BayesianOptimizationInputParameters, BayesianOptimizationExecutionParameters, \
    BayesianOptimizationResult, BayesianOptimizationResultItem, \
    OptimizationTrialStatus, Sampling

# -------------------------------------------------------------
# USER INPUT
# -------------------------------------------------------------

class SOBOBayesianOptimizationInputParameters(BayesianOptimizationInputParameters):
    def __init__(self,
                 acquisition_function=None,
                 sobol_trials=10,
                 bo_trials=10,
                 motors_to_optimize=None,
                 beam_manager_type: str = None,
                 platform: str          = None,
                 beam_manager_id: str   = None,
                 random_seed=2124,
                 **kwargs):
        super(SOBOBayesianOptimizationInputParameters, self).__init__(acquisition_function=acquisition_function,
                                                                      sobol_trials=sobol_trials,
                                                                      bo_trials=bo_trials,
                                                                      motors_to_optimize=motors_to_optimize,
                                                                      beam_manager_type=beam_manager_type,
                                                                      platform=platform,
                                                                      beam_manager_id=beam_manager_id,
                                                                      random_seed=random_seed,
                                                                      **kwargs)

class SOBOBayesianOptimizationExecutionParameters(BayesianOptimizationExecutionParameters):
    def __init__(self,
                 home_directory: str = os.curdir,
                 do_batch_optimization: bool = False,
                 batch_size: int = min(1, multiprocessing.cpu_count()-2),
                 optimization_type: int = OptimizationType.FULL_START,
                 warm_start_home_directory: str = os.curdir,
                 warm_start_data_type: int = WarmStartDataType.PARETO_FRONTIERS,
                 warm_start_strategy: int = WarmStartStrategy.MAXIMUM_EXTENSION,
                 warm_start_expansion_factors: list = [0.1, 1.5],
                 use_warm_start_search_space: bool = True,
                 use_warm_start_hypervolume_reference_points: bool = True,
                 erase_warm_start_data: bool = True,
                 save_warm_start_data: bool = True,
                 use_exit_strategy: bool = False,
                 exit_loss_function: dict = {},
                 convergence_threshold: float = 0.01,
                 patience: int = 5,
                 move_motors_on_best_trial: bool = False,
                 requires_pause_at_end: bool = False):
        super(SOBOBayesianOptimizationExecutionParameters, self).__init__(home_directory=home_directory,
                                                                          do_batch_optimization=do_batch_optimization,
                                                                          batch_size=batch_size,
                                                                          optimization_type=optimization_type,
                                                                          warm_start_home_directory=warm_start_home_directory,
                                                                          warm_start_data_type=warm_start_data_type,
                                                                          warm_start_strategy=warm_start_strategy,
                                                                          warm_start_expansion_factors=warm_start_expansion_factors,
                                                                          use_warm_start_search_space=use_warm_start_search_space,
                                                                          use_warm_start_hypervolume_reference_points=use_warm_start_hypervolume_reference_points,
                                                                          erase_warm_start_data=erase_warm_start_data,
                                                                          save_warm_start_data=save_warm_start_data,
                                                                          use_exit_strategy=use_exit_strategy,
                                                                          exit_loss_function=exit_loss_function,
                                                                          convergence_threshold=convergence_threshold,
                                                                          patience=patience,
                                                                          move_motors_on_best_trial=move_motors_on_best_trial,
                                                                          requires_pause_at_end=requires_pause_at_end)

# -------------------------------------------------------------
# Optimization Output
# -------------------------------------------------------------

class SOBOBayesianOptimizationResultItem(BayesianOptimizationResultItem):
    def __init__(self,
                 trial_number: int = 0,
                 start_time:float = time(),
                 end_time: float  = time(),
                 fidelity: int = Fidelity.LOW,
                 status: int = OptimizationTrialStatus.COMPLETED,
                 motor_positions: dict = {},  # motor_id : position
                 loss_function: dict = {},  # {optimization_criterion : loss }
                 scalar_loss: float = np.nan,
                 sampling: int = Sampling.OPTIMIZED,
                 beam: Beam = None,
                 beam_string: str = None):
        super(SOBOBayesianOptimizationResultItem, self).__init__(trial_number=trial_number,
                                                                 start_time=start_time,
                                                                 end_time=end_time,
                                                                 fidelity=fidelity,
                                                                 status=status,
                                                                 motor_positions=motor_positions,
                                                                 loss_function=loss_function,
                                                                 scalar_loss=scalar_loss,
                                                                 sampling=sampling,
                                                                 beam=beam,
                                                                 beam_string=beam_string)

class SOBOBayesianOptimizationResult(BayesianOptimizationResult):
    def __init__(self, optimization_items: List[SOBOBayesianOptimizationResultItem]=None):
        super(SOBOBayesianOptimizationResult, self).__init__(optimization_items)

