#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
try:
    from databroker import Broker
    from databroker.assets.utils import install_sentinels
    DATA_BROKER_IS_AVALIABLE = True
except Exception:
    print("WARNING: Data Broker not available")
    DATA_BROKER_IS_AVALIABLE = False

from bluesky.callbacks.best_effort import BestEffortCallback
from bluesky.run_engine import RunEngine, RunEngineResult

def get_data_broker(broker_name="temp"):
    if DATA_BROKER_IS_AVALIABLE:
        data_broker = Broker.named(broker_name)
        try:    install_sentinels(data_broker.reg.config, version=1)
        except: pass
        return data_broker
    else:
        return None

def create_run_engine(broker_name="temp", best_effort_callback=False): #-> (RunEngine, Broker):
    run_engine = RunEngine({}, context_managers=[])
    if best_effort_callback: run_engine.subscribe(BestEffortCallback())
    if DATA_BROKER_IS_AVALIABLE:
        data_broker = get_data_broker(broker_name)
        run_engine.subscribe(data_broker.insert)
    else:
        data_broker = None

    return run_engine, data_broker

def execute_run_engine(bluesky_plan, arguments=None, kwarguments=None, broker_name="temp") -> RunEngineResult:
    run_engine, _ = create_run_engine(broker_name)

    if not arguments is None:
        if not kwarguments is None: return run_engine(bluesky_plan(*arguments, **kwarguments))
        else:                       return run_engine(bluesky_plan(*arguments))
    else:
        if not kwarguments is None: return run_engine(bluesky_plan(**kwarguments))
        else:                       return run_engine(bluesky_plan())


