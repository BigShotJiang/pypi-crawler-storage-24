#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
import traceback

from aps.common.initializer import register_ini_instance, get_registered_ini_instance, IniMode
from aps.common.plot.qt_application import get_registered_qt_application_instance
from aps.common.scripts.generic_qt_script import GenericQTScript
from aps.common.logger import register_logger_single_instance, DEFAULT_STREAM, LoggerMode
from aps.common.widgets.congruence import check_and_create_directory

from aps.ai.beamline_controller.gui.configuration.configuration_editor import APPLICATION_NAME, create_configuration_editor

class MainConfigurationEditor(GenericQTScript):
    SCRIPT_ID = "Configuration-Editor"

    def _parse_additional_parameters(self, **kwargs):
        __args = super(MainConfigurationEditor, self)._parse_additional_parameters(**kwargs)
        __args["INI_MODE"] = IniMode.LOCAL_JSON_FILE

        return __args

    def _get_script_id(self): return MainConfigurationEditor.SCRIPT_ID
    def _get_ini_file_name(self): return ".beamline-controller.json"
    def _get_application_name(self): return APPLICATION_NAME
    def _get_script_package(self): return "aps.ai."

    def _run_script(self, **args):
        configuration_editor = create_configuration_editor(working_directory=self._working_directory, optical_system_id=self._optical_system_id)

        # ==========================================================================
        # %% Initialization parameters
        # ==========================================================================

        configuration_editor.show_configuration_editor()

        get_registered_qt_application_instance().run_qt_application()

        # ==========================================================================
        # %% Final Operations
        # ==========================================================================

        get_registered_ini_instance(self._get_application_name()).push()
        get_registered_ini_instance(self._get_application_name() + "-GUI").push()

    def _parse_additional_sys_argument(self, sys_argument, args):
        if "-m" == sys_argument[:2]: args["LOG_POOL"] = int(sys_argument[2:])
        if "-o" == sys_argument[:2]: args["OPTICAL_SYSTEM_ID"] = sys_argument[2:]

    def _help_additional_parameters(self):
        help = "  -m<use multiple loggers>\n"
        help += "   use multiple loggers:\n" + \
                "     0 on GUI only - Default value\n" + \
                "     1 on GUI and on File\n" + \
                "     2 on stdout - Default value when p=2,3\n" + \
                "     3 on stdout and on File\n"

        return help

    def _manage_working_directory(self, **args):
        optical_system_id       = args.get("OPTICAL_SYSTEM_ID", "TEST-BL")
        current_directory = os.path.abspath(os.getcwd())

        if current_directory[-len(optical_system_id):] == optical_system_id: self._working_directory = current_directory
        else: self._working_directory = os.path.join(current_directory, optical_system_id)
        self._optical_system_id = optical_system_id

        check_and_create_directory(None, self._working_directory, "Working Directory")

        os.chdir(self._working_directory)

    def _register_logger_instance(self, logger_mode, application_name, **args):
        self._manage_working_directory(**args)

        # No Log, but prevents errors
        register_logger_single_instance(stream=DEFAULT_STREAM, logger_mode=LoggerMode.NONE, application_name=application_name)

    def _register_ini_instance(self, ini_mode, application_name, **args):
        super(MainConfigurationEditor, self)._register_ini_instance(ini_mode, application_name, **args)

        register_ini_instance(IniMode.LOCAL_JSON_FILE,
                              ini_file_name=".configuration-editor.json",
                              application_name=self._get_application_name() + "-GUI")

import os, sys

if __name__=="__main__":
    if os.getenv('BC_DEBUG', "0") == "1": MainConfigurationEditor(sys_argv=sys.argv).run_script()
    else: MainConfigurationEditor().show_help()
