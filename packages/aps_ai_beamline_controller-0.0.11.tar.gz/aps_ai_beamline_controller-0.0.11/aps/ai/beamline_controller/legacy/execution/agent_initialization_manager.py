#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
import copy
import os

from aps.common.scripts.generic_process_manager import GenericProcessManager
from aps.common.initializer import get_registered_ini_instance
from aps.common.reflection import instance_for_name, get_class_name_and_module

from aps.ai.beamline_controller.legacy.initialization.facade import NullAgentInitializer

class IAgentInitializationManager(GenericProcessManager):
    def get_available_beam_managers(self): raise NotImplementedError

class AgentInitializationManager(IAgentInitializationManager):
    def __init__(self, application_name: str, working_directory: str, beamline_id: str, **kwargs):

        if application_name is None:  raise ValueError("Application name not specified")
        if working_directory is None: working_directory = os.getcwd()
        if beamline_id is None:       raise ValueError("Beamline ID not specified")

        self._application_name  = application_name
        self._beamline_id       = beamline_id
        self._working_directory = working_directory

        self.reload_utils()
        self._setup_agent_initialization(**kwargs)

    def reload_utils(self):
        self._ini = get_registered_ini_instance(application_name=self._application_name)

    def get_available_beam_managers(self): return self._available_beam_managers

    def _create_agent_initializer(self):
        agent_initializer_class, agent_initializer_module = get_class_name_and_module(self._ini.get_string_from_ini("AI", "agent, initialization",
                                                                                                                    default="aps.ai.beamline_controller.legacy.initialization.facade.NullAgentInitializer"))

        try:
            agent_initializer = instance_for_name(module_name=agent_initializer_module,
                                                  class_name=agent_initializer_class,
                                                  **{"application_name": self._application_name,
                                                     "beamline_id": self._beamline_id})

        except Exception as e:
            print("Failed to load Agent Initializer: " + str(e))
            agent_initializer = NullAgentInitializer(application_name=self._application_name,
                                                     beamline_id=self._beamline_id)

        return agent_initializer

    def _setup_agent_initialization(self, **kwargs):
        arguments = copy.deepcopy(kwargs)
        arguments["working_directory"] = self._working_directory

        self._agent_initializer = self._create_agent_initializer()
        self._agent_initializer.preliminary_setup(**arguments)

        self._available_beam_managers = self._agent_initializer.initialize_agent(**kwargs)
