#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
import copy
from aps.common.initializer import IniFacade
from aps.common.scripts.script_data import ScriptData

def generate_initialization_parameters_from_ini(ini: IniFacade):
    real_time_data = ini.get_boolean_from_ini("GUI", "real_time_data", default=False)
    capture_stdout = ini.get_boolean_from_ini("GUI", "capture_stdout", default=False)
    save_beams     = ini.get_boolean_from_ini("GUI", "save_beams", default=True)

    ai_types       = ini.get_list_from_ini("AI", "ai_types")
    ai_types_combo = ini.get_list_from_ini("AI", "ai_types_combo")
    ai_type        = ini.get_int_from_ini( "AI", "ai_type", default=0)

    # optimization: ai_type = 0

    optimization_types_combo = ini.get_list_from_ini("AI", "optimization, optimization_types_combo")
    optimization_type        = ini.get_int_from_ini("AI", "optimization, optimization_type")
    save_warm_start_data     = ini.get_boolean_from_ini("AI", "optimization, save_warm_start_data", default=True)

    optimizer_types       = ini.get_list_from_ini("AI", "optimization, optimizer_types")
    optimizer_types_combo = ini.get_list_from_ini("AI", "optimization, optimizer_types_combo")
    optimizer_type        = ini.get_int_from_ini( "AI", "optimization, optimizer_type", default=0)

    optimizer_type_configuration = {}
    for _optimizer_type in optimizer_types:
        optimizer_type_configuration[_optimizer_type] = {}

        optimizer_names = ini.get_list_from_ini("AI", f"optimization, {_optimizer_type}, names")

        optimizer_type_configuration[_optimizer_type]["names"]       = optimizer_names
        optimizer_type_configuration[_optimizer_type]["names_combo"] = ini.get_list_from_ini("AI", f"optimization, {_optimizer_type}, names_combo")
        optimizer_type_configuration[_optimizer_type]["name"]        = ini.get_int_from_ini( "AI", f"optimization, {_optimizer_type}, name", default=0)

        optimizer_configuration = {}

        for _optimizer_name in optimizer_names:
            optimizer_configuration[_optimizer_name] = copy.deepcopy(ini.get_dict_from_ini("AI", f"optimization, {_optimizer_type}, {_optimizer_name}"))
            try: optimizer_configuration[_optimizer_name].pop("initialization")
            except KeyError: pass

        optimizer_type_configuration[_optimizer_type]["optimizer_configuration"] = optimizer_configuration

    move_motors_on_best_trial = ini.get_boolean_from_ini("AI", "optimization, move_motors_on_best_trial", default=False)

    platforms          = ini.get_list_from_ini("AI", "platforms")
    platforms_combo    = ini.get_list_from_ini("AI", "platforms_combo")
    platform           = ini.get_int_from_ini("AI", "platform", default=1)

    beam_manager_types       = ini.get_list_from_ini("AI", "beam_manager_types")
    beam_manager_types_combo = ini.get_list_from_ini("AI", "beam_manager_types_combo")
    beam_manager_type        = ini.get_int_from_ini("AI",  "beam_manager_type")

    beam_manager_configuration = copy.deepcopy(ini.get_dict_from_ini("AI", "beam_manager"))

    for _beam_manager_type in beam_manager_types:
        try: beam_manager_configuration[_beam_manager_type].pop("initialization")
        except KeyError: pass
        try: beam_manager_configuration[_beam_manager_type].pop("arguments")
        except KeyError: pass

    # warm start
    warm_start_configuration = ini.get_dict_from_ini("AI", "optimization, warm_start")

    # neural network: ai_type = 1
    neural_network_configuration = copy.deepcopy(ini.get_dict_from_ini("AI", "neural_network"))
    neural_network_types =  neural_network_configuration["neural_network_types"]
    for _neural_network_type in neural_network_types:
        try: neural_network_configuration[_neural_network_type].pop("initialization")
        except KeyError: pass

    return ScriptData(real_time_data               = real_time_data,
                      capture_stdout               = capture_stdout,
                      save_beams                   = save_beams,
                      ai_types                     = ai_types,
                      ai_types_combo               = ai_types_combo,
                      ai_type                      = ai_type,
                      optimizer_types              = optimizer_types,
                      optimizer_types_combo        = optimizer_types_combo,
                      optimizer_type               = optimizer_type,
                      optimizer_type_configuration = optimizer_type_configuration,
                      move_motors_on_best_trial    = move_motors_on_best_trial,
                      platforms                    = platforms,
                      platforms_combo              = platforms_combo,
                      platform                     = platform,
                      beam_manager_types           = beam_manager_types,
                      beam_manager_types_combo     = beam_manager_types_combo,
                      beam_manager_type            = beam_manager_type,
                      beam_manager_configuration   = beam_manager_configuration,
                      optimization_types_combo     = optimization_types_combo,
                      optimization_type            = optimization_type,
                      save_warm_start_data         = save_warm_start_data,
                      warm_start_configuration     = warm_start_configuration,
                      neural_network_configuration = neural_network_configuration)

def set_ini_from_initialization_parameters(initialization_parameters: ScriptData, ini: IniFacade):
    platforms          = ini.get_list_from_ini("AI", "platforms")
    beam_manager_types = ini.get_list_from_ini("AI", "beam_manager_types")
    optimizer_types    = ini.get_list_from_ini("AI", "optimization, optimizer_types")

    ini.set_value_at_ini("GUI", "real_time_data", value=initialization_parameters.get_parameter("real_time_data"))
    ini.set_value_at_ini("GUI", "capture_stdout", value=initialization_parameters.get_parameter("capture_stdout"))
    ini.set_value_at_ini("GUI", "save_beams", value=initialization_parameters.get_parameter("save_beams"))

    ini.set_value_at_ini("AI", "ai_type", value=initialization_parameters.get_parameter("ai_type"))

    ini.set_value_at_ini("AI", "optimization, optimizer_type", value=initialization_parameters.get_parameter("optimizer_type"))
    ini.set_value_at_ini("AI", "optimization, save_warm_start_data", value=initialization_parameters.get_parameter("save_warm_start_data"))

    optimizer_type_configuration = initialization_parameters.get_parameter("optimizer_type_configuration")
    for _optimizer_type in optimizer_types:
        ini.set_value_at_ini("AI", f"optimization, {_optimizer_type}, name", value=optimizer_type_configuration[_optimizer_type]["name"])

        optimizer_names         = ini.get_list_from_ini("AI", f"optimization, {_optimizer_type}, names")
        optimizer_configuration = optimizer_type_configuration[_optimizer_type]["optimizer_configuration"]

        for _optimizer_name in optimizer_names:
            for _key in optimizer_configuration[_optimizer_name].keys():
                if not _key in ["initialization", "acquisition_functions"]:
                    value = optimizer_configuration[_optimizer_name][_key]

                    if type(value) == list: ini.set_list_at_ini("AI", f"optimization, {_optimizer_type}, {_optimizer_name}, {_key}", values_list=value)
                    else:                   ini.set_value_at_ini("AI", f"optimization, {_optimizer_type}, {_optimizer_name}, {_key}", value=value)

    ini.set_value_at_ini("AI", "move_motors_on_best_trial", value=initialization_parameters.get_parameter("move_motors_on_best_trial"))
    ini.set_value_at_ini("AI", "platform",                  value=initialization_parameters.get_parameter("platform"))
    ini.set_value_at_ini("AI", "beam_manager_type",         value=initialization_parameters.get_parameter("beam_manager_type"))

    beam_manager_configuration = initialization_parameters.get_parameter("beam_manager_configuration")
    for _beam_manager_type in beam_manager_types:
        ini.set_value_at_ini("AI",  f"beam_manager, {_beam_manager_type}, beam_manager_id",
                             value=beam_manager_configuration[_beam_manager_type]["beam_manager_id"])

        beam_manager_ids = ini.get_list_from_ini("AI", f"beam_manager, {_beam_manager_type}, beam_manager_ids", default=[])
        for _platform in platforms:
            for _beam_manager_id in beam_manager_ids:
                try:
                    _objectives = beam_manager_configuration[_beam_manager_type]["objectives"][_platform][_beam_manager_id]
                    _properties = beam_manager_configuration[_beam_manager_type]["properties"][_platform][_beam_manager_id]

                    ini.set_dict_at_ini("AI", f"beam_manager, {_beam_manager_type}, objectives, {_platform}, {_beam_manager_id}", _objectives)
                    ini.set_dict_at_ini("AI", f"beam_manager, {_beam_manager_type}, properties, {_platform}, {_beam_manager_id}", _properties)
                except KeyError:
                    pass

    warm_start_configuration   = initialization_parameters.get_parameter("warm_start_configuration")

    for _key in warm_start_configuration.keys():
        value = warm_start_configuration[_key]
        if type(value) == list:   ini.set_list_at_ini( "AI", f"optimization, warm_start, {_key}", values_list=value)
        elif type(value) == dict: ini.set_dict_at_ini( "AI", f"optimization, warm_start, {_key}", values_dict=value)
        else:                     ini.set_value_at_ini("AI", f"optimization, warm_start, {_key}", value=value)

    neural_network_configuration   = initialization_parameters.get_parameter("neural_network_configuration")

    for _key in neural_network_configuration.keys():
        value = neural_network_configuration[_key]
        if type(value) == list:   ini.set_list_at_ini( "AI", f"neural_network, {_key}", values_list=value)
        elif type(value) == dict: ini.set_dict_at_ini( "AI", f"neural_network, {_key}", values_dict=value)
        else:                     ini.set_value_at_ini("AI", f"neural_network, {_key}", value=value)
