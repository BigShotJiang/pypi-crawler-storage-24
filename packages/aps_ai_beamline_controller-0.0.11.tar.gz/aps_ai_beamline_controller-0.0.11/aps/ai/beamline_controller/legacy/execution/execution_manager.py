#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
import abc
import os
import sys
import copy
import time
import traceback
from typing import Any, TextIO, List

from AnyQt.QtCore import QThread, pyqtSignal, QObject

from aps.common.logger import get_registered_logger_instance, LoggerColor
from aps.common.scripts.script_data import ScriptData
from aps.common.singleton import synchronized_method
from aps.common.io.printout import date_now_str, time_now_str
from aps.common.widgets.stream_proxy import StreamProxy

from aps.beamline_driver.motion_management.facade import Movement, MotorsInfoLegacy, MotorInfoLegacy, MethodCallingType, IMotionManager
from aps.beamline_driver.beam_management.beam_manager_factory import create_beam_manager
from aps.beamline_driver.motion_management.motion_manager_factory import create_motion_manager

from aps.ai.beamline_controller.legacy.common.legacy_keys import Keys
from aps.ai.beamline_controller.legacy.common.bluesky_utility import create_run_engine

from aps.ai.beamline_controller.legacy.agent.facade import Fidelity
from aps.ai.beamline_controller.legacy.agent.agent_listener_factory import create_agent_listener, initialize_agent_listener_factory, IAgentListener
from aps.ai.beamline_controller.legacy.agent.optimization.facade import OptimizationCriteria, WarmStartDataType, WarmStartStrategy, OptimizationResultItem
from aps.ai.beamline_controller.legacy.agent.optimization.optimizer_factory import create_optimizer
from aps.ai.beamline_controller.legacy.agent.optimization.hypervolume_manager_factory import create_hypervolume_manager
from aps.ai.beamline_controller.legacy.agent.optimization.moo.bayesian.facade import MOBOBayesianOptimizationExecutionParameters, MOBOBayesianOptimizationInputParameters, SelectionAlgorithm
from aps.ai.beamline_controller.legacy.agent.optimization.soo.nonlinear.facade import NonLinearOptimizationExecutionParameters, NonLinearOptimizationInputParameters
from aps.ai.beamline_controller.legacy.agent.optimization.soo.nonlinear.scipy.optimizer import ScipyOptimizationModel
from aps.ai.beamline_controller.legacy.agent.optimization.soo.bayesian.facade import SOBOBayesianOptimizationExecutionParameters, SOBOBayesianOptimizationInputParameters
from aps.ai.beamline_controller.legacy.agent.machine_learning.neural_networks.tandem_neural_network import TandemNeuralNetwork, NeuralNetworkParameters
from aps.ai.beamline_controller.legacy.agent.machine_learning.neural_networks.neural_network_manager_factory import create_neural_network_manager

from aps.ai.beamline_controller.legacy.execution.execution_initialization_parameters import generate_initialization_parameters_from_ini, set_ini_from_initialization_parameters
from aps.ai.beamline_controller.legacy.execution.configuration_manager import AbstractConfigurationManager

f1 = "%m/%d/%Y"
f2 = "%H:%M:%S"

class IExecutionManager():
    # START OPTIMIZATION
    def start_ai_agent(self, initialization_parameters : ScriptData = None, **kwargs): raise NotImplementedError() # generator
    # GET RESULTS AFTER OPTIMIZATION
    def get_current_result(self): raise NotImplementedError()
    def get_current_initialization_parameters(self): raise NotImplementedError()
    def get_trial(self, trial_index, initialization_parameters=None): raise NotImplementedError()
    def get_pareto_trial_number(self, pareto_selection, initialization_parameters = None): raise NotImplementedError()
    def get_optimization_history(self): raise NotImplementedError()
    # PRE/POST-OPTIMIZATION ACTIONS
    def move_motors_to_trial_data(self, trial_data: OptimizationResultItem): raise NotImplementedError()                                                 # generator
    def set_current_motor_positions_as_initial_points(self, motors_info: MotorsInfoLegacy, initialization_parameters: ScriptData): raise NotImplementedError() # generator
    def move_motors_to_initial_points(self, motors_info: MotorsInfoLegacy, initialization_parameters: ScriptData): raise NotImplementedError()                 # generator
    def transfer_current_position_to_beam_manager_search_space(self, initialization_parameters: ScriptData): raise NotImplementedError()                 # generator

class AbstractExecutionManager(AbstractConfigurationManager, IExecutionManager, IAgentListener):
    def __init__(self, application_name: str, working_directory: str, beamline_id: str, run_as_generator=False, **kwargs):
        super(AbstractExecutionManager, self).__init__(application_name, working_directory, beamline_id, **kwargs)

        self._run_as_generator  = run_as_generator

        if run_as_generator:
            setattr(self, "start_ai_agent",                                         self.__start_ai_agent_generator)
            setattr(self, "move_motors_to_trial_data",                              self.__move_motors_to_trial_data_generator)
            setattr(self, "set_current_motor_positions_as_initial_points",          self.__set_current_motor_positions_as_initial_points_generator)
            setattr(self, "move_motors_to_initial_points",                          self.__move_motors_to_initial_points_generator)
            setattr(self, "transfer_current_position_to_beam_manager_search_space", self.__transfer_current_position_to_beam_manager_search_space_generator)
            setattr(self, "_start_ai_process",                                      self.__start_ai_process_generator)
        else:
            setattr(self, "start_ai_agent",                                         self.__start_ai_agent)
            setattr(self, "move_motors_to_trial_data",                              self.__move_motors_to_trial_data)
            setattr(self, "set_current_motor_positions_as_initial_points",          self.__set_current_motor_positions_as_initial_points)
            setattr(self, "move_motors_to_initial_points",                          self.__move_motors_to_initial_points)
            setattr(self, "transfer_current_position_to_beam_manager_search_space", self.__transfer_current_position_to_beam_manager_search_space)
            setattr(self, "_start_ai_process",                                      self.__start_ai_process)

        self.__current_ai_process = None
        self.__current_ai_agent   = None
        self.__current_ai_input   = None
        self.__current_ai_result  = None

    @abc.abstractmethod
    def abort(self): raise NotImplementedError
    @abc.abstractmethod
    def _create_ai_process(self): raise NotImplementedError
    @abc.abstractmethod
    def _connect_ai_process_handlers(self, ai_process): raise NotImplementedError
    @abc.abstractmethod
    def _send_agent_completed(self): raise NotImplementedError()
    @abc.abstractmethod
    def _connect_agent_completed(self, agent_completed_handler): raise NotImplementedError()

    def reload_utils(self):
        super(AbstractExecutionManager, self).reload_utils()

        self._logger  = get_registered_logger_instance(application_name=self._application_name)

    def _get_run_engine(self):
        try:
            run_engine  = self._agent_initializer.run_engine
            data_broker = self._agent_initializer.data_broker
        except:
            run_engine, data_broker = create_run_engine()

        return run_engine, data_broker

    # -----------------------------------------------------------------------------------------------------------------------
    #
    # OPTIMIZATION
    #
    # -----------------------------------------------------------------------------------------------------------------------

    def __create_ai_agent(self, initialization_parameters, ai_process):
        beam_manager_id_key, beam_manager_type_key, platform_key = self.__get_beam_manager_pointers(initialization_parameters)

        beam_manager_full_id = Keys.compose_manager_key(beamline_id=self._beamline_id,
                                                        platform=platform_key,
                                                        beam_manager_type=beam_manager_type_key,
                                                        beam_manager_id=beam_manager_id_key,
                                                        manager_key=Keys.Managers.BeamManager)

        motion_manager_full_id = Keys.compose_manager_key(beamline_id=self._beamline_id,
                                                          platform=platform_key,
                                                          beam_manager_type=beam_manager_type_key,
                                                          beam_manager_id=beam_manager_id_key,
                                                          manager_key=Keys.Managers.MotionManager) \
            if platform_key == Keys.Platforms.DigitalTwin else \
                                 Keys.compose_manager_key(beamline_id=self._beamline_id,
                                                          platform=platform_key,
                                                          manager_key=Keys.Managers.MotionManager)

        try: motion_manager = create_motion_manager(motion_manager_id=motion_manager_full_id)
        except: raise ValueError(f"Motion Manager {motion_manager_full_id} not supported")
        try: beam_manager   = create_beam_manager(beam_manager_id=beam_manager_full_id)
        except: raise ValueError(f"Beam Manager {beam_manager_full_id} not supported")

        motors_to_optimize        = motion_manager.get_motors_info().get_motor_ids_to_optimize(beam_manager_type=beam_manager_type_key,
                                                                                               platform=platform_key,
                                                                                               beam_manager_id=beam_manager_id_key)
        move_motors_on_best_trial = initialization_parameters.get_parameter("move_motors_on_best_trial")

        beam_manager_configuration = initialization_parameters.get_parameter("beam_manager_configuration")
        beam_manager_type_configuration = beam_manager_configuration[beam_manager_type_key]

        ai_types           = initialization_parameters.get_parameter("ai_types")
        ai_type            = initialization_parameters.get_parameter("ai_type")
        ai_type_key        = ai_types[int(ai_type)]

        if ai_type_key == Keys.AITypes.Optimization:
            objectives = beam_manager_type_configuration["objectives"][platform_key][beam_manager_id_key]

            optimizer_types = initialization_parameters.get_parameter("optimizer_types")
            optimizer_type = initialization_parameters.get_parameter("optimizer_type")
            optimizer_type_key = optimizer_types[int(optimizer_type)]

            optimizer_type_configuration = initialization_parameters.get_parameter("optimizer_type_configuration")[optimizer_type_key]

            optimization_type = initialization_parameters.get_parameter("optimization_type")
            save_warm_start_data = initialization_parameters.get_parameter("save_warm_start_data", False)
            do_warm_start = optimization_type == 1

            warm_start_configuration = initialization_parameters.get_parameter("warm_start_configuration")

            optimizer_names    = optimizer_type_configuration["names"]
            optimizer_name     = optimizer_type_configuration["name"]
            optimizer_name_key = optimizer_names[optimizer_name]

            optimization_criteria                  = OptimizationCriteria(list(objectives.keys()))
            hypervolume_reference_points           = {}
            optimization_criteria_reference_values = {}
            optimization_criteria_weights          = {}
            exit_loss_function                     = {}

            for optimization_criterion in objectives.keys():
                values = objectives[optimization_criterion]

                optimization_criteria_reference_values[optimization_criterion] = float(values[0])
                hypervolume_reference_points[optimization_criterion]           = float(values[1])
                optimization_criteria_weights[optimization_criterion]          = float(values[2])
                if float(values[3]) != 0.0: exit_loss_function[optimization_criterion] = float(values[3])

            use_exit_strategy = len(exit_loss_function.keys()) > 0

            # added beam_manager_id to home directory, it represent a different optimization pattern
            home_directory = os.path.join(os.path.abspath(os.getcwd()), f"{optimizer_name_key}-{platform_key}-{beam_manager_type_key}-{beam_manager_id_key}-cr{len(objectives.keys())}")

            if warm_start_configuration.get("warm_start_home_directory_type", 0) == 0: warm_start_home_directory = home_directory
            else:                                                                      warm_start_home_directory = warm_start_configuration.get("warm_start_home_directory")

            optimizer_configuration = optimizer_type_configuration["optimizer_configuration"][optimizer_name_key]

            optimizer_id           = f"{optimizer_type_key}-{optimizer_name_key}"
            hypervolume_manager_id = f"{optimizer_type_key}-{optimizer_name_key}-{beam_manager_type_key}"

            if optimizer_type_key == Keys.OptimizerType.MOBO:
                acquisition_functions = optimizer_configuration["acquisition_functions"]
                acquisition_function  = optimizer_configuration["acquisition_function"]
                acquisition_function_key = acquisition_functions[int(acquisition_function)]

                hypervolume_manager_args = {"hypervolume_reference_points": hypervolume_reference_points,
                                            "optimization_criteria_reference_values": optimization_criteria_reference_values,
                                            "optimization_criteria_constraints": {},  # no constrained optimizer for now
                                            "optimization_criteria_weights": optimization_criteria_weights}
                hypervolume_manager = create_hypervolume_manager(hypervolume_manager_id=hypervolume_manager_id, **hypervolume_manager_args)


                sobol_trials         = int(optimizer_configuration.get("sobol_iterations", 0))
                bo_trials            = int(optimizer_configuration.get("mobo_iterations", 0))
                selection_algorithm  = self.get_selection_algorithm(optimizer_configuration.get("pareto_selection", 0))

                hypervolume_exit = optimizer_configuration.get("hypervolume_exit", {}).get("full_start" if not do_warm_start else "warm_start", {})

                convergence_threshold = hypervolume_exit.get("convergence_threshold", 0.01)
                patience              = hypervolume_exit.get("patience", 5)

                if not do_warm_start:
                    execution_parameters = MOBOBayesianOptimizationExecutionParameters(home_directory=home_directory,
                                                                                       do_warm_start=False,
                                                                                       save_warm_start_data=save_warm_start_data,
                                                                                       use_exit_strategy=use_exit_strategy,
                                                                                       convergence_threshold=convergence_threshold,
                                                                                       patience=patience,
                                                                                       exit_loss_function=exit_loss_function,
                                                                                       move_motors_on_best_trial=move_motors_on_best_trial,
                                                                                       selection_algorithm=selection_algorithm)
                    input_parameters = MOBOBayesianOptimizationInputParameters(acquisition_function=acquisition_function_key,
                                                                               sobol_trials=sobol_trials,
                                                                               bo_trials=bo_trials,
                                                                               motors_to_optimize=motors_to_optimize,
                                                                               beam_manager_type=beam_manager_type_key,
                                                                               platform=platform_key,
                                                                               beam_manager_id=beam_manager_id_key,
                                                                               random_seed=int(time.time()))
                else:
                    warm_start_strategy          = warm_start_configuration.get("warm_start_strategy", WarmStartStrategy.MAXIMUM_EXTENSION)
                    warm_start_strategy_key      = warm_start_configuration.get("warm_start_strategies")[int(warm_start_strategy)]
                    warm_start_expansion_factors = warm_start_configuration.get("warm_start_expansion_factors", [0.0, 0.01])[warm_start_strategy_key]

                    execution_parameters = MOBOBayesianOptimizationExecutionParameters(home_directory=home_directory,
                                                                                       do_warm_start=True,
                                                                                       warm_start_data_type=warm_start_configuration.get("warm_start_data_type", WarmStartDataType.PARETO_FRONTIERS),
                                                                                       warm_start_home_directory=warm_start_home_directory,
                                                                                       warm_start_strategy=warm_start_strategy,
                                                                                       warm_start_expansion_factors=warm_start_expansion_factors,
                                                                                       use_warm_start_search_space=warm_start_configuration.get("use_warm_start_search_space", 1) == 1,
                                                                                       use_warm_start_hypervolume_reference_points=warm_start_configuration.get("use_warm_start_hypervolume_reference_points", 1) == 1,
                                                                                       save_warm_start_data=save_warm_start_data,
                                                                                       use_exit_strategy=use_exit_strategy,
                                                                                       convergence_threshold=convergence_threshold,
                                                                                       patience=patience,
                                                                                       exit_loss_function=exit_loss_function,
                                                                                       move_motors_on_best_trial=move_motors_on_best_trial,
                                                                                       selection_algorithm=selection_algorithm)
                    input_parameters = MOBOBayesianOptimizationInputParameters(acquisition_function=acquisition_function_key,
                                                                               bo_trials=bo_trials,
                                                                               motors_to_optimize=motors_to_optimize,
                                                                               beam_manager_type=beam_manager_type_key,
                                                                               platform=platform_key,
                                                                               beam_manager_id=beam_manager_id_key,
                                                                               random_seed=int(time.time()))
            elif optimizer_type_key == Keys.OptimizerType.SONL:
                hypervolume_manager_args = {"optimization_criteria_reference_values": optimization_criteria_reference_values,
                                            "optimization_criteria_constraints": {},  # no constrained optimizer for now
                                            "optimization_criteria_weights": optimization_criteria_weights}
                hypervolume_manager = create_hypervolume_manager(hypervolume_manager_id=hypervolume_manager_id, **hypervolume_manager_args)

                max_iterations    = int(optimizer_configuration.get("max_iterations", 50))
                x_absolute_change = float(optimizer_configuration.get("x_absolute_change", 1e-8))
                f_absolute_change = float(optimizer_configuration.get("f_absolute_change", 1e-8))

                if not do_warm_start:
                    execution_parameters = NonLinearOptimizationExecutionParameters(home_directory=home_directory,
                                                                                    do_warm_start=False,
                                                                                    save_warm_start_data=save_warm_start_data,
                                                                                    use_exit_strategy=use_exit_strategy,
                                                                                    exit_loss_function=exit_loss_function)
                else:
                    warm_start_strategy          = warm_start_configuration.get("warm_start_strategy", WarmStartStrategy.MAXIMUM_EXTENSION)
                    warm_start_strategy_key      = warm_start_configuration.get("warm_start_strategies")[int(warm_start_strategy)]
                    warm_start_expansion_factors = warm_start_configuration.get("warm_start_expansion_factors", [0.0, 0.01])[warm_start_strategy_key]

                    execution_parameters = NonLinearOptimizationExecutionParameters(home_directory=home_directory,
                                                                                    do_warm_start=True,
                                                                                    warm_start_data_type=warm_start_configuration.get("warm_start_data_type", WarmStartDataType.PARETO_FRONTIERS),
                                                                                    warm_start_home_directory=warm_start_home_directory,
                                                                                    warm_start_strategy=warm_start_strategy,
                                                                                    warm_start_expansion_factors=warm_start_expansion_factors,
                                                                                    save_warm_start_data=save_warm_start_data,
                                                                                    use_exit_strategy=use_exit_strategy,
                                                                                    exit_loss_function=exit_loss_function)

                input_parameters = NonLinearOptimizationInputParameters(method=ScipyOptimizationModel.UNCONSTRAINED_MULTIVARIATE_SCALAR_NELDER_MEAD,
                                                                        max_iteration=max_iterations,
                                                                        motors_to_optimize=motors_to_optimize,
                                                                        beam_manager_type=beam_manager_type_key,
                                                                        platform=platform_key,
                                                                        beam_manager_id=beam_manager_id_key,
                                                                        random_seed=int(time.time()),
                                                                        x_absolute_change=x_absolute_change,
                                                                        f_absolute_change=f_absolute_change)
            elif optimizer_type_key == Keys.OptimizerType.SOBO:
                acquisition_functions = optimizer_configuration["acquisition_functions"]
                acquisition_function = optimizer_configuration["acquisition_function"]
                acquisition_function_key = acquisition_functions[int(acquisition_function)]

                hypervolume_manager_args = {"hypervolume_reference_points": hypervolume_reference_points,
                                            "optimization_criteria_reference_values": optimization_criteria_reference_values,
                                            "optimization_criteria_constraints": {},  # no constrained optimizer for now
                                            "optimization_criteria_weights": optimization_criteria_weights}
                hypervolume_manager = create_hypervolume_manager(hypervolume_manager_id=hypervolume_manager_id, **hypervolume_manager_args)

                sobol_trials = int(optimizer_configuration.get("sobol_iterations", 0))
                bo_trials = int(optimizer_configuration.get("sobo_iterations", 0))

                if not do_warm_start:
                    execution_parameters = SOBOBayesianOptimizationExecutionParameters(home_directory=home_directory,
                                                                                       do_warm_start=False,
                                                                                       save_warm_start_data=save_warm_start_data,
                                                                                       use_exit_strategy=use_exit_strategy,
                                                                                       exit_loss_function=exit_loss_function,
                                                                                       move_motors_on_best_trial=move_motors_on_best_trial)
                    input_parameters = SOBOBayesianOptimizationInputParameters(acquisition_function=acquisition_function_key,
                                                                               sobol_trials=sobol_trials,
                                                                               bo_trials=bo_trials,
                                                                               motors_to_optimize=motors_to_optimize,
                                                                               beam_manager_type=beam_manager_type_key,
                                                                               platform=platform_key,
                                                                               beam_manager_id=beam_manager_id_key,
                                                                               random_seed=int(time.time()))
                else:
                    warm_start_strategy = warm_start_configuration.get("warm_start_strategy", WarmStartStrategy.MAXIMUM_EXTENSION)
                    warm_start_strategy_key = warm_start_configuration.get("warm_start_strategies")[int(warm_start_strategy)]
                    warm_start_expansion_factors = warm_start_configuration.get("warm_start_expansion_factors", [0.0, 0.01])[warm_start_strategy_key]

                    execution_parameters = SOBOBayesianOptimizationExecutionParameters(home_directory=home_directory,
                                                                                       do_warm_start=True,
                                                                                       warm_start_data_type=warm_start_configuration.get("warm_start_data_type", WarmStartDataType.PARETO_FRONTIERS),
                                                                                       warm_start_home_directory=warm_start_home_directory,
                                                                                       warm_start_strategy=warm_start_strategy,
                                                                                       warm_start_expansion_factors=warm_start_expansion_factors,
                                                                                       use_warm_start_search_space=warm_start_configuration.get("use_warm_start_search_space", 1) == 1,
                                                                                       use_warm_start_hypervolume_reference_points=warm_start_configuration.get("use_warm_start_hypervolume_reference_points", 1) == 1,
                                                                                       save_warm_start_data=save_warm_start_data,
                                                                                       use_exit_strategy=use_exit_strategy,
                                                                                       exit_loss_function=exit_loss_function,
                                                                                       move_motors_on_best_trial=move_motors_on_best_trial)
                    input_parameters = SOBOBayesianOptimizationInputParameters(acquisition_function=acquisition_function_key,
                                                                               bo_trials=bo_trials,
                                                                               motors_to_optimize=motors_to_optimize,
                                                                               beam_manager_type=beam_manager_type_key,
                                                                               platform=platform_key,
                                                                               beam_manager_id=beam_manager_id_key,
                                                                               random_seed=int(time.time()))
            else:
                raise ValueError("Optimizer Type not recognized")

            optimizer = create_optimizer(optimizer_id=optimizer_id, optimization_listener=ai_process, verbose=True)
            optimizer.initialize_driver(beam_manager, motion_manager)

            initialize_kwargs = {}
            if optimizer.requires_run_engine():
                run_engine, data_broker = self._get_run_engine()

                initialize_kwargs["verbose"]    = True
                initialize_kwargs["data_broker"] = data_broker

                initialization_parameters.set_parameter("run_engine", run_engine)
            optimizer.initialize_optimization(hypervolume_manager, **initialize_kwargs)

            ai_agent = optimizer
            ai_input = optimization_criteria, execution_parameters, input_parameters
        elif ai_type_key == Keys.AITypes.NeuralNetworks:
            target_properties = beam_manager_type_configuration["properties"][platform_key][beam_manager_id_key]

            neural_network_configuration = initialization_parameters.get_parameter("neural_network_configuration")

            neural_network_types    = neural_network_configuration.get("neural_network_types")
            neural_network_type     = neural_network_configuration.get("neural_network_type")
            neural_network_type_key = neural_network_types[int(neural_network_type)]

            home_directory = os.path.join(os.path.abspath(os.getcwd()), f"nn-{neural_network_type_key}-{platform_key}-{beam_manager_type_key}-{beam_manager_id_key}-tp{len(target_properties.keys())}")
            if not os.path.exists(home_directory): os.mkdir(home_directory)

            initialize_agent_listener_factory(instances={f"{neural_network_type_key}_nn": ai_process})
            neural_network_listener = create_agent_listener(listener_id=f"{neural_network_type_key}_nn")

            neural_network_model_from = neural_network_configuration.get("neural_network_model_from")

            neural_network_home_directory = neural_network_configuration.get("neural_network_home_directory")
            neural_network_data_type      = neural_network_configuration.get("neural_network_data_type", 2)
            neural_network_args           = neural_network_configuration.get("neural_network_parameters", {})
            neural_network_args["neural_network_data_type"] = neural_network_data_type

            if neural_network_type_key == Keys.NeuralNetworkType.TANDEM:
                if neural_network_model_from == 0:
                    neural_network = TandemNeuralNetwork(neural_network_parameters=NeuralNetworkParameters(input_data_directory=os.path.join(neural_network_home_directory, "ml_data"),
                                                                                                           output_model_directory=os.path.join(home_directory, "trained_nn"),
                                                                                                           **neural_network_args),
                                                         motor_ids_to_optimize=motors_to_optimize,
                                                         beam_properties_names=list(target_properties.keys()),
                                                         beam_manager=beam_manager,
                                                         listener=neural_network_listener)
                elif neural_network_model_from == 1: # trained model file
                    output_model_directory, _ = os.path.split(neural_network_configuration.get("neural_network_trained_model_file"))

                    neural_network = TandemNeuralNetwork(neural_network_parameters=NeuralNetworkParameters(output_model_directory=output_model_directory),
                                                         motor_ids_to_optimize=motors_to_optimize,
                                                         beam_properties_names=list(target_properties.keys()),
                                                         beam_manager=None,
                                                         listener=neural_network_listener)
                else:
                    raise ValueError(f"Neural Network Model From not recognized {neural_network_model_from}")
            else:
                raise ValueError(f"Neural Network Type not recognized {neural_network_type_key}")

            neural_network_manager = create_neural_network_manager(neural_network_manager_id=neural_network_type_key,
                                                                   neural_network_listener=neural_network_listener)

            neural_network_manager.initialize_driver(beam_manager, motion_manager)
            neural_network_manager.initialize_neural_network(neural_network, home_directory)

            ai_agent = neural_network_manager
            ai_input = {target_property: float(target_properties[target_property][0]) for target_property in target_properties.keys()}
        else:
            raise ValueError("Ai type not recognized")

        return ai_agent, ai_input, motion_manager

    # -----------------------------------------------------------------------------------------------------------------------

    def _start_ai_process(self, ai_agent, ai_process, **kwargs): pass

    def __start_ai_process(self, ai_agent, ai_process, **kwargs):
        if kwargs.get("is_active_gui", True): ai_process.start()
        else:                                             ai_process.run_ai_agent()

    def __start_ai_process_generator(self, ai_agent, ai_process, **kwargs):
        yield from ai_process.run_ai_agent()

    # -----------------------------------------------------------------------------------------------------------------------

    @synchronized_method
    def __start_ai_agent(self, initialization_parameters: ScriptData = None, **kwargs):
        initialization_parameters, stdout = self.__start_ai_agent_init(initialization_parameters)

        try:
            ai_agent, ai_process = self.__start_ai_agent_body(initialization_parameters)

            self._start_ai_process(ai_agent, ai_process, **kwargs)
        except:
            self.__start_ai_agent_except(initialization_parameters)

        sys.stdout = stdout

    @synchronized_method
    def __start_ai_agent_generator(self, initialization_parameters: ScriptData = None, **kwargs):
        initialization_parameters, stdout = self.__start_ai_agent_init(initialization_parameters)

        try:
            ai_agent, ai_process = self.__start_ai_agent_body(initialization_parameters)

            yield from self._start_ai_process(ai_agent, ai_process, **kwargs)
        except:
            self.__start_ai_agent_except(initialization_parameters)

        sys.stdout = stdout

    def __start_ai_agent_except(self, initialization_parameters: ScriptData):
        self.finish([None, None, initialization_parameters])

        self._logger.print_error(traceback.format_exc())

    def __start_ai_agent_body(self, initialization_parameters: ScriptData):
        if initialization_parameters.get_parameter("capture_stdout"): sys.stdout = StreamProxy(stdout_print=self._logger.print)

        if not self.__current_ai_process is None:
            try:
                while (self.__current_ai_process.isRunning()):
                    self.__current_ai_process.quit()
                    time.sleep(0.1)
            except RuntimeError as e:
                if "wrapped C/C++" in str(e): pass

        ai_process = self._create_ai_process()

        ai_agent, \
        ai_input, \
        motion_manager = self.__create_ai_agent(initialization_parameters, ai_process)

        ai_process.initialize(ai_agent=ai_agent,
                              ai_input=ai_input,
                              initialization_parameters=initialization_parameters.duplicate())

        self._connect_ai_process_handlers(ai_process)

        self.__current_ai_process     = ai_process
        self.__current_ai_agent       = ai_agent
        self.__current_ai_input       = ai_input
        self.__current_motion_manager = motion_manager

        return ai_agent, ai_process

    def __start_ai_agent_init(self, initialization_parameters: ScriptData | None) -> tuple[ScriptData, TextIO | Any]:
        if initialization_parameters is None:
            initialization_parameters = generate_initialization_parameters_from_ini(ini=self._ini)
        else:
            set_ini_from_initialization_parameters(initialization_parameters, self._ini)
            self._ini.push()

        stdout = sys.stdout

        return initialization_parameters, stdout

    # -----------------------------------
    # Signals

    def get_selection_algorithm(self, pareto_selection):
        if   pareto_selection == 0: return SelectionAlgorithm.NASH_EQUILIBRIUM
        elif pareto_selection == 1: return SelectionAlgorithm.MOST_INTENSE
        elif pareto_selection == 2: return SelectionAlgorithm.NARROWEST
        elif pareto_selection == 3: return SelectionAlgorithm.CLOSEST_TO_CENTER

    # ----------------------------------------------------------------------------
    #
    # GET RESULTS AFTER OPTIMIZATION
    #
    # ----------------------------------------------------------------------------

    def get_current_result(self):                    return self.__current_ai_result
    def get_current_initialization_parameters(self): return self.__current_initialization_parameters

    def get_trial(self, trial_index, initialization_parameters=None):
        try:    initialization_parameters = self.__current_initialization_parameters if initialization_parameters is None else initialization_parameters
        except: return

        ai_types    = initialization_parameters.get_parameter("ai_types")
        ai_type     = initialization_parameters.get_parameter("ai_type")

        if   ai_types[int(ai_type)] == Keys.AITypes.Optimization:   return self.__current_ai_agent.get_trial_data(trial_index, check_beam=True)
        elif ai_types[int(ai_type)] == Keys.AITypes.NeuralNetworks: return self.__current_ai_agent.get_alignement_result_data()

    def get_pareto_trial_number(self, pareto_selection, initialization_parameters = None):
        try:
            if initialization_parameters is None: initialization_parameters = self.__current_initialization_parameters
        except:
            return

        ai_types    = initialization_parameters.get_parameter("ai_types")
        ai_type     = initialization_parameters.get_parameter("ai_type")

        if ai_types[int(ai_type)] == Keys.AITypes.Optimization:
            try:
                best_trial_data, _ = self.__current_ai_agent.get_best_trial_data(algorithm=self.get_selection_algorithm(pareto_selection),
                                                                                 **{"check_beam": False, "show_beam": False, "save_image": False})
                return best_trial_data.trial_number
            except:
                return None
        else:
            return None

    def get_optimization_history(self):
        return self.__current_ai_agent.plot_optimization_history(plot_images=False, save_images=False)

    # ----------------------------------------------------------------------------
    #
    # PRE/POST-OPTIMIZATION ACTIONS
    #
    # ----------------------------------------------------------------------------

    def __get_beam_manager_pointers(self, initialization_parameters, transfer=False):
        platforms    = initialization_parameters.get_parameter("platforms")
        platform     = initialization_parameters.get_parameter(("platform" if not transfer else "platform_to"))
        platform_key = platforms[int(platform)]

        beam_manager_types         = initialization_parameters.get_parameter("beam_manager_types")
        beam_manager_type          = initialization_parameters.get_parameter(("beam_manager_type" if not transfer else "beam_manager_type_to"))
        beam_manager_type_key      = beam_manager_types[int(beam_manager_type)]
        beam_manager_configuration = initialization_parameters.get_parameter("beam_manager_configuration")

        beam_manager_type_configuration  = beam_manager_configuration[beam_manager_type_key]
        beam_manager_ids                 = beam_manager_type_configuration["beam_manager_ids"]
        if not transfer: beam_manager_id = beam_manager_type_configuration["beam_manager_id"]
        else:            beam_manager_id = initialization_parameters.get_parameter("beam_manager_id_to")
        beam_manager_id_key              = beam_manager_ids[int(beam_manager_id)]

        return beam_manager_id_key, beam_manager_type_key, platform_key

    # ----------------------------------------------------------------------------

    def __move_motors_to_trial_data_generator(self, trial_data: OptimizationResultItem):
        self._logger.print_message(f"Moving motors to the positions of trial #{trial_data.trial_number}")
        self._logger.print_message("Positions:\n" + str(trial_data.motor_positions))

        yield from self.__current_motion_manager.move_motors(trial_data.motor_positions, Movement.ABSOLUTE)

    def __move_motors_to_trial_data(self, trial_data: OptimizationResultItem):
        self._logger.print_message(f"Moving motors to the positions of trial #{trial_data.trial_number}")
        self._logger.print_message("Positions:\n" + str(trial_data.motor_positions))

        if not self.__current_ai_agent.requires_run_engine():
            self.__current_motion_manager.move_motors(trial_data.motor_positions, Movement.ABSOLUTE)
        else:
            run_engine, _ = self._get_run_engine()
            run_engine(self.__current_motion_manager.move_motors(trial_data.motor_positions, Movement.ABSOLUTE), purpose="AI-alignment")

    # ----------------------------------------------------------------------------

    def __get_motion_manager_and_pointers(self, initialization_parameters: ScriptData) -> tuple[IMotionManager, Any, Any, Any]:
        beam_manager_id_key, beam_manager_type_key, platform_key = self.__get_beam_manager_pointers(initialization_parameters)

        motion_manager_full_id = Keys.compose_manager_key(beamline_id=self._beamline_id,
                                                          platform=platform_key,
                                                          beam_manager_type=beam_manager_type_key,
                                                          beam_manager_id=beam_manager_id_key,
                                                          manager_key=Keys.Managers.MotionManager) \
            if platform_key == Keys.Platforms.DigitalTwin else \
            Keys.compose_manager_key(beamline_id=self._beamline_id,
                                     platform=platform_key,
                                     manager_key=Keys.Managers.MotionManager)

        try:
            motion_manager = create_motion_manager(motion_manager_id=motion_manager_full_id)
        except:
            raise ValueError(f"Motion Manager {motion_manager_full_id} not supported")

        return motion_manager, beam_manager_id_key, beam_manager_type_key, platform_key

    # ----------------------------------------------------------------------------

    def __set_as_initial_points(self, beam_manager_id_key, beam_manager_type_key, platform_key, current_motor_positions, motors_info: MotorsInfoLegacy):
        for motor_id in motors_info.get_motor_ids():
            dictionary = motors_info.get_motor_info(motor_id).to_dictionary()
            dictionary["initial_position"][beam_manager_type_key][platform_key][beam_manager_id_key] = current_motor_positions[motor_id]
            motors_info.add_motor_info(motor_id, MotorInfoLegacy.from_dictionary(dictionary))


    def __set_current_motor_positions_as_initial_points_inner_generator(self, beam_manager_id_key, beam_manager_type_key, platform_key, motion_manager: IMotionManager, motors_info: MotorsInfoLegacy):
        current_motor_positions = yield from motion_manager.get_motor_positions()

        self.__set_as_initial_points(beam_manager_id_key,
                                     beam_manager_type_key,
                                     platform_key,
                                     current_motor_positions,
                                     motors_info)


    def __set_current_motor_positions_as_initial_points_inner(self, beam_manager_id_key, beam_manager_type_key, platform_key, motion_manager: IMotionManager, motors_info: MotorsInfoLegacy):
        current_motor_positions = motion_manager.get_motor_positions()

        self.__set_as_initial_points(beam_manager_id_key,
                                     beam_manager_type_key,
                                     platform_key,
                                     current_motor_positions,
                                     motors_info)

    def __set_current_motor_positions_as_initial_points_generator(self, motors_info: MotorsInfoLegacy, initialization_parameters: ScriptData):
        (motion_manager,
         beam_manager_id_key,
         beam_manager_type_key,
         platform_key) = self.__get_motion_manager_and_pointers(initialization_parameters)

        yield from self.__set_current_motor_positions_as_initial_points_inner_generator(beam_manager_id_key,
                                                                                        beam_manager_type_key,
                                                                                        platform_key,
                                                                                        motion_manager,
                                                                                        motors_info)

    def __set_current_motor_positions_as_initial_points(self, motors_info: MotorsInfoLegacy, initialization_parameters: ScriptData):
        (motion_manager,
         beam_manager_id_key,
         beam_manager_type_key,
         platform_key) = self.__get_motion_manager_and_pointers(initialization_parameters)

        if not motion_manager.method_calling_type() == MethodCallingType.GENERATOR:
            self.__set_current_motor_positions_as_initial_points_inner(beam_manager_id_key,
                                                                       beam_manager_type_key,
                                                                       platform_key,
                                                                       motion_manager,
                                                                       motors_info)
        else:
            run_engine, _ = self._get_run_engine()
            run_engine(self.__set_current_motor_positions_as_initial_points_inner_generator(beam_manager_id_key,
                                                                                            beam_manager_type_key,
                                                                                            platform_key,
                                                                                            motion_manager,
                                                                                            motors_info), purpose="AI-alignment")

    # ----------------------------------------------------------------------------

    def __move_motors_to_initial_points_generator(self, motors_info: MotorsInfoLegacy, initialization_parameters: ScriptData):
        (motion_manager,
         beam_manager_id_key,
         beam_manager_type_key,
         platform_key) = self.__get_motion_manager_and_pointers(initialization_parameters)

        for motor_id in motors_info.get_motor_ids():
            motor_info = motors_info.get_motor_info(motor_id)

            if motor_info.optimized_by_key(beam_manager_type_key, platform_key, beam_manager_id_key):
                initial_position = motor_info.initial_position_by_key(beam_manager_type_key, platform_key, beam_manager_id_key)

                yield from motion_manager.move_motor(motor_id, initial_position, Movement.ABSOLUTE)

    def __move_motors_to_initial_points(self, motors_info: MotorsInfoLegacy, initialization_parameters: ScriptData):
        (motion_manager,
         beam_manager_id_key,
         beam_manager_type_key,
         platform_key) = self.__get_motion_manager_and_pointers(initialization_parameters)

        for motor_id in motors_info.get_motor_ids():
            motor_info = motors_info.get_motor_info(motor_id)

            if motor_info.optimized_by_key(beam_manager_type_key, platform_key, beam_manager_id_key):
                initial_position = motor_info.initial_position_by_key(beam_manager_type_key, platform_key, beam_manager_id_key)

                if not motion_manager.method_calling_type() == MethodCallingType.GENERATOR:
                    motion_manager.move_motor(motor_id, initial_position, Movement.ABSOLUTE)
                else:
                    run_engine, _ = self._get_run_engine()
                    run_engine(motion_manager.move_motor(motor_id, initial_position, Movement.ABSOLUTE), purpose="AI-alignment")

    # ----------------------------------------------------------------------------

    def __transfer_current_position_to_beam_manager_search_space_generator(self, initialization_parameters: ScriptData):
        beam_manager_id_key_to, beam_manager_type_key_to, platform_key_to = self.__get_beam_manager_pointers(initialization_parameters, transfer=True)

        current_motor_positions = yield from self.__current_motion_manager.get_motor_positions()

        self.__transfer_current_position_to_beam_manager_search_space_inner(beam_manager_id_key_to,
                                                                            beam_manager_type_key_to,
                                                                            platform_key_to,
                                                                            current_motor_positions)

    def __transfer_current_position_to_beam_manager_search_space(self, initialization_parameters: ScriptData):
        beam_manager_id_key_to, beam_manager_type_key_to, platform_key_to = self.__get_beam_manager_pointers(initialization_parameters, transfer=True)

        if not self.__current_motion_manager.requires_run_engine():
            current_motor_positions = self.__current_motion_manager.get_motor_positions()
        else:
            def set_current_motor_positions(current_motors_positions):
                motor_positions = yield from self.__current_motion_manager.get_motor_positions()
                for motor_id in motor_positions.keys(): current_motors_positions[motor_id] = motor_positions[motor_id]

            current_motors_positions = {}
            run_engine, _ = self._get_run_engine()
            run_engine(set_current_motor_positions(current_motors_positions), purpose="AI-alignment")

        self.__transfer_current_position_to_beam_manager_search_space_inner(beam_manager_id_key_to,
                                                                            beam_manager_type_key_to,
                                                                            platform_key_to,
                                                                            current_motor_positions)

    def __transfer_current_position_to_beam_manager_search_space_inner(self, beam_manager_id_key_to, beam_manager_type_key_to, platform_key_to, current_motor_positions: dict):
        motion_manager_to_full_id = Keys.compose_manager_key(beamline_id=self._beamline_id,
                                                             platform=platform_key_to,
                                                             beam_manager_type=beam_manager_type_key_to,
                                                             beam_manager_id=beam_manager_id_key_to,
                                                             manager_key=Keys.Managers.MotionManager) \
            if platform_key_to == Keys.Platforms.DigitalTwin else \
            Keys.compose_manager_key(beamline_id=self._beamline_id,
                                     platform=platform_key_to,
                                     manager_key=Keys.Managers.MotionManager)

        try:    motion_manager = create_motion_manager(motion_manager_id=motion_manager_to_full_id)
        except: raise ValueError(f"Motion Manager {motion_manager_to_full_id} not supported")

        motors_info = copy.deepcopy(motion_manager.get_motors_info())

        for motor_id in motors_info.get_motor_ids():
            motor_info = motors_info.get_motor_info(motor_id)

            if motor_info.optimized_by_key(beam_manager_type_key_to, platform_key_to, beam_manager_id_key_to):
                initial_position = current_motor_positions[motor_id]
                current_search_range = motor_info.search_range_by_key(beam_manager_type_key_to, platform_key_to, beam_manager_id_key_to)
                search_transfer_range = motor_info.search_transfer_range_by_key(beam_manager_type_key_to, platform_key_to, beam_manager_id_key_to)

                search_range = motor_info.search_range
                search_range[beam_manager_id_key_to] = [min(current_search_range[0], initial_position + search_transfer_range[0]),
                                                        max(current_search_range[1], initial_position + search_transfer_range[1])]

                new_motor_info = MotorInfoLegacy(type=motor_info.type,
                                                 units=motor_info.units,
                                                 resolution=motor_info.resolution,
                                                 search_range=search_range,
                                                 search_transfer_range=search_transfer_range,
                                                 initial_position=initial_position,
                                                 boundaries=motor_info.boundaries,
                                                 legacy_ids=motor_info.legacy_ids,
                                                 optimized=motor_info.optimized)

                motors_info.add_motor_info(motor_id, new_motor_info)

        motion_manager.to_json(f"beamline_{self._beamline_id}_motion_manager.json")

    # ----------------------------------------------------------------------------
    #
    # IAgentListener
    #
    # ----------------------------------------------------------------------------

    @synchronized_method
    def feedback(self, text_lines):
        if len(text_lines) > 1:
            for text_line in text_lines:
                if "Trial Number" in text_line:
                    self._logger.print_other(message="", prefix="", color=LoggerColor.BLUE)
                    self._logger.print_other(message=text_line, prefix="", color=LoggerColor.GREEN)
                elif "Current Loss" in text_line:
                    self._logger.print_other(message="", prefix="", color=LoggerColor.BLUE)
                    self._logger.print_other(message=text_line, prefix="--> ", color=LoggerColor.MAGENTA)
                else:
                    self._logger.print_other(message=text_line, prefix="", color=LoggerColor.BLUE)
        else:
            self._logger.print_message(text_lines[0])

    # ----------------------------------------------------------------------------
    #
    # Signals
    #
    # ----------------------------------------------------------------------------

    @synchronized_method
    def begin(self):
        self.__current_ai_result = None
        self.__current_initialization_parameters = None

        self._logger.print_message(f"AI Started at {date_now_str(format=f1)} {time_now_str(format=f2)}")

    @synchronized_method
    def error(self, text): self._logger.print_error(text)

    @synchronized_method
    def finish(self, ai_data: list):
        self.__current_ai_result                 = ai_data[0]
        self.__current_initialization_parameters = ai_data[1]

        # Here final operation that rely on matplotlib.
        # QThread and Matplotlib are notoriously unstable and can lead the gui to crash.
        # By moving these operations here, they will be on the Main Thread.

        if not self.__current_ai_result is None:
            ai_types = self.__current_initialization_parameters.get_parameter("ai_types")
            ai_type = self.__current_initialization_parameters.get_parameter("ai_type")
            ai_type_key = ai_types[int(ai_type)]

            if ai_type_key == Keys.AITypes.Optimization:
                optimizer_types = self.__current_initialization_parameters.get_parameter("optimizer_types")
                optimizer_type = self.__current_initialization_parameters.get_parameter("optimizer_type")
                optimizer_type_key = optimizer_types[int(optimizer_type)]

                optimizer_type_configuration = self.__current_initialization_parameters.get_parameter("optimizer_type_configuration")[optimizer_type_key]

                optimizer_names    = optimizer_type_configuration["names"]
                optimizer_name     = optimizer_type_configuration["name"]
                optimizer_name_key = optimizer_names[optimizer_name]

                optimizer_configuration = optimizer_type_configuration["optimizer_configuration"][optimizer_name_key]

                optimizer = self.__current_ai_agent

                if optimizer_type_key == Keys.OptimizerType.MOBO:
                    optimization_result_data, pareto_front_data = self.__current_ai_result

                    selection_algorithm = self.get_selection_algorithm(optimizer_configuration.get("pareto_selection", 0))

                    optimizer.save_optimization_result()
                    optimizer.plot_optimization_history(**{"plot_images": False, "save_images": True})
                    optimizer.plot_optimization_history_correlations(**{"plot_images": False, "save_images": True})

                    if not pareto_front_data is None and not pareto_front_data.is_empty():
                        optimizer.save_pareto_front()
                        optimizer.plot_pareto_front(**{"plot_images": False, "save_images": True})
                        best_trial_data, _ = optimizer.get_best_trial_data(algorithm=selection_algorithm, **{"check_beam": True, "show_beam": False, "save_image": True})
                    else:
                        best_trial_data = None

                    self.__current_ai_result = optimization_result_data, pareto_front_data, best_trial_data
                elif self.__current_initialization_parameters.get_parameter("optimizer_type") in [1, 2]:  # NL / SOBO
                    optimization_result_data = self.__current_ai_result

                    optimizer.save_optimization_result()
                    optimizer.plot_optimization_history(**{"plot_images": False, "save_images": True})
                    optimizer.plot_optimization_history_correlations(**{"plot_images": False, "save_images": True})

                    best_trial_data, _ = optimizer.get_best_trial_data(move_motors=False, **{"check_beam": True, "show_beam": False, "save_image": True})

                    self.__current_ai_result = optimization_result_data, best_trial_data
            elif ai_type == Keys.AITypes.NeuralNetworks:
                result_data            = self.__current_ai_result
                neural_network_manager = self.__current_ai_agent
                neural_network_manager.save_alignment_result()

                self.__current_ai_result =  result_data # redundant but for code symmetry

        self._send_agent_completed()

 # ----------------------------------------------------------------------------
 # ----------------------------------------------------------------------------
 # ----------------------------------------------------------------------------
 # ----------------------------------------------------------------------------

# EXECUTION AS SCRIPT OR BLUESKY PLAN
class ExecutionManager(AbstractExecutionManager):
    def __init__(self, application_name: str, working_directory: str, beamline_id: str, run_as_generator=False, **kwargs):
        super(ExecutionManager, self).__init__(application_name, working_directory, beamline_id, run_as_generator, **kwargs)

    def abort(self): pass

    def _create_ai_process(self):
        return AIAgentProcess(run_as_generator=self._run_as_generator,
                              feedback_method=self.feedback,
                              error_method=self.error,
                              begin_method=self.begin,
                              finish_method=self.finish)

    def _connect_ai_process_handlers(self, ai_process):          pass
    def _send_agent_completed(self):                             pass
    def _connect_agent_completed(self, agent_completed_handler): pass


# QT APPLICATION: BATCH OR GUI
class QtExecutionManager(AbstractExecutionManager, QObject):
    interrupt       = pyqtSignal()
    agent_completed = pyqtSignal()

    def __init__(self, application_name: str, working_directory: str, beamline_id: str, run_as_generator=False, **kwargs):
        QObject.__init__(self)
        AbstractExecutionManager.__init__(self, application_name, working_directory, beamline_id, run_as_generator, **kwargs)

    @synchronized_method
    def abort(self): self.interrupt.emit()

    def _create_ai_process(self) :
        return AIAgentThread(run_as_generator=self._run_as_generator)

    def _connect_ai_process_handlers(self, ai_process):
        ai_process.begin_signal.connect(self.begin)
        ai_process.error_signal.connect(self.error)
        ai_process.feedback_signal.connect(self.feedback)
        ai_process.finish_signal.connect(self.finish)
        ai_process.finished.connect(ai_process.deleteLater)
        self.interrupt.connect(ai_process.interrupt)

    def _send_agent_completed(self):
        self.agent_completed.emit() # here the main thread can manage the results.

    def _connect_agent_completed(self, agent_completed_handler):
        self.agent_completed.connect(agent_completed_handler)

# ------------------------------------------------------------------
# EXECUTION PROCESS
# ------------------------------------------------------------------

class AbstractAIAgentProcess(IAgentListener):
    def __init__(self, run_as_generator=False):
        super(AbstractAIAgentProcess, self).__init__()

        self.__initialization_parameters = None
        self.__ai_agent                  = None
        self.__ai_input                  = None
        self.__ai_result                 = None
        self.__run_as_generator          = run_as_generator

        if run_as_generator: setattr(self, "run_ai_agent",    self.__run_ai_agent_generator)
        else:                setattr(self, "run_ai_agent",    self.__run_ai_agent)

    def initialize(self, ai_agent, ai_input, initialization_parameters):
        self.__initialization_parameters = initialization_parameters
        self.__ai_agent                  = ai_agent
        self.__ai_input                  = ai_input

    @synchronized_method
    def interrupt(self):
        if not self.__ai_agent is None:
            try:   self.__ai_agent.interrupt = True
            except: self._send_feedback(["Interruption Failed"])

    @abc.abstractmethod
    def _send_feedback(self, feedback: List[str]): raise NotImplementedError
    @abc.abstractmethod
    def _send_error(self, error_message): raise NotImplementedError
    @abc.abstractmethod
    def _send_begin(self): raise NotImplementedError
    @abc.abstractmethod
    def _send_finish(self, data: List[Any]): raise NotImplementedError

    def run_ai_agent(self): pass

    def __run_ai_agent_generator(self):
        self.__ai_result = None

        try:
            ai_type_key, fidelity, platform_key = self.__run_ai_agent_init()

            if ai_type_key == Keys.AITypes.Optimization:
                (execution_parameters,
                 input_parameters,
                 optimization_criteria,
                 optimizer,
                 optimizer_type_key) = self.__optimization_init(platform_key)

                if optimizer_type_key == Keys.OptimizerType.MOBO:
                    yield from optimizer.optimize(optimization_criteria=optimization_criteria,
                                           execution_parameters=execution_parameters,
                                           input_parameters=input_parameters, **{})
                    optimization_result_data = self.__finalize_mobo(fidelity, optimizer)
                elif optimizer_type_key == Keys.OptimizerType.SOBO:
                    yield from optimizer.optimize(optimization_criteria=optimization_criteria,
                                                  execution_parameters=execution_parameters,
                                                  input_parameters=input_parameters, **{})
                    optimization_result_data = self.__finalize_soo(fidelity, optimizer)
                elif optimizer_type_key == Keys.OptimizerType.SONL:
                    raise ValueError(f"Optimizer type {optimizer_type_key} not supported whithin a Run Engine")

                self._send_feedback([" ",
                                     "#########################################################",
                                     " ",
                                     f"Optimization completed, total duration: {round(optimization_result_data.get_optimization_duration(), 1)} sec",
                                     " ",
                                     "#########################################################",
                                     " ",
                                     "Post-processing the optimization result, please wait ..."])

                time.sleep(0.1) # this is needed to give the main thread the time to print the last message
            elif ai_type_key == Keys.AITypes.NeuralNetworks:
                arguments, neural_network_manager, target_properties = self.__neural_networks_init()

                yield from neural_network_manager.move_motors_to_target_properties(target_properties=target_properties, **arguments)

                self.__finalize_neural_networks(fidelity, neural_network_manager)
            else:
                self.__ai_result = None
        except Exception:
            self._send_error('Exception occured: {}'.format(traceback.format_exc()))

        self._send_finish([self.__ai_result, self.__initialization_parameters])

    @synchronized_method
    def __run_ai_agent(self):
        self.__ai_result = None

        try:
            ai_type_key, fidelity, platform_key = self.__run_ai_agent_init()

            if ai_type_key == Keys.AITypes.Optimization:
                (execution_parameters,
                 input_parameters,
                 optimization_criteria,
                 optimizer,
                 optimizer_type_key) = self.__optimization_init(platform_key)

                if optimizer_type_key == Keys.OptimizerType.MOBO:
                    if not optimizer.requires_run_engine():
                        optimizer.optimize(optimization_criteria=optimization_criteria,
                                           execution_parameters=execution_parameters,
                                           input_parameters=input_parameters, **{})
                    else:
                        run_engine = self.__initialization_parameters.get_parameter("run_engine")
                        run_engine(optimizer.optimize(optimization_criteria=optimization_criteria,
                                                      execution_parameters=execution_parameters,
                                                      input_parameters=input_parameters, **{}), purpose="AI-alignment")

                    optimization_result_data = self.__finalize_mobo(fidelity, optimizer)
                elif optimizer_type_key == Keys.OptimizerType.SONL:
                    optimizer.optimize(optimization_criteria=optimization_criteria,
                                       execution_parameters=execution_parameters,
                                       input_parameters=input_parameters, **{})

                    optimization_result_data = self.__finalize_soo(fidelity, optimizer)
                elif optimizer_type_key == Keys.OptimizerType.SOBO:
                    if not optimizer.requires_run_engine():
                        optimizer.optimize(optimization_criteria=optimization_criteria,
                                           execution_parameters=execution_parameters,
                                           input_parameters=input_parameters, **{})
                    else:
                        run_engine = self.__initialization_parameters.get_parameter("run_engine")
                        run_engine(optimizer.optimize(optimization_criteria=optimization_criteria,
                                                      execution_parameters=execution_parameters,
                                                      input_parameters=input_parameters,
                                                      **{"compute_result": True,
                                                         "show_beam":      False,
                                                         "save_image":     True}))
                    optimization_result_data = self.__finalize_soo(fidelity, optimizer)

                self._send_feedback([" ",
                                     "#########################################################",
                                     " ",
                                     f"Optimization completed, total duration: {round(optimization_result_data.get_optimization_duration(), 1)} sec",
                                     " ",
                                     "#########################################################",
                                     " ",
                                     "Post-processing the optimization result, please wait ..."])

                time.sleep(0.1) # this is needed to give the main thread the time to print the last message
            elif ai_type_key == Keys.AITypes.NeuralNetworks:
                arguments, neural_network_manager, target_properties = self.__neural_networks_init()

                if not neural_network_manager.requires_run_engine():
                    neural_network_manager.move_motors_to_target_properties(target_properties=target_properties, **arguments)
                else:
                    run_engine = self.__initialization_parameters.get_parameter("run_engine")
                    run_engine(neural_network_manager.move_motors_to_target_properties(target_properties=target_properties, **arguments), purpose="AI-alignment")

                self.__finalize_neural_networks(fidelity, neural_network_manager)
            else:
                self.__ai_result = None
        except Exception:
            self._send_error('Exception occured: {}'.format(traceback.format_exc()))

        self._send_finish([self.__ai_result, self.__initialization_parameters])

    # -----------------------------------------
    # -----------------------------------------
    # -----------------------------------------

    def __finalize_neural_networks(self, fidelity, neural_network_manager):
        alignement_result_data, _ = neural_network_manager.get_alignement_result_data()
        if not alignement_result_data is None: alignement_result_data.fidelity = fidelity

        self.__ai_result = alignement_result_data

        self._send_feedback([" ",
                             "#########################################################",
                             " ",
                             f"NN Alignement completed",
                             " ",
                             "#########################################################",
                             " ",
                             "Post-processing the NN result, please wait ..."])

        time.sleep(0.1)  # this is needed to give the main thread the time to print the last message

    # -----------------------------------------

    def __neural_networks_init(self) -> tuple[Any, Any, dict[str, bool]]:
        neural_network_manager = self.__ai_agent
        target_properties = self.__ai_input

        neural_network_configuration = self.__initialization_parameters.get_parameter("neural_network_configuration")
        neural_network_model_from = neural_network_configuration.get("neural_network_model_from")

        if neural_network_model_from == 0:
            neural_network_manager.get_neural_network().train_neural_network()
        elif neural_network_model_from == 1:  # trained model file
            _, trained_model_file = os.path.split(neural_network_configuration.get("neural_network_trained_model_file"))
            neural_network_manager.get_neural_network().load_trained_model(file_name=trained_model_file)

        arguments = {"compute_result": True, "show_beam": False, "save_image": False}

        return arguments, neural_network_manager, target_properties

    # -----------------------------------------

    def __finalize_soo(self, fidelity, optimizer) -> Any:
        optimization_result_data = optimizer.get_optimization_result_data()
        optimization_result_data.set_fidelity(fidelity)

        self.__ai_result = optimization_result_data

        return optimization_result_data

    # -----------------------------------------

    def __finalize_mobo(self, fidelity, optimizer) -> Any:
        optimization_result_data = optimizer.get_optimization_result_data()
        optimization_result_data.set_fidelity(fidelity)
        pareto_front_data = optimizer.get_pareto_front_data()
        pareto_front_data.set_fidelity(fidelity)

        self.__ai_result = optimization_result_data, pareto_front_data

        return optimization_result_data

    # -----------------------------------------

    def __optimization_init(self, platform_key: int) -> tuple[Any, Any, Any, Any, Any]:
        optimizer_types = self.__initialization_parameters.get_parameter("optimizer_types")
        optimizer_type = self.__initialization_parameters.get_parameter("optimizer_type")
        optimizer_type_key = optimizer_types[int(optimizer_type)]

        optimizer = self.__ai_agent
        optimization_criteria, execution_parameters, input_parameters = self.__ai_input

        input_parameters.set_parameter("move_motor_to_initial_positions", platform_key == Keys.Platforms.DigitalTwin)

        return execution_parameters, input_parameters, optimization_criteria, optimizer, optimizer_type_key

    # -----------------------------------------

    def __run_ai_agent_init(self) -> tuple[Any, Any, int]:
        self._send_begin()

        if self.__ai_agent is None or self.__ai_input is None or self.__initialization_parameters is None: raise ValueError("AI Process not initialized")

        platforms    = self.__initialization_parameters.get_parameter("platforms")
        platform     = self.__initialization_parameters.get_parameter("platform")
        platform_key = platforms[int(platform)]

        ai_types    = self.__initialization_parameters.get_parameter("ai_types")
        ai_type     = self.__initialization_parameters.get_parameter("ai_type")
        ai_type_key = ai_types[int(ai_type)]

        fidelity = Fidelity.HIGH if platform_key == Keys.Platforms.Beamline else Fidelity.LOW

        return ai_type_key, fidelity, platform_key

    # -----------------------------------------
    # -----------------------------------------
    # -----------------------------------------

    @synchronized_method
    def feedback(self, trial_index: int, suggested_motor_positions: list, motors_to_optimize : list, motor_positions, current_loss : list, **kwargs):
        text_list = []

        if not trial_index is None:               text_list.append("Trial Number: " + str(trial_index))
        if not motors_to_optimize is None:        text_list.append("Motors to optimize: " + str(motors_to_optimize))
        if not suggested_motor_positions is None: text_list.append("Suggested Motor Positions: " + str(suggested_motor_positions))
        if not motor_positions is None:           text_list.append("Actual Motor Positions   : " + str(motor_positions))
        if not current_loss is None:              text_list.append("Current Loss: " + str(current_loss))

        message = kwargs.get("message", None)
        if not message is None:
            if isinstance(message, str):    text_list.append(message)
            elif isinstance(message, list): text_list.extend([line for line in message])

        if len(text_list) > 0: self._send_feedback(text_list)

#  EXECUTION AS QT GUI
class AIAgentThread(AbstractAIAgentProcess, QThread):
    begin_signal    = pyqtSignal()
    error_signal    = pyqtSignal(str)
    feedback_signal = pyqtSignal(list)
    finish_signal   = pyqtSignal(list)

    def __init__(self, run_as_generator=False):
        super(AIAgentThread, self).__init__(run_as_generator)

    def _send_feedback(self, feedback: List[str]): self.feedback_signal.emit(feedback)
    def _send_error(self, error_message):          self.error_signal.emit(error_message)
    def _send_begin(self):                         self.begin_signal.emit()
    def _send_finish(self, data: List[Any]):       self.finish_signal.emit(data)

    def run(self): self.run_ai_agent()

# EXECUTION AS SCRIPT OR BLUESKY PLAN
class AIAgentProcess(AbstractAIAgentProcess):
    def __init__(self, run_as_generator=False,
                 feedback_method=None,
                 error_method=None,
                 begin_method=None,
                 finish_method=None):
        super(AIAgentProcess, self).__init__(run_as_generator)

        self.__feedback_method = feedback_method
        self.__error_method    = error_method
        self.__begin_method    = begin_method
        self.__finish_method   = finish_method

    def _send_feedback(self, feedback: List[str]): self.__feedback_method(feedback)
    def _send_error(self, error_message):          self.__error_method(error_message)
    def _send_begin(self):                         self.__begin_method()
    def _send_finish(self, data: List[Any]):       self.__finish_method(data)

