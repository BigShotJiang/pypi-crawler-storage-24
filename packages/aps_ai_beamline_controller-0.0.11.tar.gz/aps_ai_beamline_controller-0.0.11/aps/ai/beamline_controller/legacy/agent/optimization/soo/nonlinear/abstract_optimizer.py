#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
import abc

from aps.beamline_driver.beam_management.facade import IBeamManager, BeamProperties
from aps.beamline_driver.motion_management.facade import IMotionManager
from aps.ai.beamline_controller.legacy.agent.facade import IAgentListener
from aps.ai.beamline_controller.legacy.agent.optimization.abstract_optimizer import AbstractOptimizer
from aps.ai.beamline_controller.legacy.agent.optimization.soo.nonlinear.facade import NonlinearOptimizationResult, NonlinearOptimizationResultItem
from aps.ai.beamline_controller.legacy.agent.optimization.soo.nonlinear.abstract_hypervolume_manager import AbstractNonlinearHypervolumeManager

class AbstractNonlinearOptimizer(AbstractOptimizer):
    def __init__(self,
                 optimization_listener : IAgentListener, **kwargs):
        super(AbstractNonlinearOptimizer, self).__init__(optimization_listener, **kwargs)

    def initialize(self,
                   beam_manager : IBeamManager,
                   motion_manager : IMotionManager,
                   hypervolume_manager: AbstractNonlinearHypervolumeManager = None,
                   **kwargs):
        super(AbstractNonlinearOptimizer, self).initialize(beam_manager, motion_manager, hypervolume_manager, **kwargs)

    def get_optimization_result_data(self, **kwargs) -> NonlinearOptimizationResult:
        return super(AbstractNonlinearOptimizer, self).get_optimization_result_data(**kwargs)

    def get_trial_data(self, trial_index: int, **kwargs) -> (NonlinearOptimizationResultItem, BeamProperties):
        return super(AbstractNonlinearOptimizer, self).get_trial_data(trial_index, **kwargs)

    def get_best_trial_data(self, **kwargs) -> (NonlinearOptimizationResultItem, BeamProperties):
        best_trial_data   = self._optimization_result.get_best_trial()
        if kwargs.get("check_beam", False): beam_properties = self._get_beam_properties(best_trial_data.trial_number,
                                                                                        best_trial_data.beam,
                                                                                        f"{self._get_result_file_prefix()}_best_beam_trial_{best_trial_data.trial_number}.png",
                                                                                        **kwargs)
        else:                               beam_properties = None

        return best_trial_data, beam_properties

    @abc.abstractmethod
    def _get_result_file_prefix(self): raise NotImplementedError