#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #

#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
from aps.ai.beamline_controller.legacy.agent.optimization.facade import OptimizationCriteria
from aps.ai.beamline_controller.legacy.agent.facade import ERROR_LOSS
from aps.ai.beamline_controller.legacy.agent.optimization.moo.bayesian.facade import Sampling, MOBOBayesianOptimizationResult, MOBOOptimizationTrialStatus, MOBOBayesianOptimizationResultItem
from aps.ai.beamline_controller.legacy.agent.optimization.moo.bayesian.abstract_hypervolume_manager import MOBOAbstractBayesianHypervolumeManager, TrialNumbersFilter

from blop.agent import Agent
from pandas import DataFrame

class AbstractBlopToolsHypervolumeManager(MOBOAbstractBayesianHypervolumeManager):
    def __init__(self,
                 hypervolume_reference_points: dict = {},
                 optimization_criteria_constraints: dict = {},
                 optimization_criteria_reference_values: dict = {},
                 optimization_criteria_weights: dict = {}):
        MOBOAbstractBayesianHypervolumeManager.__init__(self,
                                                    hypervolume_reference_points,
                                                    optimization_criteria_constraints,
                                                    optimization_criteria_reference_values,
                                                    optimization_criteria_weights)

    '''
    from IBayesianHypervolumeManager interface
    '''

    def get_error_loss_function(self, optimization_criteria) -> dict:
        return {optimization_criterion: ERROR_LOSS for optimization_criterion in optimization_criteria.names}

    def get_native_pareto_front(self, optimization_agent : Agent, optimization_criteria : OptimizationCriteria) -> DataFrame:
        return optimization_agent.pareto_front

    def extract_pareto_front_data(self,
                                  optimization_agent : Agent,
                                  optimization_criteria: OptimizationCriteria,
                                  trial_numbers: list = None,
                                  trial_numbers_filter: int = TrialNumbersFilter.EXCLUDE,
                                  native_pareto_front: DataFrame = None):
        native_pareto_front = self.get_native_pareto_front(optimization_agent, optimization_criteria) if native_pareto_front is None else native_pareto_front

        return self.__get_optimization_result_from_native(native_pareto_front, optimization_agent, optimization_criteria, trial_numbers, trial_numbers_filter)

    def get_native_optimization_result(self, optimization_agent: Agent) -> DataFrame:
        return optimization_agent.table

    def extract_optimization_result_data(self,
                                         optimization_agent: Agent,
                                         optimization_criteria: OptimizationCriteria,
                                         trial_numbers: list = None,
                                         trial_numbers_filter: int = TrialNumbersFilter.EXCLUDE,
                                         native_optimization_result: DataFrame = None):
        native_optimization_result = self.get_native_optimization_result(optimization_agent) if native_optimization_result is None else native_optimization_result

        return self.__get_optimization_result_from_native(native_optimization_result, optimization_agent, optimization_criteria, trial_numbers, trial_numbers_filter)

    def __get_optimization_result_from_native(self, native_optimization_result: DataFrame, optimization_agent: Agent, optimization_criteria: OptimizationCriteria, trial_numbers: list=None, trial_numbers_filter: int = TrialNumbersFilter.EXCLUDE) -> MOBOBayesianOptimizationResult:
        native_optimization_result = native_optimization_result.to_dict()

        motor_names = optimization_agent.dofs.names
        native_trial_numbers = native_optimization_result["acqf"].keys()

        def get_sampling(trial_number):
            return Sampling.QUASI_RANDOM if "quasi-random" in native_optimization_result["acqf"][trial_number].lower() else Sampling.OPTIMIZED

        if not trial_numbers is None and trial_numbers_filter == TrialNumbersFilter.EXCLUDE:
            trial_numbers = [trial_number for trial_number in native_trial_numbers if trial_number not in trial_numbers]

        optimization_result_data = MOBOBayesianOptimizationResult()
        for trial_number in native_trial_numbers:
            if trial_numbers is None or trial_number in trial_numbers:
                motor_positions = {motor_name: native_optimization_result[motor_name][trial_number] for motor_name in motor_names}
                loss_function = {criterion: native_optimization_result[criterion][trial_number] for criterion in optimization_criteria.names}

                optimization_result_data.add_optimization_item(
                    MOBOBayesianOptimizationResultItem(
                        trial_number=trial_number,
                        status=MOBOOptimizationTrialStatus.COMPLETED,
                        sampling=get_sampling(trial_number),
                        motor_positions=motor_positions,
                        loss_function=loss_function
                    )
                )

        return optimization_result_data

    def get_best_trial_number(self, optimization_agent: Agent, optimization_criteria: OptimizationCriteria, algorithm=None, pareto_front_data: MOBOBayesianOptimizationResult = None) -> int:
        trial_number = int(optimization_agent.best.name)

        return trial_number

    def _get_managed_acquisition_functions(self) -> dict:
        return {"qEI": "qei", "qNEHVI": "qnehvi", "Automatic": "qei"}

    def _initialize_loss_container(self) -> dict:
        return {}

    def _add_to_loss_container(self, optimization_criterion : str, loss_container : dict, current_loss : float):
        loss_container[optimization_criterion] = current_loss

from aps.ai.beamline_controller.legacy.agent.optimization.decorators.direct_beam_image_decorator import DirectBeamImageHyperVolumeManagerDecorator
from aps.ai.beamline_controller.legacy.agent.optimization.decorators.wavefront_analysis_decorator import WavefrontAnalysisHyperVolumeManagerDecorator

class BlopToolsDirectBeamImageHypervolumeManager(DirectBeamImageHyperVolumeManagerDecorator, AbstractBlopToolsHypervolumeManager):
    def __init__(self,
                 hypervolume_reference_points: dict,
                 optimization_criteria_constraints: dict = {},
                 optimization_criteria_reference_values: dict = {},
                 optimization_criteria_weights: dict = {}):
        DirectBeamImageHyperVolumeManagerDecorator.__init__(self)
        AbstractBlopToolsHypervolumeManager.__init__(self,
                                                     hypervolume_reference_points,
                                                     optimization_criteria_constraints,
                                                     optimization_criteria_reference_values,
                                                     optimization_criteria_weights)


class BlopToolsWavefrontAnalysisHypervolumeManager(WavefrontAnalysisHyperVolumeManagerDecorator, AbstractBlopToolsHypervolumeManager):
    def __init__(self,
                 hypervolume_reference_points: dict,
                 optimization_criteria_constraints: dict = {},
                 optimization_criteria_reference_values: dict = {},
                 optimization_criteria_weights: dict = {}):
        WavefrontAnalysisHyperVolumeManagerDecorator.__init__(self)
        AbstractBlopToolsHypervolumeManager.__init__(self,
                                                     hypervolume_reference_points,
                                                     optimization_criteria_constraints,
                                                     optimization_criteria_reference_values,
                                                     optimization_criteria_weights)

