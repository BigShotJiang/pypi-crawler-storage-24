#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
import os
import random
import numpy as np
from datetime import datetime
import pandas as pd

from torch import device, Tensor, save, load, from_numpy, no_grad, min as tmin, max as tmax
from torch.utils.data import TensorDataset, DataLoader
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import MinMaxScaler

from aps.common.io.serialization import from_pickle, to_pickle

from aps.ai.beamline_controller.legacy.agent.facade import IAgentListener
from aps.ai.beamline_controller.legacy.agent.optimization.facade import OptimizationResult
from aps.ai.beamline_controller.legacy.agent.optimization.common.bayesian.facade import BayesianOptimizationResultItem, Sampling
from aps.beamline_driver.beam_management.facade import IBeamManager

from aps.ai.beamline_controller.legacy.agent.machine_learning.neural_networks.facade import INeuralNetwork, NeuralNetworkParameters
from aps.ai.beamline_controller.legacy.agent.machine_learning.neural_networks.neural_network_models import LinearNN, TandemNN, \
    get_available_torch_device, move_data_to_torch_device

class TandemNeuralNetwork(INeuralNetwork):
    def __init__(self,
                 neural_network_parameters: NeuralNetworkParameters,
                 motor_ids_to_optimize: list,
                 beam_properties_names: list,
                 beam_manager: IBeamManager,
                 listener: IAgentListener):
        self.__motor_ids_to_optimize   = motor_ids_to_optimize
        self.__beam_properties_names   = beam_properties_names
        self.__beam_manager            = beam_manager
        self.__listener                = listener

        if not neural_network_parameters.use_cuda: self.__torch_device = device('cpu')
        else:                                      self.__torch_device = get_available_torch_device()

        if not os.path.exists(neural_network_parameters.input_data_directory): raise ValueError(f"NN Input directory {neural_network_parameters.input_data_directory} does not exist")
        if not os.path.exists(neural_network_parameters.output_model_directory): os.mkdir(neural_network_parameters.output_model_directory)

        self.__nnp = neural_network_parameters

        forward_model = LinearNN(input_dim=len(self.__motor_ids_to_optimize),
                                 output_dim=len(self.__beam_properties_names),
                                 neurons_per_layer=self.__nnp.get_parameter("neurons_per_layer_forward",
                                                                            default=[3624, 4096, 4096, 2148, 1838]))
        inverse_model = LinearNN(input_dim=len(self.__beam_properties_names),
                                 output_dim=len(self.__motor_ids_to_optimize),
                                 neurons_per_layer=self.__nnp.get_parameter("neurons_per_layer_inverse",
                                                                            default=[1458, 2117, 3570, 2088, 1930]))

        self.__tandem_model = TandemNN(forward_model=forward_model,
                                       inverse_model=inverse_model)


    def __model_path(self, model_name, file_name=None):
        if file_name is None: return os.path.abspath(os.path.join(self.__nnp.output_model_directory, f'{model_name}_full_model.pth'))
        else:                 return os.path.abspath(os.path.join(self.__nnp.output_model_directory, file_name))

    def __save_trained_NN(self, trained_nn, model_name):
        save(trained_nn, self.__model_path(model_name))

    def __load_train_NN(self, model_name, file_name=None):
        return load(self.__model_path(model_name, file_name))

    def __load_data(self, exclusion_ranges={}):
        input_data_directory       = self.__nnp.input_data_directory
        neural_network_data_type   = self.__nnp.get_parameter("neural_network_data_type", 2)
        number_of_datasets         = self.__nnp.get_parameter("number_of_datasets", -1)
        data_type_for_exclusion    = self.__nnp.get_parameter("data_type_for_exclusion", None)

        optimization_result_files  = [os.path.join(input_data_directory, f) for f in os.listdir(input_data_directory) if f.endswith('.pkl')]

        if number_of_datasets >= len(optimization_result_files): number_of_datasets = -1

        indexes = range(len(optimization_result_files)) if number_of_datasets == -1 else \
            [random.randint(0, len(optimization_result_files)-1) for _ in range(number_of_datasets)]

        loaded_data_dict_list = []
        n_loaded_datasets = 0
        for index in indexes:
            file_path = optimization_result_files[index]
            optimization_result: OptimizationResult = from_pickle(file_path)
            n_loaded_datasets += 1

            for item in optimization_result.get_optimization_items():
                skip = False
                if isinstance(item, BayesianOptimizationResultItem):
                    if   item.sampling == Sampling.OPTIMIZED and neural_network_data_type not in [0, 2]:    skip = True
                    elif item.sampling == Sampling.QUASI_RANDOM and neural_network_data_type not in [1, 2]: skip = True

                if not skip:
                    original_item = item.to_dictionary()

                    try: item_dict = {mp: original_item[mp + "-(MP)"] for mp in self.__motor_ids_to_optimize}
                    except KeyError as e: raise ValueError(f"The optimization result in {file_path} does not contain the requested motor {e}")

                    if not item.beam is None:
                        beam_properties = self.__beam_manager.get_beam_properties(beam=item.beam)

                        skip = False
                        for target_property in self.__beam_properties_names:
                            exclusion_range = exclusion_ranges.get(target_property, None)

                            try: target_property_value = beam_properties.get_parameter(target_property)
                            except: raise ValueError(f"The optimization result in {file_path} can't provide the requested property {target_property}")

                            if not exclusion_range is None and \
                                    (target_property_value < exclusion_range[0] or target_property_value > exclusion_range[1]):

                                if isinstance(item, BayesianOptimizationResultItem): skip = item.sampling == data_type_for_exclusion
                                else:                                                skip = True
                                if skip: break

                            item_dict[target_property] = target_property_value

                        if not skip: loaded_data_dict_list.append(item_dict)

        self.__listener.feedback(None, None, None, None, None, message="===================================================================")
        self.__listener.feedback(None, None, None, None, None, message="               loaded data from Optimization Results")
        self.__listener.feedback(None, None, None, None, None, message="===================================================================")
        self.__listener.feedback(None, None, None, None, None, message=f"Total number of datasets: {n_loaded_datasets}")
        self.__listener.feedback(None, None, None, None, None, message=f"Total number of items   : {len(loaded_data_dict_list)}")
        self.__listener.feedback(None, None, None, None, None, message="===================================================================")

        data_frame = pd.DataFrame(loaded_data_dict_list)

        '''
        Get inputs (beam properties), output (motor positions), normalize data 
        '''
        tensor_beam_properties    = Tensor(data_frame.loc[:, self.__beam_properties_names].values).float()
        tensor_motors_positions = Tensor(data_frame.loc[:, self.__motor_ids_to_optimize].values).float()


        self.__listener.feedback(None, None, None, None, None, message="===================================================================")
        self.__listener.feedback(None, None, None, None, None, message="               Min/Max Values")
        self.__listener.feedback(None, None, None, None, None, message="===================================================================")

        for bp in self.__beam_properties_names:
            t = Tensor(data_frame.loc[:, bp].values).float()
            self.__listener.feedback(None, None, None, None, None, message=f"{bp}: {tmin(t)}, {tmax(t)} ")

        self.__listener.feedback(None, None, None, None, None, message=f"Loading data for Tandem Neural Network")

        self.__scaler_beam_properties = MinMaxScaler()
        self.__scaler_motor_positions = MinMaxScaler()
        beam_properties_normalized = Tensor(self.__scaler_beam_properties.fit_transform(tensor_beam_properties))
        motor_positions_normalized = Tensor(self.__scaler_motor_positions.fit_transform(tensor_motors_positions))

        to_pickle(self.__scaler_beam_properties, os.path.join(self.__nnp.output_model_directory, f'scaler_beam_properties.pkl'))
        to_pickle(self.__scaler_motor_positions, os.path.join(self.__nnp.output_model_directory, f'scaler_motor_positions.pkl'))

        property_train, property_val, motor_train, motor_val = train_test_split(beam_properties_normalized,
                                                                        motor_positions_normalized,
                                                                        test_size=0.01,
                                                                        random_state=42)

        motor_val = move_data_to_torch_device(motor_val, self.__torch_device)
        property_val  = move_data_to_torch_device(property_val,  self.__torch_device)

        self.__data_loader = DataLoader(TensorDataset(motor_val, property_val), batch_size = 1024, shuffle = False)

        self.__listener.feedback(None, None, None, None, None, message=f"Loading data for Tandem Neural Network")
        self.__listener.feedback(None, None, None, None, None, message=f"property_train size: {property_train.shape}; motor_train size:{motor_train.shape}")
        self.__listener.feedback(None, None, None, None, None, message=f"property_val size:   {property_val.shape};   motor_val size:  {motor_val.shape}")
        self.__listener.feedback(None, None, None, None, None, message=f"Current date and time: {datetime.now().strftime('%m-%d-%Y %H:%M')}")

        self.__motor_train = move_data_to_torch_device(data=motor_train, torch_device=self.__torch_device)
        self.__property_train  = move_data_to_torch_device(data=property_train, torch_device=self.__torch_device)

    def __train_forward_model(self):
        result_dict = self.__tandem_model.train_forward_model(X_train=self.__motor_train,
                                                              Y_train=self.__property_train,
                                                              data_loader=self.__data_loader,
                                                              neural_network_parameters=self.__nnp,
                                                              torch_device=self.__torch_device)

        self.__save_trained_NN(self.__tandem_model.forward_model, "forward")

        return result_dict

    def __train_inverse_model(self):
        result_dict = self.__tandem_model.train_inverse_model(X_train=self.__motor_train,
                                                              Y_train=self.__property_train,
                                                              data_loader=self.__data_loader,
                                                              neural_network_parameters=self.__nnp,
                                                              torch_device=self.__torch_device)

        self.__save_trained_NN(self.__tandem_model, "tandem")

        return result_dict

    # -----------------------------------------------------------------
    # INeuralNetwork Interface
    # -----------------------------------------------------------------

    def train_neural_network(self, skip_forward = False, exclusion_ranges: dict = {}, **kwargs):
        self.__load_data(exclusion_ranges)

        if not kwargs.get("load_only", False):
            if skip_forward:
                result_forward = None
                self.__tandem_model.forward_model = self.__load_train_NN("forward")
            else:
                self.__listener.feedback(None, None, None, None, None, message=f"Training Forward Model.....")
                try:
                    result_forward = self.__train_forward_model()
                    final_loss     = result_forward['training_loss'][-1]
                except:
                    result_forward = None
                    final_loss = np.nan
                self.__listener.feedback(None, None, None, None, None, message=f"Completed -> final training loss: {final_loss}")

            self.__listener.feedback(None, None, None, None, None, message=f"Training Inverse Model.....")

            try:
                result_inverse = self.__train_inverse_model()
                final_loss     = result_inverse['training_loss'][-1]
            except:
                result_inverse = None
                final_loss = np.nan
            self.__listener.feedback(None, None, None, None, None, message=f"Completed -> final training loss: {final_loss}")

            return result_forward, result_inverse
        else:
            return None, None

    def load_trained_model(self, file_name = None):
        self.__tandem_model = self.__load_train_NN("tandem", file_name)
        self.__tandem_model.eval()

        self.__scaler_beam_properties:   MinMaxScaler = from_pickle(os.path.join(self.__nnp.output_model_directory, f'scaler_beam_properties.pkl'))
        self.__scaler_motor_positions: MinMaxScaler = from_pickle(os.path.join(self.__nnp.output_model_directory, f'scaler_motor_positions.pkl'))

    def predict_motor_positions(self, target_properties: dict) -> dict:
        if set(list(target_properties.keys())) != set(self.__beam_properties_names): raise ValueError("Requested target properties incompatible with current NN")

        target_properties_values = [target_properties.get(oc) for oc in self.__beam_properties_names]
        target_properties_scaled = self.__scaler_beam_properties.transform(np.reshape(np.array(target_properties_values), (1, len(target_properties_values))))

        with no_grad():
            target_properties_input  = from_numpy(target_properties_scaled[0]).float().to(self.__torch_device)

            motor_positions_scaled = self.__tandem_model.inverse_model(target_properties_input).cpu().numpy().reshape((1, len(self.__motor_ids_to_optimize)))
            motor_positions        = self.__scaler_motor_positions.inverse_transform(motor_positions_scaled)[0]

        return {motor_name : motor_position for motor_name, motor_position in zip(self.__motor_ids_to_optimize, motor_positions)}
