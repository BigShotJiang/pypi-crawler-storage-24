#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #

import torch
import torch.nn as nn
import gpytorch
from gpytorch.likelihoods import GaussianLikelihood
from gpytorch.mlls import ExactMarginalLogLikelihood
from botorch.models import DeepKernelLearningModel


# Define a simple neural network as a feature extractor.
class SimpleFeatureExtractor(nn.Module):
    def __init__(self, input_dim: int, output_dim: int = 4):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, 16),
            nn.ReLU(),
            nn.Linear(16, output_dim),
        )

    def forward(self, x):
        return self.net(x)


# Create synthetic training data.
# In practice, X_train and y_train would be obtained from your experimental measurements or simulation.
X_train = torch.linspace(0, 6, 50).unsqueeze(-1)  # Shape: [50, 1]
y_train = (X_train - 3) ** 2  # Simple quadratic objective with optimum at x = 3.

# Define the feature extractor.
feature_extractor = SimpleFeatureExtractor(input_dim=1, output_dim=4)

# Define the base kernel and likelihood for the GP.
base_kernel = gpytorch.kernels.ScaleKernel(gpytorch.kernels.RBFKernel())
likelihood = GaussianLikelihood()

# Create the Deep Kernel Learning (DKL) model.
dkl_model = DeepKernelLearningModel(
    train_X=X_train,
    train_Y=y_train.squeeze(),  # Model expects targets of shape [n]
    feature_extractor=feature_extractor,
    base_kernel=base_kernel,
    likelihood=likelihood,
)

# Set the model and likelihood into training mode.
dkl_model.train()
likelihood.train()

# Use the Adam optimizer to jointly train the feature extractor and the GP parameters.
optimizer = torch.optim.Adam(dkl_model.parameters(), lr=0.01)

# Define the marginal log likelihood loss.
mll = ExactMarginalLogLikelihood(likelihood, dkl_model)

# Training loop: optimize the model for a number of iterations.
training_iterations = 100
for i in range(training_iterations):
    optimizer.zero_grad()
    # Forward pass: compute predicted outputs by passing inputs through the model.
    output = dkl_model(X_train)
    # Compute negative marginal log likelihood as loss.
    loss = -mll(output, y_train.squeeze())
    loss.backward()
    optimizer.step()

    if i % 10 == 0:
        print(f"Iteration {i}: Loss = {loss.item()}")

# After training, set the model into evaluation mode.
dkl_model.eval()
likelihood.eval()

# Now you can use the trained DKL model (with its feature extractor) in your Ax optimization.
print("Training complete. Trained DKL model is ready for use.")

import torch.nn as nn
from ax.service.ax_client import AxClient
from ax.modelbridge.factory import Models
from ax.modelbridge.generation_strategy import GenerationStep, GenerationStrategy
from botorch.models import DeepKernelLearningModel
from gpytorch.kernels import RBFKernel, ScaleKernel
from gpytorch.likelihoods import GaussianLikelihood

# Define a sample objective function.
def objective_function(parameterization):
    x = parameterization["x"]
    # Here, the true optimum is at x = 3.
    return (x - 3) ** 2

# Create an Ax experiment.
ax_client = AxClient(enforce_sequential_optimization=False)
ax_client.create_experiment(
    name="dkl_experiment",
    parameters=[
        {
            "name": "x",
            "type": "range",
            "bounds": [0.0, 6.0],
        }
    ],
    objective_name="y",
    minimize=True,
)

# Phase 1: Initialize with Sobol sampling.
num_initial_trials = 5
for _ in range(num_initial_trials):
    parameters, trial_index = ax_client.get_next_trial()
    y = objective_function(parameters)
    ax_client.complete_trial(trial_index=trial_index, raw_data=y)

# Phase 2: Update the generation strategy to use a BoTorch model with DKL.
# Here we use the built-in Models.BOTORCH_MODULAR and pass custom_model_class and custom_model_kwargs.
dkl_generation_step = GenerationStep(
    model=Models.BOTORCH_MODULAR,
    num_trials=15,
    # Tell the model to use our Deep Kernel Learning implementation.
    model_kwargs={
        "custom_model_class": DeepKernelLearningModel,
        "custom_model_kwargs": {
            # Our feature extractor will be applied on inputs of dimension 1.
            "feature_extractor": SimpleFeatureExtractor(input_dim=1, output_dim=4),
            # Define the base kernel for the DKL model.
            "base_kernel": ScaleKernel(RBFKernel()),
            # Likelihood is required for model fitting.
            "likelihood": GaussianLikelihood(),
        },
    },
    min_trials_observed=num_initial_trials,
    max_parallelism=1,
    model_gen_kwargs={},
)

# Create a new generation strategy using our DKL generation step.
# (Note: In a real application, you might want to define a full strategy; here we replace the strategy for simplicity.)
gs = GenerationStrategy(steps=[dkl_generation_step])
ax_client._experiment._generation_strategy = gs

# Phase 3: Continue optimization using the DKL-based surrogate.
num_bo_trials = 15
for _ in range(num_bo_trials):
    parameters, trial_index = ax_client.get_next_trial()
    y = objective_function(parameters)
    ax_client.complete_trial(trial_index=trial_index, raw_data=y)

# Retrieve and print the best observed parameters.
best_parameters, values = ax_client.get_best_trial()
print("Best parameters found:", best_parameters)
print("Corresponding objective value:", values)