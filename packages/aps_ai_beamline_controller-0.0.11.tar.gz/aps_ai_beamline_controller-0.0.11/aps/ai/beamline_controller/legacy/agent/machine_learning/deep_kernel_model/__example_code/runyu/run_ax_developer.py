import time
import os
from datetime import datetime
from aps.ai.beamline_controller.legacy.agent.machine_learning.deep_kernel_model.example_code.runyu.ax_developer_classes import Ax_Developer_Optimizer, OptimizationModeDeveloper, TrainingDataInfo, SimpleCustomGP

try:
    from epics import ca

    ca.finalize_libca()
except:
    pass

# torch.set_default_dtype(torch.float32)  # or torch.float64

current_datetime   = datetime.fromtimestamp(int(time.time()))
formatted_datetime = current_datetime.strftime("%H-%M_%d-%m-%Y")

optimization_parameters = {'json_file_name'             : f'Ax_developer_DataSet_20_Sobol_300_BO_{formatted_datetime}',
                           'json_results_directory'     : 'DEFAULT',
                           'sobol_trials'               : 20,
                           'bo_trials'                  : 300,
                           'prior_data_location'        : os.path.abspath('../../../../../../../../../../../../Desktop/runyu 2/Data/Ax_developer_DataSet_20_Sobol_100_BO_10-18_22-05-2025.json'),
                           'optics_controller_ini_dir'  : '../../TEST_DIR/GUI/8-ID/',
                           'optimization_mode'          : OptimizationModeDeveloper.DEFAULT,           # currently unused
                           'training_data_info'         : {'fidelity': TrainingDataInfo.FIDELITY_LOW,
                                                           'size'    : TrainingDataInfo.SIZE_10},
                           'training_data_directory'    : os.path.abspath('../../../../../../../../../../../../Desktop/runyu 2/Data/s4_110k_8ID_March_24.json'),
                           'custom_gp_model'            : SimpleCustomGP,
                           'pre_trained_gp_model'       : None,
                           'custom_acquisition_function': None,
                           'trained_gp_model'           : None,
                           'warm_start'                 : False,
                           'save_results_to_json'       : True}

ax_developer_default_bom_custom_gp = Ax_Developer_Optimizer(input_parameters = optimization_parameters)
# ax_developer_default_bom_custom_gp.optimize_bom(with_SOBOL = False, customize_model = True)
ax_developer_default_bom_custom_gp.optimize_sobol_default()
ax_developer_default_bom_custom_gp.plot_results()
