#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #

import traceback
import os
import warnings

import numpy as np
from time import time

from botorch.acquisition.multi_objective import qNoisyExpectedHypervolumeImprovement

from ax.core.parameter import ChoiceParameter
from ax.service.ax_client import AxClient
from ax.service.utils.instantiation import ObjectiveProperties
from ax.modelbridge.generation_strategy import GenerationStrategy, GenerationStep
from ax.modelbridge.factory import get_sobol
from ax.models.random.sobol import SobolGenerator
from ax.modelbridge.registry import Models

from ax.modelbridge.modelbridge_utils import checked_cast, predicted_hypervolume
from ax.core.optimization_config import MultiObjectiveOptimizationConfig

from aps.beamline_driver.beam_management.facade import IBeamManager
from aps.beamline_driver.motion_management.facade import IMotionManager
from aps.ai.beamline_controller.legacy.agent.facade import IAgentListener
from aps.ai.beamline_controller.legacy.agent.optimization.facade import OptimizationDirection, OptimizationCriteria, OptimizationInitParameters, WarmStartDataType, OptimizationResult
from aps.ai.beamline_controller.legacy.agent.optimization.moo.bayesian.facade import MOBOBayesianOptimizationResult, MOBOBayesianOptimizationExecutionParameters, MOBOBayesianOptimizationInputParameters
from aps.ai.beamline_controller.legacy.agent.optimization.moo.bayesian.abstract_optimizer import MOBOAbstractBayesianOptimizer

from aps.ai.beamline_controller.legacy.agent.machine_learning.deep_kernel_model.deep_kernel_gp import LinearNNFeatureExtractor
from aps.ai.beamline_controller.legacy.agent.machine_learning.surrogates.ax.ax_dkl_surrogate import DeepKernelSurrogate

class AxOptimizer(MOBOAbstractBayesianOptimizer):
    def __init__(self, optimization_listener : IAgentListener, **kwargs):
        super(AxOptimizer, self).__init__(optimization_listener, **kwargs)

    def initialize_driver(self,
                          beam_manager : IBeamManager,
                          motion_manager : IMotionManager):
        super(AxOptimizer, self).initialize_driver(beam_manager, motion_manager)

        if self.requires_run_engine(): setattr(self, "_run_optimization", self.__run_optimization_generator)
        else:                          setattr(self, "_run_optimization", self.__run_optimization)

    # ------------------------------------------------------------------------------
    #  AbstractBayesianOptimizer implementation
    # ------------------------------------------------------------------------------

    def _create_optimization_agent(self, **kwargs):
        warnings.filterwarnings('ignore')

        optimization_criteria: OptimizationCriteria                       = self._optimization_criteria
        execution_parameters: MOBOBayesianOptimizationExecutionParameters = self._execution_parameters
        input_parameters: MOBOBayesianOptimizationInputParameters         = self._input_parameters
        optimization_parameters: OptimizationInitParameters               = self._optimization_parameters

        motors_to_optimize        = input_parameters.motors_to_optimize
        use_discrete_search_space = input_parameters.get_parameter("use_discrete_search_space", default=True)

        # ---------------------------------------------------------------
        # parameters list
        #

        if execution_parameters.do_warm_start:
            if execution_parameters.warm_start_data_type == WarmStartDataType.PRETRAINED_MODEL:
                raise NotImplementedError("Pretrained Model are not supported by this optimizer, yet")
            else:
                if execution_parameters.use_warm_start_search_space: # in case of warm start, the beam_manager_id is embedded in the directory
                    search_ranges = self._warm_start_data.get_warm_start_search_ranges()
                    if use_discrete_search_space:
                        search_spaces = self._warm_start_data.get_warm_start_search_spaces(self._motion_manager)
                        for motor_id in motors_to_optimize:
                            if len(search_spaces[motor_id]) < 2: search_spaces[motor_id] = \
                                self._motion_manager.get_motors_info().get_motor_info(motor_id).search_space_by_key(beam_manager_type=input_parameters.beam_manager_type,
                                                                                                                           platform=input_parameters.platform,
                                                                                                                           beam_manager_id=input_parameters.beam_manager_id)
                else:
                    search_ranges = self._motion_manager.get_motors_info().get_search_ranges(motor_ids=motors_to_optimize,
                                                                                                    beam_manager_type=input_parameters.beam_manager_type,
                                                                                                    platform=input_parameters.platform,
                                                                                                    beam_manager_id=input_parameters.beam_manager_id)
                    if use_discrete_search_space: search_spaces = self._motion_manager.get_motors_info().get_search_spaces(motor_ids=motors_to_optimize,
                                                                                                                                  beam_manager_type=input_parameters.beam_manager_type,
                                                                                                                                  platform=input_parameters.platform,
                                                                                                                                  beam_manager_id=input_parameters.beam_manager_id)
        else:
            search_ranges = self._motion_manager.get_motors_info().get_search_ranges(motor_ids=motors_to_optimize,
                                                                                            beam_manager_type=input_parameters.beam_manager_type,
                                                                                            platform=input_parameters.platform,
                                                                                            beam_manager_id=input_parameters.beam_manager_id)
            if use_discrete_search_space: search_spaces = self._motion_manager.get_motors_info().get_search_spaces(motor_ids=motors_to_optimize,
                                                                                                                          beam_manager_type=input_parameters.beam_manager_type,
                                                                                                                          platform=input_parameters.platform,
                                                                                                                          beam_manager_id=input_parameters.beam_manager_id)

        if use_discrete_search_space:
            parameters_list = []
            for motor_id in motors_to_optimize:
                if len(search_spaces[motor_id]) <= 1000:
                    parameters_list.append(dict(name=motor_id,
                                                type="choice",
                                                values=search_spaces[motor_id],
                                                value_type='float',
                                                is_ordered=True))
                else:
                    parameters_list.append(dict(name=motor_id,
                                                type="range",
                                                bounds=search_ranges[motor_id],
                                                value_type='float'))
        else:
            parameters_list = [dict(name=motor_id,
                                    type="range",
                                    bounds=search_ranges[motor_id],
                                    value_type='float') for motor_id in motors_to_optimize]

        # ---------------------------------------------------------------
        # objectives

        objectives = {}
        hypervolume_reference_points = optimization_parameters.get_parameter("hypervolume_reference_points")
        for optimization_criterion in optimization_criteria.names:
            optimization_direction = optimization_parameters.get_parameter("optimization_directions")[optimization_criterion]

            if execution_parameters.do_warm_start and execution_parameters.use_warm_start_hypervolume_reference_points:
                warm_start_hypervolume_reference_points = self._warm_start_data.get_warm_start_hypervolume_reference_points()
                hypervolume_reference_point  = warm_start_hypervolume_reference_points.get(optimization_criterion,
                                                                                           optimization_parameters.get_parameter("hypervolume_reference_points")[optimization_criterion])
            else:
                hypervolume_reference_point = hypervolume_reference_points[optimization_criterion]

            objectives[optimization_criterion] = ObjectiveProperties(minimize=optimization_direction == OptimizationDirection.MINIMIZE,
                                                                     threshold=hypervolume_reference_point)


        message = ["**************************************************"]
        if execution_parameters.do_warm_start:
            message.append("Warm Start: True (attached " + str(self._warm_start_data.get_number_of_items()) + " trials)")
        else:
            message.append("Warm Start: False")
        message.append("Search Space:")
        message.extend([" - " + motor_id + ":" + str(search_ranges[motor_id]) for motor_id in motors_to_optimize])
        message.append("Hypervolume reference points: ")
        message.extend([" - " + optimization_criterion + ": " + str(objectives[optimization_criterion].threshold) for optimization_criterion in objectives.keys()])
        message.append("**************************************************")
        self._optimization_listener.feedback(None, None, None, None, None, message=message)

        # ---------------------------------------------------------------
        # Creation of the AxClient

        steps                  = []
        acquisition_function   = optimization_parameters.get_parameter("acquisition_function")
        name                   = 'Ax_MOO_experiment'

        if not execution_parameters.do_batch_optimization:
            sobol_step_args          = {}
            bo_step_args             = {}
            generation_strategy_args = {}
        else:
            max_parallelism = min(1, execution_parameters.batch_size)
            sobol_step_args          = {"max_parallelism" : max_parallelism}
            bo_step_args             = {"max_parallelism" : max_parallelism}
            generation_strategy_args = {"use_batch_trials" : True, "max_parallelism_cap": max_parallelism, "max_parallelism_override" : None}

        #surrogate_type = optimization_parameters.get_parameter("surrogate", "DKL")
        surrogate_type = optimization_parameters.get_parameter("surrogate", "Default")

        if surrogate_type == "Default":
            if execution_parameters.do_warm_start:
                name += '_warm_start'
            else:
                sobol_trials = max(input_parameters.sobol_trials, optimization_criteria.number*3)
                self._optimization_listener.feedback(None, None, None, None, None, message=[f"Nr of Sobol Trials: {input_parameters.sobol_trials} -> {sobol_trials} (adjusted)"])
                steps.append(GenerationStep(model=get_sobol, num_trials=sobol_trials, **sobol_step_args))

            steps.append(GenerationStep(model=acquisition_function,
                                        num_trials=input_parameters.bo_trials,
                                        **bo_step_args))
        elif surrogate_type == "DKL":
            name += "_dkl"

            input_data_directory = execution_parameters.ml_data_directory
            number_of_datasets   = input_parameters.get_parameter("number_of_datasets", -1)
            exclusion_ranges     = input_parameters.get_parameter("exclusion_ranges", {})
            excluded_sampling    = input_parameters.get_parameter("excluded_sampling", None)

            surrogate = DeepKernelSurrogate(
                motors_to_optimize=motors_to_optimize,
                optimization_criteria=optimization_criteria.names,
                exclusion_ranges=exclusion_ranges,
                input_data_directory=input_data_directory,
                number_of_datasets=number_of_datasets,
                excluded_sampling=excluded_sampling,
                likelihood_class=None,
                likelihood_options=None,
                feature_extractor_class=LinearNNFeatureExtractor,
                feature_extractor_options= {
                    "input_size": len(motors_to_optimize),
                    "output_size": optimization_criteria.number,
                    "neurons_per_layer": [1000, 500, 50]},
                output_dimension=optimization_criteria.number,
                grid_size=100)

            gp_model_args = {'surrogate': surrogate,
                             'botorch_acqf_class': qNoisyExpectedHypervolumeImprovement}

            steps.append(GenerationStep(model=Models.BOTORCH_MODULAR,
                                        num_trials=input_parameters.bo_trials,
                                        model_kwargs=gp_model_args))

            # TODO: find the right way to train the model with ml data
            # for now I am training the NN of the kernel in the constructor
            '''
                models = []
                for i in range(train_y.shape[-1]):
                    models.append(SingleTaskGP(train_X           = train_x,
                                               train_Y           = train_y[:, i].unsqueeze(-1),
                                               outcome_transform = Standardize(m = 1)))
                model = ModelListGP(*models)
                mll   = SumMarginalLogLikelihood(model.likelihood, model)
                fit_gpytorch_mll(mll)
            '''

        self._optimization_listener.feedback(None, None, None, None, None, message=[f"Nr of MOBO Trials: {input_parameters.bo_trials}"])
        try:                   self._optimization_listener.feedback(None, None, None, None, None, message=[f"****** Acquisition Function: {acquisition_function.__qualname__} ******"])
        except AttributeError: self._optimization_listener.feedback(None, None, None, None, None, message=[f"****** Acquisition Function: {acquisition_function} ******"])


        ax_client = AxClient(generation_strategy=GenerationStrategy(steps=steps, **generation_strategy_args),
                             random_seed=input_parameters.random_seed,
                             verbose_logging=kwargs.get("verbose_logging", False))

        ax_client.create_experiment(name                          = name,
                                    parameters                    = parameters_list,
                                    objectives                    = objectives,
                                    overwrite_existing_experiment = True)

        return ax_client

    # ------------------------------------------------------------------------------

    def __run_optimization(self, **kwargs) -> (int, dict):
        ax_client                 = self._optimization_agent
        execution_parameters      = self._execution_parameters
        input_parameters          = self._input_parameters
        optimization_parameters   = self._optimization_parameters
        optimization_directions   = optimization_parameters.get_parameter("optimization_directions")
        current_timestamps        = {}
        current_raw_data          = {}
        exit_strategy_fulfilled   = False
        current_model_bridge_name = None

        self._hypervolumes          = []
        self.__no_improvement_trials = 0

        new_model_index, trials_to_execute = self.__manage_transfer_learning_initialization(execution_parameters, input_parameters)

        for i in range(trials_to_execute):
            if self.interrupt or exit_strategy_fulfilled: break

            suggested_motor_positions, trial_index, current_model_bridge_name = self.__get_suggested_motor_positions(ax_client=ax_client,
                                                                                                                     current_model_bridge_name=current_model_bridge_name,
                                                                                                                     current_timestamps=current_timestamps)
            loss_function, error_message                                      = self.__evaluate_suggested_motor_positions(suggested_motor_positions=suggested_motor_positions,
                                                                                                                          trial_index=trial_index,
                                                                                                                          current_raw_data=current_raw_data)

            exit_strategy_fulfilled, trials_to_execute                        = self.__process_and_complete_trial(ax_client=ax_client,
                                                                                                                  error_message=error_message,
                                                                                                                  execution_parameters=execution_parameters,
                                                                                                                  exit_strategy_fulfilled=exit_strategy_fulfilled,
                                                                                                                  loss_function=loss_function,
                                                                                                                  optimization_directions=optimization_directions,
                                                                                                                  trial_index=trial_index,
                                                                                                                  trials_to_execute=trials_to_execute)

        if len(self._hypervolumes) > 0:
            try: np.savetxt(os.path.join(execution_parameters.experiment_output_directory,
                                         self._get_pareto_file_prefix() + "_hypervolumes.txt"), np.array(self._hypervolumes))
            except: print("failed to save hypervolumes file")

        if execution_parameters.do_warm_start: return trials_to_execute + new_model_index, current_timestamps, current_raw_data
        else:                                  return trials_to_execute,                   current_timestamps, current_raw_data

    def __run_optimization_generator(self, **kwargs) -> (int, dict):
        ax_client               = self._optimization_agent
        execution_parameters    = self._execution_parameters
        input_parameters        = self._input_parameters
        optimization_parameters = self._optimization_parameters
        optimization_directions = optimization_parameters.get_parameter("optimization_directions")
        current_timestamps      = {}
        current_raw_data        = {}
        exit_strategy_fulfilled   = False
        current_model_bridge_name = None

        self._hypervolumes          = []
        self.__no_improvement_trials = 0

        new_model_index, trials_to_execute = self.__manage_transfer_learning_initialization(execution_parameters, input_parameters)

        for i in range(trials_to_execute):
            if self.interrupt or exit_strategy_fulfilled: break

            suggested_motor_positions, trial_index, current_model_bridge_name = self.__get_suggested_motor_positions(ax_client=ax_client,
                                                                                                                     current_model_bridge_name=current_model_bridge_name,
                                                                                                                     current_timestamps=current_timestamps)
            loss_function, error_message                                      = yield from self.__evaluate_suggested_motor_positions_bluesky(suggested_motor_positions=suggested_motor_positions,
                                                                                                                                             trial_index=trial_index,
                                                                                                                                             current_raw_data=current_raw_data)
            exit_strategy_fulfilled, trials_to_execute                        = self.__process_and_complete_trial(ax_client=ax_client,
                                                                                                                  error_message=error_message,
                                                                                                                  execution_parameters=execution_parameters,
                                                                                                                  exit_strategy_fulfilled=exit_strategy_fulfilled,
                                                                                                                  loss_function=loss_function,
                                                                                                                  optimization_directions=optimization_directions,
                                                                                                                  trial_index=trial_index,
                                                                                                                  trials_to_execute=trials_to_execute)

        if len(self._hypervolumes) > 0:
            try: np.savetxt(os.path.join(execution_parameters.experiment_output_directory,
                                         self._get_pareto_file_prefix() + "_hypervolumes.txt"), np.array(self._hypervolumes))
            except: print("failed to save hypervolumes file")

        if execution_parameters.do_warm_start: return trials_to_execute + new_model_index, current_timestamps, current_raw_data
        else:                                  return trials_to_execute,                   current_timestamps, current_raw_data

    # ------------------------------------------------------------------------------
    #  OBJECTIVE FUNCTION METHODS
    # ------------------------------------------------------------------------------

    def __get_suggested_motor_positions(self, ax_client, current_model_bridge_name, current_timestamps):
        suggested_motor_positions, trial_index = ax_client.get_next_trial()
        current_timestamps[trial_index] = [time(), time()]

        model_bridge = ax_client.generation_strategy.current_step.fitted_model
        model_bridge_name = model_bridge.__class__.__qualname__

        if model_bridge_name != current_model_bridge_name:
            message = []
            message.append(f'**************************************************')
            message.append(f'Now BoTorch model starts at trial {trial_index}')
            message.append(f'BoTorchModel:         {ax_client.generation_strategy.model.model.__class__.__qualname__}')
            message.append(f'BoTorch GP type:      {"None" if isinstance(ax_client.generation_strategy.model.model, SobolGenerator) else ax_client.generation_strategy.model.model.model.__class__.__qualname__}')
            try:    message.append(f'Acquisition function: {"Sobol Random" if isinstance(ax_client.generation_strategy.model.model, SobolGenerator) else ax_client.generation_strategy.current_step.model.__qualname__}')
            except: message.append(f'Acquisition function: {"Sobol Random" if isinstance(ax_client.generation_strategy.model.model, SobolGenerator) else ax_client.generation_strategy.current_step.model}')
            message.append(f'**************************************************')
            self._optimization_listener.feedback(None, None, None, None, None, message=message)

        current_model_bridge_name = model_bridge_name

        return suggested_motor_positions, trial_index, current_model_bridge_name

    def __manage_transfer_learning_initialization(self, execution_parameters, input_parameters):
        if execution_parameters.do_warm_start:
            trials_to_execute = input_parameters.bo_trials
            new_model_index = self._warm_start_data.get_number_of_items() if not execution_parameters.warm_start_data_type == WarmStartDataType.PRETRAINED_MODEL else 0
        else:
            trials_to_execute = input_parameters.bo_trials + input_parameters.sobol_trials
            new_model_index = input_parameters.sobol_trials
        return new_model_index, trials_to_execute

    def __manage_error(self, trial_index, optimization_criteria, motors_to_optimize, suggested_motor_positions, current_motors_positions):
        error_loss = self._hypervolume_manager.get_error_loss_function(optimization_criteria)

        self._optimization_listener.feedback(trial_index=trial_index,
                                             suggested_motor_positions=suggested_motor_positions,
                                             motors_to_optimize=motors_to_optimize,
                                             motor_positions=current_motors_positions,
                                             current_loss=error_loss)
        return error_loss

    def __evaluate_suggested_motor_positions(self, suggested_motor_positions, trial_index, current_raw_data):
        optimization_criteria = self._optimization_criteria
        motors_to_optimize    = self._input_parameters.motors_to_optimize

        current_raw_data[trial_index] = None

        try:
            self._move_motors(suggested_motor_positions)
            current_motors_positions = self._get_current_motors_positions()

            motor_ok, error_message = self._check_motor_positions(suggested_motor_positions, current_motors_positions)

            if not motor_ok: return self.__manage_error(trial_index,
                                                        optimization_criteria,
                                                        motors_to_optimize,
                                                        suggested_motor_positions,
                                                        current_motors_positions), \
                                    error_message
        except Exception as e:
            traceback.print_exc()
            return self.__manage_error(trial_index,
                                       optimization_criteria,
                                       motors_to_optimize,
                                       suggested_motor_positions,
                                       None), \
                   "Unexpected error while setting motors: " + str(e)

        try:
            beam            = self._beam_manager.get_beam()
            beam_properties = self._beam_manager.get_beam_properties(beam)

            current_raw_data[trial_index] = beam

            if beam_properties.get_parameter("is_empty_beam"):
                return  self.__manage_error(trial_index,
                                            optimization_criteria,
                                            motors_to_optimize,
                                            suggested_motor_positions,
                                            current_motors_positions), \
                        "Beam is Empty"

            loss, error, message = self._hypervolume_manager.evaluate_loss_function(beam_properties, optimization_criteria)

            if error > 0:
                return self.__manage_error(trial_index,
                                           optimization_criteria,
                                           motors_to_optimize,
                                           suggested_motor_positions,
                                           current_motors_positions), \
                       message if not message is None else "Error in calculating the loss function"
            else:
                self._optimization_listener.feedback(trial_index,
                                                     suggested_motor_positions,
                                                     motors_to_optimize,
                                                     current_motors_positions,
                                                     current_loss=loss)
                return loss, None
        except Exception as e:
            traceback.print_exc()
            return self.__manage_error(trial_index,
                                       optimization_criteria,
                                       motors_to_optimize,
                                       suggested_motor_positions,
                                       current_motors_positions), \
                   "Unexpected error while analyzing the beam: " + str(e)

    def __evaluate_suggested_motor_positions_bluesky(self, suggested_motor_positions, trial_index, current_raw_data):
        optimization_criteria = self._optimization_criteria
        motors_to_optimize    = self._input_parameters.motors_to_optimize

        current_raw_data[trial_index] = None

        try:
            yield from self._move_motors(suggested_motor_positions)
            current_motors_positions = yield from self._get_current_motors_positions()

            motor_ok, error_message = self._check_motor_positions(suggested_motor_positions, current_motors_positions)

            if not motor_ok: return self.__manage_error(trial_index,
                                                        optimization_criteria,
                                                        motors_to_optimize,
                                                        suggested_motor_positions,
                                                        current_motors_positions), \
                                    error_message
        except Exception as e:
            traceback.print_exc()
            return self.__manage_error(trial_index,
                                       optimization_criteria,
                                       motors_to_optimize,
                                       suggested_motor_positions,
                                       None), \
                   "Unexpected error while setting motors: " + str(e)

        try:
            beam            = yield from self._beam_manager.get_beam()
            beam_properties = self._beam_manager.get_beam_properties(beam)

            current_raw_data[trial_index] = beam

            if beam_properties.get_parameter("is_empty_beam"):
                return  self.__manage_error(trial_index,
                                            optimization_criteria,
                                            motors_to_optimize,
                                            suggested_motor_positions,
                                            current_motors_positions), \
                        "Beam is Empty"

            loss, error, message = self._hypervolume_manager.evaluate_loss_function(beam_properties, optimization_criteria)

            if error > 0:
                return self.__manage_error(trial_index,
                                           optimization_criteria,
                                           motors_to_optimize,
                                           suggested_motor_positions,
                                           current_motors_positions), \
                       error_message
            else:
                self._optimization_listener.feedback(trial_index,
                                                     suggested_motor_positions,
                                                     motors_to_optimize,
                                                     current_motors_positions,
                                                     current_loss=loss)
                return loss, None
        except Exception as e:
            traceback.print_exc()
            return self.__manage_error(trial_index,
                                       optimization_criteria,
                                       motors_to_optimize,
                                       suggested_motor_positions,
                                       current_motors_positions), \
                   "Unexpected error while analyzing the beam: " + str(e)

    def __compute_pareto_hypervolume(self, ax_client: AxClient, trial_index):
        if isinstance(ax_client.generation_strategy.model.model, SobolGenerator):
            self._sobol_last_index = trial_index
            hypervolume = 0.0
        else:
            try:
                if len(ax_client.experiment.lookup_data().df) == 0: hypervolume = 0.0
                else:
                    hypervolume = predicted_hypervolume(modelbridge=ax_client.generation_strategy.model,
                                                        optimization_config=checked_cast(MultiObjectiveOptimizationConfig,
                                                                                         ax_client.experiment.optimization_config))
            except:
                traceback.print_exc()

                hypervolume = np.nan

        return [trial_index, hypervolume]

    def __process_and_complete_trial(self, ax_client, error_message, execution_parameters, exit_strategy_fulfilled, loss_function, optimization_directions, trial_index, trials_to_execute):
        if error_message is None:
            ax_client.complete_trial(trial_index=trial_index, raw_data=loss_function.copy())

            self._hypervolumes.append(self.__compute_pareto_hypervolume(ax_client, trial_index))
            if execution_parameters.do_warm_start and not hasattr(self, "_sobol_last_index"): self._sobol_last_index = trial_index - 1

            message = f"Hypervolume: {self._hypervolumes[-1][1]}"

            if trial_index > self._sobol_last_index + 1:
                if self._hypervolumes[-1][1] == 0.0: self.__no_improvement_trials = 0
                else:
                    variation = (self._hypervolumes[-1][1] - self._hypervolumes[-2][1]) / self._hypervolumes[-1][1]
                    if execution_parameters.use_exit_strategy:
                        if abs(variation) < execution_parameters.convergence_threshold: self.__no_improvement_trials += 1
                        else:                                                           self.__no_improvement_trials = 0
                    message += f", \u0394: {round(100 * variation, 2)}%"

            if execution_parameters.use_exit_strategy:
                exit_strategy_fulfilled = False

                if self.__no_improvement_trials >= execution_parameters.patience: exit_strategy_fulfilled = True
                if exit_strategy_fulfilled: message += f"; EXIT STRATEGY FULLFILLED: no hypervolume improvement for more than {execution_parameters.patience} trials"

                if not exit_strategy_fulfilled:
                    exit_strategy_fulfilled = True

                    for optimization_criterion in execution_parameters.exit_loss_function.keys():
                        if optimization_directions[optimization_criterion] == OptimizationDirection.MINIMIZE:
                            if loss_function[optimization_criterion] > execution_parameters.exit_loss_function[optimization_criterion]:
                                exit_strategy_fulfilled = False
                                break
                        elif optimization_directions[optimization_criterion] == OptimizationDirection.MAXIMIZE:
                            if loss_function[optimization_criterion] < execution_parameters.exit_loss_function[optimization_criterion]:
                                exit_strategy_fulfilled = False
                                break

                    if exit_strategy_fulfilled: message += "; EXIT STRATEGY FULLFILLED: all objectives under exit threshold"

                if exit_strategy_fulfilled: trials_to_execute = trial_index + 1

                if not isinstance(ax_client.generation_strategy.model.model, SobolGenerator):
                    self._optimization_listener.feedback(None, None, None, None, None, message=message)
        else:
            self._optimization_listener.feedback(trial_index, None, None, None, None, message=error_message)
            ax_client.abandon_trial(trial_index=trial_index, reason=error_message)

        return exit_strategy_fulfilled, trials_to_execute

    # ---------------------------------------------------------------------
    # WARM-START
    # ---------------------------------------------------------------------

    @classmethod
    def _get_pareto_file_prefix(cls) -> str: return "ax_mobo_experiment"

    @classmethod
    def _get_ml_file_prefix(cls) -> str: return cls._get_pareto_file_prefix()

    #def _attach_dkl_data(self, **kwards):


    def _attach_warm_start_data(self, **kwargs):
        execution_parameter: MOBOBayesianOptimizationExecutionParameters = self._execution_parameters
        ax_client: AxClient = self._optimization_agent

        if execution_parameter.warm_start_data_type == WarmStartDataType.PRETRAINED_MODEL:
            raise NotImplementedError("Pretrained models are not supported, yet")
        else:
            warm_start_data: MOBOBayesianOptimizationResult = self._warm_start_data
            parameters_list = ax_client.experiment.parameters

            for warm_start_item in warm_start_data.get_optimization_items():
                motor_positions = warm_start_item.motor_positions

                for parameter in parameters_list.values():
                    if isinstance(parameter, ChoiceParameter):
                        motor_id                = parameter.name
                        motor_allowed_positions = np.array(parameter.values)
                        motor_position = motor_allowed_positions[np.argmin(np.absolute(motor_allowed_positions - motor_positions[motor_id]))]
                        motor_positions[motor_id] = motor_position

                ax_client.attach_trial(parameters=motor_positions)
                ax_client.complete_trial(trial_index=warm_start_item.trial_number, raw_data=warm_start_item.loss_function)

            ax_client.fit_model()

            print(f'****** All {warm_start_data.get_number_of_items()} prior trials are completed ******')
            print(f'****************************************************************************************************')

    # -----------------------------------------------------------------------
    # DKL
    # -----------------------------------------------------------------------

    # ------------------------------------------------------------------------------
    #  SAVE TO FILE AND PLOTS
    # ------------------------------------------------------------------------------

    @classmethod
    def _get_result_file_prefix(cls) -> str: return cls._get_pareto_file_prefix()


