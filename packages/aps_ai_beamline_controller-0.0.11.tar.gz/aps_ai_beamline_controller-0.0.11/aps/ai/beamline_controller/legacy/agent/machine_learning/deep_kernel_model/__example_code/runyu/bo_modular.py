import json
import os
from typing import Optional
import time
import configparser
import traceback
import matplotlib.pyplot as plt

import numpy as np
import pandas as pd
import torch
from torch import Tensor

from ax.models.torch.botorch_moo import MultiObjectiveBotorchModel
from ax.models.torch.botorch_modular.model import BoTorchModel
from ax.models.torch.botorch_modular.surrogate import Surrogate
from ax.models.random.sobol import SobolGenerator
from ax.service.ax_client import AxClient
from ax.service.utils.instantiation import ObjectiveProperties
from ax.modelbridge.generation_strategy import GenerationStrategy, GenerationStep
from ax.modelbridge.registry import Models
from ax.modelbridge.factory import get_MOO_NEHVI, get_MOO_PAREGO
from botorch import fit_gpytorch_mll
from botorch.models.gpytorch import GPyTorchModel
from botorch.models.gp_regression import SingleTaskGP
from botorch.models.model_list_gp_regression import ModelListGP
from botorch.models.transforms.outcome import Standardize
from botorch.utils.transforms import normalize
from botorch.acquisition.multi_objective import qNoisyExpectedHypervolumeImprovement

from gpytorch.distributions import MultivariateNormal
from gpytorch.kernels import RBFKernel, ScaleKernel, MaternKernel
from gpytorch.priors import GammaPrior
from gpytorch.means import ConstantMean
from gpytorch.likelihoods import GaussianLikelihood
from gpytorch.models import ExactGP
from gpytorch.mlls.exact_marginal_log_likelihood import ExactMarginalLogLikelihood
from gpytorch.mlls.sum_marginal_log_likelihood import SumMarginalLogLikelihood

from aps.common.reflection import get_class_full_name, instance_for_name, get_class_name_and_module
from aps.common.data_structures import DictionaryWrapper

from aps.beamline_driver.beam_management.beam_manager_factory import initialize_beam_manager_factory, create_beam_manager
from aps.beamline_driver.motion_management.motion_manager_factory import initialize_motion_manager_factory, create_motion_manager
from aps.ai.beamline_controller.legacy.agent.optimization.facade import OptimizationDirection, OptimizationInitParameters, OptimizationCriteria
from aps.ai.beamline_controller.legacy.agent.facade import ERROR_LOSS
from aps.ai.beamline_controller.legacy.agent.optimization.optimizer_factory import initialize_optimizer_factory
from aps.ai.beamline_controller.legacy.agent.optimization.moo.bayesian.facade import BayesianOptimizationExecutionParameters, BayesianOptimizationInputParameters, AcquisitionFunction, SelectionAlgorithm
from aps.ai.beamline_controller.legacy.agent.optimization.moo.bayesian.ax.mobo import AxDirectBeamImageHypervolumeManager, AxWavefrontAnalysisHypervolumeManager
from aps.ai.beamline_controller.legacy.agent.optimization.moo.bayesian.ax.optimizer import AxOptimizer
from aps.ai.beamline_controller.legacy.agent.optimization.moo.bayesian.optuna.hypervolume_manager import OptunaDirectBeamImageHypervolumeManager
from aps.ai.beamline_controller.legacy.agent.optimization.moo.bayesian.optuna import OptunaOptimizer
from aps.ai.beamline_controller.legacy.agent.optimization.soo.nonlinear.scipy import ScipyDirectBeamImageHypervolumeManager, ScipyWavefrontAnalysisHypervolumeManager
from aps.ai.beamline_controller.legacy.agent.optimization.soo.nonlinear.scipy import ScipyOptimizer

from aps.ai.beamline_controller.legacy.agent.optimization.hypervolume_manager_factory import initialize_hypervolume_manager_factory, create_hypervolume_manager

from aps.ai.beamlines.bl_8ID.digital_twin.optimized_optics_manager import S4Beamline8IDOptimizedOpticsManager


try:
    from epics import ca
    ca.finalize_libca()
except:
    pass

class OptimizationMode:
    DEFAULT                               = 'default'
    BOM_DEFAULT_SINGLE_TASK_GP            = 'bom_default_SingleTaskGP'
    BOM_DEFAULT_SINGLE_TASK_GP_NO_SOBOL   = 'bom_default_SingleTaskGP_no_sobol'
    BOM_AX_CLIENT_ATTACH_TRIAL_DEFAULT_GP = 'bom_ax_client_attach_trial_default_gp'
    BOM_AX_CLIENT_ATTACH_TRIAL_CUSTOM_GP  = 'bom_ax_client_attach_trial_custom_gp'
    BOM_DEFAULT                           = 'bom_default'

class TrainingDataInfo:
    FIDELITY_HIGH   = 'high'
    FIDELITY_MEDIUM = 'med'
    FIDELITY_LOW    = 'low'
    RANK_HIGH       = [0, 30000]
    RANK_MEDIUM     = [30000, 60000]
    RANK_LOW        = [60000, 90000]
    SIZE_10         = 10
    SIZE_20         = 20
    SIZE_50         = 50
    SIZE_100        = 100
    SIZE_1K         = 1000
    SIZE_10K        = 10000

class AxNNOptimizer:
    def __init__(self, input_parameters):
        self.config = configparser.ConfigParser()
        self.beam_manager                 = None
        self.motion_manager               = None
        self.hypervolume_manager          = None
        self.digital_twin_init_parameters = None
        self.exit_loss_function           = {}
        self.use_exit_strategy            = len(self.exit_loss_function.keys()) > 0
        self.acquisition_function_id      = 0
        self.sobol_trials                 = input_parameters.get('sobol_trials', 6)
        self.bo_trials                    = input_parameters.get('bo_trials', 5)
        self.optimization_mode            = input_parameters.get('optimization_mode', 'default')
        self.save_results_to_json         = input_parameters.get('save_results_to_json', True)
        self.results_directory            = os.path.join(os.path.abspath(os.getcwd()), input_parameters.get('json_results_directory', 'temp'))
        self.json_file_name               = f"{input_parameters.get('json_file_name', 'temp')}.json"
        self.json_file_dir_name           = None
        self.warm_start                   = input_parameters.get('warm_start', False)
        self.home_directory               = None
        self.id                           = None
        self.training_data_info: dict     = input_parameters.get('training_data_info', None)
        self.training_data_directory      = input_parameters.get('training_data_directory', None)
        self.custom_gp_model              = input_parameters.get('custom_gp_model', None)
        self.pre_trained_gp_model         = input_parameters.get('pre_trained_gp_model', None)
        self.trained_default_gp_model     = None
        self.trained_custom_gp_model      = None
        self.selected_training_data       = []
        self.loaded_json_data             = []
        self.NOISE_SE                     = input_parameters.get('NOISE_SE', Tensor([0.001, 0.001, 0.001]))
        self.prior_data_location          = input_parameters.get('prior_data_location', os.path.abspath('/Users/runyu/Documents/workspace/AI-Driven-Optics-Controller/TEST_DIR/GUI/8-ID/DEFAULT/DEFAULT_DATA_FOR_TRAIN_10_SOBOL_40_MOO_21-07_15-05-2025.json'))
        self.custom_acquisition_function  = input_parameters.get('custom_acquisition_function', None)
        self.acquisition_function         = get_MOO_NEHVI if self.acquisition_function_id == 0 else get_MOO_PAREGO
        self.execution_parameters:    BayesianOptimizationExecutionParameters = None
        self.input_parameters:        BayesianOptimizationInputParameters     = None
        self.optimization_parameters: OptimizationInitParameters              = None
        self._current_timestamps      = {}
        self.selection_algorithm      = SelectionAlgorithm.NASH_EQUILIBRIUM
        self.parameters_list          = {}
        self.motors_bounds_tensor     = []
        self.custom_surrogate         = None
        self.beam_manager_args        = input_parameters.get('beam_manager_args', {'beam_manager_type': 0,
                                                                                   'nbins_h'          : 4001,
                                                                                   'nbins_v'          : 4001,
                                                                                   'xrange'           : [-100.0, 100.0],
                                                                                   'yrange'           : [-100.0, 100.0]})
        self.hypervolume_manager_args = {'hypervolume_reference_points'          : {'peak-distance_spherical'    : 20.0,
                                                                                    'sigma_spherical'            : 30.0,
                                                                                    'negative-log-peak-intensity': -0.1},
                                         'optimization_criteria_reference_values': {'peak-distance_spherical'    : 0.0,
                                                                                    'sigma_spherical'            : 0.0,
                                                                                    'negative-log-peak-intensity': 0.0},
                                         'optimization_criteria_constraints'     : {},
                                         'optimization_criteria_weights'         : {'peak-distance_spherical': 1.0,
                                                                                    'sigma_spherical': 1.0,
                                                                                    'negative-log-peak-intensity': 1.0}}
        self.objectives = {'negative-log-peak-intensity': ['0.0', '-0.1', '1.0', '-2.6'],
                           'peak-distance_spherical'    : ['0.0', '20.0', '1.0', '0.1'],
                           'sigma_spherical'            : ['0.0', '30.0', '1.0', '0.25']}
        self.ax_objectives         = None
        self.ax_client             = None
        self.ax_client_bom         = None
        self.ax_client_bom_train   = None
        self.dummy_ax_client       = None
        self.fixed_seed            = 1234
        self.results_list          = []
        self.results_text          = []
        self.optimization_criteria = OptimizationCriteria(list(self.objectives.keys()))    # create optimization criteria
        self.read_optics_controller_ini()
        self.initialize_factories()
        self.create_managers()
        self.create_search_space_and_objectives()                  # create parameters search space
    def get_trained_default_gp_model(self):
        return self.trained_default_gp_model
    def get_trained_custom_gp_model(self):
        return self.trained_custom_gp_model
    def get_default_gp_model(self):
        return {'surrogate': Surrogate(botorch_model_class = SingleTaskGP,
                                       likelihood_class    = GaussianLikelihood,
                                       likelihood_options  = {'noise_prior'      : GammaPrior(2.0, 0.1)},
                                       covar_module_class  = ScaleKernel,
                                       covar_module_options= {'base_kernel'      : MaternKernel(lengthscale_prior = GammaPrior(2.0, 0.1)),
                                                              'outputscale_prior': GammaPrior(2.0, 0.1)},
                                       model_options       = {}),
                'botorch_acqf_class': qNoisyExpectedHypervolumeImprovement if self.custom_acquisition_function is None else self.custom_acquisition_function}

    def load_new_json_data(self, file_location, return_training_data_dict = True, get_sobol = True):
        if get_sobol is True:
            df_data_raw = (pd.read_json(os.path.abspath(file_location))).head(10)
            print(f'10 SOBOL points are returned')
        else:
            df_data_raw = (pd.read_json(os.path.abspath(file_location))).tail(30)
            print(f'30 BO points are returned')
        df_data_raw['negative-log-peak-intensity'] = df_data_raw['negative-log-peak-intensity'].abs()
        if return_training_data_dict:
            return (df_data_raw[[self.parameters_list[i]['name'] for i in range(len(self.parameters_list))]].to_dict(orient='records'),
                    df_data_raw[list(self.objectives.keys())].to_dict(orient='records'))
        self.loaded_json_data = df_data_raw
        return df_data_raw, df_data_raw

    def train_custom_gp_model(self):
        if self.trained_custom_gp_model is not None:
            print(f'A trained custom GP model already exists. Now exit train_custom_gp_model function.')
            return
        if self.custom_gp_model is None:
            print(f'A custom GP model template is not provided. Now exit train_custom_gp_model function.')
            return
        print(f'Start training custom GP model {self.custom_gp_model} in train_gp function.')
        features_motors, data_beam = self.load_100k_data(return_training_data_dict=True)

    def initialize_training_data(self, df_features_motors, df_data_beam):
        train_x = torch.stack(tensors=[Tensor(df_features_motors[motor_id].to_numpy()) for motor_id in list(self.motors_to_optimize)],dim=1)
        train_y = torch.stack(tensors=[Tensor(df_data_beam[criterion].to_numpy()) for criterion in list(self.objectives.keys())], dim=1)
        print(f'Generated INITIAL training data:\ntrain_x = {train_x.shape}\ntrain_y = {train_y.shape}')
        train_y_noisy = train_y + torch.randn_like(train_y) * self.NOISE_SE
        return train_x.double(), train_y.double(), train_y_noisy.double()

    def train_gp_surrogate(self):
        surrogate = Surrogate(botorch_model_class = SingleTaskGP)
        self.custom_surrogate = surrogate
        df_motors_sobol, df_beam_sobol = self.load_new_json_data(file_location = self.prior_data_location, return_training_data_dict = False,
                                                                 get_sobol     = False)
        train_x_motors, train_y_beam, train_y_beam_noisy = self.initialize_training_data(df_features_motors = df_motors_sobol, df_data_beam = df_beam_sobol)
        train_x = normalize(X=train_x_motors, bounds=self.motors_bounds_tensor)
        train_y = train_y_beam
        print(f'\nINITIALIZED MODEL LITE:\ntrain_x = {train_x.shape}\ntrain_y = {train_y.shape}')
        min_values, _ = torch.min(train_x, dim=0)
        max_values, _ = torch.max(train_x, dim=0)
        print(f"Minimum values for each column of train_x: {min_values}\nMaximum values for each column of train_x: {max_values}")
        min_values, _ = torch.min(train_y, dim=0)
        max_values, _ = torch.max(train_y, dim=0)
        print(f"Minimum values for each column of train_y: {min_values}\nMaximum values for each column of train_y: {max_values}")

        models = []
        for i in range(train_y.shape[-1]):
            models.append(SingleTaskGP(train_X           = train_x,
                                       train_Y           = train_y[:, i].unsqueeze(-1),
                                       outcome_transform = Standardize(m = 1)))
        model = ModelListGP(*models)
        mll   = SumMarginalLogLikelihood(model.likelihood, model)
        fit_gpytorch_mll(mll)

        print(f'Training default SingleTaskGP completed, and saved as self.trained_gp_model')
        self.trained_default_gp_model = model
        return surrogate

    def create_gp_model_kwargs(self):
        return {'surrogate'         : self.train_gp_surrogate(),
                'botorch_acqf_class': qNoisyExpectedHypervolumeImprovement if self.custom_acquisition_function is None else self.custom_acquisition_function}

    def bom_optimize(self):
        if self.optimization_mode is OptimizationMode.BOM_DEFAULT_SINGLE_TASK_GP_NO_SOBOL:
            steps_bom = [GenerationStep(model        = Models.SOBOL, # Add 1 sobol to avoid "ax.exceptions.core.DataRequiredError: `StandardizeY` transform requires non-empty data."
                                        num_trials   = 1),
                         GenerationStep(model        = Models.BOTORCH_MODULAR,
                                        num_trials   = self.bo_trials,
                                        model_kwargs = self.create_gp_model_kwargs())]
            total_trials_to_run = self.bo_trials
        elif self.optimization_mode is OptimizationMode.BOM_DEFAULT_SINGLE_TASK_GP:
            steps_bom = [GenerationStep(model        = Models.SOBOL,
                                        num_trials   = self.sobol_trials),
                         GenerationStep(model        = Models.BOTORCH_MODULAR,
                                        num_trials   = self.bo_trials,
                                        model_kwargs = self.create_gp_model_kwargs())]
            total_trials_to_run = self.sobol_trials + self.bo_trials
        elif self.optimization_mode is OptimizationMode.BOM_DEFAULT:
            steps_bom = [GenerationStep(model        = Models.SOBOL,
                                        num_trials   = self.sobol_trials),
                         GenerationStep(model        = Models.BOTORCH_MODULAR,
                                        num_trials   = self.bo_trials,
                                        model_kwargs = {'surrogate': Surrogate(SingleTaskGP)})]
            total_trials_to_run = self.sobol_trials + self.bo_trials
        else:
            print(f'{self.optimization_mode} is not implemented yet. Now quit bom_optimize')
            return
        ax_client_bom = AxClient(generation_strategy = GenerationStrategy(steps=steps_bom),
                                 random_seed         = self.fixed_seed,
                                 verbose_logging     = True)
        ax_client_bom.create_experiment(name                          = 'Ax_BOM',
                                        parameters                    = self.parameters_list,
                                        objectives                    = self.ax_objectives,
                                        overwrite_existing_experiment = True)
        self.ax_client_bom = ax_client_bom

        current_timestamps = {}
        current_model_bridge_name = None
        current_start_index       = 0
        for i in range(total_trials_to_run):
            timestamp = [time.time(), time.time()]
            suggested_motor_positions, trial_index = ax_client_bom.get_next_trial()
            current_timestamps[trial_index] = timestamp

            model_bridge      = ax_client_bom.generation_strategy.current_step.fitted_model
            model_bridge_name = model_bridge.__class__.__qualname__

            if model_bridge_name != current_model_bridge_name:
                self.show_model_info(trial_index=trial_index, ax_client=ax_client_bom)
            current_model_bridge_name = model_bridge_name

            loss_function, error_message = self.evaluate_suggested_motor_positions(suggested_motor_positions = suggested_motor_positions,
                                                                                   trial_index               = trial_index)
            if error_message is None:
                ax_client_bom.complete_trial(trial_index=trial_index, raw_data=loss_function.copy())
            else:
                print(error_message)
                ax_client_bom.abandon_trial(trial_index=trial_index, reason=error_message)
            timestamp[1] = time.time()
        self.ax_client_bom = ax_client_bom
        for line in self.results_text: print(line)

    def optimize(self):
        print(f'**************************************************')
        print(f'Optimization starts now in {self.optimization_mode} mode')
        print(f'**************************************************')

        if self.optimization_mode == OptimizationMode.DEFAULT:
            self.ax_optimize()
        elif self.optimization_mode == OptimizationMode.BOM_AX_CLIENT_ATTACH_TRIAL_DEFAULT_GP or self.optimization_mode == OptimizationMode.BOM_AX_CLIENT_ATTACH_TRIAL_CUSTOM_GP:
            self.ax_bom_optimize_attach_trial()
        else:
            self.bom_optimize()

        if self.save_results_to_json is True:
            self.json_file_dir_name = os.path.join(self.results_directory, self.json_file_name)
            if not os.path.exists(self.results_directory): os.mkdir(self.results_directory)
            with open(self.json_file_dir_name, 'w') as file: json.dump(self.results_list, file)
            print(f'************************\nOptimization finished.\nResults saved in {self.results_directory}')
        else: print(f'************************\nOptimization finished.\nResults are NOT requested to be saved.')

    def create_bom_BoTorchModel(self):    # TODO: unused now, look at possible direct implementation of BoTorchModel without AxClient
        self.model_bom = BoTorchModel(surrogate=Surrogate(botorch_model_class = self.custom_gp_model,  # BoTorch `Model` type
                                                          mll_class           = ExactMarginalLogLikelihood,  # Optional, MLL class with which to optimize model parameters
                                                          model_options       = {}),
                                      botorch_acqf_class  = qNoisyExpectedHypervolumeImprovement,
                                      acquisition_options = {},
                                      acquisition_class   = None,
                                      refit_on_update     = True, # Less common model settings shown with default values, refer to `BoTorchModel` documentation for detail
                                      refit_on_cv         = False,
                                      warm_start_refit    = True)

    def ax_bom_optimize_attach_trial(self):
        if self.optimization_mode == OptimizationMode.BOM_AX_CLIENT_ATTACH_TRIAL_CUSTOM_GP:
            steps_bom = [GenerationStep(model           = Models.BOTORCH_MODULAR,
                                        num_trials      = self.bo_trials,
                                        model_kwargs    = self.create_gp_model_kwargs())] # model_gen_kwargs={"model_gen_options": {'acquisition_function_kwargs': {'mc_samples': 1}}}

        elif self.optimization_mode == OptimizationMode.BOM_AX_CLIENT_ATTACH_TRIAL_DEFAULT_GP:
            steps_bom = [GenerationStep(model=Models.MOO, num_trials=self.bo_trials)]
        else:
            print(f'{self.optimization_mode} is not currently implemented. Now exit ax_client_train_optimize')
            return
        ax_client_bom_train = AxClient(generation_strategy = GenerationStrategy(steps=steps_bom),
                                       random_seed         = self.fixed_seed,
                                       verbose_logging     = True)
        ax_client_bom_train.create_experiment(name                          = 'Ax_BOM_Ax_client_train',
                                              parameters                    = self.parameters_list,
                                              objectives                    = self.ax_objectives,
                                              overwrite_existing_experiment = True)
        features_motors, data_beam = self.load_100k_data(return_training_data_dict = True)
        for i in range(len(features_motors)):
            self.feedback(trial_index=i, suggested_motor_positions=features_motors[i], motor_positions=features_motors[i], current_loss=data_beam[i], verbose=False)
            _, trial_index = ax_client_bom_train.attach_trial(features_motors[i])
            ax_client_bom_train.complete_trial(trial_index = trial_index, raw_data = data_beam[i])
        ax_client_bom_train.fit_model()

        # best_parameters, metrics = ax_client_bom_train.get_best_parameters()

        current_timestamps = {}
        current_model_bridge_name = None
        current_start_index = 0

        for i in range(self.bo_trials):
            timestamp = [time.time(), time.time()]
            suggested_motor_positions, trial_index = ax_client_bom_train.get_next_trial()
            current_timestamps[trial_index] = timestamp

            model_bridge = ax_client_bom_train.generation_strategy.current_step.fitted_model
            model_bridge_name = model_bridge.__class__.__qualname__

            if model_bridge_name != current_model_bridge_name:
                self.show_model_info(trial_index=trial_index, ax_client=ax_client_bom_train)
            current_model_bridge_name = model_bridge_name

            loss_function, error_message = self.evaluate_suggested_motor_positions(
                suggested_motor_positions=suggested_motor_positions,
                trial_index=trial_index)
            if error_message is None:
                ax_client_bom_train.complete_trial(trial_index=trial_index, raw_data=loss_function.copy())
            else:
                print(error_message)
                ax_client_bom_train.abandon_trial(trial_index=trial_index, reason=error_message)
            timestamp[1] = time.time()

        self.ax_client_bom_train = ax_client_bom_train
        for line in self.results_text: print(line)

    def ax_optimize(self):
        # ---------------------------------------------------------------
        # Creation of the AxClient

        steps = [GenerationStep(model=Models.SOBOL, num_trials=self.sobol_trials)]
        steps.append(GenerationStep(model=Models.MOO, num_trials=self.bo_trials)
                     if self.acquisition_function == AcquisitionFunction.AUTOMATIC
                     else GenerationStep(model=self.acquisition_function, num_trials=self.bo_trials))

        ax_client = AxClient(generation_strategy = GenerationStrategy(steps=steps),
                             random_seed         = self.fixed_seed,
                             verbose_logging     = True)
        ax_client.create_experiment(name                          = 'Ax_MOO_experiment',
                                    parameters                    = self.parameters_list,
                                    objectives                    = self.ax_objectives,
                                    overwrite_existing_experiment = True)
        current_timestamps = {}
        current_model_bridge_name = None

        for i in range(self.sobol_trials + self.bo_trials):
            timestamp = [time.time(), time.time()]
            suggested_motor_positions, trial_index = ax_client.get_next_trial()
            current_timestamps[trial_index] = timestamp

            model_bridge      = ax_client.generation_strategy.current_step.fitted_model
            model_bridge_name = model_bridge.__class__.__qualname__

            if model_bridge_name != current_model_bridge_name:
                self.show_model_info(trial_index=trial_index, ax_client=ax_client)
            current_model_bridge_name = model_bridge_name

            loss_function, error_message = self.evaluate_suggested_motor_positions(suggested_motor_positions=suggested_motor_positions,
                                                                                   trial_index=trial_index)
            if error_message is None:
                ax_client.complete_trial(trial_index=trial_index, raw_data=loss_function.copy())
            else:
                print(error_message)
                ax_client.abandon_trial(trial_index=trial_index, reason=error_message)
            timestamp[1] = time.time()

        self.ax_client = ax_client
        for line in self.results_text: print(line)

    def create_search_space_and_objectives(self):
        parameters_list = []
        for motor_id in self.motors_to_optimize:
            range_values = [float(item) for item in self.motion_manager.get_motors_info().get_motor_info(motor_id).search_range]
            range_values_tensor = Tensor(self.motion_manager.get_motors_info().get_motor_info(motor_id).search_range)
            self.motors_bounds_tensor.append(range_values_tensor)
            parameters_list.append(dict(name       = motor_id,
                                        type       = 'range',
                                        bounds     = range_values,
                                        value_type = 'float'))
        self.parameters_list = parameters_list
        self.motors_bounds_tensor = torch.stack(self.motors_bounds_tensor, dim=0).t()
        objectives = {}
        prior_pareto_front_data = self.input_parameters.get_parameter('warm_start_data')
        for optimization_criterion in self.optimization_criteria.names:
            optimization_direction = self.optimization_parameters.get_parameter("optimization_directions")[optimization_criterion]
            if self.execution_parameters.do_warm_start and self.execution_parameters.use_warm_start_hypervolume_reference_points:
                pareto_front_hypervolume_reference_points = prior_pareto_front_data.get_warm_start_hypervolume_reference_points()
                pareto_front_hypervolume_reference_point  = pareto_front_hypervolume_reference_points.get(optimization_criterion, self.optimization_parameters.get_parameter("hypervolume_reference_points")[optimization_criterion])
                if self.optimization_parameters.get_parameter('is_logarithmic')[optimization_criterion]:
                    hypervolume_reference_point = (1.0-self.execution_parameters.hypervolume_reference_points_coefficient)*pareto_front_hypervolume_reference_point
                else:
                    hypervolume_reference_point = (1.0+self.execution_parameters.hypervolume_reference_points_coefficient)*pareto_front_hypervolume_reference_point
            else:
                hypervolume_reference_point = self.optimization_parameters.get_parameter('hypervolume_reference_points')[optimization_criterion]
            objectives[optimization_criterion] = ObjectiveProperties(minimize=optimization_direction == OptimizationDirection.MINIMIZE, threshold=hypervolume_reference_point)
        self.ax_objectives = objectives

    def load_100k_data(self, return_training_data_dict = True):
        df_8_id_s4_100k_raw = pd.read_json(os.path.abspath(self.training_data_directory))

        # ---------------------------------------------------------------
        # Find any rows with empty beams
        # Get inputs (beam properties), output (motor positions)
        # Calculate the spherical values for peak distance and sigma

        rows_with_nan = df_8_id_s4_100k_raw[df_8_id_s4_100k_raw.isna().any(axis=1)]
        print(f"Total {len(df_8_id_s4_100k_raw)} rows with {len(rows_with_nan)} NaN values")
        df_8_id_s4_100k_raw = df_8_id_s4_100k_raw.dropna()
        print(f"Rows with NaN values dropped. Now Total {len(df_8_id_s4_100k_raw)} rows.")

        beam_properties_list = ['peak-distance-h-(LF)', 'peak-distance-v-(LF)', 'sigma-h-(LF)', 'sigma-v-(LF)', 'negative-log-peak-intensity-(LF)']
        motors_list          = ['kbv_m1_u_bender-(MP)', 'kbv_m2_d_bender-(MP)', 'kbv_m3_pitch-(MP)', 'kbv_m4_translation-(MP)',
                                'kbh_m1_u_bender-(MP)', 'kbh_m2_d_bender-(MP)', 'kbh_m3_pitch-(MP)', 'kbh_m4_translation-(MP)']
        df_beam_properties   = df_8_id_s4_100k_raw.loc[:, beam_properties_list]
        df_motors_positions  = df_8_id_s4_100k_raw.loc[:, motors_list]
        df_beam_properties.reset_index(drop=True, inplace=True)
        df_motors_positions.reset_index(drop=True, inplace=True)

        df_beam_properties['peak-distance_spherical']     = np.sqrt(df_beam_properties['peak-distance-h-(LF)'] ** 2 + df_beam_properties['peak-distance-v-(LF)'] ** 2) * 1e6
        df_beam_properties['sigma_spherical']             = np.sqrt(df_beam_properties['sigma-h-(LF)'] ** 2 + df_beam_properties['sigma-v-(LF)'] ** 2) * 1e6
        df_beam_properties['negative-log-peak-intensity'] = df_beam_properties['negative-log-peak-intensity-(LF)']
        df_beam_properties['weighted_loss_sum_e5']        = (df_beam_properties['negative-log-peak-intensity-(LF)'] +
                                                             df_beam_properties['peak-distance_spherical'] +
                                                             df_beam_properties['sigma_spherical'])
        df_beam_properties_spherical = df_beam_properties.drop(columns = beam_properties_list)
        df_motors_positions.columns  = [col.replace('-(MP)', '') for col in df_motors_positions.columns]
        df_motors_positions          = df_motors_positions.reset_index().rename(columns={'index': 'Index'})
        df_beam_properties_spherical = df_beam_properties_spherical.reset_index().rename(columns={'index': 'Index'})

        # ---------------------------------------------------------------
        # Rank rows in dataframe based on weighted loss sum
        def get_ranked_data_pair(df_motors, df_beam_sorted, range):
            selected_indices = np.random.choice(a    = df_beam_sorted.iloc[range[0]:range[1]].index,
                                                size = self.training_data_info['size'], replace=False)
            return df_beam_sorted.loc[selected_indices], df_motors.loc[selected_indices]

        rank_range = {TrainingDataInfo.FIDELITY_HIGH   : TrainingDataInfo.RANK_HIGH,
                      TrainingDataInfo.FIDELITY_MEDIUM : TrainingDataInfo.RANK_MEDIUM,
                      TrainingDataInfo.FIDELITY_LOW    : TrainingDataInfo.RANK_LOW}.get(self.training_data_info['fidelity'])

        df_beam_properties_spherical_sorted = df_beam_properties_spherical.sort_values(by = 'peak-distance_spherical', ascending=True)
        df_beam_properties_spherical_selected, df_motors_positions_selected = get_ranked_data_pair(df_motors      = df_motors_positions,
                                                                                                   df_beam_sorted = df_beam_properties_spherical_sorted,
                                                                                                   range          = rank_range)
        self.selected_training_data.append(df_motors_positions_selected)
        self.selected_training_data.append(df_beam_properties_spherical_selected)
        print(f"Requested training data is extracted from 100k 8-ID simulation dataset,\nwith range {rank_range} of highest-ranking fidelity.")
        print(f'df_motors_positions_selected:\n{df_motors_positions_selected}')
        print(f'df_beam_properties_spherical_selected:\n{df_beam_properties_spherical_selected}')
        if return_training_data_dict:
            return (df_motors_positions_selected[[self.parameters_list[i]['name'] for i in range(len(self.parameters_list))]].to_dict(orient='records'),
                    df_beam_properties_spherical_selected[list(self.objectives.keys())].to_dict(orient='records'))
        else: return df_motors_positions_selected, df_beam_properties_spherical_selected

    def show_model_info(self, trial_index, ax_client):
        message = []
        message.append(f'**************************************************')
        message.append(f'Now at trial:     {trial_index}')
        message.append(f'Step model name:  {ax_client.generation_strategy.current_step.model_name}')
        if isinstance(ax_client.generation_strategy.model.model, SobolGenerator):
            message.append(f'Acquisition function: {"Sobol Random"}')
        elif (isinstance(ax_client.generation_strategy.model.model, BoTorchModel) and
              ax_client.generation_strategy.current_step.model is Models.BOTORCH_MODULAR):
            message.append(f"Models type:          {'Models.BOTORCH_MODULAR'}")
            message.append(f'BoTorch GP type:      {ax_client.generation_strategy.model.model.surrogate.botorch_model_class.__name__}')
            message.append(f'MLL module:           {ax_client.generation_strategy.model.model.surrogate.mll_class.__name__}')
            message.append(f'Likelihood function:  {ax_client.generation_strategy.model.model.surrogate.model.likelihood.__class__.__qualname__}')
            #message.append(f'Likelihood function:  {ax_client.generation_strategy.model.model.surrogate.model.likelihood.likelihoods[0].__class__.__qualname__}')
            try:
                message.append(f"Acquisition function: {ax_client.generation_strategy.current_step.model_kwargs['botorch_acqf_class'].__name__}")
            except Exception as e:
                print(f"Error {e} while getting: ax_client.generation_strategy.current_step.model_kwargs['botorch_acqf_class'].__name__")
        elif isinstance(ax_client.generation_strategy.model.model, MultiObjectiveBotorchModel):
            message.append(f"Models type:          {'models.torch.botorch_moo.MultiObjectiveBotorchModel'}")
            message.append(f'BoTorch GP type:      {ax_client.generation_strategy.model.model.model.__class__.__qualname__}')
            #message.append(f'MLL module:           {ax_client.generation_strategy.model.model.surrogate.mll_class.__name__}')#####
            message.append(f'Likelihood function:  {ax_client.generation_strategy.model.model.model.likelihood.__class__.__qualname__}')
            message.append(f"Acquisition function: {ax_client.generation_strategy.current_node.fitted_model._model_kwargs['acqf_constructor']['value']}")
        else:
            message.append(f"BoTorch GP type:      {'Uknown, not Sobol, not BoTorchModel nor MultiObjectiveBotorchModel'}")
            message.append(f"Acquisition function: {'NA'}")
        message.append(f'**************************************************')
        for line in message: print(line)

    def read_optics_controller_ini(self):
        os.chdir('/Users/runyu/Documents/workspace/AI-Driven-Optics-Controller/TEST_DIR/GUI/8-ID')
        try: self.config.read('/Users/runyu/Documents/workspace/AI-Driven-Optics-Controller/TEST_DIR/GUI/8-ID/.optics-controller.ini')
        except Exception as e: print(f'Error read the INI file: {e}')

    def feedback(self, trial_index: int, suggested_motor_positions, motor_positions, current_loss, verbose, **kwargs):
        text = []
        total_loss = 0.0
        if not trial_index is None:
            text.append("Trial Number: " + str(trial_index))
            text.append("Suggested Motor Positions: " + str(suggested_motor_positions))
            text.append("Actual Motor Positions   : " + str(motor_positions))
            text.append("Current Loss: " + str(current_loss))
            if trial_index == 0: self.results_text.append('Trial Number   Current Loss   Sum of Losses')
            else:
                total_loss = sum(value for key, value in current_loss.items())
                formatted_result = f'{trial_index}    {current_loss}    {total_loss}'
                self.results_text.append(formatted_result)
        message = kwargs.get("message", None)

        if isinstance(message, str):    text.append(message)
        elif isinstance(message, list): text.extend([line for line in message])

        if verbose is True:
            for line in text: print(line)

        # ---------------------------------------------------------------
        # Record the same information to self.results_dict
        current_result_dict = {'Trial_Number': trial_index,
                               'Loss_Sum': total_loss,
                               **{key: value for key, value in suggested_motor_positions.items()},
                               **{key: value for key, value in current_loss.items()}}
        self.results_list.append(current_result_dict)

    def plot_results(self, read_in_file = False, read_in_file_dir = None, save_images = True, plot_images = True):
        if read_in_file is True and read_in_file_dir is None:
            print(f'Please provide read_in_file_dir')
            return
        elif read_in_file is True and read_in_file_dir is not None:
            data_df = pd.read_json(read_in_file_dir)
        else:
            data_df = pd.read_json(self.json_file_dir_name)
        criteria_rename = {'negative-log-peak-intensity': '-log(PI)',
                           'peak-distance_spherical'    : 'PL_sph (um)',
                           'sigma_spherical'            : 'Sigma_sph (um)',
                           'Loss_Sum'                   : 'Loss_sum'}

        criteria_columns = [col for col in criteria_rename.keys()]
        criteria = data_df[criteria_columns]
        fig = plt.figure(figsize=(8, 6))  # create a combined figure
        for idx, criterion in enumerate(criteria):
            fig.add_subplot(len(criteria_columns), 1, idx + 1)
            fig.gca().scatter(data_df.index, data_df[criterion], marker='o')
            if idx == len(criteria_columns) - 1:
                fig.gca().set_xlabel("Iteration")
            fig.gca().set_ylabel(criteria_rename[criterion])
            if idx == 0:
                fig.gca().set_title("Objective Value vs. Iteration")
            fig.gca().grid(True)
        fig.subplots_adjust(hspace=0.2)
        if save_images:
            plt.tight_layout()
            fig.savefig(os.path.join(self.results_directory, f"{self.json_file_name}_opt_history.png"),
                        bbox_inches='tight', pad_inches=0.01)
        if plot_images: fig.show()

    def initialize_factories(self):
        motion_manager_args = {}
        motion_manager_json_file = os.path.join(os.path.abspath(os.getcwd()), f"optical_system_8-ID_motion_manager.json")
        if os.path.exists(motion_manager_json_file): motion_manager_args["json_file"] = motion_manager_json_file
        beam_manager_json_file = os.path.join(os.path.abspath(os.getcwd()),
                                              f"optical_system_8-ID_beam_manager.json")
        if os.path.exists(beam_manager_json_file): self.beam_manager_args["json_file"] = beam_manager_json_file

        beam_profile_digital_twin_class, beam_profile_digital_twin_module = get_class_name_and_module(
            self.config.get("Initialization", "beam_profile_digital_twin"))
        wavefront_analysis_digital_twin_class, wavefront_analysis_digital_twin_module = get_class_name_and_module(
            self.config.get("Initialization", "wavefront_analysis_digital_twin"))

        self.digital_twin_args = {"motors_configuration_json_file": motion_manager_json_file}
        self.digital_twin_args.update(self.beam_manager_args)
        self.digital_twin_args.update(motion_manager_args)
        self.digital_twin_init_parameters = DictionaryWrapper(**self.digital_twin_args)

        self.beam_profile_digital_twin = instance_for_name(module_name=beam_profile_digital_twin_module,
                                                           class_name=beam_profile_digital_twin_class,
                                                           digital_twin_init_parameters=self.digital_twin_init_parameters)
        self.wavefront_analysis_digital_twin = instance_for_name(module_name=wavefront_analysis_digital_twin_module,
                                                                 class_name=wavefront_analysis_digital_twin_class,
                                                                 digital_twin_init_parameters=self.digital_twin_init_parameters)

        initialize_motion_manager_factory(classes={}, instances={'8-ID' + "-DT-BP": self.beam_profile_digital_twin,
                                                                 '8-ID' + "-DT-WA": self.wavefront_analysis_digital_twin})
        initialize_beam_manager_factory(classes={}, instances={'8-ID' + "-DT-BP": self.beam_profile_digital_twin,
                                                               '8-ID' + "-DT-WA": self.wavefront_analysis_digital_twin})
        initialize_hypervolume_manager_factory(classes={"Ax-BP": get_class_full_name(AxDirectBeamImageHypervolumeManager),
                                                        "Optuna-BP": get_class_full_name(OptunaDirectBeamImageHypervolumeManager),
                                                        "Scipy-BP": get_class_full_name(ScipyDirectBeamImageHypervolumeManager),
                                                        "Ax-WA": get_class_full_name(AxWavefrontAnalysisHypervolumeManager),
                                                        "Scipy-WA": get_class_full_name(ScipyWavefrontAnalysisHypervolumeManager)})
        initialize_optimizer_factory(classes={"Ax": get_class_full_name(AxOptimizer),
                                              "Optuna": get_class_full_name(OptunaOptimizer),
                                              "Scipy": get_class_full_name(ScipyOptimizer)})
        self.digital_twin = S4Beamline8IDOptimizedOpticsManager(digital_twin_init_parameters=self.digital_twin_init_parameters)

    def create_managers(self):
        beamline_id = '8-ID'
        platform = "BL" if self.digital_twin_init_parameters.get_parameter("platform") == 0 else "DT"
        beam_manager_type = "BP" if self.digital_twin_init_parameters.get_parameter("beam_manager_type") == 0 else "WA"
        self.home_directory = os.path.join(os.path.abspath(os.getcwd()), f"Ax-{platform}-{beam_manager_type}-cr{len(self.objectives.keys())}" + ("-ws" if self.warm_start else ""))
        self.id = beamline_id + "-" + platform + "-" + beam_manager_type
        self.motion_manager        = create_motion_manager(motion_manager_id=self.id)
        self.beam_manager          = create_beam_manager(beam_manager_id=self.id)
        self.hypervolume_manager   = create_hypervolume_manager(hypervolume_manager_id='Ax-BP', **self.hypervolume_manager_args)
        # self.optimization_listener = create_optimization_listener(listener_id='Ax')
        self.execution_parameters  = BayesianOptimizationExecutionParameters(do_warm_start=False,
                                                                             home_directory=self.home_directory,
                                                                             use_exit_strategy=self.use_exit_strategy,
                                                                             exit_loss_function=self.exit_loss_function)
        self.input_parameters = BayesianOptimizationInputParameters(acquisition_function=AcquisitionFunction.QUASIMCBASED_NOISY_EXPECTED_HYPERVOLUME_IMPROVEMENT,
                                                                    sobol_trials=self.sobol_trials,
                                                                    bo_trials=self.bo_trials,
                                                                    motors_to_optimize=None,
                                                                    random_seed=int(time.time()))
        self.optimization_parameters = self.hypervolume_manager.get_optimization_parameters(self.optimization_criteria, self.input_parameters)
        if not self.input_parameters.is_partial_optimization: self.input_parameters.motors_to_optimize = self.motion_manager.get_motors_info().get_motor_ids()
        self.motors_to_optimize = self.input_parameters.motors_to_optimize

    def check_motor_positions(self, suggested_motor_positions, current_motors_positions):
        motors_info = self.motion_manager.get_motors_info()
        for motor_id in suggested_motor_positions:
            if abs(suggested_motor_positions[motor_id] - current_motors_positions[motor_id]) > 10 * motors_info.get_motor_info(motor_id).resolution:
                return False, f"Motor {motor_id} is not correctly positioned (offset > 10*resolution)"
        return True, None

    def evaluate_suggested_motor_positions(self, suggested_motor_positions, trial_index):
        # motors_to_optimize = input_parameters.motors_to_optimize
        motors_to_optimize = [key for key in suggested_motor_positions.keys()]
        def manage_error(current_motors_positions, error_message):
            error_loss = self.hypervolume_manager.get_error_loss_function(self.optimization_criteria)
            self.feedback(trial_index=trial_index,
                          suggested_motor_positions=suggested_motor_positions,
                          motor_positions=motors_to_optimize,
                          current_loss=error_loss,
                          verbose=True)
            return error_loss, error_message
        try:
            self.motion_manager.move_motors(motor_positions=suggested_motor_positions)
            current_motors_positions = self.motion_manager.get_motor_positions(motor_ids=motors_to_optimize)
            motor_ok, error_message = self.check_motor_positions(suggested_motor_positions=suggested_motor_positions,
                                                                 current_motors_positions=current_motors_positions)
            if not motor_ok: return manage_error(current_motors_positions, error_message)
        except Exception as e:
            traceback.print_exc()
            return manage_error(None, "Unexpected error while setting motors: " + str(e))
        try:
            beam_properties = self.beam_manager.get_beam_properties(self.beam_manager.get_beam())
            if beam_properties.get_parameter('is_empty_beam'):
                return manage_error(current_motors_positions, 'Beam is empty')
            loss, error, message = self.hypervolume_manager.evaluate_loss_function(beam_properties, self.optimization_criteria)
            if error > 0:
                return manage_error(current_motors_positions, message)
            else:
                self.feedback(trial_index, suggested_motor_positions, current_motors_positions, loss, verbose=True)
                return loss, None
        except Exception as e:
            traceback.print_exc()
            return manage_error(current_motors_positions, 'Unexpected error while analyzing the beam' + str(e))

    def evaluate_loss_function(self, beam_properties):
        loss_function = {}
        error = 0
        message = ''
        for optimization_criterion in self.optimization_criteria.names:
            try:
                current_loss = self.hypervolume_manager.evaluate_loss_function(beam_properties=beam_properties,
                                                                               optimization_criteria=self.optimization_criteria)
            except Exception as e:
                current_loss = ERROR_LOSS
                message += ("" if error == 0 else "\n") + str(traceback.format_exc())
                error = 1
            if current_loss == np.nan:
                current_loss = ERROR_LOSS
                message += ("" if error == 0 else "\n") + str(traceback.format_exc())
                error = 1
            loss_function[optimization_criterion] = current_loss
        return loss_function, error, message
class SimpleCustomGP(ExactGP, GPyTorchModel):
    _num_outputs = 1  # to inform GPyTorchModel API
    def __init__(self, train_X, train_Y, train_Yvar: Optional[Tensor] = None):
        # NOTE: This ignores train_Yvar and uses inferred noise instead.
        # squeeze output dim before passing train_Y to ExactGP
        super().__init__(train_X, train_Y.squeeze(-1), GaussianLikelihood())
        self.mean_module  = ConstantMean()
        self.covar_module = ScaleKernel(base_kernel=RBFKernel(ard_num_dims=train_X.shape[-1]))
        self.to(train_X)  # make sure we're on the right device/dtype
    def forward(self, x):
        mean_x = self.mean_module(x)
        covar_x = self.covar_module(x)
        return MultivariateNormal(mean_x, covar_x)