import torch
from typing import Any, Dict, List, Optional, Type
from torch import Tensor

from ax.core.search_space import SearchSpaceDigest
from ax.core.types import TCandidateMetadata

from ax.models.torch.botorch_modular.model import BoTorchModel, Surrogate

from botorch.models.model import Model
from botorch.models.gpytorch import GPyTorchModel
from botorch.models.transforms.input import InputPerturbation, InputTransform
from botorch.models.transforms.outcome import OutcomeTransform
from botorch.utils.datasets import FixedNoiseDataset, RankingDataset, SupervisedDataset
from botorch.utils.containers import BotorchContainer, DenseContainer, SliceContainer

from gpytorch.kernels import Kernel
from gpytorch.likelihoods import Likelihood
from gpytorch.mlls import MarginalLogLikelihood
from gpytorch.models import ExactGP
from gpytorch.mlls.exact_marginal_log_likelihood import ExactMarginalLogLikelihood

'''
# MODIFIED the following classes
from linear_operator.operators.sum_linear_operator import LinearOperator, SumLinearOperator
/home/oxygen/B310691/miniconda3/envs/ax/lib/python3.9/site-packages/linear_operator/operators/dense_linear_operator.py
    def _cholesky_solve(
        self: Float[LinearOperator, "*batch N N"],
        rhs: Union[Float[LinearOperator, "*batch2 N M"], Float[Tensor, "*batch2 N M"]],
        upper: Optional[bool] = False,
    ) -> Union[Float[LinearOperator, "... N M"], Float[Tensor, "... N M"]]:
        return torch.cholesky_solve(rhs, self.to_dense().float(), upper=upper)
'''


GPU_DEVICE = None
if torch.cuda.is_available():
    for i in range(torch.cuda.device_count()):
        print(f"Device {i}: {torch.cuda.get_device_name(i)}")
        print(f"  Memory Allocated: {torch.cuda.memory_allocated(i) / 1e9} GB")
        print(f"  Memory Cached:    {torch.cuda.memory_reserved(i) / 1e9} GB")
    GPU_DEVICE = torch.device('cuda')
else:
    print(f"NO GPU Device detected")

class DenseContainerExtended(DenseContainer):
    def to(self, device: torch.device):
        self.values = self.values.to(device)
        print(f'values {self.values} moved to {device}')
        return self

class SurrogateExtended(Surrogate):
    def __init__(
        self,
        botorch_model_class: Optional[Type[Model]] = None,
        model_options: Optional[Dict[str, Any]] = None,
        mll_class: Type[MarginalLogLikelihood] = ExactMarginalLogLikelihood,
        mll_options: Optional[Dict[str, Any]] = None,
        outcome_transform: Optional[OutcomeTransform] = None,
        input_transform: Optional[InputTransform] = None,
        covar_module_class: Optional[Type[Kernel]] = None,
        covar_module_options: Optional[Dict[str, Any]] = None,
        likelihood_class: Optional[Type[Likelihood]] = None,
        likelihood_options: Optional[Dict[str, Any]] = None,
        allow_batched_models: bool = True,
    ) -> None:
        super().__init__(
            botorch_model_class=botorch_model_class,
            model_options=model_options,
            mll_class=mll_class,
            mll_options=mll_options,
            outcome_transform=outcome_transform,
            input_transform=input_transform,
            covar_module_class=covar_module_class,
            covar_module_options=covar_module_options,
            likelihood_class=likelihood_class,
            likelihood_options=likelihood_options,
            allow_batched_models=allow_batched_models,
        )
        self._device = GPU_DEVICE
    def fit(
        self,
        datasets: List[SupervisedDataset],
        metric_names: List[str],
        search_space_digest: SearchSpaceDigest,
        candidate_metadata: Optional[List[List[TCandidateMetadata]]] = None,
        state_dict: Optional[Dict[str, Tensor]] = None,
        refit: bool = True,
        original_metric_names: Optional[List[str]] = None,
        **kwargs: Any,
    ) -> None:
        for dataset in datasets:
            dataset.X.values = dataset.X.values.to(self._device).float()
            dataset.Y.values = dataset.Y.values.to(self._device).float()
            if isinstance(dataset, FixedNoiseDataset):
                dataset.Yvar.values = dataset.Yvar.values.to(self._device).float()
            # print(f'In SurrogateExtended.fit\n\ndataset.X = {dataset.X.shape} and dataset.Y = {dataset.Y.shape} are moved to {self._device}')
        super().fit(datasets=datasets,
                    metric_names=metric_names,
                    search_space_digest=search_space_digest,
                    candidate_metadata=candidate_metadata,
                    state_dict=state_dict,
                    refit=refit,
                    original_metric_names=original_metric_names,
                    **kwargs)
        self._model.to(self._device)

    def to(self, device: torch.device):
        self._device = device
        if self._model is not None:
            self._model.to(device)
        return self

    @property
    def device(self) -> torch.device:
        return self._device
