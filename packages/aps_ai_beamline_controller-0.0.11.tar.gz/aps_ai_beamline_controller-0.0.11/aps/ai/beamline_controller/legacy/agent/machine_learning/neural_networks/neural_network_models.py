#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
from torch import device, Tensor, cuda, no_grad
from torch.nn import Module, ReLU, Linear, L1Loss, ModuleList
import torch.optim as optim
from torch.utils.data import DataLoader
from torch.amp import autocast, GradScaler

from aps.ai.beamline_controller.legacy.agent.machine_learning.neural_networks.facade import NeuralNetworkParameters

class LinearNN(Module):
    def __init__(self, input_dim=8, output_dim=5, neurons_per_layer=[100, 100, 100]):
        super(LinearNN, self).__init__()
        layers = []
        for i in range(len(neurons_per_layer)):
            if i == 0: layers.append(Linear(input_dim, neurons_per_layer[0]))
            else     : layers.append(Linear(neurons_per_layer[i - 1], neurons_per_layer[i]))
            layers.append(ReLU())
        layers.append(Linear(neurons_per_layer[-1], output_dim))
        self.layers = ModuleList(layers)

    def forward(self, x):
        for layer in self.layers: x = layer(x)
        return x

    def train_model(self, X_train : Tensor, Y_train: Tensor, data_loader: DataLoader, neural_network_parameters: NeuralNetworkParameters, torch_device: device):
        lr, \
        weight_decay, \
        loss_function, \
        total_epochs, \
        patience, \
        train_batch_size, \
        train_data_size = get_training_parameters(neural_network_parameters, y_train_size=Y_train.size(0), torch_device=torch_device)

        optimizer = optim.Adam(self.parameters(), lr=lr,  weight_decay=weight_decay)

        print(f"LR={lr}, batch_size={train_batch_size}, train_data_size={train_data_size}")

        scaler            = GradScaler('cuda')
        best_val_loss     = float('inf')
        epochs_no_improve = 0
        results_dict      = {'training_loss': [], 'validation_loss': []}

        for epoch in range(total_epochs):
            self.train()
            epoch_loss = 0.0
            for i in range(train_data_size // train_batch_size):
                # Extract batch
                start = i * train_batch_size
                end = start + train_batch_size
                X_batch = X_train[start:end]
                Y_batch = Y_train[start:end]

                optimizer.zero_grad()
                # Use autocast for the forward pass
                with autocast('cuda'):
                    Y_pred = self(X_batch)
                    loss = loss_function(Y_pred, Y_batch)

                epoch_loss += loss.item()
                scaler.scale(loss).backward()
                scaler.step(optimizer)
                scaler.update()

                del X_batch, Y_batch, Y_pred, loss

            # scheduler.step()
            avg_epoch_loss = epoch_loss / (train_data_size // train_batch_size)
            results_dict['training_loss'].append(avg_epoch_loss)

            # Evaluate on validation set
            self.eval()
            total_loss = 0.0
            with no_grad():
                for motors, beam in data_loader:
                    X_batch = motors
                    Y_batch = beam
                    Y_pred = self(X_batch)
                    loss = loss_function(Y_pred, Y_batch)
                    total_loss += loss.item()
            val_loss = total_loss / len(data_loader)

            results_dict['validation_loss'].append(val_loss)

            print(f"Epoch {epoch + 1}: Training Loss: {avg_epoch_loss}, Validation Loss: {val_loss}")

            # Check for validation loss improvement
            if val_loss < best_val_loss:
                best_val_loss = val_loss
                epochs_no_improve = 0
            else:
                epochs_no_improve += 1

            # Check for early stopping
            if epochs_no_improve == patience:
                print(f"No improvement in validation loss for {patience} epochs. Stopping training.")
                break

        return results_dict

    @property
    def input_dim(self):
        try:    return self.layers[0].in_features
        except: return 0

    @property
    def output_dim(self):
        try:    return self.layers[-1].out_features
        except: return 0

class TandemNN(Module):
    def __init__(self, forward_model: LinearNN, inverse_model: LinearNN, ):
        super(TandemNN, self).__init__()

        self.__forward_model = forward_model
        self.__inverse_model = inverse_model

    @property
    def forward_model(self) -> LinearNN: return self.__forward_model
    @property
    def inverse_model(self) -> LinearNN: return self.__inverse_model
    @forward_model.setter
    def forward_model(self, value): self.__forward_model = value
    @inverse_model.setter
    def inverse_model(self, value): self.__inverse_model = value

    def forward(self, x): return self.__forward_model(self.__inverse_model(x))

    def train_forward_model(self, X_train : Tensor, Y_train: Tensor, data_loader: DataLoader, neural_network_parameters: NeuralNetworkParameters, torch_device: device):
        return self.__forward_model.train_model(X_train, Y_train, data_loader, neural_network_parameters, torch_device)

    def train_inverse_model(self, X_train : Tensor, Y_train: Tensor, data_loader: DataLoader, neural_network_parameters: NeuralNetworkParameters, torch_device: device):
        # Ensure that the decoder's parameters are frozen before passing it to Composite_NN_ model
        for parameter in self.__forward_model.parameters(): parameter.requires_grad = False

        lr, \
        weight_decay, \
        loss_function, \
        total_epochs, \
        patience, \
        train_batch_size, \
        train_data_size = get_training_parameters(neural_network_parameters, y_train_size=Y_train.size(0), torch_device=torch_device)

        optimizer = optim.Adam(self.__inverse_model.parameters(), lr=lr, weight_decay=weight_decay)

        print( f"LR={lr}, batch_size={train_batch_size}, train_data_size={train_data_size}")
        print(f"******Inverse Model Model Architecture:\n{self.__inverse_model}\n")
        print(f"******Full Composite Loss->Motors->Loss Model Architecture:\n{self}\n")

        scaler            = GradScaler('cuda')
        best_val_loss     = float('inf')
        epochs_no_improve = 0
        results_dict      = {'training_loss': [], 'validation_loss': []}

        for epoch in range(total_epochs):
            self.__inverse_model.train()
            epoch_loss = 0.0
            for i in range(train_data_size // train_batch_size):
                # Extract batch
                start   = i * train_batch_size
                end     = start + train_batch_size
                X_batch = Y_train[start:end] # beam properties
                Y_batch = X_train[start:end] # motor positions

                optimizer.zero_grad()

                # Use autocast for the forward pass
                with autocast('cuda'):
                    Y_pred = self.__inverse_model(X_batch) # predicted motor_positions
                    X_pred = self.__forward_model(Y_pred)  # beam properties from forward

                    loss = loss_function(X_pred, X_batch)# + loss_function(Y_pred, Y_batch)

                epoch_loss += loss.item()
                scaler.scale(loss).backward()
                scaler.step(optimizer)
                scaler.update()

                del X_batch, Y_batch, X_pred, Y_pred, loss

            # scheduler.step()
            avg_epoch_loss = epoch_loss / (train_data_size // train_batch_size)
            results_dict['training_loss'].append(avg_epoch_loss)

            # Evaluate on validation set
            self.eval()
            total_loss = 0.0
            with no_grad():
                for x_val, y_val in data_loader:
                    X_batch = y_val
                    Y_batch = x_val

                    Y_pred = self.__inverse_model(X_batch) # predicted motor_positions
                    X_pred = self.__forward_model(Y_pred)  # beam properties from forward

                    loss = loss_function(X_pred, X_batch)# + loss_function(Y_pred, Y_batch)
                    total_loss += loss.item()

            val_loss = total_loss / len(data_loader)
            results_dict['validation_loss'].append(val_loss)

            print(f"Epoch {epoch + 1}: Training Loss: {avg_epoch_loss}, Validation Loss: {val_loss}")

            # Check for validation loss improvement
            if val_loss < best_val_loss:
                best_val_loss = val_loss
                epochs_no_improve = 0
            else:
                epochs_no_improve += 1

            # Check for early stopping
            if epochs_no_improve == patience:
                print(f"No improvement in validation loss for {patience} epochs. Stopping training.")
                break

        return results_dict


def get_training_parameters(neural_network_parameters: NeuralNetworkParameters, y_train_size: int, torch_device: device):
    learning_rate = neural_network_parameters.get_parameter('learning_rate', default=1e-6)
    weight_decay = neural_network_parameters.get_parameter('weight_decay', default=1e-5)
    loss_function = neural_network_parameters.get_parameter('loss_function', default=L1Loss().to(torch_device))
    total_epochs = neural_network_parameters.get_parameter('total_epochs', default=5000)
    patience = neural_network_parameters.get_parameter('patience', default=50)
    train_batch_size = neural_network_parameters.get_parameter('batch_size', default=2048)

    train_data_size = y_train_size
    if train_batch_size > train_data_size: train_batch_size = min(int(train_data_size // 2), 64)

    return learning_rate, weight_decay, loss_function, total_epochs, patience, train_batch_size, train_data_size

def get_available_torch_device() -> device:
    if cuda.is_available():
        for i in range(cuda.device_count()):
            print(f"Device {i}: {cuda.get_device_name(i)}")
            print(f"  Memory Allocated: {cuda.memory_allocated(i) / 1e9} GB")
            print(f"  Memory Cached:    {cuda.memory_reserved(i) / 1e9} GB")
        return device("cuda")
    else:
        print("CUDA is not available. Listing CPU instead.")
        return device("cpu")

def move_data_to_torch_device(data, torch_device):
    print(f'Data of size {data.size()} has been moved to {torch_device}')

    return data.to(torch_device)