#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
from aps.ai.beamline_controller.legacy.agent.optimization.facade import OptimizationCriteria
from aps.ai.beamline_controller.legacy.agent.facade import ERROR_LOSS
from aps.ai.beamline_controller.legacy.agent.optimization.common.bayesian.abstract_hypervolume_manager import TrialNumbersFilter
from aps.ai.beamline_controller.legacy.agent.optimization.moo.bayesian.facade import Sampling, MOBOBayesianOptimizationResult, MOBOOptimizationTrialStatus, MOBOBayesianOptimizationResultItem
from aps.ai.beamline_controller.legacy.agent.optimization.moo.bayesian.abstract_hypervolume_manager import MOBOAbstractBayesianHypervolumeManager

from ax.core.base_trial import TrialStatus
from ax.core.experiment import Experiment
from ax.service.ax_client import AxClient
from ax.modelbridge.factory import (get_MOO_EHVI,
                                    get_MOO_RS,
                                    get_MOO_NEHVI,
                                    get_MOO_PAREGO)
from ax.modelbridge.registry import Models

from ax.service.utils.report_utils import _get_generation_method_str


class MOBOAbstractAxHypervolumeManager(MOBOAbstractBayesianHypervolumeManager):
    def __init__(self,
                 hypervolume_reference_points: dict = {},
                 optimization_criteria_constraints: dict = {},
                 optimization_criteria_reference_values: dict = {},
                 optimization_criteria_weights: dict = {}):
        MOBOAbstractBayesianHypervolumeManager.__init__(self,
                                                    hypervolume_reference_points,
                                                    optimization_criteria_constraints,
                                                    optimization_criteria_reference_values,
                                                    optimization_criteria_weights)

    def _get_managed_acquisition_functions(self) -> dict:
        return {"NEHVI":     get_MOO_NEHVI,
                "PAREGO":    get_MOO_PAREGO,
                "EHVI":      get_MOO_EHVI,
                "RS":        get_MOO_RS,
                "Automatic": Models.MOO}

    def _initialize_loss_container(self) -> dict:
        return {}

    def _add_to_loss_container(self, optimization_criterion : str, loss_container : dict, current_loss : float):
        loss_container[optimization_criterion] = current_loss

    '''
    from IBayesianHypervolumeManager interface
    '''

    def get_error_loss_function(self, optimization_criteria) -> dict:
        return {optimization_criterion: ERROR_LOSS for optimization_criterion in optimization_criteria.names}

    def get_native_pareto_front(self, optimization_agent : AxClient, optimization_criteria : OptimizationCriteria) -> dict:
        return optimization_agent.get_pareto_optimal_parameters(use_model_predictions=False)

    def extract_pareto_front_data(self,
                                  optimization_agent : AxClient,
                                  optimization_criteria: OptimizationCriteria,
                                  trial_numbers: list = None,
                                  trial_numbers_filter: int = TrialNumbersFilter.EXCLUDE,
                                  native_pareto_front: dict = None):
        native_optimization_result = self.get_native_optimization_result(optimization_agent)

        if not trial_numbers is None:
            if   trial_numbers_filter == TrialNumbersFilter.EXCLUDE: trial_numbers = [trial_number for trial_number in native_optimization_result.trials.keys() if trial_number not in trial_numbers]
            elif trial_numbers_filter == TrialNumbersFilter.INCLUDE: trial_numbers = [trial_number for trial_number in native_optimization_result.trials.keys() if trial_number in trial_numbers]
            else: trial_numbers = None

        native_pareto_front = self.get_native_pareto_front(optimization_agent, optimization_criteria) if native_pareto_front is None else native_pareto_front

        pareto_front_data = MOBOBayesianOptimizationResult()
        for trial_number in native_pareto_front.keys():
            if trial_numbers is None or trial_number in trial_numbers:
                pareto_front_data.add_optimization_item(MOBOBayesianOptimizationResultItem(trial_number=trial_number,
                                                                                       status=MOBOOptimizationTrialStatus.PARETO,
                                                                                       sampling=Sampling.OPTIMIZED, # this is 99% true, it shoudl be managed differently
                                                                                       motor_positions=native_pareto_front[trial_number][0],
                                                                                       loss_function=native_pareto_front[trial_number][1][0]))

        return pareto_front_data


    def get_native_optimization_result(self, optimization_agent: AxClient) -> Experiment:
        return optimization_agent.experiment

    def extract_optimization_result_data(self,
                                         optimization_agent: AxClient,
                                         optimization_criteria: OptimizationCriteria,
                                         trial_numbers: list = None,
                                         trial_numbers_filter: int = TrialNumbersFilter.EXCLUDE,
                                         native_optimization_result: Experiment = None):
        native_optimization_result = self.get_native_optimization_result(optimization_agent) if native_optimization_result is None else native_optimization_result
        metrics = [native_optimization_result.metrics[optimization_criterion] for optimization_criterion in optimization_criteria.names]

        if not trial_numbers is None and trial_numbers_filter == TrialNumbersFilter.EXCLUDE:
            trial_numbers = [trial_number for trial_number in native_optimization_result.trials.keys() if trial_number not in trial_numbers]

        def get_status(trial_status: TrialStatus):
            return MOBOOptimizationTrialStatus.COMPLETED if trial_status == TrialStatus.COMPLETED else MOBOOptimizationTrialStatus.FAILED

        def get_sampling(trial):
            return Sampling.QUASI_RANDOM if "sobol" in _get_generation_method_str(trial).lower() else Sampling.OPTIMIZED

        optimization_result_data = MOBOBayesianOptimizationResult()
        for trial_number in native_optimization_result.trials.keys():
            if trial_numbers is None or trial_number in trial_numbers:
                trial = native_optimization_result.trials[trial_number]

                optimization_result_data.add_optimization_item(
                    MOBOBayesianOptimizationResultItem(
                        trial_number=trial_number,
                        status=get_status(trial.status),
                        sampling=get_sampling(trial),
                        motor_positions=trial.arms[0].parameters,
                        loss_function={item[1]: item[2] for item in trial.fetch_data(metrics).df.values}
                    )
                )

        return optimization_result_data

from aps.ai.beamline_controller.legacy.agent.optimization.decorators.direct_beam_image_decorator import DirectBeamImageHyperVolumeManagerDecorator
from aps.ai.beamline_controller.legacy.agent.optimization.decorators.wavefront_analysis_decorator import WavefrontAnalysisHyperVolumeManagerDecorator
from aps.ai.beamline_controller.legacy.agent.optimization.decorators.speckle_analysis_decorator import SpeckleAnalysisHyperVolumeManagerDecorator

class AxDirectBeamImageHypervolumeManager(DirectBeamImageHyperVolumeManagerDecorator, MOBOAbstractAxHypervolumeManager):
    def __init__(self,
                 hypervolume_reference_points: dict,
                 optimization_criteria_constraints: dict = {},
                 optimization_criteria_reference_values: dict = {},
                 optimization_criteria_weights: dict = {}):
        DirectBeamImageHyperVolumeManagerDecorator.__init__(self)
        MOBOAbstractAxHypervolumeManager.__init__(self,
                                              hypervolume_reference_points,
                                              optimization_criteria_constraints,
                                              optimization_criteria_reference_values,
                                              optimization_criteria_weights)


class AxWavefrontAnalysisHypervolumeManager(WavefrontAnalysisHyperVolumeManagerDecorator, MOBOAbstractAxHypervolumeManager):
    def __init__(self,
                 hypervolume_reference_points: dict,
                 optimization_criteria_constraints: dict = {},
                 optimization_criteria_reference_values: dict = {},
                 optimization_criteria_weights: dict = {}):
        WavefrontAnalysisHyperVolumeManagerDecorator.__init__(self)
        MOBOAbstractAxHypervolumeManager.__init__(self,
                                              hypervolume_reference_points,
                                              optimization_criteria_constraints,
                                              optimization_criteria_reference_values,
                                              optimization_criteria_weights)

class AxSpeckleAnalysisHypervolumeManager(SpeckleAnalysisHyperVolumeManagerDecorator, MOBOAbstractAxHypervolumeManager):
    def __init__(self,
                 hypervolume_reference_points: dict,
                 optimization_criteria_constraints: dict = {},
                 optimization_criteria_reference_values: dict = {},
                 optimization_criteria_weights: dict = {}):
        SpeckleAnalysisHyperVolumeManagerDecorator.__init__(self)
        MOBOAbstractAxHypervolumeManager.__init__(self,
                                              hypervolume_reference_points,
                                              optimization_criteria_constraints,
                                              optimization_criteria_reference_values,
                                              optimization_criteria_weights)

