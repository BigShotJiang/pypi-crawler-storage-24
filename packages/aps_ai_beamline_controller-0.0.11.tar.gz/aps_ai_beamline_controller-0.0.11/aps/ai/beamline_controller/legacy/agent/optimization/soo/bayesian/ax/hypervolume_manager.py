#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
import numpy as np

from aps.ai.beamline_controller.legacy.agent.optimization.facade import OptimizationCriteria
from aps.ai.beamline_controller.legacy.agent.facade import ERROR_LOSS
from aps.ai.beamline_controller.legacy.agent.optimization.common.bayesian.abstract_hypervolume_manager import TrialNumbersFilter
from aps.ai.beamline_controller.legacy.agent.optimization.soo.bayesian.facade import Sampling, SOBOBayesianOptimizationResult, OptimizationTrialStatus, SOBOBayesianOptimizationResultItem
from aps.ai.beamline_controller.legacy.agent.optimization.soo.bayesian.abstract_hypervolume_manager import SOBOAbstractBayesianHypervolumeManager

from ax.core.base_trial import TrialStatus
from ax.core.experiment import Experiment
from ax.service.ax_client import AxClient
from ax.modelbridge.factory import (get_EHVI,
                                    get_NEI,
                                    get_botorch)

from ax.modelbridge.registry import Models

from ax.service.utils.report_utils import _get_generation_method_str

class SOBOAbstractAxHypervolumeManager(SOBOAbstractBayesianHypervolumeManager):
    def __init__(self,
                 hypervolume_reference_points: dict = {},
                 optimization_criteria_constraints: dict = {},
                 optimization_criteria_reference_values: dict = {},
                 optimization_criteria_weights: dict = {}):
        SOBOAbstractBayesianHypervolumeManager.__init__(self,
                                                    hypervolume_reference_points,
                                                    optimization_criteria_constraints,
                                                    optimization_criteria_reference_values,
                                                    optimization_criteria_weights)

    def _get_managed_acquisition_functions(self) -> dict:
        return {"NEI":       get_NEI,
                "EHVI":      get_EHVI,
                "BOTORCH":   get_botorch,
                "Automatic": Models.BOTORCH}

    '''
    from IBayesianHypervolumeManager interface
    '''
    def get_error_loss_function(self, optimization_criteria) -> float:
        error_loss = {optimization_criterion: ERROR_LOSS for optimization_criterion in optimization_criteria.names}
        error_loss["scalar_loss"] = ERROR_LOSS*optimization_criteria.number

        return error_loss

    def get_native_optimization_result(self, optimization_agent: AxClient) -> Experiment:
        return optimization_agent.experiment

    def set_loss_function_from_optimization(self, loss_function : dict):
        self.__loss_function = loss_function

    def extract_optimization_result_data(self,
                                         optimization_agent: AxClient,
                                         optimization_criteria: OptimizationCriteria,
                                         trial_numbers: list = None,
                                         trial_numbers_filter: int = TrialNumbersFilter.EXCLUDE,
                                         native_optimization_result: Experiment = None):
        native_optimization_result = self.get_native_optimization_result(optimization_agent) if native_optimization_result is None else native_optimization_result
        metrics = [native_optimization_result.metrics["scalar_loss"]]

        if not trial_numbers is None and trial_numbers_filter == TrialNumbersFilter.EXCLUDE:
            trial_numbers = [trial_number for trial_number in native_optimization_result.trials.keys() if trial_number not in trial_numbers]

        def get_status(trial_status: TrialStatus):
            return OptimizationTrialStatus.COMPLETED if trial_status == TrialStatus.COMPLETED else OptimizationTrialStatus.FAILED

        def get_sampling(trial):
            return Sampling.QUASI_RANDOM if "sobol" in _get_generation_method_str(trial).lower() else Sampling.OPTIMIZED

        optimization_result_data = SOBOBayesianOptimizationResult()
        for trial_number in native_optimization_result.trials.keys():
            if trial_numbers is None or trial_number in trial_numbers:
                trial = native_optimization_result.trials[trial_number]

                native_loss = {item[1]: item[2] for item in trial.fetch_data(metrics).df.values}
                loss_function = {} if self.__loss_function is None else self.__loss_function[trial_number]

                for key in native_loss.keys(): loss_function[key] = native_loss[key]

                optimization_result_data.add_optimization_item(
                    SOBOBayesianOptimizationResultItem(
                        trial_number=trial_number,
                        status=get_status(trial.status),
                        sampling=get_sampling(trial),
                        motor_positions=trial.arms[0].parameters,
                        loss_function=loss_function,
                        scalar_loss=sum(list(loss_function.values()))
                    )
                )

        return optimization_result_data

from aps.ai.beamline_controller.legacy.agent.optimization.decorators.direct_beam_image_decorator import DirectBeamImageHyperVolumeManagerDecorator
from aps.ai.beamline_controller.legacy.agent.optimization.decorators.wavefront_analysis_decorator import WavefrontAnalysisHyperVolumeManagerDecorator
from aps.ai.beamline_controller.legacy.agent.optimization.decorators.speckle_analysis_decorator import SpeckleAnalysisHyperVolumeManagerDecorator

class AxDirectBeamImageHypervolumeManager(DirectBeamImageHyperVolumeManagerDecorator, SOBOAbstractAxHypervolumeManager):
    def __init__(self,
                 hypervolume_reference_points: dict,
                 optimization_criteria_constraints: dict = {},
                 optimization_criteria_reference_values: dict = {},
                 optimization_criteria_weights: dict = {}):
        DirectBeamImageHyperVolumeManagerDecorator.__init__(self)
        SOBOAbstractAxHypervolumeManager.__init__(self,
                                              hypervolume_reference_points,
                                              optimization_criteria_constraints,
                                              optimization_criteria_reference_values,
                                              optimization_criteria_weights)


class AxWavefrontAnalysisHypervolumeManager(WavefrontAnalysisHyperVolumeManagerDecorator, SOBOAbstractAxHypervolumeManager):
    def __init__(self,
                 hypervolume_reference_points: dict,
                 optimization_criteria_constraints: dict = {},
                 optimization_criteria_reference_values: dict = {},
                 optimization_criteria_weights: dict = {}):
        WavefrontAnalysisHyperVolumeManagerDecorator.__init__(self)
        SOBOAbstractAxHypervolumeManager.__init__(self,
                                              hypervolume_reference_points,
                                              optimization_criteria_constraints,
                                              optimization_criteria_reference_values,
                                              optimization_criteria_weights)

class AxSpeckleAnalysisHypervolumeManager(SpeckleAnalysisHyperVolumeManagerDecorator, SOBOAbstractAxHypervolumeManager):
    def __init__(self,
                 hypervolume_reference_points: dict,
                 optimization_criteria_constraints: dict = {},
                 optimization_criteria_reference_values: dict = {},
                 optimization_criteria_weights: dict = {}):
        SpeckleAnalysisHyperVolumeManagerDecorator.__init__(self)
        SOBOAbstractAxHypervolumeManager.__init__(self,
                                              hypervolume_reference_points,
                                              optimization_criteria_constraints,
                                              optimization_criteria_reference_values,
                                              optimization_criteria_weights)

