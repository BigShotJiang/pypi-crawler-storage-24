#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #

###########################################################################
# Author: Saugat Kandel
#
# this code was in the module custom_botorch_integration.py
###########################################################################

import warnings
from collections import OrderedDict
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple, Union

import botorch.utils.multi_objective.pareto
import numpy
import torch
from botorch.acquisition.monte_carlo import qExpectedImprovement, qNoisyExpectedImprovement
from botorch.acquisition.multi_objective.monte_carlo import (qExpectedHypervolumeImprovement,
                                                             qNoisyExpectedHypervolumeImprovement)
from botorch.acquisition.multi_objective.objective import IdentityMCMultiOutputObjective
from botorch.acquisition.objective import ConstrainedMCObjective, GenericMCObjective
from botorch.fit import fit_gpytorch_mll
from botorch.models import SingleTaskGP
from botorch.models.transforms.outcome import Standardize
from botorch.optim import optimize_acqf

try: from botorch.sampling.samplers import SobolQMCNormalSampler
except: from botorch.sampling.normal import SobolQMCNormalSampler

from botorch.utils.multi_objective.box_decompositions import NondominatedPartitioning
from botorch.utils.multi_objective.scalarization import get_chebyshev_scalarization
from botorch.utils.sampling import sample_simplex
from botorch.utils.transforms import normalize, unnormalize
from gpytorch.mlls import ExactMarginalLogLikelihood

def qnei_candidates_func(previous_parameter_configurations: "torch.Tensor",
                         previously_observed_objectives:    "torch.Tensor",
                         objective_constraints:             Optional["torch.Tensor"],
                         search_space_bounds:               "torch.Tensor",
                         mean_module:                       Optional[object] = None,
                         covar_module:                      Optional[object] = None,
                         **kwargs) -> Tuple["SingleTaskGP", "torch.Tensor"]:
    """Quasi MC-based batch Noisy Expected Improvement (qEI).

    The default value of ``candidates_func`` in :class:`~optuna.integration.BoTorchSampler`
    with single-objective optimization.

    Args:
        previous_parameter_configurations:
            Previous parameter configurations. A ``torch.Tensor`` of shape
            ``(n_trials, n_params)``. ``n_trials`` is the number of already observed trials
            and ``n_params`` is the number of parameters. ``n_params`` may be larger than the
            actual number of parameters if categorical parameters are included in the search
            space, since these parameters are one-hot encoded.
            Values are not normalized.
        previously_observed_objectives:
            Previously observed objectives. A ``torch.Tensor`` of shape
            ``(n_trials, n_objectives)``. ``n_trials`` is identical to that of ``train_x``.
            ``n_objectives`` is the number of objectives. Observations are not normalized.
        objective_constraints:
            Objective constraints. A ``torch.Tensor`` of shape ``(n_trials, n_constraints)``.
            ``n_trials`` is identical to that of ``train_x``. ``n_constraints`` is the number of
            constraints. A constraint is violated if strictly larger than 0. If no constraints are
            involved in the optimization, this argument will be :obj:`None`.
        search_space_bounds:
            Search space bounds. A ``torch.Tensor`` of shape ``(2, n_params)``. ``n_params`` is
            identical to that of ``train_x``. The first and the second rows correspond to the
            lower and upper bounds for each parameter respectively.

    Returns:
        Next set of candidates. Usually the return value of BoTorch's ``optimize_acqf``.

    """

    if previously_observed_objectives.size(-1) != 1: raise ValueError("Objective may only contain single values with qNEI.")

    if objective_constraints is not None:
        training_observations = torch.cat([previously_observed_objectives, objective_constraints], dim=-1)

        n_constraints = objective_constraints.size(1)
        constraints = []
        for i in range(n_constraints): constraints.append(lambda Z, i=i: Z[..., -n_constraints + i])

        objective = ConstrainedMCObjective(objective=lambda Z: Z[..., 0], constraints=constraints)
    else:
        training_observations   = previously_observed_objectives
        objective = None  # Using the default identity objective.

    previous_parameter_configurations = normalize(previous_parameter_configurations, bounds=search_space_bounds)

    model = SingleTaskGP(train_X=previous_parameter_configurations,
                         train_Y=training_observations,
                         outcome_transform=Standardize(m=training_observations.size(-1)),
                         mean_module=mean_module,
                         covar_module=covar_module)
    mll = ExactMarginalLogLikelihood(model.likelihood, model)
    fit_gpytorch_mll(mll)

    acquisition_function = qNoisyExpectedImprovement(model=model,
                                                     X_baseline=previous_parameter_configurations,
                                                     sampler=SobolQMCNormalSampler(256),
                                                     objective=objective,
                                                     prune_baseline=True)

    standard_bounds = torch.zeros_like(search_space_bounds)
    standard_bounds[1] = 1

    candidates, _ = optimize_acqf(acq_function=acquisition_function,
                                  bounds=standard_bounds,
                                  q=1,
                                  num_restarts=10,
                                  raw_samples=512,
                                  options={"batch_limit": 5, "maxiter": 200},
                                  sequential=True)

    candidates = unnormalize(candidates.detach(), bounds=search_space_bounds)

    return model, candidates


def qnehvi_candidates_func(previous_parameter_configurations: "torch.Tensor",
                           previously_observed_objectives:    "torch.Tensor",
                           objective_constraints:             Optional["torch.Tensor"],
                           search_space_bounds:               "torch.Tensor",
                           mean_module:                       Optional[object] = None,
                           covar_module:                      Optional[object] = None,
                           **kwargs) -> Tuple[SingleTaskGP, "torch.Tensor"]:
    """Quasi MC-based batch Expected Hypervolume Improvement (qnehvi).

    The default value of ``candidates_func`` in :class:`~optuna.integration.BoTorchSampler`
    with multi-objective optimization when the number of objectives is three or less.

    .. seealso::
        :func:`~optuna.integration.botorch.qei_candidates_func` for argument and return value
        descriptions.
    """
    reference_points = kwargs.get("reference_points")

    n_objectives = previously_observed_objectives.size(-1)

    if objective_constraints is not None:
        training_observations = torch.cat([previously_observed_objectives, objective_constraints], dim=-1)

        constraints = []
        n_constraints = objective_constraints.size(1)

        for i in range(n_constraints): constraints.append(lambda Z, i=i: Z[..., -n_constraints + i])
        additional_qnehvi_kwargs = {"objective": IdentityMCMultiOutputObjective(outcomes=list(range(n_objectives))),
                                    "constraints": constraints}
    else:
        training_observations = previously_observed_objectives
        additional_qnehvi_kwargs = {}

    previous_parameter_configurations = normalize(previous_parameter_configurations, bounds=search_space_bounds)

    model = SingleTaskGP(train_X=previous_parameter_configurations,
                         train_Y=training_observations,
                         outcome_transform=Standardize(m=training_observations.shape[-1]),
                         mean_module=mean_module,
                         covar_module=covar_module)
    mll = ExactMarginalLogLikelihood(model.likelihood, model)
    fit_gpytorch_mll(mll)

    non_dominated_front = botorch.utils.multi_objective.pareto.is_non_dominated(training_observations)
    pareto_front        = training_observations[non_dominated_front]
    ref_points_inferred = botorch.utils.multi_objective.hypervolume.infer_reference_point(pareto_front)

    if reference_points is None: reference_points = previously_observed_objectives.min(dim=0).values - 1e-8
    else:                        reference_points = torch.tensor(reference_points)

    reference_point_list = list(torch.maximum(ref_points_inferred[:n_objectives], reference_points))

    acquisition_function = qNoisyExpectedHypervolumeImprovement(model=model,
                                                                ref_point=reference_point_list,
                                                                X_baseline=previous_parameter_configurations,
                                                                prune_baseline=True,
                                                                sampler=SobolQMCNormalSampler(256),
                                                                **additional_qnehvi_kwargs)

    standard_bounds = torch.zeros_like(search_space_bounds)
    standard_bounds[1] = 1

    candidates, _ = optimize_acqf(acq_function=acquisition_function,
                                  bounds=standard_bounds,
                                  q=1,
                                  num_restarts=20,
                                  raw_samples=1024,
                                  options={"batch_limit": 5, "maxiter": 200, "nonnegative": True},
                                  sequential=True)

    candidates = unnormalize(candidates.detach(), bounds=search_space_bounds)

    return model, candidates


def qei_candidates_func(previous_parameter_configurations: "torch.Tensor",
                        previously_observed_objectives: "torch.Tensor",
                        objective_constraints: Optional["torch.Tensor"],
                        search_space_bounds: "torch.Tensor",
                        mean_module: Optional[object] = None,
                        covar_module: Optional[object] = None,
                        **kwargs) -> Tuple[SingleTaskGP, "torch.Tensor"]:
    """Quasi MC-based batch Expected Improvement (qEI).

    The default value of ``candidates_func`` in :class:`~optuna.integration.BoTorchSampler`
    with single-objective optimization.

    Args:
        train_x:
            Previous parameter configurations. A ``torch.Tensor`` of shape
            ``(n_trials, n_params)``. ``n_trials`` is the number of already observed trials
            and ``n_params`` is the number of parameters. ``n_params`` may be larger than the
            actual number of parameters if categorical parameters are included in the search
            space, since these parameters are one-hot encoded.
            Values are not normalized.
        train_obj:
            Previously observed objectives. A ``torch.Tensor`` of shape
            ``(n_trials, n_objectives)``. ``n_trials`` is identical to that of ``train_x``.
            ``n_objectives`` is the number of objectives. Observations are not normalized.
        train_con:
            Objective constraints. A ``torch.Tensor`` of shape ``(n_trials, n_constraints)``.
            ``n_trials`` is identical to that of ``train_x``. ``n_constraints`` is the number of
            constraints. A constraint is violated if strictly larger than 0. If no constraints are
            involved in the optimization, this argument will be :obj:`None`.
        bounds:
            Search space bounds. A ``torch.Tensor`` of shape ``(2, n_params)``. ``n_params`` is
            identical to that of ``train_x``. The first and the second rows correspond to the
            lower and upper bounds for each parameter respectively.

    Returns:
        Next set of candidates. Usually the return value of BoTorch's ``optimize_acqf``.

    """

    if previously_observed_objectives.size(-1) != 1: raise ValueError("Objective may only contain single values with qEI.")
    if objective_constraints is not None:
        training_observations = torch.cat([previously_observed_objectives, objective_constraints], dim=-1)

        feasible_previously_observed_objectives = previously_observed_objectives[(objective_constraints <= 0).all(dim=-1)]

        if feasible_previously_observed_objectives.numel() == 0:
            # TODO(hvy): Do not use 0 as the best observation.
            warnings.warn("No objective values are feasible. Using 0 as the best objective in qEI.")
            best_observed_objective_value = torch.zeros(())
        else:
            best_observed_objective_value = feasible_previously_observed_objectives.max()

        constraints = []
        n_constraints = objective_constraints.size(1)
        for i in range(n_constraints): constraints.append(lambda Z, i=i: Z[..., -n_constraints + i])
        objective = ConstrainedMCObjective(objective=lambda Z: Z[..., 0], constraints=constraints)
    else:
        training_observations         = previously_observed_objectives
        best_observed_objective_value = previously_observed_objectives.max()
        objective = None  # Using the default identity objective.

    previous_parameter_configurations = normalize(previous_parameter_configurations, bounds=search_space_bounds)

    model = SingleTaskGP(train_X=previous_parameter_configurations,
                         train_Y=training_observations,
                         outcome_transform=Standardize(m=training_observations.size(-1)),
                         mean_module=mean_module,
                         covar_module=covar_module)

    mll = ExactMarginalLogLikelihood(model.likelihood, model)
    fit_gpytorch_mll(mll)

    acquisition_function = qExpectedImprovement(model=model,
                                                best_f=best_observed_objective_value,
                                                sampler=SobolQMCNormalSampler(256),
                                                objective=objective)

    standard_bounds = torch.zeros_like(search_space_bounds)
    standard_bounds[1] = 1

    candidates, _ = optimize_acqf(acq_function=acquisition_function,
                                  bounds=standard_bounds,
                                  q=1,
                                  num_restarts=10,
                                  raw_samples=512,
                                  options={"batch_limit": 5, "maxiter": 200},
                                  sequential=True)

    candidates = unnormalize(candidates.detach(), bounds=search_space_bounds)

    return model, candidates


def qehvi_candidates_func(previous_parameter_configurations: "torch.Tensor",
                          previously_observed_objectives: "torch.Tensor",
                          objective_constraints: Optional["torch.Tensor"],
                          search_space_bounds: "torch.Tensor",
                          mean_module: Optional[object] = None,
                          covar_module: Optional[object] = None,
                          **kwargs) -> Tuple[SingleTaskGP, "torch.Tensor"]:
    """Quasi MC-based batch Expected Hypervolume Improvement (qEHVI).

    The default value of ``candidates_func`` in :class:`~optuna.integration.BoTorchSampler`
    with multi-objective optimization when the number of objectives is three or less.

    .. seealso::
        :func:`~optuna.integration.botorch.qei_candidates_func` for argument and return value
        descriptions.
    """

    n_objectives = previously_observed_objectives.size(-1)

    if objective_constraints is not None:
        training_observations = torch.cat([previously_observed_objectives, objective_constraints], dim=-1)

        feasible_previously_observed_objectives = previously_observed_objectives[(objective_constraints <= 0).all(dim=-1)]

        constraints = []
        n_constraints = objective_constraints.size(1)

        for i in range(n_constraints): constraints.append(lambda Z, i=i: Z[..., -n_constraints + i])
        additional_qehvi_kwargs = {"objective":   IdentityMCMultiOutputObjective(outcomes=list(range(n_objectives))),
                                   "constraints": constraints}
    else:
        training_observations                   = previously_observed_objectives
        feasible_previously_observed_objectives = previously_observed_objectives

        additional_qehvi_kwargs = {}

    previous_parameter_configurations = normalize(previous_parameter_configurations, bounds=search_space_bounds)

    model = SingleTaskGP(train_X=previous_parameter_configurations,
                         train_Y=training_observations,
                         outcome_transform=Standardize(m=training_observations.shape[-1]),
                         mean_module=mean_module,
                         covar_module=covar_module)
    mll = ExactMarginalLogLikelihood(model.likelihood, model)
    fit_gpytorch_mll(mll)

    # Approximate box decomposition similar to Ax when the number of objectives is large.
    # https://github.com/facebook/Ax/blob/master/ax/models/torch/botorch_moo_defaults
    if n_objectives > 2: alpha = 10 ** (-8 + n_objectives)
    else:                alpha = 0.0

    reference_point      = previously_observed_objectives.min(dim=0).values - 1e-8
    partitioning         = NondominatedPartitioning(ref_point=reference_point,
                                                    Y=feasible_previously_observed_objectives,
                                                    alpha=alpha)
    reference_point_list = reference_point.tolist()

    acquisition_function = qExpectedHypervolumeImprovement(model=model,
                                                           ref_point=reference_point_list,
                                                           partitioning=partitioning,
                                                           sampler=SobolQMCNormalSampler(256),
                                                           **additional_qehvi_kwargs)

    standard_bounds = torch.zeros_like(search_space_bounds)
    standard_bounds[1] = 1

    candidates, _ = optimize_acqf(acq_function=acquisition_function,
                                  bounds=standard_bounds,
                                  q=1,
                                  num_restarts=20,
                                  raw_samples=1024,
                                  options={"batch_limit": 5, "maxiter": 200, "nonnegative": True},
                                  sequential=True)

    candidates = unnormalize(candidates.detach(), bounds=search_space_bounds)

    return model, candidates


def qparego_candidates_func(previous_parameter_configurations: "torch.Tensor",
                            previously_observed_objectives:    "torch.Tensor",
                            objective_constraints:             Optional["torch.Tensor"],
                            search_space_bounds:               "torch.Tensor",
                            mean_module:                       Optional[object] = None,
                            covar_module:                      Optional[object] = None,
                            **kwargs) -> Tuple[SingleTaskGP, "torch.Tensor"]:
    """Quasi MC-based extended ParEGO (qParEGO) for constrained multi-objective optimization.

    The default value of ``candidates_func`` in :class:`~optuna.integration.BoTorchSampler`
    with multi-objective optimization when the number of objectives is larger than three.

    .. seealso::
        :func:`~optuna.integration.botorch.qei_candidates_func` for argument and return value
        descriptions.
    """

    n_objectives = previously_observed_objectives.size(-1)

    weights = sample_simplex(n_objectives).squeeze()
    scalarization = get_chebyshev_scalarization(weights=weights, Y=previously_observed_objectives)

    if objective_constraints is not None:
        training_observations = torch.cat([previously_observed_objectives, objective_constraints], dim=-1)

        n_constraints = objective_constraints.size(1)
        constraints = []
        for i in range(n_constraints): constraints.append(lambda Z, i=i: Z[..., -n_constraints + i])

        objective = ConstrainedMCObjective(objective=lambda Z: scalarization(Z[..., :n_objectives]), constraints=constraints)
    else:
        training_observations = previously_observed_objectives
        objective = GenericMCObjective(scalarization)

    previous_parameter_configurations = normalize(previous_parameter_configurations, bounds=search_space_bounds)

    model = SingleTaskGP(train_X=previous_parameter_configurations,
                         train_Y=training_observations,
                         outcome_transform=Standardize(m=training_observations.size(-1)),
                         mean_module=mean_module,
                         covar_module=covar_module)
    mll = ExactMarginalLogLikelihood(model.likelihood, model)
    fit_gpytorch_mll(mll)

    acquisition_function = qExpectedImprovement(model=model,
                                                best_f=objective(training_observations).max(),
                                                sampler=SobolQMCNormalSampler(256),
                                                objective=objective)

    standard_bounds = torch.zeros_like(search_space_bounds)
    standard_bounds[1] = 1

    candidates, _ = optimize_acqf(acq_function=acquisition_function,
                                  bounds=standard_bounds,
                                  q=1,
                                  num_restarts=20,
                                  raw_samples=1024,
                                  options={"batch_limit": 5, "maxiter": 200},
                                  sequential=True)

    candidates = unnormalize(candidates.detach(), bounds=search_space_bounds)

    return model, candidates

def qnparego_candidates_func(previous_parameter_configurations: "torch.Tensor",
                            previously_observed_objectives:    "torch.Tensor",
                            objective_constraints:             Optional["torch.Tensor"],
                            search_space_bounds:               "torch.Tensor",
                            mean_module:                       Optional[object] = None,
                            covar_module:                      Optional[object] = None,
                            **kwargs) -> Tuple[SingleTaskGP, "torch.Tensor"]:
    """Quasi MC-based extended ParEGO (qParEGO) for constrained multi-objective optimization.

    The default value of ``candidates_func`` in :class:`~optuna.integration.BoTorchSampler`
    with multi-objective optimization when the number of objectives is larger than three.

    .. seealso::
        :func:`~optuna.integration.botorch.qei_candidates_func` for argument and return value
        descriptions.
    """

    n_objectives = previously_observed_objectives.size(-1)

    weights = sample_simplex(n_objectives).squeeze()
    scalarization = get_chebyshev_scalarization(weights=weights, Y=previously_observed_objectives)

    if objective_constraints is not None:
        training_observations = torch.cat([previously_observed_objectives, objective_constraints], dim=-1)

        n_constraints = objective_constraints.size(1)
        constraints = []
        for i in range(n_constraints): constraints.append(lambda Z, i=i: Z[..., -n_constraints + i])

        objective = ConstrainedMCObjective(objective=lambda Z: scalarization(Z[..., :n_objectives]), constraints=constraints)
    else:
        training_observations = previously_observed_objectives
        objective = GenericMCObjective(scalarization)

    previous_parameter_configurations = normalize(previous_parameter_configurations, bounds=search_space_bounds)

    model = SingleTaskGP(train_X=previous_parameter_configurations,
                         train_Y=training_observations,
                         outcome_transform=Standardize(m=training_observations.size(-1)),
                         mean_module=mean_module,
                         covar_module=covar_module)
    mll = ExactMarginalLogLikelihood(model.likelihood, model)
    fit_gpytorch_mll(mll)

    acquisition_function = qNoisyExpectedImprovement(model=model,
                                                     X_baseline=previous_parameter_configurations,
                                                     sampler=SobolQMCNormalSampler(256),
                                                     objective=objective,
                                                     prune_baseline=True)

    standard_bounds = torch.zeros_like(search_space_bounds)
    standard_bounds[1] = 1

    candidates, _ = optimize_acqf(acq_function=acquisition_function,
                                  bounds=standard_bounds,
                                  q=1,
                                  num_restarts=20,
                                  raw_samples=1024,
                                  options={"batch_limit": 5, "maxiter": 200},
                                  sequential=True)

    candidates = unnormalize(candidates.detach(), bounds=search_space_bounds)

    return model, candidates

def _get_default_candidates_func(n_objectives: int, noisy=True) -> Callable[["torch.Tensor",
                                                                             "torch.Tensor",
                                                                             Optional["torch.Tensor"],
                                                                             "torch.Tensor",
                                                                             Optional[object],
                                                                             Optional[object]],
                                                                             Tuple[SingleTaskGP, "torch.Tensor"]]:
    if n_objectives > 3:   return qnparego_candidates_func if noisy else qparego_candidates_func
    elif n_objectives > 1: return qnehvi_candidates_func if noisy else qehvi_candidates_func
    else:                  return qnei_candidates_func if noisy else qei_candidates_func
