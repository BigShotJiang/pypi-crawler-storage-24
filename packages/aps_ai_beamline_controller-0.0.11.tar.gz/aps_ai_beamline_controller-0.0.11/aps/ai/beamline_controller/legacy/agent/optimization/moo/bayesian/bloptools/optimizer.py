#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #
import time
import traceback
import numpy as np
from typing import Type

from blop.agent import DOF, Objective, Agent

from aps.beamline_driver.adapters.ophyd.motor import Motor
from aps.beamline_driver.adapters.ophyd.detector_factory import create_detector

from aps.beamline_driver.beam_management.facade import BeamProperties
from aps.beamline_driver.motion_management.facade import MethodCallingType
from aps.ai.beamline_controller.legacy.agent.facade import IAgentListener
from aps.ai.beamline_controller.legacy.agent.optimization.facade import OptimizationDirection, OptimizationCriteria, OptimizationInitParameters
from aps.ai.beamline_controller.legacy.agent.optimization.moo.bayesian.facade import MOBOBayesianOptimizationInputParameters, MOBOBayesianOptimizationResult
from aps.ai.beamline_controller.legacy.agent.optimization.moo.bayesian.abstract_optimizer import MOBOAbstractBayesianOptimizer
from aps.ai.beamline_controller.legacy.agent.optimization.moo.bayesian.bloptools.hypervolume_manager import AbstractBlopToolsHypervolumeManager

class BlopToolsOptimizer(MOBOAbstractBayesianOptimizer):
    def __init__(self, optimization_listener: IAgentListener, **kwargs):
        super(BlopToolsOptimizer, self).__init__(optimization_listener, **kwargs)

    def initialize_optimization(self,
                                hypervolume_manager: AbstractBlopToolsHypervolumeManager = None,
                                **kwargs):
        super(BlopToolsOptimizer, self).initialize_optimization(hypervolume_manager, **kwargs)

        self.__verbose     = kwargs.get("verbose", True)
        self.__debug       = kwargs.get("debug", False)
        self.__data_broker = kwargs.get("data_broker")

    def requires_run_engine(self): return True

    def _get_raw_data_type(self) -> Type: return str

    # ------------------------------------------------------------------------------
    #  AbstractBayesianOptimizer implementation
    # ------------------------------------------------------------------------------

    def _create_optimization_agent(self, **kwargs):
        optimization_criteria: OptimizationCriteria                   = self._optimization_criteria
        input_parameters: MOBOBayesianOptimizationInputParameters         = self._input_parameters
        optimization_parameters: OptimizationInitParameters           = self._optimization_parameters

        motion_manager_method_calling_type = self._motion_manager.method_calling_type()

        motors_to_optimize = input_parameters.motors_to_optimize

        try:
            self._motion_manager.set_method_calling_type(MethodCallingType.STANDARD)  # switch to ophyd

            def create_dofs_list():
                def create_dof(motor_id):
                    motor_info = self._motion_manager.get_motors_info().get_motor_info(motor_id)

                    search_range = motor_info.search_range_by_key(beam_manager_type=input_parameters.beam_manager_type,
                                                                  platform=input_parameters.platform,
                                                                  beam_manager_id=input_parameters.beam_manager_id)
                    boundaries = motor_info.boundaries_by_key(platform=input_parameters.platform)

                    return DOF(device=Motor(name=motor_id,
                                            value=self._motion_manager.get_motor_position(motor_id),
                                            motion_manager=self._motion_manager,
                                            verbose=self.__debug),
                               description=f'this is {motor_id}',
                               units=motor_info.units.label,
                               search_domain=(search_range[0], search_range[1]),
                               trust_domain=(boundaries[0], boundaries[1]),
                               read_only=False,
                               active=True,
                               tags=[])

                return [create_dof(motor_id) for motor_id in motors_to_optimize]

            def create_detectors_list():
                return [create_detector(prefix="",
                                        name=self._beam_manager.get_beam_manager_id(),
                                        beam_manager=self._beam_manager,
                                        verbose=self.__debug)]

            def create_objectives_list():
                hypervolume_reference_points  = optimization_parameters.get_parameter("hypervolume_reference_points")
                optimization_criteria_weights = optimization_parameters.get_parameter("optimization_criteria_weights")
                is_logarithmic                = optimization_parameters.get_parameter("is_logarithmic")
                optimization_directions       = optimization_parameters.get_parameter("optimization_directions")

                def create_objective(criterion):
                    if is_logarithmic[criterion]: limits = (-np.inf, hypervolume_reference_points[criterion])
                    else:                         limits = (0.0, hypervolume_reference_points[criterion])

                    return Objective(name=criterion,
                                     description=f"this is {criterion}",
                                     target="min" if optimization_directions[criterion] == OptimizationDirection.MINIMIZE else "max",
                                     weight=optimization_criteria_weights[criterion],
                                     trust_domain=limits,
                                     units='float',
                                     latent_groups=[])

                return [create_objective(criterion) for criterion in optimization_criteria.names]

            def evaluate_loss(products):
                detector_prefix = self._beam_manager.get_beam_manager_id()
                for index, entry in products.iterrows():
                    beam_properties = BeamProperties()
                    for property_name in self._beam_manager.get_beam_properties_type().to_list():
                        beam_properties.set_parameter(property_name, entry[detector_prefix + "_" + property_name.replace("-", "_")])

                    loss_function, error, message = self._hypervolume_manager.evaluate_loss_function(beam_properties, optimization_criteria)

                    for objective_name in optimization_criteria.names: products.loc[index, objective_name] = loss_function[objective_name]

                return products

        # ---------------------------------------------------------------
        # Creation of the Agent

            agent =  Agent(dofs=create_dofs_list(),
                           objectives=create_objectives_list(),
                           db=self.__data_broker,
                           detectors=create_detectors_list(),
                           digestion=evaluate_loss,
                           train_every=1,
                           verbose=self.__verbose,
                           tolerate_acquisition_errors=True,
                           sample_center_on_init=False,
                           trigger_delay=0.1)
        finally:
            self._motion_manager.set_method_calling_type(motion_manager_method_calling_type) # switch back

        return agent

    # ------------------------------------------------------------------------------

    def _run_optimization(self, **kwargs) -> (int, dict):
        motion_manager_method_calling_type = self._motion_manager.method_calling_type()
        beam_manager_method_calling_type   = self._beam_manager.method_calling_type()

        try:
            # switch to ophyd
            self._motion_manager.set_method_calling_type(MethodCallingType.STANDARD)
            self._beam_manager.set_method_calling_type(MethodCallingType.STANDARD)

            input_parameters: MOBOBayesianOptimizationInputParameters = self._input_parameters
            current_timestamps      = {}
            current_raw_data        = {}

            acquisition_function  = self._optimization_parameters.get_parameter("acquisition_function")

            message = []
            message.append(f'**************************************************')
            message.append(f'Now model starts at trial {1}')
            message.append(f'Acquisition function: {"Sobol Random (qr)"}')
            message.append(f'**************************************************')
            self._optimization_listener.feedback(None, None, None, None, None, message=message)

            last_trial_number = yield from self._run_bloptools(acqf="qr",
                                                               iterations=1,
                                                               n=input_parameters.sobol_trials,
                                                               current_timestamps=current_timestamps,
                                                               current_raw_data=current_raw_data,
                                                               initial_index=0,
                                                               initial_trial_number=1)
            message = []
            message.append(f'**************************************************')
            message.append(f'Now model starts at trial {2}')
            message.append(f'Acquisition function: {acquisition_function}')
            message.append(f'**************************************************')
            self._optimization_listener.feedback(None, None, None, None, None, message=message)

            last_trial_number = yield from self._run_bloptools(acqf=acquisition_function,
                                                               iterations=input_parameters.bo_trials,
                                                               n=1,
                                                               current_timestamps=current_timestamps,
                                                               current_raw_data=current_raw_data,
                                                               initial_index=1,
                                                               initial_trial_number=last_trial_number + 1)

        finally:
            # switch back to original setup
            self._motion_manager.set_method_calling_type(motion_manager_method_calling_type)
            self._beam_manager.set_method_calling_type(beam_manager_method_calling_type)

        return last_trial_number, current_timestamps, current_raw_data

    # ------------------------------------------------------------------------------

    def _run_bloptools(self, acqf: str = "qei", iterations: int = 1, n=1, current_timestamps={}, current_raw_data={}, initial_index=0, initial_trial_number=1):
        agent  = self._optimization_agent

        for i in range(iterations):
            if self.interrupt: break

            iteration_number = initial_index + i + 1
            trial_numbers    = np.arange(initial_trial_number, initial_trial_number + (iterations * n)).tolist()

            if self.__verbose: print(f"running iteration {i + 1} / {iterations}")

            res = agent.ask(n=n, acqf=acqf, upsample=1, route=True)

            try:
                new_table = yield from agent.acquire(res["points"])
                new_table.loc[:, "acqf"] = res["acqf_name"]

                suggested_motor_positions = {key: new_table.pop(key).tolist() for key in agent.dofs.names}
                current_loss              = {key: new_table.pop(key).tolist() for key in agent.objectives.names}
                timestamps                = new_table.pop("time").tolist()
                beam_hex_strings          = new_table.pop(self._beam_manager.get_beam_manager_id() + "_beam").tolist()
                metadata = new_table.to_dict(orient="list")

                for trial_number, timestamp, beam_hex_string in zip(trial_numbers, timestamps, beam_hex_strings):
                    current_timestamps[trial_number] = [timestamp, timestamp]
                    current_raw_data[trial_number]   = beam_hex_string

                try:
                    agent.tell(x=suggested_motor_positions, y=current_loss, metadata=metadata, append=True, train=True)

                    self._optimization_listener.feedback((iteration_number), suggested_motor_positions, agent.dofs.names, suggested_motor_positions, current_loss)
                except BaseException as e:
                    message = [f"Iteration #{iteration_number} failed while learning.",
                               f"captured exception: {type(e)}",
                               f"{traceback.format_exc()}"]
                    if self.__verbose: print(tuple(message))
                    self._optimization_listener.feedback(iteration_number, None, None, None, None, message=message)
            except BaseException as e:
                message = [f"Iteration #{iteration_number} failed during acquisition.",
                           f"captured exception: {type(e)}",
                           f"{traceback.format_exc()}"]
                if self.__verbose: print(tuple(message))
                self._optimization_listener.feedback(iteration_number, None, None, None, None, message=message)

        return trial_numbers[-1]

    @classmethod
    def _get_pareto_file_prefix(cls) -> str:
        return "bloptools_experiment"

    @classmethod
    def _get_ml_file_prefix(cls) -> str:
        return cls._get_pareto_file_prefix()

    def _manage_transfer_learning_input(self, **kwargs):
        if self._execution_parameters.do_warm_start: raise NotImplementedError("BlopTools does not support warm start")
        else:                                        self._warm_start_data = None


    # ------------------------------------------------------------------------------
    #  SAVE TO FILE AND PLOTS
    # ------------------------------------------------------------------------------

    @classmethod
    def _get_result_file_prefix(cls) -> str:
        return cls._get_pareto_file_prefix()


