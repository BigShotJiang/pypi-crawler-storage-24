#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #

###########################################################################
# Author: Saugat Kandel
#
# this code was in the module custom_botorch_integration.py
###########################################################################

import warnings
from collections import OrderedDict
from typing import Any, Callable, Dict, Optional, Sequence,  Union

import numpy
import torch
from botorch.models import SingleTaskGP
from botorch.utils.sampling import manual_seed
from optuna._transform import _SearchSpaceTransform
from optuna.distributions import BaseDistribution
from optuna.samplers import BaseSampler, RandomSampler
from optuna.search_space.intersection import IntersectionSearchSpace
from optuna.samplers._base import _CONSTRAINTS_KEY, _process_constraints_after_trial
from optuna.study import Study, StudyDirection
from optuna.trial import FrozenTrial, TrialState

from aps.ai.beamline_controller.legacy.agent.optimization.moo.bayesian.optuna.botorch.botorch_acquisition_functions import _get_default_candidates_func

class BoTorchSampler(BaseSampler):
    """A sampler that uses BoTorch, a Bayesian optimization library built on top of PyTorch.

    This sampler allows using BoTorch's optimization algorithms from Optuna to suggest parameter
    configurations. Parameters are transformed to continuous space and passed to BoTorch, and then
    transformed back to Optuna's representations. Categorical parameters are one-hot encoded.

    .. seealso::
        See an `example <https://github.com/optuna/optuna-examples/blob/main/multi_objective/
        botorch_simple.py>`_ how to use the sampler.

    .. seealso::
        See the `BoTorch <https://botorch.org/>`_ homepage for details and for how to implement
        your own ``candidates_func``.

    .. note::
        An instance of this sampler *should not be used with different studies* when used with
        constraints. Instead, a new instance should be created for each new study. The reason for
        this is that the sampler is stateful keeping all the computed constraints.

    Args:
        candidates_func:
            An optional function that suggests the next candidates. It must take the training
            data, the objectives, the constraints, the search space bounds and return the next
            candidates. The arguments are of type ``torch.Tensor``. The return value must be a
            ``torch.Tensor``. However, if ``constraints_func`` is omitted, constraints will be
            :obj:`None`. For any constraints that failed to compute, the tensor will contain
            NaN.

            If omitted, it is determined automatically based on the number of objectives. If the
            number of objectives is one, Quasi MC-based batch Expected Improvement (qEI) is used.
            If the number of objectives is either two or three, Quasi MC-based
            batch Expected Hypervolume Improvement (qEHVI) is used. Otherwise, for larger number
            of objectives, the faster Quasi MC-based extended ParEGO (qParEGO) is used.

            The function should assume *maximization* of the objective.

            .. seealso::
                See :func:`optuna.integration.botorch.qei_candidates_func` for an example.
        constraints_func:
            An optional function that computes the objective constraints. It must take a
            :class:`~optuna.trial.FrozenTrial` and return the constraints. The return value must
            be a sequence of :obj:`float` s. A value strictly larger than 0 means that a
            constraint is violated. A value equal to or smaller than 0 is considered feasible.

            If omitted, no constraints will be passed to ``candidates_func`` nor taken into
            account during suggestion.
        n_startup_trials:
            Number of initial trials, that is the number of trials to resort to independent
            sampling.
        independent_sampler:
            An independent sampler to use for the initial trials and for parameters that are
            conditional.
        seed:
            Seed for random number generator.
    """

    def __init__(self,
                 *,
                 candidates_func: Optional[Callable[["torch.Tensor",
                                                     "torch.Tensor",
                                                     Optional["torch.Tensor"],
                                                     "torch.Tensor",
                                                     Optional[object],
                                                     Optional[object]],
                                                    "torch.Tensor"]] = None,
                 constraints_func: Optional[Callable[[FrozenTrial], Sequence[float]]] = None,
                 n_startup_trials: int = 0,
                 independent_sampler: Optional[BaseSampler] = None,
                 seed: Optional[int] = None,
                 mean_module: Optional[object] = None,
                 covar_module: Optional[object] = None):

        self._candidates_func = candidates_func
        self._constraints_func = constraints_func
        self._independent_sampler = independent_sampler or RandomSampler(seed=seed)
        self._n_startup_trials = n_startup_trials
        self._seed = seed
        self._mean_module = mean_module
        self._covar_module = covar_module

        self._study_id: Optional[int] = None
        self._search_space = IntersectionSearchSpace()
        self._model: Optional[SingleTaskGP] = None

    def infer_relative_search_space(self,
                                    study: Study,
                                    trial: FrozenTrial) -> Dict[str, BaseDistribution]:
        if self._study_id is None: self._study_id = study._study_id
        if self._study_id != study._study_id:
            # Note that the check below is meaningless when `InMemoryStorage` is used
            # because `InMemoryStorage.create_new_study` always returns the same study ID.
            raise RuntimeError("BoTorchSampler cannot handle multiple studies.")

        search_space: Dict[str, BaseDistribution] = OrderedDict()
        for name, distribution in self._search_space.calculate(study, ordered_dict=True).items():
            if not distribution.single():
                # built-in `candidates_func` cannot handle distributions that contain just a
                # single value, so we skip them. Note that the parameter values for such
                # distributions are sampled in `Trial`.
                search_space[name] = distribution

        return search_space

    def sample_relative(self,
                        study: Study,
                        trial: FrozenTrial,
                        search_space: Dict[str, BaseDistribution]) -> Dict[str, Any]:
        assert isinstance(search_space, OrderedDict)

        if len(search_space) == 0: return {}

        trials = study.get_trials(deepcopy=False, states=(TrialState.COMPLETE,))

        n_trials = len(trials)
        if n_trials < self._n_startup_trials: return {}

        transform    = _SearchSpaceTransform(search_space)
        n_objectives = len(study.directions)

        values:      Union[numpy.ndarray, torch.Tensor] = numpy.empty((n_trials, n_objectives), dtype=numpy.float64)
        parameters:  Union[numpy.ndarray, torch.Tensor] = numpy.empty((n_trials, transform.bounds.shape[0]), dtype=numpy.float64)
        constraints: Optional[Union[numpy.ndarray, torch.Tensor]] = None
        bounds:      Union[numpy.ndarray, torch.Tensor] = transform.bounds

        for trial_idx, trial in enumerate(trials):
            parameters[trial_idx] = transform.transform(trial.params)
            assert len(study.directions) == len(trial.values)

            for obj_idx, (direction, value) in enumerate(zip(study.directions, trial.values)):
                assert value is not None
                if direction == StudyDirection.MINIMIZE: value *= -1 # BoTorch always assumes maximization.
                values[trial_idx, obj_idx] = value

            if not self._constraints_func is None:
                trial_constraints = study._storage.get_trial_system_attrs(trial._trial_id).get(_CONSTRAINTS_KEY)

                if not trial_constraints is None:
                    n_constraints = len(trial_constraints)

                    if constraints is None: constraints = numpy.full((n_trials, n_constraints), numpy.nan, dtype=numpy.float64)
                    elif n_constraints != constraints.shape[1]: raise RuntimeError(f"Expected {constraints.shape[1]} constraints but received {n_constraints}.")

                    constraints[trial_idx] = trial_constraints

        if not self._constraints_func is None:
            if constraints is None:              warnings.warn("`constraints_func` was given but no call to it correctly computed "
                                                       "constraints. Constraints passed to `candidates_func` will be `None`.")
            elif numpy.isnan(constraints).any(): warnings.warn("`constraints_func` was given but some calls to it did not correctly compute "
                                                       "constraints. Constraints passed to `candidates_func` will contain NaN.")

        values     = torch.from_numpy(values)
        parameters = torch.from_numpy(parameters)
        if constraints is not None: constraints = torch.from_numpy(constraints)
        bounds = torch.from_numpy(bounds)

        if constraints is not None and constraints.dim() == 1: constraints.unsqueeze_(-1)
        bounds.transpose_(0, 1)

        if self._candidates_func is None: self._candidates_func = _get_default_candidates_func(n_objectives=n_objectives)

        # `manual_seed` makes the default candidates functions reproducible.
        # `SobolQMCNormalSampler`'s constructor has a `seed` argument, but its behavior is
        # deterministic when the BoTorch's seed is fixed.
        with manual_seed(self._seed):
            self._model, candidates = self._candidates_func(parameters,
                                                            values,
                                                            constraints,
                                                            bounds,
                                                            mean_module=self._mean_module,
                                                            covar_module=self._covar_module)
            if self._seed is not None: self._seed += 1

        if not isinstance(candidates, torch.Tensor): raise TypeError("Candidates must be a torch.Tensor.")
        if candidates.dim() == 2:
            if candidates.size(0) != 1: raise ValueError("Candidates batch optimization is not supported and the first dimension must "
                                                         "have size 1 if candidates is a two-dimensional tensor. Actual: "
                                                         f"{candidates.size()}.")
            # Batch size is one. Get rid of the batch dimension.
            candidates = candidates.squeeze(0)

        if candidates.dim() != 1: raise ValueError("Candidates must be one or two-dimensional.")
        if candidates.size(0) != bounds.size(1): raise ValueError("Candidates size must match with the given bounds. Actual candidates: "
                                                                  f"{candidates.size(0)}, bounds: {bounds.size(1)}.")

        return transform.untransform(candidates.numpy())

    def sample_independent(self,
                           study: Study,
                           trial: FrozenTrial,
                           param_name: str,
                           param_distribution: BaseDistribution) -> Any:
        return self._independent_sampler.sample_independent(study, trial, param_name, param_distribution)

    def reseed_rng(self) -> None:
        self._independent_sampler.reseed_rng()
        if self._seed is not None: self._seed = numpy.random.RandomState().randint(2**60)

    def after_trial(self,
                    study: Study,
                    trial: FrozenTrial,
                    state: TrialState,
                    values: Optional[Sequence[float]]) -> None:
        if self._constraints_func is not None: _process_constraints_after_trial(self._constraints_func, study, trial, state)
        self._independent_sampler.after_trial(study, trial, state, values)
