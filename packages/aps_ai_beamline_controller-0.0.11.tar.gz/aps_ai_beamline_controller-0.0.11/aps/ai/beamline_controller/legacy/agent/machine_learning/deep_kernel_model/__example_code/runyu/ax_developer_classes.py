import json
import os
from typing import Optional
import time
import configparser
import traceback
import matplotlib.pyplot as plt

import numpy as np
import pandas as pd
import torch
from torch import Tensor
from torch.nn import Linear, ReLU

from ax.core import Data, Arm, Trial, Runner, Experiment, Metric, Objective, SearchSpace, MultiObjective, \
    RangeParameter, ParameterType, MultiObjectiveOptimizationConfig, \
    ObjectiveThreshold
from ax.models.torch.botorch_modular.model import Surrogate
from ax.runners.synthetic import SyntheticRunner
from ax.modelbridge.modelbridge_utils import observed_hypervolume
from ax.modelbridge.torch import TorchModelBridge, ModelBridge
from ax.modelbridge.random import RandomModelBridge
from ax.modelbridge.registry import Models
from ax.modelbridge.factory import get_MOO_NEHVI, get_MOO_PAREGO

from ax.utils.common.result import Ok

from botorch.models.gpytorch import GPyTorchModel
from botorch.models.gp_regression import SingleTaskGP
from botorch.acquisition.multi_objective import qNoisyExpectedHypervolumeImprovement

from gpytorch.models import ExactGP, ApproximateGP
from gpytorch.variational import CholeskyVariationalDistribution, VariationalStrategy
from gpytorch.distributions import MultivariateNormal
from gpytorch.kernels import RBFKernel, ScaleKernel, GridInterpolationKernel
from gpytorch.means import ConstantMean
from gpytorch.likelihoods import GaussianLikelihood
from gpytorch.utils.grid import ScaleToBounds

from aps.common.reflection import get_class_full_name, instance_for_name, get_class_name_and_module
from aps.common.data_structures import DictionaryWrapper
from aps.beamline_driver.beam_management.beam_manager_factory import initialize_beam_manager_factory, \
    create_beam_manager
from aps.beamline_driver.motion_management.motion_manager_factory import initialize_motion_manager_factory, \
    create_motion_manager
from aps.ai.beamline_controller.legacy.agent.optimization.facade import OptimizationInitParameters, OptimizationCriteria
from aps.ai.beamline_controller.legacy.agent.facade import ERROR_LOSS
from aps.ai.beamline_controller.legacy.agent.optimization.optimizer_factory import initialize_optimizer_factory
from aps.ai.beamline_controller.legacy.agent.optimization.moo.bayesian.facade import BayesianOptimizationExecutionParameters, \
    BayesianOptimizationInputParameters, AcquisitionFunction, SelectionAlgorithm
from aps.ai.beamline_controller.legacy.agent.optimization.moo.bayesian.ax.mobo import \
    AxDirectBeamImageHypervolumeManager, AxWavefrontAnalysisHypervolumeManager
from aps.ai.beamline_controller.legacy.agent.optimization.moo.bayesian.ax.optimizer import AxOptimizer
from aps.ai.beamline_controller.legacy.agent.optimization.moo.bayesian.optuna.hypervolume_manager import \
    OptunaDirectBeamImageHypervolumeManager
from aps.ai.beamline_controller.legacy.agent.optimization.moo.bayesian.optuna import OptunaOptimizer
from aps.ai.beamline_controller.legacy.agent.optimization.soo.nonlinear.scipy import \
    ScipyDirectBeamImageHypervolumeManager, ScipyWavefrontAnalysisHypervolumeManager
from aps.ai.beamline_controller.legacy.agent.optimization.soo.nonlinear.scipy import ScipyOptimizer
from aps.ai.beamline_controller.legacy.agent.optimization.hypervolume_manager_factory import \
    initialize_hypervolume_manager_factory, create_hypervolume_manager
from aps.ai.beamlines.bl_8ID.digital_twin.optimized_optics_manager import S4Beamline8IDOptimizedOpticsManager

from extended_surrogate import SurrogateExtended, GPU_DEVICE

try:
    from epics import ca

    ca.finalize_libca()
except:
    pass


class OptimizationModeDeveloper:
    DEFAULT = 'default'
    TRAIN_DEFAULT_GP_ONLY = 'train_default_gp_only'
    TRAIN_CUSTOM_GP_ONLY = 'train_custom_gp_only'


class TrainingDataInfo:
    FIDELITY_HIGH = 'high'
    FIDELITY_MEDIUM = 'med'
    FIDELITY_LOW = 'low'
    RANK_HIGH = [0, 30000]
    RANK_MEDIUM = [30000, 60000]
    RANK_LOW = [60000, 90000]
    SIZE_10 = 10
    SIZE_20 = 20
    SIZE_50 = 50
    SIZE_100 = 100
    SIZE_1K = 1000
    SIZE_10K = 10000


class CustomRunner(Runner):
    def __init__(self, optimizer):
        super().__init__()
        self.optimizer = optimizer
        self.results_storage = {}

    def run(self, trial: Trial):
        print(f"\nRunning trial {trial.index}. Runner set: {trial.runner.__class__.__qualname__}")
        if not trial.runner and not self.manages_own_execution: raise ValueError(
            "This trial does not have a runner and cannot be run.")
        trial_id = trial.index
        suggested_motor_positions = {name: trial.arm.parameters[name] for name in trial.arm.parameters}
        results, error_message = self.optimizer.evaluate_suggested_motor_positions(suggested_motor_positions, trial_id)
        if error_message:
            print(f"\nTrial {trial_id} is marked abandoned due to error message:\n{error_message}")
            trial.mark_abandoned(reason=error_message)
        else:
            print(f"\nTrial {trial_id} SUCCESSFULly evaluated in CustomRunner\nResults stored:\n{results}")
            data_entries = []
            for criterion, value in results.items():
                data_entries.append({"arm_name": trial.arm.name,
                                     "metric_name": criterion,
                                     "mean": value,
                                     "sem": None,  # Assuming a constant SEM for simplicity
                                     "trial_index": trial_id})
            if data_entries:
                trial.experiment.attach_data(Data(df=pd.DataFrame(data_entries)))
            self.results_storage[trial_id] = results
        return trial


class S4_spherical_3_Metrics(Metric):
    def __init__(self, name, lower_is_better, results_storage):
        super().__init__(name, lower_is_better=lower_is_better)
        self.results_storage = results_storage

    def fetch_trial_data(self, trial: Trial):
        trial_id = trial.index
        if trial_id in self.results_storage:
            result = self.results_storage[trial_id].get(self.name, float('nan'))
            data = pd.DataFrame({"arm_name": [trial.arm.name],
                                 "metric_name": [self.name],
                                 "mean": [result],
                                 "sem": [0.000001],  # Assuming a constant SEM for simplicity
                                 "trial_index": [trial_id]})
            print(f"\nTrial {trial_id} exists\nMetric: {self.name}\nResult: {result}\nData: {data}")
            return Ok(Data(df=data))
        else:
            print(f"\nTrial {trial_id} does not exists\nMetric: {self.name}\nResult: none\nData: none")
            return Data(df=pd.DataFrame())


class LargeFeatureExtractor(torch.nn.Sequential):
    def __init__(self):
        super(LargeFeatureExtractor, self).__init__()
        self.add_module('linear1', Linear(8, 1000).float())
        self.add_module('relu1', ReLU())
        self.add_module('linear2', Linear(1000, 500).float())
        self.add_module('relu2', ReLU())
        self.add_module('linear3', Linear(500, 50).float())
        self.add_module('relu3', ReLU())
        self.add_module('linear4', Linear(50, 5).float())


class DKL_GP(ExactGP, GPyTorchModel):
    _num_outputs = 1  # to inform GPyTorchModel API

    def __init__(self, train_X, train_Y, train_Yvar: Optional[Tensor] = None):
        if GPU_DEVICE is not None:
            train_X = train_X.to(GPU_DEVICE).float()
            train_Y = train_Y.to(GPU_DEVICE).float()
            if train_Yvar is not None: train_Yvar = train_Yvar.to(GPU_DEVICE).float()
            self.gpu_device = GPU_DEVICE
            # print(f'In DKL_GP\ntrain_X={train_X.dtype} and train_Y={train_Y.dtype} are moved to {self.gpu_device}')
        else:
            self.gpu_device = torch.device('cpu')

        super().__init__(train_X, train_Y.squeeze(-1), GaussianLikelihood())
        self.mean_module  = ConstantMean().to(self.gpu_device).float()
        self.covar_module = GridInterpolationKernel(base_kernel = ScaleKernel(base_kernel = RBFKernel(ard_num_dims = 5)),
                                                    num_dims    = 5,
                                                    grid_size   = 100).to(self.gpu_device).float()
        self.feature_extractor = LargeFeatureExtractor().to(self.gpu_device)
        self.scale_to_bounds   = ScaleToBounds(-1., 1.)

    def forward(self, x):
        x           = x.to(self.gpu_device).float()
        projected_x = self.feature_extractor(x)
        projected_x = self.scale_to_bounds(projected_x)

        mean_x      = self.mean_module(projected_x)
        covar_x     = self.covar_module(projected_x)

        # print(f'x type: {x.dtype}')
        # print(f'projected_x type: {projected_x.dtype}')
        # print(f'mean_x type: {mean_x.dtype}')
        # print(f'covar_x type: {covar_x.dtype}')

        # print(f'mean_x of type {type(mean_x)} = {mean_x.shape} is on {mean_x.device}')
        # print(f'covar_x of type {type(covar_x)} = {covar_x.shape} is on {covar_x.device}')
        return MultivariateNormal(mean = mean_x, covariance_matrix = covar_x)


class SimpleCustomGP(ExactGP, GPyTorchModel):
    _num_outputs = 1  # to inform GPyTorchModel API

    def __init__(self, train_X, train_Y,
                 train_Yvar: Optional[Tensor] = None):  # This ignores train_Yvar and uses inferred noise instead.
        # squeeze output dim before passing train_Y to ExactGP
        super().__init__(train_X, train_Y.squeeze(-1), GaussianLikelihood())
        self.mean_module = ConstantMean()
        self.covar_module = ScaleKernel(base_kernel=RBFKernel(ard_num_dims=train_X.shape[-1]))
        self.to(train_X)  # make sure we're on the right device/dtype

    def forward(self, x):
        mean_x = self.mean_module(x)
        covar_x = self.covar_module(x)
        return MultivariateNormal(mean_x, covar_x)


class SVGP_custom(ApproximateGP, GPyTorchModel):
    def __init__(self):
        variational_distribution = CholeskyVariationalDistribution(torch.linspace(0, 1, 100).size(0))
        variational_strategy = VariationalStrategy(self, torch.linspace(0, 1, 100), variational_distribution,
                                                   learn_inducing_locations=True)
        super(SVGP_custom, self).__init__(variational_strategy)
        self.mean_module = ConstantMean()
        self.covar_module = ScaleKernel(RBFKernel())

    def forward(self, x):
        mean_x = self.mean_module(x)
        covar_x = self.covar_module(x)
        return MultivariateNormal(mean_x, covar_x)


class Ax_Developer_Optimizer:
    def __init__(self, input_parameters):
        self.config = configparser.ConfigParser()
        self.beam_manager = None
        self.motion_manager = None
        self.hypervolume_manager = None
        self.digital_twin_init_parameters = None
        self.exit_loss_function = {}
        self.use_exit_strategy = len(self.exit_loss_function.keys()) > 0
        self.acquisition_function_id = 0
        self.sobol_trials = input_parameters.get('sobol_trials', 6)
        self.bo_trials = input_parameters.get('bo_trials', 5)
        self.optimization_mode = input_parameters.get('optimization_mode', 'default')
        self.save_results_to_json = input_parameters.get('save_results_to_json', True)
        self.results_directory = os.path.join(os.path.abspath(os.getcwd()),
                                              input_parameters.get('json_results_directory', 'temp'))
        self.json_file_name = f"{input_parameters.get('json_file_name', 'temp')}.json"
        self.json_file_dir_name = None
        self.warm_start = input_parameters.get('warm_start', False)
        self.home_directory = None
        self.id = None
        self.training_data_info: dict = input_parameters.get('training_data_info', None)
        self.training_data_directory = input_parameters.get('training_data_directory', None)
        self.custom_gp_model = input_parameters.get('custom_gp_model', None)
        self.pre_trained_gp_model = input_parameters.get('pre_trained_gp_model', None)
        self.prior_data_location = input_parameters.get('prior_data_location', os.path.abspath(
            '/Users/runyu/Documents/workspace/AI-Driven-Optics-Controller/TEST_DIR/GUI/8-ID/DEFAULT/DEFAULT_DATA_FOR_TRAIN_10_SOBOL_40_MOO_21-07_15-05-2025.json'))
        self.optics_controller_ini_dir = input_parameters.get('optics_controller_ini_dir', None)
        self.trained_default_gp_model = None
        self.trained_custom_gp_model = None
        self.experiment = None
        self.loaded_json_data = None
        self.loaded_data_in_model = []
        self.selected_training_data = []
        self.models_implemented = []
        self.custom_acquisition_function = input_parameters.get('custom_acquisition_function', None)
        self.acquisition_function = get_MOO_NEHVI if self.acquisition_function_id == 0 else get_MOO_PAREGO
        self.execution_parameters: BayesianOptimizationExecutionParameters = None
        self.input_parameters: BayesianOptimizationInputParameters = None
        self.optimization_parameters: OptimizationInitParameters = None
        self._current_timestamps = {}
        self.selection_algorithm = SelectionAlgorithm.NASH_EQUILIBRIUM
        self.parameters_list = {}
        self.search_space = None
        self.motors_to_optimize = None
        self.beam_manager_args = input_parameters.get('beam_manager_args', {'beam_manager_type': 0,
                                                                            'nbins_h': 4001,
                                                                            'nbins_v': 4001,
                                                                            'xrange': [-100.0, 100.0],
                                                                            'yrange': [-100.0, 100.0]})
        self.hypervolume_manager_args = {'hypervolume_reference_points': {'peak-distance_spherical': 20.0,
                                                                          'sigma_spherical': 30.0,
                                                                          'negative-log-peak-intensity': -0.1},
                                         'optimization_criteria_reference_values': {'peak-distance_spherical': 0.0,
                                                                                    'sigma_spherical': 0.0,
                                                                                    'negative-log-peak-intensity': 0.0},
                                         'optimization_criteria_constraints': {},
                                         'optimization_criteria_weights': {'peak-distance_spherical': 1.0,
                                                                           'sigma_spherical': 1.0,
                                                                           'negative-log-peak-intensity': 1.0}}
        self.objectives = {'negative-log-peak-intensity': ['0.0', '-0.1', '1.0', '-2.6'],
                           'peak-distance_spherical': ['0.0', '20.0', '1.0', '0.1'],
                           'sigma_spherical': ['0.0', '30.0', '1.0', '0.25']}
        self.optimization_config = None
        self.ax_client = None
        self.ax_client_bom = None
        self.ax_client_bom_train = None
        self.dummy_ax_client = None
        self.fixed_seed = 1234
        self.results_list = []
        self.results_text = []
        self.optimization_criteria = OptimizationCriteria(list(self.objectives.keys()))  # create optimization criteria
        self.read_optics_controller_ini()
        self.initialize_factories()
        self.create_managers()
        self.create_search_space_and_optimization_config()  # create parameters search space

    def load_new_json_data(self, file_location, data_size, return_training_data_dict=True, get_sobol=True):
        if get_sobol is True:
            df_data_raw = (pd.read_json(os.path.abspath(file_location))).head(data_size)
            print(f'\n{data_size} SOBOL points are returned from file {file_location}\n')
        else:
            df_data_raw = (pd.read_json(os.path.abspath(file_location))).tail(data_size)
            print(f'\n{data_size} BO points are returned from file {file_location}\n')
        if return_training_data_dict:
            return (df_data_raw[list(self.motors_to_optimize)].to_dict(orient='records'),
                    df_data_raw[list(self.objectives.keys())].to_dict(orient='records'))
        self.loaded_json_data = df_data_raw
        return df_data_raw, df_data_raw

    def create_torch_model_bridge(self):
        # bo_model = TorchModelBridge(experiment          = self.experiment,
        #                             search_space        = self.search_space,
        #                             data                = self.experiment.fetch_data(),
        #                             model               = BotorchModel(),
        #                             surrogate           = self.custom_Surrogate(),
        #                             torch_dtype         = torch.double,  # or torch.float, depending on your precision needs
        #                             torch_device        = "cpu",         # or "cuda" if GPU is available and desired
        #                             optimization_config = self.optimization_config,
        #                             fit_on_init         = True)
        pass

    def custom_surrogate(self) -> Surrogate:
        try:
            print(f'\nCustomized Surrogate is returned\n')
            return SurrogateExtended(botorch_model_class = DKL_GP).to(GPU_DEVICE)
        except Exception as e:
            print(f'Error in custom_Surrogate(): {e}')

    def optimize_bom(self, with_SOBOL, customize_model):
        print(f'********************\nOptimization starts now in BoTorch Modular mode\nSobol = {self.sobol_trials if with_SOBOL else None} + BO = {self.bo_trials}\n******************')
        self.experiment = Experiment(name                = 'Ax_developer_BOM',
                                     search_space        = self.search_space,
                                     optimization_config = self.optimization_config,
                                     runner              = self.runner)
        if with_SOBOL:
            sobol_model = Models.SOBOL(search_space = self.experiment.search_space,
                                       seed         = self.fixed_seed)
            self.models_implemented.append(sobol_model)
            for _ in range(self.sobol_trials):
                print(f'\nNow in sobol No. {_}/{self.sobol_trials}')
                trial_        = self.experiment.new_trial(generator_run = sobol_model.gen(1))
                trial_.runner = self.runner
                trial_.run()  # This should automatically manage the state transition from 'candidate' to 'running'
                trial_.mark_completed()  # Mark the trial as completed after successful run
            self.show_model_info(model_bridge = sobol_model)
            nehvi_data = self.experiment.fetch_data()
            print(f'\nFetched data after SOBOL steps:\n{nehvi_data.df}')
        else:
            loaded_data_motors, loaded_data_losses = self.load_new_json_data(file_location             = self.prior_data_location,
                                                                             data_size                 = 100,
                                                                             return_training_data_dict = True,
                                                                             get_sobol                 = False)
            data_dictionary_list = []
            for i in range(len(loaded_data_motors)):
                current_data_dictionary = {'input': loaded_data_motors[i],
                                           'output': {criterion: {'mean': loaded_data_losses[i][criterion], 'sem': None}
                                                      for criterion in self.objectives.keys()}}
                data_dictionary_list.append(current_data_dictionary)
                # ---------------------------------------------------------------
                # Record the same information to self.results_dict
                current_result_dict = {'Trial_Number': i,
                                       'Loss_Sum': sum(loaded_data_losses[i].values()),
                                       **{key: value for key, value in loaded_data_losses[i].items()},
                                       **{key: value for key, value in loaded_data_motors[i].items()}}
                self.results_list.append(current_result_dict)
            print(f'Total {len(data_dictionary_list)} training data has been loaded to {self.__class__.__name__}')
            self.loaded_data_in_model = data_dictionary_list

            for i, data in enumerate(data_dictionary_list):
                arm_name = f'{i}_0'
                trial    = self.experiment.new_trial()

                # if isinstance(data['input'], dict):
                #     for key, value in data['input'].items():
                #         if not isinstance(value, torch.Tensor): value = torch.tensor(value)
                #         if gpu_device is not None             : value = value.to(gpu_device)
                #         data['input'][key] = value

                trial.add_arm(Arm(parameters=data['input'], name=arm_name))
                ax_data = Data(df=pd.DataFrame.from_records([{"arm_name"   : arm_name,
                                                              "metric_name": metric_name,
                                                              "mean"       : output['mean'],
                                                              "sem"        : None,  # Assuming a constant SEM for simplicity
                                                              "trial_index": i} for metric_name, output in data['output'].items()]))
                self.experiment.attach_data(data=ax_data)
                trial.runner = SyntheticRunner()
                trial.run().complete()
                print(f'Imported trial No.{i + 1}/{len(data_dictionary_list)} finished using dummy runner')

        nehvi_hv_list = []
        for i in range(self.bo_trials):
            print(f'\n*****************\nNOW IN BO STEP No. {i + 1}/{self.bo_trials}\n*******************')
            bo_model: ModelBridge = Models.BOTORCH_MODULAR(experiment   = self.experiment,
                                                           data         = self.experiment.fetch_data(),
                                                           torch_device = GPU_DEVICE,
                                                           surrogate    = Surrogate(botorch_model_class = SingleTaskGP,
                                                                                    likelihood_class    = GaussianLikelihood) if customize_model is False else self.custom_surrogate(),
                                                           botorch_acqf_class = qNoisyExpectedHypervolumeImprovement if self.custom_acquisition_function is None else self.custom_acquisition_function)
            self.models_implemented.append(bo_model)
            if i == 0: self.show_model_info(model_bridge = bo_model)
            trial        = self.experiment.new_trial(generator_run = bo_model.gen(1))
            trial.runner = self.runner
            trial.run()
            trial.mark_completed()
            try:
                hv = observed_hypervolume(modelbridge = bo_model)
            except Exception as e:
                hv = 0
                print(f'Failed to compute hyper volume {e}')
            nehvi_hv_list.append(hv)
            print(f"Iteration: {i}, HV: {hv}")

        if self.save_results_to_json is True:
            self.json_file_dir_name = os.path.join(self.results_directory, self.json_file_name)
            if not os.path.exists(self.results_directory): os.mkdir(self.results_directory)
            with open(self.json_file_dir_name, 'w') as file:
                json.dump(self.results_list, file)
            print(f'************\nOptimization finished.\nResults saved in {self.results_directory}')
        else:
            print(f'************\nOptimization finished.\nResults NOT requested to be saved.')

    def optimize_sobol_default(self):
        print(
            f'********************\nOptimization starts now in SOBOL Default mode\nSobol: {self.sobol_trials}+BO: {self.bo_trials}\n******************')
        self.experiment = Experiment(name ='Ax_developer_MOBO',
                                     search_space=self.search_space,
                                     optimization_config=self.optimization_config,
                                     runner=self.runner)
        sobol_model = Models.SOBOL(search_space=self.experiment.search_space,
                                   seed=self.fixed_seed)
        for _ in range(self.sobol_trials):
            print(f'\nNow in sobol No. {_}/{self.sobol_trials}')
            trial_ = self.experiment.new_trial(generator_run=sobol_model.gen(1))
            trial_.runner = self.runner
            trial_.run()  # This should automatically manage the state transition from 'candidate' to 'running'
            trial_.mark_completed()  # Mark the trial as completed after successful run

        nehvi_data = self.experiment.fetch_data()
        print(f'\nFetched data after SOBOL steps:\n{nehvi_data.df}')
        nehvi_hv_list = []

        for i in range(self.bo_trials):
            print(f'\n*******************\nNOW IN BO STEP No. {i}/{self.bo_trials}')
            bo_model = Models.MOO(experiment=self.experiment,
                                  data=nehvi_data)
            trial = self.experiment.new_trial(generator_run=bo_model.gen(1))
            trial.runner = self.runner
            trial.run()
            trial.mark_completed()
            nehvi_data = Data.from_multiple_data([nehvi_data, trial.fetch_data()])
            try:
                hv = observed_hypervolume(modelbridge=bo_model)
            except Exception as e:
                hv = 0
                print(f'Failed to compute hyper volume {e}')
            nehvi_hv_list.append(hv)
            print(f"Iteration: {i}, HV: {hv}")

        if self.save_results_to_json is True:
            self.json_file_dir_name = os.path.join(self.results_directory, self.json_file_name)
            if not os.path.exists(self.results_directory): os.mkdir(self.results_directory)
            with open(self.json_file_dir_name, 'w') as file:
                json.dump(self.results_list, file)
            print(f'************\nOptimization finished.\nResults saved in {self.results_directory}')
        else:
            print(f'************\nOptimization finished.\nResults NOT requested to be saved.')

    def create_search_space_and_optimization_config(self):
        self.optimization_parameters = self.hypervolume_manager.get_optimization_parameters(self.optimization_criteria,
                                                                                            self.input_parameters)
        if not self.input_parameters.is_partial_optimization: self.input_parameters.motors_to_optimize = self.motion_manager.get_motors_info().get_motor_ids()
        self.motors_to_optimize = self.input_parameters.motors_to_optimize
        prior_pareto_front_data = self.input_parameters.get_parameter('warm_start_data')

        parameters_list = []
        for motor_id in self.motors_to_optimize:
            bounds = self.motion_manager.get_motors_info().get_motor_info(motor_id).search_range
            parameters_list.append(RangeParameter(name=motor_id,
                                                  parameter_type=ParameterType.FLOAT,
                                                  lower=bounds[0],
                                                  upper=bounds[1]))
        self.parameters_list = parameters_list
        self.search_space = SearchSpace(parameters_list)

        metrics = []
        objective_thresholds = []
        results_storage = {}
        self.runner = CustomRunner(optimizer=self)
        print(f'\nRunner is initiated {self.runner}\n')

        for optimization_criterion in self.optimization_criteria.names:
            optimization_direction = self.optimization_parameters.get_parameter("optimization_directions")[
                optimization_criterion]
            if self.execution_parameters.do_warm_start and self.execution_parameters.use_warm_start_hypervolume_reference_points:
                pareto_front_hypervolume_reference_points = prior_pareto_front_data.get_warm_start_hypervolume_reference_points()
                pareto_front_hypervolume_reference_point = pareto_front_hypervolume_reference_points.get(
                    optimization_criterion,
                    self.optimization_parameters.get_parameter("hypervolume_reference_points")[optimization_criterion])
                if self.optimization_parameters.get_parameter('is_logarithmic')[optimization_criterion]:
                    hypervolume_reference_point = (
                                                          1.0 - self.execution_parameters.hypervolume_reference_points_coefficient) * pareto_front_hypervolume_reference_point
                else:
                    hypervolume_reference_point = (
                                                          1.0 + self.execution_parameters.hypervolume_reference_points_coefficient) * pareto_front_hypervolume_reference_point
            else:
                hypervolume_reference_point = \
                    self.optimization_parameters.get_parameter('hypervolume_reference_points')[optimization_criterion]
            new_metric = S4_spherical_3_Metrics(name=optimization_criterion,
                                                lower_is_better=True,
                                                results_storage=self.runner.results_storage)
            metrics.append(new_metric)
            objective_thresholds.append(ObjectiveThreshold(metric=new_metric,
                                                           bound=hypervolume_reference_point,
                                                           relative=False))
        self.optimization_config = MultiObjectiveOptimizationConfig(
            objective=MultiObjective(objectives=[Objective(metric=m) for m in metrics]),
            objective_thresholds=objective_thresholds)

    def show_model_info(self, model_bridge):
        message = []
        message.append(f'*************\nModel bridge name:  {model_bridge.__class__.__qualname__}')
        if isinstance(model_bridge, RandomModelBridge):
            message.append(f'Acquisition function: {"Sobol Random"}\n*************')
        elif isinstance(model_bridge, TorchModelBridge):
            botorch_model = model_bridge.model
            message.append(f"Model type          : {botorch_model.__class__.__qualname__}")
            message.append(f'BoTorch GP type     : {botorch_model.surrogate.botorch_model_class.__name__}')
            message.append(f'MLL module          : {botorch_model.surrogate.mll_class.__name__}')
            try:
                message.append(
                    f'Likelihood function : {botorch_model.surrogate.model.likelihood.__class__.__qualname__}')
            except Exception as e:
                message.append(f'Likelihood function : {e}')
            message.append(f"Acquisition function: {model_bridge.model.botorch_acqf_class.__name__}\n*************")
        else:
            message.append(f"BoTorch GP type     : {'Uknown, not Sobol nor BotorchModel'}\n************************")
        for line in message: print(line)

    def feedback(self, trial_index: int, suggested_motor_positions, motor_positions, current_loss, verbose, **kwargs):
        text = []
        total_loss = 0.0
        if not trial_index is None:
            text.append("Trial Number             : " + str(trial_index))
            text.append("Suggested Motor Positions: " + str(suggested_motor_positions))
            text.append("Actual Motor Positions   : " + str(motor_positions))
            text.append("Current Loss             : " + str(current_loss))
            if trial_index == 0:
                self.results_text.append('Trial Number   Current Loss   Sum of Losses')
            else:
                total_loss = sum(value for key, value in current_loss.items())
                formatted_result = f'{trial_index}    {current_loss}    {total_loss}'
                self.results_text.append(formatted_result)
        message = kwargs.get("message", None)
        if isinstance(message, str):
            text.append(message)
        elif isinstance(message, list):
            text.extend([line for line in message])
        if verbose is True:
            for line in text: print(line)
        # ---------------------------------------------------------------
        # Record the same information to self.results_dict
        current_result_dict = {'Trial_Number': trial_index,
                               'Loss_Sum': total_loss,
                               **{key: value for key, value in current_loss.items()},
                               **{key: value for key, value in suggested_motor_positions.items()}}
        self.results_list.append(current_result_dict)

    def plot_results(self, read_in_file=False, read_in_file_dir=None, save_images=True, plot_images=True):
        if (
                read_in_file is True and read_in_file_dir is None) or self.optimization_mode is OptimizationModeDeveloper.TRAIN_DEFAULT_GP_ONLY:
            print(f'Please provide read_in_file_dir')
            return
        elif read_in_file is True and read_in_file_dir is not None:
            data_df = pd.read_json(read_in_file_dir)
        else:
            data_df = pd.read_json(self.json_file_dir_name)
        criteria_rename = {'negative-log-peak-intensity': '-log(PI)',
                           'peak-distance_spherical': 'PL_sph (um)',
                           'sigma_spherical': 'Sigma_sph (um)',
                           'Loss_Sum': 'Loss_sum'}
        criteria_columns = [col for col in criteria_rename.keys()]
        criteria = data_df[criteria_columns]
        fig = plt.figure(figsize=(8, 6))  # create a combined figure
        for idx, criterion in enumerate(criteria):
            fig.add_subplot(len(criteria_columns), 1, idx + 1)
            fig.gca().scatter(data_df.index, data_df[criterion], marker='o')
            if idx == len(criteria_columns) - 1:
                fig.gca().set_xlabel("Iteration")
            fig.gca().set_ylabel(criteria_rename[criterion])
            if idx == 0:
                fig.gca().set_title("Objective Value vs. Iteration")
            fig.gca().grid(True)
        fig.subplots_adjust(hspace=0.2)
        if save_images:
            plt.tight_layout()
            fig.savefig(os.path.join(self.results_directory, f"{self.json_file_name}_opt_history.png"),
                        bbox_inches='tight', pad_inches=0.01)
        if plot_images: fig.show()

    def read_optics_controller_ini(self):  # /home/oxygen/B310691/Desktop/Source/AI-Driven-Optics-Controller/TEST_DIR/GUI/8-ID
        os.chdir(os.path.abspath(self.optics_controller_ini_dir))
        current_dir = os.getcwd()
        print(f'Current working directory: {current_dir}')
        print(os.path.join(current_dir, 'optics-controller.ini'))
        try:
            self.config.read(os.path.join(current_dir, '.optics-controller.ini'))
        except Exception as e:
            print(f'Error read the INI file: {e}')

    def initialize_factories(self):
        motion_manager_args = {}
        motion_manager_json_file = os.path.join(os.path.abspath(os.getcwd()), f"optical_system_8-ID_motion_manager.json")
        if os.path.exists(motion_manager_json_file): motion_manager_args["json_file"] = motion_manager_json_file
        beam_manager_json_file = os.path.join(os.path.abspath(os.getcwd()), f"optical_system_8-ID_beam_manager.json")
        if os.path.exists(beam_manager_json_file): self.beam_manager_args["json_file"] = beam_manager_json_file
        beam_profile_digital_twin_class, beam_profile_digital_twin_module = get_class_name_and_module(
            self.config.get("Initialization", "beam_profile_digital_twin"))
        wavefront_analysis_digital_twin_class, wavefront_analysis_digital_twin_module = get_class_name_and_module(
            self.config.get("Initialization", "wavefront_analysis_digital_twin"))
        self.digital_twin_args = {"motors_configuration_json_file": motion_manager_json_file}
        self.digital_twin_args.update(self.beam_manager_args)
        self.digital_twin_args.update(motion_manager_args)
        self.digital_twin_init_parameters = DictionaryWrapper(**self.digital_twin_args)
        self.beam_profile_digital_twin = instance_for_name(module_name=beam_profile_digital_twin_module,
                                                           class_name=beam_profile_digital_twin_class,
                                                           digital_twin_init_parameters=self.digital_twin_init_parameters)
        self.wavefront_analysis_digital_twin = instance_for_name(module_name=wavefront_analysis_digital_twin_module,
                                                                 class_name=wavefront_analysis_digital_twin_class,
                                                                 digital_twin_init_parameters=self.digital_twin_init_parameters)
        initialize_motion_manager_factory(classes={}, instances={'8-ID' + "-DT-BP": self.beam_profile_digital_twin,
                                                                 '8-ID' + "-DT-WA": self.wavefront_analysis_digital_twin})
        initialize_beam_manager_factory(classes={}, instances={'8-ID' + "-DT-BP": self.beam_profile_digital_twin,
                                                               '8-ID' + "-DT-WA": self.wavefront_analysis_digital_twin})
        initialize_hypervolume_manager_factory(
            classes={"Ax-BP": get_class_full_name(AxDirectBeamImageHypervolumeManager),
                     "Optuna-BP": get_class_full_name(OptunaDirectBeamImageHypervolumeManager),
                     "Scipy-BP": get_class_full_name(ScipyDirectBeamImageHypervolumeManager),
                     "Ax-WA": get_class_full_name(AxWavefrontAnalysisHypervolumeManager),
                     "Scipy-WA": get_class_full_name(ScipyWavefrontAnalysisHypervolumeManager)})
        initialize_optimizer_factory(classes={"Ax": get_class_full_name(AxOptimizer),
                                              "Optuna": get_class_full_name(OptunaOptimizer),
                                              "Scipy": get_class_full_name(ScipyOptimizer)})
        self.digital_twin = S4Beamline8IDOptimizedOpticsManager(
            digital_twin_init_parameters=self.digital_twin_init_parameters)

    def create_managers(self):
        beamline_id = '8-ID'
        platform = "BL" if self.digital_twin_init_parameters.get_parameter("platform") == 0 else "DT"
        beam_manager_type = "BP" if self.digital_twin_init_parameters.get_parameter("beam_manager_type") == 0 else "WA"
        self.home_directory = os.path.join(os.path.abspath(os.getcwd()),
                                           f"Ax-{platform}-{beam_manager_type}-cr{len(self.objectives.keys())}" + (
                                               "-ws" if self.warm_start else ""))
        self.id = beamline_id + "-" + platform + "-" + beam_manager_type
        self.motion_manager = create_motion_manager(motion_manager_id=self.id)
        self.beam_manager = create_beam_manager(beam_manager_id=self.id)
        self.hypervolume_manager = create_hypervolume_manager(hypervolume_manager_id='Ax-BP',
                                                              **self.hypervolume_manager_args)
        self.execution_parameters = BayesianOptimizationExecutionParameters(do_warm_start=False,
                                                                            home_directory=self.home_directory,
                                                                            use_exit_strategy=self.use_exit_strategy,
                                                                            exit_loss_function=self.exit_loss_function)
        self.input_parameters = BayesianOptimizationInputParameters(
            acquisition_function=AcquisitionFunction.QUASIMCBASED_NOISY_EXPECTED_HYPERVOLUME_IMPROVEMENT,
            sobol_trials=self.sobol_trials,
            bo_trials=self.bo_trials,
            motors_to_optimize=None,
            random_seed=int(time.time()))

    def check_motor_positions(self, suggested_motor_positions, current_motors_positions):
        motors_info = self.motion_manager.get_motors_info()
        for motor_id in suggested_motor_positions:
            if abs(suggested_motor_positions[motor_id] - current_motors_positions[
                motor_id]) > 10 * motors_info.get_motor_info(motor_id).resolution:
                return False, f"Motor {motor_id} is not correctly positioned (offset > 10*resolution)"
        return True, None

    def evaluate_suggested_motor_positions(self, suggested_motor_positions, trial_index):
        motors_to_optimize = [key for key in suggested_motor_positions.keys()]

        def manage_error(current_motors_positions, error_message):
            error_loss = self.hypervolume_manager.get_error_loss_function(self.optimization_criteria)
            self.feedback(trial_index=trial_index,
                          suggested_motor_positions=current_motors_positions,
                          motor_positions=motors_to_optimize,
                          current_loss=error_loss,
                          verbose=True)
            return error_loss, error_message

        try:
            self.motion_manager.move_motors(motor_positions=suggested_motor_positions)
            print(f'\nMotors moved\n')
            current_motors_positions = self.motion_manager.get_motor_positions(motor_ids=motors_to_optimize)
            motor_ok, error_message = self.check_motor_positions(suggested_motor_positions=suggested_motor_positions,
                                                                 current_motors_positions=current_motors_positions)
            if not motor_ok: return manage_error(current_motors_positions, error_message)
        except Exception as e:
            traceback.print_exc()
            return manage_error(None, "Unexpected error while setting motors: " + str(e))
        try:
            beam_properties = self.beam_manager.get_beam_properties(self.beam_manager.get_beam())
            if beam_properties.get_parameter('is_empty_beam'):
                return manage_error(current_motors_positions, 'Beam is empty')
            loss, error, message = self.hypervolume_manager.evaluate_loss_function(beam_properties,
                                                                                   self.optimization_criteria)
            if error > 0:
                return manage_error(current_motors_positions, message)
            else:
                self.feedback(trial_index, suggested_motor_positions, current_motors_positions, loss, verbose=True)
                return loss, None
        except Exception as e:
            traceback.print_exc()
            return manage_error(current_motors_positions, 'Unexpected error while analyzing the beam' + str(e))

    def evaluate_loss_function(self, beam_properties):
        loss_function = {}
        error = 0
        message = ''
        for optimization_criterion in self.optimization_criteria.names:
            try:
                current_loss = self.hypervolume_manager.evaluate_loss_function(beam_properties=beam_properties,
                                                                               optimization_criteria=self.optimization_criteria)
            except Exception as e:
                current_loss = ERROR_LOSS
                message += ("" if error == 0 else "\n") + str(traceback.format_exc())
                error = 1
            if current_loss == np.nan:
                current_loss = ERROR_LOSS
                message += ("" if error == 0 else "\n") + str(traceback.format_exc())
                error = 1
            loss_function[optimization_criterion] = current_loss
        return loss_function, error, message
