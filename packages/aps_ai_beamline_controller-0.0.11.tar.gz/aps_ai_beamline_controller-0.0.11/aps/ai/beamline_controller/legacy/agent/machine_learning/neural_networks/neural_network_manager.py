#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #

import os
from abc import abstractmethod

from aps.beamline_driver.beam_management.facade import IBeamManager, BeamProperties
from aps.beamline_driver.motion_management.facade import IMotionManager, Movement, MethodCallingType
from aps.ai.beamline_controller.legacy.agent.facade import IAgentListener
from aps.ai.beamline_controller.legacy.agent.machine_learning.neural_networks.facade import INeuralNetworkManager, INeuralNetwork, NeuralNetworkAlignementData

class NeuralNetworkManager(INeuralNetworkManager):
    def __init__(self, neural_network_listener: IAgentListener):
        self.__neural_network_listener = neural_network_listener
        self.__result_data       = None
        self.__beam_properties_out = None

    def initialize_driver(self,
                          beam_manager: IBeamManager,
                          motion_manager: IMotionManager):
        self._beam_manager        = beam_manager
        self._motion_manager      = motion_manager

        if self.requires_run_engine():
            setattr(self, "move_motors_to_target_properties", self.__move_motors_to_target_properties_generator)
            setattr(self, "_move_motors", self.__move_motors_generator)
            setattr(self, "_get_motors_positions", self.__get_motors_positions_generator)
        else:
            setattr(self, "move_motors_to_target_properties", self.__move_motors_to_target_properties)
            setattr(self, "_move_motors", self.__move_motors)
            setattr(self, "_get_motors_positions", self.__get_motors_positions)

    def requires_run_engine(self):
        return self._beam_manager.method_calling_type() == MethodCallingType.GENERATOR or \
               self._motion_manager.method_calling_type() == MethodCallingType.GENERATOR

    def initialize_neural_network(self, neural_network: INeuralNetwork, experiment_output_directory: str = os.path.abspath(os.curdir), **kwargs, ):
        self._neural_network              = neural_network
        self._experiment_output_directory = experiment_output_directory

    def get_neural_network(self): return self._neural_network

    def __move_motors_to_target_properties_generator(self, target_properties: dict, **kwargs):
        self.__result_data       = None
        self.__beam_properties_out = None

        motor_positions = self._neural_network.predict_motor_positions(target_properties=target_properties)

        yield from self._move_motors(motor_positions)
        actual_motor_positions = yield from self._get_motors_positions(list(motor_positions.keys()))

        if kwargs.get("compute_result", True):
            beam = yield from self._beam_manager.get_beam()
            beam_properties = self._beam_manager.get_beam_properties(beam=beam,
                                                                     show_beam=kwargs.get("show_beam", False),
                                                                     save_image=kwargs.get("save_image", False),
                                                                     directory_name=self._experiment_output_directory,
                                                                     trial_num=1,
                                                                     file_name="nn_beam_image.png")

            result_data = NeuralNetworkAlignementData(motor_positions=motor_positions,
                                                      beam_properties={target_property: beam_properties.get_parameter(target_property) for target_property in target_properties},
                                                      beam=beam)

            self.__result_data         = result_data
            self.__beam_properties_out = beam_properties

            self.__neural_network_listener.feedback(trial_index=1,
                                                    suggested_motor_positions=list(motor_positions.values()),
                                                    motors_to_optimize=list(motor_positions.keys()),
                                                    motor_positions=list(actual_motor_positions.values()),
                                                    current_loss=None,
                                                    message=f"NN prediction for target criteria: {target_properties}\n" + \
                                                            f"                                -> {result_data.beam_properties}")

    def __move_motors_to_target_properties(self, target_properties: dict, **kwargs):
        self.__result_data       = None
        self.__beam_properties_out = None

        motor_positions = self._neural_network.predict_motor_positions(target_properties=target_properties)

        self._move_motors(motor_positions)
        actual_motor_positions = self._get_motors_positions(list(motor_positions.keys()))

        if kwargs.get("compute_result", True):
            beam            = self._beam_manager.get_beam()
            beam_properties = self._beam_manager.get_beam_properties(beam=beam,
                                                                     show_beam=kwargs.get("show_beam", False),
                                                                     plt=kwargs.get("plt", None),
                                                                     save_image=kwargs.get("save_image", False),
                                                                     file_name=kwargs.get("file_name", "nn_beam_image.png"),
                                                                     directory_name=self._experiment_output_directory,
                                                                     trial_num=1)

            result_data = NeuralNetworkAlignementData(motor_positions=actual_motor_positions,
                                                      suggested_motor_positions=motor_positions,
                                                      beam_properties={target_property: beam_properties.get_parameter(target_property) for target_property in target_properties},
                                                      beam=beam)

            self.__result_data         = result_data
            self.__beam_properties_out = beam_properties

            self.__neural_network_listener.feedback(trial_index=1,
                                                    suggested_motor_positions=list(motor_positions.values()),
                                                    motors_to_optimize=list(motor_positions.keys()),
                                                    motor_positions=list(actual_motor_positions.values()),
                                                    current_loss=None,
                                                    message=f"NN prediction for target criteria: {target_properties}\n" + \
                                                            f"                                -> {result_data.beam_properties}")

    def get_alignement_result_data(self) -> (NeuralNetworkAlignementData, BeamProperties):
        return self.__result_data, self.__beam_properties_out

    def save_alignment_result(self):
        pass

    # -----------------------------------------------------------------------
    # BLUESKY DYNAMIC MANAGEMENT -> PRIVATE METHODS
    # -----------------------------------------------------------------------

    @abstractmethod
    def _move_motors(self, motor_positions): raise NotImplementedError("run initialize_driver first")
    @abstractmethod
    def _get_motors_positions(self, motor_ids): raise NotImplementedError("run initialize_driver first")

    def __move_motors(self, motor_positions):
        self._motion_manager.move_motors(motor_positions, Movement.ABSOLUTE)

    def __move_motors_generator(self, motor_positions):
        yield from self._motion_manager.move_motors(motor_positions, Movement.ABSOLUTE)

    def __get_motors_positions(self, motor_ids):
        return self._motion_manager.get_motor_positions(motor_ids)

    def __get_motors_positions_generator(self, motor_ids):
        motor_positions = yield from self._motion_manager.get_motor_positions(motor_ids)
        return motor_positions