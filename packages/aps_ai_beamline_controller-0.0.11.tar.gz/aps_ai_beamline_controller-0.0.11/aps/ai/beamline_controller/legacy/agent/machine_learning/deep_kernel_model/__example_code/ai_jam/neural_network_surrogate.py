#!/usr/bin/env python
# -*- coding: utf-8 -*-
# ----------------------------------------------------------------------- #
# Copyright (c) 2025, UChicago Argonne, LLC. All rights reserved.         #
#                                                                         #
# Copyright 2025. UChicago Argonne, LLC. This software was produced       #
# under U.S. Government contract DE-AC02-06CH11357 for Argonne National   #
# Laboratory (ANL), which is operated by UChicago Argonne, LLC for the    #
# U.S. Department of Energy. The U.S. Government has rights to use,       #
# reproduce, and distribute this software.  NEITHER THE GOVERNMENT NOR    #
# UChicago Argonne, LLC MAKES ANY WARRANTY, EXPRESS OR IMPLIED, OR        #
# ASSUMES ANY LIABILITY FOR THE USE OF THIS SOFTWARE.  If software is     #
# modified to produce derivative works, such modified software should     #
# be clearly marked, so as not to confuse it with the version available   #
# from ANL.                                                               #
#                                                                         #
# Additionally, redistribution and use in source and binary forms, with   #
# or without modification, are permitted provided that the following      #
# conditions are met:                                                     #
#                                                                         #
#     * Redistributions of source code must retain the above copyright    #
#       notice, this list of conditions and the following disclaimer.     #
#                                                                         #
#     * Redistributions in binary form must reproduce the above copyright #
#       notice, this list of conditions and the following disclaimer in   #
#       the documentation and/or other materials provided with the        #
#       distribution.                                                     #
#                                                                         #
#     * Neither the name of UChicago Argonne, LLC, Argonne National       #
#       Laboratory, ANL, the U.S. Government, nor the names of its        #
#       contributors may be used to endorse or promote products derived   #
#       from this software without specific prior written permission.     #
#                                                                         #
# THIS SOFTWARE IS PROVIDED BY UChicago Argonne, LLC AND CONTRIBUTORS     #
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT       #
# LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS       #
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL UChicago     #
# Argonne, LLC OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,        #
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,    #
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;        #
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER        #
# CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT      #
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN       #
# ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE         #
# POSSIBILITY OF SUCH DAMAGE.                                             #
# ----------------------------------------------------------------------- #

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim

from ax import Models
from ax.service.ax_client import AxClient
from ax.modelbridge.generation_strategy import GenerationStrategy, GenerationStep

# BotTorch imports for our custom model interface
from botorch.models.model import Model
from botorch.posteriors import GPyTorchPosterior
from torch.distributions.multivariate_normal import MultivariateNormal
from botorch.models.model_list_gp_regression import ModelListGP


###############################################################################
# 1. Define a Custom Neural Network Surrogate with Dropout for Uncertainty
###############################################################################
class NNSurrogate(nn.Module):
    def __init__(self, input_dim=2, hidden_dim=16, dropout_rate=0.1):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout_rate),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout_rate),
            nn.Linear(hidden_dim, 1)
        )

    def forward(self, x):
        return self.net(x)


###############################################################################
# 2. Define a Custom BoTorch Model That Wraps the NN Surrogate Using MC Dropout
###############################################################################
class CustomNNModel(Model):
    def __init__(self, net, num_samples=50):
        """
        net: a trained neural network (an instance of NNSurrogate)
        num_samples: number of stochastic forward passes for MC dropout
        """
        self.net = net
        self.num_samples = num_samples

    def posterior(self, X, **kwargs):
        # Ensure dropout is active for MC sampling.
        self.net.train()
        predictions = []
        for _ in range(self.num_samples):
            predictions.append(self.net(X).squeeze(-1))
        preds = torch.stack(predictions, dim=0)  # shape: (num_samples, n)
        mean = preds.mean(dim=0)
        var = preds.var(dim=0) + 1e-6  # add jitter for stability
        cov = torch.diag_embed(var)
        mvn = MultivariateNormal(mean, covariance_matrix=cov)
        return GPyTorchPosterior(mvn)


###############################################################################
# 3. Custom Model Builder for Multi-Objective NN Surrogates
###############################################################################
def custom_nn_model(experiment, data, **kwargs):
    """
    Build a multi-objective neural network surrogate model using dropout for uncertainty.
    This function extracts the data from Ax, trains one NN surrogate per objective,
    wraps each in a CustomNNModel, and returns a ModelListGP containing both models.
    """
    # Extract data from the Ax DataFrame.
    df = data.df
    X_list, Y_list = [], []
    for _, row in df.iterrows():
        # Parameters: x1 and x2.
        X_list.append([row["x1"], row["x2"]])
        # Assume objectives are ordered as ["branin", "distance"].
        Y_list.append([row["branin"], row["distance"]])
    X = torch.tensor(X_list, dtype=torch.float32)
    Y = torch.tensor(Y_list, dtype=torch.float32)

    models = []
    num_epochs = 200
    lr = 1e-3
    # Train one NN for each objective.
    for i in range(2):  # two objectives
        net = NNSurrogate(input_dim=2, hidden_dim=16, dropout_rate=0.1)
        optimizer = optim.Adam(net.parameters(), lr=lr)
        loss_fn = nn.MSELoss()
        y_target = Y[:, i:i + 1]
        for epoch in range(num_epochs):
            optimizer.zero_grad()
            pred = net(X)
            loss = loss_fn(pred, y_target)
            loss.backward()
            optimizer.step()
        # Wrap the trained net in our custom model.
        model = CustomNNModel(net, num_samples=50)
        models.append(model)

    # Combine models into a multi-objective model list.
    return ModelListGP(*models)


###############################################################################
# 4. Define the Multi-Objective Evaluation Function
###############################################################################
def multi_objective_evaluation(parameters):
    x1 = parameters["x1"]
    x2 = parameters["x2"]
    # Branin function: scale x1 from [0,1] -> [-5,10] and x2 from [0,1] -> [0,15]
    x1_scaled = 15 * x1 - 5
    x2_scaled = 15 * x2
    a = 1.0
    b = 5.1 / (4 * np.pi ** 2)
    c = 5 / np.pi
    r = 6.0
    s = 10.0
    t = 1 / (8 * np.pi)
    branin_val = a * (x2_scaled - b * x1_scaled ** 2 + c * x1_scaled - r) ** 2 + s * (1 - t) * np.cos(x1_scaled) + s
    # Squared Euclidean distance from the center (0.5, 0.5)
    distance_val = (x1 - 0.5) ** 2 + (x2 - 0.5) ** 2
    return {"branin": (branin_val, 0.0), "distance": (distance_val, 0.0)}


###############################################################################
# 5. Set Up the Ax Experiment and Generation Strategy Using Models.BOTORCH_MODULAR
###############################################################################
ax_client = AxClient(enforce_sequential_optimization=False)
ax_client.create_experiment(
    name="multiobj_nn_surrogate",
    parameters=[
        {"name": "x1", "type": "range", "bounds": [0.0, 1.0]},
        {"name": "x2", "type": "range", "bounds": [0.0, 1.0]},
    ],
    objective_name=["branin", "distance"],
    minimize=True,
    evaluation_function=multi_objective_evaluation,
)

# Define a generation strategy with two steps:
#  - Step 1: 5 Sobol trials.
#  - Step 2: BOTORCH_MODULAR using our custom NN model with qNEHVI acquisition.
gs = GenerationStrategy(steps=[
    GenerationStep(
        model=Models.SOBOL,
        num_trials=5,
        min_trials_observed=5,
        max_trials=5,
    ),
    GenerationStep(
        model=Models.BOTORCH_MODULAR,
        num_trials=-1,  # All remaining trials
        min_trials_observed=5,
        max_parallelism=1,
        model_kwargs={},  # No additional kwargs.
        model_gen_options={
            "custom_model": custom_nn_model,
            "acquisition_function": "qNEHVI",
            # Objective thresholds define the hypervolume reference point.
            "objective_thresholds": [6.0, 0.5],
        },
    ),
])
ax_client.set_generation_strategy(gs)

###############################################################################
# 6. Run Additional Optimization Trials
###############################################################################
for _ in range(10):
    parameters, trial_index = ax_client.get_next_trial()
    print(f"Trial {trial_index} parameters: {parameters}")
    ax_client.complete_trial(trial_index=trial_index, raw_data=multi_objective_evaluation(parameters))

###############################################################################
# 7. Retrieve and Display the Best (Pareto Optimal) Points
###############################################################################
best_points = ax_client.get_best_parameters(objective_weight=None, objective_thresholds=[6.0, 0.5])
print("Best (Pareto optimal) points:", best_points)
print(ax_client.experiment.fetch_data().df)
