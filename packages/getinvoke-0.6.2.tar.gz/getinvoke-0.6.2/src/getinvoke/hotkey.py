"""Global hotkey listener via pynput."""

import logging
import platform
from collections.abc import Callable

from pynput import keyboard, mouse

logger = logging.getLogger(__name__)

# Map config strings to pynput buttons
# mouse.Button.x1/x2 are Windows-only; use getattr to avoid crash on Linux/macOS
MOUSE_BUTTON_MAP = {
    "left": mouse.Button.left,
    "right": mouse.Button.right,
    "middle": mouse.Button.middle,
}
if getattr(mouse.Button, "x1", None):
    MOUSE_BUTTON_MAP["mouse4"] = mouse.Button.x1
if getattr(mouse.Button, "x2", None):
    MOUSE_BUTTON_MAP["mouse5"] = mouse.Button.x2

# On Linux/X11, side mouse buttons are button 8 (back) and 9 (forward)
if platform.system() == "Linux":
    try:
        MOUSE_BUTTON_MAP.setdefault("mouse4", mouse.Button(8))
        MOUSE_BUTTON_MAP.setdefault("mouse5", mouse.Button(9))
    except Exception:
        pass


# Modifier key names for formatting captured hotkeys
_MODIFIER_NAMES = {
    keyboard.Key.ctrl_l: "ctrl",
    keyboard.Key.ctrl_r: "ctrl",
    keyboard.Key.shift_l: "shift",
    keyboard.Key.shift_r: "shift",
    keyboard.Key.alt_l: "alt",
    keyboard.Key.alt_r: "alt",
    keyboard.Key.cmd_l: "cmd",
    keyboard.Key.cmd_r: "cmd",
}

# Canonical modifier order for display
_MODIFIER_ORDER = ["ctrl", "shift", "alt", "cmd", "super"]


def format_key_combo(keys: set) -> str:
    """Convert a set of pynput key objects to a hotkey string like 'ctrl+shift+d'."""
    modifiers = []
    regular = []
    for key in keys:
        if key in _MODIFIER_NAMES:
            mod = _MODIFIER_NAMES[key]
            if mod not in modifiers:
                modifiers.append(mod)
        elif isinstance(key, keyboard.Key):
            name = key.name.lower()
            if name in ("ctrl_l", "ctrl_r", "shift_l", "shift_r", "alt_l", "alt_r", "cmd_l", "cmd_r"):
                mod = name.rsplit("_", 1)[0]
                if mod not in modifiers:
                    modifiers.append(mod)
            else:
                regular.append(name)
        elif isinstance(key, keyboard.KeyCode) and key.char:
            regular.append(key.char.lower())
        elif isinstance(key, keyboard.KeyCode) and key.vk:
            regular.append(f"<{key.vk}>")

    # Sort modifiers in canonical order
    modifiers.sort(key=lambda m: _MODIFIER_ORDER.index(m) if m in _MODIFIER_ORDER else 99)
    return "+".join(modifiers + regular)


class HotkeyListener:
    """Listens for push-to-talk hotkey events."""

    def __init__(
        self,
        hotkey: str,
        on_press: Callable[[], None],
        on_release: Callable[[], None],
    ) -> None:
        self._hotkey = hotkey.lower()
        self._on_press = on_press
        self._on_release = on_release
        self._listener: mouse.Listener | keyboard.Listener | None = None
        self._pressed = False

    def start(self) -> None:
        """Start listening in a background thread."""
        if self._hotkey in MOUSE_BUTTON_MAP:
            self._start_mouse_listener()
        else:
            self._start_keyboard_listener()

    def stop(self) -> None:
        """Stop the listener."""
        if self._listener is not None:
            self._listener.stop()
            self._listener = None

    def _start_mouse_listener(self) -> None:
        target_button = MOUSE_BUTTON_MAP[self._hotkey]

        def on_click(x: int, y: int, button: mouse.Button, pressed: bool) -> None:
            try:
                if button != target_button:
                    return
            except (NotImplementedError, ValueError):
                # pynput can't convert some exotic mouse events on Windows
                return
            try:
                if pressed and not self._pressed:
                    self._pressed = True
                    logger.debug(f"Hotkey pressed: {self._hotkey}")
                    self._on_press()
                elif not pressed and self._pressed:
                    self._pressed = False
                    logger.debug(f"Hotkey released: {self._hotkey}")
                    self._on_release()
            except Exception:
                logger.error("Error in hotkey callback", exc_info=True)
                self._pressed = False

        self._listener = mouse.Listener(on_click=on_click)
        self._listener.daemon = True
        self._listener.start()
        logger.info(f"Mouse hotkey listener started: {self._hotkey}")

    def _start_keyboard_listener(self) -> None:
        # Parse keyboard combo (e.g. "ctrl+shift+d" -> "<ctrl>+<shift>+d")
        try:
            if "+" not in self._hotkey:
                hotkey_str = f"<{self._hotkey}>"
            else:
                # Wrap modifier keys in angle brackets for pynput
                parts = []
                for part in self._hotkey.split("+"):
                    p = part.strip()
                    if p in ("ctrl", "shift", "alt", "cmd", "super"):
                        parts.append(f"<{p}>")
                    else:
                        parts.append(p)
                hotkey_str = "+".join(parts)
            combo_keys = set(keyboard.HotKey.parse(hotkey_str))
        except ValueError:
            combo_keys = None

        if combo_keys is None:
            logger.error(f"Could not parse keyboard hotkey: {self._hotkey}")
            return

        # Track which combo keys are currently held — bypass pynput HotKey
        # state machine which adds 1-2s latency on Linux
        held_keys: set = set()

        def on_key_press(key: keyboard.Key | keyboard.KeyCode) -> None:
            canonical = self._listener.canonical(key)
            if canonical in combo_keys:
                held_keys.add(canonical)
            # Fire immediately when all combo keys are held
            if not self._pressed and held_keys >= combo_keys:
                self._pressed = True
                logger.debug(f"Hotkey pressed: {self._hotkey}")
                try:
                    self._on_press()
                except Exception:
                    logger.error("Error in hotkey press callback", exc_info=True)
                    self._pressed = False

        def on_key_release(key: keyboard.Key | keyboard.KeyCode) -> None:
            canonical = self._listener.canonical(key)
            if canonical in combo_keys:
                held_keys.discard(canonical)
            # Release when any combo key is lifted while recording
            if self._pressed and not (held_keys >= combo_keys):
                self._pressed = False
                logger.debug(f"Hotkey released: {self._hotkey}")
                try:
                    self._on_release()
                except Exception:
                    logger.error("Error in hotkey release callback", exc_info=True)

        self._listener = keyboard.Listener(on_press=on_key_press, on_release=on_key_release)
        self._listener.daemon = True
        self._listener.start()
        logger.info(f"Keyboard hotkey listener started: {self._hotkey}")
