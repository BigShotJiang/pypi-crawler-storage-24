"""Patina theme — shared UI styling for tkinter windows."""

# --- Color palette (matches PC RGB / terminal theme) ---
BG = "#0D1B1E"  # Deep dark — window backgrounds
SURFACE = "#1A3035"  # Dark teal — entries, buttons, panels
BORDER = "#2a3a3e"  # Subtle border
TEAL = "#3D9DAA"  # Mid teal — selected tabs, hover
TEAL_BRIGHT = "#5FC8C8"  # Bright teal — accents, checked indicators
GOLD = "#D4943A"  # Gold — primary action buttons, cursor
GOLD_BRIGHT = "#E8A840"  # Bright gold — hover on primary buttons
TEXT = "#D4D4CC"  # Warm white — main text
TEXT_DIM = "#7a8a8e"  # Teal-tinted muted text
ERROR = "#E67E80"  # Muted coral — errors only
SUCCESS = "#22c55e"  # Green — success states


def apply_theme(root) -> None:
    """Apply the Patina color scheme to a tkinter root window.

    Call this after creating the tk.Tk/Toplevel. Sets up all ttk styles
    and configures the window background.
    """
    from tkinter import ttk

    root.configure(bg=BG)

    style = ttk.Style(root)
    style.theme_use("clam")

    # --- Layout containers ---
    style.configure("TFrame", background=BG)
    style.configure("TLabelframe", background=BG, foreground=TEXT)
    style.configure("TLabelframe.Label", background=BG, foreground=TEXT)

    # --- Labels ---
    style.configure("TLabel", background=BG, foreground=TEXT, font=("Segoe UI", 10))
    style.configure("Title.TLabel", font=("Segoe UI", 16, "bold"), foreground="#ffffff")
    style.configure("Sub.TLabel", font=("Segoe UI", 10), foreground=TEXT_DIM)
    style.configure("Accent.TLabel", foreground=TEAL_BRIGHT)
    style.configure("Error.TLabel", foreground=ERROR)
    style.configure("Success.TLabel", foreground=SUCCESS)
    style.configure("Green.TLabel", foreground=SUCCESS)
    style.configure("Warn.TLabel", foreground=GOLD)
    style.configure("Link.TLabel", foreground=TEAL_BRIGHT, cursor="hand2")

    # --- Notebook (tabs) ---
    style.configure("TNotebook", background=BG, borderwidth=0)
    style.configure(
        "TNotebook.Tab",
        background=SURFACE,
        foreground=TEXT_DIM,
        font=("Segoe UI", 9),
        padding=(16, 6),
    )
    style.map(
        "TNotebook.Tab",
        background=[("selected", TEAL)],
        foreground=[("selected", "#ffffff")],
        expand=[("selected", (0, 0, 0, 0))],  # Prevent clam theme from shrinking selected tab
    )

    # --- Buttons ---
    style.configure("TButton", background=SURFACE, foreground=TEXT, font=("Segoe UI", 10))
    style.map(
        "TButton",
        background=[("active", TEAL), ("pressed", TEAL)],
        foreground=[("active", "#ffffff"), ("pressed", "#ffffff")],
    )

    # Primary action button (Save, Activate, Next)
    style.configure("Gold.TButton", background=GOLD, foreground=BG, font=("Segoe UI", 10, "bold"))
    style.map(
        "Gold.TButton",
        background=[("active", GOLD_BRIGHT), ("pressed", GOLD_BRIGHT)],
        foreground=[("active", BG), ("pressed", BG)],
    )

    # --- Checkbuttons ---
    style.configure(
        "TCheckbutton",
        background=BG,
        foreground=TEXT,
        font=("Segoe UI", 10),
        indicatorbackground="#ffffff",
        indicatorforeground=BG,
        indicatormargin=4,
    )
    style.map(
        "TCheckbutton",
        background=[("active", BG)],
        foreground=[("active", TEXT)],
        indicatorbackground=[
            ("selected", TEAL_BRIGHT),
            ("selected active", TEAL_BRIGHT),
            ("active", "#ffffff"),
            ("!selected", "#ffffff"),
        ],
    )

    # --- Radiobuttons ---
    style.configure("TRadiobutton", background=BG, foreground=TEXT, font=("Segoe UI", 10))
    style.map(
        "TRadiobutton",
        background=[("active", BG)],
        foreground=[("active", TEXT)],
        indicatorbackground=[
            ("selected", TEAL_BRIGHT),
            ("selected active", TEAL_BRIGHT),
            ("active", "#ffffff"),
            ("!selected", "#ffffff"),
        ],
    )

    # --- Entries — dark fields with gold cursor ---
    style.configure("TEntry", fieldbackground=SURFACE, foreground=TEXT, insertcolor=GOLD, borderwidth=1)

    # --- Comboboxes — dark dropdown fields ---
    style.configure(
        "TCombobox",
        fieldbackground=SURFACE,
        foreground=TEXT,
        selectbackground=TEAL,
        selectforeground="#ffffff",
        font=("Segoe UI", 10),
    )
    style.map("TCombobox", fieldbackground=[("readonly", SURFACE)])

    # --- Separators ---
    style.configure("TSeparator", background=BORDER)
