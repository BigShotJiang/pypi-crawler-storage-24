"""Cross-platform clipboard access."""

import logging
import time

import pyperclip

logger = logging.getLogger(__name__)


def copy(text: str) -> bool:
    """Copy text to system clipboard. Returns True on success."""
    try:
        pyperclip.copy(text)
        logger.info(f"Copied {len(text)} chars to clipboard")
        return True
    except pyperclip.PyperclipException as e:
        logger.error(f"Clipboard error: {e}")
        return False


def paste() -> bool:
    """Simulate Ctrl+V to paste clipboard contents at cursor. Returns True on success."""
    import platform

    # Small delay to ensure clipboard is ready and hotkey is fully released
    time.sleep(0.05)

    if platform.system() != "Windows":
        # On Linux, pynput keyboard simulation is unreliable (needs X11/xdotool).
        # Use xdotool directly if available.
        try:
            import subprocess

            subprocess.run(["xdotool", "key", "ctrl+v"], timeout=2, check=True)
            logger.info("Auto-pasted via xdotool")
            return True
        except FileNotFoundError:
            logger.warning("Auto-paste needs xdotool on Linux: sudo apt install xdotool")
            return False
        except Exception as e:
            logger.error(f"Auto-paste error (xdotool): {e}")
            return False

    try:
        from pynput.keyboard import Controller, Key

        kb = Controller()
        kb.press(Key.ctrl)
        kb.press("v")
        kb.release("v")
        kb.release(Key.ctrl)
        logger.info("Auto-pasted via Ctrl+V")
        return True
    except Exception as e:
        logger.error(f"Auto-paste error: {e}")
        return False
