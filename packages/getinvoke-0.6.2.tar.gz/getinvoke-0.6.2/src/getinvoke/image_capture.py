"""Clipboard image capture — grabs image from Windows clipboard via PowerShell, saves as PNG."""

import logging
import os
import subprocess
from datetime import datetime, timedelta
from pathlib import Path

from getinvoke.config import settings

logger = logging.getLogger(__name__)


def capture_clipboard_image() -> str | None:
    """Grab image from Windows clipboard, save as PNG, return WSL file path.

    Uses PowerShell to access the Windows clipboard directly — WSLg clipboard
    bridging is unreliable. Returns None if no image is in the clipboard.
    """
    save_dir = Path(os.path.expanduser(settings.IMAGE_SAVE_DIR))
    save_dir.mkdir(parents=True, exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"clip_{timestamp}.png"
    filepath = save_dir / filename

    # Convert WSL path to Windows path for PowerShell
    try:
        win_path = subprocess.run(
            ["wslpath", "-w", str(filepath)],
            capture_output=True,
            text=True,
            timeout=5,
        ).stdout.strip()
    except FileNotFoundError:
        # Not running under WSL — try native Windows path
        win_path = str(filepath)
    except Exception as e:
        logger.error(f"Failed to convert path: {e}")
        return None

    if not win_path:
        logger.error("Empty Windows path from wslpath")
        return None

    # PowerShell: grab clipboard image, save as PNG
    ps_script = (
        "Add-Type -AssemblyName System.Windows.Forms;"
        "$img = [System.Windows.Forms.Clipboard]::GetImage();"
        "if ($img) {"
        f"  $img.Save('{win_path}', [System.Drawing.Imaging.ImageFormat]::Png);"
        "  Write-Output 'saved'"
        "} else {"
        "  Write-Output 'no_image'"
        "}"
    )

    # CREATE_NO_WINDOW prevents the PowerShell console from flashing
    creationflags = subprocess.CREATE_NO_WINDOW if hasattr(subprocess, "CREATE_NO_WINDOW") else 0

    try:
        result = subprocess.run(
            ["powershell.exe", "-NoProfile", "-NonInteractive", "-Command", ps_script],
            capture_output=True,
            text=True,
            timeout=10,
            creationflags=creationflags,
        )
    except FileNotFoundError:
        logger.error("powershell.exe not found — image capture requires Windows/WSL2")
        return None
    except subprocess.TimeoutExpired:
        logger.error("PowerShell timed out during image capture")
        return None
    except Exception as e:
        logger.error(f"Image capture error: {e}")
        return None

    output = result.stdout.strip().replace("\r", "")
    if output == "saved" and filepath.exists():
        logger.info(f"Image saved: {filepath} ({filepath.stat().st_size / 1024:.0f} KB)")
        return str(filepath)

    if output == "no_image":
        logger.debug("No image in clipboard")
    else:
        logger.warning(f"Unexpected PowerShell output: {output}")
        if result.stderr.strip():
            logger.warning(f"PowerShell stderr: {result.stderr.strip()}")

    return None


def cleanup_old_images(save_dir: str | None = None, retention_days: int | None = None) -> int:
    """Delete images older than retention_days from save_dir. Returns count deleted."""
    dir_path = Path(os.path.expanduser(save_dir or settings.IMAGE_SAVE_DIR))
    days = retention_days if retention_days is not None else settings.IMAGE_RETENTION_DAYS

    if not dir_path.exists() or days <= 0:
        return 0

    cutoff = datetime.now() - timedelta(days=days)
    deleted = 0

    try:
        for f in dir_path.glob("clip_*.png"):
            try:
                if datetime.fromtimestamp(f.stat().st_mtime) < cutoff:
                    f.unlink()
                    deleted += 1
            except OSError:
                pass
    except Exception as e:
        logger.warning(f"Image cleanup error: {e}")

    if deleted:
        logger.info(f"Cleaned up {deleted} old screenshot(s) from {dir_path}")
    return deleted
