"""License management — Lemon Squeezy integration with 7-day trial."""

from __future__ import annotations

import hashlib
import hmac
import json
import logging
import platform
import subprocess
import uuid
from datetime import datetime
from enum import Enum

import httpx

from getinvoke.config import settings

logger = logging.getLogger(__name__)

# Lemon Squeezy identifiers
STORE_ID = 314146
PRODUCT_ID_INVOKE = 887386
PRODUCT_ID_INVOKE_PLUS = 887402
PRODUCT_IDS = {PRODUCT_ID_INVOKE, PRODUCT_ID_INVOKE_PLUS}

TRIAL_DAYS = 7
GRACE_DAYS = 30

# Obfuscated salt for HMAC key derivation (not stored as a plain string)
_K = b"\x49\x6e\x76\x30\x6b\x33\x2d\x4c\x53\x2d\x38\x38\x37\x33\x38\x36"
VALIDATE_INTERVAL_DAYS = 7
UPDATE_ELIGIBILITY_DAYS = 365  # Invoke tier: 1 year of updates

_ACTIVATE_URL = "https://api.lemonsqueezy.com/v1/licenses/activate"
_VALIDATE_URL = "https://api.lemonsqueezy.com/v1/licenses/validate"
_DEACTIVATE_URL = "https://api.lemonsqueezy.com/v1/licenses/deactivate"


def _get_machine_id() -> str:
    """Get a stable machine identifier for HMAC signing.

    Windows: MachineGuid from registry.
    Linux/macOS: /etc/machine-id or fallback to uuid.getnode() (MAC address).
    """
    if platform.system() == "Windows":
        try:
            result = subprocess.run(
                ["reg", "query", r"HKLM\SOFTWARE\Microsoft\Cryptography", "/v", "MachineGuid"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            for line in result.stdout.splitlines():
                if "MachineGuid" in line:
                    return line.split()[-1]
        except Exception:
            pass
    else:
        from pathlib import Path

        for p in ("/etc/machine-id", "/var/lib/dbus/machine-id"):
            try:
                mid = Path(p).read_text().strip()
                if mid:
                    return mid
            except OSError:
                pass
    # Fallback: MAC-based UUID (stable per machine)
    return str(uuid.getnode())


def _compute_hmac(data: dict) -> str:
    """Compute HMAC-SHA256 of license data using machine-derived key."""
    machine_id = _get_machine_id()
    key = hashlib.sha256(_K + f"invoke-license-{machine_id}".encode()).digest()
    # Sign a canonical representation of the data fields (excluding the signature itself)
    signable = {k: v for k, v in sorted(data.items()) if k != "_sig"}
    payload = json.dumps(signable, sort_keys=True, separators=(",", ":"))
    return hmac.new(key, payload.encode(), hashlib.sha256).hexdigest()


def _verify_hmac(data: dict) -> bool:
    """Verify the HMAC signature on license data."""
    stored_sig = data.get("_sig")
    if not stored_sig:
        return False  # No signature = tampered or very old file, reject
    return hmac.compare_digest(stored_sig, _compute_hmac(data))


class LicenseStatus(Enum):
    TRIAL = "trial"
    ACTIVE = "active"
    EXPIRED_TRIAL = "expired_trial"
    INVALID = "invalid"
    GRACE = "grace"


class LicenseManager:
    """Manages license state via local cache + Lemon Squeezy API."""

    def __init__(self) -> None:
        self._license_file = settings.config_dir / "license.json"
        self._data: dict = {}
        self._status = LicenseStatus.TRIAL
        self._load()

    @property
    def status(self) -> LicenseStatus:
        return self._status

    @property
    def trial_days_left(self) -> int:
        started = self._data.get("trial_started")
        if not started:
            return 0
        start_dt = datetime.fromisoformat(started)
        elapsed = (datetime.now() - start_dt).days
        return max(0, TRIAL_DAYS - elapsed)

    @property
    def customer_email(self) -> str:
        return self._data.get("customer_email", "")

    @property
    def license_key(self) -> str:
        return self._data.get("license_key", "")

    @property
    def tier(self) -> str:
        """Return 'invoke_plus', 'invoke', or 'trial' based on stored product_id."""
        pid = self._data.get("product_id")
        if pid == PRODUCT_ID_INVOKE_PLUS:
            return "invoke_plus"
        if pid == PRODUCT_ID_INVOKE:
            return "invoke"
        return "trial"

    @property
    def updates_eligible(self) -> bool:
        """Check if the user is eligible for updates.

        - Trial/grace: always eligible (they need updates to evaluate)
        - Invoke+: lifetime updates
        - Invoke: 1 year from activation date
        """
        if self._status in (LicenseStatus.TRIAL, LicenseStatus.GRACE):
            return True
        if self._status != LicenseStatus.ACTIVE:
            return False
        if self.tier == "invoke_plus":
            return True
        # Invoke tier: 1 year from activation
        activated_at = self._data.get("activated_at")
        if not activated_at:
            return True  # No activation date = legacy, allow updates
        activated_dt = datetime.fromisoformat(activated_at)
        days_since = (datetime.now() - activated_dt).days
        return days_since <= UPDATE_ELIGIBILITY_DAYS

    def _load(self) -> None:
        """Load license data from disk and verify integrity."""
        if self._license_file.exists():
            try:
                self._data = json.loads(self._license_file.read_text(encoding="utf-8"))
                if not _verify_hmac(self._data):
                    logger.warning("License file integrity check failed — file may have been tampered with")
                    self._data = {}
            except (json.JSONDecodeError, OSError) as e:
                logger.warning(f"Failed to load license.json: {e}")
                self._data = {}

    def _save(self) -> None:
        """Persist license data to disk with HMAC signature."""
        # Remove old signature before computing new one
        self._data.pop("_sig", None)
        self._data["_sig"] = _compute_hmac(self._data)

        self._license_file.parent.mkdir(parents=True, exist_ok=True)
        content = json.dumps(self._data, indent=2)
        self._license_file.write_text(content, encoding="utf-8")

        # Restrict file permissions on Unix
        if platform.system() != "Windows":
            import os
            import stat

            os.chmod(self._license_file, stat.S_IRUSR | stat.S_IWUSR)

    def check(self) -> LicenseStatus:
        """Check license status. Called on startup."""
        # No license file → start trial
        if not self._data:
            self._data = {"trial_started": datetime.now().isoformat(), "status": "trial"}
            self._save()
            self._status = LicenseStatus.TRIAL
            logger.info(f"Trial started — {TRIAL_DAYS} days")
            return self._status

        status = self._data.get("status", "trial")

        # Active license — check if re-validation needed
        if status == "active":
            # Require instance_id — proves this license was actually activated via server
            if not self._data.get("instance_id"):
                logger.warning("Active license missing instance_id — re-activation required")
                self._status = LicenseStatus.INVALID
                return self._status

            last_validated = self._data.get("last_validated")
            if last_validated:
                last_dt = datetime.fromisoformat(last_validated)
                days_since = (datetime.now() - last_dt).days

                if days_since >= VALIDATE_INTERVAL_DAYS:
                    # Try to re-validate
                    if self._validate_online():
                        self._status = LicenseStatus.ACTIVE
                    elif days_since <= GRACE_DAYS:
                        self._status = LicenseStatus.GRACE
                        logger.warning(f"Offline validation — grace period ({GRACE_DAYS - days_since} days left)")
                    else:
                        self._status = LicenseStatus.INVALID
                        logger.warning("Grace period expired — license re-validation required")
                else:
                    self._status = LicenseStatus.ACTIVE
            else:
                self._status = LicenseStatus.ACTIVE
            return self._status

        # Trial — check if expired
        if status == "trial":
            if self.trial_days_left > 0:
                self._status = LicenseStatus.TRIAL
                logger.info(f"Trial active — {self.trial_days_left} days left")
            else:
                self._status = LicenseStatus.EXPIRED_TRIAL
                logger.info("Trial expired")
            return self._status

        # Anything else is invalid
        self._status = LicenseStatus.INVALID
        return self._status

    def activate(self, license_key: str) -> tuple[bool, str]:
        """Activate a license key. Returns (success, message)."""
        instance_name = platform.node() or "Invoke"

        try:
            response = httpx.post(
                _ACTIVATE_URL,
                data={"license_key": license_key, "instance_name": instance_name},
                headers={"Accept": "application/json"},
                timeout=15.0,
            )
            data = response.json()
        except httpx.TimeoutException:
            return False, "Connection timed out. Check your internet connection."
        except httpx.ConnectError:
            return False, "Could not connect to license server. Check your internet connection."
        except Exception as e:
            logger.error(f"Activation error: {e}")
            return False, f"Activation error: {e}"

        if not data.get("activated"):
            error = data.get("error", "Unknown error")
            return False, f"Activation failed: {error}"

        # Verify store/product match
        meta = data.get("meta", {})
        if STORE_ID and meta.get("store_id") != STORE_ID:
            return False, "This license key is not valid for Invoke."
        if PRODUCT_IDS and meta.get("product_id") not in PRODUCT_IDS:
            return False, "This license key is for a different product."

        # Save activation
        instance = data.get("instance", {})
        license_info = data.get("license_key", {})
        self._data = {
            "license_key": license_key,
            "instance_id": instance.get("id", ""),
            "product_id": meta.get("product_id"),
            "status": "active",
            "customer_email": meta.get("customer_email", ""),
            "activated_at": datetime.now().isoformat(),
            "last_validated": datetime.now().isoformat(),
            "trial_started": self._data.get("trial_started", ""),
            "expires_at": license_info.get("expires_at", ""),
        }
        self._save()
        self._status = LicenseStatus.ACTIVE
        logger.info(f"License activated for {self._data['customer_email']}")
        return True, "License activated successfully!"

    def deactivate(self) -> tuple[bool, str]:
        """Deactivate the current license on this machine."""
        license_key = self._data.get("license_key")
        instance_id = self._data.get("instance_id")

        if not license_key or not instance_id:
            return False, "No active license to deactivate."

        try:
            response = httpx.post(
                _DEACTIVATE_URL,
                data={"license_key": license_key, "instance_id": instance_id},
                headers={"Accept": "application/json"},
                timeout=15.0,
            )
            data = response.json()
            if data.get("deactivated"):
                logger.info("License deactivated")
            else:
                logger.warning(f"Deactivation response: {data}")
        except Exception as e:
            logger.warning(f"Deactivation API error (continuing anyway): {e}")

        # Reset to expired trial state
        self._data = {
            "trial_started": self._data.get("trial_started", datetime.now().isoformat()),
            "status": "trial",
        }
        self._save()
        self._status = LicenseStatus.EXPIRED_TRIAL
        return True, "License deactivated."

    def _validate_online(self) -> bool:
        """Re-validate license with Lemon Squeezy. Returns True if valid."""
        license_key = self._data.get("license_key")
        instance_id = self._data.get("instance_id")

        if not license_key or not instance_id:
            return False

        try:
            response = httpx.post(
                _VALIDATE_URL,
                data={"license_key": license_key, "instance_id": instance_id},
                headers={"Accept": "application/json"},
                timeout=15.0,
            )
            data = response.json()
        except Exception as e:
            logger.warning(f"Online validation failed: {e}")
            return False

        if data.get("valid"):
            self._data["last_validated"] = datetime.now().isoformat()
            self._data["status"] = "active"
            self._save()
            logger.info("License re-validated successfully")
            return True

        logger.warning(f"License validation returned invalid: {data.get('error')}")
        return False
