"""Workflow tree widget for the Ralphception dashboard."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from textual.widgets import Tree


@dataclass(frozen=True, slots=True)
class WorkflowTreeEntry:
    """A single workflow node rendered in the dashboard tree."""

    node_id: str
    parent_id: str | None
    label: str
    status: str


class WorkflowTreeWidget(Tree[WorkflowTreeEntry]):
    """Tree view of the current workflow structure."""

    def __init__(self, *args, **kwargs) -> None:
        super().__init__("Workflow", *args, **kwargs)
        self.show_root = True

    def load_entries(
        self,
        entries: list[WorkflowTreeEntry],
        *,
        selected_node_id: str | None = None,
    ) -> None:
        """Replace tree contents with the supplied workflow snapshot."""
        if not entries:
            self.root.set_label("Workflow")
            self.root.data = None
            return

        root_entry = entries[0]
        self.clear()
        self.root.set_label(_label(root_entry))
        self.root.data = root_entry
        self.root.expand()

        tree_nodes: dict[str, Any] = {root_entry.node_id: self.root}
        for entry in entries[1:]:
            parent = tree_nodes.get(entry.parent_id or root_entry.node_id, self.root)
            tree_nodes[entry.node_id] = parent.add(_label(entry), data=entry)

        if selected_node_id and selected_node_id in tree_nodes:
            self.select_node(tree_nodes[selected_node_id])


def _label(entry: WorkflowTreeEntry) -> str:
    return f"{entry.label} [{entry.status}]"
