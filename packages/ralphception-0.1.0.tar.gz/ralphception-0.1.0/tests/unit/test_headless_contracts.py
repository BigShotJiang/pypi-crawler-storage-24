from __future__ import annotations

import json
from pathlib import Path

from ralphception.headless import _load_plan_contract


def test_load_plan_contract_ignores_placeholder_verification_commands(tmp_path: Path) -> None:
    repo_root = tmp_path / "repo"
    plans_dir = repo_root / ".ralphception" / "plans"
    plans_dir.mkdir(parents=True)
    contract_path = plans_dir / "mission-plan.json"
    contract_path.write_text(
        json.dumps(
            {
                "execution_goal": "Find a bug",
                "verification_commands": [
                    "uv run pytest tests/unit/test_runtime_supervisor.py -q",
                    "uv run pytest <targeted test file or test node> -q",
                    "uv run pytest <updated targeted tests> -q",
                ],
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )

    contract = _load_plan_contract(contract_path, default_goal="fallback goal")

    assert contract.execution_goal == "Find a bug"
    assert contract.verification_commands == [
        "uv run pytest tests/unit/test_runtime_supervisor.py -q",
    ]


def test_load_plan_contract_parses_todos_commit_intents_and_execution_policy(tmp_path: Path) -> None:
    repo_root = tmp_path / "repo"
    plans_dir = repo_root / ".ralphception" / "plans"
    plans_dir.mkdir(parents=True)
    contract_path = plans_dir / "mission-plan.json"
    contract_path.write_text(
        json.dumps(
            {
                "execution_goal": "Implement the parser artifact.",
                "verification_commands": ['uv run pytest tests/unit/test_runtime_supervisor.py -q'],
                "todos": [
                    {
                        "todo_id": "todo-1",
                        "title": "Implement parser artifact",
                        "dependency_ids": [],
                        "status": "ready",
                        "commit_intent_id": "intent-1",
                        "scope_hints": ["src/parser.py"],
                    }
                ],
                "commit_intents": [
                    {
                        "intent_id": "intent-1",
                        "message": "feat: add parser artifact",
                        "todo_ids": ["todo-1"],
                        "ordering_after": [],
                    }
                ],
                "execution_policy": {
                    "max_parallel_children": 3,
                    "batch_by_scope": True,
                    "allow_commit_split": True,
                },
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )

    contract = _load_plan_contract(contract_path, default_goal="fallback goal")

    assert [todo.todo_id for todo in contract.todos] == ["todo-1"]
    assert [intent.intent_id for intent in contract.commit_intents] == ["intent-1"]
    assert contract.execution_policy.max_parallel_children == 3
