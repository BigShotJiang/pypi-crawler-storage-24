from __future__ import annotations

from types import SimpleNamespace

from ralphception.runtime.supervisor import RuntimeSupervisor
from ralphception.ui.app import RalphceptionDashboardApp
from ralphception.ui.widgets.workflow_tree import WorkflowTreeEntry


class _StubController:
    def __init__(self, *, selected_node_id: str | None) -> None:
        self.selected_node_id = selected_node_id
        self.selected: list[str] = []

    def select_node(self, node_id: str) -> None:
        self.selected.append(node_id)
        self.selected_node_id = node_id


def test_tree_selection_does_not_refresh_when_node_is_already_selected() -> None:
    controller = _StubController(selected_node_id="run:run-root")
    app = RalphceptionDashboardApp(controller)  # type: ignore[arg-type]
    refresh_calls: list[str] = []
    app._refresh_view = lambda **kwargs: refresh_calls.append("refresh")  # type: ignore[method-assign]
    entry = WorkflowTreeEntry(
        node_id="run:run-root",
        parent_id=None,
        label="run-root",
        status="pending",
    )
    event = SimpleNamespace(node=SimpleNamespace(data=entry))

    app.on_tree_node_selected(event)  # type: ignore[arg-type]

    assert controller.selected == []
    assert refresh_calls == []


def test_tree_selection_refreshes_when_user_picks_a_different_node() -> None:
    controller = _StubController(selected_node_id="run:run-root")
    app = RalphceptionDashboardApp(controller)  # type: ignore[arg-type]
    refresh_calls: list[str] = []
    app._refresh_view = lambda **kwargs: refresh_calls.append("refresh")  # type: ignore[method-assign]
    entry = WorkflowTreeEntry(
        node_id="stage:spec",
        parent_id="run:run-root",
        label="spec stage",
        status="pending",
    )
    event = SimpleNamespace(node=SimpleNamespace(data=entry))

    app.on_tree_node_selected(event)  # type: ignore[arg-type]

    assert controller.selected == ["stage:spec"]
    assert refresh_calls == ["refresh"]


def test_dashboard_app_keeps_shared_supervisor_reference(tmp_path) -> None:
    controller = _StubController(selected_node_id="run:run-root")
    supervisor = RuntimeSupervisor(repo_root=tmp_path)

    app = RalphceptionDashboardApp(controller, supervisor=supervisor)  # type: ignore[arg-type]

    assert app.supervisor is supervisor
