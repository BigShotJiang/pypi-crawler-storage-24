"""Retrieve API Routes"""
from datetime import datetime, timedelta, timezone
from uuid import uuid4
from fastapi import APIRouter, Depends, Header
from sqlalchemy.ext.asyncio import AsyncSession
from normbase.db.connection import get_db
from normbase.models.norm import NormUsageToken
from normbase.models.schemas import (
    NormRetrieveRequest,
    NormRetrieveResponse,
    NormResponse,
)
from normbase.services.retrieval import RetrievalService

router = APIRouter(prefix="/retrieve", tags=["retrieve"])
_retrieval_service: RetrievalService | None = None


def _utc_now() -> datetime:
    return datetime.now(timezone.utc).replace(tzinfo=None)


def _get_retrieval_service() -> RetrievalService:
    global _retrieval_service
    if _retrieval_service is None:
        _retrieval_service = RetrievalService()
    return _retrieval_service


def prewarm_retrieval_service() -> None:
    """Eagerly build RetrievalService to avoid first-request cold start."""
    _get_retrieval_service()


@router.post("", response_model=NormRetrieveResponse)
async def retrieve_norms(
    request: NormRetrieveRequest,
    db: AsyncSession = Depends(get_db),
    x_agent_id: str | None = Header(default=None),
    x_key_id: str | None = Header(default=None),
):
    """Retrieve applicable norms for a given context"""
    
    retrieval_service = _get_retrieval_service()
    
    # Perform retrieval
    results, cache_hit = await retrieval_service.retrieve(
        db=db,
        context=request.context,
        agent_role=request.agent_role,
        tag_filters=request.tag_filters,
        field_ids=request.field_ids,
        top_k=request.top_k
    )
    
    # Extract norms and scores
    norms = []
    scores = []
    for norm, score in results:
        norms.append(NormResponse.model_validate(norm))
        scores.append(score)
    
    usage_token = f"ut-{uuid4()}"
    token_row = NormUsageToken(
        usage_token=usage_token,
        norm_ids=[str(item.id) for item in norms],
        reported_norm_ids=[],
        agent_id=(x_agent_id or "").strip() or None,
        key_id=(x_key_id or "").strip() or None,
        expires_at=_utc_now() + timedelta(hours=24),
    )
    db.add(token_row)
    await db.commit()

    return NormRetrieveResponse(
        norms=norms,
        scores=scores,
        total=len(norms),
        usage_token=usage_token,
        cache_hit=cache_hit,
    )
