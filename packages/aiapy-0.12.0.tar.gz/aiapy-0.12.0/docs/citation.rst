.. include:: ../aiapy/CITATION.rst
