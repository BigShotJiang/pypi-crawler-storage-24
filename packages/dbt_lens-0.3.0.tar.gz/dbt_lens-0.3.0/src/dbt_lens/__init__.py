"""dbt-lens: CLI tool for navigating and understanding dbt projects."""

__version__ = "0.3.0"
