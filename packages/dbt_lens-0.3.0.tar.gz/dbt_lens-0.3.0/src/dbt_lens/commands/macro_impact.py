from __future__ import annotations

import click

from dbt_lens.cli import Context, cli, pass_context
from dbt_lens.core.macro_graph import macro_impact
from dbt_lens.output.json_output import output_json
from dbt_lens.output.terminal import render_macro_impact


@cli.command("macro-impact")
@click.argument("macro")
@click.option("--tests/--no-tests", default=False, help="Show/hide test nodes")
@pass_context
def macro_impact_cmd(ctx: Context, macro: str, tests: bool) -> None:
    """Show which models depend on a macro, including transitive dependencies."""
    try:
        result = macro_impact(ctx.graph, macro, include_tests=tests)
    except KeyError as e:
        raise click.ClickException(str(e))

    if ctx.format == "json":
        output_json(
            {
                "target_macro": result.target_macro,
                "macro_chain": result.macro_chain,
                "affected_models": [
                    {"unique_id": m.unique_id, "name": m.name, "layer": m.layer} for m in result.affected_models
                ],
                "by_layer": result.by_layer,
                "total_affected": len(result.affected_models),
            }
        )
        return

    render_macro_impact(result)
