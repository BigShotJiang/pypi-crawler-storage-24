from __future__ import annotations

from pathlib import Path

import click

from dbt_lens.cli import Context, cli, pass_context
from dbt_lens.core.git import get_git_changes, normalize_git_paths
from dbt_lens.core.graph import downstream
from dbt_lens.core.macro_graph import macro_impact
from dbt_lens.output.json_output import output_json
from dbt_lens.output.terminal import render_diff


@cli.command()
@click.option("--base", default="main", help="Base branch for comparison (default: main)")
@pass_context
def diff(ctx: Context, base: str) -> None:
    """Git-aware impact analysis — shows blast radius of current changes."""
    graph = ctx.graph

    try:
        changes = get_git_changes(base)
    except ValueError as e:
        raise click.ClickException(str(e))

    all_files = list(dict.fromkeys(changes.committed + changes.staged + changes.unstaged + changes.untracked))

    if not all_files:
        if ctx.format == "json":
            output_json(
                {
                    "base": base,
                    "modified_files": [],
                    "new_files": [],
                    "blast_radius": [],
                    "total_affected": 0,
                    "selector": "",
                }
            )
        else:
            click.echo("No modified files detected.")
        return

    # Get manifest path from parent click context
    manifest_path = Path("target/manifest.json")
    parent_ctx = click.get_current_context().parent
    if parent_ctx and parent_ctx.params.get("manifest"):
        manifest_path = Path(parent_ctx.params["manifest"]).resolve()

    normalized = normalize_git_paths(all_files, changes.git_root, manifest_path)

    # Build file path -> node/macro lookup
    path_to_node: dict[str, str] = {}
    for uid, node in graph.nodes.items():
        if node.original_file_path:
            path_to_node[node.original_file_path] = uid
    path_to_macro: dict[str, str] = {}
    for uid, macro in graph.macros.items():
        if macro.original_file_path:
            path_to_macro[macro.original_file_path] = uid

    changed_models: list[str] = []
    changed_macros: list[str] = []
    new_files: list[str] = []

    for path in normalized:
        if path in path_to_node:
            changed_models.append(path_to_node[path])
        elif path in path_to_macro:
            changed_macros.append(path_to_macro[path])
        else:
            new_files.append(path)

    blast_radius = []
    all_affected_model_ids: set[str] = set()

    # Model changes -> downstream
    selector_models: list[str] = []
    for uid in changed_models:
        node = graph.nodes[uid]
        if node.resource_type == "test":
            continue
        ds = downstream(graph, uid, include_tests=True)
        model_count = len([n for n in ds if n.resource_type == "model"])
        test_count = len([n for n in ds if n.resource_type == "test"])
        blast_radius.append(
            {
                "changed_node": uid,
                "type": "model",
                "downstream_models": model_count,
                "downstream_tests": test_count,
            }
        )
        all_affected_model_ids.add(uid)
        for n in ds:
            if n.resource_type == "model":
                all_affected_model_ids.add(n.unique_id)
        if node.resource_type == "model":
            selector_models.append(node.name)

    # Macro changes -> macro impact
    for uid in changed_macros:
        try:
            result = macro_impact(graph, uid)
            blast_radius.append(
                {
                    "changed_node": uid,
                    "type": "macro",
                    "affected_models": len(result.affected_models),
                }
            )
            for m in result.affected_models:
                all_affected_model_ids.add(m.unique_id)
                selector_models.append(m.name)
        except KeyError:
            pass

    selector_models = list(dict.fromkeys(selector_models))
    selector = ""
    if selector_models:
        selector = "dbt build -s " + " ".join(f"{name}+" for name in selector_models)

    data = {
        "base": base,
        "modified_files": [f for f in normalized if f not in new_files],
        "new_files": new_files,
        "blast_radius": blast_radius,
        "total_affected": len(all_affected_model_ids),
        "selector": selector,
    }

    if ctx.format == "json":
        output_json(data)
        return

    render_diff(data)
