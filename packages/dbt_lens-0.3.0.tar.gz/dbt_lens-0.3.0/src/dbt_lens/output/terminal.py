from __future__ import annotations

from collections.abc import Callable

from rich.console import Console
from rich.tree import Tree

from dbt_lens.core.column_lineage import ColumnTrace, ColumnTraceNode, ModelSummary
from dbt_lens.core.macro_graph import MacroImpactResult
from dbt_lens.core.manifest import DbtNode, ProjectGraph

console = Console()


def render_dependency_tree(
    graph: ProjectGraph,
    start_node: DbtNode,
    children_fn: Callable[[str], list[str]],
    include_tests: bool = True,
    max_depth: int | None = None,
) -> Tree:
    label = _node_label(graph, start_node)
    tree = Tree(label)
    _build_tree(graph, start_node.unique_id, tree, children_fn, include_tests, max_depth, depth=0, visited=set())
    return tree


def _build_tree(
    graph: ProjectGraph,
    node_id: str,
    tree: Tree,
    children_fn: Callable[[str], list[str]],
    include_tests: bool,
    max_depth: int | None,
    depth: int,
    visited: set[str],
) -> None:
    if max_depth is not None and depth >= max_depth:
        return

    visited.add(node_id)
    neighbors = children_fn(node_id)

    for neighbor_id in neighbors:
        node = graph.nodes.get(neighbor_id)
        if node is None:
            continue
        if not include_tests and node.resource_type == "test":
            continue

        if neighbor_id in visited:
            tree.add(f"[dim]{node.name} (see above)[/dim]")
            continue

        label = _node_label(graph, node)
        branch = tree.add(label)
        _build_tree(graph, neighbor_id, branch, children_fn, include_tests, max_depth, depth + 1, visited)


def _node_label(graph: ProjectGraph, node: DbtNode) -> str:
    if node.resource_type == "source":
        source_name = node.fqn[-2] if len(node.fqn) >= 2 else "unknown"
        return f"[cyan]\\[source] {source_name}.{node.name}[/cyan]"
    if node.resource_type == "seed":
        return f"[green]\\[seed] {node.name}[/green]"
    if node.resource_type == "test":
        return f"[yellow]\\[test] {node.name}[/yellow]"

    test_count = len(graph.tests_for_node(node.unique_id))
    test_suffix = f" [dim]← {test_count} tests[/dim]" if test_count > 0 else ""
    mat = node.materialization
    layer = node.layer
    return f"{node.name} [dim]({layer} | {mat})[/dim]{test_suffix}"


def render_summary_line(model_count: int, test_count: int, max_depth: int) -> str:
    return (
        f"\n [bold]{model_count}[/bold] models affected"
        f" │ [bold]{test_count}[/bold] tests"
        f" │ [bold]{max_depth}[/bold] layers deep"
    )


def render_search_results(results: list, result_type: str | None = None) -> None:
    if not results:
        console.print("[dim]No results found.[/dim]")
        return

    grouped: dict[str, list] = {}
    for r in results:
        grouped.setdefault(r.result_type, []).append(r)

    for rtype, items in grouped.items():
        if result_type and rtype != result_type:
            continue
        console.print(f"\n [bold]{rtype.title()}s:[/bold]")
        for item in items:
            console.print(f"  {item.name} [dim](score: {item.score})[/dim] — {item.path}")


def render_health_report(report: dict) -> None:
    console.print()

    console.print(" [bold]Model Coverage[/bold]")
    cov = report["coverage"]
    console.print(f"  Models with 0 tests:     {cov['untested']}/{cov['total']} ({cov['untested_pct']:.1f}%)")
    console.print(f"  Models with 0 docs:      {cov['undocumented']}/{cov['total']} ({cov['undocumented_pct']:.1f}%)")
    console.print(f"  Undocumented columns:    {cov['undocumented_columns']}")

    console.print("\n [bold]Size Warnings[/bold]")
    sizes = report["sizes"]
    console.print(f"  Models > 500 lines:      {sizes['over_500']}")
    console.print(f"  Models > {sizes['threshold']} lines:      {sizes['over_threshold']}")
    if sizes.get("largest"):
        console.print(f"  Largest: {sizes['largest']['name']} ({sizes['largest']['lines']} lines)")

    console.print("\n [bold]Macro Usage[/bold]")
    macros = report["macros"]
    if macros.get("most_used"):
        name, count = macros["most_used"]["name"], macros["most_used"]["count"]
        console.print(f"  Most-used macro:         {name} ({count} models)")
    console.print(f"  Unused macros:           {macros['unused_count']}")

    console.print("\n [bold]Source Freshness[/bold]")
    fresh = report["freshness"]
    console.print(f"  Sources without freshness config: {fresh['no_freshness']}/{fresh['total']}")

    console.print("\n [bold]Layer Summary[/bold]")
    layers = report["layers"]
    parts = [f"{layer}: {count}" for layer, count in sorted(layers.items())]
    console.print(f"  {' │ '.join(parts)}")
    console.print()


def render_column_trace(trace: ColumnTrace) -> None:
    """Render column trace as indented arrow chain."""
    target_node_name = trace.target_model.split(".")[-1]
    console.print(f"\n[bold]{target_node_name}.{trace.target_column}[/bold]")
    _render_trace_node(trace.root, depth=1)

    if trace.warnings:
        console.print()
        for w in trace.warnings:
            console.print(f"[yellow]  {w}[/yellow]")
    console.print()


def _render_trace_node(node: ColumnTraceNode, depth: int) -> None:
    """Recursively render trace nodes."""
    indent = "  " * depth
    model_short = node.model.split(".")[-1]
    inferred_tag = " [dim](inferred via SELECT *)[/dim]" if node.inferred else ""

    if node.is_source:
        console.print(f"{indent}[cyan]<- {model_short}.{node.column}[/cyan]{inferred_tag}")
        return

    if depth > 0:
        console.print(f"{indent}<- {model_short}.{node.expression}{inferred_tag}")

    for child in node.children:
        _render_trace_node(child, depth + 1)


def render_explain(summary: ModelSummary) -> None:
    """Render model summary as a Rich panel."""
    from rich.panel import Panel

    lines = []
    header = (
        f"[bold]{summary.name}[/bold] "
        f"[dim]({summary.layer} | {summary.materialization} "
        f"| {summary.line_count} lines — raw_code)[/dim]"
    )
    lines.append(header)
    lines.append("")
    lines.append(f" [bold]Sources:[/bold] {', '.join(summary.sources) if summary.sources else 'none'}")

    if summary.joins:
        join_strs = [f"{j.join_type} JOIN {j.target}" for j in summary.joins]
        lines.append(f" [bold]Joins:[/bold] {len(summary.joins)} ({', '.join(join_strs)})")
    else:
        lines.append(" [bold]Joins:[/bold] none")

    if summary.filters:
        lines.append(f" [bold]Filters:[/bold] {'; '.join(summary.filters)}")
    else:
        lines.append(" [bold]Filters:[/bold] none")

    if summary.macros:
        lines.append(f" [bold]Macros:[/bold] {', '.join(summary.macros)}")

    lines.append(f" [bold]Aggregations:[/bold] {summary.aggregations}")
    lines.append(f" [bold]Output columns:[/bold] {summary.output_columns}")

    if summary.partition_by or summary.cluster_by:
        parts = []
        if summary.partition_by:
            parts.append(f"Partition: {summary.partition_by}")
        if summary.cluster_by:
            parts.append(f"Cluster: {', '.join(summary.cluster_by)}")
        lines.append(f" [bold]Config:[/bold] {' | '.join(parts)}")

    if summary.tests:
        lines.append(f" [bold]Tests:[/bold] {', '.join(summary.tests)}")

    console.print()
    console.print(Panel("\n".join(lines), expand=False))
    console.print()


def render_diff(data: dict) -> None:
    console.print()
    console.print(" [bold]Modified files[/bold]" + (f" (vs {data['base']}):" if data.get("base") else ":"))
    for f in data.get("modified_files", []):
        console.print(f"  {f}")

    new_files = data.get("new_files", [])
    if new_files:
        console.print()
        console.print(" [yellow]New files not in manifest (run 'dbt compile' to include):[/yellow]")
        for f in new_files:
            console.print(f"  [yellow]{f}[/yellow]")

    blast = data.get("blast_radius", [])
    if blast:
        console.print()
        console.print(" [bold]Blast radius:[/bold]")
        for item in blast:
            name = item["changed_node"].split(".")[-1]
            if item["type"] == "model":
                ds_models = item["downstream_models"]
                ds_tests = item["downstream_tests"]
                console.print(f"  {name} → {ds_models} downstream models, {ds_tests} tests")
            elif item["type"] == "macro":
                console.print(f"  {name} → {item['affected_models']} models using this macro")

    console.print()
    console.print(f" [bold]Total:[/bold] {data.get('total_affected', 0)} unique models affected")

    selector = data.get("selector", "")
    if selector:
        console.print()
        console.print(" [bold]Suggested selector:[/bold]")
        console.print(f"  {selector}")
    console.print()


def render_macro_impact(result: MacroImpactResult) -> None:
    console.print()
    console.print(" [bold]Macro chain:[/bold]")
    target_name = result.target_macro.split(".")[-1]
    console.print(f"  {target_name}")
    other_macros = [m for m in result.macro_chain if m != result.target_macro]
    if other_macros:
        for m in other_macros:
            name = m.split(".")[-1]
            console.print(f"  └── {name} (depends on {target_name})")
    else:
        console.print("  └── [dim](no other macros depend on this)[/dim]")

    total = len(result.affected_models)
    console.print()
    console.print(f" [bold]Models using this chain (direct + transitive):[/bold] {total}")
    if result.by_layer:
        for layer, count in sorted(result.by_layer.items()):
            console.print(f"  {layer}:{' ' * max(1, 14 - len(layer))}{count}")
    console.print()
