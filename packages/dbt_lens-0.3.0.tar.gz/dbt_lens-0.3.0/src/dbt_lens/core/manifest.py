from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class DbtNode:
    unique_id: str
    name: str
    resource_type: str
    package_name: str
    fqn: list[str]
    description: str
    columns: dict[str, dict]
    tags: list[str]
    meta: dict
    config: dict
    depends_on_macros: list[str]
    depends_on_nodes: list[str]
    raw_code: str
    compiled_code: str | None
    original_file_path: str
    path: str
    database: str = ""
    schema_: str = ""
    freshness: dict | None = None

    @property
    def layer(self) -> str:
        if self.resource_type != "model" or len(self.fqn) < 2:
            return self.resource_type
        return self.fqn[1]

    @property
    def materialization(self) -> str:
        return str(self.config.get("materialized", "unknown"))

    @property
    def raw_code_lines(self) -> int:
        if not self.raw_code:
            return 0
        return len(self.raw_code.strip().splitlines())

    @property
    def source_key(self) -> str:
        if self.resource_type != "source" or len(self.fqn) < 2:
            return ""
        return f"{self.fqn[-2]}.{self.name}"


@dataclass
class DbtMacro:
    unique_id: str
    name: str
    package_name: str
    depends_on_macros: list[str]
    description: str
    original_file_path: str


@dataclass
class ProjectGraph:
    project_name: str
    adapter_type: str
    nodes: dict[str, DbtNode]
    macros: dict[str, DbtMacro]
    parent_map: dict[str, list[str]]
    child_map: dict[str, list[str]]

    _name_to_ids: dict[str, list[str]] = field(default_factory=dict, repr=False)
    _source_lookup: dict[str, str] = field(default_factory=dict, repr=False)
    _macro_name_to_ids: dict[str, list[str]] = field(default_factory=dict, repr=False)

    def __post_init__(self) -> None:
        self._build_indexes()

    def _build_indexes(self) -> None:
        for uid, node in self.nodes.items():
            self._name_to_ids.setdefault(node.name, []).append(uid)
            if node.resource_type == "source":
                self._source_lookup[node.source_key] = uid
        for uid, macro in self.macros.items():
            self._macro_name_to_ids.setdefault(macro.name, []).append(uid)

    def resolve_node(self, identifier: str) -> DbtNode:
        if identifier.startswith("source:"):
            source_key = identifier[len("source:") :]
            uid = self._source_lookup.get(source_key)
            if uid is None:
                raise KeyError(f"Source '{source_key}' not found.")
            return self.nodes[uid]

        if identifier in self.nodes:
            return self.nodes[identifier]

        candidates = self._name_to_ids.get(identifier, [])
        if len(candidates) == 1:
            return self.nodes[candidates[0]]
        if len(candidates) > 1:
            local = [c for c in candidates if self.nodes[c].package_name == self.project_name]
            if len(local) == 1:
                return self.nodes[local[0]]
            ids_str = ", ".join(candidates)
            raise KeyError(f"Multiple models match '{identifier}'. Use the full unique_id: {ids_str}")

        all_names = list(self._name_to_ids.keys())
        try:
            from rapidfuzz import fuzz, process

            matches = process.extract(identifier, all_names, scorer=fuzz.WRatio, limit=3)
            suggestions = [m[0] for m in matches if m[1] > 50]
        except ImportError:
            suggestions = []
        if suggestions:
            raise KeyError(f"Model '{identifier}' not found. Did you mean: {', '.join(suggestions)}?")
        raise KeyError(f"Model '{identifier}' not found.")

    def tests_for_node(self, unique_id: str) -> list[str]:
        children = self.child_map.get(unique_id, [])
        return [c for c in children if c.startswith("test.")]

    def model_nodes(self) -> dict[str, DbtNode]:
        return {uid: n for uid, n in self.nodes.items() if n.resource_type == "model"}

    def source_nodes(self) -> dict[str, DbtNode]:
        return {uid: n for uid, n in self.nodes.items() if n.resource_type == "source"}

    def project_macros(self) -> dict[str, DbtMacro]:
        return {uid: m for uid, m in self.macros.items() if m.package_name == self.project_name}

    def resolve_macro(self, identifier: str) -> DbtMacro:
        if identifier in self.macros:
            return self.macros[identifier]

        candidates = self._macro_name_to_ids.get(identifier, [])
        if len(candidates) == 1:
            return self.macros[candidates[0]]
        if len(candidates) > 1:
            local = [c for c in candidates if self.macros[c].package_name == self.project_name]
            if len(local) == 1:
                return self.macros[local[0]]
            ids_str = ", ".join(candidates)
            raise KeyError(f"Multiple macros match '{identifier}'. Use the full unique_id: {ids_str}")

        all_macro_names = list(self._macro_name_to_ids.keys())
        try:
            from rapidfuzz import fuzz, process

            matches = process.extract(identifier, all_macro_names, scorer=fuzz.WRatio, limit=3)
            suggestions = [m[0] for m in matches if m[1] > 50]
        except ImportError:
            suggestions = []
        if suggestions:
            raise KeyError(f"Macro '{identifier}' not found. Did you mean: {', '.join(suggestions)}?")
        raise KeyError(f"Macro '{identifier}' not found.")


_SCHEMA_VERSION_RE = re.compile(r"/v(\d+)\.json")
_MIN_SCHEMA_VERSION = 7


def load_manifest(path: Path) -> ProjectGraph:
    if not path.exists():
        raise FileNotFoundError(f"No manifest.json found at {path}. Run 'dbt compile' or specify --manifest.")

    with open(path) as f:
        raw = json.load(f)

    metadata = raw.get("metadata", {})

    schema_url = metadata.get("dbt_schema_version", "")
    match = _SCHEMA_VERSION_RE.search(schema_url)
    if match:
        version = int(match.group(1))
        if version < _MIN_SCHEMA_VERSION:
            raise ValueError(
                f"Manifest schema version v{version} is not supported. "
                "dbt-lens requires dbt-core >= 1.4 (manifest v7+)."
            )

    project_name = metadata.get("project_name", "unknown")
    adapter_type = metadata.get("adapter_type", "unknown")

    nodes: dict[str, DbtNode] = {}
    for uid, data in raw.get("nodes", {}).items():
        nodes[uid] = _parse_node(data)

    for uid, data in raw.get("sources", {}).items():
        nodes[uid] = _parse_source(data)

    macros: dict[str, DbtMacro] = {}
    for uid, data in raw.get("macros", {}).items():
        macros[uid] = DbtMacro(
            unique_id=uid,
            name=data["name"],
            package_name=data.get("package_name", ""),
            depends_on_macros=data.get("depends_on", {}).get("macros", []),
            description=data.get("description", ""),
            original_file_path=data.get("original_file_path", ""),
        )

    parent_map = raw.get("parent_map", {})
    child_map = raw.get("child_map", {})

    return ProjectGraph(
        project_name=project_name,
        adapter_type=adapter_type,
        nodes=nodes,
        macros=macros,
        parent_map=parent_map,
        child_map=child_map,
    )


def _parse_node(data: dict) -> DbtNode:
    depends_on = data.get("depends_on", {})
    compiled_code = data.get("compiled_code") if data.get("compiled", False) else None
    return DbtNode(
        unique_id=data["unique_id"],
        name=data["name"],
        resource_type=data["resource_type"],
        package_name=data.get("package_name", ""),
        fqn=data.get("fqn", []),
        description=data.get("description", ""),
        columns=data.get("columns", {}),
        tags=data.get("tags", []),
        meta=data.get("meta", {}),
        config=data.get("config", {}),
        depends_on_macros=depends_on.get("macros", []),
        depends_on_nodes=depends_on.get("nodes", []),
        raw_code=data.get("raw_code", ""),
        compiled_code=compiled_code,
        original_file_path=data.get("original_file_path", ""),
        path=data.get("path", ""),
        database=data.get("database", ""),
        schema_=data.get("schema", ""),
    )


def _parse_source(data: dict) -> DbtNode:
    freshness_raw = data.get("freshness")
    freshness = freshness_raw if freshness_raw else None
    return DbtNode(
        unique_id=data["unique_id"],
        name=data["name"],
        resource_type="source",
        package_name=data.get("package_name", ""),
        fqn=data.get("fqn", []),
        description=data.get("description", ""),
        columns=data.get("columns", {}),
        tags=data.get("tags", []),
        meta=data.get("meta", {}),
        config=data.get("config", {}),
        depends_on_macros=[],
        depends_on_nodes=[],
        raw_code="",
        compiled_code=None,
        original_file_path=data.get("original_file_path", ""),
        path=data.get("path", ""),
        database=data.get("database", ""),
        schema_=data.get("schema", ""),
        freshness=freshness,
    )
