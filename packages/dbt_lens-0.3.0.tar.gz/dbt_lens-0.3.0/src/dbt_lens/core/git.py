from __future__ import annotations

import subprocess
from dataclasses import dataclass
from pathlib import Path


@dataclass
class GitChanges:
    committed: list[str]
    staged: list[str]
    unstaged: list[str]
    untracked: list[str]
    git_root: Path


def get_git_root() -> Path:
    result = subprocess.run(
        ["git", "rev-parse", "--show-toplevel"],
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        raise ValueError("Not a git repository or git is not installed.")
    return Path(result.stdout.strip())


def get_git_changes(base: str = "main") -> GitChanges:
    git_root = get_git_root()

    is_on_base = subprocess.run(
        ["git", "merge-base", "--is-ancestor", "HEAD", base],
        capture_output=True,
        text=True,
        check=False,
    )
    if is_on_base.returncode not in (0, 1):
        raise ValueError(f"Branch '{base}' not found.")

    on_base_branch = is_on_base.returncode == 0

    committed: list[str] = []
    if not on_base_branch:
        result = subprocess.run(
            ["git", "diff", "--name-only", f"{base}...HEAD"],
            capture_output=True,
            text=True,
            check=False,
        )
        if result.returncode != 0:
            raise ValueError(f"Branch '{base}' not found.")
        committed = [f for f in result.stdout.strip().splitlines() if f]

    result = subprocess.run(
        ["git", "diff", "--cached", "--name-only"],
        capture_output=True,
        text=True,
        check=False,
    )
    staged = [f for f in result.stdout.strip().splitlines() if f]

    result = subprocess.run(
        ["git", "diff", "--name-only"],
        capture_output=True,
        text=True,
        check=False,
    )
    unstaged = [f for f in result.stdout.strip().splitlines() if f]

    result = subprocess.run(
        ["git", "ls-files", "--others", "--exclude-standard"],
        capture_output=True,
        text=True,
        check=False,
    )
    untracked = [f for f in result.stdout.strip().splitlines() if f and (f.endswith(".sql") or f.endswith(".yml"))]

    return GitChanges(
        committed=committed,
        staged=staged,
        unstaged=unstaged,
        untracked=untracked,
        git_root=git_root,
    )


def normalize_git_paths(
    git_paths: list[str],
    git_root: Path,
    manifest_path: Path,
) -> list[str]:
    project_root = _find_project_root(manifest_path)
    try:
        offset = project_root.relative_to(git_root)
    except ValueError:
        return [p for p in git_paths if p.endswith(".sql") or p.endswith(".yml")]

    offset_str = str(offset)
    result: list[str] = []
    for path in git_paths:
        if not (path.endswith(".sql") or path.endswith(".yml")):
            continue
        if offset_str and offset_str != "." and path.startswith(offset_str + "/"):
            result.append(path[len(offset_str) + 1 :])
        else:
            result.append(path)
    return result


def _find_project_root(manifest_path: Path) -> Path:
    current = manifest_path.resolve().parent
    for _ in range(10):
        if (current / "dbt_project.yml").exists():
            return current
        parent = current.parent
        if parent == current:
            break
        current = parent
    return manifest_path.resolve().parent.parent
