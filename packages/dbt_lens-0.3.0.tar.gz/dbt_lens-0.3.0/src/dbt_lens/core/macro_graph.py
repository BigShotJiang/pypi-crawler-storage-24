from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field

from dbt_lens.core.manifest import DbtNode, ProjectGraph


@dataclass
class MacroImpactResult:
    target_macro: str
    macro_chain: list[str]
    affected_models: list[DbtNode]
    by_layer: dict[str, int] = field(default_factory=dict)


def macro_impact(
    graph: ProjectGraph,
    macro_name: str,
    include_tests: bool = False,
) -> MacroImpactResult:
    macro = graph.resolve_macro(macro_name)

    # Build reverse edges: dep -> list of macros that depend on it
    reverse_edges: dict[str, list[str]] = {}
    for uid, m in graph.macros.items():
        for dep in m.depends_on_macros:
            reverse_edges.setdefault(dep, []).append(uid)

    # BFS from target to find all macros that transitively depend on it
    macro_chain = _find_transitive_dependents(macro.unique_id, reverse_edges)

    # Find all models that use any macro in the chain
    macro_chain_set = set(macro_chain)
    affected: list[DbtNode] = []
    for uid, node in graph.nodes.items():
        if not include_tests and node.resource_type == "test":
            continue
        if node.resource_type in ("source",):
            continue
        if macro_chain_set.intersection(node.depends_on_macros):
            affected.append(node)

    by_layer: dict[str, int] = {}
    for node in affected:
        if node.resource_type == "model":
            layer = node.layer
            by_layer[layer] = by_layer.get(layer, 0) + 1

    return MacroImpactResult(
        target_macro=macro.unique_id,
        macro_chain=macro_chain,
        affected_models=affected,
        by_layer=by_layer,
    )


def _find_transitive_dependents(
    start_id: str,
    reverse_edges: dict[str, list[str]],
) -> list[str]:
    visited: set[str] = set()
    result: list[str] = [start_id]
    visited.add(start_id)
    queue: deque[str] = deque()
    for dep in reverse_edges.get(start_id, []):
        queue.append(dep)
    while queue:
        macro_id = queue.popleft()
        if macro_id in visited:
            continue
        visited.add(macro_id)
        result.append(macro_id)
        for dep in reverse_edges.get(macro_id, []):
            if dep not in visited:
                queue.append(dep)
    return result
