from __future__ import annotations

import pytest

from dbt_lens.core.macro_graph import MacroImpactResult, macro_impact


class TestMacroImpact:
    def test_direct_impact(self, graph):
        result = macro_impact(graph, "filter_test_emails")
        assert isinstance(result, MacroImpactResult)
        model_names = [m.name for m in result.affected_models]
        assert "dim_customer" in model_names

    def test_transitive_impact(self, graph):
        result = macro_impact(graph, "filter_test_emails")
        model_names = [m.name for m in result.affected_models]
        assert "dim_validated_customer" in model_names

    def test_macro_chain_includes_transitive(self, graph):
        result = macro_impact(graph, "filter_test_emails")
        assert "macro.test_project.filter_test_emails" in result.macro_chain
        assert "macro.test_project.filter_and_validate_emails" in result.macro_chain

    def test_leaf_macro_no_transitive(self, graph):
        result = macro_impact(graph, "filter_and_validate_emails")
        assert len(result.macro_chain) == 1
        model_names = [m.name for m in result.affected_models]
        assert "dim_validated_customer" in model_names
        assert "dim_customer" not in model_names

    def test_by_layer_grouping(self, graph):
        result = macro_impact(graph, "filter_test_emails")
        assert "dimension" in result.by_layer

    def test_generate_surrogate_key_impact(self, graph):
        result = macro_impact(graph, "generate_surrogate_key")
        model_names = [m.name for m in result.affected_models]
        assert "int_orders_enriched" in model_names

    def test_exclude_tests_by_default(self, graph):
        result = macro_impact(graph, "filter_test_emails")
        for m in result.affected_models:
            assert m.resource_type != "test"

    def test_include_tests(self, graph):
        result = macro_impact(graph, "filter_test_emails", include_tests=True)
        assert isinstance(result, MacroImpactResult)

    def test_unused_macro(self, graph):
        result = macro_impact(graph, "macro.dbt_utils.generate_surrogate_key")
        assert len(result.affected_models) == 0

    def test_macro_not_found(self, graph):
        with pytest.raises(KeyError, match="not found"):
            macro_impact(graph, "nonexistent_macro")
