from __future__ import annotations

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from dbt_lens.core.git import get_git_changes, get_git_root, normalize_git_paths


def _mock_run(returncode=0, stdout="", stderr=""):
    result = MagicMock()
    result.returncode = returncode
    result.stdout = stdout
    result.stderr = stderr
    return result


class TestGetGitRoot:
    @patch("dbt_lens.core.git.subprocess.run")
    def test_success(self, mock_run):
        mock_run.return_value = _mock_run(stdout="/home/user/repo\n")
        root = get_git_root()
        assert root == Path("/home/user/repo")

    @patch("dbt_lens.core.git.subprocess.run")
    def test_not_a_repo(self, mock_run):
        mock_run.return_value = _mock_run(returncode=128, stderr="fatal: not a git repository")
        with pytest.raises(ValueError, match="Not a git repository"):
            get_git_root()


class TestGetGitChanges:
    @patch("dbt_lens.core.git.subprocess.run")
    def test_feature_branch_with_changes(self, mock_run):
        def side_effect(cmd, **kwargs):
            cmd_str = " ".join(cmd)
            if "rev-parse --show-toplevel" in cmd_str:
                return _mock_run(stdout="/repo\n")
            if "merge-base --is-ancestor" in cmd_str:
                return _mock_run(returncode=1)  # NOT on base
            if "diff --name-only main...HEAD" in cmd_str:
                return _mock_run(stdout="models/staging/stg_orders.sql\n")
            if "diff --cached --name-only" in cmd_str:
                return _mock_run(stdout="models/staging/stg_customers.sql\n")
            if "diff --name-only" in cmd_str and "--cached" not in cmd_str and "..." not in cmd_str:
                return _mock_run(stdout="")
            if "ls-files --others" in cmd_str:
                return _mock_run(stdout="models/staging/stg_new.sql\n")
            return _mock_run()

        mock_run.side_effect = side_effect
        changes = get_git_changes("main")
        assert "models/staging/stg_orders.sql" in changes.committed
        assert "models/staging/stg_customers.sql" in changes.staged
        assert "models/staging/stg_new.sql" in changes.untracked
        assert changes.git_root == Path("/repo")

    @patch("dbt_lens.core.git.subprocess.run")
    def test_on_base_branch_skips_committed(self, mock_run):
        def side_effect(cmd, **kwargs):
            cmd_str = " ".join(cmd)
            if "rev-parse --show-toplevel" in cmd_str:
                return _mock_run(stdout="/repo\n")
            if "merge-base --is-ancestor" in cmd_str:
                return _mock_run(returncode=0)  # IS on base
            if "diff --cached --name-only" in cmd_str:
                return _mock_run(stdout="models/staging/stg_orders.sql\n")
            if "diff --name-only" in cmd_str:
                return _mock_run(stdout="")
            if "ls-files --others" in cmd_str:
                return _mock_run(stdout="")
            return _mock_run()

        mock_run.side_effect = side_effect
        changes = get_git_changes("main")
        assert changes.committed == []
        assert "models/staging/stg_orders.sql" in changes.staged

    @patch("dbt_lens.core.git.subprocess.run")
    def test_base_branch_not_found(self, mock_run):
        def side_effect(cmd, **kwargs):
            cmd_str = " ".join(cmd)
            if "rev-parse --show-toplevel" in cmd_str:
                return _mock_run(stdout="/repo\n")
            if "merge-base --is-ancestor" in cmd_str:
                return _mock_run(returncode=128, stderr="fatal: Not a valid commit name")
            return _mock_run()

        mock_run.side_effect = side_effect
        with pytest.raises(ValueError, match="Branch .* not found"):
            get_git_changes("nonexistent-branch")


class TestNormalizeGitPaths:
    def test_same_root(self, tmp_path):
        git_root = tmp_path
        (tmp_path / "dbt_project.yml").touch()
        (tmp_path / "target").mkdir()
        manifest_path = tmp_path / "target" / "manifest.json"
        manifest_path.touch()
        result = normalize_git_paths(["models/staging/stg_orders.sql"], git_root, manifest_path)
        assert result == ["models/staging/stg_orders.sql"]

    def test_with_offset(self, tmp_path):
        git_root = tmp_path
        project_dir = tmp_path / "dbt_project"
        project_dir.mkdir()
        (project_dir / "dbt_project.yml").touch()
        target_dir = project_dir / "target"
        target_dir.mkdir()
        manifest_path = target_dir / "manifest.json"
        manifest_path.touch()
        result = normalize_git_paths(["dbt_project/models/staging/stg_orders.sql"], git_root, manifest_path)
        assert result == ["models/staging/stg_orders.sql"]

    def test_filters_non_sql_yml(self, tmp_path):
        (tmp_path / "dbt_project.yml").touch()
        (tmp_path / "target").mkdir()
        (tmp_path / "target" / "manifest.json").touch()
        result = normalize_git_paths(
            ["models/stg_orders.sql", "README.md", "schema.yml", "pyproject.toml"],
            tmp_path,
            tmp_path / "target" / "manifest.json",
        )
        assert "models/stg_orders.sql" in result
        assert "schema.yml" in result
        assert "README.md" not in result
        assert "pyproject.toml" not in result
