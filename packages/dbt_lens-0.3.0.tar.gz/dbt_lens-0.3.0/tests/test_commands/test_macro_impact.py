from __future__ import annotations

import json

import pytest
from click.testing import CliRunner

from dbt_lens.cli import cli


@pytest.fixture
def runner():
    return CliRunner()


@pytest.fixture
def manifest_args(small_manifest_path):
    return ["--manifest", str(small_manifest_path)]


class TestMacroImpactCommand:
    def test_basic_impact(self, runner, manifest_args):
        result = runner.invoke(cli, [*manifest_args, "macro-impact", "filter_test_emails"])
        assert result.exit_code == 0
        assert "filter_test_emails" in result.output

    def test_json_output(self, runner, manifest_args):
        result = runner.invoke(cli, [*manifest_args, "--format", "json", "macro-impact", "filter_test_emails"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["target_macro"] == "macro.test_project.filter_test_emails"
        assert "macro_chain" in data
        assert "affected_models" in data
        assert data["total_affected"] >= 1

    def test_macro_not_found(self, runner, manifest_args):
        result = runner.invoke(cli, [*manifest_args, "macro-impact", "nonexistent_macro"])
        assert result.exit_code != 0

    def test_transitive_chain_in_json(self, runner, manifest_args):
        result = runner.invoke(cli, [*manifest_args, "--format", "json", "macro-impact", "filter_test_emails"])
        data = json.loads(result.output)
        assert "macro.test_project.filter_and_validate_emails" in data["macro_chain"]

    def test_no_tests_by_default(self, runner, manifest_args):
        result = runner.invoke(cli, [*manifest_args, "--format", "json", "macro-impact", "filter_test_emails"])
        data = json.loads(result.output)
        for m in data["affected_models"]:
            assert m["layer"] != "test"
