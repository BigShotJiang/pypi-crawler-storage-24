from __future__ import annotations

import json
from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner

from dbt_lens.cli import cli


def _mock_run(returncode=0, stdout="", stderr=""):
    result = MagicMock()
    result.returncode = returncode
    result.stdout = stdout
    result.stderr = stderr
    return result


@pytest.fixture
def runner():
    return CliRunner()


@pytest.fixture
def manifest_args(small_manifest_path):
    return ["--manifest", str(small_manifest_path)]


class TestDiffCommand:
    @patch("dbt_lens.commands.diff.get_git_changes")
    def test_basic_diff_with_model_change(self, mock_git, runner, manifest_args, small_manifest_path):
        from dbt_lens.core.git import GitChanges

        mock_git.return_value = GitChanges(
            committed=["models/staging/stg_orders.sql"],
            staged=[],
            unstaged=[],
            untracked=[],
            git_root=small_manifest_path.parent.parent,
        )
        result = runner.invoke(cli, [*manifest_args, "diff"])
        assert result.exit_code == 0
        assert "stg_orders" in result.output

    @patch("dbt_lens.commands.diff.get_git_changes")
    def test_json_output(self, mock_git, runner, manifest_args, small_manifest_path):
        from dbt_lens.core.git import GitChanges

        mock_git.return_value = GitChanges(
            committed=["models/staging/stg_orders.sql"],
            staged=[],
            unstaged=[],
            untracked=[],
            git_root=small_manifest_path.parent.parent,
        )
        result = runner.invoke(cli, [*manifest_args, "--format", "json", "diff"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "blast_radius" in data
        assert "selector" in data
        assert data["total_affected"] >= 1

    @patch("dbt_lens.commands.diff.get_git_changes")
    def test_no_changes(self, mock_git, runner, manifest_args, small_manifest_path):
        from dbt_lens.core.git import GitChanges

        mock_git.return_value = GitChanges(
            committed=[],
            staged=[],
            unstaged=[],
            untracked=[],
            git_root=small_manifest_path.parent.parent,
        )
        result = runner.invoke(cli, [*manifest_args, "diff"])
        assert result.exit_code == 0
        assert "No modified" in result.output

    @patch("dbt_lens.commands.diff.get_git_changes")
    def test_macro_change(self, mock_git, runner, manifest_args, small_manifest_path):
        from dbt_lens.core.git import GitChanges

        mock_git.return_value = GitChanges(
            committed=["macros/filter_test_emails.sql"],
            staged=[],
            unstaged=[],
            untracked=[],
            git_root=small_manifest_path.parent.parent,
        )
        result = runner.invoke(cli, [*manifest_args, "--format", "json", "diff"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert data["total_affected"] >= 1

    @patch("dbt_lens.commands.diff.get_git_changes")
    def test_new_file_warning(self, mock_git, runner, manifest_args, small_manifest_path):
        from dbt_lens.core.git import GitChanges

        mock_git.return_value = GitChanges(
            committed=[],
            staged=[],
            unstaged=[],
            untracked=["models/staging/stg_brand_new.sql"],
            git_root=small_manifest_path.parent.parent,
        )
        result = runner.invoke(cli, [*manifest_args, "--format", "json", "diff"])
        assert result.exit_code == 0
        data = json.loads(result.output)
        assert "stg_brand_new.sql" in str(data.get("new_files", []))

    @patch("dbt_lens.commands.diff.get_git_changes")
    def test_git_not_available(self, mock_git, runner, manifest_args):
        mock_git.side_effect = ValueError("Not a git repository or git is not installed.")
        result = runner.invoke(cli, [*manifest_args, "diff"])
        assert result.exit_code != 0
        assert "git" in result.output.lower()

    @patch("dbt_lens.commands.diff.get_git_changes")
    def test_selector_only_has_model_names(self, mock_git, runner, manifest_args, small_manifest_path):
        from dbt_lens.core.git import GitChanges

        mock_git.return_value = GitChanges(
            committed=["macros/filter_test_emails.sql"],
            staged=[],
            unstaged=[],
            untracked=[],
            git_root=small_manifest_path.parent.parent,
        )
        result = runner.invoke(cli, [*manifest_args, "--format", "json", "diff"])
        data = json.loads(result.output)
        if data["selector"]:
            assert "filter_test_emails+" not in data["selector"]
