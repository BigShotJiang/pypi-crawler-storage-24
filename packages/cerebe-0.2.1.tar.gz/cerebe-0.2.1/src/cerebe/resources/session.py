"""Session resource for the Cerebe SDK."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from .._response import APIResponse

if TYPE_CHECKING:
    from .._client import AsyncCerebe, Cerebe


class SessionResource:
    """Sync session management operations."""

    def __init__(self, client: Cerebe) -> None:
        self._client = client

    def list(self) -> APIResponse[Any]:
        """List all sessions."""
        return self._client.request("GET", "/api/v1/sessions")

    def get(self, session_id: str) -> APIResponse[Any]:
        """Get session details."""
        return self._client.request("GET", f"/api/v1/session/{session_id}")

    def update(
        self,
        session_id: str,
        cognitive_state: dict[str, Any],
        *,
        metadata: dict[str, Any] | None = None,
    ) -> APIResponse[Any]:
        """Update session cognitive state."""
        body: dict[str, Any] = {"cognitive_state": cognitive_state}
        if metadata is not None:
            body["metadata"] = metadata
        return self._client.request("PATCH", f"/api/v1/session/{session_id}", json=body)

    def delete(self, session_id: str) -> APIResponse[Any]:
        """Delete a session."""
        return self._client.request("DELETE", f"/api/v1/session/{session_id}")

    def cleanup(self) -> APIResponse[Any]:
        """Clean up expired sessions."""
        return self._client.request("POST", "/api/v1/sessions/cleanup")


class AsyncSessionResource:
    """Async session management operations."""

    def __init__(self, client: AsyncCerebe) -> None:
        self._client = client

    async def list(self) -> APIResponse[Any]:
        """List all sessions."""
        return await self._client.request("GET", "/api/v1/sessions")

    async def get(self, session_id: str) -> APIResponse[Any]:
        """Get session details."""
        return await self._client.request("GET", f"/api/v1/session/{session_id}")

    async def update(
        self,
        session_id: str,
        cognitive_state: dict[str, Any],
        *,
        metadata: dict[str, Any] | None = None,
    ) -> APIResponse[Any]:
        """Update session cognitive state."""
        body: dict[str, Any] = {"cognitive_state": cognitive_state}
        if metadata is not None:
            body["metadata"] = metadata
        return await self._client.request("PATCH", f"/api/v1/session/{session_id}", json=body)

    async def delete(self, session_id: str) -> APIResponse[Any]:
        """Delete a session."""
        return await self._client.request("DELETE", f"/api/v1/session/{session_id}")

    async def cleanup(self) -> APIResponse[Any]:
        """Clean up expired sessions."""
        return await self._client.request("POST", "/api/v1/sessions/cleanup")
