"""Storage type definitions."""

from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel


class FileMetadata(BaseModel):
    """Metadata for an uploaded file."""

    upload_id: str
    filename: str
    content_type: str
    size_bytes: int | None = None
    content_hash: str | None = None
    created_at: datetime | None = None
    scan_status: str | None = None


class UploadResponse(BaseModel):
    """Response from file upload."""

    upload_id: str
    cdn_url: str | None = None
    status: str = "completed"
    extracted: dict[str, Any] | None = None
    memory_id: str | None = None
    processing_status: str | None = None


class EphemeralUrlResponse(BaseModel):
    """Response containing a time-limited URL."""

    url: str
    expires_at: datetime | None = None


class PresignedUploadResponse(BaseModel):
    """Response from presigned upload request."""

    status: str
    upload_id: str
    upload_url: str
    expires_in: int
    cdn_url: str | None = None


class AnalyzeContentResponse(BaseModel):
    """Response from content analysis."""

    type: str
    confidence: float
    details: dict[str, Any] | None = None
    error: str | None = None
