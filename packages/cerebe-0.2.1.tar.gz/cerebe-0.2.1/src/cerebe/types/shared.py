"""Shared type definitions."""

from __future__ import annotations

from typing import Any, Generic, TypeVar

from pydantic import BaseModel, Field

T = TypeVar("T")


class DomainContext(BaseModel):
    """Domain context for enriching Cerebe operations.

    This is the contract between domain-specific applications (like Sage)
    and Cerebe's domain-agnostic services.
    """

    schema_version: str = "1.0"
    domain: str = "general"
    entity_type: str | None = None
    session_id: str | None = None
    entity_metadata: dict[str, Any] = Field(default_factory=dict)
    constraints: dict[str, Any] = Field(default_factory=dict)
    cognitive_hints: dict[str, Any] = Field(default_factory=dict)
    plre_hints: dict[str, Any] = Field(default_factory=dict)


class PaginatedResponse(BaseModel, Generic[T]):
    """Generic paginated response."""

    items: list[T] = Field(default_factory=list)
    total: int = 0
    page: int = 1
    page_size: int = 20
    has_next_page: bool = False
