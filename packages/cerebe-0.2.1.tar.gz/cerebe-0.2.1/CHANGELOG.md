# Changelog

## [0.2.1](https://github.com/alien8d/sage3c/compare/cerebe-v0.2.0...cerebe-v0.2.1) (2026-03-13)


### Features

* Cerebe Cognitive Services Platform — productization foundation (Cycles 123-128) ([85e98b8](https://github.com/alien8d/sage3c/commit/85e98b8e4f1719c5a09b436016cc93e47ef7c3cb))
* Cycle 129 — Sage SDK migration + build integration ([adfa0d6](https://github.com/alien8d/sage3c/commit/adfa0d65e1a2fce492730c7a563b1ea434e54d56))
* **sdks:** add unit tests, CI/CD workflows, and release-please automation ([efb0c36](https://github.com/alien8d/sage3c/commit/efb0c363562da368c6597ca493abdaaa5eeb90fe))
* **sdks:** sync both SDKs to 100% API coverage + OpenAPI auto-gen pipeline ([614f69f](https://github.com/alien8d/sage3c/commit/614f69f7310ed2046b4ee1edbad4e917e27a9215))


### Bug Fixes

* **sdks:** mypy strict compliance, portal code examples, openapi-export target ([aab5e16](https://github.com/alien8d/sage3c/commit/aab5e1666c3e6ae8f7387e5a5604ffd7815375b8))


### Documentation

* **sdks:** add comprehensive README for TypeScript and Python SDKs ([f5aebf7](https://github.com/alien8d/sage3c/commit/f5aebf7d4f8f16bc7fe8120c2da540a1d222e821))
