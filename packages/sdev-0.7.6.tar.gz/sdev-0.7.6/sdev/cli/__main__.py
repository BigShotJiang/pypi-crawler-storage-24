from __future__ import annotations

"""
python -m sdev.cli 入口：

简单地调用同目录下 __init__.py 中的 main()。
"""

from . import main


if __name__ == "__main__":
    raise SystemExit(main())

