from mcp.server.fastmcp import FastMCP
from .serial_notebook import SerialNotebook
from .serial_rw_server import get_remote_hosts, fetch_boards_from_host, DEFAULT_SERVICE_PORT
from .serial_rw import scan_serial_ports, check_port_alive_nonblock
import logging
import os
import sys

# 初始化 FastMCP
mcp = FastMCP("sdev")

@mcp.tool()
def sdev_list(scope: str = "all") -> str:
    """
    获取可用串口设备列表。
    scope: "all" (默认), "local" (仅本地), "remote" (仅远程)。
    返回格式化的设备列表字符串。
    """
    from ..cli import _device_id
    
    local_ports = []
    if scope in ("all", "local"):
        local_ports = scan_serial_ports()
        
    remote_hosts = []
    if scope in ("all", "remote"):
        try:
            remote_hosts = get_remote_hosts()
        except:
            pass
        
    results = []
    
    # 本地扫描
    for p in local_ports:
        r = check_port_alive_nonblock(p, timeout=1.0)
        if r.get("available"):
            # 尝试读型号
            try:
                with SerialNotebook(device=p) as nb:
                    model = nb.get_model_type(timeout=2.0) or "unknown"
            except:
                model = "unknown"
            results.append(f"HOST: localhost, DEVICE: {p}, ID: {_device_id('localhost', p)}, TYPE: {model}")
            
    # 远程扫描
    for host, port in remote_hosts:
        try:
            boards = fetch_boards_from_host(host, port)
            for b in boards:
                if b.get("available"):
                    dev = b.get("device") or b.get("port")
                    try:
                        with SerialNotebook(device=dev, host=host, port=port) as nb:
                            model = nb.get_model_type(timeout=2.0) or "unknown"
                    except:
                        model = "unknown"
                    results.append(f"HOST: {host}, DEVICE: {dev}, ID: {_device_id(host, dev)}, TYPE: {model}")
        except:
            continue
                
    if not results:
        return "未发现可用设备。"
    return "\n".join(results)

@mcp.tool()
def sdev_run(cmd: str, device_id: str = None, timeout: float = 10.0) -> str:
    """
    在指定设备上执行命令。
    cmd: 要执行的 shell 命令。
    device_id: 设备 ID（从 sdev_list 获取）。如果不指定，则尝试使用默认设备。
    timeout: 整体超时时间（秒）。
    """
    from ..cli import _read_default, _resolve_device_to_host_port
    
    host = "localhost"
    device = None
    
    if device_id:
        res = _resolve_device_to_host_port(device_id)
        if res:
            host, device = res
        else:
            return f"错误：未找到 ID 为 {device_id} 的设备。"
    else:
        cfg = _read_default()
        if cfg:
            host = cfg.get("host", "localhost")
            device = cfg.get("device") or cfg.get("port")
        else:
            return "错误：未指定 device_id 且没有配置默认设备。"
            
    if not device:
        return "错误：无法确定串口路径。"
        
    try:
        # 使用 SerialNotebook 执行
        if host == "localhost":
            nb = SerialNotebook(device=device)
        else:
            nb = SerialNotebook(device=device, host=host, port=DEFAULT_SERVICE_PORT)
            
        with nb:
            lines = nb.run(cmd, overall_timeout=timeout, stream=False, verbose=False)
            return "".join(lines).strip()
    except Exception as e:
        return f"执行失败：{e}"

@mcp.tool()
def sdev_set_default(device_id: str) -> str:
    """
    设置默认操作的设备。
    device_id: 设备 ID。
    """
    from ..cli import _resolve_device_to_host_port, _write_default
    res = _resolve_device_to_host_port(device_id)
    if not res:
        return f"错误：未找到 ID 为 {device_id} 的设备。"
    host, device = res
    _write_default(host, device, device_id)
    return f"成功：已将默认设备设置为 {host}:{device} (ID: {device_id})"

if __name__ == "__main__":
    mcp.run()
