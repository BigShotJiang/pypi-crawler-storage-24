
import sys
import time
from loguru import logger

from .serial_rw import SerialLine, CTRL_C

GREY = "\033[90m"
YELLOW = "\033[33m"
RED = "\033[31m"
RESET = "\033[0m"

class SerialNotebook():
    def __init__(self, device: str, baudrate: int = 115200, host=None, port=None, default_flag=" #"):
        if host is not None and port is not None:
            from .serial_rw_server import SerialRWClient
            self._core = SerialRWClient(host, port, device, baudrate)
        else:
            from .serial_rw import SerialRW
            self._core = SerialRW(device, baudrate)
        self.default_flag = default_flag
        self._muted = False

    def mute(self, value=None):
        self._muted = True if value is None else value

    def _write_raw(self, text: str) -> None:
        """
        向宿主终端输出原始文本。

        - 默认实现直接写到 stdout；
        - CLI / 上层如需重定向，可在子类中覆盖该方法。
        """
        sys.stdout.write(text)
        sys.stdout.flush()
    
    def __enter__(self):
        self._core.connect()
        return self
    
    def __exit__(self, exc_type, exc_value, traceback):
        self._core.disconnect()

    def run(self, cmd: str, end_flag=None, allow_fold=True, max_fold_lines=4, strip_echo=True, stream=False, verbose=True, overall_timeout=None, response_timeout=None, keep_type=False):
        # 先清理残留输出，避免前一次命令的尾巴影响本次结果。
        assert cmd is not None
        self._core.drain_buffer()
        
        if end_flag is None:
            end_flag = self.default_flag

        deadline = time.monotonic() + overall_timeout if overall_timeout is not None else None
        def _check_overall_timeout() -> None:
                if deadline is not None and time.monotonic() >= deadline:
                    raise TimeoutError("overall timeout exceeded in SerialNotebook.run")
        
        show_log = False if self._muted else verbose
        def _iter():
            try:
                # 发送命令：
                # - 若 display=True，则先手动打印一行以 > 开头的命令回显（黄色），避免等待串口自身的 echo，
                #   直接进入等待提示符阶段以加快整体速度。 
                if show_log:
                    if cmd == CTRL_C:
                        self._write_raw(f"{YELLOW}> ^C{RESET}\n")
                    else:
                        self._write_raw(f"{YELLOW}> {cmd}{RESET}\n")
            
                # 检查输出：
                for line in self._core.forward(
                    x=cmd, 
                    flag=end_flag,
                    allow_fold=allow_fold,
                    max_fold_lines=max_fold_lines,
                    timeout=response_timeout,
                    strip_echo=strip_echo,
                ):
                    _check_overall_timeout()
                    line: SerialLine
                    if line.kind == 'error' and line.text == '<sdev timeout>\n':
                        raise TimeoutError
                    # print(line.kind, line.line, show_log, isinstance(line, SerialLine), line.kind == 'body')
                    if show_log and isinstance(line, SerialLine) and line.kind == 'body':
                        self._write_raw(f"{GREY}{line.text}{RESET}")
                    if keep_type:
                        yield line
                    else:
                        yield line.text
                # 整个命令结束后，如启用 display，则额外输出一个空行（两个换行），
                # 便于与后续命令在视觉上明显隔离。
                if show_log:
                    self._write_raw("\n\n")        

            except TimeoutError:
                if show_log:
                    # 超时时，自动换行并打印红色的 <sdev timeout> 作为结束标记，
                    # 然后正常结束迭代，不再向外抛异常（避免 CLI / 上层看到 traceback）。
                    self._write_raw(f"\n{RED}<sdev timeout>{RESET}\n")
                    return                
                pass
        
        gen = _iter()
        if stream:
            return gen
        return list(gen)

    def send_interrupt(self) -> None:
        """
        将一次「中断」请求转换为对板子的 Ctrl-C（^C）发送。

        供 CLI 在捕获本地 KeyboardInterrupt 时调用，尽量让远端 shell 也一起中断当前前台命令。
        """
        try:
            self._core.dry_send(CTRL_C)
        except Exception:
            # 中断本身是“尽力而为”，失败时不再向外抛异常，避免干扰宿主进程退出路径。
            return

    def wait_for_silence(self, timeout=1.5):
        lines = []
        try:
            for line in self._core.forward(x=None, flag=None, timeout=timeout):
                lines.append(line)
        except TimeoutError:
            pass
        return lines

    def doctor(self, interrupt=True, quiet_timeout=1.5, ctrlc_timeout=0.5, reboot_when_see='uboot#', reboot_finish_when_see=' #'):
        # 等待当前输出安静
        if not interrupt:
            self.wait_for_silence(quiet_timeout)

        # 发送 Ctrl-C，尝试中断程序
        self.send_interrupt()

        # 采样输出（仅在较短窗口内观察 Ctrl-C 的响应）
        lines = self.wait_for_silence(ctrlc_timeout)
        output = "".join(lines)

        # 检查是否存在异常 uboot 提示符
        if reboot_when_see is not None and reboot_when_see in output:
            # 发现 uboot 提示符，认为当前不在正常 Linux shell 中
            logger.warning(f"Found uboot flag '{reboot_when_see}' during check_alive, try reboot...")
            self.run(cmd="reboot", end_flag=reboot_finish_when_see)


    def get_model_type(self, prompt_flag=None, timeout=3.0, verbose=False):
        """
        读取设备树型号前缀：
        - 命令：cat /proc/device-tree/model 2>/dev/null; echo
        - 若 prompt_flag 为 None，则尝试使用较宽泛的匹配。
        """
        if prompt_flag is None:
            # 常见提示符结尾：#, $, >
            prompt_flag = "[#$>]"
        try:
            cmd = "cat /proc/device-tree/model 2>/dev/null; echo"
            lines = self.run(
                cmd=cmd,
                end_flag=prompt_flag,
                stream=False,
                overall_timeout=timeout,
                response_timeout=timeout,
                verbose=verbose,
            )
            if lines and len(lines) >= 2:
                return lines[-2].strip()
        except Exception:
            pass
        return None
    

if __name__ == "__main__":
    with SerialNotebook(device="/dev/ttyUSB0", baudrate=115200) as s:
        s.run("ls -lh")
        print(s.get_model_type())
