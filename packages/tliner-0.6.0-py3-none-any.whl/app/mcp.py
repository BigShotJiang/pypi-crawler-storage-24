import json

from fastmcp import FastMCP

from .models import Step
from .services import MoveError, Timeline
from .utils0 import L as logger  # noqa: N811

DEFAULT_MAX_CHARS = 30000
MIN_MAX_CHARS = 1000  # should be enough for summary [500 char max] + metadata for at least 1 step per page
DEFAULT_MAX_TOKENS = DEFAULT_MAX_CHARS // 3
MIN_MAX_TOKENS = MIN_MAX_CHARS // 3

TRUNCATION_SUFFIX = " [...truncated]"
WARN_THRESHOLD_CHARS = 200_000


def _build_warnings(total_chars: int, since: str, until: str, query: list[str] | None, summaries_only: bool) -> list[str]:
    if total_chars <= WARN_THRESHOLD_CHARS:
        return []
    est_tokens = total_chars // 4
    warnings = [f"Large result set: ~{est_tokens:,} tokens across all pages."]
    if not since and not until:
        warnings.append("No time filter set. Narrow with since/until to reduce result size.")
    if query:
        warnings.append(f"Query {query} may match too broadly. Try more specific keywords.")
    if not summaries_only:
        warnings.append("Try summaries_only=True for compact view first, then cherry-pick by step ID.")
    warnings.append("Consider delegating to a subagent for page-by-page processing.")
    return warnings


def paginate_steps(steps: list[Step], max_chars: int = DEFAULT_MAX_CHARS) -> list[list[Step]]:
    max_chars = max(max_chars, MIN_MAX_CHARS)

    pages: list[list[Step]] = []
    current_page: list[Step] = []
    current_chars = 0

    for step in steps:
        text = json.dumps(step.model_dump(), default=str)
        current_step = step

        if len(text) > max_chars:
            metadata_len = len(json.dumps(step.model_copy(update={"outcomes": ""}).model_dump(), default=str))
            max_outcomes = max(0, max_chars - metadata_len - len(TRUNCATION_SUFFIX))
            current_step = step.model_copy(update={"outcomes": step.outcomes[:max_outcomes] + TRUNCATION_SUFFIX})  # truncate outcomes
            text = json.dumps(current_step.model_dump(), default=str)

        if current_chars + len(text) > max_chars and current_page:
            pages.append(current_page)
            current_page = []
            current_chars = 0

        current_page.append(current_step)
        current_chars += len(text)

    if current_page:
        pages.append(current_page)

    return pages or [[]]


app = FastMCP("timeliner")
service = Timeline()


def _coerce_to_list(val: str | list[str] | None) -> list[str] | None:
    if val is None or isinstance(val, list):
        return val
    if isinstance(val, str):
        try:
            parsed = json.loads(val)
            if isinstance(parsed, list):
                return [str(x) for x in parsed]
        except (json.JSONDecodeError, ValueError):
            pass
        return [val]
    raise TypeError(f"Expected a list of strings or a single string, got {type(val).__name__}: {val!r}")


@app.tool()
def task_list() -> dict:
    """
    Lists all tasks in the system.

    WHEN TO USE:
    - To discover existing tasks
    - To find a task_id when you need to add steps to existing work
    - To review what work has been tracked in the Timeline

    Returns: dict containing list of all tasks with their task_id, title, and file paths
    """
    tasks = service.get_all_tasks()
    return {"tasks": [task.model_dump() for task in tasks]}


@app.tool()
def save_step(task_id: str, title: str, summary: str, outcomes: str, tags: list[str] | None = None, metadata: dict[str, str] | None = None) -> dict:  # noqa: PLR0913
    """
    Records the step in the Timeline for tracking AI agent work outcomes.

    WHEN TO USE:
    - After completing any significant work (bug fix, feature implementation, investigation)
    - To document decisions, findings, or outcomes that future context might need
    - To create audit trail of what was done and why

    WORKFLOW:
    1. First time? Pass "new" as task_id to auto-create new task (also accepts: "", '""', '"new"')
    2. Subsequent steps? Use the task_id returned from previous save_step call (e.g., "20251208T103349.797731Z")
    3. Add descriptive tags to make steps searchable (e.g., ["bugfix", "authentication"])
    4. Include metadata links to related resources (GitHub issues, PRs, commits)

    Args:
        task_id: Task identifier. To CREATE NEW: use "new". To APPEND: use existing task_id (e.g., "20251208T103349.797731Z")
        title: Concise step description (e.g., "Fixed login timeout bug")
        summary: Concise TL;DR of the step (max 500 chars)
        outcomes: Detailed explanation of what was done, decisions made, and results of the work
        tags: Optional categorization tags ["feature", "refactor", "investigation"]
        metadata: Optional links {"github_issue": "https://...", "pr": "https://...", "commit": "abc123"}

    Returns: dict with task_id, step_id, and file_path to the task's markdown file
    """
    # Check correctness of 'task_id'
    if task_id is None or not isinstance(task_id, str):
        raise ValueError(f"Invalid type of task_id ({task_id}). Please provide a valid task_id type or empty string.")

    # Normalize pseudo-empty strings that LLMs sometimes send
    # Support: "", '""', "new", '"new"' as indicators to create new task
    normalized_task_id = task_id.strip()
    if normalized_task_id in ['""', "new", '"new"', "'new'"]:
        normalized_task_id = ""

    # fetch Task instance and check if task exist
    if not normalized_task_id:
        task = service.create_task(title=title)
        if not task:
            raise ValueError(f"Unable to create task ({task_id}). Failed when at file creating.")  # TODO @vz: what llm should do?
    else:
        task = service.get_task(normalized_task_id)
        if not task:
            raise ValueError(f"Task with id {normalized_task_id} does not exist. Please provide a valid task_id or empty string.")

    # Create step
    step = service.create_step(task.task_id, title, summary[:500], outcomes, tags, metadata)
    if not step:
        raise ValueError("Failed to create the step.")  # TODO @vz: what llm should do?

    logger.info(f"Successfully saved step for task {task_id}")
    return {"task_id": task.task_id, "step_id": step.step_id, "file_path": task.file_path}


@app.tool()
def get_steps(  # noqa: PLR0913
    since: str = "", until: str = "", ids: list[str] | None = None, query: list[str] | None = None, page: int = 1, max_tokens: int = DEFAULT_MAX_TOKENS, summaries_only: bool = False
) -> dict:
    """
    Retrieves steps from the Timeline with optional filtering by time, IDs, or content search.

    WHEN TO USE:
    - To load context from previous work sessions
    - To find relevant past decisions or implementations
    - To review what was done recently or on specific tasks
    - To search for specific topics, issue references, or keywords

    FILTERING OPTIONS:
    - No filters: Returns ALL steps across all tasks
    - since only: Get steps from a specific time [include] onwards (ISO format: "2025-01-01T00:00:00Z")
    - until only: Get steps up to a specific time [exclude] (ISO format: "2025-02-01T00:00:00Z")
    - since and until: Get steps in a specific time range
    - ids: Get steps by task_id OR step_id (accepts both, auto-detects type)
    - query: Fuzzy keyword search in step titles, outcomes, tags, and metadata. Multiple keywords use OR logic (matches ANY keyword).
    - Combine: Mix time, ID, and search filters for precise queries (AND logic between filter types)
    - NOTE: Steps and tasks always use the UTC timezone for timestamps. Convert local time to UTC BEFORE providing 'since' and 'until' filters.
    - summaries_only: Set to True to get lightweight response (summary + metadata only, no outcomes)

    PAGINATION:
    - Results are paginated by token count (uses chars/3 approximation, not real tokenizer)
    - Pages are 1-indexed (first page is page=1)
    - Oversized steps are truncated with "[...truncated]" suffix
    - pagination.warnings: non-empty array when total result exceeds safe context size. READ warnings before loading more pages.

    Args:
        since: Optional ISO UTC format timestamp to filter steps from  [include] (e.g., "2025-01-01T00:00:00Z")
        until: Optional ISO UTC format timestamp to filter steps until [exclude] (e.g., "2025-02-01T00:00:00Z")
        ids: Optional list of task IDs or step IDs to filter steps (e.g., ["20251208T103349.797731Z"])
        query: Optional list of keywords for fuzzy search (OR logic - matches if ANY keyword found)
        page: Page number to retrieve, 1-indexed (default: 1)
        max_tokens: Maximum tokens per page, uses chars/3 approximation (default: 10000 tokens, min: 333 tokens)
        summaries_only: If True, return summaries + metadata only, no full outcomes (default: False)

    Returns: dict with steps array, count, and pagination info (page, total_pages, warnings)
    """
    ids = _coerce_to_list(ids)
    query = _coerce_to_list(query)
    steps = service.get_all_steps(since=since, until=until, ids=ids, query=query)

    if summaries_only:
        steps = [s.model_copy(update={"outcomes": ""}) for s in steps]

    # chars/3 for pagination — conservative ratio to not overrun hard MCP transport limit (see #122)
    max_chars = max_tokens * 3
    pages = paginate_steps(steps, max_chars)

    # chars/4 for warning estimate — closer to real tokenization, more precise for user-facing advice
    total_chars = sum(len(json.dumps(s.model_dump(), default=str)) for s in steps)
    warnings = _build_warnings(total_chars, since, until, query, summaries_only)
    total_pages = len(pages)

    page = max(1, min(page, total_pages)) if total_pages > 0 else 1
    page_steps = pages[page - 1] if total_pages > 0 else []

    step_dicts = []
    for m in page_steps:
        m_dict = m.model_dump()
        if summaries_only:
            m_dict.pop("outcomes", None)
        m_dict["timestamp"] = m.timestamp.isoformat()
        step_dicts.append(m_dict)

    return {"steps": step_dicts, "count": len(step_dicts), "pagination": {"page": page, "total_pages": total_pages, "warnings": warnings}}


_SKIP_ERRORS = {MoveError.STEP_NOT_GROUPABLE, MoveError.SOURCE_TASK_NOT_GROUPABLE, MoveError.TARGET_TASK_NOT_GROUPABLE}


def _validate_no_duplicate_steps(move_to_tasks: dict[str, list[str]], create_new_tasks: dict[str, list[str]]) -> None:
    all_ids: list[str] = []
    for step_ids in [*move_to_tasks.values(), *create_new_tasks.values()]:
        all_ids.extend(step_ids)
    dupes = {sid for sid in all_ids if all_ids.count(sid) > 1}
    if dupes:
        raise ValueError(f"Duplicate step_ids across groups: {sorted(dupes)}")


def _execute_moves(target_task_id: str, step_ids: list[str], moved: list, failed: list, skipped: list, deleted_tasks: list) -> None:  # noqa: PLR0913
    for step_id in step_ids:
        result = service.move_step_id(step_id, target_task_id)
        if isinstance(result, MoveError):
            entry = {"step_id": step_id, "reason" if result in _SKIP_ERRORS else "error": result.value}
            (skipped if result in _SKIP_ERRORS else failed).append(entry)
        elif isinstance(result, Step):
            moved.append(step_id)
            src_task_id = result.prev_tasks[-1] if result.prev_tasks else ""
            if src_task_id and not service.get_task(src_task_id):
                deleted_tasks.append(src_task_id)


@app.tool()
def group_steps(move_to_tasks: dict[str, list[str]] | None = None, create_new_tasks: dict[str, list[str]] | None = None) -> dict:
    """
    Moves steps between tasks based on grouping instructions.
    - Skips steps with metadata.groupable: false
    - Skips tasks with groupable: false

    WHEN TO USE:
    - After analyzing steps with get_steps() and identifying semantic groupings
    - To consolidate scattered steps into coherent task
    - When multiple tasks cover the same topic/feature

    Args:
        move_to_tasks: Mapping of existing target_task_id to list of step_ids to move there.
                       Example: {"20251225T100000.000000Z": ["20251226T120000.123456Z", "20251227T090000.654321Z"]}
        create_new_tasks: Mapping of new task title to list of step_ids. Creates a new task per title, then moves steps.
                          Example: {"Database migration": ["20251226T120000.123456Z"], "Auth refactor": ["20251227T090000.654321Z"]}
                          WARNING: JSON silently drops duplicate keys. Use unique titles — duplicates cause silent step loss.

    Returns: dict with moved, failed, skipped, deleted_tasks, and created_tasks
    """
    move_to_tasks = move_to_tasks or {}
    create_new_tasks = create_new_tasks or {}
    _validate_no_duplicate_steps(move_to_tasks, create_new_tasks)

    moved: list[str] = []
    failed: list[dict] = []
    skipped: list[dict] = []
    deleted_tasks: list[str] = []
    created_tasks: dict[str, str] = {}

    for title, step_ids in create_new_tasks.items():
        if not step_ids:
            continue
        task = service.create_task(title=title)
        if not task:
            failed.extend({"step_id": sid, "error": f"failed to create task '{title}'"} for sid in step_ids)
            continue
        created_tasks[task.task_id] = title
        _execute_moves(task.task_id, step_ids, moved, failed, skipped, deleted_tasks)

    for task_id, step_ids in move_to_tasks.items():
        if step_ids:
            _execute_moves(task_id, step_ids, moved, failed, skipped, deleted_tasks)

    logger.info(f"group_steps: moved={len(moved)}, failed={len(failed)}, skipped={len(skipped)}, deleted={len(deleted_tasks)}, created={len(created_tasks)}")

    res = {"moved": moved, "failed": failed, "skipped": skipped, "deleted_tasks": deleted_tasks, "created_tasks": created_tasks}

    if failed:
        raise ValueError(f"Some steps failed to move, see 'failed': {res}")

    return res
