"""Verbose debug logging to a temp file with timestamps."""

import logging
import tempfile
from pathlib import Path

_LOG_PATH = Path(tempfile.gettempdir()) / "pipwrap.log"


def get_log_path() -> Path:
    """Return the path to the pipwrap log file in the temp directory."""
    return _LOG_PATH


def setup_logger() -> logging.Logger:
    """Configure and return the pipwrap logger with file handler."""
    logger = logging.getLogger("pipwrap")
    logger.setLevel(logging.DEBUG)

    if not any(isinstance(h, logging.FileHandler) for h in logger.handlers):
        handler = logging.FileHandler(str(_LOG_PATH))
        handler.setLevel(logging.DEBUG)
        formatter = logging.Formatter(
            "%(asctime)s %(levelname)s %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)

    return logger
