"""Wrapper around pip install with multi-index and URL support."""

import subprocess
import site
import os

from pipwrap.logger import setup_logger
from urllib.parse import urlparse

logger = setup_logger()

def log(msg: str):
    import tempfile
    path = os.path.join(tempfile.gettempdir(), "log.txt")
    with open(path, "a") as f:
        f.write(f"{msg}\n")


class PInst:
    """Wraps pip install with support for multiple indexes and URL installs."""
    
    def __init__(self, trust_all_hosts: bool = False) -> None:
        """Initialize the installer."""
        self.trust_all_hosts = trust_all_hosts

    def build_install_command(
        self,
        packages: list[str],
        index_urls: list[str] | None = None,
    ) -> list[str]:
        """Build a pip install command with optional index URLs.

        Args:
            packages: Packages to install.
            index_urls: First URL becomes --index-url, rest become
                --extra-index-url.
        """
        if not packages:
            raise ValueError("At least one package must be specified")

        cmd = ["pip", "install"]

        for i, url in enumerate(index_urls or []):
            flag = "--index-url" if i == 0 else "--extra-index-url"
            cmd.extend([flag, url])
            log(f"{cmd}")
            if (self.trust_all_hosts):
                cmd.extend(["--trusted-host", f"{urlparse(url).netloc}"])

        cmd.extend(packages)
        return cmd

    def build_url_install_command(
        self,
        urls: list[str],
        index_urls: list[str] | None = None,
    ) -> list[str]:
        """Build a pip install command for direct URL (tar.gz) installs.

        Args:
            urls: Direct URLs to install from.
            index_urls: First URL becomes --index-url, rest become
                --extra-index-url.
        """
        if not urls:
            raise ValueError("At least one URL must be specified")

        cmd = ["pip", "install"]

        for i, url in enumerate(index_urls or []):
            flag = "--index-url" if i == 0 else "--extra-index-url"
            cmd.extend([flag, url])

        cmd.extend(urls)
        return cmd

    def install(
        self,
        packages: list[str],
        index_urls: list[str] | None = None,
    ) -> subprocess.CompletedProcess:
        """Run pip install for the given packages."""
        cmd = self.build_install_command(packages, index_urls)
        logger.debug("Running command: %s", " ".join(cmd))

        result = subprocess.run(cmd, capture_output=True, text=True)

        logger.debug("stdout: %s", result.stdout)
        if result.stderr:
            logger.error("stderr: %s", result.stderr)
        logger.debug("Return code: %d", result.returncode)

        return result

    def install_from_urls(
        self,
        urls: list[str],
        index_urls: list[str] | None = None,
    ) -> subprocess.CompletedProcess:
        """Run pip install from direct tar.gz URLs."""
        cmd = self.build_url_install_command(urls, index_urls)
        logger.debug("Running command: %s", " ".join(cmd))

        result = subprocess.run(cmd, capture_output=True, text=True)

        logger.debug("stdout: %s", result.stdout)
        if result.stderr:
            logger.error("stderr: %s", result.stderr)
        logger.debug("Return code: %d", result.returncode)

        return result

    def reset_environment(self) -> None:
        """Reset the environment to the state it was in before the installer was created."""
        if "PYTHONPATH" in os.environ:
            os.environ.pop("PYTHONPATH")
        if "PYTHONNOUSERSITE" in os.environ:
            os.environ.pop("PYTHONNOUSERSITE")
        if "PYTHONUSERBASE" in os.environ:
            os.environ.pop("PYTHONUSERBASE")

        site.addsitedir(site.getusersitepackages())