"""CLI entrypoint for pipwrap."""

import argparse
import sys

from pipwrap.installer import PInst


def main() -> int:
    """Parse args and run the pip wrapper."""
    parser = argparse.ArgumentParser(description="Wrapper around pip install")
    parser.add_argument("packages", nargs="*", help="Packages to install")
    parser.add_argument(
        "--index-url",
        action="append",
        default=[],
        help="Index URLs (first is primary, rest are extras; can be repeated)",
    )
    parser.add_argument(
        "--from-url",
        action="append",
        default=[],
        help="Install directly from tar.gz URLs",
    )

    args = parser.parse_args()
    installer = PInst()

    if not args.packages and not args.from_url:
        parser.error("Provide packages or --from-url arguments")

    if args.packages:
        result = installer.install(
            args.packages,
            index_urls=args.index_url or None,
        )
        if result.returncode != 0:
            return result.returncode

    if args.from_url:
        result = installer.install_from_urls(
            args.from_url,
            index_urls=args.index_url or None,
        )
        if result.returncode != 0:
            return result.returncode

    return 0


if __name__ == "__main__":
    sys.exit(main())
