from .installer import PInst

__all__ = ["PInst"]