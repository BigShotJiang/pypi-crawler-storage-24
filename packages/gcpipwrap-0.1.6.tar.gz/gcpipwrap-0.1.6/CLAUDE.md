# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

pipwrap (`gcpipwrap` on PyPI) is a Python wrapper around `pip install` that adds multi-index support and direct URL installs. It provides both a CLI (`pipwrap`) and a library API via the `PInst` class.

## Commands

```bash
uv sync                # Install dependencies
uv run pytest -q       # Run all tests
uv run pytest -q tests/test_installer.py              # Run a single test file
uv run pytest -q tests/test_installer.py -k "test_name"  # Run a single test
uv run ruff check .    # Lint
uv run ruff format .   # Format
```

## Architecture

- `pipwrap/installer.py` — Core logic. `PInst` class builds and executes pip commands via subprocess. First index URL becomes `--index-url`, extras become `--extra-index-url`. `trust_all_hosts` flag adds `--trusted-host` for each index.
- `pipwrap/cli.py` — CLI entrypoint (`pipwrap` command). Uses argparse. Registered as `project.scripts` in pyproject.toml.
- `pipwrap/logger.py` — Debug logging to `/tmp/pipwrap.log` with timestamps.
- `pipwrap/__init__.py` — Exports `PInst` as the public API.

## Build & Publish

- Build system: `hatchling` (wheel target packages `pipwrap/`)
- Published to PyPI as `gcpipwrap` via GitHub Actions on release (`.github/workflows/publish.yml`)
- Requires Python >=3.13
- Zero runtime dependencies

## Testing

Tests mock `subprocess.run` to avoid actual pip calls. Test files mirror the module structure under `tests/`.
