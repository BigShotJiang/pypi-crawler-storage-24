# pipwrap

A Python wrapper around `pip install` with support for multiple package indexes and direct URL installs.

## Features

- **Multi-index support** — pass multiple index URLs; the first is used as `--index-url`, the rest as `--extra-index-url`
- **Direct URL installs** — install packages from tar.gz URLs
- **Debug logging** — all commands and output are logged to a temp file for troubleshooting
- **CLI and library** — use as a command-line tool or import into your own code

## Installation

```bash
pip install .
```

Or with [uv](https://docs.astral.sh/uv/):

```bash
uv pip install .
```

## CLI Usage

Install packages from the default index:

```bash
pipwrap requests flask
```

Install from a private index with a fallback:

```bash
pipwrap requests \
  --index-url https://private.pypi.org/simple \
  --index-url https://pypi.org/simple
```

The first `--index-url` becomes the primary index. Any additional `--index-url` values are passed as `--extra-index-url` to pip.

Install directly from tar.gz URLs:

```bash
pipwrap --from-url https://example.com/packages/foo-1.0.tar.gz
```

Combine URL installs with custom indexes:

```bash
pipwrap --from-url https://example.com/foo-1.0.tar.gz \
  --index-url https://private.pypi.org/simple
```

## Library Usage

```python
from pipwrap.installer import PInst

installer = PInst()

# Install packages
installer.install(["requests", "flask"])

# Install with custom indexes
installer.install(
    ["my-private-pkg"],
    index_urls=[
        "https://private.pypi.org/simple",
        "https://pypi.org/simple",
    ],
)

# Install from direct URLs
installer.install_from_urls(["https://example.com/foo-1.0.tar.gz"])
```

## Logging

All pip commands and their output are logged to a temporary file. To find the log:

```python
from pipwrap.logger import get_log_path

print(get_log_path())  # e.g. /tmp/pipwrap.log
```

## Development

```bash
uv sync
uv run pytest -q
uv run ruff check .
```

## License

MIT
