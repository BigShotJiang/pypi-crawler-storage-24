#!/usr/bin/env bash
set -euo pipefail

# Release script for gcpipwrap.
# Bumps the version in pyproject.toml, commits, tags, and pushes.
#
# Usage: ./scripts/release.sh <version>
# Example: ./scripts/release.sh 0.2.0

if [[ $# -ne 1 ]]; then
    echo "Usage: $0 <version>" >&2
    echo "Example: $0 0.2.0" >&2
    exit 1
fi

VERSION="$1"
TAG="v${VERSION}"
REPO_ROOT="$(git rev-parse --show-toplevel)"
PYPROJECT="${REPO_ROOT}/pyproject.toml"

if [[ ! -f "$PYPROJECT" ]]; then
    echo "Error: pyproject.toml not found at ${PYPROJECT}" >&2
    exit 1
fi

if ! git diff --quiet || ! git diff --cached --quiet; then
    echo "Error: working tree is dirty. Commit or stash changes first." >&2
    exit 1
fi

if git rev-parse "$TAG" >/dev/null 2>&1; then
    echo "Error: tag ${TAG} already exists" >&2
    exit 1
fi

CURRENT=$(grep -oP '^version = "\K[^"]+' "$PYPROJECT")
echo "Bumping version: ${CURRENT} -> ${VERSION}"

sed -i "s/^version = \"${CURRENT}\"/version = \"${VERSION}\"/" "$PYPROJECT"

git add "$PYPROJECT"
git commit -m "Bump version to ${VERSION}"
git tag "$TAG"

echo ""
echo "Version ${VERSION} committed and tagged as ${TAG}."
echo "Run the following to push:"
echo "  git push origin main ${TAG}"
