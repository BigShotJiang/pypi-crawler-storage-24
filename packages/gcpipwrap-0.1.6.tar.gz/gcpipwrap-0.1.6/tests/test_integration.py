"""Integration tests - verify logging is wired into installer operations."""

from unittest.mock import MagicMock, patch

from pipwrap.installer import PInst
from pipwrap.logger import get_log_path


class TestInstallerLogging:
    @patch("pipwrap.installer.subprocess.run")
    def test_install_logs_command(self, mock_run):
        mock_run.return_value = MagicMock(returncode=0, stdout="ok", stderr="")
        installer = PInst()
        installer.install(["requests"])
        log_content = get_log_path().read_text()
        assert "pip" in log_content
        assert "requests" in log_content

    @patch("pipwrap.installer.subprocess.run")
    def test_install_logs_stdout(self, mock_run):
        mock_run.return_value = MagicMock(
            returncode=0, stdout="Successfully installed requests", stderr=""
        )
        installer = PInst()
        installer.install(["requests"])
        log_content = get_log_path().read_text()
        assert "Successfully installed requests" in log_content

    @patch("pipwrap.installer.subprocess.run")
    def test_install_logs_stderr_on_failure(self, mock_run):
        mock_run.return_value = MagicMock(returncode=1, stdout="", stderr="ERROR: could not find")
        installer = PInst()
        installer.install(["badpkg"])
        log_content = get_log_path().read_text()
        assert "ERROR: could not find" in log_content

    @patch("pipwrap.installer.subprocess.run")
    def test_install_from_urls_logs_url(self, mock_run):
        mock_run.return_value = MagicMock(returncode=0, stdout="ok", stderr="")
        installer = PInst()
        url = "https://example.com/foo-1.0.tar.gz"
        installer.install_from_urls([url])
        log_content = get_log_path().read_text()
        assert url in log_content

    @patch("pipwrap.installer.subprocess.run")
    def test_log_entries_have_timestamps(self, mock_run):
        mock_run.return_value = MagicMock(returncode=0, stdout="ok", stderr="")
        installer = PInst()
        installer.install(["requests"])
        log_content = get_log_path().read_text()
        # Timestamp format: YYYY-MM-DD HH:MM:SS
        import re

        assert re.search(r"\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}", log_content)
