"""Tests for pipwrap.logger - verbose debug logging to temp file."""

import logging
import tempfile


from pipwrap.logger import get_log_path, setup_logger


class TestLogPath:
    def test_log_path_is_in_temp_directory(self):
        log_path = get_log_path()
        assert str(log_path).startswith(tempfile.gettempdir())

    def test_log_path_has_expected_filename(self):
        log_path = get_log_path()
        assert log_path.name == "pipwrap.log"


class TestSetupLogger:
    def test_returns_logger_instance(self):
        logger = setup_logger()
        assert isinstance(logger, logging.Logger)

    def test_logger_name(self):
        logger = setup_logger()
        assert logger.name == "pipwrap"

    def test_logger_level_is_debug(self):
        logger = setup_logger()
        assert logger.level == logging.DEBUG

    def test_logger_has_file_handler(self):
        logger = setup_logger()
        file_handlers = [h for h in logger.handlers if isinstance(h, logging.FileHandler)]
        assert len(file_handlers) >= 1

    def test_file_handler_points_to_temp(self):
        logger = setup_logger()
        file_handlers = [h for h in logger.handlers if isinstance(h, logging.FileHandler)]
        handler = file_handlers[0]
        assert handler.baseFilename == str(get_log_path())

    def test_log_format_includes_timestamp(self):
        logger = setup_logger()
        file_handlers = [h for h in logger.handlers if isinstance(h, logging.FileHandler)]
        fmt = file_handlers[0].formatter._fmt
        assert "%(asctime)s" in fmt

    def test_log_format_includes_level(self):
        logger = setup_logger()
        file_handlers = [h for h in logger.handlers if isinstance(h, logging.FileHandler)]
        fmt = file_handlers[0].formatter._fmt
        assert "%(levelname)s" in fmt

    def test_log_writes_to_file(self):
        logger = setup_logger()
        logger.debug("test message from pipwrap")
        log_path = get_log_path()
        content = log_path.read_text()
        assert "test message from pipwrap" in content

    def test_repeated_setup_does_not_duplicate_handlers(self):
        logger1 = setup_logger()
        handler_count = len(logger1.handlers)
        logger2 = setup_logger()
        assert len(logger2.handlers) == handler_count
