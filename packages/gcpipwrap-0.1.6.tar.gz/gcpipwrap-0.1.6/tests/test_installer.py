"""Tests for pipwrap.installer - the core pip wrapper logic."""

from unittest.mock import MagicMock, patch

import pytest

from pipwrap.installer import PInst


class TestBuildInstallCommand:
    """Test command construction without executing pip."""

    def test_simple_install_single_package(self):
        installer = PInst()
        cmd = installer.build_install_command(["requests"])
        assert cmd == ["pip", "install", "requests"]

    def test_install_multiple_packages(self):
        installer = PInst()
        cmd = installer.build_install_command(["requests", "flask", "click"])
        assert cmd == ["pip", "install", "requests", "flask", "click"]

    def test_single_index_url(self):
        installer = PInst()
        cmd = installer.build_install_command(
            ["requests"],
            index_urls=["https://custom.pypi.org/simple"],
        )
        assert cmd == [
            "pip",
            "install",
            "--index-url",
            "https://custom.pypi.org/simple",
            "requests",
        ]

    def test_multiple_index_urls(self):
        installer = PInst()
        urls = [
            "https://index1.example.com/simple",
            "https://index2.example.com/simple",
            "https://index3.example.com/simple",
        ]
        cmd = installer.build_install_command(["pkg"], index_urls=urls)
        assert cmd == [
            "pip",
            "install",
            "--index-url",
            "https://index1.example.com/simple",
            "--extra-index-url",
            "https://index2.example.com/simple",
            "--extra-index-url",
            "https://index3.example.com/simple",
            "pkg",
        ]

    def test_custom_primary_index(self):
        installer = PInst()
        cmd = installer.build_install_command(
            ["requests"],
            index_urls=["https://private.pypi.org/simple"],
        )
        assert cmd == [
            "pip",
            "install",
            "--index-url",
            "https://private.pypi.org/simple",
            "requests",
        ]

    def test_primary_and_extra_indexes_combined(self):
        installer = PInst()
        cmd = installer.build_install_command(
            ["requests"],
            index_urls=[
                "https://primary.pypi.org/simple",
                "https://extra.pypi.org/simple",
            ],
        )
        assert cmd == [
            "pip",
            "install",
            "--index-url",
            "https://primary.pypi.org/simple",
            "--extra-index-url",
            "https://extra.pypi.org/simple",
            "requests",
        ]

    def test_empty_packages_raises(self):
        installer = PInst()
        with pytest.raises(ValueError, match="At least one package"):
            installer.build_install_command([])

    def test_arbitrarily_long_index_list(self):
        installer = PInst()
        urls = [f"https://index{i}.example.com/simple" for i in range(50)]
        cmd = installer.build_install_command(["pkg"], index_urls=urls)
        idx = cmd.index(urls[0])
        assert cmd[idx - 1] == "--index-url"
        for url in urls[1:]:
            idx = cmd.index(url)
            assert cmd[idx - 1] == "--extra-index-url"


class TestBuildUrlInstallCommand:
    """Test command construction for direct URL (tar.gz) installs."""

    def test_single_tarball_url(self):
        installer = PInst()
        url = "https://example.com/packages/foo-1.0.tar.gz"
        cmd = installer.build_url_install_command([url])
        assert cmd == ["pip", "install", url]

    def test_multiple_tarball_urls(self):
        installer = PInst()
        urls = [
            "https://example.com/packages/foo-1.0.tar.gz",
            "https://example.com/packages/bar-2.0.tar.gz",
        ]
        cmd = installer.build_url_install_command(urls)
        assert cmd == ["pip", "install"] + urls

    def test_url_install_with_index_urls(self):
        installer = PInst()
        urls = ["https://example.com/packages/foo-1.0.tar.gz"]
        cmd = installer.build_url_install_command(
            urls,
            index_urls=[
                "https://primary.pypi.org/simple",
                "https://extra.pypi.org/simple",
            ],
        )
        assert cmd == [
            "pip",
            "install",
            "--index-url",
            "https://primary.pypi.org/simple",
            "--extra-index-url",
            "https://extra.pypi.org/simple",
            "https://example.com/packages/foo-1.0.tar.gz",
        ]

    def test_empty_urls_raises(self):
        installer = PInst()
        with pytest.raises(ValueError, match="At least one URL"):
            installer.build_url_install_command([])


class TestRunInstall:
    """Test the actual execution path (subprocess calls mocked)."""

    @patch("pipwrap.installer.subprocess.run")
    def test_install_calls_subprocess(self, mock_run):
        mock_run.return_value = MagicMock(returncode=0, stdout="Success", stderr="")
        installer = PInst()
        result = installer.install(["requests"])
        mock_run.assert_called_once()
        args = mock_run.call_args[0][0]
        assert args == ["pip", "install", "requests"]
        assert result.returncode == 0

    @patch("pipwrap.installer.subprocess.run")
    def test_install_with_indexes(self, mock_run):
        mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")
        installer = PInst()
        installer.install(
            ["requests"],
            index_urls=[
                "https://primary.pypi.org/simple",
                "https://extra.pypi.org/simple",
            ],
        )
        args = mock_run.call_args[0][0]
        assert "--index-url" in args
        assert "https://primary.pypi.org/simple" in args
        assert "--extra-index-url" in args
        assert "https://extra.pypi.org/simple" in args

    @patch("pipwrap.installer.subprocess.run")
    def test_install_from_urls(self, mock_run):
        mock_run.return_value = MagicMock(returncode=0, stdout="", stderr="")
        installer = PInst()
        url = "https://example.com/foo-1.0.tar.gz"
        installer.install_from_urls([url])
        args = mock_run.call_args[0][0]
        assert url in args

    @patch("pipwrap.installer.subprocess.run")
    def test_install_failure_returns_nonzero(self, mock_run):
        mock_run.return_value = MagicMock(
            returncode=1,
            stdout="",
            stderr="ERROR: No matching distribution",
        )
        installer = PInst()
        result = installer.install(["nonexistent-package-xyz"])
        assert result.returncode == 1

    @patch("pipwrap.installer.subprocess.run")
    def test_subprocess_captures_output(self, mock_run):
        mock_run.return_value = MagicMock(returncode=0, stdout="out", stderr="err")
        installer = PInst()
        installer.install(["requests"])
        _, kwargs = mock_run.call_args
        assert kwargs["capture_output"] is True
        assert kwargs["text"] is True
