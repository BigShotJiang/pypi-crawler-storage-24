#!/usr/bin/env python3
"""
agent_reporter.py — MeshPOP Server Monitoring Agent v2.0

Mesh architecture — no single hub, no DB needed:
  - Each node runs HTTP on 0.0.0.0:8721
  - Every 30s: collect own stats → push to ALL peers (they store in their dict)
  - Any node can answer full cluster status from its own in-memory dict
  - Peer IPs: PEER_IPS env (comma-sep) OR ~/.mpop/config.json servers[*].wire_ip
  - To exclude nodes: add "mesh_exclude": ["1.2.3.4"] in ~/.mpop/config.json

Endpoints:
  GET  /api/status  → full cluster view (all known nodes)
  POST /api/report  → receive peer stats, store in local dict
  GET  /health      → 200 ok
"""
import os
import json
import time
import socket
import threading
import platform
import subprocess
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.request import urlopen, Request

DASHBOARD_PORT  = int(os.environ.get("DASHBOARD_PORT", "8721"))
REPORT_INTERVAL = int(os.environ.get("REPORT_INTERVAL", "30"))
NODE_TTL        = int(os.environ.get("NODE_TTL", "120"))   # stale after N seconds

_cluster = {}   # node_name → stats dict
_lock    = threading.Lock()


# ─── peer discovery ───────────────────────────────────────────────────────────

def _get_my_ip():
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("8.8.8.8", 80))
            return s.getsockname()[0]
    except Exception:
        return "127.0.0.1"


def _load_config():
    p = os.path.expanduser("~/.mpop/config.json")
    try:
        with open(p) as f:
            return json.load(f)
    except Exception:
        return {}


def _get_peer_ips(my_ip=None):
    """Return peer IPs to push to (excluding self + mesh_exclude list)."""
    ips = []
    cfg = _load_config()

    # 1) PEER_IPS env — injected by 'mpop setup agent' into systemd/launchd
    env = os.environ.get("PEER_IPS", "")
    if env:
        ips = [ip.strip() for ip in env.split(",") if ip.strip()]
    else:
        # 2) config.json servers[*].wire_ip
        servers = cfg.get("servers", {})
        items = servers.values() if isinstance(servers, dict) else servers
        for srv in items:
            ip = srv.get("wire_ip") or srv.get("tailscale_ip") or ""
            if ip and ip not in ips:
                ips.append(ip)
        # 3) fallback: DASHBOARD_URL or config dashboard_url
        if not ips:
            import re
            dash = os.environ.get("DASHBOARD_URL", "") or cfg.get("dashboard_url", "")
            m = re.search(r"https?://([^:/]+)", dash) if dash else None
            if m:
                ips.append(m.group(1))

    # Apply exclusions (default: full mesh, optionally exclude by IP)
    exclude = set(cfg.get("mesh_exclude", []))
    if my_ip:
        exclude.add(my_ip)
    return [ip for ip in ips if ip not in exclude]


# ─── stats collection ─────────────────────────────────────────────────────────

def _run(cmd):
    try:
        return subprocess.check_output(
            cmd, shell=True, stderr=subprocess.DEVNULL, timeout=5
        ).decode().strip()
    except Exception:
        return ""


def get_node_name():
    return (
        os.environ.get("NODE_NAME")
        or os.environ.get("HOSTNAME")
        or socket.gethostname().split(".")[0]
    )


def collect_stats(my_ip, node_name):
    """Collect this node's current stats."""
    # CPU
    cpu = 0.0
    try:
        import psutil; cpu = psutil.cpu_percent(interval=0.2)
    except ImportError:
        try: cpu = float(_run("top -bn1 | grep 'Cpu(s)' | awk '{print $2}'").replace(",", ".").replace("%",""))
        except Exception: pass

    # Memory
    mem_pct = mem_used_mb = mem_total_mb = 0
    try:
        import psutil; m = psutil.virtual_memory()
        mem_pct, mem_used_mb, mem_total_mb = m.percent, m.used >> 20, m.total >> 20
    except ImportError:
        parts = _run("free -m | awk '/Mem:/{print $3, $2}'").split()
        if len(parts) == 2:
            try:
                mem_used_mb, mem_total_mb = int(parts[0]), int(parts[1])
                mem_pct = round(mem_used_mb / mem_total_mb * 100, 1) if mem_total_mb else 0
            except Exception: pass

    # Disk
    disk_pct = disk_used_gb = disk_total_gb = 0
    try:
        import psutil; d = psutil.disk_usage("/")
        disk_pct, disk_used_gb, disk_total_gb = d.percent, d.used >> 30, d.total >> 30
    except ImportError:
        parts = _run("df -BG / | awk 'NR==2{print $3, $2, $5}'").split()
        if len(parts) >= 3:
            try:
                disk_used_gb = int(parts[0].replace("G",""))
                disk_total_gb = int(parts[1].replace("G",""))
                disk_pct = float(parts[2].replace("%",""))
            except Exception: pass

    # Load
    load = ""
    try:
        la = os.getloadavg(); load = f"{la[0]:.2f} {la[1]:.2f} {la[2]:.2f}"
    except Exception:
        load = _run("awk '{print $1,$2,$3}' /proc/loadavg 2>/dev/null")

    # Uptime
    uptime = ""
    try:
        import psutil; s = int(time.time() - psutil.boot_time())
        d2, s = divmod(s, 86400); h, s = divmod(s, 3600); mn = s // 60
        uptime = (f"{d2}d " if d2 else "") + f"{h}h {mn}m"
    except ImportError:
        uptime = _run("uptime -p 2>/dev/null || uptime")

    # Log errors (last 5 min in journal)
    errors = 0
    try:
        errors = int(_run(
            "journalctl --since '5 minutes ago' -p err -q --no-pager 2>/dev/null | wc -l"
        ))
    except Exception: pass

    return {
        "node":         node_name,
        "ip":           my_ip,
        "os":           platform.system(),
        "cpu_pct":      round(cpu, 1),
        "mem_pct":      round(mem_pct, 1),
        "mem_used_mb":  mem_used_mb,
        "mem_total_mb": mem_total_mb,
        "disk_pct":     round(disk_pct, 1),
        "disk_used_gb": disk_used_gb,
        "disk_total_gb":disk_total_gb,
        "load":         load,
        "uptime":       uptime,
        "log_errors":   errors,
        "ts":           int(time.time()),
        "agent_version":"2.0.0",
    }


# ─── HTTP server ──────────────────────────────────────────────────────────────

class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a): pass  # silence access log

    def do_GET(self):
        path = self.path.rstrip("/")
        if path in ("/api/status", "/status"):
            now = int(time.time())
            with _lock:
                nodes = [v for v in _cluster.values()
                         if now - v.get("ts", 0) <= NODE_TTL]
            body = json.dumps({"nodes": nodes, "count": len(nodes), "ts": now}).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        elif path == "/health":
            self.send_response(200); self.end_headers(); self.wfile.write(b"ok")
        else:
            self.send_response(404); self.end_headers()

    def do_POST(self):
        if self.path.rstrip("/") in ("/api/report", "/report"):
            try:
                length = int(self.headers.get("Content-Length", 0))
                data = json.loads(self.rfile.read(length).decode())
                node = data.get("node", "unknown")
                data.setdefault("ts", int(time.time()))
                with _lock:
                    _cluster[node] = data
                self.send_response(200); self.end_headers()
                self.wfile.write(b'{"ok":true}')
            except Exception as e:
                self.send_response(400); self.end_headers()
                self.wfile.write(json.dumps({"error": str(e)}).encode())
        else:
            self.send_response(404); self.end_headers()


# ─── push to peers ────────────────────────────────────────────────────────────

def push_to_peers(status, peer_ips):
    body = json.dumps(status).encode()
    for ip in peer_ips:
        try:
            req = Request(
                f"http://{ip}:{DASHBOARD_PORT}/api/report",
                data=body,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urlopen(req, timeout=5) as r:
                r.read()
        except Exception:
            pass  # peer offline — skip silently


# ─── main ─────────────────────────────────────────────────────────────────────

def main():
    my_ip     = _get_my_ip()
    node_name = get_node_name()

    server = ThreadingHTTPServer(("0.0.0.0", DASHBOARD_PORT), Handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    print(f"[agent] {node_name} ({my_ip}) :{DASHBOARD_PORT}", flush=True)

    while True:
        try:
            status    = collect_stats(my_ip, node_name)
            with _lock:
                _cluster[node_name] = status
            peer_ips  = _get_peer_ips(my_ip)       # re-read each cycle
            push_to_peers(status, peer_ips)
        except Exception as e:
            print(f"[agent] error: {e}", flush=True)
        time.sleep(REPORT_INTERVAL)


if __name__ == "__main__":
    main()
