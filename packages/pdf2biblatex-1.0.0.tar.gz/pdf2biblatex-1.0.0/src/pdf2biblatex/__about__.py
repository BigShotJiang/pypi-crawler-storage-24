# SPDX-FileCopyrightText: 2026-present Pierre Piveteau <pierre@piveteau.eu>
#
# SPDX-License-Identifier: GPL-3.0-or-later
__version__ = "1.0.0"
