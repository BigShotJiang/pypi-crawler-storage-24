# pdf2biblatex

[![PyPI - Version](https://img.shields.io/pypi/v/pdf2biblatex.svg)](https://pypi.org/project/pdf2biblatex)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/pdf2biblatex.svg)](https://pypi.org/project/pdf2biblatex)

-----

pdf2biblatex is a small command-line tool for generating a BibLaTeX file from a bunch of pdf using their DOI and Crossref.

## Installation

The default way of installing is by using `pip` :

``` shell
pip install pdf2biblatex
```

But I recommand using [`pipx`](https://pipx.pypa.io/stable/) to not burden your system with package dependencies (pdf2biblatex requires `PyMuPDF` and ``requests`), `pipx` putting them in a dedicated virtual environment.
Installation is similar to `pip` :

``` shell
pipx install pdf2biblatex
```

Otherwise, your prefered method for dealing with python package likely works.

## Usage

`pdf2biblatex` takes a directory filled with pdf as primary input, you might need to put in a dedicated folder all those you want to use in the generation of the BibLaTeX file.

From there, typical use is :

``` shell
pdf2biblatex -d path/to/directory
```
or

``` shell
cd path/to/directory
pdf2biblatex -d
```

`-d` (or `--directory`) will look into the selected folder and scan the five first pages and the metadata of any pdf for a DOI. If no DOI is found or is invalid, an error indicate the associated file. Then, a BibLaTeX file is generated for all valid DOI using the Crossref API.

After this, you might want to run :
``` shell
pdf2biblatex -a DOI_1 DOI_2 ...
```

`-a` (or `--add-doi`) will take any given DOI and generate the corresponding BibLaTeX entry in an existing BibLaTeX file or create a new one if none is detected.

Be careful if you run `--directory` again after using `--add-doi`, the former will write over the bibliography file you might have completed with the latter.

There is also a third argument `-b` (or `--bib-file`), whom you can use to change the name used for the BibLaTeX file.

For more details, you can use `pdf2biblatex --help` or look directly into the code at `src/pdf2biblatex/pdf2biblatex.py`.

## License

`pdf2biblatex` is distributed under the terms of the [GPL-3.0-or-later](https://spdx.org/licenses/GPL-3.0-or-later.html) license.
