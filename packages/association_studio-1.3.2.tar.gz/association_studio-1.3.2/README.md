# Association studio

The app helps to analyze the actually existing implementations of the association metrics.
The analysis implies computing the metric values in a GUI featuring two bounding boxes.
The user is able to move and rotate one of the boxes. The values of the currently selected
association metrics are calculated and represented instantly.

<img src="https://kovalp.github.io/association-studio-docs/assets/logo.png" width="192" alt="logo">
<img src="https://kovalp.github.io/association-studio-docs/assets/logo-vicomtech.svg" width="192" alt="VicomTech logo">

## Usage 

There is a matplotlib-driven GUI

```shell
association-studio
```

<img src="https://kovalp.github.io/association-studio-docs/assets/screenshot.png" width="957" alt="screenshot">

Checkout the active keystrokes and mouse events in the brief usage description:

```shell
association-studio --help
```

<img src="https://kovalp.github.io/association-studio-docs/assets/help-usage.png" width="734" alt="usage">


## Install

```shell
pip install association-studio
```

