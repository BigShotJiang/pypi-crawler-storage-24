"""."""

from typing import Sequence


def get_labels(names: Sequence[str]) -> list[str]:
    """."""
    labels = []
    for name in names:
        parts = name.split('-')
        one_or_two = [parts[0], '-'.join(parts[1:])] if len(parts) > 1 else parts
        labels.append('\n'.join(one_or_two))
    return labels
