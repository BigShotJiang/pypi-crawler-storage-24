import numpy as np

from kinematic_tracker import NdKkfTracker


def get_low_order_nu_scenes_tracker() -> NdKkfTracker:
    tracker = NdKkfTracker([1, 1, 1], [3, 4, 3])
    tracker.set_measurement_cov(np.eye(10))
    return tracker
