import matplotlib.pyplot as plt


def get_fig_axes() -> tuple[plt.Figure, plt.Axes]:
    fig, ax = plt.subplots(figsize=(5, 2.5))
    fig.subplots_adjust(left=0.3)
    fig.canvas.manager.set_window_title('Association Studio: metrics')
    return fig, ax
