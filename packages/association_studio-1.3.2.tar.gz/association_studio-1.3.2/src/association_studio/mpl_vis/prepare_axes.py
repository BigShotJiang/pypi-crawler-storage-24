from matplotlib import pyplot as plt

from association_studio.common import FMT


def prepare_axes(ax: plt.Axes, limits_mx: FMT) -> None:
    ax.set_xlim(*limits_mx[:, 0])
    ax.set_ylim(*limits_mx[:, 1])
    ax.set_aspect('equal')
