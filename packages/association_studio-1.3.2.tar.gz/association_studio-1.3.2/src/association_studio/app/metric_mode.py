"""."""

from kinematic_tracker.association.association_metric import AssociationMetric


class MetricMode:
    def __init__(self) -> None:
        self.choices = [m for m in AssociationMetric]
        self.metric = self.choices[0]

    def next(self) -> None:
        i = (self.choices.index(self.metric) + 1) % len(self.choices)
        self.metric = self.choices[i]
