"""."""

from enum import Enum

from association_studio.core.mid_box import Box


class ShowCooMode(Enum):
    TRANSLATION_AND_ROTATION = 0
    TRANSLATION = 1
    ROTATION = 2
    NOTHING = 3

    def next(self) -> int:
        p1 = self.value + 1
        return 0 if p1 > 3 else p1

    def format(self, box: Box) -> str:
        if self == self.TRANSLATION_AND_ROTATION:
            x, y = box.vec_z[:2]
            w, rz = box.vec_z[3:7:3]
            msg = f'xy {x:5.3f} {y:5.3f} w rz {w:5.3f} {rz:5.3f}'
        elif self == self.TRANSLATION:
            x, y = box.vec_z[:2]
            msg = f'xy {x:5.3f} {y:5.3f}'
        elif self == self.ROTATION:
            w, rz = box.vec_z[3:7:3]
            msg = f'w rz {w:5.3f} {rz:5.3f}'
        else:
            msg = ''
        return msg
