"""."""

from typing import Sequence

from .back import AssociationStudioBackend
from .cli import get_cli
from .front import AssociationFrontend


def run(args: Sequence[int] | None = None) -> None:
    _cli = get_cli(args)
    back = AssociationStudioBackend()
    front = AssociationFrontend(back)
    front.show()


def main() -> None:
    run()  # pragma: no cover
