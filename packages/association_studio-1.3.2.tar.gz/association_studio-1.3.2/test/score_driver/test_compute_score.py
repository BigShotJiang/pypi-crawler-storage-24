"""."""

import pytest

from association_studio.common import FVT
from association_studio.score_driver.score_driver import ScoreDriver


def test_compute_score(vec_z: FVT, driver: ScoreDriver) -> None:
    driver.compute_score(vec_z)
    assert driver.score == pytest.approx(0.7054992044360596)
