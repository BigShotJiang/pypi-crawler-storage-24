"""."""

import pytest

from association_studio.score_driver.score_driver import ScoreDriver


def test_init(driver: ScoreDriver) -> None:
    assert driver.score == pytest.approx(0.0)
    assert driver.det_1z.shape == (1, 10)
    assert driver.buf_1z.shape == (1, 10)
    num_metrics = 4
    assert len(driver.metric_drivers) == num_metrics
    assert len(driver.scores) == num_metrics
    assert len(driver.metric_names) == num_metrics
