"""."""

from association_studio.score_driver.score_driver import ScoreDriver


def test_set_association_metric(driver: ScoreDriver) -> None:
    assert driver.metric_index == 3
    driver.set_association_metric('mahalanobis')
    assert driver.metric_index == 2
