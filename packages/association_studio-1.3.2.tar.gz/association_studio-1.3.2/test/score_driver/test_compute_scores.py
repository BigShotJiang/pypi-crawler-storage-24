"""."""

import pytest

from association_studio.common import FVT
from association_studio.score_driver.score_driver import ScoreDriver


def test_compute_scores(vec_z: FVT, driver: ScoreDriver) -> None:
    driver.compute_scores(vec_z)
    ref = [0.13737373737373737, 0.19856674033889227, 0.1866537467790667, 0.7054992044360596]
    assert driver.scores == pytest.approx(ref)
