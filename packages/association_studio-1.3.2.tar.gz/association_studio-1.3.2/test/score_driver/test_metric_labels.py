"""."""

from association_studio.score_driver.metric_labels import get_labels


def test_get_labels() -> None:
    assert get_labels(['1-2', '1', '1-2-3']) == ['1\n2', '1', '1\n2-3']
