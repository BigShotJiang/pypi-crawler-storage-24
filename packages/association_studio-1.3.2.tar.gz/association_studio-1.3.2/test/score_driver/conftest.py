"""."""

import numpy as np
import pytest

from association_studio.common import FVT
from association_studio.score_driver.score_driver import ScoreDriver


@pytest.fixture
def vec_z() -> FVT:
    return np.array([2.0, 3.0, 4.0, 1.0, 0.1, 0.2, 0.3, 5.0, 2.0, 6.0])


@pytest.fixture
def driver() -> ScoreDriver:
    return ScoreDriver()
