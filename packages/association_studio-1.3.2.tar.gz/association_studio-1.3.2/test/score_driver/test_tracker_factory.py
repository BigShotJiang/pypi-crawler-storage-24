"""."""

import numpy as np
import pytest

from kinematic_tracker import NdKkfTracker

from association_studio.score_driver.tracker_factory import get_low_order_nu_scenes_tracker


def test_it() -> None:
    tracker = get_low_order_nu_scenes_tracker()
    assert isinstance(tracker, NdKkfTracker)
    assert tracker.shape.orders_x.tolist() == [1, 1, 1]
    assert tracker.cov_zz == pytest.approx(np.eye(10))
