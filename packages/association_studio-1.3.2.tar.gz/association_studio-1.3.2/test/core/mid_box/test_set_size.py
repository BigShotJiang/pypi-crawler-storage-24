"""."""

import pytest

from association_studio.core.mid_box import Box


def test_set_size(box: Box) -> None:
    box.set_size(1.23, 3.45, 6.78)
    assert box.vec_z[7:] == pytest.approx((1.23, 3.45, 6.78))
