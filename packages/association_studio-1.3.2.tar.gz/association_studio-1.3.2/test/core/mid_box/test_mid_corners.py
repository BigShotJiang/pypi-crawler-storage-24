"""."""

import numpy as np
import pytest

from association_studio.core.mid_box import Box


def test_mid_corners(box: Box) -> None:
    corners = box.mid_corners()
    # fmt: off
    ref = [
        [0.3945578231292516, 0.44897959183673486, 1.6054421768707483, 1.5510204081632653],
        [4.64625850340136, 4.183673469387755, -0.6462585034013602, -0.18367346938775508],
        [1.3027210884353744, 5.275510204081632, 4.697278911564625, 0.7244897959183674]
    ]
    # fmt: on
    assert corners == pytest.approx(np.array(ref))
