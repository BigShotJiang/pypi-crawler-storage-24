"""."""

import pytest

from association_studio.core.mid_box import Box


def test_init(box: Box) -> None:
    assert box.vec_z == pytest.approx((1.0, 2.0, 3.0, 7.0, 8.0, 9.0, 10.0, 4.0, 5.0, 6.0))
