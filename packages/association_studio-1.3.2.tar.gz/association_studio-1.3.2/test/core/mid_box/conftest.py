"""."""

import numpy as np
import pytest

from association_studio.core.mid_box import Box


@pytest.fixture
def box() -> Box:
    return Box(np.array((1.0, 2.0, 3.0, 7.0, 8.0, 9.0, 10.0, 4.0, 5.0, 6.0)))
