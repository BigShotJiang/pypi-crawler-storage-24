"""."""

import numpy as np
import pytest

from association_studio.core.mid_box import Box


def test_translate(box: Box) -> None:
    box.translate(np.array((1.0, 2.0, 3.0)))
    assert box.vec_z[:3] == pytest.approx((2.0, 4.0, 6.0))
