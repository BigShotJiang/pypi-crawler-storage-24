"""."""

import numpy as np
import pytest

from association_studio.core.mid_box import Box


def test_rotate(box: Box) -> None:
    box.rotate(np.array((1.0, 2.0, 3.0, 4.0)))
    ref = 0.809243648999924, -0.29814239699997197, -0.191662969499982, -0.468509480999956
    assert box.vec_z[3:7] == pytest.approx(ref)
