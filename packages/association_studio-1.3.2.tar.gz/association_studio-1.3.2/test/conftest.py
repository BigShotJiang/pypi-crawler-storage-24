"""."""

import os

from pathlib import Path
from typing import Generator

import matplotlib.pyplot as plt
import pytest


@pytest.fixture
def files_dir() -> Path:
    """."""
    return Path(__file__).parent / 'files'


@pytest.fixture(autouse=True)
def cd_tmp_path(tmp_path: Path) -> Generator[Path, None, None]:
    """."""
    orig_path = Path.cwd()
    os.chdir(tmp_path)
    yield tmp_path
    os.chdir(orig_path)


@pytest.fixture
def ax() -> plt.Axes:
    ax = plt.gca()
    ax.clear()
    yield ax
    plt.close()
