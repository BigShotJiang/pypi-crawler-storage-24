"""."""

import matplotlib.pyplot as plt
import pytest

from association_studio.mpl_vis.horizontal_bar import get_fig_axes


def test_get_fig_axes():
    fig, ax = get_fig_axes()
    assert isinstance(fig, plt.Figure)
    assert isinstance(ax, plt.Axes)
    assert fig.get_figwidth() == pytest.approx(5.0)
    assert fig.get_figheight() == pytest.approx(2.5)
    assert fig.get_dpi() == pytest.approx(100.0)
    assert fig.canvas.manager.get_window_title() == 'Association Studio: metrics'
