"""."""

import matplotlib.pyplot as plt
import numpy as np
import pytest

from association_studio.mpl_vis.prepare_axes import prepare_axes


def test_prepare_axes(ax: plt.Axes) -> None:
    """."""
    prepare_axes(ax, np.array([(-4.0, -5.0), (6.0, 7.0)]))
    assert ax.get_xlim() == pytest.approx((-4.0, 6.0))
    assert ax.get_ylim() == pytest.approx((-5.0, 7.0))
