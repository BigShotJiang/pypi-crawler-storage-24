"""."""

import numpy as np
import pytest

from association_studio.core.mid_box import Box


@pytest.fixture
def box() -> Box:
    return Box(np.array([2.0, 3.0, 4.0, 1.0, 0.1, 0.2, 0.3, 5.0, 2.0, 6.0]))
