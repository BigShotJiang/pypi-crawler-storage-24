"""."""

from kinematic_tracker.association.association_metric import AssociationMetric

from association_studio.app.metric_mode import MetricMode


def test_metric_mode() -> None:
    """."""
    mm = MetricMode()
    assert len(mm.choices) > 1
    assert mm.choices[0] == AssociationMetric.GIOU_AXES_ALIGNED
    assert mm.metric == mm.choices[0]


def test_next() -> None:
    mm = MetricMode()
    mm.next()
    assert mm.metric == mm.choices[1]
    mm.next()
    assert mm.metric == mm.choices[2]
    mm.next()
    assert mm.metric == mm.choices[3]
    mm.next()
    assert mm.metric == mm.choices[0]
