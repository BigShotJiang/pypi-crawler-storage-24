"""."""

from association_studio.app.front import AssociationFrontend


def test_on_release(front: AssociationFrontend) -> None:
    """."""
    front.pick_events.append('anything here')
    front.on_release('Anything')
    assert front.pick_events == []
