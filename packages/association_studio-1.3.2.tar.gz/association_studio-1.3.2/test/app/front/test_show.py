"""."""

from pytest_mock import MockerFixture

from association_studio.app.front import AssociationFrontend, PltHolder


def test_show(front: AssociationFrontend, mocker: MockerFixture) -> None:
    mock_show = mocker.patch.object(PltHolder, 'show')
    front.show()
    mock_show.assert_called_once_with(block=True)
