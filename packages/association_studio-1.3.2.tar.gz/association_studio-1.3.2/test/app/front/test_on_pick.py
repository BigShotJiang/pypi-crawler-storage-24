"""."""

from matplotlib.backend_bases import PickEvent
from pytest_mock import MockerFixture

from association_studio.app.front import AssociationFrontend


def test_on_pick(front: AssociationFrontend, mocker: MockerFixture, pick: PickEvent) -> None:
    mock_start = mocker.patch.object(front.back, 'start_pose_change')
    front.on_pick(pick)
    assert front.pick_events == [pick]
    mock_start.assert_called_once()
