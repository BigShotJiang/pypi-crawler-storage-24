"""."""

from matplotlib.backend_bases import MouseEvent, PickEvent
from pytest_mock import MockerFixture

from association_studio.app.front import AssociationFrontend


def test_no_picks(front: AssociationFrontend, mocker: MockerFixture) -> None:
    mouse_event = MouseEvent('mouse move', front.ax_boxes.figure.canvas, 100, 200)
    mock_chg = mocker.patch.object(front.back, 'change_trk_pose')
    front.on_move(mouse_event)
    mock_chg.assert_not_called()


def test_1_pick(front: AssociationFrontend, mocker: MockerFixture, pick: PickEvent) -> None:
    mouse_event = MouseEvent('mouse move', front.ax_boxes.figure.canvas, 100, 200)
    mock_chg = mocker.patch.object(front.back, 'change_trk_pose')
    mock_upd_bar = mocker.patch.object(front.back, 'update_horizontal_bar_container')
    front.pick_events.append(pick)
    front.on_move(mouse_event)
    mock_chg.assert_called_once_with(pick, mouse_event)
    mock_upd_bar.assert_called_once_with(front.bar)
