"""."""

from association_studio.app.back import AssociationStudioBackend
from association_studio.app.show_coo_mode import ShowCooMode


def test_next_show_coo_mode(be: AssociationStudioBackend) -> None:
    be.next_show_coo_mode()
    assert be.show_coo_mode == ShowCooMode.TRANSLATION
