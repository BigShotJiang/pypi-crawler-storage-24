"""."""

from association_studio.app.back import AssociationStudioBackend


def test_get_text(be: AssociationStudioBackend) -> None:
    assert be.get_text() == 'xy 0.300 0.700 w rz 0.928 -0.371'
