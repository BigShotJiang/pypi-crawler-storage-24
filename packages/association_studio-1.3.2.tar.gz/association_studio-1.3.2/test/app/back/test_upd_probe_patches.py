"""."""

import numpy as np
import pytest

from association_studio.app.back import AssociationStudioBackend
from association_studio.core.mid_box import Box


def test_upd_probe_patches(be: AssociationStudioBackend, box: Box) -> None:
    be.box_probe = box
    be.upd_probe_patches()
    # fmt: off
    ref = [
        [0.3945578231292516, 4.64625850340136], [0.44897959183673486, 4.183673469387755],
        [1.6054421768707483, -0.6462585034013602], [1.5510204081632653, -0.18367346938775508],
        [0.3945578231292516, 4.64625850340136]]
    # fmt: on
    assert be.probe_poly.get_xy() == pytest.approx(np.array(ref))
    assert be.probe_circle.get_center() == pytest.approx([1.5782312925170068, -0.4149659863945576])
