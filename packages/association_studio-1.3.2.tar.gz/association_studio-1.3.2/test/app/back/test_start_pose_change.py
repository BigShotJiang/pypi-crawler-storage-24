"""."""

import pytest

from association_studio.app.back import AssociationStudioBackend


def test_start_pose_change(be: AssociationStudioBackend) -> None:
    be.box_probe.translate([1, 2, 3])
    be.start_pose_change()
    assert be.box_probe_start_pose_change.vec_z == pytest.approx(be.box_probe.vec_z)
    assert id(be.box_probe_start_pose_change) != id(be.box_ref)
