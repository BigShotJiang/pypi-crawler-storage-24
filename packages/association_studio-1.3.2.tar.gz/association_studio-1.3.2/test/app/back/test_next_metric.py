"""."""

from kinematic_tracker.association.association_metric import AssociationMetric

from association_studio.app.back import AssociationStudioBackend


def test_next_metric(be: AssociationStudioBackend) -> None:
    be.next_metric()
    assert be.metric_mode.metric == AssociationMetric.GIOU_YAW
