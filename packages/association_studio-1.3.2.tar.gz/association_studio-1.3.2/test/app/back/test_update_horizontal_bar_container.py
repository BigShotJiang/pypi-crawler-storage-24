"""."""

import matplotlib.pyplot as plt
import pytest

from association_studio.app.back import AssociationStudioBackend


def test_it(be: AssociationStudioBackend, ax: plt.Axes) -> None:
    bar = ax.barh(range(4), range(4))
    be.update_horizontal_bar_container(bar)
    scores = [b.get_width() for b in bar]
    ref = [0.750544669098498, 0.6253507035390544, 0.9820862284644366, 0.9928743432859878]
    assert scores == pytest.approx(ref)
