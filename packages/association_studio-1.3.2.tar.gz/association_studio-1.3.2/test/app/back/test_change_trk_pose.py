"""."""

import matplotlib.pyplot as plt
import pytest

from matplotlib.backend_bases import MouseEvent, PickEvent

from association_studio.app.back import AssociationStudioBackend


def test_translate(ax: plt.Axes, be: AssociationStudioBackend) -> None:
    canvas = ax.figure.canvas
    mouse_event_pick = MouseEvent('mouse-pick', canvas, 100, 200)
    pick_event = PickEvent('pick', ax.figure.canvas, mouse_event_pick, be.probe_poly)
    mouse_event_move = MouseEvent('mouse-move', canvas, 110, 210)
    be.change_trk_pose(pick_event, mouse_event_move)
    assert be.box_probe.vec_z[:3] == pytest.approx([0.32016129, 0.72705628, 0.0])
    assert be.box_probe.vec_z[3:7] == pytest.approx(
        [0.9284766908852592, 0.0, 0.0, -0.3713906763541037]
    )
    assert be.box_probe.vec_z[7:] == pytest.approx([2.0, 4.0, 1.0])


def test_rotate(ax: plt.Axes, be: AssociationStudioBackend) -> None:
    canvas = ax.figure.canvas
    mouse_event_pick = MouseEvent('mouse-pick', canvas, 100, 200)
    pick_event = PickEvent('pick', ax.figure.canvas, mouse_event_pick, be.probe_circle)
    mouse_event_move = MouseEvent('mouse-move', canvas, 110, 210)
    be.change_trk_pose(pick_event, mouse_event_move)
    assert be.box_probe.vec_z[:3] == pytest.approx([0.3, 0.7, 0.0])
    assert be.box_probe.vec_z[3:7] == pytest.approx([0.92726528078645, 0.0, 0.0, -0.37440499335348])
    assert be.box_probe.vec_z[7:] == pytest.approx([2.0, 4.0, 1.0])
