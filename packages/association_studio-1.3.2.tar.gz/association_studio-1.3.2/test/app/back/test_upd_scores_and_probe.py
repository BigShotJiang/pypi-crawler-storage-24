"""."""

import pytest

from pytest_mock import MockerFixture

from association_studio.app.back import AssociationStudioBackend
from association_studio.core.mid_box import Box


def test_upd_scores_and_probe(
    be: AssociationStudioBackend, mocker: MockerFixture, box: Box
) -> None:
    be.box_probe = box
    mock_upd_probe_patches = mocker.patch.object(be, 'upd_probe_patches')
    mock_upd_ref_patches = mocker.patch.object(be, 'upd_ref_patches')
    be.upd_scores_and_probe()
    mock_upd_probe_patches.assert_called_once()
    mock_upd_ref_patches.assert_called_once()
    ref = [0.3812619345104788, 0.365317294791605, 0.0002960447300568554, 0.0007229044081617246]
    assert be.score_driver.scores == pytest.approx(ref)
