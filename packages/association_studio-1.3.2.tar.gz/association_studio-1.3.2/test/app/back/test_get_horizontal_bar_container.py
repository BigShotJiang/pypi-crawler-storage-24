"""."""

import matplotlib.pyplot as plt

from matplotlib.container import BarContainer

from association_studio.app.back import AssociationStudioBackend


def test_it(be: AssociationStudioBackend, ax: plt.Axes) -> None:
    bar_h = be.get_horizontal_bar_container(ax)
    assert isinstance(bar_h, BarContainer)
