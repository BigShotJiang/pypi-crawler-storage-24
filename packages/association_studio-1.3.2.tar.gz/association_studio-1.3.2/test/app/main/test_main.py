"""."""

import matplotlib.pyplot as plt

from pytest_mock import MockerFixture

from association_studio.app.front import PltHolder
from association_studio.app.main import run


def test_run(ax: plt.Axes, mocker: MockerFixture) -> None:
    mock_ion = mocker.patch.object(PltHolder, 'ion')
    mock_show = mocker.patch.object(PltHolder, 'show')
    run([])
    mock_ion.assert_called_once()
    mock_show.assert_called_once_with(block=True)
