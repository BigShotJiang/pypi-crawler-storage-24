from association_studio.app.cli import AssociationStudioCli, get_cli


def test_class() -> None:
    cli = AssociationStudioCli()
    assert cli.verbosity == 0


def test_factory_no_args() -> None:
    cli = get_cli([])
    assert cli.verbosity == 0


def test_factory_args() -> None:
    cli = get_cli(['-v'])
    assert cli.verbosity == 1
