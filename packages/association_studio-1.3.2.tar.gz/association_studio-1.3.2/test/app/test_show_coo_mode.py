"""."""

from association_studio.app.show_coo_mode import ShowCooMode
from association_studio.core.mid_box import Box


def test_next() -> None:
    assert ShowCooMode(0).next() == 1
    assert ShowCooMode(1).next() == 2
    assert ShowCooMode(2).next() == 3
    assert ShowCooMode(3).next() == 0


def test_format(box: Box) -> None:
    assert ShowCooMode.TRANSLATION_AND_ROTATION.format(box) == 'xy 2.000 3.000 w rz 1.000 0.300'
    assert ShowCooMode.TRANSLATION.format(box) == 'xy 2.000 3.000'
    assert ShowCooMode.ROTATION.format(box) == 'w rz 1.000 0.300'
    assert ShowCooMode.NOTHING.format(box) == ''
