## Development install

```shell
uv sync
```

### Add dependencies

Regular or development dependencies are added as following
```shell
uv add numpy
uv add pytest --dev
```

### Run tests

```shell
uv run pytest
```

### Formatting and checking 

```shell
ruff format
ruff check --fix
```

### Bump version number 

```shell
bump-my-version bump patch
```

### Publishing the packages to PyPI registry

```shell
rm -rf dist
uv build
uv publish
```

Probably the authentication used during installation will be effective for uploading the packages.

### Upgrading the dependencies

```shell
uv sync -U
```

or if you want to update a single `<package>`: 

```shell
uv sync -P <package>
```
