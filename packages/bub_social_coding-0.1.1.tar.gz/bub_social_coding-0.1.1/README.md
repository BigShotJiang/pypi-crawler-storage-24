# bub-social-coding

Social coding control-plane plugin for the [Bub fork](https://github.com/ximenzun/bub).

## Install

> Note
> This package targets the `ximenzun/bub` fork. It is not an official `bubbuild/bub` plugin package, and compatibility with upstream Bub should not be assumed.

Once published:

```bash
uv pip install bub-social-coding
```

For local development next to the Bub repo:

```bash
cd /path/to/bub-social-coding
uv sync
```

## What It Adds

- repo binding and repo control commands for social sessions
- git workflow helpers exposed through slash commands
- bundled skills for repo control, git workflow, and social coding policy

## Usage

Once installed, Bub auto-discovers the plugin through entry points.

The plugin adds slash commands like:

- `/repo`
- `/git`

For local validation:

```bash
uv run pytest -q
uv run bub hooks
```

## Release

Publishing is driven by GitHub Actions.
Create a GitHub Release on `main` with a tag like `v0.1.0` or `0.1.0`, and the release workflow will:

1. normalize the tag to a package version
2. build the sdist and wheel
3. publish to PyPI through Trusted Publishing (GitHub OIDC)

No long-lived `PYPI_TOKEN` secret is required when PyPI Trusted Publisher is configured for `.github/workflows/on-release-main.yml`.

## Contributing

See [CONTRIBUTING.md](./CONTRIBUTING.md) for the local workflow, verification commands, and pull request process.
