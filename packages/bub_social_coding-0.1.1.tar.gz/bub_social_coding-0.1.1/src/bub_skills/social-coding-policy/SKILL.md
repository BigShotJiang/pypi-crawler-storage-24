---
name: social-coding-policy
description: |
  Social-platform coding policy for Bub. Use when Bub is operating through WeCom,
  Telegram, Lark, or similar chat channels and needs to keep repository selection,
  git inspection, and risky changes explicit and auditable.
---

# Social Coding Policy

## Required Behavior

1. Treat social coding as a controlled workflow, not an implicit shell session.
2. Never infer the active repo from memory alone; use repo binding state.
3. Never infer the active branch from memory alone; use `git_preflight`.
4. If repo binding is missing, ask to bind or bind to one allowed alias before coding.
5. If the task may affect unrelated local changes, surface that risk before modifying files.
6. For long-running work, use `social.progress` during execution and close the loop with `social.complete` or `social.fail`.

## Response Style

- Keep repo facts explicit: repo alias, workspace path, branch, dirty status.
- When blocked on repo selection or safety ambiguity, state that clearly instead of guessing.
