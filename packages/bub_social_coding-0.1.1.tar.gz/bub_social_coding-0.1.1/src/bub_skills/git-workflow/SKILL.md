---
name: git-workflow
description: |
  Git inspection and safe change workflow for Bub social coding sessions. Use when
  Bub needs to inspect branch state, review dirty changes, or prepare a safe edit/test/commit flow.
---

# Git Workflow Skill

## Policy

1. Before making any git or branch claim, call `git_preflight`.
2. Before code edits, confirm the bound repo with `repo_status`.
3. Prefer this order: inspect -> branch -> edit -> test -> commit -> PR.
4. If the repo is dirty and the task did not ask to work on existing changes, report that explicitly before editing.

## Tool Usage

- `git_preflight`
- `repo_status`
- builtin `bash`
- builtin `fs_read`
- builtin `fs_edit`
- builtin `fs_write`

## Internal Command Example

```text
,git.preflight
```
