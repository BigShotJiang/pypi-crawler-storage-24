---
name: repo-control
description: |
  Repository binding workflow for Bub social coding sessions. Use when Bub needs
  to list allowed repositories, bind the current social session to a repository,
  inspect the active binding, or clear a stale binding before coding work begins.
---

# Repo Control Skill

Use this skill before repo-specific code work in social channels.

## Policy

1. If the task refers to a repo and no repo is bound, call `repo_list` first.
2. Bind with `repo_bind` before claiming current branch, changed files, or workspace contents.
3. Use `repo_status` to confirm the active binding and current git snapshot.
4. Use `repo_clear` if the conversation needs to switch repositories.
5. If the repo catalog changed outside the current process, call `repo_reload` before binding.
6. `repo_reload`, `repo_register`, and `repo_unregister` are admin-only commands.
7. Use `repo_register` and `repo_unregister` only when repo registration is explicitly enabled.

## Tool Usage

- `repo_list`
- `repo_bind`
- `repo_status`
- `repo_clear`
- `repo_reload`
- `repo_register`
- `repo_unregister`

## Internal Command Examples

```text
,repo.list
,repo.bind alias=bub
,repo.status
,repo.clear
,repo.reload
```
