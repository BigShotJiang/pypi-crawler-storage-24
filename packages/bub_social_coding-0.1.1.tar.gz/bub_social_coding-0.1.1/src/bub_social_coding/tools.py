from __future__ import annotations

import re
from typing import Any

from bub.social import ConversationRef, LiveSurfaceRef, OutboundAction, ReplyGrant
from bub.tools import tool
from republic import ToolContext

from bub_social_coding.git_snapshot import collect_git_snapshot
from bub_social_coding.runtime import SocialCodingRuntime


def _runtime(context: ToolContext) -> SocialCodingRuntime:
    runtime = context.state.get("_social_coding_runtime")
    if not isinstance(runtime, SocialCodingRuntime):
        raise TypeError("social-coding runtime is not available in this session")
    return runtime


def _binding_key(context: ToolContext) -> str:
    key = context.state.get("_social_coding_binding_key")
    if not isinstance(key, str) or not key:
        raise RuntimeError("social-coding binding key is not available for this session")
    return key


def _is_admin(context: ToolContext) -> bool:
    return bool(context.state.get("_social_coding_is_admin"))


async def _append_tape_event(context: ToolContext, name: str, payload: dict[str, Any]) -> None:
    agent = context.state.get("_runtime_agent")
    tape_name = context.tape or ""
    if not tape_name or agent is None:
        return
    append_event = getattr(agent.tapes, "append_event", None)
    if callable(append_event):
        await append_event(tape_name, name, payload)


async def _dispatch_action(context: ToolContext, action: OutboundAction) -> None:
    agent = context.state.get("_runtime_agent")
    framework = getattr(agent, "framework", None)
    if framework is None:
        raise RuntimeError("social progress dispatch requires a runtime agent with framework access")
    dispatched = await framework.dispatch_via_router(action)
    if not dispatched:
        raise RuntimeError("no outbound router handled the social progress action")


@tool(context=True, name="repo.list")
def repo_list(*, context: ToolContext) -> str:
    """List allowed repository aliases for social coding sessions."""
    runtime = _runtime(context)
    return _render_repo_list(runtime.registry.list())


@tool(context=True, name="repo.reload")
def repo_reload(*, context: ToolContext) -> str:
    """Reload the repo registry file from disk."""
    runtime = _runtime(context)
    _require_admin(context)
    runtime.reload_registry()
    return "Repo registry reloaded.\n\n" + _render_repo_list(runtime.registry.list())


@tool(context=True, name="repo.status")
def repo_status(*, context: ToolContext) -> str:
    """Show the current repo binding and the latest git snapshot for this social session."""
    runtime = _runtime(context)
    binding = runtime.binding_for_key(_binding_key(context))
    repo = runtime.repo_for_binding(binding)
    snapshot = collect_git_snapshot(repo.path) if repo is not None else None
    return _render_repo_status(binding, repo, snapshot)


@tool(context=True, name="repo.bind")
async def repo_bind(alias: str, *, context: ToolContext) -> str:
    """Bind the current social session to one allowed repository alias."""
    runtime = _runtime(context)
    scope = context.state.get("_social_coding_scope")
    session_id = context.state.get("session_id")
    if not isinstance(scope, str) or not isinstance(session_id, str):
        raise TypeError("social-coding scope or session_id is missing")
    binding = runtime.bind_repo(
        key=_binding_key(context),
        scope=scope,
        session_id=session_id,
        alias=alias,
        metadata={"bound_via": "tool"},
    )
    repo = runtime.repo_for_binding(binding)
    if repo is None:
        raise RuntimeError(f"repo binding created but alias '{alias}' is unavailable")
    context.state["_social_coding_binding"] = binding
    context.state["_social_coding_repo"] = repo
    context.state["_runtime_workspace"] = str(repo.path)
    context.state["_social_coding_git"] = runtime.snapshot_for_repo(repo)
    await _append_tape_event(context, "social_coding.repo_bound", {"alias": alias, "workspace": str(repo.path)})
    return "\n".join(
        [
            f"Bound current session to repo '{binding.repo_alias}'.",
            f"Workspace: {binding.workspace_path}",
            f"Default branch: {repo.default_branch or '(unknown)'}",
            f"Writable: {_yes_no(repo.writable)}",
        ]
    )


@tool(context=True, name="repo.clear")
async def repo_clear(*, context: ToolContext) -> str:
    """Clear the current social session's repo binding."""
    runtime = _runtime(context)
    key = _binding_key(context)
    binding = runtime.binding_for_key(key)
    runtime.clear_binding(key)
    context.state.pop("_social_coding_binding", None)
    context.state.pop("_social_coding_repo", None)
    context.state.pop("_social_coding_git", None)
    await _append_tape_event(context, "social_coding.repo_cleared", {"binding_key": key})
    if binding is None:
        return "No repo binding was active for this session."
    return f"Cleared repo binding for alias '{binding.repo_alias}'."


@tool(context=True, name="repo.register")
async def repo_register(
    alias: str,
    path: str,
    default_branch: str | None = None,
    writable: bool = True,
    *,
    context: ToolContext,
) -> str:
    """Register a new repository alias in the repo registry file."""
    runtime = _runtime(context)
    _require_repo_registration_enabled(runtime)
    _require_admin(context)
    repo = runtime.registry.register(alias=alias, path=path, default_branch=default_branch, writable=writable)
    await _append_tape_event(context, "social_coding.repo_registered", repo.as_dict())
    return "\n".join(
        [
            f"Registered repo '{repo.alias}'.",
            f"Workspace: {repo.path}",
            f"Default branch: {repo.default_branch or '(unknown)'}",
            f"Writable: {_yes_no(repo.writable)}",
        ]
    )


@tool(context=True, name="repo.unregister")
async def repo_unregister(alias: str, *, context: ToolContext) -> str:
    """Remove one repository alias from the repo registry file."""
    runtime = _runtime(context)
    _require_repo_registration_enabled(runtime)
    _require_admin(context)
    removed = runtime.registry.unregister(alias)
    payload = {"alias": alias, "removed": removed.as_dict() if removed is not None else None}
    await _append_tape_event(context, "social_coding.repo_unregistered", payload)
    if removed is None:
        return f"Repo alias '{alias}' was not registered."
    return f"Unregistered repo '{removed.alias}'."


@tool(context=True, name="git.preflight")
async def git_preflight(*, context: ToolContext) -> str:
    """Collect current git branch, status, changed files, and remotes for the bound repo/workspace."""
    runtime = _runtime(context)
    repo = context.state.get("_social_coding_repo")
    if repo is None:
        binding = runtime.binding_for_key(_binding_key(context))
        repo = runtime.repo_for_binding(binding)
    workspace = repo.path if repo is not None else runtime.workspace
    snapshot = collect_git_snapshot(workspace)
    context.state["_social_coding_git"] = snapshot
    payload = snapshot.as_dict() if snapshot is not None else {"repo_root": str(workspace), "git": False}
    await _append_tape_event(context, "social_coding.git_preflight", payload)
    return _render_git_preflight(snapshot, workspace)


@tool(context=True, name="social.progress")
async def social_progress(text: str, *, context: ToolContext) -> str:
    """Send a platform-aware progress update for the current social session."""
    conversation = _conversation(context)
    action = _progress_action(context, conversation, text)
    await _dispatch_action(context, action)
    await _append_tape_event(
        context,
        "social_coding.progress",
        {"kind": action.kind, "platform": conversation.platform, "route_channel": conversation.channel_key, "text": text},
    )
    return _render_social_dispatch("progress", conversation, action, text)


@tool(context=True, name="social.complete")
async def social_complete(text: str, *, context: ToolContext) -> str:
    """Send a platform-aware completion update for the current social session."""
    conversation = _conversation(context)
    action = _final_status_action(context, conversation, "complete", text)
    await _dispatch_action(context, action)
    await _append_tape_event(
        context,
        "social_coding.complete",
        {"kind": action.kind, "platform": conversation.platform, "route_channel": conversation.channel_key, "text": text},
    )
    return _render_social_dispatch("complete", conversation, action, text)


@tool(context=True, name="social.fail")
async def social_fail(text: str, *, context: ToolContext) -> str:
    """Send a platform-aware failure update for the current social session."""
    conversation = _conversation(context)
    action = _final_status_action(context, conversation, "fail", text)
    await _dispatch_action(context, action)
    await _append_tape_event(
        context,
        "social_coding.fail",
        {"kind": action.kind, "platform": conversation.platform, "route_channel": conversation.channel_key, "text": text},
    )
    return _render_social_dispatch("fail", conversation, action, text)


def _require_repo_registration_enabled(runtime: SocialCodingRuntime) -> None:
    if runtime.settings.allow_repo_registration:
        return
    raise RuntimeError("repo registration is disabled. Set BUB_SOCIAL_CODING_ALLOW_REPO_REGISTRATION=true to enable it.")


def _require_admin(context: ToolContext) -> None:
    if _is_admin(context):
        return
    raise RuntimeError("admin privileges are required for this repo management command.")


def _conversation(context: ToolContext) -> ConversationRef:
    conversation = context.state.get("_social_coding_conversation")
    if not isinstance(conversation, ConversationRef):
        raise TypeError("social progress requires a current conversation context")
    return conversation


def _reply_grant(context: ToolContext) -> ReplyGrant | None:
    reply_grant = context.state.get("_social_coding_reply_grant")
    return reply_grant if isinstance(reply_grant, ReplyGrant) else None


def _progress_action(context: ToolContext, conversation: ConversationRef, text: str) -> OutboundAction:
    if conversation.channel_key == "telegram":
        return OutboundAction(
            kind="set_draft",
            conversation=conversation,
            text=text,
            live_surface=LiveSurfaceRef(
                mode="text_draft",
                surface_id=_progress_surface_id(context, conversation),
                parent_message_id=context.state.get("_social_coding_message_id"),
            ),
        )
    if conversation.channel_key == "wecom_longconn_bot":
        return OutboundAction(
            kind="reply_message" if _reply_grant(context) is not None else "send_message",
            conversation=conversation,
            text=_wecom_progress_text(context, text),
            reply_grant=_reply_grant(context),
            reply_to_message_id=context.state.get("_social_coding_message_id"),
        )
    return OutboundAction(kind="presence", conversation=conversation)


def _final_status_action(
    context: ToolContext,
    conversation: ConversationRef,
    phase: str,
    text: str,
) -> OutboundAction:
    formatted = _final_status_text(phase, text)
    if conversation.channel_key == "wecom_longconn_bot":
        return OutboundAction(
            kind="reply_message" if _reply_grant(context) is not None else "send_message",
            conversation=conversation,
            content_type="card",
            card=_wecom_status_card(context, phase, text),
            reply_grant=_reply_grant(context),
            reply_to_message_id=context.state.get("_social_coding_message_id"),
        )
    if conversation.channel_key == "telegram":
        formatted = _telegram_status_text(context, phase, text)
    return OutboundAction(
        kind="reply_message" if _reply_grant(context) is not None else "send_message",
        conversation=conversation,
        text=formatted,
        reply_grant=_reply_grant(context),
        reply_to_message_id=context.state.get("_social_coding_message_id"),
    )


def _progress_surface_id(context: ToolContext, conversation: ConversationRef) -> str:
    key = context.state.get("_social_coding_binding_key")
    seed = key if isinstance(key, str) and key else f"{conversation.channel_key}:{conversation.chat_id}:text_draft"
    return f"draft-{_safe_id(seed)}"


def _safe_id(text: str) -> str:
    return re.sub(r"[^a-zA-Z0-9_.-]+", "-", text).strip("-") or "draft"


def _wecom_progress_text(context: ToolContext, text: str) -> str:
    count = int(context.state.get("_social_progress_count", 0)) + 1
    context.state["_social_progress_count"] = count
    prefix = "Working" if count == 1 else "Update"
    return f"{prefix}: {text}"


def _render_repo_list(repos: list[Any]) -> str:
    if not repos:
        return "Available repos:\n- (none)"
    lines = ["Available repos:"]
    for repo in repos:
        branch = repo.default_branch or "(unknown)"
        mode = "writable" if repo.writable else "read-only"
        lines.append(f"- {repo.alias}: {repo.path} [{branch}, {mode}]")
    return "\n".join(lines)


def _render_repo_status(binding, repo, snapshot) -> str:
    if binding is None and repo is None:
        return "No repo is currently bound to this session."
    lines: list[str] = []
    if binding is not None:
        lines.append(f"Bound repo: {binding.repo_alias}")
        lines.append(f"Workspace: {binding.workspace_path}")
        lines.append(f"Binding scope: {binding.scope}")
    if repo is not None:
        lines.append(f"Default branch: {repo.default_branch or '(unknown)'}")
        lines.append(f"Writable: {_yes_no(repo.writable)}")
    if snapshot is not None:
        lines.extend(["", *_git_snapshot_lines(snapshot)])
    return "\n".join(lines)


def _render_git_preflight(snapshot, workspace) -> str:
    if snapshot is None:
        return f"No git repository found at workspace: {workspace}"
    return "\n".join(_git_snapshot_lines(snapshot))


def _git_snapshot_lines(snapshot) -> list[str]:
    lines = [
        f"Repo root: {snapshot.repo_root}",
        f"Branch: {snapshot.branch or '(detached)'}",
        f"HEAD: {snapshot.head_sha or '(unknown)'}",
        f"Dirty: {_yes_no(snapshot.dirty)}",
    ]
    if snapshot.changed_files:
        lines.append("Changed files:")
        lines.extend(f"- {path}" for path in snapshot.changed_files)
    else:
        lines.append("Changed files: (none)")
    if snapshot.remotes:
        lines.append("Remotes:")
        lines.extend(f"- {item}" for item in snapshot.remotes)
    return lines


def _render_social_dispatch(phase: str, conversation: ConversationRef, action: OutboundAction, text: str) -> str:
    route = conversation.channel_key
    rendered_text = _render_action_preview(action, phase, text)
    return f"Sent {phase} update via {route} using action '{action.kind}': {rendered_text}"


def _final_status_text(phase: str, text: str) -> str:
    prefix = "Done" if phase == "complete" else "Failed"
    return f"{prefix}: {text}"


def _yes_no(value: bool) -> str:
    return "yes" if value else "no"


def _telegram_status_text(context: ToolContext, phase: str, text: str) -> str:
    lines = [_final_status_text(phase, text)]
    lines.extend(_status_summary_lines(context))
    return "\n".join(lines)


def _wecom_status_card(context: ToolContext, phase: str, text: str) -> dict[str, object]:
    title = "Done" if phase == "complete" else "Failed"
    binding = context.state.get("_social_coding_binding")
    snapshot = context.state.get("_social_coding_git")
    repo_alias = getattr(binding, "repo_alias", "session")
    branch = getattr(snapshot, "branch", None) or "(unknown)"
    changed_files = getattr(snapshot, "changed_files", ()) or ()
    summary = f"Branch: {branch} | Changed: {len(changed_files)}"
    return {
        "card_type": "text_notice",
        "source": {"desc": "Bub Social Coding"},
        "main_title": {"title": title, "desc": text},
        "emphasis_content": {"title": repo_alias, "desc": summary},
        "sub_title_text": summary,
        "card_action": {"type": 1, "url": "https://github.com/ximenzun/bub"},
    }


def _status_summary_lines(context: ToolContext) -> list[str]:
    binding = context.state.get("_social_coding_binding")
    snapshot = context.state.get("_social_coding_git")
    repo_alias = getattr(binding, "repo_alias", None)
    branch = getattr(snapshot, "branch", None)
    dirty = getattr(snapshot, "dirty", None)
    changed_files = getattr(snapshot, "changed_files", ()) or ()
    lines: list[str] = []
    if repo_alias is not None:
        lines.append(f"Repo: {repo_alias}")
    if branch is not None:
        lines.append(f"Branch: {branch}")
    if dirty is not None:
        lines.append(f"Dirty: {_yes_no(bool(dirty))}")
    if changed_files:
        preview = ", ".join(changed_files[:3])
        suffix = " ..." if len(changed_files) > 3 else ""
        lines.append(f"Changed: {preview}{suffix}")
    return lines


def _render_action_preview(action: OutboundAction, phase: str, fallback_text: str) -> str:
    if action.card is not None:
        main_title = action.card.get("main_title")
        if isinstance(main_title, dict):
            title = main_title.get("title")
            desc = main_title.get("desc")
            if isinstance(title, str) and isinstance(desc, str):
                return f"{title}: {desc}"
        return f"{phase} card"
    if action.text:
        return action.text
    return fallback_text
