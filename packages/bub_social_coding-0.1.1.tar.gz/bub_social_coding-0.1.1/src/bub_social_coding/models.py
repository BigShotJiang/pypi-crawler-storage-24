from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Literal

BindingScope = Literal["conversation", "thread", "actor", "tenant"]


@dataclass(slots=True, frozen=True)
class RepoSpec:
    alias: str
    path: Path
    default_branch: str | None = None
    writable: bool = True
    metadata: dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        return {
            "alias": self.alias,
            "path": str(self.path),
            "default_branch": self.default_branch,
            "writable": self.writable,
            "metadata": dict(self.metadata),
        }


@dataclass(slots=True, frozen=True)
class RepoBinding:
    key: str
    scope: BindingScope
    session_id: str
    repo_alias: str
    workspace_path: Path
    created_at: datetime
    updated_at: datetime
    metadata: dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        return {
            "key": self.key,
            "scope": self.scope,
            "session_id": self.session_id,
            "repo_alias": self.repo_alias,
            "workspace_path": str(self.workspace_path),
            "created_at": self.created_at.astimezone(UTC).isoformat(),
            "updated_at": self.updated_at.astimezone(UTC).isoformat(),
            "metadata": dict(self.metadata),
        }


@dataclass(slots=True, frozen=True)
class GitSnapshot:
    repo_root: Path
    branch: str | None
    head_sha: str | None
    status_header: str | None
    status_short: str
    dirty: bool
    changed_files: tuple[str, ...]
    remotes: tuple[str, ...]

    def as_dict(self) -> dict[str, Any]:
        return {
            "repo_root": str(self.repo_root),
            "branch": self.branch,
            "head_sha": self.head_sha,
            "status_header": self.status_header,
            "status_short": self.status_short,
            "dirty": self.dirty,
            "changed_files": list(self.changed_files),
            "remotes": list(self.remotes),
        }


@dataclass(slots=True, frozen=True)
class SocialEndpoint:
    platform: str
    route_channel: str
    account_id: str
    chat_id: str
    surface: str
    thread_id: str | None = None
    actor_id: str | None = None
    tenant_id: str | None = None

    def binding_key(self, scope: BindingScope) -> str:
        if scope == "conversation":
            return "|".join((self.platform, self.route_channel, self.account_id, self.chat_id))
        if scope == "thread":
            thread = self.thread_id or self.chat_id
            return "|".join((self.platform, self.route_channel, self.account_id, self.chat_id, thread))
        if scope == "actor":
            actor = self.actor_id or self.chat_id
            return "|".join((self.platform, self.route_channel, self.account_id, actor))
        tenant = self.tenant_id or self.account_id
        return "|".join((self.platform, self.route_channel, tenant))

    def as_dict(self) -> dict[str, Any]:
        return {
            "platform": self.platform,
            "route_channel": self.route_channel,
            "account_id": self.account_id,
            "chat_id": self.chat_id,
            "surface": self.surface,
            "thread_id": self.thread_id,
            "actor_id": self.actor_id,
            "tenant_id": self.tenant_id,
        }

    def actor_tokens(self) -> tuple[str, ...]:
        if not self.actor_id:
            return ()
        actor_id = self.actor_id
        return (actor_id, f"{self.platform}:{actor_id}", f"{self.route_channel}:{actor_id}")

    def chat_tokens(self) -> tuple[str, ...]:
        chat_id = self.chat_id
        return (chat_id, f"{self.platform}:{chat_id}", f"{self.route_channel}:{chat_id}")
