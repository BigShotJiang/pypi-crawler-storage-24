from __future__ import annotations

import shlex


def translate_social_command(content: str) -> str | None:
    stripped = content.strip()
    if not stripped.startswith("/"):
        return None
    tokens = shlex.split(stripped)
    if not tokens:
        return None
    root = tokens[0]
    if root == "/repo":
        return _translate_repo_command(tokens[1:])
    if root == "/git":
        return _translate_git_command(tokens[1:])
    return None


def _translate_repo_command(tokens: list[str]) -> str | None:
    if not tokens:
        return None
    action = tokens[0]
    if action in {"list", "status", "clear", "reload", "unbind"} and len(tokens) == 1:
        mapped = "clear" if action == "unbind" else action
        return f",repo.{mapped}"
    if action in {"bind", "unregister"} and len(tokens) == 2:
        return f",repo.{action} {shlex.quote(tokens[1])}"
    if action in {"list", "status", "clear", "reload", "unbind"}:
        return None
    if action != "register" or len(tokens) < 3:
        return None

    parsed = _parse_repo_register_options(tokens[3:])
    if parsed is None:
        return None
    alias = tokens[1]
    path = tokens[2]
    default_branch, writable = parsed
    parts = [",repo.register", shlex.quote(alias), shlex.quote(path)]
    if default_branch is not None:
        parts.append(f"default_branch={shlex.quote(default_branch)}")
    if not writable:
        parts.append("writable=false")
    return " ".join(parts)


def _translate_git_command(tokens: list[str]) -> str | None:
    if tokens == ["preflight"]:
        return ",git.preflight"
    return None


def _parse_repo_register_options(args: list[str]) -> tuple[str | None, bool] | None:
    default_branch: str | None = None
    writable = True
    index = 0
    while index < len(args):
        argument = args[index]
        if argument in {"--branch", "--default-branch"}:
            if index + 1 >= len(args):
                return None
            default_branch = args[index + 1]
            index += 2
            continue
        if argument == "--readonly":
            writable = False
            index += 1
            continue
        if argument == "--writable":
            writable = True
            index += 1
            continue
        return None
    return default_branch, writable
