from __future__ import annotations

import json
import sqlite3
from contextlib import closing
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from bub_social_coding.models import BindingScope, RepoBinding, RepoSpec


class RepoBindingStore:
    def __init__(self, db_path: Path) -> None:
        self._db_path = db_path.expanduser().resolve()
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        self._initialize()

    def get(self, key: str) -> RepoBinding | None:
        with closing(self._connect()) as conn:
            row = conn.execute(
                """
                select binding_key, scope, session_id, repo_alias, workspace_path, created_at, updated_at, metadata_json
                from repo_bindings
                where binding_key = ?
                """,
                (key,),
            ).fetchone()
        if row is None:
            return None
        return RepoBinding(
            key=row[0],
            scope=row[1],
            session_id=row[2],
            repo_alias=row[3],
            workspace_path=Path(row[4]),
            created_at=datetime.fromisoformat(row[5]),
            updated_at=datetime.fromisoformat(row[6]),
            metadata=json.loads(row[7]) if row[7] else {},
        )

    def bind(
        self,
        *,
        key: str,
        scope: BindingScope,
        session_id: str,
        repo: RepoSpec,
        metadata: dict[str, Any] | None = None,
    ) -> RepoBinding:
        now = datetime.now(UTC)
        existing = self.get(key)
        created_at = existing.created_at if existing is not None else now
        binding = RepoBinding(
            key=key,
            scope=scope,
            session_id=session_id,
            repo_alias=repo.alias,
            workspace_path=repo.path,
            created_at=created_at,
            updated_at=now,
            metadata=metadata or {},
        )
        with closing(self._connect()) as conn:
            conn.execute(
                """
                insert into repo_bindings (
                    binding_key, scope, session_id, repo_alias, workspace_path, created_at, updated_at, metadata_json
                ) values (?, ?, ?, ?, ?, ?, ?, ?)
                on conflict(binding_key) do update set
                    scope = excluded.scope,
                    session_id = excluded.session_id,
                    repo_alias = excluded.repo_alias,
                    workspace_path = excluded.workspace_path,
                    updated_at = excluded.updated_at,
                    metadata_json = excluded.metadata_json
                """,
                (
                    binding.key,
                    binding.scope,
                    binding.session_id,
                    binding.repo_alias,
                    str(binding.workspace_path),
                    binding.created_at.astimezone(UTC).isoformat(),
                    binding.updated_at.astimezone(UTC).isoformat(),
                    json.dumps(binding.metadata, ensure_ascii=False),
                ),
            )
            conn.commit()
        return binding

    def clear(self, key: str) -> None:
        with closing(self._connect()) as conn:
            conn.execute("delete from repo_bindings where binding_key = ?", (key,))
            conn.commit()

    def _connect(self) -> sqlite3.Connection:
        return sqlite3.connect(self._db_path)

    def _initialize(self) -> None:
        with closing(self._connect()) as conn:
            conn.execute(
                """
                create table if not exists repo_bindings (
                    binding_key text primary key,
                    scope text not null,
                    session_id text not null,
                    repo_alias text not null,
                    workspace_path text not null,
                    created_at text not null,
                    updated_at text not null,
                    metadata_json text not null default '{}'
                )
                """
            )
            conn.commit()
