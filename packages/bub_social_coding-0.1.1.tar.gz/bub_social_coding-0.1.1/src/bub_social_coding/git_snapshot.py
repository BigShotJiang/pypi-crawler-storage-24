from __future__ import annotations

import subprocess
from pathlib import Path
from shutil import which

from bub_social_coding.models import GitSnapshot


def collect_git_snapshot(workspace: Path) -> GitSnapshot | None:
    repo_path = resolve_repo_root(workspace)
    if repo_path is None:
        return None
    branch = _git_output(repo_path, ["branch", "--show-current"])
    head_sha = _git_output(repo_path, ["rev-parse", "HEAD"])
    status = _git_output(repo_path, ["status", "--short", "--branch"]) or ""
    status_lines = status.splitlines()
    status_header = status_lines[0] if status_lines else None
    changed_files = tuple(_parse_changed_files(status_lines[1:] if status_lines[:1] else status_lines))
    remotes_output = _git_output(repo_path, ["remote", "-v"]) or ""
    remotes = tuple(line for line in remotes_output.splitlines() if line.strip())
    return GitSnapshot(
        repo_root=repo_path,
        branch=branch or None,
        head_sha=head_sha or None,
        status_header=status_header,
        status_short=status,
        dirty=bool(changed_files),
        changed_files=changed_files,
        remotes=remotes,
    )


def resolve_repo_root(workspace: Path) -> Path | None:
    repo_root = _git_output(workspace, ["rev-parse", "--show-toplevel"])
    if repo_root is None:
        return None
    return Path(repo_root).resolve()


def detect_default_branch(repo_root: Path) -> str | None:
    remote_head = _git_output(repo_root, ["symbolic-ref", "--quiet", "--short", "refs/remotes/origin/HEAD"])
    if remote_head:
        return remote_head.rsplit("/", 1)[-1]
    branch = _git_output(repo_root, ["branch", "--show-current"])
    return branch or None


def _git_output(workspace: Path, args: list[str]) -> str | None:
    git_binary = which("git")
    if git_binary is None:
        return None
    completed = subprocess.run(
        [git_binary, *args],
        cwd=workspace,
        capture_output=True,
        text=True,
        check=False,
    )
    if completed.returncode != 0:
        return None
    return completed.stdout.strip()


def _parse_changed_files(lines: list[str]) -> list[str]:
    changed: list[str] = []
    for line in lines:
        raw = line.strip()
        if not raw:
            continue
        if " -> " in raw:
            changed.append(raw.split(" -> ", 1)[1].strip())
            continue
        if len(raw) > 3:
            changed.append(raw[3:].strip())
    return changed
