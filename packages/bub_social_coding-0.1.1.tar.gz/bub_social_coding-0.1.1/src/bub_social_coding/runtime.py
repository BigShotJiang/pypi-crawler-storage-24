from __future__ import annotations

from collections.abc import Mapping
from pathlib import Path
from typing import Any

from bub.envelope import field_of
from bub.social import ConversationRef, ParticipantRef
from bub.social.compat import conversation_of
from bub.types import Envelope, State

from bub_social_coding.bindings import RepoBindingStore
from bub_social_coding.git_snapshot import collect_git_snapshot
from bub_social_coding.models import BindingScope, GitSnapshot, RepoBinding, RepoSpec, SocialEndpoint
from bub_social_coding.registry import RepoRegistry
from bub_social_coding.settings import SocialCodingSettings


class SocialCodingRuntime:
    def __init__(self, workspace: Path) -> None:
        self.workspace = workspace.resolve()
        self.settings = SocialCodingSettings()
        self.registry = RepoRegistry.from_file(self.settings.repos_file, allowed_roots=self.settings.allowed_root_paths)
        self.store = RepoBindingStore(self.settings.db_path)

    def is_enabled_for_message(self, message: Envelope) -> bool:
        channel = str(field_of(message, "channel", ""))
        output_channel = str(field_of(message, "output_channel", channel))
        enabled = self.settings.enabled_channel_set
        return (channel in enabled) or (output_channel in enabled)

    def endpoint_from_message(self, message: Envelope) -> SocialEndpoint | None:
        conversation = self._conversation_from_message(message)
        if conversation is None:
            return None
        return SocialEndpoint(
            platform=conversation.platform,
            route_channel=conversation.channel_key,
            account_id=conversation.account_id,
            chat_id=conversation.chat_id,
            surface=conversation.surface,
            thread_id=conversation.thread_id,
            actor_id=conversation.actor_id or self._actor_id_from_message(message),
            tenant_id=conversation.tenant_id,
        )

    def scope_for_endpoint(self, endpoint: SocialEndpoint) -> BindingScope:
        if endpoint.surface in {"direct", "business"}:
            return self.settings.direct_scope
        if endpoint.surface == "group":
            return self.settings.group_scope if endpoint.thread_id else "conversation"
        return self.settings.unknown_scope

    def binding_key_for_message(self, message: Envelope) -> tuple[SocialEndpoint | None, BindingScope | None, str | None]:
        endpoint = self.endpoint_from_message(message)
        if endpoint is None:
            return None, None, None
        scope = self.scope_for_endpoint(endpoint)
        return endpoint, scope, endpoint.binding_key(scope)

    def binding_for_key(self, key: str | None) -> RepoBinding | None:
        if not key:
            return None
        return self.store.get(key)

    def repo_for_binding(self, binding: RepoBinding | None) -> RepoSpec | None:
        if binding is None:
            return None
        repo = self.registry.get(binding.repo_alias)
        if repo is not None:
            return repo
        if binding.workspace_path.exists():
            return RepoSpec(alias=binding.repo_alias, path=binding.workspace_path)
        return None

    def snapshot_for_repo(self, repo: RepoSpec | None) -> GitSnapshot | None:
        if repo is None:
            return None
        return collect_git_snapshot(repo.path)

    def bind_repo(
        self,
        *,
        key: str,
        scope: BindingScope,
        session_id: str,
        alias: str,
        metadata: dict[str, Any] | None = None,
    ) -> RepoBinding:
        repo = self.registry.get(alias)
        if repo is None:
            raise ValueError(f"unknown repo alias: {alias}")
        return self.store.bind(key=key, scope=scope, session_id=session_id, repo=repo, metadata=metadata)

    def clear_binding(self, key: str) -> None:
        self.store.clear(key)

    def reload_registry(self) -> None:
        self.registry.reload()

    def is_admin_endpoint(self, endpoint: SocialEndpoint | None) -> bool:
        if endpoint is None:
            return False
        actor_tokens = set(endpoint.actor_tokens())
        if actor_tokens & self.settings.admin_actor_set:
            return True
        chat_tokens = set(endpoint.chat_tokens())
        return bool(chat_tokens & self.settings.admin_chat_set)

    @staticmethod
    def render_prompt_context(state: State) -> str:
        repo = state.get("_social_coding_repo")
        snapshot = state.get("_social_coding_git")
        binding = state.get("_social_coding_binding")
        if repo is None and binding is None:
            return ""
        lines = ["<social_coding_context>"]
        if isinstance(binding, RepoBinding):
            lines.append(f"binding_scope: {binding.scope}")
            lines.append(f"repo_alias: {binding.repo_alias}")
            lines.append(f"workspace: {binding.workspace_path}")
        if isinstance(repo, RepoSpec):
            lines.append(f"repo_default_branch: {repo.default_branch or '(unknown)'}")
            lines.append(f"repo_writable: {repo.writable}")
        if isinstance(snapshot, GitSnapshot):
            lines.append(f"git_branch: {snapshot.branch or '(detached)'}")
            lines.append(f"git_head: {snapshot.head_sha or '(unknown)'}")
            lines.append(f"git_dirty: {snapshot.dirty}")
            if snapshot.status_short:
                lines.append("git_status:")
                lines.extend(f"  {line}" for line in snapshot.status_short.splitlines())
        lines.append("</social_coding_context>")
        return "\n".join(lines)

    @staticmethod
    def _conversation_from_message(message: Envelope) -> ConversationRef | None:
        return conversation_of(message, default_platform=str(field_of(message, "channel", "unknown")))

    @staticmethod
    def _actor_id_from_message(message: Envelope) -> str | None:
        sender = field_of(message, "sender")
        if isinstance(sender, ParticipantRef):
            return sender.id
        if isinstance(sender, Mapping):
            raw = sender.get("id") or sender.get("sender_id") or sender.get("user_id")
            return str(raw) if raw else None
        actor_id = field_of(message, "actor_id")
        if actor_id is None:
            return None
        return str(actor_id)
