from __future__ import annotations

from pathlib import Path

from bub.commands import SlashCommandSpec, translate_registered_slash_command
from bub.envelope import content_of, field_of
from bub.hookspecs import hookimpl
from bub.social.compat import conversation_of, reply_grant_of
from bub.types import Envelope, State

from bub_social_coding.commands import translate_social_command
from bub_social_coding.runtime import SocialCodingRuntime

SYSTEM_PROMPT = """\
<social_coding_instructions>
When handling a social coding session:
1. Never assume the active repo or git branch from memory alone.
2. If the task is repo-specific and no repo is bound, use repo_list and repo_bind first.
3. Before making claims about branch, dirty files, or current changes, call git_preflight.
4. Use the bound repo workspace instead of the process default workspace when a binding exists.
5. Prefer safe workflows: inspect, branch, edit, test, commit, then PR.
6. For long-running work in social channels, use social_progress so the user sees progress in a platform-native way.
</social_coding_instructions>
"""


class SocialCodingPlugin:
    def __init__(self, framework) -> None:
        self.framework = framework
        self.runtime = SocialCodingRuntime(framework.workspace)
        from bub_social_coding import tools  # noqa: F401

    @hookimpl
    def load_state(self, message: Envelope, session_id: str) -> State:
        if not self.runtime.is_enabled_for_message(message):
            return {}
        endpoint, scope, binding_key = self.runtime.binding_key_for_message(message)
        state: State = {
            "_social_coding_runtime": self.runtime,
            "_social_coding_session_id": session_id,
        }
        self._populate_message_state(state, message)
        self._populate_endpoint_state(state, endpoint, scope, binding_key)
        state["_social_coding_is_admin"] = self.runtime.is_admin_endpoint(endpoint)
        binding = self.runtime.binding_for_key(binding_key)
        repo = self.runtime.repo_for_binding(binding)
        snapshot = self.runtime.snapshot_for_repo(repo) if self.runtime.settings.auto_git_preflight else None
        self._populate_repo_state(state, binding, repo, snapshot)
        return state

    @hookimpl
    def build_prompt(self, message: Envelope, session_id: str, state: State) -> str:
        if "_social_coding_runtime" not in state:
            return None
        content = content_of(message)
        if content.startswith(","):
            if hasattr(message, "kind"):
                message.kind = "command"
            return content
        if translated := translate_social_command(content):
            if hasattr(message, "kind"):
                message.kind = "command"
            return translated
        slash_commands_getter = getattr(self.framework, "get_slash_commands", None)
        slash_commands = slash_commands_getter() if callable(slash_commands_getter) else []
        if translated := translate_registered_slash_command(content, slash_commands):
            if hasattr(message, "kind"):
                message.kind = "command"
            return translated
        blocks: list[str] = []
        context = field_of(message, "context_str")
        if context:
            blocks.append(str(context))
        social_context = self.runtime.render_prompt_context(state)
        if social_context:
            blocks.append(social_context)
        blocks.append(content)
        return "\n---\n".join(blocks)

    @hookimpl
    def system_prompt(self, prompt: str, state: State) -> str:
        if "_social_coding_runtime" not in state:
            return ""
        repo = state.get("_social_coding_repo")
        if repo is None:
            return SYSTEM_PROMPT + "\nCurrent repo binding: none.\n"
        repo_path = getattr(repo, "path", Path.cwd())
        return SYSTEM_PROMPT + f"\nCurrent bound workspace: {repo_path}\n"

    @hookimpl
    def provide_slash_commands(self) -> list[SlashCommandSpec]:
        return [
            SlashCommandSpec(
                name="/repo",
                summary="Repo management commands for social coding sessions.",
                usage=(
                    "/repo",
                    "/repo list",
                    "/repo status",
                    "/repo bind <alias>",
                    "/repo clear",
                    "/repo reload",
                    "/repo unregister <alias>",
                    "/repo register <alias> <path> [--branch <name>] [--readonly]",
                ),
                examples=("/repo list", "/repo bind demo", "/repo status"),
            ),
            SlashCommandSpec(
                name="/git",
                summary="Git workflow helpers for the current social coding session.",
                usage=(
                    "/git",
                    "/git preflight",
                ),
                examples=("/git preflight",),
            ),
        ]

    @staticmethod
    def _populate_message_state(state: State, message: Envelope) -> None:
        if conversation := conversation_of(message, default_platform=str(field_of(message, "channel", "unknown"))):
            state["_social_coding_conversation"] = conversation
        if reply_grant := reply_grant_of(message):
            state["_social_coding_reply_grant"] = reply_grant
        if message_id := field_of(message, "message_id"):
            state["_social_coding_message_id"] = str(message_id)

    @staticmethod
    def _populate_endpoint_state(
        state: State,
        endpoint,
        scope,
        binding_key: str | None,
    ) -> None:
        if endpoint is not None:
            state["_social_coding_endpoint"] = endpoint
        if scope is not None:
            state["_social_coding_scope"] = scope
        if binding_key is not None:
            state["_social_coding_binding_key"] = binding_key

    @staticmethod
    def _populate_repo_state(state: State, binding, repo, snapshot) -> None:
        if binding is not None:
            state["_social_coding_binding"] = binding
        if repo is not None:
            state["_social_coding_repo"] = repo
            state["_runtime_workspace"] = str(repo.path)
        if snapshot is not None:
            state["_social_coding_git"] = snapshot
