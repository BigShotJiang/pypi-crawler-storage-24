from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

import yaml

from bub_social_coding.git_snapshot import detect_default_branch, resolve_repo_root
from bub_social_coding.models import RepoSpec

ALIAS_PATTERN = re.compile(r"^[a-z0-9]+(?:[-_][a-z0-9]+)*$")


class RepoRegistry:
    def __init__(
        self,
        repos: dict[str, RepoSpec] | None = None,
        *,
        source_path: Path | None = None,
        allowed_roots: tuple[Path, ...] = (),
    ) -> None:
        self._repos = repos or {}
        self._source_path = source_path
        self._allowed_roots = allowed_roots

    @classmethod
    def from_file(cls, path: Path | None, *, allowed_roots: tuple[Path, ...] = ()) -> RepoRegistry:
        if path is None:
            return cls(allowed_roots=allowed_roots)
        resolved = path.expanduser().resolve()
        registry = cls(source_path=resolved, allowed_roots=allowed_roots)
        registry.reload()
        return registry

    def reload(self) -> None:
        if self._source_path is None or not self._source_path.is_file():
            self._repos = {}
            return
        raw = self._source_path.read_text(encoding="utf-8")
        data = _load_mapping(raw, self._source_path)
        repos_raw = data.get("repos", data)
        if not isinstance(repos_raw, dict):
            raise TypeError("repo registry must be a mapping or contain a top-level 'repos' mapping")
        repos: dict[str, RepoSpec] = {}
        for alias, item in repos_raw.items():
            if not isinstance(alias, str):
                raise TypeError("repo alias must be a string")
            if not isinstance(item, dict):
                raise TypeError(f"repo entry '{alias}' must be a mapping")
            repos[alias] = self._repo_from_mapping(alias, item)
        self._repos = repos

    def register(
        self,
        *,
        alias: str,
        path: str | Path,
        default_branch: str | None = None,
        writable: bool = True,
        metadata: dict[str, Any] | None = None,
    ) -> RepoSpec:
        normalized_alias = _normalize_alias(alias)
        if normalized_alias in self._repos:
            raise ValueError(f"repo alias already exists: {normalized_alias}")
        repo_path = Path(path).expanduser().resolve()
        repo_root = resolve_repo_root(repo_path)
        if repo_root is None:
            raise ValueError(f"path is not a git repository: {repo_path}")
        self._validate_allowed_root(repo_root)
        repo = RepoSpec(
            alias=normalized_alias,
            path=repo_root,
            default_branch=default_branch or detect_default_branch(repo_root),
            writable=writable,
            metadata=metadata or {},
        )
        self._repos[normalized_alias] = repo
        self._persist()
        return repo

    def unregister(self, alias: str) -> RepoSpec | None:
        normalized_alias = _normalize_alias(alias)
        removed = self._repos.pop(normalized_alias, None)
        self._persist()
        return removed

    def get(self, alias: str) -> RepoSpec | None:
        return self._repos.get(alias)

    def list(self) -> list[RepoSpec]:
        return [self._repos[key] for key in sorted(self._repos)]

    def _repo_from_mapping(self, alias: str, item: dict[str, Any]) -> RepoSpec:
        repo_path = item.get("path")
        if not isinstance(repo_path, str) or not repo_path.strip():
            raise TypeError(f"repo '{alias}' must define a non-empty path")
        if self._source_path is None:
            raise RuntimeError("source_path is required to parse repo mappings")
        raw_repo_path = Path(repo_path).expanduser()
        resolved_repo_path = (
            (self._source_path.parent / raw_repo_path).resolve() if not raw_repo_path.is_absolute() else raw_repo_path.resolve()
        )
        return RepoSpec(
            alias=alias,
            path=resolved_repo_path,
            default_branch=str(item["default_branch"]) if item.get("default_branch") else None,
            writable=bool(item.get("writable", True)),
            metadata={str(key): value for key, value in item.items() if key not in {"path", "default_branch", "writable"}},
        )

    def _validate_allowed_root(self, repo_root: Path) -> None:
        if not self._allowed_roots:
            return
        if any(repo_root.is_relative_to(root) for root in self._allowed_roots):
            return
        allowed = ", ".join(str(root) for root in self._allowed_roots)
        raise ValueError(f"repo root '{repo_root}' is outside allowed roots: {allowed}")

    def _persist(self) -> None:
        if self._source_path is None:
            raise RuntimeError("repo registry is read-only because no source file is configured")
        self._source_path.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "repos": {
                repo.alias: {
                    "path": str(repo.path),
                    "default_branch": repo.default_branch,
                    "writable": repo.writable,
                    **repo.metadata,
                }
                for repo in self.list()
            }
        }
        self._source_path.write_text(_dump_mapping(payload, self._source_path), encoding="utf-8")


def _load_mapping(raw: str, path: Path) -> dict[str, Any]:
    data = json.loads(raw) if path.suffix.lower() == ".json" else yaml.safe_load(raw)
    if not isinstance(data, dict):
        raise TypeError("repo registry file must decode to a mapping")
    return data


def _dump_mapping(data: dict[str, Any], path: Path) -> str:
    if path.suffix.lower() == ".json":
        return json.dumps(data, ensure_ascii=False, indent=2) + "\n"
    return yaml.safe_dump(data, allow_unicode=True, sort_keys=True)


def _normalize_alias(alias: str) -> str:
    normalized = alias.strip().lower()
    if not normalized or ALIAS_PATTERN.fullmatch(normalized) is None:
        raise ValueError(f"invalid repo alias: {alias!r}")
    return normalized
