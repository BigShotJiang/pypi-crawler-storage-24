from __future__ import annotations

from pathlib import Path
from typing import Literal

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

from bub_social_coding.models import BindingScope


class SocialCodingSettings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="BUB_SOCIAL_CODING_", extra="ignore", env_file=".env")

    db_path: Path = Field(default=Path.home() / ".bub" / "social_coding.db")
    repos_file: Path | None = Field(default=None, description="YAML or JSON file describing allowed repo aliases.")
    allowed_roots: str = Field(
        default="",
        description="Comma-separated list of allowed repository root prefixes for dynamic registration.",
    )
    enabled_channels: str = Field(
        default="wecom_longconn_bot,telegram,lark,discord",
        description="Comma-separated social channels allowed to use social-coding features.",
    )
    admin_actors: str = Field(
        default="",
        description="Comma-separated admin actor identifiers. Supports bare ids, platform:id, or route_channel:id.",
    )
    admin_chats: str = Field(
        default="",
        description="Comma-separated admin chat identifiers. Supports bare ids, platform:id, or route_channel:id.",
    )
    direct_scope: BindingScope = Field(default="conversation")
    group_scope: BindingScope = Field(default="thread")
    unknown_scope: BindingScope = Field(default="conversation")
    require_repo_binding: bool = Field(default=True)
    auto_git_preflight: bool = Field(default=True)
    policy_mode: Literal["observe", "enforce"] = Field(default="observe")
    allow_repo_registration: bool = Field(
        default=False,
        description="Allow repo.register and repo.unregister to persist changes to the repo registry file.",
    )

    @property
    def enabled_channel_set(self) -> set[str]:
        return {item.strip() for item in self.enabled_channels.split(",") if item.strip()}

    @property
    def allowed_root_paths(self) -> tuple[Path, ...]:
        return tuple(Path(item.strip()).expanduser().resolve() for item in self.allowed_roots.split(",") if item.strip())

    @property
    def admin_actor_set(self) -> set[str]:
        return {item.strip() for item in self.admin_actors.split(",") if item.strip()}

    @property
    def admin_chat_set(self) -> set[str]:
        return {item.strip() for item in self.admin_chats.split(",") if item.strip()}
