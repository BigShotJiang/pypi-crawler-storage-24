from __future__ import annotations

from datetime import UTC
from pathlib import Path

from bub_social_coding.bindings import RepoBindingStore
from bub_social_coding.models import RepoSpec


def test_repo_binding_store_persists_and_clears(tmp_path: Path) -> None:
    store = RepoBindingStore(tmp_path / "bindings.db")
    repo = RepoSpec(alias="demo", path=tmp_path / "repo")

    store.bind(key="k1", scope="conversation", session_id="s1", repo=repo, metadata={"source": "test"})
    loaded = store.get("k1")

    assert loaded is not None
    assert loaded.repo_alias == "demo"
    assert loaded.workspace_path == repo.path
    assert loaded.metadata == {"source": "test"}
    assert loaded.created_at.tzinfo == UTC
    assert loaded.updated_at.tzinfo == UTC

    store.clear("k1")

    assert store.get("k1") is None
