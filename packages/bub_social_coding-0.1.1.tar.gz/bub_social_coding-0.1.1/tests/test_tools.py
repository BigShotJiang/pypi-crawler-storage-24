from __future__ import annotations

import subprocess
from pathlib import Path
from types import SimpleNamespace

import pytest
from bub.social import ConversationRef, LiveSurfaceRef, OutboundAction, ReplyGrant
from republic import ToolContext

from bub_social_coding.plugin import SocialCodingPlugin
from bub_social_coding.tools import (
    git_preflight,
    repo_bind,
    repo_register,
    repo_reload,
    repo_status,
    repo_unregister,
    social_complete,
    social_fail,
    social_progress,
)


def _run(command: list[str], cwd: Path) -> None:
    subprocess.run(command, cwd=cwd, check=True, capture_output=True, text=True)


def _init_git_repo(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)
    _run(["git", "init"], cwd=path)
    _run(["git", "config", "user.email", "dev@example.com"], cwd=path)
    _run(["git", "config", "user.name", "Dev"], cwd=path)
    _run(["git", "checkout", "-b", "dev"], cwd=path)
    (path / "README.md").write_text("hello\n", encoding="utf-8")
    _run(["git", "add", "README.md"], cwd=path)
    _run(["git", "commit", "-m", "init"], cwd=path)


def _plugin(tmp_path: Path, monkeypatch: pytest.MonkeyPatch, repo_path: Path) -> SocialCodingPlugin:
    registry_file = tmp_path / "repos.yaml"
    registry_file.write_text(
        f"""
repos:
  demo:
    path: {repo_path}
    default_branch: dev
    writable: true
""".strip(),
        encoding="utf-8",
    )
    monkeypatch.setenv("BUB_SOCIAL_CODING_REPOS_FILE", str(registry_file))
    monkeypatch.setenv("BUB_SOCIAL_CODING_DB_PATH", str(tmp_path / "social-coding.db"))
    return SocialCodingPlugin(SimpleNamespace(workspace=tmp_path))


@pytest.mark.asyncio
async def test_repo_bind_and_git_preflight_tools(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    repo_path = tmp_path / "repo"
    _init_git_repo(repo_path)
    plugin = _plugin(tmp_path, monkeypatch, repo_path)
    state = {
        "_social_coding_runtime": plugin.runtime,
        "_social_coding_binding_key": "k1",
        "_social_coding_scope": "conversation",
        "session_id": "wecom:chat-1",
    }
    context = ToolContext(tape="", run_id="run", state=state)

    bind_result = await repo_bind.handler("demo", context=context)
    status_result = await repo_status.handler(context=context)
    preflight_result = await git_preflight.handler(context=context)

    assert "Bound current session to repo 'demo'." in bind_result
    assert "Bound repo: demo" in status_result
    assert "Branch: dev" in status_result
    assert "Branch: dev" in preflight_result


@pytest.mark.asyncio
async def test_repo_register_reload_and_unregister_tools(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    repo_path = tmp_path / "repo"
    _init_git_repo(repo_path)
    registry_file = tmp_path / "repos.yaml"
    registry_file.write_text("repos: {}\n", encoding="utf-8")
    monkeypatch.setenv("BUB_SOCIAL_CODING_REPOS_FILE", str(registry_file))
    monkeypatch.setenv("BUB_SOCIAL_CODING_DB_PATH", str(tmp_path / "social-coding.db"))
    monkeypatch.setenv("BUB_SOCIAL_CODING_ALLOW_REPO_REGISTRATION", "true")
    monkeypatch.setenv("BUB_SOCIAL_CODING_ALLOWED_ROOTS", str(tmp_path))
    plugin = SocialCodingPlugin(SimpleNamespace(workspace=tmp_path))
    state = {
        "_social_coding_runtime": plugin.runtime,
        "_social_coding_binding_key": "k1",
        "_social_coding_is_admin": True,
        "session_id": "s1",
    }
    context = ToolContext(tape="", run_id="run", state=state)

    register_result = await repo_register.handler("demo", str(repo_path), context=context)
    reload_result = await repo_reload.handler(context=context)
    unregister_result = await repo_unregister.handler("demo", context=context)

    assert "Registered repo 'demo'." in register_result
    assert "Repo registry reloaded." in reload_result
    assert "Unregistered repo 'demo'." in unregister_result


@pytest.mark.asyncio
async def test_repo_register_requires_admin(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    repo_path = tmp_path / "repo"
    _init_git_repo(repo_path)
    registry_file = tmp_path / "repos.yaml"
    registry_file.write_text("repos: {}\n", encoding="utf-8")
    monkeypatch.setenv("BUB_SOCIAL_CODING_REPOS_FILE", str(registry_file))
    monkeypatch.setenv("BUB_SOCIAL_CODING_DB_PATH", str(tmp_path / "social-coding.db"))
    monkeypatch.setenv("BUB_SOCIAL_CODING_ALLOW_REPO_REGISTRATION", "true")
    monkeypatch.setenv("BUB_SOCIAL_CODING_ALLOWED_ROOTS", str(tmp_path))
    plugin = SocialCodingPlugin(SimpleNamespace(workspace=tmp_path))
    state = {"_social_coding_runtime": plugin.runtime, "_social_coding_binding_key": "k1", "session_id": "s1"}
    context = ToolContext(tape="", run_id="run", state=state)

    with pytest.raises(RuntimeError, match="admin privileges are required"):
        await repo_register.handler("demo", str(repo_path), context=context)


@pytest.mark.asyncio
async def test_repo_reload_requires_admin(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    repo_path = tmp_path / "repo"
    _init_git_repo(repo_path)
    plugin = _plugin(tmp_path, monkeypatch, repo_path)
    state = {"_social_coding_runtime": plugin.runtime, "_social_coding_binding_key": "k1", "session_id": "s1"}
    context = ToolContext(tape="", run_id="run", state=state)

    with pytest.raises(RuntimeError, match="admin privileges are required"):
        await repo_reload.handler(context=context)


@pytest.mark.asyncio
async def test_social_progress_dispatches_telegram_draft_action() -> None:
    dispatched: list[OutboundAction] = []

    class Framework:
        async def dispatch_via_router(self, action: OutboundAction) -> bool:
            dispatched.append(action)
            return True

    context = ToolContext(
        tape="",
        run_id="run",
        state={
            "_runtime_agent": SimpleNamespace(framework=Framework()),
            "_social_coding_conversation": ConversationRef(platform="telegram", chat_id="42", surface="direct"),
            "_social_coding_binding_key": "telegram|42",
            "_social_coding_message_id": "7",
        },
    )

    result = await social_progress.handler("running tests", context=context)

    assert "Sent progress update via telegram" in result
    assert "running tests" in result
    assert dispatched == [
        OutboundAction(
            kind="set_draft",
            conversation=ConversationRef(platform="telegram", chat_id="42", surface="direct"),
            text="running tests",
            live_surface=LiveSurfaceRef(mode="text_draft", surface_id="draft-telegram-42", parent_message_id="7"),
        )
    ]


@pytest.mark.asyncio
async def test_social_progress_dispatches_wecom_reply_message() -> None:
    dispatched: list[OutboundAction] = []

    class Framework:
        async def dispatch_via_router(self, action: OutboundAction) -> bool:
            dispatched.append(action)
            return True

    conversation = ConversationRef(
        platform="wecom",
        route_channel="wecom_longconn_bot",
        chat_id="chat-1",
        surface="direct",
    )
    request_id = "req-1"
    reply_grant = ReplyGrant(mode="token", token=request_id, reply_to_message_id="m-1")
    context = ToolContext(
        tape="",
        run_id="run",
        state={
            "_runtime_agent": SimpleNamespace(framework=Framework()),
            "_social_coding_conversation": conversation,
            "_social_coding_reply_grant": reply_grant,
            "_social_coding_message_id": "m-1",
        },
    )

    result = await social_progress.handler("running tests", context=context)

    assert "Sent progress update via wecom_longconn_bot" in result
    assert "Working: running tests" in result
    assert dispatched == [
        OutboundAction(
            kind="reply_message",
            conversation=conversation,
            text="Working: running tests",
            reply_grant=reply_grant,
            reply_to_message_id="m-1",
        )
    ]


@pytest.mark.asyncio
async def test_social_complete_dispatches_final_reply_message() -> None:
    dispatched: list[OutboundAction] = []

    class Framework:
        async def dispatch_via_router(self, action: OutboundAction) -> bool:
            dispatched.append(action)
            return True

    conversation = ConversationRef(platform="telegram", chat_id="42", surface="direct")
    context = ToolContext(
        tape="",
        run_id="run",
        state={
            "_runtime_agent": SimpleNamespace(framework=Framework()),
            "_social_coding_conversation": conversation,
            "_social_coding_message_id": "7",
            "_social_coding_binding": SimpleNamespace(repo_alias="demo"),
            "_social_coding_git": SimpleNamespace(branch="dev", dirty=False, changed_files=("src/app.py",)),
        },
    )

    result = await social_complete.handler("all tests passed", context=context)

    assert "Sent complete update via telegram" in result
    assert "Done: all tests passed" in result
    assert "Repo: demo" in result
    assert dispatched == [
        OutboundAction(
            kind="send_message",
            conversation=conversation,
            text="Done: all tests passed\nRepo: demo\nBranch: dev\nDirty: no\nChanged: src/app.py",
            reply_to_message_id="7",
        )
    ]


@pytest.mark.asyncio
async def test_social_fail_dispatches_final_failure_reply() -> None:
    dispatched: list[OutboundAction] = []

    class Framework:
        async def dispatch_via_router(self, action: OutboundAction) -> bool:
            dispatched.append(action)
            return True

    conversation = ConversationRef(platform="wecom", route_channel="wecom_longconn_bot", chat_id="chat-1", surface="direct")
    request_id = "req-1"
    reply_grant = ReplyGrant(mode="token", token=request_id, reply_to_message_id="m-1")
    context = ToolContext(
        tape="",
        run_id="run",
        state={
            "_runtime_agent": SimpleNamespace(framework=Framework()),
            "_social_coding_conversation": conversation,
            "_social_coding_reply_grant": reply_grant,
            "_social_coding_message_id": "m-1",
        },
    )

    result = await social_fail.handler("tests failed", context=context)

    assert "Sent fail update via wecom_longconn_bot" in result
    assert "Failed: tests failed" in result
    assert dispatched == [
        OutboundAction(
            kind="reply_message",
            conversation=conversation,
            content_type="card",
            card={
                "card_type": "text_notice",
                "source": {"desc": "Bub Social Coding"},
                "main_title": {"title": "Failed", "desc": "tests failed"},
                "emphasis_content": {"title": "session", "desc": "Branch: (unknown) | Changed: 0"},
                "sub_title_text": "Branch: (unknown) | Changed: 0",
                "card_action": {"type": 1, "url": "https://github.com/ximenzun/bub"},
            },
            reply_grant=reply_grant,
            reply_to_message_id="m-1",
        )
    ]
