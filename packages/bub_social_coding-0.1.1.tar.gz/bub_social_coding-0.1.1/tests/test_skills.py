from pathlib import Path


def test_builtin_skill_tree_contains_social_coding_skills() -> None:
    root = Path(__file__).resolve().parents[1] / "src" / "bub_skills"

    assert (root / "repo-control" / "SKILL.md").is_file()
    assert (root / "git-workflow" / "SKILL.md").is_file()
    assert (root / "social-coding-policy" / "SKILL.md").is_file()
