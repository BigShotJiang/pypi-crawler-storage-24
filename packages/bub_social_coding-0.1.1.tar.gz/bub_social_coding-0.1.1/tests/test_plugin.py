from __future__ import annotations

import subprocess
from pathlib import Path
from types import SimpleNamespace

import pytest
from bub.channels.message import ChannelMessage
from bub.social import ConversationRef

from bub_social_coding.commands import translate_social_command
from bub_social_coding.plugin import SocialCodingPlugin


def _run(command: list[str], cwd: Path) -> None:
    subprocess.run(command, cwd=cwd, check=True, capture_output=True, text=True)


def _init_git_repo(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)
    _run(["git", "init"], cwd=path)
    _run(["git", "config", "user.email", "dev@example.com"], cwd=path)
    _run(["git", "config", "user.name", "Dev"], cwd=path)
    _run(["git", "checkout", "-b", "dev"], cwd=path)
    (path / "README.md").write_text("hello\n", encoding="utf-8")
    _run(["git", "add", "README.md"], cwd=path)
    _run(["git", "commit", "-m", "init"], cwd=path)


def _plugin(tmp_path: Path, monkeypatch: pytest.MonkeyPatch, repo_path: Path) -> SocialCodingPlugin:
    registry_file = tmp_path / "repos.yaml"
    registry_file.write_text(
        f"""
repos:
  demo:
    path: {repo_path}
    default_branch: dev
    writable: true
""".strip(),
        encoding="utf-8",
    )
    monkeypatch.setenv("BUB_SOCIAL_CODING_REPOS_FILE", str(registry_file))
    monkeypatch.setenv("BUB_SOCIAL_CODING_DB_PATH", str(tmp_path / "social-coding.db"))
    return SocialCodingPlugin(SimpleNamespace(workspace=tmp_path))


def test_load_state_overrides_workspace_when_repo_is_bound(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    repo_path = tmp_path / "repo"
    _init_git_repo(repo_path)
    plugin = _plugin(tmp_path, monkeypatch, repo_path)
    message = ChannelMessage(
        session_id="wecom:chat-1",
        channel="wecom_longconn_bot",
        chat_id="chat-1",
        content="status?",
        conversation=ConversationRef(
            platform="wecom",
            route_channel="wecom_longconn_bot",
            chat_id="chat-1",
            account_id="default",
            surface="direct",
        ),
    )

    state = plugin.load_state(message, "wecom:chat-1")
    binding_key = state["_social_coding_binding_key"]
    plugin.runtime.bind_repo(key=binding_key, scope="conversation", session_id="wecom:chat-1", alias="demo")

    rebound = plugin.load_state(message, "wecom:chat-1")

    assert rebound["_runtime_workspace"] == str(repo_path.resolve())
    assert rebound["_social_coding_git"].branch == "dev"


def test_build_prompt_includes_social_context(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    repo_path = tmp_path / "repo"
    _init_git_repo(repo_path)
    plugin = _plugin(tmp_path, monkeypatch, repo_path)
    message = ChannelMessage(
        session_id="wecom:chat-1",
        channel="wecom_longconn_bot",
        chat_id="chat-1",
        content="what changed?",
        conversation=ConversationRef(
            platform="wecom",
            route_channel="wecom_longconn_bot",
            chat_id="chat-1",
            account_id="default",
            surface="direct",
        ),
    )

    state = plugin.load_state(message, "wecom:chat-1")
    plugin.runtime.bind_repo(key=state["_social_coding_binding_key"], scope="conversation", session_id="wecom:chat-1", alias="demo")
    state = plugin.load_state(message, "wecom:chat-1")

    prompt = plugin.build_prompt(message, "wecom:chat-1", state)

    assert "<social_coding_context>" in prompt
    assert "repo_alias: demo" in prompt
    assert "git_branch: dev" in prompt
    assert "what changed?" in prompt


def test_load_state_marks_admin_session_from_sender_identity(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    repo_path = tmp_path / "repo"
    _init_git_repo(repo_path)
    monkeypatch.setenv("BUB_SOCIAL_CODING_ADMIN_ACTORS", "wecom:alice")
    plugin = _plugin(tmp_path, monkeypatch, repo_path)
    message = ChannelMessage(
        session_id="wecom:chat-1",
        channel="wecom_longconn_bot",
        chat_id="chat-1",
        content="status?",
        sender={"id": "alice", "id_kind": "wecom_userid"},
        conversation=ConversationRef(
            platform="wecom",
            route_channel="wecom_longconn_bot",
            chat_id="chat-1",
            account_id="default",
            surface="direct",
        ),
    )

    state = plugin.load_state(message, "wecom:chat-1")

    assert state["_social_coding_is_admin"] is True


def test_translate_social_command_maps_repo_and_git_control_commands() -> None:
    assert translate_social_command("/repo list") == ",repo.list"
    assert translate_social_command("/repo bind bub") == ",repo.bind bub"
    assert translate_social_command("/repo unbind") == ",repo.clear"
    assert translate_social_command("/repo unregister bub") == ",repo.unregister bub"
    assert (
        translate_social_command("/repo register demo /tmp/repo --branch dev --readonly")
        == ",repo.register demo /tmp/repo default_branch=dev writable=false"
    )
    assert translate_social_command("/git preflight") == ",git.preflight"
    assert translate_social_command("normal prompt") is None


def test_plugin_provides_slash_command_specs(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    repo_path = tmp_path / "repo"
    _init_git_repo(repo_path)
    plugin = _plugin(tmp_path, monkeypatch, repo_path)

    commands = plugin.provide_slash_commands()

    assert [command.name for command in commands] == ["/repo", "/git"]
    assert "/repo list" in commands[0].usage
    assert "/git preflight" in commands[1].usage


def test_build_prompt_translates_social_control_commands_into_internal_commands(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    repo_path = tmp_path / "repo"
    _init_git_repo(repo_path)
    plugin = _plugin(tmp_path, monkeypatch, repo_path)
    message = ChannelMessage(
        session_id="wecom:chat-1",
        channel="wecom_longconn_bot",
        chat_id="chat-1",
        content="/repo bind demo",
        conversation=ConversationRef(
            platform="wecom",
            route_channel="wecom_longconn_bot",
            chat_id="chat-1",
            account_id="default",
            surface="direct",
        ),
    )

    state = plugin.load_state(message, "wecom:chat-1")
    prompt = plugin.build_prompt(message, "wecom:chat-1", state)

    assert prompt == ",repo.bind demo"


def test_build_prompt_translates_registered_slash_help_commands(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    repo_path = tmp_path / "repo"
    _init_git_repo(repo_path)
    plugin = _plugin(tmp_path, monkeypatch, repo_path)
    plugin.framework.get_slash_commands = plugin.provide_slash_commands  # type: ignore[attr-defined]
    message = ChannelMessage(
        session_id="wecom:chat-1",
        channel="wecom_longconn_bot",
        chat_id="chat-1",
        content="/repo",
        conversation=ConversationRef(
            platform="wecom",
            route_channel="wecom_longconn_bot",
            chat_id="chat-1",
            account_id="default",
            surface="direct",
        ),
    )

    state = plugin.load_state(message, "wecom:chat-1")
    prompt = plugin.build_prompt(message, "wecom:chat-1", state)

    assert prompt == ",commands topic=repo"
