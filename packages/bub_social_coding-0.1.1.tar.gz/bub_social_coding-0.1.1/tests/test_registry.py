from __future__ import annotations

import subprocess
from pathlib import Path

import pytest

from bub_social_coding.registry import RepoRegistry


def _run(command: list[str], cwd: Path) -> None:
    subprocess.run(command, cwd=cwd, check=True, capture_output=True, text=True)


def _init_git_repo(path: Path, *, branch: str = "dev") -> None:
    path.mkdir(parents=True, exist_ok=True)
    _run(["git", "init"], cwd=path)
    _run(["git", "config", "user.email", "dev@example.com"], cwd=path)
    _run(["git", "config", "user.name", "Dev"], cwd=path)
    _run(["git", "checkout", "-b", branch], cwd=path)
    (path / "README.md").write_text("hello\n", encoding="utf-8")
    _run(["git", "add", "README.md"], cwd=path)
    _run(["git", "commit", "-m", "init"], cwd=path)


def test_repo_registry_loads_yaml_mapping(tmp_path: Path) -> None:
    registry_file = tmp_path / "repos.yaml"
    registry_file.write_text(
        """
repos:
  demo:
    path: ./demo-repo
    default_branch: dev
    writable: false
""".strip(),
        encoding="utf-8",
    )

    registry = RepoRegistry.from_file(registry_file)
    repo = registry.get("demo")

    assert repo is not None
    assert repo.alias == "demo"
    assert repo.path == (registry_file.parent / "demo-repo").resolve()
    assert repo.default_branch == "dev"
    assert repo.writable is False


def test_repo_registry_register_persists_and_unregisters(tmp_path: Path) -> None:
    repo_path = tmp_path / "repo"
    _init_git_repo(repo_path, branch="main")
    registry_file = tmp_path / "repos.yaml"

    registry = RepoRegistry.from_file(registry_file)
    created = registry.register(alias="demo", path=repo_path, writable=True)

    assert created.alias == "demo"
    assert created.path == repo_path.resolve()
    assert created.default_branch == "main"
    assert registry.get("demo") is not None
    assert "demo:" in registry_file.read_text(encoding="utf-8")

    registry.reload()
    reloaded = registry.get("demo")
    assert reloaded is not None
    assert reloaded.path == repo_path.resolve()

    removed = registry.unregister("demo")
    assert removed is not None
    assert registry.get("demo") is None
    assert "demo:" not in registry_file.read_text(encoding="utf-8")


def test_repo_registry_register_rejects_path_outside_allowed_roots(tmp_path: Path) -> None:
    repo_path = tmp_path / "outside" / "repo"
    _init_git_repo(repo_path)
    allowed_root = tmp_path / "allowed"
    allowed_root.mkdir()
    registry_file = tmp_path / "repos.yaml"
    registry = RepoRegistry.from_file(registry_file, allowed_roots=(allowed_root.resolve(),))

    with pytest.raises(ValueError, match="outside allowed roots"):
        registry.register(alias="demo", path=repo_path)
