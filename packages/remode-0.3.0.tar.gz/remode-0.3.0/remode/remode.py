"""Recursive Mode Detection (ReMoDe) for ordinal data."""

import warnings
from collections import Counter
from functools import partial
from typing import TYPE_CHECKING, Any, Callable, Dict, Literal, Optional, Tuple, Union, cast

import numpy as np
import pandas as pd
from scipy.stats import binomtest, chisquare, fisher_exact

if TYPE_CHECKING:
    from matplotlib.axes import Axes


ModeTestCallable = Callable[[np.ndarray, int, int, int], Tuple[float, float]]


def count_descriptive_peaks(x: np.ndarray) -> int:
    """
    Count descriptive peaks in a histogram-like vector, matching the R implementation.

    Parameters
    ----------
    x : np.ndarray
        Histogram counts.

    Returns
    -------
    int
        Number of descriptive peaks.
    """
    if len(x) < 2:
        return 0

    signs = np.concatenate((np.array([-1]), np.sign(np.diff(x))))
    x_filtered = x[signs != 0]

    if len(x_filtered) < 2:
        return 0

    signs = np.concatenate((np.array([-1]), np.sign(np.diff(x_filtered))))
    return int(np.sum(np.diff(signs) < 0))


def approximate_bayes_factor(p_value: float) -> float:
    """
    Approximate BF_10 from a p-value using Sellke, Bayarri, and Berger (2001).

    Parameters
    ----------
    p_value : float
        P-value for a detected mode.

    Returns
    -------
    float
        Approximate Bayes factor in favor of the alternative hypothesis.
    """
    if p_value == 0:
        return np.inf

    if p_value <= 1 / np.e:
        bf_01 = (-np.e * p_value * np.log(p_value)) / (1 - p_value)
        return 1 / bf_01

    return np.nan


def perform_fisher_test(
    x: np.ndarray, candidate: int, left_min: int, right_min: int
) -> Tuple[float, float]:
    """
    Perform Fisher's exact test on both sides of a candidate maximum to test if it is a true local maximum.

    Parameters
    ----------
    x : np.ndarray
        The input data array.
    candidate : int
        The index of the candidate maximum.
    left_min : int
        The index of the minimum value on the left side of the candidate maximum.
    right_min : int
        The index of the minimum value on the right side of the candidate maximum.

    Returns
    -------
    Tuple[float, float]
        The p-values of the Fisher's exact test for the left and right sides of the candidate maximum.
    """
    left_matrix = np.array(
        [
            [x[candidate], np.sum(x) - x[candidate]],
            [x[left_min], np.sum(x) - x[left_min]],
        ]
    )
    right_matrix = np.array(
        [
            [x[candidate], np.sum(x) - x[candidate]],
            [x[right_min], np.sum(x) - x[right_min]],
        ]
    )
    p_left = fisher_exact(left_matrix, "greater")[1]
    p_right = fisher_exact(right_matrix, "greater")[1]
    return p_left, p_right


def perform_binomial_test(
    x: np.ndarray, candidate: int, left_min: int, right_min: int
) -> Tuple[float, float]:
    """
    Perform binomial tests on both sides of a candidate maximum to test if it is a true local maximum.

    Parameters
    ----------
    x : np.ndarray
        The input data array.
    candidate : int
        The index of the candidate maximum.
    left_min : int
        The index of the minimum value on the left side of the candidate maximum.
    right_min : int
        The index of the minimum value on the right side of the candidate maximum.

    Returns
    -------
    Tuple[float, float]
        The p-values of the binomial tests for the left and right sides of the candidate maximum.
    """
    n_left = x[candidate] + x[left_min]
    n_right = x[candidate] + x[right_min]
    p_left = binomtest(x[candidate], n_left, alternative="greater").pvalue
    p_right = binomtest(x[candidate], n_right, alternative="greater").pvalue
    return p_left, p_right


def perform_bootstrap_test(
    x: np.ndarray,
    candidate: int,
    left_min: int,
    right_min: int,
    n_boot: int = 10000,
    rng: Optional[np.random.Generator] = None,
) -> Tuple[float, float]:
    """
    Perform the ReMoDe bootstrap significance test for a candidate mode.

    Parameters
    ----------
    x : np.ndarray
        The input data array.
    candidate : int
        The index of the candidate maximum.
    left_min : int
        The index of the minimum value on the left side of the candidate maximum.
    right_min : int
        The index of the minimum value on the right side of the candidate maximum.
    n_boot : int, optional
        Number of bootstrap samples. Default is 10000.
    rng : np.random.Generator, optional
        Random number generator to use. If omitted, a new generator is created.

    Returns
    -------
    Tuple[float, float]
        Bootstrap p-value duplicated for left/right slots for compatibility with
        the other significance test interfaces.
    """
    if n_boot <= 0:
        raise ValueError("n_boot must be a positive integer.")

    x = np.asarray(x, dtype=int)
    sample_size = int(np.sum(x))
    if sample_size <= 0:
        return 1.0, 1.0

    if rng is None:
        rng = np.random.default_rng()

    # Equivalent to R's raw-data bootstrap sampling with replacement, but vectorized.
    probs = x / sample_size
    sampled_counts = rng.multinomial(sample_size, probs, size=n_boot)
    candidate_dominates = (sampled_counts[:, candidate] > sampled_counts[:, left_min]) & (
        sampled_counts[:, candidate] > sampled_counts[:, right_min]
    )
    p_value = 1 - (float(np.sum(candidate_dominates)) / n_boot)
    return p_value, p_value


class ReMoDe:
    """
    ReMoDe (Robust Mode Detection) is a class for detecting modes in a dataset.

    The class uses statistical tests to identify local maxima in the dataset that are statistically significant.
    The identified modes can then be used for further analysis.

    Attributes
    ----------
    alpha : float
        The significance level for the statistical tests. Default is 0.05.
    alpha_correction : str or function
        The method for correcting the significance level for multiple comparisons.
        Options are "descriptive_peaks", "max_modes", and "none".
        Default is "descriptive_peaks".
    statistical_test : str or function
        The statistical test to use for identifying local maxima.
        Options are "bootstrap", "binomial", "fisher", or a custom callable.
        Default is "bootstrap".
    definition : str
        Underlying modality definition. If "shape_based", a uniform distribution
        can be classified as unimodal. If "peak_based", a non-significant
        chi-square uniformity test leads to zero detected modes.

    Methods
    -------
    format_data(xt: np.ndarray) -> np.ndarray:
        Formats the input data for mode detection.
    fit(xt: np.ndarray) -> Dict[str, Union[int, np.ndarray]]:
        Fits the model to the input data and returns the detected modes.
    remode_stability(iterations: int, percentage_steps: int) -> Dict[str, Any]:
        Evaluates the stability of the detected modes using the jackknife resampling method.
    """

    def __init__(
        self,
        alpha: float = 0.05,
        alpha_correction: Union[
            Literal["descriptive_peaks", "max_modes", "none"], Callable
        ] = "descriptive_peaks",
        statistical_test: Union[
            Literal["bootstrap", "binomial", "fisher"], ModeTestCallable
        ] = "bootstrap",
        definition: Literal["shape_based", "peak_based"] = "shape_based",
        n_boot: int = 10000,
        random_state: Optional[int] = None,
    ):
        self.alpha = alpha
        if n_boot <= 0:
            raise ValueError("n_boot must be a positive integer.")
        self.n_boot = int(n_boot)

        def _segment_length(segment: Union[np.ndarray, int]) -> int:
            if isinstance(segment, np.ndarray):
                return len(segment)
            return int(segment)

        if isinstance(alpha_correction, str):
            correction_name = alpha_correction.lower()
            if correction_name == "none":
                self._create_alpha_correction = lambda segment, alpha: alpha
            elif correction_name == "max_modes":
                self._create_alpha_correction = (
                    lambda segment, alpha: alpha
                    / np.floor((_segment_length(segment) + 1) / 2)
                )
            elif correction_name == "descriptive_peaks":
                self._create_alpha_correction = (
                    lambda segment, alpha: alpha
                    / max(1, count_descriptive_peaks(np.asarray(segment)))
                )
            else:
                raise ValueError(
                    "The alpha_correction argument must be a function or one of "
                    "'descriptive_peaks', 'max_modes', or 'none'."
                )
        else:
            if not callable(alpha_correction):
                raise ValueError(
                    "The alpha_correction argument must be a function or one of "
                    "'descriptive_peaks', 'max_modes', or 'none'."
                )

            def _create_alpha_correction(
                segment: Union[np.ndarray, int], alpha_level: float
            ) -> float:
                try:
                    return alpha_correction(segment, alpha_level)
                except TypeError:
                    return alpha_correction(_segment_length(segment), alpha_level)

            self._create_alpha_correction = _create_alpha_correction

        test_callable: ModeTestCallable
        sign_test_name: str
        if isinstance(statistical_test, str):
            test_name = statistical_test.lower()
            if test_name == "bootstrap":
                bootstrap_rng = np.random.default_rng(random_state)
                test_callable = cast(
                    ModeTestCallable,
                    partial(
                        perform_bootstrap_test,
                        n_boot=self.n_boot,
                        rng=bootstrap_rng,
                    ),
                )
                sign_test_name = "bootstrap"
            elif test_name == "binomial":
                test_callable = perform_binomial_test
                sign_test_name = "binomial"
            elif test_name == "fisher":
                test_callable = perform_fisher_test
                sign_test_name = "fisher"
            else:
                raise ValueError(
                    "The statistical_test argument must be a callable or one of "
                    "'bootstrap', 'binomial', or 'fisher'."
                )
        else:
            if not callable(statistical_test):
                raise ValueError(
                    "The statistical_test argument must be a callable or one of "
                    "'bootstrap', 'binomial', or 'fisher'."
                )
            if statistical_test is perform_bootstrap_test:
                bootstrap_rng = np.random.default_rng(random_state)
                test_callable = cast(
                    ModeTestCallable,
                    partial(
                        perform_bootstrap_test,
                        n_boot=self.n_boot,
                        rng=bootstrap_rng,
                    ),
                )
                sign_test_name = "bootstrap"
            else:
                test_callable = cast(ModeTestCallable, statistical_test)
                if statistical_test is perform_fisher_test:
                    sign_test_name = "fisher"
                elif statistical_test is perform_binomial_test:
                    sign_test_name = "binomial"
                else:
                    sign_test_name = "custom"

        self.statistical_test = test_callable
        self.sign_test = sign_test_name

        if not isinstance(definition, str):
            raise ValueError("definition must be either 'shape_based' or 'peak_based'.")
        definition_name = definition.lower()
        if definition_name not in ("shape_based", "peak_based"):
            raise ValueError("definition must be either 'shape_based' or 'peak_based'.")
        self.definition = definition_name

        self.alpha_cor: Optional[float] = None
        self.modes: np.ndarray = np.array([])
        self.p_values: np.ndarray = np.array([])
        self.approx_bayes_factors: np.ndarray = np.array([])
        self.xt: np.ndarray = np.array([])
        self.levels: np.ndarray = np.array([])
        self.uniform_distribution: Optional[bool] = None
        self.uniformity_p_value: Optional[float] = None

    def format_data(
        self, xt: Union[np.ndarray, list], levels: Optional[np.ndarray] = None
    ) -> np.ndarray:
        """
        Formats the input data for mode detection.

        Parameters
        ----------
        xt : np.ndarray
            The input data array.
        levels : np.ndarray, optional
            The levels at which to find the modes. If not provided, defaults to the range of the length of the input data.

        Returns
        -------
        np.ndarray
            The formatted data array.
        """
        if levels is None:
            # Ensure xt is a numpy array for processing
            levels = np.unique(xt)

        levels_h = np.concatenate([levels - 0.01, [levels[-1] + 0.01]])

        return np.histogram(xt, bins=levels_h)[0]

    def _find_maxima(self, xt: np.ndarray) -> list:
        """
        Finds the local maxima in the input data.

        Parameters
        ----------
        xt : np.ndarray
             The input data array.

        Returns
        -------
        list
            Pairs of local mode indices and p-values.
        """
        if len(xt) < 3:
            return []

        result = []
        alpha_cor = self._create_alpha_correction(xt, self.alpha)
        candidate = int(np.argmax(xt))
        if candidate != 0 and candidate != len(xt) - 1:
            left_min = int(np.argmin(xt[:candidate]))
            right_min = int(np.argmin(xt[candidate:]) + candidate)
            p_left, p_right = self.statistical_test(xt, candidate, left_min, right_min)
            if self.sign_test == "fisher":
                p_value = 1 - (1 - p_left) * (1 - p_right)
                if p_value < alpha_cor:
                    result.append((candidate, p_value))
            elif p_left < alpha_cor and p_right < alpha_cor:
                result.append((candidate, max(p_left, p_right)))

        left = self._find_maxima(xt[:candidate])
        right = [
            (idx + candidate + 1, p_value)
            for idx, p_value in self._find_maxima(xt[candidate + 1 :])
        ]
        return result + left + right

    def fit(
        self, xt: np.ndarray, set_data: bool = True, levels: np.ndarray = np.array([])
    ) -> Dict[str, Any]:
        """
        Fits the model to the input data and returns the detected modes.

        This method first applies an alpha correction to the input data, then finds the local maxima (modes) in the data.
        If `levels` is not provided, it defaults to the range of the length of the input data.
        If `set_data` is True, the input data is stored in the `xt` attribute of the class instance.

        Parameters
        ----------
        xt : np.ndarray
            The input data array.
        set_data : bool, optional
            Whether to store the input data in the `xt` attribute of the class instance. Default is True.
        levels : np.ndarray, optional
            The levels at which to find the modes. If not provided, defaults to the range of the length of the input data.

        Returns
        -------
        Dict[str, Any]
            A dictionary containing the detected modes and their properties. The keys of the dictionary are the indices of the modes, and the values are the properties of the modes.
        """
        xt = np.asarray(xt)
        xt_padded: np.ndarray = np.concatenate((np.array([0]), xt, np.array([0])))
        self.alpha_cor = self._create_alpha_correction(xt_padded, self.alpha)
        mode_details = self._find_maxima(xt_padded)
        if len(mode_details) == 0:
            modes = np.array([], dtype=int)
            p_values = np.array([], dtype=float)
            approx_bayes_factors = np.array([], dtype=float)
        else:
            modes = np.array([mode_index - 1 for mode_index, _ in mode_details], dtype=int)
            p_values = np.array([p_value for _, p_value in mode_details], dtype=float)

            sort_order = np.argsort(modes)
            modes = modes[sort_order]
            p_values = p_values[sort_order]
            approx_bayes_factors = np.array(
                [approximate_bayes_factor(p_value) for p_value in p_values], dtype=float
            )

        uniformity_p_value: Optional[float] = None
        uniform_distribution: Optional[bool] = None
        if self.definition == "peak_based" and np.sum(xt) > 0:
            uniformity_p_value = float(chisquare(xt).pvalue)
            uniform_distribution = bool(
                np.isfinite(uniformity_p_value) and uniformity_p_value > 0.05
            )
            # Match R behavior: fixed 0.05 threshold for the Pearson chi-square test.
            if uniform_distribution:
                modes = np.array([], dtype=int)
                p_values = np.array([], dtype=float)
                approx_bayes_factors = np.array([], dtype=float)

        if len(levels) == 0:
            self.levels = np.arange(len(xt))
        else:
            self.levels = levels

        if set_data:
            self.xt = xt
            self.modes = modes
            self.p_values = p_values
            self.approx_bayes_factors = approx_bayes_factors
            self.uniform_distribution = uniform_distribution
            self.uniformity_p_value = uniformity_p_value

        return {
            "nr_of_modes": len(modes),
            "modes": modes,
            "p_values": p_values,
            "approx_bayes_factors": approx_bayes_factors,
            "xt": xt,
            "alpha_after_correction": self.alpha_cor,
            "sign_test": self.sign_test,
            "definition": self.definition,
            "uniform_distribution": uniform_distribution,
            "uniformity_p_value": uniformity_p_value,
        }

    def plot_maxima(
        self, ax: Optional["Axes"] = None, format_plot: Optional[bool] = True
    ) -> None:
        """
        Formats the input data for mode detection.

        Parameters
        ----------
        xt : np.ndarray
            The input data array.
        format_plot : bool, optional
            Whether to format the plot. Default is True.

        Returns
        -------
        np.ndarray
            The formatted data array.
        """

        if len(self.xt) == 0:
            raise ValueError("Please fit the model first before plotting the maxima.")

        if ax is None:
            import matplotlib.pyplot as plt

            _, ax = plt.subplots()

        ax.bar(self.levels, self.xt, color="lightgrey", zorder=9, label=None)
        if len(self.modes) > 0:
            ax.bar(
                np.take(self.levels, self.modes),
                np.take(self.xt, self.modes),
                color="navy",
                zorder=10,
                alpha=0.5,
                label="Modes",
            )

        if format_plot:
            ax.set_xticks(self.levels)
            self._format_plot(ax)

    def _format_plot(
        self,
        ax,
        xlabel="Category",
        ylabel="Frequency",
        title="Modes detected",
        legend=True,
    ):
        """
        Formats the plot with the given title and standard settings.

        Parameters
        ----------
        ax : matplotlib.axes.Axes
            The Axes object to format.
        xlabel : str
            The label to set for the x-axis.
        ylabel : str
            The label to set for the y-axis.
        title : str
            The title to set for the plot.
        legend : bool
            Whether to show the legend. Default is True.

        Returns
        -------
        None
        """
        ax.set_xlabel(xlabel)
        ax.set_ylabel(ylabel)
        ax.grid(axis="y", zorder=0)
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        ax.spines["bottom"].set_visible(False)
        ax.spines["left"].set_visible(False)
        ax.set_title(title, loc="left")
        if legend:
            ax.legend()

    def _jackknife(self, percentage: float) -> np.ndarray:
        """
        Performs the jackknife resampling method on the input data.

        Parameters
        ----------
        percentage : float
            The percentage of data to remove in each resampling step.

        Returns
        -------
        np.ndarray
            The resampled data array.
        """
        # Create data from count
        x = np.repeat(np.arange(len(self.xt)), self.xt)

        # Remove 20% of the data
        n_delete = int(percentage * len(x) / 100)

        if n_delete > 0:
            x_remove = np.random.choice(x, n_delete, replace=False)
            remove_count = np.bincount(x_remove, minlength=len(self.xt))

            return np.bincount(x, minlength=len(self.xt)) - remove_count

        return np.bincount(x, minlength=len(self.xt))

    def remode_stability(
        self, iterations: int = 100, percentage_steps: int = 10, plot: bool = True
    ) -> Dict[str, Any]:
        """
        Evaluates the stability of the detected modes using the jackknife resampling method.

        Parameters
        ----------
        iterations : int
            The number of iterations to perform for the jackknife resampling.
        percentage_steps : int
            The number of percentage steps to remove in the jackknife resampling.
        plot : bool
            Whether to plot the stability analysis results.

        Returns
        -------
        Dict[str, Any]
            A dictionary containing the results of the stability evaluation.
        """
        if len(self.modes) == 0:
            raise ValueError(
                "It appears that either you did not yet apply ReMoDe or that no modes were found. Stability analyses can only be performed on modes detected by ReMoDe."
            )

        perc_range = np.linspace(0, 100, percentage_steps + 1)
        modes = pd.DataFrame(
            {
                "perc": perc_range,
                "mean_modality": np.nan,
                "most_freq_modality": np.nan,
                "majority_result": False,
            }
        )

        modes.at[0, "mean_modality"] = len(self.modes)
        modes.at[0, "most_freq_modality"] = len(self.modes)
        modes.at[0, "majority_result"] = True

        # Initialize matrix to store data counts of mode locations
        modes_locations = np.zeros((len(perc_range), len(self.xt)))
        modes_locations[0, self.modes] = iterations

        for i in range(1, len(perc_range) - 1):
            m = np.zeros(iterations)
            for j in range(iterations):
                xt_jackknifed = self._jackknife(modes.at[i, "perc"])
                r = self.fit(xt_jackknifed, set_data=False)
                m[j] = r["nr_of_modes"]
                # Update mode location matrix
                for mode in r["modes"]:
                    modes_locations[i, mode] += 1

            modes.at[i, "mean_modality"] = np.mean(m)
            modes.at[i, "most_freq_modality"] = Counter(m).most_common(1)[0][0]
            modes.at[i, "majority_result"] = (
                np.mean(m == len(self.modes)) >= 0.5
            )

        modes.loc[len(perc_range) - 1, ["mean_modality", "most_freq_modality", "majority_result"]] = [0, 0, False]
        modes_locations[len(perc_range) - 1, :] = 0

        false_indices = np.where(~modes["majority_result"].astype(bool).to_numpy())[0]
        if len(false_indices) == 0:
            stable_until = float(modes["perc"].max())
        elif false_indices[0] == 0:
            stable_until = 0.0
        else:
            stable_until = float(modes["perc"].iloc[false_indices[0] - 1])

        # Calculate the stability of the location of detected modes
        if len(self.modes) > 0:
            sorted_modes = np.sort(self.modes.astype(int))
            stability_estimates = np.apply_along_axis(
                lambda x: np.argmin(x > (iterations / 2)) / modes_locations.shape[0],
                axis=0,
                arr=modes_locations[:, sorted_modes],
            )
            stability_location_df = pd.DataFrame(
                {
                    "Mode location": sorted_modes,
                    "Stability estimate": stability_estimates,
                }
            )
            stability_location_df = stability_location_df[
                stability_location_df["Stability estimate"] > 0
            ].reset_index(drop=True)
        else:
            stability_location_df = pd.DataFrame(columns=["Mode location", "Stability estimate"])

        if plot:
            import matplotlib.gridspec as gridspec
            import matplotlib.pyplot as plt

            plt.figure(figsize=(12, 4))
            gs = gridspec.GridSpec(1, 2)  # 1 row, 2 columns

            ax1 = plt.subplot(gs[0, 0])  # left subplot spans first two columns
            self.plot_maxima(ax1)

            ax2 = plt.subplot(gs[0, 1])  # right subplot in the third column
            plt.step(
                modes["perc"],
                modes["mean_modality"],
                where="mid",
                label="Mean Modality",
                color="navy",
            )
            plt.step(
                modes["perc"],
                modes["most_freq_modality"],
                where="mid",
                linestyle="--",
                label="Most Frequent Modality",
                color="cornflowerblue",
            )
            self._format_plot(
                ax2,
                xlabel="Percentage of Data Removed",
                ylabel="Modality",
                title=f"Modes: {len(self.modes)}, stability {stable_until}%",
                legend=True,
            )
            plt.tight_layout()

        return {
            "num_mode_stability": modes,
            "stable_until": stable_until,
            "location_stability": stability_location_df
        }

    def evaluate_stability(
        self, iterations: int = 100, percentage_steps: int = 10, plot: bool = True
    ) -> Dict[str, Any]:
        """
        Deprecated alias for ``remode_stability``.
        """
        warnings.warn(
            "'evaluate_stability' is deprecated and will be removed in a future release; "
            "use 'remode_stability' instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        return self.remode_stability(
            iterations=iterations, percentage_steps=percentage_steps, plot=plot
        )
