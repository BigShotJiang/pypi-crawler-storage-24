# MultiRPC

A Python library for reliable Ethereum smart contract interactions via multiple RPC endpoints with automatic failover, load distribution, and retry logic.

## Project Structure

```
multirpc/
├── __init__.py                    # Exports MultiRpc, AsyncMultiRpc
├── base_multi_rpc_interface.py    # BaseMultiRpc (ABC) — core logic for view calls, tx building/signing/sending, receipt waiting, tx tracing
├── async_multi_rpc_interface.py   # AsyncMultiRpc — async interface, wraps base with ContractFunction
├── sync_multi_rpc_interface.py    # MultiRpc — sync interface, uses asyncio.run + thread_safe decorator
├── constants.py                   # Config constants (gas limits, view policies, logger setup, chain IDs)
├── exceptions.py                  # Custom exceptions (TransactionFailedStatus, FailedOnAllRPCs, etc.)
├── gas_estimation.py              # GasEstimation — gas price via API, RPC, fixed, or custom methods
├── tx_trace.py                    # TxTrace/TxTraceResult — debug_traceTransaction for failed tx diagnosis
├── utils.py                       # NestedDict, thread_safe decorator, MultiRpcAsyncHTTPProvider, create_web3_from_rpc
tests/
├── pytest/test_erpc_errors.py     # Unit tests for eRPC error handling (mocked, no network)
├── test.py                        # Integration tests (requires live RPCs and funded wallets)
├── constants.py                   # Test chain configs (Arbitrum, Polygon, Base, Mantle)
├── test_settings.py               # Private keys & log level (gitignored)
```

## Build & Dependencies

- **Package manager**: uv (migrated from poetry)
- **Build system**: hatchling
- **Python**: >=3.10
- **Key deps**: `web3>7.0.0`, `multicallable>=6.0.0`, `eth-account>=0.13.0`
- **Optional**: `elastic-apm>=6.0.0` (for APM tracing)
- **Dev deps**: `pytest`, `pytest-asyncio`, `bump-my-version`

## Commands

```bash
# Install
uv sync

# Run unit tests
uv run pytest

# Run integration tests (requires live RPCs + funded wallets)
uv run python tests/test.py

# Build
uv build

# Version bump
uv run bump-my-version bump patch  # or minor, major
```

## Key Architecture Decisions

- **NestedDict**: RPC URLs are organized as `{type: {bracket_id: [urls]}}` where type is "view" or "transaction"
- **View policies**: `MostUpdated` (waits for all RPCs, picks highest block) or `FirstSuccess` (returns first successful result)
- **Thread safety**: sync interface uses `thread_safe` decorator that spawns a thread if an event loop is already running
- **Custom HTTP provider**: `MultiRpcAsyncHTTPProvider` creates a new `ClientSession` per request and always closes it in `finally` (prevents resource leaks on cancellation). Based on web3==7.7.0
- **Gas estimation**: Falls back through API → RPC → Fixed → Custom methods
- **Flash blocks**: Auto-detected for supported chains (Base); uses 'pending' block identifier instead of 'latest'

## Testing

- pytest config: `asyncio_mode = "strict"`, test path: `tests/pytest/`
- Unit tests use `pytest.mark.asyncio` and mock `_send_transaction` internals
- `tests/test_settings.py` is gitignored (contains private keys)

## Code Conventions

- Logging via `MultiRPCLogger` (name: "Multi-RPC") and `GasEstimationLogger`
- APM integration is optional — controlled by `apm` parameter; uses `async_capture_span` from elasticapm when enabled
- Error strings are checked case-insensitively for known RPC/eRPC error patterns in `_send_transaction`