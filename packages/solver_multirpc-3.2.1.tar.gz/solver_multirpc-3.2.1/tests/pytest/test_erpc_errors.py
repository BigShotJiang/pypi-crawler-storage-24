"""
Unit tests for eRPC error handling — no real network calls.
"""
import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from web3.exceptions import Web3RPCError
from web3.types import RPCError, RPCResponse
from requests import ConnectionError, ReadTimeout

from multirpc.exceptions import TransactionValueError


# ---------------------------------------------------------------------------
# _send_transaction — success path
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_send_transaction_success(mrpc, provider):
    tx_hash = b"deadbeef"
    with patch.object(provider.eth, "send_raw_transaction", AsyncMock(return_value=tx_hash)), \
         patch("multirpc.base_multi_rpc_interface.get_unix_time", return_value=0), \
         patch.object(mrpc, "_logger_params"):
        result_provider, result_tx = await mrpc._send_transaction(provider, b"raw_tx")
    assert result_provider is provider
    assert result_tx == tx_hash


# ---------------------------------------------------------------------------
# _send_transaction — errors that should re-raise (NOT TransactionValueError)
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
@pytest.mark.parametrize("message,code", [
    ("rate limit exceeded", -32005),
    ("capacity exceeded", -32005),
    ("already known", -32000),
    ("transaction underpriced", -32000),
])
async def test_send_transaction_reraises_known_erpc_errors(mrpc, provider, message, code):
    err = Web3RPCError(message, rpc_response=RPCResponse(error=RPCError(message=message, code=code)))
    with patch.object(provider.eth, "send_raw_transaction", AsyncMock(side_effect=err)):
        with pytest.raises(Web3RPCError):
            await mrpc._send_transaction(provider, b"raw_tx")


# ---------------------------------------------------------------------------
# _send_transaction — unknown errors (should become TransactionValueError)
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
@pytest.mark.parametrize("message", [
    "some unknown error from eRPC",
    "execution reverted",
    "insufficient funds",
])
async def test_send_transaction_unknown_error_raises_transaction_value_error(mrpc, provider, message):
    err = Web3RPCError(message, rpc_response=RPCResponse(error=RPCError(message=message, code=-32000)))
    with patch.object(provider.eth, "send_raw_transaction", AsyncMock(side_effect=err)):
        with pytest.raises(TransactionValueError):
            await mrpc._send_transaction(provider, b"raw_tx")


# ---------------------------------------------------------------------------
# _send_transaction — network errors re-raise unchanged
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
@pytest.mark.parametrize("exc_class", [ConnectionError, ReadTimeout])
async def test_send_transaction_network_errors_reraise(mrpc, provider, exc_class):
    with patch.object(provider.eth, "send_raw_transaction", AsyncMock(side_effect=exc_class("network failure"))):
        with pytest.raises(exc_class):
            await mrpc._send_transaction(provider, b"raw_tx")

