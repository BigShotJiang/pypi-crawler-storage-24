import pytest

from multirpc.utils import truncate_rpc_url


@pytest.mark.parametrize("url,expected", [
    # eRPC-style URL with token in path
    (
        "https://erpc-dev.symmio.foundation/1jG-pTiRLOfvzmGhp_bC62dfuiV6uvnUvbljc/base-aggressive/evm/8453",
        "erpc-dev.symmio.foundation/1jG-***bljc/base-aggressive/evm/8453",
    ),
    # QuickNode-style URL with token in path
    (
        "https://broken-cosmopolitan-daylight.base-mainnet.quiknode.pro/9ead9db04f5a78fc5b813e0dfe98d7df/",
        "broken-cosmopolitan-daylight.base-mainnet.quiknode.pro/9ead***d7df/",
    ),
    # Plain URL without token
    (
        "https://rpc.ankr.com/base",
        "rpc.ankr.com/base",
    ),
    # HTTP scheme
    (
        "http://localhost:8545",
        "localhost:8545",
    ),
    # No scheme
    (
        "rpc.example.com/eth",
        "rpc.example.com/eth",
    ),
    # Short path segments are not truncated
    (
        "https://example.com/short/path",
        "example.com/short/path",
    ),
    # Long alphanumeric with digits gets truncated
    (
        "https://example.com/abc1efghijklmnop",
        "example.com/abc1***mnop",
    ),
    # Exactly at threshold (12 chars) with digit - gets truncated
    (
        "https://example.com/abcdefghijk1",
        "example.com/abcd***ijk1",
    ),
    # Below threshold (11 chars) - not truncated
    (
        "https://example.com/abcdefghijk",
        "example.com/abcdefghijk",
    ),
    # Long purely alphabetic segment - not truncated (not a token)
    (
        "https://example.com/base-aggressive",
        "example.com/base-aggressive",
    ),
])
def test_truncate_rpc_url(url, expected):
    assert truncate_rpc_url(url) == expected
