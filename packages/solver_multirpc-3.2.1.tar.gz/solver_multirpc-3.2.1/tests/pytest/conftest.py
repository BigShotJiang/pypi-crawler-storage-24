import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from multirpc.base_multi_rpc_interface import BaseMultiRpc


@pytest.fixture
def mrpc():
    instance = BaseMultiRpc.__new__(BaseMultiRpc)
    instance.apm = None
    instance.is_flash_block_aware = False
    return instance


@pytest.fixture
def provider():
    p = MagicMock()
    p.provider.endpoint_uri = "http://erpc.test/rpc"
    p.eth.chain_id = AsyncMock(return_value=1)
    return p


@pytest.fixture(autouse=True)
def silence_mrpc_logger():
    with patch("multirpc.base_multi_rpc_interface.MultiRPCLogger"):
        yield


def make_provider(url="http://rpc1.test"):
    p = MagicMock()
    p.provider.endpoint_uri = url
    return p


def make_signed_tx():
    signed = MagicMock()
    signed.hash = b"\xde\xad\xbe\xef" * 8
    signed.raw_transaction = b"raw_tx"
    return signed
