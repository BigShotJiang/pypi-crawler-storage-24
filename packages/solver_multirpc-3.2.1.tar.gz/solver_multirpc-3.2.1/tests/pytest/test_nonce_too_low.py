"""
Unit tests for NonceTooLowError — _send_transaction detection, __execute_batch_tasks
priority raising, and end-to-end propagation through __call_tx. No real network calls.
"""
import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from web3.exceptions import Web3RPCError
from web3.types import RPCError, RPCResponse
from requests import ConnectionError

from multirpc.base_multi_rpc_interface import BaseMultiRpc
from multirpc.exceptions import NonceTooLowError
from tests.pytest.conftest import make_provider, make_signed_tx


def call_tx(mrpc, providers):
    return mrpc._BaseMultiRpc__call_tx(
        func_name="transfer",
        func_args=(),
        func_kwargs={},
        private_key="0x" + "aa" * 32,
        wait_for_receipt=0,
        providers=providers,
        contracts=[MagicMock() for _ in providers],
        tx_params={},
        enable_estimate_gas_limit=False,
    )


# ---------------------------------------------------------------------------
# _send_transaction — nonce error detection
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
@pytest.mark.parametrize("message,code", [
    ("nonce too low", -32000),
    ("invalid nonce", -32000),
])
async def test_send_transaction_nonce_errors_raise_nonce_too_low(mrpc, provider, message, code):
    err = Web3RPCError(message, rpc_response=RPCResponse(error=RPCError(message=message, code=code)))
    with patch.object(provider.eth, "send_raw_transaction", AsyncMock(side_effect=err)):
        with pytest.raises(NonceTooLowError):
            await mrpc._send_transaction(provider, b"raw_tx")


# ---------------------------------------------------------------------------
# __execute_batch_tasks — NonceTooLowError priority
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_execute_batch_tasks_all_nonce_errors_raise_nonce_too_low():
    """All RPCs raise NonceTooLowError → NonceTooLowError propagates."""
    async def failing_task():
        raise NonceTooLowError()

    with pytest.raises(NonceTooLowError):
        await BaseMultiRpc._BaseMultiRpc__execute_batch_tasks(
            [failing_task(), failing_task()],
            ignored_exceptions=[NonceTooLowError],
            final_exception=None,
            priority_exceptions=[NonceTooLowError],
        )


@pytest.mark.asyncio
async def test_execute_batch_tasks_mixed_errors_nonce_wins():
    """Mix of NonceTooLowError and generic errors → NonceTooLowError wins."""
    async def nonce_task():
        raise NonceTooLowError()

    async def generic_task():
        raise ValueError("some other error")

    with pytest.raises(NonceTooLowError):
        await BaseMultiRpc._BaseMultiRpc__execute_batch_tasks(
            [generic_task(), nonce_task()],
            ignored_exceptions=[NonceTooLowError, ValueError],
            final_exception=None,
            priority_exceptions=[NonceTooLowError],
        )


# ---------------------------------------------------------------------------
# __call_tx — NonceTooLowError propagation
# ---------------------------------------------------------------------------

@pytest.mark.asyncio
async def test_call_tx_all_rpcs_nonce_too_low_raises_nonce_error(mrpc):
    """All RPCs return nonce-too-low → NonceTooLowError raised, not FailedOnAllRPCs."""
    providers = [make_provider("http://rpc1.test"), make_provider("http://rpc2.test")]
    signed_tx = make_signed_tx()

    with patch.object(mrpc, "_build_and_sign_transaction", AsyncMock(return_value=signed_tx)), \
         patch.object(mrpc, "_send_transaction", AsyncMock(side_effect=NonceTooLowError())), \
         patch.object(mrpc, "_logger_params"):
        with pytest.raises(NonceTooLowError):
            await call_tx(mrpc, providers)


@pytest.mark.asyncio
async def test_call_tx_one_nonce_one_connection_error_raises_nonce_error(mrpc):
    """One RPC returns nonce-too-low, another a connection error → NonceTooLowError wins."""
    providers = [make_provider("http://rpc1.test"), make_provider("http://rpc2.test")]
    signed_tx = make_signed_tx()

    with patch.object(mrpc, "_build_and_sign_transaction", AsyncMock(return_value=signed_tx)), \
         patch.object(mrpc, "_send_transaction", AsyncMock(side_effect=[NonceTooLowError(), ConnectionError("timeout")])), \
         patch.object(mrpc, "_logger_params"):
        with pytest.raises(NonceTooLowError):
            await call_tx(mrpc, providers)


@pytest.mark.asyncio
async def test_call_tx_all_connection_errors_does_not_raise_nonce_error(mrpc):
    """All RPCs fail with connection errors (no nonce error) → ConnectionError raised, not NonceTooLowError."""
    providers = [make_provider("http://rpc1.test"), make_provider("http://rpc2.test")]
    signed_tx = make_signed_tx()

    with patch.object(mrpc, "_build_and_sign_transaction", AsyncMock(return_value=signed_tx)), \
         patch.object(mrpc, "_send_transaction", AsyncMock(side_effect=ConnectionError("timeout"))), \
         patch.object(mrpc, "_logger_params"):
        with pytest.raises(ConnectionError):
            await call_tx(mrpc, providers)
