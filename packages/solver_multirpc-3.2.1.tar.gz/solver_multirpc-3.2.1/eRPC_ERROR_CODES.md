# eRPC Error Codes Reference

eRPC normalizes error messages from upstream RPC providers into a consistent format. This means error messages returned by eRPC **will differ** from the raw messages returned by direct RPC providers.

> **Why?** eRPC routes requests across multiple upstream providers (Alchemy, Infura, QuickNode, etc.), each of which returns different error formats for the same condition. eRPC normalizes these into a predictable set of error codes and messages so clients can handle errors consistently regardless of which upstream served the request.

## Important: Match on Error Codes, Not Messages

Always use the **numeric JSON-RPC error code** for programmatic error handling, not the message string. Error codes are stable; messages may evolve.

```jsonc
// Error response format
{
  "jsonrpc": "2.0",
  "id": 1,
  "error": {
    "code": -32014,       // <-- Use this for error handling
    "message": "...",     // <-- Human-readable, may change
    "data": { ... }       // <-- May contain original upstream error details
  }
}
```

---

## JSON-RPC Error Codes

### Standard JSON-RPC Errors

| Code | Name | Description | HTTP Status |
|------|------|-------------|-------------|
| `-32700` | Parse Error | Invalid JSON in request body | 400 |
| `-32600` | Invalid Request | Malformed JSON-RPC request (bad params, missing fields) | 400 |
| `-32601` | Method Not Found | Method is not supported or not whitelisted | 406 |
| `-32602` | Invalid Params | Invalid method parameters | 400 |
| `-32603` | Internal Error | Internal server-side error | 500 |

### EVM / eRPC Extended Errors

| Code | Name | Description | HTTP Status |
|------|------|-------------|-------------|
| `3` | Execution Reverted | EVM execution reverted (contract revert, out of gas, etc.) | 200 |
| `-32000` | Call Exception | Server error during eth_call or execution | 200 |
| `-32003` | Transaction Rejected | Transaction rejected by the node | 200 |
| `-32005` | Capacity Exceeded | Rate limit or quota exceeded | 429 |
| `-32012` | Range Too Large | `eth_getLogs` block range or result set too large | 413 |
| `-32014` | Missing Data | Requested data not available (block not yet indexed, missing trie node, pruned state) | 200 |
| `-32015` | Node Timeout | Upstream node execution timeout | 504 |
| `-32016` | Unauthorized | Invalid or missing API key / authentication failure | 401 |

---

## Error Normalization: What Changes and Why

Below is a mapping of common upstream error messages to what eRPC returns. Use this to update your exception handling.

### Block / Data Not Found (`-32014`)

| Upstream message (examples) | eRPC normalized message |
|---|---|
| `"Block with id: <id> not found."` | `"block not found with number <id>"` |
| `"header not found"` | `"block not found"` |
| `"could not find block"` | `"block not found"` |
| `"unknown block"` | `"block not found"` |
| `"block <N> not found"` | `"block not found"` |
| `"missing trie node <hash>"` | `"missing trie node 0xREDACTED"` |
| `"header for hash not found"` | `"missing data"` |
| `"height must be less than or equal to ..."` | `"missing data"` |
| `"transaction not found"` | `"missing data"` |

**How to handle:**
```python
if error["code"] == -32014:
    # Data not yet available - retry after a delay, or the block/state is pruned
    pass
```

### Execution Reverted / EVM Errors (`3` or `-32000`)

| Upstream message (examples) | eRPC normalized message |
|---|---|
| `"nonce too low"` | `"invalid nonce"` or `"nonce too low"` |
| `"execution reverted"` | `"execution reverted"` |
| `"execution reverted: <reason>"` | `"execution reverted: <reason>"` |
| `"VM Exception while processing"` | `"execution reverted"` |
| `"VM execution error"` | `"execution reverted"` |
| `"out of gas"` | `"out of gas"` |
| `"gas too low"` | `"gas too low"` |
| `"intrinsic gas too low"` | `"intrinsic gas too low"` |
| `"insufficient balance"` | `"insufficient balance"` |

**How to handle:**
```python
if error["code"] == 3 or error["code"] == -32000:
    # EVM execution failed - check message for specifics
    # These are NOT retryable (the transaction itself is invalid)
    msg = error["message"].lower()
    if "revert" in msg:
        # Contract logic rejected the call
        pass
    elif "gas" in msg:
        # Gas estimation issue
        pass
    elif "nonce" in msg:
        # Nonce mismatch - fetch fresh nonce and retry
        pass
    elif "insufficient" in msg:
        # Insufficient funds
        pass
```

### Rate Limiting (`-32005`)

| Upstream message (examples) | eRPC normalized message |
|---|---|
| `"Too many requests"` | `"rate limit exceeded"` |
| `"rate limit exceeded"` | `"rate limit exceeded"` |
| `"Exceeded the quota"` | `"capacity exceeded"` |
| `"request limit reached"` | `"capacity exceeded"` |
| `"No server available"` | `"capacity exceeded"` |

**How to handle:**
```python
if error["code"] == -32005:
    # Rate limited - back off and retry with exponential delay
    pass
```

### Range Too Large (`-32012`)

| Upstream message (examples) | eRPC normalized message |
|---|---|
| `"block range is too wide"` | `"getLogs request exceeded max allowed range"` |
| `"range too large"` | `"getLogs request exceeded max allowed range"` |
| `"exceeds max results"` | `"getLogs request exceeded max allowed range"` |
| `"response size should not exceed ..."` | `"getLogs request exceeded max allowed range"` |
| `"eth_getLogs is limited to ..."` | `"getLogs request exceeded max allowed range"` |

**How to handle:**
```python
if error["code"] == -32012:
    # Split your eth_getLogs request into smaller block ranges and retry
    pass
```

### Unauthorized (`-32016`)

| Upstream message (examples) | eRPC normalized message |
|---|---|
| `"invalid api key"` | `"unauthorized"` |
| `"key is inactive"` | `"unauthorized"` |
| `"unauthorized"` | `"unauthorized"` |
| HTTP 401 / 403 responses | `"unauthorized"` |

**How to handle:**
```python
if error["code"] == -32016:
    # Check your AUTH token in the Authorization header
    pass
```

### Method Not Supported (`-32601`)

| Upstream message (examples) | eRPC normalized message |
|---|---|
| `"Unsupported method"` | `"method not supported"` |
| `"method not found"` | `"method not supported"` |
| `"not whitelisted"` | `"method not supported"` |
| `"not included in your current plan"` | `"method not supported"` |

**How to handle:**
```python
if error["code"] == -32601:
    # This method is not available - do not retry
    pass
```

### Invalid / Malformed Request (`-32600` / `-32602`)

| Upstream message (examples) | eRPC normalized message |
|---|---|
| `"pending block not found"` | `"unsupported block tag"` |
| `"finalized is not supported"` | `"unsupported block tag"` |
| `"malformed blocknumber"` | `"invalid block number"` |
| `"param is required"` | `"missing required parameter"` |
| `"transaction too short"` | `"invalid transaction"` |
| `"invalid transaction"` | `"invalid transaction"` |

**How to handle:**
```python
if error["code"] in (-32600, -32602):
    # Fix the request parameters - do not retry as-is
    pass
```

---

## Transaction-Specific Behavior

eRPC has special handling for `eth_sendRawTransaction`:

| Scenario | Upstream message | eRPC behavior |
|---|---|---|
| TX already in mempool | `"already known"`, `"already imported"`, `"tx already in mempool"` | Returns **success** (idempotent - your TX was received) |
| Nonce already used | `"nonce too low"`, `"nonce has already been used"` | Checks if TX exists on-chain; returns **success** if confirmed |
| Insufficient funds | `"insufficient funds"` | Returns error code `3` or `-32000` |
| Invalid TX format | `"rlp: expected input list"`, `"transaction too short"` | Returns error code `-32600` (not retryable) |

---

## Upstreams Exhausted Error

When **all** upstream providers fail for a request, eRPC returns an aggregated error:

```json
{
  "code": -32603,
  "message": "all upstreams failed: <most common error message>"
}
```

HTTP status: **502**. This typically means a transient issue across all providers. Retry with backoff.

---

## Message Sanitization

eRPC sanitizes error messages for security:

| What | Replacement |
|------|-------------|
| Transaction hashes (`0xabcd...`) | `0xREDACTED` |
| IP addresses | `X.X.X.X` |
| Long tokens (31+ chars) | `XX` |
| Messages over 512 characters | Truncated |

---

## Quick Reference: Error Handling by Code

```python
RETRIABLE_CODES = {-32005, -32603, -32015}
NOT_RETRIABLE_CODES = {3, -32000, -32600, -32601, -32602, -32016}
SPLIT_AND_RETRY_CODES = {-32012}
DATA_UNAVAILABLE_CODES = {-32014}

def handle_erpc_error(error):
    code = error.get("code")

    if code in NOT_RETRIABLE_CODES:
        # Fix the request or handle the application-level error
        raise ApplicationError(error["message"])

    elif code in RETRIABLE_CODES:
        # Transient error - retry with exponential backoff
        retry_with_backoff()

    elif code in SPLIT_AND_RETRY_CODES:
        # Split eth_getLogs into smaller ranges
        split_and_retry()

    elif code in DATA_UNAVAILABLE_CODES:
        # Data not available yet - wait and retry, or data is pruned
        wait_and_retry()

    elif code == -32016:
        # Auth issue - check credentials
        raise AuthenticationError(error["message"])
```

---

## Full Error Code Table

| Code | Category | Retryable? | Action |
|------|----------|------------|--------|
| `-32700` | Parse error | No | Fix request JSON |
| `-32600` | Invalid request | No | Fix request format |
| `-32601` | Method not found | No | Use a supported method |
| `-32602` | Invalid params | No | Fix request parameters |
| `-32603` | Internal error | Yes | Retry with backoff |
| `-32005` | Rate limited | Yes | Retry with backoff |
| `-32012` | Range too large | No* | Split into smaller ranges |
| `-32014` | Missing data | Maybe | Wait and retry, or data is pruned |
| `-32015` | Node timeout | Yes | Retry with backoff |
| `-32016` | Unauthorized | No | Check AUTH token |
| `-32000` | Call exception | No | Fix transaction/call params |
| `-32003` | TX rejected | No | Fix transaction params |
| `3` | EVM reverted | No | Check contract logic / params |
