import os
import base64
import mimetypes
from typing import Dict
from .logger import ss_logger

try:
    import magic
    _has_magic = True
except ImportError:
    _has_magic = False


def _detect_mime_type(file_path: str) -> str:
    if _has_magic:
        return magic.from_file(file_path, mime=True)
    mime_type, _ = mimetypes.guess_type(file_path)
    return mime_type or "application/octet-stream"


def check_is_web_url(file_path: str):
    for url_scheme in ["https://", "http://"]:
        if file_path.startswith(url_scheme):
            return True
    return False


def get_attachment_json_for_file(file_path: str, file_name: str, ignore_if_error: bool) -> Dict:
    # Ensure that path is expanded and absolute
    abs_path = os.path.abspath(os.path.expanduser(file_path))
    # Get attachment json
    try:
        with open(abs_path, "rb") as f:
            final_file_name = os.path.basename(abs_path)
            if file_name and file_name.strip():
                final_file_name = file_name.strip()
            # --
            mime_type = _detect_mime_type(abs_path)
            # base64 encoded string
            b64encoded = base64.b64encode(f.read())
            b64data = b64encoded.decode()
            attach_data = {
                "filename": final_file_name,
                "contentType": mime_type,
                "data": b64data,
                "url": None,
                "ignore_if_error": ignore_if_error,
            }
            return attach_data
    except OSError as ex:
        if ignore_if_error:
            ss_logger.warning("Ignoring error while processing attachment file. "
                                "%s: %s", type(ex).__name__, ex)
            return None
        else:
            raise ex


def get_attachment_json_for_url(file_url: str, file_name: str, ignore_if_error: bool) -> Dict:
    return {
        "filename": file_name,
        "contentType": None,
        "data": None,
        "url": file_url,
        "ignore_if_error": ignore_if_error,
    }


def get_attachment_json(file_path: str, file_name: str = None, ignore_if_error: bool = False) -> Dict:
    if check_is_web_url(file_path):
        return get_attachment_json_for_url(file_path, file_name, ignore_if_error)
    else:
        return get_attachment_json_for_file(file_path, file_name, ignore_if_error)
