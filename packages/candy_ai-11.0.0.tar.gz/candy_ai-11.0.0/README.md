# 🍬 candy-ai v10

Client Python pour **cedric-8EF** — moteur IA multi-personnalités.  
Zéro configuration · 50 personnalités · CLI · Helper · Fichiers .cdy · Profils · Conversations

---

## Installation

```bash
pip install candy-ai
```

---

## CLI — Commandes terminal

### `candy helper` — Fenêtre Helper

```bash
candy helper
```

Ouvre une fenêtre graphique où tu décris ce que tu veux faire.
Le code candy est généré automatiquement. Tu peux :
- ▶ **Exécuter** le code directement
- 💾 **Enregistrer** en `.cdy`
- Utiliser les **templates rapides** (livre, traduction, chatbot, pipeline...)

### `candy -- script.cdy` — Exécuter un fichier .cdy

```bash
candy -- mon_script.cdy
```

Les fichiers `.cdy` sont du **code Python candy** avec une extension dédiée.
Tu peux les créer depuis la fenêtre Helper ou à la main.

**Exemple `bonjour.cdy` :**
```python
from candy import cfg, Coding

cfg.default.lang  = "FR"
cfg.default.style = "concise"

print(Coding.ask("Dis bonjour en 3 langues"))
```

```bash
candy -- bonjour.cdy
```

---

## 🤖 Helper — Génère du code candy

```python
from candy import Helper

Helper.list()   # templates disponibles

# Générer du code
code = Helper.write("livre", sujet="Napoléon", lang="FR", chapitres=20)
Helper.run("chatbot", lang="FR", module="Full")
Helper.preview("pipeline", tache="analyser un CSV", lang="FR")
```

**Templates :**

| Template | Description |
|----------|-------------|
| `livre` | Livre de N chapitres |
| `traduction` | Traduire vers plusieurs langues |
| `chatbot` | Chatbot interactif |
| `pipeline` | Coding → Debugger → Reviewer |
| `batch` | Plusieurs questions d'un coup |
| `résumé` | Résumer un texte |
| `question` | Poser une question |

---

## Profils

```python
from candy import cfg, Coding

cfg.A.lang       = "FR"
cfg.A.max_tokens = 2000
cfg.A.style      = "detailed"

cfg.A = cfg.preset("french_beginner")
cfg.default.lang = "FR"

print(Coding.ask("Hello"))
print(Coding.use("A").ask("Explique les listes"))
```

**Presets :** `french_beginner` `french_expert` `english_beginner` `english_expert`
`quick` `academic` `creative` `teacher` `coder` `journalist` `storyteller` `analyst` `coach` `debug`

---

## Tous les paramètres

| Paramètre | Défaut | Valeurs |
|-----------|--------|---------|
| `lang` | `"EN"` | `FR EN ES DE IT PT ZH JA AR RU NL PL SV TR KO HI VI ID CS RO` |
| `max_tokens` | `1024` | `100` → `4096` |
| `temperature` | `0.7` | `0.0` → `1.5` |
| `style` | `"default"` | `default concise detailed bullet academic casual technical eli5` |
| `tone` | `"neutral"` | `neutral encouraging strict humorous empathetic socratic` |
| `output_format` | `"text"` | `text markdown json html` |
| `expertise` | `"intermediate"` | `beginner intermediate expert` |
| `include_examples` | `True` | `True / False` |
| `safe_mode` | `True` | `True / False` |
| `timeout` | `120` | secondes |
| `retry` | `1` | tentatives |
| `verbose` | `False` | True = logs des requêtes |

---

## Conversations multi-tours

```python
session = Coding.chat(profile="A")
print(session.say("Explique les décorateurs"))
print(session.say("Donne un exemple"))
session.save("chat.json")
```

---

## Batch · Streaming · Utilitaires

```python
# Batch
réponses = Coding.use("A").batch(["Q1 ?", "Q2 ?", "Q3 ?"])

# Streaming
Writing.use("A").stream_print("Écris une histoire")

# Utilitaires
Coding.is_online()
Coding.ping()
Coding.quota()
cfg.A.reset()
```

---

## Les 50 personnalités

`Math` `Coding` `Reflexion` `Analytic` `Full` `Science` `Writing` `History`
`Law` `Medicine` `Finance` `Marketing` `Security` `Design` `Language`
`Psychology` `Education` `Research` `Business` `Productivity` `Cooking`
`Travel` `Music` `Film` `Sports` `Philosophy` `Environment` `Architecture`
`Automotive` `Astronomy` `Biology` `Chemistry` `Physics` `Engineering`
`Entrepreneur` `Ethics` `Geopolitics` `Crypto` `AI` `DevOps` `Database`
`GameDev` `Comic` `Storyteller` `Translator` `Summarizer` `Debugger`
`Reviewer` `Planner` `Tutor`

---

Propulsé par **cedric-8EF** · Quota 500 req/jour · MIT License
