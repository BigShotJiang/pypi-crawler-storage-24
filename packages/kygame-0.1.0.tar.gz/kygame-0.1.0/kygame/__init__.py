from kivy.uix.image import Image
from kivy.clock import Clock
from kivy.graphics.texture import Texture
import pygame

class KyGame(Image):
    def __init__(self, screen, fps=60, **kwargs):
        super().__init__(**kwargs)
        self.screen = screen
        # Автоматически обновляем экран с заданным FPS
        Clock.schedule_interval(self.update_canvas, 1.0 / fps)

    def update_canvas(self, dt):
        # Переводим графику Pygame в байты
        raw_data = pygame.image.tostring(self.screen, 'RGBA', False)
        
        # Создаем текстуру, если она еще не создана
        if not self.texture:
            w, h = self.screen.get_size()
            self.texture = Texture.create(size=(w, h), colorfmt='rgba')
            self.texture.flip_vertical()

        # Обновляем картинку
        self.texture.blit_buffer(raw_data, colorfmt='rgba', bufferfmt='ubyte')
        self.canvas.ask_update()
