# kygame 🐍📱

**kygame** — это легкий мост между Kivy и Pygame (pygame-ce). 
Создавайте игры на Pygame и запускайте их внутри Kivy-приложений с полноценной поддержкой мобильного тачскрина!

## Установка
```bash
pip install kygame
