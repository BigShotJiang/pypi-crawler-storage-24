"""Centralized error handling for the Okareo MCP server.

Classifies exceptions into user-friendly categories and formats
consistent, sanitized error responses for MCP tool calls.
"""

import json
import os

from src.key_registry import sanitize_error


def classify_error(exc: Exception) -> str:
    """Map an exception to an error category.

    Categories:
        connectivity  — network, DNS, SSL, timeout errors
        authentication — invalid API key, 401/403 responses
        validation     — invalid inputs, missing fields
        server_error   — API 500s, unexpected SDK errors, unknown errors

    Args:
        exc: The caught exception.

    Returns:
        One of: "connectivity", "authentication", "validation", "server_error".
    """
    exc_type = type(exc).__name__
    exc_module = type(exc).__module__ or ""

    # Connectivity: httpx and stdlib network/timeout errors
    if exc_type in (
        "ConnectError",
        "ConnectTimeout",
        "TimeoutException",
        "ReadTimeout",
        "WriteTimeout",
        "PoolTimeout",
        "ProxyError",
        "NetworkError",
    ) or (exc_module.startswith("httpx") and "timeout" in exc_type.lower()):
        return "connectivity"

    if isinstance(exc, (ConnectionError, TimeoutError, OSError)):
        if isinstance(exc, OSError) and not isinstance(
            exc, (ConnectionError, TimeoutError)
        ):
            # Only OS errors related to networking
            err = str(exc).lower()
            if any(
                w in err
                for w in ("refused", "reset", "unreachable", "network", "dns")
            ):
                return "connectivity"
            return "server_error"
        return "connectivity"

    # Authentication: TypeError from Okareo SDK (invalid key) or HTTP 401/403
    if isinstance(exc, TypeError):
        return "authentication"

    if exc_type == "HTTPStatusError":
        status = getattr(getattr(exc, "response", None), "status_code", 0)
        if status in (401, 403):
            return "authentication"
        return "server_error"

    if exc_type == "UnexpectedStatus":
        status = getattr(exc, "status_code", 0)
        if status in (401, 403):
            return "authentication"
        return "server_error"

    # Validation: ValueError from input checking
    if isinstance(exc, ValueError):
        return "validation"

    return "server_error"


_SUGGESTIONS = {
    "connectivity": "Check your network connection and try again.",
    "authentication": (
        "Verify your OKAREO_API_KEY at app.okareo.com and update "
        "your MCP server configuration."
    ),
    "validation": "Check the input parameters and try again.",
    "server_error": "The Okareo API encountered an error. Please try again later.",
}


def _build_message(exc: Exception, category: str) -> str:
    """Build a user-readable error message from the exception."""
    exc_type = type(exc).__name__

    if category == "connectivity":
        if "timeout" in exc_type.lower() or isinstance(exc, TimeoutError):
            return "Request to the Okareo API timed out."
        return "Cannot connect to the Okareo API."

    if category == "authentication":
        if isinstance(exc, TypeError):
            return "Invalid API key format."
        return "Authentication failed."

    if category == "validation":
        return str(exc)

    # server_error
    status = getattr(exc, "status_code", None)
    if status is None:
        status = getattr(getattr(exc, "response", None), "status_code", None)
    if status:
        return f"The Okareo API returned an error (HTTP {status})."

    return f"An unexpected error occurred: {exc_type}"


def format_tool_error(
    exc: Exception, key_registry: dict[str, str] | None = None
) -> str:
    """Format an exception as a consistent, sanitized JSON error response.

    Args:
        exc: The caught exception.
        key_registry: Provider key registry for sanitization.
            If None, only OKAREO_API_KEY is sanitized.

    Returns:
        A JSON string: {"error": {"category": ..., "message": ..., "suggestion": ...}}
    """
    if key_registry is None:
        key_registry = {}

    category = classify_error(exc)
    message = _build_message(exc, category)
    suggestion = _SUGGESTIONS[category]

    # Sanitize: strip provider keys
    message = sanitize_error(message, key_registry)
    suggestion = sanitize_error(suggestion, key_registry)

    # Also strip the OKAREO_API_KEY value itself
    okareo_key = os.environ.get("OKAREO_API_KEY", "").strip()
    if okareo_key and okareo_key in message:
        message = message.replace(okareo_key, "[REDACTED]")

    return json.dumps(
        {
            "error": {
                "category": category,
                "message": message,
                "suggestion": suggestion,
            }
        }
    )
