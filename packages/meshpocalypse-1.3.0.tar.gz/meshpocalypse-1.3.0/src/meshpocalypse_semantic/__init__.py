"""
Meshpocalypse Semantic Python SDK.

Provides an async Python client for the Meshpocalypse semantic mesh:
- NATS messaging via the async context manager ``MeshNode``
- SPARQL query/update over NATS via ``SparqlClient``
- ATF trust-level checks via ``ATFClient``

Usage::

    from meshpocalypse_semantic import MeshNode

    async with MeshNode("nats://localhost:4222") as mesh:
        result = await mesh.sparql.query("SELECT ?s WHERE { ?s a <...> }")
        trust_level = await mesh.atf.get_trust_level("did:mesh:agent-1")
        await mesh.publish("mesh.events.test", b"hello")
"""

from .client import MeshNode
from .sparql import SparqlClient, SparqlQueryError
from .atf import ATFClient, ATFLevel, ATFError
from .swarm_node import SwarmNode, SwarmNodeConfig
from .mcp_server import MCPServerConfig, MCPTool, start_mcp_server

__all__ = [
    "MeshNode",
    "SparqlClient",
    "SparqlQueryError",
    "ATFClient",
    "ATFLevel",
    "ATFError",
    "SwarmNode",
    "SwarmNodeConfig",
    "MCPServerConfig",
    "MCPTool",
    "start_mcp_server",
]

__version__ = "1.2.0"
