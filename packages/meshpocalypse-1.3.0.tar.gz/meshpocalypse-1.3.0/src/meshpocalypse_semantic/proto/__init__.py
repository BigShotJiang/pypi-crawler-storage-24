"""
Proto stubs for Meshpocalypse Semantic wire format.

The ``AgentMeshPacket`` and related message types are defined in
``agentmesh/v1/agentmesh.proto``. This package exposes Python-compatible
dataclasses that mirror the protobuf schema for use with the ``protobuf``
library.

For production use with a live Meshpocalypse mesh, run ``buf generate``
in the repo root to regenerate fully-typed stubs from the canonical
``.proto`` source files.
"""

from .agentmesh_pb2 import AgentMeshPacket, AgentCard, AckPacket, Heartbeat

__all__ = ["AgentMeshPacket", "AgentCard", "AckPacket", "Heartbeat"]
