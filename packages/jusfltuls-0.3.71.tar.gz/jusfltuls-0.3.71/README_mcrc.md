# MCRC - Midnight Commander with Rclone and Restic Backup

A terminal-based file manager combining rclone cloud storage operations with restic backup functionality.

## Requirements

- Python 3.8+
- `rclone` - configured with at least one remote
- `restic` >= 0.17.3 (for backup/restore features)
- POSIX-compatible shell

## Installation

```bash
pip install -e .
```

Or run directly:
```bash
python -m jusfltuls.mcrc
```

## Usage

```bash
mcrc [--remote REMOTE] [--refresh SECONDS] [--debug]
```

Options:
- `-r, --remote`: Pre-select rclone remote
- `-f, --refresh`: Auto-refresh interval (0=disabled)
- `-d, --debug`: Enable debug mode

## Key Bindings

### Navigation
- `↑↓` / `PgUp/PgDn` / `Home/End` - Navigate files
- `Tab` / `←→` - Switch panels
- `Enter` - Enter directory
- `r` - Refresh panels

### File Operations (Rclone)
- `2` / `F2` - Mount remote at `/mnt/<remote>`
- `3` / `F3` - Check/compare directories (size-only)
- `4` / `F4` - View text files (local/remote)
- `5` / `F5` - Copy file/directory
- `7` / `F7` - Create directory (remote)
- `8` / `F8` - Delete/purge (remote)
- `9` / `F9` / `s` - Sync directories

### Backup Operations (Restic)
- `b` - Backup local folder to remote (creates `restic_<folder>`)
- `e` - Restore from `restic_*` folder to `/tmp/` or local

### System
- `h` / `F1` - Help
- `q` - Quit

## Workflow Examples

**Mount Google Drive:**
1. Select remote in right panel
2. Press `2` or `F2`
3. Mounts at `/mnt/<remote>` with proper permissions

**Backup local project:**
1. Navigate to project folder in left panel
2. Press `b`
3. Creates `restic_<project>` on remote

**Restore backup:**
1. Find `restic_<name>` folder in remote panel
2. Press `e`
3. Choose: restore to `/tmp/` (safe) or overwrite local

## Features

- Two-panel interface (local filesystem | rclone remote)
- Automatic mount point creation with sticky bit
- Exclusions: `.git`, `.venv`, `.*~`, `uv.lock`, `.ruff_cache`
- View files in default editor ($EDITOR, vi, nano)
- Passwordless restic repositories (0.17.3+)

---

## Appendix: Command Reference

### Rclone Commands

| Function | Command |
|----------|---------|
| List remotes | `rclone listremotes` |
| List directory | `rclone lsf --dir-slash --format p <path>` |
| | `rclone lsd <path>` |
| Copy file | `rclone copyto <src> <dst> --progress` |
| Copy dir | `rclone copy <src> <dst> --progress --exclude...` |
| Sync | `rclone sync <src> <dst> --metadata --progress --exclude...` |
| Check | `rclone check <src> <dst> --size-only --progress --exclude...` |
| Delete file | `rclone deletefile <path> --progress` |
| Purge dir | `rclone purge <path> --progress [--dry-run]` |
| Mkdir | `rclone mkdir <path>` |
| Mount | `rclone mount <remote>: <mountpoint> --vfs-cache-mode writes --daemon` |
| Copy to tmp | `rclone copyto <remote_path> <tmp_file>` |

**Exclusions:**
- `.git/**`
- `.venv/**`
- `venv/**`
- `env/**`
- `.opencode/**`
- `.openai_*`
- `.*~`
- `.python-version`
- `.python-cache/**`
- `.pytest_cache/**`
- `.ruff_cache/*`

### Restic Commands

| Function | Command |
|----------|---------|
| Check repo | `RESTIC_REPOSITORY="rclone:<remote>:restic_<name>" restic snapshots --insecure-no-password` |
| Init repo | `RESTIC_REPOSITORY="rclone:<remote>:restic_<name>" restic init --insecure-no-password` |
| Backup | `RESTIC_REPOSITORY="rclone:<remote>:restic_<name>" restic backup <folder> --verbose --insecure-no-password --exclude=.venv/* --exclude=uv.lock --exclude=.*~ --exclude=.ruff_cache/*` |
| Restore | `RESTIC_REPOSITORY="rclone:<remote>:restic_<name>" restic restore latest --target <folder> --insecure-no-password` |

**Backup naming:** All restic repositories on remote are prefixed with `restic_`

### Mount Setup

```bash
# Directory creation
mkdir -p /mnt/<remote>

# Permissions
chmod +t /mnt/<remote>        # sticky bit
chown <user>:<user> /mnt/<remote>
```

## License

See project root for license information.
