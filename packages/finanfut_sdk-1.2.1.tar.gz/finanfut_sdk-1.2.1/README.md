# FinanFut Intelligence Python SDK

Official Python SDK for **FinanFut Intelligence**, a modular AI platform for agents, memory and orchestration.

This package provides a high-level client to interact with FinanFut Intelligence:
- Public `interact` API (`/api/v1/public/requests`) for chat and actions
- Application and agent management
- Memory (settings + records)
- Document ingestion and contextual actions
- Billing & usage
- Developer analytics
- Optional CLI tool: `finanfut`

---

## Installation

```bash
pip install finanfut-sdk
```

Requires **Python >= 3.12**.

---

## Quickstart

```python
from finanfut_sdk import FinanFutClient

client = FinanFutClient(
    api_key="YOUR_API_KEY",
    application_id="YOUR_APPLICATION_ID",
)

response = client.interact.query(
    query="Hello! Schedule a meeting tomorrow at 10.",
    application_agent_id="YOUR_APPLICATION_AGENT_ID",
    intent_id="YOUR_INTENT_ID",
)
print(response.answer, response.model, response.ai_model_id)
```

---

## Configuration (optional)

### Local config file

```bash
mkdir -p ~/.finanfut
```

Create `~/.finanfut/config.json`:

```json
{
  "api_key": "YOUR_API_KEY",
  "application_id": "YOUR_APPLICATION_ID",
  "api_url": "https://finanfut-intelligence.onrender.com"
}
```

Then:

```python
client = FinanFutClient()  # reads from config/env
```

### Environment variables supported

- `FINANFUT_API_KEY`
- `FINANFUT_APPLICATION_ID`
- `FINANFUT_API_URL`

`FINANFUT_API_URL` accepts either the bare host or a URL that already
includes `/api` or `/api/v1`; the SDK normalitza l'adreça perquè no s'hi
afegeixin segments duplicats.

---

## Using agents and intents

```python
# List agents
agents = client.agents.list()

for agent in agents:
    print(agent.name, agent.ai_model_id or "default model")

# Use a specific application agent and intent
response = client.interact.query(
    query="Add an event to my calendar.",
    application_agent_id="UUID_OF_APPLICATION_AGENT",
    intent_id="UUID_OF_INTENT",
)
print(response.answer)
print("Model runtime:", response.model)
print("Model catàleg:", response.ai_model_id)
```

`ai_model_id` reflects the catalog entry resolved by the backend and should be
used whenever you need to persist or audit the concrete model tied to an
agent.

---


## Model resolution i configuració per aplicació

La versió actual de l'SDK Python incorpora dos clients nous:

- `client.models`: consulta de catàleg i gestió de `model-settings`
- `client.application_agents`: inspecció d'agents d'aplicació, intents i compatibilitat

```python
# 1) Catàleg de models actius
catalog = client.models.list(category="chat", only_active=True)

# 2) Settings de model de l'aplicació
settings = client.models.list_application_settings(
    application_id=client.application_id,
    category="chat",
)

# 3) Definir model per defecte (agent_ref="default")
updated = client.models.update_application_setting(
    application_id=client.application_id,
    agent_ref="default",
    payload={
        "ai_model_id": catalog[0].id,
        "category": "chat",
        "temperature": 0.2,
    },
)

# 4) Inspeccionar model resolt per application agent
app_agents = client.application_agents.list(client.application_id)
for agent in app_agents:
    print(agent.name, agent.resolved_model, agent.model_source)
```

## Memory API

```python
settings = client.memory.settings.get(application_id="APP_UUID")

records = client.memory.records.query(
    application_id="APP_UUID",
    application_agent_id="AGENT_UUID",
    query="What was the last scheduled event?"
)
```

---

## Billing & usage

```python
usage = client.billing.get_usage()
print("Total tokens used:", usage.tokens_used)
```

---

## CLI usage

```bash
finanfut init
finanfut interact "Hi!" --agent-id "APP_AGENT_UUID" --intent-id "INTENT_UUID"
finanfut usage
```

---

## Document QA uploads

Use `client.documents.upload` to ingest files or free text for the document QA
agent. You can optionally set `document_type` to bypass automatic
classification and force the backend to tag the file with a known type such as
`context_general`, `examples_set`, `action_definition`, or `schema_contract`.

```python
from pathlib import Path
from finanfut_sdk import FinanFutClient

client = FinanFutClient(api_key="YOUR_API_KEY", application_id="APP_ID")

# Upload a PDF as contextual knowledge
detail = client.documents.upload(
    file_path=Path("knowledge.pdf"),
    document_type="context_general",
)
print(detail.document_type, detail.document_type_label)

# Upload pasted text with a strict contract type
schema_doc = client.documents.upload(
    text="{\"name\": \"Ada\", \"role\": \"engineer\"}",
    file_name="profile.json",
    mime_type="application/json",
    document_type="schema_contract",
)
print(schema_doc.document_type_version)

# Override classification for a curated examples set
client.documents.upload(
    content="Example A -> Response A", file_name="examples.md", document_type="examples_set"
)
```

---

## Mapa actual d'agents/intents per a FinanFut Sports

Per classificar correctament les peticions des de Sports, aquest és el mapa operatiu
actual (snapshot de producció):

- `core_research_agent`: `knowledge.document.ask`, `knowledge.document.chat`, `knowledge.filters.extract`, `knowledge.search.structured`, `sports.wellbeing.journal.analyze`
- `core_writer_agent`: `content.comment.suggest`, `content.post.generate`, `content.rewrite`
- `document_chatbot`: `ask`, `document_chat`
- `sports_analytics_agent`: `sports.analytics.summary`, `sports.operations.query`
- `sports_finance_agent`: `sports.finance.expense.capture`, `sports.finance.invoice.generate`
- `sports_operations_agent`: `sports.operations.query`, `sports.registration.manage`, `sports.results.record`, `sports.schedule.create_or_update`

Per refrescar el mapa des de l'SDK en temps real:

```python
app_agents = client.application_agents.list(client.application_id)
for app_agent in app_agents:
    intents = client.application_agents.get_intents(
        application_id=client.application_id,
        application_agent_id=app_agent.id,
    )
    print(
        app_agent.name,
        [item.intent.name for item in intents if item.intent and item.intent.name],
    )
```

---

## Context operatiu via documents

Per a integracions server-to-server (com Sports), el context es gestiona com
documentació pujada amb tipus `context_general` i es referencia per `document_id`
a cada execució.

```python
context_doc = client.documents.upload(
    file_path="knowledge.md",
    document_type="context_general",
)

response = client.interact.query(
    query="Utilitza aquest context per recomanar una acció",
    application_agent_id="YOUR_APPLICATION_AGENT_ID",
    intent_id="YOUR_INTENT_ID",
    document_id=str(context_doc.id),
)
print(response.answer)
```


## Ingesta de CSV a contractes JSON

L'SDK incorpora utilitats per replicar el flux del *playground* de
`data_transformer_agent`: carregar un CSV efímer, previsualitzar-lo i transformar-lo
segons un contracte JSON existent.

```python
from finanfut_sdk import FinanFutClient

client = FinanFutClient(api_key="YOUR_API_KEY", application_id="APP_ID")

# 1) Pujar el CSV de forma efímera i obtenir previsualització
preview = client.data_import.upload_transient_csv(file_path="ingesta.csv")
print("Cols", preview.preview.columns)
print("Rows", preview.preview.row_count)

# 2) Executar l'intent transform_data amb el contracte desitjat
result = client.data_import.transform_data(
    application_id=client.application_id,
    intent_id="UUID_INTENT_TRANSFORM_DATA",
    transient_csv=preview,
    contract_document_id="UUID_DATA_IMPORT_CONTRACT",
)
print("Primer registre", result.items[0] if result.items else result.response)
```

## Ingesta de PDF a contractes JSON

```python
# 1) Pujar el PDF de forma efímera i obtenir previsualització
preview = client.data_import.upload_transient_pdf(file_path="factura.pdf")

# 2) Transformar el PDF segons el contracte JSON
result = client.data_import.transform_document(
    application_id=client.application_id,
    intent_id="UUID_INTENT_TRANSFORM_DOCUMENT",
    transient_document=preview,
    contract_document_id="UUID_DATA_IMPORT_CONTRACT",
)
print("Primer registre", result.items[0] if result.items else result.response)
```

El client elimina automàticament `content_base64` i retalla la mostra de files
(`rows_sample`) abans d'enviar la petició a `/api/v1/public/requests`, tal i com
espera l'orquestrador. També pots passar `contract_name` (nom del contracte)
en comptes de `contract_document_id` si el teu agent el resol pel nom.

---

## License

This project is licensed under the MIT License.
