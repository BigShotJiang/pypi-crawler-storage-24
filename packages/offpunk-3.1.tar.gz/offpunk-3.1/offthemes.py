#!/bin/python
colors = {
                "bold"   : ["1","22"],
                "faint"  : ["2","22"],
                "italic" : ["3","23"],
                "underline": ["4","24"],
                "black"   : ["30","39"],
                "red"    : ["31","39"],
                "green"    : ["32","39"],
                "yellow" : ["33","39"],
                "blue"   : ["34","39"],
                "purple"   : ["35","39"],
                "cyan"   : ["36","39"],
                "white"   : ["37","39"],
                "background_black"   : ["40","49"],
                "background_red"    : ["41","49"],
                "background_green"    : ["42","49"],
                "background_yellow" : ["43","49"],
                "background_blue"   : ["44","49"],
                "background_purple"   : ["45","49"],
                "background_cyan"   : ["46","49"],
                "background_white"   : ["47","49"],
                "bright_black"   : ["90","39"],
                "bright_red"    : ["91","39"],
                "bright_green"    : ["92","39"],
                "bright_yellow" : ["93","39"],
                "bright_blue"   : ["94","39"],
                "bright_purple"   : ["95","39"],
                "bright_cyan"   : ["96","39"],
                "bright_white"   : ["97","39"],
           }

offpunk1 = {
                "window_title" :    ["red","bold"],
                "window_subtitle" : ["red","faint"],
                "title" :           ["blue","bold","underline"],
                "subtitle" :        ["blue"],
                "subsubtitle" :     ["blue","faint"], #fallback to subtitle if none
                "link"  :           ["blue","faint"],
                "new_link":         ["bold"],
                "blocked_link":     ["red","faint"],
                "oneline_link":     [],     #for gopher/gemini. fallback to link if none
                "image_link" :      ["yellow","faint"],
                "preformatted":     ["faint"],
                "blockquote" :      ["italic"],
                "prompt_on" :       ["yellow"],
                "prompt_off" :      ["green"],
             }  

yellow = {
                "window_title" :    ["red","bold"],
                "window_subtitle" : ["red","faint"],
                "title" :           ["yellow","bold","underline"],
                "subtitle" :        ["yellow","bold"],
                "subsubtitle" :     ["yellow","faint","underline"], #fallback to subtitle if none
                "link"  :           ["yellow","faint"],
                "new_link":         ["bold"],
                "blocked_link":     ["red","faint"],
                "oneline_link":     ["white"],     #for gopher/gemini. fallback to link if none
                "image_link" :      ["yellow","italic","faint"],
                "preformatted":     ["faint"],
                "blockquote" :      ["italic"],
                "prompt_on" :       ["green","bold"],
                "prompt_off" :      ["red","bold"],
        }


cyan =   {
                "window_title" :    ["blue","bold"],
                "window_subtitle" : ["blue","faint"],
                "title" :           ["cyan","bold","underline"],
                "subtitle" :        ["cyan","bold"],
                "subsubtitle" :     ["cyan","faint","underline"], #fallback to subtitle if none
                "link"  :           ["cyan",],
                "new_link":         ["bold"],
                "blocked_link":     ["red","faint"],
                "oneline_link":     ["white"],     #for gopher/gemini. fallback to link if none
                "image_link" :      ["blue","italic","faint"],
                "preformatted":     ["faint"],
                "blockquote" :      ["italic"],
                "prompt_on" :       ["green","bold"],
                "prompt_off" :      ["blue","bold"],
        }

bw =   {
                "window_title" :    ["background_white", "black","bold"],
                "window_subtitle" : ["background_white", "black","faint"],
                "title" :           ["bold","underline"],
                "subtitle" :        ["bold"],
                "subsubtitle" :     ["faint","underline"], #fallback to subtitle if none
                "link"  :           ["bold",],
                "new_link":         ["bold"],
                "blocked_link":     ["faint"],
                "oneline_link":     [],     #for gopher/gemini. fallback to link if none
                "image_link" :      ["italic","faint"],
                "preformatted":     ["faint"],
                "blockquote" :      ["italic"],
                "prompt_on" :       ["bold"],
                "prompt_off" :      ["faint"],
        }

themes = {"offpunk1":offpunk1,"yellow":yellow, "cyan":cyan, "bw": bw}
default = offpunk1
