"""Shared SQLite conversation storage for Telegram and HTTP API access."""

from __future__ import annotations

import json
import sqlite3
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path
from threading import Lock
from typing import Any, Callable
from zoneinfo import ZoneInfo

MONTREAL = ZoneInfo("America/Montreal")


def _default_now() -> datetime:
    return datetime.now(MONTREAL)


@dataclass
class ConversationMessage:
    id: int
    session_id: str
    timestamp: str
    role: str
    content: str
    source: str
    telegram_chat_id: str | None
    telegram_message_id: str | None
    metadata: dict[str, Any]

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "session_id": self.session_id,
            "timestamp": self.timestamp,
            "role": self.role,
            "content": self.content,
            "source": self.source,
            "telegram_chat_id": self.telegram_chat_id,
            "telegram_message_id": self.telegram_message_id,
            "metadata": self.metadata,
        }


class ConversationStore:
    """Thread-safe wrapper around the shared conversations SQLite database."""

    def __init__(
        self,
        db_path: str,
        *,
        connection: sqlite3.Connection | None = None,
        now_fn: Callable[[], datetime] | None = None,
    ) -> None:
        self.db_path = db_path
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        self._connection = connection or sqlite3.connect(db_path, check_same_thread=False)
        self._connection.row_factory = sqlite3.Row
        self._lock = Lock()
        self._now_fn = now_fn or _default_now
        self.init_db()

    @property
    def connection(self) -> sqlite3.Connection:
        return self._connection

    def init_db(self) -> None:
        with self._lock:
            self._connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS conversations (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    session_id TEXT NOT NULL,
                    timestamp TEXT NOT NULL DEFAULT (datetime('now')),
                    role TEXT NOT NULL CHECK(role IN ('user', 'assistant', 'system')),
                    content TEXT NOT NULL,
                    source TEXT NOT NULL DEFAULT 'telegram',
                    telegram_chat_id TEXT,
                    telegram_message_id TEXT,
                    metadata TEXT
                );
                CREATE TABLE IF NOT EXISTS pending_retries (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    session_id TEXT NOT NULL,
                    user_text TEXT NOT NULL,
                    thread_cfg TEXT NOT NULL,
                    chat_id TEXT NOT NULL,
                    thread_id TEXT,
                    created_at TEXT NOT NULL,
                    retry_after TEXT NOT NULL,
                    attempts INTEGER DEFAULT 0
                );
                CREATE INDEX IF NOT EXISTS idx_conversations_session
                    ON conversations(session_id);
                CREATE INDEX IF NOT EXISTS idx_conversations_timestamp
                    ON conversations(timestamp);
                CREATE INDEX IF NOT EXISTS idx_conversations_source
                    ON conversations(source);
                """
            )
            cur = self._connection.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name='conversations_fts'"
            )
            if not cur.fetchone():
                self._connection.executescript(
                    """
                    CREATE VIRTUAL TABLE conversations_fts USING fts5(
                        content, content='conversations', content_rowid='id'
                    );
                    CREATE TRIGGER IF NOT EXISTS conversations_ai
                        AFTER INSERT ON conversations BEGIN
                        INSERT INTO conversations_fts(rowid, content)
                            VALUES (new.id, new.content);
                    END;
                    CREATE TRIGGER IF NOT EXISTS conversations_ad
                        AFTER DELETE ON conversations BEGIN
                        INSERT INTO conversations_fts(conversations_fts, rowid, content)
                            VALUES('delete', old.id, old.content);
                    END;
                    """
                )
            self._connection.commit()

    def save_message(
        self,
        session_id: str,
        role: str,
        content: str,
        *,
        source: str = "telegram",
        telegram_chat_id: str | None = None,
        telegram_message_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        timestamp: str | None = None,
    ) -> ConversationMessage:
        ts = timestamp or self._now_fn().strftime("%Y-%m-%d %H:%M:%S")
        encoded_metadata = json.dumps(metadata) if metadata is not None else None
        with self._lock:
            cur = self._connection.execute(
                """
                INSERT INTO conversations
                (session_id, timestamp, role, content, source, telegram_chat_id, telegram_message_id, metadata)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    session_id,
                    ts,
                    role,
                    content,
                    source,
                    telegram_chat_id,
                    telegram_message_id,
                    encoded_metadata,
                ),
            )
            self._connection.commit()
            message_id = int(cur.lastrowid)
        return ConversationMessage(
            id=message_id,
            session_id=session_id,
            timestamp=ts,
            role=role,
            content=content,
            source=source,
            telegram_chat_id=telegram_chat_id,
            telegram_message_id=telegram_message_id,
            metadata=metadata or {},
        )

    def get_recent_messages(self, session_id: str, limit: int) -> list[tuple[str, str, str]]:
        cutoff = (self._now_fn() - timedelta(hours=1)).strftime("%Y-%m-%d %H:%M:%S")
        with self._lock:
            rows = self._connection.execute(
                """
                SELECT role, content, timestamp FROM conversations
                WHERE session_id = ? AND timestamp >= ?
                ORDER BY id DESC LIMIT ?
                """,
                (session_id, cutoff, limit),
            ).fetchall()
            if len(rows) < min(limit, 3):
                rows = self._connection.execute(
                    """
                    SELECT role, content, timestamp FROM conversations
                    WHERE session_id = ?
                    ORDER BY id DESC LIMIT ?
                    """,
                    (session_id, max(limit, 3)),
                ).fetchall()
        ordered = list(reversed(rows))
        return [(row["role"], row["content"], row["timestamp"]) for row in ordered]

    def list_messages(
        self,
        *,
        channel_id: str,
        limit: int = 50,
        before: str | None = None,
    ) -> list[ConversationMessage]:
        params: list[Any] = [
            f"api-channel-{channel_id}",
            f"%-t{channel_id}",
            channel_id,
        ]
        before_clause = ""
        if before:
            before_clause = "AND timestamp < ?"
            params.append(before)
        params.append(limit)
        query = f"""
            SELECT id, session_id, timestamp, role, content, source,
                   telegram_chat_id, telegram_message_id, metadata
            FROM conversations
            WHERE (
                session_id = ?
                OR session_id LIKE ?
                OR json_extract(metadata, '$.channel') = ?
            )
            {before_clause}
            ORDER BY timestamp DESC, id DESC
            LIMIT ?
        """
        with self._lock:
            rows = self._connection.execute(query, params).fetchall()
        return [self._row_to_message(row) for row in rows]

    def _row_to_message(self, row: sqlite3.Row) -> ConversationMessage:
        raw_metadata = row["metadata"]
        if isinstance(raw_metadata, bytes):
            raw_metadata = raw_metadata.decode()
        metadata = json.loads(raw_metadata) if raw_metadata else {}
        return ConversationMessage(
            id=row["id"],
            session_id=row["session_id"],
            timestamp=row["timestamp"],
            role=row["role"],
            content=row["content"],
            source=row["source"],
            telegram_chat_id=row["telegram_chat_id"],
            telegram_message_id=row["telegram_message_id"],
            metadata=metadata,
        )
