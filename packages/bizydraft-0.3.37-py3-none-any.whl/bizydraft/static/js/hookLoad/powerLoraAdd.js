/**
 * 劫持 Power Lora Loader 的 Add Lora 按钮，并用单个隐藏 widget 按顺序存储 model_version_id 数组
 */
import { app } from "../../../scripts/app.js";

const POWER_LORA_LOADER_NAMES = [
  "Power Lora Loader (rgthree)",
  "RgthreePowerLoraLoader",
  "Power Lora Loader",
];

const MODEL_VERSION_IDS_NAME = "model_version_id";

function isPowerLoraLoaderNode(node) {
  const name = String(node?.comfyClass || node?.type || node?.title || "");
  return (
    POWER_LORA_LOADER_NAMES.includes(name) || name.includes("Power Lora Loader")
  );
}

const ADD_LORA_LABEL = "➕ Add Lora";

function isInIframe() {
  return typeof window !== "undefined" && window.parent !== window;
}

function getLoraWidgetIndex(node, loraWidget) {
  const loraWidgets =
    node.widgets?.filter((w) => w.name?.startsWith("lora_")) ?? [];
  return loraWidgets.indexOf(loraWidget);
}

function ensureModelVersionIdsArray(node) {
  let w = node.widgets?.find((wgt) => wgt.name === MODEL_VERSION_IDS_NAME);
  if (!w) {
    w = {
      type: "hidden",
      name: MODEL_VERSION_IDS_NAME,
      value: [],
      callback: () => {},
      options: {},
      // serializeValue tells ComfyUI to use this instead of the Proxy-wrapped value
      serializeValue: () => {
        return Array.isArray(w.value) ? [...w.value] : w.value;
      },
    };
    node.addCustomWidget(w);
  }
  if (!Array.isArray(w.value)) {
    w.value = [];
  }
  return w;
}

function patchAddNewLoraWidget(proto) {
  if (proto.__bizyAddLoraWidgetPatched) return;
  const orig = proto.addNewLoraWidget;
  if (!orig) return;
  proto.__bizyAddLoraWidgetPatched = true;
  proto.addNewLoraWidget = function (lora) {
    const widget = orig.call(this, lora);
    const loraIndex = getLoraWidgetIndex(this, widget);
    const idsWidget = ensureModelVersionIdsArray(this);
    idsWidget.value = [...idsWidget.value];
    if (idsWidget.value[loraIndex] === undefined) {
      idsWidget.value[loraIndex] = 0;
    }
    return widget;
  };
}

function patchAddLoraButton(node) {
  const addLoraWidget = node.widgets?.find(
    (w) =>
      w.mouseClickCallback &&
      (w.label === ADD_LORA_LABEL ||
        w.name === ADD_LORA_LABEL ||
        (w.label && String(w.label).includes("Add Lora")) ||
        (w.name && String(w.name).includes("Add Lora")))
  );
  if (!addLoraWidget) return false;

  const originalCallback = addLoraWidget.mouseClickCallback;
  addLoraWidget.mouseClickCallback = function (event, pos, n) {
    if (!isInIframe()) {
      return originalCallback?.(event, pos, n);
    }
    window.parent.postMessage(
      {
        type: "openWidgetSelect",
        widgetType: "model",
        payload: {
          nodeId: n.id,
          widgetName: "_addLora",
          config: { modelType: ["LoRA"] },
        },
      },
      "*"
    );
    return true;
  };
  return true;
}

function patchPrototypeAddNonLoraWidgets(proto) {
  if (proto.__bizyAddLoraPatched) return;
  const orig = proto.addNonLoraWidgets;
  if (!orig) return;
  proto.__bizyAddLoraPatched = true;
  proto.addNonLoraWidgets = function () {
    orig.call(this);
    ensureModelVersionIdsArray(this);
    patchAddLoraButton(this);
  };
}

app.registerExtension({
  name: "bizyair.hook.powerLoraAdd",
  nodeCreated(node) {
    if (!node) return;
    if (!isPowerLoraLoaderNode(node)) return;

    const proto = Object.getPrototypeOf(node);
    patchPrototypeAddNonLoraWidgets(proto);
    patchAddNewLoraWidget(proto);

    // Hook onConfigure to restore model_version_id from widgets_values on load.
    const origOnConfigure = node.onConfigure;
    node.onConfigure = function (info) {
      if (origOnConfigure) origOnConfigure.call(this, info);
      if (info?.widgets_values) {
        const arrValue = info.widgets_values.find((v) => Array.isArray(v));
        if (arrValue) {
          const idsWidget = ensureModelVersionIdsArray(this);
          idsWidget.value = [...arrValue];
        }
      }
    };

    // Hook onSerialize to ensure model_version_id array is correctly written
    const origOnSerialize = node.onSerialize;
    node.onSerialize = function (o) {
      if (origOnSerialize) origOnSerialize.call(this, o);
      const idsWidget = this.widgets?.find(
        (w) => w.name === MODEL_VERSION_IDS_NAME
      );
      if (idsWidget && Array.isArray(idsWidget.value) && o.widgets_values) {
        const idx = o.widgets_values.findIndex((v) => Array.isArray(v));
        if (idx !== -1) {
          o.widgets_values[idx] = [...idsWidget.value];
        }
      }
    };
  },
});
