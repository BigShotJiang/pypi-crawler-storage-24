# pyre_tools

`pyre_tools` is a Python dependency analysis tool that works both as a CLI and as an importable module.

## Install

```bash
pip install pyre_tools
```

## CLI

Analyze a project:

```bash
pyre_tools path/to/project
```

Analyze and install missing dependencies:

```bash
pyre_tools path/to/project --install
```

Generate `requirements.txt` and `pyproject.toml`:

```bash
pyre_tools path/to/project --write-files
```

The legacy `pyre` command is still available as a compatibility alias.

`pyre_tools -h` also shows how to call the package as a module from other Python code.

## Python API

```python
import pyre_tools; pyre_tools.shield()
```

Put that line at the top of your entry script. `pyre_tools` will infer the current project, install missing dependencies, and restart the process once if it had to patch the environment.

`shield()` now does a fast preflight on the current script first:
- local project modules like `utils.py` or `utils/` are treated as already satisfied
- already importable dependencies are accepted immediately
- only real missing modules fall back to full project analysis and installation
- in REPL / `python -c` mode, it falls back to the current working directory instead of trying to parse `<stdin>` or `<string>`

## Public API

- `analyze_path(path, include_stdlib=False)`
- `bootstrap(path=".", auto_install=True, output_dir=None, write_files=False, include_stdlib=False, upgrade=False)`
- `check_and_install_dependencies(path=".", auto_install=True, output_dir=None, write_files=False, include_stdlib=False, upgrade=False)`
- `shield(path=None, auto_install=True, output_dir=None, write_files=False, include_stdlib=False, upgrade=False, restart_on_install=True)`
- `find_missing_requirements(report_or_requirements)`
- `install_requirements(requirements, python_executable=None, upgrade=False)`
- `export_requirements(requirements, output_path)`
- `export_pyproject_toml(requirements, output_path, project_name)`
- `get_install_hint(package_name="pyre_tools")`
- `format_module_not_found_hint(module_name="pyre_tools", package_name="pyre_tools")`

## Notes

- The importable module name is `pyre_tools`.
- The primary console command is also `pyre_tools`.
- This makes missing-module guidance straightforward: if users see `ModuleNotFoundError: No module named 'pyre_tools'`, the install command is `pip install pyre_tools`.
- The shortest module integration is `import pyre_tools; pyre_tools.shield()`.
