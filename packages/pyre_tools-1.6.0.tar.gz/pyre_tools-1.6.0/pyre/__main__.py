from pyre_tools.__main__ import main


if __name__ == "__main__":
    raise SystemExit(main())
