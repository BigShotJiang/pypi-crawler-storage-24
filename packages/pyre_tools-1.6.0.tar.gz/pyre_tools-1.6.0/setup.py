from setuptools import find_packages, setup


setup(
    name="pyre_tools",
    version="1.6.0",
    description="CLI and importable library for Python dependency analysis and bootstrap.",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="HuaiYu-Yang",
    author_email="1710802268@qq.com",
    url="https://github.com/huaiyu-yang/pypre_tools",
    license="MIT",
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=[
        "requests>=2.0.0",
        "setuptools>=58.0.0",
    ],
    entry_points={
        "console_scripts": [
            "pyre_tools = pyre_tools.__main__:main",
            "pyre = pyre_tools.__main__:main",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
    include_package_data=True,
)
