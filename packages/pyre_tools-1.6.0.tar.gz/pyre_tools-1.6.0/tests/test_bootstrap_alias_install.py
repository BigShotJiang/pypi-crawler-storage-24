import importlib
import sys
from pathlib import Path

import pyre_tools
from pyre_tools import analyze_path


def main() -> int:
    project_root = Path(__file__).resolve().parents[1]
    target = project_root / "tests" / "fixtures" / "alias_imports.py"
    cv2_target = project_root / "tests" / "fixtures" / "cv2_alias_imports.py"

    pre_report = analyze_path(target)
    requirement_names = {requirement.name for requirement in pre_report.requirements}
    expected = {"pillow", "pyyaml", "beautifulsoup4"}
    missing_aliases = expected - requirement_names
    if missing_aliases:
        raise RuntimeError(f"Alias mapping failed: {sorted(missing_aliases)} not found in {sorted(requirement_names)}")

    cv2_report = analyze_path(cv2_target)
    cv2_requirement_names = {requirement.name for requirement in cv2_report.requirements}
    if "opencv-python" not in cv2_requirement_names:
        raise RuntimeError(f"cv2 alias mapping failed: {sorted(cv2_requirement_names)}")

    report = pyre_tools.shield(target)

    imported = {}
    for module_name in ("PIL", "yaml", "bs4"):
        module = importlib.import_module(module_name)
        imported[module_name] = getattr(module, "__version__", "unknown")

    print("python:", sys.executable)
    print("target:", target)
    print("cv2-alias:", sorted(cv2_requirement_names))
    print("requirements:", [requirement.specifier for requirement in report.requirements])
    print("imports:", imported)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
