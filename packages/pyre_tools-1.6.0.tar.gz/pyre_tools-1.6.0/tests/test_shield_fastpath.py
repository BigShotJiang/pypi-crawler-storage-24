from pathlib import Path

import pyre_tools


def main() -> int:
    project_root = Path(__file__).resolve().parents[1]
    target = project_root / "tests" / "fixtures" / "local_fastpath" / "main.py"

    report = pyre_tools.shield(target, auto_install=False)
    requirement_names = [requirement.name for requirement in report.requirements]
    requirement_sources = [requirement.source for requirement in report.requirements]

    if requirement_names != ["utils"]:
        raise RuntimeError(f"Unexpected fastpath requirements: {requirement_names}")
    if requirement_sources != ["local_module"]:
        raise RuntimeError(f"Unexpected fastpath sources: {requirement_sources}")

    print("target:", target)
    print("requirements:", requirement_names)
    print("sources:", requirement_sources)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
