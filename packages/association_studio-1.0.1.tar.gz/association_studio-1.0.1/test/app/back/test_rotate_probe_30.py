"""."""

import pytest

from pytest_mock import MockerFixture

from association_studio.app.back import AssociationStudioBackend


def test_rotate_probe_30(be: AssociationStudioBackend, mocker: MockerFixture) -> None:
    mock_upd = mocker.patch.object(be, 'upd_scores_and_probe')
    be.rotate_probe_30()
    ref = 0.9929625950474326, 0.0, 0.0, -0.11842839539852248
    assert be.box_trk.vec_z[3:7] == pytest.approx(ref)
    mock_upd.assert_called_once()
