"""."""

import pytest

from kinematic_tracker.association.association_metric import AssociationMetric

from association_studio.app.back import AssociationStudioBackend
from association_studio.app.show_coo_mode import ShowCooMode


def test_init(be: AssociationStudioBackend) -> None:
    assert be.box_det.vec_z[:3] == pytest.approx([0.0, 0.0, 0.0])
    assert be.box_trk.vec_z[:3] == pytest.approx([0.3, 0.7, 0.0])
    assert be.show_coo_mode == ShowCooMode.TRANSLATION_AND_ROTATION
    assert be.metric_mode.metric == AssociationMetric.GIOU_AXES_ALIGNED
