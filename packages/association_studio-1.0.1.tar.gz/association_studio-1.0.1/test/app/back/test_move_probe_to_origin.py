"""."""

import pytest

from pytest_mock import MockerFixture

from association_studio.app.back import AssociationStudioBackend


def test_move_probe_to_origin(be: AssociationStudioBackend, mocker: MockerFixture) -> None:
    mock_upd = mocker.patch.object(be, 'upd_trk_patches')
    be.move_probe_to_origin()
    assert be.score_driver.scores == pytest.approx(1.0)
    mock_upd.assert_called_once()
