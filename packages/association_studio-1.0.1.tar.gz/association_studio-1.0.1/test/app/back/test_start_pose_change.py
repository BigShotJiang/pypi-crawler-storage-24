"""."""

import pytest

from association_studio.app.back import AssociationStudioBackend


def test_start_pose_change(be: AssociationStudioBackend) -> None:
    be.box_trk.translate([1, 2, 3])
    be.start_pose_change()
    assert be.box_trk_start_pose_change.vec_z == pytest.approx(be.box_trk.vec_z)
    assert id(be.box_trk_start_pose_change) != id(be.box_det)
