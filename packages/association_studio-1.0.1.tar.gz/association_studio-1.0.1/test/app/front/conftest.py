import matplotlib.pyplot as plt
import pytest

from matplotlib.backend_bases import KeyEvent, MouseEvent, PickEvent
from pytest_mock import MockerFixture

from association_studio.app.back import AssociationStudioBackend
from association_studio.app.front import AssociationFrontend, PltHolder


@pytest.fixture
def front(mocker: MockerFixture) -> AssociationFrontend:
    mocker.patch.object(PltHolder, 'ion')
    return AssociationFrontend(AssociationStudioBackend())


@pytest.fixture
def pick(ax: plt.Axes, front: AssociationFrontend) -> PickEvent:
    mouse_pick = MouseEvent('mouse pick', ax.figure.canvas, 100, 200)
    return PickEvent('my pick', ax.figure.canvas, mouse_pick, front.back.trk_poly)


@pytest.fixture
def key_event(ax: plt.Axes) -> KeyEvent:
    return KeyEvent('key event', ax.figure.canvas, 'c')
