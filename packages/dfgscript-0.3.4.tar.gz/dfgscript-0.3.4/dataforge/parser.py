"""
DataForge v0.3.2 — Parser
Tokenises and parses .dfg source into one or more DfgScript blocks.

Box variables (v0.3.2)
-----------------------
Declare a box anywhere outside a block (or inside one):

    box name = "RICK"
    box version = "1.0"

Use [name] interpolation in paths and line operations:

    create-file "[name]/README.md"
    1+[name] is the project name, version [version]
    end-file

Boxes declared before a block are available in all subsequent blocks.
Boxes declared inside a block are available for the rest of that block only.
Re-declaring a box overrides the previous value.

Multi-file syntax (v0.3)
------------------------
Each file block is explicitly closed with `end-file`:

    create-file "notes.txt"
    1+Hello world
    end-file

Single-file v0.2 .dfg files without `end-file` are still supported —
a trailing end-of-file implicitly closes the last open block.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Dict, List, Union

# ---------------------------------------------------------------------------
# Operation types
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class WriteOp:
    """N+<text>  — write/replace line N with text (expands file if needed)."""
    line_num: int
    text: str

    def __str__(self) -> str:
        return f"{self.line_num}+{self.text}"


@dataclass(frozen=True)
class DeleteOp:
    """N-         — delete line N unconditionally.
    N-"text"  — delete line N only if content matches exactly; error otherwise.
    """
    line_num: int
    expected: str | None = None   # None = unconditional; str = conditional

    def __str__(self) -> str:
        if self.expected is None:
            return f"{self.line_num}-"
        return f'{self.line_num}-"{self.expected}"'


@dataclass(frozen=True)
class InsertAfterOp:
    """N><text>  — insert <text> after line N, shifting tail down."""
    line_num: int
    text: str

    def __str__(self) -> str:
        return f"{self.line_num}>{self.text}"


@dataclass(frozen=True)
class AppendOp:
    """$+<text>  — append <text> as a new final line."""
    text: str

    def __str__(self) -> str:
        return f"$+{self.text}"


Operation = Union[WriteOp, DeleteOp, InsertAfterOp, AppendOp]

# ---------------------------------------------------------------------------
# Script container
# ---------------------------------------------------------------------------

@dataclass
class DfgScript:
    command: str                          # 'create-file' | 'replace-file' | etc.
    path: str                             # target path (already interpolated)
    operations: List[Operation] = field(default_factory=list)
    source_line: int = 0                  # 1-based line in .dfg where command was found

# ---------------------------------------------------------------------------
# Regexes
# ---------------------------------------------------------------------------

_FILE_CMD_RE = re.compile(
    r'^(create-file|replace-file|change-file|remove-file'
    r'|new-folder|set-folder|remove-folder)\s+"(.+)"\s*$'
)
_END_FILE_RE = re.compile(r'^end-file\s*$')
_BOX_RE      = re.compile(r'^box\s+(\w+)\s*=\s*"(.*)"\s*(?:#.*)?$')
_WRITE_RE    = re.compile(r'^(\d+)\+(.*)$')
_DELETE_RE      = re.compile(r'^(\d+)-$')
_DELETE_COND_RE = re.compile(r'^(\d+)-"(.*)"$')
_INSERT_RE   = re.compile(r'^(\d+)>(.*)$')
_APPEND_RE   = re.compile(r'^\$\+(.*)$')

# ---------------------------------------------------------------------------
# Errors
# ---------------------------------------------------------------------------

class ParseError(Exception):
    """Raised when a .dfg source file cannot be parsed."""

# ---------------------------------------------------------------------------
# Interpolation
# ---------------------------------------------------------------------------

def _interpolate(text: str, boxes: Dict[str, str], lineno: int) -> str:
    """Replace [name] tokens with their box values.

    Raises ParseError if a referenced box has not been declared.
    """
    def replacer(m: re.Match) -> str:
        key = m.group(1)
        if key not in boxes:
            raise ParseError(
                f"Line {lineno}: ['{key}'] is not defined. "
                f"Declare it with: box {key} = \"value\""
            )
        return boxes[key]
    return re.sub(r'\[(\w+)\]', replacer, text)

# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def parse(source: str) -> List[DfgScript]:
    """Parse *source* and return a list of :class:`DfgScript` blocks.

    A single-block .dfg returns a one-element list.
    Raises :class:`ParseError` on any syntax error.
    """
    lines  = source.splitlines()
    scripts: List[DfgScript] = []
    current: DfgScript | None = None
    boxes: Dict[str, str] = {}            # global + block-scoped boxes

    for i, raw in enumerate(lines):
        lineno  = i + 1
        stripped = raw.strip()

        # Skip blanks and full-line comments
        if not stripped or stripped.startswith('#'):
            continue

        # box declaration — valid anywhere
        m = _BOX_RE.match(stripped)
        if m:
            boxes[m.group(1)] = m.group(2)
            continue

        # end-file — closes current block
        if _END_FILE_RE.match(stripped):
            if current is None:
                raise ParseError(f"Line {lineno}: 'end-file' with no open block.")
            scripts.append(current)
            current = None
            continue

        # File-level command — opens a new block
        m = _FILE_CMD_RE.match(stripped)
        if m:
            if current is not None:
                raise ParseError(
                    f"Line {lineno}: New file command opened before "
                    f"'{current.path}' was closed with 'end-file'."
                )
            cmd  = m.group(1)
            path = _interpolate(m.group(2), boxes, lineno)
            current = DfgScript(command=cmd, path=path, source_line=lineno)
            continue

        # Line-level operation — must be inside a block
        if current is None:
            raise ParseError(
                f"Line {lineno}: Operation '{stripped}' found outside a file block."
            )
        current.operations.append(_parse_operation(stripped, boxes, lineno))

    # Implicit close — backwards-compatible with v0.2 single-block files
    if current is not None:
        scripts.append(current)

    if not scripts:
        raise ParseError("No file-level command found in source.")

    return scripts


def parse_one(source: str) -> DfgScript:
    """Convenience wrapper — parse a single-block .dfg and return the DfgScript.

    Raises :class:`ParseError` if not exactly one block.
    Use parse() for multi-file scripts.
    """
    scripts = parse(source)
    if len(scripts) != 1:
        raise ParseError(
            f"Expected exactly one file block, got {len(scripts)}. "
            "Use parse() for multi-file scripts."
        )
    return scripts[0]


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _parse_operation(line: str, boxes: Dict[str, str], lineno: int) -> Operation:
    """Parse a single line-level operation with box interpolation."""
    m = _WRITE_RE.match(line)
    if m:
        return WriteOp(int(m.group(1)), _interpolate(m.group(2), boxes, lineno))

    m = _DELETE_COND_RE.match(line)
    if m:
        return DeleteOp(int(m.group(1)), _interpolate(m.group(2), boxes, lineno))

    m = _DELETE_RE.match(line)
    if m:
        return DeleteOp(int(m.group(1)))

    m = _INSERT_RE.match(line)
    if m:
        return InsertAfterOp(int(m.group(1)), _interpolate(m.group(2), boxes, lineno))

    m = _APPEND_RE.match(line)
    if m:
        return AppendOp(_interpolate(m.group(1), boxes, lineno))

    raise ParseError(f"Line {lineno}: Unrecognised operation syntax: {line!r}")
