"""
DataForge v0.2
~~~~~~~~~~~~~~
A minimal, deterministic, LLM-friendly, line-based file manipulation DSL.

Quickstart
----------
::

    from dataforge import parse, run

    script = parse(open("edit.dfg").read())
    result_lines = run(script, dry_run=True)

Or from the command line::

    dataforge edit.dfg --dry-run
    build edit.dfg

"""

from .parser import (
    parse_one,
    AppendOp,
    DeleteOp,
    DfgScript,
    InsertAfterOp,
    Operation,
    ParseError,
    WriteOp,
    parse,
)
from .interpreter import InterpreterError, run

__version__ = "0.3.4"
__all__ = [
    # Core API
    "parse",
    "run",
    # Script / op types
    "DfgScript",
    "WriteOp",
    "DeleteOp",
    "InsertAfterOp",
    "AppendOp",
    "Operation",
    # Exceptions
    "ParseError",
    "InterpreterError",
    # Metadata
    "__version__",
]
