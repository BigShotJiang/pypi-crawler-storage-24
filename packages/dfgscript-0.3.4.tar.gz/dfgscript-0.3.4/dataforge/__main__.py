"""Enables `python -m dataforge` / `py -m dataforge`."""
from .cli import main

main()
