import shutil
import subprocess
import os

def get_bz_path():
    """自动查找 bz.exe"""
    bz = shutil.which("bz.exe")
    if bz:
        return bz

    default_paths = [
        r"C:\Program Files\Bandizip\bz.exe",
        r"C:\Program Files (x86)\Bandizip\bz.exe",
    ]
    for p in default_paths:
        if os.path.exists(p):
            return p
    return None

def bandizip_zip(source_path, archive_path=None, password=None, delete_after_zip=False):
    bz_path = get_bz_path()
    if not bz_path:
        print("❌ 未找到 Bandizip")
        return

    if not os.path.exists(source_path):
        print("❌ 源路径不存在")
        return

    # 自动生成压缩包路径（不带后缀自动加 .zip）
    if archive_path is None:
        base_name = os.path.splitext(os.path.basename(source_path))[0]
        dir_name = os.path.dirname(source_path)
        archive_path = os.path.join(dir_name, base_name + ".zip")

    # ===================== 【官方正确参数顺序】 =====================
    cmd = [bz_path, "c"]

    # 自动覆盖
    cmd.append("-y")

    # 密码
    if password:
        cmd.append(f"-p:{password}")

    # 输出文件（必须带后缀 .zip/.7z/.rar）
    cmd.append(archive_path)

    # 要压缩的源
    cmd.append(source_path)

    # =================================================================

    try:
        subprocess.run(
            cmd,
            check=True,
            creationflags=subprocess.CREATE_NO_WINDOW
        )
        print(f"✅ 压缩成功：{archive_path}")

        # 压缩完删除源
        if delete_after_zip:
            if os.path.isfile(source_path):
                os.remove(source_path)
            else:
                shutil.rmtree(source_path)
            print("🗑️ 已删除原文件/文件夹")

    except subprocess.CalledProcessError:
        print("❌ 压缩失败：路径含空格/特殊符号 或 权限不足")
        archive_path = False

    except Exception as e:
        print(f"❌ 错误：{str(e)}")
        archive_path = False
    return  archive_path
if __name__ == '__main__':
    # 最简调用：自动压缩，自动生成同名zip
    print(bandizip_zip(
        source_path=r"F:\人物卡\待制作\王者荣耀嫦娥落星盏",  # 改成你自己的路径
        delete_after_zip=False
    ))
