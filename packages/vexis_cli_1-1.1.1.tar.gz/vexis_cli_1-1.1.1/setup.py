#!/usr/bin/env python3
"""
Setup script for VEXIS-CLI package building
"""

from setuptools import setup, find_packages
import os

# Read the contents of README file
this_directory = os.path.abspath(os.path.dirname(__file__))
with open(os.path.join(this_directory, 'README.md'), encoding='utf-8') as f:
    long_description = f.read()

setup(
    name='vexis-cli-1',
    version='1.1.1',
    description='AI command-line agent for terminal automation and task execution',
    long_description=long_description,
    long_description_content_type='text/markdown',
    author='AInohogosya-team',
    license='MIT',
    classifiers=[
        'Development Status :: 5 - Production/Stable',
        'Intended Audience :: Developers',
        'Operating System :: OS Independent',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'Topic :: Software Development :: Libraries :: Python Modules',
        'Topic :: Scientific/Engineering :: Artificial Intelligence',
        'Topic :: System :: Systems Administration',
    ],
    keywords='ai automation cli terminal command-line',
    python_requires='>=3.8',
    packages=find_packages(where='src'),
    package_dir={'': 'src'},
    package_data={
        'ai_agent': [
            'config/*.yaml',
            'config/*.json', 
            'templates/*.txt',
            'scripts/*.sh',
            'scripts/*.ps1',
        ],
    },
    install_requires=[
        'Pillow>=10.0.0',
        'requests>=2.31.0',
        'numpy>=1.24.0',
        'structlog>=23.0.0',
        'rich>=13.0.0',
        'PyYAML>=6.0.0',
        'ollama>=0.1.0',
        'pyautogui>=0.9.54; sys_platform=="darwin"',
        'pyobjc-framework-Cocoa>=9.0; sys_platform=="darwin"',
        'pywin32>=306; sys_platform=="win32"',
        'python-xlib>=0.33; sys_platform=="linux"',
    ],
    entry_points={
        'console_scripts': [
            'vexis-cli=ai_agent.user_interface.main_app:main',
            'vexis-cli-enhanced=ai_agent.user_interface.two_phase_app:main',
        ],
    },
    url='https://github.com/AInohogosya-team/VEXIS-CLI-1.1',
    project_urls={
        'Bug Reports': 'https://github.com/AInohogosya-team/VEXIS-CLI-1.1/issues',
        'Source': 'https://github.com/AInohogosya-team/VEXIS-CLI-1.1',
    },
)
