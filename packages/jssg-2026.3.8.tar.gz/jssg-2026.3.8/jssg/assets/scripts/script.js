/* Checks the current location in the nav and assigns 
   a class for coloring the nav item in the header
*/

const current_url = new URL(window.location.href);
const navi = document.getElementById("navi");
const home_regex = new RegExp("/", "g");

let path_pos = 0;
if (navi.className === "nav-root") {
    path_pos = 1;
}
else if (navi.className === "nav-folder") {
    path_pos = 2;
}

if (path_pos !== 0) {
    const path_name = current_url.pathname;
    const freq_match = path_name.match(home_regex);
    const path_count = freq_match ? freq_match.length : 0;

    let nav_id;
    if (path_name === "/") {
        nav_id = "home";
    } else if (navi.className === "nav-folder" && path_count === 2) {
        nav_id = "home";
    }
    else {
        nav_id = path_name.split("/")[path_pos];
    }

    const nav_elem = document.getElementById(nav_id);
    nav_elem.className = "selected";
}
