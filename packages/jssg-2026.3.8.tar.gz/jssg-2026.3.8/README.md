# jssg

Minimalist and pragmatic static site generator, with an emphasis on blogging.

## Requirements

Python 3.13+

## Dependencies

* [Jinja2](https://pypi.org/project/Jinja2/)
* [MarkupSafe](https://pypi.org/project/MarkupSafe/)
* [Markdown](https://pypi.org/project/Markdown/)

## Features
* Site pages
* Blog posts with optional tags
* RSS feeds

## Install

```shell
pip install jssg
```

## Usage

### Initialize the site

```shell
mkdir wwwsite
cd wwwsite
jssg init
```

### Add site configurations

```shell
jssg config -t <Site title> -u <Site url> -a <Site author> -e <Site email>
```
The same configs can be passed when doing `jssg init`

See more config options with `jssg config -h`

### Add a page

```shell
jssg page <Page title>
```

After this you can start writing your page content in the generated Markdown file.

### Add a post

```shell
jssg post <Post title> -t <category tag>
```

After this you can start writing your post content in the generated Markdown file.

### Build the site

```shell
jssg build
```

### Preview the site locally

```shell
jssg serve
```

## License

Copyright (C) 2026 by Joel Torres \<joel@joeltorres.net\>

Distributed under the Zero-Clause BSD license. See the accompanying file LICENSE or https://opensource.org/license/0bsd.
