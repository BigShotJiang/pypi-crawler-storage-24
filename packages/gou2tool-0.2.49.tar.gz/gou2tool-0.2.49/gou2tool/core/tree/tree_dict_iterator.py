class TreeDictIterator:
    def __init__(self, root, config=None):
        if config is None:
            config = {}

        self.children_key = config.get("children", "children")
        self.id_key = config.get("id", "id")
        self.name_key = config.get("name", "name")
        self.parent_id_key = config.get("parent_id", "parent_id")

        if isinstance(root, list):
            self.stack = [(node, None, []) for node in reversed(root)]
        else:
            self.stack = [(root, None, [])]

        self._index = 0

    def __iter__(self):
        return self

    def __next__(self):
        if not self.stack:
            raise StopIteration

        current_index = self._index
        self._index += 1

        node, parent, parent_indices = self.stack.pop()

        if isinstance(node, dict) and self.children_key in node:
            children = node[self.children_key]
            if isinstance(children, list):
                new_parent_indices = parent_indices + [current_index]
                for child in reversed(children):
                    self.stack.append((child, node, new_parent_indices))

        result = {
            "node": node,
            "parent": parent,
            "parents": parent_indices,
            "children": node.get(self.children_key) if isinstance(node, dict) else None,
            "level": len(parent_indices) + 1,
            "index": current_index,
            "is_first": current_index == 0,
            "is_last": len(self.stack) == 0,
            "is_middle": current_index > 0 and len(self.stack) > 0,
            "parent_index": parent_indices[-1] if parent_indices else None,
            "full_index": None,
            "full_indexs": None,
            "parent_id": None,
            "root_id": None,
            "id": None,
            "name": None,
            "list_index": current_index + 1,
            "list_parent_index": (parent_indices[-1] + 1) if parent_indices else None,
            "list_full_index": None,
            "list_full_indexs": None
        }

        if isinstance(node, dict):
            result["id"] = node.get(self.id_key)
            result["name"] = node.get(self.name_key)

            parent_id_val = node.get(self.parent_id_key)
            if parent_id_val is not None:
                result["parent_id"] = parent_id_val
            elif parent is not None and isinstance(parent, dict):
                result["parent_id"] = parent.get(self.id_key)

            if parent_indices:
                full_indexes = parent_indices + [current_index]
                result["full_index"] = ",".join(str(i) for i in full_indexes)
                result["full_indexs"] = full_indexes
                list_full_indexes = [(i + 1) for i in full_indexes]
                result["list_full_index"] = ",".join(str(i) for i in list_full_indexes)
                result["list_full_indexs"] = list_full_indexes
            else:
                result["root_id"] = result["id"]
                result["full_name"] = result["name"]
                result["full_id"] = str(result["id"])
                result["full_names"] = [result["name"]] if result["name"] else []
                result["full_ids"] = [str(result["id"])] if result["id"] is not None else []
                result["full_index"] = str(current_index)
                result["full_indexs"] = [current_index]
                result["list_full_index"] = str(current_index + 1)
                result["list_full_indexs"] = [current_index + 1]

        return result