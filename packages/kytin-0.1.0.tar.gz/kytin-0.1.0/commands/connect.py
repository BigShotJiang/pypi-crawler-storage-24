from kytin.commands.base import Command
from kytin.core.executor import exec_command
from rich import print


class Connect(Command):
    name = "connect"
    description = "Connect to target"

    def run(self, cmd, context):
        parts = cmd.split()

        if len(parts) < 3:
            print("[!] Usage: connect <ip> <port>")
            return

        ip = parts[1]
        port = parts[2]

        exec_command(
            f"nc {ip} {port}",
            context,
            message=f"Connecting to {ip}:{port}..."
        )