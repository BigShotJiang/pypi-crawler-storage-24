from kytin.commands.base import Command
from kytin.core.executor import exec_command
from rich import print


class FullScan(Command):
    name = "fullscan"
    description = "Run full automated scan"

    def run(self, cmd, context):
        save_file = None
        report = ""   

        parts = cmd.split()

        if len(parts) < 2:
            print("[!] Usage: fullscan <target>")
            return

        target = parts[1]
        context.target = target

        # detect save flag
        if "--save" in parts:
            try:
                save_file = parts[parts.index("--save") + 1]
            except:
                print("[!] Usage: --save <filename>")
                return

        print(f"[+] Target set to: {target}")
        print("[+] Starting full scan...\n")

        # -------------------------------
        # 1. Nmap Scan
        # -------------------------------
        print("[bold cyan]Phase 1: Network Scan (nmap)[/bold cyan]")

        report += exec_command(
            f"nmap -T4 -F {target}",
            context,
            message="Running fast port scan...",
            capture=True
        ) or ""

        report += exec_command(
            f"nmap -sV {target}",
            context,
            message="Detecting services...",
            capture=True
        ) or ""

        # -------------------------------
        # 2. Directory Scan
        # -------------------------------
        print("\n[bold cyan]Phase 2: Directory Scan (gobuster)[/bold cyan]")

        wordlist_small = "/usr/share/wordlists/dirb/common.txt"
        wordlist_big = "/workspace/seclists/Discovery/Web-Content/common.txt"

        report += exec_command(
            f"test -f {wordlist_big} && gobuster dir -u http://{target} -w {wordlist_big} || gobuster dir -u http://{target} -w {wordlist_small}",
            context,
            message="Scanning directories...",
            capture=True   
        ) or ""

        # -------------------------------
        # 3. Web Scan
        # -------------------------------
        print("\n[bold cyan]Phase 3: Web Scan (nikto)[/bold cyan]")

        report += exec_command(
            f"perl /opt/nikto/program/nikto.pl -h http://{target}",
            context,
            message="Running Nikto scan...",
            capture=True
        ) or ""

        # -------------------------------
        # 4. Suggestions
        # -------------------------------
        print("\n[bold green]Scan Completed[/bold green]")
        print("\n[bold yellow]Suggested Next Steps:[/bold yellow]")

        suggestions = f"""
• Run deeper scan:
  nmap -p- {target}

• Check for SQL injection:
  sqlmap -u "http://{target}/page.php?id=1" --batch

• Search exploits:
  searchsploit {target}

• Brute force (if login found):
  hydra -l admin -P rockyou.txt ssh://{target}
"""

        print(suggestions)

        report += "\n=== SUGGESTIONS ===\n"
        report += suggestions

        # -------------------------------
        # SAVE REPORT
        # -------------------------------
        if save_file:
            try:
                with open(save_file, "w") as f:
                    f.write("=== KYTIN FULLSCAN REPORT ===\n\n")
                    f.write(report)

                print(f"[bold green][+] Report saved to {save_file}[/bold green]")
            except Exception as e:
                print(f"[red][!] Failed to save report: {e}[/red]")