from kytin.commands.base import Command
from kytin.core.executor import exec_command
from rich import print


class Listen(Command):
    name = "listen"
    description = "Start listener"

    def run(self, cmd, context):
        parts = cmd.split()

        if len(parts) < 2:
            print("[!] Usage: listen <port>")
            return

        port = parts[1]

        exec_command(
            f"nc -lvnp {port}",
            context,
            message=f"Listening on port {port}..."
        )