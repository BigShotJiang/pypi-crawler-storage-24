from kytin.commands.base import Command
from kytin.core.executor import exec_command
from rich import print


class Netcat(Command):
    name = "nc"
    description = "Netcat utility"

    def run(self, cmd, context):
        exec_command(cmd, context, message="Running Netcat...")