from kytin.commands.base import Command
from kytin.core.executor import exec_command
from rich import print


class Install(Command):
    name = "install"
    description = "Install optional components"

    def run(self, cmd, context):
        parts = cmd.split()

        if len(parts) < 2:
            print("[!] Usage: install <component>")
            print("Available: wordlists")
            return

        component = parts[1]

        if component == "wordlists":
            print("[+] Installing SecLists (this may take time)...")

            exec_command(
                "git clone https://github.com/danielmiessler/SecLists.git /workspace/seclists",
                context,
                message="Downloading SecLists..."
            )

            print("[+] Wordlists installed at /workspace/seclists")

        # elif component == "metasploit":
        #     print("[+] Installing Metasploit (this may take several minutes)...")

        #     exec_command(
        #         "apt update && apt install -y metasploit-framework ruby-full postgresql",
        #         context,
        #         message="Installing Metasploit (heavy)..."
        #     )

        #     print("[+] Metasploit installed. Run using: msfconsole")

        else:
            print(f"[!] Unknown component: {component}")