# from kytin.commands.base import Command
# from kytin.core.executor import exec_command
# from rich import print


# class Msfconsole(Command):
#     name = "msfconsole"
#     description = "Launch Metasploit"

#     def run(self, cmd, context):
#         print("[!] Launching Metasploit (interactive mode)")

#         # Optional debug (very useful)
#         exec_command("which msfconsole", context, message="Checking Metasploit...")

#         # Use full path (important fix)
#         exec_command(
#             "ruby /usr/bin/msfconsole",
#             context,
#             message="Starting Metasploit..."
#         )