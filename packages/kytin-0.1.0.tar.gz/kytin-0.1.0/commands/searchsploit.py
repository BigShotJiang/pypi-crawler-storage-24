from kytin.commands.base import Command
from kytin.core.executor import exec_command
from rich import print


class Searchsploit(Command):
    name = "searchsploit"
    description = "Search exploits locally"

    def run(self, cmd, context):
        parts = cmd.split()

        if len(parts) < 2:
            print("[!] Usage: searchsploit <keyword>")
            return

        exec_command(cmd, context, message="Searching exploits...")