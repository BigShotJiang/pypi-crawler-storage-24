from kytin.commands.base import Command
from kytin.core.executor import exec_command
from rich import print


class Nikto(Command):
    name = "nikto"
    description = "Run nikto web scan"

    def run(self, cmd, context):
        parts = cmd.split()

        if len(parts) < 2:
            print("[!] Usage: nikto <url>")
            return

        target = parts[1]

        exec_command(
            f"perl /opt/nikto/program/nikto.pl -h {target}",
            message="Running Nikto web scan..."
        )