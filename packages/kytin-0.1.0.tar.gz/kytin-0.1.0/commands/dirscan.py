from kytin.commands.base import Command
from kytin.core.executor import exec_command
from rich import print
import os


class DirScan(Command):
    name = "dirscan"
    description = "Quick directory scan"

    def run(self, cmd, context):
        parts = cmd.split()

        if len(parts) < 2:
            print("[!] Usage: dirscan <url>")
            return

        url = parts[1]

        wordlist = "/usr/share/wordlists/dirb/common.txt"
        better_list = "/workspace/seclists/Discovery/Web-Content/common.txt"

        exec_command(
            f"test -f {better_list} && gobuster dir -u {url} -w {better_list} || gobuster dir -u {url} -w {wordlist}",
            context,
            message="Scanning directories..."
        )