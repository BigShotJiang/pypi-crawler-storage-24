from kytin.commands.base import Command
from kytin.core.executor import exec_command
from rich import print


class Gobuster(Command):
    name = "gobuster"
    description = "Directory brute force"

    def run(self, cmd, context):
        parts = cmd.split()

        if "-u" not in parts:
            print("[!] Usage: gobuster -u <url> -w <wordlist>")
            return

        # Auto-add wordlist if missing
        if "-w" not in parts:
            cmd += " -w /usr/share/wordlists/dirb/common.txt"

        exec_command(cmd, message="Running directory brute force...")