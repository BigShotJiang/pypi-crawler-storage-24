from kytin.commands.scan import Scan
from kytin.commands.recon import Recon
from kytin.commands.target import SetTarget
from kytin.commands.sqlmap import Sqlmap
from kytin.commands.sqlscan import SqlScan
from kytin.commands.nikto import Nikto
from kytin.commands.webscan import WebScan
from kytin.commands.hydra import Hydra
from kytin.commands.brute import Brute
from kytin.commands.gobuster import Gobuster
from kytin.commands.dirscan import DirScan
from kytin.commands.netcat import Netcat
from kytin.commands.listen import Listen
from kytin.commands.connect import Connect
from kytin.commands.searchsploit import Searchsploit
from kytin.commands.exploit import Exploit
from kytin.commands.install import Install
# from kytin.commands.msf import Msfconsole
from kytin.commands.fullscan import FullScan




COMMANDS = {
    "scan": Scan(),
    "recon": Recon(),
    "set target": SetTarget(),
    "sqlmap": Sqlmap(),
    "sqlscan": SqlScan(),
    "nikto": Nikto(),
    "webscan": WebScan(),
    "hydra": Hydra(),
    "brute": Brute(),
    "gobuster": Gobuster(),
    "dirscan": DirScan(),
    "nc": Netcat(),
    "listen": Listen(),
    "connect": Connect(),
    "searchsploit": Searchsploit(),
    "exploit": Exploit(),
    "install": Install(),
    # "msfconsole": Msfconsole(),
    "fullscan": FullScan(),
}