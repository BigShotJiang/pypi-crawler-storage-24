class Context:
    def __init__(self):
        self.target = None
        self.cwd = "/root"