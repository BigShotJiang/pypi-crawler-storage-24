import subprocess
from rich.console import Console

console = Console()
CONTAINER_NAME = "kytin_container"

def exec_command(cmd, context, message="Running command...", capture=False):
    full_cmd = f'docker exec {CONTAINER_NAME} bash -c "cd {context.cwd} && {cmd}"'

    console.print(f"[dim]{cmd}[/dim]")
    console.print(f"[cyan]{message}[/cyan]\n")

    output = ""

    try:
        process = subprocess.Popen(
            full_cmd,
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True
        )

        for line in process.stdout:
            print(line, end="")
            if capture:
                output += line

    except KeyboardInterrupt:
        console.print("\n[red][!] Process interrupted by user[/red]")
        process.terminate()

    return output if capture else None