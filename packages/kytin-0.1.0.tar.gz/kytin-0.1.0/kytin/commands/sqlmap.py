from kytin.commands.base import Command
from kytin.core.executor import exec_command
from rich import print


class Sqlmap(Command):
    name = "sqlmap"
    description = "Run sqlmap manually"

    def run(self, cmd, context):
        if "-u" not in cmd:
            print("[!] Usage: sqlmap -u <url> [options]")
            return

        exec_command(cmd, message="Running sqlmap...")