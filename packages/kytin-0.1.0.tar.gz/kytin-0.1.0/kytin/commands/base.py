class Command:
    name = ""
    description = ""

    def run(self, cmd, context):
        raise NotImplementedError