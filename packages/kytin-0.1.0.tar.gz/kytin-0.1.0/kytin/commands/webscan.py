from kytin.commands.base import Command
from kytin.core.executor import exec_command
from rich import print


class WebScan(Command):
    name = "webscan"
    description = "Quick web vulnerability scan"

    def run(self, cmd, context):
        parts = cmd.split()

        if len(parts) < 2:
            print("[!] Usage: webscan <url>")
            return

        target = parts[1]

        exec_command(
            f"nikto -h {target}",
            message="Running Nikto scan..."
        )