from kytin.commands.base import Command
from kytin.core.executor import exec_command
from rich import print

class Scan(Command):
    name = "scan"
    description = "Fast scan"

    def run(self, cmd, context):
        if not context.target:
            print("[!] Set target first")
            return

        exec_command(
            f"nmap -T4 -F {context.target}",
            message="Running fast scan..."
        )