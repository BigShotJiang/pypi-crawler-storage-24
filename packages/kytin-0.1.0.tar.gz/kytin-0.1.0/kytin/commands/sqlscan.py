from kytin.commands.base import Command
from kytin.core.executor import exec_command
from rich import print


class SqlScan(Command):
    name = "sqlscan"
    description = "Quick SQL injection scan"

    def run(self, cmd, context):
        parts = cmd.split()

        if len(parts) < 2:
            print("[!] Usage: sqlscan <url>")
            return

        url = parts[1]

        exec_command(
            f"sqlmap -u \"{url}\" --batch --dbs",
            message="Running automated SQL injection scan..."
        )