from kytin.commands.base import Command
from rich import print

class SetTarget(Command):
    name = "set target"
    description = "Set target"

    def run(self, cmd, context):
        try:
            context.target = cmd.split()[-1]
            print(f"[+] Target set to: {context.target}")
        except:
            print("[!] Usage: set target <target>")