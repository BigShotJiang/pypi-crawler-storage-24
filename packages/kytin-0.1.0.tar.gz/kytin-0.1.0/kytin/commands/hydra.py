from kytin.commands.base import Command
from kytin.core.executor import exec_command
from rich import print


class Hydra(Command):
    name = "hydra"
    description = "Run hydra manually"

    def run(self, cmd, context):
        if "-l" not in cmd and "-L" not in cmd:
            print("[!] Provide username (-l or -L)")
            return

        if "-p" not in cmd and "-P" not in cmd:
            print("[!] Provide password (-p or -P)")
            return

        exec_command(cmd, message="Running Hydra attack...")