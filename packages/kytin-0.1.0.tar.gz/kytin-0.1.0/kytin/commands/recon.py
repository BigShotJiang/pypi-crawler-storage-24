from kytin.commands.base import Command
from kytin.core.executor import exec_command
from rich import print

class Recon(Command):
    name = "recon"
    description = "Recon automation"

    def run(self, cmd, context):
        parts = cmd.split()

        if len(parts) < 2:
            print("[!] Usage: recon <target>")
            return

        context.target = parts[1]
        print(f"[+] Target set to: {context.target}")

        exec_command(
            f"nmap -T4 -F {context.target}",
            message="Running fast scan..."
        )

        exec_command(
            f"nmap -sV {context.target}",
            message="Running service scan..."
        )