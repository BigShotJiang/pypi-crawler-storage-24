from setuptools import setup, find_packages

setup(
    name="kytin",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[
        "prompt_toolkit",
        "rich"
    ],
    entry_points={
        "console_scripts": [
            "kytin=kytin.main:main"
        ]
    },
    author="Ankush Kumar Mohapatra",
    description="Run Kali tools without installing Kali Linux",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/kytin",
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
)