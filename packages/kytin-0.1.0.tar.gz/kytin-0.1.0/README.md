# Kytin

Run Kali Linux tools without installing Kali.

## Features

- Nmap, Nikto, SQLMap, Hydra
- Full automated scan
- Docker-based backend

## Install

pip install kytin

## Usage

kytin
