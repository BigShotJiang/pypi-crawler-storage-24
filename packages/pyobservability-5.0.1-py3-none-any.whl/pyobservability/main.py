import logging
import pathlib
import warnings
from collections.abc import Generator
from contextlib import asynccontextmanager
from datetime import datetime
from http import HTTPStatus
from typing import Dict

import uiauth
import uvicorn
from fastapi import FastAPI, HTTPException, Request
from fastapi.routing import APIRoute, APIWebSocketRoute
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from pyobservability.config import enums, settings
from pyobservability.github import GitHub
from pyobservability.kuma import UptimeKumaClient, extract_monitors
from pyobservability.monitor import Monitor
from pyobservability.prometheus import metrics_endpoint
from pyobservability.transport import GLOBAL_MONITORS, websocket_endpoint
from pyobservability.version import __version__

LOGGER = logging.getLogger("uvicorn.default")
logging.getLogger("uvicorn.access").addFilter(settings.HealthCheckFilter())


@asynccontextmanager
async def lifespan(_: FastAPI):
    """Lifespan context manager to handle startup and shutdown events."""
    static_dir = root / "static_legacy" if settings.env.legacy_ui else root / "static"
    PyObservability.mount("/static", StaticFiles(directory=static_dir), name="static")
    if settings.env.prometheus_enabled:
        LOGGER.info("Prometheus metrics endpoint is enabled. Starting monitors for configured targets.")
        for target in settings.env.targets:
            mon = Monitor(target)
            LOGGER.info("Starting monitor for target [%s]", target["name"])
            await mon.start()
            GLOBAL_MONITORS[target["base_url"]] = mon
    LOGGER.info("PyObservability is up and running.")
    yield
    if settings.env.prometheus_enabled:
        for monitor in GLOBAL_MONITORS.values():
            LOGGER.info("Stopping monitor for target [%s]", monitor.name)
            await monitor.stop()
    LOGGER.info("PyObservability has shut down.")


PyObservability = FastAPI(title="PyObservability", lifespan=lifespan)
PyObservability.__name__ = "PyObservability"
PyObservability.description = "Observability page for nodes running PyNinja"

root = pathlib.Path(__file__).parent
templates_dir = root / "templates"
templates = Jinja2Templates(directory=templates_dir)


async def index(request: Request):
    """Pass configured targets to the template so frontend can prebuild UI.

    Args:
        request: FastAPI request object.

    Returns:
        TemplateResponse:
        Rendered HTML template with targets and version.
    """
    kuma_data = [{}] if all((settings.env.kuma_url, settings.env.kuma_username, settings.env.kuma_password)) else None
    runners_data = [{}] if all((settings.env.git_org, settings.env.git_token)) else None
    args = dict(
        request=request,
        kuma_data=kuma_data,
        runners_data=runners_data,
        targets=settings.env.targets,
        version=__version__,
        legacy_ui=settings.env.legacy_ui,
    )
    if settings.env.username and settings.env.password:
        args["logout"] = uiauth.enums.APIEndpoints.fastapi_logout.value
    return templates.TemplateResponse("index.html", args)


async def kuma():
    """Kuma endpoint to retrieve monitors from Kuma server.

    Returns:
        List[Dict[str, Any]]:
        List of monitors from Kuma server after filtering the required fields.
    """
    if kuma_data := UptimeKumaClient().get_monitors():
        LOGGER.info("Retrieved monitors from kuma server - %d found", len(kuma_data))
        monitors = list(extract_monitors(kuma_data))
        LOGGER.info("Processed [%d] monitors for UI payload.", len(monitors))
        return monitors
    raise HTTPException(
        status_code=HTTPStatus.SERVICE_UNAVAILABLE.real,
        detail="Unable to retrieve data from kuma server.",
    )


async def runners():
    """Git runners endpoint to retrieve self-hosted runners from GitHub organization.

    Returns:
        List[Dict[str, Any]]:
        List of self-hosted runners from GitHub organization after filtering the required fields.
    """
    if runners_data := GitHub().runners():
        LOGGER.info("Retrieved self-hosted runners from GitHub - %d found", runners_data.total)
        return [runner.__dict__ for runner in runners_data.runners]
    raise HTTPException(
        status_code=HTTPStatus.SERVICE_UNAVAILABLE.real,
        detail="Unable to retrieve data from GitHub.",
    )


async def health() -> Dict[str, str]:
    """Health check endpoint.

    Returns:
        Dict[str, str]:
        Health status.
    """
    return {"status": "ok"}


def gather_routes() -> Generator[APIRoute | APIWebSocketRoute]:
    """Gather API routes based on the configuration.

    Yields:
        APIRoute | APIWebSocketRoute:
        API routes for the application.
    """
    kuma_enabled = all((settings.env.kuma_url, settings.env.kuma_username, settings.env.kuma_password))
    runners_enabled = all((settings.env.git_org, settings.env.git_token))
    yield from [
        APIRoute(
            path=enums.APIEndpoints.health,
            endpoint=health,
            methods=["GET"],
            include_in_schema=False,
        ),
        APIRoute(
            path=enums.APIEndpoints.root,
            endpoint=index,
            methods=["GET"],
            include_in_schema=False,
        ),
        APIWebSocketRoute(
            path=enums.APIEndpoints.ws,
            endpoint=websocket_endpoint,
        ),
    ]
    if kuma_enabled:
        yield APIRoute(
            path=enums.APIEndpoints.kuma,
            endpoint=kuma,
            methods=["GET"],
            include_in_schema=False,
        )
    if runners_enabled:
        yield APIRoute(
            path=enums.APIEndpoints.runners,
            endpoint=runners,
            methods=["GET"],
            include_in_schema=False,
        )
    if settings.env.prometheus_enabled:
        yield APIRoute(
            endpoint=metrics_endpoint,
            path=enums.APIEndpoints.metrics,
            methods=["GET"],
        )


# noinspection PyTypeChecker
def start(**kwargs) -> None:
    """Start the FastAPI app with Uvicorn server."""
    settings.env = settings.env_loader(**kwargs)
    settings.env.targets = [{k: str(v) for k, v in target.model_dump().items()} for target in settings.env.targets]
    settings.targets_by_url = {t["base_url"]: t for t in settings.env.targets}
    routes = list(gather_routes())
    if all((settings.env.username, settings.env.password)):
        uiauth.protect(
            app=PyObservability,
            username=settings.env.username,
            password=settings.env.password,
            timeout=settings.env.timeout,
            custom_logger=LOGGER,
            routes=routes,
        )
    else:
        warnings.warn("\n\tRunning PyObservability without any authentication mechanism.", UserWarning)
        PyObservability.routes.extend(routes)
    uvicorn_args = dict(
        host=settings.env.host,
        port=settings.env.port,
        app=PyObservability,
    )
    if settings.env.log:
        if settings.env.log == enums.Log.stdout:
            uvicorn_args["log_config"] = settings.detailed_log_config(debug=settings.env.debug)
        else:
            logs_path = pathlib.Path(settings.env.logs_path)
            log_file = logs_path / f"pyobservability_{datetime.now():%d-%m-%Y}.log"
            logs_path.mkdir(parents=True, exist_ok=True)
            uvicorn_args["log_config"] = settings.detailed_log_config(
                filename=log_file.resolve(), debug=settings.env.debug
            )
    # log_config will take precedence if both log and log_config are set
    if settings.env.log_config:
        uvicorn_args["log_config"] = (
            settings.env.log_config if isinstance(settings.env.log_config, dict) else str(settings.env.log_config)
        )
    uvicorn.run(**uvicorn_args)
