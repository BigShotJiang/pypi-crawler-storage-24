import json
import logging
import os
import pathlib
import socket
from typing import Any, Dict, Iterable, List

from pydantic import BaseModel, Field, FilePath, HttpUrl, PositiveInt
from pydantic.aliases import AliasChoices
from pydantic_settings import BaseSettings

from pyobservability.config import enums


class HealthCheckFilter(logging.Filter):
    """Custom logging filter to exclude health check logs from the output."""

    def filter(self, record):
        """Filter out logs related to health checks."""
        # 'record.getMessage()' contains the log text
        # Skip logs containing 'GET /health' (from curl)
        return "/health" not in record.getMessage()


def detailed_log_config(filename: str | None = None, debug: bool = False) -> Dict[str, Any]:
    """Generate a detailed logging configuration.

    Args:
        filename: Optional log file name. If None, logs to stdout.
        debug: If True, sets log level to DEBUG, else INFO.

    Returns:
        Dict[str, Any]:
        Returns the logging configuration dictionary.
    """
    if filename:
        log_handler = {
            "class": "logging.FileHandler",
            "formatter": "default",
            "filename": filename,
            "mode": "a",
        }
    else:
        log_handler = {
            "class": "logging.StreamHandler",
            "formatter": "default",
            "stream": "ext://sys.stdout",
        }
    level = "DEBUG" if debug else "INFO"
    return {
        "version": 1,
        "disable_existing_loggers": False,
        "formatters": {
            "default": {
                "format": "%(asctime)s - %(levelname)s - [%(module)s:%(lineno)d] - %(funcName)s - %(message)s",
                "datefmt": "%b-%d-%Y %I:%M:%S %p",
            }
        },
        "handlers": {"default": log_handler},
        "loggers": {
            "uvicorn": {"handlers": ["default"], "level": level},
            "uvicorn.error": {"handlers": ["default"], "level": level, "propagate": False},
            "uvicorn.access": {"handlers": ["default"], "level": level, "propagate": False},
            "uvicorn.default": {"handlers": ["default"], "level": level, "propagate": False},
        },
        "root": {"handlers": ["default"], "level": level},
    }


class PydanticEnvConfig(BaseSettings):
    """Pydantic BaseSettings with custom order for loading environment variables.

    >>> PydanticEnvConfig

    """

    @classmethod
    def settings_customise_sources(
        cls,
        settings_cls,
        init_settings,
        env_settings,
        dotenv_settings,
        file_secret_settings,
    ):
        """Customize the order of settings sources."""
        # Precedence (last wins):
        # env < dotenv < file secrets < init
        return (
            env_settings,
            dotenv_settings,
            file_secret_settings,
            init_settings,
        )


class MonitorTarget(BaseModel):
    """Model representing a monitoring target.

    >>> MonitorTarget

    """

    name: str
    base_url: HttpUrl
    apikey: str


def alias_choices(variable: str = None, prefix: str = None, choices: Iterable = None) -> AliasChoices:
    """Custom alias choices for environment variables for GitHub.

    Args:
        variable: Variable name.
        prefix: Prefix for the variable.
        choices: Additional custom choices for the variable.

    Returns:
        AliasChoices:
        Returns the alias choices for the variable.
    """
    if choices:
        choices = tuple(x for choice in choices for x in (choice.upper(), choice.lower()))
    else:
        choices = (variable.upper(), variable.lower())
        if prefix:
            choices += (f"{prefix}_{variable}".upper(), f"{prefix}_{variable}".lower())
    return AliasChoices(*choices)


class EnvConfig(PydanticEnvConfig):
    """Configuration settings for the server.

    >>> EnvConfig

    """

    host: str = Field(socket.gethostbyname("localhost") or "0.0.0.0", validation_alias=alias_choices("HOST", "MONITOR"))
    port: PositiveInt = Field(8080, validation_alias=alias_choices("PORT", "MONITOR"))
    legacy_ui: bool = False

    targets: List[MonitorTarget] = Field(..., validation_alias=alias_choices("TARGETS", "MONITOR"))
    interval: PositiveInt = Field(3, validation_alias=alias_choices("INTERVAL", "MONITOR"))

    log: enums.Log | None = None
    logs_path: str = "logs"
    debug: bool = False
    log_config: Dict[str, Any] | FilePath | None = None

    username: str | None = Field(None, validation_alias=alias_choices("USERNAME", "MONITOR"))
    password: str | None = Field(None, validation_alias=alias_choices("PASSWORD", "MONITOR"))
    timeout: PositiveInt = Field(300, validation_alias=alias_choices("TIMEOUT", "MONITOR"))

    kuma_url: str | None = Field(None, validation_alias=alias_choices("KUMA_URL", "UPTIME"))
    kuma_username: str | None = Field(None, validation_alias=alias_choices("KUMA_USERNAME", "UPTIME"))
    kuma_password: str | None = Field(None, validation_alias=alias_choices("KUMA_PASSWORD", "UPTIME"))
    kuma_timeout: PositiveInt = Field(5, validation_alias=alias_choices("KUMA_TIMEOUT", "UPTIME"))

    git_url: HttpUrl = Field("https://api.github.com", validation_alias=alias_choices("GIT_URL", "GITHUB_URL"))
    git_org: str | None = Field(None, validation_alias=alias_choices(choices=("GIT_ORG", "GITHUB_ORG")))
    git_token: str | None = Field(None, validation_alias=alias_choices(choices=("GIT_TOKEN", "GITHUB_TOKEN")))

    prometheus_enabled: bool = False

    class Config:
        """Environment variables configuration."""

        env_prefix = ""
        extra = "forbid"
        hide_input_in_errors = True

    @classmethod
    def from_env_file(cls, filename: pathlib.Path | str) -> "EnvConfig":
        """Create an instance of EnvConfig from environment file.

        Args:
            filename: Name of the env file.

        Returns:
            EnvConfig:
            Loads the ``EnvConfig`` model.
        """
        # noinspection PyArgumentList
        return cls(_env_file=filename)


def load_kwargs(**kwargs) -> EnvConfig:
    """Load environment configuration from kwargs, ensuring they take precedence over existing environment variables.

    Returns:
        EnvConfig:
        Loads the ``EnvConfig`` model with the provided kwargs, resolving any conflicts with environment variables.
    """
    os_environ_backup = os.environ.copy()
    kwarg_keys_lower = {k.lower() for k in kwargs.keys()}
    keys_to_remove = (key for key in os.environ if key.lower() in kwarg_keys_lower)
    for key in keys_to_remove:
        os.environ.pop(key)
    try:
        return EnvConfig(**{k.lower(): v for k, v in kwargs.items()})
    finally:
        os.environ.update(os_environ_backup)


def env_loader(**kwargs) -> EnvConfig:
    """Loads environment variables based on filetypes or kwargs.

    Returns:
        EnvConfig:
        Returns a reference to the ``EnvConfig`` object.
    """
    # Default to .env if no kwargs were passed
    if not kwargs:
        return EnvConfig.from_env_file(".env")
    # Look for the kwarg env_file and process accordingly
    if env_file := kwargs.get("env_file") or os.getenv("env_file"):
        env_file = pathlib.Path(env_file)
        assert env_file.is_file(), f"\n\tenv_file: [{env_file.resolve()!r}] does not exist"
        if env_file.suffix.lower() == ".json":
            with env_file.open() as stream:
                env_data = json.load(stream)
            return load_kwargs(**env_data)
        if not env_file.suffix or env_file.suffix.lower() in (
            ".text",
            ".txt",
            ".env",
            "",
        ):
            return EnvConfig.from_env_file(env_file)
        raise ValueError(f"\n\tUnsupported format for {env_file!r}, " "can be one of (.json, .txt, .text, .env)")
    # Load env config with regular kwargs
    return load_kwargs(**kwargs)


env: EnvConfig
targets_by_url: Dict[str, Dict[str, str]]
