LIBRARY = "taskbar"
VERSION = "1.0.0"

AUTHOR = "lqxnjk"
AUTHOR_EMAIL = "lqxnjk@qq.com"
DESCRIPTION = "一个功能丰富、彩色显示、支持多线程/多进程的任务进度条库。让您的循环处理过程一目了然！"
LICENSE = "MIT"
PYTHON_REQUIRES = ">=3.7"
URL = f"https://github.com/lqxnjk/{LIBRARY}"

PROJECT_URLS = {
    'Bug Reports': f'{URL}/issues',
    'Source': URL,
    }

# Package discovery
PACKAGE_EXCLUDES = ['tests*', 'docs*', 'examples*']

# Classifiers
CLASSIFIERS = [
    "Development Status :: 3 - Alpha",
    "Intended Audience :: Developers",
    "Intended Audience :: Science/Research",
    "Programming Language :: Python :: 3.7",
    "License :: OSI Approved :: MIT License",
    "Operating System :: OS Independent",
    "Topic :: Software Development :: Libraries",
    "Topic :: Scientific/Engineering",
    ]

# Keywords
KEYWORDS = ["task", "bar", "rule", "tool", "data"]


EXTRAS_REQUIRE = {
    ':python_version < "3.8"': ['typing-extensions'],
    'dev': [
        # 'pytest>=6.0',
        # 'pytest-cov>=2.0',
        # 'flake8>=3.9',
        # 'mypy>=0.910',
        # 'sphinx>=4.0',
        ],
    'plot': [
        # 'matplotlib>=3.0',
        # 'seaborn>=0.11',
        ],
    'gpu': [
        # 'cupy>=10.0'
        ],
    'full': [f'{LIBRARY}[dev]', f'{LIBRARY}[plot]', f'{LIBRARY}[gpu]']
    }


def readme_text():
    """Read README.md content as long description."""
    with open('README.md', 'r', encoding='utf-8') as f:
        return f.read()


def requirements_list():
    """Read requirements from requirements.txt."""
    import pathlib
    with open(pathlib.Path(__file__).absolute().parent / 'requirements.txt', 'r', encoding='utf-8') as f:
        return [
            line.strip() for line in f
            if line.strip()
               and not line.startswith('#')
               and not line.startswith('--')
            ]


# ========== Setup Configuration ==========
import setuptools

setuptools.setup(
    name=LIBRARY,
    version=VERSION,
    packages=setuptools.find_packages(exclude=PACKAGE_EXCLUDES),
    install_requires=requirements_list(),
    extras_require=EXTRAS_REQUIRE,
    include_package_data=True,
    author=AUTHOR,
    author_email=AUTHOR_EMAIL,
    description=DESCRIPTION,
    long_description=readme_text(),
    long_description_content_type='text/markdown',
    url=URL,
    project_urls=PROJECT_URLS,
    classifiers=CLASSIFIERS,
    python_requires=PYTHON_REQUIRES,
    license=LICENSE,
    keywords=KEYWORDS,
    )
