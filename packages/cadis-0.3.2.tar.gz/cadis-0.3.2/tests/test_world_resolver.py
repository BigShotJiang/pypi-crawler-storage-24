from __future__ import annotations

from pathlib import Path

from cadis.world.cgd_world_resolver import CGDWorldResolver


def test_open_sea_prefers_specific_name_over_generic_ocean():
    cgd_path = (
        Path(__file__).resolve().parents[1]
        / "cadis"
        / "world"
        / "data"
        / "ne.global.v0.1.0.cgd"
    )
    assert cgd_path.is_file()

    resolver = CGDWorldResolver(cgd_path=cgd_path)
    out = resolver.resolve(39.48432435620471, 135.47042885544565)

    assert out["lookup_status"] == "ok"
    assert out["resolution_method"] == "open_sea"
    assert out["world_result"]["type"] == "open_sea"
    assert out["world_result"]["name"] == "Sea of Japan"
