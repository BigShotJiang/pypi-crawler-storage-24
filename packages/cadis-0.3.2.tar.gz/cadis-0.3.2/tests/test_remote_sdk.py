from __future__ import annotations

from cadis._remote_sdk import CadisRemoteSDK


def test_remote_sdk_lookup_uses_default_lazy_mode(monkeypatch):
    sent = {}
    sdk = CadisRemoteSDK("http://localhost:8080", mode="lazy", auto_update=True)

    def _fake_post(path: str, payload: dict):
        sent["path"] = path
        sent["payload"] = payload
        return {"execution": {"lookup_status": "ok"}}

    monkeypatch.setattr(sdk, "_post", _fake_post)
    out = sdk.lookup(25.03, 121.56)

    assert out["execution"]["lookup_status"] == "ok"
    assert sent["path"] == "/lookup"
    assert sent["payload"]["mode"] == "lazy"
    assert sent["payload"]["auto_update"] is True


def test_remote_sdk_lookup_can_override_mode(monkeypatch):
    sent = {}
    sdk = CadisRemoteSDK("http://localhost:8080", mode="lazy", auto_update=True)

    def _fake_post(path: str, payload: dict):
        sent["payload"] = payload
        return {"execution": {"lookup_status": "ok"}}

    monkeypatch.setattr(sdk, "_post", _fake_post)
    sdk.lookup(25.03, 121.56, mode="strict", auto_update=False)

    assert sent["payload"]["mode"] == "strict"
    assert sent["payload"]["auto_update"] is False

