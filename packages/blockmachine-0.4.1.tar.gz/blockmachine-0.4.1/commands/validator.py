"""Validator commands: authentication for the verification gateway"""

import os
from pathlib import Path

import typer
import yaml
from rich.console import Console

from cli import settings
from cli.commands.auth import device_login, validate_token_claims

app = typer.Typer(help="Validator authentication")

console = Console()

_config_path: Path | None = None


@app.callback()
def _validator_options(
    config: str = typer.Option(
        None,
        "--config",
        "-c",
        help="Path to validator config.yaml (or set CONFIG_PATH env)",
    ),
) -> None:
    global _config_path
    _config_path = _resolve_config_path(config)


def _resolve_config_path(explicit: str | None) -> Path | None:
    """Find the validator config YAML from flag or CONFIG_PATH env.

    Raises typer.Exit(1) if an explicit path was given but doesn't exist.
    Returns None when no path was specified.
    """
    path_str = explicit or os.environ.get("CONFIG_PATH")
    if not path_str:
        return None
    path = Path(path_str)
    if not path.is_file():
        console.print(f"[red]Config file not found:[/red] {path}")
        raise typer.Exit(1)
    return path


def _update_validator_config(
    config_path: Path,
    access_token: str,
    refresh_token: str,
    auth_url: str,
    client_id: str,
) -> None:
    """Write gateway tokens into the validator config YAML."""
    with open(config_path) as f:
        data = yaml.safe_load(f) or {}

    gw = data.setdefault("verification_gateway", {})
    gw["access_token"] = access_token
    gw["refresh_token"] = refresh_token
    gw["auth_url"] = auth_url
    gw["client_id"] = client_id

    with open(config_path, "w") as f:
        yaml.safe_dump(data, f, default_flow_style=False)


@app.command("login")
def login(
    client_id: str = typer.Option(None, "--client-id", help="OAuth client ID"),
    auth_url: str = typer.Option(None, "--auth-url", help="TaoStats auth URL"),
    no_browser: bool = typer.Option(
        False, "--no-browser", help="Don't auto-open browser"
    ),
) -> None:
    """Login with validator scopes for the verification gateway."""
    resolved_client_id = client_id or settings.CLIENT_ID
    resolved_auth_url = auth_url or settings.auth_url()

    token_data = device_login(
        scopes=settings.validator_scopes(),
        client_id=client_id,
        auth_url=auth_url,
        no_browser=no_browser,
    )

    claims = validate_token_claims(token_data)
    access_token = token_data["access_token"]
    refresh_token = token_data.get("refresh_token", "")

    console.print("\n[green]Login successful![/green]")

    scope = claims.get("scope", token_data.get("scope", ""))
    if scope:
        console.print(f"[dim]Scopes: {scope}[/dim]")

    if _config_path:
        _update_validator_config(
            _config_path,
            access_token,
            refresh_token,
            resolved_auth_url,
            resolved_client_id,
        )
        console.print(f"\n[bold]Updated:[/bold] {_config_path}")
        console.print("[dim]Restart the validator to pick up new tokens.[/dim]")
    else:
        console.print()
        console.print("[bold]Add these to your validator environment:[/bold]")
        console.print()
        console.print(f"export VERIFICATION_GATEWAY_TOKEN='{access_token}'")
        if refresh_token:
            console.print(
                f"export VERIFICATION_GATEWAY_REFRESH_TOKEN='{refresh_token}'"
            )
