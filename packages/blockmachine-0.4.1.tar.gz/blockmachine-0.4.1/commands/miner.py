"""Miner commands: node registration, secrets, and pricing"""

import getpass
import hashlib
import ipaddress
import json
import logging
import socket
import ssl
import time
from typing import Callable, Optional
from urllib.parse import urlparse

import httpx
import typer
from rich.console import Console
from rich.table import Table

from cli.client import RegistryClient
from cli import settings
from cli.commands.auth import check_status, device_login, do_logout, save_miner_token
from cli.config import load_config, save_config
from cli.utils import format_timestamp, resolve_node_id

app = typer.Typer(help="Miner node management")
secret_app = typer.Typer(help="Secret management")
price_app = typer.Typer(help="Pricing management")

app.add_typer(secret_app, name="secret")
app.add_typer(price_app, name="price")

console = Console()
logger = logging.getLogger(__name__)

CHAIN = "tao"


def _get_alias(alias: Optional[str]) -> str:
    """Resolve alias from argument or active node context."""
    if alias:
        return alias
    config = load_config()
    if config.active_miner_node:
        return config.active_miner_node
    console.print(
        "[red]No node specified and no active node set.[/red]\n"
        "Run 'bm miner use <alias>' first."
    )
    raise typer.Exit(1)


def _resolve_node(client: RegistryClient, id_or_alias: str) -> str:
    """Resolve an alias or ID to a node UUID."""
    response = client.get("/nodes")
    if response.status_code != 200:
        console.print(f"[red]Error:[/red] {response.status_code}")
        raise typer.Exit(1)
    node_id = resolve_node_id(response.json(), id_or_alias)
    if not node_id:
        console.print(f"[red]Node not found:[/red] {id_or_alias}")
        raise typer.Exit(1)
    return node_id


# ── Auth ─────────────────────────────────────────────────────────


@app.command("login")
def login(
    client_id: str = typer.Option(None, "--client-id", help="OAuth client ID"),
    auth_url: str = typer.Option(None, "--auth-url", help="TaoStats auth URL"),
    api_url: str = typer.Option(None, "--api-url", "-u", help="Registry API URL"),
    no_browser: bool = typer.Option(
        False, "--no-browser", help="Don't auto-open browser"
    ),
) -> None:
    """Login with miner scopes."""
    token_data = device_login(
        scopes=settings.miner_scopes(),
        client_id=client_id,
        auth_url=auth_url,
        no_browser=no_browser,
    )
    save_miner_token(
        token_data, client_id=client_id, auth_url=auth_url, api_url=api_url
    )


@app.command("status")
def status() -> None:
    """Check authentication status."""
    check_status()


@app.command("logout")
def logout() -> None:
    """Clear stored authentication tokens."""
    do_logout()


# ── TLS ──────────────────────────────────────────────────────────


def _test_tls(hostname: str, port: int) -> tuple[bool, Optional[str], str]:
    """Test TLS handshake. Return (ok, fingerprint, message)."""
    try:
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        with socket.create_connection((hostname, port), timeout=10) as sock:
            with ctx.wrap_socket(sock, server_hostname=hostname) as tls:
                der = tls.getpeercert(binary_form=True)
                fp = hashlib.sha256(der).hexdigest() if der else None
                return True, fp, "OK"
    except Exception as e:
        return False, None, str(e)


def _bracket_ipv6(hostname: str) -> str:
    """Wrap bare IPv6 addresses in brackets for use in URLs."""
    try:
        addr = ipaddress.ip_address(hostname)
        if addr.version == 6:
            return f"[{hostname}]"
    except ValueError:
        pass
    return hostname


def _is_ip_endpoint(endpoint: str) -> bool:
    """Return True if the endpoint hostname is an IP address (not a domain)."""
    hostname = urlparse(endpoint).hostname
    if not hostname:
        return False
    try:
        ipaddress.ip_address(hostname)
        return True
    except ValueError:
        return False


def _get_cert_fingerprint(endpoint: str) -> Optional[str]:
    """Fetch the SHA256 fingerprint of the TLS leaf certificate."""
    parsed = urlparse(endpoint)
    hostname = parsed.hostname
    port = parsed.port or 443
    if not hostname:
        return None
    ok, fingerprint, _ = _test_tls(hostname, port)
    if not ok:
        logger.warning("Could not fetch TLS certificate from %s", endpoint)
        return None
    return fingerprint


# ── Node CRUD ────────────────────────────────────────────────────


@app.command("add")
def add(
    endpoint: str = typer.Option(None, "--endpoint", "-e", help="WSS endpoint URL"),
    alias: str = typer.Option(None, "--alias", "-a", help="Friendly name"),
    secret: str = typer.Option(None, "--secret", "-s", help="Bearer token secret"),
    price: str = typer.Option(None, "--price", "-p", help="USD per compute unit"),
) -> None:
    """Register a new miner node (interactive if flags omitted)."""
    if not endpoint:
        endpoint = typer.prompt("Endpoint (wss://...)")
    if not alias:
        default = _default_alias(endpoint)
        alias = typer.prompt("Alias", default=default)
    if not secret:
        secret = getpass.getpass("Secret: ")
    if not price:
        price = typer.prompt("Price (USD/CU)")

    if len(secret) < 16:
        console.print("[red]Secret must be at least 16 characters[/red]")
        raise typer.Exit(1)

    fp = None
    if _is_ip_endpoint(endpoint):
        fp = _get_cert_fingerprint(endpoint)
        if fp:
            console.print(f"[dim]TLS fingerprint (pinned): {fp}[/dim]")
        else:
            console.print(
                "[yellow]Warning: Could not fetch TLS certificate from endpoint.[/yellow]\n"
                "[yellow]The gateway will not be able to verify this miner's identity.[/yellow]"
            )
    else:
        console.print("[dim]Domain endpoint — using standard CA verification[/dim]")

    config = load_config()
    with RegistryClient(config) as client:
        node_id = _create_node(client, endpoint, alias, secret, cert_fingerprint=fp)
        _set_node_price(client, node_id, price)

    config.active_miner_node = alias
    save_config(config)

    console.print(f"\n[dim]Active node set to '{alias}'[/dim]")


def _default_alias(endpoint: str) -> str:
    """Derive a default alias from an endpoint URL."""
    host = endpoint.replace("wss://", "").replace("ws://", "")
    host = host.split(":")[0].split("/")[0]
    return f"tao-{host.replace('.', '-')}"


def _create_node(
    client: RegistryClient,
    endpoint: str,
    alias: str,
    secret: str,
    cert_fingerprint: Optional[str] = None,
) -> str:
    """Register a node with its secret and return its ID."""
    payload: dict = {
        "endpoint": endpoint,
        "chain": CHAIN,
        "alias": alias,
        "secret": secret,
    }
    if cert_fingerprint is not None:
        payload["cert_fingerprint"] = cert_fingerprint
    response = client.post("/nodes", json=payload)
    if response.status_code == 201:
        data = response.json()
        console.print(f"[green]Node registered:[/green] {data['id'][:8]}")
        return data["id"]
    if response.status_code == 401:
        console.print("[red]Not authenticated.[/red] Run 'bm miner login' first.")
        raise typer.Exit(1)
    if response.status_code == 409:
        detail = response.json().get("detail", "Alias already exists")
        console.print(f"[red]Conflict:[/red] {detail}")
        raise typer.Exit(1)
    console.print(f"[red]Error:[/red] {response.status_code} - {response.text}")
    raise typer.Exit(1)


def _set_node_price(client: RegistryClient, node_id: str, price: str) -> None:
    """Set the price on a node."""
    response = client.post(
        f"/nodes/{node_id}/price",
        json={"target_usd_per_cu": price},
    )
    if response.status_code == 201:
        data = response.json()
        console.print(
            f"[green]Price set:[/green]"
            f" {data['target_usd_per_cu']} USD/CU"
            f" (epoch {data['effective_from_epoch']})"
        )
        return
    console.print(
        f"[red]Failed to set price:[/red] {response.status_code} - {response.text}"
    )
    raise typer.Exit(1)


@app.command("use")
def use(
    alias: str = typer.Argument(..., help="Node alias to set as active"),
) -> None:
    """Set the active miner node for subsequent commands."""
    config = load_config()
    config.active_miner_node = alias
    save_config(config)
    console.print(f"Active miner node: [bold]{alias}[/bold]")


@app.command("ls")
def ls() -> None:
    """List all miner nodes."""
    config = load_config()
    with RegistryClient(config) as client:
        response = client.get("/nodes")

    if response.status_code == 401:
        console.print("[red]Not authenticated.[/red] Run 'bm miner login' first.")
        raise typer.Exit(1)
    if response.status_code != 200:
        console.print(f"[red]Error:[/red] {response.status_code} - {response.text}")
        raise typer.Exit(1)

    nodes = response.json().get("nodes", [])
    if not nodes:
        console.print("[dim]No nodes registered[/dim]")
        return

    active = config.active_miner_node
    table = Table(title="Miner Nodes")
    table.add_column("", width=1)
    table.add_column("Alias")
    table.add_column("Chain")
    table.add_column("Status")
    table.add_column("Endpoint")
    table.add_column("Last Seen")

    for node in nodes:
        status_color = {
            "active": "green",
            "pending": "yellow",
            "unreachable": "red",
            "suspended": "red",
        }.get(node["status"], "white")
        marker = "*" if node.get("alias") == active else ""

        table.add_row(
            marker,
            node.get("alias") or node["id"][:8],
            node["chain"],
            f"[{status_color}]{node['status']}[/{status_color}]",
            _truncate(node["endpoint"], 40),
            format_timestamp(node.get("last_seen_at")),
        )

    console.print(table)


def _truncate(text: str, length: int) -> str:
    if len(text) <= length:
        return text
    return text[:length] + "..."


@app.command("show")
def show(
    alias: str = typer.Argument(None, help="Node alias or ID"),
) -> None:
    """Show details of a miner node."""
    alias = _get_alias(alias)
    config = load_config()

    with RegistryClient(config) as client:
        node_id = _resolve_node(client, alias)
        response = client.get(f"/nodes/{node_id}")

        if response.status_code == 404:
            console.print(f"[red]Node not found:[/red] {alias}")
            raise typer.Exit(1)
        if response.status_code != 200:
            console.print(f"[red]Error:[/red] {response.status_code} - {response.text}")
            raise typer.Exit(1)

        node = response.json()
        console.print(f"[bold]ID:[/bold] {node['id']}")
        console.print(f"[bold]Alias:[/bold] {node.get('alias') or '-'}")
        console.print(f"[bold]Chain:[/bold] {node['chain']}")
        console.print(f"[bold]Status:[/bold] {node['status']}")
        console.print(f"[bold]Endpoint:[/bold] {node['endpoint']}")
        console.print(f"[bold]Created:[/bold] {format_timestamp(node['created_at'])}")
        console.print(
            f"[bold]Last Seen:[/bold] {format_timestamp(node.get('last_seen_at'))}"
        )

        m_resp = client.get(f"/nodes/{node_id}/metrics")
        if m_resp.status_code == 200:
            m = m_resp.json()
            if m.get("available"):
                console.print()
                console.print("[bold]Routing Metrics[/bold]")
                _print_metrics(m)


def _fmt_success_rate(v: float) -> str:
    pct = v * 100
    color = "green" if pct >= 99 else "yellow" if pct >= 95 else "red"
    return f"[{color}]{pct:.1f}%[/{color}]"


_METRIC_FIELDS: list[tuple[str, str, Callable]] = [
    ("request_count", "Requests", lambda v: f"{v:,}"),
    ("success_rate", "Success Rate", _fmt_success_rate),
    ("p95_ms", "P95 Latency", lambda v: f"{v:.0f} ms"),
    ("latency_score", "Latency Score", lambda v: f"{v:.4f}"),
    ("routing_score", "Routing Score", lambda v: f"{v:.4f}"),
    ("traffic_pct", "Traffic Share", lambda v: f"{v:.1f}%"),
    ("reliability", "Reliability", lambda v: f"{v:.4f}"),
    ("epochs_good", "Epochs Good", str),
    ("bid", "Bid", lambda v: f"${v:.6f}"),
    ("cohort_median", "Cohort Median", lambda v: f"${v:.6f}"),
    ("price_factor", "Price Factor", lambda v: f"{v:.4f}"),
]


def _print_metrics(m: dict) -> None:
    """Print routing metrics from a metrics API response."""
    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column("Key", style="bold")
    table.add_column("Value")

    for key, label, fmt in _METRIC_FIELDS:
        val = m.get(key)
        if val is not None:
            table.add_row(label, fmt(val))

    console.print(table)


@app.command("metrics")
def metrics(
    alias: str = typer.Argument(None, help="Node alias or ID"),
) -> None:
    """Show routing metrics for a miner node."""
    alias = _get_alias(alias)
    config = load_config()

    with RegistryClient(config) as client:
        node_id = _resolve_node(client, alias)
        response = client.get(f"/nodes/{node_id}/metrics")

        if response.status_code == 503:
            console.print(
                "[yellow]Metrics not available (scoring not enabled)[/yellow]"
            )
            raise typer.Exit(1)
        if response.status_code != 200:
            console.print(f"[red]Error:[/red] {response.status_code} - {response.text}")
            raise typer.Exit(1)

        m = response.json()
        if not m.get("available"):
            console.print(
                f"[yellow]No metrics available for {alias}[/yellow]\n"
                "[dim]The gateway may not have routed traffic to this"
                " node yet.[/dim]"
            )
            return

        console.print(f"[bold]Routing Metrics: {alias}[/bold]\n")
        _print_metrics(m)


@app.command("rm")
def rm(
    alias: str = typer.Argument(None, help="Node alias or ID"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
) -> None:
    """Remove a miner node."""
    alias = _get_alias(alias)
    config = load_config()

    with RegistryClient(config) as client:
        node_id = _resolve_node(client, alias)

        if not force:
            confirm = typer.confirm(f"Delete node {alias}?")
            if not confirm:
                console.print("[dim]Cancelled[/dim]")
                return

        response = client.delete(f"/nodes/{node_id}")

    if response.status_code == 204:
        console.print("[green]Node deleted[/green]")
        if config.active_miner_node == alias:
            config.active_miner_node = None
            save_config(config)
    elif response.status_code == 404:
        console.print(f"[red]Node not found:[/red] {alias}")
        raise typer.Exit(1)
    else:
        console.print(f"[red]Error:[/red] {response.status_code} - {response.text}")
        raise typer.Exit(1)


@app.command("update")
def update(
    alias: str = typer.Argument(None, help="Node alias or ID"),
    new_alias: str = typer.Option(None, "--alias", "-a", help="New alias"),
    endpoint: str = typer.Option(None, "--endpoint", "-e", help="New endpoint"),
) -> None:
    """Update a node's alias or endpoint."""
    alias = _get_alias(alias)

    if not new_alias and not endpoint:
        console.print(
            "[yellow]Nothing to update. Specify --alias or --endpoint[/yellow]"
        )
        return

    config = load_config()
    update_data: dict = {}
    if new_alias:
        update_data["alias"] = new_alias
    if endpoint:
        update_data["endpoint"] = endpoint

    with RegistryClient(config) as client:
        node_id = _resolve_node(client, alias)
        response = client.patch(f"/nodes/{node_id}", json=update_data)

    if response.status_code == 200:
        console.print("[green]Node updated[/green]")
        if new_alias and config.active_miner_node == alias:
            config.active_miner_node = new_alias
            save_config(config)
    elif response.status_code == 409:
        detail = response.json().get("detail", "Alias already exists")
        console.print(f"[red]Conflict:[/red] {detail}")
        raise typer.Exit(1)
    else:
        console.print(f"[red]Error:[/red] {response.status_code} - {response.text}")
        raise typer.Exit(1)


# ── Test ─────────────────────────────────────────────────────────


def _test_health(hostname: str) -> tuple[bool, str]:
    """Test HTTP health endpoint on port 80."""
    try:
        r = httpx.get(
            f"http://{_bracket_ipv6(hostname)}/health",
            timeout=10,
            follow_redirects=True,
        )
        if r.status_code == 200:
            return True, "OK"
        return False, f"HTTP {r.status_code}"
    except Exception as e:
        return False, str(e)


def _test_rpc(
    hostname: str, port: int, secret: str
) -> tuple[bool, Optional[float], str]:
    """Send system_health RPC over HTTPS. Return (ok, latency_ms, message)."""
    url = f"https://{_bracket_ipv6(hostname)}:{port}"
    payload = {
        "jsonrpc": "2.0",
        "method": "system_health",
        "params": [],
        "id": 1,
    }
    try:
        start = time.monotonic()
        r = httpx.post(
            url,
            json=payload,
            headers={"Authorization": f"Bearer {secret}"},
            timeout=10,
            verify=False,
        )
        latency = (time.monotonic() - start) * 1000
        if r.status_code == 401:
            return False, None, "Authentication failed (secret mismatch)"
        if r.status_code != 200:
            return False, None, f"HTTP {r.status_code}"
        data = r.json()
        if "result" in data:
            result = data["result"]
            peers = result.get("peers", "?")
            syncing = result.get("isSyncing", False)
            status = "syncing" if syncing else "synced"
            return True, latency, f"peers={peers}, {status}"
        error = data.get("error", {}).get("message", json.dumps(data))
        return False, latency, f"RPC error: {error}"
    except Exception as e:
        return False, None, str(e)


def _fetch_active_secret(client: RegistryClient, node_id: str) -> Optional[str]:
    """Fetch the decrypted active secret from the registry."""
    response = client.get(f"/nodes/{node_id}/secret")
    if response.status_code != 200:
        return None
    for s in response.json().get("secrets", []):
        if s.get("state") == "active" and s.get("secret"):
            return s["secret"]
    return None


@app.command("test")
def test(
    alias: Optional[str] = typer.Argument(None, help="Node alias or ID"),
    endpoint: Optional[str] = typer.Option(
        None, "--endpoint", "-e", help="Endpoint URL (skip registry lookup)"
    ),
    secret: Optional[str] = typer.Option(
        None, "--secret", help="Bearer token (overrides registry)"
    ),
) -> None:
    """Test connectivity to a miner node (TLS, health, auth, RPC).

    For registered nodes, fetches the secret from the registry
    automatically. Use --endpoint and --secret for pre-registration
    testing.
    """
    if not endpoint:
        alias = _get_alias(alias)
        config = load_config()
        with RegistryClient(config) as client:
            node_id = _resolve_node(client, alias)
            response = client.get(f"/nodes/{node_id}")
            if response.status_code != 200:
                console.print(f"[red]Error:[/red] {response.status_code}")
                raise typer.Exit(1)
            node = response.json()
            endpoint = node["endpoint"]
            if not secret:
                secret = _fetch_active_secret(client, node_id)
        console.print(f"[bold]Alias:[/bold]    {alias}")

    parsed = urlparse(endpoint)
    hostname = parsed.hostname
    port = parsed.port or 443

    if not hostname:
        console.print(f"[red]Cannot parse endpoint:[/red] {endpoint}")
        raise typer.Exit(1)

    console.print(f"[bold]Endpoint:[/bold] {endpoint}\n")

    all_ok = True

    # 1. TLS
    console.print("TLS handshake... ", end="")
    tls_ok, fingerprint, tls_msg = _test_tls(hostname, port)
    if tls_ok:
        is_ip = _is_ip_endpoint(endpoint)
        mode = "pinned" if is_ip else "CA-verified"
        fp_short = fingerprint[:16] + "..." if fingerprint else "none"
        console.print(f"[green]OK[/green] ({mode}, {fp_short})")
    else:
        console.print(f"[red]FAIL[/red] {tls_msg}")
        all_ok = False

    # 2. Health
    console.print("Health check...  ", end="")
    health_ok, health_msg = _test_health(hostname)
    if health_ok:
        console.print("[green]OK[/green]")
    else:
        console.print(f"[red]FAIL[/red] {health_msg}")
        all_ok = False

    # 3. RPC with auth (only if secret provided)
    if secret:
        console.print("RPC query...     ", end="")
        rpc_ok, latency, rpc_msg = _test_rpc(hostname, port, secret)
        if rpc_ok:
            console.print(f"[green]OK[/green] ({rpc_msg}, {latency:.0f}ms)")
        else:
            console.print(f"[red]FAIL[/red] {rpc_msg}")
            all_ok = False
    else:
        console.print("[dim]Pass --secret to also test auth and RPC[/dim]")

    console.print()
    if all_ok:
        console.print("[green]All checks passed[/green]")
    else:
        console.print("[red]Some checks failed[/red]")
        raise typer.Exit(1)


# ── Snapshots ────────────────────────────────────────────────────


@app.command("snapshot")
def snapshot(
    chain: str = typer.Option("tao", "--chain", "-c", help="Chain identifier"),
    node_type: str = typer.Option(
        "lite", "--type", "-t", help="Node type (lite or archive)"
    ),
) -> None:
    """Get a pre-signed URL to download a chain snapshot."""
    config = load_config()
    with RegistryClient(config) as client:
        response = client.post(
            "/snapshots/url",
            params={"chain": chain, "node_type": node_type},
        )

    if response.status_code == 401:
        console.print("[red]Not authenticated.[/red] Run 'bm miner login' first.")
        raise typer.Exit(1)
    if response.status_code == 404:
        console.print(f"[yellow]No snapshot available for {chain}/{node_type}[/yellow]")
        raise typer.Exit(1)
    if response.status_code == 503:
        console.print("[yellow]Snapshots are not configured on this registry[/yellow]")
        raise typer.Exit(1)
    if response.status_code != 200:
        console.print(f"[red]Error:[/red] {response.status_code} - {response.text}")
        raise typer.Exit(1)

    data = response.json()
    expiry_hours = data["expires_in_seconds"] // 3600

    console.print(f"\n[bold]Snapshot: {chain}/{node_type}[/bold]")
    console.print(f"  Size:   {data['size_mb']} MB")
    console.print(f"  Valid:  {expiry_hours} hours")
    console.print("\n[bold]Snapshot URL:[/bold]\n")
    console.print(f"  {data['url']}")
    console.print(
        "\n[dim]Paste this URL when prompted during install,"
        " or download manually on your VPS.[/dim]\n"
    )


# ── Secrets ──────────────────────────────────────────────────────


@secret_app.command("set")
def secret_set(
    alias: str = typer.Argument(None, help="Node alias or ID"),
    secret: str = typer.Option(
        None,
        "--secret",
        "-s",
        help="Secret value (will prompt if not provided)",
    ),
) -> None:
    """Set the bearer token secret for a node."""
    alias = _get_alias(alias)

    if not secret:
        secret = getpass.getpass("Enter secret: ")
        confirm = getpass.getpass("Confirm secret: ")
        if secret != confirm:
            console.print("[red]Secrets do not match[/red]")
            raise typer.Exit(1)

    if len(secret) < 16:
        console.print("[red]Secret must be at least 16 characters[/red]")
        raise typer.Exit(1)

    config = load_config()
    with RegistryClient(config) as client:
        node_id = _resolve_node(client, alias)
        response = client.post(
            f"/nodes/{node_id}/secret",
            json={"secret": secret, "rotate": False},
        )

    if response.status_code == 201:
        data = response.json()
        console.print("[green]Secret set[/green]")
        console.print(f"[bold]Version:[/bold] {data['version']}")
    else:
        console.print(f"[red]Error:[/red] {response.status_code} - {response.text}")
        raise typer.Exit(1)


@secret_app.command("show")
def secret_show(
    alias: str = typer.Argument(None, help="Node alias or ID"),
) -> None:
    """Show secret metadata (not the secret itself)."""
    alias = _get_alias(alias)
    config = load_config()

    with RegistryClient(config) as client:
        node_id = _resolve_node(client, alias)
        response = client.get(f"/nodes/{node_id}/secret")

    if response.status_code != 200:
        console.print(f"[red]Error:[/red] {response.status_code} - {response.text}")
        raise typer.Exit(1)

    secrets = response.json().get("secrets", [])
    if not secrets:
        console.print("[dim]No secrets configured[/dim]")
        return

    table = Table(title="Secrets")
    table.add_column("Version")
    table.add_column("State")
    table.add_column("Created")

    for s in secrets:
        color = {"active": "green", "next": "yellow", "retired": "dim"}.get(
            s["state"], "white"
        )
        table.add_row(
            str(s["version"]),
            f"[{color}]{s['state']}[/{color}]",
            format_timestamp(s["created_at"]),
        )

    console.print(table)


@secret_app.command("promote")
def secret_promote(
    alias: str = typer.Argument(None, help="Node alias or ID"),
) -> None:
    """Promote the 'next' secret to 'active'."""
    alias = _get_alias(alias)
    config = load_config()

    with RegistryClient(config) as client:
        node_id = _resolve_node(client, alias)
        response = client.post(f"/nodes/{node_id}/secret/promote")

    if response.status_code == 200:
        data = response.json()
        console.print("[green]Secret promoted[/green]")
        console.print(f"[bold]Version:[/bold] {data['version']}")
    else:
        detail = response.json().get("detail", response.text)
        console.print(f"[red]Error:[/red] {detail}")
        raise typer.Exit(1)


# ── Pricing ──────────────────────────────────────────────────────


@price_app.command("set")
def price_set(
    alias: str = typer.Argument(None, help="Node alias or ID"),
    price: str = typer.Option(..., "--price", "-p", help="Target USD per compute unit"),
    epoch: int = typer.Option(
        None,
        "--epoch",
        "-e",
        help="Effective from epoch (default: next epoch)",
    ),
) -> None:
    """Set a price for a node."""
    alias = _get_alias(alias)

    config = load_config()
    payload: dict = {"target_usd_per_cu": price}
    if epoch is not None:
        payload["effective_from_epoch"] = epoch

    with RegistryClient(config) as client:
        node_id = _resolve_node(client, alias)
        response = client.post(
            f"/nodes/{node_id}/price",
            json=payload,
        )

    if response.status_code == 201:
        data = response.json()
        console.print(
            f"[green]Price set:[/green]"
            f" {data['target_usd_per_cu']} USD/CU"
            f" (epoch {data['effective_from_epoch']})"
        )
    elif response.status_code == 400:
        detail = response.json().get("detail", "Invalid request")
        console.print(f"[red]Error:[/red] {detail}")
        raise typer.Exit(1)
    else:
        console.print(f"[red]Error:[/red] {response.status_code} - {response.text}")
        raise typer.Exit(1)


@price_app.command("show")
def price_show(
    alias: str = typer.Argument(None, help="Node alias or ID"),
) -> None:
    """Show the current price for a node."""
    alias = _get_alias(alias)
    config = load_config()

    with RegistryClient(config) as client:
        node_id = _resolve_node(client, alias)
        response = client.get(f"/nodes/{node_id}/price")

    if response.status_code == 200:
        data = response.json()
        console.print(f"[bold]Price:[/bold] {data['target_usd_per_cu']} USD/CU")
        console.print(
            f"[bold]Effective from epoch:[/bold] {data['effective_from_epoch']}"
        )
        console.print(f"[bold]Set at:[/bold] {format_timestamp(data['created_at'])}")
    elif response.status_code == 404:
        detail = response.json().get("detail", "Not found")
        if "No price" in detail:
            console.print("[dim]No price set for this node[/dim]")
        else:
            console.print(f"[red]Node not found:[/red] {alias}")
        raise typer.Exit(1)
    else:
        console.print(f"[red]Error:[/red] {response.status_code} - {response.text}")
        raise typer.Exit(1)


@price_app.command("history")
def price_history(
    alias: str = typer.Argument(None, help="Node alias or ID"),
) -> None:
    """Show price history for a node."""
    alias = _get_alias(alias)
    config = load_config()

    with RegistryClient(config) as client:
        node_id = _resolve_node(client, alias)
        response = client.get(f"/nodes/{node_id}/price/history")

    if response.status_code != 200:
        console.print(f"[red]Error:[/red] {response.status_code} - {response.text}")
        raise typer.Exit(1)

    prices = response.json().get("prices", [])
    if not prices:
        console.print("[dim]No price history[/dim]")
        return

    table = Table(title="Price History")
    table.add_column("Epoch")
    table.add_column("Price (USD/CU)")
    table.add_column("Set At")

    for p in prices:
        table.add_row(
            str(p["effective_from_epoch"]),
            p["target_usd_per_cu"],
            format_timestamp(p["created_at"]),
        )

    console.print(table)
