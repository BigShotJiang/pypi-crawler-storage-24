"""Billing SDK for LimaCharlie v2."""

from __future__ import annotations

from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from .organization import Organization

BILLING_URL = "https://billing.limacharlie.io/"


class Billing:
    """Billing and subscription management for a LimaCharlie organization."""

    def __init__(self, org: Organization) -> None:
        self._org = org

    @property
    def client(self) -> Any:
        """The underlying API client."""
        return self._org.client

    def get_status(self) -> dict[str, Any]:
        """Get the current billing status for the organization."""
        return self.client.request("GET", f"orgs/{self._org.oid}/status", alt_root=BILLING_URL)

    def get_details(self) -> dict[str, Any]:
        """Get detailed billing information for the organization."""
        return self.client.request("GET", f"orgs/{self._org.oid}/details", alt_root=BILLING_URL)

    def get_invoice_url(self, year: int | str, month: int | str, fmt: str | None = None) -> dict[str, Any]:
        """Get the invoice URL for a specific month.

        Args:
            year: Invoice year.
            month: Invoice month (1-12).
            fmt: Optional format (e.g. 'pdf').

        Returns:
            dict: Invoice URL data.
        """
        year = str(int(year))
        month = str(int(month)).zfill(2)
        qp: dict[str, str] = {}
        if fmt:
            qp["format"] = fmt
        return self.client.request("GET", f"orgs/{self._org.oid}/invoice_url/{year}/{month}",
                                   alt_root=BILLING_URL, query_params=qp or None)

    def get_plans(self) -> dict[str, Any]:
        """Get available billing plans."""
        return self.client.request("GET", "user/self/plans", alt_root=BILLING_URL)

