"""Integration tests for LimaCharlie v2 SDK configuration sync (IaC).

Uses the ext-infrastructure extension for all operations.
"""

import sys
import os

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../../")))

from limacharlie.client import Client
from limacharlie.sdk.organization import Organization
from limacharlie.sdk.configs import Configs

TEST_PREFIX = "test-cli-v2-"


def test_v2_sync_fetch_outputs(oid, key):
    """Fetch outputs config via ext-infrastructure and verify it returns a dict."""
    client = Client(oid=oid, api_key=key)
    org = Organization(client)
    configs = Configs(org)

    result = configs.fetch(sync_outputs=True)
    assert isinstance(result, dict), (
        f"Expected dict from configs.fetch(sync_outputs=True), "
        f"got {type(result).__name__}"
    )


def test_v2_sync_fetch_hives(oid, key):
    """Fetch D&R rules via hives and verify it returns a dict."""
    client = Client(oid=oid, api_key=key)
    org = Organization(client)
    configs = Configs(org)

    result = configs.fetch(sync_hives={"dr-general": True})
    assert isinstance(result, dict), (
        f"Expected dict from configs.fetch(sync_hives=...), "
        f"got {type(result).__name__}"
    )


def test_v2_sync_push_dry_run(oid, key):
    """Push an empty config with dry_run=True and verify no changes are made."""
    client = Client(oid=oid, api_key=key)
    org = Organization(client)
    configs = Configs(org)

    # Push a minimal valid config in dry-run mode -- should not modify anything.
    empty_config = {"version": Configs.CONF_VERSION}
    result = configs.push(
        config=empty_config,
        is_dry_run=True,
        sync_outputs=True,
    )
    # push() returns a (changes, warnings) tuple.
    assert isinstance(result, tuple), (
        f"Expected tuple from configs.push(dry_run), got {type(result).__name__}"
    )
    changes, warnings = result
    assert isinstance(changes, list), (
        f"Expected list of changes, got {type(changes).__name__}"
    )
