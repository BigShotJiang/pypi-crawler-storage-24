import json
import pytest
from algoguard.report import Finding, Evidence, Severity, Category, Report


def _make_finding(sev=Severity.HIGH) -> Finding:
    return Finding(
        id="TEST-0001", title="Test finding", severity=sev, confidence=0.9,
        category=Category.SAST, description="A test finding", recommendation="Fix it",
        evidence=[Evidence(description="test", file_path="/tmp/foo.py", line_number=10)],
    )

def test_finding_to_dict():
    d = _make_finding().to_dict()
    assert d["id"] == "TEST-0001"
    assert d["severity"] == "HIGH"
    assert len(d["evidence"]) == 1

def test_report_summary():
    r = Report("test_target")
    r.add(_make_finding(Severity.CRITICAL))
    r.add(_make_finding(Severity.LOW))
    summary = r.summary()
    assert "CRITICAL" in summary and "LOW" in summary

def test_report_to_json():
    r = Report("proj")
    r.add(_make_finding())
    payload = json.loads(r.to_json())
    assert payload["target"] == "proj"
    assert len(payload["findings"]) == 1

def test_report_empty():
    assert "No findings" in Report("empty").summary()