from algoguard.utils.entropy import shannon_entropy, is_high_entropy

def test_low_entropy():
    assert shannon_entropy("aaaaaaaaaa") < 1.0

def test_high_entropy():
    assert shannon_entropy("aB3dE6fG9hI2jK5lM8nO1pQ4rS7tU0vW") > 4.0

def test_short_string():
    assert not is_high_entropy("aB3d", threshold=3.0, min_len=8)

def test_empty():
    assert shannon_entropy("") == 0.0