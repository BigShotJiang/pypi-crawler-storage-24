from algoguard.policy import Policy

def test_default():
    p = Policy.default()
    assert p.enable_sast and p.enable_secrets and not p.enable_runtime

def test_strict():
    p = Policy.strict()
    assert p.entropy_threshold < Policy.default().entropy_threshold
    assert p.enable_runtime

def test_fast():
    p = Policy.fast()
    assert not p.enable_artifact_scan and not p.enable_runtime

def test_allows_host():
    p = Policy(allowed_network_hosts={"api.example.com"})
    assert p.allows_host("api.example.com")
    assert not p.allows_host("evil.io")

def test_allows_write():
    p = Policy(allowed_write_paths=["/tmp", "/output"])
    assert p.allows_write("/tmp/file.txt")
    assert not p.allows_write("/etc/passwd")