import tempfile
from pathlib import Path
from algoguard import Auditor, Policy


def _proj(*files):
    d = tempfile.mkdtemp()
    for name, content in files:
        (Path(d) / name).write_text(content)
    return d


def test_clean_code_no_critical():
    root = _proj(("clean.py", "x = 1 + 2\nprint(x)\n"))
    policy = Policy.fast()
    policy.enable_secrets = False
    report = Auditor(policy).audit_path(root)
    assert not any(f.severity.value == "CRITICAL" for f in report.findings)


def test_detects_eval():
    root = _proj(("bad.py", "result = eval(user_input)\n"))
    report = Auditor(Policy.fast()).audit_path(root)
    assert any("eval" in f.title.lower() for f in report.findings)


def test_detects_secret():
    root = _proj(("creds.py", 'API_KEY = "AKIAIOSFODNN7EXAMPLE"\n'))
    policy = Policy.fast()
    policy.enable_secrets = True
    report = Auditor(policy).audit_path(root)
    assert any(f.category.value == "SECRET" for f in report.findings)


def test_callable_pickle():
    import pickle
    def unsafe(data):
        return pickle.loads(data)
    report = Auditor(Policy.fast()).audit_callable(unsafe)
    assert any("pickle" in f.title.lower() for f in report.findings)


def test_runtime_egress():
    import socket
    def leaky(x):
        try:
            s = socket.socket()
            s.connect(("198.51.100.1", 443))
        except Exception:
            pass
        return x
    policy = Policy.default()
    policy.enable_runtime = True
    report = Auditor(policy).audit_callable(leaky, sample_inputs=[1], runtime=True)
    assert any(f.category.value == "RUNTIME_EGRESS" for f in report.findings)


def test_json_roundtrip():
    import json
    root = _proj(("x.py", "eval('1+1')\n"))
    payload = json.loads(Auditor(Policy.fast()).audit_path(root).to_json())
    assert "findings" in payload