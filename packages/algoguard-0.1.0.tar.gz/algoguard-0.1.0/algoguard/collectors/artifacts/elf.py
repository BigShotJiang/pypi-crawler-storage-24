from __future__ import annotations
from pathlib import Path
from typing import List
from ...evidence.models import RawEvidence
from ...utils.strings import extract_strings, find_urls, find_ips
from ...utils.entropy import shannon_entropy

ELF_MAGIC = b"\x7fELF"
SUSPICIOUS_COMMANDS = [
    "curl", "wget", "nc ", "ncat", "bash", "sh -", "/bin/sh", "/bin/bash",
    "powershell", "cmd.exe", "chmod", "chown", "crontab", "dd if=", "mkfifo",
]


def is_elf(data: bytes) -> bool:
    return data[:4] == ELF_MAGIC


def collect_elf_evidence(path: Path) -> List[RawEvidence]:
    results: List[RawEvidence] = []
    try:
        data = path.read_bytes()
    except OSError:
        return results
    if not is_elf(data):
        return results

    results.append(RawEvidence(kind="elf_file", source=str(path), value=str(path), extra={"size": len(data)}))

    for s in extract_strings(data, min_len=6):
        ent = shannon_entropy(s)
        if ent >= 4.5 and len(s) >= 20:
            results.append(RawEvidence(kind="elf_high_entropy_string", source=str(path), value=s[:80], extra={"entropy": round(ent, 3)}))
        for url in find_urls(s):
            results.append(RawEvidence(kind="elf_url", source=str(path), value=url[:120]))
        for ip in find_ips(s):
            results.append(RawEvidence(kind="elf_ip", source=str(path), value=ip))
        for cmd in SUSPICIOUS_COMMANDS:
            if cmd in s:
                results.append(RawEvidence(kind="elf_suspicious_command", source=str(path), value=s[:120], extra={"trigger": cmd}))
                break
    return results