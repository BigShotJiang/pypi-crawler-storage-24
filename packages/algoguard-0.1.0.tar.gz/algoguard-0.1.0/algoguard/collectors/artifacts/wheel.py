from __future__ import annotations
import zipfile
from pathlib import Path
from typing import List
from ...evidence.models import RawEvidence
from ...utils.entropy import shannon_entropy
from ...utils.strings import extract_strings, find_urls, find_ips


def collect_wheel_evidence(path: Path) -> List[RawEvidence]:
    results: List[RawEvidence] = []
    if not zipfile.is_zipfile(path):
        return results
    try:
        with zipfile.ZipFile(path, "r") as zf:
            for name in zf.namelist():
                info = zf.getinfo(name)
                results.append(RawEvidence(kind="wheel_member", source=str(path), value=name, extra={"size": info.file_size}))
                lower = name.lower()
                if lower.endswith((".so", ".dll", ".dylib", ".pyd")):
                    data = zf.read(name)
                    results.extend(_scan_binary_bytes(str(path), name, data))
                elif lower.endswith(".py"):
                    text = zf.read(name).decode("utf-8", errors="replace")
                    results.extend(_scan_py_text(str(path), name, text))
    except zipfile.BadZipFile:
        results.append(RawEvidence(kind="wheel_bad_zip", source=str(path), value="Cannot open as zip"))
    return results


def _scan_binary_bytes(wheel: str, member: str, data: bytes) -> List[RawEvidence]:
    results = []
    for s in extract_strings(data, min_len=8):
        ent = shannon_entropy(s)
        if ent >= 4.5 and len(s) >= 20:
            results.append(RawEvidence(kind="binary_high_entropy_string", source=f"{wheel}::{member}", value=s[:80], extra={"entropy": round(ent, 3)}))
        for url in find_urls(s):
            results.append(RawEvidence(kind="binary_url", source=f"{wheel}::{member}", value=url[:120]))
        for ip in find_ips(s):
            results.append(RawEvidence(kind="binary_ip", source=f"{wheel}::{member}", value=ip))
    return results


def _scan_py_text(wheel: str, member: str, text: str) -> List[RawEvidence]:
    results = []
    dangerous = ("eval(", "exec(", "base64", "__import__", "subprocess")
    for lineno, line in enumerate(text.splitlines(), 1):
        for d in dangerous:
            if d in line:
                results.append(RawEvidence(kind="wheel_dangerous_code", source=f"{wheel}::{member}", line=lineno, value=line.strip()[:120], extra={"trigger": d}))
    return results