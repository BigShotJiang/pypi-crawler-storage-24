from __future__ import annotations
import re
from pathlib import Path
from typing import List
from ...evidence.models import RawEvidence
from ...utils.entropy import shannon_entropy

SECRET_PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    ("AWS Access Key",     re.compile(r"AKIA[0-9A-Z]{16}")),
    ("AWS Secret Key",     re.compile(r"(?i)aws.{0,20}secret.{0,20}['\"][0-9a-zA-Z/+]{40}['\"]")),
    ("GitHub Token",       re.compile(r"gh[pousr]_[A-Za-z0-9]{36,}")),
    ("Generic API Key",    re.compile(r"(?i)(api[_\-]?key|apikey)\s*[=:]\s*['\"]([A-Za-z0-9\-_]{20,})['\"]")),
    ("Bearer Token",       re.compile(r"(?i)bearer\s+[A-Za-z0-9\-_\.]{20,}")),
    ("Private Key Header", re.compile(r"-----BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY-----")),
    ("JWT Token",          re.compile(r"eyJ[A-Za-z0-9\-_]+\.eyJ[A-Za-z0-9\-_]+\.[A-Za-z0-9\-_]+")),
    ("Slack Token",        re.compile(r"xox[baprs]-[0-9A-Za-z\-]{10,}")),
    ("Stripe Key",         re.compile(r"sk_live_[0-9a-zA-Z]{24,}")),
    ("Google API Key",     re.compile(r"AIza[0-9A-Za-z\-_]{35}")),
    ("Generic Password",   re.compile(r"(?i)(password|passwd|pwd)\s*[=:]\s*['\"][^'\"]{6,}['\"]")),
    ("Database URL",       re.compile(r"(?i)(postgres|mysql|mongodb|redis)://[^\s\"'<>]{10,}")),
]

PLACEHOLDER_RE = re.compile(
    r"(placeholder|changeme|your[-_]?key|<.*?>|xxx+|todo|fixme)",
    re.IGNORECASE,
)


def _is_placeholder(value: str) -> bool:
    return bool(PLACEHOLDER_RE.search(value))


_STRING_LITERAL_RE = re.compile(r'''(?:["'])([^"'\n]{8,})(?:["'])''')


def _extract_string_literals(line: str) -> list[str]:
    return _STRING_LITERAL_RE.findall(line)


def collect_secrets(
    path: Path,
    entropy_threshold: float = 4.2,
    min_len: int = 16,
    allowlist: list[str] | None = None,
) -> List[RawEvidence]:
    allowlist = allowlist or []
    results: List[RawEvidence] = []

    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return results

    lines = text.splitlines()
    for lineno, line in enumerate(lines, start=1):
        stripped = line.strip()
        if stripped.startswith("#") or stripped.startswith("//"):
            continue

        for label, pattern in SECRET_PATTERNS:
            m = pattern.search(line)
            if m:
                matched = m.group(0)
                if matched in allowlist or _is_placeholder(matched):
                    continue
                results.append(RawEvidence(
                    kind="secret_pattern", source=str(path), line=lineno,
                    value=matched[:80], extra={"label": label, "snippet": stripped[:120]},
                ))

        for token in _extract_string_literals(line):
            if token in allowlist or _is_placeholder(token):
                continue
            if len(token) >= min_len and shannon_entropy(token) >= entropy_threshold:
                results.append(RawEvidence(
                    kind="high_entropy_string", source=str(path), line=lineno,
                    value=token[:80],
                    extra={"entropy": round(shannon_entropy(token), 3), "snippet": stripped[:120]},
                ))

    return results