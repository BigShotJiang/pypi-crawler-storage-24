from __future__ import annotations
import ast
from pathlib import Path
from typing import List
from ...evidence.models import RawEvidence


class _ASTCollector(ast.NodeVisitor):
    DANGEROUS_CALLS = {"eval", "exec", "compile", "__import__"}

    DANGEROUS_ATTRS = {
        ("pickle", "loads"), ("pickle", "load"),
        ("marshal", "loads"), ("marshal", "load"),
        ("yaml", "load"),
        ("subprocess", "call"), ("subprocess", "run"), ("subprocess", "Popen"),
        ("os", "system"), ("os", "popen"),
        ("shelve", "open"),
        ("dill", "loads"), ("dill", "load"),
    }

    SUSPICIOUS_IMPORTS = {"ctypes", "cffi", "ftplib", "telnetlib", "paramiko", "socket"}

    def __init__(self, source_path: str, source_code: str) -> None:
        self.path = source_path
        self.lines = source_code.splitlines()
        self.evidence: List[RawEvidence] = []

    def _snippet(self, node: ast.AST) -> str:
        try:
            return self.lines[node.lineno - 1].strip()
        except (AttributeError, IndexError):
            return ""

    def _add(self, kind: str, node: ast.AST, value: str, extra: dict | None = None) -> None:
        self.evidence.append(RawEvidence(
            kind=kind, source=self.path,
            line=getattr(node, "lineno", None),
            col=getattr(node, "col_offset", None),
            value=value, extra=extra or {},
        ))

    def visit_Call(self, node: ast.Call) -> None:
        func = node.func
        if isinstance(func, ast.Name) and func.id in self.DANGEROUS_CALLS:
            self._add("dangerous_call", node, func.id, {"snippet": self._snippet(node)})
        elif isinstance(func, ast.Attribute):
            obj_name = func.value.id if isinstance(func.value, ast.Name) else ""
            pair = (obj_name, func.attr)
            if pair in self.DANGEROUS_ATTRS:
                self._add("dangerous_call", node, f"{obj_name}.{func.attr}", {"snippet": self._snippet(node)})
            if func.attr in ("call", "run", "Popen", "check_output", "check_call"):
                for kw in node.keywords:
                    if kw.arg == "shell" and isinstance(kw.value, ast.Constant) and kw.value.value:
                        self._add("shell_true", node, f"{func.attr}(shell=True)", {"snippet": self._snippet(node)})
                        break
        if isinstance(func, ast.Name) and func.id in ("Popen", "call", "check_output"):
            for kw in node.keywords:
                if kw.arg == "shell" and isinstance(kw.value, ast.Constant) and kw.value.value:
                    self._add("shell_true", node, f"{func.id}(shell=True)", {"snippet": self._snippet(node)})
        self.generic_visit(node)

    def visit_Import(self, node: ast.Import) -> None:
        for alias in node.names:
            base = alias.name.split(".")[0]
            if base in self.SUSPICIOUS_IMPORTS:
                self._add("suspicious_import", node, alias.name, {"snippet": self._snippet(node)})
        self.generic_visit(node)

    def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
        module = node.module or ""
        if module.split(".")[0] in self.SUSPICIOUS_IMPORTS:
            self._add("suspicious_import", node, module, {"snippet": self._snippet(node)})
        self.generic_visit(node)

    def visit_Assign(self, node: ast.Assign) -> None:
        for child in ast.walk(node):
            if isinstance(child, ast.Call):
                func = child.func
                if isinstance(func, ast.Attribute) and func.attr in ("b64decode", "decodebytes"):
                    self._add("base64_decode_assign", node, "base64.b64decode assigned", {"snippet": self._snippet(node)})
                    break
        self.generic_visit(node)


def collect_ast_evidence(path: Path) -> List[RawEvidence]:
    try:
        source = path.read_text(encoding="utf-8", errors="replace")
        tree = ast.parse(source, filename=str(path))
    except SyntaxError:
        return []
    visitor = _ASTCollector(str(path), source)
    visitor.visit(tree)
    return visitor.evidence