from __future__ import annotations
import json
import re
from pathlib import Path
from typing import Any, Iterator, List, Tuple
from ...evidence.models import RawEvidence
from ...utils.entropy import shannon_entropy

_SENSITIVE_KEYS = re.compile(
    r"(?i)(password|passwd|secret|token|api[_\-]?key|private[_\-]?key|access[_\-]?key|auth|credential|client[_\-]?secret)"
)
_PLACEHOLDER = re.compile(r"(changeme|placeholder|your[-_]?|<|xxx+)", re.IGNORECASE)


def _is_sensitive_key(key: str) -> bool:
    return bool(_SENSITIVE_KEYS.search(key))


def _is_placeholder(v: str) -> bool:
    return bool(_PLACEHOLDER.search(v))


def _flatten(obj: Any, prefix: str = "") -> Iterator[Tuple[str, str]]:
    if isinstance(obj, dict):
        for k, v in obj.items():
            yield from _flatten(v, f"{prefix}.{k}" if prefix else k)
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            yield from _flatten(v, f"{prefix}[{i}]")
    elif isinstance(obj, (str, int, float, bool)):
        yield prefix, str(obj)


def _scan_env_file(path: Path) -> List[RawEvidence]:
    results: List[RawEvidence] = []
    try:
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return results
    for lineno, line in enumerate(lines, 1):
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or "=" not in stripped:
            continue
        key, _, value = stripped.partition("=")
        value = value.strip().strip("\"'")
        if not value or _is_placeholder(value):
            continue
        if _is_sensitive_key(key) or shannon_entropy(value) >= 4.0:
            results.append(RawEvidence(
                kind="config_secret", source=str(path), line=lineno,
                value=value[:80], extra={"key": key.strip(), "snippet": stripped[:120]},
            ))
    return results


def _scan_structured(path: Path) -> List[RawEvidence]:
    results: List[RawEvidence] = []
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return results

    obj: Any = None
    suffix = path.suffix.lower()
    try:
        if suffix == ".json":
            obj = json.loads(text)
        elif suffix in (".yaml", ".yml"):
            import yaml
            obj = yaml.safe_load(text)
        elif suffix == ".toml":
            try:
                import tomllib
                obj = tomllib.loads(text)
            except ImportError:
                import tomli
                obj = tomli.loads(text)
    except Exception:
        return results

    if obj is None:
        return results

    for dotted_key, value in _flatten(obj):
        if not value or _is_placeholder(value):
            continue
        if _is_sensitive_key(dotted_key) and len(value) >= 6:
            results.append(RawEvidence(
                kind="config_secret", source=str(path), line=None,
                value=value[:80], extra={"key": dotted_key},
            ))
        elif len(value) >= 20 and shannon_entropy(value) >= 4.2:
            results.append(RawEvidence(
                kind="config_high_entropy", source=str(path), line=None,
                value=value[:80], extra={"key": dotted_key, "entropy": round(shannon_entropy(value), 3)},
            ))
    return results


def collect_config_secrets(path: Path) -> List[RawEvidence]:
    name = path.name.lower()
    if name == ".env" or path.suffix.lower() == ".env":
        return _scan_env_file(path)
    return _scan_structured(path)