from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Set


@dataclass
class Policy:
    entropy_threshold: float = 4.2
    secret_min_length: int = 16
    allowed_network_hosts: Set[str] = field(default_factory=set)
    allowed_write_paths: List[str] = field(default_factory=lambda: ["/tmp"])
    enable_sast: bool = True
    enable_secrets: bool = True
    enable_config_scan: bool = True
    enable_artifact_scan: bool = True
    enable_runtime: bool = False
    secret_allowlist: List[str] = field(default_factory=list)
    min_severity: str = "INFO"
    extra_extensions: List[str] = field(default_factory=list)

    @classmethod
    def default(cls) -> "Policy":
        return cls()

    @classmethod
    def strict(cls) -> "Policy":
        return cls(entropy_threshold=3.8, secret_min_length=12, enable_runtime=True)

    @classmethod
    def fast(cls) -> "Policy":
        return cls(entropy_threshold=4.8, enable_artifact_scan=False, enable_runtime=False, min_severity="MEDIUM")

    def allows_host(self, host: str) -> bool:
        return host in self.allowed_network_hosts

    def allows_write(self, path: str) -> bool:
        return any(path.startswith(p) for p in self.allowed_write_paths)