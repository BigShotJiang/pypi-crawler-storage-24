from __future__ import annotations
from typing import List
from ...evidence.store import EvidenceStore
from ...report import Evidence, Finding, Severity, Category

_COUNTER = 0

def _fid() -> str:
    global _COUNTER
    _COUNTER += 1
    return f"OBF-{_COUNTER:04d}"


def detect_obfuscation(store: EvidenceStore) -> List[Finding]:
    findings: List[Finding] = []

    for ev in store.by_kind("base64_decode_assign"):
        findings.append(Finding(
            id=_fid(), title="Base64 decode assigned to variable – possible obfuscation",
            severity=Severity.HIGH, confidence=0.7, category=Category.OBFUSCATION,
            description=f"A base64.b64decode() call is assigned in {ev.source}:{ev.line}. Combined with exec/eval this is a classic backdoor pattern.",
            recommendation="Audit the decoded payload. Replace with explicit, readable code.",
            evidence=[Evidence(description="base64 decode assignment", file_path=ev.source, line_number=ev.line, snippet=ev.extra.get("snippet", ""))],
            tags=["obfuscation", "backdoor-indicator"],
        ))

    for ev in store.by_kind("high_entropy_string"):
        ent = ev.extra.get("entropy", 0)
        if ent >= 5.0 and len(ev.value or "") >= 32:
            findings.append(Finding(
                id=_fid(), title="Very high-entropy string constant – possible encrypted payload",
                severity=Severity.MEDIUM, confidence=0.6, category=Category.OBFUSCATION,
                description=f"String with entropy {ent:.2f} bits/char found in {ev.source}:{ev.line}. May be embedded encrypted payload.",
                recommendation="Verify the purpose of this constant. Avoid embedding binary/encrypted blobs in source.",
                evidence=[Evidence(description=f"High entropy string (entropy={ent:.2f})", file_path=ev.source, line_number=ev.line, snippet=ev.extra.get("snippet", ""), extra={"entropy": ent})],
                tags=["obfuscation", "high-entropy"],
            ))

    return findings