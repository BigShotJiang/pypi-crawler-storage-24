from __future__ import annotations
from typing import List
from ...evidence.store import EvidenceStore
from ...report import Evidence, Finding, Severity, Category

_COUNTER = 0

def _fid() -> str:
    global _COUNTER
    _COUNTER += 1
    return f"SEC-{_COUNTER:04d}"


def detect_secrets(store: EvidenceStore) -> List[Finding]:
    findings: List[Finding] = []

    for ev in store.by_kind("secret_pattern"):
        label = ev.extra.get("label", "Secret")
        findings.append(Finding(
            id=_fid(), title=f"Hardcoded {label} detected",
            severity=Severity.HIGH, confidence=0.85, category=Category.SECRET,
            description=f"{label} detected at {ev.source}:{ev.line}. Hardcoded credentials are easily exposed via source control.",
            recommendation="Remove the credential immediately. Rotate it if already committed. Use environment variables or a secrets manager.",
            evidence=[Evidence(
                description=f"Pattern match: {label}", file_path=ev.source, line_number=ev.line,
                snippet=ev.extra.get("snippet", ""),
                extra={"matched_value": (ev.value[:20] + "…") if ev.value and len(ev.value) > 20 else ev.value},
            )],
            tags=["secret", "credential", "hardcoded"],
        ))

    for ev in store.by_kind("high_entropy_string"):
        ent = ev.extra.get("entropy", 0)
        findings.append(Finding(
            id=_fid(), title="High-entropy string – possible secret",
            severity=Severity.MEDIUM, confidence=0.6, category=Category.SECRET,
            description=f"A string with entropy {ent:.2f} bits/char found at {ev.source}:{ev.line}.",
            recommendation="Review this string. If it is a secret, move it to an environment variable or secrets manager.",
            evidence=[Evidence(description=f"High entropy string (entropy={ent:.2f})", file_path=ev.source, line_number=ev.line, snippet=ev.extra.get("snippet", ""), extra={"entropy": ent})],
            tags=["secret", "high-entropy"],
        ))

    for ev in store.by_kind("config_secret"):
        key = ev.extra.get("key", "")
        findings.append(Finding(
            id=_fid(), title=f"Sensitive value in config file: {key}",
            severity=Severity.HIGH, confidence=0.8, category=Category.SECRET,
            description=f"Config key `{key}` has a sensitive-looking value in {ev.source}.",
            recommendation="Move secrets out of config files. Use environment variables or a secrets management solution.",
            evidence=[Evidence(description=f"Config key: {key}", file_path=ev.source, line_number=ev.line, extra={"key": key})],
            tags=["secret", "config"],
        ))

    return findings