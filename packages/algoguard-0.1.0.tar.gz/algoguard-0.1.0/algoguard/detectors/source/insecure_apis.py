from __future__ import annotations
from typing import List
from ...evidence.store import EvidenceStore
from ...report import Evidence, Finding, Severity, Category

_COUNTER = 0

def _fid(prefix: str) -> str:
    global _COUNTER
    _COUNTER += 1
    return f"{prefix}-{_COUNTER:04d}"

_CALL_RULES: dict[str, tuple] = {
    "eval":         (Severity.HIGH,     0.9,  "Use of eval()",                              "Replace eval() with ast.literal_eval() for safe expression parsing."),
    "exec":         (Severity.HIGH,     0.9,  "Use of exec()",                              "Avoid exec() – use explicit function dispatch or importlib instead."),
    "compile":      (Severity.MEDIUM,   0.7,  "Use of compile()",                           "Verify inputs are not user-controlled."),
    "__import__":   (Severity.MEDIUM,   0.75, "Dynamic __import__() call",                  "Use importlib.import_module() with an allowlist instead."),
    "pickle.loads": (Severity.CRITICAL, 0.95, "Insecure deserialization via pickle.loads()", "Never deserialize pickle from untrusted sources. Use JSON or protobuf."),
    "pickle.load":  (Severity.CRITICAL, 0.95, "Insecure deserialization via pickle.load()",  "Replace pickle with a safe serialization format."),
    "yaml.load":    (Severity.HIGH,     0.9,  "Unsafe yaml.load() – arbitrary code execution possible", "Replace with yaml.safe_load()."),
    "marshal.loads":(Severity.HIGH,     0.85, "Use of marshal.loads()",                     "Use JSON instead of marshal."),
    "dill.loads":   (Severity.CRITICAL, 0.9,  "Insecure deserialization via dill.loads()",  "dill can execute arbitrary code. Avoid or restrict inputs."),
    "os.system":    (Severity.HIGH,     0.9,  "Shell injection risk via os.system()",       "Use subprocess.run(args_list, shell=False)."),
    "os.popen":     (Severity.HIGH,     0.85, "Shell injection risk via os.popen()",        "Replace with subprocess.run(shell=False)."),
}

_SUSPICIOUS_IMPORT_RULES: dict[str, tuple] = {
    "ctypes":   (Severity.MEDIUM, 0.6,  "Import of ctypes – low-level memory access",     "Ensure ctypes is necessary; it bypasses Python safety checks."),
    "ftplib":   (Severity.MEDIUM, 0.65, "Import of ftplib – plaintext file transfer",      "Consider SFTP or HTTPS instead."),
    "telnetlib":(Severity.MEDIUM, 0.7,  "Import of telnetlib – deprecated plaintext protocol", "Use SSH (paramiko) or encrypted alternatives."),
    "paramiko": (Severity.LOW,    0.5,  "Import of paramiko – SSH client",                 "Verify SSH connections are expected; flag for manual review."),
}


def detect_insecure_apis(store: EvidenceStore) -> List[Finding]:
    findings: List[Finding] = []

    for ev in store.by_kind("dangerous_call"):
        rule = _CALL_RULES.get(ev.value or "")
        if not rule:
            continue
        severity, confidence, title, recommendation = rule
        findings.append(Finding(
            id=_fid("SAST"), title=title, severity=severity, confidence=confidence,
            category=Category.SAST,
            description=f"Detected call to `{ev.value}` in {ev.source}",
            recommendation=recommendation,
            evidence=[Evidence(description=f"Call at line {ev.line}", file_path=ev.source, line_number=ev.line, snippet=ev.extra.get("snippet", ""))],
            tags=["insecure-api", "sast"],
        ))

    for ev in store.by_kind("shell_true"):
        findings.append(Finding(
            id=_fid("SAST"), title="subprocess call with shell=True",
            severity=Severity.HIGH, confidence=0.9, category=Category.SAST,
            description=f"subprocess called with shell=True in {ev.source}:{ev.line}",
            recommendation="Pass a list of arguments and set shell=False to prevent shell injection.",
            evidence=[Evidence(description="shell=True usage", file_path=ev.source, line_number=ev.line, snippet=ev.extra.get("snippet", ""))],
            tags=["shell-injection", "sast"],
        ))

    for ev in store.by_kind("suspicious_import"):
        module = ev.value or ""
        rule = _SUSPICIOUS_IMPORT_RULES.get(module.split(".")[0])
        if not rule:
            continue
        severity, confidence, title, recommendation = rule
        findings.append(Finding(
            id=_fid("SAST"), title=title, severity=severity, confidence=confidence,
            category=Category.SAST,
            description=f"Module `{module}` imported in {ev.source}:{ev.line}",
            recommendation=recommendation,
            evidence=[Evidence(description=f"import at line {ev.line}", file_path=ev.source, line_number=ev.line, snippet=ev.extra.get("snippet", ""))],
            tags=["suspicious-import", "sast"],
        ))

    return findings