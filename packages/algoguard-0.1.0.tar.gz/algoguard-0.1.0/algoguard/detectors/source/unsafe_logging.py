from __future__ import annotations
import ast
from pathlib import Path
from typing import List
from ...evidence.store import EvidenceStore
from ...report import Evidence, Finding, Severity, Category

_COUNTER = 0

def _fid() -> str:
    global _COUNTER
    _COUNTER += 1
    return f"LOG-{_COUNTER:04d}"

_SENSITIVE_TOKENS = {
    "password", "passwd", "secret", "token", "api_key", "apikey",
    "private_key", "access_key", "credential", "auth", "jwt", "os.environ", "environ",
}


def _get_func_name(node: ast.expr) -> str | None:
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        return node.attr
    return None


def _attr_chain(node: ast.Attribute) -> str:
    parts = [node.attr]
    val = node.value
    while isinstance(val, ast.Attribute):
        parts.append(val.attr)
        val = val.value
    if isinstance(val, ast.Name):
        parts.append(val.id)
    return ".".join(reversed(parts))


class _LoggingVisitor(ast.NodeVisitor):
    def __init__(self, source: str, lines: list[str]) -> None:
        self.source = source
        self.lines = lines
        self.findings: List[Finding] = []

    def _snippet(self, node: ast.AST) -> str:
        try:
            return self.lines[node.lineno - 1].strip()
        except (AttributeError, IndexError):
            return ""

    def visit_Call(self, node: ast.Call) -> None:
        func_name = _get_func_name(node.func)
        log_funcs = {"print", "debug", "info", "warning", "error", "critical"}
        if func_name and func_name in log_funcs:
            for arg in node.args:
                self._check_arg(node, arg)
            for kw in node.keywords:
                self._check_arg(node, kw.value)
        self.generic_visit(node)

    def _check_arg(self, call_node: ast.AST, arg: ast.expr) -> None:
        for child in ast.walk(arg):
            if isinstance(child, ast.Name) and child.id.lower() in _SENSITIVE_TOKENS:
                self.findings.append(Finding(
                    id=_fid(), title="Potential logging of sensitive variable",
                    severity=Severity.MEDIUM, confidence=0.65, category=Category.UNSAFE_LOGGING,
                    description=f"Variable `{child.id}` passed to a logging/print call in {self.source}:{getattr(call_node, 'lineno', '?')}",
                    recommendation="Redact or mask sensitive values before logging.",
                    evidence=[Evidence(description="Logging of sensitive variable", file_path=self.source, line_number=getattr(call_node, "lineno", None), snippet=self._snippet(call_node))],
                    tags=["unsafe-logging", "data-leak"],
                ))
                return
            if isinstance(child, ast.Attribute):
                chain = _attr_chain(child)
                if any(tok in chain.lower() for tok in _SENSITIVE_TOKENS):
                    self.findings.append(Finding(
                        id=_fid(), title="Potential logging of sensitive attribute",
                        severity=Severity.MEDIUM, confidence=0.6, category=Category.UNSAFE_LOGGING,
                        description=f"Attribute `{chain}` passed to logging in {self.source}:{getattr(call_node, 'lineno', '?')}",
                        recommendation="Redact sensitive fields before logging.",
                        evidence=[Evidence(description="Logging of sensitive attribute", file_path=self.source, line_number=getattr(call_node, "lineno", None), snippet=self._snippet(call_node))],
                        tags=["unsafe-logging", "data-leak"],
                    ))
                    return


def detect_unsafe_logging_in_file(path: Path) -> List[Finding]:
    try:
        source = path.read_text(encoding="utf-8", errors="replace")
        tree = ast.parse(source, filename=str(path))
    except SyntaxError:
        return []
    visitor = _LoggingVisitor(str(path), source.splitlines())
    visitor.visit(tree)
    return visitor.findings


def detect_unsafe_logging(store: EvidenceStore) -> List[Finding]:
    return []