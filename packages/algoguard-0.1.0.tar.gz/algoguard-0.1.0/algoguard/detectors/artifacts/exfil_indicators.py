from __future__ import annotations
import re
from typing import List
from ...evidence.store import EvidenceStore
from ...report import Evidence, Finding, Severity, Category

_COUNTER = 0

def _fid() -> str:
    global _COUNTER
    _COUNTER += 1
    return f"EXFIL-{_COUNTER:04d}"

_SUSPICIOUS_URL_RE = re.compile(
    r"(pastebin\.com|requestbin|webhook\.site|ngrok\.io|bit\.ly|tinyurl|burpcollaborator)",
    re.IGNORECASE,
)
_PRIVATE_IP_RE = re.compile(r"^(10\.|172\.(1[6-9]|2\d|3[01])\.|192\.168\.)")
_LOOPBACK_RE = re.compile(r"^127\.")


def detect_exfil_indicators(store: EvidenceStore) -> List[Finding]:
    findings: List[Finding] = []

    for ev in store.all():
        if ev.kind not in {"binary_url", "elf_url"}:
            continue
        url = ev.value or ""
        if _SUSPICIOUS_URL_RE.search(url):
            findings.append(Finding(
                id=_fid(), title="Suspicious URL in binary artifact",
                severity=Severity.HIGH, confidence=0.8, category=Category.BINARY_SUSPICIOUS,
                description=f"URL `{url[:80]}` in binary {ev.source}. Commonly used for data exfiltration or C2.",
                recommendation="Audit why this URL is embedded. Treat binary as potentially compromised if not intentional.",
                evidence=[Evidence(description="Suspicious URL in binary", file_path=ev.source, extra={"url": url})],
                tags=["exfil", "binary", "c2"],
            ))

    for ev in store.by_kind("elf_suspicious_command"):
        findings.append(Finding(
            id=_fid(), title=f"Suspicious shell command in binary: {ev.extra.get('trigger', '')}",
            severity=Severity.HIGH, confidence=0.75, category=Category.BINARY_SUSPICIOUS,
            description=f"Binary `{ev.source}` contains `{ev.value[:60]}` – may indicate a backdoor.",
            recommendation="Disassemble or sandbox the binary to confirm intent.",
            evidence=[Evidence(description="Suspicious command string", file_path=ev.source, extra={"string": ev.value, "trigger": ev.extra.get("trigger", "")})],
            tags=["binary", "backdoor-indicator"],
        ))

    for ev in store.by_kind("binary_ip"):
        ip = ev.value or ""
        if _PRIVATE_IP_RE.match(ip) or _LOOPBACK_RE.match(ip):
            continue
        findings.append(Finding(
            id=_fid(), title=f"Hardcoded IP address in artifact: {ip}",
            severity=Severity.MEDIUM, confidence=0.65, category=Category.BINARY_SUSPICIOUS,
            description=f"Hardcoded IP `{ip}` in `{ev.source}`. May be a C2 server or telemetry endpoint.",
            recommendation="Verify the IP is intentional and document it.",
            evidence=[Evidence(description="Hardcoded IP", file_path=ev.source, extra={"ip": ip})],
            tags=["binary", "hardcoded-ip"],
        ))

    return findings


def detect_packed_binary(store: EvidenceStore) -> List[Finding]:
    findings: List[Finding] = []
    for ev in store.by_kind("binary_high_entropy_string"):
        ent = ev.extra.get("entropy", 0)
        if ent >= 5.5:
            findings.append(Finding(
                id=_fid(), title="Extremely high-entropy region in binary – possibly packed/encrypted",
                severity=Severity.MEDIUM, confidence=0.65, category=Category.BINARY_SUSPICIOUS,
                description=f"String with entropy {ent:.2f} in `{ev.source}`. Packed or encrypted sections can hide malicious code.",
                recommendation="Use a binary analyzer (Detect-It-Easy, Capa) for deeper analysis.",
                evidence=[Evidence(description=f"High entropy string (entropy={ent:.2f})", file_path=ev.source, extra={"entropy": ent, "snippet": ev.value[:80]})],
                tags=["binary", "packing", "obfuscation"],
            ))
    return findings