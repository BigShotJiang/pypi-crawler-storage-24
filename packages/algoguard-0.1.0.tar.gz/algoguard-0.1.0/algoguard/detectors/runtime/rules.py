from __future__ import annotations
from typing import Any, List
from ...evidence.models import RawEvidence
from ...report import Evidence, Finding, Severity, Category

_COUNTER = 0

def _fid(prefix: str) -> str:
    global _COUNTER
    _COUNTER += 1
    return f"{prefix}-{_COUNTER:04d}"

_SUSPICIOUS_CMDS = {"curl", "wget", "nc", "ncat", "bash", "sh", "powershell", "cmd"}


def analyze_runtime_events(events: List[RawEvidence], policy: Any) -> List[Finding]:
    findings: List[Finding] = []

    for ev in events:
        if ev.kind == "runtime_network":
            host = ev.extra.get("host", "")
            port = ev.extra.get("port", 0)
            allowed = ev.extra.get("allowed", False)
            findings.append(Finding(
                id=_fid("RT-NET"),
                title=f"Outbound network connection to {host}:{port}",
                severity=Severity.INFO if allowed else Severity.HIGH,
                confidence=0.95, category=Category.RUNTIME_EGRESS,
                description=f"The callable attempted to connect to `{host}:{port}`. {'Allowlisted.' if allowed else 'NOT allowlisted.'}",
                recommendation="Verify this connection is expected. Add to policy.allowed_network_hosts if legitimate.",
                evidence=[Evidence(description=f"socket.connect({host}:{port})", extra={"stacktrace": ev.extra.get("stacktrace", "")[:300]})],
                tags=["runtime", "network", "egress"],
            ))

        elif ev.kind == "runtime_subprocess":
            cmd = ev.value or ""
            shell = ev.extra.get("shell", False)
            is_suspicious = any(s in cmd for s in _SUSPICIOUS_CMDS)
            findings.append(Finding(
                id=_fid("RT-PROC"),
                title=f"Subprocess spawned: {cmd[:60]}",
                severity=Severity.CRITICAL if (is_suspicious or shell) else Severity.MEDIUM,
                confidence=0.9, category=Category.RUNTIME_PROCESS,
                description=f"Subprocess: `{cmd[:100]}`. shell={'True' if shell else 'False'}.",
                recommendation="Review subprocess calls. Avoid shell=True. Ensure arguments are not user-controlled.",
                evidence=[Evidence(description="Subprocess execution", extra={"cmd": cmd[:200], "shell": shell, "stacktrace": ev.extra.get("stacktrace", "")[:300]})],
                tags=["runtime", "process", "subprocess"],
            ))

        elif ev.kind == "runtime_file_write":
            path = ev.value or ""
            allowed = ev.extra.get("allowed", False)
            findings.append(Finding(
                id=_fid("RT-FS"),
                title=f"File write to: {path}",
                severity=Severity.INFO if allowed else Severity.MEDIUM,
                confidence=0.85, category=Category.RUNTIME_FILESYSTEM,
                description=f"Write to `{path}`. {'Allowlisted.' if allowed else 'NOT in allowlist.'}",
                recommendation="Verify file writes are expected. Restrict to policy.allowed_write_paths.",
                evidence=[Evidence(description=f"File write: {path}", file_path=path, extra={"stacktrace": ev.extra.get("stacktrace", "")[:300]})],
                tags=["runtime", "filesystem"],
            ))

        elif ev.kind == "runtime_import":
            module = ev.value or ""
            findings.append(Finding(
                id=_fid("RT-IMP"),
                title=f"Runtime import of risky module: {module}",
                severity=Severity.LOW, confidence=0.5, category=Category.RUNTIME_IMPORT,
                description=f"Module `{module}` was imported at runtime during execution.",
                recommendation="Verify the runtime import is necessary and expected.",
                evidence=[Evidence(description=f"Runtime import: {module}", extra={"stacktrace": ev.extra.get("stacktrace", "")[:300]})],
                tags=["runtime", "import"],
            ))

    return findings