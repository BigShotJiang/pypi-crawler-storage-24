from __future__ import annotations
import socket as _socket_module
import subprocess as _subprocess_module
import builtins
import traceback
from typing import Any, List
from ...evidence.models import RawEvidence


class RuntimeMonitor:
    """
    Monkeypatches stdlib to intercept suspicious calls.
    Use as a context manager.

        with RuntimeMonitor(policy) as mon:
            callable_under_test(*args)
        events = mon.events
    """

    def __init__(self, policy: Any) -> None:
        self.policy = policy
        self.events: List[RawEvidence] = []
        self._originals: dict[str, Any] = {}

    def __enter__(self) -> "RuntimeMonitor":
        self._patch_network()
        self._patch_subprocess()
        self._patch_filesystem()
        self._patch_imports()
        return self

    def __exit__(self, *args: Any) -> None:
        self._restore()

    def _record(self, kind: str, value: str, extra: dict | None = None) -> None:
        stack = "".join(traceback.format_stack()[:-2])
        self.events.append(RawEvidence(
            kind=kind, source="<runtime>", value=value,
            extra={**(extra or {}), "stacktrace": stack[-500:]},
        ))

    def _patch_network(self) -> None:
        monitor = self
        OrigConnect = _socket_module.socket.connect

        def _connect(self_sock: Any, address: Any) -> Any:
            host = address[0] if isinstance(address, (tuple, list)) else str(address)
            port = address[1] if isinstance(address, (tuple, list)) and len(address) > 1 else 0
            monitor._record("runtime_network", f"{host}:{port}",
                            {"host": host, "port": port, "allowed": monitor.policy.allows_host(host)})
            return OrigConnect(self_sock, address)

        self._originals["socket.connect"] = OrigConnect
        _socket_module.socket.connect = _connect  # type: ignore

    def _patch_subprocess(self) -> None:
        monitor = self
        OrigPopen = _subprocess_module.Popen

        class _PatchedPopen(OrigPopen):  # type: ignore
            def __init__(self_, *args: Any, **kwargs: Any) -> None:
                cmd = args[0] if args else kwargs.get("args", "")
                shell = kwargs.get("shell", False)
                monitor._record("runtime_subprocess", str(cmd)[:200], {"shell": shell})
                super().__init__(*args, **kwargs)

        self._originals["subprocess.Popen"] = OrigPopen
        _subprocess_module.Popen = _PatchedPopen

    def _patch_filesystem(self) -> None:
        monitor = self
        _orig_open = builtins.open

        def _open(file: Any, mode: str = "r", *args: Any, **kwargs: Any) -> Any:
            if "w" in str(mode) or "a" in str(mode):
                path = str(file)
                monitor._record("runtime_file_write", path,
                                {"mode": mode, "allowed": monitor.policy.allows_write(path)})
            return _orig_open(file, mode, *args, **kwargs)

        self._originals["builtins.open"] = _orig_open
        builtins.open = _open  # type: ignore

    def _patch_imports(self) -> None:
        monitor = self
        _orig_import = builtins.__import__
        _RISKY = {"ctypes", "ftplib", "telnetlib", "socket", "subprocess", "paramiko", "dill", "pickle"}

        def _import(name: str, *args: Any, **kwargs: Any) -> Any:
            if name.split(".")[0] in _RISKY:
                monitor._record("runtime_import", name)
            return _orig_import(name, *args, **kwargs)

        self._originals["builtins.__import__"] = _orig_import
        builtins.__import__ = _import  # type: ignore

    def _restore(self) -> None:
        if "socket.connect" in self._originals:
            _socket_module.socket.connect = self._originals["socket.connect"]
        if "subprocess.Popen" in self._originals:
            _subprocess_module.Popen = self._originals["subprocess.Popen"]
        if "builtins.open" in self._originals:
            builtins.open = self._originals["builtins.open"]
        if "builtins.__import__" in self._originals:
            builtins.__import__ = self._originals["builtins.__import__"]