from __future__ import annotations
from typing import Any, Callable, List, Optional
from ..evidence.models import RawEvidence
from ..detectors.runtime.sandbox import RuntimeMonitor


def run_callable(
    fn: Callable[..., Any],
    sample_inputs: list[Any],
    policy: Any,
) -> tuple[List[RawEvidence], Optional[Exception]]:
    all_events: List[RawEvidence] = []
    error: Optional[Exception] = None

    with RuntimeMonitor(policy) as monitor:
        for inp in sample_inputs:
            try:
                if isinstance(inp, (list, tuple)):
                    fn(*inp)
                elif isinstance(inp, dict):
                    fn(**inp)
                else:
                    fn(inp)
            except Exception as exc:
                error = exc
                continue

    all_events.extend(monitor.events)
    return all_events, error