from __future__ import annotations
from typing import List
from .models import RawEvidence


class EvidenceStore:
    def __init__(self) -> None:
        self._items: List[RawEvidence] = []

    def add(self, item: RawEvidence) -> None:
        self._items.append(item)

    def add_many(self, items: List[RawEvidence]) -> None:
        self._items.extend(items)

    def by_kind(self, kind: str) -> List[RawEvidence]:
        return [i for i in self._items if i.kind == kind]

    def all(self) -> List[RawEvidence]:
        return list(self._items)

    def __len__(self) -> int:
        return len(self._items)