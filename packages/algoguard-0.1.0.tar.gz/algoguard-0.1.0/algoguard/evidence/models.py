from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Dict, Optional


@dataclass
class RawEvidence:
    kind: str
    source: str
    line: Optional[int] = None
    col: Optional[int] = None
    value: Optional[str] = None
    extra: Dict[str, Any] = field(default_factory=dict)