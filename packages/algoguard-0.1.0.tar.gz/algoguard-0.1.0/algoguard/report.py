from __future__ import annotations
import json
import datetime
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any, Dict, List, Optional


class Severity(str, Enum):
    CRITICAL = "CRITICAL"
    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"
    INFO = "INFO"


class Category(str, Enum):
    SECRET = "SECRET"
    SAST = "SAST"
    UNSAFE_LOGGING = "UNSAFE_LOGGING"
    OBFUSCATION = "OBFUSCATION"
    RUNTIME_EGRESS = "RUNTIME_EGRESS"
    RUNTIME_PROCESS = "RUNTIME_PROCESS"
    RUNTIME_FILESYSTEM = "RUNTIME_FILESYSTEM"
    RUNTIME_IMPORT = "RUNTIME_IMPORT"
    BINARY_SUSPICIOUS = "BINARY_SUSPICIOUS"
    DEPENDENCY = "DEPENDENCY"
    CONFIG = "CONFIG"


@dataclass
class Evidence:
    description: str
    file_path: Optional[str] = None
    line_number: Optional[int] = None
    snippet: Optional[str] = None
    extra: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {k: v for k, v in asdict(self).items() if v is not None and v != {}}


@dataclass
class Finding:
    id: str
    title: str
    severity: Severity
    confidence: float
    category: Category
    description: str
    recommendation: str
    evidence: List[Evidence] = field(default_factory=list)
    tags: List[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "title": self.title,
            "severity": self.severity.value,
            "confidence": round(self.confidence, 2),
            "category": self.category.value,
            "description": self.description,
            "recommendation": self.recommendation,
            "evidence": [e.to_dict() for e in self.evidence],
            "tags": self.tags,
        }


class Report:
    def __init__(self, target: str):
        self.target = target
        self.generated_at = datetime.datetime.now(datetime.timezone.utc).isoformat().replace("+00:00", "Z")
        self.findings: List[Finding] = []
        self.metadata: Dict[str, Any] = {}

    def add(self, finding: Finding) -> None:
        self.findings.append(finding)

    def add_many(self, findings: List[Finding]) -> None:
        self.findings.extend(findings)

    def _counts(self) -> Dict[str, int]:
        counts: Dict[str, int] = {s.value: 0 for s in Severity}
        for f in self.findings:
            counts[f.severity.value] += 1
        return counts

    def summary(self) -> str:
        counts = self._counts()
        lines = [
            "AlgoGuard Audit Report",
            f"Target : {self.target}",
            f"Date   : {self.generated_at}",
            f"Findings: {len(self.findings)} total",
        ]
        for sev in Severity:
            n = counts[sev.value]
            if n:
                lines.append(f"  {sev.value:<10}: {n}")
        if not self.findings:
            lines.append("  ✅  No findings detected.")
        else:
            lines.append("\nTop findings:")
            ordered = sorted(self.findings, key=lambda f: list(Severity).index(f.severity))
            for f in ordered[:10]:
                ev_hint = ""
                if f.evidence:
                    e = f.evidence[0]
                    parts = []
                    if e.file_path:
                        parts.append(e.file_path)
                    if e.line_number:
                        parts.append(f"L{e.line_number}")
                    ev_hint = " — " + ":".join(parts) if parts else ""
                lines.append(f"  [{f.severity.value}] {f.title}{ev_hint}")
        return "\n".join(lines)

    def to_dict(self) -> dict:
        return {
            "target": self.target,
            "generated_at": self.generated_at,
            "metadata": self.metadata,
            "summary": self._counts(),
            "findings": [f.to_dict() for f in self.findings],
        }

    def to_json(self, path: Optional[str] = None, indent: int = 2) -> str:
        payload = json.dumps(self.to_dict(), indent=indent)
        if path:
            with open(path, "w") as fh:
                fh.write(payload)
        return payload

    def __repr__(self) -> str:
        return f"<Report target={self.target!r} findings={len(self.findings)}>"