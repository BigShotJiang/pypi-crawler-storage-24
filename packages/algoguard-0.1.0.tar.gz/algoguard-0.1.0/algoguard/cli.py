from __future__ import annotations
import argparse
import sys
from .auditor import Auditor
from .policy import Policy


def main() -> None:
    parser = argparse.ArgumentParser(prog="algoguard", description="AlgoGuard – Security auditor for Python projects")
    parser.add_argument("path", help="Path to project directory or Python file")
    parser.add_argument("--policy", choices=["default", "strict", "fast"], default="default")
    parser.add_argument("--json", metavar="OUTPUT", help="Write JSON report to this file")
    parser.add_argument("--min-severity", choices=["INFO", "LOW", "MEDIUM", "HIGH", "CRITICAL"], default=None)
    args = parser.parse_args()

    policy = {"default": Policy.default, "strict": Policy.strict, "fast": Policy.fast}[args.policy]()
    if args.min_severity:
        policy.min_severity = args.min_severity

    print(f"[AlgoGuard] Auditing: {args.path}  (policy={args.policy})")
    report = Auditor(policy=policy).audit_path(args.path)
    print()
    print(report.summary())

    if args.json:
        report.to_json(args.json)
        print(f"\n[AlgoGuard] JSON report written to: {args.json}")

    critical_or_high = sum(1 for f in report.findings if f.severity.value in ("CRITICAL", "HIGH"))
    sys.exit(1 if critical_or_high else 0)


if __name__ == "__main__":
    main()