from __future__ import annotations
import inspect
from pathlib import Path
from typing import Any, Callable, List, Optional

from .policy import Policy
from .report import Report, Severity
from .evidence.store import EvidenceStore
from .utils.filewalk import walk_source, walk_configs
from .collectors.source.python_ast import collect_ast_evidence
from .collectors.source.secrets import collect_secrets
from .collectors.source.configs import collect_config_secrets
from .collectors.artifacts.wheel import collect_wheel_evidence
from .collectors.artifacts.elf import collect_elf_evidence
from .detectors.source.insecure_apis import detect_insecure_apis
from .detectors.source.unsafe_logging import detect_unsafe_logging_in_file
from .detectors.source.obfuscation import detect_obfuscation
from .detectors.source.secrets_detector import detect_secrets
from .detectors.artifacts.exfil_indicators import detect_exfil_indicators, detect_packed_binary
from .detectors.runtime.rules import analyze_runtime_events


class Auditor:
    def __init__(self, policy: Optional[Policy] = None) -> None:
        self.policy = policy or Policy.default()

    def audit_path(self, path: str | Path) -> Report:
        root = Path(path).resolve()
        report = Report(target=str(root))
        store = EvidenceStore()
        if root.is_file():
            self._audit_single_file(root, store)
        else:
            self._audit_directory(root, store)
        self._run_detectors(store, report)
        self._apply_severity_filter(report)
        return report

    def audit_callable(
        self,
        fn: Callable[..., Any],
        sample_inputs: Optional[List[Any]] = None,
        runtime: bool = False,
        artifact_paths: Optional[List[str | Path]] = None,
    ) -> Report:
        report = Report(target=f"{fn.__module__}.{fn.__qualname__}")
        store = EvidenceStore()

        try:
            src_file = inspect.getsourcefile(fn)
        except TypeError:
            src_file = None

        if src_file:
            src_path = Path(src_file).resolve()
            pkg_root = _find_package_root(src_path)
            if pkg_root:
                self._audit_directory(pkg_root, store)
            else:
                self._audit_single_file(src_path, store)

        if self.policy.enable_artifact_scan and artifact_paths:
            for ap in artifact_paths:
                self._audit_artifact(Path(ap), store)

        if (runtime or self.policy.enable_runtime) and sample_inputs:
            from .runtime.runner import run_callable
            events, exc = run_callable(fn, sample_inputs, self.policy)
            store.add_many(events)
            if exc:
                report.metadata["runtime_exception"] = str(exc)

        self._run_detectors(store, report)
        self._apply_severity_filter(report)
        return report

    def _audit_directory(self, root: Path, store: EvidenceStore) -> None:
        extra = set(self.policy.extra_extensions)
        if self.policy.enable_sast or self.policy.enable_secrets:
            for path in walk_source(root, extra):
                self._audit_single_file(path, store)
        if self.policy.enable_config_scan:
            for path in walk_configs(root):
                store.add_many(collect_config_secrets(path))
        if self.policy.enable_artifact_scan:
            for path in root.rglob("*"):
                if not path.is_file():
                    continue
                suf = path.suffix.lower()
                if suf == ".whl":
                    store.add_many(collect_wheel_evidence(path))
                elif suf in (".so", ".dll", ".dylib", ".pyd"):
                    store.add_many(collect_elf_evidence(path))
                else:
                    try:
                        if path.read_bytes()[:4] == b"\x7fELF":
                            store.add_many(collect_elf_evidence(path))
                    except OSError:
                        pass

    def _audit_single_file(self, path: Path, store: EvidenceStore) -> None:
        if path.suffix.lower() == ".py" and self.policy.enable_sast:
            store.add_many(collect_ast_evidence(path))
        if self.policy.enable_secrets:
            store.add_many(collect_secrets(
                path,
                entropy_threshold=self.policy.entropy_threshold,
                min_len=self.policy.secret_min_length,
                allowlist=self.policy.secret_allowlist,
            ))

    def _audit_artifact(self, path: Path, store: EvidenceStore) -> None:
        if path.suffix.lower() == ".whl":
            store.add_many(collect_wheel_evidence(path))
        else:
            store.add_many(collect_elf_evidence(path))

    def _run_detectors(self, store: EvidenceStore, report: Report) -> None:
        if self.policy.enable_sast:
            report.add_many(detect_insecure_apis(store))
            report.add_many(detect_obfuscation(store))
        if self.policy.enable_secrets:
            report.add_many(detect_secrets(store))
        if self.policy.enable_artifact_scan:
            report.add_many(detect_exfil_indicators(store))
            report.add_many(detect_packed_binary(store))
        runtime_events = (
            store.by_kind("runtime_network") +
            store.by_kind("runtime_subprocess") +
            store.by_kind("runtime_file_write") +
            store.by_kind("runtime_import")
        )
        if runtime_events:
            report.add_many(analyze_runtime_events(runtime_events, self.policy))

    def _apply_severity_filter(self, report: Report) -> None:
        order = [s.value for s in Severity]
        min_idx = order.index(self.policy.min_severity)
        report.findings = [f for f in report.findings if order.index(f.severity.value) <= min_idx]

    def audit(self, runtime: bool = False, sample_inputs: Optional[List[Any]] = None):
        def decorator(fn: Callable[..., Any]) -> Callable[..., Any]:
            report = self.audit_callable(fn, sample_inputs=sample_inputs, runtime=runtime)
            print(report.summary())
            fn._algoguard_report = report  # type: ignore[attr-defined]
            return fn
        return decorator


def audit(
    runtime: bool = False,
    policy: str | Policy = "default",
    sample_inputs: Optional[List[Any]] = None,
):
    if isinstance(policy, str):
        policy = {"default": Policy.default, "strict": Policy.strict, "fast": Policy.fast}.get(policy, Policy.default)()
    return Auditor(policy=policy).audit(runtime=runtime, sample_inputs=sample_inputs)


def _find_package_root(src_path: Path) -> Optional[Path]:
    candidate = src_path.parent
    root = candidate
    while (candidate / "__init__.py").exists():
        root = candidate
        candidate = candidate.parent
    return root if root != src_path.parent else None