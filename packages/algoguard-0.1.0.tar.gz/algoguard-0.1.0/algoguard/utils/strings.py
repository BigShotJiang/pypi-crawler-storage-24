import re
import string

_PRINTABLE = set(string.printable)


def extract_strings(data: bytes, min_len: int = 6) -> list[str]:
    result = []
    current: list[str] = []
    for byte in data:
        ch = chr(byte)
        if ch in _PRINTABLE and ch not in ("\x0b", "\x0c"):
            current.append(ch)
        else:
            if len(current) >= min_len:
                result.append("".join(current))
            current = []
    if len(current) >= min_len:
        result.append("".join(current))
    return result


URL_RE = re.compile(r"https?://[^\s\"'<>]{6,}", re.IGNORECASE)
IP_RE = re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b")


def find_urls(text: str) -> list[str]:
    return URL_RE.findall(text)


def find_ips(text: str) -> list[str]:
    return IP_RE.findall(text)