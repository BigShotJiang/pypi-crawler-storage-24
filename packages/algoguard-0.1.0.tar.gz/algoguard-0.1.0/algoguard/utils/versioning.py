from typing import Tuple


def parse_version(v: str) -> Tuple[int, ...]:
    try:
        return tuple(int(x) for x in v.strip().lstrip("v").split(".")[:3])
    except ValueError:
        return (0,)


def version_lt(a: str, b: str) -> bool:
    return parse_version(a) < parse_version(b)