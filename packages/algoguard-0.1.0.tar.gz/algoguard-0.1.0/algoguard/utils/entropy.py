import math
from collections import Counter


def shannon_entropy(data: str) -> float:
    if not data:
        return 0.0
    counter = Counter(data)
    length = len(data)
    return -sum((count / length) * math.log2(count / length) for count in counter.values())


def is_high_entropy(value: str, threshold: float = 4.2, min_len: int = 16) -> bool:
    if len(value) < min_len:
        return False
    return shannon_entropy(value) >= threshold