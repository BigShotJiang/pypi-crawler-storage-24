from pathlib import Path
from typing import Iterator, Set

SOURCE_EXTENSIONS: Set[str] = {
    ".py", ".pyx", ".pxd", ".js", ".ts", ".jsx", ".tsx",
    ".sh", ".bash", ".zsh", ".rb", ".go", ".rs", ".c", ".cpp", ".h",
}

CONFIG_EXTENSIONS: Set[str] = {
    ".env", ".yaml", ".yml", ".json", ".toml", ".ini", ".cfg", ".conf", ".properties",
}

SKIP_DIRS: Set[str] = {
    ".git", "__pycache__", ".tox", ".mypy_cache", "node_modules",
    ".venv", "venv", "env", ".eggs", "dist", "build",
}


def walk_files(root: str | Path, extensions: Set[str] | None = None, skip_dirs: Set[str] = SKIP_DIRS) -> Iterator[Path]:
    root = Path(root)
    for path in root.rglob("*"):
        if path.is_file():
            if any(part in skip_dirs for part in path.parts):
                continue
            if extensions is None or path.suffix.lower() in extensions:
                yield path


def walk_source(root: str | Path, extra: Set[str] | None = None) -> Iterator[Path]:
    yield from walk_files(root, SOURCE_EXTENSIONS | (extra or set()))


def walk_configs(root: str | Path) -> Iterator[Path]:
    yield from walk_files(root, CONFIG_EXTENSIONS)