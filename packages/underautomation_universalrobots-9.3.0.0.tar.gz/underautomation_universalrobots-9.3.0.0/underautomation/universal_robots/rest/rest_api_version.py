from enum import IntEnum

class RestApiVersion(IntEnum):
	'''REST API version for PolyscopeX robots'''
	V1 = 1 # API Version 1
	Latest = 1 # Latest API version (currently V1)
