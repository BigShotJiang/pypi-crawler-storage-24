from enum import IntEnum

class RtdeVersions(IntEnum):
	'''RTDE version numbers'''
	V1 = 1 # Rtde version 1
	V2 = 2 # Rtde version 2
