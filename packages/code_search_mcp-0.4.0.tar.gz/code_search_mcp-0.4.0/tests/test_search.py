"""搜索和命中概率测试"""
import os

import pytest

from code_search_mcp.database import Database
from code_search_mcp.indexer import Indexer


class TestFindFiles:
    """文件搜索测试"""

    def setup_method(self):
        """每个测试前设置"""
        import tempfile
        self.temp_db = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
        self.temp_db.close()
        self.db = Database(self.temp_db.name)
        self.indexer = Indexer(self.db)

    def teardown_method(self):
        """每个测试后清理"""
        os.unlink(self.temp_db.name)

    @pytest.fixture
    def indexed_repo(self):
        """索引测试代码库"""
        test_repo_path = os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            "fixtures",
            "test_repo"
        )
        self.indexer.index_repository(test_repo_path, force_rebuild=True)
        return test_repo_path

    def test_find_files_exact(self, indexed_repo):
        """精确搜索文件名 'test.py'"""
        files = self.db.find_files(query="test.py", limit=20)

        # 应该命中 test.py
        names = [f.name for f in files]
        assert "test.py" in names

    def test_find_files_partial(self, indexed_repo):
        """模糊搜索 'test'"""
        files = self.db.find_files(query="test", limit=20)

        # 应该命中所有 test 文件
        assert len(files) >= 3
        names = [f.name for f in files]
        assert "test.js" in names
        assert "test.ts" in names
        assert "test.py" in names

    def test_find_files_extension(self, indexed_repo):
        """按扩展名搜索 '.py'"""
        files = self.db.find_files(extensions=[".py"], limit=20)

        # 仅返回 .py 文件
        assert len(files) == 1
        assert files[0].name == "test.py"

    def test_find_files_multiple_extensions(self, indexed_repo):
        """多扩展名搜索"""
        files = self.db.find_files(extensions=[".js", ".ts"], limit=20)

        # 返回 .js 和 .ts 文件
        assert len(files) == 2
        names = [f.name for f in files]
        assert "test.js" in names
        assert "test.ts" in names


class TestFindSymbols:
    """符号搜索测试"""

    def setup_method(self):
        """每个测试前设置"""
        import tempfile
        self.temp_db = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
        self.temp_db.close()
        self.db = Database(self.temp_db.name)
        self.indexer = Indexer(self.db)

    def teardown_method(self):
        """每个测试后清理"""
        os.unlink(self.temp_db.name)

    @pytest.fixture
    def indexed_repo(self):
        """索引测试代码库"""
        test_repo_path = os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            "fixtures",
            "test_repo"
        )
        self.indexer.index_repository(test_repo_path, force_rebuild=True)
        return test_repo_path

    def test_find_symbols_function(self, indexed_repo):
        """搜索函数 'calculate'"""
        symbols = self.db.find_symbols(query="calculate", limit=20)

        # 应该命中 calculateSum, calculate_sum 等
        assert len(symbols) >= 1
        names = [s["name"] for s in symbols]
        assert any("calculate" in name.lower() for name in names)

    def test_find_symbols_class(self, indexed_repo):
        """搜索类 'TestClass'"""
        symbols = self.db.find_symbols(query="TestClass", limit=20)

        # 应该命中 TestClass
        assert len(symbols) >= 1
        assert any(s["name"] == "TestClass" for s in symbols)

    def test_find_symbols_partial_class(self, indexed_repo):
        """部分类名搜索 'Test'"""
        symbols = self.db.find_symbols(query="Test", limit=20)

        # 应该命中多个包含 Test 的类
        assert len(symbols) >= 1
        names = [s["name"] for s in symbols]
        assert any("Test" in name for name in names)

    def test_find_symbols_kind_function(self, indexed_repo):
        """按类型过滤函数"""
        symbols = self.db.find_symbols(kind="function", limit=20)

        # 仅返回函数
        assert all(s["kind"] == "function" for s in symbols)

    def test_find_symbols_kind_class(self, indexed_repo):
        """按类型过滤类"""
        symbols = self.db.find_symbols(kind="class", limit=20)

        # 仅返回类
        assert all(s["kind"] == "class" for s in symbols)
        names = [s["name"] for s in symbols]
        assert "DataProcessor" in names
        assert "TestClass" in names
        assert "Calculator" in names


class TestFindContent:
    """内容搜索测试"""

    def setup_method(self):
        """每个测试前设置"""
        import tempfile
        self.temp_db = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
        self.temp_db.close()
        self.db = Database(self.temp_db.name)
        self.indexer = Indexer(self.db)

    def teardown_method(self):
        """每个测试后清理"""
        os.unlink(self.temp_db.name)

    @pytest.fixture
    def indexed_repo(self):
        """索引测试代码库"""
        test_repo_path = os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            "fixtures",
            "test_repo"
        )
        self.indexer.index_repository(test_repo_path, force_rebuild=True)
        return test_repo_path

    def test_find_content_exact(self, indexed_repo):
        """精确内容搜索 'return a + b'"""
        matches = self.db.find_content("return a + b", limit=20)

        # 应该命中对应行
        assert len(matches) >= 1

    def test_find_content_partial(self, indexed_repo):
        """部分内容搜索 'return'"""
        matches = self.db.find_content("return", limit=20)

        # 应该命中多行
        assert len(matches) >= 3

    def test_find_content_nonexistent(self, indexed_repo):
        """搜索不存在的内容"""
        matches = self.db.find_content("nonexistent_xyz_123", limit=20)

        # 应该无结果
        assert len(matches) == 0


class TestHitRate:
    """命中概率测试"""

    def setup_method(self):
        """每个测试前设置"""
        import tempfile
        self.temp_db = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
        self.temp_db.close()
        self.db = Database(self.temp_db.name)
        self.indexer = Indexer(self.db)

    def teardown_method(self):
        """每个测试后清理"""
        os.unlink(self.temp_db.name)

    @pytest.fixture
    def indexed_repo(self):
        """索引测试代码库"""
        test_repo_path = os.path.join(
            os.path.dirname(os.path.abspath(__file__)),
            "fixtures",
            "test_repo"
        )
        self.indexer.index_repository(test_repo_path, force_rebuild=True)
        return test_repo_path

    def test_hit_rate_exact_function_name(self, indexed_repo):
        """精确函数名搜索命中概率"""
        symbols = self.db.find_symbols(query="calculateSum", limit=20)

        # 精确名称应该命中
        assert len(symbols) >= 1

    def test_hit_rate_fuzzy_function_name(self, indexed_repo):
        """模糊函数名搜索命中概率"""
        symbols = self.db.find_symbols(query="calculate", limit=20)

        # 模糊搜索应该命中多个
        assert len(symbols) >= 1

    def test_hit_rate_exact_class_name(self, indexed_repo):
        """精确类名搜索命中概率"""
        symbols = self.db.find_symbols(query="TestClass", limit=20)

        # 应该命中 1 个
        assert len(symbols) == 1
        assert symbols[0]["name"] == "TestClass"

    def test_hit_rate_partial_class_name(self, indexed_repo):
        """部分类名搜索命中概率"""
        symbols = self.db.find_symbols(query="Test", limit=20)

        # 应该命中多个
        assert len(symbols) >= 1

    def test_hit_rate_exact_content(self, indexed_repo):
        """精确内容搜索命中概率"""
        matches = self.db.find_content("return a + b", limit=20)

        # 应该命中
        assert len(matches) >= 1

    def test_hit_rate_partial_content(self, indexed_repo):
        """部分内容搜索命中概率"""
        matches = self.db.find_content("return", limit=20)

        # 应该命中多行
        assert len(matches) >= 3

    def test_hit_rate_nonexistent(self, indexed_repo):
        """不存在的查询"""
        symbols = self.db.find_symbols(query="nonexistent_xyz", limit=20)

        # 应该无结果
        assert len(symbols) == 0
