"""语言策略 - 使用策略模式支持不同编程语言"""
import os
import re
from abc import ABC, abstractmethod
from typing import NamedTuple


class Symbol(NamedTuple):
    """符号定义"""
    name: str
    kind: str  # function, class, variable, method
    signature: str | None
    line_start: int
    line_end: int


class LanguageStrategy(ABC):
    """语言策略抽象基类"""

    @abstractmethod
    def extract_symbols(self, file_path: str) -> list[Symbol]:
        """提取文件中的符号"""
        pass

    @abstractmethod
    def extract_summary(self, file_path: str) -> str | None:
        """提取文件的语义摘要"""
        pass


class JavaScriptStrategy(LanguageStrategy):
    """JavaScript/TypeScript 策略"""

    # 函数/方法正则
    FUNC_PATTERN = re.compile(
        r'^(?:export\s+)?(?:async\s+)?function\s+(\w+)\s*\(([^)]*)\)',
        re.MULTILINE
    )
    # 箭头函数
    ARROW_PATTERN = re.compile(
        r'^(?:export\s+)?(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s+)?\(([^)]*)\)\s*=>',
        re.MULTILINE
    )
    # 类
    CLASS_PATTERN = re.compile(
        r'^(?:export\s+)?class\s+(\w+)(?:\s+extends\s+\w+)?(?:\s+implements\s+[\w,\s]+)?',
        re.MULTILINE
    )
    # 方法
    METHOD_PATTERN = re.compile(
        r'^\s*(?:async\s+)?(\w+)\s*\(([^)]*)\)\s*\{',
        re.MULTILINE
    )
    # TypeScript 类型
    INTERFACE_PATTERN = re.compile(
        r'^(?:export\s+)?interface\s+(\w+)',
        re.MULTILINE
    )
    TYPE_PATTERN = re.compile(
        r'^(?:export\s+)?type\s+(\w+)',
        re.MULTILINE
    )

    def extract_symbols(self, file_path: str) -> list[Symbol]:
        """提取 JS/TS 符号"""
        symbols = []
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()

            # 提取函数
            for match in self.FUNC_PATTERN.finditer(content):
                name = match.group(1)
                params = match.group(2)
                line_num = content[:match.start()].count('\n') + 1
                symbols.append(Symbol(
                    name=name,
                    kind='function',
                    signature=f"function {name}({params})",
                    line_start=line_num,
                    line_end=line_num
                ))

            # 提取箭头函数
            for match in self.ARROW_PATTERN.finditer(content):
                name = match.group(1)
                params = match.group(2)
                line_num = content[:match.start()].count('\n') + 1
                symbols.append(Symbol(
                    name=name,
                    kind='function',
                    signature=f"const {name} = ({params}) => ...",
                    line_start=line_num,
                    line_end=line_num
                ))

            # 提取类
            for match in self.CLASS_PATTERN.finditer(content):
                name = match.group(1)
                line_num = content[:match.start()].count('\n') + 1
                symbols.append(Symbol(
                    name=name,
                    kind='class',
                    signature=f"class {name}",
                    line_start=line_num,
                    line_end=line_num
                ))

            # 提取接口
            for match in self.INTERFACE_PATTERN.finditer(content):
                name = match.group(1)
                line_num = content[:match.start()].count('\n') + 1
                symbols.append(Symbol(
                    name=name,
                    kind='interface',
                    signature=f"interface {name}",
                    line_start=line_num,
                    line_end=line_num
                ))

            # 提取类型
            for match in self.TYPE_PATTERN.finditer(content):
                name = match.group(1)
                line_num = content[:match.start()].count('\n') + 1
                symbols.append(Symbol(
                    name=name,
                    kind='type',
                    signature=f"type {name}",
                    line_start=line_num,
                    line_end=line_num
                ))

        except Exception:
            pass
        return symbols

    def extract_summary(self, file_path: str) -> str | None:
        """提取 JS/TS 摘要"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()

            # 提取 import 语句
            imports = re.findall(r'^import\s+.*?from\s+[\'"](.+?)[\'"]', content, re.MULTILINE)

            # 提取导出
            exports = re.findall(r'^export\s+(?:default\s+)?(?:const|let|var|function|class|interface|type)\s+(\w+)', content, re.MULTILINE)

            parts = []
            if imports:
                parts.append(f"导入: {', '.join(imports[:5])}")
            if exports:
                parts.append(f"导出: {', '.join(exports[:5])}")

            return " | ".join(parts) if parts else None
        except Exception:
            return None


class PythonStrategy(LanguageStrategy):
    """Python 策略"""

    # 函数
    FUNC_PATTERN = re.compile(
        r'^(?:async\s+)?def\s+(\w+)\s*\(([^)]*)\):',
        re.MULTILINE
    )
    # 类
    CLASS_PATTERN = re.compile(
        r'^class\s+(\w+)(?:\(([^)]+)\))?:',
        re.MULTILINE
    )
    # 装饰器函数
    DECORATOR_FUNC_PATTERN = re.compile(
        r'^@(\w+)\s*\n(?:async\s+)?def\s+(\w+)\s*\(([^)]*)\):',
        re.MULTILINE
    )

    def extract_symbols(self, file_path: str) -> list[Symbol]:
        """提取 Python 符号"""
        symbols = []
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()

            # 提取函数
            for match in self.FUNC_PATTERN.finditer(content):
                name = match.group(1)
                params = match.group(2)
                line_num = content[:match.start()].count('\n') + 1
                symbols.append(Symbol(
                    name=name,
                    kind='function',
                    signature=f"def {name}({params})",
                    line_start=line_num,
                    line_end=line_num
                ))

            # 提取类
            for match in self.CLASS_PATTERN.finditer(content):
                name = match.group(1)
                base = match.group(2)
                line_num = content[:match.start()].count('\n') + 1
                signature = f"class {name}"
                if base:
                    signature += f"({base})"
                symbols.append(Symbol(
                    name=name,
                    kind='class',
                    signature=signature,
                    line_start=line_num,
                    line_end=line_num
                ))

        except Exception:
            pass
        return symbols

    def extract_summary(self, file_path: str) -> str | None:
        """提取 Python 摘要"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()

            # 提取 import
            imports = re.findall(r'^import\s+(\w+)', content, re.MULTILINE)
            from_imports = re.findall(r'^from\s+(\w+)\s+import', content, re.MULTILINE)

            # 提取 class 和 def
            classes = re.findall(r'^class\s+(\w+)', content, re.MULTILINE)
            functions = re.findall(r'^def\s+(\w+)', content, re.MULTILINE)

            parts = []
            all_imports = list(set(imports + from_imports))
            if all_imports:
                parts.append(f"导入: {', '.join(all_imports[:5])}")
            if classes:
                parts.append(f"类: {', '.join(classes[:3])}")
            if functions:
                parts.append(f"函数: {', '.join(functions[:5])}")

            return " | ".join(parts) if parts else None
        except Exception:
            return None


class IndexEngine:
    """索引引擎 - 管理语言策略"""

    # 扩展名到策略的映射
    STRATEGIES = {
        '.js': JavaScriptStrategy(),
        '.jsx': JavaScriptStrategy(),
        '.ts': JavaScriptStrategy(),
        '.tsx': JavaScriptStrategy(),
        '.mjs': JavaScriptStrategy(),
        '.cjs': JavaScriptStrategy(),
        '.py': PythonStrategy(),
    }

    # 扩展名到语言的映射
    EXT_TO_LANG = {
        '.js': 'JavaScript',
        '.jsx': 'JavaScript',
        '.ts': 'TypeScript',
        '.tsx': 'TypeScript',
        '.mjs': 'JavaScript',
        '.cjs': 'JavaScript',
        '.py': 'Python',
    }

    @classmethod
    def get_strategy(cls, extension: str) -> LanguageStrategy | None:
        """获取语言策略"""
        return cls.STRATEGIES.get(extension.lower())

    @classmethod
    def get_language(cls, extension: str) -> str | None:
        """获取语言名称"""
        return cls.EXT_TO_LANG.get(extension.lower())

    @classmethod
    def extract_symbols(cls, file_path: str) -> list[Symbol]:
        """提取符号"""
        ext = os.path.splitext(file_path)[1]
        strategy = cls.get_strategy(ext)
        if strategy:
            return strategy.extract_symbols(file_path)
        return []

    @classmethod
    def extract_summary(cls, file_path: str) -> str | None:
        """提取摘要"""
        ext = os.path.splitext(file_path)[1]
        strategy = cls.get_strategy(ext)
        if strategy:
            return strategy.extract_summary(file_path)
        return None
