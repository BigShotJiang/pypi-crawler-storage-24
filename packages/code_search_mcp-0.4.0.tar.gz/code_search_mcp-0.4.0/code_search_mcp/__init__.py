"""Code Index MCP - 将本地代码库转换为SQLite索引，提供高效的混合搜索能力"""
