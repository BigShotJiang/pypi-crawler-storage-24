"""数据库层 - SQLite索引存储"""
import os
import sqlite3
from contextlib import contextmanager
from dataclasses import dataclass


@dataclass
class FileRecord:
    """文件记录"""
    id: int | None
    path: str
    name: str
    extension: str | None
    language: str | None
    size: int
    modified_time: int
    indexed_at: int | None


@dataclass
class SymbolRecord:
    """符号记录"""
    id: int | None
    file_id: int
    name: str
    kind: str  # function, class, variable, method
    signature: str | None
    line_start: int
    line_end: int
    indexed_at: int | None


@dataclass
class ContentRecord:
    """内容记录"""
    id: int | None
    file_id: int
    line_number: int
    content: str
    indexed_at: int | None


@dataclass
class SummaryRecord:
    """摘要记录"""
    id: int | None
    file_id: int
    summary: str
    indexed_at: int | None


class Database:
    """SQLite数据库管理"""

    SCHEMA = """
    -- 文件索引表
    CREATE TABLE IF NOT EXISTS files (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        path TEXT UNIQUE NOT NULL,
        name TEXT NOT NULL,
        extension TEXT,
        language TEXT,
        size INTEGER,
        modified_time INTEGER,
        indexed_at INTEGER DEFAULT (strftime('%s', 'now'))
    );

    -- 符号索引表
    CREATE TABLE IF NOT EXISTS symbols (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        file_id INTEGER REFERENCES files(id) ON DELETE CASCADE,
        name TEXT NOT NULL,
        kind TEXT NOT NULL,
        signature TEXT,
        line_start INTEGER,
        line_end INTEGER,
        indexed_at INTEGER DEFAULT (strftime('%s', 'now'))
    );

    -- 内容索引表
    CREATE TABLE IF NOT EXISTS content (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        file_id INTEGER REFERENCES files(id) ON DELETE CASCADE,
        line_number INTEGER,
        content TEXT NOT NULL,
        indexed_at INTEGER DEFAULT (strftime('%s', 'now'))
    );

    -- 语义摘要表
    CREATE TABLE IF NOT EXISTS summaries (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        file_id INTEGER REFERENCES files(id) ON DELETE CASCADE,
        summary TEXT,
        indexed_at INTEGER DEFAULT (strftime('%s', 'now'))
    );

    -- 索引
    CREATE INDEX IF NOT EXISTS idx_files_path ON files(path);
    CREATE INDEX IF NOT EXISTS idx_files_name ON files(name);
    CREATE INDEX IF NOT EXISTS idx_files_extension ON files(extension);
    CREATE INDEX IF NOT EXISTS idx_files_language ON files(language);

    CREATE INDEX IF NOT EXISTS idx_symbols_file_id ON symbols(file_id);
    CREATE INDEX IF NOT EXISTS idx_symbols_name ON symbols(name);
    CREATE INDEX IF NOT EXISTS idx_symbols_kind ON symbols(kind);

    CREATE INDEX IF NOT EXISTS idx_content_file_id ON content(file_id);

    CREATE INDEX IF NOT EXISTS idx_summaries_file_id ON summaries(file_id);
    """

    FTS_SCHEMA = """
    CREATE VIRTUAL TABLE IF NOT EXISTS content_fts USING fts5(
        content,
        content='content',
        content_rowid='id'
    );
    """

    def __init__(self, db_path: str | None = None):
        """初始化数据库

        Args:
            db_path: 数据库文件路径，默认为 ~/.code-index/index.db
        """
        if db_path is None:
            home = os.path.expanduser("~")
            index_dir = os.path.join(home, ".code-index")
            os.makedirs(index_dir, exist_ok=True)
            db_path = os.path.join(index_dir, "index.db")

        self.db_path = db_path
        self._init_db()

    def _init_db(self):
        """初始化数据库schema"""
        with self.get_connection() as conn:
            conn.executescript(self.SCHEMA)
            conn.executescript(self.FTS_SCHEMA)

    @contextmanager
    def get_connection(self):
        """获取数据库连接"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    # ========== 文件操作 ==========

    def insert_file(self, path: str, name: str, extension: str | None,
                    language: str | None, size: int, modified_time: int) -> int:
        """插入文件记录"""
        import time
        with self.get_connection() as conn:
            cursor = conn.execute("""
                INSERT INTO files (path, name, extension, language, size, modified_time, indexed_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (path, name, extension, language, size, modified_time, int(time.time())))
            return cursor.lastrowid

    def get_file_by_path(self, path: str) -> FileRecord | None:
        """根据路径获取文件记录"""
        with self.get_connection() as conn:
            row = conn.execute("SELECT * FROM files WHERE path = ?", (path,)).fetchone()
            if row:
                return FileRecord(**dict(row))
            return None

    def get_file_by_id(self, file_id: int) -> FileRecord | None:
        """根据ID获取文件记录"""
        with self.get_connection() as conn:
            row = conn.execute("SELECT * FROM files WHERE id = ?", (file_id,)).fetchone()
            if row:
                return FileRecord(**dict(row))
            return None

    def update_file(self, file_id: int, **kwargs):
        """更新文件记录"""
        fields = ", ".join(f"{k} = ?" for k in kwargs.keys())
        values = list(kwargs.values()) + [file_id]
        with self.get_connection() as conn:
            conn.execute(f"UPDATE files SET {fields} WHERE id = ?", values)

    def delete_file(self, file_id: int):
        """删除文件记录"""
        with self.get_connection() as conn:
            conn.execute("DELETE FROM files WHERE id = ?", (file_id,))

    def get_all_indexed_files(self, repo_path: str) -> dict[str, FileRecord]:
        """获取仓库下所有已索引的文件

        Args:
            repo_path: 仓库路径

        Returns:
            {file_path: FileRecord} 字典
        """
        with self.get_connection() as conn:
            rows = conn.execute(
                "SELECT * FROM files WHERE path LIKE ?",
                (f"{repo_path}%",)
            ).fetchall()
            return {row['path']: FileRecord(**dict(row)) for row in rows}

    def upsert_file(self, path: str, name: str, extension: str | None,
                    language: str | None, size: int, modified_time: int) -> int:
        """插入或更新文件记录

        如果文件已存在则更新，不存在则插入

        Returns:
            文件ID
        """
        existing = self.get_file_by_path(path)
        if existing:
            self.update_file(existing.id,
                           name=name,
                           extension=extension,
                           language=language,
                           size=size,
                           modified_time=modified_time,
                           indexed_at=int(__import__('time').time()))
            return existing.id
        else:
            return self.insert_file(path, name, extension, language, size, modified_time)

    def find_files(self, query: str | None = None, extensions: list[str] | None = None,
                   limit: int = 20) -> list[FileRecord]:
        """搜索文件"""
        sql = "SELECT * FROM files WHERE 1=1"
        params = []

        if query:
            sql += " AND (name LIKE ? OR path LIKE ?)"
            params.extend([f"%{query}%", f"%{query}%"])

        if extensions:
            placeholders = ",".join("?" * len(extensions))
            sql += f" AND extension IN ({placeholders})"
            params.extend(extensions)

        sql += " ORDER BY modified_time DESC LIMIT ?"
        params.append(limit)

        with self.get_connection() as conn:
            rows = conn.execute(sql, params).fetchall()
            return [FileRecord(**dict(row)) for row in rows]

    # ========== 符号操作 ==========

    def insert_symbol(self, file_id: int, name: str, kind: str,
                      signature: str | None, line_start: int, line_end: int) -> int:
        """插入符号记录"""
        with self.get_connection() as conn:
            cursor = conn.execute("""
                INSERT INTO symbols (file_id, name, kind, signature, line_start, line_end)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (file_id, name, kind, signature, line_start, line_end))
            return cursor.lastrowid

    def delete_symbols_by_file(self, file_id: int):
        """删除文件的所有符号"""
        with self.get_connection() as conn:
            conn.execute("DELETE FROM symbols WHERE file_id = ?", (file_id,))

    def find_symbols(self, query: str | None = None, kind: str | None = None,
                     file_id: int | None = None, limit: int = 20) -> list[dict]:
        """搜索符号"""
        sql = """
            SELECT s.*, f.path as file_path, f.name as file_name
            FROM symbols s
            JOIN files f ON s.file_id = f.id
            WHERE 1=1
        """
        params = []

        if query:
            sql += " AND s.name LIKE ?"
            params.append(f"%{query}%")

        if kind:
            sql += " AND s.kind = ?"
            params.append(kind)

        if file_id:
            sql += " AND s.file_id = ?"
            params.append(file_id)

        sql += " LIMIT ?"
        params.append(limit)

        with self.get_connection() as conn:
            rows = conn.execute(sql, params).fetchall()
            return [dict(row) for row in rows]

    # ========== 内容操作 ==========

    def insert_content(self, file_id: int, line_number: int, content: str) -> int:
        """插入内容记录"""
        with self.get_connection() as conn:
            cursor = conn.execute("""
                INSERT INTO content (file_id, line_number, content)
                VALUES (?, ?, ?)
            """, (file_id, line_number, content))
            return cursor.lastrowid

    def insert_content_batch(self, records: list[tuple]):
        """批量插入内容"""
        with self.get_connection() as conn:
            conn.executemany("""
                INSERT INTO content (file_id, line_number, content)
                VALUES (?, ?, ?)
            """, records)
            # 重建 FTS 索引
            conn.execute("INSERT INTO content_fts(content_fts) VALUES('rebuild')")

    def delete_content_by_file(self, file_id: int):
        """删除文件的所有内容"""
        with self.get_connection() as conn:
            conn.execute("DELETE FROM content WHERE file_id = ?", (file_id,))

    def find_content(self, query: str, regex: bool = False,
                     file_pattern: str | None = None, limit: int = 20) -> list[dict]:
        """搜索内容"""
        if regex:
            # 使用正则搜索
            sql = """
                SELECT c.*, f.path as file_path, f.name as file_name
                FROM content c
                JOIN files f ON c.file_id = f.id
                WHERE c.content REGEXP ?
            """
            params = [query]
        else:
            # 使用 LIKE 搜索
            sql = """
                SELECT c.*, f.path as file_path, f.name as file_name
                FROM content c
                JOIN files f ON c.file_id = f.id
                WHERE c.content LIKE ?
            """
            params = [f"%{query}%"]

        if file_pattern:
            sql += " AND f.path LIKE ?"
            params.append(f"%{file_pattern}%")

        sql += " LIMIT ?"
        params.append(limit)

        with self.get_connection() as conn:
            rows = conn.execute(sql, params).fetchall()
            return [dict(row) for row in rows]

    # ========== 摘要操作 ==========

    def insert_summary(self, file_id: int, summary: str) -> int:
        """插入摘要记录"""
        with self.get_connection() as conn:
            cursor = conn.execute("""
                INSERT INTO summaries (file_id, summary)
                VALUES (?, ?)
            """, (file_id, summary))
            return cursor.lastrowid

    def delete_summary_by_file(self, file_id: int):
        """删除文件的摘要"""
        with self.get_connection() as conn:
            conn.execute("DELETE FROM summaries WHERE file_id = ?", (file_id,))

    def get_summary_by_file(self, file_id: int) -> SummaryRecord | None:
        """获取文件的摘要"""
        with self.get_connection() as conn:
            row = conn.execute("SELECT * FROM summaries WHERE file_id = ?", (file_id,)).fetchone()
            if row:
                return SummaryRecord(**dict(row))
            return None

    # ========== 统计操作 ==========

    def get_stats(self) -> dict:
        """获取索引统计"""
        with self.get_connection() as conn:
            files = conn.execute("SELECT COUNT(*) FROM files").fetchone()[0]
            symbols = conn.execute("SELECT COUNT(*) FROM symbols").fetchone()[0]
            content = conn.execute("SELECT COUNT(*) FROM content").fetchone()[0]
            return {
                "files": files,
                "symbols": symbols,
                "content_blocks": content
            }

    def clear_all(self):
        """清空所有索引数据"""
        with self.get_connection() as conn:
            conn.execute("DELETE FROM content")
            conn.execute("DELETE FROM symbols")
            conn.execute("DELETE FROM summaries")
            conn.execute("DELETE FROM files")

    # ========== 智能建议 ==========

    # 代码模式关联映射
    CODE_PATTERNS = {
        "fetch": ["fetch", "axios", "request", "http", "get", "post", "put", "delete"],
        "api": ["api", "endpoint", "route", "controller", "handler", "service"],
        "async": ["async", "await", "promise", "then", "coroutine", "future"],
        "error": ["error", "exception", "throw", "catch", "raise", "fail"],
        "test": ["test", "spec", "mock", "spy", "describe", "it", "expect"],
        "config": ["config", "setting", "option", "env", "environment", "variable"],
        "database": ["db", "database", "query", "sql", "cursor", "connection"],
        "auth": ["auth", "login", "token", "session", "jwt", "oauth", "permission"],
        "event": ["event", "listener", "handler", "emit", "onclick", "callback"],
        "utils": ["util", "helper", "tool", "common", "lib", "module"],
    }

    def get_suggestions(self, query: str, limit: int = 10) -> dict:
        """获取智能搜索建议

        基于代码模式和符号关联提供建议
        """
        suggestions = {
            "query": query,
            "related_searches": [],
            "symbol_suggestions": [],
            "pattern_suggestions": []
        }

        if not query:
            return suggestions

        query_lower = query.lower()

        # 1. 代码模式关联
        for pattern, keywords in self.CODE_PATTERNS.items():
            if query_lower in keywords:
                suggestions["pattern_suggestions"].append({
                    "pattern": pattern,
                    "keywords": keywords
                })
                # 添加相关搜索
                for kw in keywords:
                    if kw != query_lower:
                        suggestions["related_searches"].append(kw)

        # 2. 基于符号的关联建议
        # 搜索类似的符号名
        with self.get_connection() as conn:
            # 找相似符号
            similar_symbols = conn.execute("""
                SELECT DISTINCT name, kind
                FROM symbols
                WHERE name LIKE ? OR name LIKE ?
                LIMIT ?
            """, (f"%{query_lower}%", f"{query_lower}%", limit)).fetchall()

            for row in similar_symbols:
                suggestions["symbol_suggestions"].append({
                    "name": row["name"],
                    "kind": row["kind"]
                })

            # 找相关类的使用建议
            if len(query) >= 3:
                # 基于前缀/后缀的智能建议
                prefix_suggestions = conn.execute("""
                    SELECT DISTINCT name
                    FROM symbols
                    WHERE name LIKE ? AND kind = 'class'
                    LIMIT 5
                """, (f"{query_lower.capitalize()}*",)).fetchall()

                for row in prefix_suggestions:
                    if row["name"] not in [s["name"] for s in suggestions["symbol_suggestions"]]:
                        suggestions["symbol_suggestions"].append({
                            "name": row["name"],
                            "kind": "class",
                            "suggestion_type": "prefix_match"
                        })

        # 3. 热门符号建议
        with self.get_connection() as conn:
            popular_symbols = conn.execute("""
                SELECT name, kind, COUNT(*) as count
                FROM symbols
                GROUP BY name
                ORDER BY count DESC
                LIMIT 5
            """).fetchall()

            suggestions["popular"] = [
                {"name": row["name"], "kind": row["kind"]}
                for row in popular_symbols
            ]

        return suggestions
