"""Tests for context optimization and contract issue detection."""

from pathlib import Path

from conciliate.context_optimizer import ContextOptimizer
from conciliate.contract_issues import detect_contract_issues


def _sample_spec(title: str, required_email: bool = True, include_delete: bool = False):
    required = ["name", "email"] if required_email else ["name"]
    methods = {
        "post": {
            "summary": "Create user",
            "description": "Create a user in the system",
            "requestBody": {
                "content": {
                    "application/json": {
                        "schema": {"$ref": "#/components/schemas/UserCreate"}
                    }
                }
            },
            "responses": {"200": {"description": "OK"}},
            "parameters": [
                {"name": "tenant_id", "in": "query", "required": True, "schema": {"type": "string"}}
            ],
        },
        "get": {
            "summary": "List users",
            "description": "List all users",
            "responses": {"200": {"description": "OK"}},
        },
    }
    if include_delete:
        methods["delete"] = {
            "summary": "Delete users",
            "description": "Delete all users",
            "responses": {"204": {"description": "Deleted"}},
        }

    return {
        "openapi": "3.0.0",
        "info": {"title": title, "version": "1.0.0"},
        "paths": {
            "/users": methods,
            "/orders": {
                "get": {
                    "summary": "List orders",
                    "description": "List all orders",
                    "responses": {"200": {"description": "OK"}},
                }
            },
        },
        "components": {
            "schemas": {
                "UserCreate": {
                    "type": "object",
                    "required": required,
                    "properties": {
                        "name": {"type": "string"},
                        "email": {"type": "string"},
                    },
                }
            }
        },
    }


def test_context_optimizer_returns_shard_and_metrics(tmp_path: Path):
    optimizer = ContextOptimizer(output_dir=tmp_path, default_budget=300)
    specs = {
        "Users Service": _sample_spec("Users Service"),
        "Billing Service": {
            **_sample_spec("Billing Service"),
            "paths": {
                "/invoices": {
                    "get": {
                        "summary": "List invoices",
                        "description": "List all invoices",
                        "responses": {"200": {"description": "OK"}},
                    }
                }
            },
        },
    }

    result = optimizer.optimize(specs_by_service=specs, query="create user endpoint", max_tokens=260)

    assert result["estimated_tokens_full"] >= result["estimated_tokens_shard"]
    assert result["tokens_saved"] >= 0
    assert result["selected_endpoints"]
    assert any(item["path"] == "/users" for item in result["selected_endpoints"])

    metrics = optimizer.get_metrics()
    assert metrics["optimize_calls"] == 1
    assert metrics["total_tokens_full"] >= metrics["total_tokens_shard"]


def test_context_optimizer_activity_cache_influences_active_endpoints(tmp_path: Path):
    optimizer = ContextOptimizer(output_dir=tmp_path, default_budget=400)
    specs = {"Users Service": _sample_spec("Users Service")}

    optimizer.record_activity("Users Service", "POST", "/users")
    result = optimizer.optimize(specs_by_service=specs, query="", max_tokens=240)

    assert any(item["path"] == "/users" for item in result["selected_endpoints"])
    active = optimizer.get_metrics()["active_endpoints"]
    assert any(item["path"] == "/users" and item["method"] == "POST" for item in active)


def test_detect_contract_issues_reports_multiple_mismatch_types():
    spec_a = _sample_spec("Service A", required_email=True, include_delete=False)
    spec_b = _sample_spec("Service B", required_email=False, include_delete=True)

    # Add an endpoint only to service A to trigger endpoint_missing
    spec_a["paths"]["/admin"] = {
        "get": {
            "summary": "Admin endpoint",
            "description": "Only in A",
            "responses": {"200": {"description": "OK"}},
        }
    }

    # Remove required query parameter from service B to trigger parameter_mismatch
    spec_b["paths"]["/users"]["post"]["parameters"] = []

    issues = detect_contract_issues({"Service A": spec_a, "Service B": spec_b})
    types = {issue["type"] for issue in issues}

    assert "endpoint_missing" in types
    assert "method_mismatch" in types
    assert "request_schema_mismatch" in types
    assert "parameter_mismatch" in types
    assert all("services" in issue and len(issue["services"]) == 2 for issue in issues)
