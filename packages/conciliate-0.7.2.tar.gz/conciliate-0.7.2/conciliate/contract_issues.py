"""Contract issue detection across multiple API specs."""

from __future__ import annotations

from itertools import combinations
from typing import Any, Dict, List, Optional, Set


HTTP_METHODS = {"get", "post", "put", "patch", "delete"}


def detect_contract_issues(specs_by_service: Dict[str, Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Detect cross-service contract mismatches.

    The output is designed for both REST and MCP consumers.
    """
    issues: List[Dict[str, Any]] = []

    if len(specs_by_service) < 2:
        return issues

    for service_a, service_b in combinations(specs_by_service.keys(), 2):
        spec_a = specs_by_service[service_a]
        spec_b = specs_by_service[service_b]

        paths_a = set(spec_a.get("paths", {}).keys())
        paths_b = set(spec_b.get("paths", {}).keys())

        for path in sorted(paths_a - paths_b):
            issues.append(
                {
                    "type": "endpoint_missing",
                    "severity": "warning",
                    "path": path,
                    "services": [service_a, service_b],
                    "detail": f"Endpoint exists in {service_a} but not in {service_b}",
                }
            )

        for path in sorted(paths_b - paths_a):
            issues.append(
                {
                    "type": "endpoint_missing",
                    "severity": "warning",
                    "path": path,
                    "services": [service_b, service_a],
                    "detail": f"Endpoint exists in {service_b} but not in {service_a}",
                }
            )

        for path in sorted(paths_a & paths_b):
            item_a = spec_a.get("paths", {}).get(path, {})
            item_b = spec_b.get("paths", {}).get(path, {})

            methods_a = {m for m in item_a.keys() if m in HTTP_METHODS}
            methods_b = {m for m in item_b.keys() if m in HTTP_METHODS}

            method_diff = methods_a.symmetric_difference(methods_b)
            if method_diff:
                issues.append(
                    {
                        "type": "method_mismatch",
                        "severity": "error",
                        "path": path,
                        "services": [service_a, service_b],
                        "detail": "Method availability differs: "
                        + ", ".join(sorted(m.upper() for m in method_diff)),
                    }
                )

            for method in sorted(methods_a & methods_b):
                req_a = _required_body_fields(spec_a, item_a[method])
                req_b = _required_body_fields(spec_b, item_b[method])
                if req_a != req_b:
                    issues.append(
                        {
                            "type": "request_schema_mismatch",
                            "severity": "error",
                            "path": path,
                            "method": method.upper(),
                            "services": [service_a, service_b],
                            "detail": (
                                f"Required request fields differ. "
                                f"{service_a}: {sorted(req_a)} | {service_b}: {sorted(req_b)}"
                            ),
                        }
                    )

                params_a = _required_parameters(item_a[method])
                params_b = _required_parameters(item_b[method])
                if params_a != params_b:
                    issues.append(
                        {
                            "type": "parameter_mismatch",
                            "severity": "warning",
                            "path": path,
                            "method": method.upper(),
                            "services": [service_a, service_b],
                            "detail": (
                                f"Required parameters differ. "
                                f"{service_a}: {sorted(params_a)} | {service_b}: {sorted(params_b)}"
                            ),
                        }
                    )

    return issues


def _required_parameters(operation: Dict[str, Any]) -> Set[str]:
    params = operation.get("parameters", [])
    names: Set[str] = set()
    for param in params:
        if param.get("required"):
            location = param.get("in", "")
            name = param.get("name", "")
            names.add(f"{location}:{name}")
    return names


def _required_body_fields(spec: Dict[str, Any], operation: Dict[str, Any]) -> Set[str]:
    request_body = operation.get("requestBody", {})
    content = request_body.get("content", {})
    schema = content.get("application/json", {}).get("schema", {})
    resolved = _resolve_schema(schema, spec)
    required = resolved.get("required", []) if isinstance(resolved, dict) else []
    return set(required)


def _resolve_schema(schema: Dict[str, Any], spec: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(schema, dict):
        return {}
    ref = schema.get("$ref", "")
    if not ref.startswith("#/"):
        return schema

    node: Any = spec
    for part in ref.lstrip("#/").split("/"):
        if not isinstance(node, dict):
            return {}
        node = node.get(part)
        if node is None:
            return {}
    return node if isinstance(node, dict) else {}
