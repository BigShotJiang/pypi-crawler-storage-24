"""Context budget optimization utilities for API contract sharding."""

from __future__ import annotations

import json
import re
from collections import OrderedDict
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple


HttpMethod = str
EndpointKey = Tuple[str, HttpMethod, str]


class EndpointActivityCache:
    """Simple LRU cache for recently accessed endpoints in a session."""

    def __init__(self, max_size: int = 64):
        self.max_size = max_size
        self._entries: OrderedDict[EndpointKey, None] = OrderedDict()

    def touch(self, service: str, method: str, path: str) -> None:
        key = (service, method.upper(), path)
        if key in self._entries:
            self._entries.move_to_end(key)
            return
        self._entries[key] = None
        if len(self._entries) > self.max_size:
            self._entries.popitem(last=False)

    def active(self, limit: int = 16) -> List[EndpointKey]:
        return list(self._entries.keys())[-limit:]

    def __len__(self) -> int:
        return len(self._entries)


class ContextOptimizer:
    """Build query-scoped OpenAPI shards and track token savings metrics."""

    HTTP_METHODS = {"get", "post", "put", "patch", "delete", "options", "head"}

    def __init__(self, output_dir: Path, default_budget: int = 1000):
        self.output_dir = output_dir
        self.default_budget = max(200, default_budget)
        self.activity_cache = EndpointActivityCache(max_size=64)
        self.metrics_file = self.output_dir / "context_metrics.json"
        self.metrics: Dict[str, Any] = {
            "optimize_calls": 0,
            "total_tokens_full": 0,
            "total_tokens_shard": 0,
            "total_tokens_saved": 0,
            "last_query": "",
        }
        self._load_metrics()

    def _load_metrics(self) -> None:
        if self.metrics_file.exists():
            try:
                loaded = json.loads(self.metrics_file.read_text(encoding="utf-8"))
                if isinstance(loaded, dict):
                    self.metrics.update(loaded)
            except Exception:
                # Keep defaults if file is malformed.
                pass

    def _save_metrics(self) -> None:
        self.metrics_file.write_text(json.dumps(self.metrics, indent=2), encoding="utf-8")

    def record_activity(self, service: str, method: str, path: str) -> None:
        self.activity_cache.touch(service, method, path)

    def optimize(
        self,
        specs_by_service: Dict[str, Dict[str, Any]],
        query: str,
        max_tokens: Optional[int] = None,
    ) -> Dict[str, Any]:
        if not specs_by_service:
            return {
                "query": query,
                "max_tokens": max_tokens or self.default_budget,
                "error": "No specs available",
                "services": {},
                "selected_endpoints": [],
            }

        budget = max_tokens or self.default_budget
        budget = max(200, budget)

        full_tokens = self._estimate_tokens(json.dumps(specs_by_service, separators=(",", ":")))
        candidates = self._rank_candidates(specs_by_service, query)
        selected = self._select_candidates(candidates, budget)

        shards_by_service = self._build_shards(specs_by_service, selected)
        shard_tokens = self._estimate_tokens(json.dumps(shards_by_service, separators=(",", ":")))
        tokens_saved = max(0, full_tokens - shard_tokens)

        self.metrics["optimize_calls"] += 1
        self.metrics["total_tokens_full"] += full_tokens
        self.metrics["total_tokens_shard"] += shard_tokens
        self.metrics["total_tokens_saved"] += tokens_saved
        self.metrics["last_query"] = query
        self._save_metrics()

        selected_endpoints = [
            {
                "service": service,
                "method": method,
                "path": path,
                "score": round(score, 2),
            }
            for service, method, path, score, _ in selected
        ]

        return {
            "query": query,
            "max_tokens": budget,
            "estimated_tokens_full": full_tokens,
            "estimated_tokens_shard": shard_tokens,
            "tokens_saved": tokens_saved,
            "savings_pct": round((tokens_saved / full_tokens) * 100, 2) if full_tokens else 0,
            "selected_endpoints": selected_endpoints,
            "services": shards_by_service,
            "metrics": self.get_metrics(),
        }

    def get_metrics(self) -> Dict[str, Any]:
        calls = int(self.metrics.get("optimize_calls", 0))
        total_full = int(self.metrics.get("total_tokens_full", 0))
        total_shard = int(self.metrics.get("total_tokens_shard", 0))
        total_saved = int(self.metrics.get("total_tokens_saved", 0))
        avg_saved = round((total_saved / total_full) * 100, 2) if total_full else 0

        return {
            "optimize_calls": calls,
            "total_tokens_full": total_full,
            "total_tokens_shard": total_shard,
            "total_tokens_saved": total_saved,
            "average_savings_pct": avg_saved,
            "last_query": self.metrics.get("last_query", ""),
            "active_endpoints": [
                {"service": s, "method": m, "path": p}
                for s, m, p in self.activity_cache.active(limit=12)
            ],
            "active_cache_size": len(self.activity_cache),
        }

    def _rank_candidates(
        self,
        specs_by_service: Dict[str, Dict[str, Any]],
        query: str,
    ) -> List[Tuple[str, str, str, float, Dict[str, Any]]]:
        tokens = {t for t in re.split(r"[^a-zA-Z0-9_/{}-]+", query.lower()) if t}
        active = set(self.activity_cache.active(limit=24))

        ranked: List[Tuple[str, str, str, float, Dict[str, Any]]] = []
        for service, spec in specs_by_service.items():
            for path, path_item in spec.get("paths", {}).items():
                for method, operation in path_item.items():
                    if method.lower() not in self.HTTP_METHODS:
                        continue

                    score = 1.0
                    method_up = method.upper()
                    path_l = path.lower()
                    summary_l = str(operation.get("summary", "")).lower()
                    desc_l = str(operation.get("description", "")).lower()

                    if query:
                        if method_up.lower() in query.lower():
                            score += 2.0
                        if path_l in query.lower():
                            score += 6.0
                        for token in tokens:
                            if token and token in path_l:
                                score += 2.0
                            if token and token in summary_l:
                                score += 1.5
                            if token and token in desc_l:
                                score += 0.75

                    if (service, method_up, path) in active:
                        score += 3.0

                    ranked.append((service, method_up, path, score, operation))

        ranked.sort(key=lambda item: item[3], reverse=True)
        return ranked

    def _select_candidates(
        self,
        candidates: List[Tuple[str, str, str, float, Dict[str, Any]]],
        budget: int,
    ) -> List[Tuple[str, str, str, float, Dict[str, Any]]]:
        selected: List[Tuple[str, str, str, float, Dict[str, Any]]] = []
        running_tokens = 0

        for service, method, path, score, operation in candidates:
            op_tokens = self._estimate_tokens(
                json.dumps({"m": method, "p": path, "o": operation}, separators=(",", ":"))
            )
            if selected and running_tokens + op_tokens > budget:
                continue
            selected.append((service, method, path, score, operation))
            running_tokens += op_tokens
            if running_tokens >= budget:
                break

        return selected

    def _build_shards(
        self,
        specs_by_service: Dict[str, Dict[str, Any]],
        selected: List[Tuple[str, str, str, float, Dict[str, Any]]],
    ) -> Dict[str, Dict[str, Any]]:
        grouped: Dict[str, Dict[str, Dict[str, Any]]] = {}
        for service, method, path, _score, operation in selected:
            grouped.setdefault(service, {})
            grouped[service].setdefault(path, {})
            grouped[service][path][method.lower()] = operation

        shards: Dict[str, Dict[str, Any]] = {}
        for service, selected_paths in grouped.items():
            source_spec = specs_by_service[service]
            shard = {
                "openapi": source_spec.get("openapi", "3.0.0"),
                "info": source_spec.get("info", {"title": service, "version": "shard"}),
                "paths": selected_paths,
                "components": {"schemas": {}},
            }

            referenced = self._collect_schema_refs(shard)
            source_schemas = source_spec.get("components", {}).get("schemas", {})
            for schema_name in sorted(referenced):
                if schema_name in source_schemas:
                    shard["components"]["schemas"][schema_name] = source_schemas[schema_name]

            if not shard["components"]["schemas"]:
                shard.pop("components", None)

            shards[service] = shard

        return shards

    def _collect_schema_refs(self, spec_fragment: Dict[str, Any]) -> Set[str]:
        refs: Set[str] = set()

        def _walk(node: Any) -> None:
            if isinstance(node, dict):
                ref_val = node.get("$ref")
                if isinstance(ref_val, str) and ref_val.startswith("#/components/schemas/"):
                    refs.add(ref_val.split("/")[-1])
                for value in node.values():
                    _walk(value)
            elif isinstance(node, list):
                for value in node:
                    _walk(value)

        _walk(spec_fragment)
        return refs

    @staticmethod
    def _estimate_tokens(text: str) -> int:
        # Rough tokenizer approximation: ~4 chars/token for English-ish JSON payloads.
        return max(1, len(text) // 4)
