"""Shared utilities for baton."""
