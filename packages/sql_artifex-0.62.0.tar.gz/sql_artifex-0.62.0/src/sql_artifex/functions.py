"""Query building functions."""

from __future__ import annotations

from typing import Any, override

from sql_artifex._common import AsMixin, QueryBuilder
from sql_artifex.types import SQLType


class Function(AsMixin):
    """SQL function call builder."""

    def __init__(self, function: str, *args: QueryBuilder | Any) -> None:
        """Instantiate a function SQL builder."""
        super().__init__()
        self.args = args
        self.function = function

    @override
    def prepare(self) -> tuple[str, list[Any]]:
        """Get the generated SQL and a tuple of params used."""
        sqls: list[str] = []
        param_lists: list[list[Any]] = []
        for arg in self.args:
            if isinstance(arg, QueryBuilder):
                s, p = arg.prepare()
                sqls.append(s)
                param_lists.append(p)
            else:
                sqls.append("?")
                param_lists.append([arg])
        sql = ", ".join(sqls)
        params: list[Any] = []
        for params_list in param_lists:
            params.extend(params_list)
        return f"{self.function}({sql})", params


class Cast(QueryBuilder):
    """Build `CAST` SQL function call."""

    def __init__(self, subquery: QueryBuilder, sql_type: type[SQLType]) -> None:
        """Instantiate a cast builder.

        :param subquery: Subquery to cast.
        :param sql_type: Type to cast to.
        """
        super().__init__()
        self.subquery = subquery
        self.type = sql_type

    @override
    def prepare(self) -> tuple[str, list[Any]]:
        """Get the generated SQL and a tuple of params used."""
        sql, params = self.subquery.prepare()
        return f"CAST({sql} AS {self.type.__name__})", params


class Replace(QueryBuilder):
    """Build `REPLACE` SQL function call."""

    def __init__(
        self,
        string_expression: str | QueryBuilder,
        string_pattern: str | QueryBuilder,
        string_replacement: str | QueryBuilder,
    ) -> None:
        """Instantiate a replace builder."""
        super().__init__()
        self.string_expression = string_expression
        self.string_pattern = string_pattern
        self.string_replacement = string_replacement

    @override
    def prepare(self) -> tuple[str, list[Any]]:
        """Get the generated SQL and a tuple of params used."""
        params: list[Any] = []
        sql = ""
        if isinstance(self.string_expression, str):
            sql += "?, "
            params.append(self.string_expression)
        else:
            inner_sql, inner_params = self.string_expression.prepare()
            sql += inner_sql + ", "
            params.extend(inner_params)
        if isinstance(self.string_pattern, str):
            sql += "?, "
            params.append(self.string_pattern)
        else:
            inner_sql, inner_params = self.string_pattern.prepare()
            sql += inner_sql + ", "
            params.extend(inner_params)
        if isinstance(self.string_replacement, str):
            sql += "?"
            params.append(self.string_replacement)
        else:
            inner_sql, inner_params = self.string_replacement.prepare()
            sql += inner_sql
            params.extend(inner_params)
        return f"REPLACE({sql})", params
