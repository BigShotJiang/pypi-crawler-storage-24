"""PostgreSQL types for Artifex.

From the docs:
https://www.postgresql.org/docs/current/datatype.html
"""

from __future__ import annotations

import enum
from typing import override

import caseswitcher


class PGEnum(enum.Enum):
    """Enum type class."""

    @classmethod
    def pg_enum_name(cls) -> str:
        """Get the SQL name for this custom enum."""
        return caseswitcher.to_snake(cls.__name__).upper()

    @classmethod
    def pg_enum_get_create(cls) -> str:
        """Get create enum SQL."""
        options = ", ".join(f"'{it.value}'" for it in cls)
        return f"CREATE TYPE {cls.pg_enum_name()} AS ENUM ({options});"


class SQLType:
    """Base SQL type class."""

    @override
    def __str__(self) -> str:
        """Get SQL keyword for this type."""
        return self.__class__.__name__


class BIGINT(SQLType):
    """Signed eight-byte integer."""


class BIGSERIAL(SQLType):
    """Auto-incrementing eight-byte integer."""


class BIT(SQLType):
    """Fixed-length bit string."""


class VARBIT(SQLType):
    """Variable-length bit string."""


class BOOLEAN(SQLType):
    """Logical Boolean (true/false)."""


class BOX(SQLType):
    """Rectangular box on a plane."""


class BYTEA(SQLType):
    """Binary data (“byte array”)."""


class CHAR(SQLType):
    """Fixed-length character string."""

    def __init__(self, fixed_length: int | None = None) -> None:
        """Instantiate a fuxed length character string.

        :param fixed_length: Length of the char.
        """
        self._fixed_length = fixed_length

    @override
    def __str__(self) -> str:
        """Get SQL keyword for this type."""
        if self._fixed_length:
            return f"CHAR({self._fixed_length})"
        return "CHAR"


class VARCHAR(SQLType):
    """Variable-length character string."""

    def __init__(self, variable_length: int | None = None) -> None:
        """Instantiate a `VARCHAR` type.

        :param variable_length: Maximum length of the varchar.
        """
        self._variable_length = variable_length

    @override
    def __str__(self) -> str:
        """Get SQL keyword for this type."""
        if self._variable_length:
            return f"VARCHAR({self._variable_length})"
        return "VARCHAR"


class CIDR(SQLType):
    """IPv4 or IPv6 network address."""


class CIRCLE(SQLType):
    """Circle on a plane."""


class DATE(SQLType):
    """Calendar date (year, month, day)."""


class DOUBLE(SQLType):
    """Double precision floating-point number (8 bytes)."""

    @override
    def __str__(self) -> str:
        """Get SQL keyword for this type."""
        return "DOUBLE PRECISION"


class INET(SQLType):
    """IPv4 or IPv6 host address."""


class INTEGER(SQLType):
    """Signed four-byte integer."""


class INTERVAL(SQLType):
    """Time span."""

    def __init__(self, fields: str | None = None, precision: int | None = None) -> None:
        """Instantiate an `INTERVAL` type.

        :param fields: Duration components, options are:
           ============ =======
           Abbreviation Meaning
           ============ =======
           Y            Years
           M            Months
           W            Weeks
           D            Days
           H            Hours
           S            Seconds
           ============ =======
        :param precision: Precisions of the interval.
        """
        self._fields = fields
        self._precision = precision

    @override
    def __str__(self) -> str:
        """Get SQL keyword for this type."""
        fields = f" {self._fields}" if self._fields else ""
        precision = f"({self._precision})" if self._precision else ""
        return f"INTERVAL{fields}{precision}"


class JSON(SQLType):
    """Textual JSON data."""


class JSONB(SQLType):
    """Binary JSON data, decomposed."""


class LINE(SQLType):
    """Infinite line on a plane."""


class LSEG(SQLType):
    """Line segment on a plane."""


class MACADDR(SQLType):
    """MAC (Media Access Control) address."""


class MACADDR8(SQLType):
    """MAC (Media Access Control) address (EUI-64 format)."""


class MONEY(SQLType):
    """Currency amount."""


class NUMERIC(SQLType):
    """Exact numeric of selectable precision."""

    def __init__(self, precision: int | None = None, scale: int | None = None) -> None:
        """Instantiate a `NUMERIC` type.

        :param precision: Preicision of the numeric.
        :param scale: Maximum number of decimal digits.
        """
        self._precision = precision
        self._scale = scale

    @override
    def __str__(self) -> str:
        """Get SQL keyword for this type."""
        if self._precision and self._scale:
            args = f"({self._precision}, {self._scale})"
        elif self._precision:
            args = f"({self._precision})"
        elif self._scale:
            msg = "Precision must be set if scale is"
            raise ValueError(msg)
        else:
            args = ""
        return f"NUMERIC{args}"


class PATH(SQLType):
    """Geometric path on a plane."""


# noinspection PyPep8Naming
class PG_LSN(SQLType):  # noqa: N801
    """PostgreSQL Log Sequence Number."""


# noinspection PyPep8Naming
class PG_SNAPSHOT(SQLType):  # noqa: N801
    """User-level transaction ID snapshot."""


class POINT(SQLType):
    """Geometric point on a plane."""


class POLYGON(SQLType):
    """Closed geometric path on a plane."""


class REAL(SQLType):
    """Single precision floating-point number (4 bytes)."""


class SMALLINT(SQLType):
    """Signed two-byte integer."""


class SMALLSERIAL(SQLType):
    """Auto-incrementing two-byte integer."""


class SERIAL(SQLType):
    """Auto-incrementing four-byte integer."""


class TEXT(SQLType):
    """Variable-length character string."""


class TIME(SQLType):
    """Time of day."""

    def __init__(
        self, precision: int | None = None, *, with_time_zone: bool = False
    ) -> None:
        """Instantiate a `TIME` type.

        :param precision: Precision of the time.
        :param with_time_zone: Whether timestamp is timezone aware.
        """
        self._precision = precision
        self._with_time_zone = with_time_zone

    @override
    def __str__(self) -> str:
        """Get SQL keyword for this type."""
        precision = f"({self._precision})" if self._precision else ""
        tz = " WITH TIME ZONE" if self._with_time_zone else ""
        return f"TIME{precision}{tz}"


class TIMESTAMP(SQLType):
    """Date and time."""

    def __init__(
        self, precision: int | None = None, *, with_time_zone: bool = False
    ) -> None:
        """Instantiate a `TIMESTAMP` type.

        :param precision: Precision of the timestamp.
        :param with_time_zone: Whether timestamp is timezone aware.
        """
        self._precision = precision
        self._with_time_zone = with_time_zone

    @override
    def __str__(self) -> str:
        """Get SQL keyword for this type."""
        precision = f"({self._precision})" if self._precision else ""
        tz = " WITH TIME ZONE" if self._with_time_zone else ""
        return f"TIMESTAMP{precision}{tz}"


class TSQUERY(SQLType):
    """Text search query."""


class TSVECTOR(SQLType):
    """Text search document."""


class UUID(SQLType):
    """Universally unique identifier."""


class XML(SQLType):
    """XML data."""
