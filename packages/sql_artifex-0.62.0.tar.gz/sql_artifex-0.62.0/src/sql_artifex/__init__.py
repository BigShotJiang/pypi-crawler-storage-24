"""Python PostgreSQL query builder."""

from __future__ import annotations

from typing import Any

from sql_artifex._common import (
    As,
    AsMixin,
    BooleanOperator,
    Column,
    Expression,
    OperatorMixin,
    QueryBuilder,
    StringBuilder,
    Table,
    alias,
)
from sql_artifex.builders import (
    Case,
    Delete,
    DictValues,
    DoNothing,
    DoUpdate,
    From,
    InsertInto,
    Join,
    LeftJoin,
    Limit,
    Literal,
    LogicGate,
    Offset,
    On,
    OnConflict,
    OrderBy,
    Paren,
    RightJoin,
    Select,
    Set,
    Then,
    Update,
    Values,
    When,
    Where,
)
from sql_artifex.functions import Cast, Function, Replace
from sql_artifex.types import SQLType

__all__ = (
    "As",
    "AsMixin",
    "Case",
    "Column",
    "Delete",
    "DictValues",
    "DoNothing",
    "DoUpdate",
    "Expression",
    "From",
    "InsertInto",
    "Join",
    "LeftJoin",
    "Limit",
    "LogicGate",
    "Offset",
    "On",
    "OnConflict",
    "OperatorMixin",
    "OrderBy",
    "QueryBuilder",
    "RightJoin",
    "Select",
    "Set",
    "StringBuilder",
    "Table",
    "Then",
    "Update",
    "Values",
    "When",
    "Where",
    "abs_",
    "alias",
    "cast",
    "date",
    "max_",
    "min_",
    "p",
)


def abs_(subquery: QueryBuilder) -> Function:
    """Build an `ABS` SQL function call.

    :param subquery: Expression to count.
    :return: `ABS` expression query builder.
    """
    return Function("ABS", subquery)


def and_(evaluation: Expression, *evaluations: Expression | LogicGate) -> LogicGate:
    """Build an `AND` expression for a part of a query."""
    return LogicGate(BooleanOperator.AND, evaluation, *evaluations)


def and_not(evaluation: Expression, *evaluations: Expression | LogicGate) -> LogicGate:
    """Build an `AND NOT` expression for a part of a query."""
    return LogicGate(BooleanOperator.AND_NOT, evaluation, *evaluations)


def cast(expression: QueryBuilder, sql_type: type[SQLType]) -> Cast:
    """Build a `CAST` SQL function call.

    :param expression: Value to cast.
    :param type: Type to cast to.
    :return: Cast query builder.
    """
    return Cast(expression, sql_type)


def count(subquery: QueryBuilder) -> Function:
    """Build a `COUNT` SQL function call.

    :param subquery: Expression to count.
    :return: `COUNT` expression query builder.
    """
    return Function("COUNT", subquery)


def date(subquery: QueryBuilder) -> Function:
    """Build a `DATE` SQL function expression.

    :param subquery: Expression to cast to `DATE`.
    :return: `DATE` expression query builder.
    """
    return Function("DATE", subquery)


def delete_from(table: type[Table]) -> Delete:
    """Build a `DELETE` query."""
    return Delete(table)


def insert_into(table: type[Table], *args: Column) -> InsertInto:
    """Create an `INSERT` query.

    :param table: Table to insert into.
    :param args: Columns to insert values into.
    :return: Insert query builder.
    """
    return InsertInto(table, *args)


def select(*args: Column | type[Table] | QueryBuilder) -> Select:
    """Build a `SELECT` query."""
    return Select(*args)


def update(table: type[Table]) -> Update:
    """Build an `UPDATE` query."""
    return Update(table)


def join(table: type[Table]) -> Join:
    """Build a `JOIN` query."""
    return Join(table)


def left_join(table: type[Table]) -> Join:
    """Build a `LEFT JOIN` query."""
    return LeftJoin(table)


def literal(value: str) -> QueryBuilder:
    """Use the provided value as-is in generated SQL.

    This function does not sanitize SQL, use sparingly.

    :param value: SQL string.
    """
    return Literal(value)


def lower(subquery: QueryBuilder | Any) -> Function:
    """Build a `LOWER` SQL expression.

    :param subquery: Query to make lower cse.
    :return: `LOWER` expression builder.
    """
    return Function("LOWER", subquery)


def right_join(table: type[Table]) -> Join:
    """Build a `RIGHT JOIN` query."""
    return RightJoin(table)


def max_(subquery: QueryBuilder | Any) -> Function:
    """Build a `MAX` SQL expression.

    :param subquery: Column or expression to select max of.
    :return: `MAX` expression query builder.
    """
    return Function("MAX", subquery)


def min_(subquery: QueryBuilder | Any) -> Function:
    """Build a `MIN` SQL expression.

    :param subquery: Column or expression to select min of.
    :return: `MIN` expression query builder.
    """
    return Function("MIN", subquery)


def sum_(subquery: QueryBuilder | Any) -> Function:
    """Build a `SUM` SQL expression.

    :param subquery: Column or expression to select sum results of.
    :return: `SUM` expression query builder.
    """
    return Function("SUM", subquery)


def or_(evaluation: Expression, *evaluations: Expression | LogicGate) -> LogicGate:
    """Build an `OR` expression for a part of a query."""
    return LogicGate(BooleanOperator.OR, evaluation, *evaluations)


def or_not(evaluation: Expression, *evaluations: Expression | LogicGate) -> LogicGate:
    """Build an `OR NOT` expression for a part of a query."""
    return LogicGate(BooleanOperator.OR_NOT, evaluation, *evaluations)


def replace(
    string_expression: str | QueryBuilder,
    string_pattern: str | QueryBuilder,
    string_replacement: str | QueryBuilder,
) -> Replace:
    """Build `REPLACE` SQL expression.

    :param string_expression: String to search.
    :param string_pattern: Pattern to search string for,
    :param string_replacement: Replacement for the matched pattern.
    :return: `REPLACE` espression query builder.
    """
    return Replace(
        string_expression,
        string_pattern,
        string_replacement,
    )


def case_(*clauses: Then, else_: QueryBuilder | None = None) -> Case:
    """Build a SQL `CASE` statement.

    :param clauses: Case when clauses.
    :param else_: `ELSE` statement.
    :return: `CASE` query builder.
    """
    return Case(*clauses, else_=else_)


def when(*conditions: Expression | LogicGate | Paren) -> When:
    """Build then `WHEN` clause of a `CASE` statement.

    :param condition: Conditions of the `WHEN` clause.
    :return: A `WHEN` query builder.
    """
    return When(*conditions)


def p(*queries: QueryBuilder) -> Paren:
    """Group expressions by parenthesis."""
    return Paren(*queries)
