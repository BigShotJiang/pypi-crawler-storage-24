import os
import argparse
import sys
import shutil
import stat
import fnmatch
import glob

try:
    from send2trash import send2trash as _send2trash
    _HAS_SEND2TRASH = True
except Exception:
    _HAS_SEND2TRASH = False

PROJECT_TARGETS = {
    'node': [
        'node_modules',
        'package-lock.json',
    ],
    'python': [
        '__pycache__',
        '.pytest_cache',
        '.mypy_cache',
        '.pyrightcache',
        '.venv',
        'venv',
        'env',
        '.coverage',
        'htmlcov',
        'pip-wheel-metadata',
        '*.pyc',
        '*.pyo',
        '*.pyd',
    ],
    'dotnet': [
        'bin',
        'obj',
        'packages',
        'TestResults',
        '*.dll',
        '*.pdb',
        '*.user',
        '*.suo',
        '*.nupkg',
    ],
}

BUILD_TARGETS = {
    'node': [
        'dist',
        'build',
        'npm-debug.log',
        'yarn-error.log',
    ],
    'python': [
        'build',
        'dist',
        '*.egg-info',
        'pip-wheel-metadata',
        '.eggs',
        '.tox',
    ],
    'dotnet': [
        'bin',
        'obj',
        'artifacts',
        'publish',
        '*.nupkg',
    ],
}

# color support: prefer colorama on Windows, fallback to ANSI sequences
try:
    from colorama import init as _colorama_init, Fore, Style
    _colorama_init()
    _HAS_COLOR = True
except Exception:
    _HAS_COLOR = False
    class Fore:
        GREEN = '\x1b[32m'
        YELLOW = '\x1b[33m'
        CYAN = '\x1b[36m'
        RED = '\x1b[31m'
        MAGENTA = '\x1b[35m'
        BLUE = '\x1b[34m'
        WHITE = '\x1b[37m'
    class Style:
        RESET_ALL = '\x1b[0m'


def _read_console_aliases():
    """Read console_scripts names from installed package metadata."""
    try:
        from importlib import metadata as importlib_metadata
    except Exception:
        return []

    try:
        dist = importlib_metadata.distribution('search-and-destroy')
        aliases = [ep.name for ep in dist.entry_points if ep.group == 'console_scripts']
        return sorted(set(aliases))
    except Exception:
        return []


# CLI version: read from setup.cfg to keep a single source of truth
def _read_version_from_setupcfg():
    try:
        from importlib import metadata as importlib_metadata
    except Exception:
        return '0.0.0'

    try:
        return importlib_metadata.version('search-and-destroy')
    except Exception:
        return '0.0.0'


def _rmtree_onerror(func, path, excinfo):
    # Attempt to clear read-only and retry
    try:
        os.chmod(path, stat.S_IWRITE)
    except Exception:
        pass
    try:
        func(path)
    except Exception:
        raise


def _clean_project(targets, dry_run=False, safe=False, force=False):
    if not targets:
        return []

    results = []
    cwd = os.getcwd()
    sadignore = _load_sadignore(cwd)

    # Iterate targets in the original order and append a single result per-target
    # so output is stable and matches the input ordering (e.g. node_modules first).
    for t in targets:
        name = os.path.basename(t)
        # determine relative path for ignore matching
        try:
            rel = os.path.relpath(t, cwd)
        except Exception:
            rel = name
        rel = os.path.normpath(rel)

        # honor .sadignore entries (even if target doesn't exist)
        if _is_ignored(rel, sadignore):
            results.append({'name': name, 'path': t, 'status': 'ignored'})
            continue

        if not os.path.exists(t):
            results.append({'name': name, 'path': t, 'status': 'not-found'})
            continue

        if dry_run:
            results.append({'name': name, 'path': t, 'status': 'would-remove', 'safe': safe})
            continue

        # If safe-delete requested but send2trash not available, report error for this target
        if safe and not _HAS_SEND2TRASH:
            results.append({'name': name, 'path': t, 'status': 'error', 'error': 'send2trash not installed', 'safe': safe})
            continue

        try:
            if safe:
                sys.stdout.flush()
                _send2trash(t)
                results.append({'name': name, 'path': t, 'status': 'removed', 'safe': True})
                continue

            # permanent delete
            if os.path.isdir(t):
                try:
                    shutil.rmtree(t, onerror=_rmtree_onerror)
                    results.append({'name': name, 'path': t, 'status': 'removed', 'safe': False})
                    continue
                except Exception as e:
                    if force:
                        try:
                            shutil.rmtree(t, onerror=_rmtree_onerror)
                            results.append({'name': name, 'path': t, 'status': 'removed', 'safe': False})
                            continue
                        except Exception as e2:
                            results.append({'name': name, 'path': t, 'status': 'error', 'error': str(e2), 'safe': False})
                            continue
                    results.append({'name': name, 'path': t, 'status': 'error', 'error': str(e), 'safe': False})
                    continue

            # file
            try:
                os.remove(t)
                results.append({'name': name, 'path': t, 'status': 'removed', 'safe': False})
                continue
            except Exception as e:
                if force:
                    try:
                        os.chmod(t, stat.S_IWRITE)
                        os.remove(t)
                        results.append({'name': name, 'path': t, 'status': 'removed', 'safe': False})
                        continue
                    except Exception as e2:
                        results.append({'name': name, 'path': t, 'status': 'error', 'error': str(e2), 'safe': False})
                        continue
                results.append({'name': name, 'path': t, 'status': 'error', 'error': str(e), 'safe': False})
                continue

        except Exception as e:
            results.append({'name': name, 'path': t, 'status': 'error', 'error': str(e), 'safe': safe})

    return results


def _color(text, color):
    return f"{color}{text}{Style.RESET_ALL}"


def _print_results_list(results):
    """Print results as bracketed status lines, two-space aligned and colored.

    Format examples:
      [REMOVED]  node_modules
      [NOT FOUND]  package-lock.json
      [ERROR]  package-lock.json
    """
    cwd = os.getcwd()
    for r in results:
        status = r.get('status')
        # prefer showing the path relative to cwd so nested paths are visible
        path = r.get('path') or r.get('name')
        try:
            display = os.path.relpath(path, cwd)
        except Exception:
            display = path
        # use forward slashes for readability across platforms
        display = display.replace(os.sep, '/')
        if status == 'removed':
            if r.get('safe'):
                tag = '[REMOVED]'
            else:
                tag = '[DELETED]'
            color = Fore.GREEN
        elif status == 'would-remove':
            if r.get('safe'):
                tag = '[DRY-RUN REMOVED]'
            else:
                tag = '[DRY-RUN DELETED]'
            color = Fore.GREEN
        elif status == 'not-found':
            tag = '[NOT FOUND]'
            color = Fore.YELLOW
        elif status == 'error':
            tag = '[ERROR]'
            color = Fore.RED
        elif status == 'ignored':
            tag = '[IGNORED]'
            color = Fore.BLUE
        else:
            tag = '[UNKNOWN]'
            color = Fore.RED

        line = f"  {tag} {display}"
        if status == 'error' and r.get('error'):
            line = f"{line}  -> {r.get('error')}"

        # color the whole line
        print(_color(line, color))

    
def _print_list(list_type=None):
    """Print a list of targets that would be removed if found, without performing any actions."""
    if list_type and list_type not in PROJECT_TARGETS:
        print(f"Unknown list type: {list_type}")
        return

    types_to_list = [list_type] if list_type else PROJECT_TARGETS.keys()
    for t in types_to_list:
        print(_color(f"{t}:", Fore.MAGENTA))
        # project-specific targets
        pt = PROJECT_TARGETS.get(t, [])
        if pt:
            for target in pt:
                print(_color(f"  {target}", Fore.CYAN))
        else:
            print(_color("  (no project artifacts)", Fore.CYAN))

        # build targets (always shown for `list`)
        bt = BUILD_TARGETS.get(t, [])
        if bt:
            for b in bt:
                print(_color(f"  (-all) {b}", Fore.BLUE))
        else:
            print(_color("  (no build artifacts)", Fore.BLUE))


def _find_files_recursively(targets_to_find, current_dir=os.getcwd()):
    """Recursively find files and directories matching any name in
    `targets_to_find` under `current_dir` and return their paths
    relative to `current_dir` using forward slashes.

    Directories that match will be returned and not descended into.
    """
    if not targets_to_find:
        return []

    # (do not filter by .sadignore here; menu will show ignored items)

    targets_set = set(targets_to_find)
    results = []
    seen = set()
    # Support exact-name matches and glob-pattern matches (e.g. '*.pyc')
    exact_names = set()
    patterns = []
    for t in targets_to_find:
        if any(c in t for c in ('*', '?', '[')):
            patterns.append(t)
        else:
            exact_names.add(t)

    # Walk the tree top-down so we can prevent descending into matched dirs
    for root, dirs, files in os.walk(current_dir, topdown=True):
        # check directories first; copy list because we'll mutate `dirs`
        for d in list(dirs):
            match_dir = False
            if d in exact_names:
                match_dir = True
            else:
                for pat in patterns:
                    if fnmatch.fnmatchcase(d, pat):
                        match_dir = True
                        break
            if match_dir:
                full = os.path.join(root, d)
                rel = os.path.relpath(full, current_dir)
                # keep paths OS-native to avoid invalid syntax on Windows
                rel = os.path.normpath(rel)
                if rel == '.':
                    rel = d
                if rel not in seen:
                    results.append(rel)
                    seen.add(rel)
                # don't walk into this directory
                try:
                    dirs.remove(d)
                except ValueError:
                    pass

        # check files
        for f in files:
            match_file = False
            if f in exact_names:
                match_file = True
            else:
                for pat in patterns:
                    if fnmatch.fnmatchcase(f, pat):
                        match_file = True
                        break
            if match_file:
                full = os.path.join(root, f)
                rel = os.path.relpath(full, current_dir)
                rel = os.path.normpath(rel)
                if rel not in seen:
                    results.append(rel)
                    seen.add(rel)

    return results


def _get_targets(types, all):
    targets = []
    types_to_scan = types if types else PROJECT_TARGETS.keys()
    for t in types_to_scan:
        targets += PROJECT_TARGETS.get(t, [])
        if all:
            targets += BUILD_TARGETS.get(t, [])
    return targets


def _expand_targets_in_dir(targets, current_dir=os.getcwd()):
    """Given a list of target names or glob patterns, expand any globs
    inside `current_dir` and return absolute paths preserving order.

    If a glob pattern matches nothing, include the literal joined path
    so the caller can report it as not found.
    """
    out = []
    seen = set()
    for t in targets:
        if any(c in t for c in ('*', '?', '[')):
            matches = glob.glob(os.path.join(current_dir, t))
            if matches:
                for m in matches:
                    p = os.path.normpath(m)
                    if p not in seen:
                        out.append(p)
                        seen.add(p)
            else:
                # include literal (not found) for user feedback
                literal = os.path.normpath(os.path.join(current_dir, t))
                if literal not in seen:
                    out.append(literal)
                    seen.add(literal)
        else:
            p = os.path.normpath(os.path.join(current_dir, t))
            if p not in seen:
                out.append(p)
                seen.add(p)
    return out


def _load_sadignore(current_dir=os.getcwd()):
    """Load .sadignore from current_dir and return a matcher.

    Returns None when no file found. If `pathspec` is available it is used
    for full gitignore semantics; otherwise a simple fallback matcher is
    returned that supports glob patterns and negation (!) evaluated in order.
    """
    path = os.path.join(current_dir, '.sadignore')
    if not os.path.exists(path):
        return None

    try:
        import pathspec
        with open(path, 'r', encoding='utf-8') as fh:
            lines = fh.readlines()
        spec = pathspec.PathSpec.from_lines('gitwildmatch', lines)
        return ('pathspec', spec)
    except Exception:
        # fallback: load trimmed non-comment lines preserving order
        patterns = []
        with open(path, 'r', encoding='utf-8') as fh:
            for ln in fh:
                s = ln.rstrip('\n')
                if not s or s.lstrip().startswith('#'):
                    continue
                patterns.append(s)
        return ('fallback', patterns)


def _is_ignored(relpath, sadignore):
    """Return True if relpath (OS-native, relative to repo) is ignored.

    `sadignore` is the object returned from `_load_sadignore`.
    """
    if not sadignore:
        return False
    typ, data = sadignore
    # normalize to posix-style for matching
    relpos = relpath.replace(os.sep, '/')
    if typ == 'pathspec':
        try:
            return bool(data.match_file(relpos))
        except Exception:
            return False

    # fallback evaluation: apply patterns in order; `!` negates
    ignored = False
    for pat in data:
        p = pat
        neg = False
        if p.startswith('!'):
            neg = True
            p = p[1:]
        p = p.strip()
        if not p:
            continue
        # If pattern contains a slash, match against the full relative path
        if '/' in p:
            match = fnmatch.fnmatchcase(relpos, p)
        else:
            # otherwise match against any path component
            comps = relpos.split('/')
            match = any(fnmatch.fnmatchcase(c, p) for c in comps)
        if match:
            ignored = not neg
    return ignored


def _nuke(nuke_types, dry_run, safe, force, all):
    targets_to_find = _get_targets(nuke_types, all)
    targets_to_delete = _find_files_recursively(targets_to_find)
    results = _clean_project(targets=targets_to_delete, dry_run=dry_run, safe=safe, force=force)
    _print_results_list(results)


def _menu(dry_run, safe, force, all):
    targets_to_find = _get_targets(types=None, all=all)
    targets_to_prompt = _find_files_recursively(targets_to_find)

    cwd = os.getcwd()

    # Prepare option toggles (top section)
    options = [
        {'key': 'dry_run', 'label': 'Dry Run', 'value': bool(dry_run), 'desc': 'Show what would be removed without deleting'},
        {'key': 'safe', 'label': 'Safe (send2trash)', 'value': bool(safe), 'desc': 'Move files to recycle/trash instead of permanent delete'},
        {'key': 'force', 'label': 'Force', 'value': bool(force), 'desc': 'Ignore errors and try to fix permissions before failing'},
    ]

    # Targets default to not selected (user chooses which to delete)
    sadignore = _load_sadignore(cwd)
    targets = []
    for p in targets_to_prompt:
        ignored = _is_ignored(p, sadignore)
        targets.append({'path': p, 'selected': False, 'ignored': bool(ignored)})

    if not targets:
        print(_color('  [INFO] No targets found.', Fore.YELLOW))
        return

    # cross-platform single-key reader
    def _getkey():
        try:
            # Windows
            import msvcrt
            ch = msvcrt.getwch()
            if ch == '\x00' or ch == '\xe0':
                ch2 = msvcrt.getwch()
                if ch2 == 'H':
                    return 'UP'
                if ch2 == 'P':
                    return 'DOWN'
                if ch2 == 'K':
                    return 'LEFT'
                if ch2 == 'M':
                    return 'RIGHT'
                return None
            if ch == '\r':
                return 'ENTER'
            if ch == '\x1b':
                return 'ESC'
            if ch == '\t':
                return 'TAB'
            return ch
        except Exception:
            # POSIX
            import sys, tty, termios
            fd = sys.stdin.fileno()
            old = termios.tcgetattr(fd)
            try:
                tty.setraw(fd)
                ch = sys.stdin.read(1)
                if ch == '\x1b':
                    # possible escape sequence
                    nxt = sys.stdin.read(2)
                    if nxt == '[A':
                        return 'UP'
                    if nxt == '[B':
                        return 'DOWN'
                    if nxt == '[D':
                        return 'LEFT'
                    if nxt == '[C':
                        return 'RIGHT'
                    return 'ESC'
                if ch == '\r' or ch == '\n':
                    return 'ENTER'
                if ch == '\t':
                    return 'TAB'
                return ch
            finally:
                termios.tcsetattr(fd, termios.TCSADRAIN, old)

    def clear_screen():
        os.system('cls' if os.name == 'nt' else 'clear')
    # paging state
    page_offset = 0

    def render_menu(cursor):
        clear_screen()
        print(_color('Search and Destroy', Fore.CYAN))
        print('    Use ↑/↓ to move, TAB to toggle, a toggle all, d/s/f toggle options, ENTER confirm, ESC cancel')
        # Options
        print(_color('Options:', Fore.MAGENTA))
        for i, opt in enumerate(options, start=0):
            mark = '[x]' if opt['value'] else '[ ]'
            pointer = '>' if cursor == i else ' '
            print(f" {pointer} {mark} {opt['label']}: {opt['desc']}")

        # Targets (paged)
        start = len(options)
        print(_color('Targets:', Fore.MAGENTA))
        try:
            term_lines = shutil.get_terminal_size().lines
        except Exception:
            term_lines = 24
        page_size = max(3, term_lines - (len(options) + 8))
        page_size = min(page_size, max(3, len(targets)))

        vis_start = page_offset
        vis_end = min(len(targets), vis_start + page_size)
        for j in range(vis_start, vis_end):
            t = targets[j]
            idx = start + j
            pointer = '>' if cursor == idx else ' '
            if t.get('ignored'):
                mark = '[-]'
                print(f" {pointer} {mark} [IGNORED] {t['path']}")
            else:
                mark = '[x]' if t['selected'] else '[ ]'
                print(f" {pointer} {mark} {t['path']}")

        if len(targets) > page_size:
            print(_color(f"\n  (showing {vis_start+1}-{vis_end} of {len(targets)}) Use ←/→ or Space to page.", Fore.CYAN))

    cursor = 0
    total_lines = len(options) + len(targets)

    while True:
        render_menu(cursor)
        k = _getkey()
        if not k:
            continue
        if k == 'UP':
            cursor = (cursor - 1) % total_lines
            # ensure visible
            if cursor >= len(options):
                rel = cursor - len(options)
                if rel < page_offset:
                    page_offset = rel
            continue
        if k == 'DOWN':
            cursor = (cursor + 1) % total_lines
            if cursor >= len(options):
                rel = cursor - len(options)
                try:
                    term_lines = shutil.get_terminal_size().lines
                except Exception:
                    term_lines = 24
                page_size = max(3, term_lines - (len(options) + 8))
                if rel >= page_offset + page_size:
                    page_offset = rel - page_size + 1
            continue
        if k == 'TAB':
            # toggle at cursor
            if cursor < len(options):
                options[cursor]['value'] = not options[cursor]['value']
            else:
                tidx = cursor - len(options)
                if not targets[tidx].get('ignored'):
                    targets[tidx]['selected'] = not targets[tidx]['selected']
                # ignored items are not selectable
            continue
        # paging: next/prev page (use right/left arrows or Space)
        if k == 'RIGHT' or k == ' ':
            try:
                term_lines = shutil.get_terminal_size().lines
            except Exception:
                term_lines = 24
            page_size = max(3, term_lines - (len(options) + 8))
            page_offset = min(max(0, len(targets) - page_size), page_offset + page_size)
            cursor = len(options) + page_offset
            continue
        if k == 'LEFT':
            try:
                term_lines = shutil.get_terminal_size().lines
            except Exception:
                term_lines = 24
            page_size = max(3, term_lines - (len(options) + 8))
            page_offset = max(0, page_offset - page_size)
            cursor = len(options) + page_offset
            continue
        # handle ESC (returned as the token 'ESC') or single-char commands
        if k == 'ESC' or (isinstance(k, str) and k.lower() == 'q'):
            print(_color('  [ABORTED] No changes made.', Fore.YELLOW))
            return
        if isinstance(k, str) and len(k) == 1:
            if k.lower() == 'a':
                any_selected = any(t['selected'] for t in targets if not t.get('ignored'))
                for t in targets:
                    if not t.get('ignored'):
                        t['selected'] = not any_selected
                continue
            if k.lower() == 'd':
                options[0]['value'] = not options[0]['value']
                continue
            if k.lower() == 's':
                options[1]['value'] = not options[1]['value']
                continue
            if k.lower() == 'f':
                options[2]['value'] = not options[2]['value']
                continue
        if k == 'ENTER':
            break

    # Build final selection
    final_options = {opt['key']: opt['value'] for opt in options}
    selected_targets = [os.path.normpath(os.path.join(cwd, t['path'])) for t in targets if t['selected']]

    if not selected_targets:
        print(_color('  [INFO] No targets selected, aborting.', Fore.YELLOW))
        return

    # Perform the deletion/preview
    results = _clean_project(targets=selected_targets, dry_run=final_options.get('dry_run', False), safe=final_options.get('safe', False), force=final_options.get('force', False))
    _print_results_list(results)


def _animation():
    try:
        # import lazily to avoid startup overhead and circular imports
        from classes.animation import Animation
    except Exception:
        return

    anim = Animation("sad_face")
    # Play once (no loop) with a short delay between frames in cyan
    try:
        anim.play(delay=0.1, loop=False, clear_screen=True, color=Fore.BLUE)
    except Exception:
        # fallback if Fore isn't available or coloring fails
        anim.play(delay=0.1, loop=False, clear_screen=True)

def main():
    # support simple CLI subcommands (e.g. `sad list` or `sad node`)
    # build epilog with examples
    epilog_lines = [
        'Commands:',
        f'  %(prog)s [-h|--help] [-v|--version] [-d|--dry-run] [-y|--yes] [-a|--all] [-y|--force] [-s|--safe] [cmd]',
        f'  %(prog)s list [-h] [type]',
        f'  %(prog)s nuke [-h] [-d] [-y] [-a] [-y] [-s] [type1 type2 ...]',
    ]
    aliases = _read_console_aliases()
    if aliases:
        epilog_lines.append('\nAliases: ' + ', '.join(aliases))
    epilog = '\n'.join(epilog_lines) + '\n'

    parser = argparse.ArgumentParser(
        prog=os.path.basename(sys.argv[0]) or 'sad',
        description='Start from scratch with your project build files.',
        epilog=epilog,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    # standard --version support
    parser.add_argument('-version', '--version', action='version', version=f"%(prog)s {_read_version_from_setupcfg()}")
    # top-level options (no subcommand): default behavior is to clean Node targets
    parser.add_argument('-dry-run', '--dry-run', action='store_true', help='Show what would be removed without deleting')
    parser.add_argument('-yes', '--yes', action='store_true', help='Assume yes for confirmation prompts')
    parser.add_argument('-all', '--all', action='store_true', help='Clean all targets (including build artifacts)')
    parser.add_argument('-force', '--force', action='store_true', help='Ignore errors and exit 0 on failures')
    parser.add_argument('-safe', '--safe', action='store_true', help='Move files to recycle/trash instead of permanent delete (requires send2trash)')

    # Subparsers for commands and project types
    subparsers = parser.add_subparsers(dest='cmd')
    ## Commands (e.g. `sad list`)
    list_cmd = subparsers.add_parser('list', help='List project and build artifact names (no deletion)')
    list_cmd.add_argument('list_type', nargs='?', choices=list(PROJECT_TARGETS.keys()), help='Type of targets to list (default: all)')
    nuke_cmd = subparsers.add_parser('nuke', help='Recursively find and remove matching project/build artifacts')
    nuke_cmd.add_argument('nuke_type', nargs='*', choices=list(PROJECT_TARGETS.keys()), help='One or more types to nuke (default: all)')
    ## Types (e.g. `sad node`)
    subparsers.add_parser('node', help='Node.js project targets')
    subparsers.add_parser('python', help='Python project targets')
    subparsers.add_parser('dotnet', help='Dotnet / .NET project targets')

    args = parser.parse_args()

    # If no command was provided, show a helpful message and print help
    if not getattr(args, 'cmd', None):
        _animation()
        _menu(dry_run=args.dry_run, safe=args.safe, force=args.force, all=args.all)
        sys.exit(0)

    # Handle Commands first (e.g. `sad list`)
    if args.cmd == 'list':
        _print_list(args.list_type)
        sys.exit(0)

    if args.cmd == 'nuke':
        # Confrimation before nuking (skip prompt when --yes)
        if not args.yes:
            prompt = f"  [INPUT] Recursively delete all {args.nuke_type or 'project'} artifacts? [y/N]: "
            ans = input(_color(prompt, Fore.CYAN))
            if not ans.lower().startswith('y'):
                print(_color('  [ABORTED] No changes made.', Fore.YELLOW))
                sys.exit(0)
        _nuke(args.nuke_type, dry_run=args.dry_run, safe=args.safe, force=args.force, all=args.all)
        sys.exit(0)

    # confirmation before cleaning (skip prompt when --yes)
    if not args.yes:
        action = 'Forcibly delete' if args.force else 'Remove' if args.safe else 'Delete'
        prompt = f"  [INPUT] {action} {args.cmd} artifacts? [y/N]: "
        ans = input(_color(prompt, Fore.CYAN))
        if not ans.lower().startswith('y'):
            print(_color('  [ABORTED] No changes made.', Fore.YELLOW))
            sys.exit(0)

    cwd = os.getcwd()
    # expand patterns (e.g. '*.egg-info') into actual paths in cwd
    raw_targets = list(PROJECT_TARGETS.get(args.cmd, []))
    if args.all:
        raw_targets += BUILD_TARGETS.get(args.cmd, [])
    targets = _expand_targets_in_dir(raw_targets, cwd)

    # perform project-specific cleaning
    results = _clean_project(targets=targets, dry_run=args.dry_run, safe=args.safe, force=args.force)

    # print results with colors
    _print_results_list(results)

    # exit non-zero if any errors and not forced
    has_error = any(r.get('status') == 'error' for r in results)
    if has_error and not args.force:
        sys.exit(1)
    sys.exit(0)

    # If no command, show usage
    parser.print_usage()
    sys.exit(0)


if __name__ == '__main__':
    main()
