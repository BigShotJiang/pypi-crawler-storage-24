"""Animation helper class.

Uses `ANIMATIONS` from `classes.animations` and exposes a simple
`Animation` class that selects the first animation by default.
"""
from __future__ import annotations

import os
import time
from typing import List, Optional, Union

from .animations import ANIMATIONS
try:
    from colorama import Style
    _RESET = Style.RESET_ALL
except Exception:
    _RESET = '\x1b[0m'


class Animation:
    """A simple animation player for terminal-rendered frame lists.

    The animation source `ANIMATIONS` may be either a list (indexed) or a
    mapping of names -> frames. The constructor accepts either an integer
    index or a string name to select the animation. When no selector is
    provided and `ANIMATIONS` is a mapping, the default name `"sad_face"`
    will be chosen when present, otherwise the first available animation.
    """

    def __init__(self, selector: Optional[Union[int, str]] = None):
        self._index = 0
        self._name: Optional[str] = None
        self._frames: List[str] = []
        self._frame_idx = 0
        if ANIMATIONS:
            self.select(selector)

    def select(self, selector: Optional[Union[int, str]]) -> None:
        """Select animation by integer index or string name. Resets frame index."""
        if not ANIMATIONS:
            self._frames = []
            self._index = 0
            self._name = None
            self._frame_idx = 0
            return

        # Named animations (mapping)
        if isinstance(ANIMATIONS, dict):
            keys = list(ANIMATIONS.keys())
            # default selection: 'sad_face' if present, else first key
            if selector is None:
                sel_name = 'sad_face' if 'sad_face' in ANIMATIONS else keys[0]
            elif isinstance(selector, int):
                sel_name = keys[int(selector) % len(keys)]
            else:
                sel_name = selector if selector in ANIMATIONS else keys[0]

            self._name = sel_name
            self._index = keys.index(sel_name)
            self._frames = list(ANIMATIONS[sel_name])
            self._frame_idx = 0
            return

        # Sequence-style animations (list)
        # treat selector as index
        seq = list(ANIMATIONS)
        if selector is None:
            idx = 0
        else:
            try:
                idx = int(selector) % len(seq)
            except Exception:
                idx = 0
        self._index = idx
        self._name = None
        self._frames = list(seq[self._index])
        self._frame_idx = 0

    @property
    def index(self) -> int:
        return self._index

    @property
    def name(self) -> Optional[str]:
        return self._name

    @property
    def frames(self) -> List[str]:
        return list(self._frames)

    def current(self) -> str:
        """Return current frame string (empty string if none)."""
        if not self._frames:
            return ''
        return self._frames[self._frame_idx]

    def next(self) -> str:
        """Advance to next frame and return it."""
        if not self._frames:
            return ''
        self._frame_idx = (self._frame_idx + 1) % len(self._frames)
        return self.current()

    def prev(self) -> str:
        """Step to previous frame and return it."""
        if not self._frames:
            return ''
        self._frame_idx = (self._frame_idx - 1) % len(self._frames)
        return self.current()

    def reset(self) -> None:
        """Reset to the first frame."""
        self._frame_idx = 0

    def play(self, delay: float = 0.1, loop: bool = False, clear_screen: bool = True, color: Optional[str] = None) -> None:
        """Play animation to the terminal.

        - `delay` controls seconds between frames.
        - If `loop` is True, animation repeats until interrupted.
        - If `clear_screen` is True, the terminal is cleared before each frame.
        """
        if not self._frames:
            return

        try:
            while True:
                for f in self._frames:
                    if clear_screen:
                        os.system('cls' if os.name == 'nt' else 'clear')
                    if color:
                        print(f"{color}{f}{_RESET}")
                    else:
                        print(f)
                    time.sleep(delay)
                if not loop:
                    break
        except KeyboardInterrupt:
            # allow graceful stop
            if clear_screen:
                os.system('cls' if os.name == 'nt' else 'clear')
            return

    def __len__(self) -> int:
        return len(self._frames)

    def __repr__(self) -> str:
        return f"Animation(index={self._index}, frames={len(self._frames)})"
