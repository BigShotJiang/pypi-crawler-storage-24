# search-and-destroy

Build files be gone! search-and-destroy is a CLI tool to clean up build files from all types of tech stacks. It’s like a Roomba for your project directory, but instead of dust, it sucks up those pesky `node_modules/`, `build/`, and `*.egg-info/` folders.

## Requirements
- Python 3.8+

> **Caution:** It's strongly recommended to run `sad` with `--dry-run` first and add a `.sadignore` file to protect any files or folders you don't want removed.

## Quick start
```powershell
# Run search-and-destroy to remove build files
sad

# Examples
sad list
sad list node
sad --dry-run nuke node
sad --all --yes node
sad --dry-run python
sad --dry-run dotnet
```

## Commands
- `list [type]` — Show project and build artifact names that would be removed for `type` (default: all).
- `nuke [type1 type2 ...]` — Recursively find and remove matching targets for the named project types (default: all). Use `--dry-run` to preview.
- `node`, `python`, `dotnet` etc. — Run the cleaner for a single project type.

Options (common): `--dry-run`, `--yes`, `--all`, `--force`, `--safe`.

Aliases available: `search-and-destroy`

## License
- MIT

## Ignoring paths with .sadignore

Create a file named `.sadignore` in the repository root to prevent `sad` from listing or removing paths that would otherwise match targets. The file follows gitignore-style patterns when the `pathspec` package is installed; otherwise a simple glob-based fallback is used.

Examples:

- Ignore a directory anywhere in the tree:

	ignorethis/
	somedir/ignorethis

- Ignore a specific file:

  node_modules
  package-lock.json

- Anchor to repository root (requires `pathspec` for gitwildmatch semantics):

	/ignorethis/

- Negate a pattern (allow a subfolder):

	ignorethis/
	!ignorethis/keep/

Run `sad --dry-run` to preview deletions; `.sadignore` entries are respected in the preview.

# Changelog

All notable changes to this project will be documented in this file.

## 2026.0.0
- Initial release as search-and-destroy.

## 2026.1.0
- Added animation to menu.

## 2026.1.1
- Added `__init__.py` to classes package to ensure it is included in the distribution.
