from typing import Optional, Union
from annotated_types import T
import requests
from abc import ABC

class HandlerBase(ABC):

    handler_type = "base"

    def __init__(self, woocommerce_base_url: str, woocommerce_auth: tuple[str], session= None):
        self.woocommerce_base_url = woocommerce_base_url
        self.formatted_url = f'{self.woocommerce_base_url}wp-json/wc/v3/products/{self.handler_type}'
        self.auth = woocommerce_auth
        self.session = session or requests.Session()

    def retrieve(self, **kwargs) -> list[dict]:
        res = self.session.get(
            url=self.formatted_url,
            auth=self.auth,
            params={k:v for k,v in kwargs.items()} if kwargs else None
        )
        res.raise_for_status()
        return res.json()
    
    def retrieve_single(self, id: Union[str, int]) -> dict:
        res = self.session.get(
            url=f'{self.formatted_url}/{id}',
            auth=self.auth
        )
        res.raise_for_status()
        return res.json()
    
    def create(self, item: T) -> dict:
        res = self.session.post(
            url=self.formatted_url,
            auth=self.auth,
            data=item
        )
        res.raise_for_status()
        return res.json()
    
    def delete(self, id: Union[int, str], force: bool = False):
        res = self.session.delete(
            url=f'{self.formatted_url}/{id}',
            auth=self.auth,
            params={"force":force}
        )
        res.raise_for_status()
        return res.json()
    
    def batch_update(self, create: Optional[list[dict]], update: Optional[list[dict]], delete: Optional[list[int]]):
        d = {}
        if create:
            d["create"] = create
        if update:
            d["update"] = update
        if delete:
            d["delete"] = delete
        res = self.session.post(
            url=f'{self.formatted_url}/batch',
            auth=self.auth,
            data=d
        )
        res.raise_for_status()
        return res.json()
