# Fastersave
To read, write and append while taking less space in your code.

## EXAMPLES
_Using standard file handling_
```
with open("file.txt", "r") as f:
    x = f.read()
```
_Using Fastersave_
```
from fastersave import FasterSave
FasterSave.write("file.txt", "new content")
```
When these operations are repeated accross a project, Fastersave helps reduce boilerplate and keep your code more concise.
You can also choose an alias for shorter use:
```
from fastersave import FasterSave
fsa = FasterSave()
fsa.write("file.txt", "new content")
```
In larger projects with many file operations, this can reduce repetitive code and improve readability, especially when the same patterns are used repeatedly.