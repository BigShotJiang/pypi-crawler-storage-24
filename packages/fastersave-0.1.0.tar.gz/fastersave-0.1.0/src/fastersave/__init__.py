# IMPORTS
from pathlib import Path

# VAR THAT MAY BE NEEDED
BASE_DIR = Path(__file__).resolve().parent

class FasterSave:
    # READING
    @staticmethod
    def read(location, mode="r"):
        with open(location, mode) as f:
            return f.read()

    # WRITING
    @staticmethod
    def write(location, content, mode="w"):
        with open(location, mode) as f:
            f.write(content)

    # APPENDING
    @staticmethod
    def append(location, content, mode="a"):
        with open(location, mode) as f:
            f.write(content)

def helper(x="general.txt"):
    file_path = BASE_DIR / "helper" / x
    with open(file_path, "r") as f:
        return f.read()