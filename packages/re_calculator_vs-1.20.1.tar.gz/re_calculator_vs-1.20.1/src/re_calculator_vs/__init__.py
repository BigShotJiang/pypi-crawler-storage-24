def vs_cal():
    from calculating_fix_vmaxstudios import calfx

    while True:


        print("[Tachenrechner.exe] - Operatorauswahl (Optionen: +, -, *, /)")

        opinput = input()

        if opinput == "+":
    
    
            print("[Tachenrechner.exe - Addition] - Gebe den ersten Summanden ein")
            addinput1 = calfx()

            print("[Tachenrechner.exe - Addition] - Gebe den zweiten Summanden ein")
            addinput2 = calfx()

            print("[Tachenrechner.exe - Ergebnis]","Das Ergebnis der Rechenaufgabe ist:",addinput1+addinput2)


            print()
            print()
            print()
            print()
            print()
            print()
            print()
            print()
            print()
        

        elif opinput == "-":

    
            print("[Tachenrechner.exe - Addition] - Gebe den Minuend ein")
            subinput1 = calfx()

            print("[Tachenrechner.exe - Addition] - Gebe den Subtrahend ein")
            subinput2 = calfx()

            print("[Tachenrechner.exe - Ergebnis]","Das Ergebnis der Rechenaufgabe ist:",subinput1-subinput2)


            print()
            print()
            print()
            print()
            print()
            print()
            print()
            print()
            print()


        elif opinput == "*":

    
            print("[Tachenrechner.exe - Multiplikation] - Gebe den ersten Faktor ein")
            mulinput1 = calfx()

            print("[Tachenrechner.exe - Multiplikation] - Gebe den zweiten Faktor ein")
            mulinput2 = calfx()

            print("[Tachenrechner.exe - Ergebnis]","Das Ergebnis der Rechenaufgabe ist:",mulinput1*mulinput2)

            print()
            print()
            print()
            print()
            print()
            print()
            print()
            print()
            print()

        

        elif opinput == "/":

    
            print("[Tachenrechner.exe - Division] - Gebe den Divident ein")
            divinput1 = calfx()

            print("[Tachenrechner.exe - Division] - Gebe den Divisor ein")
            divinput2 = calfx()


            if divinput2 == 0:

                print("Du kannst nicht durch",divinput2,"teilen!")

            else:

                print("[Tachenrechner.exe - Ergebnis]","Das Ergebnis der Rechenaufgabe ist:",divinput1/divinput2)


            print()
            print()
            print()
            print()
            print()
            print()
            print()
            print()
            print()


        else:

    
            print("[Taschenrechner.exe - Fehler]","Du kannst nur ""+"", ""-"", ""*"", ""/"" verwenden")

        
            print()
            print()
            print()
            print()
            print()
            print()
            print()
            print()
            print()
    
