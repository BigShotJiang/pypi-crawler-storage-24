import matplotlib.pyplot as plt
import coil_geom as cg

c_c_up = cg.CircleCoil(p_dist=0.7)
c_c_dn = cg.CircleCoil()

c_e_up = cg.EllipseCoil(p_dist=0.7)
c_e_dn = cg.EllipseCoil()

c_es_up = cg.EllipseCoilShape(p_dist=0.7)
c_es_dn = cg.EllipseCoilShape()

c_ec_up = cg.EllipseCoilCurvature(p_dist=0.7)
c_ec_dn = cg.EllipseCoilCurvature()

c_c_up_x , c_c_up_y  = c_c_up .create_geom()
c_c_dn_x , c_c_dn_y  = c_c_dn .create_geom()
c_e_up_x , c_e_up_y  = c_e_up .create_geom()
c_e_dn_x , c_e_dn_y  = c_e_dn .create_geom()
c_es_up_x, c_es_up_y = c_es_up.create_geom()
c_es_dn_x, c_es_dn_y = c_es_dn.create_geom()
c_ec_up_x, c_ec_up_y = c_ec_up.create_geom()
c_ec_dn_x, c_ec_dn_y = c_ec_dn.create_geom()

plt.subplot(4,2,1)
plt.plot(c_c_up_x , c_c_up_y  )
plt.gca.set_aspect("equal")

plt.subplot(4,2,2)
plt.plot(c_c_dn_x , c_c_dn_y  )
plt.gca.set_aspect("equal")

plt.subplot(4,2,3)
plt.plot(c_e_up_x , c_e_up_y  )
plt.gca.set_aspect("equal")

plt.subplot(4,2,4)
plt.plot(c_e_dn_x , c_e_dn_y  )
plt.gca.set_aspect("equal")

plt.subplot(4,2,5)
plt.plot(c_es_up_x, c_es_up_y )
plt.gca.set_aspect("equal")

plt.subplot(4,2,6)
plt.plot(c_es_dn_x, c_es_dn_y )
plt.gca.set_aspect("equal")

plt.subplot(4,2,7)
plt.plot(c_ec_up_x, c_ec_up_y )
plt.gca.set_aspect("equal")

plt.subplot(4,2,8)
plt.plot(c_ec_dn_x, c_ec_dn_y )
plt.gca.set_aspect("equal")

plt.show()
