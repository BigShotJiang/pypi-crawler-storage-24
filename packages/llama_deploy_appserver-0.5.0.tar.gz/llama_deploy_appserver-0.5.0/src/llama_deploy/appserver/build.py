"""
Build entry point for creating deployment artifacts.

Usage: python -m llama_deploy.appserver.build
"""

from llama_deploy.appserver.bootstrap import run_build

if __name__ == "__main__":
    run_build()
