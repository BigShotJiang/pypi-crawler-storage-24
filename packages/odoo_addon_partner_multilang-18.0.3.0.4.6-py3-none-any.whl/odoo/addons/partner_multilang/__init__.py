#  Part of Odoo. See LICENSE file for full copyright and licensing details
from . import models
from .hooks import pre_init_hook, post_init_hook, uninstall_hook
