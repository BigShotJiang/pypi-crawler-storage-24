# Changelog

All notable changes to the partner_multilang module will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/), and
this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [18.0.3.0.4] - 2026-03-01

### Added

- Post-install tests for multilingual complete name and domain cleanup

## [18.0.3.0.3] - 2026-03-01

### Added

- Initial changelog entry
- Post-install tests for multilingual complete name and domain cleanup
