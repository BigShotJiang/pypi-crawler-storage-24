"""
Finch Colors
------------
Finch system design color palette, usable in Python projects
(e.g. Matplotlib, Plotly, Bokeh, etc.).
"""

colors = {
    "sky": {
        "darkest": "#073048",
        "dark":    "#004C70",
        "base":    "#095B87",
        "light":   "#0886CA",
    },
    "slate": {
        "dark":    "#464B53",
        "mid":     "#334256",
        "base":    "#64768D",
        "light":   "#C1D3E3",
    },
    "finch": {
        "teal":        "#004B71",
        "white":       "#F0F5F9",
        "cyan":        "#52BEE2",
        "blue":        "#7DA9CD",
        "sky_hover":   "#9ACFFC",
        "charcoal":    "#47484A",
        "mist_hover":  "#CED7DC",
        "navy_hover":  "#0E3B55",
    },
}

# Convenience flat aliases
sky   = colors["sky"]
slate = colors["slate"]
finch = colors["finch"]

__all__ = ["colors", "sky", "slate", "finch"]