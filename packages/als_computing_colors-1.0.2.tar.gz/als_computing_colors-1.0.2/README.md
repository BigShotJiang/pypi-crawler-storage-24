# ALS Computing Colors

Shared color palette published to both npm and PyPI.

## Install

### npm (Tailwind preset)

```bash
npm install @als-computing/colors
```

### PyPI (Python package)

```bash
pip install als-computing-colors
```

## Usage

### Tailwind CSS

```js
// tailwind.config.js
const alsColors = require('@als-computing/colors')

module.exports = {
  presets: [alsColors],
}
```

Then use classes like:

```html
<div class="bg-sky-base text-finch-white">Hello</div>
<button class="bg-finch-teal hover:bg-finch-navy-hover">Click</button>
```

### Python

```python
from als_computing_colors import colors, sky, slate, finch

print(colors["sky"]["base"])      # '#095B87'
print(sky["light"])                # '#0886CA'
print(slate["mid"])                # '#334256'
print(finch["navy_hover"])         # '#0E3B55'
```

## Palette

### `sky`

- `darkest`: `#073048`
- `dark`: `#004C70`
- `base`: `#095B87`
- `light`: `#0886CA`

### `slate`

- `dark`: `#464B53`
- `mid`: `#334256`
- `base`: `#64768D`
- `light`: `#C1D3E3`

### `finch`

- `teal`: `#004B71`
- `white`: `#F0F5F9`
- `cyan`: `#52BEE2`
- `blue`: `#7DA9CD`
- `sky_hover`: `#9ACFFC`
- `charcoal`: `#47484A`
- `mist_hover`: `#CED7DC`
- `navy_hover`: `#0E3B55`

## License

MIT
