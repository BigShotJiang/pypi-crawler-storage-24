"""zMesh CLI - Command-line tool for zMesh platform."""
from setuptools import setup, find_packages
from pathlib import Path

# Read long description from README
this_directory = Path(__file__).parent
long_description = (this_directory / "README.md").read_text()

setup(
    name="zmesh-cli",
    version="0.1.0",
    description="Command-line interface for zMesh Backend as a Service",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="zMesh Team",
    author_email="hello@zmesh.in",
    url="https://zmesh.in",
    project_urls={
        "Documentation": "https://zmesh.in/docs",
        "Source": "https://github.com/zmesh/cli",
        "Bug Reports": "https://github.com/zmesh/cli/issues",
    },
    packages=find_packages(),
    include_package_data=True,
    python_requires=">=3.11",
    install_requires=[
        "click>=8.1.0",
        "requests>=2.31.0",
        "rich>=13.0.0",
        "pyyaml>=6.0",
        "python-dotenv>=1.0.0",
        "tabulate>=0.9.0",
        "watchdog>=3.0.0",
    ],
    entry_points={
        "console_scripts": [
            "zmesh=zmesh_cli.cli:cli",
        ],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Internet :: WWW/HTTP :: Dynamic Content",
        "Topic :: Database",
        "Environment :: Console",
        "Operating System :: OS Independent",
    ],
    keywords="zmesh cli backend-as-a-service baas serverless edge-functions database storage",
)
