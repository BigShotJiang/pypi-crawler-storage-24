<div align="center">

# ⚡ zMesh

### The AI-First Backend as a Service — From Your Terminal

[![PyPI version](https://img.shields.io/pypi/v/zmesh-cli?color=%238bc34a&style=flat-square)](https://pypi.org/project/zmesh-cli/)
[![Python](https://img.shields.io/pypi/pyversions/zmesh-cli?style=flat-square)](https://pypi.org/project/zmesh-cli/)
[![License: MIT](https://img.shields.io/badge/license-MIT-blue.svg?style=flat-square)](LICENSE)
[![Downloads](https://img.shields.io/pypi/dm/zmesh-cli?style=flat-square&color=%238bc34a)](https://pypi.org/project/zmesh-cli/)

**Database • Edge Functions • Storage • AI Gateway • Auth — One CLI.**

[Website](https://zmesh.in) · [Docs](https://zmesh.in/docs) · [Dashboard](https://app.zmesh.in)

---

</div>

## What is zMesh?

zMesh is an **AI-first Backend as a Service** that gives you a full backend — PostgreSQL database, serverless edge functions, file storage, AI gateway, authentication — without writing a single line of infrastructure code.

This CLI lets you manage everything from your terminal.

```bash
pip install zmesh-cli
```

## Quick Start

```bash
# Authenticate
zmesh login

# Create a new project
zmesh init --name "My App"

# Create a table
zmesh database query "CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT UNIQUE
)"

# Deploy an edge function
zmesh functions deploy ./api.js

# Upload a file
zmesh storage upload ./logo.png --path assets/logo.png
```

**That's it.** Your backend is live.

---

## Features

<table>
<tr>
<td width="50%">

### 🗄️ Database
Full PostgreSQL — create tables, run queries, migrate schemas, seed data.
```bash
zmesh database tables
zmesh database query "SELECT * FROM users"
zmesh database migrate ./schema.sql
zmesh database seed ./data.json
```

</td>
<td width="50%">

### ⚡ Edge Functions
Deploy JavaScript or Python functions with built-in DB access.
```bash
zmesh functions deploy ./handler.js
zmesh functions invoke my-func --payload '{}'
zmesh functions logs my-func
```

</td>
</tr>
<tr>
<td width="50%">

### 📦 Storage
Upload, download, and manage files on Cloudflare R2.
```bash
zmesh storage upload ./image.png
zmesh storage list --prefix photos/
zmesh storage download photos/img.png
```

</td>
<td width="50%">

### 🤖 AI Gateway
Multi-provider AI — OpenAI, Anthropic, Google, Groq, Mistral, DeepSeek.
```bash
# Manage via Dashboard or API
# Chat, Embeddings, Vector Store (pgvector)
# Schema & RLS generation from prompts
```

</td>
</tr>
</table>

---

## Commands

### Authentication & Projects

| Command | Description |
|:---|:---|
| `zmesh login` | Authenticate with email/password |
| `zmesh logout` | Clear stored credentials |
| `zmesh whoami` | Show current user & linked project |
| `zmesh projects` | List all your projects |
| `zmesh init --name "App"` | Create & link a new project |
| `zmesh link <project-id>` | Link to an existing project |
| `zmesh unlink` | Unlink current directory |

### Database

| Command | Description |
|:---|:---|
| `zmesh database tables` | List all tables |
| `zmesh database query "<sql>"` | Execute raw SQL |
| `zmesh database query --file schema.sql` | Run SQL from file |
| `zmesh database migrate <file>` | Run a migration script |
| `zmesh database seed <file>` | Seed data from JSON |

### Edge Functions

| Command | Description |
|:---|:---|
| `zmesh functions list` | List all deployed functions |
| `zmesh functions deploy <file>` | Deploy a JS or Python function |
| `zmesh functions invoke <slug>` | Invoke with optional `--payload` |
| `zmesh functions logs <slug>` | View invocation history |
| `zmesh functions delete <slug>` | Remove a function |

**Deploy with options:**

```bash
zmesh functions deploy ./send-email.js \
  --name send-email \
  --description "Transactional email sender" \
  --entry-point handler \
  --env SMTP_HOST=smtp.example.com \
  --timeout 10000
```

### Storage

| Command | Description |
|:---|:---|
| `zmesh storage list` | List files (with `--bucket`, `--prefix`) |
| `zmesh storage upload <file>` | Upload with `--path` and `--bucket` |
| `zmesh storage download <path>` | Download to `--output` |
| `zmesh storage delete <path>` | Remove a file |

### Environment Variables

| Command | Description |
|:---|:---|
| `zmesh env --list` | List all env vars |
| `zmesh env --set KEY=value` | Set an env var |
| `zmesh env --unset KEY` | Remove an env var |

---

## Edge Functions

zMesh's edge functions run in a **custom-built sandboxed runtime** — no AWS Lambda, no third-party FaaS. Each function gets isolated subprocess execution with OS-level resource limits and a pre-injected `zmesh` SDK with direct database access.

### JavaScript

```javascript
// get-users.js
exports.handler = async (payload, zmesh) => {
  const users = await zmesh.db.query(
    'SELECT * FROM users WHERE active = $1', [true]
  );

  const newLog = await zmesh.db.insert('audit_log', {
    action: 'list_users',
    count: users.length
  });

  const secret = zmesh.env.API_SECRET;

  return { users, logged: true };
};
```

### Python

```python
# get-users.py
def handler(payload, zmesh):
    users = zmesh.db.query(
        "SELECT * FROM users WHERE active = %s", (True,)
    )

    zmesh.db.insert("audit_log", {
        "action": "list_users",
        "count": len(users)
    })

    return {"users": users}
```

### SDK Reference

| Method | Description |
|:---|:---|
| `zmesh.db.query(sql, params)` | Execute SQL, return rows |
| `zmesh.db.queryOne(sql, params)` | Execute SQL, return single row |
| `zmesh.db.insert(table, data)` | Insert a record |
| `zmesh.db.select(table, where, params)` | Select with conditions |
| `zmesh.db.update(table, data, where, params)` | Update matching rows |
| `zmesh.db.remove(table, where)` | Delete matching rows |
| `zmesh.env.KEY` | Access environment variable |
| `zmesh.projectId` | Current project ID |

---

## End-to-End Example

Build a complete blog API in under 2 minutes:

```bash
# 1. Create project
zmesh init --name "Blog API"

# 2. Create schema
zmesh database query "
CREATE TABLE posts (
  id SERIAL PRIMARY KEY,
  title TEXT NOT NULL,
  body TEXT,
  author TEXT,
  created_at TIMESTAMP DEFAULT NOW()
)"

# 3. Write a function
cat > get-posts.js << 'EOF'
exports.handler = async (payload, zmesh) => {
  const posts = await zmesh.db.query(
    'SELECT * FROM posts ORDER BY created_at DESC LIMIT $1',
    [payload.limit || 10]
  );
  return { posts };
};
EOF

# 4. Deploy
zmesh functions deploy ./get-posts.js

# 5. Test
zmesh functions invoke get-posts --payload '{"limit": 5}'

# 6. Call from your app
curl -X POST https://api.zmesh.in/api/functions/get-posts \
  -H "x-api-key: zb_your_key" \
  -H "Content-Type: application/json" \
  -d '{"limit": 5}'
```

---

## Configuration

| Location | Purpose |
|:---|:---|
| `~/.zmesh/config.json` | Global — API URL, auth token |
| `.zmesh/config.json` | Local — linked project & org |
| `.zmesh/.env` | Function environment variables |

### Self-Hosted

```bash
zmesh login --api-url https://api.yourdomain.com/v1
```

---

## Requirements

- Python 3.11+
- A [zMesh](https://zmesh.in) account

---

## Links

| | |
|:---|:---|
| 🌐 Website | [zmesh.in](https://zmesh.in) |
| 📖 Docs | [zmesh.in/docs](https://zmesh.in/docs) |
| 🖥️ Dashboard | [app.zmesh.in](https://app.zmesh.in) |
| 📧 Support | hello@zmesh.in |

---

<div align="center">

**Built by [Zyora](https://zyora.cloud)**

MIT License

</div>
