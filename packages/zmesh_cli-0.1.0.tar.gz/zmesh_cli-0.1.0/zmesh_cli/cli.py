"""Main CLI entry point."""
import click
from rich.console import Console
from rich.table import Table

from .config import config
from . import __version__

console = Console()


@click.group()
@click.version_option(version=__version__, prog_name="zmesh")
@click.pass_context
def cli(ctx):
    """
    zMesh CLI - Command-line tool for zMesh Backend as a Service

    Get started:
      zmesh login              # Authenticate with your account
      zmesh init               # Initialize a new project
      zmesh functions deploy   # Deploy an edge function

    Documentation: https://docs.zmesh.in
    """
    ctx.ensure_object(dict)


@cli.command()
@click.option("--email", prompt=True, help="Your email address")
@click.option("--password", prompt=True, hide_input=True, help="Your password")
@click.option("--api-url", default="https://api.zmesh.in/v1", help="API base URL (for self-hosted)")
def login(email: str, password: str, api_url: str):
    """Authenticate with your zMesh account."""
    from .api import APIClient

    # Set API URL
    config.set_api_url(api_url)

    # Login
    client = APIClient(base_url=api_url, access_token=None)
    try:
        response = client.post("/auth/login", data={"email": email, "password": password})
        access_token = response.get("access_token")

        if not access_token:
            console.print("[red]✗ Login failed: No access token returned[/red]")
            raise SystemExit(1)

        # Store token
        config.set_access_token(access_token)

        # Get user info
        user_response = client.get("/auth/me", api_key=None)
        user = user_response.get("user", {})

        console.print(f"[green]✓ Logged in as {user.get('email', email)}[/green]")
        console.print(f"[dim]Token stored in ~/.zmesh/config.json[/dim]")
    except SystemExit:
        raise
    except Exception as e:
        console.print(f"[red]✗ Login failed: {e}[/red]")
        raise SystemExit(1)


@cli.command()
def logout():
    """Log out and clear stored credentials."""
    config.clear_auth()
    console.print("[green]✓ Logged out successfully[/green]")


@cli.command()
def whoami():
    """Display currently authenticated user."""
    from .api import get_client

    if not config.get_access_token():
        console.print("[yellow]⚠ Not logged in. Run 'zmesh login' first.[/yellow]")
        raise SystemExit(1)

    client = get_client()
    try:
        response = client.get("/auth/me")
        user = response.get("user", {})

        table = Table(title="Current User", show_header=False)
        table.add_row("Email", user.get("email", "N/A"))
        table.add_row("Name", user.get("full_name", "N/A"))
        table.add_row("User ID", user.get("id", "N/A"))
        table.add_row("API URL", config.get_api_url())

        console.print(table)
    except SystemExit:
        raise
    except Exception as e:
        console.print(f"[red]✗ Failed to get user info: {e}[/red]")
        raise SystemExit(1)


@cli.command()
def projects():
    """List all your projects."""
    from .api import get_client

    if not config.get_access_token():
        console.print("[yellow]⚠ Not logged in. Run 'zmesh login' first.[/yellow]")
        raise SystemExit(1)

    client = get_client()
    try:
        # Get user's organizations
        orgs_response = client.get("/orgs")
        orgs = orgs_response.get("organizations", [])

        if not orgs:
            console.print("[yellow]⚠ No organizations found[/yellow]")
            return

        # Get projects for each org
        all_projects = []
        for org in orgs:
            projects_response = client.get(f"/projects/?org_id={org['org_id']}")
            projects = projects_response.get("projects", [])
            for proj in projects:
                proj["org_name"] = org["name"]
                all_projects.append(proj)

        if not all_projects:
            console.print("[yellow]⚠ No projects found. Create one at https://zmesh.in/dashboard[/yellow]")
            return

        table = Table(title="Your Projects")
        table.add_column("Name", style="cyan")
        table.add_column("ID", style="dim")
        table.add_column("Organization", style="green")
        table.add_column("Status", style="yellow")

        for proj in all_projects:
            status = "✓ Active" if proj.get("is_active", True) else "✗ Paused"
            table.add_row(
                proj.get("name", "N/A"),
                proj.get("id", "N/A")[:8] + "...",
                proj.get("org_name", "N/A"),
                status,
            )

        console.print(table)
        console.print(f"\n[dim]Total: {len(all_projects)} project(s)[/dim]")
    except SystemExit:
        raise
    except Exception as e:
        console.print(f"[red]✗ Failed to list projects: {e}[/red]")
        raise SystemExit(1)


# Import subcommands
from .commands import functions, database, project, storage

cli.add_command(functions.functions)
cli.add_command(database.database)
cli.add_command(project.init)
cli.add_command(project.link)
cli.add_command(project.unlink)
cli.add_command(project.env)
cli.add_command(storage.storage)


if __name__ == "__main__":
    cli()
