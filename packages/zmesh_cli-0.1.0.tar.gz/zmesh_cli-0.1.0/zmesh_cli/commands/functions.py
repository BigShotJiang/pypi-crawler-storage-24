"""Functions commands - deploy, invoke, list, logs."""
import click
import json
from pathlib import Path
from rich.console import Console
from rich.table import Table
from rich.syntax import Syntax
from rich.panel import Panel

from ..config import config
from ..api import get_client

console = Console()


def _require_auth():
    """Check if user is authenticated."""
    if not config.get_access_token():
        console.print("[yellow]⚠ Not logged in. Run 'zmesh login' first.[/yellow]")
        raise SystemExit(1)


def _get_project_id() -> str:
    """Get project ID from local config."""
    project = config.get_linked_project()
    if not project:
        console.print("[yellow]⚠ No project linked. Run 'zmesh link <project-id>' first.[/yellow]")
        raise SystemExit(1)
    return project["id"]


@click.group()
def functions():
    """Manage edge functions."""
    pass


@functions.command("list")
def list_functions():
    """List all functions in the current project."""
    _require_auth()
    project_id = _get_project_id()
    client = get_client()

    try:
        response = client.get(f"/projects/{project_id}/functions")
        funcs = response if isinstance(response, list) else []

        if not funcs:
            console.print("[yellow]⚠ No functions found. Deploy one with 'zmesh functions deploy'[/yellow]")
            return

        table = Table(title="Edge Functions")
        table.add_column("Name", style="cyan")
        table.add_column("Slug", style="green")
        table.add_column("Language", style="yellow")
        table.add_column("Status", style="magenta")
        table.add_column("Invocations", style="dim")

        for fn in funcs:
            status = "✓ Active" if fn.get("is_active", True) else "✗ Disabled"
            table.add_row(
                fn.get("name", "N/A"),
                fn.get("slug", "N/A"),
                fn.get("language", "N/A"),
                status,
                str(fn.get("invoke_count", 0)),
            )

        console.print(table)
        console.print(f"\n[dim]Total: {len(funcs)} function(s)[/dim]")
    except SystemExit:
        raise
    except Exception as e:
        console.print(f"[red]✗ Failed to list functions: {e}[/red]")
        raise SystemExit(1)


@functions.command("deploy")
@click.argument("file", type=click.Path(exists=True))
@click.option("--name", help="Function name (defaults to filename)")
@click.option("--description", help="Function description")
@click.option("--entry-point", default="handler", help="Entry point function name")
@click.option("--env", multiple=True, help="Environment variables (KEY=VALUE)")
@click.option("--timeout", default=30000, type=int, help="Timeout in milliseconds")
def deploy_function(file: str, name: str, description: str, entry_point: str, env: tuple, timeout: int):
    """Deploy an edge function from a file.

    Example:
      zmesh functions deploy ./my-function.js --name send-email
    """
    _require_auth()
    project_id = _get_project_id()
    client = get_client()

    file_path = Path(file)

    # Detect language from extension
    ext = file_path.suffix.lower()
    if ext == ".js":
        language = "javascript"
    elif ext == ".py":
        language = "python"
    else:
        console.print(f"[red]✗ Unsupported file type: {ext}. Use .js or .py[/red]")
        raise SystemExit(1)

    # Use filename as function name if not provided
    if not name:
        name = file_path.stem

    # Read code
    try:
        code = file_path.read_text()
    except Exception as e:
        console.print(f"[red]✗ Failed to read file: {e}[/red]")
        raise SystemExit(1)

    # Parse environment variables
    env_vars = {}
    for item in env:
        if "=" not in item:
            console.print(f"[red]✗ Invalid env format: {item}. Use KEY=VALUE[/red]")
            raise SystemExit(1)
        key, value = item.split("=", 1)
        env_vars[key] = value

    # Check if function already exists
    try:
        existing = client.get(f"/projects/{project_id}/functions")
        funcs = existing if isinstance(existing, list) else []
        existing_func = next((f for f in funcs if f.get("name") == name), None)

        if existing_func:
            # Update existing function
            console.print(f"[yellow]⚠ Function '{name}' already exists. Updating...[/yellow]")
            data = {
                "code": code,
                "entry_point": entry_point,
                "timeout_ms": timeout,
            }
            if description:
                data["description"] = description
            if env_vars:
                data["env_vars"] = env_vars

            response = client.patch(f"/projects/{project_id}/functions/{existing_func['id']}", data=data)
            console.print(f"[green]✓ Function updated: {name}[/green]")
        else:
            # Create new function
            data = {
                "name": name,
                "description": description or f"Deployed from {file_path.name}",
                "language": language,
                "code": code,
                "entry_point": entry_point,
                "env_vars": env_vars,
                "timeout_ms": timeout,
            }

            response = client.post(f"/projects/{project_id}/functions", data=data)
            console.print(f"[green]✓ Function deployed: {name}[/green]")

        slug = response.get("slug")
        if slug:
            console.print(f"[dim]Slug: {slug}[/dim]")
            console.print(f"[dim]Invoke URL: {config.get_api_url()}/api/functions/{slug}[/dim]")

    except SystemExit:
        raise
    except Exception as e:
        console.print(f"[red]✗ Deployment failed: {e}[/red]")
        raise SystemExit(1)


@functions.command("invoke")
@click.argument("function_slug")
@click.option("--payload", help="JSON payload to send")
@click.option("--file", type=click.Path(exists=True), help="Read payload from file")
def invoke_function(function_slug: str, payload: str, file: str):
    """Invoke a function by slug.

    Example:
      zmesh functions invoke send-email --payload '{"to": "user@example.com"}'
    """
    _require_auth()
    project_id = _get_project_id()
    client = get_client()

    # Parse payload
    payload_data = {}
    if file:
        try:
            payload_data = json.loads(Path(file).read_text())
        except Exception as e:
            console.print(f"[red]✗ Failed to read payload file: {e}[/red]")
            raise SystemExit(1)
    elif payload:
        try:
            payload_data = json.loads(payload)
        except json.JSONDecodeError as e:
            console.print(f"[red]✗ Invalid JSON payload: {e}[/red]")
            raise SystemExit(1)

    try:
        # Get function ID from slug
        funcs_response = client.get(f"/projects/{project_id}/functions")
        funcs = funcs_response if isinstance(funcs_response, list) else []
        func = next((f for f in funcs if f.get("slug") == function_slug), None)

        if not func:
            console.print(f"[red]✗ Function not found: {function_slug}[/red]")
            raise SystemExit(1)

        # Invoke function
        console.print(f"[cyan]→ Invoking {function_slug}...[/cyan]")
        response = client.post(
            f"/projects/{project_id}/functions/{func['id']}/invoke",
            data={"payload": payload_data},
        )

        status = response.get("status")
        if status == "success":
            console.print(f"[green]✓ Function executed successfully[/green]")
            result = response.get("result", {})
            syntax = Syntax(json.dumps(result, indent=2), "json", theme="monokai")
            console.print(Panel(syntax, title="Result", border_style="green"))
        elif status == "error":
            console.print(f"[red]✗ Function execution failed[/red]")
            error = response.get("error", "Unknown error")
            console.print(Panel(error, title="Error", border_style="red"))
        elif status == "timeout":
            console.print(f"[red]✗ Function timed out[/red]")
            error = response.get("error", "Timeout")
            console.print(Panel(error, title="Error", border_style="red"))

        duration = response.get("duration_ms", 0)
        console.print(f"[dim]Duration: {duration}ms[/dim]")

    except SystemExit:
        raise
    except Exception as e:
        console.print(f"[red]✗ Invocation failed: {e}[/red]")
        raise SystemExit(1)


@functions.command("logs")
@click.argument("function_slug")
@click.option("--limit", default=20, type=int, help="Number of logs to fetch")
def function_logs(function_slug: str, limit: int):
    """View invocation logs for a function.

    Example:
      zmesh functions logs send-email --limit 50
    """
    _require_auth()
    project_id = _get_project_id()
    client = get_client()

    try:
        # Get function ID from slug
        funcs_response = client.get(f"/projects/{project_id}/functions")
        funcs = funcs_response if isinstance(funcs_response, list) else []
        func = next((f for f in funcs if f.get("slug") == function_slug), None)

        if not func:
            console.print(f"[red]✗ Function not found: {function_slug}[/red]")
            raise SystemExit(1)

        # Get logs
        response = client.get(f"/projects/{project_id}/functions/{func['id']}/invocations", params={"limit": limit})
        logs = response if isinstance(response, list) else []

        if not logs:
            console.print("[yellow]⚠ No invocation logs found[/yellow]")
            return

        table = Table(title=f"Logs: {function_slug}")
        table.add_column("Time", style="dim")
        table.add_column("Status", style="cyan")
        table.add_column("Duration", style="yellow")
        table.add_column("Error", style="red")

        for log in logs:
            status_emoji = {
                "success": "[green]✓[/green]",
                "error": "[red]✗[/red]",
                "timeout": "[yellow]⏱[/yellow]",
            }.get(log.get("status"), "?")

            table.add_row(
                log.get("created_at", "N/A")[:19].replace("T", " "),
                f"{status_emoji} {log.get('status', 'N/A')}",
                f"{log.get('duration_ms', 0)}ms",
                log.get("error", "")[:50] or "-",
            )

        console.print(table)
        console.print(f"\n[dim]Showing {len(logs)} most recent invocation(s)[/dim]")

    except SystemExit:
        raise
    except Exception as e:
        console.print(f"[red]✗ Failed to fetch logs: {e}[/red]")
        raise SystemExit(1)


@functions.command("delete")
@click.argument("function_slug")
@click.confirmation_option(prompt="Are you sure you want to delete this function?")
def delete_function(function_slug: str):
    """Delete a function.

    Example:
      zmesh functions delete send-email
    """
    _require_auth()
    project_id = _get_project_id()
    client = get_client()

    try:
        # Get function ID from slug
        funcs_response = client.get(f"/projects/{project_id}/functions")
        funcs = funcs_response if isinstance(funcs_response, list) else []
        func = next((f for f in funcs if f.get("slug") == function_slug), None)

        if not func:
            console.print(f"[red]✗ Function not found: {function_slug}[/red]")
            raise SystemExit(1)

        # Delete function
        client.delete(f"/projects/{project_id}/functions/{func['id']}")
        console.print(f"[green]✓ Function deleted: {function_slug}[/green]")

    except SystemExit:
        raise
    except Exception as e:
        console.print(f"[red]✗ Failed to delete function: {e}[/red]")
        raise SystemExit(1)
