"""Storage commands - upload, download, list."""
import click
from pathlib import Path
from rich.console import Console
from rich.table import Table
from rich.progress import Progress
import requests

from ..config import config
from ..api import get_client

console = Console()


def _require_auth():
    """Check if user is authenticated."""
    if not config.get_access_token():
        console.print("[yellow]⚠ Not logged in. Run 'zmesh login' first.[/yellow]")
        raise SystemExit(1)


def _get_project_id() -> str:
    """Get project ID from local config."""
    project = config.get_linked_project()
    if not project:
        console.print("[yellow]⚠ No project linked. Run 'zmesh link <project-id>' first.[/yellow]")
        raise SystemExit(1)
    return project["id"]


@click.group()
def storage():
    """Manage file storage."""
    pass


@storage.command("list")
@click.option("--bucket", default="default", help="Bucket name")
@click.option("--prefix", help="Filter by path prefix")
def list_files(bucket: str, prefix: str):
    """List files in storage.

    Example:
      zmesh storage list --bucket images --prefix uploads/
    """
    _require_auth()
    project_id = _get_project_id()
    client = get_client()

    try:
        params = {"bucket": bucket}
        if prefix:
            params["prefix"] = prefix

        response = client.get(f"/projects/{project_id}/storage/files", params=params)
        files = response.get("files", []) if isinstance(response, dict) else []

        if not files:
            console.print("[yellow]⚠ No files found[/yellow]")
            return

        table = Table(title=f"Storage: {bucket}")
        table.add_column("Path", style="cyan")
        table.add_column("Size", style="yellow")
        table.add_column("Modified", style="dim")

        for file in files:
            size_bytes = file.get("size", 0)
            # Format size
            if size_bytes < 1024:
                size_str = f"{size_bytes} B"
            elif size_bytes < 1024 * 1024:
                size_str = f"{size_bytes / 1024:.1f} KB"
            else:
                size_str = f"{size_bytes / 1024 / 1024:.1f} MB"

            table.add_row(
                file.get("path", "N/A"),
                size_str,
                file.get("modified_at", "N/A")[:19].replace("T", " "),
            )

        console.print(table)
        console.print(f"\n[dim]Total: {len(files)} file(s)[/dim]")

    except SystemExit:
        raise
    except Exception as e:
        console.print(f"[red]✗ Failed to list files: {e}[/red]")
        raise SystemExit(1)


@storage.command("upload")
@click.argument("file", type=click.Path(exists=True))
@click.option("--path", help="Destination path (defaults to filename)")
@click.option("--bucket", default="default", help="Bucket name")
def upload_file(file: str, path: str, bucket: str):
    """Upload a file to storage.

    Example:
      zmesh storage upload ./image.png --path uploads/image.png
    """
    _require_auth()
    project_id = _get_project_id()
    client = get_client()

    file_path = Path(file)

    # Use filename as destination if not provided
    if not path:
        path = file_path.name

    try:
        console.print(f"[cyan]→ Uploading {file_path.name}...[/cyan]")

        # Get presigned upload URL
        response = client.post(
            f"/projects/{project_id}/storage/upload",
            data={"path": path, "bucket": bucket},
        )

        upload_url = response.get("upload_url")
        if not upload_url:
            console.print("[red]✗ Failed to get upload URL[/red]")
            raise SystemExit(1)

        # Upload file
        with open(file_path, "rb") as f:
            upload_response = requests.put(upload_url, data=f)
            upload_response.raise_for_status()

        console.print(f"[green]✓ Uploaded: {path}[/green]")

        # Get file URL
        file_url = response.get("file_url")
        if file_url:
            console.print(f"[dim]URL: {file_url}[/dim]")

    except SystemExit:
        raise
    except Exception as e:
        console.print(f"[red]✗ Upload failed: {e}[/red]")
        raise SystemExit(1)


@storage.command("download")
@click.argument("path")
@click.option("--output", help="Output file path (defaults to filename)")
@click.option("--bucket", default="default", help="Bucket name")
def download_file(path: str, output: str, bucket: str):
    """Download a file from storage.

    Example:
      zmesh storage download uploads/image.png --output ./image.png
    """
    _require_auth()
    project_id = _get_project_id()
    client = get_client()

    # Use filename from path if output not provided
    if not output:
        output = Path(path).name

    try:
        console.print(f"[cyan]→ Downloading {path}...[/cyan]")

        # Get presigned download URL
        response = client.post(
            f"/projects/{project_id}/storage/download",
            data={"path": path, "bucket": bucket},
        )

        download_url = response.get("download_url")
        if not download_url:
            console.print("[red]✗ File not found[/red]")
            raise SystemExit(1)

        # Download file
        download_response = requests.get(download_url)
        download_response.raise_for_status()

        # Save to file
        Path(output).write_bytes(download_response.content)

        console.print(f"[green]✓ Downloaded: {output}[/green]")

    except SystemExit:
        raise
    except Exception as e:
        console.print(f"[red]✗ Download failed: {e}[/red]")
        raise SystemExit(1)


@storage.command("delete")
@click.argument("path")
@click.option("--bucket", default="default", help="Bucket name")
@click.confirmation_option(prompt="Are you sure you want to delete this file?")
def delete_file(path: str, bucket: str):
    """Delete a file from storage.

    Example:
      zmesh storage delete uploads/image.png
    """
    _require_auth()
    project_id = _get_project_id()
    client = get_client()

    try:
        client.delete(
            f"/projects/{project_id}/storage/files",
            params={"path": path, "bucket": bucket},
        )

        console.print(f"[green]✓ Deleted: {path}[/green]")

    except SystemExit:
        raise
    except Exception as e:
        console.print(f"[red]✗ Delete failed: {e}[/red]")
        raise SystemExit(1)
