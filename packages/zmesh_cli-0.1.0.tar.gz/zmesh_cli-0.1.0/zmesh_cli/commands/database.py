"""Database commands - migrations, query, seed."""
import click
from pathlib import Path
from rich.console import Console
from rich.table import Table
from rich.syntax import Syntax
from rich.panel import Panel
import json

from ..config import config
from ..api import get_client

console = Console()


def _require_auth():
    """Check if user is authenticated."""
    if not config.get_access_token():
        console.print("[yellow]⚠ Not logged in. Run 'zmesh login' first.[/yellow]")
        raise SystemExit(1)


def _get_project_id() -> str:
    """Get project ID from local config."""
    project = config.get_linked_project()
    if not project:
        console.print("[yellow]⚠ No project linked. Run 'zmesh link <project-id>' first.[/yellow]")
        raise SystemExit(1)
    return project["id"]


@click.group()
def database():
    """Manage database (tables, migrations, queries)."""
    pass


@database.command("tables")
def list_tables():
    """List all tables in the project database."""
    _require_auth()
    project_id = _get_project_id()
    client = get_client()

    try:
        response = client.get(f"/projects/{project_id}/database/tables")
        tables = response.get("tables", []) if isinstance(response, dict) else []

        if not tables:
            console.print("[yellow]⚠ No tables found. Create one at the dashboard or via SQL.[/yellow]")
            return

        table = Table(title="Database Tables")
        table.add_column("Table Name", style="cyan")
        table.add_column("Row Count", style="yellow")

        for tbl in tables:
            table.add_row(
                tbl.get("table_name", "N/A"),
                str(tbl.get("row_count", 0)),
            )

        console.print(table)
        console.print(f"\n[dim]Total: {len(tables)} table(s)[/dim]")
    except SystemExit:
        raise
    except Exception as e:
        console.print(f"[red]✗ Failed to list tables: {e}[/red]")
        raise SystemExit(1)


@database.command("query")
@click.argument("sql", required=False)
@click.option("--file", type=click.Path(exists=True), help="Read SQL from file")
def execute_query(sql: str, file: str):
    """Execute a SQL query.

    Example:
      zmesh database query "SELECT * FROM users LIMIT 10"
      zmesh database query --file migration.sql
    """
    _require_auth()
    project_id = _get_project_id()
    client = get_client()

    # Get SQL from file or argument
    if file:
        try:
            sql = Path(file).read_text()
        except Exception as e:
            console.print(f"[red]✗ Failed to read SQL file: {e}[/red]")
            raise SystemExit(1)
    elif not sql:
        console.print("[red]✗ Provide SQL query or use --file[/red]")
        raise SystemExit(1)

    try:
        console.print(f"[cyan]→ Executing query...[/cyan]")
        response = client.post(f"/projects/{project_id}/database/execute", data={"sql": sql})

        if response.get("error"):
            console.print(f"[red]✗ Query failed[/red]")
            console.print(Panel(response["error"], title="Error", border_style="red"))
            raise SystemExit(1)

        result = response.get("result", [])
        affected_rows = response.get("affected_rows", 0)

        if isinstance(result, list) and result:
            # Display as table
            if len(result) > 0 and isinstance(result[0], dict):
                table = Table(title="Query Results")
                # Add columns
                for key in result[0].keys():
                    table.add_column(key, style="cyan")
                # Add rows
                for row in result[:100]:  # Limit to 100 rows for display
                    table.add_row(*[str(v) for v in row.values()])

                console.print(table)
                if len(result) > 100:
                    console.print(f"[dim]Showing first 100 of {len(result)} rows[/dim]")
                else:
                    console.print(f"[dim]Rows returned: {len(result)}[/dim]")
            else:
                # Non-SELECT query
                console.print(f"[green]✓ Query executed successfully[/green]")
                console.print(f"[dim]Rows affected: {affected_rows}[/dim]")
        else:
            console.print(f"[green]✓ Query executed successfully[/green]")
            console.print(f"[dim]Rows affected: {affected_rows}[/dim]")

    except SystemExit:
        raise
    except Exception as e:
        console.print(f"[red]✗ Query execution failed: {e}[/red]")
        raise SystemExit(1)


@database.command("migrate")
@click.argument("file", type=click.Path(exists=True))
@click.option("--name", help="Migration name")
def run_migration(file: str, name: str):
    """Run a database migration from a SQL file.

    Example:
      zmesh database migrate ./migrations/001_create_users.sql
    """
    _require_auth()
    project_id = _get_project_id()
    client = get_client()

    file_path = Path(file)

    # Use filename as migration name if not provided
    if not name:
        name = file_path.stem

    # Read SQL
    try:
        sql = file_path.read_text()
    except Exception as e:
        console.print(f"[red]✗ Failed to read migration file: {e}[/red]")
        raise SystemExit(1)

    try:
        console.print(f"[cyan]→ Running migration: {name}...[/cyan]")
        response = client.post(f"/projects/{project_id}/database/execute", data={"sql": sql})

        if response.get("error"):
            console.print(f"[red]✗ Migration failed[/red]")
            console.print(Panel(response["error"], title="Error", border_style="red"))
            raise SystemExit(1)

        console.print(f"[green]✓ Migration completed: {name}[/green]")
        affected_rows = response.get("affected_rows", 0)
        console.print(f"[dim]Rows affected: {affected_rows}[/dim]")

    except SystemExit:
        raise
    except Exception as e:
        console.print(f"[red]✗ Migration failed: {e}[/red]")
        raise SystemExit(1)


@database.command("seed")
@click.argument("file", type=click.Path(exists=True))
def seed_data(file: str):
    """Seed database with data from a JSON file.

    Example:
      zmesh database seed ./seeds/users.json

    JSON format:
      {
        "table": "users",
        "data": [
          {"name": "Alice", "email": "alice@example.com"},
          {"name": "Bob", "email": "bob@example.com"}
        ]
      }
    """
    _require_auth()
    project_id = _get_project_id()
    client = get_client()

    file_path = Path(file)

    # Read JSON
    try:
        seed_data = json.loads(file_path.read_text())
    except Exception as e:
        console.print(f"[red]✗ Failed to read seed file: {e}[/red]")
        raise SystemExit(1)

    table_name = seed_data.get("table")
    records = seed_data.get("data", [])

    if not table_name or not records:
        console.print("[red]✗ Invalid seed file format. Must have 'table' and 'data' fields.[/red]")
        raise SystemExit(1)

    try:
        console.print(f"[cyan]→ Seeding table '{table_name}' with {len(records)} record(s)...[/cyan]")

        # Insert records one by one
        success_count = 0
        for record in records:
            try:
                client.post(f"/projects/{project_id}/autoapi/{table_name}", data=record)
                success_count += 1
            except Exception as e:
                console.print(f"[yellow]⚠ Failed to insert record: {e}[/yellow]")

        console.print(f"[green]✓ Seeded {success_count}/{len(records)} record(s)[/green]")

    except SystemExit:
        raise
    except Exception as e:
        console.print(f"[red]✗ Seeding failed: {e}[/red]")
        raise SystemExit(1)


@database.command("dump")
@click.option("--output", default="dump.sql", help="Output file path")
def dump_database(output: str):
    """Dump database schema to a SQL file (requires pg_dump).

    Example:
      zmesh database dump --output backup.sql
    """
    _require_auth()
    project = config.get_linked_project()
    if not project:
        console.print("[yellow]⚠ No project linked. Run 'zmesh link <project-id>' first.[/yellow]")
        raise SystemExit(1)

    console.print("[yellow]⚠ Database dump feature requires direct PostgreSQL access.[/yellow]")
    console.print("[dim]Contact support@zmesh.in for database backup assistance.[/dim]")
