"""Project commands - init, link, env."""
import click
from pathlib import Path
from rich.console import Console
from rich.table import Table
from rich.prompt import Prompt
import json

from ..config import config
from ..api import get_client

console = Console()


def _require_auth():
    """Check if user is authenticated."""
    if not config.get_access_token():
        console.print("[yellow]⚠ Not logged in. Run 'zmesh login' first.[/yellow]")
        raise SystemExit(1)


@click.command()
@click.option("--name", prompt=True, help="Project name")
@click.option("--org-id", help="Organization ID (will prompt if not provided)")
def init(name: str, org_id: str):
    """Initialize a new zMesh project.

    Example:
      zmesh init --name "My API"
    """
    _require_auth()
    client = get_client()

    try:
        # Get organizations if org_id not provided
        if not org_id:
            orgs_response = client.get("/orgs")
            orgs = orgs_response.get("organizations", [])

            if not orgs:
                console.print("[red]✗ No organizations found. Create one at https://zmesh.in/dashboard[/red]")
                raise SystemExit(1)

            # Display organizations
            console.print("\n[cyan]Available Organizations:[/cyan]")
            for i, org in enumerate(orgs, 1):
                console.print(f"  {i}. {org['name']} ({org['org_id']})")

            # Prompt for selection
            choice = Prompt.ask("\nSelect organization", choices=[str(i) for i in range(1, len(orgs) + 1)])
            org_id = orgs[int(choice) - 1]["org_id"]

        # Create project
        console.print(f"\n[cyan]→ Creating project '{name}'...[/cyan]")
        response = client.post("/projects/", data={"name": name, "org_id": org_id})

        project_id = response.get("id")
        project_name = response.get("name")

        # Link project locally
        config.link_project(project_id, project_name, org_id)

        # Create .zmesh directory
        zmesh_dir = Path.cwd() / ".zmesh"
        zmesh_dir.mkdir(exist_ok=True)

        # Create .gitignore
        gitignore = Path.cwd() / ".gitignore"
        if not gitignore.exists():
            gitignore.write_text(".zmesh/\n.env\n")
        else:
            content = gitignore.read_text()
            if ".zmesh/" not in content:
                gitignore.write_text(content + "\n.zmesh/\n")

        console.print(f"\n[green]✓ Project created: {project_name}[/green]")
        console.print(f"[dim]Project ID: {project_id}[/dim]")
        console.print(f"[dim]Linked to current directory[/dim]")

        # Show next steps
        console.print("\n[cyan]Next steps:[/cyan]")
        console.print("  1. Deploy a function:     zmesh functions deploy ./my-function.js")
        console.print("  2. Execute a SQL query:   zmesh database query 'CREATE TABLE users(id SERIAL PRIMARY KEY, name TEXT)'")
        console.print("  3. View your dashboard:   https://zmesh.in/dashboard")

    except SystemExit:
        raise
    except Exception as e:
        console.print(f"[red]✗ Project creation failed: {e}[/red]")
        raise SystemExit(1)


@click.command()
@click.argument("project_id")
def link(project_id: str):
    """Link current directory to an existing project.

    Example:
      zmesh link abc123...
    """
    _require_auth()
    client = get_client()

    try:
        # Verify project exists and user has access
        console.print(f"[cyan]→ Linking to project {project_id}...[/cyan]")

        # Get user's organizations
        orgs_response = client.get("/orgs")
        orgs = orgs_response.get("organizations", [])

        # Find project in any org
        project = None
        org_id = None
        for org in orgs:
            projects_response = client.get(f"/projects/?org_id={org['org_id']}")
            projects = projects_response.get("projects", [])
            for proj in projects:
                if proj["id"] == project_id:
                    project = proj
                    org_id = org["org_id"]
                    break
            if project:
                break

        if not project:
            console.print(f"[red]✗ Project not found or you don't have access: {project_id}[/red]")
            raise SystemExit(1)

        # Link project
        config.link_project(project_id, project["name"], org_id)

        console.print(f"[green]✓ Linked to project: {project['name']}[/green]")
        console.print(f"[dim]Project ID: {project_id}[/dim]")

    except SystemExit:
        raise
    except Exception as e:
        console.print(f"[red]✗ Link failed: {e}[/red]")
        raise SystemExit(1)


@click.command()
def unlink():
    """Unlink current directory from project.

    Example:
      zmesh unlink
    """
    project = config.get_linked_project()
    if not project:
        console.print("[yellow]⚠ No project linked[/yellow]")
        return

    config.unlink_project()
    console.print(f"[green]✓ Unlinked from project: {project['name']}[/green]")


@click.command()
@click.option("--set", "set_var", multiple=True, help="Set environment variable (KEY=VALUE)")
@click.option("--unset", multiple=True, help="Unset environment variable")
@click.option("--list", "list_vars", is_flag=True, help="List all environment variables")
def env(set_var: tuple, unset: tuple, list_vars: bool):
    """Manage environment variables for edge functions.

    Example:
      zmesh env --set API_KEY=secret123
      zmesh env --list
      zmesh env --unset API_KEY
    """
    _require_auth()
    project_id = config.get_linked_project()
    if not project_id:
        console.print("[yellow]⚠ No project linked. Run 'zmesh link <project-id>' first.[/yellow]")
        raise SystemExit(1)

    # For now, env vars are per-function, not global
    # This command manages a local .env file
    env_file = Path.cwd() / ".zmesh" / ".env"

    if list_vars:
        if not env_file.exists():
            console.print("[yellow]⚠ No environment variables set[/yellow]")
            return

        env_vars = {}
        for line in env_file.read_text().splitlines():
            if "=" in line and not line.startswith("#"):
                key, value = line.split("=", 1)
                env_vars[key.strip()] = value.strip()

        if not env_vars:
            console.print("[yellow]⚠ No environment variables set[/yellow]")
            return

        table = Table(title="Environment Variables")
        table.add_column("Key", style="cyan")
        table.add_column("Value", style="dim")

        for key, value in env_vars.items():
            # Mask sensitive values
            masked = value if len(value) <= 4 else value[:4] + "*" * (len(value) - 4)
            table.add_row(key, masked)

        console.print(table)
        return

    if set_var:
        env_file.parent.mkdir(parents=True, exist_ok=True)

        # Read existing env vars
        existing = {}
        if env_file.exists():
            for line in env_file.read_text().splitlines():
                if "=" in line and not line.startswith("#"):
                    key, value = line.split("=", 1)
                    existing[key.strip()] = value.strip()

        # Update with new values
        for item in set_var:
            if "=" not in item:
                console.print(f"[red]✗ Invalid format: {item}. Use KEY=VALUE[/red]")
                continue
            key, value = item.split("=", 1)
            existing[key.strip()] = value.strip()
            console.print(f"[green]✓ Set {key.strip()}[/green]")

        # Write back
        lines = [f"{k}={v}" for k, v in existing.items()]
        env_file.write_text("\n".join(lines) + "\n")

    if unset:
        if not env_file.exists():
            console.print("[yellow]⚠ No environment variables to unset[/yellow]")
            return

        # Read existing env vars
        existing = {}
        for line in env_file.read_text().splitlines():
            if "=" in line and not line.startswith("#"):
                key, value = line.split("=", 1)
                existing[key.strip()] = value.strip()

        # Remove specified keys
        for key in unset:
            if key in existing:
                del existing[key]
                console.print(f"[green]✓ Unset {key}[/green]")
            else:
                console.print(f"[yellow]⚠ {key} not found[/yellow]")

        # Write back
        if existing:
            lines = [f"{k}={v}" for k, v in existing.items()]
            env_file.write_text("\n".join(lines) + "\n")
        else:
            env_file.unlink()

    if not set_var and not unset and not list_vars:
        console.print("[yellow]⚠ Use --set, --unset, or --list[/yellow]")
