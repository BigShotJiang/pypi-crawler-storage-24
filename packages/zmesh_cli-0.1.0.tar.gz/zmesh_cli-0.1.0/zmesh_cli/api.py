"""HTTP client for zMesh API."""
import requests
from typing import Optional, Any
from rich.console import Console

from .config import config

console = Console()


class APIClient:
    """HTTP client for interacting with zMesh API."""

    def __init__(self, base_url: Optional[str] = None, access_token: Optional[str] = None):
        self.base_url = base_url or config.get_api_url()
        self.access_token = access_token or config.get_access_token()
        self.session = requests.Session()

    def _get_headers(self, api_key: Optional[str] = None) -> dict:
        """Build request headers."""
        headers = {"Content-Type": "application/json"}
        if api_key:
            headers["x-api-key"] = api_key
        elif self.access_token:
            headers["Authorization"] = f"Bearer {self.access_token}"
        return headers

    def request(
        self,
        method: str,
        endpoint: str,
        data: Optional[dict] = None,
        params: Optional[dict] = None,
        api_key: Optional[str] = None,
        files: Optional[dict] = None,
    ) -> dict:
        """Make HTTP request to zMesh API."""
        url = f"{self.base_url}{endpoint}"
        headers = self._get_headers(api_key)

        # Remove Content-Type for file uploads
        if files:
            headers.pop("Content-Type", None)

        try:
            response = self.session.request(
                method=method,
                url=url,
                json=data if not files else None,
                params=params,
                headers=headers,
                files=files,
                timeout=30,
            )
            response.raise_for_status()
            return response.json() if response.content else {}
        except requests.exceptions.HTTPError as e:
            try:
                error_data = e.response.json()
                error_msg = error_data.get("detail", str(e))
            except Exception:
                error_msg = str(e)
            console.print(f"[red]✗ API Error:[/red] {error_msg}")
            raise SystemExit(1)
        except requests.exceptions.RequestException as e:
            console.print(f"[red]✗ Request failed:[/red] {e}")
            raise SystemExit(1)

    def get(self, endpoint: str, params: Optional[dict] = None, api_key: Optional[str] = None) -> dict:
        """GET request."""
        return self.request("GET", endpoint, params=params, api_key=api_key)

    def post(self, endpoint: str, data: Optional[dict] = None, api_key: Optional[str] = None, files: Optional[dict] = None) -> dict:
        """POST request."""
        return self.request("POST", endpoint, data=data, api_key=api_key, files=files)

    def patch(self, endpoint: str, data: Optional[dict] = None, api_key: Optional[str] = None) -> dict:
        """PATCH request."""
        return self.request("PATCH", endpoint, data=data, api_key=api_key)

    def delete(self, endpoint: str, api_key: Optional[str] = None) -> dict:
        """DELETE request."""
        return self.request("DELETE", endpoint, api_key=api_key)


def get_client() -> APIClient:
    """Get configured API client."""
    return APIClient()
