"""Configuration management for zMesh CLI."""
import os
import json
from pathlib import Path
from typing import Optional


class Config:
    """Manages CLI configuration (API keys, project links, etc.)."""

    def __init__(self):
        self.config_dir = Path.home() / ".zmesh"
        self.config_file = self.config_dir / "config.json"
        self.local_config_file = Path.cwd() / ".zmesh" / "config.json"
        self._ensure_config_dir()

    def _ensure_config_dir(self):
        """Create config directory if it doesn't exist."""
        self.config_dir.mkdir(parents=True, exist_ok=True)
        local_dir = Path.cwd() / ".zmesh"
        local_dir.mkdir(parents=True, exist_ok=True)

    def load_global(self) -> dict:
        """Load global config from ~/.zmesh/config.json."""
        if not self.config_file.exists():
            return {}
        try:
            with open(self.config_file, "r") as f:
                return json.load(f)
        except Exception:
            return {}

    def save_global(self, data: dict):
        """Save global config to ~/.zmesh/config.json."""
        with open(self.config_file, "w") as f:
            json.dump(data, f, indent=2)

    def load_local(self) -> dict:
        """Load local project config from .zmesh/config.json."""
        if not self.local_config_file.exists():
            return {}
        try:
            with open(self.local_config_file, "r") as f:
                return json.load(f)
        except Exception:
            return {}

    def save_local(self, data: dict):
        """Save local project config to .zmesh/config.json."""
        self.local_config_file.parent.mkdir(parents=True, exist_ok=True)
        with open(self.local_config_file, "w") as f:
            json.dump(data, f, indent=2)

    def get_access_token(self) -> Optional[str]:
        """Get stored access token."""
        config = self.load_global()
        return config.get("access_token")

    def set_access_token(self, token: str):
        """Store access token."""
        config = self.load_global()
        config["access_token"] = token
        self.save_global(config)

    def get_api_url(self) -> str:
        """Get API base URL (default: production)."""
        config = self.load_global()
        return config.get("api_url", "https://api.zmesh.in/v1")

    def set_api_url(self, url: str):
        """Set API base URL."""
        config = self.load_global()
        config["api_url"] = url
        self.save_global(config)

    def get_linked_project(self) -> Optional[dict]:
        """Get locally linked project info."""
        config = self.load_local()
        return config.get("project")

    def link_project(self, project_id: str, project_name: str, org_id: str):
        """Link current directory to a project."""
        config = self.load_local()
        config["project"] = {
            "id": project_id,
            "name": project_name,
            "org_id": org_id,
        }
        self.save_local(config)

    def unlink_project(self):
        """Unlink current directory from project."""
        config = self.load_local()
        if "project" in config:
            del config["project"]
            self.save_local(config)

    def clear_auth(self):
        """Clear stored authentication."""
        config = self.load_global()
        if "access_token" in config:
            del config["access_token"]
        self.save_global(config)


# Global config instance
config = Config()
