import re


def readable_size(size, decimal_places=2):
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if size < 1024.0:
            break
        size /= 1024.0
    return f"{size:.{decimal_places}f}{unit}"


def clean_text(text):
    """
    Removes common Markdown symbols to clean up the display.
    """
    if not text:
        return ""
    text = re.sub(r'[*_`~▫️▪]', '', text)
    text = re.sub(r'\s+', ' ', text).strip()
    return text
