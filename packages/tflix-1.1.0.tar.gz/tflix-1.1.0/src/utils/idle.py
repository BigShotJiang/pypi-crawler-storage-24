import asyncio
import time
from src.cli.prompt import input_session

async def idle_monitor(last_active_time):
    """Monitors for inactivity. Exits input_session if IDLE_TIMEOUT is reached."""
    while True:
        await asyncio.sleep(60)
        idle_duration = time.time() - last_active_time[0]

        if idle_duration >= 600:
            input_session.app.exit()