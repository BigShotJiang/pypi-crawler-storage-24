import subprocess
import sys
from typing import List

try:
    import pyperclip
except ImportError:
    pyperclip = None

def parse_selection(selection_str: str, total_items: int) -> List[int]:
    """
    Parses selection string like '1', '1:5', '5:1', '1,3,5' into a list of 1-based indices.
    """
    indices = []
    parts = selection_str.split(',')

    for part in parts:
        part = part.strip()
        if not part:
            continue

        if ':' in part or '-' in part:
            # Range handling
            start_str, end_str = part.split(':') if ':' in part else part.split('-')
            try:
                start = int(start_str)
                end = int(end_str)

                # Determine direction
                if start <= end:
                    rng = range(start, end + 1)
                else:
                    rng = range(start, end - 1, -1)

                for i in rng:
                    if 1 <= i <= total_items:
                        indices.append(i)
            except ValueError:
                continue
        else:
            # Single item
            try:
                i = int(part)
                if 1 <= i <= total_items:
                    indices.append(i)
            except ValueError:
                continue

    return list(dict.fromkeys(indices)) # to remove any duplicates

def normalize_fancy_text(text):
    """
    Converts 'Fancy' Unicode Mathematical Small Letters to standard ASCII.
    """
    fancy_map = str.maketrans({
        'ᴀ': 'a', 'ʙ': 'b', 'ᴄ': 'c', 'ᴅ': 'd', 'ᴇ': 'e', 'ғ': 'f',
        'ɢ': 'g', 'ʜ': 'h', 'ɪ': 'i', 'ᴊ': 'j', 'ᴋ': 'k', 'ʟ': 'l',
        'ᴍ': 'm', 'ɴ': 'n', 'ᴏ': 'o', 'ᴘ': 'p', 'ǫ': 'q', 'ʀ': 'r',
        's': 's', 'ᴛ': 't', 'ᴜ': 'u', 'ᴠ': 'v', 'ᴡ': 'w', 'x': 'x',
        'ʏ': 'y', 'ᴢ': 'z'
    })

    normalized = text.translate(fancy_map)
    # Remove emojis and keep only alphanumerics/spaces
    clean_text = ''.join([c if c.isalnum() else ' ' for c in normalized])
    return clean_text.lower()

def is_android():
    return hasattr(sys, 'getandroidapilevel')

def copy_stream_link(stream_link):
        if is_android():
            subprocess.run(["termux-clipboard-set"], input=stream_link, text=True)
        else:
            if pyperclip:
                pyperclip.copy(stream_link)

