import os
import sys
from .config import ENV_FILE
from dotenv import load_dotenv
from src.cli import console


load_dotenv(ENV_FILE)

def setup_env():
    """
    Loads credentials from .env file.
    """
    if not ENV_FILE.exists():
        console.print("ERROR: Configuration file not found", style="red")
        console.print(f"[yellow]Expected location:[/] {ENV_FILE}")
        console.print("\nCreate the .env file with the following content:",style="yellow")
        console.print("  TGRAM_API_ID=your_api_id")
        console.print("  TGRAM_API_HASH=your_api_hash")
        sys.exit(1)

    api_id = os.getenv("TGRAM_API_ID")
    api_hash = os.getenv("TGRAM_API_HASH")

    if not api_id or not api_hash:
        console.print(f"ERROR: TGRAM_API_ID or TGRAM_API_HASH missing in {ENV_FILE}", style="red")
        sys.exit(1)

    try:
        return int(api_id), api_hash
    except Exception:
        console.print(f"ERROR: TGRAM_API_ID must be an integer", style="red")
        sys.exit(1)

def tmdb_ombd_api():
    tmdb_api_id = os.getenv("TMDB_API_ID")
    omdb_api_id = os.getenv("OMDB_API_ID")
    return tmdb_api_id, omdb_api_id