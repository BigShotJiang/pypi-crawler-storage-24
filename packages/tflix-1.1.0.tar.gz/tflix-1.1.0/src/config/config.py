import configparser
import platform
import os
import sys
from pathlib import Path
from src.cli import console


if platform.system() == "Windows":
    # Windows: C:\Users\<User>\tflix
    CONFIG_DIR = Path.home() / 'tflix'
else:
    # Linux/Mac: ~/.config/tflix
    CONFIG_DIR = Path.home() / '.config' / 'tflix'

CONFIG_DIR.mkdir(parents=True, exist_ok=True)

ENV_FILE = CONFIG_DIR / ".env"
CONF_FILE = CONFIG_DIR / "tflix.conf"
SESSION_NAME = CONFIG_DIR / "tflix_session"


config_data =(
"""[chat]
auto_join_buttons = join updates channel, join channel, me joined, request to my updates channel
buttons_to_skip = search movies here, search on google

[log]
# channel =

[server]
host = http://localhost
port = 8080

[stream]
auto_stream = True
copy_links = True

[download]
connection_count = 4
"""
)

if not os.path.exists(CONF_FILE):
    with open(CONF_FILE, "w") as f:
        f.write(config_data)

config_parse = configparser.ConfigParser()
config_parse.read(CONF_FILE)

try:
    JOIN_BUTTONS = config_parse.get("chat", "auto_join_buttons", fallback="[]")
    SKIP_BUTTONS = config_parse.get("chat", "buttons_to_skip", fallback="[]")
    LOG_CHANNEL = config_parse.getint("log", "channel", fallback=None)
    PORT = config_parse.getint("server", "port", fallback=8080)
    HOST = config_parse.get("server", "host", fallback="http://localhost")
    AUTO_STREAM = config_parse.getboolean("stream", "auto_stream", fallback=True)
    COPY_LINK = config_parse.getboolean("stream", "copy_links", fallback=True)
    CONNECTION_COUNT = config_parse.getint("download", "connection_count", fallback=4)

except ValueError:
    console.print("[red]ERROR: Invalid Config Values Found")
    sys.exit(1)

JOIN_BUTTONS = [b.strip() for b in JOIN_BUTTONS.split(",") if b.strip()]
SKIP_BUTTONS = [b.strip() for b in SKIP_BUTTONS.split(",") if b.strip()]

if CONNECTION_COUNT < 1:
    CONNECTION_COUNT = 1
elif CONNECTION_COUNT > 20:
    CONNECTION_COUNT = 20


