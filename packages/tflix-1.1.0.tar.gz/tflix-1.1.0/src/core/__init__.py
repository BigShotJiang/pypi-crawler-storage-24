from telethon import TelegramClient
from src.config.env import setup_env
from src.config.config import SESSION_NAME
from src.config.config import LOG_CHANNEL
from telethon.tl.types import PeerChannel
from src.cli import console, parse_args

args = parse_args()

api_id, api_hash = setup_env()
client = TelegramClient(str(SESSION_NAME), api_id, api_hash)

async def chat():
    try:
        first_name = None
        if args.chat.isdigit():
            chat_entity = await client.get_entity(PeerChannel(int(args.chat)))
            chat_name = chat_entity.title # type: ignore
        else:
            log_entity = await log()
            if log_entity == None:
                console.print(f"ERROR: No Channel found for {LOG_CHANNEL}", style="red")
                return False
            log_channel_name = log_entity.title if log_entity else "" # type: ignore
            if args.chat == log_channel_name.lower():
                chat_entity = log_entity
                chat_name = log_channel_name
                return chat_entity, chat_name, first_name

            chat_entity = await client.get_entity(args.chat)
            chat_name = chat_entity.username # type: ignore
            first_name = chat_entity.first_name # type: ignore

    except Exception:
        console.print(f"[black on cyan]CHAT[/] [red]Invalid Username, ID or Link")
        return False

    return chat_entity, chat_name, first_name

async def log():
    try:
        if LOG_CHANNEL:
            log_entity = await client.get_entity(PeerChannel(LOG_CHANNEL))
            return log_entity
        return False
    except Exception:
        return None

