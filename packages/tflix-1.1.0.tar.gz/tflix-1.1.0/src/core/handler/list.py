from . import last_search_results, stream_cache
from src.utils.formatter import clean_text, readable_size
from src.utils import copy_stream_link
from rich.table import Table
from rich import box
from src.cli import console
from src.core import log
from src.config.config import COPY_LINK

def files_table():
    table = Table(box=box.ASCII2, show_lines=True, border_style="#d9cbbd")
    table.add_column("#", style=None)
    table.add_column("size", style=None)
    table.add_column("Name", style=None, overflow="fold")
    return table

async def handle_ls(client, chat_entity, args_string: str):
    """
    Handles the 'ls' command.
    args_string: can be a number (limit) or a search string.
    """
    global last_search_results, stream_cache

    search_query = None
    if not args_string:
        limit = len(last_search_results) if last_search_results else 1

    # Reset previous results
    last_search_results.clear()
    stream_cache.clear()

    # Check if input is a number (limit)
    if args_string.strip().isdigit():
        limit = int(args_string)
    elif args_string.strip():
        search_query = args_string.strip()
        limit = None

    chat_title = getattr(chat_entity, 'title', getattr(chat_entity, 'username', 'Chat'))
    stream_log = await log()
    stream_log_title = stream_log.title if stream_log else "" # type: ignore
    is_streamlog = chat_title.lower() == stream_log_title.lower()

    console.print(f"[blue][*][/] Searching in '[cyan]{chat_title}[/]' (Limit: [yellow]{limit}[/], Query: '[yellow]{search_query or 'None'}[/]')...")


    reply_map = {} # Stores { msg_id: reply_text_message }
    seen_files = set() # For duplicate deduplication (name, size)

    messages = []
    #  iter_messages filter is found to be less efficient
    async for msg in client.iter_messages(chat_entity, search=search_query, limit=None):
        if msg.document and msg.document.mime_type.startswith('video/') and msg.file.size > 15 * 1024 * 1024:
            # Deduplication Check: (Filename, Size)
            if limit and len(messages) >= limit:
                break
            file_sig = (msg.file.name, msg.file.size)
            if file_sig in seen_files:
                continue
            seen_files.add(file_sig)
            messages.append(msg)
        # Cache text messages that are replies
        if search_query and is_streamlog:
            async for reply in client.iter_messages(chat_entity, reply_to=msg.id):
                if reply.text and is_streamlog:
                    reply_map[msg.id] = reply.text
                    break
        if is_streamlog and msg.text and msg.reply_to_msg_id:
            reply_map[msg.reply_to_msg_id] = msg.text

    table = files_table()

    for idx, msg in enumerate(messages, 1):
        size_str = readable_size(msg.file.size)
        name = clean_text(msg.file.name) if msg.file.name else "Video"

        # Check for streambot reply link
        extra_info = ""
        if is_streamlog and msg.id in reply_map:
            link = reply_map[msg.id]
            stream_cache[idx] = link
            extra_info = f"\n      └─> [blue]{link}"

        table.add_row(f"{idx}",f"[yellow]{size_str}", f"{name} {extra_info}")

        # Store in global map for 'dl' command
        last_search_results[idx] = msg

    if len(messages) > 0:
        console.print(table)
        if COPY_LINK:
            link = "\n".join(list(stream_cache.values()))
            copy_stream_link(link)
    console.print(f"[green][+][/] Found [cyan]{len(messages)}[/] file(s)\n")