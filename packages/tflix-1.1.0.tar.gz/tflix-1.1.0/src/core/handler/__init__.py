from src.utils import normalize_fancy_text
from src.config.config import JOIN_BUTTONS, SKIP_BUTTONS

last_search_results = {}
stream_cache = {}

AUTO_KEYWORDS = JOIN_BUTTONS

USELESS_KEYWORDS = SKIP_BUTTONS

USELESS_KEYWORDS.extend(AUTO_KEYWORDS)

def is_button_useless(btn_text):
    """Checks if a button text matches useless keywords."""
    text_normal = normalize_fancy_text(btn_text)
    for kw in USELESS_KEYWORDS:
        if kw.lower() in text_normal:
            return True
    return False

def auto_click(text_normal):
    for kw in AUTO_KEYWORDS:
        if kw.lower() in text_normal:
            return True
    return False