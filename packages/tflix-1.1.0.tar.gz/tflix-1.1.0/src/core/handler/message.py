from . import stream_cache, last_search_results, auto_click, is_button_useless, button
from src.utils import copy_stream_link, normalize_fancy_text
from src.utils.formatter import clean_text
from rich.table import Table
from rich import box
from src.cli import console
from src.config.config import COPY_LINK, AUTO_STREAM

def options_table():
    table = Table(
        box=box.ASCII2,
        show_lines=True,
        show_header=False,
        border_style="#d9cbbd"
    )
    return table

async def process_incoming_message(client, event, last_message_ref, stream):
    """
    Processes incoming messages.
    """
    message = event.message
    last_message_ref['id'] = message.id
    if message.text:
        pass

    if message.document and message.document.mime_type.startswith('video/') and message.file.size > 15 * 1024 * 1024:
        file_name = message.file.name
        size = message.file.size
        mb = size / (1024 * 1024)
        idx = len(last_search_results) + 1
        last_search_results[idx] = message

        console.print(f"[green][+][/] {file_name} | [yellow]{mb:.2f} MB")
        if stream and AUTO_STREAM:
            stream_link = await stream(message)
            idx = len(stream_cache) + 1
            stream_cache[idx] = stream_link
            console.print(f"         └─> [blue]{stream_link}")
            if COPY_LINK:
                copy_stream_link(stream_link)
        print()

    if message.reply_markup:
        has_useful_button = False
        for row in message.reply_markup.rows:
            for btn in row.buttons:
                btn_text = getattr(btn, 'text', 'No Text')
                if not is_button_useless(btn_text):
                    has_useful_button = True
                    break
            if has_useful_button:
                break

        if has_useful_button:
            console.print("[blue][*][/] Options")
            option_count = 1
            has_auto_action = False
            table = options_table()

            # Track flat index (0, 1, 2...)
            flat_index = 0

            for row in message.reply_markup.rows:
                for btn in row.buttons:
                    btn_text = getattr(btn, 'text', 'No Text')

                    if is_button_useless(btn_text):
                        flat_index += 1
                        continue

                    table.add_row(f"[yellow]{option_count:02}", f"{clean_text(btn_text)}")

                    if auto_click(normalize_fancy_text(btn_text)):
                        console.print(f"[blue][*][/] Detected auto click button '{btn_text}'...")
                        try:
                            result = await message.click(flat_index)

                            if isinstance(result, str):
                                await button.process_callback_url(client, result)
                            elif hasattr(result, 'url'):
                                await button.process_callback_url(client, result.url)

                            has_auto_action = True
                        except Exception as e:
                            console.print(f"[Error] Auto-click failed: {e}", style="red")

                    option_count += 1
                    flat_index += 1
            console.print(table)

            if has_auto_action:
                console.print("[green][+][/] Action taken. Waiting for bot response...")

            print()
