from pathlib import Path
from src.cli import console
from  ..downloader import fast_download
from . import last_search_results
from src.utils import parse_selection

async def handle_dl(client, chat_entity, output_path, selection_str: str = ''):
    """
    Handles the 'dl' command. Parses selection and downloads files.
    """
    global last_search_results

    if not last_search_results:
        seen_files = set()
        message = None
        async for msg in client.iter_messages(chat_entity):
            if msg.document and msg.document.mime_type.startswith('video/') and msg.file.size > 15 * 1024 * 1024:
                file_sig = (msg.file.name, msg.file.size)
                if file_sig in seen_files:
                    continue
                seen_files.add(file_sig)
                message = msg
                break
        if message:
            last_search_results[1] = message
        else:
            console.print("[yellow][!][/] No media files found in the chat")
            return False

    count = len(last_search_results)
    indices = parse_selection(selection_str, count)

    if not indices:
        if selection_str:
            console.print("[yellow][!][/] Invalid input or no Media found to download")
            return False
        indices = list(range(1, count + 1)) if count > 1 else [1]
    console.print(f"[blue][*][/] Preparing to download [green]{len(indices)}[/] file(s) to [cyan]{Path(output_path).resolve()}")

    for idx in indices:
        if idx in last_search_results:
            msg = last_search_results[idx]
            try:
                await fast_download(client, msg, output_path, idx)
            except Exception as e:
                console.print(f"[red][!][/] Failed to download item {idx}: {e}")
                return False
    console.print(f"[green][+][/] Finished downloading [green]{len(indices)}[/] file(s)")
    return True
