from  ..streamer import generate_stream_link
from . import last_search_results, stream_cache
from src.utils import parse_selection, copy_stream_link
from src.config.config import COPY_LINK
from src.cli import console

async def handle_stream(client, chat_entity, selection_str: str = ''):
    """
    Handles the 'stream' command. Parses selection and return stream link.
    """
    global last_search_results

    if not last_search_results:
        seen_files = set()
        message = None
        async for msg in client.iter_messages(chat_entity):
            if msg.document and msg.document.mime_type.startswith('video/') and msg.file.size > 15 * 1024 * 1024:
                file_sig = (msg.file.name, msg.file.size)
                if file_sig in seen_files:
                    continue
                seen_files.add(file_sig)
                message = msg
                break
        if message:
            last_search_results[1] = message
        else:
            console.print("[yellow][!][/] No media files found in the chat\n")
            return False

    count = len(last_search_results)
    indices = parse_selection(selection_str, count)

    if not indices:
        if selection_str:
            console.print("[yellow][!][/] Invalid input or no Media found to generate stream link\n")
            return False
        indices = list(range(1, count + 1)) if count > 1 else [1]
    console.print(f"[blue][*][/] Preparing to stream [green]{len(indices)}[/] file(s)...")

    for idx in indices:
        if idx in last_search_results:
            msg = last_search_results[idx]
            try:
                link = await generate_stream_link(msg)
                if COPY_LINK:
                    copy_stream_link(link)
                stream_idx = len(stream_cache) + 1
                stream_cache[stream_idx] = link
                console.print(f"{msg.file.name}\n       └─> [blue]{link}")
            except Exception as e:
                console.print(f"[red][!][/] Failed to stream item {idx}: {e}")
    print()
    return True



