from urllib.parse import urlparse, parse_qs
from telethon.tl.functions.messages import ImportChatInviteRequest
from telethon.tl.functions.channels import JoinChannelRequest
from telethon.errors import UserAlreadyParticipantError
from src.utils.formatter import clean_text
from . import is_button_useless
from src.cli import console


async def process_callback_url(client, url):
    """Handles URLs returned by button clicks."""
    if not url:
        return

    try:
        parsed = urlparse(url)

        # Invite Link (Private)
        if "+" in parsed.path:
            invite_hash = None
            if "+" in parsed.path:
                invite_hash = parsed.path.strip("/").lstrip("+")

            if invite_hash:
                try:
                    await client(ImportChatInviteRequest(invite_hash))
                    console.print(f"Joined the requested group via invite link.", style="yellow")
                except UserAlreadyParticipantError:
                    pass
                except Exception as e:
                    if "successfully requested to join" in str(e):
                        pass
                    else:
                        console.print(f"[!] Failed to join via invite link: {e}\n", style="red")
            return

        if "t.me" in parsed.netloc:
            entity = parsed.path.strip('/')
            params = parse_qs(parsed.query)
            start_param = params.get('start', [None])[0]

            if entity and start_param:
                # Deep Link
                console.print(f"[blue][*][/] Getting file...")
                await client.send_message(entity, f"/start {start_param}")
            elif entity:
                # Public Channel
                console.print(f"Joining requested public channel @{entity}...", style="yellow")
                try:
                    await client(JoinChannelRequest(entity))
                    pass
                except UserAlreadyParticipantError:
                    pass
                except Exception as e:
                    console.print(f"Failed to join @{entity}: {e}", style="red")

    except Exception as e:
        console.print(f"[Error] Failed to fetch file: {e}", style="red")

async def click_button_by_index(client, chat_id, message_id, index):
    """Clicks a button using Row/Column coordinates."""
    try:
        message = await client.get_messages(chat_id, ids=message_id)
        if not message or not message.reply_markup:
            console.print("[yellow][!][/] No buttons found on this message\n")
            return False

        current_index = 0
        target_row = -1
        target_col = -1

        visible_index = 0

        for r, row in enumerate(message.reply_markup.rows):
            for c, button in enumerate(row.buttons):
                btn_text = getattr(button, 'text', "Button")
                if is_button_useless(btn_text):
                    pass
                else:
                    visible_index += 1
                    if visible_index == index:
                        target_row = r
                        target_col = c
                        console.print(f"[blue][*][/] Clicking option [yellow]{index}[/]: {clean_text(btn_text)}")
                        break
                current_index += 1
            if target_row != -1: break

        if target_row != -1:
            result = await message.click(target_row, target_col)
            if isinstance(result, str):
                await process_callback_url(client, result)
            elif hasattr(result, 'url'):
                await process_callback_url(client, result.url)
            return True
        else:
            console.print(f"[yellow][!][/] Invalid option number '{index}'")
            return False

    except Exception as e:
        console.print(f"[Error] failed to click button: {e}")
        return False
