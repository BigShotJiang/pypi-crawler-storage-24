import os
from src.cli import console
from .downloader import download_file
from rich.text import Text
from rich.progress import (
    Progress,
    BarColumn,
    DownloadColumn,
    TransferSpeedColumn,
    TimeRemainingColumn,
    TimeElapsedColumn,
    )


async def fast_download(client, message, download_folder, idx):
    media = message.document
    if not media:
        console.print("[red][!][/] No media found")
        return

    filename = message.file.name
    if not filename:
        ext = message.file.ext if message.file else ""
        filename = f"download_{message.id}{ext}"

    filename = filename.replace('/', '_').replace('\\', '_')
    os.makedirs(download_folder, exist_ok=True)
    download_location = os.path.join(download_folder, filename)

    file_size = message.file.size
    if not file_size:
        console.print("[red][!][/] Could not determine file size")
        return

    console.print(f"\n([cyan]{idx}[/]) {filename}")

    # Progress Bar Setup
    progress = MultiLineProgress(
        BarColumn(),
        "[progress.percentage]{task.percentage:>3.1f}%",
        "•",
        DownloadColumn(binary_units=True),
        "@",
        TransferSpeedColumn()
    )

    with progress:
        task_id = progress.add_task(f"[cyan]{filename}", total=file_size)

        def update_progress(downloaded, total):
            progress.update(task_id, completed=downloaded)

        # download
        with open(download_location, "wb") as f:
            await download_file(
                client=client,
                location=media,
                out=f,
                file_size=file_size,
                progress_callback=update_progress
            )

    # print(f"[+] Download completed")
    return download_location


class MultiLineProgress(Progress):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._eta_col = TimeRemainingColumn()
            self._elapsed_col = TimeElapsedColumn()

        def get_renderables(self):
            yield self.make_tasks_table(self.tasks)

            if self.tasks:
                task = self.tasks[0]
                eta_text = self._eta_col.render(task)
                elapsed_text = self._elapsed_col.render(task)

                line2 = Text.assemble(
                    ("ETA: "),
                    eta_text,
                    (" • Elapsed: "),
                    elapsed_text,
                )
                yield line2