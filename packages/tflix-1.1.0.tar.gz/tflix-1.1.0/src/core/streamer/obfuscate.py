import base64
import struct
from src.config.config import LOG_CHANNEL

ID_OBFUSCATION_KEY = int(str(LOG_CHANNEL)[1:8])  # type: ignore

def encode_id(msg_id: int) -> str:
    scrambled = msg_id ^ ID_OBFUSCATION_KEY
    data = struct.pack('>i', scrambled)
    return base64.urlsafe_b64encode(data).decode('utf-8').rstrip('=')

def decode_id(encoded: str) -> int:
    try:
        pad = len(encoded) % 4
        if pad: encoded += '=' * (4 - pad)
        data = base64.urlsafe_b64decode(encoded)
        scrambled = struct.unpack('>i', data)[0]
        return scrambled ^ ID_OBFUSCATION_KEY
    except:
        return 0