import asyncio
from datetime import datetime
from aiohttp import web
from telethon.errors import RPCError, FileReferenceExpiredError
from src.cli import console
from .obfuscate import decode_id
from . import START_TIME, stream_generator, client
from src.config.config import LOG_CHANNEL

MESSAGE_CACHE = {}

# --- MIDDLEWARE ---
@web.middleware
async def error_middleware(request, handler):
    try:
        return await handler(request)
    except web.HTTPException:
        # Re-raise known HTTP errors
        raise
    except Exception as e:
        # Catch unexpected errors
        console.print(f"[black on white]SERVER[/] [red]{type(e).__name__}: {e}")
        return web.json_response(
            {"detail": "Internal Server Error"},
            status=500
        )

# --- ROUTES ---
async def root(request):
    """Root endpoint: /"""
    uptime = datetime.now() - START_TIME
    return web.json_response({
        "status": "running",
        "uptime": str(uptime).split('.')[0],
        "service": "Telegram Streamer"
    })

async def stream_file(request):
    """Stream endpoint: /stream/{encoded_id}"""
    encoded_id = request.match_info.get('encoded_id', '')

    # Decode ID
    msg_id = decode_id(encoded_id)
    if msg_id == 0:
        console.print("[black on white]SERVER[/] [yellow]Invalid Link")
        return web.json_response({"detail": "Invalid Link"}, status=400)

    message = MESSAGE_CACHE.get(msg_id)
    # If not in cache fetch message
    if not message:
        try:
            message = await client.get_messages(LOG_CHANNEL, ids=msg_id)
            if message:
                MESSAGE_CACHE[msg_id] = message
        except RPCError as e:
            return web.json_response({"detail": f"Telegram Error: {e}"}, status=500)

    if not message or not message.document: # type: ignore
        console.print("[black on white]SERVER[/] [yellow]File Not Found")
        return web.json_response({"detail": "File Not Found"}, status=404)

    # Prepare Metadata
    file_size = message.file.size # type: ignore
    mime_type = message.file.mime_type or "application/octet-stream" # type: ignore
    filename = message.file.name or "Video" # type: ignore

    #  Handle Range Headers (Seeking)
    http_range = request.http_range
    start, end = 0, file_size - 1
    status_code = 200

    if http_range is not None:
        start = http_range.start or 0
        end = (http_range.stop - 1) if http_range.stop else file_size - 1
        status_code = 206

    length = end - start + 1

    # 5. Prepare Response
    response = web.StreamResponse(status=status_code)

    # Set Headers
    response.headers['Content-Type'] = mime_type
    response.headers['Accept-Ranges'] = 'bytes'
    response.headers['Content-Length'] = str(length)
    response.headers['Content-Range'] = f"bytes {start}-{end}/{file_size}"
    response.headers['Content-Disposition'] = f'inline; filename="{filename}"'

    # 6. Stream Data
    await response.prepare(request)

    try:
        async for chunk in stream_generator(message, start, end):
            await response.write(chunk)
    except FileReferenceExpiredError:
        # If file reference inside the cached message is old, delete it from cache so the next attempt gets a fresh one.
        if msg_id in MESSAGE_CACHE:
            del MESSAGE_CACHE[msg_id]
    except asyncio.CancelledError:
        pass
    except ConnectionError as e:
        pass
    except OSError as e:
        console.print(f"[black on white]SERVER[/] OS level Error: {e}", style="red")

    return response

# --- APP FACTORY ---
def create_app():
    app = web.Application(middlewares=[error_middleware])
    app.router.add_get('/', root)
    app.router.add_get('/stream/{encoded_id}', stream_file)
    return app