from datetime import datetime
from .obfuscate import encode_id
from src.config.config import LOG_CHANNEL, HOST, PORT
from src.core import client


START_TIME = datetime.now()

async def generate_stream_link(message):
    try:
        fwd_msg = await client.forward_messages(LOG_CHANNEL, message) # type: ignore
        encoded_str = encode_id(fwd_msg.id) # type: ignore
        link = f"{HOST}:{PORT}/stream/{encoded_str}"
        await client.send_message(LOG_CHANNEL, f"{link}", reply_to=fwd_msg.id) # type: ignore
        return link
    except Exception as e:
        print(f"[Error] {e}")
        return None

async def stream_generator(message, start_byte, end_byte):
    # Calculate limit (how many bytes to fetch)
    limit = end_byte - start_byte + 1

    # Using Telethon's built-in iterator
    async for chunk in client.iter_download(
        message.document,
        offset=start_byte,
        limit=limit,
        request_size=1024 * 1024
    ):
        yield chunk
