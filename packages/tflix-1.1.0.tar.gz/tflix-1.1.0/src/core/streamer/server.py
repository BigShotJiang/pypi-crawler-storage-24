from aiohttp import web
from .routes import create_app
from src.config.config import PORT


async def start_server():
    """
    Starts the aiohttp server in the background.
    """
    app = create_app()
    runner = web.AppRunner(app)

    # Setup the runner
    await runner.setup()

    site = web.TCPSite(runner, host="0.0.0.0", port=PORT)
    await site.start()

    return runner