import argparse
from rich.console import Console
from rich.table import Table
from rich import box

console = Console(highlight=False)


def parse_args():
    parser = argparse.ArgumentParser(
        usage="tflix CHAT [OPTIONS]",
        description="tflix: Telegram CLI Interface for automated media downloading.",
        formatter_class=AlignedHelpFormatter,
        epilog="Recommended bots\n"
        "Movies - PeruchazhiX1bot, Ck_flbot\n"
        "Series - BU_flbot, SeriesLandRobot\n\n"
        "Docs & issues: https://github.com/voidsnax/tflix.git"
    )

    parser.add_argument("chat",metavar='CHAT', help="Chat username, ID, or link")
    parser.add_argument("-o", "--output", metavar="PATH",default=".", help="Output directory for downloads (default: current dir)")
    parser.add_argument("-l", "--list", metavar="VALUE", nargs="?", const="1", help="List recent N bot media messages (default: 2, upto 100)")
    parser.add_argument("-d", "--download", action='store_true', help="Downloads recent N bot media messages (default: 2, upto 100)")
    parser.add_argument("-s", "--stream", action="store_true", help="Streamer")

    return parser.parse_args()


class AlignedHelpFormatter(argparse.HelpFormatter):
    def __init__(self, *args, **kwargs):
        kwargs['max_help_position'] = 35
        super().__init__(*args, **kwargs)
    def _fill_text(self, text, width, indent):
        # Preserve newlines in Description and Epilog
        # splitlines(keepends=True) ensures not losing of double newlines
        return ''.join(indent + line for line in text.splitlines(keepends=True))

    def _split_lines(self, text, width):
        # Preserve newlines in help
        return text.splitlines()


def chat_options():
    table = Table(box=box.ASCII2)
    table.add_column("Command", style="magenta")
    table.add_column("Description", style=None)

    table.add_row("h", "prints this help table")
    table.add_row("[white]<text>", "Send message")
    table.add_row("[white]<number>", "Click button # from the list")
    table.add_row("ls [white][LIMIT/STRING]", "List files to a limit or based on string")
    table.add_row("stream [white][INDEX]", "Stream files")
    table.add_row("dl [white][INDEX]", "Download files \n(e.g., indices '1', 1,2,3', '1:3', '1-3')\ndefault will be last file")
    table.add_row("exit/ctrl-c", "Quit")

    console.print(table)
    print()