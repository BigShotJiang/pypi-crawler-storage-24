import aiohttp
from prompt_toolkit.completion import Completer, Completion

class OMDBMenuCompleter(Completer):
    def __init__(self, api_key):
        self.api_key = api_key
        self.session = None
        self.cache = {}

    # define a dummy function
    def get_completions(self, document, complete_event):
        return []

    async def get_completions_async(self, document, complete_event):
        text = document.text_before_cursor.strip()

        if not self.session:
            self.session = aiohttp.ClientSession()

        if len(text) < 3:
            return
        # check cache
        if text in self.cache:
            results = self.cache[text]
            for item in results:
                yield Completion(
                    item["Title"],
                    start_position=-len(text),
                    display=item["Title"],
                    display_meta=item.get("Year", "")
                )
            return

        try:
            url = f"http://www.omdbapi.com"
            params = {
                "apikey": self.api_key,
                "s": text,
            }

            async with self.session.get(url, params=params) as resp:
                if resp.status != 200:
                    return
                data = await resp.json()

            results = data.get("Search", [])

            if results:
                self.cache[text] = results

            for item in results:
                yield Completion(
                    item["Title"],
                    start_position=-len(text),
                    display=item["Title"],
                    display_meta=item.get("Year", "")
                )
        except Exception:
            pass

    async def close(self):
        if self.session:
            await self.session.close()


class TMDBMenuCompleter(Completer):
    def __init__(self, api_key):
        self.api_key = api_key
        self.session = None
        self.cache = {}

    def get_completions(self, document, complete_event):
        return []

    async def get_completions_async(self, document, complete_event):
        text = document.text_before_cursor.strip()

        if not self.session:
            self.session = aiohttp.ClientSession()

        if len(text) < 3:
            return

        if text in self.cache:
            results = self.cache[text]
            for item in results:
                yield Completion(
                    item["display_text"],
                    start_position=-len(text),
                    display=item["display_text"],
                    display_meta=item["meta"]
                )
            return

        try:
            url = f"https://api.themoviedb.org/3/search/multi"
            params = {
                "api_key": self.api_key,
                "query": text,
                "include_adult": "true"
            }

            async with self.session.get(url, params=params) as resp:
                if resp.status != 200:
                    return
                data = await resp.json()

            raw_results = data.get("results", [])
            filtered_results = []

            for item in raw_results:
                media_type = item.get("media_type")

                if media_type in ['movie', 'tv']:
                    # Get title (Movies use 'title', TV uses 'name')
                    title = item.get("title") or item.get("name")

                    # Get date (Movies use 'release_date', TV uses 'first_air_date')
                    date = item.get("release_date") or item.get("first_air_date")
                    year = str(date)[:4] if date else "N/A"

                    # Format meta string to show type (Movie/TV)
                    # type_label = "MOV" if media_type == 'movie' else "TV"

                    display_text = title

                    filtered_results.append({
                        "display_text": display_text,
                        "meta": f"{year}"
                    })

            # Save to cache
            if filtered_results:
                self.cache[text] = filtered_results

            # Yield results
            for item in filtered_results:
                yield Completion(
                    item["display_text"],
                    start_position=-len(text),
                    display=item["display_text"],
                    display_meta=item["meta"]
                )
        except Exception:
            pass

    async def close(self):
        if self.session:
            await self.session.close()