from prompt_toolkit.key_binding import KeyBindings
from prompt_toolkit.filters import has_completions

kb = KeyBindings()

@kb.add("c-z", filter=has_completions)
def _(event):
    event.app.current_buffer.cancel_completion()