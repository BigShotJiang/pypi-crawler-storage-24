from prompt_toolkit import PromptSession
from prompt_toolkit.formatted_text import HTML
from .key_bindings import kb
from .completer import (
    suggestions,
    ListAutoSuggest,
    menu_completer,
    history
)

input_session = PromptSession(
    message=HTML('<skyblue>>>> </skyblue>'),
    history=history,
    auto_suggest=ListAutoSuggest(suggestions),
    completer=menu_completer,
    complete_while_typing=False,
    key_bindings=kb,
    bottom_toolbar=None
)