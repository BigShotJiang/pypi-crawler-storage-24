from prompt_toolkit.auto_suggest import AutoSuggest, Suggestion
from prompt_toolkit.history import InMemoryHistory
from .media_search import TMDBMenuCompleter, OMDBMenuCompleter
from src.config.env import tmdb_ombd_api

history = InMemoryHistory()
menu_completer = None
suggestions = ["1080p", "720p", "1440p", "s0", "stream", "dl", "ls"]

tmdb_api_id, omdb_api_id = tmdb_ombd_api()
if tmdb_api_id:
    menu_completer = TMDBMenuCompleter(tmdb_api_id)
elif omdb_api_id:
    menu_completer = OMDBMenuCompleter(omdb_api_id)

# simple series season episode suggestion
for i in range (1,21):
    season_episode = f"s{i:02}e0"
    suggestions.append(season_episode)

class ListAutoSuggest(AutoSuggest):
    def __init__(self, words):
        self.words = words

    def get_suggestion(self, buffer, document):
        text = document.text
        if (
            text.isspace()
            or text[0].isdigit()
            or len(text.split()) > 1 and text.split()[-2] in self.words
        ):
            return None
        last_token = text.split()[-1]

        for word in self.words:
            if word != 'stream' and word.startswith('s') and len(text.split()) < 2:
                continue
            if word.startswith(last_token):
                return Suggestion(word[len(last_token):])
        return None