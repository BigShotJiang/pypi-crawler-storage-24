import signal
import sys

signal.signal(signal.SIGINT, lambda x, y: sys.exit(0))

import asyncio
import logging
import time

from .config.config import LOG_CHANNEL, PORT, HOST
from telethon import events
from prompt_toolkit.patch_stdout import patch_stdout

from .cli import parse_args, prompt, console, chat_options
from .utils.idle import idle_monitor
from .core import client, chat
from .core.handler import (
    message,
    button,
    download,
    list
    )

signal.signal(signal.SIGINT, signal.default_int_handler)
logging.getLogger("telethon").setLevel(logging.CRITICAL)

async def _amain():
    """The main asynchronous logic."""
    args = parse_args()

    server_running = False

    try:
        console.print(f"[black on dark_sea_green]CLIENT[/] Logging in...")
        await client.start()   # type: ignore
        me = await client.get_me()
        console.print(f"[black on dark_sea_green]CLIENT[/] Logged in successfully as [magenta]{me.first_name}\n") # type: ignore

        get_chat = await chat()
        if not get_chat: sys.exit(1)
        chat_entity, chat_name, first_name = get_chat

        console.print(f"[black on cyan]CHAT[/] Connected to: [sky_blue1]{chat_name}",end='')
        if first_name: print(f" ({first_name})\n")
        else: print('\n')

        stream_link = None
        if args.stream and not args.download:
            if LOG_CHANNEL:
                from .core.streamer import generate_stream_link, server
                server_running = True
                stream_link = generate_stream_link
            else:
                console.print("[yellow][!][/] No log channel ID found\n")

        last_message_ref = {'id': None}
        @client.on(events.NewMessage(chats=chat_entity))
        @client.on(events.MessageEdited(chats=chat_entity))
        async def handler(event):
            await message.process_incoming_message(client, event, last_message_ref, stream_link)

        # Start background monitors
        last_active_time = [time.time()]
        idle = asyncio.create_task(idle_monitor(last_active_time))

        chat_session = True

        if args.list:
            await list.handle_ls(client, chat_entity, args.list)
        if args.download:
            await download.handle_dl(client, chat_entity, args.output)
            chat_session = False

        with patch_stdout(raw=True):
            if server_running:
                await server.start_server()
                prompt.input_session.bottom_toolbar = f"Server is Running at {HOST}:{PORT}"
                idle.cancel()
                try:
                    await idle
                except asyncio.CancelledError:
                    pass
            while chat_session:
                user_input = await prompt.input_session.prompt_async()
                # when idle monitor stops input_session
                if user_input is None:
                    console.print(f"\n[black on cyan]CHAT[/] [yellow]Session closed due to inactivity")
                    break
                if not user_input or user_input.isspace():
                    continue

                last_active_time[0] = time.time()
                user_input = user_input.strip()

                parts = user_input.strip().split(maxsplit=1)
                cmd = parts[0].lower()
                values = parts[1] if len(parts) > 1 else ""

                if user_input.lower() == 'exit': break
                elif user_input.lower() == 'h': chat_options()

                elif cmd == 'ls':
                    await list.handle_ls(client, chat_entity, values)
                elif cmd == 'stream':
                    if not server_running:
                        console.print("[yellow][!][/] Server is not running\nStart it by passing -server/-s\n")
                    else:
                        from .core.handler import stream
                        await stream.handle_stream(client, chat_entity, values)
                elif cmd == 'dl':
                    result = await download.handle_dl(client, chat_entity, args.output, values)
                    if result:
                        break
                    print()

                # Check for numeric button input
                elif user_input.isdigit():
                    if last_message_ref['id']:
                        await button.click_button_by_index(client, chat_entity, last_message_ref['id'], int(user_input))
                    else:
                        console.print("[yellow][!][/] No recent message found to click buttons on\n")
                    continue

                # Default: Send Message
                else:
                    await client.send_message(chat_entity, user_input) # type: ignore

    except asyncio.CancelledError:
        pass
    except ConnectionError:
        console.print("[Error] Connection to Telegram failed", style="red")
        sys.exit(1)
    except Exception as e:
        console.print(f"[Error] {e}", style="red")
        sys.exit(1)
    finally:
        if prompt.completer.menu_completer:
            await prompt.completer.menu_completer.close()
        if client.is_connected():
            try:
                await client.disconnect() # type: ignore
            except Exception:
                pass
        print()

def main():
    try:
        asyncio.run(_amain()) # type: ignore
    except KeyboardInterrupt:
        sys.exit(0)