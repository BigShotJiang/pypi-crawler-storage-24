# tflix

A Telegram CLI interface for media downloading and streaming.

## Description

tflix streamlines the process of discovering and downloading media files from Telegram bots. It provides an interactive command-line interface that handles bot navigation, automatic channel joining, and media file downloads with minimal user intervention.

## Features

- **Interactive CLI** - Navigate bot menus and send messages directly from the terminal
- **Auto-Join Support** - Automatically joins groups via invite links when required
- **Button Navigation** - Click numbered options from bot menus instantly
- **Media Filtering** - Lists and downloads files

## Requirements

- Python 3.8+
- [Telegram API Credentials](https://my.telegram.org)

## Installation

### From PyPI

```bash
pip install tflix
```

### From Source

```bash
git clone https://github.com/voidsnax/tflix.git
cd tflix
pip install -e .
```

## Usage

### Setup Guide

#### Creating the `.env` File

1. **Locate the config folder:**
    - **Windows:** `C:\Users\<User>\AppData\Local\tflix\`
    - **Linux/Mac:** `~/.config/tflix/`

2. **Create a new file** named `.env` in the config folder

3. **Get your Telegram API credentials:**
    - Visit [https://my.telegram.org](https://my.telegram.org)
    - Log in with your Telegram account
    - Go to "API development tools"
    - Create a new application
    - Copy your `api_id` and `api_hash`

4. **Add your credentials to `.env`:**
    ```
    TGRAM_API_ID=your_api_id_here
    TGRAM_API_HASH=your_api_hash_here
    ```

5. **Save the file**


### Basic Command

```bash
tflix [CHAT] [OPTIONS]
```

### Options

```
CHAT                  Chat username, ID, or link
-o, --output PATH     Output directory for downloads (default: current directory)
-l, --list VALUE      List recent N bot media messages (default: 2, max: 100)
```

### Interactive Commands

```
[Text]     → Send message to bot
[Number]   → Click button # from available options
q[n]       → Quit and download last n messages
exit       → Exit without downloading
```

### Examples

**Connect to default bot and list 5 recent files:**
```bash
tflix -l 5
```

**Connect to a specific bot and set output folder:**
```bash
tflix @bot -o C:\
```

Then interact:
```
Connected to: @bot
---------------------------------------------
Commands:
  [Text]     -> Send message
  [Number]   -> Click button # from the list
  exit       -> Quit
---------------------------------------------


## Notes

- **API Credentials** - Create `.env` in config folder with `TGRAM_API_ID` and `TGRAM_API_HASH`
- **Session Changes** - Overwrites existing session when .env file attributes changes
- **Private groups** - need invite link
- **Inactivity Timeout** - Sessions automatically exit after 10 minutes without input (when server is not running)
- **File Freshness** - Re-fetch files if older downloads fail; bots may remove expired links
- **Input Delay** - Allow 10-15 seconds for input to process if responses seem delayed
- **Message Listing** - Limited to 100 recent messages per query

## License

MIT License

