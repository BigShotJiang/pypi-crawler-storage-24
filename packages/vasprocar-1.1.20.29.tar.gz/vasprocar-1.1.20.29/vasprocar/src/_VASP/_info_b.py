# VASProcar Copyright (C) 2023
# GNU GPL-3.0 license

import numpy as np

#######################################################
############## Analyzing the OUTCAR file ##############
########### Searching for system information ##########
#######################################################

# ------------------------------------------------------------------------------
# Checking if the "output" folder exists, if it does not exist it is created ---
# ------------------------------------------------------------------------------
if os.path.isdir(dir_files + '/output'):
    0 == 0
else:
    os.mkdir(dir_files + '/output')
# ---------------------------------


# ---------------------------------------------------------------------
# Checking the presence of CONTCAR, OUTCAR and PROCAR files: ----------
# ---------------------------------------------------------------------

n_contcar = 0
#------------
try:
    f = open(dir_files + '/CONTCAR')
    f.close()
    n_contcar = 1
except:
    print('')
    print('... Missing CONTCAR file ...')

n_outcar = 0
#------------
try:
    f = open(dir_files + '/OUTCAR')
    f.close()
    n_outcar = 1
except:
    print('')
    print('... Missing OUTCAR file ...')

n_procar = 0
#-----------
try:
    f = open(dir_files + '/PROCAR')
    f.close()
    n_procar = 1
except:
    0 == 0
#---------
try:
    f = open(dir_files + '/PROCAR.1')
    f.close()
    n_procar = 1
except:
    0 == 0    
#-----------------
if (n_procar == 0):
   print('')
   print('... Missing PROCAR file ...')

if (abs(opcao) != 31 and (n_contcar == 0 or n_outcar == 0 or n_procar == 0)):   
   print('')
   print('')
   print('---------------------------------------------------------------------------')
   print('After inserting the missing files in the directory, press ENTER to continue')
   print('---------------------------------------------------------------------------')
   confirmacao = input (" "); confirmacao = str(confirmacao)

if (abs(opcao) == 31 and (n_contcar == 0 or n_outcar == 0)):   
   print('')
   print('')
   print('---------------------------------------------------------------------------')
   print('After inserting the missing files in the directory, press ENTER to continue')
   print('---------------------------------------------------------------------------')
   confirmacao = input (" "); confirmacao = str(confirmacao)
   

# ----------------------------------------------------------------------
# Checking the presence and number of PROCAR files to be read: ---------
# ----------------------------------------------------------------------

n_procar = 0

try:
    f = open(dir_files + '/PROCAR')
    f.close()
    n_procar = 1
except:
    0 == 0

loop_nprocar = len([file for file in os.listdir(dir_files) if file.startswith("PROCAR.")])

for i in range(1, (loop_nprocar +1)):
    try:
        f = open(dir_files + '/PROCAR.'+str(i))
        f.close()
        n_procar = i
    except:
        0 == 0


# ----------------------------------------------------------------------
# Checking the amount of orbitals in the PROCAR file: ------------------
# ----------------------------------------------------------------------

if (n_procar == 1):
   procar = open(dir_files + '/PROCAR', "r")
if (n_procar > 1):
   procar = open(dir_files + '/PROCAR.1', "r")

if (n_procar != 0):
   #-----------
   test = 'nao'
   #-----------
   while (test == 'nao'):             
         #------------------------
         VTemp = procar.readline()
         Teste = VTemp.split() 
         #---------------------------------------------
         if (len(Teste) > 0 and Teste[0] == 'ion'):
            test = 'sim'

   VTemp = procar.readline().split()

   #--------------------
   n_orb = len(VTemp) -2
   #--------------------

   procar.close()


#-----------------------------------------------------------------------------------
# Control parameters for reading orbitals and spin components in the PROCAR file ---
#-----------------------------------------------------------------------------------
read_orb  = 0
read_cont = 0
read_spin = 0
read_reg  = 0
read_psi  = 0

#----------------------------------------
outcar = open(dir_files + '/OUTCAR', "r")
#--------------------------------------------------------
inform = open(dir_files + '/output/informacoes.txt', "w")
#--------------------------------------------------------

inform.write(" \n")
inform.write("############################################################## \n")
inform.write(f'# {VASProcar_name} \n')
inform.write(f'# {url_1} \n')
inform.write(f'# {url_2} \n')
inform.write("############################################################## \n")
inform.write(" \n")


#----------------------------------------------------------------------
# Obtaining the number of k-points (nk), bands (nb) and ions (ni): ----
#----------------------------------------------------------------------

palavra = 'Dimension'                          # Dimension is a word present on a line before the lines containing information about the number of k-points (nk), bands (nb) and ions (ni).

for line in outcar:   
    if palavra in line: 
       break

VTemp = outcar.readline().split()
nk = int(VTemp[3])
nb = int(VTemp[14])

VTemp = outcar.readline().split()
ni = int(VTemp[11])


#-----------------------------------------------------------------------
# Check if the calculation was performed with or without SO coupling: --
#-----------------------------------------------------------------------

palavra = 'ICHARG'                             # ICHARG is a word present on a line before the line that contains information about the ISPIN variable.

for line in outcar:   
    if palavra in line: 
       break

VTemp = outcar.readline().split()
ispin = int(VTemp[2])                          # Reading the value associated with the ISPIN variable.

#------------
nb = nb*ispin
#------------

#-----------------------------------------------------------------------

VTemp = outcar.readline().split()
lnoncollinear = VTemp[2]                       # Reading the value associated with the LNONCOLLINEAR variable.

VTemp = outcar.readline().split()
lsorbit = VTemp[2]                             # Reading the value associated with the LSORBIT variable.

inform.write("---------------------------------------------------- \n")

if (lnoncollinear == "F"):
   LNC = 1
   inform.write("LNONCOLLINEAR = .FALSE. (Collinear Calculation) \n")
if (lnoncollinear == "T"):
   LNC = 2
   inform.write("LNONCOLLINEAR = .TRUE. (Non-collinear calculation) \n")

if (lsorbit == "F"):
   SO = 1
   inform.write("LSORBIT = .FALSE. (Calculation without SO coupling) \n")
if (lsorbit == "T"):
   SO = 2
   inform.write("LSORBIT = .TRUE. (Calculation with SO coupling) \n")


#-----------------------------------------------------------------------
# Finding the number of electrons in the system: -----------------------
#---------------------------------------------------------------------- 
 
palavra = 'VCA'                                       # VCA is a word present on a line before the line containing information about the NELECT variable.

for line in outcar:   
    if palavra in line: 
       break

VTemp = outcar.readline().split()
n_eletrons = float(VTemp[2])                          # Reading the value associated with the NELECT variable.

inform.write("---------------------------------------------------- \n")

if (n_procar == 1):
   inform.write(f'nº k-points = {nk};  nº Bands = {nb} \n')
if (n_procar > 1):
   inform.write(f'nº k-points = {nk*n_procar} (nº PROCAR files = {n_procar});  nº Bands = {nb} \n')   

inform.write(f'nº ions = {ni};  nº electrons = {n_eletrons} \n')


#-----------------------------------------------------------------------
# Obtaining the LORBIT used to generate the PROCAR file: ---------------
#-----------------------------------------------------------------------
 
palavra = 'LELF'                                    # LELF is a word present on a line before the line containing information about the LORBIT variable.

for line in outcar:   
    if palavra in line: 
       break

VTemp = outcar.readline().split()
lorbit = int(VTemp[2])                              # Reading the value associated with the LORBIT variable.

inform.write("--------------------------------------------------- \n")
inform.write(f'LORBIT = {lorbit};  ISPIN = {ispin} ')
if (ispin == 1): inform.write("(without spin polarization) \n")
if (ispin == 2): inform.write("(with spin polarization) \n")
inform.write("--------------------------------------------------- \n")

#-------------
outcar.close()
#-------------


#-----------------------------------------------------------------------
# searching for the fermi energy value in the OUTCAR file: -------------
#-----------------------------------------------------------------------
file_outcar = "OUTCAR"
if os.path.exists(dir_files + '/OUTCAR.scf'): file_outcar = "OUTCAR.scf"
#-----------------------------------------------------------------------
outcar = open(dir_files + '/' + file_outcar, "r")
Efermi = -1000.0
number = 0
#-------------------
palavra1 = 'E-fermi'
palavra2 = 'reached'
#------------------
for line in outcar:
    number += 1
    if (palavra1 or palavra2)  in line:
       Efermi_check = 1
       break
#-------------
outcar.close()
#------------------------------------------------
outcar = open(dir_files + '/' + file_outcar, "r")
#------------------------------------------------
for i in range(number):
    VTemp = outcar.readline()
VTemp = VTemp.split()
Efermi = float(VTemp[2])
#-----------------------
outcar.close()
#-------------


#-----------------------------------------------------------------------
# Finding the Fermi Energy of the System: ------------------------------
#-----------------------------------------------------------------------
outcar = open(dir_files + '/OUTCAR', "r") 
#----------------------------------------
palavra = 'average'                            # average is a word present on a line a little before the line that contains information about the E-fermi variable.
number = 0                                     # number represents which line contains information about the E-fermi variable.
#------------------
for line in outcar:
    number += 1    
    if palavra in line: 
       break
#------------------
palavra = 'E-fermi'
#------------------
for line in outcar:
    number += 1    
    if palavra in line: 
       break
#-------------
outcar.close()
#----------------------------------------
outcar = open(dir_files + '/OUTCAR', "r") 
#----------------------------------------
for i in range(number):
    VTemp = outcar.readline()
VTemp = VTemp.split()
# Efermi = float(VTemp[2])

inform.write(f'Fermi energy = {Efermi} eV \n')
inform.write("--------------------------------------------------- \n")


#-----------------------------------------------------------------------
# Finding the total energy of the system: ------------------------------
#-----------------------------------------------------------------------

palavra = 'FREE'                               # FREE is a word present on a line that is four lines before the line that contains information about the variable (free energy TOTEN).
number = 0                                     # number represents which line contains the information about the variable (free energy TOTEN).

for line in outcar:
    number += 1     
    if palavra in line: 
       break

for i in range(3):
    VTemp = outcar.readline()
    
VTemp = outcar.readline().split()
energ_tot = float(VTemp[3])                     

inform.write(f'free energy TOTEN = {energ_tot} eV \n')
inform.write("--------------------------------------------------- \n")

#-------------
outcar.close()
#-------------


#-----------------------------------------------------------------------
# searching for the Magnetic Moment values in the OUTCAR file: ---------
#-----------------------------------------------------------------------

stage = 0
targets = ["(x)", "(y)", "(z)"]
line_x = line_y = line_z = 0

with open(dir_files + '/OUTCAR', 'r') as f:
    for i, line in enumerate(f, 1):
        if stage == 0 and "reached" in line: stage = 1
        elif stage == 1 and all(w in line for w in ["free", "energy", "TOTEN"]): stage = 2
        elif stage == 2 and "magnetization" in line:
            #---------------------------- 
            if "(x)" in line: line_x = i
            if "(y)" in line: line_y = i
            if "(z)" in line: line_z = i
            #---------------------------- 
            for axis in targets[:]:
                if axis in line: targets.remove(axis)
            if not targets: break

if (ispin == 2 and LNC == 1):

   #========================= Magnetic Moment (X) ========================= 
   outcar = open(dir_files + '/OUTCAR', "r");  mmoments = []
   #--------------------------------------------------------
   for i in range(line_x +3): VTemp = outcar.readline()
   for i in range(ni):
       VTemp = outcar.readline().split()
       mmoments.append(float(VTemp[-1]))
   #------------------------------------
   sum_mmoments_x = sum(mmoments)
   for i in range(2): VTemp = outcar.readline().split()
   mmoment_tot_x = float(VTemp[-1])
   #-------------
   outcar.close()
   #-------------

if (LNC == 2):

   #========================= Magnetic Moment (X) ========================= 
   outcar = open(dir_files + '/OUTCAR', "r");  mmoments_x = []
   #----------------------------------------------------------
   for i in range(line_x +3):
       VTemp = outcar.readline()
   for i in range(ni):
       VTemp = outcar.readline().split()
       mmoments_x.append(float(VTemp[-1]))
   #------------------------------------
   sum_mmoments_x = sum(mmoments_x)
   for i in range(2): VTemp = outcar.readline().split()
   mmoment_tot_x = float(VTemp[-1])

   #========================= Magnetic Moment (Y) ========================= 
   palavra = 'magnetization';  mmoments_y = [] 
   #------------------------------------------
   for line in outcar:  
       if palavra in line: 
          break
   #-------------------------------------------
   for i in range(3): VTemp = outcar.readline()
   for i in range(ni):
       VTemp = outcar.readline().split()
       mmoments_y.append(float(VTemp[-1]))
   #------------------------------------
   sum_mmoments_y = sum(mmoments_y)
   for i in range(2): VTemp = outcar.readline().split()
   mmoment_tot_y = float(VTemp[-1])

   #========================= Magnetic Moment (Z) ========================= 
   palavra = 'magnetization';  mmoments_z = [] 
   #------------------------------------------
   for line in outcar:  
       if palavra in line: 
          break
   #-------------------------------------------
   for i in range(3): VTemp = outcar.readline()
   for i in range(ni):
       VTemp = outcar.readline().split()
       mmoments_z.append(float(VTemp[-1]))
   #------------------------------------
   sum_mmoments_z = sum(mmoments_z)
   for i in range(2): VTemp = outcar.readline().split()
   mmoment_tot_z = float(VTemp[-1])
   #-------------
   outcar.close()
   #-------------

   mmoments = []    
   for i in range(ni): mmoments.append([float(mmoments_x[i]), float(mmoments_y[i]), float(mmoments_z[i])])


#######################################################################
######################## CONTCAR File Reading: ########################
#######################################################################
 
#------------------------------------------
contcar = open(dir_files + '/CONTCAR', "r")
#------------------------------------------

VTemp = contcar.readline().split()
VTemp = contcar.readline().split()

Parametro = float(VTemp[0])                                 # Reading the System Lattice Parameter.

A1 = contcar.readline().split()
A1x = float(A1[0]); A1y = float(A1[1]); A1z = float(A1[2])  # Reading the coordinates (X, Y and Z) of the primitive vector (A1) of the unit cell in real space.

A2 = contcar.readline().split()
A2x = float(A2[0]); A2y = float(A2[1]); A2z = float(A2[2])  # Reading the coordinates (X, Y and Z) of the primitive vector (A2) of the unit cell in real space.

A3 = contcar.readline().split()
A3x = float(A3[0]); A3y = float(A3[1]); A3z = float(A3[2])  # Reading the coordinates (X, Y and Z) of the primitive vector (A3) of the unit cell in real space.

#--------------
contcar.close()
#--------------


#-----------------------------------------------------------------------
# Obtaining the labels of the ions present in the CONTCAR file ---------
#-----------------------------------------------------------------------

#------------------------------------------
contcar = open(dir_files + '/CONTCAR', "r")
#------------------------------------------

for i in range(6):
    VTemp = contcar.readline().split() 
types = len(VTemp)                                                     # Obtaining the number of different types of ions that make up the lattice.

#----------------------------------------------

label = [0]*(types+1)
ion_label = [0]*(ni+1)
rotulo = [0]*(ni+1)
rotulo_temp = [0]*(ni+1)

#----------------------------------------------

for i in range (1,(types+1)):
    label[i] = VTemp[(i-1)]                                            # Obtaining the labels/abbreviations that label each type of ion in the lattice.

VTemp = contcar.readline().split()                                    

for i in range (1,(types+1)):            
    ion_label[i] = int(VTemp[(i-1)])                                   # Obtaining the number of ions corresponding to each label/abbreviation.

#----------------------------------------------

contador = 0

for i in range (1,(types+1)):
    number = ion_label[i]
    for j in range (1,(number+1)):
        contador += 1
        rotulo[contador] = label[i]

#--------------
contcar.close()
#--------------


#------------------------------------------------------------------------
#---- Estimation of the correct value of the Network Parameter as the ---
#------ smallest value between the modulus of vectors A1, A2 and A3 -----
#------------------------------------------------------------------------

if (param_estim == 2):

   A1x = A1x*Parametro; A1y = A1y*Parametro; A1z = A1z*Parametro
   A2x = A2x*Parametro; A2y = A2y*Parametro; A2z = A2z*Parametro
   A3x = A3x*Parametro; A3y = A3y*Parametro; A3z = A3z*Parametro

   Parametro_1 = ((A1x*A1x) + (A1y*A1y) + (A1z*A1z))**0.5
   Parametro = Parametro_1

   Parametro_2 = ((A2x*A2x) + (A2y*A2y) + (A2z*A2z))**0.5
   if (Parametro_2 < Parametro):
      Parametro = Parametro_2

   Parametro_3 = ((A3x*A3x) + (A3y*A3y) + (A3z*A3z))**0.5
   if (Parametro_3 < Parametro):
      Parametro = Parametro_3

   A1x = A1x/Parametro; A1y = A1y/Parametro; A1z = A1z/Parametro
   A2x = A2x/Parametro; A2y = A2y/Parametro; A2z = A2z/Parametro
   A3x = A3x/Parametro; A3y = A3y/Parametro; A3z = A3z/Parametro

#-----------------------------------------------------------------------

V_real  = A1x*((A2y*A3z) - (A2z*A3y))   # I just divide this sum into three parts, since it is very long, and it exceeded the length of the line.
V_real += A1y*((A2z*A3x) - (A2x*A3z))
V_real += A1z*((A2x*A3y) - (A2y*A3x))
V_real  =  abs(V_real*(Parametro**3))   # Cell volume in real space (in Angs^3)
V_real  = round(V_real, 6)

#-----------------------------------------------------------------------

inform.write(" \n")
inform.write("===================================================== \n")
inform.write("Primitive Vectors of the Crystalline Lattice: ======= \n")
inform.write("===================================================== \n")
inform.write(f'Param. = {Parametro} Angs \n')
inform.write(f'A1 = Param.({A1x}, {A1y}, {A1z}) \n')
inform.write(f'A2 = Param.({A2x}, {A2y}, {A2z}) \n')
inform.write(f'A3 = Param.({A3x}, {A3y}, {A3z}) \n')
inform.write(f'Volume_cell = {V_real} Angs^3 \n')

#-----------------------------------------------------------------------

ss1 = A1x*((A2y*A3z) - (A2z*A3y))
ss2 = A1y*((A2z*A3x) - (A2x*A3z))
ss3 = A1z*((A2x*A3y) - (A2y*A3x))
ss =  ss1 + ss2 + ss3                                        # I just divide this sum into three parts, since it is very long, and it exceeded the length of the line.

B1x = ((A2y*A3z) - (A2z*A3y))/ss                             # To understand these operations on the X, Y and Z components of the primitive vectors of the lattice, 
B1y = ((A2z*A3x) - (A2x*A3z))/ss                             # you must perform the standard operation of building the primitive vectors of the reciprocal lattice 
B1z = ((A2x*A3y) - (A2y*A3x))/ss                             # based on the primitive vectors of the crystalline lattice. Such an operation is available in any solid-state book.
B2x = ((A3y*A1z) - (A3z*A1y))/ss                             
B2y = ((A3z*A1x) - (A3x*A1z))/ss
B2z = ((A3x*A1y) - (A3y*A1x))/ss
B3x = ((A1y*A2z) - (A1z*A2y))/ss
B3y = ((A1z*A2x) - (A1x*A2z))/ss
B3z = ((A1x*A2y) - (A1y*A2x))/ss

#-----------------------------------------------------------------------

dpi = 2*3.1415926535897932384626433832795
V_rec  = B1x*((B2y*B3z) - (B2z*B3y))     # I just divide this sum into three parts, since it is very long, and it exceeded the length of the line.
V_rec += B1y*((B2z*B3x) - (B2x*B3z))
V_rec += B1z*((B2x*B3y) - (B2y*B3x))
V_rec  = abs(V_rec*((dpi/Parametro)**3))   # Cell volume in reciprocal space (in Angs^-3)
V_rec  = round(V_rec, 6)

#-----------------------------------------------------------------------

inform.write("===================================================== \n")
inform.write("Primitive Vectors of the Reciprocal Lattice: ======== \n")
inform.write("===================================================== \n")
inform.write(f'2pi/Param. = {dpi/Parametro} Angs^-1 \n')
inform.write(f'B1 = 2pi/Param.({B1x}, {B1y}, {B1z}) \n')
inform.write(f'B2 = 2pi/Param.({B2x}, {B2y}, {B2z}) \n')
inform.write(f'B3 = 2pi/Param.({B3x}, {B3y}, {B3z}) \n')
inform.write(f'Volume_ZB = {V_rec} Angs^-3 \n')
inform.write("===================================================== \n")
inform.write(" \n")


#-----------------------------------------------------------------------
# Writing the magnetic moment values -----------------------------------
#-----------------------------------------------------------------------

if ((LNC == 2) or (ispin == 2 and LNC == 1)):
   #--------------------
   if (ispin == 2 and LNC == 1):
      m = np.zeros((ni, 3))
      m[:, 2] = mmoments
   elif (LNC == 2):
      m = np.array(mmoments)
   #--------------------
   magnitudes = np.linalg.norm(m, axis=1)  # Magnitude Calculations - Individual magnetic moments (Bohr magnetons)
   m_abs_total = np.sum(magnitudes)
   #--------------------
   m_avg_cell = m_abs_total / ni
   #--------------------
   threshold_nm  = 0.1
   threshold_mag = 0.3
   #--------------------
   mask_nm  = magnitudes < threshold_nm
   mask_qnm = (magnitudes >= threshold_nm) & (magnitudes <= threshold_mag)
   mask_mag = magnitudes > threshold_mag
   #----------------------
   n_nm  = np.sum(mask_nm)
   n_qnm = np.sum(mask_qnm)
   n_mag = np.sum(mask_mag)
   #-----------------------
   frac_mag = n_mag / ni 
   #-----------------------
   if n_mag > 0: m_avg_mag_ions = np.sum(magnitudes[mask_mag]) / n_mag
   else: m_avg_mag_ions = 0.0
   #-----------------------
   m_net_vec = np.sum(m, axis=0)               # Net Magnetization (Vector Sum)
   m_net_mag = np.linalg.norm(m_net_vec)
   #-----------------------
   eps = 1e-10                                 # Alignment Ratio (R) - R ranges from 0 (Perfect AFM/Cancellation) to 1 (Perfect FM) 
   ratio = m_net_mag / (m_abs_total + eps)     # This holds true regardless of whether magnitudes are 1 or 10 muB.   
   #--------------------
   label_mag = ""
   #--------------------
   if n_mag == 0:
       if n_qnm == 0:  label_mag = "Non-magnetic (NM)"
       else:           label_mag = "quasi Non-magnetic (NM)"
   #--------------------
   elif frac_mag < 0.05:
       label_mag = "quasi Non-magnetic (NM)"
   #-------------------- 
   else:
       if ratio >= 0.80:    label_mag = "Ferromagnetic (FM)"
       elif ratio <= 0.15:  label_mag = "Antiferromagnetic (AFM)"
       elif ratio >= 0.60:  label_mag = "quasi Ferromagnetic (FM)"
       elif ratio <= 0.40:  label_mag = "quasi Antiferromagnetic (AFM)"
       else:                label_mag = "Ferrimagnetic/Complex"

   inform.write("===================================================== \n")
   inform.write("Magnetic Moment: ==================================== \n")
   inform.write("===================================================== \n")
   inform.write(f"Total Net MAGMOM:            {m_net_mag:.4f} muB \n")
   inform.write(f"Mean MAGMOM (Cell):          {m_avg_cell:.4f} muB \n")
   inform.write(f"Mean MAGMOM (Mag. ions):     {m_avg_mag_ions:.4f} muB \n")
   inform.write(f"Number of NM ions:           {n_nm}   # < {threshold_nm} muB \n")
   inform.write(f"Number of quasi-NM ions:     {n_qnm}   # [{threshold_nm}, {threshold_mag}] muB \n")
   inform.write(f"Number of magnetic ions:     {n_mag}   # > {threshold_mag} muB \n")
   if (label_mag != "Non-magnetic (NM)"): inform.write(f"MAGMOM Alignment Ratio (R):  {ratio:.4f} \n")
   if (label_mag == "Non-magnetic (NM)"): inform.write(f"MAGMOM Alignment Ratio (R):  NaN \n")
   inform.write(f"Magnetic Order Class:        {label_mag} \n")
   inform.write("----------------------------------------------------- \n")
   inform.write("Note: Magnetic labels are derived from numerical thresholds. \n")
   inform.write("Always verify consistency with your OUTCAR/OSZICAR convergence and spin-polarized DOS. \n")
   inform.write("===================================================== \n")

 


   """
   #-----------------------
   tol_nm  = 0.05   # Threshold for Non-Magnetic (muB)             # Threshold Definitions (Adjust based on your DFT convergence/material)
   tol_qnm = 0.20   # quase não magnético
   tol_afm = 0.15   # Max ratio for Antiferromagnetic
   tol_fm  = 0.80   # Min ratio for Ferromagnetic
   #-----------------------
   if (ispin == 2 and LNC == 1):
      m = np.zeros((ni, 3))
      m[:, 2] = mmoments
   elif (LNC == 2):
      m = np.array(mmoments)
   #-----------------------
   magnitudes = np.linalg.norm(m, axis=1)  # Magnitude Calculations - Individual magnetic moments (Bohr magnetons)
   m_abs_total = np.sum(magnitudes)
   #-----------------------
   m_avg_cell = m_abs_total / ni
   #-----------------------
   mag_mask = magnitudes > 0.3;  n_mag = np.sum(mag_mask)
   if n_mag > 0: m_avg_mag_ions = np.sum(magnitudes[mag_mask]) / n_mag
   else: m_avg_mag_ions = 0.0
   #-----------------------
   m_net_vec = np.sum(m, axis=0)               # Net Magnetization (Vector Sum)
   m_net_mag = np.linalg.norm(m_net_vec)
   #-----------------------
   eps = 1e-10                                 # Alignment Ratio (R) - R ranges from 0 (Perfect AFM/Cancellation) to 1 (Perfect FM) 
   ratio = m_net_mag / (m_abs_total + eps)     # This holds true regardless of whether magnitudes are 1 or 10 muB.                                          
   # --- Classification Logic ---
   label_mag = ""
   #-------------
   if   m_avg_cell < tol_nm:   label_mag = "Non-magnetic (NM)"
   elif m_avg_cell < tol_qnm:  label_mag = "quasi Non-magnetic (NM)"
   else:
       if ratio >= tol_fm:     label_mag = "Ferromagnetic (FM)"
       elif ratio <= tol_afm:  label_mag = "Antiferromagnetic (AFM)"
       elif ratio >= 0.60:     label_mag = "quasi Ferromagnetic (FM)"
       elif ratio <= 0.40:     label_mag = "quasi Antiferromagnetic (AFM)"
       else:                   label_mag = "Ferrimagnetic/Complex"

   inform.write("===================================================== \n")
   inform.write("Magnetic Moment: ==================================== \n")
   inform.write("===================================================== \n")
   inform.write(f"Total Net MAGMOM:            {m_net_mag:.4f} muB \n")
   inform.write(f"Mean MAGMOM (Cell):          {m_avg_cell:.4f} muB \n")
   inform.write(f"Mean MAGMOM (Mag. ions):     {m_avg_mag_ions:.4f} muB \n")
   inform.write(f"Number of magnetic ions:     {n_mag} \n")
   if (label_mag != "Non-magnetic (NM)"): inform.write(f"MAGMOM Alignment Ratio (R):  {ratio:.4f} \n")
   if (label_mag == "Non-magnetic (NM)"): inform.write(f"MAGMOM Alignment Ratio (R):  NaN \n")
   inform.write(f"Magnetic Order Class:        {label_mag} \n")
   inform.write("----------------------------------------------------- \n")
   inform.write("Note: Magnetic labels are derived from numerical thresholds. \n")
   inform.write("Always verify consistency with your OUTCAR/OSZICAR convergence and spin-polarized DOS. \n")
   inform.write("===================================================== \n")
   """




if (ispin == 2 and LNC == 1):
   #-------------------
   for i in range (ni):
       rotulo_t = rotulo[i+1].replace("_"," ").replace("/"," ").split();  rotulo_t = rotulo_t[0]
       if (len(rotulo_t) == 1): inform.write(f'{rotulo_t}:  {mmoments[i]:8.4f} \n')
       if (len(rotulo_t) == 2): inform.write(f'{rotulo_t}: {mmoments[i]:8.4f} \n')
   inform.write(f'------------------------------ \n')
   inform.write(f'Total (sum)         = {sum_mmoments_x:8.4f} \n')
   inform.write(f'Total (VASP output) = {mmoment_tot_x:8.4f} \n')
   inform.write("===================================================== \n")
   inform.write(" \n")

if (LNC == 2):
   #-------------------
   for i in range (ni):
       rotulo_t = rotulo[i+1].replace("_"," ").replace("/"," ").split();  rotulo_t = rotulo_t[0]
       if (len(rotulo_t) == 1): inform.write(f'{rotulo_t}:  {mmoments_x[i]:8.4f} {mmoments_y[i]:8.4f} {mmoments_z[i]:8.4f} \n')
       if (len(rotulo_t) == 2): inform.write(f'{rotulo_t}: {mmoments_x[i]:8.4f} {mmoments_y[i]:8.4f} {mmoments_z[i]:8.4f} \n')
   inform.write(f'----------------------------- \n')
   inform.write(f'Total (sum)         = {sum_mmoments_x:8.4f} {sum_mmoments_y:8.4f} {sum_mmoments_z:8.4f} \n')
   inform.write(f'Total (VASP output) = {mmoment_tot_x:8.4f} {mmoment_tot_y:8.4f} {mmoment_tot_z:8.4f} \n')
   inform.write("===================================================== \n")
   inform.write(" \n")

#-------------
inform.close()
#-------------
