//! Stochastic simulation via SDE expression DSL.
//!
//! Users define stochastic differential equations as string expressions
//! (e.g. `"mu - 0.5 * h"` for drift) that get compiled into efficient
//! register-machine tapes and executed via Rayon-parallel Euler-Maruyama
//! simulation — all at native Rust speed, no Python callback overhead.
//!
//! # Architecture
//!
//! ```text
//! Expression strings  →  Parser (AST)  →  Compiler (SdeOp tape)
//!                                              ↓
//!                                     Runner (Euler-Maruyama, Rayon)
//!                                              ↓
//!                                     StochasticResult (stats + paths)
//! ```
//!
//! # Example (from Python)
//!
//! ```python
//! model = mbt.StochasticModel(
//!     drift="mu - 0.5 * h",
//!     diffusion="sqrt(h)",
//!     jump_intensity="lambda",
//!     jump_size="normal(mu_j, sigma_j)",
//!     state_vars={"h": 1e-4},
//!     state_update={"h": "omega + alpha * (ret - mu) ** 2 + beta * h"},
//!     params={"mu": 0.08, "omega": 1e-6, "alpha": 0.1, "beta": 0.85,
//!             "lambda": 5.0, "mu_j": -0.02, "sigma_j": 0.04},
//! )
//! result = mbt.run_stochastic(model, s0=100, n_paths=10000, n_steps=252, dt=1/252)
//! ```

pub mod compiler;
#[cfg(feature = "cuda")]
pub mod gpu;
pub mod parser;
pub mod presets;
pub mod runner;
pub mod sde_ops;

// Re-export key types for convenience.
pub use compiler::{compile_sde, SdeModelDef, SdeProgram};
pub use presets::{available_presets, preset};
pub use runner::{run_stochastic, StochasticResult, StochasticSimConfig};
#[cfg(feature = "cuda")]
pub use gpu::run_stochastic_gpu;
