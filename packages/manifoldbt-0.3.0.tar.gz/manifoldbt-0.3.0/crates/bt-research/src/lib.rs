pub mod experiment;
pub mod monte_carlo;
pub mod stability;
pub mod stochastic;
pub mod sweep_2d;
pub mod walk_forward;

use bt_analytics::PerformanceMetrics;

/// Extract a named metric from `PerformanceMetrics`.
///
/// Supported names: "sharpe", "sortino", "calmar", "total_return", "cagr",
/// "volatility", "max_drawdown", "omega_ratio", "ulcer_index", "skewness",
/// "kurtosis", "tail_ratio".
pub fn extract_metric(metrics: &PerformanceMetrics, name: &str) -> f64 {
    match name {
        "sharpe" => metrics.sharpe,
        "sortino" => metrics.sortino,
        "calmar" => metrics.calmar,
        "total_return" => metrics.total_return,
        "cagr" => metrics.cagr,
        "volatility" => metrics.volatility,
        "max_drawdown" => metrics.max_drawdown,
        "omega_ratio" => metrics.omega_ratio,
        "ulcer_index" => metrics.ulcer_index,
        "skewness" => metrics.skewness,
        "kurtosis" => metrics.kurtosis,
        "tail_ratio" => metrics.tail_ratio,
        "best_day" => metrics.best_day,
        "worst_day" => metrics.worst_day,
        "avg_daily_return" => metrics.avg_daily_return,
        "pct_positive_days" => metrics.pct_positive_days,
        "max_drawdown_duration_days" => metrics.max_drawdown_duration_days,
        _ => {
            tracing::warn!(metric = name, "unknown metric name, returning 0.0");
            0.0
        }
    }
}
