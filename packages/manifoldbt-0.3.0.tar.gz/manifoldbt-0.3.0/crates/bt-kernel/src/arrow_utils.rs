use arrow::datatypes::SchemaRef;
use arrow::record_batch::RecordBatch;

use crate::Result;

pub fn concat_batches(schema: SchemaRef, batches: &[RecordBatch]) -> Result<RecordBatch> {
    if batches.is_empty() {
        return Ok(RecordBatch::new_empty(schema));
    }

    Ok(arrow::compute::concat_batches(&schema, batches)?)
}
