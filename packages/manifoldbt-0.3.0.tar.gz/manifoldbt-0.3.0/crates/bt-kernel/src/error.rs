#[derive(thiserror::Error, Debug)]
pub enum BtError {
    #[error("data error: {0}")]
    Data(String),

    #[error("schema mismatch: expected {expected}, got {got}")]
    SchemaMismatch { expected: String, got: String },

    #[error("symbol not found: {0}")]
    SymbolNotFound(String),

    #[error("time range error: {0}")]
    TimeRange(String),

    #[error("expression error: {0}")]
    Expression(String),

    #[error("strategy error: {0}")]
    Strategy(String),

    #[error("unsupported operation: {0}")]
    Unsupported(String),

    #[error("io error: {0}")]
    Io(#[from] std::io::Error),

    #[error("arrow error: {0}")]
    Arrow(#[from] arrow::error::ArrowError),

    #[error("parquet error: {0}")]
    Parquet(#[from] parquet::errors::ParquetError),

    #[error("sqlite error: {0}")]
    Sqlite(#[from] rusqlite::Error),

    #[error("json error: {0}")]
    Json(#[from] serde_json::Error),
}

pub type Result<T> = std::result::Result<T, BtError>;
