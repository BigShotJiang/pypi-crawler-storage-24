pub mod metrics;
pub mod tearsheet;

pub use metrics::{
    compute_benchmark_daily_returns, compute_capm_alpha, compute_daily_returns,
    compute_performance_metrics, compute_performance_metrics_with_rf, compute_trade_statistics,
    extract_round_trip_pnls, resample_to_daily, OlsResult, PerformanceMetrics, RoundTrip,
    TradeStatistics,
};
pub use tearsheet::Tearsheet;
