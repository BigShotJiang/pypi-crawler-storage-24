use serde::{Deserialize, Serialize};

use crate::metrics::PerformanceMetrics;

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct Tearsheet {
    pub title: String,
    pub metrics: PerformanceMetrics,
    pub notes: Vec<String>,
}
