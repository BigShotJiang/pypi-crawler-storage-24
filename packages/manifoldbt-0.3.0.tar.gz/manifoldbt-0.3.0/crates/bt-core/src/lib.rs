pub mod alignment;
pub mod fees;
pub mod fill;
pub mod manifest;
pub mod orchestrator;
pub mod orders;
pub mod portfolio;
pub mod portfolio_model;
pub mod portfolio_runner;
pub mod slippage;
pub mod sweep;
pub mod universe;

pub use fees::FillType;
pub use manifest::RunManifest;
pub use orchestrator::{
    BacktestConfig, BacktestResult, BacktestRunner, BarInterval, BatchResultLite, ExecutionConfig,
    ExecutionPrice, FeeConfig, FillModel, IntraBarPrice, PositionSizingMode, ProfileData,
    SimpleBacktestRunner, StrategyMetadata, StrategyPlan,
};
pub use orders::{
    ActiveBracket, ExitReason, LimitOrderConfig, OrderConfig, StopLossConfig, TakeProfitConfig,
    TimeInForce, TrailingStopConfig,
};
pub use portfolio_model::{
    PerStrategyResult, PortfolioDef, PortfolioResult, RebalanceConfig, RebalanceEvent, RiskEvent,
    RiskRule, StrategySlot,
};
pub use portfolio_runner::run_portfolio;
pub use slippage::{
    BarData, FixedBpsSlippage, Side, SlippageConfig, SlippageModel, SpreadBasedSlippage,
    VolumeImpactSlippage,
};
pub use sweep::ParamGrid;
