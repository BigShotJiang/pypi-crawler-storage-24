use std::collections::HashSet;

use bt_kernel::{BtError, Result, SymbolId};

pub fn validate_universe(universe: &[SymbolId]) -> Result<()> {
    if universe.is_empty() {
        return Err(BtError::Strategy("backtest universe is empty".to_string()));
    }

    let mut seen = HashSet::new();
    for &symbol in universe {
        if !seen.insert(symbol) {
            return Err(BtError::Strategy(format!(
                "duplicate symbol in universe: {:?}",
                symbol
            )));
        }
    }

    Ok(())
}
