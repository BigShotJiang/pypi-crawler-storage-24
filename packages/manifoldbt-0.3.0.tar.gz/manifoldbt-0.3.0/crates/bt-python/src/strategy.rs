use bt_strategy::{compile_strategy, StrategyDef};
use pyo3::prelude::*;
use serde::Serialize;

#[derive(Debug, Serialize)]
struct CompiledStrategySummary {
    name: String,
    signal_names: Vec<String>,
    required_columns: Vec<String>,
    required_features: Vec<String>,
    parameters: Vec<String>,
}

#[pyfunction]
pub fn compile_strategy_json(strategy_json: &str) -> PyResult<String> {
    let strategy: StrategyDef =
        serde_json::from_str(strategy_json).map_err(super::map_json_error)?;
    let compiled = compile_strategy(&strategy).map_err(super::map_bt_error)?;

    let mut signal_names = compiled.signals.keys().cloned().collect::<Vec<_>>();
    signal_names.sort();

    let mut parameters = compiled.parameters.keys().cloned().collect::<Vec<_>>();
    parameters.sort();

    let summary = CompiledStrategySummary {
        name: compiled.name,
        signal_names,
        required_columns: compiled.required_columns,
        required_features: compiled.required_features,
        parameters,
    };

    serde_json::to_string_pretty(&summary).map_err(super::map_json_error)
}
