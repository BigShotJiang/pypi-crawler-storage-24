use arrow::array::{Array, ArrayRef};
use arrow::pyarrow::ToPyArrow;
use arrow::record_batch::RecordBatch;
use pyo3::prelude::*;

pub fn array_to_pyarrow(py: Python<'_>, array: &ArrayRef) -> PyResult<PyObject> {
    array.to_data().to_pyarrow(py)
}

pub fn batch_to_pyarrow(py: Python<'_>, batch: &RecordBatch) -> PyResult<PyObject> {
    batch.to_pyarrow(py)
}
