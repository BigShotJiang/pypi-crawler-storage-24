mod device;
mod error;
mod guard;
mod license;
mod telemetry;

pub use error::LicenseError;
pub use guard::{
    activate, check_feature, downgrade_to_community, init_guard, is_pro, license_info,
    max_monte_carlo_sims, min_resolution_secs,
};
pub use license::{License, LicenseFeature};
