use sha2::{Digest, Sha256};
use std::path::PathBuf;

/// Generate a stable, anonymous device fingerprint.
/// Uses machine-uid which reads machine-specific identifiers
/// (Windows: MachineGuid from registry, Linux: /etc/machine-id, macOS: IOPlatformUUID).
pub fn device_hash() -> String {
    let uid = machine_uid::get().unwrap_or_else(|_| "unknown-device".to_string());
    let mut hasher = Sha256::new();
    hasher.update(uid.as_bytes());
    hasher.update(b"manifoldbt-salt-2026");
    let result = hasher.finalize();
    hex::encode(&result[..16])
}

/// Path to the local license state directory.
/// Stores license key, device registration, and last-ping timestamp.
pub fn license_dir() -> PathBuf {
    dirs::data_local_dir()
        .unwrap_or_else(|| PathBuf::from("."))
        .join("manifoldbt")
        .join("license")
}

/// Path to the stored license key file.
pub fn license_file() -> PathBuf {
    license_dir().join("license.key")
}

/// Path to the local state file (last ping time, device hash).
pub fn state_file() -> PathBuf {
    license_dir().join("state.json")
}
