use thiserror::Error;

#[derive(Error, Debug)]
pub enum LicenseError {
    #[error("invalid license key")]
    InvalidKey,
    #[error("license expired on {0}")]
    Expired(String),
    #[error("feature '{0}' requires a Pro license")]
    FeatureNotLicensed(String),
    #[error("internet connection required for initial activation")]
    ConnectionRequired,
    #[error("license revoked")]
    Revoked,
    #[error("io error: {0}")]
    Io(#[from] std::io::Error),
}
