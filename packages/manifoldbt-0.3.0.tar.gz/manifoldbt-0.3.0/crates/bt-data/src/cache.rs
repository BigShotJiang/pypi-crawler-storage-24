use std::hash::{Hash, Hasher};

use bt_kernel::SymbolId;

#[derive(Clone, Debug, Eq)]
pub struct CacheKey {
    pub dataset: String,
    pub symbol: SymbolId,
    pub day: String,
}

impl PartialEq for CacheKey {
    fn eq(&self, other: &Self) -> bool {
        self.dataset == other.dataset && self.symbol == other.symbol && self.day == other.day
    }
}

impl Hash for CacheKey {
    fn hash<H: Hasher>(&self, state: &mut H) {
        self.dataset.hash(state);
        self.symbol.hash(state);
        self.day.hash(state);
    }
}

#[derive(Debug, Default)]
pub struct DataCache;
