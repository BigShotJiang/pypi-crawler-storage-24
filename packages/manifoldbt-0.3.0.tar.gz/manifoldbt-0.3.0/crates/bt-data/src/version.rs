use bt_kernel::{SymbolId, TimeRange, Timestamp};
use serde::{Deserialize, Serialize};

#[derive(Clone, Debug, PartialEq, Serialize, Deserialize)]
pub struct DatasetVersion {
    pub id: String,
    pub dataset: String,
    pub created_at: Timestamp,
    pub schema_hash: String,
    pub row_count: u64,
    pub time_range: TimeRange,
    pub symbols: Vec<SymbolId>,
    pub source_hash: String,
    pub metadata: serde_json::Value,
}
