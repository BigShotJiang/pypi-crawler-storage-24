#  @copyright (c) 2024 e:fs TechHub GmbH. All rights reserved.
#  Dr.-Ludwig-Kraus-Straße 6, 85080 Gaimersheim, DE, https://www.efs-techhub.com
"""
This module provides the main entry point for the Thetis evaluation toolkit.
"""

from thetiscore import ThetisArgs
from thetiscore import thetis as thetiscore_main


def thetis(thetis_args: ThetisArgs) -> dict:
    """
    Main entrance point for the Thetis evaluation service.

    Executes the main Thetis processing function after initializing the license
    and validating the user configuration. Handles exceptions and wraps the core
    logic in a license context to ensure compliance.

    Given a ground-truth data set and the respective predictions by an AI
    model, this service examines several safety-relevant aspects such as
    uncertainty quality, data set quality, performance metrics, and fairness.

    Args:
        thetis_args (ThetisArgs): A data class containing all necessary arguments
            for the execution, including the API key, license file path, license
            XML string, and license key/signature.

    Returns:
        dict: Dictionary with the evaluation results, rating scores, and
            recommendations for the examined AI model.

    Raises:
        ConnectionError: if API key is given but if connection to Thetis user management cannot be established.
            (raised by :func:`thetiscore._licensing.license._License.__init__`).
        LicenseInvalidError: if API key is given but if API key is either invalid or a valid license cannot be found.
            (raised by :func:`thetiscore._licensing.license._License.__init__`).
        ThetisInternalLicenseError: on any other unexpected error during API key validation.
            (raised by :func:`thetiscore._licensing.license._License.__init__`).
        FileNotFoundError: if file with given license_file_path cannot be found
            (raised by :func:`thetiscore._licensing.license._License.__init__`).
        RuntimeError: if license_file_path is given but file path is malformed
            (e.g., due to insufficient escaping of backslashes)
            (raised by :func:`thetiscore._licensing.license._License.__init__`).
        RuntimeError: if parsing the given XML file failed
            (raised by :func:`thetiscore._licensing.license._License.__init__`).
        RuntimeError: if parsing the given XML string failed
            (raised by :func:`thetiscore._licensing.License.__init__`).
        RuntimeError: if neither 'license_file_path', 'license_xml_str', 'license_key_and_signature', THETIS_LICENSE,
            "license.dat" in working directory nor "license.dat" in user local home directory (OS specific)
            could be found (raised by :func:`thetiscore._licensing.license._License.__init__`).
        AttributeError: if the key 'Key' cannot be found at the expected location
            (raised by :func:`thetiscore._licensing.license._License.__init__`).
        AttributeError: if the key 'Signature' cannot be found at the expected location
            (raised by :func:`thetiscore._licensing.license._License.__init__`).
        :class:`thetiscore.errors.LicenseInvalidError`: if the passed license key/signature pair is invalid
            (raised by :func:`thetiscore._licensing.license._License.verify`).
        RuntimeError: if the license Key XML cannot be parsed
            (raised by :func:`thetiscore._licensing.license._License.verify`).
        AttributeError: if the key 'ExpiryDate' cannot be found at the expected location
            (raised by :func:`thetiscore._licensing.license._License.verify`).
        :class:`thetiscore.errors.LicenseExpiredError`: if the license has expired
            (raised by :func:`thetiscore._licensing.license._License.verify`).
        TypeError: if config is neither str nor python dict (raised by :func:`thetiscore._data.get_config`).
        SyntaxError: if the syntax of the user configuration is malformed according to
            the required configuration schema (raised by :func:`thetiscore._data.get_config`).
        AttributeError: if classification or detection mode but key "distinct_classes" is missing or empty
            (raised by :func:`thetiscore._data.get_config`).
        AttributeError: if classification mode but length of "distinct_classes" is lower than 2
            (raised by :func:`thetiscore._data.get_config`).
        AttributeError: if binary classification mode (length of "distinct_classes" is 2) but error_msg field
            "binary_positive_label" is missing (raised by :func:`thetiscore._data.get_config`).
        AttributeError: if detection mode but key "task_settings/detection_bbox_format" is missing in user config.
            (raised by :func:`thetiscore._data.get_config`).
        AttributeError: if "fairness" evaluation is active but no sensitive attribute has been specified
            (raised by :func:`thetiscore._data.get_config`).
        AttributeError: if more than 2 distinct_classes are specified along with a "binary_positive_label"
            (raised by :func:`thetiscore._data.get_config`).
        AttributeError: if "binary_positive_label" key is specified for any task other than classification
            (raised by :func:`thetiscore._data.get_config`).
        AttributeError: if "distinct_classes" key is specified for a regression task
            (raised by :func:`thetiscore._data.get_config`).
        RuntimeError: if the license Key XML cannot be parsed
            (raised by :func:`thetiscore._licensing.license._License.verify_feature`).
        AttributeError: if the key 'Features' cannot be found at the expected location
            (raised by :func:`thetiscore._licensing.license._License.verify_feature`).
        NotImplementedError: if "task" is not one of "classification", "regression", "detection"
            (raised by :func:`thetiscore._data.get_input`).
        RuntimeError: if the given language identifier is unknown or not supported
            (raised by :func:`thetiscore._language.Language._Language.__init__`).
        TypeError: if 'predictions' is not type pd.DataFrame
            (classification, raised by :func:`thetiscore._data.get_input`).
        TypeError: if 'annotations' is not type pd.DataFrame
            (classification, raised by :func:`thetiscore._data.get_input`).
        TypeError: if 'predictions' is not type dict
            (detection, raised by :func:`thetiscore._data.get_input`).
        TypeError: if any value in 'predictions' dictionary is not type pd.DataFrame
            (detection, raised by :func:`thetiscore._data.get_input`).
        TypeError: if 'annotations' is not type dict
            (detection, raised by :func:`thetiscore._data.get_input`).
        TypeError: if any value in 'annotations' dictionary is not type pd.DataFrame
            (detection, raised by :func:`thetiscore._data.get_input`).
        TypeError: if 'description' is not type dict
        TypeError: if 'description' values are not type str
        KeyError: if 'description' has unexpected or missing keys
        RuntimeError: if the indices of the predicted and ground-truth data set do not match to each other.
            (classification, raised by :func:`thetiscore._data.get_input`).
        ValueError: if "distinct_classes" in application config contains duplicates
            (classification or detection, raised by :func:`thetiscore._data.get_input`).
        AttributeError: if the requested column "labels" does not exist within the predicted data set
            (classification or detection, raised by :func:`thetiscore._data.get_input`).
        AttributeError: if the requested column "predictions" does not exist within the predicted data set
            (regression, raised by :func:`thetiscore._data.get_input`).
        AttributeError: if the requested column "target" does not exist within the ground-truth data set
            (raised by :func:`thetiscore._data.get_input`).
        ValueError: if the data type conversion to one of "int" or "str" of column "labels"
            failed within the predicted data set
            (classification or detection, raised by :func:`thetiscore._data.get_input`).
        ValueError: if the data type conversion to "float" of column "predictions"
            failed within the predicted data set (regression, raised by :func:`thetiscore._data.get_input`).
        ValueError: if the data type conversion to one of "int" or "str" of column "target"
            failed within the ground-truth data set
            (classification or detection, raised by :func:`thetiscore._data.get_input`).
        ValueError: if the data type conversion to "float" of column "target"
            failed within the ground-truth data set (regression, raised by :func:`thetiscore._data.get_input`).
        RuntimeError: if the arrays for predicted labels and ground-truth data set have different dtypes
            (classification or detection, raised by :func:`thetiscore._data.get_input`).
        ValueError: if classes are found that have not been specified by 'distinct_classes' in the config file
            (classification or detection, raised by :func:`thetiscore._data.get_input`).
        ValueError: if binary classification and "binary_positive_label" can not be found in "distinct_classes"
            (classification or detection, raised by :func:`thetiscore._data.get_input`).
        ValueError: if binary classification and a complementary label to "binary_positive_label" can not
            be found in "distinct_classes" (classification or detection, raised by :func:`thetiscore._data.get_input`).
        RuntimeError: if multi-class extraction failed and if more than 2 distinct classes are detected
            (binary classification, raised by :func:`thetiscore._data.get_input`).
        AttributeError: if multi-class extraction failed and if the requested column "confidence" does not exist within
            the predicted data set (binary classification or detection, raised by :func:`thetiscore._data.get_input`).
        ValueError: if multi-class extraction failed and if the data type conversion to "float" of column "confidence"
            failed within the predicted data set (binary classification or detection,
            raised by :func:`thetiscore._data.get_input`).
        RuntimeError: if multi-class extraction failed and if the specified positive label within the application
            config cannot be found in the data set (binary classification,
            raised by :func:`thetiscore._data.get_input`).
        AttributeError: if a sensitive feature is defined for a label that has not been found in the data set.
            (raised by :func:`thetiscore._data.get_input`).
        RuntimeError: if uncertainty evaluation is active but no uncertainty information is given
            (regression, raised by :func:`thetiscore._data.get_input`).
        ValueError: if column "variance" exists in predictions dataframe and if the data type conversion
            to "float" of column "variance" failed within the predicted data set
            (regression, raised by :func:`thetiscore._data.get_input`).
        ValueError: if column "stddev" exists in predictions dataframe and if the data type conversion
            to "float" of column "stddev" failed within the predicted data set
            (regression, raised by :func:`thetiscore._data.get_input`).
        AttributeError: if the requested column for a sensitive feature does not exist within the ground-truth data set
            (raised by :func:`thetiscore._data.get_input`).
        ValueError: if the data type conversion to one of "int" or "str" failed for a requested sensitive feature
            within the ground-truth data set (raised by :func:`thetiscore._data.get_input`).
        ValueError: if a sensitive feature has a missing or invalid entry
            (raised by :func:`thetiscore._data.get_input`).
        ValueError: if a sensitive feature has less than 2 distinct labels
            (raised by :func:`thetiscore._data.get_input`).
        RuntimeError: if bbox_format is not one of 'xyxy', 'xywh', or 'cxcywh'
            (detection, raised by: :func:`thetiscore._data.get_input`).
        AttributeError: if the field '__meta__' within the ground-truth data set annotations is completely missing
            (detection, raised by: :func:`thetiscore._data.get_input`).
        AttributeError: if the meta information provided by '__meta__' is missing for a certain image
            (detection, raised by: :func:`thetiscore._data.get_input`).
        ValueError: if the image width or height information provided by '__meta__' for a certain image are <= 0
            (detection, raised by: :func:`thetiscore._data.get_input`).
        ValueError: if bbox_format is 'xyxy' and xmin > xmax (detection, raised by: :func:`thetiscore._data.get_input`).
        ValueError: if bbox_format is 'xyxy' and ymin > ymax (detection, raised by: :func:`thetiscore._data.get_input`).
        ValueError: if bbox_format is 'xywh' or 'cxcywh' and width is negative
            (detection, raised by: :func:`thetiscore._data.get_input`).
        ValueError: if bbox_format is 'xywh' or 'cxcywh' and height is negative
            (detection, raised by: :func:`thetiscore._data.get_input`).
        RuntimeError: if the fields "weight" or "invert" are missing within a YAML file for a certain rating aspect
            (raised by :func:`thetiscore._utils.get_rating_score`).
        RuntimeError: if "evaluation_spline" has been defined within a YAML file for a certain rating
            aspect but fieds "x" or "y" are missing.
            (raised by :func:`thetiscore._utils.get_rating_score`).
        RuntimeError: if the "weight" parameters do not sum up to 1 during metric calculation.
            (raised by :func:`thetiscore._utils.get_rating_score`).
        RuntimeError: if 'rating_scores' and 'rating_aspects' do not have the same length
            (raised by :func:`thetiscore._utils.get_rating_recommendations`).
        ValueError: if the confidence for any prediction is greater than 1
            (classification, raised by :func:`thetiscore._data.get_input`).
        ValueError: if the confidence for any prediction is lower than 0
            (classification, raised by :func:`thetiscore._data.get_input`).
        ValueError: if there are any NaN or missing values in the required columns in either predictions or annotations
            (raised by :func:`thetiscore._data.get_input`).
        NotImplementedError: if the bounding box matching strategy is not one of "exclusive", "max"
            (raised by :func:`thetiscore._data.get_input`).
        ValueError: if all prediction and annotation dataframes are empty, and task is set to object detection
            (raised by :func:`thetiscore._data.get_input`).
        NotImplementedError: if detection_bbox_clipping is specified and is not one of 'relative .%' or 'absolute .px'
            (raised by :func:`thetiscore._data.get_input`).
        RuntimeError: if detection_bbox_clipping value is not specified correctly (in case of relative or absolute px)
            (raised by :func:`thetiscore._data.get_input`).
        RuntimeError: if task is detection and any boxes are out of bounds set by the detection_bbox_clipping parameter
            (raised by: :func:`thetiscore._data.utils.get_input`).
    """
    return thetiscore_main(thetis_args)
