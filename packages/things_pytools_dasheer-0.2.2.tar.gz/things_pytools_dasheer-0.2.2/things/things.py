import random
import os
import time
from tkinter import filedialog, Tk
import sys

def timer(n):
    return time.sleep(n)

def sum(n, m):
    return n + m

def sub(n, m):
    return n - m

def mult(n, m):
    return n * m

def div(n, m):
    if m != 0:
        return n / m
    else:
        return "ERROR: Division by 0"

def sqrt(n):
    if n >= 0:
        return n ** 0.5
    else:
        return "ERROR: Negative square root"

def pow(n, m):
    return n ** m

def binary(n):
    return bin(n)[2:]
    
def clear():
    if 'google.colab' in sys.modules:
        from IPython.display import clear_output
        clear_output()
    else:
        if os.name == "posix":
            os.system("clear")
        else:
            os.system("cls")
        
def randint(n, m):
    if n < m:
        return random.randint(n, m)
    else:
        return "ERROR: Invalid random number"

def randchoice(lista):
    return random.choice(lista)

def save(archivo_nombre, texto_contenido):
    # 1. Check if running in Google Colab
    if 'google.colab' in sys.modules:
        ruta_colab = f"{archivo_nombre}.txt"
        try:
            with open(ruta_colab, "a", encoding="utf-8") as f:
                f.write(texto_contenido + "\n")
            return f"Success: Saved in Colab environment as {ruta_colab}"
        except Exception as e:
            return f"ERROR: Could not save file in Colab. {e}"

    # 2. PC Mode (Windows/Linux/Mac) with Window Selector
    try:
        from tkinter import filedialog, Tk
        root = Tk()
        root.withdraw() 
        root.attributes("-topmost", True) 

        print("Select the folder where you want to save your file...")
        carpeta_seleccionada = filedialog.askdirectory(title="Select Save Folder")
        
        root.destroy()

        if not carpeta_seleccionada:
            return "Operation cancelled by the user."

        # Create the full path
        ruta_final = os.path.join(carpeta_seleccionada, f"{archivo_nombre}.txt")
        
        with open(ruta_final, "a", encoding="utf-8") as f:
            f.write(texto_contenido + "\n")
        
        return f"Success: File saved at {ruta_final}"
        
    except Exception as e:
        return f"ERROR: An unexpected error occurred on PC. {e}"
