"""Execute shell commands with timeout and output capture.

Used by the engine to run configured commands.  The working directory
is set by the caller — typically the project root or the ralph directory
for ``./`` commands.
"""

from __future__ import annotations

import os
import shlex
import subprocess
from dataclasses import dataclass
from pathlib import Path

from ralphify._output import collect_output

TIMEOUT_EXIT_CODE: int = -1
"""Sentinel exit code returned when a command times out.

Subprocess exit codes are non-negative, so ``-1`` is unambiguous.
Callers should prefer checking ``RunResult.timed_out`` over comparing
the exit code directly.
"""


@dataclass
class RunResult:
    """Result of running a command or script."""

    success: bool
    returncode: int
    output: str
    timed_out: bool = False


def run_command(
    *,
    script: Path | None,
    command: str | None,
    cwd: Path,
    timeout: float,
    env: dict[str, str] | None = None,
) -> RunResult:
    """Run a script or shell command and return the result.

    If *script* is set it takes precedence; otherwise *command* is
    split with :func:`shlex.split` and executed directly (no shell).
    Pipes, redirections, and ``&&`` chaining are not supported in
    commands — use a ``run.*`` script for complex logic.

    When *env* is set, the given variables are merged on top of the
    current process environment so scripts keep ``PATH`` etc.  When
    ``None`` (default), ``subprocess.run`` inherits the parent env.

    On timeout, returns ``returncode=TIMEOUT_EXIT_CODE`` and ``timed_out=True``.
    """
    if script:
        cmd = [str(script)]
    elif command:
        cmd = shlex.split(command)
        if not cmd:
            raise ValueError(f"Command string produced no tokens after parsing: {command!r}")
    else:
        raise ValueError("Either 'script' or 'command' must be provided")

    merged_env = {**os.environ, **env} if env else None

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            cwd=cwd,
            timeout=timeout,
            env=merged_env,
        )
        return RunResult(
            success=result.returncode == 0,
            returncode=result.returncode,
            output=collect_output(result.stdout, result.stderr),
        )
    except subprocess.TimeoutExpired as e:
        return RunResult(
            success=False,
            returncode=TIMEOUT_EXIT_CODE,
            output=collect_output(e.stdout, e.stderr),
            timed_out=True,
        )
