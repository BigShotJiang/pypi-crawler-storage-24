"""Data types for run configuration and state.

These are the core types shared across the engine, CLI, manager, and UI
modules.  They are intentionally separate from ``engine.py`` so modules
that only need the types don't pull in the engine's execution logic.
"""

from __future__ import annotations

import threading
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path


DEFAULT_COMMAND_TIMEOUT: float = 60
"""Default timeout in seconds for commands defined in RALPH.md frontmatter."""

RUN_ID_LENGTH: int = 12
"""Number of hex characters used for generated run IDs."""


def generate_run_id() -> str:
    """Generate a short hex run ID from a random UUID."""
    return uuid.uuid4().hex[:RUN_ID_LENGTH]


class RunStatus(Enum):
    """Lifecycle status of a run.

    Transitions follow a simple path: ``PENDING`` → ``RUNNING`` →
    terminal (``COMPLETED``, ``STOPPED``, or ``FAILED``).  A running loop
    may also be ``PAUSED`` and later resumed back to ``RUNNING``.
    """

    PENDING = "pending"
    RUNNING = "running"
    PAUSED = "paused"
    STOPPED = "stopped"
    COMPLETED = "completed"
    FAILED = "failed"

    @property
    def reason(self) -> str:
        """Return the reason string for terminal statuses.

        Used in ``RUN_STOPPED`` event data.  Only valid for terminal
        statuses (``COMPLETED``, ``FAILED``, ``STOPPED``).

        Raises :class:`ValueError` for non-terminal statuses.
        """
        reason = _STATUS_REASONS.get(self)
        if reason is None:
            raise ValueError(f"{self.name} is not a terminal status")
        return reason


# Maps terminal run statuses to the reason string emitted in RUN_STOPPED events.
_STATUS_REASONS: dict[RunStatus, str] = {
    RunStatus.COMPLETED: "completed",
    RunStatus.FAILED: "error",
    RunStatus.STOPPED: "user_requested",
}


@dataclass
class Command:
    """A named command from RALPH.md frontmatter."""

    name: str
    run: str
    timeout: float = DEFAULT_COMMAND_TIMEOUT


@dataclass
class RunConfig:
    """All settings for a single run.

    Mutable by design: the engine reads fields at each iteration boundary,
    so you can change ``max_iterations``, ``delay``, or ``timeout`` while
    the loop is running and the new values take effect on the next cycle.
    """

    agent: str
    ralph_dir: Path
    ralph_file: Path
    commands: list[Command] = field(default_factory=list)
    args: dict[str, str] = field(default_factory=dict)
    max_iterations: int | None = None
    delay: float = 0
    timeout: float | None = None
    stop_on_error: bool = False
    log_dir: str | None = None
    project_root: Path = field(default=Path("."))


@dataclass
class RunState:
    """Observable state for a run.

    Control methods (:meth:`request_stop`, :meth:`request_pause`,
    :meth:`request_resume`) use :class:`threading.Event` so the run loop
    can react at iteration boundaries without busy-waiting.

    **Counter invariant**: ``timed_out`` is a *subset* of ``failed``, not
    an independent category.  A timed-out iteration increments both
    ``timed_out`` and ``failed``.  Therefore
    ``completed + failed == total iterations`` (use :attr:`total`).
    """

    run_id: str
    status: RunStatus = RunStatus.PENDING
    iteration: int = 0
    completed: int = 0
    failed: int = 0
    timed_out: int = 0
    started_at: datetime | None = None

    _stop_requested: bool = field(default=False, init=False, repr=False, compare=False)
    _resume_event: threading.Event = field(default_factory=threading.Event, init=False, repr=False, compare=False)

    @property
    def total(self) -> int:
        """Total iterations run (``completed + failed``)."""
        return self.completed + self.failed

    def __post_init__(self) -> None:
        # Set initially: the run starts in an unpaused (resumed) state.
        self._resume_event.set()

    def request_stop(self) -> None:
        """Signal the loop to stop after the current iteration."""
        self._stop_requested = True
        self._resume_event.set()

    def request_pause(self) -> None:
        """Pause the loop between iterations until resumed."""
        self.status = RunStatus.PAUSED
        self._resume_event.clear()

    def request_resume(self) -> None:
        """Resume a paused loop."""
        self.status = RunStatus.RUNNING
        self._resume_event.set()

    @property
    def stop_requested(self) -> bool:
        """Whether a stop has been requested."""
        return self._stop_requested

    @property
    def paused(self) -> bool:
        """Whether the run is currently paused."""
        return not self._resume_event.is_set()

    def wait_for_unpause(self, timeout: float | None = None) -> bool:
        """Block until unpaused or timeout. Returns True if unpaused."""
        return self._resume_event.wait(timeout=timeout)

    def mark_completed(self) -> None:
        """Record a successful iteration."""
        self.completed += 1

    def mark_failed(self) -> None:
        """Record a failed iteration."""
        self.failed += 1

    def mark_timed_out(self) -> None:
        """Record a timed-out iteration (also counts as failed)."""
        self.timed_out += 1
        self.mark_failed()
