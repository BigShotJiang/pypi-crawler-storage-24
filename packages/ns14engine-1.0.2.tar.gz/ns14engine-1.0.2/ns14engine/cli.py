import os
import sys
import time
import subprocess
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

try:
    from .templates import APP_PY_TEMPLATE, APP_NSX_TEMPLATE, STYLE_NSS_TEMPLATE
except ImportError:
    from templates import APP_PY_TEMPLATE, APP_NSX_TEMPLATE, STYLE_NSS_TEMPLATE

class ReloadHandler(FileSystemEventHandler):
    def __init__(self):
        self.process = None
        self.start_app()

    def start_app(self):
        self.process = subprocess.Popen([sys.executable, "app.py"])

    def on_modified(self, event):
        if event.src_path.endswith(('.nsx', '.nss', '.py')):
            print(f"\n🔄 बदलाव मिला: Reloading UI...")
            if self.process:
                self.process.terminate()
                self.process.wait()
            self.start_app()

def main():
    if len(sys.argv) < 2:
        print("⚡ NS14 Framework Commands: create <name>, start, build")
        sys.exit(1)

    cmd = sys.argv[1].lower()

    if cmd == "create":
        project_name = sys.argv[2]
        os.makedirs(f"{project_name}/src", exist_ok=True)
        
        with open(f"{project_name}/app.py", "w", encoding="utf-8") as f:
            f.write(APP_PY_TEMPLATE)
        with open(f"{project_name}/src/App.nsx", "w", encoding="utf-8") as f:
            f.write(APP_NSX_TEMPLATE)
        with open(f"{project_name}/src/style.nss", "w", encoding="utf-8") as f:
            f.write(STYLE_NSS_TEMPLATE)
            
        print(f"✅ Project '{project_name}' created!")

    elif cmd == "start":
        print("🔥 NS14 Hot Reloading Active!")
        handler = ReloadHandler()
        observer = Observer()
        observer.schedule(handler, path=".", recursive=True)
        observer.start()
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            observer.stop()
            if handler.process:
                handler.process.terminate()
        observer.join()

    elif cmd == "build":
        print("📦 .exe बनाई जा रही है...")
        sep = ';' if os.name == 'nt' else ':'
        subprocess.run([
            "pyinstaller", "--noconfirm", "--onefile", "--windowed",
            f"--add-data=src{sep}src", "--name=My_NS14_App", "app.py"
        ])
        print("🎉 Build Complete! 'dist' फोल्डर देखें।")

if __name__ == '__main__':
    main()
