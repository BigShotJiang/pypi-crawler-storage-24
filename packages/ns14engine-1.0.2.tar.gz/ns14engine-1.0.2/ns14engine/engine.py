import sys
import os
import xml.etree.ElementTree as ET
from PyQt6.QtWidgets import QApplication, QWidget, QVBoxLayout, QPushButton, QLabel
from PyQt6.QtCore import Qt  # 💡 यहाँ से Qt इम्पोर्ट किया है

class NS14Window(QWidget):
    def __init__(self, nsx_file, nss_file):
        super().__init__()
        self.setWindowTitle("NS14 Native App 🚀")
        self.resize(800, 600)
        self.layout = QVBoxLayout()
        self.setLayout(self.layout)
        
        if os.path.exists(nss_file):
            with open(nss_file, "r", encoding="utf-8") as f:
                self.setStyleSheet(f.read())
                
        if os.path.exists(nsx_file):
            with open(nsx_file, "r", encoding="utf-8") as f:
                self.build_ui(f.read())
        else:
            self.layout.addWidget(QLabel(f"Error: {nsx_file} not found!"))

    def build_ui(self, nsx_code):
        try:
            root = ET.fromstring(nsx_code)
            for el in root:
                if el.tag in ["text", "h1", "h2", "p"]:
                    w = QLabel(el.text)
                elif el.tag == "button":
                    w = QPushButton(el.text)
                    w.setCursor(Qt.CursorShape.PointingHandCursor) # ✅ FIX: सही कर्सर
                else:
                    continue

                if "id" in el.attrib:
                    w.setObjectName(el.attrib["id"])
                
                self.layout.addWidget(w)
        except Exception as e:
            err = QLabel(f"NSX Parsing Error: {e}")
            err.setStyleSheet("color: red; font-size: 20px;")
            self.layout.addWidget(err)

def run_app():
    app = QApplication(sys.argv)
    window = NS14Window("src/App.nsx", "src/style.nss")
    window.show()
    sys.exit(app.exec())
