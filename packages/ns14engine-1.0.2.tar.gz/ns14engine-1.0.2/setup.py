from setuptools import setup, find_packages

setup(
    name="ns14engine",
    version="1.0.2",
    packages=find_packages(),
    install_requires=[
        "PyQt6",
        "watchdog",
        "pyinstaller"
    ],
    entry_points={
        "console_scripts": [
            "ns14=ns14engine.cli:main"
        ]
    },
    description="A Native Desktop Framework using XML/CSS syntax.",
    author="Neelesh Singour"
)
