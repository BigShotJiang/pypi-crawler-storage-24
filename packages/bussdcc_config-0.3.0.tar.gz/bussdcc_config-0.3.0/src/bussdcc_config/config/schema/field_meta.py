from dataclasses import dataclass, Field
from typing import Any
from types import MappingProxyType


@dataclass(slots=True, frozen=True)
class FieldMeta:
    label: str
    group: str = "General"
    required: bool = False
    help: str | None = None
    min: int | float | None = None
    max: int | float | None = None
    step: int | float | None = None

    @staticmethod
    def from_field(f: Field[object]) -> "FieldMeta":
        meta: MappingProxyType[Any, Any] = f.metadata

        return FieldMeta(
            label=meta.get("label", f.name),
            group=meta.get("group", "General"),
            required=meta.get("required", False),
            help=meta.get("help"),
            min=meta.get("min"),
            max=meta.get("max"),
            step=meta.get("step"),
        )
