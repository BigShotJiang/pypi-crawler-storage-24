"""RL training dashboard routes."""

from __future__ import annotations

import json
import logging
from typing import Any

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse

from ..dependencies import create_dag_reader
from ..rl_loader import (
    build_episode_graph,
    discover_training_runs,
    load_episode_steps,
    load_policy_info,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/rl")


def _ctx(request: Request) -> dict[str, Any]:
    """Base template context."""
    return {"request": request}


@router.get("/", response_class=HTMLResponse)
async def rl_training_list() -> RedirectResponse:
    """Redirect /rl/ to /training/ — the DB-backed training page."""
    return RedirectResponse(url="/training/", status_code=301)


@router.get("/{slug}/", response_class=HTMLResponse)
async def rl_training_detail(request: Request, slug: str) -> HTMLResponse:
    """Detail view for a single RL training run with charts."""
    output_dir = getattr(request.app.state, "output_dir", None)
    if not output_dir:
        raise HTTPException(status_code=404, detail="No output directory configured")

    runs = discover_training_runs(output_dir)
    run = next((r for r in runs if r.slug == slug), None)
    if run is None:
        raise HTTPException(status_code=404, detail=f"Training run '{slug}' not found")

    # Load policy data for Q-table heatmap
    policy_info = load_policy_info(run.path)

    # Load phases, max_steps, and setup_duration from training config
    phases: list[dict[str, Any]] = []
    max_steps: int = 0
    setup_duration_secs: float | None = None
    config_path = run.path / "training_config.json"
    if config_path.exists():
        config = json.loads(config_path.read_text())
        phases = config.get("phases", [])
        max_steps = config.get("max_steps", 0)
        setup_duration_secs = config.get("setup_duration_secs")

    # Build chart data from checkpoints
    checkpoint_data = [
        {
            "episode": c.episode,
            "mean_reward": c.mean_reward,
            "epsilon": c.epsilon,
            "name": c.name,
        }
        for c in run.checkpoints
    ]

    # Build per-episode data
    episode_data = [
        {
            "episode": e.episode,
            "reward": e.reward,
            "steps": e.steps,
            "epsilon": e.epsilon,
            "satisfied": e.satisfied,
            "total_aps": e.total_aps,
            "all_satisfied": e.all_satisfied,
            "duration_secs": e.duration_secs,
            "execution_ms": e.execution_ms,
            "tokens": e.tokens,
            "backtracks": e.backtracks,
            "started_at": e.started_at,
            "finished_at": e.finished_at,
        }
        for e in run.episode_log
    ]

    # Compute episode completion rate from episode_log
    episodes_with_status = [e for e in run.episode_log if e.all_satisfied is not None]
    completed_episodes = sum(1 for e in episodes_with_status if e.all_satisfied)
    completion_rate = (
        completed_episodes / len(episodes_with_status) if episodes_with_status else None
    )

    templates = request.app.state.templates
    return templates.TemplateResponse(
        "rl_detail.html",
        {
            **_ctx(request),
            "run": run,
            "checkpoint_data_json": json.dumps(checkpoint_data),
            "episode_data_json": json.dumps(episode_data),
            "phases": phases,
            "max_steps": max_steps,
            "setup_duration_secs": setup_duration_secs,
            "progress": run.progress,
            "progress_json": json.dumps(
                {
                    "episode": run.progress.episode,
                    "step": run.progress.step,
                    "max_steps": run.progress.max_steps,
                    "satisfied": run.progress.satisfied,
                    "total_aps": run.progress.total_aps,
                    "timestamp": run.progress.timestamp,
                }
            )
            if run.progress
            else "null",
            "completion_rate": completion_rate,
            "completed_episodes": completed_episodes,
            "total_episodes_tracked": len(episodes_with_status),
            "policy_info": policy_info,
            "policy_json": json.dumps(
                {
                    "ap_ids": policy_info.ap_ids,
                    "num_states": policy_info.num_states,
                    "num_actions": policy_info.num_actions,
                    "q_table": policy_info.q_table,
                    "visit_counts": policy_info.visit_counts,
                    "greedy_actions": policy_info.greedy_actions,
                    "total_visits": policy_info.total_visits,
                }
            )
            if policy_info
            else "null",
        },
    )


@router.get("/{slug}/episode/{episode}/", response_class=HTMLResponse)
async def rl_episode_detail(request: Request, slug: str, episode: int) -> HTMLResponse:
    """DAG view for a single RL training episode."""
    output_dir = getattr(request.app.state, "output_dir", None)
    if not output_dir:
        raise HTTPException(status_code=404, detail="No output directory configured")

    runs = discover_training_runs(output_dir)
    run = next((r for r in runs if r.slug == slug), None)
    if run is None:
        raise HTTPException(status_code=404, detail=f"Training run '{slug}' not found")

    steps = load_episode_steps(run.path, episode)
    graph = build_episode_graph(steps)

    # Find episode summary from episode_log
    episode_info = next((e for e in run.episode_log if e.episode == episode), None)

    # --- Load rich artifact DAG data ---
    nodes_json = "[]"
    edges_json = "[]"
    artifacts_json = "{}"
    runs_json = "[]"
    instance_id: str | None = None
    dag_mode: str | None = None  # "per_episode" | "time_filtered" | "full_instance"
    has_dag_data = False

    # Determine instance_id: from episode_info first, then sequential rotation
    if episode_info and episode_info.instance_id:
        instance_id = episode_info.instance_id
    elif run.instance_ids:
        idx = (episode - 1) % len(run.instance_ids)
        instance_id = run.instance_ids[idx]

    if instance_id:
        dag_dir = run.path / "artifact_dags" / instance_id
        if dag_dir.is_dir():
            try:
                reader = create_dag_reader(dag_dir)

                # Determine best filter: workflow_id > timestamps > full instance
                workflow_id = episode_info.workflow_id if episode_info else None
                time_start = None
                time_end = None

                if workflow_id:
                    dag_mode = "per_episode"
                elif (
                    episode_info
                    and episode_info.started_at
                    and episode_info.finished_at
                ):
                    from datetime import datetime

                    time_start = datetime.fromisoformat(
                        episode_info.started_at
                    ).timestamp()
                    time_end = datetime.fromisoformat(
                        episode_info.finished_at
                    ).timestamp()
                    dag_mode = "time_filtered"
                else:
                    dag_mode = "full_instance"

                vis_data = reader.get_visualization_data_for_episode(
                    workflow_id=workflow_id,
                    time_start=time_start,
                    time_end=time_end,
                )

                if vis_data.nodes:
                    nodes_json = json.dumps(vis_data.nodes)
                    edges_json = json.dumps(vis_data.edges)
                    artifacts_json = json.dumps(vis_data.artifacts)
                    runs_json = json.dumps(vis_data.runs)
                    has_dag_data = True
            except Exception:
                logger.exception("Failed to load DAG for %s episode %d", slug, episode)

    templates = request.app.state.templates
    return templates.TemplateResponse(
        "rl_episode.html",
        {
            **_ctx(request),
            "run": run,
            "episode": episode,
            "episode_info": episode_info,
            "steps": steps,
            "graph_json": json.dumps(graph),
            "instance_id": instance_id,
            "dag_mode": dag_mode,
            "has_dag_data": has_dag_data,
            "nodes_json": nodes_json,
            "edges_json": edges_json,
            "artifacts_json": artifacts_json,
            "runs_json": runs_json,
            "all_ap_ids_json": json.dumps(run.ap_ids),
        },
    )
