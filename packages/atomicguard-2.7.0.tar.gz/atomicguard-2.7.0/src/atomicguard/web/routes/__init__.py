"""Dashboard route registration."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from fastapi import FastAPI


def register_routes(app: FastAPI) -> None:
    """Include all page routers."""
    from .ollama_pages import router as ollama_router
    from .pages import router
    from .policy_pages import router as policy_router
    from .rl_pages import router as rl_router
    from .run_pages import router as run_router
    from .spark_pages import router as spark_router
    from .training_pages import router as training_router
    from .workflow_pages import router as workflow_router
    from .ws_routes import router as ws_router

    app.include_router(router)
    app.include_router(rl_router)
    app.include_router(run_router)
    app.include_router(training_router)
    app.include_router(policy_router)
    app.include_router(spark_router)
    app.include_router(ollama_router)
    app.include_router(workflow_router)
    app.include_router(ws_router)
