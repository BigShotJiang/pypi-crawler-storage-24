"""DB-backed workflow routes — read-only views and editor."""

from __future__ import annotations

import json
import logging
import re
from dataclasses import replace
from typing import Any

from fastapi import APIRouter, Depends, Form, HTTPException, Request, UploadFile
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse

from atomicguard.domain.interfaces import (
    APContextRepositoryInterface,
    WorkflowRepositoryInterface,
)
from atomicguard.domain.models import (
    ActionPairDefinition,
    APContextEntry,
)

from ..dependencies import get_ap_context_repo, get_workflow_repo

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/workflows", tags=["workflows"])


def _ctx(request: Request) -> dict[str, Any]:
    """Base template context."""
    return {
        "request": request,
        "config_loader": request.app.state.config_loader,
    }


def _slugify(name: str) -> str:
    """Convert a name to a URL-safe slug."""
    slug = name.lower().strip()
    slug = re.sub(r"[^a-z0-9]+", "-", slug)
    return slug.strip("-")


def _build_ap_context_dict(
    ctx_repo: APContextRepositoryInterface,
) -> dict[str, dict[str, str]]:
    """Build ap_context dict from DB for graph extraction."""
    ap_context_dict: dict[str, dict[str, str]] = {}
    try:
        all_contexts = ctx_repo.list_contexts()
        for ap_id, entry in all_contexts.items():
            ap_context_dict[ap_id] = {
                "role": entry.role,
                "task": entry.task,
                "constraints": entry.constraints,
                "feedback_wrapper": entry.feedback_wrapper,
                "escalation_feedback_wrapper": entry.escalation_feedback_wrapper,
                "artifact_context": entry.artifact_context,
            }
    except RuntimeError:
        logger.debug("AP context repository not available, returning empty dict")
    return ap_context_dict


def _detect_cycle(
    ap_id: str,
    requires: list[str],
    all_aps: dict[str, list[str]],
) -> bool:
    """Return True if adding requires to ap_id would create a cycle."""
    visited: set[str] = set()

    def _dfs(current: str) -> bool:
        if current == ap_id:
            return True
        if current in visited:
            return False
        visited.add(current)
        return any(_dfs(dep) for dep in all_aps.get(current, []))

    return any(_dfs(req) for req in requires)


# ─── Read-Only Routes ───────────────────────────────────────


@router.get("/", response_class=HTMLResponse)
async def workflow_list(
    request: Request,
    q: str = "",
    repo: WorkflowRepositoryInterface = Depends(get_workflow_repo),
) -> HTMLResponse:
    """List all workflows from the database, with optional search filter."""
    workflows = repo.list_workflows()

    if q:
        q_lower = q.lower()
        workflows = [
            w
            for w in workflows
            if q_lower in w.name.lower()
            or q_lower in w.slug.lower()
            or q_lower in (w.description or "").lower()
        ]

    workflows.sort(key=lambda w: w.name.lower())

    templates = request.app.state.templates

    if request.headers.get("HX-Request"):
        return templates.TemplateResponse(
            "partials/workflow_cards.html",
            {**_ctx(request), "workflows": workflows, "q": q},
        )

    return templates.TemplateResponse(
        "workflow_list.html",
        {**_ctx(request), "workflows": workflows, "q": q},
    )


@router.get("/{slug}/", response_class=HTMLResponse)
async def workflow_detail(
    request: Request,
    slug: str,
    repo: WorkflowRepositoryInterface = Depends(get_workflow_repo),
    ctx_repo: APContextRepositoryInterface = Depends(get_ap_context_repo),
) -> HTMLResponse:
    """Workflow detail with Cytoscape topology viewer, backed by DB."""
    from atomicguard.visualization.workflow_config_exporter import (
        _extract_ap_context,
        _extract_graph,
    )

    try:
        workflow_json = repo.export_to_json(slug)
    except KeyError as exc:
        raise HTTPException(
            status_code=404, detail=f"Workflow '{slug}' not found"
        ) from exc

    ap_context_dict = _build_ap_context_dict(ctx_repo)
    nodes, edges = _extract_graph(workflow_json)
    prompt_data = _extract_ap_context(workflow_json, ap_context_dict)

    templates = request.app.state.templates
    return templates.TemplateResponse(
        "workflow_detail.html",
        {
            **_ctx(request),
            "slug": slug,
            "workflow": workflow_json,
            "nodes_json": json.dumps(nodes),
            "edges_json": json.dumps(edges),
            "prompts_json": json.dumps(prompt_data),
        },
    )


# ─── Editor Routes ──────────────────────────────────────────


@router.get("/{slug}/edit", response_class=HTMLResponse)
async def workflow_edit(
    request: Request,
    slug: str,
    repo: WorkflowRepositoryInterface = Depends(get_workflow_repo),
    ctx_repo: APContextRepositoryInterface = Depends(get_ap_context_repo),
) -> HTMLResponse:
    """Workflow editor with interactive Cytoscape and HTMX sidebar forms."""
    from atomicguard.visualization.workflow_config_exporter import (
        _extract_ap_context,
        _extract_graph,
    )

    try:
        workflow = repo.get_workflow(slug)
        workflow_json = repo.export_to_json(slug)
    except KeyError as exc:
        raise HTTPException(
            status_code=404, detail=f"Workflow '{slug}' not found"
        ) from exc

    ap_context_dict = _build_ap_context_dict(ctx_repo)
    nodes, edges = _extract_graph(workflow_json)
    prompt_data = _extract_ap_context(workflow_json, ap_context_dict)

    templates = request.app.state.templates
    return templates.TemplateResponse(
        "workflow_editor.html",
        {
            **_ctx(request),
            "slug": slug,
            "workflow": workflow,
            "workflow_json": workflow_json,
            "nodes_json": json.dumps(nodes),
            "edges_json": json.dumps(edges),
            "prompts_json": json.dumps(prompt_data),
            "ap_context_dict": ap_context_dict,
        },
    )


# ─── Workflow CRUD ──────────────────────────────────────────


@router.put("/{slug}/meta", response_class=HTMLResponse)
async def workflow_update_meta(
    request: Request,
    slug: str,
    name: str = Form(...),
    description: str = Form(""),
    model: str = Form(""),
    provider: str = Form(""),
    rmax: int = Form(3),
    repo: WorkflowRepositoryInterface = Depends(get_workflow_repo),
) -> HTMLResponse:
    """Update workflow metadata (name, description, model, etc.)."""
    try:
        workflow = repo.get_workflow(slug)
    except KeyError as exc:
        raise HTTPException(status_code=404) from exc

    updated = replace(
        workflow,
        name=name.strip(),
        description=description.strip(),
        model=model.strip(),
        provider=provider.strip(),
        rmax=rmax,
    )
    repo.save_workflow(updated)

    templates = request.app.state.templates
    return templates.TemplateResponse(
        "partials/workflow_meta_form.html",
        {**_ctx(request), "slug": slug, "workflow": updated, "saved": True},
    )


@router.post("/{slug}/clone")
async def workflow_clone(
    slug: str,
    repo: WorkflowRepositoryInterface = Depends(get_workflow_repo),
) -> RedirectResponse:
    """Clone a workflow with a new slug."""
    try:
        workflow = repo.get_workflow(slug)
    except KeyError as exc:
        raise HTTPException(status_code=404) from exc

    new_name = f"{workflow.name} (copy)"
    new_slug = _slugify(new_name)

    # Ensure unique slug
    existing_slugs = {w.slug for w in repo.list_workflows()}
    counter = 2
    base_slug = new_slug
    while new_slug in existing_slugs:
        new_slug = f"{base_slug}-{counter}"
        counter += 1

    cloned = replace(workflow, slug=new_slug, name=new_name)
    repo.save_workflow(cloned)
    return RedirectResponse(f"/workflows/{new_slug}/edit", status_code=303)


@router.delete("/{slug}/")
async def workflow_delete(
    slug: str,
    repo: WorkflowRepositoryInterface = Depends(get_workflow_repo),
) -> HTMLResponse:
    """Delete a workflow. Returns HTMX redirect."""
    try:
        repo.delete_workflow(slug)
    except KeyError as exc:
        raise HTTPException(status_code=404) from exc

    return HTMLResponse(
        content="",
        status_code=200,
        headers={"HX-Redirect": "/workflows/"},
    )


@router.get("/{slug}/export")
async def workflow_export(
    slug: str,
    repo: WorkflowRepositoryInterface = Depends(get_workflow_repo),
) -> JSONResponse:
    """Export workflow as JSON file download."""
    try:
        workflow_json = repo.export_to_json(slug)
    except KeyError as exc:
        raise HTTPException(status_code=404) from exc

    return JSONResponse(
        content=workflow_json,
        headers={
            "Content-Disposition": f'attachment; filename="{slug}.json"',
        },
    )


@router.post("/import")
async def workflow_import(
    file: UploadFile,
    repo: WorkflowRepositoryInterface = Depends(get_workflow_repo),
) -> RedirectResponse:
    """Import a workflow from a JSON file upload."""
    content = await file.read()
    try:
        data = json.loads(content)
    except json.JSONDecodeError as exc:
        raise HTTPException(status_code=400, detail="Invalid JSON") from exc

    slug = repo.import_from_json(data)
    return RedirectResponse(f"/workflows/{slug}/edit", status_code=303)


# ─── Action Pair CRUD ───────────────────────────────────────


@router.get("/{slug}/aps/{ap_id}/form", response_class=HTMLResponse)
async def ap_form_get(
    request: Request,
    slug: str,
    ap_id: str,
    repo: WorkflowRepositoryInterface = Depends(get_workflow_repo),
) -> HTMLResponse:
    """Return AP edit form as an HTMX partial."""
    try:
        workflow = repo.get_workflow(slug)
    except KeyError as exc:
        raise HTTPException(status_code=404) from exc

    ap = None
    for a in workflow.action_pairs:
        if a.ap_id == ap_id:
            ap = a
            break

    if ap is None:
        raise HTTPException(status_code=404, detail=f"AP '{ap_id}' not found")

    templates = request.app.state.templates
    return templates.TemplateResponse(
        "partials/ap_form.html",
        {
            **_ctx(request),
            "slug": slug,
            "ap": ap,
            "all_ap_ids": [a.ap_id for a in workflow.action_pairs],
        },
    )


@router.post("/{slug}/aps/", response_class=HTMLResponse)
async def ap_add(
    slug: str,
    ap_id: str = Form(...),
    generator: str = Form(""),
    guard: str = Form("syntax"),
    description: str = Form(""),
    repo: WorkflowRepositoryInterface = Depends(get_workflow_repo),
) -> HTMLResponse:
    """Add a new action pair to a workflow."""
    try:
        workflow = repo.get_workflow(slug)
    except KeyError as exc:
        raise HTTPException(status_code=404) from exc

    ap_id = ap_id.strip()
    if not ap_id:
        raise HTTPException(status_code=400, detail="AP ID is required")

    existing_ids = {ap.ap_id for ap in workflow.action_pairs}
    if ap_id in existing_ids:
        raise HTTPException(status_code=400, detail=f"AP '{ap_id}' already exists")

    new_ap = ActionPairDefinition(
        ap_id=ap_id,
        generator=generator.strip(),
        guard=guard.strip(),
        description=description.strip(),
    )
    updated = replace(
        workflow,
        action_pairs=workflow.action_pairs + (new_ap,),
    )
    repo.save_workflow(updated)

    # Return redirect to refresh the editor
    return HTMLResponse(
        content="",
        status_code=200,
        headers={"HX-Redirect": f"/workflows/{slug}/edit"},
    )


@router.put("/{slug}/aps/{ap_id}", response_class=HTMLResponse)
async def ap_update(
    request: Request,
    slug: str,
    ap_id: str,
    repo: WorkflowRepositoryInterface = Depends(get_workflow_repo),
) -> HTMLResponse:
    """Update an action pair's properties."""
    try:
        workflow = repo.get_workflow(slug)
    except KeyError as exc:
        raise HTTPException(status_code=404) from exc

    form = await request.form()

    # Find the AP to update
    ap_index = None
    for i, ap in enumerate(workflow.action_pairs):
        if ap.ap_id == ap_id:
            ap_index = i
            break

    if ap_index is None:
        raise HTTPException(status_code=404, detail=f"AP '{ap_id}' not found")

    old_ap = workflow.action_pairs[ap_index]

    # Parse requires from comma-separated string
    requires_str = str(form.get("requires", "")).strip()
    requires = tuple(r.strip() for r in requires_str.split(",") if r.strip())

    # Parse escalation targets
    escalate_str = str(form.get("escalate_feedback_to", "")).strip()
    escalate_to = tuple(e.strip() for e in escalate_str.split(",") if e.strip())

    # Cycle detection for requires
    all_aps_deps = {ap.ap_id: list(ap.requires) for ap in workflow.action_pairs}
    all_aps_deps[ap_id] = list(requires)
    if _detect_cycle(ap_id, list(requires), all_aps_deps):
        raise HTTPException(
            status_code=400,
            detail=f"Adding requires {requires} to '{ap_id}' would create a cycle",
        )

    updated_ap = replace(
        old_ap,
        generator=str(form.get("generator", old_ap.generator)).strip(),
        guard=str(form.get("guard", old_ap.guard)).strip(),
        description=str(form.get("description", old_ap.description)).strip(),
        r_patience=int(str(form["r_patience"])) if form.get("r_patience") else None,
        e_max=int(str(form.get("e_max", old_ap.e_max))),
        requires=requires,
        escalate_feedback_to=escalate_to,
        goal=form.get("goal") == "on",
    )

    aps = list(workflow.action_pairs)
    aps[ap_index] = updated_ap
    updated_workflow = replace(workflow, action_pairs=tuple(aps))
    repo.save_workflow(updated_workflow)

    templates = request.app.state.templates
    return templates.TemplateResponse(
        "partials/ap_form.html",
        {
            **_ctx(request),
            "slug": slug,
            "ap": updated_ap,
            "all_ap_ids": [a.ap_id for a in updated_workflow.action_pairs],
            "saved": True,
        },
    )


@router.delete("/{slug}/aps/{ap_id}", response_class=HTMLResponse)
async def ap_delete(
    slug: str,
    ap_id: str,
    repo: WorkflowRepositoryInterface = Depends(get_workflow_repo),
) -> HTMLResponse:
    """Remove an action pair from a workflow."""
    try:
        workflow = repo.get_workflow(slug)
    except KeyError as exc:
        raise HTTPException(status_code=404) from exc

    aps = [ap for ap in workflow.action_pairs if ap.ap_id != ap_id]
    if len(aps) == len(workflow.action_pairs):
        raise HTTPException(status_code=404, detail=f"AP '{ap_id}' not found")

    updated = replace(workflow, action_pairs=tuple(aps))
    repo.save_workflow(updated)

    return HTMLResponse(
        content="",
        status_code=200,
        headers={"HX-Redirect": f"/workflows/{slug}/edit"},
    )


# ─── AP Context CRUD ────────────────────────────────────────


@router.get("/api/context/{ap_id}/form", response_class=HTMLResponse)
async def ap_context_form(
    request: Request,
    ap_id: str,
    ctx_repo: APContextRepositoryInterface = Depends(get_ap_context_repo),
) -> HTMLResponse:
    """Return the AP context edit form as an HTMX partial."""
    try:
        entry = ctx_repo.get_context(ap_id)
    except KeyError:
        entry = APContextEntry(ap_id=ap_id)

    templates = request.app.state.templates
    return templates.TemplateResponse(
        "partials/ap_context_form.html",
        {**_ctx(request), "entry": entry, "ap_id": ap_id},
    )


@router.put("/api/context/{ap_id}", response_class=HTMLResponse)
async def ap_context_update(
    request: Request,
    ap_id: str,
    role: str = Form(""),
    task: str = Form(""),
    constraints: str = Form(""),
    feedback_wrapper: str = Form(""),
    escalation_feedback_wrapper: str = Form(""),
    artifact_context: str = Form(""),
    ctx_repo: APContextRepositoryInterface = Depends(get_ap_context_repo),
) -> HTMLResponse:
    """Update AP context."""
    entry = APContextEntry(
        ap_id=ap_id,
        role=role.strip(),
        task=task.strip(),
        constraints=constraints.strip(),
        feedback_wrapper=feedback_wrapper.strip(),
        escalation_feedback_wrapper=escalation_feedback_wrapper.strip(),
        artifact_context=artifact_context.strip(),
    )
    ctx_repo.save_context(entry)

    templates = request.app.state.templates
    return templates.TemplateResponse(
        "partials/ap_context_form.html",
        {**_ctx(request), "entry": entry, "ap_id": ap_id, "saved": True},
    )
