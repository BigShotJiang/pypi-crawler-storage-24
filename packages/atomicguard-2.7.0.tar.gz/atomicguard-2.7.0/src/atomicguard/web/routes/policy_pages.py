"""Policy library routes — list, detail, scan."""

from __future__ import annotations

import contextlib
import json
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse

from atomicguard.domain.interfaces import (
    PolicyRepositoryInterface,
    TrainingRunRepositoryInterface,
)

from ..dependencies import get_policy_repo, get_training_repo

router = APIRouter(prefix="/policies", tags=["policies"])


def _ctx(request: Request) -> dict[str, Any]:
    return {
        "request": request,
        "config_loader": getattr(request.app.state, "config_loader", None),
    }


# ─── List ──────────────────────────────────────────────────


@router.get("/", response_class=HTMLResponse)
async def policy_list(
    request: Request,
    repo: PolicyRepositoryInterface = Depends(get_policy_repo),
) -> HTMLResponse:
    """List all policies in the library."""
    policies = repo.list_policies(limit=100)
    templates = request.app.state.templates
    return templates.TemplateResponse(
        "policy_list.html",
        {**_ctx(request), "policies": policies},
    )


# ─── Detail ────────────────────────────────────────────────


@router.get("/{slug}/", response_class=HTMLResponse)
async def policy_detail(
    request: Request,
    slug: str,
    repo: PolicyRepositoryInterface = Depends(get_policy_repo),
    training_repo: TrainingRunRepositoryInterface = Depends(get_training_repo),
) -> HTMLResponse:
    """Policy detail with Q-table heatmap and provenance."""
    try:
        policy = repo.get_policy_by_slug(slug)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="Policy not found") from exc

    # Load training run if linked
    training_run = None
    if policy.training_run_id:
        with contextlib.suppress(KeyError):
            training_run = training_repo.get_run(policy.training_run_id)

    # Load Q-table data from filesystem for heatmap
    policy_json = "null"
    from pathlib import Path

    from ..rl_loader import load_policy_info

    policy_path = Path(policy.path) if policy.path else None
    if policy_path and policy_path.is_dir():
        # The path is a checkpoint dir — load Q-table directly
        policy_info = load_policy_info(policy_path.parent)
        if policy_info:
            policy_json = json.dumps(
                {
                    "ap_ids": policy_info.ap_ids,
                    "num_states": policy_info.num_states,
                    "num_actions": policy_info.num_actions,
                    "q_table": policy_info.q_table,
                    "visit_counts": policy_info.visit_counts,
                    "greedy_actions": policy_info.greedy_actions,
                    "total_visits": policy_info.total_visits,
                }
            )

    templates = request.app.state.templates
    return templates.TemplateResponse(
        "policy_detail.html",
        {
            **_ctx(request),
            "policy": policy,
            "training_run": training_run,
            "policy_json": policy_json,
        },
    )


# ─── Scan ──────────────────────────────────────────────────


@router.post("/scan", response_class=HTMLResponse)
async def policy_scan(
    request: Request,
    repo: PolicyRepositoryInterface = Depends(get_policy_repo),
) -> RedirectResponse:
    """Scan checkpoint directories and import new policies."""
    output_dir = getattr(request.app.state, "output_dir", None)
    if not output_dir:
        raise HTTPException(status_code=400, detail="No output directory configured")

    repo.scan_checkpoints(str(output_dir))
    return RedirectResponse(url="/policies/", status_code=303)
