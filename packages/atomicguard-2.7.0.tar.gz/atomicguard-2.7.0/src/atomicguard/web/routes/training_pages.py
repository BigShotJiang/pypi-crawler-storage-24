"""Training run management routes — list, detail, import, new, start."""

from __future__ import annotations

import datetime as dt
import json
import logging
from typing import Any

from fastapi import APIRouter, Depends, Form, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse

from atomicguard.domain.interfaces import (
    PolicyRepositoryInterface,
    TrainingRunRepositoryInterface,
    WorkflowRepositoryInterface,
)

from ..dependencies import get_policy_repo, get_training_repo, get_workflow_repo

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/training", tags=["training"])

AVAILABLE_REWARDS = ["sparse", "step", "efficiency", "potential-based"]
AVAILABLE_ARMS = [
    "singleshot",
    "s1_direct",
    "s1_tdd",
    "s1_tdd_verified",
    "s1_tdd_behavior",
    "s1_decomposed",
    "s1_decomposed_lite",
    "s1_tdd_review",
    "s1_tdd_review_backtrack",
    "s1_tdd_rule_backtrack",
    "adaptive_backtrack",
    "s1_tdd_eval",
    "s1_decomposed_lite_eval",
    "singleshot_eval",
]


def _now_iso() -> str:
    return dt.datetime.now(dt.UTC).isoformat()


def _ctx(request: Request) -> dict[str, Any]:
    return {
        "request": request,
        "config_loader": getattr(request.app.state, "config_loader", None),
    }


# ─── List ──────────────────────────────────────────────────


@router.get("/", response_class=HTMLResponse)
async def training_list(
    request: Request,
    status: str = "",
    repo: TrainingRunRepositoryInterface = Depends(get_training_repo),
) -> HTMLResponse:
    """List training runs with optional status filter."""
    runs = repo.list_runs(status=status or None, limit=100)
    templates = request.app.state.templates
    ctx = {
        **_ctx(request),
        "runs": runs,
        "status_filter": status,
    }
    if request.headers.get("HX-Request"):
        return templates.TemplateResponse("partials/training_cards.html", ctx)
    return templates.TemplateResponse("training_list.html", ctx)


# ─── Detail ────────────────────────────────────────────────


@router.get("/{slug}/", response_class=HTMLResponse)
async def training_detail(
    request: Request,
    slug: str,
    repo: TrainingRunRepositoryInterface = Depends(get_training_repo),
    policy_repo: PolicyRepositoryInterface = Depends(get_policy_repo),
) -> HTMLResponse:
    """Training run detail with episode data and charts."""
    try:
        run = repo.get_run_by_slug(slug)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="Training run not found") from exc

    episodes = repo.get_episodes(run.id, limit=2000)

    # Build chart data
    episode_data = [
        {
            "episode": e.episode,
            "reward": e.reward,
            "steps": e.steps,
            "epsilon": e.epsilon,
            "satisfied": e.satisfied,
            "total_aps": e.total_aps,
            "all_satisfied": e.all_satisfied,
            "duration_secs": e.duration_secs,
            "tokens": e.tokens,
            "backtracks": e.backtracks,
        }
        for e in episodes
    ]

    # Compute completion rate
    episodes_with_status = [e for e in episodes if e.all_satisfied is not None]
    completed_episodes = sum(1 for e in episodes_with_status if e.all_satisfied)
    completion_rate = (
        completed_episodes / len(episodes_with_status) if episodes_with_status else None
    )

    # Find linked policies
    policies = policy_repo.list_policies(limit=100)
    linked_policies = [p for p in policies if p.training_run_slug == slug]

    # Load filesystem-level policy/Q-table data if available
    policy_json = "null"
    from pathlib import Path

    from ..rl_loader import load_policy_info

    run_path = Path(run.path) if run.path else None
    if run_path and run_path.is_dir():
        policy_info = load_policy_info(run_path)
        if policy_info:
            policy_json = json.dumps(
                {
                    "ap_ids": policy_info.ap_ids,
                    "num_states": policy_info.num_states,
                    "num_actions": policy_info.num_actions,
                    "q_table": policy_info.q_table,
                    "visit_counts": policy_info.visit_counts,
                    "greedy_actions": policy_info.greedy_actions,
                    "total_visits": policy_info.total_visits,
                }
            )

    templates = request.app.state.templates
    return templates.TemplateResponse(
        "training_detail.html",
        {
            **_ctx(request),
            "run": run,
            "episodes": episodes,
            "episode_data_json": json.dumps(episode_data),
            "completion_rate": completion_rate,
            "completed_episodes": completed_episodes,
            "total_episodes_tracked": len(episodes_with_status),
            "linked_policies": linked_policies,
            "policy_json": policy_json,
        },
    )


# ─── Import from filesystem ───────────────────────────────


@router.post("/import", response_class=HTMLResponse)
async def training_import(
    request: Request,
    repo: TrainingRunRepositoryInterface = Depends(get_training_repo),
) -> RedirectResponse:
    """Scan filesystem and import discovered training runs."""
    output_dir = getattr(request.app.state, "output_dir", None)
    if not output_dir:
        raise HTTPException(status_code=400, detail="No output directory configured")

    from pathlib import Path

    from ..rl_loader import discover_training_runs

    fs_runs = discover_training_runs(output_dir)
    imported = 0
    for fs_run in fs_runs:
        try:
            repo.import_from_filesystem(str(fs_run.path))
            imported += 1
        except Exception:
            logger.exception("Failed to import training run from %s", fs_run.path)

    # Also scan for policies
    policy_repo = get_policy_repo()
    policy_repo.scan_checkpoints(str(Path(output_dir)))

    return RedirectResponse(url="/training/", status_code=303)


# ─── New form ──────────────────────────────────────────────


@router.get("/new", response_class=HTMLResponse)
async def training_new_form(
    request: Request,
    wf_repo: WorkflowRepositoryInterface = Depends(get_workflow_repo),
) -> HTMLResponse:
    """Show the new training run configuration form."""
    workflows = wf_repo.list_workflows()
    templates = request.app.state.templates
    return templates.TemplateResponse(
        "training_new.html",
        {
            **_ctx(request),
            "workflows": workflows,
            "available_arms": AVAILABLE_ARMS,
            "available_rewards": AVAILABLE_REWARDS,
        },
    )


# ─── Create ────────────────────────────────────────────────


@router.post("/", response_class=HTMLResponse)
async def training_create(
    model: str = Form(""),
    provider: str = Form("openrouter"),
    arm: str = Form("s1_tdd_rule_backtrack"),
    reward: str = Form("potential-based"),
    episodes: int = Form(100),
    max_steps: int = Form(0),
    gamma: float = Form(0.95),
    epsilon: float = Form(0.3),
    epsilon_decay: float = Form(0.995),
    alpha: float = Form(0.2),
    instances: int = Form(10),
    language: str = Form("python"),
    repo: TrainingRunRepositoryInterface = Depends(get_training_repo),
) -> HTMLResponse:
    """Create and start a training run as a subprocess."""
    from ..training_launcher import launch_training

    timestamp = dt.datetime.now(dt.UTC).strftime("%Y%m%d_%H%M%S")
    slug = f"train_{timestamp}"
    checkpoint_dir = f"output/rl_training/{slug}"

    from atomicguard.domain.models import TrainingRunRecord

    run = TrainingRunRecord(
        id=0,
        slug=slug,
        display_name=slug.replace("_", " ").title(),
        path=checkpoint_dir,
        model=model.strip(),
        provider=provider.strip(),
        arm=arm.strip(),
        reward=reward.strip(),
        episodes=episodes,
        gamma=gamma,
        alpha=alpha,
        epsilon_initial=epsilon,
        epsilon_final=epsilon,
        epsilon_decay=epsilon_decay,
        instances=instances,
        language=language.strip() or None,
        status="in_progress",
        created_at=_now_iso(),
        updated_at=_now_iso(),
    )
    run_id = repo.create_run(run)

    try:
        launch_training(
            run_id=run_id,
            repo=repo,
            model=model.strip(),
            provider=provider.strip(),
            arm=arm.strip(),
            reward=reward.strip(),
            episodes=episodes,
            max_steps=max_steps,
            gamma=gamma,
            epsilon=epsilon,
            epsilon_decay=epsilon_decay,
            alpha=alpha,
            instances=instances,
            language=language.strip(),
            checkpoint_dir=checkpoint_dir,
        )
    except Exception as exc:
        repo.update_run(run_id, status="terminated", updated_at=_now_iso())
        raise HTTPException(status_code=500, detail=str(exc)) from exc

    return HTMLResponse(
        content="",
        status_code=200,
        headers={"HX-Redirect": f"/training/{slug}/"},
    )


# ─── Episode detail (migrated from /rl/) ──────────────────


@router.get("/{slug}/episode/{episode}/", response_class=HTMLResponse)
async def training_episode_detail(
    request: Request,
    slug: str,
    episode: int,
    repo: TrainingRunRepositoryInterface = Depends(get_training_repo),
) -> HTMLResponse:
    """Episode detail with step-by-step DAG view."""
    try:
        run = repo.get_run_by_slug(slug)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="Training run not found") from exc

    from pathlib import Path

    from ..rl_loader import build_episode_graph, load_episode_steps

    run_path = Path(run.path)
    steps = load_episode_steps(run_path, episode) if run_path.is_dir() else []
    graph = build_episode_graph(steps)

    # Find episode info from DB
    episodes = repo.get_episodes(run.id, limit=2000)
    episode_info = next((e for e in episodes if e.episode == episode), None)

    templates = request.app.state.templates
    return templates.TemplateResponse(
        "training_episode.html",
        {
            **_ctx(request),
            "run": run,
            "episode": episode,
            "episode_info": episode_info,
            "steps": steps,
            "graph_json": json.dumps(graph),
        },
    )
