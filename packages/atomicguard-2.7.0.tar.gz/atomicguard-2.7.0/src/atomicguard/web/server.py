"""FastAPI app factory and CLI entry point."""

from __future__ import annotations

import json
from pathlib import Path

import click
import uvicorn
from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from jinja2 import Environment, FileSystemLoader

from .config_loader import ConfigLoader
from .discovery import ExperimentDiscovery
from .experiment_locator import ExperimentLocator
from .routes import register_routes

_PACKAGE_DIR = Path(__file__).parent
_REPO_ROOT = _PACKAGE_DIR.parent.parent.parent  # src/atomicguard/web/ -> repo root

_DEFAULT_DB = Path("~/.atomicguard/web.db").expanduser()


def create_app(
    artifact_dir: Path | None = None,
    workflows_dir: Path | None = None,
    ap_context_path: Path | None = None,
    output_dir: Path | None = None,
    db_path: Path | None = None,
) -> FastAPI:
    """Create and configure the FastAPI application."""
    app = FastAPI(title="AtomicGuard Web UI", docs_url=None, redoc_url=None)

    # Initialise DB if path provided
    if db_path is not None:
        from .dependencies import init_db

        init_db(db_path)

    # Build experiment registry
    experiments: dict[str, object] = {}  # slug -> ExperimentEntry
    discoveries: dict[str, ExperimentDiscovery] = {}  # slug -> discovery

    if output_dir and output_dir.is_dir():
        locator = ExperimentLocator(output_dir / "experiments")
        for entry in locator.discover():
            experiments[entry.slug] = entry
            discoveries[entry.slug] = ExperimentDiscovery(entry.artifact_dags_path)
    elif artifact_dir:
        # Legacy single-experiment fallback
        from .experiment_locator import ExperimentEntry

        entry = ExperimentEntry(
            slug="default",
            display_name="Default Experiment",
            artifact_dags_path=artifact_dir,
        )
        # Derive counts from filesystem
        locator = ExperimentLocator(Path("."))
        locator._count_from_filesystem(entry)
        experiments["default"] = entry
        discoveries["default"] = ExperimentDiscovery(artifact_dir)

    app.state.experiments = experiments
    app.state.discoveries = discoveries
    app.state.output_dir = output_dir
    app.state.docs_dir = _REPO_ROOT / "docs"
    # Auto-detect workflows directory when not explicitly provided
    if workflows_dir is None:
        default_workflows = _REPO_ROOT / "examples" / "swe_bench_common" / "workflows"
        if default_workflows.is_dir():
            workflows_dir = default_workflows

    app.state.config_loader = ConfigLoader(workflows_dir, ap_context_path)

    # Jinja2 templates
    template_dir = _PACKAGE_DIR / "templates"
    env = Environment(loader=FileSystemLoader(str(template_dir)), autoescape=True)

    # Global function so base.html can show latest Spark metrics on every page
    def _get_spark_latest() -> dict | None:
        if not output_dir:
            return None
        f = output_dir / "spark_monitor" / "metrics.jsonl"
        if not f.exists():
            return None
        # Read last line efficiently
        try:
            import json as _json

            last = ""
            for line in f.read_text().splitlines():
                if line.strip():
                    last = line.strip()
            return _json.loads(last) if last else None
        except Exception:
            return None

    env.globals["get_spark_latest"] = _get_spark_latest

    def _get_ollama_latest() -> dict | None:
        if not output_dir:
            return None
        f = output_dir / "ollama_monitor" / "requests.jsonl"
        if not f.exists():
            return None
        try:
            import json as _json

            requests = []
            for line in f.read_text().splitlines():
                line = line.strip()
                if line:
                    try:
                        requests.append(_json.loads(line))
                    except _json.JSONDecodeError:
                        continue
            if not requests:
                return None
            total = len(requests)
            errors = sum(1 for r in requests if r.get("status", 0) >= 400)
            durations = [r.get("duration_s", 0) for r in requests]
            avg = round(sum(durations) / len(durations), 1) if durations else 0
            return {"count": total, "avg_latency": avg, "error_count": errors}
        except Exception:
            return None

    env.globals["get_ollama_latest"] = _get_ollama_latest
    app.state.templates = _TemplateRenderer(env)

    # Static files
    static_dir = _PACKAGE_DIR / "static"
    app.mount("/static", StaticFiles(directory=str(static_dir)), name="static")

    # Routes
    register_routes(app)

    return app


class _TemplateRenderer:
    """Thin wrapper to match Starlette's TemplateResponse interface."""

    def __init__(self, env: Environment) -> None:
        self._env = env

    def TemplateResponse(  # noqa: N802 — matches Starlette convention
        self,
        name: str,
        context: dict,
        status_code: int = 200,
    ) -> HTMLResponse:
        template = self._env.get_template(name)
        html = template.render(**context)
        return HTMLResponse(content=html, status_code=status_code)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


@click.group(invoke_without_command=True)
@click.pass_context
@click.option(
    "--output-dir",
    type=click.Path(exists=True, path_type=Path),
    default=None,
    help="Root output directory containing experiment runs.",
)
@click.option(
    "--artifact-dir",
    type=click.Path(exists=True, path_type=Path),
    default=None,
    help="(Legacy) Single artifact_dags directory.",
)
@click.option(
    "--workflows-dir",
    type=click.Path(exists=True, path_type=Path),
    default=None,
    help="Directory with workflow *.json configs.",
)
@click.option(
    "--ap-context",
    type=click.Path(exists=True, path_type=Path),
    default=None,
    help="Path to ap_context.json.",
)
@click.option(
    "--db",
    type=click.Path(path_type=Path),
    default=None,
    help=f"SQLite database path (default: {_DEFAULT_DB}).",
)
@click.option("--host", default="0.0.0.0", help="Bind address.")
@click.option("--port", default=8000, type=int, help="Port number.")
def main(
    ctx: click.Context,
    output_dir: Path | None,
    artifact_dir: Path | None,
    workflows_dir: Path | None,
    ap_context: Path | None,
    db: Path | None,
    host: str,
    port: int,
) -> None:
    """AtomicGuard Web UI — workflow management and experiment browser."""
    # Store common options for subcommands
    ctx.ensure_object(dict)
    ctx.obj["output_dir"] = output_dir
    ctx.obj["artifact_dir"] = artifact_dir
    ctx.obj["workflows_dir"] = workflows_dir
    ctx.obj["ap_context"] = ap_context
    ctx.obj["db"] = db
    ctx.obj["host"] = host
    ctx.obj["port"] = port

    # Default action: start the server
    if ctx.invoked_subcommand is None:
        _serve(output_dir, artifact_dir, workflows_dir, ap_context, db, host, port)


@main.command()
@click.pass_context
def serve(ctx: click.Context) -> None:
    """Start the web UI server."""
    obj = ctx.obj
    _serve(
        obj["output_dir"],
        obj["artifact_dir"],
        obj["workflows_dir"],
        obj["ap_context"],
        obj["db"],
        obj["host"],
        obj["port"],
    )


def _serve(
    output_dir: Path | None,
    artifact_dir: Path | None,
    workflows_dir: Path | None,
    ap_context: Path | None,
    db: Path | None,
    host: str,
    port: int,
) -> None:
    """Core serve logic shared between default invocation and serve subcommand."""
    # Auto-detect ./output if neither flag given
    if output_dir is None and artifact_dir is None:
        default_output = Path("./output")
        if default_output.is_dir():
            output_dir = default_output

    if output_dir is None and artifact_dir is None:
        raise click.UsageError("Provide --output-dir or --artifact-dir.")

    # Default DB path
    db_path = db or _DEFAULT_DB

    app = create_app(artifact_dir, workflows_dir, ap_context, output_dir, db_path)
    uvicorn.run(app, host=host, port=port)


@main.command("import-all")
@click.option(
    "--workflows-dir",
    type=click.Path(exists=True, path_type=Path),
    required=True,
    help="Directory with workflow *.json configs.",
)
@click.option(
    "--ap-context",
    type=click.Path(exists=True, path_type=Path),
    required=True,
    help="Path to ap_context.json.",
)
@click.option(
    "--db",
    type=click.Path(path_type=Path),
    default=None,
    help=f"SQLite database path (default: {_DEFAULT_DB}).",
)
def import_all(
    workflows_dir: Path,
    ap_context: Path,
    db: Path | None,
) -> None:
    """Import all workflow JSON files and AP context into the database."""
    from .dependencies import init_db

    db_path = db or _DEFAULT_DB
    conn = init_db(db_path)

    from atomicguard.infrastructure.persistence.sqlite import (
        SQLiteAPContextRepository,
        SQLiteWorkflowRepository,
    )

    wf_repo = SQLiteWorkflowRepository(conn)
    ctx_repo = SQLiteAPContextRepository(conn)

    # Import workflows
    wf_count = 0
    for wf_file in sorted(workflows_dir.glob("*.json")):
        data = json.loads(wf_file.read_text())
        slug = wf_repo.import_from_json(data)
        click.echo(f"  Imported workflow: {slug} ({wf_file.name})")
        wf_count += 1

    # Import AP context
    ctx_data = json.loads(ap_context.read_text())
    ctx_count = ctx_repo.import_from_json(ctx_data)

    click.echo(
        f"\nImported {wf_count} workflows and {ctx_count} AP contexts into {db_path}"
    )


@main.command("export-workflow")
@click.argument("slug")
@click.option(
    "--output",
    type=click.Path(path_type=Path),
    default=None,
    help="Output directory (default: stdout).",
)
@click.option(
    "--db",
    type=click.Path(path_type=Path),
    default=None,
    help=f"SQLite database path (default: {_DEFAULT_DB}).",
)
def export_workflow(slug: str, output: Path | None, db: Path | None) -> None:
    """Export a workflow from the database as JSON."""
    from .dependencies import init_db

    db_path = db or _DEFAULT_DB
    conn = init_db(db_path)

    from atomicguard.infrastructure.persistence.sqlite import SQLiteWorkflowRepository

    wf_repo = SQLiteWorkflowRepository(conn)
    data = wf_repo.export_to_json(slug)

    json_str = json.dumps(data, indent=2) + "\n"
    if output:
        output.mkdir(parents=True, exist_ok=True)
        out_path = output / f"{slug}.json"
        out_path.write_text(json_str)
        click.echo(f"Exported to {out_path}")
    else:
        click.echo(json_str)


@main.command("export-context")
@click.option(
    "--output",
    type=click.Path(path_type=Path),
    default=None,
    help="Output file path (default: stdout).",
)
@click.option(
    "--db",
    type=click.Path(path_type=Path),
    default=None,
    help=f"SQLite database path (default: {_DEFAULT_DB}).",
)
def export_context(output: Path | None, db: Path | None) -> None:
    """Export all AP context from the database as JSON."""
    from .dependencies import init_db

    db_path = db or _DEFAULT_DB
    conn = init_db(db_path)

    from atomicguard.infrastructure.persistence.sqlite import (
        SQLiteAPContextRepository,
    )

    ctx_repo = SQLiteAPContextRepository(conn)
    data = ctx_repo.export_to_json()

    json_str = json.dumps(data, indent=2) + "\n"
    if output:
        output.write_text(json_str)
        click.echo(f"Exported to {output}")
    else:
        click.echo(json_str)
