"""
In-memory implementations of persistence interfaces.

Useful for testing and ephemeral workflows.
"""

from __future__ import annotations

from atomicguard.domain.interfaces import (
    APContextRepositoryInterface,
    ArtifactDAGInterface,
    WorkflowRepositoryInterface,
)
from atomicguard.domain.models import (
    APContextEntry,
    Artifact,
    WorkflowDefinition,
    WorkflowSummary,
)


class InMemoryArtifactDAG(ArtifactDAGInterface):
    """Simple in-memory DAG for testing."""

    def __init__(self) -> None:
        self._artifacts: dict[str, Artifact] = {}

    def store(self, artifact: Artifact) -> str:
        self._artifacts[artifact.artifact_id] = artifact
        return artifact.artifact_id

    def get_artifact(self, artifact_id: str) -> Artifact:
        if artifact_id not in self._artifacts:
            raise KeyError(f"Artifact not found: {artifact_id}")
        return self._artifacts[artifact_id]

    def get_provenance(self, artifact_id: str) -> list[Artifact]:
        result = []
        current = self._artifacts.get(artifact_id)
        while current:
            result.append(current)
            if (
                not hasattr(current, "previous_attempt_id")
                or current.previous_attempt_id is None
            ):
                break
            current = self._artifacts.get(current.previous_attempt_id)
        return list(reversed(result))

    def get_latest_for_action_pair(
        self, action_pair_id: str, workflow_id: str
    ) -> Artifact | None:
        """
        Get the most recent artifact for an action pair in a workflow.

        Args:
            action_pair_id: The action pair identifier (e.g., 'g_test')
            workflow_id: UUID of the workflow execution instance

        Returns:
            The most recent artifact, or None if not found
        """
        candidates = [
            a
            for a in self._artifacts.values()
            if a.action_pair_id == action_pair_id and a.workflow_id == workflow_id
        ]
        if not candidates:
            return None
        # Sort by created_at descending and return the latest
        candidates.sort(key=lambda a: a.created_at, reverse=True)
        return candidates[0]

    def get_all_for_action_pair(
        self, action_pair_id: str, workflow_id: str
    ) -> list[Artifact]:
        """Get all artifacts for an action pair in a specific workflow.

        Args:
            action_pair_id: The action pair identifier (e.g., 'g_test')
            workflow_id: UUID of the workflow execution instance

        Returns:
            List of artifacts sorted by created_at ascending.
        """
        candidates = [
            a
            for a in self._artifacts.values()
            if a.action_pair_id == action_pair_id and a.workflow_id == workflow_id
        ]
        candidates.sort(key=lambda a: a.created_at)
        return candidates

    def get_all(self) -> list[Artifact]:
        """Return all artifacts in the DAG.

        Returns:
            List of all artifacts, sorted by created_at.
        """
        artifacts = list(self._artifacts.values())
        artifacts.sort(key=lambda a: a.created_at)
        return artifacts


class InMemoryWorkflowRepository(WorkflowRepositoryInterface):
    """Simple in-memory workflow repository for testing."""

    def __init__(self) -> None:
        self._workflows: dict[str, WorkflowDefinition] = {}

    def list_workflows(self) -> list[WorkflowSummary]:
        return [
            WorkflowSummary(
                slug=wf.slug,
                name=wf.name,
                description=wf.description,
                action_pair_count=len(wf.action_pairs),
                model=wf.model,
                provider=wf.provider,
            )
            for wf in sorted(self._workflows.values(), key=lambda w: w.slug)
        ]

    def get_workflow(self, slug: str) -> WorkflowDefinition:
        if slug not in self._workflows:
            raise KeyError(f"Workflow not found: {slug}")
        return self._workflows[slug]

    def save_workflow(self, workflow: WorkflowDefinition) -> str:
        self._workflows[workflow.slug] = workflow
        return workflow.slug

    def delete_workflow(self, slug: str) -> None:
        if slug not in self._workflows:
            raise KeyError(f"Workflow not found: {slug}")
        del self._workflows[slug]

    def import_from_json(self, data: dict) -> str:
        from atomicguard.infrastructure.persistence.sqlite import (
            _ap_dict_to_definition,
            _slugify,
        )

        name = data["name"]
        slug = _slugify(name)
        aps = [
            _ap_dict_to_definition(ap_id, ap_data)
            for ap_id, ap_data in data.get("action_pairs", {}).items()
        ]
        workflow = WorkflowDefinition(
            slug=slug,
            name=name,
            description=data.get("description", ""),
            specification=data.get("specification"),
            constraints=data.get("constraints", ""),
            model=data.get("model", ""),
            provider=data.get("provider", ""),
            rmax=data.get("rmax", 3),
            action_pairs=tuple(aps),
        )
        return self.save_workflow(workflow)

    def export_to_json(self, slug: str) -> dict:
        from typing import Any

        from atomicguard.infrastructure.persistence.sqlite import (
            _ap_definition_to_dict,
        )

        wf = self.get_workflow(slug)
        result: dict[str, Any] = {"name": wf.name}
        if wf.description:
            result["description"] = wf.description
        if wf.specification is not None:
            result["specification"] = wf.specification
        if wf.constraints:
            result["constraints"] = wf.constraints
        if wf.model:
            result["model"] = wf.model
        if wf.provider:
            result["provider"] = wf.provider
        if wf.rmax != 3:
            result["rmax"] = wf.rmax
        aps: dict[str, Any] = {}
        for ap in wf.action_pairs:
            aps[ap.ap_id] = _ap_definition_to_dict(ap)
        result["action_pairs"] = aps
        return result


class InMemoryAPContextRepository(APContextRepositoryInterface):
    """Simple in-memory AP context repository for testing."""

    def __init__(self) -> None:
        self._contexts: dict[str, APContextEntry] = {}

    def get_context(self, ap_id: str) -> APContextEntry:
        if ap_id not in self._contexts:
            raise KeyError(f"AP context not found: {ap_id}")
        return self._contexts[ap_id]

    def save_context(self, context: APContextEntry) -> None:
        self._contexts[context.ap_id] = context

    def list_contexts(self) -> dict[str, APContextEntry]:
        return dict(sorted(self._contexts.items()))

    def import_from_json(self, data: dict) -> int:
        count = 0
        for ap_id, entry_data in data.items():
            self.save_context(
                APContextEntry(
                    ap_id=ap_id,
                    role=entry_data.get("role", ""),
                    constraints=entry_data.get("constraints", ""),
                    task=entry_data.get("task", ""),
                    feedback_wrapper=entry_data.get("feedback_wrapper", ""),
                    escalation_feedback_wrapper=entry_data.get(
                        "escalation_feedback_wrapper", ""
                    ),
                    feedback_mode=entry_data.get("feedback_mode", "inline"),
                    artifact_context=entry_data.get("artifact_context", ""),
                )
            )
            count += 1
        return count

    def export_to_json(self) -> dict:
        from typing import Any

        result: dict[str, Any] = {}
        for ap_id, entry in sorted(self._contexts.items()):
            d: dict[str, Any] = {}
            if entry.role:
                d["role"] = entry.role
            if entry.constraints:
                d["constraints"] = entry.constraints
            if entry.task:
                d["task"] = entry.task
            if entry.feedback_wrapper:
                d["feedback_wrapper"] = entry.feedback_wrapper
            if entry.escalation_feedback_wrapper:
                d["escalation_feedback_wrapper"] = entry.escalation_feedback_wrapper
            if entry.feedback_mode and entry.feedback_mode != "inline":
                d["feedback_mode"] = entry.feedback_mode
            if entry.artifact_context:
                d["artifact_context"] = entry.artifact_context
            result[ap_id] = d
        return result
