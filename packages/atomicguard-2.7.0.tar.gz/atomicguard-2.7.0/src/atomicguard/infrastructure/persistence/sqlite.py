"""SQLite persistence adapter — implements workflow and AP context repository interfaces."""

from __future__ import annotations

import contextlib
import json
import logging
import sqlite3
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path
from typing import Any

from atomicguard.domain.interfaces import (
    APContextRepositoryInterface,
    PolicyRepositoryInterface,
    RunRepositoryInterface,
    TrainingRunRepositoryInterface,
    WorkflowRepositoryInterface,
)
from atomicguard.domain.models import (
    ActionPairDefinition,
    APContextEntry,
    GuardResultRecord,
    PolicyRecord,
    ProductionRun,
    TrainingEpisodeRecord,
    TrainingRunRecord,
    WorkflowDefinition,
    WorkflowSummary,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Schema
# ---------------------------------------------------------------------------

SCHEMA_SQL = """\
CREATE TABLE IF NOT EXISTS workflows (
    slug        TEXT PRIMARY KEY,
    name        TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    specification TEXT,          -- JSON (string or SpecificationSource object)
    constraints TEXT NOT NULL DEFAULT '',
    model       TEXT NOT NULL DEFAULT '',
    provider    TEXT NOT NULL DEFAULT '',
    rmax        INTEGER NOT NULL DEFAULT 3,
    extra       TEXT NOT NULL DEFAULT '{}',  -- JSON: extra top-level keys not in schema (e.g. backtrack_config)
    source_keys TEXT NOT NULL DEFAULT '[]'   -- JSON array: keys present in source JSON (for faithful export)
);

CREATE TABLE IF NOT EXISTS workflow_action_pairs (
    id                         INTEGER PRIMARY KEY AUTOINCREMENT,
    workflow_slug              TEXT NOT NULL REFERENCES workflows(slug) ON DELETE CASCADE,
    ap_id                      TEXT NOT NULL,
    generator                  TEXT NOT NULL DEFAULT '',
    generator_config           TEXT NOT NULL DEFAULT '{}',   -- JSON
    guard                      TEXT NOT NULL DEFAULT '',
    guards                     TEXT,                          -- JSON (list or CompositeGuardSpec)
    guard_config               TEXT NOT NULL DEFAULT '{}',   -- JSON
    requires                   TEXT NOT NULL DEFAULT '[]',   -- JSON array of strings
    artifact_type              TEXT NOT NULL DEFAULT '',
    output_type                TEXT NOT NULL DEFAULT '',
    r_patience                 INTEGER,
    e_max                      INTEGER NOT NULL DEFAULT 1,
    escalate_feedback_to       TEXT NOT NULL DEFAULT '[]',   -- JSON array of strings
    escalate_feedback_by_guard TEXT NOT NULL DEFAULT '{}',   -- JSON {guard: [ap_ids]}
    human_prompt_title         TEXT NOT NULL DEFAULT '',
    description                TEXT NOT NULL DEFAULT '',
    "group"                    TEXT NOT NULL DEFAULT '',
    goal                       INTEGER NOT NULL DEFAULT 0,   -- boolean: 1 = goal AP
    sort_order                 INTEGER NOT NULL DEFAULT 0,
    source_keys                TEXT NOT NULL DEFAULT '[]',  -- JSON array: keys present in source AP JSON
    UNIQUE(workflow_slug, ap_id)
);

CREATE TABLE IF NOT EXISTS ap_context (
    ap_id                       TEXT PRIMARY KEY,
    role                        TEXT NOT NULL DEFAULT '',
    constraints                 TEXT NOT NULL DEFAULT '',
    task                        TEXT NOT NULL DEFAULT '',
    feedback_wrapper            TEXT NOT NULL DEFAULT '',
    escalation_feedback_wrapper TEXT NOT NULL DEFAULT '',
    feedback_mode               TEXT NOT NULL DEFAULT 'inline',
    artifact_context            TEXT NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS import_metadata (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    source_type  TEXT NOT NULL,   -- 'workflow' or 'ap_context'
    source_path  TEXT,
    imported_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS production_runs (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    workflow_slug       TEXT NOT NULL,
    model               TEXT NOT NULL DEFAULT '',
    provider            TEXT NOT NULL DEFAULT '',
    arms                TEXT NOT NULL DEFAULT '[]',   -- JSON array of strings
    language            TEXT,
    max_instances       INTEGER,
    max_workers         INTEGER NOT NULL DEFAULT 1,
    output_dir          TEXT NOT NULL DEFAULT '',
    policy_path         TEXT NOT NULL DEFAULT '',
    status              TEXT NOT NULL DEFAULT 'pending',  -- pending|running|completed|failed|cancelled
    pid                 INTEGER,
    created_at          TEXT NOT NULL DEFAULT (datetime('now')),
    started_at          TEXT,
    finished_at         TEXT,
    error               TEXT,
    total_instances     INTEGER NOT NULL DEFAULT 0,
    completed_instances INTEGER NOT NULL DEFAULT 0,
    failed_instances    INTEGER NOT NULL DEFAULT 0,
    resolved_instances  INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS guard_results (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id            INTEGER NOT NULL REFERENCES production_runs(id) ON DELETE CASCADE,
    instance_id       TEXT NOT NULL,
    arm               TEXT NOT NULL,
    step_id           TEXT NOT NULL,
    guard_name        TEXT NOT NULL,
    passed            INTEGER NOT NULL DEFAULT 0,
    feedback          TEXT NOT NULL DEFAULT '',
    attempt           INTEGER NOT NULL DEFAULT 1,
    wall_time_seconds REAL NOT NULL DEFAULT 0.0,
    tokens_used       INTEGER NOT NULL DEFAULT 0,
    recorded_at       TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_guard_results_run ON guard_results(run_id);
CREATE INDEX IF NOT EXISTS idx_guard_results_instance ON guard_results(run_id, instance_id);
CREATE INDEX IF NOT EXISTS idx_production_runs_status ON production_runs(status);

CREATE TABLE IF NOT EXISTS training_runs (
    id                   INTEGER PRIMARY KEY AUTOINCREMENT,
    slug                 TEXT NOT NULL UNIQUE,
    display_name         TEXT NOT NULL DEFAULT '',
    path                 TEXT NOT NULL DEFAULT '',
    model                TEXT NOT NULL DEFAULT '',
    provider             TEXT NOT NULL DEFAULT '',
    arm                  TEXT NOT NULL DEFAULT '',
    reward               TEXT NOT NULL DEFAULT '',
    episodes             INTEGER NOT NULL DEFAULT 0,
    gamma                REAL NOT NULL DEFAULT 0.0,
    alpha                REAL NOT NULL DEFAULT 0.0,
    epsilon_initial      REAL NOT NULL DEFAULT 0.0,
    epsilon_final        REAL NOT NULL DEFAULT 0.0,
    epsilon_decay        REAL NOT NULL DEFAULT 0.0,
    instances            INTEGER NOT NULL DEFAULT 0,
    language             TEXT,
    training_mean_reward REAL NOT NULL DEFAULT 0.0,
    eval_mean_reward     REAL NOT NULL DEFAULT 0.0,
    eval_success_rate    REAL NOT NULL DEFAULT 0.0,
    ap_ids               TEXT NOT NULL DEFAULT '[]',
    status               TEXT NOT NULL DEFAULT 'complete',
    completed_episodes   INTEGER NOT NULL DEFAULT 0,
    created_at           TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at           TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS training_episodes (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    training_run_id  INTEGER NOT NULL REFERENCES training_runs(id) ON DELETE CASCADE,
    episode          INTEGER NOT NULL,
    reward           REAL NOT NULL DEFAULT 0.0,
    steps            INTEGER NOT NULL DEFAULT 0,
    epsilon          REAL NOT NULL DEFAULT 0.0,
    satisfied        INTEGER,
    total_aps        INTEGER,
    all_satisfied    INTEGER,
    duration_secs    REAL,
    tokens           INTEGER,
    backtracks       INTEGER,
    instance_id      TEXT
);

CREATE INDEX IF NOT EXISTS idx_training_episodes_run ON training_episodes(training_run_id);

CREATE TABLE IF NOT EXISTS policies (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    slug              TEXT NOT NULL UNIQUE,
    display_name      TEXT NOT NULL DEFAULT '',
    path              TEXT NOT NULL DEFAULT '',
    training_run_id   INTEGER REFERENCES training_runs(id) ON DELETE SET NULL,
    training_run_slug TEXT NOT NULL DEFAULT '',
    model             TEXT NOT NULL DEFAULT '',
    provider          TEXT NOT NULL DEFAULT '',
    arm               TEXT NOT NULL DEFAULT '',
    reward            TEXT NOT NULL DEFAULT '',
    episodes          INTEGER NOT NULL DEFAULT 0,
    mean_reward       REAL NOT NULL DEFAULT 0.0,
    eval_success_rate REAL NOT NULL DEFAULT 0.0,
    ap_ids            TEXT NOT NULL DEFAULT '[]',
    num_states        INTEGER NOT NULL DEFAULT 0,
    num_actions       INTEGER NOT NULL DEFAULT 0,
    total_visits      INTEGER NOT NULL DEFAULT 0,
    created_at        TEXT NOT NULL DEFAULT (datetime('now'))
);
"""


# ---------------------------------------------------------------------------
# Connection manager
# ---------------------------------------------------------------------------


class SQLiteConnection:
    """Manage SQLite connection with WAL mode and foreign keys."""

    def __init__(self, db_path: Path) -> None:
        self.db_path = db_path

    @contextmanager
    def get(self) -> Iterator[sqlite3.Connection]:
        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA foreign_keys=ON")
        try:
            yield conn
            conn.commit()
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def init_schema(self) -> None:
        """Create tables if they don't exist."""
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        with self.get() as conn:
            conn.executescript(SCHEMA_SQL)


# ---------------------------------------------------------------------------
# Workflow repository
# ---------------------------------------------------------------------------


class SQLiteWorkflowRepository(WorkflowRepositoryInterface):
    """SQLite adapter for workflow persistence."""

    def __init__(self, conn: SQLiteConnection) -> None:
        self._conn = conn

    def list_workflows(self) -> list[WorkflowSummary]:
        with self._conn.get() as db:
            rows = db.execute(
                "SELECT slug, name, description, model, provider FROM workflows ORDER BY slug"
            ).fetchall()
            summaries = []
            for row in rows:
                count = db.execute(
                    "SELECT COUNT(*) FROM workflow_action_pairs WHERE workflow_slug = ?",
                    (row["slug"],),
                ).fetchone()[0]
                summaries.append(
                    WorkflowSummary(
                        slug=row["slug"],
                        name=row["name"],
                        description=row["description"],
                        action_pair_count=count,
                        model=row["model"],
                        provider=row["provider"],
                    )
                )
            return summaries

    def get_workflow(self, slug: str) -> WorkflowDefinition:
        with self._conn.get() as db:
            row = db.execute(
                "SELECT * FROM workflows WHERE slug = ?", (slug,)
            ).fetchone()
            if row is None:
                raise KeyError(f"Workflow not found: {slug}")
            ap_rows = db.execute(
                "SELECT * FROM workflow_action_pairs WHERE workflow_slug = ? ORDER BY sort_order",
                (slug,),
            ).fetchall()
            return self._row_to_definition(row, ap_rows)

    def save_workflow(self, workflow: WorkflowDefinition) -> str:
        return self._save_workflow_with_keys(workflow, None, None)

    def _save_workflow_with_keys(
        self,
        workflow: WorkflowDefinition,
        wf_source_keys: list[str] | None,
        ap_source_keys_map: dict[str, list[str]] | None,
        extra: dict[str, Any] | None = None,
    ) -> str:
        with self._conn.get() as db:
            spec_json = (
                json.dumps(workflow.specification)
                if workflow.specification is not None
                else None
            )
            source_keys_json = json.dumps(wf_source_keys) if wf_source_keys else "[]"
            extra_json = json.dumps(extra) if extra else "{}"
            db.execute(
                """\
                INSERT OR REPLACE INTO workflows
                    (slug, name, description, specification, constraints, model, provider,
                     rmax, extra, source_keys)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    workflow.slug,
                    workflow.name,
                    workflow.description,
                    spec_json,
                    workflow.constraints,
                    workflow.model,
                    workflow.provider,
                    workflow.rmax,
                    extra_json,
                    source_keys_json,
                ),
            )
            # Replace action pairs
            db.execute(
                "DELETE FROM workflow_action_pairs WHERE workflow_slug = ?",
                (workflow.slug,),
            )
            for idx, ap in enumerate(workflow.action_pairs):
                ap_keys = (ap_source_keys_map or {}).get(ap.ap_id)
                self._insert_ap(db, workflow.slug, ap, idx, ap_keys)
        return workflow.slug

    def delete_workflow(self, slug: str) -> None:
        with self._conn.get() as db:
            cursor = db.execute("DELETE FROM workflows WHERE slug = ?", (slug,))
            if cursor.rowcount == 0:
                raise KeyError(f"Workflow not found: {slug}")

    def import_from_json(self, data: dict) -> str:
        """Import a workflow JSON dict. Returns slug."""
        name = data["name"]
        slug = _slugify(name)
        # Track source keys in original order for faithful round-trip export
        wf_source_keys = list(data.keys())
        # Collect extra top-level keys not in our schema
        _known_wf_keys = {
            "name",
            "description",
            "specification",
            "constraints",
            "model",
            "provider",
            "rmax",
            "action_pairs",
        }
        extra = {k: v for k, v in data.items() if k not in _known_wf_keys}
        aps = []
        ap_source_keys_map: dict[str, list[str]] = {}
        for ap_id, ap_data in data.get("action_pairs", {}).items():
            aps.append(_ap_dict_to_definition(ap_id, ap_data))
            ap_source_keys_map[ap_id] = list(ap_data.keys())
        workflow = WorkflowDefinition(
            slug=slug,
            name=name,
            description=data.get("description", ""),
            specification=data.get("specification"),
            constraints=data.get("constraints", ""),
            model=data.get("model", ""),
            provider=data.get("provider", ""),
            rmax=data.get("rmax", 3),
            action_pairs=tuple(aps),
        )
        return self._save_workflow_with_keys(
            workflow, wf_source_keys, ap_source_keys_map, extra
        )

    def export_to_json(self, slug: str) -> dict:
        """Export as CLI-compatible JSON matching workflow.schema.json."""
        with self._conn.get() as db:
            row = db.execute(
                "SELECT * FROM workflows WHERE slug = ?", (slug,)
            ).fetchone()
            if row is None:
                raise KeyError(f"Workflow not found: {slug}")
            wf_source_keys = json.loads(row["source_keys"])  # list in original order
            wf_extra = json.loads(row["extra"])
            ap_rows = db.execute(
                "SELECT * FROM workflow_action_pairs WHERE workflow_slug = ? ORDER BY sort_order",
                (slug,),
            ).fetchall()
            wf = self._row_to_definition(row, ap_rows)

        # Build an unordered pool of all exportable keys
        pool: dict[str, Any] = {"name": wf.name}
        if wf.description or "description" in wf_source_keys:
            pool["description"] = wf.description
        if wf.specification is not None or "specification" in wf_source_keys:
            pool["specification"] = wf.specification
        if wf.constraints or "constraints" in wf_source_keys:
            pool["constraints"] = wf.constraints
        if wf.model or "model" in wf_source_keys:
            pool["model"] = wf.model
        if wf.provider or "provider" in wf_source_keys:
            pool["provider"] = wf.provider
        if wf.rmax != 3 or "rmax" in wf_source_keys:
            pool["rmax"] = wf.rmax
        # Extra fields (backtrack_config, etc.)
        pool.update(wf_extra)
        aps: dict[str, Any] = {}
        for ap_row in ap_rows:
            ap_id = ap_row["ap_id"]
            ap_keys = json.loads(ap_row["source_keys"])  # list preserving order
            ap_def = next(a for a in wf.action_pairs if a.ap_id == ap_id)
            aps[ap_id] = _ap_definition_to_dict(ap_def, ap_keys)
        pool["action_pairs"] = aps
        # Emit keys in source order (preserves original JSON key ordering)
        if wf_source_keys:
            result: dict[str, Any] = {}
            for k in wf_source_keys:
                if k in pool:
                    result[k] = pool[k]
            # Include any keys not in source_keys (shouldn't happen, but safe)
            for k, v in pool.items():
                if k not in result:
                    result[k] = v
            return result
        return pool

    # -- internal helpers --

    def _row_to_definition(
        self, row: sqlite3.Row, ap_rows: list[sqlite3.Row]
    ) -> WorkflowDefinition:
        spec = json.loads(row["specification"]) if row["specification"] else None
        aps = []
        for ap_row in ap_rows:
            aps.append(
                ActionPairDefinition(
                    ap_id=ap_row["ap_id"],
                    generator=ap_row["generator"],
                    generator_config=json.loads(ap_row["generator_config"]),
                    guard=ap_row["guard"],
                    guards=json.loads(ap_row["guards"]) if ap_row["guards"] else None,
                    guard_config=json.loads(ap_row["guard_config"]),
                    requires=tuple(json.loads(ap_row["requires"])),
                    artifact_type=ap_row["artifact_type"],
                    output_type=ap_row["output_type"],
                    r_patience=ap_row["r_patience"],
                    e_max=ap_row["e_max"],
                    escalate_feedback_to=tuple(
                        json.loads(ap_row["escalate_feedback_to"])
                    ),
                    escalate_feedback_by_guard={
                        k: tuple(v)
                        for k, v in json.loads(
                            ap_row["escalate_feedback_by_guard"]
                        ).items()
                    },
                    human_prompt_title=ap_row["human_prompt_title"],
                    group=ap_row["group"],
                    goal=bool(ap_row["goal"]),
                    description=ap_row["description"],
                )
            )
        return WorkflowDefinition(
            slug=row["slug"],
            name=row["name"],
            description=row["description"],
            specification=spec,
            constraints=row["constraints"],
            model=row["model"],
            provider=row["provider"],
            rmax=row["rmax"],
            action_pairs=tuple(aps),
        )

    def _insert_ap(
        self,
        db: sqlite3.Connection,
        slug: str,
        ap: ActionPairDefinition,
        idx: int,
        source_keys: list[str] | None = None,
    ) -> None:
        db.execute(
            """\
            INSERT INTO workflow_action_pairs
                (workflow_slug, ap_id, generator, generator_config, guard, guards,
                 guard_config, requires, artifact_type, output_type, r_patience,
                 e_max, escalate_feedback_to, escalate_feedback_by_guard,
                 human_prompt_title, description, "group", goal, sort_order, source_keys)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                slug,
                ap.ap_id,
                ap.generator,
                json.dumps(ap.generator_config),
                ap.guard,
                json.dumps(ap.guards) if ap.guards is not None else None,
                json.dumps(ap.guard_config),
                json.dumps(list(ap.requires)),
                ap.artifact_type,
                ap.output_type,
                ap.r_patience,
                ap.e_max,
                json.dumps(list(ap.escalate_feedback_to)),
                json.dumps(
                    {k: list(v) for k, v in ap.escalate_feedback_by_guard.items()}
                ),
                ap.human_prompt_title,
                ap.description,
                ap.group or "",
                1 if ap.goal else 0,
                idx,
                json.dumps(source_keys) if source_keys else "[]",
            ),
        )


# ---------------------------------------------------------------------------
# AP Context repository
# ---------------------------------------------------------------------------


class SQLiteAPContextRepository(APContextRepositoryInterface):
    """SQLite adapter for AP context persistence."""

    def __init__(self, conn: SQLiteConnection) -> None:
        self._conn = conn

    def get_context(self, ap_id: str) -> APContextEntry:
        with self._conn.get() as db:
            row = db.execute(
                "SELECT * FROM ap_context WHERE ap_id = ?", (ap_id,)
            ).fetchone()
            if row is None:
                raise KeyError(f"AP context not found: {ap_id}")
            return self._row_to_entry(row)

    def save_context(self, context: APContextEntry) -> None:
        with self._conn.get() as db:
            db.execute(
                """\
                INSERT OR REPLACE INTO ap_context
                    (ap_id, role, constraints, task, feedback_wrapper,
                     escalation_feedback_wrapper, feedback_mode, artifact_context)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    context.ap_id,
                    context.role,
                    context.constraints,
                    context.task,
                    context.feedback_wrapper,
                    context.escalation_feedback_wrapper,
                    context.feedback_mode,
                    context.artifact_context,
                ),
            )

    def list_contexts(self) -> dict[str, APContextEntry]:
        with self._conn.get() as db:
            rows = db.execute("SELECT * FROM ap_context ORDER BY ap_id").fetchall()
            return {row["ap_id"]: self._row_to_entry(row) for row in rows}

    def import_from_json(self, data: dict) -> int:
        """Import AP contexts from a JSON dict. Returns count imported."""
        count = 0
        for ap_id, entry_data in data.items():
            entry = APContextEntry(
                ap_id=ap_id,
                role=entry_data.get("role", ""),
                constraints=entry_data.get("constraints", ""),
                task=entry_data.get("task", ""),
                feedback_wrapper=entry_data.get("feedback_wrapper", ""),
                escalation_feedback_wrapper=entry_data.get(
                    "escalation_feedback_wrapper", ""
                ),
                feedback_mode=entry_data.get("feedback_mode", "inline"),
                artifact_context=entry_data.get("artifact_context", ""),
            )
            self.save_context(entry)
            count += 1
        return count

    def export_to_json(self) -> dict:
        """Export all AP contexts as a JSON dict matching ap_context.schema.json."""
        contexts = self.list_contexts()
        result: dict[str, Any] = {}
        for ap_id, entry in contexts.items():
            d: dict[str, Any] = {}
            # Only include non-empty fields to match original JSON style
            if entry.role:
                d["role"] = entry.role
            if entry.constraints:
                d["constraints"] = entry.constraints
            if entry.task:
                d["task"] = entry.task
            if entry.feedback_wrapper:
                d["feedback_wrapper"] = entry.feedback_wrapper
            if entry.escalation_feedback_wrapper:
                d["escalation_feedback_wrapper"] = entry.escalation_feedback_wrapper
            if entry.feedback_mode and entry.feedback_mode != "inline":
                d["feedback_mode"] = entry.feedback_mode
            if entry.artifact_context:
                d["artifact_context"] = entry.artifact_context
            result[ap_id] = d
        return result

    # -- internal helpers --

    @staticmethod
    def _row_to_entry(row: sqlite3.Row) -> APContextEntry:
        return APContextEntry(
            ap_id=row["ap_id"],
            role=row["role"],
            constraints=row["constraints"],
            task=row["task"],
            feedback_wrapper=row["feedback_wrapper"],
            escalation_feedback_wrapper=row["escalation_feedback_wrapper"],
            feedback_mode=row["feedback_mode"],
            artifact_context=row["artifact_context"],
        )


# ---------------------------------------------------------------------------
# Production run repository
# ---------------------------------------------------------------------------


class SQLiteRunRepository(RunRepositoryInterface):
    """SQLite adapter for production run persistence."""

    def __init__(self, conn: SQLiteConnection) -> None:
        self._conn = conn

    def create_run(self, run: ProductionRun) -> int:
        import datetime as _dt

        created = run.created_at or _dt.datetime.now(_dt.UTC).isoformat()

        with self._conn.get() as db:
            cur = db.execute(
                """\
                INSERT INTO production_runs
                    (workflow_slug, model, provider, arms, language,
                     max_instances, max_workers, output_dir, policy_path,
                     status, pid,
                     created_at, started_at, finished_at, error,
                     total_instances, completed_instances,
                     failed_instances, resolved_instances)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    run.workflow_slug,
                    run.model,
                    run.provider,
                    json.dumps(list(run.arms)),
                    run.language,
                    run.max_instances,
                    run.max_workers,
                    run.output_dir,
                    run.policy_path,
                    run.status,
                    run.pid,
                    created,
                    run.started_at,
                    run.finished_at,
                    run.error,
                    run.total_instances,
                    run.completed_instances,
                    run.failed_instances,
                    run.resolved_instances,
                ),
            )
            return cur.lastrowid  # type: ignore[return-value]

    def get_run(self, run_id: int) -> ProductionRun:
        with self._conn.get() as db:
            row = db.execute(
                "SELECT * FROM production_runs WHERE id = ?", (run_id,)
            ).fetchone()
            if row is None:
                raise KeyError(f"Run not found: {run_id}")
            return self._row_to_run(row)

    def list_runs(
        self,
        status: str | None = None,
        limit: int = 50,
        offset: int = 0,
    ) -> list[ProductionRun]:
        with self._conn.get() as db:
            if status:
                rows = db.execute(
                    "SELECT * FROM production_runs WHERE status = ? "
                    "ORDER BY id DESC LIMIT ? OFFSET ?",
                    (status, limit, offset),
                ).fetchall()
            else:
                rows = db.execute(
                    "SELECT * FROM production_runs ORDER BY id DESC LIMIT ? OFFSET ?",
                    (limit, offset),
                ).fetchall()
            return [self._row_to_run(r) for r in rows]

    def update_run(self, run_id: int, **fields: object) -> None:
        allowed = {
            "status",
            "pid",
            "started_at",
            "finished_at",
            "error",
            "output_dir",
            "policy_path",
            "total_instances",
            "completed_instances",
            "failed_instances",
            "resolved_instances",
        }
        invalid = set(fields) - allowed
        if invalid:
            raise ValueError(f"Cannot update fields: {invalid}")

        with self._conn.get() as db:
            # Verify run exists
            row = db.execute(
                "SELECT id FROM production_runs WHERE id = ?", (run_id,)
            ).fetchone()
            if row is None:
                raise KeyError(f"Run not found: {run_id}")

            set_clauses = ", ".join(f"{k} = ?" for k in fields)
            db.execute(
                f"UPDATE production_runs SET {set_clauses} WHERE id = ?",  # noqa: S608
                (*fields.values(), run_id),
            )

    def add_guard_result(self, result: GuardResultRecord) -> int:
        import datetime as _dt

        recorded = result.recorded_at or _dt.datetime.now(_dt.UTC).isoformat()

        with self._conn.get() as db:
            cur = db.execute(
                """\
                INSERT INTO guard_results
                    (run_id, instance_id, arm, step_id, guard_name,
                     passed, feedback, attempt, wall_time_seconds,
                     tokens_used, recorded_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    result.run_id,
                    result.instance_id,
                    result.arm,
                    result.step_id,
                    result.guard_name,
                    1 if result.passed else 0,
                    result.feedback,
                    result.attempt,
                    result.wall_time_seconds,
                    result.tokens_used,
                    recorded,
                ),
            )
            return cur.lastrowid  # type: ignore[return-value]

    def get_guard_results(
        self,
        run_id: int,
        instance_id: str | None = None,
        limit: int = 200,
    ) -> list[GuardResultRecord]:
        with self._conn.get() as db:
            if instance_id:
                rows = db.execute(
                    "SELECT * FROM guard_results "
                    "WHERE run_id = ? AND instance_id = ? "
                    "ORDER BY id DESC LIMIT ?",
                    (run_id, instance_id, limit),
                ).fetchall()
            else:
                rows = db.execute(
                    "SELECT * FROM guard_results WHERE run_id = ? "
                    "ORDER BY id DESC LIMIT ?",
                    (run_id, limit),
                ).fetchall()
            return [self._row_to_guard_result(r) for r in rows]

    def import_results_jsonl(self, run_id: int, jsonl_path: str) -> int:
        """Import ArmResult records from results.jsonl and update run stats."""
        from pathlib import Path

        path = Path(jsonl_path)
        if not path.exists():
            return 0

        count = 0
        total = 0
        completed = 0
        failed = 0
        resolved = 0

        with self._conn.get() as db:
            for line in path.read_text().splitlines():
                line = line.strip()
                if not line:
                    continue
                try:
                    record = json.loads(line)
                except json.JSONDecodeError:
                    continue

                total += 1
                error = record.get("error")
                is_resolved = record.get("resolved")
                if error or record.get("fatal"):
                    failed += 1
                else:
                    completed += 1
                if is_resolved:
                    resolved += 1

                count += 1

            db.execute(
                """\
                UPDATE production_runs
                SET total_instances = ?,
                    completed_instances = ?,
                    failed_instances = ?,
                    resolved_instances = ?
                WHERE id = ?""",
                (total, completed, failed, resolved, run_id),
            )

        return count

    # -- internal helpers --

    @staticmethod
    def _row_to_run(row: sqlite3.Row) -> ProductionRun:
        return ProductionRun(
            id=row["id"],
            workflow_slug=row["workflow_slug"],
            model=row["model"],
            provider=row["provider"],
            arms=tuple(json.loads(row["arms"])),
            language=row["language"],
            max_instances=row["max_instances"],
            max_workers=row["max_workers"],
            output_dir=row["output_dir"],
            policy_path=row["policy_path"],
            status=row["status"],
            pid=row["pid"],
            created_at=row["created_at"] or "",
            started_at=row["started_at"],
            finished_at=row["finished_at"],
            error=row["error"],
            total_instances=row["total_instances"],
            completed_instances=row["completed_instances"],
            failed_instances=row["failed_instances"],
            resolved_instances=row["resolved_instances"],
        )

    @staticmethod
    def _row_to_guard_result(row: sqlite3.Row) -> GuardResultRecord:
        return GuardResultRecord(
            id=row["id"],
            run_id=row["run_id"],
            instance_id=row["instance_id"],
            arm=row["arm"],
            step_id=row["step_id"],
            guard_name=row["guard_name"],
            passed=bool(row["passed"]),
            feedback=row["feedback"],
            attempt=row["attempt"],
            wall_time_seconds=row["wall_time_seconds"],
            tokens_used=row["tokens_used"],
            recorded_at=row["recorded_at"] or "",
        )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _slugify(name: str) -> str:
    """Convert a workflow name to a URL-safe slug."""
    import re

    slug = name.lower().strip()
    slug = re.sub(r"[^a-z0-9]+", "-", slug)
    return slug.strip("-")


def _ap_dict_to_definition(ap_id: str, data: dict) -> ActionPairDefinition:
    """Convert a workflow JSON action pair entry to an ActionPairDefinition."""
    efbg = data.get("escalate_feedback_by_guard", {})
    return ActionPairDefinition(
        ap_id=ap_id,
        generator=data.get("generator", ""),
        generator_config=data.get("generator_config", {}),
        guard=data.get("guard", ""),
        guards=data.get("guards"),
        guard_config=data.get("guard_config", {}),
        requires=tuple(data.get("requires", [])),
        artifact_type=data.get("artifact_type", ""),
        output_type=data.get("output_type", ""),
        r_patience=data.get("r_patience"),
        e_max=data.get("e_max", 1),
        escalate_feedback_to=tuple(data.get("escalate_feedback_to", [])),
        escalate_feedback_by_guard={k: tuple(v) for k, v in efbg.items()},
        human_prompt_title=data.get("human_prompt_title", ""),
        description=data.get("description", ""),
        group=data.get("group", ""),
        goal=data.get("goal", False),
    )


def _ap_definition_to_dict(
    ap: ActionPairDefinition, source_keys: set[str] | list[str] | None = None
) -> dict[str, Any]:
    """Convert an ActionPairDefinition back to a JSON-compatible dict.

    If *source_keys* is provided, include a field if it has a non-default
    value OR was present in the original JSON (for faithful round-trip).
    Key order follows source_keys if it's a list.
    """
    sk = set(source_keys) if source_keys else set()
    # Build pool of all includable key-value pairs
    pool: dict[str, Any] = {}
    if ap.generator or "generator" in sk:
        pool["generator"] = ap.generator
    if ap.generator_config or "generator_config" in sk:
        pool["generator_config"] = ap.generator_config
    if ap.guard or "guard" in sk:
        pool["guard"] = ap.guard
    if ap.guards is not None or "guards" in sk:
        pool["guards"] = ap.guards
    if ap.guard_config or "guard_config" in sk:
        pool["guard_config"] = ap.guard_config
    if ap.requires or "requires" in sk:
        pool["requires"] = list(ap.requires)
    if ap.artifact_type or "artifact_type" in sk:
        pool["artifact_type"] = ap.artifact_type
    if ap.output_type or "output_type" in sk:
        pool["output_type"] = ap.output_type
    if ap.r_patience is not None or "r_patience" in sk:
        pool["r_patience"] = ap.r_patience
    if ap.e_max != 1 or "e_max" in sk:
        pool["e_max"] = ap.e_max
    if ap.escalate_feedback_to or "escalate_feedback_to" in sk:
        pool["escalate_feedback_to"] = list(ap.escalate_feedback_to)
    if ap.escalate_feedback_by_guard or "escalate_feedback_by_guard" in sk:
        pool["escalate_feedback_by_guard"] = {
            k: list(v) for k, v in ap.escalate_feedback_by_guard.items()
        }
    if ap.human_prompt_title or "human_prompt_title" in sk:
        pool["human_prompt_title"] = ap.human_prompt_title
    if ap.description or "description" in sk:
        pool["description"] = ap.description
    if ap.group or "group" in sk:
        pool["group"] = ap.group
    if ap.goal or "goal" in sk:
        pool["goal"] = ap.goal
    # Re-order based on source key order if available
    if isinstance(source_keys, list) and source_keys:
        result: dict[str, Any] = {}
        for k in source_keys:
            if k in pool:
                result[k] = pool[k]
        for k, v in pool.items():
            if k not in result:
                result[k] = v
        return result
    return pool


# ---------------------------------------------------------------------------
# Training run repository
# ---------------------------------------------------------------------------


class SQLiteTrainingRunRepository(TrainingRunRepositoryInterface):
    """SQLite adapter for training run persistence."""

    def __init__(self, conn: SQLiteConnection) -> None:
        self._conn = conn

    def create_run(self, run: TrainingRunRecord) -> int:
        import datetime as _dt

        created = run.created_at or _dt.datetime.now(_dt.UTC).isoformat()
        updated = run.updated_at or created

        with self._conn.get() as db:
            cur = db.execute(
                """\
                INSERT INTO training_runs
                    (slug, display_name, path, model, provider, arm, reward,
                     episodes, gamma, alpha, epsilon_initial, epsilon_final,
                     epsilon_decay, instances, language, training_mean_reward,
                     eval_mean_reward, eval_success_rate, ap_ids, status,
                     completed_episodes, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    run.slug,
                    run.display_name,
                    run.path,
                    run.model,
                    run.provider,
                    run.arm,
                    run.reward,
                    run.episodes,
                    run.gamma,
                    run.alpha,
                    run.epsilon_initial,
                    run.epsilon_final,
                    run.epsilon_decay,
                    run.instances,
                    run.language,
                    run.training_mean_reward,
                    run.eval_mean_reward,
                    run.eval_success_rate,
                    json.dumps(list(run.ap_ids)),
                    run.status,
                    run.completed_episodes,
                    created,
                    updated,
                ),
            )
            return cur.lastrowid  # type: ignore[return-value]

    def get_run(self, run_id: int) -> TrainingRunRecord:
        with self._conn.get() as db:
            row = db.execute(
                "SELECT * FROM training_runs WHERE id = ?", (run_id,)
            ).fetchone()
            if row is None:
                raise KeyError(f"Training run not found: {run_id}")
            return self._row_to_run(row)

    def get_run_by_slug(self, slug: str) -> TrainingRunRecord:
        with self._conn.get() as db:
            row = db.execute(
                "SELECT * FROM training_runs WHERE slug = ?", (slug,)
            ).fetchone()
            if row is None:
                raise KeyError(f"Training run not found: {slug}")
            return self._row_to_run(row)

    def list_runs(
        self,
        status: str | None = None,
        limit: int = 100,
    ) -> list[TrainingRunRecord]:
        with self._conn.get() as db:
            if status:
                rows = db.execute(
                    "SELECT * FROM training_runs WHERE status = ? "
                    "ORDER BY id DESC LIMIT ?",
                    (status, limit),
                ).fetchall()
            else:
                rows = db.execute(
                    "SELECT * FROM training_runs ORDER BY id DESC LIMIT ?",
                    (limit,),
                ).fetchall()
            return [self._row_to_run(r) for r in rows]

    def update_run(self, run_id: int, **fields: object) -> None:
        allowed = {
            "status",
            "completed_episodes",
            "training_mean_reward",
            "eval_mean_reward",
            "eval_success_rate",
            "epsilon_final",
            "episodes",
            "updated_at",
        }
        invalid = set(fields) - allowed
        if invalid:
            raise ValueError(f"Cannot update fields: {invalid}")
        with self._conn.get() as db:
            row = db.execute(
                "SELECT id FROM training_runs WHERE id = ?", (run_id,)
            ).fetchone()
            if row is None:
                raise KeyError(f"Training run not found: {run_id}")
            set_clauses = ", ".join(f"{k} = ?" for k in fields)
            db.execute(
                f"UPDATE training_runs SET {set_clauses} WHERE id = ?",  # noqa: S608
                (*fields.values(), run_id),
            )

    def add_episode(self, episode: TrainingEpisodeRecord) -> int:
        with self._conn.get() as db:
            cur = db.execute(
                """\
                INSERT INTO training_episodes
                    (training_run_id, episode, reward, steps, epsilon,
                     satisfied, total_aps, all_satisfied, duration_secs,
                     tokens, backtracks, instance_id)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    episode.training_run_id,
                    episode.episode,
                    episode.reward,
                    episode.steps,
                    episode.epsilon,
                    episode.satisfied,
                    episode.total_aps,
                    1
                    if episode.all_satisfied
                    else (0 if episode.all_satisfied is not None else None),
                    episode.duration_secs,
                    episode.tokens,
                    episode.backtracks,
                    episode.instance_id,
                ),
            )
            return cur.lastrowid  # type: ignore[return-value]

    def get_episodes(
        self,
        training_run_id: int,
        limit: int = 1000,
    ) -> list[TrainingEpisodeRecord]:
        with self._conn.get() as db:
            rows = db.execute(
                "SELECT * FROM training_episodes WHERE training_run_id = ? "
                "ORDER BY episode ASC LIMIT ?",
                (training_run_id, limit),
            ).fetchall()
            return [self._row_to_episode(r) for r in rows]

    def import_from_filesystem(self, run_dir: str) -> int:
        """Import a training run from a filesystem directory."""
        import datetime as _dt

        run_path = Path(run_dir)
        if not run_path.is_dir():
            raise FileNotFoundError(f"Not a directory: {run_dir}")

        slug = run_path.name

        # Check if already imported
        with self._conn.get() as db:
            existing = db.execute(
                "SELECT id FROM training_runs WHERE slug = ?", (slug,)
            ).fetchone()
            if existing:
                return int(existing["id"])

        # Load metadata from summary or config
        meta: dict[str, Any] = {}
        for name in ("training_summary.json", "training_config.json"):
            meta_path = run_path / name
            if meta_path.exists():
                meta = json.loads(meta_path.read_text())
                break

        now = _dt.datetime.now(_dt.UTC).isoformat()

        run = TrainingRunRecord(
            id=0,
            slug=slug,
            display_name=slug.replace("_", " ").title(),
            path=str(run_path),
            model=meta.get("model", ""),
            provider=meta.get("provider", ""),
            arm=meta.get("arm", ""),
            reward=meta.get("reward", ""),
            episodes=meta.get("episodes", 0),
            gamma=meta.get("gamma", 0.0),
            alpha=meta.get("alpha", 0.0),
            epsilon_initial=meta.get("epsilon_initial", 0.0),
            epsilon_final=meta.get("epsilon_final", 0.0),
            epsilon_decay=meta.get("epsilon_decay", 0.0),
            instances=meta.get("instances", 0),
            language=meta.get("language"),
            training_mean_reward=meta.get("training_mean_reward", 0.0),
            eval_mean_reward=meta.get("eval_mean_reward", 0.0),
            eval_success_rate=meta.get("eval_success_rate", 0.0),
            ap_ids=tuple(meta.get("ap_ids", [])),
            status="complete"
            if (run_path / "training_summary.json").exists()
            else "in_progress",
            created_at=now,
            updated_at=now,
        )
        run_id = self.create_run(run)

        # Import episode log
        log_path = run_path / "episode_log.jsonl"
        ep_count = 0
        if log_path.exists():
            for line in log_path.read_text().splitlines():
                line = line.strip()
                if not line:
                    continue
                try:
                    data = json.loads(line)
                except json.JSONDecodeError:
                    continue
                ep = TrainingEpisodeRecord(
                    id=0,
                    training_run_id=run_id,
                    episode=data.get("episode", 0),
                    reward=data.get("reward", 0.0),
                    steps=data.get("steps", 0),
                    epsilon=data.get("epsilon", 0.0),
                    satisfied=data.get("satisfied"),
                    total_aps=data.get("total_aps"),
                    all_satisfied=data.get("all_satisfied"),
                    duration_secs=data.get("duration_secs"),
                    tokens=data.get("tokens"),
                    backtracks=data.get("backtracks"),
                    instance_id=data.get("instance_id"),
                )
                self.add_episode(ep)
                ep_count += 1

        # Update completed_episodes
        if ep_count > 0:
            self.update_run(run_id, completed_episodes=ep_count, updated_at=now)

        return run_id

    @staticmethod
    def _row_to_run(row: sqlite3.Row) -> TrainingRunRecord:
        return TrainingRunRecord(
            id=row["id"],
            slug=row["slug"],
            display_name=row["display_name"],
            path=row["path"],
            model=row["model"],
            provider=row["provider"],
            arm=row["arm"],
            reward=row["reward"],
            episodes=row["episodes"],
            gamma=row["gamma"],
            alpha=row["alpha"],
            epsilon_initial=row["epsilon_initial"],
            epsilon_final=row["epsilon_final"],
            epsilon_decay=row["epsilon_decay"],
            instances=row["instances"],
            language=row["language"],
            training_mean_reward=row["training_mean_reward"],
            eval_mean_reward=row["eval_mean_reward"],
            eval_success_rate=row["eval_success_rate"],
            ap_ids=tuple(json.loads(row["ap_ids"])),
            status=row["status"],
            completed_episodes=row["completed_episodes"],
            created_at=row["created_at"] or "",
            updated_at=row["updated_at"] or "",
        )

    @staticmethod
    def _row_to_episode(row: sqlite3.Row) -> TrainingEpisodeRecord:
        all_sat = row["all_satisfied"]
        return TrainingEpisodeRecord(
            id=row["id"],
            training_run_id=row["training_run_id"],
            episode=row["episode"],
            reward=row["reward"],
            steps=row["steps"],
            epsilon=row["epsilon"],
            satisfied=row["satisfied"],
            total_aps=row["total_aps"],
            all_satisfied=bool(all_sat) if all_sat is not None else None,
            duration_secs=row["duration_secs"],
            tokens=row["tokens"],
            backtracks=row["backtracks"],
            instance_id=row["instance_id"],
        )


# ---------------------------------------------------------------------------
# Policy repository
# ---------------------------------------------------------------------------


class SQLitePolicyRepository(PolicyRepositoryInterface):
    """SQLite adapter for trained policy persistence."""

    def __init__(self, conn: SQLiteConnection) -> None:
        self._conn = conn

    def create_policy(self, policy: PolicyRecord) -> int:
        import datetime as _dt

        created = policy.created_at or _dt.datetime.now(_dt.UTC).isoformat()
        with self._conn.get() as db:
            cur = db.execute(
                """\
                INSERT OR REPLACE INTO policies
                    (slug, display_name, path, training_run_id, training_run_slug,
                     model, provider, arm, reward, episodes, mean_reward,
                     eval_success_rate, ap_ids, num_states, num_actions,
                     total_visits, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    policy.slug,
                    policy.display_name,
                    policy.path,
                    policy.training_run_id,
                    policy.training_run_slug,
                    policy.model,
                    policy.provider,
                    policy.arm,
                    policy.reward,
                    policy.episodes,
                    policy.mean_reward,
                    policy.eval_success_rate,
                    json.dumps(list(policy.ap_ids)),
                    policy.num_states,
                    policy.num_actions,
                    policy.total_visits,
                    created,
                ),
            )
            return cur.lastrowid  # type: ignore[return-value]

    def get_policy(self, policy_id: int) -> PolicyRecord:
        with self._conn.get() as db:
            row = db.execute(
                "SELECT * FROM policies WHERE id = ?", (policy_id,)
            ).fetchone()
            if row is None:
                raise KeyError(f"Policy not found: {policy_id}")
            return self._row_to_policy(row)

    def get_policy_by_slug(self, slug: str) -> PolicyRecord:
        with self._conn.get() as db:
            row = db.execute(
                "SELECT * FROM policies WHERE slug = ?", (slug,)
            ).fetchone()
            if row is None:
                raise KeyError(f"Policy not found: {slug}")
            return self._row_to_policy(row)

    def list_policies(self, limit: int = 100) -> list[PolicyRecord]:
        with self._conn.get() as db:
            rows = db.execute(
                "SELECT * FROM policies ORDER BY id DESC LIMIT ?",
                (limit,),
            ).fetchall()
            return [self._row_to_policy(r) for r in rows]

    def scan_checkpoints(self, output_dir: str) -> int:
        """Scan output directory for checkpoint dirs and import new policies."""
        import datetime as _dt

        import numpy as np

        output_path = Path(output_dir)
        if not output_path.is_dir():
            return 0

        count = 0
        # Scan rl_training dirs for checkpoint dirs with qtable.npz
        rl_dir = output_path / "rl_training"
        if not rl_dir.is_dir():
            return 0

        for run_dir in sorted(rl_dir.iterdir()):
            if not run_dir.is_dir():
                continue
            # Check subdirectories that look like training runs
            candidates = [run_dir]
            for child in sorted(run_dir.iterdir()):
                if child.is_dir() and not child.name.startswith("checkpoint_"):
                    candidates.append(child)

            for candidate in candidates:
                # Find the best checkpoint: latest symlink, final, or last numbered
                qtable_path = None
                checkpoint_dir = None
                for ckpt_name in ("latest", "final"):
                    ckpt = candidate / ckpt_name
                    if ckpt.exists() and (ckpt / "qtable.npz").exists():
                        qtable_path = ckpt / "qtable.npz"
                        checkpoint_dir = ckpt
                        break

                if qtable_path is None:
                    numbered = sorted(
                        d
                        for d in candidate.iterdir()
                        if d.is_dir()
                        and d.name.startswith("checkpoint_")
                        and (d / "qtable.npz").exists()
                    )
                    if numbered:
                        checkpoint_dir = numbered[-1]
                        qtable_path = checkpoint_dir / "qtable.npz"

                if qtable_path is None or checkpoint_dir is None:
                    continue

                slug = f"policy-{candidate.name}"
                # Skip if already exists
                with self._conn.get() as db:
                    existing = db.execute(
                        "SELECT id FROM policies WHERE slug = ?", (slug,)
                    ).fetchone()
                    if existing:
                        continue

                # Load metadata
                meta: dict[str, Any] = {}
                for name in ("training_summary.json", "training_config.json"):
                    meta_path = candidate / name
                    if meta_path.exists():
                        with contextlib.suppress(json.JSONDecodeError):
                            meta = json.loads(meta_path.read_text())
                        break

                # Load Q-table stats
                num_states = 0
                num_actions = 0
                total_visits = 0
                ap_ids: list[str] = meta.get("ap_ids", [])
                try:
                    data = np.load(qtable_path, allow_pickle=True)
                    q = data["Q"]
                    num_states, num_actions = q.shape
                    if "visit_count" in data:
                        total_visits = int(data["visit_count"].sum())
                    if "ap_ids" in data and not ap_ids:
                        ap_ids = [str(x) for x in data["ap_ids"]]
                except (OSError, KeyError, ValueError):
                    logger.debug("Could not read Q-table stats from %s", qtable_path)

                # Find linked training run
                training_run_id = None
                training_run_slug = candidate.name
                with self._conn.get() as db:
                    tr_row = db.execute(
                        "SELECT id FROM training_runs WHERE slug = ?",
                        (candidate.name,),
                    ).fetchone()
                    if tr_row:
                        training_run_id = tr_row["id"]

                # Load checkpoint metadata for reward
                ckpt_meta_path = checkpoint_dir / "metadata.json"
                ckpt_meta: dict[str, Any] = {}
                if ckpt_meta_path.exists():
                    with contextlib.suppress(json.JSONDecodeError):
                        ckpt_meta = json.loads(ckpt_meta_path.read_text())

                now = _dt.datetime.now(_dt.UTC).isoformat()
                policy = PolicyRecord(
                    id=0,
                    slug=slug,
                    display_name=candidate.name.replace("_", " ").title(),
                    path=str(checkpoint_dir.resolve()),
                    training_run_id=training_run_id,
                    training_run_slug=training_run_slug,
                    model=meta.get("model", ""),
                    provider=meta.get("provider", ""),
                    arm=meta.get("arm", ""),
                    reward=meta.get("reward", ""),
                    episodes=ckpt_meta.get("total_episodes", meta.get("episodes", 0)),
                    mean_reward=ckpt_meta.get(
                        "mean_reward", meta.get("eval_mean_reward", 0.0)
                    ),
                    eval_success_rate=meta.get("eval_success_rate", 0.0),
                    ap_ids=tuple(ap_ids),
                    num_states=num_states,
                    num_actions=num_actions,
                    total_visits=total_visits,
                    created_at=now,
                )
                self.create_policy(policy)
                count += 1

        return count

    @staticmethod
    def _row_to_policy(row: sqlite3.Row) -> PolicyRecord:
        return PolicyRecord(
            id=row["id"],
            slug=row["slug"],
            display_name=row["display_name"],
            path=row["path"],
            training_run_id=row["training_run_id"],
            training_run_slug=row["training_run_slug"],
            model=row["model"],
            provider=row["provider"],
            arm=row["arm"],
            reward=row["reward"],
            episodes=row["episodes"],
            mean_reward=row["mean_reward"],
            eval_success_rate=row["eval_success_rate"],
            ap_ids=tuple(json.loads(row["ap_ids"])),
            num_states=row["num_states"],
            num_actions=row["num_actions"],
            total_visits=row["total_visits"],
            created_at=row["created_at"] or "",
        )
