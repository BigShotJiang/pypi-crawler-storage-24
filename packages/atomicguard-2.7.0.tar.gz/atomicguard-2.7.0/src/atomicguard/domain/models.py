"""
Domain models for the Dual-State Framework.

These are pure data structures aligned with paper Definitions 4-6.
All models are immutable (frozen dataclasses) to ensure referential transparency.
"""

from dataclasses import dataclass, field
from enum import Enum
from types import MappingProxyType
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from atomicguard.domain.interfaces import ArtifactDAGInterface


# =============================================================================
# GUARD RESULT (moved before Artifact for forward reference)
# =============================================================================


@dataclass(frozen=True)
class SubGuardOutcome:
    """Outcome from a single sub-guard within a composite (Definition 43).

    Captures individual guard result for attribution in composite validations.
    """

    guard_name: str  # Class name of the sub-guard
    passed: bool  # Whether this sub-guard passed
    feedback: str  # Feedback from this sub-guard
    execution_time_ms: float = 0.0  # Time spent in this sub-guard


@dataclass(frozen=True)
class GuardResult:
    """Immutable guard validation outcome (Definition 6).

    G(α, C) → {v, φ} where:
    - v = passed (⊤ or ⊥)
    - φ = feedback signal
    - fatal = ⊥_fatal (non-recoverable, requires escalation)

    Note: Stagnation detection is done by the agent (which sees feedback history),
    not by guards (which are stateless and validate single artifacts).
    """

    passed: bool
    feedback: str = ""
    fatal: bool = False  # ⊥_fatal - skip retry, escalate to human
    guard_name: str | None = None  # Name of the guard that produced this result
    metadata: dict[str, str] | None = (
        None  # Structured guard observations (e.g. strategy recommendation)
    )
    sub_results: tuple[SubGuardOutcome, ...] = ()  # For composite guards (Extension 08)


# =============================================================================
# ARTIFACT MODEL (Definition 4-6)
# =============================================================================


class ArtifactStatus(Enum):
    """Status of an artifact in the DAG."""

    PENDING = "pending"  # Generated, not yet validated
    REJECTED = "rejected"  # Guard returned ⊥
    ACCEPTED = "accepted"  # Guard returned ⊤, final for this step
    SUPERSEDED = "superseded"  # Guard returned ⊤, but later attempt also passed


class ArtifactSource(Enum):
    """Origin of artifact content."""

    GENERATED = "generated"  # LLM-generated
    HUMAN = "human"  # Human-provided during amendment
    IMPORTED = "imported"  # Imported from external source


@dataclass(frozen=True)
class FeedbackEntry:
    """Single entry in feedback history H."""

    artifact_id: str  # Reference to the rejected artifact
    feedback: str  # Guard's rejection message φ


@dataclass(frozen=True)
class ContextSnapshot:
    """Immutable context C that conditioned generation (Definition 5)."""

    workflow_id: str  # UUID of the workflow execution instance
    specification: str  # Ψ - static specification
    constraints: str  # Ω - global constraints
    feedback_history: tuple[FeedbackEntry, ...]  # H - accumulated rejections
    dependency_artifacts: tuple[
        tuple[str, str], ...
    ] = ()  # (action_pair_id, artifact_id) - matches schema
    escalation_feedback: tuple[str, ...] = ()  # One entry per escalation cycle
    dependency_types: tuple[
        tuple[str, str], ...
    ] = ()  # (action_pair_id, artifact_type) for type-based lookup


@dataclass(frozen=True)
class Artifact:
    """
    Immutable node in the Versioned Repository DAG (Definition 4).

    Represents a single generation attempt with full provenance tracking.
    """

    # Identity
    artifact_id: str  # Unique identifier (UUID)
    workflow_id: str  # UUID of the workflow execution instance
    content: str  # The generated code/text

    # DAG Structure
    previous_attempt_id: str | None  # Retry chain within same action pair
    parent_action_pair_id: str | None  # Parent hierarchy for composite generators
    # Cross-step deps are in context.dependency_artifacts

    # Action Pair Coupling (Definition 6: A = ⟨ρ, a_gen, G⟩)
    action_pair_id: str  # Which action pair produced this

    # Metadata
    created_at: str  # ISO timestamp
    attempt_number: int  # Attempt within this action pair context
    status: ArtifactStatus  # pending/rejected/accepted/superseded
    guard_result: GuardResult | None  # Full guard result (None if pending)
    context: ContextSnapshot  # Full context snapshot at generation time
    source: ArtifactSource = ArtifactSource.GENERATED  # Origin of content

    # Extension 01: Versioned Environment (Definition 10)
    workflow_ref: str | None = None  # W_ref: Content-addressed workflow hash (Def 11)

    # Extension 07: Incremental Execution (Definition 33)
    config_ref: str | None = (
        None  # Ψ_ref: Configuration fingerprint for change detection
    )

    metadata: MappingProxyType[str, Any] = field(
        default_factory=lambda: MappingProxyType({})
    )  # Immutable metadata dict

    # Semantic type tag for dependency resolution by type
    artifact_type: str | None = None  # e.g. "patch", "localization", "test"

    # Producer-driven context instruction for consumers
    artifact_context: str | None = None

    def __post_init__(self) -> None:
        """Convert metadata dict to immutable MappingProxyType if needed."""
        # Handle case where metadata is passed as a regular dict
        if isinstance(object.__getattribute__(self, "metadata"), dict):
            object.__setattr__(self, "metadata", MappingProxyType(self.metadata))


# =============================================================================
# CONTEXT AND ENVIRONMENT
# =============================================================================


@dataclass(frozen=True)
class AmbientEnvironment:
    """Ambient Environment E = ⟨R, Ω⟩"""

    repository: "ArtifactDAGInterface"
    constraints: str = ""


@dataclass(frozen=True)
class Context:
    """Immutable hierarchical context composition (Definition 5)."""

    ambient: AmbientEnvironment
    specification: str
    current_artifact: str | None = None
    feedback_history: tuple[tuple[str, str], ...] = ()
    dependency_artifacts: tuple[
        tuple[str, str], ...
    ] = ()  # (action_pair_id, artifact_id) - matches schema
    workflow_id: str | None = None  # Extension 03: Agent workflow identifier (Def 19)
    escalation_feedback: tuple[str, ...] = ()  # Downstream failure summaries
    dependency_types: tuple[
        tuple[str, str], ...
    ] = ()  # (action_pair_id, artifact_type) for type-based lookup
    dependency_artifact_contexts: tuple[
        tuple[str, str], ...
    ] = ()  # (action_pair_id, artifact_context) for producer-driven context

    def get_dependency_by_type(self, artifact_type: str) -> str | None:
        """Look up artifact_id by artifact_type.

        Returns the artifact_id for the first dependency whose type matches.
        """
        for ap_id, dep_type in self.dependency_types:
            if dep_type == artifact_type:
                return self.get_dependency(ap_id)
        return None

    def get_dependency(self, action_pair_id: str) -> str | None:
        """Look up artifact_id by action_pair_id."""
        for key, artifact_id in self.dependency_artifacts:
            if key == action_pair_id:
                return artifact_id
        return None

    def amend(self, delta_spec: str = "", delta_constraints: str = "") -> "Context":
        """Monotonic configuration amendment (⊕ operator, Definition 12).

        Creates a new Context with appended specification and/or constraints.
        Original Context remains unchanged (immutability preserved).

        Args:
            delta_spec: Additional specification to append to current specification.
            delta_constraints: Additional constraints to append to ambient constraints.

        Returns:
            New Context with amended specification and constraints.
        """
        new_spec = self.specification
        if delta_spec:
            new_spec = f"{self.specification}\n{delta_spec}"

        new_constraints = self.ambient.constraints
        if delta_constraints:
            new_constraints = f"{self.ambient.constraints}\n{delta_constraints}"

        new_ambient = AmbientEnvironment(
            repository=self.ambient.repository,
            constraints=new_constraints,
        )

        return Context(
            ambient=new_ambient,
            specification=new_spec,
            current_artifact=self.current_artifact,
            feedback_history=self.feedback_history,
            dependency_artifacts=self.dependency_artifacts,
            workflow_id=self.workflow_id,
            escalation_feedback=self.escalation_feedback,
            dependency_types=self.dependency_types,
            dependency_artifact_contexts=self.dependency_artifact_contexts,
        )


# =============================================================================
# WORKFLOW STATE
# =============================================================================


class WorkflowStatus(Enum):
    """Workflow execution outcome."""

    SUCCESS = "success"  # All steps completed
    FAILED = "failed"  # Rmax exhausted on a step
    ESCALATION = "escalation"  # Fatal guard triggered


@dataclass
class WorkflowState:
    """Mutable workflow state tracking guard satisfaction."""

    guards: dict[str, bool] = field(default_factory=dict)
    artifact_ids: dict[str, str] = field(default_factory=dict)

    def is_satisfied(self, guard_id: str) -> bool:
        return self.guards.get(guard_id, False)

    def satisfy(self, guard_id: str, artifact_id: str) -> None:
        self.guards[guard_id] = True
        self.artifact_ids[guard_id] = artifact_id

    def unsatisfy(self, guard_id: str) -> None:
        """Mark a guard as unsatisfied (Extension 09: Cascade Invalidation)."""
        self.guards[guard_id] = False
        self.artifact_ids.pop(guard_id, None)

    def get_artifact_id(self, guard_id: str) -> str | None:
        return self.artifact_ids.get(guard_id)

    def get_satisfied_guards(self) -> tuple[str, ...]:
        """Return tuple of all currently satisfied guard IDs."""
        return tuple(gid for gid, satisfied in self.guards.items() if satisfied)


@dataclass(frozen=True)
class WorkflowResult:
    """Result of workflow execution."""

    status: WorkflowStatus
    artifacts: dict[str, Artifact]
    failed_step: str | None = None
    provenance: tuple[tuple[Artifact, str], ...] = ()
    escalation_artifact: Artifact | None = None  # Artifact that triggered escalation
    escalation_feedback: str = ""  # Fatal feedback message


# =============================================================================
# STAGNATION INFO (Definition 44)
# =============================================================================


@dataclass(frozen=True)
class StagnationInfo:
    """Result of stagnation detection (Definition 44).

    Captures whether consecutive failures are similar enough to trigger
    escalation, along with summary information for context injection.
    """

    detected: bool  # True if r_patience consecutive similar failures
    similar_count: int  # Number of consecutive similar failures
    error_signature: str  # Deduplicated error type/pattern
    approaches_tried: tuple[str, ...]  # Summary of what was attempted
    failure_summary: str  # Full summary for context injection (Definition 48)
    stagnant_guard: str | None = (
        None  # Sub-guard that caused stagnation (composite guards)
    )


# =============================================================================
# WEB UI DOMAIN MODELS (workflow/AP context persistence)
# =============================================================================


@dataclass(frozen=True)
class WorkflowSummary:
    """Lightweight workflow metadata for list views."""

    slug: str
    name: str
    description: str = ""
    action_pair_count: int = 0
    model: str = ""
    provider: str = ""


@dataclass(frozen=True)
class ActionPairDefinition:
    """Stored definition of a single action pair within a workflow."""

    ap_id: str
    generator: str = ""
    generator_config: dict[str, Any] = field(default_factory=dict)
    guard: str = ""
    guards: Any = None  # list[str] | CompositeGuardSpec dict | None
    guard_config: dict[str, Any] = field(default_factory=dict)
    requires: tuple[str, ...] = ()
    artifact_type: str = ""
    output_type: str = ""
    r_patience: int | None = None
    e_max: int = 1
    escalate_feedback_to: tuple[str, ...] = ()
    escalate_feedback_by_guard: dict[str, tuple[str, ...]] = field(default_factory=dict)
    human_prompt_title: str = ""
    description: str = ""
    group: str = ""
    goal: bool = False


@dataclass(frozen=True)
class WorkflowDefinition:
    """Full workflow definition for persistence and round-trip export."""

    slug: str
    name: str
    description: str = ""
    specification: Any = None  # str | SpecificationSource dict
    constraints: str = ""
    model: str = ""
    provider: str = ""
    rmax: int = 3
    action_pairs: tuple[ActionPairDefinition, ...] = ()


@dataclass(frozen=True)
class APContextEntry:
    """Stored AP context (prompt template) for a single action pair."""

    ap_id: str
    role: str = ""
    constraints: str = ""
    task: str = ""
    feedback_wrapper: str = ""
    escalation_feedback_wrapper: str = ""
    feedback_mode: str = "inline"
    artifact_context: str = ""


# =============================================================================
# Production Run Management (Web UI — Step 4)
# =============================================================================


@dataclass(frozen=True)
class ProductionRun:
    """A production experiment run tracked by the web UI."""

    id: int
    workflow_slug: str
    model: str = ""
    provider: str = ""
    arms: tuple[str, ...] = ()
    language: str | None = None
    max_instances: int | None = None
    max_workers: int = 1
    output_dir: str = ""
    policy_path: str = ""  # path to trained RL policy checkpoint dir
    status: str = "pending"  # pending | running | completed | failed | cancelled
    pid: int | None = None
    created_at: str = ""  # ISO 8601
    started_at: str | None = None
    finished_at: str | None = None
    error: str | None = None
    # Summary stats (populated after completion or during progress)
    total_instances: int = 0
    completed_instances: int = 0
    failed_instances: int = 0
    resolved_instances: int = 0


@dataclass(frozen=True)
class GuardResultRecord:
    """A single guard result from a production run, for the timeline view."""

    id: int
    run_id: int
    instance_id: str
    arm: str
    step_id: str
    guard_name: str
    passed: bool
    feedback: str = ""
    attempt: int = 1
    wall_time_seconds: float = 0.0
    tokens_used: int = 0
    recorded_at: str = ""  # ISO 8601


# =============================================================================
# Training Run Management (Web UI — Step 5)
# =============================================================================


@dataclass(frozen=True)
class TrainingRunRecord:
    """A training run tracked by the web UI."""

    id: int
    slug: str
    display_name: str
    path: str  # filesystem path to training run directory
    model: str = ""
    provider: str = ""
    arm: str = ""
    reward: str = ""
    episodes: int = 0
    gamma: float = 0.0
    alpha: float = 0.0
    epsilon_initial: float = 0.0
    epsilon_final: float = 0.0
    epsilon_decay: float = 0.0
    instances: int = 0
    language: str | None = None
    training_mean_reward: float = 0.0
    eval_mean_reward: float = 0.0
    eval_success_rate: float = 0.0
    ap_ids: tuple[str, ...] = ()
    status: str = "complete"  # in_progress | complete | terminated
    completed_episodes: int = 0
    created_at: str = ""
    updated_at: str = ""


@dataclass(frozen=True)
class TrainingEpisodeRecord:
    """A single training episode record."""

    id: int
    training_run_id: int
    episode: int
    reward: float = 0.0
    steps: int = 0
    epsilon: float = 0.0
    satisfied: int | None = None
    total_aps: int | None = None
    all_satisfied: bool | None = None
    duration_secs: float | None = None
    tokens: int | None = None
    backtracks: int | None = None
    instance_id: str | None = None


# =============================================================================
# Policy Library (Web UI — Step 6)
# =============================================================================


@dataclass(frozen=True)
class PolicyRecord:
    """A trained policy in the policy library."""

    id: int
    slug: str
    display_name: str
    path: str  # filesystem path to checkpoint directory
    training_run_id: int | None = None  # link to source training run
    training_run_slug: str = ""
    model: str = ""
    provider: str = ""
    arm: str = ""
    reward: str = ""
    episodes: int = 0
    mean_reward: float = 0.0
    eval_success_rate: float = 0.0
    ap_ids: tuple[str, ...] = ()
    num_states: int = 0
    num_actions: int = 0
    total_visits: int = 0
    created_at: str = ""
