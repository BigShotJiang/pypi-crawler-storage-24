"""FastEval output reporters."""
