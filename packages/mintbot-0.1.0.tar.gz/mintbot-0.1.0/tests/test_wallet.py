"""
tests/test_wallet.py — Mintbot SDK test suite.

Run with:
    pytest tests/ -v

For live API tests (requires network):
    pytest tests/ -v -m live
"""
from __future__ import annotations

from datetime import datetime
from unittest.mock import MagicMock, patch
import json

import pytest
import httpx

from mintbot import (
    AgentWallet,
    AuthenticationError,
    InsufficientBalance,
    WalletNotFound,
    APIError,
    Invoice,
    PaymentResult,
    Transaction,
    BalanceInfo,
    HealthInfo,
    WithdrawalResult,
)


# ── Fixtures ──────────────────────────────────────────────────────────────────

FAKE_API_KEY = "vf_live_00000000000000000000000000000000"
BASE_URL = "https://api.visionfusen.org"


def make_wallet() -> AgentWallet:
    return AgentWallet(api_key=FAKE_API_KEY, base_url=BASE_URL)


def mock_response(status_code: int, body: dict) -> MagicMock:
    resp = MagicMock(spec=httpx.Response)
    resp.status_code = status_code
    resp.is_success = 200 <= status_code < 300
    resp.json.return_value = body
    return resp


# ── Unit tests ────────────────────────────────────────────────────────────────


class TestAgentWalletCreate:
    def test_create_success(self):
        body = {
            "wallet_id": "w_abc123",
            "api_key": FAKE_API_KEY,
            "api_key_prefix": "vf_live_0000000",
            "mint_url": "http://127.0.0.1:3339",
            "balance_sats": 0,
            "agent_name": "test-bot",
            "budget_limit_sats": None,
            "warning": "Store your api_key securely",
        }
        with patch("httpx.Client") as MockClient:
            ctx = MockClient.return_value.__enter__.return_value
            ctx.post.return_value = mock_response(201, body)
            wallet = AgentWallet.create(agent_name="test-bot", base_url=BASE_URL)

        assert isinstance(wallet, AgentWallet)
        assert wallet.api_key == FAKE_API_KEY
        assert wallet._wallet_info.wallet_id == "w_abc123"

    def test_create_server_error(self):
        with patch("httpx.Client") as MockClient:
            ctx = MockClient.return_value.__enter__.return_value
            ctx.post.return_value = mock_response(500, {"error": "Internal server error"})
            with pytest.raises(APIError):
                AgentWallet.create(base_url=BASE_URL)


class TestBalance:
    def test_balance_property(self):
        wallet = make_wallet()
        body = {
            "wallet_id": "w_abc",
            "agent_name": "bot",
            "balance_sats": 950,
            "budget_limit_sats": None,
            "created_at": "2025-01-01T00:00:00Z",
            "last_active": "2025-01-02T00:00:00Z",
        }
        with patch.object(wallet._client, "get", return_value=mock_response(200, body)):
            assert wallet.balance == 950

    def test_balance_auth_error(self):
        wallet = make_wallet()
        with patch.object(wallet._client, "get", return_value=mock_response(401, {"error": "Unauthorized"})):
            with pytest.raises(AuthenticationError):
                _ = wallet.balance

    def test_get_balance_info(self):
        wallet = make_wallet()
        body = {
            "wallet_id": "w_abc",
            "agent_name": "my-bot",
            "balance_sats": 500,
            "budget_limit_sats": 1000,
            "created_at": "2025-06-01T10:00:00Z",
            "last_active": "2025-06-02T12:00:00Z",
        }
        with patch.object(wallet._client, "get", return_value=mock_response(200, body)):
            info = wallet.get_balance_info()

        assert isinstance(info, BalanceInfo)
        assert info.balance_sats == 500
        assert info.budget_limit_sats == 1000
        assert info.agent_name == "my-bot"


class TestCreateInvoice:
    def test_create_invoice_success(self):
        wallet = make_wallet()
        body = {
            "method": "lightning",
            "bolt11": "lnbc1000n1...",
            "quote_id": "q_xyz",
            "amount_sats": 1000,
            "status": "UNPAID",
            "wallet_id": "w_abc",
            "note": "Pay this invoice.",
        }
        with patch.object(wallet._client, "post", return_value=mock_response(200, body)):
            invoice = wallet.create_invoice(amount=1000)

        assert isinstance(invoice, Invoice)
        assert invoice.bolt11 == "lnbc1000n1..."
        assert invoice.amount_sats == 1000
        assert invoice.status == "UNPAID"

    def test_create_invoice_invalid_amount(self):
        wallet = make_wallet()
        with pytest.raises(Exception):
            wallet.create_invoice(amount=0)


class TestPay:
    def test_pay_internal_success(self):
        wallet = make_wallet()
        body = {
            "success": True,
            "tx_id": "tx_001",
            "from_wallet": "w_abc",
            "to_wallet": "w_xyz",
            "amount_sats": 50,
            "tx_type": "internal",
            "memo": "translation",
            "status": "completed",
            "new_balance_sats": 900,
            "created_at": "2025-01-01T00:00:00Z",
        }
        with patch.object(wallet._client, "post", return_value=mock_response(200, body)):
            result = wallet.pay(to_wallet="w_xyz", amount=50, memo="translation")

        assert isinstance(result, PaymentResult)
        assert result.tx_type == "internal"
        assert result.amount_sats == 50
        assert result.new_balance_sats == 900

    def test_pay_insufficient_balance(self):
        wallet = make_wallet()
        body = {
            "error": "Insufficient balance",
            "balance_sats": 10,
            "required_sats": 50,
            "shortfall_sats": 40,
        }
        with patch.object(wallet._client, "post", return_value=mock_response(402, body)):
            with pytest.raises(InsufficientBalance) as exc_info:
                wallet.pay(to_wallet="w_xyz", amount=50)

        assert exc_info.value.balance_sats == 10
        assert exc_info.value.shortfall_sats == 40

    def test_pay_wallet_not_found(self):
        wallet = make_wallet()
        body = {"error": "Recipient wallet not found"}
        with patch.object(wallet._client, "post", return_value=mock_response(404, body)):
            with pytest.raises(WalletNotFound):
                wallet.pay(to_wallet="w_nonexistent", amount=50)

    def test_pay_invoice(self):
        wallet = make_wallet()
        body = {
            "success": True,
            "tx_id": "tx_002",
            "from_wallet": "w_abc",
            "amount_sats": 500,
            "fee_sats": 2,
            "total_debited_sats": 502,
            "tx_type": "lightning_out",
            "status": "completed",
            "new_balance_sats": 448,
            "lightning_invoice": "lnbc500n1...",
            "created_at": "2025-01-01T00:00:00Z",
        }
        with patch.object(wallet._client, "post", return_value=mock_response(200, body)):
            result = wallet.pay_invoice("lnbc500n1...")

        assert result.tx_type == "lightning_out"
        assert result.fee_sats == 2

    def test_pay_address(self):
        wallet = make_wallet()
        body = {
            "success": True,
            "tx_id": "tx_003",
            "from_wallet": "w_abc",
            "amount_sats": 100,
            "fee_sats": 1,
            "total_debited_sats": 101,
            "tx_type": "lightning_out",
            "status": "completed",
            "new_balance_sats": 849,
            "lightning_address": "user@getalby.com",
            "created_at": "2025-01-01T00:00:00Z",
        }
        with patch.object(wallet._client, "post", return_value=mock_response(200, body)):
            result = wallet.pay_address("user@getalby.com", amount=100)

        assert result.lightning_address == "user@getalby.com"
        assert result.amount_sats == 100


class TestWithdraw:
    def test_withdraw_returns_token(self):
        wallet = make_wallet()
        body = {
            "success": True,
            "tx_id": "tx_004",
            "token": "cashuAeyJhbGciOiJIUzI1NiJ9...",
            "amount_sats": 200,
            "wallet_id": "w_abc",
            "new_balance_sats": 750,
            "created_at": "2025-01-01T00:00:00Z",
        }
        with patch.object(wallet._client, "post", return_value=mock_response(200, body)):
            token = wallet.withdraw(amount=200)

        assert token.startswith("cashuA")

    def test_withdraw_full_returns_result(self):
        wallet = make_wallet()
        body = {
            "success": True,
            "tx_id": "tx_005",
            "token": "cashuAeyJ...",
            "amount_sats": 200,
            "wallet_id": "w_abc",
            "new_balance_sats": 750,
            "created_at": "2025-01-01T00:00:00Z",
        }
        with patch.object(wallet._client, "post", return_value=mock_response(200, body)):
            result = wallet.withdraw_full(amount=200)

        assert isinstance(result, WithdrawalResult)
        assert result.new_balance_sats == 750

    def test_withdraw_insufficient_balance(self):
        wallet = make_wallet()
        body = {
            "error": "Insufficient balance",
            "balance_sats": 50,
            "required_sats": 200,
            "shortfall_sats": 150,
        }
        with patch.object(wallet._client, "post", return_value=mock_response(402, body)):
            with pytest.raises(InsufficientBalance):
                wallet.withdraw(amount=200)


class TestTransactions:
    def test_transactions_list(self):
        wallet = make_wallet()
        body = {
            "wallet_id": "w_abc",
            "transactions": [
                {
                    "id": "1",
                    "direction": "out",
                    "from_wallet": "w_abc",
                    "to_wallet": "w_xyz",
                    "amount_sats": 50,
                    "fee_sats": 0,
                    "tx_type": "internal",
                    "memo": "hi",
                    "status": "completed",
                    "lightning_invoice": None,
                    "lightning_address": None,
                    "mint_quote_id": None,
                    "created_at": "2025-01-01T00:00:00Z",
                }
            ],
            "total": 1,
            "limit": 20,
            "offset": 0,
        }
        with patch.object(wallet._client, "get", return_value=mock_response(200, body)):
            txs = wallet.transactions(limit=10)

        assert len(txs) == 1
        assert isinstance(txs[0], Transaction)
        assert txs[0].tx_type == "internal"
        assert txs[0].direction == "out"


class TestHealth:
    def test_health_ok(self):
        body = {
            "status": "ok",
            "service": "visionfusen-agent-api",
            "version": "2.0.0",
            "timestamp": "2025-01-01T00:00:00Z",
            "features": ["internal-pay", "lightning-in"],
        }
        with patch("httpx.Client") as MockClient:
            ctx = MockClient.return_value.__enter__.return_value
            ctx.get.return_value = mock_response(200, body)
            info = AgentWallet.health(base_url=BASE_URL)

        assert isinstance(info, HealthInfo)
        assert info.status == "ok"
        assert "internal-pay" in info.features


class TestContextManager:
    def test_context_manager(self):
        with AgentWallet(api_key=FAKE_API_KEY) as w:
            assert isinstance(w, AgentWallet)
        # Should not raise after close


# ── Live API tests (requires real server) ─────────────────────────────────────


@pytest.mark.live
class TestLiveAPI:
    """
    Live integration tests against https://api.visionfusen.org.
    Run with: pytest tests/ -m live -v
    """

    def test_health_live(self):
        info = AgentWallet.health()
        assert info.status == "ok"

    def test_create_and_balance(self):
        wallet = AgentWallet.create(agent_name="sdk-test-live")
        print(f"\nCreated wallet: {wallet._wallet_info.wallet_id}")
        print(f"API key: {wallet.api_key}")
        assert wallet.balance == 0

    def test_create_invoice_live(self):
        wallet = AgentWallet.create(agent_name="sdk-invoice-test")
        invoice = wallet.create_invoice(amount=100)
        assert invoice.bolt11.startswith("lnbc")
        assert invoice.status == "UNPAID"
        print(f"\nInvoice: {invoice.bolt11[:50]}...")
