"""
mintbot.models — Data classes for API responses.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional


@dataclass
class WalletInfo:
    """Returned by AgentWallet.create()."""

    wallet_id: str
    api_key: str
    api_key_prefix: str
    mint_url: str
    balance_sats: int
    agent_name: Optional[str]
    budget_limit_sats: Optional[int]
    warning: str


@dataclass
class BalanceInfo:
    """Returned by wallet.get_balance_info()."""

    wallet_id: str
    agent_name: Optional[str]
    balance_sats: int
    budget_limit_sats: Optional[int]
    created_at: datetime
    last_active: datetime


@dataclass
class Invoice:
    """Returned by wallet.create_invoice()."""

    method: str
    bolt11: str
    quote_id: str
    amount_sats: int
    status: str
    wallet_id: str
    note: str


@dataclass
class PaymentResult:
    """Returned by wallet.pay(), wallet.pay_invoice(), wallet.pay_address()."""

    success: bool
    tx_id: str
    from_wallet: str
    amount_sats: int
    tx_type: str
    status: str
    created_at: datetime
    memo: Optional[str] = None
    to_wallet: Optional[str] = None
    fee_sats: int = 0
    total_debited_sats: int = 0
    lightning_invoice: Optional[str] = None
    lightning_address: Optional[str] = None
    new_balance_sats: int = 0


@dataclass
class WithdrawalResult:
    """Returned by wallet.withdraw()."""

    success: bool
    tx_id: str
    token: str
    amount_sats: int
    wallet_id: str
    new_balance_sats: int
    created_at: datetime


@dataclass
class Transaction:
    """A single transaction record."""

    id: str
    direction: str  # "in" or "out"
    amount_sats: int
    tx_type: str  # "internal", "lightning_in", "lightning_out", "withdraw", "mint"
    status: str   # "completed", "pending", "failed"
    created_at: datetime
    fee_sats: int = 0
    from_wallet: Optional[str] = None
    to_wallet: Optional[str] = None
    memo: Optional[str] = None
    lightning_invoice: Optional[str] = None
    lightning_address: Optional[str] = None
    mint_quote_id: Optional[str] = None


@dataclass
class TransactionList:
    """Returned by wallet.transactions()."""

    wallet_id: str
    transactions: list[Transaction]
    total: int
    limit: int
    offset: int


@dataclass
class HealthInfo:
    """Returned by AgentWallet.health()."""

    status: str
    service: str
    version: str
    timestamp: str
    features: list[str]
