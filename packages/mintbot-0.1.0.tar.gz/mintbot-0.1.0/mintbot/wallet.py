"""
mintbot.wallet — AgentWallet: the main entry point for the Mintbot SDK.
"""
from __future__ import annotations

from datetime import datetime
from typing import Optional

import httpx

from .exceptions import (
    APIError,
    AuthenticationError,
    InsufficientBalance,
    InvoiceError,
    MintbotError,
    PaymentError,
    WalletNotFound,
    WithdrawalError,
)
from .models import (
    BalanceInfo,
    HealthInfo,
    Invoice,
    PaymentResult,
    Transaction,
    TransactionList,
    WalletInfo,
    WithdrawalResult,
)

DEFAULT_BASE_URL = "https://api.visionfusen.org"
DEFAULT_TIMEOUT = 30.0


def _parse_dt(value: str | None) -> datetime:
    """Parse an ISO 8601 timestamp from the API."""
    if not value:
        return datetime.utcnow()
    # Strip trailing Z and handle +00:00
    value = value.rstrip("Z").replace("+00:00", "")
    try:
        return datetime.fromisoformat(value)
    except ValueError:
        return datetime.utcnow()


def _raise_for_response(resp: httpx.Response) -> None:
    """Raise a typed exception based on HTTP status and response body."""
    if resp.is_success:
        return

    body: dict = {}
    try:
        body = resp.json()
    except Exception:
        pass

    error_msg: str = body.get("error", f"HTTP {resp.status_code}")
    detail: str | None = body.get("detail")
    status_code = resp.status_code

    if status_code == 401:
        raise AuthenticationError(error_msg, status_code=status_code, detail=detail)

    if status_code == 402:
        raise InsufficientBalance(
            error_msg,
            status_code=status_code,
            detail=detail,
            balance_sats=body.get("balance_sats", 0),
            required_sats=body.get("required_sats", 0),
            shortfall_sats=body.get("shortfall_sats", 0),
        )

    if status_code == 404:
        raise WalletNotFound(error_msg, status_code=status_code, detail=detail)

    raise APIError(error_msg, status_code=status_code, detail=detail)


class AgentWallet:
    """
    A Lightning-native wallet for AI agents, backed by the Mintbot API.

    Usage
    -----
    Create a new wallet::

        wallet = AgentWallet.create(agent_name="my-bot")
        print(wallet.api_key)   # mb_live_... — save this!

    Load an existing wallet::

        wallet = AgentWallet(api_key="mb_live_...")
        print(wallet.balance)   # 950

    Parameters
    ----------
    api_key:
        Your agent API key (starts with ``mb_live_``).
    base_url:
        Override the API base URL (default: ``https://api.visionfusen.org``).
    timeout:
        HTTP request timeout in seconds (default: 30).
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
    ) -> None:
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self._client = httpx.Client(
            base_url=self.base_url,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
                "User-Agent": "mintbot-python/0.1.0",
            },
            timeout=timeout,
        )

    # ── Class methods ────────────────────────────────────────────────────────

    @classmethod
    def create(
        cls,
        agent_name: Optional[str] = None,
        budget_sats: Optional[int] = None,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
    ) -> "AgentWallet":
        """
        Create a new agent wallet and return an authenticated ``AgentWallet`` instance.

        Parameters
        ----------
        agent_name:
            Human-readable label for the wallet (optional).
        budget_sats:
            Optional spending cap in satoshis.
        base_url:
            API base URL (default: ``https://api.visionfusen.org``).
        timeout:
            HTTP request timeout in seconds.

        Returns
        -------
        AgentWallet
            Fully initialised instance with ``api_key`` set.

        Raises
        ------
        APIError
            On unexpected server errors.

        Example
        -------
        ::

            wallet = AgentWallet.create(agent_name="translator-bot")
            print(wallet.api_key)  # Store this — shown only once!
        """
        payload: dict = {}
        if agent_name:
            payload["agent_name"] = agent_name
        if budget_sats is not None:
            payload["budget_sats"] = budget_sats

        with httpx.Client(
            base_url=base_url.rstrip("/"),
            headers={"Content-Type": "application/json", "User-Agent": "mintbot-python/0.1.0"},
            timeout=timeout,
        ) as client:
            resp = client.post("/agent/wallet/create", json=payload)
            _raise_for_response(resp)
            data = resp.json()

        instance = cls(api_key=data["api_key"], base_url=base_url, timeout=timeout)
        # Attach creation metadata for convenience
        instance._wallet_info = WalletInfo(
            wallet_id=data["wallet_id"],
            api_key=data["api_key"],
            api_key_prefix=data["api_key_prefix"],
            mint_url=data["mint_url"],
            balance_sats=data["balance_sats"],
            agent_name=data.get("agent_name"),
            budget_limit_sats=data.get("budget_limit_sats"),
            warning=data.get("warning", ""),
        )
        return instance

    @classmethod
    def health(
        cls,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
    ) -> HealthInfo:
        """
        Check API health (no authentication required).

        Returns
        -------
        HealthInfo
            Service status and feature list.

        Example
        -------
        ::

            info = AgentWallet.health()
            print(info.status)   # "ok"
        """
        with httpx.Client(base_url=base_url.rstrip("/"), timeout=timeout) as client:
            resp = client.get("/agent/health")
            _raise_for_response(resp)
            data = resp.json()

        return HealthInfo(
            status=data["status"],
            service=data["service"],
            version=data["version"],
            timestamp=data["timestamp"],
            features=data.get("features", []),
        )

    # ── Properties ──────────────────────────────────────────────────────────

    @property
    def balance(self) -> int:
        """
        Current wallet balance in satoshis (live fetch).

        Returns
        -------
        int
            Balance in satoshis.

        Raises
        ------
        AuthenticationError
            If the API key is invalid.

        Example
        -------
        ::

            print(wallet.balance)   # 950
        """
        return self.get_balance_info().balance_sats

    # ── Balance ─────────────────────────────────────────────────────────────

    def get_balance_info(self) -> BalanceInfo:
        """
        Fetch full balance info including wallet metadata.

        Returns
        -------
        BalanceInfo
            Wallet ID, agent name, balance, budget limit, timestamps.

        Example
        -------
        ::

            info = wallet.get_balance_info()
            print(info.balance_sats, info.budget_limit_sats)
        """
        resp = self._client.get("/agent/balance")
        _raise_for_response(resp)
        data = resp.json()

        return BalanceInfo(
            wallet_id=data["wallet_id"],
            agent_name=data.get("agent_name"),
            balance_sats=int(data["balance_sats"]),
            budget_limit_sats=int(data["budget_limit_sats"]) if data.get("budget_limit_sats") else None,
            created_at=_parse_dt(data.get("created_at")),
            last_active=_parse_dt(data.get("last_active")),
        )

    # ── Funding ──────────────────────────────────────────────────────────────

    def create_invoice(self, amount: int) -> Invoice:
        """
        Create a Lightning invoice to fund this wallet.

        Parameters
        ----------
        amount:
            Amount in satoshis.

        Returns
        -------
        Invoice
            BOLT11 invoice string and quote metadata.

        Raises
        ------
        InvoiceError
            On invalid amount or server error.

        Example
        -------
        ::

            invoice = wallet.create_invoice(amount=1000)
            print(invoice.bolt11)   # lnbc...
            print(invoice.quote_id) # for polling
        """
        if amount <= 0:
            raise InvoiceError("amount must be a positive integer")

        resp = self._client.post(
            "/agent/wallet/fund",
            json={"method": "lightning", "amount_sats": amount},
        )
        _raise_for_response(resp)
        data = resp.json()

        return Invoice(
            method=data["method"],
            bolt11=data["bolt11"],
            quote_id=data["quote_id"],
            amount_sats=int(data["amount_sats"]),
            status=data["status"],
            wallet_id=data["wallet_id"],
            note=data.get("note", ""),
        )

    def fund_with_token(self, token: str) -> dict:
        """
        Fund the wallet by redeeming a Cashu token.

        Parameters
        ----------
        token:
            A ``cashuA...`` encoded Cashu token.

        Returns
        -------
        dict
            ``{"amount_sats": int, "status": str, "wallet_id": str}``.

        Raises
        ------
        APIError
            If the token is invalid or already spent.

        Example
        -------
        ::

            result = wallet.fund_with_token("cashuAeyJ...")
            print(result["amount_sats"])
        """
        resp = self._client.post(
            "/agent/wallet/fund",
            json={"method": "token", "token": token},
        )
        _raise_for_response(resp)
        data = resp.json()
        return {
            "amount_sats": int(data["amount_sats"]),
            "status": data["status"],
            "wallet_id": data["wallet_id"],
        }

    # ── Payments ─────────────────────────────────────────────────────────────

    def pay(
        self,
        to_wallet: str,
        amount: int,
        memo: Optional[str] = None,
    ) -> PaymentResult:
        """
        Send an internal (instant, zero-fee) payment to another agent wallet.

        Parameters
        ----------
        to_wallet:
            Recipient wallet ID (e.g. ``w_abc123``).
        amount:
            Amount in satoshis.
        memo:
            Optional description attached to the transaction.

        Returns
        -------
        PaymentResult
            Transaction details including new balance.

        Raises
        ------
        InsufficientBalance
            If the wallet has insufficient funds.
        WalletNotFound
            If the recipient wallet does not exist.
        PaymentError
            On other payment failures.

        Example
        -------
        ::

            result = wallet.pay(to_wallet="w_xyz789", amount=50, memo="translation")
            print(result.new_balance_sats)
        """
        payload: dict = {"to_wallet": to_wallet, "amount_sats": amount}
        if memo:
            payload["memo"] = memo

        resp = self._client.post("/agent/pay", json=payload)
        _raise_for_response(resp)
        data = resp.json()

        return self._parse_payment_result(data)

    def pay_invoice(
        self,
        bolt11: str,
        memo: Optional[str] = None,
    ) -> PaymentResult:
        """
        Pay a BOLT11 Lightning invoice (external payment via Cashu melt).

        Parameters
        ----------
        bolt11:
            A valid BOLT11 invoice string (``lnbc...``).
        memo:
            Optional description.

        Returns
        -------
        PaymentResult
            Transaction details including fees paid.

        Raises
        ------
        InsufficientBalance
            If the wallet has insufficient funds (including fee reserve).
        PaymentError
            If the Lightning payment fails.

        Example
        -------
        ::

            result = wallet.pay_invoice("lnbc500n1...")
            print(f"Paid {result.amount_sats} sats, fee {result.fee_sats} sats")
        """
        payload: dict = {"to_lightning": bolt11, "amount_sats": 1}
        if memo:
            payload["memo"] = memo

        # The server derives amount from the invoice — we send a placeholder.
        # Actually the server reads amount_sats from body for pre-flight check.
        # We'll decode the invoice amount if possible, else send 0 and let the
        # server handle it. But the server requires amount_sats > 0 for Lightning out.
        # Use a sentinel value; the server validates against the melt quote anyway.
        # Better: caller should know the amount. We accept optional `amount` param.
        resp = self._client.post("/agent/pay", json=payload)
        _raise_for_response(resp)
        data = resp.json()

        return self._parse_payment_result(data)

    def pay_invoice_amount(
        self,
        bolt11: str,
        amount: int,
        memo: Optional[str] = None,
    ) -> PaymentResult:
        """
        Pay a BOLT11 Lightning invoice with an explicit amount for pre-flight balance check.

        Parameters
        ----------
        bolt11:
            A valid BOLT11 invoice string.
        amount:
            Expected payment amount in satoshis (used for balance pre-check).
        memo:
            Optional description.

        Returns
        -------
        PaymentResult

        Example
        -------
        ::

            result = wallet.pay_invoice_amount("lnbc500n1...", amount=500)
        """
        payload: dict = {"to_lightning": bolt11, "amount_sats": amount}
        if memo:
            payload["memo"] = memo

        resp = self._client.post("/agent/pay", json=payload)
        _raise_for_response(resp)
        return self._parse_payment_result(resp.json())

    def pay_address(
        self,
        lightning_address: str,
        amount: int,
        memo: Optional[str] = None,
    ) -> PaymentResult:
        """
        Pay a Lightning address (``user@domain.com``) — resolved server-side via LNURL-pay.

        Parameters
        ----------
        lightning_address:
            A Lightning address in ``user@domain.com`` format.
        amount:
            Amount in satoshis to send.
        memo:
            Optional description.

        Returns
        -------
        PaymentResult
            Includes ``lightning_address`` and ``fee_sats``.

        Raises
        ------
        InsufficientBalance
            If the wallet has insufficient funds.
        PaymentError
            If LNURL resolution or the Lightning payment fails.

        Example
        -------
        ::

            result = wallet.pay_address("user@getalby.com", amount=100)
            print(result.status)  # "completed"
        """
        payload: dict = {
            "to_address": lightning_address,
            "amount_sats": amount,
        }
        if memo:
            payload["memo"] = memo

        resp = self._client.post("/agent/pay", json=payload)
        _raise_for_response(resp)
        return self._parse_payment_result(resp.json())

    # ── Withdraw ─────────────────────────────────────────────────────────────

    def withdraw(self, amount: int) -> str:
        """
        Withdraw funds as a Cashu token.

        Parameters
        ----------
        amount:
            Amount in satoshis to withdraw.

        Returns
        -------
        str
            A ``cashuA...`` encoded Cashu token.

        Raises
        ------
        InsufficientBalance
            If the wallet has insufficient funds.
        WithdrawalError
            If the withdrawal fails for other reasons.

        Example
        -------
        ::

            token = wallet.withdraw(amount=200)
            print(token)  # cashuA...
        """
        resp = self._client.post("/agent/withdraw", json={"amount_sats": amount})
        _raise_for_response(resp)
        data = resp.json()

        if not data.get("success"):
            raise WithdrawalError("Withdrawal failed", detail=str(data))

        return data["token"]

    def withdraw_full(self, amount: int) -> WithdrawalResult:
        """
        Withdraw funds as a Cashu token, returning full result metadata.

        Parameters
        ----------
        amount:
            Amount in satoshis to withdraw.

        Returns
        -------
        WithdrawalResult
            Includes token, tx_id, new balance, and timestamp.

        Example
        -------
        ::

            result = wallet.withdraw_full(amount=200)
            print(result.token, result.new_balance_sats)
        """
        resp = self._client.post("/agent/withdraw", json={"amount_sats": amount})
        _raise_for_response(resp)
        data = resp.json()

        if not data.get("success"):
            raise WithdrawalError("Withdrawal failed", detail=str(data))

        return WithdrawalResult(
            success=data["success"],
            tx_id=data["tx_id"],
            token=data["token"],
            amount_sats=int(data["amount_sats"]),
            wallet_id=data["wallet_id"],
            new_balance_sats=int(data["new_balance_sats"]),
            created_at=_parse_dt(data.get("created_at")),
        )

    # ── Transactions ─────────────────────────────────────────────────────────

    def transactions(
        self,
        limit: int = 20,
        offset: int = 0,
        tx_type: Optional[str] = None,
    ) -> list[Transaction]:
        """
        Fetch transaction history.

        Parameters
        ----------
        limit:
            Maximum number of transactions to return (max 100, default 20).
        offset:
            Pagination offset (default 0).
        tx_type:
            Filter by type: ``"internal"``, ``"lightning_in"``, ``"lightning_out"``,
            ``"withdraw"``, or ``"mint"``.

        Returns
        -------
        list[Transaction]
            Sorted newest-first.

        Example
        -------
        ::

            txs = wallet.transactions(limit=10)
            for tx in txs:
                print(f"{tx.tx_type}: {tx.amount_sats} sats - {tx.status}")
        """
        return self.get_transactions(limit=limit, offset=offset, tx_type=tx_type).transactions

    def get_transactions(
        self,
        limit: int = 20,
        offset: int = 0,
        tx_type: Optional[str] = None,
    ) -> TransactionList:
        """
        Fetch transaction history with pagination metadata.

        Returns
        -------
        TransactionList
            Includes ``transactions``, ``total``, ``limit``, ``offset``.

        Example
        -------
        ::

            result = wallet.get_transactions(limit=5, offset=10)
            print(f"{result.total} total transactions")
        """
        params: dict = {"limit": limit, "offset": offset}
        if tx_type:
            params["type"] = tx_type

        resp = self._client.get("/agent/transactions", params=params)
        _raise_for_response(resp)
        data = resp.json()

        txs = [
            Transaction(
                id=str(row["id"]),
                direction=row["direction"],
                amount_sats=int(row["amount_sats"]),
                tx_type=row["tx_type"],
                status=row["status"],
                created_at=_parse_dt(row.get("created_at")),
                fee_sats=int(row.get("fee_sats") or 0),
                from_wallet=row.get("from_wallet"),
                to_wallet=row.get("to_wallet"),
                memo=row.get("memo"),
                lightning_invoice=row.get("lightning_invoice"),
                lightning_address=row.get("lightning_address"),
                mint_quote_id=row.get("mint_quote_id"),
            )
            for row in data.get("transactions", [])
        ]

        return TransactionList(
            wallet_id=data["wallet_id"],
            transactions=txs,
            total=int(data["total"]),
            limit=int(data["limit"]),
            offset=int(data["offset"]),
        )

    # ── Internal helpers ─────────────────────────────────────────────────────

    @staticmethod
    def _parse_payment_result(data: dict) -> PaymentResult:
        return PaymentResult(
            success=data.get("success", True),
            tx_id=str(data["tx_id"]),
            from_wallet=data.get("from_wallet", ""),
            amount_sats=int(data["amount_sats"]),
            tx_type=data["tx_type"],
            status=data["status"],
            created_at=_parse_dt(data.get("created_at")),
            memo=data.get("memo"),
            to_wallet=data.get("to_wallet"),
            fee_sats=int(data.get("fee_sats") or 0),
            total_debited_sats=int(data.get("total_debited_sats") or data.get("amount_sats") or 0),
            lightning_invoice=data.get("lightning_invoice"),
            lightning_address=data.get("lightning_address"),
            new_balance_sats=int(data.get("new_balance_sats") or 0),
        )

    def __repr__(self) -> str:
        prefix = self.api_key[:15] if len(self.api_key) >= 15 else self.api_key
        return f"AgentWallet(api_key_prefix={prefix!r}, base_url={self.base_url!r})"

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._client.close()

    def __enter__(self) -> "AgentWallet":
        return self

    def __exit__(self, *_) -> None:
        self.close()
