"""
mintbot — Python SDK for Mintbot Agent Pay.

Quick start::

    from mintbot import AgentWallet

    # Create a new wallet
    wallet = AgentWallet.create(agent_name="my-bot")
    print(wallet.api_key)  # mb_live_... — save this!

    # Load existing wallet
    wallet = AgentWallet(api_key="mb_live_...")
    print(wallet.balance)  # 950

See https://mintbot.cash for full documentation.
"""
from .wallet import AgentWallet
from .models import (
    BalanceInfo,
    HealthInfo,
    Invoice,
    PaymentResult,
    Transaction,
    TransactionList,
    WalletInfo,
    WithdrawalResult,
)
from .exceptions import (
    MintbotError,
    AuthenticationError,
    InsufficientBalance,
    WalletNotFound,
    PaymentError,
    InvoiceError,
    WithdrawalError,
    APIError,
)

__version__ = "0.1.0"
__all__ = [
    "AgentWallet",
    # Models
    "BalanceInfo",
    "HealthInfo",
    "Invoice",
    "PaymentResult",
    "Transaction",
    "TransactionList",
    "WalletInfo",
    "WithdrawalResult",
    # Exceptions
    "MintbotError",
    "AuthenticationError",
    "InsufficientBalance",
    "WalletNotFound",
    "PaymentError",
    "InvoiceError",
    "WithdrawalError",
    "APIError",
]
