"""
mintbot.exceptions — Custom exceptions for the Mintbot SDK.
"""


class MintbotError(Exception):
    """Base exception for all Mintbot errors."""

    def __init__(self, message: str, status_code: int | None = None, detail: str | None = None):
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.detail = detail

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}({self.message!r})"


class AuthenticationError(MintbotError):
    """Raised when the API key is invalid or missing."""


class InsufficientBalance(MintbotError):
    """Raised when the wallet does not have enough funds."""

    def __init__(
        self,
        message: str,
        balance_sats: int = 0,
        required_sats: int = 0,
        shortfall_sats: int = 0,
        **kwargs,
    ):
        super().__init__(message, **kwargs)
        self.balance_sats = balance_sats
        self.required_sats = required_sats
        self.shortfall_sats = shortfall_sats


class WalletNotFound(MintbotError):
    """Raised when a wallet ID cannot be found."""


class PaymentError(MintbotError):
    """Raised when a payment fails."""


class InvoiceError(MintbotError):
    """Raised when invoice creation or resolution fails."""


class WithdrawalError(MintbotError):
    """Raised when a Cashu token withdrawal fails."""


class APIError(MintbotError):
    """Generic API error for unexpected responses."""
