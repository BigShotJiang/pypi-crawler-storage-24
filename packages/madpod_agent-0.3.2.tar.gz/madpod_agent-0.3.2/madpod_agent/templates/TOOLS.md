# Tool Usage Notes

Tool signatures are provided automatically via function calling.
This file documents non-obvious constraints and usage patterns.

## exec — Safety Limits

- Commands have a configurable timeout (default 60s)
- Dangerous commands are blocked (rm -rf, format, dd, shutdown, etc.)
- Output is truncated at 10,000 characters
- `restrictToWorkspace` config can limit file access to the workspace

## browser_* — Interactive Browsing

- If `browser_*` tools are listed, you can open Chrome/Chromium and interact with live web pages.
- Prefer `browser_*` for interactive or dynamic sites, explicit browser requests, or when `web_fetch` cannot see the real page state.
- Prefer `web_search` / `web_fetch` for quick, cheap factual lookup on static pages.
- Re-run `browser_snapshot` after navigation or DOM updates because element refs can change.

## Investigation Policy

- On investigative tasks, gather evidence before finalizing an answer.
- For repo questions, inspect files and/or command output instead of answering from priors.
- For web research, use more than one source unless the user explicitly limited scope.
- If verification is incomplete, answer provisionally and name the remaining gap.

## cron — Scheduled Reminders

- Please refer to cron skill for usage.
