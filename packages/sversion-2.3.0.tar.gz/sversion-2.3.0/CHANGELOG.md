# Changelog

> The changelog **must** comply to the [keep a changelog](https://keepachangelog.com/en/1.1.0) standard.

## 2.3.0 - 2026-03-21

_*Added*_

- uv support for pyproject_toml_based get_version method

## 2.2.1 - 2026-03-08

_*Added*_

- get_version method that works with pyproject.toml file


## 2.1.0 - 2025-04-29

_*Changed*_

- Project dependency and build system to poetry

## 2.0.0 - 2025-02-20

_*Changed*_

- File-based get_version method to use location to start search of version file from as a parameter


## 1.0.0 - 2025-02-20

_*Added*_

- First version of sversion
