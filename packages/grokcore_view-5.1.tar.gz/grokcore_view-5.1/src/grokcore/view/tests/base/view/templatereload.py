"""
Filesystem-based templates, once grokked, can be changed.  The change
will automatically be picked up, reloading Zope is not necessary.

  >>> grok.testing.grok(__name__)
  >>> from zope.component import getMultiAdapter
  >>> from zope.publisher.browser import TestRequest
  >>> request = TestRequest()
  >>> view = getMultiAdapter((Mammoth(), request), name='index')
  >>> print(view())
  before

Now we change the file:

  >>> import os.path
  >>> here = os.path.dirname(__file__)
  >>> template_file = os.path.join(
  ...     here, 'templatereload_templates', 'index.pt')
  >>> with open(template_file, 'w') as template:
  ...     dummy = template.write('after')

and find that the output of the view has changed as well:

  >>> print(view())
  after

At last, we should change everything back to normal:

  >>> template = open(template_file, 'w')
  >>> dummy = template.write('before')
  >>> template.close()
"""
import grokcore.view as grok


class Mammoth(grok.Context):
    pass


class Index(grok.View):
    pass
