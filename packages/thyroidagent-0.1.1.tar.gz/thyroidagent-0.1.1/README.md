# ThyroidAgent

ThyroidAgent is a PyTorch-based library that provides DINOv3 + UNet models for thyroid ultrasound image analysis, including both single-task segmentation and multi-task learning (segmentation + malignancy classification + TIRADS).

## Features

- **DINOv3_S_UNet**: single-task tumor segmentation.
- **DINOv3_S_UNet_MULTITASK**: joint segmentation, malignancy classification, and TIRADS prediction.
- **Dataset utilities**: `FullDataset` and `MultiTaskDataset` for training/validation pipelines.
- **Metrics and loss**: ready-to-use evaluation metrics and loss functions for medical image segmentation and multi-task learning.

## Installation

From PyPI (after you publish):

pip install ThyroidAgent
