"""
Model inference test script for DINOv3_S_UNet.
Run: python -m thyroid_agent.tests.test_parallel --checkpoint <path> --test_image_paths <dir> --test_gt_paths <dir>
"""
import argparse
import os
import sys
import torch
import numpy as np
import time
from datetime import datetime
from PIL import Image
from tqdm import tqdm
from torch.utils.data import DataLoader
from torchvision import transforms

from thyroid_agent.models.dino_unet import DINOv3_S_UNet
from thyroid_agent.models import FullDataset
from thyroid_agent.utils.metrics import evaluate_model

try:
    import imageio
except ImportError:
    imageio = None


class Logger(object):
    def __init__(self, filename):
        self.terminal = sys.stdout
        self.log = open(filename, "w")

    def write(self, message):
        self.terminal.write(message)
        if self.log is not None:
            self.log.write(message)

    def flush(self):
        self.terminal.flush()
        if self.log is not None:
            self.log.flush()

    def close(self):
        if self.log is not None:
            self.log.close()
            self.log = None


def clean_path(path):
    """Clean path by removing extra quotes and whitespace."""
    if isinstance(path, str):
        if (path.startswith('"') and path.endswith('"')) or \
           (path.startswith("'") and path.endswith("'")):
            path = path[1:-1]
        path = path.strip()
    return path


def _empty_results():
    return {'Dice': {'mean': 0.0, 'CI95': (0.0, 0.0)}, 'HD95': {'mean': 0.0, 'CI95': (0.0, 0.0)}}


def process_dataset(checkpoint, image_path, gt_path, save_base_path, dataset_name, device, save_results,
                    target_size=224, dino_pretrained=True, save_orig_size=False):
    save_path = os.path.join(save_base_path, dataset_name)
    if save_results.lower() == "true":
        os.makedirs(save_path, exist_ok=True)

    image_path = clean_path(image_path)
    gt_path = clean_path(gt_path)

    print(f"Processing dataset: {dataset_name}")
    print(f"Image path: {image_path}")
    print(f"GT path: {gt_path}")
    print(f"Save path: {save_path}")

    if not os.path.exists(image_path):
        print(f"Error: Image directory does not exist: {image_path}")
        return _empty_results()

    if not os.path.exists(gt_path):
        print(f"Error: Mask directory does not exist: {gt_path}")
        return _empty_results()

    try:
        image_files = os.listdir(image_path)
        mask_files = os.listdir(gt_path)
        print(f"Found {len(image_files)} files in image directory")
        print(f"Found {len(mask_files)} files in mask directory")
    except Exception as e:
        print(f"Error listing directory contents: {e}")

    print("Loading model...")
    model = DINOv3_S_UNet(pretrained=dino_pretrained).to(device)
    try:
        checkpoint_dict = torch.load(checkpoint, map_location=device, weights_only=True)
        model.load_state_dict(checkpoint_dict, strict=False)
        print(f"Successfully loaded checkpoint from {checkpoint}")
    except Exception as e:
        print(f"Error loading checkpoint: {e}")
        return _empty_results()

    print(f"Loading dataset with FullDataset using size: {target_size}x{target_size}")
    test_dataset = FullDataset(image_path, gt_path, target_size, mode='val')

    if len(test_dataset) == 0:
        print(f"Error: Test dataset {dataset_name} is empty!")
        return _empty_results()

    test_loader = DataLoader(test_dataset, shuffle=False, batch_size=1, num_workers=8)
    print(f"Dataset loaded: {len(test_dataset)} images found")

    print(f"Calculating evaluation metrics for dataset: {dataset_name}")
    results = evaluate_model(model, test_loader, device)
    dice_mean = results.get('Dice', {}).get('mean', 0.0)
    dice_ci95 = results.get('Dice', {}).get('CI95', (0.0, 0.0))
    hd95_mean = results.get('HD95', {}).get('mean', 0.0)
    hd95_ci95 = results.get('HD95', {}).get('CI95', (0.0, 0.0))
    print(f"Dice Mean: {dice_mean:.4f}, Dice CI95: ({dice_ci95[0]:.4f}, {dice_ci95[1]:.4f})")
    print(f"HD95 Mean: {hd95_mean:.4f}, HD95 CI95: ({hd95_ci95[0]:.4f}, {hd95_ci95[1]:.4f})")

    if save_results.lower() == "true":
        if imageio is None:
            print("Warning: imageio not installed, skipping prediction save.")
        else:
            model.eval()
            for i, batch in enumerate(tqdm(test_loader, desc='Saving predictions', unit='image')):
                with torch.no_grad():
                    image = batch['image'].to(device=device)
                    name = batch.get('filename', [f'image_{i}'])[0]

                    res = model(image)
                    if type(res) == type([]):
                        res = res[0]

                    res_sigmoid = res.sigmoid().data.cpu()
                    res_np = res_sigmoid.numpy().squeeze()
                    res_normalized = (res_np - res_np.min()) / (res_np.max() - res_np.min() + 1e-8)
                    res_uint8 = (res_normalized * 255).astype(np.uint8)

                    if save_orig_size:
                        try:
                            orig_size = batch.get('orig_size', None)
                            w, h = orig_size[0], orig_size[1]
                            if (res_uint8.shape[1], res_uint8.shape[0]) != (w, h):
                                res_uint8 = np.array(
                                    Image.fromarray(res_uint8).resize((w, h), resample=Image.NEAREST)
                                ).astype(np.uint8)
                        except Exception as e:
                            print(f"Warning: Failed to resize {name} to orig_size: {e}")

                    try:
                        imageio.imsave(os.path.join(save_path, name), res_uint8)
                    except Exception as e:
                        print(f"Error saving prediction for {name}: {e}")
    print(f"Dataset {dataset_name} processing completed.")

    return results


def main():
    parser = argparse.ArgumentParser("DINOV3-UNet Test")
    parser.add_argument("--checkpoint", "--checkpoint_path", type=str, required=True,
                        help="path to the checkpoint of dino_unet")
    parser.add_argument('--test_image_paths', '--image_paths', type=str, action='append', default=[],
                        help='paths to the test image directories (can be used multiple times)')
    parser.add_argument('--test_gt_paths', '--gt_paths', '--test_mask_paths', type=str, action='append', default=[],
                        help='paths to the test mask directories (can be used multiple times)')
    parser.add_argument('--test_dataset_names', '--dataset_names', type=str, action='append', default=[],
                        help='names of the test datasets (can be used multiple times)')
    parser.add_argument("--save_path", type=str, default="./predictions",
                        help="base path to save the predicted masks")
    parser.add_argument("--save_results", type=str, default="true",
                        help="Whether to save prediction results (true/false)")
    parser.add_argument("--img_size", type=int, default=224,
                        help="input image size for dataset (default: 224)")
    parser.add_argument('--dino_pretrained', type=str, default='True',
                        help='whether to load pretrained weights for the DINO backbone (True/False)')
    parser.add_argument("--save_orig_size", type=str, default="false",
                        help="Whether to resize predicted masks back to original image size before saving (true/false).")
    parser.add_argument("--device", type=str, default=None,
                        help="Device to use: 'cuda', 'cuda:0', 'cuda:1', 'cpu'. Overrides default when set.")
    parser.add_argument("--log_dir", type=str, default="./logs",
                        help="Directory to save log files")
    args = parser.parse_args()
    args.dino_pretrained = str(args.dino_pretrained).lower() in ('true', '1', 'yes', 'y')
    args.save_orig_size = str(args.save_orig_size).lower() in ('true', '1', 'yes', 'y')

    os.makedirs(args.log_dir, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_file = os.path.join(args.log_dir, f"test_{timestamp}.log")
    sys.stdout = Logger(log_file)

    if args.device is not None:
        device = torch.device(args.device)
    else:
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}")
    print(f"Image size: {args.img_size} x {args.img_size}")
    print(f"DINO pretrained: {args.dino_pretrained}")
    print(f"DINO Dilation: False")
    print(f"Save pred masks in orig size: {args.save_orig_size}")
    print(f"Checkpoint path: {args.checkpoint}")
    print(f"Save path: {args.save_path}")
    print(f"Save results: {args.save_results}")
    print(f"Test dataset names: {args.test_dataset_names}")

    if not args.test_image_paths or not args.test_gt_paths:
        print("Error: No test datasets provided. Please use --test_image_paths and --test_gt_paths arguments.")
        return

    args.test_image_paths = [clean_path(path) for path in args.test_image_paths]
    args.test_gt_paths = [clean_path(path) for path in args.test_gt_paths]

    print(f"Number of test image paths: {len(args.test_image_paths) if args.test_image_paths else 0}")
    if args.test_image_paths:
        print(f"Test image paths: {args.test_image_paths}")
        for i, path in enumerate(args.test_image_paths):
            print(f"Image path {i+1} {'exists' if os.path.exists(path) else 'does not exist'}: {path}")
    print(f"Number of test ground truth paths: {len(args.test_gt_paths) if args.test_gt_paths else 0}")
    if args.test_gt_paths:
        print(f"Test ground truth paths: {args.test_gt_paths}")
        for i, path in enumerate(args.test_gt_paths):
            print(f"GT path {i+1} {'exists' if os.path.exists(path) else 'does not exist'}: {path}")

    if len(args.test_image_paths) != len(args.test_gt_paths):
        print(f"Warning: Number of test image paths ({len(args.test_image_paths)}) and mask paths ({len(args.test_gt_paths)}) do not match.")
        min_len = min(len(args.test_image_paths), len(args.test_gt_paths))
        args.test_image_paths = args.test_image_paths[:min_len]
        args.test_gt_paths = args.test_gt_paths[:min_len]

    os.makedirs(args.save_path, exist_ok=True)
    print(f"Created base save directory: {args.save_path}")

    all_metrics = []
    start_time = time.time()
    for i, (img_path, gt_path) in enumerate(zip(args.test_image_paths, args.test_gt_paths)):
        dataset_name = (args.test_dataset_names[i] if i < len(args.test_dataset_names) and args.test_dataset_names[i]
                       else f"Test_Set_{i+1}")
        print(f"\nProcessing dataset {i+1}/{len(args.test_image_paths)}")
        result = process_dataset(
            args.checkpoint, img_path, gt_path, args.save_path, dataset_name, device,
            args.save_results, args.img_size, args.dino_pretrained, args.save_orig_size,
        )
        all_metrics.append((dataset_name, result))

    total_time = time.time() - start_time
    print(f"All datasets processed in {total_time:.2f} seconds")

    print("\n===== Summary of All Datasets =====")
    for dataset_name, result in all_metrics:
        dice_mean = result.get('Dice', {}).get('mean', 0.0)
        dice_ci95 = result.get('Dice', {}).get('CI95', (0.0, 0.0))
        hd95_mean = result.get('HD95', {}).get('mean', 0.0)
        hd95_ci95 = result.get('HD95', {}).get('CI95', (0.0, 0.0))
        print(f"Dataset: {dataset_name}")
        print(f"  Dice Mean: {dice_mean:.4f}  CI95: ({dice_ci95[0]:.4f}, {dice_ci95[1]:.4f})")
        print(f"  HD95 Mean: {hd95_mean:.4f}  CI95: ({hd95_ci95[0]:.4f}, {hd95_ci95[1]:.4f})")

    print("\nAll datasets processing completed successfully!")
    print(f"Log file location: {log_file}")
    try:
        if hasattr(sys.stdout, 'close'):
            sys.stdout.close()
    except Exception:
        pass


if __name__ == "__main__":
    main()
