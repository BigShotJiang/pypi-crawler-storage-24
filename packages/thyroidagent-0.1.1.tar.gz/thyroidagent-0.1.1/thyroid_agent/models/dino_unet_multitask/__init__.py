"""DINOv3 + UNet 多任务模型（分割 + 恶性分类 + TIRADS 分类）."""
from .dino_unet_multitask import DINOv3_S_UNet_MULTITASK

__all__ = ["DINOv3_S_UNet_MULTITASK"]
