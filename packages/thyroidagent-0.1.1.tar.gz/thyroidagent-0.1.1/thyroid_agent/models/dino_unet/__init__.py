"""DINOv3 + UNet 单任务分割模型."""
from .dino_unet import DINOv3_S_UNet

__all__ = ["DINOv3_S_UNet"]
