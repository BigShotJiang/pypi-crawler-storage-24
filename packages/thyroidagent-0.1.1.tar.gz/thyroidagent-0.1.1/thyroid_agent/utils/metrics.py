import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
from scipy.ndimage import distance_transform_edt as edt
from tqdm import tqdm


# =========================
# Dice（逐病例）
# =========================
class Dice(nn.Module):
    """
    Dice coefficient calculator for binary segmentation tasks.
    """
    def __init__(self):
        super(Dice, self).__init__()

    def forward(self, predict, target):
        smooth = 1.0
        intersection = (predict * target).sum()
        dice = (2.0 * intersection + smooth) / (
            predict.sum() + target.sum() + smooth
        )
        return dice


# =========================
# HD95（逐病例）
# =========================
class HD95(nn.Module):
    """
    HD95 calculator for binary segmentation tasks.
    使用距离变换方法计算 Hausdorff Distance (95%)
    """
    def __init__(self):
        super(HD95, self).__init__()

    def forward(self, predict, target):
        return self.calculate_hd(predict, target)

    def calculate_hd(self, predict, target):
        # 确保输入是2D或3D tensor，统一处理
        if predict.dim() == 3:
            # 如果是3D [C, H, W] 或 [H, W, C]，取第一个通道
            if predict.shape[0] == 1 or predict.shape[2] == 1:
                predict = predict.squeeze()
            else:
                predict = predict[0]  # 取第一个通道
        if target.dim() == 3:
            if target.shape[0] == 1 or target.shape[2] == 1:
                target = target.squeeze()
            else:
                target = target[0]
        
        # 确保是2D tensor
        if predict.dim() != 2 or target.dim() != 2:
            raise ValueError(f"Expected 2D tensors, got predict: {predict.shape}, target: {target.shape}")
        
        pred_np = predict.cpu().numpy().astype(bool)
        target_np = target.cpu().numpy().astype(bool)
        
        # 检查空 mask 情况
        pred_empty = not np.any(pred_np)
        target_empty = not np.any(target_np)
        
        # 处理空 mask 的特殊情况
        if pred_empty and target_empty:
            # 两者都为空：定义为0（完全匹配）
            return torch.tensor(0.0, dtype=torch.float32)
        elif pred_empty or target_empty:
            # 一个为空，另一个不为空：返回图像对角线长度（表示最大可能距离）
            if pred_empty:
                print(f"pred_empty: {pred_np.shape}")
            if target_empty:
                print(f"target_empty: {target_np.shape}")
            h, w = pred_np.shape
            max_distance = float(np.sqrt(h * h + w * w))
            return torch.tensor(max_distance, dtype=torch.float32)
                    
        # 两者都不为空：正常计算 Hausdorff Distance
        hd1 = self.hd_distance(pred_np, target_np)
        hd2 = self.hd_distance(target_np, pred_np)

        return torch.tensor(max(hd1, hd2), dtype=torch.float32)

    def hd_distance(self, x: np.ndarray, y: np.ndarray) -> float:
        indexes = np.nonzero(x)
        distances = edt(~y)
        return float(np.percentile(distances[indexes], 95))


# =========================
# Bootstrap CI95（通用）
# =========================
def bootstrap_ci(values, n_boot=5000, ci=0.95, seed=0):
    """
    基于逐病例指标计算 mean 和 CI95（bootstrap）
    """
    values = np.asarray(values, dtype=np.float32)
    values = values[~np.isnan(values)]
    n = len(values)

    if n == 0:
        return 0.0, (0.0, 0.0)

    rng = np.random.default_rng(seed)
    boot_means = []

    for _ in range(n_boot):
        sample = rng.choice(values, size=n, replace=True)
        boot_means.append(sample.mean())

    boot_means = np.array(boot_means)
    alpha = 1.0 - ci
    lower = np.percentile(boot_means, 100 * alpha / 2)
    upper = np.percentile(boot_means, 100 * (1 - alpha / 2))

    return values.mean(), (lower, upper)


# =========================
# 模型评估（逐病例 + CI95）
# =========================
def evaluate_model(net, dataloader, device):
    """
    Evaluate segmentation model with:
    - Dice (per-case)
    - HD95 (per-case)
    - CI95 for both metrics (bootstrap)

    Returns:
        dict with mean + CI95
    """
    net.eval()

    dice_calculator = Dice()
    hd_calculator = HD95()

    all_dice_values = []
    all_hd_values = []

    for batch in tqdm(dataloader, desc="Evaluating Model", leave=False):
        # 兼容不同 batch 格式
        if isinstance(batch, dict):
            image = batch["image"]
            mask_true = batch["label"]
        else:
            image, mask_true = batch

        image = image.to(device)
        mask_true = mask_true.to(device)

        with torch.no_grad():
            mask_pred = net(image)
            if isinstance(mask_pred, (list, tuple)):
                mask_pred = mask_pred[0]

            mask_pred = torch.sigmoid(mask_pred)
            mask_pred_binary = (mask_pred > 0.5).float()

        batch_size = image.size(0)

        # =========================
        # 逐病例计算 Dice / HD95
        # =========================
        for i in range(batch_size):
            pred_i = mask_pred_binary[i]
            true_i = (mask_true[i] > 0.5).float()

            # Dice
            dice_i = dice_calculator(pred_i, true_i).item()
            all_dice_values.append(dice_i)

            # HD95
            try:
                hd_i = hd_calculator(pred_i, true_i).item()
                all_hd_values.append(hd_i)
            except Exception as e:
                print(f"[Warning] HD95 failed on sample {i}: {e}")

    net.train()

    # =========================
    # 计算 mean + CI95
    # =========================
    dice_mean, dice_ci95 = bootstrap_ci(all_dice_values)
    hd95_mean, hd95_ci95 = bootstrap_ci(all_hd_values)

    # 将逐病例值也保留到 4 位小数，便于后续输出一致性
    rounded_dice_values = [round(float(v), 4) for v in all_dice_values]
    rounded_hd_values = [round(float(v), 4) for v in all_hd_values]

    results = {
        "Dice": {
            "mean": round(dice_mean, 4),
            "CI95": (round(dice_ci95[0], 4), round(dice_ci95[1], 4)),
            "values": rounded_dice_values,
        },
        "HD95": {
            "mean": round(hd95_mean, 4),
            "CI95": (round(hd95_ci95[0], 4), round(hd95_ci95[1], 4)),
            "values": rounded_hd_values,
        },
    }

    return results
