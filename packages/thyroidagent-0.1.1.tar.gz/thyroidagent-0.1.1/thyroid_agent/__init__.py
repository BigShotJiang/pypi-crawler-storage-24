"""
ThyroidAgent (thyroid_agent): DINOv3 + UNet 甲状腺分割与多任务模型库

可直接使用：
  - DINOv3_S_UNet: 单任务分割
  - DINOv3_S_UNet_MULTITASK: 多任务（分割 + 恶性分类 + TIRADS）
  - FullDataset / MultiTaskDataset: 数据加载
"""


from .models import (
    DINOv3_S_UNet,
    DINOv3_S_UNet_MULTITASK,
    FullDataset,
    MultiTaskDataset,
    Normalize,
    Resize,
    RandomHorizontalFlip,
    RandomVerticalFlip,
    ToTensor,
)

__version__ = "0.1.0"

__all__ = [
    "DINOv3_S_UNet",
    "DINOv3_S_UNet_MULTITASK",
    "FullDataset",
    "MultiTaskDataset",
    "ToTensor",
    "Resize",
    "RandomHorizontalFlip",
    "RandomVerticalFlip",
    "Normalize",
]
