"""
Bash Tool — Execute shell commands.

Safety model:
    - Subprocess with timeout (prevents hung commands)
    - Narasimha hypervisor (Gate 2 in AgentLoop._check_tool_gates) audits
      every bash invocation for threats. This is the REAL security boundary.
    - No blocklist theater — pattern matching is trivially bypassed and
      gives false confidence. Narasimha does proper threat analysis.
"""

from __future__ import annotations

import subprocess
from typing import Any

from vibe_core.tools.tool_protocol import Tool, ToolResult


class BashTool(Tool):
    """Execute a bash command and return stdout/stderr.

    Security: Narasimha (Gate 2) audits commands before execution.
    Timeout prevents runaway processes.
    """

    def __init__(self, timeout: int = 120, cwd: str | None = None) -> None:
        super().__init__()
        self._timeout = timeout
        self._cwd = cwd

    @property
    def name(self) -> str:
        return "bash"

    @property
    def description(self) -> str:
        return (
            "Execute a bash command in a shell. Returns stdout and stderr. "
            "Use for running tests, git commands, installing packages, "
            "or any system operation."
        )

    @property
    def parameters_schema(self) -> dict[str, Any]:
        return {
            "command": {
                "type": "string",
                "required": True,
                "description": "The bash command to execute",
            },
            "timeout": {
                "type": "integer",
                "required": False,
                "description": "Timeout in seconds (default: 120). Increase for long builds or tests.",
            },
        }

    def validate(self, parameters: dict[str, Any]) -> None:
        if "command" not in parameters:
            raise ValueError("Missing required parameter: command")
        if not isinstance(parameters["command"], str):
            raise TypeError("command must be a string")
        if not parameters["command"].strip():
            raise ValueError("command must not be empty")

    def execute(self, parameters: dict[str, Any]) -> ToolResult:
        command = parameters["command"]
        timeout = parameters.get("timeout", self._timeout)

        try:
            result = subprocess.run(
                ["bash", "-c", command],
                capture_output=True,
                text=True,
                timeout=timeout,
                cwd=self._cwd,
            )
            output = result.stdout
            if result.stderr:
                output += f"\n[stderr]\n{result.stderr}" if output else result.stderr

            return ToolResult(
                success=result.returncode == 0,
                output=output.strip() if output else "",
                error=f"Exit code: {result.returncode}" if result.returncode != 0 else None,
                metadata={"exit_code": result.returncode},
            )
        except subprocess.TimeoutExpired:
            return ToolResult(success=False, error=f"Command timed out after {timeout}s")
        except Exception as e:
            return ToolResult(success=False, error=str(e))
