# 国防科技大学图书馆专业检索工具

精简后的核心检索工具，保留最核心的登录和检索功能。

## 📁 项目结构

```
library-nudt-mcp/
├── nudt_light_login.py              # 轻量级登录工具（核心）
├── nudt_professional_search.py      # 专业检索 API（核心）
├── quick_search_example.py          # 快速检索示例
├── 国防科技大学图书馆专业检索编码规则.md  # 编码规则文档
├── cache/                           # 缓存目录（自动创建）
│   ├── library_cookies.json         # Cookie 文件
│   └── search_result_*.html         # 检索结果
├── backup/                          # 备份目录（非核心文件）
├── .venv/                           # Python 虚拟环境
└── __pycache__/                     # Python 缓存
```

## 🚀 快速开始

### 1. 安装依赖

```bash
pip install playwright requests pycryptodome
playwright install
```

### 2. 登录获取 Cookie

```bash
python nudt_light_login.py
```

支持参数：
- `-u 学号` - 自动填充学号
- `-p 密码` - 自动填充密码
- `--headless` - 无头模式运行

**Cookie 保存位置**: `cache/library_cookies.json`

### 3. 执行专业检索

#### 方法 1: 使用快速检索示例

```bash
# 基本检索
python quick_search_example.py "刘锋"

# 按作者检索
python quick_search_example.py "机器学习" --author "刘锋"

# 按年份检索
python quick_search_example.py "人工智能" --year-start 2020 --year-end 2024
```

**结果保存位置**: `cache/search_result_*.html`

#### 方法 2: 使用 API

```python
from nudt_professional_search import ProfessionalSearchBuilder, MatchType, load_cookies
import requests
from urllib.parse import quote

# 加载 Cookie（从 cache/library_cookies.json）
cookies = load_cookies()

# 构建检索式
builder = ProfessionalSearchBuilder()
builder.add_author('刘锋', MatchType.FUZZY)
search_expr = builder.build()

# 发送请求
encoded_search = quote(search_expr, safe='')
url = f'https://fx.gfkd.chaoxing.com/s?sw={encoded_search}&size=20&isort=0'

headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
}

response = requests.get(url, headers=headers, cookies=cookies, timeout=30)
print(f'检索成功！响应长度：{len(response.text)} 字符')
```

## 📚 核心 API

### nudt_light_login.py

轻量级登录工具，使用系统已安装的 Chrome/Edge 浏览器。

**主要功能**：
- 自动检测已安装的浏览器
- 支持手动/自动输入账号密码
- 支持滑动验证码等复杂验证
- 自动保存 Cookie 到文件

**使用方法**：
```bash
# 手动登录
python nudt_light_login.py

# 自动填充账号密码
python nudt_light_login.py -u 学号 -p 密码

# 无头模式
python nudt_light_login.py --headless
```

### nudt_professional_search.py

专业检索 API，提供灵活的检索式构建功能。

**主要类**：
- `ProfessionalSearchBuilder` - 检索式构建器
- `SearchField` - 检索字段枚举
- `SearchCondition` - 检索条件
- `MatchType` - 匹配类型（精确/模糊）

**支持的检索字段**：
- 标题 (TITLE)
- 作者 (AUTHOR)
- 关键词 (KEYWORD)
- 摘要 (ABSTRACT)
- 作者单位 (AFFILIATION)
- 主题 (SUBJECT)
- 全文 (FULLTEXT)

**检索示例**：

```python
from nudt_professional_search import ProfessionalSearchBuilder, SearchField, MatchType

# 简单检索
builder = ProfessionalSearchBuilder()
builder.add_title('机器学习', MatchType.FUZZY)
search_url = builder.build()

# 多条件检索
builder = ProfessionalSearchBuilder()
builder.add_author('刘锋', MatchType.FUZZY)
builder.add_keyword('人工智能', MatchType.FUZZY)
builder.set_year_range(2020, 2024)
search_url = builder.build()

# 自定义检索式
builder = ProfessionalSearchBuilder()
builder.set_custom_expression("A='刘锋' AND K='人工智能'")
search_url = builder.build()
```

## 📋 编码规则

详见 [`国防科技大学图书馆专业检索编码规则.md`](国防科技大学图书馆专业检索编码规则.md)

### URL 编码规则

1. **中文字符**：使用 UTF-8 URL 编码
2. **特殊字符**：保留 `=`, `&` 等分隔符
3. **字段代码**：
   - `A` - 作者
   - `T` - 标题
   - `K` - 关键词
   - `S` - 摘要
   - `F` - 全文

### 检索式语法

```
# 单字段检索
A='刘锋'          # 作者检索
T='机器学习'        # 标题检索
K='人工智能'        # 关键词检索

# 多字段组合
A='刘锋' AND K='人工智能'
A='刘锋' OR A='李明'

# 年份范围
Y=2020-2024
```

## 🗂️ 备份文件

`backup/` 目录包含以下非核心但可能有用的文件：

### 文档类
- 各种使用指南 (GUIDE.md)
- 测试报告 (TEST_REPORT.md)
- 快速参考 (QUICK_REFERENCE.md)
- 项目说明 (README_*.md)

### 工具类
- `check_result.py` - 结果验证工具
- `search_result_parser.py` - HTML 解析器
- `test_*.py` - 测试脚本
- `examples*.py` - 示例代码

### 数据类
- `search_*.html` - 搜索结果
- `*_results.json` - 结构化数据

如需使用备份文件，可从 `backup/` 目录复制回主目录。

## 📦 Cache 目录

`cache/` 目录用于存储所有中间文件和临时数据，**自动创建**。

### 目录内容

| 文件 | 说明 | 来源 |
|------|------|------|
| `library_cookies.json` | 登录 Cookie | `nudt_light_login.py` 自动生成 |
| `search_result_*.html` | 检索结果 HTML | 检索脚本自动生成 |
| `result.html` | 检索结果 | 示例脚本生成 |

### 管理 Cache

**查看 Cache 内容**：
```bash
ls -lh cache/
```

**清理 Cache**：
```bash
# 删除所有缓存文件
rm -rf cache/*

# 仅删除 Cookie
rm cache/library_cookies.json

# 仅删除检索结果
rm cache/search_result_*.html
```

**备份 Cookie**：
```bash
# 备份到安全位置
cp cache/library_cookies.json ~/backup/
```

**恢复 Cookie**：
```bash
# 从备份恢复
cp ~/backup/library_cookies.json cache/
```

### Cookie 文件格式

```json
{
  "cookies": {
    "__dxca": "50264f30-...",
    "cookiecheck": "true",
    "JSESSIONID": "..."
  },
  "timestamp": 1774178135.692535,
  "username": "unknown"
}
```

### 注意事项

1. **Cookie 有效期**: Cookie 会过期，建议定期重新登录
2. **安全性**: Cookie 包含登录信息，不要分享给他人
3. **自动创建**: `cache/` 目录会在首次运行时自动创建
4. **版本控制**: 建议将 `cache/` 添加到 `.gitignore`

### .gitignore 配置

```
# Cache 目录
cache/
__pycache__/
*.pyc
*.pyo

# 临时文件
*.tmp
*.log
```

## ⚙️ 环境要求

- Python 3.8+
- Playwright
- requests
- pycryptodome
- Chrome 或 Edge 浏览器

## 📝 使用示例

### 示例 1：检索特定作者的文章

```python
import requests
from urllib.parse import quote
from nudt_professional_search import ProfessionalSearchBuilder, MatchType, load_cookies

# 加载 Cookie（从 cache 目录）
cookies = load_cookies()

# 构建检索
builder = ProfessionalSearchBuilder()
builder.add_author('刘锋', MatchType.FUZZY)
search_expr = builder.build()

# 发送请求
url = f'https://fx.gfkd.chaoxing.com/s?sw={quote(search_expr, safe="")}&size=20'
response = requests.get(url, headers={'User-Agent': 'Mozilla/5.0'}, cookies=cookies)

# 保存结果（到 cache 目录）
with open('cache/result.html', 'w', encoding='utf-8') as f:
    f.write(response.text)
```

### 示例 2：多条件组合检索

```python
from nudt_professional_search import ProfessionalSearchBuilder, SearchField, MatchType

builder = ProfessionalSearchBuilder()
builder.add_author('刘锋', MatchType.FUZZY)
builder.add_keyword('水资源', MatchType.FUZZY)
builder.set_year_range(2020, 2024)
builder.set_document_type('期刊')

search_url = builder.build()
print(f'检索 URL: {search_url}')
```

## 🔧 故障排除

### 问题 1：浏览器检测失败

**解决**：
```bash
# 手动指定浏览器路径
export CHROME_PATH="/usr/bin/chromium"
python nudt_light_login.py
```

### 问题 2：Cookie 失效

**解决**：
```bash
# 重新登录获取新 Cookie（会自动更新 cache/library_cookies.json）
python nudt_light_login.py
```

**手动删除 Cookie**：
```bash
rm cache/library_cookies.json
python nudt_light_login.py
```

### 问题 3：检索结果为空

**可能原因**：
- Cookie 失效
- 检索式过于严格
- 网络问题

**解决方法**：
1. 检查 Cookie 是否有效
2. 简化检索条件
3. 检查网络连接

## 📞 技术支持

- 编码规则：详见 `国防科技大学图书馆专业检索编码规则.md`
- 更多示例：参考 `backup/examples*.py`
- 测试用例：参考 `backup/test_*.py`

---

**最后更新**: 2026 年 3 月 22 日  
**版本**: 2.0 (精简版)
