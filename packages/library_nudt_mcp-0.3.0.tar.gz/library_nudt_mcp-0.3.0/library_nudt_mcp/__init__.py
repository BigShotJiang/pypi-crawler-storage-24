#!/usr/bin/env python3
"""
国防科技大学图书馆 MCP 服务器

使用 FastMCP 框架实现真正的 MCP 协议服务器
"""

import sys
import json
import requests
from pathlib import Path
from typing import Optional, List, Dict, Any
from datetime import datetime
from urllib.parse import quote

# FastMCP 导入
try:
    from fastmcp import FastMCP
except ImportError:
    print("错误：请安装 fastmcp: pip install fastmcp", file=sys.stderr)
    sys.exit(1)

# 本地模块导入（使用相对导入）
from .nudt_light_login import load_cookies_from_file, login_with_installed_browser
from .expression_validator import ExpressionValidator
from .search_result_parser import SearchResultsParser
from .experience_manager import ExperienceManager

# 创建 FastMCP 服务器实例
mcp = FastMCP(
    name="library-nudt",
    instructions="国防科技大学图书馆检索服务，提供学术资源检索功能"
)

# 全局变量
_server_instance = None
CACHE_DIR = Path("cache")
COOKIE_FILE = CACHE_DIR / "library_cookies.json"


class LibraryMCPServer:
    """图书馆 MCP 服务器实现"""
    
    def __init__(self):
        """初始化服务器"""
        self.cookie_file = COOKIE_FILE
        self.cookies: Optional[Dict[str, str]] = None
        self.validator = ExpressionValidator()
        self.base_url = "https://fx.gfkd.chaoxing.com/s"
        self.last_url = "https://fx.gfkd.chaoxing.com/"
        
        # 确保 cache 目录存在
        CACHE_DIR.mkdir(exist_ok=True)
        
        # 加载 Cookie
        self._load_cookies()
    
    def _load_cookies(self) -> bool:
        """加载 Cookie"""
        if self.cookie_file.exists():
            self.cookies = load_cookies_from_file(str(self.cookie_file))
            if self.cookies:
                print(f"✓ 已加载 {len(self.cookies)} 个 Cookie", file=sys.stderr)
                return True
        return False
    
    def login(self, username: Optional[str] = None, 
              password: Optional[str] = None,
              headless: bool = False,
              force: bool = False,# 强制登录，即使当前 Cookie 可能有效
              wait_time: int = 300) -> Dict[str, Any]:
        """
        执行登录
        
        Args:
            username: 用户名（可选，不提供则手动输入）
            password: 密码（可选，不提供则手动输入）
            headless: 是否使用无头模式（默认 False，显示浏览器）
            force: 是否强制登录，即使当前 Cookie 可能有效（默认 False）
            wait_time: 等待登录完成的时间（秒，默认 300）
            
        Returns:
            登录结果，包含：
            - success: 是否成功
            - message: 提示信息
            - cookie_count: Cookie 数量
        """
        try:
            print(f"开始登录流程...", file=sys.stderr)
            
            if not force and self._test_cookies():
                print(f"当前 Cookie 有效，无需重新登录.", file=sys.stderr)
                return {
                    "success": True,
                    "message": "当前 Cookie 有效，无需重新登录",
                    "cookie_count": len(self.cookies) if self.cookies else 0
                }
            # 调用登录函数
            if force:
                print(f"强制登录已启用，即使当前 Cookie 可能有效.", file=sys.stderr)
            else:
                print(f"当前 Cookie 无效，正在重新登录...", file=sys.stderr)
            success = login_with_installed_browser(
                username=username,
                password=password,
                headless=headless,
                wait_time=wait_time
            )
            
            if success:
                # 重新加载 Cookie
                self._load_cookies()
                
                return {
                    "success": True,
                    "message": "登录成功，Cookie 已保存",
                    "cookie_count": len(self.cookies) if self.cookies else 0
                }
            else:
                return {
                    "success": False,
                    "message": "登录失败，请检查账号密码或网络连接",
                    "cookie_count": 0
                }
                
        except Exception as e:
            print(f"登录异常：{e}", file=sys.stderr)
            return {
                "success": False,
                "message": f"登录异常：{str(e)}",
                "cookie_count": 0
            }
    
    def _test_cookies(self) -> bool:
        """测试 Cookie 是否有效"""
        if not self.cookies:
            return False
        
        try:
            test_url = f"{self.base_url}?sw=测试&size=1"
            headers = {
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                'Accept-Encoding': 'gzip, deflate, br, zstd',
                'Accept-Language': 'en-US,en;q=0.9',
                'Connection': 'keep-alive',
                'Referer': self.last_url,
                'Sec-Ch-Ua': '"Not-A.Brand";v="24", "Chromium";v="146"',
                'Sec-Ch-Ua-Mobile': '?0',
                'Sec-Ch-Ua-Platform': '"Linux"',
                'Sec-Fetch-Dest': 'document',
                'Sec-Fetch-Mode': 'navigate',
                'Sec-Fetch-Site': 'same-origin',
                'Sec-Fetch-User': '?1',
                'Upgrade-Insecure-Requests': '1',
                'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36'
            }
            response = requests.get(test_url, headers=headers, cookies=self.cookies, timeout=10)
            
            if response.status_code != 200:
                return False
            
            # 检测是否返回搜索结果页面（包含 cur-search-count 类）
            # 登录页面不会包含这个类
            if 'cur-search-count' in response.text:
                return True
            
            return False
            
        except Exception as e:
            print(f"Cookie 测试失败：{e}", file=sys.stderr)
            return False
    
    def search(self, expression: str, page: int = 1, size: int = 50) -> Dict[str, Any]:
        """
        执行检索
        
        Args:
            expression: 检索表达式
            page: 页码
            size: 每页结果数
            
        Returns:
            检索结果
        """
        result = {
            "success": False,
            "data": None,
            "error": None,
            "validation": None
        }
        
        # Step 1: 验证表达式
        print(f"验证表达式：{expression}", file=sys.stderr)
        is_valid = self.validator.validate(expression)
        
        if not is_valid:
            errors = [
                {
                    "level": e.level.value,
                    "message": e.message,
                    "position": e.position,
                    "suggestion": e.suggestion
                }
                for e in self.validator.errors
            ]
            warnings = [
                {
                    "level": w.level.value,
                    "message": w.message
                }
                for w in self.validator.warnings
            ]
            
            result["error"] = "检索表达式验证失败"
            result["validation"] = {
                "is_valid": False,
                "errors": errors,
                "warnings": warnings
            }
            print(f"✗ 表达式验证失败", file=sys.stderr)
            return result
        
        result["validation"] = {"is_valid": True, "errors": [], "warnings": []}
        print("✓ 表达式验证通过", file=sys.stderr)
        
        # Step 2: 检查 Cookie
        if not self.cookies or not self._test_cookies():
            result["error"] = "Cookie 无效，请先运行 nudt_light_login.py 登录"
            print("✗ Cookie 无效", file=sys.stderr)
            return result
        
        # Step 3: 执行检索
        try:
            encoded_expression = quote(expression, safe='').replace('%20', '+')
            url = f"{self.base_url}?adv={encoded_expression}&size={size}&aorp=p&isort=1&x=814_51&pages={page}&version=v2"
            
            headers = {
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                'Accept-Encoding': 'gzip, deflate, br, zstd',
                'Accept-Language': 'en-US,en;q=0.9',
                'Connection': 'keep-alive',
                'Referer': self.last_url,
                'Sec-Ch-Ua': '"Not-A.Brand";v="24", "Chromium";v="146"',
                'Sec-Ch-Ua-Mobile': '?0',
                'Sec-Ch-Ua-Platform': '"Linux"',
                'Sec-Fetch-Dest': 'document',
                'Sec-Fetch-Mode': 'navigate',
                'Sec-Fetch-Site': 'same-origin',
                'Sec-Fetch-User': '?1',
                'Upgrade-Insecure-Requests': '1',
                'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36',
            }
            
            print(f"执行检索：{url}", file=sys.stderr)
            response = requests.get(url, headers=headers, cookies=self.cookies, timeout=30)
            
            if response.status_code != 200:
                result["error"] = f"请求失败，状态码：{response.status_code}"
                print(f"✗ 请求失败：{response.status_code}", file=sys.stderr)
                return result
            
            # 更新 last_url 为当前请求 URL，供下次请求使用
            self.last_url = url
            
            print(f"✓ 请求成功，响应长度：{len(response.text)}", file=sys.stderr)
            
            # Step 4: 解析结果（使用新的 search_result_parser.py）
            parser = SearchResultsParser(response.text)
            search_results = parser.parse()
            # print(f"✓ 解析 {search_results}", file=sys.stderr)
            print(f"✓ 解析第{page}页的{(page -1)*size + 1}-{min(page * size, search_results['total_count'])}/{search_results['total_count']} 条结果", file=sys.stderr)
            
            # 转换为字典列表
            
            result["success"] = True
            result["data"] = {
                "expression": expression,
                "page": page,
                "size": size,
                "page_count": search_results['page_count'],  # 当前页结果数
                "total_count": search_results['total_count'],  # 总结果数（来自页面）
                "rest_count": max(0, search_results['total_count'] - page * size),  # 估算剩余结果数
                "results": search_results['results'],  # 结果列表（包含所有字段：作者、出处、发明人、申请号等）
                "timestamp": datetime.now().isoformat()
            }
            
            # 保存结果
            self._save_results(expression, response.text, search_results)
            
        except Exception as e:
            result["error"] = f"检索执行失败：{str(e)}"
            print(f"✗ 检索失败：{e}", file=sys.stderr)
        
        return result
    
    def _get_deitails_url(self, url: str) -> Dict[str, Any]:
        """根据详情页 URL 分析文献具体字段"""
        headers = {
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
                'Accept-Encoding': 'gzip, deflate, br, zstd',
                'Accept-Language': 'en-US,en;q=0.9',
                'Connection': 'keep-alive',
                'Referer': self.last_url,
                'Sec-Ch-Ua': '"Not-A.Brand";v="24", "Chromium";v="146"',
                'Sec-Ch-Ua-Mobile': '?0',
                'Sec-Ch-Ua-Platform': '"Linux"',
                'Sec-Fetch-Dest': 'document',
                'Sec-Fetch-Mode': 'navigate',
                'Sec-Fetch-Site': 'same-origin',
                'Sec-Fetch-User': '?1',
                'Upgrade-Insecure-Requests': '1',
                'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36',
            }
        print(f"执行检索：{url}", file=sys.stderr)
        response = requests.get(url, headers=headers, cookies=self.cookies, timeout=30)
        result={}
        if response.status_code != 200:
            result["error"] = f"请求失败，状态码：{response.status_code}"
            print(f"✗ 请求失败：{response.status_code}", file=sys.stderr)
            return result
        else:# 需要专门的解析器来解析详情页，提取作者、出处、发明人、申请号等字段
            # 更新 last_url 为当前请求 URL，供下次请求使用
            self.last_url = url
            print(f"✓ 请求成功，响应长度：{len(response.text)}", file=sys.stderr)
            # 解析详情页（需要新的解析器）
            parser = SearchResultsParser(response.text)
            details = parser.parse_details()
            print(f"✓ 解析详情页成功：{details}", file=sys.stderr)
            return details

    def _save_results(self, expression: str, html: str, data: List[Dict]):
        """保存检索结果"""
        try:
            import hashlib
            expr_hash = hashlib.md5(expression.encode('utf-8')).hexdigest()[:8]
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            
            html_file = CACHE_DIR / f"search_{expr_hash}_{timestamp}.html"
            json_file = CACHE_DIR / f"search_{expr_hash}_{timestamp}.json"
            
            with open(html_file, 'w', encoding='utf-8') as f:
                f.write(html)
            
            with open(json_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            
            print(f"✓ 结果已保存", file=sys.stderr)
        except Exception as e:
            print(f"⚠ 保存失败：{e}", file=sys.stderr)
    
    def get_help(self) -> Dict[str, Any]:
        """获取检索帮助"""
        return {
            "success": True,
            "data": {
                "field_codes": {
                    "通用字段": {
                        "T": "标题（书名、标题）",
                        "A": "作者（责任者）",
                        "K": "关键词",
                        "S": "文摘（摘要、视频简介）",
                        "O": "作者单位（作者单位、学位授予单位）",
                        "Su": "主题（标题、关键词、摘要）",
                        "Z": "全部字段",
                        "Y": "年（出版发行年、学位年度、会议召开年、专利申请年、标准发布年）",
                        "Clc": "中图分类号",
                        "Sdc": "教育部本科生学科分类号",
                        "Gdc": "教育部研究生学科分类号"
                    },
                    "文献类型": {
                        "BK": "图书",
                        "JN": "期刊",
                        "DT": "学位",
                        "CP": "会议",
                        "PT": "专利",
                        "ST": "标准",
                        "VI": "音视频",
                        "NP": "报纸",
                        "TR": "科技成果",
                        "YB": "年鉴",
                        "LW": "法律法规",
                        "CA": "案例",
                        "RE": "报告",
                        "IF": "信息资讯",
                        "GI": "政府信息",
                        "IMG": "图片"
                    },
                    "非通用字段（需加文献类型前缀）": {
                        "BKs": "丛书名（图书）",
                        "F": "指导老师（学位）/ 专利申请人（专利）",
                        "DTn": "学位",
                        "Tf": "英文标题（学位）",
                        "DTa": "英文文摘（学位）",
                        "CPn": "会议名称",
                        "PTt": "专利类型",
                        "STd": "起草单位（标准）"
                    }
                },
                "logic_operators": {
                    "不同字段间": {
                        "AND": "与（并且）",
                        "OR": "或（或者）",
                        "NOT": "非（不包含）",
                        "priority": "NOT > AND > OR"
                    },
                    "同一字段内": {
                        "*": "并且",
                        "|": "或者",
                        "-": "不包含",
                        "priority": "- > * > |"
                    },
                    "note": "逻辑运算符必须大写，前后各空一个字节"
                },
                "match_symbols": {
                    "\"\"": "精确匹配",
                    "''": "模糊匹配",
                    "note": "检索词包含空格或逻辑符号时，必须加引号"
                },
                "year_range_help": {
                    "correct": "2000<Y<2020 (包含 2000 和 2020)",
                    "incorrect": "2000<=Y<=2020 (错误：不能使用 >= 和 <=)",
                    "note": "< 和 > 默认包含边界值，不需要使用 >="
                },
                "parentheses": {
                    "usage": "使用英文半角括号 () 改变运算优先级",
                    "example": "JN((A=杨振宁|周培源 AND O=清华大学) OR A=钱学森)"
                },
                "examples": [
                    {
                        "desc": "简单检索 - 作者为张士锋的文章",
                        "expression": "A='张士锋'"
                    },
                    {
                        "desc": "多条件检索 - 张士锋关于水资源的研究",
                        "expression": "A='张士锋' AND K='水资源'"
                    },
                    {
                        "desc": "年份范围 - 2000 至 2020 年（含边界）",
                        "expression": "A='张士锋' AND 2000<Y<2020"
                    },
                    {
                        "desc": "期刊论文 - 清华大学杨振宁或周培源的文章",
                        "expression": "JN(A=杨振宁|周培源 AND O=清华大学)"
                    },
                    {
                        "desc": "复杂检索 - 多条件组合",
                        "expression": "JN((A=杨振宁|周培源 AND O=清华大学) OR A=钱学森 AND 2000<Y<2016 NOT K=断层)"
                    },
                    {
                        "desc": "同一字段内运算 - 海或海洋相关机构",
                        "expression": "JN(O=(海|海洋)*(研究所 | 中心 | 学院 | 分局 | 大学 | 研究室 | 实验室 | 系)) AND Su=海洋 AND 2000<Y<2016"
                    },
                    {
                        "desc": "包含空格的检索词",
                        "expression": "K=\"cryptography\"|'cipher code'|\"Multimedia security\""
                    },
                    {
                        "desc": "专利检索",
                        "expression": "PT(A='张士锋' AND PTt=发明)"
                    },
                    {
                        "desc": "学位论文检索",
                        "expression": "DT(F='李四' AND DTn=博士)"
                    }
                ],
                "quick_reference": {
                    "基本格式": "字段=检索词",
                    "多字段": "A='作者' AND K='关键词' AND T='标题'",
                    "年份范围": "2000<Y<2020 (包含边界)",
                    "文献类型前缀": "JN(...), BK(...), DT(...), PT(...) 等",
                    "注意事项": [
                        "所有符号和英文字母必须使用英文半角",
                        "逻辑运算符必须大写，前后空格",
                        "检索词包含空格或逻辑符号时需加引号",
                        "< 和 > 默认包含边界值，不使用 >= 和 <=",
                        "403 错误通常是请求太快，请稍后再试",
                        "如果 rest_count>0，可以继续请求下一页 page+1 来获取更多结果，直到 rest_count=0"
                    ]
                }
            }
        }


# 初始化服务器实例
_server_instance = LibraryMCPServer()


# ==================== MCP 工具定义 ====================

@mcp.tool()
def nudt_search(expression: str, page: int = 1, size: int = 20) -> Dict[str, Any]:
    """
    执行国防科技大学图书馆检索
    
    ⚠️ 重要：检索表达式必须使用专业检索语法，不是自然语言！
    
    Args:
        expression: 检索表达式（必须使用字段代码和逻辑运算符）
             "field_codes": {
                    "通用字段": {
                        "T": "标题（书名、标题）",
                        "A": "作者（责任者）",
                        "K": "关键词",
                        "S": "文摘（摘要、视频简介）",
                        "O": "作者单位（作者单位、学位授予单位）",
                        "Su": "主题（标题、关键词、摘要）",
                        "Z": "全部字段",
                        "Y": "年（出版发行年、学位年度、会议召开年、专利申请年、标准发布年）",
                        "Clc": "中图分类号",
                        "Sdc": "教育部本科生学科分类号",
                        "Gdc": "教育部研究生学科分类号"
                    },
                    "文献类型": {
                        "BK": "图书",
                        "JN": "期刊",
                        "DT": "学位",
                        "CP": "会议",
                        "PT": "专利",
                        "ST": "标准",
                        "VI": "音视频",
                        "NP": "报纸",
                        "TR": "科技成果",
                        "YB": "年鉴",
                        "LW": "法律法规",
                        "CA": "案例",
                        "RE": "报告",
                        "IF": "信息资讯",
                        "GI": "政府信息",
                        "IMG": "图片"
                    },
                    "非通用字段（需加文献类型前缀）": {
                        "BKs": "丛书名（图书）",
                        "F": "指导老师（学位）/ 专利申请人（专利）",
                        "DTn": "学位",
                        "Tf": "英文标题（学位）",
                        "DTa": "英文文摘（学位）",
                        "CPn": "会议名称",
                        "PTt": "专利类型",
                        "STd": "起草单位（标准）"
                    }
                },
                "logic_operators": {
                    "不同字段间": {
                        "AND": "与（并且）",
                        "OR": "或（或者）",
                        "NOT": "非（不包含）",
                        "priority": "NOT > AND > OR"
                    },
                    "同一字段内": {
                        "*": "并且",
                        "|": "或者",
                        "-": "不包含",
                        "priority": "- > * > |"
                    },
                    "note": "逻辑运算符必须大写，前后各空一个字节"
                },
                "match_symbols": {
                    "\"\"": "精确匹配",
                    "''": "模糊匹配",
                    "note": "检索词包含空格或逻辑符号时，必须加引号"
                },
                "year_range_help": {
                    "correct": "2000<Y<2020 (包含 2000 和 2020)",
                    "incorrect": "2000<=Y<=2020 (错误：不能使用 >= 和 <=)",
                    "note": "< 和 > 默认包含边界值，不需要使用 >="
                },
                "parentheses": {
                    "usage": "使用英文半角括号 () 改变运算优先级",
                    "example": "JN((A=杨振宁|周培源 AND O=清华大学) OR A=钱学森)"
                },
                "examples": [
                    {
                        "desc": "简单检索 - 作者为张士锋的文章",
                        "expression": "A='张士锋'"
                    },
                    {
                        "desc": "多条件检索 - 张士锋关于水资源的研究",
                        "expression": "A='张士锋' AND K='水资源'"
                    },
                    {
                        "desc": "年份范围 - 2000 至 2020 年（含边界）",
                        "expression": "A='张士锋' AND 2000<Y<2020"
                    },
                    {
                        "desc": "期刊论文 - 清华大学杨振宁或周培源的文章",
                        "expression": "JN(A=杨振宁|周培源 AND O=清华大学)"
                    },
                    {
                        "desc": "复杂检索 - 多条件组合",
                        "expression": "JN((A=杨振宁|周培源 AND O=清华大学) OR A=钱学森 AND 2000<Y<2016 NOT K=断层)"
                    },
                    {
                        "desc": "同一字段内运算 - 海或海洋相关机构",
                        "expression": "JN(O=(海|海洋)*(研究所 | 中心 | 学院 | 分局 | 大学 | 研究室 | 实验室 | 系)) AND Su=海洋 AND 2000<Y<2016"
                    },
                    {
                        "desc": "包含空格的检索词",
                        "expression": "K=\"cryptography\"|'cipher code'|\"Multimedia security\""
                    },
                    {
                        "desc": "专利检索",
                        "expression": "PT(A='张士锋' AND PTt=发明)"
                    },
                    {
                        "desc": "学位论文检索",
                        "expression": "DT(F='李四' AND DTn=博士)"
                    }
                ],
                "quick_reference": {
                    "基本格式": "字段=检索词",
                    "多字段": "A='作者' AND K='关键词' AND T='标题'",
                    "年份范围": "2000<Y<2020 (包含边界)",
                    "文献类型前缀": "JN(...), BK(...), DT(...), PT(...) 等",
                    "注意事项": [
                        "所有符号和英文字母必须使用英文半角",
                        "逻辑运算符必须大写，前后空格",
                        "检索词包含空格或逻辑符号时需加引号",
                        "< 和 > 默认包含边界值，不使用 >= 和 <=",
                        "403 错误通常是请求太快，请稍后再试",
                        
                    ]
                }
        page: 页码（从 1 开始）
        size: 每页结果数量（默认 50,必要时可以使用最大值 100）
    
    Returns:
        检索结果，包含：
        - success: 是否成功
        - data: 
            - expression: 原始检索表达式
            - page: 当前页码
            - size: 每页结果数
            - page_count: 当前页结果数
            - total_count: 总结果数, 如果 total_count=0，表示没有结果，建议查看以往经验: search_search_experiences 来优化检索表达式
            - rest_count: 估算剩余结果数, 如果 rest_count>0，可以继续请求下一页 page+1 来获取更多结果，直到 rest_count=0
            - results: 结果列表
            - timestamp: 检索时间戳
        - error: 错误信息, 403 错误通常是请求太快，请稍后3秒再试, 与size参数和检索词没有关系，大size参数反而不容易导致错误，因为需要的次数更少
        - validation: 验证结果

        提示：
        1. 如果
        2. 如果尝试了多次才成功，请总结经验，保存到经验管理工具中：save_search_experience(user_need, search_expression, result_count, lessons_learned, notes)，并提供给后续检索参考

    """
    return _server_instance.search(expression, page, size)


@mcp.tool()
def get_search_detail(url: str) -> Dict[str, Any]:
    """
    获取某条检索的详情信息
    
    Args:
        url: 详情页 URL, 来自 nudt_search->search_results['data']['results'] 中每条结果的 detail_url 字段
    Returns: Dict[str, Any]: 详情信息，包含：
            - key: 数据标签，例如作者、出处、发明人等
            - value: 对应的值，例如"张士锋"、"清华大学"、"李四"等
    """
    return _server_instance._get_deitails_url(url)

@mcp.tool()
def login(username: Optional[str] = None, 
          password: Optional[str] = None,
          headless: bool = False,
          force: bool = False,# 强制登录，即使当前 Cookie 可能有效
          wait_time: int = 30) -> Dict[str, Any]:
    """
    登录国防科技大学图书馆
    
    ⚠️ 重要：首次使用或 Cookie 失效时需要登录
    
    Args:
        username: 用户名/学号（可选，不提供则在浏览器中手动输入）
        password: 密码（可选，不提供则在浏览器中手动输入）
        headless: 是否使用无头模式（默认 False，显示浏览器便于手动完成验证码）
        force: 是否强制登录，即使当前 Cookie 可能有效（默认 False）
        wait_time: 等待登录完成的时间（秒，默认 30）
    
    Returns:
        登录结果，包含：
        - success: 是否成功
        - message: 提示信息
        - cookie_count: 保存的 Cookie 数量
    
    使用场景：
        1. 首次使用：提供 username 和 password，自动填充并手动完成验证码
        2. Cookie 失效：不提供参数，打开浏览器手动登录
        3. 自动化脚本：提供 username 和 password，设置 headless=True
    
    示例：
        # 首次登录，提供账号密码
        login(username="lijun17a", password="902059a")
        
        # Cookie 失效，手动登录
        login()
        
        # 自动化登录（无头模式）
        login(username="lijun17a", password="902059a", headless=True)
    
    提示：
        - 登录成功后 Cookie 会自动保存到 cache/library_cookies.json
        - 建议使用 headless=False（默认），便于手动完成验证码
        - 登录完成后可以调用 check_cookies() 验证状态
    """
    return _server_instance.login(username, password, headless, force, wait_time)


# ==================== 经验管理工具 ====================

@mcp.tool()
def save_search_experience(user_need: str,
                          search_expression: str,
                          result_count: int,
                          lessons_learned: str,
                          notes: str = "") -> Dict[str, Any]:
    """
    保存检索经验总结
    
    用于记录检索过程中的经验教训，帮助优化后续检索策略。
    经验会自动保存到 cache/experience.md 文件中。
    
    Args:
        user_need: 用户需求描述（自然语言，例如："查找张士锋教授关于水资源的研究论文"）
        search_expression: 检索表达式（专业检索语法，例如："A='张士锋' AND K='水资源'"）
        result_count: 检索结果数量
        lessons_learned: 经验教训总结（例如："使用主题字段 Su 比关键词字段 K 能获得更多相关结果"）
        notes: 额外备注（可选，例如："建议使用 AND 连接多个条件来提高精确度"）
    
    Returns:
        保存结果，包含：
        - success: 是否成功
        - experience_id: 经验 ID（用于后续查询）
        - message: 提示信息
        - keywords: 自动提取的关键词列表
    
    示例:
        save_search_experience(
            user_need="查找张士锋教授关于水资源的研究论文",
            search_expression="A='张士锋' AND K='水资源'",
            result_count=50,
            lessons_learned="使用主题字段 Su 比关键词字段 K 能获得更多相关结果，建议使用 Su 字段进行检索",
            notes="检索结果按被引频次排序更有价值"
        )
    """
    try:
        manager = ExperienceManager(CACHE_DIR)
        experience = manager.save_experience(
            user_need=user_need,
            search_expression=search_expression,
            result_count=result_count,
            lessons_learned=lessons_learned,
            notes=notes
        )
        
        return {
            "success": True,
            "experience_id": experience.id,
            "message": f"经验 #{experience.id} 已保存",
            "keywords": experience.keywords,
            "timestamp": experience.timestamp
        }
    except Exception as e:
        return {
            "success": False,
            "message": f"保存失败：{str(e)}"
        }


@mcp.tool()
def search_search_experiences(keywords: Optional[str] = None,
                             start_line: int = 1,
                             end_line: Optional[int] = None,
                             min_results: Optional[int] = None,
                             max_results: Optional[int] = None,
                             success_only: bool = False,
                             limit: int = 20) -> Dict[str, Any]:
    """
    搜索和查看以往的检索经验
    
    支持按关键词搜索、分页浏览、按结果数量过滤等功能。
    帮助快速找到类似场景下的检索经验和优化策略。
    
    Args:
        keywords: 搜索关键词（空格分隔多个关键词，例如："张士锋 水资源"）
        start_line: 开始行号（用于分页，默认 1）
        end_line: 结束行号（用于分页，例如：1-20 页）
        min_results: 最小结果数（过滤掉结果少于该值的经验）
        max_results: 最大结果数（过滤掉结果多于该值的经验）
        success_only: 只返回成功的经验（默认 False）
        limit: 返回数量限制（默认 20）
    
    Returns:
        搜索结果，包含：
        - success: 是否成功
        - total_found: 找到的经验数量
        - experiences: 经验列表，每项包含：
            - id: 经验 ID
            - user_need: 用户需求
            - search_expression: 检索表达式
            - result_count: 结果数量
            - lessons_learned: 经验教训
            - keywords: 关键词
            - timestamp: 时间戳
            - success: 是否成功
            - notes: 备注
        - statistics: 统计信息（总记录数、成功率等）
    
    示例:
        # 搜索关于"张士锋 水资源"的经验
        search_search_experiences(keywords="张士锋 水资源")
        
        # 查看第 1-20 条经验
        search_search_experiences(start_line=1, end_line=20)
        
        # 只查看成功的经验，且结果数在 10-100 之间
        search_search_experiences(min_results=10, max_results=100, success_only=True)
        
        # 查看统计信息（不指定关键词会返回所有经验）
        search_search_experiences()
    """
    try:
        manager = ExperienceManager(CACHE_DIR)
        
        # 搜索经验
        experiences = manager.search_experiences(
            keywords=keywords,
            start_line=start_line,
            end_line=end_line,
            min_results=min_results,
            max_results=max_results,
            success_only=success_only,
            limit=limit
        )
        
        # 获取统计信息
        stats = manager.get_statistics()
        
        # 转换为字典列表
        from dataclasses import asdict
        experiences_data = [asdict(e) for e in experiences]
        
        return {
            "success": True,
            "total_found": len(experiences_data),
            "experiences": experiences_data,
            "statistics": stats,
            "filters_applied": {
                "keywords": keywords,
                "start_line": start_line,
                "end_line": end_line,
                "min_results": min_results,
                "max_results": max_results,
                "success_only": success_only,
                "limit": limit
            }
        }
    except Exception as e:
        return {
            "success": False,
            "message": f"搜索失败：{str(e)}"
        }


# ==================== 主函数 ====================

def main():
    """主函数 - 启动 MCP 服务器"""
    print("启动国防科技大学图书馆 MCP 服务器...", file=sys.stderr)
    print(f"Cookie 文件：{COOKIE_FILE}", file=sys.stderr)
    print(f"Cache 目录：{CACHE_DIR}", file=sys.stderr)
    _server_instance.login(force=False)
    
    # 启动 FastMCP 服务器
    print("\n启动 MCP 服务器（stdio 模式）...", file=sys.stderr)
    mcp.run()


if __name__ == "__main__":
    main()
