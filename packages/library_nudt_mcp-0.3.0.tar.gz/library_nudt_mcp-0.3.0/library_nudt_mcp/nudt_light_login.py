"""
国防科技大学图书馆轻量级登录工具 - 使用已安装的浏览器

使用 Playwright 连接系统中已安装的 Chrome/Edge 浏览器
避免下载额外的浏览器核心（~170MB），最轻量级方案

依赖：
    pip install playwright requests pycryptodome
    playwright install  # 首次需要安装 Playwright 核心（可复用）

优势：
    ✓ 使用系统已安装的浏览器，不额外下载
    ✓ 自动处理滑动验证码
    ✓ 代码简洁，易于维护
"""

import json
import re
import time
from pathlib import Path
from typing import Optional, Dict
from playwright.sync_api import sync_playwright
import requests


# ====================== 【配置】你的配置 ======================
USERNAME = "lijun17a"
PASSWORD = "902059a"
CACHE_DIR = Path("cache")
COOKIE_FILE = CACHE_DIR / "library_cookies.json"
# =============================================================

# 固定参数
LOGIN_URL = "https://library.nudt.edu.cn/sso/login?wfwfid=182&refer=http%3A%2F%2Ffx.gfkd.chaoxing.com%2F"
SEARCH_URL = "https://fx.gfkd.chaoxing.com/s"


def ensure_cache_dir():
    """确保 cache 目录存在"""
    CACHE_DIR.mkdir(exist_ok=True)


def detect_chrome_path() -> Optional[str]:
    """
    自动检测系统中已安装的 Chrome/Edge 浏览器路径
    
    Returns:
        浏览器可执行文件路径，如果未找到则返回 None
    """
    import platform
    import os
    
    system = platform.system()
    
    if system == "Windows":
        # Windows 常见浏览器路径
        possible_paths = [
            # Google Chrome
            r"C:\Program Files\Google\Chrome\Application\chrome.exe",
            r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
            os.path.expandvars(r"%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe"),
            
            # Microsoft Edge
            r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
            r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
            os.path.expandvars(r"%LOCALAPPDATA%\Microsoft\Edge\Application\msedge.exe"),
        ]
        
        for path in possible_paths:
            if os.path.exists(path):
                return path
    
    elif system == "Darwin":  # macOS
        possible_paths = [
            "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
            "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
        ]
        
        for path in possible_paths:
            if os.path.exists(path):
                return path
    
    elif system == "Linux":
        possible_paths = [
            "/usr/bin/google-chrome",
            "/usr/bin/google-chrome-stable",
            "/usr/bin/chromium",
            "/usr/bin/chromium-browser",
            "/usr/bin/microsoft-edge",
        ]
        
        for path in possible_paths:
            if os.path.exists(path):
                return path
    
    return None


def login_with_installed_browser(username: Optional[str] = None, 
                                  password: Optional[str] = None,
                                  headless: bool = False,
                                  wait_time: int = 30) -> bool:
    """
    使用已安装的浏览器进行登录
    
    Args:
        username: 用户名（可选，提供则尝试自动填充）
        password: 密码（可选，提供则尝试自动填充）
        headless: 是否使用无头模式
        wait_time: 手动登录等待时间（秒）
        
    Returns:
        登录是否成功
    """
    print("=" * 60)
    print("国防科技大学图书馆轻量级登录工具")
    print("=" * 60)
    
    # 检测浏览器路径
    print("\n[1/4] 检测已安装的浏览器...")
    browser_path = detect_chrome_path()
    
    if browser_path:
        print(f"✓ 检测到浏览器：{browser_path}")
    else:
        print("✗ 未找到已安装的 Chrome/Edge 浏览器")
        print("  请安装 Google Chrome 或 Microsoft Edge")
        return False
    
    # 启动浏览器
    print(f"\n[2/4] 启动浏览器...")
    
    with sync_playwright() as p:
        try:
            # 启动浏览器
            browser = p.chromium.launch(
                headless=headless,
                executable_path=browser_path,
                args=[
                    "--no-sandbox",
                    "--disable-dev-shm-usage",
                    "--disable-gpu",
                ]
            )
            
            # 创建浏览器上下文
            context = browser.new_context(
                viewport={"width": 1920, "height": 1080},
                user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
            )
            
            page = context.new_page()
            
            # 打开登录页面
            print(f"\n[3/4] 打开登录页面...")
            page.goto(LOGIN_URL, wait_until="domcontentloaded")
            
            # 如果提供了账号密码，尝试自动填充
            if username and password:
                print("检测到账号密码，尝试自动填充...")
                try:
                    # 等待输入框加载
                    page.wait_for_selector('input[type="text"]', timeout=5000)
                    
                    # 填充账号密码
                    page.fill('input[type="text"]', username)
                    page.fill('input[type="password"]', password)
                    
                    print("✓ 已自动填充账号密码")
                    print("请手动完成验证码并点击登录按钮")
                except Exception as e:
                    print(f"自动填充失败：{e}")
                    print("请手动输入账号密码")
            else:
                print("请在浏览器中输入账号密码并完成验证码")
            
            # 等待登录完成
            print(f"\n[4/4] 等待登录完成...")
            print(f"  最长等待时间：{wait_time}秒")
            print(f"  提示：登录成功后会自动保存 Cookie")
            # time.sleep(wait_time)
            # # 方法 1：等待 URL 变化到搜索页面
            try:
                page.wait_for_url("http*://fx.gfkd.chaoxing.com*", timeout=wait_time * 1000)
                print("\n✓ 检测到登录成功（URL 变化）")
            except:
                # 方法 2：等待搜索框出现
                time.sleep(wait_time)
            # 
            # 获取 Cookie
            print("\n正在获取 Cookie...")
            cookies = context.cookies()
            
            # 过滤出需要的 Cookie
            needed_cookies = {}
            for cookie in cookies:
                if cookie["domain"] and ("chaoxing.com" in cookie["domain"] or "gfkd.chaoxing.com" in cookie["domain"]):
                    needed_cookies[cookie["name"]] = cookie["value"]
            
            if not needed_cookies:
                print("✗ 未获取到 Cookie")
                browser.close()
                return False
            
            print(f"✓ 获取到 {len(needed_cookies)} 个 Cookie")
            
            # 确保 cache 目录存在
            ensure_cache_dir()
            
            # 保存 Cookie
            cookie_data = {
                "cookies": needed_cookies,
                "timestamp": time.time(),
                "username": username if username else "unknown"
            }
            
            with open(COOKIE_FILE, "w", encoding="utf-8") as f:
                json.dump(cookie_data, f, indent=2, ensure_ascii=False)
            
            print(f"✓ Cookie 已保存到 {COOKIE_FILE}")
            
            # 关闭浏览器
            browser.close()
            
            print("\n" + "=" * 60)
            print("登录成功！")
            print("=" * 60)
            print(f"\nCookie 文件：{COOKIE_FILE}")
            print("\n使用方法：")
            print(f"  python quick_start.py --use-cookies")
            print("\n或在代码中加载：")
            print("  from nudt_library_search import LibrarySearch")
            print("  search = LibrarySearch(use_cookies=True)")
            print("=" * 60)
            
            return True
            
        except Exception as e:
            print(f"\n✗ 登录过程中发生错误：{e}")
            import traceback
            traceback.print_exc()
            return False


def load_cookies_from_file(cookie_file: str) -> Optional[Dict[str, str]]:
    """
    从文件加载 Cookie
    
    Args:
        cookie_file: Cookie 文件路径
        
    Returns:
        Cookie 字典，如果加载失败则返回 None
    """
    try:
        with open(cookie_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        if 'cookies' in data:
            return data['cookies']
        return None
        
    except Exception as e:
        print(f"加载 Cookie 失败：{e}")
        return None


def login_and_save_cookies(username: Optional[str] = None, 
                          password: Optional[str] = None,
                          cookie_file: Optional[str] = None,
                          headless: bool = False,
                          wait_time: int = 30) -> bool:
    """
    登录并保存 Cookie
    
    Args:
        username: 用户名
        password: 密码
        cookie_file: Cookie 文件路径（可选）
        headless: 是否无头模式
        wait_time: 等待时间（秒）
        
    Returns:
        是否成功
    """
    global COOKIE_FILE
    
    if cookie_file:
        COOKIE_FILE = Path(cookie_file)
    
    return login_with_installed_browser(
        username=username,
        password=password,
        headless=headless,
        wait_time=wait_time
    )


def main():
    """主函数"""
    import argparse
    
    parser = argparse.ArgumentParser(description="国防科技大学图书馆轻量级登录工具")
    parser.add_argument("-u", "--username", type=str, help="学号/用户名")
    parser.add_argument("-p", "--password", type=str, help="密码")
    parser.add_argument("--headless", action="store_true", help="使用无头模式")
    parser.add_argument("-t", "--time", type=int, default=300, help="等待时间（秒）")
    
    args = parser.parse_args()
    
    # 如果命令行提供了账号密码，使用命令行的
    username = args.username or USERNAME
    password = args.password or PASSWORD
    
    # 执行登录
    success = login_with_installed_browser(
        username=username,
        password=password,
        headless=args.headless,
        wait_time=args.time
    )
    
    if not success:
        exit(1)


if __name__ == "__main__":
    main()
