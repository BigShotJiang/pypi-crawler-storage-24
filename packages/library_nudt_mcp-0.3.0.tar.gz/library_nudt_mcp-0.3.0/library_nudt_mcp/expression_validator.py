"""
国防科技大学图书馆专业检索表达式验证器

根据编码规则验证检索表达式的正确性
"""

import re
from typing import List, Tuple, Optional
from dataclasses import dataclass
from enum import Enum


class ValidationLevel(Enum):
    """验证级别"""
    ERROR = "错误"
    WARNING = "警告"
    INFO = "提示"


@dataclass
class ValidationResult:
    """验证结果"""
    level: ValidationLevel
    message: str
    position: Optional[int] = None
    suggestion: Optional[str] = None
    
    def __str__(self) -> str:
        pos_str = f" (位置 {self.position})" if self.position else ""
        sug_str = f" 建议：{self.suggestion}" if self.suggestion else ""
        return f"[{self.level.value}]{pos_str}: {self.message}{sug_str}"


class ExpressionValidator:
    """检索表达式验证器"""
    
    # 字段代码定义
    VALID_FIELDS = {
        # 通用字段
        'T', 'A', 'K', 'S', 'O', 'Su', 'Z', 'Y', 'Clc', 'Sdc', 'Gdc',
        # 文献类型标识
        'BK', 'JN', 'DT', 'CP', 'PT', 'ST', 'VI', 'NP', 'TR', 'YB', 'LW', 'CA', 'RE', 'IF', 'GI', 'IMG',
        # 非通用字段
        'BKs', 'F', 'DTn', 'Tf', 'DTa', 'CPn', 'PTt', 'STd'
    }
    
    # 逻辑运算符
    LOGIC_OPERATORS = {'AND', 'OR', 'NOT'}
    
    # 同一字段内的运算符
    FIELD_OPERATORS = {'*', '|', '-'}
    
    # 匹配符号
    MATCH_SYMBOLS = {'"', "'"}
    
    # 比较运算符
    COMPARE_OPERATORS = {'<', '>', '<=', '>='}
    
    def __init__(self):
        self.errors: List[ValidationResult] = []
        self.warnings: List[ValidationResult] = []
        self.infos: List[ValidationResult] = []
    
    def validate(self, expression: str) -> bool:
        """
        验证检索表达式
        
        Args:
            expression: 检索表达式
            
        Returns:
            是否有效
        """
        self.errors = []
        self.warnings = []
        self.infos = []
        
        if not expression or not expression.strip():
            self.errors.append(ValidationResult(
                level=ValidationLevel.ERROR,
                message="检索表达式不能为空"
            ))
            return False
        
        # 1. 检查全角字符
        self._check_fullwidth_chars(expression)
        
        # 2. 检查括号匹配
        self._check_parentheses(expression)
        
        # 3. 检查字段代码
        self._check_field_codes(expression)
        
        # 4. 检查逻辑运算符
        self._check_logic_operators(expression)
        
        # 5. 检查字段内运算符
        self._check_field_operators(expression)
        
        # 6. 检查匹配符号
        self._check_match_symbols(expression)
        
        # 7. 检查年份范围格式
        self._check_year_range(expression)
        
        # 8. 检查文献类型前缀
        self._check_document_type_prefix(expression)
        
        # 9. 检查空格使用
        self._check_spacing(expression)
        
        # 输出验证结果
        self._print_results()
        
        return len(self.errors) == 0
    
    def _check_fullwidth_chars(self, expression: str):
        """检查是否包含全角字符"""
        # 匹配常见的全角字符（除了中文）
        fullwidth_pattern = r'[\uFF01-\uFF5E\u3000-\u303F]'
        matches = re.finditer(fullwidth_pattern, expression)
        
        for match in matches:
            char = match.group()
            self.errors.append(ValidationResult(
                level=ValidationLevel.ERROR,
                message=f"检测到全角字符 '{char}'，所有符号和英文字母必须使用英文半角字符",
                position=match.start(),
                suggestion=f"将 '{char}' 改为半角字符"
            ))
    
    def _check_parentheses(self, expression: str):
        """检查括号匹配"""
        stack = []
        for i, char in enumerate(expression):
            if char == '(':
                stack.append(i)
            elif char == ')':
                if not stack:
                    self.errors.append(ValidationResult(
                        level=ValidationLevel.ERROR,
                        message="右括号 ')' 没有匹配的左括号",
                        position=i
                    ))
                else:
                    stack.pop()
        
        if stack:
            for pos in stack:
                self.errors.append(ValidationResult(
                    level=ValidationLevel.ERROR,
                    message="左括号 '(' 没有匹配的右括号",
                    position=pos
                ))
    
    def _check_field_codes(self, expression: str):
        """检查字段代码"""
        # 匹配字段代码模式：字母开头，后跟等号
        field_pattern = r'\b([A-Za-z]+)='
        matches = re.finditer(field_pattern, expression)
        
        for match in matches:
            field_code = match.group(1)
            if field_code not in self.VALID_FIELDS:
                # 检查是否是文献类型前缀
                if field_code not in {'BK', 'JN', 'DT', 'CP', 'PT', 'ST', 'VI', 'NP', 'TR', 'YB', 'LW', 'CA', 'RE', 'IF', 'GI', 'IMG'}:
                    self.errors.append(ValidationResult(
                        level=ValidationLevel.ERROR,
                        message=f"无效的字段代码 '{field_code}'",
                        position=match.start(),
                        suggestion=f"有效的字段代码包括：{', '.join(sorted(self.VALID_FIELDS)[:10])} 等"
                    ))
    
    def _check_logic_operators(self, expression: str):
        """检查逻辑运算符"""
        # 检查逻辑运算符是否大写
        logic_lower_pattern = r'\b(and|or|not)\b'
        matches = re.finditer(logic_lower_pattern, expression, re.IGNORECASE)
        
        for match in matches:
            op = match.group(1)
            if op.islower():
                self.errors.append(ValidationResult(
                    level=ValidationLevel.ERROR,
                    message=f"逻辑运算符 '{op}' 必须使用大写",
                    position=match.start(),
                    suggestion=f"改为 '{op.upper()}'"
                ))
        
        # 检查逻辑运算符前后是否有空格
        for op in self.LOGIC_OPERATORS:
            pattern = r'(?<! )' + op + r'( )|( )' + op + r'(?! )'
            matches = re.finditer(pattern, expression)
            for match in matches:
                self.warnings.append(ValidationResult(
                    level=ValidationLevel.WARNING,
                    message=f"逻辑运算符 '{op}' 前后应该各有一个空格",
                    position=match.start()
                ))
    
    def _check_field_operators(self, expression: str):
        """检查字段内运算符"""
        # 检查同一字段内的运算符使用
        # 模式：字段=值 运算符 值
        field_op_pattern = r'([A-Za-z]+)=([^()|*\-ANDOR\s]+)([\*\|\-])([^()|*\-ANDOR\s]+)'
        matches = re.finditer(field_op_pattern, expression)
        
        for match in matches:
            field = match.group(1)
            op = match.group(3)
            
            # 检查运算符是否正确
            if op not in self.FIELD_OPERATORS:
                self.errors.append(ValidationResult(
                    level=ValidationLevel.ERROR,
                    message=f"无效的字段内运算符 '{op}'",
                    position=match.start(3),
                    suggestion="使用 '*' (与), '|' (或), '-' (非)"
                ))
    
    def _check_match_symbols(self, expression: str):
        """检查匹配符号"""
        # 检查引号是否成对
        single_quotes = expression.count("'")
        double_quotes = expression.count('"')
        
        if single_quotes % 2 != 0:
            self.errors.append(ValidationResult(
                level=ValidationLevel.ERROR,
                message="单引号不成对出现",
                suggestion="确保检索词两边的单引号成对"
            ))
        
        if double_quotes % 2 != 0:
            self.errors.append(ValidationResult(
                level=ValidationLevel.ERROR,
                message="双引号不成对出现",
                suggestion="确保检索词两边的双引号成对"
            ))
        
        # 检查包含空格的检索词是否有引号（排除逻辑运算符）
        # 更精确的模式：匹配字段=值，其中值包含空格但不在引号内
        space_word_pattern = r'([A-Z][A-Za-z]*)=([^"\'()|*<>\s]+(?:\s+(?!AND|OR|NOT)[^"\'()|*<>\s]+)+)'
        matches = re.finditer(space_word_pattern, expression)
        
        for match in matches:
            field = match.group(1)
            word = match.group(2)
            # 排除年份范围
            if re.match(r'\d{4}', word):
                continue
            self.warnings.append(ValidationResult(
                level=ValidationLevel.WARNING,
                message=f"检索词 '{word}' 包含空格，建议添加引号",
                position=match.start(2),
                suggestion=f"改为 {field}=\"{word}\" 或 {field}='{word}'"
            ))
    
    def _check_year_range(self, expression: str):
        """检查年份范围格式"""
        # 检查是否使用了错误的 >= 和 <=
        invalid_pattern = r'Y>=|Y<=|>=Y|<=Y'
        matches = re.finditer(invalid_pattern, expression)
        
        for match in matches:
            self.errors.append(ValidationResult(
                level=ValidationLevel.ERROR,
                message=f"年份范围不能使用 '{match.group()}'，请使用 '>' 或 '<'",
                position=match.start(),
                suggestion="年份范围使用 '2000<Y<2020' 格式，< 和 > 默认包含边界值"
            ))
        
        # 匹配年份范围模式
        year_pattern = r'(\d{4})<Y<(\d{4})|(\d{4})<Y|Y<(\d{4})|Y>(\d{4})'
        matches = re.finditer(year_pattern, expression)
        
        for match in matches:
            groups = match.groups()
            
            # 检查年份范围
            if groups[0] and groups[1]:
                start_year = int(groups[0])
                end_year = int(groups[1])
                
                if start_year > end_year:
                    self.errors.append(ValidationResult(
                        level=ValidationLevel.ERROR,
                        message=f"年份范围错误：起始年份 {start_year} 大于结束年份 {end_year}",
                        position=match.start()
                    ))
                
                if start_year < 1900 or end_year > 2100:
                    self.warnings.append(ValidationResult(
                        level=ValidationLevel.WARNING,
                        message=f"年份范围可能不合理：{start_year}-{end_year}",
                        position=match.start()
                    ))
    
    def _check_document_type_prefix(self, expression: str):
        """检查文献类型前缀"""
        # 匹配文献类型前缀模式
        prefix_pattern = r'^([A-Z]{2,3})\('
        match = re.match(prefix_pattern, expression)
        
        if match:
            prefix = match.group(1)
            valid_prefixes = {'BK', 'JN', 'DT', 'CP', 'PT', 'ST', 'VI', 'NP', 'TR', 'YB', 'LW', 'CA', 'RE', 'IF', 'GI', 'IMG'}
            
            if prefix not in valid_prefixes:
                self.warnings.append(ValidationResult(
                    level=ValidationLevel.WARNING,
                    message=f"文献类型前缀 '{prefix}' 可能不正确",
                    position=0,
                    suggestion=f"有效的前缀包括：{', '.join(sorted(valid_prefixes)[:5])} 等"
                ))
    
    def _check_spacing(self, expression: str):
        """检查空格使用"""
        # 检查逻辑运算符前后的空格
        for op in self.LOGIC_OPERATORS:
            # 检查是否缺少空格
            pattern = r'[^ ]' + op + r'[^ ]'
            matches = re.finditer(pattern, expression)
            for match in matches:
                self.warnings.append(ValidationResult(
                    level=ValidationLevel.WARNING,
                    message=f"逻辑运算符 '{op}' 前后应该有空格",
                    position=match.start()
                ))
    
    def _print_results(self):
        """打印验证结果"""
        print("=" * 60)
        print("检索表达式验证结果")
        print("=" * 60)
        
        if self.errors:
            print(f"\n❌ 错误 ({len(self.errors)}):")
            for error in self.errors:
                print(f"  {error}")
        
        if self.warnings:
            print(f"\n⚠️  警告 ({len(self.warnings)}):")
            for warning in self.warnings:
                print(f"  {warning}")
        
        if self.infos:
            print(f"\nℹ️  提示 ({len(self.infos)}):")
            for info in self.infos:
                print(f"  {info}")
        
        if not self.errors and not self.warnings:
            print("\n✅ 表达式格式正确！")
        
        print()
        print(f"总计：{len(self.errors)} 个错误，{len(self.warnings)} 个警告")
        print("=" * 60)


def validate_expression(expression: str) -> bool:
    """
    验证检索表达式的便捷函数
    
    Args:
        expression: 检索表达式
        
    Returns:
        是否有效
    """
    validator = ExpressionValidator()
    return validator.validate(expression)


# 测试示例
if __name__ == "__main__":
    print("示例 1: 正确的表达式")
    expr1 = 'JN((A=杨振宁|周培源 AND O=清华大学) OR A=钱学森 AND 2000<Y<2016 NOT K=断层)'
    validate_expression(expr1)
    
    print("\n示例 2: 包含全角字符的错误表达式")
    expr2 = 'A=钱学森 AND K＝人工智能'  # ＝是全角
    validate_expression(expr2)
    
    print("\n示例 3: 括号不匹配")
    expr3 = 'A=张士锋 AND (K=水资源'
    validate_expression(expr3)
    
    print("\n示例 4: 逻辑运算符小写")
    expr4 = 'A=张士锋 and K=水资源'
    validate_expression(expr4)
    
    print("\n示例 5: 年份范围错误")
    expr5 = '2020<Y<2010'
    validate_expression(expr5)
    
    print("\n示例 6: 检索词包含空格但未加引号")
    expr6 = 'K=machine learning'
    validate_expression(expr6)
    
    print("\n示例 7: 正确的复杂表达式")
    expr7 = "JN(O=(海 | 海洋)*(研究所 | 中心 | 学院) AND Su=海洋 AND 2000<Y<2016)"
    validate_expression(expr7)
