"""
国防科技大学图书馆检索结果解析器 v2

改进版：支持专利、图书、标准等多种文献类型
采用统一方法提取所有可读信息，去除样式/排版干扰
"""

import re
import json
from bs4 import BeautifulSoup
from typing import List, Dict, Any, Optional
from dataclasses import dataclass, asdict
from datetime import datetime


class SearchResult:
    """检索结果数据类"""
    def __init__(self, details: Optional[Dict[str, Any]] = None, raw_text: Optional[str] = None):
        self.details = details or {}
        self.raw_text = raw_text
    
    def to_dict(self) -> Dict[str, Any]:
        """转换为字典（排除 raw_text 和 None 字段）"""
        # details 已经是字典，直接使用
        result = dict(self.details) if self.details else {}
        
        # 移除 None 字段
        return {k: v for k, v in result.items() if v is not None}


class SearchResultsParser:
    """检索结果解析器 - 支持多种文献类型"""
    
    def __init__(self, html_content: str):
        """
        初始化解析器
        
        Args:
            html_content: 搜索结果 HTML 内容
        """
        self.html = html_content
        self.soup = BeautifulSoup(html_content, 'html.parser')
        self.results: List = []
        self.total_count: Optional[int] = None
        self.total_citation_count: Optional[int] = None
    
    def _clean_text(self, text: Optional[str]) -> str:
        """清理文本，去除多余空白和 HTML 标签"""
        if not text:
            return ""
        text = re.sub(r'<[^>]+>', '', text)
        text = re.sub(r'\s+', ' ', text).strip()
        return text
    
    def _extract_total_count(self):
        """提取总结果数和总被引频次"""
        # 兼容多种格式：
        # 1. 返回 <span class="red cur-search-count">100</span> 条结果
        # 2. 返回 <span class="red">0</span> 条结果（0 条结果时）
        # 3. 返回 <span>50</span> 条结果（无 class 属性）
        # 4. 数字可能包含千位分隔符，如 7,527
        patterns = [
            r'返回\s*<span[^>]*class="red cur-search-count"[^>]*>([\d,]+)</span>\s*条结果',
            r'返回\s*<span[^>]*class="red"[^>]*>([\d,]+)</span>\s*条结果',
            r'返回\s*<span[^>]*>([\d,]+)</span>\s*条结果',
        ]
        
        for pattern in patterns:
            match = re.search(pattern, self.html)
            if match:
                # 移除千位分隔符后转换为整数
                self.total_count = int(match.group(1).replace(',', ''))
                break
        
        citation_pattern = r'总被引频次：(\d+)次'
        citation_match = re.search(citation_pattern, self.html)
        if citation_match:
            self.total_citation_count = int(citation_match.group(1))
    
    def _find_result_items(self) -> List:
        """查找所有结果项"""
        items = []
        
        # 方法 1：查找 mainlist 下的所有 zyList 容器（推荐）
        mainlist = self.soup.find('div', id='mainlist')
        if mainlist:
            zylist_items = mainlist.find_all('div', class_='zyList')
            if zylist_items:
                return zylist_items
        
    
    def _extract_fields_from_ul(self, item) -> Dict[str, str]:
        """
        从 ul/li 结构中提取所有字段（统一方法）
        
        Returns:
            字段名到字段值的映射
        """
        fields = {}
        # 获取标题和文献类型和url
        # 找到第二个div
        src=item.find('div', class_='fr zyList_right', recursive=False)
        if src:
            title_div_src = src.find('div', class_='card_name', recursive=False)
            title_div=title_div_src.find('h3',recursive=False) if title_div_src else None
            if title_div:
                title_text = title_div.get_text()
                # 提取文献类型
                type_match = re.search(r'\[(.*?)\]', title_text)
                if type_match:
                    fields['文献类型'] = type_match.group(1)
                
                # 提取 URL
                a=title_div.find('a', href=True)
                if a:
                    href = a['href']
                    if 'detail' in href:
                        fields['detail_url'] = href if href.startswith('http') else 'https://fx.gfkd.chaoxing.com' + href
                    elif 'goread' in href:
                        fields['PDF下载URL'] = href if href.startswith('http') else 'https://fx.gfkd.chaoxing.com' + href
                    # 提取标题
                    fields['标题'] = a.get_text().strip()
            # 提取其他字段
            ul=src.find('ul',recursive=False)
            # 查找 ul 下的所有 li
            for li in ul.find_all('li',recursive=False):
                # 查找 span.col9（字段标签）
                label_span = li.find('span',recursive=False)
                if not label_span:
                    continue
                label = self._clean_text(label_span.get_text())
                if not label:
                    continue
                
                # 查找对应的值（div.zylist_font）
                value_div = li.find('div', class_='zylist_font')
                if value_div:
                    value = self._clean_text(value_div.get_text())
                    fields[label] = value
            
        return fields
    
    def parse(self) -> List[SearchResult]:
        """解析搜索结果"""
        self._extract_total_count()
        items = self._find_result_items()
        
        if items is not None:
            for item in items:
                try:
                    detail_fields = self._extract_fields_from_ul(item)
                    result = SearchResult(details=detail_fields, raw_text=str(item))
                    self.results.append(result)
                        
                except Exception as e:
                    print(f"解析结果项时出错：{e}")
                    continue
        data = {
            "page_count": len(self.results),
            "total_count": self.total_count,
            "results": [r.to_dict() for r in self.results]
        }
        
        return data
    def parse_details(self) -> Dict[str, Any]:
        """解析详情页"""
        # 实现详情页解析逻辑 .savelist_con
        src=self.soup.find('div', class_='savelist_con')
        items=src.find_all('dl',class_='card_line',recursive=False) if src else []
        results={}
        for item in items:
            try:
                # 提取字段
                dt=item.find('dt',recursive=False)
                dd=item.find('dd',recursive=False)
                if dt and dd:
                    label=self._clean_text(dt.get_text())
                    value=self._clean_text(dd.get_text())
                    results[label] = value
            except Exception as e:
                print(f"解析详情项时出错：{e}")
                continue

        return results

    def to_json(self, indent: int = 2, ensure_ascii: bool = False) -> str:
        """导出为 JSON"""
        data = {
            "page_count": len(self.results),
            "total_count": self.total_count,
            "results": [r.to_dict() for r in self.results]
        }
        print(f"提取字段：{data}")
        return json.dumps(data, indent=indent, ensure_ascii=ensure_ascii)


def parse_search_results(html_file: str, output_file: Optional[str] = None) -> List[Dict[str, Any]]:
    """便捷函数：解析搜索结果"""
    with open(html_file, 'r', encoding='utf-8') as f:
        html = f.read()
    
    ParserClass = SearchResultsParser
    parser = ParserClass(html)
    results = parser.parse()
    print(f"提取字段：{results}")
    
    if output_file:
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(parser.to_json())
    
    return results['results']


if __name__ == '__main__':
    """测试代码"""
    import sys
    
    print('=' * 60)
    print('search_result_parser.py 测试')
    print('=' * 60)
    
    # 测试文件
    test_files = [
        ("混合文献（期刊 + 专利）", "cache/search_result_A=张士峰_AND_O='国防科技大学'|'国防科学技术大学'.html"),
        ("专利文献", "cache/search_result_PT(A=张士峰_AND_O='国防科技大学'|'国防科学技术大学').html"),
    ]
    
    for test_name, test_file in test_files:
        print(f'\n【测试】{test_name}')
        print('-' * 60)
        
        try:
            # 解析
            results = parse_search_results(test_file,"cache/parsed_result.json")
            
            print(f'解析结果：{len(results)} 条')
            
            if results:
                # 显示第 1 条
                first = results[0]
                print(f'\n第 1 条结果:')
                print(f'  标题：{first.get("标题", "N/A")[:50]}')
                print(f'  文献类型：{first.get("文献类型", "N/A")}')
                print(f'  作者/发明人：{first.get("作者", first.get("发明人", "N/A"))[:50] if first.get("作者") or first.get("发明人") else "N/A"}')
                print(f'  出处/申请号：{first.get("出处", first.get("申请号", "N/A"))[:50] if first.get("出处") or first.get("申请号") else "N/A"}')
                
                # 如果有专利，显示专利字段
                if first.get('文献类型') == '专利':
                    print(f'\n专利字段:')
                    for key in ['发明人', '申请号', '申请日期', '公开号', '申请人', '专利类型', '分类号']:
                        value = first.get(key, 'N/A')
                        if value and value != 'N/A':
                            print(f'  {key}: {value[:50] if isinstance(value, str) else value}')
            
            print()
            
        except FileNotFoundError:
            print(f'✗ 文件不存在：{test_file}')
        except Exception as e:
            print(f'✗ 错误：{e}')
            import traceback
            traceback.print_exc()
    
    print('=' * 60)
