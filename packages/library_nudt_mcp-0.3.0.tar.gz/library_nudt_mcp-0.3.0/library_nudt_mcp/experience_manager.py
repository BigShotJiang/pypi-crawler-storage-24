"""
检索经验管理模块

用于保存和查询检索经验，帮助优化检索策略
"""

import json
from pathlib import Path
from typing import List, Dict, Any, Optional
from datetime import datetime
from dataclasses import dataclass, asdict
import re


@dataclass
class SearchExperience:
    """检索经验数据类"""
    id: int  # 经验 ID
    user_need: str  # 用户需求描述
    search_expression: str  # 检索表达式
    result_count: int  # 结果数量
    lessons_learned: str  # 经验教训总结
    keywords: List[str]  # 提取的关键词
    timestamp: str  # 时间戳
    success: bool = True  # 是否成功检索
    notes: str = ""  # 额外备注


class ExperienceManager:
    """经验管理器"""
    
    def __init__(self, cache_dir: Path = None):
        """
        初始化经验管理器
        
        Args:
            cache_dir: 缓存目录，默认为 cache/
        """
        self.cache_dir = cache_dir or Path("cache")
        self.cache_dir.mkdir(exist_ok=True)
        self.experience_file = self.cache_dir / "experience.md"
        self.experience_index_file = self.cache_dir / "experience_index.json"
        
        # 初始化经验 ID 计数器
        self._init_id_counter()
    
    def _init_id_counter(self):
        """初始化 ID 计数器"""
        if not self.experience_index_file.exists():
            self._save_index({"next_id": 1, "total_count": 0})
    
    def _load_index(self) -> Dict[str, Any]:
        """加载索引文件"""
        if self.experience_index_file.exists():
            with open(self.experience_index_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        return {"next_id": 1, "total_count": 0}
    
    def _save_index(self, index: Dict[str, Any]):
        """保存索引文件"""
        with open(self.experience_index_file, 'w', encoding='utf-8') as f:
            json.dump(index, f, indent=2, ensure_ascii=False)
    
    def _extract_keywords(self, text: str) -> List[str]:
        """
        从文本中提取关键词
        
        Args:
            text: 输入文本
            
        Returns:
            关键词列表
        """
        # 简单的中文关键词提取（按标点符号分割）
        # 可以改进为使用更智能的分词算法
        keywords = re.split(r'[，。；、？！,\.\?!;\s]+', text)
        # 过滤掉空字符串和过短的词
        keywords = [k.strip() for k in keywords if len(k.strip()) > 1]
        return keywords[:10]  # 限制最多 10 个关键词
    
    def save_experience(self, 
                       user_need: str,
                       search_expression: str,
                       result_count: int,
                       lessons_learned: str,
                       notes: str = "",
                       success: bool = True) -> SearchExperience:
        """
        保存检索经验
        
        Args:
            user_need: 用户需求描述
            search_expression: 检索表达式
            result_count: 结果数量
            lessons_learned: 经验教训总结
            notes: 额外备注
            success: 是否成功检索
            
        Returns:
            保存的经验对象
        """
        # 获取并更新 ID
        index = self._load_index()
        exp_id = index["next_id"]
        index["next_id"] += 1
        index["total_count"] += 1
        self._save_index(index)
        
        # 创建经验对象
        # 合并用户需求和检索表达式作为关键词来源
        keywords_text = f"{user_need} {search_expression}"
        experience = SearchExperience(
            id=exp_id,
            user_need=user_need,
            search_expression=search_expression,
            result_count=result_count,
            lessons_learned=lessons_learned,
            keywords=self._extract_keywords(keywords_text),
            timestamp=datetime.now().isoformat(),
            success=success,
            notes=notes
        )
        
        # 追加到 Markdown 文件
        self._append_to_markdown(experience)
        
        return experience
    
    def _append_to_markdown(self, experience: SearchExperience):
        """将经验追加到 Markdown 文件"""
        # 如果文件不存在，先写入标题
        if not self.experience_file.exists():
            with open(self.experience_file, 'w', encoding='utf-8') as f:
                f.write("# 检索经验总结\n\n")
                f.write("本文档记录了检索过程中的经验教训，用于优化后续检索策略。\n\n")
                f.write("---\n\n")
        
        # 追加经验记录
        with open(self.experience_file, 'a', encoding='utf-8') as f:
            f.write(f"## 经验 #{experience.id}\n\n")
            f.write(f"**时间**: {experience.timestamp}\n\n")
            f.write(f"**用户需求**: {experience.user_need}\n\n")
            f.write(f"**检索表达式**: `{experience.search_expression}`\n\n")
            f.write(f"**结果数量**: {experience.result_count}\n\n")
            f.write(f"**关键词**: {', '.join(experience.keywords)}\n\n")
            f.write(f"**经验教训**:\n{experience.lessons_learned}\n\n")
            if experience.notes:
                f.write(f"**备注**: {experience.notes}\n\n")
            f.write(f"**状态**: {'✓ 成功' if experience.success else '✗ 失败'}\n\n")
            f.write("---\n\n")
    
    def search_experiences(self,
                          keywords: Optional[str] = None,
                          start_line: int = 1,
                          end_line: Optional[int] = None,
                          min_results: Optional[int] = None,
                          max_results: Optional[int] = None,
                          success_only: bool = False,
                          limit: int = 20) -> List[SearchExperience]:
        """
        搜索经验记录
        
        Args:
            keywords: 关键词（空格分隔多个关键词）
            start_line: 开始行号（用于分页）
            end_line: 结束行号（用于分页）
            min_results: 最小结果数
            max_results: 最大结果数
            success_only: 只返回成功的经验
            limit: 返回数量限制
            
        Returns:
            经验记录列表
        """
        if not self.experience_file.exists():
            return []
        
        # 读取所有经验记录
        experiences = self._load_all_experiences()
        
        # 过滤
        filtered = []
        for exp in experiences:
            # 按成功状态过滤
            if success_only and not exp.success:
                continue
            
            # 按结果数量过滤
            if min_results is not None and exp.result_count < min_results:
                continue
            if max_results is not None and exp.result_count > max_results:
                continue
            
            # 按关键词过滤
            if keywords:
                keyword_list = keywords.lower().split()
                text_to_search = f"{exp.user_need} {exp.search_expression} {' '.join(exp.keywords)}".lower()
                if not any(kw in text_to_search for kw in keyword_list):
                    continue
            
            filtered.append(exp)
        
        # 分页
        if start_line > 0:
            filtered = filtered[start_line - 1:]
        if end_line is not None:
            filtered = filtered[:end_line - start_line + 1]
        
        # 限制数量
        filtered = filtered[:limit]
        
        return filtered
    
    def _load_all_experiences(self) -> List[SearchExperience]:
        """从 Markdown 文件加载所有经验记录"""
        if not self.experience_file.exists():
            return []
        
        experiences = []
        with open(self.experience_file, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # 使用正则表达式解析每个经验块
        pattern = r'## 经验 #(\d+)\n\n\*\*时间\*\*: (.+?)\n\n\*\*用户需求\*\*: (.+?)\n\n\*\*检索表达式\*\*: `(.+?)`\n\n\*\*结果数量\*\*: (\d+)\n\n\*\*关键词\*\*: (.+?)\n\n\*\*经验教训\*\*:\n(.+?)\n\n(?:\*\*备注\*\*: (.+?)\n\n)?\*\*状态\*\*: (✓ 成功|✗ 失败)\n\n---'
        
        matches = re.finditer(pattern, content, re.DOTALL)
        for match in matches:
            try:
                exp = SearchExperience(
                    id=int(match.group(1)),
                    timestamp=match.group(2).strip(),
                    user_need=match.group(3).strip(),
                    search_expression=match.group(4).strip(),
                    result_count=int(match.group(5)),
                    keywords=[k.strip() for k in match.group(6).split(',')],
                    lessons_learned=match.group(7).strip(),
                    notes=match.group(8).strip() if match.group(8) else "",
                    success=(match.group(9) == '✓ 成功')
                )
                experiences.append(exp)
            except (ValueError, IndexError):
                # 解析失败，跳过
                continue
        
        return experiences
    
    def get_experience_by_id(self, exp_id: int) -> Optional[SearchExperience]:
        """
        根据 ID 获取经验
        
        Args:
            exp_id: 经验 ID
            
        Returns:
            经验对象，如果不存在则返回 None
        """
        experiences = self._load_all_experiences()
        for exp in experiences:
            if exp.id == exp_id:
                return exp
        return None
    
    def get_statistics(self) -> Dict[str, Any]:
        """
        获取统计信息
        
        Returns:
            统计信息字典
        """
        experiences = self._load_all_experiences()
        
        if not experiences:
            return {
                "total_count": 0,
                "success_count": 0,
                "failure_count": 0,
                "avg_result_count": 0,
                "success_rate": 0
            }
        
        success_count = sum(1 for e in experiences if e.success)
        total_results = sum(e.result_count for e in experiences)
        
        return {
            "total_count": len(experiences),
            "success_count": success_count,
            "failure_count": len(experiences) - success_count,
            "avg_result_count": round(total_results / len(experiences), 2),
            "success_rate": round(success_count / len(experiences) * 100, 2)
        }
    
    def export_to_json(self, output_file: Optional[str] = None) -> str:
        """
        导出为 JSON 格式
        
        Args:
            output_file: 输出文件路径（可选）
            
        Returns:
            JSON 字符串
        """
        experiences = self._load_all_experiences()
        data = {
            "total_count": len(experiences),
            "experiences": [asdict(e) for e in experiences]
        }
        
        json_str = json.dumps(data, indent=2, ensure_ascii=False)
        
        if output_file:
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(json_str)
        
        return json_str


# 便捷函数
def save_search_experience(user_need: str,
                          search_expression: str,
                          result_count: int,
                          lessons_learned: str,
                          notes: str = "",
                          cache_dir: Path = None) -> SearchExperience:
    """
    便捷函数：保存检索经验
    
    Args:
        user_need: 用户需求描述
        search_expression: 检索表达式
        result_count: 结果数量
        lessons_learned: 经验教训总结
        notes: 额外备注
        cache_dir: 缓存目录
        
    Returns:
        保存的经验对象
    """
    manager = ExperienceManager(cache_dir)
    return manager.save_experience(
        user_need=user_need,
        search_expression=search_expression,
        result_count=result_count,
        lessons_learned=lessons_learned,
        notes=notes
    )


def search_search_experiences(keywords: Optional[str] = None,
                             limit: int = 20,
                             cache_dir: Path = None) -> List[Dict[str, Any]]:
    """
    便捷函数：搜索检索经验
    
    Args:
        keywords: 关键词
        limit: 返回数量限制
        cache_dir: 缓存目录
        
    Returns:
        经验记录列表（字典格式）
    """
    manager = ExperienceManager(cache_dir)
    experiences = manager.search_experiences(keywords=keywords, limit=limit)
    return [asdict(e) for e in experiences]
