# library-nudt-mcp

国防科技大学图书馆 MCP 服务器 - 提供学术资源检索功能

## 功能特性

- 🔍 专业的学术资源检索
- 📚 支持多种文献类型（图书、期刊、专利、标准等）
- 🎯 精确的检索表达式验证
- 🔐 安全的 Cookie 管理
- 🚀 基于 FastMCP 框架

## 安装

```bash
pip install library-nudt-mcp
```

## 快速开始

### 1. 作为 MCP 服务器使用

在 VS Code 的 MCP 配置中添加：

```json
{
  "servers": {
    "libnudt": {
      "command": "uv",
      "args": [
        "run",
        "--with",
        "library-nudt-mcp",
        "library-nudt-mcp"
      ]
    }
  }
}
```

### 2. 作为 Python 库使用

```python
from library_nudt_mcp import nudt_search, nudt_get_help

# 获取帮助信息
help_info = nudt_get_help()
print(help_info)

# 执行检索
result = nudt_search(expression="A='张三'", page=1, size=20)
print(result)
```

## 检索表达式语法

### 字段代码

- `T` - 标题
- `A` - 作者
- `K` - 关键词
- `S` - 摘要
- `O` - 作者单位
- `Y` - 年份

### 逻辑运算符

- `AND` - 与（并且）
- `OR` - 或（或者）
- `NOT` - 非（不包含）

### 示例

```python
# 简单检索
nudt_search("A='张三'")

# 多条件检索
nudt_search("A='张三' AND K='水资源'")

# 年份范围
nudt_search("A='张三' AND 2000<Y<2020")

# 复杂检索
nudt_search("JN(A=杨振宁|周培源 AND O=清华大学)")
```

## 开发

```bash
# 克隆仓库
git clone https://github.com/yourusername/library-nudt-mcp.git
cd library-nudt-mcp

# 安装开发依赖
pip install -e ".[dev]"

# 运行测试
pytest

# 代码格式化
black library_nudt_mcp
```

## 发布到 PyPI

```bash
# 安装构建工具
pip install build twine

# 构建分发包
python -m build

# 上传到 PyPI
twine upload dist/*
```

## 许可证

MIT License

## 作者

Your Name <your.email@example.com>

## 贡献

欢迎提交 Issue 和 Pull Request！
