from setuptools import setup, find_packages

setup(
    name='money1',
    version='0.1',
    packages=find_packages(),
    description='Simple finance utilities package',
    author='o',
    classifiers=[
        'Programming Language :: Python :: 3',
    ],
)