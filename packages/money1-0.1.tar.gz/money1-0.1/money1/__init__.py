def topics():
    return [
        "sip",
        "emi",
        "interest",
        "tax",
        "extra"
    ]


def get_text(topic=None):
    data = {
        "sip": """# SIP Calculator
P = 1000  # monthly investment
r = 0.12 / 12
n = 12 * 5

future_value = P * (((1 + r)**n - 1) / r) * (1 + r)
print("Future Value:", future_value)
""",

        "emi": """# EMI Calculator
P = 500000
r = 0.08 / 12
n = 60

emi = (P * r * (1 + r)**n) / ((1 + r)**n - 1)
print("EMI:", emi)
""",

        "interest": """# Simple Interest
P = 10000
R = 5
T = 2

SI = (P * R * T) / 100
print("Simple Interest:", SI)
""",

        "tax": """# Basic Tax Example
income = 500000

if income < 250000:
    tax = 0
elif income < 500000:
    tax = income * 0.05
else:
    tax = income * 0.2

print("Tax:", tax)
""",

        "extra": """# Extra Notes
You can add your custom financial calculations here.
"""
    }

    if topic is None:
        return "Use money1.topics() to see available topics"

    topic = topic.lower()
    return data.get(topic, f"No data for topic: {topic}")