# -*- coding: utf-8 -*-
from pathlib import Path

from qtpy.QtCore import Qt, QSize
from qtpy.QtGui import QIcon, QPixmap


PACKAGE_DIR = Path(__file__).resolve().parents[1]


def create_path(folder: str, filename: str) -> str:
    """Builds a path to the image file."""
    return str(PACKAGE_DIR.joinpath("static", "icons", folder, filename))


def empty_icon(size: QSize = QSize(32, 32)) -> QIcon:
    pixmap = QPixmap(size)
    pixmap.fill(Qt.transparent)  # Make the pixmap transparent
    return QIcon(pixmap)


icons = dict(
    # Icons from href="https://www.flaticon.com/

    # MAIN
    ab = create_path("main", "activitybrowser.png"),

    # arrows
    right = create_path("main", "right.png"),
    left = create_path("main", "left.png"),
    forward = create_path("main", "forward.png"),
    backward = create_path("main", "backward.png"),

    # Simple actions
    delete = create_path("context", "delete.png"),
    clear = create_path("context", "clear.png"),
    copy = create_path("context", "copy.png"),
    add = create_path("context", "add.png"),
    edit = create_path("main", "edit.png"),
    calculate = create_path("main", "calculate.png"),
    question = create_path("context", "question.png"),
    search = create_path("main", "search.png"),
    filter = create_path("main", "filter.png"),
    filter_outline = create_path("main", "filter_outline.png"),

    # database
    import_db = create_path("main", "import_database.png"),
    duplicate_database = create_path("main", "duplicate_database.png"),

    # activity
    duplicate_activity = create_path("main", "duplicate_activity.png"),
    duplicate_to_other_database = create_path("main", "import_database.png"),
    parameterized = create_path("main", "parameterized.png"),

    # windows
    graph_explorer = create_path("main", "graph_explorer.png"),
    issue = create_path("main", "idea.png"),
    settings = create_path("main", "settings.png"),
    history = create_path("main", "history.png"),
    welcome = create_path("main", "welcome.png"),
    main_window = create_path("main", "home.png"),

    # plugins
    plugin = create_path("main", "plugin.png"),

    # nodes
    process = create_path("nodes", "process.png"),
    product = create_path("nodes", "product.png"),
    waste = create_path("nodes", "waste.png"),
    processproduct = create_path("nodes", "processproduct.png"),
    biosphere = create_path("nodes", "biosphere.png"),
    readonly_process = create_path("nodes", "read-only-process.png"),

    # exchanges
    link = create_path("exchanges", "link.png"),
    unlink = create_path("exchanges", "unlink.png"),
    relink = create_path("exchanges", "relink.png"),

    # other
    superstructure = create_path("main", "superstructure.png"),
    copy_to_clipboard = create_path("main", "copy_to_clipboard.png"),
    warning = create_path("context", "warning.png"),
    critical = create_path("context", "critical.png"),
    locked = create_path("main", "locked.png"),
    unlocked = create_path("main", "unlocked.png"),
    star = create_path("main", "star.png"),
)


class QIcons:
    """Lazily loads QIcon instances only when accessed."""
    def __getattribute__(self, name):
        if name == 'empty':
            return empty_icon()
        elif name in icons:
            if name not in _initialized_icons:
                _initialized_icons[name] = QIcon(icons[name])
            return _initialized_icons[name]
        else:
            raise AttributeError(f"QIcons has no icon '{name}'")

_initialized_icons = {}
qicons = QIcons()

