from loguru import logger

from activity_browser import app
from activity_browser.app.actions.base import ABAction, exception_dialogs
from activity_browser.ui.icons import qicons
from activity_browser.ui.core.application import global_shortcut

from .activity.activity_open import ActivityOpen

class NodeSelectOpen(ABAction):

    icon = qicons.search
    text = "Search project"

    @staticmethod
    @global_shortcut("Ctrl+Shift+F")
    @exception_dialogs
    def run():
        from activity_browser.app import dialogs
        dialog = dialogs.NodeSelectDialog(parent=app.main_window, drag_enabled=True)

        dialog.exec_()
        if dialog.result() != dialog.DialogCode.Accepted:
            return

        selected_node = dialog.get_selected_node()
        if selected_node:
            logger.debug(f"Opening node: {selected_node}")
            ActivityOpen.run([selected_node])