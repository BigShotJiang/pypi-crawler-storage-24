from ase.constraints import FixAtoms as ASE_FixAtoms
from ase.filters import Filter as ASE_Filter
from ase.constraints import FixCom as ASE_FixCom
import numpy as np
from ase.parallel import world

class ConstraintMixin:
    """Mixin class FixAtoms and Filter"""
         
    def start_asap_dynamics(self, atoms):
        """Prepare this constraint for optimized Asap dynamics
        
        This function must be called when parallel dynamics start running for
        all dynamics supporting parallel MD.
        """
        # Store the arrays of the atoms, not the atoms, to prevent cyclic references.
        if getattr(atoms, "parallel", False):
            assert not self.asap_ready
            self.atoms_arrays = atoms.arrays
            assert self.indexname not in self.atoms_arrays
            idx = self.index   # Reads constraint from this object
            self.asap_ready = True
            self.storable = False
            self.index = idx   # Stores constraint on atoms object
            del self._index
            assert self.indexname in self.atoms_arrays

    def end_asap_dynamics(self, atoms):
        """Undo what start_asap_dynamics() did.

        This function must be called when parallel dynamics stop running.
        """
        if getattr(atoms, "parallel", False):
            assert self.asap_ready
            assert self.indexname in self.atoms_arrays
            idx = self.index   # Reads constraint from atoms
            self.asap_ready = False
            del self.atoms_arrays[self.indexname]
            self.index = idx   # Stores constraint in this object
            assert hasattr(self, '_index')
        
    def set_index(self, idx):
        if self.asap_ready:
            natoms = len(self.atoms_arrays['positions'])
            if idx.dtype == bool:
                # Boolean - must be a mask
                assert len(idx) == natoms
            else:
                # Must be a list of indices.  Convert to a mask
                idx2 = np.zeros(natoms, bool)
                idx2[idx] = True
                idx = idx2
            self.atoms_arrays[self.indexname] = idx
        else:
            self._index = idx
            
    def get_index(self):
        if self.asap_ready:
            return self.atoms_arrays[self.indexname]
        else:
            return self._index

    def todict(self):
        "Convert to dictionary for storage in e.g. a Trajectory object."
        if not self.storable:
            raise RuntimeError(
                f"Cannot store asap3.{self.dictname} constraint in parallel simulations.")
        idx = self.index
        if idx.dtype == bool:
            return {'name': self.dictname,
                    'kwargs': {'mask': idx}}
        else:
            return {'name': self.dictname,
                    'kwargs': {'indices': idx}}
                
class FixAtoms(ConstraintMixin, ASE_FixAtoms):
    dictname = 'FixAtoms'  # Name used when converting to dictionary.
    def __init__(self, indices=None, mask=None):
        self.pre_init()
        ASE_FixAtoms.__init__(self, indices=indices, mask=mask)
        
    def pre_init(self):
        self.indexname = "FixAtoms_index"
        self.asap_ready = False
        self.storable = True
        
    def copy(self):
        if self.index.dtype == bool:
            return FixAtoms(mask=self.index.copy())
        else:
            return FixAtoms(indices=self.index.copy())

    def get_removed_dof(self, atoms):
        if self.index.dtype == bool:
            return 3 * int(len(self.index) - self.index.sum())
        else:
            return 3 * len(self.index)
        
    def __get_state__(self):
        return {'data': self.index,
                'version': 1}
        
    def __set_state__(self, state):
        try:
            assert(state['version'] == 1)
        except KeyError:
            print(state)
            raise
        self.pre_init()
        self.index = state['data']
        
    index = property(ConstraintMixin.get_index, ConstraintMixin.set_index)
    
    
class Filter(ASE_Filter):
    dictname = 'Filter'  # Name used when converting to dictionary.
    def __init__(self, atoms, indices=None, mask=None):
        """Filter atoms.

        This filter can be used to hide degrees of freedom in an Atoms
        object.

        Parameters
        ----------
        indices : list of int
           Indices for those atoms that should remain visible.
        mask : list of bool
           One boolean per atom indicating if the atom should remain
           visible or not.
        """

        self.indexname = "Filter_index"
        if getattr(atoms, "parallel", False):
            assert self.indexname not in atoms.arrays
            self.asap_ready = True
            self.storable = False
        else:
            self.asap_ready = False
        ASE_Filter.__init__(self, atoms, indices, mask)
        
    def set_index(self, idx):
        if self.asap_ready:
            natoms = len(self.atoms.arrays['positions'])
            if idx.dtype == bool:
                # Boolean - must be a mask
                assert len(idx) == natoms
            else:
                # Must be a list of indices.  Convert to a mask
                idx2 = np.zeros(natoms, bool)
                idx2[idx] = True
                idx = idx2
            self.atoms.arrays[self.indexname] = idx
        else:
            self._index = idx

    def get_index(self):
        if self.asap_ready:
            return self.atoms.arrays[self.indexname]
        else:
            return self._index

    index = property(get_index, set_index)
    

class FixCom(ASE_FixCom):
    """Constraint class for fixing the center of mass."""
    def adjust_positions(self, atoms, new):
        masses = atoms.get_masses()
        old_pos_sum = masses @ atoms.get_positions()
        new_pos_sum = masses @ new
        msum = masses.sum()
        # Communicate in one shot
        if hasattr(atoms, 'comm') and atoms.comm.size > 1:
            data = np.zeros(7)
            data[0:3] = old_pos_sum
            data[3:6] = new_pos_sum
            data[6] = msum
            atoms.comm.sum(data)
            old_pos_sum = data[0:3]
            new_pos_sum = data[3:6]
            msum = data[6]
        old_cm = old_pos_sum / msum
        new_cm = new_pos_sum / msum
        diff = old_cm - new_cm
        new += diff

    def adjust_momenta(self, atoms, momenta):
        """Adjust momenta so that the center-of-mass velocity is zero."""
        masses = atoms.get_masses()
        msum = masses.sum()
        momenta_sum = momenta.sum(axis=0)
        # Communicate in one shot
        if hasattr(atoms, 'comm') and atoms.comm.size > 1:
            data = np.zeros(4)
            data[0:3] = momenta_sum
            data[3] = msum
            atoms.comm.sum(data)
            momenta_sum = data[0:3]
            msum = data[3]
        velocity_com = momenta_sum / msum
        momenta[self.index] -= masses[:, None] * velocity_com

    def adjust_forces(self, atoms, forces):
        # Eqs. (3) and (7) in https://doi.org/10.1021/jp9722824
        masses = atoms.get_masses()
        sum_sq_masses = sum(masses**2)
        if hasattr(atoms, 'comm') and atoms.comm.size > 1:
            sum_sq_masses = atoms.comm.sum(sum_sq_masses)
        lmd = masses @ forces / sum_sq_masses
        forces[self.index] -= masses[:, None] * lmd

    def start_asap_dynamics(self, *args, **kwargs):
        pass

    def end_asap_dynamics(self, *args, **kwargs):
        pass

    def get_removed_dof(self, atoms):
        # Report removed DOFs on master only
        if world.rank == 0:
            return 3
        else:
            return 0

def check_asap_constraints(atoms, allowed=None):
    """Check that atoms only have a single allowed constraint.

    Returns True if atoms has at most a single allowed constraint.
    Returns False if atoms has non-allowed constraints or more than
    one constraint.

    An optional second parameter can be a tuple of allowed constraints.
    """
    if allowed is None:
        allowed = (FixAtoms,)
        
    if len(atoms.constraints) == 0:
        return True
    if len(atoms.constraints) > 1:
        return False
    return isinstance(atoms.constraints[0], allowed)

