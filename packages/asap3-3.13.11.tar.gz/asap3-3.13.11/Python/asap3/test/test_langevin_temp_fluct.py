"""Test Langevin temperature distribution.

The instantaneous temperature in the NVT ensemble follows a Gamma
distribution, so T_instantaneous / T follows
  Gamma(alpha=Nf/2, theta=2/Nf)
where Nf is the number of degrees of freedom.

The Gamma distribution has these properties:
Mean:      alpha * theta    = 1
Variance:  alpha * theta**2 = 2 / Nf
Skewness:  2 / sqrt(alpha)  = 2 sqrt(2) / sqrt(Nf)

This is tested here, both with a tiny free system, with
the center of mass fixed by a FixCom constraint, and with
half the atoms fixed with a FixAtoms constraint.

The test is done both in serial and parallel.
"""

from asap3 import Atoms, EMT, MakeParallelAtoms
from asap3.md.langevin import Langevin
# from asap3.md.velocitydistribution import MaxwellBoltzmannDistribution, Stationary
from asap3.constraints import FixAtoms, FixCom
from ase import units
from ase.build import bulk
from ase.parallel import world

import numpy as np

import pytest

# Parameters
Natoms = 4
dt = 2.5  # fs

Ntau = 50  # timesteps
Nequi = Ntau * 10
Nsimul = Ntau * 2000
Nlog = 20000
Nsample = 5


@pytest.fixture
def atoms():
    atoms = bulk('CuAg', 'rocksalt', a=4.0, cubic=True)
    atoms = atoms[(0, 1, 2, 5)]  # Picks two of each element
    atoms.pbc = False
    atoms.center(vacuum=20.0)
    atoms.pbc = True
    atoms.set_tags(np.arange(len(atoms)))
    return atoms

class Thermometer:
    def __init__(self):
        self.T = []
        self.Ekin = []
    def __call__(self, atoms):
        self.T.append(atoms.get_temperature())
        self.Ekin.append(atoms.get_kinetic_energy())
    def get_data(self):
        return np.array(self.T), np.array(self.Ekin)

@pytest.mark.skipif(world.size not in (1, 2, 4), reason='Number of cores must be 1, 2 or 4')
@pytest.mark.parametrize('variant', ('Free', 'FixCom', 'FixAtoms'))
@pytest.mark.parametrize('forceASE', (False, True))
def test_langevin_T_fluct(atoms, cpulayout, variant, forceASE):
    T = 300
    print(f'Langevin temperature test, T={T} K, constraint={variant}, forceASE={forceASE}')
    assert len(atoms) == Natoms
    if cpulayout:
        if world.rank > 0:
            atoms = None
        atoms = MakeParallelAtoms(atoms, cpulayout)
    else:
        atoms = Atoms(atoms)

    atoms.calc = EMT()
    print('Initial potential energy:', atoms.get_potential_energy())
    frict = 1/(Ntau * dt * units.fs)
    print('Langevin friction:', frict)
    
    # Set constraints        
    if variant == 'Free':
        ndof = Natoms * 3
    elif variant == 'FixCom':
        ndof = Natoms * 3 - 3
        atoms.set_constraint(FixCom())
    elif variant == 'FixAtoms':
        ndof = (Natoms - 2) * 3
        mask = atoms.get_tags() < 2
        atoms.set_constraint(FixAtoms(mask=mask))

    # Thermalize
    dyn = Langevin(atoms, dt * units.fs, temperature_K=T, friction=frict,
                   logfile='-', loginterval=Nlog, forceASE=forceASE)
    dyn.run(Nequi)

    print('Taking data')
    # Take data
    thermometer = Thermometer()
    dyn.attach(thermometer, Nsample, atoms)
    dyn.run(Nsimul)

    tdata, edata= thermometer.get_data()
    tdata /= T
    print(len(tdata), tdata.mean())

    tmean = tdata.mean()
    tmean_exp = 1.0
    tvar = tdata.var()
    tvar_exp = 2 / ndof
    tskew = np.mean( (tdata-tmean)**3 / tvar**1.5 )
    tskew_exp = 2 * np.sqrt(2 / ndof)

    emean = edata.mean()
    emean_exp = ndof / 2 * units.kB * T

    print()
    print('TEMPERATURE')
    print(f'Mean:     {tmean:.4f}  - expected {tmean_exp:.4f}  - error {(tmean - tmean_exp) / tmean_exp:.3f}')
    print(f'Variance: {tvar:.4f}  - expected {tvar_exp:.4f}  - error {(tvar - tvar_exp) / tvar_exp:.3f}')
    print(f'Skewness: {tskew:.4f}  - expected {tskew_exp:.4f}  - error {(tskew - tskew_exp) / tskew_exp:.3f}')
    print()
    print('KINETIC ENERGY')
    print(f'Mean:     {emean:.4f}  - expected {emean_exp:.4f}  - error {(emean - emean_exp) / emean_exp:.3f}')
    print()

    assert atoms.get_number_of_degrees_of_freedom() == ndof
    assert np.isclose(tmean, tmean_exp, rtol=0.05)
    assert np.isclose(tvar, tvar_exp, rtol=0.15)
    assert np.isclose(tskew, tskew_exp, rtol=0.25)
    assert np.isclose(emean, emean_exp, rtol=0.05)
