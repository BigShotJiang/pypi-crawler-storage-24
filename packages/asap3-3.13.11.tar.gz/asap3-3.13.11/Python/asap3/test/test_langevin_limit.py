'Test that Langevin becomes velocity verlet in the limit of no friction.'

from ase import units
from ase import Atoms
from ase.build import bulk
from asap3 import EMT, MakeParallelAtoms
from asap3.md.velocitydistribution import MaxwellBoltzmannDistribution
from asap3.md.velocitydistribution import Stationary
from asap3.md.langevin import Langevin
from asap3.md.verlet import VelocityVerlet
from numpy.linalg import norm
from asap3.test.pytest_markers import serial
import numpy as np
from ase.parallel import world

import pytest

# parameters
size = 4
T = 300
dt = 0.5
friction = 0.02
Nstep = 200
etol = 5e-6

@pytest.mark.core
def test_langevin_limit(cpulayout):
    if cpulayout:
        mysize = size * np.array(cpulayout)
    else:
        mysize = (size, size, size)
    init_atoms = bulk('CuAg', 'rocksalt', a=3.75 * np.sqrt(2), cubic=True).repeat(mysize)
    init_atoms.pbc = False
    init_atoms.center(vacuum=4.0)
    MaxwellBoltzmannDistribution(init_atoms, temperature_K=3*T)
    Stationary(init_atoms)
    if world.rank > 0:
        init_atoms = None
    
    # Part 1: Run Velocity Verlet
    if cpulayout:
        atoms = MakeParallelAtoms(init_atoms, cpulayout)
    else:
        atoms = Atoms(init_atoms)
    natoms = atoms.get_global_number_of_atoms()
    atoms.calc = EMT()
    e_init = atoms.get_potential_energy() + atoms.get_kinetic_energy()
    dyn = VelocityVerlet(atoms, dt*units.fs, logfile='-')
    dyn.run(Nstep)

    e_verlet = atoms.get_potential_energy() + atoms.get_kinetic_energy()
    pos_verlet = atoms.get_positions()
    de_verlet = e_verlet - e_init
    print(f'Change in energy (Verlet): {de_verlet:.4e}')
    print(f'Tolerance: {etol * natoms:.4e}')
    assert np.abs(de_verlet) < etol * natoms

    # Part 2: Run Langevin with and without friction
    for fr in (0.0, friction):
        if cpulayout:
            atoms = MakeParallelAtoms(init_atoms, cpulayout)
        else:
            atoms = Atoms(init_atoms)
        atoms.calc = EMT()
        dyn = Langevin(atoms, dt*units.fs, friction=fr, temperature_K=T, logfile='-')
        dyn.run(Nstep)

        e_lgv = atoms.get_potential_energy() + atoms.get_kinetic_energy()
        pos_lgv = atoms.get_positions()
        de_lgv = e_lgv - e_init
        print(f'Change in energy (Langevin, friction={fr}):', de_lgv)
        if fr:
            eloss = natoms * units.kB * T / 3
            assert de_lgv < -eloss, 'Langevin has removed energy from system'
        else:
            assert np.abs(de_lgv) < etol * natoms, 'Langevin conserves energy with no friction'
            assert np.allclose(atoms.get_positions(), pos_lgv), 'Langevin reproduces Verlet'
