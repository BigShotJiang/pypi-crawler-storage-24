'''Test that the Asap mpi interface matches GPAw's - not currently the case.

The Asap MPI module is missing some functions, that causes this to raise
exceptions, which causes MPI to abort.  It is not enough to mark the
functions as xfail, they need to be skipped completely.
'''
import pytest
import numpy as np
from asap3.mpi import world, broadcast_array, send, receive
from asap3.test.pytest_markers import parallel

import pytest

@parallel
def test_send_receive_object():
    if world.size == 1:
        return
    obj = (42, 'hello')
    if world.rank == 0:
        send(obj, 1, world)
    elif world.rank == 1:
        assert obj == receive(0, world)


@parallel
@pytest.mark.core
def test_scalar_reduce():
    'Gpaw-style scalar reduction functions.'
    assert world.sum_scalar(world.rank + 1) == world.size * \
        (world.size + 1) // 2
    assert np.allclose(world.sum_scalar(world.rank + 1.0),
                       world.size * (world.size + 1.0) / 2)
    assert world.min_scalar(world.rank + 1) == 1
    assert world.max_scalar(world.rank + 1) == world.size
    assert world.min_scalar(world.rank + 1.0) == 1.0
    assert world.max_scalar(world.rank + 1.0) == world.size * 1.0

@parallel
@pytest.mark.core
def test_implicit_scalar_reduce():
    'Asap mpi object can reduce scalars with the same function as arrays'
    assert world.sum(world.rank + 1) == world.size * \
        (world.size + 1) // 2
    assert np.allclose(world.sum(world.rank + 1.0),
                       world.size * (world.size + 1.0) / 2)
    assert world.min(world.rank + 1) == 1
    assert world.max(world.rank + 1) == world.size
    assert world.min(world.rank + 1.0) == 1.0
    assert world.max(world.rank + 1.0) == world.size * 1.0

@parallel
def test_get_members():
    'Test the get_members method'
    worldmembers = world.get_members()
    assert np.all(worldmembers == np.arange(world.size))
    wanted = [0, world.size-1]
    newcomm = world.new_communicator(np.array(wanted))
    if newcomm is None:
        assert world.rank not in wanted
    else:
        assert np.all(newcomm.get_members() == np.array(wanted))

@parallel
def test_alltoallv():
    'Test the alltoallv method'
    send_sizes = np.arange(world.size)
    recv_sizes = np.ones_like(send_sizes) * world.rank
    send_offsets = np.zeros_like(send_sizes)
    recv_offsets = np.zeros_like(recv_sizes)
    for i in range(1, world.size):
        send_offsets[i] = send_offsets[i-1] + send_sizes[i-1]
        recv_offsets[i] = recv_offsets[i-1] + recv_sizes[i-1]
    finalsendsize = send_offsets[-1] + send_sizes[-1]
    assert finalsendsize == send_sizes.sum()
    finalrecvsize = recv_offsets[-1] + recv_sizes[-1]
    assert finalrecvsize == recv_sizes.sum()
    send_data = np.ones(finalsendsize) * world.rank
    recv_data = np.zeros(finalrecvsize)
    world.alltoallv(send_data, send_sizes, send_offsets,
                    recv_data, recv_sizes, recv_offsets)
    expected = []
    for i in range(world.size):
        expected += [i,] * world.rank
    assert len(expected) == len(recv_data)
    assert np.all(np.equal(recv_data, expected))

    # Now check that the type is tested
    send_offsets = list(send_offsets)
    with pytest.raises(TypeError):
        world.alltoallv(send_data, send_sizes, send_offsets,
                        recv_data, recv_sizes, recv_offsets)

@parallel
def test_mpi_compare():
    'Test compare method of communicator.'
    result = world.compare(world)
    assert result == 'ident'

@parallel
def test_translate_ranks():
    newcomm = world.new_communicator([0, world.size-1])
    if newcomm is not None:
        xlat = world.translate_ranks(newcomm, np.arange(world.size))
        print(xlat)
        assert len(xlat) == world.size
        assert xlat[0] == 0
        assert xlat[-1] == 1
        for i in range(1, world.size-1):
            assert xlat[i] == -1

@parallel
def test_get_c_object():
    cobj = world.get_c_object()
    assert isinstance(cobj, int)

@parallel
def test_bcast_array():
    'Broadcast of arrays on multiple communicators simultanously - not needed in Asap'
    new = world.new_communicator

    if world.size == 2:
        comms = [world]
    elif world.size == 4:
        ranks = np.array([[0, 1], [2, 3]])
        comms = [new(ranks[world.rank // 2]),
                 new(ranks[:, world.rank % 2])]
    elif world.size == 8:
        ranks = [[[0, 1], [0, 2], [0, 4]],
                 [[0, 1], [1, 3], [1, 5]],
                 [[2, 3], [0, 2], [2, 6]],
                 [[2, 3], [1, 3], [3, 7]],
                 [[4, 5], [4, 6], [0, 4]],
                 [[4, 5], [5, 7], [1, 5]],
                 [[6, 7], [4, 6], [2, 6]],
                 [[6, 7], [5, 7], [3, 7]]]
        comms = [new(r) for r in ranks[world.rank]]
    else:
        return

    array = np.zeros(3, int)
    if world.rank == 0:
        array[:] = 42

    out = broadcast_array(array, *comms)
    assert (out == 42).all()
