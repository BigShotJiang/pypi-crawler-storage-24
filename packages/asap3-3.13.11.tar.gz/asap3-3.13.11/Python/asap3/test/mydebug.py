from ase import units
from ase import Atoms
from ase.build import bulk
from asap3 import EMT, MakeParallelAtoms
from asap3.md.velocitydistribution import MaxwellBoltzmannDistribution
from asap3.md.velocitydistribution import Stationary
from asap3.md.langevin import Langevin
from asap3.md.verlet import VelocityVerlet
from numpy.linalg import norm
from asap3.test.pytest_markers import serial
import numpy as np
from ase.parallel import world

size = 2
T = 300
dt = 0.5
friction = 0.02
Nstep = 200
etol = 5e-6

mysize = (size, size, size)
init_atoms = bulk('CuAg', 'rocksalt', a=3.75 * np.sqrt(2), cubic=True).repeat(mysize)
init_atoms.pbc = False
init_atoms.center(vacuum=4.0)

atoms = Atoms(init_atoms)
natoms = atoms.get_global_number_of_atoms()
atoms.calc = EMT()

dyn = Langevin(atoms, dt*units.fs, friction=friction, temperature_K=T)
dyn.run(5)
