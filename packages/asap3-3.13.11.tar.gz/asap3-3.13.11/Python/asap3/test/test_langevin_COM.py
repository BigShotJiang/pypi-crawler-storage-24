from ase import units
from ase.build import bulk
from asap3 import EMT
from asap3.md.velocitydistribution import MaxwellBoltzmannDistribution
from asap3.md.velocitydistribution import Stationary
from asap3.md.langevin import Langevin
from asap3.constraints import FixCom
from asap3 import MakeParallelAtoms
from ase.parallel import world, parprint
from numpy.linalg import norm
from asap3.test.pytest_markers import serial
import numpy as np

import pytest

# parameters
size = 4
T = 600
dt = 1.0


@pytest.fixture
def atoms(cpulayout):
    if cpulayout:
        mysize = size * np.array(cpulayout)
    else:
        mysize = (size, size, size)
    atoms = bulk('CuAg', 'rocksalt', a=3.8, cubic=True).repeat(mysize)
    atoms.pbc = False
    atoms.center(vacuum=4.0)
    return atoms

@pytest.mark.core
@pytest.mark.parametrize('fixcm', (False, True))
@pytest.mark.parametrize('forcease', (False, True))
def test_langevin_com(atoms, cpulayout, fixcm, forcease):
    if cpulayout:
        if world.rank > 0:
            atoms = None
        atoms = MakeParallelAtoms(atoms, cpulayout)
    parprint('Cell:')
    parprint(atoms.cell)
    atoms.calc = EMT()
    atoms.set_momenta(np.zeros((len(atoms), 3)))
    if fixcm:
        atoms.constraints.append(FixCom())
    else:
        assert len(atoms.constraints) == 0
    dyn = Langevin(atoms, dt * units.fs, temperature_K=T, friction=0.02, forceASE=forcease)
    
    # run NVT
    cm_init = atoms.get_center_of_mass()

    parprint('Initial center of mass', cm_init)

    dyn.run(500)

    mom_final = atoms.get_momenta().sum(axis=0)
    world.sum(mom_final)
    cm_final = atoms.get_center_of_mass()
    parprint('Final center of mass: ', cm_final)
    parprint('Final momentum:', mom_final)
    parprint()

    if fixcm:
        # Center of mass should NOT change
        assert norm(cm_final - cm_init) < 1e-5
        assert norm(mom_final) < 1e-6
    else:
        # Center of mass should change
        assert norm(cm_final - cm_init) > 1e-5 or norm(mom_final) > 1e-6

