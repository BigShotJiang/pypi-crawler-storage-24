from asap3.mpi import world
import numpy as np

print(f'WORLD, rank={world.rank}:', world.get_members())

nc = world.new_communicator(np.array([0, world.size-1]))
if nc is not None:
    print(f'WORNEWLD, rank={world.rank}:', nc.get_members())


