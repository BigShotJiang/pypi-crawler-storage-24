"""Langevin dynamics class."""

import numpy as np
from numpy.random import standard_normal, randint
import asap3
import ase
import ase.units
from asap3.md.md import ParallelMolDynMixin
from ase.md.md import MolecularDynamics
from ase.md.langevin import Langevin as _Langevin_ASE
import asap3.constraints
from ase.parallel import world, DummyMPI
import sys
import numbers
import warnings

_fixcm_error = '''The fixcm argument has been deprecated in ASE as the results were 
incorrect.  See https://gitlab.com/ase/ase/-/issues/1871

In ASAP, please use the asap3.constrains.FixCom constraint instead.
'''

class ASE_Langevin(_Langevin_ASE, ParallelMolDynMixin):
    def __init__(self, atoms, timestep, temperature=None, friction=None, fixcm=False,
                     *, temperature_K=None, seed=None, **kwargs):
        if fixcm:
            warnings.warn(_fixcm_error, FutureWarning)
        ParallelMolDynMixin.__init__(self, "Langevin", atoms)
        if seed is not None:
            if 'rng' in kwargs:
                raise ValueError('ASE_Langevin: Cannot specify both seed and rng parameters!')
            if not isinstance(seed, np.random.SeedSequence):
                seed = np.random.SeedSequence(seed)
            kwargs['rng'] = np.random.default_rng(seed.spawn(world.size)[world.rank])
        if ase.__version__ >= '3.25.0':
            _Langevin_ASE.__init__(self, atoms, timestep, temperature=temperature,
                                   friction=friction, temperature_K=temperature_K,
                                   fixcm=fixcm, comm=DummyMPI(), **kwargs)
        else:
            _Langevin_ASE.__init__(self, atoms, timestep, temperature=temperature,
                                   friction=friction, temperature_K=temperature_K,
                                   fixcm=fixcm, communicator=None, **kwargs)

    def run(self, steps):
        self.before_run(allow_fixcom=True)
        super().run(steps)
        self.after_run()

    def _get_com_velocity(self, velocity=None):
        """Return the center of mass velocity."""
        if velocity is None:
            velocity = self.v  # Compatibility with older ASE
        if getattr(self.atoms, "parallel", False):
            data = np.zeros(4)
            data[:3] = np.dot(self.masses.flatten(), velocity)
            data[3] = self.masses.sum()
            self.atoms.comm.sum(data)
            return data[:3] / data[3]
        else:
            return np.dot(self.masses.flatten(), velocity) / self.masses.sum()

    temp = property(lambda s: s.get("temp"), lambda s, x: s.set("temp", x))
    fr = property(lambda s: s.get("fr"), lambda s, x: s.set("fr", x))
    masses = property(lambda s: s.get("masses"), lambda s, x: s.set("masses", x))
    c1 = property(lambda s: s.get("c1"), lambda s, x: s.set("c1", x))
    c2 = property(lambda s: s.get("c2"), lambda s, x: s.set("c2", x))
    c3 = property(lambda s: s.get("c3"), lambda s, x: s.set("c3", x))
    c4 = property(lambda s: s.get("c4"), lambda s, x: s.set("c4", x))
    c5 = property(lambda s: s.get("c5"), lambda s, x: s.set("c5", x))
    v = property(lambda s: s.get("v"), lambda s, x: s.set("v", x))
    rnd_pos = property(lambda s: s.get("rnd_pos"), lambda s, x: s.set("rnd_pos", x))
    rnd_vel = property(lambda s: s.get("rnd_vel"), lambda s, x: s.set("rnd_vel", x))

class Langevin_Fast(MolecularDynamics, ParallelMolDynMixin):
    """Langevin dynamics implemented in C++ for fast simulations.

    Implements the propagator from Vanden-Eijnden and Ciccotti eq (23).

    Reference:
    E. Vanden-Eijnden and G. Ciccotti, "Second-order integrators for
    Langevin equations with holonomic constraints",
    Chem. Phys. Lett. 429, 310-316 (2006). doi:10.1016/j.cplett.2006.07.086
    """
    def __init__(self, atoms, timestep, temperature=None, friction=None, fixcm=False,
                     *, temperature_K=None, 
                     trajectory=None, logfile=None, loginterval=1, seed=None):
        if fixcm:
            raise ValueError(_fixcm_error)
        temperature = ase.units.kB * self._process_temperature(temperature, temperature_K, 'eV')
        ParallelMolDynMixin.__init__(self, "Langevin", atoms)
        self._uselocaldata = False # Need to store on atoms for serial simul too.
        self.calculator = atoms.calc
        if not atoms.has('momenta'):
            atoms.set_momenta(np.zeros((len(atoms), 3), float))
        if len(atoms.constraints) > 1:
            raise RuntimeError('Asap does not support multiple simultaneous contraints.')
        if seed is None:
            seed = randint(1 << 30)
        elif isinstance(seed, np.random.SeedSequence):
            # Convert into a numeric seed for the Asap implementation.
            seed = seed.generate_state(1, dtype=np.uint64)
        assert isinstance(seed, numbers.Integral), "seed must be an int"
        self.asap_md = asap3._asap.Langevin(atoms, self.calculator, timestep,
                                            c3=self.prefix+"c3", c4=self.prefix+"c4",
                                            c5=self.prefix+"c5", rnd_vel=self.prefix+"rnd_vel",
                                            masses=self.prefix+"masses",
                                            seed=seed)
        MolecularDynamics.__init__(self, atoms, timestep, trajectory,
                                   logfile, loginterval)
        self.temp = temperature
        self.frict = friction
        self.communicator = None   # Prevent ASE md class from communicating
        self.updatevars()

    def set_temperature(self, temperature=None, *, temperature_K=None):
        self.temp =  ase.units.kB * self._process_temperature(temperature, temperature_K, 'eV')
        self.updatevars()

    def set_friction(self, friction):
        self.frict = friction
        self.updatevars()

    def set_timestep(self, timestep):
        self.dt = timestep
        self.updatevars()

    def updatevars(self):
        dt = self.dt
        # Detect supported constraints:
        # * If a FixAtoms constraint is present, friction is made an array to
        #   force all constants to be arrays.
        # * If a FixCom constraint is present, note it.  As the ASE version works
        #   as well (the fixing is not done by the constraint), allow it.
        if len(self.atoms.constraints) > 1:
            raise ValueError('Asap Langevin does not support multiple contraints.')
        has_fixatoms_constraint = (
            len(self.atoms.constraints) == 1 and
            isinstance(self.atoms.constraints[0], asap3.constraints.FixAtoms)
        )
        has_fixcom_constraint = (
            len(self.atoms.constraints) == 1 and
            isinstance(self.atoms.constraints[0], ase.constraints.FixCom) 
        )

        fr = self.frict
        if has_fixatoms_constraint:
            fr = fr * np.ones(len(self.atoms))

        # If the friction is an array some other constants must be arrays too.
        self._localfrict = hasattr(fr, 'shape')
        masses = self.masses.reshape((-1,))
        self.sum_of_masses = masses.sum()

        # ASAP works with momenta, not velocities, so c3 and c4 are
        # multiplied by masses compared to ASE implementation.
        self.c1 = dt / 2.0 - dt * dt * fr / 8.0
        self.one_minus_c2 = 1.0 - self.c1 * fr
        sigma = np.sqrt(2 * self.temp * fr / masses)
        self.c3 = (np.sqrt(dt) / 2.0 - dt**1.5 * fr / 8) * sigma * masses
        self.c5 = (dt**1.5 / (2 * np.sqrt(3))) * sigma
        self.c4 = fr / 2.0 * self.c5 * masses
        _n = len(self.atoms)
        if self._localfrict:
            assert self.c1.shape == (_n,)
            assert self.one_minus_c2.shape == (_n,)
        assert sigma.shape == (_n,)
        assert self.c3.shape == (_n,)
        assert self.c4.shape == (_n,)
        assert self.c5.shape == (_n,)
        
        # We also set an empty array for rnd_vel which needs to be present
        # on the atoms for the dynamics to work
        self.rnd_vel = np.zeros((len(self.atoms), 3))
        self.natoms = self.atoms.get_global_number_of_atoms()
        if has_fixatoms_constraint:
            # Process the FixAtoms constraint
            constr = self.atoms.constraints[0].index
            self.c1[constr] = 0.0
            self.one_minus_c2[constr] = 0.0
            self.c3[constr] = 0.0
            self.c4[constr] = 0.0
            self.c5[constr] = 0.0
        # The variable names of array c3, c4 and c5 are transferred at initialization time.
        # The variables c1 and one_minus_c2 are transferred now, as they may change
        # nature (vector versus scalar, for example if a constraint is added/removed).
        if self._localfrict:
            self.asap_md.set_vector_constants(
                self.prefix+"c1",
                self.prefix+"one_minus_c2",
                fixcm=has_fixcom_constraint,
                sum_of_masses=self.sum_of_masses
                )
        else:
            self.asap_md.set_scalar_constants(
                self.c1,
                self.one_minus_c2,
                fixcm=has_fixcom_constraint,
                sum_of_masses=self.sum_of_masses
                )

    def run(self, steps):
        assert(self.calculator is self.atoms.calc)
        # Always update the variables, as the constraints and/or
        # atoms types may have changed.
        self.updatevars()
        self.before_run(check_serial=True)
        self.asap_md.run(steps, self.observers, self)
        self.after_run()

    def get_random(self, gaussian):
        return self.asap_md.get_random(gaussian)

    c1 = property(lambda s: s.get("c1"), lambda s, x: s.set("c1", x))
    one_minus_c2 = property(lambda s: s.get("one_minus_c2"), lambda s, x: s.set("one_minus_c2", x))
    c3 = property(lambda s: s.get("c3"), lambda s, x: s.set("c3", x))
    c4 = property(lambda s: s.get("c4"), lambda s, x: s.set("c4", x))
    c5 = property(lambda s: s.get("c5"), lambda s, x: s.set("c5", x))
    rnd_vel = property(lambda s: s.get("rnd_vel"), lambda s, x: s.set("rnd_vel", x))
    masses = property(lambda s: s.get("masses"), lambda s, x: s.set("masses", x))

def Langevin(atoms, *args, **kwargs):
    if (not kwargs.pop('forceASE', False)
        and isinstance(atoms, ase.Atoms)
        and asap3.constraints.check_asap_constraints(atoms)
       ):
        # Nothing prevents Asap optimization
        if world.rank == 0:
            sys.stderr.write("Using Asap-optimized C++-Langevin algorithm\n")
        return Langevin_Fast(atoms, *args, **kwargs)
    else:
        if world.rank == 0:
            sys.stderr.write("Using ASE-based Langevin algorithm\n")
        return ASE_Langevin(atoms, *args, **kwargs)
