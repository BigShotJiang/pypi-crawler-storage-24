# Copyright (C) 2003  CAMP
# Please see the accompanying LICENSE file for further information.

import os
import sys
import pickle

import numpy as np

from asap3 import _asap

MASTER = 0

def is_contiguous(array, dtype=None):
    """Check for contiguity and type."""
    if dtype is None:
        return array.flags.contiguous
    else:
        return array.flags.contiguous and array.dtype == dtype

# Serial communicator
class SerialCommunicator:
    size = 1
    rank = 0
    def sum(self, array, root=-1):
        if isinstance(array, (float, complex)):
            return array

    def scatter(self, s, r, root):
        r[:] = s

    def max(self, value, root=-1):
        return value

    def broadcast(self, buf, root):
        pass

    def send(self, buff, root, tag=123, block=True):
        pass

    def barrier(self):
        pass

    def gather(self, a, root, b):
        b[:] = a

    def new_communicator(self, ranks):
        return self

    def cart_create(self, dimx, dimy, dimz, periodic):
        return self

class DummyCommunicator(SerialCommunicator):
    size = 1
    size = 0
    def new_communicator(self, ranks):
        new_comm = DummyCommunicator()
        new_comm.size = len(ranks)
        return new_comm


# serial_comm = SerialCommunicator()

if hasattr(_asap, "Communicator"):
    world = _asap.Communicator()
else:
    world = SerialCommunicator()

size = world.size
rank = world.rank
parallel = (size > 1)


def all_gather_array(comm, a): #???
    # Gather array into flat array
    shape = (comm.size,) + np.shape(a)
    all = np.zeros(shape)
    comm.all_gather(a, all)
    return all.ravel()

def broadcast_array(array: np.ndarray, *communicators):
    """Broadcast np.ndarray across sequence of MPI-communicators."""
    comms = list(communicators)
    while comms:
        comm = comms.pop()
        if all(comm.rank == 0 for comm in comms):
            comm.broadcast(array, 0)
    return array

def broadcast_string(string=None, root=0, *, comm):
    if comm.rank == root:
        string = string.encode()
    return broadcast_bytes(string, root, comm=comm).decode()

def broadcast_bytes(b=None, root=0, *, comm):
    """Broadcast a bytes across an MPI communicator and return it."""
    if comm.rank == root:
        assert isinstance(b, bytes)
        n = np.array(len(b), int)
    else:
        assert b is None
        n = np.zeros(1, int)
    comm.broadcast(n, root)
    if comm.rank == root:
        b = np.frombuffer(b, np.int8)
    else:
        b = np.zeros(n, np.int8)
    comm.broadcast(b, root)
    return b.tobytes()

def send(obj, rank: int, comm):
    """Send object to rank on the MPI communicator comm."""
    b = pickle.dumps(obj, pickle.HIGHEST_PROTOCOL)
    comm.send(np.array(len(b)), rank)
    comm.send(np.frombuffer(b, np.int8).copy(), rank)


def receive(rank: int, comm):
    """Receive object from rank on the MPI communicator comm."""
    n = np.array(0)
    comm.receive(n, rank)
    buf = np.empty(int(n), np.int8)
    comm.receive(buf, rank)
    return pickle.loads(buf.tobytes())

# def run(iterators):
#     """Run through list of iterators one step at a time."""
#     if not isinstance(iterators, list):
#         # It's a single iterator - empty it:
#         for i in iterators:
#             pass
#         return

#     if len(iterators) == 0:
#         return

#     while True:
#         try:
#             results = [iter.next() for iter in iterators]
#         except StopIteration:
#             return results
