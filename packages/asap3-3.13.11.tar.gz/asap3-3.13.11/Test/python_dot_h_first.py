'''Check that Python.h is included before any system header files.

The Python C/C++ API requires that Python.h is #include'd before any system
header file.  This is tricky to verify if it is included indirectly through
another header file.  This script does that.

All sub-folders of the folder being investigated may contain .h files, any
other folder containing .h files may be specified with the -I option.
'''

import argparse
import sys
import os
import subprocess
import sysconfig
import numpy as np


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('path', help='Source code folder or file (C/C++).')
    parser.add_argument('-I', '--include', action='append',
                        help='Specify include folder for compiler.')
    parser.add_argument('--exclude', action='append',
                        help='Exclude sub-folder from tests')
    parser.add_argument('--break', action='store_true', dest='brk',
                        help='Stop after first error found')
    parser.add_argument('--compiler', default='g++', help='GCC compatible compiler to use')
    args = parser.parse_args()

    # Include folders for numpy and Python itself
    include_folders = [sysconfig.get_paths()["include"], np.get_include()]
    # Include folders for OpenKIM stuff, if installed.
    failed = subprocess.call("pkg-config --exists libkim-api", shell=True)
    if not failed:
        kimincl = subprocess.check_output(
            "pkg-config --cflags-only-I libkim-api", shell=True).decode()
        include_folders += [f.strip() for f in kimincl.split('-I') if f]
    if args.include:
        include_folders.extend(args.include)
    include_folders = set(include_folders)
    print('path =', args.path)
    print('include = ', args.include)
    print('include_folders =', include_folders)
    print('compiler:', args.compiler)

    if os.path.isdir(args.path):
        # Find subfolders with .h files
        for dirpath, dirs, files in os.walk(args.path):
            for f in files:
                if f.lower().endswith('.h') or f.lower().endswith('.hpp'):
                    include_folders.add(dirpath)
        excludefolders = set()
        if args.exclude:
            for excl in args.exclude:
                if excl.startswith('/'):
                    excludefolders.add(excl)
                else:
                    excludefolders.add(os.path.join(args.path, excl))
        # Process folder
        print('Exclude folders:', excludefolders)
        errors = process_folder(args.path, include_folders, exclude=excludefolders, root=[args.path], 
                                brk=args.brk, compiler=args.compiler)
    else:
        root = os.getcwd()
        errors = []
        e = process_file(args.path, include_folders, root=[root], compiler=args.compiler)
        if e:
            errors.append(e)
    if errors:
        print(f'{len(errors)} files import Python.h after importing system headers.')
        for e in errors:
            print('   ', e)
    return len(errors)

def process_folder(path, inc, exclude, root, brk, compiler):
    errors = []
    for dirpath, dirs, files in os.walk(path):
        skipfolder = False
        for excl in exclude:
            if dirpath.startswith(excl):
                print('Skipping:', dirpath)
                skipfolder = True
        if not skipfolder:
            for f in files:
                if f.lower().endswith('.c') or f.lower().endswith('.cpp'):
                    e = process_file(os.path.join(dirpath, f), inc, root, compiler)
                    if e:
                        errors.append(e)
                        if brk:
                            # Break after first error
                            return errors
    return errors

def process_file(f, inc, root, compiler, debug=False):
    '''Process a file.
    
    Parameters:
    f: Path to file.
    inc: List of include folders.
    root: Paths to top of tree containing header files of this project.
    '''
    includes = ' '.join(['-I ' + x for x in inc])
    cmdline = f'{compiler} -H -E {includes} {f}'
    data = subprocess.run(cmdline, shell=True, capture_output=True)
    if data.returncode:
        print('ERROR: The following command failed:')
        print(' ', cmdline)
        print('Error output:')
        for line in data.stderr.decode().split('\n'):
            if not line.startswith('.'):  # Desired output, not error message
                print(line)
        sys.exit(data.returncode)
    # print(data)
    stderror = data.stderr.decode().split('\n')
    foundsystemheader = False
    for i, line in enumerate(stderror):
        words = line.split()
        if len(words) != 2:
            # Unexpected output, probably a compiler warning
            continue
        dots, fname = words
        if not dots.startswith('.'):
            # Unexpected output, probably a compiler warning
            continue
        for c in dots:
            if c != '.':
                raise RuntimeError(f'Expected first word to be dots, found:\n{line}')
        if debug:
            print(fname)
        if fname.endswith('Python.h'):
            if debug:
                print('FOUND Python.h !')
            if foundsystemheader:
                # This file has imported a system header and then Python.h
                print(f'*** ERROR ***: {f}')
                for l in stderror[:i+1]:
                    print(l)
                return f
            break
        ok = [fname.startswith(r) for r in root]
        if not sum(ok):
            # file is apparently a system header
            foundsystemheader = True
    return None

sys.exit(main())
