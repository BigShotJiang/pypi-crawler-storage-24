// Langevin.cpp  --  The Velocity Verlet molecular dynamics algorithm.
// -*- c++ -*-
//
// Copyright (C) 2001-2011 Jakob Schiotz and Center for Individual
// Nanoparticle Functionality, Department of Physics, Technical
// University of Denmark.  Email: schiotz@fysik.dtu.dk
//
// This file is part of Asap version 3.
//
// This program is free software: you can redistribute it and/or
// modify it under the terms of the GNU Lesser General Public License
// version 3 as published by the Free Software Foundation.  Permission
// to use other versions of the GNU Lesser General Public License may
// granted by Jakob Schiotz or the head of department of the
// Department of Physics, Technical University of Denmark, as
// described in section 14 of the GNU General Public License.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// and the GNU Lesser Public License along with this program.  If not,
// see <http://www.gnu.org/licenses/>.

#include "Langevin.h"
#include "Potential.h"
#include "DynamicAtoms.h"
#include "RandomNumbers.h"
//#define ASAPDEBUG
#include "Debug.h"

#include <iostream>
#include <cmath>

// Support for the FixCom constraint is disabled, as it requires communication and
// * This file is not necessarily compiled with MPI enabled.
// * There is no guarantee that the communication should use the world communicator
//   since a short setup simulation may happen on a single core.
//
// This can be enabled once communicators are securely passed via the Atoms object
// and a better handling of serial/parallel compilation is done.
//
// If enabling, also reinstate the reduction() clauses in the OpenMP pragmas
#undef FIXCOM

Langevin::Langevin(PyObject *py_atoms, Potential *calc, double timestep,
                   PyObject *c3_name, PyObject *c4_name, PyObject *c5_name,
                   PyObject *rnd_vel_name, PyObject *masses_name,
                   unsigned int seed) :
    MolecularDynamics(py_atoms, calc, timestep)
{
  DEBUGPRINT;
  vectorconstants = false;
  npy_uint32 seed32 = seed;
  random = new AsapRandomThread(seed32);
  this->c3_name = c3_name;
  this->c4_name = c4_name;
  this->c5_name = c5_name;
  this->rnd_vel_name = rnd_vel_name;
  this->masses_name = masses_name;
  Py_INCREF(this->c3_name);
  Py_INCREF(this->c4_name);
  Py_INCREF(this->c5_name);
  Py_INCREF(this->rnd_vel_name);
  Py_INCREF(this->masses_name);
  DEBUGPRINT;
}

Langevin::~Langevin()
{
  Py_DECREF(c3_name);
  Py_DECREF(c4_name);
  Py_DECREF(c5_name);
  Py_DECREF(rnd_vel_name);
  Py_DECREF(masses_name);
  if (vectorconstants)
    ClearPyNames();
  delete random;
}

void Langevin::SetScalarConstants(double c1, double one_minus_c2,
                                  bool fixcm, double sum_of_masses)
{
  DEBUGPRINT;
  if (vectorconstants)
    ClearPyNames();
  vectorconstants = false;
  this->c1 = c1;
  this->one_minus_c2 = one_minus_c2;
  this->fixcm = fixcm;
  this->sum_of_masses = sum_of_masses;
  DEBUGPRINT;
}

void Langevin::SetVectorConstants(PyObject *c1_name, PyObject *one_minus_c2_name,
                                  bool fixcm, double sum_of_masses)
{
  DEBUGPRINT;
  if (vectorconstants)
    ClearPyNames();
  vectorconstants = true;
  this->c1_name = c1_name;
  this->one_minus_c2_name = one_minus_c2_name;
  this->fixcm = fixcm;
  this->sum_of_masses = sum_of_masses;
  Py_INCREF(this->c1_name);
  Py_INCREF(this->one_minus_c2_name);
  DEBUGPRINT;
}

void Langevin::ClearPyNames()
{
  DEBUGPRINT;
  Py_DECREF(c1_name);
  Py_DECREF(one_minus_c2_name);
  DEBUGPRINT;
}

void Langevin::Run2(int nsteps, PyObject *observers, PyObject *self)
{
  DEBUGPRINT;
#ifndef FIXCOM
  ASSERT(!fixcm);
#endif
  ParseObservers(observers);
  DEBUGPRINT;
  vector<Vec> xi;
  vector<Vec> eta;
  bool firstloop = true;
  bool needcalculation = true;

  Vec *r = NULL;
  Vec *p = NULL;
  const Vec *F = NULL;
  DEBUGPRINT;
  for (int n = 0; n < nsteps; n++)  // nsteps-1 steps
    {
      CHECKNOASAPERROR; // Unnecessary paranoia.
      DEBUGPRINT;
      if (needcalculation)
      {
        DEBUGPRINT;
        F = GetForces();  // After first iteration, this normally does nothing as
                          // force is already calculated, but may fix rare trouble.
        r = atoms->GetPositions();
        p = atoms->GetMomenta();
        if (firstloop)
          {
            // Cannot be done before the loop, as nAtoms becomes set by GetForces().
            xi.reserve(nAtoms + nAtoms/20);
            eta.reserve(nAtoms + nAtoms/20);
            firstloop = false;
          }
        needcalculation = false;
      }
      DEBUGPRINT;
      double *c1_v = NULL;
      double *one_minus_c2_v = NULL;
      double *c3 = atoms->GetDoubleData(c3_name, nAtoms);
      double *c4 = atoms->GetDoubleData(c4_name, nAtoms);
      double *c5 = atoms->GetDoubleData(c5_name, nAtoms);
      Vec *rnd_vel = atoms->GetVecData(rnd_vel_name, nAtoms);
      double *masses = atoms->GetDoubleData(masses_name, nAtoms);
      DEBUGPRINT;
      GetRandom(xi, eta);
      DEBUGPRINT;
      // Now the positions and momenta are updated.  We also
      // keep the random velocity component for later use (in
      // second velocity update)
#ifdef FIXCOM
      Vec sum_r_before(0, 0, 0);
      Vec sum_r_after(0, 0, 0);
      double sum_m = 0;
#endif
      if (vectorconstants)
        {
          c1_v = atoms->GetDoubleData(c1_name, nAtoms);
          one_minus_c2_v = atoms->GetDoubleData(one_minus_c2_name, nAtoms);
          DEBUGPRINT;
#ifdef _OPENMP
#pragma omp parallel for // FIXCOM:  reduction(+:sum_r_before,sum_r_after,sum_m)
#endif // _OPENMP
          for (int i = 0; i < nAtoms; i++)
            {
              double m = masses[i];
              // Random velocity component
              rnd_vel[i] = c3[i] * xi[i] + c4[i] * eta[i];
              // First halv of momentum update
              p[i] = one_minus_c2_v[i] * p[i] + c1_v[i] * F[i] + rnd_vel[i];
#ifdef FIXCOM
              sum_r_before += m * r[i];
#endif
              r[i] += (timestep / m) * p[i] + c5[i] * eta[i];
#ifdef FIXCOM
              sum_r_after += m * r[i];
              sum_m += m;
#endif
            }
        }
      else
        {
          DEBUGPRINT;
#ifdef _OPENMP
#pragma omp parallel for // FIXCOM:  reduction(+:sum_r_before,sum_r_after,sum_m)
#endif // _OPENMP
          for (int i = 0; i < nAtoms; i++)
            {
              double m = masses[i];
              // Random velocity component
              rnd_vel[i] = c3[i] * xi[i] + c4[i] * eta[i];
              // First halv of momentum update
              p[i] = one_minus_c2 * p[i] + c1 * F[i] + rnd_vel[i];
#ifdef FIXCOM
              sum_r_before += m * r[i];
#endif
              r[i] += (timestep / m) * p[i] + c5[i] * eta[i];
#ifdef FIXCOM
              sum_r_after += m * r[i];
              sum_m += m;
#endif
            }
        }
#ifdef FIXCOM
      if (fixcm)
      {
        // Check the sum of masses - detect if communication was not
        // compiled in but should have been.
        ASSERT(abs(sum_m - sum_of_masses) < 1e-6);
        // Fix the center of mass
        Vec delta_com = sum_r_after / sum_m - sum_r_before / sum_m;
#ifdef _OPENMP
#pragma omp parallel for
#endif // _OPENMP
          for (int i = 0; i < nAtoms; i++)
            {
              r[i] -= delta_com;
            }
      }
#endif
      // Get forces, this may migrate atoms.
      DEBUGPRINT;
      F = GetForces();
      r = atoms->GetPositions();
      p = atoms->GetMomenta();
      rnd_vel = (Vec *) atoms->GetDoubleData(rnd_vel_name);
      DEBUGPRINT;
#ifdef FIXCOM
      Vec sum_p(0, 0, 0);
#endif
      if (vectorconstants)
        {
          c1_v = atoms->GetDoubleData(c1_name);
          one_minus_c2_v = atoms->GetDoubleData(one_minus_c2_name);
          DEBUGPRINT;
#ifdef _OPENMP
#pragma omp parallel for // FIXCOM:  reduction(+:sum_p)
#endif // _OPENMP
          for (int i = 0; i < nAtoms; i++)
          {
            p[i] = one_minus_c2_v[i] * p[i] + c1_v[i] * F[i] + rnd_vel[i];
#ifdef FIXCOM
            sum_p += p[i];
#endif
          }
        }
      else
        {
          DEBUGPRINT;
#ifdef _OPENMP
#pragma omp parallel for // FIXCOM:  reduction(+:sum_p)
#endif // _OPENMP
          for (int i = 0; i < nAtoms; i++)
            {
              p[i] = one_minus_c2 * p[i] + c1 * F[i] + rnd_vel[i];
#ifdef FIXCOM
              sum_p += p[i];
#endif
            }
        }
      DEBUGPRINT;
#ifdef FIXCOM
      if (fixcm)
      {
        Vec com_velocity = sum_p / sum_m;
#ifdef _OPENMP
#pragma omp parallel for reduction(+:sum_p)
#endif // _OPENMP
          for (int i = 0; i < nAtoms; i++)
          {
            p[i] -= masses[i] * com_velocity;
          }
      }
#endif
      steps++;
      needcalculation = CallObservers(self);
      DEBUGPRINT;
      // The observers might change the positions array (e.g. wrapping into box)
      // so we get a new pointer at the beginning of this loop if an observer was called.
    }
  DEBUGPRINT;
  CleanupObservers();
  UpdateStepsInPython(self);
}

void Langevin::GetRandom(std::vector<Vec> &x1, std::vector<Vec> &x2, bool gaussian /*=true*/)
{
  x1.resize(nAtoms);
  x2.resize(nAtoms);
  random->RandomDoubles((double *) &x1[0], 3*nAtoms);
  random->RandomDoubles((double *) &x2[0], 3*nAtoms);
  if (!gaussian)
    return;
  // Make them Gaussian
  double u1, u2, f;
#ifdef _OPENMP
#pragma omp parallel for private(u1, u2, f)
#endif // _OPENMP
  for (int i = 0; i < nAtoms; i++)
    for (int j = 0; j < 3; j++)
      {
        u1 = x1[i][j];
        u2 = 2 * M_PI * x2[i][j];
        f = sqrt(-2.0 * log(1.0 - u1));
        x1[i][j] = f * sin(u2);
        x2[i][j] = f * cos(u2);
      }
}
