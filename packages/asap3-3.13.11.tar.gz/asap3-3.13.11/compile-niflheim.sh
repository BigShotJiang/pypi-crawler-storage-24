#!/bin/bash

# Compiling ASAP for Niflheim.
#
# This script assumes that you are already on Nifhleim and in the ASAP 
# directory. 

NIFHOSTS="surt.fysik.dtu.dk sara.fysik.dtu.dk svol.fysik.dtu.dk sylg.fysik.dtu.dk"
NIFAMDHOSTS="fjorm.fysik.dtu.dk"
NIFEXTRA="slid2.fysik.dtu.dk slid.fysik.dtu.dk thul.fysik.dtu.dk"
OK=n
for H in $NIFHOSTS $NIFAMDHOSTS $NIFEXTRA; do
    if [[ "$H" == `hostname` ]]; then
	OK=y
    fi
done
if [[ $OK == n ]]; then
    echo "Apparently not on a Niflheim compile node."
    echo "This script should be executed on one of these machines:"
    echo "   $NIFHOSTS $NIFAMDHOSTS $NIFEXTRA"
    echo "but this is `hostname`"
    exit 1
fi

if [[ -n "$EBROOTFOSS" ]]; then
    echo "FOSS compilers set - enabling compilation on AMD hosts."
    NIFHOSTS="$NIFHOSTS $NIFAMDHOSTS"
    NIFL_TCHAIN=foss
elif [[ -n "$EBROOTINTEL" ]]; then
    echo "Intel compilers set - skipping AMD hosts."
    NIFL_TCHAIN=intel
else
    echo 'Error: No toolchain loaded.'
    exit 1
fi

# Now loop over all machines and compile.  Note that `pwd` is executed
# when the command is parsed, i.e. on this machine!

CMD="cd `pwd` && make depend-maybe && make -j16 all"
if [[ -n "$VIRTUAL_ENV" ]] ; then
    echo "Virtual environment detected: $VIRTUAL_ENV"
    CMD="source \"$VIRTUAL_ENV\"/bin/activate && $CMD"
fi
echo "Compilation command: $CMD"

for H in $NIFHOSTS; do
    echo
    echo "**** Compiling on $H ****"
    echo
    ssh $H "$CMD"
    if [[ $? -ne 0 ]]; then
	echo 
	echo '!!!!!!!  COMPILATION FAILED  !!!!!!!!'
	exit 1
    fi
done

if [[ -n "$VIRTUAL_ENV" ]]; then
    pyver=`python -c 'import sys; print(f"{sys.version_info[0]}.{sys.version_info[1]}")'`
    PTH_TARGET=${VIRTUAL_ENV}/lib/python${pyver}/site-packages/niflheim_asap.pth
    echo
    echo "Virtual environment detected:"
    echo "Installing .pth file into ${PTH_TARGET}"
    cat niflheim_asap.pth.txt | sed -s "s+ASAPSOURCEDIR+`pwd`+g" | sed -s "s/NIFL_TCHAIN/${NIFL_TCHAIN}/" > $PTH_TARGET
    # cat $PTH_TARGET
    echo
fi
