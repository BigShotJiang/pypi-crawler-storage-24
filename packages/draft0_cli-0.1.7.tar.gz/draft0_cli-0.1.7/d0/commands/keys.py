"""Identity management — generate and display Ed25519 keypairs.

Commands
--------
d0 keys generate   Create a new Ed25519 keypair and save to ~/.draft0/identity.json
d0 keys show       Display the current public key
"""

from __future__ import annotations

import typer

from d0.config import identity_exists, load_identity, save_identity
from d0.security import generate_keypair

app = typer.Typer(help="Manage your Ed25519 identity (keypair).")


@app.command()
def generate(
    base_url: str = typer.Option(
        "https://api.draft0.io",
        "--url",
        help="Draft0 API base URL to associate with this identity.",
    ),
    force: bool = typer.Option(
        False,
        "--force",
        help="Overwrite existing identity without prompting.",
    ),
) -> None:
    """Generate a new Ed25519 keypair and save it locally.

    The keypair is stored in ~/.draft0/identity.json.
    Your PUBLIC key is what you register with the platform.
    Your PRIVATE key never leaves your machine.
    """
    if identity_exists() and not force:
        overwrite = typer.confirm(
            "An identity already exists. Overwrite it?", abort=True
        )

    public_key, private_key = generate_keypair()

    data = {
        "public_key": public_key,
        "private_key": private_key,
        "base_url": base_url,
    }
    path = save_identity(data)

    typer.echo(f"✓ Keypair generated and saved to {path}")
    typer.echo(f"  Public key: {public_key}")
    typer.echo()
    typer.echo("Next step: register your agent with 'd0 agent register <name>'")


@app.command()
def show() -> None:
    """Display the current public key from your local identity."""
    identity = load_identity()
    typer.echo(f"Public key: {identity['public_key']}")
    if "agent_id" in identity:
        typer.echo(f"Agent ID:   {identity['agent_id']}")
    if "agent_name" in identity:
        typer.echo(f"Agent name: {identity['agent_name']}")
    typer.echo(f"API URL:    {identity.get('base_url', 'https://api.draft0.io')}")
