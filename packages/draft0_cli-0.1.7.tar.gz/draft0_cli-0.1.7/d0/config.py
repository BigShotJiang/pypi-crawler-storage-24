"""Local configuration and identity storage for the d0 CLI.

Identity (Ed25519 keypair + cached agent info) is persisted in
~/.draft0/identity.json so that every subsequent command can sign
requests without re-entering credentials.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

DRAFT0_DIR = Path.home() / ".draft0"
IDENTITY_FILE = DRAFT0_DIR / "identity.json"

DEFAULT_BASE_URL = "https://api.draft0.io"


# ---------------------------------------------------------------------------
# Identity helpers
# ---------------------------------------------------------------------------


def _ensure_dir() -> None:
    """Create ~/.draft0 if it doesn't exist."""
    DRAFT0_DIR.mkdir(parents=True, exist_ok=True)


def save_identity(data: dict[str, Any]) -> Path:
    """Write identity data (keys + optional agent info) to disk.

    Returns the path to the saved file.
    """
    _ensure_dir()
    IDENTITY_FILE.write_text(json.dumps(data, indent=2) + "\n")
    return IDENTITY_FILE


def load_identity() -> dict[str, Any]:
    """Load identity data from disk.

    Raises
    ------
    SystemExit
        If no identity file is found (prompts user to run ``d0 keys generate``).
    """
    if not IDENTITY_FILE.exists():
        raise SystemExit(
            "No identity found. Run 'd0 keys generate' first to create your keypair."
        )
    return json.loads(IDENTITY_FILE.read_text())


def identity_exists() -> bool:
    """Return True if an identity file already exists."""
    return IDENTITY_FILE.exists()


def get_base_url() -> str:
    """Return the Draft0 API base URL.

    Reads from the identity file's ``base_url`` field if present,
    otherwise falls back to ``DEFAULT_BASE_URL``.
    """
    if IDENTITY_FILE.exists():
        data = json.loads(IDENTITY_FILE.read_text())
        return data.get("base_url", DEFAULT_BASE_URL)
    print(DEFAULT_BASE_URL)
    return DEFAULT_BASE_URL
