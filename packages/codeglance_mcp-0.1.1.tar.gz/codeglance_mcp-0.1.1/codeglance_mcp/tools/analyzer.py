"""Repository analysis tools following MCP best practices."""

import asyncio
from pathlib import Path
from typing import Dict
import logging

from codeglance_mcp.utils.async_helpers import (
    clone_repository_async,
    get_directory_structure_async,
    read_file_async,
    write_file_async
)
from codeglance_mcp.utils.gemini_client import gemini_client
from codeglance_mcp.utils.cache import cache
from codeglance_mcp.config import config

logger = logging.getLogger(__name__)


class RepositoryAnalyzer:
    """Repository analyzer with intelligent size detection."""

    def __init__(self):
        self.key_files = [
            "README.md", "readme.md", "README.rst", "README.txt",
            "package.json", "requirements.txt", "Cargo.toml", "go.mod", "pom.xml",
            "main.py", "index.js", "app.py", "server.py", "main.go", "src/main.rs",
            ".env.example", "docker-compose.yml", "Dockerfile", "Makefile",
            "tsconfig.json", "next.config.js", "vite.config.js",
            "pyproject.toml", "setup.py", "setup.cfg",
        ]

    async def clone_repository(self, repo_url: str, working_directory: str = ".") -> tuple[bool, str, str]:
        """Clone repository and return success, message, and local path."""
        try:
            repo_name = repo_url.removesuffix('.git').rstrip('/').split('/')[-1]
            local_path = Path(working_directory) / repo_name

            success, message = await clone_repository_async(repo_url, local_path)
            return success, message, str(local_path)

        except Exception as e:
            logger.error(f"Error in clone_repository: {e}")
            return False, str(e), ""

    async def detect_repository_size(self, repo_path: Path) -> str:
        """Detect repository size category for adaptive analysis."""
        try:
            structure = await get_directory_structure_async(repo_path)
            file_count = len(structure.split('\n'))

            if file_count < 50:
                return "small"
            elif file_count < 500:
                return "medium"
            elif file_count < 2000:
                return "large"
            else:
                return "massive"

        except Exception:
            return "medium"

    async def read_key_files(self, repo_path: Path, max_files: int = None) -> Dict[str, str]:
        """Read key files from repository asynchronously."""
        files_content = {}
        max_files = max_files or config.max_files_per_analysis

        repo_size = await self.detect_repository_size(repo_path)
        if repo_size == "large":
            max_files = min(max_files, 20)
        elif repo_size == "massive":
            max_files = min(max_files, 10)

        tasks = []
        file_paths = []

        for file_name in self.key_files[:max_files]:
            file_path = repo_path / file_name
            if file_path.exists():
                tasks.append(read_file_async(file_path, config.max_file_size))
                file_paths.append(file_name)

        if tasks:
            results = await asyncio.gather(*tasks, return_exceptions=True)

            for file_name, result in zip(file_paths, results):
                if isinstance(result, Exception):
                    files_content[file_name] = f"Error reading file: {str(result)}"
                elif result is not None:
                    files_content[file_name] = result

        return files_content

    async def load_prompt_template(self, template_name: str) -> str:
        """Load prompt template asynchronously with caching."""
        cache_key = f"prompt_template:{template_name}"

        async def load_template():
            prompt_file = config.prompts_dir / f"{template_name}.md"
            content = await read_file_async(prompt_file, max_size=50000)
            return content or f"Prompt template '{template_name}.md' not found."

        return await cache.get_or_set(cache_key, load_template)

    async def create_analysis_prompt(self, template_name: str, repo_path: Path) -> str:
        """Create analysis prompt with repository context."""
        try:
            template_task = self.load_prompt_template(template_name)
            structure_task = get_directory_structure_async(repo_path)
            files_task = self.read_key_files(repo_path)

            template, structure, key_files = await asyncio.gather(
                template_task, structure_task, files_task
            )

            prompt = template.replace("[REPOSITORY_PATH]", str(repo_path))

            full_prompt = f"{prompt}\n\n## Repository Structure:\n```\n{structure}\n```\n\n## Key Files Content:\n"

            for filename, content in key_files.items():
                full_prompt += f"\n### {filename}:\n```\n{content}\n```\n"

            return full_prompt

        except Exception as e:
            logger.error(f"Error creating analysis prompt: {e}")
            return f"Error creating prompt: {str(e)}"

    async def generate_analysis(self, template_name: str, repo_path: Path, output_file: Path) -> tuple[bool, str]:
        """Generate analysis using Gemini and save to file."""
        max_retries = 2
        retry_delay = 5

        for attempt in range(max_retries + 1):
            try:
                cache_key = cache.cache_key("analysis", template_name, str(repo_path))

                async def generate():
                    prompt = await self.create_analysis_prompt(template_name, repo_path)
                    success, result = await gemini_client.generate_content_async(prompt)
                    return success, result

                success, content = await cache.get_or_set(cache_key, generate)

                if success:
                    write_success = await write_file_async(output_file, content)
                    if write_success:
                        return True, f"Analysis saved to {output_file}"
                    else:
                        return False, f"Failed to write analysis to {output_file}"
                else:
                    if attempt < max_retries:
                        logger.warning(f"Analysis attempt {attempt + 1} failed for {template_name}: {content}. Retrying...")
                        await asyncio.sleep(retry_delay)
                        continue
                    return False, content

            except Exception as e:
                if attempt < max_retries:
                    logger.warning(f"Analysis attempt {attempt + 1} failed for {template_name}: {e}. Retrying...")
                    await asyncio.sleep(retry_delay)
                    continue
                logger.error(f"Error generating analysis after {max_retries + 1} attempts: {e}")
                return False, str(e)


# Global analyzer instance
analyzer = RepositoryAnalyzer()
