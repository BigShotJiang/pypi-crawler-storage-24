"""Configuration management for CodeGlance MCP server."""

import os
import logging
import sys
from pathlib import Path
from typing import Optional

# Configure stderr logging (MCP requirement - never use stdout)
logging.basicConfig(
    stream=sys.stderr,
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

logger = logging.getLogger(__name__)


class Config:
    """Configuration class for CodeGlance MCP server.

    The Gemini API key can be provided via:
    - GEMINI_API_KEY environment variable (set directly or via MCP server config)
    - .env file in the current working directory (for local development)
    """

    def __init__(self):
        # Try loading .env only if it exists (optional for local dev)
        try:
            from dotenv import load_dotenv
            load_dotenv()
        except ImportError:
            pass

        # API Keys - primarily from environment (set via MCP config or shell)
        self.gemini_api_key: Optional[str] = os.getenv("GEMINI_API_KEY")

        # Paths - use importlib.resources for package data
        self.project_root = Path(__file__).parent
        self.prompts_dir = self.project_root / "prompts"

        # Repository analysis settings
        self.max_file_size = int(os.getenv("MAX_FILE_SIZE", "5000"))
        self.max_files_per_analysis = int(os.getenv("MAX_FILES_PER_ANALYSIS", "50"))

        # Async settings
        self.timeout_seconds = float(os.getenv("TIMEOUT_SECONDS", "120.0"))
        self.max_concurrent_requests = int(os.getenv("MAX_CONCURRENT_REQUESTS", "3"))

        # Model settings
        self.content_generation_model = os.getenv("CONTENT_GENERATION_MODEL", "gemini-2.5-flash")

        # Cache settings
        self.cache_ttl_seconds = int(os.getenv("CACHE_TTL_SECONDS", "3600"))

        if self.gemini_api_key:
            logger.info("Gemini API key configured")
        else:
            logger.warning(
                "GEMINI_API_KEY not set. "
                "Set it via environment variable or MCP server config."
            )

    @property
    def has_gemini_key(self) -> bool:
        """Check if Gemini API key is configured."""
        return bool(self.gemini_api_key)


# Global config instance
config = Config()
