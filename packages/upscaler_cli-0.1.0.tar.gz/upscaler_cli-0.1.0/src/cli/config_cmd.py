"""CLI config command for persistent settings."""

import click

from src.config import CLIConfig, VALID_KEYS


@click.group("config", help="Manage persistent CLI settings in ~/.upscaler/config.json.")
def config_group():
    pass


@config_group.command("set")
@click.argument("key")
@click.argument("value")
def config_set(key, value):
    """Set a config value. Valid keys: server_url, oauth_url, default_format."""
    try:
        config = CLIConfig()
        config.set(key, value)
        click.echo(f"{key} = {value}")
    except ValueError as e:
        click.echo(str(e), err=True)
        raise SystemExit(1)


@config_group.command("get")
@click.argument("key")
def config_get(key):
    """Get a config value."""
    if key not in VALID_KEYS:
        click.echo(
            f"Unknown config key: {key}. Valid keys: {', '.join(sorted(VALID_KEYS))}",
            err=True,
        )
        raise SystemExit(1)
    config = CLIConfig()
    value = config.get(key)
    click.echo(value if value else "")
