"""Get asset, member, or group by ID."""

import asyncio
import sys

import click

from src.cli.context import Context, pass_context
from src.cli.helpers import handle_error


# Prefix → (type, endpoint)
_PREFIX_ROUTES = {
    "g_": ("group", "/api/v1/groups"),
}

# Known asset prefixes (routed to /api/v1/assets)
_ASSET_PREFIXES = ("d_", "doc_", "rg_", "rd_", "urd_", "r_", "rec_", "i_", "to_", "t_")

# Explicit --type → endpoint
_TYPE_ROUTES = {
    "member": "/api/v1/members",
    "group": "/api/v1/groups",
}


def _detect_route(resource_id, resource_type):
    """Detect the API route for a resource.

    Returns (endpoint_base, is_asset) or (None, None) if unknown.
    """
    # 1. Explicit --type takes priority
    if resource_type and resource_type in _TYPE_ROUTES:
        return _TYPE_ROUTES[resource_type], False

    # 2. Auto-detect by prefix
    for prefix, (_, endpoint) in _PREFIX_ROUTES.items():
        if resource_id.startswith(prefix):
            return endpoint, False

    for prefix in _ASSET_PREFIXES:
        if resource_id.startswith(prefix):
            return "/api/v1/assets", True

    # 3. Unknown
    return None, None


@click.command("get")
@click.argument("resource_id")
@click.option(
    "--format", "fmt", default=None,
    type=click.Choice(["json", "markdown", "schema"]),
    help="Output format: json (overview), markdown (content), schema (fields).",
)
@click.option(
    "--type", "resource_type", default=None,
    type=click.Choice(["member", "group"]),
    help="Resource type (for IDs without a known prefix, e.g. member).",
)
@pass_context
def get_asset(ctx, resource_id, fmt, resource_type):
    """Retrieve an asset, member, or group by ID.

    Asset and group IDs are auto-detected by prefix (rg_, d_, g_, etc.).
    For members, use --type member since member IDs have no prefix.

    Examples:
        upscaler get rg_abc123
        upscaler get rg_abc123 --format schema
        upscaler get g_abc123
        upscaler get <uid> --type member
        upscaler --json get <uid> --type member
    """
    from src.cli.helpers import make_client
    from src.formatters.json_fmt import format_json

    client = make_client(ctx)

    endpoint, is_asset = _detect_route(resource_id, resource_type)

    if endpoint is None:
        msg = (
            f"Unknown resource ID format: {resource_id}. "
            "Use --type member or --type group for IDs without a known prefix."
        )
        if ctx.json_mode:
            import json
            click.echo(json.dumps({"error": msg, "exit_code": 1}), err=True)
        else:
            click.echo(msg, err=True)
        sys.exit(1)
        return

    if is_asset:
        _get_asset(ctx, client, resource_id, fmt, format_json)
    else:
        _get_simple(ctx, client, f"{endpoint}/{resource_id}", format_json)


def _get_asset(ctx, client, asset_id, fmt, format_json):
    """Fetch and display an asset with format control."""
    params = {}
    if fmt:
        params["format"] = fmt

    try:
        result = asyncio.run(
            client.request("GET", f"/api/v1/assets/{asset_id}", params=params)
        )
    except Exception as e:
        handle_error(ctx, e)
        return

    data = result.get("data", {})

    if ctx.json_mode:
        click.echo(format_json(result, compact=True))
    elif fmt == "markdown":
        content = data.get("markdown", data.get("text", ""))
        if content:
            click.echo(content)
        else:
            click.echo("No markdown content for this asset type.", err=True)
    elif fmt == "schema":
        schema = data.get("schema", {})
        if schema:
            click.echo(format_json(schema))
        else:
            click.echo("No schema available for this asset type.", err=True)
    else:
        click.echo(format_json(data))


def _get_simple(ctx, client, endpoint, format_json):
    """Fetch and display a simple resource (member, group)."""
    try:
        result = asyncio.run(client.request("GET", endpoint))
    except Exception as e:
        handle_error(ctx, e)
        return

    data = result.get("data", {})

    if ctx.json_mode:
        click.echo(format_json(result, compact=True))
    else:
        click.echo(format_json(data))
