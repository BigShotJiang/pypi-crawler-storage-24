"""Authentication CLI commands: login, refresh, status, logout."""

import asyncio
import json
import sys
import time

import click

from src.cli.context import Context, pass_context


@click.command()
@click.option("--port", default=19876, help="Localhost port for OAuth callback.")
@pass_context
def login(ctx, port):
    """Authenticate with Upscaler via browser-based OAuth2 login.

    Opens your default browser to the Upscaler login page. After
    authenticating, tokens are encrypted and stored locally.

    Examples:
        upscaler login
        upscaler login --port 9999
        upscaler --server https://custom.upscaler.com login
    """
    from src.auth.oauth import OAuthFlow
    from src.auth.token_store import TokenStore
    from src.config import CLIConfig

    config = CLIConfig()
    server_url = config.resolve_server_url(ctx.server_url)
    if not server_url:
        click.echo("Server URL required. Use --server or: upscaler config set server_url <url>",
                    err=True)
        sys.exit(1)

    verify_ssl = config.resolve_verify_ssl()
    flow = OAuthFlow(server_url, verify_ssl=verify_ssl)
    store = TokenStore()

    try:
        if not ctx.json_mode:
            click.echo("Starting OAuth login...", err=True)

        token_data = asyncio.run(flow.login(port=port))
        store.save(token_data)

        expires_in = int(token_data.expires_at - time.time())
        if ctx.json_mode:
            click.echo(json.dumps({"success": True, "data": {"expires_in": expires_in}}))
        else:
            click.echo(f"Logged in successfully. Token expires in {expires_in}s", err=True)

    except RuntimeError as e:
        if ctx.json_mode:
            click.echo(json.dumps({"error": str(e)}), err=True)
        else:
            click.echo(str(e), err=True)
        sys.exit(1)


@click.command()
@pass_context
def refresh(ctx):
    """Refresh an expired access token using the stored refresh token.

    Examples:
        upscaler refresh
        upscaler refresh --json
    """
    from src.auth.oauth import OAuthFlow
    from src.auth.token_store import TokenStore
    from src.config import CLIConfig

    config = CLIConfig()
    server_url = config.resolve_server_url(ctx.server_url)
    store = TokenStore()

    try:
        token_data = store.load()
    except RuntimeError as e:
        if ctx.json_mode:
            click.echo(json.dumps({"error": str(e), "exit_code": 2}), err=True)
        else:
            click.echo(str(e), err=True)
        sys.exit(2)

    try:
        verify_ssl = config.resolve_verify_ssl()
        flow = OAuthFlow(server_url or "", verify_ssl=verify_ssl)
        new_token_data = asyncio.run(flow.refresh(token_data))
        store.save(new_token_data)

        expires_in = int(new_token_data.expires_at - time.time())
        if ctx.json_mode:
            click.echo(json.dumps({"success": True, "data": {"expires_in": expires_in}}))
        else:
            click.echo(f"Token refreshed. Expires in {expires_in}s")

    except RuntimeError as e:
        if ctx.json_mode:
            click.echo(json.dumps({"error": str(e), "exit_code": 2}), err=True)
        else:
            click.echo(str(e), err=True)
        sys.exit(2)


@click.command()
@pass_context
def status(ctx):
    """Show authentication status and token expiry.

    Examples:
        upscaler status
        upscaler --json status
    """
    from src.auth.token_store import TokenStore

    store = TokenStore()

    try:
        token_data = store.load()
    except RuntimeError:
        if ctx.json_mode:
            click.echo(json.dumps({"authenticated": False, "message": "Not authenticated"}))
        else:
            click.echo("Status: Not authenticated")
            click.echo("Run: upscaler login")
        return

    now = time.time()
    if now >= token_data.expires_at:
        if ctx.json_mode:
            click.echo(json.dumps({"authenticated": True, "expired": True}))
        else:
            click.echo("Status: Token expired")
            click.echo("Run: upscaler refresh")
    else:
        expires_in = int(token_data.expires_at - now)
        if ctx.json_mode:
            click.echo(json.dumps({
                "authenticated": True,
                "expired": False,
                "expires_in": expires_in,
                "organization_id": token_data.organization_id,
            }))
        else:
            click.echo("Status: Authenticated")
            if token_data.organization_id:
                click.echo(f"Organization: {token_data.organization_id}")
            click.echo(f"Expires in: {expires_in}s ({expires_in // 60}m)")


@click.command()
@pass_context
def logout(ctx):
    """Revoke tokens and clear local storage.

    Examples:
        upscaler logout
    """
    from src.auth.oauth import OAuthFlow
    from src.auth.token_store import TokenStore
    from src.config import CLIConfig

    config = CLIConfig()
    server_url = config.resolve_server_url(ctx.server_url)
    store = TokenStore()

    try:
        token_data = store.load()
    except RuntimeError:
        if ctx.json_mode:
            click.echo(json.dumps({"success": True, "message": "Not logged in."}))
        else:
            click.echo("Not logged in.")
        return

    # Best-effort server revocation
    if server_url:
        try:
            verify_ssl = config.resolve_verify_ssl()
            flow = OAuthFlow(server_url, verify_ssl=verify_ssl)
            asyncio.run(flow.revoke(token_data))
        except Exception:
            if not ctx.json_mode:
                click.echo(
                    "Logged out locally. Server revocation failed — "
                    "token will expire naturally.",
                    err=True,
                )

    store.delete()

    if ctx.json_mode:
        click.echo(json.dumps({"success": True}))
    else:
        click.echo("Logged out successfully.")
