"""Shared helpers for CLI commands."""

import json
import sys
from pathlib import Path

from src.errors import CLIError


def parse_data(value: str) -> dict:
    """Parse --data flag value into a dict.

    Supports three input forms:
    - Flag value: --data '{"json": true}'
    - Stdin pipe: --data -
    - File reference: --data @file.json

    Args:
        value: The --data flag value.

    Returns:
        Parsed dict.

    Raises:
        CLIError: On invalid JSON, missing file, or TTY stdin.
    """
    if value == "-":
        # Stdin
        if sys.stdin.isatty():
            print("Reading JSON from stdin (Ctrl+D to end):", file=sys.stderr)
        raw = sys.stdin.read()
    elif value.startswith("@"):
        # File reference
        file_path = Path(value[1:])
        if not file_path.exists():
            raise CLIError(f"File not found: {file_path}")
        raw = file_path.read_text()
    else:
        # Direct value
        raw = value

    try:
        data = json.loads(raw)
    except json.JSONDecodeError as e:
        raise CLIError(f"Invalid JSON: {e}")

    if not isinstance(data, dict):
        raise CLIError("--data must be a JSON object (dict)")

    return data


def handle_error(ctx, e) -> None:
    """Handle CLI errors with appropriate output mode and exit code.

    Args:
        ctx: CLI Context with json_mode flag.
        e: Exception to handle.
    """
    import click

    exit_code = getattr(e, "exit_code", 1)
    if ctx.json_mode:
        click.echo(json.dumps({"error": str(e), "exit_code": exit_code}), err=True)
    else:
        click.echo(str(e), err=True)
    sys.exit(exit_code)


def make_client(ctx):
    """Create an UpscalerClient from CLI context.

    Centralizes config resolution and client construction.

    Args:
        ctx: CLI Context with server_url and verbose flags.

    Returns:
        Configured UpscalerClient instance.
    """
    from src.auth.token_store import TokenStore
    from src.client import UpscalerClient
    from src.config import CLIConfig

    config = CLIConfig()
    server_url = config.resolve_server_url(ctx.server_url)
    verify_ssl = config.resolve_verify_ssl()
    return UpscalerClient(server_url, TokenStore(), verbose=ctx.verbose, verify_ssl=verify_ssl)


def confirm_destructive(operation: str, resource_id: str, json_mode: bool) -> bool:
    """Prompt for confirmation on destructive operations.

    Silent (returns True) when piped or in --json mode.

    Args:
        operation: Operation name (e.g., "delete").
        resource_id: ID of the resource being affected.
        json_mode: If True, skip confirmation.

    Returns:
        True if confirmed, False otherwise.
    """
    if json_mode or not sys.stdout.isatty():
        return True

    response = input(f"Confirm {operation} {resource_id}? [y/N] ")
    return response.lower() in ("y", "yes")
