"""OAuth2 Authorization Code + PKCE flow for CLI login.

Flow:
1. Register client via Dynamic Client Registration (DCR)
2. Generate PKCE code verifier + challenge
3. Start localhost HTTP server for callback
4. Open browser to authorize URL
5. Wait for callback with auth code
6. Exchange code for tokens
7. Return TokenData

Also supports:
- Token refresh (refresh_token grant)
- Token revocation (best-effort)
"""

import asyncio
import base64
import hashlib
import http.server
import logging
import os
import secrets
import socket
import sys
import threading
import time
import webbrowser
from dataclasses import dataclass
from typing import Optional, Tuple
from urllib.parse import parse_qs, urlencode, urlparse

import httpx

from src.auth.token_store import TokenData

logger = logging.getLogger(__name__)

# Default callback port for localhost server
DEFAULT_PORT = 19876
LOGIN_TIMEOUT = 120  # seconds


def generate_pkce() -> Tuple[str, str]:
    """Generate PKCE code verifier and challenge.

    Returns:
        Tuple of (verifier, challenge) where:
        - verifier: 43-128 character random string
        - challenge: base64url(sha256(verifier))
    """
    # Generate 32 random bytes → 43 character base64url string
    verifier = base64.urlsafe_b64encode(os.urandom(32)).rstrip(b"=").decode("ascii")

    # S256 challenge
    digest = hashlib.sha256(verifier.encode("ascii")).digest()
    challenge = base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")

    return verifier, challenge


def generate_state() -> str:
    """Generate random state parameter for CSRF prevention."""
    return secrets.token_urlsafe(32)


class OAuthFlow:
    """Manages OAuth2 flows: login, refresh, revoke."""

    def __init__(self, server_url: str, verify_ssl: bool = True):
        """Initialize OAuth flow.

        Args:
            server_url: Base URL of the Upscaler API (e.g., https://api.upscaler.com)
            verify_ssl: If False, skip SSL certificate verification.
        """
        self.server_url = server_url.rstrip("/")
        self.oauth_base = f"{self.server_url}/mcp"
        self.verify_ssl = verify_ssl

    async def register_client(self) -> Tuple[str, str]:
        """Register a new OAuth client via Dynamic Client Registration.

        Returns:
            Tuple of (client_id, client_secret).
        """
        url = f"{self.oauth_base}/register"
        payload = {
            "client_name": f"upscaler-cli-{secrets.token_hex(4)}",
            "grant_types": ["authorization_code", "refresh_token"],
            "response_types": ["code"],
            "redirect_uris": [f"http://127.0.0.1:{DEFAULT_PORT}/callback"],
            "token_endpoint_auth_method": "client_secret_post",
        }

        async with httpx.AsyncClient(verify=self.verify_ssl) as client:
            response = await client.post(url, json=payload)
            response.raise_for_status()
            data = response.json()

        return data["client_id"], data["client_secret"]

    async def login(self, port: int = DEFAULT_PORT) -> TokenData:
        """Run full OAuth2 PKCE login flow.

        Args:
            port: Localhost port for callback server.

        Returns:
            TokenData with access + refresh tokens.

        Raises:
            RuntimeError: On timeout, port conflict, or auth failure.
        """
        # Check port availability
        if not self._is_port_available(port):
            raise RuntimeError(
                f"Login callback port {port} in use. Use --port to specify another."
            )

        # Register client
        client_id, client_secret = await self.register_client()

        # Generate PKCE
        verifier, challenge = generate_pkce()
        state = generate_state()

        # Start callback server
        auth_code_holder = {"code": None, "error": None}
        server = self._start_callback_server(port, state, auth_code_holder)

        try:
            # Build authorize URL
            redirect_uri = f"http://127.0.0.1:{port}/callback"
            params = {
                "response_type": "code",
                "client_id": client_id,
                "redirect_uri": redirect_uri,
                "state": state,
                "code_challenge": challenge,
                "code_challenge_method": "S256",
                "scope": "mcp:read mcp:write",
            }
            authorize_url = f"{self.oauth_base}/authorize?{urlencode(params)}"

            # Open browser
            if not webbrowser.open(authorize_url):
                print(
                    f"Open this URL in your browser: {authorize_url}", file=sys.stderr
                )

            # Wait for callback
            deadline = time.time() + LOGIN_TIMEOUT
            while time.time() < deadline:
                if auth_code_holder["code"] or auth_code_holder["error"]:
                    break
                await asyncio.sleep(0.5)

            if auth_code_holder["error"]:
                raise RuntimeError(f"Login failed: {auth_code_holder['error']}")

            if not auth_code_holder["code"]:
                raise RuntimeError("Login timed out. Run upscaler login to try again.")

            # Exchange code for tokens
            token_data = await self._exchange_code(
                code=auth_code_holder["code"],
                verifier=verifier,
                redirect_uri=redirect_uri,
                client_id=client_id,
                client_secret=client_secret,
            )

            return token_data

        finally:
            server.shutdown()

    async def refresh(self, token_data: TokenData) -> TokenData:
        """Exchange refresh token for new access + refresh tokens.

        Args:
            token_data: Current token data with refresh_token.

        Returns:
            Updated TokenData with new tokens.

        Raises:
            RuntimeError: If refresh fails (session expired).
        """
        payload = {
            "grant_type": "refresh_token",
            "refresh_token": token_data.refresh_token,
            "client_id": token_data.client_id,
            "client_secret": token_data.client_secret,
        }

        async with httpx.AsyncClient(verify=self.verify_ssl) as client:
            response = await client.post(token_data.token_endpoint, data=payload)

        if response.status_code != 200:
            raise RuntimeError("Session expired. Run: upscaler login")

        data = response.json()
        return TokenData(
            access_token=data["access_token"],
            refresh_token=data.get("refresh_token", token_data.refresh_token),
            expires_at=time.time() + data.get("expires_in", 86400),
            client_id=token_data.client_id,
            client_secret=token_data.client_secret,
            organization_id=token_data.organization_id,
            token_endpoint=token_data.token_endpoint,
        )

    async def revoke(self, token_data: TokenData) -> None:
        """Revoke tokens (best-effort — does not raise on failure)."""
        url = f"{self.oauth_base}/revoke"
        payload = {
            "token": token_data.access_token,
            "client_id": token_data.client_id,
            "client_secret": token_data.client_secret,
        }

        try:
            async with httpx.AsyncClient(timeout=5.0, verify=self.verify_ssl) as client:
                await client.post(url, data=payload)
        except Exception as e:
            logger.debug(f"Token revocation failed (best-effort): {e}")

    async def _exchange_code(
        self,
        code: str,
        verifier: str,
        redirect_uri: str,
        client_id: str,
        client_secret: str,
    ) -> TokenData:
        """Exchange authorization code for tokens."""
        token_url = f"{self.oauth_base}/token"
        payload = {
            "grant_type": "authorization_code",
            "code": code,
            "redirect_uri": redirect_uri,
            "code_verifier": verifier,
            "client_id": client_id,
            "client_secret": client_secret,
        }

        async with httpx.AsyncClient(verify=self.verify_ssl) as client:
            response = await client.post(token_url, data=payload)

        if response.status_code != 200:
            raise RuntimeError(
                f"Token exchange failed ({response.status_code}). Run: upscaler login"
            )

        data = response.json()
        return TokenData(
            access_token=data["access_token"],
            refresh_token=data["refresh_token"],
            expires_at=time.time() + data.get("expires_in", 86400),
            client_id=client_id,
            client_secret=client_secret,
            organization_id=data.get("organization_id"),
            token_endpoint=token_url,
        )

    def _is_port_available(self, port: int) -> bool:
        """Check if a port is available for binding."""
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.bind(("127.0.0.1", port))
                return True
        except OSError:
            return False

    def _start_callback_server(
        self, port: int, expected_state: str, result_holder: dict
    ) -> http.server.HTTPServer:
        """Start a localhost HTTP server to receive the OAuth callback."""

        class CallbackHandler(http.server.BaseHTTPRequestHandler):
            def do_GET(self):
                parsed = urlparse(self.path)

                # Ignore non-callback requests (favicon, prefetch, etc.)
                if not parsed.path.rstrip("/").endswith("/callback"):
                    self.send_response(204)
                    self.end_headers()
                    return

                params = parse_qs(parsed.query)

                state = params.get("state", [None])[0]
                code = params.get("code", [None])[0]
                error = params.get("error", [None])[0]

                if error:
                    result_holder["error"] = error
                    self.send_response(200)
                    self.end_headers()
                    self.wfile.write(b"Login failed. You can close this tab.")
                    return

                if state != expected_state:
                    result_holder["error"] = "State mismatch — possible CSRF attack"
                    self.send_response(400)
                    self.end_headers()
                    self.wfile.write(b"State mismatch. Login cancelled.")
                    return

                if code:
                    result_holder["code"] = code
                    self.send_response(200)
                    self.end_headers()
                    self.wfile.write(b"Login successful! You can close this tab.")

            def log_message(self, format, *args):
                pass  # Suppress server logs

        server = http.server.HTTPServer(("127.0.0.1", port), CallbackHandler)
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        return server
