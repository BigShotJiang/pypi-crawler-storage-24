"""Persistent CLI configuration stored at ~/.upscaler/config.json.

Config values are overridden by env vars which are overridden by flags:
    flag > env var > config file > default
"""

import json
import os
from pathlib import Path
from typing import Any, Optional


DEFAULT_CONFIG = {
    "server_url": "",
    "oauth_url": "",
    "default_format": "table",
    "verify_ssl": True,
}

VALID_KEYS = set(DEFAULT_CONFIG.keys())


class CLIConfig:
    """Manages persistent configuration in ~/.upscaler/config.json."""

    CONFIG_FILE = "config.json"

    def __init__(self, config_dir: Optional[str] = None):
        self.config_dir = Path(config_dir or os.path.expanduser("~/.upscaler"))
        self._config: Optional[dict] = None

    def _load(self) -> dict:
        """Load config from disk, or return defaults."""
        if self._config is not None:
            return self._config

        config_path = self.config_dir / self.CONFIG_FILE
        if config_path.exists():
            try:
                self._config = json.loads(config_path.read_text())
            except (json.JSONDecodeError, OSError):
                self._config = dict(DEFAULT_CONFIG)
        else:
            self._config = dict(DEFAULT_CONFIG)
        return self._config

    def get(self, key: str) -> Any:
        """Get a config value."""
        config = self._load()
        return config.get(key, DEFAULT_CONFIG.get(key))

    def set(self, key: str, value: Any) -> None:
        """Set a config value and persist to disk."""
        if key not in VALID_KEYS:
            raise ValueError(f"Unknown config key: {key}. Valid keys: {', '.join(sorted(VALID_KEYS))}")

        config = self._load()
        config[key] = value
        self._save(config)

    def _save(self, config: dict) -> None:
        """Write config to disk."""
        self.config_dir.mkdir(mode=0o700, parents=True, exist_ok=True)
        config_path = self.config_dir / self.CONFIG_FILE
        config_path.write_text(json.dumps(config, indent=2))
        self._config = config

    def resolve_server_url(
        self, flag_value: Optional[str] = None
    ) -> str:
        """Resolve server URL: flag > env > config > empty.

        Args:
            flag_value: --server flag value (highest priority).

        Returns:
            Resolved server URL string.
        """
        if flag_value:
            return flag_value
        env_value = os.environ.get("UPSCALER_SERVER")
        if env_value:
            return env_value
        return self.get("server_url") or ""

    def resolve_verify_ssl(self) -> bool:
        """Resolve SSL verification: env > config > default (True).

        Set to False for self-signed certs in dev/staging:
            upscaler config set verify_ssl false
            UPSCALER_VERIFY_SSL=false upscaler health
        """
        env_value = os.environ.get("UPSCALER_VERIFY_SSL")
        if env_value is not None:
            return env_value.lower() not in ("false", "0", "no")
        val = self.get("verify_ssl")
        if isinstance(val, bool):
            return val
        if isinstance(val, str):
            return val.lower() not in ("false", "0", "no")
        return True
