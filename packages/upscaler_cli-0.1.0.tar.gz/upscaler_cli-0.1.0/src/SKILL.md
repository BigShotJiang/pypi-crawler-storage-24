# Upscaler CLI

Search, retrieve, and manage Upscaler documents, records, and workflows.

## Setup

```bash
pip install up-sdk
upscaler config set server_url https://your-api-url.com
upscaler config set verify_ssl false  # for dev/staging with self-signed certs
upscaler login
```

## Important: Global flags go BEFORE the command

```bash
upscaler --json list todos        # correct
upscaler list todos --json        # WRONG — --json is a global flag
upscaler --verbose --json search "query"  # correct
```

## Commands

### Read

```bash
upscaler search "safety procedures"                          # table output
upscaler --json search "compliance" --limit 5 --type policy  # JSON output
upscaler get <asset_id>                                      # asset overview
upscaler get <asset_id> --format markdown                    # document content
upscaler get <asset_id> --format schema                      # field schema
upscaler get <uid> --type member                             # member by ID
upscaler get <group_id> --type group                         # group by ID (also auto-detected for g_ prefix)
upscaler hierarchy <asset_id>                                # asset tree
upscaler hierarchy <asset_id> --depth 5                      # deep tree
upscaler list definitions                                    # all definitions
upscaler list entries --definition-id <id>                   # entries for a definition
upscaler list todos                                          # your todos
upscaler list field-options --definition-id <id> --field-key <key>
```

### Write (use --dry-run to preview changes)

```bash
upscaler todo create --title "Review doc"
upscaler todo close <id>
upscaler entry create --definition-id <id> --data @payload.json
upscaler entry update --entry-id <id> --data '{"values": {...}}'
upscaler asset create --type register_definition --data '{"title": "..."}'
upscaler asset delete --asset-id <id> --dry-run              # preview only
```

### Data Input

Write commands accept `--data` in three forms:

- Flag value: `--data '{"key": "value"}'`
- File reference: `--data @payload.json` (safest — avoids shell escaping)
- Stdin pipe: `echo '{}' | upscaler entry create --data -`

### Utility

```bash
upscaler health                   # check server connectivity
upscaler status                   # check auth state
upscaler config set <key> <value> # persist settings
upscaler config get <key>         # read settings
```

## Agent Usage

Always use `--json` (global flag, before the command) for structured output:

```bash
upscaler --json search "audit"
upscaler --json get <asset_id>
upscaler --json list todos
upscaler --json todo create --title "x"
```

## Error Handling

- Exit code 0 = success
- Exit code 1 = error → check stderr for details
- Exit code 2 = auth required → tell user to run `upscaler login`
