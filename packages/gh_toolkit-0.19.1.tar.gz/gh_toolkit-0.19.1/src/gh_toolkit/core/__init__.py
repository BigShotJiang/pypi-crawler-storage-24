# Core functionality
