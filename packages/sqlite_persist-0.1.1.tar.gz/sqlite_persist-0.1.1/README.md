# sqlite-persistence

Classe de base ORM légère pour SQLite, sans dépendances externes.

## Installation

```bash
uv add sqlite-persist
# ou
uv add git+https://codeberg.com/styfore/sqlite-persist.git
```

## Usage minimal

```python
from sqlite_persist import Persistence
import sqlite3

con = sqlite3.connect("ma_base.db")

class User(Persistence):
    def __init__(self, id, username, password):
        self.id = id
        self.username = username
        self.password = password

# Lecture
user = User.get(1, con=con)
users = User.get_by({"username": "alice"}, con=con)
users = User.get_by({"username": "alice"}, order_by="username", con=con)

# Écriture
user.upsert(con=con)     # insert ou replace
user.update(con=con)     # update strict (la ligne doit exister)
user.insert(con=con)     # insert, met à jour self.id après
user.delete(con=con)

# Batch
User.upsert_all([u1, u2, u3], con=con)
User.delete_all([u1, u2], con=con)
User.delete_where({"username": "bob"}, con=con)
User.update_where(values={"password": "..."}, where={"username": "alice"}, con=con)
```

## Injection automatique de connexion (ex. Flask)

Créer une classe intermédiaire qui surcharge `_con()` :

```python
from sqlite_persistence import Persistence
from mon_app.db import get_db

class FlaskPersistence(Persistence):
    @classmethod
    def _con(cls):
        return get_db()

class User(FlaskPersistence):
    ...

# con= n'est plus nécessaire
user = User.get(1)
user.save()
```

## Clé primaire composite

```python
class Day(FlaskPersistence):
    _pk = ("month", "day")

day = Day.get("12", "01")
```

## Attributs transitoires

Tout attribut commençant par `_` est ignoré lors des opérations SQL :

```python
class User(FlaskPersistence):
    _table = "user"  # si le nom de table diffère de la classe, par défaut le nom de la classe
    
    def __init__(self, id, name):
        self.id = id
        self.name = name
        self._transient = None  # jamais envoyé en base
```