from __future__ import annotations

import sqlite3
from collections.abc import Collection
from typing import Any, ClassVar, Self


class Persistence:
    _columns_cache: ClassVar[dict[str, set[str]]] = {}
    _pk: str | tuple[str, ...] = "id"
    _table: ClassVar[str | None] = None

    # ── Utilitaires internes ───────────────────────────────────────────────

    @classmethod
    def _pk_columns(cls) -> tuple[str, ...]:
        return (cls._pk,) if isinstance(cls._pk, str) else tuple(cls._pk)

    def _pk_dict(self) -> dict:
        return {col: self.__dict__[col] for col in self._pk_columns()}

    @classmethod
    def _pk_where_clause(cls) -> str:
        return " AND ".join(f"{col}=:{col}" for col in cls._pk_columns())

    @classmethod
    def _table_name(cls) -> str:
        return cls._table or cls.__name__

    @classmethod
    def _con(cls) -> sqlite3.Connection:
        raise NotImplementedError("Passez con= explicitement ou surchargez _con().")

    @classmethod
    def _check_columns(cls, con: sqlite3.Connection, keys: Collection) -> None:
        if cls._table_name() not in cls._columns_cache:
            cur = con.execute(f"SELECT name FROM pragma_table_info('{cls._table_name()}')")  # noqa: S608
            cls._columns_cache[cls._table_name()] = {row[0] for row in cur.fetchall()}

        valid_columns = cls._columns_cache[cls._table_name()]
        invalid = set(keys) - valid_columns
        if invalid:
            raise ValueError(f"Colonnes invalides : {invalid}")

    def _row_data(self) -> dict:
        return {k: v for k, v in self.__dict__.items() if not k.startswith("_")}

    def __repr__(self) -> str:
        pk_cols = self._pk_columns()
        pk_str = ", ".join(f"{col}={self.__dict__.get(col)!r}" for col in pk_cols)
        rest_str = ", ".join(f"{k}={v!r}" for k, v in self.__dict__.items() if k not in pk_cols and not k.startswith("_"))
        return f"{self._table_name()}[{pk_str} | {rest_str}]"

    # ── Lecture ────────────────────────────────────────────────────────────

    @classmethod
    def find(cls, *pk_values, con: sqlite3.Connection | None = None) -> Self | None:
        con: sqlite3.Connection = con or cls._con()
        pk_cols = cls._pk_columns()
        if len(pk_values) != len(pk_cols):
            raise ValueError(f"{cls._table_name()} attend {len(pk_cols)} valeur(s) de PK : {pk_cols}")
        params = dict(zip(pk_cols, pk_values, strict=False))

        cursor = con.cursor()
        cursor.row_factory = sqlite3.Row
        row = cursor.execute(
            f"SELECT * FROM {cls._table_name()} WHERE {cls._pk_where_clause()}",  # noqa: S608
            params,
        ).fetchone()
        cursor.close()

        if row is not None:
            o: Self = object.__new__(cls)
            o.__dict__.update(dict(row))
            return o
        return None

    @classmethod
    def get(cls, *pk_values, con: sqlite3.Connection | None = None) -> Self:
        result = cls.find(*pk_values, con=con)
        if result is None:
            raise KeyError(f"{cls._table_name()} introuvable : {pk_values}")
        return result

    @classmethod
    def get_by(
        cls,
        parameters: dict[str, Any],
        order_by: str | list[str] | None = None,
        con: sqlite3.Connection | None = None,
    ) -> list[Self]:
        con: sqlite3.Connection = con or cls._con()
        cls._check_columns(con, parameters.keys())
        where = " AND ".join(f"{k}=:{k}" for k in parameters)
        query = f"SELECT * FROM {cls._table_name()} WHERE {where}"  # noqa: S608

        if order_by is not None:
            cols = [order_by] if isinstance(order_by, str) else order_by
            query += f" ORDER BY {', '.join(cols)}"

        cursor = con.cursor()
        cursor.row_factory = sqlite3.Row
        rows = cursor.execute(query, parameters).fetchall()
        cursor.close()

        objects: list[Self] = []
        for row in rows:
            o: Self = object.__new__(cls)
            o.__dict__.update(dict(row))
            objects.append(o)
        return objects

    # ── Insertion ──────────────────────────────────────────────────────────

    def insert(self, con: sqlite3.Connection | None = None) -> None:
        con: sqlite3.Connection = con or self._con()
        data: dict = self._row_data()
        self._check_columns(con, data.keys())
        cols = ", ".join(data.keys())
        placeholders = ", ".join(f":{k}" for k in data)
        cursor = con.execute(
            f"INSERT INTO {self._table_name()} ({cols}) VALUES ({placeholders})",  # noqa: S608
            data,
        )
        con.commit()
        if cursor.lastrowid is not None:
            pk_cols = self._pk_columns()
            self.__dict__[pk_cols[0]] = cursor.lastrowid

    @classmethod
    def insert_all(cls, items: list[Self], con: sqlite3.Connection | None = None) -> None:
        con: sqlite3.Connection = con or cls._con()
        if not items:
            return
        sample = items[0]._row_data()
        cls._check_columns(con, sample.keys())
        cols = ", ".join(sample.keys())
        placeholders = ", ".join(f":{k}" for k in sample)
        cursor = con.executemany(
            f"INSERT INTO {cls._table_name()} ({cols}) VALUES ({placeholders})",  # noqa: S608
            [item._row_data() for item in items],
        )
        con.commit()
        if cursor.lastrowid is not None:
            first_id = cursor.lastrowid - len(items) + 1
            pk_col = cls._pk_columns()[0]
            for item, generated_id in zip(items, range(first_id, cursor.lastrowid + 1), strict=False):
                item.__dict__[pk_col] = generated_id

    # ── Mise à jour ────────────────────────────────────────────────────────

    def update(self, con: sqlite3.Connection | None = None) -> None:
        con: sqlite3.Connection = con or self._con()
        data: dict = self._row_data()
        self._check_columns(con, data.keys())
        pk_cols = self._pk_columns()
        missing = [col for col in pk_cols if col not in data]
        if missing:
            raise ValueError(f"Colonnes PK manquantes dans l'instance : {missing}")
        set_clause = ", ".join(f"{k}=:{k}" for k in data if k not in pk_cols)
        con.execute(
            f"UPDATE {self._table_name()} SET {set_clause} WHERE {self._pk_where_clause()}",  # noqa: S608
            data,
        )
        con.commit()

    @classmethod
    def update_where(cls, values: dict[str, Any], where: dict[str, Any], con: sqlite3.Connection | None = None) -> None:
        con: sqlite3.Connection = con or cls._con()
        cls._check_columns(con, list(values.keys()) + list(where.keys()))
        set_clause = ", ".join(f"{k}=:set_{k}" for k in values)
        where_clause = " AND ".join(f"{k}=:where_{k}" for k in where)
        params = {f"set_{k}": v for k, v in values.items()} | {f"where_{k}": v for k, v in where.items()}
        con.execute(
            f"UPDATE {cls._table_name()} SET {set_clause} WHERE {where_clause}",  # noqa: S608
            params,
        )
        con.commit()

    @classmethod
    def update_all(cls, items: list[Self], con: sqlite3.Connection | None = None) -> None:
        con: sqlite3.Connection = con or cls._con()
        if not items:
            return
        pk_cols = cls._pk_columns()
        sample = items[0]._row_data()
        cls._check_columns(con, sample.keys())
        missing = [col for col in pk_cols if col not in sample]
        if missing:
            raise ValueError(f"Colonnes PK manquantes : {missing}")
        set_clause = ", ".join(f"{k}=:{k}" for k in sample if k not in pk_cols)
        con.executemany(
            f"UPDATE {cls._table_name()} SET {set_clause} WHERE {cls._pk_where_clause()}",  # noqa: S608
            [item._row_data() for item in items],
        )
        con.commit()

    # ── Suppression ────────────────────────────────────────────────────────

    def delete(self, con: sqlite3.Connection | None = None) -> None:
        con: sqlite3.Connection = con or self._con()
        con.execute(
            f"DELETE FROM {self._table_name()} WHERE {self._pk_where_clause()}",  # noqa: S608
            self._pk_dict(),
        )
        con.commit()

    @classmethod
    def delete_where(cls, parameters: dict[str, Any], con: sqlite3.Connection | None = None) -> None:
        con: sqlite3.Connection = con or cls._con()
        cls._check_columns(con, parameters.keys())
        where_clause = " AND ".join(f"{k}=:{k}" for k in parameters)
        con.execute(
            f"DELETE FROM {cls._table_name()} WHERE {where_clause}",  # noqa: S608
            parameters,
        )
        con.commit()

    @classmethod
    def delete_all(cls, items: list[Self], con: sqlite3.Connection | None = None) -> None:
        con: sqlite3.Connection = con or cls._con()
        if not items:
            return
        con.executemany(
            f"DELETE FROM {cls._table_name()} WHERE {cls._pk_where_clause()}",  # noqa: S608
            [item._pk_dict() for item in items],
        )
        con.commit()

    # ── Upsert ────────────────────────────────────────────────────────

    def upsert(self, con: sqlite3.Connection | None = None) -> None:
        con: sqlite3.Connection = con or self._con()
        data: dict = self._row_data()
        self._check_columns(con, data.keys())
        cols = ", ".join(data.keys())
        placeholders = ", ".join(f":{k}" for k in data)
        cursor = con.execute(
            f"INSERT OR REPLACE INTO {self._table_name()} ({cols}) VALUES ({placeholders})",  # noqa: S608
            data,
        )
        con.commit()
        # Récupère l'id généré uniquement si la PK était absente
        pk_cols = self._pk_columns()
        if len(pk_cols) == 1 and self.__dict__.get(pk_cols[0]) is None:
            self.__dict__[pk_cols[0]] = cursor.lastrowid

    @classmethod
    def upsert_all(cls, items: list[Self], con: sqlite3.Connection | None = None) -> None:
        if not items:
            return
        con: sqlite3.Connection = con or cls._con()
        sample = items[0]._row_data()
        cls._check_columns(con, sample.keys())
        cols = ", ".join(sample.keys())
        placeholders = ", ".join(f":{k}" for k in sample)
        con.executemany(
            f"INSERT OR REPLACE INTO {cls._table_name()} ({cols}) VALUES ({placeholders})",  # noqa: S608
            [item._row_data() for item in items],
        )
        con.commit()
