"""
Pose processing and normalization utilities.
"""

from sltk.processing.features import (
    compute_angle_features,
    compute_body_angles,
    compute_body_angles_from_smplx,
    compute_hamer_features,
    compute_hand_angles,
    load_features_from_h5,
    load_features_from_nlf_wilor,
    save_features,
)
from sltk.processing.normalization import (
    align_facing_direction,
    compute_acceleration,
    compute_velocity,
    face_center,
    hip_center,
    normalize_poses,
    scale_to_unit_palm,
    scale_to_unit_shoulders,
    scale_to_unit_torso,
    shoulder_center,
    wrist_center,
)

__all__ = [
    "normalize_poses",
    "shoulder_center",
    "hip_center",
    "face_center",
    "wrist_center",
    "scale_to_unit_torso",
    "scale_to_unit_shoulders",
    "scale_to_unit_palm",
    "align_facing_direction",
    "compute_velocity",
    "compute_acceleration",
    # Feature computation
    "compute_angle_features",
    "compute_hamer_features",
    "compute_body_angles",
    "compute_body_angles_from_smplx",
    "compute_hand_angles",
    "load_features_from_h5",
    "load_features_from_nlf_wilor",
    "save_features",
]
