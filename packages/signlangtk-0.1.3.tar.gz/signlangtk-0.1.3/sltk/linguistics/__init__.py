"""
Linguistic analysis tools for sign language research.

This module provides specialized tools for linguistic analysis of sign language
data, with a focus on features specific to visual-gestural languages.

Submodules:
    phonology: Phonological representations and analysis (HLMO parameters)
    nonmanual: Non-manual signal (NMS) analysis tools
    reliability: Inter-rater reliability metrics for corpus annotation

The phonological model follows standard sign language linguistics
frameworks based on Stokoe (1960), Battison (1978), and Brentari (1998).
"""

from sltk.linguistics.nonmanual import (
    # Constants
    GRAMMATICAL_MARKERS,
    NMS_TIERS,
    # Result dataclasses
    GrammaticalPattern,
    NMSCooccurrenceResult,
    NMSDurationStats,
    NMSInventoryResult,
    NMSScopeResult,
    NMSTimingResult,
    ScopeExample,
    # Main analysis functions
    analyze_nms_cooccurrence,
    analyze_nms_inventory,
    analyze_nms_scope,
    analyze_nms_timing,
    detect_grammatical_patterns,
    # Convenience functions
    get_grammatical_markers,
    get_standard_nms_tiers,
    nms_duration_stats,
    summarize_nms,
)
from sltk.linguistics.phonology import (
    # Constants
    CORE_PARAMETERS,
    EXTENDED_PARAMETERS,
    # Enums - Standard inventories
    FingerOrientation,
    HandArrangement,
    Handshape,
    # Data models
    InventoryStats,
    LinguisticSegment,
    Location,
    Movement,
    NonManualSignal,
    PalmOrientation,
    PhonologicalForm,
    # Inventory analysis
    analyze_inventory,
    compute_phonological_neighborhood,
    filter_by_parameter,
    # Minimal pair detection
    find_minimal_pairs,
    find_near_minimal_pairs,
    # Distance functions
    get_differing_parameters,
    group_by_parameter,
    phonological_distance,
)
from sltk.linguistics.reliability import (
    # Result dataclasses
    BoundaryAgreementResult,
    ConfusionMatrixResult,
    KappaResult,
    LabelAgreementResult,
    ReliabilityResult,
    # Temporal agreement
    analyze_reliability_by_tier,
    # Confusion matrix
    annotation_confusion_matrix,
    boundary_agreement,
    # Kappa metrics
    cohens_kappa,
    fleiss_kappa,
    krippendorff_alpha,
    temporal_label_agreement,
)

__all__ = [
    # Phonology - Constants
    "CORE_PARAMETERS",
    "EXTENDED_PARAMETERS",
    # Phonology - Standard inventories (enums)
    "Handshape",
    "Location",
    "Movement",
    "PalmOrientation",
    "FingerOrientation",
    "HandArrangement",
    "NonManualSignal",
    # Phonology - Data models
    "PhonologicalForm",
    "LinguisticSegment",
    "InventoryStats",
    # Phonology - Distance functions
    "phonological_distance",
    "get_differing_parameters",
    # Phonology - Minimal pair detection
    "find_minimal_pairs",
    "find_near_minimal_pairs",
    # Phonology - Inventory analysis
    "analyze_inventory",
    "filter_by_parameter",
    "group_by_parameter",
    "compute_phonological_neighborhood",
    # Non-manual constants
    "NMS_TIERS",
    "GRAMMATICAL_MARKERS",
    # Non-manual result dataclasses
    "ScopeExample",
    "NMSCooccurrenceResult",
    "NMSScopeResult",
    "GrammaticalPattern",
    "NMSDurationStats",
    "NMSTimingResult",
    "NMSInventoryResult",
    # Non-manual analysis functions
    "analyze_nms_cooccurrence",
    "analyze_nms_scope",
    "detect_grammatical_patterns",
    "nms_duration_stats",
    "analyze_nms_timing",
    "analyze_nms_inventory",
    # Non-manual convenience functions
    "get_standard_nms_tiers",
    "get_grammatical_markers",
    "summarize_nms",
    # Reliability result dataclasses
    "KappaResult",
    "BoundaryAgreementResult",
    "LabelAgreementResult",
    "ReliabilityResult",
    "ConfusionMatrixResult",
    # Reliability kappa metrics
    "cohens_kappa",
    "fleiss_kappa",
    "krippendorff_alpha",
    # Reliability temporal agreement
    "boundary_agreement",
    "temporal_label_agreement",
    "analyze_reliability_by_tier",
    # Reliability confusion matrix
    "annotation_confusion_matrix",
]
