"""
Glossing and dictionary lookup tools.

Provides utilities for working with sign language glosses:
- Vocabulary management (build, save, load)
- Gloss encoding/decoding for model training
- Gloss normalization and categorization

Example:
    from sltk.glossing import Vocabulary

    # Build vocabulary from dataset
    vocab = Vocabulary.from_samples(dataset)

    # Encode glosses for training
    ids = vocab.encode(["HELLO", "WORLD"], add_bos=True, add_eos=True)
"""

from sltk.glossing.vocabulary import (
    Vocabulary,
    gloss_category,
    is_fingerspelling,
    is_pointing_sign,
    normalize_gloss,
    parse_compound_gloss,
)

__all__ = [
    "Vocabulary",
    "normalize_gloss",
    "parse_compound_gloss",
    "is_pointing_sign",
    "is_fingerspelling",
    "gloss_category",
]
