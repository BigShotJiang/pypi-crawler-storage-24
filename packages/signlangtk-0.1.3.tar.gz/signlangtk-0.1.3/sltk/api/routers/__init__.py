"""
SLTK API Routers.

Each router handles a specific domain of functionality.
"""

from sltk.api.routers.admin import router as admin_router
from sltk.api.routers.analysis import router as analysis_router
from sltk.api.routers.audio import router as audio_router
from sltk.api.routers.chat import router as chat_router
from sltk.api.routers.corpus import router as corpus_router
from sltk.api.routers.datasets import router as datasets_router
from sltk.api.routers.embeddings import router as embeddings_router
from sltk.api.routers.extraction import router as extraction_router
from sltk.api.routers.features import router as features_router
from sltk.api.routers.jobs import router as jobs_router
from sltk.api.routers.linguistics import router as linguistics_router
from sltk.api.routers.nm_annotator import router as nm_annotator_router
from sltk.api.routers.nms import router as nms_router
from sltk.api.routers.poses import router as poses_router
from sltk.api.routers.processing import router as processing_router
from sltk.api.routers.search import router as search_router
from sltk.api.routers.segmentation import router as segmentation_router
from sltk.api.routers.settings import router as settings_router
from sltk.api.routers.signrep import router as signrep_router
from sltk.api.routers.videos import router as videos_router
from sltk.api.routers.visualization import router as visualization_router
from sltk.api.routers.workspace import router as workspace_router

__all__ = [
    "admin_router",
    "analysis_router",
    "audio_router",
    "chat_router",
    "corpus_router",
    "datasets_router",
    "embeddings_router",
    "extraction_router",
    "features_router",
    "jobs_router",
    "linguistics_router",
    "nm_annotator_router",
    "nms_router",
    "poses_router",
    "processing_router",
    "search_router",
    "segmentation_router",
    "settings_router",
    "signrep_router",
    "videos_router",
    "visualization_router",
    "workspace_router",
]
