"""
SLTK FastAPI Backend.

Provides REST API endpoints for:
- Video discovery and extraction pipelines
- Pose visualization data
- Segmentation evaluation
- Dataset browsing
- Linguistic analysis
- Feature management
"""

from sltk.api.main import app, create_app

__all__ = ["app", "create_app"]
