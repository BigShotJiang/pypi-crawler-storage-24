"""SQLite corpus database for per-workspace ELAN annotation storage."""

from __future__ import annotations

from sltk.db.corpus import CorpusDB

__all__ = ["CorpusDB"]
