"""
Analysis tools for sign language research.

Includes clustering, dimensionality reduction, dataset comparison,
lexical statistics, linguistic analysis, caption-based analysis,
and cross-dataset comparison tools.
"""

from sltk.analysis.captions import (
    CaptionSegment,
    CaptionStatistics,
    analyze_caption_corpus,
    build_caption_concordance,
    compute_caption_alignment_stats,
    extract_caption_keywords,
    extract_caption_ngrams,
    search_captions,
)
from sltk.analysis.clustering import (
    ClusteringResult,
    PoseClusterer,
    cluster_embeddings,
    find_similar,
    reduce_dimensions,
)
from sltk.analysis.cross_dataset import (
    ContextPattern,
    CrossDatasetResult,
    DatasetCache,
    DurationStats,
    GlossMatch,
    ParallelExample,
    VocabularyComparison,
    analyze_gloss_contexts,
    batch_find_glosses,
    compare_dataset_vocabularies,
    compare_gloss_durations,
    find_common_glosses,
    find_gloss_across_datasets,
    find_parallel_examples,
    get_dataset_vocabulary_summary,
)
from sltk.analysis.datasets import (
    DatasetComparison,
    LexicalStatistics,
    compare_datasets,
    lexical_statistics,
    pos_analysis,
    vocabulary_growth,
)
from sltk.analysis.linguistic import (
    ConcordanceLine,
    CooccurrenceResult,
    DurationAnalysis,
    MinimalPair,
    NGram,
    SegmentReference,
    analyze_cooccurrence,
    analyze_duration_patterns,
    analyze_signer_variation,
    build_concordance,
    compute_cooccurrence_matrix,
    extract_ngrams,
    find_minimal_pairs,
)

__all__ = [
    # Clustering
    "cluster_embeddings",
    "find_similar",
    "reduce_dimensions",
    "ClusteringResult",
    "PoseClusterer",
    # Dataset analysis
    "lexical_statistics",
    "compare_datasets",
    "pos_analysis",
    "vocabulary_growth",
    "LexicalStatistics",
    "DatasetComparison",
    # Linguistic analysis (gloss-based)
    "ConcordanceLine",
    "NGram",
    "CooccurrenceResult",
    "DurationAnalysis",
    "MinimalPair",
    "SegmentReference",
    "build_concordance",
    "analyze_cooccurrence",
    "extract_ngrams",
    "analyze_duration_patterns",
    "find_minimal_pairs",
    "analyze_signer_variation",
    "compute_cooccurrence_matrix",
    # Caption-based analysis
    "CaptionSegment",
    "CaptionStatistics",
    "analyze_caption_corpus",
    "extract_caption_keywords",
    "search_captions",
    "compute_caption_alignment_stats",
    "build_caption_concordance",
    "extract_caption_ngrams",
    # Cross-dataset analysis
    "ContextPattern",
    "CrossDatasetResult",
    "DatasetCache",
    "DurationStats",
    "GlossMatch",
    "ParallelExample",
    "VocabularyComparison",
    "analyze_gloss_contexts",
    "batch_find_glosses",
    "compare_dataset_vocabularies",
    "compare_gloss_durations",
    "find_common_glosses",
    "find_gloss_across_datasets",
    "find_parallel_examples",
    "get_dataset_vocabulary_summary",
]
