"""
Sign language video embedding and similarity search.

This module provides:
- SignRepPipeline: Full inference pipeline with dictionary extraction,
  continuous features, and gloss spotting
- SignRepEmbedder: Backward-compatible wrapper for simple embedding
- Cross-dataset similarity search using cosine similarity
- Self-contained SignRep model architecture (Hiera backbone + projection heads)

Example:
    from sltk.embedding import SignRepPipeline, SignRepEmbedder

    # Full pipeline
    pipeline = SignRepPipeline()
    result = pipeline.extract_dictionary("sign.mp4", method="middle")
    result = pipeline.spot_from_video("video.mp4", "segments.json", ["dicts/"])

    # Simple embedding (backward-compatible)
    embedder = SignRepEmbedder()
    embedding = embedder.embed_video("video.mp4")

    # Similarity search
    from sltk.embedding import SimilaritySearch
    search = SimilaritySearch(embedder)
    matches = search.find_similar("query_video.mp4", datasets=["wlasl", "bslcp"])
"""

__all__ = [
    # Full pipeline
    "SignRepPipeline",
    "DictionaryResult",
    "ContinuousResult",
    "DictionaryIndex",
    "SegmentMatch",
    "SpottingResult",
    "POOLING_METHODS",
    "SEGMENT_POOLING",
    "get_pipeline",
    # Backward-compatible API
    "SignRepEmbedder",
    "SignRepConfig",
    "SimilaritySearch",
    "SimilarityMatch",
    "EmbeddingStore",
    "compute_cosine_similarity",
    # Model architecture
    "SignRepModel",
    "Hiera",
    "MaskedAutoencoderHiera",
    "ProjectionModel",
    "Transformation",
]


def __getattr__(name):
    if name in (
        "POOLING_METHODS",
        "SEGMENT_POOLING",
        "ContinuousResult",
        "DictionaryIndex",
        "DictionaryResult",
        "SegmentMatch",
        "SignRepPipeline",
        "SpottingResult",
        "get_pipeline",
    ):
        from sltk.embedding.pipeline import (
            POOLING_METHODS,
            SEGMENT_POOLING,
            ContinuousResult,
            DictionaryIndex,
            DictionaryResult,
            SegmentMatch,
            SignRepPipeline,
            SpottingResult,
            get_pipeline,
        )

        return locals()[name]

    if name in ("SignRepConfig", "SignRepEmbedder"):
        from sltk.embedding.signrep import SignRepConfig, SignRepEmbedder

        return locals()[name]

    if name in (
        "Hiera",
        "MaskedAutoencoderHiera",
        "ProjectionModel",
        "SignRepModel",
        "Transformation",
    ):
        from sltk.embedding.signrep_models import (
            Hiera,
            MaskedAutoencoderHiera,
            ProjectionModel,
            SignRepModel,
            Transformation,
        )

        return locals()[name]

    if name in (
        "EmbeddingStore",
        "SimilarityMatch",
        "SimilaritySearch",
        "compute_cosine_similarity",
    ):
        from sltk.embedding.similarity import (
            EmbeddingStore,
            SimilarityMatch,
            SimilaritySearch,
            compute_cosine_similarity,
        )

        return locals()[name]

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
