"""SignRep models for sign language representation learning.

This module contains the SignRep model architecture including:
- Hiera backbone (hierarchical vision transformer)
- MAE (Masked Autoencoder) variants
- Projection heads for downstream tasks
- Video augmentation transforms
"""

from sltk.embedding.signrep_models.augmentation import Transformation
from sltk.embedding.signrep_models.backbones import (
    Hiera,
    HieraClsToken,
    MaskedAutoencoderHiera,
    mae_hiera_base_16x224,
)
from sltk.embedding.signrep_models.final_model import Model as SignRepModel
from sltk.embedding.signrep_models.heads import ProjectionModel

__all__ = [
    "SignRepModel",
    "Hiera",
    "HieraClsToken",
    "MaskedAutoencoderHiera",
    "mae_hiera_base_16x224",
    "ProjectionModel",
    "Transformation",
]
