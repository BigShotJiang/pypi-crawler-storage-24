"""Hiera backbone models for SignRep."""

from sltk.embedding.signrep_models.backbones.hiera import (
    Hiera,
    HieraBlock,
    MaskUnitAttention,
    Head,
    PatchEmbed,
    hiera_tiny_224,
    hiera_small_224,
    hiera_base_224,
    hiera_base_plus_224,
    hiera_large_224,
    hiera_huge_224,
    hiera_base_16x224,
    hiera_base_plus_16x224,
    hiera_large_16x224,
    hiera_huge_16x224,
)

from sltk.embedding.signrep_models.backbones.hiera_clstoken import (
    Hiera as HieraClsToken,
)

from sltk.embedding.signrep_models.backbones.hiera_nodec_mae import (
    MaskedAutoencoderHiera,
    mae_hiera_tiny_224,
    mae_hiera_small_224,
    mae_hiera_base_224,
    mae_hiera_base_plus_224,
    mae_hiera_large_224,
    mae_hiera_huge_224,
    mae_hiera_base_16x224,
    mae_hiera_base_plus_16x224,
    mae_hiera_large_16x224,
    mae_hiera_huge_16x224,
)

from sltk.embedding.signrep_models.backbones.hiera_utils import (
    pretrained_model,
    conv_nd,
    do_pool,
    do_masked_conv,
    undo_windowing,
    Unroll,
    Reroll,
)

from sltk.embedding.signrep_models.backbones.hfhub import (
    PyTorchModelHubMixin,
    has_config,
    is_huggingface_hub_available,
)

__all__ = [
    # Core Hiera
    "Hiera",
    "HieraBlock",
    "MaskUnitAttention",
    "Head",
    "PatchEmbed",
    # Hiera with CLS token
    "HieraClsToken",
    # MAE variants
    "MaskedAutoencoderHiera",
    # Image model constructors
    "hiera_tiny_224",
    "hiera_small_224",
    "hiera_base_224",
    "hiera_base_plus_224",
    "hiera_large_224",
    "hiera_huge_224",
    # Video model constructors
    "hiera_base_16x224",
    "hiera_base_plus_16x224",
    "hiera_large_16x224",
    "hiera_huge_16x224",
    # MAE model constructors
    "mae_hiera_tiny_224",
    "mae_hiera_small_224",
    "mae_hiera_base_224",
    "mae_hiera_base_plus_224",
    "mae_hiera_large_224",
    "mae_hiera_huge_224",
    "mae_hiera_base_16x224",
    "mae_hiera_base_plus_16x224",
    "mae_hiera_large_16x224",
    "mae_hiera_huge_16x224",
    # Utilities
    "pretrained_model",
    "conv_nd",
    "do_pool",
    "do_masked_conv",
    "undo_windowing",
    "Unroll",
    "Reroll",
    "PyTorchModelHubMixin",
    "has_config",
    "is_huggingface_hub_available",
]
