"""
Dataset loaders for common sign language datasets.

Supported datasets:

Isolated Sign Recognition:
- WLASL: Word-Level American Sign Language (2000+ signs)
- ASLDict: ASL Dictionary (isolated signs from online dictionaries)
- ASL Citizen: Community-sourced ASL (diverse signers)

Continuous Sign Language:
- BSLCP: British Sign Language Corpus Project (multiview, ELAN)
- BOBSL: BBC-Oxford British Sign Language (mouthings/subtitles)
- How2Sign: Large-scale multimodal ASL (instructional videos)
- Phoenix-2014T: German Sign Language (weather broadcasts)
- CSL-Daily: Chinese Sign Language (daily conversations)

Caption-Based (no glosses):
- YTSL-25: YouTube Sign Language 25 (multilingual, 25 languages)
- YT-ASL: YouTube ASL (large-scale subtitle-based)

Usage:
    from sltk.data.datasets import (
        BSLCPDataset, BOBSLDataset, ASLDictDataset,
        WLASLDataset, How2SignDataset, Phoenix2014TDataset,
        CSLDailyDataset, ASLCitizenDataset, YTSL25Dataset, YTASLDataset,
    )

    # Load BSLCP with gloss annotations
    bslcp = BSLCPDataset(load_poses=True, pose_format="wilor")

    # Load WLASL-100
    wlasl = WLASLDataset(root="/path/to/wlasl", num_classes=100)

    # Load YTSL-25 for BSL
    ytsl = YTSL25Dataset(root="/path/to/ytsl", language="bsl")
"""

from sltk.data.datasets.asl_citizen import ASLCitizenDataset
from sltk.data.datasets.asldict import ASLDictDataset
from sltk.data.datasets.base import BaseDataset
from sltk.data.datasets.bobsl import BOBSLDataset
from sltk.data.datasets.bslcp import BSLCPDataset
from sltk.data.datasets.csl_daily import CSLDailyDataset
from sltk.data.datasets.how2sign import How2SignDataset
from sltk.data.datasets.phoenix import Phoenix2014TDataset
from sltk.data.datasets.wlasl import WLASLDataset
from sltk.data.datasets.ytsl import YTASLDataset, YTSL25Dataset
from sltk.exceptions import DatasetNotFoundError

# Registry of available datasets
DATASETS = {
    # British Sign Language
    "bslcp": BSLCPDataset,
    "bobsl": BOBSLDataset,
    # American Sign Language
    "asldict": ASLDictDataset,
    "wlasl": WLASLDataset,
    "how2sign": How2SignDataset,
    "asl_citizen": ASLCitizenDataset,
    "yt_asl": YTASLDataset,
    # German Sign Language
    "phoenix2014t": Phoenix2014TDataset,
    # Chinese Sign Language
    "csl_daily": CSLDailyDataset,
    # Multilingual
    "ytsl25": YTSL25Dataset,
}

# Mapping of sign languages to available datasets
LANGUAGE_DATASETS = {
    "asl": ["asldict", "wlasl", "how2sign", "asl_citizen", "yt_asl"],
    "bsl": ["bslcp", "bobsl"],
    "dgs": ["phoenix2014t"],
    "csl": ["csl_daily"],
}


def get_dataset(name: str, **kwargs):
    """
    Get a dataset by name.

    Args:
        name: Dataset name (e.g., 'wlasl', 'bslcp')
        **kwargs: Arguments to pass to the dataset constructor

    Returns:
        Dataset instance

    Example:
        >>> dataset = get_dataset("wlasl", root="/path/to/wlasl", num_classes=100)
    """
    name_lower = name.lower().replace("-", "_")
    if name_lower not in DATASETS:
        raise DatasetNotFoundError(name)
    return DATASETS[name_lower](**kwargs)


def list_datasets() -> list:
    """List all available dataset names."""
    return sorted(DATASETS.keys())


def list_datasets_for_language(language: str) -> list:
    """List datasets available for a specific sign language."""
    lang = language.lower()
    return LANGUAGE_DATASETS.get(lang, [])


__all__ = [
    # Base class
    "BaseDataset",
    # British Sign Language
    "BSLCPDataset",
    "BOBSLDataset",
    # American Sign Language
    "ASLDictDataset",
    "WLASLDataset",
    "How2SignDataset",
    "ASLCitizenDataset",
    "YTASLDataset",
    # German Sign Language
    "Phoenix2014TDataset",
    # Chinese Sign Language
    "CSLDailyDataset",
    # Multilingual
    "YTSL25Dataset",
    # Registry and utilities
    "DATASETS",
    "LANGUAGE_DATASETS",
    "get_dataset",
    "list_datasets",
    "list_datasets_for_language",
]
