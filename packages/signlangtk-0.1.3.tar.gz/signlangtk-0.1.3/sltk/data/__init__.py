"""
Data structures and loading utilities for SLTK.
"""

from sltk.data.core import PoseSequence, Sample, Segment, SegmentList
from sltk.data.feature_manager import (
    ExtractionPlan,
    ExtractionStep,
    FeatureAvailability,
    FeatureConnectionConfig,
    FeatureConnectionManager,
    FeatureSource,
    FeatureSummary,
    get_feature_manager,
)
from sltk.data.formats import convert_poses, list_formats, load_poses, save_poses
from sltk.data.rotations import RotationConverter, axis_angle_to_matrix, matrix_to_6d

__all__ = [
    # Core types
    "PoseSequence",
    "Segment",
    "SegmentList",
    "Sample",
    # Feature management
    "FeatureConnectionManager",
    "FeatureConnectionConfig",
    "FeatureSource",
    "FeatureAvailability",
    "FeatureSummary",
    "ExtractionPlan",
    "ExtractionStep",
    "get_feature_manager",
    # Format utilities
    "load_poses",
    "save_poses",
    "convert_poses",
    "list_formats",
    # Rotation utilities
    "RotationConverter",
    "axis_angle_to_matrix",
    "matrix_to_6d",
]
