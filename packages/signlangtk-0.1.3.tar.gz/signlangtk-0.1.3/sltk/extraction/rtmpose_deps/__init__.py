"""RTMPose whole-body keypoint extraction dependencies.

Re-exports the processor and config for use by ``sltk.extraction.rtmpose``.
"""

from sltk.extraction.rtmpose_deps.rtmpose_processor import (
    RTMPoseProcessor,
    RTMPoseProcessorConfig,
)

__all__ = ["RTMPoseProcessor", "RTMPoseProcessorConfig"]
