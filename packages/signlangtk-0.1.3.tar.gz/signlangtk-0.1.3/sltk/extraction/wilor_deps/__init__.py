"""
WiLoR dependencies bundled for VLTK.

This package contains vendored WiLoR code with modifications for
compatibility and integration with the VLTK extraction pipeline.
"""

import sys
from pathlib import Path

# Register chumpy stub before any imports that might load MANO
# This provides compatibility with Python 3.12+ where the original
# chumpy package fails due to removed inspect.getargspec
try:
    import chumpy
except (ImportError, AttributeError):
    # chumpy not installed or incompatible - use our stub
    from . import chumpy_stub
    sys.modules['chumpy'] = chumpy_stub
