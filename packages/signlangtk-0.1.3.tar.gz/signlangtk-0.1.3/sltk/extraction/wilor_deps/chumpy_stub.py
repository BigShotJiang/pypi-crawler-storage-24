"""
Minimal chumpy stub for loading legacy MANO .pkl files in Python 3.12+.

The original chumpy package uses deprecated inspect.getargspec which
was removed in Python 3.12. This stub provides minimal compatibility
for loading MANO model parameters without the full chumpy functionality.
"""

import numpy as np


class Ch:
    """Minimal chumpy Ch object that behaves like a numpy array."""

    def __init__(self, data=None):
        if data is not None:
            self._data = np.asarray(data)
        else:
            self._data = np.array([])

    @property
    def r(self):
        """Return numpy array (chumpy's .r property)."""
        return self._data

    def __array__(self, dtype=None):
        return self._data if dtype is None else self._data.astype(dtype)

    def __getattr__(self, name):
        # Forward attribute access to numpy array
        return getattr(self._data, name)

    def __getitem__(self, key):
        return self._data[key]

    def __len__(self):
        return len(self._data)


def array(*args, **kwargs):
    """Create a chumpy array (returns Ch wrapping numpy)."""
    return Ch(np.array(*args, **kwargs))


# Expose Ch as the main class
__all__ = ['Ch', 'array']
