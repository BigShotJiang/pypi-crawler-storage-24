"""
Bundled NLF processor for SMPLX pose extraction.

This module provides the NLF (Neural Localizer and Fitter) processor
for extracting SMPLX body pose parameters from video frames.

The processor is GPU-optimized and uses YOLO for person detection
followed by NLF for SMPLX parameter estimation.
"""

from sltk.extraction.nlf_deps.nlf_processor import (
    NLFConfig as NLFProcessorConfig,
    NLFProcessorOptimized,
)

__all__ = ["NLFProcessorConfig", "NLFProcessorOptimized"]
