"""
Pose extraction wrappers.

Provides consistent interfaces for different extraction backends:
- MediaPipe: Body, hand, and face landmarks
- WiLoR: High-quality 3D hand poses with MANO parameters
- NLF: Full-body SMPLX poses
- TEASER: FLAME 3D face parameters (jaw, expression, shape, eyelid, head pose)
- RTMPose: 133 COCO-WholeBody keypoints (body, foot, face, hands)
- Uplift: 2D to 3D pose conversion

Example usage:
    from sltk.extraction import MediaPipeExtractor, extract_mediapipe

    # Using the class
    extractor = MediaPipeExtractor()
    extractor.load_model()
    result = extractor.extract_from_video("video.mp4")

    # Using the convenience function
    result = extract_mediapipe("video.mp4", output_path="poses.h5")
"""

from sltk.extraction.base import (
    ExtractionConfig,
    ExtractionResult,
    PoseExtractor,
    get_video_info,
    read_video_frames,
)


# Lazy imports to avoid loading heavy dependencies
def __getattr__(name):
    """Lazy import extraction modules."""
    if name in ("MediaPipeExtractor", "MediaPipeConfig", "extract_mediapipe"):
        from sltk.extraction.mediapipe import (
            MediaPipeConfig,
            MediaPipeExtractor,
            extract_mediapipe,
        )

        return locals()[name]

    elif name in ("WiLoRExtractor", "WiLoRConfig", "extract_wilor"):
        from sltk.extraction.wilor import (
            WiLoRConfig,
            WiLoRExtractor,
            extract_wilor,
        )

        return locals()[name]

    elif name in ("NLFExtractor", "NLFConfig", "extract_nlf"):
        from sltk.extraction.nlf import (
            NLFConfig,
            NLFExtractor,
            extract_nlf,
        )

        return locals()[name]

    elif name in ("TeaserExtractor", "TeaserConfig", "extract_teaser"):
        from sltk.extraction.teaser import (
            TeaserConfig,
            TeaserExtractor,
            extract_teaser,
        )

        return locals()[name]

    elif name in ("RTMPoseExtractor", "RTMPoseConfig", "extract_rtmpose"):
        from sltk.extraction.rtmpose import (
            RTMPoseConfig,
            RTMPoseExtractor,
            extract_rtmpose,
        )

        return locals()[name]

    elif name in ("PoseUplifter", "UpliftConfig", "uplift_poses"):
        from sltk.extraction.uplift import (
            PoseUplifter,
            UpliftConfig,
            uplift_poses,
        )

        return locals()[name]

    elif name in ("SMPLFXFitter", "SMPLFXFittingConfig"):
        from sltk.extraction.smplfx_fitting import (
            SMPLFXFitter,
            SMPLFXFittingConfig,
        )

        return locals()[name]

    elif name in ("DepthExtractor", "DepthExtractionConfig"):
        from sltk.extraction.depth_extraction import (
            DepthExtractionConfig,
            DepthExtractor,
        )

        return locals()[name]

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    # Base classes
    "PoseExtractor",
    "ExtractionConfig",
    "ExtractionResult",
    "get_video_info",
    "read_video_frames",
    # MediaPipe
    "MediaPipeExtractor",
    "MediaPipeConfig",
    "extract_mediapipe",
    # WiLoR
    "WiLoRExtractor",
    "WiLoRConfig",
    "extract_wilor",
    # NLF
    "NLFExtractor",
    "NLFConfig",
    "extract_nlf",
    # TEASER
    "TeaserExtractor",
    "TeaserConfig",
    "extract_teaser",
    # RTMPose
    "RTMPoseExtractor",
    "RTMPoseConfig",
    "extract_rtmpose",
    # Uplift
    "PoseUplifter",
    "UpliftConfig",
    "uplift_poses",
    # SMPLFX Fitting
    "SMPLFXFitter",
    "SMPLFXFittingConfig",
    # Depth Extraction
    "DepthExtractor",
    "DepthExtractionConfig",
]
