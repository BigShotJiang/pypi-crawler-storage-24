"""FLAME face model for mesh reconstruction and expression classification."""

from __future__ import annotations

from sltk.extraction.teaser_deps.flame.flame_model import FLAME
from sltk.extraction.teaser_deps.flame.processor import FLAMEProcessor

__all__ = ["FLAME", "FLAMEProcessor"]
