"""TEASER face encoder dependencies bundled with VLTK."""

from __future__ import annotations

from sltk.extraction.teaser_deps.teaser_processor import (
    TeaserProcessorConfig,
    TeaserProcessorOptimized,
)

__all__ = [
    "TeaserProcessorConfig",
    "TeaserProcessorOptimized",
    "FLAMEProcessor",
]


def __getattr__(name: str) -> object:
    """Lazy-load FLAME subpackage to avoid heavy imports at package init."""
    if name == "FLAMEProcessor":
        from sltk.extraction.teaser_deps.flame.processor import FLAMEProcessor

        return FLAMEProcessor
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
