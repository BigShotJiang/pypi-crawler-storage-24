"""Data structures for the NMS detector package."""

from dataclasses import dataclass


@dataclass
class TrackingQuality:
    """Summary of tracking data quality for a person."""

    total_data_frames: int
    total_video_frames: int
    detection_rate: float
    eyelid_valid_frames: int
    eyelid_valid_rate: float
    score_mean: float
    active_eye: int  # 0 or 1, or -1 if neither has data
    usable_time_sec: float


@dataclass
class BlinkEvent:
    """A detected blink event."""

    start_frame: int
    end_frame: int
    peak_frame: int
    peak_value: float
    prominence: float
    width_ms: float
    duration_ms: float
    confidence: float
    segment_baseline: float
    data_index: int


@dataclass
class FrameState:
    """Pre-computed overlay state for one video frame."""

    is_valid: bool
    is_blink: bool
    blink_confidence: float
    eyelid_value: float
    det_score: float
    blink_count: int
    blink_rate: float
    coverage_pct: float


@dataclass
class NMSEvent:
    """A non-manual signal event."""

    tier: str  # ELAN tier name: HEAD-NOD, HEAD-SHAKE, etc.
    start_frame: int
    end_frame: int
    peak_frame: int
    peak_value: float  # max magnitude during event
    duration_ms: float
    confidence: float
    label: str  # annotation text for ELAN
