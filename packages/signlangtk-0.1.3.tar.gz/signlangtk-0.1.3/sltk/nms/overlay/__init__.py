"""Video overlay rendering."""

from .renderer import create_annotated_video, precompute_frame_states
