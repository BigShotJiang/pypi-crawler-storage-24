"""Shared constants for the NMS detector package."""

FPS = 25

# Expression coefficients most correlated with eye closure (from data analysis)
EXPR_BLINK_INDICES = [7, 8, 15, 17]

# Lip-related FLAME expression coefficient indices
LIP_EXPR_INDICES = [10, 11, 12, 13, 14, 18, 19, 20, 21, 22, 23, 24, 25]

# All available NMS detector names
ALL_DETECTORS = {"nod", "shake", "tilt", "mouth", "eyebrow", "gaze", "squint", "lips"}

# Default threshold values (used to detect when user explicitly overrides)
THRESHOLD_DEFAULTS = {
    "prominence": 0.055,
    "nod_amplitude": 0.030,
    "shake_amplitude": 0.040,
    "tilt_threshold": 0.10,
    "mouth_threshold": 0.06,
    "eyebrow_threshold": 1.2,
    "squint_threshold": 0.03,
    "lip_threshold": 0.15,
}
