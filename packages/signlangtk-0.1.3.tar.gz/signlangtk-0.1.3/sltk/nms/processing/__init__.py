"""Signal processing: validity masking, segmentation, and adaptive thresholds."""

from .adaptive import compute_adaptive_thresholds
from .utils import build_idx_to_frame, mask_to_regions, merge_mouth_events, merge_regions
from .validity import compute_validity_mask, filter_by_side, segment_valid_regions
