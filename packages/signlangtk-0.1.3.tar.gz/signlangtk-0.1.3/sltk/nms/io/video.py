"""Video path resolution utilities."""

from pathlib import Path


def find_video_path(h5_path: str, video_override: str | None = None) -> Path:
    """Resolve the source video path from an h5 file path.

    Checks for video_override first, then looks for common video extensions
    in the same directory as the H5 file.
    """
    if video_override:
        p = Path(video_override)
        if p.exists():
            return p
        raise FileNotFoundError(f"Video override not found: {video_override}")

    h5 = Path(h5_path)
    # Look for video in same directory with common extensions
    for ext in [".mp4", ".mov", ".avi", ".mkv"]:
        candidate = h5.with_suffix(ext)
        if candidate.exists():
            return candidate

    raise FileNotFoundError(f"Cannot find video for {h5_path}. Use video_path to specify.")
