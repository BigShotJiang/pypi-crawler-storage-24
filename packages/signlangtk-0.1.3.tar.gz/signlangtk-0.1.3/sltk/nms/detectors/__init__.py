"""NMS detectors: blinks, head movements, mouth, eyes."""

from .blinks import detect_blinks
from .eyes import detect_eye_gaze_events, detect_eye_squint, detect_eyebrow_events
from .head import detect_head_oscillations, detect_head_tilts, detect_single_head_movements
from .mouth import detect_lip_activity, detect_mouth_open
from .pipeline import detect_all_nms
