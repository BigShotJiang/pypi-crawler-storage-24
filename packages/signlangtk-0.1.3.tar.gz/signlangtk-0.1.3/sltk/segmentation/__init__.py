"""Sign language video segmentation (v2).

Uses a Transformer encoder with two-stream hand processing on WiLoR
hand pose features (192-dim H5 files). Produces BIO labels:
OUT=0, IN=1, BEGIN=2.

Example:
    from sltk.segmentation import get_runner, segment_h5

    # One-shot segmentation
    predictions = segment_h5("video_features.h5", "output.json")

    # Reusable runner
    runner = get_runner()
    predictions = runner.run_h5("features_dir/")
"""

from sltk.segmentation.h5_loader import h5_to_features, load_h5_directory
from sltk.segmentation.output import OutputFormat, save_predictions
from sltk.segmentation.postprocess import extract_segments, label_fixes, merge_begin_tags
from sltk.segmentation.runner import (
    InferenceRunner,
    get_runner,
    segment_features,
    segment_h5,
)
from sltk.segmentation.segmenter_v2 import SignSegmenterV2

__all__ = [
    "InferenceRunner",
    "get_runner",
    "segment_h5",
    "segment_features",
    "OutputFormat",
    "save_predictions",
    "label_fixes",
    "extract_segments",
    "merge_begin_tags",
    "h5_to_features",
    "load_h5_directory",
]
