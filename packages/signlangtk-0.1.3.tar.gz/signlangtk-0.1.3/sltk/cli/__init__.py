"""
SLTK Command Line Interface.
"""

from sltk.cli.main import main

__all__ = ["main"]
