"""
Evaluation metrics for sign language tasks.
"""

from sltk.metrics.segmentation import (
    SegmentationResult,
    SegmentMatch,
    boundary_f1,
    boundary_f1_multi_tolerance,
    comprehensive_segmentation_metrics,
    confusion_matrix,
    frame_accuracy,
    label_accuracy,
    over_segmentation_rate,
    per_class_metrics,
    per_segment_iou,
    segment_iou,
    segmentation_metrics,
    segmentation_summary,
    under_segmentation_rate,
)
from sltk.metrics.translation import bleu_score, rouge_score, translation_metrics

__all__ = [
    # Translation metrics
    "translation_metrics",
    "bleu_score",
    "rouge_score",
    # Basic segmentation metrics
    "segmentation_metrics",
    "boundary_f1",
    "segment_iou",
    "frame_accuracy",
    # Comprehensive segmentation metrics
    "comprehensive_segmentation_metrics",
    "SegmentationResult",
    "SegmentMatch",
    "boundary_f1_multi_tolerance",
    "label_accuracy",
    "over_segmentation_rate",
    "under_segmentation_rate",
    "per_segment_iou",
    "per_class_metrics",
    "confusion_matrix",
    "segmentation_summary",
]
