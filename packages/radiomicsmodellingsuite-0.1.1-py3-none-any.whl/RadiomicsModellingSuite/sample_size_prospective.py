import numpy as np
import scipy.stats as stats
from scipy.special import logit
import sympy as sp
from sympy import symbols, sqrt, exp, erf, solve, N
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score
import latex_reporting as lr

def std_from_proportion(proportion, sample_size):
    """
    Calculate the standard deviation from a proportion and sample size.
    
    Parameters:
    
    * proportion (float): The proportion of interest (e.g., 0.5 for 50%).
    
    * sample_size (int): The size of the sample.
    
    Returns:

    * std (float): The standard deviation calculated from the proportion and sample size.
    """
    std = np.sqrt(proportion * (1 - proportion)/sample_size)
    return std

def confidence_interval(confidence_level, sample_mean, sample_std):
    """
    Calculate the confidence interval for a given confidence level, sample size, sample mean, and sample standard deviation.
    
    Parameters:
    
    * confidence_level (float): The desired confidence level (e.g., 0.95 for 95% confidence).
    
    * sample_mean (float): The mean of the sample.
    
    * sample_std (float): The standard deviation of the sample.
    
    Returns:
    
    * lower_bound (float): lower bound of confidence interval
     
    * upper_bound (float): upper bound of the confidence interval.
    """
    z_score = stats.norm.ppf((1 + confidence_level) / 2)
    margin_of_error = z_score * sample_std 
    
    lower_bound = sample_mean - margin_of_error
    upper_bound = sample_mean + margin_of_error
    
    return lower_bound, upper_bound

def sample_size_from_proportion(confidence_level, proportion, margin_of_error, round=True):
    """
    Calculate the required sample size for a given confidence level, sample mean, sample standard deviation, and margin of error.
    
    Parameters:
    * confidence_level (float): The desired confidence level (e.g., 0.95 for 95% confidence).
    
    * sample_mean (float): The mean of the sample.
    
    * sample_std (float): The standard deviation of the sample.
    
    * margin_of_error (float): The desired margin of error, half the width of the confidence interval.
    
    * round (bool): Whether to round the sample size up to the nearest whole number. Default is True.
    
    Returns:
    
    * n (int if round is True, else float): The required sample size.
    """
    z_score = stats.norm.ppf((1 + confidence_level) / 2)
    n = (z_score ** 2 * proportion * (1 - proportion)) / (margin_of_error ** 2)
    if round:
        n = int(np.ceil(n))  # Round up to the nearest whole number
    return n

def sample_size_mape(proportion, predictor_parameters, mean_absolute_prediction_error=0.05):
    """
    Calculates sample size required for small mean absolute prediction error.

    Parameters:
    
    * proportion (float): anticipated outcome proportion
    
    * n_features (integer): number of features, including polynomial transformations of features (candidate predictor variables)
    
    * mean_absolute_prediction_error (float): average error allowed in model's estimated outcome probability

    Returns:
    
    * n (int): The required sample size.
    """
    if proportion > 0.5:
        proportion = 1-proportion
    expression = -0.508 + 0.259*np.log(proportion) + 0.504*np.log(predictor_parameters) - np.log(mean_absolute_prediction_error)
    return int(np.ceil(np.exp(expression/0.544)))

def sample_size_sensitivity(confidence_level, sensitivity, margin_of_error, prevalence):
    """
    Calculate the required sample size for a given confidence level, sensitivity, and margin of error.
    
    Parameters:
    
    * confidence_level (float): The desired confidence level (e.g., 0.95 for 95% confidence).
    
    * sensitivity (float): The sensitivity of the test.
    
    * margin_of_error (float): The desired margin of error, half the width of the confidence interval.
    
    Returns:

    * n (int): The required sample size.
    """
    n = sample_size_from_proportion(confidence_level, 
                                       sensitivity, margin_of_error, round=False)/prevalence
    return n

def sample_size_specificity(confidence_level, specificity, margin_of_error, prevalence):
    """
    Calculate the required sample size for a given confidence level, specificity, and margin of error.
    
    Parameters:
    
    * confidence_level (float): The desired confidence level as a decimal (e.g., 0.95 for 95% confidence).
    
    * specificity (float): The specificity of the test.
    
    * margin_of_error (float): The desired margin of error, half the width of the confidence interval.
    
    Returns:
    
    * n (int): The required sample size.
    """
    n = sample_size_from_proportion(confidence_level, 
                                       specificity, margin_of_error, round=False)/(1-prevalence)
    return n

def sample_size_auc_from_se(alpha, margin_error, auc_in, prevalence_in):
    """
    Calculate the required sample size for a given AUC and standard error.
    
    Parameters:
    
    * alpha (float): The significance level as a decimal (e.g., 0.05 for 95% confidence).
    
    * margin_error (float): The desired margin of error, half the width of the confidence interval
    
    * auc (float): The area under the ROC curve.
    
    * prevalence (float): The prevalence of the condition in the population.
    
    Returns:
    
    * n_numeric (int): The required sample size.
    """
    se_in = margin_error / stats.norm.ppf(1 - alpha/2)
    # Define symbolic variables
    auc, n, prevalence, se = sp.symbols('auc n prevalence se')

    # Define Q1 and Q2
    Q1 = auc / (2 - auc)
    Q2 = 2 * auc**2 / (1 + auc)

    # Define nA and nB
    nA = n * prevalence
    nB = n * (1 - prevalence)

    # Define the standard error formula
    se_expr = sp.sqrt((auc * (1 - auc) + (nA - 1) * (Q1 - auc**2) + (nB - 1)*(Q2 - auc**2)) / (nA * nB))

    # Square both sides to eliminate the square root
    equation = sp.Eq(se**2, se_expr**2)

    # Solve for n
    solution_n = sp.solve(equation, n)

    # Example values
    example_values = {
        auc: auc_in,
        prevalence: prevalence_in,
        se: se_in
    }

    # Evaluate the solution numerically (choose the positive root)
    n_numeric = [sol.evalf(subs=example_values) for sol in solution_n if sol.evalf(subs=example_values) > 0]
    return n_numeric

def standard_error_auc(auc, n, prevalence):
    """
    Calculate the standard error for a given AUC.
    
    Parameters:
    
    * auc (float): The area under the ROC curve.
    
    * n (int): The sample size.
    
    * prevalence (float): The prevalence of the condition in the population.
    
    Returns:
    * se (float): standard error of AUC.
    """
    Q1 = auc / (2-auc)
    Q2 = 2*auc**2 / (1 + auc)
    nA = n * prevalence
    nB = n * (1 - prevalence)
    se = np.sqrt((auc * (1 - auc) + (nA - 1) * (Q1 - auc**2) + (nB - 1)*(Q2 - auc**2)) / (nA * nB))
    return n

def sample_size_cox(power, alpha, data, covariate, min_hazard_ratio, psi, p=0.5, method='hsieh'):
    """
    Calculates sample size needed for Cox regression
    
    Parameters:

    * power (float): power of test
    
    * alpha (float): Type I error rate
    
    * data (pandas DataFrame): features
    
    * covariate (str): column of interest
    
    * min_hazard_ratio (float): minimum hazard ratio to detect
    
    * psi (float): proportion of patients who died
    
    * p (float): proportion of patients with the covariate=1
    
    * method (str): method to use, currently only 'hsieh' implemented

    Returns:

    * n (int): sample size needed
    """
    z = stats.norm.ppf(1-alpha/2)
    beta = np.log(min_hazard_ratio)
    if method.lower() == 'hsieh':
        x1 = data[covariate]
        x2 = data.drop(columns=[covariate] + [col for col in data.columns if 'target' in col.lower()])
        sd = x1.std()
        # Fit the model
        model = LinearRegression()
        model.fit(x2, x1)

        # Predict values
        x1_pred = model.predict(x2)

        # Calculate correlation coefficient
        correlation_coefficient = np.corrcoef(x1, x1_pred)[0, 1]
        n = (stats.norm.ppf(power) + z)**2/(beta**2 * sd**2 * psi * (1-correlation_coefficient**2))
        return n
    elif method.lower() == 'schoenfeld':
        n_events = ((stats.norm.ppf(power) + z)**2)/(p * (1-p) * beta**2)
        n = n_events/psi
        return n
    elif method.lower() == 'freedman':
        k = p/(1-p)
        m = (1/k) * ((k*min_hazard_ratio + 1)/(min_hazard_ratio - 1)**2) * (z+stats.norm.ppf(power))**2
        n = m/psi
        return n

def sample_size_exponential_survival(event_rate, time, confidence, margin_of_error):
    """
    Calculates sample size needed for fitting an exponential survival model.
    
    Parameters:
    
    * event_rate (float): event rate (per person year)
    
    * time (float): time in years to evaluate results
    
    * confidence (float): The desired confidence level (e.g., 0.95 for 95% confidence).
    
    * margin_of_error (float): desired margin of error

    Returns:
    
    * n (int): sample size
    """
    z_score = stats.norm.ppf((1 + confidence) / 2)
    calculated_value = 1 - np.exp(-1*event_rate*time)
    person_years = sp.symbols('person_years')
    equation_1 = sp.Eq(event_rate + z_score*sp.sqrt(event_rate/person_years),(-1/time)*np.log(np.exp(-1*event_rate*time) - margin_of_error))
    solution_1 = sp.solve(equation_1, person_years)[0]
    #print(event_rate*((((-1/time)*np.log(np.exp(-1*event_rate*time) - margin_of_error) - event_rate)/z_score)**-2)) #manual solution_1
    person_years = sp.symbols('person_years')
    equation_2 = sp.Eq((event_rate - z_score*sp.sqrt(event_rate/person_years)),(-1/time)*np.log(margin_of_error+np.exp(-1*event_rate*time)))
    #print(((event_rate + (1/time)*np.log(margin_of_error+np.exp(-1*event_rate*time)))/z_score)**-2) #manual solution_2
    solution_2 = sp.solve(equation_2, person_years)[0]
    if solution_1 >= solution_2: 
        n = np.ceil(solution_1/time)
    else:
        n = np.ceil(solution_2/time)
    return n

def max_rcs_binary(phi):
    """
    Calculates the maximum Cox-Snell R squared statistic for binary classification.

    Parameters:
    
    * n (int): sample size
    
    * phi (float): outcome proportion

    Returns:
    
    * r_cs (float): maximum Cox-Snell R squared statistic
    """
    log_likelihood = phi * np.log(phi) + (1-phi)*np.log(1-phi)
    r_cs = 1 - np.exp(2*log_likelihood)
    return r_cs

def max_rcs_survival(n, event_rate, mean_followup_time):
    """
    Calculates the maximum Cox-Snell R squared statistic for survival model

    Parameters:
    
    * n (int): sample size
    
    * event_rate (float): event rate (/time)
    
    * mean_followup_time (float): mean follow up time

    Returns:
    
    * r_cs (float): maximum Cox-Snell R squared statistic
    """
    corrected_rate = event_rate * mean_followup_time
    log_likelihood = corrected_rate*n*(np.log(corrected_rate)-1)
    r_cs = 1-np.exp(2*log_likelihood/n)
    return r_cs

def sample_size_shrinkage(num_predictors, shrinkage, r_cs):
    """
    Calculates the sample size required to achieve a desired shrinkage S.

    Parameters:
    
    * num_predictors (int): number of features used
    
    * shrinkage (float): desired shrinkage
    
    * r_cs (float): Cox-Snell R squared statistic, measure of signal:noise ratio

    Returns:
    
    * n (int): Sample size required for desired shrinkage
    """
    n = int(np.ceil(num_predictors/((shrinkage-1)*np.log(1-r_cs/shrinkage))))
    return n

def n_features_shrinkage(n, shrinkage, r_cs):
    """
    Calculates the maximum number of features required to achieve a desired shrinkage S.

    Parameters:
    
    * n (int): sample size
    
    * shrinkage (float): desired shrinkage
    
    * r_cs (float): Cox-Snell R squared statistic, measure of signal:noise ratio

    Returns:
    
    * n_features (int): Number of features required for desired shrinkage S
    """
    n_features = np.floor(n*(shrinkage-1)*np.log(1-r_cs/shrinkage))
    return n_features

def sample_size_optimism(phi, n_features, r_cs, optimism):
    """
    Calculates the sample size required for a small expected optimisim in r^2 Nagelkerke

    Parameters:
    
    * phi (float): outcome proportion
    
    * n_features (int): number of features
    
    * r_cs (float): anticipated Cox-Snell R squared statistic, measure of signal:noise ratio
    
    * optimism (float): expected optimisim in apparent r^2 Nagelkerke

    Returns:
    * n (int): sample size
    """
    shrinkage = r_cs/(r_cs + optimism*max_rcs_binary(phi))
    n = sample_size_shrinkage(n_features, shrinkage, r_cs)
    return n

def binary_sample_size_calculations(proportion, n_features, author, mean_absolute_prediction_error=0.05, margin_of_error=0.05, confidence_level=0.95, shrinkage=0.9, r_cs=0.1, r_nagelkerke=None, optimism=0.05, filename='sample_size_report', title='Sample Size Report'):
    """
    Calculate various sample sizes required for binary outcome prediction model

    Parameters:
    
    * proportion (float): anticipated outcome proportion
    
    * n_features (integer): number of features, including polynomial transformations of features (candidate predictor variables)
    
    * author (str): author's name
    
    * mean_absolute_prediction_error (float): average error allowed in model's estimated outcome probability. Default 0.05
    
    * margin_of_error (float): margin of error for confidence interval. Default 0.05
    
    * confidence_level (float): level of confidence for confidence interval. Default 0.95
    
    * shrinkage (float): expected uniform shrinkage factor desired. Default 0.9
    
    * r_cs (float): Anticipated r^2 cs value. Ignored if r_nagelkerke specified instead. Default 0.1.
    
    * r_nagelkerke (float): Anticipated r^2 nagelkerke value. Default None
    
    * optimism (float): Desired optimism value. Default 0.05
    
    * filename (str): Filename for report. Default sample_size_report
    
    * title (str): Report title. Default Sample Size Report

    Returns:
    * sample_sizes (list[int]): list of sample sizes calculated
    """
    sample_sizes = []
    if r_nagelkerke is not None:
        r_cs = r_nagelkerke * max_rcs_binary(proportion)
    sample_sizes.append(sample_size_from_proportion(confidence_level, proportion, margin_of_error, round=True))
    sample_sizes.append(sample_size_mape(proportion, n_features, mean_absolute_prediction_error=mean_absolute_prediction_error))
    sample_sizes.append(sample_size_shrinkage(n_features, shrinkage, r_cs))
    sample_sizes.append(sample_size_optimism(proportion, n_features, r_cs, optimism))
    lr.prospective_sample_size_binary_report(proportion, n_features, mean_absolute_prediction_error, margin_of_error, confidence_level, shrinkage, r_cs, optimism, sample_sizes, author, filename=filename, title=title)
    return sample_sizes

def num_features_mape(proportion, n, mean_absolute_prediction_error=0.05):
    """
    Calculates maximum number of features required for small mean absolute prediction error.

    Parameters:
    
    * proportion (float): anticipated outcome proportion
    
    * n (integer): sample size
    
    * mean_absolute_prediction_error (float): average error allowed in model's estimated outcome probability

    Returns:
    
    * num_features (int): The required number of features
    """
    if proportion > 0.5:
        proportion = 1-proportion
    expression = 0.508 - 0.259*np.log(proportion) + 0.544*np.log(n) + np.log(mean_absolute_prediction_error)
    num_features = int(np.floor(np.exp(expression/0.504)))
    return num_features

def num_features_shrinkage(n, shrinkage, r_cs):
    """
    Calculates the number of features required to achieve a desired shrinkage S.

    Parameters:
    
    * n (int): sample size
    
    * shrinkage (float): desired shrinkage
    
    * r_cs (float): Cox-Snell R squared statistic, measure of signal:noise ratio

    Returns:
    
    * num_features (int): Number of features required for desired shrinkage
    """
    num_features = int(np.floor(n*(shrinkage-1)*np.log(1-r_cs/shrinkage)))
    return num_features

def num_features_optimism(phi, n, r_cs, optimism):
    """
    Calculates the number of features required for a small expected optimisim in r^2 Nagelkerke

    Parameters:
    
    * phi (float): outcome proportion
    
    * n (int): sample size
    
    * r_cs (float): anticipated Cox-Snell R squared statistic, measure of signal:noise ratio
    
    * optimism (float): expected optimisim in apparent r^2 Nagelkerke

    Returns:
    
    * num_features (int): number of features required for desired optimism
    """
    shrinkage = r_cs/(r_cs + optimism*max_rcs_binary(phi))
    return num_features_shrinkage(n, shrinkage, r_cs)

def binary_num_features_calculations(proportion, sample_size, author, mean_absolute_prediction_error=0.05, margin_of_error=0.05, confidence_level=0.95, shrinkage=0.9, r_cs=0.1, r_nagelkerke=None, optimism=0.05, filename='num_features_report', title='Number of Features Report'):
    """
    Calculate various sample sizes required for binary outcome prediction model

    Parameters:
    
    * proportion (float): anticipated outcome proportion
    
    * sample_size (integer): sample size
    
    * author (str): author's name
    
    * mean_absolute_prediction_error (float): average error allowed in model's estimated outcome probability
    
    * margin_of_error (float): margin of error for confidence interval
    
    * confidence_level (float): level of confidence for confidence interval
    
    * shrinkage (float): expected uniform shrinkage factor desired
    
    * r_cs (float): Anticipated r^2 cs value. Ignored if r_nagelkerke specified instead
    
    * r_nagelkerke (float): Anticipated r^2 nagelkerke value.
    
    * optimism (float): Desired optimism value
    
    * filename (str): filename to save report to

    * title (str): Report title

    Returns:

    * num_features (list[int]): list of number of features calculated
    """
    num_features = []
    if r_nagelkerke is not None:
        r_cs = r_nagelkerke * max_rcs_binary(proportion)
    num_features.append(num_features_mape(proportion, sample_size, mean_absolute_prediction_error=mean_absolute_prediction_error))
    num_features.append(num_features_shrinkage(sample_size, shrinkage, r_cs))
    num_features.append(num_features_optimism(proportion, sample_size, r_cs, optimism))
    lr.prospective_num_features_binary_report(proportion, sample_size, mean_absolute_prediction_error, margin_of_error, confidence_level, shrinkage, r_cs, optimism, num_features, author, filename=filename, title=title)
    return num_features