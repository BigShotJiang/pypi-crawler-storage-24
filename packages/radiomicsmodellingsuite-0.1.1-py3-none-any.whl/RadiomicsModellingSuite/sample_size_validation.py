import numpy as np
import scipy.stats as stats
from scipy.special import logit
import sympy as sp
from sympy import symbols, sqrt, exp, erf, solve, N
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score
from lifelines import KaplanMeierFitter, CoxPHFitter
from lifelines.utils import concordance_index
import pandas as pd

def sample_size_observed_expected(phi, confidence_level, margin_of_error):
    """
    Function to calculate sample size based on desired confidence width for 
    ratio of the total number of observed outcome events, divided by the total number of expected (predicted) outcome events (O/E)

    Parameters:
    
    * phi (float): Anticipated outcome event proportion
    
    * confidence_level (float): The confidence level
    
    * margin_error (float): The desired margin of error, half the width of the confidence interval

    Returns:
    
    * N (int): The required sample size.
    """
    z_score = stats.norm.ppf((1 + confidence_level) / 2)
    SE = margin_of_error/z_score
    N = (1-phi)/(phi*SE**2)
    return np.ceil(N)

def SE_C(C, N, phi):
    """
    Function to calculate standard error of C-statistic from Newcombe's formula (2006)

    Parameters:
    
    * C (float): C-statistic
    
    * N (int): sample size
    
    * phi (float): Anticipated outcome event proportion

    Returns:

    * SE (float): standard error of C-statistic
    """
    SE = sp.sqrt((C*(1-C)*(1 + (N/2 - 1)*((1-C)/(2-C)) + C*(N/2 - 1)/(1+C)))/(N**2 * phi * (1-phi)))
    return SE

def sample_size_C(C, phi, confidence_level, margin_of_error):
    """
    Function to calculate sample size for given C-statistic

    Parameters:
    
    * C (float): C-statistic observed in validation set
    
    * phi (float): Anticipated outcome event proportion
    
    * confidence_level (float): The confidence level
    
    * margin_error (float): The desired margin of error, half the width of the confidence interval

    Returns:
    
    * solutions (list): list of possible sample sizes
    """
    z_score = stats.norm.ppf((1 + confidence_level) / 2)
    SE = margin_of_error/z_score

    #define symbols and equation
    N = sp.symbols('N')
    expr = SE_C(C, N, phi)
     # Square both sides to eliminate the square root
    equation = sp.Eq(SE**2, expr**2)

    # Solve for n
    solution_n = sp.solve(equation, N)
    solutions = [np.ceil(n) for n in solution_n if n > 0] #only return positive solutions
    return solutions

def SE_net_benefit(N, phi, p, sensitivity, specificity):
    """
    Function to calculate standard error of net benefit

    Parameters:
    
    * N (int): sample size
    
    * phi (float): Anticipated outcome event proportion
    
    * p (float): risk threshold
    
    * sensitivity (float): sensitivity of the test
    
    * specificity (float): specificity of the test

    Returns:

    * SE (float): standard error of net benefit
    """
    w = (1-phi)/phi * (p/(1-p))
    SE = sp.sqrt(1/N * ((sensitivity*(1-sensitivity)/phi) + (w**2 * specificity*(1-specificity))/(1-phi) + (w**2 * (1-specificity)**2)/(phi*(1-phi))))
    return SE

def sample_size_net_benefit(phi, p, sensitivity, specificity, confidence_level, margin_of_error):
    """
    Function to calculate sample size given a desired confidence level and margin of error for net benefit

    Parameters:
    
    * phi (float): Anticipated outcome event proportion
    
    * p (float): risk threshold
    
    * sensitivity (float): sensitivity of the test
    
    * specificity (float): specificity of the test
    
    * confidence_level (float): The confidence level
    
    * margin_error (float): The desired margin of error, half the width of the confidence interval

    Returns:

    * N (int): sample size
    """
    z_score = stats.norm.ppf((1 + confidence_level) / 2)
    SE = margin_of_error/z_score
    w = (1-phi)/phi * (p/(1-p))
    N = np.ceil((1/SE**2) * ((sensitivity*(1-sensitivity)/phi) + (w**2 * specificity*(1-specificity))/(1-phi) + (w**2 * (1-specificity)**2)/(phi*(1-phi))))
    return N

def calculate_calibration_matrix_elements(alpha, beta, phi, LP_vector = None, num_patients=1000):
    """
    Calculate elements of calibration matrix

    Parameters:
    
    * alpha (float): calibration intercept
    
    * beta (float): calibration slope
    
    * phi (float): Anticipated outcome event proportion
    
    * LP_vector (numpy array): vector of LP values
    
    * num_patients (int): number of LP values to generate

    Returns:
    
    * Ia, Iab, Ib (all floats) as defined in Riley et al (2021)
    """
    if LP_vector is None:
        sd = np.sqrt(phi*(1-phi)/num_patients)
        p_vector = np.random.normal(loc=phi, scale=sd, size=num_patients)
        LP_vector = logit(p_vector)
    a = np.exp(alpha + beta*LP_vector)/(np.exp(alpha + beta*LP_vector) + 1)**2
    b = LP_vector * np.exp(alpha + beta*LP_vector)/(np.exp(alpha + beta*LP_vector) + 1)**2
    c = LP_vector**2 * np.exp(alpha + beta*LP_vector)/(np.exp(alpha + beta*LP_vector) + 1)**2
    return np.mean(a), np.mean(b), np.mean(c)

def sample_size_calibration(alpha, beta, phi, confidence_level, margin_of_error, num_patients=1000):
    """
    Calculate sample size needed for calibration

    Parameters:
    
    * alpha (float): calibration intercept
    
    * beta (float): calibration slope
    
    * phi (float): Anticipated outcome event proportion
    
    * confidence_level (float): The desired confidence level (e.g., 0.95 for 95% confidence).
    
    * margin_of_error (float): The desired margin of error, half the width of the confidence interval.
    
    * num_patients (int): number of LP values to generate

    Returns:
    
    * N (int): sample size
    """
    Ia, Iab, Ib = calculate_calibration_matrix_elements(alpha, beta, phi, num_patients=num_patients)
    z_score = stats.norm.ppf((1 + confidence_level) / 2)
    SE = margin_of_error/z_score
    N = Ia/((Ia*Ib - Iab**2)*SE**2)
    return N

def find_linear_predictor_mean(phi, C, tolerance = 0.05, num_patients=1000, num_iterations=10):
    """
    Finds mean of linear predictor value of nonevents group

    Parameters:
    
    * phi (float): Anticipated outcome event proportion
    
    * C (float): C-index of classifier
    
    * tolerance (float): maximum deviation of sample proportion from true proportion to accept mu. Default 0.05.
    
    * num_patients (int): number of patients to simulate. Default 1000.

    * num_iterations (int): maximum number of iterations to run. Default 10.

    Returns:
    
    * best_mu (float): best estimate for mean of linear predictor values. 
    """
    find_mu = True
    sample = np.random.binomial(n=1,p=phi,size=num_patients)
    sd = np.sqrt(2)*stats.norm.ppf(C)
    iteration = 1
    #initialise upper and lower bounds of mu
    low_mu = -20
    high_mu = 20
    mu = np.random.uniform(low=low_mu, high=high_mu)
    best_mu = mu
    while find_mu:
        LPs = [np.random.normal(loc=mu+sd, scale=sd) if i == 0 else np.random.normal(loc=mu, scale=sd) for i in sample ]
        observed = [np.random.binomial(n=1,p=(np.exp(LP)/(1+np.exp(LP)))) for LP in LPs]
        observed_proportion = sum(observed)/len(observed)      
        error = np.abs(observed_proportion - phi)
        if iteration == 1: #initialise best error
            best_error = error
        if error < best_error: #store current mu as best mu if error is smaller than previous best
            best_mu = mu
            best_error = error
        if error < tolerance: #if error within tolerance, store current mu as best mu and stop the loop
            best_mu = mu
            best_error = error
            print(f"Converged after {iteration} iterations.")
            find_mu = False 
        elif iteration >= num_iterations: #stop loop if number of iterations exceeded
            print("Did not converge in number of iterations")
            find_mu = False
        else: #otherwise choose a new mu value and keep going with loop
            if observed_proportion < phi: #if observed proportion < phi, this means LPs are too small so mu should increase
                low_mu = mu
            else:
                high_mu = mu
            mu = np.random.uniform(low=low_mu, high=high_mu)        
        iteration += 1
    print(f"best mu: {best_mu}, best error: {best_error}")
    return best_mu

def sample_size_perfect_calibration(phi, C, confidence_level, margin_of_error, tolerance=0.05, num_patients=1000, num_iterations=10):
    """
    Calculate sample size needed for calibration

    Parameters:
    
    * alpha (float): calibration intercept
    
    * beta (float): calibration slope
    
    * phi (float): Anticipated outcome event proportion
    
    * confidence_level (float): The desired confidence level (e.g., 0.95 for 95% confidence).
    
    * margin_of_error (float): The desired margin of error, half the width of the confidence interval.
    
    * num_patients (int): number of LP values to generate

    Returns:
    
    * N (int): sample size
    """
    alpha = 0
    beta = 1
    sd = np.sqrt(2)*stats.norm.ppf(C)
    mu_nonevents = find_linear_predictor_mean(phi, C, tolerance=tolerance, num_patients=num_patients, num_iterations=num_iterations)
    mu_events = mu_nonevents + sd**2
    LP_nonevents = np.random.normal(loc=mu_nonevents, scale=sd, size=int(num_patients*phi))
    LP_events = np.random.normal(loc=mu_events, scale=sd, size=num_patients - int(num_patients*phi))
    LP_vector = np.array(list(LP_nonevents) + list(LP_events))
    #LP_vector = np.random.normal(loc=-1.75, scale=1.47, size=num_patients) #uncomment to use example in Riley et al
    Ia, Iab, Ib = calculate_calibration_matrix_elements(alpha, beta, phi, LP_vector=LP_vector)
    z_score = stats.norm.ppf((1 + confidence_level) / 2)
    SE = margin_of_error/z_score
    N = Ia/((Ia*Ib - Iab**2)*SE**2)
    return N

def SD_LP(C):
    """
    Calculate standard deviation of the LP distribution given Harrell's C-index

    Parameter:

    * C (float): Harrell's C-index

    Returns:

    * SD (float): standard deviation of LP distribution
    """
    D = 5.50*(C-0.5) + 10.26*(C-0.5)**3
    SE = D*np.sqrt(np.pi/8)
    return SE

def simulate_survival_data(Lambda, LP, time_point):
    """
    Simulates survival data

    Parameters:
    
    * Lambda (float): baseline Hazard rate
    
    * LP (numpy array): linear predictor values
    
    * time_point (float): time point to calculate survival statistics at

    Returns:

    * results (dict): dictionary with survival statistics 'St', 'c.index', and 'D'
    """
    # Simulate survival data
    event_time = np.random.exponential(scale=1 / (Lambda * np.exp(LP)))
    event = np.ones_like(event_time)
    event[event_time > time_point] = 0
    event_time[event_time > time_point] = time_point
    
    # Create a DataFrame
    
    df = pd.DataFrame({'eventtime': event_time, 'dead': event, 'LP': LP})
    print('df', df)
    
    # Fit Kaplan-Meier model
    kmf = KaplanMeierFitter()
    kmf.fit(event_time, event)
    St = kmf.predict(time_point)
    
    # Fit Cox PH model
    cph = CoxPHFitter()
    cph.fit(df, duration_col='eventtime', event_col='dead')
    c_index = concordance_index(df['eventtime'], -cph.predict_partial_hazard(df), df['dead'])
    
    # Calculate Royston's D 
    D = 5.50*(c_index-0.5) + 10.26*(c_index-0.5)**3
    
    results = {'St': St, 'c.index': c_index, 'D': D}
    return results



# def validate_sample_size_cox(N, LP_moments, time):
#     """
#     Calculate sample size needed for validating cox proportional hazards model
#     """
#     LP = np.random.normal(loc=LP_moments[0], scale=LP_moments[1], size=N)
#     print(simulate_survival_data(0.1, LP, time))
def validate_sample_size_cox(C_index, margin_of_error, LP_mean, time, surviving_fraction, censoring_fraction, starting_n=100, num_bootstraps=100, max_iterations=10):
    """
    Calculates sample size needed for Cox proportional hazards model
    
    Parameters:
    
    * C_index (float): C-index of the model, if known
    
    * margin_of_error (float): margin of error for confidence interval, if known
    
    * LP_mean (float): mean of linear predictor values

    * time (float): time point to calculate sample size for
    
    * surviving_fraction (float): fraction of patients expected to survive at time point.
    
    * censoring_fraction (float): fraction of patients expected to be censored at time point.
    
    * starting_n (int): starting sample size for Riley method. Default 100
    
    * num_bootstraps (int): number of bootstraps to use when calculating pseudo-observations. Default 100.

    * max_iterations (int): maximum number of iterations to run. Default 10.
    
    Returns:
    
    * n (int): required sample size
    """
    sd = SD_LP(C_index)
    z = stats.norm.ppf(0.975)
    target_standard_error = margin_of_error/z
    standard_error = np.inf
    n = starting_n
    censoring_rate = -np.log(1 - censoring_fraction)/time
    print('censoring rate:', censoring_rate)
    #event_rate = -np.log(surviving_fraction)/time
    event_rate = -1*np.log((1-surviving_fraction)**(1/np.exp(LP_mean)))/time
    print('event rate:', event_rate)
    num_iterations = 0
    while standard_error > target_standard_error and num_iterations <= max_iterations - 1:
        print('n=',n)
        LPs = np.random.normal(loc=LP_mean, scale=sd, size=n)
        survivals = np.exp(-time*event_rate) ** np.exp(LPs)
        risks = 1 - survivals
        survival_times = []
        censoring_times = []
        for patient in LPs:
            u = np.random.rand()
            t = -np.log((1-u)**(1/np.exp(patient)))/event_rate
            c = np.random.exponential(1/censoring_rate)
            survival_times.append(t)
            censoring_times.append(c)
        times = []
        statuses = []
        #print('survival times', survival_times)
        #print('censoring times', censoring_times)
        for survival, censoring in zip(survival_times, censoring_times):
            if survival <= censoring:
                statuses.append(1)
                times.append(survival)
            else:
                statuses.append(0)
                times.append(censoring)
        #print('statuses', statuses)
        #print('times', times)
        kmf = KaplanMeierFitter()
        kmf.fit(durations=times, event_observed=statuses)
        full_cumulative_incidence = n*kmf.survival_function_at_times(time).values[0]
        pseudoobservations = np.zeros((len(LPs), num_bootstraps))  # num_bootstraps is the number of times you want to calculate the pseudo-observations
        for bootstrap in range(num_bootstraps):
            indices = np.random.choice(len(times), size=len(times), replace=True)
            times_boot = np.array(times)[indices]
            statuses_boot = np.array(statuses)[indices]
            kmf_boot = KaplanMeierFitter()
            kmf_boot.fit(durations=times_boot, event_observed=statuses_boot)
            full_cumulative_incidence_boot = len(times_boot)*kmf_boot.survival_function_at_times(time).values[0]           
            pseudoobservations_bootstrap = []
            for i, patient in enumerate(LPs):
                kmf_minus = KaplanMeierFitter()
                times_minus = times.copy()
                del times_minus[i]
                statuses_minus = statuses.copy()
                del statuses_minus[i]
                indices = np.random.choice(len(times_minus), size=len(times_minus), replace=True)
                times_minus = np.array(times_minus)[indices]
                statuses_minus = np.array(statuses_minus)[indices]
                kmf_minus.fit(durations=times_minus, event_observed=statuses_minus)
                pseudoobservations_bootstrap.append(full_cumulative_incidence_boot - (len(times_boot)-1)*kmf_minus.survival_function_at_times(time).values[0])
            pseudoobservations[:, bootstrap] = pseudoobservations_bootstrap
        mean_pseudoobservations = np.mean(pseudoobservations, axis=1)
        y = np.log(-1*np.log(1 - mean_pseudoobservations)).reshape(-1, 1)
        x = np.log(-1*np.log(1-np.array(risks))).reshape(-1, 1)
        mask = ~np.isnan(x).any(axis=1) & ~np.isnan(y).any(axis=1)
        x = x[mask]
        y = y[mask]
        reg = LinearRegression().fit(x, y)
        print(reg.coef_, reg.intercept_)
        k = x.shape[1]
        residuals = y - reg.predict(x)
        sigma_squared = np.sum(residuals**2) / (len(y) - k)
        cov_matrix = sigma_squared * np.linalg.inv(np.dot(x.T, x))
        standard_error = np.sqrt(sigma_squared / np.sum((x - np.mean(x))**2))
        print("Standard error of the slope:", standard_error)        
        if num_iterations == max_iterations - 1:
            print('warning, max iterations reached')
            return n
        else:
            num_iterations += 1
            n += 10
    return n
