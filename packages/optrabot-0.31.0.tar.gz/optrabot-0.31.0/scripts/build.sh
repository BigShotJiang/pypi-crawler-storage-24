#!/usr/bin/env bash
# Full build including frontend (React UI) and UV package build
set -e
cd "$(dirname "$0")/.."
uv run python -m optrabot.build
