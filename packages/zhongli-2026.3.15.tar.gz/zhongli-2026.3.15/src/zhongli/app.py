"""High level logic for zhongli."""

import asyncio
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from typing import Final

from httpx import AsyncClient
from loguru import logger as log
from minimal_activitypub import Status
from minimal_activitypub.client_2_server import ActivityPub
from minimal_activitypub.client_2_server import NetworkError
from minimal_activitypub.client_2_server import ServerError
from pybreaker import CircuitBreakerError
from stamina import retry

from zhongli import __version__
from zhongli.attachment_hasher import AttachmentHasher
from zhongli.attachment_tracker import AttachmentTracker
from zhongli.circuit_breaker import circuit_breaker_decorator
from zhongli.config import Configuration
from zhongli.config import Fediverse
from zhongli.config import determine_config
from zhongli.fenliu_client import FenLiuClient
from zhongli.fenliu_models import QueuedPost
from zhongli.reblog_service import ReblogService


@dataclass
class BoostContext:
    """Context for boosting operations, holds shared services."""

    fenliu_client: FenLiuClient
    reblog_service: ReblogService
    config: Configuration
    attachment_tracker: AttachmentTracker
    attachment_hasher: AttachmentHasher


ENABLE_MINIMAL_ACTIVITYPUB_LOGGING: Final[bool] = False

if ENABLE_MINIMAL_ACTIVITYPUB_LOGGING:
    import logging

    log_fmt = "%(asctime)s - %(levelname)s - %(name)s - %(funcName)s(%(lineno)d) - %(message)s"
    lib_log = logging.getLogger("Minimal-ActivityPub")
    lib_log.setLevel(logging.DEBUG)
    cons = logging.StreamHandler()
    cons.setFormatter(logging.Formatter(log_fmt))
    lib_log.addHandler(cons)


@log.catch
async def main(config_path: Path, max_posts: int | None) -> None:
    """Read communities and post to fediverse account."""
    log.info(f"Welcome to zhongli({__version__})")

    config = await determine_config(config_path=config_path)
    log.debug(f"{config=}")

    client = AsyncClient(http2=True, timeout=30)

    try:
        instance: ActivityPub
        instance = await connect(auth=config.fediverse, client=client)
    except (NetworkError, CircuitBreakerError) as error:
        log.info(f"Unable to connect to your Fediverse account with {error=}")
        log.opt(colors=True).info("<red><bold>Can't continue!</bold></red> ... Exiting")
        sys.exit(1)

    # FenLiu queue mode is required
    if not config.fenliu:
        log.error("FenLiu configuration is required")
        log.opt(colors=True).info("<red><bold>FenLiu not configured!</bold></red> Check your config.toml")
        sys.exit(1)

    await boost_from_fenliu(
        instance=instance,
        client=client,
        config=config,
        max_posts=max_posts,
    )

    await client.aclose()


@circuit_breaker_decorator("authentication")
@retry(on=NetworkError, attempts=3)
async def connect(auth: Fediverse, client: AsyncClient) -> ActivityPub:
    """Connect to fediverse instance server and initialise some values."""
    activity_pub = ActivityPub(
        instance=auth.domain_name,
        access_token=auth.api_token,
        client=client,
    )
    await activity_pub.determine_instance_type()

    user_info = await activity_pub.verify_credentials()

    log.info(f"Successfully authenticated as @{user_info['username']} on {auth.domain_name}")

    return activity_pub


def _convert_fenliu_post_to_status(queued_post: QueuedPost) -> Status:
    """Convert FenLiu QueuedPost to ActivityPub Status format.

    Args:
        queued_post: Post from FenLiu queue

    Returns:
        Status dict compatible with Boostable validation.

    """
    return {
        "id": queued_post.id,
        "url": queued_post.url,
        "content": queued_post.content,
        "created_at": queued_post.created_at,
        "account": queued_post.actor,
        "sensitive": queued_post.sensitive,
        "language": queued_post.language,
        "tags": queued_post.tag or [],
        "media_attachments": queued_post.attachment or [],
        "in_reply_to_id": queued_post.in_reply_to,
    }


async def _process_single_fenliu_post(
    queued_post: QueuedPost,
    context: BoostContext,
) -> bool:
    """Process a single post from FenLiu queue.

    Args:
        queued_post: Post from FenLiu queue
        context: Boost context with shared services

    Returns:
        True if post was boosted, False otherwise.

    """
    post_id = queued_post.id
    status_url = queued_post.url

    log.bind(post_id=post_id, post_url=status_url, phase="start").debug(f"Processing post from queue: {status_url}")

    # Convert to Status format for validation
    status = _convert_fenliu_post_to_status(queued_post)

    # Quick validation checks
    if not _should_boost_fenliu_post(status=status, config=context.config):
        log.bind(post_id=post_id, post_url=status_url, phase="validation", result="skipped").debug(
            f"Skipping post due to validation: {status_url}"
        )
        await context.fenliu_client.nack(post_id=post_id)
        return False

    # First, fetch the full status from ActivityPub to check attachments
    full_status = await context.reblog_service.find_status_by_url(status_url=status_url)

    if not full_status:
        # Status not found
        log.bind(post_id=post_id, post_url=status_url, phase="find_status", result="not_found").warning(
            f"Status not found on fediverse: {status_url}"
        )
        await context.fenliu_client.error(
            post_id=post_id,
            message="Status not found on fediverse",
        )
        return False

    # Check for duplicate attachments before reblogging
    duplicate_check = await _check_for_duplicate_attachments_from_status(
        status=full_status,
        attachment_tracker=context.attachment_tracker,
        attachment_hasher=context.attachment_hasher,
    )

    if duplicate_check is not None:
        duplicate_record = duplicate_check
        log.bind(
            post_id=post_id,
            post_url=status_url,
            phase="duplicate_check",
            result="duplicate_found",
            previous_post_id=duplicate_record.boosted_post_id,
        ).warning(
            f"Duplicate attachment detected in {status_url}: "
            f"previously boosted with post {duplicate_record.boosted_post_id}"
        )
        await context.fenliu_client.error(
            post_id=post_id,
            message=f"Duplicate attachment (previously boosted: {duplicate_record.boosted_post_id})",
        )
        return False

    # Attempt to reblog
    result = await context.reblog_service.attempt_boost(status_url=status_url)

    if result is None:
        # This shouldn't happen since we just found it, but handle it gracefully
        log.bind(post_id=post_id, post_url=status_url, phase="reblog", result="disappeared").warning(
            f"Status disappeared before reblogging: {status_url}"
        )
        await context.fenliu_client.error(
            post_id=post_id,
            message="Status disappeared before reblogging",
        )
        return False

    success, should_record = result

    if success:
        # Record attachments from the full status
        await _record_post_attachments_from_status(
            status=full_status,
            post_id=post_id,
            attachment_tracker=context.attachment_tracker,
            attachment_hasher=context.attachment_hasher,
        )
        await context.fenliu_client.ack(post_id=post_id)
        log.opt(colors=True).bind(post_id=post_id, post_url=status_url, phase="reblog", result="success").info(
            f"Boosted <cyan>{status_url}</>"
        )
        return True

    if should_record:
        # Permanent failure - don't retry
        await context.fenliu_client.error(
            post_id=post_id,
            message="Permanent error reblogging post",
        )
        log.bind(
            post_id=post_id, post_url=status_url, phase="reblog", result="permanent_failure", should_retry=False
        ).warning(f"Permanent error for post: {status_url}")
    else:
        # Transient failure - allow retry
        await context.fenliu_client.nack(post_id=post_id)
        log.bind(
            post_id=post_id, post_url=status_url, phase="reblog", result="transient_failure", should_retry=True
        ).warning(f"Transient error for post, will retry: {status_url}")

    return False


async def _fenliu_fetch_and_process(
    context: BoostContext,
) -> tuple[bool, str]:
    """Fetch and process a single queue item.

    Args:
        context: Boost context with shared services

    Returns:
        Tuple of (boosted, url) where boosted=True if post was reblogged

    """
    queued_post = await context.fenliu_client.get_next_post()

    if not queued_post:
        log.bind(phase="queue_poll", result="empty").debug("Queue is empty, waiting before retry...")
        await asyncio.sleep(30)
        return False, ""

    boosted = await _process_single_fenliu_post(
        queued_post=queued_post,
        context=context,
    )
    return boosted, queued_post.url


def _should_stop_boosting(number_boosted: int, max_posts: int | None) -> bool:
    """Check if boosting should stop.

    Args:
        number_boosted: Number of posts boosted so far
        max_posts: Maximum posts to boost

    Returns:
        True if should stop, False otherwise

    """
    if max_posts and number_boosted >= max_posts:
        return True

    return False


async def _handle_boost_result(boosted: bool, number_boosted: int) -> int:
    """Handle successful boost and log result.

    Args:
        boosted: Whether boost was successful
        number_boosted: Current boost count

    Returns:
        Updated boost count

    """
    if boosted:
        number_boosted += 1
    return number_boosted


async def _handle_loop_error(error: Exception, is_network: bool) -> None:
    """Handle loop errors with appropriate logging and backoff.

    Args:
        error: Exception that occurred
        is_network: True for network errors, False for unexpected

    """
    if is_network:
        log.bind(phase="main_loop", error_type="network", error_class=type(error).__name__).warning(
            f"Error in FenLiu boost loop: {error}"
        )
    else:
        log.bind(phase="main_loop", error_type="unexpected", error_class=type(error).__name__).exception(
            f"Unexpected error in FenLiu boost loop: {error}"
        )
    await asyncio.sleep(10)


async def _fenliu_main_loop(
    context: BoostContext,
    max_posts: int | None,
) -> None:
    """Process FenLiu queue in a loop.

    Args:
        context: Boost context with shared services
        max_posts: Maximum posts to process

    """
    number_boosted: int = 0

    while True:
        try:
            boosted, _url = await _fenliu_fetch_and_process(
                context=context,
            )

            number_boosted = await _handle_boost_result(boosted, number_boosted)

            if _should_stop_boosting(number_boosted, max_posts):
                break

            if context.config.delay_between_posts > 0:
                await asyncio.sleep(context.config.delay_between_posts)

        except (NetworkError, CircuitBreakerError, ServerError) as error:
            await _handle_loop_error(error, is_network=True)
        except Exception as error:
            await _handle_loop_error(error, is_network=False)


async def boost_from_fenliu(
    instance: ActivityPub,
    client: AsyncClient,
    config: Configuration,
    max_posts: int | None = None,
) -> None:
    """Boost posts from FenLiu's queue.

    Continuously polls FenLiu's queue for posts to reblog, validates them,
    and sends appropriate feedback (ack/nack/error) back to FenLiu.

    Args:
        instance: ActivityPub instance for reblogging
        client: HTTP client for requests
        config: Configuration with FenLiu settings
        max_posts: Maximum posts to boost (None to use config.max_reblog)

    """
    if not config.fenliu:
        log.error("FenLiu not properly configured")
        return

    # Use max_posts from CLI if provided, otherwise use config.max_reblog
    effective_max_posts = max_posts if max_posts is not None else config.max_reblog

    fenliu_client = FenLiuClient(
        base_url=config.fenliu.base_url,
        client=client,
        api_key=config.fenliu.api_key,
        random_selection=config.fenliu.random_selection,
    )

    reblog_service = ReblogService(instance=instance, client=client)
    attachment_tracker = AttachmentTracker()
    attachment_hasher = AttachmentHasher(client=client, instance=instance)

    # Cleanup old attachment records at startup
    await attachment_tracker.cleanup_old_records()

    context = BoostContext(
        fenliu_client=fenliu_client,
        reblog_service=reblog_service,
        config=config,
        attachment_tracker=attachment_tracker,
        attachment_hasher=attachment_hasher,
    )

    await _fenliu_main_loop(
        context=context,
        max_posts=effective_max_posts,
    )


def _should_boost_fenliu_post(
    status: Status,
    config: Configuration,
) -> bool:
    """Quick validation checks for FenLiu posts.

    Performs minimal validation on posts from FenLiu before attempting reblog.
    This is intentionally lightweight as FenLiu pre-filters posts.

    Args:
        status: Status to validate
        config: Configuration with validation settings

    Returns:
        True if post should be boosted, False otherwise.

    """
    # Skip if no content
    if not status.get("content"):
        log.bind(validation="no_content").debug("Skipping post with no content")
        return False

    # Skip if sensitive and we don't reblog sensitive content
    if status.get("sensitive") and not config.reblog_sensitive:
        log.bind(validation="sensitive").debug("Skipping sensitive post")
        return False

    # Skip if in reply (optional check based on config)
    if status.get("in_reply_to_id"):
        log.bind(validation="is_reply").debug("Skipping reply")
        return False

    return True


async def _check_for_duplicate_attachments_from_status(
    status: Status,
    attachment_tracker: AttachmentTracker,
    attachment_hasher: AttachmentHasher,
) -> Any:
    """Check if any attachments in status have been boosted before.

    Checks attachments using URL → SHA-256 → dHash in order.

    Args:
        status: ActivityPub Status from the fediverse instance
        attachment_tracker: Tracker for duplicate attachments
        attachment_hasher: Hasher for computing attachment hashes

    Returns:
        AttachmentRecord if duplicate found, None otherwise.

    """
    attachments = status.get("media_attachments") or []
    status_id = status.get("id", "unknown")
    log.bind(status_id=status_id, attachment_count=len(attachments)).debug(
        f"Checking {len(attachments)} attachments for duplicates in post {status_id}"
    )

    if not attachments:
        log.bind(status_id=status_id).debug(f"Post {status_id} has no attachments, skipping duplicate check")
        return None

    for attachment in attachments:
        url = attachment.get("url")
        media_type = attachment.get("mediaType") or attachment.get("type")
        log.bind(status_id=status_id, url=url, media_type=media_type).debug(
            f"Checking attachment: url={url}, media_type={media_type}"
        )

        if not url:
            log.bind(status_id=status_id).debug("Attachment has no URL, skipping")
            continue

        # Try checking without hashes first (fast path)
        existing = await attachment_tracker.check_attachment(
            url=url,
            content_hash=None,
            dhash=None,
        )

        if existing:
            log.bind(status_id=status_id, url=url, detection_method="url").debug("Duplicate found by URL match")
            return existing

        # If not found by URL, compute hashes and check again
        content_hash, dhash = await attachment_hasher.hash_attachment(
            url=url,
            media_type=media_type,
        )

        existing = await attachment_tracker.check_attachment(
            url=url,
            content_hash=content_hash,
            dhash=dhash,
        )

        if existing:
            log.bind(status_id=status_id, url=url, detection_method="hash").debug("Duplicate found by hash match")
            return existing

    return None


async def _record_post_attachments_from_status(
    status: Status,
    post_id: str,
    attachment_tracker: AttachmentTracker,
    attachment_hasher: AttachmentHasher,
) -> None:
    """Record all attachments from a successfully boosted post.

    Args:
        status: ActivityPub Status from the fediverse instance
        post_id: ID of the post that was boosted
        attachment_tracker: Tracker for duplicate attachments
        attachment_hasher: Hasher for computing attachment hashes

    """
    attachments = status.get("media_attachments") or []
    log.bind(post_id=post_id, attachment_count=len(attachments)).debug(
        f"Recording {len(attachments)} attachments for boosted post {post_id}"
    )

    for attachment in attachments:
        url = attachment.get("url")
        media_type = attachment.get("mediaType") or attachment.get("type")
        log.bind(post_id=post_id, url=url, media_type=media_type).debug(
            f"Recording attachment: url={url}, media_type={media_type}"
        )

        if not url:
            continue

        content_hash, dhash = await attachment_hasher.hash_attachment(
            url=url,
            media_type=media_type,
        )

        await attachment_tracker.record_attachment(
            url=url,
            boosted_post_id=post_id,
            content_hash=content_hash,
            dhash=dhash,
            media_type=media_type,
        )
        log.bind(post_id=post_id, url=url, content_hash=content_hash[:8] if content_hash else None).debug(
            f"Recorded attachment {url} for post {post_id} (hash: {content_hash[:8] if content_hash else 'N/A'}...)"
        )
