"""Lint MCP tools for scitex-linter."""

from typing import Optional


def register_lint_tools(mcp) -> None:
    """Register lint-related MCP tools."""

    @mcp.tool()
    def linter_check(
        path: str, severity: str = "info", category: Optional[str] = None
    ) -> dict:
        """Check a Python file for SciTeX pattern compliance."""
        from ...checker import lint_file
        from ...config import load_config
        from ...formatter import to_json
        from ...rules import SEVERITY_ORDER

        config = load_config(path)
        issues = lint_file(path, config=config)
        min_sev = SEVERITY_ORDER.get(severity, 0)
        categories = set(category.split(",")) if category else None

        issues = [
            i
            for i in issues
            if SEVERITY_ORDER[i.rule.severity] >= min_sev
            and (categories is None or i.rule.category in categories)
        ]

        return to_json(issues, path)

    @mcp.tool()
    def linter_list_rules(
        category: Optional[str] = None, severity: Optional[str] = None
    ) -> dict:
        """List all available lint rules (built-in + plugin-contributed)."""
        from ... import list_rules

        rules_list = list_rules()

        if category:
            cats = set(category.split(","))
            rules_list = [r for r in rules_list if r.category in cats]
        if severity:
            rules_list = [r for r in rules_list if r.severity == severity]

        return {
            "rules": [
                {
                    "id": r.id,
                    "severity": r.severity,
                    "category": r.category,
                    "message": r.message,
                    "suggestion": r.suggestion,
                }
                for r in rules_list
            ],
            "count": len(rules_list),
        }

    @mcp.tool()
    def linter_check_source(source: str, filepath: str = "<stdin>") -> dict:
        """Lint Python source code string for SciTeX pattern compliance."""
        from ...checker import lint_source
        from ...config import load_config
        from ...formatter import to_json

        config = load_config(filepath)
        issues = lint_source(source, filepath=filepath, config=config)
        return to_json(issues, filepath)
