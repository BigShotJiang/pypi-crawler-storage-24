import typer

from cli.commands.knowledge.collections.status.presenter import (
    present_collection_statuses,
)
from cli.infrastructure.command import async_command, authenticated_client


def knowledge_collections_status_command(
    collection: str | None = typer.Option(
        None,
        "-C",
        "--collection",
        help="Filter by collection ID or name",
    ),
) -> None:
    """Show per-collection document processing counts.

    Examples:
        alloy knowledge collections status
        alloy knowledge collections status --collection support-docs
        alloy knowledge collections status -C 550e8400-e29b-41d4-a716-446655440000
    """
    _execute_status(collection_id=collection)


@async_command
async def _execute_status(collection_id: str | None) -> None:
    async with authenticated_client() as (_config, client):
        response = await client.list_collection_statuses(collection_id=collection_id)

    present_collection_statuses(response)
