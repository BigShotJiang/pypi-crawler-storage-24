# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from ..types import opportunity_list_params, opportunity_create_params, opportunity_update_params
from .._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from .._utils import maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._base_client import make_request_options
from ..types.opportunity_list_response import OpportunityListResponse
from ..types.opportunity_create_response import OpportunityCreateResponse
from ..types.opportunity_update_response import OpportunityUpdateResponse
from ..types.opportunity_retrieve_response import OpportunityRetrieveResponse

__all__ = ["OpportunityResource", "AsyncOpportunityResource"]


class OpportunityResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> OpportunityResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Lightfld/lightfield-python#accessing-raw-response-data-eg-headers
        """
        return OpportunityResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> OpportunityResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Lightfld/lightfield-python#with_streaming_response
        """
        return OpportunityResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        fields: opportunity_create_params.Fields,
        relationships: opportunity_create_params.Relationships,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> OpportunityCreateResponse:
        """
        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/v1/opportunities",
            body=maybe_transform(
                {
                    "fields": fields,
                    "relationships": relationships,
                },
                opportunity_create_params.OpportunityCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=OpportunityCreateResponse,
        )

    def retrieve(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> OpportunityRetrieveResponse:
        """
        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get(
            f"/v1/opportunities/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=OpportunityRetrieveResponse,
        )

    def update(
        self,
        id: str,
        *,
        fields: opportunity_update_params.Fields | Omit = omit,
        relationships: opportunity_update_params.Relationships | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> OpportunityUpdateResponse:
        """
        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._post(
            f"/v1/opportunities/{id}",
            body=maybe_transform(
                {
                    "fields": fields,
                    "relationships": relationships,
                },
                opportunity_update_params.OpportunityUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=OpportunityUpdateResponse,
        )

    def list(
        self,
        *,
        limit: int | Omit = omit,
        offset: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> OpportunityListResponse:
        """
        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            "/v1/opportunities",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "limit": limit,
                        "offset": offset,
                    },
                    opportunity_list_params.OpportunityListParams,
                ),
            ),
            cast_to=OpportunityListResponse,
        )


class AsyncOpportunityResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncOpportunityResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Lightfld/lightfield-python#accessing-raw-response-data-eg-headers
        """
        return AsyncOpportunityResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncOpportunityResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Lightfld/lightfield-python#with_streaming_response
        """
        return AsyncOpportunityResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        fields: opportunity_create_params.Fields,
        relationships: opportunity_create_params.Relationships,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> OpportunityCreateResponse:
        """
        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/v1/opportunities",
            body=await async_maybe_transform(
                {
                    "fields": fields,
                    "relationships": relationships,
                },
                opportunity_create_params.OpportunityCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=OpportunityCreateResponse,
        )

    async def retrieve(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> OpportunityRetrieveResponse:
        """
        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._get(
            f"/v1/opportunities/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=OpportunityRetrieveResponse,
        )

    async def update(
        self,
        id: str,
        *,
        fields: opportunity_update_params.Fields | Omit = omit,
        relationships: opportunity_update_params.Relationships | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> OpportunityUpdateResponse:
        """
        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._post(
            f"/v1/opportunities/{id}",
            body=await async_maybe_transform(
                {
                    "fields": fields,
                    "relationships": relationships,
                },
                opportunity_update_params.OpportunityUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=OpportunityUpdateResponse,
        )

    async def list(
        self,
        *,
        limit: int | Omit = omit,
        offset: int | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> OpportunityListResponse:
        """
        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            "/v1/opportunities",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "limit": limit,
                        "offset": offset,
                    },
                    opportunity_list_params.OpportunityListParams,
                ),
            ),
            cast_to=OpportunityListResponse,
        )


class OpportunityResourceWithRawResponse:
    def __init__(self, opportunity: OpportunityResource) -> None:
        self._opportunity = opportunity

        self.create = to_raw_response_wrapper(
            opportunity.create,
        )
        self.retrieve = to_raw_response_wrapper(
            opportunity.retrieve,
        )
        self.update = to_raw_response_wrapper(
            opportunity.update,
        )
        self.list = to_raw_response_wrapper(
            opportunity.list,
        )


class AsyncOpportunityResourceWithRawResponse:
    def __init__(self, opportunity: AsyncOpportunityResource) -> None:
        self._opportunity = opportunity

        self.create = async_to_raw_response_wrapper(
            opportunity.create,
        )
        self.retrieve = async_to_raw_response_wrapper(
            opportunity.retrieve,
        )
        self.update = async_to_raw_response_wrapper(
            opportunity.update,
        )
        self.list = async_to_raw_response_wrapper(
            opportunity.list,
        )


class OpportunityResourceWithStreamingResponse:
    def __init__(self, opportunity: OpportunityResource) -> None:
        self._opportunity = opportunity

        self.create = to_streamed_response_wrapper(
            opportunity.create,
        )
        self.retrieve = to_streamed_response_wrapper(
            opportunity.retrieve,
        )
        self.update = to_streamed_response_wrapper(
            opportunity.update,
        )
        self.list = to_streamed_response_wrapper(
            opportunity.list,
        )


class AsyncOpportunityResourceWithStreamingResponse:
    def __init__(self, opportunity: AsyncOpportunityResource) -> None:
        self._opportunity = opportunity

        self.create = async_to_streamed_response_wrapper(
            opportunity.create,
        )
        self.retrieve = async_to_streamed_response_wrapper(
            opportunity.retrieve,
        )
        self.update = async_to_streamed_response_wrapper(
            opportunity.update,
        )
        self.list = async_to_streamed_response_wrapper(
            opportunity.list,
        )
