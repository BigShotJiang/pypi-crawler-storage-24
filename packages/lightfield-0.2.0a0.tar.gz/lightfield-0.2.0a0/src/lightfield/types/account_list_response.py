# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import TYPE_CHECKING, Dict, List, Union, Optional

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["AccountListResponse", "Data", "DataFields", "DataRelationships"]


class DataFields(BaseModel):
    value: Union[
        str,
        float,
        bool,
        List[Union[str, float, bool, List[Optional[object]], Dict[str, object], None]],
        Dict[str, Union[str, float, bool, List[Optional[object]], Dict[str, object], None]],
        None,
    ] = None

    value_type: str = FieldInfo(alias="valueType")


class DataRelationships(BaseModel):
    cardinality: str

    object_type: str = FieldInfo(alias="objectType")

    values: List[str]


class Data(BaseModel):
    id: str

    created_at: str = FieldInfo(alias="createdAt")

    fields: Dict[str, DataFields]

    http_link: Optional[str] = FieldInfo(alias="httpLink", default=None)

    relationships: Dict[str, DataRelationships]

    if TYPE_CHECKING:
        # Some versions of Pydantic <2.8.0 have a bug and don’t allow assigning a
        # value to this field, so for compatibility we avoid doing it at runtime.
        __pydantic_extra__: Dict[
            str,
            Union[
                str,
                float,
                bool,
                List[Union[str, float, bool, List[Optional[object]], Dict[str, object], None]],
                Dict[str, Union[str, float, bool, List[Optional[object]], Dict[str, object], None]],
                None,
            ],
        ] = FieldInfo(init=False)  # pyright: ignore[reportIncompatibleVariableOverride]

        # Stub to indicate that arbitrary properties are accepted.
        # To access properties that are not valid identifiers you can use `getattr`, e.g.
        # `getattr(obj, '$type')`
        def __getattr__(
            self, attr: str
        ) -> Union[
            str,
            float,
            bool,
            List[Union[str, float, bool, List[Optional[object]], Dict[str, object], None]],
            Dict[str, Union[str, float, bool, List[Optional[object]], Dict[str, object], None]],
            None,
        ]: ...
    else:
        __pydantic_extra__: Dict[
            str,
            Union[
                str,
                float,
                bool,
                List[Union[str, float, bool, List[Optional[object]], Dict[str, object], None]],
                Dict[str, Union[str, float, bool, List[Optional[object]], Dict[str, object], None]],
                None,
            ],
        ]


class AccountListResponse(BaseModel):
    data: List[Data]

    object: str

    total_count: int = FieldInfo(alias="totalCount")
