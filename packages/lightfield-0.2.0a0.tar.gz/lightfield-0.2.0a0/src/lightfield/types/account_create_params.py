# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Union, Iterable, Optional
from typing_extensions import Required, Annotated, TypedDict

from .._types import SequenceNotStr
from .._utils import PropertyInfo

__all__ = ["AccountCreateParams", "Fields", "Relationships"]


class AccountCreateParams(TypedDict, total=False):
    fields: Required[Fields]

    relationships: Relationships


class Fields(
    TypedDict,
    total=False,
    extra_items=Union[
        str,
        float,
        bool,
        SequenceNotStr[Union[str, float, bool, Iterable[object], Dict[str, object], None]],
        Dict[str, Union[str, float, bool, Iterable[object], Dict[str, object], None]],
        None,
    ],
):  # type: ignore[call-arg]
    system_name: Required[str]

    system_facebook: Optional[str]

    system_headcount: Optional[str]

    system_industry: Optional[SequenceNotStr[str]]

    system_instagram: Optional[str]

    system_last_funding_type: Annotated[Optional[str], PropertyInfo(alias="system_lastFundingType")]

    system_linked_in: Annotated[Optional[str], PropertyInfo(alias="system_linkedIn")]

    system_primary_address: Annotated[Optional[Dict[str, str]], PropertyInfo(alias="system_primaryAddress")]

    system_twitter: Optional[str]

    system_website: Optional[SequenceNotStr[str]]


class Relationships(TypedDict, total=False, extra_items=Union[str, SequenceNotStr[str]]):  # type: ignore[call-arg]
    system_contact: Union[str, SequenceNotStr[str]]

    system_owner: Union[str, SequenceNotStr[str]]
