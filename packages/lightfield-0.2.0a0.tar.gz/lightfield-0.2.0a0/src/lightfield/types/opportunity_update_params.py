# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Union, Iterable, Optional
from typing_extensions import Annotated, TypedDict

from .._types import SequenceNotStr
from .._utils import PropertyInfo

__all__ = [
    "OpportunityUpdateParams",
    "Fields",
    "Relationships",
    "RelationshipsSystemAccount",
    "RelationshipsSystemChampion",
    "RelationshipsSystemCreatedBy",
    "RelationshipsSystemEvaluator",
    "RelationshipsSystemOwner",
    "Relationship",
]


class OpportunityUpdateParams(TypedDict, total=False):
    fields: Fields

    relationships: Relationships


class Fields(
    TypedDict,
    total=False,
    extra_items=Union[
        str,
        float,
        bool,
        SequenceNotStr[Union[str, float, bool, Iterable[object], Dict[str, object], None]],
        Dict[str, Union[str, float, bool, Iterable[object], Dict[str, object], None]],
        None,
    ],
):  # type: ignore[call-arg]
    system_name: Optional[str]

    system_stage: Optional[str]


class RelationshipsSystemAccount(TypedDict, total=False):
    add: Union[str, SequenceNotStr[str]]

    remove: Union[str, SequenceNotStr[str]]

    replace: Union[str, SequenceNotStr[str]]


class RelationshipsSystemChampion(TypedDict, total=False):
    add: Union[str, SequenceNotStr[str]]

    remove: Union[str, SequenceNotStr[str]]

    replace: Union[str, SequenceNotStr[str]]


class RelationshipsSystemCreatedBy(TypedDict, total=False):
    add: Union[str, SequenceNotStr[str]]

    remove: Union[str, SequenceNotStr[str]]

    replace: Union[str, SequenceNotStr[str]]


class RelationshipsSystemEvaluator(TypedDict, total=False):
    add: Union[str, SequenceNotStr[str]]

    remove: Union[str, SequenceNotStr[str]]

    replace: Union[str, SequenceNotStr[str]]


class RelationshipsSystemOwner(TypedDict, total=False):
    add: Union[str, SequenceNotStr[str]]

    remove: Union[str, SequenceNotStr[str]]

    replace: Union[str, SequenceNotStr[str]]


class Relationship(TypedDict, total=False):
    add: Union[str, SequenceNotStr[str]]

    remove: Union[str, SequenceNotStr[str]]

    replace: Union[str, SequenceNotStr[str]]


class Relationships(TypedDict, total=False, extra_items=Relationship):  # type: ignore[call-arg]
    system_account: RelationshipsSystemAccount

    system_champion: RelationshipsSystemChampion

    system_created_by: Annotated[RelationshipsSystemCreatedBy, PropertyInfo(alias="system_createdBy")]

    system_evaluator: RelationshipsSystemEvaluator

    system_owner: RelationshipsSystemOwner
