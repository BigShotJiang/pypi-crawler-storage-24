from __future__ import annotations

from typing import Any
from typing_extensions import override

from ._proxy import LazyProxy


class ResourcesProxy(LazyProxy[Any]):
    """A proxy for the `lightfield.resources` module.

    This is used so that we can lazily import `lightfield.resources` only when
    needed *and* so that users can just import `lightfield` and reference `lightfield.resources`
    """

    @override
    def __load__(self) -> Any:
        import importlib

        mod = importlib.import_module("lightfield.resources")
        return mod


resources = ResourcesProxy().__as_proxied__()
