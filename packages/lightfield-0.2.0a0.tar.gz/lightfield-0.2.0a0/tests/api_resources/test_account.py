# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from lightfield import Lightfield, AsyncLightfield
from tests.utils import assert_matches_type
from lightfield.types import (
    AccountListResponse,
    AccountCreateResponse,
    AccountUpdateResponse,
    AccountRetrieveResponse,
)

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestAccount:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @parametrize
    def test_method_create(self, client: Lightfield) -> None:
        account = client.account.create(
            fields={"system_name": "system_name"},
        )
        assert_matches_type(AccountCreateResponse, account, path=["response"])

    @parametrize
    def test_method_create_with_all_params(self, client: Lightfield) -> None:
        account = client.account.create(
            fields={
                "system_name": "system_name",
                "system_facebook": "system_facebook",
                "system_headcount": "system_headcount",
                "system_industry": ["string"],
                "system_instagram": "system_instagram",
                "system_last_funding_type": "system_lastFundingType",
                "system_linked_in": "system_linkedIn",
                "system_primary_address": {"foo": "string"},
                "system_twitter": "system_twitter",
                "system_website": ["string"],
            },
            relationships={
                "system_contact": "string",
                "system_owner": "string",
            },
        )
        assert_matches_type(AccountCreateResponse, account, path=["response"])

    @parametrize
    def test_raw_response_create(self, client: Lightfield) -> None:
        response = client.account.with_raw_response.create(
            fields={"system_name": "system_name"},
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        account = response.parse()
        assert_matches_type(AccountCreateResponse, account, path=["response"])

    @parametrize
    def test_streaming_response_create(self, client: Lightfield) -> None:
        with client.account.with_streaming_response.create(
            fields={"system_name": "system_name"},
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            account = response.parse()
            assert_matches_type(AccountCreateResponse, account, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_method_retrieve(self, client: Lightfield) -> None:
        account = client.account.retrieve(
            "id",
        )
        assert_matches_type(AccountRetrieveResponse, account, path=["response"])

    @parametrize
    def test_raw_response_retrieve(self, client: Lightfield) -> None:
        response = client.account.with_raw_response.retrieve(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        account = response.parse()
        assert_matches_type(AccountRetrieveResponse, account, path=["response"])

    @parametrize
    def test_streaming_response_retrieve(self, client: Lightfield) -> None:
        with client.account.with_streaming_response.retrieve(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            account = response.parse()
            assert_matches_type(AccountRetrieveResponse, account, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_retrieve(self, client: Lightfield) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.account.with_raw_response.retrieve(
                "",
            )

    @parametrize
    def test_method_update(self, client: Lightfield) -> None:
        account = client.account.update(
            id="id",
        )
        assert_matches_type(AccountUpdateResponse, account, path=["response"])

    @parametrize
    def test_method_update_with_all_params(self, client: Lightfield) -> None:
        account = client.account.update(
            id="id",
            fields={
                "system_facebook": "system_facebook",
                "system_headcount": "system_headcount",
                "system_industry": ["string"],
                "system_instagram": "system_instagram",
                "system_last_funding_type": "system_lastFundingType",
                "system_linked_in": "system_linkedIn",
                "system_name": "system_name",
                "system_primary_address": {"foo": "string"},
                "system_twitter": "system_twitter",
                "system_website": ["string"],
            },
            relationships={
                "system_contact": {
                    "add": "string",
                    "remove": "string",
                    "replace": "string",
                },
                "system_owner": {
                    "add": "string",
                    "remove": "string",
                    "replace": "string",
                },
            },
        )
        assert_matches_type(AccountUpdateResponse, account, path=["response"])

    @parametrize
    def test_raw_response_update(self, client: Lightfield) -> None:
        response = client.account.with_raw_response.update(
            id="id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        account = response.parse()
        assert_matches_type(AccountUpdateResponse, account, path=["response"])

    @parametrize
    def test_streaming_response_update(self, client: Lightfield) -> None:
        with client.account.with_streaming_response.update(
            id="id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            account = response.parse()
            assert_matches_type(AccountUpdateResponse, account, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_update(self, client: Lightfield) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.account.with_raw_response.update(
                id="",
            )

    @parametrize
    def test_method_list(self, client: Lightfield) -> None:
        account = client.account.list()
        assert_matches_type(AccountListResponse, account, path=["response"])

    @parametrize
    def test_method_list_with_all_params(self, client: Lightfield) -> None:
        account = client.account.list(
            limit=1,
            offset=0,
        )
        assert_matches_type(AccountListResponse, account, path=["response"])

    @parametrize
    def test_raw_response_list(self, client: Lightfield) -> None:
        response = client.account.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        account = response.parse()
        assert_matches_type(AccountListResponse, account, path=["response"])

    @parametrize
    def test_streaming_response_list(self, client: Lightfield) -> None:
        with client.account.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            account = response.parse()
            assert_matches_type(AccountListResponse, account, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncAccount:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @parametrize
    async def test_method_create(self, async_client: AsyncLightfield) -> None:
        account = await async_client.account.create(
            fields={"system_name": "system_name"},
        )
        assert_matches_type(AccountCreateResponse, account, path=["response"])

    @parametrize
    async def test_method_create_with_all_params(self, async_client: AsyncLightfield) -> None:
        account = await async_client.account.create(
            fields={
                "system_name": "system_name",
                "system_facebook": "system_facebook",
                "system_headcount": "system_headcount",
                "system_industry": ["string"],
                "system_instagram": "system_instagram",
                "system_last_funding_type": "system_lastFundingType",
                "system_linked_in": "system_linkedIn",
                "system_primary_address": {"foo": "string"},
                "system_twitter": "system_twitter",
                "system_website": ["string"],
            },
            relationships={
                "system_contact": "string",
                "system_owner": "string",
            },
        )
        assert_matches_type(AccountCreateResponse, account, path=["response"])

    @parametrize
    async def test_raw_response_create(self, async_client: AsyncLightfield) -> None:
        response = await async_client.account.with_raw_response.create(
            fields={"system_name": "system_name"},
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        account = await response.parse()
        assert_matches_type(AccountCreateResponse, account, path=["response"])

    @parametrize
    async def test_streaming_response_create(self, async_client: AsyncLightfield) -> None:
        async with async_client.account.with_streaming_response.create(
            fields={"system_name": "system_name"},
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            account = await response.parse()
            assert_matches_type(AccountCreateResponse, account, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_method_retrieve(self, async_client: AsyncLightfield) -> None:
        account = await async_client.account.retrieve(
            "id",
        )
        assert_matches_type(AccountRetrieveResponse, account, path=["response"])

    @parametrize
    async def test_raw_response_retrieve(self, async_client: AsyncLightfield) -> None:
        response = await async_client.account.with_raw_response.retrieve(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        account = await response.parse()
        assert_matches_type(AccountRetrieveResponse, account, path=["response"])

    @parametrize
    async def test_streaming_response_retrieve(self, async_client: AsyncLightfield) -> None:
        async with async_client.account.with_streaming_response.retrieve(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            account = await response.parse()
            assert_matches_type(AccountRetrieveResponse, account, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_retrieve(self, async_client: AsyncLightfield) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.account.with_raw_response.retrieve(
                "",
            )

    @parametrize
    async def test_method_update(self, async_client: AsyncLightfield) -> None:
        account = await async_client.account.update(
            id="id",
        )
        assert_matches_type(AccountUpdateResponse, account, path=["response"])

    @parametrize
    async def test_method_update_with_all_params(self, async_client: AsyncLightfield) -> None:
        account = await async_client.account.update(
            id="id",
            fields={
                "system_facebook": "system_facebook",
                "system_headcount": "system_headcount",
                "system_industry": ["string"],
                "system_instagram": "system_instagram",
                "system_last_funding_type": "system_lastFundingType",
                "system_linked_in": "system_linkedIn",
                "system_name": "system_name",
                "system_primary_address": {"foo": "string"},
                "system_twitter": "system_twitter",
                "system_website": ["string"],
            },
            relationships={
                "system_contact": {
                    "add": "string",
                    "remove": "string",
                    "replace": "string",
                },
                "system_owner": {
                    "add": "string",
                    "remove": "string",
                    "replace": "string",
                },
            },
        )
        assert_matches_type(AccountUpdateResponse, account, path=["response"])

    @parametrize
    async def test_raw_response_update(self, async_client: AsyncLightfield) -> None:
        response = await async_client.account.with_raw_response.update(
            id="id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        account = await response.parse()
        assert_matches_type(AccountUpdateResponse, account, path=["response"])

    @parametrize
    async def test_streaming_response_update(self, async_client: AsyncLightfield) -> None:
        async with async_client.account.with_streaming_response.update(
            id="id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            account = await response.parse()
            assert_matches_type(AccountUpdateResponse, account, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_update(self, async_client: AsyncLightfield) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.account.with_raw_response.update(
                id="",
            )

    @parametrize
    async def test_method_list(self, async_client: AsyncLightfield) -> None:
        account = await async_client.account.list()
        assert_matches_type(AccountListResponse, account, path=["response"])

    @parametrize
    async def test_method_list_with_all_params(self, async_client: AsyncLightfield) -> None:
        account = await async_client.account.list(
            limit=1,
            offset=0,
        )
        assert_matches_type(AccountListResponse, account, path=["response"])

    @parametrize
    async def test_raw_response_list(self, async_client: AsyncLightfield) -> None:
        response = await async_client.account.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        account = await response.parse()
        assert_matches_type(AccountListResponse, account, path=["response"])

    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncLightfield) -> None:
        async with async_client.account.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            account = await response.parse()
            assert_matches_type(AccountListResponse, account, path=["response"])

        assert cast(Any, response.is_closed) is True
