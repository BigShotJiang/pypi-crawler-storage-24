# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from lightfield import Lightfield, AsyncLightfield
from tests.utils import assert_matches_type
from lightfield.types import (
    ContactListResponse,
    ContactCreateResponse,
    ContactUpdateResponse,
    ContactRetrieveResponse,
)

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestContact:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @parametrize
    def test_method_create(self, client: Lightfield) -> None:
        contact = client.contact.create(
            fields={},
        )
        assert_matches_type(ContactCreateResponse, contact, path=["response"])

    @parametrize
    def test_method_create_with_all_params(self, client: Lightfield) -> None:
        contact = client.contact.create(
            fields={
                "system_email": ["string"],
                "system_name": {
                    "first_name": "firstName",
                    "last_name": "lastName",
                },
                "system_profile_photo_url": "system_profilePhotoUrl",
            },
            relationships={"system_account": "string"},
        )
        assert_matches_type(ContactCreateResponse, contact, path=["response"])

    @parametrize
    def test_raw_response_create(self, client: Lightfield) -> None:
        response = client.contact.with_raw_response.create(
            fields={},
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        contact = response.parse()
        assert_matches_type(ContactCreateResponse, contact, path=["response"])

    @parametrize
    def test_streaming_response_create(self, client: Lightfield) -> None:
        with client.contact.with_streaming_response.create(
            fields={},
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            contact = response.parse()
            assert_matches_type(ContactCreateResponse, contact, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_method_retrieve(self, client: Lightfield) -> None:
        contact = client.contact.retrieve(
            "id",
        )
        assert_matches_type(ContactRetrieveResponse, contact, path=["response"])

    @parametrize
    def test_raw_response_retrieve(self, client: Lightfield) -> None:
        response = client.contact.with_raw_response.retrieve(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        contact = response.parse()
        assert_matches_type(ContactRetrieveResponse, contact, path=["response"])

    @parametrize
    def test_streaming_response_retrieve(self, client: Lightfield) -> None:
        with client.contact.with_streaming_response.retrieve(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            contact = response.parse()
            assert_matches_type(ContactRetrieveResponse, contact, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_retrieve(self, client: Lightfield) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.contact.with_raw_response.retrieve(
                "",
            )

    @parametrize
    def test_method_update(self, client: Lightfield) -> None:
        contact = client.contact.update(
            id="id",
        )
        assert_matches_type(ContactUpdateResponse, contact, path=["response"])

    @parametrize
    def test_method_update_with_all_params(self, client: Lightfield) -> None:
        contact = client.contact.update(
            id="id",
            fields={
                "system_email": ["string"],
                "system_name": {
                    "first_name": "firstName",
                    "last_name": "lastName",
                },
                "system_profile_photo_url": "system_profilePhotoUrl",
            },
            relationships={
                "system_account": {
                    "add": "string",
                    "remove": "string",
                    "replace": "string",
                }
            },
        )
        assert_matches_type(ContactUpdateResponse, contact, path=["response"])

    @parametrize
    def test_raw_response_update(self, client: Lightfield) -> None:
        response = client.contact.with_raw_response.update(
            id="id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        contact = response.parse()
        assert_matches_type(ContactUpdateResponse, contact, path=["response"])

    @parametrize
    def test_streaming_response_update(self, client: Lightfield) -> None:
        with client.contact.with_streaming_response.update(
            id="id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            contact = response.parse()
            assert_matches_type(ContactUpdateResponse, contact, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_update(self, client: Lightfield) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.contact.with_raw_response.update(
                id="",
            )

    @parametrize
    def test_method_list(self, client: Lightfield) -> None:
        contact = client.contact.list()
        assert_matches_type(ContactListResponse, contact, path=["response"])

    @parametrize
    def test_method_list_with_all_params(self, client: Lightfield) -> None:
        contact = client.contact.list(
            limit=1,
            offset=0,
        )
        assert_matches_type(ContactListResponse, contact, path=["response"])

    @parametrize
    def test_raw_response_list(self, client: Lightfield) -> None:
        response = client.contact.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        contact = response.parse()
        assert_matches_type(ContactListResponse, contact, path=["response"])

    @parametrize
    def test_streaming_response_list(self, client: Lightfield) -> None:
        with client.contact.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            contact = response.parse()
            assert_matches_type(ContactListResponse, contact, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncContact:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @parametrize
    async def test_method_create(self, async_client: AsyncLightfield) -> None:
        contact = await async_client.contact.create(
            fields={},
        )
        assert_matches_type(ContactCreateResponse, contact, path=["response"])

    @parametrize
    async def test_method_create_with_all_params(self, async_client: AsyncLightfield) -> None:
        contact = await async_client.contact.create(
            fields={
                "system_email": ["string"],
                "system_name": {
                    "first_name": "firstName",
                    "last_name": "lastName",
                },
                "system_profile_photo_url": "system_profilePhotoUrl",
            },
            relationships={"system_account": "string"},
        )
        assert_matches_type(ContactCreateResponse, contact, path=["response"])

    @parametrize
    async def test_raw_response_create(self, async_client: AsyncLightfield) -> None:
        response = await async_client.contact.with_raw_response.create(
            fields={},
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        contact = await response.parse()
        assert_matches_type(ContactCreateResponse, contact, path=["response"])

    @parametrize
    async def test_streaming_response_create(self, async_client: AsyncLightfield) -> None:
        async with async_client.contact.with_streaming_response.create(
            fields={},
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            contact = await response.parse()
            assert_matches_type(ContactCreateResponse, contact, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_method_retrieve(self, async_client: AsyncLightfield) -> None:
        contact = await async_client.contact.retrieve(
            "id",
        )
        assert_matches_type(ContactRetrieveResponse, contact, path=["response"])

    @parametrize
    async def test_raw_response_retrieve(self, async_client: AsyncLightfield) -> None:
        response = await async_client.contact.with_raw_response.retrieve(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        contact = await response.parse()
        assert_matches_type(ContactRetrieveResponse, contact, path=["response"])

    @parametrize
    async def test_streaming_response_retrieve(self, async_client: AsyncLightfield) -> None:
        async with async_client.contact.with_streaming_response.retrieve(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            contact = await response.parse()
            assert_matches_type(ContactRetrieveResponse, contact, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_retrieve(self, async_client: AsyncLightfield) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.contact.with_raw_response.retrieve(
                "",
            )

    @parametrize
    async def test_method_update(self, async_client: AsyncLightfield) -> None:
        contact = await async_client.contact.update(
            id="id",
        )
        assert_matches_type(ContactUpdateResponse, contact, path=["response"])

    @parametrize
    async def test_method_update_with_all_params(self, async_client: AsyncLightfield) -> None:
        contact = await async_client.contact.update(
            id="id",
            fields={
                "system_email": ["string"],
                "system_name": {
                    "first_name": "firstName",
                    "last_name": "lastName",
                },
                "system_profile_photo_url": "system_profilePhotoUrl",
            },
            relationships={
                "system_account": {
                    "add": "string",
                    "remove": "string",
                    "replace": "string",
                }
            },
        )
        assert_matches_type(ContactUpdateResponse, contact, path=["response"])

    @parametrize
    async def test_raw_response_update(self, async_client: AsyncLightfield) -> None:
        response = await async_client.contact.with_raw_response.update(
            id="id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        contact = await response.parse()
        assert_matches_type(ContactUpdateResponse, contact, path=["response"])

    @parametrize
    async def test_streaming_response_update(self, async_client: AsyncLightfield) -> None:
        async with async_client.contact.with_streaming_response.update(
            id="id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            contact = await response.parse()
            assert_matches_type(ContactUpdateResponse, contact, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_update(self, async_client: AsyncLightfield) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.contact.with_raw_response.update(
                id="",
            )

    @parametrize
    async def test_method_list(self, async_client: AsyncLightfield) -> None:
        contact = await async_client.contact.list()
        assert_matches_type(ContactListResponse, contact, path=["response"])

    @parametrize
    async def test_method_list_with_all_params(self, async_client: AsyncLightfield) -> None:
        contact = await async_client.contact.list(
            limit=1,
            offset=0,
        )
        assert_matches_type(ContactListResponse, contact, path=["response"])

    @parametrize
    async def test_raw_response_list(self, async_client: AsyncLightfield) -> None:
        response = await async_client.contact.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        contact = await response.parse()
        assert_matches_type(ContactListResponse, contact, path=["response"])

    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncLightfield) -> None:
        async with async_client.contact.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            contact = await response.parse()
            assert_matches_type(ContactListResponse, contact, path=["response"])

        assert cast(Any, response.is_closed) is True
