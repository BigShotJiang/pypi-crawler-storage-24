"""Task transfer/copy/move mixin."""

from pathlib import Path

from jot.categories.config import CategoryConfig
from jot.categories.manager import CategoryManager
from jot.core.task_manager import TaskManager
from jot.ui.picker import PickerItem, fuzzy_picker, quick_picker
from jot.ui.styles import RESET, RED


class TransferMixin:
    """Copy, move, and transfer tasks between projects/categories."""

    def _pick_project_fuzzy(self, prompt_text="Select project"):
        """Interactive fuzzy search project picker.

        Returns project name or None if cancelled.
        """
        if not self.registry:
            return None

        current_dir = str(self.task_manager.project_dir.resolve())
        usage_items = self.registry.list_projects_by_usage()
        available = [
            (n, p, u) for n, p, u in usage_items
            if str(Path(p).resolve()) != current_dir
        ]

        if not available:
            print(f"\n{RED}✗ No other projects available{RESET}")
            return None

        items = [
            PickerItem(
                value=name,
                label=name,
                annotation=f"({usage})" if usage > 0 else "",
            )
            for name, path, usage in available
        ]

        result = fuzzy_picker(items, prompt=prompt_text)
        return result.value

    def copy_task_to_project(self):
        """Copy current task to a different project (keeps original)"""
        if not self.registry:
            print("\n✗ Project registry not available")
            return True

        current_task = self.task_manager.get_current_task()
        if not current_task:
            print("\n✗ No current task selected")
            return True

        task_text = current_task['text']

        target_project = self._pick_project_fuzzy(f"Copy '{task_text}' to:")
        if not target_project:
            print("\n✗ Cancelled")
            return True

        target_path = self.registry.get_project_path(target_project)

        # Check if destination has the same category
        current_category = self.task_manager.category
        target_category = None
        category_preserved = False

        if current_category:
            target_cat_manager = CategoryManager(project_dir=target_path)
            if target_cat_manager.category_exists_locally(current_category):
                target_category = current_category
                category_preserved = True

        target_tm = TaskManager(
            directory=target_path, category=target_category, project_registry=self.registry
        )
        target_tm.add_task(
            task_text,
            priority=current_task.get('priority', 'none'),
            status=current_task.get('status', 'todo'),
            labels=current_task.get('labels', []),
            effort=current_task.get('effort', None),
        )

        # Preserve additional metadata on the new task
        new_task = target_tm.tasks[-1]
        new_task['notes'] = current_task.get('notes', '')
        new_task['agent_task'] = current_task.get('agent_task', False)
        new_task['keyword'] = current_task.get('keyword', None)
        new_task['day'] = current_task.get('day', None)
        if current_task.get('created_at'):
            new_task['created_at'] = current_task['created_at']

        target_tm._save_tasks()
        self.registry.record_usage(target_project)

        if category_preserved:
            print(f"✓ Copied task to {target_project} (kept in '{current_category}' category)")
        elif current_category:
            print(
                f"✓ Copied task to {target_project} "
                f"(category '{current_category}' not available, added to default)"
            )
        else:
            print(f"✓ Copied task to {target_project}")
        return True

    def move_task_to_project(self):
        """Move current task to a different project"""
        if not self.registry:
            print("\n✗ Project registry not available")
            return True

        current_task = self.task_manager.get_current_task()
        if not current_task:
            print("\n✗ No current task selected")
            return True

        task_id = current_task['id']
        task_text = current_task['text']

        target_project = self._pick_project_fuzzy(f"Move '{task_text}' to:")
        if not target_project:
            print("\n✗ Cancelled")
            return True

        target_path = self.registry.get_project_path(target_project)

        current_category = self.task_manager.category
        target_category = None
        category_preserved = False

        if current_category:
            target_cat_manager = CategoryManager(project_dir=target_path)
            if target_cat_manager.category_exists_locally(current_category):
                target_category = current_category
                category_preserved = True

        target_tm = TaskManager(
            directory=target_path, category=target_category, project_registry=self.registry
        )
        target_tm.add_task(
            task_text,
            priority=current_task.get('priority', 'none'),
            status=current_task.get('status', 'todo'),
            labels=current_task.get('labels', []),
            effort=current_task.get('effort', None),
        )

        new_task = target_tm.tasks[-1]
        new_task['notes'] = current_task.get('notes', '')
        new_task['agent_task'] = current_task.get('agent_task', False)
        new_task['keyword'] = current_task.get('keyword', None)
        new_task['day'] = current_task.get('day', None)
        if current_task.get('created_at'):
            new_task['created_at'] = current_task['created_at']

        target_tm._save_tasks()
        self.task_manager.remove_task(task_id)
        self.registry.record_usage(target_project)

        if category_preserved:
            print(f"✓ Moved task to {target_project} (kept in '{current_category}' category)")
        elif current_category:
            print(
                f"✓ Moved task to {target_project} "
                f"(category '{current_category}' not available, added to default)"
            )
        else:
            print(f"✓ Moved task to {target_project}")
        return True

    def transfer_task_to_category(self):
        """Transfer current task to a different category within the same project"""
        current_task = self.task_manager.get_current_task()
        if not current_task:
            print("\n✗ No current task selected")
            return True

        task_text = current_task['text']
        task_id = current_task['id']
        task_done = current_task.get('done', False)

        project_dir = (
            self.task_manager.project_dir if not self.task_manager.is_global else Path.cwd()
        )
        current_category = self.task_manager.category

        cat_manager = CategoryManager(project_dir=project_dir)
        local_categories = cat_manager.discover_categories()
        global_categories = cat_manager.discover_global_categories()

        # Build category list (excluding current)
        categories = []
        if current_category is not None:
            categories.append(("default", None, False))
        for cat in local_categories:
            if cat != current_category:
                categories.append((cat, cat, False))
        for cat in global_categories:
            if cat != current_category and cat not in local_categories:
                categories.append((cat, cat, True))

        if not categories:
            print("\n✗ No other categories available")
            return True

        cat_config = CategoryConfig(project_dir=project_dir)

        items = []
        for display_name, cat_name, is_global in categories:
            if display_name == "default":
                items.append(PickerItem(
                    value=(None, False),
                    label="default",
                    annotation="(no category)",
                    color=cat_config.get_color('default'),
                ))
            else:
                scope = "[global]" if is_global else "[local]"
                items.append(PickerItem(
                    value=(cat_name, is_global),
                    label=cat_name,
                    annotation=scope,
                    color=cat_config.get_color(cat_name, for_global=is_global),
                ))

        result = quick_picker(items, prompt=f"Transfer '{task_text}' to")
        if result.value is None:
            return True

        selected_category, selected_is_global = result.value

        if selected_is_global:
            dest_tm = TaskManager(
                category=selected_category, is_global=True, project_registry=self.registry
            )
        else:
            dest_tm = TaskManager(
                directory=project_dir,
                category=selected_category,
                is_global=False,
                project_registry=self.registry,
            )

        dest_tm.add_task(task_text)
        if task_done:
            new_task_id = dest_tm.tasks[-1]['id']
            dest_tm.set_task_status(new_task_id, 'done')

        self.task_manager.remove_task(task_id)

        dest_name = selected_category or 'default'
        if selected_is_global:
            print(f"✓ Transferred task to global:{dest_name}")
        else:
            print(f"✓ Transferred task to {dest_name}")

        print("\nPress Enter to continue...", end='', flush=True)
        input()
        return True
