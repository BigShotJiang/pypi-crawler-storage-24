"""Reusable interactive terminal picker with fuzzy filtering.

Provides fuzzy_picker() for filterable lists and quick_picker() for
small fixed-choice menus. Both use get_key() for raw keyboard input
and render a visual selection indicator.
"""

import sys
from dataclasses import dataclass

from jot.ui.input import get_key
from jot.ui.styles import RESET, BOLD, DIM, CYAN, GREEN
from jot.utils.text_utils import fuzzy_match


@dataclass
class PickerItem:
    """A single item in a picker list.

    Attributes:
        value: Return value when this item is selected.
        label: Display text shown in the list.
        annotation: Optional dim text after the label (e.g., path, "[global]").
        color: Optional ANSI color code for the label.
        symbol: Optional symbol prefix (e.g., priority symbol).
    """
    value: str
    label: str
    annotation: str = ""
    color: str = ""
    symbol: str = ""


@dataclass
class PickerResult:
    """Result from fuzzy_picker() or quick_picker().

    Attributes:
        value: Selected item's value, freeform text, or None if cancelled.
        is_freeform: True if value was typed by the user (not from the list).
    """
    value: object = None
    is_freeform: bool = False


def fuzzy_picker(items, prompt="Select", *, enable_filter=True,
                 max_display=15, allow_freeform=False,
                 freeform_hint="Type a new name and press Enter",
                 default_index=0):
    """Interactive terminal picker with optional fuzzy filtering.

    Args:
        items: List of PickerItem objects.
        prompt: Title text displayed at top.
        enable_filter: If True, typing filters via fuzzy_match().
        max_display: Max items visible at once.
        allow_freeform: If True, Enter with no matches returns typed text.
        freeform_hint: Hint shown when allow_freeform and no matches.
        default_index: Pre-selected item index (0-based).

    Returns:
        PickerResult with value=None if cancelled (ESC).
    """
    if not items:
        return PickerResult()

    search_buffer = ""
    selected_idx = min(default_index, len(items) - 1)

    while True:
        # Filter items
        if enable_filter and search_buffer:
            filtered = []
            for item in items:
                is_match, score, _ = fuzzy_match(search_buffer, item.label)
                if is_match:
                    filtered.append((item, score))
            filtered.sort(key=lambda x: (-x[1], x[0].label))
            visible_items = [item for item, _ in filtered]
        else:
            visible_items = list(items)

        # Clamp selection
        if visible_items:
            selected_idx = min(selected_idx, len(visible_items) - 1)
        else:
            selected_idx = 0

        # Calculate visible window
        display_items = visible_items[:max_display]

        # Render
        sys.stdout.write('\033[2J\033[H')
        print(f"{BOLD}{prompt}{RESET}")

        if enable_filter:
            print(f"{DIM}Type to filter \u00b7 \u2191\u2193 navigate \u00b7 Enter select \u00b7 ESC cancel{RESET}")
            cursor = "\u258c" if not search_buffer else ""
            print(f"\n{CYAN}> {search_buffer}{cursor}{RESET}")
        else:
            print(f"{DIM}\u2191\u2193 navigate \u00b7 Enter select \u00b7 ESC cancel{RESET}")

        print()

        if not visible_items:
            if allow_freeform and search_buffer:
                print(f"  {DIM}{freeform_hint}{RESET}")
            else:
                print(f"  {DIM}No matches{RESET}")
        else:
            for i, item in enumerate(display_items):
                # Build display text
                if item.symbol:
                    text = f"{item.color}{item.symbol} {item.label}{RESET}"
                elif item.color:
                    text = f"{item.color}{item.label}{RESET}"
                else:
                    text = item.label

                if item.annotation:
                    text += f" {DIM}{item.annotation}{RESET}"

                if i == selected_idx:
                    print(f"  {GREEN}{BOLD}\u2192 {text}{RESET}")
                else:
                    print(f"    {text}")

            if len(visible_items) > max_display:
                remaining = len(visible_items) - max_display
                print(f"\n  {DIM}... and {remaining} more{RESET}")

        if enable_filter:
            print(f"\n{DIM}{len(visible_items)}/{len(items)} items{RESET}")

        # Read key
        key = get_key(timeout=30.0)
        if key is None:
            continue
        if key == '\x1b':
            return PickerResult()
        elif key in ('\r', '\n'):
            if visible_items:
                return PickerResult(value=visible_items[selected_idx].value)
            elif allow_freeform and search_buffer:
                return PickerResult(value=search_buffer, is_freeform=True)
            return PickerResult()
        elif key == 'UP':
            selected_idx = max(0, selected_idx - 1)
        elif key == 'DOWN':
            if visible_items:
                selected_idx = min(len(visible_items) - 1, selected_idx + 1)
        elif key == '\x7f' and enable_filter:
            search_buffer = search_buffer[:-1]
            selected_idx = 0
        elif enable_filter and isinstance(key, str) and len(key) == 1 and key.isprintable():
            search_buffer += key
            selected_idx = 0


def quick_picker(items, prompt="Select", *, default_index=0):
    """Arrow-key picker for small lists (no fuzzy filtering).

    Thin wrapper around fuzzy_picker() with filtering disabled.
    """
    return fuzzy_picker(
        items, prompt,
        enable_filter=False,
        max_display=len(items) if items else 1,
        default_index=default_index,
    )


def multiselect_picker(items, prompt="Select", *, max_display=20,
                       select_all_default=True):
    """Interactive checkbox picker — Space toggles, Enter confirms.

    Args:
        items: List of PickerItem objects.
        prompt: Title text.
        max_display: Max visible items.
        select_all_default: If True, all items start checked.

    Returns:
        List of selected PickerItem.value values, or [] if cancelled.
    """
    if not items:
        return []

    checked = set(range(len(items))) if select_all_default else set()
    cursor = 0

    while True:
        display_items = items[:max_display]

        sys.stdout.write('\033[2J\033[H')
        print(f"{BOLD}{prompt}{RESET}")
        print(f"{DIM}\u2191\u2193 navigate \u00b7 Space toggle \u00b7"
              f" a all \u00b7 n none \u00b7 Enter confirm \u00b7"
              f" ESC cancel{RESET}\n")

        for i, item in enumerate(display_items):
            box = f"{GREEN}[\u2713]{RESET}" if i in checked else "[ ]"
            text = item.label
            if item.annotation:
                text += f" {DIM}{item.annotation}{RESET}"

            if i == cursor:
                print(f"  {GREEN}\u2192{RESET} {box} {text}")
            else:
                print(f"    {box} {text}")

        if len(items) > max_display:
            remaining = len(items) - max_display
            print(f"\n  {DIM}... and {remaining} more{RESET}")

        print(f"\n{DIM}{len(items)} items \u00b7"
              f" {len(checked)} selected{RESET}")

        key = get_key(timeout=30.0)
        if key is None:
            continue
        if key == '\x1b':
            return []
        if key in ('\r', '\n'):
            return [items[i].value for i in sorted(checked)]
        if key == ' ':
            if cursor in checked:
                checked.discard(cursor)
            else:
                checked.add(cursor)
        elif key == 'UP':
            cursor = max(0, cursor - 1)
        elif key == 'DOWN':
            cursor = min(len(items) - 1, cursor + 1)
        elif key == 'a':
            checked = set(range(len(items)))
        elif key == 'n':
            checked.clear()
