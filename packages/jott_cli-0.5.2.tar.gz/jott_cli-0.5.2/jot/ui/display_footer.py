"""Mode-specific footer rendering for the main task display."""

from jot.core.constants import (
    MODE_QUICK_ADD, MODE_COMMAND, MODE_MULTISELECT, MODE_FUZZY_SEARCH,
    DAY_COLORS, DAY_ABBREVIATIONS,
)
from jot.ui.styles import (
    RESET, BOLD, DIM, CYAN, GREEN, YELLOW,
    get_terminal_width,
)


def render_mode_footer(
        mode, input_buffer, selected_tasks, search_buffer,
        tasks, archived_task_ids, include_archived_in_search,
        show_shortcuts):
    """Render the mode-specific footer at the bottom."""
    if mode == MODE_QUICK_ADD:
        _render_quick_add(input_buffer, show_shortcuts)
    elif mode == MODE_MULTISELECT:
        _render_multiselect(selected_tasks)
    elif mode == MODE_FUZZY_SEARCH:
        _render_fuzzy_search(
            tasks, search_buffer, archived_task_ids,
            include_archived_in_search)
    else:
        _render_command()


def _render_quick_add(input_buffer, show_shortcuts):
    """Render the quick-add mode footer."""
    print(
        f"{GREEN}[QUICK ADD]{RESET} Type task, {BOLD}Enter{RESET} "
        f"to save | {BOLD}/{RESET}: search | {BOLD}ESC{RESET}: "
        f"commands | {BOLD}Shift+V{RESET}: multi-select | "
        f"{BOLD}?{RESET}: shortcuts"
    )
    if show_shortcuts:
        from jot.ui.display_help import display_categorized_shortcuts
        display_categorized_shortcuts()
    print(f"→ {input_buffer}█", end='', flush=True)


def _render_multiselect(selected_tasks):
    """Render the multi-select mode footer."""
    selected_count = len(selected_tasks) if selected_tasks else 0
    print(
        f"{CYAN}{BOLD}[MULTI-SELECT]{RESET} {selected_count} selected "
        f"| {BOLD}Space{RESET}: toggle | {BOLD}B{RESET}: bulk actions "
        f"| {BOLD}ESC{RESET}: exit"
    )
    print(
        f"{CYAN}Navigation:{RESET} {BOLD}↑/↓{RESET}: move | "
        f"{BOLD}Shift+↑/↓{RESET}: select while moving | "
        f"{BOLD}A{RESET}: select all | {BOLD}N{RESET}: select none"
    )
    print("-" * get_terminal_width())


def _render_fuzzy_search(
        tasks, search_buffer, archived_task_ids,
        include_archived_in_search):
    """Render the fuzzy search mode footer with result counts."""
    active_count = sum(
        1 for task in tasks
        if task['id'] not in (archived_task_ids or set()))
    archived_count = len(archived_task_ids or set())

    toggle_status = (
        f"{GREEN}with archives{RESET}"
        if include_archived_in_search
        else f"{DIM}active only{RESET}"
    )

    count_info = ""
    if search_buffer:
        count_info = f" {DIM}({active_count} active"
        if archived_count > 0:
            count_info += f", {archived_count} archived"
        count_info += f"){RESET}"

    print(
        f"{CYAN}{BOLD}[FUZZY SEARCH]{RESET} "
        f"{toggle_status} {search_buffer}█{count_info}"
    )
    print(
        f"{CYAN}Keys:{RESET} Type to filter | {BOLD}↑/↓{RESET}: "
        f"navigate | {BOLD}Enter{RESET}: select | "
        f"{BOLD}Ctrl+A{RESET}: toggle archives | "
        f"{BOLD}ESC{RESET}: cancel"
    )
    print("-" * get_terminal_width())


def _render_command():
    """Render the command mode footer."""
    print(
        f"{YELLOW}[COMMAND]{RESET} Press {BOLD}'a'{RESET} for "
        f"quick-add | {BOLD}'h'{RESET} for help | "
        f"{BOLD}'q'{RESET} to quit"
    )
    print(
        f"Commands: {BOLD}(a){RESET}dd | {BOLD}(c){RESET}urrent "
        f"| {BOLD}(d){RESET}elete | {BOLD}(e){RESET}dit | "
        f"{BOLD}(M){RESET}ove | {BOLD}(r){RESET}efresh | "
        f"{BOLD}(h){RESET}elp | {BOLD}(q){RESET}uit"
    )
    print("-" * get_terminal_width())
    print("Command: ", end='', flush=True)


def render_archived_section(archived_tasks):
    """Render the archived tasks section below the active list."""
    print(f"\n{DIM}{BOLD}--- ARCHIVED ({len(archived_tasks)}) ---{RESET}")
    for task in archived_tasks:
        status = "✓" if task.get('done', False) else " "
        day = task.get('day')
        tally = task.get('tally', 0)

        day_prefix = ""
        if day:
            day_color = DAY_COLORS.get(day, CYAN)
            day_abbrev = DAY_ABBREVIATIONS.get(day, day[:3])
            day_prefix = f"{day_color}[{day_abbrev}]{RESET} "

        tally_suffix = ""
        if tally > 0:
            tally_suffix = f" {DIM}(×{tally}){RESET}"

        print(
            f"{DIM}  [{status}] {task['id']}. "
            f"{day_prefix}{task['text']}{tally_suffix}{RESET}"
        )
    print(f"{DIM}" + "-" * get_terminal_width() + RESET)
