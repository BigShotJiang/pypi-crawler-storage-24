"""Delete mixin — archive, permanent delete, notes export."""

import os
from datetime import datetime


class DeleteMixin:
    """Task removal, archival, and notes preservation."""

    def remove_task(self, task_id):
        """Archive a task by ID and set previous task as current"""
        org_file = self.save_notes_to_org_file(task_id)
        if org_file:
            print(f"\n\u2713 Notes saved to {os.path.basename(org_file)}")

        task_to_archive = None
        task_index = -1

        for i, task in enumerate(self.tasks):
            if task['id'] == task_id:
                task_to_archive = task
                task_index = i
                break

        if not task_to_archive:
            return False

        self.tasks = [t for t in self.tasks if t['id'] != task_id]
        self.archived.append(task_to_archive)

        # Set previous task as current
        if self.tasks:
            for task in self.tasks:
                task['current'] = False
            if task_index == 0:
                self.tasks[0]['current'] = True
            else:
                new_index = min(task_index - 1, len(self.tasks) - 1)
                self.tasks[new_index]['current'] = True

        self._save_tasks()
        return True

    def delete_task_permanently(self, task_id):
        """Permanently delete a task and release its ID for reuse"""
        org_file = self.save_notes_to_org_file(task_id)
        if org_file:
            print(f"\n\u2713 Notes saved to {os.path.basename(org_file)}")

        deleted = False

        original_count = len(self.tasks)
        self.tasks = [t for t in self.tasks if t['id'] != task_id]
        if len(self.tasks) < original_count:
            deleted = True

        original_archived = len(self.archived)
        self.archived = [t for t in self.archived if t['id'] != task_id]
        if len(self.archived) < original_archived:
            deleted = True

        if deleted:
            self.id_manager.release_id(task_id)
            self._save_tasks()
            return True
        return False

    def archive_task(self, task_id):
        """Archive a task by ID (wrapper around remove_task)"""
        return self.remove_task(task_id)

    def save_notes_to_org_file(self, task_id):
        """Save task notes to an org file before deletion.
        Only creates file if task has non-empty notes.

        Returns:
            str: Path to created org file, or None if no notes
        """
        task = None
        for t in self.tasks:
            if t['id'] == task_id:
                task = t
                break
        if not task:
            for t in self.archived:
                if t['id'] == task_id:
                    task = t
                    break

        if not task:
            return None

        notes = task.get('notes', '').strip()
        if not notes:
            return None

        # Format created_at for display
        created_at = task.get('created_at', 'unknown')
        if created_at != 'unknown':
            try:
                created_dt = datetime.fromisoformat(
                    created_at.replace('Z', '+00:00'))
                created_at = created_dt.strftime('%Y-%m-%d %H:%M:%S')
            except Exception:
                pass

        now = datetime.now()
        org_content = (
            f"#+TITLE: Task #{task_id} Notes (Deleted)\n"
            f"#+DATE: {now.strftime('%Y-%m-%d')}\n\n"
            f"* Task Information\n"
            f"  - ID: {task_id}\n"
            f"  - Text: {task['text']}\n"
            f"  - Status: {task.get('status', 'todo')}\n"
            f"  - Priority: {task.get('priority', 'none')}\n"
            f"  - Created: {created_at}\n\n"
            f"* Notes\n{notes}\n\n"
            f"* Metadata\n"
            f"  - Deleted: {now.strftime('%Y-%m-%d %H:%M:%S')}\n"
            f"  - Original file: {self.storage_file.name}\n"
        )

        filename = f"TASK-{task_id}-notes-{now.strftime('%Y%m%d_%H%M%S')}.org"
        org_file_path = self.project_dir / filename

        try:
            with open(org_file_path, 'w') as f:
                f.write(org_content)
            return str(org_file_path)
        except Exception as e:
            print(f"Warning: Could not save notes to org file: {e}")
            return None
