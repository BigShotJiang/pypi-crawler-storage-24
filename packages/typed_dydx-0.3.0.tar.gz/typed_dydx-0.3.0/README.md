# Typed dYdX

> A fully typed, validated async client for the dYdX v4 APIs

**Use autocomplete instead of documentation.**

```python
from dydx import Indexer

async with Indexer.new() as indexer:
  btc = await indexer.data.get_market('BTC-USD')
  print(btc['oraclePrice'])
```

## Why Typed dYdX?

- **🎯 Precise Types**: Strong typing throughout, so your editor can help before runtime does.
- **✅ Automatic Validation**: Catch upstream API changes earlier, where they are easier to debug.
- **⚡ Async First**: Built for concurrent, network-heavy workflows.
- **🔒 Safer Usage**: Typed inputs and explicit errors reduce avoidable mistakes.
- **🎨 Better DX**: Clear routing, sensible defaults, and minimal ceremony.
- **📦 Practical Extras**: Pagination, streams, and helpers where they actually help.

## Package Shape

This package intentionally follows the way dYdX itself is split:

- `Indexer` for HTTP market/account data and WebSocket subaccount streams
- `PublicNode` for public node reads like prices, CLOB pair data, and fee tiers
- `PrivateNode` for signed trading actions like placing and cancelling orders

## Installation

```bash
pip install typed-dydx
```

## Documentation

> [**Read the docs**](https://dydx.tribulnation.com)
