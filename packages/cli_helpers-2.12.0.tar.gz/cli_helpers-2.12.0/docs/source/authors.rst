.. include:: ../../AUTHORS
