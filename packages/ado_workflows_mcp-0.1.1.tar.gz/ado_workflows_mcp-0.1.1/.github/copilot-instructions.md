```instructions
Before starting any task, read and follow the skill-compliance skill.
```
