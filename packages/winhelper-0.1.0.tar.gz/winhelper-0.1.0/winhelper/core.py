import os
import sys
import ctypes
import ctypes.wintypes
import subprocess
import pathlib
import shutil
import tempfile
import json
import datetime
import hashlib
import base64
import socket
import struct
import time
import threading
import queue
import logging
import re
import stat
import fnmatch
import collections
import typing
import functools
import inspect
import traceback
import warnings
import contextlib
import io
import string
import random
import uuid
import platform
import getpass
import glob
import zipfile
import tarfile
import gzip
import bz2
import lzma
import hmac
import secrets
import enum
import dataclasses
import abc
import copy
import weakref
import gc
import mmap
import select
import selectors
import concurrent.futures
import multiprocessing
import signal
import msvcrt
import winsound
import winreg


class WinError(Exception):
    pass


class RegistryError(WinError):
    pass


class ProcessError(WinError):
    pass


class FileError(WinError):
    pass


class NetworkError(WinError):
    pass


class ServiceError(WinError):
    pass


class UserError(WinError):
    pass


class SecurityError(WinError):
    pass


class SystemError(WinError):
    pass


class HKEY(ctypes.c_void_p):
    pass


class WinHelper:
    _instance = None
    _initialized = False
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    def __init__(self):
        if self._initialized:
            return
        self._initialized = True
        self._kernel32 = ctypes.windll.kernel32
        self._user32 = ctypes.windll.user32
        self._advapi32 = ctypes.windll.advapi32
        self._shell32 = ctypes.windll.shell32
        self._ntdll = ctypes.windll.ntdll
        self._ws2_32 = ctypes.windll.ws2_32
        self._handles = []
        self._processes = []
        self._registry_keys = []
        self._lock = threading.Lock()
        self._event_queue = queue.Queue()
        self._callbacks = {}
        self._cache = {}
        self._cache_ttl = 300
        self._log_file = None
        self._log_enabled = False
        self._debug_mode = False
        self._admin_checked = None
        self._windows_version = None
        self._architecture = None
        self._initialize_constants()
        self._setup_logging()
    
    def _initialize_constants(self):
        self.ERROR_SUCCESS = 0
        self.ERROR_FILE_NOT_FOUND = 2
        self.ERROR_PATH_NOT_FOUND = 3
        self.ERROR_ACCESS_DENIED = 5
        self.ERROR_INVALID_HANDLE = 6
        self.ERROR_NOT_ENOUGH_MEMORY = 8
        self.ERROR_INVALID_PARAMETER = 87
        self.ERROR_INSUFFICIENT_BUFFER = 122
        self.ERROR_MORE_DATA = 234
        self.MAX_PATH = 260
        self.MAX_LONG_PATH = 32767
        self.GENERIC_READ = 0x80000000
        self.GENERIC_WRITE = 0x40000000
        self.GENERIC_EXECUTE = 0x20000000
        self.GENERIC_ALL = 0x10000000
        self.FILE_SHARE_READ = 0x00000001
        self.FILE_SHARE_WRITE = 0x00000002
        self.FILE_SHARE_DELETE = 0x00000004
        self.CREATE_NEW = 1
        self.CREATE_ALWAYS = 2
        self.OPEN_EXISTING = 3
        self.OPEN_ALWAYS = 4
        self.TRUNCATE_EXISTING = 5
        self.FILE_ATTRIBUTE_READONLY = 0x00000001
        self.FILE_ATTRIBUTE_HIDDEN = 0x00000002
        self.FILE_ATTRIBUTE_SYSTEM = 0x00000004
        self.FILE_ATTRIBUTE_DIRECTORY = 0x00000010
        self.FILE_ATTRIBUTE_ARCHIVE = 0x00000020
        self.FILE_ATTRIBUTE_NORMAL = 0x00000080
        self.FILE_ATTRIBUTE_TEMPORARY = 0x00000100
        self.FILE_ATTRIBUTE_COMPRESSED = 0x00000800
        self.FILE_ATTRIBUTE_OFFLINE = 0x00001000
        self.FILE_ATTRIBUTE_NOT_CONTENT_INDEXED = 0x00002000
        self.FILE_ATTRIBUTE_ENCRYPTED = 0x00004000
        self.FILE_ATTRIBUTE_INTEGRITY_STREAM = 0x00008000
        self.FILE_ATTRIBUTE_VIRTUAL = 0x00010000
        self.FILE_ATTRIBUTE_NO_SCRUB_DATA = 0x00020000
        self.FILE_ATTRIBUTE_RECALL_ON_OPEN = 0x00040000
        self.FILE_ATTRIBUTE_PINNED = 0x00080000
        self.FILE_ATTRIBUTE_UNPINNED = 0x00100000
        self.FILE_ATTRIBUTE_RECALL_ON_DATA_ACCESS = 0x00400000
        self.INVALID_HANDLE_VALUE = ctypes.c_void_p(-1).value
        self.THREAD_TERMINATE = 0x0001
        self.THREAD_SUSPEND_RESUME = 0x0002
        self.THREAD_GET_CONTEXT = 0x0008
        self.THREAD_SET_CONTEXT = 0x0010
        self.THREAD_QUERY_INFORMATION = 0x0040
        self.THREAD_SET_INFORMATION = 0x0020
        self.PROCESS_TERMINATE = 0x0001
        self.PROCESS_CREATE_THREAD = 0x0002
        self.PROCESS_SET_SESSIONID = 0x0004
        self.PROCESS_VM_OPERATION = 0x0008
        self.PROCESS_VM_READ = 0x0010
        self.PROCESS_VM_WRITE = 0x0020
        self.PROCESS_DUP_HANDLE = 0x0040
        self.PROCESS_CREATE_PROCESS = 0x0080
        self.PROCESS_SET_QUOTA = 0x0100
        self.PROCESS_SET_INFORMATION = 0x0200
        self.PROCESS_QUERY_INFORMATION = 0x0400
        self.PROCESS_SUSPEND_RESUME = 0x0800
        self.PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
        self.STILL_ACTIVE = 259
        self.ABSTRACT = 0x00000000
        self.REALTIME_PRIORITY_CLASS = 0x00000100
        self.HIGH_PRIORITY_CLASS = 0x00000080
        self.ABOVE_NORMAL_PRIORITY_CLASS = 0x00008000
        self.NORMAL_PRIORITY_CLASS = 0x00000020
        self.BELOW_NORMAL_PRIORITY_CLASS = 0x00004000
        self.IDLE_PRIORITY_CLASS = 0x00000040
        self.SERVICE_WIN32_OWN_PROCESS = 0x00000010
        self.SERVICE_WIN32_SHARE_PROCESS = 0x00000020
        self.SERVICE_KERNEL_DRIVER = 0x00000001
        self.SERVICE_FILE_SYSTEM_DRIVER = 0x00000002
        self.SERVICE_INTERACTIVE_PROCESS = 0x00000100
        self.SERVICE_AUTO_START = 0x00000002
        self.SERVICE_BOOT_START = 0x00000000
        self.SERVICE_DEMAND_START = 0x00000003
        self.SERVICE_DISABLED = 0x00000004
        self.SERVICE_SYSTEM_START = 0x00000001
        self.SERVICE_RUNNING = 0x00000004
        self.SERVICE_STOPPED = 0x00000001
        self.SERVICE_START_PENDING = 0x00000002
        self.SERVICE_STOP_PENDING = 0x00000003
        self.SERVICE_CONTINUE_PENDING = 0x00000005
        self.SERVICE_PAUSE_PENDING = 0x00000006
        self.SERVICE_PAUSED = 0x00000007
        self.SERVICE_CONTROL_STOP = 0x00000001
        self.SERVICE_CONTROL_PAUSE = 0x00000002
        self.SERVICE_CONTROL_CONTINUE = 0x00000003
        self.SERVICE_CONTROL_INTERROGATE = 0x00000004
        self.SERVICE_CONTROL_SHUTDOWN = 0x00000005
        self.SERVICE_ALL_ACCESS = 0xF003F
        self.SC_MANAGER_CONNECT = 0x0001
        self.SC_MANAGER_CREATE_SERVICE = 0x0002
        self.SC_MANAGER_ENUMERATE_SERVICE = 0x0004
        self.SC_MANAGER_LOCK = 0x0008
        self.SC_MANAGER_QUERY_LOCK_STATUS = 0x0010
        self.SC_MANAGER_MODIFY_BOOT_CONFIG = 0x0020
        self.SC_MANAGER_ALL_ACCESS = 0xF003F
        self.HKEY_CLASSES_ROOT = ctypes.c_void_p(0x80000000)
        self.HKEY_CURRENT_USER = ctypes.c_void_p(0x80000001)
        self.HKEY_LOCAL_MACHINE = ctypes.c_void_p(0x80000002)
        self.HKEY_USERS = ctypes.c_void_p(0x80000003)
        self.HKEY_PERFORMANCE_DATA = ctypes.c_void_p(0x80000004)
        self.HKEY_CURRENT_CONFIG = ctypes.c_void_p(0x80000005)
        self.HKEY_DYN_DATA = ctypes.c_void_p(0x80000006)
        self.REG_NONE = 0
        self.REG_SZ = 1
        self.REG_EXPAND_SZ = 2
        self.REG_BINARY = 3
        self.REG_DWORD = 4
        self.REG_DWORD_LITTLE_ENDIAN = 4
        self.REG_DWORD_BIG_ENDIAN = 5
        self.REG_LINK = 6
        self.REG_MULTI_SZ = 7
        self.REG_RESOURCE_LIST = 8
        self.REG_FULL_RESOURCE_DESCRIPTOR = 9
        self.REG_RESOURCE_REQUIREMENTS_LIST = 10
        self.REG_QWORD = 11
        self.KEY_QUERY_VALUE = 0x0001
        self.KEY_SET_VALUE = 0x0002
        self.KEY_CREATE_SUB_KEY = 0x0004
        self.KEY_ENUMERATE_SUB_KEYS = 0x0008
        self.KEY_NOTIFY = 0x0010
        self.KEY_CREATE_LINK = 0x0020
        self.KEY_READ = 0x20019
        self.KEY_WRITE = 0x20006
        self.KEY_EXECUTE = 0x20019
        self.KEY_ALL_ACCESS = 0xF003F
        self.EVENTLOG_SUCCESS = 0x0000
        self.EVENTLOG_ERROR_TYPE = 0x0001
        self.EVENTLOG_WARNING_TYPE = 0x0002
        self.EVENTLOG_INFORMATION_TYPE = 0x0004
        self.EVENTLOG_AUDIT_SUCCESS = 0x0008
        self.EVENTLOG_AUDIT_FAILURE = 0x0010
        self.SE_PRIVILEGE_ENABLED = 0x00000002
        self.SE_PRIVILEGE_ENABLED_BY_DEFAULT = 0x00000001
        self.SE_PRIVILEGE_REMOVED = 0x00000004
        self.SE_PRIVILEGE_USED_FOR_ACCESS = 0x80000000
        self.TOKEN_ASSIGN_PRIMARY = 0x0001
        self.TOKEN_DUPLICATE = 0x0002
        self.TOKEN_IMPERSONATE = 0x0004
        self.TOKEN_QUERY = 0x0008
        self.TOKEN_QUERY_SOURCE = 0x0010
        self.TOKEN_ADJUST_PRIVILEGES = 0x0020
        self.TOKEN_ADJUST_GROUPS = 0x0040
        self.TOKEN_ADJUST_DEFAULT = 0x0080
        self.TOKEN_ADJUST_SESSIONID = 0x0100
        self.TOKEN_ALL_ACCESS = 0xF00FF
        self.TOKEN_READ = 0x20008
        self.TOKEN_WRITE = 0x200E0
        self.TOKEN_EXECUTE = 0x20008
        self.WAIT_OBJECT_0 = 0
        self.WAIT_ABANDONED = 0x00000080
        self.WAIT_TIMEOUT = 0x00000102
        self.WAIT_FAILED = 0xFFFFFFFF
        self.INFINITE = 0xFFFFFFFF
        self.SW_HIDE = 0
        self.SW_SHOWNORMAL = 1
        self.SW_SHOWMINIMIZED = 2
        self.SW_SHOWMAXIMIZED = 3
        self.SW_SHOWNOACTIVATE = 4
        self.SW_SHOW = 5
        self.SW_MINIMIZE = 6
        self.SW_SHOWMINNOACTIVE = 7
        self.SW_SHOWNA = 8
        self.SW_RESTORE = 9
        self.SW_SHOWDEFAULT = 10
        self.SW_FORCEMINIMIZE = 11
        self.CW_HIDE = 0x0000
        self.CW_SHOWNORMAL = 0x0001
        self.CW_SHOWMINIMIZED = 0x0002
        self.CW_SHOWMAXIMIZED = 0x0003
        self.CW_SHOWNOACTIVATE = 0x0004
        self.CW_SHOW = 0x0005
        self.CW_MINIMIZE = 0x0006
        self.CW_SHOWMINNOACTIVE = 0x0007
        self.CW_SHOWNA = 0x0008
        self.CW_RESTORE = 0x0009
        self.CW_SHOWDEFAULT = 0x000A
        self.CW_FORCEMINIMIZE = 0x000B
        self.MB_OK = 0x00000000
        self.MB_OKCANCEL = 0x00000001
        self.MB_ABORTRETRYIGNORE = 0x00000002
        self.MB_YESNOCANCEL = 0x00000003
        self.MB_YESNO = 0x00000004
        self.MB_RETRYCANCEL = 0x00000005
        self.MB_CANCELTRYCONTINUE = 0x00000006
        self.MB_ICONHAND = 0x00000010
        self.MB_ICONQUESTION = 0x00000020
        self.MB_ICONEXCLAMATION = 0x00000030
        self.MB_ICONASTERISK = 0x00000040
        self.MB_USERICON = 0x00000080
        self.MB_ICONWARNING = 0x00000030
        self.MB_ICONERROR = 0x00000010
        self.MB_ICONINFORMATION = 0x00000040
        self.MB_ICONSTOP = 0x00000010
        self.MB_DEFBUTTON1 = 0x00000000
        self.MB_DEFBUTTON2 = 0x00000100
        self.MB_DEFBUTTON3 = 0x00000200
        self.MB_DEFBUTTON4 = 0x00000300
        self.MB_APPLMODAL = 0x00000000
        self.MB_SYSTEMMODAL = 0x00001000
        self.MB_TASKMODAL = 0x00002000
        self.MB_HELP = 0x00004000
        self.MB_NOFOCUS = 0x00008000
        self.MB_SETFOREGROUND = 0x00010000
        self.MB_DEFAULT_DESKTOP_ONLY = 0x00020000
        self.MB_TOPMOST = 0x00040000
        self.MB_RIGHT = 0x00080000
        self.MB_RTLREADING = 0x00100000
        self.MB_SERVICE_NOTIFICATION = 0x00200000
        self.IDOK = 1
        self.IDCANCEL = 2
        self.IDABORT = 3
        self.IDRETRY = 4
        self.IDIGNORE = 5
        self.IDYES = 6
        self.IDNO = 7
        self.IDCLOSE = 8
        self.IDHELP = 9
        self.IDTRYAGAIN = 10
        self.IDCONTINUE = 11
        self.IDTIMEOUT = 32000
        self.SW_NORMAL = 1
        self.SW_MINIMIZE = 6
        self.SW_RESTORE = 9
        self.SW_SHOW = 5
        self.SW_SHOWMAXIMIZED = 3
        self.SW_SHOWMINIMIZED = 2
        self.SW_SHOWMINNOACTIVE = 7
        self.SW_SHOWNA = 8
        self.SW_SHOWNOACTIVATE = 4
        self.SW_SHOWNORMAL = 1
        self.AF_INET = 2
        self.AF_INET6 = 23
        self.SOCK_STREAM = 1
        self.SOCK_DGRAM = 2
        self.SOCK_RAW = 3
        self.IPPROTO_IP = 0
        self.IPPROTO_ICMP = 1
        self.IPPROTO_TCP = 6
        self.IPPROTO_UDP = 17
        self.IPPROTO_IPV6 = 41
        self.IPPROTO_ICMPV6 = 58
        self.SOL_SOCKET = 0xFFFF
        self.SO_DEBUG = 0x0001
        self.SO_ACCEPTCONN = 0x0002
        self.SO_REUSEADDR = 0x0004
        self.SO_KEEPALIVE = 0x0008
        self.SO_DONTROUTE = 0x0010
        self.SO_BROADCAST = 0x0020
        self.SO_USELOOPBACK = 0x0040
        self.SO_LINGER = 0x0080
        self.SO_OOBINLINE = 0x0100
        self.SO_DONTLINGER = 0xFFFFFF7F
        self.SO_EXCLUSIVEADDRUSE = 0x0005
        self.SO_SNDBUF = 0x1001
        self.SO_RCVBUF = 0x1002
        self.SO_SNDLOWAT = 0x1003
        self.SO_RCVLOWAT = 0x1004
        self.SO_SNDTIMEO = 0x1005
        self.SO_RCVTIMEO = 0x1006
        self.SO_ERROR = 0x1007
        self.SO_TYPE = 0x1008
        self.SO_UPDATE_CONNECT_CONTEXT = 0x7010
        self.SO_UPDATE_ACCEPT_CONTEXT = 0x700B
        self.SO_CONNECT_TIME = 0x700C
        self.SO_CONDITIONAL_ACCEPT = 0x7011
        self.SO_PAUSE_ACCEPT = 0x7012
        self.SO_COMPARTMENT_ID = 0x7013
        self.SO_RANDOMIZE_PORT = 0x7014
        self.SO_PORT_SCALABILITY = 0x7015
        self.SO_CONSECUTIVE_CONNECT_ATTEMPTS = 0x7016
        self.SO_MAX_MSG_SIZE = 0x2003
        self.SO_MAX_PATH_MTU = 0x3005
        self.SO_MTU = 0x3006
        self.SO_MAXPATHMTU = 0x3005
        self.IP_OPTIONS = 1
        self.IP_HDRINCL = 2
        self.IP_TOS = 3
        self.IP_TTL = 4
        self.IP_MULTICAST_IF = 9
        self.IP_MULTICAST_TTL = 10
        self.IP_MULTICAST_LOOP = 11
        self.IP_ADD_MEMBERSHIP = 12
        self.IP_DROP_MEMBERSHIP = 13
        self.IP_DONTFRAGMENT = 14
        self.IP_ADD_SOURCE_MEMBERSHIP = 15
        self.IP_DROP_SOURCE_MEMBERSHIP = 16
        self.IP_BLOCK_SOURCE = 17
        self.IP_UNBLOCK_SOURCE = 18
        self.IP_PKTINFO = 19
        self.IP_HOPLIMIT = 21
        self.IP_PROTECTION_LEVEL = 25
        self.IP_RECVIF = 20
        self.IP_RECVDSTADDR = 25
        self.IPV6_UNICAST_HOPS = 4
        self.IPV6_MULTICAST_IF = 9
        self.IPV6_MULTICAST_HOPS = 10
        self.IPV6_MULTICAST_LOOP = 11
        self.IPV6_ADD_MEMBERSHIP = 12
        self.IPV6_DROP_MEMBERSHIP = 13
        self.IPV6_JOIN_GROUP = 12
        self.IPV6_LEAVE_GROUP = 13
        self.IPV6_PKTINFO = 19
        self.IPV6_HOPLIMIT = 21
        self.IPV6_PROTECTION_LEVEL = 23
        self.IPV6_V6ONLY = 27
        self.IPV6_IFLIST = 28
        self.IPV6_RECVIF = 32
        self.IPV6_RECVDSTADDR = 33
        self.IPV6_HDRINCL = 2
        self.IPV6_IPSEC_POLICY = 34
        self.IPV6_ECN = 35
        self.TCP_NODELAY = 0x0001
        self.TCP_EXPEDITED_1122 = 0x0002
        self.TCP_KEEPALIVE = 3
        self.TCP_MAXSEG = 4
        self.TCP_MAXRT = 5
        self.TCP_STDURG = 6
        self.TCP_NOURG = 7
        self.TCP_ATMARK = 8
        self.TCP_NOSYNRETRIES = 9
        self.TCP_TIMESTAMPS = 10
        self.TCP_OFFLOAD_PREFERENCE = 11
        self.TCP_CONGESTION_ALGORITHM = 12
        self.TCP_DELAY_FIN_ACK = 13
        self.TCP_MAXRTMS = 14
        self.TCP_FASTOPEN = 15
        self.TCP_KEEPCNT = 16
        self.TCP_KEEPIDLE = 17
        self.TCP_KEEPINTVL = 18
        self.TCP_FAIL_CONNECT_ON_ICMP_ERROR = 19
        self.TCP_ICMP_ERROR_INFO = 20
        self.TCP_SYN_ATTACK_PROTECT = 21
        self.TCP_DISABLE_AUTO_TUNING = 22
        self.TCP_ENABLE_ECN = 23
        self.TCP_WINDOW_SCALE = 24
        self.TCP_TIMESTAMP = 25
        self.TCP_SACK = 26
        self.TCP_RTT_VAR = 27
        self.TCP_SPEED = 28
        self.TCP_NAGLE = 29
        self.TCP_BPF = 30
        self.TCP_CC_INFO = 31
        self.TCP_ULP = 32
        self.TCP_MD5SIG = 33
        self.TCP_THIN_LINEAR_TIMEOUTS = 34
        self.TCP_THIN_DUPACK = 35
        self.TCP_USER_TIMEOUT = 36
        self.TCP_REPAIR = 37
        self.TCP_REPAIR_QUEUE = 38
        self.TCP_QUEUE_SEQ = 39
        self.TCP_REPAIR_OPTIONS = 40
        self.TCP_FASTKEY = 41
        self.TCP_REPAIR_WINDOW = 42
        self.TCP_ZEROCOPY_RECEIVE = 43
        self.TCP_NOTSENT_LOWAT = 44
        self.TCP_CC_CONGCTL = 45
        self.TCP_BPF_MODIFY = 46
        self.TCP_BPF_POLL = 47
        self.TCP_BPF_BIND = 48
        self.TCP_BPF_CONNECT = 49
        self.TCP_BPF_LISTEN = 50
        self.TCP_BPF_ACCEPT = 51
        self.TCP_BPF_CLOSE = 52
        self.TCP_BPF_SHUTDOWN = 53
        self.TCP_BPF_GETSOCKOPT = 54
        self.TCP_BPF_SETSOCKOPT = 55
        self.TCP_BPF_GETPEERNAME = 56
        self.TCP_BPF_GETSOCKNAME = 57
        self.TCP_BPF_GETTIMEOFDAY = 58
        self.TCP_BPF_GETCPUID = 59
        self.TCP_BPF_GETPID = 60
        self.TCP_BPF_GETUID = 61
        self.TCP_BPF_GETGID = 62
        self.TCP_BPF_GETEUID = 63
        self.TCP_BPF_GETEGID = 64
        self.TCP_BPF_GETPGRP = 65
        self.TCP_BPF_GETSID = 66
        self.TCP_BPF_GETPGID = 67
        self.TCP_BPF_GETPPID = 68
        self.TCP_BPF_GETTID = 69
        self.TCP_BPF_GETTGID = 70
        self.TCP_BPF_GETNSPID = 71
        self.TCP_BPF_GETNSPGID = 72
        self.TCP_BPF_GETNSSID = 73
        self.TCP_BPF_GETNSUID = 74
        self.TCP_BPF_GETNSGID = 75
        self.TCP_BPF_GETNSEUID = 76
        self.TCP_BPF_GETNSEGID = 77
        self.TCP_BPF_GETNSPGRP = 78
        self.TCP_BPF_GETNSPPID = 79
        self.TCP_BPF_GETNSTID = 80
        self.TCP_BPF_GETNSTGID = 81
        self.WSADESCRIPTION_LEN = 256
        self.WSASYS_STATUS_LEN = 128
        self.WSABASEERR = 10000
        self.WSAEINTR = 10004
        self.WSAEBADF = 10009
        self.WSAEACCES = 10013
        self.WSAEFAULT = 10014
        self.WSAEINVAL = 10022
        self.WSAEMFILE = 10024
        self.WSAEWOULDBLOCK = 10035
        self.WSAEINPROGRESS = 10036
        self.WSAEALREADY = 10037
        self.WSAENOTSOCK = 10038
        self.WSAEDESTADDRREQ = 10039
        self.WSAEMSGSIZE = 10040
        self.WSAEPROTOTYPE = 10041
        self.WSAENOPROTOOPT = 10042
        self.WSAEPROTONOSUPPORT = 10043
        self.WSAESOCKTNOSUPPORT = 10044
        self.WSAEOPNOTSUPP = 10045
        self.WSAEPFNOSUPPORT = 10046
        self.WSAEAFNOSUPPORT = 10047
        self.WSAEADDRINUSE = 10048
        self.WSAEADDRNOTAVAIL = 10049
        self.WSAENETDOWN = 10050
        self.WSAENETUNREACH = 10051
        self.WSAENETRESET = 10052
        self.WSAECONNABORTED = 10053
        self.WSAECONNRESET = 10054
        self.WSAENOBUFS = 10055
        self.WSAEISCONN = 10056
        self.WSAENOTCONN = 10057
        self.WSAESHUTDOWN = 10058
        self.WSAETOOMANYREFS = 10059
        self.WSAETIMEDOUT = 10060
        self.WSAECONNREFUSED = 10061
        self.WSAELOOP = 10062
        self.WSAENAMETOOLONG = 10063
        self.WSAEHOSTDOWN = 10064
        self.WSAEHOSTUNREACH = 10065
        self.WSAENOTEMPTY = 10066
        self.WSAEPROCLIM = 10067
        self.WSAEUSERS = 10068
        self.WSAEDQUOT = 10069
        self.WSAESTALE = 10070
        self.WSAEREMOTE = 10071
        self.WSASYSNOTREADY = 10091
        self.WSAVERNOTSUPPORTED = 10092
        self.WSANOTINITIALISED = 10093
        self.WSAEDISCON = 10101
        self.WSAENOMORE = 10102
        self.WSAECANCELLED = 10103
        self.WSAEINVALIDPROCTABLE = 10104
        self.WSAEINVALIDPROVIDER = 10105
        self.WSAEPROVIDERFAILEDINIT = 10106
        self.WSASYSCALLFAILURE = 10107
        self.WSASERVICE_NOT_FOUND = 10108
        self.WSATYPE_NOT_FOUND = 10109
        self.WSA_E_NO_MORE = 10110
        self.WSA_E_CANCELLED = 10111
        self.WSAEREFUSED = 10112
        self.WSAHOST_NOT_FOUND = 11001
        self.WSATRY_AGAIN = 11002
        self.WSANORECOVERY = 11003
        self.WSANO_DATA = 11004
        self.WSA_QOS_RECEIVERS = 11005
        self.WSA_QOS_SENDERS = 11006
        self.WSA_QOS_NO_SENDERS = 11007
        self.WSA_QOS_NO_RECEIVERS = 11008
        self.WSA_QOS_REQUEST_CONFIRMED = 11009
        self.WSA_QOS_ADMISSION_FAILURE = 11010
        self.WSA_QOS_POLICY_FAILURE = 11011
        self.WSA_QOS_BAD_STYLE = 11012
        self.WSA_QOS_BAD_OBJECT = 11013
        self.WSA_QOS_TRAFFIC_CTRL_ERROR = 11014
        self.WSA_QOS_GENERIC_ERROR = 11015
        self.WSA_QOS_ESERVICETYPE = 11016
        self.WSA_QOS_EFLOWSPEC = 11017
        self.WSA_QOS_EPROVSPECBUF = 11018
        self.WSA_QOS_EFILTERSTYLE = 11019
        self.WSA_QOS_EFILTERTYPE = 11020
        self.WSA_QOS_EFILTERCOUNT = 11021
        self.WSA_QOS_EOBJLENGTH = 11022
        self.WSA_QOS_EFLOWCOUNT = 11023
        self.WSA_QOS_EUNKOWNPSOBJ = 11024
        self.WSA_QOS_EPOLICYOBJ = 11025
        self.WSA_QOS_EFLOWDESC = 11026
        self.WSA_QOS_EPSFLOWSPEC = 11027
        self.WSA_QOS_EPSFILTERSPEC = 11028
        self.WSA_QOS_ESDMODEOBJ = 11029
        self.WSA_QOS_ESHAPERATEOBJ = 11030
        self.WSA_QOS_RESERVED_PETYPE = 11031
    
    def _setup_logging(self):
        self._logger = logging.getLogger("WinHelper")
        self._logger.setLevel(logging.DEBUG)
        handler = logging.StreamHandler()
        handler.setLevel(logging.INFO)
        formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
        handler.setFormatter(formatter)
        self._logger.addHandler(handler)
    
    def _log(self, level, message):
        if self._log_enabled:
            self._logger.log(level, message)
    
    def _get_last_error(self):
        return ctypes.get_last_error()
    
    def _format_error(self, error_code):
        buffer = ctypes.create_unicode_buffer(1024)
        self._kernel32.FormatMessageW(
            0x00001000 | 0x00002000,
            None,
            error_code,
            0,
            buffer,
            len(buffer),
            None
        )
        return buffer.value.strip()
    
    def _check_result(self, result, error_message="Operation failed"):
        if result == 0 or result == self.INVALID_HANDLE_VALUE:
            error_code = self._get_last_error()
            raise WinError(f"{error_message}: {self._format_error(error_code)} (Error {error_code})")
        return result
    
    def _cache_get(self, key):
        if key in self._cache:
            entry = self._cache[key]
            if time.time() - entry["timestamp"] < self._cache_ttl:
                return entry["value"]
            del self._cache[key]
        return None
    
    def _cache_set(self, key, value):
        self._cache[key] = {"value": value, "timestamp": time.time()}
    
    def _cache_clear(self):
        self._cache.clear()
    
    def _cache_cleanup(self):
        now = time.time()
        expired = [k for k, v in self._cache.items() if now - v["timestamp"] >= self._cache_ttl]
        for key in expired:
            del self._cache[key]
    
    def enable_logging(self, log_file=None):
        self._log_enabled = True
        if log_file:
            file_handler = logging.FileHandler(log_file)
            file_handler.setLevel(logging.DEBUG)
            file_handler.setFormatter(logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s"))
            self._logger.addHandler(file_handler)
            self._log_file = log_file
    
    def disable_logging(self):
        self._log_enabled = False
    
    def set_debug_mode(self, enabled):
        self._debug_mode = enabled
    
    def is_admin(self):
        if self._admin_checked is not None:
            return self._admin_checked
        try:
            result = ctypes.windll.shell32.IsUserAnAdmin()
            self._admin_checked = bool(result)
            return self._admin_checked
        except Exception:
            self._admin_checked = False
            return False
    
    def run_as_admin(self, executable, arguments=None, wait=True):
        if arguments is None:
            arguments = []
        if isinstance(arguments, str):
            arguments = [arguments]
        params = " ".join([executable] + arguments)
        result = ctypes.windll.shell32.ShellExecuteW(
            None,
            "runas",
            executable,
            params,
            None,
            self.SW_SHOWNORMAL
        )
        if result <= 32:
            raise ProcessError(f"Failed to run as admin: {result}")
        if wait:
            time.sleep(0.5)
        return result
    
    def get_windows_version(self):
        if self._windows_version is not None:
            return self._windows_version
        try:
            version = platform.version()
            release = platform.release()
            self._windows_version = {"version": version, "release": release}
            return self._windows_version
        except Exception:
            return {"version": "unknown", "release": "unknown"}
    
    def get_architecture(self):
        if self._architecture is not None:
            return self._architecture
        try:
            arch = platform.machine()
            self._architecture = arch
            return self._architecture
        except Exception:
            return "unknown"
    
    def get_system_info(self):
        class SYSTEM_INFO(ctypes.Structure):
            _fields_ = [
                ("wProcessorArchitecture", ctypes.c_ushort),
                ("wReserved", ctypes.c_ushort),
                ("dwPageSize", ctypes.c_ulong),
                ("lpMinimumApplicationAddress", ctypes.c_void_p),
                ("lpMaximumApplicationAddress", ctypes.c_void_p),
                ("dwActiveProcessorMask", ctypes.c_ulong),
                ("dwNumberOfProcessors", ctypes.c_ulong),
                ("dwProcessorType", ctypes.c_ulong),
                ("dwAllocationGranularity", ctypes.c_ulong),
                ("wProcessorLevel", ctypes.c_ushort),
                ("wProcessorRevision", ctypes.c_ushort),
            ]
        sys_info = SYSTEM_INFO()
        self._kernel32.GetSystemInfo(ctypes.byref(sys_info))
        return {
            "processor_architecture": sys_info.wProcessorArchitecture,
            "page_size": sys_info.dwPageSize,
            "min_address": sys_info.lpMinimumApplicationAddress,
            "max_address": sys_info.lpMaximumApplicationAddress,
            "active_processor_mask": sys_info.dwActiveProcessorMask,
            "number_of_processors": sys_info.dwNumberOfProcessors,
            "processor_type": sys_info.dwProcessorType,
            "allocation_granularity": sys_info.dwAllocationGranularity,
            "processor_level": sys_info.wProcessorLevel,
            "processor_revision": sys_info.wProcessorRevision,
        }
    
    def get_memory_info(self):
        class MEMORYSTATUSEX(ctypes.Structure):
            _fields_ = [
                ("dwLength", ctypes.c_ulong),
                ("dwMemoryLoad", ctypes.c_ulong),
                ("ullTotalPhys", ctypes.c_ulonglong),
                ("ullAvailPhys", ctypes.c_ulonglong),
                ("ullTotalPageFile", ctypes.c_ulonglong),
                ("ullAvailPageFile", ctypes.c_ulonglong),
                ("ullTotalVirtual", ctypes.c_ulonglong),
                ("ullAvailVirtual", ctypes.c_ulonglong),
                ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
            ]
        mem_status = MEMORYSTATUSEX()
        mem_status.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
        self._kernel32.GlobalMemoryStatusEx(ctypes.byref(mem_status))
        return {
            "memory_load": mem_status.dwMemoryLoad,
            "total_physical": mem_status.ullTotalPhys,
            "available_physical": mem_status.ullAvailPhys,
            "total_page_file": mem_status.ullTotalPageFile,
            "available_page_file": mem_status.ullAvailPageFile,
            "total_virtual": mem_status.ullTotalVirtual,
            "available_virtual": mem_status.ullAvailVirtual,
        }
    
    def get_disk_info(self, drive=None):
        if drive is None:
            drive = "C:\\"
        free_bytes = ctypes.c_ulonglong()
        total_bytes = ctypes.c_ulonglong()
        total_free_bytes = ctypes.c_ulonglong()
        self._kernel32.GetDiskFreeSpaceExW(
            ctypes.c_wchar_p(drive),
            ctypes.byref(free_bytes),
            ctypes.byref(total_bytes),
            ctypes.byref(total_free_bytes)
        )
        return {
            "drive": drive,
            "free_bytes": free_bytes.value,
            "total_bytes": total_bytes.value,
            "total_free_bytes": total_free_bytes.value,
        }
    
    def get_all_drives(self):
        drives = []
        drive_bits = self._kernel32.GetLogicalDrives()
        for i in range(26):
            if drive_bits & (1 << i):
                drives.append(chr(65 + i) + ":\\")
        return drives
    
    def get_cpu_info(self):
        class CPU_INFO(ctypes.Structure):
            _fields_ = [
                ("cpuid", ctypes.c_uint),
                ("eax", ctypes.c_uint),
                ("ebx", ctypes.c_uint),
                ("ecx", ctypes.c_uint),
                ("edx", ctypes.c_uint),
            ]
        cpu_info = {}
        try:
            import ctypes
            cpu_info["processor_count"] = multiprocessing.cpu_count()
            cpu_info["processor_name"] = platform.processor()
        except Exception:
            cpu_info["processor_count"] = 1
            cpu_info["processor_name"] = "unknown"
        return cpu_info
    
    def get_network_info(self):
        network_info = {}
        try:
            hostname = socket.gethostname()
            network_info["hostname"] = hostname
            try:
                ip_address = socket.gethostbyname(hostname)
                network_info["ip_address"] = ip_address
            except Exception:
                network_info["ip_address"] = "unknown"
        except Exception:
            network_info["hostname"] = "unknown"
            network_info["ip_address"] = "unknown"
        return network_info
    
    def get_user_info(self):
        return {
            "username": getpass.getuser(),
            "home": os.path.expanduser("~"),
            "computer_name": os.environ.get("COMPUTERNAME", "unknown"),
            "user_domain": os.environ.get("USERDOMAIN", "unknown"),
        }
    
    def get_environment_variables(self):
        return dict(os.environ)
    
    def get_environment_variable(self, name):
        return os.environ.get(name)
    
    def set_environment_variable(self, name, value):
        os.environ[name] = value
    
    def delete_environment_variable(self, name):
        if name in os.environ:
            del os.environ[name]
    
    def get_current_directory(self):
        return os.getcwd()
    
    def set_current_directory(self, path):
        os.chdir(path)
    
    def get_temp_directory(self):
        return tempfile.gettempdir()
    
    def create_temp_file(self, suffix="", prefix="tmp", dir=None):
        fd, path = tempfile.mkstemp(suffix=suffix, prefix=prefix, dir=dir)
        os.close(fd)
        return path
    
    def create_temp_directory(self, suffix="", prefix="tmp", dir=None):
        return tempfile.mkdtemp(suffix=suffix, prefix=prefix, dir=dir)
    
    def delete_temp_file(self, path):
        if os.path.exists(path):
            os.remove(path)
    
    def delete_temp_directory(self, path):
        if os.path.exists(path):
            shutil.rmtree(path)
    
    def file_exists(self, path):
        return os.path.isfile(path)
    
    def directory_exists(self, path):
        return os.path.isdir(path)
    
    def path_exists(self, path):
        return os.path.exists(path)
    
    def is_absolute_path(self, path):
        return os.path.isabs(path)
    
    def is_relative_path(self, path):
        return not os.path.isabs(path)
    
    def join_path(self, *paths):
        return os.path.join(*paths)
    
    def normalize_path(self, path):
        return os.path.normpath(path)
    
    def absolute_path(self, path):
        return os.path.abspath(path)
    
    def relative_path(self, path, start=None):
        return os.path.relpath(path, start)
    
    def split_path(self, path):
        return os.path.split(path)
    
    def split_extension(self, path):
        return os.path.splitext(path)
    
    def get_file_name(self, path):
        return os.path.basename(path)
    
    def get_directory_name(self, path):
        return os.path.dirname(path)
    
    def get_file_extension(self, path):
        return os.path.splitext(path)[1]
    
    def get_file_size(self, path):
        return os.path.getsize(path)
    
    def get_file_creation_time(self, path):
        return os.path.getctime(path)
    
    def get_file_modification_time(self, path):
        return os.path.getmtime(path)
    
    def get_file_access_time(self, path):
        return os.path.getatime(path)
    
    def format_timestamp(self, timestamp):
        return datetime.datetime.fromtimestamp(timestamp).strftime("%Y-%m-%d %H:%M:%S")
    
    def create_directory(self, path, parents=False, exist_ok=False):
        if parents:
            os.makedirs(path, exist_ok=exist_ok)
        else:
            os.mkdir(path)
    
    def delete_directory(self, path, recursive=False):
        if recursive:
            shutil.rmtree(path)
        else:
            os.rmdir(path)
    
    def delete_file(self, path):
        os.remove(path)
    
    def move_file(self, src, dst):
        shutil.move(src, dst)
    
    def copy_file(self, src, dst, follow_symlinks=True):
        shutil.copy2(src, dst) if follow_symlinks else shutil.copy(src, dst)
    
    def copy_directory(self, src, dst, symlinks=False, ignore=None, copy_function=shutil.copy2, ignore_dangling_symlinks=False):
        shutil.copytree(src, dst, symlinks=symlinks, ignore=ignore, copy_function=copy_function, ignore_dangling_symlinks=ignore_dangling_symlinks)
    
    def list_directory(self, path):
        return os.listdir(path)
    
    def walk_directory(self, path, topdown=True, onerror=None, followlinks=False):
        return os.walk(path, topdown=topdown, onerror=onerror, followlinks=followlinks)
    
    def glob_files(self, path, recursive=False):
        return glob.glob(path, recursive=recursive)
    
    def match_files(self, files, pattern):
        return fnmatch.filter(files, pattern)
    
    def read_file(self, path, encoding="utf-8"):
        with open(path, "r", encoding=encoding) as f:
            return f.read()
    
    def write_file(self, path, content, encoding="utf-8"):
        with open(path, "w", encoding=encoding) as f:
            f.write(content)
    
    def read_file_binary(self, path):
        with open(path, "rb") as f:
            return f.read()
    
    def write_file_binary(self, path, content):
        with open(path, "wb") as f:
            f.write(content)
    
    def read_file_lines(self, path, encoding="utf-8"):
        with open(path, "r", encoding=encoding) as f:
            return f.readlines()
    
    def write_file_lines(self, path, lines, encoding="utf-8"):
        with open(path, "w", encoding=encoding) as f:
            f.writelines(lines)
    
    def append_file(self, path, content, encoding="utf-8"):
        with open(path, "a", encoding=encoding) as f:
            f.write(content)
    
    def truncate_file(self, path, size=0):
        with open(path, "r+") as f:
            f.truncate(size)
    
    def get_file_attributes(self, path):
        return ctypes.windll.kernel32.GetFileAttributesW(ctypes.c_wchar_p(path))
    
    def set_file_attributes(self, path, attributes):
        result = ctypes.windll.kernel32.SetFileAttributesW(ctypes.c_wchar_p(path), attributes)
        if result == 0:
            raise FileError(f"Failed to set file attributes: {self._format_error(self._get_last_error())}")
    
    def set_file_readonly(self, path, readonly=True):
        current = self.get_file_attributes(path)
        if readonly:
            new_attrs = current | self.FILE_ATTRIBUTE_READONLY
        else:
            new_attrs = current & ~self.FILE_ATTRIBUTE_READONLY
        self.set_file_attributes(path, new_attrs)
    
    def set_file_hidden(self, path, hidden=True):
        current = self.get_file_attributes(path)
        if hidden:
            new_attrs = current | self.FILE_ATTRIBUTE_HIDDEN
        else:
            new_attrs = current & ~self.FILE_ATTRIBUTE_HIDDEN
        self.set_file_attributes(path, new_attrs)
    
    def set_file_system(self, path, system=True):
        current = self.get_file_attributes(path)
        if system:
            new_attrs = current | self.FILE_ATTRIBUTE_SYSTEM
        else:
            new_attrs = current & ~self.FILE_ATTRIBUTE_SYSTEM
        self.set_file_attributes(path, new_attrs)
    
    def set_file_archive(self, path, archive=True):
        current = self.get_file_attributes(path)
        if archive:
            new_attrs = current | self.FILE_ATTRIBUTE_ARCHIVE
        else:
            new_attrs = current & ~self.FILE_ATTRIBUTE_ARCHIVE
        self.set_file_attributes(path, new_attrs)
    
    def is_file_readonly(self, path):
        attrs = self.get_file_attributes(path)
        return bool(attrs & self.FILE_ATTRIBUTE_READONLY)
    
    def is_file_hidden(self, path):
        attrs = self.get_file_attributes(path)
        return bool(attrs & self.FILE_ATTRIBUTE_HIDDEN)
    
    def is_file_system(self, path):
        attrs = self.get_file_attributes(path)
        return bool(attrs & self.FILE_ATTRIBUTE_SYSTEM)
    
    def is_file_archive(self, path):
        attrs = self.get_file_attributes(path)
        return bool(attrs & self.FILE_ATTRIBUTE_ARCHIVE)
    
    def is_file_directory(self, path):
        attrs = self.get_file_attributes(path)
        return bool(attrs & self.FILE_ATTRIBUTE_DIRECTORY)
    
    def get_file_owner(self, path):
        try:
            import win32security
            sd = win32security.GetFileSecurity(path, win32security.OWNER_SECURITY_INFORMATION)
            owner = sd.GetSecurityDescriptorOwner()
            return owner
        except Exception:
            return None
    
    def get_file_permissions(self, path):
        return stat.S_IMODE(os.stat(path).st_mode)
    
    def set_file_permissions(self, path, mode):
        os.chmod(path, mode)
    
    def hash_file(self, path, algorithm="sha256"):
        hash_func = hashlib.new(algorithm)
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(8192), b""):
                hash_func.update(chunk)
        return hash_func.hexdigest()
    
    def verify_file_hash(self, path, expected_hash, algorithm="sha256"):
        actual_hash = self.hash_file(path, algorithm)
        return actual_hash.lower() == expected_hash.lower()
    
    def compare_files(self, path1, path2):
        hash1 = self.hash_file(path1)
        hash2 = self.hash_file(path2)
        return hash1 == hash2
    
    def find_files(self, directory, pattern, recursive=False):
        results = []
        if recursive:
            for root, dirs, files in os.walk(directory):
                for file in files:
                    if fnmatch.fnmatch(file, pattern):
                        results.append(os.path.join(root, file))
        else:
            for file in os.listdir(directory):
                if fnmatch.fnmatch(file, pattern):
                    results.append(os.path.join(directory, file))
        return results
    
    def search_files(self, directory, pattern, recursive=False, case_sensitive=False):
        results = []
        if recursive:
            for root, dirs, files in os.walk(directory):
                for file in files:
                    if (case_sensitive and pattern in file) or (not case_sensitive and pattern.lower() in file.lower()):
                        results.append(os.path.join(root, file))
        else:
            for file in os.listdir(directory):
                if (case_sensitive and pattern in file) or (not case_sensitive and pattern.lower() in file.lower()):
                    results.append(os.path.join(directory, file))
        return results
    
    def get_recent_files(self, directory, count=10):
        files = []
        for file in os.listdir(directory):
            path = os.path.join(directory, file)
            if os.path.isfile(path):
                mtime = os.path.getmtime(path)
                files.append((path, mtime))
        files.sort(key=lambda x: x[1], reverse=True)
        return [f[0] for f in files[:count]]
    
    def get_largest_files(self, directory, count=10):
        files = []
        for file in os.listdir(directory):
            path = os.path.join(directory, file)
            if os.path.isfile(path):
                size = os.path.getsize(path)
                files.append((path, size))
        files.sort(key=lambda x: x[1], reverse=True)
        return [f[0] for f in files[:count]]
    
    def get_oldest_files(self, directory, count=10):
        files = []
        for file in os.listdir(directory):
            path = os.path.join(directory, file)
            if os.path.isfile(path):
                mtime = os.path.getmtime(path)
                files.append((path, mtime))
        files.sort(key=lambda x: x[1])
        return [f[0] for f in files[:count]]
    
    def compress_file(self, src, dst, format="zip"):
        if format == "zip":
            with zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED) as zf:
                zf.write(src, os.path.basename(src))
        elif format == "gzip":
            with open(src, "rb") as f_in:
                with gzip.open(dst, "wb") as f_out:
                    shutil.copyfileobj(f_in, f_out)
        elif format == "bz2":
            with open(src, "rb") as f_in:
                with bz2.open(dst, "wb") as f_out:
                    shutil.copyfileobj(f_in, f_out)
        elif format == "xz":
            with open(src, "rb") as f_in:
                with lzma.open(dst, "wb") as f_out:
                    shutil.copyfileobj(f_in, f_out)
        else:
            raise FileError(f"Unsupported compression format: {format}")
    
    def decompress_file(self, src, dst=None):
        if src.endswith(".zip"):
            if dst is None:
                dst = os.path.dirname(src)
            with zipfile.ZipFile(src, "r") as zf:
                zf.extractall(dst)
        elif src.endswith(".gz"):
            if dst is None:
                dst = src[:-3]
            with gzip.open(src, "rb") as f_in:
                with open(dst, "wb") as f_out:
                    shutil.copyfileobj(f_in, f_out)
        elif src.endswith(".bz2"):
            if dst is None:
                dst = src[:-4]
            with bz2.open(src, "rb") as f_in:
                with open(dst, "wb") as f_out:
                    shutil.copyfileobj(f_in, f_out)
        elif src.endswith(".xz"):
            if dst is None:
                dst = src[:-3]
            with lzma.open(src, "rb") as f_in:
                with open(dst, "wb") as f_out:
                    shutil.copyfileobj(f_in, f_out)
        else:
            raise FileError(f"Unsupported compression format")
    
    def create_zip_archive(self, dst, sources):
        with zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED) as zf:
            for src in sources:
                if os.path.isfile(src):
                    zf.write(src, os.path.basename(src))
                elif os.path.isdir(src):
                    for root, dirs, files in os.walk(src):
                        for file in files:
                            file_path = os.path.join(root, file)
                            arc_name = os.path.relpath(file_path, os.path.dirname(src))
                            zf.write(file_path, arc_name)
    
    def extract_zip_archive(self, src, dst=None):
        if dst is None:
            dst = os.path.dirname(src)
        with zipfile.ZipFile(src, "r") as zf:
            zf.extractall(dst)
    
    def registry_key_exists(self, key, subkey):
        try:
            winreg.OpenKey(key, subkey, 0, winreg.KEY_READ)
            return True
        except FileNotFoundError:
            return False
        except Exception:
            return False
    
    def registry_value_exists(self, key, subkey, value_name):
        try:
            k = winreg.OpenKey(key, subkey, 0, winreg.KEY_READ)
            winreg.QueryValueEx(k, value_name)
            winreg.CloseKey(k)
            return True
        except FileNotFoundError:
            return False
        except Exception:
            return False
    
    def registry_read_value(self, key, subkey, value_name):
        try:
            k = winreg.OpenKey(key, subkey, 0, winreg.KEY_READ)
            value, value_type = winreg.QueryValueEx(k, value_name)
            winreg.CloseKey(k)
            return {"value": value, "type": value_type}
        except FileNotFoundError:
            raise RegistryError(f"Key not found: {subkey}")
        except Exception as e:
            raise RegistryError(f"Failed to read value: {e}")
    
    def registry_write_value(self, key, subkey, value_name, value, value_type=winreg.REG_SZ):
        try:
            k = winreg.CreateKey(key, subkey)
            winreg.SetValueEx(k, value_name, 0, value_type, value)
            winreg.CloseKey(k)
        except Exception as e:
            raise RegistryError(f"Failed to write value: {e}")
    
    def registry_delete_value(self, key, subkey, value_name):
        try:
            k = winreg.OpenKey(key, subkey, 0, winreg.KEY_SET_VALUE)
            winreg.DeleteValue(k, value_name)
            winreg.CloseKey(k)
        except FileNotFoundError:
            raise RegistryError(f"Value not found: {value_name}")
        except Exception as e:
            raise RegistryError(f"Failed to delete value: {e}")
    
    def registry_delete_key(self, key, subkey):
        try:
            winreg.DeleteKey(key, subkey)
        except FileNotFoundError:
            raise RegistryError(f"Key not found: {subkey}")
        except Exception as e:
            raise RegistryError(f"Failed to delete key: {e}")
    
    def registry_create_key(self, key, subkey):
        try:
            winreg.CreateKey(key, subkey)
        except Exception as e:
            raise RegistryError(f"Failed to create key: {e}")
    
    def registry_enum_subkeys(self, key, subkey):
        try:
            k = winreg.OpenKey(key, subkey, 0, winreg.KEY_ENUMERATE_SUB_KEYS)
            subkeys = []
            i = 0
            while True:
                try:
                    subkey_name = winreg.EnumKey(k, i)
                    subkeys.append(subkey_name)
                    i += 1
                except OSError:
                    break
            winreg.CloseKey(k)
            return subkeys
        except Exception as e:
            raise RegistryError(f"Failed to enumerate subkeys: {e}")
    
    def registry_enum_values(self, key, subkey):
        try:
            k = winreg.OpenKey(key, subkey, 0, winreg.KEY_QUERY_VALUE)
            values = []
            i = 0
            while True:
                try:
                    value_name, value, value_type = winreg.EnumValue(k, i)
                    values.append({"name": value_name, "value": value, "type": value_type})
                    i += 1
                except OSError:
                    break
            winreg.CloseKey(k)
            return values
        except Exception as e:
            raise RegistryError(f"Failed to enumerate values: {e}")
    
    def registry_export(self, key, subkey, file_path):
        try:
            import subprocess
            full_key = self._get_registry_full_name(key)
            cmd = f'reg export "{full_key}\\{subkey}" "{file_path}" /y'
            subprocess.run(cmd, shell=True, check=True)
        except Exception as e:
            raise RegistryError(f"Failed to export registry: {e}")
    
    def registry_import(self, file_path):
        try:
            import subprocess
            cmd = f'reg import "{file_path}"'
            subprocess.run(cmd, shell=True, check=True)
        except Exception as e:
            raise RegistryError(f"Failed to import registry: {e}")
    
    def _get_registry_full_name(self, key):
        key_map = {
            self.HKEY_CLASSES_ROOT: "HKEY_CLASSES_ROOT",
            self.HKEY_CURRENT_USER: "HKEY_CURRENT_USER",
            self.HKEY_LOCAL_MACHINE: "HKEY_LOCAL_MACHINE",
            self.HKEY_USERS: "HKEY_USERS",
            self.HKEY_CURRENT_CONFIG: "HKEY_CURRENT_CONFIG",
        }
        return key_map.get(key, "UNKNOWN")
    
    def process_exists(self, pid):
        try:
            handle = self._kernel32.OpenProcess(self.PROCESS_QUERY_INFORMATION, False, pid)
            if handle:
                self._kernel32.CloseHandle(handle)
                return True
            return False
        except Exception:
            return False
    
    def get_process_by_name(self, name):
        processes = []
        for proc in self.list_processes():
            if proc["name"].lower() == name.lower():
                processes.append(proc)
        return processes
    
    def get_process_by_id(self, pid):
        for proc in self.list_processes():
            if proc["pid"] == pid:
                return proc
        return None
    
    def list_processes(self):
        processes = []
        try:
            import subprocess
            result = subprocess.run(["tasklist", "/FO", "CSV", "/NH"], capture_output=True, text=True)
            lines = result.stdout.strip().split("\n")
            for line in lines:
                parts = line.strip('"').split('","')
                if len(parts) >= 2:
                    try:
                        pid = int(parts[1].replace(",", ""))
                        processes.append({
                            "name": parts[0],
                            "pid": pid,
                            "memory": parts[2] if len(parts) > 2 else "N/A",
                        })
                    except ValueError:
                        continue
        except Exception:
            pass
        return processes
    
    def start_process(self, executable, arguments=None, wait=False, show_window=True):
        if arguments is None:
            arguments = []
        if isinstance(arguments, str):
            arguments = [arguments]
        cmd = [executable] + arguments
        startupinfo = None
        if not show_window:
            startupinfo = subprocess.STARTUPINFO()
            startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            startupinfo.wShowWindow = self.SW_HIDE
        try:
            process = subprocess.Popen(cmd, startupinfo=startupinfo)
            if wait:
                process.wait()
            return process.pid
        except Exception as e:
            raise ProcessError(f"Failed to start process: {e}")
    
    def start_process_hidden(self, executable, arguments=None):
        return self.start_process(executable, arguments, show_window=False)
    
    def start_process_admin(self, executable, arguments=None):
        return self.run_as_admin(executable, arguments)
    
    def kill_process(self, pid, force=False):
        try:
            if force:
                subprocess.run(["taskkill", "/PID", str(pid), "/F"], check=True)
            else:
                subprocess.run(["taskkill", "/PID", str(pid)], check=True)
            return True
        except Exception:
            return False
    
    def kill_process_by_name(self, name, force=False):
        killed = 0
        for proc in self.get_process_by_name(name):
            if self.kill_process(proc["pid"], force):
                killed += 1
        return killed
    
    def suspend_process(self, pid):
        try:
            handle = self._kernel32.OpenProcess(self.PROCESS_SUSPEND_RESUME, False, pid)
            if not handle:
                return False
            self._ntdll.NtSuspendProcess(handle)
            self._kernel32.CloseHandle(handle)
            return True
        except Exception:
            return False
    
    def resume_process(self, pid):
        try:
            handle = self._kernel32.OpenProcess(self.PROCESS_SUSPEND_RESUME, False, pid)
            if not handle:
                return False
            self._ntdll.NtResumeProcess(handle)
            self._kernel32.CloseHandle(handle)
            return True
        except Exception:
            return False
    
    def get_process_memory(self, pid):
        try:
            handle = self._kernel32.OpenProcess(self.PROCESS_QUERY_INFORMATION | self.PROCESS_VM_READ, False, pid)
            if not handle:
                return None
            class MEMORY_COUNTERS(ctypes.Structure):
                _fields_ = [
                    ("ByteSize", ctypes.c_size_t),
                    ("PeakVirtualSize", ctypes.c_size_t),
                    ("VirtualSize", ctypes.c_size_t),
                    ("PageFaultCount", ctypes.c_ulong),
                    ("PeakWorkingSetSize", ctypes.c_size_t),
                    ("WorkingSetSize", ctypes.c_size_t),
                    ("QuotaPeakPagedPoolUsage", ctypes.c_size_t),
                    ("QuotaPagedPoolUsage", ctypes.c_size_t),
                    ("QuotaPeakNonPagedPoolUsage", ctypes.c_size_t),
                    ("QuotaNonPagedPoolUsage", ctypes.c_size_t),
                    ("PagefileUsage", ctypes.c_size_t),
                    ("PeakPagefileUsage", ctypes.c_size_t),
                    ("PrivateUsage", ctypes.c_size_t),
                ]
            counters = MEMORY_COUNTERS()
            counters.ByteSize = ctypes.sizeof(MEMORY_COUNTERS)
            self._kernel32.GetProcessMemoryInfo(handle, ctypes.byref(counters), ctypes.sizeof(MEMORY_COUNTERS))
            self._kernel32.CloseHandle(handle)
            return {
                "peak_virtual_size": counters.PeakVirtualSize,
                "virtual_size": counters.VirtualSize,
                "page_fault_count": counters.PageFaultCount,
                "peak_working_set_size": counters.PeakWorkingSetSize,
                "working_set_size": counters.WorkingSetSize,
                "pagefile_usage": counters.PagefileUsage,
                "peak_pagefile_usage": counters.PeakPagefileUsage,
            }
        except Exception:
            return None
    
    def get_process_threads(self, pid):
        threads = []
        try:
            import subprocess
            result = subprocess.run(["tasklist", "/FI", f"PID eq {pid}", "/FO", "CSV", "/NH"], capture_output=True, text=True)
            if result.returncode == 0:
                threads.append({"pid": pid, "status": "running"})
        except Exception:
            pass
        return threads
    
    def get_process_handles(self, pid):
        handles = []
        try:
            handle = self._kernel32.OpenProcess(self.PROCESS_DUP_HANDLE, False, pid)
            if handle:
                self._kernel32.CloseHandle(handle)
                handles.append({"handle": handle, "type": "process"})
        except Exception:
            pass
        return handles
    
    def get_process_command_line(self, pid):
        try:
            import subprocess
            result = subprocess.run(["wmic", "process", "where", f"ProcessId={pid}", "get", "CommandLine"], capture_output=True, text=True)
            lines = result.stdout.strip().split("\n")
            if len(lines) > 1:
                return lines[1].strip()
        except Exception:
            pass
        return None
    
    def get_process_executable_path(self, pid):
        try:
            import subprocess
            result = subprocess.run(["wmic", "process", "where", f"ProcessId={pid}", "get", "ExecutablePath"], capture_output=True, text=True)
            lines = result.stdout.strip().split("\n")
            if len(lines) > 1:
                return lines[1].strip()
        except Exception:
            pass
        return None
    
    def get_process_working_directory(self, pid):
        try:
            import subprocess
            result = subprocess.run(["wmic", "process", "where", f"ProcessId={pid}", "get", "CommandLine"], capture_output=True, text=True)
            cmd = result.stdout.strip().split("\n")
            if len(cmd) > 1:
                import shlex
                try:
                    parts = shlex.split(cmd[1].strip())
                    if parts:
                        exe_path = parts[0]
                        return os.path.dirname(exe_path)
                except Exception:
                    pass
        except Exception:
            pass
        return None
    
    def get_process_owner(self, pid):
        try:
            import subprocess
            result = subprocess.run(["wmic", "process", "where", f"ProcessId={pid}", "get", "Owner"], capture_output=True, text=True)
            lines = result.stdout.strip().split("\n")
            if len(lines) > 1:
                return lines[1].strip()
        except Exception:
            pass
        return None
    
    def get_process_priority(self, pid):
        try:
            handle = self._kernel32.OpenProcess(self.PROCESS_QUERY_INFORMATION, False, pid)
            if not handle:
                return None
            priority = self._kernel32.GetPriorityClass(handle)
            self._kernel32.CloseHandle(handle)
            priority_map = {
                self.REALTIME_PRIORITY_CLASS: "realtime",
                self.HIGH_PRIORITY_CLASS: "high",
                self.ABOVE_NORMAL_PRIORITY_CLASS: "above_normal",
                self.NORMAL_PRIORITY_CLASS: "normal",
                self.BELOW_NORMAL_PRIORITY_CLASS: "below_normal",
                self.IDLE_PRIORITY_CLASS: "idle",
            }
            return priority_map.get(priority, "unknown")
        except Exception:
            return None
    
    def set_process_priority(self, pid, priority):
        priority_map = {
            "realtime": self.REALTIME_PRIORITY_CLASS,
            "high": self.HIGH_PRIORITY_CLASS,
            "above_normal": self.ABOVE_NORMAL_PRIORITY_CLASS,
            "normal": self.NORMAL_PRIORITY_CLASS,
            "below_normal": self.BELOW_NORMAL_PRIORITY_CLASS,
            "idle": self.IDLE_PRIORITY_CLASS,
        }
        try:
            handle = self._kernel32.OpenProcess(self.PROCESS_SET_INFORMATION, False, pid)
            if not handle:
                return False
            self._kernel32.SetPriorityClass(handle, priority_map.get(priority, self.NORMAL_PRIORITY_CLASS))
            self._kernel32.CloseHandle(handle)
            return True
        except Exception:
            return False
    
    def wait_for_process(self, pid, timeout=None):
        try:
            handle = self._kernel32.OpenProcess(self.PROCESS_QUERY_INFORMATION | self.SYNCHRONIZE, False, pid)
            if not handle:
                return False
            wait_time = self.INFINITE if timeout is None else int(timeout * 1000)
            result = self._kernel32.WaitForSingleObject(handle, wait_time)
            self._kernel32.CloseHandle(handle)
            return result == self.WAIT_OBJECT_0
        except Exception:
            return False
    
    def service_exists(self, service_name):
        return service_name in self.list_services()
    
    def list_services(self):
        services = []
        try:
            import subprocess
            result = subprocess.run(["sc", "query", "type=", "service"], capture_output=True, text=True)
            lines = result.stdout.split("\n")
            current_service = None
            for line in lines:
                if line.startswith("SERVICE_NAME:"):
                    if current_service:
                        services.append(current_service)
                    current_service = {"name": line.split(":")[1].strip()}
                elif current_service and line.startswith("    DISPLAY_NAME:"):
                    current_service["display_name"] = line.split(":")[1].strip()
                elif current_service and line.startswith("    STATE"):
                    state_parts = line.split(":")
                    if len(state_parts) > 1:
                        current_service["state"] = state_parts[1].strip()
            if current_service:
                services.append(current_service)
        except Exception:
            pass
        return services
    
    def get_service_status(self, service_name):
        try:
            import subprocess
            result = subprocess.run(["sc", "query", service_name], capture_output=True, text=True)
            if result.returncode == 0:
                for line in result.stdout.split("\n"):
                    if "STATE" in line:
                        state = line.split(":")[-1].strip()
                        return state
        except Exception:
            pass
        return "unknown"
    
    def start_service(self, service_name):
        try:
            import subprocess
            result = subprocess.run(["sc", "start", service_name], capture_output=True, text=True)
            return result.returncode == 0
        except Exception:
            return False
    
    def stop_service(self, service_name):
        try:
            import subprocess
            result = subprocess.run(["sc", "stop", service_name], capture_output=True, text=True)
            return result.returncode == 0
        except Exception:
            return False
    
    def restart_service(self, service_name):
        self.stop_service(service_name)
        time.sleep(1)
        return self.start_service(service_name)
    
    def pause_service(self, service_name):
        try:
            import subprocess
            result = subprocess.run(["sc", "pause", service_name], capture_output=True, text=True)
            return result.returncode == 0
        except Exception:
            return False
    
    def continue_service(self, service_name):
        try:
            import subprocess
            result = subprocess.run(["sc", "continue", service_name], capture_output=True, text=True)
            return result.returncode == 0
        except Exception:
            return False
    
    def delete_service(self, service_name):
        try:
            import subprocess
            result = subprocess.run(["sc", "delete", service_name], capture_output=True, text=True)
            return result.returncode == 0
        except Exception:
            return False
    
    def create_service(self, service_name, display_name, executable, start_type="auto"):
        try:
            import subprocess
            start_map = {"auto": "auto", "demand": "demand", "disabled": "disabled", "boot": "boot", "system": "system"}
            cmd = ["sc", "create", service_name, "binPath=", executable, "displayName=", display_name, "start=", start_map.get(start_type, "auto")]
            result = subprocess.run(cmd, capture_output=True, text=True)
            return result.returncode == 0
        except Exception:
            return False
    
    def configure_service(self, service_name, start_type=None, executable=None):
        try:
            import subprocess
            cmd = ["sc", "config", service_name]
            if start_type:
                cmd.extend(["start=", start_type])
            if executable:
                cmd.extend(["binPath=", executable])
            result = subprocess.run(cmd, capture_output=True, text=True)
            return result.returncode == 0
        except Exception:
            return False
    
    def get_service_config(self, service_name):
        config = {}
        try:
            import subprocess
            result = subprocess.run(["sc", "qc", service_name], capture_output=True, text=True)
            for line in result.stdout.split("\n"):
                if ":" in line:
                    key, value = line.split(":", 1)
                    config[key.strip()] = value.strip()
        except Exception:
            pass
        return config
    
    def get_service_dependencies(self, service_name):
        dependencies = []
        try:
            import subprocess
            result = subprocess.run(["sc", "qc", service_name], capture_output=True, text=True)
            in_deps = False
            for line in result.stdout.split("\n"):
                if "DEPENDENCIES" in line:
                    in_deps = True
                    continue
                if in_deps:
                    if line.strip():
                        dep = line.strip()
                        if dep and dep != "(no dependencies)":
                            dependencies.append(dep)
                    else:
                        break
        except Exception:
            pass
        return dependencies
    
    def show_message_box(self, title, message, buttons="ok", icon="information"):
        button_map = {
            "ok": self.MB_OK,
            "okcancel": self.MB_OKCANCEL,
            "yesno": self.MB_YESNO,
            "yesnocancel": self.MB_YESNOCANCEL,
            "abortretryignore": self.MB_ABORTRETRYIGNORE,
            "retrycancel": self.MB_RETRYCANCEL,
        }
        icon_map = {
            "information": self.MB_ICONINFORMATION,
            "warning": self.MB_ICONWARNING,
            "error": self.MB_ICONERROR,
            "question": self.MB_ICONQUESTION,
        }
        flags = button_map.get(buttons.lower(), self.MB_OK) | icon_map.get(icon.lower(), self.MB_ICONINFORMATION)
        result = self._user32.MessageBoxW(None, message, title, flags)
        result_map = {
            self.IDOK: "ok",
            self.IDCANCEL: "cancel",
            self.IDYES: "yes",
            self.IDNO: "no",
            self.IDABORT: "abort",
            self.IDRETRY: "retry",
            self.IDIGNORE: "ignore",
        }
        return result_map.get(result, "unknown")
    
    def show_error(self, title, message):
        return self.show_message_box(title, message, buttons="ok", icon="error")
    
    def show_warning(self, title, message):
        return self.show_message_box(title, message, buttons="ok", icon="warning")
    
    def show_info(self, title, message):
        return self.show_message_box(title, message, buttons="ok", icon="information")
    
    def show_question(self, title, message):
        return self.show_message_box(title, message, buttons="yesno", icon="question")
    
    def play_sound(self, sound_type="asterisk"):
        sound_map = {
            "asterisk": 0x00000040,
            "exclamation": 0x00000030,
            "hand": 0x00000010,
            "ok": 0x00000000,
            "question": 0x00000020,
        }
        winsound.MessageBeep(sound_map.get(sound_type, 0x00000040))
    
    def play_system_sound(self, sound_name):
        try:
            winsound.PlaySound(sound_name, winsound.SND_APPLICATION)
        except Exception:
            pass
    
    def beep(self, frequency=1000, duration=100):
        winsound.Beep(frequency, duration)
    
    def get_clipboard_text(self):
        try:
            if self._user32.OpenClipboard(None):
                handle = self._user32.GetClipboardData(13)
                if handle:
                    text = ctypes.c_wchar_p(handle).value
                    self._user32.CloseClipboard()
                    return text
                self._user32.CloseClipboard()
        except Exception:
            pass
        return None
    
    def set_clipboard_text(self, text):
        try:
            if self._user32.OpenClipboard(None):
                self._user32.EmptyClipboard()
                encoded = text.encode("utf-16-le") + b"\x00\x00"
                buffer_size = len(encoded)
                handle = self._kernel32.GlobalAlloc(0x42, buffer_size)
                if handle:
                    locked = self._kernel32.GlobalLock(handle)
                    if locked:
                        ctypes.memmove(locked, encoded, buffer_size)
                        self._kernel32.GlobalUnlock(handle)
                        self._user32.SetClipboardData(13, handle)
                self._user32.CloseClipboard()
                return True
        except Exception:
            pass
        return False
    
    def clear_clipboard(self):
        try:
            if self._user32.OpenClipboard(None):
                self._user32.EmptyClipboard()
                self._user32.CloseClipboard()
                return True
        except Exception:
            pass
        return False
    
    def get_screen_resolution(self):
        return {
            "width": self._user32.GetSystemMetrics(0),
            "height": self._user32.GetSystemMetrics(1),
        }
    
    def get_cursor_position(self):
        class POINT(ctypes.Structure):
            _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]
        point = POINT()
        self._user32.GetCursorPos(ctypes.byref(point))
        return {"x": point.x, "y": point.y}
    
    def set_cursor_position(self, x, y):
        self._user32.SetCursorPos(x, y)
    
    def get_mouse_buttons_state(self):
        return {
            "left": bool(self._user32.GetKeyState(0x01) & 0x8000),
            "right": bool(self._user32.GetKeyState(0x02) & 0x8000),
            "middle": bool(self._user32.GetKeyState(0x04) & 0x8000),
        }
    
    def is_key_pressed(self, key_code):
        return bool(self._user32.GetKeyState(key_code) & 0x8000)
    
    def get_key_state(self, key_code):
        return self._user32.GetKeyState(key_code)
    
    def simulate_key_press(self, key_code):
        self._user32.keybd_event(key_code, 0, 0, 0)
        self._user32.keybd_event(key_code, 0, 0x0002, 0)
    
    def simulate_mouse_click(self, x=None, y=None, button="left"):
        if x is not None and y is not None:
            self.set_cursor_position(x, y)
        button_map = {"left": 0x0002, "right": 0x0008, "middle": 0x0020}
        flags = button_map.get(button, 0x0002)
        self._user32.mouse_event(flags, 0, 0, 0, 0)
    
    def simulate_mouse_move(self, x, y):
        self._user32.mouse_event(0x0001, x, y, 0, 0)
    
    def lock_workstation(self):
        self._user32.LockWorkStation()
    
    def logoff(self, force=False):
        flags = 0 if force else 0
        self._user32.ExitWindowsEx(0, flags)
    
    def shutdown(self, force=False, reboot=False):
        flags = 0x00000001 if force else 0
        if reboot:
            flags |= 0x00000002
        self._user32.ExitWindowsEx(flags, 0)
    
    def restart(self, force=False):
        self.shutdown(force=force, reboot=True)
    
    def sleep(self, seconds):
        time.sleep(seconds)
    
    def get_uptime(self):
        return time.time() - self._kernel32.GetTickCount64() / 1000
    
    def get_tick_count(self):
        return self._kernel32.GetTickCount64()
    
    def get_local_time(self):
        class SYSTEMTIME(ctypes.Structure):
            _fields_ = [
                ("wYear", ctypes.c_ushort),
                ("wMonth", ctypes.c_ushort),
                ("wDayOfWeek", ctypes.c_ushort),
                ("wDay", ctypes.c_ushort),
                ("wHour", ctypes.c_ushort),
                ("wMinute", ctypes.c_ushort),
                ("wSecond", ctypes.c_ushort),
                ("wMilliseconds", ctypes.c_ushort),
            ]
        st = SYSTEMTIME()
        self._kernel32.GetLocalTime(ctypes.byref(st))
        return {
            "year": st.wYear,
            "month": st.wMonth,
            "day": st.wDay,
            "hour": st.wHour,
            "minute": st.wMinute,
            "second": st.wSecond,
            "millisecond": st.wMilliseconds,
            "day_of_week": st.wDayOfWeek,
        }
    
    def get_system_time(self):
        class SYSTEMTIME(ctypes.Structure):
            _fields_ = [
                ("wYear", ctypes.c_ushort),
                ("wMonth", ctypes.c_ushort),
                ("wDayOfWeek", ctypes.c_ushort),
                ("wDay", ctypes.c_ushort),
                ("wHour", ctypes.c_ushort),
                ("wMinute", ctypes.c_ushort),
                ("wSecond", ctypes.c_ushort),
                ("wMilliseconds", ctypes.c_ushort),
            ]
        st = SYSTEMTIME()
        self._kernel32.GetSystemTime(ctypes.byref(st))
        return {
            "year": st.wYear,
            "month": st.wMonth,
            "day": st.wDay,
            "hour": st.wHour,
            "minute": st.wMinute,
            "second": st.wSecond,
            "millisecond": st.wMilliseconds,
            "day_of_week": st.wDayOfWeek,
        }
    
    def set_system_time(self, year, month, day, hour, minute, second):
        class SYSTEMTIME(ctypes.Structure):
            _fields_ = [
                ("wYear", ctypes.c_ushort),
                ("wMonth", ctypes.c_ushort),
                ("wDayOfWeek", ctypes.c_ushort),
                ("wDay", ctypes.c_ushort),
                ("wHour", ctypes.c_ushort),
                ("wMinute", ctypes.c_ushort),
                ("wSecond", ctypes.c_ushort),
                ("wMilliseconds", ctypes.c_ushort),
            ]
        st = SYSTEMTIME()
        st.wYear = year
        st.wMonth = month
        st.wDay = day
        st.wHour = hour
        st.wMinute = minute
        st.wSecond = second
        st.wMilliseconds = 0
        self._kernel32.SetSystemTime(ctypes.byref(st))
    
    def get_timezone_info(self):
        import time
        tz = time.tzname
        offset = -time.timezone // 3600
        return {
            "timezone": tz[0] if tz else "unknown",
            "dst_timezone": tz[1] if len(tz) > 1 else "unknown",
            "offset_hours": offset,
        }
    
    def ping(self, host, count=4, timeout=1000):
        try:
            import subprocess
            result = subprocess.run(["ping", "-n", str(count), "-w", str(timeout), host], capture_output=True, text=True)
            return {
                "success": result.returncode == 0,
                "output": result.stdout,
            }
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def get_host_by_name(self, name):
        try:
            return socket.gethostbyname(name)
        except Exception:
            return None
    
    def get_name_by_host(self, ip):
        try:
            return socket.gethostbyaddr(ip)[0]
        except Exception:
            return None
    
    def get_port_status(self, host, port, timeout=1):
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(timeout)
            result = sock.connect_ex((host, port))
            sock.close()
            return result == 0
        except Exception:
            return False
    
    def scan_ports(self, host, ports, timeout=1):
        open_ports = []
        for port in ports:
            if self.get_port_status(host, port, timeout):
                open_ports.append(port)
        return open_ports
    
    def get_mac_address(self):
        import uuid
        return ":".join(["{:02x}".format((uuid.getnode() >> elements) & 0xFF) for elements in range(0, 48, 8)][::-1])
    
    def get_ip_addresses(self):
        addresses = []
        try:
            hostname = socket.gethostname()
            addresses = socket.gethostbyname_ex(hostname)[2]
        except Exception:
            pass
        return addresses
    
    def get_default_gateway(self):
        try:
            import subprocess
            result = subprocess.run(["route", "print", "0.0.0.0"], capture_output=True, text=True)
            for line in result.stdout.split("\n"):
                if "0.0.0.0" in line and "0.0.0.0" in line:
                    parts = line.split()
                    if len(parts) >= 4:
                        return parts[3]
        except Exception:
            pass
        return None
    
    def get_dns_servers(self):
        servers = []
        try:
            import subprocess
            result = subprocess.run(["ipconfig", "/all"], capture_output=True, text=True)
            for line in result.stdout.split("\n"):
                if "DNS Servers" in line or "DNS Server" in line:
                    parts = line.split(":")
                    if len(parts) > 1:
                        servers.append(parts[1].strip())
        except Exception:
            pass
        return servers
    
    def flush_dns_cache(self):
        try:
            import subprocess
            subprocess.run(["ipconfig", "/flushdns"], check=True)
            return True
        except Exception:
            return False
    
    def release_ip(self):
        try:
            import subprocess
            subprocess.run(["ipconfig", "/release"], check=True)
            return True
        except Exception:
            return False
    
    def renew_ip(self):
        try:
            import subprocess
            subprocess.run(["ipconfig", "/renew"], check=True)
            return True
        except Exception:
            return False
    
    def get_event_logs(self, log_name="Application", count=10):
        logs = []
        try:
            import subprocess
            result = subprocess.run(["wevtutil", "qe", log_name, "/c:str(count)", "/f:text"], capture_output=True, text=True)
            logs = result.stdout.split("\n\n")
        except Exception:
            pass
        return logs
    
    def clear_event_log(self, log_name="Application"):
        try:
            import subprocess
            subprocess.run(["wevtutil", "cl", log_name], check=True)
            return True
        except Exception:
            return False
    
    def export_event_log(self, log_name, file_path):
        try:
            import subprocess
            subprocess.run(["wevtutil", "epl", log_name, file_path], check=True)
            return True
        except Exception:
            return False
    
    def write_event_log(self, source, message, event_type="information"):
        try:
            import subprocess
            type_map = {"information": 4, "warning": 2, "error": 1}
            subprocess.run(["eventcreate", "/T", type_map.get(event_type, 4).str(), "/ID", "1", "/L", "APPLICATION", "/SO", source, "/D", message], check=True)
            return True
        except Exception:
            return False
    
    def create_shortcut(self, target, shortcut_path, arguments=None, description=None, icon=None, working_directory=None):
        try:
            import subprocess
            target = target.replace("\\", "\\\\")
            shortcut_path = shortcut_path.replace("\\", "\\\\")
            vbs_content = f'Set oWS = WScript.CreateObject("WScript.Shell")\n'
            vbs_content += f'sLinkFile = "{shortcut_path}"\n'
            vbs_content += f'Set oLink = oWS.CreateShortcut(sLinkFile)\n'
            vbs_content += f'oLink.TargetPath = "{target}"\n'
            if arguments:
                vbs_content += f'oLink.Arguments = "{arguments}"\n'
            if description:
                vbs_content += f'oLink.Description = "{description}"\n'
            if icon:
                vbs_content += f'oLink.IconLocation = "{icon}"\n'
            if working_directory:
                vbs_content += f'oLink.WorkingDirectory = "{working_directory}"\n'
            vbs_content += "oLink.Save\n"
            vbs_path = tempfile.gettempdir() + "\\create_shortcut.vbs"
            with open(vbs_path, "w") as f:
                f.write(vbs_content)
            subprocess.run(["cscript", "//nologo", vbs_path], check=True)
            os.remove(vbs_path)
            return True
        except Exception:
            return False
    
    def get_shortcut_target(self, shortcut_path):
        try:
            import subprocess
            vbs_content = f'Set oWS = WScript.CreateObject("WScript.Shell")\n'
            vbs_content += f'sLinkFile = "{shortcut_path}"\n'
            vbs_content += f'Set oLink = oWS.CreateShortcut(sLinkFile)\n'
            vbs_content += f'WScript.Echo oLink.TargetPath\n'
            vbs_path = tempfile.gettempdir() + "\\get_shortcut.vbs"
            with open(vbs_path, "w") as f:
                f.write(vbs_content)
            result = subprocess.run(["cscript", "//nologo", vbs_path], capture_output=True, text=True)
            os.remove(vbs_path)
            return result.stdout.strip()
        except Exception:
            return None
    
    def get_special_folder(self, folder_name):
        folder_map = {
            "desktop": 0,
            "programs": 2,
            "documents": 5,
            "favorites": 6,
            "startup": 7,
            "recent": 8,
            "sendto": 9,
            "startmenu": 11,
            "mydocuments": 5,
            "mymusic": 13,
            "myvideo": 14,
            "desktopdirectory": 16,
            "drives": 17,
            "network": 18,
            "fonts": 20,
            "templates": 21,
            "appdata": 26,
            "localappdata": 28,
            "commonappdata": 35,
        }
        try:
            from ctypes import wintypes
            SHGetFolderPath = ctypes.windll.shell32.SHGetFolderPathW
            path_buffer = ctypes.create_unicode_buffer(self.MAX_PATH)
            result = SHGetFolderPath(None, folder_map.get(folder_name.lower(), 0), None, 0, path_buffer)
            if result == 0:
                return path_buffer.value
        except Exception:
            pass
        return None
    
    def add_to_startup(self, name, executable, arguments=None):
        startup_folder = self.get_special_folder("startup")
        if startup_folder:
            shortcut_path = os.path.join(startup_folder, f"{name}.lnk")
            return self.create_shortcut(executable, shortcut_path, arguments)
        return False
    
    def remove_from_startup(self, name):
        startup_folder = self.get_special_folder("startup")
        if startup_folder:
            shortcut_path = os.path.join(startup_folder, f"{name}.lnk")
            if os.path.exists(shortcut_path):
                os.remove(shortcut_path)
                return True
        return False
    
    def get_startup_programs(self):
        programs = []
        startup_folder = self.get_special_folder("startup")
        if startup_folder and os.path.exists(startup_folder):
            for file in os.listdir(startup_folder):
                if file.endswith(".lnk"):
                    programs.append({"name": file[:-4], "path": os.path.join(startup_folder, file)})
        return programs
    
    def enable_privilege(self, privilege_name):
        try:
            handle = ctypes.c_void_p()
            self._advapi32.OpenProcessToken(
                self._kernel32.GetCurrentProcess(),
                self.TOKEN_ADJUST_PRIVILEGES | self.TOKEN_QUERY,
                ctypes.byref(handle)
            )
            luid = ctypes.c_long()
            self._advapi32.LookupPrivilegeValueW(None, privilege_name, ctypes.byref(luid))
            class LUID_AND_ATTRIBUTES(ctypes.Structure):
                _fields_ = [("Luid", ctypes.c_long), ("Attributes", ctypes.c_ulong)]
            class TOKEN_PRIVILEGES(ctypes.Structure):
                _fields_ = [("PrivilegeCount", ctypes.c_ulong), ("Privileges", LUID_AND_ATTRIBUTES * 1)]
            tp = TOKEN_PRIVILEGES()
            tp.PrivilegeCount = 1
            tp.Privileges[0].Luid = luid
            tp.Privileges[0].Attributes = self.SE_PRIVILEGE_ENABLED
            self._advapi32.AdjustTokenPrivileges(handle, False, ctypes.byref(tp), 0, None, None)
            self._kernel32.CloseHandle(handle)
            return True
        except Exception:
            return False
    
    def disable_privilege(self, privilege_name):
        try:
            handle = ctypes.c_void_p()
            self._advapi32.OpenProcessToken(
                self._kernel32.GetCurrentProcess(),
                self.TOKEN_ADJUST_PRIVILEGES | self.TOKEN_QUERY,
                ctypes.byref(handle)
            )
            luid = ctypes.c_long()
            self._advapi32.LookupPrivilegeValueW(None, privilege_name, ctypes.byref(luid))
            class LUID_AND_ATTRIBUTES(ctypes.Structure):
                _fields_ = [("Luid", ctypes.c_long), ("Attributes", ctypes.c_ulong)]
            class TOKEN_PRIVILEGES(ctypes.Structure):
                _fields_ = [("PrivilegeCount", ctypes.c_ulong), ("Privileges", LUID_AND_ATTRIBUTES * 1)]
            tp = TOKEN_PRIVILEGES()
            tp.PrivilegeCount = 1
            tp.Privileges[0].Luid = luid
            tp.Privileges[0].Attributes = 0
            self._advapi32.AdjustTokenPrivileges(handle, False, ctypes.byref(tp), 0, None, None)
            self._kernel32.CloseHandle(handle)
            return True
        except Exception:
            return False
    
    def check_privilege(self, privilege_name):
        try:
            handle = ctypes.c_void_p()
            self._advapi32.OpenProcessToken(
                self._kernel32.GetCurrentProcess(),
                self.TOKEN_QUERY,
                ctypes.byref(handle)
            )
            luid = ctypes.c_long()
            self._advapi32.LookupPrivilegeValueW(None, privilege_name, ctypes.byref(luid))
            self._kernel32.CloseHandle(handle)
            return True
        except Exception:
            return False
    
    def get_privileges(self):
        privileges = []
        privilege_names = [
            "SeDebugPrivilege",
            "SeShutdownPrivilege",
            "SeTakeOwnershipPrivilege",
            "SeBackupPrivilege",
            "SeRestorePrivilege",
            "SeSystemEnvironmentPrivilege",
            "SeLoadDriverPrivilege",
            "SeSecurityPrivilege",
            "SeChangeNotifyPrivilege",
            "SeRemoteShutdownPrivilege",
        ]
        for name in privilege_names:
            if self.check_privilege(name):
                privileges.append(name)
        return privileges
    
    def encrypt_file(self, path, password):
        try:
            with open(path, "rb") as f:
                data = f.read()
            key = hashlib.sha256(password.encode()).digest()
            encrypted = bytearray()
            for i, byte in enumerate(data):
                encrypted.append(byte ^ key[i % len(key)])
            with open(path + ".enc", "wb") as f:
                f.write(bytes(encrypted))
            return True
        except Exception:
            return False
    
    def decrypt_file(self, path, password):
        try:
            with open(path, "rb") as f:
                data = f.read()
            key = hashlib.sha256(password.encode()).digest()
            decrypted = bytearray()
            for i, byte in enumerate(data):
                decrypted.append(byte ^ key[i % len(key)])
            output_path = path[:-4] if path.endswith(".enc") else path + ".dec"
            with open(output_path, "wb") as f:
                f.write(bytes(decrypted))
            return True
        except Exception:
            return False
    
    def generate_password(self, length=16, include_special=True):
        chars = string.ascii_letters + string.digits
        if include_special:
            chars += string.punctuation
        return "".join(secrets.choice(chars) for _ in range(length))
    
    def generate_api_key(self, length=32):
        return secrets.token_hex(length // 2)
    
    def hash_password(self, password, salt=None):
        if salt is None:
            salt = secrets.token_hex(16)
        hashed = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 100000)
        return f"{salt}${hashed.hex()}"
    
    def verify_password(self, password, hashed):
        try:
            salt, hash_value = hashed.split("$")
            new_hash = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 100000)
            return new_hash.hex() == hash_value
        except Exception:
            return False
    
    def encode_base64(self, data):
        if isinstance(data, str):
            data = data.encode()
        return base64.b64encode(data).decode()
    
    def decode_base64(self, data):
        if isinstance(data, str):
            data = data.encode()
        return base64.b64decode(data).decode()
    
    def encode_url(self, data):
        from urllib.parse import quote
        return quote(data)
    
    def decode_url(self, data):
        from urllib.parse import unquote
        return unquote(data)
    
    def json_dumps(self, obj, indent=2):
        return json.dumps(obj, indent=indent, ensure_ascii=False)
    
    def json_loads(self, data):
        return json.loads(data)
    
    def json_save(self, path, obj, indent=2):
        with open(path, "w", encoding="utf-8") as f:
            json.dump(obj, f, indent=indent, ensure_ascii=False)
    
    def json_load(self, path):
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    
    def calculate_checksum(self, data, algorithm="md5"):
        hash_func = hashlib.new(algorithm)
        if isinstance(data, str):
            data = data.encode()
        hash_func.update(data)
        return hash_func.hexdigest()
    
    def verify_checksum(self, data, expected, algorithm="md5"):
        return self.calculate_checksum(data, algorithm) == expected
    
    def generate_uuid(self):
        return str(uuid.uuid4())
    
    def generate_uuid_v1(self):
        return str(uuid.uuid1())
    
    def generate_uuid_v3(self, namespace, name):
        return str(uuid.uuid3(namespace, name))
    
    def generate_uuid_v5(self, namespace, name):
        return str(uuid.uuid5(namespace, name))
    
    def validate_uuid(self, uuid_string):
        try:
            uuid.UUID(uuid_string)
            return True
        except ValueError:
            return False
    
    def get_random_int(self, min_val, max_val):
        return secrets.randbelow(max_val - min_val + 1) + min_val
    
    def get_random_float(self, min_val, max_val):
        return secrets.randbelow(1000000) / 1000000 * (max_val - min_val) + min_val
    
    def get_random_choice(self, items):
        return secrets.choice(items)
    
    def shuffle_list(self, items):
        shuffled = items.copy()
        secrets.SystemRandom().shuffle(shuffled)
        return shuffled
    
    def create_thread(self, target, args=(), daemon=False):
        thread = threading.Thread(target=target, args=args, daemon=daemon)
        thread.start()
        return thread
    
    def create_pool(self, max_workers=None):
        return concurrent.futures.ThreadPoolExecutor(max_workers=max_workers)
    
    def run_in_thread(self, func, *args, **kwargs):
        with concurrent.futures.ThreadPoolExecutor() as executor:
            future = executor.submit(func, *args, **kwargs)
            return future.result()
    
    def run_in_process(self, func, *args, **kwargs):
        with concurrent.futures.ProcessPoolExecutor() as executor:
            future = executor.submit(func, *args, **kwargs)
            return future.result()
    
    def create_timer(self, interval, callback, *args):
        def run():
            while True:
                time.sleep(interval)
                callback(*args)
        return self.create_thread(run, daemon=True)
    
    def create_scheduler(self):
        return Scheduler()
    
    def get_thread_id(self):
        return threading.current_thread().ident
    
    def get_process_id(self):
        return os.getpid()
    
    def get_parent_process_id(self):
        try:
            import ctypes
            return ctypes.windll.kernel32.GetCurrentProcessId()
        except Exception:
            return None
    
    def create_mutex(self, name):
        try:
            handle = self._kernel32.CreateMutexW(None, False, name)
            return handle
        except Exception:
            return None
    
    def release_mutex(self, handle):
        try:
            self._kernel32.ReleaseMutex(handle)
        except Exception:
            pass
    
    def close_mutex(self, handle):
        try:
            self._kernel32.CloseHandle(handle)
        except Exception:
            pass
    
    def create_semaphore(self, initial_count, max_count, name=None):
        try:
            handle = self._kernel32.CreateSemaphoreW(None, initial_count, max_count, name)
            return handle
        except Exception:
            return None
    
    def release_semaphore(self, handle, release_count=1):
        try:
            self._kernel32.ReleaseSemaphore(handle, release_count, None)
        except Exception:
            pass
    
    def close_semaphore(self, handle):
        try:
            self._kernel32.CloseHandle(handle)
        except Exception:
            pass
    
    def create_event(self, manual_reset=False, initial_state=False, name=None):
        try:
            handle = self._kernel32.CreateEventW(None, manual_reset, initial_state, name)
            return handle
        except Exception:
            return None
    
    def set_event(self, handle):
        try:
            self._kernel32.SetEvent(handle)
        except Exception:
            pass
    
    def reset_event(self, handle):
        try:
            self._kernel32.ResetEvent(handle)
        except Exception:
            pass
    
    def wait_for_event(self, handle, timeout=None):
        try:
            wait_time = self.INFINITE if timeout is None else int(timeout * 1000)
            result = self._kernel32.WaitForSingleObject(handle, wait_time)
            return result == self.WAIT_OBJECT_0
        except Exception:
            return False
    
    def close_event(self, handle):
        try:
            self._kernel32.CloseHandle(handle)
        except Exception:
            pass
    
    def create_pipe(self):
        try:
            read_handle = ctypes.c_void_p()
            write_handle = ctypes.c_void_p()
            self._kernel32.CreatePipe(ctypes.byref(read_handle), ctypes.byref(write_handle), None, 0)
            return read_handle, write_handle
        except Exception:
            return None, None
    
    def read_pipe(self, handle, size=1024):
        try:
            buffer = ctypes.create_string_buffer(size)
            bytes_read = ctypes.c_ulong()
            self._kernel32.ReadFile(handle, buffer, size, ctypes.byref(bytes_read), None)
            return buffer.value[:bytes_read.value]
        except Exception:
            return None
    
    def write_pipe(self, handle, data):
        try:
            bytes_written = ctypes.c_ulong()
            self._kernel32.WriteFile(handle, data, len(data), ctypes.byref(bytes_written), None)
            return bytes_written.value
        except Exception:
            return 0
    
    def close_pipe(self, handle):
        try:
            self._kernel32.CloseHandle(handle)
        except Exception:
            pass
    
    def create_file_mapping(self, name, size):
        try:
            handle = self._kernel32.CreateFileMappingW(self.INVALID_HANDLE_VALUE, None, 0x04, 0, size, name)
            return handle
        except Exception:
            return None
    
    def map_view_of_file(self, handle, offset=0, size=0):
        try:
            view = self._kernel32.MapViewOfFile(handle, 0xF001F, 0, offset, size)
            return view
        except Exception:
            return None
    
    def unmap_view_of_file(self, view):
        try:
            self._kernel32.UnmapViewOfFile(view)
        except Exception:
            pass
    
    def close_file_mapping(self, handle):
        try:
            self._kernel32.CloseHandle(handle)
        except Exception:
            pass
    
    def get_module_handle(self, module_name):
        try:
            return self._kernel32.GetModuleHandleW(module_name)
        except Exception:
            return None
    
    def get_proc_address(self, module_handle, proc_name):
        try:
            return self._kernel32.GetProcAddress(module_handle, proc_name)
        except Exception:
            return None
    
    def load_library(self, library_name):
        try:
            return self._kernel32.LoadLibraryW(library_name)
        except Exception:
            return None
    
    def free_library(self, library_handle):
        try:
            self._kernel32.FreeLibrary(library_handle)
        except Exception:
            pass
    
    def get_current_module(self):
        try:
            return self._kernel32.GetModuleHandleW(None)
        except Exception:
            return None
    
    def get_module_filename(self, module_handle):
        try:
            buffer = ctypes.create_unicode_buffer(self.MAX_PATH)
            self._kernel32.GetModuleFileNameW(module_handle, buffer, self.MAX_PATH)
            return buffer.value
        except Exception:
            return None
    
    def allocate_memory(self, size):
        try:
            return self._kernel32.VirtualAlloc(None, size, 0x3000, 0x04)
        except Exception:
            return None
    
    def free_memory(self, address):
        try:
            self._kernel32.VirtualFree(address, 0, 0x8000)
        except Exception:
            pass
    
    def protect_memory(self, address, size, protection):
        try:
            old_protection = ctypes.c_ulong()
            self._kernel32.VirtualProtect(address, size, protection, ctypes.byref(old_protection))
            return old_protection.value
        except Exception:
            return None
    
    def read_memory(self, address, size):
        try:
            buffer = ctypes.create_string_buffer(size)
            self._kernel32.RtlMoveMemory(buffer, address, size)
            return buffer.raw
        except Exception:
            return None
    
    def write_memory(self, address, data):
        try:
            self._kernel32.RtlMoveMemory(address, data, len(data))
            return True
        except Exception:
            return False
    
    def zero_memory(self, address, size):
        try:
            self._kernel32.RtlZeroMemory(address, size)
        except Exception:
            pass
    
    def copy_memory(self, dest, src, size):
        try:
            self._kernel32.RtlMoveMemory(dest, src, size)
        except Exception:
            pass
    
    def compare_memory(self, addr1, addr2, size):
        try:
            return self._kernel32.RtlCompareMemory(addr1, addr2, size)
        except Exception:
            return 0
    
    def get_heap_info(self):
        try:
            process_heap = self._kernel32.GetProcessHeap()
            return {"heap_handle": process_heap}
        except Exception:
            return None
    
    def allocate_heap(self, size):
        try:
            process_heap = self._kernel32.GetProcessHeap()
            return self._kernel32.HeapAlloc(process_heap, 0, size)
        except Exception:
            return None
    
    def free_heap(self, address):
        try:
            process_heap = self._kernel32.GetProcessHeap()
            self._kernel32.HeapFree(process_heap, 0, address)
        except Exception:
            pass
    
    def get_performance_counter(self):
        try:
            frequency = ctypes.c_longlong()
            self._kernel32.QueryPerformanceFrequency(ctypes.byref(frequency))
            counter = ctypes.c_longlong()
            self._kernel32.QueryPerformanceCounter(ctypes.byref(counter))
            return counter.value / frequency.value
        except Exception:
            return 0
    
    def get_performance_counter_frequency(self):
        try:
            frequency = ctypes.c_longlong()
            self._kernel32.QueryPerformanceFrequency(ctypes.byref(frequency))
            return frequency.value
        except Exception:
            return 0
    
    def start_performance_timer(self):
        return self.get_performance_counter()
    
    def end_performance_timer(self, start_time):
        end_time = self.get_performance_counter()
        return end_time - start_time
    
    def get_cpu_usage(self):
        try:
            import subprocess
            result = subprocess.run(["wmic", "cpu", "get", "LoadPercentage"], capture_output=True, text=True)
            lines = result.stdout.strip().split("\n")
            if len(lines) > 1:
                return int(lines[1].strip())
        except Exception:
            pass
        return 0
    
    def get_memory_usage(self):
        mem_info = self.get_memory_info()
        total = mem_info.get("total_physical", 1)
        available = mem_info.get("available_physical", 0)
        used = total - available
        return int((used / total) * 100) if total > 0 else 0
    
    def get_disk_usage(self, drive=None):
        disk_info = self.get_disk_info(drive)
        total = disk_info.get("total_bytes", 1)
        free = disk_info.get("total_free_bytes", 0)
        used = total - free
        return int((used / total) * 100) if total > 0 else 0
    
    def get_network_usage(self):
        try:
            import subprocess
            result = subprocess.run(["netstat", "-e"], capture_output=True, text=True)
            lines = result.stdout.strip().split("\n")
            for line in lines:
                if "Bytes" in line:
                    parts = line.split()
                    if len(parts) >= 3:
                        return {"received": int(parts[1]), "sent": int(parts[2])}
        except Exception:
            pass
        return {"received": 0, "sent": 0}
    
    def get_system_load(self):
        return {
            "cpu": self.get_cpu_usage(),
            "memory": self.get_memory_usage(),
            "disk": self.get_disk_usage(),
        }
    
    def monitor_resources(self, interval=1, callback=None):
        def monitor():
            while True:
                load = self.get_system_load()
                if callback:
                    callback(load)
                time.sleep(interval)
        return self.create_thread(monitor, daemon=True)
    
    def cleanup(self):
        self._cache_cleanup()
        for handle in self._handles:
            try:
                self._kernel32.CloseHandle(handle)
            except Exception:
                pass
        self._handles.clear()
        self._cache_clear()
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.cleanup()
        return False


class Scheduler:
    def __init__(self):
        self._tasks = []
        self._running = False
        self._thread = None
    
    def add_task(self, func, interval, *args, **kwargs):
        self._tasks.append({"func": func, "interval": interval, "args": args, "kwargs": kwargs, "last_run": 0})
    
    def remove_task(self, func):
        self._tasks = [t for t in self._tasks if t["func"] != func]
    
    def clear_tasks(self):
        self._tasks.clear()
    
    def _run(self):
        while self._running:
            now = time.time()
            for task in self._tasks:
                if now - task["last_run"] >= task["interval"]:
                    try:
                        task["func"](*task["args"], **task["kwargs"])
                    except Exception:
                        pass
                    task["last_run"] = now
            time.sleep(0.1)
    
    def start(self):
        self._running = True
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
    
    def stop(self):
        self._running = False
        if self._thread:
            self._thread.join(timeout=1)


class EventManager:
    def __init__(self):
        self._events = {}
        self._lock = threading.Lock()
    
    def on(self, event_name, callback):
        with self._lock:
            if event_name not in self._events:
                self._events[event_name] = []
            self._events[event_name].append(callback)
    
    def off(self, event_name, callback=None):
        with self._lock:
            if event_name in self._events:
                if callback:
                    self._events[event_name] = [c for c in self._events[event_name] if c != callback]
                else:
                    del self._events[event_name]
    
    def emit(self, event_name, *args, **kwargs):
        with self._lock:
            if event_name in self._events:
                for callback in self._events[event_name]:
                    try:
                        callback(*args, **kwargs)
                    except Exception:
                        pass
    
    def clear(self):
        with self._lock:
            self._events.clear()


class ConfigManager:
    def __init__(self, config_path=None):
        if config_path is None:
            config_path = os.path.join(os.path.expanduser("~"), ".winhelper", "config.json")
        self._config_path = config_path
        self._config = {}
        self._load()
    
    def _load(self):
        try:
            if os.path.exists(self._config_path):
                with open(self._config_path, "r") as f:
                    self._config = json.load(f)
        except Exception:
            self._config = {}
    
    def _save(self):
        try:
            os.makedirs(os.path.dirname(self._config_path), exist_ok=True)
            with open(self._config_path, "w") as f:
                json.dump(self._config, f, indent=2)
        except Exception:
            pass
    
    def get(self, key, default=None):
        return self._config.get(key, default)
    
    def set(self, key, value):
        self._config[key] = value
        self._save()
    
    def delete(self, key):
        if key in self._config:
            del self._config[key]
            self._save()
    
    def clear(self):
        self._config.clear()
        self._save()
    
    def keys(self):
        return list(self._config.keys())
    
    def items(self):
        return list(self._config.items())
    
    def values(self):
        return list(self._config.values())


class Logger:
    def __init__(self, name="WinHelper", log_file=None, level=logging.INFO):
        self._logger = logging.getLogger(name)
        self._logger.setLevel(level)
        if log_file:
            handler = logging.FileHandler(log_file)
        else:
            handler = logging.StreamHandler()
        handler.setLevel(level)
        formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
        handler.setFormatter(formatter)
        self._logger.addHandler(handler)
        self._logger.propagate = False
    
    def debug(self, message):
        self._logger.debug(message)
    
    def info(self, message):
        self._logger.info(message)
    
    def warning(self, message):
        self._logger.warning(message)
    
    def error(self, message):
        self._logger.error(message)
    
    def critical(self, message):
        self._logger.critical(message)
    
    def exception(self, message):
        self._logger.exception(message)


def get_helper():
    return WinHelper()


def is_admin():
    return WinHelper().is_admin()


def run_as_admin(executable, arguments=None):
    return WinHelper().run_as_admin(executable, arguments)


def get_system_info():
    return WinHelper().get_system_info()


def get_memory_info():
    return WinHelper().get_memory_info()


def get_disk_info(drive=None):
    return WinHelper().get_disk_info(drive)


def get_all_drives():
    return WinHelper().get_all_drives()


def get_cpu_info():
    return WinHelper().get_cpu_info()


def get_network_info():
    return WinHelper().get_network_info()


def get_user_info():
    return WinHelper().get_user_info()


def get_environment_variables():
    return WinHelper().get_environment_variables()


def get_environment_variable(name):
    return WinHelper().get_environment_variable(name)


def set_environment_variable(name, value):
    return WinHelper().set_environment_variable(name, value)


def get_current_directory():
    return WinHelper().get_current_directory()


def set_current_directory(path):
    return WinHelper().set_current_directory(path)


def get_temp_directory():
    return WinHelper().get_temp_directory()


def create_temp_file(suffix="", prefix="tmp"):
    return WinHelper().create_temp_file(suffix, prefix)


def create_temp_directory(suffix="", prefix="tmp"):
    return WinHelper().create_temp_directory(suffix, prefix)


def file_exists(path):
    return WinHelper().file_exists(path)


def directory_exists(path):
    return WinHelper().directory_exists(path)


def path_exists(path):
    return WinHelper().path_exists(path)


def create_directory(path, parents=False):
    return WinHelper().create_directory(path, parents)


def delete_directory(path, recursive=False):
    return WinHelper().delete_directory(path, recursive)


def delete_file(path):
    return WinHelper().delete_file(path)


def move_file(src, dst):
    return WinHelper().move_file(src, dst)


def copy_file(src, dst):
    return WinHelper().copy_file(src, dst)


def copy_directory(src, dst):
    return WinHelper().copy_directory(src, dst)


def list_directory(path):
    return WinHelper().list_directory(path)


def read_file(path, encoding="utf-8"):
    return WinHelper().read_file(path, encoding)


def write_file(path, content, encoding="utf-8"):
    return WinHelper().write_file(path, content, encoding)


def read_file_binary(path):
    return WinHelper().read_file_binary(path)


def write_file_binary(path, content):
    return WinHelper().write_file_binary(path, content)


def hash_file(path, algorithm="sha256"):
    return WinHelper().hash_file(path, algorithm)


def find_files(directory, pattern):
    return WinHelper().find_files(directory, pattern)


def compress_file(src, dst, format="zip"):
    return WinHelper().compress_file(src, dst, format)


def decompress_file(src, dst=None):
    return WinHelper().decompress_file(src, dst)


def registry_key_exists(key, subkey):
    return WinHelper().registry_key_exists(key, subkey)


def registry_value_exists(key, subkey, value_name):
    return WinHelper().registry_value_exists(key, subkey, value_name)


def registry_read_value(key, subkey, value_name):
    return WinHelper().registry_read_value(key, subkey, value_name)


def registry_write_value(key, subkey, value_name, value):
    return WinHelper().registry_write_value(key, subkey, value_name, value)


def registry_delete_value(key, subkey, value_name):
    return WinHelper().registry_delete_value(key, subkey, value_name)


def registry_delete_key(key, subkey):
    return WinHelper().registry_delete_key(key, subkey)


def process_exists(pid):
    return WinHelper().process_exists(pid)


def get_process_by_name(name):
    return WinHelper().get_process_by_name(name)


def list_processes():
    return WinHelper().list_processes()


def start_process(executable, arguments=None):
    return WinHelper().start_process(executable, arguments)


def kill_process(pid, force=False):
    return WinHelper().kill_process(pid, force)


def kill_process_by_name(name, force=False):
    return WinHelper().kill_process_by_name(name, force)


def suspend_process(pid):
    return WinHelper().suspend_process(pid)


def resume_process(pid):
    return WinHelper().resume_process(pid)


def service_exists(service_name):
    return WinHelper().service_exists(service_name)


def list_services():
    return WinHelper().list_services()


def get_service_status(service_name):
    return WinHelper().get_service_status(service_name)


def start_service(service_name):
    return WinHelper().start_service(service_name)


def stop_service(service_name):
    return WinHelper().stop_service(service_name)


def restart_service(service_name):
    return WinHelper().restart_service(service_name)


def show_message_box(title, message, buttons="ok"):
    return WinHelper().show_message_box(title, message, buttons)


def show_error(title, message):
    return WinHelper().show_error(title, message)


def show_warning(title, message):
    return WinHelper().show_warning(title, message)


def show_info(title, message):
    return WinHelper().show_info(title, message)


def show_question(title, message):
    return WinHelper().show_question(title, message)


def get_clipboard_text():
    return WinHelper().get_clipboard_text()


def set_clipboard_text(text):
    return WinHelper().set_clipboard_text(text)


def clear_clipboard():
    return WinHelper().clear_clipboard()


def get_screen_resolution():
    return WinHelper().get_screen_resolution()


def lock_workstation():
    return WinHelper().lock_workstation()


def shutdown(force=False):
    return WinHelper().shutdown(force)


def restart(force=False):
    return WinHelper().restart(force)


def ping(host, count=4):
    return WinHelper().ping(host, count)


def get_host_by_name(name):
    return WinHelper().get_host_by_name(name)


def get_port_status(host, port):
    return WinHelper().get_port_status(host, port)


def get_mac_address():
    return WinHelper().get_mac_address()


def get_ip_addresses():
    return WinHelper().get_ip_addresses()


def flush_dns_cache():
    return WinHelper().flush_dns_cache()


def create_shortcut(target, shortcut_path):
    return WinHelper().create_shortcut(target, shortcut_path)


def get_special_folder(folder_name):
    return WinHelper().get_special_folder(folder_name)


def add_to_startup(name, executable):
    return WinHelper().add_to_startup(name, executable)


def remove_from_startup(name):
    return WinHelper().remove_from_startup(name)


def get_startup_programs():
    return WinHelper().get_startup_programs()


def generate_password(length=16):
    return WinHelper().generate_password(length)


def hash_password(password):
    return WinHelper().hash_password(password)


def verify_password(password, hashed):
    return WinHelper().verify_password(password, hashed)


def encode_base64(data):
    return WinHelper().encode_base64(data)


def decode_base64(data):
    return WinHelper().decode_base64(data)


def json_dumps(obj):
    return WinHelper().json_dumps(obj)


def json_loads(data):
    return WinHelper().json_loads(data)


def json_save(path, obj):
    return WinHelper().json_save(path, obj)


def json_load(path):
    return WinHelper().json_load(path)


def generate_uuid():
    return WinHelper().generate_uuid()


def validate_uuid(uuid_string):
    return WinHelper().validate_uuid(uuid_string)


def get_random_int(min_val, max_val):
    return WinHelper().get_random_int(min_val, max_val)


def get_random_choice(items):
    return WinHelper().get_random_choice(items)


def create_thread(target, args=()):
    return WinHelper().create_thread(target, args)


def get_thread_id():
    return WinHelper().get_thread_id()


def get_process_id():
    return WinHelper().get_process_id()


def get_cpu_usage():
    return WinHelper().get_cpu_usage()


def get_memory_usage():
    return WinHelper().get_memory_usage()


def get_disk_usage(drive=None):
    return WinHelper().get_disk_usage(drive)


def get_system_load():
    return WinHelper().get_system_load()