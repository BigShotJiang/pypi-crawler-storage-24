# DATOS_PESADOS

![PyPI](https://img.shields.io/pypi/v/datos_pesados)
![License](https://img.shields.io/badge/license-MIT-blue.svg)

> **prueba de curb**

## 📖 Descripción
Este proyecto fue generado automáticamente y está listo para ser utilizado en entornos de producción y pruebas.

## 🚀 Instalación
```bash
pip install datos_pesados
```

## 💻 Uso Básico
```python
import datos_pesados

# Añade tu código aquí
```

<p align='center'>
  <img src='https://raw.githubusercontent.com/photoview/photoview/master/screenshots/timeline.png' alt='prueba curb' width='700'>
</p>
