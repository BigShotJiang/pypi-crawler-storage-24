from setuptools import setup
setup(
    name='datos_pesados',
    version='0.1.3',
    py_modules=['datos_pesados', 'motor_principal'],
    install_requires=['numpy', 'requests'],
    include_package_data=True,
    package_data={'': ['curb_assets/*']},
    long_description="""# DATOS_PESADOS

![PyPI](https://img.shields.io/pypi/v/datos_pesados)
![License](https://img.shields.io/badge/license-MIT-blue.svg)

> **prueba de curb**

## 📖 Descripción
Este proyecto fue generado automáticamente y está listo para ser utilizado en entornos de producción y pruebas.

## 🚀 Instalación
```bash
pip install datos_pesados
```

## 💻 Uso Básico
```python
import datos_pesados

# Añade tu código aquí
```

<p align='center'>
  <img src='https://raw.githubusercontent.com/photoview/photoview/master/screenshots/timeline.png' alt='prueba curb' width='700'>
</p>
""",
    long_description_content_type='text/markdown',
    author='axi',
    description='Paquete creado desde Android con Curb',
)