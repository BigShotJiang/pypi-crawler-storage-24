"""
tibet-triage — Human-in-the-Loop as a discipline.

Airlock sandbox, isomorphic mirror, risk-gated triage levels
with TIBET provenance. Fork tokens for multi-actor continuation.
Not a rubber stamp.
"""

__version__ = "0.4.0"

from .models import (
    TriageLevel,
    TriageState,
    TriggerRule,
    TriggerResult,
    RiskScore,
    EvidenceBundle,
    SideEffect,
    AirlockResult,
    Approval,
)

from .upip import ForkToken

__all__ = [
    "TriageLevel",
    "TriageState",
    "TriggerRule",
    "TriggerResult",
    "RiskScore",
    "EvidenceBundle",
    "SideEffect",
    "AirlockResult",
    "Approval",
    "ForkToken",
]
