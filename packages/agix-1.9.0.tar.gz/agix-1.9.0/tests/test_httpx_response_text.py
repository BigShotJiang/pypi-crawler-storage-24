import httpx


def test_response_text_property_reads_bytes_as_utf8():
    response = httpx.Response(status_code=200, content="áéí".encode("utf-8"))

    assert response.text == "áéí"


def test_response_text_property_not_callable():
    response = httpx.Response(status_code=200, content=b"data")

    assert response.text == "data"
    # Acceso como atributo; invocarlo debe fallar para confirmar que es propiedad.
    try:
        response.text()  # type: ignore[operator]
    except TypeError:
        pass
    else:  # pragma: no cover - defensive
        raise AssertionError("La propiedad text no debería ser invocable")
