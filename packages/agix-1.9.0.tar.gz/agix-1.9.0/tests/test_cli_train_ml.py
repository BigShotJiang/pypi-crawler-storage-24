import argparse
import importlib

from agix.cli.commands import train_ml


def test_run_training_shows_hint_when_sklearn_missing(monkeypatch, capsys):
    """Se muestra un mensaje claro si falta la dependencia opcional ``ml``."""

    real_find_spec = importlib.util.find_spec

    def fake_find_spec(name, package=None):
        if name == "sklearn":
            return None
        return real_find_spec(name, package)

    monkeypatch.setattr(importlib.util, "find_spec", fake_find_spec)
    args = argparse.Namespace(model=None, incremental=False)

    train_ml.run_training(args)

    captured = capsys.readouterr()
    assert "extra `ml`" in captured.out
    assert "pip install \"agix[ml]\"" in captured.out
