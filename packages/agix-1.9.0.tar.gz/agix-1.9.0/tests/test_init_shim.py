import importlib
import sys
from pathlib import Path


def test_httpx_prefers_existing_installation(tmp_path, monkeypatch):
    modules_snapshot = sys.modules.copy()
    monkeypatch.setattr(sys, "modules", modules_snapshot)

    external_dir = tmp_path / "external"
    external_dir.mkdir()
    (external_dir / "httpx.py").write_text("ORIGIN = 'external_httpx'\n")

    monkeypatch.setattr(sys, "path", [str(external_dir), *sys.path])

    for name in ("httpx", "src.httpx"):
        sys.modules.pop(name, None)

    src_pkg = importlib.import_module("src")
    importlib.reload(src_pkg)

    imported_httpx = importlib.import_module("httpx")

    assert getattr(imported_httpx, "ORIGIN") == "external_httpx"
    assert str(external_dir) in (imported_httpx.__file__ or "")


def test_agix_uses_external_package_before_src(tmp_path, monkeypatch):
    modules_snapshot = sys.modules.copy()
    monkeypatch.setattr(sys, "modules", modules_snapshot)

    external_dir = tmp_path / "external_agix"
    agix_pkg = external_dir / "agix"
    agix_pkg.mkdir(parents=True)
    (agix_pkg / "__init__.py").write_text("ORIGIN = 'external_agix'\n")

    project_root = Path(__file__).resolve().parents[1]

    monkeypatch.setattr(
        sys,
        "path",
        [
            str(project_root),
            str(external_dir),
            str(project_root / "src"),
            *[
                path
                for path in sys.path
                if path not in {str(project_root), str(external_dir), str(project_root / "src")}
            ],
        ],
    )

    for name in ("agix", "src.agix"):
        sys.modules.pop(name, None)

    src_pkg = importlib.import_module("src")
    importlib.reload(src_pkg)

    imported_agix = importlib.import_module("agix")

    assert getattr(imported_agix, "ORIGIN") == "external_agix"
    assert str(agix_pkg) in (imported_agix.__file__ or "")
    assert "src.agix" not in sys.modules


def test_httpx_import_origin_is_not_local_shim():
    imported_httpx = importlib.import_module("httpx")
    module_path = Path(imported_httpx.__file__ or "").resolve()
    repo_src_httpx = (Path(__file__).resolve().parents[1] / "src" / "httpx").resolve()

    assert imported_httpx.__name__ == "httpx"
    assert not str(module_path).startswith(str(repo_src_httpx))
