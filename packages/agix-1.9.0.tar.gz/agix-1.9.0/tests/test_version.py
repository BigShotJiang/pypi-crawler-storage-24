# tests/test_version.py

import agix


def test_package_version_matches():
    assert agix.__version__ == "1.8.0"
