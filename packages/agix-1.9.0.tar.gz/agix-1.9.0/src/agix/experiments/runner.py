import importlib
from typing import TYPE_CHECKING, Callable, Iterable, List

from ..evaluation.metrics import EvaluationMetrics


if TYPE_CHECKING:  # pragma: no cover - solo para hints
    import pandas as pd


def _require_pandas():
    if importlib.util.find_spec("pandas") is None:  # pragma: no cover - flujo de error
        message = (
            "La generación de tablas de resultados requiere pandas. "
            "Instala el extra de datos con `pip install \"agix[data]\"` "
            "(pandas>=2.1,<2.3)."
        )
        raise ImportError(message)

    pd = importlib.import_module("pandas")
    return pd


class ExperimentRunner:
    """Ejecuta experimentos con múltiples agentes y entornos."""

    def __init__(
        self,
        agents: Iterable,
        environments: Iterable,
        metrics: Iterable[Callable] | None = None,
    ) -> None:
        self.agents = list(agents)
        self.environments = list(environments)
        if metrics is None:
            metrics = [
                EvaluationMetrics.average_reward,
                EvaluationMetrics.max_reward,
                EvaluationMetrics.std_reward,
                EvaluationMetrics.success_rate,
            ]
        self.metrics = list(metrics)

    def _run_episode(self, agent, env) -> float:
        obs = env.reset()
        done = False
        total_reward = 0.0
        while not done:
            if hasattr(agent, "perceive"):
                agent.perceive(obs)
            if hasattr(agent, "decide"):
                action = agent.decide()
            else:
                action = 0
            obs, reward, done, _ = env.step(action)
            if hasattr(agent, "learn"):
                agent.learn(reward, done)
            total_reward += reward
        if hasattr(agent, "reset"):
            agent.reset()
        return total_reward

    def run(self, episodes: int = 1) -> "pd.DataFrame":
        """Ejecuta todas las combinaciones y devuelve un DataFrame."""
        pd = _require_pandas()
        results: List[dict] = []
        for agent in self.agents:
            for env in self.environments:
                rewards = [self._run_episode(agent, env) for _ in range(episodes)]
                row = {
                    "agent": agent.__class__.__name__,
                    "environment": env.__class__.__name__,
                }
                for metric in self.metrics:
                    func = metric
                    name = func.__name__
                    try:
                        value = func(rewards)
                    except Exception:
                        try:
                            value = func(agent, [env])
                        except Exception:
                            value = None
                    row[name] = value
                results.append(row)
        return pd.DataFrame(results)
