
from .adapter import EducationAdapter
