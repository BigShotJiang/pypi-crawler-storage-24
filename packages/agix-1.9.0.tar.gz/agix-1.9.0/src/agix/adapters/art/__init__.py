
from .adapter import ArtAdapter
