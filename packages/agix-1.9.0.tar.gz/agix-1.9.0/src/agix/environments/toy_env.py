"""Entorno mínimo utilizado en ejemplos y pruebas rápidas."""

from __future__ import annotations

import numpy as np


class ToyEnvironment:
    """Entorno mínimo para simulaciones rápidas.

    Genera observaciones sencillas y recompensas deterministas para
    facilitar ejemplos de uso sin dependencias adicionales.
    """

    def __init__(self, obs_size: int = 10):
        self.obs_size = obs_size
        self.steps = 0
        self.max_steps = 5

    def reset(self):
        self.steps = 0
        return np.ones(self.obs_size)

    def step(self, action):
        self.steps += 1
        reward = 1.0 if action < 2 else -0.5
        done = self.steps >= self.max_steps
        return np.ones(self.obs_size), reward, done, {}


__all__ = ["ToyEnvironment"]
