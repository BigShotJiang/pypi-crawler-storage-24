
import numpy as np

from .base import SensorPlugin


class ImagePlugin(SensorPlugin):
    """Convierte listas de píxeles en arrays NumPy."""

    def process(self, raw_input):
        return np.asarray(raw_input)
