from __future__ import annotations


from typing import Any, Dict, Sequence, Set
import os
import secrets
import warnings

from fastapi import (
    Depends,
    FastAPI,
    Header,
    HTTPException,
    WebSocket,
    WebSocketDisconnect,
    status,
)
from pydantic import BaseModel, ConfigDict, Field
from ..qualia.constants import QUALIA_WS_PATH
from ..qualia.qualia_engine import QualiaEngine
from ..memory.experiential import GestorDeMemoria
import uvicorn


class RegisterPayload(BaseModel):
    model_config = ConfigDict(extra="forbid")
    name: str
    metadata: Dict[str, Any] = Field(default_factory=dict)


class EventPayload(BaseModel):
    model_config = ConfigDict(extra="forbid")
    event: str


class QualiaPayload(BaseModel):
    model_config = ConfigDict(extra="forbid")
    input: list[float] = Field(default_factory=list)
    internal: list[float] = Field(default_factory=list)


def _load_api_token() -> str:
    token = os.getenv("AGIX_API_TOKEN")
    if token:
        return token

    generated = secrets.token_urlsafe(32)
    try:
        warnings.warn(
            "AGIX_API_TOKEN no está definido. Se ha generado un token temporal. "
            "Establece la variable de entorno AGIX_API_TOKEN con un valor seguro "
            "antes de iniciar el hub para evitar este comportamiento.",
            RuntimeWarning,
            stacklevel=2,
        )
    except Exception:
        pass
    return generated


API_TOKEN = _load_api_token()


def _token_from_authorization_header(authorization: str | None) -> str | None:
    if not authorization:
        return None
    scheme, _, token = authorization.partition(" ")
    if scheme.lower() != "bearer" or not token:
        return None
    return token


def verify_token(authorization: str | None = Header(default=None)) -> None:
    token = _token_from_authorization_header(authorization)
    if token is None or not secrets.compare_digest(token, API_TOKEN):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token")


class QualiaHub:
    """Orquestador central de módulos AGIX."""

    def __init__(self) -> None:
        self.modules: Dict[str, Dict[str, Any]] = {}
        self.app = FastAPI(title="Qualia Hub")
        try:
            self.engine: Any = QualiaEngine(GestorDeMemoria())
        except Exception:
            try:
                self.engine = QualiaEngine(GestorDeMemoria(), backend="jax")
            except Exception:
                import numpy as np

                class _NumpyEngine:
                    def __init__(self, memory):
                        self.memory = memory
                        self._lib = np

                    def generate_state(self, input_data, internal_state):
                        a = np.asarray(input_data, dtype=float)
                        b = np.asarray(internal_state, dtype=float)
                        return a + b

                self.engine = _NumpyEngine(GestorDeMemoria())
        self.current_state: Any | None = None
        self.clients: Set[WebSocket] = set()
        self._setup_routes()

    # ------------------------------------------------------------------
    def _setup_routes(self) -> None:
        @self.app.post("/register")
        def _register(payload: RegisterPayload, _: None = Depends(verify_token)):
            name = payload.name
            metadata = payload.metadata
            if name:
                self.register_module(name, metadata)
            return {"status": "ok"}

        @self.app.get("/modules")
        def _modules(_: None = Depends(verify_token)):
            return {"modules": self.modules}

        @self.app.post("/event")
        def _event(payload: EventPayload, _: None = Depends(verify_token)):
            event = payload.event
            self.broadcast_event(event)
            return {"status": "ok"}

        @self.app.post("/qualia")
        async def _process(payload: QualiaPayload, _: None = Depends(verify_token)):
            data = payload.input
            state = payload.internal
            qualia = self.process_input(data, state)
            message = {"qualia": self._as_list(qualia)}
            for client in list(self.clients):
                try:
                    await client.send_json(message)
                except Exception:
                    self.clients.discard(client)
            return message

        @self.app.get("/qualia")
        def _get_state(_: None = Depends(verify_token)):
            return {"qualia": self._as_list(self.current_state)}

        @self.app.get("/health")
        def _health():
            return {"status": "ok"}

        @self.app.websocket(QUALIA_WS_PATH)
        async def _ws(ws: WebSocket):
            token = _token_from_authorization_header(ws.headers.get("authorization"))
            if token is None or not secrets.compare_digest(token, API_TOKEN):
                await ws.close(code=1008)
                return
            await ws.accept()
            self.clients.add(ws)
            if self.current_state is not None:
                await ws.send_json({"qualia": self._as_list(self.current_state)})
            try:
                while True:
                    await ws.receive_text()
            except WebSocketDisconnect:
                self.clients.discard(ws)

    # ------------------------------------------------------------------
    def register_module(self, name: str, metadata: Dict[str, Any]) -> None:
        """Registra un módulo junto a sus metadatos."""
        self.modules[name] = metadata

    def get_modules(self) -> Dict[str, Dict[str, Any]]:
        """Devuelve la tabla de módulos registrados."""
        return self.modules

    def broadcast_event(self, event: str) -> None:
        """Difunde un evento a los módulos registrados (solo log)."""
        print(f"Evento difundido: {event}")

    def process_input(
        self, input_data: Sequence[float], internal_state: Sequence[float]
    ) -> Any:
        """Genera y almacena un estado de cualia a partir de los datos."""
        self.current_state = self.engine.generate_state(input_data, internal_state)
        return self.current_state

    def apply_to_behavior(self, agix_agent: Any) -> None:
        """Ajusta el comportamiento del agente según el estado de cualia."""
        if self.current_state is None:
            return
        try:
            mean_val = float(self.engine._lib.mean(self.current_state))
        except Exception:
            mean_val = 0.0
        agix_agent.internal_state["qualia_intensity"] = mean_val
        if hasattr(agix_agent, "feel"):
            try:
                agix_agent.feel("qualia", abs(mean_val), "curiosidad")
            except Exception:
                pass

    # ------------------------------------------------------------------
    def _as_list(self, tensor: Any | None) -> list[float]:
        """Convierte el tensor a lista para ser serializado."""
        if tensor is None:
            return []
        try:
            data = tensor.tolist()  # type: ignore[assignment]
        except Exception:
            data = tensor
        if isinstance(data, list):
            return [float(x) for x in data]
        try:
            return [float(data)]  # type: ignore[arg-type]
        except Exception:
            return []

    def run(self, host: str = "127.0.0.1", port: int = 9000, emotion: bool = False) -> None:
        """Arranca el servidor HTTP de QualiaHub o del EmotionHub."""
        if emotion:
            from .emotion_hub import EmotionHub

            EmotionHub().run(host=host, port=port)
            return
        uvicorn.run(self.app, host=host, port=port)
