"""Submódulos especializados disponibles en :mod:`agix.modules`.

Se evita importar los paquetes pesados (por ejemplo ``torch``) hasta que se
solicitan explícitamente, lo que permite usar partes livianas del paquete sin
depender de librerías externas opcionales.
"""


from importlib import import_module
from typing import TYPE_CHECKING

__all__ = ["neuroinspired", "temporal_inrf"]

if TYPE_CHECKING:  # pragma: no cover - sólo para comprobación estática
    from . import neuroinspired, temporal_inrf


def __getattr__(name: str):
    if name in __all__:
        return import_module(f"{__name__}.{name}")
    raise AttributeError(name)
