from __future__ import annotations

import importlib
import sys

import numpy as np
from typing import Any, Sequence

from ..memory.experiential import GestorDeMemoria, Experiencia


def _module_available(name: str) -> bool:
    try:
        return importlib.util.find_spec(name) is not None
    except ValueError:
        return name in sys.modules


class QualiaEngine:
    """Motor para generar estados cualitativos a partir de entradas y memoria."""

    def __init__(self, memory: GestorDeMemoria, backend: str = "torch") -> None:
        """Inicializa el motor con un estado de memoria y un backend de tensores.

        Parameters
        ----------
        memory:
            Referencia al estado de memoria del agente.
        backend:
            Nombre del backend a utilizar. Debe ser ``"torch"`` o ``"jax"``.
        """
        self.memory = memory
        self.experience_state: list[Experiencia] = []
        selected_backend = backend.lower().strip()

        if selected_backend == "torch":
            if not _module_available("torch"):
                raise ImportError(
                    "El backend 'torch' de QualiaEngine requiere PyTorch. "
                    "Instala el extra opcional con `pip install \"agix[neuro]\"` "
                    "(torch>=2.2,<2.7)."
                )
            self.backend = "torch"
            self._lib = importlib.import_module("torch")
        elif selected_backend == "jax":
            if not _module_available("jax"):
                raise ImportError(
                    "El backend 'jax' de QualiaEngine requiere JAX. "
                    "Instala el extra opcional con `pip install \"agix[neuro_jax]\"` "
                    "(jax>=0.4.28,<0.6)."
                )
            self.backend = "jax"
            self._lib = importlib.import_module("jax.numpy")
        else:  # pragma: no cover - validación de entrada
            raise ValueError("backend debe ser 'torch' o 'jax'")

    # ------------------------------------------------------------------
    def _to_tensor(self, data: Sequence[float]) -> Any:
        """Convierte los datos a un tensor del backend seleccionado."""
        if self.backend == "torch":
            tensor_ctor = getattr(self._lib, "tensor", None)
            if callable(tensor_ctor):
                return tensor_ctor(data)
            asarray_ctor = getattr(self._lib, "asarray", None)
            if callable(asarray_ctor):
                return asarray_ctor(data)
            return np.asarray(data, dtype=float)
        return self._lib.asarray(data)

    def generate_state(self, input_data: Sequence[float], internal_state: Sequence[float]) -> Any:
        """Genera un tensor que representa la experiencia subjetiva.

        Combina los datos de entrada con el estado interno. Si la memoria
        proporciona un método ``store_experience``, el resultado se almacena.
        """
        input_tensor = self._to_tensor(input_data)
        state_tensor = self._to_tensor(internal_state)
        experience = input_tensor + state_tensor

        if hasattr(self.memory, "store_experience"):
            try:  # pragma: no cover - la memoria es opcional
                self.memory.store_experience(experience)
            except Exception:
                pass
        return experience

    def update_from_memory(self, n: int = 5) -> None:
        """Incorpora experiencias recientes de la memoria al estado interno."""
        if hasattr(self.memory, "obtener_recientes"):
            recientes = self.memory.obtener_recientes(n)
            conocidas = {e.firma for e in self.experience_state if e.firma}
            for exp in recientes:
                if exp.firma not in conocidas:
                    self.experience_state.append(exp)

    # ------------------------------------------------------------------
    def encode_integrated_info(
        self, symbolic_repr: Sequence[float], affective_repr: Sequence[float]
    ) -> tuple[Any, dict[str, Any]]:
        """Fusiona representaciones simbólica y afectiva en un tensor."""

        symbolic_tensor = self._to_tensor(symbolic_repr)
        affective_tensor = self._to_tensor(affective_repr)

        if symbolic_tensor.shape != affective_tensor.shape:
            raise ValueError("Las representaciones deben tener la misma longitud")

        stack_fn = getattr(self._lib, "stack", None)
        if callable(stack_fn):
            fused = stack_fn((symbolic_tensor, affective_tensor))
        else:
            fused = np.stack((symbolic_tensor, affective_tensor))
        metadata = {"channels": ["symbolic", "affective"]}
        return fused, metadata
