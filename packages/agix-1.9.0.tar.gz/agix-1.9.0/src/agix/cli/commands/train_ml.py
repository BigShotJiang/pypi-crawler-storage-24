# src/agix/cli/commands/train_ml.py
"""Subcomando para entrenar modelos de aprendizaje automático."""

import argparse
import importlib
from typing import Optional

import numpy as np

from ...config import MODEL_REGISTRY, DEFAULT_MODEL


def _load_sgd_classifier():
    if importlib.util.find_spec("sklearn") is None:
        print(
            "scikit-learn no está instalado. Instala el extra `ml` con "
            "`pip install \"agix[ml]\"` (scikit-learn>=1.4,<1.6)."
        )
        return None

    sklearn_linear_model = importlib.import_module("sklearn.linear_model")
    return getattr(sklearn_linear_model, "SGDClassifier")


def run_training(args: argparse.Namespace) -> None:
    """Entrena un modelo simple de ML según la configuración."""
    SGDClassifier = _load_sgd_classifier()
    if SGDClassifier is None:
        return

    model_key = args.model or DEFAULT_MODEL
    model_key = model_key.lower()
    learner_cls = MODEL_REGISTRY.get(model_key)
    if learner_cls is None:
        print(f"Modelo '{model_key}' no reconocido. Opciones: {list(MODEL_REGISTRY.keys())}")
        return

    estimator = SGDClassifier(max_iter=5)
    learner = learner_cls(estimator)

    X = np.array([[0], [1], [2], [3]])
    y = np.array([0, 0, 1, 1])

    if args.incremental:
        learner.train_incremental(X, y, classes=np.array([0, 1]))
    else:
        learner.train(X, y)

    preds = learner.predict(X)
    print(f"Predicciones: {preds.tolist()}")


def build_parser(parser: Optional[argparse.ArgumentParser] = None) -> argparse.ArgumentParser:
    """Construye el parser para ``train_ml``."""
    if parser is None:
        parser = argparse.ArgumentParser(description="Entrena un modelo de ML")

    parser.add_argument(
        "--model",
        type=str,
        default=DEFAULT_MODEL,
        help="Nombre del modelo definido en config.py",
    )
    parser.add_argument(
        "--incremental",
        action="store_true",
        help="Usar entrenamiento incremental si el modelo lo permite",
    )

    return parser


__all__ = ["run_training", "build_parser"]
