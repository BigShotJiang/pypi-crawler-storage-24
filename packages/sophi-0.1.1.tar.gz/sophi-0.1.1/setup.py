from setuptools import setup, find_packages

setup(
    name='sophi',
    version='0.1.0',
    description='Balance-based non-custodial swap language for Bitcoin',
    author='Eduardo de Figueiredo',
    packages=find_packages(),
    entry_points={
        'console_scripts': [
            'sophi=sophi.cli:main',
        ]
    },
    python_requires='>=3.9',
)
