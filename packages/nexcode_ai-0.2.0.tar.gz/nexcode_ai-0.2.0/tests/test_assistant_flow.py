from pathlib import Path

import pytest
from rich.table import Table

from nexcode import agent, config, utils
from nexcode.agent_runtime.planner import _finalize_fix_plan
from nexcode.agent_runtime.reporter import _normalize_submit_report_args
from nexcode.agent_runtime.token_utils import UsageData
from nexcode.agent_runtime.workspace import load_agent_state, save_agent_state
from nexcode.tools.shell_tools import CommandRunResult


def _make_workspace(tmp_path: Path) -> Path:
    workspace = tmp_path / "demo"
    (workspace / ".agent").mkdir(parents=True)
    (workspace / "project").mkdir(parents=True)
    return workspace


@pytest.fixture
def captured_agent_prints(monkeypatch):
    calls = []

    def _capture(*args, **kwargs):
        calls.append(args)

    monkeypatch.setattr(agent.console, "print", _capture)
    return calls


def test_load_agent_state_applies_new_assistant_defaults(tmp_path):
    workspace = _make_workspace(tmp_path)

    save_agent_state(workspace, {"original_prompt": "demo", "current_step": 1, "completed_steps": [], "plan": []})
    state = load_agent_state(workspace)

    assert state["pending_clarification"]["active"] is False
    assert state["pending_clarification"]["question"] == ""
    assert state["pending_workspace_decision"]["active"] is False
    assert state["last_resolution_type"] == ""
    assert state["last_user_goal"] == ""
    assert state["last_execution"]["status"] == ""
    assert state["last_execution"]["full_output_chars"] == 0
    assert state["recent_targets"] == []


def test_need_more_info_persists_pending_clarification(tmp_path, monkeypatch, captured_agent_prints):
    workspace = _make_workspace(tmp_path)
    save_agent_state(workspace, {"original_prompt": "demo app", "fix_history": [], "plan": []})

    def fake_run_investigation(**kwargs):
        return {
            "is_question": True,
            "resolution_type": "need_more_info",
            "issue_category": "unknown",
            "user_instructions": "Which route or command is failing?",
            "report": "I need the exact failing route to update the correct handler.",
            "scratchpad": "- need the failing route",
            "complexity": "simple",
            "confidence": "medium",
            "checked_files": ["src/server/router.py"],
            "needs_plan_preview": False,
            "clarification_reason": "I need the exact failing route to update the correct handler.",
        }

    monkeypatch.setattr("nexcode.agent_runtime.reporter.run_investigation", fake_run_investigation)

    agent._run_assistant_turn(workspace, "demo", "Fix the login bug", verbose=False, image_urls=None)
    state = load_agent_state(workspace)

    assert state["pending_clarification"]["active"] is True
    assert state["pending_clarification"]["question"] == "Which route or command is failing?"
    assert "exact failing route" in state["pending_clarification"]["reason"]
    assert state["last_resolution_type"] == "need_more_info"
    assert state["last_user_goal"] == "Fix the login bug"
    assert "Why I need it:" in state["fix_history"][-1]["outcome"]
    assert any("Need more info" in str(arg) for call in captured_agent_prints for arg in call)


def test_follow_up_answer_reuses_pending_clarification_context(tmp_path, monkeypatch):
    workspace = _make_workspace(tmp_path)
    save_agent_state(
        workspace,
        {
            "original_prompt": "demo app",
            "fix_history": [{"prompt": "Fix login", "outcome": "Which route is failing?"}],
            "plan": [],
            "last_user_goal": "Fix login",
            "pending_clarification": {
                "active": True,
                "question": "Which route is failing?",
                "reason": "I need the route to update the correct handler.",
                "requested_at_utc": "2026-03-18T00:00:00Z",
                "last_report": "Need route",
            },
        },
    )

    captured = {}

    def fake_run_investigation(**kwargs):
        captured["prompt"] = kwargs["prompt"]
        return {
            "is_question": True,
            "resolution_type": "answer_only",
            "issue_category": "unknown",
            "user_instructions": "The issue is isolated to the mobile login route.",
            "report": "The issue is isolated to the mobile login route.",
            "scratchpad": "",
            "complexity": "simple",
            "confidence": "high",
            "checked_files": ["src/server/router.py"],
            "needs_plan_preview": False,
            "clarification_reason": "",
        }

    monkeypatch.setattr("nexcode.agent_runtime.reporter.run_investigation", fake_run_investigation)
    monkeypatch.setattr("nexcode.agent_runtime.planner.generate_plan", lambda *args, **kwargs: pytest.fail("planner should not run"))
    monkeypatch.setattr("nexcode.agent_runtime.executor.execute_plan", lambda *args, **kwargs: pytest.fail("executor should not run"))

    agent._run_assistant_turn(workspace, "demo", "It only fails on mobile Safari.", verbose=False, image_urls=None)
    state = load_agent_state(workspace)

    assert "Original unresolved goal: Fix login" in captured["prompt"]
    assert "Clarification requested: Which route is failing?" in captured["prompt"]
    assert "Latest user reply: It only fails on mobile Safari." in captured["prompt"]
    assert state["pending_clarification"]["active"] is False
    assert state["last_resolution_type"] == "answer_only"


def test_casual_chat_turn_preserves_pending_clarification_and_skips_investigation(tmp_path, monkeypatch, captured_agent_prints):
    workspace = _make_workspace(tmp_path)
    save_agent_state(
        workspace,
        {
            "original_prompt": "demo app",
            "fix_history": [
                {
                    "prompt": "Fix login",
                    "outcome": "What I changed:\nUpdated the login handler.",
                    "resolution_type": "code_change",
                    "context_scope": "implementation",
                }
            ],
            "plan": [],
            "last_resolution_type": "need_more_info",
            "last_user_goal": "Fix login",
            "pending_clarification": {
                "active": True,
                "question": "Which route is failing?",
                "reason": "I need the route to update the correct handler.",
                "requested_at_utc": "2026-03-18T00:00:00Z",
                "last_report": "Need route",
            },
        },
    )
    monkeypatch.setattr("nexcode.config.load_access", lambda: {"api_key": "", "endpoint": "", "provider": "grok"})

    agent._run_current_workspace_turn(workspace, "demo", "thanks buddy", verbose=True, image_urls=None)
    state = load_agent_state(workspace)
    rendered = "\n".join(" ".join(str(arg) for arg in call) for call in captured_agent_prints)

    assert state["pending_clarification"]["active"] is True
    assert state["pending_clarification"]["question"] == "Which route is failing?"
    assert state["last_resolution_type"] == "answer_only"
    assert state["last_user_goal"] == "Fix login"
    assert state["fix_history"][-1]["prompt"] == "thanks buddy"
    assert state["fix_history"][-1]["context_scope"] == "casual_chat"
    assert "What I checked:" not in state["fix_history"][-1]["outcome"]
    assert "investigation" not in state["fix_history"][-1]["outcome"].lower()
    assert "Routing" in rendered
    assert "casual_chat" in rendered
    assert "Investigation" not in rendered


def test_answer_only_skips_planner_and_executor(tmp_path, monkeypatch):
    workspace = _make_workspace(tmp_path)
    save_agent_state(workspace, {"original_prompt": "demo", "fix_history": [], "plan": []})
    called = {"planner": False, "executor": False}

    def fake_run_investigation(**kwargs):
        return {
            "is_question": True,
            "resolution_type": "answer_only",
            "issue_category": "unknown",
            "user_instructions": "This behavior is already implemented.",
            "report": "This behavior is already implemented.",
            "scratchpad": "",
            "complexity": "simple",
            "confidence": "high",
            "checked_files": ["src/app.py"],
            "needs_plan_preview": False,
            "clarification_reason": "",
        }

    monkeypatch.setattr("nexcode.agent_runtime.reporter.run_investigation", fake_run_investigation)
    monkeypatch.setattr("nexcode.agent_runtime.planner.generate_plan", lambda *args, **kwargs: called.__setitem__("planner", True))
    monkeypatch.setattr("nexcode.agent_runtime.executor.execute_plan", lambda *args, **kwargs: called.__setitem__("executor", True))

    agent._run_assistant_turn(workspace, "demo", "Is dark mode already wired?", verbose=False, image_urls=None)

    assert called["planner"] is False
    assert called["executor"] is False


def test_suggestion_prompt_routes_to_consult_only_without_execution(tmp_path, monkeypatch):
    workspace = _make_workspace(tmp_path)
    save_agent_state(workspace, {"original_prompt": "demo", "fix_history": [], "plan": []})
    captured = {"routing_mode": "", "planner": False, "executor": False}

    def fake_run_investigation(**kwargs):
        captured["routing_mode"] = kwargs["routing_mode"]
        return {
            "is_question": True,
            "resolution_type": "answer_only",
            "issue_category": "ui",
            "user_instructions": "Add social proof and a product comparison section.",
            "report": "Add social proof and a product comparison section.",
            "scratchpad": "",
            "complexity": "simple",
            "confidence": "high",
            "checked_files": ["src/app/page.tsx"],
            "needs_plan_preview": False,
            "clarification_reason": "",
        }

    monkeypatch.setattr("nexcode.agent_runtime.reporter.run_investigation", fake_run_investigation)
    monkeypatch.setattr("nexcode.agent_runtime.planner.generate_plan", lambda *args, **kwargs: captured.__setitem__("planner", True))
    monkeypatch.setattr("nexcode.agent_runtime.executor.execute_plan", lambda *args, **kwargs: captured.__setitem__("executor", True))

    agent._run_assistant_turn(workspace, "demo", "What else can we add to the landing page?", verbose=False, image_urls=None)

    assert captured["routing_mode"] == "consult_only"
    assert captured["planner"] is False
    assert captured["executor"] is False


def test_landing_page_suggestion_regression_stays_consult_only(tmp_path, monkeypatch):
    workspace = _make_workspace(tmp_path)
    save_agent_state(workspace, {"original_prompt": "finance app", "fix_history": [], "plan": []})
    calls = []

    def fake_run_investigation(**kwargs):
        calls.append((kwargs["prompt"], kwargs["routing_mode"]))
        return {
            "is_question": True,
            "resolution_type": "answer_only",
            "issue_category": "ui",
            "user_instructions": "You could add testimonials, pricing, and FAQ sections.",
            "report": "You could add testimonials, pricing, and FAQ sections.",
            "scratchpad": "",
            "complexity": "simple",
            "confidence": "high",
            "checked_files": ["src/app/page.tsx"],
            "needs_plan_preview": False,
            "clarification_reason": "",
        }

    monkeypatch.setattr("nexcode.agent_runtime.reporter.run_investigation", fake_run_investigation)
    monkeypatch.setattr("nexcode.agent_runtime.planner.generate_plan", lambda *args, **kwargs: pytest.fail("planner should not run"))
    monkeypatch.setattr("nexcode.agent_runtime.executor.execute_plan", lambda *args, **kwargs: pytest.fail("executor should not run"))

    agent._run_assistant_turn(workspace, "finance", "thankyou so much and what else can we add to the landing page?", verbose=False, image_urls=None)

    assert calls == [("thankyou so much and what else can we add to the landing page?", "consult_only")]


def test_mixed_prompt_splits_suggestions_and_implementation(tmp_path, monkeypatch):
    workspace = _make_workspace(tmp_path)
    save_agent_state(workspace, {"original_prompt": "demo", "fix_history": [], "plan": []})
    calls = {"reporter": [], "planner": 0, "executor": 0}

    def fake_run_investigation(**kwargs):
        calls["reporter"].append((kwargs["prompt"], kwargs["routing_mode"]))
        if kwargs["routing_mode"] == "consult_only":
            return {
                "is_question": True,
                "resolution_type": "answer_only",
                "issue_category": "ui",
                "user_instructions": "Add a comparison table and customer logos.",
                "report": "Add a comparison table and customer logos.",
                "scratchpad": "",
                "complexity": "simple",
                "confidence": "high",
                "checked_files": ["src/app/page.tsx"],
                "needs_plan_preview": False,
                "clarification_reason": "",
            }
        return {
            "is_question": False,
            "resolution_type": "code_change",
            "issue_category": "ui",
            "user_instructions": "",
            "report": "Add a testimonials section to the landing page.",
            "scratchpad": "",
            "complexity": "simple",
            "confidence": "high",
            "checked_files": ["src/app/page.tsx"],
            "needs_plan_preview": False,
            "clarification_reason": "",
        }

    def fake_generate_plan(*args, **kwargs):
        calls["planner"] += 1
        return [
            {
                "step": 1,
                "task": "Add testimonials to the landing page",
                "goal": "Improve trust on the landing page",
                "rationale": "The user explicitly asked to add testimonials.",
                "files": ["src/app/page.tsx"],
                "type": "implementation",
                "design_notes": "",
            }
        ]

    monkeypatch.setattr("nexcode.agent_runtime.reporter.run_investigation", fake_run_investigation)
    monkeypatch.setattr("nexcode.agent_runtime.planner.generate_plan", fake_generate_plan)
    monkeypatch.setattr("nexcode.agent_runtime.executor.execute_plan", lambda *args, **kwargs: calls.__setitem__("executor", calls["executor"] + 1))
    monkeypatch.setattr("nexcode.config.load_access", lambda: {"api_key": "test", "endpoint": "https://example.com", "model": "demo"})
    monkeypatch.setattr("nexcode.config.load_agent_config", lambda *args, **kwargs: {"model": "demo", "assistant_intent_mode": "conservative"})
    monkeypatch.setattr(
        "nexcode.agent_runtime.planner._call_gateway",
        lambda *args, **kwargs: (
            "What I changed:\nAdded testimonials.\n\nWhy it should work:\nThis adds social proof.\n\nHow to verify:\nOpen the landing page.\n\nRemaining risk:\nnone noted.",
            UsageData(),
        ),
    )

    agent._run_assistant_turn(workspace, "demo", "What else can we add, and add testimonials", verbose=False, image_urls=None)
    state = load_agent_state(workspace)

    assert calls["planner"] == 1
    assert calls["executor"] == 1
    assert calls["reporter"][0][1] == "consult_only"
    assert calls["reporter"][1][1] == "implementation"
    assert "Suggestions:" in state["fix_history"][-1]["outcome"]
    assert "Implementation update:" in state["fix_history"][-1]["outcome"]


def test_explicit_create_request_respects_reporter_answer_only(tmp_path, monkeypatch, captured_agent_prints):
    workspace = _make_workspace(tmp_path)
    save_agent_state(workspace, {"original_prompt": "demo", "fix_history": [], "plan": []})
    captured = {}

    pasted_code = (
        "Create a new Python file named `linked_list_cycle.py` in the root directory.\n\n"
        "The file should contain:\n\n"
        "```python\n"
        "class Solution:\n"
        "    def hasCycle(self, head):\n"
        "        return False\n"
        "```"
    )

    monkeypatch.setattr(
        "nexcode.agent_runtime.reporter.run_investigation",
        lambda **kwargs: {
            "is_question": True,
            "resolution_type": "answer_only",
            "issue_category": "unknown",
            "user_instructions": pasted_code,
            "report": pasted_code,
            "scratchpad": "- linked list cycle solution",
            "complexity": "simple",
            "confidence": "high",
            "checked_files": ["."],
            "needs_plan_preview": False,
            "clarification_reason": "",
        },
    )
    monkeypatch.setattr("nexcode.agent_runtime.planner.generate_plan", lambda *args, **kwargs: pytest.fail("planner should not run"))

    agent._run_assistant_turn(
        workspace,
        "demo",
        "can you create a python file that solves the leet code problem of finding is the linkedlist is loop or not?",
        verbose=True,
        image_urls=None,
    )

    state = load_agent_state(workspace)
    assert state["last_resolution_type"] == "answer_only"
    assert "Create a new Python file named" in state["fix_history"][-1]["outcome"]
    assert not any("Routing override" in str(arg) for call in captured_agent_prints for arg in call)


def test_explicit_update_request_respects_reporter_user_action_only(tmp_path, monkeypatch):
    workspace = _make_workspace(tmp_path)
    save_agent_state(workspace, {"original_prompt": "demo", "fix_history": [], "plan": []})
    captured = {}

    monkeypatch.setattr(
        "nexcode.agent_runtime.reporter.run_investigation",
        lambda **kwargs: {
            "is_question": True,
            "resolution_type": "user_action_only",
            "issue_category": "unknown",
            "user_instructions": (
                "Update `handlers_scan.go` with the following logic:\n\n"
                "```go\n"
                "if scan == nil { return nil }\n"
                "```"
            ),
            "report": "Update `handlers_scan.go` with the nil guard.",
            "scratchpad": "- nil guard belongs in handlers_scan.go",
            "complexity": "simple",
            "confidence": "high",
            "checked_files": ["handlers_scan.go"],
            "needs_plan_preview": False,
            "clarification_reason": "",
        },
    )
    monkeypatch.setattr("nexcode.agent_runtime.planner.generate_plan", lambda *args, **kwargs: pytest.fail("planner should not run"))

    agent._run_assistant_turn(
        workspace,
        "demo",
        "please update handlers_scan.go to guard nil scan values",
        verbose=False,
        image_urls=None,
    )

    state = load_agent_state(workspace)
    assert state["last_resolution_type"] == "user_action_only"
    assert "Update `handlers_scan.go`" in state["fix_history"][-1]["outcome"]


def test_reporter_code_change_marked_as_question_still_executes_code_change_turn(tmp_path, monkeypatch):
    workspace = _make_workspace(tmp_path)
    save_agent_state(workspace, {"original_prompt": "demo", "fix_history": [], "plan": []})
    captured = {}

    monkeypatch.setattr(
        "nexcode.agent_runtime.reporter.run_investigation",
        lambda **kwargs: {
            "is_question": True,
            "resolution_type": "code_change",
            "issue_category": "unknown",
            "user_instructions": (
                "The user requested a Python file for linked list cycle detection.\n\n"
                "Instruct the Fix Planner to create a new file named `linked_list_cycle.py` "
                "in the root directory with the following content:\n\n"
                "```python\n"
                "class Solution:\n"
                "    def hasCycle(self, head):\n"
                "        return False\n"
                "```"
            ),
            "report": "Create `linked_list_cycle.py` with a Floyd cycle-detection solution.",
            "scratchpad": "- linked list cycle solution",
            "complexity": "simple",
            "confidence": "high",
            "checked_files": ["."],
            "needs_plan_preview": False,
            "clarification_reason": "",
        },
    )
    monkeypatch.setattr(
        agent,
        "_run_code_change_turn",
        lambda **kwargs: captured.update({"investigation_result": kwargs["investigation_result"]}),
    )

    agent._run_assistant_turn(
        workspace,
        "demo",
        "can you create a python file that solves the leet code problem of finding is the linkedlist is loop or not?",
        verbose=False,
        image_urls=None,
    )

    result = captured["investigation_result"]
    assert result["resolution_type"] == "code_change"
    assert result["forced_code_change"] is False
    assert result["is_question"] is True


def test_need_more_info_is_never_overridden_for_implementation_request(tmp_path, monkeypatch):
    workspace = _make_workspace(tmp_path)
    save_agent_state(workspace, {"original_prompt": "demo", "fix_history": [], "plan": []})

    monkeypatch.setattr(
        "nexcode.agent_runtime.reporter.run_investigation",
        lambda **kwargs: {
            "is_question": True,
            "resolution_type": "need_more_info",
            "issue_category": "unknown",
            "user_instructions": "Which linked list node format should I target?",
            "report": "I need the expected function signature before creating the file.",
            "scratchpad": "",
            "complexity": "simple",
            "confidence": "medium",
            "checked_files": ["."],
            "needs_plan_preview": False,
            "clarification_reason": "I need the expected function signature before creating the file.",
        },
    )
    monkeypatch.setattr("nexcode.agent_runtime.planner.generate_plan", lambda *args, **kwargs: pytest.fail("planner should not run"))
    monkeypatch.setattr(agent, "_run_code_change_turn", lambda **kwargs: pytest.fail("code change turn should not run"))

    agent._run_assistant_turn(workspace, "demo", "create a python file for linked list cycle", verbose=False, image_urls=None)
    state = load_agent_state(workspace)

    assert state["last_resolution_type"] == "need_more_info"
    assert state["pending_clarification"]["active"] is True


def test_stale_cache_like_report_no_longer_forces_user_action_only(tmp_path, monkeypatch):
    workspace = _make_workspace(tmp_path)
    save_agent_state(workspace, {"original_prompt": "demo", "fix_history": [], "plan": []})
    captured = {}

    monkeypatch.setattr(
        "nexcode.agent_runtime.reporter.run_investigation",
        lambda **kwargs: {
            "is_question": False,
            "resolution_type": "code_change",
            "issue_category": "unknown",
            "user_instructions": "Restart the dev server, delete `.next`, and refresh the browser.",
            "report": "Restart the dev server, delete `.next`, and refresh the browser.",
            "scratchpad": "- stale build output",
            "complexity": "simple",
            "confidence": "high",
            "checked_files": ["src/app/page.tsx"],
            "needs_plan_preview": False,
            "clarification_reason": "",
        },
    )
    monkeypatch.setattr(
        agent,
        "_run_code_change_turn",
        lambda **kwargs: captured.update({"investigation_result": kwargs["investigation_result"]}),
    )

    agent._run_assistant_turn(workspace, "demo", "fix the landing page rendering", verbose=False, image_urls=None)
    assert captured["investigation_result"]["resolution_type"] == "code_change"


def test_already_implemented_answer_only_is_not_overridden(tmp_path, monkeypatch):
    workspace = _make_workspace(tmp_path)
    save_agent_state(workspace, {"original_prompt": "demo", "fix_history": [], "plan": []})

    monkeypatch.setattr(
        "nexcode.agent_runtime.reporter.run_investigation",
        lambda **kwargs: {
            "is_question": True,
            "resolution_type": "answer_only",
            "issue_category": "ui",
            "user_instructions": (
                "This behavior is already implemented.\n\n"
                "What I checked: src/app.py\n\n"
                "How to verify: Run the existing flow and confirm the linked list cycle helper is already present."
            ),
            "report": "This behavior is already implemented.",
            "scratchpad": "",
            "complexity": "simple",
            "confidence": "high",
            "checked_files": ["src/app.py"],
            "needs_plan_preview": False,
            "clarification_reason": "",
        },
    )
    monkeypatch.setattr("nexcode.agent_runtime.planner.generate_plan", lambda *args, **kwargs: pytest.fail("planner should not run"))
    monkeypatch.setattr(agent, "_run_code_change_turn", lambda **kwargs: pytest.fail("code change turn should not run"))

    agent._run_assistant_turn(workspace, "demo", "fix the linked list cycle helper", verbose=False, image_urls=None)
    state = load_agent_state(workspace)

    assert state["last_resolution_type"] == "answer_only"
    assert "already implemented" in state["fix_history"][-1]["outcome"].lower()


def test_mixed_mode_respects_reporter_for_implementation_half(tmp_path, monkeypatch):
    workspace = _make_workspace(tmp_path)
    save_agent_state(workspace, {"original_prompt": "demo", "fix_history": [], "plan": []})
    captured = {"reporter_modes": []}

    def fake_run_investigation(**kwargs):
        captured["reporter_modes"].append(kwargs["routing_mode"])
        if kwargs["routing_mode"] == "consult_only":
            return {
                "is_question": True,
                "resolution_type": "answer_only",
                "issue_category": "ui",
                "user_instructions": "Add social proof and a quick FAQ.",
                "report": "Add social proof and a quick FAQ.",
                "scratchpad": "",
                "complexity": "simple",
                "confidence": "high",
                "checked_files": ["README.md"],
                "needs_plan_preview": False,
                "clarification_reason": "",
            }
        return {
            "is_question": True,
            "resolution_type": "answer_only",
            "issue_category": "unknown",
            "user_instructions": (
                "Create a new Python file named `linked_list_cycle.py`.\n\n"
                "```python\n"
                "class Solution:\n"
                "    pass\n"
                "```"
            ),
            "report": "Create a new Python file named `linked_list_cycle.py`.",
            "scratchpad": "",
            "complexity": "simple",
            "confidence": "high",
            "checked_files": ["."],
            "needs_plan_preview": False,
            "clarification_reason": "",
        }

    monkeypatch.setattr("nexcode.agent_runtime.reporter.run_investigation", fake_run_investigation)
    monkeypatch.setattr("nexcode.agent_runtime.planner.generate_plan", lambda *args, **kwargs: pytest.fail("planner should not run"))

    agent._run_assistant_turn(
        workspace,
        "demo",
        "what else can we add, and create a python helper for linked list cycle",
        verbose=False,
        image_urls=None,
    )

    assert captured["reporter_modes"] == ["consult_only", "implementation"]
    state = load_agent_state(workspace)
    assert "Add social proof and a quick FAQ." in state["fix_history"][-1]["outcome"]
    assert "Create a new Python file named `linked_list_cycle.py`." in state["fix_history"][-1]["outcome"]


def test_question_form_add_request_routes_to_implementation(tmp_path, monkeypatch):
    workspace = _make_workspace(tmp_path)
    save_agent_state(workspace, {"original_prompt": "demo", "fix_history": [], "plan": []})
    captured = {"routing_mode": "", "planner": False, "executor": False}

    def fake_run_investigation(**kwargs):
        captured["routing_mode"] = kwargs["routing_mode"]
        return {
            "is_question": False,
            "resolution_type": "code_change",
            "issue_category": "ui",
            "user_instructions": "",
            "report": "Add testimonials to the landing page.",
            "scratchpad": "",
            "complexity": "simple",
            "confidence": "high",
            "checked_files": ["src/app/page.tsx"],
            "needs_plan_preview": False,
            "clarification_reason": "",
        }

    monkeypatch.setattr("nexcode.agent_runtime.reporter.run_investigation", fake_run_investigation)
    monkeypatch.setattr("nexcode.agent_runtime.planner.generate_plan", lambda *args, **kwargs: captured.__setitem__("planner", True) or [])
    monkeypatch.setattr("nexcode.agent_runtime.executor.execute_plan", lambda *args, **kwargs: captured.__setitem__("executor", True))

    agent._run_assistant_turn(workspace, "demo", "Can you add testimonials?", verbose=False, image_urls=None)

    assert captured["routing_mode"] == "implementation"
    assert captured["planner"] is True


def test_implementation_turn_filters_prior_consult_history_before_planning(tmp_path, monkeypatch):
    workspace = _make_workspace(tmp_path)
    save_agent_state(
        workspace,
        {
            "original_prompt": "demo",
            "fix_history": [
                {
                    "prompt": "Can you explain the architecture?",
                    "outcome": "What I checked: src/app.py\n\nHow to verify: read the module.",
                    "resolution_type": "answer_only",
                    "context_scope": "consult_only",
                },
                {
                    "prompt": "Fix the login bug",
                    "outcome": "What I changed:\nUpdated the login handler.",
                    "resolution_type": "code_change",
                    "context_scope": "implementation",
                },
                {
                    "prompt": "Run test.py and tell me output",
                    "outcome": "Ran test.py | status=success | preview=all good",
                    "resolution_type": "answer_only",
                    "context_scope": "execution_request",
                },
            ],
            "plan": [],
        },
    )
    captured = {}

    monkeypatch.setattr(
        "nexcode.agent_runtime.reporter.run_investigation",
        lambda **kwargs: {
            "is_question": False,
            "resolution_type": "code_change",
            "issue_category": "ui",
            "user_instructions": "",
            "report": "Remove comments from test.py.",
            "scratchpad": "",
            "complexity": "simple",
            "confidence": "high",
            "checked_files": ["test.py"],
            "needs_plan_preview": False,
            "clarification_reason": "",
        },
    )

    def fake_generate_plan(*args, **kwargs):
        captured["fix_history"] = kwargs["fix_history"]
        return []

    monkeypatch.setattr("nexcode.agent_runtime.planner.generate_plan", fake_generate_plan)
    monkeypatch.setattr("nexcode.agent_runtime.executor.execute_plan", lambda *args, **kwargs: None)

    agent._run_assistant_turn(workspace, "demo", "remove comments from test.py", verbose=False, image_urls=None)

    prompts = [entry["prompt"] for entry in captured["fix_history"]]
    assert "Fix the login bug" in prompts
    assert "Can you explain the architecture?" not in prompts
    assert "Run test.py and tell me output" not in prompts


def test_casual_chat_history_is_excluded_from_future_reporter_context(tmp_path, monkeypatch):
    workspace = _make_workspace(tmp_path)
    save_agent_state(
        workspace,
        {
            "original_prompt": "demo",
            "fix_history": [
                {
                    "prompt": "Fix the login bug",
                    "outcome": "What I changed:\nUpdated the login handler.",
                    "resolution_type": "code_change",
                    "context_scope": "implementation",
                }
            ],
            "plan": [],
            "last_resolution_type": "code_change",
            "last_user_goal": "Fix the login bug",
        },
    )
    monkeypatch.setattr("nexcode.config.load_access", lambda: {"api_key": "", "endpoint": "", "provider": "grok"})
    agent._run_casual_chat_turn(workspace, "demo", "thanks buddy", verbose=False)

    captured = {}

    def fake_run_investigation(**kwargs):
        captured["fix_history"] = kwargs["fix_history"]
        return {
            "is_question": False,
            "resolution_type": "code_change",
            "issue_category": "ui",
            "user_instructions": "",
            "report": "Fix the mobile layout too.",
            "scratchpad": "",
            "complexity": "simple",
            "confidence": "high",
            "checked_files": ["src/app.py"],
            "needs_plan_preview": False,
            "clarification_reason": "",
        }

    monkeypatch.setattr("nexcode.agent_runtime.reporter.run_investigation", fake_run_investigation)
    monkeypatch.setattr("nexcode.agent_runtime.planner.generate_plan", lambda *args, **kwargs: [])
    monkeypatch.setattr("nexcode.agent_runtime.executor.execute_plan", lambda *args, **kwargs: None)

    agent._run_assistant_turn(workspace, "demo", "fix mobile too", verbose=False, image_urls=None)

    prompts = [entry["prompt"] for entry in captured["fix_history"]]
    assert "Fix the login bug" in prompts
    assert "thanks buddy" not in prompts


def test_execution_request_persists_compact_state_and_timing(tmp_path, monkeypatch, captured_agent_prints):
    workspace = tmp_path / "demo"
    workspace.mkdir()
    (workspace / "test.py").write_text("print('ok')\n", encoding="utf-8")
    status_updates = []

    class DummyStatus:
        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc, tb):
            return False

        def update(self, message):
            status_updates.append(message)

    monkeypatch.setattr(agent.console, "status", lambda *args, **kwargs: DummyStatus())

    def fake_run_command_interactive(workspace_path, cmd, path=".", verbose=False, status_callback=None, tail_callback=None, timeout=900):
        assert any("Running `test.py` now" in str(arg) for call in captured_agent_prints for arg in call)
        if status_callback:
            status_callback(0.4, "scan started")
        return CommandRunResult(
            command=cmd,
            cwd=str(workspace_path),
            status="success",
            exit_code=0,
            duration_sec=2.5,
            started_at_utc="2026-03-19T07:52:59Z",
            ended_at_utc="2026-03-19T07:53:02Z",
            artifact_path=str(workspace_path / ".agent" / ".ai_logs" / "command_artifacts" / "run.log"),
            output_preview="scan started\nscan finished",
            full_output_chars=26,
        )

    monkeypatch.setattr("nexcode.tools.shell_tools.run_command_interactive", fake_run_command_interactive)

    agent._run_execution_request_turn(
        workspace,
        "demo",
        "can you pls run test.py and tell me output what u see?",
        verbose=False,
    )

    state = load_agent_state(workspace)

    assert state["last_execution"]["target_file"] == "test.py"
    assert state["last_execution"]["status"] == "success"
    assert state["last_execution"]["full_output_chars"] == 26
    assert state["recent_targets"][0]["path"] == "test.py"
    assert state["recent_targets"][0]["role"] == "executed"
    assert "```text" not in state["investigation_report"]
    assert len(state["fix_history"][-1]["outcome"]) < 950
    assert state["fix_history"][-1]["context_scope"] == "execution_request"
    assert state["last_timing_event"]["durations_sec"]["execution"] == 2.5
    assert state["last_timing_event"]["context_scope"] == "execution_request"
    assert state["last_timing_event"]["command"] == 'python "test.py"'
    assert status_updates


def test_execution_request_verbose_prints_live_tail_updates(tmp_path, monkeypatch, captured_agent_prints):
    workspace = tmp_path / "demo"
    workspace.mkdir()
    (workspace / "test.py").write_text("print('ok')\n", encoding="utf-8")

    class DummyStatus:
        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc, tb):
            return False

        def update(self, message):
            return None

    monkeypatch.setattr(agent.console, "status", lambda *args, **kwargs: DummyStatus())

    def fake_run_command_interactive(workspace_path, cmd, path=".", verbose=False, status_callback=None, tail_callback=None, timeout=900):
        if status_callback:
            status_callback(0.2, "still running")
        if tail_callback:
            tail_callback(["line one", "line two"], 3)
        return CommandRunResult(
            command=cmd,
            cwd=str(workspace_path),
            status="success",
            exit_code=0,
            duration_sec=1.2,
            started_at_utc="2026-03-19T07:52:59Z",
            ended_at_utc="2026-03-19T07:53:00Z",
            artifact_path=str(workspace_path / ".agent" / ".ai_logs" / "command_artifacts" / "run.log"),
            output_preview="line one\nline two",
            full_output_chars=16,
        )

    monkeypatch.setattr("nexcode.tools.shell_tools.run_command_interactive", fake_run_command_interactive)

    agent._run_execution_request_turn(
        workspace,
        "demo",
        "run test.py and tell me output",
        verbose=True,
    )

    flattened = [str(arg) for call in captured_agent_prints for arg in call]
    assert any("Live output" in line and "line one" in line for line in flattened)
    assert any("3 more line(s)" in line for line in flattened)


def test_execution_request_resolves_recent_file_follow_up(tmp_path, monkeypatch):
    workspace = tmp_path / "demo"
    workspace.mkdir()
    (workspace / "linked_list_cycle.py").write_text("print('ok')\n", encoding="utf-8")
    save_agent_state(
        workspace,
        {
            "original_prompt": "demo",
            "recent_targets": [
                {
                    "path": "linked_list_cycle.py",
                    "kind": "file",
                    "role": "created",
                    "source": "implementation",
                    "recorded_at_utc": "2026-03-19T08:55:34Z",
                }
            ],
        },
    )

    monkeypatch.setattr(agent.console, "status", lambda *args, **kwargs: type("DummyStatus", (), {"__enter__": lambda self: self, "__exit__": lambda self, exc_type, exc, tb: False, "update": lambda self, message: None})())

    monkeypatch.setattr(
        "nexcode.tools.shell_tools.run_command_interactive",
        lambda *args, **kwargs: CommandRunResult(
            command='python "linked_list_cycle.py"',
            cwd=".",
            status="success",
            exit_code=0,
            duration_sec=0.8,
            started_at_utc="2026-03-19T09:00:00Z",
            ended_at_utc="2026-03-19T09:00:01Z",
            artifact_path=str(workspace / ".agent" / ".ai_logs" / "command_artifacts" / "run.log"),
            output_preview="True",
            full_output_chars=4,
        ),
    )

    agent._run_execution_request_turn(
        workspace,
        "demo",
        "run that file and summarize the output",
        verbose=False,
    )

    state = load_agent_state(workspace)

    assert state["last_execution"]["target_file"] == "linked_list_cycle.py"
    assert state["last_execution"]["command"] == 'python "linked_list_cycle.py"'


def test_execution_request_asks_when_recent_target_is_ambiguous(tmp_path, monkeypatch):
    workspace = tmp_path / "demo"
    workspace.mkdir()
    (workspace / "first.py").write_text("print('a')\n", encoding="utf-8")
    (workspace / "second.py").write_text("print('b')\n", encoding="utf-8")
    save_agent_state(
        workspace,
        {
            "original_prompt": "demo",
            "recent_targets": [
                {
                    "path": "first.py",
                    "kind": "file",
                    "role": "edited",
                    "source": "implementation",
                    "recorded_at_utc": "2026-03-19T08:55:34Z",
                },
                {
                    "path": "second.py",
                    "kind": "file",
                    "role": "edited",
                    "source": "implementation",
                    "recorded_at_utc": "2026-03-19T08:55:30Z",
                },
            ],
        },
    )
    captured = {}

    monkeypatch.setattr(
        agent,
        "_emit_direct_agent_response",
        lambda workspace_path, project_name, user_message, formatted_message, **kwargs: captured.update(
            {"resolution_type": kwargs["resolution_type"], "message": formatted_message}
        ),
    )

    agent._run_execution_request_turn(
        workspace,
        "demo",
        "run that file",
        verbose=False,
    )

    assert captured["resolution_type"] == "need_more_info"
    assert "first.py" in captured["message"]
    assert "second.py" in captured["message"]


def test_execution_request_does_not_run_unsupported_file_type(tmp_path, monkeypatch):
    workspace = tmp_path / "demo"
    workspace.mkdir()
    (workspace / "notes.txt").write_text("hello\n", encoding="utf-8")
    captured = {}

    monkeypatch.setattr(
        agent,
        "_emit_direct_agent_response",
        lambda workspace_path, project_name, user_message, formatted_message, **kwargs: captured.update(
            {"resolution_type": kwargs["resolution_type"], "message": formatted_message}
        ),
    )

    agent._run_execution_request_turn(
        workspace,
        "demo",
        "run notes.txt and tell me output",
        verbose=False,
    )

    assert captured["resolution_type"] == "answer_only"
    assert "safe default runtime" in captured["message"]


def test_format_no_code_response_dedupes_checked_files_line():
    rendered = agent._format_no_code_response(
        "answer_only",
        "Already done.\n\nWhat I checked: test.py",
        ["test.py"],
    )

    assert rendered.count("What I checked:") == 1


def test_bug_prompt_routes_to_implementation(tmp_path, monkeypatch):
    workspace = _make_workspace(tmp_path)
    save_agent_state(workspace, {"original_prompt": "demo", "fix_history": [], "plan": []})
    captured = {"routing_mode": "", "planner": False}

    def fake_run_investigation(**kwargs):
        captured["routing_mode"] = kwargs["routing_mode"]
        return {
            "is_question": False,
            "resolution_type": "code_change",
            "issue_category": "ui",
            "user_instructions": "",
            "report": "Fix the broken logout button.",
            "scratchpad": "",
            "complexity": "simple",
            "confidence": "high",
            "checked_files": ["src/components/Header.tsx"],
            "needs_plan_preview": False,
            "clarification_reason": "",
        }

    monkeypatch.setattr("nexcode.agent_runtime.reporter.run_investigation", fake_run_investigation)
    monkeypatch.setattr("nexcode.agent_runtime.planner.generate_plan", lambda *args, **kwargs: captured.__setitem__("planner", True) or [])
    monkeypatch.setattr("nexcode.agent_runtime.executor.execute_plan", lambda *args, **kwargs: None)

    agent._run_assistant_turn(workspace, "demo", "Logout is broken", verbose=False, image_urls=None)

    assert captured["routing_mode"] == "implementation"
    assert captured["planner"] is True


def test_model_intent_classifier_takes_priority_over_heuristics(tmp_path, monkeypatch):
    workspace = _make_workspace(tmp_path)
    save_agent_state(workspace, {"original_prompt": "demo", "fix_history": [], "plan": []})
    captured = {"routing_mode": "", "planner": False}

    monkeypatch.setattr(
        agent,
        "_classify_assistant_intent_with_model",
        lambda *args, **kwargs: {
            "intent": "implementation",
            "consult_request": "",
            "implementation_request": "Please add testimonials",
            "reason": "model_classifier",
        },
    )

    def fake_run_investigation(**kwargs):
        captured["routing_mode"] = kwargs["routing_mode"]
        return {
            "is_question": False,
            "resolution_type": "code_change",
            "issue_category": "ui",
            "user_instructions": "",
            "report": "Add testimonials to the landing page.",
            "scratchpad": "",
            "complexity": "simple",
            "confidence": "high",
            "checked_files": ["src/app/page.tsx"],
            "needs_plan_preview": False,
            "clarification_reason": "",
        }

    monkeypatch.setattr("nexcode.agent_runtime.reporter.run_investigation", fake_run_investigation)
    monkeypatch.setattr("nexcode.agent_runtime.planner.generate_plan", lambda *args, **kwargs: captured.__setitem__("planner", True) or [])
    monkeypatch.setattr("nexcode.agent_runtime.executor.execute_plan", lambda *args, **kwargs: None)

    agent._run_assistant_turn(workspace, "demo", "What else can we add? Also add testimonials.", verbose=False, image_urls=None)

    assert captured["routing_mode"] == "implementation"
    assert captured["planner"] is True


def test_autonomous_mode_preserves_reporter_first_behavior(tmp_path, monkeypatch):
    workspace = _make_workspace(tmp_path)
    save_agent_state(workspace, {"original_prompt": "demo", "fix_history": [], "plan": []})
    called = {"planner": False, "executor": False, "routing_mode": ""}

    def fake_run_investigation(**kwargs):
        called["routing_mode"] = kwargs["routing_mode"]
        return {
            "is_question": False,
            "resolution_type": "code_change",
            "issue_category": "ui",
            "user_instructions": "",
            "report": "Implement the suggested landing page sections.",
            "scratchpad": "",
            "complexity": "simple",
            "confidence": "medium",
            "checked_files": ["src/app/page.tsx"],
            "needs_plan_preview": False,
            "clarification_reason": "",
        }

    monkeypatch.setattr("nexcode.agent_runtime.reporter.run_investigation", fake_run_investigation)
    monkeypatch.setattr("nexcode.agent_runtime.planner.generate_plan", lambda *args, **kwargs: called.__setitem__("planner", True) or [])
    monkeypatch.setattr("nexcode.agent_runtime.executor.execute_plan", lambda *args, **kwargs: called.__setitem__("executor", True))
    monkeypatch.setattr("nexcode.config.load_agent_config", lambda *args, **kwargs: {"model": "demo", "assistant_intent_mode": "autonomous"})
    monkeypatch.setattr(
        agent,
        "_classify_assistant_intent_with_model",
        lambda *args, **kwargs: {
            "intent": "implementation",
            "consult_request": "",
            "implementation_request": "Add the suggested landing page sections.",
            "reason": "model_classifier",
        },
    )

    agent._run_assistant_turn(workspace, "demo", "What else can we add to the landing page?", verbose=False, image_urls=None)

    assert called["routing_mode"] == "implementation"
    assert called["planner"] is True


def test_run_assistant_turn_respects_intent_decision_override_without_model_classifier(tmp_path, monkeypatch):
    workspace = _make_workspace(tmp_path)
    save_agent_state(workspace, {"original_prompt": "demo", "fix_history": [], "plan": []})
    captured = {"routing_mode": "", "planner": False}

    monkeypatch.setattr(
        agent,
        "_classify_assistant_intent_with_model",
        lambda *args, **kwargs: pytest.fail("assistant intent model should not run when an override is provided"),
    )

    def fake_run_investigation(**kwargs):
        captured["routing_mode"] = kwargs["routing_mode"]
        return {
            "is_question": False,
            "resolution_type": "code_change",
            "issue_category": "ui",
            "user_instructions": "",
            "report": "Add testimonials to the landing page.",
            "scratchpad": "",
            "complexity": "simple",
            "confidence": "high",
            "checked_files": ["src/app/page.tsx"],
            "needs_plan_preview": False,
            "clarification_reason": "",
        }

    monkeypatch.setattr("nexcode.agent_runtime.reporter.run_investigation", fake_run_investigation)
    monkeypatch.setattr("nexcode.agent_runtime.planner.generate_plan", lambda *args, **kwargs: captured.__setitem__("planner", True) or [])
    monkeypatch.setattr("nexcode.agent_runtime.executor.execute_plan", lambda *args, **kwargs: None)

    agent._run_assistant_turn(
        workspace,
        "demo",
        "What else can we add? Also add testimonials.",
        verbose=False,
        image_urls=None,
        intent_decision_override={
            "intent": "implementation",
            "consult_request": "",
            "implementation_request": "Add testimonials to the landing page.",
            "reason": "model_route_override",
        },
    )

    assert captured["routing_mode"] == "implementation"
    assert captured["planner"] is True


def test_default_agent_config_uses_conservative_intent_mode():
    assert config.DEFAULT_AGENT_CONFIG["assistant_intent_mode"] == "conservative"
    assert config.DEFAULT_AGENT_CONFIG["assistant_routing_strategy"] == "heuristic"


def test_agent_file_has_single_active_run_assistant_turn_definition():
    source = Path(agent.__file__).read_text(encoding="utf-8")
    assert source.count("def _run_assistant_turn(") == 1


def test_simple_code_change_skips_visible_plan_preview(tmp_path, monkeypatch, captured_agent_prints):
    workspace = _make_workspace(tmp_path)
    save_agent_state(workspace, {"original_prompt": "demo", "fix_history": [], "plan": []})

    def fake_run_investigation(**kwargs):
        return {
            "is_question": False,
            "resolution_type": "code_change",
            "issue_category": "ui",
            "user_instructions": "",
            "report": "Update the shared button styles to restore hover contrast.",
            "scratchpad": "- button style issue",
            "complexity": "simple",
            "confidence": "high",
            "checked_files": ["src/components/Button.tsx"],
            "needs_plan_preview": False,
            "clarification_reason": "",
        }

    def fake_generate_plan(*args, **kwargs):
        return [
            {
                "step": 1,
                "task": "Update the shared button hover treatment",
                "goal": "Restore the expected hover contrast on the primary button",
                "rationale": "The hover regression is isolated to the shared button component.",
                "files": ["src/components/Button.tsx"],
                "type": "implementation",
                "design_notes": "",
            }
        ]

    monkeypatch.setattr("nexcode.agent_runtime.reporter.run_investigation", fake_run_investigation)
    monkeypatch.setattr("nexcode.agent_runtime.planner.generate_plan", fake_generate_plan)
    monkeypatch.setattr("nexcode.agent_runtime.executor.execute_plan", lambda *args, **kwargs: None)
    monkeypatch.setattr("nexcode.config.load_access", lambda: {"api_key": "test", "endpoint": "https://example.com", "model": "demo"})
    monkeypatch.setattr("nexcode.config.load_agent_config", lambda *args, **kwargs: {"model": "demo"})
    monkeypatch.setattr(
        "nexcode.agent_runtime.planner._call_gateway",
        lambda *args, **kwargs: (
            "What I changed:\nUpdated the shared button hover treatment.\n\nWhy it should work:\nThe hover contrast now comes from the corrected shared styles.\n\nHow to verify:\nOpen the affected screen and hover the primary button.\n\nRemaining risk:\nnone noted.",
            UsageData(),
        ),
    )

    agent._run_assistant_turn(workspace, "demo", "Fix the primary button hover state", verbose=False, image_urls=None)

    assert not any(isinstance(arg, Table) for call in captured_agent_prints for arg in call)
    assert any("Plan ready. Applying the fix autonomously" in str(arg) for call in captured_agent_prints for arg in call)


def test_complex_code_change_shows_plan_preview(tmp_path, monkeypatch, captured_agent_prints):
    workspace = _make_workspace(tmp_path)
    save_agent_state(workspace, {"original_prompt": "demo", "fix_history": [], "plan": []})

    def fake_run_investigation(**kwargs):
        return {
            "is_question": False,
            "resolution_type": "code_change",
            "issue_category": "ui",
            "user_instructions": "",
            "report": "Update the theme tokens and all affected layout surfaces for dark mode.",
            "scratchpad": "- dark mode touches layout and globals",
            "complexity": "complex",
            "confidence": "medium",
            "checked_files": ["src/app/layout.tsx", "src/app/globals.css"],
            "needs_plan_preview": True,
            "clarification_reason": "",
        }

    def fake_generate_plan(*args, **kwargs):
        return [
            {
                "step": 1,
                "task": "Update the global theme tokens",
                "goal": "Fix the shared dark mode foundation",
                "rationale": "All affected surfaces inherit from the global tokens.",
                "files": ["src/app/globals.css"],
                "type": "implementation",
                "design_notes": "",
            },
            {
                "step": 2,
                "task": "Validate the updated theme behavior",
                "goal": "Confirm dark mode is correct across the affected views",
                "rationale": "A broad theme fix needs explicit verification.",
                "files": [],
                "type": "validation",
                "design_notes": "",
            },
        ]

    monkeypatch.setattr("nexcode.agent_runtime.reporter.run_investigation", fake_run_investigation)
    monkeypatch.setattr("nexcode.agent_runtime.planner.generate_plan", fake_generate_plan)
    monkeypatch.setattr("nexcode.agent_runtime.executor.execute_plan", lambda *args, **kwargs: None)
    monkeypatch.setattr("nexcode.config.load_access", lambda: {"api_key": "test", "endpoint": "https://example.com", "model": "demo"})
    monkeypatch.setattr("nexcode.config.load_agent_config", lambda *args, **kwargs: {"model": "demo"})
    monkeypatch.setattr(
        "nexcode.agent_runtime.planner._call_gateway",
        lambda *args, **kwargs: (
            "What I changed:\nUpdated the theme tokens and validated the shared surfaces.\n\nWhy it should work:\nThe affected pages now inherit the corrected dark mode palette.\n\nHow to verify:\nSwitch to dark mode and inspect the updated layouts.\n\nRemaining risk:\nnone noted.",
            UsageData(),
        ),
    )

    agent._run_assistant_turn(workspace, "demo", "Make dark mode correct everywhere", verbose=False, image_urls=None)

    assert any(isinstance(arg, Table) for call in captured_agent_prints for arg in call)


def test_reporter_normalizes_metadata_defaults():
    normalized = _normalize_submit_report_args(
        {
            "resolution_type": "code_change",
            "final_report": "Update the shared form submission flow.",
        }
    )

    assert normalized["complexity"] == "simple"
    assert normalized["confidence"] == "medium"
    assert normalized["checked_files"] == []
    assert normalized["needs_plan_preview"] is False


def test_reporter_answer_only_includes_checked_files_and_verification():
    normalized = _normalize_submit_report_args(
        {
            "resolution_type": "answer_only",
            "user_instructions": "This behavior is already implemented.",
            "checked_files": ["src/app.py"],
        }
    )

    assert normalized["user_instructions"] == "This behavior is already implemented."
    assert normalized["target_scope"] == "single_file"
    assert normalized["validation_level"] == "scoped"


def test_reporter_need_more_info_includes_reason():
    normalized = _normalize_submit_report_args(
        {
            "resolution_type": "need_more_info",
            "user_instructions": "Which environment is failing?",
        }
    )

    assert normalized["clarification_reason"] == "I am missing a detail needed to continue safely."
    assert normalized["user_instructions"] == "Which environment is failing?"


def test_finalize_fix_plan_adds_schema_defaults():
    plan = [{"step": 1, "task": "Update the login handler"}]

    finalized = _finalize_fix_plan(plan, fix_metadata={"complexity": "simple"})

    step = finalized[0]
    assert step["goal"] == "Update the login handler"
    assert step["rationale"]
    assert step["files"] == []
    assert step["type"] == "implementation"
    assert "design_notes" in step


def test_finalize_fix_plan_adds_validation_step_for_complex_changes():
    plan = [
        {
            "step": 1,
            "task": "Update the shared dark mode tokens",
            "goal": "Fix the dark mode foundation",
            "rationale": "All affected layouts inherit from these tokens.",
            "files": ["src/app/globals.css"],
            "type": "implementation",
            "design_notes": "",
        }
    ]

    finalized = _finalize_fix_plan(plan, fix_metadata={"complexity": "complex"})

    assert any(step["type"] == "validation" for step in finalized)


def test_finalize_fix_plan_requires_files_for_complex_changes():
    plan = [{"step": 1, "task": "Update the shared dark mode tokens"}]

    with pytest.raises(ValueError):
        _finalize_fix_plan(plan, fix_metadata={"complexity": "complex"})


def test_finalize_fix_plan_preserves_model_selected_files_and_metadata():
    plan = [
        {
            "step": 1,
            "task": "Replace entire content of test.py with complete merge sort implementation including unit tests",
            "goal": "Create a standalone Python file that implements and tests merge sort",
            "rationale": "The request is for a test python file.",
            "files": ["test.py"],
            "type": "implementation",
            "design_notes": "Use unittest for verification.",
            "target_scope": "single_file",
            "overwrite_existing": True,
            "validation_level": "scoped",
        },
        {
            "step": 2,
            "task": "Validate merge sort implementation by running the test file",
            "goal": "Confirm the merge sort tests pass",
            "rationale": "Validation confirms the implementation is correct.",
            "files": ["test.py"],
            "type": "validation",
            "design_notes": "",
            "target_scope": "single_file",
            "validation_level": "scoped",
        },
    ]

    finalized = _finalize_fix_plan(plan, fix_metadata={"complexity": "simple"})

    assert len(finalized) == 2
    assert finalized[0]["files"] == ["test.py"]
    assert finalized[0]["overwrite_existing"] is True
    assert finalized[0]["target_scope"] == "single_file"
    assert finalized[0]["validation_level"] == "scoped"


def test_finalize_fix_plan_keeps_explicit_test_py_target_when_user_names_it():
    plan = [
        {
            "step": 1,
            "task": "Replace test.py with a merge sort implementation",
            "goal": "Update the existing test.py file",
            "rationale": "The user explicitly asked for test.py.",
            "files": ["test.py"],
            "type": "implementation",
            "design_notes": "",
        }
    ]

    finalized = _finalize_fix_plan(plan, fix_metadata={"complexity": "simple"})

    assert finalized[0]["files"] == ["test.py"]


def test_handle_agent_cli_rejects_chat(monkeypatch, captured_agent_prints):
    with pytest.raises(SystemExit):
        agent.handle_agent_cli(["chat", "demo", "what does this do"], piped_content="", verbose=False, image_urls=None)

    assert any("has been removed" in str(arg) for call in captured_agent_prints for arg in call)


def test_print_help_does_not_advertise_agent_chat(monkeypatch):
    captured = []

    def _capture(*args, **kwargs):
        captured.append(args)

    monkeypatch.setattr(utils, "print_banner", lambda: None)
    monkeypatch.setattr(utils.console, "print", _capture)
    monkeypatch.setattr(
        "nexcode.config.load_full_access",
        lambda: {
            "active": "grok",
            "grok": {"api_key": "abc123456", "model": "demo"},
            "gemini": {"api_key": "", "model": "demo"},
        },
    )

    utils.print_help()

    table = next(arg for call in captured for arg in call if isinstance(arg, Table))
    commands = list(table.columns[0]._cells)
    assert any("agent [message]" in cell for cell in commands)
    assert not any("agent chat" in cell for cell in commands)
    assert not any("nexcode <message>" in cell for cell in commands)
