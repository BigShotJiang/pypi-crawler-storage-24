import json

import pytest

from nexcode import cli, config


class _DummyStdin:
    def __init__(self, text: str = "", is_tty: bool = True):
        self._text = text
        self._is_tty = is_tty

    def isatty(self) -> bool:
        return self._is_tty

    def read(self) -> str:
        return self._text


def test_init_home_migrates_access_json_to_nexcode_json(tmp_path, monkeypatch):
    home_dir = tmp_path / ".nexcode-ai"
    home_dir.mkdir(parents=True, exist_ok=True)
    legacy_file = home_dir / "access.json"
    nexcode_file = home_dir / "nexcode.json"
    agent_cfg = home_dir / "agent.yaml"

    legacy_file.write_text(
        json.dumps(
            {
                "active": "gemini",
                "grok": dict(config.PROVIDER_DEFAULTS["grok"]),
                "gemini": {
                    "api_key": "gem-secret",
                    "endpoint": config.PROVIDER_DEFAULTS["gemini"]["endpoint"],
                    "model": "gemini-3.1-pro-preview",
                },
            }
        ),
        encoding="utf-8",
    )

    monkeypatch.setattr(config, "HOME_DIR", home_dir)
    monkeypatch.setattr(config, "LEGACY_ACCESS_FILE", legacy_file)
    monkeypatch.setattr(config, "NEXCODE_CONFIG_FILE", nexcode_file)
    monkeypatch.setattr(config, "AGENT_CONFIG_FILE", agent_cfg)

    config.init_home()

    assert nexcode_file.exists()
    assert not legacy_file.exists()
    assert agent_cfg.exists()
    assert not (home_dir / "MEMORY.md").exists()
    assert not (home_dir / "SOUL.md").exists()
    assert not (home_dir / "sessions").exists()

    loaded = config.load_full_access()
    assert loaded["active"] == "gemini"
    assert loaded["gemini"]["api_key"] == "gem-secret"


def test_cli_main_rejects_direct_message_mode(monkeypatch):
    printed = []

    monkeypatch.setattr(cli, "init_home", lambda: None)
    monkeypatch.setattr(cli.sys, "argv", ["nexcode", "hi"])
    monkeypatch.setattr(cli.sys, "stdin", _DummyStdin(is_tty=True))
    monkeypatch.setattr(
        "rich.console.Console.print",
        lambda self, *args, **kwargs: printed.append(" ".join(str(arg) for arg in args)),
    )

    with pytest.raises(SystemExit):
        cli.main()

    assert any("Direct messaging has been removed" in line for line in printed)
    assert any("nexcode agent [message]" in line for line in printed)
