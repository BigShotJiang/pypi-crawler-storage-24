import pytest
from pathlib import Path
from nexcode.agent_runtime import reporter
from nexcode.agent_runtime.tool_registry import load_all_tools

def test_validate_tool_call_invalid_arg():
    load_all_tools()
    
    # list_files only takes 'path' (and 'workspace' via runner)
    error = reporter._validate_tool_call("list_files", {"pattern": "*.py"})
    assert "unexpected argument(s): pattern" in error
    assert "Valid arguments are: path" in error

def test_validate_tool_call_missing_required():
    load_all_tools()
    
    # search_file requires 'path' and 'query'
    error = reporter._validate_tool_call("search_file", {"path": "test.py"})
    assert "missing required argument(s): query" in error

def test_validate_tool_call_valid():
    load_all_tools()
    
    # grep_search takes query, path, include_patterns
    error = reporter._validate_tool_call("grep_search", {"query": "todo", "path": ".", "include_patterns": ["*.ts"]})
    assert error is None

def test_validate_tool_call_submit_report():
    # submit_report is handled specially and skip signature check in validator
    error = reporter._validate_tool_call("submit_report", {"anything": "goes"})
    assert error is None

def test_validate_tool_call_unknown_tool():
    error = reporter._validate_tool_call("non_existent_tool", {"arg": 1})
    assert "is not recognized" in error
