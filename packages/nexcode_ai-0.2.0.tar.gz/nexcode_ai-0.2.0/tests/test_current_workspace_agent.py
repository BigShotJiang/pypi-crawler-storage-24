from pathlib import Path

import pytest

from nexcode import agent, config
from nexcode.agent_runtime.project_profile import detect_project_profile
from nexcode.agent_runtime.snapshot import create_snapshot
from nexcode.agent_runtime.task_scope import build_workspace_summary, resolve_task_scope
from nexcode.agent_runtime.workspace import load_agent_state, save_agent_state
from nexcode.tools.file_tools import grep_search, list_files, read_file


def test_current_workspace_turn_routes_review_prompt_to_review_only(tmp_path, monkeypatch):
    captured = {}

    def fake_run_assistant_turn(workspace_path, project_name, user_message, verbose, image_urls, routing_override=None):
        captured["workspace"] = workspace_path
        captured["project"] = project_name
        captured["message"] = user_message
        captured["routing_override"] = routing_override

    monkeypatch.setattr(agent, "_run_assistant_turn", fake_run_assistant_turn)

    agent._run_current_workspace_turn(
        tmp_path,
        "demo",
        "pls explore curr code base and find flaws in arch",
        verbose=False,
        image_urls=None,
    )

    assert captured["workspace"] == tmp_path
    assert captured["routing_override"] == "review_only"


def test_current_workspace_turn_routes_greeting_to_casual_chat(tmp_path, monkeypatch):
    captured = {}

    monkeypatch.setattr(
        agent,
        "_run_casual_chat_turn",
        lambda workspace_path, project_name, user_message, verbose: captured.update(
            {"workspace": workspace_path, "project": project_name, "message": user_message}
        ),
    )

    agent._run_current_workspace_turn(tmp_path, "demo", "hi", verbose=False, image_urls=None)

    assert captured["workspace"] == tmp_path
    assert captured["message"] == "hi"


def test_current_workspace_turn_routes_closure_prompt_to_casual_chat(tmp_path, monkeypatch):
    captured = {}

    monkeypatch.setattr(
        agent,
        "_run_casual_chat_turn",
        lambda workspace_path, project_name, user_message, verbose: captured.update(
            {"workspace": workspace_path, "project": project_name, "message": user_message}
        ),
    )

    agent._run_current_workspace_turn(tmp_path, "demo", "thanks now working", verbose=False, image_urls=None)

    assert captured["workspace"] == tmp_path
    assert captured["message"] == "thanks now working"


def test_current_workspace_turn_ai_first_uses_model_route_for_casual_chat(tmp_path, monkeypatch):
    captured = {}

    monkeypatch.setattr(
        "nexcode.config.load_agent_config",
        lambda *args, **kwargs: {
            "model": "demo",
            "assistant_routing_strategy": "ai_first",
            "assistant_intent_mode": "conservative",
        },
    )
    monkeypatch.setattr(
        agent,
        "_classify_workspace_route_with_model",
        lambda *args, **kwargs: {
            "route": "casual_chat",
            "intent": "",
            "consult_request": "",
            "implementation_request": "",
            "action_kind": "",
            "target_hint": "",
            "reason": "model_casual_chat",
        },
    )
    monkeypatch.setattr(
        agent,
        "_run_casual_chat_turn",
        lambda workspace_path, project_name, user_message, verbose: captured.update(
            {"workspace": workspace_path, "project": project_name, "message": user_message}
        ),
    )

    agent._run_current_workspace_turn(tmp_path, "demo", "yo pal", verbose=False, image_urls=None)

    assert captured["workspace"] == tmp_path
    assert captured["message"] == "yo pal"


def test_current_workspace_turn_ai_first_uses_model_route_for_review_only(tmp_path, monkeypatch):
    captured = {}

    monkeypatch.setattr(
        "nexcode.config.load_agent_config",
        lambda *args, **kwargs: {
            "model": "demo",
            "assistant_routing_strategy": "ai_first",
            "assistant_intent_mode": "conservative",
        },
    )
    monkeypatch.setattr(
        agent,
        "_classify_workspace_route_with_model",
        lambda *args, **kwargs: {
            "route": "review_only",
            "intent": "",
            "consult_request": "",
            "implementation_request": "",
            "action_kind": "",
            "target_hint": "",
            "reason": "model_review",
        },
    )
    monkeypatch.setattr(
        agent,
        "_run_assistant_turn",
        lambda workspace_path, project_name, user_message, verbose, image_urls, routing_override=None, intent_decision_override=None: captured.update(
            {
                "workspace": workspace_path,
                "project": project_name,
                "message": user_message,
                "routing_override": routing_override,
                "intent_decision_override": intent_decision_override,
            }
        ),
    )

    agent._run_current_workspace_turn(tmp_path, "demo", "walk the repo and see if the architecture feels shaky", verbose=False, image_urls=None)

    assert captured["workspace"] == tmp_path
    assert captured["routing_override"] == "review_only"
    assert captured["intent_decision_override"] is None


def test_current_workspace_turn_ai_first_passes_model_assistant_intent_to_assistant(tmp_path, monkeypatch):
    captured = {}

    monkeypatch.setattr(
        "nexcode.config.load_agent_config",
        lambda *args, **kwargs: {
            "model": "demo",
            "assistant_routing_strategy": "ai_first",
            "assistant_intent_mode": "conservative",
        },
    )
    monkeypatch.setattr(
        agent,
        "_classify_workspace_route_with_model",
        lambda *args, **kwargs: {
            "route": "assistant",
            "intent": "mixed",
            "consult_request": "what else can we add",
            "implementation_request": "also fix mobile nav",
            "action_kind": "",
            "target_hint": "",
            "reason": "model_mixed",
        },
    )
    monkeypatch.setattr(
        agent,
        "_run_assistant_turn",
        lambda workspace_path, project_name, user_message, verbose, image_urls, routing_override=None, intent_decision_override=None: captured.update(
            {
                "workspace": workspace_path,
                "project": project_name,
                "message": user_message,
                "routing_override": routing_override,
                "intent_decision_override": intent_decision_override,
            }
        ),
    )

    agent._run_current_workspace_turn(
        tmp_path,
        "demo",
        "what else can we add, and also fix mobile nav",
        verbose=False,
        image_urls=None,
    )

    assert captured["workspace"] == tmp_path
    assert captured["routing_override"] is None
    assert captured["intent_decision_override"]["intent"] == "mixed"
    assert captured["intent_decision_override"]["implementation_request"] == "also fix mobile nav"


def test_current_workspace_turn_routes_thanks_plus_followup_to_assistant(tmp_path, monkeypatch):
    captured = {}

    def fail_casual_chat(*args, **kwargs):
        raise AssertionError("casual path should not run")

    monkeypatch.setattr(agent, "_run_casual_chat_turn", fail_casual_chat)
    monkeypatch.setattr(
        agent,
        "_run_assistant_turn",
        lambda workspace_path, project_name, user_message, verbose, image_urls, routing_override=None: captured.update(
            {"workspace": workspace_path, "project": project_name, "message": user_message, "routing_override": routing_override}
        ),
    )

    agent._run_current_workspace_turn(tmp_path, "demo", "thanks buddy can you also fix mobile", verbose=False, image_urls=None)

    assert captured["workspace"] == tmp_path
    assert captured["message"] == "thanks buddy can you also fix mobile"
    assert captured["routing_override"] is None


def test_current_workspace_turn_keeps_consult_prompt_out_of_casual_chat(tmp_path, monkeypatch):
    captured = {}

    def fail_casual_chat(*args, **kwargs):
        raise AssertionError("casual path should not run")

    monkeypatch.setattr(agent, "_run_casual_chat_turn", fail_casual_chat)
    monkeypatch.setattr(
        agent,
        "_run_assistant_turn",
        lambda workspace_path, project_name, user_message, verbose, image_urls, routing_override=None: captured.update(
            {"workspace": workspace_path, "project": project_name, "message": user_message, "routing_override": routing_override}
        ),
    )

    agent._run_current_workspace_turn(
        tmp_path,
        "demo",
        "thankyou so much and what else can we add to the landing page?",
        verbose=False,
        image_urls=None,
    )

    assert captured["workspace"] == tmp_path
    assert captured["message"] == "thankyou so much and what else can we add to the landing page?"
    assert captured["routing_override"] is None


def test_current_workspace_turn_fix_command_hint_forces_implementation_route(tmp_path, monkeypatch):
    captured = {}

    monkeypatch.setattr(
        agent,
        "_run_assistant_turn",
        lambda workspace_path, project_name, user_message, verbose, image_urls, routing_override=None, intent_decision_override=None: captured.update(
            {
                "workspace": workspace_path,
                "project": project_name,
                "message": user_message,
                "routing_override": routing_override,
                "intent_decision_override": intent_decision_override,
            }
        ),
    )

    agent._run_current_workspace_turn(
        tmp_path,
        "demo",
        "fix the mobile login error",
        verbose=False,
        image_urls=None,
        command_hint="fix",
    )

    assert captured["workspace"] == tmp_path
    assert captured["routing_override"] == "implementation"
    assert captured["intent_decision_override"] is None


def test_current_workspace_turn_builds_in_metadata_only_workspace(tmp_path, monkeypatch):
    (tmp_path / ".gitignore").write_text("node_modules/\n", encoding="utf-8")
    captured = {}

    monkeypatch.setattr(
        agent,
        "_run_build_prompt_in_workspace",
        lambda workspace_path, project_name, prompt, verbose, image_urls, target_dir="": captured.update(
            {"workspace": workspace_path, "project": project_name, "prompt": prompt, "target_dir": target_dir}
        ),
    )

    agent._run_current_workspace_turn(
        tmp_path,
        "demo",
        "pls can you make a portfolio using my resume",
        verbose=False,
        image_urls=None,
    )

    assert captured["workspace"] == tmp_path
    assert "portfolio" in captured["prompt"].lower()


def test_current_workspace_turn_ai_decides_integrate_for_greenfield_in_existing_repo(tmp_path, monkeypatch):
    """AI classifier returns 'integrate' → build in-place, no user question asked."""
    (tmp_path / "package.json").write_text('{"name":"demo"}', encoding="utf-8")
    captured = {}

    monkeypatch.setattr(
        agent,
        "_classify_greenfield_workspace_decision",
        lambda *args, **kwargs: "integrate",
    )
    monkeypatch.setattr(
        agent,
        "_run_build_prompt_in_workspace",
        lambda workspace_path, project_name, prompt, verbose, image_urls, target_dir="": captured.update(
            {"workspace": workspace_path, "project": project_name, "prompt": prompt, "target_dir": target_dir}
        ),
    )

    agent._run_current_workspace_turn(
        tmp_path,
        "demo",
        "pls can you make a portfolio using my resume",
        verbose=False,
        image_urls=None,
    )

    assert captured["workspace"] == tmp_path
    assert "portfolio" in captured["prompt"].lower()
    assert captured["target_dir"] == ""


def test_current_workspace_turn_ai_decides_existing_project_routes_to_assistant(tmp_path, monkeypatch):
    """AI classifier returns 'existing_project' → falls through to normal assistant routing."""
    (tmp_path / "ai_job_scorer.py").write_text("# scorer", encoding="utf-8")
    (tmp_path / "api_key_manager.py").write_text("# api keys", encoding="utf-8")
    captured = {}

    monkeypatch.setattr(
        agent,
        "_classify_greenfield_workspace_decision",
        lambda *args, **kwargs: "existing_project",
    )
    monkeypatch.setattr(
        agent,
        "_run_assistant_turn",
        lambda workspace_path, project_name, user_message, verbose, image_urls, routing_override=None, intent_decision_override=None: captured.update(
            {"workspace": workspace_path, "project": project_name, "message": user_message}
        ),
    )

    agent._run_current_workspace_turn(
        tmp_path,
        "demo",
        "can you tell me how this project works and explore the codebase",
        verbose=False,
        image_urls=None,
    )

    assert captured["workspace"] == tmp_path
    assert "codebase" in captured["message"].lower()


def test_current_workspace_turn_ai_decides_separate_creates_subfolder(tmp_path, monkeypatch):
    """AI classifier returns 'separate' → auto-creates subfolder, no user question asked."""
    (tmp_path / "package.json").write_text('{"name":"demo"}', encoding="utf-8")
    captured = {}

    monkeypatch.setattr(
        agent,
        "_classify_greenfield_workspace_decision",
        lambda *args, **kwargs: "separate",
    )
    monkeypatch.setattr(
        agent,
        "_run_build_prompt_in_workspace",
        lambda workspace_path, project_name, prompt, verbose, image_urls, target_dir="": captured.update(
            {"workspace": workspace_path, "project": project_name, "prompt": prompt, "target_dir": target_dir}
        ),
    )

    agent._run_current_workspace_turn(
        tmp_path,
        "demo",
        "build me a completely separate portfolio website",
        verbose=False,
        image_urls=None,
    )

    assert captured["workspace"] == tmp_path
    assert captured["target_dir"]  # auto-derived subfolder name, non-empty
    assert "portfolio" in captured["prompt"].lower()


def test_current_workspace_turn_continues_pending_greenfield_in_subfolder(tmp_path, monkeypatch):
    (tmp_path / "package.json").write_text('{"name":"demo"}', encoding="utf-8")
    save_agent_state(
        tmp_path,
        {
            "original_prompt": "demo",
            "pending_workspace_decision": {
                "active": True,
                "original_prompt": "build me a portfolio using my resume",
                "proposed_subdir": "portfolio-site",
                "mode": "",
                "image_urls": [],
                "command_hint": "build",
                "requested_at_utc": "2026-03-19T00:00:00Z",
            },
        },
    )
    captured = {}

    monkeypatch.setattr(
        agent,
        "_run_build_prompt_in_workspace",
        lambda workspace_path, project_name, prompt, verbose, image_urls, target_dir="": captured.update(
            {"workspace": workspace_path, "project": project_name, "prompt": prompt, "target_dir": target_dir}
        ),
    )

    agent._run_current_workspace_turn(
        tmp_path,
        "demo",
        "separate app",
        verbose=False,
        image_urls=None,
    )

    assert captured["workspace"] == tmp_path
    assert captured["prompt"] == "build me a portfolio using my resume"
    assert captured["target_dir"] == "portfolio-site"


def test_current_workspace_turn_routes_build_it_to_recent_target_action(tmp_path, monkeypatch):
    save_agent_state(
        tmp_path,
        {
            "original_prompt": "demo",
            "recent_targets": [
                {
                    "path": "portfolio-site",
                    "kind": "dir",
                    "role": "created",
                    "source": "implementation",
                    "recorded_at_utc": "2026-03-19T00:00:00Z",
                }
            ],
        },
    )
    captured = {}

    monkeypatch.setattr(
        agent,
        "_run_execution_request_turn",
        lambda workspace_path, project_name, user_message, verbose, action_kind="run": captured.update(
            {
                "workspace": workspace_path,
                "project": project_name,
                "message": user_message,
                "action_kind": action_kind,
            }
        ),
    )

    agent._run_current_workspace_turn(
        tmp_path,
        "demo",
        "build it",
        verbose=False,
        image_urls=None,
    )

    assert captured["workspace"] == tmp_path
    assert captured["action_kind"] == "build"


def test_current_workspace_turn_ai_first_routes_execution_request_from_model(tmp_path, monkeypatch):
    captured = {}

    monkeypatch.setattr(
        "nexcode.config.load_agent_config",
        lambda *args, **kwargs: {
            "model": "demo",
            "assistant_routing_strategy": "ai_first",
            "assistant_intent_mode": "conservative",
        },
    )
    monkeypatch.setattr(
        agent,
        "_classify_workspace_route_with_model",
        lambda *args, **kwargs: {
            "route": "execution_request",
            "intent": "",
            "consult_request": "",
            "implementation_request": "",
            "action_kind": "test",
            "target_hint": "project",
            "reason": "model_execution",
        },
    )
    monkeypatch.setattr(
        agent,
        "_run_execution_request_turn",
        lambda workspace_path, project_name, user_message, verbose, action_kind="run": captured.update(
            {
                "workspace": workspace_path,
                "project": project_name,
                "message": user_message,
                "action_kind": action_kind,
            }
        ),
    )

    agent._run_current_workspace_turn(
        tmp_path,
        "demo",
        "test the project we edited",
        verbose=False,
        image_urls=None,
    )

    assert captured["workspace"] == tmp_path
    assert captured["action_kind"] == "test"


def test_current_workspace_turn_ai_first_does_not_trust_model_target_hint_for_execution(tmp_path, monkeypatch):
    captured = {}

    monkeypatch.setattr(
        "nexcode.config.load_agent_config",
        lambda *args, **kwargs: {
            "model": "demo",
            "assistant_routing_strategy": "ai_first",
            "assistant_intent_mode": "conservative",
        },
    )
    monkeypatch.setattr(
        agent,
        "_classify_workspace_route_with_model",
        lambda *args, **kwargs: {
            "route": "execution_request",
            "intent": "",
            "consult_request": "",
            "implementation_request": "",
            "action_kind": "run",
            "target_hint": "notes.txt",
            "reason": "model_execution",
        },
    )
    monkeypatch.setattr(
        agent,
        "_emit_direct_agent_response",
        lambda workspace_path, project_name, user_message, formatted_message, **kwargs: captured.update(
            {"resolution_type": kwargs["resolution_type"], "message": formatted_message}
        ),
    )

    agent._run_current_workspace_turn(
        tmp_path,
        "demo",
        "can you show me what the script outputs",
        verbose=False,
        image_urls=None,
    )

    assert captured["resolution_type"] == "need_more_info"
    assert "could not identify" in captured["message"].lower()


def test_current_workspace_turn_ai_first_falls_back_to_heuristics_without_second_model_call(tmp_path, monkeypatch):
    captured = {}

    monkeypatch.setattr(
        "nexcode.config.load_agent_config",
        lambda *args, **kwargs: {
            "model": "demo",
            "assistant_routing_strategy": "ai_first",
            "assistant_intent_mode": "conservative",
        },
    )
    monkeypatch.setattr(agent, "_classify_workspace_route_with_model", lambda *args, **kwargs: None)
    monkeypatch.setattr(
        agent,
        "_classify_assistant_intent_with_model",
        lambda *args, **kwargs: pytest.fail("assistant intent model should not rerun during heuristic fallback"),
    )
    monkeypatch.setattr(
        agent,
        "_run_assistant_turn",
        lambda workspace_path, project_name, user_message, verbose, image_urls, routing_override=None, intent_decision_override=None: captured.update(
            {
                "workspace": workspace_path,
                "project": project_name,
                "message": user_message,
                "routing_override": routing_override,
                "intent_decision_override": intent_decision_override,
            }
        ),
    )

    agent._run_current_workspace_turn(tmp_path, "demo", "fix mobile nav spacing", verbose=False, image_urls=None)

    assert captured["workspace"] == tmp_path
    assert captured["routing_override"] is None
    assert captured["intent_decision_override"]["intent"] == "implementation"
    assert captured["intent_decision_override"]["reason"].startswith("heuristic_")


def test_handle_agent_cli_routes_plain_message_to_current_workspace(tmp_path, monkeypatch):
    captured = {}
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(
        agent,
        "_run_current_workspace_turn",
        lambda workspace_path, project_name, user_message, verbose, image_urls, command_hint="": captured.update(
            {
                "workspace": workspace_path,
                "project": project_name,
                "message": user_message,
                "command_hint": command_hint,
            }
        ),
    )

    agent.handle_agent_cli(["pls", "fix", "landing", "page"], piped_content="", verbose=False, image_urls=None)

    assert captured["workspace"] == tmp_path
    assert captured["message"] == "pls fix landing page"
    assert captured["command_hint"] == ""


def test_handle_agent_cli_no_args_starts_current_workspace_repl(tmp_path, monkeypatch):
    captured = {}
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(
        agent,
        "_run_workspace_repl",
        lambda workspace_path, project_name, piped_content, verbose, image_urls, prompt_label, turn_runner, command_hint="": captured.update(
            {
                "workspace": workspace_path,
                "project": project_name,
                "prompt_label": prompt_label,
                "command_hint": command_hint,
            }
        ),
    )

    agent.handle_agent_cli([], piped_content="", verbose=False, image_urls=None)

    assert captured["workspace"] == tmp_path
    assert captured["prompt_label"] == "agent"


def test_handle_agent_cli_new_in_uses_subfolder_build(tmp_path, monkeypatch):
    captured = {}
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(
        agent,
        "_run_build_prompt_in_workspace",
        lambda workspace_path, project_name, prompt, verbose, image_urls, target_dir="": captured.update(
            {"workspace": workspace_path, "project": project_name, "prompt": prompt, "target_dir": target_dir}
        ),
    )

    agent.handle_agent_cli(
        ["--new-in", "portfolio", "make", "a", "portfolio", "using", "my", "resume"],
        piped_content="",
        verbose=False,
        image_urls=None,
    )

    assert captured["workspace"] == tmp_path / "portfolio"
    assert "portfolio" in captured["prompt"].lower()


def test_handle_agent_cli_resume_defaults_to_current_workspace(tmp_path, monkeypatch):
    captured = {}
    monkeypatch.chdir(tmp_path)
    save_agent_state(tmp_path, {"original_prompt": "demo", "plan": [{"step": 1, "task": "do thing"}], "completed_steps": []})
    monkeypatch.setattr(
        agent,
        "_run_resume_for_workspace",
        lambda workspace_path, project_name, verbose: captured.update(
            {"workspace": workspace_path, "project": project_name, "verbose": verbose}
        ),
    )

    agent.handle_agent_cli(["resume"], piped_content="", verbose=False, image_urls=None)

    assert captured["workspace"] == tmp_path


def test_load_agent_config_merges_local_override(tmp_path, monkeypatch):
    global_cfg = tmp_path / "agent.yaml"
    global_cfg.write_text("model: global-model\nmax_steps: 50\n", encoding="utf-8")
    local_cfg = tmp_path / ".agent" / "agent.yaml"
    local_cfg.parent.mkdir(parents=True, exist_ok=True)
    local_cfg.write_text("model: local-model\nmax_steps: 12\n", encoding="utf-8")

    monkeypatch.setattr(config, "AGENT_CONFIG_FILE", global_cfg)
    monkeypatch.setattr(config, "init_home", lambda: None)

    loaded = config.load_agent_config(tmp_path)

    assert loaded["model"] == "local-model"
    assert loaded["max_steps"] == 12


def test_list_files_and_grep_search_ignore_agent_dir(tmp_path):
    (tmp_path / ".agent").mkdir()
    (tmp_path / ".agent" / "secret.txt").write_text("token\n", encoding="utf-8")
    (tmp_path / "app.py").write_text("print('hello')\n", encoding="utf-8")

    listed = list_files(tmp_path, ".")
    searched = grep_search(tmp_path, "token", ".")

    assert "app.py" in listed
    assert ".agent/secret.txt" not in listed
    assert "No matches found" in searched


def test_create_snapshot_skips_git_for_in_place_workspace(tmp_path, monkeypatch):
    calls = []

    monkeypatch.setattr("nexcode.agent_runtime.snapshot.subprocess.run", lambda *args, **kwargs: calls.append(args))

    create_snapshot(tmp_path, 1)

    assert calls == []


def test_current_workspace_turn_routes_execution_request_to_direct_runner(tmp_path, monkeypatch):
    captured = {}

    monkeypatch.setattr(
        agent,
        "_run_execution_request_turn",
        lambda workspace_path, project_name, user_message, verbose, action_kind="run": captured.update(
            {"workspace": workspace_path, "project": project_name, "message": user_message, "action_kind": action_kind}
        ),
    )

    agent._run_current_workspace_turn(
        tmp_path,
        "demo",
        "can you run test.py and tell me what you see?",
        verbose=False,
        image_urls=None,
    )

    assert captured["workspace"] == tmp_path
    assert captured["message"].startswith("can you run test.py")
    assert captured["action_kind"] == "run"


def test_list_files_and_grep_search_ignore_vendor_and_html_but_direct_read_still_works(tmp_path):
    (tmp_path / "vendor").mkdir()
    (tmp_path / "vendor" / "lib.txt").write_text("vendored-token\n", encoding="utf-8")
    (tmp_path / "html").mkdir()
    (tmp_path / "html" / "index.html").write_text("generated-token\n", encoding="utf-8")
    (tmp_path / "app.py").write_text("print('hello')\n", encoding="utf-8")

    listed = list_files(tmp_path, ".")
    searched = grep_search(tmp_path, "generated-token", ".")
    direct = read_file(tmp_path, "html/index.html")

    assert "app.py" in listed
    assert "vendor/lib.txt" not in listed
    assert "html/index.html" not in listed
    assert "No matches found" in searched
    assert "generated-token" in direct


def test_task_scope_prefers_root_file_and_caps_workspace_summary(tmp_path):
    (tmp_path / "go.mod").write_text("module demo\n", encoding="utf-8")
    (tmp_path / "test.py").write_text("print('ok')\n", encoding="utf-8")
    (tmp_path / "ui").mkdir()
    (tmp_path / "ui" / "package.json").write_text('{"name":"ui"}', encoding="utf-8")
    (tmp_path / "html").mkdir()
    for idx in range(300):
        (tmp_path / "html" / f"page-{idx}.html").write_text("content\n", encoding="utf-8")

    scope = resolve_task_scope(tmp_path, user_message="please run test.py and tell me output")
    profile = detect_project_profile(tmp_path, task_scope=scope)
    summary = build_workspace_summary(tmp_path, scope)

    assert scope.focused_files == ("test.py",)
    assert scope.primary_root == tmp_path
    assert "python" in profile.stack_ids
    assert "html/page-299.html" not in summary
    assert len(summary) <= 12000
