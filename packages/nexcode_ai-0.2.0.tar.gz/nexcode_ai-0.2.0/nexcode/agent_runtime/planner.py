"""
planner.py — Queries the AI to generate a structured implementation plan.
"""
import json
import re
from pathlib import Path
from rich.console import Console

from nexcode.config import load_access, load_agent_config
from nexcode.agent_runtime.prompt_context import build_compact_workspace_summary
from nexcode.agent_runtime.presentation import ui_detail, ui_status
from nexcode.agent_runtime.workspace import save_agent_state, load_agent_state

console = Console()


def _strip_fences(text: str) -> str:
    """Remove markdown code fences from LLM response."""
    text = text.strip()
    # Remove ```json ... ``` or ``` ... ```
    m = re.search(r'```(?:json)?\s*([\s\S]*?)```', text)
    if m:
        return m.group(1).strip()
    # Remove single-line fence prefix/suffix
    if text.startswith("```"):
        text = text[3:]
    if text.endswith("```"):
        text = text[:-3]
    return text.strip()


def extract_plan_steps(payload):
    """Normalize plan payloads that may be either a bare list or an object with a plan key."""
    if isinstance(payload, dict) and isinstance(payload.get("plan"), list):
        return payload["plan"]
    if isinstance(payload, list):
        return payload
    return None


def repair_json_plan(text: str):
    """
    Tolerant JSON plan parser. Returns a list of step dicts or None.

    Strategy:
      1. Strip markdown fences.
      2. Try strict json.loads — fastest path for clean responses.
      3. Regex-scan for the outermost JSON array and try again — handles some
         cases of trailing text or minor prefix garbage.
      4. Item-level rescue: scan for each {...} step object individually and
         reconstruct the list. Handles plans where an internal string contains
         an unescaped double quote (e.g. LLM embeds code in task/design_notes).
    """
    text = _strip_fences(text)

    # 1. Strict parse
    try:
        result = json.loads(text)
        normalized = extract_plan_steps(result)
        if normalized is not None:
            return normalized
    except Exception:
        pass

    # 2. Find outermost [ ... ] array boundary or object boundary
    start = text.find('{')
    if start != -1:
        for end in range(len(text) - 1, start, -1):
            if text[end] == '}':
                candidate = text[start:end + 1]
                try:
                    result = json.loads(candidate)
                    normalized = extract_plan_steps(result)
                    if normalized is not None:
                        return normalized
                except Exception:
                    break
                    
    start = text.find('[')
    if start != -1:
        for end in range(len(text) - 1, start, -1):
            if text[end] == ']':
                candidate = text[start:end + 1]
                try:
                    result = json.loads(candidate)
                    normalized = extract_plan_steps(result)
                    if normalized is not None:
                        return normalized
                except Exception:
                    break  # the slice is still broken; fall through

    # 3. Item-level rescue — extract each step object individually.
    # We look for objects that contain the key "step" and "task".
    # For each, we parse only the keys we need safely.
    steps = []
    # Find all top-level { ... } blobs that look like step objects
    depth = 0
    obj_start = None
    for i, ch in enumerate(text):
        if ch == '{' and depth == 0:
            obj_start = i
            depth = 1
        elif ch == '{':
            depth += 1
        elif ch == '}' and depth == 1:
            depth = 0
            if obj_start is not None:
                blob = text[obj_start:i + 1]
                try:
                    obj = json.loads(blob)
                    if isinstance(obj, dict) and 'step' in obj and 'task' in obj:
                        steps.append(obj)
                except Exception:
                    # Blob has unescaped quotes — do a targeted safe extraction
                    safe = _safe_extract_step(blob)
                    if safe:
                        steps.append(safe)
                obj_start = None
        elif ch == '}':
            depth -= 1

    if steps:
        return steps
    return None


def _safe_extract_step(blob: str) -> dict | None:
    """
    Extract key fields from a JSON-like step object even when string values
    contain unescaped double quotes.
    Uses targeted regex per known field name.
    """
    def _get_str(key: str) -> str:
        """Extract a string value for key, stops at first unescaped quote + comma/brace."""
        # Match: "key": "value"  — captures up to the next "  followed by , or }
        pattern = rf'"  {re.escape(key)}  "\s*:\s*"(.*?)"(?=\s*[,}}])'
        # Use non-greedy on the value, with DOTALL
        m = re.search(
            rf'"{re.escape(key)}"\s*:\s*"(.*?)"(?=[,\n\r}}])',
            blob, re.DOTALL
        )
        if m:
            return m.group(1)
        return ""

    def _get_int(key: str) -> int | None:
        m = re.search(rf'"{re.escape(key)}"\s*:\s*(\d+)', blob)
        return int(m.group(1)) if m else None

    def _get_list(key: str) -> list:
        m = re.search(rf'"{re.escape(key)}"\s*:\s*(\[[^\]]*\])', blob, re.DOTALL)
        if m:
            try:
                return json.loads(m.group(1))
            except Exception:
                pass
        return []

    step = _get_int('step')
    task = _get_str('task')
    if step is None or not task:
        return None

    return {
        'step': step,
        'task': task,
        'goal': _get_str('goal'),
        'rationale': _get_str('rationale'),
        'files': _get_list('files'),
        'type': _get_str('type') or 'implementation',
        'design_notes': _get_str('design_notes'),
    }


def _normalize_step_schema(step: dict, step_idx: int, is_fix: bool = False) -> dict:
    allowed_types = {"setup", "implementation", "testing", "validation"}
    allowed_scopes = {"single_file", "localized", "project_wide"}
    allowed_validation_levels = {"none", "scoped", "broad"}

    def _clean_text(key: str, fallback: str = "") -> str:
        return str(step.get(key) or fallback).strip()

    raw_files = step.get("files", [])
    if isinstance(raw_files, str):
        files = [raw_files.strip()] if raw_files.strip() else []
    elif isinstance(raw_files, list):
        files = [str(item).strip() for item in raw_files if str(item or "").strip()]
    else:
        files = []

    normalized = {
        "step": int(step.get("step", step_idx) or step_idx),
        "task": _clean_text("task"),
        "goal": _clean_text("goal"),
        "rationale": _clean_text("rationale"),
        "files": files,
        "type": _clean_text("type", "implementation").lower(),
        "design_notes": _clean_text("design_notes"),
        "target_scope": _clean_text("target_scope"),
        "overwrite_existing": bool(step.get("overwrite_existing", False)),
        "validation_level": _clean_text("validation_level"),
    }

    if normalized["type"] not in allowed_types:
        normalized["type"] = "implementation"
    if not normalized["goal"]:
        normalized["goal"] = normalized["task"]
    if is_fix and not normalized["rationale"]:
        normalized["rationale"] = "This step advances the requested fix while keeping the implementation aligned with the investigated root cause."
    if normalized["target_scope"] not in allowed_scopes:
        normalized["target_scope"] = "localized" if len(files) > 1 else "single_file" if len(files) == 1 else "project_wide"
    if normalized["validation_level"] not in allowed_validation_levels:
        if normalized["type"] == "validation":
            normalized["validation_level"] = "broad"
        elif normalized["target_scope"] == "project_wide":
            normalized["validation_level"] = "broad"
        elif normalized["target_scope"] == "single_file":
            normalized["validation_level"] = "scoped"
        else:
            normalized["validation_level"] = "scoped"
    return normalized


def _normalize_plan_schema(plan: list[dict], is_fix: bool = False) -> list[dict]:
    return [_normalize_step_schema(step, idx, is_fix=is_fix) for idx, step in enumerate(plan, start=1)]


def _has_validation_step(plan: list[dict]) -> bool:
    for step in plan:
        if str(step.get("type") or "").strip().lower() == "validation":
            return True
        text = f"{step.get('task', '')} {step.get('goal', '')}".lower()
        if any(token in text for token in ("validate", "verification", "verify", "lint", "build", "test")):
            return True
    return False


def _finalize_fix_plan(plan: list[dict], fix_metadata: dict | None = None, workspace: Path | None = None) -> list[dict]:
    metadata = fix_metadata or {}
    complexity = str(metadata.get("complexity") or "simple").strip().lower()
    normalized = _normalize_plan_schema(plan, is_fix=True)

    if complexity == "complex":
        has_scoped_files = any(step.get("files") for step in normalized if step.get("type") != "validation")
        if not has_scoped_files:
            raise ValueError("Complex fix plan must name impacted files or wiring points.")
        if not _has_validation_step(normalized):
            normalized.append(
                {
                    "step": len(normalized) + 1,
                    "task": "Validate the updated behavior with targeted regression checks",
                    "goal": "Confirm the complex fix works end-to-end and does not regress nearby behavior",
                    "rationale": "Complex changes need an explicit verification pass before the assistant declares success.",
                    "files": [],
                    "type": "validation",
                    "design_notes": "",
                }
            )

    for idx, step in enumerate(normalized, start=1):
        step["step"] = idx
    return normalized


def _normalize_path_tokens(step: dict) -> str:
    files = " ".join(step.get("files", []) or [])
    return f"{step.get('task', '')} {step.get('goal', '')} {files}".lower()


def _looks_like_js_app_plan(plan: list[dict]) -> bool:
    text = " ".join(_normalize_path_tokens(step) for step in plan)
    return any(token in text for token in ("next.js", "create-next-app", "npm install", "app/", "shadcn"))


def _plan_step_priority(step: dict) -> tuple[int, int]:
    text = _normalize_path_tokens(step)
    files = " ".join(step.get("files", []) or []).lower()

    if any(token in text for token in ("create-next-app", "scaffold", "bootstrap", "initialize a new")):
        return (10, 0)
    if "install all required npm packages" in text or "npm install" in text:
        return (20, 0)
    if "shadcn" in text and "init" in text:
        return (30, 0)
    if "shadcn" in text and " add " in f" {text} ":
        return (31, 0)
    if any(token in text for token in ("types/", " type ", "interface ", "schema", "zod schema")):
        return (40, 0)
    if any(token in text for token in ("lib/data", "dummy data", "sample jobs", "store", "hook", "localstorage")):
        return (45, 0)
    if any(token in text for token in ("context", "provider", "providers.tsx")):
        return (50, 0)
    if any(
        token in text for token in (
            "theme foundation",
            "design system",
            "theme provider",
            "next-themes",
            "app shell",
            "layout shell",
            "light and dark",
        )
    ):
        return (55, 0)
    if any(token in text for token in ("polish", "responsive audit", "theme parity", "visual audit", "empty states", "ui refinement")):
        return (88, 0)
    if any(token in text for token in ("globals.css", "tailwind.config", "postcss.config", "theme", "glassmorphism")):
        return (60, 0)
    if any(token in text for token in ("route group", "move existing routes", "move routes", "restructure routes", "folder reorganization", "refactor app structure")):
        return (65, 0)
    if any(token in text for token in ("sidebar", "topbar", "layout.tsx")):
        return (70, 0)
    if any(token in text for token in ("components/", "statscard", "applicationtable", "chartcard", "modal", "kanbanboard")):
        return (75, 0)
    if any(token in text for token in ("app/page.tsx", "dashboard/page.tsx", "applications/page.tsx", "analytics/page.tsx", "calendar/page.tsx", "settings/page.tsx", "landing page", "implement app/")):
        return (80, 0)
    if any(token in text for token in ("test", "validation", "verify", "lint", "build")):
        return (90, 0)
    if "type" in files and "lib/data" in files:
        return (45, 1)
    return (85, 0)


def _reorder_plan_for_execution(plan: list[dict]) -> list[dict]:
    if not plan or not _looks_like_js_app_plan(plan):
        return plan

    indexed = list(enumerate(plan))
    reordered = [step for _, step in sorted(indexed, key=lambda item: (_plan_step_priority(item[1]), item[0]))]
    normalized = []
    for idx, step in enumerate(reordered, start=1):
        updated = dict(step)
        updated["step"] = idx
        normalized.append(updated)
    return normalized

PLANNING_PROMPT = """
You are an expert autonomous software engineer responsible for planning software projects.

User Request (Instruction Memory):
"{instruction_memory}"

Structured Content Memory:
{content_memory}

Design Memory / UI Constraints:
{design_memory}

Existing Workspace Files:
{files}

Your task is to produce a clear development plan that an autonomous coding agent can execute step-by-step.

Before generating the plan, infer the most appropriate:

- project type
- language
- framework or tooling (if applicable)

Examples of project types include:
- CLI tool
- backend API
- frontend application
- full-stack application
- library
- automation script
- debugging / bug fix
- data processing pipeline

The plan must adapt to the requirements of the inferred project type.

-------------------------------------

RULES

1. Steps must be atomic, sequential, and actionable.
2. Each step must represent a concrete development action.
2.1. **Step Scopes (CRITICAL)**: The runtime enforces a step scope guard based on the step's `files` list. If you provide a non-empty `files` list for a step, it MUST include every file that will be created or modified in that step. If a change requires wiring new components into a page/route, include both the component file(s) and the wiring file (e.g. `src/app/page.tsx`) or add a dedicated wiring step.
2.2. **Structural Refactors (CRITICAL)**: For route-group moves, folder reorganizations, broad layout refactors, or similar structural work, use directory scope entries in `files` such as `src/app` or the specific moved directories. Do not under-scope structural steps to only one or two leaf files.
3. CRITICAL FOR UI/WEB: You MUST generate component-level steps. Do not use vague terms like "Create UI". If the `design_memory` provides a `sections` list (e.g. navbar, hero, features, footer), you MUST create a distinct plan step for implementing EACH section individually.
4. **Resolved Workspace Project Root (MANDATORY)**: The runtime provides a resolved workspace project root for application code. If you infer a framework like Next.js, React (Vite), or an API (FastAPI, Flask) is needed, you MUST:
   - Plan scaffolding directly into the resolved workspace project root by default.
   - If the user explicitly requests a separate app, subproject, or nested structure, you may scaffold into the specified subdirectory under the project root instead.
   - Keep setup and implementation steps phrased as actions in the chosen target root (project root by default, or the explicit subdirectory when requested).
   - Keep all later file paths consistent with the chosen scaffold mode. If the scaffold step uses `--src-dir`, later paths must use `src/app`, `src/components`, and `src/lib` rather than root-level `app`, `components`, or `lib`.
   - Only introduce nested folders when the user explicitly requests a monorepo, multi-app structure, or separate subproject.
   - This keeps the Coder Agent aligned with the runtime-owned workspace layout.
5. Only include steps that are necessary to complete the project.
6. Avoid unnecessary technologies or frameworks.
7. Never produce placeholder implementations or TODOs.
8. Prefer production-ready structures and good engineering practices.
9. Use practical workflows used by real software engineers.
10. Prefer 6–10 steps unless the task clearly requires more or fewer.
11. Take existing files in the workspace into account when planning.
12. For frontend or web applications, prefer a modern JavaScript framework like React (via Vite) or Next.js. EXCEPTION: If the user explicitly requests "plain HTML", "Flask", "Django", or any other server-rendered or non-React stack, you MUST honor that choice. In that case, you MUST include a dedicated early step (Step 1 or Step 2) to "Create the CSS design system file (style.css) with all CSS custom properties for colors, typography, spacing, reset, and base component styles" BEFORE any page or component implementation steps. This design system setup step is mandatory and must appear before any UI work begins.
13. **Dedicated Package Install Step (MANDATORY for library-heavy React/Next.js projects)**: If the project requires 3 or more third-party npm packages beyond what `create-next-app` or `create-vite` installs by default (e.g., framer-motion, recharts, @dnd-kit/core, zod, react-hook-form, shadcn/ui, lucide-react, date-fns, react-big-calendar, @radix-ui/*, class-variance-authority, etc.), you MUST create a **dedicated step** to install ALL of these packages together using a single `npm install` command. This step MUST:
   - Come AFTER the scaffolding step (e.g., after `npx create-next-app`) and BEFORE any component implementation steps.
   - Enumerate every non-default package by name in the `design_notes` field.
   - Use the task description: "Install all required npm packages in the project root".
   This prevents "Module not found" errors that occur when packages are missing during component development.
14. **Tailwind/Shadcn Reality (MANDATORY for Next.js)**:
   - Do NOT assume `tailwind.config.ts` or `tailwind.config.js` exists in a freshly scaffolded Next.js + Tailwind project. Tailwind v4 setups may only have `postcss.config.*` plus a globals CSS import.
   - Only include a Tailwind config edit/create step if the chosen packages or design system truly require it.
   - Prefer `npx shadcn@latest` over the deprecated `npx shadcn-ui@latest` when planning shadcn setup steps.
   - Keep shadcn setup isolated into dedicated steps: one step for shadcn initialization and a later step for adding components. Do not mix shadcn work into dependency-install steps.
15. **Dependency Ordering (MANDATORY)**:
   - Foundational types, schemas, and shared interfaces must be created before any data, store, context, or page files that import them.
   - Data/store/context/provider steps must come before pages or components that consume them.
   - If a later step depends on a file from an earlier step, reorder the plan so the dependency exists first.
16. **Theme Foundation Step (MANDATORY for React/Next.js web apps)**:
   - Before page implementation begins, include a dedicated step to establish the global theme foundation and shared app shell.
   - This step should cover the real globals CSS file, semantic color tokens, typography choices, dark/light mode token strategy, and the shared layout shell.
   - If the product includes a settings page, theme selector, or explicit dark/light mode requirement, this step must also include the theme provider and toggle wiring.
17. **UI Composition Quality (MANDATORY for multi-page web apps)**:
   - Shared shell work must be separated from page-specific implementation.
   - Structural route or folder moves must be separated from page content implementation when both are required.
   - Major routes implied by the prompt and design spec should each receive their own implementation step or a clearly grouped pair of steps.
   - Page steps must mention the primary content blocks they are responsible for, not just the file path.
19. **Scoped Retry Friendly Planning**:
   - The Coder may use scratch helpers and alternate in-step approaches, but the plan must still make the current step boundary obvious.
   - Do not mix shell or route-structure work into a layout-only step or mix layout shell work into a page-only step.
18. **Final UI Polish Step (MANDATORY for web apps)**:
   - Include a near-final step to refine responsive spacing, empty states, loading states, hover/focus states, theme parity, and the styling of any task-relevant complex UI surfaces across the implemented routes.
   - This polish step should happen before the final validation/build step so the Coder treats visual quality as deliverable work rather than optional cleanup.


-------------------------------------

STEP SCHEMA

Each step must include the following fields:

{{
  "step": number,
  "task": "short actionable instruction",
  "goal": "purpose of the step",
  "rationale": "strategic reason for this step (why does this target the goal/bug?)",
  "files": ["optional list of related files"],
  "type": "setup | implementation | testing | validation",
  "design_notes": "optional UI/UX or architectural directions for the Component/Step"
}}

Optional planning metadata:
- `target_scope`: `single_file | localized | project_wide`
- `overwrite_existing`: boolean
- `validation_level`: `none | scoped | broad`

Field meanings:

step
Execution order of the step.

task
What the agent should do.

goal
Why the step exists.

files
Optional list of files likely to be created or modified.

type
Category of work being performed.

design_notes
If the task involves UI, CSS, or architecture boundaries, provide explicit style notes or data constraints (e.g. "center card layout with soft shadow").

-------------------------------------

OUTPUT FORMAT

Return ONLY a valid JSON object containing a `"plan"` key which holds the array of steps.

Example format:

{{
  "plan": [
    {{
      "step": 1,
      "task": "Create project folder structure",
      "goal": "Initialize workspace for the project",
      "files": [],
      "type": "setup",
      "design_notes": "Store assets in static/ and structure by clean architecture."
    }},
    {{
      "step": 2,
      "task": "Create dependency configuration file",
      "goal": "Define project dependencies",
      "files": ["requirements.txt"],
      "type": "setup",
      "design_notes": ""
    }}
  ]
}}

-------------------------------------

CRITICAL REQUIREMENTS

The response MUST be valid JSON.

Do NOT include:

- markdown formatting
- code block markers
- explanations
- commentary
- headings
- text outside the JSON array

STRING VALUE SAFETY (CRITICAL — prevents JSON parse errors):
- The "task", "goal", and "design_notes" fields must contain PLAIN ENGLISH descriptions ONLY.
- Do NOT put raw code, CSS rules, JS snippets, HTML tags, or shell commands inside these string fields.
- Do NOT use double-quote characters (") inside string values — they break JSON parsing.
- Describe what to implement in plain prose, not by embedding the actual code.
  CORRECT: "Add a flexbox container with dark background and two equal-width panels side by side"
  WRONG:   "add: .container {{ display: flex; }} <div class='container'>"
- The "files" field must be a valid JSON array of plain path strings.

Return ONLY the JSON object.
"""

FIX_PLANNING_PROMPT = """
You are an expert software engineer planning a focused but production-ready fix for an existing codebase.

The original project goals were:
"{orig_prompt}"

Previous fix context (History):
{fix_history}

LATEST KNOWLEDGE (PREVIOUS Fix Walkthrough):
{last_walkthrough}

Existing Workspace Files:
{files}

Investigation Metadata:
- Complexity: {fix_complexity}
- Confidence: {fix_confidence}
- Reporter checked files/areas:
{checked_files}

The user has reported a specific issue or requested a focused change:
"{prompt}"

Your Task: Produce a complete sequence of implementation steps to resolve the user's issue or request.

## FIXER AGENT RULES

1. **Context Awareness**: Use the provided codebase context and any forensic evidence from the Investigative Bug Report to understand the scope of the problem.
2. **Strategic Rationale**: Every step MUST include a "rationale" field explaining why this specific change solves the reported bug.
3. **Localized vs Broad**: If the user reports a specific localized bug, produce a concise focused fix plan, usually 1-3 steps. If the request is broader or app-wide, you MUST generate a comprehensive plan that covers every affected surface, file, or wiring point.
4. **Thoroughness**: Do not take shortcuts. If a requested change requires modifying 5 different files to be fully complete, you must map out steps for all 5 files or clearly group the affected pattern.
5. **Implementation Steps Only**: Do NOT output tool instructions such as search_file, patch_file, replace_in_file, or line-number actions. Describe the engineering work to implement.
6. **Validation Required**: If the change is non-trivial or broad, end with an explicit validation step.
7. **No Placeholders**: Never suggest placeholders. All code must be final.
8. **Files Matter**: If a step modifies or creates files, list them in the `files` array. Broad changes should still name representative files or wiring points.
9. **Structural Scope Accuracy**: If the fix includes moving routes, reorganizing folders, or shared-shell rewiring, scope that step to the relevant directory roots in `files` rather than only a couple of leaf files.
10. **Preserve Explicit Targets**: If the user explicitly named a file, preserve that path. Do not silently retarget to a different filename.
11. **No Silent Overwrites**: Do not overwrite an existing generic file unless the user or repo context clearly indicates it is the intended target. Use `overwrite_existing=true` only when that intent is explicit.
12. **Scope Honesty**: Set `target_scope` and `validation_level` to match the real blast radius of the step. Narrow tasks should stay narrow.

## Output Format (STRICT)

Return a **valid JSON object containing a "plan" array**.

Example:
{{
  "plan": [
    {{
      "step": 1,
      "task": "Update the shared sidebar rendering logic for collapsed navigation labels",
      "goal": "Fix the broken collapsed sidebar layout in the navigation shell",
      "rationale": "The bug originates in the shared sidebar component, so the fix must start where the broken layout is rendered",
      "files": ["src/components/navigation/Sidebar.tsx"],
      "type": "implementation",
      "design_notes": ""
    }},
    {{
      "step": 2,
      "task": "Validate the navigation shell behavior after the sidebar update",
      "goal": "Confirm the fix works across the affected views without introducing regressions",
      "rationale": "A targeted verification step is needed before the assistant declares the issue resolved",
      "files": [],
      "type": "validation",
      "design_notes": ""
    }}
  ]
}}

Each step must include:
- `step`
- `task`
- `goal`
- `rationale`
- `files`
- `type`
- `design_notes`

When relevant, also include:
- `target_scope`
- `overwrite_existing`
- `validation_level`
"""

from nexcode.agent_runtime.token_utils import UsageData


def _format_fix_history_for_prompt(fix_history: list | None) -> str:
    lines: list[str] = []
    for entry in (fix_history or []):
        if isinstance(entry, dict):
            request = str(entry.get("prompt", "Unknown")).strip() or "Unknown"
            outcome = str(entry.get("outcome", "No summary available.")).strip() or "No summary available."
            lines.append(f"- Request: {request}\n  Action Taken: {outcome}")
        else:
            text = str(entry).strip()
            if text:
                lines.append(f"- {text}")
    return "\n".join(lines)


def _format_checked_files_for_prompt(checked_files: object) -> str:
    if isinstance(checked_files, list):
        lines = [f"- {str(path).strip()}" for path in checked_files if str(path).strip()]
        return "\n".join(lines) or "- none recorded"
    checked = str(checked_files or "").strip()
    return f"- {checked}" if checked else "- none recorded"


def _build_fix_planning_prompt(
    *,
    prompt: str,
    orig_prompt: str,
    fix_history: list | None,
    last_walkthrough: str,
    files: str,
    fix_metadata: dict | None = None,
) -> str:
    metadata = fix_metadata or {}
    return FIX_PLANNING_PROMPT.format(
        prompt=prompt,
        orig_prompt=orig_prompt,
        fix_history=_format_fix_history_for_prompt(fix_history),
        last_walkthrough=last_walkthrough,
        files=files,
        fix_complexity=str(metadata.get("complexity") or "simple"),
        fix_confidence=str(metadata.get("confidence") or "medium"),
        checked_files=_format_checked_files_for_prompt(metadata.get("checked_files")),
    )

# Cache OpenAI clients to avoid TCP+TLS handshake on every call
_client_cache: dict = {}


def _get_cached_client(endpoint: str, api_key: str):
    """Return a cached OpenAI client, creating one if needed."""
    from openai import OpenAI
    import httpx
    key = (endpoint, api_key)
    if key not in _client_cache:
        _client_cache[key] = OpenAI(
            base_url=endpoint,
            api_key=api_key,
            timeout=httpx.Timeout(900.0)
        )
    return _client_cache[key]


def _call_gateway(api_key: str, endpoint: str, model: str, system_prompt: str, user_prompt: str | list, json_mode: bool = True) -> tuple[str, UsageData]:
    """Helper to call the chat completions API non-streaming for the agent."""

    # Detect provider to handle API differences
    acc = load_access()
    provider = acc.get("provider", "grok").lower()
    is_gemini = provider == "gemini"

    # Guarantee LLM knows it must output JSON (if json_mode is True)
    # For Gemini, reinforce via prompt since response_format is not supported
    if json_mode and not system_prompt.endswith("JSON.") and not system_prompt.endswith("JSON"):
        system_prompt += "\n\nCRITICAL: You must return ONLY valid JSON. No prefix, no suffix, no codeblocks."

    client = _get_cached_client(endpoint, api_key)

    kwargs = {
        "model": model,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ],
        "stream": False,
        "temperature": 0.2,
    }

    # response_format json_object is supported by Grok but NOT by Gemini
    if json_mode and not is_gemini:
        kwargs["response_format"] = {"type": "json_object"}

    resp = client.chat.completions.create(**kwargs)
    
    # Extract usage data
    usage = UsageData()
    if hasattr(resp, 'usage') and resp.usage:
        usage.input_tokens = resp.usage.get('prompt_tokens', 0) if isinstance(resp.usage, dict) else getattr(resp.usage, 'prompt_tokens', 0)
        usage.output_tokens = resp.usage.get('completion_tokens', 0) if isinstance(resp.usage, dict) else getattr(resp.usage, 'completion_tokens', 0)
        usage.total_tokens = resp.usage.get('total_tokens', 0) if isinstance(resp.usage, dict) else getattr(resp.usage, 'total_tokens', 0)
        
        # Grok-specific reasoning tokens if available
        if not is_gemini and hasattr(resp.usage, 'completion_tokens_details') and resp.usage.completion_tokens_details:
            usage.reasoning_tokens = getattr(resp.usage.completion_tokens_details, 'reasoning_tokens', 0)

    if hasattr(resp.choices[0], 'message') and hasattr(resp.choices[0].message, 'content'):
        content = resp.choices[0].message.content
        if content:
            return content.strip(), usage

    # Fallback
    return str(resp).strip(), usage


def generate_plan(
    user_prompt: str,
    workspace: Path,
    verbose: bool = False,
    image_urls: list[str] = None,
    is_fix: bool = False,
    orig_prompt: str = "",
    fix_history: list = None,
    fix_metadata: dict | None = None,
) -> list:
    """
    Generate a structured JSON plan and save it to the agent memory.
    """
    console.print(ui_status("Planning", "Generating implementation plan"))
    acc = load_access()
    agent_cfg = load_agent_config(workspace)
    state = load_agent_state(workspace)
    
    api_key = acc["api_key"]
    endpoint = acc["endpoint"]
    model = agent_cfg["model"]
    
    if not api_key:
        console.print(ui_status("Error", "Not logged in. Please run `nexcode login`.", tone="error"))
        return []
        
    sys_prompt = "You are a planning AI."
    
    current_files, _ = build_compact_workspace_summary(
        workspace,
        query=user_prompt,
        checked_files=list((fix_metadata or {}).get("checked_files", []) or []),
        top_k=15,
        max_chars=10000,
    )
    
    if is_fix:
        last_walkthrough = state.get("last_fix_walkthrough", "No previous walkthrough available.")
        user_p = _build_fix_planning_prompt(
            prompt=user_prompt,
            orig_prompt=orig_prompt,
            fix_history=fix_history,
            last_walkthrough=last_walkthrough,
            files=current_files,
            fix_metadata=fix_metadata,
        )
    else:
        state = load_agent_state(workspace)
        inst_mem = state.get("instruction_memory", user_prompt)
        cont_mem = json.dumps(state.get("content_memory", {}), indent=2)
        arch_mem = state.get("architecture_memory", "")
        design_mem_json = json.dumps(state.get("design_memory", {}), indent=2)
        des_mem = f"{arch_mem}\n\n---\nStructured Design Memory:\n{design_mem_json}" if arch_mem else design_mem_json
        user_p = PLANNING_PROMPT.format(
            instruction_memory=inst_mem,
            content_memory=cont_mem,
            design_memory=des_mem,
            files=current_files
        )
    
    if image_urls:
        user_p = [{"type": "text", "text": user_p}]
        for url in image_urls:
            user_p.append({
                "type": "image_url",
                "image_url": {
                    "url": url
                }
            })
    
    if verbose:
        console.print(ui_detail("Model", f"Generating plan with {model}"))
        
    response_text = ""
    for attempt in range(1, 3):  # max 2 attempts
        try:
            response_text, usage = _call_gateway(api_key, endpoint, model, sys_prompt, user_p)
            
            # Track usage in state if workspace is available
            try:
                state = load_agent_state(workspace)
                cum_usage = UsageData.from_dict(state.get("cumulative_usage", {}))
                cum_usage.add(usage, model=model)
                state["cumulative_usage"] = cum_usage.to_dict()
                save_agent_state(workspace, state)
            except Exception:
                pass

            # Tolerant parse: handles fences, minor prefix garbage, and plans where
            # the LLM embedded code snippets with unescaped quotes in string values.
            plan = repair_json_plan(response_text)

            if not plan or not isinstance(plan, list):
                raise ValueError(f"repair_json_plan returned invalid result: {type(plan)}")

            for item in plan:
                if 'step' not in item or 'task' not in item:
                    raise ValueError(f"Step missing required keys: {item}")

            if is_fix:
                plan = _finalize_fix_plan(plan, fix_metadata=fix_metadata, workspace=workspace)
            else:
                plan = _normalize_plan_schema(plan)

            plan = _reorder_plan_for_execution(plan)

            console.print(ui_status("Planning", f"Plan generated ({len(plan)} steps)", tone="success"))
            if verbose:
                for s in plan:
                    console.print(ui_detail(f"Step {s['step']}", s["task"][:80]))

            # Save to memory ONLY if it's the initial build plan.
            # For fix plans, agent.py handles extending the existing plan.
            if not is_fix:
                state = load_agent_state(workspace)
                state["plan"] = plan
                save_agent_state(workspace, state)
                
            return plan

        except Exception as e:
            console.print(ui_status("Warning", f"Plan parse attempt {attempt}/2 failed: {e}", tone="warning"))
            if verbose:
                console.print(ui_detail("Raw preview", response_text[:500]))

            if attempt == 1:
                # Retry with a stricter prompt: forbid code snippets in string values
                strict_suffix = (
                    "\n\n[STRICT MODE] The previous plan had JSON parse errors because you embedded "
                    "code snippets with double-quote characters inside JSON string values. "
                    "RULES for this retry:\n"
                    "  1. The 'task' and 'design_notes' fields must contain PLAIN ENGLISH ONLY — "
                    "no raw code, no CSS, no JS snippets, no backticks, no double-quotes.\n"
                    "  2. If you need to describe a code change, use plain prose: "
                    "e.g. 'Add a flex container div' NOT code or HTML with double-quotes.\n"
                    "  3. The 'files' field must be a valid JSON array of strings.\n"
                    "  4. Return ONLY the JSON object, no other text."
                )
                if isinstance(user_p, list):
                    user_p[0]["text"] = user_p[0]["text"] + strict_suffix
                else:
                    user_p = user_p + strict_suffix

    console.print(ui_status("Error", "Failed to generate a valid plan after 2 attempts.", tone="error"))
    return []
