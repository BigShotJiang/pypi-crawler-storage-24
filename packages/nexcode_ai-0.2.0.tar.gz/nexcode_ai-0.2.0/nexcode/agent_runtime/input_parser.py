import json
from pathlib import Path
from rich.console import Console

from nexcode.config import load_access, load_agent_config
from nexcode.agent_runtime.presentation import ui_detail, ui_status
from nexcode.agent_runtime.workspace import save_agent_state, load_agent_state
from nexcode.agent_runtime.planner import _call_gateway

console = Console()

PARSER_SYSTEM_PROMPT = """
You are a Universal Input Parser for an autonomous coding agent.
Your job is to analyze the user's prompt, piped content, and any provided images to extract distinct memory layers.

Extract the input into exactly three categories, returned as a strict JSON object:

1. `instruction_memory`: The core task description. What needs to be built? (e.g. "Build a React portfolio website").
2. `content_memory`: A structured JSON object containing raw data/text that MUST appear in the final output (e.g. resumes, company descriptions, features). Do NOT summarize or hallucinate. Preserve the exact strings, data points, or skills.
   - You MUST also generate a `compressed_content_memory` string alongside this if the data is huge, which summarizes the content while preserving the exact strings that must be injected into the UI. If the data is small, `compressed_content_memory` can just be a JSON string of the `content_memory`.
3. `design_memory`: Visual layout constraints extracted from text or images.
   - You MUST explicitly include a `sections` array (e.g. `["navbar", "hero", "features", "footer"]`).
   - Include any other layout, theme, or styling hints.

# OUTPUT FORMAT (STRICT JSON)

{
  "instruction_memory": "...",
  "content_memory": {
    "profile": {...},
    "data_points": [...]
  },
  "compressed_content_memory": "...",
  "design_memory": {
    "layout": "...",
    "sections": ["..."]
  }
}
"""

def parse_input(user_prompt: str, workspace: Path, image_urls: list[str] = None, verbose: bool = False) -> dict:
    """
    Parses the raw user input into instruction, content, and design memories.
    Saves the structured memory into the agent state.
    """
    console.print(ui_status("Parsing", "Building structured memory layers"))
    
    acc = load_access()
    agent_cfg = load_agent_config(workspace)
    
    api_key = acc["api_key"]
    endpoint = acc["endpoint"]
    model = agent_cfg["model"]
    
    if not api_key:
        return {}
        
    user_p = f"User Input:\n{user_prompt}"
    
    if image_urls:
        user_p = [{"type": "text", "text": user_p}]
        for url in image_urls:
            user_p.append({
                "type": "image_url",
                "image_url": {
                    "url": url
                }
            })
        
    if verbose:
        console.print(ui_detail("Model", f"Extracting input structure with {model}"))
        
    try:
        response_text, _usage = _call_gateway(api_key, endpoint, model, PARSER_SYSTEM_PROMPT, user_p)
        
        # Clean up possible markdown fences
        if response_text.startswith("```json"):
            response_text = response_text[7:]
        if response_text.startswith("```"):
            response_text = response_text[3:]
        if response_text.endswith("```"):
            response_text = response_text[:-3]
            
        from nexcode.agent_runtime.executor import extract_json

        parsed_data = extract_json(response_text.strip())
        if not isinstance(parsed_data, dict):
            parsed_data = json.loads(response_text.strip())
        
        # Save to memory
        state = load_agent_state(workspace)
        state["raw_user_prompt"] = user_prompt
        state["instruction_memory"] = parsed_data.get("instruction_memory", "")
        state["content_memory"] = parsed_data.get("content_memory", {})
        state["compressed_content_memory"] = parsed_data.get("compressed_content_memory", "")
        state["design_memory"] = parsed_data.get("design_memory", {"sections": []})
        save_agent_state(workspace, state)
        
        console.print(ui_status("Parsing", "Structured memory saved", tone="success"))
        return parsed_data
        
    except Exception as e:
        console.print(ui_status("Warning", f"Input parsing fell back to raw instruction memory: {e}", tone="warning"))
        state = load_agent_state(workspace)
        state["raw_user_prompt"] = user_prompt
        state["instruction_memory"] = user_prompt
        state["content_memory"] = {"raw_user_input": user_prompt}
        state["compressed_content_memory"] = user_prompt
        state["design_memory"] = {"sections": [], "raw_prompt": user_prompt}
        save_agent_state(workspace, state)
        
        return {
            "instruction_memory": user_prompt,
            "content_memory": {"raw_user_input": user_prompt},
            "compressed_content_memory": user_prompt,
            "design_memory": {"sections": [], "raw_prompt": user_prompt}
        }
