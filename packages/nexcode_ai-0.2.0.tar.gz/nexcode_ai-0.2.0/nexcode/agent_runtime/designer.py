"""
designer.py — Generates a UI and Architecture design spec before execution.
"""
import json
from pathlib import Path
from rich.console import Console

from nexcode.config import load_access, load_agent_config
from nexcode.agent_runtime.presentation import ui_detail, ui_status
from nexcode.agent_runtime.workspace import save_agent_state, load_agent_state, get_agent_dir
from nexcode.agent_runtime.planner import _call_gateway

console = Console()


def _normalize_contract_path(path: str) -> str:
    return str(Path(path).as_posix()).lstrip("./")


def _derive_ui_contract(plan: list, design_spec: str) -> dict:
    design_lower = (design_spec or "").lower()
    files = []
    for step in plan or []:
        files.extend(step.get("files", []) or [])

    normalized_files = sorted({_normalize_contract_path(path) for path in files if path})
    page_files = [path for path in normalized_files if path.endswith("/page.tsx") or path.endswith("\\page.tsx")]
    layout_files = [path for path in normalized_files if path.endswith("layout.tsx")]
    globals_files = [path for path in normalized_files if path.endswith("globals.css")]

    protected_shell_files = set(layout_files + globals_files)
    for path in normalized_files:
        lower = path.lower()
        if any(token in lower for token in ("sidebar", "navbar", "topbar", "header", "shell", "theme-toggle", "page-header", "pageheader", "nav/")):
            protected_shell_files.add(path)

    route_contracts = {}
    for page in page_files:
        route_contracts[page] = {
            "requires_header": True,
            "requires_empty_state": any(token in page.lower() for token in ("tasks", "notes", "applications", "settings", "dashboard")),
        }

    return {
        "requires_shared_shell": len(page_files) >= 2,
        "requires_theme_tokens": bool(page_files),
        "requires_theme_toggle": "theme switch" in design_lower or "theme toggle" in design_lower or "settings screen" in design_lower,
        "protected_shell_files": sorted(protected_shell_files),
        "page_files": page_files,
        "layout_files": layout_files,
        "globals_files": globals_files,
        "route_contracts": route_contracts,
        "required_theme_tokens": [
            "--background",
            "--foreground",
            "--card",
            "--card-foreground",
            "--border",
            "--primary",
            "--primary-foreground",
        ],
    }

DESIGNER_PROMPT = """
You are an Expert Software Architect and UI/UX Designer.

The user has requested the following system:
"{prompt}"

The Planner agent has proposed the following steps:
{plan}

Design Phase Guidance:
{phase_instructions}

Your task is to generate a comprehensive "Design Spec" (Architecture Memory) before the Coder begins implementation.

---

## Step 1: Stack Detection

Identify the tech stack from the plan. Classify it as one of:
- **React/Next.js** (Tailwind CSS available)
- **Plain HTML/CSS** (no framework)
- **Flask/Django/Jinja** (server-rendered templates with CSS)
- **Vue/Svelte** (component-based, scoped styles)
- **Vanilla JS with CSS** (no build step)

State the detected stack at the top of your output.

---

## Step 2: Required Sections

### 1. Component / File Architecture
List every top-level module, route, page, or UI component the Coder will need to create. Include file paths.

### 2. State & Data Flow
Describe how data is managed and passed between components, routes, or template contexts.

### 3. UI/UX Design System (CRITICAL — tailor to detected stack)

**For React/Next.js stacks:** 
You MUST output a "Premium Next.js Design System Specification" covering:
#### 0. Scaffold Awareness
- If the scaffold uses `--src-dir`, all route and component paths MUST live under `src/` (for example `src/app/page.tsx`, `src/components/...`, `src/lib/...`).
- Do NOT assume `tailwind.config.ts` exists. In Tailwind v4 Next.js projects, the default setup may rely on `postcss.config.*` plus `@import "tailwindcss"` in the real globals CSS file.

#### a. Visual Identity
Infer the most appropriate visual direction from the user's product, audience, domain, and requested mood.
- Do NOT default to one signature style, color family, or layout pattern across all projects.
- If the user gave brand hints or references, follow them. Otherwise choose a visual direction that fits the task and briefly justify it.
- You may name the style if helpful, but it should be a task-specific choice rather than a fixed preset list.
- Name the visual direction and explain why it fits the user's app.
- Define the headline style, supporting body text tone, icon treatment, card density, and how the layout should avoid looking generic.
- If the prompt implies dashboards, analytics, kanban, or other data-heavy views, describe how each page still feels intentional instead of becoming a generic data screen.

#### b. Theme Foundation (MANDATORY)
You MUST define a concrete dark/light theme contract:
- Default theme and fallback theme
- Semantic tokens to implement in globals CSS for both modes: `--background`, `--foreground`, `--muted`, `--muted-foreground`, `--card`, `--card-foreground`, `--border`, `--input`, `--primary`, `--primary-foreground`, `--accent`, `--accent-foreground`, `--ring`
- Distinct light mode guidance so it does not become washed-out white with weak contrast
- Distinct dark mode guidance so it does not collapse into one flat, low-contrast surface
- Theme switch behavior and placement (for example, top bar toggle or settings screen), and whether `next-themes` is required

#### c. Typography & Visual Rhythm
- Name the preferred font family and fallback stack
- Define heading scale, body scale, and label/caption treatment
- Specify how to create hierarchy across page titles, section titles, supporting UI, dense data areas, and helper text

#### d. App Shell & Layout Patterns
- Define the full shell: sidebar, top bar, content container width, padding rhythm, and mobile collapse behavior
- If the app has multiple authenticated pages, specify a reusable shell that every route must share
- Choose structural patterns that fit the product. Use asymmetric grids, dashboards, editorial layouts, dense workspaces, or simpler content columns only when they improve clarity

#### e. Page Composition Map (MANDATORY)
For every major route or page implied by the plan, provide a short composition map:
- page purpose
- hero or page header block
- primary action area
- main content blocks
- empty / loading / error state treatment

#### f. Component Polish Rules
- Specify `shadcn/ui` component styling and variant usage
- Cards should feel elevated and tactile, not like flat rectangles
- Any forms, data views, visualizations, schedules, or interactive surfaces present in the task must be themed to match the design system
- If the app includes structured data views, specify readability, row density, grouping, and hover/focus treatment
- If the app includes charts or other visualizations, specify palette, labeling, and readability in both themes

#### g. Interactions & Animations
- **Stagger**: All lists and grids should use subtle staggered entry where it helps
- **Hover**: Cards and action controls should have restrained hover motion
- **Entry**: Pages should use an opacity + Y-offset entry animation
- Mention where motion should be avoided for readability

#### h. Visual QA Checklist (MANDATORY)
Provide a short checklist the Coder can use before finishing:
- dark mode and light mode both readable
- no page uses a flat single-color background with weak contrast
- every major page has a header, supporting copy, and clear actions
- empty/loading states exist
- all task-relevant interactive or data-heavy views inherit the theme correctly

**For all other stacks (Plain HTML/CSS, Flask/Django, Vue, Svelte, Vanilla JS):** You MUST output a complete CSS Design System Specification covering ALL of the following:

#### a. CSS Custom Properties Token Set
Define the full `:root {{}}` variable names AND their exact values to use:
- **Colors:** `--color-primary` (hex), `--color-primary-hover` (hex), `--color-secondary` (hex), `--color-bg` (hex), `--color-surface` (hex), `--color-surface-elevated` (hex), `--color-text` (hex), `--color-text-muted` (hex), `--color-border` (hex), `--color-accent` (hex)
- **Spacing scale** (4px base unit, in rem): `--space-1` through `--space-12`
- **Typography scale** (in rem): `--text-xs`, `--text-sm`, `--text-base`, `--text-lg`, `--text-xl`, `--text-2xl`, `--text-4xl`
- **Border radius:** `--radius-sm`, `--radius-md`, `--radius-lg`, `--radius-full`
- **Shadows:** `--shadow-sm`, `--shadow-md`, `--shadow-lg` (full box-shadow values)
- **Transitions:** `--transition-fast` (e.g. `all 0.15s ease`), `--transition-base` (e.g. `all 0.25s ease`)

#### b. Typography
- Specify the exact Google Fonts `<link>` URL to embed (prefer Inter, Plus Jakarta Sans, DM Sans, or Outfit for modern look)
- Primary font family string (with fallback stack)
- Font weight usage: which weights for body, headings, labels, captions
- Line height values for body text and headings

#### c. Color Palette & Theme
- Provide exact hex values for ALL tokens listed above
- Specify: dark theme or light theme (or which to default to)
- Ensure sufficient contrast for accessibility (WCAG AA minimum)

#### d. Layout Architecture
- Main page layout strategy: CSS Grid or Flexbox, with structural description (e.g. "top navbar + centered content column max-width 1200px" or "left sidebar 260px + main content area")
- Section structure for the page

#### e. Per-Component Style Guidance
For each major UI element present in this project:
- **Buttons:** border-radius (use --radius-md), padding, background color token, hover/active state description, transition
- **Cards:** background token (--color-surface), border (1px solid --color-border), border-radius (--radius-lg), padding, shadow (--shadow-md)
- **Navigation bar:** height, background (solid or blur/glass), sticky positioning, link styles
- **Form inputs:** border, focus ring color and offset, padding, border-radius
- **Section spacing:** recommended padding-top/padding-bottom values using spacing tokens

#### f. Responsive Breakpoints
- Mobile: base styles (default, mobile-first)
- Tablet: `@media (min-width: 768px)`
- Desktop: `@media (min-width: 1200px)`
- Describe what changes at each breakpoint (layout shift, font size increase, etc.)

#### g. CSS Reset
Specify that the Coder must include: `*, *::before, *::after {{ box-sizing: border-box; }}`, reset margin/padding on body, and `scroll-behavior: smooth` on html.

#### h. Visual Style Direction
Write 2–3 sentences describing the overall aesthetic. Choose a style direction that fits the user's task instead of defaulting to a single reusable look. Explain what makes this project's UI feel premium rather than generic.

### 4. Sections List
Provide a `sections` array listing every distinct UI section to implement in order (e.g. `["navbar", "hero", "features-grid", "pricing", "footer"]`). This drives per-section planning steps.

### 5. Package Requirements (MANDATORY for React/Next.js)
For React and Next.js projects, explicitly enumerate ALL npm packages required, grouped into:

**a. Default (already installed by create-next-app or create-vite):**  
List packages that come pre-installed (e.g., react, react-dom, next, typescript, tailwindcss if selected).

**b. Must install via npm (required, not defaults):**  
List every additional package the Coder will `import` from, such as:
- UI libraries: `framer-motion`, `@radix-ui/react-dialog`, `class-variance-authority`, `lucide-react`
- Data/form: `react-hook-form`, `@hookform/resolvers`, `zod`
- Charts: `recharts`
- Drag-and-drop: `@dnd-kit/core`, `@dnd-kit/sortable`, `@dnd-kit/utilities`
- Calendar: `react-big-calendar`, `date-fns`
- Theming: `next-themes`
- Other specifics for this project.
- If shadcn/ui is part of the plan, prefer the current CLI package name `shadcn` over deprecated legacy names.

**c. Optional enhancements (install if time allows):**  
List nice-to-haves that are not critical to core functionality.

Be EXHAUSTIVE. The Planner uses this list to create a dedicated install step. Missing packages = "Module not found" errors.

---

Do NOT write actual implementation code. Do NOT write complete CSS rule blocks.
Output a clear, dense Markdown specification that the Coder will use as the source-of-truth design reference.
"""

def generate_design(user_prompt: str, plan: list, workspace: Path, verbose: bool = False, phase: str = "post_plan") -> str:
    """
    Generates an architectural memory/design spec and saves it to state.
    """
    console.print(ui_status("Design", "Generating architecture and UI specification"))
    acc = load_access()
    agent_cfg = load_agent_config(workspace)
    
    api_key = acc["api_key"]
    endpoint = acc["endpoint"]
    model = agent_cfg["model"]
    
    if not api_key:
        return ""
        
    state = load_agent_state(workspace)
    plan = plan or []
    if plan:
        plan_str = json.dumps(plan, indent=2)
        phase_instructions = (
            "Use the supplied implementation plan to sharpen the architecture, package list, "
            "file structure, verification order, and UI spec."
        )
    else:
        plan_str = (
            "No formal implementation plan exists yet. Produce a pre-planning architecture brief "
            "that identifies the likely stack, project structure, package needs, verification steps, "
            "and UI/design direction so the planner can create a reliable execution plan."
        )
        phase_instructions = (
            "Focus on package requirements, likely routes/modules, setup order, and verification strategy. "
            "This output will directly inform planning."
        )

    sys_prompt = "You are an Expert Architect."
    user_p = DESIGNER_PROMPT.format(
        prompt=user_prompt,
        plan=plan_str,
        phase_instructions=phase_instructions,
    )
    
    if verbose:
        console.print(ui_detail("Model", f"Generating design specification with {model}"))
        
    try:
        # Use temperature 0.0 for deterministic architecture
        design_spec, _usage = _call_gateway(api_key, endpoint, model, sys_prompt, user_p)
        
        console.print(ui_status("Design", "Design specification generated", tone="success"))
        if verbose:
            console.print(ui_detail("Preview", f"{design_spec[:500]}..."))
            
        # Save to memory
        state = load_agent_state(workspace)
        if phase == "pre_plan":
            state["pre_plan_architecture_memory"] = design_spec
        state["architecture_memory"] = design_spec
        if plan:
            ui_contract = _derive_ui_contract(plan, design_spec)
            state["ui_contract"] = ui_contract
            try:
                agent_dir = get_agent_dir(workspace)
                agent_dir.mkdir(parents=True, exist_ok=True)
                (agent_dir / "ui_contract.json").write_text(json.dumps(ui_contract, indent=2), encoding="utf-8")
            except Exception:
                pass
        save_agent_state(workspace, state)
        
        return design_spec
        
    except Exception as e:
        console.print(ui_status("Error", f"Design specification failed: {e}", tone="error"))
        return ""
