"""
workspace.py - Workspace initialization, path resolution, and agent state persistence.
"""
import json
import os
import shutil
from pathlib import Path

AGENT_DIRNAME = ".agent"
PROJECT_DIRNAME = "project"
SCRATCH_DIRNAME = ".scratch"
STATE_FILENAME = "agent_state.json"
LOCAL_AGENT_CONFIG_FILENAME = "agent.yaml"

DEFAULT_AGENT_STATE = {
    "original_prompt": "",
    "current_step": 0,
    "completed_steps": [],
    "plan": [],
    "pending_clarification": {
        "active": False,
        "question": "",
        "reason": "",
        "requested_at_utc": "",
        "last_report": "",
    },
    "last_resolution_type": "",
    "last_user_goal": "",
}


def _default_pending_clarification() -> dict:
    return {
        "active": False,
        "question": "",
        "reason": "",
        "requested_at_utc": "",
        "last_report": "",
    }


def _default_pending_workspace_decision() -> dict:
    return {
        "active": False,
        "original_prompt": "",
        "proposed_subdir": "",
        "mode": "",
        "image_urls": [],
        "command_hint": "",
        "requested_at_utc": "",
    }


def _default_last_execution() -> dict:
    return {
        "command": "",
        "cwd": "",
        "target_file": "",
        "exit_code": None,
        "status": "",
        "duration_sec": 0.0,
        "started_at_utc": "",
        "ended_at_utc": "",
        "artifact_path": "",
        "output_preview": "",
        "full_output_chars": 0,
    }


def _default_recent_target() -> dict:
    return {
        "path": "",
        "kind": "",
        "role": "",
        "source": "",
        "recorded_at_utc": "",
    }


def _default_agent_state() -> dict:
    return {
        "original_prompt": "",
        "current_step": 0,
        "completed_steps": [],
        "plan": [],
        "pending_clarification": _default_pending_clarification(),
        "pending_workspace_decision": _default_pending_workspace_decision(),
        "last_resolution_type": "",
        "last_user_goal": "",
        "last_execution": _default_last_execution(),
        "recent_targets": [],
    }


def _normalize_pending_clarification(raw: object) -> dict:
    pending = _default_pending_clarification()
    if not isinstance(raw, dict):
        return pending

    pending.update({
        "question": str(raw.get("question") or "").strip(),
        "reason": str(raw.get("reason") or "").strip(),
        "requested_at_utc": str(raw.get("requested_at_utc") or "").strip(),
        "last_report": str(raw.get("last_report") or "").strip(),
    })
    pending["active"] = bool(raw.get("active", False))
    return pending


def _normalize_pending_workspace_decision(raw: object) -> dict:
    pending = _default_pending_workspace_decision()
    if not isinstance(raw, dict):
        return pending

    pending.update(
        {
            "original_prompt": str(raw.get("original_prompt") or "").strip(),
            "proposed_subdir": normalize_rel_path(str(raw.get("proposed_subdir") or "")).rstrip("/"),
            "mode": str(raw.get("mode") or "").strip().lower(),
            "command_hint": str(raw.get("command_hint") or "").strip(),
            "requested_at_utc": str(raw.get("requested_at_utc") or "").strip(),
        }
    )
    image_urls = raw.get("image_urls")
    if isinstance(image_urls, list):
        pending["image_urls"] = [str(item).strip() for item in image_urls if str(item).strip()]
    pending["active"] = bool(raw.get("active", False))
    if pending["mode"] not in {"", "integrate", "separate"}:
        pending["mode"] = ""
    return pending


def _normalize_last_execution(raw: object) -> dict:
    execution = _default_last_execution()
    if not isinstance(raw, dict):
        return execution

    execution.update(
        {
            "command": str(raw.get("command") or "").strip(),
            "cwd": str(raw.get("cwd") or "").strip(),
            "target_file": str(raw.get("target_file") or "").strip(),
            "status": str(raw.get("status") or "").strip(),
            "started_at_utc": str(raw.get("started_at_utc") or "").strip(),
            "ended_at_utc": str(raw.get("ended_at_utc") or "").strip(),
            "artifact_path": str(raw.get("artifact_path") or "").strip(),
            "output_preview": str(raw.get("output_preview") or "").strip(),
        }
    )

    exit_code = raw.get("exit_code")
    execution["exit_code"] = int(exit_code) if isinstance(exit_code, int) else (int(exit_code) if str(exit_code).strip().lstrip("-").isdigit() else None)

    try:
        execution["duration_sec"] = float(raw.get("duration_sec", 0.0) or 0.0)
    except Exception:
        execution["duration_sec"] = 0.0

    try:
        execution["full_output_chars"] = int(raw.get("full_output_chars", 0) or 0)
    except Exception:
        execution["full_output_chars"] = 0

    return execution


def _normalize_recent_target_entry(raw: object) -> dict | None:
    if not isinstance(raw, dict):
        return None

    entry = _default_recent_target()
    entry.update(
        {
            "path": normalize_rel_path(str(raw.get("path") or "")).rstrip("/"),
            "kind": str(raw.get("kind") or "").strip().lower(),
            "role": str(raw.get("role") or "").strip().lower(),
            "source": str(raw.get("source") or "").strip().lower(),
            "recorded_at_utc": str(raw.get("recorded_at_utc") or "").strip(),
        }
    )
    if not entry["path"]:
        return None
    if entry["kind"] not in {"file", "dir"}:
        entry["kind"] = ""
    if entry["role"] not in {"created", "edited", "executed", "planned", "checked"}:
        entry["role"] = ""
    return entry


def _normalize_recent_targets(raw: object) -> list[dict]:
    if not isinstance(raw, list):
        return []

    normalized: list[dict] = []
    seen: set[str] = set()
    for item in raw:
        entry = _normalize_recent_target_entry(item)
        if not entry:
            continue
        path = entry["path"]
        if path in seen:
            continue
        seen.add(path)
        normalized.append(entry)
        if len(normalized) >= 25:
            break
    return normalized


def _apply_state_defaults(data: dict) -> dict:
    normalized = _default_agent_state()
    normalized.update(data)
    normalized["pending_clarification"] = _normalize_pending_clarification(
        data.get("pending_clarification")
    )
    normalized["pending_workspace_decision"] = _normalize_pending_workspace_decision(
        data.get("pending_workspace_decision")
    )
    normalized["last_resolution_type"] = str(data.get("last_resolution_type") or "").strip()
    normalized["last_user_goal"] = str(data.get("last_user_goal") or "").strip()
    normalized["last_execution"] = _normalize_last_execution(data.get("last_execution"))
    normalized["recent_targets"] = _normalize_recent_targets(data.get("recent_targets"))
    return normalized


def get_workspace_root() -> Path:
    """Return the global .ai-workspace path inside the current directory."""
    return Path(os.getcwd()) / ".ai-workspace"


def _slugify_name(prompt: str) -> str:
    words = "".join(c if c.isalnum() or c.isspace() else " " for c in prompt).split()
    return "-".join(words[:4]).lower() if words else "project"


def has_managed_layout(workspace: Path) -> bool:
    return (workspace / PROJECT_DIRNAME).exists() or (workspace / AGENT_DIRNAME).exists()


def get_agent_dir(workspace: Path) -> Path:
    return workspace / AGENT_DIRNAME


def ensure_agent_dir(workspace: Path) -> Path:
    agent_dir = get_agent_dir(workspace)
    agent_dir.mkdir(parents=True, exist_ok=True)
    return agent_dir


def is_managed_workspace(workspace: Path) -> bool:
    return (workspace / PROJECT_DIRNAME).exists()


def is_in_place_workspace(workspace: Path) -> bool:
    return not is_managed_workspace(workspace)


def get_project_root(workspace: Path) -> Path:
    managed_root = workspace / PROJECT_DIRNAME
    if managed_root.exists():
        return managed_root
    return workspace


def get_local_agent_config_file(workspace: Path) -> Path:
    return get_agent_dir(workspace) / LOCAL_AGENT_CONFIG_FILENAME


def get_logs_dir(workspace: Path) -> Path:
    return get_agent_dir(workspace) / ".ai_logs"


def get_snapshots_dir(workspace: Path) -> Path:
    return get_agent_dir(workspace) / ".snapshots"


def get_lock_path(workspace: Path) -> Path:
    return get_agent_dir(workspace) / ".ai_lock"


def get_agent_artifacts_dir(workspace: Path) -> Path:
    return get_agent_dir(workspace)


def get_scratch_root(workspace: Path) -> Path:
    return get_agent_dir(workspace) / SCRATCH_DIRNAME


def get_current_step_index(workspace: Path) -> int:
    try:
        return int(load_agent_state(workspace).get("current_step", 0) or 0)
    except Exception:
        return 0


def get_step_scratch_dir(workspace: Path, step_idx: int | None = None) -> Path:
    effective_step = get_current_step_index(workspace) if step_idx is None else int(step_idx)
    return get_scratch_root(workspace) / f"step-{effective_step}"


def cleanup_step_scratch_dir(workspace: Path, step_idx: int | None = None) -> None:
    scratch_dir = get_step_scratch_dir(workspace, step_idx)
    if scratch_dir.exists():
        shutil.rmtree(scratch_dir, ignore_errors=True)


def init_workspace(prompt: str) -> Path:
    """
    Create .ai-workspace/<project_dir> and initialize the managed layout.
    """
    workspace = get_workspace_root() / _slugify_name(prompt)
    workspace.mkdir(parents=True, exist_ok=True)
    (workspace / AGENT_DIRNAME).mkdir(parents=True, exist_ok=True)
    (workspace / PROJECT_DIRNAME).mkdir(parents=True, exist_ok=True)
    return workspace


def safe_path(workspace: Path, target_path: str) -> Path:
    """
    Resolve a path inside the workspace project root and prevent traversal.
    """
    project_root = get_project_root(workspace).resolve()
    resolved = (project_root / target_path).resolve()
    try:
        resolved.relative_to(project_root)
    except ValueError as exc:
        raise ValueError(f"Unsafe path: {target_path} escapes project root {project_root}") from exc
    return resolved


def _load_state_file(path: Path) -> dict | None:
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            return None
        return _apply_state_defaults(data)
    except Exception:
        return None


def load_agent_state(workspace: Path) -> dict:
    managed_state = get_agent_dir(workspace) / STATE_FILENAME
    legacy_state = workspace / STATE_FILENAME

    for state_file in (managed_state, legacy_state):
        data = _load_state_file(state_file)
        if data is not None:
            return data

    return _default_agent_state()


def save_agent_state(workspace: Path, state: dict) -> None:
    agent_dir = ensure_agent_dir(workspace)
    (agent_dir / STATE_FILENAME).write_text(json.dumps(state, indent=2), encoding="utf-8")


def normalize_rel_path(path: str) -> str:
    """Normalize a relative file path to forward-slash, no-leading-dot form."""
    if not path:
        return ""
    raw = str(path).strip()
    if raw.lower().startswith("scratch:"):
        suffix = raw.split(":", 1)[1].replace("\\", "/").lstrip("/").strip()
        suffix = str(Path(suffix).as_posix()) if suffix else ""
        while suffix.startswith("./"):
            suffix = suffix[2:]
        return f"scratch:{suffix}" if suffix else "scratch:"
    normalized = str(Path(raw).as_posix())
    while normalized.startswith("./"):
        normalized = normalized[2:]
    return normalized


def clear_pending_workspace_decision(state: dict) -> dict:
    state["pending_workspace_decision"] = _default_pending_workspace_decision()
    return state


def record_recent_targets(
    state: dict,
    paths: list[str] | tuple[str, ...] | set[str] | None,
    *,
    role: str,
    source: str,
    recorded_at_utc: str = "",
    kind_overrides: dict[str, str] | None = None,
) -> dict:
    role = str(role or "").strip().lower()
    source = str(source or "").strip().lower()
    if role not in {"created", "edited", "executed", "planned", "checked"}:
        return state
    if not source:
        return state

    recent = _normalize_recent_targets(state.get("recent_targets"))
    by_path = {entry["path"]: entry for entry in recent}
    ordered_paths = [entry["path"] for entry in recent]
    kind_overrides = {
        normalize_rel_path(str(path)).rstrip("/"): str(kind).strip().lower()
        for path, kind in (kind_overrides or {}).items()
        if path
    }
    timestamp = str(recorded_at_utc or "").strip()

    for raw_path in paths or []:
        normalized = normalize_rel_path(str(raw_path or "")).rstrip("/")
        if not normalized or normalized == "." or is_scratch_path(normalized):
            continue
        kind = kind_overrides.get(normalized, "")
        if kind not in {"file", "dir"}:
            kind = "file" if "." in Path(normalized).name else "dir"
        entry = {
            "path": normalized,
            "kind": kind,
            "role": role,
            "source": source,
            "recorded_at_utc": timestamp,
        }
        if normalized in by_path:
            ordered_paths = [path for path in ordered_paths if path != normalized]
        ordered_paths.insert(0, normalized)
        by_path[normalized] = entry

    state["recent_targets"] = [by_path[path] for path in ordered_paths[:25] if path in by_path]
    return state


def is_scratch_path(path: str) -> bool:
    return normalize_rel_path(path).lower().startswith("scratch:")


def resolve_agent_path(workspace: Path, target_path: str, step_idx: int | None = None) -> Path:
    """
    Resolve a path inside either the resolved workspace project root or the active step scratch dir.
    Scratch paths use the `scratch:` prefix.
    """
    normalized = normalize_rel_path(target_path)
    if is_scratch_path(normalized):
        scratch_root = get_step_scratch_dir(workspace, step_idx).resolve()
        relative = normalized.split(":", 1)[1].lstrip("/")
        resolved = (scratch_root / relative).resolve() if relative else scratch_root
        try:
            resolved.relative_to(scratch_root)
        except ValueError as exc:
            raise ValueError(f"Unsafe scratch path: {target_path} escapes scratch root {scratch_root}") from exc
        return resolved
    return safe_path(workspace, normalized)


def relativize_agent_path(workspace: Path, absolute_path: Path, step_idx: int | None = None) -> str:
    """
    Convert an absolute project or scratch path back into the agent-relative form.
    """
    resolved = absolute_path.resolve()
    project_root = get_project_root(workspace).resolve()
    scratch_root = get_step_scratch_dir(workspace, step_idx).resolve()
    try:
        rel = resolved.relative_to(project_root)
        return normalize_rel_path(str(rel).replace("\\", "/"))
    except ValueError:
        pass
    try:
        rel = resolved.relative_to(scratch_root)
        suffix = normalize_rel_path(str(rel).replace("\\", "/"))
        return f"scratch:{suffix}" if suffix else "scratch:"
    except ValueError as exc:
        raise ValueError(f"Path {absolute_path} is not inside the resolved workspace project root or active scratch directory.") from exc
