"""
reporter.py - Internal investigation engine for Nexcode Agent.

This module runs before the Fix Planner. Its purpose is to search, read, and
understand the codebase based on the user's issue, building up investigation
memory before producing routing metadata and a report for the main assistant.
"""

import json
from pathlib import Path
from rich.console import Console

from nexcode.agent_runtime.prompt_context import build_compact_workspace_summary, summarize_tool_observation
from nexcode.agent_runtime.presentation import ui_detail, ui_status
from nexcode.agent_runtime.task_scope import resolve_task_scope
from nexcode.agent_runtime.workspace import safe_path

console = Console()


def _existing_workspace_files(workspace: Path, items) -> list[str]:
    if isinstance(items, str):
        candidates = [items]
    elif isinstance(items, list):
        candidates = items
    else:
        return []

    normalized: list[str] = []
    seen: set[str] = set()
    for item in candidates:
        value = str(item or "").strip()
        if not value or value in seen:
            continue
        candidate = value.split(" (", 1)[0].strip()
        if not candidate:
            continue
        try:
            target = safe_path(workspace, candidate)
        except Exception:
            continue
        if not target.exists() or not target.is_file():
            continue
        seen.add(candidate)
        normalized.append(candidate.replace("\\", "/"))
    return normalized

REPORTER_SYSTEM_PROMPT = """
You are the internal investigation engine for Nexcode Agent. Your job is to
survey the codebase, diagnose bugs, understand architecture, and prepare
evidence-backed guidance for the main assistant.

You are NOT the final user-facing assistant. Any user-facing text that you put
into `user_instructions` or `final_report` must sound like Nexcode Agent
speaking naturally. Never mention being an investigator, never mention routing,
scratchpads, or internal tools, and never say you are performing an
investigation unless the user explicitly asks about internals.

The user has presented a query or reported a bug. You must figure out what
needs to be changed, how confident you are, and what depth of action is required.

# RULES

1. You have a persistent "Investigation Scratchpad". Use it to take notes on what
   you find so you don't forget. To persist scratchpad across tool calls, include a
   `"scratchpad_update"` string field alongside your tool call JSON on every turn.
   Keep it short (bullet notes). Do NOT paste tool outputs into it.
2. **BATCH OPERATIONS (CRITICAL)**: Do NOT read files sequentially one-by-one. 
   - Use `multi_read` to batch the most relevant files or file excerpts at once.
   - Use `grep_search` to find patterns globally across the codebase instead of guessing which file has them.
   - For large files, prefer `search_file` to locate anchors and `read_lines` to inspect exact ranges.
3. **DEPTH MUST MATCH COMPLEXITY**:
   - For simple or localized issues, keep the investigation fast: usually 2-3 tool calls.
   - For broad, ambiguous, multi-file, or architectural issues, it is acceptable to investigate deeper before submitting.
   - For broad or global changes, do NOT read every affected component. Read the shared config plus 1 or 2 representative examples, identify the pattern, and submit the general fix shape.
4. **NO RUNTIME/BUILD TESTS**: You are an investigator ONLY. You are STRICTLY FORBIDDEN from running `npm run build`, `npm test`, `pytest`, or trying to compile code. Do NOT try to verify if Tailwind or configs work by running builds. Just read the configuration, identify the problem, and `submit_report`.
5. **EXPECTED WORKFLOW**:
   - Simple/local issue: `grep_search` or `list_files`, then targeted `multi_read` or `read_lines`, then `submit_report`.
   - Complex issue: take only the extra reads needed to establish the pattern, affected areas, and next action.
   - Never loop endlessly. If you already understand the fix pattern, submit the report.
6. Once you understand the core logic or the bug via reading/searching, call `submit_report` with a detailed explanation of what the assistant should do next.
7. Every final report MUST include:
   - `complexity`: `simple` or `complex`
   - `confidence`: `low`, `medium`, or `high`
   - `checked_files`: the key files or areas you inspected
   - `needs_plan_preview`: true for complex code changes, false for simple/local fixes
   - when code changes are needed, include `target_scope` (`single_file`, `localized`, or `project_wide`) and `validation_level` (`none`, `scoped`, or `broad`) when you can infer them from the repo evidence
   - set `overwrite_existing` to true only when the user explicitly asked to replace an existing file or the existing file is clearly the intended target
8. If you return `answer_only`, you MUST include:
   - what you checked
   - why the answer is correct
   - how the user can verify it
9. If you return `need_more_info`, the question must state exactly what detail is missing and why it matters.
10. If you return `code_change` for a broad issue, describe the affected pattern or surfaces, not just one file.
11. For explicit create-new-file requests, do NOT reinterpret generic words like test, script, or helper as permission to overwrite an existing file named `test.py`, `script.py`, or similar unless the user explicitly named that path.
12. If the user asks for a plain algorithm/script file, do NOT assume `unittest`, `pytest`, or a separate validation harness unless the user explicitly asked for tests.

You must call exactly ONE tool per response in a valid JSON object. It MUST contain a "thinking" string explaining your logic before the tool call.

{"thinking": "I need to search everywhere for the dark mode class.", "scratchpad_update": "- Need find dark-mode class usage", "tool": "grep_search", "args": {"query": "dark:"}}
{"thinking": "I'll read the main layout and the most likely config files at once.", "scratchpad_update": "- Inspect layout + globals + postcss", "tool": "multi_read", "args": {"paths": ["app/layout.tsx", "app/globals.css", "postcss.config.mjs"], "focus_terms": ["dark", "theme", "class"]}}

# THE FINAL TOOL


When your investigation is complete, call:

{{
  "thinking": "I now understand the issue completely.",
  "tool": "submit_report",
  "args": {{
    "resolution_type": "code_change",
    "issue_category": "unknown",
    "complexity": "simple",
    "confidence": "medium",
    "checked_files": ["src/app.tsx"],
    "needs_plan_preview": false,
    "user_instructions": "",
    "is_question": false,
    "investigation_scratchpad": "Your internal notes and deductions so far...",
    "final_report": "A highly detailed, file-by-file breakdown of what is wrong and EXACTLY what the Fix Planner must do to fix it."
  }}
}}

RESOLUTION ROUTING (CRITICAL):
- Set resolution_type to ONE of:
  - "code_change": code edits are required; Fix Planner should run.
  - "user_action_only": no code edits needed; the user must do something (restart dev server, clear cache, run a command).
  - "answer_only": user asked a question OR the request is already satisfied in the codebase; answer in user_instructions and stop.
  - "need_more_info": you cannot proceed; ask for missing info in user_instructions and stop.
- issue_category should be ONE of: "stale_cache", "config", "data", "ui", "unknown"
- If resolution_type is "user_action_only" / "answer_only" / "need_more_info":
  - Set is_question=true (backwards compatibility with agent.py's early-exit behavior).
  - Put the user-facing message (with exact steps/commands) in user_instructions.
  - final_report can be brief or the same as user_instructions.
- IMPORTANT: If the user asks to fix something and you confirm it's already fixed, use "answer_only" and include:
   - what files/patterns you checked
   - why it is already correct
   - how the user can verify (steps/expected result)
"""

REPORTER_CONSULT_ONLY_APPENDIX = """

CONSULT-ONLY MODE:
- The user is primarily asking for suggestions, explanation, guidance, or evaluation.
- You may inspect the codebase to ground your answer, but you are NOT authorized to initiate implementation work.
- If you did not inspect files, do not imply that you inspected files.
- Prefer `resolution_type="answer_only"` unless the user's wording explicitly asks to implement or modify code.
- Summarize what currently exists, what could be improved, and the highest-value suggestions based on the actual codebase.
- Avoid proposing direct edits as if they are already approved. Frame changes as recommendations unless the user explicitly asked to make them.
"""

REPORTER_REVIEW_ONLY_APPENDIX = """

REVIEW-ONLY MODE:
- The user is asking for an audit, review, or architecture critique of the current codebase.
- Inspect the real repository shape and return concrete findings, tradeoffs, and weak spots grounded in files you checked.
- You are NOT authorized to change code in this mode.
- Prefer `resolution_type="answer_only"` unless a blocking ambiguity requires `need_more_info`.
- Focus on architecture, maintainability, correctness risks, missing boundaries, fragile flows, and testing gaps over generic advice.
"""

_ALLOWED_RESOLUTION_TYPES = {"code_change", "user_action_only", "answer_only", "need_more_info"}
_ALLOWED_ISSUE_CATEGORIES = {"stale_cache", "config", "data", "ui", "unknown"}
_ALLOWED_COMPLEXITY = {"simple", "complex"}
_ALLOWED_CONFIDENCE = {"low", "medium", "high"}
_ALLOWED_TARGET_SCOPES = {"single_file", "localized", "project_wide"}
_ALLOWED_VALIDATION_LEVELS = {"none", "scoped", "broad"}


REPORTER_TOOLS_DESCRIPTION = """
# AVAILABLE TOOLS

You must use exactly one of these tools per turn:

1. `grep_search(query: str, path: str = ".", include_patterns: list[str] = None)`
   Search for a regex pattern across files. 
   - `query`: The regex or string to find.
   - `path`: Directory to search (default ".").
   - `include_patterns`: Optional list of glob patterns to restrict search (e.g. ["*.ts", "*.vue"]).

2. `list_files(path: str = ".")`
   List all files in a directory recursively (ignoring build/system artifacts).
   - `path`: The directory to list.

3. `multi_read(paths: list[str], focus_terms: list[str] = None)`
   Read multiple files or excerpts at once.
   - `paths`: List of relative file paths.
   - `focus_terms`: Optional terms to help center excerpts on relevant code.

4. `read_file(path: str)`
   Read the entire content of a single file.

5. `search_file(path: str, query: str)`
   Search for a string within a specific file and return matching lines.

6. `read_lines(path: str, start_line: int, end_line: int)`
   Read a specific 1-indexed line range.

7. `run_command(cmd: str, path: str = ".")`
   Execute a shell command. Use sparingly for discovery (e.g. `ls -R`, `find`).
   - `cmd`: The command to run.
   - `path`: Working directory.

8. `submit_report(...)`
   Call this ONLY when your investigation is complete.
"""


def _build_reporter_system_prompt(routing_mode: str) -> str:
    base = REPORTER_SYSTEM_PROMPT
    if routing_mode == "consult_only":
        base += REPORTER_CONSULT_ONLY_APPENDIX
    elif routing_mode == "review_only":
        base += REPORTER_REVIEW_ONLY_APPENDIX
    
    return base + "\n\n" + REPORTER_TOOLS_DESCRIPTION


def _validate_tool_call(t_name: str, t_args: dict) -> str | None:
    """
    Validate tool arguments against the actual function signature.
    Returns an error message if invalid, or None if valid.
    """
    import inspect
    from nexcode.agent_runtime.tool_registry import get_tool
    
    if t_name == "submit_report":
        return None
        
    try:
        func = get_tool(t_name)
    except Exception:
        return f"Error: Tool '{t_name}' is not recognized. Valid tools are: grep_search, list_files, multi_read, read_file, search_file, read_lines, run_command, submit_report."
        
    sig = inspect.signature(func)
    # The 'workspace' arg is injected by the runner, so we ignore it in validation
    params = list(sig.parameters.keys())
    if "workspace" in params:
        params.remove("workspace")
        
    # Check for unexpected arguments
    unexpected = [k for k in t_args if k not in params]
    if unexpected:
        valid_args = ", ".join(params)
        return f"Error: Tool '{t_name}' received unexpected argument(s): {', '.join(unexpected)}. Valid arguments are: {valid_args}."
        
    # Check for missing required arguments (those without defaults)
    missing = [
        k for k, v in sig.parameters.items() 
        if k != "workspace" and v.default is inspect.Parameter.empty and k not in t_args
    ]
    if missing:
        return f"Error: Tool '{t_name}' is missing required argument(s): {', '.join(missing)}."
        
    return None


def _build_reporter_user_prompt(
    orig_prompt: str,
    history_str: str,
    prompt: str,
    os_name: str,
    workspace_summary: str,
    routing_mode: str,
) -> str:
    if routing_mode == "consult_only":
        request_label = "User's Current Message"
        kickoff = "Begin your investigation. Identify the next best read or search that will ground a helpful answer."
    elif routing_mode == "review_only":
        request_label = "User's Review Request"
        kickoff = "Begin your investigation. Identify the next best read or search that will ground a concrete review of the current codebase."
    else:
        request_label = "User's Current Request/Bug"
        kickoff = "Begin your investigation. Identify the next best read or search to understand the required changes."
    return (
        f"Original Project Goal:\n{orig_prompt}\n\n"
        f"{history_str}"
        f"Assistant Routing Mode: {routing_mode}\n\n"
        f"{request_label}:\n{prompt}\n\n"
        f"Environment: {os_name}\n\n"
        f"Workspace Summary:\n{workspace_summary}\n\n"
        f"{kickoff}"
    )


def _append_scratchpad(existing: str, update: str, max_tokens: int = 20_000) -> str:
    """Append a scratchpad update, keeping the combined notes within a real token budget.

    Uses estimate_tokens (tiktoken o200k_base) for accurate accounting.
    When over budget, the oldest notes are trimmed — most-recent notes survive.
    """
    update = (update or "").strip()
    if not update:
        return existing or ""

    combined = f"{existing.rstrip()}\n{update}" if existing else update

    try:
        from nexcode.agent_runtime.token_utils import estimate_tokens
        if estimate_tokens(combined) <= max_tokens:
            return combined
        # Over budget — trim from the top until we fit
        lines = combined.splitlines()
        while lines and estimate_tokens("\n".join(lines)) > max_tokens:
            lines.pop(0)
        trimmed = "\n".join(lines)
        return f"[... earlier notes trimmed to fit token budget ...]\n{trimmed}"
    except Exception:
        # Fallback: character-based (4 chars ≈ 1 token → 20K tokens ≈ 80K chars)
        char_limit = max_tokens * 4
        if len(combined) <= char_limit:
            return combined
        return combined[-char_limit:]


def _normalize_checked_files(workspace: Path | None, raw_checked_files) -> list[str]:
    if workspace is None:
        if isinstance(raw_checked_files, str):
            items = [raw_checked_files]
        elif isinstance(raw_checked_files, list):
            items = raw_checked_files
        else:
            return []
        normalized: list[str] = []
        seen: set[str] = set()
        for item in items:
            value = str(item or "").strip()
            if not value or value in seen:
                continue
            seen.add(value)
            normalized.append(value.split(" (", 1)[0].strip().replace("\\", "/"))
        return [item for item in normalized if item]
    return _existing_workspace_files(workspace, raw_checked_files)


def _normalize_submit_report_args(workspace: Path | dict, t_args: dict | None = None) -> dict:
    workspace_arg = workspace
    if t_args is None:
        workspace = None
        t_args = dict(workspace_arg or {}) if isinstance(workspace_arg, dict) else {}
    else:
        workspace = workspace_arg if isinstance(workspace_arg, Path) else None
    resolution_type = str(t_args.get("resolution_type") or "code_change").strip()
    if resolution_type not in _ALLOWED_RESOLUTION_TYPES:
        resolution_type = "code_change"

    issue_category = str(t_args.get("issue_category") or "unknown").strip()
    if issue_category not in _ALLOWED_ISSUE_CATEGORIES:
        issue_category = "unknown"

    user_instructions = str(t_args.get("user_instructions") or "").strip()
    final_report = str(t_args.get("final_report") or "").strip()
    scratchpad = str(t_args.get("investigation_scratchpad") or "")
    complexity = str(t_args.get("complexity") or "simple").strip().lower()
    if complexity not in _ALLOWED_COMPLEXITY:
        complexity = "simple"
    confidence = str(t_args.get("confidence") or "medium").strip().lower()
    if confidence not in _ALLOWED_CONFIDENCE:
        confidence = "medium"
    checked_files = _normalize_checked_files(workspace, t_args.get("checked_files"))
    needs_plan_preview = bool(t_args.get("needs_plan_preview", complexity == "complex"))
    clarification_reason = str(t_args.get("clarification_reason") or "").strip()
    verification_steps = str(t_args.get("verification_steps") or "").strip()
    target_scope = str(t_args.get("target_scope") or "").strip().lower()
    overwrite_existing = bool(t_args.get("overwrite_existing", False))
    validation_level = str(t_args.get("validation_level") or "").strip().lower()

    is_question = bool(t_args.get("is_question", False))
    if resolution_type in {"user_action_only", "answer_only", "need_more_info"}:
        is_question = True

    if not user_instructions and resolution_type != "code_change":
        user_instructions = final_report
    if not final_report:
        final_report = user_instructions

    if target_scope not in _ALLOWED_TARGET_SCOPES:
        if checked_files and len(checked_files) == 1:
            target_scope = "single_file"
        elif checked_files:
            target_scope = "localized"
        else:
            target_scope = "project_wide" if complexity == "complex" else "localized"
    if validation_level not in _ALLOWED_VALIDATION_LEVELS:
        validation_level = "broad" if complexity == "complex" else "scoped"

    if resolution_type == "answer_only" and not final_report:
        final_report = user_instructions

    if resolution_type == "need_more_info":
        if not clarification_reason:
            clarification_reason = "I am missing a detail needed to continue safely."
        if not user_instructions:
            user_instructions = "Please share the missing detail so I can continue."
        final_report = user_instructions

    return {
        "is_question": is_question,
        "resolution_type": resolution_type,
        "issue_category": issue_category,
        "user_instructions": user_instructions,
        "report": final_report,
        "scratchpad": scratchpad,
        "complexity": complexity,
        "confidence": confidence,
        "checked_files": checked_files,
        "needs_plan_preview": needs_plan_preview,
        "clarification_reason": clarification_reason,
        "target_scope": target_scope,
        "overwrite_existing": overwrite_existing,
        "validation_level": validation_level,
        "verification_steps": verification_steps,
    }

def run_investigation(
    workspace: Path,
    prompt: str,
    orig_prompt: str,
    verbose: bool = False,
    image_urls: list[str] = None,
    fix_history: list = None,
    routing_mode: str = "implementation",
    task_scope=None,
) -> dict:
    """
    Run the Reporter loop until it submits a final report.
    Returns normalized routing metadata and the final report for the assistant flow.
    """
    from nexcode.config import load_access, load_agent_config
    from nexcode.agent_runtime.planner import _call_gateway
    from nexcode.agent_runtime.tool_registry import load_all_tools, get_tool
    
    acc = load_access()
    agent_cfg = load_agent_config(workspace)
    load_all_tools()
    
    status_msg = ui_status("Investigation", "Analyzing the request and codebase")
    with console.status(status_msg, spinner="dots") as status:
        effective_scope = task_scope or resolve_task_scope(
            workspace,
            user_message=prompt,
            checked_files=None,
            plan_files=None,
            changed_files=None,
            mode_hint=routing_mode,
        )
        workspace_summary, _ = build_compact_workspace_summary(
            workspace,
            query=prompt,
            checked_files=list(effective_scope.focused_files),
            task_scope=effective_scope,
            top_k=15,
            max_chars=10000,
        )
        
        import sys
        os_name = "Windows (PowerShell)" if sys.platform == "win32" else "Linux/Mac"
        
        history_str = ""
        if fix_history:
            from nexcode.agent_runtime.token_utils import estimate_tokens as _est_tok_hist
            _FIX_HIST_TOKEN_LIMIT = 30_000
            history_str = (
                "PREVIOUS WORK HISTORY (Use this as context. If the user asks to fix something that was addressed here, "
                "you MUST re-check the codebase. If it is already fixed, report that via resolution_type='answer_only' "
                "with verification steps. If it is still broken, investigate deeper):\n"
            )
            # Take only the most recent 20 entries to stay within budget
            recent_history = fix_history[-20:] if len(fix_history) > 20 else fix_history
            if len(fix_history) > 20:
                history_str += f"[{len(fix_history) - 20} earlier entries omitted]\n"
            for h in recent_history:
                if isinstance(h, dict):
                    history_str += f"- Request: {h.get('prompt', 'Unknown')}\n  Action Taken: {h.get('outcome', 'No summary available.')}\n"
                else:
                    history_str += f"- Request: {h}\n"
            # Final token cap — trim from top if too large
            if _est_tok_hist(history_str) > _FIX_HIST_TOKEN_LIMIT:
                lines = history_str.splitlines()
                while lines and _est_tok_hist("\n".join(lines)) > _FIX_HIST_TOKEN_LIMIT:
                    lines.pop(0)
                history_str = "[... history trimmed to fit token budget ...]\n" + "\n".join(lines)
            history_str += "\n"
            
        history = []
        user_p = _build_reporter_user_prompt(
            orig_prompt=orig_prompt,
            history_str=history_str,
            prompt=prompt,
            os_name=os_name,
            workspace_summary=workspace_summary,
            routing_mode=routing_mode,
        )
        
        observations = []
        
        scratchpad = ""
        try:
            from nexcode.agent_runtime.workspace import load_agent_state
            persisted = load_agent_state(workspace).get("reporter_scratchpad", "")
            scratchpad = _append_scratchpad(scratchpad, str(persisted or "").strip())
        except Exception:
            scratchpad = scratchpad
        
        step_count = 1
        
        for attempt in range(1, 15):
            try:
                # Include scratchpad in prompt
                sys_p = _build_reporter_system_prompt(routing_mode)
                if scratchpad:
                    sys_p += f"\n\nCURRENT SCRATCHPAD MEMORY:\n{scratchpad}"
                    
                # Build the prompt dynamically to preserve the original instructions
                # Smart token-aware observation window:
                # Use real token counter — summarize once the window exceeds 500K tokens.
                from nexcode.agent_runtime.token_utils import estimate_tokens as _est_tok
                _TOKEN_LIMIT = 500_000  # reporter investigation budget

                obs_window = observations[-100:]
                total_obs_tokens = sum(_est_tok(o) for o in obs_window)

                if total_obs_tokens > _TOKEN_LIMIT and len(obs_window) > 14:
                    # Keep first 2 (initial findings) and last 10 (recent context) intact.
                    # Condense the middle to first-line summaries only.
                    head = obs_window[:2]
                    tail = obs_window[-10:]
                    middle = obs_window[2:-10]

                    head_text = "\n\n".join(head)
                    middle_summaries = []
                    for obs in middle:
                        first_line = obs.split("\n")[0][:120] if obs else "(empty)"
                        middle_summaries.append(f"  • {first_line}")
                    middle_text = (
                        f"... [{len(middle)} intermediate observations condensed — {total_obs_tokens:,} tokens total] ...\n"
                        + "\n".join(middle_summaries[-5:])
                    )
                    tail_text = "\n\n".join(tail)
                    obs_text = f"{head_text}\n\n{middle_text}\n\n{tail_text}"

                    # Final safety cap if combined is still enormous
                    if _est_tok(obs_text) > _TOKEN_LIMIT:
                        half = _TOKEN_LIMIT // 2
                        # Approximate chars from tokens (~4 chars/token)
                        char_half = half * 4
                        obs_text = obs_text[:char_half] + "\n...[TRUNCATED]...\n" + obs_text[-char_half:]
                else:
                    # Everything fits — join all observations chronologically
                    obs_text = "\n\n".join(obs_window)
                current_user_text = f"{user_p}\n\nRECENT OBSERVATIONS:\n{obs_text}\n\nWhat next? Update your scratchpad internally if needed, then call the next tool or submit_report."
                
                if image_urls:
                    current_prompt = [{"type": "text", "text": current_user_text}]
                    for url in image_urls:
                        current_prompt.append({
                            "type": "image_url",
                            "image_url": {"url": url}
                        })
                else:
                    current_prompt = current_user_text
                    
                response, _usage = _call_gateway(
                    api_key=acc["api_key"],
                    endpoint=acc["endpoint"],
                    model=agent_cfg["model"],
                    system_prompt=sys_p,
                    user_prompt=current_prompt,
                    json_mode=True
                )
                
                # Extract JSON tool call
                from nexcode.agent_runtime.executor import extract_json, parse_tool_call_from_text
                tool_call = extract_json(response)
                if not tool_call:
                    tool_call = parse_tool_call_from_text(response)
                    
                if not tool_call or "tool" not in tool_call:
                    observations.append("System: Invalid JSON or no tool call found. You must call exactly one tool.")
                    continue
                    
                t_name = tool_call["tool"]
                t_args = tool_call.get("args", {})
                thinking = tool_call.get("thinking", "")
                scratchpad_update = tool_call.get("scratchpad_update", tool_call.get("scratchpad", ""))
                scratchpad = _append_scratchpad(scratchpad, str(scratchpad_update or ""))
                
                if thinking:
                    # Spinner: first sentence of thinking
                    short_thought = thinking.split('.')[0].strip()
                    if len(short_thought) > 80:
                        short_thought = short_thought[:77] + "..."
                    status.update(ui_status("Investigation", f"Step {step_count}: {short_thought}"))

                    if verbose:
                        # High-level thought — trim to first 2 sentences, no tool name prefix
                        sentences = [s.strip() for s in thinking.replace('\n', ' ').split('.') if s.strip()]
                        summary = '. '.join(sentences[:2])
                        if len(summary) > 120:
                            summary = summary[:117] + "..."
                        console.print(ui_detail("Thought", summary))
                
                if t_name == "submit_report":
                    status.stop()
                    console.print(ui_status("Investigation", "Investigation complete", tone="success"))
                    normalized = _normalize_submit_report_args(workspace, t_args)
                    if not normalized.get("scratchpad"):
                        normalized["scratchpad"] = scratchpad
                    return normalized
                    
                if verbose:
                    # Readable action label: tool + most meaningful arg
                    def _fmt_args(name: str, args: dict) -> str:
                        if not args:
                            return name
                        key_arg = (
                            args.get("query") or args.get("path") or args.get("paths")
                            or args.get("pattern") or args.get("command") or ""
                        )
                        if isinstance(key_arg, list):
                            key_arg = ", ".join(str(p) for p in key_arg[:3])
                        key_arg = str(key_arg)[:60].strip()
                        return f"{name} → {key_arg!r}" if key_arg else name
                    console.print(ui_detail("Action", _fmt_args(t_name, t_args)))
                    
                # Execute standard tools
                validation_error = _validate_tool_call(t_name, t_args)
                if validation_error:
                    result = validation_error
                elif t_name in ["read_file", "list_files", "search_file", "read_lines", "multi_read", "grep_search"]:
                    func = get_tool(t_name)
                    try:
                        result = func(workspace, **t_args)
                    except TypeError as te:
                        # Final safety catch for signature mismatches not caught by inspect
                        result = f"Error: Tool call failed due to argument mismatch: {te}. Please check the tool definition and try again."
                elif t_name == "run_command":
                    func = get_tool("run_command")
                    result = func(workspace, **t_args)
                else:
                    result = f"Error: Tool '{t_name}' not allowed for Reporter."
                    
                res_str = str(result)
                if len(res_str) > 120000:
                    res_str = res_str[:60000] + "\n...[TRUNCATED]...\n" + res_str[-60000:]
                    
                if verbose:
                    # Show a clean result summary — file/match counts or first line only
                    lines = [l for l in res_str.splitlines() if l.strip()]
                    if t_name == "grep_search":
                        label = f"{len(lines)} match{'es' if len(lines) != 1 else ''}"
                    elif t_name in {"list_files", "multi_read"}:
                        label = f"{len(lines)} line{'s' if len(lines) != 1 else ''}"
                    elif t_name in {"read_file", "read_lines", "search_file"}:
                        label = f"{len(lines)} line{'s' if len(lines) != 1 else ''}"
                    else:
                        label = lines[0][:80] if lines else "(empty)"
                    console.print(ui_detail("Result", label))
                    
                observations.append(
                    f"Tool '{t_name}' returned:\n{summarize_tool_observation(t_name, res_str)}"
                )
                step_count += 1
                
            except Exception as e:
                if verbose:
                    console.print(f"[red]System Error: {e}[/red]")
                observations.append(f"System Error: {e}")
                
        # Fallback if loops out
        status.stop()
        console.print(ui_status("Warning", "Investigation loop limit reached; submitting a best-effort report", tone="warning"))
        if routing_mode in {"consult_only", "review_only"}:
            return {
                "is_question": True,
                "resolution_type": "answer_only",
                "issue_category": "unknown",
                "user_instructions": "I inspected the codebase, but the investigation loop timed out before I could produce a more specific answer.",
                "report": "I inspected the codebase, but the investigation loop timed out before I could produce a more specific answer.",
                "scratchpad": "",
                "complexity": "simple",
                "confidence": "low",
                "checked_files": [],
                "needs_plan_preview": False,
                "clarification_reason": "",
            }
        return {
            "is_question": False,
            "resolution_type": "code_change",
            "issue_category": "unknown",
            "user_instructions": "",
            "report": "Investigation timed out. The Fix Planner should analyze the root cause carefully.",
            "scratchpad": "",
            "complexity": "complex",
            "confidence": "low",
            "checked_files": [],
            "needs_plan_preview": True,
            "clarification_reason": "",
        }
