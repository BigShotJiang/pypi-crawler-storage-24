"""
project_profile.py - Shared project stack detection and stack-aware command helpers.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

from nexcode.agent_runtime.task_scope import DISCOVERY_IGNORED_DIRS, TaskScope, resolve_task_scope
from nexcode.agent_runtime.workspace import get_project_root

_IGNORED_DIRS = set(DISCOVERY_IGNORED_DIRS)

BASE_SAFE_COMMANDS = {
    "git", "ls", "dir", "pwd", "cat", "type", "cd",
    "echo", "sleep", "timeout",
    "mkdir", "md", "move", "mv", "copy", "cp", "ren", "rename",
    "del", "rm", "rmdir", "rd",
}

STACK_COMMANDS = {
    "node": {"node", "npm", "npx", "pnpm", "yarn"},
    "python": {"python", "python3", "py", "pip", "pytest", "uvicorn", "ruff", "flake8"},
    "rust": {"cargo", "rustc"},
    "go": {"go"},
    "dotnet": {"dotnet"},
    "java-maven": {"mvn", "mvnw", "mvnw.cmd"},
    "java-gradle": {"gradle", "gradlew", "gradlew.bat"},
    "php": {"php", "composer", "phpunit"},
    "ruby": {"ruby", "bundle", "rake", "rspec", "rails"},
    "elixir": {"mix"},
    "swift": {"swift"},
    "native": {"make", "cmake", "ctest"},
}

ALL_STACK_SAFE_COMMANDS = set(BASE_SAFE_COMMANDS)
for _commands in STACK_COMMANDS.values():
    ALL_STACK_SAFE_COMMANDS.update(_commands)

STACK_PRIORITY = (
    "nextjs",
    "react",
    "node",
    "python-web",
    "python",
    "rust",
    "go",
    "dotnet",
    "java-gradle",
    "java-maven",
    "php",
    "ruby",
    "elixir",
    "swift",
    "native",
    "static-web",
    "generic",
)

STACK_LABELS = {
    "nextjs": "Next.js App Router",
    "react": "React web app",
    "node": "Node.js app",
    "python-web": "Python web framework",
    "python": "Python",
    "rust": "Rust",
    "go": "Go",
    "dotnet": ".NET",
    "java-gradle": "Gradle JVM",
    "java-maven": "Maven JVM",
    "php": "PHP",
    "ruby": "Ruby",
    "elixir": "Elixir",
    "swift": "Swift Package Manager",
    "native": "Native build tooling",
    "static-web": "Static web app",
    "generic": "generic or mixed",
}


@dataclass(frozen=True)
class ProjectProfile:
    project_root: Path
    stack_ids: tuple[str, ...]
    primary_stack: str
    package_manager: str = "npm"
    package_scripts: dict[str, str] | None = None
    focused_roots: tuple[Path, ...] = ()

    @property
    def display_name(self) -> str:
        if len(self.stack_ids) <= 1:
            return STACK_LABELS.get(self.primary_stack, "generic or mixed")
        names = [STACK_LABELS.get(stack, stack) for stack in self.stack_ids]
        return " + ".join(names)

    @property
    def allowed_commands(self) -> set[str]:
        allowed = set(BASE_SAFE_COMMANDS)
        for stack in self.stack_ids:
            base_stack = _normalize_stack_family(stack)
            allowed.update(STACK_COMMANDS.get(base_stack, set()))
        if self.primary_stack in {"generic", "static-web"}:
            allowed.update(STACK_COMMANDS["node"])
            allowed.update(STACK_COMMANDS["python"])
        return allowed


def _normalize_stack_family(stack: str) -> str:
    if stack in {"nextjs", "react"}:
        return "node"
    if stack == "python-web":
        return "python"
    return stack


def _safe_listdir(path: Path) -> list[Path]:
    try:
        return list(path.iterdir())
    except Exception:
        return []


def _safe_read_json(path: Path) -> dict:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def _candidate_roots(workspace: Path) -> list[Path]:
    managed_project_root = get_project_root(workspace)
    ordered: list[Path] = []
    seen: set[Path] = set()

    def add(path: Path | None) -> None:
        if path is None or path in seen or not path.exists() or not path.is_dir():
            return
        seen.add(path)
        ordered.append(path)

    add(managed_project_root)
    add(workspace)
    for base in tuple(ordered):
        for child in _safe_listdir(base):
            if child.is_dir() and not child.name.startswith(".") and child.name not in _IGNORED_DIRS:
                add(child)
    return ordered


def _root_score(path: Path) -> int:
    score = 0
    if (path / "package.json").exists():
        score += 30
    for marker in (
        "pyproject.toml",
        "requirements.txt",
        "Pipfile",
        "poetry.lock",
        "Cargo.toml",
        "go.mod",
        "composer.json",
        "mix.exs",
        "pom.xml",
        "build.gradle",
        "build.gradle.kts",
        "Package.swift",
        "CMakeLists.txt",
        "Makefile",
        "Gemfile",
    ):
        if (path / marker).exists():
            score += 25
    if any(path.glob("*.sln")) or any(path.glob("*.csproj")):
        score += 25
    if (path / "index.html").exists():
        score += 10
    for child in _safe_listdir(path):
        if child.name in {"src", "app", "tests", "spec", "cmd", "lib"}:
            score += 3
    return score


def find_project_root(workspace: Path, task_scope: TaskScope | None = None) -> Path:
    if task_scope and task_scope.focused_roots:
        return task_scope.focused_roots[0]
    workspace_root = get_project_root(workspace)
    if _root_score(workspace_root) > 0:
        return workspace_root
    candidates = _candidate_roots(workspace)
    if not candidates:
        return workspace_root
    best = max(candidates, key=_root_score)
    if _root_score(best) > 0:
        return best
    managed = get_project_root(workspace)
    return managed if managed.exists() else workspace


def _detect_package_manager(project_root: Path) -> str:
    if (project_root / "pnpm-lock.yaml").exists():
        return "pnpm"
    if (project_root / "yarn.lock").exists():
        return "yarn"
    return "npm"


def _looks_like_python_project(project_root: Path) -> bool:
    if any((project_root / marker).exists() for marker in ("pyproject.toml", "requirements.txt", "Pipfile", "poetry.lock", "setup.py")):
        return True
    return any(project_root.glob("*.py")) or any((project_root / name).exists() for name in ("manage.py", "conftest.py"))


def _detect_stack_ids(project_root: Path, hint_text: str = "") -> tuple[str, ...]:
    stacks: set[str] = set()
    text = (hint_text or "").lower()

    package_json = project_root / "package.json"
    package_data = _safe_read_json(package_json) if package_json.exists() else {}
    deps = {
        **package_data.get("dependencies", {}),
        **package_data.get("devDependencies", {}),
    }

    if package_json.exists():
        stacks.add("node")
        if "next" in deps or any((project_root / marker).exists() for marker in ("next.config.js", "next.config.mjs", "next.config.ts")):
            stacks.add("nextjs")
        elif "react" in deps or "react-dom" in deps:
            stacks.add("react")

    if _looks_like_python_project(project_root):
        stacks.add("python")
        if (
            (project_root / "manage.py").exists()
            or any(token in text for token in ("django", "fastapi", "flask", "jinja", "uvicorn"))
            or any(name in deps for name in ("django", "fastapi", "flask"))
        ):
            stacks.add("python-web")

    if (project_root / "Cargo.toml").exists():
        stacks.add("rust")
    if (project_root / "go.mod").exists():
        stacks.add("go")
    if any(project_root.glob("*.sln")) or any(project_root.glob("*.csproj")):
        stacks.add("dotnet")
    if (project_root / "build.gradle").exists() or (project_root / "build.gradle.kts").exists() or (project_root / "gradlew").exists() or (project_root / "gradlew.bat").exists():
        stacks.add("java-gradle")
    if (project_root / "pom.xml").exists() or (project_root / "mvnw").exists() or (project_root / "mvnw.cmd").exists():
        stacks.add("java-maven")
    if (project_root / "composer.json").exists() or (project_root / "artisan").exists():
        stacks.add("php")
    if (project_root / "Gemfile").exists() or (project_root / "Rakefile").exists() or (project_root / "config.ru").exists():
        stacks.add("ruby")
    if (project_root / "mix.exs").exists():
        stacks.add("elixir")
    if (project_root / "Package.swift").exists():
        stacks.add("swift")
    if (project_root / "CMakeLists.txt").exists() or (project_root / "Makefile").exists():
        stacks.add("native")
    if not stacks and ((project_root / "index.html").exists() or any(project_root.glob("*.html"))):
        stacks.add("static-web")

    if not stacks and any(token in text for token in ("python", "pytest")):
        stacks.add("python")
    if not stacks and any(token in text for token in ("react", "next.js", "next", "vite", "npm")):
        stacks.add("node")
    if not stacks:
        stacks.add("generic")

    ordered = [stack for stack in STACK_PRIORITY if stack in stacks]
    return tuple(ordered or ["generic"])


def _merge_stack_ids(roots: tuple[Path, ...], hint_text: str = "") -> tuple[str, ...]:
    ordered: list[str] = []
    seen: set[str] = set()
    for root in roots:
        for stack_id in _detect_stack_ids(root, hint_text=hint_text):
            if stack_id in seen:
                continue
            seen.add(stack_id)
            ordered.append(stack_id)
    return tuple(ordered or ["generic"])


def detect_project_profile(
    workspace: Path,
    plan_item: dict | None = None,
    task_scope: TaskScope | None = None,
) -> ProjectProfile:
    hint_text = ""
    if isinstance(plan_item, dict):
        hint_text = f"{plan_item.get('task', '')} {plan_item.get('goal', '')}"
    effective_scope = task_scope
    if effective_scope is None:
        effective_scope = resolve_task_scope(
            workspace,
            user_message=hint_text,
            checked_files=None,
            plan_files=list(plan_item.get("files", [])) if isinstance(plan_item, dict) else None,
            changed_files=None,
        )
    roots = effective_scope.focused_roots or (find_project_root(workspace),)
    project_root = roots[0]
    stack_ids = _merge_stack_ids(tuple(roots), hint_text=hint_text)
    package_scripts = None
    package_json = project_root / "package.json"
    if package_json.exists():
        package_scripts = _safe_read_json(package_json).get("scripts", {}) or {}
    return ProjectProfile(
        project_root=project_root,
        stack_ids=stack_ids,
        primary_stack=stack_ids[0] if stack_ids else "generic",
        package_manager=_detect_package_manager(project_root),
        package_scripts=package_scripts,
        focused_roots=tuple(roots),
    )


def _node_script_command(profile: ProjectProfile, script: str) -> list[str] | None:
    scripts = profile.package_scripts or {}
    if script not in scripts:
        return None
    if profile.package_manager == "pnpm":
        cmd = ["pnpm", script]
        if script == "test":
            cmd.extend(["--", "--watchAll=false"])
        return cmd
    if profile.package_manager == "yarn":
        cmd = ["yarn", script]
        if script == "test":
            cmd.append("--watchAll=false")
        return cmd
    if script == "test":
        return ["npm", "test", "--", "--watchAll=false"]
    return ["npm", "run", script]


def _first_existing(project_root: Path, names: list[str], fallback: str) -> str:
    for name in names:
        if (project_root / name).exists():
            return name
    return fallback


def _unique_targets(targets: list[str] | None) -> list[str]:
    ordered: list[str] = []
    seen: set[str] = set()
    for target in targets or []:
        normalized = str(Path(str(target)).as_posix()).lstrip("./")
        if not normalized or normalized in seen:
            continue
        seen.add(normalized)
        ordered.append(normalized)
    return ordered


def _has_eslint_config(project_root: Path) -> bool:
    return any(
        (project_root / marker).exists()
        for marker in (
            ".eslintrc.js",
            ".eslintrc.json",
            ".eslintrc.cjs",
            "eslint.config.js",
            "eslint.config.cjs",
            "eslint.config.mjs",
            "eslint.config.ts",
        )
    )


def build_test_commands(
    profile: ProjectProfile,
    *,
    targets: list[str] | None = None,
    verification_mode: str = "project",
) -> list[tuple[str, list[str]]]:
    if verification_mode == "scoped":
        return []
    commands: list[tuple[str, list[str]]] = []
    if "node" in profile.stack_ids or "nextjs" in profile.stack_ids or "react" in profile.stack_ids:
        node_test = _node_script_command(profile, "test")
        if node_test:
            label = f"{profile.package_manager} test" if profile.package_manager != "npm" else "npm test"
            commands.append((label, node_test))
    if "python-web" in profile.stack_ids and (profile.project_root / "manage.py").exists():
        commands.append(("python manage.py test", ["python", "manage.py", "test"]))
    if "python" in profile.stack_ids:
        if any(
            (profile.project_root / marker).exists()
            for marker in ("pytest.ini", "pyproject.toml")
        ) or list(profile.project_root.glob("tests/*.py")) or list(profile.project_root.glob("test_*.py")):
            commands.append(("pytest", ["pytest", "--tb=short", "-q"]))
        commands.append(("python -m unittest", ["python", "-m", "unittest", "discover"]))
    if "rust" in profile.stack_ids:
        commands.append(("cargo test", ["cargo", "test", "--quiet"]))
    if "go" in profile.stack_ids:
        commands.append(("go test", ["go", "test", "./..."]))
    if "dotnet" in profile.stack_ids:
        commands.append(("dotnet test", ["dotnet", "test", "--nologo"]))
    if "java-maven" in profile.stack_ids:
        mvn = _first_existing(profile.project_root, ["mvnw.cmd", "mvnw"], "mvn")
        commands.append(("maven test", [mvn, "test", "-q"]))
    if "java-gradle" in profile.stack_ids:
        gradle = _first_existing(profile.project_root, ["gradlew.bat", "gradlew"], "gradle")
        commands.append(("gradle test", [gradle, "test", "--console=plain"]))
    if "php" in profile.stack_ids:
        composer_test = False
        composer_json = _safe_read_json(profile.project_root / "composer.json")
        if "test" in (composer_json.get("scripts") or {}):
            commands.append(("composer test", ["composer", "test"]))
            composer_test = True
        if (profile.project_root / "artisan").exists():
            commands.append(("php artisan test", ["php", "artisan", "test"]))
        if not composer_test and (
            (profile.project_root / "phpunit.xml").exists()
            or (profile.project_root / "phpunit.xml.dist").exists()
            or (profile.project_root / "tests").exists()
        ):
            commands.append(("phpunit", ["phpunit"]))
    if "ruby" in profile.stack_ids:
        if (profile.project_root / "spec").exists():
            commands.append(("bundle exec rspec", ["bundle", "exec", "rspec"]))
        if (profile.project_root / "test").exists():
            commands.append(("bundle exec rake test", ["bundle", "exec", "rake", "test"]))
    if "elixir" in profile.stack_ids:
        commands.append(("mix test", ["mix", "test"]))
    if "swift" in profile.stack_ids:
        commands.append(("swift test", ["swift", "test"]))
    if "native" in profile.stack_ids and (profile.project_root / "CMakeLists.txt").exists():
        commands.append(("ctest", ["ctest", "--output-on-failure"]))
    return commands


def build_lint_commands(
    profile: ProjectProfile,
    *,
    targets: list[str] | None = None,
    verification_mode: str = "project",
) -> list[tuple[str, list[str]]]:
    commands: list[tuple[str, list[str]]] = []
    normalized_targets = _unique_targets(targets)
    if "node" in profile.stack_ids or "nextjs" in profile.stack_ids or "react" in profile.stack_ids:
        if verification_mode == "scoped":
            if normalized_targets and _has_eslint_config(profile.project_root):
                commands.append(("eslint", ["npx", "eslint", *normalized_targets, "--max-warnings=0"]))
        else:
            node_lint = _node_script_command(profile, "lint")
            if node_lint:
                label = f"{profile.package_manager} lint" if profile.package_manager != "npm" else "npm run lint"
                commands.append((label, node_lint))
            elif _has_eslint_config(profile.project_root):
                commands.append(("eslint", ["npx", "eslint", ".", "--max-warnings=0"]))
    if "python" in profile.stack_ids:
        pyproject = (profile.project_root / "pyproject.toml")
        pyproject_text = ""
        try:
            if pyproject.exists():
                pyproject_text = pyproject.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            pyproject_text = ""
        python_targets = [target for target in normalized_targets if Path(target).suffix.lower() == ".py"]
        if verification_mode == "scoped":
            if python_targets:
                if (profile.project_root / "ruff.toml").exists() or "[tool.ruff" in pyproject_text:
                    commands.append(("ruff", ["ruff", "check", *python_targets]))
                commands.append(
                    (
                        "flake8",
                        [
                            "flake8",
                            "--exclude=node_modules,.venv,.env,.snapshots,__pycache__",
                            "--max-line-length=120",
                            "--count",
                            *python_targets,
                        ],
                    )
                )
        else:
            if (profile.project_root / "ruff.toml").exists() or "[tool.ruff" in pyproject_text:
                commands.append(("ruff", ["ruff", "check", "."]))
            commands.append(("flake8", ["flake8", "--exclude=node_modules,.venv,.env,.snapshots,__pycache__", "--max-line-length=120", "--count", "."]))
    if verification_mode != "scoped" and "go" in profile.stack_ids:
        commands.append(("go vet", ["go", "vet", "./..."]))
    if verification_mode != "scoped" and "elixir" in profile.stack_ids and (profile.project_root / ".formatter.exs").exists():
        commands.append(("mix format", ["mix", "format", "--check-formatted"]))
    return commands


def build_build_commands(
    profile: ProjectProfile,
    *,
    targets: list[str] | None = None,
    verification_mode: str = "project",
) -> list[tuple[str, list[str]]]:
    if verification_mode == "scoped":
        return []
    commands: list[tuple[str, list[str]]] = []
    if "node" in profile.stack_ids or "nextjs" in profile.stack_ids or "react" in profile.stack_ids:
        node_build = _node_script_command(profile, "build")
        if node_build:
            label = f"{profile.package_manager} build" if profile.package_manager != "npm" else "npm build"
            commands.append((label, node_build))
    if "rust" in profile.stack_ids:
        commands.append(("cargo check", ["cargo", "check", "--quiet"]))
    if "go" in profile.stack_ids:
        commands.append(("go build", ["go", "build", "./..."]))
    if "dotnet" in profile.stack_ids:
        commands.append(("dotnet build", ["dotnet", "build", "--nologo"]))
    if "java-maven" in profile.stack_ids:
        mvn = _first_existing(profile.project_root, ["mvnw.cmd", "mvnw"], "mvn")
        commands.append(("maven package", [mvn, "-q", "-DskipTests", "package"]))
    if "java-gradle" in profile.stack_ids:
        gradle = _first_existing(profile.project_root, ["gradlew.bat", "gradlew"], "gradle")
        commands.append(("gradle build", [gradle, "build", "-x", "test", "--console=plain"]))
    if "elixir" in profile.stack_ids:
        commands.append(("mix compile", ["mix", "compile", "--warnings-as-errors"]))
    if "swift" in profile.stack_ids:
        commands.append(("swift build", ["swift", "build"]))
    if "native" in profile.stack_ids and (profile.project_root / "Makefile").exists():
        commands.append(("make", ["make"]))
    return commands
