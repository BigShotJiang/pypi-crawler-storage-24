"""
tool_registry.py — Central registry for agent tools.
"""
from typing import Callable, Dict, Any

TOOLS: Dict[str, Callable] = {}

def register_tool(name: str):
    """
    Decorator to register an agent tool.
    Example:
      @register_tool("write_file")
      def write_file(...):
    """
    def decorator(func: Callable):
        TOOLS[name] = func
        return func
    return decorator

def get_tool(name: str) -> Callable:
    if name not in TOOLS:
        raise ValueError(f"Tool '{name}' is not registered.")
    return TOOLS[name]

# This will trigger the decorators to populate TOOLS
def load_all_tools():
    import nexcode.tools.file_tools
    import nexcode.tools.shell_tools
    import nexcode.tools.test_tools
