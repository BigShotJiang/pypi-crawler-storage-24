"""
snapshot.py — Handles automated git checkpoints during execution.
"""
import subprocess
from pathlib import Path
from rich.console import Console
from nexcode.agent_runtime.presentation import ui_detail, ui_status
from nexcode.agent_runtime.workspace import get_scratch_root, is_in_place_workspace

console = Console()

def create_snapshot(workspace: Path, step_idx: int):
    """
    Creates a git commit checkpoint of the workspace.
    Initializes git if it doesn't exist.
    """
    if is_in_place_workspace(workspace):
        return

    try:
        if not (workspace / ".git").exists():
            subprocess.run(["git", "init"], cwd=workspace, capture_output=True, check=True)
            
        subprocess.run(["git", "add", "."], cwd=workspace, capture_output=True, check=True)
        scratch_root = get_scratch_root(workspace)
        scratch_rel = scratch_root.relative_to(workspace) if scratch_root.exists() else None
        if scratch_rel is not None:
            subprocess.run(
                ["git", "reset", "-q", "--", str(scratch_rel).replace("\\", "/")],
                cwd=workspace,
                capture_output=True,
                check=False,
            )
        
        msg = f"Auto-checkpoint: Step {step_idx} complete"
        # We don't use check=True here because there might be nothing to commit
        res = subprocess.run(["git", "commit", "-m", msg], cwd=workspace, capture_output=True)
        
        if res.returncode == 0:
            console.print(ui_detail("Checkpoint", f"Saved git checkpoint for step {step_idx}"))
            
    except Exception as e:
        console.print(ui_status("Warning", f"Failed to create git snapshot: {e}", tone="warning"))
