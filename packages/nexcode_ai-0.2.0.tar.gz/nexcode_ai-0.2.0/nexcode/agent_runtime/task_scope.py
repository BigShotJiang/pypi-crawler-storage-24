from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path

from nexcode.agent_runtime.workspace import get_project_root, normalize_rel_path, safe_path

DISCOVERY_IGNORED_DIRS = {
    ".agent",
    ".ai_logs",
    ".ai-workspace",
    ".cache",
    ".docker",
    ".git",
    ".hg",
    ".history",
    ".idea",
    ".ipynb_checkpoints",
    ".model_cache",
    ".mypy_cache",
    ".next",
    ".nuxt",
    ".parcel-cache",
    ".pnpm-store",
    ".pytest_cache",
    ".ruff_cache",
    ".scratch",
    ".snapshots",
    ".svn",
    ".tox",
    ".turbo",
    ".venv",
    ".vscode",
    ".yarn",
    "__pycache__",
    "bin",
    "build",
    "checkpoints",
    "coverage",
    "debug",
    "dist",
    "env",
    "html",
    "node_modules",
    "obj",
    "out",
    "release",
    "runs",
    "site",
    "storybook-static",
    "target",
    "temp",
    "tmp",
    "vendor",
    "venv",
    "wandb",
}

DISCOVERY_IGNORED_FILE_SUFFIXES = {
    ".dll",
    ".dylib",
    ".exe",
    ".gif",
    ".gz",
    ".ico",
    ".jpg",
    ".jpeg",
    ".pdf",
    ".png",
    ".so",
    ".svgz",
    ".webp",
    ".zip",
}

MANIFEST_MARKERS = (
    "package.json",
    "pyproject.toml",
    "requirements.txt",
    "Pipfile",
    "poetry.lock",
    "setup.py",
    "pytest.ini",
    "Cargo.toml",
    "go.mod",
    "composer.json",
    "mix.exs",
    "pom.xml",
    "build.gradle",
    "build.gradle.kts",
    "Gemfile",
    "Package.swift",
    "CMakeLists.txt",
    "Makefile",
)

EXECUTION_REQUEST_RE = re.compile(
    r"\b(?:run|execute|launch|start)\b.*\b(?:file|script|program)?\b",
    re.IGNORECASE,
)


@dataclass(frozen=True)
class TaskScope:
    mode: str
    focused_files: tuple[str, ...]
    explicit_files: tuple[str, ...]
    focused_roots: tuple[Path, ...]

    @property
    def primary_root(self) -> Path | None:
        return self.focused_roots[0] if self.focused_roots else None


def _unique_paths(items: list[str]) -> tuple[str, ...]:
    ordered: list[str] = []
    seen: set[str] = set()
    for item in items:
        normalized = normalize_rel_path(item).rstrip("/")
        if not normalized or normalized in seen:
            continue
        seen.add(normalized)
        ordered.append(normalized)
    return tuple(ordered)


def _extract_file_mentions(*texts: str) -> list[str]:
    found: list[str] = []
    # Strict regex for paths with extensions, avoiding common command noise tokens.
    # We ignore potential version numbers or huge hex strings by limiting part length.
    path_pattern = re.compile(r"[\w\-/\\._]{2,64}\.\w{2,10}")
    for text in texts:
        if not text:
            continue
        # Skip very long lines which are likely minified code or command output noise
        for line in text.splitlines():
            if len(line) > 300:
                continue
            for match in path_pattern.findall(line):
                # Basic noise filtering: skip common command tokens that look like files
                if match.lower() in {"requirement.already", "installing.", "collecting."}:
                    continue
                found.append(str(Path(match).as_posix()))
    return found


def _has_manifest(path: Path) -> bool:
    return any((path / marker).exists() for marker in MANIFEST_MARKERS) or any(path.glob("*.sln")) or any(path.glob("*.csproj"))


def _resolve_existing_explicit_files(project_root: Path, *texts: str) -> tuple[str, ...]:
    resolved: list[str] = []
    for candidate in _extract_file_mentions(*texts):
        normalized = normalize_rel_path(candidate)
        if not normalized:
            continue
        try:
            target = safe_path(project_root, normalized)
        except Exception:
            continue
        if target.exists() and target.is_file():
            resolved.append(normalized)
    return _unique_paths(resolved)


def _iter_parent_candidates(project_root: Path, rel_path: str) -> list[Path]:
    normalized = normalize_rel_path(rel_path)
    if not normalized or normalized.startswith("scratch:"):
        return []
    relative = Path(normalized)
    current = project_root / relative
    parent = current if current.is_dir() else current.parent
    candidates: list[Path] = []
    while True:
        try:
            parent.relative_to(project_root)
        except ValueError:
            break
        candidates.append(parent)
        if parent == project_root:
            break
        parent = parent.parent
    return candidates


def _nearest_manifest_root(project_root: Path, rel_path: str) -> Path:
    for candidate in _iter_parent_candidates(project_root, rel_path):
        if _has_manifest(candidate):
            return candidate
    return project_root


def _detect_mode(user_message: str, mode_hint: str = "") -> str:
    normalized_hint = str(mode_hint or "").strip().lower()
    if normalized_hint in {"consult_only", "review_only", "implementation", "execution_request"}:
        return normalized_hint
    if EXECUTION_REQUEST_RE.search(str(user_message or "")) and _extract_file_mentions(user_message):
        return "execution_request"
    return "implementation"


def resolve_task_scope(
    workspace: Path,
    user_message: str = "",
    checked_files: list[str] | None = None,
    plan_files: list[str] | None = None,
    changed_files: list[str] | None = None,
    mode_hint: str = "",
) -> TaskScope:
    project_root = get_project_root(workspace).resolve()
    explicit_files = _resolve_existing_explicit_files(project_root, user_message)

    combined_files = _unique_paths(
        list(explicit_files)
        + [str(item) for item in (changed_files or [])]
        + [str(item) for item in (plan_files or [])]
        + [str(item) for item in (checked_files or [])]
    )

    roots: list[Path] = []
    seen_roots: set[Path] = set()

    for rel_path in combined_files:
        root = _nearest_manifest_root(project_root, rel_path).resolve()
        if root not in seen_roots:
            seen_roots.add(root)
            roots.append(root)

    if not roots:
        if _has_manifest(project_root):
            roots = [project_root]
        else:
            roots = [project_root]

    return TaskScope(
        mode=_detect_mode(user_message, mode_hint=mode_hint),
        focused_files=combined_files,
        explicit_files=explicit_files,
        focused_roots=tuple(roots),
    )


def _is_noise_file(path: Path) -> bool:
    if path.name.lower().startswith(".env"):
        return True
    return path.suffix.lower() in DISCOVERY_IGNORED_FILE_SUFFIXES


def _iter_visible_files(root: Path, limit: int) -> list[str]:
    import os
    files: list[str] = []
    ignored_names = {d.lower() for d in DISCOVERY_IGNORED_DIRS}
    
    # Use os.walk for efficiency: it allows pruning 'dirs' in-place to avoid
    # descending into massive ignored directories like node_modules or .venv.
    for current_dir, dirs, filenames in os.walk(root):
        # Prune ignored directories in-place
        dirs[:] = [d for d in dirs if d.lower() not in ignored_names and not d.startswith(".")]
        
        for f in filenames:
            if len(files) >= limit:
                return files
            
            f_path = Path(current_dir) / f
            if _is_noise_file(f_path):
                continue
            
            try:
                rel = f_path.relative_to(root)
                files.append(str(rel).replace("\\", "/"))
            except ValueError:
                continue
    return files


def build_workspace_summary(workspace: Path, scope: TaskScope, max_chars: int = 12000) -> str:
    project_root = get_project_root(workspace).resolve()

    if scope.focused_files:
        nearby: list[str] = []
        seen: set[str] = set(scope.focused_files)
        for root in scope.focused_roots:
            try:
                rel_root = root.relative_to(project_root)
                prefix = "" if str(rel_root) == "." else str(rel_root).replace("\\", "/").rstrip("/") + "/"
            except ValueError:
                prefix = ""
            for marker in ("README.md", *MANIFEST_MARKERS):
                candidate = root / marker
                if candidate.exists() and candidate.is_file():
                    rel_candidate = f"{prefix}{marker}".lstrip("/")
                    if rel_candidate not in seen:
                        seen.add(rel_candidate)
                        nearby.append(rel_candidate)
        lines = ["Focused workspace summary:"]
        for rel_path in list(scope.focused_files) + nearby:
            lines.append(f"- {rel_path}")
        summary = "\n".join(lines)
        return summary[:max_chars]

    top_level_lines: list[str] = ["Workspace summary:"]
    for child in sorted(project_root.iterdir(), key=lambda item: item.name.lower()):
        if child.name in DISCOVERY_IGNORED_DIRS or child.name.startswith(".env"):
            continue
        if child.is_file():
            if _is_noise_file(child):
                continue
            top_level_lines.append(f"- {child.name}")
            continue
        sample_count = len(_iter_visible_files(child, 200))
        top_level_lines.append(f"- {child.name}/ ({sample_count} visible files)")

    visible_files = _iter_visible_files(project_root, 120)
    if visible_files:
        top_level_lines.append("")
        top_level_lines.append("Representative files:")
        for rel_path in visible_files:
            top_level_lines.append(f"- {rel_path}")

    summary = "\n".join(top_level_lines)
    return summary[:max_chars]
