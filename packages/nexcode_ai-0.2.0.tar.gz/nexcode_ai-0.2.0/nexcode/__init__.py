"""
nexcode - CLI for the Nexcode AI
"""

__version__ = "0.2.0"
__app_name__ = "nexcode"
__description__ = "CLI for the Nexcode AI - configure providers and run workspace agents from your terminal"
