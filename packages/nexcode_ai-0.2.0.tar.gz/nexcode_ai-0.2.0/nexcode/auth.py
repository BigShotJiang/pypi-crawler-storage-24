"""
auth.py - Provider login: prompt API key, test connection, save to nested nexcode.json.
"""

import getpass
import os
import sys

from openai import APIConnectionError, APIError, AuthenticationError, OpenAI
from rich.console import Console
from rich.panel import Panel
from rich.prompt import Prompt

from nexcode.config import (
    PROVIDER_DEFAULTS,
    is_provider_configured,
    load_full_access,
    save_provider_credentials,
)

console = Console()

_PROVIDER_META = {
    "grok": {
        "name": "xAI Grok",
        "color": "cyan",
        "key_hint": "Get your API key from the xAI console: [cyan]https://console.x.ai[/cyan]",
        "key_prompt": "xAI API Key (hidden): ",
        "ping_model": "grok-4-1-fast-reasoning",
        "env_var": "XAI_API_KEY",
    },
    "gemini": {
        "name": "Google Gemini",
        "color": "green",
        "key_hint": "Get your API key from Google AI Studio: [green]https://aistudio.google.com/app/apikey[/green]",
        "key_prompt": "Google AI Studio API Key (hidden): ",
        "ping_model": "gemini-3-flash-preview",
        "env_var": "GOOGLE_API_KEY",
    },
}


def _test_connection(endpoint: str, api_key: str, model: str) -> tuple[bool, str]:
    """Test connection to the provider endpoint. Returns (success, message)."""
    try:
        client = OpenAI(base_url=endpoint, api_key=api_key, timeout=15.0)
        client.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": "ping"}],
            stream=False,
            max_tokens=5,
        )
        return True, "Connection successful ✓"
    except AuthenticationError:
        return False, "Invalid API key (401 Unauthorized)"
    except APIConnectionError:
        return False, f"Cannot connect to '{endpoint}'"
    except APIError as exc:
        return False, f"API Error: {exc.message}"
    except Exception as exc:
        return False, f"Unexpected error: {exc}"


def login(provider: str = "grok") -> None:
    """
    Configure the API key for a specific provider (grok or gemini).
    Credentials are stored in nexcode.json nested under the provider name.
    The user only needs to do this once per provider.
    """
    if provider not in _PROVIDER_META:
        console.print(f"[red]Unknown provider '{provider}'. Use 'grok' or 'gemini'.[/red]")
        sys.exit(1)

    meta = _PROVIDER_META[provider]
    defaults = PROVIDER_DEFAULTS[provider]
    color = meta["color"]
    already = is_provider_configured(provider)

    console.print()
    console.print(
        Panel(
            f"[bold {color}]{meta['name']} - Login[/bold {color}]\n"
            f"[dim]{'Update' if already else 'Set up'} your {meta['name']} API key.[/dim]",
            border_style=color,
        )
    )
    console.print()

    console.print(f"[dim]{meta['key_hint']}[/dim]")
    if already:
        console.print("[dim]A key is already configured. Press Enter to keep it, or paste a new one.[/dim]")
    try:
        api_key = getpass.getpass(meta["key_prompt"]).strip()
    except (KeyboardInterrupt, EOFError):
        console.print("\n[yellow]Login cancelled.[/yellow]")
        sys.exit(0)

    if not api_key:
        if already:
            full = load_full_access()
            api_key = full[provider]["api_key"]
            console.print(f"[dim]Keeping existing {meta['name']} key.[/dim]")
        else:
            console.print("[red]✗ API key cannot be empty.[/red]")
            sys.exit(1)

    endpoint = defaults["endpoint"]
    default_model = defaults["model"]

    console.print()
    with console.status(f"[bold {color}]Testing connection...[/bold {color}]", spinner="dots"):
        ok, msg = _test_connection(endpoint, api_key, model=meta["ping_model"])

    if ok:
        console.print(f"[bold green]✓ {msg}[/bold green]")
    else:
        console.print(f"[bold red]✗ {msg}[/bold red]")
        force_save = Prompt.ask(
            "\n[yellow]Connection test failed. Save this configuration anyway?[/yellow]",
            choices=["y", "n"],
            default="n",
            console=console,
        )
        if force_save.lower() != "y":
            console.print("[red]Login aborted.[/red]")
            sys.exit(1)

    full = load_full_access()
    existing_model = full.get(provider, {}).get("model", default_model)
    save_provider_credentials(provider, api_key, endpoint, existing_model)
    os.environ[meta["env_var"]] = api_key

    console.print()
    console.print(
        Panel(
            f"[bold green]{meta['name']} configured![/bold green]\n"
            f"[dim]Model:[/dim] [{color}]{existing_model}[/{color}]\n"
            f"[dim]Saved to:[/dim] [{color}]~/.nexcode-ai/nexcode.json[/{color}]",
            border_style="green",
        )
    )

    _print_provider_summary()


def login_status() -> None:
    """Show which providers are configured and which is currently active."""
    console.print()
    _print_provider_summary()


def _print_provider_summary() -> None:
    """Print a compact status of all configured providers."""
    from rich import box as rbox
    from rich.table import Table

    full = load_full_access()
    active = full.get("active", "grok")

    table = Table(box=rbox.ROUNDED, border_style="dim", show_header=True, header_style="bold white")
    table.add_column("Provider", style="bold", no_wrap=True)
    table.add_column("Status", no_wrap=True)
    table.add_column("Model", style="dim")
    table.add_column("Active", no_wrap=True)

    for provider, meta in _PROVIDER_META.items():
        configured = bool(full.get(provider, {}).get("api_key", ""))
        model = full.get(provider, {}).get("model", PROVIDER_DEFAULTS[provider]["model"])
        status = "[green]✓ Configured[/green]" if configured else "[red]✗ Not set[/red]"
        is_active = "● active" if provider == active else ""
        table.add_row(meta["name"], status, model, is_active)

    console.print(table)
    console.print()
    console.print("[dim]Switch provider: [bold]nexcode switch grok[/bold] or [bold]nexcode switch gemini[/bold][/dim]")
    console.print("[dim]Change model:    [bold]nexcode config model <model-name>[/bold][/dim]")
    console.print()
