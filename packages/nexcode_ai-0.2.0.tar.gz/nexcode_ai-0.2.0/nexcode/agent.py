"""
agent.py — Main router for the autonomous coding agent.
"""

import re
import subprocess
import sys
import time
from pathlib import Path
from rich.console import Console
from datetime import datetime, timezone
from nexcode.agent_runtime.presentation import ui_detail, ui_header, ui_status, ui_timing

# Force UTF-8 on Windows for consistent Rich output
if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

console = Console()

_ASSISTANT_INTENT_MODES = {"conservative", "balanced", "autonomous"}
_ASSISTANT_ROUTING_STRATEGIES = {"heuristic", "ai_first"}
_WORKSPACE_ROUTE_KINDS = {"casual_chat", "review_only", "assistant", "execution_request"}
_EXECUTION_ACTION_KINDS = {"run", "build", "test", "open"}
_ACTION_VERBS = ("fix", "implement", "add", "create", "update", "change", "remove", "refactor", "build", "rewrite", "make")
_CONSULT_HINTS = (
    "what else can we add",
    "what should we add",
    "what can we add",
    "what else can we do",
    "what can we do",
    "what else should we add",
    "any ideas",
    "suggest",
    "recommend",
    "is this okay",
    "is this good",
    "can you explain",
    "could you explain",
    "what do you think",
    "how can we improve",
    "how should we",
    "what sections should",
    "what sections can",
)
_BUG_HINTS = (
    " bug",
    "broken",
    "not working",
    "doesn't work",
    "doesnt work",
    "error",
    "issue",
    "failing",
    "fails",
    "failed",
    "crash",
    "problem",
)
_REVIEW_HINTS = (
    "review the codebase",
    "review current codebase",
    "review the architecture",
    "audit the architecture",
    "audit the codebase",
    "find flaws",
    "find issues in architecture",
    "architectural flaws",
    "architecture flaws",
    "explore curr code base",
    "explore current code base",
    "explore current codebase",
    "analyze the architecture",
    "analyze architecture",
    "inspect the architecture",
)
_CLOSURE_HINTS = (
    "thanks",
    "thank you",
    "working now",
    "works now",
    "now working",
    "all good",
    "looks good",
    "resolved now",
    "fixed now",
)
_CASUAL_CHAT_PATTERNS = (
    re.compile(r"^(?:hi|hello|hey)(?:\s+(?:there|buddy|bro|team|folks|everyone|nexcode|nexcode agent))?$", re.IGNORECASE),
    re.compile(r"^good\s+(?:morning|afternoon|evening)(?:\s+(?:buddy|team|everyone))?$", re.IGNORECASE),
    re.compile(
        r"^(?:thanks|thank you|thankyou|thx|thanks a lot|many thanks)(?:\s+(?:so much|buddy|bro|man|team|nexcode|nexcode agent|again|for that|for the help))*$",
        re.IGNORECASE,
    ),
    re.compile(r"^(?:all good(?: now)?|looks good|working now|works now|resolved now|fixed now)$", re.IGNORECASE),
    re.compile(r"^(?:ok|okay|cool|nice|awesome|great|perfect)(?:\s+(?:thanks|thank you|buddy|bro|man|team))?$", re.IGNORECASE),
    re.compile(r"^(?:how are you|how's it going|hows it going|what's up|whats up)$", re.IGNORECASE),
    re.compile(r"^(?:bye|goodbye|see you|see ya|talk soon|catch you later)$", re.IGNORECASE),
)
_CASUAL_CHAT_TOKEN_ALLOWLIST = {
    "hi",
    "hello",
    "hey",
    "there",
    "buddy",
    "bro",
    "man",
    "team",
    "folks",
    "everyone",
    "nexcode",
    "agent",
    "good",
    "morning",
    "afternoon",
    "evening",
    "thanks",
    "thank",
    "you",
    "thankyou",
    "thx",
    "so",
    "much",
    "again",
    "for",
    "the",
    "help",
    "all",
    "looks",
    "working",
    "works",
    "resolved",
    "fixed",
    "now",
    "ok",
    "okay",
    "cool",
    "nice",
    "awesome",
    "great",
    "perfect",
    "how",
    "are",
    "its",
    "it's",
    "going",
    "what",
    "whats",
    "what's",
    "up",
    "bye",
    "goodbye",
    "see",
    "ya",
    "talk",
    "soon",
    "catch",
    "later",
    "appreciate",
    "appreciated",
    "it",
}
_METADATA_ONLY_DIRS = {
    ".agent",
    ".git",
    ".github",
    ".idea",
    ".vscode",
    ".pytest_cache",
    ".next",
    "node_modules",
    "dist",
    "build",
    "out",
    "target",
    "coverage",
    "__pycache__",
    ".venv",
    "venv",
    "env",
}
_METADATA_ONLY_FILES = {
    ".gitignore",
    ".gitattributes",
    ".editorconfig",
    "readme.md",
    "license",
    "license.md",
    "license.txt",
    "changelog.md",
}
_IMPLEMENTATION_LEAD_RE = re.compile(
    r"^(?:please\s+)?(?:(?:can|could|would|will|shall)\s+you\s+)?(?:help\s+me\s+)?"
    r"(?P<verb>fix|implement|add|create|update|change|remove|refactor|build|rewrite|make)\b(?P<rest>.*)$",
    re.IGNORECASE,
)
_IMPLEMENTATION_INLINE_RE = re.compile(
    r"\b(?P<verb>fix|implement|add|create|update|change|remove|refactor|build|rewrite|make)\b(?P<rest>.*)$",
    re.IGNORECASE,
)
_FOLLOWUP_ACTION_RE = re.compile(
    r"(?P<lead>.*?)(?:,|\b(?:and|also|then)\b)\s*"
    r"(?P<action>(?:please\s+)?(?:(?:can|could|would|will|shall)\s+you\s+)?(?:help\s+me\s+)?"
    r"(?:fix|implement|add|create|update|change|remove|refactor|build|rewrite|make)\b.*)$",
    re.IGNORECASE | re.DOTALL,
)
_EXECUTION_REQUEST_RE = re.compile(
    r"\b(?:run|execute|launch|start)\b.*(?:\bfile\b|\bscript\b|\boutput\b|\bwhat (?:you|u) see\b)?",
    re.IGNORECASE,
)
_FOLLOWUP_TARGET_ACTION_RE = re.compile(
    r"^(?:please\s+)?(?:(?:can|could|would|will|shall)\s+you\s+)?(?:help\s+me\s+)?(?P<verb>run|execute|launch|start|test|build|open)\b",
    re.IGNORECASE,
)
_REFERENTIAL_TARGET_HINTS = (
    "that file",
    "this file",
    "that script",
    "this script",
    "that app",
    "this app",
    "that project",
    "this project",
    "the app we just made",
    "the project we just made",
    "the file we just made",
    "the file you created",
    "the app you created",
    "it",
)

def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _fmt_duration(seconds: float) -> str:
    try:
        seconds = float(seconds)
    except Exception:
        return "unknown"
    if seconds < 0:
        seconds = 0
    if seconds < 1:
        return f"{seconds*1000:.0f}ms"
    if seconds < 60:
        return f"{seconds:.1f}s"
    minutes = int(seconds // 60)
    rem = seconds - (minutes * 60)
    if minutes < 60:
        return f"{minutes}m{rem:04.1f}s"
    hours = minutes // 60
    minutes = minutes % 60
    return f"{hours}h{minutes:02d}m"


def _append_timing_event(state: dict, event: dict, max_events: int = 200) -> dict:
    """
    Persist a bounded list of timing events for observability.
    """
    events = state.get("timing_events", [])
    if not isinstance(events, list):
        events = []
    events.append(event)
    if len(events) > max_events:
        events = events[-max_events:]
    state["timing_events"] = events
    state["last_timing_event"] = event
    return state


def _strip_wrapping_quotes(text: str) -> str:
    t = (text or "").strip()
    if len(t) >= 2 and ((t[0] == '"' and t[-1] == '"') or (t[0] == "'" and t[-1] == "'")):
        return t[1:-1]
    return t


def _resolve_image(img_path: str) -> str | None:
    """
    Resolve an image path or URL to a usable image_url string.
    Mirrors nexcode.cli._resolve_image, but kept local to avoid import coupling.
    """
    import os
    import base64
    import mimetypes

    p = (img_path or "").strip()
    if not p:
        return None
    if p.startswith("http://") or p.startswith("https://"):
        return p
    if os.path.exists(p):
        mime_type, _ = mimetypes.guess_type(p)
        mime_type = mime_type or "image/jpeg"
        with open(p, "rb") as f:
            encoded = base64.b64encode(f.read()).decode("utf-8")
        return f"data:{mime_type};base64,{encoded}"
    console.print(f"[red]ERROR:[/red] Image file not found: {p}")
    return None


def _normalize_fix_history(raw_history) -> list[dict]:
    """
    Back-compat: fix_history used to be a list[str]. Normalize to list[dict].
    Expected shape: {"prompt": str, "outcome": str}
    """
    normalized: list[dict] = []
    if not isinstance(raw_history, list):
        return normalized
    for entry in raw_history:
        if isinstance(entry, str) and entry.strip():
            normalized.append({"prompt": entry.strip(), "outcome": "Completed (No summary available)"})
        elif isinstance(entry, dict):
            prompt = str(entry.get("prompt") or "").strip()
            outcome = str(entry.get("outcome") or "").strip()
            if prompt or outcome:
                item = {"prompt": prompt, "outcome": outcome}
                for key in ("resolution_type", "context_scope", "intent"):
                    value = str(entry.get(key) or "").strip()
                    if value:
                        item[key] = value
                normalized.append(item)
    return normalized


def _update_latest_fix_history_entry(state: dict, user_message: str, **fields) -> dict:
    history = state.get("fix_history", [])
    if not history or not isinstance(history[-1], dict) or history[-1].get("prompt") != user_message:
        return state
    for key, value in fields.items():
        if value is None:
            continue
        history[-1][key] = value
    return state


def _history_entry_is_implementation(entry: dict) -> bool:
    if not isinstance(entry, dict):
        return False
    resolution_type = str(entry.get("resolution_type") or "").strip().lower()
    context_scope = str(entry.get("context_scope") or entry.get("intent") or "").strip().lower()
    if context_scope == "execution_request":
        return False
    if resolution_type == "code_change":
        return True
    if context_scope in {"implementation", "mixed"}:
        return True
    prompt = str(entry.get("prompt") or "")
    outcome = str(entry.get("outcome") or "").lower()
    if "what i changed:" in outcome or "implementation update:" in outcome:
        return True
    if _extract_explicit_action_request(prompt, "conservative") or _contains_bug_signal(prompt):
        return True
    return False


def _filter_fix_history_context(entries: list[dict], implementation_only: bool = False) -> list[dict]:
    filtered: list[dict] = []
    for entry in (entries or []):
        if not isinstance(entry, dict):
            continue
        context_scope = str(entry.get("context_scope") or entry.get("intent") or "").strip().lower()
        if context_scope == "casual_chat":
            continue
        if implementation_only and not _history_entry_is_implementation(entry):
            continue
        filtered.append(entry)
    return filtered


def _clamp_assistant_context_start(state: dict, history_len: int) -> int:
    try:
        idx = int(state.get("assistant_context_start_idx", 0) or 0)
    except Exception:
        idx = 0
    idx = max(0, min(idx, history_len))
    state["assistant_context_start_idx"] = idx
    return idx


def _assistant_soft_reset_state(state: dict) -> dict:
    """
    Soft reset:
      - Keep fix_history as an audit log
      - Start a new context window (ignore prior entries as context)
      - Clear investigation scratchpads/last walkthrough
    """
    history = state.get("fix_history", [])
    history_len = len(history) if isinstance(history, list) else 0
    state["assistant_context_start_idx"] = history_len
    state["reporter_scratchpad"] = ""
    state["investigation_report"] = ""
    state["last_fix_walkthrough"] = ""
    state["last_resolution_type"] = ""
    state["last_user_goal"] = ""
    state = _clear_pending_clarification(state)
    state["pending_workspace_decision"] = {
        "active": False,
        "original_prompt": "",
        "proposed_subdir": "",
        "mode": "",
        "image_urls": [],
        "command_hint": "",
        "requested_at_utc": "",
    }
    return state


def _format_soft_reset_message(state: dict) -> str:
    history_len = len(state.get("fix_history") or [])
    start_idx = int(state.get("assistant_context_start_idx", 0) or 0)
    return (
        "OK: Assistant context reset (soft). "
        f"History kept: {history_len} message(s). New context starts at index {start_idx}."
    )


def _empty_pending_clarification() -> dict:
    return {
        "active": False,
        "question": "",
        "reason": "",
        "requested_at_utc": "",
        "last_report": "",
    }


def _clear_pending_clarification(state: dict) -> dict:
    state["pending_clarification"] = _empty_pending_clarification()
    return state


def _normalize_checked_files(raw_checked_files) -> list[str]:
    if isinstance(raw_checked_files, str):
        items = [raw_checked_files]
    elif isinstance(raw_checked_files, list):
        items = raw_checked_files
    else:
        return []

    normalized: list[str] = []
    seen: set[str] = set()
    for item in items:
        value = str(item or "").strip()
        if not value or value in seen:
            continue
        seen.add(value)
        normalized.append(value)
    return normalized


def _format_checked_files_line(checked_files: list[str], max_items: int = 6) -> str:
    if not checked_files:
        return ""
    preview = ", ".join(checked_files[:max_items])
    if len(checked_files) > max_items:
        preview += f", +{len(checked_files) - max_items} more"
    return f"What I checked: {preview}"


def _build_follow_up_investigation_prompt(state: dict, user_message: str) -> tuple[str, str]:
    pending = state.get("pending_clarification", {})
    if not isinstance(pending, dict) or not pending.get("active"):
        return user_message, user_message

    prior_goal = str(state.get("last_user_goal") or "").strip()
    question = str(pending.get("question") or "").strip()
    reason = str(pending.get("reason") or "").strip()

    lines = [
        "FOLLOW-UP CONTEXT: The user is replying to a prior clarification request for the same unresolved task.",
    ]
    if prior_goal:
        lines.append(f"Original unresolved goal: {prior_goal}")
    if question:
        lines.append(f"Clarification requested: {question}")
    if reason:
        lines.append(f"Why clarification was needed: {reason}")
    lines.append(f"Latest user reply: {user_message}")
    lines.append("Treat this reply as additional information for the original unresolved goal.")
    return "\n".join(lines), prior_goal or user_message


def _format_no_code_response(
    resolution_type: str,
    message: str,
    checked_files: list[str],
    clarification_reason: str = "",
) -> str:
    cleaned_message = (message or "").strip() or "No additional details were returned."
    parts = [cleaned_message]
    checked_line = _format_checked_files_line(checked_files)
    lowered_message = cleaned_message.lower()

    if resolution_type == "need_more_info":
        reason = (clarification_reason or "").strip()
        if reason and "why i need it:" not in lowered_message:
            parts.extend(["", f"Why I need it: {reason}"])
    if checked_line and "what i checked:" not in lowered_message:
        parts.extend(["", checked_line])
    return "\n".join(parts)


def _recent_non_casual_history_summary(state: dict, max_items: int = 3) -> str:
    entries = _normalize_fix_history(state.get("fix_history", []))
    collected: list[str] = []
    for entry in reversed(entries):
        if not isinstance(entry, dict):
            continue
        context_scope = str(entry.get("context_scope") or entry.get("intent") or "").strip().lower()
        if context_scope == "casual_chat":
            continue
        prompt = _truncate_state_text(str(entry.get("prompt") or "").strip(), limit=140)
        outcome = _truncate_state_text(str(entry.get("outcome") or "").strip(), limit=220)
        if not prompt and not outcome:
            continue
        parts = []
        if prompt:
            parts.append(f"User: {prompt}")
        if outcome:
            parts.append(f"Assistant: {outcome}")
        collected.append(" | ".join(parts))
        if len(collected) >= max_items:
            break
    collected.reverse()
    return "\n".join(f"- {item}" for item in collected)


def _build_casual_chat_fallback_response(user_message: str, state: dict) -> str:
    norm = _normalize_intent_text(user_message)
    pending = state.get("pending_clarification", {}) if isinstance(state.get("pending_clarification"), dict) else {}
    pending_active = bool(pending.get("active"))
    pending_question = str(pending.get("question") or "").strip()
    if any(token in norm for token in ("thank", "thanks", "thankyou", "thx")) or _is_closure_message(user_message):
        message = "Happy to help."
        if pending_active and pending_question:
            return f"{message} Whenever you're ready, send {pending_question.lower()}."
        return f"{message} If you want, we can keep going from here."
    if any(token in norm for token in ("how are you", "how's it going", "hows it going", "what's up", "whats up")):
        return "Doing well. I'm ready whenever you want to keep going."
    if any(token in norm for token in ("bye", "goodbye", "see you", "talk soon", "catch you later")):
        return "See you soon. I'll be here when you want to continue."
    if any(token in norm for token in ("hi", "hello", "hey", "good morning", "good afternoon", "good evening")):
        return "Hi! I'm Nexcode Agent. What would you like to work on?"
    return "I'm here. Tell me what you'd like to work on next."


def _emit_workspace_routing_trace(verbose: bool, source: str, route: str, intent: str = "", action_kind: str = "") -> None:
    if not verbose:
        return
    final_route = intent if route == "assistant" and intent else route
    console.print(ui_detail("Routing source", source))
    console.print(ui_detail("Final route", final_route))
    if route == "execution_request" and action_kind:
        console.print(ui_detail("Execution action", action_kind))


def _normalize_assistant_intent_mode(raw_mode: str) -> str:
    mode = str(raw_mode or "").strip().lower()
    return mode if mode in _ASSISTANT_INTENT_MODES else "conservative"


def _normalize_assistant_routing_strategy(raw_strategy: str) -> str:
    strategy = str(raw_strategy or "").strip().lower()
    return strategy if strategy in _ASSISTANT_ROUTING_STRATEGIES else "heuristic"


def _normalize_intent_text(text: str) -> str:
    return re.sub(r"\s+", " ", str(text or "").strip().lower())


def _clean_intent_clause(text: str) -> str:
    cleaned = str(text or "").strip().strip(",;:-")
    return re.sub(r"^(?:and|also|then)\s+", "", cleaned, flags=re.IGNORECASE).strip()


def _contains_bug_signal(text: str) -> bool:
    norm = f" {_normalize_intent_text(text)} "
    return any(token in norm for token in _BUG_HINTS)


def _has_useful_action_target(rest: str) -> bool:
    tokens = [
        token
        for token in re.findall(r"[a-z0-9']+", _normalize_intent_text(rest))
        if token not in {"please", "the", "a", "an", "to", "and", "also", "then", "me", "you", "us"}
    ]
    if not tokens:
        return False
    if len(tokens) == 1 and tokens[0] in {"it", "this", "that", "something", "things", "stuff", "more"}:
        return False
    return True


def _is_consult_request(text: str) -> bool:
    clause = _clean_intent_clause(text)
    norm = _normalize_intent_text(clause)
    if not norm:
        return False
    if _IMPLEMENTATION_LEAD_RE.match(norm):
        return False
    if any(hint in norm for hint in _CONSULT_HINTS):
        return True
    return norm.startswith(
        (
            "what else ",
            "what should ",
            "what can ",
            "how can ",
            "how should ",
            "should we ",
            "do you think ",
            "is this okay",
            "is this good",
            "can you explain",
            "could you explain",
            "why is ",
        )
    )


def _is_review_request(text: str) -> bool:
    norm = _normalize_intent_text(text)
    if not norm:
        return False
    if any(hint in norm for hint in _REVIEW_HINTS):
        return True
    return bool(
        re.search(
            r"\b(review|audit|inspect|explore|analy[sz]e)\b.*\b(codebase|code base|repo|repository|architecture|arch|design|flaws|weakness|issues)\b",
            norm,
        )
    )


def _is_closure_message(text: str) -> bool:
    norm = _normalize_intent_text(text)
    if not norm:
        return False
    if any(hint in norm for hint in _CLOSURE_HINTS):
        return True
    return norm.startswith(("thanks ", "thank you ", "awesome ", "great "))


def _has_casual_chat_actionable_intent(text: str) -> bool:
    cleaned = _clean_intent_clause(text)
    if not cleaned:
        return False
    if _looks_like_path_target(cleaned):
        return True
    if re.search(
        r"\b(?:can|could|would|will|shall)\s+you\b.*\b(?:fix|implement|add|create|update|change|remove|refactor|build|rewrite|make)\b",
        cleaned,
        re.IGNORECASE,
    ):
        return True
    if _detect_followup_target_action(cleaned):
        return True
    if _is_review_request(cleaned) or _looks_like_greenfield_request(cleaned):
        return True
    if _contains_bug_signal(cleaned):
        return True
    if _is_consult_request(cleaned):
        return True
    if _extract_explicit_action_request(cleaned, "conservative"):
        return True
    return False


def _is_casual_chat_message(text: str) -> bool:
    norm = _normalize_intent_text(text)
    if not norm:
        return False
    if _has_casual_chat_actionable_intent(text):
        return False
    if _is_closure_message(text):
        return True
    if any(pattern.match(norm) for pattern in _CASUAL_CHAT_PATTERNS):
        return True
    tokens = re.findall(r"[a-z0-9']+", norm)
    if not tokens or len(tokens) > 8:
        return False
    return all(token in _CASUAL_CHAT_TOKEN_ALLOWLIST for token in tokens)


def _looks_like_greenfield_request(text: str) -> bool:
    norm = _normalize_intent_text(text)
    if not norm:
        return False
    if any(phrase in norm for phrase in ("using my resume", "from scratch", "new app", "new website", "new project")):
        return True
    return bool(
        re.search(
            r"\b(build|create|make|start|scaffold|bootstrap)\b.*\b(portfolio|website|web app|app|project|dashboard|landing page|api|tool|saas)\b",
            norm,
        )
    )


def _is_execution_request(text: str) -> bool:
    return _detect_followup_target_action(text) == "run"


def _detect_followup_target_action(text: str) -> str:
    norm = _normalize_intent_text(text)
    if not norm:
        return ""
    match = _FOLLOWUP_TARGET_ACTION_RE.match(norm)
    if not match:
        return ""
    explicit_target = bool(re.search(r"[\w\-/\\.]+\.\w+", text or ""))
    referential_target = any(
        hint in norm
        for hint in _REFERENTIAL_TARGET_HINTS
    )
    if not explicit_target and not referential_target:
        return ""
    verb = str(match.group("verb") or "").strip().lower()
    if verb in {"execute", "launch", "start"}:
        return "run"
    return verb


def _looks_like_path_target(text: str) -> bool:
    return bool(re.search(r"[\w\-/\\.]+\.\w+", str(text or "")))


def _normalize_recent_target_entries(raw_entries) -> list[dict]:
    normalized: list[dict] = []
    if not isinstance(raw_entries, list):
        return normalized
    for entry in raw_entries:
        if not isinstance(entry, dict):
            continue
        path = str(entry.get("path") or "").strip().replace("\\", "/").lstrip("./").rstrip("/")
        if not path:
            continue
        normalized.append(
            {
                "path": path,
                "kind": str(entry.get("kind") or "").strip().lower(),
                "role": str(entry.get("role") or "").strip().lower(),
                "source": str(entry.get("source") or "").strip().lower(),
                "recorded_at_utc": str(entry.get("recorded_at_utc") or "").strip(),
            }
        )
    return normalized


def _target_exists_in_workspace(workspace_path: Path, rel_path: str, kind: str = "") -> bool:
    from nexcode.agent_runtime.workspace import get_project_root

    normalized = str(rel_path or "").strip().replace("\\", "/").lstrip("./").rstrip("/")
    if not normalized:
        return False
    candidate = (get_project_root(workspace_path).resolve() / normalized).resolve()
    if not candidate.exists():
        return False
    if kind == "file":
        return candidate.is_file()
    if kind == "dir":
        return candidate.is_dir()
    return True


def _path_kind_in_workspace(workspace_path: Path, rel_path: str) -> str:
    from nexcode.agent_runtime.workspace import get_project_root

    normalized = str(rel_path or "").strip().replace("\\", "/").lstrip("./").rstrip("/")
    if not normalized:
        return ""
    candidate = (get_project_root(workspace_path).resolve() / normalized).resolve()
    if candidate.is_dir():
        return "dir"
    if candidate.is_file():
        return "file"
    return ""


def _recent_target_score(entry: dict, action_kind: str, idx: int, message_norm: str, last_execution: dict) -> int:
    score = max(20, 82 - (idx * 4))
    kind = str(entry.get("kind") or "").strip().lower()
    role = str(entry.get("role") or "").strip().lower()
    path = str(entry.get("path") or "").strip()

    if action_kind == "run":
        score += 20 if kind == "file" else -20
    elif action_kind in {"build", "test"}:
        score += 22 if kind == "dir" else -8
    elif action_kind == "open":
        score += 10

    if role == "executed":
        score += 16 if action_kind in {"run", "test"} else 8
    elif role in {"created", "edited"}:
        score += 14 if action_kind == "run" else 10
    elif role == "planned":
        score += 12 if action_kind in {"build", "test"} else 5
    elif role == "checked":
        score += 6

    if path and path == str(last_execution.get("target_file") or "").strip():
        score += 18

    if "that file" in message_norm or "this file" in message_norm:
        score += 10 if kind == "file" else -8
    if "that app" in message_norm or "this app" in message_norm or "that project" in message_norm or "this project" in message_norm:
        score += 10 if kind == "dir" else -6
    if "the app we just made" in message_norm or "the project we just made" in message_norm:
        score += 14 if kind == "dir" else -8
    if "summarize" in message_norm or "output" in message_norm:
        score += 6 if action_kind == "run" else 0

    return score


def _resolve_followup_target_candidate(workspace_path: Path, user_message: str, action_kind: str) -> tuple[dict | None, list[dict]]:
    from nexcode.agent_runtime.workspace import get_project_root, load_agent_state

    state = load_agent_state(workspace_path)
    project_root = get_project_root(workspace_path).resolve()
    message = str(user_message or "")
    message_norm = _normalize_intent_text(message)
    scored: list[dict] = []
    seen: set[str] = set()

    explicit_mentions = []
    for raw_match in re.findall(r"[\w\-/\\.]+\.\w+", message):
        normalized = str(Path(raw_match).as_posix()).lstrip("./")
        if not normalized or normalized in seen or not _target_exists_in_workspace(workspace_path, normalized):
            continue
        explicit_mentions.append(
            {
                "path": normalized.rstrip("/"),
                "kind": _path_kind_in_workspace(workspace_path, normalized),
                "role": "explicit",
                "source": "message",
                "score": 100,
            }
        )
        seen.add(normalized.rstrip("/"))

    if explicit_mentions:
        return explicit_mentions[0], explicit_mentions

    last_execution = state.get("last_execution", {}) if isinstance(state.get("last_execution"), dict) else {}
    last_exec_target = str(last_execution.get("target_file") or "").strip()
    if last_exec_target and _target_exists_in_workspace(workspace_path, last_exec_target):
        entry = {
            "path": last_exec_target.rstrip("/"),
            "kind": _path_kind_in_workspace(workspace_path, last_exec_target),
            "role": "executed",
            "source": "last_execution",
            "score": 92 if action_kind == "run" else 82,
        }
        scored.append(entry)
        seen.add(entry["path"])

    last_exec_cwd = str(last_execution.get("cwd") or "").strip().replace("\\", "/").rstrip("/")
    if action_kind in {"build", "test"} and last_exec_cwd and last_exec_cwd not in {"", "."} and _target_exists_in_workspace(workspace_path, last_exec_cwd, kind="dir"):
        if last_exec_cwd not in seen:
            scored.append(
                {
                    "path": last_exec_cwd,
                    "kind": "dir",
                    "role": "executed",
                    "source": "last_execution_cwd",
                    "score": 90,
                }
            )
            seen.add(last_exec_cwd)

    for idx, entry in enumerate(_normalize_recent_target_entries(state.get("recent_targets"))):
        path = entry["path"]
        if path in seen or not _target_exists_in_workspace(workspace_path, path, kind=entry.get("kind") or ""):
            continue
        scored.append(
            {
                **entry,
                "kind": entry.get("kind") or _path_kind_in_workspace(workspace_path, path),
                "score": _recent_target_score(entry, action_kind, idx, message_norm, last_execution),
            }
        )
        seen.add(path)

    for idx, rel_path in enumerate(_normalize_checked_files(state.get("investigation_checked_files"))):
        normalized = rel_path.rstrip("/")
        if not normalized or normalized in seen or not _target_exists_in_workspace(workspace_path, normalized):
            continue
        kind = _path_kind_in_workspace(workspace_path, normalized)
        scored.append(
            {
                "path": normalized,
                "kind": kind,
                "role": "checked",
                "source": "investigation_checked_files",
                "score": max(40, 68 - idx * 3) + (10 if action_kind == "run" and kind == "file" else 0),
            }
        )
        seen.add(normalized)

    scored.sort(key=lambda item: (-int(item.get("score", 0)), item.get("path", "")))
    if not scored:
        return None, []

    top = scored[0]
    second_score = int(scored[1].get("score", 0)) if len(scored) > 1 else -999
    if int(top.get("score", 0)) >= 70 and (len(scored) == 1 or int(top.get("score", 0)) - second_score >= 20):
        return top, scored
    return None, scored


def _format_followup_target_clarification(action_kind: str, candidates: list[dict]) -> str:
    action = {"run": "run", "test": "test", "build": "build", "open": "open"}.get(action_kind, "use")
    lines = [f"I found more than one likely target for `{action}`. Tell me which one you want:"]
    for candidate in candidates[:3]:
        label = candidate.get("path", "")
        kind = candidate.get("kind") or "target"
        source = candidate.get("source") or "recent context"
        lines.append(f"- `{label}` ({kind}, from {source})")
    return "\n".join(lines)


def _derive_subproject_slug(prompt: str, workspace_path: Path) -> str:
    lowered = _normalize_intent_text(prompt)
    if "portfolio" in lowered:
        base = "portfolio-site"
    elif "dashboard" in lowered:
        base = "dashboard-app"
    elif "landing page" in lowered:
        base = "landing-page"
    elif "docs" in lowered or "documentation" in lowered:
        base = "docs-site"
    elif "api" in lowered:
        base = "api-service"
    else:
        words = re.findall(r"[a-z0-9]+", lowered)
        filtered = [word for word in words if word not in {"build", "create", "make", "me", "please", "can", "you", "using", "with", "for", "new", "app", "project", "website"}]
        base = "-".join(filtered[:3]) or "new-app"

    from nexcode.agent_runtime.workspace import get_project_root

    project_root = get_project_root(workspace_path).resolve()
    candidate = base
    suffix = 2
    while (project_root / candidate).exists():
        candidate = f"{base}-{suffix}"
        suffix += 1
    return candidate


def _collect_plan_target_paths(plan: list[dict]) -> list[str]:
    paths: list[str] = []
    for item in plan or []:
        for entry in item.get("files", []) or []:
            normalized = str(entry or "").strip().replace("\\", "/").lstrip("./").rstrip("/")
            if normalized and normalized not in paths:
                paths.append(normalized)
    return paths


def _inspect_workspace_root(workspace_path: Path) -> dict:
    meaningful_entries: list[str] = []
    metadata_entries: list[str] = []

    try:
        children = sorted(workspace_path.iterdir(), key=lambda item: item.name.lower())
    except Exception:
        children = []

    for child in children:
        name = child.name
        lower = name.lower()
        if child.is_dir():
            if lower in _METADATA_ONLY_DIRS:
                metadata_entries.append(name)
                continue
            meaningful_entries.append(name)
            continue
        if lower in _METADATA_ONLY_FILES or lower.startswith(".env"):
            metadata_entries.append(name)
            continue
        meaningful_entries.append(name)

    return {
        "meaningful_entries": meaningful_entries,
        "metadata_entries": metadata_entries,
        "is_empty": not meaningful_entries and not metadata_entries,
        "is_metadata_only": not meaningful_entries and bool(metadata_entries),
        "has_meaningful_content": bool(meaningful_entries),
    }


def _extract_explicit_action_request(text: str, mode: str) -> str:
    clause = _clean_intent_clause(text)
    norm = _normalize_intent_text(clause)
    if not norm:
        return ""
    if _contains_bug_signal(clause):
        return clause
    if _is_consult_request(clause) and not _IMPLEMENTATION_LEAD_RE.match(norm):
        return ""

    lead_match = _IMPLEMENTATION_LEAD_RE.match(norm)
    if lead_match and _has_useful_action_target(lead_match.group("rest")):
        return clause

    inline_match = _IMPLEMENTATION_INLINE_RE.search(norm)
    if not inline_match or not _has_useful_action_target(inline_match.group("rest")):
        return ""
    if mode == "balanced":
        return clause
    if inline_match.start() == 0 or inline_match.group("verb").lower() == "make":
        return clause
    return ""


def _split_mixed_consult_and_action(text: str, mode: str) -> tuple[str, str]:
    cleaned = str(text or "").strip()
    if not _is_consult_request(cleaned):
        return "", ""
    match = _FOLLOWUP_ACTION_RE.match(cleaned)
    if not match:
        return "", ""
    consult_part = _clean_intent_clause(match.group("lead"))
    action_part = _clean_intent_clause(match.group("action"))
    if not consult_part or not action_part:
        return "", ""
    if not _is_consult_request(consult_part):
        return "", ""
    if not _extract_explicit_action_request(action_part, mode):
        return "", ""
    return consult_part, action_part


def _split_intent_clauses(text: str) -> list[str]:
    raw = re.split(r"(?:[\n\r]+|[.;?!]+|,\s*)", str(text or ""))
    return [clause for clause in (_clean_intent_clause(item) for item in raw) if clause]


def _classify_assistant_intent_with_model(message: str, mode: str, workspace_path: Path | None = None) -> dict | None:
    try:
        from nexcode.config import load_access, load_agent_config
        from nexcode.agent_runtime.executor import extract_json
        from nexcode.agent_runtime.planner import _call_gateway

        acc = load_access()
        if not acc.get("api_key"):
            return None
        agent_cfg = load_agent_config(workspace_path)
        classifier_prompt = (
            "Classify the user's latest assistant request.\n"
            f"assistant_intent_mode={mode}\n\n"
            "Return strict JSON only in this shape:\n"
            '{"intent":"consult_only|implementation|mixed","consult_request":"","implementation_request":"","reason":""}\n\n'
            "Definitions:\n"
            "- consult_only: suggestions, ideas, questions, doubts, evaluation, brainstorming, or explanation with no authorization to edit code.\n"
            "- implementation: the user explicitly asks to change code, add a feature, fix a bug, or modify the repo.\n"
            "- mixed: both consult intent and implementation intent are present.\n\n"
            "Rules:\n"
            '- "can you add testimonials?" => implementation\n'
            '- "what else can we add?" => consult_only\n'
            "- If mixed, extract the consult part and the implementation part separately.\n\n"
            f"User message:\n{message}"
        )
        response, _usage = _call_gateway(
            acc["api_key"],
            acc["endpoint"],
            agent_cfg["model"],
            "You are a strict intent classifier. Return JSON only.",
            classifier_prompt,
            json_mode=False,
        )
        parsed = extract_json(response)
        if not isinstance(parsed, dict):
            return None
        intent = str(parsed.get("intent") or "").strip()
        if intent not in {"consult_only", "implementation", "mixed"}:
            return None
        return {
            "intent": intent,
            "consult_request": str(parsed.get("consult_request") or "").strip(),
            "implementation_request": str(parsed.get("implementation_request") or "").strip(),
            "reason": str(parsed.get("reason") or "model_classifier").strip() or "model_classifier",
        }
    except Exception:
        return None


def _classify_assistant_intent_heuristically(message: str, mode: str) -> dict:
    normalized_mode = _normalize_assistant_intent_mode(mode)
    cleaned_message = str(message or "").strip()
    consult_part, action_part = _split_mixed_consult_and_action(cleaned_message, normalized_mode)
    if consult_part and action_part:
        return {
            "intent": "mixed",
            "consult_request": consult_part,
            "implementation_request": action_part,
            "reason": "heuristic_mixed",
        }

    clauses = _split_intent_clauses(cleaned_message) or [cleaned_message]
    consult_clauses: list[str] = []
    implementation_clauses: list[str] = []
    for clause in clauses:
        action_request = _extract_explicit_action_request(clause, normalized_mode)
        if action_request:
            implementation_clauses.append(action_request)
            continue
        if _is_consult_request(clause):
            consult_clauses.append(clause)

    if consult_clauses and implementation_clauses:
        return {
            "intent": "mixed",
            "consult_request": " ".join(consult_clauses).strip(),
            "implementation_request": " ".join(implementation_clauses).strip(),
            "reason": "heuristic_split",
        }
    if implementation_clauses:
        return {
            "intent": "implementation",
            "consult_request": "",
            "implementation_request": cleaned_message,
            "reason": "heuristic_implementation",
        }
    if consult_clauses:
        return {
            "intent": "consult_only",
            "consult_request": cleaned_message,
            "implementation_request": "",
            "reason": "heuristic_consult",
        }

    return {
        "intent": "consult_only",
        "consult_request": cleaned_message,
        "implementation_request": "",
        "reason": "heuristic_fallback",
    }


def _classify_assistant_intent(message: str, mode: str, workspace_path: Path | None = None) -> dict:
    normalized_mode = _normalize_assistant_intent_mode(mode)
    cleaned_message = str(message or "").strip()
    model_result = _classify_assistant_intent_with_model(cleaned_message, normalized_mode, workspace_path)
    if model_result:
        return model_result
    return _classify_assistant_intent_heuristically(cleaned_message, normalized_mode)


def _normalize_workspace_route_decision(parsed: dict | None) -> dict | None:
    if not isinstance(parsed, dict):
        return None

    route = str(parsed.get("route") or "").strip().lower()
    if route not in _WORKSPACE_ROUTE_KINDS:
        return None

    intent = str(parsed.get("intent") or "").strip()
    if route == "assistant":
        if intent not in {"consult_only", "implementation", "mixed"}:
            return None
    else:
        intent = ""

    action_kind = str(parsed.get("action_kind") or "").strip().lower()
    if route == "execution_request":
        if action_kind not in _EXECUTION_ACTION_KINDS:
            return None
    else:
        action_kind = ""

    consult_request = str(parsed.get("consult_request") or "").strip()
    implementation_request = str(parsed.get("implementation_request") or "").strip()
    if route != "assistant":
        consult_request = ""
        implementation_request = ""

    return {
        "route": route,
        "intent": intent,
        "consult_request": consult_request,
        "implementation_request": implementation_request,
        "action_kind": action_kind,
        "target_hint": str(parsed.get("target_hint") or "").strip(),
        "reason": str(parsed.get("reason") or "").strip() or "model_route_classifier",
    }


def _classify_workspace_route_with_model(message: str, mode: str, workspace_path: Path | None = None) -> dict | None:
    try:
        from nexcode.config import load_access, load_agent_config
        from nexcode.agent_runtime.executor import extract_json
        from nexcode.agent_runtime.planner import _call_gateway

        cleaned_message = str(message or "").strip()
        acc = load_access()
        if not acc.get("api_key"):
            return None
        agent_cfg = load_agent_config(workspace_path)
        classifier_prompt = (
            "Classify the user's latest current-workspace request.\n"
            f"assistant_intent_mode={mode}\n\n"
            "Return strict JSON only in this shape:\n"
            '{"route":"casual_chat|review_only|assistant|execution_request","intent":"consult_only|implementation|mixed|","consult_request":"","implementation_request":"","action_kind":"run|build|test|open|","target_hint":"","reason":""}\n\n'
            "Definitions:\n"
            "- casual_chat: greeting, gratitude, acknowledgement, closure, or small talk only.\n"
            "- review_only: analyze or inspect the current repo/architecture with no code changes requested.\n"
            "- execution_request: the user wants to run, test, build, or open an existing file or project target.\n"
            "- assistant: every other natural-language request; include the assistant intent fields when you choose this route.\n\n"
            "Rules:\n"
            "- Never invent or suggest shell commands.\n"
            "- Use execution_request only when the user's intent is to run/test/build/open something. Put only the action kind, not a command.\n"
            "- If the target is unclear, target_hint may be empty.\n"
            "- If route=assistant, intent must be consult_only, implementation, or mixed.\n"
            '- "hi" => casual_chat\n'
            '- "please inspect the repo architecture" => review_only\n'
            '- "run test.py and show output" => execution_request with action_kind="run"\n'
            '- "what else can we add?" => assistant + consult_only\n'
            '- "fix the navbar overlap" => assistant + implementation\n'
            '- "what else can we add, and also fix mobile" => assistant + mixed\n\n'
            f"User message:\n{cleaned_message}"
        )
        response, _usage = _call_gateway(
            acc["api_key"],
            acc["endpoint"],
            agent_cfg["model"],
            "You are a strict workspace routing classifier. Return JSON only.",
            classifier_prompt,
            json_mode=False,
        )
        parsed = extract_json(response)
        normalized = _normalize_workspace_route_decision(parsed)
        if not normalized:
            return None
        if normalized["route"] == "assistant":
            if normalized["intent"] in {"consult_only", "mixed"} and not normalized["consult_request"]:
                normalized["consult_request"] = cleaned_message
            if normalized["intent"] in {"implementation", "mixed"} and not normalized["implementation_request"]:
                normalized["implementation_request"] = cleaned_message
        return normalized
    except Exception:
        return None


def _classify_greenfield_workspace_decision(
    user_message: str,
    workspace_info: dict,
    mode: str,
    workspace_path: "Path | None" = None,
) -> str:
    """
    Ask the AI whether a greenfield-looking request in a non-empty workspace should be:
      - "integrate"       → work into the existing project
      - "separate"        → create a new subfolder for the new app
      - "existing_project"→ this is NOT a build request (e.g. analysis/exploration); skip greenfield path

    Falls back to "integrate" on any error so we never block the user.
    """
    try:
        from nexcode.config import load_access, load_agent_config
        from nexcode.agent_runtime.executor import extract_json
        from nexcode.agent_runtime.planner import _call_gateway

        cleaned_message = str(user_message or "").strip()
        entries = list(workspace_info.get("meaningful_entries") or [])[:8]
        files_preview = ", ".join(entries) if entries else "(none)"

        acc = load_access()
        if not acc.get("api_key"):
            return "integrate"

        agent_cfg = load_agent_config(workspace_path)
        classifier_prompt = (
            "You are helping an autonomous coding agent decide how to handle a user request.\n\n"
            f"The workspace already contains these files/dirs: {files_preview}\n\n"
            f"User message: {cleaned_message}\n\n"
            "Decide the correct handling strategy. Return strict JSON only:\n"
            '{"decision":"integrate|separate|existing_project","reason":""}\n\n'
            "Definitions:\n"
            "- integrate: the user wants to build/add something NEW that should go into the existing project.\n"
            "- separate: the user wants to build a completely different new app that should live in its own subfolder.\n"
            "- existing_project: the user is asking about, exploring, analyzing, fixing, or working on the EXISTING project — NOT requesting a new separate build.\n\n"
            "Rules:\n"
            "- Prefer 'existing_project' when the message is about understanding, reviewing, fixing, or improving what already exists.\n"
            "- Prefer 'integrate' when the user wants to add a new feature/module to the current project.\n"
            "- Prefer 'separate' ONLY when the request is clearly for a standalone new app unrelated to existing files.\n"
            "- When in doubt, choose 'existing_project'.\n\n"
            "Examples:\n"
            '- "can you tell me how this project works" => existing_project\n'
            '- "explore the codebase and find what we can build further" => existing_project\n'
            '- "add a user dashboard to the existing app" => integrate\n'
            '- "build me a completely separate portfolio website" => separate\n'
        )
        response, _usage = _call_gateway(
            acc["api_key"],
            acc["endpoint"],
            agent_cfg["model"],
            "You are a strict workspace strategy classifier. Return JSON only.",
            classifier_prompt,
            json_mode=False,
        )
        parsed = extract_json(response)
        if not isinstance(parsed, dict):
            return "integrate"
        decision = str(parsed.get("decision") or "").strip().lower()
        if decision in {"integrate", "separate", "existing_project"}:
            return decision
        return "integrate"
    except Exception:
        return "integrate"


def _classify_workspace_route_heuristically(message: str, mode: str) -> dict:
    cleaned_message = str(message or "").strip()
    followup_action = _detect_followup_target_action(cleaned_message)
    if followup_action in _EXECUTION_ACTION_KINDS:
        return {
            "route": "execution_request",
            "intent": "",
            "consult_request": "",
            "implementation_request": "",
            "action_kind": followup_action,
            "target_hint": "",
            "reason": "heuristic_execution",
        }
    if _is_review_request(cleaned_message):
        return {
            "route": "review_only",
            "intent": "",
            "consult_request": "",
            "implementation_request": "",
            "action_kind": "",
            "target_hint": "",
            "reason": "heuristic_review",
        }
    if _is_casual_chat_message(cleaned_message):
        return {
            "route": "casual_chat",
            "intent": "",
            "consult_request": "",
            "implementation_request": "",
            "action_kind": "",
            "target_hint": "",
            "reason": "heuristic_casual_chat",
        }
    intent_decision = _classify_assistant_intent_heuristically(cleaned_message, mode)
    return {
        "route": "assistant",
        "intent": str(intent_decision.get("intent") or "").strip(),
        "consult_request": str(intent_decision.get("consult_request") or "").strip(),
        "implementation_request": str(intent_decision.get("implementation_request") or "").strip(),
        "action_kind": "",
        "target_hint": "",
        "reason": str(intent_decision.get("reason") or "heuristic_assistant").strip() or "heuristic_assistant",
    }


def _coerce_consult_investigation_result(result: dict) -> dict:
    normalized = dict(result or {})
    if str(normalized.get("resolution_type") or "").strip() != "code_change":
        return normalized
    fallback = str(normalized.get("user_instructions") or normalized.get("report") or "").strip()
    if not fallback:
        fallback = "I reviewed the codebase and prepared recommendations, but no code changes were executed."
    normalized["is_question"] = True
    normalized["resolution_type"] = "answer_only"
    normalized["user_instructions"] = fallback
    normalized["report"] = fallback
    normalized["needs_plan_preview"] = False
    return normalized


def _build_mixed_response(suggestions: str, implementation_update: str) -> str:
    suggestions = str(suggestions or "").strip() or "No suggestions were generated."
    implementation_update = str(implementation_update or "").strip() or "No implementation update was generated."
    return f"Suggestions:\n{suggestions}\n\nImplementation update:\n{implementation_update}"


def _user_requested_preventative_fix(text: str) -> bool:
    t = (text or "").lower()
    return any(token in t for token in ("prevent", "permanent", "automate", "always", "never again", "predev", "script"))


def _reporter_message_has_implementation_cues(text: str) -> bool:
    lowered = str(text or "").strip().lower()
    if not lowered:
        return False
    cues = (
        "```",
        "create a new file",
        "create a python file",
        "new file named",
        "the file should contain",
        "put this code in",
        "exact code to put",
        "save this as",
        "write the following code",
        "here is the exact code",
        "replace the contents",
        "add this code",
        "create `",
        "named `",
    )
    return any(cue in lowered for cue in cues)


def _reporter_message_says_already_satisfied(text: str) -> bool:
    lowered = str(text or "").strip().lower()
    if not lowered:
        return False
    satisfied_markers = (
        "already implemented",
        "already fixed",
        "already correct",
        "already exists",
        "already handled",
        "already wired",
        "already in place",
        "no code changes needed",
        "no changes needed",
        "this behavior is already",
    )
    if any(marker in lowered for marker in satisfied_markers):
        return True
    return "how to verify:" in lowered and "already" in lowered


def _should_force_code_change(user_message: str, implementation_request: str, normalized_result: dict) -> tuple[bool, str]:
    resolution_type = str(normalized_result.get("resolution_type") or "").strip()
    if resolution_type in {"code_change", "need_more_info", "answer_only", "user_action_only"}:
        return False, ""
    if not str(normalized_result.get("report") or normalized_result.get("report_text") or normalized_result.get("routed_message") or "").strip():
        action_text = (
            _extract_explicit_action_request(implementation_request or "", "conservative")
            or _extract_explicit_action_request(user_message or "", "conservative")
        )
        if action_text:
            return True, "reporter output was malformed; preserving explicit implementation request"
    return False, ""


def _record_assistant_timing_event(
    workspace_path,
    project_name: str,
    prompt: str,
    resolution_type: str,
    turn_started_at_iso: str,
    total_s: float,
    inv_s: float,
    plan_s: float = 0.0,
    exec_s: float = 0.0,
    summary_s: float = 0.0,
    complexity: str = "",
    confidence: str = "",
    context_scope: str = "",
    checked_files: list[str] | None = None,
    command: str = "",
    exit_code: int | None = None,
) -> None:
    try:
        from nexcode.agent_runtime.workspace import load_agent_state, save_agent_state

        state = load_agent_state(workspace_path)
        event = {
            "kind": "assistant_turn",
            "project": project_name,
            "prompt": prompt[:5000],
            "resolution_type": resolution_type,
            "started_at_utc": turn_started_at_iso,
            "ended_at_utc": _utc_now_iso(),
            "durations_sec": {
                "total": round(total_s, 3),
                "investigation": round(inv_s, 3),
                "planning": round(plan_s, 3),
                "execution": round(exec_s, 3),
                "summary": round(summary_s, 3),
            },
        }
        if complexity:
            event["complexity"] = complexity
        if confidence:
            event["confidence"] = confidence
        if context_scope:
            event["context_scope"] = context_scope
        if checked_files:
            event["checked_files"] = [str(path).strip() for path in checked_files if str(path).strip()]
        if command:
            event["command"] = str(command).strip()
        if exit_code is not None:
            event["exit_code"] = int(exit_code)
        state = _append_timing_event(state, event)
        save_agent_state(workspace_path, state)
    except Exception:
        pass


def _run_code_change_turn(
    workspace_path,
    project_name: str,
    user_message: str,
    implementation_request: str,
    current_user_goal: str,
    verbose: bool,
    image_urls: list[str] | None,
    orig_prompt: str,
    fix_history_context: list,
    investigation_result: dict,
    turn_started_at_iso: str,
    turn_t0: float,
    inv_s: float,
    response_prefix: str = "",
) -> None:
    from rich.table import Table

    from nexcode.agent_runtime.executor import execute_plan
    from nexcode.agent_runtime.planner import generate_plan
    from nexcode.agent_runtime.workspace import (
        get_agent_artifacts_dir,
        load_agent_state,
        record_recent_targets,
        save_agent_state,
    )

    resolution_type = str(investigation_result.get("resolution_type") or "code_change").strip()
    complexity = str(investigation_result.get("complexity") or "simple").strip().lower()
    if complexity not in {"simple", "complex"}:
        complexity = "simple"
    confidence = str(investigation_result.get("confidence") or "medium").strip().lower()
    if confidence not in {"low", "medium", "high"}:
        confidence = "medium"
    checked_files = _normalize_checked_files(investigation_result.get("checked_files"))
    needs_plan_preview = bool(investigation_result.get("needs_plan_preview", complexity == "complex"))

    plan_s = exec_s = summary_s = 0.0
    checked_files_block = "\n".join(f"- {path}" for path in checked_files) if checked_files else "- none recorded"
    context_str = f"Investigative Bug Report:\n{investigation_result.get('report')}\n"

    state = load_agent_state(workspace_path)
    state["investigation_report"] = investigation_result.get("report")
    state["reporter_scratchpad"] = str(investigation_result.get("scratchpad") or "").strip()
    state["investigation_checked_files"] = checked_files
    state["investigation_complexity"] = complexity
    state["investigation_confidence"] = confidence
    state["is_fix"] = True
    state["last_resolution_type"] = resolution_type
    state["last_user_goal"] = str(current_user_goal or implementation_request or user_message).strip()
    state = _clear_pending_clarification(state)
    save_agent_state(workspace_path, state)

    full_fix_prompt = (
        f"Primary user goal: '{current_user_goal}'.\n"
        f"Implementation request for this turn: '{implementation_request}'.\n"
        f"Latest user message: '{user_message}'.\n"
        f"Reporter complexity: {complexity}.\n"
        f"Reporter confidence: {confidence}.\n"
        f"Reporter checked files or areas:\n{checked_files_block}\n\n"
        f"{context_str}\n\n"
        "If code changes are required, provide a complete implementation plan for the existing codebase."
    )
    fix_metadata = {
        "complexity": complexity,
        "confidence": confidence,
        "checked_files": checked_files,
        "needs_plan_preview": needs_plan_preview,
        "target_scope": str(investigation_result.get("target_scope") or "").strip(),
        "overwrite_existing": bool(investigation_result.get("overwrite_existing", False)),
        "validation_level": str(investigation_result.get("validation_level") or "").strip(),
        "user_message": str(user_message or "").strip(),
        "implementation_request": str(implementation_request or "").strip(),
        "current_user_goal": str(current_user_goal or "").strip(),
    }

    plan_t0 = time.time()
    fix_plan = generate_plan(
        full_fix_prompt,
        workspace_path,
        verbose=verbose,
        image_urls=image_urls,
        is_fix=True,
        orig_prompt=orig_prompt,
        fix_history=fix_history_context,
        fix_metadata=fix_metadata,
    )
    plan_s = time.time() - plan_t0

    if not fix_plan:
        outcome_summary = "I investigated the request but could not produce a safe implementation plan yet."
        if response_prefix:
            outcome_summary = _build_mixed_response(response_prefix, outcome_summary)
        state = load_agent_state(workspace_path)
        state["last_resolution_type"] = "no_plan"
        if state.get("fix_history") and isinstance(state["fix_history"][-1], dict) and state["fix_history"][-1].get("prompt") == user_message:
            state["fix_history"][-1]["outcome"] = outcome_summary
            state["fix_history"][-1]["resolution_type"] = "no_plan"
            state["fix_history"][-1]["context_scope"] = "implementation"
        save_agent_state(workspace_path, state)
        console.print(ui_status("Planning", "I investigated the request but could not produce a safe implementation plan yet.", tone="warning"))
        console.print("")
        console.print(ui_status("Assistant update", "", tone="success", width=18))
        console.print(outcome_summary)
        total_s = time.time() - turn_t0
        _record_assistant_timing_event(
            workspace_path,
            project_name,
            user_message,
            "no_plan",
            turn_started_at_iso,
            total_s,
            inv_s,
            plan_s=plan_s,
            complexity=complexity,
            confidence=confidence,
        )
        if verbose:
            console.print(ui_timing(f"total={_fmt_duration(total_s)} | investigation={_fmt_duration(inv_s)} | planning={_fmt_duration(plan_s)} | started={turn_started_at_iso}"))
        else:
            console.print(ui_timing(f"done in {_fmt_duration(total_s)}"))
        return

    table = Table(title=f"Assistant Plan | {project_name}", show_header=True, header_style="bold cyan")
    table.add_column("Step", style="dim", width=6, justify="center")
    table.add_column("Task", style="white")

    state = load_agent_state(workspace_path)
    start_step = 1
    if state.get("plan"):
        start_step = state["plan"][-1]["step"] + 1

    for p in fix_plan:
        p["step"] = start_step + (p["step"] - 1)
        table.add_row(str(p["step"]), p["task"])

    if needs_plan_preview:
        console.print(table)
        console.print("")
        console.print(ui_status("Execution", "Applying changes autonomously...", tone="accent"))
        console.print("")
    else:
        console.print("")
        console.print(ui_status("Execution", "Plan ready. Applying the fix autonomously...", tone="accent"))
        console.print("")

    state = load_agent_state(workspace_path)
    state.setdefault("plan", [])
    state["plan"].extend(fix_plan)
    plan_targets = _collect_plan_target_paths(fix_plan)
    if plan_targets:
        state = record_recent_targets(
            state,
            plan_targets,
            role="planned",
            source="plan",
            recorded_at_utc=turn_started_at_iso,
        )
    save_agent_state(workspace_path, state)

    exec_t0 = time.time()
    execute_plan(state["plan"], workspace_path, verbose=verbose)
    exec_s = time.time() - exec_t0

    outcome_summary = ""
    try:
        console.print("")
        console.print(ui_detail("Summary", "Summarizing the outcome for context"))
        summary_t0 = time.time()
        state = load_agent_state(workspace_path)

        relevant_history = []
        step_details = []
        for step in fix_plan:
            s_idx = step["step"]
            task_text = step.get("task", "Unknown Task")
            step_details.append(f"Planned Step {s_idx}: {task_text}")
            relevant_history.extend(state.get(f"coder_history_{s_idx}", []))

        step_list_str = "\n".join(step_details)
        history_blob = "\n".join(relevant_history)
        summarize_req = (
            f"Write the final assistant update for the resolved request.\n\n"
            f"Primary user goal: {current_user_goal}\n"
            f"Implementation request: {implementation_request}\n"
            f"Latest user message: {user_message}\n"
            f"Plan complexity: {complexity}\n"
            f"Original steps planned:\n{step_list_str}\n\n"
            "Return plain text with these sections:\n"
            "What I changed:\n"
            "Why it should work:\n"
            "How to verify:\n"
            "Remaining risk:\n\n"
            "Be concise, concrete, and personal. If there is no meaningful remaining risk, say none noted.\n\n"
            f"Execution Logs:\n{history_blob[:6000000]}"
        )

        from nexcode.config import load_access, load_agent_config
        from nexcode.agent_runtime.planner import _call_gateway
        from nexcode.agent_runtime.token_utils import UsageData

        acc = load_access()
        agent_cfg = load_agent_config(workspace_path)
        outcome_summary, usage = _call_gateway(
            acc["api_key"],
            acc["endpoint"],
            agent_cfg["model"],
            "You are a collaborative senior engineer writing the final user-facing implementation update. Be warm, concise, and concrete.",
            summarize_req,
            json_mode=False,
        )

        if response_prefix:
            outcome_summary = _build_mixed_response(response_prefix, outcome_summary)

        state = load_agent_state(workspace_path)
        state["last_resolution_type"] = resolution_type
        if state.get("fix_history") and isinstance(state["fix_history"][-1], dict) and state["fix_history"][-1].get("prompt") == user_message:
            state["fix_history"][-1]["outcome"] = outcome_summary
            state["fix_history"][-1]["resolution_type"] = resolution_type
            state["fix_history"][-1]["context_scope"] = "implementation"
        state["last_fix_walkthrough"] = outcome_summary

        try:
            artifacts_dir = get_agent_artifacts_dir(workspace_path)
            log_path = artifacts_dir / "WALKTHROUGH.md"
            log_path.parent.mkdir(parents=True, exist_ok=True)
            with open(log_path, "w", encoding="utf-8") as f:
                f.write(f"# High-Fidelity Walkthrough: {user_message}\n\n{outcome_summary}\n")

            dev_log = artifacts_dir / "DEVELOPMENT_LOG.md"
            with open(dev_log, "a", encoding="utf-8") as f:
                f.write(f"\n## ASSISTANT: {user_message}\n\n{outcome_summary}\n\n---\n")
        except Exception:
            pass

        cum_usage = UsageData.from_dict(state.get("cumulative_usage", {}))
        cum_usage.add(usage, model=agent_cfg["model"])
        state["cumulative_usage"] = cum_usage.to_dict()
        save_agent_state(workspace_path, state)
        summary_s = time.time() - summary_t0
    except Exception as e:
        outcome_summary = (
            "What I changed:\n"
            "I completed the planned implementation work, but I could not generate the full assistant summary.\n\n"
            "Why it should work:\n"
            "The executor finished the planned fix path.\n\n"
            "How to verify:\n"
            "Review the changed files and rerun the affected workflow.\n\n"
            "Remaining risk:\n"
            f"Summary generation failed: {e}"
        )
        if response_prefix:
            outcome_summary = _build_mixed_response(response_prefix, outcome_summary)
        console.print(ui_status("Warning", f"Could not summarize outcome: {e}", tone="warning"))
        try:
            state = load_agent_state(workspace_path)
            state["last_resolution_type"] = resolution_type
            if state.get("fix_history") and isinstance(state["fix_history"][-1], dict) and state["fix_history"][-1].get("prompt") == user_message:
                state["fix_history"][-1]["outcome"] = outcome_summary
                state["fix_history"][-1]["resolution_type"] = resolution_type
                state["fix_history"][-1]["context_scope"] = "implementation"
            save_agent_state(workspace_path, state)
        except Exception:
            pass

    console.print("")
    console.print(ui_status("Assistant update", "", tone="success", width=18))
    console.print(outcome_summary)

    total_s = time.time() - turn_t0
    _record_assistant_timing_event(
        workspace_path,
        project_name,
        user_message,
        resolution_type,
        turn_started_at_iso,
        total_s,
        inv_s,
        plan_s=plan_s,
        exec_s=exec_s,
        summary_s=summary_s,
        complexity=complexity,
        confidence=confidence,
    )
    if verbose:
        console.print(
            ui_timing(
                f"total={_fmt_duration(total_s)} | investigation={_fmt_duration(inv_s)} | "
                f"planning={_fmt_duration(plan_s)} | execution={_fmt_duration(exec_s)} | summary={_fmt_duration(summary_s)} | "
                f"started={turn_started_at_iso}"
            )
        )
    else:
        console.print(ui_timing(f"done in {_fmt_duration(total_s)}"))


def _split_first_arg(raw: str) -> tuple[str, str]:
    """
    Split a raw string into (first_arg, remainder). Supports quoted first args.
    Examples:
      '"C:\\a b\\c.png" fix this' -> ('C:\\a b\\c.png', 'fix this')
      'http://x/y.png what is this' -> ('http://x/y.png', 'what is this')
      'C:\\a.png' -> ('C:\\a.png', '')
    """
    s = (raw or "").lstrip()
    if not s:
        return "", ""
    if s[0] in {"\"", "'"}:
        quote = s[0]
        i = 1
        while i < len(s) and s[i] != quote:
            i += 1
        if i >= len(s):
            return s.strip(quote), ""
        first = s[1:i]
        rest = s[i + 1 :].lstrip()
        return first, rest
    parts = s.split(maxsplit=1)
    first = parts[0]
    rest = parts[1].lstrip() if len(parts) > 1 else ""
    return first, rest


def _maybe_compress_fix_history(workspace_path, project_name: str, state: dict) -> dict:
    """
    Compress fix_history when it grows too large to safely inject into Reporter/Planner.
    Preserves assistant reset semantics via assistant_context_start_idx clamping.
    """
    try:
        from nexcode.agent_runtime.token_utils import UsageData, estimate_tokens
        from nexcode.config import load_access, load_agent_config
        from nexcode.agent_runtime.planner import _call_gateway
        from nexcode.agent_runtime.workspace import save_agent_state

        fix_history = state.get("fix_history", [])
        if not isinstance(fix_history, list) or not fix_history:
            return state

        history_text = "\n".join(
            [
                f"Request: {h.get('prompt', 'Unknown')}\nOutcome: {h.get('outcome', 'No summary available.')}"
                for h in fix_history
                if isinstance(h, dict)
            ]
        )

        agent_cfg = load_agent_config(workspace_path)
        history_token_est = estimate_tokens(history_text) if history_text.strip() else 0
        history_threshold = int(agent_cfg.get("fix_history_summary_threshold", 500000))
        if history_token_est <= history_threshold:
            return state

        console.print("[dim]Compressing assistant history (Context threshold reached)...[/dim]")
        acc = load_access()

        orig_prompt = str(state.get("original_prompt", "") or "").strip()
        compress_prompt = (
            "You are a senior technical architect. Below is a detailed history of requests and outcomes for this project.\n\n"
            f"Project name: {project_name}\n"
            f"Original project goal:\n{orig_prompt}\n\n"
            "Your task is to consolidate this history into a dense, high-fidelity technical summary. "
            "Capture the project's evolution, major architectural decisions, and critical bug fixes. "
            "Maintain the most important technical details so a future developer can understand the current state perfectly.\n\n"
            f"History to consolidate:\n{history_text}"
        )
        summary, usage = _call_gateway(
            acc["api_key"],
            acc["endpoint"],
            agent_cfg["model"],
            "You are a senior software architect who writes extremely dense and useful technical summaries. Focus on architecture, logic, and critical fixes. Avoid fluff.",
            compress_prompt,
            json_mode=False,
        )

        state["fix_history"] = [{"prompt": "Fix History (Compressed)", "outcome": summary}]
        _clamp_assistant_context_start(state, len(state["fix_history"]))

        cum_usage = UsageData.from_dict(state.get("cumulative_usage", {}))
        cum_usage.add(usage, model=agent_cfg["model"])
        state["cumulative_usage"] = cum_usage.to_dict()

        save_agent_state(workspace_path, state)
        return state
    except Exception as e:
        console.print(f"[yellow]Failed to compress assistant history: {e}[/yellow]")
        return state


def _legacy_run_assistant_turn_unused(workspace_path, project_name: str, user_message: str, verbose: bool, image_urls: list[str] | None) -> None:
    """
    One assistant turn:
      - Investigate first (Reporter) and route (answer/user_action/need_more_info/code_change)
      - If code_change: plan+execute+summarize
      - Always persist outcomes to agent_state.json
    """
    from nexcode.agent_runtime.workspace import load_agent_state, save_agent_state, get_agent_artifacts_dir
    from nexcode.agent_runtime.planner import generate_plan
    from nexcode.agent_runtime.executor import execute_plan

    turn_started_at_iso = _utc_now_iso()
    turn_t0 = time.time()
    inv_s = plan_s = exec_s = summary_s = 0.0
    resolution_type = "unknown"

    # Load + normalize memory
    state = load_agent_state(workspace_path)
    state["fix_history"] = _normalize_fix_history(state.get("fix_history", []))
    orig_prompt = str(state.get("original_prompt", "") or "").strip()

    # Compress when needed
    state = _maybe_compress_fix_history(workspace_path, project_name, state)
    state["fix_history"] = _normalize_fix_history(state.get("fix_history", []))
    fix_history = state["fix_history"]

    # Context window slicing
    ctx_start = _clamp_assistant_context_start(state, len(fix_history))
    fix_history_context = list(fix_history[ctx_start:]) if fix_history else []

    # Append this message to the audit log
    state["fix_history"].append({"prompt": user_message, "outcome": "In progress..."})
    save_agent_state(workspace_path, state)

    # Investigate first (always)
    from nexcode.agent_runtime.reporter import run_investigation
    inv_t0 = time.time()
    investigation_result = run_investigation(
        workspace=workspace_path,
        prompt=user_message,
        orig_prompt=orig_prompt,
        verbose=verbose,
        image_urls=image_urls,
        fix_history=fix_history_context,
    )
    inv_s = time.time() - inv_t0

    resolution_type = str(investigation_result.get("resolution_type") or "code_change").strip()
    issue_category = str(investigation_result.get("issue_category") or "unknown").strip()
    user_instructions = str(investigation_result.get("user_instructions") or "").strip()
    report_text = str(investigation_result.get("report") or "").strip()
    routed_message = user_instructions or report_text

    if issue_category == "unknown" and routed_message:
        msg = routed_message.lower()
        if any(token in msg for token in (".contentlayer", ".next", "stale cache", "restart dev server")):
            issue_category = "stale_cache"

    def _user_requested_preventative_fix(text: str) -> bool:
        t = (text or "").lower()
        return any(token in t for token in ("prevent", "permanent", "automate", "always", "never again", "predev", "script"))

    force_user_action_only = (
        issue_category == "stale_cache"
        and routed_message
        and resolution_type == "code_change"
        and not _user_requested_preventative_fix(user_message)
    )
    if force_user_action_only:
        resolution_type = "user_action_only"

    # No-code routes
    if investigation_result.get("is_question") or resolution_type in {"user_action_only", "answer_only", "need_more_info"}:
        state = load_agent_state(workspace_path)
        state["investigation_report"] = report_text or routed_message
        state["reporter_scratchpad"] = str(investigation_result.get("scratchpad") or "").strip()
        if state.get("fix_history") and isinstance(state["fix_history"][-1], dict) and state["fix_history"][-1].get("prompt") == user_message:
            state["fix_history"][-1]["outcome"] = routed_message or report_text or "No details provided."
        save_agent_state(workspace_path, state)

        if resolution_type == "need_more_info":
            title = "Need more info"
        elif resolution_type == "answer_only":
            title = "Assistant update"
        else:
            title = "User action required"

        console.print(f"\n[bold green]{title}:[/bold green]\n{routed_message}")
        if force_user_action_only:
            console.print("\n[dim](If you want me to make this permanent, ask for a preventative code change.)[/dim]")

        # Persist timing event
        try:
            state = load_agent_state(workspace_path)
            event = {
                "kind": "assistant_turn",
                "project": project_name,
                "prompt": user_message[:5000],
                "resolution_type": resolution_type,
                "started_at_utc": turn_started_at_iso,
                "ended_at_utc": _utc_now_iso(),
                "durations_sec": {
                    "total": round(time.time() - turn_t0, 3),
                    "investigation": round(inv_s, 3),
                },
            }
            state = _append_timing_event(state, event)
            save_agent_state(workspace_path, state)
        except Exception:
            pass

        total_s = time.time() - turn_t0
        if verbose:
            console.print(
                f"[dim]⏱ Timing: total={_fmt_duration(total_s)} | investigation={_fmt_duration(inv_s)} | started={turn_started_at_iso}[/dim]"
            )
        else:
            console.print(f"[dim]⏱ Done in {_fmt_duration(total_s)}[/dim]")
        return

    # Code change route: save diagnostics for the executor, then plan+execute.
    context_str = f"Investigative Bug Report:\n{investigation_result.get('report')}\n"
    state = load_agent_state(workspace_path)
    state["investigation_report"] = investigation_result.get("report")
    state["reporter_scratchpad"] = str(investigation_result.get("scratchpad") or "").strip()
    state["is_fix"] = True
    save_agent_state(workspace_path, state)

    full_fix_prompt = (
        f"The user asked: '{user_message}'.\n\n"
        f"{context_str}\n\n"
        "If this request requires code changes, provide a surgical plan to implement it in the existing codebase."
    )
    plan_t0 = time.time()
    fix_plan = generate_plan(
        full_fix_prompt,
        workspace_path,
        verbose=verbose,
        image_urls=image_urls,
        is_fix=True,
        orig_prompt=orig_prompt,
        fix_history=fix_history_context,
    )
    plan_s = time.time() - plan_t0

    if not fix_plan:
        state = load_agent_state(workspace_path)
        if state.get("fix_history") and isinstance(state["fix_history"][-1], dict) and state["fix_history"][-1].get("prompt") == user_message:
            state["fix_history"][-1]["outcome"] = "No fix plan generated."
        save_agent_state(workspace_path, state)
        console.print("[yellow]No fix plan was generated for this request.[/yellow]")

        # Persist timing event
        try:
            state = load_agent_state(workspace_path)
            event = {
                "kind": "assistant_turn",
                "project": project_name,
                "prompt": user_message[:5000],
                "resolution_type": "no_plan",
                "started_at_utc": turn_started_at_iso,
                "ended_at_utc": _utc_now_iso(),
                "durations_sec": {
                    "total": round(time.time() - turn_t0, 3),
                    "investigation": round(inv_s, 3),
                    "planning": round(plan_s, 3),
                },
            }
            state = _append_timing_event(state, event)
            save_agent_state(workspace_path, state)
        except Exception:
            pass

        total_s = time.time() - turn_t0
        if verbose:
            console.print(
                f"[dim]⏱ Timing: total={_fmt_duration(total_s)} | investigation={_fmt_duration(inv_s)} | planning={_fmt_duration(plan_s)} | started={turn_started_at_iso}[/dim]"
            )
        else:
            console.print(f"[dim]⏱ Done in {_fmt_duration(total_s)}[/dim]")
        return

    from rich.table import Table

    table = Table(title=f"Assistant Plan for '{project_name}'", show_header=True, header_style="bold magenta")
    table.add_column("Step", style="dim", width=6, justify="center")
    table.add_column("Task", style="white")

    # Adjust step numbering relative to existing plan
    state = load_agent_state(workspace_path)
    start_step = 1
    if state.get("plan"):
        start_step = state["plan"][-1]["step"] + 1

    for p in fix_plan:
        p["step"] = start_step + (p["step"] - 1)
        table.add_row(str(p["step"]), p["task"])

    console.print(table)
    console.print("\n[bold magenta]Applying changes autonomously...[/bold magenta]\n")

    state = load_agent_state(workspace_path)
    state.setdefault("plan", [])
    state["plan"].extend(fix_plan)
    save_agent_state(workspace_path, state)

    exec_t0 = time.time()
    execute_plan(state["plan"], workspace_path, verbose=verbose)
    exec_s = time.time() - exec_t0

    # Summarize the outcome for context (reload state AFTER execution).
    try:
        console.print("\n[dim]Summarizing outcome for context...[/dim]")
        summary_t0 = time.time()
        state = load_agent_state(workspace_path)

        relevant_history = []
        step_details = []
        for step in fix_plan:
            s_idx = step["step"]
            task_text = step.get("task", "Unknown Task")
            step_details.append(f"Planned Step {s_idx}: {task_text}")
            relevant_history.extend(state.get(f"coder_history_{s_idx}", []))

        step_list_str = "\n".join(step_details)
        history_blob = "\n".join(relevant_history)
        summarize_req = (
            f"Create a High-Fidelity Technical Walkthrough for the resolved request: '{user_message}'.\n\n"
            f"Original Steps Planned:\n{step_list_str}\n\n"
            "Instructions:\n"
            "1. Precisely list every file modified/created.\n"
            "2. For each file, describe the technical change.\n"
            "3. Explain how the changes solve the request.\n"
            "4. Highlight key architectural decisions.\n\n"
            f"Execution Logs:\n{history_blob[:6000000]}"
        )

        from nexcode.config import load_access, load_agent_config
        from nexcode.agent_runtime.planner import _call_gateway
        from nexcode.agent_runtime.token_utils import UsageData

        acc = load_access()
        agent_cfg = load_agent_config(workspace_path)
        outcome_summary, usage = _call_gateway(
            acc["api_key"],
            acc["endpoint"],
            agent_cfg["model"],
            "You are a lead engineer writing a dense post-mortem of what changed and why.",
            summarize_req,
            json_mode=False,
        )

        state = load_agent_state(workspace_path)
        if state.get("fix_history") and isinstance(state["fix_history"][-1], dict) and state["fix_history"][-1].get("prompt") == user_message:
            state["fix_history"][-1]["outcome"] = outcome_summary
        state["last_fix_walkthrough"] = outcome_summary

        try:
            artifacts_dir = get_agent_artifacts_dir(workspace_path)
            log_path = artifacts_dir / "WALKTHROUGH.md"
            log_path.parent.mkdir(parents=True, exist_ok=True)
            with open(log_path, "w", encoding="utf-8") as f:
                f.write(f"# High-Fidelity Walkthrough: {user_message}\n\n{outcome_summary}\n")

            dev_log = artifacts_dir / "DEVELOPMENT_LOG.md"
            with open(dev_log, "a", encoding="utf-8") as f:
                f.write(f"\n## ASSISTANT: {user_message}\n\n{outcome_summary}\n\n---\n")
        except Exception:
            pass

        cum_usage = UsageData.from_dict(state.get("cumulative_usage", {}))
        cum_usage.add(usage, model=agent_cfg["model"])
        state["cumulative_usage"] = cum_usage.to_dict()

        save_agent_state(workspace_path, state)
        if verbose:
            console.print(f"[dim]Outcome summary: {outcome_summary}[/dim]")
        summary_s = time.time() - summary_t0
    except Exception as e:
        console.print(f"[yellow]Could not summarize outcome: {e}[/yellow]")
        try:
            state = load_agent_state(workspace_path)
            if state.get("fix_history") and isinstance(state["fix_history"][-1], dict) and state["fix_history"][-1].get("prompt") == user_message:
                if str(state["fix_history"][-1].get("outcome") or "").strip().lower() == "in progress...":
                    state["fix_history"][-1]["outcome"] = f"Completed (walkthrough generation failed: {e})"
            save_agent_state(workspace_path, state)
        except Exception:
            pass

    # Persist timing event + print summary
    try:
        state = load_agent_state(workspace_path)
        total_s = time.time() - turn_t0
        event = {
            "kind": "assistant_turn",
            "project": project_name,
            "prompt": user_message[:5000],
            "resolution_type": resolution_type,
            "started_at_utc": turn_started_at_iso,
            "ended_at_utc": _utc_now_iso(),
            "durations_sec": {
                "total": round(total_s, 3),
                "investigation": round(inv_s, 3),
                "planning": round(plan_s, 3),
                "execution": round(exec_s, 3),
                "summary": round(summary_s, 3),
            },
        }
        state = _append_timing_event(state, event)
        save_agent_state(workspace_path, state)
    except Exception:
        total_s = time.time() - turn_t0

    if verbose:
        console.print(
            f"[dim]⏱ Timing: total={_fmt_duration(total_s)} | investigation={_fmt_duration(inv_s)} | "
            f"planning={_fmt_duration(plan_s)} | execution={_fmt_duration(exec_s)} | summary={_fmt_duration(summary_s)} | "
            f"started={turn_started_at_iso}[/dim]"
        )
    else:
        console.print(f"[dim]⏱ Done in {_fmt_duration(total_s)}[/dim]")


def _run_assistant_turn(
    workspace_path,
    project_name: str,
    user_message: str,
    verbose: bool,
    image_urls: list[str] | None,
    routing_override: str | None = None,
    intent_decision_override: dict | None = None,
) -> None:
    """
    One assistant turn:
      - Investigate first (Reporter) and route (answer/user_action/need_more_info/code_change)
      - If code_change: plan+execute+summarize
      - Always persist outcomes to agent_state.json
    """
    from nexcode.agent_runtime.reporter import run_investigation
    from nexcode.agent_runtime.task_scope import resolve_task_scope
    from nexcode.agent_runtime.workspace import load_agent_state, save_agent_state
    from nexcode.config import load_agent_config

    turn_started_at_iso = _utc_now_iso()
    turn_t0 = time.time()
    inv_s = 0.0

    state = load_agent_state(workspace_path)
    state["fix_history"] = _normalize_fix_history(state.get("fix_history", []))
    orig_prompt = str(state.get("original_prompt", "") or "").strip()

    state = _maybe_compress_fix_history(workspace_path, project_name, state)
    state["fix_history"] = _normalize_fix_history(state.get("fix_history", []))
    fix_history = state["fix_history"]

    ctx_start = _clamp_assistant_context_start(state, len(fix_history))
    raw_fix_history_context = list(fix_history[ctx_start:]) if fix_history else []
    fix_history_context = _filter_fix_history_context(raw_fix_history_context)
    implementation_history_context = _filter_fix_history_context(fix_history_context, implementation_only=True)

    investigation_prompt, current_user_goal = _build_follow_up_investigation_prompt(state, user_message)
    state["last_user_goal"] = str(current_user_goal or user_message).strip()
    state = _clear_pending_clarification(state)
    state["fix_history"].append({"prompt": user_message, "outcome": "In progress..."})
    save_agent_state(workspace_path, state)

    routing_mode = _normalize_assistant_intent_mode(load_agent_config(workspace_path).get("assistant_intent_mode", "conservative"))
    effective_goal = str(current_user_goal or user_message).strip()
    if intent_decision_override:
        override_intent = str(intent_decision_override.get("intent") or "").strip()
        if override_intent in {"consult_only", "implementation", "mixed"}:
            intent_decision = {
                "intent": override_intent,
                "consult_request": str(intent_decision_override.get("consult_request") or "").strip(),
                "implementation_request": str(intent_decision_override.get("implementation_request") or "").strip(),
                "reason": str(intent_decision_override.get("reason") or "routing_override").strip() or "routing_override",
            }
            if override_intent in {"consult_only", "mixed"} and not intent_decision["consult_request"]:
                intent_decision["consult_request"] = effective_goal
            if override_intent in {"implementation", "mixed"} and not intent_decision["implementation_request"]:
                intent_decision["implementation_request"] = effective_goal
        else:
            intent_decision = _classify_assistant_intent(effective_goal, routing_mode, workspace_path)
    elif routing_override == "consult_only":
        intent_decision = {
            "intent": "consult_only",
            "consult_request": effective_goal,
            "implementation_request": "",
            "reason": "forced_consult_only",
        }
    elif routing_override == "review_only":
        intent_decision = {
            "intent": "consult_only",
            "consult_request": effective_goal,
            "implementation_request": "",
            "reason": "forced_review_only",
        }
    elif routing_override == "implementation":
        intent_decision = {
            "intent": "implementation",
            "consult_request": "",
            "implementation_request": effective_goal,
            "reason": "forced_implementation",
        }
    else:
        intent_decision = _classify_assistant_intent(effective_goal, routing_mode, workspace_path)
    state = _update_latest_fix_history_entry(state, user_message, intent=intent_decision["intent"])
    save_agent_state(workspace_path, state)
    if verbose:
        console.print(ui_detail("Routing", intent_decision["intent"]))
        if intent_decision["intent"] == "mixed" and intent_decision.get("implementation_request"):
            console.print(ui_detail("Action target", intent_decision["implementation_request"]))

    def _investigate(prompt_text: str, reporter_mode: str) -> dict:
        nonlocal inv_s
        inv_t0 = time.time()
        task_scope = resolve_task_scope(
            workspace_path,
            user_message=prompt_text,
            checked_files=state.get("investigation_checked_files", []),
            plan_files=None,
            changed_files=None,
            mode_hint=reporter_mode,
        )
        result = run_investigation(
            workspace=workspace_path,
            prompt=prompt_text,
            orig_prompt=orig_prompt,
            verbose=verbose,
            image_urls=image_urls,
            fix_history=implementation_history_context if reporter_mode == "implementation" else fix_history_context,
            routing_mode=reporter_mode,
            task_scope=task_scope,
        )
        inv_s += time.time() - inv_t0
        return result

    def _normalize_result(result: dict) -> dict:
        normalized = dict(result or {})
        reporter_original_resolution_type = str(normalized.get("resolution_type") or "code_change").strip()
        resolution_type = reporter_original_resolution_type
        issue_category = str(normalized.get("issue_category") or "unknown").strip()
        user_instructions = str(normalized.get("user_instructions") or "").strip()
        report_text = str(normalized.get("report") or "").strip()
        routed_message = user_instructions or report_text
        complexity = str(normalized.get("complexity") or "simple").strip().lower()
        if complexity not in {"simple", "complex"}:
            complexity = "simple"
        confidence = str(normalized.get("confidence") or "medium").strip().lower()
        if confidence not in {"low", "medium", "high"}:
            confidence = "medium"
        checked_files = _normalize_checked_files(normalized.get("checked_files"))
        clarification_reason = str(normalized.get("clarification_reason") or "").strip()
        target_scope = str(normalized.get("target_scope") or "").strip().lower()
        overwrite_existing = bool(normalized.get("overwrite_existing", False))
        validation_level = str(normalized.get("validation_level") or "").strip().lower()
        if target_scope not in {"single_file", "localized", "project_wide"}:
            if checked_files and len(checked_files) == 1:
                target_scope = "single_file"
            elif checked_files:
                target_scope = "localized"
            else:
                target_scope = "localized"
        if validation_level not in {"none", "scoped", "broad"}:
            validation_level = "broad" if complexity == "complex" else "scoped"

        normalized.update(
            {
                "resolution_type": resolution_type,
                "issue_category": issue_category,
                "routed_message": routed_message,
                "report_text": report_text,
                "complexity": complexity,
                "confidence": confidence,
                "checked_files": checked_files,
                "clarification_reason": clarification_reason,
                "force_user_action_only": False,
                "reporter_original_resolution_type": reporter_original_resolution_type,
                "reporter_override_reason": "",
                "forced_code_change": False,
                "target_scope": target_scope,
                "overwrite_existing": overwrite_existing,
                "validation_level": validation_level,
            }
        )
        return normalized

    def _finalize_no_code_turn(result: dict, formatted_message: str, title_override: str = "") -> None:
        resolution_type = str(result.get("resolution_type") or "answer_only")
        routed_message = str(result.get("routed_message") or result.get("report_text") or "").strip()
        report_text = str(result.get("report_text") or result.get("report") or routed_message).strip()
        checked_files = _normalize_checked_files(result.get("checked_files"))
        complexity = str(result.get("complexity") or "simple")
        confidence = str(result.get("confidence") or "medium")
        clarification_reason = str(result.get("clarification_reason") or "").strip()

        state = load_agent_state(workspace_path)
        state["investigation_report"] = report_text or routed_message
        state["reporter_scratchpad"] = str(result.get("scratchpad") or "").strip()
        state["investigation_checked_files"] = checked_files
        state["investigation_complexity"] = complexity
        state["investigation_confidence"] = confidence
        state["last_resolution_type"] = resolution_type
        state["last_user_goal"] = str(current_user_goal or user_message).strip()
        state["is_fix"] = False
        state["recent_targets"] = state.get("recent_targets", [])

        if resolution_type == "need_more_info":
            question = routed_message or "I need one more detail before I can safely continue."
            reason = clarification_reason or report_text or "The request is missing a detail needed for a safe implementation."
            state["pending_clarification"] = {
                "active": True,
                "question": question,
                "reason": reason,
                "requested_at_utc": turn_started_at_iso,
                "last_report": report_text or routed_message,
            }
        else:
            state = _clear_pending_clarification(state)

        if state.get("fix_history") and isinstance(state["fix_history"][-1], dict) and state["fix_history"][-1].get("prompt") == user_message:
            state["fix_history"][-1]["outcome"] = formatted_message
            state["fix_history"][-1]["resolution_type"] = resolution_type
            state["fix_history"][-1]["context_scope"] = "consult_only" if resolution_type == "answer_only" else resolution_type
        if checked_files:
            from nexcode.agent_runtime.workspace import record_recent_targets

            state = record_recent_targets(
                state,
                checked_files,
                role="checked",
                source="reporter",
                recorded_at_utc=turn_started_at_iso,
            )
        save_agent_state(workspace_path, state)

        if title_override:
            title = title_override
        elif resolution_type == "need_more_info":
            title = "Need more info"
        elif resolution_type == "answer_only":
            title = "Assistant update"
        else:
            title = "User action required"

        console.print("")
        console.print(ui_status(title, "", tone="success"))
        console.print(formatted_message)
        if result.get("force_user_action_only"):
            console.print("")
            console.print(ui_detail("Note", "If you want me to make this permanent, ask for a preventative code change."))

        total_s = time.time() - turn_t0
        _record_assistant_timing_event(
            workspace_path,
            project_name,
            user_message,
            resolution_type,
            turn_started_at_iso,
            total_s,
            inv_s,
            complexity=complexity,
            confidence=confidence,
        )
        if verbose:
            console.print(ui_timing(f"total={_fmt_duration(total_s)} | investigation={_fmt_duration(inv_s)} | started={turn_started_at_iso}"))
        else:
            console.print(ui_timing(f"done in {_fmt_duration(total_s)}"))

    if intent_decision["intent"] == "consult_only":
        consult_reporter_mode = "review_only" if routing_override == "review_only" else "consult_only"
        consult_result = _normalize_result(_coerce_consult_investigation_result(_investigate(investigation_prompt, consult_reporter_mode)))
        consult_message = _format_no_code_response(
            consult_result["resolution_type"],
            consult_result["routed_message"],
            consult_result["checked_files"],
            clarification_reason=consult_result["clarification_reason"] or consult_result["report_text"],
        )
        _finalize_no_code_turn(consult_result, consult_message)
        return

    if intent_decision["intent"] == "mixed":
        consult_prompt = intent_decision.get("consult_request") or current_user_goal or user_message
        consult_result = _normalize_result(_coerce_consult_investigation_result(_investigate(consult_prompt, "consult_only")))
        consult_message = _format_no_code_response(
            consult_result["resolution_type"],
            consult_result["routed_message"],
            consult_result["checked_files"],
            clarification_reason=consult_result["clarification_reason"] or consult_result["report_text"],
        )
        action_prompt = str(intent_decision.get("implementation_request") or "").strip()
        if not action_prompt:
            final_message = (
                f"{consult_message}\n\n"
                "No concrete implementation target was identified, so I did not change code."
            )
            _finalize_no_code_turn(consult_result, final_message, title_override="Assistant update")
            return

        implementation_result = _normalize_result(_investigate(action_prompt, "implementation"))
        force_code_change, override_reason = _should_force_code_change(user_message, action_prompt, implementation_result)
        if force_code_change:
            implementation_result["resolution_type"] = "code_change"
            implementation_result["is_question"] = False
            implementation_result["forced_code_change"] = True
            implementation_result["reporter_override_reason"] = override_reason
            implementation_result["force_user_action_only"] = False
            if verbose:
                console.print(ui_detail("Routing override", override_reason))
        if implementation_result["resolution_type"] in {"user_action_only", "answer_only", "need_more_info"}:
            implementation_message = _format_no_code_response(
                implementation_result["resolution_type"],
                implementation_result["routed_message"],
                implementation_result["checked_files"],
                clarification_reason=implementation_result["clarification_reason"] or implementation_result["report_text"],
            )
            _finalize_no_code_turn(
                implementation_result,
                _build_mixed_response(consult_message, implementation_message),
                title_override="Assistant update",
            )
            return

        _run_code_change_turn(
            workspace_path=workspace_path,
            project_name=project_name,
            user_message=user_message,
            implementation_request=action_prompt,
            current_user_goal=action_prompt,
            verbose=verbose,
            image_urls=image_urls,
            orig_prompt=orig_prompt,
            fix_history_context=implementation_history_context,
            investigation_result=implementation_result,
            turn_started_at_iso=turn_started_at_iso,
            turn_t0=turn_t0,
            inv_s=inv_s,
            response_prefix=consult_message,
        )
        return

    implementation_result = _normalize_result(_investigate(investigation_prompt, "implementation"))
    force_code_change, override_reason = _should_force_code_change(user_message, current_user_goal, implementation_result)
    if force_code_change:
        implementation_result["resolution_type"] = "code_change"
        implementation_result["is_question"] = False
        implementation_result["forced_code_change"] = True
        implementation_result["reporter_override_reason"] = override_reason
        implementation_result["force_user_action_only"] = False
        if verbose:
            console.print(ui_detail("Routing override", override_reason))
    if implementation_result["resolution_type"] in {"user_action_only", "answer_only", "need_more_info"}:
        implementation_message = _format_no_code_response(
            implementation_result["resolution_type"],
            implementation_result["routed_message"],
            implementation_result["checked_files"],
            clarification_reason=implementation_result["clarification_reason"] or implementation_result["report_text"],
        )
        _finalize_no_code_turn(implementation_result, implementation_message)
        return

    _run_code_change_turn(
        workspace_path=workspace_path,
        project_name=project_name,
        user_message=user_message,
        implementation_request=investigation_prompt,
        current_user_goal=current_user_goal,
        verbose=verbose,
        image_urls=image_urls,
        orig_prompt=orig_prompt,
        fix_history_context=implementation_history_context,
        investigation_result=implementation_result,
        turn_started_at_iso=turn_started_at_iso,
        turn_t0=turn_t0,
        inv_s=inv_s,
    )


def _workspace_project_name(workspace_path: Path) -> str:
    name = workspace_path.resolve().name
    return name or "workspace"


def _combine_agent_message(message_text: str, piped_content: str) -> str:
    full_parts = []
    if piped_content:
        full_parts.append(f"Piped Input Context:\n---\n{piped_content}\n---")
    if message_text:
        full_parts.append(message_text)
    return "\n\n".join(full_parts).strip()


def _ensure_workspace_state_seeded(workspace_path: Path, initial_prompt: str = "", replace_synthetic: bool = False) -> dict:
    from nexcode.agent_runtime.workspace import ensure_agent_dir, load_agent_state, save_agent_state

    ensure_agent_dir(workspace_path)
    state = load_agent_state(workspace_path)
    state["fix_history"] = _normalize_fix_history(state.get("fix_history", []))

    existing_prompt = str(state.get("original_prompt") or "").strip()
    synthetic_prompt = f"Workspace: {_workspace_project_name(workspace_path)}"
    should_replace = not existing_prompt or (replace_synthetic and existing_prompt.startswith("Workspace: "))
    desired_prompt = str(initial_prompt or "").strip() or synthetic_prompt
    if should_replace and desired_prompt:
        state["original_prompt"] = desired_prompt

    save_agent_state(workspace_path, state)
    return state


def _reset_workspace_context(workspace_path: Path) -> dict:
    from nexcode.agent_runtime.workspace import load_agent_state, save_agent_state

    state = load_agent_state(workspace_path)
    state["fix_history"] = _normalize_fix_history(state.get("fix_history", []))
    state = _assistant_soft_reset_state(state)
    save_agent_state(workspace_path, state)
    return state


def _run_casual_chat_turn(
    workspace_path: Path,
    project_name: str,
    user_message: str,
    verbose: bool,
) -> None:
    from nexcode.agent_runtime.workspace import load_agent_state

    if verbose:
        console.print(ui_detail("Routing", "casual_chat"))

    _ensure_workspace_state_seeded(workspace_path)
    state = load_agent_state(workspace_path)
    state["fix_history"] = _normalize_fix_history(state.get("fix_history", []))
    pending = state.get("pending_clarification", {}) if isinstance(state.get("pending_clarification"), dict) else {}
    recent_history = _recent_non_casual_history_summary(state)
    last_resolution_type = str(state.get("last_resolution_type") or "").strip()

    reply = ""
    try:
        from nexcode.config import load_access, load_agent_config
        from nexcode.agent_runtime.planner import _call_gateway

        acc = load_access()
        if acc.get("api_key"):
            agent_cfg = load_agent_config(workspace_path)
            context_lines = [
                f"Latest user message: {user_message}",
                f"Last non-casual resolution type: {last_resolution_type or 'none'}",
            ]
            if recent_history:
                context_lines.append(f"Recent technical context:\n{recent_history}")
            if pending.get("active"):
                question = str(pending.get("question") or "").strip()
                reason = _truncate_state_text(str(pending.get("reason") or "").strip(), limit=180)
                if question:
                    context_lines.append(f"Pending clarification question: {question}")
                if reason:
                    context_lines.append(f"Why it is pending: {reason}")
            context_lines.append(
                "Write a short plain-text reply as Nexcode Agent. Keep it to 1-2 sentences, warm and natural. "
                "Do not introduce yourself unless it helps with a greeting. Do not mention investigation, routing, tools, "
                "scratchpads, internal roles, or codebase inspection. If there is recent technical progress, you may acknowledge it briefly."
            )
            reply, _usage = _call_gateway(
                acc["api_key"],
                acc["endpoint"],
                agent_cfg["model"],
                (
                    "You are Nexcode Agent replying to a casual terminal message. "
                    "Stay conversational, brief, and grounded in the provided recent context only."
                ),
                "\n\n".join(context_lines),
                json_mode=False,
            )
            reply = str(reply or "").strip()
    except Exception:
        reply = ""

    if not reply:
        reply = _build_casual_chat_fallback_response(user_message, state)

    _emit_direct_agent_response(
        workspace_path,
        project_name,
        user_message,
        reply,
        resolution_type="answer_only",
        title="Assistant update",
        context_scope="casual_chat",
        preserve_pending_clarification=True,
        preserve_last_user_goal=bool(pending.get("active")),
    )


def _emit_direct_agent_response(
    workspace_path: Path,
    project_name: str,
    user_message: str,
    formatted_message: str,
    *,
    resolution_type: str,
    clarification_reason: str = "",
    checked_files: list[str] | None = None,
    title: str = "Assistant update",
    context_scope: str = "",
    preserve_pending_clarification: bool = False,
    preserve_last_user_goal: bool = False,
) -> None:
    from nexcode.agent_runtime.workspace import load_agent_state, record_recent_targets, save_agent_state

    checked_files = checked_files or []
    turn_started_at_iso = _utc_now_iso()
    turn_t0 = time.time()

    _ensure_workspace_state_seeded(workspace_path)
    state = load_agent_state(workspace_path)
    state["fix_history"] = _normalize_fix_history(state.get("fix_history", []))
    effective_context_scope = str(context_scope or "").strip().lower()
    if not effective_context_scope:
        effective_context_scope = (
            "execution_request" if "did not run" in formatted_message.lower() or "i ran `" in formatted_message.lower() else resolution_type
        )
    state["fix_history"].append(
        {
            "prompt": user_message,
            "outcome": formatted_message,
            "resolution_type": resolution_type,
            "context_scope": effective_context_scope,
        }
    )
    state["last_resolution_type"] = resolution_type
    if not preserve_last_user_goal:
        state["last_user_goal"] = str(user_message or "").strip()
    state["investigation_checked_files"] = checked_files
    state["investigation_report"] = formatted_message
    state["is_fix"] = False
    if checked_files:
        state = record_recent_targets(
            state,
            checked_files,
            role="checked",
            source="agent",
            recorded_at_utc=turn_started_at_iso,
        )

    if resolution_type == "need_more_info":
        state["pending_clarification"] = {
            "active": True,
            "question": str(formatted_message.splitlines()[0]).strip(),
            "reason": clarification_reason or "I need a direction before editing this workspace.",
            "requested_at_utc": turn_started_at_iso,
            "last_report": formatted_message,
        }
    elif not preserve_pending_clarification:
        state = _clear_pending_clarification(state)

    save_agent_state(workspace_path, state)

    console.print("")
    console.print(ui_status(title, "", tone="success"))
    console.print(formatted_message)

    total_s = time.time() - turn_t0
    _record_assistant_timing_event(
        workspace_path,
        project_name,
        user_message,
        resolution_type,
        turn_started_at_iso,
        total_s,
        0.0,
        context_scope=effective_context_scope,
    )
    console.print(ui_timing(f"done in {_fmt_duration(total_s)}"))


def _resolve_legacy_workspace(project_name: str) -> Path | None:
    from nexcode.agent_runtime.workspace import get_workspace_root

    candidate = get_workspace_root() / str(project_name or "").strip()
    return candidate if candidate.exists() else None


def _run_build_prompt_in_workspace(
    workspace_path: Path,
    project_name: str,
    prompt: str,
    verbose: bool,
    image_urls: list[str] | None,
    target_dir: str = "",
) -> None:
    from nexcode.agent_runtime.planner import generate_plan
    from nexcode.agent_runtime.executor import execute_plan
    from nexcode.agent_runtime.workspace import load_agent_state, record_recent_targets, save_agent_state
    from nexcode.agent_runtime.input_parser import parse_input
    from nexcode.agent_runtime.designer import generate_design
    from rich.table import Table

    console.print(ui_header("Nexcode Agent", f"workspace='{project_name}' mode=build verbose={verbose}"))
    console.print("")

    effective_prompt = str(prompt or "").strip()
    normalized_target_dir = str(target_dir or "").strip().replace("\\", "/").rstrip("/")
    if normalized_target_dir:
        effective_prompt = (
            f"{effective_prompt}\n\n"
            f"Runtime instruction: create this as a standalone app inside the current workspace in the subdirectory "
            f"`{normalized_target_dir}`. Keep scaffolding and all new project files under `{normalized_target_dir}/`."
        )

    state = _ensure_workspace_state_seeded(workspace_path, initial_prompt=prompt, replace_synthetic=True)
    state["is_fix"] = False
    if normalized_target_dir:
        state = record_recent_targets(
            state,
            [normalized_target_dir],
            role="planned",
            source="build",
            recorded_at_utc=_utc_now_iso(),
            kind_overrides={normalized_target_dir: "dir"},
        )
    save_agent_state(workspace_path, state)

    build_started_at_iso = _utc_now_iso()
    build_t0 = time.time()
    try:
        state = load_agent_state(workspace_path)
        state = _append_timing_event(
            state,
            {
                "kind": "build_run",
                "project": project_name,
                "started_at_utc": build_started_at_iso,
                "ended_at_utc": "",
                "durations_sec": {},
                    "prompt": prompt[:5000],
                },
            )
        save_agent_state(workspace_path, state)
    except Exception:
        pass

    parse_input(effective_prompt, workspace_path, image_urls=image_urls, verbose=verbose)
    generate_design(effective_prompt, [], workspace_path, verbose=verbose, phase="pre_plan")
    plan = generate_plan(effective_prompt, workspace_path, verbose=verbose, image_urls=image_urls)

    if not plan:
        console.print(ui_status("Planning", "I could not produce a safe build plan for this workspace yet.", tone="warning"))
        return

    generate_design(effective_prompt, plan, workspace_path, verbose=verbose, phase="post_plan")
    table = Table(title=f"Implementation Plan | {project_name}", show_header=True, header_style="bold cyan")
    table.add_column("Step", style="dim", width=6, justify="center")
    table.add_column("Task", style="white")
    for p in plan:
        table.add_row(str(p["step"]), p["task"])

    plan_targets = _collect_plan_target_paths(plan)
    if plan_targets:
        state = load_agent_state(workspace_path)
        state = record_recent_targets(
            state,
            plan_targets,
            role="planned",
            source="plan",
            recorded_at_utc=build_started_at_iso,
        )
        save_agent_state(workspace_path, state)

    console.print(table)
    console.print("")
    console.print(ui_status("Execution", "Starting autonomous execution", tone="success"))
    console.print("")
    try:
        execute_plan(plan, workspace_path, verbose=verbose)
    finally:
        build_total_s = time.time() - build_t0
        try:
            state = load_agent_state(workspace_path)
            state = _append_timing_event(
                state,
                {
                    "kind": "build_run",
                    "project": project_name,
                    "started_at_utc": build_started_at_iso,
                    "ended_at_utc": _utc_now_iso(),
                    "durations_sec": {"total": round(build_total_s, 3)},
                    "prompt": prompt[:5000],
                },
            )
            save_agent_state(workspace_path, state)
        except Exception:
            pass
        if verbose:
            console.print(ui_timing(f"build total={_fmt_duration(build_total_s)} | started={build_started_at_iso}"))
        else:
            console.print(ui_timing(f"build done in {_fmt_duration(build_total_s)}"))


def _reply_prefers_new_subfolder(text: str) -> bool:
    norm = _normalize_intent_text(text)
    return any(token in norm for token in ("new subfolder", "separate subfolder", "new folder", "separate folder", "separate app"))


def _reply_prefers_integration(text: str) -> bool:
    norm = _normalize_intent_text(text)
    return any(token in norm for token in ("integrate", "existing app", "current app", "inside this app", "same repo"))


def _extract_requested_subdir(text: str) -> str:
    raw = str(text or "").strip()
    if not raw:
        return ""
    for pattern in (
        r"`(?P<name>[a-zA-Z0-9][a-zA-Z0-9._-]*)`",
        r'\"(?P<name>[a-zA-Z0-9][a-zA-Z0-9._-]*)\"',
        r"\b(?:folder|subfolder|subdir|directory|dir)\s+(?:named\s+)?(?P<name>[a-zA-Z0-9][a-zA-Z0-9._-]*)\b",
        r"\b(?:in|inside|under)\s+(?P<name>[a-zA-Z0-9][a-zA-Z0-9._-]*)\b",
    ):
        match = re.search(pattern, raw)
        if not match:
            continue
        candidate = str(match.group("name") or "").strip().replace("\\", "/").rstrip("/")
        if candidate and candidate not in {"app", "repo", "workspace", "project"}:
            return candidate
    return ""


def _truncate_state_text(value: str, limit: int = 500) -> str:
    cleaned = str(value or "").strip()
    if len(cleaned) <= limit:
        return cleaned
    return f"{cleaned[: max(0, limit - 15)]}... [truncated]"


def _execution_summary_line(preview: str) -> str:
    for line in str(preview or "").splitlines():
        candidate = line.strip()
        if not candidate:
            continue
        if candidate.lower().startswith("output preview"):
            continue
        return _truncate_state_text(candidate, limit=180)
    return "No output preview available."


def _build_execution_state_payload(result, target_file: str) -> dict:
    return {
        "command": str(result.command or "").strip(),
        "cwd": str(result.cwd or "").strip(),
        "target_file": str(target_file or "").strip(),
        "exit_code": result.exit_code,
        "status": str(result.status or "").strip(),
        "duration_sec": round(float(result.duration_sec or 0.0), 3),
        "started_at_utc": str(result.started_at_utc or "").strip(),
        "ended_at_utc": str(result.ended_at_utc or "").strip(),
        "artifact_path": str(result.artifact_path or "").strip(),
        "output_preview": _truncate_state_text(result.output_preview, limit=1800),
        "full_output_chars": int(result.full_output_chars or 0),
    }


def _build_execution_history_summary(result, target_file: str) -> str:
    action = "Ran" if result.status in {"success", "failed", "timed_out"} else "Did not run"
    pieces = [
        f"{action} {target_file or 'requested target'}",
        f"status={result.status or 'unknown'}",
    ]
    if result.exit_code is not None:
        pieces.append(f"exit={result.exit_code}")
    pieces.append(f"duration={_fmt_duration(result.duration_sec)}")
    summary = _execution_summary_line(result.output_preview)
    artifact = str(result.artifact_path or "").strip()
    text = f"{' | '.join(pieces)} | preview={summary}"
    if artifact:
        text += f" | artifact={artifact}"
    return _truncate_state_text(text, limit=900)


def _format_execution_request_message(target_file: str, result) -> str:
    command = str(result.command or "").strip() or target_file
    duration = _fmt_duration(result.duration_sec)
    artifact = str(result.artifact_path or "").strip()
    preview = str(result.output_preview or "").strip() or "Command executed successfully with no output."

    if result.status == "success":
        intro = f"I ran `{target_file}` with `{command}`."
        outcome = f"Exit code: `{result.exit_code}` in {duration}."
    elif result.status == "failed":
        intro = f"I ran `{target_file}` with `{command}`, but it exited with a non-zero status."
        outcome = f"Exit code: `{result.exit_code}` after {duration}."
    elif result.status == "timed_out":
        intro = f"I started `{target_file}` with `{command}`, but it timed out."
        outcome = f"The run stopped after {duration}."
    else:
        intro = f"I did not run `{target_file}`."
        outcome = preview

    parts = [intro, outcome]

    if result.status in {"success", "failed", "timed_out"}:
        parts.append(f"What happened: {_execution_summary_line(preview)}")
        parts.append(f"Output preview:\n```text\n{preview}\n```")
        if artifact:
            parts.append(f"Full output log: `{artifact}`")

    return "\n\n".join(part for part in parts if str(part).strip())


def _run_execution_request_turn(
    workspace_path: Path,
    project_name: str,
    user_message: str,
    verbose: bool,
    action_kind: str = "run",
) -> None:
    from nexcode.agent_runtime.task_scope import resolve_task_scope
    from nexcode.agent_runtime.project_profile import (
        build_build_commands,
        build_test_commands,
        detect_project_profile,
    )
    from nexcode.agent_runtime.workspace import (
        get_project_root,
        load_agent_state,
        normalize_rel_path,
        record_recent_targets,
        save_agent_state,
    )
    from nexcode.tools.shell_tools import run_command_interactive

    _ensure_workspace_state_seeded(workspace_path)
    action_kind = str(action_kind or "run").strip().lower()
    scope = resolve_task_scope(workspace_path, user_message=user_message, mode_hint="execution_request")
    candidate_files = list(scope.explicit_files or ()) if _looks_like_path_target(user_message) else []
    candidate_entry = None
    candidates: list[dict] = []
    if candidate_files:
        target_file = candidate_files[0]
        candidate_entry = {
            "path": target_file,
            "kind": _path_kind_in_workspace(workspace_path, target_file),
            "role": "explicit",
            "source": "message",
            "score": 100,
        }
        candidates = [candidate_entry]
    else:
        candidate_entry, candidates = _resolve_followup_target_candidate(workspace_path, user_message, action_kind)

    if not candidate_entry:
        clarification = (
            _format_followup_target_clarification(action_kind, candidates)
            if candidates
            else f"I could not identify a concrete recent target to `{action_kind}` from your request."
        )
        _emit_direct_agent_response(
            workspace_path,
            project_name,
            user_message,
            clarification,
            resolution_type="need_more_info",
            clarification_reason=f"I need a concrete file or project target to `{action_kind}` safely inside the current workspace.",
            checked_files=[item.get('path', '') for item in candidates[:3] if item.get("path")],
            title="Need more info",
        )
        return

    target_file = str(candidate_entry.get("path") or "").strip()
    target_kind = str(candidate_entry.get("kind") or "").strip().lower() or _path_kind_in_workspace(workspace_path, target_file)
    project_root = get_project_root(workspace_path).resolve()
    target_path = (project_root / target_file).resolve()

    if action_kind == "open":
        _emit_direct_agent_response(
            workspace_path,
            project_name,
            user_message,
            f"The most relevant recent target is `{target_file}`.",
            resolution_type="answer_only",
            checked_files=[target_file],
            title="Assistant update",
        )
        return

    command = ""
    exec_dir = "."
    if action_kind == "run":
        if target_kind != "file":
            _emit_direct_agent_response(
                workspace_path,
                project_name,
                user_message,
                f"I did not run `{target_file}` because it is not a runnable file target.",
                resolution_type="need_more_info",
                clarification_reason="I need a concrete file path to run.",
                checked_files=[target_file],
                title="Need more info",
            )
            return
        suffix = target_path.suffix.lower()
        if suffix == ".py":
            command = f'python "{target_path.name}"'
        elif suffix in {".js", ".cjs", ".mjs"}:
            command = f'node "{target_path.name}"'
        else:
            _emit_direct_agent_response(
                workspace_path,
                project_name,
                user_message,
                f"I did not run `{target_file}` because I do not know a safe default runtime for `{suffix or 'that file type'}` yet.",
                resolution_type="answer_only",
                checked_files=[target_file],
                title="Assistant update",
            )
            return
        exec_dir = str(Path(target_file).parent).replace("\\", "/")
        exec_dir = "." if exec_dir in {"", "."} else exec_dir
    elif action_kind in {"build", "test"}:
        scoped_scope = resolve_task_scope(
            workspace_path,
            user_message=user_message,
            checked_files=[target_file],
            plan_files=[target_file],
            changed_files=[target_file],
            mode_hint="implementation",
        )
        scoped_root = scoped_scope.primary_root or project_root
        profile = detect_project_profile(workspace_path, task_scope=scoped_scope)
        command_candidates = (
            build_build_commands(profile, verification_mode="project")
            if action_kind == "build"
            else build_test_commands(profile, verification_mode="project")
        )
        if not command_candidates:
            _emit_direct_agent_response(
                workspace_path,
                project_name,
                user_message,
                f"I found `{target_file}`, but I could not detect a safe default `{action_kind}` command for it.",
                resolution_type="answer_only",
                checked_files=[target_file],
                title="Assistant update",
            )
            return
        command = subprocess.list2cmdline(command_candidates[0][1])
        exec_dir = normalize_rel_path(str(scoped_root.relative_to(project_root)).replace("\\", "/")).rstrip("/")
        exec_dir = "." if exec_dir in {"", "."} else exec_dir

    state = load_agent_state(workspace_path)
    state["last_user_goal"] = user_message
    state["investigation_checked_files"] = [target_file]
    state = _clear_pending_clarification(state)
    state = record_recent_targets(
        state,
        [target_file],
        role="checked",
        source="execution",
        recorded_at_utc=_utc_now_iso(),
        kind_overrides={target_file: target_kind or "file"},
    )
    save_agent_state(workspace_path, state)

    verb = {"run": "Running", "build": "Building", "test": "Testing"}.get(action_kind, "Running")
    console.print(ui_status("Execution", f"{verb} `{target_file}` now. I will share what happens.", tone="accent"))

    def _status_update(elapsed: float, latest_line: str) -> None:
        label = {"run": "Running", "build": "Building", "test": "Testing"}.get(action_kind, "Running")
        message = f"{label} `{target_file}` ({_fmt_duration(elapsed)} elapsed)"
        snippet = str(latest_line or "").strip()
        if snippet:
            message += f" | latest: {_truncate_state_text(snippet, limit=120)}"
        status.update(ui_status("Execution", message, tone="accent"))

    def _tail_update(lines: list[str], omitted: int) -> None:
        if not verbose:
            return
        for line in lines:
            console.print(ui_detail("Live output", line))
        if omitted > 0:
            console.print(ui_detail("Live output", f"... {omitted} more line(s) arrived in this batch"))

    with console.status(ui_status("Execution", f"{verb} `{target_file}`...", tone="accent"), spinner="dots") as status:
        result = run_command_interactive(
            workspace_path,
            command,
            path=exec_dir,
            verbose=verbose,
            status_callback=_status_update,
            tail_callback=_tail_update,
        )

    result.target_file = target_file
    message = _format_execution_request_message(target_file, result)
    state = load_agent_state(workspace_path)
    state["fix_history"] = _normalize_fix_history(state.get("fix_history", []))
    state["fix_history"].append(
        {
            "prompt": user_message,
            "outcome": _build_execution_history_summary(result, target_file),
            "resolution_type": "answer_only",
            "context_scope": "execution_request",
        }
    )
    state["last_resolution_type"] = "answer_only"
    state["last_user_goal"] = str(user_message or "").strip()
    state["investigation_checked_files"] = [target_file]
    state["investigation_report"] = _build_execution_history_summary(result, target_file)
    state["last_execution"] = _build_execution_state_payload(result, target_file)
    state["is_fix"] = False
    state = _clear_pending_clarification(state)
    state = record_recent_targets(
        state,
        [target_file],
        role="executed",
        source="execution",
        recorded_at_utc=result.ended_at_utc or _utc_now_iso(),
        kind_overrides={target_file: target_kind or "file"},
    )
    save_agent_state(workspace_path, state)

    console.print("")
    console.print(ui_status("Assistant update", "", tone="success"))
    console.print(message)

    _record_assistant_timing_event(
        workspace_path,
        project_name,
        user_message,
        "answer_only",
        result.started_at_utc or _utc_now_iso(),
        result.duration_sec,
        0.0,
        exec_s=result.duration_sec,
        context_scope="execution_request",
        checked_files=[target_file],
        command=result.command,
        exit_code=result.exit_code,
    )
    console.print(ui_timing(f"done in {_fmt_duration(result.duration_sec)}"))


def _run_current_workspace_turn(
    workspace_path: Path,
    project_name: str,
    user_message: str,
    verbose: bool,
    image_urls: list[str] | None,
    command_hint: str = "",
) -> None:
    from nexcode.agent_runtime.workspace import clear_pending_workspace_decision, load_agent_state, save_agent_state
    from nexcode.config import load_agent_config

    state = _ensure_workspace_state_seeded(workspace_path)
    pending_decision = state.get("pending_workspace_decision", {})
    if isinstance(pending_decision, dict) and pending_decision.get("active"):
        original_prompt = str(pending_decision.get("original_prompt") or "").strip()
        resumed_image_urls = pending_decision.get("image_urls") if isinstance(pending_decision.get("image_urls"), list) else image_urls
        if _reply_prefers_new_subfolder(user_message):
            target_dir = _extract_requested_subdir(user_message) or str(pending_decision.get("proposed_subdir") or "").strip() or _derive_subproject_slug(original_prompt, workspace_path)
            state = load_agent_state(workspace_path)
            state = _clear_pending_clarification(state)
            state = clear_pending_workspace_decision(state)
            save_agent_state(workspace_path, state)
            _run_build_prompt_in_workspace(
                workspace_path,
                project_name,
                original_prompt,
                verbose,
                resumed_image_urls,
                target_dir=target_dir,
            )
            return
        if _reply_prefers_integration(user_message):
            state = load_agent_state(workspace_path)
            state = _clear_pending_clarification(state)
            state = clear_pending_workspace_decision(state)
            save_agent_state(workspace_path, state)
            _run_build_prompt_in_workspace(
                workspace_path,
                project_name,
                original_prompt,
                verbose,
                resumed_image_urls,
            )
            return
        question = (
            "I still need to know whether to integrate this into the current project or create a separate app in a subfolder."
        )
        _emit_direct_agent_response(
            workspace_path,
            project_name,
            user_message,
            question,
            resolution_type="need_more_info",
            clarification_reason="Reply with integrate or separate app, and optionally name the subfolder.",
            title="Need more info",
        )
        state = load_agent_state(workspace_path)
        state["pending_workspace_decision"] = pending_decision
        save_agent_state(workspace_path, state)
        return

    agent_cfg = load_agent_config(workspace_path)
    routing_strategy = _normalize_assistant_routing_strategy(agent_cfg.get("assistant_routing_strategy", "heuristic"))
    routing_mode = _normalize_assistant_intent_mode(agent_cfg.get("assistant_intent_mode", "conservative"))
    workspace_info = _inspect_workspace_root(workspace_path)
    greenfield_requested = command_hint == "build" or _looks_like_greenfield_request(user_message)
    if greenfield_requested:
        if workspace_info["has_meaningful_content"]:
            routing_mode_for_gf = _normalize_assistant_intent_mode(agent_cfg.get("assistant_intent_mode", "conservative"))
            gf_decision = _classify_greenfield_workspace_decision(
                user_message,
                workspace_info,
                routing_mode_for_gf,
                workspace_path,
            )
            _emit_workspace_routing_trace(verbose, "ai_greenfield_classifier", gf_decision)
            if gf_decision == "existing_project":
                # Not a build request — fall through to normal assistant routing below
                pass
            elif gf_decision == "separate":
                target_dir = _derive_subproject_slug(user_message, workspace_path)
                state = load_agent_state(workspace_path)
                state = _clear_pending_clarification(state)
                save_agent_state(workspace_path, state)
                _run_build_prompt_in_workspace(
                    workspace_path,
                    project_name,
                    user_message,
                    verbose,
                    image_urls,
                    target_dir=target_dir,
                )
                return
            else:
                # "integrate" — build/extend in place
                state = load_agent_state(workspace_path)
                state = _clear_pending_clarification(state)
                save_agent_state(workspace_path, state)
                _run_build_prompt_in_workspace(workspace_path, project_name, user_message, verbose, image_urls)
                return
        else:
            _run_build_prompt_in_workspace(workspace_path, project_name, user_message, verbose, image_urls)
            return

    if command_hint == "fix":
        _emit_workspace_routing_trace(verbose, "guardrail", "assistant", intent="implementation")
        _run_assistant_turn(
            workspace_path,
            project_name,
            user_message,
            verbose,
            image_urls,
            routing_override="implementation",
        )
        return

    followup_action = _detect_followup_target_action(user_message)
    if followup_action in _EXECUTION_ACTION_KINDS:
        _emit_workspace_routing_trace(verbose, "guardrail", "execution_request", action_kind=followup_action)
        _run_execution_request_turn(workspace_path, project_name, user_message, verbose, action_kind=followup_action)
        return

    if routing_strategy == "ai_first":
        route_decision = _classify_workspace_route_with_model(user_message, routing_mode, workspace_path)
        routing_source = "model"
        if not route_decision:
            route_decision = _classify_workspace_route_heuristically(user_message, routing_mode)
            routing_source = "heuristic_fallback"
        route = str(route_decision.get("route") or "assistant").strip()
        intent = str(route_decision.get("intent") or "").strip()
        action_kind = str(route_decision.get("action_kind") or "").strip().lower()
        _emit_workspace_routing_trace(verbose, routing_source, route, intent=intent, action_kind=action_kind)
        if route == "casual_chat":
            _run_casual_chat_turn(workspace_path, project_name, user_message, verbose)
            return
        if route == "review_only":
            _run_assistant_turn(workspace_path, project_name, user_message, verbose, image_urls, routing_override="review_only")
            return
        if route == "execution_request" and action_kind in _EXECUTION_ACTION_KINDS:
            _run_execution_request_turn(workspace_path, project_name, user_message, verbose, action_kind=action_kind)
            return
        _run_assistant_turn(
            workspace_path,
            project_name,
            user_message,
            verbose,
            image_urls,
            intent_decision_override=route_decision,
        )
        return

    if _is_review_request(user_message):
        _emit_workspace_routing_trace(verbose, "heuristic_fallback", "review_only")
        _run_assistant_turn(workspace_path, project_name, user_message, verbose, image_urls, routing_override="review_only")
        return

    if _is_casual_chat_message(user_message):
        _emit_workspace_routing_trace(verbose, "heuristic_fallback", "casual_chat")
        _run_casual_chat_turn(workspace_path, project_name, user_message, verbose)
        return

    _run_assistant_turn(workspace_path, project_name, user_message, verbose, image_urls)


def _run_workspace_repl(
    workspace_path: Path,
    project_name: str,
    piped_content: str,
    verbose: bool,
    image_urls: list[str] | None,
    prompt_label: str,
    turn_runner,
    command_hint: str = "",
) -> None:
    console.print(ui_detail("Commands", "/exit, /reset, /image <path-or-url> [message...], /clear_images"))
    console.print("")

    piped_prefix = piped_content.strip() if piped_content else ""
    pending_images: list[str] = list(image_urls or [])
    while True:
        try:
            line = input(f"{prompt_label}> ")
        except EOFError:
            console.print("")
            console.print(ui_detail("Session", "EOF received. Exiting agent."))
            break
        except KeyboardInterrupt:
            console.print("")
            console.print(ui_detail("Session", "Interrupted. Type /exit to quit."))
            continue

        text = (line or "").strip()
        if not text:
            continue

        lower = text.lower().strip()
        if lower in {"/exit", "exit", "quit"}:
            break
        if lower == "/reset":
            state = _reset_workspace_context(workspace_path)
            console.print(f"[bold green]{_format_soft_reset_message(state)}[/bold green]")
            continue
        if lower.startswith("/image "):
            raw = text[len("/image ") :].strip()
            img_arg, remainder = _split_first_arg(raw)
            img_arg = _strip_wrapping_quotes(img_arg)
            resolved = _resolve_image(img_arg)
            if resolved:
                if remainder:
                    images_for_turn = (pending_images + [resolved]) if pending_images else [resolved]
                    pending_images = []
                    if piped_prefix:
                        user_message = f"Piped Input Context:\n---\n{piped_prefix}\n---\n\n{remainder}"
                        piped_prefix = ""
                    else:
                        user_message = remainder
                    turn_runner(workspace_path, project_name, user_message, verbose, images_for_turn, command_hint)
                else:
                    pending_images.append(resolved)
                    console.print(ui_status("Images", "Image attached for the next message", tone="success"))
            continue
        if lower == "/clear_images":
            pending_images = []
            console.print(ui_status("Images", "Cleared pending images", tone="success"))
            continue

        if piped_prefix:
            user_message = f"Piped Input Context:\n---\n{piped_prefix}\n---\n\n{text}"
            piped_prefix = ""
        else:
            user_message = text

        images_for_turn = pending_images if pending_images else None
        pending_images = []
        turn_runner(workspace_path, project_name, user_message, verbose, images_for_turn, command_hint)


def _run_legacy_assistant_cli(
    workspace_path: Path,
    project_name: str,
    message_args: list[str],
    piped_content: str,
    verbose: bool,
    image_urls: list[str] | None,
) -> None:
    rest = list(message_args)
    reset_flag = False
    if "--reset" in rest:
        reset_flag = True
        rest = [token for token in rest if token != "--reset"]

    if reset_flag:
        state = _reset_workspace_context(workspace_path)
        console.print(f"[bold green]{_format_soft_reset_message(state)}[/bold green]")

    message_text = " ".join(rest).strip()
    if message_text or piped_content:
        user_message = _combine_agent_message(message_text, piped_content)
        console.print(ui_header("Nexcode Assistant", f"project='{project_name}' verbose={verbose}"))
        console.print("")
        if user_message.strip() == "/reset":
            state = _reset_workspace_context(workspace_path)
            console.print(f"[bold green]{_format_soft_reset_message(state)}[/bold green]")
            return
        _run_assistant_turn(workspace_path, project_name, user_message, verbose, image_urls)
        return

    console.print(ui_header("Nexcode Assistant", f"project='{project_name}' verbose={verbose}"))
    _run_workspace_repl(
        workspace_path,
        project_name,
        piped_content,
        verbose,
        image_urls,
        "assistant",
        lambda ws, proj, msg, vb, imgs, _hint: _run_assistant_turn(ws, proj, msg, vb, imgs),
    )


def _run_resume_for_workspace(workspace_path: Path, project_name: str, verbose: bool) -> None:
    from nexcode.agent_runtime.workspace import load_agent_state
    from nexcode.agent_runtime.executor import execute_plan

    state = load_agent_state(workspace_path)
    plan = state.get("plan", [])
    if not plan:
        console.print("[red]Error:[/red] No valid plan found in the saved agent state to resume.")
        sys.exit(1)

    console.print(ui_header("Nexcode Resume", f"project='{project_name}' verbose={verbose}"))
    console.print("")
    execute_plan(plan, workspace_path, verbose=verbose)


def handle_agent_cli(args: list[str], piped_content: str = "", verbose: bool = False, image_urls: list[str] = None) -> None:
    """
    Handle the `nexcode agent` command namespace.
    """
    args = list(args or [])
    image_urls = list(image_urls or [])

    if "--new-in" in args:
        idx = args.index("--new-in")
        if idx + 1 >= len(args):
            console.print("[red]Error:[/red] `--new-in` requires a relative folder name.")
            sys.exit(1)
        new_in_target = args[idx + 1].strip()
        del args[idx : idx + 2]
    else:
        new_in_target = ""

    reset_flag = False
    if "--reset" in args:
        reset_flag = True
        args = [token for token in args if token != "--reset"]

    if args and args[0] == "chat":
        console.print(
            "[red]Error:[/red] `nexcode agent chat` has been removed. "
            "Use [cyan]nexcode agent [message][/cyan] instead."
        )
        sys.exit(1)

    if args and args[0] == "resume":
        legacy_workspace = _resolve_legacy_workspace(args[1]) if len(args) > 1 else None
        if len(args) > 1 and legacy_workspace is None:
            console.print(f"[red]Error:[/red] Legacy workspace '{args[1]}' not found.")
            sys.exit(1)
        workspace_path = legacy_workspace or Path.cwd()
        project_name = args[1] if legacy_workspace is not None else _workspace_project_name(workspace_path)
        _run_resume_for_workspace(workspace_path, project_name, verbose)
        return

    command_hint = ""
    if args and args[0] == "assistant":
        if len(args) > 1:
            legacy_workspace = _resolve_legacy_workspace(args[1])
            if legacy_workspace is not None:
                _run_legacy_assistant_cli(legacy_workspace, args[1], args[2:], piped_content, verbose, image_urls)
                return
        console.print("[dim]Note: `assistant` now routes through the current workspace agent flow.[/dim]")
        args = args[1:]
    elif args and args[0] == "build":
        console.print("[dim]Note: `build` now routes through the current workspace agent flow.[/dim]")
        command_hint = "build"
        args = args[1:]
    elif args and args[0] == "fix":
        console.print("[dim]Note: `fix` is an alias for the current workspace agent flow.[/dim]")
        command_hint = "fix"
        args = args[1:]

    cwd = Path.cwd()
    if new_in_target:
        new_in_path = Path(new_in_target)
        if new_in_path.is_absolute() or ".." in new_in_path.parts:
            console.print("[red]Error:[/red] `--new-in` must stay inside the current workspace.")
            sys.exit(1)
        workspace_path = cwd / new_in_path
        workspace_path.mkdir(parents=True, exist_ok=True)
        target_info = _inspect_workspace_root(workspace_path)
        if target_info["has_meaningful_content"] and (args or piped_content):
            console.print(
                f"[red]Error:[/red] Target folder '{new_in_target}' already contains project files. "
                "Choose an empty folder or a metadata-only folder."
            )
            sys.exit(1)
    else:
        workspace_path = cwd

    project_name = _workspace_project_name(workspace_path)
    _ensure_workspace_state_seeded(workspace_path)

    if reset_flag:
        state = _reset_workspace_context(workspace_path)
        console.print(f"[bold green]{_format_soft_reset_message(state)}[/bold green]")
        if not args and not piped_content:
            return

    message_text = " ".join(args).strip()
    user_message = _combine_agent_message(message_text, piped_content)

    if new_in_target and user_message:
        _run_build_prompt_in_workspace(workspace_path, project_name, user_message, verbose, image_urls)
        return

    console.print(ui_header("Nexcode Agent", f"workspace='{project_name}' verbose={verbose}"))
    console.print("")

    if user_message:
        _run_current_workspace_turn(workspace_path, project_name, user_message, verbose, image_urls, command_hint=command_hint)
        return

    _run_workspace_repl(
        workspace_path,
        project_name,
        piped_content,
        verbose,
        image_urls,
        "agent",
        _run_current_workspace_turn,
        command_hint=command_hint,
    )
    return

    if not args:
        console.print("[red]Error:[/red] Missing agent command. Usage: [cyan]nexcode agent build <prompt>[/cyan]")
        console.print("Commands: build, resume, assistant")
        sys.exit(1)

    command = args[0]
    prompt_args = args[1:]

    if command == "build":
        if not prompt_args:
            console.print("[red]Error:[/red] Missing prompt for build. Example: [cyan]nexcode agent build \"REST API\"[/cyan]")
            sys.exit(1)

        prompt_text = " ".join(prompt_args)

        # Combine text prompt with piped input
        full_prompt_parts = []
        if piped_content:
            full_prompt_parts.append(f"Piped Input Context:\n---\n{piped_content}\n---")
        if prompt_text:
            full_prompt_parts.append(prompt_text)
        prompt = "\n\n".join(full_prompt_parts).strip()

        from nexcode.agent_runtime.planner import generate_plan
        from nexcode.agent_runtime.executor import execute_plan
        from nexcode.agent_runtime.workspace import init_workspace, load_agent_state, save_agent_state

        console.print(ui_header("Nexcode Build", f"verbose={verbose}"))
        console.print("")

        # Generate workspace name locally — no LLM call needed
        import re as _re

        folder_name = _re.sub(r"[^a-z0-9]+", "-", prompt_text.lower()).strip("-")[:40]
        if not folder_name:
            folder_name = "project"

        workspace_path = init_workspace(folder_name)

        # Save original prompt to state right away so assistant knows what we are building
        state = load_agent_state(workspace_path)
        if not state.get("original_prompt"):
            state["original_prompt"] = prompt
            save_agent_state(workspace_path, state)

        build_started_at_iso = _utc_now_iso()
        build_t0 = time.time()
        try:
            state = load_agent_state(workspace_path)
            state = _append_timing_event(
                state,
                {
                    "kind": "build_run",
                    "project": folder_name,
                    "started_at_utc": build_started_at_iso,
                    "ended_at_utc": "",
                    "durations_sec": {},
                    "prompt": prompt[:5000],
                },
            )
            save_agent_state(workspace_path, state)
        except Exception:
            pass

        # Parse the input into distinct memory layers
        from nexcode.agent_runtime.input_parser import parse_input

        parse_input(prompt, workspace_path, image_urls=image_urls, verbose=verbose)

        from nexcode.agent_runtime.designer import generate_design

        generate_design(prompt, [], workspace_path, verbose=verbose, phase="pre_plan")
        plan = generate_plan(prompt, workspace_path, verbose=verbose, image_urls=image_urls)

        if plan:
            generate_design(prompt, plan, workspace_path, verbose=verbose, phase="post_plan")
            from rich.table import Table

            table = Table(title=f"Implementation Plan | {folder_name}", show_header=True, header_style="bold cyan")
            table.add_column("Step", style="dim", width=6, justify="center")
            table.add_column("Task", style="white")
            for p in plan:
                table.add_row(str(p["step"]), p["task"])

            console.print(table)
            console.print("")
            console.print(ui_status("Execution", "Starting autonomous execution", tone="success"))
            console.print("")
            try:
                execute_plan(plan, workspace_path, verbose=verbose)
            finally:
                build_total_s = time.time() - build_t0
                try:
                    state = load_agent_state(workspace_path)
                    # Update last event if it was build_run
                    event = {
                        "kind": "build_run",
                        "project": folder_name,
                        "started_at_utc": build_started_at_iso,
                        "ended_at_utc": _utc_now_iso(),
                        "durations_sec": {"total": round(build_total_s, 3)},
                        "prompt": prompt[:5000],
                    }
                    state = _append_timing_event(state, event)
                    save_agent_state(workspace_path, state)
                except Exception:
                    pass
                if verbose:
                    console.print(ui_timing(f"build total={_fmt_duration(build_total_s)} | started={build_started_at_iso}"))
                else:
                    console.print(ui_timing(f"build done in {_fmt_duration(build_total_s)}"))
        return

    if command == "resume":
        if not prompt_args:
            console.print("[red]Error:[/red] Missing project name for resume. Example: [cyan]nexcode agent resume \"calculator_app\"[/cyan]")
            sys.exit(1)

        project_name = prompt_args[0]
        from nexcode.agent_runtime.workspace import get_workspace_root, load_agent_state
        from nexcode.agent_runtime.executor import execute_plan

        workspace_path = get_workspace_root() / project_name
        if not workspace_path.exists():
            console.print(f"[red]Error:[/red] Workspace '{project_name}' not found in {get_workspace_root()}.")
            sys.exit(1)

        state = load_agent_state(workspace_path)
        plan = state.get("plan", [])
        if not plan:
            console.print("[red]Error:[/red] No valid plan found in the saved agent state to resume.")
            sys.exit(1)

        console.print(ui_header("Nexcode Resume", f"project='{project_name}' verbose={verbose}"))
        console.print("")
        execute_plan(plan, workspace_path, verbose=verbose)
        return

    if command in {"assistant", "fix"}:
        if not prompt_args:
            console.print("[red]Error:[/red] Missing project name. Example: [cyan]nexcode agent assistant \"calculator_app\"[/cyan]")
            sys.exit(1)

        # Back-compat alias notice
        if command == "fix":
            console.print("[dim]Note: 'fix' is an alias for 'assistant'.[/dim]")

        project_name = prompt_args[0]
        rest = list(prompt_args[1:])

        reset_flag = False
        if "--reset" in rest:
            reset_flag = True
            rest = [t for t in rest if t != "--reset"]

        from nexcode.agent_runtime.workspace import get_workspace_root, load_agent_state, save_agent_state

        workspace_path = get_workspace_root() / project_name
        if not workspace_path.exists():
            console.print(f"[red]Error:[/red] Workspace '{project_name}' not found.")
            sys.exit(1)

        if reset_flag:
            state = load_agent_state(workspace_path)
            state["fix_history"] = _normalize_fix_history(state.get("fix_history", []))
            state = _assistant_soft_reset_state(state)
            save_agent_state(workspace_path, state)
            console.print(f"[bold green]{_format_soft_reset_message(state)}[/bold green]")

        message_text = " ".join(rest).strip()

        # One-shot mode
        if message_text:
            full_parts = []
            if piped_content:
                full_parts.append(f"Piped Input Context:\n---\n{piped_content}\n---")
            full_parts.append(message_text)
            user_message = "\n\n".join(full_parts).strip()

            console.print(ui_header("Nexcode Assistant", f"project='{project_name}' verbose={verbose}"))
            console.print("")

            if user_message.strip() == "/reset":
                state = load_agent_state(workspace_path)
                state["fix_history"] = _normalize_fix_history(state.get("fix_history", []))
                state = _assistant_soft_reset_state(state)
                save_agent_state(workspace_path, state)
                console.print(f"[bold green]{_format_soft_reset_message(state)}[/bold green]")
                return

            _run_assistant_turn(workspace_path, project_name, user_message, verbose, image_urls)
            return

        # REPL mode
        console.print(ui_header("Nexcode Assistant", f"project='{project_name}' verbose={verbose}"))
        console.print(ui_detail("Commands", "/exit, /reset, /image <path-or-url> [message...], /clear_images"))
        console.print("")

        piped_prefix = piped_content.strip() if piped_content else ""
        # In REPL mode, treat any CLI-provided images as "pending for the next message" (one-time).
        pending_images: list[str] = list(image_urls or [])
        while True:
            try:
                line = input("assistant> ")
            except EOFError:
                console.print("")
                console.print(ui_detail("Session", "EOF received. Exiting assistant."))
                break
            except KeyboardInterrupt:
                console.print("")
                console.print(ui_detail("Session", "Interrupted. Type /exit to quit."))
                continue

            text = (line or "").strip()
            if not text:
                continue

            lower = text.lower().strip()
            if lower in {"/exit", "exit", "quit"}:
                break

            if lower == "/reset":
                state = load_agent_state(workspace_path)
                state["fix_history"] = _normalize_fix_history(state.get("fix_history", []))
                state = _assistant_soft_reset_state(state)
                save_agent_state(workspace_path, state)
                console.print(f"[bold green]{_format_soft_reset_message(state)}[/bold green]")
                continue
            if lower.startswith("/image "):
                raw = text[len("/image ") :].strip()
                img_arg, remainder = _split_first_arg(raw)
                img_arg = _strip_wrapping_quotes(img_arg)
                resolved = _resolve_image(img_arg)
                if resolved:
                    if remainder:
                        images_for_turn = (pending_images + [resolved]) if pending_images else [resolved]
                        pending_images = []
                        if piped_prefix:
                            user_message = f"Piped Input Context:\n---\n{piped_prefix}\n---\n\n{remainder}"
                            piped_prefix = ""
                        else:
                            user_message = remainder
                        _run_assistant_turn(workspace_path, project_name, user_message, verbose, images_for_turn)
                    else:
                        pending_images.append(resolved)
                        console.print(ui_status("Images", "Image attached for the next message", tone="success"))
                continue
            if lower == "/clear_images":
                pending_images = []
                console.print(ui_status("Images", "Cleared pending images", tone="success"))
                continue

            # Apply piped context only once (first interactive message)
            if piped_prefix:
                user_message = f"Piped Input Context:\n---\n{piped_prefix}\n---\n\n{text}"
                piped_prefix = ""
            else:
                user_message = text

            images_for_turn = pending_images if pending_images else None
            pending_images = []
            _run_assistant_turn(workspace_path, project_name, user_message, verbose, images_for_turn)

        return

    if command == "chat":
        console.print(
            "[red]Error:[/red] `nexcode agent chat` has been removed. "
            "Use [cyan]nexcode agent assistant <project> [message][/cyan] instead."
        )
        sys.exit(1)

    console.print(
        f"[red]Error:[/red] Unknown agent command '{command}'. Supported commands: build, resume, assistant"
    )
    sys.exit(1)
