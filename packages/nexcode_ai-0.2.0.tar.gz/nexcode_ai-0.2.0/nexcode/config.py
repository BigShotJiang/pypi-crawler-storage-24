"""
config.py - Home directory setup and multi-provider Nexcode config management.

nexcode.json structure (v2 - nested, stores both providers):
{
  "active": "grok",
  "grok": {
    "api_key": "xai-...",
    "endpoint": "https://api.x.ai/v1",
    "model": "grok-4-1-fast-reasoning"
  },
  "gemini": {
    "api_key": "AIza...",
    "endpoint": "https://generativelanguage.googleapis.com/v1beta/openai/",
    "model": "gemini-3.1-pro-preview"
  }
}

load_access() returns a backward-compatible flat dict for the active provider.
"""

import json
from pathlib import Path


HOME_DIR = Path.home() / ".nexcode-ai"
LEGACY_ACCESS_FILE = HOME_DIR / "access.json"
NEXCODE_CONFIG_FILE = HOME_DIR / "nexcode.json"
AGENT_CONFIG_FILE = HOME_DIR / "agent.yaml"


PROVIDER_DEFAULTS = {
    "grok": {
        "api_key": "",
        "endpoint": "https://api.x.ai/v1",
        "model": "grok-4-1-fast-reasoning",
    },
    "gemini": {
        "api_key": "",
        "endpoint": "https://generativelanguage.googleapis.com/v1beta/openai/",
        "model": "gemini-3.1-pro-preview",
    },
}

DEFAULT_AGENT_CONFIG = {
    "model": "grok-4-1-fast-reasoning",
    "max_steps": 60,
    "temperature": 0.7,
    "max_rejects": 8,
    "max_step_attempts": 20,
    "coder_context_summary_threshold": 250000,
    "assistant_routing_strategy": "heuristic",
    "assistant_intent_mode": "conservative",
    # When fix_history becomes too large to safely inject into Reporter/Planner prompts,
    # we consolidate it into a dense summary to prevent context-window overflows.
    "fix_history_summary_threshold": 500000,
}


def _default_full_access() -> dict:
    return {
        "active": "grok",
        "grok": dict(PROVIDER_DEFAULTS["grok"]),
        "gemini": dict(PROVIDER_DEFAULTS["gemini"]),
    }


def init_home() -> None:
    """Create ~/.nexcode-ai/ and all default files on first run."""
    HOME_DIR.mkdir(parents=True, exist_ok=True)

    if LEGACY_ACCESS_FILE.exists() and not NEXCODE_CONFIG_FILE.exists():
        LEGACY_ACCESS_FILE.replace(NEXCODE_CONFIG_FILE)

    if not NEXCODE_CONFIG_FILE.exists():
        NEXCODE_CONFIG_FILE.write_text(
            json.dumps(_default_full_access(), indent=2),
            encoding="utf-8",
        )

    if not AGENT_CONFIG_FILE.exists():
        default_yaml = (
            "model: grok-4-1-fast-reasoning\n"
            "max_steps: 60\n"
            "temperature: 0.2\n"
            "max_rejects: 8\n"
            "max_step_attempts: 20\n"
            "coder_context_summary_threshold: 250000\n"
            "assistant_routing_strategy: heuristic\n"
            "assistant_intent_mode: conservative\n"
            "fix_history_summary_threshold: 500000\n"
        )
        AGENT_CONFIG_FILE.write_text(default_yaml, encoding="utf-8")


def load_full_access() -> dict:
    """Load the full nested nexcode.json. Migrates old flat format automatically."""
    init_home()
    try:
        raw = json.loads(NEXCODE_CONFIG_FILE.read_text(encoding="utf-8"))
    except Exception:
        raw = {}

    # Detect old flat format (had top-level "api_key") and migrate
    if "api_key" in raw and "grok" not in raw and "gemini" not in raw:
        provider = raw.get("provider", "grok")
        if provider not in PROVIDER_DEFAULTS:
            provider = "grok"
        migrated = {
            "active": provider,
            "grok": dict(PROVIDER_DEFAULTS["grok"]),
            "gemini": dict(PROVIDER_DEFAULTS["gemini"]),
        }
        migrated[provider]["api_key"] = raw.get("api_key", "")
        migrated[provider]["endpoint"] = raw.get(
            "endpoint",
            PROVIDER_DEFAULTS[provider]["endpoint"],
        )
        migrated[provider]["model"] = raw.get(
            "model",
            PROVIDER_DEFAULTS[provider]["model"],
        )
        save_full_access(migrated)
        return migrated

    full = {"active": raw.get("active", "grok")}
    for provider, defaults in PROVIDER_DEFAULTS.items():
        full[provider] = {**defaults, **raw.get(provider, {})}
    return full


def save_full_access(data: dict) -> None:
    """Save the full nested nexcode.json."""
    init_home()
    NEXCODE_CONFIG_FILE.write_text(json.dumps(data, indent=2), encoding="utf-8")


def load_access() -> dict:
    """
    Load nexcode.json. Returns a flat dict for the active provider.
    Shape: {provider, api_key, endpoint, model}
    """
    full = load_full_access()
    active = full.get("active", "grok")
    pdata = full.get(active, PROVIDER_DEFAULTS.get(active, PROVIDER_DEFAULTS["grok"]))
    return {
        "provider": active,
        "api_key": pdata.get("api_key", ""),
        "endpoint": pdata.get(
            "endpoint",
            PROVIDER_DEFAULTS.get(active, {}).get("endpoint", ""),
        ),
        "model": pdata.get(
            "model",
            PROVIDER_DEFAULTS.get(active, {}).get("model", ""),
        ),
    }


def save_access(data: dict) -> None:
    """
    Save from a flat dict (backward-compat). Updates the active provider's
    section in the nested structure.
    """
    full = load_full_access()
    provider = data.get("provider", full.get("active", "grok"))
    full["active"] = provider
    full.setdefault(provider, dict(PROVIDER_DEFAULTS.get(provider, {})))
    if "api_key" in data:
        full[provider]["api_key"] = data["api_key"]
    if "endpoint" in data:
        full[provider]["endpoint"] = data["endpoint"]
    if "model" in data:
        full[provider]["model"] = data["model"]
    save_full_access(full)


def save_provider_credentials(provider: str, api_key: str, endpoint: str, model: str) -> None:
    """Save or update credentials for a specific provider."""
    full = load_full_access()
    full.setdefault(provider, dict(PROVIDER_DEFAULTS.get(provider, {})))
    full[provider]["api_key"] = api_key
    full[provider]["endpoint"] = endpoint
    full[provider]["model"] = model
    save_full_access(full)


def switch_provider(provider: str) -> None:
    """Switch the active provider and sync agent.yaml."""
    full = load_full_access()
    if provider not in PROVIDER_DEFAULTS:
        raise ValueError(f"Unknown provider: {provider}. Must be one of: {list(PROVIDER_DEFAULTS.keys())}")
    full["active"] = provider
    save_full_access(full)
    active_model = full.get(provider, {}).get("model", PROVIDER_DEFAULTS[provider]["model"])
    save_agent_model(active_model)


def set_provider_model(provider: str, model: str) -> None:
    """Change the model for a specific provider and sync agent.yaml if active."""
    full = load_full_access()
    full.setdefault(provider, dict(PROVIDER_DEFAULTS.get(provider, {})))
    full[provider]["model"] = model
    save_full_access(full)
    if full.get("active") == provider:
        save_agent_model(model)


def is_logged_in() -> bool:
    """Return True if the active provider has an API key configured."""
    acc = load_access()
    return bool(acc.get("endpoint") and acc.get("api_key"))


def is_provider_configured(provider: str) -> bool:
    """Return True if the given provider has an API key saved."""
    full = load_full_access()
    return bool(full.get(provider, {}).get("api_key", ""))


def save_agent_model(model: str) -> None:
    """Update only the model: line in agent.yaml, preserving all other settings."""
    init_home()
    if AGENT_CONFIG_FILE.exists():
        lines = AGENT_CONFIG_FILE.read_text(encoding="utf-8").splitlines()
        new_lines = []
        replaced = False
        for line in lines:
            if line.strip().startswith("model:"):
                new_lines.append(f"model: {model}")
                replaced = True
            else:
                new_lines.append(line)
        if not replaced:
            new_lines.insert(0, f"model: {model}")
        AGENT_CONFIG_FILE.write_text("\n".join(new_lines) + "\n", encoding="utf-8")
    else:
        default_yaml = (
            f"model: {model}\n"
            "max_steps: 60\n"
            "temperature: 0.2\n"
            "max_rejects: 8\n"
            "max_step_attempts: 20\n"
            "coder_context_summary_threshold: 250000\n"
            "assistant_routing_strategy: heuristic\n"
            "assistant_intent_mode: conservative\n"
            "fix_history_summary_threshold: 500000\n"
        )
        AGENT_CONFIG_FILE.write_text(default_yaml, encoding="utf-8")


def _parse_agent_config_text(text: str) -> dict:
    parsed = {}
    for raw_line in str(text or "").split("\n"):
        line = raw_line.strip()
        if not line or line.startswith("#") or ":" not in line:
            continue
        key, value = line.split(":", 1)
        key = key.strip()
        value = value.strip()
        if key in {
            "max_steps",
            "max_rejects",
            "max_step_attempts",
            "coder_context_summary_threshold",
            "fix_history_summary_threshold",
        }:
            parsed[key] = int(value)
        elif key == "temperature":
            parsed[key] = float(value)
        else:
            parsed[key] = value
    return parsed


def _load_agent_config_file(path: Path | None) -> dict:
    if path is None or not path.exists():
        return {}

    try:
        return _parse_agent_config_text(path.read_text(encoding="utf-8").strip())
    except Exception:
        return {}


def load_agent_config(workspace: Path | None = None) -> dict:
    """Load effective agent config. Local .agent/agent.yaml overrides global agent.yaml."""
    init_home()
    config = dict(DEFAULT_AGENT_CONFIG)
    config.update(_load_agent_config_file(AGENT_CONFIG_FILE))

    if workspace is not None:
        try:
            from nexcode.agent_runtime.workspace import get_local_agent_config_file

            local_path = get_local_agent_config_file(Path(workspace))
            config.update(_load_agent_config_file(local_path))
        except Exception:
            pass

    return config
