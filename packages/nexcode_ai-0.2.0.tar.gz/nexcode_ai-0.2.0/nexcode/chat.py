"""
chat.py — Streaming chat with Nexcode.

Uses SSE (Server-Sent Events) streaming from /api/v1/chat/completions.
Session history is persisted to ~/.nexcode-ai/sessions/session1.md.
"""

import json
import sys
from datetime import datetime
from pathlib import Path
from typing import Generator

import requests
from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel

from nexcode.config import (
    HOME_DIR,
    load_access,
    is_logged_in,
)

console = Console()
SESSIONS_DIR = HOME_DIR / "sessions"
SOUL_FILE = HOME_DIR / "SOUL.md"


def get_session_file(session_id: str) -> Path:
    return SESSIONS_DIR / f"{session_id}.md"


def create_session_file(session_id: str) -> None:
    SESSIONS_DIR.mkdir(parents=True, exist_ok=True)
    path = get_session_file(session_id)
    if not path.exists():
        content = (
            f"# Session: {session_id}\n"
            f"_Started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}_\n\n---\n\n"
        )
        path.write_text(content, encoding="utf-8")


class UsageData:
    def __init__(self):
        self.input_tokens = 0
        self.output_tokens = 0
        self.total_tokens = 0
        self.reasoning_tokens = 0


# ─── Session history ──────────────────────────────────────────────────────────

def _load_session_messages(session_id: str) -> list[dict]:
    """
    Parse a session file into a list of OpenAI-style messages.
    We look for **User:** / **Assistant:** markers written by _append_to_session.
    """
    messages: list[dict] = []
    path = get_session_file(session_id)
    if not path.exists():
        return messages

    text = path.read_text(encoding="utf-8")
    for block in text.split("---"):
        lines = block.strip().splitlines()
        user_msg = ""
        asst_msg = ""
        for line in lines:
            if line.startswith("**User:** "):
                user_msg = line[len("**User:** "):]
            elif line.startswith("**Assistant:** "):
                asst_msg = line[len("**Assistant:** "):]
        if user_msg:
            messages.append({"role": "user", "content": user_msg})
        if asst_msg:
            messages.append({"role": "assistant", "content": asst_msg})
    return messages

def _append_to_session(session_id: str, user_msg: str, assistant_msg: str) -> None:
    """Append a conversation turn to the session file."""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M")
    entry = (
        f"\n## [{timestamp}]\n"
        f"**User:** {user_msg}\n"
        f"**Assistant:** {assistant_msg}\n\n"
        f"---\n"
    )
    path = get_session_file(session_id)
    with open(path, "a", encoding="utf-8") as f:
        f.write(entry)


def _build_system_prompt(system_prompt_override: str = None) -> str:
    """Build the system prompt from an override or the global SOUL file."""
    if system_prompt_override:
        return system_prompt_override.strip()

    if not SOUL_FILE.exists():
        return ""

    soul_raw = SOUL_FILE.read_text(encoding="utf-8").strip()
    soul_lines = [line for line in soul_raw.splitlines() if not line.startswith("#")]
    return "\n".join(soul_lines).strip()

# ─── Streaming ────────────────────────────────────────────────────────────────

def _stream_chat(
    endpoint: str,
    api_key: str,
    model: str,
    messages: list[dict],
) -> Generator[str, None, None]:
    """
    POST to chat completions using the OpenAI Python client.
    Yields content tokens as they arrive.
    """
    from openai import OpenAI, APIConnectionError, APIError, AuthenticationError
    import httpx

    client = OpenAI(
        base_url=endpoint,
        api_key=api_key,
        timeout=httpx.Timeout(900.0)
    )

    usage = UsageData() # Initialize UsageData

    try:
        response = client.chat.completions.create(
            model=model,
            messages=messages,
            stream=True,
        )
        for chunk in response:
            if not chunk.choices:
                continue
            token = chunk.choices[0].delta.content
            if token:
                yield token

        # After streaming, attempt to capture usage data from the final response object
        # Note: OpenAI's streaming API typically provides usage in the final chunk or
        # in the response object after iteration. This might need adjustment based on
        # the specific client's behavior for streaming.
        if hasattr(response, 'usage') and response.usage:
            usage.input_tokens = response.usage.get('prompt_tokens', 0) if isinstance(response.usage, dict) else getattr(response.usage, 'prompt_tokens', 0)
            usage.output_tokens = response.usage.get('completion_tokens', 0) if isinstance(response.usage, dict) else getattr(response.usage, 'completion_tokens', 0)
            usage.total_tokens = response.usage.get('total_tokens', 0) if isinstance(response.usage, dict) else getattr(response.usage, 'total_tokens', 0)
            
            if hasattr(response.usage, 'completion_tokens_details') and response.usage.completion_tokens_details:
                usage.reasoning_tokens = getattr(response.usage.completion_tokens_details, 'reasoning_tokens', 0)

    except AuthenticationError:
        yield f"\n[ERROR] Invalid API Key — 401 Unauthorized. Check your xAI API key."
    except APIConnectionError:
        yield f"\n[ERROR] Cannot connect to '{endpoint}'. Check your internet or endpoint config."
    except APIError as exc:
        yield f"\n[ERROR] API Error: {exc.message}"
    except Exception as exc:
        yield f"\n[ERROR] Unexpected error: {exc}"
    finally:
        # Return usage data. For generators, this value is accessible via gen.value after iteration.
        return usage


# ─── Public API ───────────────────────────────────────────────────────────────

def send(prompt: str, session_id: str = None, image_urls: list[str] = None, system_prompt_override: str = None) -> None:
    """
    Main entry: load config, build messages, stream response,
    render to terminal, and save to session file.
    """
    import threading
    import time
    import itertools

    if not is_logged_in():
        console.print(
            Panel(
                "[bold yellow]Not logged in.[/bold yellow]\n"
                "Run [bold cyan]nexcode login[/bold cyan] first.",
                border_style="yellow",
            )
        )
        sys.exit(1)

    acc = load_access()
    endpoint = acc["endpoint"]
    api_key = acc["api_key"]
    model = acc.get("model", "grok-4-1-fast-reasoning")

    soul = _build_system_prompt(system_prompt_override)

    # Build full messages list
    messages: list[dict] = []
    
    if soul:
        messages.append({"role": "system", "content": soul})
    
    if not session_id:
        session_id = datetime.now().strftime("%Y%m%d_%H%M%S")
    create_session_file(session_id)

    messages.extend(_load_session_messages(session_id))
    
    # Handle multimodal input
    if image_urls:
        content_array = []
        if prompt:
            content_array.append({"type": "text", "text": prompt})
        for url in image_urls:
            content_array.append({
                "type": "image_url",
                "image_url": {
                    "url": url
                }
            })
        messages.append({"role": "user", "content": content_array})
    else:
        messages.append({"role": "user", "content": prompt})

    # ── Thread-based thinking spinner ───────────────────────────────────────
    _stop_spinner = threading.Event()

    def _spinner_thread() -> None:
        frames = ["⣾", "⣽", "⣻", "⢿", "⡿", "⣟", "⣯", "⣷"]
        # Fallback ASCII for terminals that can't handle unicode
        ascii_frames = ["|", "/", "-", "\\"]
        try:
            for frame in itertools.cycle(frames):
                if _stop_spinner.is_set():
                    break
                sys.stdout.write(f"\r  {frame} Nexcode is thinking...")
                sys.stdout.flush()
                time.sleep(0.08)
        except Exception:
            for frame in itertools.cycle(ascii_frames):
                if _stop_spinner.is_set():
                    break
                sys.stdout.write(f"\r  {frame} Nexcode is thinking...")
                sys.stdout.flush()
                time.sleep(0.1)

    spinner = threading.Thread(target=_spinner_thread, daemon=True)
    spinner.start()

    # ── Start streaming (this blocks until first token or error) ────────────
    gen = _stream_chat(endpoint, api_key, model, messages)
    first = next(gen, None)

    # ── Stop spinner, clear the spinner line ────────────────────────────────
    _stop_spinner.set()
    spinner.join(timeout=0.5)
    sys.stdout.write("\r" + " " * 50 + "\r")  # clear spinner line
    sys.stdout.flush()

    # ── Stream response to terminal ─────────────────────────────────────────

    collected_tokens: list[str] = []

    if first is not None:
        sys.stdout.write(first)
        sys.stdout.flush()
        collected_tokens.append(first)

    for token in gen:
        sys.stdout.write(token)
        sys.stdout.flush()
        collected_tokens.append(token)

    sys.stdout.write("\n\n")
    sys.stdout.flush()

    # ── Save to session ─────────────────────────────────────────────────────
    full_response = "".join(collected_tokens).strip()
    if full_response and not full_response.startswith("[ERROR]"):
        _append_to_session(session_id, prompt, full_response)

