"""
shell_tools.py — Safe command execution for the agent.
"""
from collections import deque
from dataclasses import dataclass
from datetime import datetime, timezone
from queue import Empty, Queue
import subprocess
import time
import os
import re
import threading
from pathlib import Path
from nexcode.agent_runtime.project_profile import ALL_STACK_SAFE_COMMANDS, detect_project_profile
from nexcode.agent_runtime.task_scope import resolve_task_scope
from nexcode.agent_runtime.excerpts import build_log_output_summary, write_text_artifact
from nexcode.agent_runtime.tool_registry import register_tool
from nexcode.agent_runtime.workspace import (
    get_logs_dir,
    get_project_root,
    get_step_scratch_dir,
    is_scratch_path,
    load_agent_state,
    normalize_rel_path,
    relativize_agent_path,
    resolve_agent_path,
)

# Restrict commands to safe, stack-aware toolchains.
ALLOWED_COMMANDS = set(ALL_STACK_SAFE_COMMANDS)

LOCAL_FILESYSTEM_COMMANDS = {
    "mkdir", "md", "move", "mv", "copy", "cp", "ren", "rename", "del", "rm", "rmdir", "rd"
}

BLOCKED_COMMAND_HINTS = {
    "powershell": "Use `run_command` with approved commands or the structured repo tools instead of PowerShell.",
    "bash": "Use approved local commands only.",
    "sh": "Use approved local commands only.",
    "curl": "Network download commands are blocked for security reasons.",
    "wget": "Network download commands are blocked for security reasons.",
}

SAFE_GIT_COMMANDS = {
    "status", "diff", "log", "show", "branch", "add", "commit", "push", "pull", "checkout"
}

# Track background processes: { pid: { "process": Popen, "log": Path, "cmd": str } }
BACKGROUND_PROCESSES = {}


@dataclass
class CommandRunResult:
    command: str
    cwd: str
    target_file: str = ""
    exit_code: int | None = None
    status: str = ""
    duration_sec: float = 0.0
    started_at_utc: str = ""
    ended_at_utc: str = ""
    artifact_path: str = ""
    output_preview: str = ""
    full_output_chars: int = 0


def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _allowed_commands_for_workspace(workspace: Path | None = None) -> set[str]:
    if workspace is None:
        return set(ALLOWED_COMMANDS)
    try:
        state = load_agent_state(workspace)
        plan = state.get("plan", [])
        current_step = int(state.get("current_step", 0) or 0)
        plan_item = None
        if isinstance(plan, list) and current_step > 0 and current_step <= len(plan):
            candidate = plan[current_step - 1]
            if isinstance(candidate, dict):
                plan_item = candidate
        checked_files = state.get("investigation_checked_files", [])
        plan_files = list(plan_item.get("files", [])) if isinstance(plan_item, dict) else []
        task_scope = resolve_task_scope(
            workspace,
            user_message=str(state.get("last_user_goal") or ""),
            checked_files=checked_files if isinstance(checked_files, list) else [],
            plan_files=plan_files,
        )
        return detect_project_profile(workspace, plan_item=plan_item, task_scope=task_scope).allowed_commands
    except Exception:
        return set(ALLOWED_COMMANDS)


def _command_artifact_dir(workspace: Path) -> Path:
    return get_logs_dir(workspace) / "command_artifacts"


def _prepare_run_command_request(workspace: Path, cmd: str, path: str) -> tuple[Path | None, str | None]:
    if not cmd.strip():
        return None, "Error: Empty command."

    try:
        exec_dir = resolve_agent_path(workspace, path)
        if is_scratch_path(path):
            exec_dir.mkdir(parents=True, exist_ok=True)
        if not exec_dir.exists() or not exec_dir.is_dir():
            return None, f"Error: Directory not found: {path}"
    except Exception as e:
        return None, f"Error resolving path {path}: {str(e)}"

    words = re.findall(r'[a-zA-Z0-9_\-]+', cmd.lower())
    suspicious = {"wget", "curl", "bash", "sh", "sudo", "su"}
    for w in words:
        if w in suspicious:
            return None, f"Error: Command contains forbidden keyword '{w}' for security reasons."

    validation_error = _validate_command(cmd, workspace=workspace, exec_dir=exec_dir)
    if validation_error:
        return None, validation_error

    return exec_dir, None


def _format_command_output(workspace: Path, output: str, *, failed: bool, artifact_prefix: str) -> str:
    rendered, _ = build_log_output_summary(
        output,
        failed=failed,
        artifact_dir=_command_artifact_dir(workspace),
        artifact_prefix=artifact_prefix,
    )
    return rendered


def _truncate_preview_line(text: str, limit: int = 300) -> str:
    cleaned = (text or "").rstrip("\r\n")
    if len(cleaned) <= limit:
        return cleaned
    return f"{cleaned[: max(0, limit - 15)]}... [truncated]"


def _flush_live_tail_batch(tail_callback, pending_batch: list[str]) -> None:
    if not tail_callback or not pending_batch:
        pending_batch.clear()
        return
    omitted = max(0, len(pending_batch) - 5)
    lines = [_truncate_preview_line(line, limit=200) for line in pending_batch[-5:]]
    try:
        tail_callback(lines, omitted)
    except Exception:
        pass
    pending_batch.clear()


def _build_interactive_output_preview(
    *,
    first_lines: list[str],
    tail_lines: deque[str],
    total_lines: int,
    total_chars: int,
) -> str:
    if total_chars <= 0:
        return "Command executed successfully with no output."

    trimmed_first = [_truncate_preview_line(line) for line in first_lines if line is not None]
    trimmed_tail = [_truncate_preview_line(line) for line in list(tail_lines) if line is not None]

    if total_lines <= 18 and total_chars <= 8000:
        combined = trimmed_first
        for line in trimmed_tail:
            if len(combined) >= total_lines:
                break
            if line not in combined:
                combined.append(line)
        rendered = "\n".join(line for line in combined if line)
        return rendered or "Command executed successfully with no output."

    if total_lines <= 1:
        source = trimmed_first[0] if trimmed_first else (trimmed_tail[-1] if trimmed_tail else "")
        if total_chars > len(source):
            return f"Output preview (truncated from {total_chars} chars):\n{source}"
        return source or "Command executed successfully with no output."

    head = trimmed_first[:5]
    tail = trimmed_tail[-5:]
    preview_lines = [f"Output preview ({total_lines} lines):"]
    for idx, line in enumerate(head, start=1):
        preview_lines.append(f"L{idx}: {line}")

    omitted = max(0, total_lines - len(head) - len(tail))
    if omitted > 0:
        preview_lines.append(f"... [{omitted} middle lines omitted] ...")

    start_line = max(len(head) + 1, total_lines - len(tail) + 1)
    for offset, line in enumerate(tail):
        preview_lines.append(f"L{start_line + offset}: {line}")

    return "\n".join(preview_lines)




def _resolve_scratch_in_command(workspace: Path, cmd: str) -> str:
    """
    Replace all 'scratch:...' snippets in a command string with their
    actual absolute filesystem paths.
    """
    def _replacer(match):
        path_str = match.group(0)
        try:
            from nexcode.agent_runtime.workspace import resolve_agent_path
            return str(resolve_agent_path(workspace, path_str))
        except Exception:
            return path_str

    # Match scratch: followed by non-whitespace shell-like characters
    return re.sub(r'scratch:[a-zA-Z0-9_\-./\\]+', _replacer, cmd)

def _prepare_cli_command(command: list[str]) -> list[str]:
    if os.name == "nt" and command and command[0].lower() in {"npm", "npx", "pnpm", "yarn"}:
        return ["cmd", "/c", *command]
    return command


def _is_dev_server_command(cmd: str) -> bool:
    normalized = cmd.lower()
    return any(
        pattern in normalized
        for pattern in ("npm run dev", "pnpm dev", "yarn dev", "next dev", "vite --host", "vite")
    )


def _stop_process_entry(pid: int, proc_info: dict) -> None:
    process: subprocess.Popen = proc_info["process"]
    if os.name == 'nt':
        subprocess.run(['taskkill', '/F', '/T', '/PID', str(pid)], capture_output=True)
    else:
        process.terminate()
        process.wait(timeout=5)


def _run_cli_command(
    workspace: Path,
    exec_dir: Path,
    command: list[str],
    timeout: int = 900,
    env: dict | None = None,
) -> tuple[int, str]:
    try:
        result = subprocess.run(
            _prepare_cli_command(command),
            cwd=exec_dir,
            capture_output=True,
            text=True,
            timeout=timeout,
            env=env,
            shell=False,
            encoding="utf-8",
            errors="replace"
        )
    except subprocess.TimeoutExpired:
        return 1, f"ERROR: Command timed out after {timeout} seconds."
    except FileNotFoundError:
        return 1, f"ERROR: Command not found: {command[0]}"
    except Exception as e:
        return 1, f"ERROR: {e}"

    output = (result.stdout or "") + (result.stderr or "")
    rendered = _format_command_output(
        workspace,
        output,
        failed=result.returncode != 0,
        artifact_prefix="_".join(command[:3]) or "cli_command",
    )
    return result.returncode, rendered


def _shadcn_support_files_exist(project_root: Path) -> bool:
    if not (project_root / "components.json").exists():
        return False
    return any(
        path.exists()
        for path in (
            project_root / "lib" / "utils.ts",
            project_root / "src" / "lib" / "utils.ts",
            project_root / "components" / "ui",
            project_root / "src" / "components" / "ui",
        )
    )


def _resolve_component_dir(project_root: Path) -> Path:
    src_dir = project_root / "src" / "components" / "ui"
    if src_dir.exists() or (project_root / "src").exists():
        return src_dir
    return project_root / "components" / "ui"


def _split_command_segments(cmd: str) -> list[str]:
    """
    Split shell command chains while preserving separators inside quoted strings.

    This keeps validation compatible with inline scripts such as:
      node -e "const fs = require('fs'); console.log(fs.existsSync('src'))"
    """
    segments: list[str] = []
    current: list[str] = []
    quote_char: str | None = None
    i = 0

    while i < len(cmd):
        ch = cmd[i]

        # Treat caret as an escape marker for the following character in cmd.exe.
        if ch == "^" and i + 1 < len(cmd):
            current.append(ch)
            i += 1
            current.append(cmd[i])
            i += 1
            continue

        if quote_char:
            current.append(ch)
            if ch == quote_char:
                backslashes = 0
                j = i - 1
                while j >= 0 and cmd[j] == "\\":
                    backslashes += 1
                    j -= 1
                if backslashes % 2 == 0:
                    quote_char = None
            i += 1
            continue

        if ch in {'"', "'"}:
            quote_char = ch
            current.append(ch)
            i += 1
            continue

        two_char = cmd[i:i + 2]
        if two_char in {"&&", "||"}:
            segment = "".join(current).strip()
            if segment:
                segments.append(segment)
            current = []
            i += 2
            continue

        if ch in {"&", "|", ";", "\n", "\r"}:
            segment = "".join(current).strip()
            if segment:
                segments.append(segment)
            current = []
            i += 1
            continue

        current.append(ch)
        i += 1

    segment = "".join(current).strip()
    if segment:
        segments.append(segment)

    return segments


def _normalize_command_segment(segment: str) -> str:
    normalized = segment.strip()
    if normalized.lower().startswith("cmd /c "):
        normalized = normalized[7:].strip()
    return normalized


def _tokenize_command_segment(segment: str) -> list[str]:
    normalized = _normalize_command_segment(segment)
    if not normalized:
        return []
    return re.findall(r'"[^"]*"|\'[^\']*\'|\S+', normalized)


def _strip_shell_quotes(token: str) -> str:
    if len(token) >= 2 and token[0] == token[-1] and token[0] in {'"', "'"}:
        return token[1:-1]
    return token


def _extract_command_head(segment: str) -> tuple[str, list[str]]:
    """Extract the primary command and token arguments from one shell segment."""
    tokens = _tokenize_command_segment(segment)
    if not tokens:
        return "", []
    command = _strip_shell_quotes(tokens[0]).lower()
    args = [_strip_shell_quotes(token) for token in tokens[1:]]
    return command, args


def _is_flag_token(command: str, token: str) -> bool:
    normalized = token.strip().lower()
    if not normalized:
        return True
    if normalized.startswith("-"):
        return True
    if command in {"del", "rmdir", "rd"} and normalized in {"/f", "/q", "/s"}:
        return True
    if command in {"copy", "xcopy"} and normalized in {"/y"}:
        return True
    return False


def _is_relative_shell_path(token: str) -> bool:
    normalized = _strip_shell_quotes(token).strip()
    if not normalized or "*" in normalized or "?" in normalized:
        return False
    if normalized.startswith(("\\\\", "//", "/", "~")):
        return False
    if re.match(r"^[A-Za-z]:", normalized):
        return False
    return True


def _allowed_command_roots(workspace: Path) -> list[Path]:
    return [get_project_root(workspace).resolve(), get_step_scratch_dir(workspace).resolve()]


def _resolve_command_path(exec_dir: Path, token: str, *, rename_base: Path | None = None) -> Path:
    cleaned = _strip_shell_quotes(token).strip()
    if not _is_relative_shell_path(cleaned):
        raise ValueError(f"Path '{token}' must stay relative to the project or scratch directory.")
    base_dir = rename_base if rename_base is not None else exec_dir
    return (base_dir / cleaned).resolve()


def _ensure_allowed_command_path(workspace: Path, candidate: Path, token: str) -> None:
    for root in _allowed_command_roots(workspace):
        try:
            candidate.relative_to(root)
            return
        except ValueError:
            continue
    raise ValueError(f"Path '{token}' escapes the resolved workspace project root or active scratch directory.")


def _relativize_command_path(workspace: Path, candidate: Path) -> str:
    return normalize_rel_path(relativize_agent_path(workspace, candidate))


def _analyze_command_paths(workspace: Path, cmd: str, exec_dir: Path) -> tuple[list[str], str | None]:
    touched_paths: list[str] = []
    seen: set[str] = set()
    segments = _split_command_segments(cmd)
    if not segments:
        return [], "Error: Empty command."

    for segment in segments:
        command, raw_args = _extract_command_head(segment)
        if command not in LOCAL_FILESYSTEM_COMMANDS:
            continue
        operands = [arg for arg in raw_args if not _is_flag_token(command, arg)]
        if command in {"mkdir", "md", "del", "rm", "rmdir", "rd"}:
            if not operands:
                return [], f"Error: Command '{command}' requires at least one relative path."
            resolved_operands = []
            for operand in operands:
                try:
                    candidate = _resolve_command_path(exec_dir, operand)
                    _ensure_allowed_command_path(workspace, candidate, operand)
                    resolved_operands.append(candidate)
                except ValueError as exc:
                    return [], f"Error: {exc}"
            for candidate in resolved_operands:
                rel = _relativize_command_path(workspace, candidate)
                if rel not in seen:
                    seen.add(rel)
                    touched_paths.append(rel)
        elif command in {"move", "mv", "copy", "cp"}:
            if len(operands) != 2:
                return [], f"Error: Command '{command}' requires exactly one source and one destination path."
            try:
                source = _resolve_command_path(exec_dir, operands[0])
                destination = _resolve_command_path(exec_dir, operands[1])
                _ensure_allowed_command_path(workspace, source, operands[0])
                _ensure_allowed_command_path(workspace, destination, operands[1])
            except ValueError as exc:
                return [], f"Error: {exc}"
            for candidate in (source, destination):
                rel = _relativize_command_path(workspace, candidate)
                if rel not in seen:
                    seen.add(rel)
                    touched_paths.append(rel)
        elif command in {"ren", "rename"}:
            if len(operands) != 2:
                return [], f"Error: Command '{command}' requires an existing path and a new name or destination."
            try:
                source = _resolve_command_path(exec_dir, operands[0])
                rename_target = operands[1]
                rename_base = source.parent if "/" not in rename_target and "\\" not in rename_target else None
                destination = _resolve_command_path(exec_dir, rename_target, rename_base=rename_base)
                _ensure_allowed_command_path(workspace, source, operands[0])
                _ensure_allowed_command_path(workspace, destination, operands[1])
            except ValueError as exc:
                return [], f"Error: {exc}"
            for candidate in (source, destination):
                rel = _relativize_command_path(workspace, candidate)
                if rel not in seen:
                    seen.add(rel)
                    touched_paths.append(rel)

    return touched_paths, None

def extract_command_paths(workspace: Path, cmd: str, path: str = ".") -> set[str]:
    try:
        exec_dir = resolve_agent_path(workspace, path)
    except Exception:
        return set()
    touched_paths, error = _analyze_command_paths(workspace, cmd, exec_dir)
    if error:
        return set()
    return {normalize_rel_path(item) for item in touched_paths if item}


def _validate_command(cmd: str, workspace: Path | None = None, exec_dir: Path | None = None) -> str | None:
    """Validate every shell segment before execution."""
    segments = _split_command_segments(cmd)
    if not segments:
        return "Error: Empty command."

    allowed_commands = _allowed_commands_for_workspace(workspace)

    for segment in segments:
        command, args = _extract_command_head(segment)
        if not command:
            return f"Error: Could not parse command segment '{segment}'."
        if command not in allowed_commands:
            hint = BLOCKED_COMMAND_HINTS.get(command)
            if hint:
                return f"Error: Command '{command}' is not allowed. {hint}"
            return f"Error: Command '{command}' is not allowed for the detected project stack. Use approved tooling only."
        if command == "git":
            subcommand = next((arg.lower() for arg in args if not str(arg).startswith("-")), "")
            if subcommand not in SAFE_GIT_COMMANDS:
                return f"Error: Git subcommand '{subcommand or 'unknown'}' is not allowed."

    if workspace is not None and exec_dir is not None:
        _, path_error = _analyze_command_paths(workspace, cmd, exec_dir)
        if path_error:
            return path_error

    return None

@register_tool("run_command")
def run_command(workspace: Path, cmd: str, path: str = ".", background: bool = False) -> str:
    """
    Run a terminal command safely. Allows predefined safe commands and chaining (e.g., cd dir && npm install).
    If background=True, starts the process and returns immediately.
    The 'path' argument specifies the working directory relative to the workspace.
    """
    exec_dir, prep_error = _prepare_run_command_request(workspace, cmd, path)
    if prep_error:
        return prep_error

    # Auto-resolve scratch: paths in the command string so the shell understands them
    cmd = _resolve_scratch_in_command(workspace, cmd)
            
    try:
        if background:
            log_dir = get_logs_dir(workspace) / "background"
            log_dir.mkdir(parents=True, exist_ok=True)
            log_file = log_dir / f"proc_{int(time.time())}.log"
            stopped_pids = []

            if _is_dev_server_command(cmd):
                for pid, proc_info in list(BACKGROUND_PROCESSES.items()):
                    same_dir = Path(proc_info.get("cwd", "")) == exec_dir
                    if same_dir and _is_dev_server_command(proc_info.get("cmd", "")):
                        try:
                            _stop_process_entry(pid, proc_info)
                        except Exception:
                            pass
                        finally:
                            BACKGROUND_PROCESSES.pop(pid, None)
                            stopped_pids.append(pid)
            
            # Start process in background
            creationflags = 0
            if os.name == 'nt':
                # CREATE_NEW_PROCESS_GROUP = 0x00000200
                creationflags = 0x00000200
            
            with open(log_file, "w", encoding="utf-8") as f:
                proc = subprocess.Popen(
                    cmd,
                    shell=True,
                    cwd=exec_dir,
                    stdout=f,
                    stderr=subprocess.STDOUT,
                    text=True,
                    creationflags=creationflags,
                    encoding="utf-8",
                    errors="replace"
                )
            
            BACKGROUND_PROCESSES[proc.pid] = {
                "process": proc,
                "log": log_file,
                "cmd": cmd,
                "cwd": str(exec_dir),
                "start_time": time.time()
            }

            if stopped_pids:
                return (
                    f"Stopped stale background process(es) {', '.join(str(pid) for pid in stopped_pids)}. "
                    f"Started background process {proc.pid}: '{cmd}'. Output is being logged to {log_file.name}."
                )
            return f"Started background process {proc.pid}: '{cmd}'. Output is being logged to {log_file.name}."

        result = subprocess.run(
            cmd,
            shell=True,
            cwd=exec_dir,
            capture_output=True,
            text=True,
            timeout=900,
            encoding="utf-8",
            errors="replace"
        )
        output = result.stdout + result.stderr

        rendered = _format_command_output(
            workspace,
            output,
            failed=result.returncode != 0,
            artifact_prefix="run_command",
        )

        if result.returncode != 0:
            return f"Error: Command failed with exit code {result.returncode}.\nOutput:\n{rendered}"

        return rendered
    except subprocess.TimeoutExpired:
        return f"Error: Command '{cmd}' timed out after 900 seconds."
    except Exception as e:
        return f"Error running command '{cmd}': {str(e)}"


def run_command_interactive(
    workspace: Path,
    cmd: str,
    path: str = ".",
    verbose: bool = False,
    status_callback=None,
    tail_callback=None,
    timeout: int = 900,
) -> CommandRunResult:
    sentinel = object()
    started_at_iso = _utc_now_iso()
    turn_started = time.time()
    exec_dir, prep_error = _prepare_run_command_request(workspace, cmd, path)
    if prep_error:
        return CommandRunResult(
            command=cmd,
            cwd=str(path),
            status="blocked",
            started_at_utc=started_at_iso,
            ended_at_utc=_utc_now_iso(),
            duration_sec=max(0.0, time.time() - turn_started),
            output_preview=prep_error,
        )

    # Auto-resolve scratch: paths in the command string so the shell understands them
    cmd = _resolve_scratch_in_command(workspace, cmd)

    artifact_path = write_text_artifact(_command_artifact_dir(workspace), "run_command", "")
    line_queue: Queue[object] = Queue()
    first_lines: list[str] = []
    tail_lines: deque[str] = deque(maxlen=8)
    latest_meaningful = ""
    pending_batch: list[str] = []
    total_chars = 0
    total_lines = 0
    timed_out = False

    try:
        proc = subprocess.Popen(
            cmd,
            shell=True,
            cwd=exec_dir,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
            encoding="utf-8",
            errors="replace",
        )
    except Exception as e:
        return CommandRunResult(
            command=cmd,
            cwd=str(exec_dir),
            status="error",
            started_at_utc=started_at_iso,
            ended_at_utc=_utc_now_iso(),
            duration_sec=max(0.0, time.time() - turn_started),
            artifact_path=str(artifact_path),
            output_preview=f"Error running command '{cmd}': {e}",
        )

    def _reader(stdout, queue_obj: Queue[object], log_path: Path) -> None:
        with log_path.open("a", encoding="utf-8") as log_file:
            try:
                if stdout is not None:
                    for chunk in iter(stdout.readline, ""):
                        if not chunk:
                            break
                        log_file.write(chunk)
                        log_file.flush()
                        queue_obj.put(chunk)
                    remainder = stdout.read() if stdout else ""
                    if remainder:
                        log_file.write(remainder)
                        log_file.flush()
                        queue_obj.put(remainder)
            finally:
                queue_obj.put(sentinel)

    reader = threading.Thread(target=_reader, args=(proc.stdout, line_queue, artifact_path), daemon=True)
    reader.start()

    last_status_update = 0.0
    last_tail_flush = time.time()
    sentinel_received = False

    while True:
        now = time.time()
        if not timed_out and proc.poll() is None and (now - turn_started) > timeout:
            timed_out = True
            try:
                proc.kill()
            except Exception:
                pass

        try:
            chunk = line_queue.get(timeout=0.1)
        except Empty:
            chunk = None

        if chunk is sentinel:
            sentinel_received = True
        elif chunk is None:
            pass
        else:
            for line in chunk.splitlines():
                total_lines += 1
                total_chars += len(line) + 1
                stripped = line.rstrip("\r\n")
                if len(first_lines) < 8:
                    first_lines.append(stripped)
                tail_lines.append(stripped)
                if stripped.strip():
                    latest_meaningful = stripped.strip()
                if verbose:
                    pending_batch.append(stripped)

        elapsed = time.time() - turn_started
        if status_callback and (elapsed - last_status_update) >= 0.25:
            try:
                status_callback(elapsed, latest_meaningful)
            except Exception:
                pass
            last_status_update = elapsed

        if verbose and pending_batch and (len(pending_batch) >= 10 or (time.time() - last_tail_flush) >= 2.0):
            _flush_live_tail_batch(tail_callback, pending_batch)
            last_tail_flush = time.time()

        if sentinel_received and proc.poll() is not None and line_queue.empty():
            break

    reader.join(timeout=1.0)
    _flush_live_tail_batch(tail_callback, pending_batch)

    if total_chars <= 0 and artifact_path.exists():
        artifact_text = artifact_path.read_text(encoding="utf-8")
        total_chars = len(artifact_text)
        if artifact_text and not first_lines:
            split_lines = artifact_text.splitlines()
            total_lines = len(split_lines)
            first_lines.extend(split_lines[:8])
            for line in split_lines[-8:]:
                tail_lines.append(line)

    exit_code = proc.returncode
    status = "timed_out" if timed_out else ("success" if exit_code == 0 else "failed")
    preview = _build_interactive_output_preview(
        first_lines=first_lines,
        tail_lines=tail_lines,
        total_lines=total_lines,
        total_chars=total_chars,
    )
    ended_at_iso = _utc_now_iso()

    return CommandRunResult(
        command=cmd,
        cwd=str(exec_dir),
        exit_code=exit_code,
        status=status,
        duration_sec=max(0.0, time.time() - turn_started),
        started_at_utc=started_at_iso,
        ended_at_utc=ended_at_iso,
        artifact_path=str(artifact_path),
        output_preview=preview,
        full_output_chars=total_chars,
    )


@register_tool("scaffold_next_app")
def scaffold_next_app(
    workspace: Path,
    app_name: str = "app",
    use_tailwind: bool = True,
    use_src_dir: bool = True,
    package_manager: str = "npm",
    target_dir: str | None = None,
) -> str:
    """
    Scaffold a Next.js app into the resolved workspace project root or a subdirectory inside it.
    Returns success only if package.json is created.
    """
    project_root = get_project_root(workspace)
    try:
        project_root.mkdir(parents=True, exist_ok=True)
    except Exception as e:
        return f"ERROR: could not prepare project root: {e}"

    normalized_target_dir = normalize_rel_path(str(target_dir or "")).rstrip("/")
    if normalized_target_dir in {"", "."}:
        normalized_target_dir = ""
    if normalized_target_dir.startswith("scratch:"):
        return "ERROR: target_dir must stay inside the resolved workspace project root."

    try:
        target_root = resolve_agent_path(workspace, normalized_target_dir or ".")
    except Exception as e:
        return f"ERROR: invalid target_dir: {e}"

    if target_root == workspace.resolve() and project_root != workspace.resolve():
        target_root = project_root

    target_label = normalized_target_dir or "."
    target_arg = normalized_target_dir or "."

    try:
        target_root.parent.mkdir(parents=True, exist_ok=True)
    except Exception as e:
        return f"ERROR: could not prepare target parent directory: {e}"

    try:
        existing_entries = [p.name for p in target_root.iterdir()] if target_root.exists() else []
    except Exception as e:
        return f"ERROR: could not inspect target directory: {e}"

    if existing_entries:
        return (
            f"ERROR: target directory '{target_label}' is not empty. "
            "Scaffold only into an empty directory inside the resolved workspace project root."
        )

    manager_flags = {
        "npm": "--use-npm",
        "pnpm": "--use-pnpm",
        "yarn": "--use-yarn",
    }
    manager_flag = manager_flags.get(package_manager.lower())
    if not manager_flag:
        return f"ERROR: unsupported package manager '{package_manager}'. Use npm, pnpm, or yarn."

    command = [
        "npx",
        "create-next-app@latest",
        target_arg,
        "--ts",
        "--eslint",
        "--app",
        "--yes",
        "--disable-git",
        "--import-alias",
        "@/*",
        manager_flag,
    ]
    if use_tailwind:
        command.append("--tailwind")
    if use_src_dir:
        command.append("--src-dir")

    env = os.environ.copy()
    env["CI"] = "1"
    env["NEXT_TELEMETRY_DISABLED"] = "1"

    try:
        returncode, output = _run_cli_command(workspace, project_root, command, timeout=900, env=env)
    except Exception as e:
        return f"ERROR: failed to scaffold Next.js app: {e}"
    package_json = target_root / "package.json"
    if returncode != 0:
        if "Command not found: npx" in output:
            return "ERROR: npx is not installed or not available on PATH."
        return f"ERROR: create-next-app failed with exit code {returncode}.\nOutput:\n{output}"
    if not package_json.exists():
        return (
            f"ERROR: create-next-app did not produce package.json in '{target_label}'.\n"
            f"Output:\n{output}"
        )

    location = "project root" if not normalized_target_dir else normalized_target_dir
    return f"SUCCESS: Next.js app scaffolded in {location} for '{app_name}'.\nOutput:\n{output}"


@register_tool("setup_shadcn")
def setup_shadcn(
    workspace: Path,
    template: str = "next",
    base: str = "radix",
    css_variables: bool = True,
    force: bool = False,
    preset: str = "",
) -> str:
    """
    Initialize shadcn/ui in the resolved workspace project root and verify support files exist.
    """
    project_root = get_project_root(workspace)
    if not (project_root / "package.json").exists():
        return "ERROR: Cannot initialize shadcn/ui before the project has been scaffolded."

    command = ["npx", "shadcn@latest", "init", "--template", template, "--base", base, "--yes"]
    if css_variables:
        command.append("--css-variables")
    if force:
        command.append("--force")
    if preset:
        command.extend(["--preset", preset])

    env = os.environ.copy()
    env["CI"] = "1"
    returncode, output = _run_cli_command(workspace, project_root, command, timeout=900, env=env)
    if returncode != 0:
        return f"ERROR: shadcn init failed with exit code {returncode}.\nOutput:\n{output}"
    if not _shadcn_support_files_exist(project_root):
        return (
            "ERROR: shadcn init completed but required files were not created.\n"
            "Expected components.json and lib/utils.ts or a generated ui directory.\n"
            f"Output:\n{output}"
        )
    return f"SUCCESS: shadcn/ui initialized successfully.\nOutput:\n{output}"


@register_tool("add_shadcn_components")
def add_shadcn_components(workspace: Path, components: list[str]) -> str:
    """
    Add shadcn/ui components and verify their primary files exist when applicable.
    """
    project_root = get_project_root(workspace)
    if not _shadcn_support_files_exist(project_root):
        return "ERROR: shadcn/ui is not initialized yet. Run setup_shadcn first."
    if not components:
        return "ERROR: No shadcn components were provided."

    component_dir = _resolve_component_dir(project_root)
    created = []
    failures = []
    outputs = []

    for component in components:
        normalized = component.strip()
        if not normalized:
            continue
        command = ["npx", "shadcn@latest", "add", normalized, "--yes"]
        env = os.environ.copy()
        env["CI"] = "1"
        returncode, output = _run_cli_command(workspace, project_root, command, timeout=900, env=env)
        outputs.append(f"[{normalized}]\n{output}")
        expected_file = component_dir / f"{normalized}.tsx"
        if returncode == 0:
            if expected_file.exists() or normalized in {"form", "date-picker"}:
                created.append(normalized)
            else:
                failures.append(f"{normalized}: command succeeded but expected file was not found")
        else:
            failures.append(f"{normalized}: {output}")

    if failures:
        return (
            "ERROR: Failed to add one or more shadcn components.\n"
            f"Created: {', '.join(created) if created else 'none'}\n"
            + "\n".join(failures)
        )

    rendered_output = _format_command_output(
        workspace,
        "\n".join(outputs),
        failed=bool(failures),
        artifact_prefix="add_shadcn_components",
    )
    return f"SUCCESS: Added shadcn component(s): {', '.join(created)}.\nOutput:\n{rendered_output}"

@register_tool("stop_command")
def stop_command(workspace: Path, pid: int) -> str:
    """
    Stop a background process by its PID.
    """
    if pid not in BACKGROUND_PROCESSES:
        return f"Error: Process {pid} not found or already terminated."

    proc_info = BACKGROUND_PROCESSES[pid]
    process: subprocess.Popen = proc_info["process"]
    
    try:
        _stop_process_entry(pid, proc_info)
            
        del BACKGROUND_PROCESSES[pid]
        return f"Successfully stopped process {pid}: '{proc_info['cmd']}'."
    except Exception as e:
        return f"Error stopping process {pid}: {str(e)}"

@register_tool("wait_for_output")
def wait_for_output(workspace: Path, match_string: str, timeout: int = 60, pid: int = None) -> str:
    """
    Wait for a specific string to appear in the output of a background process.
    If pid is not provided, uses the most recently started process.
    """
    if not BACKGROUND_PROCESSES:
        return "Error: No background processes are running."

    target_pid = pid
    if target_pid is None:
        # Get the most recent PID
        target_pid = max(BACKGROUND_PROCESSES.keys(), key=lambda k: BACKGROUND_PROCESSES[k]["start_time"])
    
    if target_pid not in BACKGROUND_PROCESSES:
        return f"Error: Process {target_pid} not found."

    proc_info = BACKGROUND_PROCESSES[target_pid]
    log_file: Path = proc_info["log"]
    process: subprocess.Popen = proc_info["process"]
    
    start_wait = time.time()
    while time.time() - start_wait < timeout:
        if log_file.exists():
            content = log_file.read_text(encoding="utf-8")
            if match_string in content:
                return f"Found match '{match_string}' in process {target_pid} output after {int(time.time() - start_wait)}s."
        
        # Check if process died
        if process.poll() is not None:
            tail = ""
            if log_file.exists():
                try:
                    content = log_file.read_text(encoding="utf-8", errors="ignore")
                    tail, _ = build_log_output_summary(
                        content,
                        failed=True,
                        artifact_path=log_file,
                        artifact_prefix="background_process",
                    )
                except Exception:
                    tail = ""
            if tail:
                return (
                    f"Error: Process {target_pid} terminated early before match was found.\n"
                    f"Last output:\n{tail}"
                )
            return f"Error: Process {target_pid} terminated early before match was found."
            
        time.sleep(1)
        
    return f"Error: Timed out waiting for '{match_string}' in process {target_pid} output after {timeout}s."
