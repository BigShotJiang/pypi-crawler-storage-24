from aioq3rcon import Client
from clypi import Command, Spinner, arg
from typing_extensions import override

from q3rcon_cli import console


class Mapname(Command):
    """Prints the current map name of the server."""

    host: str = arg(inherited=True)
    port: int = arg(inherited=True)
    password: str = arg(inherited=True)

    @override
    async def run(self):
        async with Spinner('Getting map name...'):
            async with Client(self.host, self.port, self.password) as client:
                response = await client.send_command('mapname')

        console.out.print_cvar(response)
