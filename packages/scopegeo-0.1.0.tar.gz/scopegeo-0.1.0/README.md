# ScopeGeo CLI

Geospatial data scoping from the terminal. Find the best satellite imagery and spatial datasets for your project — ranked, scored, and assessed for feasibility.

Powered by [ScopeGeo](http://130.162.194.71).

## Install

```bash
pip install scopegeo
```

Requires Python 3.11+. No API key needed for free-tier features.

## Quick Start

```bash
# Check connectivity to ScopeGeo API
scopegeo health

# Create a scope from a natural language brief
scopegeo scope new "Monitor vegetation on a 500ha mine site near Emerald QLD, monthly for 12 months"

# View results for a scope
scopegeo scope view <scope_id>

# Download a PDF compliance report
scopegeo scope report <scope_id> --output report.pdf

# Compare recommendations side-by-side
scopegeo scope compare <scope_id>
```

## Search

```bash
# Browse free satellite data providers
scopegeo search providers --free-only

# Filter by resolution
scopegeo search providers --resolution 10

# Search STAC catalogs for recent scenes
scopegeo search stac --collection sentinel-2-l2a --bbox 144,-38,145,-37
```

## Projects

```bash
# List your project workspaces
scopegeo project list

# Create a new project
scopegeo project create "Mine Rehabilitation Monitoring"
```

## AI Agents

```bash
# List available AI agents
scopegeo agents list

# Run an agent on a scope
scopegeo agents run methodology_writer --scope <scope_id>
```

## Configuration

Config is stored at `~/.scopegeo/config.yaml`:

```bash
# View current config
scopegeo config show

# Point to a different API (e.g., local dev server)
scopegeo config set api_url http://localhost:8000

# Point to production (default)
scopegeo config set api_url http://130.162.194.71
```

## Authentication

```bash
scopegeo auth login --email user@example.com
scopegeo auth status
scopegeo auth logout
```

Authentication is optional for core scoping features. Required for projects, agents, and alert subscriptions.

## Also Available

- **Web app**: [http://130.162.194.71](http://130.162.194.71)
- **MCP Server**: Connect ScopeGeo to Claude, Cursor, Windsurf, and other AI assistants
- **REST API**: Full OpenAPI docs at [/docs](http://130.162.194.71/docs)
