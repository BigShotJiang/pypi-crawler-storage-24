"""Shared fixtures for CLI tests."""

import pytest
from typer.testing import CliRunner

from scopegeo_cli.main import app


@pytest.fixture
def runner():
    return CliRunner()


@pytest.fixture
def cli_app():
    return app


@pytest.fixture(autouse=True)
def tmp_config(tmp_path, monkeypatch):
    """Redirect config to a temp directory so tests don't touch real ~/.scopegeo."""
    config_dir = tmp_path / ".scopegeo"
    config_dir.mkdir()
    monkeypatch.setattr("scopegeo_cli.config.CONFIG_DIR", config_dir)
    monkeypatch.setattr("scopegeo_cli.config.CONFIG_FILE", config_dir / "config.yaml")
