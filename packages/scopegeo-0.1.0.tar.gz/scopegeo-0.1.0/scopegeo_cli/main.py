"""ScopeGeo CLI — geospatial data scoping from the terminal.

Usage:
    scopegeo scope new "Monitor vegetation on a 500ha mine site near Emerald QLD"
    scopegeo scope view <scope_id>
    scopegeo search providers --resolution 10
    scopegeo auth login
"""

import typer

from scopegeo_cli import __version__
from scopegeo_cli.commands import agents, auth, config, project, scope, search, skills

app = typer.Typer(
    name="scopegeo",
    help="ScopeGeo — geospatial data scoping from the terminal.",
    no_args_is_help=True,
    rich_markup_mode="rich",
)

app.add_typer(scope.app, name="scope", help="Create and view scopes.")
app.add_typer(search.app, name="search", help="Search STAC catalogs and providers.")
app.add_typer(auth.app, name="auth", help="Authentication (login/logout/status).")
app.add_typer(config.app, name="config", help="Configuration management.")
app.add_typer(project.app, name="project", help="Project workspace management.")
app.add_typer(agents.app, name="agents", help="AI agent listing and execution.")
app.add_typer(skills.app, name="skills", help="Skills engine (list/run).")


@app.command()
def version() -> None:
    """Show CLI version."""
    typer.echo(f"scopegeo {__version__}")


@app.command()
def health() -> None:
    """Check API connectivity."""
    from scopegeo_cli.client import health as api_health
    from scopegeo_cli.output import error, success

    try:
        data = api_health()
        success(f"API healthy — v{data.get('version', '?')} ({data.get('environment', '?')})")
    except Exception as exc:
        error(f"Cannot reach API: {exc}")
        raise typer.Exit(1)


if __name__ == "__main__":
    app()
