"""Project commands — list, create, add-scope."""

from typing import Optional

import typer
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table

from scopegeo_cli import client, output

app = typer.Typer(no_args_is_help=True)


@app.command("list")
def project_list() -> None:
    """List your projects."""
    with Progress(
        SpinnerColumn(),
        TextColumn("[bold cyan]Loading projects..."),
        transient=True,
        console=output.console,
    ):
        resp = client.get("/projects")

    if resp.status_code == 401:
        output.error("Authentication required. Run [bold]scopegeo auth login[/].")
        raise typer.Exit(1)
    if resp.status_code != 200:
        output.error(f"API error {resp.status_code}: {resp.text[:200]}")
        raise typer.Exit(1)

    projects = resp.json()
    if isinstance(projects, dict):
        projects = projects.get("projects", [])

    if not projects:
        output.warning("No projects yet. Use [bold]scopegeo project create[/] to start one.")
        return

    table = Table(title="Projects", border_style="cyan", show_lines=True)
    table.add_column("ID", style="dim", max_width=36)
    table.add_column("Name", style="bold white")
    table.add_column("Status", style="cyan")
    table.add_column("Scopes", justify="right")
    table.add_column("Created", style="dim")

    for p in projects:
        table.add_row(
            str(p.get("id", ""))[:36],
            p.get("name", ""),
            p.get("status", "active"),
            str(p.get("scope_count", 0)),
            str(p.get("created_at", ""))[:10],
        )

    output.console.print(table)


@app.command("create")
def project_create(
    name: str = typer.Argument(help="Project name"),
    description: Optional[str] = typer.Option(None, "--desc", "-d", help="Project description"),
) -> None:
    """Create a new project workspace."""
    body: dict = {"name": name}
    if description:
        body["description"] = description

    with Progress(
        SpinnerColumn(),
        TextColumn("[bold cyan]Creating project..."),
        transient=True,
        console=output.console,
    ):
        resp = client.post("/projects", json=body)

    if resp.status_code == 401:
        output.error("Authentication required. Run [bold]scopegeo auth login[/].")
        raise typer.Exit(1)
    if resp.status_code not in (200, 201):
        output.error(f"API error {resp.status_code}: {resp.text[:200]}")
        raise typer.Exit(1)

    data = resp.json()
    output.success(f"Project created: [bold]{data.get('name', name)}[/] ({data.get('id', '?')})")


@app.command("add-scope")
def project_add_scope(
    project_id: str = typer.Argument(help="Project UUID"),
    scope_id: str = typer.Argument(help="Scope UUID to add"),
) -> None:
    """Add a scope to an existing project."""
    with Progress(
        SpinnerColumn(),
        TextColumn("[bold cyan]Adding scope to project..."),
        transient=True,
        console=output.console,
    ):
        resp = client.post(f"/projects/{project_id}/scopes", json={"scope_id": scope_id})

    if resp.status_code == 401:
        output.error("Authentication required.")
        raise typer.Exit(1)
    if resp.status_code not in (200, 201):
        output.error(f"API error {resp.status_code}: {resp.text[:200]}")
        raise typer.Exit(1)

    output.success(f"Scope [bold]{scope_id}[/] added to project [bold]{project_id}[/]")
