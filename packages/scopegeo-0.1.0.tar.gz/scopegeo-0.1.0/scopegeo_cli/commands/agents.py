"""Agents commands — list, run."""

import typer
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn

from scopegeo_cli import client, output

app = typer.Typer(no_args_is_help=True)


@app.command("list")
def agents_list() -> None:
    """List available AI agents."""
    with Progress(
        SpinnerColumn(),
        TextColumn("[bold cyan]Loading agents..."),
        transient=True,
        console=output.console,
    ):
        resp = client.get("/agents")

    if resp.status_code != 200:
        output.error(f"API error {resp.status_code}: {resp.text[:200]}")
        raise typer.Exit(1)

    data = resp.json()
    agents = data if isinstance(data, list) else data.get("agents", [])

    if agents:
        output.console.print(output.agents_table(agents))
    else:
        output.warning("No agents available.")


@app.command("run")
def agents_run(
    slug: str = typer.Argument(help="Agent slug (e.g. methodology_writer)"),
    scope_id: str = typer.Option(..., "--scope", "-s", help="Scope UUID for context"),
    prompt: str = typer.Option("", "--prompt", "-p", help="Additional prompt/instructions"),
) -> None:
    """Execute an AI agent with scope context."""
    body: dict = {"scope_id": scope_id}
    if prompt:
        body["prompt"] = prompt

    with Progress(
        SpinnerColumn(),
        TextColumn(f"[bold cyan]Running agent '{slug}'..."),
        transient=True,
        console=output.console,
    ):
        resp = client.post(f"/agents/{slug}/run", json=body)

    if resp.status_code == 401:
        output.error("Authentication required. Run [bold]scopegeo auth login[/].")
        raise typer.Exit(1)
    if resp.status_code == 403:
        output.error("Tier upgrade required for this agent.")
        raise typer.Exit(1)
    if resp.status_code != 200:
        output.error(f"API error {resp.status_code}: {resp.text[:200]}")
        raise typer.Exit(1)

    data = resp.json()
    agent_output = data.get("output", data.get("result", ""))

    output.console.print(Panel(
        str(agent_output),
        title=f"Agent: {slug}",
        border_style="green",
    ))
