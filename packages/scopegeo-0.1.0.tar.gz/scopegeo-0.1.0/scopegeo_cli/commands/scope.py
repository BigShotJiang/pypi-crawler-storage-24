"""Scope commands — new, view, report, compare."""

from pathlib import Path
from typing import Optional

import typer
from rich.progress import Progress, SpinnerColumn, TextColumn

from scopegeo_cli import client, output

app = typer.Typer(no_args_is_help=True)


@app.command("new")
def scope_new(
    brief: str = typer.Argument(help="Project brief in plain English"),
    project_id: Optional[str] = typer.Option(None, "--project", "-p", help="Add scope to project"),
) -> None:
    """Create a new scope from a project brief."""
    with Progress(
        SpinnerColumn(),
        TextColumn("[bold cyan]Scoping..."),
        transient=True,
        console=output.console,
    ):
        body: dict = {"brief": brief}
        if project_id:
            body["project_id"] = project_id
        resp = client.post("/scope", json=body)

    if resp.status_code != 200:
        output.error(f"API error {resp.status_code}: {resp.text[:200]}")
        raise typer.Exit(1)

    data = resp.json()
    scope_id = data.get("scope_id", "?")
    output.success(f"Scope created: [bold]{scope_id}[/]")

    parsed = data.get("parsed_brief", {})
    output.console.print(output.parsed_brief_panel(parsed))

    recs = data.get("recommendations", [])
    if recs:
        output.console.print(output.recommendations_table(recs))
    else:
        output.warning("No matching sensors found.")

    notes = data.get("global_notes", [])
    for note in notes:
        output.info(f"  {note}")


@app.command("view")
def scope_view(
    scope_id: str = typer.Argument(help="Scope UUID to view"),
) -> None:
    """View an existing scope and its recommendations."""
    with Progress(
        SpinnerColumn(),
        TextColumn("[bold cyan]Loading scope..."),
        transient=True,
        console=output.console,
    ):
        resp = client.get(f"/scope/{scope_id}")

    if resp.status_code == 404:
        output.error(f"Scope {scope_id} not found.")
        raise typer.Exit(1)
    if resp.status_code != 200:
        output.error(f"API error {resp.status_code}: {resp.text[:200]}")
        raise typer.Exit(1)

    data = resp.json()
    parsed = data.get("parsed_brief", {})
    output.console.print(output.parsed_brief_panel(parsed))

    recs = data.get("recommendations", [])
    if recs:
        output.console.print(output.recommendations_table(recs))
    else:
        output.warning("No recommendations in this scope.")


@app.command("report")
def scope_report(
    scope_id: str = typer.Argument(help="Scope UUID"),
    output_path: Path = typer.Option("report.pdf", "--output", "-o", help="Output PDF path"),
) -> None:
    """Download a compliance PDF report for a scope."""
    with Progress(
        SpinnerColumn(),
        TextColumn("[bold cyan]Generating report..."),
        transient=True,
        console=output.console,
    ):
        resp = client.get_raw(f"/scope/{scope_id}/report")

    if resp.status_code != 200:
        output.error(f"API error {resp.status_code}: {resp.text[:200]}")
        raise typer.Exit(1)

    output_path.write_bytes(resp.content)
    output.success(f"Report saved to [bold]{output_path}[/] ({len(resp.content):,} bytes)")


@app.command("compare")
def scope_compare(
    scope_id: str = typer.Argument(help="Scope UUID to compare recommendations"),
) -> None:
    """Compare recommendations side-by-side for a scope."""
    with Progress(
        SpinnerColumn(),
        TextColumn("[bold cyan]Loading scope..."),
        transient=True,
        console=output.console,
    ):
        resp = client.get(f"/scope/{scope_id}")

    if resp.status_code != 200:
        output.error(f"API error {resp.status_code}: {resp.text[:200]}")
        raise typer.Exit(1)

    data = resp.json()
    recs = data.get("recommendations", [])
    if not recs:
        output.warning("No recommendations to compare.")
        raise typer.Exit(0)

    from rich.table import Table

    table = Table(title="Comparison", border_style="cyan", show_lines=True)
    table.add_column("Attribute", style="bold")
    for rec in recs[:5]:
        table.add_column(rec.get("sensor_name", "?"), style="white")

    rows = [
        ("Provider", "provider_name"),
        ("Type", "sensor_type"),
        ("Resolution", "spatial_resolution_m"),
        ("Revisit (days)", "temporal_resolution_days"),
        ("Fit Score", "fit_score"),
        ("Feasibility", "feasibility_status"),
        ("Detection", "detection_confidence"),
    ]

    for label, key in rows:
        vals = []
        for rec in recs[:5]:
            v = rec.get(key, "—")
            if key == "fit_score" and isinstance(v, (int, float)):
                v = f"{v:.0%}"
            elif key == "spatial_resolution_m" and v not in (None, "—"):
                v = f"{v}m"
            elif key == "temporal_resolution_days" and v not in (None, "—"):
                v = f"{v}"
            vals.append(str(v) if v is not None else "—")
        table.add_row(label, *vals)

    output.console.print(table)

    # Strengths / limitations
    for rec in recs[:5]:
        name = rec.get("sensor_name", "?")
        strengths = rec.get("strengths", [])
        limitations = rec.get("limitations", [])
        if strengths or limitations:
            output.console.print(f"\n[bold cyan]{name}[/]")
            for s in strengths:
                output.console.print(f"  [green]+[/] {s}")
            for l in limitations:
                output.console.print(f"  [red]-[/] {l}")
