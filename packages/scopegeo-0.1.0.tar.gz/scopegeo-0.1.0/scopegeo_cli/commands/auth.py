"""Auth commands — login, logout, status."""

import typer
from rich.progress import Progress, SpinnerColumn, TextColumn

from scopegeo_cli import client, output
from scopegeo_cli.config import get_token, set_token

app = typer.Typer(no_args_is_help=True)


@app.command("login")
def auth_login(
    email: str = typer.Option(..., "--email", "-e", prompt=True, help="Account email"),
    password: str = typer.Option(..., "--password", "-p", prompt=True, hide_input=True, help="Password"),
) -> None:
    """Log in to ScopeGeo and store JWT token."""
    import httpx

    from scopegeo_cli.config import get_api_url

    with Progress(
        SpinnerColumn(),
        TextColumn("[bold cyan]Authenticating..."),
        transient=True,
        console=output.console,
    ):
        # Call Supabase-compatible auth endpoint
        # The frontend uses Supabase JS SDK, but the CLI can use the REST API
        try:
            base = get_api_url().rstrip("/")
            resp = httpx.post(
                f"{base}/api/v1/auth/login",
                json={"email": email, "password": password},
                timeout=15.0,
            )
        except httpx.RequestError as exc:
            output.error(f"Connection failed: {exc}")
            raise typer.Exit(1)

    if resp.status_code == 200:
        data = resp.json()
        token = data.get("access_token") or data.get("token")
        if token:
            set_token(token)
            output.success(f"Logged in as [bold]{email}[/]")
        else:
            output.error("Login succeeded but no token returned.")
            raise typer.Exit(1)
    elif resp.status_code == 401:
        output.error("Invalid email or password.")
        raise typer.Exit(1)
    else:
        output.error(f"Login failed ({resp.status_code}): {resp.text[:200]}")
        raise typer.Exit(1)


@app.command("logout")
def auth_logout() -> None:
    """Clear stored authentication token."""
    set_token(None)
    output.success("Logged out.")


@app.command("status")
def auth_status() -> None:
    """Show current authentication status."""
    token = get_token()
    if not token:
        output.warning("Not logged in. Use [bold]scopegeo auth login[/] to authenticate.")
        return

    # Try fetching profile to verify token is valid
    with Progress(
        SpinnerColumn(),
        TextColumn("[bold cyan]Checking token..."),
        transient=True,
        console=output.console,
    ):
        resp = client.get("/profile")

    if resp.status_code == 200:
        profile = resp.json()
        email = profile.get("email", "?")
        tier = profile.get("tier", "free")
        output.success(f"Authenticated as [bold]{email}[/] (tier: {tier})")
    elif resp.status_code == 401:
        output.error("Token expired or invalid. Run [bold]scopegeo auth login[/] again.")
        set_token(None)
    else:
        output.warning(f"Could not verify token (status {resp.status_code})")
