# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from darabonba.model import DaraModel

class GetEnrolledAccountRequest(DaraModel):
    def __init__(
        self,
        account_uid: int = None,
        region_id: str = None,
    ):
        # The account ID.
        # 
        # This parameter is required.
        self.account_uid = account_uid
        # The region ID.
        self.region_id = region_id

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.account_uid is not None:
            result['AccountUid'] = self.account_uid

        if self.region_id is not None:
            result['RegionId'] = self.region_id

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('AccountUid') is not None:
            self.account_uid = m.get('AccountUid')

        if m.get('RegionId') is not None:
            self.region_id = m.get('RegionId')

        return self

