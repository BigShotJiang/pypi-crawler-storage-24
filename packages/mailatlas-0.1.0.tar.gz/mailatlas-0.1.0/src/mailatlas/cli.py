from __future__ import annotations

import argparse
import json
import os
import sys

from mailatlas.adapters.imap import ImapSyncError
from mailatlas.ai import generate_brief
from mailatlas.core import ImapSyncConfig, MailAtlas, ParserConfig


def _workspace_defaults() -> tuple[str, str]:
    return ".mailatlas/store.db", ".mailatlas/workspace"


def _add_workspace_arguments(parser: argparse.ArgumentParser) -> None:
    db_default, workspace_default = _workspace_defaults()
    parser.add_argument("--db", default=db_default, help="SQLite database path.")
    parser.add_argument("--workspace", default=workspace_default, help="Workspace directory path.")


def _add_parser_config_arguments(parser: argparse.ArgumentParser) -> None:
    parser.add_argument(
        "--strip-forwarded-headers",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Remove forwarded wrapper header lines from body_text.",
    )
    parser.add_argument(
        "--strip-boilerplate",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Remove common newsletter CTA and reaction boilerplate lines.",
    )
    parser.add_argument(
        "--strip-link-only-lines",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Remove lines that contain only a URL.",
    )
    parser.add_argument(
        "--stop-at-footer",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Stop body_text collection when a footer marker like unsubscribe is reached.",
    )
    parser.add_argument(
        "--strip-invisible-chars",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Remove zero-width and formatting characters from body_text.",
    )
    parser.add_argument(
        "--normalize-whitespace",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Collapse repeated blank lines and trim line whitespace.",
    )


def _parser_config_from_args(args: argparse.Namespace) -> ParserConfig:
    return ParserConfig(
        strip_forwarded_headers=args.strip_forwarded_headers,
        strip_boilerplate=args.strip_boilerplate,
        strip_link_only_lines=args.strip_link_only_lines,
        stop_at_footer=args.stop_at_footer,
        strip_invisible_chars=args.strip_invisible_chars,
        normalize_whitespace=args.normalize_whitespace,
    )


def _env_or_value(value: str | None, env_name: str, default: str | None = None) -> str | None:
    if value is not None:
        return value
    return os.environ.get(env_name, default)


def _imap_sync_config_from_args(args: argparse.Namespace) -> ImapSyncConfig:
    host = _env_or_value(args.host, "MAILATLAS_IMAP_HOST")
    port_raw = _env_or_value(str(args.port) if args.port is not None else None, "MAILATLAS_IMAP_PORT", "993")
    username = _env_or_value(args.username, "MAILATLAS_IMAP_USERNAME")
    password = _env_or_value(args.password, "MAILATLAS_IMAP_PASSWORD")
    access_token = _env_or_value(args.access_token, "MAILATLAS_IMAP_ACCESS_TOKEN")
    folders = tuple(args.folder or ["INBOX"])

    try:
        port = int(port_raw or "993")
    except ValueError as error:
        raise ValueError("IMAP port must be an integer.") from error

    return ImapSyncConfig(
        host=host or "",
        port=port,
        username=username or "",
        auth=args.auth,
        password=password,
        access_token=access_token,
        folders=folders,
        parser_config=_parser_config_from_args(args),
    )


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="mailatlas",
        description="Email ingestion for AI agents and data applications.",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    ingest_parser = subparsers.add_parser("ingest", help="Ingest content into the local workspace.")
    ingest_subparsers = ingest_parser.add_subparsers(dest="ingest_command", required=True)

    ingest_eml_parser = ingest_subparsers.add_parser("eml", help="Ingest .eml files.")
    ingest_eml_parser.add_argument("paths", nargs="+", help="EML file paths to ingest.")
    _add_workspace_arguments(ingest_eml_parser)
    _add_parser_config_arguments(ingest_eml_parser)

    ingest_mbox_parser = ingest_subparsers.add_parser("mbox", help="Ingest an mbox archive.")
    ingest_mbox_parser.add_argument("path", help="Path to an mbox file.")
    _add_workspace_arguments(ingest_mbox_parser)
    _add_parser_config_arguments(ingest_mbox_parser)

    show_parser = subparsers.add_parser("show", help="Show a stored document as JSON.")
    show_parser.add_argument("document_id", help="Document identifier.")
    show_parser.add_argument("--format", choices=["json"], default="json", help="Output format.")
    _add_workspace_arguments(show_parser)

    export_parser = subparsers.add_parser("export", help="Export a stored document.")
    export_parser.add_argument("document_id", help="Document identifier.")
    export_parser.add_argument(
        "--format",
        choices=["json", "markdown", "html", "pdf"],
        default="json",
        help="Export format.",
    )
    export_parser.add_argument("--out", default=None, help="Optional path to write the export.")
    _add_workspace_arguments(export_parser)

    list_parser = subparsers.add_parser("list", help="List stored documents.")
    list_parser.add_argument("--query", default=None, help="Optional substring query.")
    _add_workspace_arguments(list_parser)

    brief_parser = subparsers.add_parser("brief", help="Generate a briefing from stored documents.")
    brief_subparsers = brief_parser.add_subparsers(dest="brief_command", required=True)

    brief_generate_parser = brief_subparsers.add_parser("generate", help="Generate a briefing.")
    brief_generate_parser.add_argument("--query", default=None, help="Optional substring query for document selection.")
    brief_generate_parser.add_argument("--ids", nargs="*", default=None, help="Explicit document identifiers.")
    brief_generate_parser.add_argument("--out", default=None, help="Output HTML path.")
    brief_generate_parser.add_argument("--provider", default="fallback", help="Brief provider: fallback, openai, anthropic, google.")
    _add_workspace_arguments(brief_generate_parser)

    sync_parser = subparsers.add_parser("sync", help="Sync content from external sources.")
    sync_subparsers = sync_parser.add_subparsers(dest="sync_command", required=True)

    sync_imap_parser = sync_subparsers.add_parser("imap", help="Sync one or more IMAP folders.")
    sync_imap_parser.add_argument("--host", default=None, help="IMAP hostname or use MAILATLAS_IMAP_HOST.")
    sync_imap_parser.add_argument("--port", type=int, default=None, help="IMAP TLS port or use MAILATLAS_IMAP_PORT.")
    sync_imap_parser.add_argument("--username", default=None, help="IMAP username or use MAILATLAS_IMAP_USERNAME.")
    sync_imap_parser.add_argument(
        "--auth",
        choices=["password", "xoauth2"],
        default="password",
        help="Authentication mode.",
    )
    sync_imap_parser.add_argument("--password", default=None, help="IMAP password or use MAILATLAS_IMAP_PASSWORD.")
    sync_imap_parser.add_argument(
        "--access-token",
        default=None,
        help="OAuth access token or use MAILATLAS_IMAP_ACCESS_TOKEN.",
    )
    sync_imap_parser.add_argument(
        "--folder",
        action="append",
        default=None,
        help="Folder to sync. Repeat for multiple folders. Defaults to INBOX.",
    )
    _add_workspace_arguments(sync_imap_parser)
    _add_parser_config_arguments(sync_imap_parser)

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)
    parser_config = _parser_config_from_args(args) if args.command == "ingest" else None
    atlas = MailAtlas(db_path=args.db, workspace_path=args.workspace, parser_config=parser_config)

    if args.command == "ingest" and args.ingest_command == "eml":
        refs = atlas.ingest_eml(args.paths)
        print(json.dumps([reference.to_dict() for reference in refs], indent=2))
        return 0

    if args.command == "ingest" and args.ingest_command == "mbox":
        refs = atlas.ingest_mbox(args.path)
        print(json.dumps([reference.to_dict() for reference in refs], indent=2))
        return 0

    if args.command == "show":
        document = atlas.get_document(args.document_id)
        print(json.dumps(document.to_dict(), indent=2))
        return 0

    if args.command == "export":
        result = atlas.export_document(
            args.document_id,
            format=args.format,
            out_path=args.out,
        )
        print(result)
        return 0

    if args.command == "list":
        refs = atlas.list_documents(query=args.query)
        print(json.dumps([reference.to_dict() for reference in refs], indent=2))
        return 0

    if args.command == "brief" and args.brief_command == "generate":
        output_path = generate_brief(
            document_ids=args.ids or None,
            query=args.query,
            output_path=args.out,
            model_config={"provider": args.provider},
            db_path=args.db,
            workspace_path=args.workspace,
        )
        print(output_path)
        return 0

    if args.command == "sync" and args.sync_command == "imap":
        try:
            result = atlas.sync_imap(_imap_sync_config_from_args(args))
        except (ImapSyncError, ValueError) as error:
            print(str(error), file=sys.stderr)
            return 1

        print(json.dumps(result.to_dict(), indent=2))
        return 1 if result.has_errors() else 0

    parser.error("Unsupported command")
    return 1
