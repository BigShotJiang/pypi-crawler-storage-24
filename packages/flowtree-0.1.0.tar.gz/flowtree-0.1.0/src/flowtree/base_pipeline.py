from .exceptions import *

import gi  # noqa
gi.require_version('Gst', '1.0')  # noqa
from gi.repository import Gst, GLib


class BasePipeline:
    def __init__(self, name: str):
        self.name: str = name
        self.pipeline: Gst.Pipeline = None
        self.bus: Gst.Bus = None
        self.last_element: Gst.Element = None
        self.loop = GLib.MainLoop()

    def _on_message(self, bus, message):
        if message.type == Gst.MessageType.EOS:
            self.loop.quit()
        elif message.type == Gst.MessageType.ERROR:
            self.loop.quit()
            error, debug = message.parse_error()
            raise BusMessageError(error, debug)
        elif message.type == Gst.MessageType.WARNING:
            warn, debug = message.parse_warning()
            print(f"总线消息警告: {warn}, {debug}")

    def _set_state(self, state: Gst.State):
        ret = self.pipeline.set_state(state)
        if ret == Gst.StateChangeReturn.FAILURE:
            raise PipelineSetStateError()

    def append_element(self, factory_name: str, name: str, properties: dict = None):
        element = Gst.ElementFactory.make(factory_name, name)
        if not element:
            raise ElementCreateFailedError()
        if properties:
            for property_name, property_value in properties.items():
                element.set_property(property_name, property_value)
        self.pipeline.add(element)
        if self.last_element:
            if not Gst.Element.link(self.last_element, element):
                raise ElementLinkFailedError(
                    self.last_element.name, element.name)
        self.last_element = element

    def create(self):
        self.pipeline = Gst.Pipeline.new(self.name)
        if not self.pipeline:
            raise PipelineCreateFailedError(self.name)
        self.bus = self.pipeline.get_bus()
        self.bus.add_signal_watch()
        self.bus.connect("message", self._on_message)

    def start(self):
        self._set_state(Gst.State.PLAYING)
        self.loop.run()
        self._set_state(Gst.State.NULL)

    def stop(self):
        if self.pipeline:
            self.pipeline.send_event(Gst.Event.new_eos())
            self.pipeline._set_state(Gst.State.NULL)
