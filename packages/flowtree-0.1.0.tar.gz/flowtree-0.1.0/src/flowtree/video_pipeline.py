from .exceptions import *
from .base_pipeline import BasePipeline

import gi  # noqa
gi.require_version('Gst', '1.0')  # noqa
from gi.repository import Gst


class VideoPipeline(BasePipeline):
    def __init__(self, name: str):
        super().__init__(name)
        self.camera_path: str = None
        self.frame_type: str = None
        self.frame_width: int = None
        self.frame_height: int = None
        self.frame_rate: int = None

    def set_camera(self, camera_path: str, frame_type: str, frame_width: int, frame_height: int, frame_rate: int):
        self.camera_path = camera_path
        self.frame_type = frame_type
        self.frame_width = frame_width
        self.frame_height = frame_height
        self.frame_rate = frame_rate

    def start(self):
        self.create()

        self.append_element("v4l2src", "source", properties={
            "device": self.camera_path, "num-buffers": 300})
        self.append_element("capsfilter", "capsfilter", properties={
            "caps": Gst.Caps.from_string(f"{self.frame_type},width={self.frame_width},height={self.frame_height},framerate={self.frame_rate}/1")})
        self.append_element("mppjpegdec", "jpegdec")
        self.append_element("videoconvert", "videoconvert")
        self.append_element("queue", "queue")
        self.append_element("mpph264enc", "h264enc")
        self.append_element("h264parse", "h264parse")
        self.append_element("mp4mux", "mp4mux")
        self.append_element("filesink", "sink", properties={
            "location": "output.mp4"})

        super().start()
