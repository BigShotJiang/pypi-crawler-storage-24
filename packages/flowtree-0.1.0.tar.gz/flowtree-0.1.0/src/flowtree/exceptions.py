class PipelineError(Exception):
    def __init__(self, message):
        self.message = message
        super().__init__(self.message)

    @property
    def lineno(self):
        return self.__traceback__.tb_lineno


class PipelineCreateFailedError(PipelineError):
    def __init__(self, pipeline_name: str):
        super().__init__(f"无法创建管道：{pipeline_name}")


class ElementCreateFailedError(PipelineError):
    def __init__(self, element_name: str):
        super().__init__(f"无法创建元素：{element_name}")


class ElementLinkFailedError(PipelineError):
    def __init__(self, element1_name: str, element2_name: str):
        super().__init__(f"无法链接元素：{element1_name} -> {element2_name}")


class BusMessageError(PipelineError):
    def __init__(self, error_text: str, debug_text: str):
        super().__init__(f"总线消息错误：{error_text}, {debug_text}")


class PipelineSetStateError(PipelineError):
    def __init__(self):
        super().__init__(f"总线状态设置错误")
