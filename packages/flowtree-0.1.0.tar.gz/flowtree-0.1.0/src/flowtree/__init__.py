__version__ = "0.1.0"

from .video_pipeline import VideoPipeline
from .audio_pipeline import AudioPipeline
from .exceptions import *

from gi.repository import Gst
Gst.init(None) # 初始化GStreamer