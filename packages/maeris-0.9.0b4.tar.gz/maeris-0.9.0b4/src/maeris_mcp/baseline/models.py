"""Data models for the baseline test generation system.

Pure dataclasses — no I/O, no AI.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class TestStatus(str, Enum):
    PENDING = "pending"
    PASSING = "passing"
    FAILING = "failing"
    REPAIRED = "repaired"
    UNSTABLE = "unstable"  # failed stability (3-pass) gate
    PUSHED = "pushed"      # successfully pushed to Maeris


@dataclass
class BaselineTest:
    name: str
    page: str              # route / page identifier, e.g. "/checkout"
    steps: list[dict]      # structured step dicts for playwright_generator
    assertions: list[dict] # assertion dicts for playwright_generator
    script_path: str = ""  # abs path to generated .py file
    status: TestStatus = TestStatus.PENDING
    pass_count: int = 0    # consecutive passes so far
    repair_attempts: int = 0  # max 1 allowed
    failure_reason: str = ""
    maeris_testcase_id: str = ""  # set after push


@dataclass
class BaselineResult:
    total: int = 0
    pushed: int = 0
    unstable: int = 0
    skipped: int = 0
    tests: list[BaselineTest] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "total": self.total,
            "pushed": self.pushed,
            "unstable": self.unstable,
            "skipped": self.skipped,
            "tests": [
                {
                    "name": t.name,
                    "page": t.page,
                    "status": t.status,
                    "pass_count": t.pass_count,
                    "maeris_id": t.maeris_testcase_id,
                    "failure_reason": t.failure_reason,
                }
                for t in self.tests
            ],
        }
