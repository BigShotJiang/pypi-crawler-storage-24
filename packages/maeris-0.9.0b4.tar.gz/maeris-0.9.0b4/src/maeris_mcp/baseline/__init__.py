"""Baseline test generation system.

Pipeline: deterministic discovery → AI generation → local execution →
3-pass stability validation → optional AI repair (max 1) → Maeris push.

Public API:
    generate_baseline(client, scan_root, base_url, model, dry_run) → BaselineResult
    discover_journeys(scan_root) → DiscoveryResult
    BaselineTest, BaselineResult, TestStatus
"""

from .models import BaselineTest, BaselineResult, TestStatus
from .journey_discovery import discover_journeys, DiscoveryResult
from .baseline_manager import generate_baseline

__all__ = [
    "BaselineTest",
    "BaselineResult",
    "TestStatus",
    "DiscoveryResult",
    "discover_journeys",
    "generate_baseline",
]
