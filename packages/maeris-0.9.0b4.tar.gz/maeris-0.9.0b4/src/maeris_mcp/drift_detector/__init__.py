"""Deterministic drift detection — no AI, safe to call from CI.

Public API:
    detect_ui_drift(client, scan_root)    → DriftReport
    detect_api_drift(client, scan_root)   → DriftReport
    detect_flow_drift(client)             → DriftReport
    detect_all_drift(client, scan_root)   → DriftReport (merged contract report)
"""

from __future__ import annotations

from pathlib import Path

from .models import DriftIssue, DriftKind, DriftReport, DriftSeverity, RepairResult
from .ui_drift import detect_ui_drift
from .api_drift import detect_api_drift
from .flow_drift import detect_flow_drift

__all__ = [
    "DriftIssue",
    "DriftKind",
    "DriftReport",
    "DriftSeverity",
    "RepairResult",
    "detect_ui_drift",
    "detect_api_drift",
    "detect_flow_drift",
    "detect_all_drift",
]


async def detect_all_drift(client, scan_root: Path | str) -> DriftReport:
    """Run all three detectors and merge results into a single contract report.

    This is the entry point used by `maeris ci --contract-check` and
    `maeris repair contract`. Never calls any AI — purely deterministic.

    Args:
        client: An active MaerisClient instance.
        scan_root: Root directory for UI + API source scanning.

    Returns:
        DriftReport with domain='contract' containing all issues from all domains.
    """
    import asyncio

    scan_root = Path(scan_root)

    ui_report, api_report, flow_report = await asyncio.gather(
        detect_ui_drift(client, scan_root),
        detect_api_drift(client, scan_root),
        detect_flow_drift(client),
    )

    all_issues = ui_report.issues + api_report.issues + flow_report.issues
    merged_meta = {**ui_report.meta, **api_report.meta, **flow_report.meta}

    return DriftReport(
        domain="contract",
        issues=all_issues,
        meta=merged_meta,
    )
