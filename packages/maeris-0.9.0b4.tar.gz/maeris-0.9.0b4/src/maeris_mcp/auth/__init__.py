"""Authentication module for Maeris MCP."""

from maeris_mcp.auth.oauth import OAuthFlow
from maeris_mcp.auth.token_store import TokenStore
from maeris_mcp.auth.device_flow import DeviceFlow, DeviceFlowError, MaerisAIToken
from maeris_mcp.auth.scopes import ScopeConfig
__all__ = [
    "OAuthFlow",
    "TokenStore",
    "DeviceFlow",
    "DeviceFlowError",
    "MaerisAIToken",
    "ScopeConfig",
]
