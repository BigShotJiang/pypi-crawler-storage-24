"""Repair engine — AI-assisted fix orchestration.

Each submodule: detect drift → ask AI for suggestion → (if approved) apply via client.

This package must NEVER be imported from drift_detector.
"""

from .ui_repair import repair_ui
from .api_repair import repair_api
from .flow_repair import repair_flow

__all__ = ["repair_ui", "repair_api", "repair_flow"]
