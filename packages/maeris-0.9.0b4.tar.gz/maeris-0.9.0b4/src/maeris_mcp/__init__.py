"""Maeris MCP Server — API management, security scanning, and test generation."""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("maeris")
except PackageNotFoundError:
    __version__ = "0.9.0b4"
