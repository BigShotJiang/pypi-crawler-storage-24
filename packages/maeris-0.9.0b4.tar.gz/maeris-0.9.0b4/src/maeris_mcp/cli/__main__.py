"""Entry point for running the CLI package with `python -m maeris_mcp.cli`."""

from maeris_mcp.cli import cli


if __name__ == "__main__":
    cli()
