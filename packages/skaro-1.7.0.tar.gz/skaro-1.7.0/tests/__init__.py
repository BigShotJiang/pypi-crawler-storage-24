"""Skaro tests."""
