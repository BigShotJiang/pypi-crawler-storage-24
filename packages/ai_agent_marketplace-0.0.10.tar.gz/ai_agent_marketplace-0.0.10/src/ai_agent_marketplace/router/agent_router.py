"""

This python class OneKey Agent Router is a unified API gateway to router to
MCP style  API style and Chat style Agents Usage, key `DEEPNLP_ONEKEY_ROUTER_ACCESS` is required

curl -X POST "https://agent.deepnlp.org/agent_router" \
-H "X-OneKey: $DEEPNLP_ONEKEY_ROUTER_ACCESS" \
-H "Content-Type: application/json" \
-d '{
  "unique_id": "craftsman-agent/craftsman-agent",
  "api_id": "generate_lego_build_plan",
  "data": {
    "prompt": "USER_PROMPT_START\npink lego phone\nUSER_PROMPT_END",
    "ref_image_url": [],
    "mode": "basic"
  }
}'



## MCP Style

curl -X POST "https://agent.deepnlp.org/agent_router" \
-H "X-OneKey: $DEEPNLP_ONEKEY_ROUTER_ACCESS" \
-H "Content-Type: application/json" \
-d '{
  "unique_id": "craftsman-agent/craftsman-agent",
  "api_id": "generate_lego_build_plan",
  "data": {
    "prompt": "USER_PROMPT_START\npink lego phone\nUSER_PROMPT_END",
    "ref_image_url": [],
    "mode": "basic"
  }
}'

"""

import os
import requests
import json
import uuid
from dotenv import load_dotenv
import os
import sys
from typing import List, Any, Dict
from mcp_marketplace import OneKeyMCPRouter
from pathlib import Path
from urllib import request, parse, error

load_dotenv()

LOG_ENABLE = False
KEY_DEEPNLP_ONEKEY_ROUTER_ACCESS = "DEEPNLP_ONEKEY_ROUTER_ACCESS"
MCP_ROUTER_MCP_ENDPOINT = "https://agent.deepnlp.org/mcp"
AGENT_ROUTER_CHAT_ENDPOINT = "https://agent.deepnlp.org/agent_router"
ONEKEY_HEADER = "X-OneKey"
KEY_TIMEOUT = "timeout"
TIMEOUT_DEFAULT_SECS = 60

def load_agent_router_config(config_path: str):
    """
    Load the Agent Router configuration from a JSON file.

    Args:
        config_path (str): Path to the JSON config file.

    Returns:
        dict: Parsed JSON config.

    Raises:
        FileNotFoundError: If the config file does not exist.
        json.JSONDecodeError: If the JSON is invalid.
        ValueError: If the loaded content is not a dict.
    """
    try:
        config_file = Path(config_path)
        if not config_file.exists():
            raise FileNotFoundError(f"Agent Router config file not found: {config_file}")

        with open(config_file, "r", encoding="utf-8") as f:
            try:
                config_data = json.load(f)
            except json.JSONDecodeError as e:
                raise json.JSONDecodeError(f"Invalid JSON in {config_file}: {e.msg}", e.doc, e.pos)

        if not isinstance(config_data, dict):
            raise ValueError(f"Agent Router config must be a JSON object (dict), got {type(config_data)}")

        return config_data

    except Exception as e:
        print (f"Failed to load_agent_router_config with error {e} ")
        return {}

FILE_DIR = Path(__file__).resolve().parents[0]
if str(FILE_DIR) not in sys.path:
    sys.path.insert(0, str(FILE_DIR))  # put at highest priority
    if LOG_ENABLE:
        print (f"Appending {FILE_DIR} to sys.path")

SRC_DIR = Path(__file__).resolve().parents[2]
if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))  # put at highest priority
    if LOG_ENABLE:
        print (f"Appending {SRC_DIR} to sys.path")

## MCP Get Access
agent_router_mcp_config_file = SRC_DIR/ "ai_agent_marketplace" / "data" / "agent_router_mcp_config.json"
agent_router_config = load_agent_router_config(str(agent_router_mcp_config_file))
if LOG_ENABLE:
    print (f"INFO: Loading agent_router_config Size {len(agent_router_config)}")

def post_json_with_header(url, payload, api_key, timeout):
    try:
        data = json.dumps(payload).encode("utf-8")
        if LOG_ENABLE:
            print (f"DEBUG: post_json_with_header url {url} payload {payload} api_key {api_key}")
        req = request.Request(
            url,
            data=data,
            headers={"Content-Type": "application/json", ONEKEY_HEADER: api_key},
            method="POST",
        )
        with request.urlopen(req, timeout=timeout) as resp:
            body = resp.read().decode("utf-8")
            return resp.status, body
    except Exception as e:
        print (f"post_json_with_header failed with error {e}")
        return 400, ""

# --- OneKey Agent Router ---
class OneKeyAgentRouter:
    def __init__(self, onekey: str = None, log_enable: bool = False):
        self.mcp_endpoint = MCP_ROUTER_MCP_ENDPOINT
        self.agent_chat_endpoint = AGENT_ROUTER_CHAT_ENDPOINT
        self.onekey = os.getenv(KEY_DEEPNLP_ONEKEY_ROUTER_ACCESS) or onekey
        if not self.onekey:
            raise ValueError("Missing OneKey access key. Set env DEEPNLP_ONEKEY_ROUTER_ACCESS or provide onekey")
        self.log_enable = log_enable
        self._request_id_counter = 0
        # Cache of MCP Router Initialized
        self._mcp_router_dict = {}

    def _get_next_id(self):
        self._request_id_counter += 1
        return str(self._request_id_counter)

    def _make_request(self, server_name: str, method: str, params: dict = None):
        """Generic POST request to MCP endpoint."""
        final_url = f"{self.endpoint}?server_name={server_name}&onekey={self.onekey}"
        payload = build_rpc_payload(method=method, params=params, request_id=self._get_next_id())
        if self.log_enable:
            print(f"[DEBUG] Request {payload} → {final_url}")
        try:
            response = requests.post(final_url, headers={"Content-Type": "application/json"}, json=payload)
            response.raise_for_status()
            return {"status": True, "response": response.json(), "message": "OK"}
        except Exception as e:
            logging.error(f"Request error: {e}")
            return {"status": False, "response": None, "message": str(e)}

    def chat(self, unique_id: str, messages: List[Any] = None,**kwargs):
        """
            Input Chat Style messages
        """
        return

    def invoke(self, unique_id: str, api_id: str, data: dict, **kwargs):
        """
        Common entry point for any unique_id call.
        unique_id: server_name/api_name for mcp style endpoint
        unique_id: owner_name/repo_name for chat style endpoint

        api_id: str, function to call
        data: the payload to post

        input_data schema:
        {
            "unique_id": "google-maps/maps_directions",
            "payload": {...},
            "messages": [...]
        }

        Return:
            {
                "success": True,
                'content': [{
                    'type': 'text',
                    'text': ""
                }]
            }
        """
        try:
            ### branch
            if unique_id in agent_router_config:
                ## Call /mcp endpoint MCP Router Style
                # Initialize MCP Router
                pairs = unique_id.split("/")
                if len(pairs) == 2:
                    ## owner/repo
                    server_name = pairs[1]
                else:
                    server_name = unique_id
                if LOG_ENABLE:
                    print (f"DEBUG: unique_id {unique_id} Router to /mcp endpoint with server_name {server_name}")
                router = None
                if server_name in self._mcp_router_dict:
                    ## Google Maps
                    router = self._mcp_router_dict.get(server_name)
                else:
                    router = OneKeyMCPRouter(server_name=server_name, onekey=self.onekey)
                    print (f"INFO: Starting new connection to OneKeyRouter {server_name}")
                if not router:
                    result = {"success": False, "message": f"server_name {server_name} router not found"}
                    return result
                # Call the tool
                result = {}
                try:
                    tool_result = router.tools_call(server_name, api_id, data)
                    ## json rpc
                    result = tool_result.get('result', {})
                except Exception as e:
                    print (f"ERROR: Failed to Call OneKey Router: {e}")
                    result = {"success": False, "message": str(e)}
                return result

            else:
                if LOG_ENABLE:
                    print (f"DEBUG: unique_id {unique_id} Router to /agent_router endpoint")
                ## Call /agent_router onekey endpoint
                payload = {
                    "unique_id": unique_id,
                    "api_id": api_id,
                    "data": data
                }
                timeout = kwargs.get(KEY_TIMEOUT, TIMEOUT_DEFAULT_SECS)
                body = ""
                result = {}
                try:
                    status, body = post_json_with_header(AGENT_ROUTER_CHAT_ENDPOINT, payload, self.onekey, timeout)
                except error.HTTPError as e:
                    print (f"Error: HTTPError: {e}")
                    return {"success": False, "message": f"Error: HTTPError: {e}"}
                except error.URLError as e:
                    print (f"Error: URLError: {e}")
                    return {"success": False, "message": f"Error: URLError: {e}"}
                except Exception as e:
                    print (f"Error: Agent Router API Error: {e}")
                    return {"success": False, "message": f"Error: Agent Router API Error: {e}"}
                if body == "":
                    return {"success": False, "message": f"Error: Agent Router API Return Result Empty Error..."}
                try:
                    result = json.loads(body)
                    result["success"] = True
                    return result
                except json.JSONDecodeError as e:
                    print (f"Error: Json Parsing Failed {e}")
                    return {"success": False, "message": f"Error: Json Parsing Failed {e}"}

        except Exception as e:
            print (f"Request error: {e}")
            return {"success": False, "message": f"Internal Server Error {e}"}

# --- Example Usage ---
if __name__ == "__main__":

    ## 1. Google Maps
    agent_router = OneKeyAgentRouter(onekey="BETA_TEST_KEY_MARCH_2026")
    print (f"DEBUG: Connectin to agent_router google-maps")
    result = agent_router.invoke(
        unique_id = "google-maps/google-maps",
        api_id = "maps_directions",
        data = {
            "origin": "Boston", "destination": "New York", "mode": "driving"
        }
    )
    print("Google Map Result:", result)

    ## 2. Craftsman
    result2 = agent_router.invoke(
        unique_id = "craftsman-agent/craftsman-agent",
        api_id = "generate_lego_build_plan",
        data = {
            "prompt": "pink lego phone",
            "ref_image_url": [],
            "mode": "demo"
        },
        timeout=10
    )
    print("Craftsman-agent generate_lego_build_plan Result:", result2)

