# -*- coding: utf-8 -*-
"""
Base Live Runtime for AI Agent Marketplace

Supports:
- DeepAgents
- AgentScope
- LangChain
- LangGraph
- Callable async agents

Users:
    from ai_agent_marketplace import BaseLiveRuntime
    runtime = BaseLiveRuntime(agent=my_agent)
    app = runtime.app
"""

import asyncio
import json
import uuid
from typing import Any, Dict, List, Optional, Callable, AsyncGenerator

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field
from contextlib import asynccontextmanager

# ==============================
# Streaming / Message Constants
# ==============================
MESSAGE_TYPE_ASSISTANT = "assistant"
MESSAGE_TYPE_USER = "user"

OUTPUT_FORMAT_TEXT = "text"
OUTPUT_FORMAT_HTML = "html"

CONTENT_TYPE_MARKDOWN = "text/markdown"
CONTENT_TYPE_HTML = "text/html"

SECTION_ANSWER = "answer"
SECTION_TOOL = "tool"
SECTION_THINK = "think"
SECTION_SYSTEM_MSG = "system_msg"
SECTION_CONTEXT = "context"

STREAMING_SEPARATOR_DEFAULT = "\n"
STREAMING_SEPARATOR_BACKSPACE = "\b"

TEMPLATE_STREAMING_CONTENT_TYPE = "streaming_content_type"
TEMPLATE_REASONING_HTML = "reason_html"

# =========================================================
# Request / Response Models
# =========================================================

class ChatRequest(BaseModel):
    messages: List[Dict[str, str]] = Field(...)
    model: Optional[str] = None

# =========================================================
# Base Runtime
# =========================================================

class BaseLiveRuntime:
    """
    Universal Agent Runtime

    agent:
        Any agent that implements:
        - __call__()
        - run()
        - invoke()
        - reply()
    """

    def __init__(
        self,
        agent: Any,
        title: str = "AI Agent Runtime",
        description: str = "Universal Agent Runtime",
        version: str = "0.1.0",
        stream_handler: Optional[
            Callable[[Any, Any], AsyncGenerator[str, None]]
        ] = None,
        separator: Optional[str] = "\n",
    ):
        self.agent = agent
        self.stream_handler = stream_handler or self.default_stream_handler

        self.app = FastAPI(
            title=title,
            description=description,
            version=version,
            lifespan=self._lifespan,
        )

        self._setup_middlewares()
        self._setup_routes()
        self.separator = separator

    # =====================================================
    # Lifespan
    # =====================================================

    @asynccontextmanager
    async def _lifespan(self, app: FastAPI):
        await self.startup()
        yield
        await self.shutdown()

    async def startup(self):
        """Override if needed"""
        pass

    async def shutdown(self):
        """Auto close agent if needed"""
        if hasattr(self.agent, "close"):
            try:
                await self.agent.close()
            except Exception:
                pass

    # =====================================================
    # Setup
    # =====================================================

    def _setup_middlewares(self):
        self.app.add_middleware(
            CORSMiddleware,
            allow_origins=["*"],
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )

    def _setup_routes(self):
        @self.app.post("/chat")
        async def chat(request: ChatRequest):
            if self.agent is None:
                raise HTTPException(status_code=503, detail="Agent not initialized")

            try:
                user_query = request.messages[-1]["content"]
            except Exception:
                user_query = "hello"

            return StreamingResponse(
                self.stream_handler(self.agent, user_query),
                media_type="application/json",
            )

    # =====================================================
    # Default Stream Handler
    # =====================================================

    async def default_stream_handler(
        self, agent: Any, user_query: str
    ) -> AsyncGenerator[str, None]:
        """
        Universal async adapter
        """

        # ---- initial chunk ----
        yield self._json_chunk(
            content="Task Started...",
            section="system",
        ) + self.separator

        try:
            result = await self._call_agent(agent, user_query)

            yield self._json_chunk(
                content=result,
                section="answer",
            ) + self.separator

        except Exception as e:
            yield self._json_chunk(
                content=str(e),
                section="error",
            )  + self.separator

    # =====================================================
    # Universal Agent Caller
    # =====================================================

    async def _call_agent(self, agent: Any, user_query: str):

        # 1️⃣ AgentScope style (reply)
        if hasattr(agent, "reply"):
            return (await agent.reply(user_query)).content

        # 2️⃣ Async callable
        if asyncio.iscoroutinefunction(agent):
            return await agent(user_query)

        # 3️⃣ __call__
        if callable(agent):
            result = agent(user_query)
            if asyncio.iscoroutine(result):
                return await result
            return result

        # 4️⃣ run()
        if hasattr(agent, "run"):
            result = agent.run(user_query)
            if asyncio.iscoroutine(result):
                return await result
            return result

        # 5️⃣ invoke()
        if hasattr(agent, "invoke"):
            result = agent.invoke(user_query)
            if asyncio.iscoroutine(result):
                return await result
            return result

        raise RuntimeError("Unsupported agent type")

    # =====================================================
    # Message Assembly
    # =====================================================

    def _json_chunk(
        self,
        content: Any,
        message_type: str = "assistant",
        format: str = "text",
        section: str = "answer",
        content_type: str = "text/markdown",
    ) -> str:

        payload = {
            "type": message_type,
            "format": format,
            "content": content,
            "section": section,
            "content_type": content_type,
            "message_id": str(uuid.uuid4()),
        }

        return json.dumps(payload) + "\n"


"""
    Assembly Message Chunks to Render in Agent Router deepnlp.org/?agent=owner_id/repo
"""
def assembly_message(type, format, content, **kwargs):
    """
        content_type: html,pdf,etc
        {
            "type": "assistant",
            "format": "html",  // html
            "content": "xxxxx",
            "content_type": "xxxxx",
            "section": "tool",
            “template”:
            "message_id": "xxxxx"
        }
        type: role
        format: text/img
        section: reason/tool/response

        content:
            str,
            dict
    """
    try:
        output_message = {"type": type, "format": format, "content": content}

        keys = ["section", "message_id", "content_type", "template", "task_ids", "tab_message_ids", "tab_id"]
        for key in keys:
            value = kwargs[key] if key in kwargs else ""
            output_message[key] = value

        return output_message

        ## add key: c
    except Exception as e:
        print(f"DEBUG: processing error with {e}")
        return {"type": type, "format": format, "content": content}


"""
    Extract Message Content From LangChain extract_message_content_langchain
"""
def extract_message_content_langchain(message):
    """
    Convert any LangChain/BaseMessage or dict into a simple string.

    message:
        langchain_core.messages.human.HumanMessag
        'langchain_core.messages.ai.AIMessage: AIMessage contains list structure
    """
    # 1. BaseMessage or subclass
    if hasattr(message, "content"):
        content = getattr(message, "content", "")
        role = getattr(message, "role", "assistant")
        message_id = getattr(message, "id", str(uuid.uuid4()))
    # 2. dict
    elif isinstance(message, dict):
        content = message.get("content", "")
        role = message.get("role", "assistant")
        message_id = message.get("id", str(uuid.uuid4()))
    # 3. fallback
    else:
        content = str(message)
        role = "assistant"
        message_id = str(uuid.uuid4())

    # Flatten if content is a list of structured blocks
    if isinstance(content, list):
        parts = []
        for block in content:
            if isinstance(block, dict) and "text" in block:
                parts.append(block["text"])
            else:
                parts.append(str(block))
        content = "\n".join(parts)

    # Ensure content is always string
    if not isinstance(content, str):
        content = str(content)

    return message_id, content, role

