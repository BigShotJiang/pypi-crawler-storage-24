import os
import tempfile

from pathlib import Path

import urgap

urgap_ascii = """

                                                             88
                                                             88
                                                             88
88       88  8b,dPPYba,  ,adPPYba,   ,adPPYb,d8  ,adPPYYba,  88
88       88  88P'   "Y8  I8[    ""  a8"    `Y88  ""     `Y8  88
88       88  88           `"Y8ba,   8b       88  ,adPPPPP88  88
"8a,   ,a88  88          aa    ]8I  "8a,   ,d88  88,    ,88  88
 `"YbbdP'Y8  88          `"YbbdP"'   `"YbbdP"Y8  `"8bbdP"Y8  88
                                     aa,    ,88
                                      "Y8bbdP"
"""


def test_uio_calculate_md5_standard():
    with tempfile.NamedTemporaryFile(mode="w", delete=False, newline="\n") as output:
        print(urgap_ascii, file=output)

    output_md5 = urgap.ucore.calculate_file_hash(
        Path(output.name),
        hash_algorithm="md5",
    )
    os.remove(output.name)
    assert output_md5 == "8d6c9484a6b6f329a9ae57a1f8837e7e"
