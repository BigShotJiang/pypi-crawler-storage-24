.. urgap

Welcome to urgap


urgap is a node wrapping framework, containing abstraction layers for data and meta data, extensive re-run skipping logic and data versioning. urgap can be incorporated with any scheduling/pipelining tool making pipeline development independent from business logic and data storage, while offering standardized logging and execution, which makes monitoring and debugging easy.


Documentation
=============

.. toctree::
   :glob:
   :maxdepth: 2
   :caption: Main:

   getting_started
   quickstart
   concepts
   advanced_topics
   faq
   third_party
   example_scripts
   resource_wrapping

.. toctree::
   :glob:
   :maxdepth: 2
   :caption: Developer:

   api_docs
   contributing
   appendix

The latest Documentation was generated on: |today|
