# Configuration file for the Sphinx documentation builder.
#
# This file only contains a selection of the most common options. For a full
# list see the documentation:
# https://www.sphinx-doc.org/en/master/usage/configuration.html

# -- Path setup --------------------------------------------------------------

# If extensions (or modules to document with autodoc) are in another directory,
# add these directories to sys.path here. If the directory is relative to the
# documentation root, use os.path.abspath to make it absolute, like shown here.
import os
import sys
from importlib.metadata import version
from pathlib import Path

sys.path.insert(0, os.path.abspath("../../"))
for example_file in Path("../../example_scripts").glob("**/*.py"):
    sys.path.insert(0, str(example_file.parent.resolve()))

# -- Project information -----------------------------------------------------

project = "urgap"
copyright = "2021, urgap Team"
author = "urgap Team"

# The full version, including alpha/beta/rc tags stored in version.txt
# version_path = os.path.join(
#     os.path.dirname(__file__), os.pardir, os.pardir, "urgap", "version.txt"
# )
# with open(version_path, "r") as version_file:
#     urgap_version = version_file.read().strip()

# The full version, including alpha/beta/rc tags.
release = version("urgap")
# @TODO@MKoesters: Could not build docs with above code, creating git tag did not help
# Need to get this working
# release = "1.0.0"
# # for example take major/minor
version = ".".join(release.split(".")[:2])

# -- General configuration ---------------------------------------------------

# Add any Sphinx extension module names here, as strings. They can be
# extensions coming with Sphinx (named 'sphinx.ext.*') or your custom
# ones.
extensions = [
    "sphinx.ext.autodoc",
    "sphinx.ext.napoleon",
    "sphinx.ext.githubpages",
    "nbsphinx",
]

nbsphinx_execute = "never"


def setup(app):
    import shutil

    tutorial_src = Path(app.srcdir).parent / "tutorial"
    tutorial_dst = Path(app.srcdir) / "tutorial"
    if tutorial_src.exists():
        shutil.copytree(tutorial_src, tutorial_dst, dirs_exist_ok=True)

# Add any paths that contain templates here, relative to this directory.
templates_path = ["_templates"]

# List of patterns, relative to source directory, that match files and
# directories to ignore when looking for source files.
# This pattern also affects html_static_path and html_extra_path.
exclude_patterns = ["_build", "Thumbs.db", ".DS_Store"]


# -- Options for HTML output -------------------------------------------------

# The theme to use for HTML and HTML Help pages.  See the documentation for
# a list of builtin themes.
#
html_theme = "sphinx_rtd_theme"

# Add any paths that contain custom static files (such as style sheets) here,
# relative to this directory. They are copied after the builtin static files,
# so a file named "default.css" will overwrite the builtin "default.css".
# html_static_path = ["_static"]

# autodoc_typehints = "description"
