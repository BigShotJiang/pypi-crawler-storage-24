"""IOCreds submodule of urgap."""
