"""Init VennDiagram."""
