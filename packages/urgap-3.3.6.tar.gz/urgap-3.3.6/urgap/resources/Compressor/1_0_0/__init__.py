"""Init Compressor 1_0_0 resource."""
