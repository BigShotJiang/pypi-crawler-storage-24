"""Init Compressor resources."""
