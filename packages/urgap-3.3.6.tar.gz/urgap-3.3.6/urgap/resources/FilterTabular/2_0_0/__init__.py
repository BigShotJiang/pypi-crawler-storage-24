"""Init FilterTabular 2_0_0 resource."""
