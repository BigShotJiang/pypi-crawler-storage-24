"""Init urgap resources."""
