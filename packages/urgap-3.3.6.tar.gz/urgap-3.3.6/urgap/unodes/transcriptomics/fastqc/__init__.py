"""FastQC wrapper."""
