"""Transcriptomic metrics wrappers."""
