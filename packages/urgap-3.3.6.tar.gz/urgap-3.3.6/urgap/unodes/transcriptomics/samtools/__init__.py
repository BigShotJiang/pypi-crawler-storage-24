"""Samtools wrappers."""
