"""Cutadapt wrappers."""
