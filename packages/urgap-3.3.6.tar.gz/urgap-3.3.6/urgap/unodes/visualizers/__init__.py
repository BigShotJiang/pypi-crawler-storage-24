"""Init VennDiagram Unode."""
