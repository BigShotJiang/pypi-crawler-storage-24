"""Init Filter tabular to xlsx Unode."""
