#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

if ! command -v helm >/dev/null 2>&1; then
  echo "helm not available, skipping chart lint/render test"
  exit 0
fi

helm lint "$ROOT_DIR/helm" -f "$ROOT_DIR/helm/node-piccolo.yaml" -f "$ROOT_DIR/helm/replicas.yaml"
rendered_default="$(mktemp)"
rendered_router_scouter="$(mktemp)"
rendered_base="$(mktemp)"
trap 'rm -f "$rendered_default" "$rendered_router_scouter" "$rendered_base"' EXIT

helm template shenron "$ROOT_DIR/helm" -f "$ROOT_DIR/helm/node-piccolo.yaml" -f "$ROOT_DIR/helm/replicas.yaml" >"$rendered_default"
helm template shenron "$ROOT_DIR/helm" >"$rendered_base"

if ! grep -q "app.kubernetes.io/component: caddy" "$rendered_default"; then
  echo "expected caddy resources to be rendered in default profile" >&2
  exit 1
fi

if ! grep -q "handle_path /llm/*" "$rendered_default"; then
  echo "expected caddy to route /llm/* in default profile" >&2
  exit 1
fi

if ! grep -q "name: shenron-replica-manager" "$rendered_default"; then
  echo "expected replica manager resources to be rendered in default profile" >&2
  exit 1
fi

if ! grep -q "REPLICA_MANAGER_TOKEN" "$rendered_default"; then
  echo "expected replica manager auth env var wiring in default profile" >&2
  exit 1
fi

if grep -q "app.kubernetes.io/component: router" "$rendered_default"; then
  echo "did not expect router resources when router.enabled=false in models profile" >&2
  exit 1
fi

if grep -q "http://shenron-router-" "$rendered_default"; then
  echo "did not expect onwards targets to point to router services when router.enabled=false" >&2
  exit 1
fi

if ! grep -q '"url": "http://shenron-' "$rendered_default"; then
  echo "expected onwards targets to point to model services in default profile" >&2
  exit 1
fi

if grep -q "app.kubernetes.io/component: scouter-reporter" "$rendered_default"; then
  echo "did not expect scouter reporter resources when scouterReporter.enabled=false in models profile" >&2
  exit 1
fi

helm template shenron "$ROOT_DIR/helm" -f "$ROOT_DIR/helm/node-piccolo.yaml" -f "$ROOT_DIR/helm/replicas.yaml" \
  --set router.enabled=true \
  --set scouterReporter.enabled=true \
  --set prometheus.enabled=true >"$rendered_router_scouter"

if ! grep -q "app.kubernetes.io/component: router" "$rendered_router_scouter"; then
  echo "expected router resources to be rendered when router.enabled=true" >&2
  exit 1
fi

if ! grep -q -- "--service-discovery" "$rendered_router_scouter"; then
  echo "expected router deployments to enable service discovery" >&2
  exit 1
fi

if ! grep -q "http://shenron-router-" "$rendered_router_scouter"; then
  echo "expected onwards targets to point to router services when router.enabled=true" >&2
  exit 1
fi

if ! grep -q "app.kubernetes.io/component: scouter-reporter" "$rendered_router_scouter"; then
  echo "expected scouter reporter resources when scouterReporter.enabled=true" >&2
  exit 1
fi

if ! grep -q "SCOUTER_MODE" "$rendered_router_scouter"; then
  echo "expected scouter reporter env wiring when scouterReporter.enabled=true" >&2
  exit 1
fi

if ! grep -q "SCOUTER_INGEST_API_KEY" "$rendered_router_scouter"; then
  echo "expected scouter reporter API key secret wiring when scouterReporter.enabled=true" >&2
  exit 1
fi

if ! grep -q 'value: "http://shenron-prometheus:9090"' "$rendered_router_scouter"; then
  echo "expected scouter reporter to target in-cluster prometheus service by default" >&2
  exit 1
fi

assert_model_has_shm() {
  local file="$1"
  local model="$2"

  if ! awk -v model="$model" '
    index($0, "  " model ":") == 1 { in_model=1; next }
    in_model && $0 ~ /^  [^[:space:]].*:/ { exit(found ? 0 : 1) }
    in_model && $0 == "    shm:" { saw_shm=1; next }
    in_model && saw_shm && $0 == "      enabled: true" { found=1; exit 0 }
    END { exit(in_model && found ? 0 : (found ? 0 : 1)) }
  ' "$file"; then
    echo "expected $file to enable shm for $model" >&2
    exit 1
  fi
}

for model in \
  "Qwen/Qwen3-VL-235B-A22B-Instruct-FP8" \
  "Qwen/Qwen3-VL-30B-A3B-Instruct-FP8" \
  "Qwen/Qwen3.5-122B-A10B-FP8" \
  "Qwen/Qwen3.5-27B-FP8" \
  "Qwen/Qwen3.5-35B-A3B-FP8" \
  "Qwen/Qwen3.5-397B-A17B-FP8" \
  "Qwen/Qwen3.5-9B" \
  "Qwen/Qwen3.5-4B" \
  "openai/gpt-oss-120b" \
  "google/medgemma-27b-it" \
  "deepseek-ai/DeepSeek-OCR-2" \
  "lightonai/LightOnOCR-2-1B" \
  "allenai/olmOCR-2-7B-1025-FP8"
do
  assert_model_has_shm "$ROOT_DIR/helm/node-piccolo.yaml" "$model"
done

for model in \
  "Qwen/Qwen3-VL-235B-A22B-Instruct-FP8" \
  "Qwen/Qwen3-VL-30B-A3B-Instruct-FP8" \
  "Qwen/Qwen3.5-122B-A10B-FP8" \
  "Qwen/Qwen3.5-27B-FP8" \
  "Qwen/Qwen3.5-35B-A3B-FP8" \
  "Qwen/Qwen3.5-397B-A17B-FP8" \
  "Qwen/Qwen3.5-9B" \
  "Qwen/Qwen3.5-4B" \
  "google/medgemma-27b-it" \
  "deepseek-ai/DeepSeek-OCR-2" \
  "lightonai/LightOnOCR-2-1B" \
  "allenai/olmOCR-2-7B-1025-FP8"
do
  assert_model_has_shm "$ROOT_DIR/helm/node-chiaotzu.yaml" "$model"
done

if grep -q "OTEL_EXPORTER_OTLP_ENDPOINT" "$rendered_base"; then
  echo "did not expect OTEL env vars to be auto-injected into rendered manifests" >&2
  exit 1
fi

if grep -q "\-\-enable-trace" "$rendered_base"; then
  echo "did not expect tracing flags to be auto-injected into rendered manifests" >&2
  exit 1
fi

if grep -q "\-\-otlp-traces-endpoint" "$rendered_base"; then
  echo "did not expect OTLP trace endpoint flags to be auto-injected into rendered manifests" >&2
  exit 1
fi

echo "helm chart lint/template succeeded for default and router+scouter profiles"
