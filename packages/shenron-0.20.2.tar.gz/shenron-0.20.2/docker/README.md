# Docker Notes

The primary deployment flow is now config-first via the `shenron` CLI:

```bash
uv pip install shenron
wget https://github.com/doublewordai/shenron-configs/releases/download/v0.5.3/Qwen06B-cu126-TP1.yml
shenron .
docker compose up -d
```

`shenron` generates `docker-compose.yml` and the `.generated/*` runtime files in your target directory.

## CUDA Images

CUDA-specific runtime images are still built from:
- `docker/Dockerfile.vllm.cu126`
- `docker/Dockerfile.sglang.cu126`
- `docker/Dockerfile.vllm.cu129`
- `docker/Dockerfile.sglang.cu129`
- `docker/Dockerfile.vllm.cu130`
- `docker/Dockerfile.sglang.cu130`

Additional Kubernetes-focused images:
- `docker/Dockerfile.sglang-router` (runs `sglang_router.launch_router`)
- `docker/Dockerfile.replica-manager` (runs the Helm-backed replica manager API)

CI continues to build and push those images through Depot when Dockerfiles or `VERSION` change.
