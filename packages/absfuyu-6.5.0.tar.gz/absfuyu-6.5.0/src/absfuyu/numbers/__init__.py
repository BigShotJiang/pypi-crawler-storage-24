"""
Absfuyu: Numbers
----------------
Numbers related

Version: 6.5.0
Date updated: 04/02/2026 (dd/mm/yyyy)
"""


from absfuyu.numbers.number_to_word import NumberToWords
from absfuyu.numbers.shorten_number import Decimal
from absfuyu.numbers.time_duration import Duration
