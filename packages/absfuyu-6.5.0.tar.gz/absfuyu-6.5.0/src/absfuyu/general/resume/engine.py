"""
Absfuyu: Resume
---------------
Resume Engine

Version: 6.5.0
Date updated: 27/02/2026 (dd/mm/yyyy)
"""

# Module level
# ---------------------------------------------------------------------------
__all__ = ["CVEngine"]


# Library
# ---------------------------------------------------------------------------
from absfuyu.general.resume.exporter import ExportRegistry
from absfuyu.general.resume.func import ExperienceSorter, LatestFirstSorter
from absfuyu.general.resume.models import CV


# Class
# ---------------------------------------------------------------------------
class CVEngine:
    """
    CV Engine
    """

    def __init__(self, sorter: ExperienceSorter | None = None):
        self.sorter = sorter or LatestFirstSorter()

    @property
    def available_export_format(self) -> list[str]:
        return list(ExportRegistry._registry.keys())

    def render(self, cv: CV, format_name: str) -> str | bytes:
        cv.experiences = self.sorter.sort(cv.experiences)
        exporter = ExportRegistry.get(format_name)
        return exporter.export(cv)
