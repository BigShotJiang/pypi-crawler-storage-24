"""
Absfuyu: Resume
---------------
Resume Builder

Version: 6.5.0
Date updated: 27/02/2026 (dd/mm/yyyy)
"""

# Module level
# ---------------------------------------------------------------------------
__all__ = ["CVBuilder"]


# Library
# ---------------------------------------------------------------------------
from typing import Self

from absfuyu.general.resume.models import (
    CV,
    Education,
    Experience,
    PersonalInfo,
    Project,
)


# Class
# ---------------------------------------------------------------------------
class CVBuilder:
    def __init__(self, personal: PersonalInfo):
        self._cv = CV(personal=personal)

    def summary(self, text: str) -> Self:
        self._cv.summary = text
        return self

    def add_skill(self, skill: str) -> Self:
        self._cv.skills.append(skill)
        return self

    def add_experience(self, experience: Experience) -> Self:
        self._cv.experiences.append(experience)
        return self

    def add_education(self, education: Education) -> Self:
        self._cv.education.append(education)
        return self

    def add_project(self, project: Project) -> Self:
        self._cv.projects.append(project)
        return self

    def build(self) -> CV:
        return self._cv
