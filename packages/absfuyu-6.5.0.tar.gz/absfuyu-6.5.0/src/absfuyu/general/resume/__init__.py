"""
Absfuyu: Resume
---------------
Resume

Version: 6.5.0
Date updated: 01/03/2026 (dd/mm/yyyy)
"""

# Module level
# ---------------------------------------------------------------------------
__all__ = [
    "CVBuilder",
    "CVEngine",
    "CV",
    "Education",
    "Experience",
    "PersonalInfo",
    "Project",
    "LatestFirstSorter",
    "ExperienceSorter",
    "Exporter",
]


# Library
# ---------------------------------------------------------------------------
from absfuyu.general.resume.builder import CVBuilder
from absfuyu.general.resume.engine import CVEngine
from absfuyu.general.resume.exporter import (
    DictExporter,
    Exporter,
    ExportRegistry,
    JSONExporter,
    MarkdownExporter,
)
from absfuyu.general.resume.func import ExperienceSorter, LatestFirstSorter
from absfuyu.general.resume.models import (
    CV,
    Education,
    Experience,
    PersonalInfo,
    Project,
)

# Register export format
# ---------------------------------------------------------------------------
ExportRegistry.register(DictExporter)
ExportRegistry.register(JSONExporter)
ExportRegistry.register(MarkdownExporter)


# Class
# ---------------------------------------------------------------------------


if __name__ == "__main__":
    from datetime import date

    from rich import print

    # Build CV
    personal = PersonalInfo(full_name="John Doe", email="john@doe.com", phone="0123456789", location="Unknown")

    cv = (
        CVBuilder(personal)
        .summary("Python developer")
        .add_skill("Python")
        .add_skill("Markdown")
        .add_experience(Experience("ABC Company", "Developer", date(2025, 1, 1), achievements=["Maintain system"]))
        .add_education(Education("JJJ", "BA", 2020, 2025))
        .build()
    )

    engine = CVEngine()
    output = engine.render(cv, "json")
    print(output)
