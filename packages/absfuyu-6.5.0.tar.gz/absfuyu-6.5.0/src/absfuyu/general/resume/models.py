"""
Absfuyu: Resume
---------------
Resume Model

Version: 6.5.0
Date updated: 27/02/2026 (dd/mm/yyyy)
"""

# Module level
# ---------------------------------------------------------------------------
__all__ = ["PersonalInfo", "Experience", "Education", "Project", "CV"]


# Library
# ---------------------------------------------------------------------------
from dataclasses import dataclass, field
from datetime import date


# Class - Section
# ---------------------------------------------------------------------------
@dataclass(slots=True)
class PersonalInfo:
    """
    Personal information section of a CV.

    Attributes
    ----------
    full_name : str
        Candidate full name.

    email : str | None
        Contact email.

    phone : str | None
        Contact phone number.

    location : str | None
        City or country.

    linkedin : str | None
        LinkedIn profile URL.

    github : str | None
        GitHub profile URL.
    """

    full_name: str
    email: str | None = None
    phone: str | None = None
    location: str | None = None
    linkedin: str | None = None
    github: str | None = None


@dataclass(slots=True)
class Experience:
    """
    Work experience entry.

    Attributes
    ----------
    company : str
        Company name.

    role : str
        Job title.

    start_date : date
        Start date.

    end_date : date | None
        End date (``None`` if current).

    achievements : list[str]
        Key achievements or responsibilities.
    """

    company: str
    role: str
    start_date: date
    end_date: date | None = None
    achievements: list[str] = field(default_factory=list)


@dataclass(slots=True)
class Education:
    """
    Education entry.

    Attributes
    ----------
    institution : str
        School or university name.

    degree : str
        Degree name.

    start_year : int
        Start year.

    end_year : int
        End year.

    location : str | None
        Location.
    """

    institution: str
    degree: str
    start_year: int
    end_year: int
    location: str | None = None


@dataclass(slots=True)
class Project:
    """
    Project entry.

    Attributes
    ----------
    name : str
        Project name.

    description : str
        Short description.

    technologies : list[str]
        Tech stack used.

    link : str | None
        Link to project.
    """

    name: str
    description: str
    technologies: list[str] = field(default_factory=list)
    link: str | None = None


# Class
# ---------------------------------------------------------------------------
@dataclass(slots=True)
class CV:
    """
    Curriculum Vitae model.

    Attributes
    ----------
    personal : PersonalInfo
        Personal information section.

    summary : str
        Professional summary.

    experiences : list[Experience]
        Work experience list.

    education : list[Education]
        Education list.

    skills : list[str]
        List of skills.

    projects : list[Project]
        Projects list.
    """

    personal: PersonalInfo
    summary: str = ""
    experiences: list[Experience] = field(default_factory=list)
    education: list[Education] = field(default_factory=list)
    skills: list[str] = field(default_factory=list)
    projects: list[Project] = field(default_factory=list)
