"""
Absfuyu: General
----------------
Collection of useful classes

Version: 6.5.0
Date updated: 04/02/2026 (dd/mm/yyyy)

Features:
---------
- content
- generator
- human
"""

# Module level
# ---------------------------------------------------------------------------
__all__ = ["content", "shape", "human"]


# Libary
# ---------------------------------------------------------------------------
from absfuyu.general import content, human, shape
