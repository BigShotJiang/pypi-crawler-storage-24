"""
Absfuyu: Core
-------------
Dummy functions when other libraries are unvailable

Version: 6.5.0
Date updated: 04/02/2026 (dd/mm/yyyy)
"""

# Module Package
# ---------------------------------------------------------------------------
__all__ = [
    "tqdm",
    "tqdm2",
    "unidecode",
    "dummy_function",
]


# Library
# ---------------------------------------------------------------------------
from functools import partial
from importlib import import_module
from typing import overload

# Wrapper
# ---------------------------------------------------------------------------
# tqdm wrapper
try:
    _tqdm = import_module("tqdm")
    tqdm = getattr(_tqdm, "tqdm")  # noqa
    tqdm2 = partial(tqdm, unit_scale=True, dynamic_ncols=True)
except (ImportError, AttributeError):

    def tqdm[T](iterable: T, *args, **kwargs) -> T:
        """
        Dummy tqdm function,
        install package ``tqdm`` to fully use this feature
        """
        return iterable

    tqdm2 = tqdm


# unidecode wrapper
try:
    _unidecode = import_module("unidecode")
    unidecode = getattr(_unidecode, "unidecode")  # noqa
except (ImportError, AttributeError):

    def unidecode(string: str, errors: str = "ignore", replace_str: str = "?") -> str:
        """
        Dummy unidecode function,
        install package ``unidecode`` to fully use this feature
        """
        return string


# dummy
@overload
def dummy_function() -> None: ...
@overload
def dummy_function[T](*args: T, **kwargs: T) -> T: ...
def dummy_function[T](*args: T, **kwargs: T) -> T | None:
    """This is a dummy function"""
    if args:
        return args[0]
    if kwargs:
        return kwargs[list(kwargs)[0]]
    return None
