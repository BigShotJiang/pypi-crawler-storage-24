"""
Absfuyu: Audio
--------------
Audio related

Version: 6.5.0
Date updated: 04/02/2026 (dd/mm/yyyy)
"""
