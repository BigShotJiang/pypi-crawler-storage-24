#!/bin/bash
set -e

echo "===== Installing Cline CLI ====="

# Update system packages
apt-get update
apt-get install -y curl ca-certificates

# Install Node.js via nvm
echo "Installing Node.js via nvm..."
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.2/install.sh | bash
export NVM_DIR="$HOME/.nvm"
[ -s "$NVM_DIR/nvm.sh" ] && . "$NVM_DIR/nvm.sh"
nvm install 22
nvm use 22
nvm alias default 22

echo "Node.js installed: $(node --version)"
echo "Default Node version set to 22"

# Install Cline CLI globally (nightly version with latest changes)
echo "Installing Cline CLI nightly..."
npm install -g cline@nightly
sleep 0.5

echo "Cline CLI version:"
cline version || echo "(version command may not be available)"

echo "===== Cline CLI installation complete ====="
echo "Note: Configuration will be done at runtime with provider-specific credentials"
