#!/bin/bash

apt-get update
apt-get install -y curl

curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.40.2/install.sh | bash

source "$HOME/.nvm/nvm.sh"

nvm install 22
npm -v

{% if version %}
npm install -g @openai/codex@{{ version }}
{% else %}
npm install -g @openai/codex@latest
{% endif %}
