from bb_integrations_lib.protocols.pipelines import Step
from bb_integrations_lib.shared.model import RawData


class SaveRawDataToDiskStep(Step):
    """Save a RawData object to disk in the current working directory."""
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    def describe(self) -> str:
        return "Save a RawData object to the current working directory"

    async def execute(self, i: RawData | list[RawData]) -> None:
        items = i if isinstance(i, list) else [i]
        for item in items:
            with open(item.file_name, "wb") as f:
                f.write(item.data.read() if hasattr(item.data, "read") else item.data)
