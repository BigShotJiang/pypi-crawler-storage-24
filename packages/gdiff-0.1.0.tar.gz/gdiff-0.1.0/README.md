# gdiff

A web-based side-by-side git diff viewer. Generates a self-contained HTML page with syntax highlighting and opens it in your browser.

## Installation

```bash
pip install gdiff
```

For syntax highlighting (recommended):

```bash
pip install gdiff[highlight]
```

## Usage

```bash
# Diff a specific file
gdiff path/to/file.py

# Staged changes
gdiff --staged path/to/file.py

# All unstaged changes
gdiff

# Pipe mode
git diff | gdiff

# Save without opening browser
gdiff --no-open -o diff.html

# Compare branches/commits
gdiff main..feature -- path/to/file.py
```

## Features

- **Side-by-side view** with old code on the left, new code on the right
- **Syntax highlighting** for 500+ languages (via pygments)
- **Dark theme** inspired by GitHub
- **Line numbers** on both sides
- **File navigation** header with clickable links
- **Keyboard navigation** (`j`/`k` to jump between files)
- **Zero config** - works out of the box
- **Fully offline** - generates a self-contained HTML file

## Requirements

- Python 3.8+
- Git

## License

MIT - Younes Boukdir
