# frawdbot
> Insider threat detection for Google Workspace
**Official package by Colin McNamara LLC.** Namespace reservation.
- Website: https://frawdbot.ai
- License: Proprietary
