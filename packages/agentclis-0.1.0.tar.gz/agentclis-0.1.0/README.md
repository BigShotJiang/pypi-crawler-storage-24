# agentclis

Official Python package for Agentclis.

## Status

`agentclis` is currently a bootstrap release.

This package is published as the official Python entry for Agentclis on PyPI.
It is intentionally minimal at this stage.

Future releases are expected to distribute the official Agentclis CLI and related binaries.

## Installation

```bash
pip install agentclis
```

## Usage

```bash
agentclis
agentclis --version
python -m agentclis
```

## Notes

- This is the official `agentclis` package on PyPI.
- This package is currently minimal by design.
- Source code for Agentclis is not published at this time.

## Links

- Homepage: https://agentable.ai

## License

Proprietary.
