import argparse

from agentclis import __version__


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="agentclis",
        description="Official Python package for Agentclis.",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )
    return parser


def main() -> int:
    parser = build_parser()
    parser.parse_args()

    print("Agentclis")
    print(f"Version: {__version__}")
    print("Status: bootstrap release")
    print("This is the official Agentclis package on PyPI.")
    print("Future releases will distribute the official Agentclis CLI and related binaries.")
    return 0
