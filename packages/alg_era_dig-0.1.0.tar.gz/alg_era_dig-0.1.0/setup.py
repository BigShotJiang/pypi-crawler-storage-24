from setuptools import setup, find_packages

with open('README.md', 'r', encoding='utf-8') as f:
    long_description = f.read()

setup(
	name = 'alg-era-dig',
	version = '0.1.0',
        license = 'MIT',
        author_email = 'basthianvalenzuela08@gmail.com',
        project_urls = {
            'Source': 'https://github.com/BasthianV/alg-era-dig'
        },
	packages = find_packages(),
	install_requires = [
		'numpy >= 2.3.4',
                'sympy >= 1.14.0',
                'hilbertcurve >= 2.0.5',
                'matplotlib >= 3.10.7',
                'matplotlib-venn >= 1.1.2'
	],
	entry_points = {
		'console_scripts': [
			'ac-dc=alg_era_dig.ac_dc:main',
                        'circuito-2=alg_era_dig.circuito_2_interruptores:main',
                        'circuito-6=alg_era_dig.circuito_6_interruptores:main',
                        'composicion=alg_era_dig.composicion_funciones:main',
                        'hilbert=alg_era_dig.curva_hilbert:main',
                        'inversa=alg_era_dig.funcion_inversa:main',
                        'conversor-logico=alg_era_dig.conversor_logico:main',
                        'venn-2=alg_era_dig.operacion_2_sets:main',
                        'venn-3=alg_era_dig.operacion_3_sets:main',
                        'proyectil=alg_era_dig.proyectil:main',
                        'recta-hor=alg_era_dig.prueba_recta_horizontal:main',
                        'raices-unitarias=alg_era_dig.raices_unitarias:main',
                        'trig-suma=alg_era_dig.suma_funciones_trigonometricas:main',
                        'transformador=alg_era_dig.transformador_funciones:main',
                        'triangulo-rect=alg_era_dig.triangulo_rectangulo_2_lados:main',
                        'trig-ecuaciones=alg_era_dig.trigonometria_ecuaciones_basicas:main',
                        'trig-recta-hor=alg_era_dig.trigonometria_recta_horizontal:main',
                        'teorema-seno=alg_era_dig.trigonometria_teorema_seno:main',
                        'trig-tiempo=alg_era_dig.trigonometria_tiempo_interactivo:main',
                        'trig-variables=alg_era_dig.trigonometria_variables_interactivo:main',
                        'trig-voltaje=alg_era_dig.trigonometria_voltaje:main'
		]
	},
        package_data = {'alg_era_dig': ['images/*']},
        description = 'Repositorio oficial de programas del libro Introducción al Álgebra en la Era Digital, del Dr. Eric Jeltsch Figueroa',
	long_description = long_description,
	long_description_content_type = 'text/markdown'
)
