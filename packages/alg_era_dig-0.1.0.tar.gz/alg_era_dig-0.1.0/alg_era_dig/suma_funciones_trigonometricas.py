from .interfaz import *
from numpy import linspace, sin, pi, radians
from sympy import symbols, sympify, solve, latex

RESOLUTION = 1000
A = 10
F = 60

class SumaOndasFrame(SimpleInteractiveGraphFrame):
    def __init__(self, controlador):
        self.controlador = controlador
        super().__init__(controlador)
        
        # 1. Inicialización de interfaz general
        self.setPanels(ejes=2, horizontal=False, toolBar=False)

        # 2. Panel de interacción con la gráfica
        self.panelDesfase = tk.Frame(self.panelDown)
        self.panelDesfase.pack(fill='x', expand=True)
        tk.Label(self.panelDesfase, text='Desfase\n(grados)', font=TEXT_FONT, width=LABEL_GRAL_WIDTH).pack(side='left', padx=GRAL_PAD)
        self.sliderDesfase = tk.Scale(self.panelDesfase, from_=0, to=180, font=SLIDER_FONT, resolution=1, orient='horizontal', command=self.__updateGraph)
        self.sliderDesfase.pack(side='left', fill='x', expand=True, padx=GRAL_PAD)
        self.sliderDesfase.set(0)

        # 3. Gráfica
        self.__updateGraph(init=True)

    def v1(self, t):
        return A * sin(self.omega * t)

    def v2(self, t, phi):
        return A * sin(self.omega * t + phi)

    def __updateGraph(self, _=None, *, init=False):
        if init:
            self.t = np.linspace(0, 1/F, RESOLUTION)
            self.omega = 2 * pi * F
            self.v1Y = self.v1(self.t)
            self.ejes[0].plot(self.t * 1000, self.v1Y, color='blue', label=rf'$V_{{1}}(t)={A}\cdot\sin{{({self.omega:.3f}t)}}$')
            v2Y = self.v2(self.t, 0)
            self.lineV2, = self.ejes[0].plot(self.t * 1000, v2Y, color='green', label=rf'$V_{{2}}(t)={A}\cdot\sin{{({self.omega:.3f}t)}}$')
            self.lineSum, = self.ejes[1].plot(self.t * 1000, self.v1Y + v2Y, color='red', label=r'$V_{T}=V_{1}+V_{2}$')
            for i in range(2):
                self.ejes[i].set_xlabel('Tiempo (ms)')
                self.ejes[i].set_ylabel('Voltaje (V)')
                self.ejes[i].grid(True)
                self.ejes[i].set_xlim(0, 1000/F)
                self.ejes[i].legend()
            self.setLineasEjes(self.ejes, variosEjes=True)
            self.ejes[0].set_title('Señales individuales')
            self.ejes[1].set_title('Señal resultante')
            plt.tight_layout()
        else:
            phi = radians(self.sliderDesfase.get())
            v2Y = self.v2(self.t, phi)
            self.lineV2.set_data(self.t * 1000, v2Y)
            self.lineSum.set_data(self.t * 1000, self.v1Y + v2Y)
            self.lineV2.set_label(rf'$V_{{2}}(t)={A}\cdot\sin{{({self.omega:.3f}t+{phi:.3f})}}$')
            self.lineSum.set_label(r'$V_{T}=V_{1}+V_{2}$')
            self.ejes[0].legend()
            self.ejes[1].legend()
            self.canvas.draw()

def main():
    app = Controlador(
        title='III. Funciones — Suma de Funciones trigonométricas',
        firstFrame=SumaOndasFrame,
        height=800, width=775
    )
    app.mainloop()

if __name__ == '__main__':
    main()
