from .interfaz import *
from .circuito import *

class FrameCircuito2(FrameCircuito):
    def __init__(self, circuito):
        self.circuito = circuito
        super().__init__(circuito)

        # 1. Panel principal
        self.panel = tk.Frame(self)
        self.panel.pack(expand=True)

        self.setPanels(self.panel)
        self.__set_circuit()
        interruptores = self.setInterruptores(2, 45)
        self.__setMenu()
        self.setBombilla()

    def __setMenu(self):
        self.operacion = tk.StringVar(self.panel_up_right)
        self.operacion.set('A ∧ B')
        menu_operaciones = tk.OptionMenu(self.panel_up_right, self.operacion, 'A ∧ B', 'A ∨ B', 'A ⇒ B', 'B ⇒ A', command=self.__cambio_operacion)
        menu_operaciones.config(font=TEXT_FONT)
        menu_operaciones['menu'].config(font=TEXT_FONT)
        menu_operaciones.pack(side='top')

    def __set_circuit(self):
        self.interruptoresLines = {'A': [], 'B': []}

        # Línea de A
        self.interruptoresLines['A'].append(self.canvas.create_line(70, 10, 70, 140, fill='gray', width=2))
        self.interruptoresLines['A'].append(self.canvas.create_line(70, 140, 250, 140, fill='gray', width=2))

        # Línea de B
        self.interruptoresLines['B'].append(self.canvas.create_line(185, 10, 185, 120, fill='gray', width=2))
        self.interruptoresLines['B'].append(self.canvas.create_line(185, 120, 250, 120, fill='gray', width=2))

        # Operadores
        # 1. And
        self.circuit_and = self.createCircuitAnd(x=250, upY=120, downY=140)
        self.operator = self.circuit_and

        # 2. Or
        self.circuit_or = self.createCircuitOr(x=250, upY=120, downY=140)
        self.__show_or_hide_circuit_operator(self.circuit_or, show=False)

        # 3. Negación
        # 3.1. A
        self.circuit_not_a = [self.canvas.create_oval(250, 140+NOT_CIRCLE_RADIUS, 250-2*NOT_CIRCLE_RADIUS, 140-NOT_CIRCLE_RADIUS, fill=OPERATOR_CIRCUIT_COLOR, outline=OPERATOR_CIRCUIT_COLOR, width=2)]
        self.__show_or_hide_circuit_operator(self.circuit_not_a, show=False)

        # 3.2. B
        self.circuit_not_b = [self.canvas.create_oval(250, 120+NOT_CIRCLE_RADIUS, 250-2*NOT_CIRCLE_RADIUS, 120-NOT_CIRCLE_RADIUS, fill=OPERATOR_CIRCUIT_COLOR, outline=OPERATOR_CIRCUIT_COLOR, width=2)]
        self.__show_or_hide_circuit_operator(self.circuit_not_b, show=False)

        # A la derecha del operador
        self.hline_bombilla = self.canvas.create_line(310, 130, 450, 130, fill='gray', width=2)
        self.vline_bombilla = self.canvas.create_line(450, 130, 450, 10, fill='gray', width=2)

    def __show_or_hide_circuit_operator(self, operator, show):
        if show:
            state = 'normal'
        else:
            state = 'hidden'
        for segment in operator:
            self.canvas.itemconfig(segment, state=state)

    def __cambio_operacion(self, _):
        # Ocultamiento del operador actualmente mostrado
        self.__show_or_hide_circuit_operator(self.operator, show=False)

        # Actualización del operador
        match self.operacion.get():
            case 'A ∧ B':
                 self.operator = self.circuit_and
            case 'A ∨ B':
                self.operator = self.circuit_or
            case 'A ⇒ B':
                self.operator = self.circuit_not_a + self.circuit_or
            case 'B ⇒ A':
                self.operator = self.circuit_not_b + self.circuit_or

        # Mostración del nuevo operador
        self.__show_or_hide_circuit_operator(self.operator, show=True)
        self.check_bombilla()

    def encendido(self, interruptores):
        match self.operacion.get():
            case 'A ∧ B':
                ans = interruptores['A'] and interruptores['B']
            case 'A ∨ B':
                ans = interruptores['A'] or interruptores['B']
            case 'A ⇒ B':
                ans = not interruptores['A'] or interruptores['B'] # DNF
            case 'B ⇒ A':
                ans = not interruptores['B'] or interruptores['A'] # DNF
        return ans

def main():
    app = Controlador(
        title='II. Lógica y Conjuntos — Circuito de 2 Interruptores',
        firstFrame=FrameCircuito2,
        height=500, width=700
    )
    app.mainloop()

if __name__ == '__main__':
    main()
