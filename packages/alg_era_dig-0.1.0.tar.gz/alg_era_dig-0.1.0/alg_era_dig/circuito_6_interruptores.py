from .interfaz import *
from .circuito import *

class FrameCircuito6(FrameCircuito):
    def __init__(self, circuito):
        self.circuito = circuito
        super().__init__(circuito)

        # 1. Panel principal
        self.panel = tk.Frame(self)
        self.panel.pack(expand=True)

        self.__setExprLabel()
        self.setPanels(self.panel)
        self.__set_circuit()
        interruptores = self.setInterruptores(6, 5)
        self.setBombilla()

    def __setExprLabel(self):
        exprLabel = tk.Label(self.panel, text='A ∧ B ∧ (C ∨ D ∨ E) ∧ F', font=TEXT_FONT)
        exprLabel.pack(side='top')

    def __set_circuit(self):

        self.interruptoresLines = {'A': [], 'B': [], 'C': [], 'D': [], 'E': [], 'F': []}
        
        x = 25
        y = 140
        shiftX = 41
        shiftY = 20
        orX = 220
        andX = 300
        width = 60

        # And
        andDownY = y - shiftY - shiftY / 2
        self.circuit_and = self.createCircuitAnd(x=andX, upY=andDownY-2*shiftY, downY=andDownY, shift=10, width=width)

        # A
        self.interruptoresLines['A'].append(self.canvas.create_line(x, 10, x, y, fill='gray', width=2))
        self.interruptoresLines['A'].append(self.canvas.create_line(x, y, orX+width, y, fill='gray', width=2))
        self.interruptoresLines['A'].append(self.canvas.create_line(orX+width, y, andX, andDownY, fill='gray', width=2))
        x += shiftX
        y -= shiftY

        # B
        self.interruptoresLines['B'].append(self.canvas.create_line(x, 10, x, y, fill='gray', width=2))
        self.interruptoresLines['B'].append(self.canvas.create_line(x, y, orX+width, y, fill='gray', width=2))
        self.interruptoresLines['B'].append(self.canvas.create_line(orX+width, y, andX, y-shiftY-shiftY/2, fill='gray', width=2))
        x += shiftX
        y -= shiftY

        # Or
        self.circuit_or = self.createCircuitOr(x=orX, upY=y-2*shiftY, downY=y, shift=10, width=width)

        # C
        self.interruptoresLines['C'].append(self.canvas.create_line(x, 10, x, y, fill='gray', width=2))
        self.interruptoresLines['C'].append(self.canvas.create_line(x, y, orX, y, fill='gray', width=2))
        x += shiftX
        y -= shiftY

        # D
        self.interruptoresLines['D'].append(self.canvas.create_line(x, 10, x, y, fill='gray', width=2))
        self.interruptoresLines['D'].append(self.canvas.create_line(x, y, orX, y, fill='gray', width=2))
        self.hlineOr = self.canvas.create_line(orX+width, y, andX, y, fill='gray', width=2)
        x += shiftX
        y -= shiftY

        # E
        self.interruptoresLines['E'].append(self.canvas.create_line(x, 10, x, y, fill='gray', width=2))
        self.interruptoresLines['E'].append(self.canvas.create_line(x, y, orX, y, fill='gray', width=2))
        x += shiftX
        y -= shiftY

        # F
        self.interruptoresLines['F'].append(self.canvas.create_line(x, 10, x, y, fill='gray', width=2))
        self.interruptoresLines['F'].append(self.canvas.create_line(x, y, orX+width, y, fill='gray', width=2))
        self.interruptoresLines['F'].append(self.canvas.create_line(orX+width, y, andX, y+shiftY+shiftY/2, fill='gray', width=2))

        # Bombilla
        andY = 90
        self.hline_bombilla = self.canvas.create_line(andX+width, andY, 450, andY, fill='gray', width=2)
        self.vline_bombilla = self.canvas.create_line(450, andY, 450, 10, fill='gray', width=2)

    def __orExpr(self, interruptores):
        if interruptores['C'] | interruptores['D'] | interruptores['E']:
            self.canvas.itemconfig(self.hlineOr, fill=WIRES_CIRCUIT_COLOR)
        else:
            self.canvas.itemconfig(self.hlineOr, fill='gray')

    def encendido(self, interruptores):
        self.__orExpr(interruptores)
        return interruptores['A'] & interruptores['B'] & (interruptores['C'] | interruptores['D'] | interruptores['E']) & interruptores['F']

def main():
    app = Controlador(
        title='II. Lógica y Conjuntos — Circuito de 6 Interruptores',
        firstFrame=FrameCircuito6,
        height=500, width=700
    )
    app.mainloop()

if __name__ == '__main__':
    main()
