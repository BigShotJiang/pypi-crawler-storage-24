import tkinter as tk
from functools import partial
from importlib.resources import files

TEXT_FONT = ('DejaVu Sans', 13)
IMG_BOMBILLA_OFF = files('alg_era_dig') / 'images/bombilla_off.png'
IMG_BOMBILLA_ON = files('alg_era_dig') / 'images/bombilla_on.png'
PAD_INTERRUPTOR_BOMBILLA = 50
INTERRUPTOR_HEIGHT = 40
INTERRUPTOR_WIDTH = 25
FULL_WIDTH = 500
FULL_HEIGHT = 400
NOT_CIRCLE_RADIUS = 6
OPERATOR_CIRCUIT_COLOR = 'gray'
WIRES_CIRCUIT_COLOR = '#ffea5c'
INTERRUPTOR_PKG_WIDTH = 250


class FrameCircuito(tk.Frame):
    def setPanels(self, panel):
        # 1.1. Panel superior
        self.panel_up = tk.Frame(panel, width=FULL_WIDTH, height=FULL_HEIGHT/2)
        self.panel_up.pack_propagate(False)
        self.panel_up.pack(side='top', expand=True)
        
        # 1.1.1. Panel izquierdo
        self.panel_up_left = tk.Frame(self.panel_up, bg='lightgrey', width=INTERRUPTOR_PKG_WIDTH, height=120, highlightbackground='gray', highlightthickness=2)
        self.panel_up_left.pack_propagate(False)
        self.panel_up_left.pack(side='left')

        # 1.1.2. Panel derecho
        self.panel_up_right = tk.Frame(self.panel_up, width=105, height=200)
        self.panel_up_right.pack(side='right')
        self.panel_up_right.pack_propagate(False)

        # 1.2. Panel inferior
        self.canvas = tk.Canvas(panel, width=FULL_WIDTH, height=FULL_HEIGHT//2)
        self.canvas.pack()

    def setBombilla(self):
        self.img_bombilla_off = tk.PhotoImage(file=IMG_BOMBILLA_OFF)
        self.img_bombilla_on = tk.PhotoImage(file=IMG_BOMBILLA_ON)
        self.label_bombilla = tk.Label(self.panel_up_right, image=self.img_bombilla_off)
        self.label_bombilla.config(image=self.img_bombilla_off)
        self.label_bombilla.pack(side='bottom')

    def setInterruptores(self, n, padx_interruptor):
        self.interruptores = {chr(i): False for i in range(65, 65 + n)}

        # Imágenes de un interruptor encendido y uno apagado
        self.img_interruptor_off = tk.PhotoImage(width=INTERRUPTOR_WIDTH, height=INTERRUPTOR_HEIGHT)
        self.img_interruptor_off.put('darkgray', to=(0, 0, INTERRUPTOR_WIDTH, INTERRUPTOR_HEIGHT))
        self.img_interruptor_on = tk.PhotoImage(width=INTERRUPTOR_WIDTH, height=INTERRUPTOR_HEIGHT)
        self.img_interruptor_on.put('gray', to=(0, 0, INTERRUPTOR_WIDTH, INTERRUPTOR_HEIGHT))

        self.interruptoresLabels = {}
        for interruptor in self.interruptores:
            self.interruptoresLabels[interruptor] = tk.Label(self.panel_up_left, text=interruptor, image=self.img_interruptor_off, compound='center', fg='white', font=TEXT_FONT, cursor='hand2')
            self.interruptoresLabels[interruptor].config(image=self.img_interruptor_off)
            self.interruptoresLabels[interruptor].pack(side='left', padx=padx_interruptor)
            self.interruptoresLabels[interruptor].bind('<Button-1>', partial(self.interruptor_presionado, interruptor))
        
    def interruptor_presionado(self, interruptor, _):
        self.interruptores[interruptor] = not self.interruptores[interruptor]
        if self.interruptores[interruptor]:
            self.interruptoresLabels[interruptor].config(image=self.img_interruptor_on)
            for line in self.interruptoresLines[interruptor]:
                self.canvas.itemconfig(line, fill=WIRES_CIRCUIT_COLOR)
        else:
            self.interruptoresLabels[interruptor].config(image=self.img_interruptor_off)
            for line in self.interruptoresLines[interruptor]:
                self.canvas.itemconfig(line, fill='gray')
        
        self.check_bombilla()

    def check_bombilla(self):
        if self.encendido(self.interruptores):
            self.label_bombilla.config(image=self.img_bombilla_on)
            self.canvas.itemconfig(self.hline_bombilla, fill=WIRES_CIRCUIT_COLOR)
            self.canvas.itemconfig(self.vline_bombilla, fill=WIRES_CIRCUIT_COLOR)
        else:
            self.label_bombilla.config(image=self.img_bombilla_off)
            self.canvas.itemconfig(self.hline_bombilla, fill='gray')
            self.canvas.itemconfig(self.vline_bombilla, fill='gray')

    def createCircuitAnd(self, x, upY, downY, shift=20, width=60):
        return [self.canvas.create_line(x, upY-shift, x, downY+shift, fill='gray', width=2),
                self.canvas.create_line(x, downY+shift, x+width/2, downY+shift, fill='gray', width=2),
                self.canvas.create_line(x, upY-shift, x+width/2, upY-shift, fill='gray', width=2),
                self.canvas.create_arc(x, upY-shift, x+width, downY+shift, start=270, extent=180, style='arc', outline=OPERATOR_CIRCUIT_COLOR, width=2)]

    def createCircuitOr(self, x, upY, downY, shift=20, width=60):
        left = x-(shift//2)
        midX = x+(width//2)
        midY = (upY + downY) // 2
        return [self.canvas.create_line(left, downY+shift, x, downY, x, upY, left, upY-shift, fill=OPERATOR_CIRCUIT_COLOR, width=2, smooth=True),
                self.canvas.create_line(left, downY+shift, midX, downY+shift, x+width, midY, fill=OPERATOR_CIRCUIT_COLOR, width=2, smooth=True),
                self.canvas.create_line(left, upY-shift, midX, upY-shift, x+width, midY, fill=OPERATOR_CIRCUIT_COLOR, width=2, smooth=True)]
