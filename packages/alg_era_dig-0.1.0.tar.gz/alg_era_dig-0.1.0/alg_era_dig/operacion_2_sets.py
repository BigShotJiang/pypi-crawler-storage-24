from .interfaz import Controlador
from .operacion_3_sets import FrameDiagrama

def main():
    conjuntoA = {1, 2, 3, 4}
    conjuntoB = {3, 4, 5, 6}
    app = Controlador(
        title='II. Lógica y Conjuntos — Operación de 2 conjuntos fijos y Diagrama de Venn',
        firstFrame=FrameDiagrama,
        firstFrameArgs=(conjuntoA, conjuntoB, set(), True),
        height=600, width=775
    )
    app.mainloop()

if __name__ == '__main__':
    main()
