*Introducción al Álgebra en la Era Digital* trata las ideas fundamentales del álgebra con un enfoque tecnológico para apoyar el aprendizaje y hacerlo más sustantivo.

## Unidades y Comandos
El libro está conformado por seis unidades, varias de las cuales poseen programas asociados de acompañamiento a la lectura con tal de permitir experimentar con los conceptos matemáticos tratados. Cada uno de estos recursos posee un comando que activa su ejecución.

1. Operaciones básicas
2. Lógica y Conjuntos
    - `circuito-2`
    - `circuito-6`
    - `conversor-logico`
    - `venn-2`
    - `venn-3`
3. Funciones
    - `trig-suma`
    - `triangulo-rect`
    - `trig-ecuaciones`
    - `trig-recta-hor`
    - `trig-variables`
    - `trig-voltaje`
    - `transformador`
    - `proyectil`
    - `composicion`
    - `recta-hor`
    - `inversa`
    - `trig-tiempo`
    - `teorema-seno`
4. Sucesiones
    - `hilbert`
5. Números complejos
    - `ac-dc`
    - `raices-unitarias`
6. Polinomios