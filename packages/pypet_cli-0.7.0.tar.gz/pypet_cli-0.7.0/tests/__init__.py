"""Test suite for pypet"""
