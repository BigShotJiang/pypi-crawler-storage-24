# sufa -- Complete Usage Guide

AI-powered web vulnerability analysis platform. sufa combines LLM reasoning with traditional security scanning into a CLI tool, API server, and Burp Suite extension.

---

## Table of Contents

- [Installation](#installation)
- [Quick Start](#quick-start)
- [AI Provider Setup](#ai-provider-setup)
- [Configuration Reference](#configuration-reference)
- [Scanning](#scanning)
- [Findings Management](#findings-management)
- [Traffic Import](#traffic-import)
- [Intercept Proxy](#intercept-proxy)
- [Request Replay](#request-replay)
- [Reports](#reports)
- [Projects](#projects)
- [API Server (Enterprise)](#api-server-enterprise)
- [Burp Suite Extension](#burp-suite-extension)
- [Docker](#docker)
- [Scan Profiles](#scan-profiles)
- [Plugin System](#plugin-system)
- [Custom Rules](#custom-rules)
- [Payload Files](#payload-files)
- [Architecture Overview](#architecture-overview)

---

## Installation

### From PyPI

```bash
pip install sufa
```

Requires **Python 3.11+**.

### Optional Extras

```bash
pip install sufa[proxy]       # Intercept proxy (mitmproxy)
pip install sufa[server]      # API server (FastAPI, PostgreSQL)
pip install sufa[crawler]     # Web crawler (BeautifulSoup)
pip install sufa[pdf]         # PDF report generation
pip install sufa[all]         # Everything
```

### From Source

```bash
git clone https://github.com/sufiyansaidsha/sufaAI.git
cd sufaAI
pip install -e ".[all,dev]"
```

### Docker

```bash
docker pull sufaai/sufaai:0.1.0
docker run -p 9000:9000 sufaai/sufaai:0.1.0
```

---

## Quick Start

```bash
# 1. Configure an AI provider
sufa config set ai.provider gemini
sufa config set ai.api_key YOUR_GEMINI_API_KEY

# 2. Test connectivity
sufa provider test

# 3. Scan a target
sufa scan https://example.com

# 4. View findings
sufa findings list

# 5. Generate a report
sufa report generate --format html --output report.html
```

---

## AI Provider Setup

sufa supports four AI providers with automatic failover. If the primary provider fails, it tries the next one in the priority chain.

### Ollama (Local, Free)

```bash
sufa config set ai.provider ollama
sufa config set ai.api_url http://localhost:11434
sufa config set ai.model deepseek-r1:latest
```

### OpenAI

```bash
sufa config set ai.provider openai
sufa config set ai.api_key sk-your-openai-key
sufa config set ai.model gpt-4o
```

### Google Gemini

```bash
sufa config set ai.provider gemini
sufa config set ai.api_key YOUR_GEMINI_API_KEY
sufa config set ai.model gemini-2.0-flash
```

### Anthropic Claude

```bash
sufa config set ai.provider claude
sufa config set ai.api_key YOUR_CLAUDE_API_KEY
sufa config set ai.model claude-sonnet-4-20250514
```

### Remote Ollama (with Auth)

If you run Ollama on a remote GPU server with authentication:

```bash
sufa config set ai.provider ollama
sufa config set ai.api_url http://your-gpu-server:11434
sufa config set ai.api_key YOUR_BEARER_TOKEN
sufa config set ai.model your-model-name
```

### Provider Priority (Failover)

Configure multiple providers. If the first fails, sufa tries the next:

```bash
sufa config set ai.priority "gemini,openai,ollama"
```

### Per-Provider Configuration

Override settings for specific providers without changing the global config:

```bash
sufa config set ai.openai.api_key sk-your-openai-key
sufa config set ai.openai.model gpt-4o
sufa config set ai.gemini.api_key YOUR_GEMINI_KEY
```

### Testing Providers

```bash
sufa provider test    # Test all configured providers
sufa provider list    # List available providers
```

---

## Configuration Reference

Config is stored at `~/.sufa/config.json`.

### AI Settings

| Key | Default | Description |
|-----|---------|-------------|
| `ai.provider` | `ollama` | Primary AI provider (ollama, openai, claude, gemini) |
| `ai.api_url` | `http://localhost:11434` | API base URL |
| `ai.api_key` | (empty) | API key / Bearer token |
| `ai.model` | `deepseek-r1:latest` | Model name |
| `ai.max_tokens` | `4096` | Maximum output tokens |
| `ai.timeout` | `120` | Request timeout in seconds |
| `ai.priority` | `ollama` | Failover chain (comma-separated) |
| `ai.max_concurrent` | `1` | Max concurrent AI requests |
| `ai.request_delay` | `2.0` | Delay between AI calls in seconds |

### Scan Settings

| Key | Default | Description |
|-----|---------|-------------|
| `scan.confidence_threshold` | `50` | Minimum confidence score (0-100) to report a finding |
| `scan.max_request_body` | `2000` | Max request body chars sent to AI |
| `scan.max_response_body` | `3000` | Max response body chars sent to AI |
| `scan.skip_extensions` | `.js,.css,.png,...` | File extensions to skip |

### Redaction Settings

| Key | Default | Description |
|-----|---------|-------------|
| `redact.enabled` | `true` | Strip sensitive data before sending to AI |
| `redact.patterns` | `authorization,cookie,...` | Header names to redact |

### Other Settings

| Key | Default | Description |
|-----|---------|-------------|
| `logging.verbose` | `false` | Enable verbose logging |
| `logging.level` | `INFO` | Log level (DEBUG, INFO, WARNING, ERROR) |
| `project.name` | `default` | Default project name |
| `project.db_path` | (empty) | Custom database path (default: `~/.sufa/sufa.db`) |

### Managing Configuration

```bash
sufa config set <key> <value>   # Set a value
sufa config get <key>           # Get a value
sufa config list                # Show all settings
sufa config reset --yes         # Reset to defaults
```

---

## Scanning

### Passive Scan

Fetches the target URL and analyzes the HTTP traffic with AI:

```bash
sufa scan https://example.com
```

### Scan with Profile

```bash
sufa scan https://example.com --profile quick      # Fast, high-confidence only
sufa scan https://example.com --profile standard    # Default, balanced
sufa scan https://example.com --profile deep        # Active scanning + crawler + chain analysis
```

### Associate with Project

```bash
sufa scan https://example.com --project my-project-id
```

### What Happens During a Scan

1. **Fetch** -- HTTP request is sent to the target
2. **Store** -- Request/response stored in the traffic database
3. **Normalize** -- Bodies are decompressed, decoded, and size-limited
4. **Redact** -- Sensitive headers (auth, cookies) are stripped
5. **Deduplicate** -- Endpoint normalization prevents re-scanning the same endpoint
6. **AI Analysis** -- Traffic is sent to the AI provider with a security analysis prompt
7. **Parse Findings** -- AI response is parsed for vulnerability findings
8. **Filter** -- Findings below the confidence threshold are dropped
9. **Store Findings** -- Results saved to database

---

## Findings Management

### List Findings

```bash
sufa findings list                                   # All findings
sufa findings list --severity high                   # Filter by severity
sufa findings list --status open                     # Filter by status
sufa findings list --scan SCAN_ID                    # Filter by scan
sufa findings list --limit 20                        # Limit results
```

### View Finding Details

```bash
sufa findings show FINDING_ID
```

Displays: title, severity, confidence, CWE, OWASP category, URL, parameter, evidence, description, and remediation.

### Triage a Finding

Update the status of a finding:

```bash
sufa findings triage FINDING_ID --status confirmed
sufa findings triage FINDING_ID --status false_positive
sufa findings triage FINDING_ID --status accepted_risk
sufa findings triage FINDING_ID --status fixed
sufa findings triage FINDING_ID --status open
```

---

## Traffic Import

Import captured traffic from HAR or Burp Suite XML files:

```bash
sufa import capture.har                     # Auto-detect format
sufa import burp_export.xml                 # Auto-detect Burp XML
sufa import traffic.har --format har        # Explicit format
sufa import traffic.xml --format burp       # Explicit Burp format
sufa import traffic.har --project PROJ_ID   # Associate with project
sufa import traffic.har --scan SCAN_ID      # Associate with scan
```

Imported traffic is stored in the database and can be scanned, replayed, or reported on.

---

## Intercept Proxy

Capture live HTTP(S) traffic through a local proxy (requires `sufa[proxy]`):

```bash
sufa proxy start                          # Start on default port 8080
sufa proxy start --port 9090              # Custom port
sufa proxy start --scan SCAN_ID           # Associate traffic with a scan
sufa proxy start --project PROJ_ID        # Associate traffic with a project
```

### How to Use

1. Start the proxy: `sufa proxy start --port 8080`
2. Configure your browser or tool to use `http://localhost:8080` as proxy
3. Browse the target application
4. All traffic is captured and stored in sufa's database
5. Stop the proxy with `Ctrl+C`
6. Analyze captured traffic: `sufa scan` or view with `sufa findings list`

---

## Request Replay

Re-send a previously captured HTTP request:

```bash
sufa replay REQUEST_ID
```

### Options

```bash
sufa replay REQUEST_ID --url https://other-host.com    # Override target URL
sufa replay REQUEST_ID -H "Authorization: Bearer xxx"   # Override headers
sufa replay REQUEST_ID -H "X-Custom: value"             # Multiple headers
sufa replay REQUEST_ID --timeout 60                      # Custom timeout
sufa replay REQUEST_ID --no-verify                       # Skip SSL verification
```

Request IDs can be found in traffic listings. Prefix matching is supported (e.g., first 8 characters).

---

## Reports

Generate reports from scan results:

```bash
sufa report generate                                  # HTML report (latest scan)
sufa report generate --format html --output report.html
sufa report generate --format json --output report.json
sufa report generate --format sarif --output report.sarif
sufa report generate --format pdf --output report.pdf   # Requires sufa[pdf]
sufa report generate --scan SCAN_ID                     # Specific scan
```

### Report Formats

| Format | Description | Use Case |
|--------|-------------|----------|
| **HTML** | Rich styled report with severity colors and finding cards | Sharing with stakeholders |
| **JSON** | Machine-readable with scan metadata, summary, and findings | Integration with other tools |
| **SARIF** | Static Analysis Results Interchange Format (v2.1.0) | CI/CD integration (GitHub, GitLab) |
| **PDF** | PDF version of the HTML report | Formal deliverables |

---

## Projects

Organize scans and findings into projects:

```bash
sufa project create "My Web App"                      # Create a project
sufa project create "API Audit" --desc "Q1 audit"     # With description
sufa project list                                      # List all projects
sufa project delete PROJECT_ID --yes                   # Delete a project
```

Associate scans with projects:

```bash
sufa scan https://example.com --project PROJECT_ID
```

---

## API Server (Enterprise)

Start the REST API server for team collaboration (requires `sufa[server]`):

```bash
sufa server start                            # Default: 0.0.0.0:9000
sufa server start --port 8000               # Custom port
sufa server start --host 127.0.0.1          # Localhost only
sufa server start --reload                  # Auto-reload for development
```

API documentation available at `http://localhost:9000/docs` (Swagger UI).

### API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/health` | Health check |
| **Projects** | | |
| `POST` | `/api/v1/projects` | Create project |
| `GET` | `/api/v1/projects` | List projects |
| `GET` | `/api/v1/projects/{id}` | Get project |
| `DELETE` | `/api/v1/projects/{id}` | Delete project |
| **Scans** | | |
| `POST` | `/api/v1/scans` | Create scan |
| `GET` | `/api/v1/scans` | List scans |
| `GET` | `/api/v1/scans/{id}` | Get scan |
| **Traffic** | | |
| `POST` | `/api/v1/traffic` | Ingest traffic |
| `GET` | `/api/v1/traffic` | List traffic |
| `GET` | `/api/v1/traffic/{id}` | Get traffic entry |
| **Findings** | | |
| `GET` | `/api/v1/findings` | List findings |
| `GET` | `/api/v1/findings/{id}` | Get finding |
| `PATCH` | `/api/v1/findings/{id}` | Update finding status |

---

## Burp Suite Extension

Use sufa as a Burp Suite extension to analyze traffic in real-time.

### Setup

1. Start the sufa API server:

```bash
sufa server start --port 9000
```

2. In Burp Suite:
   - Go to **Extensions** tab
   - Click **Add**
   - Extension Type: **Python** (requires Jython)
   - Select `src/sufa/burp/extension.py`

3. Traffic is automatically forwarded to sufa for analysis.

4. Right-click any request and select **"Analyze with sufa"** to manually send specific requests.

---

## Docker

### Quick Start

```bash
docker pull sufaai/sufaai:0.1.0
docker run -p 9000:9000 sufaai/sufaai:0.1.0
```

### With Persistent Storage

```bash
docker run -p 9000:9000 -v sufa-data:/data sufaai/sufaai:0.1.0
```

### Docker Compose (SQLite)

```bash
docker compose up
```

### Docker Compose (PostgreSQL, Enterprise)

```bash
docker compose --profile enterprise up
```

This starts:
- **sufa-postgres** -- PostgreSQL 16 database
- **sufa-enterprise** -- sufa API server connected to PostgreSQL

### Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `SUFA_DB_URL` | `sqlite:///data/sufa.db` | Database connection URL |

---

## Scan Profiles

Three built-in profiles control scan depth and behavior:

### Quick

Fast scan with high confidence threshold. No active scanning or crawling.

```bash
sufa scan https://example.com --profile quick
```

| Setting | Value |
|---------|-------|
| Confidence threshold | 70 |
| Max request body | 1000 chars |
| Max response body | 1500 chars |
| Active scanning | Off |
| Crawler | Off |
| Chain analysis | Off |
| AI delay | 1.0s |
| Max findings per endpoint | 3 |

### Standard (Default)

Balanced analysis with moderate confidence threshold.

```bash
sufa scan https://example.com --profile standard
```

| Setting | Value |
|---------|-------|
| Confidence threshold | 50 |
| Max request body | 2000 chars |
| Max response body | 3000 chars |
| Active scanning | Off |
| Crawler | Off |
| Chain analysis | Off |
| AI delay | 2.0s |
| Max findings per endpoint | 10 |

### Deep

Full analysis with active scanning, crawling, and attack chain discovery.

```bash
sufa scan https://example.com --profile deep
```

| Setting | Value |
|---------|-------|
| Confidence threshold | 40 |
| Max request body | 4000 chars |
| Max response body | 6000 chars |
| Active scanning | On |
| Crawler | On (depth 3) |
| Chain analysis | On |
| AI delay | 3.0s |
| Max findings per endpoint | 20 |

---

## Plugin System

sufa supports plugins that hook into the event system.

### Plugin Structure

Place plugins in a directory with this structure:

```
plugins/
  my_plugin/
    plugin.py      # Must contain a class inheriting from SufaPlugin
```

### Plugin Hooks

| Hook | Trigger |
|------|---------|
| `on_load(context)` | Plugin is loaded |
| `on_unload()` | Plugin is unloaded |
| `on_request(request)` | HTTP request captured |
| `on_response(request, response)` | HTTP response received |
| `on_finding(finding)` | Vulnerability finding created |
| `on_scan_start(scan)` | Scan begins |
| `on_scan_finish(scan)` | Scan completes |
| `on_chain_discovered(chain)` | Attack chain found |

### Built-in Example Plugins

| Plugin | Description |
|--------|-------------|
| **jwt_analyzer** | Checks for JWT vulnerabilities (alg=none, weak algorithms, missing expiry) |
| **graphql_scanner** | Detects GraphQL introspection enabled and verbose error messages |
| **oauth_analyzer** | Checks OAuth flows for missing state parameter, PKCE, and open redirects |

---

## Custom Rules

sufa uses a YAML-based rule engine. Custom rules are placed in the rules directory.

### Rule Format

```yaml
- id: my_custom_rule
  name: "Custom Check Name"
  description: "What this rule checks for"
  category: injection
  severity: high
  cwe_id: "CWE-89"
  owasp_category: "A03:2021 Injection"
  conditions:
    - field: request.url
      operator: contains
      value: "/api/"
  prompt_template: |
    Analyze this traffic for {category} vulnerabilities.
    Focus on: {description}
  tags:
    - custom
    - injection
```

### Condition Operators

| Operator | Description |
|----------|-------------|
| `contains` | Field contains the value |
| `not_contains` | Field does not contain the value |
| `equals` | Field exactly matches the value |

### Built-in Rules (OWASP Top 10)

| Rule ID | Name | Severity |
|---------|------|----------|
| `injection_sql` | SQL Injection Detection | High |
| `injection_command` | Command Injection Detection | Critical |
| `xss_reflected` | Reflected XSS Detection | Medium |
| `broken_auth` | Broken Authentication | High |
| `idor` | Insecure Direct Object Reference | High |
| `security_misconfig` | Security Misconfiguration | Medium |
| `sensitive_data` | Sensitive Data Exposure | High |
| `ssrf` | Server-Side Request Forgery | High |
| `csrf` | Cross-Site Request Forgery | Medium |

---

## Payload Files

Active scanning uses payload files for fuzzing. Located in `src/sufa/payloads/`:

| File | Vulnerability Type | Examples |
|------|-------------------|----------|
| `sqli.txt` | SQL Injection | `' OR 1=1--`, `UNION SELECT`, `SLEEP(5)` |
| `xss.txt` | Cross-Site Scripting | `<script>alert(1)</script>`, `<img onerror=...>` |
| `ssrf.txt` | Server-Side Request Forgery | `http://localhost`, `http://169.254.169.254` |
| `idor.txt` | Insecure Direct Object Reference | `0`, `1`, `-1`, `admin`, UUID values |
| `lfi.txt` | Local File Inclusion | `../../etc/passwd`, `php://filter/...` |

Custom payloads: one payload per line, lines starting with `#` are comments.

---

## Architecture Overview

```
sufa
├── CLI (Typer + Rich)          User interface
├── Core
│   ├── AI Router               Provider failover (Ollama/OpenAI/Claude/Gemini)
│   ├── Traffic Store            Central HTTP traffic database
│   ├── HTTP Normalizer          Decompress, decode, size-limit bodies
│   ├── Data Redactor            Strip sensitive data before AI analysis
│   ├── Deduplicator             Prevent redundant endpoint analysis
│   ├── Passive Scanner          AI-powered vulnerability detection
│   ├── Active Scanner           Payload injection and AI verification
│   ├── Rule Engine              YAML-based analysis rules
│   ├── Session Manager          Cookie, JWT, CSRF state tracking
│   ├── Attack Graph             Multi-step attack chain discovery
│   ├── Event Bus                Publish/subscribe for loose coupling
│   └── Plugin System            Extensible hook-based plugins
├── Crawler                      HTML spider, JS endpoint extraction, API discovery
├── Proxy                        mitmproxy-based HTTP(S) intercept
├── Reports                      HTML, JSON, SARIF, PDF generation
├── Burp Extension               Jython bridge to Burp Suite
└── Server (FastAPI)             REST API with RBAC for team collaboration
```

### Data Flow

```
Traffic Source                    Analysis                        Output
─────────────                    ────────                        ──────
Browser → Proxy ─┐
HAR/Burp Import ─┤               Normalize → Redact → Deduplicate
CLI scan ────────┤→ Traffic Store ──────────────────────────────→ AI Router
API ingest ──────┘                                                  │
                                                                    ▼
                                                              Parse Findings
                                                                    │
                                                                    ▼
                                                         Store → Report/Triage
```

---

## Troubleshooting

### "No providers available"

All AI providers failed connectivity test. Check:

```bash
sufa config list          # Verify ai.provider, ai.api_url, ai.api_key
sufa provider test        # See which providers fail
```

### Rate limiting (429 errors)

Gemini free tier has 15 requests/minute. sufa retries automatically with backoff (5s, 15s, 30s). Increase delay between requests:

```bash
sufa config set ai.request_delay 5.0
```

### "pip install sufa" fails

Requires Python 3.11+. Check your version:

```bash
python3 --version
```

### Proxy not capturing HTTPS

Install the mitmproxy CA certificate in your browser. The certificate is generated on first run at `~/.mitmproxy/mitmproxy-ca-cert.pem`.

---

## License

MIT License. See [LICENSE](LICENSE) for details.

**Repository:** https://github.com/sufiyansaidsha/sufaAI
**PyPI:** https://pypi.org/project/sufa/
**Docker Hub:** https://hub.docker.com/r/sufaai/sufaai
