"""Ollama AI provider adapter."""

from __future__ import annotations

import time

import httpx

from sufa.core.ai.base import AIProvider, AIResponse
from sufa.core.utils.logging import get_logger

logger = get_logger(__name__)


class OllamaProvider(AIProvider):
    name = "ollama"

    def __init__(
        self,
        api_url: str = "http://localhost:11434",
        api_key: str = "",
        model: str = "deepseek-r1:latest",
        max_tokens: int = 4096,
        timeout: int = 120,
        num_ctx: int = 2048,
    ) -> None:
        super().__init__(api_url, api_key, model, max_tokens, timeout)
        self.num_ctx = num_ctx

    def _headers(self) -> dict[str, str]:
        h: dict[str, str] = {"Content-Type": "application/json"}
        if self.api_key:
            h["Authorization"] = f"Bearer {self.api_key}"
        return h

    async def analyze(self, prompt: str) -> AIResponse:
        url = f"{self.api_url}/api/generate"
        payload = {
            "model": self.model,
            "prompt": prompt,
            "stream": False,
            "options": {
                "num_ctx": self.num_ctx,
                "num_predict": self.max_tokens,
            },
        }

        start = time.monotonic()
        retries = 2
        last_error = ""

        for attempt in range(retries + 1):
            try:
                async with httpx.AsyncClient(timeout=self.timeout) as client:
                    resp = await client.post(url, headers=self._headers(), json=payload)
                    resp.raise_for_status()
                    data = resp.json()

                elapsed = (time.monotonic() - start) * 1000
                return AIResponse(
                    text=data.get("response", ""),
                    prompt_tokens=data.get("prompt_eval_count", 0),
                    completion_tokens=data.get("eval_count", 0),
                    model=self.model,
                    provider=self.name,
                    latency_ms=elapsed,
                )
            except httpx.TimeoutException:
                last_error = f"Timeout on attempt {attempt + 1}"
                logger.warning("ollama_timeout", attempt=attempt + 1, model=self.model)
            except httpx.HTTPError as e:
                last_error = str(e)
                break

        elapsed = (time.monotonic() - start) * 1000
        return AIResponse(
            provider=self.name,
            model=self.model,
            success=False,
            error=last_error,
            latency_ms=elapsed,
        )

    async def test_connection(self) -> bool:
        try:
            async with httpx.AsyncClient(timeout=10) as client:
                resp = await client.get(f"{self.api_url}/api/tags", headers=self._headers())
                if resp.status_code == 200:
                    return True
                resp = await client.post(
                    f"{self.api_url}/api/generate",
                    headers=self._headers(),
                    json={"model": self.model, "prompt": "ping", "stream": False},
                    timeout=30,
                )
                return resp.status_code == 200
        except Exception:
            return False
