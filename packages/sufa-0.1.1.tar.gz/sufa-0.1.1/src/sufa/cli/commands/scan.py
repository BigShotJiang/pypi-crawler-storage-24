"""CLI commands for scanning targets."""

from __future__ import annotations

import asyncio

import typer

from sufa.cli.display import console, print_error, print_findings_table, print_info, print_success

app = typer.Typer(no_args_is_help=True)


def _run_scan(target: str, profile: str, project_id: str) -> None:
    """Execute the scan workflow."""
    from sufa.core.ai.cost import CostTracker
    from sufa.core.ai.router import AIRouter
    from sufa.core.db import Repository, init_db
    from sufa.core.dedup import Deduplicator
    from sufa.core.events import EventBus
    from sufa.core.http.parser import build_request, build_response
    from sufa.core.models import Scan, ScanType, TrafficEntry
    from sufa.core.scanner.passive import PassiveScanner
    from sufa.core.scanner.scope import ScopeManager
    from sufa.core.traffic import TrafficStore
    from sufa.core.utils.config import SufaConfig
    from sufa.core.utils.logging import setup_logging

    config = SufaConfig()
    setup_logging(verbose=bool(config.get("logging.verbose")))

    init_db(config.get_db_path())
    repo = Repository()
    bus = EventBus()
    router = AIRouter(config)
    scope = ScopeManager()
    scope.set_target(target)
    dedup = Deduplicator()
    cost = CostTracker()

    scanner = PassiveScanner(
        router=router,
        repo=repo,
        event_bus=bus,
        deduplicator=dedup,
        scope=scope,
        cost_tracker=cost,
        confidence_threshold=int(config.get("scan.confidence_threshold", 50)),
    )

    scan = Scan(
        target_url=target,
        scan_type=ScanType.PASSIVE,
        profile=profile,
        project_id=project_id,
    )

    import httpx

    fetch_timeout = float(config.get("scan.fetch_timeout", 45))
    print_info(f"Fetching {target}")

    async def fetch_and_scan() -> Scan:
        timeout = httpx.Timeout(fetch_timeout, connect=20)
        async with httpx.AsyncClient(timeout=timeout, follow_redirects=True, verify=False) as client:
            resp = await client.get(target)

        req_model = build_request("GET", target)
        resp_model = build_response(resp.status_code, dict(resp.headers), resp.text)
        entry = TrafficEntry(request=req_model, response=resp_model, scan_id=scan.id, source="cli")

        store = TrafficStore(repo, bus)
        store.store(entry)

        return await scanner.run_scan(scan, [entry])

    with console.status("[cyan]Analyzing with AI...[/cyan]"):
        result = asyncio.run(fetch_and_scan())

    print_success(
        f"Scan complete: {result.stats.analyzed} analyzed, "
        f"{result.stats.findings_count} findings, "
        f"{result.stats.skipped} skipped"
    )

    if result.stats.findings_count > 0:
        findings_list = repo.list_findings(scan_id=result.id)
        print_findings_table([f.model_dump() for f in findings_list])

    if cost.total_calls > 0:
        print_info(f"AI cost: ~${cost.estimated_cost_usd:.4f} ({cost.total_calls} calls)")

    repo.close()


@app.callback(invoke_without_command=True)
def scan_target(
    target: str = typer.Argument(..., help="Target URL to scan"),
    profile: str = typer.Option(
        "standard",
        "--profile",
        "-p",
        help="Scan profile: quick, standard, deep",
    ),
    project_id: str = typer.Option("", "--project", help="Project ID to associate scan with"),
) -> None:
    """Scan a target URL for vulnerabilities."""
    if not target.startswith("http"):
        target = f"https://{target}"

    print_info(f"Starting passive scan: {target}")
    print_info(f"Profile: {profile}")

    try:
        _run_scan(target, profile, project_id)
    except KeyboardInterrupt:
        print_error("Scan cancelled by user")
        raise typer.Exit(1)
    except Exception as e:
        msg = _friendly_error(e)
        print_error(f"Scan failed: {msg}")
        raise typer.Exit(1)


def _friendly_error(exc: Exception) -> str:
    """Turn common exceptions into human-readable messages."""
    import httpx

    name = type(exc).__name__
    text = str(exc).strip()
    if isinstance(exc, httpx.ConnectTimeout):
        return "Connection timed out — target may be unreachable or behind a firewall"
    if isinstance(exc, httpx.ReadTimeout):
        return "Read timed out — server accepted the connection but didn't respond in time"
    if isinstance(exc, httpx.ConnectError):
        return f"Connection refused or DNS resolution failed ({text or name})"
    if isinstance(exc, httpx.HTTPStatusError):
        return f"HTTP {exc.response.status_code} from target"
    return text or name
