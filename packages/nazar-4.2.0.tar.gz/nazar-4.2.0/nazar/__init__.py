"""Nazar - Autonomous Testing Tool

Projeyi tarar, mimariyi anlar, test plani olusturur, testleri calistirir.
"""
__version__ = "4.2.0"
