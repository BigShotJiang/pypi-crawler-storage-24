"""Orchestrator 测试。"""

from promptgrad.orchestrator import Orchestrator


class TestShouldStop:
    def test_target_reached(self):
        orch = Orchestrator.__new__(Orchestrator)
        orch.target_score = 0.9
        orch.max_iterations = 10
        orch.patience = 3
        stop, reason = orch._should_stop(scores=[0.5, 0.7, 0.92], iteration=3)
        assert stop is True
        assert "达标" in reason

    def test_max_iterations(self):
        orch = Orchestrator.__new__(Orchestrator)
        orch.target_score = 0.9
        orch.max_iterations = 3
        orch.patience = 5
        stop, reason = orch._should_stop(scores=[0.5, 0.6, 0.65], iteration=3)
        assert stop is True
        assert "上限" in reason

    def test_patience_exhausted(self):
        orch = Orchestrator.__new__(Orchestrator)
        orch.target_score = 0.9
        orch.max_iterations = 10
        orch.patience = 2
        stop, reason = orch._should_stop(scores=[0.5, 0.505, 0.508], iteration=3)
        assert stop is True
        assert "收敛" in reason or "停滞" in reason

    def test_continue(self):
        orch = Orchestrator.__new__(Orchestrator)
        orch.target_score = 0.9
        orch.max_iterations = 10
        orch.patience = 3
        stop, reason = orch._should_stop(scores=[0.5, 0.7], iteration=2)
        assert stop is False

    def test_first_iteration_never_stops_for_patience(self):
        orch = Orchestrator.__new__(Orchestrator)
        orch.target_score = 0.9
        orch.max_iterations = 10
        orch.patience = 1
        stop, _ = orch._should_stop(scores=[0.5], iteration=1)
        assert stop is False
