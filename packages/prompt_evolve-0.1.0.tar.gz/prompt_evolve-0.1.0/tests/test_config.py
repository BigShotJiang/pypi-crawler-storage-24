"""配置模块测试。"""

import pytest
import yaml

from promptgrad.config import load_config, save_config

SAMPLE_CONFIG = {
    "project": {"name": "test-project", "description": "test", "created_at": "2026-03-23"},
    "prompt": {
        "version": 1,
        "system": "You are a helper.",
        "template": "Input: {{query}}\nOutput:",
        "few_shot_examples": [],
    },
    "model": {"name": "claude-sonnet-4-20250514", "temperature": 0.3, "max_tokens": 200},
    "test_suite": {"path": "test_cases/", "format": "yaml"},
    "eval_rubric": {
        "dimensions": [
            {"name": "relevance", "weight": 0.5, "description": "Is it relevant", "eval_method": "llm_judge"},
            {
                "name": "format",
                "weight": 0.5,
                "description": "Correct format",
                "eval_method": "rule",
                "rules": [{"type": "max_length", "value": 100}],
            },
        ],
        "pass_threshold": 0.8,
    },
    "optimization": {
        "max_iterations": 5,
        "target_score": 0.9,
        "patience": 2,
        "strategy": "targeted",
        "concurrency": 10,
        "enable_regression_check": True,
    },
}


class TestLoadConfig:
    def test_load_valid_config(self, tmp_promptgrad_dir):
        config_path = tmp_promptgrad_dir / "config.yaml"
        config_path.write_text(yaml.dump(SAMPLE_CONFIG))
        config = load_config(str(config_path))
        assert config.project_name == "test-project"
        assert config.model_name == "claude-sonnet-4-20250514"
        assert config.max_iterations == 5
        assert len(config.dimensions) == 2

    def test_load_missing_file(self):
        with pytest.raises(FileNotFoundError):
            load_config("/nonexistent/config.yaml")


class TestSaveConfig:
    def test_save_and_reload(self, tmp_promptgrad_dir):
        config_path = tmp_promptgrad_dir / "config.yaml"
        save_config(SAMPLE_CONFIG, str(config_path))
        config = load_config(str(config_path))
        assert config.project_name == "test-project"


class TestPromptGradConfig:
    def test_properties(self, tmp_promptgrad_dir):
        config_path = tmp_promptgrad_dir / "config.yaml"
        config_path.write_text(yaml.dump(SAMPLE_CONFIG))
        config = load_config(str(config_path))
        assert config.pass_threshold == 0.8
        assert config.target_score == 0.9
        assert config.patience == 2
        assert config.concurrency == 10
        assert config.strategy == "targeted"
        assert config.enable_regression_check is True

    def test_test_cases_dir(self, tmp_promptgrad_dir):
        config_path = tmp_promptgrad_dir / "config.yaml"
        config_path.write_text(yaml.dump(SAMPLE_CONFIG))
        config = load_config(str(config_path))
        assert config.test_cases_dir.endswith("test_cases")

    def test_prompt_config(self, tmp_promptgrad_dir):
        config_path = tmp_promptgrad_dir / "config.yaml"
        config_path.write_text(yaml.dump(SAMPLE_CONFIG))
        config = load_config(str(config_path))
        pc = config.prompt_config
        assert pc["system"] == "You are a helper."
        assert "{{query}}" in pc["template"]
