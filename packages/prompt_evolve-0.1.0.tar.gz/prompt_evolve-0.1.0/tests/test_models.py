"""数据模型测试。"""

from promptgrad.models import CaseScore, EvalResult, ExecutionResult, OptimizeResult, TestCase


class TestTestCase:
    def test_create_with_golden(self):
        tc = TestCase(id="case_001", input={"query": "python list"}, golden="Python list tutorial", tags=["basic"])
        assert tc.id == "case_001"
        assert tc.golden == "Python list tutorial"

    def test_create_without_golden(self):
        tc = TestCase(id="case_002", input={"query": "test"}, golden=None, tags=[])
        assert tc.golden is None

    def test_has_golden(self):
        tc_with = TestCase(id="c1", input={}, golden="answer", tags=[])
        tc_without = TestCase(id="c2", input={}, golden=None, tags=[])
        assert tc_with.has_golden is True
        assert tc_without.has_golden is False


class TestExecutionResult:
    def test_create(self):
        er = ExecutionResult(
            case_id="case_001",
            input={"query": "test"},
            output="result text",
            latency_ms=150.5,
            token_usage={"input": 100, "output": 50},
        )
        assert er.case_id == "case_001"
        assert er.latency_ms == 150.5


class TestCaseScore:
    def test_create(self):
        cs = CaseScore(
            case_id="case_001",
            scores={"relevance": 0.9, "format": 0.6},
            weighted_score=0.77,
            critique="format issues",
            passed=False,
        )
        assert cs.passed is False
        assert cs.scores["relevance"] == 0.9


class TestEvalResult:
    def test_create(self):
        er = EvalResult(
            version=1,
            case_scores=[],
            avg_score=0.75,
            pass_rate=0.65,
            dimension_breakdown={"relevance": {"avg": 0.88, "min": 0.6}},
            worst_dimension="format",
            failure_patterns=[],
        )
        assert er.worst_dimension == "format"


class TestOptimizeResult:
    def test_create(self):
        opr = OptimizeResult(
            new_version=2,
            prompt_config={"system": "test", "template": "{{query}}", "few_shot_examples": []},
            changelog="fixed format",
            hypothesis="format low due to missing schema",
            changes=[],
        )
        assert opr.new_version == 2
