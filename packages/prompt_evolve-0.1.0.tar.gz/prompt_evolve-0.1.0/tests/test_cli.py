"""CLI 入口冒烟测试。"""

import subprocess
import sys


class TestCLIUsage:
    def test_no_args_shows_usage(self):
        result = subprocess.run(
            [sys.executable, "-m", "promptgrad"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 1
        assert "Usage" in result.stdout or "Commands" in result.stdout

    def test_unknown_command(self):
        result = subprocess.run(
            [sys.executable, "-m", "promptgrad", "nonexistent"],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 1
        assert "Unknown" in result.stdout

    def test_execute_missing_config(self):
        result = subprocess.run(
            [sys.executable, "-m", "promptgrad", "execute", "--config", "/nonexistent/config.yaml"],
            capture_output=True,
            text=True,
        )
        assert result.returncode != 0
