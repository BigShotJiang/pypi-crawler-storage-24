"""Optimizer: 回归保护检查。优化逻辑由宿主模型完成。"""

from __future__ import annotations

from promptgrad.evaluator import Evaluator
from promptgrad.executor import Executor
from promptgrad.models import TestCase


class Optimizer:
    """优化器: 提供回归保护检查能力。"""

    def __init__(self, concurrency: int = 10):
        self.concurrency = concurrency

    def regression_check(
        self,
        new_prompt: dict,
        passed_cases: list[TestCase],
        model_config: dict,
        rubric: dict,
        prev_pass_rate: float,
    ) -> bool:
        """
        用新 prompt 重跑已通过 case，检查是否退步。

        Returns:
            True = 无回归，可以采纳新 prompt
            False = 有回归，应拒绝
        """
        if not passed_cases:
            return True

        executor = Executor(
            prompt_config=new_prompt,
            model_config=model_config,
            concurrency=self.concurrency,
        )
        results = executor.run(passed_cases)

        evaluator = Evaluator(rubric=rubric, concurrency=self.concurrency)
        eval_result = evaluator.evaluate(results, passed_cases)

        return eval_result.pass_rate >= prev_pass_rate
