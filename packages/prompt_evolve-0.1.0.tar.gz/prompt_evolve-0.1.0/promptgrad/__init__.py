"""PromptGrad - Prompt 自动优化引擎。"""

__version__ = "0.1.0"
