"""PromptGrad 核心数据模型。"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class TestCase:
    """测试用例。"""

    id: str
    input: dict
    golden: str | None = None
    tags: list[str] = field(default_factory=list)

    @property
    def has_golden(self) -> bool:
        """是否有参考答案。"""
        return self.golden is not None


@dataclass
class ExecutionResult:
    """单个 case 的执行结果。"""

    case_id: str
    input: dict
    output: str
    latency_ms: float
    token_usage: dict


@dataclass
class CaseScore:
    """单个 case 的评分。"""

    case_id: str
    scores: dict[str, float]
    weighted_score: float
    critique: str
    passed: bool


@dataclass
class EvalResult:
    """评估聚合结果。"""

    version: int
    case_scores: list[CaseScore]
    avg_score: float
    pass_rate: float
    dimension_breakdown: dict
    worst_dimension: str
    failure_patterns: list[dict]


@dataclass
class OptimizeResult:
    """优化结果。"""

    new_version: int
    prompt_config: dict
    changelog: str
    hypothesis: str
    changes: list[dict]
