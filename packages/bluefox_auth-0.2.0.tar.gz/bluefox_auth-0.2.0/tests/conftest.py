from bluefox_core.database import BluefoxBase
from bluefox_test import bluefox_test_setup

globals().update(
    bluefox_test_setup(
        base=BluefoxBase,
        app_factory=None,
        session_dependency=None,
    )
)
