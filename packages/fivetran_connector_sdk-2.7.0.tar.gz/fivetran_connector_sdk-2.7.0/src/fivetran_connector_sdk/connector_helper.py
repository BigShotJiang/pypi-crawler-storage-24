import io
import os
import re
import ast
import json
import sys
import time
import socket
import platform
import subprocess
import requests as rq
import pathspec

from http import HTTPStatus
from typing import Optional, Tuple
from zipfile import ZipFile, ZIP_DEFLATED

from fivetran_connector_sdk.protos import common_pb2

from fivetran_connector_sdk import constants
from fivetran_connector_sdk.logger import Logging
from fivetran_connector_sdk.helpers import (
    print_library_log, get_input_from_cli,
    validate_and_load_state,
    validate_and_load_configuration,
)
from fivetran_connector_sdk.constants import (
    OS_MAP,
    ARCH_MAP,
    WIN_OS,
    X64,
    TESTER_FILENAME,
    UPLOAD_FILENAME,
    LAST_VERSION_CHECK_FILE,
    ROOT_LOCATION,
    CONFIG_FILE,
    OUTPUT_FILES_DIR,
    REQUIREMENTS_TXT,
    CONFIGURATION_JSON,
    PYPI_PACKAGE_DETAILS_URL,
    ONE_DAY_IN_SEC,
    MAX_RETRIES,
    VIRTUAL_ENV_CONFIG,
    ROOT_FILENAME,
    EXCLUDED_DIRS,
    EXCLUDED_PIPREQS_DIRS,
    INSTALLATION_SCRIPT,
    INSTALLATION_SCRIPT_MISSING_MESSAGE,
    DRIVERS,
    UTF_8,
    CONNECTION_SCHEMA_NAME_PATTERN,
    TABLES,
    EVALUATION_MARKDOWN,
    REDACTED_VALUE,
)

def get_destination_group(args):
    ft_group = args.destination if args.destination else None
    env_destination_name = os.getenv('FIVETRAN_DESTINATION_NAME', None)
    if not ft_group:
        ft_group = get_input_from_cli("Provide the destination name (as displayed in your dashboard destination list)", env_destination_name)
    return ft_group

def get_connection_name(args, retrying=0):
    ft_connection = args.connection if args.connection else None
    env_connection_name = os.getenv('FIVETRAN_CONNECTION_NAME', None)
    if not ft_connection:
        ft_connection = get_input_from_cli("Provide the connection name", env_connection_name)
    if not is_connection_name_valid(ft_connection):
        print_library_log(
            f"invalid connection name: '{ft_connection}'", Logging.Level.SEVERE)
        print_library_log("connection names must use only [a-z0-9_] and begin with '_' or a lowercase letter", Logging.Level.SEVERE)
        args.connection = None
        if retrying >= MAX_RETRIES or args.force:
            sys.exit(1)
        else:
            return get_connection_name(args, retrying + 1)
    return ft_connection

def get_api_key(args):
    ft_deploy_key = args.api_key if args.api_key else None
    env_api_key = os.getenv('FIVETRAN_API_KEY', None)
    if not ft_deploy_key:
        ft_deploy_key = get_input_from_cli("Provide your API Key (Base 64 Encoded)", env_api_key, True)
    return ft_deploy_key

def get_python_version(args):
    python_version = args.python_version if args.python_version else None
    env_python_version = os.getenv('FIVETRAN_PYTHON_VERSION', None)
    if env_python_version and not python_version and not args.force:
        python_version = get_input_from_cli("Provide your python version", env_python_version)
    return python_version

def get_hd_agent_id(args):
    hd_agent_id = args.hybrid_deployment_agent_id if args.hybrid_deployment_agent_id else None
    env_hd_agent_id = os.getenv('FIVETRAN_HD_AGENT_ID', None)

    if env_hd_agent_id and not hd_agent_id and not args.force:
        hd_agent_id = get_input_from_cli("Provide the Hybrid Deployment Agent ID", env_hd_agent_id)
    return hd_agent_id

def get_state(args):
    if args.command.lower() == "deploy" and args.state:
        print_library_log(
            "unrecognised argument: '--state'; not supported by 'deploy'\n      manage connection state using the Fivetran API instead\n      reference:https://fivetran.com/docs/connector-sdk/working-with-connector-sdk#workingwithstatejsonfile",
            Logging.Level.WARNING
        )
        sys.exit(1)
    state = args.state if args.state else os.getenv('FIVETRAN_STATE', None)
    state = validate_and_load_state(args, state)
    return state


def get_configuration(args, retrying = 0):
    configuration = args.configuration if args.configuration else None
    env_configuration = os.getenv('FIVETRAN_CONFIGURATION', None)
    try:
        if not configuration and not args.force and args.command.lower() == "deploy":
            return _deploy_config_flow(args, env_configuration, retrying)
        config_values = validate_and_load_configuration(args.project_path, configuration)
        return config_values, configuration
    except ValueError as e:
        args.configuration = None
        if retrying >= MAX_RETRIES or args.force:
            print_library_log(f"invalid configuration error: {e}", level=Logging.Level.SEVERE, log_icon=Logging.LogIcon.FAILURE)
            sys.exit(1)
        else:
            return get_configuration(args, retrying + 1)


def check_newer_version(version: str):
    """Periodically checks for a newer version of the SDK and notifies the user if one is available."""
    tester_root_dir = tester_root_dir_helper()
    last_check_file_path = os.path.join(tester_root_dir, LAST_VERSION_CHECK_FILE)
    if not os.path.isdir(tester_root_dir):
        os.makedirs(tester_root_dir, exist_ok=True)

    if os.path.isfile(last_check_file_path):
        # Is it time to check again?
        with open(last_check_file_path, 'r', encoding=UTF_8) as f_in:
            timestamp = int(f_in.read())
            if (int(time.time()) - timestamp) < ONE_DAY_IN_SEC:
                return

    for index in range(MAX_RETRIES):
        try:
            # check version and save current time
            response = rq.get(PYPI_PACKAGE_DETAILS_URL)
            response.raise_for_status()
            data = json.loads(response.text)
            latest_version = data["info"]["version"]
            if version < latest_version:
                print_library_log(f"fivetran-connector-sdk {latest_version} is available. (a newer release exists)", log_icon=Logging.LogIcon.LIGHTNING)
                print_library_log("run 'pip install --upgrade fivetran-connector-sdk' to update", log_icon=Logging.LogIcon.LIGHTNING)

            with open(last_check_file_path, 'w', encoding=UTF_8) as f_out:
                f_out.write(f"{int(time.time())}")
            break
        except Exception:
            retry_after = 2 ** index
            print_library_log("unable to check for a newer version of `fivetran-connector-sdk`", Logging.Level.WARNING)
            print_library_log(f"retrying after {retry_after} seconds", Logging.Level.WARNING)
            time.sleep(retry_after)


def tester_root_dir_helper() -> str:
    """Returns the root directory for the tester."""
    return os.path.join(os.path.expanduser("~"), ROOT_LOCATION)


def _deploy_config_flow(args, env_configuration, retrying):
    """Handles the configuration flow for the deploy command."""
    confirm = 'y'
    if not retrying:
        json_filepath = os.path.join(args.project_path, CONFIGURATION_JSON)
        if os.path.exists(json_filepath):
            print_library_log("configuration.json found, "
                              "but --configuration flag was not provided for 'deploy'", Logging.Level.WARNING)
            env_configuration = env_configuration if env_configuration else CONFIGURATION_JSON
        confirm = input("does this run require configuration? (y/N): ")
    if confirm.lower() == 'y':
        configuration = get_input_from_cli("Provide the configuration file path", env_configuration)
        config_values = validate_and_load_configuration(args.project_path, configuration)
        return config_values, configuration
    else:
        print_library_log("️no configuration provided; continuing without configuration", level=Logging.Level.INFO, log_icon=Logging.LogIcon.INFO)
        return {}, None


def _warn_exit_usage(filename, line_no, func):
    print_library_log(
        f"avoid using {func} to exit from python code\n      this may cause the connector to hang\n      raise an error instead at: {filename}:{line_no}\n      reference: https://fivetran.com/docs/connector-sdk/technical-reference#handlingexceptions",
        Logging.Level.WARNING
    )


def _check_and_warn_attribute_exit(node):
    """Checks for the presence of 'exit()' in the AST node and warns if found."""
    if isinstance(node.func, ast.Name) and node.func.id == "exit":
        _warn_exit_usage(ROOT_FILENAME, node.lineno, "exit()")
    elif isinstance(node.func, ast.Attribute) and isinstance(node.func.value, ast.Name):
        if node.func.attr == "_exit" and node.func.value.id == "os":
            _warn_exit_usage(ROOT_FILENAME, node.lineno, "os._exit()")
        if node.func.attr == "exit" and node.func.value.id == "sys":
            _warn_exit_usage(ROOT_FILENAME, node.lineno, "sys.exit()")


def exit_check(project_path):
    """Checks for the presence of 'exit()' in the calling code.
    Args:
        project_path: The absolute project_path to check exit in the connector.py file in the project.
    """
    # We expect the connector.py to catch errors or throw exceptions
    # This is a warning shown to let the customer know that we expect either the yield call or error thrown
    # exit() or sys.exit() in between some yields can cause the connector to be stuck without processing further upsert calls

    filepath = os.path.join(project_path, ROOT_FILENAME)
    with open(filepath, "r", encoding=UTF_8) as f:
        try:
            tree = ast.parse(f.read())
            for node in ast.walk(tree):
                if isinstance(node, ast.Call):
                    _check_and_warn_attribute_exit(node)
        except SyntaxError as e:
            print_library_log(f"SyntaxError in {ROOT_FILENAME}: {e}", Logging.Level.SEVERE)


def check_dict(incoming: dict, string_only: bool = False) -> dict:
    """Validates the incoming dictionary.
    Args:
        incoming (dict): The dictionary to validate.
        string_only (bool): Whether to allow only string values.

    Returns:
        dict: The validated dictionary.
    """

    if not incoming:
        return {}

    if not isinstance(incoming, dict):
        raise ValueError(
            "invalid configuration file; must be a valid JSON object\nreference: https://fivetran.com/docs/connectors/connector-sdk/detailed-guide#workingwithconfigurationjsonfile")

    if string_only:
        for k, v in incoming.items():
            if not isinstance(v, str):
                print_library_log(
                    "invalid configuration file; all values must be strings\n      reference: https://fivetran.com/docs/connectors/connector-sdk/detailed-guide#workingwithconfigurationjsonfile", Logging.Level.SEVERE)
                sys.exit(1)

    return incoming


def is_connection_name_valid(connection: str):
    """Validates if the incoming connection schema name is valid or not.
    Args:
        connection (str): The connection schema name being validated.

    Returns:
        bool: True if connection name is valid.
    """

    pattern = re.compile(CONNECTION_SCHEMA_NAME_PATTERN)
    return pattern.match(connection)


def is_port_in_use(port: int):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        return s.connect_ex(('127.0.0.1', port)) == 0


def get_available_port():
    for port in range(50051, 50061):
        if not is_port_in_use(port):
            return port
    return None


def update_base_url_if_required():
    config_file_path = os.path.join(tester_root_dir_helper(), CONFIG_FILE)
    if os.path.isfile(config_file_path):
        with open(config_file_path, 'r', encoding=UTF_8) as f:
            data = json.load(f)
            base_url = data.get('production_base_url')
            if base_url is not None:
                constants.PRODUCTION_BASE_URL = base_url
                print_library_log(f"using custom production url: {base_url}", log_icon=Logging.LogIcon.INFO)

def fetch_requirements_from_file(file_path: str) -> list[str]:
    """Reads the requirements file and returns a list of dependencies.

    Args:
        file_path (str): The path to the requirements file.

    Returns:
        list[str]: A list of dependencies as strings.
    """
    with open(file_path, 'r', encoding=UTF_8) as f:
        return f.read().splitlines()

def fetch_requirements_as_dict(file_path: str) -> dict:
    """Converts a list of dependencies from the requirements file into a dictionary.

    Args:
        file_path (str): The path to the requirements file.

    Returns:
        dict: A dictionary where keys are package names (lowercase) and
        values are the full dependency strings.
    """
    requirements_dict = {}
    if not os.path.exists(file_path):
        return requirements_dict
    for requirement in fetch_requirements_from_file(file_path):
        requirement = requirement.strip()
        if not requirement or requirement.startswith("#"):  # Skip empty lines and comments
            continue
        try:
            key = re.split(r"==|>=|<=|>|<", requirement)[0]
            requirements_dict[key.lower().replace('-', '_')] = requirement.lower()
        except ValueError:
            print_library_log(f"Invalid requirement format: '{requirement}'", Logging.Level.SEVERE)
    return requirements_dict

def validate_requirements_file(project_path: str, is_deploy: bool, version: str):
    """Validates the `requirements.txt` file against the project's actual dependencies.

    This method generates a temporary requirements file using `pipreqs`, compares
    it with the existing `requirements.txt`, and checks for version mismatches,
    missing dependencies, and unused dependencies. It will issue warnings, errors,
    or even terminate the process depending on whether it's being run for deployment.

    Args:
        project_path (str): The path to the project directory containing the `requirements.txt`.
        is_deploy (bool): If `True`, the method will exit the process on critical errors.
        version (str): The current version of the connector.

    """
    requirements_file_path = os.path.join(project_path, REQUIREMENTS_TXT)
    requirements = load_or_add_requirements_file(requirements_file_path)

    # copying packages of requirements file to tmp file to handle pipreqs fail use-case
    tmp_requirements_file_path = os.path.join(project_path, 'tmp_requirements.txt')
    copy_requirements_file_to_tmp_requirements_file(requirements_file_path, tmp_requirements_file_path)

    # Run the pipreqs command and capture stderr
    run_pipreqs_with_retries(is_deploy, project_path, tmp_requirements_file_path)
    tmp_requirements = fetch_requirements_as_dict(tmp_requirements_file_path)
    remove_unwanted_packages(tmp_requirements)
    delete_file_if_exists(tmp_requirements_file_path)

    # remove corrupt requirements listed by pipreqs
    corrupt_requirements = [key for key in tmp_requirements if key.startswith("~")]
    for requirement in corrupt_requirements:
        del tmp_requirements[requirement]

    update_version_requirements = verify_version_mismatch_deps(is_deploy, requirements, tmp_requirements)
    update_missing_requirements = verify_missing_deps(is_deploy, requirements, tmp_requirements)
    update_unused_requirements = verify_unused_deps(is_deploy, requirements, tmp_requirements)

    if update_version_requirements or update_missing_requirements or update_unused_requirements:
        with open(requirements_file_path, "w", encoding=UTF_8) as file:
            file.write("\n".join(requirements.values()))
            print_library_log(f"`{REQUIREMENTS_TXT}` has been updated successfully.")
    elif not requirements:
        delete_file_if_exists(requirements_file_path)

    if is_deploy: print_library_log(f"Validation of {REQUIREMENTS_TXT} completed.")


def verify_unused_deps(is_deploy, requirements, tmp_requirements):

    unused_deps = list(requirements.keys() - tmp_requirements.keys() -
                       {"fivetran_connector_sdk", "fivetran-connector-sdk", "requests"})
    if not unused_deps:
        return False

    handle_unused_deps(unused_deps, is_deploy)
    if not is_deploy:
        return False

    confirm = input(f"Would you like us to update {REQUIREMENTS_TXT} to remove the unused libraries? (y/N):")
    if confirm.lower() == "n":
        print_library_log(
            f"Changes identified for unused libraries have been ignored. These changes have NOT been made to {REQUIREMENTS_TXT}.")
        return False
    elif confirm.lower() == "y":
        for requirement in unused_deps:
            del requirements[requirement]
        print_library_log(f"Successfully removed unused libraries from {REQUIREMENTS_TXT}.")
    return True


def verify_missing_deps(is_deploy, requirements, tmp_requirements):
    missing_deps = {key: tmp_requirements[key] for key in (tmp_requirements.keys() - requirements.keys())}
    if not missing_deps:
        return False

    handle_missing_deps(missing_deps, is_deploy)
    if not is_deploy:
        return False

    confirm = input(f"Would you like us to update {REQUIREMENTS_TXT} to add missing dependent libraries? (y/N):")
    if confirm.lower() == "n":
        print_library_log(
            f"Changes identified as missing dependencies for libraries have been ignored. These changes have NOT been made to {REQUIREMENTS_TXT}.")
        return False
    elif confirm.lower() == "y":
        for requirement in missing_deps:
            requirements[requirement] = tmp_requirements[requirement]
        print_library_log(f"Successfully added missing dependencies to {REQUIREMENTS_TXT}.")
    return True


def verify_version_mismatch_deps(is_deploy, requirements, tmp_requirements):
    version_mismatch_deps = {key: tmp_requirements[key] for key in
                             (requirements.keys() & tmp_requirements.keys())
                             if requirements[key] != tmp_requirements[key]}
    if not version_mismatch_deps:
        return False
    if not is_deploy:
        print_library_log("We recommend using the current stable version for the following libraries:",
                          Logging.Level.INFO)
        print(version_mismatch_deps)
        return False

    print_library_log("We recommend using the current stable version for the following libraries:",
                      Logging.Level.WARNING)
    print(version_mismatch_deps)
    confirm = input(
        f"Would you like us to update {REQUIREMENTS_TXT} to the current stable versions of the dependent libraries? (y/N):")
    if confirm.lower() == "n":
        print_library_log(
            f"Changes identified for libraries with version conflicts have been ignored. These changes have NOT been made to {REQUIREMENTS_TXT}.")
        return False
    elif confirm.lower() == "y":
        for requirement in version_mismatch_deps:
            requirements[requirement] = tmp_requirements[requirement]
        print_library_log(
            f"Successfully updated {REQUIREMENTS_TXT} to the current stable versions of the dependent libraries.")
    return True


def run_pipreqs_with_retries(is_deploy, project_path, tmp_requirements_file_path):
    # Detect and exclude virtual environment directories
    venv_dirs = [name for name in os.listdir(project_path)
                 if os.path.isdir(os.path.join(project_path, name)) and
                 VIRTUAL_ENV_CONFIG in os.listdir(os.path.join(project_path, name))]

    ignored_dirs = EXCLUDED_PIPREQS_DIRS + venv_dirs if venv_dirs else EXCLUDED_PIPREQS_DIRS

    attempt = 0
    while attempt < MAX_RETRIES:
        attempt += 1
        result = subprocess.run(
            ["pipreqs", project_path, "--savepath", tmp_requirements_file_path, "--ignore", ",".join(ignored_dirs)],
            stderr=subprocess.PIPE,
            text=True  # Ensures output is in string format
        )

        if result.returncode == 0:
            break

        print_library_log(f"attempt {attempt}: pipreqs check failed", Logging.Level.WARNING)

        if attempt < MAX_RETRIES:
            retry_after = 3 ** attempt
            print_library_log(f"retrying after {retry_after} seconds", Logging.Level.WARNING)
            time.sleep(retry_after)
        else:
            print_library_log(f"pipreqs failed after {MAX_RETRIES} attempts", Logging.Level.SEVERE)
            if result.stderr:
                print_library_log(f"pipreqs failed with error: {result.stderr.strip()}", Logging.Level.SEVERE)
            print_library_log(
                f"skipping requirements.txt validation; continuing with {'deploy' if is_deploy else 'debug'}",
                Logging.Level.WARNING)


def handle_unused_deps(unused_deps, is_deploy):
    if is_deploy:
        print_library_log("The following dependencies are not needed, "
              f"they are already installed or not in use. Remove them from {REQUIREMENTS_TXT}:", Logging.Level.WARNING)
    else:
        print_library_log("The following dependencies are not needed, "
              f"they are already installed or not in use. Remove them from {REQUIREMENTS_TXT}:", Logging.Level.INFO)
    print(*unused_deps)

def handle_missing_deps(missing_deps, is_deploy):
    if is_deploy:
        print_library_log(f"Include the following dependency libraries in {REQUIREMENTS_TXT}, to be used by "
              "Fivetran production. "
              "For more information, see our docs: "
              "https://fivetran.com/docs/connectors/connector-sdk/detailed-guide"
              "#workingwithrequirementstxtfile", Logging.Level.SEVERE)
    else:
        print_library_log(f"Include the following dependency libraries in {REQUIREMENTS_TXT}, to be used by "
                          "Fivetran production. "
                          "For more information, see our docs: "
                          "https://fivetran.com/docs/connectors/connector-sdk/detailed-guide"
                          "#workingwithrequirementstxtfile", Logging.Level.INFO)
    print(*list(missing_deps.values()))

def load_or_add_requirements_file(requirements_file_path):
    if os.path.exists(requirements_file_path):
        requirements = fetch_requirements_as_dict(requirements_file_path)
    else:
        with open(requirements_file_path, 'w', encoding=UTF_8):
            # Intentional empty block: Creating an empty requirements.txt file
            pass
        requirements = {}
        print_library_log("`requirements.txt` file not found in your project folder", Logging.Level.WARNING)
    return requirements

def copy_requirements_file_to_tmp_requirements_file(requirements_file_path: str, tmp_requirements_file_path):
    if os.path.exists(requirements_file_path):
        requirements_file_content = fetch_requirements_from_file(requirements_file_path)
        with open(tmp_requirements_file_path, 'w') as file:
            file.write("\n".join(requirements_file_content))

def remove_unwanted_packages(requirements: dict):
    # remove the `fivetran_connector_sdk` and `requests` packages from requirements as we already pre-installed them.
    if requirements.get("fivetran_connector_sdk") is not None:
        requirements.pop("fivetran_connector_sdk")
    if requirements.get('requests') is not None:
        requirements.pop("requests")

def evaluate_project(project_path: str, deploy_key: str):
    print_library_log(f"evaluating '{project_path}'", log_icon=Logging.LogIcon.STEP)
    package_file_path = create_package(project_path)
    try:
        evaluation_report = evaluate(package_file_path, project_path, deploy_key)
        if not evaluation_report:
            print_library_log(
                "evaluation failed; no report was generated",
                Logging.Level.SEVERE
            )
            sys.exit(1)
    finally:
        delete_file_if_exists(package_file_path)

def package_project(project_path: str, deploy_key: str) -> str:
    """Packages the project for deployment.

    Args:
        project_path (str): The path to the project directory.
        deploy_key (str): The deployment key.

    Returns:
        str: The uploaded package ID.
    """
    # Create a new package for both new and existing connections.
    package_file_path = create_package(project_path)
    try:
        uploaded_package_id = upload_package(
            package_file_path,
            deploy_key,
        )
        if not uploaded_package_id:
            sys.exit(1)
        print_library_log(f"package id: {uploaded_package_id}", indent=True)
        return uploaded_package_id
    finally:
        delete_file_if_exists(package_file_path)

def cleanup_uploaded_project(deploy_key: str, package_id: str):
    """Cleans up an orphaned package when connection creation fails.

    Args:
        deploy_key (str): The deployment key.
        package_id (str): The package ID to delete.
    """
    cleanup_result = cleanup_uploaded_code(deploy_key, package_id)
    if not cleanup_result:
        sys.exit(1)

def log_connection_success(response: rq.Response, is_new_connection: bool, connection_id: Optional[str]) -> None:
    """Logs connection creation or update success details.

    Args:
        response: The successful HTTP response from the API.
        is_new_connection: True if creating a new connection, False if updating.
        connection_id: The connection ID (provided for updates, extracted for creates).
    """
    # Extract connection_id from response if not provided (create case)
    conn_id = connection_id if connection_id else response.json()['data']['id']
    # Determine operation text and dashboard action based on flag
    operation = "created" if is_new_connection else "updated"
    dashboard_action = "to start the initial sync" if is_new_connection else "to manage the connection"
    print_library_log(f"connection {operation}", log_icon=Logging.LogIcon.SUCCESS)
    print_library_log(f"connection id: {conn_id}", indent=True)
    print_library_log(f"runtime python version: {response.json()['data']['config']['python_version']}",
                      level=Logging.Level.INFO, indent=True)
    print_library_log(f"visit the Fivetran dashboard {dashboard_action}:")
    print_library_log(f"https://fivetran.com/dashboard/connectors/{conn_id}/status")


def handle_connection_response(
    response: rq.Response,
    package_id: str,
    deploy_key: str,
    expected_status: int,
    is_new_connection: bool,
    connection_id: Optional[str] = None
) -> None:
    """Common handler for create/update connection responses.

    Args:
        response: The HTTP response from create/update connection API call.
        package_id: The package ID to cleanup if operation fails.
        deploy_key: The deployment key for cleanup operations.
        expected_status: The expected HTTP status code for success (e.g., 200 or 201).
        is_new_connection: True if creating a new connection, False if updating existing.
        connection_id: The connection ID (required for update, extracted from response for create).
    """
    if response.ok and response.status_code == expected_status:
        if are_setup_tests_failing(response):
            operation = "created" if is_new_connection else "updated"
            handle_failing_tests_message_and_exit(response, f"connection {operation} but setup tests failed")
        else:
            log_connection_success(response, is_new_connection, connection_id)
    else:
        action = "create" if is_new_connection else "update"
        print_library_log(
            f"failed to {action} connection error: {response.json()['message']}",
            level=Logging.Level.SEVERE, log_icon=Logging.LogIcon.FAILURE)
        cleanup_uploaded_project(deploy_key, package_id)
        sys.exit(1)

def update_connection(id: str, name: str, group: str, config: dict, package_id: str, deploy_key: str, hd_agent_id: str):
    """Updates the connection with the given ID, name, group, configuration, and deployment key.

    Args:
        id (str): The connection ID.
        name (str): The connection name.
        group (str): The group name.
        config (dict): The configuration dictionary.
        package_id (str): The package ID.
        deploy_key (str): The deployment key.
        hd_agent_id (str): The hybrid deployment agent ID within the Fivetran system.

    Returns:
        rq.Response: The response object.
    """
    if not config.get("secrets_list"):
        del config["secrets_list"]

    config["package_id"] = package_id
    json_payload = {
        "config": config,
        "run_setup_tests": True
    }

    # hybrid_deployment_agent_id is optional when redeploying your connection.
    # Customer can use it to change existing hybrid_deployment_agent_id.
    if hd_agent_id:
        json_payload["hybrid_deployment_agent_id"] = hd_agent_id

    response = rq.patch(f"{constants.PRODUCTION_BASE_URL}/v1/connectors/{id}",
                        headers={"Authorization": f"Basic {deploy_key}"},
                        json=json_payload)

    return response

def handle_failing_tests_message_and_exit(resp, log_message):
    print_library_log(log_message, Logging.Level.SEVERE)
    print_failing_setup_tests(resp)
    connection_id = resp.json().get('data', {}).get('id')
    print_library_log(f"connection id: {connection_id}")
    sys.exit(1)

def are_setup_tests_failing(response) -> bool:
    """Checks for failed setup tests in the response and returns True if any test has failed, otherwise False."""
    response_json = response.json()
    setup_tests = response_json.get("data", {}).get("setup_tests", [])

    # Return True if any test has "FAILED" status, otherwise False
    return any(test.get("status") == "FAILED" or test.get("status") == "JOB_FAILED" for test in setup_tests)

def print_failing_setup_tests(response):
    """Checks for failed setup tests in the response and print errors."""
    response_json = response.json()
    setup_tests = response_json.get("data", {}).get("setup_tests", [])

    # Collect failed setup tests
    failed_tests = [test for test in setup_tests if
                    test.get("status") == "FAILED" or test.get("status") == "JOB_FAILED"]

    if failed_tests:
        print_library_log("failed setup tests:", level=Logging.Level.WARNING, log_icon=Logging.LogIcon.FAILURE)
        for test in failed_tests:
            print_library_log(f"test: {test.get('title')}", level=Logging.Level.WARNING, indent=True)
            print_library_log(f"status: {test.get('status')}", level=Logging.Level.WARNING, indent=True)
            print_library_log(f"message: {test.get('message')}", level=Logging.Level.WARNING, indent=True)

def get_connection_details(name: str, group: str, group_id: str, deploy_key: str) -> Optional[Tuple[str, str]]:
    """Retrieves the connection ID for the specified connection schema name, group, and deployment key.

    Args:
        name (str): The connection name.
        group (str): The group name.
        group_id (str): The group ID.
        deploy_key (str): The deployment key.

    Returns:
        Optional[Tuple[str, str]]: A tuple of (connection_id, service_type) if found, None otherwise.
    """
    resp = rq.get(f"{constants.PRODUCTION_BASE_URL}/v1/groups/{group_id}/connectors",
                  headers={"Authorization": f"Basic {deploy_key}"},
                  params={"schema": name})
    if not resp.ok:
        print_library_log(
            f"failed to list connections for destination '{group}'", level=Logging.Level.SEVERE, log_icon=Logging.LogIcon.FAILURE)
        sys.exit(1)

    if resp.json()['data']['items']:
        return resp.json()['data']['items'][0]['id'], resp.json()['data']['items'][0]['service']

    return None

def create_connection(deploy_key: str, group_id: str, config: dict, hd_agent_id: str, package_id: str) -> rq.Response:
    """Creates a new connection with the given deployment key, group ID, and configuration.

    Args:
        deploy_key (str): The deployment key.
        group_id (str): The group ID.
        config (dict): The configuration dictionary.
        hd_agent_id (str): The hybrid deployment agent ID within the Fivetran system.
        package_id (str): The package ID.

    Returns:
        rq.Response: The response object.
    """
    print_library_log("creating connection", log_icon=Logging.LogIcon.STEP)
    config["package_id"] = package_id
    response = rq.post(f"{constants.PRODUCTION_BASE_URL}/v1/connectors",
                       headers={"Authorization": f"Basic {deploy_key}"},
                       json={
                           "group_id": group_id,
                           "service": "connector_sdk",
                           "config": config,
                           "paused": True,
                           "run_setup_tests": True,
                           "sync_frequency": "360",
                           "hybrid_deployment_agent_id": hd_agent_id
                       })
    return response


def create_package(project_path: str) -> str:
    """Creates a package file for the given project path.

    Args:
        project_path (str): The path to the project directory.

    Returns:
        str: The path to the packaged zip file.
    """
    print_library_log("packaging project for upload", log_icon=Logging.LogIcon.STEP)
    zip_file_path = zip_folder(project_path)
    print_library_log("project packaged for upload", log_icon=Logging.LogIcon.SUCCESS)
    return zip_file_path


def load_ftignore(directory_path: str) -> list[str]:
    """Load pattern lines from a .ftignore file in the specified directory.

    Follows gitignore conventions:
    - Blank lines are ignored
    - Lines starting with # are treated as comments and ignored
    - Leading and trailing whitespace is stripped from patterns

    Args:
        directory_path (str): The directory path to check for .ftignore file.

    Returns:
        list[str]: A list of non-empty, non-comment pattern strings from the .ftignore file.
                   Returns an empty list if the file doesn't exist or cannot be read
                   (OSError is logged as a warning).
    """
    ftignore_path = os.path.join(directory_path, constants.FTIGNORE_FILENAME)
    if os.path.exists(ftignore_path):
        try:
            with open(ftignore_path, 'r', encoding=constants.UTF_8) as file:
                patterns = []
                for line in file:
                    # Strip leading/trailing whitespace
                    line = line.strip()
                    # Skip empty lines and comments
                    if line and not line.startswith('#'):
                        patterns.append(line)
                print_library_log(f"loaded .ftignore with {len(patterns)} patterns")
                return patterns
        except OSError as e:
            print_library_log(f"failed to read .ftignore at {ftignore_path}: {e}", level=Logging.Level.WARNING, log_icon=Logging.LogIcon.FAILURE)
            print_library_log("using empty ignore patterns", Logging.Level.WARNING)
            return []
    return []


def get_default_ignore_patterns() -> list[str]:
    """Get default exclusion pattern strings for backwards compatibility.

    These patterns replicate the hardcoded exclusions from the original implementation.

    Returns:
        list[str]: A list of default ignore pattern strings.
    """
    # Convert EXCLUDED_DIRS to pathspec patterns with trailing slashes for directory matching
    default_patterns = [directory + '/' for directory in EXCLUDED_DIRS]
    # Add pattern to exclude hidden files and directories (starting with .)
    default_patterns.append('.*')
    return default_patterns


def normalize_path_for_matching(path: str) -> str:
    """Normalize path to POSIX-style for cross-platform pattern matching.

    Converts backslashes to forward slashes to ensure .ftignore patterns
    (which use gitwildmatch/POSIX syntax) work correctly on Windows.

    Args:
        path (str): Path with platform-specific separators

    Returns:
        str: Path with forward slashes (POSIX-style)
    """
    # Replace Windows backslashes with forward slashes
    # This is a no-op on Unix systems where os.sep is already '/'
    if os.sep != '/':
        return path.replace(os.sep, '/')
    return path


def transform_ftignore_patterns(patterns: list[str], directory_rel_path: str) -> list[str]:
    """Transform .ftignore patterns to be relative to project root.

    Patterns in nested .ftignore files are relative to their containing directory.
    This function transforms them to be relative to the project root for correct
    hierarchical pattern matching, following gitignore semantics.

    Args:
        patterns: Pattern strings from a .ftignore file
        directory_rel_path: Relative path from project root to the directory containing the .ftignore
                           (must use forward slashes - call normalize_path_for_matching first)

    Returns:
        Transformed patterns relative to project root

    Examples:
        >>> transform_ftignore_patterns(['/secret.py'], 'src')
        ['src/secret.py']  # Anchored pattern becomes relative to src/

        >>> transform_ftignore_patterns(['*.log'], 'src')
        ['src/**/*.log']  # Unanchored pattern matches recursively under src/

        >>> transform_ftignore_patterns(['!/important.log'], 'src')
        ['!src/important.log']  # Negation with anchored pattern
    """
    if not directory_rel_path or directory_rel_path == '.':
        # At project root, no transformation needed
        return patterns

    transformed = []
    for pattern in patterns:
        if not pattern:
            continue

        # Handle negation patterns
        is_negation = pattern.startswith('!')
        if is_negation:
            pattern = pattern[1:]  # Remove '!' temporarily

        # Transform based on pattern type
        if pattern.startswith('/'):
            # Anchored pattern: /foo -> dirpath/foo
            # Matches only direct children of the directory
            transformed_pattern = f"{directory_rel_path}/{pattern[1:]}"
        else:
            # Unanchored pattern: foo -> dirpath/**/foo
            # Matches anywhere recursively under the directory
            transformed_pattern = f"{directory_rel_path}/**/{pattern}"

        # Re-add negation if present
        if is_negation:
            transformed_pattern = f"!{transformed_pattern}"

        transformed.append(transformed_pattern)

    return transformed


def zip_folder(project_path: str) -> str:
    """Zips the folder at the given project path.

    Args:
        project_path (str): The path to the project.

    Returns:
        str: The path to the zip file.
    """
    # Derive zip filename from project folder name for better local file identification
    # Use absolute path to handle relative paths like '.'
    abs_project_path = os.path.abspath(project_path)
    project_name = os.path.basename(abs_project_path)
    upload_filename = f"{project_name}.zip" if project_name else UPLOAD_FILENAME
    upload_filepath = os.path.join(project_path, OUTPUT_FILES_DIR, upload_filename)
    os.makedirs(os.path.dirname(upload_filepath), exist_ok=True)
    connector_file_exists = False
    custom_drivers_exists = False
    custom_driver_installation_script_exists = False
    skip_tracker = {'has_skipped': False}

    with ZipFile(upload_filepath, 'w', ZIP_DEFLATED) as zipf:
        for root, files in dir_walker(project_path, skip_tracker=skip_tracker):
            if os.path.basename(root) == DRIVERS:
                custom_drivers_exists = True
            if INSTALLATION_SCRIPT in files:
                custom_driver_installation_script_exists = True
            for file in files:
                if file == ROOT_FILENAME:
                    connector_file_exists = True
                file_path = os.path.join(root, file)
                arcname = os.path.relpath(file_path, project_path)
                zipf.write(file_path, arcname)

    if not connector_file_exists:
        print_library_log(
            "connector.py not found in the project root\n      this file is required to start a sync and must be named in lowercase",
            Logging.Level.SEVERE)
        sys.exit(1)

    if custom_drivers_exists and not custom_driver_installation_script_exists:
        print_library_log(INSTALLATION_SCRIPT_MISSING_MESSAGE, Logging.Level.SEVERE)
        sys.exit(1)

    if skip_tracker['has_skipped']:
        print_library_log("ignored non-python files during deploy; uploading only .py files and requirements.txt")

    return upload_filepath

def _initialize_walker_patterns(top, project_root, parent_patterns):
    """Initialize patterns for directory walking.

    Args:
        top (str): The current directory being processed.
        project_root (str): The root of the project, or None on first call.
        parent_patterns (list[str]): Pattern strings from parent directories, or None on first call.

    Returns:
        tuple: (project_root, combined_patterns, combined_spec, has_negation)
            - project_root (str): The project root directory
            - combined_patterns (list[str]): Combined pattern strings
            - combined_spec (pathspec.PathSpec): Compiled pattern matcher
            - has_negation (bool): True if any negation patterns exist
    """
    if project_root is None:
        project_root = top
        parent_patterns = get_default_ignore_patterns()

    local_patterns = load_ftignore(top)

    if project_root != top:
        directory_rel_path = os.path.relpath(top, project_root)
        directory_rel_path = normalize_path_for_matching(directory_rel_path)
        local_patterns = transform_ftignore_patterns(local_patterns, directory_rel_path)

    combined_patterns = parent_patterns + local_patterns

    try:
        combined_spec = pathspec.PathSpec.from_lines('gitwildmatch', combined_patterns)
    except Exception as e:
        print_library_log(f"failed to parse .ftignore error: {e}", level=Logging.Level.SEVERE, log_icon=Logging.LogIcon.FAILURE)
        sys.exit(1)

    has_negation = any(pattern.strip().startswith('!') for pattern in combined_patterns if pattern.strip())

    return project_root, combined_patterns, combined_spec, has_negation


def _is_virtual_environment(path):
    """Check if a directory is a virtual environment.

    Treats inaccessible directories (OSError) as virtual environments to ensure they are skipped.

    Args:
        path (str): Path to the directory to check.

    Returns:
        bool: True if the directory is a virtual environment or inaccessible, False otherwise.
    """
    try:
        return VIRTUAL_ENV_CONFIG in os.listdir(path)
    except OSError as e:
        Logging.warning(f"Directory '{path}' could not be accessed and will be skipped as a virtual environment. Reason: {e}")
        return True


def _should_include_directory(path, project_root, combined_spec, has_negation):
    """Determine if a directory should be included in traversal.

    Args:
        path (str): Path to the directory.
        project_root (str): The project root directory.
        combined_spec (pathspec.PathSpec): Compiled pattern matcher.
        has_negation (bool): True if negation patterns exist.

    Returns:
        bool: True if the directory should be traversed, False if it should be skipped.
    """
    rel_path = os.path.relpath(path, project_root)
    normalized_rel_path = normalize_path_for_matching(rel_path)
    dir_match_path = normalized_rel_path + '/'

    if combined_spec.match_file(dir_match_path) and not has_negation:
        return False
    return True


def _should_include_file(name, path, project_root, combined_spec, in_drivers_folder, has_negation):
    """Determine if a file should be included based on patterns and type.

    Args:
        name (str): The file name.
        path (str): Full path to the file.
        project_root (str): The project root directory.
        combined_spec (pathspec.PathSpec): Compiled pattern matcher.
        in_drivers_folder (bool): True if the file is in the drivers/ folder.
        has_negation (bool): True if negation patterns exist.

    Returns:
        bool: True if the file should be included, False otherwise.
    """
    # First check if file type qualifies for potential inclusion
    is_allowed_type = in_drivers_folder or name.endswith(".py") or name == "requirements.txt"
    if not is_allowed_type:
        return False

    # Now check against .ftignore patterns
    rel_path = os.path.relpath(path, project_root)
    normalized_rel_path = normalize_path_for_matching(rel_path)

    if has_negation:
        # When negations exist, use check_file for detailed result
        check_result = combined_spec.check_file(normalized_rel_path)
        if check_result.include is None:
            # No pattern matched, include the file
            return True
        else:
            # pathspec's include field is inverted for gitignore semantics:
            # include=True means "matched exclusion pattern" (exclude file)
            # include=False means "matched negation pattern" (include file)
            return not check_result.include
    else:
        # Fast path when no negations exist
        if combined_spec.match_file(normalized_rel_path):
            # Matched an exclusion pattern
            return False
        # No match, include the file
        return True


def _classify_directory_entries(top, project_root, combined_spec, has_negation, skip_tracker):
    """Classify directory entries into directories to recurse and files to include.

    Args:
        top (str): The current directory being processed.
        project_root (str): The project root directory.
        combined_spec (pathspec.PathSpec): Compiled pattern matcher.
        has_negation (bool): True if negation patterns exist.
        skip_tracker (dict):  Mutable dict to track if files were skipped

    Returns:
        tuple: (dirs, files) - lists of directory and file names to process.
    """
    dirs = []
    files = []
    in_drivers_folder = os.path.basename(top) == DRIVERS

    for name in os.listdir(top):
        path = os.path.join(top, name)
        is_dir = os.path.isdir(path)

        if is_dir:
            if _is_virtual_environment(path):
                continue

            if _should_include_directory(path, project_root, combined_spec, has_negation):
                dirs.append(name)
        else:
            if _should_include_file(name, path, project_root, combined_spec, in_drivers_folder, has_negation):
                files.append(name)
            elif name!=CONFIGURATION_JSON:
                skip_tracker['has_skipped'] = True

    return dirs, files


def dir_walker(top, project_root=None, parent_patterns=None, skip_tracker=None):
    """Walks the directory tree starting at the given top directory with .ftignore support.

    This function supports hierarchical .ftignore files similar to .gitignore behavior.
    Default exclusion patterns are applied automatically for backwards compatibility.

    The drivers/ folder has special handling for file types only:
    - drivers/ folder: Includes ALL file types (.jar, .so, .dll, etc.) but still applies .ftignore patterns
    - Other folders: Only includes .py files and requirements.txt, and applies .ftignore patterns

    Args:
        top (str): The top directory to start the walk.
        project_root (str, optional): Internal use only. Set automatically during recursion.
        parent_patterns (list[str], optional): Internal use only. Set automatically during recursion.
        skip_tracker (dict): Tracks if files were skipped

    Yields:
        tuple: A tuple containing the current directory path and a list of files (root, files).
    """
    if skip_tracker is None:
        skip_tracker = {'has_skipped': False}

    project_root, combined_patterns, combined_spec, has_negation = \
        _initialize_walker_patterns(top, project_root, parent_patterns)

    dirs, files = _classify_directory_entries(top, project_root, combined_spec, has_negation, skip_tracker)

    yield top, files

    for name in dirs:
        new_path = os.path.join(top, name)
        yield from dir_walker(new_path, project_root, combined_patterns, skip_tracker)


def render_section(lines, title, items):
    """
    Renders a section of the markdown report.
    Args:
        lines (list): The list of lines to append to.
        title (str): The title of the section.
        items (list): The list of items in the section.
    """
    lines.extend([f"## {title}", ""])
    if not items:
        lines.extend(["_No recommendations._", ""])
        return
    for index, item in enumerate(items, 1):
        issue = item.get("issue", "(missing issue)")
        lines.append(f"### {index}. {issue}")
        if recommendation := item.get("recommendation"):
            lines.append(f"- **Recommendation:** {recommendation}")
        if current_code := item.get("current_code"):
            fenced_code = f"```python\n{current_code.rstrip()}\n```"
            lines += ["\n**Current Code:**", fenced_code]
        if fix := item.get("code_fix"):
            fenced_code = f"```python\n{fix.rstrip()}\n```"
            lines += ["\n**Code Fix:**", fenced_code]
        lines.append("")


def render_markdown(report):
    """
    Renders the evaluation report as markdown.
    Args:
        report (dict): The evaluation report.
    """
    lines = []
    lines += ["# Evaluation Report", ""]
    overall_score = report.get("score")
    if overall_score:
        lines += [f"**Overall Score:** {overall_score}", ""]

    subscore = report.get("subscores") or {}
    if subscore:
        lines += ["## Subscores", "", "| Metric | Score |", "|---|---:|"]
        lines += [f"| {key} | {value} |" for key, value in subscore.items()]
        lines.append("")

    render_section(lines, "Required", report.get("required"))
    render_section(lines, "Good to Have", report.get("good_to_have"))

    return "\n".join(lines)


def save_evaluation_report(evaluation_report, project_path: str):
    """Saves the evaluation report to a file in the project path.
    Args:
        evaluation_report: The evaluation data.
        project_path: The path to the project.
    """
    # Save evaluation report
    working_dir = os.path.join(project_path, OUTPUT_FILES_DIR)
    os.makedirs(working_dir, exist_ok=True)
    report_path = os.path.join(working_dir, EVALUATION_MARKDOWN)
    markdown_content = render_markdown(evaluation_report)
    try:
        with open(report_path, 'w', encoding=UTF_8) as report_file:
            report_file.write(markdown_content)
        print_library_log(f"evaluation report saved to {report_path}", log_icon=Logging.LogIcon.SUCCESS)
    except Exception as e:
        print_library_log(f"failed to save evaluation report: {e}", level=Logging.Level.SEVERE, log_icon=Logging.LogIcon.FAILURE)


def print_evaluation_summary(evaluation_data):
    """
    Prints a summary of the evaluation data to the console.
    Args:
        evaluation_data (dict): The evaluation data.
    """
    print("Evaluation Summary")
    print("─" * 20)

    print(f"Overall score: {evaluation_data.get('score')}")
    subscores = evaluation_data.get("subscores", {})
    if subscores:
        print("Subscores:")
        for name, value in subscores.items():
            print(f"  {name:<14}: {value}")

    required = evaluation_data.get("required", [])
    good_to_have = evaluation_data.get("good_to_have", [])

    if required:
        print(f"Required Issues ({len(required)}):")
        for item in required:
            print(f"  • {item.get('issue')}")

    if good_to_have:
        print(f"Good-to-have Issues ({len(good_to_have)}):")
        for item in good_to_have:
            print(f"  • {item.get('issue')}")


def evaluate(local_path: str, project_path:str, deploy_key: str):
    """Uploads the local code file for evaluation and returns the evaluation report.

    The server responds with a file containing JSON. This function streams the
    file safely, parses the JSON, and prints it.

    Args:
        local_path (str): The local file path.
        project_path (str): The path to the project.
        deploy_key (str): The deployment key.

    Returns:
        dict | None: Parsed evaluation report if successful, None otherwise.
    """
    print_library_log("uploading project for evaluation", log_icon=Logging.LogIcon.STEP)

    with open(local_path, 'rb') as f:
        response = rq.post(
            f"{constants.PRODUCTION_BASE_URL}{constants.EVALUATE_ENDPOINT}",
            files={'file': f},
            headers={
                "Authorization": f"Basic {deploy_key}",
                "X-OS-ARCH": get_os_arch_suffix(),
                "User-Agent": "fivetran-connector-sdk"},
            stream=True  # stream to handle file responses safely
        )

    if response.ok:
        try:
            buffer = io.BytesIO()
            for chunk in response.iter_content(chunk_size=8192):
                buffer.write(chunk)
            buffer.seek(0)

            evaluation_data = json.load(buffer)
            save_evaluation_report(evaluation_data, project_path)
            print_evaluation_summary(evaluation_data)

            return evaluation_data

        except json.JSONDecodeError as e:
            print_library_log(f"failed to parse evaluation report error: {e}", level=Logging.Level.SEVERE, log_icon=Logging.LogIcon.FAILURE)
            return None

    print_library_log(
        f"failed to upload project for evaluation error: {response.text}",
        level=Logging.Level.SEVERE,
        log_icon=Logging.LogIcon.FAILURE
    )
    return None


def upload_package(local_path: str, deploy_key: str) -> Optional[str]:
    """Uploads a connector package to Fivetran's package management system.

    Always creates a new package via POST.

    Args:
        local_path (str): The absolute path to the package zip file.
        deploy_key (str): Base64-encoded Fivetran API key.

    Returns:
        Optional[str]: The package ID if upload succeeded, None if failed.
    """
    print_library_log("uploading package", log_icon=Logging.LogIcon.STEP)
    url = f"{constants.PRODUCTION_BASE_URL}/v1/connector-sdk/packages"

    headers = {
        "Authorization": f"Basic {deploy_key}",
        "X-OS-ARCH": get_os_arch_suffix(),
        "User-Agent": "fivetran-connector-sdk"
    }

    with open(local_path, 'rb') as f:
        response = rq.post(url, files={'file': f}, headers=headers)

    if response.ok:
        try:
            response_data = response.json()
        except json.JSONDecodeError as e:
            print_library_log(
                f"package upload succeeded but failed to parse response JSON: {e}. Response text: {response.text}",
                Logging.Level.SEVERE)
            return None

        package_id = response_data.get('data', {}).get('id')
        if not package_id:
            print_library_log(
                "package upload succeeded but response missing package ID. Response: " + str(response_data),
                Logging.Level.SEVERE)
            return None

        print_library_log("package uploaded", log_icon=Logging.LogIcon.SUCCESS)
        return package_id

    try:
        error_details = json.loads(response.text).get("message", response.text)
    except json.JSONDecodeError:
        error_details = response.text
    error_message = f"{response.reason}: {error_details}"
    print_library_log(f"failed to upload the package error: {error_message}", level=Logging.Level.SEVERE, log_icon=Logging.LogIcon.FAILURE)
    return None

def cleanup_uploaded_code(deploy_key: str, package_id: str) -> bool:
    """Deletes an orphaned package when connection creation fails.

    Args:
        deploy_key (str): The deployment key.
        package_id (str): The package ID to delete.

    Returns:
        bool: True if the cleanup was successful, False otherwise.
    """
    print_library_log(f"cleaning up orphaned package: {package_id}", log_icon=Logging.LogIcon.STEP)
    response = rq.delete(f"{constants.PRODUCTION_BASE_URL}/v1/connector-sdk/packages/{package_id}",
                         headers={"Authorization": f"Basic {deploy_key}"})
    if response.ok:
        print_library_log("cleaned up orphaned package", log_icon=Logging.LogIcon.SUCCESS)
        return True

    print_library_log(f"failed to cleanup orphaned package error: {response.reason}",
                      level=Logging.Level.SEVERE, log_icon=Logging.LogIcon.FAILURE)
    return False

def get_os_arch_suffix() -> str:
    """
    Returns the operating system and architecture suffix for the current operating system.
    """
    system = platform.system().lower()
    machine = platform.machine().lower()

    if system not in OS_MAP:
        raise RuntimeError(f"unsupported OS: {system}")

    plat = OS_MAP[system]

    if machine not in ARCH_MAP or (plat == WIN_OS and ARCH_MAP[machine] != X64):
        raise RuntimeError(f"unsupported architecture '{machine}' for {plat}")

    return f"{plat}-{ARCH_MAP[machine]}"

def get_group_info(group: str, deploy_key: str) -> tuple[str, str]:
    """Retrieves the group information for the specified group and deployment key.

    Args:
        group (str): The group name.
        deploy_key (str): The deployment key.

    Returns:
        tuple[str, str]: A tuple containing the group ID and group name.
    """
    groups_url = f"{constants.PRODUCTION_BASE_URL}/v1/groups"

    params = {"limit": 500}
    headers = {"Authorization": f"Basic {deploy_key}"}
    resp = rq.get(groups_url, headers=headers, params=params)

    if not resp.ok:
        print_library_log(
            f"request failed error: {resp.status_code}\n      ensure you're using a valid base64-encoded API key",
            Logging.Level.SEVERE)
        sys.exit(1)

    data = resp.json().get("data", {})
    groups = data.get("items")

    if not groups:
        print_library_log("failed to deploy; no destinations defined in account", level=Logging.Level.SEVERE, log_icon=Logging.LogIcon.FAILURE)
        sys.exit(1)

    if not group:
        if len(groups) == 1:
            return groups[0]['id'], groups[0]['name']
        else:
            print_library_log(
                "failed to deploy; multiple destinations found and --destination not provided",
                level=Logging.Level.SEVERE, log_icon=Logging.LogIcon.FAILURE)
            sys.exit(1)

    while True:
        for grp in groups:
            if grp['name'] == group:
                return grp['id'], grp['name']
        next_cursor = data.get("next_cursor")
        if not next_cursor:
            break

        params = {"cursor": next_cursor, "limit": 500}
        resp = rq.get(groups_url, headers=headers, params=params)
        data = resp.json().get("data", {})
        groups = data.get("items", [])

    print_library_log(
        f"failed to deploy; destination '{group}' not found in account", level=Logging.Level.SEVERE, log_icon=Logging.LogIcon.FAILURE)
    sys.exit(1)

def java_exe_helper(location: str, os_arch_suffix: str) -> str:
    """Returns the path to the Java executable.

    Args:
        location (str): The location of the Java executable.
        os_arch_suffix (str): The name of the operating system and architecture

    Returns:
        str: The path to the Java executable.
    """
    java_exe_base = os.path.join(location, "bin", "java")
    return f"{java_exe_base}.exe" if os_arch_suffix == f"{WIN_OS}-{X64}" else java_exe_base

def process_stream(stream):
    """Processes a stream of text lines, replacing occurrences of a specified pattern.

    This method reads each line from the provided stream, searches for occurrences of
    a predefined pattern, and skips them.

    Args:
        stream (iterable): An iterable stream of text lines, typically from a file or another input source.

    Yields:
        str: Each line from the stream after skipping the matched pattern.
    """
    tester_pattern = r'com\.fivetran\.partner_sdk.*\.tools\.testers\.\S+'
    client_pattern = r'com\.fivetran\.partner_sdk.*\.client\.connector\.PartnerSdkConnectorClient'
    skip_next = False

    for line in iter(stream.readline, ""):
        if skip_next:
            # Skip the line immediately following the client_pattern
            skip_next = False
            continue
        if re.search(tester_pattern, line):
            continue
        if re.search(client_pattern, line):
            skip_next = True
            continue

        yield line

def redact_configuration_values(configuration: dict) -> dict:
    """Redacts all values in a configuration dictionary while preserving keys.

    Args:
        configuration (dict): The configuration dictionary to redact.

    Returns:
        dict: A new dictionary with all string values replaced with REDACTED_VALUE.
    """
    if not configuration:
        return configuration

    redacted = {}
    for key, value in configuration.items():
        # All configuration values should be strings
        redacted[key] = REDACTED_VALUE
    return redacted


def _build_tester_command(java_exe_str: str, root_dir: str, working_dir: str, port: int,
                          state_json: str, configuration_json: str) -> list:
    """Builds the command list for running the tester.

    Args:
        java_exe_str (str): The path to the Java executable.
        root_dir (str): The root directory.
        working_dir (str): The working directory for test output.
        port (int): The port number to use for the tester.
        state_json (str): The state JSON string to pass to the tester.
        configuration_json (str): The configuration JSON string to pass to the tester.

    Returns:
        list: The command list for subprocess execution.
    """
    cmd = [java_exe_str,
           "-jar",
           os.path.join(root_dir, TESTER_FILENAME),
           "--connector-sdk=true",
           f"--port={port}",
           f"--working-dir={working_dir}",
           "--tester-type=source",
           f"--state={state_json}",
           f"--configuration={configuration_json}"]

    return cmd


def run_tester(java_exe_str: str, root_dir: str, project_path: str, port: int, state_json: str, configuration: dict):
    """Runs the connector tester.

    Args:
        java_exe_str (str): The path to the Java executable.
        root_dir (str): The root directory.
        project_path (str): The path to the project.
        port (int): The port number to use for the tester.
        state_json (str): The state JSON string to pass to the tester.
        configuration (dict): The configuration dictionary to pass to the tester.

    Yields:
        str: The log messages from the tester.
    """
    working_dir = os.path.join(project_path, OUTPUT_FILES_DIR)
    try:
        os.mkdir(working_dir)
    except FileExistsError:
        pass

    cmd = _build_tester_command(java_exe_str, root_dir, working_dir, port, state_json, json.dumps(configuration))

    popen = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)
    for line in process_stream(popen.stderr):
        yield _maybe_colorize_jar_output(line)

    for line in process_stream(popen.stdout):
        yield _maybe_colorize_jar_output(line)
    popen.stdout.close()
    return_code = popen.wait()
    if return_code:
        # Build redacted command for error reporting
        configuration_redacted = redact_configuration_values(configuration)
        redacted_cmd = _build_tester_command(java_exe_str, root_dir, working_dir, port, state_json, json.dumps(configuration_redacted))
        raise subprocess.CalledProcessError(return_code, redacted_cmd)

def _maybe_colorize_jar_output(line: str) -> str:
    if not constants.DEBUGGING:
        return line

    if "SEVERE" in line or "ERROR" in line or "Exception" in line or "FAILED" in line:
        return f"\033[196m{line}\033[0m"  # ANSI Red color #ff0000
    elif "WARN" in line or "WARNING" in line:
        return f"\033[130m{line}\033[0m"  # ANSI Orange-like color #af5f00
    return line

def process_tables(response, table_list):
    for entry in response:
        if 'table' not in entry:
            raise ValueError("Entry missing table name: " + entry)

        table_name = entry['table']

        if table_name in table_list:
            raise ValueError("Table already defined: " + table_name)

        table = common_pb2.Table(name=table_name)
        columns = {}

        if "primary_key" in entry:
            process_primary_keys(columns, entry)

        if "columns" in entry:
            process_columns(columns, entry)

        table.columns.extend(columns.values())
        TABLES[table_name] = table
        table_list[table_name] = table

def process_primary_keys(columns, entry):
    for column_name in entry["primary_key"]:
        column = columns[column_name] if column_name in columns else common_pb2.Column(name=column_name)
        column.primary_key = True
        columns[column_name] = column

def process_columns(columns, entry):
    for column_name, type in entry["columns"].items():
        column = columns[column_name] if column_name in columns else common_pb2.Column(name=column_name)

        if isinstance(type, str):
            process_data_type(column, type)

        elif isinstance(type, dict):
            if type['type'].upper() != "DECIMAL":
                error_message = (
                    f"Expecting DECIMAL data type for dictionary column entry, but got: {type['type']} in entry: {entry} "
                    f"for column: {column_name}. "
                    "Dictionary type is only allowed for DECIMAL columns with 'precision' and 'scale' fields, "
                    "as in: {'type': 'DECIMAL', 'precision': <int>, 'scale': <int>}. "
                    "For all other data types, use a string as the column type."
                )
                raise ValueError(error_message)
            column.type = common_pb2.DataType.DECIMAL
            column.params.decimal.precision = type['precision']
            column.params.decimal.scale = type['scale']

        else:
            raise ValueError(
                f"Unrecognized column type for column: {column_name} in entry: {entry}. Got: {str(type)}"
            )

        if "primary_key" in entry and column_name in entry["primary_key"]:
            column.primary_key = True


        columns[column_name] = column

def process_data_type(column, type):
    if type.upper() == "BOOLEAN":
        column.type = common_pb2.DataType.BOOLEAN
    elif type.upper() == "SHORT":
        column.type = common_pb2.DataType.SHORT
    elif type.upper() == "INT":
        column.type = common_pb2.DataType.INT
    elif type.upper() == "LONG":
        column.type = common_pb2.DataType.LONG
    elif type.upper() == "DECIMAL":
        raise ValueError(
            "DECIMAL data type missing precision and scale. "
            "Use a dictionary for DECIMAL column type like: "
            '''"col_name": {  # Decimal data type with precision and scale.\n'''
            '''    "type": "DECIMAL",\n'''
            '''    "precision": 15,\n'''
            '''    "scale": 2\n'''
            '''}'''
        )
    elif type.upper() == "FLOAT":
        column.type = common_pb2.DataType.FLOAT
    elif type.upper() == "DOUBLE":
        column.type = common_pb2.DataType.DOUBLE
    elif type.upper() == "NAIVE_DATE":
        column.type = common_pb2.DataType.NAIVE_DATE
    elif type.upper() == "NAIVE_DATETIME":
        column.type = common_pb2.DataType.NAIVE_DATETIME
    elif type.upper() == "UTC_DATETIME":
        column.type = common_pb2.DataType.UTC_DATETIME
    elif type.upper() == "BINARY":
        column.type = common_pb2.DataType.BINARY
    elif type.upper() == "XML":
        column.type = common_pb2.DataType.XML
    elif type.upper() == "STRING":
        column.type = common_pb2.DataType.STRING
    elif type.upper() == "JSON":
        column.type = common_pb2.DataType.JSON
    else:
        raise ValueError("Unrecognized column type encountered:: ", str(type))

def delete_file_if_exists(file_path):
    if os.path.exists(file_path):
        os.remove(file_path)
