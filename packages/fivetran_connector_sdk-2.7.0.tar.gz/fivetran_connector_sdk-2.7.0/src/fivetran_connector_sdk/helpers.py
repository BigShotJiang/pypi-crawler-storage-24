import os
import select
import stat
import shutil
import sys
import json
import importlib.util
from datetime import datetime
from prompt_toolkit import prompt
from prompt_toolkit.document import Document
from prompt_toolkit.history import FileHistory
from prompt_toolkit.completion import Completer, Completion, PathCompleter, merge_completers

from fivetran_connector_sdk.logger import Logging
from fivetran_connector_sdk import constants
from fivetran_connector_sdk.constants import (
    LOGGING_PREFIX,
    ROOT_FILENAME,
    MAX_CONFIG_FIELDS,
    MAX_ALLOWED_EDIT_DISTANCE_FROM_VALID_COMMAND,
    COMMANDS_AND_SYNONYMS,
    VALID_COMMANDS,
    OUTPUT_FILES_DIR,
    UTF_8,
    FIFO_READ_TIMEOUT_SECONDS
)

RENAMED_TABLE_NAMES = {}
RENAMED_COL_NAMES = {}


def is_regular_file_or_fifo(filepath):
    """Check if the given path is a regular file or a FIFO (named pipe).

    Args:
        filepath (str): The path to check.

    Returns:
        bool: True if the path is a regular file or FIFO, False otherwise.
    """
    try:
        file_stat = os.stat(filepath)
        mode = file_stat.st_mode
        return stat.S_ISREG(mode) or stat.S_ISFIFO(mode)
    except (FileNotFoundError, NotADirectoryError):
        # Path does not exist or an intermediate component is not a directory.
        # In these cases, treat it as "not a regular file or FIFO".
        return False


def is_fifo(filepath):
    """Check if the given path is a FIFO (named pipe).

    Args:
        filepath (str): The path to check.

    Returns:
        bool: True if the path is a FIFO, False otherwise.
    """
    try:
        file_stat = os.stat(filepath)
        return stat.S_ISFIFO(file_stat.st_mode)
    except (FileNotFoundError, NotADirectoryError):
        return False


def safe_read_file(filepath, timeout_seconds=FIFO_READ_TIMEOUT_SECONDS):
    """Read contents from a file, with special handling for FIFOs to avoid indefinite blocking.

    For regular files, reads normally.
    For FIFOs (named pipes), uses non-blocking I/O with a timeout to prevent
    hanging indefinitely when a writer is delayed or crashes.

    Args:
        filepath (str): Path to the file to read.
        timeout_seconds (int): Timeout in seconds for FIFO reads (default: 30).

    Returns:
        str: The file contents.

    Raises:
        TimeoutError: If FIFO read times out waiting for a writer.
        OSError: If the file cannot be read.
    """
    if not is_fifo(filepath):
        # Regular file - open normally
        with open(filepath, 'r', encoding=UTF_8) as f:
            return f.read()

    # FIFO - use non-blocking open with timeout
    fd = None
    try:
        # Open FIFO in non-blocking mode to avoid blocking on open()
        fd = os.open(filepath, os.O_RDONLY | os.O_NONBLOCK)

        # Wait for data to be available with timeout
        readable, _, _ = select.select([fd], [], [], timeout_seconds)

        if not readable:
            raise TimeoutError(
                f"Timed out after {timeout_seconds} seconds waiting for data from FIFO: {filepath}. "
                "Ensure the writer process is running and producing data."
            )

        # Switch back to blocking mode so read() waits for complete data until EOF.
        # Without this, read() on a non-blocking fd returns only currently buffered
        # bytes, which can cause truncated reads if the writer emits data in chunks.
        import fcntl  # Unix-only, imported lazily to avoid breaking Windows for non-FIFO paths
        flags = fcntl.fcntl(fd, fcntl.F_GETFL)
        fcntl.fcntl(fd, fcntl.F_SETFL, flags & ~os.O_NONBLOCK)

        # Read all data - fdopen takes ownership of fd
        with os.fdopen(fd, 'r', encoding=UTF_8) as f:
            fd = None  # Prevent double-close in finally block
            return f.read()
    finally:
        if fd is not None:
            os.close(fd)


def print_library_log(message: str, level: Logging.Level = Logging.Level.INFO, dev_log: bool = False, log_icon: Logging.LogIcon = Logging.LogIcon.NONE, indent: bool = False):
    """Logs a library message with the specified logging level.
    Args:
        level (Logging.Level): The logging level.
        message (str): The message to log.
        dev_log (bool): Boolean value to check if it is dev log and shouldn't be visible to customer
        log_icon (Logging.LogIcon): The type of log icon to add.
        indent (bool): Whether to indent the message.
    """
    message = add_icon_to_log_message(message, log_icon)
    if indent:
        message = f"  {message}"
    if constants.DEBUGGING or constants.EXECUTED_VIA_CLI:
        if dev_log:
            return
        now = datetime.now()
        current_time = now.strftime("%d-%b %H:%M:%S.") + f"{now.microsecond // 1000:03d}"
        prefix = f"{current_time} {level.name} {LOGGING_PREFIX}"
        print(f"{Logging.get_color(level)}{prefix}{message} {Logging.reset_color()}")
    else:
        message_origin = "library_dev" if dev_log else "library"
        escaped_message = json.dumps(LOGGING_PREFIX + message)
        log_message = f'{{"level":"{level.name}", "message": {escaped_message}, "message_origin": "{message_origin}"}}'
        print(log_message)


def add_icon_to_log_message(message: str, log_icon: Logging.LogIcon):
    """Adds an icon to the log message based on the specified log icon type.
    Args:
        message (str): The message to log.
        log_icon (Logging.LogIcon): The type of log icon to add.
    Returns:
        str: The log message with the added icon.
    """
    match log_icon:
        case Logging.LogIcon.INFO:
            return f"ℹ️ {message}"
        case Logging.LogIcon.SUCCESS:
            return f"✓ {message}"
        case Logging.LogIcon.FAILURE:
            return f"✗ {message}"
        case Logging.LogIcon.STEP:
            return f"› {message}"
        case Logging.LogIcon.LIGHTNING:
            return f"⚡ {message}"
        case _:
            return message


# Functions used by main method only

def find_connector_object(project_path):
    """Finds the connector object in the given project path.
    Args:
        project_path (str): The path to the project.
    """

    sys.path.append(project_path)  # Allows python interpreter to search for modules in this path
    module_name = "connector_connector_code"
    connector_py = os.path.join(project_path, ROOT_FILENAME)
    try:
        spec = importlib.util.spec_from_file_location(module_name, connector_py)
        module = importlib.util.module_from_spec(spec)
        sys.modules[module_name] = module
        spec.loader.exec_module(module)
        for obj in dir(module):
            if not obj.startswith('__'):  # Exclude built-in attributes
                obj_attr = getattr(module, obj)
                if '<fivetran_connector_sdk.Connector object at' in str(obj_attr):
                    return obj_attr
    except FileNotFoundError:
        print_library_log(
            f"connector.py not found in {project_path}\n      this file is required to start a sync\n      reference: https://fivetran.com/docs/connectors/connector-sdk/technical-reference#technicaldetailsrequiredobjectconnector",
            Logging.Level.SEVERE)
        return None

    print_library_log(
        "connector object not found\n      define a Connector object in connector.py\n      reference: https://fivetran.com/docs/connectors/connector-sdk/technical-reference#technicaldetailsrequiredobjectconnector",
        Logging.Level.SEVERE)
    return None


def suggest_correct_command(input_command: str) -> bool:
    # for typos
    # calculate the edit distance of the input command (lowercased) with each of the valid commands
    edit_distances_of_commands = sorted(
        [(command, edit_distance(command, input_command.lower())) for command in VALID_COMMANDS], key=lambda x: x[1])

    if edit_distances_of_commands[0][1] <= MAX_ALLOWED_EDIT_DISTANCE_FROM_VALID_COMMAND:
        # if the closest command is within the max allowed edit distance, we suggest that command
        # threshold is kept to prevent suggesting a valid command for an obvious wrong command like `fivetran iknowthisisntacommandbuttryanyway`
        print_suggested_command_message(edit_distances_of_commands[0][0], input_command)
        return True

    # for synonyms
    for (command, synonyms) in COMMANDS_AND_SYNONYMS.items():
        # check if the input command (lowercased) is a recognised synonym of the valid commands, if yes, suggest that command
        if input_command.lower() in synonyms:
            print_suggested_command_message(command, input_command)
            return True

    return False


def print_suggested_command_message(valid_command: str, input_command: str) -> None:
    print_library_log(f"unknown command: {input_command}", Logging.Level.SEVERE)
    print_library_log(f"did you mean `fivetran {valid_command}`?", Logging.Level.SEVERE)
    print_library_log("use `fivetran --help` for more details", Logging.Level.SEVERE)


def edit_distance(first_string: str, second_string: str) -> int:
    first_string_length: int = len(first_string)
    second_string_length: int = len(second_string)

    # Initialize the previous row of distances (for the base case of an empty first string) 'previous_row[j]' holds
    # the edit distance between an empty prefix of 'first_string' and the first 'j' characters of 'second_string'.
    # The first row is filled with values [0, 1, 2, ..., second_string_length]
    previous_row: list[int] = list(range(second_string_length + 1))

    # Rest of the rows
    for first_string_index in range(1, first_string_length + 1):
        # Start the current row with the distance for an empty second string
        current_row: list[int] = [first_string_index]

        # Iterate over each character in the second string
        for second_string_index in range(1, second_string_length + 1):
            if first_string[first_string_index - 1] == second_string[second_string_index - 1]:
                # If characters match, no additional cost
                current_row.append(previous_row[second_string_index - 1])
            else:
                # Minimum cost of insertion, deletion, or substitution
                current_row.append(
                    1 + min(current_row[-1], previous_row[second_string_index], previous_row[second_string_index - 1]))

        # Move to the next row
        previous_row = current_row

    # The last value in the last row is the edit distance
    return previous_row[second_string_length]

class EnvironmentVariableCompleter(Completer):
    def get_completions(self, document, complete_event):
        text = document.text_before_cursor
        if text.startswith('$'):
            # Get the variable name part (text after the '$')
            var_name = text[1:]

            # Suggest all environment variables that start with the typed name
            for env_var in os.environ:
                if env_var.startswith(var_name):
                    yield Completion(
                        f'${env_var}',
                        start_position=-len(text)
                    )

class EnvVarPathCompleter(Completer):
    def get_completions(self, document, complete_event):
        text_before_cursor = document.text_before_cursor
        expanded_text = os.path.expandvars(text_before_cursor)

        # Create a new document for the PathCompleter to use
        expanded_document = Document(
            text=expanded_text, cursor_position=len(expanded_text)
        )

        # Use a standard PathCompleter on our new, temporary document
        path_completer = PathCompleter(expanduser=True)
        yield from path_completer.get_completions(expanded_document, complete_event)


def get_input_from_cli(prompt_txt: str, default_value: str, hide_value = False) -> str:
    """
    Prompts the user for input.
    """
    final_completer = merge_completers([EnvironmentVariableCompleter(), EnvVarPathCompleter()])
    history = FileHistory(os.path.join(os.path.expanduser('~'), '.fivetran_history'))
    if default_value:
        if hide_value:
            default_value_hidden = default_value[0:8] + "********"
            value = prompt(f"{prompt_txt} [Default : {default_value_hidden}]: ",
                           completer=final_completer, history=history, complete_while_typing=False, complete_style='readline_like'
                           ).strip() or default_value
        else:
            value = prompt(f"{prompt_txt} [Default : {default_value}]: ",
                           completer=final_completer, history=history, complete_while_typing=False, complete_style='readline_like'
                           ).strip() or default_value
    else:
        value = prompt(f"{prompt_txt}: ",
                       completer=final_completer, history=history, complete_while_typing=False, complete_style='readline_like'
                       ).strip()

    if not value:
        raise ValueError("Missing required input: Expected a value but received None")
    return os.path.expandvars(value)

def validate_and_load_configuration(project_path, configuration):
    if not configuration:
        print_library_log("no configuration file passed", Logging.Level.INFO)
        return {}

    configuration = os.path.expanduser(configuration)
    json_filepath = os.path.abspath(
        configuration if os.path.isabs(configuration)
        else os.path.join(project_path, configuration)
    )

    if not os.path.exists(json_filepath) or not is_regular_file_or_fifo(json_filepath):
        raise ValueError(
            f"Configuration path is incorrect, cannot find file at the location {json_filepath}"
        )

    try:
        content = safe_read_file(json_filepath)
    except OSError as e:
        raise ValueError(
            str(e) if isinstance(e, TimeoutError)
            else f"Cannot read configuration file at {json_filepath}: {e}"
        ) from e

    try:
        configuration = json.loads(content)
    except json.JSONDecodeError:
        raise ValueError(
            "Configuration must be provided as a JSON file. Please check your input. Reference: "
            "https://fivetran.com/docs/connectors/connector-sdk/detailed-guide#workingwithconfigurationjsonfile"
        )

    if len(configuration) > MAX_CONFIG_FIELDS:
        raise ValueError(
            f"Configuration field count exceeds maximum of {MAX_CONFIG_FIELDS}. Reduce the field count."
        )

    return configuration


def validate_and_load_state(args, state):
    if state:
        json_filepath = os.path.abspath(os.path.join(args.project_path, args.state))
    else:
        json_filepath = os.path.join(args.project_path, "files", "state.json")

    if os.path.exists(json_filepath):
        # Support both regular files and pipes/FIFOs (os.path.isfile returns False for pipes)
        if is_regular_file_or_fifo(json_filepath):
            try:
                content = safe_read_file(json_filepath)
                state = json.loads(content)
            except TimeoutError as e:
                raise ValueError(str(e)) from e
            except OSError as e:
                raise ValueError(
                    f"Cannot read state file at {json_filepath}: {e}") from e
        else:
            raise ValueError(
                f"State path is incorrect, cannot find file at the location {json_filepath}")
    else:
        state = {}
    return state


def reset_local_file_directory(args):
    files_path = os.path.join(args.project_path, OUTPUT_FILES_DIR)
    if args.force:
        confirm = "y"
    else:
        confirm = input(
            "This will delete your current state and `warehouse.db` files. Do you want to continue? (Y/n): ")
    if confirm.lower() != "y":
        print_library_log("reset cancelled")
    else:
        try:
            print_library_log(f"resetting project {args.project_path}", log_icon=Logging.LogIcon.STEP)
            if os.path.exists(files_path) and os.path.isdir(files_path):
                shutil.rmtree(files_path)
            print_library_log("reset successful", log_icon=Logging.LogIcon.SUCCESS)
        except Exception as e:
            print_library_log("reset failed", level=Logging.Level.SEVERE, log_icon=Logging.LogIcon.FAILURE)
            raise e
