# RAG Debugger SDK

**Observability & Debugging Platform for RAG Pipelines**

`ragdebug` allows you to auto-trace every stage of your RAG application and start a comprehensive local dashboard for analysis with a single command.

## Prerequisites

To run the full local RAG Debugger platform, you must have **Docker Desktop** installed and running on your machine.
- [Download and Install Docker Desktop here](https://docs.docker.com/get-docker/)

Once installed and running, you can follow the instructions below.

## Quickstart

1. Install the SDK with the CLI power-ups:
   ```bash
   pip install "ragdebug[cli]"
   ```

2. Start the local RAG Debugger platform:
   ```bash
   ragdebug up
   ```

3. Open the dashboard at [http://localhost:8000](http://localhost:8000)

## Integrating Tracing

Add the `@trace` decorator to your RAG pipeline functions:

```python
from ragdebug import init, trace, Prompt

init(project="my-project")

test_prompt = Prompt(name="QA Prompt", template="Context: {{context}}\n\nQ: {{query}}")

@trace(name="qa_pipeline")
def answer_question(query: str):
    # Your RAG logic here
    return "Answer"

answer_question("What is RAG?")
```

## Advanced CLI Usage

| Command | Description |
|---|---|
| `ragdebug up` | Start all 4 containers (mongo, postgres, redis, platform) |
| `ragdebug up --build` | Force rebuild the platform image |
| `ragdebug down` | Stop all containers |
| `ragdebug status` | Show container status + API health check |
| `ragdebug logs` | Stream container logs |

## Documentation

For full documentation on Prompts, Evaluations, and more, check the UI dashboard after running `ragdebug up`.
