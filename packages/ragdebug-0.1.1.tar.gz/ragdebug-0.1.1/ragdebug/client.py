"""
HTTP client — batches traces and sends them asynchronously.
"""

from __future__ import annotations

import atexit
import logging
import queue
import threading
from typing import Any

import httpx

from ragdebug.config import get_config

logger = logging.getLogger("ragdebug")

_queue: queue.Queue[dict[str, Any]] = queue.Queue()
_flush_thread: threading.Thread | None = None
_shutdown_event = threading.Event()


def _flush_loop() -> None:
    """Background thread that flushes batched traces."""
    cfg = get_config()
    while not _shutdown_event.is_set():
        batch: list[dict] = []
        try:
            # Block up to flush_interval for the first item
            item = _queue.get(timeout=cfg.flush_interval)
            batch.append(item)
        except queue.Empty:
            continue

        # Drain up to batch_size
        while len(batch) < cfg.batch_size:
            try:
                batch.append(_queue.get_nowait())
            except queue.Empty:
                break

        _send_batch(batch)


def _send_batch(batch: list[dict]) -> None:
    """Send a batch of traces to the platform API."""
    cfg = get_config()
    url = f"{cfg.endpoint}/api/v1/traces"
    headers = {"Authorization": f"Bearer {cfg.api_key}"}

    for payload in batch:
        try:
            resp = httpx.post(url, json=payload, headers=headers, timeout=10.0)
            if cfg.debug:
                logger.debug(f"Trace sent: {resp.status_code}")
        except Exception as exc:
            if cfg.debug:
                logger.warning(f"Failed to send trace: {exc}")
            # Silently swallow — SDK errors must never crash the host app


def _sync_prompt(
    project_id: str,
    name: str,
    template: str,
    template_hash: str,
    variables: list[str],
    metadata: dict[str, Any],
) -> int | None:
    """Synchronously sync a prompt with the backend and return its ID."""
    cfg = get_config()
    if not cfg.enabled:
        return None
        
    url = f"{cfg.endpoint}/api/v1/prompts/sync"
    headers = {"Authorization": f"Bearer {cfg.api_key}"}
    payload = {
        "project_id": project_id,
        "name": name,
        "template": template,
        "template_hash": template_hash,
        "variables": variables,
        "metadata": metadata,
    }
    
    try:
        resp = httpx.post(url, json=payload, headers=headers, timeout=5.0)
        resp.raise_for_status()
        return resp.json().get("id")
    except Exception as exc:
        if cfg.debug:
            logger.warning(f"Failed to sync prompt: {exc}")
        return None


def _pull_active_prompt(project_id: str, name: str) -> dict[str, Any] | None:
    """Synchronously pull the active prompt version from the backend."""
    cfg = get_config()
    if not cfg.enabled:
        return None
        
    url = f"{cfg.endpoint}/api/v1/prompts/{name}/active?project_id={project_id}"
    headers = {"Authorization": f"Bearer {cfg.api_key}"}
    
    try:
        resp = httpx.get(url, headers=headers, timeout=5.0)
        resp.raise_for_status()
        return resp.json()
    except Exception as exc:
        if cfg.debug:
            logger.warning(f"Failed to pull active prompt: {exc}")
        return None

def _trigger_eval(
    project_id: str,
    name: str,
    prompt_version_id: int | None,
    test_cases: list[dict[str, Any]],
) -> dict[str, Any] | None:
    """Synchronously trigger an evaluation run on the backend."""
    cfg = get_config()
    if not cfg.enabled:
        return None
        
    url = f"{cfg.endpoint}/api/v1/evaluations"
    headers = {"Authorization": f"Bearer {cfg.api_key}"}
    payload = {
        "project_id": project_id,
        "name": name,
        "prompt_version_id": prompt_version_id,
        "test_cases": test_cases,
    }
    
    try:
        resp = httpx.post(url, json=payload, headers=headers, timeout=10.0)
        resp.raise_for_status()
        return resp.json()
    except Exception as exc:
        if cfg.debug:
            logger.warning(f"Failed to trigger evaluation: {exc}")
        return None


def enqueue_trace(trace_dict: dict[str, Any]) -> None:
    """Add a trace to the outgoing queue."""
    cfg = get_config()
    if not cfg.enabled:
        return

    _queue.put(trace_dict)
    _ensure_flush_thread()


def _ensure_flush_thread() -> None:
    """Lazily start the background flush thread."""
    global _flush_thread
    if _flush_thread is None or not _flush_thread.is_alive():
        _flush_thread = threading.Thread(target=_flush_loop, daemon=True, name="ragdebug-flush")
        _flush_thread.start()


def shutdown() -> None:
    """Flush remaining traces and stop the background thread."""
    _shutdown_event.set()
    # Drain remaining items
    remaining: list[dict] = []
    while not _queue.empty():
        try:
            remaining.append(_queue.get_nowait())
        except queue.Empty:
            break
    if remaining:
        _send_batch(remaining)


atexit.register(shutdown)
