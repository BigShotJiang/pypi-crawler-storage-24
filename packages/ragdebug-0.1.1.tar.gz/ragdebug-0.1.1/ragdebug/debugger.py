"""
RAGDebugger wrapper for programmatic trace control.
"""

from typing import Any, Optional
from ragdebug.config import set_config
from ragdebug.tracer import trace
from ragdebug.spans import span

class RAGDebugger:
    """
    Programmatic entry point for the RAG Debugger SDK.
    """
    def __init__(self, api_url: str = "http://localhost:8000", project_id: str = "default", api_key: str = "default_key"):
        set_config(endpoint=api_url, project=project_id, api_key=api_key)
        self.project_id = project_id
        self.api_key = api_key
    
    def trace(self, query: str):
        """Context manager/decorator for a trace."""
        return trace(name=query)
    
    def span(self, name: str, span_type: str = "general"):
        """Context manager for a span."""
        return span(name=name, span_type=span_type)
