"""
ragdebug CLI — manage the self-hosted platform via Docker Compose.

Usage:
    ragdebug up       Start the platform (MongoDB, PostgreSQL, Redis, Backend+Dashboard)
    ragdebug down     Stop the platform
    ragdebug status   Show container status and health check
"""

from __future__ import annotations

import importlib.resources
import shutil
import subprocess
import sys

import click
import httpx


def _get_compose_file() -> str:
    """Resolve the path to the bundled docker-compose.yml."""
    ref = importlib.resources.files("ragdebug") / "platform" / "docker-compose.yml"
    with importlib.resources.as_file(ref) as path:
        return str(path)


def _docker_available() -> bool:
    """Check if Docker and Docker Compose are available."""
    if shutil.which("docker") is None:
        click.secho("✗ Docker not found. Please install Docker Desktop:", fg="red")
        click.echo("  https://docs.docker.com/get-docker/")
        return False
    
    result = subprocess.run(
        ["docker", "compose", "version"],
        capture_output=True, text=True,
    )
    if result.returncode != 0:
        click.secho("✗ Docker Compose not found. Please install Docker Desktop.", fg="red")
        return False
    
    return True


def _run_compose(args: list[str], compose_file: str) -> int:
    """Run a docker compose command with the bundled compose file."""
    cmd = ["docker", "compose", "-f", compose_file, "-p", "ragdebug"] + args
    click.secho(f"  → {' '.join(cmd)}", fg="bright_black")
    result = subprocess.run(cmd)
    return result.returncode


@click.group()
@click.version_option(package_name="ragdebug")
def cli():
    """ragdebug — Observability & Debugging Platform for RAG Pipelines."""
    pass


@cli.command()
@click.option("--build", is_flag=True, help="Force rebuild the platform image.")
@click.option(
    "--detach/--no-detach", default=True,
    help="Run containers in the background (default: detach)."
)
def up(build: bool, detach: bool):
    """Start the ragdebug platform (databases + backend + dashboard)."""
    if not _docker_available():
        sys.exit(1)

    compose_file = _get_compose_file()
    click.secho("\n🚀 Starting ragdebug platform...\n", fg="cyan", bold=True)

    args = ["up"]
    if detach:
        args.append("-d")
    if build:
        args.append("--build")

    rc = _run_compose(args, compose_file)

    if rc == 0 and detach:
        click.echo()
        click.secho("✓ Platform is starting up!", fg="green", bold=True)
        click.echo()
        click.echo("  Dashboard:  http://localhost:8000")
        click.echo("  API:        http://localhost:8000/api/v1/")
        click.echo("  Health:     http://localhost:8000/health")
        click.echo()
        click.secho("  Run 'ragdebug status' to check readiness.", fg="bright_black")
        click.secho("  Run 'ragdebug down' to stop.\n", fg="bright_black")
    
    sys.exit(rc)


@cli.command()
@click.option(
    "--volumes", is_flag=True,
    help="Also remove persistent data volumes (MongoDB, PostgreSQL)."
)
def down(volumes: bool):
    """Stop the ragdebug platform."""
    if not _docker_available():
        sys.exit(1)

    compose_file = _get_compose_file()
    click.secho("\n⏹  Stopping ragdebug platform...\n", fg="yellow", bold=True)

    args = ["down"]
    if volumes:
        args.append("-v")

    rc = _run_compose(args, compose_file)

    if rc == 0:
        msg = "✓ Platform stopped."
        if volumes:
            msg += " All data volumes removed."
        click.secho(msg, fg="green", bold=True)
        click.echo()

    sys.exit(rc)


@cli.command()
def status():
    """Show platform container status and health check."""
    if not _docker_available():
        sys.exit(1)

    compose_file = _get_compose_file()
    click.secho("\n📊 ragdebug platform status\n", fg="cyan", bold=True)

    _run_compose(["ps"], compose_file)
    click.echo()

    # Health check
    try:
        resp = httpx.get("http://localhost:8000/health", timeout=3.0)
        data = resp.json()
        click.secho(
            f"  API Health: ✓ {data.get('status', 'ok')} (v{data.get('version', '?')})",
            fg="green",
        )
    except Exception:
        click.secho("  API Health: ✗ Backend not reachable", fg="red")
    
    click.echo()


@cli.command()
def logs():
    """Stream logs from the platform containers."""
    if not _docker_available():
        sys.exit(1)

    compose_file = _get_compose_file()
    _run_compose(["logs", "-f", "--tail", "100"], compose_file)
