"""
@trace decorator — wraps a RAG pipeline function to capture the full trace.
"""

from __future__ import annotations

import asyncio
import functools
import inspect
import time
import uuid
from typing import Any, Callable

from ragdebug.client import enqueue_trace
from ragdebug.config import get_config
from ragdebug.models import SpanData, TraceData
from ragdebug.prompt import get_current_prompt_context

# Thread-local to hold the current trace's spans
import threading

_trace_local = threading.local()


def _get_trace_spans() -> list[SpanData]:
    if not hasattr(_trace_local, "spans"):
        _trace_local.spans = []
    return _trace_local.spans


def _register_span(span_data: SpanData) -> None:
    """Called when a top-level span finishes to register it in the current trace."""
    spans = _get_trace_spans()
    spans.append(span_data)


class TraceContext:
    def __init__(self, name: str, cfg: SDKConfig):
        self.name = name
        self.cfg = cfg
        self.start_time = 0
        self.trace_id = str(uuid.uuid4())
        self.spans = []
        self.input_data = {}
        self.output_data = {}
        self.status = "success"

    def __enter__(self):
        _trace_local.spans = []
        self.start_time = time.perf_counter()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        elapsed_ms = round((time.perf_counter() - self.start_time) * 1000, 2)
        if exc_type:
            self.status = "error"
        
        trace_data = TraceData(
            project_id=self.cfg.project,
            prompt_version_id=get_current_prompt_context(),
            input=self.input_data or {"query": self.name},
            output=self.output_data,
            spans=list(_trace_local.spans),
            duration_ms=elapsed_ms,
            status=self.status,
            metadata={"error": str(exc_val)} if exc_val else {},
        )
        enqueue_trace(trace_data.to_dict())
        _trace_local.spans = []

    def span(self, name: str, span_type: str = "general"):
        from ragdebug.spans import span
        return span(name=name, span_type=span_type)

    def set_input(self, **kwargs):
        self.input_data.update(kwargs)

    def set_output(self, **kwargs):
        self.output_data.update(kwargs)

    def __call__(self, func: Callable):
        trace_name = self.name or func.__name__
        if asyncio.iscoroutinefunction(func):
            @functools.wraps(func)
            async def async_wrapper(*args, **kwargs):
                if not self.cfg.enabled: return await func(*args, **kwargs)
                with TraceContext(trace_name, self.cfg) as ctx:
                    query = str(args[0]) if args else str(kwargs.get("query", ""))
                    ctx.set_input(query=query)
                    res = await func(*args, **kwargs)
                    ctx.set_output(response=str(res))
                    return res
            return async_wrapper
        else:
            @functools.wraps(func)
            def sync_wrapper(*args, **kwargs):
                if not self.cfg.enabled: return func(*args, **kwargs)
                with TraceContext(trace_name, self.cfg) as ctx:
                    query = str(args[0]) if args else str(kwargs.get("query", ""))
                    ctx.set_input(query=query)
                    res = func(*args, **kwargs)
                    ctx.set_output(response=str(res))
                    return res
            return sync_wrapper

def trace(func: Callable | None = None, *, name: str | None = None):
    """
    Decorator OR Context Manager to capture a full RAG pipeline trace.
    """
    cfg = get_config()
    if func is None:
        # If it's not a function, it's a context manager call: with trace(name="..."):
        # Also supports @trace(name="...") by implementing __call__ on TraceContext
        return TraceContext(name or "manual_trace", cfg)

    # It's a direct decorator: @trace
    return TraceContext(name or func.__name__, cfg)(func)

