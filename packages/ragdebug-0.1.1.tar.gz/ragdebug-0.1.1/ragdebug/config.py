"""
SDK configuration.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class SDKConfig:
    """Global SDK configuration — set via ragdebug.init()."""
    api_key: str = ""
    project: str = ""
    endpoint: str = "http://localhost:8000"
    flush_interval: float = 5.0          # seconds
    batch_size: int = 10
    enabled: bool = True
    debug: bool = False


# Singleton instance
_config = SDKConfig()


def get_config() -> SDKConfig:
    return _config


def set_config(**kwargs) -> None:
    for k, v in kwargs.items():
        if hasattr(_config, k):
            setattr(_config, k, v)
