"""
Evaluation trigger from the SDK.
"""

from __future__ import annotations

from typing import Any

from ragdebug.client import _trigger_eval
from ragdebug.config import get_config
from ragdebug.prompt import Prompt


def evaluate(
    name: str,
    test_cases: list[dict[str, Any]],
    prompt: Prompt | None = None,
    project_id: str | None = None,
) -> dict[str, Any] | None:
    """
    Trigger an automated evaluation run on the RAG Debugger platform.
    
    Args:
        name: Name for this evaluation run (e.g., "Nightly CI Eval")
        test_cases: List of dictionaries, each containing at least 'input_query' 
                    and optionally 'expected_output'.
        prompt: An optional Prompt instance. If provided, the evaluation will be
                linked to this prompt's active version.
        project_id: Override the default project ID.
        
    Returns:
        The evaluation run definition including its ID and status.
    """
    cfg = get_config()
    pid = project_id or cfg.project
    
    prompt_version_id = None
    if prompt:
        prompt_version_id = getattr(prompt, "version_id", None)
        
    # Ensure test cases are formatted correctly
    formatted_cases = []
    for tc in test_cases:
        if "input_query" not in tc:
            if "query" in tc:
                tc["input_query"] = tc.pop("query")
            else:
                raise ValueError("Each test case must contain an 'input_query' key.")
        
        # Ensure we don't send extra junk that the backend doesn't expect
        formatted_cases.append({
            "input_query": tc["input_query"],
            "expected_output": tc.get("expected_output", ""),
        })

    return _trigger_eval(
        project_id=pid,
        name=name,
        prompt_version_id=prompt_version_id,
        test_cases=formatted_cases,
    )
