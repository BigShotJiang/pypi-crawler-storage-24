"""
Prompt management via the SDK.
"""

from __future__ import annotations

import hashlib
import json
import threading
from typing import Any

from ragdebug.client import _sync_prompt, _pull_active_prompt

# Thread-local storage to associate physical traces with the prompt executed
_prompt_context = threading.local()

def get_current_prompt_context() -> int | None:
    """Retrieve the active prompt_version_id for the current thread."""
    return getattr(_prompt_context, "prompt_version_id", None)

def set_current_prompt_context(version_id: int | None) -> None:
    """Set the active prompt_version_id for the current thread."""
    _prompt_context.prompt_version_id = version_id


class Prompt:
    """
    A Prompt Template that automatically syncs to the RAG Debugger platform.
    """
    def __init__(
        self,
        name: str,
        template: str,
        project_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ):
        self.name = name
        self.template = template
        self.project_id = project_id or "default"
        self.metadata = metadata or {}
        
        # Extract variables simple regex or just string match
        import re
        self.variables = list(set(re.findall(r"\{\{(\w+)\}\}", template)))
        
        # Compute SHA-256 hash of the template
        self.template_hash = hashlib.sha256(template.encode("utf-8")).hexdigest()
        
        # Sync with backend immediately
        self.version_id = self._sync()
        
    def _sync(self) -> int | None:
        """Sync this prompt with the platform and return its version ID."""
        return _sync_prompt(
            project_id=self.project_id,
            name=self.name,
            template=self.template,
            template_hash=self.template_hash,
            variables=self.variables,
            metadata=self.metadata,
        )

    def format(self, **kwargs: Any) -> str:
        """
        Format the prompt with variables.
        Also temporarily sets the thread-local prompt context so any
        @trace executed within this block can link to this prompt_version_id.
        """
        rendered = self.template
        for k, v in kwargs.items():
            rendered = rendered.replace(f"{{{{{k}}}}}", str(v))
            
        # Set the prompt context before returning
        set_current_prompt_context(self.version_id)
        return rendered

    @classmethod
    def pull(cls, name: str, project_id: str = "default") -> "Prompt":
        """
        Pull the currently active version of a prompt from the platform.
        """
        data = _pull_active_prompt(project_id, name)
        if not data:
            raise ValueError(f"No active prompt found for '{name}' in project '{project_id}'")
            
        # Create an instance that won't re-sync because we already have the ID
        p = cls.__new__(cls)
        p.name = data["name"]
        p.template = data["template"]
        p.project_id = data["project_id"]
        p.metadata = data.get("metadata", {})
        p.variables = data.get("variables", [])
        p.template_hash = None # Skip hash check
        p.version_id = data["id"]
        return p
