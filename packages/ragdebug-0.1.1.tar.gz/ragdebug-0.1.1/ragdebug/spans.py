"""
Span context manager — captures timing and I/O for a pipeline stage.
"""

from __future__ import annotations

import time
import uuid
from contextlib import contextmanager
from typing import Any, Generator

from ragdebug.models import SpanData

# Thread-local span stack (supports nested spans)
import threading

_span_stack: threading.local = threading.local()


def _get_stack() -> list[SpanData]:
    if not hasattr(_span_stack, "stack"):
        _span_stack.stack = []
    return _span_stack.stack


@contextmanager
def span(name: str, span_type: str = "general") -> Generator[SpanData, None, None]:
    """
    Context manager that records a named span.
    """
    stack = _get_stack()
    span_data = SpanData(
        span_id=f"span_{uuid.uuid4().hex[:8]}",
        name=name,
        span_type=span_type
    )

    span_data._abs_start = time.perf_counter()  # type: ignore[attr-defined]
    stack.append(span_data)

    try:
        yield span_data
    except Exception as exc:
        span_data.status = "error"
        span_data.metadata["error"] = str(exc)
        raise
    finally:
        elapsed = time.perf_counter() - span_data._abs_start  # type: ignore[attr-defined]
        span_data.duration_ms = round(elapsed * 1000, 2)
        stack.pop()

        if stack:
            # Nest under parent
            stack[-1].children.append(span_data)
        else:
            # Register as top-level span for the current trace
            from ragdebug.tracer import _register_span
            _register_span(span_data)


def reset_spans() -> None:
    _span_stack.stack = []

