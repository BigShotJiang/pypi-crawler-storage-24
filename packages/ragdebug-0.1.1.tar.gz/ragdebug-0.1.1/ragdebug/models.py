"""
Lightweight data models for trace payloads (SDK-side).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any


@dataclass
class SpanData:
    span_id: str
    name: str
    span_type: str = "general"
    start_time_ms: float = 0
    duration_ms: float = 0
    input: dict = field(default_factory=dict)
    output: dict = field(default_factory=dict)
    metadata: dict = field(default_factory=dict)
    status: str = "success"
    children: list[SpanData] = field(default_factory=list)

    def set_input(self, **kwargs):
        self.input.update(kwargs)

    def set_output(self, **kwargs):
        self.output.update(kwargs)

    def to_dict(self) -> dict:
        return {
            "span_id": self.span_id,
            "name": self.name,
            "span_type": self.span_type,
            "start_time_ms": self.start_time_ms,
            "duration_ms": self.duration_ms,
            "input": self.input,
            "output": self.output,
            "metadata": self.metadata,
            "status": self.status,
            "children": [c.to_dict() for c in self.children],
        }


@dataclass
class TraceData:
    """Full trace payload to be sent to the platform."""
    project_id: str = ""
    prompt_version_id: int | None = None
    input: dict[str, Any] = field(default_factory=dict)
    output: dict[str, Any] = field(default_factory=dict)
    spans: list[SpanData] = field(default_factory=list)
    duration_ms: float = 0
    status: str = "success"
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict:
        d = {
            "project_id": self.project_id,
            "input": self.input,
            "output": self.output,
            "spans": [s.to_dict() for s in self.spans],
            "duration_ms": self.duration_ms,
            "status": self.status,
            "metadata": self.metadata,
        }
        if self.prompt_version_id is not None:
            d["prompt_version_id"] = self.prompt_version_id
        return d
