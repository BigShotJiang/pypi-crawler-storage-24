"""
ragdebug — Observability SDK for RAG pipelines.

Usage:
    from ragdebug import init, trace, span

    init(api_key="rdb_xxx", project="my-rag-app")

    @trace
    def rag_pipeline(query: str) -> str:
        with span("embedding"):
            vector = embed(query)
        with span("retrieval"):
            docs = search(vector)
        with span("llm_call"):
            response = llm(docs, query)
        return response
"""

import logging

from ragdebug.config import set_config
from ragdebug.tracer import trace
from ragdebug.spans import span
from ragdebug.prompt import Prompt
from ragdebug.evaluator import evaluate
from ragdebug.debugger import RAGDebugger

logger = logging.getLogger("ragdebug")


def _check_backend(endpoint: str) -> None:
    """Non-blocking health check — warns if the backend is unreachable."""
    try:
        import httpx
        resp = httpx.get(f"{endpoint}/health", timeout=2.0)
        if resp.status_code == 200:
            logger.debug(f"Backend reachable at {endpoint}")
        else:
            logger.warning(
                f"⚠ ragdebug backend returned status {resp.status_code}. "
                f"Dashboard may not be working."
            )
    except Exception:
        print(
            f"\n⚠  ragdebug backend not reachable at {endpoint}\n"
            f"   Run 'ragdebug up' to start the platform.\n"
            f"   Or set enabled=False to silence this warning.\n"
        )


def init(
    api_key: str = "",
    project: str = "",
    endpoint: str = "http://localhost:8000",
    enabled: bool = True,
    debug: bool = False,
    flush_interval: float = 5.0,
    batch_size: int = 10,
) -> None:
    """
    Initialize the ragdebug SDK.

    Args:
        api_key: API key for authentication (from the RAG Debugger dashboard).
        project: Project identifier (e.g. "my-rag-app").
        endpoint: RAG Debugger platform URL (default: localhost).
        enabled: Set to False to disable tracing without removing decorators.
        debug: Enable debug logging.
        flush_interval: Seconds between flush cycles (default: 5).
        batch_size: Max traces per flush batch (default: 10).
    """
    set_config(
        api_key=api_key,
        project=project,
        endpoint=endpoint,
        enabled=enabled,
        debug=debug,
        flush_interval=flush_interval,
        batch_size=batch_size,
    )

    if enabled:
        _check_backend(endpoint)


__all__ = ["init", "trace", "span", "Prompt", "evaluate"]
__version__ = "0.1.0"

