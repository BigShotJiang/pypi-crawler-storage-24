from cusrl.hook import player

from .advantage import (
    AdvantageNormalization,
    AdvantageReduction,
)
from .amp import AdversarialMotionPrior
from .condition import ConditionalObjectiveActivation
from .distillation import (
    PolicyDistillation,
    PolicyDistillationLoss,
)
from .empty_cuda_cache import EmptyCudaCache
from .environment_spec import (
    DynamicEnvironmentSpecOverride,
    EnvironmentSpecOverride,
)
from .estimation import StateEstimation
from .gae import GeneralizedAdvantageEstimation
from .gradient import GradientClipping
from .initialization import ModuleInitialization
from .lr_schedule import (
    AdaptiveLRSchedule,
    MiniBatchWiseLRSchedule,
    ThresholdLRSchedule,
)
from .observation import (
    ObservationNanToNum,
    ObservationNormalization,
)
from .on_policy import (
    OnPolicyBufferCapacitySchedule,
    OnPolicyPreparation,
    OnPolicyStatistics,
)
from .ppo import (
    EntropyLoss,
    PpoSurrogateLoss,
)
from .representation import (
    NextStatePrediction,
    ReturnPrediction,
    StatePrediction,
)
from .reward import RewardShaping
from .rnd import RandomNetworkDistillation
from .schedule import (
    HookActivationSchedule,
    HookParameterSchedule,
)
from .smoothness import ActionSmoothnessLoss
from .symmetry import (
    SymmetricArchitecture,
    SymmetricDataAugmentation,
    SymmetryLoss,
)
from .value import (
    ValueComputation,
    ValueLoss,
)

__all__ = [
    "player",
    "ActionSmoothnessLoss",
    "AdaptiveLRSchedule",
    "AdvantageNormalization",
    "AdvantageReduction",
    "AdversarialMotionPrior",
    "ConditionalObjectiveActivation",
    "DynamicEnvironmentSpecOverride",
    "EmptyCudaCache",
    "EntropyLoss",
    "EnvironmentSpecOverride",
    "GeneralizedAdvantageEstimation",
    "GradientClipping",
    "HookActivationSchedule",
    "HookParameterSchedule",
    "MiniBatchWiseLRSchedule",
    "ModuleInitialization",
    "NextStatePrediction",
    "ObservationNanToNum",
    "ObservationNormalization",
    "OnPolicyBufferCapacitySchedule",
    "OnPolicyPreparation",
    "OnPolicyStatistics",
    "PolicyDistillation",
    "PolicyDistillationLoss",
    "PpoSurrogateLoss",
    "RandomNetworkDistillation",
    "ReturnPrediction",
    "RewardShaping",
    "StateEstimation",
    "StatePrediction",
    "SymmetricArchitecture",
    "SymmetricDataAugmentation",
    "SymmetryLoss",
    "ThresholdLRSchedule",
    "ValueComputation",
    "ValueLoss",
]
