# mansion_gym/mansion_env.py

import os
import json
import gymnasium as gym
from copy import deepcopy
from ai2thor.controller import Controller
from typing import Any, Dict, Mapping, Optional, Tuple, Union

# ---- Utility modules we separated ----
from .gym_utils.controller_utils import setup_scene, reset_scene
from .gym_utils.navigation_utils import (
    update_edge_states,
    teleport_to_room,
    get_current_room,
    visualize_landmarks,
    visualize_room_graph,
)
from .gym_utils.geometry_utils import (
    get_room_polygons,
)
from .gym_utils.floor_utils import update_floor
from .gym_utils.camera_utils import capture_landmark_views

from .gym_skills import (
    call_elevator,
    go_near_object,
    goto_landmark,
    manipulate_door,
    move_to,
    pickup,
    take_stairs,
    use_elevator,
    putobject,
)


class MansionGym(gym.Env):
    """
    Clean modular version of the MansionGym environment.
    Only high-level env API + floor/object-state logic stays here.
    """

    def __init__(self, building_dir, initial_floor=1, max_steps=1000, save_dir="assets", capture_panoramas=False):
        super(MansionGym, self).__init__()

        # ---- Load floors ----
        # MansionWorld dataset uses floor_1.json, floor_2.json, ... naming
        self.floor_jsons = []
        for i in range(1, 100):
            floor_path = os.path.join(building_dir, f"floor_{i}.json")
            if os.path.exists(floor_path):
                print(f"[MansionGym] Loading {floor_path} as Floor {i}")
                with open(floor_path, "r") as f:
                    self.floor_jsons.append(json.load(f))
            else:
                break

        if not self.floor_jsons:
            # Fallback: sort all .json files in the directory
            files = sorted([f for f in os.listdir(building_dir) if f.endswith(".json")])
            self.floor_jsons = [json.load(open(os.path.join(building_dir, f))) for f in files]

        self.max_floor = len(self.floor_jsons)
        self.current_floor = initial_floor
        self.max_steps = max_steps

        # ---- Save dir for debug, panoramas, graphs ----
        self.save_dir = os.path.join(building_dir, save_dir)

        # ---- Controller / scene placeholders ----
        self.controller: Controller | None = None
        self.cur_json = None

        # ---- Room landmarks and door graph ----
        self.landmarks = {}
        self.room_graph = set()
        self.graph = None
        self.edge_doors = {}
        self.open_space_edges = set()

        # ---- Set up first scene ----
        setup_scene(self, change_floor=False)

        # ---- Standard Gymnasium reset ----
        self.reset()

        # ---- Optionally capture per-room panoramas ----
        # Disabled by default — rendering all floors on first load is slow.
        # Enable with: MansionGym(..., capture_panoramas=True)
        if capture_panoramas:
            os.makedirs(self.save_dir, exist_ok=True)
            capture_landmark_views(self, height_offset=0.5)
        
        self.skill_registry = {
            "MoveTo": move_to.step,
            "GoNearObject": go_near_object.step,
            "OpenDoor": manipulate_door.step,
            "CloseDoor": manipulate_door.step,
            "PickupObject": pickup.step,
            "GoToLandmark": goto_landmark.step,
            "CallElevator": call_elevator.step,
            "TakeStairs": take_stairs.step,
            "UseElevator": use_elevator.step,
            "PutObject": putobject.step,
        }

    # ---------------------------------------------------------
    # Gym reset
    # ---------------------------------------------------------
    def reset(self, *, seed=None, options=None, skip_reset=False):
        super().reset(seed=seed)
        self.steps = 0

        # ---- Object states ----
        self.saved_object_states = {f_num: {} for f_num in range(1, self.max_floor + 1)}
        self.held_object = None
        self.held_object_cur_state= None
        self.recepted_objs= None

        # Reset scene using utility function
        reset_scene(self, skip_reset=skip_reset)

        update_edge_states(self)

        obs = self.get_observation()
        self.agent_pos= obs.metadata["agent"]["position"]
        self.agent_rot= obs.metadata["agent"]["rotation"]
        
        return obs, {}

    # ---------------------------------------------------------
    # Gym step
    # ---------------------------------------------------------
    def _parse_ai2thor_action(self, action: Optional[Union[str, Mapping[str, Any]]], kwargs: Dict[str, Any]) -> Tuple[str, Dict[str, Any]]:
        """
        Accepts ONLY AI2-THOR-style inputs:
        - env.step(action="MoveAhead", moveMagnitude=0.25)
        - env.step(dict(action="MoveAhead", moveMagnitude=0.25))
        """
        # Case A: env.step(dict(action="...", ...))
        if isinstance(action, Mapping):
            if "action" not in action or not isinstance(action["action"], str):
                raise ValueError(
                    "Action dict must be AI2-THOR style: {'action': <str>, ...}. "
                    "Legacy {'MoveAhead': {...}} is not supported."
                )
            act_name = action["action"]
            params = {k: v for k, v in action.items() if k != "action"}
            params.update(kwargs)
            return act_name, params

        # Case B: env.step(action="MoveAhead", ...)
        if isinstance(action, str):
            return action, dict(kwargs)

        # Case C: env.step(action="MoveAhead", ...) with action passed via kwargs only
        if action is None and "action" in kwargs:
            act_name = kwargs.pop("action")
            if not isinstance(act_name, str):
                raise TypeError("'action' must be a string.")
            return act_name, dict(kwargs)

        raise TypeError(
            "Unsupported action input. Use env.step(action='MoveAhead', ...) "
            "or env.step({'action': 'MoveAhead', ...})."
        )


    _INFRASTRUCTURE_KEYWORDS = ("stair", "elevator")

    @staticmethod
    def _is_infrastructure(object_id: str) -> bool:
        low = object_id.lower()
        return any(kw in low for kw in MansionGym._INFRASTRUCTURE_KEYWORDS)

    def step(self, action=None, **kwargs):
        act_name, params = self._parse_ai2thor_action(action, kwargs)

        # Guard: block raw PickupObject on infrastructure assets
        if act_name == "PickupObject":
            obj_id = params.get("objectId", "")
            if self._is_infrastructure(obj_id):
                info = {"lastActionSuccess": False,
                        "errorMessage": f"'{obj_id}' is scene infrastructure (stair/elevator) and cannot be picked up."}
                obs = self.get_observation()
                return obs, 0.0, self.steps >= self.max_steps, False, info
                    
        # --- dispatch (custom skills OR raw ai2thor actions) ---
        if act_name in self.skill_registry:
            # We pass skill_name explicitly so shared skills (Open/Close) know the context
            success, msg = self.skill_registry[act_name](self, skill_name=act_name, **params)
            info = {"lastActionSuccess": success, "errorMessage": msg}
        else:
            # Raw AI2-THOR passthrough (matches controller.step(action="Teleport", position=...))
            event = self.controller.step(action=act_name, **params)
            info = {
                "lastActionSuccess": event.metadata.get("lastActionSuccess", False),
                "errorMessage": event.metadata.get("errorMessage", ""),
            }

        # --- sync held_object state ---
        self.held_object_cur_state = None
        if self.held_object is not None:
            matches = [
                obj for obj in self.get_observation().metadata["objects"]
                if obj["objectId"] == self.held_object["id"]
            ]
            if matches:
                self.held_object_cur_state = matches[0]
                if not self.held_object_cur_state["isPickedUp"]:
                    self.held_object = None
                    self.held_object_cur_state = None
            else:
                # Object not present in current scene (e.g. floor-switch pickup failed)
                self.held_object = None
                self.held_object_cur_state = None

        if self.held_object is not None and info["lastActionSuccess"] and ("move" in act_name.lower() or "rotate" in act_name.lower() or "look" in act_name.lower()):
            event= self.controller.step(action="MoveHeldObject", ahead=0.05, up=-0.4, forceVisible=False)

        obs = self.get_observation()
        self.agent_pos= obs.metadata["agent"]["position"]
        self.agent_rot= obs.metadata["agent"]["rotation"]
        
        rew = 0.0
        self.steps += 1
        done = self.steps >= self.max_steps
        
        self.record_object_states()

        return obs, rew, done, False, info
    

    def update_floor(self, target_floor):
        return update_floor(self, target_floor)
    
    def update_edge_states(self):
        return update_edge_states(self)

    # ---------------------------------------------------------
    # Object state recording (kept in env)
    # ---------------------------------------------------------
    def record_object_states(self):
        self.saved_object_states[self.current_floor]= deepcopy(self.get_observation().metadata["objects"])
        # write to a file for debugging
        os.makedirs(self.save_dir, exist_ok=True)
        with open(os.path.join(self.save_dir, f"floor_{self.current_floor}_object_states.json"), "w") as f:
            json.dump(self.saved_object_states[self.current_floor], f, indent=4)
        
            
    # ---------------------------------------------------------
    def close(self):
        if self.controller is not None:
            self.controller.stop()
  
    def get_observation(self):
        return self.controller.last_event
    
    def get_visible_objects(self):
        return [ obj for obj in self.get_observation().metadata["objects"] if obj["visible"] ]

    def get_current_floor(self):
        return self.current_floor

    
    # ---------------------------------------------------------
    # Wrapper utility functions
    # ---------------------------------------------------------
    def get_current_room(self):
        return get_current_room(self)

    def visualize_landmarks(self, filename="landmarks.png"):
        return visualize_landmarks(self, filename)

    def visualize_room_graph(self, filename="room_graph.png"):
        return visualize_room_graph(self, filename)

    def get_room_polygons(self):
        return get_room_polygons(self.cur_json)


    # ---------------------------------------------------------
    
    def _teleport_to_room(self, target_room):
        return teleport_to_room(self, target_room, offset= 0.5)

    def _capture_landmark_views(self, height_offset=0.5):
        return capture_landmark_views(self, height_offset)