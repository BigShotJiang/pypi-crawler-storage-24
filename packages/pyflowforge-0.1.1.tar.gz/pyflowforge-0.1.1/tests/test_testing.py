"""Tests for the testing module (scenario auto-tests)."""

import textwrap
from pathlib import Path

import pytest
from flowforge import Bot, TestRunResult
from flowforge.testing import (
    load_test_file,
    run_tests,
    format_results,
    _check_response,
    _check_context,
)

FIXTURES = Path(__file__).parent / "fixtures"

SIMPLE_SCENARIO = textwrap.dedent("""\
    scenario:
      name: test_bot
      initial_state: start

    intents:
      ask_price:
        - "how much does it cost"
        - "what is the price"
      greeting:
        - "hello"
        - "hi"

    states:
      start:
        responses:
          - "Hello! Ask about prices or say help."
        auto_transitions:
          - target: price_info
            when:
              - type: intent
                value: ask_price
          - target: help
            when:
              - type: regex
                value: 'help|support'

      price_info:
        run:
          - action: get_price
        responses:
          - "Price: {price} USD. Want to order?"
        response_transitions:
          - target: confirm
            when:
              - type: regex
                value: 'yes|sure|ok'
          - target: start
            when:
              - type: regex
                value: 'no|back'

      confirm:
        responses:
          - "Order confirmed!"
        auto_transitions:
          - target: start
            when:
              - type: intent
                value: '*'

      help:
        responses:
          - "I can help with pricing."
        auto_transitions:
          - target: start
            when:
              - type: intent
                value: '*'
""")


def _make_bot():
    bot = Bot.from_string(SIMPLE_SCENARIO)

    @bot.action("get_price")
    def get_price(ctx):
        return {"price": 100}

    return bot


# -- Unit tests for helpers --

class TestCheckResponse:
    def test_substring_match(self):
        assert _check_response("Hello", "Hello, world!")

    def test_substring_no_match(self):
        assert not _check_response("Goodbye", "Hello, world!")

    def test_regex_match(self):
        assert _check_response(r"/Price: \d+ USD/", "Price: 100 USD.")

    def test_regex_no_match(self):
        assert not _check_response(r"/Price: \d+ EUR/", "Price: 100 USD.")

    def test_single_slash_not_regex(self):
        # Single slash "/" is not treated as regex
        assert _check_response("/", "a/b")


class TestCheckContext:
    def test_match(self):
        assert _check_context({"price": 100}, {"price": 100}) is None

    def test_mismatch(self):
        err = _check_context({"price": 100}, {"price": 200})
        assert err is not None
        assert "price" in err

    def test_missing_key(self):
        err = _check_context({"price": 100}, {})
        assert err is not None

    def test_numeric_coercion(self):
        assert _check_context({"price": 100}, {"price": 100.0}) is None


# -- Load tests --

class TestLoadTestFile:
    def test_load_simple_format(self, tmp_path):
        f = tmp_path / "test.qa.yaml"
        f.write_text(textwrap.dedent("""\
            tests:
              greeting:
                - "hello"
                - "hi"
              pricing:
                - "how much"
        """))
        data = load_test_file(f)
        assert len(data["conversations"]) == 3
        # Each phrase becomes a single-step conversation
        assert data["conversations"][0]["steps"][0]["state"] == "greeting"

    def test_load_extended_format(self, tmp_path):
        f = tmp_path / "test.qa.yaml"
        f.write_text(textwrap.dedent("""\
            conversations:
              - name: "Flow A"
                steps:
                  - user: "hello"
                    state: start
                  - user: "buy"
                    state: checkout
        """))
        data = load_test_file(f)
        assert len(data["conversations"]) == 1
        assert len(data["conversations"][0]["steps"]) == 2

    def test_load_mixed_format(self, tmp_path):
        f = tmp_path / "test.qa.yaml"
        f.write_text(textwrap.dedent("""\
            tests:
              greeting:
                - "hello"
            conversations:
              - name: "Flow A"
                steps:
                  - user: "buy"
                    state: checkout
        """))
        data = load_test_file(f)
        assert len(data["conversations"]) == 2

    def test_load_with_setup(self, tmp_path):
        f = tmp_path / "test.qa.yaml"
        f.write_text(textwrap.dedent("""\
            setup:
              actions:
                get_price:
                  price: 42
            tests:
              pricing:
                - "how much"
        """))
        data = load_test_file(f)
        assert data["setup"]["actions"]["get_price"]["price"] == 42


# -- Integration tests --

class TestRunTests:
    def test_simple_format_passing(self):
        bot = _make_bot()
        data = load_test_file(FIXTURES / "test_simple.qa.yaml")
        results = run_tests(bot, data)
        assert results.ok
        assert results.passed_count == 4

    def test_conversations_passing(self):
        bot = _make_bot()
        data = load_test_file(FIXTURES / "test_conversations.qa.yaml")
        results = run_tests(bot, data)
        # The fixture uses setup.actions mock, so get_price doesn't need @bot.action
        for case in results.cases:
            if not case.passed:
                for step in case.steps:
                    if not step.passed:
                        print(f"  FAIL [{case.name}] step {step.index}: {step.error}")
        assert results.ok

    def test_failing_state_check(self):
        bot = _make_bot()
        data = {
            "conversations": [{
                "name": "wrong state",
                "steps": [{"user": "hello", "state": "nonexistent"}],
            }],
            "setup": {},
        }
        results = run_tests(bot, data)
        assert not results.ok
        assert results.failed_count == 1
        assert "state" in results.cases[0].steps[0].error

    def test_failing_response_check(self):
        bot = _make_bot()
        data = {
            "conversations": [{
                "name": "wrong response",
                "steps": [{"user": "hello", "response": "WRONG TEXT"}],
            }],
            "setup": {},
        }
        results = run_tests(bot, data)
        assert not results.ok
        assert "response" in results.cases[0].steps[0].error

    def test_context_check(self):
        bot = _make_bot()
        data = {
            "conversations": [{
                "name": "check context",
                "steps": [{
                    "user": "how much does it cost",
                    "state": "price_info",
                    "context": {"price": 100},
                }],
            }],
            "setup": {},
        }
        results = run_tests(bot, data)
        assert results.ok

    def test_context_check_failing(self):
        bot = _make_bot()
        data = {
            "conversations": [{
                "name": "wrong context",
                "steps": [{
                    "user": "how much does it cost",
                    "context": {"price": 999},
                }],
            }],
            "setup": {},
        }
        results = run_tests(bot, data)
        assert not results.ok
        assert "price" in results.cases[0].steps[0].error

    def test_regex_response_check(self):
        bot = _make_bot()
        data = {
            "conversations": [{
                "name": "regex match",
                "steps": [{
                    "user": "how much does it cost",
                    "response": r"/Price: \d+ USD/",
                }],
            }],
            "setup": {},
        }
        results = run_tests(bot, data)
        assert results.ok

    def test_setup_actions_mock(self):
        """setup.actions should override registered actions."""
        bot = Bot.from_string(SIMPLE_SCENARIO)
        # Don't register get_price — let setup.actions mock it
        data = {
            "conversations": [{
                "name": "mocked action",
                "steps": [{
                    "user": "how much does it cost",
                    "state": "price_info",
                    "context": {"price": 42},
                }],
            }],
            "setup": {"actions": {"get_price": {"price": 42}}},
        }
        results = run_tests(bot, data)
        assert results.ok

    def test_setup_actions_restored_after_tests(self):
        """Original action handlers should be restored after tests."""
        bot = _make_bot()
        data = {
            "conversations": [{
                "name": "mocked",
                "steps": [{"user": "how much does it cost"}],
            }],
            "setup": {"actions": {"get_price": {"price": 999}}},
        }
        run_tests(bot, data)
        # Original handler should be back
        resp = bot.send("how much does it cost")
        assert "100" in resp.text

    def test_multi_turn_conversation(self):
        bot = _make_bot()
        data = {
            "conversations": [{
                "name": "multi-turn",
                "steps": [
                    {"user": "how much does it cost", "state": "price_info"},
                    {"user": "yes", "state": "confirm"},
                ],
            }],
            "setup": {},
        }
        results = run_tests(bot, data)
        assert results.ok


class TestBotTestMethod:
    def test_bot_test_from_file(self):
        bot = _make_bot()
        results = bot.test(FIXTURES / "test_simple.qa.yaml")
        assert isinstance(results, TestRunResult)
        assert results.ok

    def test_bot_test_conversations(self):
        bot = _make_bot()
        results = bot.test(FIXTURES / "test_conversations.qa.yaml")
        assert results.ok


class TestFormatResults:
    def test_passing_output(self):
        bot = _make_bot()
        data = load_test_file(FIXTURES / "test_simple.qa.yaml")
        results = run_tests(bot, data)
        output = format_results(results)
        assert "passed" in output
        assert "0 failed" in output

    def test_failing_output(self):
        bot = _make_bot()
        data = {
            "conversations": [{
                "name": "fail test",
                "steps": [{"user": "hello", "state": "wrong"}],
            }],
            "setup": {},
        }
        results = run_tests(bot, data)
        output = format_results(results)
        assert "1 failed" in output
        assert "fail test" in output
