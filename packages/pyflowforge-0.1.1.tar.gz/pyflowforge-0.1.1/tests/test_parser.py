"""Tests for the DSL parser."""

import pytest
from flowforge.parser import parse_dsl, load_intents_yaml, load_scenario, DSLParseError


def test_parse_basic_scenario():
    yaml_text = """
scenario:
  name: test
  initial_state: start
  fallback_state: fallback

states:
  start:
    responses:
      - "Hello!"
    auto_transitions:
      - target: other
        when:
          - type: regex
            value: 'go'
  other:
    responses:
      - "Other state"
  fallback:
    responses:
      - "Fallback"
"""
    result = parse_dsl(yaml_text)
    assert result["name"] == "test"
    assert result["initial_state"] == "start"
    assert result["fallback_state"] == "fallback"
    assert "start" in result["states"]
    assert "other" in result["states"]
    assert result["states"]["start"]["responses"] == ["Hello!"]
    assert len(result["states"]["start"]["auto_transitions"]) == 1


def test_parse_inline_intents():
    yaml_text = """
scenario:
  name: test

intents:
  greeting:
    - hello
    - hi
  ask_price: |
    how much
    price

states:
  start:
    responses:
      - "Hi"
"""
    result = parse_dsl(yaml_text)
    assert "greeting" in result["intents"]
    assert result["intents"]["greeting"] == ["hello", "hi"]
    assert "ask_price" in result["intents"]
    assert "how much" in result["intents"]["ask_price"]


def test_parse_legacy_format():
    yaml_text = """
scenario:
  name: test

states:
  start:
    responses:
      - "Hello"
    transitions:
      - intent: greeting
        target: greet
    actions:
      - python: x = foo()
"""
    result = parse_dsl(yaml_text)
    state = result["states"]["start"]
    # Legacy transitions → auto_transitions
    assert len(state["auto_transitions"]) == 1
    assert state["auto_transitions"][0]["when"][0]["type"] == "intent"
    # Legacy actions → run
    assert len(state["run"]) == 1


def test_parse_invalid_yaml():
    with pytest.raises(DSLParseError):
        parse_dsl("{{invalid yaml")


def test_parse_non_mapping():
    with pytest.raises(DSLParseError):
        parse_dsl("- just a list")


def test_default_initial_state():
    yaml_text = """
scenario:
  name: test

states:
  first:
    responses: ["Hi"]
  second:
    responses: ["Bye"]
"""
    result = parse_dsl(yaml_text)
    assert result["initial_state"] == "first"


def test_load_intents_yaml(tmp_path):
    intents_file = tmp_path / "intents.yaml"
    intents_file.write_text("""
intents:
  ask_price: |
    how much
    price
  greeting:
    - hello
    - hi
""")
    result = load_intents_yaml(intents_file)
    assert "ask_price" in result
    assert "greeting" in result
    assert len(result["ask_price"]) == 2


def test_load_intents_yaml_nonexistent(tmp_path):
    result = load_intents_yaml(tmp_path / "nonexistent.yaml")
    assert result == {}


def test_load_scenario_with_auto_intents(tmp_path):
    scenario_file = tmp_path / "scenario.yaml"
    intents_file = tmp_path / "intents.yaml"

    scenario_file.write_text("""
scenario:
  name: test
states:
  start:
    responses: ["Hi"]
""")
    intents_file.write_text("""
intents:
  greeting:
    - hello
""")
    result = load_scenario(scenario_file)
    assert "greeting" in result["intents"]


def test_load_scenario_merge_intents(tmp_path):
    scenario_file = tmp_path / "scenario.yaml"
    intents_file = tmp_path / "intents.yaml"

    scenario_file.write_text("""
scenario:
  name: test
intents:
  ask_price:
    - how much
states:
  start:
    responses: ["Hi"]
""")
    intents_file.write_text("""
intents:
  greeting:
    - hello
""")
    result = load_scenario(scenario_file)
    # Both intents should be present
    assert "greeting" in result["intents"]
    assert "ask_price" in result["intents"]


def test_multi_file_scenario(tmp_path):
    """Test loading multiple scenario files via flowforge.config.yaml."""
    # Main scenario
    (tmp_path / "main.yaml").write_text("""
scenario:
  name: multi_test
  initial_state: start
  fallback_state: fallback
states:
  start:
    responses: ["Hello!"]
    auto_transitions:
      - target: pricing
        when:
          - type: regex
            value: price
  fallback:
    responses: ["Fallback"]
""")

    # Extra scenario file
    (tmp_path / "pricing.yaml").write_text("""
states:
  pricing:
    responses: ["$10/month"]
    auto_transitions:
      - target: start
        when:
          - type: intent
            value: '*'
""")

    # Intents files
    (tmp_path / "intents.yaml").write_text("""
intents:
  greeting:
    - hello
    - hi
""")
    (tmp_path / "intents_extra.yaml").write_text("""
intents:
  ask_price:
    - how much
    - price
""")

    # Config
    (tmp_path / "flowforge.config.yaml").write_text("""
scenario_files:
  - main.yaml
  - pricing.yaml
intent_files:
  - intents.yaml
  - intents_extra.yaml
""")

    result = load_scenario(tmp_path / "main.yaml")

    # States from both files should be present
    assert "start" in result["states"]
    assert "pricing" in result["states"]
    assert "fallback" in result["states"]

    # Intents from both files should be merged
    assert "greeting" in result["intents"]
    assert "ask_price" in result["intents"]


def test_multi_file_entry_overrides(tmp_path):
    """Entry file states should override extra file states on conflict."""
    (tmp_path / "main.yaml").write_text("""
scenario:
  name: test
states:
  shared:
    responses: ["From main"]
""")
    (tmp_path / "extra.yaml").write_text("""
states:
  shared:
    responses: ["From extra"]
  bonus:
    responses: ["Bonus"]
""")
    (tmp_path / "flowforge.config.yaml").write_text("""
scenario_files:
  - main.yaml
  - extra.yaml
""")

    result = load_scenario(tmp_path / "main.yaml")
    assert result["states"]["shared"]["responses"] == ["From main"]
    assert result["states"]["bonus"]["responses"] == ["Bonus"]


def test_named_patterns(tmp_path):
    """Test loading named patterns from patterns.yaml."""
    (tmp_path / "main.yaml").write_text("""
scenario:
  name: test
states:
  start:
    responses: ["Hi"]
""")
    (tmp_path / "patterns.yaml").write_text("""
greeting: '(hi | hello | hey)'
price_word: '(price* | cost*)'
""")

    result = load_scenario(tmp_path / "main.yaml")
    assert result["named_patterns"]["greeting"] == "(hi | hello | hey)"
    assert result["named_patterns"]["price_word"] == "(price* | cost*)"
