"""Tests for session stores — MemoryStore, SqliteStore, and Bot integration."""

from flowforge import Bot, MemoryStore
from flowforge.session import MemoryStore, context_to_dict, context_from_dict
from flowforge.context import Context
from flowforge.contrib.sqlite_store import SqliteStore


SIMPLE_SCENARIO = """
scenario:
  name: test
  initial_state: start

states:
  start:
    responses: ["Hello!"]
    auto_transitions:
      - target: other
        when:
          - type: regex
            value: 'go'
  other:
    responses: ["Other state"]
    auto_transitions: []
    response_transitions: []
"""


# -- Context serialization --

def test_context_roundtrip():
    """Context should survive serialization/deserialization."""
    ctx = Context(session_id="user_1", state="price_info")
    ctx.vars = {"price": 100, "name": "Alice"}
    ctx.history = [
        {"role": "user", "content": "hello", "state": "start"},
        {"role": "assistant", "content": "hi!", "state": "start"},
    ]

    data = context_to_dict(ctx)
    restored = context_from_dict(data)

    assert restored.session_id == "user_1"
    assert restored.state == "price_info"
    assert restored.vars == {"price": 100, "name": "Alice"}
    assert len(restored.history) == 2


# -- MemoryStore --

def test_memory_store_basic():
    store = MemoryStore()
    assert store.load("x") is None

    ctx = Context(session_id="x", state="start")
    store.save("x", ctx)
    loaded = store.load("x")
    assert loaded is not None
    assert loaded.state == "start"

    store.delete("x")
    assert store.load("x") is None


def test_memory_store_delete_nonexistent():
    """Deleting a non-existent session should not raise."""
    store = MemoryStore()
    store.delete("nonexistent")  # should not raise


# -- SqliteStore --

def test_sqlite_store_basic(tmp_path):
    db_path = tmp_path / "test.db"
    store = SqliteStore(db_path)

    assert store.load("user_1") is None

    ctx = Context(session_id="user_1", state="price_info")
    ctx.vars = {"price": 50}
    ctx.history = [{"role": "user", "content": "hi"}]
    store.save("user_1", ctx)

    loaded = store.load("user_1")
    assert loaded is not None
    assert loaded.state == "price_info"
    assert loaded.vars == {"price": 50}
    assert len(loaded.history) == 1

    store.delete("user_1")
    assert store.load("user_1") is None
    store.close()


def test_sqlite_store_persistence(tmp_path):
    """Data should survive closing and reopening the store."""
    db_path = tmp_path / "persist.db"

    # Write
    store1 = SqliteStore(db_path)
    ctx = Context(session_id="user_1", state="help")
    ctx.vars = {"key": "value"}
    store1.save("user_1", ctx)
    store1.close()

    # Read with a new connection
    store2 = SqliteStore(db_path)
    loaded = store2.load("user_1")
    assert loaded is not None
    assert loaded.state == "help"
    assert loaded.vars == {"key": "value"}
    store2.close()


def test_sqlite_store_overwrite(tmp_path):
    """Saving the same session_id should overwrite."""
    db_path = tmp_path / "overwrite.db"
    store = SqliteStore(db_path)

    ctx1 = Context(session_id="u", state="start")
    store.save("u", ctx1)

    ctx2 = Context(session_id="u", state="end")
    store.save("u", ctx2)

    loaded = store.load("u")
    assert loaded.state == "end"
    store.close()


# -- Bot + session_store integration --

def test_bot_with_memory_store():
    """Default behavior — MemoryStore."""
    bot = Bot.from_string(SIMPLE_SCENARIO)
    bot.send("go")
    ctx = bot._get_session("default")
    assert ctx.state == "other"


def test_bot_with_sqlite_store(tmp_path):
    """Bot should persist sessions via SqliteStore."""
    db_path = tmp_path / "bot.db"
    store = SqliteStore(db_path)

    bot = Bot.from_string(SIMPLE_SCENARIO, session_store=store)
    bot.send("go", session_id="user_1")

    # Session should be persisted
    loaded = store.load("user_1")
    assert loaded is not None
    assert loaded.state == "other"
    store.close()


def test_bot_session_survives_reload(tmp_path):
    """Session state should survive creating a new Bot with the same store."""
    db_path = tmp_path / "reload.db"

    # Bot 1 — user sends a message
    store1 = SqliteStore(db_path)
    bot1 = Bot.from_string(SIMPLE_SCENARIO, session_store=store1)
    bot1.send("go", session_id="user_1")
    store1.close()

    # Bot 2 — new instance, same DB
    store2 = SqliteStore(db_path)
    bot2 = Bot.from_string(SIMPLE_SCENARIO, session_store=store2)
    ctx = bot2._get_session("user_1")
    assert ctx.state == "other"  # state persisted from bot1
    store2.close()


def test_bot_reset_with_store(tmp_path):
    """reset_session should delete from the store."""
    db_path = tmp_path / "reset.db"
    store = SqliteStore(db_path)

    bot = Bot.from_string(SIMPLE_SCENARIO, session_store=store)
    bot.send("go", session_id="user_1")
    assert store.load("user_1") is not None

    bot.reset_session("user_1")
    assert store.load("user_1") is None
    store.close()


def test_bot_multiple_sessions_with_store(tmp_path):
    """Multiple sessions should be independent in the store."""
    db_path = tmp_path / "multi.db"
    store = SqliteStore(db_path)

    bot = Bot.from_string(SIMPLE_SCENARIO, session_store=store)
    bot.send("go", session_id="user_1")
    bot.send("hello", session_id="user_2")

    s1 = store.load("user_1")
    s2 = store.load("user_2")
    assert s1.state == "other"
    assert s2.state == "start"
    store.close()
