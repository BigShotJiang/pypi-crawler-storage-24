"""Tests for intent detection system."""

from flowforge.intent.tfidf import TfIdfClassifier
from flowforge.intent.pattern import match_pattern, compile_pattern
from flowforge.intent.detector import IntentDetector


# -- TF-IDF tests --

def test_tfidf_train_and_classify():
    clf = TfIdfClassifier()
    clf.train({
        "greeting": ["hello", "hi there", "good morning"],
        "ask_price": ["how much", "what is the price", "pricing"],
    })
    assert clf.trained

    intent, score = clf.classify("hello")
    assert intent == "greeting"
    assert score > 0.15

    intent, score = clf.classify("what is the price")
    assert intent == "ask_price"


def test_tfidf_untrained():
    clf = TfIdfClassifier()
    assert not clf.trained
    intent, score = clf.classify("hello")
    assert intent is None
    assert score == 0.0


def test_tfidf_known_intents():
    clf = TfIdfClassifier()
    clf.train({"a": ["hello"], "b": ["world"]})
    assert clf.known_intents() == ["a", "b"]


# -- Pattern matcher tests --

def test_pattern_exact_word():
    assert match_pattern("hello", "hello world")
    assert not match_pattern("hello", "goodbye")


def test_pattern_prefix():
    assert match_pattern("pric*", "pricing info")
    assert match_pattern("pric*", "the price is good")


def test_pattern_wildcard():
    assert match_pattern("hello * world", "hello big wide world")


def test_pattern_alternation():
    assert match_pattern("(yes | sure | ok)", "sure thing")
    assert not match_pattern("(yes | sure | ok)", "no way")


def test_pattern_optional():
    assert match_pattern("[please] help", "help")
    assert match_pattern("[please] help", "please help")


def test_pattern_bag():
    # Both elements must be present in any order
    assert match_pattern("{hello * world}", "hello beautiful world")
    assert match_pattern("{hello * world}", "world says hello")


def test_pattern_named():
    named = {"greeting": r"(?:\bhello\b|\bhi\b)"}
    assert match_pattern("$greeting", "hello", named)
    assert match_pattern("$greeting", "hi", named)


# -- IntentDetector tests --

def test_detector_regex():
    det = IntentDetector()
    assert det.check_trigger({"type": "regex", "value": "hello|hi"}, "hello world")
    assert not det.check_trigger({"type": "regex", "value": "hello|hi"}, "goodbye")


def test_detector_pattern():
    det = IntentDetector()
    assert det.check_trigger({"type": "pattern", "value": "pric*"}, "pricing")
    assert not det.check_trigger({"type": "pattern", "value": "pric*"}, "hello")


def test_detector_intent():
    clf = TfIdfClassifier()
    clf.train({"greeting": ["hello", "hi"], "ask_price": ["how much", "price"]})
    det = IntentDetector(classifiers=[clf])
    assert det.check_trigger({"type": "intent", "value": "greeting"}, "hello")
    assert det.check_trigger({"type": "intent", "value": "*"}, "anything")


def test_detector_transition_or_logic():
    det = IntentDetector()
    transition = {
        "when": [
            {"type": "regex", "value": "hello"},
            {"type": "regex", "value": "hi"},
        ],
        "target": "greeting",
    }
    assert det.check_transition(transition, "hello world")
    assert det.check_transition(transition, "hi there")
    assert not det.check_transition(transition, "goodbye")


def test_detector_transition_speed_order():
    """Regex should be checked before intent (speed order)."""
    clf = TfIdfClassifier()
    clf.train({"greeting": ["hello"]})
    det = IntentDetector(classifiers=[clf])

    transition = {
        "when": [
            {"type": "intent", "value": "greeting"},
            {"type": "regex", "value": "^hello$"},
        ],
        "target": "greet",
    }
    # Should match via regex (faster path)
    assert det.check_transition(transition, "hello")
