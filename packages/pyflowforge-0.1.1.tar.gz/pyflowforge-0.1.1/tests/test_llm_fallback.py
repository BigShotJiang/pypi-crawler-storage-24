"""Tests for LLM fallback and knowledge integration."""

from flowforge import Bot, BotResponse


class MockLLM:
    """Mock LLM provider for testing."""

    def __init__(self, response: str = "LLM response"):
        self._response = response
        self.last_message = None
        self.last_history = None
        self.last_knowledge = None

    def generate(self, message, history, knowledge=""):
        self.last_message = message
        self.last_history = history
        self.last_knowledge = knowledge
        return self._response


SCENARIO_WITH_LLM_FALLBACK = """
scenario:
  name: test
  initial_state: start
  fallback: llm

states:
  start:
    responses: ["Hello!"]
    auto_transitions:
      - target: help
        when:
          - type: regex
            value: 'help'
  help:
    responses: ["Here is help."]
    auto_transitions: []
    response_transitions: []
"""

SCENARIO_WITH_STATE_FALLBACK = """
scenario:
  name: test
  initial_state: start
  fallback: unknown

states:
  start:
    responses: ["Hello!"]
    auto_transitions: []
    response_transitions: []
  unknown:
    responses: ["I don't understand."]
    auto_transitions: []
    response_transitions: []
"""

SCENARIO_WITH_LEGACY_FALLBACK = """
scenario:
  name: test
  initial_state: start
  fallback_state: unknown

states:
  start:
    responses: ["Hello!"]
    auto_transitions: []
    response_transitions: []
  unknown:
    responses: ["I don't understand."]
    auto_transitions: []
    response_transitions: []
"""

SCENARIO_NO_FALLBACK = """
scenario:
  name: test
  initial_state: start

states:
  start:
    responses: ["Hello!"]
    auto_transitions: []
    response_transitions: []
"""


def test_llm_fallback_basic():
    """When no transition matches and fallback: llm, LLM provider is called."""
    llm = MockLLM("I can help with that!")
    bot = Bot.from_string(SCENARIO_WITH_LLM_FALLBACK, llm=llm)
    response = bot.send("something completely unknown")
    assert response.text == "I can help with that!"
    assert response.intent == "llm_fallback"
    assert llm.last_message == "something completely unknown"


def test_llm_fallback_not_used_when_transition_matches():
    """LLM fallback should NOT be called when a regex transition matches."""
    llm = MockLLM("LLM response")
    bot = Bot.from_string(SCENARIO_WITH_LLM_FALLBACK, llm=llm)
    response = bot.send("help")
    assert response.state == "help"
    assert response.text == "Here is help."
    assert llm.last_message is None  # LLM was not called


def test_llm_fallback_receives_history():
    """LLM provider should receive conversation history."""
    llm = MockLLM("Second LLM response")
    bot = Bot.from_string(SCENARIO_WITH_LLM_FALLBACK, llm=llm)
    bot.send("first unknown message")
    bot.send("second unknown message")
    assert llm.last_message == "second unknown message"
    assert len(llm.last_history) >= 2  # at least previous exchange


def test_llm_fallback_without_provider():
    """If fallback: llm but no llm= passed, stay in current state."""
    bot = Bot.from_string(SCENARIO_WITH_LLM_FALLBACK)
    response = bot.send("unknown stuff")
    # No LLM provider → stays in current state, returns default response
    assert response.state == "start"
    assert response.text == "Hello!"


def test_state_fallback():
    """fallback: state_name should go to that state (not LLM)."""
    bot = Bot.from_string(SCENARIO_WITH_STATE_FALLBACK)
    response = bot.send("gibberish")
    assert response.state == "unknown"
    assert response.text == "I don't understand."


def test_legacy_fallback_state():
    """fallback_state: still works for backward compatibility."""
    bot = Bot.from_string(SCENARIO_WITH_LEGACY_FALLBACK)
    response = bot.send("gibberish")
    assert response.state == "unknown"
    assert response.text == "I don't understand."


def test_no_fallback_stays_in_state():
    """No fallback at all → stay in current state."""
    bot = Bot.from_string(SCENARIO_NO_FALLBACK)
    response = bot.send("gibberish")
    assert response.state == "start"
    assert response.text == "Hello!"


def test_knowledge_passed_to_llm(tmp_path):
    """Knowledge file content should be passed to LLM provider."""
    # Create knowledge file
    knowledge_file = tmp_path / "knowledge.md"
    knowledge_file.write_text("We are open Mon-Sat 10-20. Sunday closed.")

    # Create scenario file
    scenario_file = tmp_path / "scenario.yaml"
    scenario_file.write_text("""
scenario:
  name: test
  initial_state: start
  fallback: llm
  knowledge: knowledge.md

states:
  start:
    responses: ["Hi!"]
    auto_transitions: []
    response_transitions: []
""")

    llm = MockLLM("We are open Monday to Saturday.")
    bot = Bot.from_yaml(scenario_file, llm=llm)
    bot.send("when are you open?")
    assert llm.last_knowledge == "We are open Mon-Sat 10-20. Sunday closed."


def test_knowledge_empty_when_no_file():
    """Knowledge should be empty string when not configured."""
    llm = MockLLM("response")
    bot = Bot.from_string(SCENARIO_WITH_LLM_FALLBACK, llm=llm)
    bot.send("question")
    assert llm.last_knowledge == ""


def test_fallback_decorator():
    """@bot.fallback should work as alternative to llm= parameter."""
    yaml_text = """
scenario:
  name: test
  initial_state: start

states:
  start:
    responses: ["Hello!"]
    auto_transitions: []
    response_transitions: []
"""
    bot = Bot.from_string(yaml_text)

    @bot.fallback
    def my_fallback(ctx):
        ctx.say(f"Fallback for: {ctx.message}")

    response = bot.send("anything unknown")
    assert "Fallback for: anything unknown" in response.text
    assert response.intent == "llm_fallback"


def test_fallback_decorator_with_knowledge(tmp_path):
    """@bot.fallback handler should have access to knowledge via ctx.vars."""
    knowledge_file = tmp_path / "knowledge.md"
    knowledge_file.write_text("Important info here.")

    scenario_file = tmp_path / "scenario.yaml"
    scenario_file.write_text("""
scenario:
  name: test
  initial_state: start
  knowledge: knowledge.md

states:
  start:
    responses: ["Hi!"]
    auto_transitions: []
    response_transitions: []
""")

    bot = Bot.from_yaml(scenario_file)

    @bot.fallback
    def my_fallback(ctx):
        knowledge = ctx.vars.get("knowledge", "")
        ctx.say(f"Knowledge: {knowledge}")

    response = bot.send("tell me something")
    assert "Important info here." in response.text


def test_llm_provider_exception_handled():
    """If LLM provider raises an exception, bot should not crash."""

    class BrokenLLM:
        def generate(self, message, history, knowledge=""):
            raise RuntimeError("API error")

    bot = Bot.from_string(SCENARIO_WITH_LLM_FALLBACK, llm=BrokenLLM())
    response = bot.send("something")
    assert response.text == "..."  # graceful fallback
