"""Tests for the conversation engine."""

from flowforge.engine import ConversationEngine, _interpolate
from flowforge.intent.detector import IntentDetector
from flowforge.intent.tfidf import TfIdfClassifier
from flowforge.actions import ActionRegistry
from flowforge.context import Context


def _make_engine(intents=None):
    clf = TfIdfClassifier()
    if intents:
        clf.train(intents)
    detector = IntentDetector(classifiers=[clf] if intents else [])
    registry = ActionRegistry()
    return ConversationEngine(detector, registry), registry


def test_interpolate():
    assert _interpolate("{name} hello", {"name": "World"}) == "World hello"
    assert _interpolate("{missing}", {}) == "{missing}"
    assert _interpolate("price", {"price": 100}) == "100"


def test_basic_transition():
    engine, _ = _make_engine()
    states = {
        "start": {
            "responses": ["Hello"],
            "auto_transitions": [
                {"when": [{"type": "regex", "value": "help"}], "target": "help"}
            ],
            "response_transitions": [],
        },
        "help": {
            "responses": ["I can help!"],
            "auto_transitions": [],
            "response_transitions": [],
        },
    }
    ctx = Context(session_id="test", state="start")
    result = engine.process("help me", "start", states, ctx)
    assert result["new_state"] == "help"
    assert result["response"] == "I can help!"


def test_response_transitions():
    engine, _ = _make_engine()
    states = {
        "ask": {
            "responses": ["Yes or no?"],
            "auto_transitions": [],
            "response_transitions": [
                {"when": [{"type": "regex", "value": "yes"}], "target": "confirmed"},
            ],
        },
        "confirmed": {
            "responses": ["Done!"],
            "auto_transitions": [],
            "response_transitions": [],
        },
    }
    ctx = Context(session_id="test", state="ask")
    result = engine.process("yes", "ask", states, ctx)
    assert result["new_state"] == "confirmed"
    assert result["response"] == "Done!"


def test_fallback_state():
    engine, _ = _make_engine()
    states = {
        "__meta__": {"fallback_state": "fallback"},
        "start": {
            "responses": ["Hello"],
            "auto_transitions": [],
            "response_transitions": [],
        },
        "fallback": {
            "responses": ["Didn't understand"],
            "auto_transitions": [],
            "response_transitions": [],
        },
    }
    ctx = Context(session_id="test", state="start")
    result = engine.process("gibberish", "start", states, ctx)
    assert result["new_state"] == "fallback"


def test_routing_state():
    engine, _ = _make_engine()
    states = {
        "router": {
            "responses": [],
            "auto_transitions": [
                {"when": [{"type": "regex", "value": "price"}], "target": "pricing"},
            ],
            "response_transitions": [],
        },
        "pricing": {
            "responses": ["$10/month"],
            "auto_transitions": [],
            "response_transitions": [],
        },
    }
    ctx = Context(session_id="test", state="start")
    # Simulate being routed to the router
    result = engine.process("price info", "router", states, ctx)
    assert result["new_state"] == "pricing"
    assert result["response"] == "$10/month"


def test_action_execution():
    engine, registry = _make_engine()
    registry.register("get_price", lambda ctx: {"price": 42})
    states = {
        "start": {
            "responses": ["Hello"],
            "auto_transitions": [
                {"when": [{"type": "regex", "value": "price"}], "target": "pricing"},
            ],
            "response_transitions": [],
        },
        "pricing": {
            "responses": ["Price: {price} USD"],
            "run": [{"action": "get_price"}],
            "auto_transitions": [],
            "response_transitions": [],
        },
    }
    ctx = Context(session_id="test", state="start")
    result = engine.process("price", "start", states, ctx)
    assert result["new_state"] == "pricing"
    assert "42" in result["response"]


def test_global_transition():
    engine, _ = _make_engine()
    states = {
        "current": {
            "type": "general",
            "responses": ["In current"],
            "auto_transitions": [],
            "response_transitions": [],
        },
        "other": {
            "type": "general",
            "responses": ["In other"],
            "auto_transitions": [
                {"when": [{"type": "regex", "value": "goto_other"}], "target": "other"},
            ],
            "response_transitions": [],
        },
    }
    ctx = Context(session_id="test", state="current")
    result = engine.process("goto_other", "current", states, ctx)
    assert result["new_state"] == "other"


def test_history_tracking():
    engine, _ = _make_engine()
    states = {
        "start": {
            "responses": ["Hello"],
            "auto_transitions": [],
            "response_transitions": [],
        },
    }
    ctx = Context(session_id="test", state="start")
    engine.process("hi", "start", states, ctx)
    assert len(ctx.history) == 2
    assert ctx.history[0]["role"] == "user"
    assert ctx.history[1]["role"] == "assistant"
