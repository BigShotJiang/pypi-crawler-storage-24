"""Tests for the Bot class — integration tests."""

from pathlib import Path

from flowforge import Bot, BotResponse


FIXTURES = Path(__file__).parent / "fixtures"


def test_from_yaml():
    bot = Bot.from_yaml(FIXTURES / "simple.yaml")
    assert bot._initial_state == "start"
    assert "start" in bot._states


def test_send_basic():
    bot = Bot.from_yaml(FIXTURES / "simple.yaml")
    response = bot.send("hello")
    assert isinstance(response, BotResponse)
    assert isinstance(response.text, str)
    assert len(response.text) > 0


def test_send_regex_transition():
    bot = Bot.from_yaml(FIXTURES / "simple.yaml")
    response = bot.send("help me please")
    assert response.state == "help"
    assert "help" in response.text.lower() or "pricing" in response.text.lower()


def test_send_with_action():
    bot = Bot.from_yaml(FIXTURES / "simple.yaml")

    @bot.action("get_price")
    def get_price(ctx):
        return {"price": 99}

    response = bot.send("what is the price")
    assert response.state == "price_info"
    assert "99" in response.text


def test_response_transition():
    bot = Bot.from_yaml(FIXTURES / "simple.yaml")

    @bot.action("get_price")
    def get_price(ctx):
        return {"price": 50}

    # First message → go to price_info
    bot.send("what is the price")
    # Second message → response_transition "yes" → confirm
    response = bot.send("yes")
    assert response.state == "confirm"
    assert "confirmed" in response.text.lower()


def test_session_isolation():
    bot = Bot.from_yaml(FIXTURES / "simple.yaml")

    @bot.action("get_price")
    def get_price(ctx):
        return {"price": 10}

    bot.send("what is the price", session_id="user_1")
    bot.send("hello", session_id="user_2")

    # user_1 should be in price_info, user_2 should not
    session1 = bot._get_session("user_1")
    session2 = bot._get_session("user_2")
    assert session1.state == "price_info"
    assert session2.state != "price_info"


def test_reset_session():
    bot = Bot.from_yaml(FIXTURES / "simple.yaml")
    bot.send("help")
    assert bot._get_session("default").state == "help"
    bot.reset_session("default")
    # After reset, session should be fresh (initial state)
    assert bot._get_session("default").state == bot._initial_state


def test_from_string():
    yaml_text = """
scenario:
  name: test
  initial_state: start

states:
  start:
    responses:
      - "Hello!"
"""
    bot = Bot.from_string(yaml_text)
    response = bot.send("anything")
    assert response.text == "Hello!"


def test_from_dict():
    scenario = {
        "name": "test",
        "initial_state": "start",
        "states": {
            "start": {
                "responses": ["Hi!"],
                "auto_transitions": [],
                "response_transitions": [],
            },
        },
        "intents": {},
    }
    bot = Bot.from_dict(scenario)
    response = bot.send("anything")
    assert response.text == "Hi!"


def test_get_greeting():
    bot = Bot.from_yaml(FIXTURES / "simple.yaml")
    greeting = bot.get_greeting()
    assert greeting is not None
    assert isinstance(greeting, str)


def test_programmatic_state():
    yaml_text = """
scenario:
  name: test
  initial_state: start
states:
  start:
    responses:
      - "Start"
    auto_transitions:
      - target: dynamic
        when:
          - type: regex
            value: 'go'
"""
    bot = Bot.from_string(yaml_text)

    @bot.state("dynamic")
    def dynamic(ctx):
        ctx.say(f"Dynamic: {ctx.message}")

    response = bot.send("go")
    assert response.state == "dynamic"
    assert "Dynamic: go" in response.text


def test_add_classifier():
    """Test adding a custom classifier."""

    class MockClassifier:
        @property
        def trained(self):
            return True

        def classify(self, text):
            if "magic" in text:
                return "magic_intent", 0.99
            return None, 0.0

    yaml_text = """
scenario:
  name: test
  initial_state: start
states:
  start:
    responses: ["Start"]
    auto_transitions:
      - target: magic
        when:
          - type: intent
            value: magic_intent
  magic:
    responses: ["Magic!"]
    auto_transitions: []
    response_transitions: []
"""
    bot = Bot.from_string(yaml_text)
    bot.add_classifier(MockClassifier())
    response = bot.send("do some magic")
    assert response.state == "magic"


def test_custom_classifier_at_creation():
    """Test passing a custom classifier via classifier= parameter."""

    class AlwaysGreeting:
        @property
        def trained(self):
            return True

        def classify(self, text):
            return "greeting", 0.99

    yaml_text = """
scenario:
  name: test
  initial_state: start
states:
  start:
    responses: ["Start"]
    auto_transitions:
      - target: greeted
        when:
          - type: intent
            value: greeting
  greeted:
    responses: ["Hello there!"]
    auto_transitions: []
    response_transitions: []
"""
    bot = Bot.from_string(yaml_text, classifier=AlwaysGreeting())
    response = bot.send("anything at all")
    assert response.state == "greeted"
    assert "greeting" in response.intent


def test_fallback():
    yaml_text = """
scenario:
  name: test
  initial_state: start
  fallback_state: fallback
states:
  start:
    responses: ["Hello"]
    auto_transitions: []
    response_transitions: []
  fallback:
    responses: ["Didn't understand"]
    auto_transitions: []
    response_transitions: []
"""
    bot = Bot.from_string(yaml_text)
    response = bot.send("asdfghjkl random gibberish")
    assert response.state == "fallback"
