# FlowForge FAQ

## What is FlowForge?
FlowForge is an open-source Python framework for building conversational bots. It uses a declarative YAML DSL where each state is a business object — not an abstract node in a state machine.

## How do I install it?
```
pip install pyflowforge
```
Requires Python 3.9+. The only dependency is PyYAML.

## What makes FlowForge different?
FlowForge uses an Object-Oriented DSL approach:
- States are business objects (pricing, support, checkout), not abstract nodes
- YAML defines the dialogue structure, Python handles the logic
- The engine connects them automatically
- No heavy dependencies — just PyYAML

## Can I connect FlowForge to Telegram/Discord/Slack?
Yes! FlowForge is channel-agnostic. You call `bot.send(text)` and get a response back. Connect it to any messaging platform — Telegram, Discord, Slack, WhatsApp, web chat, etc.

## Does FlowForge support LLMs?
Yes. You can set `fallback: llm` in your scenario and pass an LLM provider when creating the bot. FlowForge handles known paths with rules and falls back to LLM for everything else. Built-in providers for OpenAI and Anthropic are included.

## How does intent detection work?
FlowForge includes a built-in TF-IDF classifier trained on examples you provide in YAML. You can also plug in your own classifier (BERT, OpenAI, etc.) via the IntentClassifier protocol.

## Can I use a knowledge base?
Yes. Add `knowledge: knowledge.md` to your scenario. The content is passed to the LLM as context for answering questions that don't match any defined state transitions.

## How do I test my bot?
Write tests in `.qa.yaml` files and run them:
```
python -m flowforge test scenario.yaml tests.qa.yaml
```
Or in Python: `results = bot.test("tests.qa.yaml")`

## Is FlowForge free?
Yes, FlowForge is free and open-source under the MIT license.
