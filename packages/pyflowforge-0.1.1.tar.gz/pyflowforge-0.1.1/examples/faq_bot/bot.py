"""FAQ bot — rule-based for known topics, LLM fallback for everything else.

This example shows how to combine structured YAML states with LLM fallback
and a knowledge base file. Known topics (pricing, contact) are handled by
rules; unknown questions are answered by the LLM using knowledge.md.

To run with LLM fallback, you need an API key:

    # OpenAI
    export OPENAI_API_KEY=sk-...
    python bot.py

    # Anthropic
    export ANTHROPIC_API_KEY=sk-ant-...
    python bot.py --anthropic

Without an API key, the bot still works — it just won't answer
questions outside the defined states.
"""

import os
import sys
from flowforge import Bot


def make_bot():
    llm = None

    # Try to set up LLM provider from environment
    if "--anthropic" in sys.argv:
        api_key = os.environ.get("ANTHROPIC_API_KEY")
        if api_key:
            from flowforge.contrib.llm import AnthropicProvider
            llm = AnthropicProvider(
                api_key=api_key,
                model="claude-sonnet-4-20250514",
                system="You are a helpful FAQ bot for FlowForge. Answer concisely.",
            )
            print("(Using Anthropic LLM fallback)")
    else:
        api_key = os.environ.get("OPENAI_API_KEY")
        if api_key:
            from flowforge.contrib.llm import OpenAIProvider
            llm = OpenAIProvider(
                api_key=api_key,
                model="gpt-4o-mini",
                system="You are a helpful FAQ bot for FlowForge. Answer concisely.",
            )
            print("(Using OpenAI LLM fallback)")

    if llm is None:
        print("(No LLM API key found — running without LLM fallback)")
        print("(Set OPENAI_API_KEY or ANTHROPIC_API_KEY for full functionality)\n")

    return Bot.from_yaml("scenario.yaml", llm=llm)


if __name__ == "__main__":
    bot = make_bot()
    bot.run()
