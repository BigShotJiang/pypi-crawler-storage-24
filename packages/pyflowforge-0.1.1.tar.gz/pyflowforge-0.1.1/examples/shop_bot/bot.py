"""Shop bot — product catalog, pricing, and checkout."""

from flowforge import Bot

bot = Bot.from_yaml("scenario.yaml")

PRODUCTS = {
    "laptop": 999,
    "phone": 699,
    "headphones": 149,
    "keyboard": 79,
}

order_counter = 0


@bot.action("get_catalog")
def get_catalog(ctx):
    items = ", ".join(f"{name} (${price})" for name, price in PRODUCTS.items())
    return {"catalog": items}


@bot.action("get_price")
def get_price(ctx):
    message = ctx.message.lower()
    for name, price in PRODUCTS.items():
        if name in message:
            return {"item": name.title(), "price": price}
    # Default to first product if no specific item mentioned
    name = list(PRODUCTS.keys())[0]
    return {"item": name.title(), "price": PRODUCTS[name]}


@bot.action("create_order")
def create_order(ctx):
    global order_counter
    order_counter += 1
    return {"order_id": f"{order_counter:04d}"}


if __name__ == "__main__":
    bot.run()
