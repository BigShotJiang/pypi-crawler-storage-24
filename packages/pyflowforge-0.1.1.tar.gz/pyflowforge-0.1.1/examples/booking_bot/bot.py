"""Booking bot — restaurant table reservation with multi-step flow."""

import re
from flowforge import Bot

bot = Bot.from_yaml("scenario.yaml")

booking_counter = 0


@bot.action("save_guests")
def save_guests(ctx):
    match = re.search(r'\d+', ctx.message)
    guests = int(match.group()) if match else 2
    return {"guests": guests}


@bot.action("save_date")
def save_date(ctx):
    return {"date": ctx.message.strip()}


@bot.action("create_booking")
def create_booking(ctx):
    global booking_counter
    booking_counter += 1
    return {"booking_id": f"BK-{booking_counter:04d}"}


@bot.action("get_menu")
def get_menu(ctx):
    menu = "Tomato Soup, Grilled Salmon, Caesar Salad, Tiramisu"
    return {"menu": menu}


if __name__ == "__main__":
    bot.run()
