"""
ActionRegistry — executes actions defined in run: blocks.

Supports:
  - action: name     — calls a Python function registered via @bot.action("name")
  - js: var = func() — calls a Node.js function from .js files via subprocess
"""

from __future__ import annotations

import json
import re
import subprocess
from pathlib import Path
from typing import Any, Callable

from .context import Context


class ActionRegistry:
    """Registry for Python action handlers + Node.js subprocess executor."""

    def __init__(self) -> None:
        self._handlers: dict[str, Callable] = {}
        self._project_path: Path | None = None

    @property
    def project_path(self) -> Path | None:
        return self._project_path

    @project_path.setter
    def project_path(self, path: Path | None) -> None:
        self._project_path = path

    def register(self, name: str, handler: Callable) -> None:
        """Register a Python action handler."""
        self._handlers[name] = handler

    def has(self, name: str) -> bool:
        return name in self._handlers

    def execute(self, action: Any, context: Context) -> dict[str, Any]:
        """
        Execute a single action entry from the run: block.

        Returns dict of variables to merge into context.
        """
        if isinstance(action, dict):
            # action: name — Python registered handler
            if "action" in action:
                return self._execute_python(action["action"], context)

            # js: var = func() — Node.js subprocess
            if "js" in action:
                return self._execute_js(action["js"], context)

        return {}

    def _execute_python(self, name: str, context: Context) -> dict[str, Any]:
        """Call a registered Python action handler."""
        handler = self._handlers.get(name)
        if handler is None:
            raise RuntimeError(
                f"Action '{name}' not registered. Use @bot.action('{name}')"
            )

        result = handler(context)
        if isinstance(result, dict):
            return result
        elif result is not None:
            return {name: result}
        return {}

    def _execute_js(self, expr: str, context: Context) -> dict[str, Any]:
        """Execute a JS function via Node.js subprocess."""
        parsed = _parse_js_action(expr)
        if parsed is None:
            return {}

        var_name, func_call = parsed
        func_name_match = re.match(r'^(\w+)\s*\(', func_call)
        func_name = func_name_match.group(1) if func_name_match else func_call

        project_path = self._project_path
        if project_path is None:
            return {var_name: None}

        source_file = _find_js_function(func_name, project_path)
        if source_file is None:
            return {var_name: None}

        try:
            result = _run_js(func_call, source_file, project_path)
            return {var_name: result}
        except Exception as e:
            return {var_name: f"<error: {e}>"}


def _parse_js_action(expr: str) -> tuple[str, str] | None:
    """Parse 'var = func()' expression."""
    expr = str(expr).strip()
    m = re.match(r'^([A-Za-z_]\w*)\s*=\s*(.+)$', expr)
    if m:
        return m.group(1), m.group(2).strip()
    return None


def _find_js_function(func_name: str, project_path: Path) -> Path | None:
    """Search project .js files for the function definition."""
    pattern = re.compile(
        rf'(?:function\s+{re.escape(func_name)}\s*\(|'
        rf'(?:const|let|var)\s+{re.escape(func_name)}\s*=\s*(?:async\s+)?(?:function|\())',
        re.MULTILINE,
    )
    for f in sorted(project_path.glob("*.js")):
        try:
            if pattern.search(f.read_text(encoding="utf-8")):
                return f
        except OSError:
            pass
    return None


def _run_js(func_call: str, source_file: Path, project_path: Path) -> Any:
    """Execute a JS function call and return its JSON-serializable result."""
    script = (
        f"const _m = require({str(source_file)!r});\n"
        f"Promise.resolve(_m.{func_call}).then(r => process.stdout.write(JSON.stringify(r ?? null)));"
    )
    proc = subprocess.run(
        ["node", "-e", script],
        capture_output=True, text=True, timeout=10, cwd=str(project_path),
    )
    if proc.returncode != 0:
        raise RuntimeError(proc.stderr.strip() or "JS action failed")
    return json.loads(proc.stdout.strip())
