"""Session stores — protocol and in-memory implementation."""

from __future__ import annotations

import json
from typing import Any, Protocol, runtime_checkable

from .context import Context


@runtime_checkable
class SessionStore(Protocol):
    """
    Protocol for session persistence.

    Implement this to store sessions in Redis, PostgreSQL, or any other backend.

    Example::

        class MyStore:
            def load(self, session_id: str) -> Context | None: ...
            def save(self, session_id: str, context: Context) -> None: ...
            def delete(self, session_id: str) -> None: ...
    """

    def load(self, session_id: str) -> Context | None:
        """Load a session. Returns None if not found."""
        ...

    def save(self, session_id: str, context: Context) -> None:
        """Save a session."""
        ...

    def delete(self, session_id: str) -> None:
        """Delete a session."""
        ...


class MemoryStore:
    """In-memory session store (default). Sessions are lost on restart."""

    def __init__(self) -> None:
        self._sessions: dict[str, Context] = {}

    def load(self, session_id: str) -> Context | None:
        return self._sessions.get(session_id)

    def save(self, session_id: str, context: Context) -> None:
        self._sessions[session_id] = context

    def delete(self, session_id: str) -> None:
        self._sessions.pop(session_id, None)


def context_to_dict(ctx: Context) -> dict[str, Any]:
    """Serialize a Context to a plain dict (for JSON storage)."""
    return {
        "session_id": ctx.session_id,
        "state": ctx.state,
        "vars": ctx.vars,
        "history": ctx.history,
    }


def context_from_dict(data: dict[str, Any]) -> Context:
    """Deserialize a Context from a plain dict."""
    return Context(
        session_id=data.get("session_id", "default"),
        state=data.get("state", "start"),
        vars=data.get("vars", {}),
        history=data.get("history", []),
    )
