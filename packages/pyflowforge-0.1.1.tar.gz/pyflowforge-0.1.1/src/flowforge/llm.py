"""LLM Provider — protocol and base class for LLM integration."""

from __future__ import annotations

from typing import Protocol, runtime_checkable


@runtime_checkable
class LLMProvider(Protocol):
    """
    Protocol for LLM providers used by FlowForge.

    The engine calls generate() when LLM is needed (e.g. fallback).
    Implement this protocol to plug in any LLM: OpenAI, Anthropic,
    local models, or custom APIs.

    Example::

        class MyLLM:
            def generate(self, message: str, history: list, knowledge: str = "") -> str:
                # call your LLM here
                return "response text"

        bot = Bot.from_yaml("scenario.yaml", llm=MyLLM())
    """

    def generate(
        self,
        message: str,
        history: list[dict[str, str]],
        knowledge: str = "",
    ) -> str:
        """
        Generate a response using an LLM.

        Args:
            message: Current user message.
            history: Conversation history as list of {"role": ..., "content": ...}.
            knowledge: Knowledge base text (from knowledge.md), empty if not set.

        Returns:
            Generated response text.
        """
        ...
