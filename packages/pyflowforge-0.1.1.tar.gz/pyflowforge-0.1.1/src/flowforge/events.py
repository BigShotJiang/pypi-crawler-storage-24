"""EventEmitter — structured JSONL event logger."""

from __future__ import annotations

import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


class EventEmitter:
    def __init__(self, log_path: Path | None = None, echo: bool = False):
        """
        Args:
            log_path: Path to .jsonl file. None → events are discarded.
            echo: If True, print events to stderr.
        """
        self._log_path = log_path
        self._echo = echo
        if log_path:
            log_path.parent.mkdir(parents=True, exist_ok=True)

    def emit(self, event: str, **kwargs: Any) -> None:
        """Emit a structured log event."""
        record: dict[str, Any] = {
            "ts": datetime.now(timezone.utc).isoformat(),
            "event": event,
        }
        record.update(kwargs)

        if self._log_path:
            try:
                with self._log_path.open("a", encoding="utf-8") as f:
                    f.write(json.dumps(record, ensure_ascii=False) + "\n")
            except OSError:
                pass

        if self._echo:
            print(json.dumps(record, ensure_ascii=False), file=sys.stderr)
