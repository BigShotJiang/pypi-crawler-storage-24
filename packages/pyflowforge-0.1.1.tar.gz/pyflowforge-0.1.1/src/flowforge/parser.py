"""
DSL Parser — converts YAML DSL to internal scenario format.

Supports:
  - scenario: section (name, initial_state, fallback_state)
  - states: section with auto_transitions, response_transitions, run, responses
  - intents: section (inline intents in the same file)
  - action: syntax in run (calls registered Python functions)
  - js: syntax in run (calls Node.js functions via subprocess)
  - Legacy format (transitions → auto_transitions, actions → run, intent: → when:)
"""

from __future__ import annotations

import yaml
from pathlib import Path
from typing import Any


class DSLParseError(ValueError):
    pass


def _parse_transitions(raw_list: list) -> list[dict]:
    """Parse a list of transition dicts (old or new format)."""
    result = []
    for t in raw_list or []:
        if t is None:
            continue
        if "when" in t:
            result.append({
                "when": t["when"],
                "target": t.get("target", ""),
                "condition": t.get("condition"),
            })
        elif "intent" in t:
            # Old format: {intent: foo, target: bar}
            result.append({
                "when": [{"type": "intent", "value": t.get("intent", "any")}],
                "target": t.get("target", ""),
                "condition": t.get("condition"),
            })
        else:
            result.append(t)
    return result


def parse_dsl(dsl_text: str) -> dict[str, Any]:
    """
    Parse DSL YAML text into internal scenario dict.

    Returns:
        {
            "name": str,
            "initial_state": str,
            "fallback_state": str | None,
            "states": {state_id: state_data, ...},
            "intents": {intent_name: [phrase, ...], ...},
        }
    """
    try:
        data = yaml.safe_load(dsl_text)
    except yaml.YAMLError as e:
        raise DSLParseError(f"Invalid YAML: {e}")

    if not isinstance(data, dict):
        raise DSLParseError("DSL must be a YAML mapping")

    scenario_meta = data.get("scenario", {})
    raw_states = data.get("states", {})

    if not isinstance(raw_states, dict):
        raise DSLParseError("'states' must be a mapping")

    states: dict[str, Any] = {}
    for state_id, state_data in raw_states.items():
        if state_data is None:
            state_data = {}

        auto_transitions = _parse_transitions(
            state_data.get("auto_transitions") or state_data.get("transitions", [])
        )
        response_transitions = _parse_transitions(
            state_data.get("response_transitions", [])
        )
        responses = state_data.get("responses", []) or []
        run = state_data.get("run") or state_data.get("actions", []) or []

        states[state_id] = {
            "id": state_id,
            "name": state_data.get("name", state_id),
            "type": state_data.get("type", "general"),
            "accumulate_from": state_data.get("accumulate_from"),
            "responses": [str(r) for r in responses],
            "run": list(run),
            "auto_transitions": auto_transitions,
            "response_transitions": response_transitions,
        }

    initial_state = scenario_meta.get("initial_state") or (
        list(states.keys())[0] if states else "start"
    )

    # Parse fallback — supports multiple formats:
    #   fallback: llm               → LLM fallback
    #   fallback: state_name        → go to state
    #   fallback_state: state_name  → legacy format
    fallback_raw = scenario_meta.get("fallback") or scenario_meta.get("fallback_state")
    fallback_mode = None  # "llm" or "state"
    fallback_state = None

    if fallback_raw:
        fallback_str = str(fallback_raw).strip()
        if fallback_str == "llm":
            fallback_mode = "llm"
        else:
            fallback_mode = "state"
            fallback_state = fallback_str

    # Store fallback in __meta__ for engine compatibility
    meta: dict[str, Any] = {}
    if fallback_state:
        meta["fallback_state"] = fallback_state
    if fallback_mode:
        meta["fallback_mode"] = fallback_mode
    if meta:
        states["__meta__"] = meta

    # Parse knowledge file reference
    knowledge_file = scenario_meta.get("knowledge")

    # Parse inline intents
    intents = _parse_intents_section(data.get("intents", {}))

    return {
        "name": scenario_meta.get("name", "Unnamed Scenario"),
        "description": scenario_meta.get("description"),
        "initial_state": initial_state,
        "fallback_mode": fallback_mode,
        "fallback_state": fallback_state,
        "knowledge_file": knowledge_file,
        "states": states,
        "intents": intents,
    }


def _parse_intents_section(raw: Any) -> dict[str, list[str]]:
    """Parse intents from YAML (inline or from file)."""
    if not raw or not isinstance(raw, dict):
        return {}

    intents: dict[str, list[str]] = {}
    for name, value in raw.items():
        if isinstance(value, str):
            # Block scalar: one phrase per line; skip comments
            phrases = [
                ln.strip() for ln in value.strip().splitlines()
                if ln.strip() and not ln.strip().startswith('#')
            ]
        elif isinstance(value, list):
            phrases = [str(v).strip() for v in value if v]
        else:
            continue
        if phrases:
            intents[str(name)] = phrases
    return intents


def load_intents_yaml(path: Path | str) -> dict[str, list[str]]:
    """Load intents from a standalone intents.yaml file."""
    p = Path(path)
    if not p.exists():
        return {}
    try:
        data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
    except Exception:
        return {}

    # Support both {intents: {...}} and flat {intent_name: ...} formats
    raw = data.get("intents", data) if isinstance(data, dict) else {}
    return _parse_intents_section(raw)


def _load_config(project_dir: Path) -> dict:
    """Load flowforge.config.yaml, returning {} if absent."""
    config_path = project_dir / "flowforge.config.yaml"
    if not config_path.exists():
        return {}
    try:
        return yaml.safe_load(config_path.read_text(encoding="utf-8")) or {}
    except Exception:
        return {}


def _parse_states_from_file(path: Path) -> dict[str, Any]:
    """Parse states from a single YAML file (no scenario: metadata)."""
    try:
        data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    except Exception:
        return {}

    raw_states = data.get("states", {})
    if not isinstance(raw_states, dict):
        return {}

    states: dict[str, Any] = {}
    for state_id, state_data in raw_states.items():
        if state_data is None:
            state_data = {}
        auto_transitions = _parse_transitions(
            state_data.get("auto_transitions") or state_data.get("transitions", [])
        )
        response_transitions = _parse_transitions(
            state_data.get("response_transitions", [])
        )
        responses = state_data.get("responses", []) or []
        run = state_data.get("run") or state_data.get("actions", []) or []

        states[state_id] = {
            "id": state_id,
            "name": state_data.get("name", state_id),
            "type": state_data.get("type", "general"),
            "accumulate_from": state_data.get("accumulate_from"),
            "responses": [str(r) for r in responses],
            "run": list(run),
            "auto_transitions": auto_transitions,
            "response_transitions": response_transitions,
        }
    return states


def _load_patterns(project_dir: Path, pattern_files: list[str]) -> dict[str, str]:
    """Load and merge named patterns from pattern files."""
    merged: dict[str, str] = {}
    for fname in pattern_files:
        p = project_dir / fname
        if not p.exists():
            continue
        try:
            data = yaml.safe_load(p.read_text(encoding="utf-8")) or {}
        except Exception:
            continue
        for k, v in data.items():
            if isinstance(v, (str, int, float)):
                merged[str(k)] = str(v)
    return merged


def load_scenario(
    path: Path | str,
    intents_path: Path | str | None = None,
) -> dict[str, Any]:
    """
    Load a complete scenario from YAML file(s).

    Supports multi-file projects via flowforge.config.yaml:
        scenario_files:   # states are merged; entry file has highest priority
          - main.yaml
          - pricing.yaml
        intent_files:     # intents are merged
          - intents.yaml
        pattern_files:    # named patterns are merged
          - patterns.yaml

    Args:
        path: Path to main scenario YAML file.
        intents_path: Optional explicit path to intents.yaml.
            If None, uses config or auto-discovers intents.yaml.

    Returns:
        Parsed scenario dict with merged states, intents, and patterns.
    """
    p = Path(path)
    project_dir = p.parent
    entry_file = p.name

    # Parse the entry file
    dsl_text = p.read_text(encoding="utf-8")
    scenario = parse_dsl(dsl_text)

    # Load project config
    config = _load_config(project_dir)

    # -- Merge additional scenario files --
    scenario_files = config.get("scenario_files", [])
    if scenario_files:
        merged_states: dict[str, Any] = {}
        for fname in scenario_files:
            if fname == entry_file:
                continue
            fpath = project_dir / fname
            if not fpath.exists():
                continue
            extra_states = _parse_states_from_file(fpath)
            merged_states.update(extra_states)
        # Entry file states have highest priority (override extras)
        merged_states.update({
            k: v for k, v in scenario["states"].items() if k != "__meta__"
        })
        # Preserve __meta__
        if "__meta__" in scenario["states"]:
            merged_states["__meta__"] = scenario["states"]["__meta__"]
        scenario["states"] = merged_states

    # -- Load intents --
    all_intents: dict[str, list[str]] = {}

    # From config intent_files
    intent_files = config.get("intent_files", [])
    if intent_files:
        for fname in intent_files:
            file_intents = load_intents_yaml(project_dir / fname)
            for name, phrases in file_intents.items():
                all_intents.setdefault(name, []).extend(phrases)
    elif intents_path is not None:
        # Explicit intents path
        all_intents.update(load_intents_yaml(intents_path))
    else:
        # Auto-discover intents.yaml next to scenario file
        auto_path = project_dir / "intents.yaml"
        if auto_path.exists():
            all_intents.update(load_intents_yaml(auto_path))

    # Inline intents override external on conflict
    if all_intents:
        all_intents.update(scenario["intents"])
        scenario["intents"] = all_intents
    # If no external intents, scenario["intents"] already has inline ones

    # -- Load named patterns --
    pattern_files = config.get("pattern_files", ["patterns.yaml"])
    patterns = _load_patterns(project_dir, pattern_files)
    scenario["named_patterns"] = patterns

    # -- Load knowledge file --
    knowledge_file = scenario.get("knowledge_file")
    if knowledge_file:
        knowledge_path = project_dir / knowledge_file
        if knowledge_path.exists():
            try:
                scenario["knowledge"] = knowledge_path.read_text(encoding="utf-8")
            except Exception:
                scenario["knowledge"] = ""
        else:
            scenario["knowledge"] = ""
    else:
        scenario["knowledge"] = ""

    return scenario
