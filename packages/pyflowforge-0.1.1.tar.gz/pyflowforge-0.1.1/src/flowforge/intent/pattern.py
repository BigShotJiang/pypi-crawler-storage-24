"""
pattern_matcher.py — FlowForge pattern syntax.

Syntax (type: pattern):
  word       — exact word  (\\bword\\b, case-insensitive)
  word*      — prefix      (\\bword\\w*)
  *          — any words   (matches anything in between)
  (A | B)    — alternation
  [X]        — optional X
  {A * B}    — A AND B in any order (both required), * = separator
  $name      — named pattern reference (from patterns.yaml)
"""

from __future__ import annotations

import re
from itertools import permutations
from typing import Optional


class PatternSyntaxError(ValueError):
    pass


class _Parser:
    def __init__(self, src: str, named: dict[str, str]):
        self.src = src
        self.named = named
        self.pos = 0

    def _ws(self) -> None:
        while self.pos < len(self.src) and self.src[self.pos] == ' ':
            self.pos += 1

    def _peek(self) -> Optional[str]:
        self._ws()
        return self.src[self.pos] if self.pos < len(self.src) else None

    def parse_top(self) -> str:
        return self._seq('')

    def _seq(self, stop: str) -> str:
        parts: list[str] = []
        while True:
            self._ws()
            if self.pos >= len(self.src):
                break
            c = self.src[self.pos]
            if c in stop:
                break
            if c == '|':
                return self._alt(parts, stop)
            a = self._atom(stop + '|')
            if a is not None:
                parts.append(a)
        return ''.join(parts)

    def _alt(self, first: list[str], stop: str) -> str:
        alts = [''.join(first)]
        while self.pos < len(self.src) and self.src[self.pos] == '|':
            self.pos += 1
            parts: list[str] = []
            while self.pos < len(self.src):
                c = self.src[self.pos]
                if c in stop or c == '|':
                    break
                a = self._atom(stop + '|')
                if a is not None:
                    parts.append(a)
            alts.append(''.join(parts))
        return '(?:' + '|'.join(alts) + ')'

    def _atom(self, stop: str) -> Optional[str]:
        self._ws()
        if self.pos >= len(self.src):
            return None
        c = self.src[self.pos]
        if c in stop:
            return None
        if c == '(':
            return self._group()
        if c == '[':
            return self._optional()
        if c == '{':
            return self._bag()
        if c == '$':
            return self._named()
        if c == '*':
            self.pos += 1
            return r'[\s\S]*?'
        return self._word()

    def _group(self) -> str:
        self.pos += 1
        inner = self._seq(')')
        if self.pos < len(self.src) and self.src[self.pos] == ')':
            self.pos += 1
        return f'(?:{inner})'

    def _optional(self) -> str:
        self.pos += 1
        inner = self._seq(']')
        if self.pos < len(self.src) and self.src[self.pos] == ']':
            self.pos += 1
        return f'(?:{inner})?'

    def _bag(self) -> str:
        self.pos += 1
        elements: list[str] = []
        cur: list[str] = []

        while self.pos < len(self.src) and self.src[self.pos] != '}':
            self._ws()
            if self.pos >= len(self.src) or self.src[self.pos] == '}':
                break
            c = self.src[self.pos]
            if c == '*':
                if cur:
                    elements.append(''.join(cur))
                    cur = []
                self.pos += 1
            elif c == '|':
                alt = self._alt(cur, '}*')
                cur = [alt]
            else:
                a = self._atom('}*|')
                if a:
                    cur.append(a)

        if cur:
            elements.append(''.join(cur))
        if self.pos < len(self.src) and self.src[self.pos] == '}':
            self.pos += 1

        if not elements:
            return ''
        if len(elements) == 1:
            return elements[0]

        elems = elements[:3]
        perm_strs = [r'[\s\S]*?'.join(p) for p in permutations(elems)]
        return '(?:' + '|'.join(perm_strs) + ')'

    def _named(self) -> str:
        self.pos += 1
        j = self.pos
        while j < len(self.src) and (self.src[j].isalnum() or self.src[j] == '_'):
            j += 1
        name = self.src[self.pos:j]
        self.pos = j
        if name in self.named:
            return f'(?:{self.named[name]})'
        return r'\b' + re.escape(name) + r'\b'

    def _word(self) -> str:
        j = self.pos
        special = set(' ()[]{}|*$')
        while j < len(self.src) and self.src[j] not in special:
            j += 1
        word = self.src[self.pos:j]
        self.pos = j

        star = self.pos < len(self.src) and self.src[self.pos] == '*'
        if star:
            self.pos += 1

        if not word:
            return ''

        escaped = re.escape(word)
        if star:
            return r'\b' + escaped + r'\w*'
        return r'\b' + escaped + r'\b'


def compile_pattern(
    pattern: str,
    named_patterns: dict[str, str] | None = None,
) -> re.Pattern:
    """Compile a FlowForge pattern string to a Python re.Pattern."""
    parser = _Parser(pattern.strip(), named_patterns or {})
    regex_str = parser.parse_top()
    try:
        return re.compile(regex_str, re.IGNORECASE | re.UNICODE)
    except re.error as exc:
        raise PatternSyntaxError(
            f"Pattern '{pattern}' → invalid regex '{regex_str}': {exc}"
        ) from exc


def match_pattern(
    pattern: str,
    text: str,
    named_patterns: dict[str, str] | None = None,
) -> bool:
    """Return True if text matches FlowForge pattern anywhere."""
    try:
        return bool(compile_pattern(pattern, named_patterns).search(text))
    except PatternSyntaxError:
        try:
            return bool(re.search(pattern, text, re.IGNORECASE | re.UNICODE))
        except re.error:
            return False
