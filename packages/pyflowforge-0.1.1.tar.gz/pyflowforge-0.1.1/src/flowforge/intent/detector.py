"""
IntentDetector — maps user messages to transitions.

Trigger type pipeline (checked in order of speed):
  1. type: regex   — plain Python re.search
  2. type: pattern — pattern matching syntax
  3. type: intent  — classifiers chain (TF-IDF, custom, etc.)
"""

from __future__ import annotations

import re
from typing import Any

from .protocol import IntentClassifier
from .pattern import match_pattern


class IntentDetector:
    def __init__(
        self,
        classifiers: list[IntentClassifier] | None = None,
        named_patterns: dict[str, str] | None = None,
    ) -> None:
        self._classifiers: list[IntentClassifier] = list(classifiers or [])
        self.named_patterns: dict[str, str] = named_patterns or {}

    def add_classifier(self, clf: IntentClassifier) -> None:
        """Add a classifier to the chain."""
        self._classifiers.append(clf)

    # -- Low-level matchers --

    def match_regex(self, message: str, pattern: str) -> bool:
        """Plain Python re.search — case-insensitive."""
        try:
            return bool(re.search(pattern, message, re.IGNORECASE | re.UNICODE))
        except re.error:
            return False

    def match_cn_pattern(self, message: str, pattern: str) -> bool:
        """Pattern matching syntax."""
        return match_pattern(pattern, message, self.named_patterns or None)

    def _check_intent(self, message: str, intent_value: str) -> bool:
        """
        Classify message against a single intent name.
        Tries each classifier in order until one matches.
        """
        if intent_value in ("any", "*"):
            return True

        for clf in self._classifiers:
            if clf.trained:
                predicted, _score = clf.classify(message)
                if predicted == intent_value:
                    return True

        return False

    # -- Transition matching --

    def check_trigger(self, trigger: dict, message: str) -> bool:
        """Check a single trigger dict against message."""
        ttype = trigger.get("type", "intent")
        value = trigger.get("value", "")

        if ttype == "regex":
            return self.match_regex(message, value)
        if ttype == "pattern":
            return self.match_cn_pattern(message, value)
        if ttype in ("intent", "action"):
            return self._check_intent(message, value)
        return False

    def check_transition(self, transition: dict, message: str) -> bool:
        """
        Check if transition fires for message.

        Supports:
          - New format: when: [{type, value}, ...]  (OR-logic)
          - Old format: intent: <name>
        """
        when = transition.get("when")
        if when:
            # Evaluate in speed order: regex → pattern → intent
            regex_triggers = [t for t in when if t.get("type") == "regex"]
            pattern_triggers = [t for t in when if t.get("type") == "pattern"]
            intent_triggers = [
                t for t in when if t.get("type") not in ("regex", "pattern")
            ]

            for t in regex_triggers:
                if self.match_regex(message, t.get("value", "")):
                    return True

            for t in pattern_triggers:
                if self.match_cn_pattern(message, t.get("value", "")):
                    return True

            for t in intent_triggers:
                if self._check_intent(message, t.get("value", "")):
                    return True

            return False

        # Old format: intent field
        intent = transition.get("intent", "any")
        return self._check_intent(message, intent)
