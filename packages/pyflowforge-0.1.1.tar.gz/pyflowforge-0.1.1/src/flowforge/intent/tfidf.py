"""
TF-IDF intent classifier — zero external dependencies.

Trains on example phrases and classifies new text using cosine similarity
of TF-IDF vectors.
"""

from __future__ import annotations

import math
import re
from collections import Counter
from typing import Optional


def _tokenize(text: str) -> list[str]:
    """Lowercase + extract word tokens (Latin + Cyrillic)."""
    return re.findall(r'[а-яёa-z\w]+', text.lower(), re.UNICODE)


class TfIdfClassifier:
    """
    Lightweight TF-IDF intent classifier with cosine-similarity ranking.

    Usage::

        clf = TfIdfClassifier()
        clf.train({"ask_price": ["цена?", "сколько стоит"], "help": ["помогите"]})
        intent, score = clf.classify("сколько стоит услуга?")
    """

    def __init__(self) -> None:
        self.labels: list[str] = []
        self.phrase_vecs: list[dict[str, float]] = []
        self.idf: dict[str, float] = {}
        self._trained: bool = False

    @property
    def trained(self) -> bool:
        return self._trained

    def train(self, intents: dict[str, list[str]]) -> None:
        """
        Train on intents = {intent_name: [phrase, ...]}.
        Replaces any previous training.
        """
        all_tokens: list[list[str]] = []
        labels: list[str] = []

        for intent_name, phrases in intents.items():
            for phrase in phrases:
                tokens = _tokenize(phrase)
                if tokens:
                    all_tokens.append(tokens)
                    labels.append(intent_name)

        if not all_tokens:
            return

        N = len(all_tokens)

        # IDF with Laplace smoothing
        df: Counter = Counter()
        for tokens in all_tokens:
            for w in set(tokens):
                df[w] += 1
        self.idf = {w: math.log((N + 1) / (cnt + 1)) + 1.0 for w, cnt in df.items()}

        self.labels = labels
        self.phrase_vecs = [self._tfidf(t) for t in all_tokens]
        self._trained = True

    def _tfidf(self, tokens: list[str]) -> dict[str, float]:
        tf = Counter(tokens)
        total = len(tokens) or 1
        return {w: (cnt / total) * self.idf.get(w, 0.0) for w, cnt in tf.items()}

    @staticmethod
    def _cosine(a: dict[str, float], b: dict[str, float]) -> float:
        dot = sum(a.get(w, 0.0) * v for w, v in b.items())
        na = math.sqrt(sum(x * x for x in a.values())) or 1e-9
        nb = math.sqrt(sum(x * x for x in b.values())) or 1e-9
        return dot / (na * nb)

    def classify(
        self,
        text: str,
        threshold: float = 0.15,
    ) -> tuple[Optional[str], float]:
        """
        Classify text. Returns (intent_name, score) or (None, score)
        if the best score is below threshold.
        """
        if not self._trained or not self.phrase_vecs:
            return None, 0.0

        query_tokens = _tokenize(text)
        if not query_tokens:
            return None, 0.0

        query_vec = self._tfidf(query_tokens)
        if not query_vec:
            return None, 0.0

        scores = [self._cosine(query_vec, pv) for pv in self.phrase_vecs]
        best_idx = max(range(len(scores)), key=lambda i: scores[i])
        best_score = scores[best_idx]

        if best_score < threshold:
            return None, best_score

        return self.labels[best_idx], best_score

    def known_intents(self) -> list[str]:
        """Return sorted list of unique intent names."""
        return sorted(set(self.labels))
