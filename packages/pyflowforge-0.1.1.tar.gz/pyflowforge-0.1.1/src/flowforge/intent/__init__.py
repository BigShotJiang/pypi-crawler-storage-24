"""Intent detection system — pluggable classifiers and trigger matching."""

from .protocol import IntentClassifier
from .tfidf import TfIdfClassifier
from .detector import IntentDetector

__all__ = ["IntentClassifier", "TfIdfClassifier", "IntentDetector"]
