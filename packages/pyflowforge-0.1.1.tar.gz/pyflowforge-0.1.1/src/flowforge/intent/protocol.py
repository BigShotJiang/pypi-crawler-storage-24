"""IntentClassifier protocol — interface for pluggable classifiers."""

from __future__ import annotations

from typing import Protocol, runtime_checkable


@runtime_checkable
class IntentClassifier(Protocol):
    """
    Protocol for intent classifiers.

    Implement this to create custom classifiers (LLM-based, embedding-based, etc.).

    Example::

        class MyClassifier:
            @property
            def trained(self) -> bool:
                return True

            def classify(self, text: str) -> tuple[str | None, float]:
                # your classification logic
                return "greeting", 0.95
    """

    def classify(self, text: str) -> tuple[str | None, float]:
        """
        Classify text into an intent.

        Returns:
            (intent_name, confidence) or (None, 0.0) if no match.
        """
        ...

    @property
    def trained(self) -> bool:
        """Whether the classifier is ready for inference."""
        ...
