"""
Conversation Engine — synchronous pipeline for processing user messages.

Pipeline (two-phase transition system):
  1. Check response_transitions of current state (answers to bot's question)
  2. If no match → check auto_transitions of current state
  3. If no match → go to fallback_state (or stay)
  4. Pipeline through routing states (no responses → follow auto_transitions, max depth: 20)
  5. Execute run actions of final state
  6. Generate response from responses of final state
"""

from __future__ import annotations

import logging
import random
import re
from typing import Any

from .intent.detector import IntentDetector
from .actions import ActionRegistry
from .context import Context

logger = logging.getLogger("flowforge")

_MAX_ROUTING_DEPTH = 20


def _interpolate(template: str, variables: dict[str, Any]) -> str:
    """Replace {var} placeholders with values from variables dict."""
    stripped = template.strip()
    if re.fullmatch(r'[A-Za-z_]\w*', stripped) and stripped in variables:
        val = variables[stripped]
        return str(val) if val is not None else template

    def replace(m: re.Match) -> str:
        key = m.group(1)
        val = variables.get(key)
        return str(val) if val is not None else m.group(0)

    return re.sub(r'\{([A-Za-z_]\w*)\}', replace, template)


def _is_routing_state(state: dict) -> bool:
    """A routing state has no responses and no response_transitions."""
    return not bool(state.get("responses")) and not bool(state.get("response_transitions"))


def _get_run(state: dict) -> list:
    return state.get("run") or state.get("actions", [])


def _get_auto_transitions(state: dict) -> list:
    return state.get("auto_transitions") or state.get("transitions", [])


def _get_response_transitions(state: dict) -> list:
    return state.get("response_transitions", [])


class ConversationEngine:
    def __init__(
        self,
        intent_detector: IntentDetector,
        action_registry: ActionRegistry,
        llm_provider: Any | None = None,
        knowledge: str = "",
    ) -> None:
        self.intent_detector = intent_detector
        self.action_registry = action_registry
        self.llm_provider = llm_provider
        self.knowledge = knowledge

    def _find_matching_transition(
        self,
        transitions: list,
        message: str,
    ) -> dict | None:
        """Return first matching transition dict, or None."""
        for t in transitions:
            if self.intent_detector.check_transition(t, message):
                return t
        return None

    def _find_global_transition(
        self,
        states: dict[str, Any],
        current_state_id: str,
        message: str,
        context_vars: dict[str, Any],
    ) -> tuple[str | None, str]:
        """
        Called when current state produced no match.
        Priority:
          1. general states (auto_transitions)
          2. specify states — saves fragment in context[accumulate_from]
        Returns (next_state_id, detected_intent) or (None, "none").
        """
        # 1. Try general states
        for state_id, state_data in states.items():
            if state_id in ("__meta__", current_state_id):
                continue
            if state_data.get("type", "general") != "general":
                continue
            match = self._find_matching_transition(
                _get_auto_transitions(state_data), message
            )
            if match:
                intent = self._transition_intent(match)
                return match.get("target"), intent

        # 2. Try specify states
        for state_id, state_data in states.items():
            if state_id == "__meta__":
                continue
            if state_data.get("type") != "specify":
                continue
            match = self._find_matching_transition(
                _get_auto_transitions(state_data), message
            )
            if match:
                key = state_data.get("accumulate_from")
                if key:
                    context_vars[key] = message
                intent = self._transition_intent(match)
                return state_id, intent

        return None, "none"

    @staticmethod
    def _transition_intent(transition: dict) -> str:
        if "when" in transition:
            triggers = transition["when"]
            return " | ".join(
                f"{tr.get('type', 'intent')}:{tr.get('value', '')}"
                for tr in triggers
            )
        return transition.get("intent", "any")

    def process(
        self,
        message: str,
        current_state_id: str,
        scenario_states: dict[str, Any],
        context: Context,
    ) -> dict[str, Any]:
        """
        Process a user message and return the engine result.

        Returns:
            {
                response: str,
                new_state: str,
                intent: str,
                actions_executed: list[str],
            }
        """
        meta = scenario_states.get("__meta__", {})
        fallback_state = meta.get("fallback_state")
        fallback_mode = meta.get("fallback_mode")

        current_state = scenario_states.get(current_state_id, {})
        is_specify = current_state.get("type") == "specify"

        logger.debug("[%s] message=%r  state=%s", context.session_id, message, current_state_id)

        # -- Phase 1: Check response_transitions --
        matched_transition = self._find_matching_transition(
            _get_response_transitions(current_state), message
        )
        if matched_transition is not None:
            logger.debug("[%s] phase1: response_transition matched → %s",
                         context.session_id, matched_transition.get("target"))
        if matched_transition is None and is_specify:
            key = current_state.get("accumulate_from", "")
            accumulated = context.vars.get(key, "") if key else ""
            if accumulated and accumulated.lower() not in message.lower():
                combined = accumulated + " " + message
                logger.debug("[%s] phase1: specify — combined=%r", context.session_id, combined)
                matched_transition = self._find_matching_transition(
                    _get_response_transitions(current_state), combined
                )

        # -- Phase 2: Check auto_transitions --
        if matched_transition is None:
            matched_transition = self._find_matching_transition(
                _get_auto_transitions(current_state), message
            )
            if matched_transition is not None:
                logger.debug("[%s] phase2: auto_transition matched → %s",
                             context.session_id, matched_transition.get("target"))
            else:
                logger.debug("[%s] phase2: no match in current state", context.session_id)

        # -- Phase 3: Determine next state --
        detected_intent = "none"
        use_llm_fallback = False
        if matched_transition is not None:
            next_state_id = matched_transition["target"]
            detected_intent = self._transition_intent(matched_transition)
        else:
            global_next, detected_intent = self._find_global_transition(
                scenario_states, current_state_id, message, context.vars
            )
            if global_next is not None:
                next_state_id = global_next
                logger.debug("[%s] phase3: global search → %s (%s)",
                             context.session_id, next_state_id, detected_intent)
            elif fallback_mode == "llm" and self.llm_provider is not None:
                use_llm_fallback = True
                next_state_id = current_state_id
                logger.debug("[%s] phase3: LLM fallback", context.session_id)
            elif fallback_state and fallback_state in scenario_states:
                next_state_id = fallback_state
                logger.debug("[%s] phase3: fallback state → %s", context.session_id, fallback_state)
            else:
                next_state_id = current_state_id
                logger.debug("[%s] phase3: no match, staying in %s", context.session_id, current_state_id)

        # -- Phase 4: Pipeline through routing states --
        depth = 0
        while depth < _MAX_ROUTING_DEPTH:
            next_state = scenario_states.get(next_state_id, {})
            if not _is_routing_state(next_state):
                break
            routing_match = self._find_matching_transition(
                _get_auto_transitions(next_state), message
            )
            if routing_match is None:
                break
            next_state_id = routing_match["target"]
            logger.debug("[%s] phase4: routing %s → %s", context.session_id,
                         next_state.get("id", "?"), next_state_id)
            depth += 1

        next_state = scenario_states.get(next_state_id, current_state)

        # -- Phase 5: Execute run actions --
        actions_executed: list[str] = []
        for action in _get_run(next_state):
            context.state = next_state_id
            logger.debug("[%s] phase5: executing action %s", context.session_id, action)
            result = self.action_registry.execute(action, context)
            if result:
                actions_executed.append(str(action))
                context.vars.update(result)

        # Check if state handler queued responses or forced a goto
        if context._goto_state:
            logger.debug("[%s] phase5: goto → %s", context.session_id, context._goto_state)
            next_state_id = context._goto_state
            next_state = scenario_states.get(next_state_id, next_state)
            context._goto_state = None

        # -- Phase 6: Generate response --
        if use_llm_fallback:
            # LLM fallback — generate response via LLM provider
            history = [
                {"role": entry["role"], "content": entry["content"]}
                for entry in context.history
            ]
            try:
                response = self.llm_provider.generate(
                    message=message,
                    history=history,
                    knowledge=self.knowledge,
                )
            except Exception as exc:
                logger.error("[%s] LLM fallback error: %s", context.session_id, exc)
                response = "..."
            detected_intent = "llm_fallback"
        elif context._responses:
            response = "\n".join(context._responses)
            context._responses = []
        else:
            responses = next_state.get("responses", [])
            if responses:
                raw = random.choice(responses)
                response = _interpolate(str(raw), context.vars)
            else:
                response = "..."

        logger.debug("[%s] result: state=%s → %s  intent=%s  response=%r",
                     context.session_id, current_state_id, next_state_id,
                     detected_intent, response[:80])

        # Update history
        context.history.append({
            "role": "user", "content": message, "state": current_state_id
        })
        context.history.append({
            "role": "assistant", "content": response, "state": next_state_id
        })

        return {
            "response": response,
            "new_state": next_state_id,
            "intent": detected_intent,
            "actions_executed": actions_executed,
        }

    def get_initial_messages(
        self, scenario_states: dict[str, Any], initial_state_id: str
    ) -> list[str]:
        """Get initial bot messages for a new session."""
        state = scenario_states.get(initial_state_id, {})
        responses = state.get("responses", [])
        return responses[:1] if responses else []
