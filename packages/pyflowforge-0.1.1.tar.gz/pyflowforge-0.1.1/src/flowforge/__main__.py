"""CLI entry point: python -m flowforge test <scenario> [tests.qa.yaml]"""

from __future__ import annotations

import sys
from pathlib import Path


def main() -> None:
    args = sys.argv[1:]

    if not args or args[0] != "test":
        print("Usage: python -m flowforge test <scenario.yaml> [tests.qa.yaml]")
        sys.exit(1)

    if len(args) < 2:
        print("Usage: python -m flowforge test <scenario.yaml> [tests.qa.yaml]")
        sys.exit(1)

    scenario_path = Path(args[1])
    if not scenario_path.exists():
        print(f"Scenario file not found: {scenario_path}")
        sys.exit(1)

    if len(args) > 2:
        test_path = Path(args[2])
    else:
        # Auto-discover *.qa.yaml next to scenario
        candidates = sorted(scenario_path.parent.glob("*.qa.yaml"))
        if not candidates:
            print(f"No .qa.yaml files found next to {scenario_path}")
            sys.exit(1)
        test_path = candidates[0]

    if not test_path.exists():
        print(f"Test file not found: {test_path}")
        sys.exit(1)

    from .bot import Bot
    from .testing import load_test_file, run_tests, format_results

    bot = Bot.from_yaml(scenario_path)
    test_data = load_test_file(test_path)
    results = run_tests(bot, test_data)
    print(format_results(results))
    sys.exit(0 if results.ok else 1)


if __name__ == "__main__":
    main()
