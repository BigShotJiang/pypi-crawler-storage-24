"""
Ready-made LLM providers for FlowForge.

These are convenience wrappers — you can always write your own class
that implements the LLMProvider protocol instead.

Usage::

    from flowforge.contrib.llm import OpenAIProvider

    llm = OpenAIProvider(api_key="sk-...", model="gpt-4o-mini")
    bot = Bot.from_yaml("scenario.yaml", llm=llm)

Requires the corresponding SDK to be installed:
    pip install openai        # for OpenAIProvider
    pip install anthropic     # for AnthropicProvider
"""

from __future__ import annotations


class OpenAIProvider:
    """
    LLM provider using OpenAI Chat Completions API.

    Args:
        api_key: OpenAI API key.
        model: Model name (default: "gpt-4o-mini").
        system: System prompt prepended to every request.
        temperature: Sampling temperature (default: 0.7).
    """

    def __init__(
        self,
        api_key: str,
        model: str = "gpt-4o-mini",
        system: str = "",
        temperature: float = 0.7,
    ) -> None:
        try:
            import openai
        except ImportError:
            raise ImportError(
                "OpenAIProvider requires the 'openai' package. "
                "Install it with: pip install openai"
            )
        self._client = openai.OpenAI(api_key=api_key)
        self._model = model
        self._system = system
        self._temperature = temperature

    @property
    def trained(self) -> bool:
        return True

    def generate(
        self,
        message: str,
        history: list[dict[str, str]],
        knowledge: str = "",
    ) -> str:
        system = self._system
        if knowledge:
            system = (system + "\n\n" if system else "") + (
                "Use the following knowledge base to answer questions. "
                "If the answer is not in the knowledge base, say you don't know.\n\n"
                f"{knowledge}"
            )

        messages: list[dict[str, str]] = []
        if system:
            messages.append({"role": "system", "content": system})
        for entry in history:
            messages.append({
                "role": entry.get("role", "user"),
                "content": entry.get("content", ""),
            })
        messages.append({"role": "user", "content": message})

        response = self._client.chat.completions.create(
            model=self._model,
            messages=messages,
            temperature=self._temperature,
        )
        return response.choices[0].message.content or ""


class AnthropicProvider:
    """
    LLM provider using Anthropic Messages API.

    Args:
        api_key: Anthropic API key.
        model: Model name (default: "claude-sonnet-4-20250514").
        system: System prompt prepended to every request.
        max_tokens: Maximum tokens in response (default: 1024).
        temperature: Sampling temperature (default: 0.7).
    """

    def __init__(
        self,
        api_key: str,
        model: str = "claude-sonnet-4-20250514",
        system: str = "",
        max_tokens: int = 1024,
        temperature: float = 0.7,
    ) -> None:
        try:
            import anthropic
        except ImportError:
            raise ImportError(
                "AnthropicProvider requires the 'anthropic' package. "
                "Install it with: pip install anthropic"
            )
        self._client = anthropic.Anthropic(api_key=api_key)
        self._model = model
        self._system = system
        self._max_tokens = max_tokens
        self._temperature = temperature

    @property
    def trained(self) -> bool:
        return True

    def generate(
        self,
        message: str,
        history: list[dict[str, str]],
        knowledge: str = "",
    ) -> str:
        system = self._system
        if knowledge:
            system = (system + "\n\n" if system else "") + (
                "Use the following knowledge base to answer questions. "
                "If the answer is not in the knowledge base, say you don't know.\n\n"
                f"{knowledge}"
            )

        messages: list[dict[str, str]] = []
        for entry in history:
            messages.append({
                "role": entry.get("role", "user"),
                "content": entry.get("content", ""),
            })
        messages.append({"role": "user", "content": message})

        response = self._client.messages.create(
            model=self._model,
            system=system or "You are a helpful assistant.",
            messages=messages,
            max_tokens=self._max_tokens,
            temperature=self._temperature,
        )
        return response.content[0].text
