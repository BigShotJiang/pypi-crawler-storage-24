"""FlowForge contrib — optional integrations (LLM providers, etc.)."""
