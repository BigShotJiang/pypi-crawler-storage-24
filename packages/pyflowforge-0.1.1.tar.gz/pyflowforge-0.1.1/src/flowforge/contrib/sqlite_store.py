"""SQLite session store — persists sessions to a local database file."""

from __future__ import annotations

import json
import sqlite3
from pathlib import Path

from ..context import Context
from ..session import context_to_dict, context_from_dict


class SqliteStore:
    """
    Persistent session store backed by SQLite.

    Sessions survive bot restarts. Good for single-process deployments.

    Usage::

        from flowforge.contrib.sqlite_store import SqliteStore

        bot = Bot.from_yaml("scenario.yaml", session_store=SqliteStore("sessions.db"))

    Args:
        path: Path to SQLite database file. Created automatically if it doesn't exist.
    """

    def __init__(self, path: str | Path = "sessions.db") -> None:
        self._path = str(path)
        self._conn = sqlite3.connect(self._path)
        self._conn.execute(
            "CREATE TABLE IF NOT EXISTS sessions ("
            "  session_id TEXT PRIMARY KEY,"
            "  data TEXT NOT NULL"
            ")"
        )
        self._conn.commit()

    def load(self, session_id: str) -> Context | None:
        """Load a session from the database."""
        row = self._conn.execute(
            "SELECT data FROM sessions WHERE session_id = ?",
            (session_id,),
        ).fetchone()
        if row is None:
            return None
        try:
            data = json.loads(row[0])
            return context_from_dict(data)
        except (json.JSONDecodeError, KeyError):
            return None

    def save(self, session_id: str, context: Context) -> None:
        """Save a session to the database."""
        data = json.dumps(context_to_dict(context), ensure_ascii=False)
        self._conn.execute(
            "INSERT OR REPLACE INTO sessions (session_id, data) VALUES (?, ?)",
            (session_id, data),
        )
        self._conn.commit()

    def delete(self, session_id: str) -> None:
        """Delete a session from the database."""
        self._conn.execute(
            "DELETE FROM sessions WHERE session_id = ?",
            (session_id,),
        )
        self._conn.commit()

    def close(self) -> None:
        """Close the database connection."""
        self._conn.close()
