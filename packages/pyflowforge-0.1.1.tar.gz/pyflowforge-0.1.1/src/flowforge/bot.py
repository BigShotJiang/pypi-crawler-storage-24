"""Bot — the main entry point for FlowForge headless library."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

from .context import Context
from .engine import ConversationEngine
from .actions import ActionRegistry
from .intent.detector import IntentDetector
from .intent.tfidf import TfIdfClassifier
from .intent.protocol import IntentClassifier
from .llm import LLMProvider
from .parser import load_scenario, parse_dsl
from .session import SessionStore, MemoryStore

logger = logging.getLogger("flowforge")


@dataclass
class BotResponse:
    """Response returned by Bot.send()."""
    text: str
    state: str
    intent: str | None = None
    context: dict[str, Any] = field(default_factory=dict)


class Bot:
    """
    Main class for building conversational bots.

    Usage::

        bot = Bot.from_yaml("scenario.yaml")

        @bot.action("get_price")
        def get_price(ctx):
            return {"price": 100}

        response = bot.send("How much?")
        print(response.text)

        bot.run()  # interactive console REPL
    """

    def __init__(
        self,
        session_store: SessionStore | None = None,
        verbose: bool = False,
    ) -> None:
        self._scenario: dict[str, Any] = {}
        self._states: dict[str, Any] = {}
        self._initial_state: str = "start"
        self._session_store: SessionStore = session_store or MemoryStore()
        self._action_registry = ActionRegistry()
        self._intent_detector = IntentDetector()
        self._llm_provider: Any | None = None
        self._knowledge: str = ""
        self._engine = ConversationEngine(self._intent_detector, self._action_registry)
        self._state_handlers: dict[str, Callable] = {}
        self._fallback_handler: Callable | None = None

        if verbose:
            _setup_verbose_logging()

    @classmethod
    def from_yaml(
        cls,
        path: str | Path,
        intents: str | Path | None = None,
        classifier: IntentClassifier | None = None,
        llm: Any | None = None,
        session_store: SessionStore | None = None,
        verbose: bool = False,
    ) -> "Bot":
        """
        Load bot from a YAML scenario file.

        Args:
            path: Path to scenario YAML file (e.g. "scenario.yaml").
            intents: Optional path to intents.yaml.
                If None, auto-discovers intents.yaml next to the scenario file.
            classifier: Optional custom IntentClassifier.
                If provided, used instead of the built-in TF-IDF classifier.
            llm: Optional LLM provider for LLM fallback.
                Must implement LLMProvider protocol (generate method).
            session_store: Optional session store for persistence.
                Default: MemoryStore (in-memory, lost on restart).
            verbose: If True, enable debug logging to stderr.
        """
        bot = cls(session_store=session_store, verbose=verbose)
        scenario = load_scenario(path, intents)
        bot._load_scenario(scenario, classifier=classifier, llm=llm)
        bot._action_registry.project_path = Path(path).parent
        return bot

    @classmethod
    def from_dict(
        cls,
        scenario: dict[str, Any],
        classifier: IntentClassifier | None = None,
        llm: Any | None = None,
        session_store: SessionStore | None = None,
        verbose: bool = False,
    ) -> "Bot":
        """
        Load bot from a pre-parsed scenario dict.

        Useful for programmatic scenario construction or testing.

        Args:
            scenario: Pre-parsed scenario dict.
            classifier: Optional custom IntentClassifier.
                If provided, used instead of the built-in TF-IDF classifier.
            llm: Optional LLM provider for LLM fallback.
            session_store: Optional session store for persistence.
            verbose: If True, enable debug logging to stderr.
        """
        bot = cls(session_store=session_store, verbose=verbose)
        bot._load_scenario(scenario, classifier=classifier, llm=llm)
        return bot

    @classmethod
    def from_string(
        cls,
        yaml_text: str,
        classifier: IntentClassifier | None = None,
        llm: Any | None = None,
        session_store: SessionStore | None = None,
        verbose: bool = False,
    ) -> "Bot":
        """
        Load bot from a YAML string.

        Args:
            yaml_text: YAML scenario as a string.
            classifier: Optional custom IntentClassifier.
                If provided, used instead of the built-in TF-IDF classifier.
            llm: Optional LLM provider for LLM fallback.
            session_store: Optional session store for persistence.
            verbose: If True, enable debug logging to stderr.
        """
        bot = cls(session_store=session_store, verbose=verbose)
        scenario = parse_dsl(yaml_text)
        bot._load_scenario(scenario, classifier=classifier, llm=llm)
        return bot

    def _load_scenario(
        self,
        scenario: dict[str, Any],
        classifier: IntentClassifier | None = None,
        llm: Any | None = None,
    ) -> None:
        """Initialize bot from parsed scenario dict."""
        self._scenario = scenario
        self._states = scenario.get("states", {})
        self._initial_state = scenario.get("initial_state", "start")

        # Load named patterns
        named_patterns = scenario.get("named_patterns", {})
        if named_patterns:
            self._intent_detector.named_patterns = named_patterns

        intents = scenario.get("intents", {})
        if classifier is not None:
            # Use the custom classifier provided by the user
            self._intent_detector.add_classifier(classifier)
        elif intents:
            # Default: train built-in TF-IDF classifier
            clf = TfIdfClassifier()
            clf.train(intents)
            self._intent_detector.add_classifier(clf)

        # Set up LLM provider and knowledge
        self._llm_provider = llm
        self._knowledge = scenario.get("knowledge", "")
        self._engine = ConversationEngine(
            self._intent_detector,
            self._action_registry,
            llm_provider=llm,
            knowledge=self._knowledge,
        )

    # -- Decorators --

    def action(self, name: str) -> Callable:
        """
        Register a Python action handler.

        Usage::

            @bot.action("get_price")
            def get_price(ctx):
                return {"price": 100}
        """
        def decorator(func: Callable) -> Callable:
            self._action_registry.register(name, func)
            return func
        return decorator

    def state(self, name: str, **kwargs: Any) -> Callable:
        """
        Register a programmatic state handler.

        Usage::

            @bot.state("dynamic", initial=False)
            def dynamic(ctx):
                ctx.say("Dynamic response")
        """
        def decorator(func: Callable) -> Callable:
            self._state_handlers[name] = func
            # Add state to scenario if not exists
            if name not in self._states:
                self._states[name] = {
                    "id": name,
                    "name": name,
                    "type": kwargs.get("type", "general"),
                    "responses": [],
                    "run": [{"action": f"__state_handler_{name}"}],
                    "auto_transitions": kwargs.get("auto_transitions", []),
                    "response_transitions": kwargs.get("response_transitions", []),
                }
            # Register the state handler as an action
            self._action_registry.register(f"__state_handler_{name}", func)
            if kwargs.get("initial"):
                self._initial_state = name
            return func
        return decorator

    def fallback(self, func: Callable) -> Callable:
        """
        Register a custom fallback handler.

        Alternative to llm= parameter. Called when no transition matches
        and fallback mode is "llm" (or no fallback_state is set).

        The function receives a Context and should call ctx.say() to respond.

        Usage::

            @bot.fallback
            def my_fallback(ctx):
                # call any LLM or custom logic
                ctx.say("I don't know, but let me try...")
        """
        self._fallback_handler = func

        # Wrap as LLM provider for the engine
        class _CallableLLM:
            def __init__(self, handler: Callable) -> None:
                self._handler = handler

            def generate(self, message: str, history: list, knowledge: str = "") -> str:
                return ""  # unused — handler uses ctx.say() directly

        # We need a different approach: wrap as action in engine
        # Instead, set the llm_provider to call the handler
        class _FallbackAdapter:
            def __init__(self, handler: Callable) -> None:
                self._handler = handler

            def generate(self, message: str, history: list, knowledge: str = "") -> str:
                # Create a minimal context for the handler
                from .context import Context as Ctx
                ctx = Ctx(session_id="", state="")
                ctx.message = message
                ctx.history = [dict(h) for h in history]
                ctx.vars["knowledge"] = knowledge
                self._handler(ctx)
                if ctx._responses:
                    return "\n".join(ctx._responses)
                return "..."

        self._engine.llm_provider = _FallbackAdapter(func)
        # Enable llm fallback mode in __meta__
        if "__meta__" not in self._states:
            self._states["__meta__"] = {}
        self._states["__meta__"]["fallback_mode"] = "llm"
        return func

    def add_classifier(self, clf: IntentClassifier) -> None:
        """Add a custom intent classifier to the detection chain."""
        self._intent_detector.add_classifier(clf)

    # -- Session management --

    def _get_session(self, session_id: str) -> Context:
        """Get or create a session context."""
        ctx = self._session_store.load(session_id)
        if ctx is None:
            ctx = Context(
                session_id=session_id,
                state=self._initial_state,
            )
        return ctx

    def _save_session(self, session_id: str, ctx: Context) -> None:
        """Persist session to the store."""
        self._session_store.save(session_id, ctx)

    def reset_session(self, session_id: str = "default") -> None:
        """Reset a session to initial state."""
        self._session_store.delete(session_id)

    # -- Core API --

    def send(self, text: str, session_id: str = "default") -> BotResponse:
        """
        Send a message to the bot and get a response.

        Args:
            text: User message text.
            session_id: Session identifier (default: "default").

        Returns:
            BotResponse with text, state, intent, and context.
        """
        ctx = self._get_session(session_id)
        ctx.message = text

        result = self._engine.process(
            message=text,
            current_state_id=ctx.state,
            scenario_states=self._states,
            context=ctx,
        )

        ctx.state = result["new_state"]
        self._save_session(session_id, ctx)

        return BotResponse(
            text=result["response"],
            state=result["new_state"],
            intent=result["intent"],
            context=dict(ctx.vars),
        )

    def get_greeting(self, session_id: str = "default") -> str | None:
        """Get the initial greeting message (first response of initial state)."""
        messages = self._engine.get_initial_messages(self._states, self._initial_state)
        return messages[0] if messages else None

    # -- Testing --

    def test(self, path: str | Path) -> "TestRunResult":
        """
        Run tests from a .qa.yaml file against this bot.

        Args:
            path: Path to .qa.yaml test file.

        Returns:
            TestRunResult with pass/fail status for each test case.
        """
        from .testing import load_test_file, run_tests, TestRunResult
        test_data = load_test_file(Path(path))
        return run_tests(self, test_data)

    # -- Run loop --

    def run(self, session_id: str = "default") -> None:
        """
        Start an interactive console REPL.

        Type messages and see bot responses. Ctrl+C or 'quit' to exit.
        """
        greeting = self.get_greeting(session_id)
        if greeting:
            print(f"Bot: {greeting}")

        print("(Type 'quit' to exit)\n")

        try:
            while True:
                try:
                    user_input = input("You: ").strip()
                except EOFError:
                    break

                if not user_input:
                    continue
                if user_input.lower() in ("quit", "exit", "q"):
                    break

                response = self.send(user_input, session_id)
                print(f"Bot: {response.text}")
                if response.intent and response.intent != "none":
                    print(f"     [state: {response.state}, intent: {response.intent}]")
        except KeyboardInterrupt:
            pass

        print("\nBye!")


def _setup_verbose_logging() -> None:
    """Configure the 'flowforge' logger to print DEBUG messages to stderr."""
    fg_logger = logging.getLogger("flowforge")
    if not fg_logger.handlers:
        handler = logging.StreamHandler()
        handler.setFormatter(logging.Formatter(
            "%(asctime)s [flowforge] %(message)s", datefmt="%H:%M:%S"
        ))
        fg_logger.addHandler(handler)
    fg_logger.setLevel(logging.DEBUG)
