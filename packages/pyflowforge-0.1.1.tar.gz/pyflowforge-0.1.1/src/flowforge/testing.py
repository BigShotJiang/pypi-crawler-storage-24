"""
Testing — run automated tests against bot scenarios.

Supports two formats in .qa.yaml files:

1. Simple (legacy, compatible with FlowForge IDE):
   tests:
     greeting:
       - "hello"
       - "hi"

2. Extended (multi-turn conversations with assertions):
   conversations:
     - name: "Purchase flow"
       steps:
         - user: "hello"
           state: greeting
           response: "Welcome"
           context:
             price: 100
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, TYPE_CHECKING

import yaml

if TYPE_CHECKING:
    from .bot import Bot


@dataclass
class StepResult:
    """Result of a single test step."""
    index: int
    user_message: str
    passed: bool
    error: str | None = None
    expected_state: str | None = None
    actual_state: str | None = None
    expected_response: str | None = None
    actual_response: str | None = None


@dataclass
class TestCaseResult:
    """Result of a single test case (conversation)."""
    name: str
    passed: bool
    steps: list[StepResult] = field(default_factory=list)


@dataclass
class TestRunResult:
    """Result of running all test cases."""
    cases: list[TestCaseResult] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return all(c.passed for c in self.cases)

    @property
    def passed_count(self) -> int:
        return sum(1 for c in self.cases if c.passed)

    @property
    def failed_count(self) -> int:
        return sum(1 for c in self.cases if not c.passed)

    @property
    def summary(self) -> str:
        return f"{self.passed_count} passed, {self.failed_count} failed"


def load_test_file(path: Path) -> dict:
    """Load and normalize a .qa.yaml test file.

    Returns a dict with keys:
      - conversations: list of {name, steps: [{user, state?, response?, context?}]}
      - setup: {actions: {name: {key: value}}}
    """
    with open(path, encoding="utf-8") as f:
        raw = yaml.safe_load(f) or {}

    conversations: list[dict] = []

    # Legacy format: tests: {state_name: [phrases]}
    if "tests" in raw:
        for state_name, phrases in raw["tests"].items():
            if not isinstance(phrases, list):
                continue
            for phrase in phrases:
                conversations.append({
                    "name": f"{state_name}: {phrase}",
                    "steps": [{"user": str(phrase), "state": state_name}],
                })

    # Extended format: conversations: [{name, steps}]
    if "conversations" in raw:
        for conv in raw["conversations"]:
            conversations.append({
                "name": conv.get("name", "unnamed"),
                "steps": conv.get("steps", []),
            })

    setup = raw.get("setup", {})
    return {"conversations": conversations, "setup": setup}


def _check_response(expected: str, actual: str) -> bool:
    """Check if actual response matches expected.

    If expected is wrapped in /.../ — treat as regex.
    Otherwise — substring match.
    """
    if expected.startswith("/") and expected.endswith("/") and len(expected) > 2:
        pattern = expected[1:-1]
        return bool(re.search(pattern, actual))
    return expected in actual


def _check_context(expected: dict, actual: dict) -> str | None:
    """Check context variables. Returns error message or None."""
    for key, expected_val in expected.items():
        actual_val = actual.get(key)
        # Compare with type coercion for numeric values
        if actual_val != expected_val:
            # Try numeric comparison
            try:
                if float(actual_val) == float(expected_val):
                    continue
            except (TypeError, ValueError):
                pass
            return f"context[{key!r}]: expected {expected_val!r}, got {actual_val!r}"
    return None


def run_tests(bot: "Bot", test_data: dict) -> TestRunResult:
    """Execute all test cases against a bot instance."""
    conversations = test_data.get("conversations", [])
    setup = test_data.get("setup", {})
    mock_actions = setup.get("actions", {})

    # Save original action handlers and register mocks
    original_handlers: dict[str, Any] = {}
    for action_name, mock_result in mock_actions.items():
        if bot._action_registry.has(action_name):
            original_handlers[action_name] = bot._action_registry._handlers[action_name]
        mock_data = dict(mock_result) if isinstance(mock_result, dict) else {action_name: mock_result}
        bot._action_registry.register(action_name, lambda ctx, d=mock_data: d)

    try:
        results = TestRunResult()
        for conv in conversations:
            case_result = _run_conversation(bot, conv)
            results.cases.append(case_result)
        return results
    finally:
        # Restore original handlers
        for action_name in mock_actions:
            if action_name in original_handlers:
                bot._action_registry.register(action_name, original_handlers[action_name])
            else:
                bot._action_registry._handlers.pop(action_name, None)


def _run_conversation(bot: "Bot", conv: dict) -> TestCaseResult:
    """Run a single conversation test case."""
    name = conv.get("name", "unnamed")
    steps = conv.get("steps", [])
    session_id = "__test__"

    bot.reset_session(session_id)

    step_results: list[StepResult] = []
    case_passed = True

    for i, step in enumerate(steps, 1):
        user_msg = str(step.get("user", ""))
        expected_state = step.get("state")
        expected_response = step.get("response")
        expected_context = step.get("context")

        response = bot.send(user_msg, session_id=session_id)

        errors: list[str] = []

        # Check state
        if expected_state is not None and response.state != expected_state:
            errors.append(
                f"state: expected {expected_state!r}, got {response.state!r}"
            )

        # Check response text
        if expected_response is not None:
            if not _check_response(str(expected_response), response.text):
                errors.append(
                    f"response: expected {expected_response!r}, "
                    f"got {response.text!r}"
                )

        # Check context variables
        if expected_context is not None and isinstance(expected_context, dict):
            ctx_error = _check_context(expected_context, response.context)
            if ctx_error:
                errors.append(ctx_error)

        passed = len(errors) == 0
        if not passed:
            case_passed = False

        step_results.append(StepResult(
            index=i,
            user_message=user_msg,
            passed=passed,
            error="; ".join(errors) if errors else None,
            expected_state=expected_state,
            actual_state=response.state,
            expected_response=str(expected_response) if expected_response else None,
            actual_response=response.text,
        ))

    return TestCaseResult(name=name, passed=case_passed, steps=step_results)


def format_results(results: TestRunResult) -> str:
    """Format test results for CLI output."""
    lines: list[str] = []

    for case in results.cases:
        if case.passed:
            lines.append(f"  \033[32m✓\033[0m {case.name}")
        else:
            lines.append(f"  \033[31m✗\033[0m {case.name}")
            for step in case.steps:
                if not step.passed:
                    lines.append(
                        f"    step {step.index} ({step.user_message!r}): "
                        f"{step.error}"
                    )

    lines.append("")
    color = "\033[32m" if results.ok else "\033[31m"
    lines.append(f"{color}{results.summary}\033[0m")
    return "\n".join(lines)
