"""Context — conversation state holder passed to action handlers and state handlers."""

from __future__ import annotations

from typing import Any


class Context:
    """
    Conversation context passed to @bot.action() and @bot.state() handlers.

    Attributes:
        message: Current user message text.
        state: Current state ID.
        session_id: Session identifier.
        vars: User-defined variables (persisted across messages in session).
        history: Conversation history [{role, content, state}, ...].
    """

    def __init__(
        self,
        message: str = "",
        state: str = "",
        session_id: str = "default",
        vars: dict[str, Any] | None = None,
        history: list[dict] | None = None,
    ) -> None:
        self.message = message
        self.state = state
        self.session_id = session_id
        self.vars: dict[str, Any] = vars if vars is not None else {}
        self.history: list[dict] = history if history is not None else []
        self._responses: list[str] = []
        self._goto_state: str | None = None

    def say(self, text: str) -> None:
        """Queue a response message."""
        self._responses.append(text)

    def goto(self, state: str) -> None:
        """Force transition to a specific state."""
        self._goto_state = state

    def set(self, key: str, value: Any) -> None:
        """Set a context variable."""
        self.vars[key] = value

    def get(self, key: str, default: Any = None) -> Any:
        """Get a context variable."""
        return self.vars.get(key, default)
