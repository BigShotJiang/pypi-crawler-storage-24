# FlowForge DSL — Documentation

> Python framework for building conversational bots using the Object-Oriented DSL.

---

## Contents

1. [Quick Start](#quick-start)
2. [The Object-Oriented DSL](#oo-dsl)
3. [Scenario File — main.yaml](#scenario)
4. [Trigger Types (when)](#triggers)
   - [type: intent](#intent)
   - [type: regex](#regex)
   - [type: pattern — Pattern Syntax](#pattern)
5. [Intents](#intents)
6. [Actions — Calling Functions](#actions)
7. [Python API](#python-api)
8. [Pluggable Intent Classifiers](#classifiers)
9. [LLM Fallback](#llm-fallback)
10. [Knowledge Base](#knowledge)
11. [Persistent Sessions](#sessions)
12. [Debugging](#debugging)
13. [Connecting Channels (Telegram, etc.)](#channels)
14. [Multi-file Scenarios](#multi-file)
15. [Testing Scenarios](#testing)

---

## 1. Quick Start

```bash
pip install pyflowforge
```

Create `scenario.yaml`:

```yaml
scenario:
  name: hello_bot
  initial_state: start

states:
  start:
    responses:
      - "Hello! Ask about prices or say help."
    auto_transitions:
      - target: price_info
        when:
          - type: regex
            value: 'price|cost|how much'
      - target: help
        when:
          - type: regex
            value: 'help|support'

  price_info:
    responses:
      - "Our plans start at $10/month."
    auto_transitions:
      - target: start
        when:
          - type: intent
            value: '*'

  help:
    responses:
      - "I can help with pricing and orders."
    auto_transitions:
      - target: start
        when:
          - type: intent
            value: '*'
```

Run:

```python
from flowforge import Bot

bot = Bot.from_yaml("scenario.yaml")
bot.run()  # interactive console REPL
```

Or use programmatically:

```python
response = bot.send("how much does it cost?")
print(response.text)   # "Our plans start at $10/month."
print(response.state)  # "price_info"
```

---

## 2. The Object-Oriented DSL

FlowForge uses an **Object-Oriented DSL** (OO-DSL): the core organizing unit is not an abstract state machine node, but a **business object** — a topic, entity, or service concept your bot knows about.

### Objects, not states

Think of each `state:` as an **object** in your business domain:

| Traditional view | OO-DSL view |
|-----------------|-------------|
| State node | Business object (e.g. `price_info`, `order`, `help_center`) |
| Responses | What the object **says about itself** |
| `run:` actions | What the object **does** when activated |
| `auto_transitions` | **Incoming signals** this object listens for |
| `response_transitions` | **Follow-up actions** after the object has spoken |

### Why this matters

Organizing your bot around **objects** leads to:
- **Self-documenting code** — state names mirror your domain (`price_info`, `support_ticket`, `checkout`)
- **Natural handoffs** — "the Pricing object hands off to the Order object"
- **Easier maintenance** — add a new business topic by adding one object block

### Example — three business objects

```yaml
scenario:
  name: shop_bot
  initial_state: greeting

states:
  # Object: Greeting — entry point
  greeting:
    responses:
      - "Hi! Ask about prices, orders, or help."
    auto_transitions:
      - target: pricing
        when:
          - type: intent
            value: ask_price
      - target: support
        when:
          - type: intent
            value: help

  # Object: Pricing — knows everything about prices
  pricing:
    responses:
      - "Our plans start at $10/month. Want to order?"
    response_transitions:
      - target: order
        when:
          - type: regex
            value: 'yes|sure|ok'
      - target: greeting
        when:
          - type: regex
            value: 'no|back'

  # Object: Order — handles the purchase flow
  order:
    responses:
      - "Order confirmed! We'll email you shortly."
    auto_transitions:
      - target: greeting
        when:
          - type: intent
            value: '*'

  # Object: Support — handles help requests
  support:
    responses:
      - "I can help with pricing, orders, and account issues."
    auto_transitions:
      - target: greeting
        when:
          - type: intent
            value: '*'
```

### Routing objects

A **routing object** has no `responses` — it purely dispatches to the right object:

```yaml
  router:
    auto_transitions:
      - target: pricing
        when: [{type: intent, value: ask_price}]
      - target: support
        when: [{type: intent, value: help}]
```

The engine passes through it instantly (no reply to the user), following its `auto_transitions`. Maximum chain depth: 20.

---

## 3. Scenario File — main.yaml

```yaml
scenario:
  name: my_bot
  initial_state: start       # starting state (default: first state)
  fallback_state: unknown    # where to go if no transition matched (optional)

states:
  start:
    responses:
      - 'Hello! How can I help?'
      - 'Hi there! Ask me anything.'     # randomly selected
    auto_transitions:
      - target: price_info
        when:
          - type: intent
            value: ask_price
          - type: regex
            value: 'price|pricing|cost'   # OR logic within a transition
      - target: help_state
        when:
          - type: intent
            value: help

  price_info:
    run:
      - action: get_price                 # calls @bot.action("get_price")
    responses:
      - 'Price: {price} USD.'             # variable interpolation
    response_transitions:
      - target: confirm_order
        when:
          - type: regex
            value: 'yes|sure|ok'

  unknown:
    responses:
      - "Sorry, I didn't understand. Could you rephrase?"
    auto_transitions:
      - target: start
        when:
          - type: intent
            value: '*'
```

### Scenario Fields (`scenario:`)

| Field | Required | Description |
|-------|----------|-------------|
| `name` | yes | Scenario name |
| `initial_state` | no | Starting state (default: first state in the file) |
| `fallback` | no | What to do when no transition matches: `llm` (use LLM provider) or `state_name` (go to state). See [LLM Fallback](#llm-fallback). |
| `fallback_state` | no | Legacy syntax for `fallback: state_name`. Still works. |
| `knowledge` | no | Path to a knowledge base file (e.g. `knowledge.md`). Passed to LLM on fallback. See [Knowledge Base](#knowledge). |

### Object Fields (per state)

| Field | Required | Description |
|-------|----------|-------------|
| `responses` | no | What the object **says** — list of strings, one is chosen at random. |
| `auto_transitions` | no | Signals this object **listens for** — checked on every message. |
| `response_transitions` | no | **Follow-ups** after the object speaks — checked before `auto_transitions`. |
| `run` | no | What the object **does** before responding — list of actions. |
| `type` | no | `general` (default) or `specify` — see [State Types](#state-types-general-and-specify) below. |
| `accumulate_from` | no | Only for `specify` states. A variable name where the engine saves the user's incomplete message, so it can combine it with the next message. See [State Types](#state-types-general-and-specify) for a detailed example. |

### Transition Fields

| Field | Required | Description |
|-------|----------|-------------|
| `target` | yes | Target state ID |
| `when` | yes | List of triggers (OR logic — one match is enough) |

### Variable Interpolation in Responses

```yaml
responses:
  - 'Price: {price} USD'    # {var} placeholders
  - '{name}, welcome!'      # replaced from context variables
  - price                    # bare variable name → substituted with value
```

---

### State Types: `general` and `specify`

| Value | Description |
|-------|-------------|
| `general` | Standard state (default). Matches normally. |
| `specify` | **Clarification state.** Activates when the user said something incomplete — e.g. "order" without specifying *what* to order. The bot asks a follow-up question, then combines the two messages to understand the full intent. |

#### How `specify` works (step by step)

The problem: a user says "order" but doesn't say *what*. The bot needs to ask "What would you like to order?" and then combine the answer with the original message.

The `accumulate_from` field is a **variable name** (any name you choose) where the engine temporarily saves the user's incomplete message. On the next turn, the engine glues it together with the new message and re-checks the transitions.

You don't need to do anything with this variable yourself — the engine uses it internally. You just pick a name.

**Example — food ordering bot:**

```yaml
states:
  start:
    responses:
      - "How can I help?"
    auto_transitions:
      - when:
          - type: intent
            value: pizza
        target: pizza_flow
      - when:
          - type: intent
            value: sushi
        target: sushi_flow

  # This state catches "order" WITHOUT a specific food item
  order_clarify:
    type: specify
    accumulate_from: saved_fragment     # engine saves "order" here automatically
    responses:
      - "What exactly would you like to order?"
    auto_transitions:
      - when:
          - type: intent
            value: order                # triggers on bare "order" / "I want to order"
    response_transitions:
      - when:
          - type: intent
            value: pizza
        target: pizza_flow
      - when:
          - type: intent
            value: sushi
        target: sushi_flow
```

**What happens in a conversation:**

| Step | User says | What the engine does | Bot replies |
|------|-----------|---------------------|-------------|
| 1 | "order pizza" | Intent `pizza` matches a `general` state → `pizza_flow` | "Pizza ordered!" |
| 1 | "order" | No `general` state matches. `specify` state catches intent `order`. Engine saves `"order"` into `saved_fragment`. | "What exactly would you like to order?" |
| 2 | "pizza" | Engine combines `"order"` + `"pizza"` = `"order pizza"`. Checks `response_transitions` → intent `pizza` matches → `pizza_flow` | "Pizza ordered!" |

**The key idea:** the user's message was incomplete on step 1, so the bot asked for clarification. On step 2, the engine automatically combined both messages and matched the full intent.

#### Routing priority for each message

1. `response_transitions` / `auto_transitions` of the **current** state
2. `auto_transitions` of all **general** states (global search)
3. `auto_transitions` of all **specify** states (last resort — if nothing else matched)
4. `fallback_state` (or stay in current state)

---

## 4. Trigger Types

**Two-phase pipeline:**
1. First, `response_transitions` of the current state (answers to the bot's question).
2. If no match — `auto_transitions` of the current state.
3. If still no match — global search through all states, then `fallback_state`.

Check order within a single transition: **regex → pattern → intent** (fastest to slowest).
Within a single transition, **OR logic** applies: fires if at least one trigger matches.

---

### 4.1 type: intent

Classifies the message using a TF-IDF classifier (or custom pluggable classifier).

```yaml
- type: intent
  value: ask_price      # intent name from intents
```

Special values:
- `value: '*'` or `value: any` — matches **always** (use as fallback transition).

This is the idiomatic way to say "any message" in FlowForge. Unlike `type: regex` with `value: '.*'` (which would also work), `intent: '*'` is a special case in the engine — it returns true instantly without calling the classifier or compiling a regex. Use it as a catch-all transition to leave a state:

```yaml
help:
  responses:
    - "I can help with pricing and orders."
  auto_transitions:
    - target: greeting
      when:
        - type: intent
          value: '*'    # any next message → back to greeting
```

How it works (for normal intents):
1. TF-IDF classifier trains on examples from intents (inline or intents.yaml).
2. For each message, TF-IDF vector and cosine similarity are computed.
3. The intent with the highest similarity wins (threshold: 0.15).

---

### 4.2 type: regex

Direct Python `re.search` — the pattern can appear **anywhere** in the message.

```yaml
- type: regex
  value: 'price|cost|pricing'
```

Notes:
- Case-insensitive (`re.IGNORECASE`).
- Full Python regex syntax supported.
- Invalid regex won't crash the bot — the trigger simply won't fire.

---

### 4.3 type: pattern

Pattern syntax. Compiled to regex automatically.

```yaml
- type: pattern
  value: '* (price* | cost* | pricing) *'
```

#### Syntax Elements

| Element | Description | Example | Matches |
|---------|-------------|---------|---------|
| `word` | Exact word | `price` | "price", "check price" |
| `word*` | Word prefix | `pric*` | "price", "pricing", "prices" |
| `*` | Any characters | `hello * world` | "hello big world" |
| `(A \| B)` | One of the options | `(yes \| sure)` | "yes", "sure" |
| `[X]` | Optional part | `[please] help` | "help", "please help" |
| `{A * B}` | A and B in **any order** | `{discount* * service*}` | "discount on services", "services with discount" |
| `$name` | Named pattern from patterns.yaml | `$greeting` | depends on definition |

---

## 5. Intents

Training examples for the TF-IDF classifier. Two ways to define them:

### Option 1: Inline in scenario.yaml

```yaml
scenario:
  name: my_bot
  initial_state: start

intents:
  ask_price:
    - "How much does it cost?"
    - "What is the price?"
  help:
    - "Help me"
    - "I need help"

states:
  # ...
```

### Option 2: Separate intents.yaml

```yaml
# intents.yaml
intents:
  ask_price: |
    How much does it cost?
    What is the price?
    Price list please

  help: |
    Help me
    I need help
    How do I use this?
```

Block scalar (`|`) format: one phrase per line, lines starting with `#` are comments.

```python
# Explicit path
bot = Bot.from_yaml("scenario.yaml", intents="intents.yaml")

# Auto-discovery: if intents.yaml is next to scenario.yaml, it loads automatically
bot = Bot.from_yaml("scenario.yaml")
```

If both inline and external intents exist, they are merged. Inline intents override external on name conflict.

### Format Rules

- **Intent name** — string without spaces, matches `value` in `type: intent`.
- **More varied** examples → more accurate classifier.
- Lines starting with `#` are comments — skipped by the classifier.

---

## 6. Actions — Calling Functions

Actions are functions that run **before** the bot sends a response. They let you execute business logic — call APIs, query databases, calculate values — and pass the results into response templates.

Actions are defined in `run:` blocks inside states:

```yaml
states:
  pricing:
    run:                              # ← actions go here
      - action: get_price             #    Python action
      - js: tax = calculateTax()      #    Node.js action
    responses:
      - "Price: {price} USD (tax: {tax})"
```

The engine pipeline is:
1. User sends a message
2. Engine finds the matching state (via transitions)
3. **`run:` actions execute** — results are stored in context variables
4. `responses:` template is rendered with those variables

### `run:` block format

`run:` is a list. Each entry is one action. Actions execute in order, top to bottom.

```yaml
run:
  - action: get_price          # Python action
  - action: get_discount       # another Python action
  - js: tax = calculateTax()   # Node.js action
```

Two syntaxes are supported:

| Syntax | Language | How it works |
|---|---|---|
| `action: name` | Python | Calls a function registered via `@bot.action("name")`. |
| `js: var = func()` | Node.js | Finds and calls a function in `*.js` files via `node` subprocess. |

You can mix both in one `run:` block. If a state has no actions, omit `run:` entirely.

---

### Python actions — `action: name`

This is the recommended way. You define the action name in YAML and register the function in Python.

**Step 1. Declare in YAML:**

```yaml
states:
  pricing:
    run:
      - action: get_price
    responses:
      - "Price: {price} {currency}."
```

**Step 2. Register in Python:**

```python
from flowforge import Bot

bot = Bot.from_yaml("scenario.yaml")

@bot.action("get_price")
def get_price(ctx):
    # ctx — Context object
    # ctx.message  — current user message
    # ctx.vars     — context variables dict
    # ctx.session_id — session ID
    # ctx.history  — conversation history
    price = fetch_from_api(ctx.message)
    return {"price": price, "currency": "USD"}
```

The name in `@bot.action("get_price")` must match the name in `action: get_price` in YAML.

**What the function receives:**

A single argument `ctx` — a `Context` object (see [Context Object](#context-object) below). You can read user message, session state, history, and any previously set variables.

**What the function returns:**

| Return type | What happens | Example |
|---|---|---|
| `dict` | Each key-value pair is merged into context variables. Available as `{key}` in responses. | `return {"price": 100, "currency": "USD"}` |
| Any other value | Stored as `context.vars["action_name"]`. | `return 100` → `{get_price}` = `100` |
| `None` | Nothing is stored. Useful for side-effects (logging, API calls). | `return None` |

**Multiple actions:**

Actions run in order. Each one can use variables set by previous actions:

```yaml
run:
  - action: get_price        # sets {price}
  - action: apply_discount   # can read ctx.vars["price"], sets {final_price}
responses:
  - "Was {price}, now {final_price}!"
```

```python
@bot.action("get_price")
def get_price(ctx):
    return {"price": 100}

@bot.action("apply_discount")
def apply_discount(ctx):
    price = ctx.vars["price"]       # set by get_price above
    return {"final_price": price * 0.9}
```

**Side-effect actions** (no return value needed):

```python
@bot.action("log_event")
def log_event(ctx):
    analytics.track("user_asked", message=ctx.message)
    # returns None — nothing added to context

@bot.action("send_email")
def send_email(ctx):
    email_service.send(to=ctx.vars["email"], body="Order confirmed")
```

**Using `ctx.say()` and `ctx.goto()`:**

Actions can also control the conversation flow directly:

```python
@bot.action("check_auth")
def check_auth(ctx):
    if not is_authenticated(ctx.session_id):
        ctx.say("Please log in first.")
        ctx.goto("login")          # force transition to login state
```

---

### Node.js actions — `js: var = func()`

For calling JavaScript functions from `.js` files in your project directory. Useful when you have existing Node.js code or need to call npm packages.

**Syntax:** `js: variable_name = functionName()`

```yaml
states:
  pricing:
    run:
      - js: tax = calculateTax()
      - js: shipping = getShipping()
    responses:
      - "Tax: {tax}, Shipping: {shipping}"
```

**How it works:**

1. The engine searches all `*.js` files in the project directory (the folder containing `scenario.yaml`)
2. It finds the file where `calculateTax` is defined
3. It runs `node -e "..."` as a subprocess, calling the function
4. The JSON result is stored in the context variable `tax`

**Requirements for `.js` files:**

- Functions must be exported via `module.exports`
- Functions must return a JSON-serializable value (or a Promise that resolves to one)
- Node.js must be installed on the system

```javascript
// helpers.js — in the same directory as scenario.yaml
function calculateTax() {
    return 15.5;
}

async function getShipping() {
    // async functions work too
    return 5.99;
}

module.exports = { calculateTax, getShipping };
```

**Supported function declaration styles:**

```javascript
// All of these are found by the engine:
function calculateTax() { ... }
const calculateTax = function() { ... }
const calculateTax = () => { ... }
const calculateTax = async () => { ... }
```

**Limitations compared to Python actions:**

- Slower (spawns a new `node` process each time)
- No access to `ctx` — the function can't read conversation state
- No `ctx.say()` / `ctx.goto()` — can't control flow
- 10-second timeout per call

For most use cases, Python actions are better. Use Node.js actions when you need existing JS libraries or have legacy code.

---

### Actions and testing

When running tests (`.qa.yaml` files), actions still execute. If an action is not registered and not mocked, the test fails with:

```
RuntimeError: Action 'get_price' not registered. Use @bot.action('get_price')
```

**Two ways to handle this in tests:**

1. **Mock in the test file** — no Python code needed:

```yaml
# tests.qa.yaml
setup:
  actions:
    get_price:
      price: 42
```

2. **Register in Python** — then call `bot.test()`:

```python
@bot.action("get_price")
def get_price(ctx):
    return {"price": 42}

results = bot.test("tests.qa.yaml")
```

See [Testing — Mocking actions](#mocking-actions--setup) for details.

---

## 7. Python API

### Bot — all methods at a glance

| Method | Description |
|--------|-------------|
| `Bot.from_yaml(path, ...)` | Create bot from a YAML file. Main way to load a bot. |
| `Bot.from_string(yaml_text, ...)` | Create bot from a YAML string (for tests / dynamic scenarios). |
| `Bot.from_dict(scenario, ...)` | Create bot from a Python dict (fully programmatic, no YAML). |
| `bot.send(text, session_id)` | Send a message, get `BotResponse` back. |
| `bot.get_greeting(session_id)` | Get the greeting message (first response of the initial state). |
| `bot.run(session_id)` | Start interactive console REPL (stdin/stdout). |
| `bot.reset_session(session_id)` | Reset a session to the initial state. |
| `@bot.action("name")` | Decorator: register a Python action handler. |
| `@bot.state("name")` | Decorator: register a programmatic state. |
| `@bot.fallback` | Decorator: register a custom fallback handler. See [LLM Fallback](#llm-fallback). |
| `bot.test(path)` | Run tests from a `.qa.yaml` file. Returns `TestRunResult`. See [Testing](#testing). |
| `bot.add_classifier(clf)` | Add an intent classifier to the detection chain. |

All `from_*` methods accept optional `classifier=`, `llm=`, `session_store=`, and `verbose=` parameters. See [Pluggable Intent Classifiers](#classifiers), [LLM Fallback](#llm-fallback), [Persistent Sessions](#sessions), and [Debugging](#debugging).

### Loading a Bot

There's only one class — `Bot`. You create it by pointing to your scenario:

```python
from flowforge import Bot

bot = Bot.from_yaml("scenario.yaml")
```

That's it for most cases. The bot automatically picks up `intents.yaml`, `patterns.yaml`, and `flowforge.config.yaml` if they exist next to the scenario file.

**Optional parameters:**

```python
# Custom intent classifier (replaces built-in TF-IDF)
bot = Bot.from_yaml("scenario.yaml", classifier=my_classifier)

# LLM provider for fallback (requires fallback: llm in YAML)
bot = Bot.from_yaml("scenario.yaml", llm=my_llm_provider)

# Persistent sessions (survive bot restarts)
from flowforge.contrib.sqlite_store import SqliteStore
bot = Bot.from_yaml("scenario.yaml", session_store=SqliteStore("sessions.db"))

# Combine any parameters
bot = Bot.from_yaml("scenario.yaml", classifier=my_clf, llm=my_llm, session_store=store)

# Explicit intents path — if intents.yaml is elsewhere or named differently
bot = Bot.from_yaml("scenario.yaml", intents="path/to/my_intents.yaml")
```

**Other ways to load** (for special cases):

```python
# From a YAML string — useful for tests or dynamically generated scenarios
# Note: does NOT pick up external files (intents.yaml, config, etc.)
bot = Bot.from_string(yaml_text)

# From a Python dict — for fully programmatic bots with no YAML at all
bot = Bot.from_dict(scenario_dict)
```

All loading methods accept `classifier=` and `llm=` parameters.

**Multi-file projects** — if your bot is split across several YAML files (e.g. `main.yaml`, `pricing.yaml`, `intents_extra.yaml`), you still call `Bot.from_yaml()` pointing to the main file. The config file `flowforge.config.yaml` tells the engine which extra files to load and merge. See [Multi-file Scenarios](#multi-file) for details.

```python
# flowforge.config.yaml sits next to main.yaml and lists all extra files.
# Bot.from_yaml picks it up automatically — no extra arguments needed.
bot = Bot.from_yaml("my_bot/main.yaml")
```

### Sending Messages

```python
response = bot.send("Hello")
response = bot.send("Hello", session_id="user_123")

print(response.text)      # bot's reply
print(response.state)     # current state after processing
print(response.intent)    # detected intent
print(response.context)   # context variables dict
```

### Registering Actions

```python
@bot.action("get_price")
def get_price(ctx):
    return {"price": fetch_price_from_api()}
```

### Programmatic States

```python
@bot.state("dynamic_state")
def dynamic(ctx):
    ctx.say(f"You said: {ctx.message}")

@bot.state("redirect_state")
def redirect(ctx):
    ctx.goto("another_state")
```

### Context Object

The `ctx` parameter passed to handlers:

| Attribute | Description |
|-----------|-------------|
| `ctx.message` | Current user message text |
| `ctx.state` | Current state ID |
| `ctx.session_id` | Session identifier |
| `ctx.vars` | User-defined variables dict |
| `ctx.history` | Conversation history |
| `ctx.say(text)` | Queue a response message |
| `ctx.goto(state)` | Force transition to a state |
| `ctx.set(key, value)` | Set a context variable |
| `ctx.get(key, default)` | Get a context variable |

### BotResponse

| Field | Type | Description |
|-------|------|-------------|
| `text` | `str` | Bot's reply text |
| `state` | `str` | State after processing |
| `intent` | `str \| None` | Detected intent |
| `context` | `dict` | Context variables snapshot |

### Session Management

```python
# Each session_id has independent state and context
bot.send("hi", session_id="user_1")
bot.send("hi", session_id="user_2")

# Reset a session
bot.reset_session("user_1")
```

### Console REPL

```python
bot.run()  # interactive stdin/stdout loop
```

---

## 8. Pluggable Intent Classifiers

By default, FlowForge uses TF-IDF for `type: intent` triggers. You can **replace** the built-in classifier entirely, or **add** extra classifiers to work alongside it.

### Option A: Replace the default classifier

Pass `classifier=` when creating the bot. The built-in TF-IDF will **not** be used — only your classifier:

```python
from flowforge import Bot

bot = Bot.from_yaml("scenario.yaml", classifier=my_classifier)
```

This works with all three loading methods:

```python
bot = Bot.from_yaml("scenario.yaml", classifier=my_classifier)
bot = Bot.from_string(yaml_text, classifier=my_classifier)
bot = Bot.from_dict(scenario_dict, classifier=my_classifier)
```

### Option B: Add a classifier alongside TF-IDF

If you want both — TF-IDF for simple intents and your own classifier for harder cases — use `add_classifier()` after creating the bot:

```python
bot = Bot.from_yaml("scenario.yaml")             # TF-IDF is set up as usual
bot.add_classifier(OpenAIClassifier(api_key="..."))  # added on top
```

Classifiers are tried in order. The first one that returns a matching intent wins.

### Writing a custom classifier

Any Python class with two things: a `classify()` method and a `trained` property.

```python
class OpenAIClassifier:
    def __init__(self, api_key: str):
        self.api_key = api_key

    @property
    def trained(self) -> bool:
        return True  # always ready (no training needed)

    def classify(self, text: str) -> tuple[str | None, float]:
        # Your classification logic here (API call, embedding lookup, etc.)
        # Return (intent_name, confidence) or (None, 0.0) if no match
        return "ask_price", 0.95
```

### IntentClassifier Protocol

Formally, a classifier must match this protocol:

```python
class IntentClassifier(Protocol):
    def classify(self, text: str) -> tuple[str | None, float]: ...

    @property
    def trained(self) -> bool: ...
```

- `classify(text)` — returns `(intent_name, confidence)` or `(None, 0.0)` if nothing matches.
- `trained` — returns `True` when the classifier is ready. If `False`, the engine skips it.

You don't need to inherit from anything — just implement these two things and it works (duck typing).

---

## 9. LLM Fallback

When the rule-based engine can't find a matching transition, it normally goes to `fallback_state` or stays in the current state. **LLM fallback** changes this: instead of a canned "I don't understand" response, the bot calls an LLM (ChatGPT, Claude, etc.) to generate a meaningful answer.

This creates a **hybrid bot**: predictable rule-based paths for known scenarios + LLM for everything else.

### How it works

```
User message
    │
    ▼
┌─────────────────────┐
│  Rule-based engine   │ ──── transition found ──── ▶ normal response
│  (regex/pattern/     │
│   intent/TF-IDF)     │
└─────────┬───────────┘
          │ no match
          ▼
┌─────────────────────┐
│   LLM fallback      │ ──── generates response ──── ▶ LLM response
│   (OpenAI/Claude/   │
│    custom)           │
└─────────────────────┘
```

### Setting up LLM fallback

**Step 1** — set `fallback: llm` in your YAML:

```yaml
scenario:
  name: shop_bot
  initial_state: start
  fallback: llm          # use LLM when no transition matches
```

**Step 2** — pass an LLM provider when creating the bot:

```python
from flowforge import Bot
from flowforge.contrib.llm import OpenAIProvider

llm = OpenAIProvider(api_key="sk-...", model="gpt-4o-mini")
bot = Bot.from_yaml("scenario.yaml", llm=llm)
```

That's it. Now when the bot encounters a message that doesn't match any transition, it calls the LLM instead of replying with a generic fallback.

### The `llm=` parameter

`llm=` is a single LLM provider passed once at bot creation. The engine uses it wherever the YAML config says to (currently: fallback). In the future, the same provider can power other LLM features (NER, response rewriting, etc.) — you won't need to change the Python code.

```python
# All three loading methods accept llm=
bot = Bot.from_yaml("scenario.yaml", llm=llm)
bot = Bot.from_string(yaml_text, llm=llm)
bot = Bot.from_dict(scenario_dict, llm=llm)
```

### Ready-made providers

FlowForge includes ready-made wrappers for popular LLM APIs. They require the corresponding SDK to be installed separately.

#### OpenAI

```bash
pip install openai
```

```python
from flowforge.contrib.llm import OpenAIProvider

llm = OpenAIProvider(
    api_key="sk-...",
    model="gpt-4o-mini",           # default
    system="You are a shop assistant. Be brief.",  # system prompt
    temperature=0.7,                # default
)
bot = Bot.from_yaml("scenario.yaml", llm=llm)
```

#### Anthropic (Claude)

```bash
pip install anthropic
```

```python
from flowforge.contrib.llm import AnthropicProvider

llm = AnthropicProvider(
    api_key="sk-ant-...",
    model="claude-sonnet-4-20250514",  # default
    system="You are a shop assistant.",
    max_tokens=1024,                    # default
)
bot = Bot.from_yaml("scenario.yaml", llm=llm)
```

### Custom LLM provider

You can use **any** LLM — just write a class with a `generate()` method:

```python
class MyLLM:
    def generate(self, message: str, history: list, knowledge: str = "") -> str:
        # Call any API, local model, or custom logic
        # message  — current user message
        # history  — conversation history [{"role": "user", "content": "..."}, ...]
        # knowledge — text from knowledge.md (empty if not set)
        return "your response"

bot = Bot.from_yaml("scenario.yaml", llm=MyLLM())
```

The `LLMProvider` protocol:

```python
class LLMProvider(Protocol):
    def generate(self, message: str, history: list, knowledge: str = "") -> str: ...
```

One method. No inheritance required — duck typing works.

### Alternative: `@bot.fallback` decorator

If you don't want to create a separate class, use the `@bot.fallback` decorator. It gets a `Context` object and should call `ctx.say()`:

```python
import openai

bot = Bot.from_yaml("scenario.yaml")  # no llm= needed

@bot.fallback
def my_fallback(ctx):
    response = openai.chat.completions.create(
        model="gpt-4o-mini",
        messages=[
            {"role": "system", "content": "You are a helpful assistant."},
            *[{"role": m["role"], "content": m["content"]} for m in ctx.history],
            {"role": "user", "content": ctx.message},
        ],
    )
    ctx.say(response.choices[0].message.content)
```

Note: `@bot.fallback` automatically enables LLM fallback mode — you don't need `fallback: llm` in YAML when using the decorator.

### Fallback modes summary

| YAML | Python | What happens when no transition matches |
|------|--------|-----------------------------------------|
| `fallback: llm` | `llm=provider` | LLM generates a response |
| `fallback: llm` | *(no llm=)* | Stays in current state (LLM not available) |
| `fallback: unknown` | — | Goes to the `unknown` state |
| `fallback_state: unknown` | — | Same (legacy syntax) |
| *(not set)* | `@bot.fallback` | Decorator handler is called |
| *(not set)* | — | Stays in current state |

### Error handling

If the LLM provider throws an exception (network error, rate limit, etc.), the bot does **not** crash. It returns `"..."` as the response. You can handle errors inside your provider or fallback handler.

---

## 10. Knowledge Base

A knowledge base is a text file with information your bot "knows". When the LLM fallback is triggered, this text is passed to the LLM as context — so it can answer questions based on your business information, not just general knowledge.

This is a **simplified RAG** (Retrieval-Augmented Generation): instead of embedding search, the entire file is sent as context. Simple, but works great for small-to-medium knowledge bases (up to ~50 pages of text depending on the model).

### Setting up

**Step 1** — create a knowledge file (Markdown works best):

```markdown
# knowledge.md

## About Us
We are TechShop, an electronics store since 2015.
Hours: Mon-Sat 10:00-20:00, Sunday closed.
Address: 42 Main Street.

## Delivery
Free delivery for orders over $50. Delivery time: 1-3 business days.
Pickup available at our store.

## Returns
14-day return policy. Item must be in original packaging.
Refund processed within 5 business days.

## Products
- Laptops: starting at $499
- Smartphones: starting at $199
- Accessories: starting at $9.99
```

**Step 2** — reference it in your scenario:

```yaml
scenario:
  name: shop_bot
  initial_state: start
  fallback: llm
  knowledge: knowledge.md    # path relative to the scenario file
```

**Step 3** — the LLM provider automatically receives the knowledge text:

```python
from flowforge import Bot
from flowforge.contrib.llm import OpenAIProvider

llm = OpenAIProvider(api_key="sk-...", system="You are a TechShop assistant.")
bot = Bot.from_yaml("scenario.yaml", llm=llm)

response = bot.send("What are your hours?")
# LLM answers: "We are open Monday to Saturday, 10 AM to 8 PM. We are closed on Sundays."
```

You don't need to do anything special — the engine reads `knowledge.md` at startup and passes its contents to `llm.generate(knowledge=...)` on every LLM fallback call.

### How it works inside

1. Parser reads `knowledge: knowledge.md` from `scenario:` section
2. `load_scenario()` loads the file contents into `scenario["knowledge"]`
3. Engine stores the text and passes it to `llm_provider.generate(knowledge=text)` during fallback
4. The ready-made providers (OpenAI, Anthropic) inject it into the system prompt:
   ```
   "Use the following knowledge base to answer questions.
   If the answer is not in the knowledge base, say you don't know.

   <contents of knowledge.md>"
   ```

### With `@bot.fallback` decorator

If you use the decorator instead of `llm=`, the knowledge is available via `ctx.vars["knowledge"]`:

```python
@bot.fallback
def my_fallback(ctx):
    knowledge = ctx.vars.get("knowledge", "")
    # Pass knowledge to your LLM call
    ctx.say(call_my_llm(ctx.message, knowledge=knowledge))
```

### Tips

- **Keep it focused.** Only include information the bot needs. Irrelevant text wastes tokens and can confuse the LLM.
- **Structure it well.** Use headers and bullet points — LLMs understand structured text better.
- **Update it.** The file is read at bot startup. To update knowledge, restart the bot.
- **Size limit.** The entire file must fit in the LLM's context window. For GPT-4o-mini that's ~128K tokens (~50-100 pages). If your knowledge base is larger, you'll need a real RAG solution with embeddings.

### Full example: FAQ bot with knowledge

```
my_bot/
├── scenario.yaml
├── knowledge.md
└── bot.py
```

```yaml
# scenario.yaml
scenario:
  name: faq_bot
  initial_state: start
  fallback: llm
  knowledge: knowledge.md

intents:
  greeting:
    - hello
    - hi
    - hey

states:
  start:
    responses:
      - "Hi! Ask me anything about our store."
    auto_transitions:
      - target: start
        when:
          - type: intent
            value: greeting
```

```python
# bot.py
from flowforge import Bot
from flowforge.contrib.llm import OpenAIProvider

llm = OpenAIProvider(
    api_key="sk-...",
    system="You are a friendly store assistant. Answer based on the knowledge base. Be concise.",
)
bot = Bot.from_yaml("scenario.yaml", llm=llm)
bot.run()
```

```
Bot: Hi! Ask me anything about our store.
You: What are your hours?
Bot: We're open Monday to Saturday, 10 AM to 8 PM. Closed on Sundays.
You: Do you deliver?
Bot: Yes! Free delivery for orders over $50, takes 1-3 business days. You can also pick up at 42 Main Street.
You: hi
Bot: Hi! Ask me anything about our store.
```

Notice: "hi" matched the `greeting` intent → rule-based response. "What are your hours?" didn't match any transition → LLM fallback answered using `knowledge.md`.

---

## 11. Persistent Sessions

By default, all sessions live in memory. Restart the bot — all conversations are lost. For production, you need persistent sessions.

### The problem

```python
# Bot starts, user has a conversation
bot.send("go", session_id="user_1")  # user moves to "other" state

# Bot restarts (deploy, crash, server reboot)...

# User sends another message — but the bot forgot everything
bot.send("continue", session_id="user_1")  # starts from scratch :(
```

### The solution: `session_store=`

Pass a session store when creating the bot:

```python
from flowforge import Bot
from flowforge.contrib.sqlite_store import SqliteStore

bot = Bot.from_yaml("scenario.yaml", session_store=SqliteStore("sessions.db"))
```

Now sessions are saved to a SQLite file. Restart the bot — conversations continue from where they left off.

### SQLite store

Built-in, zero dependencies (SQLite is part of Python). Good for single-process bots.

```python
from flowforge.contrib.sqlite_store import SqliteStore

# File is created automatically if it doesn't exist
store = SqliteStore("sessions.db")

bot = Bot.from_yaml("scenario.yaml", session_store=store)
```

What gets saved per session:
- Current state
- Context variables (`ctx.vars`)
- Conversation history (`ctx.history`)

### Memory store (default)

If you don't pass `session_store=`, the bot uses `MemoryStore` — a plain Python dict. Fast, but lost on restart. This is the same behavior as before.

```python
# These two are equivalent:
bot = Bot.from_yaml("scenario.yaml")
bot = Bot.from_yaml("scenario.yaml", session_store=MemoryStore())
```

### Custom session store

For Redis, PostgreSQL, or any other backend — write a class with three methods:

```python
class RedisStore:
    def __init__(self, url):
        self.redis = redis.from_url(url)

    def load(self, session_id: str) -> Context | None:
        data = self.redis.get(f"session:{session_id}")
        if data is None:
            return None
        return context_from_dict(json.loads(data))

    def save(self, session_id: str, context: Context) -> None:
        data = json.dumps(context_to_dict(context))
        self.redis.set(f"session:{session_id}", data)

    def delete(self, session_id: str) -> None:
        self.redis.delete(f"session:{session_id}")

bot = Bot.from_yaml("scenario.yaml", session_store=RedisStore("redis://localhost"))
```

Helper functions `context_to_dict` and `context_from_dict` are available for serialization:

```python
from flowforge.session import context_to_dict, context_from_dict
```

### SessionStore protocol

```python
class SessionStore(Protocol):
    def load(self, session_id: str) -> Context | None: ...
    def save(self, session_id: str, context: Context) -> None: ...
    def delete(self, session_id: str) -> None: ...
```

Three methods, no inheritance needed. Duck typing works.

### Example: Telegram bot with persistent sessions

```python
from telegram import Update
from telegram.ext import ApplicationBuilder, MessageHandler, filters
from flowforge import Bot
from flowforge.contrib.sqlite_store import SqliteStore

bot = Bot.from_yaml("scenario.yaml", session_store=SqliteStore("sessions.db"))

async def handle_message(update: Update, context):
    user_id = str(update.effective_user.id)
    response = bot.send(update.message.text, session_id=user_id)
    await update.message.reply_text(response.text)

app = ApplicationBuilder().token("YOUR_TOKEN").build()
app.add_handler(MessageHandler(filters.TEXT, handle_message))
app.run_polling()
```

Now if the bot restarts, each user's conversation continues from where it was. The only change from the non-persistent version is `session_store=SqliteStore("sessions.db")`.

---

## 12. Debugging

When something doesn't work as expected — a transition doesn't fire, the bot goes to the wrong state — use `verbose=True` to see exactly what the engine is doing.

### Quick start

```python
bot = Bot.from_yaml("scenario.yaml", verbose=True)
```

This prints a step-by-step trace to stderr for every message:

```
13:40:56 [flowforge] [default] message='help me'  state=start
13:40:56 [flowforge] [default] phase2: auto_transition matched → help
13:40:56 [flowforge] [default] result: state=start → help  intent=regex:help  response='Here is help.'
```

### What the log shows

| Log entry | Meaning |
|-----------|---------|
| `message='...' state=...` | Incoming message and current state |
| `phase1: response_transition matched → X` | A response_transition fired |
| `phase2: auto_transition matched → X` | An auto_transition fired |
| `phase2: no match in current state` | No transition matched in the current state |
| `phase3: global search → X` | Found a match in another state's auto_transitions |
| `phase3: LLM fallback` | No match anywhere, calling LLM |
| `phase3: fallback state → X` | No match, going to fallback state |
| `phase3: no match, staying in X` | No match and no fallback, staying put |
| `phase4: routing X → Y` | Routing through a state with no responses |
| `phase5: executing action ...` | Running an action |
| `phase5: goto → X` | Action forced a state transition via `ctx.goto()` |
| `result: state=A → B intent=... response='...'` | Final result summary |

### Using Python's logging directly

`verbose=True` is a shortcut. Under the hood, FlowForge uses the standard `logging` module with the logger name `"flowforge"`. You can configure it yourself:

```python
import logging

# Show debug logs
logging.getLogger("flowforge").setLevel(logging.DEBUG)
logging.getLogger("flowforge").addHandler(logging.StreamHandler())

# Or log to a file
handler = logging.FileHandler("bot.log")
logging.getLogger("flowforge").addHandler(handler)
```

This integrates with any existing logging setup in your application.

---

## 13. Connecting Channels (Telegram, etc.)

FlowForge is **channel-agnostic** — it doesn't know anything about Telegram, WhatsApp, Discord, or any other platform. It's a "brain" that takes text in and gives text out:

```
User message (text) → bot.send() → BotResponse (text)
```

You connect it to any channel by writing a thin adapter: the channel receives a message, passes the text to `bot.send()`, and sends the response back. That's it.

### Architecture

```
┌──────────┐     text      ┌───────────┐     text      ┌──────────┐
│ Telegram │  ──────────►  │ FlowForge │  ──────────►  │ Telegram │
│  (input) │               │  bot.send()│               │ (output) │
└──────────┘               └───────────┘               └──────────┘
```

FlowForge handles: intent detection, state transitions, actions, response generation.
The channel handles: receiving messages, sending replies, authentication, webhooks.

### Example: Telegram (python-telegram-bot)

```bash
pip install python-telegram-bot flowforge
```

```python
from telegram import Update
from telegram.ext import ApplicationBuilder, MessageHandler, CommandHandler, filters
from flowforge import Bot

# 1. Create the FlowForge bot from your scenario
bot = Bot.from_yaml("scenario.yaml")

# 2. Register any actions your scenario uses
@bot.action("get_price")
def get_price(ctx):
    return {"price": 100}

# 3. /start command — send the bot's greeting
async def start(update: Update, context):
    greeting = bot.get_greeting() # <--- FlowForge!
    await update.message.reply_text(greeting or "Hi!")

# 4. Any text message — pass to FlowForge, send the response back
async def handle_message(update: Update, context):
    user_id = str(update.effective_user.id)             # unique session per user
    response = bot.send(update.message.text, session_id=user_id) # <--- FlowForge!
    await update.message.reply_text(response.text)

# 5. Wire it up
app = ApplicationBuilder().token("YOUR_BOT_TOKEN").build()
app.add_handler(CommandHandler("start", start))
app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
app.run_polling()
```

**Key points:**

- `session_id=user_id` — each Telegram user gets their own independent session (state, context, history). Without this, all users would share one conversation.
- `handle_message` catches **every** text message. You don't need separate handlers for each topic — FlowForge routes internally based on your YAML scenario.
- `bot.send()` is synchronous. In the Telegram handler (which is async), this is fine — it runs fast (regex/TF-IDF, no network calls). If your actions make slow API calls, consider wrapping in `asyncio.to_thread()`.

### Example: Discord (discord.py)

```python
import discord
from flowforge import Bot

bot = Bot.from_yaml("scenario.yaml")
client = discord.Client(intents=discord.Intents.default())

@client.event
async def on_message(message):
    if message.author == client.user:
        return
    user_id = str(message.author.id)
    response = bot.send(message.content, session_id=user_id)
    await message.channel.send(response.text)

client.run("YOUR_DISCORD_TOKEN")
```

### Example: Flask webhook (any platform)

```python
from flask import Flask, request, jsonify
from flowforge import Bot

app = Flask(__name__)
bot = Bot.from_yaml("scenario.yaml")

@app.route("/webhook", methods=["POST"])
def webhook():
    data = request.json
    user_id = data["user_id"]
    response = bot.send(data["text"], session_id=user_id)
    return jsonify({"reply": response.text})
```

### The pattern is always the same

No matter what channel you connect:

1. **Receive** a text message from the channel
2. **Pass** it to `bot.send(text, session_id=user_id)`
3. **Send** `response.text` back through the channel

FlowForge doesn't care where the message came from. The YAML scenario and the channel adapter are completely independent — you can swap Telegram for Discord by changing only the adapter code, without touching the scenario at all.

---

## 14. Multi-file Scenarios

When your bot grows, you can split it across multiple files. This keeps each file focused on one topic (pricing, support, onboarding, etc.) instead of having one giant YAML.

### How it works

Create a `flowforge.config.yaml` next to your main scenario file. It lists which files to load:

```yaml
# flowforge.config.yaml
scenario_files:       # states from these files are merged into one bot
  - main.yaml
  - pricing.yaml
  - support.yaml

intent_files:         # training phrases from these files are combined
  - intents.yaml
  - intents_extra.yaml

pattern_files:        # named patterns are merged
  - patterns.yaml
```

In Python, nothing changes — just point to the main file:

```python
bot = Bot.from_yaml("my_bot/main.yaml")
# flowforge.config.yaml is picked up automatically
```

### Project structure example

```
my_bot/
├── flowforge.config.yaml   # tells the engine which files to load
├── main.yaml                # scenario: block + core states
├── pricing.yaml             # extra states for pricing topic
├── support.yaml             # extra states for support topic
├── intents.yaml             # main intents
├── intents_extra.yaml       # more intents (merged with intents.yaml)
├── patterns.yaml            # named patterns for $name syntax
└── bot.py                   # Python code
```

### Rules

- **`scenario:` block** (name, initial_state, fallback_state) goes **only in the main file** (e.g. `main.yaml`).
- Extra scenario files contain **only `states:`** — no `scenario:` block.
- If two files define the same state name, the **main file wins**.
- Intent phrases from all `intent_files` are **combined** (not overwritten).
- If `flowforge.config.yaml` doesn't exist, the bot loads just one file — same as before.

### Extra scenario file example

```yaml
# pricing.yaml — only states:, no scenario: block
states:
  price_info:
    run:
      - action: get_price
    responses:
      - "Our prices start at {price} USD."
    response_transitions:
      - target: confirm_order
        when:
          - type: regex
            value: 'yes|sure'
      - target: start
        when:
          - type: regex
            value: 'no|back'

  confirm_order:
    responses:
      - "Order confirmed!"
    auto_transitions:
      - target: start
        when:
          - type: intent
            value: '*'
```

These states are merged with states from `main.yaml` as if they were all in one file. Transitions between files work normally — `target: start` points to the `start` state from `main.yaml`.

### Named Patterns File — patterns.yaml

Reusable pattern fragments for `type: pattern` triggers. Use `$name` to reference them in your scenario.

```yaml
# patterns.yaml
greeting: '(hi | hello | hey | good morning)'
price_word: '(price* | cost* | pricing | how much)'
negation: '(no | cancel | back | never mind)'
```

```yaml
# In scenario — $greeting expands to the pattern defined above
auto_transitions:
  - target: help
    when:
      - type: pattern
        value: '$greeting * help*'    # matches "hello can you help me"
```

---

<a id="testing"></a>

## 15. Testing Scenarios

FlowForge has a built-in test runner. You describe expected dialogues in `.qa.yaml` files, and the runner replays them against your bot, checking states, responses, and context variables.

No external test framework required — although FlowForge integrates with pytest if you use it.

### Quick start

**1. You have a scenario** — `scenario.yaml`:

```yaml
scenario:
  name: shop_bot
  initial_state: greeting

intents:
  ask_price:
    - "how much does it cost"
    - "what is the price"

states:
  greeting:
    responses:
      - "Hello! Ask about prices or say help."
    auto_transitions:
      - target: pricing
        when:
          - type: intent
            value: ask_price
      - target: help
        when:
          - type: regex
            value: 'help|support'

  pricing:
    run:
      - action: get_price
    responses:
      - "Price: {price} USD. Want to buy?"
    response_transitions:
      - target: checkout
        when:
          - type: regex
            value: 'yes|sure|buy'
      - target: greeting
        when:
          - type: regex
            value: 'no|back'

  checkout:
    responses:
      - "Order confirmed! Thank you."

  help:
    responses:
      - "I can help with pricing and orders."
    auto_transitions:
      - target: greeting
        when:
          - type: intent
            value: '*'
```

**2. Create a test file** — `tests.qa.yaml` (same directory):

```yaml
setup:
  actions:
    get_price:
      price: 42

tests:
  pricing:
    - "how much does it cost"
    - "what is the price"
  help:
    - "help"
    - "support"

conversations:
  - name: "Full purchase"
    steps:
      - user: "hello"
        state: greeting
        response: "Hello"
      - user: "how much does it cost"
        state: pricing
        response: "Price: 42 USD"
        context:
          price: 42
      - user: "yes"
        state: checkout
        response: "Order confirmed"

  - name: "Ask price then decline"
    steps:
      - user: "what is the price"
        state: pricing
      - user: "no"
        state: greeting

  - name: "Help and return"
    steps:
      - user: "help"
        state: help
        response: "I can help"
      - user: "hello"
        state: greeting
```

**3. Run:**

```bash
python -m flowforge test scenario.yaml
```

Output:

```
  ✓ pricing: how much does it cost
  ✓ pricing: what is the price
  ✓ help: help
  ✓ help: support
  ✓ Full purchase
  ✓ Ask price then decline
  ✓ Help and return

7 passed, 0 failed
```

If a test fails:

```
  ✗ Full purchase
    step 2 ("how much does it cost"): state: expected 'pricing', got 'greeting'

6 passed, 1 failed
```

**Note** that every part of the test is optional: you are free to use actions/tests/conversations separatly.

---

### Project structure

Recommended file layout:

```
my_bot/
├── scenario.yaml          # bot scenario
├── intents.yaml           # intents (optional, can be inline)
├── knowledge.md           # knowledge base (optional)
├── tests.qa.yaml          # test file — auto-discovered by CLI
├── bot.py                 # Python entry point with @bot.action()
└── tests/
    └── test_bot.py        # pytest tests (optional)
```

The CLI auto-discovers `*.qa.yaml` files next to the scenario. You can also have multiple test files:

```
my_bot/
├── scenario.yaml
├── smoke.qa.yaml          # quick smoke tests
├── full.qa.yaml           # comprehensive flow tests
└── edge_cases.qa.yaml     # tricky edge cases
```

Run a specific file:

```bash
python -m flowforge test scenario.yaml edge_cases.qa.yaml
```

Or auto-discover (picks the first `*.qa.yaml` alphabetically):

```bash
python -m flowforge test scenario.yaml
```

---

### Test file format (`.qa.yaml`)

A `.qa.yaml` file can contain three top-level sections. All are optional; use whichever combination you need.

```yaml
setup:           # mock configuration (optional)
  actions: ...

tests:           # simple format — single-message state checks
  ...

conversations:   # extended format — multi-turn dialogues
  ...
```

#### Simple format — `tests:`

Maps a target state name to a list of user phrases. Each phrase is tested independently — the bot resets to `initial_state` before each one.

```yaml
tests:
  greeting:
    - "hello"
    - "hi there"
    - "hey"
  pricing:
    - "how much does it cost"
    - "what is the price"
  help:
    - "help"
    - "I need support"
```

**What this checks:** after sending the phrase from `initial_state`, the bot must land in the state matching the key name.

**When to use:** quick smoke tests for intent routing — "does phrase X reach state Y?"

Each phrase becomes an independent single-step test case. The test file above generates 6 test cases.

#### Extended format — `conversations:`

A list of named conversations. Each conversation is a sequence of steps executed in order within a single session.

```yaml
conversations:
  - name: "Greeting then pricing then checkout"
    steps:
      - user: "hello"
        state: greeting
        response: "Hello! Ask about prices"
      - user: "how much does it cost"
        state: pricing
        response: "/Price: \\d+ USD/"
        context:
          price: 42
      - user: "yes"
        state: checkout
        response: "Order confirmed"
```

**Key difference from `tests:`:** steps run sequentially in one session, so each step starts from the state where the previous step ended. This lets you test multi-turn flows.

**When to use:** testing complete user journeys, response content, context variables.

#### Mixing both formats

Both sections can coexist in one file. `tests:` entries run first, then `conversations:`.

```yaml
# Quick routing checks
tests:
  pricing:
    - "how much"
  help:
    - "help"

# Detailed flow tests
conversations:
  - name: "Full journey"
    steps:
      - user: "hello"
        state: greeting
      - user: "how much"
        state: pricing
      - user: "yes"
        state: checkout
```

---

### Step reference

Each step in a conversation is a YAML mapping:

```yaml
- user: "message text"       # required — what the user says
  state: expected_state       # optional — check resulting state
  response: "expected text"   # optional — check bot response
  context:                    # optional — check context variables
    key: value
```

| Field | Required | Type | What it checks |
|---|---|---|---|
| `user` | yes | string | The message to send to the bot. |
| `state` | no | string | Bot must be in this state after processing. Exact match. |
| `response` | no | string | Bot response must match (see [Response matching](#response-matching)). |
| `context` | no | dict | Each key-value pair must be present in `response.context`. |

**If only `user` is specified** — the step always passes. Useful for "setup" steps where you just need to advance the conversation:

```yaml
steps:
  - user: "hello"              # just advance to greeting, don't check anything
  - user: "how much"
    state: pricing              # now check that we're in pricing
    response: "Price: 42 USD"
```

---

<a id="response-matching"></a>

### Response matching

Three modes:

**Substring match** (default) — the expected text must appear somewhere in the bot's response:

```yaml
response: "Order confirmed"
# passes for "Order confirmed! Thank you." ✓
# passes for "Order confirmed"              ✓
# fails  for "Your order is processing"     ✗
```

**Regex match** — wrap the pattern in `/.../`:

```yaml
response: "/Price: \\d+ USD/"
# passes for "Price: 42 USD. Want to buy?"  ✓
# passes for "Price: 100 USD."              ✓
# fails  for "Price: free"                  ✗
```

> **Note:** In YAML, backslashes must be doubled inside double-quoted strings: `"\\d+"` becomes the regex `\d+`. In single-quoted strings, backslashes are literal: `'/Price: \d+ USD/'` also works.

**Exact match** — use regex with anchors `^` and `$`:

```yaml
response: "/^Order confirmed!$/"
# passes for "Order confirmed!"              ✓
# fails  for "Order confirmed! Thank you."   ✗
```

---

<a id="mocking-actions--setup"></a>

### Mocking actions — `setup:`

#### The problem

Suppose your scenario has a `run:` block:

```yaml
pricing:
  run:
    - action: get_price      # calls @bot.action("get_price")
  responses:
    - "Price: {price} USD."
```

When the engine reaches `pricing`, it calls the `get_price` function. In production, that function might hit an API, query a database, or do something expensive. In tests, you don't want that — you want a predictable, instant result.

If the action is neither registered nor mocked, the test crashes:

```
RuntimeError: Action 'get_price' not registered. Use @bot.action('get_price')
```

#### Solution: `setup.actions`

Add a `setup:` section to your `.qa.yaml` file. Under `actions:`, list each action name and the dict it should return:

```yaml
setup:
  actions:
    get_price:           # action name (must match "action: get_price" in YAML)
      price: 42          # key-value pairs that the mock returns
      currency: "USD"
```

This is equivalent to writing:

```python
@bot.action("get_price")
def get_price(ctx):
    return {"price": 42, "currency": "USD"}
```

...but without any Python code. The mock returns the same dict every time it's called.

#### Multiple actions

List all actions your scenario uses:

```yaml
setup:
  actions:
    get_price:
      price: 42
      currency: "USD"
    fetch_user:
      name: "John"
      email: "john@example.com"
    create_order:
      order_id: "ORD-001"
      status: "confirmed"
```

#### When `setup:` is NOT needed

If your scenario has **no `run:` blocks** — there are no actions to call, so `setup:` is unnecessary:

```yaml
# This scenario has no actions — no setup needed
states:
  greeting:
    responses:
      - "Hello!"
    auto_transitions:
      - target: help
        when:
          - type: regex
            value: 'help'
  help:
    responses:
      - "I can help with pricing."
```

```yaml
# Test file — no setup section
tests:
  help:
    - "help"
```

#### Two approaches to handling actions in tests

**Approach 1: Mock in `.qa.yaml`** — works everywhere (CLI, `bot.test()`, pytest):

```yaml
# tests.qa.yaml
setup:
  actions:
    get_price:
      price: 42

tests:
  pricing:
    - "how much does it cost"
```

```bash
# No Python code needed
python -m flowforge test scenario.yaml tests.qa.yaml
```

**Approach 2: Register in Python** — when you want real logic or conditional returns:

```python
bot = Bot.from_yaml("scenario.yaml")

@bot.action("get_price")
def get_price(ctx):
    if "premium" in ctx.message:
        return {"price": 200}
    return {"price": 42}

results = bot.test("tests.qa.yaml")
```

**Both together:** if the same action is both registered in Python and mocked in `setup.actions`, the mock wins during the test run. After tests finish, the original Python handler is restored.

#### How mocks work internally

1. Before tests start: for each action in `setup.actions`, the original handler (if any) is saved, and a mock function is registered in its place
2. During tests: the mock returns the specified dict every time
3. After all tests complete: original handlers are restored

This means mocks don't affect the bot outside of `bot.test()` — your production handlers remain intact.

#### Node.js actions in tests

`js:` actions work in tests if Node.js is installed, but they're slower and harder to control. Consider mocking the equivalent Python action instead:

```yaml
# Instead of running the real JS:
#   run:
#     - js: tax = calculateTax()
# Mock it as if it were a Python action — the engine treats the result the same way

# Unfortunately, js: actions can't be mocked via setup.actions (only action: can).
# If your scenario uses js: actions, either:
# 1. Have Node.js installed and the .js files available
# 2. Replace js: with action: and mock/register in Python
```

---

### Checking context variables

The `context` field lets you verify that actions set the right values:

```yaml
steps:
  - user: "how much does it cost"
    state: pricing
    context:
      price: 42
      currency: "USD"
```

This checks that after processing the message, `response.context["price"] == 42` and `response.context["currency"] == "USD"`.

**Numeric comparison:** integers and floats are compared with type coercion — `42` matches `42.0`.

**Partial check:** you only need to list the keys you care about. Extra keys in the context are ignored.

```yaml
# Only checks "price", ignores everything else in context
context:
  price: 42
```

---

### Three ways to run tests

#### 1. CLI — `python -m flowforge test`

Best for quick checks and CI/CD.

```bash
# Explicit test file
python -m flowforge test scenario.yaml tests.qa.yaml

# Auto-discover *.qa.yaml next to the scenario
python -m flowforge test scenario.yaml
```

Exit code: `0` = all passed, `1` = failures.

Use in CI:

```yaml
# .github/workflows/test.yml
- run: pip install pyflowforge
- run: python -m flowforge test scenario.yaml tests.qa.yaml
```

#### 2. Python API — `bot.test()`

Best when you need programmatic access to results, or when your bot has Python actions.

```python
from flowforge import Bot

bot = Bot.from_yaml("scenario.yaml")

@bot.action("get_price")
def get_price(ctx):
    return {"price": 42}

results = bot.test("tests.qa.yaml")

print(results.summary)    # "7 passed, 0 failed"
print(results.ok)         # True
print(results.passed_count)  # 7
print(results.failed_count)  # 0
```

Inspect failures:

```python
for case in results.cases:
    if not case.passed:
        print(f"FAIL: {case.name}")
        for step in case.steps:
            if not step.passed:
                print(f"  Step {step.index} ({step.user_message!r}):")
                print(f"    {step.error}")
                if step.expected_state:
                    print(f"    expected state: {step.expected_state}")
                    print(f"    actual state:   {step.actual_state}")
                if step.expected_response:
                    print(f"    expected response: {step.expected_response}")
                    print(f"    actual response:   {step.actual_response}")
```

#### 3. pytest integration

Best for running alongside your Python unit tests.

```python
# test_bot.py
from flowforge import Bot

def make_bot():
    bot = Bot.from_yaml("scenario.yaml")

    @bot.action("get_price")
    def get_price(ctx):
        return {"price": 42}

    return bot

def test_scenario_smoke():
    """All .qa.yaml tests pass."""
    bot = make_bot()
    results = bot.test("tests.qa.yaml")
    assert results.ok, results.summary

def test_specific_flow():
    """Test a specific flow programmatically."""
    bot = make_bot()
    r = bot.send("how much does it cost")
    assert r.state == "pricing"
    assert "42" in r.text
```

```bash
pytest test_bot.py -v
```

---

### `TestRunResult` API

`bot.test()` returns a `TestRunResult`:

| Property | Type | Description |
|---|---|---|
| `ok` | `bool` | `True` if all test cases passed. |
| `passed_count` | `int` | Number of passing test cases. |
| `failed_count` | `int` | Number of failing test cases. |
| `summary` | `str` | e.g. `"7 passed, 0 failed"`. |
| `cases` | `list[TestCaseResult]` | Individual test case results. |

Each `TestCaseResult`:

| Field | Type | Description |
|---|---|---|
| `name` | `str` | Test case name. For simple format: `"state: phrase"`. |
| `passed` | `bool` | Whether all steps in this case passed. |
| `steps` | `list[StepResult]` | Per-step results. |

Each `StepResult`:

| Field | Type | Description |
|---|---|---|
| `index` | `int` | Step number (1-based). |
| `user_message` | `str` | The message that was sent. |
| `passed` | `bool` | Whether this step passed all assertions. |
| `error` | `str \| None` | Error description if failed. Multiple errors joined by `"; "`. |
| `expected_state` | `str \| None` | Expected state (if asserted). |
| `actual_state` | `str` | Actual state after processing. |
| `expected_response` | `str \| None` | Expected response pattern (if asserted). |
| `actual_response` | `str` | Actual bot response text. |

---

### Tips and common mistakes

**Always mock actions that call external APIs.** Without a mock or a registered handler, the test crashes:

```
RuntimeError: Action 'get_price' not registered. Use @bot.action('get_price')
```

Fix: add `setup.actions` in the test file, or register the action in Python before calling `bot.test()`.

**YAML quoting for regex.** Backslashes need escaping in double-quoted YAML strings:

```yaml
# Correct
response: "/Price: \\d+ USD/"

# Also correct — single quotes don't need escaping
response: '/Price: \d+ USD/'

# Wrong — \d is not a valid YAML escape, may parse incorrectly
response: "/Price: \d+ USD/"
```

**Each `tests:` phrase runs from initial_state.** If your target state is only reachable after multiple steps, use `conversations:` instead.

**State names must match exactly.** The test checks `response.state == "pricing"`, not a substring. Typos in state names silently produce failures.

**Random responses.** If a state has multiple responses (`responses: ["A", "B"]`), the bot picks one randomly. Use substring or regex matching to handle this:

```yaml
# Instead of exact match:
response: "/A|B/"

# Or check just the common part:
response: "Price:"
```

**Debug failing tests.** Enable verbose mode to see the engine trace:

```python
bot = Bot.from_yaml("scenario.yaml", verbose=True)
results = bot.test("tests.qa.yaml")
```

This prints the full engine pipeline for every message, showing which transitions matched and why.

---

### Complete walkthrough

Let's build tests for a booking bot step by step.

**Scenario** (`scenario.yaml`):

```yaml
scenario:
  name: booking_bot
  initial_state: greeting

intents:
  want_booking:
    - "I want to book"
    - "make a reservation"
    - "book a table"
  ask_menu:
    - "show menu"
    - "what do you have"

states:
  greeting:
    responses:
      - "Welcome! Book a table or check our menu."
    auto_transitions:
      - target: booking
        when:
          - type: intent
            value: want_booking
      - target: menu
        when:
          - type: intent
            value: ask_menu

  booking:
    responses:
      - "For how many people?"
    response_transitions:
      - target: confirm_booking
        when:
          - type: regex
            value: '\d+'

  confirm_booking:
    run:
      - action: create_booking
    responses:
      - "Booked for {guests} guests! Confirmation: {booking_id}."

  menu:
    run:
      - action: get_menu
    responses:
      - "Today's menu: {menu}"
    auto_transitions:
      - target: greeting
        when:
          - type: intent
            value: '*'
```

**Test file** (`tests.qa.yaml`):

```yaml
# Mock external actions
setup:
  actions:
    create_booking:
      guests: 4
      booking_id: "BK-001"
    get_menu:
      menu: "Pasta, Salad, Steak"

# Quick routing checks
tests:
  booking:
    - "I want to book"
    - "make a reservation"
    - "book a table"
  menu:
    - "show menu"
    - "what do you have"

# Full conversation flows
conversations:
  - name: "Book a table for 4"
    steps:
      - user: "I want to book"
        state: booking
        response: "For how many people?"
      - user: "4"
        state: confirm_booking
        response: "/Booked for \\d+ guests/"
        context:
          booking_id: "BK-001"

  - name: "Check menu then book"
    steps:
      - user: "show menu"
        state: menu
        response: "Pasta"
      - user: "I want to book"
        state: booking
      - user: "2"
        state: confirm_booking

  - name: "Unknown input stays in greeting"
    steps:
      - user: "asdfgh"
        state: greeting
```

**Run:**

```bash
python -m flowforge test scenario.yaml
```

```
  ✓ booking: I want to book
  ✓ booking: make a reservation
  ✓ booking: book a table
  ✓ menu: show menu
  ✓ menu: what do you have
  ✓ Book a table for 4
  ✓ Check menu then book
  ✓ Unknown input stays in greeting

8 passed, 0 failed
```
