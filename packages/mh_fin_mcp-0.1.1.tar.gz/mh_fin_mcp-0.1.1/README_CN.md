# mh-fin-mcp

[English](./README.md)

A股量化数据 MCP Server，为 AI 助手提供实时 A 股市场数据接口，由 [MetricHub Quant](https://quant.metrichub.app) 提供数据支持。

## 功能

- **市场全景**：主要指数行情、涨跌停统计、市场宽度、北向资金、情绪评分
- **行业轮动**：申万行业涨跌排名、涨停分布
- **板块热点**：概念板块涨停统计、领涨个股
- **个股数据**：5000+ A股全市场日线数据（OHLCV、PE、PB、市值、主力资金）
- **个股搜索**：按名称或代码模糊匹配
- **涨停分析**：13 因子量化评分（封板强度、时间、量能等）
- **因子有效性**：因子 IC 历史趋势
- **风险预警**：股东减持(R1)、业绩预亏(R2)等

## 快速开始

### 1. 获取 API Key

访问 [quant.metrichub.app](https://quant.metrichub.app) 注册账号，登录后在 [API Key 管理页](https://quant.metrichub.app/api-keys) 创建密钥。

### 2. 选择接入方式

#### 方式 A：远程服务器（推荐，无需安装）

无需安装任何东西，直接配置 URL 即可：

**Claude Desktop**（编辑 `claude_desktop_config.json`）：
```json
{
  "mcpServers": {
    "mh-fin": {
      "url": "https://api.quant.metrichub.app/mcp/sse",
      "headers": {
        "X-API-Key": "mhfk_你的密钥"
      }
    }
  }
}
```

**Claude Code**（编辑项目下 `.claude/settings.json`）：
```json
{
  "mcpServers": {
    "mh-fin": {
      "url": "https://api.quant.metrichub.app/mcp/sse",
      "headers": {
        "X-API-Key": "mhfk_你的密钥"
      }
    }
  }
}
```

#### 方式 B：本地安装（通过 PyPI）

```bash
pip install mh-fin-mcp
```

**Claude Desktop**（编辑 `claude_desktop_config.json`）：
```json
{
  "mcpServers": {
    "mh-fin": {
      "command": "uvx",
      "args": ["mh-fin-mcp"],
      "env": {
        "MH_FIN_API_KEY": "mhfk_你的密钥"
      }
    }
  }
}
```

**Claude Code**（编辑项目下 `.claude/settings.json`）：
```json
{
  "mcpServers": {
    "mh-fin": {
      "command": "uvx",
      "args": ["mh-fin-mcp"],
      "env": {
        "MH_FIN_API_KEY": "mhfk_你的密钥"
      }
    }
  }
}
```

### 3. 重启 Claude 即可使用

## 可用工具

| 工具 | 说明 |
|------|------|
| `get_trade_dates` | 获取可用交易日列表 |
| `get_market_overview` | 市场全景：指数行情、涨跌停、市场宽度、北向资金、情绪评分 |
| `get_industry_ranking` | 行业轮动：申万行业涨跌排名、涨停分布 |
| `get_sector_hotspots` | 板块热点：概念板块涨停统计、领涨个股 |
| `get_stock_list` | 全市场个股数据：5000+ A股，支持排序分页 |
| `search_stock` | 个股搜索：按名称或代码模糊匹配 |
| `get_limitup_analysis` | 涨停分析：13 因子量化评分 |
| `get_factor_ic` | 因子 IC：因子有效性历史趋势 |
| `get_risk_alerts` | 风险预警：股东减持(R1)、业绩预亏(R2) |

## 使用示例

配置好后在 Claude 中直接提问：

- "今天 A 股市场整体表现如何？"
- "帮我查一下最近涨停的股票"
- "搜索一下贵州茅台的数据"
- "最近哪些行业表现最强？"
- "有哪些风险预警的股票？"

## 数据说明

- 覆盖全部 5000+ A股
- 每个交易日 17:30（北京时间）后更新
- 包含 13 个量化因子评分
- 仅提供数据统计，不构成投资建议

## 许可证

MIT
