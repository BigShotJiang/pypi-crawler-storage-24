from setuptools import setup, find_packages

setup(
    name="powertrack",  # must be unique on PyPI
    version="0.1.0",
    author="Ege Güvener",
    author_email="egeguvener0808@gmail.com",
    description="A Python library that measures actual energy and power usage of a function.",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/powertrack",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.7',
)