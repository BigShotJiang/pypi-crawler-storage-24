from yta_editor_nodes_gpu.nodes import _FirstAndSecondTexturesGPUNode
from yta_editor_time.evaluation_context import EvaluationContext

import moderngl

    
class _TransitionNodeProcessorGPU(_FirstAndSecondTexturesGPUNode):
    """
    *For internal use only*

    Class to represent a node processor that uses GPU
    to build a transition from one video to another.

    The shader is using two inputs called `first_texture`
    and `second_texture`.
    """

    def process(
        self,
        render_target: 'RenderTarget',
        inputs: dict[str, moderngl.Texture],
        evaluation_context: EvaluationContext,
        **kwargs
    ) -> 'RenderTarget':
        """
        Validate the parameters, set the textures
        map, process it and return the result
        according to the `evaluation_context`
        provided.

        You can provide any additional parameter
        in the **kwargs, but be careful because
        this could overwrite other uniforms that
        were previously set.

        We use and return textures to maintain
        the process in GPU and optimize it.
        """
        return super().process(
            render_target = render_target,
            inputs = inputs,
            progress = float(evaluation_context.progress),
            **kwargs
        )