from yta_editor_nodes_gpu.processor.video.abstract import _VideoNodeProcessorGPU
from yta_editor_time.evaluation_context import EvaluationContext
from yta_video_opengl.pipeline import _OpenGLPipeline

import moderngl


# TODO: I don't know if this is working
class _BreathingFramePipelineGPU(_OpenGLPipeline):
    """
    *For internal use only*

    The frame but as if it was breathing.

    This pipeline is specific and unique for its the
    Node with the same name.
    """

    @property
    def fragment_shader(
        self
    ):
        return (
            '''
            #version 330
            uniform sampler2D base_texture;
            uniform float t;
            uniform float zoom;
            in vec2 v_uv;
            out vec4 output_color;
            // Use uniforms to be customizable

            void main() {
                // Dynamic zoom scaled with t
                float scale = 1.0 + zoom * sin(t * 2.0);
                vec2 center = vec2(0.5, 0.5);

                // Recalculate coords according to center
                vec2 uv = (v_uv - center) / scale + center;

                // Clamp to avoid artifacts
                uv = clamp(uv, 0.0, 1.0);

                output_color = texture(base_texture, uv);
            }
            '''
        )
    
    @property
    def _textures_expected(
        self
    ) -> dict:
        return {
            'base_texture': 0
        }
    
class BreathingFrameVideoNodeProcessorGPU(_VideoNodeProcessorGPU):
    """
    A node to modify the color of the textures we
    receive as input by transforming into a breathing
    frame.
    """

    def __init__(
        self,
        gpu_render_context: 'GPURenderContext'
    ):
        super().__init__(
            gpu_render_context = gpu_render_context,
            opengl_pipeline = _BreathingFramePipelineGPU
        )

    def process(
        self,
        render_target: 'RenderTarget',
        inputs: dict[str, moderngl.Texture],
        evaluation_context: EvaluationContext,
        zoom: float = 0.05,
        **kwargs
    ) -> 'RenderTarget':
        """
        Process the `inputs` provided and get an output of
        the given `output_size` and for the 
        `evaluation_context` provided.
        """
        return super().process(
            render_target = render_target,
            inputs = inputs,
            evaluation_context = evaluation_context,
            zoom = zoom
        )