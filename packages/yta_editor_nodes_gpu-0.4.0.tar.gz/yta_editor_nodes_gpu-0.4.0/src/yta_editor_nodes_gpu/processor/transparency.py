from yta_editor_nodes_gpu.processor.abstract import _NodeProcessorGPU
from yta_editor_time.evaluation_context import EvaluationContext
from yta_video_opengl.pipeline import _OpenGLPipeline

import moderngl


class _TransparencyPipelineGPU(_OpenGLPipeline):
    """
    *For internal use only*

    A OpenGL pipeline to modify transparency of the
    textures we receive as input by transforming
    them into more or less transparent outputs.

    This pipeline is specific and unique for its the
    Node with the same name.
    """

    @property
    def fragment_shader(
        self
    ):
        return (
            '''
            #version 330

            uniform sampler2D base_texture;
            uniform float transparency; // 1.0=full transparent, 0.0=full opaque

            in vec2 v_uv;
            out vec4 output_color;

            void main() {
                vec4 color = texture(base_texture, v_uv);
                color.a *= (1.0 - transparency);
                output_color = color;
            }
            '''
        )
    
    @property
    def _textures_expected(
        self
    ) -> dict:
        return {
            'base_texture': 0
        }
    
class TransparencyNodeProcessorGPU(_NodeProcessorGPU):
    """
    A node to modify the transparency of the textures we
    receive as input by transforming them into more or
    less transparent outputs.
    """

    def __init__(
        self,
        gpu_render_context: 'GPURenderContext'
    ):
        super().__init__(
            gpu_render_context = gpu_render_context,
            opengl_pipeline = _TransparencyPipelineGPU
        )

    def process(
        self,
        render_target: 'RenderTarget',
        inputs: dict[str, moderngl.Texture],
        evaluation_context: EvaluationContext,
        transparency: float = 1.0,
        **kwargs
    ) -> 'RenderTarget':
        """
        Process the `inputs` provided and get an output
        of the given `output_size` by using the
        `**dynamic_uniforms` if needed.
        """
        return super().process(
            render_target = render_target,
            inputs = inputs,
            transparency = transparency
        )