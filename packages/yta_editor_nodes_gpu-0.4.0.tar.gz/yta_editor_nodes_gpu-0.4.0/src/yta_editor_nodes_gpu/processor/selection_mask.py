from yta_editor_nodes_gpu.processor.abstract import _SelectionMaskProcessorGPU
from yta_editor_time.evaluation_context import EvaluationContext
from yta_video_opengl.pipeline import _OpenGLPipeline

import moderngl


class _SelectionMaskPipelineGPU(_OpenGLPipeline):
    """
    *For internal use only*

    A OpenGL pipeline to to use a mask selection (from
    which we will read the red color to determine if
    the pixel must be applied or not) to apply the
    `processed_texture` on the `original_texture`.

    If the selection mask is completely full, the
    result will be the `processed_texture`. If it is
    completely empty, the `original_texture`.

    This pipeline is specific and unique for its the
    Node with the same name.
    """

    @property
    def fragment_shader(
        self
    ):
        return (
            '''
            #version 330

            uniform sampler2D original_texture;
            uniform sampler2D processed_texture;
            // White = apply, black = ignore
            uniform sampler2D selection_mask_texture;
            in vec2 v_uv;
            out vec4 output_color;

            void main() {
                vec4 original_color = texture(original_texture, v_uv);
                vec4 processed_color = texture(processed_texture, v_uv);
                // We use the red as the value
                float mask = texture(selection_mask_texture, v_uv).r; 

                output_color = mix(original_color, processed_color, mask);
            }
            '''
        )
    
    @property
    def _textures_expected(
        self
    ) -> dict:
        return {
            'original_texture': 0,
            'processed_texture': 1,
            'selection_mask_texture': 2
        }
    
class SelectionMaskNodeProcessorGPU(_SelectionMaskProcessorGPU):
    """
    Class to use a mask selection (from which we will
    read the red color to determine if the pixel must
    be applied or not) to apply the `processed_texture`
    on the `original_texture`.

    If the selection mask is completely full, the
    result will be the `processed_texture`.
    """

    def __init__(
        self,
        gpu_render_context: 'GPURenderContext'
    ):
        super().__init__(
            gpu_render_context = gpu_render_context,
            opengl_pipeline = _SelectionMaskPipelineGPU
        )

    def process(
        self,
        render_target: 'RenderTarget',
        inputs: dict[str, moderngl.Texture],
        evaluation_context: EvaluationContext,
        **kwargs
    ) -> 'RenderTarget':
        """
        Process the `inputs` provided and get an output of
        the given `output_size`.
        """
        return super().process(
            render_target = render_target,
            inputs = inputs
        )