class GPURenderContext:
    """
    Class to wrap the information we need to
    be able to execute the nodes in GPU.

    This class must be created by the general
    node (located in `yta-editor-nodes` with the
    data from the general `RenderContext`).
    """

    def __init__(
        self,
        render_target_provider: 'RenderTargetProvider',
        opengl_context: 'moderngl.Context'
    ):
        self.render_target_provider: 'RenderTargetProvider' = render_target_provider
        """
        The `RenderTargetProvider` instance, able to acquire
        and release `RenderTarget` instances.
        """
        self.opengl_context: 'moderngl.Context' = opengl_context
        """
        The `moderngl.Context` instance.
        """