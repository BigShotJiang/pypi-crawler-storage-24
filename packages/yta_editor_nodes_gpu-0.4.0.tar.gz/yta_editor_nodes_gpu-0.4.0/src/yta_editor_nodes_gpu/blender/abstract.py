from yta_editor_nodes_gpu.nodes import _BaseAndOverlayTexturesGPUNode


class _NodeBlenderGPU(_BaseAndOverlayTexturesGPUNode):
    """
    A class to be able to identify the blenders.
    """

    pass