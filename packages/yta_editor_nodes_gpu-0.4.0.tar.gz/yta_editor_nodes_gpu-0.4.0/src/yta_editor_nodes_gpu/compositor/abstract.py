from yta_editor_nodes_gpu.nodes import _BaseAndOverlayTexturesGPUNode


class _NodeCompositorGPU(_BaseAndOverlayTexturesGPUNode):
    """
    Just a class to be able to identify the children
    as compositor nodes.
    """

    pass