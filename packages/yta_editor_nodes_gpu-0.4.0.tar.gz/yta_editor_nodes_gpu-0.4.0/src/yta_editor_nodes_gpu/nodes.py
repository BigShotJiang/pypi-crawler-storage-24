"""
Module to copy the nodes available in the 
`yta-video-opengl` library but receiving the
`GPURenderContext` and sending only the
parameters the nodes of this other library
need.

Check this file:
- `from yta_video_opengl.opengl_nodes`
"""
from yta_video_opengl.opengl_nodes import _SingleTextureOpenGLNode, _BaseAndOverlayTexturesOpenGLNode, _FirstAndSecondTexturesOpenGLNode, _OriginalProcessedSelectionOpenGLNode
from yta_validation.parameter import ParameterValidator


"""
TODO: Please, having all these classes is a bit
a non-sense when we could have one with a config
(see 'yta-editor-nodes-common', it is already
there). We are repeating a lot of code doing this.
"""
class _SingleTextureGPUNode(_SingleTextureOpenGLNode):
    """
    *For internal use only*

    A GPU node that uses a single texture called 
    `base_texture`.
    """

    mandatory_inputs: list[str] = ['base_input']
    """
    The inputs that are mandatory to be able to use the
    node.
    """
    optional_inputs: list[str] = []
    """
    The inputs that will be used in the node if provided
    but are not mandatory to make the node work properly.
    """

    def __init__(
        self,
        gpu_render_context: 'GPURenderContext',
        opengl_pipeline: '_OpenGLPipeline',
        **initial_parameters
    ):
        ParameterValidator.validate_mandatory_instance_of('gpu_render_context', gpu_render_context, 'GPURenderContext')

        super().__init__(
            opengl_pipeline = opengl_pipeline(
                opengl_context = gpu_render_context.opengl_context
            ),
            **initial_parameters
        )

        self.gpu_render_context: 'GPURenderContext' = gpu_render_context
        """
        The `GPURenderContext` instance.
        """

class _BaseAndOverlayTexturesGPUNode(_BaseAndOverlayTexturesOpenGLNode):
    """
    *For internal use only*

    An OpenGL node that uses a base texture called
    `base_texture` and an overlay texture named as
    `overlay_texture`.
    """

    mandatory_inputs: list[str] = ['base_input', 'overlay_input']
    """
    The inputs that are mandatory to be able to use the
    node.
    """
    optional_inputs: list[str] = []
    """
    The inputs that will be used in the node if provided
    but are not mandatory to make the node work properly.
    """

    def __init__(
        self,
        gpu_render_context: 'GPURenderContext',
        opengl_pipeline: '_OpenGLPipeline',
        **initial_parameters
    ):
        ParameterValidator.validate_mandatory_instance_of('gpu_render_context', gpu_render_context, 'GPURenderContext')
        ParameterValidator.validate_mandatory_subclass_of('opengl_pipeline', opengl_pipeline, '_OpenGLPipeline')

        super().__init__(
            opengl_pipeline = opengl_pipeline(
                opengl_context = gpu_render_context.opengl_context
            ),
            **initial_parameters
        )

        self.gpu_render_context: 'GPURenderContext' = gpu_render_context
        """
        The `GPURenderContext` instance.
        """

class _FirstAndSecondTexturesGPUNode(_FirstAndSecondTexturesOpenGLNode):
    """
    *For internal use only*

    An GPU node that uses a first texture called
    `first_texture` and a second texture named as
    `second_texture`.
    """

    mandatory_inputs: list[str] = ['first_input', 'second_input']
    """
    The inputs that are mandatory to be able to use the
    node.
    """
    optional_inputs: list[str] = []
    """
    The inputs that will be used in the node if provided
    but are not mandatory to make the node work properly.
    """

    def __init__(
        self,
        gpu_render_context: 'GPURenderContext',
        opengl_pipeline: '_OpenGLPipeline',
        **initial_parameters
    ):
        ParameterValidator.validate_mandatory_instance_of('gpu_render_context', gpu_render_context, 'GPURenderContext')

        super().__init__(
            opengl_pipeline = opengl_pipeline(
                opengl_context = gpu_render_context.opengl_context
            ),
            **initial_parameters
        )

        self.gpu_render_context: 'GPURenderContext' = gpu_render_context
        """
        The `GPURenderContext` instance.
        """

class _OriginalProcessedSelectionTexturesGPUNode(_OriginalProcessedSelectionOpenGLNode):
    """
    *For internal use only*

    A GPU node that uses one texture called
    `original_texture`, a second texture named as
    `processed_texture`, with also another one called
    `selection_mask_texture` to combine them.
    """

    mandatory_inputs: list[str] = ['original_input', 'processed_input', 'selection_mask_input']
    """
    The inputs that are mandatory to be able to use the
    node.
    """
    optional_inputs: list[str] = []
    """
    The inputs that will be used in the node if provided
    but are not mandatory to make the node work properly.
    """

    def __init__(
        self,
        gpu_render_context: 'GPURenderContext',
        opengl_pipeline: '_OpenGLPipeline',
        **initial_parameters
    ):
        ParameterValidator.validate_mandatory_instance_of('gpu_render_context', gpu_render_context, 'GPURenderContext')
        
        super().__init__(
            opengl_pipeline = opengl_pipeline(
                opengl_context = gpu_render_context.opengl_context
            ),
            **initial_parameters
        )

        self.gpu_render_context: 'GPURenderContext' = gpu_render_context
        """
        The `GPURenderContext` instance.
        """