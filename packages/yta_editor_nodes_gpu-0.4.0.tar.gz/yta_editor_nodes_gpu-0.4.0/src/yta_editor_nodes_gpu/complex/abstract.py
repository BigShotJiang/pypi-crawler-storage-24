from yta_editor_nodes_gpu.context import GPURenderContext
from yta_validation.parameter import ParameterValidator


class _NodeComplexGPU:
    """
    Nodes that are built by using different nodes
    inside, so working different than the others.
    """

    @property
    def context(
        self
    ) -> 'moderngl.Context':
        """
        The `moderngl.Context` instance extracted directly
        from the internal `GPURenderContext` instance.
        """
        return self.gpu_render_context.opengl_context

    def __init__(
        self,
        # TODO: Maybe rename to 'render_context' (?)
        gpu_render_context: 'GPURenderContext'
    ):
        """
        Provide all the variables you want to be initialized
        as uniforms at the begining for the global OpenGL
        animation in the `**kwargs`.
        """
        ParameterValidator.validate_instance_of('gpu_render_context', gpu_render_context, 'GPURenderContext')

        self.gpu_render_context: 'GPURenderContext' = gpu_render_context
        """
        The `GPURenderContext` instance.
        """