from yta_editor_nodes_gpu.complex.abstract import _NodeComplexGPU
from yta_editor_time.evaluation_context import EvaluationContext

import moderngl


class DisplayOverAtNodeComplexGPU(_NodeComplexGPU):
    """
    The overlay input is placed in the scene with the
    given position, rotation and size, and then put as
    an overlay of the also given base input.

    Information:
    - The scene size is `(1920, 1080)`, so provide the
    `position` parameter according to it, where it is
    representing the center of the texture.
    - The `rotation` is in degrees, where `rotation=90`
    means rotating 90 degrees to the right.
    - The `size` parameter must be provided according to
    the previously mentioned scene size `(1920, 1080)`.

    This complex node is using the next other nodes:
    - `DisplacementWithRotationNodeCompositorGPU`
    - `AlphaBlenderGPU`
    """

    mandatory_inputs = ['overlay_input']
    optional_inputs = ['base_input']

    def process(
        self,
        render_target: 'RenderTarget',
        inputs: dict[str, moderngl.Texture],
        evaluation_context: EvaluationContext,
        position: tuple[int, int] = (1920 / 2, 1080 / 2),
        size: tuple[int, int] = (1920 / 2, 1080 / 2),
        rotation: int = 0,
        **kwargs
    ) -> 'RenderTarget':
        """
        By default, the texture overlayed will be displayed in
        the center of the scene, with half of the scene size
        and no rotation.
        """
        from yta_editor_nodes_gpu.compositor import DisplacementWithRotationNodeCompositorGPU
        from yta_editor_nodes_gpu.blender import AlphaBlenderGPU
        from yta_editor_pools.render_target.context_manager import RenderTargetContextManager

        displacement_node_processor = DisplacementWithRotationNodeCompositorGPU(
            gpu_render_context = self.gpu_render_context
        )

        base_input = inputs.get('base_input', None)

        render_target_context_manager = RenderTargetContextManager(self.gpu_render_context.render_target_provider)

        if base_input is not None:
            with render_target_context_manager.acquire(
                width = render_target.width,
                height = render_target.height,
                number_of_components = render_target.number_of_components,
                dtype = render_target.dtype
            ) as render_target_intermediate:
                render_target_intermediate = displacement_node_processor.process(
                    render_target = render_target_intermediate,
                    inputs = {
                        'base_input': None,
                        # TODO: What if None (?)
                        'overlay_input': inputs['overlay_input']
                    },
                    evaluation_context = evaluation_context,
                    position = position,
                    size = size,
                    rotation = rotation
                    #rotation = 0.785398 # 0.785398 = 45deg
                )

                blender = AlphaBlenderGPU(
                    gpu_render_context = self.gpu_render_context
                )

                render_target = blender.process(
                    render_target = render_target,
                    inputs = {
                        'base_input': base_input,
                        'overlay_input': render_target_intermediate.texture
                    },
                    evaluation_context = evaluation_context,
                    mix_weight = 1.0,
                    blend_strength = 1.0
                )
        else:
            render_target = displacement_node_processor.process(
                render_target = render_target,
                inputs = {
                    'base_input': None,
                    # TODO: What if None (?)
                    'overlay_input': inputs['overlay_input']
                },
                evaluation_context = evaluation_context,
                position = position,
                size = size,
                rotation = rotation
            )

        return render_target
    