"""knktx MCP server — exposes project management tools for AI agents."""

import asyncio
import json
from collections.abc import Coroutine
from typing import Annotated, Any, Literal, TypeAlias

from mcp.server.fastmcp import FastMCP
from pydantic import Field

from knktx_mcp.client import ApiError, KnktxClient
from knktx_mcp.enforcement import StepData, render_rules, render_workflows

# Without a Field description, LLMs skip the agent_model param — this alias ensures
# every mutating tool exposes it with a clear prompt so agents consistently identify themselves.
_AgentModel: TypeAlias = Annotated[str | None, Field(description="Your full model ID (e.g. 'claude-opus-4-6', 'gpt-codex-5.4')")]
_Assignee: TypeAlias = Annotated[str | None, Field(description="Auto-populated from agent_model when omitted. Only set to override.")]


mcp = FastMCP(
    "knktx",
    instructions=(
        "At session start, call get_workflows() to retrieve your operational workflows and rules. "
        "Before starting any task, match against the workflow list and follow the matching "
        "workflow step-by-step. For project-scoped work, also call "
        "get_document(project_slug, 'handoff') for current state and "
        "get_document(project_slug, 'project_description') for architecture and locked decisions."
    ),
)

_client: KnktxClient | None = None
_client_lock = asyncio.Lock()


async def _get_client() -> KnktxClient:
    global _client
    async with _client_lock:
        if _client is None:
            _client = KnktxClient()
    return _client


async def _close_client() -> None:
    global _client
    if _client is not None:
        await _client.aclose()
        _client = None


def _fmt(data: Any) -> str:
    """Format API response as readable JSON. Passes strings through unchanged."""
    if isinstance(data, str):
        return data
    return json.dumps(data, indent=2, default=str)


async def _void_to_msg(coro: Coroutine[Any, Any, Any], msg: str) -> str:
    """Await a void-returning coroutine and return a static message string."""
    await coro
    return msg


async def _api_call(coro: Coroutine[Any, Any, Any]) -> str:
    """Execute an API call and format the result."""
    return _fmt(await coro)


# === Projects ===


@mcp.tool()
async def list_projects(include_archived: bool = False) -> str:
    """List all projects you own. By default, archived projects are excluded."""
    client = await _get_client()
    return await _api_call(client.list_projects(include_archived=include_archived))


@mcp.tool()
async def create_project(name: str, description: str | None = None, agent_model: _AgentModel = None) -> str:
    """Create a new project."""
    client = await _get_client()
    return await _api_call(client.create_project(name, description, agent_model=agent_model))


@mcp.tool()
async def get_project(slug: str) -> str:
    """Get project details by slug."""
    client = await _get_client()
    return await _api_call(client.get_project(slug))


@mcp.tool()
async def update_project(
    slug: str,
    name: str | None = None,
    description: str | None = None,
    agent_model: _AgentModel = None,
) -> str:
    """Update a project's name or description."""
    fields: dict[str, Any] = {}
    if name is not None:
        fields["name"] = name
    if description is not None:
        fields["description"] = description
    if not fields:
        return "No fields to update"
    client = await _get_client()
    return await _api_call(client.update_project(slug, **fields, agent_model=agent_model))


@mcp.tool()
async def archive_project(slug: str, agent_model: _AgentModel = None) -> str:
    """Archive a project (soft delete — can be restored)."""
    client = await _get_client()
    return await _api_call(client.archive_project(slug, agent_model=agent_model))


@mcp.tool()
async def restore_project(slug: str, agent_model: _AgentModel = None) -> str:
    """Restore an archived project."""
    client = await _get_client()
    return await _api_call(client.restore_project(slug, agent_model=agent_model))


@mcp.tool()
async def delete_project(slug: str, agent_model: _AgentModel = None) -> str:
    """Permanently delete a project. The project must be archived first. This cannot be undone."""
    client = await _get_client()
    return await _void_to_msg(client.delete_project(slug, agent_model=agent_model), "Project deleted.")


# === Boards ===


@mcp.tool()
async def list_boards(
    project_slug: str,
    status: Literal["active", "completed", "archived"] | None = "active",
) -> str:
    """List all boards in a project. Returns active boards by default. Pass status=null for all."""
    client = await _get_client()
    return await _api_call(client.list_boards(project_slug, status=status))


@mcp.tool()
async def create_board(project_slug: str, name: str, description: str | None = None, agent_model: _AgentModel = None) -> str:
    """Create a new plan board in a project."""
    client = await _get_client()
    return await _api_call(client.create_board(project_slug, name, description, agent_model=agent_model))


@mcp.tool()
async def get_board(project_slug: str, board_id: str) -> str:
    """Get a board with its cards."""
    client = await _get_client()

    async def _fetch() -> dict[str, Any]:
        data = await client.get_board(project_slug, board_id)
        data["cards"] = await client.list_cards(project_slug, board_id)
        return data

    return await _api_call(_fetch())


@mcp.tool()
async def update_board(
    project_slug: str,
    board_id: str,
    name: str | None = None,
    description: str | None = None,
    status: str | None = None,
    agent_model: _AgentModel = None,
) -> str:
    """Update a board's name, description, or status. Status: "active", "completed", or "archived"."""
    fields: dict[str, Any] = {}
    if name is not None:
        fields["name"] = name
    if description is not None:
        fields["description"] = description
    if status is not None:
        fields["status"] = status
    if not fields:
        return "No fields to update"
    client = await _get_client()
    return await _api_call(client.update_board(project_slug, board_id, **fields, agent_model=agent_model))


@mcp.tool()
async def delete_board(project_slug: str, board_id: str, agent_model: _AgentModel = None) -> str:
    """Delete a board and all its cards. This cannot be undone."""
    client = await _get_client()
    return await _void_to_msg(client.delete_board(project_slug, board_id, agent_model=agent_model), "Board deleted.")


# === Cards ===


@mcp.tool()
async def list_cards(project_slug: str, board_id: str) -> str:
    """List all cards on a board (all statuses)."""
    client = await _get_client()
    return await _api_call(client.list_cards(project_slug, board_id))


@mcp.tool()
async def get_card(project_slug: str, board_id: str, card_id: str) -> str:
    """Get a single card by ID."""
    client = await _get_client()
    return await _api_call(client.get_card(project_slug, board_id, card_id))


@mcp.tool()
async def create_card(
    project_slug: str,
    board_id: str,
    title: str,
    description: str | None = None,
    status: str = "inbox",
    assignee: _Assignee = None,
    source_note_id: str | None = None,
    agent_model: _AgentModel = None,
) -> str:
    """Create a task card on a board. Status: inbox, in_progress, done, or merged. Use source_note_id to link a card to the note that inspired it."""
    client = await _get_client()
    return await _api_call(
        client.create_card(project_slug, board_id, title, description=description, status=status, assignee=assignee, source_note_id=source_note_id, agent_model=agent_model)
    )


@mcp.tool()
async def update_card(
    project_slug: str,
    board_id: str,
    card_id: str,
    title: str | None = None,
    description: str | None = None,
    assignee: _Assignee = None,
    branch_name: str | None = None,
    pr_url: str | None = None,
    source_note_id: str | None = None,
    agent_model: _AgentModel = None,
) -> str:
    """Update a task card's details. Does not change status — use move_card for that."""
    fields: dict[str, Any] = {}
    if title is not None:
        fields["title"] = title
    if description is not None:
        fields["description"] = description
    if assignee is not None:
        fields["assignee"] = assignee
    if branch_name is not None:
        fields["branch_name"] = branch_name
    if pr_url is not None:
        fields["pr_url"] = pr_url
    if source_note_id is not None:
        fields["source_note_id"] = source_note_id
    if not fields:
        return "No fields to update"
    client = await _get_client()
    return await _api_call(
        client.update_card(project_slug, board_id, card_id, **fields, agent_model=agent_model)
    )


@mcp.tool()
async def move_card(project_slug: str, board_id: str, card_id: str, status: str, agent_model: _AgentModel = None) -> str:
    """Transition a card to a new status column. Status: inbox, in_progress, done, or merged."""
    client = await _get_client()
    return await _api_call(client.move_card(project_slug, board_id, card_id, status, agent_model=agent_model))


@mcp.tool()
async def delete_card(project_slug: str, board_id: str, card_id: str, agent_model: _AgentModel = None) -> str:
    """Delete a card from a board. This cannot be undone."""
    client = await _get_client()
    return await _void_to_msg(client.delete_card(project_slug, board_id, card_id, agent_model=agent_model), "Card deleted.")


@mcp.tool()
async def comment_on_card(
    project_slug: str,
    board_id: str,
    card_id: str,
    content: str,
    agent_model: _AgentModel = None,
) -> str:
    """Add a comment to a task card. Author is determined from the API key."""
    client = await _get_client()
    return await _api_call(client.comment_on_card(project_slug, board_id, card_id, content, agent_model=agent_model))


@mcp.tool()
async def list_comments(project_slug: str, board_id: str, card_id: str) -> str:
    """List all comments on a card."""
    client = await _get_client()
    return await _api_call(client.list_comments(project_slug, board_id, card_id))


@mcp.tool()
async def update_comment(
    project_slug: str,
    board_id: str,
    card_id: str,
    comment_id: str,
    content: str,
    agent_model: _AgentModel = None,
) -> str:
    """Edit an existing comment on a card."""
    client = await _get_client()
    return await _api_call(client.update_comment(project_slug, board_id, card_id, comment_id, content, agent_model=agent_model))


@mcp.tool()
async def delete_comment(
    project_slug: str,
    board_id: str,
    card_id: str,
    comment_id: str,
    agent_model: _AgentModel = None,
) -> str:
    """Delete a comment from a card. This cannot be undone."""
    client = await _get_client()
    return await _void_to_msg(
        client.delete_comment(project_slug, board_id, card_id, comment_id, agent_model=agent_model), "Comment deleted."
    )


# === Documents ===


@mcp.tool()
async def list_documents(
    project_slug: str,
    doc_type: str | None = None,
    board_id: str | None = None,
    path: str | None = None,
    include_completed: bool = False,
) -> str:
    """List documents in a project, optionally filtered. Documents linked to completed/archived boards are hidden by default."""
    client = await _get_client()
    return await _api_call(client.list_documents(project_slug, doc_type=doc_type, board_id=board_id, path=path, include_completed=include_completed))


@mcp.tool()
async def get_document(project_slug: str, doc_type: str, board_id: str | None = None) -> str:
    """Read a project document by type (e.g. "handoff", "project_description", "plan")."""
    client = await _get_client()
    return await _api_call(client.get_document_by_type(project_slug, doc_type, board_id=board_id))


@mcp.tool()
async def create_document(
    project_slug: str,
    doc_type: str,
    title: str,
    content: str,
    board_id: str | None = None,
    path: str | None = None,
    agent_model: _AgentModel = None,
) -> str:
    """Create or update a project document (upserts by project + doc_type + board_id)."""
    client = await _get_client()
    return await _api_call(
        client.write_document(project_slug, doc_type, title, content, board_id=board_id, path=path, agent_model=agent_model)
    )


@mcp.tool()
async def update_document(
    project_slug: str,
    document_id: str,
    title: str | None = None,
    content: str | None = None,
    path: str | None = None,
    agent_model: _AgentModel = None,
) -> str:
    """Update an existing document's title, content, or folder path. Change path to move between folders."""
    fields: dict[str, Any] = {}
    if title is not None:
        fields["title"] = title
    if content is not None:
        fields["content"] = content
    if path is not None:
        fields["path"] = path
    if not fields:
        return "No fields to update"
    client = await _get_client()
    return await _api_call(client.update_document(project_slug, document_id, **fields, agent_model=agent_model))


@mcp.tool()
async def delete_document(project_slug: str, document_id: str, agent_model: _AgentModel = None) -> str:
    """Delete a document. This cannot be undone."""
    client = await _get_client()
    return await _void_to_msg(client.delete_document(project_slug, document_id, agent_model=agent_model), "Document deleted.")


# === Notes ===


@mcp.tool()
async def get_note(note_id: str) -> str:
    """Get a note's full content by UUID (e.g. '550e8400-e29b-41d4-a716-446655440000')."""
    client = await _get_client()
    return await _api_call(client.get_note(note_id))


@mcp.tool()
async def list_notes(project_slug: str | None = None, status: str = "active", board_id: str | None = None) -> str:
    """List notes (summaries without content). Use get_note(note_id) for full content. Status: "active", "completed", or "archived"."""
    client = await _get_client()
    effective_board_id = board_id if project_slug else None
    return await _api_call(client.list_notes(project_slug=project_slug, status=status, board_id=effective_board_id))


@mcp.tool()
async def write_note(
    title: str,
    content: str | None = None,
    description: str | None = None,
    agent: str | None = None,
    tags: list[str] | None = None,
    status: str | None = None,
    board_id: str | None = None,
    clear_fields: list[str] | None = None,
    project_slug: str | None = None,
    agent_model: _AgentModel = None,
) -> str:
    """Write a note (upserts by title). PATCH semantics: omit a field to leave it unchanged.

    content: required when creating, optional on update (omit to keep existing).
    description: short summary (max 500 chars) shown in list results.
    status: "active", "completed", or "archived".
    clear_fields: list of field names to explicitly set to null (e.g. ["description", "tags"]).
      Clearable fields: description, content, agent, tags, board_id.
    """
    client = await _get_client()
    return await _api_call(
        client.write_note(title, content, description=description, agent=agent, tags=tags, status=status, board_id=board_id, clear_fields=clear_fields, project_slug=project_slug, agent_model=agent_model)
    )


@mcp.tool()
async def delete_note(title: str, project_slug: str | None = None, agent_model: _AgentModel = None) -> str:
    """Delete a note by title."""
    client = await _get_client()
    return await _void_to_msg(
        client.delete_note(title, project_slug=project_slug, agent_model=agent_model), "Note deleted."
    )


# === Skills ===


@mcp.tool()
async def list_skills(agent: str | None = None) -> str:
    """List all available skills, optionally filtered by agent."""
    agent = agent.strip().lower() if agent else None
    client = await _get_client()
    return await _api_call(client.list_skills(agent=agent))


@mcp.tool()
async def get_skill(slug: str) -> str:
    """Get a skill's content by slug."""
    client = await _get_client()
    return await _api_call(client.get_skill(slug))


@mcp.tool()
async def create_skill(
    name: str,
    content: str = "",
    version: str = "1.0.0",
    description: str | None = None,
    metadata: dict[str, Any] | None = None,
    is_public: bool = False,
    enabled: bool = True,
    user_invocable: bool = False,
    allowed_tools: list[str] | None = None,
    agent_model: _AgentModel = None,
) -> str:
    """Create a new skill."""
    client = await _get_client()
    return await _api_call(
        client.create_skill(name, content=content, version=version, description=description, metadata=metadata, is_public=is_public, enabled=enabled, user_invocable=user_invocable, allowed_tools=allowed_tools, agent_model=agent_model)
    )


@mcp.tool()
async def update_skill(
    slug: str,
    name: str | None = None,
    content: str | None = None,
    version: str | None = None,
    description: str | None = None,
    metadata: dict[str, Any] | None = None,
    is_public: bool | None = None,
    enabled: bool | None = None,
    user_invocable: bool | None = None,
    allowed_tools: list[str] | None = None,
    agent_model: _AgentModel = None,
) -> str:
    """Update an existing skill."""
    fields: dict[str, Any] = {}
    if name is not None:
        fields["name"] = name
    if content is not None:
        fields["content"] = content
    if version is not None:
        fields["version"] = version
    if description is not None:
        fields["description"] = description
    if metadata is not None:
        fields["metadata"] = metadata
    if is_public is not None:
        fields["is_public"] = is_public
    if enabled is not None:
        fields["enabled"] = enabled
    if user_invocable is not None:
        fields["user_invocable"] = user_invocable
    if allowed_tools is not None:
        fields["allowed_tools"] = allowed_tools
    if not fields:
        return "No fields to update"
    client = await _get_client()
    return await _api_call(client.update_skill(slug, **fields, agent_model=agent_model))


@mcp.tool()
async def delete_skill(slug: str, agent_model: _AgentModel = None) -> str:
    """Delete a skill by slug. This cannot be undone."""
    client = await _get_client()
    return await _void_to_msg(client.delete_skill(slug, agent_model=agent_model), "Skill deleted.")


# === MCP Configs ===


@mcp.tool()
async def list_mcp_configs(agent: str | None = None) -> str:
    """List all MCP server configurations, optionally filtered by agent."""
    agent = agent.strip().lower() if agent else None
    client = await _get_client()
    return await _api_call(client.list_mcp_configs(agent=agent))


@mcp.tool()
async def get_mcp_config(name: str) -> str:
    """Get an MCP server configuration by name."""
    client = await _get_client()
    return await _api_call(client.get_mcp_config(name))


@mcp.tool()
async def create_mcp_config(
    name: str,
    config: dict[str, Any],
    description: str | None = None,
    metadata: dict[str, Any] | None = None,
    is_public: bool = False,
    enabled: bool = True,
    install_command: str | None = None,
    agent_model: _AgentModel = None,
) -> str:
    """Create a new MCP server configuration."""
    client = await _get_client()
    return await _api_call(
        client.create_mcp_config(name, config, description=description, metadata=metadata, is_public=is_public, enabled=enabled, install_command=install_command, agent_model=agent_model)
    )


@mcp.tool()
async def update_mcp_config(
    name: str,
    config: dict[str, Any] | None = None,
    description: str | None = None,
    metadata: dict[str, Any] | None = None,
    is_public: bool | None = None,
    enabled: bool | None = None,
    install_command: str | None = None,
    agent_model: _AgentModel = None,
) -> str:
    """Update an MCP server configuration."""
    fields: dict[str, Any] = {}
    if config is not None:
        fields["config"] = config
    if description is not None:
        fields["description"] = description
    if metadata is not None:
        fields["metadata"] = metadata
    if is_public is not None:
        fields["is_public"] = is_public
    if enabled is not None:
        fields["enabled"] = enabled
    if install_command is not None:
        fields["install_command"] = install_command
    if not fields:
        return "No fields to update"
    client = await _get_client()
    return await _api_call(client.update_mcp_config(name, **fields, agent_model=agent_model))


@mcp.tool()
async def delete_mcp_config(name: str, agent_model: _AgentModel = None) -> str:
    """Delete an MCP server configuration. This cannot be undone."""
    client = await _get_client()
    return await _void_to_msg(client.delete_mcp_config(name, agent_model=agent_model), "MCP config deleted.")


# === Plugins ===


@mcp.tool()
async def list_plugins(agent: str | None = None) -> str:
    """List plugin configurations. Each entry is one agent (e.g. "claude") with its full install script, not individual plugins."""
    agent = agent.strip().lower() if agent else None
    client = await _get_client()
    return await _api_call(client.list_plugins(agent=agent))


@mcp.tool()
async def get_plugin(slug: str) -> str:
    """Get a plugin configuration by slug. Each entry is one agent (e.g. "claude")."""
    client = await _get_client()
    return await _api_call(client.get_plugin(slug))


@mcp.tool()
async def create_plugin(
    name: str,
    content: str = "",
    description: str | None = None,
    metadata: dict[str, Any] | None = None,
    is_public: bool = False,
    enabled: bool = True,
    agent_model: _AgentModel = None,
) -> str:
    """Create a plugin configuration. One entry per agent (e.g. name="claude"), not per plugin. Content contains the full install script. Check list_plugins() first to avoid duplicates."""
    client = await _get_client()
    return await _api_call(
        client.create_plugin(name, content=content, description=description, metadata=metadata, is_public=is_public, enabled=enabled, agent_model=agent_model)
    )


@mcp.tool()
async def update_plugin(
    slug: str,
    name: str | None = None,
    content: str | None = None,
    description: str | None = None,
    metadata: dict[str, Any] | None = None,
    is_public: bool | None = None,
    enabled: bool | None = None,
    agent_model: _AgentModel = None,
) -> str:
    """Update a plugin configuration. Changing the name may update the slug."""
    fields: dict[str, Any] = {}
    if name is not None:
        fields["name"] = name
    if content is not None:
        fields["content"] = content
    if description is not None:
        fields["description"] = description
    if metadata is not None:
        fields["metadata"] = metadata
    if is_public is not None:
        fields["is_public"] = is_public
    if enabled is not None:
        fields["enabled"] = enabled
    if not fields:
        return "No fields to update"
    client = await _get_client()
    return await _api_call(client.update_plugin(slug, **fields, agent_model=agent_model))


@mcp.tool()
async def delete_plugin(slug: str, agent_model: _AgentModel = None) -> str:
    """Delete a plugin configuration by slug. This cannot be undone."""
    client = await _get_client()
    return await _void_to_msg(client.delete_plugin(slug, agent_model=agent_model), "Plugin deleted.")


# === Activity ===


@mcp.tool()
async def get_activity(project_slug: str, limit: int = 20) -> str:
    """Get recent project activity (timeline). Returns the last 20 events by default."""
    client = await _get_client()
    return await _api_call(client.get_activity(project_slug, limit=limit))


# === Workflows ===


@mcp.tool()
async def get_workflows(agent: str | None = None) -> str:
    """Returns all enabled workflows and rules as structured markdown. Main entry point for agents to read operational instructions."""
    agent = agent.strip().lower() if agent else None
    client = await _get_client()
    data = await client.list_workflows(enabled=True, agent=agent)

    # Render workflows as markdown (with step-level agent filtering)
    result = render_workflows(data, agent=agent)

    # Also render rules
    try:
        rules_data = await client.list_rules(enabled=True, agent=agent)
        rules_section = render_rules(rules_data)
        if rules_section:
            result = result + "\n\n" + rules_section
    except ApiError as exc:
        result = result + f"\n\n[RULES LOAD ERROR: {exc} — rules omitted from this response]"

    return result


@mcp.tool()
async def list_workflows(enabled: bool | None = True, agent: str | None = None) -> str:
    """Returns workflow metadata list (id, name, trigger, enabled, version). By default returns only enabled workflows."""
    agent = agent.strip().lower() if agent else None
    client = await _get_client()
    return await _api_call(client.list_workflows(enabled=enabled, agent=agent))


@mcp.tool()
async def get_workflow(workflow_id: str) -> str:
    """Get a specific workflow by ID with full steps."""
    client = await _get_client()
    return await _api_call(client.get_workflow(workflow_id))


@mcp.tool()
async def create_workflow(
    name: str,
    steps: list[StepData] | None = None,
    description: str | None = None,
    trigger_type: Literal["event", "manual"] | None = None,
    trigger_config: dict[str, Any] | None = None,
    enabled: bool = True,
    agent_model: _AgentModel = None,
) -> str:
    """Create a new workflow. All workflows are global."""
    client = await _get_client()
    return await _api_call(
        client.create_workflow(name, description=description, trigger_type=trigger_type, trigger_config=trigger_config, steps=steps, enabled=enabled, agent_model=agent_model)
    )


@mcp.tool()
async def update_workflow(
    workflow_id: str,
    name: str | None = None,
    steps: list[StepData] | None = None,
    description: str | None = None,
    trigger_type: Literal["event", "manual"] | None = None,
    trigger_config: dict[str, Any] | None = None,
    enabled: bool | None = None,
    agent_model: _AgentModel = None,
) -> str:
    """Update an existing workflow's steps, trigger, or metadata."""
    client = await _get_client()

    kwargs = {
        k: v
        for k, v in {
            "name": name,
            "description": description,
            "trigger_type": trigger_type,
            "trigger_config": trigger_config,
            "steps": steps,
            "enabled": enabled,
        }.items()
        if v is not None
    }
    if not kwargs:
        return "No fields to update"
    return await _api_call(client.update_workflow(workflow_id, **kwargs, agent_model=agent_model))


@mcp.tool()
async def delete_workflow(workflow_id: str, agent_model: _AgentModel = None) -> str:
    """Delete a workflow by ID."""
    client = await _get_client()
    return await _void_to_msg(client.delete_workflow(workflow_id, agent_model=agent_model), "Workflow deleted.")


@mcp.tool()
async def duplicate_workflow(workflow_id: str, agent_model: _AgentModel = None) -> str:
    """Clone an existing workflow. Resets version to 1, appends ' (copy)' to name."""
    client = await _get_client()
    return await _api_call(client.duplicate_workflow(workflow_id, agent_model=agent_model))


# === Rules ===


@mcp.tool()
async def list_rules(
    rule_type: str | None = None,
    enabled: bool | None = None,
    source: Literal["custom", "settings"] | None = None,
    agent: str | None = None,
) -> str:
    """List all rules, optionally filtered. Rule types: prohibition, obligation, preference. Source: "custom" or "settings"."""
    agent = agent.strip().lower() if agent else None
    client = await _get_client()
    return await _api_call(client.list_rules(rule_type=rule_type, enabled=enabled, source=source, agent=agent))


@mcp.tool()
async def get_rule(rule_id: str) -> str:
    """Get a rule by its UUID."""
    client = await _get_client()
    return await _api_call(client.get_rule(rule_id))


@mcp.tool()
async def create_rule(
    name: str,
    rule_type: str,
    config: dict[str, Any] | None = None,
    description: str | None = None,
    source: Literal["custom", "settings"] = "custom",
    enabled: bool = True,
    agent_model: _AgentModel = None,
) -> str:
    """Create a new rule (rendered in get_workflows() output). Types: prohibition, obligation, preference. Source is immutable after creation."""
    client = await _get_client()
    return await _api_call(
        client.create_rule(name, rule_type, description=description, config=config, source=source, enabled=enabled, agent_model=agent_model)
    )


@mcp.tool()
async def update_rule(
    rule_id: str,
    name: str | None = None,
    description: str | None = None,
    rule_type: str | None = None,
    config: dict[str, Any] | None = None,
    enabled: bool | None = None,
    agent_model: _AgentModel = None,
) -> str:
    """Update an existing rule."""
    client = await _get_client()
    kwargs = {
        k: v
        for k, v in {
            "name": name,
            "description": description,
            "rule_type": rule_type,
            "config": config,
            "enabled": enabled,
        }.items()
        if v is not None
    }
    if not kwargs:
        return "No fields to update"
    return await _api_call(client.update_rule(rule_id, **kwargs, agent_model=agent_model))


@mcp.tool()
async def delete_rule(rule_id: str, agent_model: _AgentModel = None) -> str:
    """Delete a rule by ID."""
    client = await _get_client()
    return await _void_to_msg(client.delete_rule(rule_id, agent_model=agent_model), "Rule deleted.")


def main() -> None:
    """Entry point for the knktx MCP server."""
    mcp.run()


if __name__ == "__main__":
    main()
