#!/bin/bash

echo "=========================================="
echo "Test 1: Federate Authentication (Midway)"
echo "=========================================="
echo ""

# Check prerequisites
echo "Checking prerequisites..."
echo ""

# Check Midway session
if [ -f ~/.midway/cookie ]; then
    echo "✓ Midway cookie exists"
    USER=$(python -c "from src.agentcore_mcp_proxy.auth_manager import AuthManager; am = AuthManager(); print(am.get_user_alias())" 2>/dev/null)
    if [ $? -eq 0 ]; then
        echo "✓ User alias from Midway: $USER"
    else
        echo "✗ Could not extract user from Midway cookies"
        exit 1
    fi
else
    echo "✗ No Midway cookie found"
    echo "  Please run: mwinit"
    exit 1
fi

# Check cached tokens
if [ -d ~/.agentcore_mcp_proxy ]; then
    echo "⚠ Cached tokens exist (will be used if valid)"
    echo "  To force fresh authentication, run: rm -rf ~/.agentcore_mcp_proxy/"
else
    echo "✓ No cached tokens (will require authentication)"
fi

echo ""
echo "Configuration:"
python -c "from src.agentcore_mcp_proxy import config; print(f'  Gateway: {config.AGENTCORE_GATEWAY_URL[:50]}...'); print(f'  Cognito: {config.COGNITO_DOMAIN}'); print(f'  Callback: {config.COGNITO_CALLBACK_URL}')"

echo ""
echo "=========================================="
echo "Ready to test!"
echo "=========================================="
echo ""
echo "To start the MCP server and test authentication:"
echo "  python -m agentcore_mcp_proxy.server"
echo ""
echo "Expected behavior:"
echo "  1. Server will detect Midway session"
echo "  2. If no cached tokens, browser will open to Amazon SSO"
echo "  3. Authenticate with your Amazon credentials"
echo "  4. Success page will appear"
echo "  5. Server will initialize and be ready"
echo ""
echo "To test in Kiro:"
echo "  1. Ensure MCP server is configured in Kiro"
echo "  2. Restart Kiro or reload MCP servers"
echo "  3. Try listing tools - should see authentication tools"
echo "  4. Try calling a tool - should work without re-auth"
echo ""
