#!/usr/bin/env python3
"""
Authentication Manager for Social Media Tracker MCP Server
Handles Cognito OAuth flow, token management, and Midway cookie integration
"""

import os
import sys
import time
import socket
import signal
import subprocess
import requests
import webbrowser
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
from typing import Optional, Dict, Any
from http.cookiejar import MozillaCookieJar
import threading
import logging
import platform

from .token_encryption import TokenEncryption
from . import config


logger = logging.getLogger(__name__)


class OAuthCallbackHandler(BaseHTTPRequestHandler):
    """HTTP handler for OAuth callback"""
    
    # Class variable to store the authorization code
    auth_code = None
    
    def log_message(self, format, *args):
        """Suppress default HTTP server logging"""
        pass
    
    def do_GET(self):
        """Handle OAuth callback"""
        parsed_path = urlparse(self.path)
        
        if parsed_path.path == '/callback':
            # Extract authorization code
            query_params = parse_qs(parsed_path.query)
            code = query_params.get('code', [None])[0]
            
            if code:
                OAuthCallbackHandler.auth_code = code
                
                # Return success page
                self.send_response(200)
                self.send_header('Content-type', 'text/html')
                self.end_headers()
                
                success_html = '''
                <!DOCTYPE html>
                <html>
                <head>
                    <meta charset="UTF-8">
                    <title>Authentication Successful</title>
                    <style>
                        body {
                            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
                            min-height: 100vh;
                            display: flex;
                            align-items: center;
                            justify-content: center;
                            margin: 0;
                            padding: 20px;
                        }
                        .card {
                            background: linear-gradient(135deg, #a78bfa 0%, #8b5cf6 100%);
                            border-radius: 24px;
                            padding: 48px 40px;
                            max-width: 440px;
                            text-align: center;
                            box-shadow: 0 20px 60px rgba(139, 92, 246, 0.3);
                        }
                        .success-icon {
                            width: 80px;
                            height: 80px;
                            background: rgba(255, 255, 255, 0.2);
                            border-radius: 50%;
                            display: flex;
                            align-items: center;
                            justify-content: center;
                            margin: 0 auto 24px;
                            font-size: 48px;
                        }
                        h1 {
                            color: white;
                            font-size: 32px;
                            margin-bottom: 16px;
                        }
                        .message {
                            color: rgba(255, 255, 255, 0.9);
                            font-size: 16px;
                            line-height: 1.6;
                        }
                        .info {
                            color: rgba(255, 255, 255, 0.8);
                            font-size: 14px;
                            background: rgba(255, 255, 255, 0.1);
                            padding: 16px;
                            border-radius: 12px;
                            margin-top: 24px;
                        }
                    </style>
                </head>
                <body>
                    <div class="card">
                        <div class="success-icon">✓</div>
                        <h1>Authentication Successful!</h1>
                        <p class="message">You're all set and ready to go.</p>
                        <div class="info">
                            Your credentials have been securely encrypted and cached locally.
                            They will be used automatically for the next 30 days.
                        </div>
                        <p style="color: rgba(255, 255, 255, 0.7); font-size: 12px; margin-top: 24px;">
                            You can close this window and return to Kiro
                        </p>
                    </div>
                    <script>
                        setTimeout(() => { window.close(); }, 3000);
                    </script>
                </body>
                </html>
                '''
                self.wfile.write(success_html.encode())
            else:
                # No code received
                self.send_response(400)
                self.send_header('Content-type', 'text/html')
                self.end_headers()
                self.wfile.write(b'<h1>Error: No authorization code received</h1>')
        else:
            # Unknown path
            self.send_response(404)
            self.end_headers()


class AuthChoiceHandler(BaseHTTPRequestHandler):
    """HTTP handler for authentication method selection"""
    
    # Class variables to store user choice
    auth_choice = None  # Will be 'federate' or 'cognito_user'
    
    def log_message(self, format, *args):
        """Suppress default HTTP server logging"""
        pass
    
    def do_GET(self):
        """Handle authentication choice page and selection"""
        parsed_path = urlparse(self.path)
        
        if parsed_path.path == '/auth-choice':
            # Display authentication choice page
            self.send_response(200)
            self.send_header('Content-type', 'text/html')
            self.end_headers()
            
            choice_html = '''
            <!DOCTYPE html>
            <html>
            <head>
                <meta charset="UTF-8">
                <title>Customer Intelligence - Authentication</title>
                <style>
                    body {
                        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                        background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
                        min-height: 100vh;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        margin: 0;
                        padding: 20px;
                    }
                    .card {
                        background: linear-gradient(135deg, #a78bfa 0%, #8b5cf6 100%);
                        border-radius: 24px;
                        padding: 48px 40px;
                        max-width: 440px;
                        text-align: center;
                        box-shadow: 0 20px 60px rgba(139, 92, 246, 0.3);
                    }
                    h1 {
                        color: white;
                        font-size: 36px;
                        margin-bottom: 8px;
                        font-weight: 600;
                    }
                    .subtitle {
                        color: rgba(255, 255, 255, 0.9);
                        font-size: 18px;
                        margin-bottom: 24px;
                    }
                    .description {
                        color: rgba(255, 255, 255, 0.8);
                        font-size: 14px;
                        line-height: 1.6;
                        margin-bottom: 32px;
                    }
                    .button {
                        display: block;
                        width: 100%;
                        padding: 16px 24px;
                        margin-bottom: 16px;
                        background: rgba(255, 255, 255, 0.95);
                        color: #8b5cf6;
                        border: none;
                        border-radius: 12px;
                        font-size: 16px;
                        font-weight: 600;
                        cursor: pointer;
                        text-decoration: none;
                        transition: all 0.2s;
                        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
                    }
                    .button:hover {
                        background: white;
                        transform: translateY(-2px);
                        box-shadow: 0 6px 16px rgba(0, 0, 0, 0.15);
                    }
                    .button.secondary {
                        background: rgba(255, 255, 255, 0.15);
                        color: white;
                        border: 2px solid rgba(255, 255, 255, 0.3);
                    }
                    .button.secondary:hover {
                        background: rgba(255, 255, 255, 0.25);
                        border-color: rgba(255, 255, 255, 0.5);
                    }
                    .divider {
                        color: rgba(255, 255, 255, 0.6);
                        font-size: 14px;
                        margin: 24px 0;
                        position: relative;
                    }
                    .divider::before,
                    .divider::after {
                        content: '';
                        position: absolute;
                        top: 50%;
                        width: 40%;
                        height: 1px;
                        background: rgba(255, 255, 255, 0.3);
                    }
                    .divider::before { left: 0; }
                    .divider::after { right: 0; }
                    .note {
                        color: rgba(255, 255, 255, 0.7);
                        font-size: 12px;
                        margin-top: 24px;
                        font-style: italic;
                    }
                    .icon {
                        font-size: 20px;
                        margin-right: 8px;
                        vertical-align: middle;
                    }
                    .helper-text {
                        color: rgba(255, 255, 255, 0.7);
                        font-size: 13px;
                        margin-bottom: 20px;
                    }
                </style>
            </head>
            <body>
                <div class="card">
                    <h1>Sameer's MCP Auth</h1>
                    
                    <a href="/auth-select?method=federate" class="button">
                        <span class="icon">→</span>
                        Amazon Corporate Single Sign-On
                    </a>
                    <div class="helper-text">
                        Sign in with your Amazon corporate credentials
                    </div>
                    
                    <div class="divider">OR</div>
                    
                    <a href="/auth-select?method=cognito_user" class="button secondary">
                        Sign in with Cognito User
                    </a>
                    <div class="note">
                        For testing and development purposes
                    </div>
                </div>
            </body>
            </html>
            '''
            self.wfile.write(choice_html.encode())
            
        elif parsed_path.path == '/auth-select':
            # User selected authentication method
            query_params = parse_qs(parsed_path.query)
            method = query_params.get('method', [None])[0]
            
            if method in ['federate', 'cognito_user']:
                AuthChoiceHandler.auth_choice = method
                
                # Return loading page
                self.send_response(200)
                self.send_header('Content-type', 'text/html')
                self.end_headers()
                
                loading_html = '''
                <!DOCTYPE html>
                <html>
                <head>
                    <meta charset="UTF-8">
                    <title>Redirecting...</title>
                    <style>
                        body {
                            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
                            min-height: 100vh;
                            display: flex;
                            align-items: center;
                            justify-content: center;
                            margin: 0;
                        }
                        .card {
                            background: linear-gradient(135deg, #a78bfa 0%, #8b5cf6 100%);
                            border-radius: 24px;
                            padding: 48px 40px;
                            text-align: center;
                            box-shadow: 0 20px 60px rgba(139, 92, 246, 0.3);
                        }
                        h1 {
                            color: white;
                            font-size: 24px;
                            margin-bottom: 16px;
                        }
                        .spinner {
                            border: 4px solid rgba(255, 255, 255, 0.3);
                            border-top: 4px solid white;
                            border-radius: 50%;
                            width: 40px;
                            height: 40px;
                            animation: spin 1s linear infinite;
                            margin: 0 auto 20px;
                        }
                        @keyframes spin {
                            0% { transform: rotate(0deg); }
                            100% { transform: rotate(360deg); }
                        }
                    </style>
                </head>
                <body>
                    <div class="card">
                        <div class="spinner"></div>
                        <h1>Redirecting to authentication...</h1>
                    </div>
                </body>
                </html>
                '''
                self.wfile.write(loading_html.encode())
            else:
                self.send_response(400)
                self.end_headers()
        
        elif parsed_path.path == '/callback':
            # Handle OAuth callback (reuse OAuthCallbackHandler logic)
            query_params = parse_qs(parsed_path.query)
            code = query_params.get('code', [None])[0]
            
            if code:
                OAuthCallbackHandler.auth_code = code
                
                # Return success page
                self.send_response(200)
                self.send_header('Content-type', 'text/html')
                self.end_headers()
                
                success_html = '''
                <!DOCTYPE html>
                <html>
                <head>
                    <meta charset="UTF-8">
                    <title>Authentication Successful</title>
                    <style>
                        body {
                            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
                            min-height: 100vh;
                            display: flex;
                            align-items: center;
                            justify-content: center;
                            margin: 0;
                            padding: 20px;
                        }
                        .card {
                            background: linear-gradient(135deg, #a78bfa 0%, #8b5cf6 100%);
                            border-radius: 24px;
                            padding: 48px 40px;
                            max-width: 440px;
                            text-align: center;
                            box-shadow: 0 20px 60px rgba(139, 92, 246, 0.3);
                        }
                        .success-icon {
                            width: 80px;
                            height: 80px;
                            background: rgba(255, 255, 255, 0.2);
                            border-radius: 50%;
                            display: flex;
                            align-items: center;
                            justify-content: center;
                            margin: 0 auto 24px;
                            font-size: 48px;
                        }
                        h1 {
                            color: white;
                            font-size: 32px;
                            margin-bottom: 16px;
                        }
                        .message {
                            color: rgba(255, 255, 255, 0.9);
                            font-size: 16px;
                            line-height: 1.6;
                        }
                        .info {
                            color: rgba(255, 255, 255, 0.8);
                            font-size: 14px;
                            background: rgba(255, 255, 255, 0.1);
                            padding: 16px;
                            border-radius: 12px;
                            margin-top: 24px;
                        }
                    </style>
                </head>
                <body>
                    <div class="card">
                        <div class="success-icon">✓</div>
                        <h1>Authentication Successful!</h1>
                        <p class="message">You're all set and ready to go.</p>
                        <div class="info">
                            Your credentials have been securely encrypted and cached locally.
                            They will be used automatically for the next 30 days.
                        </div>
                        <p style="color: rgba(255, 255, 255, 0.7); font-size: 12px; margin-top: 24px;">
                            You can close this window and return to Kiro
                        </p>
                    </div>
                    <script>
                        setTimeout(() => { window.close(); }, 3000);
                    </script>
                </body>
                </html>
                '''
                self.wfile.write(success_html.encode())
            else:
                self.send_response(400)
                self.send_header('Content-type', 'text/html')
                self.end_headers()
                self.wfile.write(b'<h1>Error: No authorization code received</h1>')
        else:
            # Unknown path
            self.send_response(404)
            self.end_headers()


class AuthManager:
    """Manages Cognito authentication and token lifecycle"""
    
    def __init__(self):
        self.token_encryption = TokenEncryption()
        self.config = config
        self._callback_server = None
        self._callback_port = 8080
    
    def _kill_process_on_port(self, port: int) -> bool:
        """
        Kill any process using the specified port
        Returns True if a process was killed, False otherwise
        """
        system = platform.system()
        
        try:
            if system == 'Darwin' or system == 'Linux':
                # Use lsof to find process using the port
                result = subprocess.run(
                    ['lsof', '-ti', f':{port}'],
                    capture_output=True,
                    text=True,
                    timeout=5
                )
                
                if result.returncode == 0 and result.stdout.strip():
                    pids = result.stdout.strip().split('\n')
                    for pid in pids:
                        try:
                            pid_int = int(pid)
                            logger.info(f"Killing process {pid_int} using port {port}")
                            os.kill(pid_int, signal.SIGTERM)
                            time.sleep(0.5)  # Give it time to cleanup
                            return True
                        except (ValueError, ProcessLookupError) as e:
                            logger.warning(f"Could not kill process {pid}: {e}")
                    return True
                return False
            
            elif system == 'Windows':
                # Use netstat to find process using the port
                result = subprocess.run(
                    ['netstat', '-ano'],
                    capture_output=True,
                    text=True,
                    timeout=5
                )
                
                if result.returncode == 0:
                    for line in result.stdout.split('\n'):
                        if f':{port}' in line and 'LISTENING' in line:
                            parts = line.split()
                            if parts:
                                pid = parts[-1]
                                try:
                                    logger.info(f"Killing process {pid} using port {port}")
                                    subprocess.run(['taskkill', '/F', '/PID', pid], timeout=5)
                                    time.sleep(0.5)
                                    return True
                                except Exception as e:
                                    logger.warning(f"Could not kill process {pid}: {e}")
                return False
            
            else:
                logger.warning(f"Unsupported OS for port cleanup: {system}")
                return False
                
        except Exception as e:
            logger.warning(f"Error checking/killing process on port {port}: {e}")
            return False
    
    def get_midway_cookies(self) -> Optional[Dict[str, str]]:
        """Load Midway cookies from ~/.midway/cookie"""
        cookie_path = os.path.expanduser("~/.midway/cookie")
        
        if not os.path.exists(cookie_path):
            logger.warning(f"Midway cookie file not found at {cookie_path}")
            return None
        
        try:
            cookie_jar = MozillaCookieJar(cookie_path)
            cookie_jar.load(ignore_discard=True, ignore_expires=True)
            return requests.utils.dict_from_cookiejar(cookie_jar)
        except Exception as e:
            logger.error(f"Error loading Midway cookies: {e}")
            return None
    
    def get_user_from_midway_cookies(self, cookies: Dict[str, str]) -> Optional[str]:
        """Extract username from Midway cookies"""
        if 'user_name' in cookies:
            return cookies['user_name']
        
        # Try phonetool API as fallback
        try:
            response = requests.get(
                "https://phonetool.amazon.com/users/whoami",
                cookies=cookies,
                timeout=5
            )
            if response.status_code == 200:
                return response.json().get('login')
        except Exception as e:
            logger.warning(f"Could not get user from phonetool: {e}")
        
        return None
    
    def get_user_alias(self) -> str:
        """Get current user alias from Midway cookies"""
        cookies = self.get_midway_cookies()
        if not cookies:
            raise AuthError(
                "No Midway session found. Please run 'mwinit' to authenticate with Midway."
            )
        
        user_alias = self.get_user_from_midway_cookies(cookies)
        if not user_alias:
            raise AuthError(
                "Could not determine user from Midway cookies. Please run 'mwinit'."
            )
        
        return user_alias
    
    def get_user_from_id_token(self, id_token: str) -> Optional[str]:
        """Extract username from Cognito ID token (JWT)"""
        try:
            import base64
            import json
            
            # JWT format: header.payload.signature
            parts = id_token.split('.')
            if len(parts) != 3:
                logger.error("Invalid JWT format")
                return None
            
            # Decode payload (add padding if needed)
            payload = parts[1]
            payload += '=' * (4 - len(payload) % 4)
            decoded = base64.urlsafe_b64decode(payload)
            claims = json.loads(decoded)
            
            # Extract username from claims
            # Cognito uses 'cognito:username' claim
            username = claims.get('cognito:username') or claims.get('email')
            logger.info(f"Extracted username from ID token: {username}")
            return username
            
        except Exception as e:
            logger.error(f"Error extracting user from ID token: {e}")
            return None
    
    def exchange_code_for_tokens(self, auth_code: str) -> Optional[Dict[str, Any]]:
        """Exchange authorization code for Cognito tokens"""
        try:
            token_url = f"https://{self.config.COGNITO_DOMAIN}/oauth2/token"
            redirect_uri = f"http://localhost:{self._callback_port}/callback"
            
            response = requests.post(
                token_url,
                data={
                    'grant_type': 'authorization_code',
                    'client_id': self.config.COGNITO_CLIENT_ID,
                    'code': auth_code,
                    'redirect_uri': redirect_uri
                },
                headers={'Content-Type': 'application/x-www-form-urlencoded'},
                timeout=10
            )
            
            if response.status_code == 200:
                return response.json()
            else:
                logger.error(f"Token exchange failed: {response.text}")
                return None
                
        except Exception as e:
            logger.error(f"Error exchanging code for tokens: {e}")
            return None
    
    def refresh_cognito_token(self, refresh_token: str) -> Optional[Dict[str, Any]]:
        """Refresh Cognito access token"""
        try:
            token_url = f"https://{self.config.COGNITO_DOMAIN}/oauth2/token"
            
            response = requests.post(
                token_url,
                data={
                    'grant_type': 'refresh_token',
                    'client_id': self.config.COGNITO_CLIENT_ID,
                    'refresh_token': refresh_token
                },
                headers={'Content-Type': 'application/x-www-form-urlencoded'},
                timeout=10
            )
            
            if response.status_code == 200:
                return response.json()
            else:
                logger.error(f"Token refresh failed: {response.text}")
                return None
                
        except Exception as e:
            logger.error(f"Error refreshing token: {e}")
            return None
    
    def initiate_oauth_flow(self, user_alias: str = None, auth_method: str = None) -> str:
        """
        Start OAuth flow with browser and temporary callback server
        
        Args:
            user_alias: User alias (optional for cognito_user flow)
            auth_method: 'federate' or 'cognito_user' (if None, show choice page)
        
        Returns:
            access token after successful authentication
        """
        logger.info(f"Starting OAuth flow (user: {user_alias}, method: {auth_method})...")
        
        # Reset auth code and choice
        OAuthCallbackHandler.auth_code = None
        AuthChoiceHandler.auth_choice = None
        
        # Check if port is in use and kill the process if needed
        try:
            # Try to create a test socket to check if port is available
            test_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            test_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            test_socket.bind(('localhost', self._callback_port))
            test_socket.close()
            logger.info(f"Port {self._callback_port} is available")
        except OSError as e:
            if e.errno == 48 or 'Address already in use' in str(e):
                logger.warning(f"Port {self._callback_port} is in use, attempting to free it...")
                if self._kill_process_on_port(self._callback_port):
                    logger.info(f"✓ Freed port {self._callback_port}")
                    time.sleep(1)  # Give OS time to fully release the port
                else:
                    logger.warning(f"Could not free port {self._callback_port}, will try SO_REUSEADDR")
            else:
                raise
        
        # Create callback server with socket reuse enabled
        server_address = ('localhost', self._callback_port)
        
        # Use AuthChoiceHandler if no method specified, otherwise use OAuthCallbackHandler
        if auth_method is None:
            httpd = HTTPServer(server_address, AuthChoiceHandler)
        else:
            httpd = HTTPServer(server_address, OAuthCallbackHandler)
        
        # Enable socket reuse as additional safety
        httpd.socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        
        logger.info(f"✓ OAuth callback server started on port {self._callback_port}")
        
        server_thread = threading.Thread(target=httpd.serve_forever, daemon=True)
        server_thread.start()
        
        try:
            # If no auth_method specified, show choice page
            if auth_method is None:
                logger.info("No authentication method specified, showing choice page...")
                
                # Open browser to choice page
                choice_url = f"http://localhost:{self._callback_port}/auth-choice"
                
                print("\n" + "="*60)
                print("AUTHENTICATION REQUIRED")
                print("="*60)
                print(f"\nPlease select your authentication method in the browser.")
                print(f"If browser doesn't open, visit: {choice_url}")
                print("\nYou can choose between:")
                print("  • Amazon Corporate Single Sign-On (Midway/Federate)")
                print("  • Cognito User Pool (Username/Password)")
                print("="*60 + "\n")
                
                # Open browser
                webbrowser.open(choice_url)
                
                # Wait for user to select method (max 5 minutes)
                timeout = 300
                start_time = time.time()
                while AuthChoiceHandler.auth_choice is None:
                    if time.time() - start_time > timeout:
                        raise AuthError("Authentication selection timeout. Please try again.")
                    time.sleep(0.5)
                
                auth_method = AuthChoiceHandler.auth_choice
                logger.info(f"✓ User selected authentication method: {auth_method}")
            
            # Build Cognito auth URL based on method
            redirect_uri = f"http://localhost:{self._callback_port}/callback"
            
            if auth_method == 'cognito_user':
                # Cognito User Pool login (username/password)
                auth_url = (
                    f"https://{self.config.COGNITO_DOMAIN}/login?"
                    f"redirect_uri={redirect_uri}&"
                    f"response_type=code&"
                    f"client_id={self.config.COGNITO_CLIENT_ID}&"
                    f"scope=openid+email+profile"
                )
                
                logger.info("Opening browser for Cognito User Pool authentication...")
                print("\n" + "="*60)
                print("COGNITO USER POOL AUTHENTICATION")
                print("="*60)
                print(f"\nOpening browser for Cognito User Pool login...")
                print(f"Please enter your username and password in the browser.")
                print(f"If browser doesn't open, visit: {auth_url}")
                print("\nAfter authentication, your token will be encrypted and cached locally.")
                print("You won't need to authenticate again for 30 days.")
                print("="*60 + "\n")
            else:  # federate
                # Amazon Corporate SSO
                auth_url = (
                    f"https://{self.config.COGNITO_DOMAIN}/oauth2/authorize?"
                    f"identity_provider={self.config.AMAZON_IDP_NAME}&"
                    f"redirect_uri={redirect_uri}&"
                    f"response_type=code&"
                    f"client_id={self.config.COGNITO_CLIENT_ID}&"
                    f"scope=openid+email+profile"
                )
                
                logger.info("Opening browser for Federate authentication...")
                print("\n" + "="*60)
                print("AMAZON CORPORATE AUTHENTICATION")
                print("="*60)
                print(f"\nOpening browser for Cognito authentication...")
                print(f"If browser doesn't open, visit: {auth_url}")
                print("\nAfter authentication, your token will be encrypted and cached locally.")
                print("You won't need to authenticate again for 30 days.")
                print("="*60 + "\n")
            
            # Open browser
            webbrowser.open(auth_url)
            
            # Wait for callback (max 2 minutes)
            timeout = 120
            start_time = time.time()
            while OAuthCallbackHandler.auth_code is None:
                if time.time() - start_time > timeout:
                    raise AuthError("Authentication timeout. Please try again.")
                time.sleep(0.5)
            
            # Exchange code for tokens
            auth_code = OAuthCallbackHandler.auth_code
            tokens = self.exchange_code_for_tokens(auth_code)
            
            if not tokens:
                raise AuthError("Failed to exchange authorization code for tokens")
            
            # For cognito_user, extract username from ID token if not provided
            if auth_method == 'cognito_user' and not user_alias:
                user_alias = self.get_user_from_id_token(tokens.get('id_token'))
                if not user_alias:
                    raise AuthError("Could not extract username from Cognito ID token")
                logger.info(f"✓ Extracted user alias from ID token: {user_alias}")
            
            # Save tokens with auth_method metadata
            token_data = {
                'auth_method': auth_method,
                'access_token': tokens.get('access_token'),
                'refresh_token': tokens.get('refresh_token'),
                'id_token': tokens.get('id_token'),
                'expires_at': time.time() + tokens.get('expires_in', 3600) - 60
            }
            
            self.token_encryption.save_tokens(user_alias, token_data)
            logger.info(f"✓ Cached encrypted tokens for {user_alias} (method: {auth_method})")
            
            return token_data[self._get_token_field()]
            
        finally:
            # Shutdown callback server in a daemon thread with timeout
            # to avoid the 57-second hang caused by blocking httpd.shutdown()
            def _shutdown():
                try:
                    httpd.shutdown()
                except Exception:
                    pass

            shutdown_thread = threading.Thread(target=_shutdown, daemon=True)
            shutdown_thread.start()
            shutdown_thread.join(timeout=3)
            if shutdown_thread.is_alive():
                logger.warning("httpd.shutdown() timed out after 3s, forcing server_close()")
            httpd.server_close()
    
    def _get_token_field(self) -> str:
        """Return the token field name based on TOKEN_TYPE config."""
        return 'id_token' if self.config.TOKEN_TYPE == 'id_token' else 'access_token'

    def get_valid_token(self, user_alias: str = None) -> str:
        """
        Get valid token for user, handling refresh and re-auth.
        
        Returns access_token by default, or id_token if TOKEN_TYPE=id_token is configured.
        
        Args:
            user_alias: User alias (optional, will try to get from Midway or show choice)
        
        Returns:
            Token string (access_token or id_token based on TOKEN_TYPE config)
        
        Raises:
            AuthError if authentication is required
        """
        token_field = self._get_token_field()
        
        # If AMAZON_IDP_NAME is configured, try Midway first
        # If not configured, skip Midway entirely and go straight to Cognito User Pool
        if user_alias is None:
            if self.config.AMAZON_IDP_NAME:
                # Federate mode enabled — try Midway
                try:
                    user_alias = self.get_user_alias()  # From Midway cookies
                    logger.info(f"✓ Got user alias from Midway: {user_alias}")
                except AuthError as e:
                    # No Midway session - show choice page
                    logger.info("No Midway session found, will show authentication choice")
                    return self.initiate_oauth_flow(user_alias=None, auth_method=None)
            else:
                # No IDP configured — try cached tokens before launching browser
                logger.info("No AMAZON_IDP_NAME configured, checking cached tokens first")
                cached = self.token_encryption.load_tokens('cognito_user')
                if cached:
                    auth_method = cached.get('auth_method', 'cognito_user')
                    if cached.get('expires_at', 0) > time.time():
                        logger.info("Using cached cognito_user token")
                        return cached.get(token_field)
                    # Expired — try refresh
                    if cached.get('refresh_token'):
                        logger.info("Cached cognito_user token expired, attempting refresh...")
                        new_tokens = self.refresh_cognito_token(cached['refresh_token'])
                        if new_tokens:
                            token_data = {
                                'auth_method': auth_method,
                                'access_token': new_tokens.get('access_token'),
                                'refresh_token': cached.get('refresh_token'),
                                'id_token': new_tokens.get('id_token'),
                                'expires_at': time.time() + new_tokens.get('expires_in', 3600) - 60
                            }
                            self.token_encryption.save_tokens('cognito_user', token_data)
                            logger.info("✓ Cognito user token refreshed successfully")
                            return token_data[token_field]
                # No valid cached token — fall through to full OAuth flow
                logger.info("No valid cached token, initiating Cognito User Pool flow")
                return self.initiate_oauth_flow(user_alias=None, auth_method='cognito_user')
        
        # Load cached tokens
        tokens = self.token_encryption.load_tokens(user_alias)
        
        if tokens:
            # Backward compatibility: assume 'federate' if auth_method missing
            auth_method = tokens.get('auth_method', 'federate')
            
            # Check if token is still valid
            if tokens.get('expires_at', 0) > time.time():
                logger.info(f"Using cached {auth_method} token for {user_alias}")
                return tokens.get(token_field)
            
            # Token expired - try refresh
            if tokens.get('refresh_token'):
                logger.info(f"Token expired for {user_alias}, attempting refresh...")
                new_tokens = self.refresh_cognito_token(tokens['refresh_token'])
                
                if new_tokens:
                    token_data = {
                        'auth_method': auth_method,  # Preserve auth method
                        'access_token': new_tokens.get('access_token'),
                        'refresh_token': tokens.get('refresh_token'),  # Keep old refresh token
                        'id_token': new_tokens.get('id_token'),
                        'expires_at': time.time() + new_tokens.get('expires_in', 3600) - 60
                    }
                    self.token_encryption.save_tokens(user_alias, token_data)
                    logger.info(f"✓ Token refreshed successfully for {user_alias}")
                    return token_data[token_field]
        
        # No valid token - need full OAuth flow
        if user_alias:
            logger.info(f"No valid token found for {user_alias}, initiating federate OAuth flow...")
            return self.initiate_oauth_flow(user_alias=user_alias, auth_method='federate')
        else:
            logger.info(f"No valid token found, showing authentication choice...")
            return self.initiate_oauth_flow(user_alias=None, auth_method=None)


class AuthError(Exception):
    """Custom exception for authentication errors"""
    pass
