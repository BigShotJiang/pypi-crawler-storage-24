#!/bin/bash
set -e  # Exit on error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}Social Media Tracker MCP Server${NC}"
echo -e "${GREEN}Build, Test, and Deploy Pipeline${NC}"
echo -e "${GREEN}========================================${NC}\n"

# Check prerequisites
echo -e "${YELLOW}Checking prerequisites...${NC}"
command -v uv >/dev/null 2>&1 || { echo -e "${RED}Error: uv is not installed${NC}"; exit 1; }
command -v npx >/dev/null 2>&1 || { echo -e "${RED}Error: npx is not installed${NC}"; exit 1; }
echo -e "${GREEN}✓ Prerequisites OK${NC}\n"

# Step 1: Clean previous builds
echo -e "${YELLOW}Step 1: Cleaning previous builds...${NC}"
rm -rf dist/ build/ *.egg-info
echo -e "${GREEN}✓ Cleaned${NC}\n"

# Step 2: Build the package
echo -e "${YELLOW}Step 2: Building package...${NC}"
uv build
echo -e "${GREEN}✓ Package built successfully${NC}"
ls -lh dist/
echo ""

# Step 3: Install in editable mode for testing
echo -e "${YELLOW}Step 3: Installing in editable mode...${NC}"
uv pip install -e . --force-reinstall --no-deps
echo -e "${GREEN}✓ Installed in editable mode${NC}\n"

# Step 4: Verify installation
echo -e "${YELLOW}Step 4: Verifying installation...${NC}"
python -c "from agentcore_mcp_proxy import main; print('✓ Import successful')"
which agentcore_mcp_proxy
echo -e "${GREEN}✓ Installation verified${NC}\n"

# Step 5: Test with MCP Inspector
echo -e "${YELLOW}Step 5: Testing with MCP Inspector...${NC}"
echo -e "${YELLOW}This will open a browser window at http://localhost:6274${NC}"
echo -e "${YELLOW}Test the following tools:${NC}"
echo "  - list_territories"
echo "  - list_customers"
echo "  - get_activities_by_customer"
echo ""
echo -e "${YELLOW}Press Ctrl+C to stop the inspector when done testing${NC}"
echo -e "${YELLOW}Starting inspector in 3 seconds...${NC}"
sleep 3

# Kill any existing inspector processes
pkill -f "@modelcontextprotocol/inspector" 2>/dev/null || true
lsof -ti:6274 | xargs kill -9 2>/dev/null || true
lsof -ti:6277 | xargs kill -9 2>/dev/null || true
lsof -ti:5173 | xargs kill -9 2>/dev/null || true
sleep 1

# Get the full path to the installed command
VENV_BIN=$(dirname $(which python))
MCP_CMD="${VENV_BIN}/agentcore_mcp_proxy"

echo -e "${GREEN}Starting MCP Inspector...${NC}"
npx @modelcontextprotocol/inspector "$MCP_CMD" || {
    echo -e "${RED}Inspector test failed or was interrupted${NC}"
    echo -e "${YELLOW}If you completed testing, this is normal${NC}"
}
echo ""

# Step 6: Test in Kiro
echo -e "${YELLOW}Step 6: Testing in Kiro...${NC}"
echo -e "${YELLOW}Manual steps required:${NC}"
echo ""
echo "1. Open Kiro MCP Configuration:"
echo "   Command Palette → 'MCP: Open MCP Configuration'"
echo ""
echo "2. Update or add the agentcore_mcp_proxy server:"
echo '   {
     "agentcore_mcp_proxy": {
       "command": "'"$MCP_CMD"'",
       "args": [],
       "env": {
         "AGENTCORE_GATEWAY_URL": "https://socialmediatracker-gateway-jbk0fjwwjg.gateway.bedrock-agentcore.us-west-2.amazonaws.com/mcp",
         "COGNITO_USER_POOL_ID": "us-west-2_AThP6UY1M",
         "COGNITO_CLIENT_ID": "7tpkgnnh53ua6gt04347nk3qd3",
         "COGNITO_DOMAIN": "customer-intelligence-175918693907.auth.us-west-2.amazoncognito.com"
       },
       "disabled": false,
       "autoApprove": [
         "list_territories",
         "list_customers"
       ]
     }
   }'
echo ""
echo "3. Restart the MCP server in Kiro:"
echo "   Kiro sidebar → MCP Servers → right-click 'agentcore_mcp_proxy' → Restart"
echo ""
echo "4. Test in Kiro chat:"
echo "   Ask: 'List my territories'"
echo ""
read -p "Press Enter when Kiro testing is complete..."
echo -e "${GREEN}✓ Kiro testing complete${NC}\n"

# Step 7: Prepare for PyPI deployment
echo -e "${YELLOW}Step 7: Preparing for PyPI deployment...${NC}"
echo -e "${YELLOW}Before deploying to PyPI, ensure:${NC}"
echo "  1. Version number is updated in pyproject.toml"
echo "  2. README.md is complete and accurate"
echo "  3. LICENSE file is present"
echo "  4. All tests pass"
echo "  5. You have PyPI credentials configured"
echo ""
read -p "Have you completed the pre-deployment checklist? (y/n) " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo -e "${YELLOW}Deployment cancelled. Complete the checklist and run again.${NC}"
    exit 0
fi

# Step 8: Deploy to PyPI
echo -e "${YELLOW}Step 8: Deploying to PyPI...${NC}"
echo -e "${YELLOW}Choose deployment target:${NC}"
echo "  1. TestPyPI (recommended for first deployment)"
echo "  2. PyPI (production)"
read -p "Enter choice (1 or 2): " -n 1 -r
echo

if [[ $REPLY == "1" ]]; then
    echo -e "${YELLOW}Deploying to TestPyPI...${NC}"
    echo -e "${YELLOW}Ensure you have TestPyPI credentials configured:${NC}"
    echo "  uv publish --publish-url https://test.pypi.org/legacy/"
    echo ""
    read -p "Press Enter to deploy to TestPyPI or Ctrl+C to cancel..."
    uv publish --publish-url https://test.pypi.org/legacy/
    echo -e "${GREEN}✓ Deployed to TestPyPI${NC}"
    echo -e "${GREEN}Test installation with:${NC}"
    echo "  pip install --index-url https://test.pypi.org/simple/ agentcore-mcp-proxy"
elif [[ $REPLY == "2" ]]; then
    echo -e "${RED}WARNING: This will deploy to production PyPI!${NC}"
    read -p "Are you absolutely sure? (yes/no): " -r
    if [[ $REPLY == "yes" ]]; then
        echo -e "${YELLOW}Deploying to PyPI...${NC}"
        uv publish
        echo -e "${GREEN}✓ Deployed to PyPI${NC}"
        echo -e "${GREEN}Install with:${NC}"
        echo "  pip install agentcore-mcp-proxy"
        echo "  # or"
        echo "  uvx agentcore_mcp_proxy"
    else
        echo -e "${YELLOW}Deployment cancelled${NC}"
        exit 0
    fi
else
    echo -e "${RED}Invalid choice${NC}"
    exit 1
fi

echo ""
echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}Build, Test, and Deploy Complete!${NC}"
echo -e "${GREEN}========================================${NC}"
echo ""
echo -e "${GREEN}Package: agentcore-mcp-proxy${NC}"
echo -e "${GREEN}Version: $(grep '^version' pyproject.toml | cut -d'"' -f2)${NC}"
echo -e "${GREEN}Distribution files:${NC}"
ls -lh dist/
echo ""
echo -e "${YELLOW}Next steps:${NC}"
echo "  - Update documentation with installation instructions"
echo "  - Tag the release in git: git tag v$(grep '^version' pyproject.toml | cut -d'"' -f2)"
echo "  - Push tags: git push --tags"
echo "  - Create GitHub release with changelog"
