# Kiro Testing Checklist

## Test 1: Verify Authentication Tools Appear

**Action**: Ask Kiro to list available tools from the Social Media Tracker MCP server

**Expected Result**: You should see these new authentication tools:
- `authenticate_with_cognito_user` - Authenticate using Cognito User Pool credentials
- `authenticate_with_federate` - Authenticate using Amazon Corporate Single Sign-On

Plus the existing 10 tools:
- `get_activities_by_customer`
- `get_activities_by_source`
- `get_activity_frequency`
- `get_activity_heatmap`
- `get_activity_velocity`
- `get_geo_distribution`
- `get_hashtag_analytics`
- `get_customer`
- `list_customers`
- `list_territories`

---

## Test 2: Test Existing Tools (Federate Auth)

**Action**: Ask Kiro to call any existing tool, for example:
```
"List all territories"
```

**Expected Result**: 
- Tool executes successfully
- Returns territory data
- No authentication prompt (uses cached federate tokens)

---

## Test 3: Test Authentication Tool - Cognito User

**Action**: Ask Kiro to:
```
"Authenticate with Cognito User"
```

**Expected Result**:
1. Browser opens to Cognito Hosted UI
2. Shows username/password form
3. After entering credentials:
   - Success page appears
   - Kiro shows success message
   - Server re-initializes with new token

**Note**: You'll need a Cognito User Pool user for this test.

---

## Test 4: Test Authentication Tool - Federate

**Action**: Ask Kiro to:
```
"Authenticate with Amazon Corporate Single Sign-On"
```

**Expected Result**:
1. Browser opens to Amazon SSO
2. After authentication:
   - Success page appears
   - Kiro shows success message
   - Server re-initializes with new token

---

## Test 5: Verify Token Metadata

**Action**: Check the stored tokens to verify auth_method is tracked

**Command**:
```bash
python -c "from src.agentcore_mcp_proxy.token_encryption import TokenEncryption; te = TokenEncryption(); tokens = te.load_tokens('sbattoo'); print(f'Auth method: {tokens.get(\"auth_method\", \"not set\")}') if tokens else print('No tokens')"
```

**Expected Result**: Should show `Auth method: federate` (or `cognito_user` if you tested that)

---

## Test 6: Test Without Midway (Choice Page)

**Prerequisites**: 
```bash
mv ~/.midway/cookie ~/.midway/cookie.backup
rm -rf ~/.agentcore_mcp_proxy/
```

**Action**: Restart Kiro MCP server

**Expected Result**:
1. Browser opens to authentication choice page
2. Beautiful UI with two buttons:
   - "Amazon Corporate Single Sign-On"
   - "Sign in with Cognito User"
3. Click either button to authenticate

**Cleanup**:
```bash
mv ~/.midway/cookie.backup ~/.midway/cookie
```

---

## Troubleshooting

### If tools don't appear:
1. Check MCP server logs: `/tmp/agentcore_mcp_proxy.log`
2. Verify MCP configuration: `~/.kiro/settings/mcp.json`
3. Restart Kiro completely

### If authentication fails:
1. Check logs for error messages
2. Verify Cognito configuration in `.env`
3. Ensure port 8080 is available

### If browser doesn't open:
1. Check firewall settings
2. Try manually visiting: `http://localhost:8080/auth-choice`
3. Check if another process is using port 8080

---

## Success Criteria

✅ All 12 tools appear in Kiro  
✅ Existing tools work without re-authentication  
✅ New authentication tools trigger browser flows  
✅ Token metadata includes `auth_method`  
✅ Choice page appears when Midway unavailable  
✅ Both authentication methods work end-to-end  

---

## Quick Test Commands for Kiro

Try these prompts in Kiro:

1. "List all available tools from Social Media Tracker"
2. "List all territories"
3. "Search for customers with name containing 'hex' and include insights"
4. "Authenticate with Cognito User"
5. "Show me the authentication tools available"

