# Build, Test, and Deploy Guide

Complete guide for building, testing, and deploying the Social Media Tracker MCP Server to PyPI.

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [Build Process](#build-process)
3. [Testing](#testing)
4. [Deployment](#deployment)
5. [Troubleshooting](#troubleshooting)

---

## Prerequisites

### Required Tools

- **Python 3.10+**: The MCP server requires Python 3.10 or higher
- **uv**: Fast Python package manager and build tool
  ```bash
  # Install uv (macOS/Linux)
  curl -LsSf https://astral.sh/uv/install.sh | sh
  
  # Or with pip
  pip install uv
  ```
- **Node.js & npm**: Required for MCP Inspector
  ```bash
  # Check if installed
  node --version
  npm --version
  ```

### Environment Setup

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd proxy_mcp_server
   ```

2. **Create virtual environment**
   ```bash
   uv venv
   source .venv/bin/activate  # On Windows: .venv\Scripts\activate
   ```

3. **Install dependencies**
   ```bash
   uv pip install -e .
   ```

4. **Configure environment variables**
   
   Create a `.env` file in the project root:
   ```bash
   cp .env.sample .env
   ```
   
   Edit `.env` with your AWS resources:
   ```bash
   AGENTCORE_GATEWAY_URL=https://your-gateway.gateway.bedrock-agentcore.us-west-2.amazonaws.com/mcp
   COGNITO_USER_POOL_ID=us-west-2_XXXXXXXXX
   COGNITO_CLIENT_ID=your_client_id_here
   COGNITO_DOMAIN=your-domain.auth.us-west-2.amazoncognito.com
   ```

---

## Build Process

### Automated Build (Recommended)

Run the automated build script:

```bash
./Build_Test_Deploy.sh
```

The script will guide you through all steps interactively.

### Manual Build Steps

#### Step 1: Clean Previous Builds

Remove any previous build artifacts:

```bash
rm -rf dist/ build/ *.egg-info
```

#### Step 2: Build the Package

Build both wheel and source distribution:

```bash
uv build
```

This creates:
- `dist/agentcore_mcp_proxy-0.1.0-py3-none-any.whl` (wheel)
- `dist/agentcore_mcp_proxy-0.1.0.tar.gz` (source distribution)

#### Step 3: Install in Editable Mode

Install the package in development mode:

```bash
uv pip install -e . --force-reinstall --no-deps
```

This allows you to make changes without rebuilding.

#### Step 4: Verify Installation

Test that the package imports correctly:

```bash
python -c "from agentcore_mcp_proxy import main; print('✓ Import successful')"
which agentcore_mcp_proxy
```

---

## Testing

### 1. MCP Inspector Testing (Interactive Browser Testing)

The MCP Inspector provides a visual interface to test your MCP server.

#### Start the Inspector

```bash
# Kill any existing inspector processes
pkill -f "@modelcontextprotocol/inspector" 2>/dev/null || true
lsof -ti:6274 | xargs kill -9 2>/dev/null || true

# Start the inspector
npx @modelcontextprotocol/inspector agentcore_mcp_proxy
```

Or use the full path:

```bash
npx @modelcontextprotocol/inspector /path/to/.venv/bin/agentcore_mcp_proxy
```

#### What to Test

The inspector will open at `http://localhost:6274`. Test the following:

1. **Tools Tab**: Verify all 10 tools are listed
   - `list_territories`
   - `list_customers`
   - `get_activities_by_customer`
   - `get_activities_by_source`
   - `get_activity_frequency`
   - `get_activity_heatmap`
   - `get_activity_velocity`
   - `get_geo_distribution`
   - `get_hashtag_analytics`
   - `get_customer`

2. **Test Simple Tools First**
   - Click `list_territories`
   - Click "Execute"
   - Verify you see territory data

3. **Test Tools with Parameters**
   - Click `get_activities_by_customer`
   - Fill in `customer_ids`: `["cust_123"]`
   - Click "Execute"
   - Verify response

4. **Check Logs**
   - View request/response logs in the inspector
   - Check `/tmp/agentcore_mcp_proxy.log` for detailed logs

#### Authentication Flow

On first run, the server will:
1. Check for cached tokens in `~/.agentcore_mcp_proxy/`
2. If not found, open a browser for Cognito authentication
3. Cache encrypted tokens for 30 days

#### Troubleshooting Inspector

**Port conflicts:**
```bash
# Kill all inspector processes
pkill -f "@modelcontextprotocol/inspector"
lsof -ti:6274 | xargs kill -9
lsof -ti:6277 | xargs kill -9
lsof -ti:5173 | xargs kill -9
```

**Environment variables not loading:**
```bash
# Run from project directory (where .env file is)
cd /path/to/proxy_mcp_server
npx @modelcontextprotocol/inspector agentcore_mcp_proxy
```

**Import errors:**
```bash
# Rebuild and reinstall
uv build
uv pip install -e . --force-reinstall --no-deps
```

### 2. Kiro Testing (Production-like Environment)

Test the MCP server in Kiro to ensure it works in a real IDE environment.

#### Configure Kiro

1. **Open MCP Configuration**
   - Command Palette → `MCP: Open MCP Configuration`
   - Or edit `~/.kiro/settings/mcp.json` directly

2. **Add Server Configuration**
   ```json
   {
     "mcpServers": {
       "agentcore_mcp_proxy": {
         "command": "/path/to/.venv/bin/agentcore_mcp_proxy",
         "args": [],
         "env": {
           "AGENTCORE_GATEWAY_URL": "https://your-gateway.gateway.bedrock-agentcore.us-west-2.amazonaws.com/mcp",
           "COGNITO_USER_POOL_ID": "us-west-2_XXXXXXXXX",
           "COGNITO_CLIENT_ID": "your_client_id_here",
           "COGNITO_DOMAIN": "your-domain.auth.us-west-2.amazoncognito.com"
         },
         "disabled": false,
         "autoApprove": [
           "list_territories",
           "list_customers",
           "get_activities_by_customer",
           "get_customer"
         ]
       }
     }
   }
   ```

3. **Restart MCP Server**
   - Kiro sidebar → MCP Servers
   - Right-click `agentcore_mcp_proxy`
   - Click "Restart"

#### Test in Kiro

1. **Check Connection**
   - Look for green indicator next to `agentcore_mcp_proxy` in MCP Servers panel
   - Check logs: View → Output → Select "Kiro - MCP Logs"

2. **Test Tool Calls**
   
   In Kiro chat, ask:
   ```
   List my territories
   ```
   
   The AI should use the `list_territories` tool and return your territory data.
   
   Try other queries:
   ```
   Show me customers in my territory
   Get activities for customer cust_123
   What are the trending hashtags?
   ```

3. **Verify Logs**
   - Check `/tmp/agentcore_mcp_proxy.log`
   - Verify authentication succeeded
   - Verify tool calls are being made

#### Troubleshooting Kiro

**Server won't start:**
- Check the full path to `agentcore_mcp_proxy` is correct
- Verify environment variables are set in the config
- Check Kiro MCP Logs for error messages

**Authentication errors:**
- For Federate: Ensure you've run `mwinit` for Midway authentication
- For Cognito User: Verify username/password credentials
- Delete `~/.agentcore_mcp_proxy/` and re-authenticate
- Check Cognito configuration is correct
- Try the authentication choice page or MCP authentication tools

**Tools not appearing:**
- Restart the MCP server
- Check gateway URL is correct
- Verify network connectivity to AgentCore Gateway

---

## Deployment

### Pre-Deployment Checklist

Before deploying to PyPI, ensure:

- [ ] Version number updated in `pyproject.toml`
- [ ] `README.md` is complete and accurate
- [ ] `LICENSE` file is present
- [ ] All tests pass (Inspector + Kiro)
- [ ] `.env.sample` is up to date
- [ ] `.gitignore` excludes sensitive files
- [ ] Documentation is complete
- [ ] PyPI credentials are configured

### PyPI Credentials Setup

#### Option 1: API Token (Recommended)

1. Create PyPI account at https://pypi.org
2. Generate API token: Account Settings → API tokens → Add API token
3. Configure uv:
   ```bash
   # Create ~/.pypirc
   cat > ~/.pypirc << EOF
   [pypi]
   username = __token__
   password = pypi-YOUR_TOKEN_HERE
   EOF
   
   chmod 600 ~/.pypirc
   ```

#### Option 2: Username/Password

```bash
cat > ~/.pypirc << EOF
[pypi]
username = your_username
password = your_password
EOF

chmod 600 ~/.pypirc
```

### Deploy to TestPyPI (Recommended First)

TestPyPI is a separate instance for testing package uploads.

1. **Create TestPyPI account** at https://test.pypi.org

2. **Configure TestPyPI credentials**
   ```bash
   cat >> ~/.pypirc << EOF
   
   [testpypi]
   repository = https://test.pypi.org/legacy/
   username = __token__
   password = pypi-YOUR_TESTPYPI_TOKEN_HERE
   EOF
   ```

3. **Upload to TestPyPI**
   ```bash
   uv publish --publish-url https://test.pypi.org/legacy/
   ```

4. **Test installation from TestPyPI**
   ```bash
   # Create a new virtual environment
   python -m venv test_env
   source test_env/bin/activate
   
   # Install from TestPyPI
   pip install --index-url https://test.pypi.org/simple/ agentcore-mcp-proxy
   
   # Test it works
   agentcore_mcp_proxy --help
   ```

### Deploy to Production PyPI

Once TestPyPI deployment is verified:

1. **Final checks**
   ```bash
   # Verify version
   grep '^version' pyproject.toml
   
   # Verify build artifacts
   ls -lh dist/
   
   # Verify package metadata
   tar -tzf dist/agentcore_mcp_proxy-*.tar.gz | head -20
   ```

2. **Upload to PyPI**
   ```bash
   uv publish
   ```

3. **Verify on PyPI**
   - Visit https://pypi.org/project/agentcore-mcp-proxy/
   - Check package metadata, description, and links

4. **Test installation**
   ```bash
   # In a fresh environment
   pip install agentcore-mcp-proxy
   
   # Or with uvx (no installation)
   uvx agentcore_mcp_proxy
   ```

### Post-Deployment

1. **Tag the release**
   ```bash
   VERSION=$(grep '^version' pyproject.toml | cut -d'"' -f2)
   git tag -a "v${VERSION}" -m "Release v${VERSION}"
   git push origin "v${VERSION}"
   ```

2. **Create GitHub release**
   - Go to GitHub → Releases → Create new release
   - Select the tag you just created
   - Add release notes with changelog
   - Attach distribution files from `dist/`

3. **Update documentation**
   - Update README with installation instructions
   - Update version references
   - Add to CHANGELOG.md

4. **Announce**
   - Share on relevant channels
   - Update internal documentation
   - Notify users of new version

---

## Troubleshooting

### Build Issues

**Import errors after build:**
```bash
# Check for circular imports
python -c "from agentcore_mcp_proxy import main"

# Verify all imports use relative imports
grep -r "^from [^.]" src/agentcore_mcp_proxy/*.py
```

**Missing dependencies:**
```bash
# Reinstall all dependencies
uv pip install -e . --force-reinstall
```

### Testing Issues

**MCP Inspector won't start:**
```bash
# Clear all ports
pkill -f "@modelcontextprotocol/inspector"
for port in 5173 6274 6277; do
  lsof -ti:$port | xargs kill -9 2>/dev/null || true
done

# Try again
npx @modelcontextprotocol/inspector agentcore_mcp_proxy
```

**Authentication fails:**
```bash
# Clear cached tokens
rm -rf ~/.agentcore_mcp_proxy/

# For Federate authentication: Verify Midway authentication
mwinit

# For Cognito User: Use the authentication choice page or MCP tools

# Check environment variables
env | grep COGNITO
env | grep AGENTCORE
```

**Tools not discovered:**
```bash
# Check gateway connectivity
curl -I https://your-gateway.gateway.bedrock-agentcore.us-west-2.amazonaws.com/mcp

# Check logs
tail -f /tmp/agentcore_mcp_proxy.log
```

### Deployment Issues

**Upload fails:**
```bash
# Verify credentials
cat ~/.pypirc

# Check package validity
twine check dist/*

# Try with verbose output
uv publish --verbose
```

**Package not found after upload:**
- Wait a few minutes for PyPI to index
- Check package name spelling
- Verify upload succeeded (check PyPI website)

**Installation fails:**
```bash
# Check package on PyPI
pip index versions agentcore-mcp-proxy

# Try with verbose output
pip install -v agentcore-mcp-proxy
```

---

## Quick Reference

### Common Commands

```bash
# Build
uv build

# Install locally
uv pip install -e .

# Test with inspector
npx @modelcontextprotocol/inspector agentcore_mcp_proxy

# Deploy to TestPyPI
uv publish --publish-url https://test.pypi.org/legacy/

# Deploy to PyPI
uv publish

# Clean build artifacts
rm -rf dist/ build/ *.egg-info

# View logs
tail -f /tmp/agentcore_mcp_proxy.log
```

### File Locations

- **Package source**: `src/agentcore_mcp_proxy/`
- **Build artifacts**: `dist/`
- **Configuration**: `pyproject.toml`
- **Environment**: `.env`
- **Logs**: `/tmp/agentcore_mcp_proxy.log`
- **Cached tokens**: `~/.agentcore_mcp_proxy/`
- **Kiro config**: `~/.kiro/settings/mcp.json`

### Important URLs

- **PyPI**: https://pypi.org/project/agentcore-mcp-proxy/
- **TestPyPI**: https://test.pypi.org/project/agentcore-mcp-proxy/
- **MCP Inspector**: http://localhost:6274 (when running)
- **Documentation**: README.md

---

## Version History

### v0.1.0 (Initial Release)
- Cognito OAuth authentication
- Hardware-bound token encryption
- 10 social media tracking tools
- AgentCore Gateway integration
- MCP protocol support
- Kiro IDE integration
