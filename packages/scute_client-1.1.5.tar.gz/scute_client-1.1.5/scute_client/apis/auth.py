from typing import Dict, Any
from .base import BaseClient

class AuthAPI:
    def __init__(self, client: BaseClient):
        self.client = client

    def get_current_user(self, access_token: str) -> Dict[str, Any]:
        headers = {"X-Authorization": access_token}
        path = f"/auth/{self.client.app_id}/current_user"
        data = self.client.request(method="GET", path=path, headers=headers)
        return data.get("user", {}) if data else {}

    def logout_current_user(self, access_token: str) -> bool:
        headers = {"X-Authorization": access_token}
        path = f"/auth/{self.client.app_id}/current_user/logout"
        self.client.request(method="POST", path=path, headers=headers)
        return True

    def create_app_session(self, access_token: str, app_id: str) -> Dict[str, Any]:
        headers = {
            "Authorization": self.client.workspace_secret,
            "X-Authorization": access_token,
        }
        files = {
            "app_id": (None, app_id),
        }  # multipart/form-data
        path = f"/workspaces/{self.client.workspace_id}/sessions"
        data = self.client.request(method="POST", path=path, headers=headers, files=files)
        return data.get("user", {}) if data else {}
