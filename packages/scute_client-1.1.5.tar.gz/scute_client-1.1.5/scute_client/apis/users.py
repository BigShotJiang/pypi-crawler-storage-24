from typing import Dict, Any, Optional, Iterator
from .base import BaseClient


class UsersAPI:
    def __init__(self, client: BaseClient):
        self.client = client

    def create_user(self, identifier: str, app_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Creates a user using the given identifier (email or phone).

        :param identifier: User's identifier (email or phone number)
        :param app_id: Optional app ID. If not provided, the client's default app_id will be used.
        :return: Created user data dictionary
        :raises ValueError: If identifier is not provided
        """
        if not identifier:
            raise ValueError("The 'identifier' (email or phone) is required.")

        headers = {
            "Authorization": self.client.workspace_secret if self.client._workspace_secret else self.client.app_secret
        }

        app_id = app_id or self.client.app_id
        path = f"/{app_id}/users"
        files = {"identifier": (None, identifier)}  # multipart/form-data

        data = self.client.request("POST", path, headers=headers, files=files)
        return data.get("user", {}) if data else {}

    def get_user_by_id(self, user_id: str, app_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Retrieves a user by their unique ID.

        :param user_id: User ID
        :param app_id: Optional app ID. If not provided, the client's default app_id will be used.
        :return: User data dictionary
        """
        headers = {
            "Authorization": self.client.workspace_secret if self.client._workspace_secret else self.client.app_secret
        }

        app_id = app_id or self.client.app_id
        path = f"/{app_id}/users/{user_id}"

        data = self.client.request("GET", path, headers=headers)
        return data.get("user", {}) if data else {}

    def list_users(
        self,
        id: Optional[str] = None,
        email: Optional[str] = None,
        phone: Optional[str] = None,
        created_before: Optional[str] = None,
        status: Optional[str] = None,  # "active" | "pending" | "inactive"
        page: Optional[int] = 1,
        limit: Optional[int] = 20,
        app_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Lists users with optional filtering and pagination.

        :param id: Filter by user ID
        :param email: Filter by email
        :param phone: Filter by phone
        :param created_before: Filter users created before given timestamp
        :param status: User status ("active", "pending", or "inactive")
        :param page: Page number
        :param limit: Number of users per page
        :param app_id: Optional app ID. If not provided, the client's default app_id will be used.
        :return: Dictionary with users list and pagination metadata
        :raises ValueError: If status is invalid
        """
        headers = {
            "Authorization": self.client.workspace_secret if self.client._workspace_secret else self.client.app_secret
        }
        params = {"page": page, "limit": limit}

        if id:
            params["id"] = id
        if email:
            params["email"] = email
        if phone:
            params["phone"] = phone
        if created_before:
            params["created_before"] = created_before
        if status:
            if status not in {"active", "pending", "inactive"}:
                raise ValueError("Invalid status. Must be 'active', 'pending', or 'inactive'.")
            params["status"] = status

        app_id = app_id or self.client.app_id
        path = f"/{app_id}/users"

        return self.client.request("GET", path, headers=headers, params=params) or {}

    def list_all_users(
        self,
        email: Optional[str] = None,
        phone: Optional[str] = None,
        created_before: Optional[str] = None,
        status: Optional[str] = None,
        limit: int = 50,
        app_id: Optional[str] = None
    ) -> Iterator[Dict[str, Any]]:
        """
        Generator that yields all users by automatically paginating.

        :param email: Filter by email
        :param phone: Filter by phone
        :param created_before: Filter users created before given timestamp
        :param status: User status
        :param limit: Number of users per page
        :param app_id: Optional app ID. If not provided, the client's default app_id will be used.
        :yield: Individual user dictionaries
        """
        page = 1
        while True:
            response = self.list_users(
                email=email,
                phone=phone,
                created_before=created_before,
                status=status,
                page=page,
                limit=limit,
                app_id=app_id
            )
            users = response.get("users", [])
            if not users:
                break

            for user in users:
                yield user

            page += 1

    def delete_user(self, user_id: str, app_id: Optional[str] = None) -> bool:
        """
        Deletes a user by ID.

        :param user_id: ID of the user to delete
        :param app_id: Optional app ID. If not provided, the client's default app_id will be used.
        :return: True if deletion was successful
        :raises ValueError: If user_id is missing
        """
        if not user_id:
            raise ValueError("The 'user_id' is required.")

        headers = {
            "Authorization": self.client.workspace_secret if self.client._workspace_secret else self.client.app_secret
        }

        app_id = app_id or self.client.app_id
        path = f"/{app_id}/users/{user_id}"

        response = self.client.request("DELETE", path, headers=headers)

        return response.get("message") == "ok" or response == {}
