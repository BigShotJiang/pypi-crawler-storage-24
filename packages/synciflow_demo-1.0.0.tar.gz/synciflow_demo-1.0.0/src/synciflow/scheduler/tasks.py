from __future__ import annotations

import logging
import shutil
from datetime import datetime, timezone, timedelta
from pathlib import Path

from sqlmodel import Session, delete, select, func

from synciflow.config import AppConfig, USER_EXPIRY_SECONDS, TRACK_EXPIRY_SECONDS
from synciflow.db.models import Job, Playlist, PlaylistTrack, Track, User
from synciflow.storage.path_manager import StoragePaths
from synciflow.storage.file_manager import FileManager

LOG = logging.getLogger("synciflow.scheduler")


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _user_files(cfg: AppConfig, user_id: int) -> FileManager:
    fm = FileManager(StoragePaths(root=cfg.user_storage_root(user_id)))
    return fm


# ---------------------------------------------------------------------------
# Task 1 — Delete expired users and all their data
# ---------------------------------------------------------------------------

def delete_expired_users(engine, cfg: AppConfig) -> int:
    """
    Delete every User whose created_at is older than USER_EXPIRY_SECONDS.

    For each expired user this also:
      - Deletes all their PlaylistTrack relations
      - Deletes all their Playlists
      - Deletes all their Tracks (DB rows)
      - Deletes all their Jobs
      - Removes the entire user storage directory from disk

    Returns the number of users deleted.
    """
    cutoff = _utcnow() - timedelta(seconds=USER_EXPIRY_SECONDS)
    deleted_count = 0

    with Session(engine) as session:
        expired_users = session.exec(
            select(User).where(User.created_at <= cutoff)
        ).all()

        for user in expired_users:
            LOG.info("Scheduler: deleting expired user id=%s username=%s", user.id, user.username)

            # 1. Delete PlaylistTrack relations for all user playlists
            user_playlists = session.exec(
                select(Playlist).where(Playlist.user_id == user.id)
            ).all()
            for playlist in user_playlists:
                session.exec(
                    delete(PlaylistTrack).where(PlaylistTrack.playlist_db_id == playlist.id)
                )

            # 2. Delete all Playlists
            session.exec(delete(Playlist).where(Playlist.user_id == user.id))

            # 3. Delete all Tracks
            session.exec(delete(Track).where(Track.user_id == user.id))

            # 4. Delete all Jobs
            session.exec(delete(Job).where(Job.user_id == user.id))

            # 5. Delete the user row
            session.delete(user)

            session.commit()

            # 6. Remove the entire user storage directory from disk
            user_root = cfg.user_storage_root(user.id)
            if user_root.exists():
                try:
                    shutil.rmtree(str(user_root))
                    LOG.info("Scheduler: removed storage dir %s", user_root)
                except OSError as exc:
                    LOG.warning("Scheduler: could not remove %s: %s", user_root, exc)

            deleted_count += 1

    LOG.info("Scheduler [delete_expired_users]: deleted %d user(s)", deleted_count)
    return deleted_count


# ---------------------------------------------------------------------------
# Task 2 — Delete expired tracks and playlist relations
# ---------------------------------------------------------------------------

def delete_expired_tracks(engine, cfg: AppConfig) -> int:
    """
    Delete every Track whose created_at is older than TRACK_EXPIRY_SECONDS,
    along with:
      - All PlaylistTrack relations that reference the track
      - The audio file on disk

    Playlists that become empty after this are left in the DB (they can be
    re-synced).  Only dangling relations and the audio files are removed.

    Returns the number of tracks deleted.
    """
    cutoff = _utcnow() - timedelta(seconds=TRACK_EXPIRY_SECONDS)
    deleted_count = 0

    with Session(engine) as session:
        expired_tracks = session.exec(
            select(Track).where(Track.created_at <= cutoff)
        ).all()

        for track in expired_tracks:
            LOG.info(
                "Scheduler: deleting expired track id=%s track_id=%s user_id=%s",
                track.id, track.track_id, track.user_id,
            )

            # 1. Remove PlaylistTrack relations via surrogate track.id
            session.exec(
                delete(PlaylistTrack).where(PlaylistTrack.track_db_id == track.id)
            )

            # 2. Remove the audio file from disk
            if track.audio_path:
                audio_file = Path(track.audio_path)
                if audio_file.exists():
                    try:
                        audio_file.unlink()
                        LOG.info("Scheduler: removed audio file %s", audio_file)
                    except OSError as exc:
                        LOG.warning("Scheduler: could not remove %s: %s", audio_file, exc)

            # 3. Delete the Track row
            session.delete(track)
            session.commit()

            deleted_count += 1

    LOG.info("Scheduler [delete_expired_tracks]: deleted %d track(s)", deleted_count)
    return deleted_count


# ---------------------------------------------------------------------------
# Task 3 — Delete expired playlists (optional cleanup of empty playlists)
# ---------------------------------------------------------------------------

def delete_expired_playlists(engine, cfg: AppConfig) -> int:
    """
    Delete every Playlist whose created_at is older than TRACK_EXPIRY_SECONDS
    AND has no remaining PlaylistTrack relations (i.e. all its tracks were
    already removed by delete_expired_tracks).

    Returns the number of playlists deleted.
    """
    cutoff = _utcnow() - timedelta(seconds=TRACK_EXPIRY_SECONDS)
    deleted_count = 0

    with Session(engine) as session:
        expired_playlists = session.exec(
            select(Playlist).where(Playlist.created_at <= cutoff)
        ).all()

        for playlist in expired_playlists:
            # Only delete if no tracks remain
            ref_count = session.exec(
                select(func.count())
                .select_from(PlaylistTrack)
                .where(PlaylistTrack.playlist_db_id == playlist.id)
            ).one()

            if int(ref_count) > 0:
                continue

            LOG.info(
                "Scheduler: deleting empty expired playlist id=%s playlist_id=%s user_id=%s",
                playlist.id, playlist.playlist_id, playlist.user_id,
            )

            # Remove playlist metadata JSON if it exists
            if playlist.user_id is not None:
                meta_dir = cfg.user_storage_root(playlist.user_id) / "playlists"
                meta_file = meta_dir / f"{playlist.playlist_id}.json"
                if meta_file.exists():
                    try:
                        meta_file.unlink()
                    except OSError:
                        pass

            session.delete(playlist)
            session.commit()
            deleted_count += 1

    LOG.info("Scheduler [delete_expired_playlists]: deleted %d playlist(s)", deleted_count)
    return deleted_count


# ---------------------------------------------------------------------------
# Run all tasks in order
# ---------------------------------------------------------------------------

def run_all_tasks(engine, cfg: AppConfig) -> None:
    """Run all cleanup tasks in the correct dependency order."""
    LOG.info("Scheduler: starting cleanup run at %s", _utcnow().isoformat())
    try:
        delete_expired_users(engine, cfg)
        delete_expired_tracks(engine, cfg)
        delete_expired_playlists(engine, cfg)
    except Exception as exc:
        LOG.error("Scheduler: cleanup run failed: %s", exc, exc_info=True)
    LOG.info("Scheduler: cleanup run complete")
