from __future__ import annotations

import logging
import threading
import time

from synciflow.config import (
    ENABLE_SCHEDULER,
    SCHEDULER_INTERVAL_SECONDS,
    AppConfig,
)
from synciflow.scheduler.tasks import run_all_tasks

LOG = logging.getLogger("synciflow.scheduler")


class SchedulerRunner:
    """
    Background daemon thread that wakes up every SCHEDULER_INTERVAL_SECONDS
    and runs all cleanup tasks.

    Controlled by the ENABLE_SCHEDULER constant in config.py.
    When ENABLE_SCHEDULER is False, start() is a no-op.

    Usage (called automatically from library_manager / server lifespan):
        runner = SchedulerRunner(engine, cfg)
        runner.start()   # on startup
        runner.stop()    # on shutdown
    """

    def __init__(self, engine, cfg: AppConfig) -> None:
        self._engine = engine
        self._cfg = cfg
        self._stop_event = threading.Event()
        self._thread: threading.Thread | None = None

    def start(self) -> None:
        if not ENABLE_SCHEDULER:
            LOG.info("Scheduler: disabled (ENABLE_SCHEDULER=False)")
            return

        if self._thread is not None and self._thread.is_alive():
            LOG.warning("Scheduler: already running")
            return

        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._run_loop,
            name="synciflow-scheduler",
            daemon=True,   # dies automatically when the main process exits
        )
        self._thread.start()
        LOG.info(
            "Scheduler: started (interval=%ds, user_expiry controlled by config)",
            SCHEDULER_INTERVAL_SECONDS,
        )

    def stop(self) -> None:
        self._stop_event.set()
        if self._thread is not None:
            self._thread.join(timeout=10)
            self._thread = None
        LOG.info("Scheduler: stopped")

    def _run_loop(self) -> None:
        """
        Run tasks once immediately on startup, then sleep for
        SCHEDULER_INTERVAL_SECONDS before each subsequent run.
        """
        LOG.info("Scheduler: first run on startup")
        run_all_tasks(self._engine, self._cfg)

        while not self._stop_event.wait(timeout=SCHEDULER_INTERVAL_SECONDS):
            LOG.info("Scheduler: waking up for scheduled run")
            run_all_tasks(self._engine, self._cfg)

        LOG.info("Scheduler: loop exiting")
