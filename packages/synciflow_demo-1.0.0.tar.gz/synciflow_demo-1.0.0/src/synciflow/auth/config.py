"""
auth/config.py
JWT + password hashing configuration for synciflow.

Uses `bcrypt` directly instead of passlib to avoid the passlib/bcrypt
version-conflict bug on Windows (ValueError: password cannot be longer
than 72 bytes).
"""

import os
from datetime import datetime, timedelta
from typing import Optional

import bcrypt
from jose import JWTError, jwt

from synciflow.config import ACCESS_TOKEN_EXPIRE_MINUTES_CONFIG, REFRESH_TOKEN_EXPIRE_DAYS_CONFIG  # noqa: F401  (JWTError re-exported for callers)

# ---------------------------------------------------------------------------
# Secrets & algorithm – override via environment variables in production
# ---------------------------------------------------------------------------
SECRET_KEY: str = os.getenv(
    "f1a4d7e0b3c6f9a2d5e8b1c4f7a0d3e6b9c2f5a8d1e4b7c0f3a6d9e2b5c8f1a4d7",
    "2c5f8a1d4e7b0c3f6a9d2e5b8c1f4a7d0e3b6c9f2a5d8e1b4c7f0a3d6e9b2c5f8",
)
ALGORITHM: str = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES: int = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", ACCESS_TOKEN_EXPIRE_MINUTES_CONFIG))
REFRESH_TOKEN_EXPIRE_DAYS: int = int(os.getenv("REFRESH_TOKEN_EXPIRE_DAYS", REFRESH_TOKEN_EXPIRE_DAYS_CONFIG))


# ---------------------------------------------------------------------------
# Password hashing  (bcrypt directly – no passlib)
# ---------------------------------------------------------------------------

def hash_password(plain: str) -> str:
    """Return the bcrypt hash of *plain* as a UTF-8 string."""
    # bcrypt.hashpw requires bytes; encode first
    hashed = bcrypt.hashpw(plain.encode("utf-8"), bcrypt.gensalt())
    return hashed.decode("utf-8")


def verify_password(plain: str, hashed: str) -> bool:
    """Return True if *plain* matches the stored *hashed* value."""
    return bcrypt.checkpw(plain.encode("utf-8"), hashed.encode("utf-8"))


# ---------------------------------------------------------------------------
# JWT helpers
# ---------------------------------------------------------------------------

def create_access_token(
    subject: str,
    expires_delta: Optional[timedelta] = None,
) -> str:
    """Create a signed JWT access token for *subject*."""
    expire = datetime.utcnow() + (
        expires_delta or timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    )
    payload = {"sub": subject, "exp": expire, "type": "access"}
    return jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)


def create_refresh_token(subject: str) -> str:
    """Create a signed JWT refresh token for *subject*."""
    expire = datetime.utcnow() + timedelta(days=REFRESH_TOKEN_EXPIRE_DAYS)
    payload = {"sub": subject, "exp": expire, "type": "refresh"}
    return jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)


def decode_token(token: str) -> dict:
    """
    Decode and validate *token*.
    Raises jose.JWTError on any validation failure.
    """
    return jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])