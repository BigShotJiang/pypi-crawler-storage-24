from __future__ import annotations

import os
import shutil
from dataclasses import dataclass
from pathlib import Path

from .path_manager import StoragePaths, ensure_parent_dir, ensure_storage_dirs, track_audio_path
from synciflow.config import ENFORCE_USER_STORAGE_LIMIT, USER_STORAGE_LIMIT_BYTES


class StorageQuotaExceeded(Exception):
    """
    Raised when a user's tracks directory is at or over the configured limit.

    Attributes
    ----------
    used_bytes  : current size of the tracks directory
    limit_bytes : the configured maximum
    """

    def __init__(self, used_bytes: int, limit_bytes: int) -> None:
        self.used_bytes = used_bytes
        self.limit_bytes = limit_bytes
        used_mb = used_bytes / (1024 * 1024)
        limit_mb = limit_bytes / (1024 * 1024)
        super().__init__(
            f"Storage quota exceeded: {used_mb:.2f} MB used of {limit_mb:.2f} MB allowed. "
            f"Remove some tracks to free up space."
        )


@dataclass(frozen=True)
class FileManager:
    storage: StoragePaths

    def init_storage(self) -> None:
        ensure_storage_dirs(self.storage)

    def audio_path(self, track_id: str) -> Path:
        return track_audio_path(self.storage, track_id)

    def exists(self, track_id: str) -> bool:
        return self.audio_path(track_id).exists()

    # ------------------------------------------------------------------
    # Storage quota
    # ------------------------------------------------------------------

    def tracks_dir_size(self) -> int:
        """
        Return total bytes of all files inside the tracks directory.
        Returns 0 if the directory does not exist yet.
        """
        tracks_dir = self.storage.tracks_dir
        if not tracks_dir.exists():
            return 0
        total = 0
        for entry in tracks_dir.rglob("*"):
            if entry.is_file():
                try:
                    total += entry.stat().st_size
                except OSError:
                    pass
        return total

    def check_storage_quota(self) -> None:
        """
        Raise ``StorageQuotaExceeded`` if quota enforcement is enabled and
        the tracks directory is already at or over USER_STORAGE_LIMIT_BYTES.

        Uses the module-level constants from config directly:
            ENFORCE_USER_STORAGE_LIMIT  — toggle on/off
            USER_STORAGE_LIMIT_BYTES    — the byte ceiling

        Call this BEFORE downloading a new track.  Re-loading an existing
        track skips this check entirely since nothing new is written.
        """
        if not ENFORCE_USER_STORAGE_LIMIT:
            return
        used = self.tracks_dir_size()
        if used >= USER_STORAGE_LIMIT_BYTES:
            raise StorageQuotaExceeded(
                used_bytes=used,
                limit_bytes=USER_STORAGE_LIMIT_BYTES,
            )

    # ------------------------------------------------------------------
    # File operations  (unchanged from original)
    # ------------------------------------------------------------------

    def atomic_move_to_library(self, track_id: str, tmp_mp3_path: str | Path) -> Path:
        """
        Atomically move a downloaded temp file into the library path.
        Uses os.replace (atomic on same filesystem).
        """
        self.init_storage()
        src = Path(tmp_mp3_path)
        if not src.exists():
            raise FileNotFoundError(str(src))

        dst = self.audio_path(track_id)
        ensure_parent_dir(dst)
        os.replace(str(src), str(dst))
        return dst

    def delete(self, track_id: str) -> None:
        path = self.audio_path(track_id)
        try:
            path.unlink()
        except FileNotFoundError:
            return

    def open_for_stream(self, track_id: str, mode: str = "rb"):
        path = self.audio_path(track_id)
        return path.open(mode)

    def copy_into_tmp(self, src_path: str | Path) -> Path:
        """Helper for tests/fakes: copy a file into tmp/ and return the new path."""
        self.init_storage()
        src = Path(src_path)
        if not src.exists():
            raise FileNotFoundError(str(src))
        dst = self.storage.tmp_dir / src.name
        ensure_parent_dir(dst)
        shutil.copyfile(str(src), str(dst))
        return dst