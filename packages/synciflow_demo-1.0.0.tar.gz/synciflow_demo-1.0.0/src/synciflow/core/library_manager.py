from __future__ import annotations

from dataclasses import dataclass

from sqlmodel import Session

from synciflow.config import AppConfig
from synciflow.db.database import DatabaseConfig, create_sqlite_engine, init_db
from synciflow.storage.file_manager import FileManager
from synciflow.storage.path_manager import StoragePaths
from synciflow.scheduler.runner import SchedulerRunner
from .playlist_manager import PlaylistManager
from .sync_manager import SyncManager
from .track_manager import TrackManager


@dataclass(frozen=True)
class Library:
    cfg: AppConfig
    engine: object
    files: FileManager          # global FileManager rooted at storage_root (admin/shared use)
    scheduler: SchedulerRunner  # global scheduler runner
    # ------------------------------------------------------------------
    # Construction
    # ------------------------------------------------------------------

    @classmethod
    def create(cls, cfg: AppConfig | None = None) -> "Library":
        cfg = cfg or AppConfig()
        engine = create_sqlite_engine(DatabaseConfig(db_path=cfg.db_path))
        init_db(engine)
        # Top-level FileManager for shared/global paths (tmp, zip staging, etc.)
        files = FileManager(StoragePaths(root=cfg.storage_root))
        files.init_storage()
        scheduler = SchedulerRunner(engine=engine, cfg=cfg)
        return cls(cfg=cfg, engine=engine, files=files, scheduler=scheduler)

    # ------------------------------------------------------------------
    # Per-user FileManager
    # ------------------------------------------------------------------

    def user_files(self, user_id: int) -> FileManager:
        """
        Return a FileManager rooted at the user-specific storage directory.

        Layout:
            storage_data/users/<user_id>/tracks/
            storage_data/users/<user_id>/playlists/
            storage_data/users/<user_id>/tmp/
        """
        user_root = self.cfg.user_storage_root(user_id)
        fm = FileManager(StoragePaths(root=user_root))
        fm.init_storage()
        return fm

    # ------------------------------------------------------------------
    # Session helper
    # ------------------------------------------------------------------

    def session(self) -> Session:
        return Session(self.engine)

    # ------------------------------------------------------------------
    # Manager factories — all require user_id
    # ------------------------------------------------------------------

    def track_manager(self, session: Session, user_id: int) -> TrackManager:
        """Return a TrackManager scoped to *user_id*."""
        return TrackManager(
            session=session,
            files=self.user_files(user_id),
            user_id=user_id,
        )

    def playlist_manager(self, session: Session, user_id: int) -> PlaylistManager:
        """Return a PlaylistManager scoped to *user_id*."""
        tm = self.track_manager(session, user_id)
        return PlaylistManager(
            session=session,
            tracks=tm,
            files=self.user_files(user_id),
            user_id=user_id,
        )

    def sync_manager(self, session: Session, user_id: int) -> SyncManager:
        """Return a SyncManager scoped to *user_id*."""
        tm = self.track_manager(session, user_id)
        return SyncManager(
            session=session,
            tracks=tm,
            user_id=user_id,
        )