from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import logging
from typing import Callable

from sqlmodel import Session, delete, func, select

from synciflow.core.utils import LIKES_PLAYLIST_ID, extract_spotify_id
from synciflow.db.models import Playlist, PlaylistTrack, Track
from synciflow.schemas.playlist import PlaylistDetails
from synciflow.services import spotify_client
from synciflow.services.downloader import DownloadError

from .track_manager import TrackManager


LOG = logging.getLogger("synciflow.sync")


@dataclass(frozen=True)
class SyncResult:
    added: int
    removed: int
    kept: int


@dataclass(frozen=True)
class SyncManager:
    session: Session
    tracks: TrackManager
    user_id: int

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _user_playlist_id(self, playlist_id: str) -> str:
        if playlist_id == LIKES_PLAYLIST_ID:
            return f"{LIKES_PLAYLIST_ID}_{self.user_id}"
        return playlist_id

    def _get_playlist(self, scoped_id: str) -> Playlist | None:
        return self.session.exec(
            select(Playlist)
            .where(Playlist.playlist_id == scoped_id)
            .where(Playlist.user_id == self.user_id)
        ).first()

    def _delete_playlist_tracks(self, playlist_db_id: int) -> None:
        self.session.exec(
            delete(PlaylistTrack).where(PlaylistTrack.playlist_db_id == playlist_db_id)
        )
        self.session.commit()

    # ------------------------------------------------------------------
    # Core sync implementation
    # ------------------------------------------------------------------

    def _sync_from_details(
        self,
        details: PlaylistDetails,
        playlist_id: str,
        progress_callback: Callable[[int, int, str], None] | None = None,
        fallback_url: str = "",
    ) -> SyncResult:
        scoped_id = self._user_playlist_id(playlist_id)

        playlist = self._get_playlist(scoped_id)
        if playlist is None:
            playlist = Playlist(
                playlist_id=scoped_id,
                playlist_url=details.playlist_url or fallback_url,
                title=details.title,
                playlist_image_url=details.playlist_image_url,
                user_id=self.user_id,
            )
            self.session.add(playlist)
            self.session.commit()
            self.session.refresh(playlist)
        else:
            playlist.playlist_url = details.playlist_url or playlist.playlist_url or fallback_url
            playlist.title = details.title or playlist.title
            playlist.playlist_image_url = details.playlist_image_url or playlist.playlist_image_url
            self.session.add(playlist)
            self.session.commit()
            self.session.refresh(playlist)

        desired_track_urls = list(details.track_urls or [])
        desired_spotify_ids = [extract_spotify_id(u, "track") for u in desired_track_urls]

        # Current relations — keyed by track_db_id, value = track.track_id (Spotify string)
        current_rows = list(
            self.session.exec(
                select(PlaylistTrack, Track)
                .where(PlaylistTrack.playlist_db_id == playlist.id)
                .where(PlaylistTrack.track_db_id == Track.id)
            ).all()
        )
        # map spotify track_id → Track.id (surrogate)
        current_spotify_to_db: dict[str, int] = {
            track.track_id: track.id for _, track in current_rows
        }

        desired_set = {sid for sid in desired_spotify_ids if sid}
        current_set = set(current_spotify_to_db.keys())

        to_add = desired_set - current_set
        to_remove = current_set - desired_set
        kept = len(desired_set & current_set)

        # Rebuild all relations from scratch (keeps positions correct)
        self._delete_playlist_tracks(playlist.id)

        total = len(desired_track_urls)
        for pos, track_url in enumerate(desired_track_urls):
            try:
                track = self.tracks.load_track(track_url)
            except DownloadError as exc:
                LOG.warning(
                    "Skipping track during sync (user=%s); could not download: %s (%s)",
                    self.user_id, track_url, exc,
                )
                if progress_callback is not None:
                    progress_callback(pos + 1, total, "Skipping track (unresolved on YouTube)")
                continue

            self.session.add(PlaylistTrack(
                playlist_db_id=playlist.id,
                track_db_id=track.id,
                position=pos,
            ))
            if progress_callback is not None:
                progress_callback(pos + 1, total, "Syncing tracks")

        self.session.commit()

        # Remove tracks that are no longer in ANY of this user's playlists
        removed_count = 0
        for spotify_track_id in to_remove:
            # Find the Track row owned by this user
            track = self.session.exec(
                select(Track)
                .where(Track.track_id == spotify_track_id)
                .where(Track.user_id == self.user_id)
            ).first()
            if track is None:
                continue

            # Count remaining PlaylistTrack references using the surrogate Track.id,
            # restricted to playlists owned by this user
            ref_count = self.session.exec(
                select(func.count())
                .select_from(PlaylistTrack)
                .join(Playlist, Playlist.id == PlaylistTrack.playlist_db_id)
                .where(PlaylistTrack.track_db_id == track.id)
                .where(Playlist.user_id == self.user_id)
            ).one()

            if int(ref_count) == 0:
                self.tracks.files.delete(spotify_track_id)
                self.session.delete(track)
                self.session.commit()
                removed_count += 1

        playlist.last_synced_at = datetime.now(timezone.utc)
        self.session.add(playlist)
        self.session.commit()

        if progress_callback is not None:
            progress_callback(
                total, total,
                f"Done: added={len(to_add)}, removed={removed_count}, kept={kept}",
            )

        return SyncResult(added=len(to_add), removed=removed_count, kept=kept)

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def sync_playlist(
        self,
        spotify_playlist_url: str,
        progress_callback: Callable[[int, int, str], None] | None = None,
    ) -> SyncResult:
        details = spotify_client.get_playlist_details(spotify_playlist_url)
        playlist_id = details.playlist_id or extract_spotify_id(spotify_playlist_url, "playlist")
        if not playlist_id:
            raise ValueError("Could not determine playlist_id from Spotify URL/details.")
        return self._sync_from_details(
            details=details,
            playlist_id=playlist_id,
            progress_callback=progress_callback,
            fallback_url=spotify_playlist_url,
        )

    def sync_likes(
        self,
        progress_callback: Callable[[int, int, str], None] | None = None,
        login_timeout: int = 120,
        page_load_timeout: int = 30,
        scroll_pause: float = 2.0,
    ) -> SyncResult:
        details = spotify_client.get_likes_details(
            login_timeout=login_timeout,
            page_load_timeout=page_load_timeout,
            scroll_pause=scroll_pause,
        )
        return self._sync_from_details(
            details=details,
            playlist_id=LIKES_PLAYLIST_ID,
            progress_callback=progress_callback,
            fallback_url=details.playlist_url,
        )