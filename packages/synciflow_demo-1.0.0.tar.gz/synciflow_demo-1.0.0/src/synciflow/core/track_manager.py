from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Callable

from sqlmodel import Session, select

from synciflow.db.models import Track
from synciflow.schemas.track import TrackDetails
from synciflow.services import downloader as downloader_service
from synciflow.services import spotify_client
from synciflow.services.tagging import ensure_cover_art
from synciflow.storage.file_manager import FileManager, StorageQuotaExceeded  # noqa: F401 re-export

from .utils import extract_spotify_id


@dataclass(frozen=True)
class TrackManager:
    session: Session
    files: FileManager
    user_id: int

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _get_track(self, track_id: str) -> Track | None:
        return self.session.exec(
            select(Track)
            .where(Track.track_id == track_id)
            .where(Track.user_id == self.user_id)
        ).first()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def load_track(
        self,
        spotify_url: str,
        progress_callback: Callable[[str], None] | None = None,
    ) -> Track:
        """
        Load (and download if needed) a track from a Spotify URL.

        Quota logic
        -----------
        - If the audio file already exists on disk → return it immediately,
          no quota check (nothing new is written).
        - If the file needs to be downloaded → call
          ``self.files.check_storage_quota()`` first.  This reads the
          module-level constants ENFORCE_USER_STORAGE_LIMIT and
          USER_STORAGE_LIMIT_BYTES from config and raises
          ``StorageQuotaExceeded`` when the tracks dir is full.
        """
        track_id_from_url = extract_spotify_id(spotify_url, "track")

        existing: Track | None = None
        if track_id_from_url:
            existing = self._get_track(track_id_from_url)

        details: TrackDetails | None = None

        if existing is None:
            details = spotify_client.get_track_details(spotify_url)
            track_id = details.track_id or track_id_from_url
            if not track_id:
                raise ValueError("Could not determine track_id from Spotify URL/details.")
            existing = Track(
                track_id=track_id,
                spotify_url=details.spotify_url or spotify_url,
                track_title=details.track_title,
                artist_title=details.artist_title,
                track_image_url=details.track_image_url,
                duration_ms=details.duration_ms,
                duration_str=details.duration_str,
                user_id=self.user_id,
            )
            self.session.add(existing)
            self.session.commit()
            self.session.refresh(existing)
        else:
            track_id = existing.track_id

        # Audio already on disk — sync the DB path and return.
        # No quota check: we are not downloading anything new.
        if self.files.exists(track_id):
            audio_path_path = self.files.audio_path(track_id)
            audio_path_str = str(audio_path_path)
            if existing.audio_path != audio_path_str:
                existing.audio_path = audio_path_str
                if existing.downloaded_at is None:
                    existing.downloaded_at = datetime.now(timezone.utc)

            if not existing.track_image_url or not existing.track_title or not existing.artist_title:
                details = spotify_client.get_track_details(existing.spotify_url)
                if not existing.track_title and details.track_title:
                    existing.track_title = details.track_title
                if not existing.artist_title and details.artist_title:
                    existing.artist_title = details.artist_title
                if not existing.track_image_url and details.track_image_url:
                    existing.track_image_url = details.track_image_url

            self.session.add(existing)
            self.session.commit()
            self.session.refresh(existing)
            ensure_cover_art(audio_path_path, existing.track_image_url)
            return existing

        # ── Quota check — before any download ────────────────────────────
        # Raises StorageQuotaExceeded if the user's tracks dir is full.
        # No-op when ENFORCE_USER_STORAGE_LIMIT = False in config.
        self.files.check_storage_quota()

        if details is None:
            details = spotify_client.get_track_details(spotify_url)

        if not existing.track_title and details.track_title:
            existing.track_title = details.track_title
        if not existing.artist_title and details.artist_title:
            existing.artist_title = details.artist_title
        if not existing.track_image_url and details.track_image_url:
            existing.track_image_url = details.track_image_url

        if progress_callback is not None:
            progress_callback("started")

        result = downloader_service.download_track_to_tmp(details, self.files)
        final_path = self.files.atomic_move_to_library(track_id, result.tmp_mp3_path)

        existing.audio_path = str(final_path)
        existing.downloaded_at = datetime.now(timezone.utc)
        self.session.add(existing)
        self.session.commit()
        self.session.refresh(existing)

        ensure_cover_art(final_path, existing.track_image_url)
        if progress_callback is not None:
            progress_callback("completed")
        return existing

    def load_local(self, track_id: str) -> Track:
        """Local-first load — no download, no quota check."""
        audio_path = self.files.audio_path(track_id)
        if not audio_path.exists():
            raise ValueError(
                f"Local audio file not found for track_id={track_id} (user={self.user_id})"
            )

        track = self._get_track(track_id)
        if track is None:
            track = Track(
                track_id=track_id,
                spotify_url="",
                track_title="",
                artist_title="",
                track_image_url="",
                duration_ms=0,
                duration_str="",
                audio_path=str(audio_path),
                downloaded_at=datetime.now(timezone.utc),
                user_id=self.user_id,
            )
            self.session.add(track)
        else:
            updated = False
            if track.audio_path != str(audio_path):
                track.audio_path = str(audio_path)
                updated = True
            if track.downloaded_at is None:
                track.downloaded_at = datetime.now(timezone.utc)
                updated = True
            if updated:
                self.session.add(track)

        self.session.commit()
        self.session.refresh(track)
        ensure_cover_art(audio_path, track.track_image_url)
        return track

    def list_tracks(self) -> list[Track]:
        return list(
            self.session.exec(
                select(Track).where(Track.user_id == self.user_id)
            ).all()
        )