from __future__ import annotations

import asyncio
import queue
from dataclasses import dataclass, field
from typing import Any

# ---------------------------------------------------------------------------
# Event type constants
# ---------------------------------------------------------------------------
TRACK_DOWNLOAD_STARTED = "TRACK_DOWNLOAD_STARTED"
TRACK_DOWNLOAD_COMPLETED = "TRACK_DOWNLOAD_COMPLETED"
PLAYLIST_PROGRESS = "PLAYLIST_PROGRESS"
PLAYLIST_COMPLETED = "PLAYLIST_COMPLETED"
SYNC_PROGRESS = "SYNC_PROGRESS"
SYNC_COMPLETED = "SYNC_COMPLETED"
ERROR = "ERROR"


@dataclass
class NotificationEvent:
    """Payload for a notification event."""
    event_type: str
    job_id: str | None = None
    progress: float | None = None
    message: str | None = None
    payload: dict[str, Any] = field(default_factory=dict)
    # user_id is set by the bus so subscribers can filter their own events
    user_id: int | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "event_type": self.event_type,
            "job_id":     self.job_id,
            "progress":   self.progress,
            "message":    self.message,
            "user_id":    self.user_id,
            **self.payload,
        }


class NotificationBus:
    """
    Notification bus with sync publishing (for threads/CLI) and async consumption (WebSocket).

    Per-user isolation
    ------------------
    Every subscriber is registered with a *user_id*.  The bridge only delivers
    events to subscribers whose user_id matches the event's user_id — so each
    connected WebSocket client only sees its own jobs' events.

    Global subscribers (user_id=None) still receive ALL events (useful for
    admin dashboards or server-side monitoring).
    """

    def __init__(self) -> None:
        self._sync_queue: queue.Queue[NotificationEvent] = queue.Queue()
        # mapping: user_id (or None for global) → set of subscriber queues
        self._subscribers: dict[int | None, set[asyncio.Queue[NotificationEvent]]] = {}
        self._bridge_task: asyncio.Task[None] | None = None
        self._stop = False

    # ------------------------------------------------------------------
    # Publishing
    # ------------------------------------------------------------------

    def publish_sync(self, event: NotificationEvent) -> None:
        """Thread-safe: publish from sync code (e.g. background worker thread)."""
        self._sync_queue.put_nowait(event)

    async def publish(self, event: NotificationEvent) -> None:
        """Async: publish from async code."""
        await self._dispatch(event)

    # ------------------------------------------------------------------
    # Subscribing
    # ------------------------------------------------------------------

    def subscribe(self, user_id: int | None = None) -> asyncio.Queue[NotificationEvent]:
        """
        Create a new subscriber queue scoped to *user_id*.

        - Pass a real user_id to receive only that user's events.
        - Pass None to receive every event (global / admin subscriber).

        Caller should await queue.get() in a loop and call unsubscribe() on disconnect.
        """
        q: asyncio.Queue[NotificationEvent] = asyncio.Queue(maxsize=256)
        self._subscribers.setdefault(user_id, set()).add(q)
        return q

    def unsubscribe(self, q: asyncio.Queue[NotificationEvent], user_id: int | None = None) -> None:
        """Remove *q* from the subscriber set for *user_id*."""
        bucket = self._subscribers.get(user_id)
        if bucket:
            bucket.discard(q)
            if not bucket:
                del self._subscribers[user_id]

    # ------------------------------------------------------------------
    # Internal dispatch
    # ------------------------------------------------------------------

    async def _dispatch(self, event: NotificationEvent) -> None:
        """
        Route the event to:
          1. All subscribers registered for event.user_id  (the owner)
          2. All global subscribers (user_id=None)
        """
        targets: set[asyncio.Queue[NotificationEvent]] = set()

        # User-scoped subscribers
        if event.user_id is not None:
            targets |= self._subscribers.get(event.user_id, set())

        # Global (admin / monitoring) subscribers
        targets |= self._subscribers.get(None, set())

        for sub in targets:
            try:
                sub.put_nowait(event)
            except asyncio.QueueFull:
                # Slow consumer — drop event rather than block the bus
                pass

    # ------------------------------------------------------------------
    # Bridge: sync thread → async event loop
    # ------------------------------------------------------------------

    def _get_event(self) -> NotificationEvent:
        """Block until an event is available (used by bridge in thread)."""
        return self._sync_queue.get(timeout=0.5)

    async def _bridge(self) -> None:
        """Drain sync_queue and broadcast to matching subscribers."""
        while not self._stop:
            try:
                event = await asyncio.to_thread(self._get_event)
            except queue.Empty:
                continue
            except asyncio.CancelledError:
                break
            except Exception:
                continue
            await self._dispatch(event)

    def start_bridge(self, loop: asyncio.AbstractEventLoop) -> None:
        """Start the bridge task that forwards sync_queue to subscribers."""
        if self._bridge_task is not None:
            return
        self._stop = False
        self._bridge_task = loop.create_task(self._bridge())

    def stop_bridge(self) -> None:
        """Signal the bridge to stop. Call from shutdown."""
        self._stop = True
        if self._bridge_task is not None:
            self._bridge_task.cancel()
            self._bridge_task = None