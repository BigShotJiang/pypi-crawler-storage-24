from __future__ import annotations

from dataclasses import dataclass
import logging
from typing import Callable, List

from sqlmodel import Session, delete, select

from synciflow.core.track_manager import TrackManager
from synciflow.core.utils import LIKES_PLAYLIST_ID, extract_spotify_id
from synciflow.db.models import Playlist, PlaylistTrack
from synciflow.schemas.playlist import PlaylistDetails
from synciflow.services import spotify_client
from synciflow.services.downloader import DownloadError
from synciflow.storage.file_manager import FileManager
from synciflow.storage.playlist_metadata import (
    PlaylistMetadata,
    read_playlist_metadata,
    write_playlist_metadata,
)


LOG = logging.getLogger("synciflow.playlist")


@dataclass(frozen=True)
class PlaylistManager:
    session: Session
    tracks: TrackManager
    files: FileManager
    user_id: int

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _get_playlist(self, playlist_id: str) -> Playlist | None:
        return self.session.exec(
            select(Playlist)
            .where(Playlist.playlist_id == playlist_id)
            .where(Playlist.user_id == self.user_id)
        ).first()

    def _user_playlist_id(self, playlist_id: str) -> str:
        """Scope the likes pseudo-playlist per user so two users never collide."""
        if playlist_id == LIKES_PLAYLIST_ID:
            return f"{LIKES_PLAYLIST_ID}_{self.user_id}"
        return playlist_id

    def _delete_playlist_tracks(self, playlist_db_id: int) -> None:
        """Delete all PlaylistTrack rows for the given playlist surrogate id."""
        self.session.exec(
            delete(PlaylistTrack).where(PlaylistTrack.playlist_db_id == playlist_db_id)
        )
        self.session.commit()

    # ------------------------------------------------------------------
    # Core implementation
    # ------------------------------------------------------------------

    def _load_from_details(
        self,
        details: PlaylistDetails,
        playlist_id: str,
        progress_callback: Callable[[int, int, str], None] | None = None,
        fallback_url: str = "",
    ) -> Playlist:
        scoped_id = self._user_playlist_id(playlist_id)

        playlist = self._get_playlist(scoped_id)
        if playlist is None:
            playlist = Playlist(
                playlist_id=scoped_id,
                playlist_url=details.playlist_url or fallback_url,
                title=details.title,
                playlist_image_url=details.playlist_image_url,
                user_id=self.user_id,
            )
            self.session.add(playlist)
            self.session.commit()
            self.session.refresh(playlist)
        else:
            playlist.playlist_url = details.playlist_url or playlist.playlist_url or fallback_url
            playlist.title = details.title or playlist.title
            playlist.playlist_image_url = details.playlist_image_url or playlist.playlist_image_url
            self.session.add(playlist)
            self.session.commit()
            self.session.refresh(playlist)

        # Rebuild relations using the surrogate playlist.id
        self._delete_playlist_tracks(playlist.id)

        track_ids: List[str] = []
        track_urls = details.track_urls or []
        total = len(track_urls)

        for pos, track_url in enumerate(track_urls):
            try:
                track = self.tracks.load_track(track_url)
            except DownloadError as exc:
                LOG.warning(
                    "Skipping track while loading playlist (user=%s); could not download: %s (%s)",
                    self.user_id, track_url, exc,
                )
                if progress_callback is not None:
                    progress_callback(pos + 1, total, "Skipping track (unresolved on YouTube)")
                continue

            # Use surrogate integer IDs for the relation
            rel = PlaylistTrack(
                playlist_db_id=playlist.id,
                track_db_id=track.id,
                position=pos,
            )
            self.session.add(rel)
            track_ids.append(track.track_id)
            if progress_callback is not None:
                progress_callback(pos + 1, total, track.track_title or track.track_id)

        self.session.commit()

        metadata = PlaylistMetadata(
            playlist_id=scoped_id,
            title=playlist.title,
            track_ids=track_ids,
        )
        write_playlist_metadata(self.files.storage, metadata)

        return playlist

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def load_playlist(
        self,
        spotify_playlist_url: str,
        progress_callback: Callable[[int, int, str], None] | None = None,
    ) -> Playlist:
        details: PlaylistDetails = spotify_client.get_playlist_details(spotify_playlist_url)
        playlist_id = details.playlist_id or extract_spotify_id(spotify_playlist_url, "playlist")
        if not playlist_id:
            raise ValueError("Could not determine playlist_id from Spotify URL/details.")
        return self._load_from_details(
            details=details,
            playlist_id=playlist_id,
            progress_callback=progress_callback,
            fallback_url=spotify_playlist_url,
        )

    def load_likes(
        self,
        progress_callback: Callable[[int, int, str], None] | None = None,
        login_timeout: int = 120,
        page_load_timeout: int = 30,
        scroll_pause: float = 2.0,
    ) -> Playlist:
        details = spotify_client.get_likes_details(
            login_timeout=login_timeout,
            page_load_timeout=page_load_timeout,
            scroll_pause=scroll_pause,
        )
        return self._load_from_details(
            details=details,
            playlist_id=LIKES_PLAYLIST_ID,
            progress_callback=progress_callback,
            fallback_url=details.playlist_url,
        )

    def load_local(self, playlist_id: str) -> Playlist:
        scoped_id = self._user_playlist_id(playlist_id)

        playlist = self._get_playlist(scoped_id)
        if playlist is None:
            playlist = Playlist(
                playlist_id=scoped_id,
                playlist_url="",
                title="",
                playlist_image_url="",
                user_id=self.user_id,
            )
            self.session.add(playlist)
            self.session.commit()
            self.session.refresh(playlist)

        metadata = read_playlist_metadata(self.files.storage, scoped_id)
        if metadata is None:
            return playlist

        self._delete_playlist_tracks(playlist.id)

        for pos, track_id in enumerate(metadata.track_ids):
            track = self.tracks.load_local(track_id)
            rel = PlaylistTrack(
                playlist_db_id=playlist.id,
                track_db_id=track.id,
                position=pos,
            )
            self.session.add(rel)

        self.session.commit()
        return playlist

    def list_playlists(self) -> list[Playlist]:
        return list(
            self.session.exec(
                select(Playlist).where(Playlist.user_id == self.user_id)
            ).all()
        )