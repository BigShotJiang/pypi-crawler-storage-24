from __future__ import annotations

import asyncio
from contextlib import asynccontextmanager
from dataclasses import dataclass
from pathlib import Path
import importlib.resources as resources
import re
import shutil
from typing import Optional

from fastapi import Depends, FastAPI, HTTPException, Query, WebSocket, WebSocketDisconnect, status
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from jose import JWTError
from pydantic import BaseModel, EmailStr, Field
from sqlmodel import Session, select

from synciflow.core.job_manager import (
    complete_job,
    create_job,
    fail_job,
    get_job,
    list_jobs,
    update_job_progress,
)
from synciflow.core.library_manager import Library
from synciflow.core.notification_bus import (
    ERROR,
    NotificationBus,
    NotificationEvent,
    PLAYLIST_COMPLETED,
    PLAYLIST_PROGRESS,
    SYNC_COMPLETED,
    SYNC_PROGRESS,
    TRACK_DOWNLOAD_COMPLETED,
    TRACK_DOWNLOAD_STARTED,
)
from synciflow.core.utils import LIKES_PLAYLIST_ID
from synciflow.db.database import get_session
from synciflow.db.models import Playlist, PlaylistTrack, Track
from synciflow.storage.zip_builder import build_playlist_zip
from synciflow.services.tagging import ensure_cover_art
from fastapi.middleware.cors import CORSMiddleware

from synciflow.auth.config import (
    ACCESS_TOKEN_EXPIRE_MINUTES,
    create_access_token,
    create_refresh_token,
    decode_token,
    hash_password,
    verify_password,
)
from synciflow.db.models import User


# ---------------------------------------------------------------------------
# API prefixes — SPA catch-all will NOT intercept these
# ---------------------------------------------------------------------------
_API_PREFIXES = (
    "/auth/",
    "/track/",
    "/tracks",
    "/playlist/",
    "/playlists",
    "/likes/",
    "/jobs",           # covers /jobs and /jobs/
    "/library/",
    "/ws/",
    "/assets/",
)


# =============================================================================
# Schemas
# =============================================================================

class LoadRequest(BaseModel):
    url: str


class RegisterRequest(BaseModel):
    username: str = Field(..., min_length=3, max_length=50, examples=["alice"])
    email: EmailStr = Field(..., examples=["alice@example.com"])
    password: str = Field(..., min_length=8, examples=["s3cur3P@ss"])


class LoginRequest(BaseModel):
    username: str = Field(..., examples=["alice"])
    password: str = Field(..., examples=["s3cur3P@ss"])


class RefreshRequest(BaseModel):
    refresh_token: str


class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int


class UserResponse(BaseModel):
    id: int
    username: str
    email: str
    is_active: bool

    class Config:
        from_attributes = True


# =============================================================================
# App state
# =============================================================================

@dataclass(frozen=True)
class AppState:
    library: Library


# =============================================================================
# Auth dependency factory
# =============================================================================

_bearer_scheme = HTTPBearer(auto_error=True)

_CREDENTIALS_EXCEPTION = HTTPException(
    status_code=status.HTTP_401_UNAUTHORIZED,
    detail="Could not validate credentials",
    headers={"WWW-Authenticate": "Bearer"},
)


def _make_auth_dep(session_dep):
    def _dep(
        credentials: HTTPAuthorizationCredentials = Depends(_bearer_scheme),
        session: Session = Depends(session_dep),
    ) -> User:
        token = credentials.credentials
        try:
            payload = decode_token(token)
            if payload.get("type") != "access":
                raise _CREDENTIALS_EXCEPTION
            username: str | None = payload.get("sub")
            if not username:
                raise _CREDENTIALS_EXCEPTION
        except JWTError:
            raise _CREDENTIALS_EXCEPTION

        user = session.exec(select(User).where(User.username == username)).first()
        if user is None or not user.is_active:
            raise _CREDENTIALS_EXCEPTION
        return user

    return _dep


# =============================================================================
# Frontend helper
# =============================================================================

def _find_frontend_dir() -> Optional[Path]:
    try:
        base = resources.files("synciflow") / "frontend"
        candidate = Path(base)
        if candidate.is_dir():
            return candidate
    except Exception:
        pass

    here = Path(__file__).resolve()
    for root in [here.parent.parent.parent, here.parent.parent]:
        candidate = root / "frontend"
        if candidate.is_dir():
            return candidate

    return None


# =============================================================================
# Background job runners  — now carry user_id through to the bus event
# =============================================================================

def _run_track_load_job(library, url, job_id, bus, user_id: int):
    with Session(library.engine) as session:
        try:
            update_job_progress(session, job_id, 0.0, "Starting track download")
            bus.publish_sync(NotificationEvent(
                TRACK_DOWNLOAD_STARTED, job_id=job_id, message="Starting", user_id=user_id
            ))

            def track_progress(phase: str) -> None:
                with Session(library.engine) as s2:
                    if phase == "started":
                        update_job_progress(s2, job_id, 0.0, "Downloading")
                    else:
                        update_job_progress(s2, job_id, 1.0, "Completed")

            tm = library.track_manager(session, user_id)
            track = tm.load_track(url, progress_callback=track_progress)
            complete_job(session, job_id)
            bus.publish_sync(NotificationEvent(
                TRACK_DOWNLOAD_COMPLETED, job_id=job_id, progress=1.0,
                message=track.track_title or track.track_id,
                payload={"track_id": track.track_id}, user_id=user_id,
            ))
        except Exception as e:
            fail_job(session, job_id, str(e))
            bus.publish_sync(NotificationEvent(ERROR, job_id=job_id, message=str(e), user_id=user_id))
            raise


def _run_playlist_load_job(library, url, job_id, bus, user_id: int):
    with Session(library.engine) as session:
        try:
            update_job_progress(session, job_id, 0.0, "Loading playlist")

            def progress_cb(current, total, message):
                with Session(library.engine) as s2:
                    p = current / total if total else 0.0
                    update_job_progress(s2, job_id, p, message)
                bus.publish_sync(NotificationEvent(
                    PLAYLIST_PROGRESS, job_id=job_id, progress=p, message=message,
                    payload={"current": current, "total": total}, user_id=user_id,
                ))

            pm = library.playlist_manager(session, user_id)
            playlist = pm.load_playlist(url, progress_callback=progress_cb)
            complete_job(session, job_id)
            bus.publish_sync(NotificationEvent(
                PLAYLIST_COMPLETED, job_id=job_id, progress=1.0,
                message=playlist.title or playlist.playlist_id,
                payload={"playlist_id": playlist.playlist_id}, user_id=user_id,
            ))
        except Exception as e:
            fail_job(session, job_id, str(e))
            bus.publish_sync(NotificationEvent(ERROR, job_id=job_id, message=str(e), user_id=user_id))
            raise


def _run_likes_load_job(library, job_id, bus, user_id: int):
    with Session(library.engine) as session:
        try:
            update_job_progress(session, job_id, 0.0, "Loading liked songs")

            def progress_cb(current, total, message):
                with Session(library.engine) as s2:
                    p = current / total if total else 0.0
                    update_job_progress(s2, job_id, p, message)
                bus.publish_sync(NotificationEvent(
                    PLAYLIST_PROGRESS, job_id=job_id, progress=p, message=message,
                    payload={"current": current, "total": total, "playlist_id": LIKES_PLAYLIST_ID},
                    user_id=user_id,
                ))

            pm = library.playlist_manager(session, user_id)
            playlist = pm.load_likes(progress_callback=progress_cb)
            complete_job(session, job_id)
            bus.publish_sync(NotificationEvent(
                PLAYLIST_COMPLETED, job_id=job_id, progress=1.0,
                message=playlist.title or playlist.playlist_id,
                payload={"playlist_id": playlist.playlist_id}, user_id=user_id,
            ))
        except Exception as e:
            fail_job(session, job_id, str(e))
            bus.publish_sync(NotificationEvent(ERROR, job_id=job_id, message=str(e), user_id=user_id))
            raise


def _run_sync_job(library, url, job_id, bus, user_id: int):
    with Session(library.engine) as session:
        try:
            update_job_progress(session, job_id, 0.0, "Starting sync")

            def progress_cb(current, total, message):
                with Session(library.engine) as s2:
                    p = current / total if total else 0.0
                    update_job_progress(s2, job_id, p, message)
                bus.publish_sync(NotificationEvent(
                    SYNC_PROGRESS, job_id=job_id, progress=p, message=message,
                    payload={"current": current, "total": total}, user_id=user_id,
                ))

            sm = library.sync_manager(session)
            result = sm.sync_playlist(url, progress_callback=progress_cb)
            complete_job(session, job_id)
            bus.publish_sync(NotificationEvent(
                SYNC_COMPLETED, job_id=job_id, progress=1.0,
                message=f"added={result.added} removed={result.removed} kept={result.kept}",
                payload={"added": result.added, "removed": result.removed, "kept": result.kept},
                user_id=user_id,
            ))
        except Exception as e:
            fail_job(session, job_id, str(e))
            bus.publish_sync(NotificationEvent(ERROR, job_id=job_id, message=str(e), user_id=user_id))
            raise


def _run_likes_sync_job(library, job_id, bus, user_id: int):
    with Session(library.engine) as session:
        try:
            update_job_progress(session, job_id, 0.0, "Starting likes sync")

            def progress_cb(current, total, message):
                with Session(library.engine) as s2:
                    p = current / total if total else 0.0
                    update_job_progress(s2, job_id, p, message)
                bus.publish_sync(NotificationEvent(
                    SYNC_PROGRESS, job_id=job_id, progress=p, message=message,
                    payload={"current": current, "total": total, "playlist_id": LIKES_PLAYLIST_ID},
                    user_id=user_id,
                ))

            sm = library.sync_manager(session)
            result = sm.sync_likes(progress_callback=progress_cb)
            complete_job(session, job_id)
            bus.publish_sync(NotificationEvent(
                SYNC_COMPLETED, job_id=job_id, progress=1.0,
                message=f"added={result.added} removed={result.removed} kept={result.kept}",
                payload={
                    "added": result.added, "removed": result.removed,
                    "kept": result.kept, "playlist_id": LIKES_PLAYLIST_ID,
                },
                user_id=user_id,
            ))
        except Exception as e:
            fail_job(session, job_id, str(e))
            bus.publish_sync(NotificationEvent(ERROR, job_id=job_id, message=str(e), user_id=user_id))
            raise


# =============================================================================
# Lifespan
# =============================================================================

@asynccontextmanager
async def _lifespan(app: FastAPI):
    bus = NotificationBus()
    loop = asyncio.get_running_loop()
    bus.start_bridge(loop)
    app.state.notification_bus = bus

    # Scheduler — start background cleanup thread
    library: Library = app.state._synciflow.library
    library.scheduler.start()
    yield
    library.scheduler.stop()
    bus.stop_bridge()


# =============================================================================
# App factory
# =============================================================================

def create_app(library: Library | None = None) -> FastAPI:
    library = library or Library.create()
    app = FastAPI(title="synciflow", version="0.0.1", lifespan=_lifespan)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    app.state._synciflow = AppState(library=library)

    def _session():
        yield from get_session(library.engine)

    require_auth = _make_auth_dep(_session)

    # =========================================================================
    # AUTH ROUTES  (public)
    # =========================================================================

    @app.post("/auth/register", response_model=UserResponse,
              status_code=status.HTTP_201_CREATED, tags=["auth"])
    def auth_register(body: RegisterRequest, session: Session = Depends(_session)):
        if session.exec(select(User).where(User.username == body.username)).first():
            raise HTTPException(status_code=409, detail="Username already taken")
        if session.exec(select(User).where(User.email == body.email)).first():
            raise HTTPException(status_code=409, detail="Email already registered")
        user = User(username=body.username, email=body.email,
                    hashed_password=hash_password(body.password))
        session.add(user)
        session.commit()
        session.refresh(user)
        return user

    @app.post("/auth/login", response_model=TokenResponse, tags=["auth"])
    def auth_login(body: LoginRequest, session: Session = Depends(_session)):
        user = session.exec(select(User).where(User.username == body.username)).first()
        if user is None or not verify_password(body.password, user.hashed_password):
            raise HTTPException(status_code=401, detail="Incorrect username or password",
                                headers={"WWW-Authenticate": "Bearer"})
        if not user.is_active:
            raise HTTPException(status_code=403, detail="User account is disabled")
        return TokenResponse(
            access_token=create_access_token(subject=user.username),
            refresh_token=create_refresh_token(subject=user.username),
            expires_in=ACCESS_TOKEN_EXPIRE_MINUTES * 60,
        )

    @app.post("/auth/refresh", response_model=TokenResponse, tags=["auth"])
    def auth_refresh(body: RefreshRequest, session: Session = Depends(_session)):
        _invalid = HTTPException(status_code=401, detail="Invalid or expired refresh token",
                                 headers={"WWW-Authenticate": "Bearer"})
        try:
            payload = decode_token(body.refresh_token)
            if payload.get("type") != "refresh":
                raise _invalid
            username: str | None = payload.get("sub")
            if not username:
                raise _invalid
        except JWTError:
            raise _invalid
        user = session.exec(select(User).where(User.username == username)).first()
        if user is None or not user.is_active:
            raise _invalid
        return TokenResponse(
            access_token=create_access_token(subject=user.username),
            refresh_token=create_refresh_token(subject=user.username),
            expires_in=ACCESS_TOKEN_EXPIRE_MINUTES * 60,
        )

    @app.get("/auth/me", response_model=UserResponse, tags=["auth"])
    def auth_me(current_user: User = Depends(require_auth)):
        return current_user

    # =========================================================================
    # JOBS  (user-scoped)
    # =========================================================================

    @app.get("/jobs", tags=["jobs"],
             summary="List all jobs for the authenticated user")
    def list_user_jobs(
        job_status: str | None = Query(None, alias="status",
                                       description="Filter by status: pending | running | completed | failed"),
        limit: int = Query(50, ge=1, le=200),
        session: Session = Depends(_session),
        current_user: User = Depends(require_auth),
    ):
        """
        Returns jobs created by the current user, newest first.
        Optionally filter by `status`.
        """
        jobs = list_jobs(session, user_id=current_user.id, status=job_status, limit=limit)
        return [
            {
                "job_id":     j.job_id,
                "job_type":   j.job_type,
                "status":     j.status,
                "progress":   j.progress,
                "message":    j.message,
                "created_at": j.created_at.isoformat(),
                "updated_at": j.updated_at.isoformat(),
            }
            for j in jobs
        ]

    @app.get("/jobs/{job_id}", tags=["jobs"],
             summary="Get status of a single job (must belong to current user)")
    def get_job_status(
        job_id: str,
        session: Session = Depends(_session),
        current_user: User = Depends(require_auth),
    ):
        job = get_job(session, job_id, user_id=current_user.id)
        if job is None:
            raise HTTPException(status_code=404, detail="Job not found")
        return {
            "job_id":     job.job_id,
            "job_type":   job.job_type,
            "status":     job.status,
            "progress":   job.progress,
            "message":    job.message,
            "created_at": job.created_at.isoformat(),
            "updated_at": job.updated_at.isoformat(),
        }

    # =========================================================================
    # PROTECTED ROUTES — job runners now receive user_id
    # =========================================================================

    @app.post("/track/load", tags=["tracks"])
    async def load_track(
        req: LoadRequest,
        session: Session = Depends(_session),
        current_user: User = Depends(require_auth),
    ):
        bus: NotificationBus = app.state.notification_bus
        job = create_job(session, "track_load", user_id=current_user.id)
        asyncio.create_task(
            asyncio.to_thread(_run_track_load_job, library, req.url, job.job_id, bus, current_user.id)
        )
        return {"job_id": job.job_id}, 202

    @app.post("/playlist/load", tags=["playlists"])
    async def load_playlist(
        req: LoadRequest,
        session: Session = Depends(_session),
        current_user: User = Depends(require_auth),
    ):
        bus: NotificationBus = app.state.notification_bus
        job = create_job(session, "playlist_load", user_id=current_user.id)
        asyncio.create_task(
            asyncio.to_thread(_run_playlist_load_job, library, req.url, job.job_id, bus, current_user.id)
        )
        return {"job_id": job.job_id}, 202

    @app.post("/likes/load", tags=["likes"])
    async def load_likes(
        session: Session = Depends(_session),
        current_user: User = Depends(require_auth),
    ):
        bus: NotificationBus = app.state.notification_bus
        job = create_job(session, "likes_load", user_id=current_user.id)
        asyncio.create_task(
            asyncio.to_thread(_run_likes_load_job, library, job.job_id, bus, current_user.id)
        )
        return {"job_id": job.job_id}, 202

    @app.post("/playlist/sync", tags=["playlists"])
    async def sync_playlist(
        req: LoadRequest,
        session: Session = Depends(_session),
        current_user: User = Depends(require_auth),
    ):
        bus: NotificationBus = app.state.notification_bus
        job = create_job(session, "sync", user_id=current_user.id)
        asyncio.create_task(
            asyncio.to_thread(_run_sync_job, library, req.url, job.job_id, bus, current_user.id)
        )
        return {"job_id": job.job_id}, 202

    @app.post("/likes/sync", tags=["likes"])
    async def sync_likes(
        session: Session = Depends(_session),
        current_user: User = Depends(require_auth),
    ):
        bus: NotificationBus = app.state.notification_bus
        job = create_job(session, "likes_sync", user_id=current_user.id)
        asyncio.create_task(
            asyncio.to_thread(_run_likes_sync_job, library, job.job_id, bus, current_user.id)
        )
        return {"job_id": job.job_id}, 202

    @app.post("/track/{track_id}/load_local", tags=["tracks"])
    def load_track_local(track_id: str, session: Session = Depends(_session),
                         current_user: User = Depends(require_auth)):
        return library.track_manager(session, current_user.id).load_local(track_id).model_dump()

    @app.post("/playlist/{playlist_id}/load_local", tags=["playlists"])
    def load_playlist_local(playlist_id: str, session: Session = Depends(_session),
                            current_user: User = Depends(require_auth)):
        return library.playlist_manager(session, current_user.id).load_local(playlist_id).model_dump()

    @app.get("/track/{track_id}", tags=["tracks"])
    def get_track(track_id: str, session: Session = Depends(_session),
                  current_user: User = Depends(require_auth)):
        t = session.exec(
            select(Track)
            .where(Track.track_id == track_id)
            .where(Track.user_id == current_user.id)
        ).first()
        if t is None:
            raise HTTPException(status_code=404, detail="Track not found")
        return t.model_dump()

    @app.get("/playlist/{playlist_id}", tags=["playlists"])
    def get_playlist(playlist_id: str, session: Session = Depends(_session),
                     current_user: User = Depends(require_auth)):
        p = session.exec(
            select(Playlist)
            .where(Playlist.playlist_id == playlist_id)
            .where(Playlist.user_id == current_user.id)
        ).first()
        if p is None:
            raise HTTPException(status_code=404, detail="Playlist not found")
        return p.model_dump()

    @app.get("/tracks", tags=["tracks"])
    def list_tracks(session: Session = Depends(_session), current_user: User = Depends(require_auth)):
        return [t.model_dump() for t in session.exec(
            select(Track).where(Track.user_id == current_user.id)
        ).all()]

    @app.get("/playlists", tags=["playlists"])
    def list_playlists(session: Session = Depends(_session), current_user: User = Depends(require_auth)):
        return [p.model_dump() for p in session.exec(
            select(Playlist).where(Playlist.user_id == current_user.id)
        ).all()]

    @app.get("/playlist/{playlist_id}/tracks", tags=["playlists"])
    def get_playlist_tracks(playlist_id: str, session: Session = Depends(_session),
                            current_user: User = Depends(require_auth)):
        # Verify ownership first
        playlist = session.exec(
            select(Playlist)
            .where(Playlist.playlist_id == playlist_id)
            .where(Playlist.user_id == current_user.id)
        ).first()
        if playlist is None:
            raise HTTPException(status_code=404, detail="Playlist not found")
        rows = session.exec(
            select(PlaylistTrack, Track)
            .where(PlaylistTrack.playlist_db_id == playlist.id)
            .where(PlaylistTrack.track_db_id == Track.id)
            .where(Track.user_id == current_user.id)
            .order_by(PlaylistTrack.position)
        ).all()
        return [{"position": rel.position, "track": track.model_dump()} for rel, track in rows]

    @app.get("/track/{track_id}/stream", tags=["tracks"])
    def stream_track(track_id: str, session: Session = Depends(_session),
                     current_user: User = Depends(require_auth)):
        t = session.exec(
            select(Track)
            .where(Track.track_id == track_id)
            .where(Track.user_id == current_user.id)
        ).first()
        if t is None or not t.audio_path:
            raise HTTPException(status_code=404, detail="Track or audio not found")
        return FileResponse(path=t.audio_path, media_type="audio/mpeg", filename=f"{track_id}.mp3")

    @app.get("/track/{track_id}/download", tags=["tracks"])
    def download_track(track_id: str, session: Session = Depends(_session),
                       current_user: User = Depends(require_auth)):
        t = session.exec(
            select(Track)
            .where(Track.track_id == track_id)
            .where(Track.user_id == current_user.id)
        ).first()
        if t is None or not t.audio_path:
            raise HTTPException(status_code=404, detail="Track or audio not found")
        return FileResponse(path=t.audio_path, media_type="audio/mpeg",
                            filename=f"{t.track_title or track_id}.mp3")

    def _sanitize_filename(name: str, fallback: str) -> str:
        name = name.strip() or fallback
        name = re.sub(r'[\\/:*?"<>|]', "-", name)
        name = re.sub(r"\s+", " ", name)
        name = re.sub(r"-{2,}", "-", name)
        return name[:120].strip()

    def _track_display_name(track: Track) -> str:
        parts = [p for p in [track.track_title, track.artist_title] if p]
        return _sanitize_filename(" - ".join(parts) if parts else track.track_id, track.track_id)

    @app.get("/playlist/{playlist_id}/download.zip", tags=["playlists"])
    def download_playlist_zip(playlist_id: str, session: Session = Depends(_session),
                              current_user: User = Depends(require_auth)):
        playlist = session.exec(
            select(Playlist)
            .where(Playlist.playlist_id == playlist_id)
            .where(Playlist.user_id == current_user.id)
        ).first()
        if playlist is None:
            raise HTTPException(status_code=404, detail="Playlist not found")
        rows = session.exec(
            select(PlaylistTrack, Track)
            .where(PlaylistTrack.playlist_db_id == playlist.id)
            .where(PlaylistTrack.track_db_id == Track.id)
            .where(Track.user_id == current_user.id)
            .order_by(PlaylistTrack.position)
        ).all()
        user_files = library.user_files(current_user.id)
        track_files = []
        tmp_root = user_files.storage.tmp_dir / "playlist-zips" / playlist_id
        for rel, track in rows:
            if not track.audio_path:
                continue
            src = Path(track.audio_path)
            if not src.exists():
                continue
            tmp_dir = tmp_root / "tracks"
            tmp_dir.mkdir(parents=True, exist_ok=True)
            tmp_path = tmp_dir / f"{track.track_id}.mp3"
            try:
                shutil.copyfile(src, tmp_path)
            except OSError:
                continue
            track_files.append((rel.position, track.track_id, _track_display_name(track),
                                 ensure_cover_art(tmp_path, track.track_image_url)))
        if not track_files:
            raise HTTPException(status_code=404, detail="No audio files available for playlist")
        zip_path = build_playlist_zip(user_files, playlist_id, track_files)
        return FileResponse(str(zip_path), media_type="application/zip",
                            filename=f"{playlist.title or playlist_id}.zip")

    @app.get("/library/download-all-tracks.zip", tags=["library"])
    def download_all_tracks_zip(session: Session = Depends(_session),
                                current_user: User = Depends(require_auth)):
        rows = session.exec(
            select(Track)
            .where(Track.user_id == current_user.id)
            .order_by(Track.created_at, Track.track_id)
        ).all()
        user_files = library.user_files(current_user.id)
        track_files = []
        tmp_root = user_files.storage.tmp_dir / "library-zips" / "all-tracks"
        for i, track in enumerate(rows, 1):
            if not track.audio_path:
                continue
            src = Path(track.audio_path)
            if not src.exists():
                continue
            tmp_dir = tmp_root / "tracks"
            tmp_dir.mkdir(parents=True, exist_ok=True)
            tmp_path = tmp_dir / f"{track.track_id}.mp3"
            try:
                shutil.copyfile(src, tmp_path)
            except OSError:
                continue
            track_files.append((i, track.track_id, _track_display_name(track),
                                 ensure_cover_art(tmp_path, track.track_image_url)))
        if not track_files:
            raise HTTPException(status_code=404, detail="No audio files available in library")
        zip_path = build_playlist_zip(user_files, "all-tracks", track_files)
        return FileResponse(str(zip_path), media_type="application/zip", filename="all-tracks.zip")

    # =========================================================================
    # PER-USER WEBSOCKET
    # =========================================================================

    @app.websocket("/ws/notifications")
    async def ws_notifications(
        websocket: WebSocket,
        token: str = Query(..., description="Access token for authentication"),
    ):
        """
        Per-user real-time notification stream.

        Authentication
        --------------
        Pass the access_token as a query parameter:
            ws://host/ws/notifications?token=<access_token>

        Isolation
        ---------
        Each connection is scoped to the authenticated user — only events
        generated by that user's jobs are delivered.  Other users' events
        are never visible.

        Event shape
        -----------
        {
          "event_type": "TRACK_DOWNLOAD_COMPLETED" | "PLAYLIST_PROGRESS" | ...,
          "job_id":     "<uuid>",
          "progress":   0.0 – 1.0,
          "message":    "...",
          "user_id":    <int>,
          ...payload fields
        }
        """
        # ── Authenticate the WebSocket handshake ──────────────────────────
        try:
            payload = decode_token(token)
            if payload.get("type") != "access":
                await websocket.close(code=4001)
                return
            username: str | None = payload.get("sub")
            if not username:
                await websocket.close(code=4001)
                return
        except JWTError:
            await websocket.close(code=4001)
            return

        # Resolve user from DB
        async with Session(library.engine) as session:
            user = session.exec(select(User).where(User.username == username)).first()

        if user is None or not user.is_active:
            await websocket.close(code=4001)
            return

        await websocket.accept()

        bus: NotificationBus = app.state.notification_bus
        subscriber_queue = bus.subscribe(user_id=user.id)   # ← scoped to this user

        try:
            while True:
                event = await subscriber_queue.get()
                await websocket.send_json(event.to_dict())
        except WebSocketDisconnect:
            pass
        finally:
            bus.unsubscribe(subscriber_queue, user_id=user.id)

    # =========================================================================
    # Frontend static UI
    # =========================================================================

    frontend_dir = _find_frontend_dir()
    if frontend_dir is not None:
        index_file = frontend_dir / "index.html"
        assets_dir = frontend_dir / "assets"
        if assets_dir.is_dir():
            app.mount("/assets", StaticFiles(directory=str(assets_dir)), name="frontend-assets")

        @app.get("/", include_in_schema=False)
        async def serve_frontend_root():
            if not index_file.is_file():
                raise HTTPException(status_code=500, detail="Frontend index.html not found")
            return FileResponse(str(index_file), media_type="text/html")

        @app.get("/{full_path:path}", include_in_schema=False)
        async def serve_frontend_spa(full_path: str):
            request_path = f"/{full_path}"
            if any(request_path.startswith(p) for p in _API_PREFIXES):
                raise HTTPException(status_code=404, detail="Not found")
            candidate = frontend_dir / full_path
            if candidate.is_file():
                return FileResponse(str(candidate))
            if not index_file.is_file():
                raise HTTPException(status_code=500, detail="Frontend index.html not found")
            return FileResponse(str(index_file), media_type="text/html")

    return app