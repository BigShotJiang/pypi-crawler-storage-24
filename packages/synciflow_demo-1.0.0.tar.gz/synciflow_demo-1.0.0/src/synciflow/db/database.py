from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Generator

from sqlalchemy import event
from sqlmodel import Session, SQLModel, create_engine


@dataclass(frozen=True)
class DatabaseConfig:
    db_path: Path


def create_sqlite_engine(cfg: DatabaseConfig):
    """
    Create a SQLite engine with production-ready pragmas.

    - Ensures the parent directory exists before SQLite tries to create the file.
    - WAL mode: concurrent reads don't block writes (critical for background threads).
    - synchronous=NORMAL: safe with WAL, removes unnecessary disk flushes.
    - busy_timeout=30000: wait up to 30 s on a locked DB instead of crashing instantly.
    - foreign_keys=ON: SQLite ignores FK constraints by default — enforce them.
    """
    # Create the data directory if it doesn't exist yet.
    # Without this SQLite raises "unable to open database file".
    cfg.db_path.parent.mkdir(parents=True, exist_ok=True)

    db_url = f"sqlite:///{cfg.db_path}"
    engine = create_engine(
        db_url,
        connect_args={"check_same_thread": False},
        echo=False,
    )

    @event.listens_for(engine, "connect")
    def _set_sqlite_pragma(dbapi_conn, _connection_record):
        cursor = dbapi_conn.cursor()
        cursor.execute("PRAGMA journal_mode=WAL")
        cursor.execute("PRAGMA synchronous=NORMAL")
        cursor.execute("PRAGMA busy_timeout=30000")
        cursor.execute("PRAGMA foreign_keys=ON")
        cursor.close()

    return engine


def init_db(engine) -> None:
    """
    Create all tables defined in SQLModel metadata.

    Imports models explicitly so SQLModel's metadata registry knows about
    every table before create_all() runs — even if nothing else has
    imported them yet.
    """
    import synciflow.db.models  # noqa: F401

    SQLModel.metadata.create_all(engine)


def get_session(engine) -> Generator[Session, None, None]:
    """FastAPI dependency: yield a DB session, close it when the request ends."""
    with Session(engine) as session:
        yield session