from __future__ import annotations
import sys
import shutil
from pathlib import Path

import typer
from rich.progress import BarColumn, Progress, TaskProgressColumn, TextColumn
from sqlmodel import select

from synciflow.api.server import create_app
from synciflow.config import AppConfig
from synciflow.core.library_manager import Library
from synciflow.core.utils import LIKES_PLAYLIST_ID, track_display_name
from synciflow.db.models import Playlist, PlaylistTrack, Track
from synciflow.services.tagging import ensure_cover_art
from synciflow.storage.path_manager import ensure_parent_dir
from synciflow.storage.zip_builder import build_playlist_zip

from .smart import _print_header, run as run_smart_cli


app = typer.Typer(add_completion=False)

# ---------------------------------------------------------------------------
# CLI runs without a logged-in user — we use a sentinel user_id of 0 which
# maps to a shared "local" storage area (storage_data/users/0/).
# In a real deployment the CLI would accept --user-id or read from config.
# ---------------------------------------------------------------------------
_CLI_USER_ID = 0


def _lib() -> Library:
    return Library.create(AppConfig())


@app.command()
def track(url: str):
    """Load a single track into the offline library."""
    lib = _lib()
    with lib.session() as session:
        tm = lib.track_manager(session, _CLI_USER_ID)
        progress = Progress(
            TextColumn("[bold blue]{task.description}"),
            BarColumn(),
            TaskProgressColumn(),
        )
        with progress:
            task_id = progress.add_task("Downloading track...", total=2)

            def track_progress(phase: str) -> None:
                if phase == "started":
                    progress.update(task_id, advance=1, description="Downloading...")
                else:
                    progress.update(task_id, advance=1, description="Done")

            t = tm.load_track(url, progress_callback=track_progress)
            progress.update(task_id, completed=2, description="Done")
        typer.echo(f"{t.track_title} - {t.artist_title}")
        typer.echo(f"id={t.track_id}")
        typer.echo(f"path={t.audio_path}")


@app.command("track-local")
def track_local(track_id: str):
    """Register or repair a track from an existing local file by ID."""
    lib = _lib()
    with lib.session() as session:
        tm = lib.track_manager(session, _CLI_USER_ID)
        t = tm.load_local(track_id)
        typer.echo(f"{t.track_title or '<unknown title>'} - {t.artist_title or '<unknown artist>'}")
        typer.echo(f"id={t.track_id}")
        typer.echo(f"path={t.audio_path}")


@app.command()
def playlist(url: str):
    """Load a playlist into the offline library (downloads all tracks)."""
    lib = _lib()
    with lib.session() as session:
        pm = lib.playlist_manager(session, _CLI_USER_ID)
        progress = Progress(
            TextColumn("[bold blue]{task.description}"),
            BarColumn(),
            TaskProgressColumn(),
        )
        with progress:
            task_id = progress.add_task("Loading playlist...", total=None)

            def progress_cb(current: int, total: int, message: str) -> None:
                progress.update(
                    task_id,
                    total=total,
                    completed=current,
                    description=message[:60] if message else f"Track {current}/{total}",
                )

            p = pm.load_playlist(url, progress_callback=progress_cb)
        typer.echo(f"{p.title}")
        typer.echo(f"id={p.playlist_id}")


@app.command("likes")
def likes():
    """Load or sync your Spotify Liked Songs into the offline library."""
    lib = _lib()
    with lib.session() as session:
        sm = lib.sync_manager(session, _CLI_USER_ID)
        progress = Progress(
            TextColumn("[bold blue]{task.description}"),
            BarColumn(),
            TaskProgressColumn(),
        )
        with progress:
            task_id = progress.add_task("Syncing liked songs...", total=None)

            def progress_cb(current: int, total: int, message: str) -> None:
                progress.update(
                    task_id,
                    total=total or 1,
                    completed=current,
                    description=message[:60] if message else "Syncing liked songs...",
                )

            result = sm.sync_likes(progress_callback=progress_cb)
        typer.echo(f"playlist_id={LIKES_PLAYLIST_ID}_{_CLI_USER_ID}")
        typer.echo(f"added={result.added} removed={result.removed} kept={result.kept}")


@app.command("playlist-local")
def playlist_local(playlist_id: str):
    """Register or repair a playlist using local tracks and stored metadata."""
    lib = _lib()
    with lib.session() as session:
        pm = lib.playlist_manager(session, _CLI_USER_ID)
        p = pm.load_local(playlist_id)
        typer.echo(f"{p.title or '<untitled playlist>'}")
        typer.echo(f"id={p.playlist_id}")


@app.command()
def sync(url: str):
    """Sync an offline playlist with the current Spotify playlist state."""
    lib = _lib()
    with lib.session() as session:
        sm = lib.sync_manager(session, _CLI_USER_ID)
        progress = Progress(
            TextColumn("[bold blue]{task.description}"),
            BarColumn(),
            TaskProgressColumn(),
        )
        with progress:
            task_id = progress.add_task("Syncing playlist...", total=None)

            def progress_cb(current: int, total: int, message: str) -> None:
                progress.update(
                    task_id,
                    total=total or 1,
                    completed=current,
                    description=message[:60] if message else "Syncing...",
                )

            r = sm.sync_playlist(url, progress_callback=progress_cb)
        typer.echo(f"added={r.added} removed={r.removed} kept={r.kept}")


@app.command("tracks")
def list_tracks():
    """List all tracks in the library."""
    lib = _lib()
    with lib.session() as session:
        tracks = session.exec(
            select(Track).where(Track.user_id == _CLI_USER_ID)
        ).all()
        if not tracks:
            typer.echo("No tracks found.")
            return
        for t in tracks:
            typer.echo(f"{t.track_id} | {t.track_title} - {t.artist_title}")


@app.command("playlists")
def list_playlists():
    """List all playlists in the library."""
    lib = _lib()
    with lib.session() as session:
        playlists = session.exec(
            select(Playlist).where(Playlist.user_id == _CLI_USER_ID)
        ).all()
        if not playlists:
            typer.echo("No playlists found.")
            return
        for p in playlists:
            typer.echo(f"{p.playlist_id} | {p.title}")


def _build_playlist_zip_with_cover(lib: Library, playlist_id: str) -> Path:
    """Build a ZIP for the playlist with display names and embedded cover art."""
    with lib.session() as session:
        # Resolve playlist surrogate id (scoped to CLI user)
        playlist_row = session.exec(
            select(Playlist)
            .where(Playlist.playlist_id == playlist_id)
            .where(Playlist.user_id == _CLI_USER_ID)
        ).first()
        if playlist_row is None:
            typer.echo("Playlist not found.", err=True)
            raise typer.Exit(code=1)

        # Join via surrogate PKs
        rows = session.exec(
            select(PlaylistTrack, Track)
            .where(PlaylistTrack.playlist_db_id == playlist_row.id)
            .where(PlaylistTrack.track_db_id == Track.id)
            .where(Track.user_id == _CLI_USER_ID)
            .order_by(PlaylistTrack.position)
        ).all()

    user_files = lib.user_files(_CLI_USER_ID)
    track_files = []
    tmp_root = user_files.storage.tmp_dir / "playlist-zips" / playlist_id
    for rel, track in rows:
        if not track.audio_path:
            continue
        source_audio_path = Path(track.audio_path)
        if not source_audio_path.exists():
            continue
        tmp_audio_dir = tmp_root / "tracks"
        tmp_audio_dir.mkdir(parents=True, exist_ok=True)
        tmp_audio_path = tmp_audio_dir / f"{track.track_id}.mp3"
        try:
            shutil.copyfile(source_audio_path, tmp_audio_path)
        except OSError:
            continue
        tagged_path = ensure_cover_art(tmp_audio_path, track.track_image_url)
        display_name = track_display_name(track)
        track_files.append((rel.position, track.track_id, display_name, tagged_path))

    if not track_files:
        typer.echo("No audio files available for this playlist.", err=True)
        raise typer.Exit(code=1)
    return build_playlist_zip(user_files, playlist_id, track_files)


def _build_library_zip_with_cover(lib: Library) -> Path:
    """Build a ZIP for all tracks in the library with display names and embedded cover art."""
    with lib.session() as session:
        tracks = session.exec(
            select(Track)
            .where(Track.user_id == _CLI_USER_ID)
            .order_by(Track.created_at, Track.track_id)
        ).all()

    user_files = lib.user_files(_CLI_USER_ID)
    track_files = []
    tmp_root = user_files.storage.tmp_dir / "library-zips" / "all-tracks"
    position = 1
    for track in tracks:
        if not track.audio_path:
            continue
        source_audio_path = Path(track.audio_path)
        if not source_audio_path.exists():
            continue
        tmp_audio_dir = tmp_root / "tracks"
        tmp_audio_dir.mkdir(parents=True, exist_ok=True)
        tmp_audio_path = tmp_audio_dir / f"{track.track_id}.mp3"
        try:
            shutil.copyfile(source_audio_path, tmp_audio_path)
        except OSError:
            continue
        tagged_path = ensure_cover_art(tmp_audio_path, track.track_image_url)
        display_name = track_display_name(track)
        track_files.append((position, track.track_id, display_name, tagged_path))
        position += 1

    if not track_files:
        typer.echo("No audio files available in the library.", err=True)
        raise typer.Exit(code=1)
    return build_playlist_zip(user_files, "all-tracks", track_files)


@app.command("download-track")
def download_track(track_id: str, out: Path | None = typer.Argument(None)):
    """Download or export a single track file by ID."""
    lib = _lib()
    with lib.session() as session:
        t = session.exec(
            select(Track)
            .where(Track.track_id == track_id)
            .where(Track.user_id == _CLI_USER_ID)
        ).first()
        if t is None:
            typer.echo("Track not found.", err=True)
            raise typer.Exit(code=1)
        if not t.audio_path:
            typer.echo("Track has no audio file.", err=True)
            raise typer.Exit(code=1)
        src = Path(t.audio_path)
        if not src.exists():
            typer.echo("Audio file is missing on disk.", err=True)
            raise typer.Exit(code=1)
        if out is None:
            typer.echo(str(src))
            return
        out = Path(out)
        dest = out / src.name if out.is_dir() else out
        ensure_parent_dir(dest)
        shutil.copyfile(src, dest)
        typer.echo(f"Saved to {dest}")


@app.command("save-track")
def save_track(
    track_id: str,
    out: Path = typer.Argument(..., help="Output file or directory path"),
):
    """Save a single track to a file."""
    lib = _lib()
    with lib.session() as session:
        t = session.exec(
            select(Track)
            .where(Track.track_id == track_id)
            .where(Track.user_id == _CLI_USER_ID)
        ).first()
        if t is None:
            typer.echo("Track not found.", err=True)
            raise typer.Exit(code=1)
        if not t.audio_path:
            typer.echo("Track has no audio file.", err=True)
            raise typer.Exit(code=1)
    src = Path(t.audio_path)
    if not src.exists():
        typer.echo("Audio file is missing on disk.", err=True)
        raise typer.Exit(code=1)
    out = Path(out)
    dest = out / f"{track_display_name(t)}.mp3" if out.is_dir() else out
    ensure_parent_dir(dest)
    shutil.copyfile(src, dest)
    typer.echo(f"Saved to {dest}")


@app.command("download-playlist-zip")
def download_playlist_zip(playlist_id: str, out: Path):
    """Build a ZIP file for a playlist (with cover art) and save it."""
    lib = _lib()
    zip_path = _build_playlist_zip_with_cover(lib, playlist_id)
    out = Path(out)
    dest = out / zip_path.name if out.is_dir() else out
    ensure_parent_dir(dest)
    shutil.copyfile(zip_path, dest)
    typer.echo(f"Saved ZIP to {dest}")


@app.command("download-all-tracks-zip")
def download_all_tracks_zip(out: Path):
    """Build a ZIP file for all tracks in the library (with cover art) and save it."""
    lib = _lib()
    zip_path = _build_library_zip_with_cover(lib)
    out = Path(out)
    dest = out / zip_path.name if out.is_dir() else out
    ensure_parent_dir(dest)
    shutil.copyfile(zip_path, dest)
    typer.echo(f"Saved library ZIP to {dest}")


@app.command("save-playlist")
def save_playlist(
    playlist_id: str,
    out: Path = typer.Argument(..., help="Output ZIP file or directory path"),
):
    """Save a playlist as a ZIP file with embedded cover art."""
    lib = _lib()
    with lib.session() as session:
        playlist = session.exec(
            select(Playlist)
            .where(Playlist.playlist_id == playlist_id)
            .where(Playlist.user_id == _CLI_USER_ID)
        ).first()
        if playlist is None:
            typer.echo("Playlist not found.", err=True)
            raise typer.Exit(code=1)

    zip_path = _build_playlist_zip_with_cover(lib, playlist_id)
    out = Path(out)
    dest = out / f"{playlist.title or playlist_id}.zip" if out.is_dir() else out
    ensure_parent_dir(dest)
    shutil.copyfile(zip_path, dest)
    typer.echo(f"Saved playlist ZIP to {dest}")


@app.command()
def smart():
    """Launch the interactive smart CLI."""
    run_smart_cli()


@app.command()
def serve(host: str = "127.0.0.1", port: int = 4359):
    """Run the FastAPI server (API + frontend UI)."""
    import uvicorn
    _print_header()
    api = create_app(Library.create(AppConfig()))
    uvicorn.run(api, host=host, port=port)


def run():
    if len(sys.argv) == 1:
        sys.argv.append("--help")
    app()