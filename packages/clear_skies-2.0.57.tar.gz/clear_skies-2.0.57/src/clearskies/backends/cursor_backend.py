from __future__ import annotations

from collections.abc import Callable
from typing import TYPE_CHECKING, Any

from clearskies.autodoc.schema import Integer as AutoDocInteger
from clearskies.autodoc.schema import Schema as AutoDocSchema
from clearskies.backends.backend import Backend
from clearskies.di import InjectableProperties, inject
from clearskies.query import Condition, ParsedCondition, Query
from clearskies.query.result import (
    CountQueryResult,
    RecordQueryResult,
    RecordsQueryResult,
    SuccessQueryResult,
)

if TYPE_CHECKING:
    from clearskies import Model
    from clearskies.di import Di


class CursorBackend(Backend, InjectableProperties):
    """
    The cursor backend connects your models to a MySQL or MariaDB database.

    ## Installing Dependencies

    clearskies uses PyMySQL to manage the database connection and make queries.  This is not installed by default,
    but is a named extra that you can install when needed via:

    ```bash
    pip install clear-skies[mysql]
    ```

    ## Connecting to your server

    By default, database credentials are expected in environment variables:

    | Name        | Default | Value                                                         |
    |-------------|---------|---------------------------------------------------------------|
    | db_host     |         | The hostname where the database can be found                  |
    | db_username |         | The username to connect as                                    |
    | db_password |         | The password to connect with                                  |
    | db_database |         | The name of the database to use                               |
    | db_port     | 3306    | The network port to connect to                                |
    | db_ssl_ca   |         | Path to a certificate to use: enables SSL over the connection |

    However, you can fully control the credential provisioning process by declaring a dependency named `connection_details` and
    setting it to a dictionary with the above keys, minus the `db_` prefix:

    ```python
    class ConnectionDetails(clearskies.di.AdditionalConfig):
        provide_connection_details(self, secrets):
            return {
                "host": secrets.get("database_host"),
                "username": secrets.get("db_username"),
                "password": secrets.get("db_password"),
                "database": secrets.get("db_database"),
                "port": 3306,
                "ssl_ca": "/path/to/ca",
            }

    wsgi = clearskies.contexts.Wsgi(
        some_application,
        additional_configs=[ConnectionDetails()],
        bindings={
            "secrets": "" # some configuration here to point to your secret manager
        }
    )
    ```

    Similarly, some alternate credential provisioning schemes are built into clearskies.  See the
    clearskies.secrets.additional_configs module for those options.

    ## Connecting models to tables

    The table name for your model comes from calling the `destination_name` class method of the model class.  By
    default, this takes the class name, converts it to snake case, and then pluralizes it.  So, if you have a model
    class named `UserPreference` then the cursor backend will look for a table called `user_preferences`.  If this
    isn't what you want, then you can simply override `destination_name` to return whatever table you want:

    ```python
    class UserPreference(clearskies.Model):
        @classmethod
        def destination_name(cls):
            return "some_other_table_name"
    ```

    Additionally, the cursor backend accepts an argument called `table_prefix` which, if provided, will be prefixed
    to your table name.  Finally, you can declare a dependency called `global_table_prefix` which will automatically
    be added to every table name.  In the following example, the table name will be `user_configuration_preferences`
    due to:

     1. The `destination_name` method sets the table name to `preferences`
     2. The `table_prefix` argument to the CursorBackend constructor adds a prefix of `configuration_`
     3. The `global_table_prefix` binding sets a prefix of `user_`, wihch goes before everything else.

    ```python
    import clearskies


    class UserPreference(clearskies.Model):
        id_column_name = "id"
        backend = clearskies.backends.CursorBackend(table_prefix="configuration_")
        id = clearskies.columns.Uuid()

        @classmethod
        def destination_name(cls):
            return "preferences"


    cli = clearskies.contexts.Cli(
        clearskies.endpoints.Callable(
            lambda user_preferences: user_preferences.create(no_data=True).id,
        ),
        classes=[UserPreference],
        bindings={
            "global_table_prefix": "user_",
        },
    )
    ```

    """

    supports_n_plus_one = True
    global_table_prefix = inject.ByName("global_table_prefix")
    di: Di = inject.Di()  # type: ignore[assignment]

    def __init__(
        self,
        cursor_dependency_name: str = "cursor",
        table_prefix: str = "",
        can_create: bool | None = None,
        can_update: bool | None = None,
        can_delete: bool | None = None,
        can_query: bool | None = None,
    ):
        # Only pass permission flags to parent if they are explicitly set (not None)
        # This allows the parent's default values (True) to be used when not specified
        parent_kwargs = {}
        if can_create is not None:
            parent_kwargs["can_create"] = can_create
        if can_update is not None:
            parent_kwargs["can_update"] = can_update
        if can_delete is not None:
            parent_kwargs["can_delete"] = can_delete
        if can_query is not None:
            parent_kwargs["can_query"] = can_query
        super().__init__(**parent_kwargs)
        self.cursor_dependency_name = cursor_dependency_name
        self.table_prefix = table_prefix

    @property
    def cursor(self):
        """
        Lazily inject and return the database cursor instance.

        Returns
        -------
            The cursor object used for executing database queries.
        """
        if not hasattr(self, "_cursor"):
            self._cursor = self.di.build(self.cursor_dependency_name)
        return self._cursor

    def _finalize_table_name(self, table_name):
        self.logger.debug(f"Finalizing table name for: {table_name}")
        table_name = f"{self.global_table_prefix}{self.table_prefix}{table_name}"
        if "." not in table_name:
            return f"{self.cursor.table_escape_character}{table_name}{self.cursor.table_escape_character}"
        return (
            self.cursor.table_escape_character
            + f"{self.cursor.table_escape_character}.{self.cursor.table_escape_character}".join(table_name.split("."))
            + self.cursor.table_escape_character
        )

    def update(self, id: int | str, data: dict[str, Any], model: Model) -> RecordQueryResult:
        """
        Update the record with the given id with the information from the data dictionary.

        The updated record is fetched from the database after the update to ensure the returned
        data reflects any database-side changes (triggers, defaults, etc.).

        The result contains the updated record accessible via the `record` property:

        ```python
        result = backend.update(user_id, {"name": "Jane"}, user_model)
        updated_record = result.record  # {"id": user_id, "name": "Jane", ...}
        ```
        """
        query_parts = []
        parameters = []
        for key, val in data.items():
            query_parts.append(self.cursor.column_equals_with_placeholder(key))
            parameters.append(val)
        updates = ", ".join(query_parts)

        # update the record
        table_name = self._finalize_table_name(model.destination_name())
        id_equals = self.cursor.column_equals_with_placeholder(model.id_column_name)
        self.cursor.execute(f"UPDATE {table_name} SET {updates} WHERE {id_equals}", tuple([*parameters, id]))

        # and now query again to fetch the updated record.
        records_response = self.records(
            Query(model.__class__, conditions=[ParsedCondition(model.id_column_name, "=", [str(id)])])
        )
        records = records_response.data
        return RecordQueryResult(record=records[0])

    def create(self, data: dict[str, Any], model: Model) -> RecordQueryResult:
        """
        Create a record with the information from the data dictionary.

        The created record is fetched from the database after insertion to ensure the returned
        data includes any auto-generated values (auto-increment IDs, default values, etc.).

        The result contains the created record accessible via the `record` property:

        ```python
        result = backend.create({"name": "Jane"}, user_model)
        new_record = result.record  # {"id": "auto-generated-id", "name": "Jane", ...}
        ```
        """
        escape = self.cursor.column_escape_character
        columns = escape + f"{escape}, {escape}".join(data.keys()) + escape
        placeholders = ", ".join([self.cursor.value_placeholder for i in range(len(data))])

        table_name = self._finalize_table_name(model.destination_name())
        self.cursor.execute(f"INSERT INTO {table_name} ({columns}) VALUES ({placeholders})", tuple(data.values()))
        new_id = data.get(model.id_column_name)
        if not new_id:
            new_id = self.cursor.lastrowid
        if not new_id:
            raise ValueError("I can't figure out what the id is for a newly created record :(")

        records_response = self.records(
            Query(model.__class__, conditions=[ParsedCondition(model.id_column_name, "=", [new_id])])
        )
        records = records_response.data
        return RecordQueryResult(record=records[0])

    def delete(self, id: int | str, model: Model) -> SuccessQueryResult:
        """
        Delete the record with the given id.

        Executes a DELETE statement against the database for the record matching the given id.
        Raises an exception if the delete fails.

        The result indicates success via the `success` property:

        ```python
        result = backend.delete(user_id, user_model)
        assert result.success  # True
        ```
        """
        table_name = self._finalize_table_name(model.destination_name())
        id_equals = self.cursor.column_equals_with_placeholder(model.id_column_name)
        self.cursor.execute(f"DELETE FROM {table_name} WHERE {id_equals}", (id,))
        return SuccessQueryResult()

    def count(self, query: Query) -> CountQueryResult:
        """
        Return the number of records which match the given query configuration.

        Executes a COUNT(*) query against the database with the conditions from the query.

        The result contains the count accessible via the `count` property:

        ```python
        result = backend.count(query)
        total = result.count  # e.g., 42
        ```
        """
        (sql, parameters) = self.as_count_sql(query)
        self.cursor.execute(sql, parameters)
        count = 0
        for row in self.cursor:
            count = row[0] if type(row) == tuple else row["count"]
            break
        return CountQueryResult(count=count)

    def records(self, query: Query) -> RecordsQueryResult:
        """
        Return a list of records that match the given query configuration.

        Executes a SELECT query against the database with the conditions, joins, sorting,
        and pagination from the query.

        The result contains the records accessible via the `records` property, and pagination
        information in `next_page_data` if there are more results available:

        ```python
        result = backend.records(query)
        for record in result.records:
            print(record["name"])

        if result.has_more_pages():
            next_query = query.pagination(**result.next_page_data)
        ```
        """
        # I was going to get fancy and have this return an iterator, but since I'm going to load up
        # everything into a list anyway, I may as well just return the list, right?
        sql, parameters = self.as_sql(query)
        self.cursor.execute(sql, parameters)
        records = [row for row in self.cursor]
        next_page_data = None
        limit = query.limit
        start = query.pagination.get("start", 0)
        if limit and len(records) == limit:
            next_page_data = {"start": int(start) + int(limit)}
        return RecordsQueryResult(records=records, next_page_data=next_page_data)

    def as_sql(self, query: Query) -> tuple[str, tuple[Any]]:
        escape = self.cursor.column_escape_character
        table_name = query.model_class.destination_name()
        self.logger.debug(f"Generating SQL for table: {table_name} from model: {query.model_class.__name__}")
        wheres, parameters = self.conditions_as_wheres_and_parameters(
            query.conditions, query.model_class.destination_name()
        )
        select_parts = []
        if query.select_all:
            select_parts.append(self._finalize_table_name(table_name) + ".*")
        if query.selects:
            select_parts.extend(query.selects)
        select = ", ".join(select_parts)
        if query.joins:
            joins = " " + " ".join([join._raw_join for join in query.joins])
        else:
            joins = ""
        if query.sorts:
            sort_parts = []
            for sort in query.sorts:
                prefix = self._finalize_table_name(sort.table_name) + "." if sort.table_name else ""
                sort_parts.append(f"{prefix}{escape}{sort.column_name}{escape} {sort.direction}")
            order_by = " ORDER BY " + ", ".join(sort_parts)
        else:
            order_by = ""
        group_by = self.group_by_clause(query.group_by)
        limit = ""
        if query.limit:
            start = 0
            limit_size = int(query.limit)
            if "start" in query.pagination:
                start = int(query.pagination["start"])
            limit = f" LIMIT {start}, {limit_size}"

        table_name = self._finalize_table_name(table_name)
        return (
            f"SELECT {select} FROM {table_name}{joins}{wheres}{group_by}{order_by}{limit}".strip(),
            parameters,
        )

    def as_count_sql(self, query: Query) -> tuple[str, tuple[Any]]:
        escape = self.cursor.column_escape_character
        # note that this won't work if we start including a HAVING clause
        wheres, parameters = self.conditions_as_wheres_and_parameters(
            query.conditions, query.model_class.destination_name()
        )
        # we also don't currently support parameters in the join clause - I'll probably need that though
        if query.joins:
            # We can ignore left joins because they don't change the count
            join_sections = filter(lambda join: join.join_type != "LEFT", query.joins)
            joins = " " + " ".join([join._raw_join for join in join_sections])
        else:
            joins = ""
        table_name = self._finalize_table_name(query.model_class.destination_name())
        if not query.group_by:
            query_string = f"SELECT COUNT(*) AS count FROM {table_name}{joins}{wheres}"
        else:
            group_by = self.group_by_clause(query.group_by)
            query_string = (
                f"SELECT COUNT(*) AS count FROM (SELECT 1 FROM {table_name}{joins}{wheres}{group_by}) AS count_inner"
            )
        return (query_string, parameters)

    def conditions_as_wheres_and_parameters(
        self, conditions: list[Condition], default_table_name: str
    ) -> tuple[str, tuple[Any]]:
        if not conditions:
            return ("", ())  # type: ignore

        parameters = []
        where_parts = []
        for condition in conditions:
            parameters.extend(condition.values)
            table = condition.table_name if condition.table_name else self._finalize_table_name(default_table_name)
            column = condition.column_name
            where_parts.append(
                condition._with_placeholders(
                    f"{table}.{column}",
                    condition.operator,
                    condition.values,
                    escape=False,
                    placeholder=self.cursor.value_placeholder,
                )
            )
        return (" WHERE " + " AND ".join(where_parts), tuple(parameters))  # type: ignore

    def group_by_clause(self, group_by: str) -> str:
        if not group_by:
            return ""
        escape = self.cursor.column_escape_character
        if "." not in group_by:
            return f" GROUP BY {escape}{group_by}{escape}"
        parts = group_by.split(".", 1)
        table = parts[0]
        column = parts[1]
        return f" GROUP BY {escape}{table}{escape}.{escape}{column}{escape}"

    def validate_pagination_data(self, data: dict[str, Any], case_mapping: Callable) -> str:
        extra_keys = set(data.keys()) - set(self.allowed_pagination_keys())
        if len(extra_keys):
            key_name = case_mapping("start")
            return "Invalid pagination key(s): '" + "','".join(extra_keys) + f"'.  Only '{key_name}' is allowed"
        if "start" not in data:
            key_name = case_mapping("start")
            return f"You must specify '{key_name}' when setting pagination"
        start = data["start"]
        try:
            start = int(start)
        except:
            key_name = case_mapping("start")
            return f"Invalid pagination data: '{key_name}' must be a number"
        return ""

    def allowed_pagination_keys(self) -> list[str]:
        return ["start"]

    def documentation_pagination_next_page_response(self, case_mapping: Callable[[str], str]) -> list[Any]:
        return [AutoDocInteger(case_mapping("start"), example=0)]

    def documentation_pagination_next_page_example(self, case_mapping: Callable[[str], str]) -> dict[str, Any]:
        return {case_mapping("start"): 0}

    def documentation_pagination_parameters(
        self, case_mapping: Callable[[str], str]
    ) -> list[tuple[AutoDocSchema, str]]:
        return [
            (
                AutoDocInteger(case_mapping("start"), example=0),
                "The zero-indexed record number to start listing results from",
            )
        ]
