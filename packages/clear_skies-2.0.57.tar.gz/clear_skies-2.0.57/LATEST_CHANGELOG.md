## [2.0.57] - 2026-03-25

### Fixed
- Cors import

