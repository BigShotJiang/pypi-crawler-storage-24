from __future__ import annotations

import json
import os
from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table

from keynode import KeyNodeClient
from keynode.exceptions import KeynodeError

app = typer.Typer(help="KeyNode CLI")
run_app = typer.Typer(help="Manage runs")
auth_app = typer.Typer(help="Authentication")
dataset_app = typer.Typer(help="Manage datasets")
source_app = typer.Typer(help="Manage sources")
secret_app = typer.Typer(help="Manage secrets")
backup_app = typer.Typer(help="Manage backups")
gpu_app = typer.Typer(help="Browse GPU catalog")
apikey_app = typer.Typer(help="Manage API keys")

app.add_typer(run_app, name="run")
app.add_typer(auth_app, name="auth")
app.add_typer(dataset_app, name="dataset")
app.add_typer(source_app, name="source")
app.add_typer(secret_app, name="secret")
app.add_typer(backup_app, name="backup")
app.add_typer(gpu_app, name="gpu")
app.add_typer(apikey_app, name="apikey")

console = Console()
CONFIG_DIR = Path.home() / ".keynode"
CONFIG_FILE = CONFIG_DIR / "config.json"


def load_config() -> dict:
    if CONFIG_FILE.exists():
        return json.loads(CONFIG_FILE.read_text())
    return {}


def save_config(data: dict) -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(json.dumps(data, indent=2))


def get_client() -> KeyNodeClient:
    cfg = load_config()
    base_url = cfg.get("base_url") or os.getenv("KEYNODE_BASE_URL") or "https://api.keynode.es"
    api_key = cfg.get("api_key") or os.getenv("KEYNODE_API_KEY")

    if not api_key:
        raise typer.BadParameter("No API key configured. Run: keynode auth login")

    return KeyNodeClient(base_url=base_url, api_key=api_key)


@auth_app.command("login")
def auth_login(
    api_key: str = typer.Option(..., prompt=True, hide_input=True),
    base_url: str = typer.Option("https://api.keynode.es"),
):
    save_config({
        "api_key": api_key,
        "base_url": base_url,
    })
    console.print("[green]KeyNode API key saved.[/green]")


@auth_app.command("whoami")
def auth_whoami():
    try:
        with get_client() as client:
            client.runs.list()
            cfg = load_config()
            console.print("[green]KeyNode authentication OK[/green]")
            console.print(f"Base URL: {cfg.get('base_url')}")
            console.print("API key valid: yes")
    except Exception as e:
        console.print(f"[red]Authentication failed:[/red] {e}")
        raise typer.Exit(code=1)


@run_app.command("list")
def run_list():
    try:
        with get_client() as client:
            data = client.runs.list()
            rows = data.get("rows", [])

            table = Table(title="KeyNode Runs")
            table.add_column("Run ID")
            table.add_column("Name")
            table.add_column("Status")
            table.add_column("Image")

            for r in rows:
                table.add_row(
                    str(r.get("run_id")),
                    str(r.get("name") or "—"),
                    str(r.get("status") or "—"),
                    str(r.get("image") or "—"),
                )

            console.print(table)
    except KeynodeError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(code=1)


@run_app.command("get")
def run_get(run_id: int):
    try:
        with get_client() as client:
            data = client.runs.get(run_id)
            console.print_json(json.dumps(data))
    except KeynodeError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(code=1)


@run_app.command("cancel")
def run_cancel(run_id: int):
    try:
        with get_client() as client:
            data = client.runs.cancel(run_id)
            console.print_json(json.dumps(data))
    except KeynodeError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(code=1)


@run_app.command("retry")
def run_retry(run_id: int):
    try:
        with get_client() as client:
            data = client.runs.retry_now(run_id)
            console.print_json(json.dumps(data))
    except KeynodeError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(code=1)


@run_app.command("create")
def run_create(
    file: str = typer.Option(..., "--file", "-f", help="JSON payload file"),
):
    try:
        payload = json.loads(Path(file).read_text())

        with get_client() as client:
            data = client.runs.create(payload)
            console.print_json(json.dumps(data))
    except FileNotFoundError:
        console.print(f"[red]File not found: {file}[/red]")
        raise typer.Exit(code=1)
    except json.JSONDecodeError as e:
        console.print(f"[red]Invalid JSON in {file}: {e}[/red]")
        raise typer.Exit(code=1)
    except KeynodeError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(code=1)
    
@run_app.command("manifest")
def run_manifest(run_id: int):
    try:
        with get_client() as client:
            data = client.runs.manifest(run_id)
            console.print_json(json.dumps(data))
    except KeynodeError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(code=1)
    
@run_app.command("artifacts")
def run_artifacts(
    run_id: int,
    base: str = typer.Option("out", help="Artifact base path"),
):
    try:
        with get_client() as client:
            data = client.runs.artifacts(run_id, base=base)
            console.print_json(json.dumps(data))
    except KeynodeError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(code=1)
    
@run_app.command("download-manifest")
def run_download_manifest(
    run_id: int,
    output: str | None = typer.Option(None, "--output", "-o"),
):
    try:
        with get_client() as client:
            path = client.runs.download_manifest(run_id, output_path=output)
            console.print(f"[green]Manifest downloaded to:[/green] {path}")
    except KeynodeError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(code=1)
    
@run_app.command("resume")
def run_resume(run_id: int):
    try:
        with get_client() as client:
            data = client.runs.resume(run_id)
            console.print_json(json.dumps(data))
    except KeynodeError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(code=1)
    
@run_app.command("clone-retry")
def run_clone_retry(run_id: int):
    try:
        with get_client() as client:
            data = client.runs.clone_retry(run_id)
            console.print_json(json.dumps(data))
    except KeynodeError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(code=1)


@run_app.command("metrics")
def run_metrics(
    run_id: int,
    step: int = typer.Option(5, "--step", help="Aggregation step in seconds"),
):
    try:
        with get_client() as client:
            data = client.runs.metrics(run_id, step_s=step)
            console.print_json(json.dumps(data))
    except KeynodeError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(code=1)


@run_app.command("wait")
def run_wait(
    run_id: int,
    timeout: float | None = typer.Option(None, "--timeout", help="Max seconds to wait"),
    poll: float = typer.Option(5.0, "--poll", help="Poll interval in seconds"),
):
    """Wait until a run reaches a terminal state."""
    try:
        with get_client() as client:
            console.print(f"Waiting for run [bold]{run_id}[/bold]...")
            run = client.runs.wait(run_id, poll_interval=poll, timeout=timeout)
            status = run.get("status", "unknown")
            color = "green" if status == "completed" else "red"
            console.print(f"Run {run_id} finished with status: [{color}]{status}[/{color}]")
    except TimeoutError as e:
        console.print(f"[yellow]{e}[/yellow]")
        raise typer.Exit(code=1)
    except KeynodeError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(code=1)
    
@dataset_app.command("list")
def dataset_list():
    try:
        with get_client() as client:
            rows = client.datasets.list()

            table = Table(title="KeyNode Datasets")
            table.add_column("ID")
            table.add_column("Name")
            table.add_column("Original filename")
            table.add_column("Size")
            table.add_column("Created")

            for d in rows:
                table.add_row(
                    str(d.get("id", "—")),
                    str(d.get("name", "—")),
                    str(d.get("original_filename", "—")),
                    str(d.get("size_bytes", "—")),
                    str(d.get("created_at", "—")),
                )

            console.print(table)
    except KeynodeError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(code=1)

@dataset_app.command("upload")
def dataset_upload(
    file: str = typer.Argument(..., help="Path to dataset file"),
    name: str | None = typer.Option(None, "--name", "-n", help="Dataset name"),
):
    try:
        with get_client() as client:
            data = client.datasets.upload(file, dataset_name=name)
            console.print_json(json.dumps(data))
    except FileNotFoundError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(code=1)
    except KeynodeError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(code=1)

@dataset_app.command("download")
def dataset_download(
    dataset_id: int,
    output: str | None = typer.Option(None, "--output", "-o"),
):
    try:
        with get_client() as client:
            path = client.datasets.download(dataset_id, output_path=output)
            console.print(f"[green]Dataset downloaded to:[/green] {path}")
    except KeynodeError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(code=1)

@dataset_app.command("delete")
def dataset_delete(dataset_id: int):
    try:
        with get_client() as client:
            client.datasets.delete(dataset_id)
            console.print(f"[green]Dataset deleted:[/green] {dataset_id}")
    except KeynodeError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(code=1)

@source_app.command("list")
def source_list():
    try:
        with get_client() as client:
            rows = client.sources.list()

            table = Table(title="KeyNode Sources")
            table.add_column("ID")
            table.add_column("Filename")
            table.add_column("Size")
            table.add_column("Created")

            for s in rows:
                table.add_row(
                    str(s.get("id", "—")),
                    str(s.get("filename", "—")),
                    str(s.get("size_bytes", "—")),
                    str(s.get("created_at", "—")),
                )

            console.print(table)
    except KeynodeError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(code=1)
    
@source_app.command("upload")
def source_upload(
    file: str = typer.Argument(..., help="Path to source archive"),
):
    try:
        with get_client() as client:
            data = client.sources.upload(file)
            console.print_json(json.dumps(data))
    except FileNotFoundError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(code=1)
    except KeynodeError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(code=1)   

@source_app.command("delete")
def source_delete(source_id: int):
    try:
        with get_client() as client:
            client.sources.delete(source_id)
            console.print(f"[green]Source deleted:[/green] {source_id}")
    except KeynodeError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(code=1)
    
@run_app.command("download-artifacts")
def run_download_artifacts(
    run_id: int,
    output: str | None = typer.Option(None, "--output", "-o"),
    base: str = typer.Option("out", "--base", help="Artifact base path"),
):
    try:
        with get_client() as client:
            path = client.runs.download_artifacts(run_id, output_path=output, base=base)
            console.print(f"[green]Artifacts downloaded to:[/green] {path}")
    except KeynodeError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(code=1)

@secret_app.command("list")
def secret_list():
    try:
        with get_client() as client:
            rows = client.secrets.list()

            table = Table(title="KeyNode Secrets")
            table.add_column("ID")
            table.add_column("Name")
            table.add_column("Created")
            table.add_column("Updated")

            for s in rows:
                table.add_row(
                    str(s.get("id", "—")),
                    str(s.get("name", "—")),
                    str(s.get("created_at", "—")),
                    str(s.get("updated_at", "—")),
                )

            console.print(table)
    except KeynodeError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(code=1)

@secret_app.command("create")
def secret_create(
    name: str = typer.Option(..., "--name"),
    value: str = typer.Option(..., "--value", prompt=True, hide_input=True),
    description: str | None = typer.Option(None, "--description"),
):
    try:
        with get_client() as client:
            data = client.secrets.create(name=name, value=value, description=description)
            console.print_json(json.dumps(data))
    except KeynodeError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(code=1)

@secret_app.command("delete")
def secret_delete(secret_id: int):
    try:
        with get_client() as client:
            client.secrets.delete(secret_id)
            console.print(f"[green]Secret deleted:[/green] {secret_id}")
    except KeynodeError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(code=1)


# ---------------------------------------------------------------------------
# backup commands
# ---------------------------------------------------------------------------

@backup_app.command("list")
def backup_list(
    run_id: int | None = typer.Option(None, "--run-id", help="Filter by run ID"),
    status: str | None = typer.Option(None, "--status", help="Filter by status"),
):
    try:
        with get_client() as client:
            rows = client.backups.list(run_id=run_id, status=status)

            table = Table(title="KeyNode Backups")
            table.add_column("ID")
            table.add_column("Name")
            table.add_column("Run ID")
            table.add_column("Status")
            table.add_column("Size")
            table.add_column("Created")
            table.add_column("Expires")

            for b in rows:
                table.add_row(
                    str(b.get("id", "—")),
                    str(b.get("name") or "—"),
                    str(b.get("run_id") or "—"),
                    str(b.get("status") or "—"),
                    str(b.get("size_bytes") or "—"),
                    str(b.get("created_at") or "—"),
                    str(b.get("expires_at") or "—"),
                )

            console.print(table)
    except KeynodeError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(code=1)


@backup_app.command("delete")
def backup_delete(backup_id: int):
    try:
        with get_client() as client:
            client.backups.delete(backup_id)
            console.print(f"[green]Backup deleted:[/green] {backup_id}")
    except KeynodeError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(code=1)


# ---------------------------------------------------------------------------
# gpu commands
# ---------------------------------------------------------------------------

@gpu_app.command("list")
def gpu_list(
    region: str | None = typer.Option(None, "--region", help="Filter by region"),
    model: str | None = typer.Option(None, "--model", help="Filter by model name (partial match)"),
    min_vram: int | None = typer.Option(None, "--min-vram", help="Minimum VRAM in GB"),
    max_price: float | None = typer.Option(None, "--max-price", help="Maximum price per hour (€)"),
    audited: bool | None = typer.Option(None, "--audited/--no-audited", help="Filter by audited providers"),
):
    try:
        with get_client() as client:
            rows = client.gpu.list(
                region=region,
                gpu_model=model,
                min_vram=min_vram,
                max_price=max_price,
                audited=audited,
            )

            table = Table(title="KeyNode GPU Catalog")
            table.add_column("Model")
            table.add_column("VRAM")
            table.add_column("Available")
            table.add_column("Price/hr")
            table.add_column("Regions")
            table.add_column("DL Score")
            table.add_column("Tags")

            for g in rows:
                price = g.get("min_price_per_hour")
                table.add_row(
                    str(g.get("model", "—")),
                    f"{g.get('vram_gb', '?')} GB",
                    str(g.get("units_available", 0)),
                    f"€{price:.3f}" if price is not None else "—",
                    ", ".join(g.get("regions") or []),
                    str(g.get("dl_score", "—")),
                    ", ".join(g.get("tags") or []),
                )

            console.print(table)
    except KeynodeError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(code=1)


@gpu_app.command("stats")
def gpu_stats():
    try:
        with get_client() as client:
            data = client.gpu.stats()
            console.print_json(json.dumps(data))
    except KeynodeError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(code=1)


@gpu_app.command("detail")
def gpu_detail(
    model: str = typer.Argument(..., help="GPU model name"),
    vram_gb: int | None = typer.Option(None, "--vram", help="VRAM in GB"),
    region: str | None = typer.Option(None, "--region"),
):
    try:
        with get_client() as client:
            data = client.gpu.detail(model=model, vram_gb=vram_gb, region=region)
            console.print_json(json.dumps(data))
    except KeynodeError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(code=1)


# ---------------------------------------------------------------------------
# apikey commands
# ---------------------------------------------------------------------------

@apikey_app.command("list")
def apikey_list():
    try:
        with get_client() as client:
            rows = client.api_keys.list()

            table = Table(title="KeyNode API Keys")
            table.add_column("ID")
            table.add_column("Name")
            table.add_column("Prefix")
            table.add_column("Created")
            table.add_column("Last used")

            for k in rows:
                table.add_row(
                    str(k.get("api_key_id", "—")),
                    str(k.get("name", "—")),
                    str(k.get("key_prefix", "—")),
                    str(k.get("created_at", "—")),
                    str(k.get("last_used_at") or "never"),
                )

            console.print(table)
    except KeynodeError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(code=1)


@apikey_app.command("create")
def apikey_create(
    name: str = typer.Option(..., "--name", "-n", help="Descriptive name for the key"),
    expires_in_days: int | None = typer.Option(None, "--expires-in-days", help="Key expiry in days"),
):
    try:
        with get_client() as client:
            data = client.api_keys.create(name=name, expires_in_days=expires_in_days)
            console.print(f"[yellow]Save this key now — it will not be shown again:[/yellow]")
            console.print(f"\n  [bold green]{data.get('api_key')}[/bold green]\n")
            console.print(f"Name: {data.get('name')}  |  Prefix: {data.get('key_prefix')}  |  ID: {data.get('api_key_id')}")
    except KeynodeError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(code=1)


@apikey_app.command("revoke")
def apikey_revoke(api_key_id: int):
    try:
        with get_client() as client:
            client.api_keys.revoke(api_key_id)
            console.print(f"[green]API key revoked:[/green] {api_key_id}")
    except KeynodeError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(code=1)