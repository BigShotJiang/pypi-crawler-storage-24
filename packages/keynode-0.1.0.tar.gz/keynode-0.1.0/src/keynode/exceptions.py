class KeynodeError(Exception):
    """Base exception for KeyNode SDK."""


class KeynodeAuthError(KeynodeError):
    """Authentication/authorization error."""


class KeynodeApiError(KeynodeError):
    """Generic API error."""

    def __init__(self, status_code: int, message: str):
        self.status_code = status_code
        self.message = message
        super().__init__(f"[{status_code}] {message}")