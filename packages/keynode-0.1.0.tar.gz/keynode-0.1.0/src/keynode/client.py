from __future__ import annotations
from typing import Any
from pathlib import Path
import httpx, json
from .config import KeynodeConfig
from .exceptions import KeynodeApiError, KeynodeAuthError
from .resources.runs import RunsResource
from .resources.datasets import DatasetsResource
from .resources.sources import SourcesResource
from .resources.secrets import SecretsResource
from .resources.backups import BackupsResource
from .resources.gpu_catalog import GpuCatalogResource
from .resources.api_keys import ApiKeysResource
from .resources.me import MeResource

class KeyNodeClient:
    def __init__(
        self,
        *,
        base_url: str,
        api_key: str | None = None,
        timeout: float = 30.0,
    ):
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key
        self.timeout = timeout
        self._client = httpx.Client(
            base_url=self.base_url,
            timeout=self.timeout,
            headers=self._build_headers(),
            follow_redirects=True,
        )

        self.runs = RunsResource(self)
        self.datasets = DatasetsResource(self)
        self.sources = SourcesResource(self)
        self.secrets = SecretsResource(self)
        self.backups = BackupsResource(self)
        self.gpu = GpuCatalogResource(self)
        self.api_keys = ApiKeysResource(self)
        self.me = MeResource(self)

    @classmethod
    def from_env(cls) -> "KeyNodeClient":
        cfg = KeynodeConfig.from_env()
        return cls(base_url=cfg.base_url, api_key=cfg.api_key)

    def _build_headers(self) -> dict[str, str]:
        headers = {"Accept": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        return headers

    def close(self) -> None:
        self._client.close()

    def _handle_response(self, response: httpx.Response) -> Any:
        if response.status_code in (401, 403):
            raise KeynodeAuthError("Unauthorized. Check your KeyNode API key.")

        if response.status_code >= 400:
            try:
                payload = response.json()
                message = payload.get("detail") or payload.get("error") or response.text
            except Exception:
                message = response.text
            raise KeynodeApiError(response.status_code, message)

        if not response.content:
            return None

        content_type = response.headers.get("content-type", "")
        if "application/json" in content_type:
            return response.json()

        return response.content

    def get(self, path: str, params: dict[str, Any] | None = None) -> Any:
        resp = self._client.get(path, params=params)
        return self._handle_response(resp)

    def post(self, path: str, json_body: dict[str, Any] | None = None) -> Any:
        resp = self._client.post(path, json=json_body)
        return self._handle_response(resp)

    def delete(self, path: str) -> Any:
        resp = self._client.delete(path)
        return self._handle_response(resp)
    
    def post_multipart(
        self,
        path: str,
        *,
        data: dict[str, Any] | None = None,
        files: dict[str, Any] | None = None,
    ) -> Any:
        resp = self._client.post(path, data=data, files=files)
        return self._handle_response(resp)
    
    def download_file(
        self,
        path: str,
        output_path: str,
        params: dict[str, Any] | None = None,
    ) -> str:
        with self._client.stream("GET", path, params=params) as resp:
            if resp.status_code in (401, 403):
                raise KeynodeAuthError("Unauthorized. Check your KeyNode API key.")

            if resp.status_code >= 400:
                try:
                    payload = resp.json()
                    message = payload.get("detail") or payload.get("error") or str(payload)
                except Exception:
                    message = resp.text
                raise KeynodeApiError(resp.status_code, message)

            out = Path(output_path)
            with out.open("wb") as f:
                for chunk in resp.iter_bytes():
                    f.write(chunk)

        return str(out)

    def to_pretty_json(self, data: Any) -> str:
        return json.dumps(data, indent=2, ensure_ascii=False)

    def __enter__(self) -> "KeyNodeClient":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()