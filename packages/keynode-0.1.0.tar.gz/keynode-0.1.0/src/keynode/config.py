from dataclasses import dataclass
import os


@dataclass
class KeynodeConfig:
    base_url: str
    api_key: str | None = None

    @classmethod
    def from_env(cls) -> "KeynodeConfig":
        return cls(
            base_url=os.getenv("KEYNODE_BASE_URL", "https://api.keynode.es"),
            api_key=os.getenv("KEYNODE_API_KEY"),
        )