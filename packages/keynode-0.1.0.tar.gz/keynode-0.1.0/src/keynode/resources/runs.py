from __future__ import annotations
from typing import Any
from pathlib import Path
import time


TERMINAL_STATUSES = {"completed", "failed", "cancelled", "error"}


class RunsResource:
    def __init__(self, client):
        self._client = client

    def list(self) -> dict[str, Any]:
        return self._client.get("/runs/")

    def get(self, run_id: int) -> dict[str, Any]:
        return self._client.get(f"/runs/{run_id}")

    def create(self, payload: dict[str, Any]) -> dict[str, Any]:
        return self._client.post("/runs", json_body=payload)

    def cancel(self, run_id: int) -> dict[str, Any]:
        return self._client.post(f"/runs/{run_id}/cancel", json_body={})

    def retry_now(self, run_id: int) -> dict[str, Any]:
        return self._client.post(f"/runs/{run_id}/retry-now", json_body={})

    def clone_retry(self, run_id: int) -> dict[str, Any]:
        return self._client.post(f"/runs/{run_id}/clone-retry", json_body={})

    def resume(self, run_id: int) -> dict[str, Any]:
        return self._client.post(f"/runs/{run_id}/resume", json_body={})

    def manifest(self, run_id: int) -> dict[str, Any]:
        return self._client.get(f"/runs/{run_id}/manifest")

    def artifacts(self, run_id: int, base: str = "out") -> dict[str, Any]:
        return self._client.get(f"/runs/{run_id}/artifacts", params={"base": base})

    def download_manifest(self, run_id: int, output_path: str | None = None) -> str:
        content = self._client.get(f"/runs/{run_id}/manifest/download")
        filename = output_path or f"run-{run_id}-manifest.json"
        Path(filename).write_bytes(content if isinstance(content, bytes) else str(content).encode("utf-8"))
        return filename

    def download_artifacts(
        self,
        run_id: int,
        output_path: str | None = None,
        base: str = "out",
    ) -> str:
        if output_path is None:
            output_path = f"run-{run_id}-artifacts.tar.gz"

        path = self._client.download_file(
            f"/runs/{run_id}/artifacts/download-tar",
            output_path=output_path,
            params={"base": base},
        )
        return path

    def metrics(
        self,
        run_id: int,
        step_s: int = 5,
    ) -> dict[str, Any]:
        """
        Returns CPU, memory, GPU utilization, VRAM, power and temperature
        time-series for the run. Useful for debugging and cost analysis.
        """
        return self._client.get(f"/runs/{run_id}/metrics", params={"step_s": step_s})

    def wait(
        self,
        run_id: int,
        poll_interval: float = 5.0,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """
        Polls the run until it reaches a terminal state (completed, failed, cancelled).
        Returns the final run dict.

        Raises TimeoutError if timeout (seconds) is exceeded.
        """
        start = time.monotonic()
        while True:
            run = self.get(run_id)
            status = run.get("status", "")
            if status in TERMINAL_STATUSES:
                return run
            if timeout is not None and (time.monotonic() - start) >= timeout:
                raise TimeoutError(
                    f"Run {run_id} did not finish within {timeout}s (current status: {status})"
                )
            time.sleep(poll_interval)