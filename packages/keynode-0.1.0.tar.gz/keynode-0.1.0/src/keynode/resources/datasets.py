from __future__ import annotations

from pathlib import Path
from typing import Any


class DatasetsResource:
    def __init__(self, client):
        self._client = client

    def list(self) -> list[dict[str, Any]]:
        data = self._client.get("/datasets/")
        if isinstance(data, dict):
            if "datasets" in data:
                return data["datasets"]
            if "items" in data:
                return data["items"]
        return data if isinstance(data, list) else []

    def upload(self, path: str, dataset_name: str | None = None) -> dict[str, Any]:
        file_path = Path(path)
        if not file_path.exists():
            raise FileNotFoundError(f"Dataset file not found: {path}")

        name = dataset_name or file_path.stem

        with file_path.open("rb") as f:
            return self._client.post_multipart(
                "/datasets/upload",
                data={"dataset_name": name},
                files={"file": (file_path.name, f)},
            )

    def delete(self, dataset_id: int) -> dict[str, Any] | None:
        return self._client.delete(f"/datasets/{dataset_id}")

    def download(self, dataset_id: int, output_path: str | None = None) -> str:
        content = self._client.get(f"/datasets/{dataset_id}/download")

        filename = output_path or f"dataset-{dataset_id}"
        Path(filename).write_bytes(content if isinstance(content, bytes) else bytes(content))
        return filename