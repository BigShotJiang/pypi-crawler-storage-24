from __future__ import annotations
from typing import Any


class GpuCatalogResource:
    def __init__(self, client):
        self._client = client

    def list(
        self,
        region: str | None = None,
        gpu_model: str | None = None,
        audited: bool | None = None,
        max_price: float | None = None,
        min_vram: int | None = None,
        limit: int = 100,
        offset: int = 0,
    ) -> list[dict[str, Any]]:
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if region is not None:
            params["region"] = region
        if gpu_model is not None:
            params["gpu_model"] = gpu_model
        if audited is not None:
            params["audited"] = audited
        if max_price is not None:
            params["max_price"] = max_price
        if min_vram is not None:
            params["min_vram"] = min_vram
        return self._client.get("/gpu-catalog", params=params)

    def stats(self) -> dict[str, Any]:
        return self._client.get("/gpu-catalog/stats")

    def detail(
        self,
        model: str,
        vram_gb: int | None = None,
        region: str | None = None,
        audited: bool | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"model": model}
        if vram_gb is not None:
            params["vram_gb"] = vram_gb
        if region is not None:
            params["region"] = region
        if audited is not None:
            params["audited"] = audited
        return self._client.get("/gpu-catalog/detail", params=params)
