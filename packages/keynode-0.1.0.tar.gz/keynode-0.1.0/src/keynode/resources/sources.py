from __future__ import annotations

from pathlib import Path
from typing import Any


class SourcesResource:
    def __init__(self, client):
        self._client = client

    def list(self) -> list[dict[str, Any]]:
        data = self._client.get("/sources/")
        if isinstance(data, dict):
            if "items" in data:
                return data["items"]
            if "sources" in data:
                return data["sources"]
        return data if isinstance(data, list) else []

    def upload(self, path: str) -> dict[str, Any]:
        file_path = Path(path)
        if not file_path.exists():
            raise FileNotFoundError(f"Source file not found: {path}")

        with file_path.open("rb") as f:
            return self._client.post_multipart(
                "/sources/upload",
                files={"file": (file_path.name, f)},
            )

    def delete(self, source_id: int) -> dict[str, Any] | None:
        return self._client.delete(f"/sources/{source_id}")

    def presign(self, source_id: int) -> dict[str, Any]:
        return self._client.post(f"/sources/{source_id}/presign", json_body={})