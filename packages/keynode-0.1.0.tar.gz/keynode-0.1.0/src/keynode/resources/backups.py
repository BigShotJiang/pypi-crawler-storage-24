from __future__ import annotations
from typing import Any


class BackupsResource:
    def __init__(self, client):
        self._client = client

    def list(
        self,
        run_id: int | None = None,
        status: str | None = None,
        limit: int = 200,
    ) -> list[dict[str, Any]]:
        params: dict[str, Any] = {"limit": limit}
        if run_id is not None:
            params["run_id"] = run_id
        if status is not None:
            params["status"] = status
        return self._client.get("/backups/", params=params)

    def delete(self, backup_id: int) -> dict[str, Any]:
        return self._client.delete(f"/backups/{backup_id}")
