from __future__ import annotations
from typing import Any


class ApiKeysResource:
    """
    Manage API keys for programmatic access.

    Note: these endpoints require Supabase JWT authentication (user session token),
    not an API key. Support for API key auth on these endpoints is planned.
    """

    def __init__(self, client):
        self._client = client

    def list(self) -> list[dict[str, Any]]:
        return self._client.get("/api-keys/")

    def create(self, name: str, expires_in_days: int | None = None) -> dict[str, Any]:
        """
        Creates a new API key. The raw key is returned only once — save it immediately.
        """
        body: dict[str, Any] = {"name": name}
        if expires_in_days is not None:
            body["expires_in_days"] = expires_in_days
        return self._client.post("/api-keys/", json_body=body)

    def revoke(self, api_key_id: int) -> dict[str, Any]:
        return self._client.delete(f"/api-keys/{api_key_id}")
