from __future__ import annotations
from typing import Any


class MeResource:
    """
    User profile and platform summary.

    Note: get() requires Supabase JWT authentication (user session token).
    summary() is public and accessible without authentication.
    """

    def __init__(self, client):
        self._client = client

    def get(self) -> dict[str, Any]:
        """Returns user profile: user_id, email, full_name, role."""
        return self._client.get("/me")

    def summary(self) -> dict[str, Any]:
        """Returns platform-wide stats: providers_total, gpus_available, audited_pct, uptime_7d_avg."""
        return self._client.get("/summary")
