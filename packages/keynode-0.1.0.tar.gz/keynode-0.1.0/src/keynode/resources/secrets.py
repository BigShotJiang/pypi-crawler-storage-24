from __future__ import annotations

from typing import Any


class SecretsResource:
    def __init__(self, client):
        self._client = client

    def list(self) -> list[dict[str, Any]]:
        data = self._client.get("/secrets/")
        if isinstance(data, dict):
            if "secrets" in data:
                return data["secrets"]
            if "items" in data:
                return data["items"]
        return data if isinstance(data, list) else []

    def create(self, name: str, value: str, description: str | None = None) -> dict[str, Any]:
        payload = {
            "name": name,
            "value": value,
            "description": description,
        }
        return self._client.post("/secrets/", json_body=payload)

    def delete(self, secret_id: int) -> dict[str, Any] | None:
        return self._client.delete(f"/secrets/{secret_id}")