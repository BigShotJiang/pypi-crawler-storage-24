.. include:: upgrade.rst.inc

Examples
~~~~~~~~
::

    # Upgrade the borg repository to the most recent version.
    $ borg upgrade -v /path/to/repo
    making a hardlink copy in /path/to/repo.before-upgrade-2016-02-15-20:51:55
    opening attic repository with borg and converting
    no key file found for repository
    converting repo index /path/to/repo/index.0
    converting 1 segments...
    converting borg 0.xx to borg current
    no key file found for repository

.. _borg_key_migrate-to-repokey:

Upgrading a passphrase-encrypted Attic repo
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Attic offered a "passphrase" encryption mode, but this was removed in Borg 1.0
and replaced by the "repokey" mode (which stores the passphrase-protected
encryption key in the repository config).

Thus, to upgrade a "passphrase" Attic repo to a "repokey" Borg repo, two steps
are needed, in this order:

- borg upgrade repo
- borg key migrate-to-repokey repo
