#! /usr/bin/env python
# -*- coding: utf-8 -*-
# tests/test_cli_bom.py
"""Tests for the add-to-bom and get-bom commands."""

from contextlib import contextmanager

import pytest
import requests
from typer.testing import CliRunner

from gladiator.cli import app


@pytest.fixture(autouse=True)
def _clear_login_env(monkeypatch):
    """Ensure arena login env vars never leak into tests."""
    monkeypatch.delenv("GLADIATOR_USERNAME", raising=False)
    monkeypatch.delenv("GLADIATOR_PASSWORD", raising=False)


@contextmanager
def _noop_spinner(*_args, **_kwargs):
    yield


# ---------------------------------------------------------------------------
# add-to-bom
# ---------------------------------------------------------------------------


def test_add_to_bom_cli_create(monkeypatch):
    runner = CliRunner()

    class DummyClient:
        def __init__(self):
            self.calls = []

        def add_or_update_bom_line(self, **kwargs):
            self.calls.append(kwargs)
            return {
                "action": "created",
                "line": {
                    "item": {"number": kwargs["child_item_number"]},
                    "quantity": kwargs.get("quantity", 1),
                    "refDes": kwargs.get("ref_des"),
                    "notes": kwargs.get("notes"),
                },
            }

    dummy = DummyClient()

    monkeypatch.setattr("gladiator.cli._client", lambda: dummy)
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(
        app,
        [
            "add-to-bom",
            "ASM-100",
            "510-0001",
            "--qty",
            "2",
            "--refdes",
            "R5",
        ],
    )

    assert result.exit_code == 0
    assert dummy.calls == [
        {
            "parent_item_number": "ASM-100",
            "child_item_number": "510-0001",
            "parent_revision": "WORKING",
            "child_revision": None,
            "quantity": 2.0,
            "ref_des": "R5",
            "notes": None,
        }
    ]
    assert "BOM line created" in result.stdout
    assert "qty 2.0" in result.stdout


def test_add_to_bom_cli_json(monkeypatch):
    runner = CliRunner()

    class DummyClient:
        def __init__(self):
            self.calls = []

        def add_or_update_bom_line(self, **kwargs):
            self.calls.append(kwargs)
            return {"action": "updated", "line": {"guid": "LINE-1"}}

    dummy = DummyClient()

    monkeypatch.setattr("gladiator.cli._client", lambda: dummy)
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(
        app,
        [
            "add-to-bom",
            "--format",
            "json",
            "ASM-100",
            "510-0001",
        ],
    )

    assert result.exit_code == 0
    assert '"action": "updated"' in result.stdout
    assert dummy.calls[0]["quantity"] is None


def test_add_to_bom_cli_http_error(monkeypatch):
    runner = CliRunner()

    class DummyClient:
        def add_or_update_bom_line(self, **_kwargs):
            raise requests.HTTPError("boom")

    monkeypatch.setattr("gladiator.cli._client", lambda: DummyClient())
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(app, ["add-to-bom", "ASM-100", "510-0002"])

    assert result.exit_code == 2
    assert "Arena request failed" in result.stderr


def test_add_to_bom_cli_arena_error(monkeypatch):
    runner = CliRunner()

    class DummyClient:
        def add_or_update_bom_line(self, **_kwargs):
            from gladiator.arena import ArenaError

            raise ArenaError("cannot update BOM")

    monkeypatch.setattr("gladiator.cli._client", lambda: DummyClient())
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(app, ["add-to-bom", "ASM-100", "510-0003"])

    assert result.exit_code == 2
    assert "cannot update BOM" in result.stderr


# ---------------------------------------------------------------------------
# get-bom
# ---------------------------------------------------------------------------


def test_bom_table(monkeypatch):
    runner = CliRunner()

    class DummyClient:
        def get_bom(self, item, revision, recursive, max_depth):
            assert recursive is False
            assert max_depth is None
            return [
                {
                    "lineNumber": 1,
                    "quantity": 2,
                    "itemNumber": "510-CH-A",
                    "itemName": "Child A",
                    "refDes": "R1",
                    "level": 0,
                }
            ]

    monkeypatch.setattr("gladiator.cli._client", lambda: DummyClient())
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(app, ["get-bom", "510-0009"])

    assert result.exit_code == 0
    assert "510-CH-A" in result.stdout
    assert "Child A" in result.stdout


def test_bom_json(monkeypatch):
    runner = CliRunner()

    class DummyClient:
        def get_bom(self, item, revision, recursive, max_depth):
            assert recursive is True
            assert max_depth == 2
            return []

    monkeypatch.setattr("gladiator.cli._client", lambda: DummyClient())
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(
        app,
        [
            "get-bom",
            "510-0010",
            "--rev",
            "WORKING",
            "--output",
            "json",
            "--recursive",
            "--max-depth",
            "2",
        ],
    )

    assert result.exit_code == 0
    assert result.stdout.strip() == '{\n  "count": 0,\n  "results": []\n}'


def test_bom_http_error(monkeypatch):
    runner = CliRunner()

    class DummyClient:
        def get_bom(self, item, revision, recursive, max_depth):
            raise requests.HTTPError("boom")

    monkeypatch.setattr("gladiator.cli._client", lambda: DummyClient())
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(app, ["get-bom", "510-0011"])

    assert result.exit_code == 2
    assert "Arena request failed" in result.stderr


def test_bom_arena_error(monkeypatch):
    runner = CliRunner()

    class DummyClient:
        def get_bom(self, item, revision, recursive, max_depth):
            from gladiator.arena import ArenaError

            raise ArenaError("bad bom")

    monkeypatch.setattr("gladiator.cli._client", lambda: DummyClient())
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(app, ["get-bom", "510-0012"])

    assert result.exit_code == 2
    assert "bad bom" in result.stderr
