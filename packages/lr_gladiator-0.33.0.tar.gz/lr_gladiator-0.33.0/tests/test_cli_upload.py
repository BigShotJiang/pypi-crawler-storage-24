#! /usr/bin/env python
# -*- coding: utf-8 -*-
# tests/test_cli_upload.py
"""Tests for the upload-weblink and upload-file commands."""

from contextlib import contextmanager

import pytest
import requests
from typer.testing import CliRunner

from gladiator.cli import app


@pytest.fixture(autouse=True)
def _clear_login_env(monkeypatch):
    """Ensure arena login env vars never leak into tests."""
    monkeypatch.delenv("GLADIATOR_USERNAME", raising=False)
    monkeypatch.delenv("GLADIATOR_PASSWORD", raising=False)


@contextmanager
def _noop_spinner(*_args, **_kwargs):
    yield


# ---------------------------------------------------------------------------
# upload-weblink
# ---------------------------------------------------------------------------


def test_upload_weblink_truncates_edition(monkeypatch):
    runner = CliRunner()
    captured = {}

    class DummyClient:
        def upload_weblink_to_working(self, **kwargs):
            captured.update(kwargs)
            return {"ok": True}

    monkeypatch.setattr("gladiator.cli._client", lambda: DummyClient())

    long_edition = "x" * 40
    result = runner.invoke(
        app,
        [
            "upload-weblink",
            "510-0001",
            "https://example.com/resource",
            "--edition",
            long_edition,
        ],
    )

    assert result.exit_code == 0
    assert captured["edition"] == long_edition[:16]


def test_upload_weblink_http_error(monkeypatch):
    runner = CliRunner()

    class DummyClient:
        def upload_weblink_to_working(self, **kwargs):
            raise requests.HTTPError("boom")

    monkeypatch.setattr("gladiator.cli._client", lambda: DummyClient())
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(
        app,
        ["upload-weblink", "510-0001", "https://example.com/resource"],
    )

    assert result.exit_code == 2
    assert "Arena request failed" in result.stderr


def test_upload_weblink_arena_error(monkeypatch):
    runner = CliRunner()

    class DummyClient:
        def upload_weblink_to_working(self, **kwargs):
            from gladiator.arena import ArenaError

            raise ArenaError("web upload blocked")

    monkeypatch.setattr("gladiator.cli._client", lambda: DummyClient())
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(
        app,
        ["upload-weblink", "510-0001", "https://example.com/resource"],
    )

    assert result.exit_code == 2
    assert "web upload blocked" in result.stderr


# ---------------------------------------------------------------------------
# upload-file
# ---------------------------------------------------------------------------


def test_upload_file_truncates_edition(monkeypatch, tmp_path):
    runner = CliRunner()
    captured = {}

    class DummyClient:
        def upload_file_to_working(self, item, file_path, reference, **kwargs):
            captured.update(kwargs)
            return {"ok": True}

    monkeypatch.setattr("gladiator.cli._client", lambda: DummyClient())

    dummy = tmp_path / "firmware.bin"
    dummy.write_text("hi")

    long_edition = "ABCDEF0123456789ZYXWV"  # 21 chars
    result = runner.invoke(
        app,
        [
            "upload-file",
            "510-0001",
            str(dummy),
            "--edition",
            long_edition,
        ],
    )

    assert result.exit_code == 0
    assert captured["edition"] == long_edition[:16]


def test_upload_file_http_error(monkeypatch, tmp_path):
    runner = CliRunner()

    class DummyClient:
        def upload_file_to_working(self, *args, **kwargs):
            raise requests.HTTPError("boom")

    dummy = tmp_path / "fw.bin"
    dummy.write_text("x")

    monkeypatch.setattr("gladiator.cli._client", lambda: DummyClient())
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(app, ["upload-file", "510-0001", str(dummy)])

    assert result.exit_code == 2
    assert "Arena request failed" in result.stderr


def test_upload_file_arena_error(monkeypatch, tmp_path):
    runner = CliRunner()

    class DummyClient:
        def upload_file_to_working(self, *args, **kwargs):
            from gladiator.arena import ArenaError

            raise ArenaError("upload blocked")

    dummy = tmp_path / "fw.bin"
    dummy.write_text("x")

    monkeypatch.setattr("gladiator.cli._client", lambda: DummyClient())
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(app, ["upload-file", "510-0001", str(dummy)])

    assert result.exit_code == 2
    assert "upload blocked" in result.stderr
