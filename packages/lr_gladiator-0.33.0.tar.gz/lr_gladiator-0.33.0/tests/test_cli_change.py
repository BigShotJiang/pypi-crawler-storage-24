#! /usr/bin/env python
# -*- coding: utf-8 -*-
# tests/test_cli_change.py
"""Tests for the get-change, add-to-change, submit-change, and create-change commands."""

import json
from contextlib import contextmanager

import pytest
import requests
from typer.testing import CliRunner

from gladiator.cli import app


@pytest.fixture(autouse=True)
def _clear_login_env(monkeypatch):
    """Ensure arena login env vars never leak into tests."""
    monkeypatch.delenv("GLADIATOR_USERNAME", raising=False)
    monkeypatch.delenv("GLADIATOR_PASSWORD", raising=False)


@contextmanager
def _noop_spinner(*_args, **_kwargs):
    yield


# ---------------------------------------------------------------------------
# get-change
# ---------------------------------------------------------------------------


def test_get_change_cli_success(monkeypatch):
    runner = CliRunner()

    class DummyChangeClient:
        def __init__(self):
            self.calls = []

        def get_change_items(self, *, change_number):
            self.calls.append(change_number)
            return {
                "count": 1,
                "results": [
                    {
                        "affectedItemRevision": {
                            "number": "510-0001",
                            "revisionNumber": "A",
                        },
                        "newRevisionNumber": "B",
                        "dispositionAttributes": [
                            {"name": "In Stock", "value": "Use"},
                            {"name": "WIP", "value": None},
                        ],
                        "notes": "Review",
                        "bomView": {"includedInThisChange": True},
                        "specsView": {"includedInThisChange": False},
                        "filesView": {"includedInThisChange": True},
                        "sourcingView": {"includedInThisChange": False},
                        "costView": {"includedInThisChange": True},
                    }
                ],
            }

    dummy = DummyChangeClient()

    monkeypatch.setattr("gladiator.cli._change_client", lambda: dummy)
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(app, ["get-change", "CCO-0006"])

    assert result.exit_code == 0
    assert dummy.calls == ["CCO-0006"]
    assert "Affected items for CCO-0006" in result.stdout
    assert "BOM" in result.stdout
    assert result.stdout.count("*") >= 3


def test_get_change_cli_json_format(monkeypatch):
    runner = CliRunner()

    class DummyChangeClient:
        def get_change_items(self, *, change_number):
            return {"count": 2, "results": []}

    monkeypatch.setattr("gladiator.cli._change_client", lambda: DummyChangeClient())
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(app, ["get-change", "--format", "json", "CCO-0009"])

    assert result.exit_code == 0
    assert '{\n  "count": 2' in result.stdout


def test_get_change_cli_http_error(monkeypatch):
    runner = CliRunner()

    class DummyChangeClient:
        def get_change_items(self, **_kwargs):
            raise requests.HTTPError("boom")

    monkeypatch.setattr("gladiator.cli._change_client", lambda: DummyChangeClient())
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(app, ["get-change", "CCO-0007"])

    assert result.exit_code == 2
    assert "Arena request failed" in result.stderr


def test_get_change_cli_arena_error(monkeypatch):
    runner = CliRunner()

    class DummyChangeClient:
        def get_change_items(self, **_kwargs):
            from gladiator.arena import ArenaError

            raise ArenaError("cannot fetch")

    monkeypatch.setattr("gladiator.cli._change_client", lambda: DummyChangeClient())
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(app, ["get-change", "CCO-0008"])

    assert result.exit_code == 2
    assert "cannot fetch" in result.stderr


# ---------------------------------------------------------------------------
# add-to-change
# ---------------------------------------------------------------------------


def test_add_to_change_cli_success(monkeypatch):
    runner = CliRunner()

    class DummyChangeClient:
        def __init__(self):
            self.add_calls = []
            self.get_calls = []

        def add_item_to_change(
            self,
            *,
            change_number,
            item_number,
            new_revision=None,
            lifecycle_phase=None,
        ):
            self.add_calls.append(
                {
                    "change": change_number,
                    "item": item_number,
                    "new_revision": new_revision,
                    "lifecycle_phase": lifecycle_phase,
                }
            )
            return {"status": "ok"}

        def get_change_items(self, *, change_number):
            self.get_calls.append(change_number)
            return {
                "results": [
                    {
                        "affectedItemRevision": {
                            "number": "510-0001",
                            "revisionNumber": "A",
                        },
                        "newRevisionNumber": "B",
                        "notes": "Added",
                        "bomView": {"includedInThisChange": True},
                        "specsView": {"includedInThisChange": False},
                        "filesView": {"includedInThisChange": True},
                        "sourcingView": {"includedInThisChange": False},
                        "costView": {"includedInThisChange": False},
                    }
                ]
            }

    dummy = DummyChangeClient()

    monkeypatch.setattr("gladiator.cli._change_client", lambda: dummy)
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(
        app,
        [
            "add-to-change",
            "--change",
            "CCO-0003",
            "510-0001",
        ],
    )

    assert result.exit_code == 0
    assert dummy.add_calls == [
        {
            "change": "CCO-0003",
            "item": "510-0001",
            "new_revision": None,
            "lifecycle_phase": "In Production",
        }
    ]
    assert dummy.get_calls == ["CCO-0003"]
    assert "Affected items for CCO-0003" in result.stdout
    assert "┏" in result.stdout


def test_add_to_change_cli_custom_options(monkeypatch):
    runner = CliRunner()

    class DummyChangeClient:
        def __init__(self):
            self.add_calls = []
            self.get_calls = []

        def add_item_to_change(
            self,
            *,
            change_number,
            item_number,
            new_revision=None,
            lifecycle_phase=None,
        ):
            self.add_calls.append(
                {
                    "change": change_number,
                    "item": item_number,
                    "new_revision": new_revision,
                    "lifecycle_phase": lifecycle_phase,
                }
            )
            return {"status": "ok"}

        def get_change_items(self, *, change_number):
            self.get_calls.append(change_number)
            return {"results": []}

    dummy = DummyChangeClient()

    monkeypatch.setattr("gladiator.cli._change_client", lambda: dummy)
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(
        app,
        [
            "add-to-change",
            "--change",
            "CCO-0010",
            "--new-revision",
            "1.2.3",
            "--lifecycle-phase",
            "Pilot",
            "510-0009",
        ],
    )

    assert result.exit_code == 0
    assert dummy.add_calls == [
        {
            "change": "CCO-0010",
            "item": "510-0009",
            "new_revision": "1.2.3",
            "lifecycle_phase": "Pilot",
        }
    ]
    assert dummy.get_calls == ["CCO-0010"]


def test_add_to_change_cli_http_error(monkeypatch):
    runner = CliRunner()

    class DummyChangeClient:
        def add_item_to_change(self, **_kwargs):
            raise requests.HTTPError("boom")

    monkeypatch.setattr("gladiator.cli._change_client", lambda: DummyChangeClient())
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(
        app,
        [
            "add-to-change",
            "--change",
            "CCO-0004",
            "510-0002",
        ],
    )

    assert result.exit_code == 2
    assert "Arena request failed" in result.stderr


def test_add_to_change_cli_arena_error(monkeypatch):
    runner = CliRunner()

    class DummyChangeClient:
        def add_item_to_change(self, **_kwargs):
            from gladiator.arena import ArenaError

            raise ArenaError("cannot add")

    monkeypatch.setattr("gladiator.cli._change_client", lambda: DummyChangeClient())
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(
        app,
        [
            "add-to-change",
            "--change",
            "CCO-0005",
            "510-0003",
        ],
    )

    assert result.exit_code == 2
    assert "cannot add" in result.stderr


def test_add_to_change_cli_json_format(monkeypatch):
    runner = CliRunner()

    class DummyChangeClient:
        def add_item_to_change(self, **_kwargs):
            return {"status": "ok"}

        def get_change_items(self, **_kwargs):
            raise AssertionError("should not fetch change items in json mode")

    monkeypatch.setattr("gladiator.cli._change_client", lambda: DummyChangeClient())
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(
        app,
        [
            "add-to-change",
            "--change",
            "CCO-0011",
            "--format",
            "json",
            "510-0011",
        ],
    )

    assert result.exit_code == 0
    assert '"status"' in result.stdout


def test_add_to_change_cli_null_revision(monkeypatch):
    runner = CliRunner()

    class DummyChangeClient:
        def __init__(self):
            self.add_calls = []

        def add_item_to_change(
            self,
            *,
            change_number,
            item_number,
            new_revision=None,
            lifecycle_phase=None,
        ):
            self.add_calls.append(
                {
                    "change": change_number,
                    "item": item_number,
                    "new_revision": new_revision,
                    "lifecycle_phase": lifecycle_phase,
                }
            )
            return {"status": "ok"}

        def get_change_items(self, *, change_number):
            return {"results": []}

    dummy = DummyChangeClient()

    monkeypatch.setattr("gladiator.cli._change_client", lambda: dummy)
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(
        app,
        [
            "add-to-change",
            "--change",
            "CCO-0020",
            "--format",
            "json",
            "510-0020",
        ],
    )

    assert result.exit_code == 0
    assert dummy.add_calls == [
        {
            "change": "CCO-0020",
            "item": "510-0020",
            "new_revision": None,
            "lifecycle_phase": "In Production",
        }
    ]
    assert json.loads(result.stdout) == {"status": "ok"}


# ---------------------------------------------------------------------------
# submit-change
# ---------------------------------------------------------------------------


def test_submit_change_cli_success(monkeypatch):
    runner = CliRunner()

    class DummyChangeClient:
        def __init__(self):
            self.calls = []

        def submit_change(
            self,
            *,
            change_number,
            status,
            comment=None,
            administrators=None,
        ):
            self.calls.append(
                {
                    "change_number": change_number,
                    "status": status,
                    "comment": comment,
                    "administrators": administrators,
                }
            )
            return {"change": {"number": change_number}, "status": "SUBMITTED"}

    dummy = DummyChangeClient()

    monkeypatch.setattr("gladiator.cli._change_client", lambda: dummy)
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(
        app,
        ["submit-change", "ECO-0100", "--status", "submitted", "--comment", "Ready"],
    )

    assert result.exit_code == 0
    assert dummy.calls == [
        {
            "change_number": "ECO-0100",
            "status": "submitted",
            "comment": "Ready",
            "administrators": None,
        }
    ]
    assert "Change ECO-0100 status set to SUBMITTED" in result.stdout


def test_submit_change_cli_json(monkeypatch):
    runner = CliRunner()

    class DummyChangeClient:
        def submit_change(self, **_kwargs):
            return {"ok": True}

    monkeypatch.setattr("gladiator.cli._change_client", lambda: DummyChangeClient())
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(
        app,
        [
            "submit-change",
            "ECO-0101",
            "--format",
            "json",
        ],
    )

    assert result.exit_code == 0
    assert '"ok": true' in result.stdout


def test_submit_change_cli_http_error(monkeypatch):
    runner = CliRunner()

    class DummyChangeClient:
        def submit_change(self, **_kwargs):
            raise requests.HTTPError("boom")

    monkeypatch.setattr("gladiator.cli._change_client", lambda: DummyChangeClient())
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(app, ["submit-change", "ECO-0102"])

    assert result.exit_code == 2
    assert "Arena request failed" in result.stderr


def test_submit_change_cli_arena_error(monkeypatch):
    runner = CliRunner()

    class DummyChangeClient:
        def submit_change(self, **_kwargs):
            from gladiator.arena import ArenaError

            raise ArenaError("cannot submit")

    monkeypatch.setattr("gladiator.cli._change_client", lambda: DummyChangeClient())
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(app, ["submit-change", "ECO-0103"])

    assert result.exit_code == 2
    assert "cannot submit" in result.stderr


# ---------------------------------------------------------------------------
# create-change
# ---------------------------------------------------------------------------


def test_create_change_cli_success(monkeypatch):
    runner = CliRunner()
    captured = {}

    class DummyChangeClient:
        def __init__(self):
            self.resolved = []

        def resolve_change_category_guid(self, name):
            self.resolved.append(name)
            return "DOC-GUID"

        def create_change(self, **kwargs):
            captured.update(kwargs)
            return {"guid": "CHG-1", "number": "ECO-0001"}

    dummy = DummyChangeClient()

    monkeypatch.setattr("gladiator.cli._change_client", lambda: dummy)
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(
        app,
        [
            "create-change",
            "--category",
            "Documentation Change Order",
            "--title",
            "ECO Title",
            "--description",
            "Desc",
            "--effectivity-type",
            "permanent_on_date",
            "--planned-date",
            "2025-01-01T00:00:00Z",
            "--approval-deadline",
            "2025-01-10T00:00:00Z",
            "--enforce-deadline",
        ],
    )

    assert result.exit_code == 0
    assert dummy.resolved == ["Documentation Change Order"]
    assert captured["category_guid"] == "DOC-GUID"
    assert captured["effectivity_type"] == "permanent_on_date"
    assert "number_sequence_prefix" not in captured
    assert "routings" not in captured
    assert "additional_attributes" not in captured
    assert captured["enforce_approval_deadline"] is True
    assert "Created change" in result.stdout
    assert "ECO-0001" in result.stdout


def test_create_change_cli_uses_default_category(monkeypatch):
    runner = CliRunner()
    captured = {}

    class DummyChangeClient:
        def __init__(self):
            self.resolved = []

        def resolve_change_category_guid(self, name):
            self.resolved.append(name)
            return "COMP-GUID"

        def create_change(self, **kwargs):
            captured.update(kwargs)
            return {"guid": "CHG-2"}

    dummy = DummyChangeClient()

    monkeypatch.setattr("gladiator.cli._change_client", lambda: dummy)
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(app, ["create-change", "--title", "Default Title"])

    assert result.exit_code == 0
    assert dummy.resolved == ["Engineering Change Order"]
    assert captured["category_guid"] == "COMP-GUID"
    assert "number_sequence_prefix" not in captured
    assert "routings" not in captured
    assert "additional_attributes" not in captured
    assert "Created change" in result.stdout


def test_create_change_cli_json_format(monkeypatch):
    runner = CliRunner()

    class DummyChangeClient:
        def resolve_change_category_guid(self, name):
            return "CAT"

        def create_change(self, **kwargs):
            return {"guid": "CHG-JSON", "number": "ECO-0099"}

    monkeypatch.setattr("gladiator.cli._change_client", lambda: DummyChangeClient())
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(
        app,
        [
            "create-change",
            "--title",
            "JSON Change",
            "--format",
            "json",
        ],
    )

    assert result.exit_code == 0
    assert '{\n  "guid": "CHG-JSON"' in result.stdout


def test_create_change_cli_http_error(monkeypatch):
    runner = CliRunner()

    class DummyChangeClient:
        def resolve_change_category_guid(self, name):
            return "CAT"

        def create_change(self, **kwargs):
            raise requests.HTTPError("boom")

    monkeypatch.setattr("gladiator.cli._change_client", lambda: DummyChangeClient())
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(
        app,
        [
            "create-change",
            "--title",
            "ECO",
        ],
    )

    assert result.exit_code == 2
    assert "Arena request failed" in result.stderr


def test_create_change_cli_arena_error(monkeypatch):
    runner = CliRunner()

    class DummyChangeClient:
        def resolve_change_category_guid(self, name):
            return "CAT"

        def create_change(self, **kwargs):
            from gladiator.arena import ArenaError

            raise ArenaError("bad change")

    monkeypatch.setattr("gladiator.cli._change_client", lambda: DummyChangeClient())
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(
        app,
        [
            "create-change",
            "--title",
            "ECO",
        ],
    )

    assert result.exit_code == 2
    assert "bad change" in result.stderr


def test_create_change_cli_category_lookup_error(monkeypatch):
    runner = CliRunner()

    class DummyChangeClient:
        def resolve_change_category_guid(self, name):
            from gladiator.arena import ArenaError

            raise ArenaError("category missing")

        def create_change(self, **kwargs):
            raise AssertionError("create_change should not be called")

    monkeypatch.setattr("gladiator.cli._change_client", lambda: DummyChangeClient())
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(
        app,
        [
            "create-change",
            "--category",
            "Missing",
            "--title",
            "ECO",
        ],
    )

    assert result.exit_code == 2
    assert "category missing" in result.stderr
