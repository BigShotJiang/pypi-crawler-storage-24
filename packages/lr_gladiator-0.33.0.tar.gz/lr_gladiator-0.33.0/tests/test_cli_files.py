#! /usr/bin/env python
# -*- coding: utf-8 -*-
# tests/test_cli_files.py
"""Tests for the list-files and get-files commands."""

from contextlib import contextmanager
from pathlib import Path

import pytest
import requests
from typer.testing import CliRunner

from gladiator.cli import app


@pytest.fixture(autouse=True)
def _clear_login_env(monkeypatch):
    """Ensure arena login env vars never leak into tests."""
    monkeypatch.delenv("GLADIATOR_USERNAME", raising=False)
    monkeypatch.delenv("GLADIATOR_PASSWORD", raising=False)


@contextmanager
def _noop_spinner(*_args, **_kwargs):
    yield


# ---------------------------------------------------------------------------
# list-files
# ---------------------------------------------------------------------------


def test_list_files_success(monkeypatch):
    runner = CliRunner()

    class DummyClient:
        def __init__(self):
            self.calls = []

        def list_files(self, item, revision):
            self.calls.append((item, revision))
            return [
                {
                    "title": "Firmware",
                    "name": "fw.bin",
                    "size": 1024,
                    "edition": "A",
                    "storageMethodName": "FILE",
                    "location": None,
                }
            ]

    client = DummyClient()

    monkeypatch.setattr("gladiator.cli._client", lambda: client)
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(app, ["list-files", "510-0005"])

    assert result.exit_code == 0
    assert client.calls == [("510-0005", None)]
    assert "fw.bin" in result.stdout
    assert "1024" in result.stdout


def test_list_files_json(monkeypatch):
    runner = CliRunner()

    class DummyClient:
        def list_files(self, item, revision):
            return [{"name": "fw.bin"}]

    monkeypatch.setattr("gladiator.cli._client", lambda: DummyClient())
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(
        app,
        ["list-files", "510-0006", "--rev", "WORKING", "--format", "json"],
    )

    assert result.exit_code == 0
    assert (
        result.stdout.strip()
        == '{\n  "article": "510-0006",\n  "revision": "WORKING",\n  "files": [\n    {\n      "name": "fw.bin"\n    }\n  ]\n}'
    )


def test_list_files_http_error(monkeypatch):
    runner = CliRunner()

    class DummyClient:
        def list_files(self, item, revision):
            raise requests.HTTPError("boom")

    monkeypatch.setattr("gladiator.cli._client", lambda: DummyClient())
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(app, ["list-files", "510-0007"])

    assert result.exit_code == 2
    assert "Arena request failed" in result.stderr


def test_list_files_arena_error(monkeypatch):
    runner = CliRunner()

    class DummyClient:
        def list_files(self, item, revision):
            from gladiator.arena import ArenaError

            raise ArenaError("no files")

    monkeypatch.setattr("gladiator.cli._client", lambda: DummyClient())
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(app, ["list-files", "510-0008"])

    assert result.exit_code == 2
    assert "no files" in result.stderr


# ---------------------------------------------------------------------------
# get-files
# ---------------------------------------------------------------------------


def test_get_files_default(monkeypatch):
    runner = CliRunner()

    class DummyClient:
        def __init__(self):
            self.calls = []

        def download_files(self, item, revision, out_dir):
            self.calls.append((item, revision, out_dir))
            return [out_dir / "fw.bin"]

    client = DummyClient()

    monkeypatch.setattr("gladiator.cli._client", lambda: client)
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(app, ["get-files", "510-0013"])

    assert result.exit_code == 0
    assert client.calls == [("510-0013", None, Path("510-0013"))]
    assert result.stdout.strip() == str(Path("510-0013") / "fw.bin")


def test_get_files_recursive(monkeypatch, tmp_path):
    runner = CliRunner()

    class DummyClient:
        def __init__(self):
            self.recursive_calls = []

        def download_files_recursive(self, item, revision, out_dir, max_depth):
            self.recursive_calls.append((item, revision, out_dir, max_depth))
            return [out_dir / "fw.bin"]

        def download_files(self, *args, **kwargs):
            raise AssertionError("Expected recursive path")

    client = DummyClient()
    target_dir = tmp_path / "artifacts"

    monkeypatch.setattr("gladiator.cli._client", lambda: client)
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(
        app,
        [
            "get-files",
            "510-0014",
            "--rev",
            "WORKING",
            "--out",
            str(target_dir),
            "--recursive",
            "--max-depth",
            "2",
        ],
    )

    assert result.exit_code == 0
    assert client.recursive_calls == [("510-0014", "WORKING", target_dir, 2)]
    assert result.stdout.strip() == str(target_dir / "fw.bin")


def test_get_files_http_error(monkeypatch):
    runner = CliRunner()

    class DummyClient:
        def download_files(self, item, revision, out_dir):
            raise requests.HTTPError("boom")

    monkeypatch.setattr("gladiator.cli._client", lambda: DummyClient())
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(app, ["get-files", "510-0015"])

    assert result.exit_code == 2
    assert "Arena request failed" in result.stderr


def test_get_files_arena_error(monkeypatch):
    runner = CliRunner()

    class DummyClient:
        def download_files(self, item, revision, out_dir):
            from gladiator.arena import ArenaError

            raise ArenaError("download blocked")

    monkeypatch.setattr("gladiator.cli._client", lambda: DummyClient())
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(app, ["get-files", "510-0016"])

    assert result.exit_code == 2
    assert "download blocked" in result.stderr
