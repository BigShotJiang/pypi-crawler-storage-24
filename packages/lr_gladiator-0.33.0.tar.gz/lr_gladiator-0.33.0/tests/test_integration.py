#! /usr/bin/env python
# -*- coding: utf-8 -*-
# tests/test_integration.py
"""
Integration tests that hit the live Arena backend.

These are **not** run as part of the normal unit-test suite.
Run them explicitly with:

    pytest tests/test_integration.py \
        --run-integration \
        --arena-username you@example.com \
        --arena-password secret

Username / password can also be supplied via the environment variables
GLADIATOR_USERNAME and GLADIATOR_PASSWORD instead of CLI flags.
"""

import json
import os
from pathlib import Path

import pytest

from gladiator.arena.base import arena_login, ArenaError
from gladiator.arena import ArenaClient

# A well-known item number that should always exist in the workspace.
KNOWN_ITEM_NUMBER = "501-1001"


def _credentials(request):
    """Resolve username/password from CLI options or env vars."""
    username = request.config.getoption("--arena-username") or os.environ.get(
        "GLADIATOR_USERNAME"
    )
    password = request.config.getoption("--arena-password") or os.environ.get(
        "GLADIATOR_PASSWORD"
    )
    if not username or not password:
        pytest.skip(
            "Arena credentials not provided "
            "(use --arena-username/--arena-password or env vars)"
        )
    return username, password


@pytest.fixture(scope="module")
def config_path(tmp_path_factory):
    """Return a temporary path for the login config file."""
    config_dir = tmp_path_factory.mktemp("gladiator")
    return config_dir / "login.json"


@pytest.fixture(scope="module")
def arena_config(request, config_path):
    """Log in once per module and return a LoginConfig."""
    username, password = _credentials(request)
    cfg = arena_login(
        username,
        password,
        save_to_disk=True,
        config_path=config_path,
    )
    assert cfg.arena_session_id, "Login should return a session id"
    return cfg


@pytest.fixture(scope="module")
def client(arena_config):
    """Return an ArenaClient authenticated against the live backend."""
    return ArenaClient(arena_config)


@pytest.mark.integration
class TestArenaLogin:
    """Verify that programmatic login works end-to-end."""

    def test_login_returns_session_id(self, arena_config):
        assert arena_config.arena_session_id

    def test_login_returns_workspace(self, arena_config):
        assert arena_config.workspace_id is not None

    def test_config_file_created(self, arena_config, config_path):
        assert config_path.exists(), "Login should save config to disk"
        data = json.loads(config_path.read_text())
        assert "arenaSessionId" in data, "Saved config should contain arenaSessionId"
        assert data["arenaSessionId"], "arenaSessionId should not be empty"


@pytest.mark.integration
class TestItemInfo:
    """Run the equivalent of 'gladiator info 501-1001' via the Python API."""

    def test_get_item_summary(self, client):
        summary = client.get_item_summary(KNOWN_ITEM_NUMBER)
        assert summary, "Expected a non-empty summary dict"
        assert summary.get("number") == KNOWN_ITEM_NUMBER
        assert summary.get("name"), "Item should have a name"

    def test_get_item_summary_has_revision(self, client):
        summary = client.get_item_summary(KNOWN_ITEM_NUMBER)
        assert summary.get("revision"), "Item should have a revision label"

    def test_get_item_summary_has_lifecycle(self, client):
        summary = client.get_item_summary(KNOWN_ITEM_NUMBER)
        assert summary.get("lifecyclePhase"), "Item should have a lifecycle phase"
