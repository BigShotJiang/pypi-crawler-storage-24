#! /usr/bin/env python
# -*- coding: utf-8 -*-
# tests/test_cli_status.py
"""Tests for the status and list-items commands."""

import json
from contextlib import contextmanager

import pytest
import requests
from typer.testing import CliRunner

from gladiator.cli import app


@pytest.fixture(autouse=True)
def _clear_login_env(monkeypatch):
    """Ensure arena login env vars never leak into tests."""
    monkeypatch.delenv("GLADIATOR_USERNAME", raising=False)
    monkeypatch.delenv("GLADIATOR_PASSWORD", raising=False)


@contextmanager
def _noop_spinner(*_args, **_kwargs):
    yield


# ---------------------------------------------------------------------------
# status
# ---------------------------------------------------------------------------


def test_status_success(monkeypatch):
    runner = CliRunner()

    class DummyClient:
        def check_status(self):
            return {
                "connected": True,
                "base_url": "https://api.arenasolutions.com/v1",
                "status_code": 200,
            }

    monkeypatch.setattr("gladiator.cli._client", lambda: DummyClient())

    result = runner.invoke(app, ["status"])

    assert result.exit_code == 0
    assert "Connected to" in result.stdout
    assert "https://api.arenasolutions.com/v1" in result.stdout


def test_status_http_error_with_status_code(monkeypatch):
    runner = CliRunner()

    class DummyClient:
        def check_status(self):
            return {
                "connected": False,
                "base_url": "https://api.arenasolutions.com/v1",
                "status_code": 401,
                "error": "HTTP error: 401 Client Error: Unauthorized",
            }

    monkeypatch.setattr("gladiator.cli._client", lambda: DummyClient())

    result = runner.invoke(app, ["status"])

    assert result.exit_code == 2
    assert "Unable to connect" in result.stderr
    assert "401" in result.stderr


def test_status_multiple_errors(monkeypatch):
    runner = CliRunner()

    class DummyClient:
        def check_status(self):
            return {
                "connected": False,
                "base_url": "https://api.arenasolutions.com/v1",
                "status_code": 403,
                "error": "HTTP error: 403 Client Error: Forbidden",
            }

    monkeypatch.setattr("gladiator.cli._client", lambda: DummyClient())

    result = runner.invoke(app, ["status"])

    assert result.exit_code == 2


def test_status_server_error(monkeypatch):
    runner = CliRunner()

    class DummyClient:
        def check_status(self):
            return {
                "connected": False,
                "base_url": "https://api.arenasolutions.com/v1",
                "status_code": 500,
                "error": "HTTP error: 500 Server Error",
            }

    monkeypatch.setattr("gladiator.cli._client", lambda: DummyClient())

    result = runner.invoke(app, ["status"])

    assert result.exit_code == 2


def test_status_json_output(monkeypatch):
    runner = CliRunner()

    class DummyClient:
        def check_status(self):
            return {
                "connected": True,
                "base_url": "https://api.arenasolutions.com/v1",
                "status_code": 200,
            }

    monkeypatch.setattr("gladiator.cli._client", lambda: DummyClient())

    result = runner.invoke(app, ["status", "--format", "json"])

    assert result.exit_code == 0
    data = json.loads(result.stdout)
    assert data["connected"] is True
    assert data["base_url"] == "https://api.arenasolutions.com/v1"
    assert data["status_code"] == 200


def test_status_connection_failure(monkeypatch):
    runner = CliRunner()

    class DummyClient:
        def check_status(self):
            return {
                "connected": False,
                "base_url": "https://api.arenasolutions.com/v1",
                "error": "Connection error: [Errno -2] Name or service not known",
            }

    monkeypatch.setattr("gladiator.cli._client", lambda: DummyClient())

    result = runner.invoke(app, ["status"])

    assert result.exit_code == 2
    assert "Unable to connect" in result.stderr
    assert "Connection error" in result.stderr


def test_status_timeout(monkeypatch):
    runner = CliRunner()

    class DummyClient:
        def check_status(self):
            return {
                "connected": False,
                "base_url": "https://api.arenasolutions.com/v1",
                "error": "Request timeout: HTTPSConnectionPool(host='api.arenasolutions.com', port=443)",
            }

    monkeypatch.setattr("gladiator.cli._client", lambda: DummyClient())

    result = runner.invoke(app, ["status"])

    assert result.exit_code == 2
    assert "Unable to connect" in result.stderr
    assert "timeout" in result.stderr.lower()


# ---------------------------------------------------------------------------
# list-items
# ---------------------------------------------------------------------------


def test_list_items_success(monkeypatch):
    runner = CliRunner()

    class DummyClient:
        def __init__(self):
            self.calls = []

        def search_items(self, pattern):
            self.calls.append(pattern)
            return [
                {
                    "number": "104-0001",
                    "name": "Widget A",
                    "description": "Desc A",
                    "revisionNumber": "B",
                    "lifecyclePhase": "In Production",
                },
                {
                    "number": "104-0002",
                    "name": "Widget B",
                    "description": None,
                    "revisionNumber": "A",
                    "lifecyclePhase": None,
                },
            ]

    client = DummyClient()

    monkeypatch.setattr("gladiator.cli._client", lambda: client)
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(app, ["list-items", "104*"])

    assert result.exit_code == 0
    assert client.calls == ["104*"]
    assert "104-0001" in result.stdout
    assert "Widget A" in result.stdout
    assert "104-0002" in result.stdout


def test_list_items_json(monkeypatch):
    runner = CliRunner()

    class DummyClient:
        def search_items(self, pattern):
            return [
                {"number": "104-0001", "name": "Widget A"},
            ]

    monkeypatch.setattr("gladiator.cli._client", lambda: DummyClient())
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(app, ["list-items", "104*", "--format", "json"])

    assert result.exit_code == 0
    data = json.loads(result.stdout)
    assert data["count"] == 1
    assert data["results"][0]["number"] == "104-0001"


def test_list_items_empty(monkeypatch):
    runner = CliRunner()

    class DummyClient:
        def search_items(self, pattern):
            return []

    monkeypatch.setattr("gladiator.cli._client", lambda: DummyClient())
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(app, ["list-items", "999*"])

    assert result.exit_code == 0
    assert "No items matching" in result.stdout


def test_list_items_http_error(monkeypatch):
    runner = CliRunner()

    class DummyClient:
        def search_items(self, pattern):
            raise requests.HTTPError("boom")

    monkeypatch.setattr("gladiator.cli._client", lambda: DummyClient())
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(app, ["list-items", "104*"])

    assert result.exit_code == 2
    assert "Arena request failed" in result.stderr


def test_list_items_arena_error(monkeypatch):
    runner = CliRunner()

    class DummyClient:
        def search_items(self, pattern):
            from gladiator.arena import ArenaError

            raise ArenaError("search failed")

    monkeypatch.setattr("gladiator.cli._client", lambda: DummyClient())
    monkeypatch.setattr("gladiator.cli.spinner", _noop_spinner)

    result = runner.invoke(app, ["list-items", "104*"])

    assert result.exit_code == 2
    assert "search failed" in result.stderr
