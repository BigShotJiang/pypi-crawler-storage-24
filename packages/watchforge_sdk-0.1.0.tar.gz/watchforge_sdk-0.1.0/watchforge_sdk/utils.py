"""
Utility functions for WatchForge SDK
"""
import sys
import traceback
import inspect
import os
import platform
import socket
import pkg_resources
from typing import Dict, List, Any, Optional
import importlib.util


def extract_stacktrace(exception: Exception) -> List[Dict[str, Any]]:
    """
    Extract stacktrace as a list of frame dictionaries with full context.
    
    Returns:
        List of frame dictionaries with:
        - filename: Relative filename
        - abs_path: Absolute file path
        - lineno: Line number where error occurred
        - colno: Column number (if available)
        - function: Function name
        - module: Module name
        - context_line: The actual line of code where error occurred
        - pre_context: List of 5 lines before the error
        - post_context: List of 5 lines after the error
        - vars: Local variables at this frame
        - in_app: Whether this is application code (not library)
    """
    frames = []
    
    # Get traceback from exception
    tb = getattr(exception, '__traceback__', None)
    
    # If no traceback, try to get from sys.exc_info
    if tb is None:
        import sys
        exc_type, exc_value, exc_traceback = sys.exc_info()
        if exc_traceback:
            tb = exc_traceback
            # Also attach it to the exception for future use
            if hasattr(exception, '__traceback__'):
                exception.__traceback__ = exc_traceback
    
    # If still no traceback, we can't extract frames - return empty list
    if tb is None:
        return frames
    
    # Get the current working directory to determine if code is "in app"
    try:
        cwd = os.getcwd()
    except Exception:
        cwd = ""
    
    while tb is not None:
        frame = tb.tb_frame
        abs_path = frame.f_code.co_filename
        lineno = tb.tb_lineno
        function = frame.f_code.co_name
        module = frame.f_globals.get('__name__', '')
        
        # Determine relative filename
        filename = abs_path
        try:
            # Try to get relative path from common locations
            if abs_path.startswith(cwd):
                filename = os.path.relpath(abs_path, cwd)
            elif '<' in abs_path or '>' in abs_path:
                # Built-in or dynamic code
                filename = abs_path
            else:
                # Try to get just the filename
                filename = os.path.basename(abs_path)
        except Exception:
            filename = abs_path
        
        # Determine if this is application code
        in_app = _is_in_app_code(abs_path, cwd)
        
        # Extract context lines (5 before, error line, 5 after)
        context_line = None
        pre_context = []
        post_context = []
        vars_dict = {}
        
        try:
            # Get source lines around the error
            source_lines, start_line = inspect.getsourcelines(frame)
            relative_lineno = lineno - start_line
            
            if 0 <= relative_lineno < len(source_lines):
                # Get the error line
                context_line = source_lines[relative_lineno].rstrip()
                
                # Get 5 lines before (pre_context)
                pre_start = max(0, relative_lineno - 5)
                pre_context = [
                    source_lines[i].rstrip() 
                    for i in range(pre_start, relative_lineno)
                ]
                
                # Get 5 lines after (post_context)
                post_end = min(len(source_lines), relative_lineno + 6)
                post_context = [
                    source_lines[i].rstrip() 
                    for i in range(relative_lineno + 1, post_end)
                ]
        except (OSError, TypeError, ValueError):
            # Source not available (e.g., built-in modules, dynamic code)
            # Try to get at least the error line from traceback
            try:
                import linecache
                line = linecache.getline(abs_path, lineno)
                if line:
                    context_line = line.rstrip()
            except Exception:
                pass
        
        # Extract local variables
        vars_dict = _extract_frame_locals(frame)
        
        # Try to get column number from traceback (if available)
        colno = None
        try:
            # Python 3.11+ has column information in traceback
            if hasattr(tb, 'tb_lasti'):
                # Try to extract column from bytecode offset
                code = frame.f_code
                if hasattr(code, 'co_positions'):
                    positions = code.co_positions()
                    if positions:
                        # Get position for the current instruction
                        colno = positions[0][1] if positions else None
        except Exception:
            pass
        
        frame_data = {
            "filename": filename,
            "abs_path": abs_path,
            "lineno": lineno,
            "function": function,
            "module": module,
            "in_app": in_app,
        }
        
        # Add column number if available
        if colno:
            frame_data["colno"] = colno
        
        # Add context information
        if context_line:
            frame_data["context_line"] = context_line
        
        if pre_context:
            frame_data["pre_context"] = pre_context
        
        if post_context:
            frame_data["post_context"] = post_context
        
        # Add variables
        if vars_dict:
            frame_data["vars"] = vars_dict
        
        frames.append(frame_data)
        
        tb = tb.tb_next
    
    return frames


def _is_in_app_code(filepath: str, cwd: str) -> bool:
    """
    Determine if a file path is application code (not library code).
    
    Args:
        filepath: Absolute file path
        cwd: Current working directory
    
    Returns:
        True if this is application code, False if library code
    """
    if not filepath or not cwd:
        return False
    
    # Built-in modules are not in-app
    if filepath.startswith('<') or filepath.startswith('>'):
        return False
    
    # Check for venv/virtualenv paths (library code)
    if '/venv/' in filepath or '/virtualenv/' in filepath or '/env/' in filepath:
        return False
    
    # Check if file is in site-packages (library code)
    if '/site-packages/' in filepath:
        return False
    
    # Check if file is in dist-packages (Debian/Ubuntu)
    if '/dist-packages/' in filepath:
        return False
    
    # Check if file is in Python library paths
    if '/lib/python' in filepath:
        return False
    
    # Check if file is in site-packages (library code)
    import site
    try:
        site_packages = site.getsitepackages()
        for sp in site_packages:
            if filepath.startswith(sp):
                return False
    except Exception:
        pass
    
    # Check if file is in the current working directory or project
    try:
        if filepath.startswith(cwd):
            # Double check it's not in a venv within the project
            if '/venv/' not in filepath and '/virtualenv/' not in filepath:
                return True
    except Exception:
        pass
    
    # Default: assume NOT in-app if we can't determine (safer to exclude)
    return False


def _extract_frame_locals(frame) -> Dict[str, Any]:
    """
    Extract local variables from a frame, excluding sensitive data.
    Returns serializable values (JSON-compatible).
    """
    import json
    from decimal import Decimal
    from datetime import datetime, date
    
    locals_dict = {}
    try:
        for key, value in frame.f_locals.items():
            # Skip sensitive keys
            if key.startswith('_') or key.lower() in ['password', 'secret', 'token', 'api_key', 'key', 'auth', 'credential']:
                continue
            
            # Try to serialize the value
            try:
                # Handle common non-serializable types
                if isinstance(value, (Decimal,)):
                    locals_dict[key] = str(value)
                elif isinstance(value, (datetime, date)):
                    locals_dict[key] = value.isoformat()
                elif isinstance(value, (bytes,)):
                    try:
                        locals_dict[key] = value.decode('utf-8')
                    except UnicodeDecodeError:
                        locals_dict[key] = f"<bytes: {len(value)} bytes>"
                elif isinstance(value, (set, frozenset)):
                    locals_dict[key] = list(value)
                elif isinstance(value, (type,)):
                    locals_dict[key] = f"<class: {value.__name__}>"
                else:
                    # Try JSON serialization
                    try:
                        json.dumps(value)  # Test if serializable
                        # Limit size for large objects
                        str_value = str(value)
                        if len(str_value) > 1000:
                            str_value = str_value[:1000] + "... (truncated)"
                        locals_dict[key] = value if len(str_value) < 100 else str_value
                    except (TypeError, ValueError):
                        # Fallback to string representation
                        str_value = str(value)
                        if len(str_value) > 500:
                            str_value = str_value[:500] + "... (truncated)"
                        locals_dict[key] = str_value
            except Exception as e:
                locals_dict[key] = f"<unable to serialize: {type(value).__name__}>"
    except Exception:
        pass
    
    return locals_dict


def get_system_info() -> Dict[str, Any]:
    """
    Get system information.
    """
    return {
        "platform": platform.platform(),
        "python_version": sys.version,
        "python_version_info": {
            "major": sys.version_info.major,
            "minor": sys.version_info.minor,
            "micro": sys.version_info.micro,
        },
        "architecture": platform.architecture()[0],
        "machine": platform.machine(),
        "processor": platform.processor(),
        "hostname": socket.gethostname(),
    }


def get_network_info() -> Dict[str, Any]:
    """
    Get network information.
    """
    network_info = {
        "hostname": socket.gethostname(),
    }
    
    try:
        # Get local IP address
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        network_info["local_ip"] = s.getsockname()[0]
        s.close()
    except Exception:
        network_info["local_ip"] = None
    
    try:
        # Get FQDN
        network_info["fqdn"] = socket.getfqdn()
    except Exception:
        network_info["fqdn"] = None
    
    return network_info


def get_installed_packages() -> List[Dict[str, str]]:
    """
    Get list of installed packages with versions.
    
    Returns:
        List of dicts with 'name' and 'version' keys
    """
    packages = []
    try:
        for dist in pkg_resources.working_set:
            packages.append({
                "name": dist.project_name,
                "version": dist.version,
            })
    except Exception:
        pass
    
    return sorted(packages, key=lambda x: x["name"])


def get_code_replay(filename: str, lineno: int, context_lines: int = 10) -> Optional[Dict[str, Any]]:
    """
    Get code context around a specific line for code replay.
    
    Args:
        filename: Path to the source file
        lineno: Line number where error occurred
        context_lines: Number of lines before and after to capture
    
    Returns:
        Dict with start_line, end_line, lines, and error_line
    """
    try:
        if not os.path.exists(filename):
            return None
        
        with open(filename, 'r', encoding='utf-8', errors='ignore') as f:
            all_lines = f.readlines()
        
        # Calculate range
        start_line = max(0, lineno - context_lines - 1)  # -1 for 0-indexing
        end_line = min(len(all_lines), lineno + context_lines)
        
        # Extract lines
        code_lines = [line.rstrip() for line in all_lines[start_line:end_line]]
        
        # Calculate error line relative to start
        error_line_idx = lineno - start_line - 1
        
        return {
            "filename": filename,
            "start_line": start_line + 1,  # 1-indexed for display
            "end_line": end_line,
            "lines": code_lines,
            "error_line": error_line_idx,
            "error_lineno": lineno,
        }
    except Exception:
        return None


def format_stacktrace_string(exception: Exception) -> str:
    """
    Get formatted stacktrace as string (fallback).
    """
    return ''.join(traceback.format_exception(
        type(exception),
        exception,
        exception.__traceback__
    ))
