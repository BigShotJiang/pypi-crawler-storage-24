from .client import register, init, capture_exception, capture_message, flush
from .context import Context
from .hooks import (
    install_exception_hook,
    uninstall_exception_hook,
    install_logging_handler,
    uninstall_logging_handler,
    auto_capture_exceptions,
)
from .tracing import (
    start_transaction,
    get_current_transaction,
    finish_transaction,
    Transaction,
    Span,
    init_tracing,
)

# Export context as both Context and context for convenience
context = Context

# Framework handlers are available via watchforge_sdk.handlers
# from watchforge_sdk.handlers.django import DjangoHandler

__all__ = [
    "register",  # Primary registration method
    "init",  # Deprecated alias for register
    "capture_exception",
    "capture_message",
    "flush",
    "Context",
    "context",
    "install_exception_hook",
    "uninstall_exception_hook",
    "install_logging_handler",
    "uninstall_logging_handler",
    "auto_capture_exceptions",
    # Tracing
    "start_transaction",
    "get_current_transaction",
    "finish_transaction",
    "Transaction",
    "Span",
    "init_tracing",
]