"""
WatchForge Python SDK Client
Enhanced version with full context capture
"""
import uuid
import datetime
from typing import Dict, Any, Optional, List
try:
    from zoneinfo import ZoneInfo  # Python 3.9+
except ImportError:
    try:
        from backports.zoneinfo import ZoneInfo  # Python 3.8 backport
    except ImportError:
        # Fallback to pytz if zoneinfo not available
        try:
            import pytz
            ZoneInfo = None  # Will use pytz instead
        except ImportError:
            ZoneInfo = None
            pytz = None
from .transport import send_event, flush as flush_events, set_debug as set_transport_debug
from .context import Context
from .utils import (
    extract_stacktrace,
    get_system_info,
    get_network_info,
    get_installed_packages,
    get_code_replay,
    format_stacktrace_string,
)

_DSN = None
_ENV = "production"
_ENABLE_SYSTEM_INFO = True
_ENABLE_PACKAGES = True
_ENABLE_CODE_REPLAY = True
_AUTO_CAPTURE_EXCEPTIONS = True
_AUTO_CAPTURE_LOGGING = True
_LOGGING_LEVEL = None  # Will be set to logging.WARNING by default
_DEBUG = False  # Debug mode to print event data

# Cache system info (computed once)
_cached_system_info = None
_cached_network_info = None
_cached_packages = None


def register(
    endpoint: str,
    app_env: str = "production",
    enable_system_info: bool = True,
    enable_packages: bool = True,
    enable_code_replay: bool = True,
    auto_capture_exceptions: bool = True,
    auto_capture_logging: bool = True,
    logging_level: Optional[int] = None,
    debug: bool = False,
    integrations: Optional[List] = None,
):
    """
    Register WatchForge SDK with your application.
    
    By default, this will automatically capture:
    - All unhandled exceptions (errors)
    - All logging messages at INFO level and above (info, warning, error)
    
    You don't need to manually call capture_message() or capture_exception() 
    for most cases - just use Python's logging module or let exceptions bubble up.
    
    Args:
        endpoint: WatchForge endpoint URL (project endpoint)
        app_env: Application environment name (production, staging, dev, etc.)
        enable_system_info: Whether to capture system and network info
        enable_packages: Whether to capture installed packages
        enable_code_replay: Whether to capture code context around errors
        auto_capture_exceptions: Automatically capture unhandled exceptions (default: True)
        auto_capture_logging: Automatically capture logging messages (default: True)
        logging_level: Minimum log level to capture (default: INFO). 
                      Use logging.INFO, logging.WARNING, logging.ERROR, etc.
        debug: Print event data to console before sending (default: False)
        integrations: List of integrations to enable (e.g., [DjangoHandler()])
    
    Example - Basic:
        from watchforge_sdk import register
        
        register(endpoint="your-endpoint", app_env="production")
    
    Example - Django:
        from watchforge_sdk import register
        from watchforge_sdk.integrations.django import DjangoHandler
        
        register(
            endpoint="your-endpoint",
            app_env="production",
            integrations=[DjangoHandler()],
        )
    """
    import logging
    global _DSN, _ENV, _ENABLE_SYSTEM_INFO, _ENABLE_PACKAGES, _ENABLE_CODE_REPLAY
    global _AUTO_CAPTURE_EXCEPTIONS, _AUTO_CAPTURE_LOGGING, _LOGGING_LEVEL, _DEBUG
    
    _DSN = endpoint
    _ENV = app_env
    _ENABLE_SYSTEM_INFO = enable_system_info
    _ENABLE_PACKAGES = enable_packages
    _ENABLE_CODE_REPLAY = enable_code_replay
    _AUTO_CAPTURE_EXCEPTIONS = auto_capture_exceptions
    _AUTO_CAPTURE_LOGGING = auto_capture_logging
    # Default to INFO level to capture info, warning, and error
    _LOGGING_LEVEL = logging_level if logging_level is not None else logging.INFO
    _DEBUG = debug
    
    # Set debug mode in transport
    set_transport_debug(debug)
    
    # Initialize tracing
    from .tracing import init_tracing
    init_tracing(endpoint, app_env, debug)
    
    # Print initialization info if debug mode
    if debug:
        from .transport import get_api_url, parse_dsn
        api_url = get_api_url(endpoint)
        parsed = parse_dsn(endpoint)
        print("\n" + "=" * 80)
        print("WATCHFORGE SDK - REGISTERED")
        print("=" * 80)
        print(f"Endpoint: {endpoint[:50]}..." if len(endpoint) > 50 else f"Endpoint: {endpoint}")
        if parsed:
            print(f"  -> Host: {parsed['host']}" + (f":{parsed['port']}" if parsed['port'] else ""))
            print(f"  -> Project ID: {parsed['project_id']}")
        print(f"App Environment: {app_env}")
        print(f"API URL: {api_url}")
        print(f"Auto-capture exceptions: {auto_capture_exceptions}")
        print(f"Auto-capture logging: {auto_capture_logging}")
        if integrations:
            print(f"Integrations: {[i.__class__.__name__ for i in integrations]}")
        print(f"Debug mode: {debug}")
        print("=" * 80 + "\n")
    
    # Install automatic hooks if enabled
    if _AUTO_CAPTURE_EXCEPTIONS:
        from .hooks import install_exception_hook
        install_exception_hook()
    
    if _AUTO_CAPTURE_LOGGING:
        from .hooks import install_logging_handler
        install_logging_handler(level=_LOGGING_LEVEL)
    
    # Setup integrations
    if integrations:
        for integration in integrations:
            if hasattr(integration, 'setup'):
                try:
                    integration.setup()
                    if debug:
                        print(f"[WatchForge] Integration {integration.__class__.__name__} installed")
                except Exception as e:
                    if debug:
                        print(f"[WatchForge] Failed to setup {integration.__class__.__name__}: {e}")


def _get_system_metadata() -> Dict[str, Any]:
    """Get cached system metadata."""
    global _cached_system_info, _cached_network_info, _cached_packages
    
    metadata = {}
    
    if _ENABLE_SYSTEM_INFO:
        if _cached_system_info is None:
            _cached_system_info = get_system_info()
            _cached_network_info = get_network_info()
        metadata["system"] = _cached_system_info
        metadata["network"] = _cached_network_info
    
    if _ENABLE_PACKAGES:
        if _cached_packages is None:
            _cached_packages = get_installed_packages()
        metadata["packages"] = _cached_packages
    
    return metadata


def _build_event(
    level: str,
    message: str,
    exception: Optional[Exception] = None,
    tags: Optional[Dict[str, Any]] = None,
    extra: Optional[Dict[str, Any]] = None,
    user: Optional[Dict[str, Any]] = None,
    request: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Build a complete event with all context.
    
    Args:
        level: Event level (error, warning, info)
        message: Event message
        exception: Exception object (if applicable)
        tags: Additional tags (merged with context tags)
        extra: Additional extra data (merged with context extra)
        user: User information (merged with context user)
        request: Request information (merged with context request)
    
    Returns:
        Complete event dictionary
    """
    # Get context data
    context = Context.get_all()
    
    # Merge provided data with context
    event_user = user or context.get("user")
    event_tags = {**(context.get("tags") or {}), **(tags or {})}
    event_extra = {**(context.get("extra") or {}), **(extra or {})}
    event_request = request or context.get("request")
    
    # Get IST timezone
    if ZoneInfo:
        ist_tz = ZoneInfo("Asia/Kolkata")
    elif pytz:
        ist_tz = pytz.timezone("Asia/Kolkata")
    else:
        # Fallback: manually add 5:30 offset
        ist_tz = datetime.timezone(datetime.timedelta(hours=5, minutes=30))
    
    # Build base event with IST timestamp
    ist_now = datetime.datetime.now(ist_tz)
    event = {
        "event_id": str(uuid.uuid4()),
        "timestamp": ist_now.isoformat(),
        "level": level,
        "environment": _ENV,
        "message": message,
    }
    
    # Add exception-specific data
    if exception:
        event["exception_type"] = exception.__class__.__name__
        event["exception_module"] = exception.__class__.__module__
        event["exception_value"] = str(exception)
        
        # Ensure data dict exists
        if "data" not in event:
            event["data"] = {}
        
        # Extract stacktrace with full context for exceptions (ZeroDivisionError, etc.)
        # This is CRITICAL - always extract stacktrace for exceptions
        stacktrace = None
        try:
            # Check if exception has traceback
            if not hasattr(exception, '__traceback__') or exception.__traceback__ is None:
                if _DEBUG:
                    print(f"[WatchForge] Exception {type(exception).__name__} has no traceback")
                # Try to get traceback from sys.exc_info if available
                import sys
                exc_type, exc_value, exc_traceback = sys.exc_info()
                if exc_traceback and exc_traceback is not None:
                    # Create a temporary exception with the traceback
                    class ExceptionWithTraceback(Exception):
                        pass
                    temp_exc = ExceptionWithTraceback(str(exception))
                    temp_exc.__traceback__ = exc_traceback
                    stacktrace = extract_stacktrace(temp_exc)
                else:
                    if _DEBUG:
                        print(f"[WatchForge] No traceback available from sys.exc_info either")
            else:
                stacktrace = extract_stacktrace(exception)
            
            if _DEBUG:
                print(f"[WatchForge] Extracted stacktrace: {len(stacktrace) if stacktrace else 0} frames")
                if stacktrace:
                    print(f"[WatchForge] First frame: {stacktrace[0] if stacktrace else 'None'}")
        except Exception as e:
            if _DEBUG:
                print(f"[WatchForge] Error extracting stacktrace: {e}")
                import traceback
                traceback.print_exc()
            # Fallback to string stacktrace
            try:
                event["stacktrace_string"] = format_stacktrace_string(exception)
                event["data"]["stacktrace_raw"] = format_stacktrace_string(exception)
            except:
                pass
        
        # Always set stacktrace if we have it (even if empty, backend will handle it)
        if stacktrace and len(stacktrace) > 0:
            # Format stacktrace for backend
            # Backend expects: stacktrace.frames at top level
            # And also stores in data.stacktrace.frames for frontend
            stacktrace_data = {
                "frames": stacktrace
            }
            event["stacktrace"] = stacktrace_data
            event["data"]["stacktrace"] = stacktrace_data
            
            if _DEBUG:
                print(f"[WatchForge] Stacktrace set: {len(stacktrace)} frames")
                print(f"[WatchForge] Event stacktrace keys: {list(event.keys())}")
                print(f"[WatchForge] Event data keys: {list(event.get('data', {}).keys())}")
            
            # Get code replay for the first frame (where error occurred)
            if _ENABLE_CODE_REPLAY:
                first_frame = stacktrace[0]
                abs_path = first_frame.get("abs_path") or first_frame.get("filename")
                lineno = first_frame.get("lineno")
                
                if abs_path and lineno:
                    try:
                        code_replay = get_code_replay(abs_path, lineno)
                        if code_replay:
                            event["code_replay"] = code_replay
                    except Exception as e:
                        if _DEBUG:
                            print(f"[WatchForge] Error getting code replay: {e}")
        else:
            # No stacktrace extracted - try fallback
            if _DEBUG:
                print(f"[WatchForge] No stacktrace extracted (stacktrace={stacktrace}), using fallback")
            try:
                fallback_trace = format_stacktrace_string(exception)
                if fallback_trace:
                    event["stacktrace_string"] = fallback_trace
                    event["data"]["stacktrace_raw"] = fallback_trace
                    if _DEBUG:
                        print(f"[WatchForge] Using fallback stacktrace string: {len(fallback_trace)} chars")
            except Exception as e:
                if _DEBUG:
                    print(f"[WatchForge] Error creating fallback stacktrace: {e}")
    else:
        # For messages without exceptions, try to infer error type from message
        # Common error patterns
        message_lower = message.lower()
        if "timeout" in message_lower or "timed out" in message_lower:
            event["exception_type"] = "TimeoutError"
        elif "network" in message_lower or "connection" in message_lower:
            event["exception_type"] = "NetworkError"
        elif "database" in message_lower or "db" in message_lower or "query" in message_lower:
            event["exception_type"] = "DatabaseError"
        elif "permission" in message_lower or "forbidden" in message_lower:
            event["exception_type"] = "PermissionError"
        elif "not found" in message_lower or "404" in message_lower:
            event["exception_type"] = "NotFoundError"
        elif "validation" in message_lower or "invalid" in message_lower:
            event["exception_type"] = "ValidationError"
        elif "chunked" in message_lower or "encoding" in message_lower:
            event["exception_type"] = "ChunkedEncodingError"
        elif "slow" in message_lower and "query" in message_lower:
            event["exception_type"] = "SlowDBQuery"
        elif "improperly" in message_lower and "configured" in message_lower:
            event["exception_type"] = "ImproperlyConfigured"
        elif level in ("error", "fatal"):
            # Default to generic Error for error-level messages without exceptions
            event["exception_type"] = "Error"
        
        # Add mechanism information (like Sentry)
        event["data"] = event.get("data", {})
        event["data"]["mechanism"] = {
            "type": "generic",
            "handled": True,  # Python exceptions are typically "handled" by the SDK
        }
    
    # Add user information
    if event_user:
        event["user"] = event_user
    
    # Add tags
    if event_tags:
        event["tags"] = event_tags
    
    # Add extra data
    if event_extra:
        event["extra"] = event_extra
    
    # Add request information
    if event_request:
        event["request"] = event_request
    
    # Add breadcrumbs from context
    breadcrumbs = Context.get_breadcrumbs()
    if breadcrumbs:
        event["breadcrumbs"] = breadcrumbs
        # Also add to data for consistency
        if "data" not in event:
            event["data"] = {}
        event["data"]["breadcrumbs"] = breadcrumbs
    
    # Add system metadata
    system_metadata = _get_system_metadata()
    if system_metadata:
        event["metadata"] = system_metadata
    
    return event


def capture_exception(
    exc: Exception,
    tags: Optional[Dict[str, Any]] = None,
    extra: Optional[Dict[str, Any]] = None,
    user: Optional[Dict[str, Any]] = None,
    request: Optional[Dict[str, Any]] = None,
):
    """
    Capture an exception with full context.
    
    Args:
        exc: Exception to capture
        tags: Additional tags for this event
        extra: Additional context data for this event
        user: User information for this event
        request: Request information for this event
    
    Example:
        try:
            1 / 0
        except ZeroDivisionError as e:
            capture_exception(
                e,
                tags={"component": "payment", "severity": "high"},
                extra={"order_id": "12345", "amount": 99.99},
                user={"id": "user123", "email": "user@example.com"},
            )
    """
    if not _DSN:
        return
    
    message = str(exc)
    event = _build_event(
        level="error",
        message=message,
        exception=exc,
        tags=tags,
        extra=extra,
        user=user,
        request=request,
    )
    
    send_event(_DSN, event)


def capture_message(
    message: str,
    level: str = "info",
    tags: Optional[Dict[str, Any]] = None,
    extra: Optional[Dict[str, Any]] = None,
    user: Optional[Dict[str, Any]] = None,
    request: Optional[Dict[str, Any]] = None,
):
    """
    Capture a custom message with full context.
    
    Args:
        message: Message to capture
        level: Message level (info, warning, error)
        tags: Additional tags for this event
        extra: Additional context data for this event
        user: User information for this event
        request: Request information for this event
    
    Example:
        capture_message(
            "User logged in successfully",
            level="info",
            tags={"action": "login"},
            user={"id": "user123", "username": "john"},
        )
    """
    if not _DSN:
        return
    
    event = _build_event(
        level=level,
        message=message,
        tags=tags,
        extra=extra,
        user=user,
        request=request,
    )
    
    send_event(_DSN, event)


def flush():
    """
    Manually flush all buffered events to the backend immediately.
    Useful for testing or ensuring events are sent before program exit.
    
    Example:
        from watchforge_sdk import register, capture_message, flush
        
        register(endpoint="...", debug=True)
        capture_message("Test message")
        flush()  # Force immediate send
    """
    if not _DSN:
        if _DEBUG:
            print("WATCHFORGE SDK - ERROR: No endpoint set, cannot flush events")
        return
    
    flush_events(_DSN, force=True)


# Backward compatibility alias (deprecated - use register instead)
def init(dsn=None, endpoint=None, environment=None, app_env=None, **kwargs):
    """
    Deprecated: Use register() instead.
    This alias is provided for backward compatibility.
    
    Maps old parameter names to new ones:
    - dsn -> endpoint
    - environment -> app_env
    """
    import warnings
    warnings.warn(
        "init() is deprecated. Use register() instead.",
        DeprecationWarning,
        stacklevel=2
    )
    
    # Map old parameters to new ones
    if dsn is not None and endpoint is None:
        endpoint = dsn
    if environment is not None and app_env is None:
        app_env = environment
    
    # Remove old parameters from kwargs if they exist
    kwargs.pop('dsn', None)
    kwargs.pop('environment', None)
    
    return register(endpoint=endpoint, app_env=app_env, **kwargs)
