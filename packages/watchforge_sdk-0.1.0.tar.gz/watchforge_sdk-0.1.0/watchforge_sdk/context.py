"""
Context management for WatchForge SDK
Stores global context like user, tags, extra data, etc.
"""
from typing import Dict, Any, Optional
import threading
import datetime
try:
    from zoneinfo import ZoneInfo  # Python 3.9+
except ImportError:
    try:
        from backports.zoneinfo import ZoneInfo  # Python 3.8 backport
    except ImportError:
        # Fallback to pytz if zoneinfo not available
        try:
            import pytz
            ZoneInfo = None  # Will use pytz instead
        except ImportError:
            ZoneInfo = None
            pytz = None

# Thread-local storage for context
_context = threading.local()


class Context:
    """Thread-local context for WatchForge SDK"""
    
    @staticmethod
    def set_user(user_id: Optional[str] = None, username: Optional[str] = None, 
                 email: Optional[str] = None, ip_address: Optional[str] = None,
                 **kwargs):
        """
        Set user information in context.
        
        Args:
            user_id: Unique user identifier
            username: Username
            email: User email
            ip_address: User IP address
            **kwargs: Additional user metadata
        """
        if not hasattr(_context, 'user'):
            _context.user = {}
        
        _context.user = {
            "id": user_id,
            "username": username,
            "email": email,
            "ip_address": ip_address,
            **kwargs
        }
    
    @staticmethod
    def get_user() -> Optional[Dict[str, Any]]:
        """Get current user from context."""
        return getattr(_context, 'user', None)
    
    @staticmethod
    def set_tags(**tags):
        """
        Set tags in context (key-value pairs for filtering).
        
        Args:
            **tags: Tag key-value pairs
        """
        if not hasattr(_context, 'tags'):
            _context.tags = {}
        
        _context.tags.update(tags)
    
    @staticmethod
    def get_tags() -> Dict[str, Any]:
        """Get current tags from context."""
        return getattr(_context, 'tags', {})
    
    @staticmethod
    def set_extra(**extra):
        """
        Set extra data in context.
        
        Args:
            **extra: Extra key-value pairs
        """
        if not hasattr(_context, 'extra'):
            _context.extra = {}
        
        _context.extra.update(extra)
    
    @staticmethod
    def get_extra() -> Dict[str, Any]:
        """Get current extra data from context."""
        return getattr(_context, 'extra', {})
    
    @staticmethod
    def set_request(method: Optional[str] = None, url: Optional[str] = None,
                    headers: Optional[Dict[str, str]] = None,
                    query_string: Optional[str] = None,
                    data: Optional[Any] = None,
                    cookies: Optional[Dict[str, str]] = None,
                    **kwargs):
        """
        Set HTTP request information in context.
        
        Args:
            method: HTTP method (GET, POST, etc.)
            url: Request URL
            headers: Request headers
            query_string: Query string
            data: Request data/body
            cookies: Request cookies
            **kwargs: Additional request metadata
        """
        if not hasattr(_context, 'request'):
            _context.request = {}
        
        _context.request = {
            "method": method,
            "url": url,
            "headers": headers or {},
            "query_string": query_string,
            "data": str(data) if data else None,
            "cookies": cookies or {},
            **kwargs
        }
    
    @staticmethod
    def get_request() -> Optional[Dict[str, Any]]:
        """Get current request from context."""
        return getattr(_context, 'request', None)
    
    @staticmethod
    def clear():
        """Clear all context."""
        if hasattr(_context, 'user'):
            delattr(_context, 'user')
        if hasattr(_context, 'tags'):
            delattr(_context, 'tags')
        if hasattr(_context, 'extra'):
            delattr(_context, 'extra')
        if hasattr(_context, 'request'):
            delattr(_context, 'request')
        if hasattr(_context, 'breadcrumbs'):
            delattr(_context, 'breadcrumbs')
    
    @staticmethod
    def add_breadcrumb(
        type: str,
        message: Optional[str] = None,
        level: str = "info",
        category: Optional[str] = None,
        data: Optional[Dict[str, Any]] = None,
        timestamp: Optional[str] = None,
    ):
        """
        Add a breadcrumb to the context.
        
        Breadcrumbs are a chronological list of events leading up to an error.
        They help understand what happened before the error occurred.
        
        Args:
            type: Breadcrumb type (query, http, log, navigation, user, etc.)
            message: Breadcrumb message
            level: Breadcrumb level (info, warning, error, fatal)
            category: Breadcrumb category (db.query, http, log, etc.)
            data: Additional breadcrumb data (query, duration, table, etc.)
            timestamp: Optional timestamp (defaults to current time)
        
        Examples:
            # Add a database query breadcrumb
            Context.add_breadcrumb(
                type="query",
                message="SELECT * FROM users WHERE id = 1",
                level="info",
                category="db.query",
                data={
                    "query": "SELECT * FROM users WHERE id = 1",
                    "duration": 15.5,
                    "table": "users"
                }
            )
            
            # Add an HTTP request breadcrumb
            Context.add_breadcrumb(
                type="http",
                message="GET /api/users",
                level="info",
                category="http",
                data={
                    "url": "http://example.com/api/users",
                    "method": "GET",
                    "status_code": 200
                }
            )
            
            # Add a log breadcrumb
            Context.add_breadcrumb(
                type="log",
                message="Starting authentication process",
                level="info",
                category="log"
            )
        """
        if not hasattr(_context, 'breadcrumbs'):
            _context.breadcrumbs = []
        
        # Get IST timezone
        if ZoneInfo:
            ist_tz = ZoneInfo("Asia/Kolkata")
        elif pytz:
            ist_tz = pytz.timezone("Asia/Kolkata")
        else:
            # Fallback: manually add 5:30 offset
            ist_tz = datetime.timezone(datetime.timedelta(hours=5, minutes=30))
        
        if timestamp is None:
            ist_now = datetime.datetime.now(ist_tz)
            timestamp = ist_now.isoformat()
        
        breadcrumb = {
            "type": type,
            "level": level,
            "category": category or type,
            "timestamp": timestamp,
        }
        
        if message:
            breadcrumb["message"] = message
        
        if data:
            breadcrumb["data"] = data
        
        _context.breadcrumbs.append(breadcrumb)
    
    @staticmethod
    def get_breadcrumbs() -> list:
        """Get all breadcrumbs from context."""
        return getattr(_context, 'breadcrumbs', [])
    
    @staticmethod
    def clear_breadcrumbs():
        """Clear all breadcrumbs from context."""
        if hasattr(_context, 'breadcrumbs'):
            delattr(_context, 'breadcrumbs')
    
    @staticmethod
    def get_all() -> Dict[str, Any]:
        """Get all context data."""
        return {
            "user": Context.get_user(),
            "tags": Context.get_tags(),
            "extra": Context.get_extra(),
            "request": Context.get_request(),
            "breadcrumbs": Context.get_breadcrumbs(),
        }
