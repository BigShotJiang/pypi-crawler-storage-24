# WatchForge SDK Framework Handlers
from .django import DjangoHandler, DjangoIntegration

__all__ = ['DjangoHandler', 'DjangoIntegration']  # DjangoIntegration is deprecated alias
