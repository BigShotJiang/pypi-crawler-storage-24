"""
WatchForge Django Handler

Automatically captures all unhandled exceptions in Django views.
Just add DjangoHandler() to your register() call.

Usage in settings.py:
    from watchforge_sdk import register
    from watchforge_sdk.handlers.django import DjangoHandler
    
    register(
        endpoint="your-endpoint",
        integrations=[DjangoHandler()],
    )
"""
import sys
import logging

logger = logging.getLogger(__name__)

_MIDDLEWARE_INSTALLED = False


def _get_client_ip(request):
    """
    Extract client IP address from Django request.
    Handles proxies and load balancers.
    """
    if not request:
        return None
    
    # Try various headers (for proxies/load balancers)
    x_forwarded_for = None
    if hasattr(request, 'META'):
        x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
        if x_forwarded_for:
            # X-Forwarded-For can contain multiple IPs, get the first one
            ip = x_forwarded_for.split(',')[0].strip()
            return ip
        
        # Try other common headers
        ip = request.META.get('HTTP_X_REAL_IP')
        if ip:
            return ip
        
        # Fallback to REMOTE_ADDR
        ip = request.META.get('REMOTE_ADDR')
        if ip:
            return ip
    
    return None


class DjangoHandler:
    """
    Django framework handler for WatchForge.
    
    Automatically captures:
    - All unhandled exceptions in views
    - Request context (URL, method, headers)
    - User information (if authenticated)
    
    Usage:
        from watchforge_sdk import register
        from watchforge_sdk.handlers.django import DjangoHandler
        
        register(
            endpoint="your-endpoint",
            integrations=[DjangoHandler()],
        )
    """
    
    identifier = "django"
    
    def __init__(self, transaction_style="url", middleware_spans=True):
        self.transaction_style = transaction_style
        self.middleware_spans = middleware_spans
    
    def setup(self):
        """Called when the handler is set up."""
        _patch_django()


# Backward compatibility alias (deprecated)
DjangoIntegration = DjangoHandler


def _patch_django():
    """Patch Django to automatically capture exceptions."""
    global _MIDDLEWARE_INSTALLED
    
    if _MIDDLEWARE_INSTALLED:
        return
    
    try:
        from django.conf import settings
        from django.core.exceptions import ImproperlyConfigured
        
        # Check if Django is configured
        try:
            settings.INSTALLED_APPS
        except ImproperlyConfigured:
            logger.debug("Django not configured yet, skipping patch")
            return
        
        # Use Django's got_request_exception signal - most reliable way
        _connect_exception_signal()
        
        # Also patch Django REST Framework if installed
        _patch_drf_exception_handler()
        
        # Patch the base handler for non-view exceptions
        _patch_exception_handler()
        
        # Hook into database queries to capture as breadcrumbs
        _hook_database_queries()
        
        # Hook into HTTP requests to capture as breadcrumbs
        _hook_http_requests()
        
        # Mark as installed
        _MIDDLEWARE_INSTALLED = True
        print("[WatchForge] Django integration installed successfully")
        
    except ImportError:
        logger.warning("[WatchForge] Django not found, skipping integration")
    except Exception as e:
        logger.error(f"[WatchForge] Failed to install Django integration: {e}")


def _connect_exception_signal():
    """Connect to Django's got_request_exception signal."""
    try:
        from django.core.signals import got_request_exception
        
        def on_exception(sender, request=None, **kwargs):
            """Handle exception signal from Django."""
            import sys
            exc_info = sys.exc_info()
            
            if exc_info and exc_info[1]:
                exception = exc_info[1]
                print(f"[WatchForge] Caught exception via signal: {type(exception).__name__}: {exception}")
                _capture_exception_from_request(request, exc_info)
        
        # Connect the signal (use dispatch_uid to prevent double-connecting)
        got_request_exception.connect(on_exception, dispatch_uid="watchforge_exception_handler")
        print("[WatchForge] Connected to got_request_exception signal")
        
    except Exception as e:
        logger.error(f"[WatchForge] Failed to connect exception signal: {e}")


def _patch_exception_handler():
    """Patch Django's exception handling to capture errors."""
    try:
        from django.core.handlers.base import BaseHandler
        
        # Patch handle_uncaught_exception if it exists
        if hasattr(BaseHandler, 'handle_uncaught_exception'):
            original_handle_uncaught_exception = BaseHandler.handle_uncaught_exception
            
            def patched_handle_uncaught_exception(self, request, resolver, exc_info):
                """Patched exception handler that sends to WatchForge."""
                _capture_exception_from_request(request, exc_info)
                return original_handle_uncaught_exception(self, request, resolver, exc_info)
            
            BaseHandler.handle_uncaught_exception = patched_handle_uncaught_exception
        
        # Also patch the WSGI handler for more complete coverage
        _patch_wsgi_handler()
        
    except Exception as e:
        logger.error(f"[WatchForge] Failed to patch exception handler: {e}")


def _patch_drf_exception_handler():
    """Patch Django REST Framework's exception handling."""
    try:
        from rest_framework import views as drf_views
        
        original_handler = drf_views.exception_handler
        
        def patched_exception_handler(exc, context):
            """Patched DRF exception handler that sends to WatchForge."""
            # Capture ALL exceptions (including database errors, etc.)
            try:
                request = context.get('request') if context else None
                print(f"[WatchForge] DRF exception handler called: {type(exc).__name__}: {exc}")
                _capture_drf_exception(exc, request)
            except Exception as e:
                print(f"[WatchForge] Error capturing DRF exception: {e}")
                import traceback
                traceback.print_exc()
            
            # Call original handler
            return original_handler(exc, context)
        
        drf_views.exception_handler = patched_exception_handler
        print("[WatchForge] Django REST Framework exception handler patched")
        
    except ImportError:
        print("[WatchForge] Django REST Framework not installed, skipping DRF patch")
    except Exception as e:
        print(f"[WatchForge] Could not patch DRF: {e}")
        import traceback
        traceback.print_exc()


def _add_middleware_to_settings():
    """Add WatchForge middleware to Django settings."""
    try:
        from django.conf import settings
        
        middleware_path = 'watchforge_sdk.handlers.django.WatchForgeMiddleware'
        
        # Check if middleware is already added
        middleware = list(getattr(settings, 'MIDDLEWARE', []))
        if middleware_path not in middleware:
            # Add at the beginning to catch all exceptions
            middleware.insert(0, middleware_path)
            settings.MIDDLEWARE = middleware
            logger.debug("[WatchForge] Middleware added to settings")
        
    except Exception as e:
        logger.debug(f"[WatchForge] Could not add middleware to settings: {e}")


def _capture_drf_exception(exc, request):
    """Capture a DRF exception."""
    try:
        from watchforge_sdk import capture_exception, flush
        from watchforge_sdk.client import _DSN, _DEBUG
        
        if not _DSN:
            if _DEBUG:
                print("[WatchForge] No DSN set, skipping DRF exception capture")
            return
        
        # Only skip HTTP exceptions (400, 401, 403, 404, etc.) - capture all 500s and database errors
        from rest_framework.exceptions import APIException
        from django.db import DatabaseError
        
        # Skip only client errors (4xx), but capture server errors (5xx) and database errors
        if isinstance(exc, APIException):
            # Check if it's a 4xx error (client error) or 5xx (server error)
            status_code = getattr(exc, 'status_code', None)
            if status_code and 400 <= status_code < 500:
                # These are handled client errors, not crashes
                if _DEBUG:
                    print(f"[WatchForge] Skipping client error: {status_code}")
                return
            # 5xx errors should be captured
        
        # Always capture database errors
        if isinstance(exc, DatabaseError):
            if _DEBUG:
                print(f"[WatchForge] Capturing database error: {type(exc).__name__}")
        
        if _DEBUG:
            print(f"[WatchForge] Capturing DRF exception: {type(exc).__name__}: {exc}")
        
        # Build request context
        request_data = None
        user_data = None
        
        if request:
            try:
                # DRF request wraps Django request
                django_request = getattr(request, '_request', request)
                
                # Extract query parameters
                query_params = {}
                if hasattr(request, 'query_params'):
                    query_params = dict(request.query_params)
                elif hasattr(django_request, 'GET'):
                    query_params = dict(django_request.GET)
                
                # Extract request body
                body = None
                try:
                    if hasattr(request, 'data'):
                        # DRF request has parsed data
                        body = dict(request.data) if hasattr(request.data, 'items') else request.data
                    elif hasattr(django_request, 'body'):
                        body_bytes = django_request.body
                        if body_bytes:
                            try:
                                import json
                                body = json.loads(body_bytes.decode('utf-8'))
                            except (json.JSONDecodeError, UnicodeDecodeError):
                                body_str = body_bytes.decode('utf-8', errors='ignore')
                                if len(body_str) > 10000:
                                    body = body_str[:10000] + "... (truncated)"
                                else:
                                    body = body_str
                except Exception as e:
                    if _DEBUG:
                        print(f"[WatchForge] Error extracting DRF request body: {e}")
                
                # Extract headers
                headers = {}
                if hasattr(request, 'headers'):
                    for key, value in request.headers.items():
                        lower_key = key.lower()
                        if lower_key not in ('authorization', 'cookie', 'x-csrftoken', 'x-api-key'):
                            headers[key] = value
                elif hasattr(django_request, 'META'):
                    for key, value in django_request.META.items():
                        if key.startswith('HTTP_'):
                            header_name = key[5:].replace('_', '-').title()
                            lower_key = header_name.lower()
                            if lower_key not in ('authorization', 'cookie', 'x-csrftoken', 'x-api-key'):
                                headers[header_name] = value
                
                request_data = {
                    'url': django_request.build_absolute_uri() if hasattr(django_request, 'build_absolute_uri') else str(request.path),
                    'method': request.method,
                    'query': query_params,  # Use 'query' instead of 'query_string'
                    'headers': headers,
                }
                
                # Add body if available
                if body is not None:
                    request_data['body'] = body
                
                # Add IP address
                ip_address = _get_client_ip(django_request)
                if ip_address:
                    request_data['ip'] = ip_address
                    
            except Exception as e:
                if _DEBUG:
                    print(f"[WatchForge] Error building DRF request data: {e}")
                pass
            
            # Get user info
            try:
                user = getattr(request, 'user', None)
                if user and hasattr(user, 'is_authenticated') and user.is_authenticated:
                    # Get client IP address
                    ip_address = _get_client_ip(django_request)
                    
                    user_data = {
                        'id': str(user.id),
                        'email': getattr(user, 'email', ''),
                        'username': getattr(user, 'username', ''),
                        'ip_address': ip_address,  # ✅ Add IP address
                    }
            except Exception:
                pass
        
        if _DEBUG:
            print(f"[WatchForge] Capturing DRF exception: {type(exc).__name__}: {exc}")
        
        capture_exception(exc, request=request_data, user=user_data)
        flush()
        
    except Exception as e:
        logger.error(f"[WatchForge] Error capturing DRF exception: {e}")


def _patch_wsgi_handler():
    """Patch Django's WSGI handler."""
    try:
        from django.core.handlers.wsgi import WSGIHandler
        
        original_call = WSGIHandler.__call__
        
        def patched_call(self, environ, start_response):
            try:
                return original_call(self, environ, start_response)
            except Exception:
                # Get exception info
                exc_info = sys.exc_info()
                _capture_exception_simple(exc_info)
                raise
        
        WSGIHandler.__call__ = patched_call
        
    except Exception as e:
        logger.debug(f"[WatchForge] Could not patch WSGI handler: {e}")


def _capture_exception_from_request(request, exc_info):
    """Capture exception with request context."""
    try:
        from watchforge_sdk import capture_exception, flush
        from watchforge_sdk.client import _DSN, _DEBUG
        
        if not _DSN:
            if _DEBUG:
                print("[WatchForge] No DSN set, skipping exception capture")
            return
        
        # Get exception from exc_info (preserves traceback)
        exception = exc_info[1] if exc_info and len(exc_info) > 1 else None
        if not exception:
            # Try to get from sys.exc_info as fallback
            import sys
            exc_type, exc_value, exc_traceback = sys.exc_info()
            if exc_value:
                exception = exc_value
                # Ensure traceback is attached
                if exc_traceback and not hasattr(exception, '__traceback__'):
                    exception.__traceback__ = exc_traceback
        
        if not exception:
            if _DEBUG:
                print("[WatchForge] No exception found in exc_info")
            return
        
        # Ensure exception has traceback
        if not hasattr(exception, '__traceback__') or exception.__traceback__ is None:
            if exc_info and len(exc_info) > 2:
                exception.__traceback__ = exc_info[2]
            else:
                import sys
                _, _, exc_traceback = sys.exc_info()
                if exc_traceback:
                    exception.__traceback__ = exc_traceback
        
        if _DEBUG:
            print(f"[WatchForge] Capturing exception: {type(exception).__name__}: {exception}")
            print(f"[WatchForge] Exception has traceback: {hasattr(exception, '__traceback__') and exception.__traceback__ is not None}")
        
        # Build request context
        request_data = None
        user_data = None
        
        if request:
            try:
                # Extract query parameters
                query_params = {}
                if hasattr(request, 'GET'):
                    query_params = dict(request.GET)
                elif hasattr(request, 'query_params'):
                    query_params = dict(request.query_params)
                
                # Extract request body
                body = None
                try:
                    if hasattr(request, 'body'):
                        body_bytes = request.body
                        if body_bytes:
                            # Try to parse as JSON
                            try:
                                import json
                                body = json.loads(body_bytes.decode('utf-8'))
                            except (json.JSONDecodeError, UnicodeDecodeError):
                                # If not JSON, store as string (limit size)
                                body_str = body_bytes.decode('utf-8', errors='ignore')
                                # Limit body size to 10KB to avoid huge payloads
                                if len(body_str) > 10000:
                                    body = body_str[:10000] + "... (truncated)"
                                else:
                                    body = body_str
                except Exception as e:
                    if _DEBUG:
                        print(f"[WatchForge] Error extracting request body: {e}")
                
                # Extract headers (exclude sensitive ones)
                headers = {}
                if hasattr(request, 'headers'):
                    for key, value in request.headers.items():
                        lower_key = key.lower()
                        # Exclude sensitive headers
                        if lower_key not in ('authorization', 'cookie', 'x-csrftoken', 'x-api-key'):
                            headers[key] = value
                elif hasattr(request, 'META'):
                    # Fallback for older Django versions
                    for key, value in request.META.items():
                        if key.startswith('HTTP_'):
                            header_name = key[5:].replace('_', '-').title()
                            lower_key = header_name.lower()
                            if lower_key not in ('authorization', 'cookie', 'x-csrftoken', 'x-api-key'):
                                headers[header_name] = value
                
                request_data = {
                    'url': request.build_absolute_uri() if hasattr(request, 'build_absolute_uri') else request.path,
                    'method': request.method,
                    'query': query_params,  # Use 'query' instead of 'query_string' for consistency
                    'headers': headers,
                }
                
                # Add body if available
                if body is not None:
                    request_data['body'] = body
                
                # Add IP address
                ip_address = _get_client_ip(request)
                if ip_address:
                    request_data['ip'] = ip_address
                
            except Exception as e:
                if _DEBUG:
                    print(f"[WatchForge] Error building request data: {e}")
                pass
            
            # Get user info if authenticated
            try:
                if hasattr(request, 'user') and request.user.is_authenticated:
                    # Get client IP address
                    ip_address = _get_client_ip(request)
                    
                    user_data = {
                        'id': str(request.user.id),
                        'email': getattr(request.user, 'email', ''),
                        'username': getattr(request.user, 'username', ''),
                        'ip_address': ip_address,  # ✅ Add IP address
                    }
            except Exception:
                pass
        
        # Capture the exception with full context
        # IMPORTANT: Capture immediately while traceback is still available
        try:
            capture_exception(
                exception,
                request=request_data,
                user=user_data,
            )
            
            # Flush immediately to ensure it's sent
            flush()
        except Exception as e:
            logger.error(f"[WatchForge] Error in capture_exception: {e}")
            import traceback
            traceback.print_exc()
        
        if _DEBUG:
            print("[WatchForge] Exception captured and flushed successfully")
        
    except Exception as e:
        logger.error(f"[WatchForge] Error capturing exception: {e}")
        import traceback
        traceback.print_exc()


def _capture_exception_simple(exc_info):
    """Capture exception without request context."""
    try:
        from watchforge_sdk import capture_exception, flush
        from watchforge_sdk.client import _DSN
        
        if not _DSN:
            return
        
        exception = exc_info[1] if exc_info else None
        if not exception:
            return
        
        capture_exception(exception)
        flush()
        
    except Exception as e:
        logger.error(f"[WatchForge] Error capturing exception: {e}")


# Middleware class for manual installation (optional)
class WatchForgeMiddleware:
    """
    Django middleware for WatchForge.
    
    You can add this to MIDDLEWARE in settings.py for explicit control:
        MIDDLEWARE = [
            ...
            'watchforge_sdk.handlers.django.WatchForgeMiddleware',
        ]
    
    Or just use DjangoHandler() which patches automatically.
    """
    
    def __init__(self, get_response):
        self.get_response = get_response
    
    def __call__(self, request):
        return self.get_response(request)
    
    def process_exception(self, request, exception):
        """Capture unhandled exceptions."""
        try:
            from watchforge_sdk import capture_exception, flush
            from watchforge_sdk.client import _DSN
            
            if not _DSN:
                return None
            
            # Build request context
            query_params = {}
            if hasattr(request, 'GET'):
                query_params = dict(request.GET)
            
            # Extract request body
            body = None
            try:
                if hasattr(request, 'body'):
                    body_bytes = request.body
                    if body_bytes:
                        try:
                            import json
                            body = json.loads(body_bytes.decode('utf-8'))
                        except (json.JSONDecodeError, UnicodeDecodeError):
                            body_str = body_bytes.decode('utf-8', errors='ignore')
                            if len(body_str) > 10000:
                                body = body_str[:10000] + "... (truncated)"
                            else:
                                body = body_str
            except Exception:
                pass
            
            # Extract headers
            headers = {}
            if hasattr(request, 'headers'):
                for key, value in request.headers.items():
                    lower_key = key.lower()
                    if lower_key not in ('authorization', 'cookie', 'x-csrftoken', 'x-api-key'):
                        headers[key] = value
            elif hasattr(request, 'META'):
                for key, value in request.META.items():
                    if key.startswith('HTTP_'):
                        header_name = key[5:].replace('_', '-').title()
                        lower_key = header_name.lower()
                        if lower_key not in ('authorization', 'cookie', 'x-csrftoken', 'x-api-key'):
                            headers[header_name] = value
            
            request_data = {
                'url': request.build_absolute_uri() if hasattr(request, 'build_absolute_uri') else request.path,
                'method': request.method,
                'query': query_params,
                'headers': headers,
            }
            
            if body is not None:
                request_data['body'] = body
            
            ip_address = _get_client_ip(request)
            if ip_address:
                request_data['ip'] = ip_address
            
            # Get user info
            user_data = None
            if hasattr(request, 'user') and request.user.is_authenticated:
                # Get client IP address
                ip_address = _get_client_ip(request)
                
                user_data = {
                    'id': str(request.user.id),
                    'email': getattr(request.user, 'email', ''),
                    'username': getattr(request.user, 'username', ''),
                    'ip_address': ip_address,  # ✅ Add IP address
                }
            
            capture_exception(exception, request=request_data, user=user_data)
            flush()
            
        except Exception as e:
            logger.error(f"[WatchForge] Middleware error: {e}")
        
        return None  # Let Django handle the error normally


def _hook_database_queries():
    """Hook into Django's database queries to capture them as breadcrumbs."""
    try:
        from django.db import connection
        from django.db.backends.signals import query_executed
        from watchforge_sdk.context import Context
        from watchforge_sdk.client import _DEBUG
        
        def on_query_executed(sender, query, **kwargs):
            """Capture database query as breadcrumb."""
            try:
                # Only capture SELECT, INSERT, UPDATE, DELETE queries
                query_upper = query.strip().upper()
                if not any(query_upper.startswith(cmd) for cmd in ['SELECT', 'INSERT', 'UPDATE', 'DELETE']):
                    return
                
                # Extract table name if possible
                table = None
                if query_upper.startswith('SELECT'):
                    # Try to extract table from SELECT ... FROM table
                    parts = query_upper.split('FROM')
                    if len(parts) > 1:
                        table_part = parts[1].strip().split()[0]
                        table = table_part.strip('`"[]')
                elif query_upper.startswith('INSERT'):
                    # INSERT INTO table
                    parts = query_upper.split('INTO')
                    if len(parts) > 1:
                        table_part = parts[1].strip().split()[0]
                        table = table_part.strip('`"[]')
                elif query_upper.startswith('UPDATE'):
                    # UPDATE table
                    parts = query_upper.split()
                    if len(parts) > 1:
                        table = parts[1].strip('`"[]')
                elif query_upper.startswith('DELETE'):
                    # DELETE FROM table
                    parts = query_upper.split('FROM')
                    if len(parts) > 1:
                        table_part = parts[1].strip().split()[0]
                        table = table_part.strip('`"[]')
                
                # Get query duration
                duration = kwargs.get('duration', 0)
                
                # Truncate long queries
                query_display = query
                if len(query_display) > 500:
                    query_display = query_display[:500] + "... (truncated)"
                
                # Get current timestamp with millisecond precision
                import datetime
                try:
                    from zoneinfo import ZoneInfo
                    ist_tz = ZoneInfo("Asia/Kolkata")
                except ImportError:
                    try:
                        from backports.zoneinfo import ZoneInfo
                        ist_tz = ZoneInfo("Asia/Kolkata")
                    except ImportError:
                        try:
                            import pytz
                            ist_tz = pytz.timezone("Asia/Kolkata")
                        except ImportError:
                            ist_tz = datetime.timezone(datetime.timedelta(hours=5, minutes=30))
                
                # Create timestamp with millisecond precision
                now = datetime.datetime.now(ist_tz)
                timestamp_ms = now.isoformat()
                
                # Add breadcrumb with timestamp
                Context.add_breadcrumb(
                    type="query",
                    message=query_display,
                    level="info",
                    category="db.query",
                    timestamp=timestamp_ms,
                    data={
                        "query": query_display,
                        "duration": round(duration * 1000, 2) if duration else None,  # Convert to ms
                        "table": table,
                        "timestamp_ms": round(duration * 1000, 2) if duration else None,  # Query execution time in ms
                    }
                )
                
                if _DEBUG:
                    print(f"[WatchForge] Captured query breadcrumb: {table or 'unknown'} ({duration*1000:.2f}ms)")
                    
            except Exception as e:
                if _DEBUG:
                    print(f"[WatchForge] Error capturing query breadcrumb: {e}")
        
        # Connect to query_executed signal
        query_executed.connect(on_query_executed, dispatch_uid="watchforge_query_handler")
        
        if _DEBUG:
            print("[WatchForge] Database query hook installed")
            
    except ImportError:
        logger.debug("[WatchForge] Django database signals not available")
    except Exception as e:
        logger.debug(f"[WatchForge] Failed to hook database queries: {e}")


def _hook_http_requests():
    """Hook into Django HTTP requests to capture them as breadcrumbs."""
    try:
        from django.core.signals import request_started, request_finished
        from watchforge_sdk.context import Context
        from watchforge_sdk.client import _DEBUG
        
        # Store request info per thread
        import threading
        _request_info = threading.local()
        
        def on_request_started(sender, **kwargs):
            """Capture request start."""
            try:
                request = kwargs.get('environ', {}).get('PATH_INFO') or kwargs.get('request')
                if request:
                    if hasattr(request, 'method') and hasattr(request, 'path'):
                        _request_info.url = request.build_absolute_uri() if hasattr(request, 'build_absolute_uri') else request.path
                        _request_info.method = request.method
                        _request_info.start_time = __import__('time').time()
            except Exception:
                pass
        
        def on_request_finished(sender, **kwargs):
            """Capture request finish as breadcrumb."""
            try:
                request = kwargs.get('request')
                if not request:
                    return
                
                # Get request info
                url = getattr(_request_info, 'url', None) or (request.build_absolute_uri() if hasattr(request, 'build_absolute_uri') else request.path)
                method = getattr(_request_info, 'method', None) or getattr(request, 'method', 'UNKNOWN')
                start_time = getattr(_request_info, 'start_time', None)
                
                # Calculate duration
                duration = None
                if start_time:
                    duration = (__import__('time').time() - start_time) * 1000  # Convert to ms
                
                # Get status code if available
                status_code = None
                if hasattr(request, 'response') and hasattr(request.response, 'status_code'):
                    status_code = request.response.status_code
                elif hasattr(kwargs, 'response') and hasattr(kwargs['response'], 'status_code'):
                    status_code = kwargs['response'].status_code
                
                # Get current timestamp with millisecond precision
                import datetime
                try:
                    from zoneinfo import ZoneInfo
                    ist_tz = ZoneInfo("Asia/Kolkata")
                except ImportError:
                    try:
                        from backports.zoneinfo import ZoneInfo
                        ist_tz = ZoneInfo("Asia/Kolkata")
                    except ImportError:
                        try:
                            import pytz
                            ist_tz = pytz.timezone("Asia/Kolkata")
                        except ImportError:
                            ist_tz = datetime.timezone(datetime.timedelta(hours=5, minutes=30))
                
                # Create timestamp with millisecond precision
                now = datetime.datetime.now(ist_tz)
                timestamp_ms = now.isoformat()
                
                # Add breadcrumb with timestamp
                Context.add_breadcrumb(
                    type="http",
                    message=f"{method} {url}",
                    level="info",
                    category="http",
                    timestamp=timestamp_ms,
                    data={
                        "url": url,
                        "method": method,
                        "status_code": status_code,
                        "duration": round(duration, 2) if duration else None,
                    }
                )
                
                if _DEBUG:
                    print(f"[WatchForge] Captured HTTP breadcrumb: {method} {url} ({status_code or 'N/A'})")
                
                # Clear request info
                if hasattr(_request_info, 'url'):
                    delattr(_request_info, 'url')
                if hasattr(_request_info, 'method'):
                    delattr(_request_info, 'method')
                if hasattr(_request_info, 'start_time'):
                    delattr(_request_info, 'start_time')
                    
            except Exception as e:
                if _DEBUG:
                    print(f"[WatchForge] Error capturing HTTP breadcrumb: {e}")
        
        # Connect to request signals
        request_started.connect(on_request_started, dispatch_uid="watchforge_request_started")
        request_finished.connect(on_request_finished, dispatch_uid="watchforge_request_finished")
        
        if _DEBUG:
            print("[WatchForge] HTTP request hook installed")
            
    except ImportError:
        logger.debug("[WatchForge] Django request signals not available")
    except Exception as e:
        logger.debug(f"[WatchForge] Failed to hook HTTP requests: {e}")
