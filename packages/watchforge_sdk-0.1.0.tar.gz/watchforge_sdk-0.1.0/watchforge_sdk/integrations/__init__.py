# WatchForge SDK Integrations (deprecated - use watchforge_sdk.handlers instead)
# This module is kept for backward compatibility only
from ..handlers.django import DjangoHandler, DjangoIntegration

__all__ = ['DjangoHandler', 'DjangoIntegration']
