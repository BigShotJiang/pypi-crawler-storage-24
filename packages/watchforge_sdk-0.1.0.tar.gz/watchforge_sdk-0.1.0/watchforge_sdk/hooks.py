"""
Automatic hooks for WatchForge SDK
- Exception hook for unhandled exceptions
- Logging handler for logger errors/warnings
"""
import sys
import logging
from typing import Optional


def _get_dsn():
    """Get DSN from client module."""
    from .client import _DSN
    return _DSN


def _capture_exception(exc):
    """Capture exception using client."""
    from .client import capture_exception
    capture_exception(exc)


def _capture_message(message, level, tags=None, extra=None):
    """Capture message using client."""
    from .client import capture_message
    capture_message(message, level=level, tags=tags, extra=extra)


# Store original exception hook
_original_excepthook = None

# Store logging handler instance
_logging_handler = None


class WatchForgeLoggingHandler(logging.Handler):
    """
    Logging handler that automatically captures log records to WatchForge.
    Captures all levels based on the configured minimum level (default: INFO).
    """
    
    def __init__(self, level=logging.WARNING):
        super().__init__(level)
        self.setFormatter(logging.Formatter())
    
    def emit(self, record):
        """
        Emit a log record to WatchForge.
        """
        if not _get_dsn():
            return
        
        try:
            # Map logging levels to WatchForge levels
            level_map = {
                logging.CRITICAL: "error",
                logging.ERROR: "error",
                logging.WARNING: "warning",
                logging.INFO: "info",
                logging.DEBUG: "info",
            }
            
            watchforge_level = level_map.get(record.levelno, "info")
            
            # Build message
            message = self.format(record)
            
            # Extract exception info if present
            exception = None
            if record.exc_info:
                exception = record.exc_info[1]
            
            # Build tags from logger name
            tags = {
                "logger": record.name,
                "module": record.module,
                "function": record.funcName,
            }
            
            # Build extra from record attributes
            extra = {
                "filename": record.filename,
                "lineno": record.lineno,
                "pathname": record.pathname,
                "process": record.process,
                "thread": record.threadName,
            }
            
            # Add any extra fields from the log record
            if hasattr(record, 'watchforge_tags'):
                tags.update(record.watchforge_tags)
            if hasattr(record, 'watchforge_extra'):
                extra.update(record.watchforge_extra)
            
            # Capture the log record
            if exception:
                _capture_exception(exception)
            else:
                _capture_message(message, level=watchforge_level, tags=tags, extra=extra)
        
        except Exception:
            # Don't let logging handler errors break the application
            pass


def _exception_hook(exc_type, exc_value, exc_traceback):
    """
    Global exception hook to capture unhandled exceptions.
    """
    # Call original hook first (to maintain default behavior)
    if _original_excepthook:
        _original_excepthook(exc_type, exc_value, exc_traceback)
    
    # Capture to WatchForge
    if _get_dsn() and exc_value:
        try:
            _capture_exception(exc_value)
        except Exception:
            # Don't let exception hook errors break the application
            pass


def install_exception_hook():
    """
    Install the global exception hook to capture unhandled exceptions.
    """
    global _original_excepthook
    
    if _original_excepthook is None:
        _original_excepthook = sys.excepthook
        sys.excepthook = _exception_hook


def uninstall_exception_hook():
    """
    Uninstall the global exception hook and restore original.
    """
    global _original_excepthook
    
    if _original_excepthook:
        sys.excepthook = _original_excepthook
        _original_excepthook = None


def install_logging_handler(level=logging.WARNING, logger_name=None):
    """
    Install logging handler to automatically capture logger errors/warnings.
    
    Args:
        level: Minimum log level to capture (default: WARNING)
        logger_name: Specific logger name, or None for root logger
    
    Returns:
        The installed handler instance
    """
    global _logging_handler
    
    if _logging_handler is None:
        _logging_handler = WatchForgeLoggingHandler(level=level)
        
        # Install on root logger or specific logger
        if logger_name:
            logger = logging.getLogger(logger_name)
        else:
            logger = logging.getLogger()
        
        logger.addHandler(_logging_handler)
    
    return _logging_handler


def uninstall_logging_handler(logger_name=None):
    """
    Uninstall the logging handler.
    
    Args:
        logger_name: Specific logger name, or None for root logger
    """
    global _logging_handler
    
    if _logging_handler:
        if logger_name:
            logger = logging.getLogger(logger_name)
        else:
            logger = logging.getLogger()
        
        logger.removeHandler(_logging_handler)
        _logging_handler = None


def auto_capture_exceptions(func):
    """
    Decorator to automatically capture exceptions from a function.
    Useful for wrapping functions where you want to capture caught exceptions.
    
    Example:
        from watchforge_sdk import register
        from watchforge_sdk.hooks import auto_capture_exceptions
        
        register(endpoint="...")
        
        @auto_capture_exceptions
        def my_function():
            # If this raises an exception, it will be automatically captured
            raise ValueError("This will be captured")
    """
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception as e:
            if _get_dsn():
                _capture_exception(e)
            raise  # Re-raise the exception
    return wrapper
