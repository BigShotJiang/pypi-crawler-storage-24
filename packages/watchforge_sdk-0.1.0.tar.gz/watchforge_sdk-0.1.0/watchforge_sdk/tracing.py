"""
Trace and Span instrumentation for WatchForge Python SDK.
"""
import uuid
import time
import threading
from typing import Dict, Any, Optional, List
from datetime import datetime
from .transport import send_trace, set_debug as set_transport_debug
from .context import Context

# Thread-local storage for active transaction and spans
_thread_local = threading.local()

_DSN = None
_ENV = "production"
_DEBUG = False


def init_tracing(dsn: str, environment: str = "production", debug: bool = False):
    """Initialize tracing with DSN and environment."""
    global _DSN, _ENV, _DEBUG
    _DSN = dsn
    _ENV = environment
    _DEBUG = debug
    set_transport_debug(debug)


class Span:
    """Represents a single span within a trace."""
    
    def __init__(self, span_id: str, op: str, description: str = "", parent_span_id: Optional[str] = None, data: Optional[Dict[str, Any]] = None):
        self.span_id = span_id
        self.op = op
        self.description = description
        self.parent_span_id = parent_span_id
        self.data = data or {}
        self.start_timestamp = time.time() * 1000  # milliseconds
        self.finish_timestamp = None
        self.duration_ms = 0
        self.status = "ok"
        self.status_code = None
        self.tags = {}
    
    def finish(self, status: str = "ok", status_code: Optional[int] = None):
        """Finish the span and calculate duration."""
        self.finish_timestamp = time.time() * 1000
        self.duration_ms = self.finish_timestamp - self.start_timestamp
        self.status = status
        self.status_code = status_code
    
    def set_tag(self, key: str, value: Any):
        """Set a tag on the span."""
        self.tags[key] = value
    
    def set_data(self, key: str, value: Any):
        """Set data on the span."""
        self.data[key] = value
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert span to dictionary for sending."""
        return {
            "span_id": self.span_id,
            "parent_span_id": self.parent_span_id,
            "op": self.op,
            "description": self.description,
            "start_timestamp": datetime.fromtimestamp(self.start_timestamp / 1000.0).isoformat() + "Z",
            "finish_timestamp": datetime.fromtimestamp(self.finish_timestamp / 1000.0).isoformat() + "Z" if self.finish_timestamp else None,
            "duration_ms": self.duration_ms,
            "status": self.status,
            "status_code": self.status_code,
            "data": self.data,
            "tags": self.tags,
            "timestamp": datetime.fromtimestamp(self.start_timestamp / 1000.0).isoformat() + "Z",
        }


class Transaction:
    """Represents a transaction (trace) containing multiple spans."""
    
    def __init__(self, trace_id: str, transaction: str, transaction_name: str = "", op: str = "http.server"):
        self.trace_id = trace_id
        self.transaction = transaction
        self.transaction_name = transaction_name or transaction
        self.op = op
        self.start_timestamp = time.time() * 1000
        self.finish_timestamp = None
        self.duration_ms = 0
        self.status = "ok"
        self.spans: List[Span] = []
        self.tags = {}
        self.contexts = {}
        self.user = None
        self.request = None
        self.release_version = None
        self.environment = _ENV
    
    def start_span(self, op: str, description: str = "", data: Optional[Dict[str, Any]] = None) -> Span:
        """Start a new span within this transaction."""
        parent_span_id = self.spans[-1].span_id if self.spans else None
        span = Span(
            span_id=str(uuid.uuid4()),
            op=op,
            description=description,
            parent_span_id=parent_span_id,
            data=data or {}
        )
        self.spans.append(span)
        return span
    
    def finish(self, status: str = "ok"):
        """Finish the transaction and send it to WatchForge."""
        self.finish_timestamp = time.time() * 1000
        self.duration_ms = self.finish_timestamp - self.start_timestamp
        self.status = status
        
        # Finish all unfinished spans
        for span in self.spans:
            if span.finish_timestamp is None:
                span.finish()
        
        # Build trace payload
        payload = {
            "trace_id": self.trace_id,
            "transaction": self.transaction,
            "transaction_name": self.transaction_name,
            "start_timestamp": datetime.fromtimestamp(self.start_timestamp / 1000.0).isoformat() + "Z",
            "finish_timestamp": datetime.fromtimestamp(self.finish_timestamp / 1000.0).isoformat() + "Z",
            "duration_ms": self.duration_ms,
            "status": self.status,
            "environment": self.environment,
            "release": self.release_version,
            "spans": [span.to_dict() for span in self.spans],
            "tags": self.tags,
            "contexts": self.contexts,
            "user": self.user,
            "request": self.request,
            "platform": "python",
            "sdk_name": "watchforge-python",
            "sdk_version": "0.1.0",
        }
        
        if _DEBUG:
            print(f"[WatchForge Trace] Sending trace: {self.transaction_name}")
            print(f"[WatchForge Trace] Spans: {len(self.spans)}")
        
        # Send trace
        if _DSN:
            send_trace(_DSN, payload)
        
        return payload
    
    def set_tag(self, key: str, value: Any):
        """Set a tag on the transaction."""
        self.tags[key] = value
    
    def set_user(self, user: Dict[str, Any]):
        """Set user context."""
        self.user = user
    
    def set_request(self, request: Dict[str, Any]):
        """Set request context."""
        self.request = request


def start_transaction(transaction: str, transaction_name: str = "", op: str = "http.server") -> Transaction:
    """
    Start a new transaction (trace).
    
    Args:
        transaction: Transaction identifier (e.g., "/api/users", "GET /orders")
        transaction_name: Human-readable name (defaults to transaction)
        op: Operation type (default: "http.server")
    
    Returns:
        Transaction object
    
    Example:
        with start_transaction("/api/users", "GET /api/users") as txn:
            with txn.start_span("db.query", "SELECT * FROM users") as span:
                # Execute query
                pass
    """
    trace_id = str(uuid.uuid4())
    txn = Transaction(trace_id, transaction, transaction_name, op)
    
    # Store in thread-local storage
    if not hasattr(_thread_local, 'transactions'):
        _thread_local.transactions = []
    _thread_local.transactions.append(txn)
    
    return txn


def get_current_transaction() -> Optional[Transaction]:
    """Get the current active transaction for this thread."""
    if hasattr(_thread_local, 'transactions') and _thread_local.transactions:
        return _thread_local.transactions[-1]
    return None


def finish_transaction(status: str = "ok"):
    """Finish the current transaction and send it."""
    txn = get_current_transaction()
    if txn:
        _thread_local.transactions.pop()
        return txn.finish(status)
    return None
