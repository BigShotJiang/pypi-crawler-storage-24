import time
import os
import atexit
import requests
import json
import re
from urllib.parse import urlparse

# Try to load .env file if python-dotenv is available
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass  # python-dotenv is optional

BUFFER = []
LAST_FLUSH = time.time()
FLUSH_INTERVAL = 5
_DEBUG = False  # Debug mode flag
_DSN_FOR_FLUSH = None  # Store DSN for exit flush
_API_URL_CACHE = {}  # Cache parsed API URLs


def parse_dsn(dsn: str) -> dict:
    """
    Parse a DSN string into its components.
    
    DSN format: https://PUBLIC_KEY@HOST:PORT/PROJECT_ID
    
    Examples:
        - https://abc123@watchforge.io/project-uuid
        - https://abc123@localhost:8001/project-uuid
        - http://abc123@127.0.0.1:8001/project-uuid
    
    Returns:
        dict with keys: scheme, public_key, host, port, project_id, api_url
    """
    # Pattern: scheme://public_key@host:port/project_id
    pattern = r'^(https?):\/\/([a-f0-9]+)@([^\/\:]+)(?:\:(\d+))?\/(.+)$'
    match = re.match(pattern, dsn, re.IGNORECASE)
    
    if not match:
        return None
    
    scheme = match.group(1)
    public_key = match.group(2)
    host = match.group(3)
    port = match.group(4)  # May be None
    project_id = match.group(5)
    
    # Build API URL from DSN components
    # For localhost/127.0.0.1, use http; for others, use original scheme
    if host in ('localhost', '127.0.0.1'):
        api_scheme = 'http'
    else:
        api_scheme = scheme
    
    if port:
        api_url = f"{api_scheme}://{host}:{port}/api/ingestion/events/"
    else:
        api_url = f"{api_scheme}://{host}/api/ingestion/events/"
    
    return {
        'scheme': scheme,
        'public_key': public_key,
        'host': host,
        'port': port,
        'project_id': project_id,
        'api_url': api_url,
    }


def get_api_url(dsn: str) -> str:
    """
    Get the API URL for a given DSN.
    
    Priority:
    1. WATCHFORGE_API_URL environment variable (if set)
    2. Derived from DSN host
    3. Default fallback
    """
    # Check environment variable override first
    env_url = os.getenv("WATCHFORGE_API_URL")
    if env_url:
        return env_url
    
    # Check cache
    if dsn in _API_URL_CACHE:
        return _API_URL_CACHE[dsn]
    
    # Parse DSN to get API URL
    parsed = parse_dsn(dsn)
    if parsed:
        api_url = parsed['api_url']
        _API_URL_CACHE[dsn] = api_url
        return api_url
    
    # Fallback default
    return "http://127.0.0.1:8001/api/ingestion/events/"


# Legacy: Keep API_URL for backward compatibility
API_URL = os.getenv("WATCHFORGE_API_URL", "http://127.0.0.1:8001/api/ingestion/events/")

def _flush_on_exit():
    """Flush any remaining events when program exits."""
    global BUFFER, _DSN_FOR_FLUSH, _DEBUG
    if BUFFER and _DSN_FOR_FLUSH:
        try:
            # Get API URL from DSN
            api_url = get_api_url(_DSN_FOR_FLUSH)
            
            # Direct flush implementation to avoid circular reference
            import requests
            response = requests.post(
                api_url,
                json=BUFFER,
                headers={"Authorization": f"DSN {_DSN_FOR_FLUSH}"},
                timeout=2,
            )
            if _DEBUG:
                print(f"WATCHFORGE SDK - Exit flush: {response.status_code}")
        except Exception:
            pass  # Don't raise errors on exit

def set_debug(debug):
    """Set debug mode."""
    global _DEBUG
    _DEBUG = debug

def _print_event_data(payload):
    """Print event data in a readable format."""
    global _DEBUG
    if not _DEBUG:
        return
    
    print("\n" + "=" * 80)
    print("WATCHFORGE SDK - EVENT DATA BEING SENT")
    print("=" * 80)
    print(json.dumps(payload, indent=2, default=str))
    print("=" * 80 + "\n")

def send_event(dsn, payload):
    global BUFFER, LAST_FLUSH, _DEBUG, _DSN_FOR_FLUSH

    # Print event data if debug mode is enabled
    _print_event_data(payload)

    if not dsn:
        if _DEBUG:
            print("WATCHFORGE SDK - ERROR: No DSN provided, event not sent")
        return

    # Store DSN for exit flush
    _DSN_FOR_FLUSH = dsn

    BUFFER.append(payload)

    if _DEBUG:
        print(f"WATCHFORGE SDK - Event added to buffer (size: {len(BUFFER)}/{10})")
        print(f"WATCHFORGE SDK - Will flush when buffer >= 10 or {FLUSH_INTERVAL}s elapsed")

    if len(BUFFER) >= 10 or time.time() - LAST_FLUSH > FLUSH_INTERVAL:
        flush(dsn)

def flush(dsn, force=False):
    """
    Flush events to backend.
    
    Args:
        dsn: DSN for authentication
        force: If True, flush immediately even if buffer is small
    """
    global BUFFER, LAST_FLUSH, _DEBUG

    if not BUFFER:
        if _DEBUG:
            print("WATCHFORGE SDK - No events to flush")
        return
    
    if not dsn:
        if _DEBUG:
            print("WATCHFORGE SDK - ERROR: No DSN provided, cannot send events")
        return
    
    # Get API URL from DSN
    api_url = get_api_url(dsn)
    
    try:
        # Print buffer if debug mode is enabled
        if _DEBUG and BUFFER:
            print("\n" + "=" * 80)
            print(f"WATCHFORGE SDK - FLUSHING {len(BUFFER)} EVENT(S) TO BACKEND")
            print(f"WATCHFORGE SDK - API URL: {api_url}")
            print("=" * 80)
            for i, event in enumerate(BUFFER, 1):
                print(f"\n--- Event {i}/{len(BUFFER)} ---")
                print(json.dumps(event, indent=2, default=str))
            print("=" * 80 + "\n")
        
        response = requests.post(
            api_url,
            json=BUFFER,
            headers={"Authorization": f"DSN {dsn}"},
            timeout=2,
        )
        
        if _DEBUG:
            print(f"WATCHFORGE SDK - Response Status: {response.status_code}")
            if response.status_code >= 400:
                print(f"WATCHFORGE SDK - Response Body: {response.text}")
        
        response.raise_for_status()  # Raise exception for bad status codes
        BUFFER = []
        LAST_FLUSH = time.time()
    except requests.exceptions.RequestException as e:
        if _DEBUG:
            print(f"\nWATCHFORGE SDK - ERROR SENDING EVENT: {type(e).__name__}: {e}")
            print(f"WATCHFORGE SDK - URL: {api_url}")
            print(f"WATCHFORGE SDK - Events will remain in buffer and retry on next flush\n")
        # Keep events in buffer for retry on next flush
        LAST_FLUSH = time.time()  # Update flush time to avoid immediate retry
    except Exception as e:
        if _DEBUG:
            print(f"\nWATCHFORGE SDK - UNEXPECTED ERROR: {type(e).__name__}: {e}\n")
        # Keep events in buffer for retry
        LAST_FLUSH = time.time()

def send_trace(dsn, payload):
    """
    Send a trace (transaction with spans) to WatchForge backend.
    
    Args:
        dsn: DSN for authentication
        payload: Trace payload dictionary
    """
    global _DEBUG
    
    if _DEBUG:
        print("\n" + "=" * 80)
        print("WATCHFORGE SDK - TRACE DATA BEING SENT")
        print("=" * 80)
        print(json.dumps(payload, indent=2, default=str))
        print("=" * 80 + "\n")
    
    if not dsn:
        if _DEBUG:
            print("WATCHFORGE SDK - ERROR: No DSN provided, trace not sent")
        return
    
    # Get trace API URL from DSN
    parsed = parse_dsn(dsn)
    if parsed:
        scheme = parsed['scheme']
        host = parsed['host']
        port = parsed['port']
        
        if host in ('localhost', '127.0.0.1'):
            api_scheme = 'http'
        else:
            api_scheme = scheme
        
        if port:
            trace_url = f"{api_scheme}://{host}:{port}/api/ingestion/trace/"
        else:
            trace_url = f"{api_scheme}://{host}/api/ingestion/trace/"
    else:
        trace_url = "http://127.0.0.1:8001/api/ingestion/trace/"
    
    try:
        response = requests.post(
            trace_url,
            json=payload,
            headers={"Authorization": f"DSN {dsn}"},
            timeout=5,
        )
        
        if _DEBUG:
            print(f"WATCHFORGE SDK - Trace Response Status: {response.status_code}")
            if response.status_code >= 400:
                print(f"WATCHFORGE SDK - Response Body: {response.text}")
        
        response.raise_for_status()
    except requests.exceptions.RequestException as e:
        if _DEBUG:
            print(f"\nWATCHFORGE SDK - ERROR SENDING TRACE: {type(e).__name__}: {e}")
            print(f"WATCHFORGE SDK - URL: {trace_url}\n")
    except Exception as e:
        if _DEBUG:
            print(f"\nWATCHFORGE SDK - UNEXPECTED ERROR: {type(e).__name__}: {e}\n")

# Register exit handler to flush events on program exit (after flush is defined)
atexit.register(_flush_on_exit)