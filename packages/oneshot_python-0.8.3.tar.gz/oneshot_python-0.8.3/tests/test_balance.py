"""Tests for OneShotClient.get_balance() and aget_balance().

Uses mock HTTP responses to verify the client correctly calls the
/v1/tools/balance endpoint and returns the parsed response.
"""

from __future__ import annotations

import json
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from eth_account import Account

from oneshot.client import OneShotClient

# Deterministic test key (never use with real funds)
TEST_PRIVATE_KEY = "0xac0974bec39a17e36ba4a6b4d238ff944bacb478cbed5efcae784d7bf4f2ff80"
TEST_ADDRESS = Account.from_key(TEST_PRIVATE_KEY).address

MOCK_BALANCE_RESPONSE = {
    "on_chain_balance": "125.500000",
    "credits_balance": "45.00",
    "currency": "USDC",
    "address": TEST_ADDRESS,
    "chain_id": 8453,
}


class TestGetBalance:
    """Synchronous get_balance() tests."""

    def test_calls_correct_endpoint(self) -> None:
        client = OneShotClient(TEST_PRIVATE_KEY)

        with patch.object(client, "call_free_get", return_value=MOCK_BALANCE_RESPONSE) as mock:
            result = client.get_balance()

        mock.assert_called_once_with("/v1/tools/balance")
        assert result == MOCK_BALANCE_RESPONSE

    def test_returns_all_fields(self) -> None:
        client = OneShotClient(TEST_PRIVATE_KEY)

        with patch.object(client, "call_free_get", return_value=MOCK_BALANCE_RESPONSE):
            result = client.get_balance()

        assert result["on_chain_balance"] == "125.500000"
        assert result["credits_balance"] == "45.00"
        assert result["currency"] == "USDC"
        assert result["address"] == TEST_ADDRESS
        assert result["chain_id"] == 8453

    def test_propagates_errors(self) -> None:
        client = OneShotClient(TEST_PRIVATE_KEY)

        with patch.object(client, "call_free_get", side_effect=Exception("Network error")):
            with pytest.raises(Exception, match="Network error"):
                client.get_balance()


class TestAgetBalance:
    """Async aget_balance() tests."""

    @pytest.mark.asyncio
    async def test_calls_correct_endpoint(self) -> None:
        client = OneShotClient(TEST_PRIVATE_KEY)

        with patch.object(
            client, "acall_free_get", new_callable=AsyncMock, return_value=MOCK_BALANCE_RESPONSE
        ) as mock:
            result = await client.aget_balance()

        mock.assert_called_once_with("/v1/tools/balance")
        assert result == MOCK_BALANCE_RESPONSE

    @pytest.mark.asyncio
    async def test_returns_all_fields(self) -> None:
        client = OneShotClient(TEST_PRIVATE_KEY)

        with patch.object(
            client, "acall_free_get", new_callable=AsyncMock, return_value=MOCK_BALANCE_RESPONSE
        ):
            result = await client.aget_balance()

        assert result["on_chain_balance"] == "125.500000"
        assert result["credits_balance"] == "45.00"
        assert result["currency"] == "USDC"

    @pytest.mark.asyncio
    async def test_propagates_errors(self) -> None:
        client = OneShotClient(TEST_PRIVATE_KEY)

        with patch.object(
            client, "acall_free_get", new_callable=AsyncMock, side_effect=Exception("Timeout")
        ):
            with pytest.raises(Exception, match="Timeout"):
                await client.aget_balance()
