"""EIP-712 payment signing for x402 protocol (USDC TransferWithAuthorization).

Produces x402 PaymentPayload v2 format compatible with @x402/core SDK:
  { x402Version: 2, accepted: { scheme, network, amount, asset, payTo, ... },
    payload: { signature: "0x...", authorization: { from, to, value, ... } } }

The payload is base64-encoded and sent as the `payment-signature` header.
"""

from __future__ import annotations

import base64
import json
import os
import time
from typing import Any, TypedDict

from eth_account import Account
from eth_account.messages import encode_typed_data


class PaymentRequirements(TypedDict, total=False):
    """x402 v2 PaymentRequirements from server's accepts[] array."""

    scheme: str
    network: str
    amount: str
    asset: str
    payTo: str
    maxTimeoutSeconds: int
    extra: dict[str, Any]


class PaymentAuthorization(TypedDict):
    """x402 PaymentPayload v2 format."""

    x402Version: int
    accepted: dict[str, Any]
    payload: dict[str, Any]


class ParsedPaymentRequired(TypedDict, total=False):
    """Full parsed 402 response with Bazaar discovery metadata."""

    accepted: PaymentRequirements
    resource: dict[str, Any]
    extensions: dict[str, Any]


def parse_payment_required(header: str | None) -> ParsedPaymentRequired:
    """Decode the base64 PAYMENT-REQUIRED header and return accepted requirements + Bazaar metadata.

    Falls back to sensible defaults if the header is missing or unparseable.
    """
    if header:
        try:
            decoded = base64.b64decode(header).decode()
            parsed = json.loads(decoded)
            # x402 v2: { x402Version: 2, accepts: [...], resource: {...}, extensions: {...} }
            accepts = parsed.get("accepts", [])
            if accepts:
                result: ParsedPaymentRequired = {"accepted": accepts[0]}
                if parsed.get("resource"):
                    result["resource"] = parsed["resource"]
                if parsed.get("extensions"):
                    result["extensions"] = parsed["extensions"]
                return result
        except Exception:
            pass

    # Fallback with production defaults
    return ParsedPaymentRequired(
        accepted=PaymentRequirements(
            scheme="exact",
            network="eip155:8453",
            amount="0",
            asset="0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913",
            payTo="",
            maxTimeoutSeconds=300,
            extra={"name": "USD Coin", "version": "2"},
        ),
    )


def sign_payment_authorization(
    *,
    private_key: str,
    from_address: str,
    to_address: str,
    amount: str,
    token_address: str,
    chain_id: int,
    network: str,
    accepted: PaymentRequirements | None = None,
    resource: dict[str, Any] | None = None,
    extensions: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Create an EIP-712 TransferWithAuthorization signature for USDC.

    Args:
        private_key: Hex-encoded private key (with or without 0x prefix).
        from_address: Sender wallet address.
        to_address: Recipient (merchant) address.
        amount: Amount in USDC human-readable units (e.g. "1.50").
        token_address: USDC contract address.
        chain_id: EVM chain ID (8453 for Base Mainnet).
        network: CAIP-2 network string (e.g. "eip155:8453").
        accepted: Parsed PaymentRequirements from server's PAYMENT-REQUIRED header.
        resource: Resource metadata from 402 response (for Bazaar discovery).
        extensions: Extensions from 402 response (for Bazaar discovery).

    Returns:
        x402 PaymentPayload v2 dict.
    """
    # Convert human-readable amount to USDC base units (6 decimals)
    value = _parse_usdc_amount(amount)
    now = int(time.time())
    valid_after = now - 300
    valid_before = now + 3600
    nonce = "0x" + os.urandom(32).hex()

    # Use EIP-712 domain from server's payment requirements when available
    extra = (accepted or {}).get("extra", {})
    domain_name = extra.get("name", "USD Coin")
    domain_version = extra.get("version", "2")

    domain_data = {
        "name": domain_name,
        "version": domain_version,
        "chainId": chain_id,
        "verifyingContract": token_address,
    }

    message_types = {
        "TransferWithAuthorization": [
            {"name": "from", "type": "address"},
            {"name": "to", "type": "address"},
            {"name": "value", "type": "uint256"},
            {"name": "validAfter", "type": "uint256"},
            {"name": "validBefore", "type": "uint256"},
            {"name": "nonce", "type": "bytes32"},
        ],
    }

    message_data = {
        "from": from_address,
        "to": to_address,
        "value": value,
        "validAfter": valid_after,
        "validBefore": valid_before,
        "nonce": bytes.fromhex(nonce[2:]),
    }

    signable = encode_typed_data(
        domain_data=domain_data,
        message_types=message_types,
        message_data=message_data,
    )
    signed = Account.sign_message(signable, private_key=private_key)

    # Build accepted requirements for the v2 wrapper
    accepted_req = accepted or PaymentRequirements(
        scheme="exact",
        network=network,
        amount=str(value),
        asset=token_address,
        payTo=to_address,
        maxTimeoutSeconds=300,
        extra={"name": domain_name, "version": domain_version},
    )

    # x402 PaymentPayload v2 format (including resource + extensions for Bazaar discovery)
    result: dict[str, Any] = {
        "x402Version": 2,
        "accepted": dict(accepted_req),
        "payload": {
            "signature": "0x" + (signed.signature.hex() if isinstance(signed.signature, bytes) else format(signed.signature, 'x')),
            "authorization": {
                "from": from_address,
                "to": to_address,
                "value": str(value),
                "validAfter": str(valid_after),
                "validBefore": str(valid_before),
                "nonce": nonce,
            },
        },
    }
    if resource:
        result["resource"] = resource
    if extensions:
        result["extensions"] = extensions
    return result


def build_zero_cost_authorization(
    *,
    from_address: str,
    to_address: str,
    accepted: PaymentRequirements | dict[str, Any] | None = None,
    resource: dict[str, Any] | None = None,
    extensions: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Build a zero-cost x402 PaymentPayload for credit-covered requests.

    Instead of skipping the payment header entirely (which causes the server's
    x402 SDK to return a 402 error), we send a stub authorization with value=0
    and signature=0x so the server can recognise the zero-cost intent.
    """
    result: dict[str, Any] = {
        "x402Version": 2,
        "accepted": dict(accepted) if accepted else {},
        "payload": {
            "signature": "0x",
            "authorization": {
                "from": from_address,
                "to": to_address,
                "value": "0",
                "validAfter": "0",
                "validBefore": "0",
                "nonce": "0x" + "00" * 32,
            },
        },
    }
    if resource:
        result["resource"] = resource
    if extensions:
        result["extensions"] = extensions
    return result


def encode_payment_header(auth: dict[str, Any]) -> str:
    """Base64-encode a PaymentPayload dict for the payment-signature header."""
    return base64.b64encode(json.dumps(auth).encode()).decode()


def _parse_usdc_amount(amount: str) -> int:
    """Convert a human-readable USDC amount to base units (6 decimals).

    Examples:
        "1.50" -> 1500000
        "10"   -> 10000000
        "0.01" -> 10000
    """
    parts = amount.split(".")
    whole = int(parts[0])
    if len(parts) == 1:
        return whole * 1_000_000

    # Pad or truncate fractional part to 6 digits
    frac_str = parts[1][:6].ljust(6, "0")
    return whole * 1_000_000 + int(frac_str)
