# `Handoffs`

::: agents.realtime.handoffs
