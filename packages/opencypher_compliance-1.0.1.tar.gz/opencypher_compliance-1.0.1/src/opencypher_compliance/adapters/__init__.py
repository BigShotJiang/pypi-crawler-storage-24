"""Adapter base class, QueryResult, and adapter registry."""

from __future__ import annotations

import importlib
from dataclasses import dataclass, field


@dataclass
class QueryResult:
    columns: list[str] = field(default_factory=list)
    rows: list[list] = field(default_factory=list)


class CypherAdapter:
    """Base class. Each adapter wraps one database's Python package."""

    def connect(self, host: str, port: int, auth: dict, **options) -> None:
        raise NotImplementedError

    def execute(self, query: str) -> QueryResult:
        raise NotImplementedError

    def close(self) -> None:
        raise NotImplementedError

    def cleanup(self) -> None:
        """Remove all nodes and relationships."""
        self.execute("MATCH (n) DETACH DELETE n")

    def get_version(self) -> str | None:
        """Return the database version string, or None if not retrievable."""
        return None


ADAPTERS: dict[str, str] = {
    "bolt": "opencypher_compliance.adapters.bolt.BoltAdapter",
    "falkordb": "opencypher_compliance.adapters.falkordb.FalkorDBAdapter",
}


def get_adapter(name: str) -> CypherAdapter:
    """Look up and instantiate an adapter by name."""
    if name not in ADAPTERS:
        raise KeyError(f"Unknown adapter: {name!r}. Available: {list(ADAPTERS.keys())}")
    module_path, class_name = ADAPTERS[name].rsplit(".", 1)
    module = importlib.import_module(module_path)
    return getattr(module, class_name)()
