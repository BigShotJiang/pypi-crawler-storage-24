"""OpenCypher compliance testing tool."""

__version__ = "1.0.0"


def run_compliance(**kwargs):
    """Run compliance tests. See runner.run_compliance for full signature."""
    from opencypher_compliance.runner import run_compliance as _run
    return _run(**kwargs)


__all__ = ["run_compliance", "__version__"]
