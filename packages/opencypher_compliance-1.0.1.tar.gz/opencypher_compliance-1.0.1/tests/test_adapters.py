"""Tests for adapter base class, QueryResult, and registry."""

import pytest
from opencypher_compliance.adapters import (
    CypherAdapter,
    QueryResult,
    ADAPTERS,
    get_adapter,
)


class TestQueryResult:
    def test_default_empty(self):
        qr = QueryResult()
        assert qr.columns == []
        assert qr.rows == []

    def test_with_data(self):
        qr = QueryResult(columns=["name", "age"], rows=[["Alice", 30]])
        assert qr.columns == ["name", "age"]
        assert qr.rows == [["Alice", 30]]

    def test_multiple_rows(self):
        qr = QueryResult(columns=["x"], rows=[[1], [2], [3]])
        assert len(qr.rows) == 3


class TestCypherAdapterBase:
    def test_connect_raises(self):
        adapter = CypherAdapter()
        with pytest.raises(NotImplementedError):
            adapter.connect("localhost", 7687, {})

    def test_execute_raises(self):
        adapter = CypherAdapter()
        with pytest.raises(NotImplementedError):
            adapter.execute("RETURN 1")

    def test_close_raises(self):
        adapter = CypherAdapter()
        with pytest.raises(NotImplementedError):
            adapter.close()

    def test_cleanup_calls_execute(self):
        """cleanup() calls execute() with MATCH (n) DETACH DELETE n."""
        adapter = CypherAdapter()
        with pytest.raises(NotImplementedError):
            adapter.cleanup()

    def test_get_version_returns_none(self):
        adapter = CypherAdapter()
        assert adapter.get_version() is None


class TestAdapterRegistry:
    def test_all_adapters_registered(self):
        expected = {"bolt", "falkordb"}
        assert set(ADAPTERS.keys()) == expected

    def test_unknown_adapter_raises(self):
        with pytest.raises(KeyError, match="Unknown adapter"):
            get_adapter("nonexistent")

    def test_registry_values_are_dotted_paths(self):
        for name, path in ADAPTERS.items():
            parts = path.rsplit(".", 1)
            assert len(parts) == 2, f"Adapter {name} path should be module.ClassName"
