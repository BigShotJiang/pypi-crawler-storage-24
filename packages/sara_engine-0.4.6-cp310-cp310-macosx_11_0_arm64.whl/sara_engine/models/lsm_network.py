# {
#     "//": "ディレクトリパス: src/sara_engine/models/lsm_network.py",
#     "//": "ファイルの日本語タイトル: Liquid State Machine ネットワーク",
#     "//": "ファイルの目的や内容: オブジェクト指向のLSM。樹状突起ネットワークによる空間計算と、STPによる時間計算を統合。純粋なメッセージパッシングで $O(N)$ の動的システムを駆動する。"
# }

import random
from typing import List, Optional, Sequence
from ..learning.force import ForceReadout
from ..neuro.neuron import Neuron
from ..neuro.synapse import Synapse
from ..metrics.branching_ratio import BranchingRatioEstimator


class LSMNetwork:
    """
    樹状突起計算(Dendritic Computation) と メタ可塑性 を備えた Liquid Transformer 代替コア。
    """

    def __init__(
        self,
        n_input: int = 50,
        n_liquid: int = 500,
        n_output: int = 100,
        branches_per_neuron: int = 4,
        readout_decay: float = 0.9,
        enable_force_readout: bool = True,
        force_output_dim: int = 1,
        force_alpha: float = 1.0,
        force_forgetting_factor: float = 1.0,
    ):
        self.inputs = [Neuron(i, is_inhibitory=False, num_branches=1)
                       for i in range(n_input)]
        self.liquid = [Neuron(i, is_inhibitory=(
            i % 5 == 0), num_branches=branches_per_neuron) for i in range(n_liquid)]
        self.outputs = [Neuron(
            i, is_inhibitory=False, num_branches=branches_per_neuron) for i in range(n_output)]

        self.synapses: List[Synapse] = []
        self.global_step = 0

        self.target_rate = 0.05
        self.firing_rates = {
            n: self.target_rate for n in self.liquid + self.outputs}
        self.branching_estimator = BranchingRatioEstimator(smoothing_alpha=0.08)
        self.target_sigma = 1.0

        self.prune_threshold = 0.01
        self.growth_prob = 0.1

        self.readout_decay = max(0.0, min(0.999, readout_decay))
        self.filtered_input_state = [0.0 for _ in range(n_input)]
        self.filtered_liquid_state = [0.0 for _ in range(n_liquid)]
        self.filtered_output_state = [0.0 for _ in range(n_output)]
        self.force_readout: Optional[ForceReadout] = None
        if enable_force_readout:
            self.force_readout = ForceReadout(
                input_size=self.state_size,
                output_size=max(1, force_output_dim),
                alpha=force_alpha,
                forgetting_factor=force_forgetting_factor,
            )

        # ネットワークの配線 (枝をランダムに指定)
        self._wire_population(self.inputs, self.liquid, prob=0.2)
        self._wire_population(self.liquid, self.liquid,
                              prob=0.1, avoid_self=True)
        self._wire_population(self.liquid, self.outputs, prob=0.5)

    @property
    def state_size(self) -> int:
        return (
            len(self.filtered_input_state)
            + len(self.filtered_liquid_state)
            + len(self.filtered_output_state)
        )

    def _wire_population(self, pre_pop: List[Neuron], post_pop: List[Neuron], prob: float, avoid_self: bool = False):
        for pre_n in pre_pop:
            for post_n in post_pop:
                if avoid_self and pre_n.id == post_n.id:
                    continue
                if random.random() < prob:
                    # ランダムな枝に接続 (シナプスクラスタリングの初期状態)
                    b_idx = random.randint(0, len(post_n.branches) - 1)
                    self.synapses.append(
                        Synapse(pre_n, post_n, b_idx, is_inhibitory=pre_n.is_inhibitory))

    def step(self, input_spikes: List[bool]) -> List[bool]:
        """
        1ステップのシミュレーション。行列演算 O(N^2) を使わず、
        スパイクが発生したシナプスのみが信号を伝播するグラフ処理ライクな O(E) の計算。
        """
        self.global_step += 1

        # 1. 外部入力の強制発火
        for i, neuron in enumerate(self.inputs):
            neuron.spike = bool(input_spikes[i]) if i < len(input_spikes) else False

        # 2. シナプス経由の電流伝達 (純粋なメッセージパッシング)
        # 各シナプスが pre の発火を確認し、post の特定の枝へ電流を注入する
        for syn in self.synapses:
            syn.step(dt=1.0)

        # 3. ニューロン状態の更新 (Dendrite統合とSoma発火)
        for n in self.liquid:
            n.step()
            self.firing_rates[n] = (
                self.firing_rates[n] * 0.99
                + (1.0 if n.spike else 0.0) * 0.01
            )

        # 4. 出力層の更新
        out_spikes = []
        for n in self.outputs:
            spike = n.step()
            out_spikes.append(spike)
            self.firing_rates[n] = (
                self.firing_rates[n] * 0.99
                + (1.0 if n.spike else 0.0) * 0.01
            )

        self._update_filtered_state(input_spikes, self.liquid, self.outputs)

        sigma = self.branching_estimator.update(
            sum(1 for n in self.liquid if n.spike) + sum(1 for s in out_spikes if s)
        )
        self._apply_criticality_control(sigma)

        # メタ可塑性の適用
        if self.global_step % 100 == 0:
            self._apply_homeostasis()

        if self.global_step % 1000 == 0:
            self._apply_structural_plasticity()

        return out_spikes

    def force_step(
        self,
        input_spikes: Sequence[bool],
        target: Optional[Sequence[float]] = None,
        learning: bool = True,
    ) -> List[float]:
        """Advance the reservoir and optionally update the FORCE readout."""
        self.step(list(input_spikes))
        if self.force_readout is None:
            raise RuntimeError('FORCE readout is not enabled for this network')

        state = self.get_reservoir_state()
        if target is not None and learning:
            return self.force_readout.update(state, target)
        return self.force_readout.predict(state)

    def predict_force(self, input_spikes: Sequence[bool]) -> List[float]:
        return self.force_step(input_spikes, target=None, learning=False)

    def train_force(self, input_spikes: Sequence[bool], target: Sequence[float]) -> List[float]:
        return self.force_step(input_spikes, target=target, learning=True)

    def get_reservoir_state(self) -> List[float]:
        return (
            list(self.filtered_input_state)
            + list(self.filtered_liquid_state)
            + list(self.filtered_output_state)
        )

    def reset_dynamic_state(self, reset_readout: bool = False) -> None:
        self.global_step = 0
        for neuron in self.inputs + self.liquid + self.outputs:
            neuron.v = 0.0
            neuron.spike = False
            neuron.refractory_time = 0
            neuron.active_branches.clear()
            for branch in neuron.branches:
                branch.current_input = 0.0
                branch.is_active = False
        for idx in range(len(self.filtered_input_state)):
            self.filtered_input_state[idx] = 0.0
        for idx in range(len(self.filtered_liquid_state)):
            self.filtered_liquid_state[idx] = 0.0
        for idx in range(len(self.filtered_output_state)):
            self.filtered_output_state[idx] = 0.0
        if reset_readout and self.force_readout is not None:
            self.force_readout.reset()

    def _update_filtered_state(
        self,
        input_spikes: Sequence[bool],
        liquid_neurons: Sequence[Neuron],
        output_neurons: Sequence[Neuron],
    ) -> None:
        decay = self.readout_decay
        for idx in range(len(self.filtered_input_state)):
            spike_value = 1.0 if idx < len(input_spikes) and input_spikes[idx] else 0.0
            self.filtered_input_state[idx] = self.filtered_input_state[idx] * decay + spike_value
        for idx, neuron in enumerate(liquid_neurons):
            self.filtered_liquid_state[idx] = (
                self.filtered_liquid_state[idx] * decay
                + (1.0 if neuron.spike else 0.0)
            )
        for idx, neuron in enumerate(output_neurons):
            self.filtered_output_state[idx] = (
                self.filtered_output_state[idx] * decay
                + (1.0 if neuron.spike else 0.0)
            )

    def _apply_criticality_control(self, sigma: float) -> None:
        sigma_error = sigma - self.target_sigma
        if abs(sigma_error) < 0.05:
            return

        threshold_shift = max(-0.15, min(0.15, sigma_error * 0.04))
        for n in self.liquid + self.outputs:
            n.threshold = max(0.2, min(2.5, n.threshold + threshold_shift))

    def _apply_homeostasis(self):
        scale_factors = {}
        for n, rate in self.firing_rates.items():
            scale = self.target_rate / (rate + 1e-6)
            scale_factors[n] = max(0.8, min(scale, 1.2))

        for syn in self.synapses:
            if syn.post in scale_factors:
                syn.weight *= scale_factors[syn.post]
                if syn.is_inhibitory:
                    syn.weight = max(-2.0, min(0.0, syn.weight))
                else:
                    syn.weight = max(0.0, min(2.0, syn.weight))

    def _apply_structural_plasticity(self):
        self.synapses = [s for s in self.synapses if abs(
            s.weight) > self.prune_threshold]

        if random.random() < self.growth_prob:
            pre_n = random.choice(self.liquid)
            post_n = random.choice(self.liquid)
            if pre_n.id != post_n.id:
                # Synaptic Clustering: 他の強いシナプスがある枝を優先的に選ぶことで
                # 特徴検出器（ANDゲート）としての能力を高めることが可能（将来の拡張）
                b_idx = random.randint(0, len(post_n.branches) - 1)
                self.synapses.append(
                    Synapse(pre_n, post_n, b_idx, is_inhibitory=pre_n.is_inhibitory))
