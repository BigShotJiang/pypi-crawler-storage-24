"""Tests for wt-registry."""
