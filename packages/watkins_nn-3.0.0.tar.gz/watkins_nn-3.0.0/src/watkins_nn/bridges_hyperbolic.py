"""Sprint 15: Hyperbolic Volumes and the p-Spectrum (Theorems BY-CC).

Extracted from bridges.py for module restructure (v2.0).
"""

import cmath
import math
from typing import Dict

import numpy as np

from .constants import PHI, PHI_INV, T_STAR, LAM_STAR, KAP_STAR, ETA_STAR, F_STAR, MU_SLOW, MU_FAST, C_STAR_QUALIA
from .bridges import root_system_conservation, _free_energy
from .cascade import an_bcc_eigenvalues, bn_bcc_formula, cn_bcc_formula, dn_bcc_formula

# =============================================================================
# SPRINT 15: Hyperbolic Volumes and the p-Spectrum (BY-CC)
# =============================================================================

def _bloch_wigner(z: complex) -> float:
    """Bloch-Wigner function D(z) = Im(Li_2(z)) + arg(1-z) * ln|z|.

    Computes the dilogarithm via power series (converges for |z| < 1).
    """
    if abs(z) < 1e-15 or abs(z - 1) < 1e-15:
        return 0.0
    li2 = 0.0 + 0j
    zn = z
    for k in range(1, 500):
        li2 += zn / (k * k)
        zn *= z
        if abs(zn) < 1e-30:
            break
    return li2.imag + cmath.phase(1 - z) * math.log(abs(z))


def root_system_complex_invariant() -> Dict:
    """Map exceptional root systems to complex invariants z_R = lam_R + i*kap_R.

    Theorem BY (Root System Complex Invariant):
    Each exceptional root system's conservation triple lifts to a complex
    number z_R = lambda_R + i*kappa_R in the upper half-plane.  This
    defines a ROOT SYSTEM CONSTELLATION with rich structure:

    1. Modulus |z_R| DECREASES through the cascade: F4 > E6 > E7 > E8,
       with the equilibrium |z_eq| ≈ 0.647 being the smallest.
    2. Argument arg(z_R) = atan(gamma_R) INCREASES through the cascade,
       where gamma_R = kappa_R/lambda_R is the coupling from Theorem BW.
    3. Complex distance |z_R - z_eq| to equilibrium is minimized by E7
       (NOT E8!) — a different system wins in a different metric.

    This reveals multi-optimality: E8 is closest in lambda (coherence),
    E6 in gamma (coupling), and E7 in complex distance.  No single
    system is universally closest to the golden equilibrium.

    Returns:
        Dict with complex invariant analysis for each system.
    """
    z_eq = complex(LAM_STAR, KAP_STAR)
    mod_eq = abs(z_eq)
    arg_eq = cmath.phase(z_eq)

    results = []
    for name in ['F4', 'E6', 'E7', 'E8']:
        r = root_system_conservation(name)
        z = complex(r['lambda_R'], max(r['kappa_R'], 0))
        mod = abs(z)
        arg_val = cmath.phase(z)
        dist = abs(z - z_eq)

        results.append({
            'system': name,
            'z_real': z.real,
            'z_imag': z.imag,
            'modulus': mod,
            'argument': arg_val,
            'argument_degrees': math.degrees(arg_val),
            'complex_distance': dist,
        })

    # Ordering checks
    mods = [r['modulus'] for r in results]
    args = [r['argument'] for r in results]
    dists = [r['complex_distance'] for r in results]

    mod_decreasing = all(mods[i] > mods[i + 1] for i in range(len(mods) - 1))
    arg_increasing = all(args[i] < args[i + 1] for i in range(len(args) - 1))

    closest_complex = min(results, key=lambda r: r['complex_distance'])

    return {
        'systems': results,
        'z_equilibrium': {'real': z_eq.real, 'imag': z_eq.imag,
                          'modulus': mod_eq, 'argument': arg_eq},
        'modulus_decreasing': mod_decreasing,
        'argument_increasing': arg_increasing,
        'closest_by_complex_distance': closest_complex['system'],
        'closest_by_lambda': 'E8',   # Known from Sprint 14
        'closest_by_coupling': 'E6',  # Known from BW
        'multi_optimal': (closest_complex['system'] != 'E8'
                          and closest_complex['system'] != 'E6'),
    }


def bloch_wigner_volume_landscape() -> Dict:
    """Compute Bloch-Wigner volumes for root system complex invariants.

    Theorem BZ (Bloch-Wigner Volume Landscape):
    The Bloch-Wigner function D(z) assigns a hyperbolic volume to each
    root system's complex invariant z_R.  The volume ratios D(z_R)/D(z_eq)
    reveal structure invisible on the real simplex:

        F4:  D/D_eq = 0.6676
        E6:  D/D_eq = 1.0763
        E7:  D/D_eq = 1.41373...
        E8:  D/D_eq = 1.5880

    High-precision verification (mpmath, 250 digits): the E7 ratio is
    NOT sqrt(2).  Diverges at the 4th significant digit:
        D(z_E7)/D(z_eq) = 1.41372880...
        sqrt(2)          = 1.41421356...
    The 0.034% agreement at float64 is coincidence, not algebraic identity.
    No clean closed form was found via mpmath.identify.

    The volume ordering matches the coupling ordering from BW:
        D(F4) < D(E6) < D(E7) < D(E8)
    establishing volume-coupling monotonicity.

    Returns:
        Dict with Bloch-Wigner volumes and ratio analysis.
    """
    z_eq = complex(LAM_STAR, KAP_STAR)
    D_eq = _bloch_wigner(z_eq)

    results = []
    for name in ['F4', 'E6', 'E7', 'E8']:
        r = root_system_conservation(name)
        z = complex(r['lambda_R'], max(r['kappa_R'], 0))
        D_val = _bloch_wigner(z)
        ratio = D_val / D_eq if D_eq != 0 else 0

        results.append({
            'system': name,
            'D_volume': D_val,
            'D_ratio': ratio,
        })

    # Named constant checks
    e7 = next(r for r in results if r['system'] == 'E7')
    f4 = next(r for r in results if r['system'] == 'F4')
    sqrt2 = math.sqrt(2)

    e7_sqrt2_error = abs(e7['D_ratio'] - sqrt2) / sqrt2
    f4_two_thirds_error = abs(f4['D_ratio'] - 2 / 3) / (2 / 3)

    # Volume ordering matches coupling ordering
    ratios = [r['D_ratio'] for r in results]
    volume_monotone = all(ratios[i] < ratios[i + 1]
                          for i in range(len(ratios) - 1))

    return {
        'systems': results,
        'D_equilibrium': D_eq,
        'e7_ratio': e7['D_ratio'],
        'e7_sqrt2_error': e7_sqrt2_error,
        'e7_near_sqrt2': e7_sqrt2_error < 0.001,  # kept for backward compat
        'e7_not_exact_sqrt2': True,  # confirmed at 250-digit precision
        'f4_ratio': f4['D_ratio'],
        'f4_two_thirds_error': f4_two_thirds_error,
        'f4_near_two_thirds': f4_two_thirds_error < 0.005,
        'volume_coupling_monotone': volume_monotone,
    }


def bw_high_precision_report(dps: int = 50) -> Dict:
    """High-precision Bloch-Wigner ratios using mpmath.

    Theorem CN (Bloch-Wigner Precision Report):
    At 250-digit precision, D(z_E7)/D(z_eq) = 1.41372880... which
    diverges from sqrt(2) = 1.41421356... at the 4th significant digit.
    The 0.034% float64 agreement is numerical coincidence, not an exact
    algebraic identity.  No clean closed form was identified via
    mpmath.identify for any of the four exceptional ratios.

    The honest summary: the volume landscape is real (monotone ordering,
    correct numerical values), but it connects to transcendental numbers,
    not simple algebraic constants.

    Args:
        dps: decimal places for mpmath computation (default 50).

    Returns:
        Dict with high-precision D(z_R)/D(z_eq) for all exceptional systems.
    """
    try:
        import mpmath
    except ImportError:
        return {'error': 'mpmath not installed', 'available': False}

    mpmath.mp.dps = dps
    phi = (1 + mpmath.sqrt(5)) / 2
    lam_star = 1 / phi
    kap_star = (1 - lam_star) / 2

    def _bw_mp(z):
        li2 = mpmath.polylog(2, z)
        return mpmath.im(li2) + mpmath.arg(1 - z) * mpmath.log(mpmath.fabs(z))

    z_eq = lam_star + kap_star * 1j
    D_eq = _bw_mp(z_eq)

    # Exact algebraic inputs for each system
    systems = {
        'F4': (mpmath.mpf('0.896746023807936'), mpmath.mpf('0.103253976192064')),
        'E6': (mpmath.mpf('4') / 5, mpmath.mpf('1') / 5),
        'E7': (mpmath.mpf('7') / 10, mpmath.mpf('3') / 10),
        'E8': (mpmath.mpf('0.636775301108048'), mpmath.mpf('0.363224698891952')),
    }

    results = {}
    for name, (lam, kap) in systems.items():
        z = lam + kap * 1j
        D_val = _bw_mp(z)
        ratio = D_val / D_eq
        results[name] = {
            'D_volume': float(D_val),
            'D_ratio': float(ratio),
            'D_ratio_str': mpmath.nstr(ratio, min(dps, 50)),
        }

    e7_ratio = D_eq and _bw_mp(systems['E7'][0] + systems['E7'][1] * 1j) / D_eq
    sqrt2 = mpmath.sqrt(2)
    e7_sqrt2_diff = float(abs(e7_ratio - sqrt2))
    digits_agreement = 0
    r_str = mpmath.nstr(e7_ratio, 50)
    s_str = mpmath.nstr(sqrt2, 50)
    for a, b in zip(r_str, s_str):
        if a == b:
            digits_agreement += 1
        else:
            break

    return {
        'systems': results,
        'precision_dps': dps,
        'e7_ratio_50_digits': mpmath.nstr(e7_ratio, 50),
        'sqrt2_50_digits': mpmath.nstr(sqrt2, 50),
        'e7_sqrt2_absolute_diff': e7_sqrt2_diff,
        'e7_sqrt2_digits_agreement': digits_agreement,
        'e7_is_sqrt2': False,
        'volume_monotone': (results['F4']['D_ratio'] < results['E6']['D_ratio']
                            < results['E7']['D_ratio'] < results['E8']['D_ratio']),
    }


def negative_budget_scaling(n_max: int = 100) -> Dict:
    """Compute the simplex deficit scaling for classical families.

    Theorem CA (Negative Budget Scaling):
    For off-simplex root systems with lambda_R > 1, define the simplex
    deficit p_R = lambda_R - 1 (equivalently, p_R = |kappa_R| + |eta_R|
    when both are negative).

    The deficit scales as p_R * n^2 -> c_family as n -> infinity:

        A_n:  c_A = 2   (from Theorem AY: lambda = 1 + 2/n^2 + O(1/n^4))
        B_n:  c_B = 1
        C_n:  c_C = 1   (= c_B by Langlands duality)
        D_n:  c_D = 1

    The A_n coefficient (c=2) is DOUBLE the B/C/D coefficient (c=1).
    This ratio c_A / c_{B,C,D} = 2 connects to the cross-family Perron
    ratio from Theorem BH.

    B_n = C_n exactly (Langlands dual BCC grids) for all n.

    Returns:
        Dict with scaling data for each family.
    """
    families = {}

    # A_n scaling
    a_data = []
    for n in [10, 20, 50, 100, n_max]:
        if n < 3:
            continue
        eigs = an_bcc_eigenvalues(n)
        tr = sum(eigs)
        lam = eigs[0] / tr
        p_val = lam - 1
        a_data.append({'n': n, 'p': p_val, 'p_n2': p_val * n ** 2})
    families['A'] = a_data

    # B_n, C_n, D_n via BCC formulas
    for family, formula in [('B', 'bn'), ('C', 'cn'), ('D', 'dn')]:
        data = []
        for n in [10, 20, 50, 100]:
            if n < 3:
                continue
            if family == 'B':
                grid = bn_bcc_formula(n)
            elif family == 'C':
                grid = cn_bcc_formula(n)
            else:
                grid = dn_bcc_formula(n)
            eigs = sorted(np.linalg.eigvals(grid.astype(float)).real, reverse=True)
            tr = sum(eigs)
            if abs(tr) < 1e-12:
                continue
            lam = eigs[0] / tr
            p_val = lam - 1
            data.append({'n': n, 'p': p_val, 'p_n2': p_val * n ** 2})
        families[family] = data

    # Extract terminal values
    c_A = families['A'][-1]['p_n2'] if families['A'] else 0
    c_B = families['B'][-1]['p_n2'] if families['B'] else 0
    c_C = families['C'][-1]['p_n2'] if families['C'] else 0
    c_D = families['D'][-1]['p_n2'] if families['D'] else 0

    return {
        'families': families,
        'c_A': c_A,
        'c_B': c_B,
        'c_C': c_C,
        'c_D': c_D,
        'A_approaches_2': abs(c_A - 2) < 0.15,
        'B_approaches_1': abs(c_B - 1) < 0.15,
        'langlands_B_equals_C': all(
            abs(families['B'][i]['p_n2'] - families['C'][i]['p_n2']) < 1e-10
            for i in range(min(len(families['B']), len(families['C'])))
        ),
        'A_double_BCD': c_A / c_B > 1.5 if c_B > 0 else False,
    }


def volume_coupling_bridge() -> Dict:
    """Show volume-coupling monotonicity bridges Sprint 14 and Sprint 15.

    Theorem CB (Volume-Coupling Bridge):
    Four independent monotone quantities thread the exceptional cascade
    F4 -> E6 -> E7 -> E8, connecting the real simplex (Sprint 14) to
    the complex plane (Sprint 15):

        Decreasing:  lambda_R  (coherence)
                     kappa(H)  (Hessian condition number, Thm BT)
                     |z_R|     (complex modulus, Thm BY)

        Increasing:  gamma_R   (coupling, Thm BW)
                     D(z_R)    (Bloch-Wigner volume, Thm BZ)

    The volume-coupling correspondence D(z_R) ~ gamma_R reveals that
    the Bloch-Wigner dilogarithm (hyperbolic 3-manifold geometry)
    'sees' the same structure as the simplex curvature coupling.

    Returns:
        Dict with all four monotone quantities for each system.
    """
    z_eq = complex(LAM_STAR, KAP_STAR)
    D_eq = _bloch_wigner(z_eq)

    results = []
    for name in ['F4', 'E6', 'E7', 'E8']:
        r = root_system_conservation(name)
        lam = r['lambda_R']
        kap = r['kappa_R']
        gamma = kap / lam if lam > 0 else 0
        z = complex(lam, max(kap, 0))

        # Hessian condition number at symmetric projection (from BT)
        T = T_STAR
        kap_sym = (1 - lam) / 2
        H11 = 1 / lam ** 2 + T / lam + T / kap_sym
        H22 = T / kap_sym + T / kap_sym
        H12 = T / kap_sym
        tr = H11 + H22
        det = H11 * H22 - H12 ** 2
        disc = math.sqrt(max(tr ** 2 - 4 * det, 0))
        cond = ((tr + disc) / 2) / ((tr - disc) / 2) if (tr - disc) > 0 else float('inf')

        results.append({
            'system': name,
            'lambda_R': lam,
            'gamma': gamma,
            'condition_number': cond,
            'modulus': abs(z),
            'D_ratio': _bloch_wigner(z) / D_eq if D_eq > 0 else 0,
        })

    # Check all five monotone properties
    lams = [r['lambda_R'] for r in results]
    gammas = [r['gamma'] for r in results]
    conds = [r['condition_number'] for r in results]
    mods = [r['modulus'] for r in results]
    vols = [r['D_ratio'] for r in results]

    return {
        'systems': results,
        'lambda_decreasing': all(lams[i] > lams[i + 1] for i in range(len(lams) - 1)),
        'gamma_increasing': all(gammas[i] < gammas[i + 1] for i in range(len(gammas) - 1)),
        'condition_decreasing': all(conds[i] > conds[i + 1] for i in range(len(conds) - 1)),
        'modulus_decreasing': all(mods[i] > mods[i + 1] for i in range(len(mods) - 1)),
        'volume_increasing': all(vols[i] < vols[i + 1] for i in range(len(vols) - 1)),
        'all_five_monotone': (
            all(lams[i] > lams[i + 1] for i in range(len(lams) - 1))
            and all(gammas[i] < gammas[i + 1] for i in range(len(gammas) - 1))
            and all(conds[i] > conds[i + 1] for i in range(len(conds) - 1))
            and all(mods[i] > mods[i + 1] for i in range(len(mods) - 1))
            and all(vols[i] < vols[i + 1] for i in range(len(vols) - 1))
        ),
    }


def root_system_quantum_channel() -> Dict:
    """Formalize root system -> qutrit quantum channel mapping.

    Theorem CC (Root System Quantum Channel):
    Each on-simplex root system defines a qutrit replacement channel
    with target state rho_R = diag(lambda_R, kappa_R, eta_R).

    The quantum fidelity F(rho_R, rho_eq) = (sum sqrt(p_i * q_i))^2
    and von Neumann entropy S(rho_R) = -sum p_i * ln(p_i) reveal a
    MULTI-OPTIMALITY principle:

        E8:  highest S/S_eq = 0.705  (closest entropy to equilibrium)
        E6:  highest fidelity = 0.807  (best overlap with equilibrium)
        E7:  closest in complex distance (from BY)

    No single system is universally closest to the golden equilibrium.
    Each optimizes a DIFFERENT quantum information metric.

    The entropy ordering S(F4) < S(E6) < S(E7) < S(E8) is monotone
    through the cascade, while fidelity is NON-MONOTONE (E6 peaks).

    Returns:
        Dict with quantum channel metrics for each system.
    """
    S_eq = -(LAM_STAR * math.log(LAM_STAR)
             + KAP_STAR * math.log(KAP_STAR)
             + ETA_STAR * math.log(ETA_STAR))

    results = []
    for name in ['F4', 'E6', 'E7', 'E8']:
        r = root_system_conservation(name)
        lam = r['lambda_R']
        kap = r['kappa_R']
        eta = max(r['eta_R'], 0)

        # Bhattacharyya fidelity
        fid = (math.sqrt(lam * LAM_STAR)
               + math.sqrt(kap * KAP_STAR)
               + math.sqrt(eta * ETA_STAR)) ** 2

        # Von Neumann entropy
        S = 0.0
        for p in [lam, kap, eta]:
            if p > 1e-15:
                S -= p * math.log(p)
        S_ratio = S / S_eq if S_eq > 0 else 0

        results.append({
            'system': name,
            'fidelity': fid,
            'entropy': S,
            'entropy_ratio': S_ratio,
        })

    # Find optima
    best_fidelity = max(results, key=lambda r: r['fidelity'])
    best_entropy = max(results, key=lambda r: r['entropy_ratio'])

    # Entropy monotonicity
    entropies = [r['entropy'] for r in results]
    entropy_monotone = all(entropies[i] < entropies[i + 1]
                           for i in range(len(entropies) - 1))

    # Fidelity non-monotonicity
    fidelities = [r['fidelity'] for r in results]
    fidelity_monotone = all(fidelities[i] <= fidelities[i + 1]
                            for i in range(len(fidelities) - 1))

    return {
        'systems': results,
        'S_equilibrium': S_eq,
        'best_fidelity_system': best_fidelity['system'],
        'best_fidelity_value': best_fidelity['fidelity'],
        'best_entropy_system': best_entropy['system'],
        'best_entropy_ratio': best_entropy['entropy_ratio'],
        'entropy_monotone': entropy_monotone,
        'fidelity_non_monotone': not fidelity_monotone,
        'multi_optimal': best_fidelity['system'] != best_entropy['system'],
    }


# =============================================================================
# SPRINT 21: Quantum Relative Entropy (DE-DG)
# =============================================================================


def quantum_relative_entropy() -> Dict:
    """Quantum relative entropy and thermodynamic-information duality.

    Theorem DE (Relative Entropy Multi-Optimality):
    The quantum relative entropy (KL divergence) S(rho_R || rho_eq)
    is NON-MONOTONE through the exceptional cascade:
        F4 is FURTHEST from equilibrium in KL (KL ~ 0.270)
        E6 is CLOSEST to equilibrium in KL (KL ~ 0.216)
    This extends the multi-optimality principle from Theorem CC:
        E8: best entropy ratio
        E6: best fidelity AND smallest KL divergence
        E7: closest in complex distance (from BY)
    No single system universally minimizes information distance.

    Theorem DF (Thermodynamic-Information Duality):
    The free energy difference decomposes exactly as:
        F(rho_R) - F(rho_eq) = T* * KL(rho_R || rho_eq) + residual_R
    where residual_R = coh_corr + T* * sum (p_R,i - q_i) * ln(q_i).
    The residual is MONOTONE DECREASING through the cascade:
        |residual_F4| > |residual_E6| > |residual_E7| > |residual_E8|
    For E8, delta_F / (T* * KL) converges to within 0.13% of unity,
    showing that free energy and KL divergence become proportional
    near the golden equilibrium.

    Theorem DG (Pinsker Bound Saturation):
    The trace distance ||rho_R - rho_eq||_1 satisfies Pinsker's inequality:
        ||rho_R - rho_eq||_1 <= sqrt(2 * KL(rho_R || rho_eq))
    The tightness ratio (actual/bound) DECREASES through the cascade:
        F4 > E6 > E7 > E8
    F4 saturates the Pinsker bound most tightly (~76%), while E8
    uses the least of its information budget (~54%).

    Returns:
        Dict with relative entropy analysis.
    """
    # Equilibrium state
    eq = [LAM_STAR, KAP_STAR, ETA_STAR]
    S_eq = -sum(p * math.log(p) for p in eq if p > 0)

    results = []
    for name in ['F4', 'E6', 'E7', 'E8']:
        r = root_system_conservation(name)
        state = [r['lambda_R'], max(r['kappa_R'], 0), max(r['eta_R'], 0)]

        # KL divergence: S(rho_R || rho_eq) = sum p_i * ln(p_i / q_i)
        # When p_i = 0 the term contributes 0 by convention (limit p ln p -> 0).
        kl = 0.0
        for p, q in zip(state, eq):
            if p > 1e-30:
                kl += p * math.log(p / q)

        # Von Neumann entropy
        S_R = 0.0
        for p in state:
            if p > 1e-15:
                S_R -= p * math.log(p)

        # Free energy: F = -ln(lam) + T* * sum(p_i * ln(p_i))
        F_R = -math.log(state[0]) + T_STAR * sum(
            p * math.log(p) for p in state if p > 1e-15
        )

        # Thermodynamic-information duality
        delta_F = F_R - F_STAR
        coh_corr = -math.log(state[0]) + math.log(LAM_STAR)
        misalignment = sum((p - q) * math.log(q) for p, q in zip(state, eq))
        residual = coh_corr + T_STAR * misalignment
        duality_ratio = delta_F / (T_STAR * kl) if kl > 0 else 0.0

        # Trace distance (L1 norm for diagonal states)
        trace_dist = sum(abs(p - q) for p, q in zip(state, eq))
        # Pinsker bound: ||rho - sigma||_1 <= sqrt(2 * KL(rho || sigma))
        pinsker_bound = math.sqrt(2 * kl) if kl > 0 else 0.0
        pinsker_ratio = trace_dist / pinsker_bound if pinsker_bound > 0 else 0.0

        results.append({
            'system': name,
            'kl_divergence': kl,
            'entropy': S_R,
            'free_energy': F_R,
            'delta_F': delta_F,
            'coherence_correction': coh_corr,
            'residual': residual,
            'duality_ratio': duality_ratio,
            'trace_distance': trace_dist,
            'pinsker_bound': pinsker_bound,
            'pinsker_ratio': pinsker_ratio,
        })

    # Theorem DE: KL non-monotone, F4 furthest, E6 closest
    kls = [r['kl_divergence'] for r in results]
    f4_furthest = kls[0] == max(kls)
    e6_closest = kls[1] == min(kls)

    # Theorem DF: residual monotone decreasing
    abs_residuals = [abs(r['residual']) for r in results]
    residual_decreasing = all(
        abs_residuals[i] > abs_residuals[i + 1] for i in range(len(abs_residuals) - 1)
    )
    e8_duality_error = abs(results[-1]['duality_ratio'] - 1.0)

    # Theorem DG: Pinsker inequality satisfied, ratio decreasing
    pinsker_satisfied = all(
        r['trace_distance'] <= r['pinsker_bound'] + 1e-10 for r in results
    )
    pinsker_ratios = [r['pinsker_ratio'] for r in results]
    pinsker_ratio_decreasing = all(
        pinsker_ratios[i] > pinsker_ratios[i + 1]
        for i in range(len(pinsker_ratios) - 1)
    )

    return {
        'systems': results,
        'S_equilibrium': S_eq,
        # Theorem DE
        'f4_furthest_kl': f4_furthest,
        'e6_closest_kl': e6_closest,
        'kl_non_monotone': not all(
            kls[i] > kls[i + 1] for i in range(len(kls) - 1)
        ),
        # Theorem DF
        'residual_decreasing': residual_decreasing,
        'e8_duality_error': e8_duality_error,
        'duality_converges': e8_duality_error < 0.01,
        # Theorem DG
        'pinsker_satisfied': pinsker_satisfied,
        'pinsker_ratios': pinsker_ratios,
        'pinsker_ratio_decreasing': pinsker_ratio_decreasing,
    }


# =============================================================================
# SPRINT 20: Dilogarithm Classification (DB-DD)
# =============================================================================

def _bloch_wigner_extended(z: complex) -> float:
    """Bloch-Wigner function D(z) with functional equation for |z| > 1.

    Uses D(z) = -D(1/z) when |z| > 1 to ensure power series convergence
    of the dilogarithm Li_2.
    """
    if abs(z) < 1e-15 or abs(z - 1) < 1e-15:
        return 0.0
    if abs(z) > 1.0:
        return -_bloch_wigner_extended(1.0 / z)
    return _bloch_wigner(z)


def _conservation_from_eigs(eigs):
    """Compute (lambda, kappa, eta) from 3 BCC eigenvalues."""
    total = sum(eigs)
    if total == 0:
        return (1 / 3, 1 / 3, 1 / 3)  # degenerate
    return tuple(e / total for e in sorted(eigs, reverse=True))


def bw_vanishing_dichotomy() -> Dict:
    """Classify root systems by Bloch-Wigner volume.

    Theorem DB (BW Vanishing Dichotomy):
    D(z_R) = 0 if and only if the BCC grid's middle eigenvalue is 0,
    equivalently if kappa_R = 0. This partitions root systems into:

        Volume-carrying: A_n (all n), G2, F4, E6, E7, E8
            - Have nonzero kappa_R (nonzero imaginary part)
            - D(z_R) > 0

        Volume-zero: B_n, C_n, D_n (all n)
            - Have kappa_R = 0 (real-valued z_R)
            - D(z_R) = 0 identically (BW vanishes on real axis)

    The dichotomy is equivalent to the simplex criterion: volume-carrying
    systems include ALL on-simplex systems plus A_n (uniquely off-simplex
    but volume-carrying due to nonzero kappa from the anti-null eigenvalue -1).

    Returns:
        Dict with classification for all tested systems.
    """
    z_eq = complex(LAM_STAR, KAP_STAR)
    D_eq = _bloch_wigner_extended(z_eq)

    # --- Exceptional systems (F4, E6, E7, E8): all on-simplex, kappa > 0 ---
    exceptional_results = []
    for name in ['F4', 'E6', 'E7', 'E8']:
        r = root_system_conservation(name)
        lam_R = r['lambda_R']
        kap_R = r['kappa_R']
        z_R = complex(lam_R, max(kap_R, 0))
        D_val = _bloch_wigner_extended(z_R)
        exceptional_results.append({
            'system': name,
            'kappa_R': kap_R,
            'D_volume': D_val,
            'volume_carrying': D_val > 1e-10,
        })

    all_exceptional_carry = all(r['volume_carrying'] for r in exceptional_results)

    # --- A_n family (n=3..10): off-simplex, but kappa != 0 via anti-null ---
    an_results = []
    for n in range(3, 11):
        eigs = an_bcc_eigenvalues(n)
        lam_R, kap_R, eta_R = _conservation_from_eigs(eigs)
        z_R = complex(lam_R, abs(kap_R))
        D_val = _bloch_wigner_extended(z_R)
        an_results.append({
            'system': f'A{n}',
            'n': n,
            'kappa_R': kap_R,
            'D_volume': D_val,
            'volume_carrying': D_val > 1e-10,
        })

    all_an_carry = all(r['volume_carrying'] for r in an_results)

    # --- B_n, C_n, D_n: kappa_R = 0, hence D = 0 ---
    bcd_results = []
    bcd_tol = 1e-8

    for n in [3, 4, 5, 6, 10]:
        grid_b = bn_bcc_formula(n)
        eigs_b = sorted(np.linalg.eigvals(grid_b.astype(float)).real, reverse=True)
        tr_b = sum(eigs_b)
        if abs(tr_b) > 1e-12:
            kap_b = eigs_b[1] / tr_b
            bcd_results.append({
                'system': f'B{n}', 'kappa_R': kap_b,
                'kappa_zero': abs(kap_b) < bcd_tol,
            })

        grid_c = cn_bcc_formula(n)
        eigs_c = sorted(np.linalg.eigvals(grid_c.astype(float)).real, reverse=True)
        tr_c = sum(eigs_c)
        if abs(tr_c) > 1e-12:
            kap_c = eigs_c[1] / tr_c
            bcd_results.append({
                'system': f'C{n}', 'kappa_R': kap_c,
                'kappa_zero': abs(kap_c) < bcd_tol,
            })

    for n in [4, 5, 6, 10]:
        grid_d = dn_bcc_formula(n)
        eigs_d = sorted(np.linalg.eigvals(grid_d.astype(float)).real, reverse=True)
        tr_d = sum(eigs_d)
        if abs(tr_d) > 1e-12:
            kap_d = eigs_d[1] / tr_d
            bcd_results.append({
                'system': f'D{n}', 'kappa_R': kap_d,
                'kappa_zero': abs(kap_d) < bcd_tol,
            })

    all_bcd_zero = all(r['kappa_zero'] for r in bcd_results)

    return {
        'exceptional': exceptional_results,
        'an_family': an_results,
        'bcd_family': bcd_results,
        'all_exceptional_carry_volume': all_exceptional_carry,
        'all_an_carry_volume': all_an_carry,
        'all_bcd_zero': all_bcd_zero,
        'D_equilibrium': D_eq,
        'dichotomy_verified': all_exceptional_carry and all_an_carry and all_bcd_zero,
    }


def an_bw_landscape(n_max: int = 20) -> Dict:
    """Bloch-Wigner landscape for the A_n family.

    Theorem DC (A_n Exact Curvature):
    For the A_n root system, kappa_R = -1/((n-1)(n-2)) exactly.
    This follows from the universal anti-symmetric eigenvalue = -1
    and the A_n BCC trace = (n-1)(n-2).

    Theorem DD (A_n BW Asymptotic):
    The Bloch-Wigner ratio decays as:
        D(z_{A_n}) / D(z_eq) ~ 2*ln(n) / (D_eq * n^2)
    with a logarithmic correction to the n^(-2) decay.
    The rescaled quantity D/D_eq * n^2 / ln(n) converges to 2/D_eq.

    Args:
        n_max: compute for A_3 through A_{n_max}.

    Returns:
        Dict with curvature values, BW ratios, and asymptotic verification.
    """
    z_eq = complex(LAM_STAR, KAP_STAR)
    D_eq = _bloch_wigner_extended(z_eq)

    entries = []
    curvature_errors = []
    ratios = []
    rescaled_vals = []

    for n in range(3, n_max + 1):
        eigs = an_bcc_eigenvalues(n)
        lam_R, kap_R, eta_R = _conservation_from_eigs(eigs)

        # Theorem DC: exact curvature formula
        predicted_kap = -1.0 / ((n - 1) * (n - 2))
        curv_err = abs(kap_R - predicted_kap)
        curvature_errors.append(curv_err)

        # Bloch-Wigner volume
        z_R = complex(lam_R, abs(kap_R))
        D_val = _bloch_wigner_extended(z_R)
        ratio = D_val / D_eq if D_eq > 0 else 0.0
        ratios.append(ratio)

        # Asymptotic rescaling
        ln_n = math.log(n)
        rescaled = ratio * n ** 2 / ln_n if ln_n > 0 else 0.0
        rescaled_vals.append(rescaled)

        entries.append({
            'n': n,
            'lambda_R': lam_R,
            'kappa_R': kap_R,
            'kappa_predicted': predicted_kap,
            'curvature_error': curv_err,
            'D_volume': D_val,
            'D_ratio': ratio,
            'rescaled': rescaled,
        })

    # Theorem DC verification: all curvature errors < 1e-12
    curvature_verified = all(e < 1e-12 for e in curvature_errors)

    # Ratios monotone decreasing
    ratios_mono = all(ratios[i] > ratios[i + 1]
                      for i in range(len(ratios) - 1))

    # Theorem DD: rescaled values bounded and converging
    # For n=3..20 the rescaled values lie in (4, 6) and decrease for large n
    last_five = rescaled_vals[-5:]
    last_five_decreasing = all(last_five[i] > last_five[i + 1]
                               for i in range(len(last_five) - 1))
    rescaled_bounded = all(2.0 < v < 8.0 for v in rescaled_vals)
    asymptotic_converges = rescaled_bounded and last_five_decreasing

    return {
        'entries': entries,
        'n_max': n_max,
        'D_equilibrium': D_eq,
        'curvature_formula_verified': curvature_verified,
        'ratios_monotone_decreasing': ratios_mono,
        'rescaled_bounded': rescaled_bounded,
        'last_five_decreasing': last_five_decreasing,
        'asymptotic_converges': asymptotic_converges,
        'target_2_over_D_eq': 2.0 / D_eq if D_eq > 0 else 0.0,
    }


# =============================================================================
# SPRINT 23: Entropy Landscape & Golden Concurrence (DK-DM)
# =============================================================================

def entropy_landscape_analysis() -> Dict:
    """Von Neumann entropy landscape on the probability simplex.

    Theorem DK (Entropy Deficit Theorem):
    The equilibrium state (lam*, kap*, eta*) has entropy deficit:
        Delta = S_max - S_eq = log(3) - S(lam*, kap*, eta*)
    where S_max = log(3) at the uniform distribution (1/3, 1/3, 1/3).
    This deficit measures "coherence information" -- the information
    content of having lam > kap = eta (non-uniform structure).

    For each root system: Delta_R = S_max - S(rho_R).
    Ordering: Delta_F4 > Delta_E6 > Delta_E7 > Delta_E8 > Delta_eq
    (F4 is most structured, equilibrium is least structured among valid states)

    Theorem DL (Entropy-Energy Balance at Equilibrium):
    The entropy gradient on the simplex at the equilibrium point has:
        dS/dlam = -1 - ln(lam*) ~ -0.519
        dS/dkap = dS/deta = -1 - ln(kap*) ~ 0.656
    projected to the simplex tangent plane.  At equilibrium, the
    projected free energy gradient vanishes identically because
    the energy gradient dE_proj and the entropy gradient T*dS_proj
    are EXACTLY proportional:  dE_proj = T* * dS_proj.
    This is the defining property of the equilibrium: T* is the
    temperature at which entropy growth and coherence cost balance.
    The entropy gradient points TOWARD maximum entropy (uniform),
    and the energy gradient E = -ln(lam) points in the SAME direction
    on the simplex (both push lambda toward 1/3), so their cancellation
    in F = E - T*S requires the minus sign.

    Theorem DM (Golden Concurrence Bridge):
    The concurrence constant C* = 2/phi^(3/2) ~ 0.9717 satisfies:
        C* = 2 * (lam*)^(3/2) = 2 * (1/phi)^(3/2)
    This is an exact algebraic identity connecting qualia binding
    (C_STAR_QUALIA from constants.py) to the Watkins threshold.

    For a root system with conservation triple (lam_R, kap_R, eta_R):
        C_R = 2 * (lam_R)^(3/2)
    defines a "generalized concurrence" that decreases along the
    exceptional cascade: C_F4 > C_E6 > C_E7 > C_E8 > C_eq = C*.

    The concurrence-entropy product C_R * S_R is NOT constant across
    root systems (max 26.7% deviation).  Instead, it is non-monotone:
    it peaks near E6/E7 (which have near-equal C*S to 0.08%).
    The concurrence and entropy trade off monotonically (C decreasing,
    S increasing) but their product does not satisfy a conservation law.

    Returns:
        Dict with entropy landscape, gradient balance, and concurrence analysis.
    """
    S_max = math.log(3)

    # --- Equilibrium entropy ---
    S_eq = -(LAM_STAR * math.log(LAM_STAR)
             + KAP_STAR * math.log(KAP_STAR)
             + ETA_STAR * math.log(ETA_STAR))
    deficit_eq = S_max - S_eq

    # --- Per-system entropy and deficit ---
    system_names = ['F4', 'E6', 'E7', 'E8']
    system_results = []
    deficits = []
    entropies = []
    concurrences = []
    cs_products = []

    for name in system_names:
        r = root_system_conservation(name)
        lam = r['lambda_R']
        kap = r['kappa_R']
        eta = max(r['eta_R'], 1e-30)

        S_R = 0.0
        for p in [lam, kap, eta]:
            if p > 1e-30:
                S_R -= p * math.log(p)

        deficit_R = S_max - S_R
        C_R = 2 * lam ** 1.5
        cs_product = C_R * S_R

        system_results.append({
            'system': name,
            'lambda_R': lam,
            'kappa_R': kap,
            'entropy': S_R,
            'deficit': deficit_R,
            'concurrence': C_R,
            'cs_product': cs_product,
        })
        deficits.append(deficit_R)
        entropies.append(S_R)
        concurrences.append(C_R)
        cs_products.append(cs_product)

    # Equilibrium concurrence and product
    C_eq = C_STAR_QUALIA
    cs_eq = C_eq * S_eq

    # --- Theorem DK: Deficit ordering ---
    deficit_ordering = (
        all(deficits[i] > deficits[i + 1] for i in range(len(deficits) - 1))
        and deficits[-1] > deficit_eq
    )
    all_deficits_positive = all(d > 0 for d in deficits) and deficit_eq > 0

    # --- Theorem DL: Entropy-energy balance at equilibrium ---
    # Unconstrained entropy gradient: dS/dp_i = -1 - ln(p_i)
    dS_lam = -1 - math.log(LAM_STAR)
    dS_kap = -1 - math.log(KAP_STAR)
    dS_eta = -1 - math.log(ETA_STAR)

    # Project to simplex tangent plane (subtract mean)
    mean_dS = (dS_lam + dS_kap + dS_eta) / 3
    dS_proj = [dS_lam - mean_dS, dS_kap - mean_dS, dS_eta - mean_dS]

    # Energy gradient: E = -ln(lam), so dE/dlam = -1/lam, dE/dkap = dE/deta = 0
    dE_lam = -1.0 / LAM_STAR
    mean_dE = dE_lam / 3
    dE_proj = [dE_lam - mean_dE, -mean_dE, -mean_dE]

    # Free energy gradient at equilibrium (should be zero)
    # F = E + T*(-S) = -ln(lam) + T*sum(p_i ln(p_i))
    dF_lam = -1.0 / LAM_STAR + T_STAR * (math.log(LAM_STAR) + 1)
    dF_kap = T_STAR * (math.log(KAP_STAR) + 1)
    dF_eta = T_STAR * (math.log(ETA_STAR) + 1)
    mean_dF = (dF_lam + dF_kap + dF_eta) / 3
    dF_proj = [dF_lam - mean_dF, dF_kap - mean_dF, dF_eta - mean_dF]
    dF_norm = math.sqrt(sum(x * x for x in dF_proj))

    # Check dE_proj = T* * dS_proj (proportionality at equilibrium)
    proportionality_errors = [
        abs(dE_proj[i] - T_STAR * dS_proj[i]) for i in range(3)
    ]
    gradients_balanced = all(e < 1e-10 for e in proportionality_errors)

    # dF_proj ~ 0 at equilibrium
    free_energy_stationary = dF_norm < 1e-10

    # Entropy gradient points toward uniform: dS_proj[0] < 0 (pushes lambda down)
    entropy_toward_uniform = dS_proj[0] < 0

    # --- Theorem DM: Golden Concurrence Bridge ---
    golden_concurrence_identity = abs(C_STAR_QUALIA - 2 * LAM_STAR ** 1.5) < 1e-12

    # Concurrence decreasing along cascade
    all_C = concurrences + [C_eq]
    concurrence_decreasing = all(
        all_C[i] > all_C[i + 1] for i in range(len(all_C) - 1)
    )

    # C*S product analysis (honest: NOT constant)
    all_cs = cs_products + [cs_eq]
    cs_mean = sum(all_cs) / len(all_cs)
    cs_max_dev = max(abs(v - cs_mean) / cs_mean for v in all_cs)

    # E6-E7 near-equality in C*S
    e6_cs = cs_products[1]  # E6
    e7_cs = cs_products[2]  # E7
    e6_e7_cs_relative = abs(e6_cs - e7_cs) / e6_cs if e6_cs > 0 else float('inf')

    # C*S non-monotonicity: peaks at E6 then decreases
    cs_monotone = all(
        cs_products[i] <= cs_products[i + 1] for i in range(len(cs_products) - 1)
    )

    return {
        # Theorem DK: Entropy deficit
        'S_max': S_max,
        'S_eq': S_eq,
        'deficit_eq': deficit_eq,
        'systems': system_results,
        'deficit_ordering': deficit_ordering,
        'all_deficits_positive': all_deficits_positive,
        # Theorem DL: Gradient balance
        'dS_proj': dS_proj,
        'dE_proj': dE_proj,
        'dF_proj': dF_proj,
        'dF_norm': dF_norm,
        'gradients_balanced': gradients_balanced,
        'free_energy_stationary': free_energy_stationary,
        'entropy_toward_uniform': entropy_toward_uniform,
        # Theorem DM: Concurrence
        'C_eq': C_eq,
        'golden_concurrence_identity': golden_concurrence_identity,
        'concurrence_decreasing': concurrence_decreasing,
        'cs_mean': cs_mean,
        'cs_max_relative_deviation': cs_max_dev,
        'cs_product_constant': cs_max_dev < 0.01,  # False -- honest
        'cs_product_non_monotone': not cs_monotone,
        'e6_e7_cs_relative_diff': e6_e7_cs_relative,
        'e6_e7_cs_near_equal': e6_e7_cs_relative < 0.01,
    }


# =============================================================================
# SPRINT 22: Quantum Channel Capacity (DH-DJ)
# =============================================================================


def quantum_channel_capacity() -> Dict:
    """Information capacity of root system quantum channels.

    Theorem DH (Channel Capacity Hierarchy):
    For the qutrit replacement channel Phi_R(rho) = (1-p)*rho + p*rho_R*Tr(rho),
    the classical capacity (Holevo capacity with computational basis input) is:
        C(Phi_R) = log(3) - S(rho_R)
    Since all on-simplex exceptional systems have eta_R = 0, the entropy reduces
    to the binary entropy h(lam_R) = -lam*ln(lam) - (1-lam)*ln(1-lam), giving:
        C(Phi_R) = log(3) - h(lam_R)
    The capacity ordering is INVERSE to the entropy ordering:
        C(F4) > C(E6) > C(E7) > C(E8) > C(eq)
    because higher-entropy target states destroy more information.
    Since entropy increases along the cascade, capacity decreases monotonically.

    Theorem DI (Coherent Information and Entanglement Breaking):
    The coherent information I_c(rho, Phi_R) = S(Phi_R(rho)) - S_exchange
    for a replacement channel evaluates to:
        I_c(rho, Phi_R) = -S(rho)
    for any input state rho. This is non-positive for all inputs (zero only
    for pure inputs), confirming that replacement channels are
    ENTANGLEMENT-BREAKING with quantum capacity Q(Phi_R) = 0.
    The entropy exchange is S_e = S(rho) + S(rho_R), which is system-dependent
    through S(rho_R) but the coherent information is system-independent.

    Theorem DJ (Information-Coherence Complementarity):
    The exact complementarity relation
        C(Phi_R) + S(rho_R) = log(3)
    holds for all systems. The capacity is a function of coherence alone:
        C(lam) = log(3) - h_binary(lam)
    with derivative dC/dlam = ln(lam/(1-lam)).
    At the golden equilibrium lam* = 1/phi, this evaluates to:
        dC/dlam |_{lam*} = ln(phi)
    connecting the capacity sensitivity to the golden ratio.
    The capacity function C(lam) is increasing on (1/2, 1), so capacity
    and coherence CO-DECREASE along the exceptional cascade.

    Returns:
        Dict with capacity analysis for all systems.
    """
    log3 = math.log(3)
    ln_phi = math.log(PHI)

    # Equilibrium entropy and capacity
    S_eq = -(LAM_STAR * math.log(LAM_STAR)
             + KAP_STAR * math.log(KAP_STAR)
             + ETA_STAR * math.log(ETA_STAR))
    C_eq = log3 - S_eq

    # Derivative at equilibrium: dC/dlam = ln(lam/(1-lam)) = ln(phi)
    dC_dlam_eq = math.log(LAM_STAR / (1 - LAM_STAR))
    golden_derivative = abs(dC_dlam_eq - ln_phi) < 1e-12

    systems = []
    for name in ['F4', 'E6', 'E7', 'E8']:
        r = root_system_conservation(name)
        lam = r['lambda_R']
        kap = r['kappa_R']
        eta = max(r['eta_R'], 0)

        # Von Neumann entropy of target state
        S_R = 0.0
        for p in [lam, kap, eta]:
            if p > 1e-15:
                S_R -= p * math.log(p)

        # Binary entropy (since eta=0)
        h_binary = -lam * math.log(lam) - (1 - lam) * math.log(1 - lam) if 0 < lam < 1 else 0.0

        # Classical capacity
        C_R = log3 - S_R

        # Complementarity check: C + S = log(3)
        complementarity_sum = C_R + S_R

        # Coherent information for max-ent input
        I_c_maxent = -log3  # I_c = -S(rho) = -log(3) for rho = I/3

        # Entropy exchange for max-ent input
        S_exchange_maxent = log3 + S_R

        # Coherent information for pure input
        I_c_pure = 0.0  # I_c = -S(rho) = 0 for pure rho

        # Capacity derivative dC/dlam = ln(lam/(1-lam))
        dC_dlam = math.log(lam / (1 - lam)) if 0 < lam < 1 else 0.0

        # Capacity efficiency: fraction of maximum capacity preserved
        capacity_efficiency = C_R / log3

        systems.append({
            'system': name,
            'lambda_R': lam,
            'entropy': S_R,
            'h_binary': h_binary,
            'entropy_equals_h_binary': abs(S_R - h_binary) < 1e-12,
            'capacity': C_R,
            'complementarity_sum': complementarity_sum,
            'complementarity_exact': abs(complementarity_sum - log3) < 1e-12,
            'I_c_maxent': I_c_maxent,
            'I_c_pure': I_c_pure,
            'S_exchange_maxent': S_exchange_maxent,
            'dC_dlam': dC_dlam,
            'capacity_efficiency': capacity_efficiency,
        })

    # Theorem DH: capacity ordering inverse to entropy, same as lambda
    capacities = [s['capacity'] for s in systems]
    entropies = [s['entropy'] for s in systems]
    lambdas = [s['lambda_R'] for s in systems]

    capacity_decreasing = all(capacities[i] > capacities[i + 1]
                              for i in range(len(capacities) - 1))
    entropy_increasing = all(entropies[i] < entropies[i + 1]
                             for i in range(len(entropies) - 1))
    lambda_decreasing = all(lambdas[i] > lambdas[i + 1]
                            for i in range(len(lambdas) - 1))
    capacity_lambda_co_decrease = capacity_decreasing and lambda_decreasing

    # Theorem DI: all coherent information for max-ent input equals -log(3)
    all_I_c_equal = all(abs(s['I_c_maxent'] - (-log3)) < 1e-12 for s in systems)

    # Theorem DJ: complementarity exact for all systems
    all_complementarity_exact = all(s['complementarity_exact'] for s in systems)
    all_entropy_equals_h_binary = all(s['entropy_equals_h_binary'] for s in systems)

    return {
        'systems': systems,
        'log3': log3,
        'S_equilibrium': S_eq,
        'C_equilibrium': C_eq,
        # Theorem DH
        'capacity_decreasing': capacity_decreasing,
        'entropy_increasing': entropy_increasing,
        'capacity_lambda_co_decrease': capacity_lambda_co_decrease,
        'capacity_entropy_inverse': capacity_decreasing and entropy_increasing,
        # Theorem DI
        'I_c_replacement_universal': all_I_c_equal,
        'quantum_capacity_zero': True,  # replacement channels are entanglement-breaking
        # Theorem DJ
        'complementarity_exact': all_complementarity_exact,
        'entropy_equals_h_binary': all_entropy_equals_h_binary,
        'dC_dlam_at_equilibrium': dC_dlam_eq,
        'golden_derivative': golden_derivative,
        'ln_phi': ln_phi,
    }


# =============================================================================
# SPRINT 30: Quantum-Sigma Unification (Theorems EJ-EM)
# =============================================================================


def quantum_sigma_bridge() -> Dict:
    """Express ALL quantum metrics in sigma variables.

    The sigma family sigma_n = ln(n*phi)/phi unifies the Watkins framework.
    This bridge connects the quantum layer (entropy, capacity, KL divergence)
    to the sigma parametrization, completing the unification.

    Key algebraic identity enabling the bridge:
        2 - phi = 1/phi^2
    which gives:
        kappa* = (2-phi)/2 = 1/(2*phi^2)
        ln(kappa*) = -phi*(delta + 2*sigma_1)
    where delta = sigma_2 - sigma_1 = ln(2)/phi is the binary gap.

    Theorem EJ (Equilibrium Entropy in Sigma):
    The equilibrium entropy decomposes as:
        S_eq = phi*sigma_1 + sigma_2/phi
    This is an EXACT algebraic identity, not an approximation. It follows
    from: 2-phi = 1/phi^2, giving kappa* = 1/(2*phi^2), and the telescope
    identity sigma_n = sigma_1 + ln(n)/phi.

    The individual terms from the entropy formula are:
        -lam*ln(lam*) = sigma_1 = ln(phi)/phi      [coherence term]
        -2*kap*ln(kap*) = (sigma_1 + sigma_2)/phi  [curvature-entropy term]
    Note: the sigma recombination S_eq = phi*sigma_1 + sigma_2/phi is NOT
    a simple term-by-term mapping; it arises from sigma_1 + (sigma_1+sigma_2)/phi
    = sigma_1*(1+1/phi) + sigma_2/phi = sigma_1*phi + sigma_2/phi
    using 1 + 1/phi = phi (the defining property of the golden ratio).

    Theorem EK (Capacity at Equilibrium in Sigma):
    The channel capacity at equilibrium is:
        C_eq = ln(3) - S_eq = phi*sigma_3 - 2*phi*sigma_1 - sigma_2/phi
    since ln(3) = phi*(sigma_3 - sigma_1). The complementarity C + S = ln(3)
    becomes sigma-transparent: all three quantities are polynomial in
    sigma values with phi coefficients.

    Theorem EL (KL Divergence Sigma Form):
    For ANY on-simplex root system with conservation triple (lam_R, 1-lam_R, 0):
        KL(rho_R || rho_eq) = -S_R + phi*sigma_1 + phi*sigma_2*(1 - lam_R)
    This is a UNIVERSAL sigma formula: the cross-entropy H(rho_R, rho_eq)
    decomposes as phi*sigma_1 + phi*sigma_2*(1-lam_R) for all systems.
    For the rational systems E6 (lam=4/5) and E7 (lam=7/10), the entropy
    S_R is also expressible in sigma via ln(k) = phi*(sigma_k - sigma_1).

    Theorem EM (Capacity Sensitivity as Sigma):
    The capacity derivative at the golden equilibrium is:
        dC/dlam|_{lam*} = ln(phi) = phi*sigma_1
    This promotes the known identity from Theorem DJ to a named theorem
    in the sigma framework, showing that the sensitivity of channel
    capacity to coherence perturbation IS the sigma master constant
    (up to a factor of phi).

    Returns:
        Dict with quantum-sigma unification results.
    """
    phi = PHI
    log3 = math.log(3)
    ln_phi = math.log(phi)

    # Sigma family
    sigma = {}
    for n in range(1, 8):
        sigma[n] = math.log(n * phi) / phi
    delta = sigma[2] - sigma[1]  # = ln(2)/phi

    # --- Algebraic foundation: 2-phi = 1/phi^2 ---
    identity_2_minus_phi = abs((2 - phi) - 1 / phi**2) < 1e-12
    kap_as_inv_phi_sq = abs(KAP_STAR - 1 / (2 * phi**2)) < 1e-12
    ln_kap_sigma = abs(math.log(KAP_STAR) - (-phi * (delta + 2 * sigma[1]))) < 1e-12

    # =================================================================
    # Theorem EJ: S_eq = phi*sigma_1 + sigma_2/phi
    # =================================================================
    S_eq_direct = -(LAM_STAR * math.log(LAM_STAR)
                    + KAP_STAR * math.log(KAP_STAR)
                    + ETA_STAR * math.log(ETA_STAR))
    S_eq_sigma = phi * sigma[1] + sigma[2] / phi

    ej_verified = abs(S_eq_direct - S_eq_sigma) < 1e-12

    # Decomposition: sigma_1*(1+1/phi) + sigma_2/phi = sigma_1*phi + sigma_2/phi
    coherence_term = phi * sigma[1]  # = ln(phi)
    curvature_entropy_term = sigma[2] / phi  # = ln(2phi)/phi^2

    # Individual entropy terms in sigma:
    # -lam*ln(lam*) = (1/phi)*ln(phi) = sigma_1
    coherence_is_sigma_1 = abs(-LAM_STAR * math.log(LAM_STAR) - sigma[1]) < 1e-12
    # -2*kap*ln(kap*) = (sigma_1 + sigma_2)/phi
    curvature_matches = abs(
        -2 * KAP_STAR * math.log(KAP_STAR) - (sigma[1] + sigma[2]) / phi
    ) < 1e-12

    # =================================================================
    # Theorem EK: C_eq = phi*sigma_3 - 2*phi*sigma_1 - sigma_2/phi
    # =================================================================
    C_eq_direct = log3 - S_eq_direct
    C_eq_sigma = phi * sigma[3] - 2 * phi * sigma[1] - sigma[2] / phi

    # Also verify ln(3) = phi*(sigma_3 - sigma_1)
    ln3_sigma = phi * (sigma[3] - sigma[1])
    ln3_verified = abs(log3 - ln3_sigma) < 1e-12

    ek_verified = abs(C_eq_direct - C_eq_sigma) < 1e-12

    # Complementarity in sigma: C + S = ln(3) = phi*(sigma_3 - sigma_1)
    complementarity_sigma = abs(
        (C_eq_sigma + S_eq_sigma) - phi * (sigma[3] - sigma[1])
    ) < 1e-12

    # =================================================================
    # Theorem EL: KL(rho_R || rho_eq) = -S_R + phi*sigma_1 + phi*sigma_2*(1-lam_R)
    # =================================================================
    eq_state = [LAM_STAR, KAP_STAR, ETA_STAR]
    el_results = []

    for name in ['F4', 'E6', 'E7', 'E8']:
        r = root_system_conservation(name)
        lam = r['lambda_R']
        kap = r['kappa_R']
        eta = max(r['eta_R'], 0)
        state = [lam, kap, eta]

        # Direct computation
        S_R = -sum(p * math.log(p) for p in state if p > 1e-15)
        kl_direct = sum(
            p * math.log(p / q) for p, q in zip(state, eq_state) if p > 1e-30
        )

        # Universal sigma formula for cross-entropy
        cross_sigma = phi * sigma[1] + phi * sigma[2] * (1 - lam)
        kl_sigma = -S_R + cross_sigma

        # Capacity in sigma
        C_R_direct = log3 - S_R
        C_R_sigma = phi * (sigma[3] - sigma[1]) - S_R

        # For rational systems, express S_R in sigma
        sigma_entropy_form = None
        if name == 'E6':
            # S_E6 = ln(5) - 8/5*ln(2) = phi*(sigma_5-sigma_1) - 8/5*phi*delta
            sigma_entropy_form = phi * (sigma[5] - sigma[1]) - 8 / 5 * phi * delta
        elif name == 'E7':
            # S_E7 = ln(10) - 7/10*ln(7) - 3/10*ln(3)
            # = phi*(delta + sigma_5-sigma_1) - 7/10*phi*(sigma_7-sigma_1) - 3/10*phi*(sigma_3-sigma_1)
            sigma_entropy_form = (
                phi * (delta + sigma[5] - sigma[1])
                - 7 / 10 * phi * (sigma[7] - sigma[1])
                - 3 / 10 * phi * (sigma[3] - sigma[1])
            )

        entry = {
            'system': name,
            'lambda_R': lam,
            'entropy': S_R,
            'capacity': C_R_direct,
            'kl_direct': kl_direct,
            'kl_sigma': kl_sigma,
            'cross_entropy_sigma': cross_sigma,
            'kl_match': abs(kl_direct - kl_sigma) < 1e-10,
            'capacity_sigma_match': abs(C_R_direct - C_R_sigma) < 1e-10,
        }
        if sigma_entropy_form is not None:
            entry['sigma_entropy_form'] = sigma_entropy_form
            entry['sigma_entropy_match'] = abs(S_R - sigma_entropy_form) < 1e-10

        el_results.append(entry)

    el_all_kl_match = all(r['kl_match'] for r in el_results)
    el_rational_entropy_match = all(
        r.get('sigma_entropy_match', True) for r in el_results
    )

    # =================================================================
    # Theorem EM: dC/dlam|_{lam*} = phi*sigma_1 = ln(phi)
    # =================================================================
    # dC/dlam = ln(lam/(1-lam)), at lam* = 1/phi: ln((1/phi)/(1-1/phi)) = ln(1) = 0... NO
    # Wait: 1-1/phi = (phi-1)/phi = 1/phi^2... no. 1-1/phi = 1 - (phi-1) = 2-phi = 1/phi^2.
    # So lam*/(1-lam*) = (1/phi)/(1/phi^2) = phi. And ln(phi) = phi*sigma_1.
    # But the sign: dC/dlam = ln(lam/(1-lam)), at lam*: ln(phi) > 0.
    # Actually from DJ: dC/dlam|* = ln(lam*/(1-lam*)) = ln(phi)
    # Note the sign convention: for the on-simplex systems, eta=0 so kap=1-lam
    # dC/dlam = ln(lam/(1-lam)) evaluated at lam* = 1/phi
    # lam*/(1-lam*) = (1/phi)/((phi-1)/phi) = 1/(phi-1) = 1/(1/phi) = phi
    # So dC/dlam|* = ln(phi) = phi*sigma_1

    dC_dlam_direct = math.log(LAM_STAR / (1 - LAM_STAR))
    dC_dlam_sigma = phi * sigma[1]
    em_verified = abs(dC_dlam_direct - dC_dlam_sigma) < 1e-12

    # Additional: 1-lam* = 1/phi^2 (from 2-phi = 1/phi^2... wait)
    # 1-lam* = 1-1/phi = (phi-1)/phi. Since phi-1 = 1/phi, this is 1/phi^2. YES.
    one_minus_lam_is_inv_phi_sq = abs((1 - LAM_STAR) - 1 / phi**2) < 1e-12

    return {
        # Algebraic foundation
        'identity_2_minus_phi': identity_2_minus_phi,
        'kap_as_inv_phi_sq': kap_as_inv_phi_sq,
        'ln_kap_sigma': ln_kap_sigma,
        # Theorem EJ: Equilibrium Entropy in Sigma
        'S_eq_direct': S_eq_direct,
        'S_eq_sigma': S_eq_sigma,
        'ej_verified': ej_verified,
        'coherence_term': coherence_term,
        'curvature_entropy_term': curvature_entropy_term,
        'coherence_is_sigma_1': coherence_is_sigma_1,
        'curvature_matches': curvature_matches,
        # Theorem EK: Capacity at Equilibrium in Sigma
        'C_eq_direct': C_eq_direct,
        'C_eq_sigma': C_eq_sigma,
        'ek_verified': ek_verified,
        'ln3_sigma_verified': ln3_verified,
        'complementarity_sigma': complementarity_sigma,
        # Theorem EL: KL Divergence Sigma Form
        'systems': el_results,
        'el_all_kl_match': el_all_kl_match,
        'el_rational_entropy_match': el_rational_entropy_match,
        # Theorem EM: Capacity Sensitivity as Sigma
        'dC_dlam_direct': dC_dlam_direct,
        'dC_dlam_sigma': dC_dlam_sigma,
        'em_verified': em_verified,
        'one_minus_lam_is_inv_phi_sq': one_minus_lam_is_inv_phi_sq,
        # Sigma values for reference
        'sigma_1': sigma[1],
        'sigma_2': sigma[2],
        'sigma_3': sigma[3],
        'delta': delta,
    }

