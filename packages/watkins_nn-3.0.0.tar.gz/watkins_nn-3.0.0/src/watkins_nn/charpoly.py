"""
Characteristic Polynomial of the Kaleidoscope Matrix — Theorems Q, W
=====================================================================

The characteristic polynomial p_n(λ) = λ³ - p₁λ² + p₂λ - p₃ where:

    p₁ = tr(M)     = seq2 + seq8 + L(2n)
    p₂ = tr(adj(M)) = C₀₀ + Δ_ML + C₂₂
    p₃ = det(M)     = Sarrus expansion in seq1-seq9

All three coefficients are exact integer combinations of the 9 sequences.
Cayley-Hamilton: M³ - p₁M² + p₂M - p₃I = 0.

Theorem W (Determinant Arithmetic Factorization):

    det(M(n)) = 4 · seq8(n) · (2φ²)^n / seq3(n) + O((2ψ²)^n)

The determinant lives at lattice point (2,1) = ln(2φ²) on the Kaleidoscope
hyperboloid. Since 4·seq8/seq3 > 0 and |2ψ²| < 1, this proves
det(M(n)) > 0 for all sufficiently large n (verified: all n ≥ 23).

(C) 2024-2026 Dustin Watkins / DataSphere AI, LLC. MIT License.
"""

import math
from math import gcd, factorial

from .kaleidoscope import (
    seq1_cycle_lb_numerator, seq2_mersenne_numerator, seq3_mersenne_gcd,
    seq4_lucas_numerator, seq5_lucas_gcd, seq6_mersenne_lucas_gcd,
    seq7_binary_preservation, seq8_cross_gcd, seq9_weight_moments,
    mersenne, lucas,
)

__all__ = [
    'charpoly_coefficients',
    'charpoly_eval',
    'trace_M',
    'trace_adj',
    'det_M',
    'det_M_predicted',
    'cofactor_diagonal',
]


def trace_M(n: int) -> int:
    """p₁ = tr(M(n)) = seq2(n) + seq8(n) + L(2n)."""
    return seq2_mersenne_numerator(n) + seq8_cross_gcd(n) + seq9_weight_moments(n)


def cofactor_diagonal(n: int) -> tuple:
    """Return (C₀₀, C₁₁, C₂₂) — the three cofactor diagonal entries.

    C₀₀ = seq8·L(2n) - seq7·seq5   (Bridge-Lucas minor)
    C₁₁ = seq2·L(2n) - seq1·seq4   (Δ_ML, Mersenne-Lucas minor, Theorem I)
    C₂₂ = seq2·seq8 - seq3·seq6    (Mersenne-Bridge minor)
    """
    s2 = seq2_mersenne_numerator(n)
    s3 = seq3_mersenne_gcd(n)
    s5 = seq5_lucas_gcd(n)
    s6 = seq6_mersenne_lucas_gcd(n)
    s7 = seq7_binary_preservation(n)
    s8 = seq8_cross_gcd(n)
    s1 = seq1_cycle_lb_numerator(n)
    s4 = seq4_lucas_numerator(n)
    l2n = seq9_weight_moments(n)

    c00 = s8 * l2n - s7 * s5
    c11 = s2 * l2n - s1 * s4   # Δ_ML
    c22 = s2 * s8 - s3 * s6

    return (c00, c11, c22)


def trace_adj(n: int) -> int:
    """p₂ = tr(adj(M(n))) = C₀₀ + Δ_ML + C₂₂."""
    c00, c11, c22 = cofactor_diagonal(n)
    return c00 + c11 + c22


def det_M(n: int) -> int:
    """p₃ = det(M(n)) via Sarrus expansion along the bridge row.

    det = seq6·(seq1·seq5 - seq3·L(2n))
        + seq8·(seq2·L(2n) - seq1·seq4)
        + seq7·(seq3·seq4 - seq2·seq5)
    """
    s1 = seq1_cycle_lb_numerator(n)
    s2 = seq2_mersenne_numerator(n)
    s3 = seq3_mersenne_gcd(n)
    s4 = seq4_lucas_numerator(n)
    s5 = seq5_lucas_gcd(n)
    s6 = seq6_mersenne_lucas_gcd(n)
    s7 = seq7_binary_preservation(n)
    s8 = seq8_cross_gcd(n)
    l2n = seq9_weight_moments(n)

    return (s6 * (s1 * s5 - s3 * l2n)
            + s8 * (s2 * l2n - s1 * s4)
            + s7 * (s3 * s4 - s2 * s5))


def det_M_predicted(n: int) -> float:
    """Theorem W predicted determinant: 4·seq8(n)·(2φ²)^n / seq3(n).

    Uses the spectral-point arithmetic factorization. The determinant
    lives at lattice point (2,1) on the Kaleidoscope hyperboloid, with
    growth base 2φ² = 3+√5 ≈ 5.236.

    Agrees with det_M(n) to high relative precision for n ≥ 25 when
    seq3(n) is moderate. The correction is O((2ψ²)^n) with |2ψ²| < 1.
    """
    PHI = (1 + math.sqrt(5)) / 2
    s3 = seq3_mersenne_gcd(n)
    s8 = seq8_cross_gcd(n)
    if s3 == 0:
        return float('inf')
    return 4.0 * s8 * (2 * PHI**2) ** n / s3


def charpoly_coefficients(n: int) -> tuple:
    """Return (p₁, p₂, p₃) — the three characteristic polynomial coefficients.

    p_n(λ) = λ³ - p₁λ² + p₂λ - p₃
    """
    return (trace_M(n), trace_adj(n), det_M(n))


def charpoly_eval(n: int, lam: float) -> float:
    """Evaluate the characteristic polynomial p_n(λ) at a given λ."""
    p1, p2, p3 = charpoly_coefficients(n)
    return lam**3 - p1 * lam**2 + p2 * lam - p3
