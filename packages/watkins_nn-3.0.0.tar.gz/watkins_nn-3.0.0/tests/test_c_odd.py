"""Tests for Result 29: C_odd = 2φ/9 — the odd coupling constant.

E(n)/(2φ)^n → 2φ/9 for n ≡ 1 mod 4 (medium-odd subsequence).
The even/odd energy ratio is L(2)² = 9.
Discovered via 3/2 connection: C_odd × (3/2)² = cos(π/5) = φ/2.
"""

import math

from watkins_nn.constants import PHI
from watkins_nn.coupling import coupling_energy


TWO_PHI = 2 * PHI
C_ODD = TWO_PHI / 9


def test_c_odd_is_2phi_over_9():
    """C_odd = 2φ/9 matches cos(π/5) × 4/9 = φ/2 × 4/9 = 2φ/9."""
    assert abs(C_ODD - 2 * PHI / 9) < 1e-15


def test_c_odd_times_nine_fourths_is_cos_pi5():
    """C_odd × (3/2)² = cos(π/5) = φ/2."""
    assert abs(C_ODD * 9 / 4 - math.cos(math.pi / 5)) < 1e-14


def test_coupling_energy_odd_convergence():
    """E(n)/(2φ)^n → 2φ/9 for n ≡ 1 mod 4, verified at n=37,41,45."""
    for n in [37, 41, 45]:
        E = coupling_energy(n)
        ratio = E / TWO_PHI**n
        if abs(ratio - C_ODD) / C_ODD < 0.01:  # only test non-disrupted n
            assert abs(ratio - C_ODD) / C_ODD < 1e-10, \
                f"n={n}: ratio={ratio}, expected {C_ODD}"


def test_even_odd_ratio_is_l2_squared():
    """HIGH/MEDIUM ratio = L(2)² = 9."""
    from watkins_nn.kaleidoscope import lucas
    assert lucas(2)**2 == 9
    # Even resonant / odd medium ≈ 9
    E_even = coupling_energy(36)
    E_odd = coupling_energy(37)
    ratio_even = E_even / TWO_PHI**36
    ratio_odd = E_odd / TWO_PHI**37
    phase_ratio = ratio_even / ratio_odd
    assert abs(phase_ratio - 9) < 0.01, f"phase ratio = {phase_ratio}"
