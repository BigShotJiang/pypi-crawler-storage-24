"""Test that version declarations stay in sync across the project."""
import re
import pathlib

import watkins_nn


def test_version_consistency():
    """pyproject.toml and __init__.py versions must match."""
    root = pathlib.Path(watkins_nn.__file__).resolve().parent.parent.parent
    pyproject = root / "pyproject.toml"
    if not pyproject.exists():
        return  # skip when installed from wheel (no pyproject.toml)
    text = pyproject.read_text(encoding="utf-8")
    declared = re.search(r'^version\s*=\s*"(.+?)"', text, re.M).group(1)
    assert watkins_nn.__version__ == declared, (
        f"__init__.py={watkins_nn.__version__} != pyproject.toml={declared}"
    )


def test_citation_version():
    """CITATION.cff version must match __init__.py."""
    root = pathlib.Path(watkins_nn.__file__).resolve().parent.parent.parent
    citation = root / "CITATION.cff"
    if not citation.exists():
        return  # skip when installed from wheel
    text = citation.read_text(encoding="utf-8")
    declared = re.search(r"^version:\s*(.+)", text, re.M).group(1).strip()
    assert watkins_nn.__version__ == declared, (
        f"__init__.py={watkins_nn.__version__} != CITATION.cff={declared}"
    )
