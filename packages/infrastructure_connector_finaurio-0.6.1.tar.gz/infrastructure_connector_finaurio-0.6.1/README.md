# Pypi_Infrastructure_Connector



## Getting started
alembic revision --autogenerate -m "Init"
python3 -m twine upload --repository pypi dist/*