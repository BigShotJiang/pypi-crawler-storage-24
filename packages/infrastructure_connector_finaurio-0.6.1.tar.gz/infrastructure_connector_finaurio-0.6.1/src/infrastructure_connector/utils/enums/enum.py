from enum import Enum


# 1. Alert management
class AlertCode(str, Enum):
    BROUILLON = "brouillon"
    VALIDEE = "validee"
    EXPEDIEE = "expediee"
    ANNULEE = "annulee"


# 2. Trading operations
class OperationStatus(str, Enum):
    PENDING = "PENDING"
    EXECUTED = "EXECUTED"
    CANCELED = "CANCELED"


class Direction(str, Enum):
    LONG = "LONG"
    SHORT = "SHORT"


class OperationType(str, Enum):
    OPEN = "OPEN"
    CLOSE = "CLOSE"
    PARTIAL_CLOSE = "PARTIAL_CLOSE"
    ADD = "ADD"


# 3. Timeframes
class TimeHorizon(str, Enum):
    SCALP = "SCALP"
    DAY = "DAY"
    SWING = "SWING"
    POSITION = "POSITION"


# 4. Opportunity lifecycle
class OpportunityStatus(str, Enum):
    DETECTED = "DETECTED"
    VALIDATED = "VALIDATED"
    REJECTED = "REJECTED"
    EXECUTED = "EXECUTED"
    EXPIRED = "EXPIRED"


# 5. Asset classification
class AssetClass(str, Enum):
    FOREX = "FOREX"
    COMMODITIES = "COMMODITIES"
    CRYPTO = "CRYPTO"
    STOCKS = "STOCKS"
    INDICES = "INDICES"
    BONDS = "BONDS"


class AssetSubclass(str, Enum):
    FX_MAJOR = "FX_MAJOR"
    METAL = "METAL"
    TECH = "TECH"


# 6. Strategy & objectives
class StrategyType(str, Enum):
    TREND_FOLLOWING = "TREND_FOLLOWING"
    RANGE_TRADING = "RANGE_TRADING"
    BREAKOUT = "BREAKOUT"
    MEAN_REVERSION = "MEAN_REVERSION"
    PRICE_ACTION = "PRICE_ACTION"
    CARRY = "CARRY"
    NEWS_TRADING = "NEWS_TRADING"
    MACRO_FX = "MACRO_FX"


class ObjectiveStatus(str, Enum):
    CLOSE_BY_TARGET_RETURN = "CLOSE_BY_TARGET_RETURN"
    CLOSE_BY_MAX_DRAWNDOWN = "CLOSE_BY_MAX_DRAWNDOWN"
    CLOSE_BY_TIME_HORIZON = "CLOSE_BY_TIME_HORIZON"
    IN_PROGRESS = "IN_PROGRESS"


# 7. Analysis & signals
class Bias(str, Enum):
    BULLISH = "BULLISH"
    BEARISH = "BEARISH"
    NEUTRAL = "NEUTRAL"


class AnalysisType(str, Enum):
    MACRO = "macro"
    MICRO = "micro"
    TECHNICS = "technics"
    MIXED = "mixed"


class Signal(str, Enum):
    POSITIVE = "POSITIVE"
    NEUTRAL = "NEUTRAL"
    NEGATIVE = "NEGATIVE"


# 8. Artifacts
class ArtifactType(str, Enum):
    PDF = "pdf"
    JSON = "json"
    CSV = "csv"
    NOTEBOOK = "notebook"


# 9. Fundamental indicators
class ValueType(str, Enum):
    LEVEL = "LEVEL"
    CHANGE = "CHANGE"
    YOY = "YOY"
    MOM = "MOM"
    ZSCORE = "ZSCORE"


class TypicalFrequency(str, Enum):
    DAILY = "DAILY"
    WEEKLY = "WEEKLY"
    MONTHLY = "MONTHLY"
    QUARTERLY = "QUARTERLY"


class LeadingStatus(str, Enum):
    LAGGING = "LAGGING"
    NEUTRAL = "NEUTRAL"
    LEADING = "LEADING"


# 10. Asset profiles
class LiquidityProfile(str, Enum):
    VERY_HIGH = "VERY_HIGH"
    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"


class VolatilityProfile(str, Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"


# 11. Market geography
class Market(str, Enum):
    USA = "USA"


class Countries(str, Enum):
    USA = "USA"


# 12. Macro regime
class Level(str, Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"


class GrowthTrend(str, Enum):
    EXPANSION = "EXPANSION"
    SLOWDOWN = "SLOWDOWN"
    RECESSION = "RECESSION"
    RECOVERY = "RECOVERY"


class InflationTrend(str, Enum):
    RISING = "RISING"
    FALLING = "FALLING"
    STABLE = "STABLE"


class MonetaryPolicy(str, Enum):
    TIGHTENING = "TIGHTENING"
    EASING = "EASING"
    NEUTRAL = "NEUTRAL"


class RiskAppetite(str, Enum):
    RISK_ON = "RISK_ON"
    RISK_OFF = "RISK_OFF"
    NEUTRAL = "NEUTRAL"


# 13. Performance periods
class Period(str, Enum):
    DAILY = "DAILY"
    WEEKLY = "WEEKLY"
    MONTHLY = "MONTHLY"
    YTD = "YTD"
    ALL_TIME = "ALL_TIME"


# 13. Tiingo Time Unit Enum
class TimeUnitEnum(str, Enum):
    M1 = "1min"
    M5 = "5min"
    M15 = "15min"
    M30 = "30min"
    H1 = "1hour"
    H4 = "4hour"
    D1 = "24hour"
    W1 = "168hour"
    MN = "730hour"
