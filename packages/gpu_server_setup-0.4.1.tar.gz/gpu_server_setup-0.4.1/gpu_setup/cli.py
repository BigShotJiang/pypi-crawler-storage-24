import typer
from typing import Optional

from .core import GPUServer, get_plan
from .rich_console import header, plan_table, success, error

app = typer.Typer(
    name="gpu-setup",
    help="Один клик — удалённый GPU-сервер с Ollama + VS Code Remote",
    rich_markup_mode="rich",
    add_completion=True,
)


@app.command()
def plan(
    ip: str = typer.Option(..., "--ip", help="IP-адрес сервера"),
    user: str = typer.Option(..., "--user", help="Имя пользователя"),
    model: Optional[str] = typer.Option(None, "--model", help="Модель Ollama"),
    install_ollama: bool = typer.Option(True, "--install-ollama/--no-install"),
    no_vscode: bool = typer.Option(False, "--no-vscode"),
):
    """Показать план выполнения (dry-run)"""
    server = GPUServer(ip=ip, user=user, dry_run=True)
    plan_list = get_plan(server, install_ollama, model, no_vscode)
    header(f"План для сервера {ip}")
    plan_table(plan_list)


@app.command()
def setup(
    ip: str = typer.Option(..., "--ip", help="IP-адрес сервера"),
    user: str = typer.Option(..., "--user", help="Имя пользователя"),
    password: str = typer.Option(
        None,
        "--password",
        prompt=True,
        hide_input=True,
        help="Пароль (только для первого подключения и sudo)",
    ),
    model: Optional[str] = typer.Option(None, "--model", help="Модель Ollama (например llama3.2)"),
    install_ollama: bool = typer.Option(True, "--install-ollama/--no-install"),
    no_vscode: bool = typer.Option(False, "--no-vscode"),
    dry_run: bool = typer.Option(False, "--dry-run"),
    key_type: str = typer.Option("ed25519", "--key-type"),
):
    if dry_run:
        plan(ip=ip, user=user, model=model, install_ollama=install_ollama, no_vscode=no_vscode)
        return

    server = GPUServer(
        ip=ip, user=user, password=password, key_type=key_type, dry_run=False
    )

    server.generate_key()
    server.copy_pubkey()
    server.setup_ssh_config()
    server.test_connection()

    if install_ollama:
        server.install_ollama()

    if model:
        server.pull_model(model)

    if not no_vscode:
        server.open_vscode()

    success("Готово! 🎉")
    if model:
        typer.echo(f"\nЗапуск модели: [bold]ollama run {model}[/bold]")



@app.command()
def ssh(
    ip: str = typer.Option(..., "--ip", help="IP-адрес сервера"),
    user: str = typer.Option(..., "--user", help="Имя пользователя"),
    password: str = typer.Option(
        None,
        "--password",
        prompt=True,
        hide_input=True,
        help="Пароль для первого копирования ключа",
    ),
    dry_run: bool = typer.Option(False, "--dry-run"),
    key_type: str = typer.Option("ed25519", "--key-type"),
):
    server = GPUServer(ip=ip, user=user, password=password, key_type=key_type, dry_run=dry_run)
    server.generate_key()
    server.copy_pubkey()
    server.setup_ssh_config()
    server.test_connection()
    success("SSH полностью настроен!")


@app.command("ollama-install")
def ollama_install(
    ip: str = typer.Option(..., "--ip"),
    user: str = typer.Option(..., "--user"),
    password: str = typer.Option(
        None,
        "--password",
        prompt=True,
        hide_input=True,
        help="Пароль для sudo",
    ),
    dry_run: bool = typer.Option(False, "--dry-run"),
):
    server = GPUServer(ip=ip, user=user, password=password, dry_run=dry_run)
    server.install_ollama()


@app.command("model-pull")
def model_pull(
    model: str = typer.Argument(..., help="Название модели (llama3.2, gemma2 и т.д.)"),
    ip: str = typer.Option(..., "--ip"),
    user: str = typer.Option(..., "--user"),
    password: Optional[str] = typer.Option(None, "--password", hide_input=True),
    dry_run: bool = typer.Option(False, "--dry-run"),
):
    server = GPUServer(ip=ip, user=user, password=password, dry_run=dry_run)
    server.pull_model(model)


@app.command()
def vscode(
    ip: str = typer.Option(..., "--ip"),
    user: str = typer.Option(..., "--user"),
    password: Optional[str] = typer.Option(None, "--password", hide_input=True),
    dry_run: bool = typer.Option(False, "--dry-run"),
):
    server = GPUServer(ip=ip, user=user, password=password, dry_run=dry_run)
    server.open_vscode()


if __name__ == "__main__":
    app()