# Copa — shell integration for zsh
# Add to your .zshrc:  eval "$(copa init zsh)"
#
# What this does:
#   1. Records every command you run (precmd hook, background, zero latency)
#   2. Replaces Ctrl+R with an fzf command palette that searches across
#      command text AND descriptions — not just raw history
#   3. Ctrl+R cycles modes inside fzf: all → frequent → recent → all
#   4. Composition keys append shell operators (|, &&, &, etc.) to selected commands

# --- Load keybinding config (runs once at shell startup) ---
eval "$(copa _fzf-config 2>/dev/null)" || {
  # Fallback defaults if copa _fzf-config fails
  _COPA_EXPECT='ctrl-v,ctrl-o,ctrl-x,ctrl-t,ctrl-a,ctrl-/'
  _COPA_DESCRIBE_KEY='ctrl-d'
  _COPA_GROUP_KEY='ctrl-g'
  _COPA_FLAGS_KEY='ctrl-f'
  _COPA_FILTER_GROUP_KEY='ctrl-s'
  _COPA_CYCLE_GROUP_KEY='ctrl-n'
  _COPA_TOGGLE_HEADER_KEY='ctrl-h'
  _COPA_COMPLETION_BRANDING='true'
  _COPA_HEADER=$'Copa | ^R:cycle | ^V:& | ^O:2>&1 | ^X:| | ^T:> | ^A:&& | ^/:quiet | ^H:keys\n^G:grp | ^D:desc | ^F:flag | ^S:scope | ^N:↻grp'
  typeset -gA _COPA_SUFFIXES
  _COPA_SUFFIXES[ctrl-v]=' &'
  _COPA_SUFFIXES[ctrl-o]=' 2>&1'
  _COPA_SUFFIXES[ctrl-x]=' | '
  _COPA_SUFFIXES[ctrl-t]=' > '
  _COPA_SUFFIXES[ctrl-a]=' && '
  _COPA_SUFFIXES[ctrl-/]=' 2>/dev/null'
}

# --- precmd hook: record last command ---
_copa_precmd() {
  local last_cmd
  last_cmd="$(fc -ln -1 2>/dev/null)"
  last_cmd="${last_cmd## }"  # strip leading space
  if [[ -n "$last_cmd" && "$last_cmd" != _copa_* ]]; then
    copa _record "$last_cmd" &!
  fi
}

# Add to precmd hooks (avoid duplicates)
autoload -Uz add-zsh-hook
add-zsh-hook precmd _copa_precmd

# --- Ctrl+R: fzf-powered command palette ---
# Replaces default zsh reverse-search. fzf searches all visible fields:
# command text, description, group badges, shared-set names, and frequency.
# Selected command is placed into the prompt without executing.
# Composition keys (configured via copa _fzf-config) append shell operators.
# Requires fzf: brew install fzf
_copa_fzf_widget() {
  if ! command -v fzf &>/dev/null; then
    zle -M "Copa: fzf not found. Install with: brew install fzf"
    return 1
  fi

  local mode="all"
  local output
  local copa_bin="${commands[copa]:-copa}"
  local _copa_modal_file=$(mktemp -t copa_modal.XXXXXX)

  output=$("$copa_bin" fzf-list --mode "$mode" | \
    fzf --ansi \
        --delimiter '┃' \
        --with-nth '2..3' \
        --preview "$copa_bin _preview {1}" \
        --preview-window 'right:40%:wrap' \
        --header "$_COPA_HEADER" \
        --prompt 'copa> ' \
        --height '80%' \
        --layout reverse \
        --expect "$_COPA_EXPECT" \
        --bind "${_COPA_DESCRIBE_KEY}:execute($copa_bin describe {1})+refresh-preview" \
        --bind "${_COPA_FLAGS_KEY}:execute($copa_bin _set-flags {1})+reload($copa_bin fzf-list)+refresh-preview" \
        --bind "${_COPA_FILTER_GROUP_KEY}:reload($copa_bin _list-groups)+change-prompt(scope> )+clear-query+hide-preview" \
        --bind "${_COPA_GROUP_KEY}:transform:
          echo {1} > ${_copa_modal_file};
          echo \"reload(${copa_bin} _list-groups-for-assign)+change-prompt(group> )+clear-query+hide-preview\"" \
        --bind "${_COPA_CYCLE_GROUP_KEY}:transform:
          cur_group='(all)';
          if [[ \$FZF_PROMPT =~ 'copa \\[(.+)\\]> ' ]]; then
            cur_group=\"\${match[1]}\";
          fi;
          next=\$(${copa_bin} _next-group \"\$cur_group\");
          if [[ \$next == '(all)' ]]; then
            echo \"reload(${copa_bin} fzf-list --mode all)+change-prompt(copa> )\";
          else
            echo \"reload(${copa_bin} fzf-list --mode group --group \$next)+change-prompt(copa [\$next]> )\";
          fi" \
        --bind 'ctrl-r:transform:
          if [[ $FZF_PROMPT == "copa> " ]]; then
            echo "reload('"$copa_bin"' fzf-list --mode frequent)+change-prompt(frequent> )"
          elif [[ $FZF_PROMPT == "frequent> " ]]; then
            echo "reload('"$copa_bin"' fzf-list --mode recent)+change-prompt(recent> )"
          else
            echo "reload('"$copa_bin"' fzf-list --mode all)+change-prompt(copa> )"
          fi' \
        --bind "${_COPA_TOGGLE_HEADER_KEY}:toggle-header" \
        --bind 'enter:transform:
          if [[ $FZF_PROMPT == "scope> " ]]; then
            selected={2};
            if [[ $selected == "(all)" ]]; then
              echo "reload('"$copa_bin"' fzf-list --mode all)+change-prompt(copa> )+clear-query+show-preview"
            else
              echo "reload('"$copa_bin"' fzf-list --mode group --group $selected)+change-prompt(copa [$selected]> )+clear-query+show-preview"
            fi
          elif [[ $FZF_PROMPT == "group> " ]]; then
            cmd_id=$(cat '"${_copa_modal_file}"');
            selected={2};
            '"$copa_bin"' _set-group-direct $cmd_id $selected;
            echo "reload('"$copa_bin"' fzf-list)+change-prompt(copa> )+clear-query+show-preview"
          else
            echo "accept"
          fi' \
        --bind 'esc:transform:
          if [[ $FZF_PROMPT == "scope> " || $FZF_PROMPT == "group> " ]]; then
            echo "reload('"$copa_bin"' fzf-list)+change-prompt(copa> )+clear-query+show-preview"
          else
            echo "abort"
          fi' \
  )

  [[ -f "$_copa_modal_file" ]] && rm -f "$_copa_modal_file"

  if [[ -n "$output" ]]; then
    # --expect output: line 1 = key pressed (empty for Enter), line 2+ = selected item
    local key selected cmd suffix
    key=$(echo "$output" | head -1)
    selected=$(echo "$output" | tail -n +2)

    # Skip lines without ┃ (modal group names don't have the delimiter)
    if [[ -n "$selected" && "$selected" == *┃* ]]; then
      cmd=$(echo "$selected" | cut -d'┃' -f2 | sed 's/^ *//;s/ *$//')
      suffix="${_COPA_SUFFIXES[$key]}"
      LBUFFER="${cmd}${suffix}"
    fi
  fi

  zle reset-prompt
}

zle -N _copa_fzf_widget
bindkey '^R' _copa_fzf_widget

# --- Tab completion ---
# Ensure zsh completion system is available, then register Copa completions.
if ! (( $+functions[compdef] )); then
  autoload -Uz compinit && compinit -i -C
fi
eval "$(copa completion zsh)"

# --- Supplemental tab completion from Copa database ---
# Registers as a fallback completer so that any command (e.g. adb <TAB>)
# gets completion candidates from Copa's command history.
_copa_history_complete() {
    # Only provide Copa completions when primary completers found nothing
    (( compstate[nmatches] > 0 )) && return
    # Skip empty tokens (bare <TAB> with no partial input)
    [[ -z "${words[CURRENT]}" ]] && return
    # Skip internal copa commands
    [[ "${words[CURRENT]}" == _copa_* ]] && return
    local -a results
    results=("${(@f)$(copa _complete-word "${(@)words[1,CURRENT]}" 2>/dev/null)}")
    (( ${#results} )) && compadd -V 'copa-history' -o nosort -- "${results[@]}"
}

# Append to existing completers without clobbering user config
() {
    local -a cur
    zstyle -g cur ':completion:*' completer 2>/dev/null
    if (( ! ${cur[(Ie)_copa_history_complete]} )); then
        zstyle ':completion:*' completer ${cur:-_complete} _copa_history_complete
    fi
    # Copa completion branding: show "Copa history" header when branding is enabled
    if [[ "$_COPA_COMPLETION_BRANDING" != 'false' ]]; then
        zstyle ':completion:*:*:*:copa-history' group-header '%F{magenta}-- Copa history --%f'
    fi
}
