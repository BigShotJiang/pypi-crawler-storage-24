import enum
from datetime import datetime
from typing import Optional
from uuid import UUID, uuid4, uuid5

import fptf_pydantic.models as fptf
import lptf_pydantic as lptf
import sqlmodel as sql
import traewelling_pydantic.enums as trwl_enums
import traewelling_pydantic.models as trwl
from pydantic_extra_types.coordinate import Latitude, Longitude

UUID_NS_TRWL_STATION = UUID("1d9f9301-7efd-4950-9bcc-6409c64d29f6")
UUID_NS_TRWL_TRANSPORT = UUID("151d0a94-19cd-42a5-bfef-2705f8b1343c")
UUID_NS_TRWL_OPERATOR = UUID("822b5971-bb51-4de4-8222-828be7b007b8")
UUID_NS_TRWL_STATUS = UUID("391b0b17-f96d-4452-a714-b3e2527423ec")
UUID_NS_TRWL_EVENT = UUID("1581be5e-1ae9-4c27-8bad-151933ceaa90")


class Location(sql.SQLModel, table=True):
    uuid: UUID = sql.Field(default_factory=uuid4, primary_key=True)
    name: Optional[str] = None
    addresses: list["LocationIdentifier"] = sql.Relationship(back_populates="location")

    lon: Optional[Longitude] = None
    lat: Optional[Latitude] = None
    alt: Optional[int] = None


class LocationIdentifierEnum(enum.IntEnum):
    UNKNOWN = 0
    ID = 1
    ADDRESS = 2


class LocationIdentifier(sql.SQLModel, table=True):
    location_id: UUID = sql.Field(foreign_key="location.uuid", primary_key=True)
    location: "Location" = sql.Relationship(back_populates="addresses")
    type: LocationIdentifierEnum = sql.Field(primary_key=True)
    address: str = sql.Field(primary_key=True)


class Stay(sql.SQLModel, table=True):
    uuid: UUID = sql.Field(default_factory=uuid4, primary_key=True)
    name: Optional[str] = None
    address: Optional[str] = None

    location_id: Optional[UUID] = sql.Field(default=None, foreign_key="location.uuid")
    category: lptf.StayCategory


class Station(sql.SQLModel, table=True):
    uuid: UUID = sql.Field(default_factory=uuid4, primary_key=True)
    traewelling_id: Optional[int] = None
    identifiers: list["StationIdentifier"] = sql.Relationship(back_populates="station")

    name: str

    location_id: Optional[UUID] = sql.Field(default=None, foreign_key="location.uuid")

    @classmethod
    def from_traewelling(cls, obj: trwl.Station):
        return cls(
            uuid=uuid5(namespace=UUID_NS_TRWL_STATION, name=str(obj.id)),
            name=obj.name,
            traewelling_id=obj.id,
            identifiers=[
                StationIdentifier.from_traewelling(
                    i,
                    uuid5(namespace=UUID_NS_TRWL_STATION, name=str(obj.id)),
                    traewelling_id=obj.id,
                )
                for i in obj.identifiers
            ],
        )


class StationIdentifier(sql.SQLModel, table=True):
    station_id: UUID = sql.Field(foreign_key="station.uuid", primary_key=True)
    station: "Station" = sql.Relationship(back_populates="identifiers")
    station_traewelling_id: Optional[int] = sql.Field(default=None)
    id_type: str = sql.Field(primary_key=True)
    identifier: str = sql.Field(primary_key=True)

    @classmethod
    def from_traewelling(
        cls, obj: trwl.StationIdentifier, uuid: UUID, traewelling_id: Optional[int]
    ):
        return cls(
            station_id=uuid,
            station_traewelling_id=traewelling_id,
            id_type=obj.type,
            identifier=obj.identifier,
        )


class Operator(sql.SQLModel, table=True):
    uuid: UUID = sql.Field(default_factory=uuid4, primary_key=True)
    traewelling_id: Optional[int] = None
    identifier_str: Optional[str] = None
    name: str

    @classmethod
    def from_traewelling(cls, obj: trwl.Operator):
        return cls(
            uuid=uuid5(namespace=UUID_NS_TRWL_OPERATOR, name=str(obj.id)),
            traewelling_id=obj.id,
            name=obj.name,
        )


class TransportProduct(sql.SQLModel, table=True):
    uuid: UUID = sql.Field(default_factory=uuid4, primary_key=True)
    name: str
    mode: Optional[lptf.Mode] = sql.Field(default=None)
    scope: Optional[lptf.ProductScope] = sql.Field(default=None)
    stopping_pattern: Optional[lptf.StoppingPattern] = sql.Field(default=None)


class Transport(sql.SQLModel, table=True):
    uuid: UUID = sql.Field(default_factory=uuid4, primary_key=True)
    traewelling_id: Optional[int] = None
    identifiers: list["TransportIdentifier"] = sql.Relationship(
        back_populates="transport"
    )

    origin_id: UUID = sql.Field(foreign_key="station.uuid")
    destination_id: UUID = sql.Field(foreign_key="station.uuid")

    name: str
    mode: str

    operator_id: Optional[UUID] = sql.Field(default=None, foreign_key="operator.uuid")
    product_id: Optional[UUID] = sql.Field(
        default=None, foreign_key="transportproduct.uuid"
    )

    stops: list["Stop"] = sql.Relationship(back_populates="route")

    @classmethod
    def from_traewelling(cls, obj: trwl.Transport):
        return cls(
            uuid=uuid5(namespace=UUID_NS_TRWL_TRANSPORT, name=str(obj.trip)),
            traewelling_id=obj.trip,
            identifiers=[
                TransportIdentifier(
                    transport_id=uuid5(
                        namespace=UUID_NS_TRWL_TRANSPORT, name=str(obj.trip)
                    ),
                    transport_traewelling_id=obj.trip,
                    id_type="hafas",
                    identifier=obj.hafasId,
                )
            ],
            origin_id=uuid5(namespace=UUID_NS_TRWL_STATION, name=str(obj.origin.id)),
            destination_id=uuid5(
                namespace=UUID_NS_TRWL_STATION, name=str(obj.destination.id)
            ),
            name=obj.lineName,
            mode=obj.category,
            operator_id=uuid5(
                namespace=UUID_NS_TRWL_OPERATOR, name=str(obj.operator.id)
            )
            if obj.operator is not None
            else None,
        )


class TransportIdentifier(sql.SQLModel, table=True):
    transport_id: UUID = sql.Field(foreign_key="transport.uuid", primary_key=True)
    transport: "Transport" = sql.Relationship(back_populates="identifiers")
    transport_traewelling_id: Optional[int] = sql.Field(default=None)
    id_type: str
    identifier: str


class Stop(sql.SQLModel, table=True):
    station_id: UUID = sql.Field(foreign_key="station.uuid", primary_key=True)

    route_id: UUID = sql.Field(foreign_key="transport.uuid", primary_key=True)
    route: "Transport" = sql.Relationship(back_populates="stops")

    stop_sequence: int = sql.Field(primary_key=True)

    arrival_time_planned: Optional[datetime] = None
    arrival_time_real: Optional[datetime] = None

    departure_time_planned: Optional[datetime] = None
    departure_time_real: Optional[datetime] = None

    platform: Optional[str] = None

    cancelled: bool = False


class Tag(sql.SQLModel, table=True):
    status_id: UUID = sql.Field(foreign_key="status.uuid", primary_key=True)
    status: "Status" = sql.Relationship(back_populates="tags")
    key: str = sql.Field(primary_key=True)
    value: str

    @classmethod
    def from_traewelling(cls, obj: trwl.Tag, status_id: UUID):
        return cls(status_id=status_id, key=obj.key, value=obj.value)


class Event(sql.SQLModel, table=True):
    uuid: UUID = sql.Field(default_factory=uuid4, primary_key=True)
    traewelling_id: Optional[int] = None

    name: str
    hashtag: Optional[str] = None
    host: Optional[str] = None
    url: Optional[str] = None
    begin: datetime
    end: datetime
    station_id: Optional[UUID] = sql.Field(default=None, foreign_key="station.uuid")
    location_id: Optional[UUID] = sql.Field(default=None, foreign_key="location.uuid")
    is_pride: bool = False

    @classmethod
    def from_traewelling(
        cls,
        obj: trwl.Event,
        station_id: Optional[UUID] = None,
        location_id: Optional[UUID] = None,
    ):
        return cls(
            uuid=uuid5(namespace=UUID_NS_TRWL_EVENT, name=str(obj.id)),
            traewelling_id=obj.id,
            name=obj.name,
            hashtag=obj.hashtag,
            host=obj.host,
            url=obj.url,
            begin=obj.begin,
            end=obj.end,
            station_id=station_id,
            location_id=location_id,
            is_pride=obj.isPride,
        )


class Individual(sql.SQLModel, table=True):
    uuid: UUID = sql.Field(default_factory=uuid4, primary_key=True)
    traewelling_id: Optional[int] = None

    name: str
    bio: str

    @classmethod
    def from_traewelling(cls, obj: trwl.User):
        return cls(uuid=obj.uuid, traewelling_id=obj.id, name=obj.username, bio=obj.bio)


class StatusPurposeEnum(enum.IntEnum):
    PRIVATE = 0
    BUSINESS = 1
    COMMUTE = 2
    WORK = 3

    @classmethod
    def from_traewelling(cls, obj: trwl_enums.Business):
        if obj == trwl_enums.Business.private:
            return cls.PRIVATE
        elif obj == trwl_enums.Business.business:
            return cls.BUSINESS
        elif obj == trwl_enums.Business.commute:
            return cls.COMMUTE


class Status(sql.SQLModel, table=True):
    uuid: UUID = sql.Field(default_factory=uuid4, primary_key=True)
    traewelling_id: Optional[int] = None

    body: str
    purpose: StatusPurposeEnum
    is_public: Optional[bool] = None
    traveler_id: UUID = sql.Field(foreign_key="individual.uuid")

    transport_id: UUID = sql.Field(foreign_key="transport.uuid")
    event_id: Optional[UUID] = sql.Field(default=None, foreign_key="event.uuid")
    tags: list["Tag"] = sql.Relationship(back_populates="status")

    created_at: datetime

    @classmethod
    def from_traewelling(cls, obj: trwl.Status):
        return cls(
            uuid=uuid5(namespace=UUID_NS_TRWL_STATUS, name=str(obj.id)),
            traewelling_id=obj.id,
            body=obj.body,
            purpose=StatusPurposeEnum.from_traewelling(obj.business),
            is_public=(obj.visibility < 2),
            traveler_id=obj.user.uuid,
            event_id=uuid5(namespace=UUID_NS_TRWL_EVENT, name=str(obj.event.id))
            if obj.event is not None
            else None,
            tags=[
                Tag.from_traewelling(
                    i, uuid5(namespace=UUID_NS_TRWL_STATUS, name=str(obj.id))
                )
                for i in obj.tags
            ],
            created_at=obj.createdAt,
            transport_id=uuid5(
                namespace=UUID_NS_TRWL_TRANSPORT, name=str(obj.checkin.trip)
            ),
        )
