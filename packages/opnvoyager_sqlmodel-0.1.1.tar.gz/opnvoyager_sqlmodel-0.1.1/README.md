# ÖPNVoyager-SQLModel

A package that contains the SQLModels for the ÖPNVoyager tool.
