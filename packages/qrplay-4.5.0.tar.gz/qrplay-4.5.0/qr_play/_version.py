"""
Provides qr_play version information.
"""

# This file is auto-generated! Do not edit!
# Use `python -m incremental.update qr_play` to change this file.

from incremental import Version

__version__ = Version("qr_play", 4, 5, 0)
__all__ = ["__version__"]
