# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.2.1] - 2026-03-27
### Added
- feat(bootstrap): merge MCP config into existing opencode.json
## [0.2.0] - 2026-03-27
### Added
- feat(bootstrap): add machine bootstrap command
### Chores
- chore: add pre-commit hooks and fix formatting
## [0.1.0] - 2026-03-27
### Added
- feat(ci): combine tag and publish into single release workflow with GitHub Release
### Fixed
- fix(ci): uv publish does not support --no-build flag (remove it)
### Documentation
- docs: update publishing workflow to use release.yml
### Chores
- chore(release): bump version to 0.0.3-rc.2
- chore(release): bump version to 0.0.3-rc.1
## [0.0.3-rc.2] - 2026-03-27
### Fixed
- fix(ci): uv publish does not support --no-build flag (remove it)
## [0.0.3-rc.1] - 2026-03-27
### Added
- feat(ci): combine tag and publish into single release workflow with GitHub Release
### Documentation
- docs: update publishing workflow to use release.yml
## [0.0.2] - 2026-03-27
## [0.0.1] - 2026-03-27
### Added
- feat(ci): support numbered RC tags and fix commit ranges
- feat(ci): automate changelog generation and remove test gate from publish
- feat(piagentsync): initial implementation with full test suite
### Fixed
- fix(ci): prevent duplicate tags by checking existing tags
### Tests
- test(cli): make version check dynamic using package __version__
### Chores
- chore(release): bump version to 0.0.1-rc
- chore(release): bump version to 0.0.1-rc
- chore(release): bump version to 0.0.1-rc
### CI/CD
- ci: add GitHub Actions workflows for CI, tagging, and publishing
### Other
- Initial commit
## [0.0.1-rc] - 2026-03-27
### Added
- feat(ci): automate changelog generation and remove test gate from publish
- feat(piagentsync): initial implementation with full test suite
### Fixed
- fix(ci): prevent duplicate tags by checking existing tags
### Tests
- test(cli): make version check dynamic using package __version__
### Chores
- chore(release): bump version to 0.0.1-rc
- chore(release): bump version to 0.0.1-rc
### CI/CD
- ci: add GitHub Actions workflows for CI, tagging, and publishing
### Other
- Initial commit
## [0.0.1-rc] - 2026-03-27
### Added
- feat(ci): automate changelog generation and remove test gate from publish
- feat(piagentsync): initial implementation with full test suite
### Tests
- test(cli): make version check dynamic using package __version__
### Chores
- chore(release): bump version to 0.0.1-rc
### CI/CD
- ci: add GitHub Actions workflows for CI, tagging, and publishing
### Other
- Initial commit
## [0.1.0] - 2026-03-27

### Added
- Initial release of piagentsync
- Sync OpenCode agents and skills from Obsidian vault to workspace
- CLI commands: `pull`, `status`, `init`
- Support for global agents
- Dry-run mode
- Full TDD implementation with pytest
