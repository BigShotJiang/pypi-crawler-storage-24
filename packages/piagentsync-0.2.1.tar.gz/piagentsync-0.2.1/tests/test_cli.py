"""Tests for CLI commands."""

from pathlib import Path

import pytest
from typer.testing import CliRunner

from piagentsync import __version__
from piagentsync.cli import app

runner = CliRunner()


def test_version_flag() -> None:
    """--version prints version and exits."""
    result = runner.invoke(app, ["--version"])
    assert result.exit_code == 0
    assert f"piagentsync {__version__}" in result.stdout


def test_pull_project_success(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Exits 0, prints table with written/skipped, writes files."""
    vault = tmp_path / "vault"
    vault.mkdir()
    project = "testproj"
    proj_dir = vault / "projects" / project
    proj_dir.mkdir(parents=True)
    agents_dir = proj_dir / "agents"
    agents_dir.mkdir()
    skills_dir = proj_dir / "skills"
    skills_dir.mkdir()

    agent_content = "# Agent\nDoes things."
    (agents_dir / "agent.md").write_text(agent_content)
    skill_content = "# Skill\nSkilled."
    (skills_dir / "skill.md").write_text(skill_content)

    workspace = tmp_path / "workspace" / project
    workspace.mkdir(parents=True)
    (proj_dir / "AGENTS.md").write_text(
        f"""---
project: {project}
workspace: {workspace}
---
"""
    )

    result = runner.invoke(
        app, ["pull", project], env={"PIAGENTSYNC_VAULT_PATH": str(vault)}
    )
    assert result.exit_code == 0
    assert (workspace / ".opencode" / "agents" / "agent.md").exists()
    assert (workspace / ".opencode" / "skills" / "skill.md").exists()
    assert "agent" in result.stdout.lower() and "written" in result.stdout.lower()


def test_pull_project_not_found(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Exits 1, prints error message."""
    vault = tmp_path / "vault"
    vault.mkdir()
    result = runner.invoke(
        app, ["pull", "nonexistent"], env={"PIAGENTSYNC_VAULT_PATH": str(vault)}
    )
    assert result.exit_code == 1
    assert "not found" in result.stdout.lower()


def test_pull_dry_run(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Exits 0, no files written, output says dry-run."""
    vault = tmp_path / "vault"
    vault.mkdir()
    project = "dryproj"
    proj_dir = vault / "projects" / project
    proj_dir.mkdir(parents=True)
    agents_dir = proj_dir / "agents"
    agents_dir.mkdir()
    (agents_dir / "agent.md").write_text("# agent")
    workspace = tmp_path / "workspace" / project
    (proj_dir / "AGENTS.md").write_text(
        f"""---
project: {project}
workspace: {workspace}
---
"""
    )
    result = runner.invoke(
        app, ["pull", project, "--dry-run"], env={"PIAGENTSYNC_VAULT_PATH": str(vault)}
    )
    assert result.exit_code == 0
    assert not (workspace / ".opencode" / "agents" / "agent.md").exists()
    assert "dry run" in result.stdout.lower() or "dry-run" in result.stdout.lower()


def test_pull_all_discovers_projects(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """Syncs multiple projects."""
    vault = tmp_path / "vault"
    vault.mkdir()
    for proj in ["proj-a", "proj-b"]:
        proj_dir = vault / "projects" / proj
        proj_dir.mkdir(parents=True)
        (proj_dir / "agents").mkdir()
        (proj_dir / "skills").mkdir()
        (proj_dir / "agents" / "agent.md").write_text("# agent")
        workspace = tmp_path / "workspace" / proj
        (proj_dir / "AGENTS.md").write_text(
            f"---\nproject: {proj}\nworkspace: {workspace}\n---\n"
        )
    result = runner.invoke(
        app, ["pull", "--all"], env={"PIAGENTSYNC_VAULT_PATH": str(vault)}
    )
    assert result.exit_code == 0
    for proj in ["proj-a", "proj-b"]:
        ws = tmp_path / "workspace" / proj
        assert (ws / ".opencode" / "agents" / "agent.md").exists()


def test_pull_global(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Syncs global agents."""
    vault = tmp_path / "vault"
    vault.mkdir()
    global_dir = vault / "agents" / "global"
    global_dir.mkdir(parents=True)
    (global_dir / "chief.md").write_text("# Global agent")
    project_dir = vault / "projects" / "myproj"
    project_dir.mkdir(parents=True)
    workspace = tmp_path / "workspace" / "myproj"
    (project_dir / "AGENTS.md").write_text(
        f"---\nproject: myproj\nworkspace: {workspace}\n---\n"
    )
    (project_dir / "agents").mkdir()
    (project_dir / "skills").mkdir()
    global_base = tmp_path / "global" / "opencode"
    result = runner.invoke(
        app,
        ["pull", "myproj", "--global"],
        env={
            "PIAGENTSYNC_VAULT_PATH": str(vault),
            "PIAGENTSYNC_GLOBAL_OPENCODE_PATH": str(global_base),
        },
    )
    assert result.exit_code == 0
    assert (global_base / "agents" / "chief.md").exists()


def test_status_in_sync(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Shows table, exits 0, state 'in sync'."""
    vault = tmp_path / "vault"
    vault.mkdir()
    project = "syncproj"
    proj_dir = vault / "projects" / project
    proj_dir.mkdir(parents=True)
    (proj_dir / "agents").mkdir()
    (proj_dir / "skills").mkdir()
    agent_content = "# agent"
    (proj_dir / "agents" / "agent.md").write_text(agent_content)
    workspace = tmp_path / "workspace" / project
    workspace.mkdir(parents=True)
    # Create destination beforehand to simulate in-sync
    dst_agent = workspace / ".opencode" / "agents"
    dst_agent.mkdir(parents=True)
    (dst_agent / "agent.md").write_text(agent_content)
    (proj_dir / "AGENTS.md").write_text(
        f"---\nproject: {project}\nworkspace: {workspace}\n---\n"
    )
    result = runner.invoke(
        app, ["status", project], env={"PIAGENTSYNC_VAULT_PATH": str(vault)}
    )
    assert result.exit_code == 0
    assert "in sync" in result.stdout.lower()
    assert "agent" in result.stdout.lower()


def test_status_needs_pull(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Shows 'needs pull' when dest missing."""
    vault = tmp_path / "vault"
    vault.mkdir()
    project = "needproj"
    proj_dir = vault / "projects" / project
    proj_dir.mkdir(parents=True)
    (proj_dir / "agents").mkdir()
    (proj_dir / "agents" / "agent.md").write_text("# agent")
    workspace = tmp_path / "workspace" / project
    workspace.mkdir(parents=True)
    (proj_dir / "AGENTS.md").write_text(
        f"---\nproject: {project}\nworkspace: {workspace}\n---\n"
    )
    result = runner.invoke(
        app, ["status", project], env={"PIAGENTSYNC_VAULT_PATH": str(vault)}
    )
    assert result.exit_code == 0
    assert "needs pull" in result.stdout.lower() or "missing" in result.stdout.lower()


def test_status_no_project_shows_all(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    """No arg = all projects."""
    vault = tmp_path / "vault"
    vault.mkdir()
    for proj in ["proj-a", "proj-b"]:
        proj_dir = vault / "projects" / proj
        proj_dir.mkdir(parents=True)
        (proj_dir / "agents").mkdir()
        (proj_dir / "agents" / "a.md").write_text("# a")
        workspace = tmp_path / "workspace" / proj
        workspace.mkdir(parents=True)
        (proj_dir / "AGENTS.md").write_text(
            f"---\nproject: {proj}\nworkspace: {workspace}\n---\n"
        )
        # For proj-a, we'll not create dest so it shows needs pull; for proj-b we create dest in sync.
        if proj == "proj-b":
            dst = workspace / ".opencode" / "agents"
            dst.mkdir(parents=True)
            (dst / "a.md").write_text("# a")
    result = runner.invoke(app, ["status"], env={"PIAGENTSYNC_VAULT_PATH": str(vault)})
    assert result.exit_code == 0
    # Should contain info about both projects
    assert "proj-a" in result.stdout and "proj-b" in result.stdout


def test_init_creates_scaffold(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Directories and files created."""
    vault = tmp_path / "vault"
    vault.mkdir()
    workspace = tmp_path / "workspace" / "newproj"
    result = runner.invoke(
        app,
        ["init", "newproj", "--workspace", str(workspace)],
        env={"PIAGENTSYNC_VAULT_PATH": str(vault)},
    )
    assert result.exit_code == 0
    proj_dir = vault / "projects" / "newproj"
    assert proj_dir.exists()
    assert (proj_dir / "agents").exists()
    assert (proj_dir / "skills").exists()
    assert (proj_dir / "context.md").exists()
    assert (proj_dir / "decisions.md").exists()
    assert (proj_dir / "AGENTS.md").exists()
    # Verify AGENTS.md contains frontmatter with correct workspace
    content = (proj_dir / "AGENTS.md").read_text()
    assert "project: newproj" in content
    assert f"workspace: {workspace}" in content
    # Next step message
    assert "piagentsync pull newproj" in result.stdout


def test_init_invalid_slug(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Exits 1 for slug with spaces."""
    vault = tmp_path / "vault"
    vault.mkdir()
    workspace = tmp_path / "workspace" / "badproj"
    result = runner.invoke(
        app,
        ["init", "Invalid Slug", "--workspace", str(workspace)],
        env={"PIAGENTSYNC_VAULT_PATH": str(vault)},
    )
    assert result.exit_code == 1
    assert "invalid" in result.stdout.lower() or "slug" in result.stdout.lower()


def test_init_already_exists(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Exits 1 if project dir exists."""
    vault = tmp_path / "vault"
    vault.mkdir()
    proj_dir = vault / "projects" / "exists"
    proj_dir.mkdir(parents=True)
    workspace = tmp_path / "workspace" / "exists"
    result = runner.invoke(
        app,
        ["init", "exists", "--workspace", str(workspace)],
        env={"PIAGENTSYNC_VAULT_PATH": str(vault)},
    )
    assert result.exit_code == 1
    assert "already exists" in result.stdout.lower()
