"""Tests for configuration."""

from pathlib import Path

import pytest
from piagentsync.config import Settings


def test_default_vault_path(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Defaults to ~/vault expanded."""
    # Set HOME to a temporary directory
    monkeypatch.setenv("HOME", str(tmp_path))
    # Ensure no env overrides
    monkeypatch.delenv("PIAGENTSYNC_VAULT_PATH", raising=False)
    # Also ensure no .env file interferes
    monkeypatch.chdir(tmp_path)
    settings = Settings()
    expected = tmp_path / "vault"
    assert settings.vault_path == expected


def test_env_var_override(monkeypatch: pytest.MonkeyPatch) -> None:
    """PIAGENTSYNC_VAULT_PATH overrides default."""
    monkeypatch.setenv("PIAGENTSYNC_VAULT_PATH", "/custom/vault")
    settings = Settings()
    assert settings.vault_path == Path("/custom/vault").resolve()


def test_dot_env_file(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """.env file in cwd is read."""
    cwd = tmp_path / "sub"
    cwd.mkdir()
    env_file = cwd / ".env"
    env_file.write_text("PIAGENTSYNC_VAULT_PATH=/fromenv/vault")
    monkeypatch.chdir(cwd)
    # Clear any env vars that might interfere
    monkeypatch.delenv("PIAGENTSYNC_VAULT_PATH", raising=False)
    settings = Settings()
    assert settings.vault_path == Path("/fromenv/vault").resolve()


def test_paths_are_expanded(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """Tilde and relative paths resolved to absolute."""
    monkeypatch.chdir(tmp_path)
    # Test relative path
    rel_path = Path("rel_vault")
    global_path = Path("global_opencode")
    settings = Settings(vault_path=rel_path, global_opencode_path=global_path)
    assert settings.vault_path.is_absolute()
    assert settings.global_opencode_path.is_absolute()
    # Resolve relative to tmp_path
    assert settings.vault_path == (tmp_path / rel_path).resolve()
    assert settings.global_opencode_path == (tmp_path / global_path).resolve()
    # Test tilde expansion
    monkeypatch.setenv("HOME", str(tmp_path))
    tilde_path = Path("~/tilde_vault")
    settings2 = Settings(vault_path=tilde_path)
    assert str(settings2.vault_path).startswith(str(tmp_path))
