"""Custom exception hierarchy for piagentsync."""


class PiAgentSyncError(Exception):
    """Base exception for all piagentsync errors."""

    def __init__(self, message: str) -> None:
        super().__init__(message)
        self.message = message


class ManifestNotFoundError(PiAgentSyncError):
    """Raised when an AGENTS.md manifest file does not exist."""

    pass


class ManifestParseError(PiAgentSyncError):
    """Raised when manifest parsing fails (missing or malformed frontmatter)."""

    pass


class VaultNotFoundError(PiAgentSyncError):
    """Raised when the vault directory does not exist."""

    pass


class SyncError(PiAgentSyncError):
    """Raised for general sync failures (e.g., file system errors)."""

    pass
