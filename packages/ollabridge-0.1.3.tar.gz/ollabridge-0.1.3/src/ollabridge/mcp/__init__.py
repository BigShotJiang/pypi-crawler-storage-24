"""MCP server implementation."""
