"""OllaBridge core module."""
