"""Album management modules."""
