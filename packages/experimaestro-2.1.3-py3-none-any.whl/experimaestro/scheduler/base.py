import json
import logging
import threading
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import (
    Dict,
    List,
    Optional,
    Set,
    ClassVar,
    TYPE_CHECKING,
)
import asyncio


from experimaestro.exceptions import GracefulTimeout
from experimaestro.scheduler import experiment
from experimaestro.scheduler.jobs import (
    Job,
    JobState,
    JobError,
    JobDependency,
    JobStateError,
    JobFailureStatus,
)
from experimaestro.scheduler.services import Service
from experimaestro.scheduler.interfaces import (
    BaseJob,
    BaseExperiment,
    BaseService,
    STATE_NAME_TO_JOBSTATE,
    deserialize_to_datetime,
    serialize_timestamp,
)
from experimaestro.scheduler.state_provider import StateProvider
from experimaestro.scheduler.state_status import (
    CarbonMetricsEvent,
    EventReader,
    ExperimentJobStateEvent,
    JobProgressEvent,
    JobStateChangedEvent,
    WatchedDirectory,
    job_entity_id_extractor,
    task_id_hash,
)
from experimaestro.scheduler.state_provider import CarbonMetricsData


import concurrent.futures

if TYPE_CHECKING:
    from experimaestro.webui import WebUIServer
    from experimaestro.settings import ServerSettings
    from experimaestro.scheduler.workspace import Workspace
    from experimaestro.connectors import Process
    from experimaestro.scheduler.interfaces import ExperimentJobInformation

    # vulture: ignore
    from experimaestro.scheduler.experiment import experiment as Experiment


logger = logging.getLogger("xpm.scheduler")


@dataclass
class SchedulerExperimentRunInfo:
    """Per-(experiment, run) metadata tracked by the scheduler.

    Unifies tags, dependencies, and experiment job info into one structure.
    """

    tags: dict[str, dict[str, str]] = field(default_factory=dict)
    """job_id -> {tag_key: tag_value}"""

    dependencies: dict[str, list[str]] = field(default_factory=dict)
    """job_id -> [depends_on_job_ids]"""

    job_infos: dict[str, "ExperimentJobInformation"] = field(default_factory=dict)
    """job_id -> ExperimentJobInformation"""


class Listener:
    def on_job_submitted(self, job):
        """Called when job is submitted (new preferred method)"""
        pass

    def job_submitted(self, job):
        """Deprecated: use on_job_submitted instead"""
        # Backward compatibility: delegate to new method
        self.on_job_submitted(job)

    def on_job_state_changed(self, job):
        """Called when job state changes (new preferred method)"""
        pass

    def job_state(self, job):
        """Deprecated: use on_job_state_changed instead"""
        # Backward compatibility: delegate to new method
        self.on_job_state_changed(job)

    def on_service_added(self, service: Service):
        """Called when a new service is added (new preferred method)"""
        pass

    def service_add(self, service: Service):
        """Deprecated: use on_service_added instead"""
        # Backward compatibility: delegate to new method
        self.on_service_added(service)


class Scheduler(StateProvider, threading.Thread):
    """A job scheduler (singleton) that provides live state

    The scheduler is based on asyncio for easy concurrency handling.
    This is a singleton - only one scheduler instance exists per process.

    Inherits from StateProvider to allow TUI/Web interfaces to access
    live job and experiment state during experiment execution.
    """

    _instance: ClassVar[Optional["Scheduler"]] = None
    _lock: ClassVar[threading.Lock] = threading.Lock()

    #: Scheduler is always live
    is_live: bool = True

    def __init__(self, name: str = "Global"):
        StateProvider.__init__(self)  # Initialize state listener management
        threading.Thread.__init__(self, name=f"Scheduler ({name})", daemon=True)
        self._ready = threading.Event()

        # Name of the scheduler
        self.name = name

        # Track experiments (simple dict for now)
        self.experiments: Dict[str, "experiment"] = {}

        # Exit mode activated
        self.exitmode = False

        # List of all jobs
        self.jobs: Dict[str, "Job"] = {}

        # Services: (experiment_id, run_id) -> {service_id -> Service}
        self.services: Dict[tuple[str, str], Dict[str, Service]] = {}

        # Per-(experiment, run) metadata
        self._run_infos: dict[tuple[str, str], SchedulerExperimentRunInfo] = {}

        # List of jobs
        self.waitingjobs: Set[Job] = set()

        # Legacy listeners with thread-safe access
        self._listeners: Set[Listener] = set()
        self._listeners_lock = threading.Lock()

        # Notification thread pool (single worker to serialize notifications)
        self._notification_executor = concurrent.futures.ThreadPoolExecutor(
            max_workers=1, thread_name_prefix="NotificationWorker"
        )

        # Server (managed by scheduler)
        self.server: Optional["WebUIServer"] = None

        # Job event readers per workspace
        # Uses EventReader to watch .events/jobs/ directory
        self._job_event_readers: Dict[Path, EventReader] = {}
        self._job_event_readers_lock = threading.Lock()

        # Track which workspaces have logging setup
        self._workspace_logging_setup: set[Path] = set()

    @staticmethod
    def has_instance() -> bool:
        """Check if a scheduler instance exists without creating one"""
        return Scheduler._instance is not None

    @staticmethod
    def instance() -> "Scheduler":
        """Get or create the global scheduler instance"""
        if Scheduler._instance is None:
            with Scheduler._lock:
                if Scheduler._instance is None:
                    Scheduler._instance = Scheduler._create()
        return Scheduler._instance

    @staticmethod
    def _create(name: str = "Global"):
        """Internal method to create and initialize scheduler"""
        instance = Scheduler(name)
        # Initialize the scheduler (sets up loop variables)
        # Don't call start() - scheduler uses EventLoopThread's loop
        instance.run()
        return instance

    @staticmethod
    def create(xp: "Experiment" = None, name: str = "Global"):
        """Create or get the scheduler instance

        Args:
            xp: (Deprecated) Experiment reference, ignored
            name: Name for the scheduler (only used on first creation)

        Returns:
            The global scheduler instance
        """
        return Scheduler.instance()

    def setup_workspace_logging(self, workspace: "Workspace") -> None:
        """Setup logging to workspace .scheduler/{run_id}/experimaestro.log"""
        log_file = workspace.scheduler_run_path / "experimaestro.log"
        log_file.parent.mkdir(parents=True, exist_ok=True)

        # Add file handler to experimaestro logger
        file_handler = logging.FileHandler(log_file)
        file_handler.setLevel(logging.INFO)
        file_handler.setFormatter(
            logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
        )

        xpm_logger = logging.getLogger("xpm")
        xpm_logger.addHandler(file_handler)

        logger.info(f"Logging to {log_file}")

    def register_experiment(self, xp: "Experiment"):
        """Register an experiment with the scheduler"""
        # Use experiment name as key (not workdir.name which is now run_id)
        key = xp.name
        self.experiments[key] = xp

        # Setup workspace logging on first experiment registration
        workspace_path = xp.workspace.path
        if workspace_path not in self._workspace_logging_setup:
            self.setup_workspace_logging(xp.workspace)
            self._workspace_logging_setup.add(workspace_path)

            # Cleanup old run directories (runs at most once per day)
            try:
                deleted, errors = xp.workspace.cleanup_old_scheduler_runs()
                if deleted > 0:
                    logger.info(f"Cleaned up {deleted} old scheduler run directories")
            except Exception as e:
                logger.warning(f"Scheduler run cleanup failed: {e}")

        # Start watching job events for this workspace
        self._start_job_event_reader(xp.workspace.path)

        logger.debug("Registered experiment %s with scheduler", key)

    def unregister_experiment(self, xp: "Experiment"):
        """Mark experiment as finished but keep it registered for TUI visibility

        Previously this removed the experiment from the scheduler, but this caused
        issues with the TUI where jobs would disappear when the experiment finished.
        Now we keep the experiment registered so its jobs remain visible in the TUI.
        The experiment's status (DONE/FAILED/DETACHED) reflects that it's finished.
        """
        key = xp.name
        if key in self.experiments:
            # Don't remove - just log that the experiment has finished
            # The experiment's _status property will be DONE/FAILED/DETACHED
            logger.debug("Experiment %s finished (status: %s)", key, xp.status.name)

    def start_server(
        self,
        settings: "ServerSettings" = None,
        workspace: "Workspace" = None,  # noqa: ARG002 - kept for backward compat
        wait_for_quit: bool = False,
    ):
        """Start the web server (if not already running)

        Args:
            settings: Server settings
            workspace: Workspace instance (deprecated, not used)
            wait_for_quit: If True, server waits for explicit quit from web UI
        """
        if self.server is None:
            from experimaestro.webui import WebUIServer

            # Use the Scheduler itself as the StateProvider for live state access
            self.server = WebUIServer.instance(settings, self, wait_for_quit)
            self.server.start()
            logger.info("Web server started by scheduler")
        else:
            logger.debug("Web server already running")

    def stop_server(self):
        """Stop the web server"""
        if self.server is not None:
            self.server.stop()
            logger.info("Web server stopped by scheduler")

    def wait_for_server_quit(self):
        """Wait for explicit quit from web interface

        Only blocks if server was started with wait_for_quit=True.
        """
        if self.server is not None:
            self.server.wait()

    def run(self):
        """Initialize scheduler using EventLoopThread's event loop.

        The scheduler shares the event loop with lock management and file watching,
        ensuring all async operations happen in a single loop.
        """
        logger.debug("Initializing scheduler")
        from experimaestro.locking import EventLoopThread

        # Use the central event loop from EventLoopThread
        event_loop_thread = EventLoopThread.instance()
        self.loop = event_loop_thread.loop

        # Set loop-dependent variables (must be created in the event loop's context)
        # Schedule their creation on the event loop
        init_done = threading.Event()

        def init_loop_vars():
            self.exitCondition = asyncio.Condition()
            self.dependencyLock = asyncio.Lock()
            init_done.set()

        self.loop.call_soon_threadsafe(init_loop_vars)
        init_done.wait()

        self._ready.set()
        logger.debug("Scheduler initialized with EventLoopThread's loop")

    def addlistener(self, listener: Listener):
        with self._listeners_lock:
            self._listeners.add(listener)

    def removelistener(self, listener: Listener):
        with self._listeners_lock:
            self._listeners.discard(listener)

    def clear_listeners(self):
        """Clear all listeners (for testing purposes)"""
        with self._listeners_lock:
            self._listeners.clear()

    def wait_for_notifications(self, timeout: float = 5.0) -> bool:
        """Wait for all pending notifications to be processed.

        This submits a sentinel task and waits for it to complete,
        ensuring all previously submitted notifications have been processed.

        Args:
            timeout: Maximum time to wait in seconds

        Returns:
            True if all notifications were processed, False if timeout occurred
        """
        try:
            # Submit a no-op and wait for it to complete
            future = self._notification_executor.submit(lambda: None)
            future.result(timeout=timeout)
            return True
        except concurrent.futures.TimeoutError:
            logger.warning("Timeout waiting for notification queue to drain")
            return False

    def getJobState(self, job: Job) -> "concurrent.futures.Future[JobState]":
        # Check if the job belongs to this scheduler
        if job.identifier not in self.jobs:
            # If job is not in this scheduler, return its current state directly
            future = concurrent.futures.Future()
            future.set_result(job.state)
            return future

        return asyncio.run_coroutine_threadsafe(self.aio_getjobstate(job), self.loop)

    async def aio_getjobstate(self, job: Job):
        return job.state

    def submit(self, job: Job) -> Optional[Job]:
        if self.exitmode:
            from experimaestro.exceptions import ExperimentStopped

            raise ExperimentStopped()

        # Wait for the future containing the submitted job
        logger.debug("Submit job %s to the scheduler", job)
        otherFuture = asyncio.run_coroutine_threadsafe(
            self.aio_registerJob(job), self.loop
        )
        other = otherFuture.result()
        logger.debug(
            "Job %s already submitted" if other else "First submission of job %s", job
        )

        # Only returns if job was already submitted and doesn't need reprocessing
        if other is not None:
            # If state is WAITING, it was just reset for resubmission and needs processing
            # If state is RUNNING or finished (DONE), no need to reprocess
            if other.scheduler_state != JobState.WAITING:
                return other
            # Use 'other' for resubmission since it has the correct experiments list
            job = other

        async def submit():
            try:
                state = await self.aio_submit(job)
                # UNSCHEDULED is valid for transient jobs that weren't needed
                if job.scheduler_state == JobState.WAITING:
                    logger.error("Job ended with unexpected state: %s", state)
                elif job.scheduler_state.is_unscheduled():
                    if job.transient.is_transient:
                        logger.debug(
                            "Transient job ended unscheduled (not needed): %s", state
                        )
                    else:
                        logger.error("Job ended with unexpected state: %s", state)
                else:
                    logger.debug("Job ended: %s", state)
                return state
            except Exception:
                logger.exception("Exception in aio_submit for job %s", job)

        job._future = asyncio.run_coroutine_threadsafe(submit(), self.loop)

        return other

    def prepare(self, job: Job):
        """Prepares the job for running"""
        logger.info("Preparing job %s", job.path)
        job.prepare(overwrite=True)

    async def aio_registerJob(self, job: Job):
        """Register a job by adding it to the list, and checks
        whether the job has already been submitted
        """
        logger.debug("Registering job %s", job)

        if self.exitmode:
            from experimaestro.exceptions import ExperimentStopped

            raise ExperimentStopped()

        # Job was already submitted
        if job.identifier in self.jobs:
            other = self.jobs[job.identifier]
            assert job.type == other.type

            # Add current experiment to the existing job's experiments list
            xp = experiment.current()
            xp.add_job(other)

            # Merge transient modes: more conservative mode wins
            # NONE(0) > TRANSIENT(1) > REMOVE(2) - lower value wins
            was_transient = other.transient.is_transient
            if job.transient < other.transient:
                other.transient = job.transient
                # If job was transient and is now non-transient, mark it as needed
                # This flag tells aio_submit not to skip the job
                if was_transient and not other.transient.is_transient:
                    other._needed_transient = True

            # Copy watched outputs from new job to existing job
            # This ensures new callbacks are registered even for resubmitted jobs
            other.watched_outputs.extend(job.watched_outputs)

            # Update max_retries if the new job has a higher value
            # This allows restarting failed jobs by increasing max_retries
            if job.max_retries > other.max_retries:
                other.max_retries = job.max_retries

            # Check if job needs to be re-started
            need_restart = False
            if other.scheduler_state.is_error():
                need_restart = True
            elif (
                was_transient
                and not other.transient.is_transient
                and other.scheduler_state.is_unscheduled()
            ):
                # Job was transient and skipped, but now is non-transient - restart it
                logger.info("Re-submitting job (was transient, now non-transient)")
                need_restart = True

            if need_restart:
                # Clean up old process info so it will be re-started
                other._process = None
                if other.pidpath.is_file():
                    other.pidpath.unlink()
                # Use set_state to handle experiment statistics updates
                other.set_scheduler_state(JobState.WAITING)
                self.notify_job_state(other)  # Notify listeners of re-submit
                # The calling aio_submit will continue with this job and start it
            else:
                logger.warning("Job %s already submitted", job.identifier)

            # Returns the previous job
            return other

        # Register this job
        xp = experiment.current()
        self.jobs[job.identifier] = job
        xp.add_job(job)

        # Get tags from config (tags are experiment-specific, not stored on Job)
        job_tags = dict(job.config.tags()) if job.config.tags() else {}

        # Update per-run info
        exp_run_key = (xp.name, xp.run_id)
        run_info = self._run_infos.setdefault(exp_run_key, SchedulerExperimentRunInfo())

        if job_tags:
            run_info.tags[job.identifier] = job_tags

        depends_on_ids = [
            dep.origin.identifier
            for dep in job.dependencies
            if isinstance(dep, JobDependency)
        ]
        if depends_on_ids:
            run_info.dependencies[job.identifier] = depends_on_ids

        from experimaestro.scheduler.interfaces import ExperimentJobInformation
        import time as _time

        run_info.job_infos[job.identifier] = ExperimentJobInformation(
            job_id=job.identifier,
            task_id=str(job.type.identifier),
            tags=job_tags,
            timestamp=_time.time(),
        )

        # Set up dependencies
        for dependency in job.dependencies:
            dependency.target = job
            # Some dependencies (like PartialDependency) don't have an origin resource
            if dependency.origin is not None:
                dependency.origin.dependents.add(dependency)

        return None

    def _start_job_event_reader(self, workspace_path: Path) -> None:
        """Start watching job events in a workspace

        Uses EventReader to watch .events/jobs/ for job progress events.
        Job state events are emitted by the job process itself.
        Only starts one reader per workspace.

        Args:
            workspace_path: Path to the workspace directory
        """
        with self._job_event_readers_lock:
            # Already watching this workspace
            if workspace_path in self._job_event_readers:
                return

            jobs_dir = workspace_path / ".events" / "jobs"

            # Create new reader for this workspace
            reader = EventReader(
                WatchedDirectory(
                    path=jobs_dir,
                    glob_pattern="*-*-*.jsonl",
                    entity_id_extractor=job_entity_id_extractor,
                    on_should_follow=self._should_follow_job,
                    on_created=self._on_job_created,
                    on_event=self._on_job_event,
                )
            )
            reader.start_watching()
            self._job_event_readers[workspace_path] = reader
            logger.debug("Started job event reader for %s", jobs_dir)

    def _stop_job_event_reader(self, workspace_path: Optional[Path] = None) -> None:
        """Stop watching job events

        Args:
            workspace_path: If provided, stop only this workspace's reader.
                           If None, stop all readers.
        """
        with self._job_event_readers_lock:
            if workspace_path is not None:
                reader = self._job_event_readers.pop(workspace_path, None)
                if reader is not None:
                    reader.stop_watching()
                    logger.debug("Stopped job event reader for %s", workspace_path)
            else:
                # Stop all readers
                for path, reader in self._job_event_readers.items():
                    reader.stop_watching()
                    logger.debug("Stopped job event reader for %s", path)
                self._job_event_readers.clear()

    def _should_follow_job(self, entity_id: str) -> bool:
        """Cheap filter: check if a job is managed by this scheduler (no file I/O)."""
        _task_id, job_id = BaseJob.parse_full_id(entity_id)
        return job_id in self.jobs

    def _on_job_created(self, entity_id: str, events: list) -> bool:
        """Handle new job discovery from EventReader.

        Only follow jobs that this scheduler knows about (was submitted to it).
        Applies historical events in bulk and emits a single notification.

        Args:
            entity_id: Job entity ID in format "{task_id}:{job_id}"
            events: Historical events collected during catch-up

        Returns:
            True if this scheduler should follow the job's events
        """
        # Parse entity_id (full_id) to get job_id
        _task_id, job_id = BaseJob.parse_full_id(entity_id)
        # Only follow jobs that this scheduler is managing
        job = self.jobs.get(job_id)
        if job is None:
            logger.debug(
                "Job created event for %s (job_id=%s): rejected (not in scheduler)",
                entity_id,
                job_id[:8] if job_id else "",
            )
            return False

        logger.debug(
            "Job created event for %s (job_id=%s): accepted (%d events)",
            entity_id,
            job_id[:8] if job_id else "",
            len(events),
        )

        if events:
            job.apply_events(events)
            self.notify_job_state(job)

        return True

    def _on_job_event(self, entity_id: str, event) -> None:
        """Handle job events from EventReader

        Updates job state from file-based events and notifies listeners.

        Args:
            entity_id: Job entity ID in format "{task_id}:{job_id}" (same as full_id)
            event: The event (JobProgressEvent, JobStateChangedEvent, CarbonMetricsEvent)
        """
        # Parse entity_id (full_id) to get job_id
        _task_id, job_id = BaseJob.parse_full_id(entity_id)
        job = self.jobs.get(job_id)
        if job is None:
            logger.debug(
                "Job event for unknown job %s",
                entity_id,
            )
            return
        logger.debug("Received event for job %s: %s", job, event)

        if isinstance(event, JobProgressEvent):
            # Update job's in-memory progress and notify legacy listeners
            job.set_progress(event.level, event.progress, event.desc)
            self.notify_job_state(job)
            # Forward the original progress event to state listeners (TUI/WebUI)
            # so they can handle it specifically, and also send a state changed
            # event so that a refresh picks up the updated job state
            self._notify_state_listeners_async(event)
            self._notify_state_listeners_async(
                JobStateChangedEvent(
                    job_id=job.identifier,
                    state=job.state.name.lower(),
                )
            )

        elif isinstance(event, JobStateChangedEvent):
            # Update execution state from event (e.g., SCHEDULED→RUNNING from job process)
            # NOTE: Only update execution state (_state), NOT scheduler_state.
            # scheduler_state is managed by the scheduler itself (aio_start/finalize).
            # Calling set_scheduler_state here from the FileWatcher thread would race
            # with finalize_status and corrupt experiment stats (unfinishedJobs count).
            new_state = STATE_NAME_TO_JOBSTATE.get(event.state)
            if new_state is not None:
                job.set_state(new_state, loading=True)
                self.notify_job_state(job)
            # Update job timestamps from event
            if event.started_time and job.starttime is None:
                job.starttime = deserialize_to_datetime(event.started_time)
            if event.ended_time and job.endtime is None:
                job.endtime = deserialize_to_datetime(event.ended_time)
            # Forward to state listeners
            self._notify_state_listeners_async(event)

        elif isinstance(event, CarbonMetricsEvent):
            # Update job's carbon metrics and notify listeners
            job.carbon_metrics = CarbonMetricsData(
                co2_kg=event.co2_kg,
                energy_kwh=event.energy_kwh,
                cpu_power_w=event.cpu_power_w,
                gpu_power_w=event.gpu_power_w,
                ram_power_w=event.ram_power_w,
                duration_s=event.duration_s,
                region=event.region,
                is_final=event.is_final,
            )
            logger.debug(
                "Updated carbon metrics for job %s: %.4f kg CO2",
                job.identifier,
                event.co2_kg,
            )
            # Notify StateProvider-style listeners (TUI/WebUI)
            self._notify_state_listeners_async(event)

    def _follow_job_events(self, job: Job) -> None:
        """Tell the EventReader to follow this job's events and consolidate existing ones.

        Called after a job is registered in self.jobs so that event files
        created before the EventReader started (or before the job was known)
        are applied in bulk. This ensures progress/carbon/start_time are up to
        date when picking up an already-running job on restart, without flooding
        listeners with individual notifications.
        """
        workspace_path = job.workspace.path if job.workspace else None
        if workspace_path is None:
            return

        with self._job_event_readers_lock:
            reader = self._job_event_readers.get(workspace_path)
            if reader is None:
                return

        # Build the entity_id in the same format as job_entity_id_extractor
        entity_id = BaseJob.make_full_id(job.task_id, job.identifier)

        # Get the WatchedDirectory config from the reader and collect events
        # without triggering callbacks (replay=False)
        dir_config = None
        for dc in reader.directories:
            if dc.on_event == self._on_job_event:
                dir_config = dc
                events = reader.follow(entity_id, dc)
                break
        else:
            return

        # Always ensure the expected event file is polled. This is needed
        # because: (1) on NFS/shared filesystems, watchdog doesn't detect
        # remote file creation; (2) if the job is restarted, the old event
        # file gets deleted (removing it from polling), but follow() returns
        # early since the entity is already registered.
        expected_file = (
            dir_config.path / f"{task_id_hash(job.task_id)}-{job.identifier}-0.jsonl"
        )
        reader.ensure_file_polled(expected_file)

        if not events:
            return

        # Apply events in bulk to the job (no notifications per event)
        job.apply_events(events)

        # Single notification after consolidation
        self.notify_job_state(job)
        self._notify_state_listeners_async(
            JobStateChangedEvent(
                job_id=job.identifier,
                state=job.state.name.lower(),
            )
        )

    def _cleanup_job_marker_files(self, job: Job) -> None:
        """Clean up old marker files (.done/.failed) from previous runs

        Called when a job is about to start to ensure clean state.
        This is necessary when resubmitting a failed job.

        Args:
            job: The job being started
        """
        logger.debug("Cleaning up marker files for job %s", job.identifier[:8])
        for marker_file in [job.donepath, job.failedpath]:
            logger.debug(
                "  Checking marker file: %s (exists=%s)",
                marker_file,
                marker_file.exists(),
            )
            if marker_file.exists():
                try:
                    marker_file.unlink()
                    logger.debug("  Removed old marker file: %s", marker_file)
                except OSError as e:
                    logger.warning(
                        "Failed to remove marker file %s: %s", marker_file, e
                    )

    def _notify_listeners(self, notification_func, job: Job):
        """Execute notification in thread pool with error isolation.

        This runs notifications in a dedicated thread pool to avoid blocking
        the scheduler and to isolate errors from affecting other listeners.
        """

        def _do_notify():
            # Get a snapshot of listeners with the lock
            with self._listeners_lock:
                listeners_snapshot = list(self._listeners)

            for listener in listeners_snapshot:
                try:
                    notification_func(listener, job)
                except Exception:
                    logger.exception("Got an error with listener %s", listener)

        self._notification_executor.submit(_do_notify)

    def _notify_state_listeners_async(self, event):
        """Notify StateProvider-style listeners asynchronously with error isolation.

        This runs notifications in the same thread pool as _notify_listeners
        to avoid blocking the scheduler and isolate errors.
        """

        def _do_notify():
            # Get a snapshot of listeners with the lock
            with self._state_listener_lock:
                listeners_snapshot = list(self._state_listeners)

            for listener in listeners_snapshot:
                try:
                    listener(event)
                except Exception:
                    logger.exception("Got an error with state listener %s", listener)

        self._notification_executor.submit(_do_notify)

    def notify_job_submitted(self, job: Job):
        """Notify the listeners that a job has been submitted"""
        self._notify_listeners(lambda lst, j: lst.on_job_submitted(j), job)

        # Also notify StateProvider-style listeners (for TUI etc.)
        from experimaestro.scheduler.state_status import ExperimentJobStateEvent, JobTag

        # Get experiment info from job's experiments list
        for exp in job.experiments:
            experiment_id = exp.experiment_id
            run_id = exp.run_id

            # Get tags and dependencies for this job
            exp_run_key = (experiment_id, run_id)
            run_info = self._run_infos.get(exp_run_key)
            tags_dict = run_info.tags.get(job.identifier, {}) if run_info else {}
            tags = [JobTag(key=k, value=v) for k, v in tags_dict.items()]
            depends_on = (
                run_info.dependencies.get(job.identifier, []) if run_info else []
            )

            job_info = run_info.job_infos.get(job.identifier) if run_info else None
            event = ExperimentJobStateEvent(
                experiment_id=experiment_id,
                run_id=run_id,
                job_id=job.identifier,
                task_id=str(job.type.identifier),
                scheduler_state="submitted",
                tags=tags,
                depends_on=depends_on,
                submitted_time=serialize_timestamp(job_info.timestamp)
                if job_info
                else None,
            )
            self._notify_state_listeners_async(event)

    def notify_job_state(self, job: Job):
        """Notify the listeners that a job has changed state

        Note: This does NOT write to job event files. Job events are written
        by the job process itself. The scheduler only forwards notifications
        to listeners.
        """
        # Listener notification (per-experiment)
        self._notify_listeners(lambda lst, j: lst.on_job_state_changed(j), job)

        # Emit ExperimentJobStateEvent for scheduler lifecycle tracking
        failure_reason = None
        if job.scheduler_state.failure_reason is not None:
            failure_reason = job.scheduler_state.failure_reason.name

        for xp in job.experiments:
            event = ExperimentJobStateEvent(
                experiment_id=xp.experiment_id,
                run_id=xp.run_id,
                job_id=job.identifier,
                task_id=job.task_id,
                scheduler_state=job.scheduler_state.name.lower(),
                failure_reason=failure_reason,
            )
            self._notify_state_listeners_async(event)

            # Write to experiment event file for offline monitoring
            if xp._event_writer is not None:
                try:
                    xp._event_writer.write_event(event)
                except Exception as e:
                    logger.warning(
                        "Failed to write scheduler state event to experiment %s: %s",
                        xp.name,
                        e,
                    )

    def notify_service_add(
        self, service: Service, experiment_id: str = "", run_id: str = ""
    ):
        """Notify the listeners that a service has been added"""
        self._notify_listeners(lambda lst, s: lst.on_service_added(s), service)

        # Store experiment info on the service for later retrieval
        if experiment_id:
            service._experiment_id = experiment_id
            service._run_id = run_id or ""

        # Store service in scheduler's services dict (persists after experiment ends)
        if experiment_id:
            key = (experiment_id, run_id or "")
            if key not in self.services:
                self.services[key] = {}
            self.services[key][service.id] = service
            logger.debug(
                "Added service %s to scheduler (experiment=%s, run=%s). Total services: %d",
                service.id,
                experiment_id,
                run_id,
                len(self.services[key]),
            )

        # Also notify StateProvider-style listeners (for TUI etc.)
        from experimaestro.scheduler.state_status import ServiceAddedEvent

        if experiment_id:
            event = ServiceAddedEvent(
                experiment_id=experiment_id,
                run_id=run_id or "",
                service_id=service.id,
            )
            self._notify_state_listeners_async(event)

    async def aio_submit(self, job: Job) -> JobState:
        """Main scheduler function: submit a job, run it (if needed), and returns
        the status code
        """
        logger.info("Submitting job %s", job)
        job.scheduler = self
        self.waitingjobs.add(job)

        # Register watched outputs now that the job has a scheduler
        job.register_watched_outputs()

        # Note: Job metadata will be written after directory is created in aio_start

        # Creates a link into the experiment folder
        path = experiment.current().jobspath / job.relpath
        path.parent.mkdir(parents=True, exist_ok=True)
        if path.is_symlink():
            path.unlink()
        path.symlink_to(job.path)

        # Now, notify that the job has been submitted
        self.notify_job_submitted(job)

        # Run the job and handle retries
        while True:
            try:
                await self.aio_submit_inner(job)
                break
            except GracefulTimeout:
                # If timeout we just start again the loop to start the job again
                # if needed
                logger.info(
                    "GracefulTimeout caught for job %s, restarting",
                    job.identifier[:8],
                )
                pass

        logger.debug("Current job scheduler_state is %s", job.scheduler_state)

        # Process job completion: task outputs, final status write, cleanup
        return await self.aio_final_state(job)

    async def aio_submit_inner(self, job: Job) -> None:
        """Inner job submission logic: load state, check for running process, start if needed.

        This method handles:
        1. Loading existing job state from disk
        2. Checking for already-done or exhausted-retries jobs
        3. Checking for running processes
        4. Starting the job with retry loop for GracefulTimeout

        Args:
            job: The job to submit
        """
        # Load existing job status if available (from previous run)
        # set_state(loading=True) properly handles experiment statistics
        job.load_from_disk()

        # Replay any existing event files for this job (e.g., from a previous
        # scheduler run). Must be AFTER load_from_disk() since that resets
        # progress/carbon from status.json which may be stale.
        self._follow_job_events(job)
        logger.debug("Job state after load_from_disk + events: %s", job.state_dict())

        # Sync scheduler_state from execution state if disk shows a final result
        # (e.g., replaying completed experiment, or scheduler restart after job finished).
        # _load_scheduler_state is a no-op for live Jobs, so scheduler_state may
        # still be WAITING while execution state is DONE/ERROR from disk.
        if job.state.finished() and not job.scheduler_state.finished():
            job.set_scheduler_state(job.state)

        # Check if job is already done (e.g., replaying a completed experiment)
        if job.state == JobState.DONE:
            return

        # Check if job failed with exhausted retries (scheduler knows the lifecycle)
        if (
            job.scheduler_state.is_error()
            and job.resumable
            and job.retry_count >= job.max_retries
        ):
            logger.info(
                "Job %s failed with retry_count=%d/max_retries=%d - not restarting",
                job.identifier[:8],
                job.retry_count,
                job.max_retries,
            )
            return

        # Check if we have a running process
        if not job.state.finished():
            process = await job.aio_process()

            if process is not None:
                logger.info(
                    "Got process %s for job %s - waiting to complete", process, job
                )

                # Just wait for the process to finish since it is already
                # running
                return await self._wait_for_job_process(job, process)

        # If not done or running, start the job
        if not job.state.finished() or job.scheduler_state.is_error():
            # OK, we can reset the job state to run afresh if needed (i.e.
            # error state)
            job._clear_transient_fields()

            # Check if this is a transient job that is not needed
            if job.transient.is_transient and not job._needed_transient:
                logger.debug("Job is transient and not needed, discarding for now")
                job.set_scheduler_state(JobState.TRANSIENT)
            else:
                # Job needs to run, set in WAITING mode
                job.set_scheduler_state(JobState.WAITING)

            # Start the job if not skipped (scheduler_state is still WAITING)
            # Loop to handle GracefulTimeout for resumable tasks
            logger.debug(
                "No process for job %s (scheduler_state %s), starting",
                job,
                job.scheduler_state,
            )
            while job.scheduler_state == JobState.WAITING:
                try:
                    state = await self.aio_start(job)
                    logger.debug(
                        "aio_start returned %s for job %s", state, job.identifier[:8]
                    )
                    if state is not None:
                        job.set_scheduler_state(state)
                        logger.debug(
                            "Job %s state after set_state: %s",
                            job.identifier[:8],
                            job.state,
                        )
                    break  # Exit loop on success
                except GracefulTimeout:
                    # Just re-raise
                    raise
                except Exception:
                    logger.exception("Got an exception while starting the job")
                    raise

    async def aio_final_state(self, job: Job) -> JobState:
        """Process job completion and return final state.

        This method handles:
        1. Skip processing for UNSCHEDULED jobs (transient jobs not needed)
        2. Write final status file (if different from disk)
        3. Process task outputs (with completion signaling)
        4. Remove job from waiting jobs
        5. Notify exit condition

        Args:
            job: The job that has completed

        Returns:
            The final job state
        """
        logger.debug("Processing final state for job %s", job.identifier[:8])

        # Skip processing for UNSCHEDULED jobs (transient jobs that weren't needed)
        if job.scheduler_state.is_unscheduled():
            logger.debug(
                "Skipping final state for unscheduled job %s", job.identifier[:8]
            )

        else:
            # Finalize status: load from disk (carbon info), write if different
            # Preserve current scheduler_state since it was already set by aio_submit_inner
            # (load_from_disk would otherwise overwrite it with stale disk state)
            current_scheduler_state = job.scheduler_state

            def preserve_state_callback(j: Job):
                j.set_scheduler_state(current_scheduler_state)

            await job.finalize_status(callback=preserve_state_callback)

            # Process task outputs (queues remaining events for processing)
            await job.aio_done_handler()

        # Remove from waiting jobs
        self.waitingjobs.discard(job)

        # Notify with final state
        self.notify_job_state(job)

        # Notify the experiments
        async with self.exitCondition:
            self.exitCondition.notify_all()

        # Wait for done handler to complete and notify exit condition
        return job.scheduler_state

    async def _wait_for_job_process(self, job: Job, process: "Process") -> None:
        """Wait for a running job process to complete and update state.

        Args:
            job: The job with a running process
            process: The process to wait for
        """

        # And now, we wait...
        code = await process.aio_code()
        logger.info("Job %s completed with code %s", job, code)

        # Record exit code if available
        if code is not None:
            job.exit_code = code

        # Read state from .done/.failed files (contains detailed failure reason)
        state = JobState.from_path(job.path, job.name)

        # If state is a generic FAILED error, let the process determine
        # the state (it may detect launcher-specific failures like SLURM timeout)
        if (
            state is not None
            and state.is_error()
            and state.failure_reason == JobFailureStatus.FAILED
            and code is not None
        ):
            process_state = process.get_job_state(code)
            if (
                process_state.is_error()
                and process_state.failure_reason != JobFailureStatus.FAILED
            ):
                # Process detected a more specific failure reason
                state = process_state

        if state is None:
            if code is not None:
                # Fall back to process-specific state detection
                state = process.get_job_state(code)
            else:
                logger.error("No .done or .failed file found for job %s", job)
                state = JobState.ERROR

        job.set_scheduler_state(state)
        self.notify_job_state(job)  # Notify listeners of final state

    async def aio_start(self, job: Job) -> Optional[JobState]:  # noqa: C901
        """Start a job with full job starting logic

        This method handles job locking, dependency acquisition, directory setup,
        and job execution while using the scheduler's coordination lock to prevent
        race conditions between multiple jobs.

        :param job: The job to start
        :return: JobState.WAITING if dependencies could not be locked, JobState.DONE
            if job completed successfully, JobState.ERROR if job failed during execution,
            or None (should not occur in normal operation)
        :raises Exception: Various exceptions during job execution, dependency locking,
            or process creation
        """
        from experimaestro.locking import DynamicDependencyLocks, LockError

        # Separate static and dynamic dependencies
        static_deps = [d for d in job.dependencies if not d.is_dynamic()]
        dynamic_deps = [d for d in job.dependencies if d.is_dynamic()]

        logger.debug(
            "Starting job %s with %d dependencies (%d static, %d dynamic)",
            job,
            len(job.dependencies),
            len(static_deps),
            len(dynamic_deps),
        )

        # First, wait for all static dependencies (jobs) to complete
        # These don't need the dependency lock as they can't change state
        # Static dependency locks don't need to be added to locks list
        logger.debug("Waiting for %d static dependencies", len(static_deps))
        for dependency in static_deps:
            logger.debug("Waiting for static dependency %s", dependency)
            try:
                await dependency.aio_lock()
            except RuntimeError as e:
                # Dependency failed - mark job as failed due to dependency
                logger.warning("Job %s cannot start: dependency failed: %s", job, e)
                return JobStateError(JobFailureStatus.DEPENDENCY)

        # We first lock the job before proceeding
        async with DynamicDependencyLocks() as locks:
            logger.debug("[starting] Locking job %s", job)
            async with job.launcher.connector.async_lock(job.lockpath):
                logger.debug("[starting] Locked job %s", job)

                state = None
                try:
                    # Now handle dynamic dependencies (tokens) with retry logic
                    # CRITICAL: Only one task at a time can acquire dynamic dependencies
                    # to prevent deadlocks (e.g., Task A holds Token1 waiting for Token2,
                    # Task B holds Token2 waiting for Token1)
                    if dynamic_deps:
                        async with self.dependencyLock:
                            logger.debug(
                                "Locking %d dynamic dependencies (tokens)",
                                len(dynamic_deps),
                            )
                            while True:
                                all_locked = True
                                for idx, dependency in enumerate(dynamic_deps):
                                    try:
                                        # Use timeout=0 for first dependency, 0.1s for subsequent
                                        timeout = 0 if idx == 0 else 0.1
                                        # Acquire the lock (this might block on IPC locks)
                                        lock = await dependency.aio_lock(
                                            timeout=timeout
                                        )
                                        locks.append(lock)
                                    except LockError:
                                        logger.info(
                                            "Could not lock %s, retrying",
                                            dependency,
                                        )
                                        # Release all locks and restart
                                        for lock in locks.locks:
                                            await lock.aio_release()
                                        locks.locks.clear()
                                        # Put failed dependency first
                                        dynamic_deps.remove(dependency)
                                        dynamic_deps.insert(0, dependency)
                                        all_locked = False
                                        break
                                    except Exception as e:
                                        # Check if this is a StaleLockError
                                        from experimaestro.locking import StaleLockError

                                        if isinstance(e, StaleLockError):
                                            logger.warning(
                                                "Stale locks detected for %s: %s",
                                                dependency,
                                                e.description[:100],
                                            )
                                            # Create warning event to listeners
                                            from experimaestro.scheduler.state_status import (
                                                WarningEvent,
                                            )

                                            warning_event = WarningEvent(
                                                experiment_id=job.experiment_id,
                                                run_id=job.experiment.run_id,
                                                warning_key=e.warning_key,
                                                description=e.description,
                                                actions=e.actions,
                                                context=e.context,
                                            )

                                            # Register action callbacks and metadata
                                            self.register_warning_actions(
                                                e.warning_key,
                                                e.callbacks,
                                                warning_event,
                                            )

                                            # Emit warning event to listeners
                                            self._notify_state_listeners(warning_event)
                                            logger.info(
                                                "Emitted WarningEvent for stale locks: %s",
                                                e.warning_key,
                                            )
                                        # Re-raise to trigger retry logic
                                        raise LockError(f"Failed to acquire lock: {e}")

                                if all_locked:
                                    # All locks acquired successfully
                                    break

                    # Creates the main directory
                    directory = job.path
                    logger.debug("Making directories job %s...", directory)

                    # Warn about directory cleanup for non-resumable tasks
                    # (only once per task type)
                    xpmtype = job.config.__xpmtype__
                    if (
                        directory.is_dir()
                        and not job.resumable
                        and not xpmtype.warned_clean_not_resumable
                    ):
                        xpmtype.warned_clean_not_resumable = True
                        logger.warning(
                            "In a future version, directory will be cleaned up for "
                            "non-resumable tasks (%s). Use ResumableTask if you want "
                            "to preserve the directory contents.",
                            xpmtype.identifier,
                        )

                    if not directory.is_dir():
                        directory.mkdir(parents=True, exist_ok=True)

                    # Clean up old job event files from previous runs
                    job._cleanup_event_files()

                    # Clean up old marker files (.done/.failed) from previous runs
                    self._cleanup_job_marker_files(job)

                    # Generate run_group_id on first run (preserved across retries)
                    if job.run_group_id is None:
                        job.run_group_id = datetime.now().strftime("%Y%m%d-%H%M%S.%f")[
                            :18
                        ]

                    # Write metadata with submit and start time (after directory creation)
                    job.status_path.parent.mkdir(parents=True, exist_ok=True)
                    job.status_path.write_text(json.dumps(job.state_dict()))

                    # Notify locks before job starts (e.g., create symlinks)
                    await locks.aio_job_before_start(job)

                except Exception:
                    logger.warning(
                        "Error while locking job %s (path: %s), will retry",
                        job,
                        job.path,
                        exc_info=True,
                    )
                    return JobState.WAITING

                try:
                    # Rotate logs if this is a retry of a resumable task
                    if job.resumable and job.retry_count > 0:
                        job.rotate_logs()

                    # Runs the job
                    process = await job.aio_run()

                    # Notify locks that job has started
                    await locks.aio_job_started(job, process)

                    # Write locks.json for job process (if there are dynamic locks)
                    if locks.locks:
                        import tempfile

                        locks_path = job.path / "locks.json"
                        locks_data = {"dynamic_locks": locks.to_json()}
                        # Atomic write: write to temp file then rename
                        with tempfile.NamedTemporaryFile(
                            mode="w",
                            dir=job.path,
                            prefix=".locks.",
                            suffix=".json",
                            delete=False,
                        ) as tmp:
                            json.dump(locks_data, tmp)
                            tmp_path = tmp.name
                        # Rename is atomic on POSIX
                        import os

                        os.rename(tmp_path, locks_path)
                except Exception:
                    logger.error(
                        "Error while starting job %s (path: %s)",
                        job,
                        job.path,
                        exc_info=True,
                    )
                    return JobState.ERROR

            # The job process will update this to RUNNING when it starts. We set
            # it to SCHEDULED here to reflect that the job has been launched and
            # is awaiting execution.
            job.set_scheduler_state(JobState.SCHEDULED)

            # Pre-register the job entity with the event reader so that
            # file watcher events are properly routed when the job process
            # starts writing event files.
            self._follow_job_events(job)

            # Wait for job to complete while holding locks
            try:
                logger.debug("Waiting for job %s process to end", job)

                code = await process.aio_code()
                logger.debug("Got return code %s for %s", code, job)

                # Record exit code if available
                if code is not None:
                    logger.info("Job %s ended with code %s", job, code)
                    job.exit_code = code
                else:
                    logger.info("Job %s ended, reading state from files", job)

                # Read state from .done/.failed files (contains detailed failure reason)
                state = JobState.from_path(job.path, job.name)
                logger.debug(
                    "State from marker files for job %s: %s (code=%s, donepath=%s, failedpath=%s)",
                    job.identifier[:8],
                    state,
                    code,
                    job.donepath.exists(),
                    job.failedpath.exists(),
                )

                # If state is a generic FAILED error, let the process determine
                # the state (it may detect launcher-specific failures like SLURM timeout)
                if (
                    state is not None
                    and state.is_error()
                    and state.failure_reason == JobFailureStatus.FAILED
                    and code is not None
                ):
                    process_state = process.get_job_state(code)
                    if (
                        process_state.is_error()
                        and process_state.failure_reason != JobFailureStatus.FAILED
                    ):
                        # Process detected a more specific failure reason
                        state = process_state

                if state is None:
                    if code is not None:
                        # Fall back to process-specific state detection
                        state = process.get_job_state(code)
                    else:
                        logger.error("No .done or .failed file found for job %s", job)
                        state = JobState.ERROR

            except JobError:
                logger.error(
                    "Error while running job %s (path: %s)",
                    job,
                    job.path,
                    exc_info=True,
                )
                state = JobState.ERROR

            except Exception:
                logger.error(
                    "Error while running job %s (in experimaestro, path: %s)",
                    job,
                    job.path,
                    exc_info=True,
                )
                state = JobState.ERROR

            # Notify locks that job has finished (before releasing)
            await locks.aio_job_finished(job)

        # Locks are released here after job completes

        # Finalize status: load from disk (carbon info), set state, increment retry_count
        def finalize_callback(j: Job):
            j.set_scheduler_state(state)
            # Increment retry_count for any failure of a resumable task
            if state.is_error() and j.resumable:
                j.retry_count += 1

        logger.debug("[job ended] Finalizing")
        await job.finalize_status(callback=finalize_callback)

        # Check if we should restart a resumable task that timed out
        if (
            state.is_error()
            and state.failure_reason == JobFailureStatus.TIMEOUT
            and job.resumable
            and job.retry_count <= job.max_retries
        ):
            logger.info(
                "Resumable task %s timed out - restarting (attempt %d/%d)",
                job,
                job.retry_count,
                job.max_retries,
            )

            # Clear cached process so aio_run() will create a new one
            job._process = None

            # Continue the loop to restart
            raise GracefulTimeout()

        # Job finished (success or non-recoverable error)
        # Notify scheduler listeners of job state after job completes
        self.notify_job_state(job)
        return state

    # =========================================================================
    # StateProvider abstract method implementations
    # =========================================================================

    def get_experiments(
        self,
        since: Optional[datetime] = None,  # noqa: ARG002
    ) -> List[BaseExperiment]:
        """Get list of all live experiments"""
        # Note: 'since' filter not applicable for live scheduler
        return list(self.experiments.values())

    def get_experiment(self, experiment_id: str) -> Optional[BaseExperiment]:
        """Get a specific experiment by ID"""
        return self.experiments.get(experiment_id)

    def get_experiment_runs(self, experiment_id: str) -> List[BaseExperiment]:
        """Get all runs for an experiment

        For a live scheduler, returns the live experiment directly.
        """
        exp = self.experiments.get(experiment_id)
        if not exp:
            return []

        # Return the live experiment (it already implements BaseExperiment)
        return [exp]

    def get_current_run(self, experiment_id: str) -> Optional[str]:
        """Get the current run ID for an experiment"""
        exp = self.experiments.get(experiment_id)
        return exp.run_id if exp else None

    def get_jobs(
        self,
        experiment_id: Optional[str] = None,
        run_id: Optional[str] = None,  # noqa: ARG002 - not used in live scheduler
        task_id: Optional[str] = None,
        state: Optional[str] = None,
        tags: Optional[Dict[str, str]] = None,
        since: Optional[datetime] = None,  # noqa: ARG002 - not used in live scheduler
    ) -> List[BaseJob]:
        """Query jobs with optional filters"""
        jobs: List[BaseJob] = list(self.jobs.values())

        # Filter by experiment
        if experiment_id:
            exp = self.experiments.get(experiment_id)
            if exp:
                jobs = [j for j in jobs if j.experiments and exp in j.experiments]
            else:
                jobs = []

        # Filter by task_id
        if task_id:
            jobs = [j for j in jobs if j.task_id == task_id]

        # Filter by state (uses scheduler_state for live scheduler)
        if state:
            jobs = [j for j in jobs if j.scheduler_state.name.lower() == state.lower()]

        # Filter by tags (all tags must match)
        if tags:
            jobs = [j for j in jobs if all(j.tags.get(k) == v for k, v in tags.items())]

        return jobs

    def get_job(
        self,
        task_id: str,  # noqa: ARG002 - job_id is sufficient in live scheduler
        job_id: str,
    ) -> Optional[BaseJob]:
        """Get a specific job"""
        return self.jobs.get(job_id)

    def get_all_jobs(
        self,
        state: Optional[str] = None,
        tags: Optional[Dict[str, str]] = None,
        since: Optional[datetime] = None,  # noqa: ARG002 - not used in live scheduler
    ) -> List[BaseJob]:
        """Get all jobs across all experiments"""
        jobs: List[BaseJob] = list(self.jobs.values())

        if state:
            jobs = [j for j in jobs if j.scheduler_state.name.lower() == state.lower()]

        if tags:
            jobs = [j for j in jobs if all(j.tags.get(k) == v for k, v in tags.items())]

        return jobs

    def get_services(
        self,
        experiment_id: Optional[str] = None,
        run_id: Optional[str] = None,
    ) -> List[BaseService]:
        """Get services for an experiment

        Services are stored in the scheduler and persist after experiments finish.
        """
        if experiment_id is None:
            # Return all services from all experiments
            services = []
            for services_dict in self.services.values():
                services.extend(services_dict.values())
            return services

        # Get services for specific experiment
        services = []
        if run_id is not None:
            # Specific run requested
            key = (experiment_id, run_id)
            services_dict = self.services.get(key, {})
            services = list(services_dict.values())
        else:
            # No run_id specified - return services from all runs of this experiment
            for (exp_id, _run_id), services_dict in self.services.items():
                if exp_id == experiment_id:
                    services.extend(services_dict.values())

        logger.debug(
            "get_services(%s, %s): returning %d services",
            experiment_id,
            run_id,
            len(services),
        )
        return services

    def _get_run_info(
        self, experiment_id: str, run_id: Optional[str] = None
    ) -> SchedulerExperimentRunInfo | None:
        """Get the run info for an experiment/run, or None if not found."""
        exp = self.experiments.get(experiment_id)
        if not exp:
            return None
        if run_id is None:
            run_id = exp.run_id
        return self._run_infos.get((experiment_id, run_id))

    def get_tags_map(
        self,
        experiment_id: str,
        run_id: Optional[str] = None,
    ) -> dict[str, dict[str, str]]:
        info = self._get_run_info(experiment_id, run_id)
        return info.tags if info else {}

    def get_dependencies_map(
        self,
        experiment_id: str,
        run_id: Optional[str] = None,
    ) -> dict[str, list[str]]:
        info = self._get_run_info(experiment_id, run_id)
        return info.dependencies if info else {}

    def get_experiment_job_info(
        self,
        experiment_id: str,
        run_id: Optional[str] = None,
    ) -> dict[str, "ExperimentJobInformation"]:
        info = self._get_run_info(experiment_id, run_id)
        return info.job_infos if info else {}

    def kill_job(self, job: BaseJob, perform: bool = False) -> bool:
        """Kill a running or scheduled job.

        For the scheduler, this is a live operation. Works for both:
        - RUNNING jobs: actively executing
        - SCHEDULED jobs: submitted to launcher (e.g., SLURM pending queue)

        Raises:
            RuntimeError: If the job cannot be killed.
        """
        if not perform:
            # Just check if the job can be killed
            return job.scheduler_state.running()

        if not job.scheduler_state.running():
            raise RuntimeError("Job is not running or scheduled")

        # Get the actual Job from our jobs dict
        actual_job = self.jobs.get(job.identifier)
        if actual_job is None:
            raise RuntimeError("Job not found in scheduler")

        # Try to kill the process via the _process attribute
        process = actual_job._process
        if process is None:
            raise RuntimeError("No process found for job")

        try:
            process.kill()
            return True
        except Exception as e:
            logger.exception("Failed to kill job %s", job.identifier)
            raise RuntimeError(f"Failed to kill process: {e}") from e

    def clean_job(
        self,
        job: BaseJob,  # noqa: ARG002
        perform: bool = False,  # noqa: ARG002
    ) -> bool:
        """Clean a finished job

        For the scheduler, jobs are automatically cleaned when they finish.
        """
        # Live scheduler doesn't support cleaning jobs
        return False

    def get_process_info(self, job: BaseJob):
        """Get process information for a job

        For the scheduler, we can access the actual Job and read its PID file.
        """
        from experimaestro.scheduler.state_provider import ProcessInfo

        # Get the actual Job from our jobs dict
        actual_job = self.jobs.get(job.identifier)
        if actual_job is None:
            return None

        # Try to read the PID file
        try:
            pidpath = getattr(actual_job, "pidpath", None)
            if pidpath is None or not pidpath.exists():
                return None

            pinfo = json.loads(pidpath.read_text())
            pid = pinfo.get("pid")
            proc_type = pinfo.get("type", "unknown")

            if pid is None:
                return None

            # Check if running based on scheduler state
            running = actual_job.scheduler_state == JobState.RUNNING

            return ProcessInfo(pid=pid, type=proc_type, running=running)
        except Exception:
            return None

    def close(self) -> None:
        """Close the state provider and clean up resources"""
        # Stop all job event readers
        self._stop_job_event_reader()

    @property
    def read_only(self) -> bool:
        """Live scheduler is read-write"""
        return False

    @property
    def is_remote(self) -> bool:
        """Live scheduler is local"""
        return False
