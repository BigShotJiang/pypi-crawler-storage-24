import asyncio
import logging
import threading
from datetime import datetime
from pathlib import Path
from typing import (
    Any,
    Dict,
    List,
    Optional,
    Tuple,
    TYPE_CHECKING,
    get_type_hints,
)
from experimaestro.connectors.local import LocalConnector
import re
from shlex import quote as shquote
from contextlib import contextmanager
from dataclasses import dataclass
from experimaestro.launcherfinder.registry import (
    LauncherRegistry,
)
from experimaestro.utils import ThreadingCondition
from experimaestro.tests.connectors.utils import OutputCaptureHandler
from functools import cached_property
from experimaestro.launchers import Launcher
from experimaestro.scriptbuilder import PythonScriptBuilder
from experimaestro.connectors import (
    Connector,
    ProcessBuilder,
    Process,
    ProcessState,
    Redirect,
    RedirectType,
)

if TYPE_CHECKING:
    from experimaestro.scheduler.jobs import JobState

logger = logging.getLogger("xpm.slurm")

# Cached job end time (absolute timestamp).
# Only used when a task is running within a SLURM job.
_slurm_job_end_time: Optional[float] = None


class SlurmLauncherInformation:
    """Launcher information for SLURM jobs, used during task execution."""

    def __init__(self, binpath: str = "/usr/bin"):
        self.binpath = Path(binpath)

    def remaining_time(self) -> Optional[float]:
        """Returns the remaining time in seconds before the SLURM job times out.

        Uses the SLURM_JOB_ID environment variable to query squeue for the
        remaining time. The job end time is cached on first call.

        Returns:
            The remaining time in seconds, or None if no time limit.
        """
        import os
        import time

        global _slurm_job_end_time

        # Use cached end time if available
        if _slurm_job_end_time is not None:
            remaining = _slurm_job_end_time - time.time()
            return max(0.0, remaining)

        # Query SLURM for remaining time and compute end time
        job_id = os.environ.get("SLURM_JOB_ID")
        if not job_id:
            logger.debug("No SLURM_JOB_ID in environment, cannot get remaining time")
            return None

        remaining_seconds = self._query_remaining_time(job_id)
        if remaining_seconds is None:
            return None

        # Cache the absolute end time
        _slurm_job_end_time = time.time() + remaining_seconds
        return remaining_seconds

    def _query_remaining_time(self, job_id: str) -> Optional[float]:
        """Query SLURM for remaining time of a job."""
        import subprocess

        try:
            result = subprocess.run(
                [
                    f"{self.binpath}/squeue",
                    "--job",
                    job_id,
                    "--format=%L",
                    "--noheader",
                ],
                capture_output=True,
                text=True,
                timeout=30,
            )

            if result.returncode != 0:
                logger.warning(
                    "squeue returned error code %d: %s",
                    result.returncode,
                    result.stderr,
                )
                return None

            time_str = result.stdout.strip()
            if not time_str or time_str == "UNLIMITED":
                return None

            return self._parse_slurm_time(time_str)
        except subprocess.TimeoutExpired:
            logger.warning("Timeout querying squeue for remaining time")
            return None
        except Exception as e:
            logger.warning("Error querying SLURM remaining time: %s", e)
            return None

    @staticmethod
    def _parse_slurm_time(time_str: str) -> Optional[float]:
        """Parse SLURM time format to seconds.

        SLURM time format can be:
        - D-HH:MM:SS (days-hours:minutes:seconds)
        - HH:MM:SS (hours:minutes:seconds)
        - MM:SS (minutes:seconds)
        - SS (seconds)

        Returns:
            Time in seconds, or None if parsing fails
        """
        try:
            days = 0
            if "-" in time_str:
                days_str, time_str = time_str.split("-", 1)
                days = int(days_str)

            parts = time_str.split(":")
            if len(parts) == 3:
                hours, minutes, seconds = int(parts[0]), int(parts[1]), int(parts[2])
            elif len(parts) == 2:
                hours = 0
                minutes, seconds = int(parts[0]), int(parts[1])
            elif len(parts) == 1:
                hours = 0
                minutes = 0
                seconds = int(parts[0])
            else:
                logger.warning("Could not parse SLURM time: %s", time_str)
                return None

            return float(days * 86400 + hours * 3600 + minutes * 60 + seconds)
        except (ValueError, IndexError) as e:
            logger.warning("Could not parse SLURM time '%s': %s", time_str, e)
            return None


class SlurmJobState:
    start: str
    end: str
    status: str

    STATE_MAP = {
        "CONFIGURING": ProcessState.SCHEDULED,
        "REQUEUE_FED": ProcessState.SCHEDULED,
        "PENDING": ProcessState.SCHEDULED,
        "REQUEUE_HOLD": ProcessState.SCHEDULED,
        "COMPLETING": ProcessState.RUNNING,
        "RUNNING": ProcessState.RUNNING,
        "COMPLETED": ProcessState.DONE,
        "FAILED": ProcessState.ERROR,
        "DEADLINE": ProcessState.ERROR,
        "NODE_FAIL": ProcessState.ERROR,
        "REVOKED": ProcessState.ERROR,
        "TIMEOUT": ProcessState.ERROR,
        "CANCELLED": ProcessState.ERROR,
        "BOOT_FAIL": ProcessState.ERROR,
        "OUT_OF_MEMORY": ProcessState.ERROR,
    }

    @staticmethod
    def get_failure_status(reason: str):
        """Get the JobFailureStatus for a fatal pending reason, or None"""
        from experimaestro.scheduler.jobs import JobFailureStatus

        _REASON_TO_STATUS = {
            "PartitionTimeLimit": JobFailureStatus.REJECTED_TIMELIMIT,
        }
        return _REASON_TO_STATUS.get(reason)

    def __init__(self, status, start, end):
        self.slurm_state = status if status[-1] == "+" else status
        self.reason = ""
        if self.slurm_state.startswith("CANCELLED"):
            self.state = ProcessState.ERROR
        else:
            self.state = SlurmJobState.STATE_MAP.get(self.slurm_state, None)
            if self.state is None:
                logging.warning(
                    "Unknown state: %s (supposing this is an error)", self.slurm_state
                )
                self.state = ProcessState.ERROR

        self.start = start
        self.end = end

    def set_pending_reason(self, reason: str):
        """Update state based on pending reason from squeue"""
        self.reason = reason
        if (
            self.slurm_state == "PENDING"
            and self.get_failure_status(reason) is not None
        ):
            logging.error("SLURM job will never start (reason: %s)", reason)
            self.state = ProcessState.ERROR

    def finished(self):
        """Returns true if the job has finished"""
        return self.state.finished

    def __repr__(self):
        return f"{self.slurm_state} ({self.start}-{self.end})"


class SlurmProcessWatcher(threading.Thread):
    """Process that calls sacct at regular interval to check job status"""

    WATCHERS: Dict[Tuple[Tuple[str, Any]], "SlurmProcessWatcher"] = {}
    WATCHERS_LOCK = threading.Lock()

    def __init__(self, launcher: "SlurmLauncher"):
        super().__init__(daemon=True)
        self.launcher = launcher
        self.count = 0  # Will be incremented to 1 by first get() call
        self.jobs: Dict[str, SlurmJobState] = {}

        self.cv = ThreadingCondition()
        self.fetched_event = threading.Event()
        self.updating_jobs = threading.Lock()
        self.last_check_time: datetime | None = None

        # Async waiters for job completion: jobid -> list of (asyncio.Future, event_loop)
        self.async_waiters: Dict[
            str, List[Tuple[asyncio.Future, asyncio.AbstractEventLoop]]
        ] = {}
        # Async waiters for state change: jobid -> list of (asyncio.Future, event_loop)
        self.async_state_waiters: Dict[
            str, List[Tuple[asyncio.Future, asyncio.AbstractEventLoop]]
        ] = {}
        self.async_waiters_lock = threading.Lock()

        # Async waiters for first fetch: list of (asyncio.Future, event_loop)
        self.async_fetched_waiters: List[
            Tuple[asyncio.Future, asyncio.AbstractEventLoop]
        ] = []
        # Note: start() is called by get() after incrementing count

    @staticmethod
    def acquire(launcher: "SlurmLauncher") -> "SlurmProcessWatcher":
        """Acquire a reference to the watcher, creating it if needed.

        The caller must call release() when done to allow the watcher to stop.
        """
        with SlurmProcessWatcher.WATCHERS_LOCK:
            watcher = SlurmProcessWatcher.WATCHERS.get(launcher.key, None)
            is_new = watcher is None
            if is_new:
                watcher = SlurmProcessWatcher(launcher)
                SlurmProcessWatcher.WATCHERS[launcher.key] = watcher
            with watcher.cv:
                watcher.count += 1
            # Start thread after incrementing count (for new watchers only)
            if is_new:
                watcher.start()
        return watcher

    @staticmethod
    def release(watcher: "SlurmProcessWatcher"):
        """Release a reference to the watcher."""
        with watcher.cv:
            watcher.count -= 1
            watcher.cv.notify()

    @staticmethod
    @contextmanager
    def get(launcher: "SlurmLauncher"):
        watcher = SlurmProcessWatcher.acquire(launcher)
        try:
            yield watcher
        finally:
            SlurmProcessWatcher.release(watcher)

    def getjob(self, jobid, timeout=None, *, wait_for_update: bool = True):
        """Get job state from the watcher (blocking).

        Args:
            jobid: The SLURM job ID to look up
            timeout: Timeout for waiting for an update (only if wait_for_update=True)
            wait_for_update: If True (default), wait for the next poll cycle.
                If False, return current cached data immediately after first fetch.
        """
        # Ensures that we have fetched at least once
        self.fetched_event.wait()

        if wait_for_update:
            # Waits that jobs are refreshed (with a timeout)
            with self.cv:
                logger.debug(
                    "Waiting for information about %s [timeout=%s]", jobid, timeout
                )
                self.cv.wait(timeout=timeout)

        # Ensures jobs are not updated right now
        with self.updating_jobs:
            return self.jobs.get(jobid)

    async def aio_getjob(self, jobid) -> Optional[SlurmJobState]:
        """Get job state from the watcher (async, non-blocking).

        Waits asynchronously for the first fetch if needed, then returns
        the current cached state without waiting for updates.

        Args:
            jobid: The SLURM job ID to look up

        Returns:
            SlurmJobState or None if job not found
        """
        # If already fetched, return immediately
        if self.fetched_event.is_set():
            with self.updating_jobs:
                return self.jobs.get(jobid)

        # Register for async notification of first fetch
        loop = asyncio.get_running_loop()
        future = loop.create_future()
        with self.async_waiters_lock:
            self.async_fetched_waiters.append((future, loop))

        # Check again in case it was set while we were registering
        if self.fetched_event.is_set():
            # Cancel our waiter and return immediately
            with self.async_waiters_lock:
                self.async_fetched_waiters = [
                    (f, lp) for f, lp in self.async_fetched_waiters if f is not future
                ]
            with self.updating_jobs:
                return self.jobs.get(jobid)

        # Wait for the first fetch
        await future

        # Return the job state
        with self.updating_jobs:
            return self.jobs.get(jobid)

    def register_async_waiter(
        self, jobid: str, loop: asyncio.AbstractEventLoop
    ) -> asyncio.Event:
        """Register an async waiter for a job.

        Returns an asyncio.Event that will be set when the job finishes.
        """
        event = loop.create_future()
        with self.async_waiters_lock:
            if jobid not in self.async_waiters:
                self.async_waiters[jobid] = []
            self.async_waiters[jobid].append((event, loop))
        return event

    def register_async_state_waiter(
        self, jobid: str, loop: asyncio.AbstractEventLoop
    ) -> asyncio.Future:
        """Register an async waiter for job state change.

        Returns an asyncio.Future that will be set on next state update.
        """
        future = loop.create_future()
        with self.async_waiters_lock:
            if jobid not in self.async_state_waiters:
                self.async_state_waiters[jobid] = []
            self.async_state_waiters[jobid].append((future, loop))
        return future

    def _notify_async_waiters(self):
        """Notify async waiters for finished jobs and state changes"""
        with self.async_waiters_lock:
            # Notify completion waiters
            finished_jobs = []
            for jobid, waiters in self.async_waiters.items():
                state = self.jobs.get(jobid)
                if state and state.finished():
                    finished_jobs.append(jobid)
                    for future, loop in waiters:
                        # Set the result from watcher thread to asyncio loop
                        loop.call_soon_threadsafe(future.set_result, state)

            for jobid in finished_jobs:
                del self.async_waiters[jobid]

            # Notify state change waiters (always notify with current state)
            for jobid, waiters in list(self.async_state_waiters.items()):
                state = self.jobs.get(jobid)
                for future, loop in waiters:
                    loop.call_soon_threadsafe(future.set_result, state)
            self.async_state_waiters.clear()

    def _notify_async_fetched_waiters(self):
        """Notify async waiters waiting for the first fetch"""
        with self.async_waiters_lock:
            for future, loop in self.async_fetched_waiters:
                loop.call_soon_threadsafe(future.set_result, True)
            self.async_fetched_waiters.clear()

    def _check_pending_reasons(self, pending_ids: list[str]):
        """Query squeue for pending job reasons and update states.

        Jobs with fatal reasons (e.g. PartitionTimeLimit) are cancelled
        and marked as errors.
        """
        builder = self.launcher.connector.processbuilder()
        builder.command = [
            f"{self.launcher.binpath}/squeue",
            "--jobs=" + ",".join(pending_ids),
            "--format=%i|%r",
            "--noheader",
        ]
        handler = OutputCaptureHandler()
        builder.detach = False
        builder.stdout = Redirect.pipe(handler)
        builder.environ = self.launcher.launcherenv
        process = builder.start()
        process.wait()
        output = handler.output.decode("utf-8")

        cancel_ids = []
        for line in output.split("\n"):
            line = line.strip()
            if not line:
                continue
            try:
                jobid, reason = line.split("|", 1)
                jobid = jobid.strip()
                reason = reason.strip()
                if jobid in self.jobs:
                    self.jobs[jobid].set_pending_reason(reason)
                    if SlurmJobState.get_failure_status(reason) is not None:
                        cancel_ids.append(jobid)
            except ValueError:
                logger.error("Could not parse squeue line: %s", line)

        # Cancel jobs that will never start
        if cancel_ids:
            builder = self.launcher.connector.processbuilder()
            builder.command = [
                f"{self.launcher.binpath}/scancel",
                *cancel_ids,
            ]
            builder.environ = self.launcher.launcherenv
            builder.start()
            logger.warning(
                "Cancelled SLURM jobs with fatal pending reasons: %s",
                ", ".join(cancel_ids),
            )

    def run(self):
        while self.count > 0:
            builder = self.launcher.connector.processbuilder()
            builder.command = [
                f"{self.launcher.binpath}/sacct",
                "-n",
                "-p",
                "--format=JobID,State,Start,End",
            ]
            handler = OutputCaptureHandler()
            builder.detach = False
            builder.stdout = Redirect.pipe(handler)
            builder.environ = self.launcher.launcherenv
            logger.debug("Checking SLURM state with sacct")
            process = builder.start()

            with self.updating_jobs:
                old_jobs = self.jobs
                self.jobs = {}
                output = handler.output.decode("utf-8")
                for line in output.split("\n"):
                    line = line.strip()
                    if line:
                        try:
                            jobid, state, start, end, *_ = line.split("|")
                            new_state = SlurmJobState(state, start, end)
                            # Carry forward reason from previous poll
                            old = old_jobs.get(jobid)
                            if old and old.reason:
                                new_state.reason = old.reason
                            self.jobs[jobid] = new_state
                            logger.debug("Parsed line: %s", line)
                        except ValueError:
                            logger.error("Could not parse line %s", line)
            process.kill()

            # Check pending jobs via squeue to get reasons
            pending_ids = [
                jid for jid, js in self.jobs.items() if js.slurm_state == "PENDING"
            ]
            if pending_ids:
                self._check_pending_reasons(pending_ids)

            self.last_check_time = datetime.now()

            # Notify async waiters for finished jobs
            self._notify_async_waiters()

            with self.cv:
                logger.debug("Jobs %s", self.jobs)
                self.fetched_event.set()
                self.cv.notify_all()

            # Notify async waiters for first fetch (outside cv lock)
            self._notify_async_fetched_waiters()

            with self.cv:
                self.cv.wait_for(
                    lambda: self.count == 0, timeout=self.launcher.interval
                )

            # Check if we should stop - grace period allows reuse
            if self.count == 0:
                # Wait one more interval before stopping, allowing other
                # callers to reuse this watcher
                logger.debug(
                    "SLURM watcher has no holders, entering grace period (%s)",
                    self.launcher.key,
                )
                with self.cv:
                    self.cv.wait_for(
                        lambda: self.count > 0, timeout=self.launcher.interval
                    )

                if self.count == 0:
                    with SlurmProcessWatcher.WATCHERS_LOCK:
                        with self.cv:
                            if self.count == 0:
                                logger.debug(
                                    "Stopping SLURM watcher process (%s)",
                                    self.launcher.key,
                                )
                                del SlurmProcessWatcher.WATCHERS[self.launcher.key]
                                break


class BatchSlurmProcess(Process):
    """A batch slurm process"""

    def __init__(
        self, launcher: "SlurmLauncher", jobid: str, *, hold_watcher: bool = False
    ):
        self.launcher = launcher
        self.jobid = jobid
        self._last_state: Optional[SlurmJobState] = None
        self._watcher: Optional[SlurmProcessWatcher] = None

        # Optionally acquire a watcher reference to keep it alive
        if hold_watcher:
            self._watcher = SlurmProcessWatcher.acquire(launcher)

    def _release_watcher(self):
        """Release the held watcher reference if any."""
        if self._watcher is not None:
            SlurmProcessWatcher.release(self._watcher)
            self._watcher = None

    def __del__(self):
        # Ensure watcher is released if process is garbage collected
        self._release_watcher()

    def wait(self):
        try:
            with SlurmProcessWatcher.get(self.launcher) as watcher:
                while True:
                    state = watcher.getjob(self.jobid)
                    if state and state.finished():
                        self._last_state = state
                        return 0 if state.slurm_state == "COMPLETED" else 1
        finally:
            # Release held watcher when wait completes
            self._release_watcher()

    async def aio_wait(self) -> int:
        """Asynchronously wait for SLURM job to finish (event-driven)"""
        logger.debug("Async waiting for SLURM job %s", self.jobid)
        loop = asyncio.get_running_loop()

        try:
            with SlurmProcessWatcher.get(self.launcher) as watcher:
                # Check if already finished (async to avoid blocking on first fetch)
                state = await watcher.aio_getjob(self.jobid)
                if state and state.finished():
                    self._last_state = state
                    return 0 if state.slurm_state == "COMPLETED" else 1

                # Register and wait for the job to finish
                future = watcher.register_async_waiter(self.jobid, loop)
                self._last_state = await future

                code = 0 if self._last_state.slurm_state == "COMPLETED" else 1
                logger.debug(
                    "Finished async wait for SLURM job %s: code %s", self.jobid, code
                )
                return code
        finally:
            # Release held watcher when wait completes
            self._release_watcher()

    def get_job_state(self, code: int) -> "JobState":
        """Convert SLURM exit code to JobState, detecting timeouts"""
        from experimaestro.scheduler.jobs import (
            JobState,
            JobStateError,
            JobFailureStatus,
        )

        if code == 0:
            return JobState.DONE

        # Check if this was a SLURM timeout
        if self._last_state and self._last_state.slurm_state == "TIMEOUT":
            logger.info("SLURM job %s timed out", self.jobid)
            return JobStateError(JobFailureStatus.TIMEOUT)

        # Check if job was rejected due to fatal pending reason
        if self._last_state and (
            failure_status := SlurmJobState.get_failure_status(self._last_state.reason)
        ):
            logger.info(
                "SLURM job %s rejected (reason: %s, status: %s)",
                self.jobid,
                self._last_state.reason,
                failure_status.name,
            )
            return JobStateError(failure_status)

        return JobState.ERROR

    async def aio_state(self, timeout: float | None = None) -> ProcessState:
        # Get watcher - either use held one or acquire temporarily
        if self._watcher is not None:
            watcher = self._watcher
            release_after = False
        else:
            watcher = SlurmProcessWatcher.acquire(self.launcher)
            release_after = True

        try:
            jobinfo = await watcher.aio_getjob(self.jobid)
            return jobinfo.state if jobinfo else ProcessState.SCHEDULED
        finally:
            if release_after:
                SlurmProcessWatcher.release(watcher)

    async def aio_wait_until_running(self) -> ProcessState:
        """Wait until the job transitions from SCHEDULED to RUNNING (or finishes).

        Uses the SLURM watcher's event-driven notification instead of polling.
        Returns the new ProcessState (RUNNING or a finished state).
        """
        loop = asyncio.get_running_loop()

        with SlurmProcessWatcher.get(self.launcher) as watcher:
            while True:
                # Check current state
                jobinfo = await watcher.aio_getjob(self.jobid)
                if jobinfo:
                    if jobinfo.state != ProcessState.SCHEDULED:
                        return jobinfo.state
                else:
                    # Job not found yet, wait for next update
                    pass

                # Register for state change notification and wait
                future = watcher.register_async_state_waiter(self.jobid, loop)
                await future

    def kill(self):
        logger.warning("Killing slurm job %s", self.jobid)
        builder = self.launcher.connector.processbuilder()
        builder.command = [f"{self.launcher.binpath}/scancel", f"{self.jobid}"]
        builder.start()

    @property
    def last_state_check(self) -> datetime | None:
        """Returns the time of the last SLURM state check"""
        if self._watcher is not None:
            return self._watcher.last_check_time
        return None

    def __repr__(self):
        return f"slurm:{self.jobid}"

    def tospec(self):
        return {"type": "slurm", "pid": self.jobid, "options": self.launcher.key}

    @classmethod
    def fromspec(cls, connector: Connector, spec: Dict[str, Any]):
        options = {k: v for k, v in spec.get("options", ())}
        launcher = SlurmLauncher(connector=connector, **options)

        # Create process with hold_watcher=True to keep watcher alive
        # until wait/aio_wait completes
        process = BatchSlurmProcess(launcher, spec["pid"], hold_watcher=True)

        # Check that the process is running (watcher is already held by process)
        # Use wait_for_update=False to get cached data immediately
        logger.debug("Checking SLURM job %s", process.jobid)
        jobinfo = process._watcher.getjob(process.jobid, wait_for_update=False)
        if jobinfo and jobinfo.state.running:
            logger.debug("SLURM job is running (%s), returning process", process.jobid)
            return process

        # Job not running, release the watcher and return None
        process._release_watcher()
        return None


def addstream(command: List[str], option: str, redirect: Redirect):
    if redirect.type == RedirectType.FILE:
        command.extend([option, redirect.path])
    elif redirect.type == RedirectType.INHERIT:
        pass
    else:
        raise NotImplementedError("For %s", redirect)


class SlurmProcessBuilder(ProcessBuilder):
    def __init__(self, launcher: "SlurmLauncher"):
        super().__init__()
        self.launcher = launcher
        # SLURM should always use sbatch (detach=True) by default,
        # even in test mode, since sbatch is the normal submission path
        self.detach = True

    def start(self, task_mode: bool = False) -> BatchSlurmProcess:
        """Start the process"""
        builder = self.launcher.connector.processbuilder()
        builder.environ = self.launcher.launcherenv
        builder.detach = False

        if not self.detach:
            # Simplest case: we wait for the output
            builder.workingDirectory = self.workingDirectory
            builder.command = [f"{self.launcher.binpath}/srun"]
            builder.command.extend(self.launcher.options.args())
            builder.command.extend(self.command)
            builder.stdin = self.stdin
            builder.stdout = self.stdout
            builder.stderr = self.stderr
            builder.environ = self.environ
            builder.detach = False
            return builder.start()

        builder.command = [f"{self.launcher.binpath}/sbatch", "--parsable"]

        if not task_mode:
            # Use command line parameters when not running a task
            builder.command.extend(self.launcher.options.args())

            if self.workingDirectory:
                workdir = self.launcher.connector.resolve(self.workingDirectory)
                builder.command.append(f"--chdir={workdir}")
            addstream(builder.command, "-e", self.stderr)
            addstream(builder.command, "-o", self.stdout)
            addstream(builder.command, "-i", self.stdin)

        builder.command.extend(self.command)
        logger.info(
            "slurm sbatch command: %s", " ".join(f'"{s}"' for s in builder.command)
        )
        handler = OutputCaptureHandler()
        builder.stdout = Redirect.pipe(handler)
        builder.stderr = Redirect.inherit()
        p = builder.start()
        if p.wait() != 0:
            logger.error("Error while running sbatch command")
            raise RuntimeError("Error while submitting job")

        output = handler.output.decode("utf-8").strip(" \n")
        RE_SUBMITTED_JOB = re.compile(r"""^(\d+)(?:;.*)?$""", re.MULTILINE)
        m = RE_SUBMITTED_JOB.match(output)
        if m is None:
            raise RuntimeError(f"Could not get the submitted job ID from {output}")

        return BatchSlurmProcess(self.launcher, m.group(1))


@dataclass
class SlurmOptions:
    # Options
    nodes: Optional[int] = 1
    """Number of requested nodes"""

    time: Optional[str] = None
    """Requested time"""

    account: Optional[str] = None
    """The account for launching the job"""

    qos: Optional[str] = None
    """The requested Quality of Service"""

    partition: Optional[str] = None
    """The requested partition"""

    constraint: Optional[str] = None
    """Logic expression on node features (as defined by the administator)"""

    mem: Optional[str] = None
    """Requested memory on the node (in megabytes by default)"""

    exclude: Optional[str] = None
    """List of hosts to exclude"""

    mem_per_gpu: Optional[str] = None
    """Requested memory per allocated GPU (size with units: K, M, G, or T)"""

    cpus_per_task: Optional[str] = None
    """Number of cpus requested per task"""

    nodelist: Optional[str] = None
    """Request a specific list of hosts"""

    # GPU-related
    gpus: Optional[int] = None
    """Number of GPUs"""

    gpus_per_node: Optional[int] = None
    """Number of GPUs per node"""

    def args(self) -> List[str]:
        """Returns the corresponding options"""
        options = []
        for key in get_type_hints(SlurmOptions).keys():
            value = getattr(self, key, None)
            if value is not None:
                options.append(
                    f"""--{key.replace("_", "-")}={value}""",
                )

        return options

    def merge(self, other: "SlurmOptions"):
        merged = SlurmOptions()

        for key, value in self.__dict__.items():
            setattr(merged, key, value)

        for key, value in other.__dict__.items():
            if value is not None:
                setattr(merged, key, value)

        return merged

    @staticmethod
    def format_time(duration_s: int):
        """Format time for the SLURM option

        :param duration_s: Time duration in seconds1
        :return: The configuration string
        """
        seconds = duration_s % 60
        minutes = (duration_s // 60) % 60
        hours = duration_s // 3600
        return f"{hours}:{minutes}:{seconds}"


class SlurmLauncher(Launcher):
    """Slurm workload manager launcher

    https://slurm.schedmd.com/documentation.html
    """

    def __init__(
        self,
        *,
        connector: Connector = None,
        options: SlurmOptions = None,
        interval: float = 60,
        main=None,
        launcherenv: Dict[str, str] = None,
        binpath="/usr/bin",
    ):
        """
        Arguments:
            main: Main slurm launcher to avoid launching too many polling jobs
            interval: seconds between polling job statuses
        """
        super().__init__(connector or LocalConnector.instance())
        self.binpath = Path(binpath)
        self.interval = interval
        self.launcherenv = launcherenv
        self.options = options or SlurmOptions()

    def __str__(self):
        return f"SlurmLauncher({self.options}, path={self.binpath})"

    @staticmethod
    def init_registry(registry: LauncherRegistry):
        from .configuration import SlurmConfiguration

        registry.register_launcher("slurm", SlurmConfiguration)

    @staticmethod
    def get_cli():
        from .cli import cli

        return cli

    @cached_property
    def key(self):
        """Returns a dictionary characterizing this launcher when calling sacct/etc"""
        return (
            ("binpath", str(self.binpath)),
            ("interval", self.interval),
        )

    def config(self, **kwargs):
        """Returns a new Slurm launcher with the given configuration"""
        return SlurmLauncher(
            connector=self.connector,
            binpath=self.binpath,
            launcherenv=self.launcherenv,
            options=self.options.merge(SlurmOptions(**kwargs)),
            interval=self.interval,
        )

    def scriptbuilder(self):
        """Returns the script builder

        We assume Unix, but should be changed to PythonScriptBuilder when working
        """
        return SlurmScriptBuilder(self)

    def processbuilder(self) -> SlurmProcessBuilder:
        """Returns the process builder for this launcher

        By default, returns the associated connector builder"""
        return SlurmProcessBuilder(self)

    def launcher_info_code(self) -> str:
        """Returns Python code to set up launcher info during task execution."""
        return (
            "    from experimaestro.launchers.slurm import SlurmLauncherInformation\n"
            "    from experimaestro import taskglobals\n"
            f'    taskglobals.Env.instance().launcher_info = SlurmLauncherInformation(binpath="{self.binpath}")\n'
        )


class SlurmScriptBuilder(PythonScriptBuilder):
    def __init__(self, launcher: SlurmLauncher, pythonpath=None):
        super().__init__(pythonpath)
        self.launcher = launcher
        self.processtype = "slurm"

    def write(self, job):
        py_path = super().write(job)
        main_path = py_path.parent

        def relpath(path: Path):
            return shquote(self.launcher.connector.resolve(path, main_path))

        # Writes the sbatch shell script containing all the options
        sh_path = job.jobpath / ("%s.sh" % job.name)
        with sh_path.open("wt") as out:
            out.write("""#!/bin/sh\n\n""")

            workdir = self.launcher.connector.resolve(main_path)
            out.write(f"#SBATCH --chdir={shquote(workdir)}\n")
            out.write(f"""#SBATCH --error={relpath(job.stderr)}\n""")
            out.write(f"""#SBATCH --output={relpath(job.stdout)}\n""")

            for arg in self.launcher.options.args():
                out.write(f"""#SBATCH {arg}\n""")

            # We finish by the call to srun
            out.write(f"""\nsrun ./{relpath(py_path)}\n\n""")

        self.launcher.connector.setExecutable(sh_path, True)
        return sh_path
