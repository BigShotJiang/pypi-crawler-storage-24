from __future__ import annotations

import sys
import unittest
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from brightree.exceptions import BrightreeException
from brightree.services import CustomField, Doctor, Patient, SalesOrder, Security
from brightree.services.base import default_config


class SoapFault(Exception):
    def __init__(self, message: str, code: int, detail: dict) -> None:
        super().__init__(message)
        self.message = message
        self.code = code
        self.detail = detail


class FakeSoapClient:
    def __init__(self, **kwargs) -> None:
        self.kwargs = kwargs

    def call(self, method, params):
        return {"method": method, "params": params}


class FaultingSoapClient(FakeSoapClient):
    def call(self, method, params):
        raise SoapFault("Remote failure", 503, {"method": method})


def info_for(service_name: str) -> dict:
    return {
        "username": "testuser",
        "password": "testpass",
        "config": {"service": {service_name: f"https://example.com/{service_name}"}},
    }


class ServiceTest(unittest.TestCase):
    def test_default_config_contains_known_services(self) -> None:
        config = default_config()
        self.assertIn("service", config)
        self.assertIn("patient", config["service"])
        self.assertIn("doctor", config["service"])
        self.assertEqual(
            config["service"]["patient"],
            "https://webservices.brightree.net/v0100-2410/OrderEntryService/patientservice.svc",
        )
        self.assertEqual(
            config["service"]["salesorder"],
            "https://webservices.brightree.net/v0100-2408/OrderEntryService/SalesOrderService.svc",
        )
        self.assertEqual(
            config["service"]["security"],
            "https://webservices.brightree.net/v0100-2407/SecurityService/UserSecurityService.svc",
        )

    def test_constructor_requires_credentials(self) -> None:
        with self.assertRaises(BrightreeException) as ctx:
            CustomField({"config": {"service": {"custom": "https://example.com/custom"}}})
        self.assertEqual(ctx.exception.code, 1001)
        self.assertIn("Authentication credentials not provided", str(ctx.exception))

    def test_custom_field_fetch_by_category(self) -> None:
        service = CustomField(info_for("custom"), client_factory=FakeSoapClient)
        result = service.CustomFieldFetchAllByCategory("Patient", 1)
        self.assertEqual(
            result,
            {
                "method": "CustomFieldFetchAllByCategory",
                "params": {"category": "Patient", "includeInactive": 1},
            },
        )

    def test_magic_call_with_standard_query_method(self) -> None:
        service = Doctor(info_for("doctor"), client_factory=FakeSoapClient)
        result = service.DoctorSearch({"lastName": "Smith"})
        self.assertEqual(result["method"], "DoctorSearch")
        self.assertEqual(result["params"], {"lastName": "Smith"})

    def test_magic_call_with_special_method(self) -> None:
        service = Doctor(info_for("doctor"), client_factory=FakeSoapClient)
        result = service.DoctorFetchByExternalID(12345)
        self.assertEqual(result["params"], {"ExternalID": 12345})

    def test_magic_call_without_query_uses_empty_payload(self) -> None:
        service = Security(info_for("security"), client_factory=FakeSoapClient)
        result = service.UserGroupFetchAll()
        self.assertEqual(result["method"], "UserGroupFetchAll")
        self.assertEqual(result["params"], {})

    def test_missing_special_method_argument_raises_param_error(self) -> None:
        service = Doctor(info_for("doctor"), client_factory=FakeSoapClient)
        with self.assertRaises(BrightreeException) as ctx:
            service.DoctorFetchByExternalID()
        self.assertEqual(ctx.exception.code, 1002)
        self.assertIn("ExternalID", str(ctx.exception))

    def test_non_existent_method_raises_attribute_error(self) -> None:
        service = Doctor(info_for("doctor"), client_factory=FakeSoapClient)
        with self.assertRaises(AttributeError):
            service.NonExistentMethod()

    def test_patient_search_requires_iterable(self) -> None:
        service = Patient(info_for("patient"), client_factory=FakeSoapClient)
        with self.assertRaises(BrightreeException) as ctx:
            service.PatientSearch("not-an-array")
        self.assertEqual(ctx.exception.code, 1002)
        self.assertIn("Method PatientSearch requires an iterable parameter", str(ctx.exception))

    def test_patient_fetch_validates_brightree_id(self) -> None:
        service = Patient(info_for("patient"), client_factory=FakeSoapClient)
        with self.assertRaises(BrightreeException) as ctx:
            service.PatientFetchByBrightreeID(0)
        self.assertEqual(ctx.exception.code, 1003)
        self.assertIn("Invalid Brightree ID: 0", str(ctx.exception))

    def test_fetch_patient_opt_in_status(self) -> None:
        service = Patient(info_for("patient"), client_factory=FakeSoapClient)
        result = service.fetch_patient_opt_in_status(12345, "5551234567")
        self.assertEqual(result["method"], "FetchPatientOptInStatus")
        self.assertEqual(result["params"], {"brightreeId": 12345, "patientPhone": "5551234567"})

    def test_fetch_patient_opt_in_status_validates_inputs(self) -> None:
        service = Patient(info_for("patient"), client_factory=FakeSoapClient)
        with self.assertRaises(BrightreeException) as ctx:
            service.fetch_patient_opt_in_status(0, "5551234567")
        self.assertEqual(ctx.exception.code, 1003)
        self.assertIn("Invalid Brightree ID: 0", str(ctx.exception))

        with self.assertRaises(BrightreeException) as ctx:
            service.fetch_patient_opt_in_status(12345, "")
        self.assertEqual(ctx.exception.code, 1003)
        self.assertIn("patient_phone must be non-empty", str(ctx.exception))

    def test_update_patient_opt_in_status_accepts_dict_and_object_payloads(self) -> None:
        service = Patient(info_for("patient"), client_factory=FakeSoapClient)

        dict_result = service.update_patient_opt_in_status({"Status": True})
        self.assertEqual(
            dict_result["params"],
            {"patientOptInStatus": {"Status": True}},
        )

        object_result = service.update_patient_opt_in_status(SimpleNamespace(Status=False))
        self.assertEqual(
            object_result["params"],
            {"patientOptInStatus": {"Status": False}},
        )

    def test_update_patient_opt_in_status_validates_payload(self) -> None:
        service = Patient(info_for("patient"), client_factory=FakeSoapClient)
        with self.assertRaises(BrightreeException) as ctx:
            service.update_patient_opt_in_status("invalid")
        self.assertEqual(ctx.exception.code, 1003)
        self.assertIn("patient_opt_in_status must be a dict or object-like payload", str(ctx.exception))

    def test_additional_patient_contact_methods(self) -> None:
        service = Patient(info_for("patient"), client_factory=FakeSoapClient)

        create_result = service.additional_patient_contact_create({"Name": "Jane"})
        self.assertEqual(create_result["method"], "AdditionalPatientContactCreate")
        self.assertEqual(create_result["params"], {"AdditionalPatientContact": {"Name": "Jane"}})

        fetch_result = service.additional_patient_contact_fetch_by_brightree_id("12345")
        self.assertEqual(fetch_result["method"], "AdditionalPatientContactFetchByBrightreeID")
        self.assertEqual(fetch_result["params"], {"PatientBrightreeID": "12345"})

        update_result = service.additional_patient_contact_update(55, SimpleNamespace(Name="Jane Updated"))
        self.assertEqual(update_result["method"], "AdditionalPatientContactUpdate")
        self.assertEqual(
            update_result["params"],
            {"BrightreePatientContactKey": 55, "AdditionalPatientContact": {"Name": "Jane Updated"}},
        )

    def test_additional_patient_contact_methods_validate_inputs(self) -> None:
        service = Patient(info_for("patient"), client_factory=FakeSoapClient)

        with self.assertRaises(BrightreeException) as ctx:
            service.additional_patient_contact_create("invalid")
        self.assertEqual(ctx.exception.code, 1003)
        self.assertIn("additional_patient_contact must be a dict or object-like payload", str(ctx.exception))

        with self.assertRaises(BrightreeException) as ctx:
            service.additional_patient_contact_fetch_by_brightree_id("")
        self.assertEqual(ctx.exception.code, 1003)
        self.assertIn("patient_brightree_id must be non-empty", str(ctx.exception))

        with self.assertRaises(BrightreeException) as ctx:
            service.additional_patient_contact_update(0, {"Name": "Jane"})
        self.assertEqual(ctx.exception.code, 1003)
        self.assertIn("Invalid BrightreePatientContactKey: 0", str(ctx.exception))

    def test_sales_order_fetch_requires_brightree_id_field(self) -> None:
        service = SalesOrder(info_for("salesorder"), client_factory=FakeSoapClient)
        with self.assertRaises(BrightreeException) as ctx:
            service.SalesOrderFetchByBrightreeID({})
        self.assertEqual(ctx.exception.code, 1003)
        self.assertIn("BrightreeID is required for SalesOrderFetchByBrightreeID", str(ctx.exception))

    def test_sales_order_patient_note_comment_fetch_aliases(self) -> None:
        service = SalesOrder(info_for("salesorder"), client_factory=FakeSoapClient)
        plural_result = service.patient_notes_comment_fetch(44)
        alias_result = service.patient_note_comment_fetch(44)
        direct_result = service.PatientNoteCommentFetch(44)
        query_result = service.PatientNoteCommentFetch({"PatientNoteKey": 44})

        self.assertEqual(plural_result["method"], "PatientNoteCommentFetch")
        self.assertEqual(plural_result["params"], {"PatientNoteKey": 44})
        self.assertEqual(alias_result["params"], {"PatientNoteKey": 44})
        self.assertEqual(direct_result["params"], {"PatientNoteKey": 44})
        self.assertEqual(query_result["params"], {"PatientNoteKey": 44})

    def test_sales_order_new_passthrough_methods(self) -> None:
        service = SalesOrder(info_for("salesorder"), client_factory=FakeSoapClient)
        quick_add_payload = {"SalesOrderBrightreeID": 123, "Items": [{"Item": "A"}]}
        payor_payload = {"TemplateKey": 9, "Payor": {"ID": 2}}

        quick_add_result = service.sales_order_quick_add_item_with_items_data_return(quick_add_payload)
        payor_result = service.sales_order_template_update_item_payor(payor_payload)

        self.assertEqual(quick_add_result["method"], "SalesOrderQuickAddItemWithItemsDataReturn")
        self.assertEqual(quick_add_result["params"], quick_add_payload)
        self.assertEqual(payor_result["method"], "SalesOrderTemplateUpdateItemPayor")
        self.assertEqual(payor_result["params"], payor_payload)

    def test_security_user_group_bdm_permissions_methods(self) -> None:
        service = Security(info_for("security"), client_factory=FakeSoapClient)

        fetch_result = service.user_group_bdm_permissions_fetch_by_user_group_brightree_id(77)
        self.assertEqual(fetch_result["method"], "UserGroupBDMPermissionsFetchByUserGroupBrightreeID")
        self.assertEqual(fetch_result["params"], {"UserGroupBrightreeID": 77})

        dict_result = service.user_group_bdm_permissions_update(77, {"CanEdit": True})
        self.assertEqual(
            dict_result["params"],
            {"UserGroupBrightreeID": 77, "UserGroupBDMPermissions": {"CanEdit": True}},
        )

        object_result = service.user_group_bdm_permissions_update(77, SimpleNamespace(CanEdit=False))
        self.assertEqual(
            object_result["params"],
            {"UserGroupBrightreeID": 77, "UserGroupBDMPermissions": {"CanEdit": False}},
        )

    def test_security_user_group_bdm_permissions_update_validates_payload(self) -> None:
        service = Security(info_for("security"), client_factory=FakeSoapClient)
        with self.assertRaises(BrightreeException) as ctx:
            service.user_group_bdm_permissions_update(77, "invalid")
        self.assertEqual(ctx.exception.code, 1003)
        self.assertIn("user_group_bdm_permissions must be a dict or object-like payload", str(ctx.exception))

    def test_soap_faults_are_wrapped_with_request_context(self) -> None:
        service = Doctor(info_for("doctor"), client_factory=FaultingSoapClient)
        with self.assertRaises(BrightreeException) as ctx:
            service.DoctorSearch({"lastName": "Smith"})

        self.assertEqual(ctx.exception.code, 503)
        self.assertEqual(str(ctx.exception), "Remote failure")
        self.assertEqual(
            ctx.exception.request_data,
            {"method": "DoctorSearch", "params": {"lastName": "Smith"}},
        )
        self.assertEqual(ctx.exception.error_data, {"method": "DoctorSearch"})

    def test_api_response_exception_extracts_nested_error(self) -> None:
        response = SimpleNamespace(Error=SimpleNamespace(Message="Bad payload", Code=422))
        exception = BrightreeException.from_api_response(response, request_data={"method": "DoctorCreate"})
        self.assertEqual(str(exception), "Bad payload")
        self.assertEqual(exception.code, 422)
        self.assertIs(exception.error_data, response)
        self.assertEqual(exception.request_data, {"method": "DoctorCreate"})


if __name__ == "__main__":
    unittest.main()
