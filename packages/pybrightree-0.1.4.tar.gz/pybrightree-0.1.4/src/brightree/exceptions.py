from __future__ import annotations


class BrightreeException(Exception):
    def __init__(
        self,
        message: str,
        code: int = 0,
        *,
        error_data=None,
        request_data=None,
        previous: Exception | None = None,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.error_data = error_data
        self.request_data = request_data
        self.previous = previous

    @classmethod
    def from_soap_fault(cls, fault: Exception, request_data=None) -> "BrightreeException":
        message = getattr(fault, "message", str(fault))
        code = getattr(fault, "code", 0) or 0
        detail = getattr(fault, "detail", None)
        return cls(message, code, error_data=detail, request_data=request_data, previous=fault)

    @classmethod
    def from_api_response(cls, response, request_data=None) -> "BrightreeException":
        message = "API Error"
        code = 0
        error = getattr(response, "Error", None)
        if error is not None:
            message = getattr(error, "Message", message)
            code = getattr(error, "Code", code) or 0
        return cls(message, code, error_data=response, request_data=request_data)

    @classmethod
    def config_error(cls, message: str) -> "BrightreeException":
        return cls(f"Configuration Error: {message}", 1000)

    @classmethod
    def auth_error(cls, message: str = "Authentication failed") -> "BrightreeException":
        return cls(f"Authentication Error: {message}", 1001)

    @classmethod
    def param_error(cls, method: str, param: str) -> "BrightreeException":
        return cls(f"Parameter Error: Required parameter '{param}' missing for method '{method}'", 1002)
