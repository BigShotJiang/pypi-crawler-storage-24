from __future__ import annotations

from ..exceptions import BrightreeException
from .base import BaseService


class Pricing(BaseService):
    methods = {
        "CMNFormFetchAll": True,
        "NonTaxReasonFetchAll": True,
        "PriceCreateItem": True,
        "PriceCreateStandard": True,
        "PriceDetailCreate": True,
        "PriceDetailFetchByBrightreeDetailID": True,
        "PriceDetailUpdate": True,
        "PriceFetch": True,
        "PriceOptionLetterTypeFetchAll": True,
        "PriceTableFetchAll": True,
        "Ping": False,
    }

    def PriceCreateItem(self, query):
        return self._call_with_query("PriceCreateItem", query)

    def PriceDetailFetchByBrightreeDetailID(self, query):
        self._ensure_iterable("PriceDetailFetchByBrightreeDetailID", query)
        if "BrightreeDetailID" not in query:
            raise BrightreeException("BrightreeDetailID is required for PriceDetailFetchByBrightreeDetailID", 1003)
        return self._api_call("PriceDetailFetchByBrightreeDetailID", dict(query))

    def Ping(self):
        return self._api_call("Ping", {})
