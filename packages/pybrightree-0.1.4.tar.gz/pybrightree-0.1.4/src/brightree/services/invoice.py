from __future__ import annotations

from ..exceptions import BrightreeException
from .base import BaseService


class Invoice(BaseService):
    methods = {
        "InvoiceItemUpdate": True,
        "InvoiceUpdate": True,
        "ResubmitInvoices": True,
    }
    special_methods = {
        "InvoiceCreatePrintActivity": ("BrightreeID",),
        "InvoiceFetchByBrightreeID": ("BrightreeID",),
        "InvoiceFetchByInvoiceID": ("InvoiceID",),
        "OpenInvoiceAgedBalanceFetchByPatient": ("PatientBrightreeID",),
        "OpenInvoiceBalanceFetchByPatient": ("PatientBrightreeID",),
    }

    def InvoiceFetchByBrightreeID(self, brightree_id: int):
        if brightree_id <= 0:
            raise BrightreeException(f"Invalid Brightree ID: {brightree_id}", 1003)
        return self._api_call("InvoiceFetchByBrightreeID", {"BrightreeID": brightree_id})

    def InvoiceFetchByInvoiceID(self, invoice_id: int):
        if invoice_id <= 0:
            raise BrightreeException(f"Invalid Invoice ID: {invoice_id}", 1003)
        return self._api_call("InvoiceFetchByInvoiceID", {"InvoiceID": invoice_id})

    def OpenInvoiceBalanceFetchByPatient(self, brightree_id: int):
        if brightree_id <= 0:
            raise BrightreeException(f"Invalid Patient Brightree ID: {brightree_id}", 1003)
        return self._api_call("OpenInvoiceBalanceFetchByPatient", {"PatientBrightreeID": brightree_id})
