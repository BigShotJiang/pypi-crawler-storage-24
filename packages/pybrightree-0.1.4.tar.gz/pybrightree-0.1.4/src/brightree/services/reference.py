from __future__ import annotations

from ..exceptions import BrightreeException
from .base import BaseService


class Reference(BaseService):
    methods = {
        "AccountGroupFetchAll": False,
        "AddFacilityReferralContact": True,
        "BranchInfoFetchAll": False,
        "BranchInfoFetchByBrightreeID": True,
        "ClaimNoteTypeFetchAll": False,
        "ContactTypeCreate": True,
        "ContactTypeDelete": True,
        "ContactTypeFetchAll": False,
        "ContactTypeFetchByBrightreeID": True,
        "ContactTypeUpdate": True,
        "DeliveryTechnicianFetchAll": False,
        "DepreciationTypesFetchAll": False,
        "EPSDTConditionCodeFetchAll": False,
        "FacilityCreate": True,
        "FacilityDelete": True,
        "FacilityFetchByBrightreeID": True,
        "FacilityFetchByExternalID": True,
        "FacilityInfoFetchAll": False,
        "FacilityReferralContactsFetchByFacilityKey": True,
        "FacilityUpdate": True,
        "FetchCurrentSecUser": False,
        "FunctionalAssessmentFetchAll": False,
        "GLAccountGroupsFetchAll": False,
        "ItemGroupFetchAll": False,
        "ItemManufacturerFetchAll": False,
        "ItemStatusFetchAll": False,
        "ItemTypesFetchAll": False,
        "LocationInfoFetchAll": False,
        "MarketingRepFetchAll": False,
        "MarketingRepFetchByBrightreeID": True,
        "MarketingRepFetchByExternalID": True,
        "MarketingRepUpdateExternalID": True,
        "MSPInsTypeFetchAll": False,
        "PatientNoteReasonFetchAll": False,
        "PlaceOfServiceFetchAll": False,
        "PolicyClaimCodeFetchAll": False,
        "PolicyTypeCodeFetchAll": False,
        "PractitionerInfoFetchAll": False,
        "ReferralContactCreate": True,
        "ReferralContactFetchByBrightreeID": True,
        "ReferralContactFetchByExternalID": True,
        "ReferralContactSearch": True,
        "ReferralContactUpdate": True,
        "ReferralFetchByBrightreeID": True,
        "ReferralSearch": True,
        "RemoveFacilityReferralContact": True,
        "SalesOrderClassificationFetchAll": False,
        "SalesOrderManualHoldReasonFetchAll": False,
        "SalesOrderVoidReasonFetchAll": False,
        "SalesTypesFetchAll": False,
        "SecUsersFetchAll": False,
        "ShippingCarriersFetchAll": False,
        "SiteInfoFetch": True,
        "TaxZoneFetchAll": False,
        "VendorFetchByBrightreeID": True,
        "VendorsFetchAll": False,
        "WIPStatesFetchAll": False,
    }

    def FacilityFetchByBrightreeID(self, query):
        self._ensure_iterable("FacilityFetchByBrightreeID", query)
        if "BrightreeID" not in query:
            raise BrightreeException("BrightreeID is required for FacilityFetchByBrightreeID", 1003)
        return self._api_call("FacilityFetchByBrightreeID", dict(query))

    def ReferralContactSearch(self, query):
        return self._call_with_query("ReferralContactSearch", query)

    def SecUsersFetchAll(self):
        return self._api_call("SecUsersFetchAll", {})
