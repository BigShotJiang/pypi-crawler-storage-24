from __future__ import annotations

from ..exceptions import BrightreeException
from .base import BaseService


class SalesOrder(BaseService):
    methods = {
        "BrightSHIPSalesOrderAck": True,
        "BrightShipSalesOrderFetch": True,
        "OrderImport": True,
        "SalesOrderAddDeliveryException": True,
        "SalesOrderAddMarketingReferral": True,
        "SalesOrderConfirm": True,
        "SalesOrderCreate": True,
        "SalesOrderEvaluateDropShip": True,
        "SalesOrderEvaluateDropShipWithAccountNumber": True,
        "SalesOrderFetchByBrightreeID": True,
        "SalesOrderFetchByExternalID": True,
        "SalesOrderFetchByPurchaseOrderID": True,
        "SalesOrderFetchPendingByShippingCarrierKey": True,
        "SalesOrderFetchReadyforShipping": True,
        "SalesOrderFulfillmentVendorsFetchAll": False,
        "SalesOrderItemAddDeliveryException": True,
        "SalesOrderItemPriceOptionFetchByBrightreeID": True,
        "SalesOrderItemReplaceGeneric": True,
        "SalesOrderItemUpdateLotNumbers": True,
        "SalesOrderItemUpdatePriceOption": True,
        "SalesOrderItemUpdateSerialNumbers": True,
        "SalesOrderMessagesFetchByBrightreeID": True,
        "SalesOrderOverrideValidationDetailMessage": True,
        "SalesOrderOverrideValidationHeaderMessage": True,
        "SalesOrderPayorSearch": True,
        "SalesOrderQuickAddItem": True,
        "SalesOrderQuickAddItemWithItemsDataReturn": True,
        "SalesOrderRemoveItem": True,
        "SalesOrderRemoveMarketingReferral": True,
        "SalesOrderSearch": True,
        "SalesOrderSendPOD": True,
        "SalesOrderSubmitDropShip": True,
        "SalesOrderTemplateCreate": True,
        "SalesOrderTemplateCreateSalesOrder": True,
        "SalesOrderTemplateDelete": True,
        "SalesOrderTemplateFetchByBrightreeID": True,
        "SalesOrderTemplateFetchByExternalID": True,
        "SalesOrderTemplateItemFrequencyUpdate": True,
        "SalesOrderTemplateItemPriceOptionFetchByBrightreeID": True,
        "SalesOrderTemplateItemUpdatePriceOption": True,
        "SalesOrderTemplateQuickAddItem": True,
        "SalesOrderTemplateRemoveItem": True,
        "SalesOrderTemplateScheduleFetchBySOTemplateKey": True,
        "SalesOrderTemplateScheduleLogSearch": True,
        "SalesOrderTemplateScheduleSearch": True,
        "SalesOrderTemplateScheduleUpdate": True,
        "SalesOrderTemplateSearch": True,
        "SalesOrderTemplateUpdate": True,
        "SalesOrderTemplateUpdateInsurance": True,
        "SalesOrderTemplateUpdateItem": True,
        "SalesOrderTemplateUpdateItemsWithDefaultPriceOption": True,
        "SalesOrderTemplateUpdateItemPayor": True,
        "SalesOrderTemplateUpdateWIPState": True,
        "SalesOrderUpdate": True,
        "SalesOrderUpdateInsurance": True,
        "SalesOrderUpdateItem": True,
        "SalesOrderUpdateItemGeneric": True,
        "SalesOrderUpdateItemNextBilling": True,
        "SalesOrderUpdateItemPayor": True,
        "SalesOrderUpdateItemsWithDefaultPriceOption": True,
        "SalesOrderUpdatePODStatus": True,
        "SalesOrderUpdateTracking": True,
        "SalesOrderUpdateWIPState": True,
        "SalesOrderVoid": True,
        "SalesOrderVoidSearch": True,
        "SearchWIPStatusWithUpdate": True,
        "StopReasonFetchAll": False,
        "StopReasonSalesOrderTemplateUpdate": True,
        "StopReasonSalesOrderUpdate": True,
        "PatientNoteCommentCreate": True,
        "PatientNoteCommentFetch": True,
        "PatientNoteCommentUpdate": True,
    }
    special_methods = {
        "SalesOrderTemplateItemFrequencyFetchByBrightreeID": ("BrightreeID",),
        "StopReasonSalesOrderFetchByBrightreeID": ("BrightreeID",),
        "StopReasonSalesOrderTemplateFetchByBrightreeID": ("BrightreeID",),
    }

    def SalesOrderFetchByBrightreeID(self, query):
        self._ensure_iterable("SalesOrderFetchByBrightreeID", query)
        if "BrightreeID" not in query:
            raise BrightreeException("BrightreeID is required for SalesOrderFetchByBrightreeID", 1003)
        return self._api_call("SalesOrderFetchByBrightreeID", dict(query))

    def SalesOrderTemplateItemFrequencyFetchByBrightreeID(self, brightree_id: int):
        if brightree_id <= 0:
            raise BrightreeException(f"Invalid Brightree ID: {brightree_id}", 1003)
        return self._api_call("SalesOrderTemplateItemFrequencyFetchByBrightreeID", {"BrightreeID": brightree_id})

    def StopReasonSalesOrderFetchByBrightreeID(self, brightree_id: int):
        if brightree_id <= 0:
            raise BrightreeException(f"Invalid Brightree ID: {brightree_id}", 1003)
        return self._api_call("StopReasonSalesOrderFetchByBrightreeID", {"BrightreeID": brightree_id})

    def PatientNoteCommentFetch(self, patient_note_key_or_query):
        if self._is_iterable(patient_note_key_or_query):
            return self._call_with_query("PatientNoteCommentFetch", patient_note_key_or_query)
        return self._api_call("PatientNoteCommentFetch", {"PatientNoteKey": patient_note_key_or_query})

    def patient_notes_comment_fetch(self, patient_note_key):
        return self._api_call("PatientNoteCommentFetch", {"PatientNoteKey": patient_note_key})

    def patient_note_comment_fetch(self, patient_note_key):
        return self.patient_notes_comment_fetch(patient_note_key)

    def sales_order_quick_add_item_with_items_data_return(self, payload):
        return self._call_with_query("SalesOrderQuickAddItemWithItemsDataReturn", payload)

    def sales_order_template_update_item_payor(self, payload):
        return self._call_with_query("SalesOrderTemplateUpdateItemPayor", payload)
