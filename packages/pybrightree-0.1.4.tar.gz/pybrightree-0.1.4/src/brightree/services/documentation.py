from __future__ import annotations

from ..exceptions import BrightreeException
from .base import BaseService


class Documentation(BaseService):
    methods = {
        "CMNCreateFromPatient": True,
        "CMNDetailCreate": True,
        "CMNDetailDelete": True,
        "CMNDetailUpdate": True,
        "CMNFetchByBrightreeID": True,
        "CMNFetchByExternalID": True,
        "CMNFetchByPatientBrightreeID": True,
        "CMNFetchBySalesOrderBrightreeID": True,
        "CMNFrequencyUpdate": True,
        "CMNLog": True,
        "CMNPreview": True,
        "CMNPrint": True,
        "CMNQuestionAnswerConfiguration": True,
        "CMNReasonFetchAll": True,
        "CMNRenew": True,
        "CMNRevise": True,
        "CMNSearch": True,
        "CMNTaskCreate": True,
        "CMNTaskUpdate": True,
        "CMNUpdate": True,
        "PARAddPurchaseLimit": True,
        "PARCreateFromPatient": True,
        "PARDelete": True,
        "PARFetchByBrightreeID": True,
        "PARFetchByExternalID": True,
        "PARFetchByPatientBrightreeID": True,
        "PARFetchBySalesOrderBrightreeID": True,
        "PARFetchBySalesOrderTemplateBrightreeID": True,
        "PARLog": True,
        "PARRenew": True,
        "PARSearch": True,
        "PARTaskCreate": True,
        "PARTaskUpdate": True,
        "PARUpdate": True,
        "PARUpdatePurchaseLimit": True,
        "SalesOrderItemLinkCMN": True,
        "SalesOrderItemLinkNewCMN": True,
        "SalesOrderItemLinkToNewPAR": True,
        "SalesOrderItemLinkToPAR": True,
        "SalesOrderItemsLinkCMN": True,
        "SalesOrderItemsLinkNewCMN": True,
        "SalesOrderItemsLinkToNewPAR": True,
        "SalesOrderItemsLinkToPAR": True,
        "SalesOrderItemsUnlinkCMN": True,
        "SalesOrderItemsUnlinkPAR": True,
        "SalesOrderItemUnlinkCMN": True,
        "SalesOrderItemUnlinkPAR": True,
        "SalesOrderTemplateItemLinkToPAR": True,
        "SalesOrderTemplateItemsLinkToPAR": True,
        "SalesOrderTemplateItemsUnlinkPAR": True,
        "SalesOrderTemplateItemUnlinkPAR": True,
        "SetParticipantComplianceDate": True,
        "PARTaskReasonFetchAll": False,
    }
    special_methods = {
        "CMNFrequencyFetchbyBrightreeID": ("BrightreeID",),
        "PARTaskFetchByPARBrightreeID": ("BrightreeID",),
    }

    def CMNFrequencyFetchbyBrightreeID(self, brightree_id: int):
        if brightree_id <= 0:
            raise BrightreeException(f"Invalid Brightree ID: {brightree_id}", 1003)
        return self._api_call("CMNFrequencyFetchbyBrightreeID", {"BrightreeID": brightree_id})

    def PARTaskFetchByPARBrightreeID(self, par_brightree_id: int):
        if par_brightree_id <= 0:
            raise BrightreeException(f"Invalid PAR Brightree ID: {par_brightree_id}", 1003)
        return self._api_call("PARTaskFetchByPARBrightreeID", {"BrightreeID": par_brightree_id})

    def PARTaskReasonFetchAll(self):
        return self._api_call("PARTaskReasonFetchAll", {})
