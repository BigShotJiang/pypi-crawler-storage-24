from __future__ import annotations

from ..exceptions import BrightreeException
from .base import BaseService


class Insurance(BaseService):
    methods = {
        "InsuranceSearch": True,
        "InsuranceUpdate": True,
        "BranchOfficeInsuranceUpdate": True,
        "BundleBillingRuleSetFetchAll": False,
        "ClaimFormFetchAll": False,
        "CommercialEligibilityPayerSearch": True,
        "CommercialPayerSearch": True,
        "CoverageLimitFetchAll": False,
        "CustomAppealFormFetchAll": False,
        "InsuranceCarrierCodeCreate": True,
        "InsuranceCarrierCodeUpdate": True,
        "InsuranceCompanyFetchAll": False,
        "InsuranceCreate": True,
        "InsuranceGroupFetchAll": False,
        "InsurancePlanTypeFetchAll": False,
        "InsurancePrintedFormsClaimFieldsFetch": False,
        "InsurancePrintedFormsPARFieldsFetch": False,
        "InsuranceSpanDateHoldInclusionCreate": True,
        "InsuranceSpanDateOverrideCreate": True,
        "InsuranceSpanDateOverrideUpdate": True,
        "ItemGroupFetchAll": False,
        "PARFormFetchAll": False,
        "Ping": False,
        "PriceTableSearch": True,
        "SpanDateSplit": True,
    }
    special_methods = {
        "InsuranceFetchByBrightreeID": ("BrightreeID",),
        "InsuranceFetchByExternalID": ("ExternalID",),
        "BranchOfficeInsuranceFetchByBranchBrightreeIDAndInsuranceBrightreeID": (
            "BranchBrightreeID",
            "InsuranceBrightreeID",
        ),
        "FetchPmtSubTypeByPmtTypeBrightreeID": ("PaymentTypeBrightreeID",),
        "InsuranceCarrierCodeDelete": ("BrightreeID",),
        "InsuranceSpanDateHoldInclusionDelete": ("BrightreeID",),
        "InsuranceSpanDateOverrideDelete": ("BrightreeID",),
        "InsuranceValidationRuleSetCreate": ("BranchBrightreeID", "InsuranceBrightreeID"),
        "InsuranceValidationRuleSetDelete": ("BrightreeID",),
        "ItemGroupFetchByInsuranceBrightreeID": ("BrightreeID",),
    }

    def InsuranceFetchByBrightreeID(self, brightree_id: int):
        if brightree_id <= 0:
            raise BrightreeException(f"Invalid Brightree ID: {brightree_id}", 1003)
        return self._api_call("InsuranceFetchByBrightreeID", {"BrightreeID": brightree_id})

    def InsuranceFetchByExternalID(self, external_id: int):
        if external_id <= 0:
            raise BrightreeException(f"Invalid External ID: {external_id}", 1003)
        return self._api_call("InsuranceFetchByExternalID", {"ExternalID": external_id})

    def BranchOfficeInsuranceFetchByBranchBrightreeIDAndInsuranceBrightreeID(
        self,
        branch_brightree_id: int | None = None,
        insurance_brightree_id: int | None = None,
    ):
        if branch_brightree_id is None:
            raise BrightreeException("BranchBrightreeID is required", 1003)
        if insurance_brightree_id is None:
            raise BrightreeException("InsuranceBrightreeID is required", 1003)
        return self._api_call(
            "BranchOfficeInsuranceFetchByBranchBrightreeIDAndInsuranceBrightreeID",
            {
                "BranchBrightreeID": branch_brightree_id,
                "InsuranceBrightreeID": insurance_brightree_id,
            },
        )

    def InsuranceValidationRuleSetCreate(
        self,
        validation_rule_set_brightree_id: int | None = None,
        insurance_brightree_id: int | None = None,
    ):
        if validation_rule_set_brightree_id is None:
            raise BrightreeException("ValidationRuleSetBrightreeID is required", 1003)
        if insurance_brightree_id is None:
            raise BrightreeException("InsuranceBrightreeID is required", 1003)
        return self._api_call(
            "InsuranceValidationRuleSetCreate",
            {
                "ValidationRuleSetBrightreeID": validation_rule_set_brightree_id,
                "InsuranceBrightreeID": insurance_brightree_id,
            },
        )
