from __future__ import annotations

from ..exceptions import BrightreeException
from .base import BaseService


class Patient(BaseService):
    methods = {
        "FacilityMasterInfoFetchAll": False,
        "FacilityResidentCreate": True,
        "PatientCreate": True,
        "PatientSearch": True,
        "PatientUpdate": True,
        "PatientNoteCreate": True,
        "PatientNoteSearch": True,
        "PatientNoteUpdate": True,
        "PatientPayorAdd": True,
        "PatientPayorFetch": True,
        "PatientPayorUpdate": True,
        "PatientPhoneNumberSearch": True,
        "PatientUpdateSleepTherapyPatientID": True,
        "PharmacyPatientClinicalInfoFetchByBrightreeID": True,
        "FetchPatientOptInStatus": True,
        "UpdatePatientOptInStatus": True,
        "AdditionalPatientContactCreate": True,
        "AdditionalPatientContactFetchByBrightreeID": True,
        "AdditionalPatientContactUpdate": True,
    }
    special_methods = {
        "PatientAddMarketingReferral": ("BrightreeID", "BrightreeReferralID"),
        "PatientFetchByExternalID": ("ExternalID",),
        "PatientFetchByPatientID": ("PatientID",),
        "PatientFetchByBrightreeID": ("BrightreeID",),
        "PatientNoteFetchByKey": ("brightreeID",),
        "PatientNoteFetchByPatient": ("brightreeID",),
        "PatientPayorFetchAll": ("PatientKey",),
        "PatientPayorRemove": ("brightreeID",),
        "PatientRemoveMarketingReferral": ("brightreeID",),
        "PharmacyPatientLabResultsFetchByBrightreeIDAndPatientBrightreeID": (
            "BrightreeID",
            "PatientBrightreeID",
        ),
        "PharmacyPatientMedicationHistoryFetchByBrightreeIDAndPatientBrightreeID": (
            "BrightreeID",
            "PatientBrightreeID",
        ),
        "PharmacyPatientMostRecentLabResultsFetchByPatientBrightreeID": ("brightreeID",),
    }

    def PatientFetchByBrightreeID(self, brightree_id: int):
        if brightree_id <= 0:
            raise BrightreeException(f"Invalid Brightree ID: {brightree_id}", 1003)
        return self._api_call("PatientFetchByBrightreeID", {"BrightreeID": brightree_id})

    def PatientAddMarketingReferral(self, brightree_id: int | None = None, referral_id: int | None = None):
        if brightree_id is None:
            raise BrightreeException("BrightreeID is required for PatientAddMarketingReferral", 1003)
        if referral_id is None:
            raise BrightreeException("BrightreeReferralID is required for PatientAddMarketingReferral", 1003)
        return self._api_call(
            "PatientAddMarketingReferral",
            {"BrightreeID": brightree_id, "BrightreeReferralID": referral_id},
        )

    def PatientPayorFetchAll(self, patient_key: int):
        if patient_key <= 0:
            raise BrightreeException(f"Invalid PatientKey: {patient_key}", 1003)
        return self._api_call("PatientPayorFetchAll", {"PatientKey": patient_key})

    def PharmacyPatientLabResultsFetchByBrightreeIDAndPatientBrightreeID(
        self,
        patient_brightree_id: int | None = None,
        brightree_id: int | None = None,
    ):
        if patient_brightree_id is None:
            raise BrightreeException("PatientBrightreeID is required", 1003)
        if brightree_id is None:
            raise BrightreeException("BrightreeID is required", 1003)
        return self._api_call(
            "PharmacyPatientLabResultsFetchByBrightreeIDAndPatientBrightreeID",
            {"BrightreeID": brightree_id, "PatientBrightreeID": patient_brightree_id},
        )

    def fetch_patient_opt_in_status(self, brightree_id: int, patient_phone: str):
        if brightree_id <= 0:
            raise BrightreeException(f"Invalid Brightree ID: {brightree_id}", 1003)
        if not patient_phone:
            raise BrightreeException("patient_phone must be non-empty", 1003)
        return self._api_call(
            "FetchPatientOptInStatus",
            {"brightreeId": brightree_id, "patientPhone": patient_phone},
        )

    def update_patient_opt_in_status(self, patient_opt_in_status):
        payload = self._coerce_payload(patient_opt_in_status, "patient_opt_in_status")
        return self._api_call("UpdatePatientOptInStatus", {"patientOptInStatus": payload})

    def additional_patient_contact_create(self, additional_patient_contact):
        payload = self._coerce_payload(additional_patient_contact, "additional_patient_contact")
        return self._api_call("AdditionalPatientContactCreate", {"AdditionalPatientContact": payload})

    def additional_patient_contact_fetch_by_brightree_id(self, patient_brightree_id):
        if patient_brightree_id in (None, ""):
            raise BrightreeException("patient_brightree_id must be non-empty", 1003)
        return self._api_call(
            "AdditionalPatientContactFetchByBrightreeID",
            {"PatientBrightreeID": str(patient_brightree_id)},
        )

    def additional_patient_contact_update(self, brightree_patient_contact_key: int, additional_patient_contact):
        if brightree_patient_contact_key <= 0:
            raise BrightreeException(
                f"Invalid BrightreePatientContactKey: {brightree_patient_contact_key}",
                1003,
            )
        payload = self._coerce_payload(additional_patient_contact, "additional_patient_contact")
        return self._api_call(
            "AdditionalPatientContactUpdate",
            {
                "BrightreePatientContactKey": int(brightree_patient_contact_key),
                "AdditionalPatientContact": payload,
            },
        )
