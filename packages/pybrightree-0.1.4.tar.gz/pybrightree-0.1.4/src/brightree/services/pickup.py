from __future__ import annotations

from ..exceptions import BrightreeException
from .base import BaseService


class Pickup(BaseService):
    methods = {
        "PickupExchangeAddAllRentalItems": True,
        "PickupExchangeAddDeliveryException": True,
        "PickupExchangeAddPickupItem": True,
        "PickupExchangeCancelPOD": True,
        "PickupExchangeConfirm": True,
        "PickupExchangeCreate": True,
        "PickupExchangeDelete": True,
        "PickupExchangeFetchByBrightreeID": True,
        "PickupExchangeFetchByExternalID": True,
        "PickupExchangeItemAddDeliveryException": True,
        "PickupExchangeItemSpecifyExchangeItem": True,
        "PickupExchangeMessagesFetchByBrightreeID": True,
        "PickupExchangePayorSearch": True,
        "PickupExchangeRemoveItem": True,
        "PickupExchangeSearch": True,
        "PickupExchangeSendPOD": True,
        "PickupExchangeUpdate": True,
        "PickupExchangeUpdateItem": True,
        "PickupExchangeUpdatePODStatus": True,
    }

    def PickupExchangeFetchByBrightreeID(self, query):
        self._ensure_iterable("PickupExchangeFetchByBrightreeID", query)
        if "BrightreeID" not in query:
            raise BrightreeException("BrightreeID is required for PickupExchangeFetchByBrightreeID", 1003)
        return self._api_call("PickupExchangeFetchByBrightreeID", dict(query))

    def PickupExchangeCreate(self, query):
        return self._call_with_query("PickupExchangeCreate", query)

    def PickupExchangeSearch(self, query):
        return self._call_with_query("PickupExchangeSearch", query)
