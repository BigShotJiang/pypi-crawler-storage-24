from __future__ import annotations

from ..exceptions import BrightreeException
from .base import BaseService


class Inventory(BaseService):
    methods = {
        "CoverageTypeFetchAll": False,
        "ClaimNoteTypeFetchAll": False,
        "FetchItemLocations": True,
        "FetchItemQuantitiesAtLocation": True,
        "InventoryItemAddLots": True,
        "InventoryItemAddSerialNumbers": True,
        "InventoryItemAdjustment": True,
        "InventoryItemTransfer": True,
        "ItemAddToLocation": True,
        "ItemAddToLocations": True,
        "ItemCreate": True,
        "ItemFetchByBrightreeID": True,
        "ItemFetchByExternalID": True,
        "ItemFetchByItemID": True,
        "ItemFetchReplacementItemsByBrightreeID": True,
        "ItemFetchReplacementItemsByItemID": True,
        "ItemLocationsUpdate": True,
        "ItemLocationUpdate": True,
        "ItemSearch": True,
        "ItemUpdate": True,
        "KitTypeFetchAll": False,
        "NDCFetchAll": False,
        "StockingUOMFetchAll": False,
    }

    def ItemFetchByBrightreeID(self, query):
        self._ensure_iterable("ItemFetchByBrightreeID", query)
        if "BrightreeID" not in query:
            raise BrightreeException("BrightreeID is required for ItemFetchByBrightreeID", 1003)
        return self._api_call("ItemFetchByBrightreeID", dict(query))

    def ItemSearch(self, query):
        return self._call_with_query("ItemSearch", query)

    def CoverageTypeFetchAll(self):
        return self._api_call("CoverageTypeFetchAll", {})
