from __future__ import annotations

from ..exceptions import BrightreeException
from .base import BaseService


class Document(BaseService):
    methods = {
        "DocumentTypesFetchAll": False,
        "DocumentBatchCreate": True,
        "DocumentBatchSearch": True,
        "DocumentPropertyUpdate": True,
        "DocumentReviewUpdate": True,
        "DocumentSearch": True,
        "GenerateDocumentID": True,
        "StoreDocument": True,
    }
    special_methods = {
        "FetchDocumentContent": ("documentKey",),
    }

    def FetchDocumentContent(self, key: int = 12345):
        if key <= 0:
            raise BrightreeException(f"Invalid document key: {key}", 1003)
        return self._api_call("FetchDocumentContent", {"documentKey": key})
