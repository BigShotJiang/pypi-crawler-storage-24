from __future__ import annotations

from ..exceptions import BrightreeException
from .base import BaseService


class Security(BaseService):
    methods = {
        "UserCreate": True,
        "UserSearch": True,
        "UserUpdate": True,
        "UserGroupCreate": True,
        "UserGroupUpdate": True,
        "UserGroupFetchByBrightreeID": True,
        "UserGroupFetchAll": False,
        "UserGroupBDMPermissionsFetchByUserGroupBrightreeID": True,
        "UserGroupBDMPermissionsUpdate": True,
        "UserGroupPermissionsFetchByUserGroupBrightreeID": True,
        "UserGroupPermissionsUpdate": True,
    }
    special_methods = {
        "UserFetchByBrightreeID": ("BrightreeID",),
    }

    def UserFetchByBrightreeID(self, brightree_id: int):
        if brightree_id <= 0:
            raise BrightreeException(f"Invalid Brightree ID: {brightree_id}", 1003)
        return self._api_call("UserFetchByBrightreeID", {"BrightreeID": brightree_id})

    def UserCreate(self, query):
        return self._call_with_query("UserCreate", query)

    def UserGroupPermissionsUpdate(self, query):
        return self._call_with_query("UserGroupPermissionsUpdate", query)

    def user_group_bdm_permissions_fetch_by_user_group_brightree_id(self, user_group_brightree_id):
        return self._api_call(
            "UserGroupBDMPermissionsFetchByUserGroupBrightreeID",
            {"UserGroupBrightreeID": user_group_brightree_id},
        )

    def user_group_bdm_permissions_update(self, user_group_brightree_id, user_group_bdm_permissions):
        payload = self._coerce_payload(user_group_bdm_permissions, "user_group_bdm_permissions")
        return self._api_call(
            "UserGroupBDMPermissionsUpdate",
            {
                "UserGroupBrightreeID": user_group_brightree_id,
                "UserGroupBDMPermissions": payload,
            },
        )
