from __future__ import annotations

from .base import BaseService


class CustomField(BaseService):
    service_name = "custom"
    methods = {
        "CustomFieldValueSaveMultiple": True,
    }
    special_methods = {
        "CustomFieldFetchAllByCategory": ("category", "includeInactive"),
        "CustomFieldValueFetchAllByBrightreeID": ("brightreeID", "category"),
    }

    def CustomFieldFetchAllByCategory(self, category: str, includeInactive: int = 0):
        return self._api_call(
            "CustomFieldFetchAllByCategory",
            {"category": category, "includeInactive": includeInactive},
        )

    def CustomFieldValueFetchAllByBrightreeID(self, brightree_id: int, category: str):
        return self._api_call(
            "CustomFieldValueFetchAllByBrightreeID",
            {"brightreeID": brightree_id, "category": category},
        )

    def CustomFieldValueSaveMultiple(self, query):
        return self._call_with_query("CustomFieldValueSaveMultiple", query)
