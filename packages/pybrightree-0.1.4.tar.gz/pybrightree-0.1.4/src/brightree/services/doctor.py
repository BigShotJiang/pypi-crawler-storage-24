from __future__ import annotations

from .base import BaseService


class Doctor(BaseService):
    methods = {
        "DoctorCreate": True,
        "DoctorNoteCreate": True,
        "DoctorNoteUpdate": True,
        "DoctorSearch": True,
        "DoctorUpdate": True,
        "DoctorGroupFetchAll": False,
        "FacilityFetchAll": False,
        "FacilityGroupFetchAll": False,
        "MarketingRepFetchAll": False,
    }
    special_methods = {
        "AddDoctorReferralContact": ("DoctorBrightreeID", "ReferralContactBrightreeID"),
        "DoctorFetchByBrightreeID": ("BrightreeID",),
        "DoctorFetchByExternalID": ("ExternalID",),
        "DoctorNoteFetchByKey": ("brightreeID",),
        "DoctorNoteFetchByDoctor": ("brightreeID",),
        "DoctorReferralContactsFetchByDoctorKey": ("DoctorBrightreeID",),
        "RemoveDoctorReferralContact": ("DoctorBrightreeID", "ReferralContactBrightreeID"),
    }

    def AddDoctorReferralContact(self, doctor_brightree_id: int, referral_contact_brightree_id: int):
        return self._api_call(
            "AddDoctorReferralContact",
            {
                "DoctorBrightreeID": doctor_brightree_id,
                "ReferralContactBrightreeID": referral_contact_brightree_id,
            },
        )

    def DoctorCreate(self, query):
        return self._call_with_query("DoctorCreate", query)

    def DoctorFetchByBrightreeID(self, brightree_id: int):
        return self._api_call("DoctorFetchByBrightreeID", {"BrightreeID": brightree_id})

    def RemoveDoctorReferralContact(self, doctor_brightree_id: int, referral_contact_brightree_id: int):
        return self._api_call(
            "RemoveDoctorReferralContact",
            {
                "DoctorBrightreeID": doctor_brightree_id,
                "ReferralContactBrightreeID": referral_contact_brightree_id,
            },
        )
