from __future__ import annotations


class ArrayHelper:
    def __init__(self) -> None:
        self._search = {}
        self._sort = {}
        self._pages = {"page": 1}
        self._page_size = {"pageSize": 10}

    def search(self, search: dict) -> "ArrayHelper":
        self._search = search
        return self

    def sort(self, sort: dict | None = None) -> "ArrayHelper":
        self._sort = sort or {"SortParams": []}
        return self

    def pageSize(self, page_size: int = 10) -> "ArrayHelper":
        self._page_size = {"pageSize": page_size}
        return self

    def page_size(self, page_size: int = 10) -> "ArrayHelper":
        return self.pageSize(page_size)

    def pages(self, pages: int = 1) -> "ArrayHelper":
        self._pages = {"page": pages}
        return self

    def page(self, page_number: int = 1) -> "ArrayHelper":
        return self.pages(page_number)

    def build(self) -> dict:
        if not self._sort:
            self._sort = {"SortParams": []}
        return {**self._search, **self._sort, **self._pages, **self._page_size}
