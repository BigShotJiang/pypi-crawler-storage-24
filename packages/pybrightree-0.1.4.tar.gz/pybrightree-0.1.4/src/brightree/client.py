from __future__ import annotations

from .config import DEFAULT_SERVICES
from .helpers import ArrayHelper
from .services import (
    CustomField,
    Doctor,
    Document,
    Documentation,
    Insurance,
    Inventory,
    Invoice,
    Patient,
    Pickup,
    Pricing,
    Reference,
    SalesOrder,
    Security,
)


class Brightree(ArrayHelper):
    def __init__(self, username: str, password: str, config: dict | None = None, client_factory=None) -> None:
        super().__init__()
        merged_config = {"service": dict(DEFAULT_SERVICES)}
        if config:
            merged_config.update({key: value for key, value in config.items() if key != "service"})
            if "service" in config:
                merged_config["service"].update(config["service"])

        self.info = {
            "username": username,
            "password": password,
            "config": merged_config,
        }
        self._client_factory = client_factory

    def _service(self, cls):
        return cls(self.info, client_factory=self._client_factory)

    def Patient(self):
        return self._service(Patient)

    def Doctor(self):
        return self._service(Doctor)

    def Document(self):
        return self._service(Document)

    def Documentation(self):
        return self._service(Documentation)

    def CustomField(self):
        return self._service(CustomField)

    def Insurance(self):
        return self._service(Insurance)

    def Inventory(self):
        return self._service(Inventory)

    def Pickup(self):
        return self._service(Pickup)

    def Reference(self):
        return self._service(Reference)

    def SalesOrder(self):
        return self._service(SalesOrder)

    def Pricing(self):
        return self._service(Pricing)

    def Security(self):
        return self._service(Security)

    def Invoice(self):
        return self._service(Invoice)
