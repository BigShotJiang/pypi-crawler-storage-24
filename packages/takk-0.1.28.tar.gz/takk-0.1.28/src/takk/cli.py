from contextlib import suppress
import functools
import json
from pathlib import Path
from uuid import uuid4
import click
import logging
import asyncio

from docker import DockerClient
from docker.errors import APIError
from pydantic import BaseModel, SecretStr
from urllib3.exceptions import ReadTimeoutError

from takk.docker import build_custom_image, build_image, dev_volumes, find_lockfile, packages_from_lockfile, prepare_project, stream_docker_logs
from takk.models import CompiledJob, CompiledProject, Job, NetworkApp, Project, SecretValue, Subscriber, TakkClient, TakkServer, TakkEnvironment, secrets_for
from takk.runners import default_runner

from rich.console import Console
from rich.panel import Panel
from rich.text import Text

from takk.secrets import Environments, ServiceUrl

logger = logging.getLogger(__name__)
console = Console()

def async_(func):  # noqa
    """Decorator to run async functions."""

    @functools.wraps(func)
    def wrapper(*args, **kwargs):  # noqa
        return asyncio.run(func(*args, **kwargs))

    return wrapper


@click.group(help="""
takk - A CLI for managing and deploying Python applications.

Define your project in a project.py file, then use these commands to build,
run, test, and deploy your applications with Docker-based infrastructure.

\b
Quick Start:
  takk up              Start local development environment
  takk deploy          Deploy to production
  takk test            Run tests in isolated containers
""")
@click.version_option(package_name="takk")
@click.option("--cli-debug", is_flag=True)
def cli(cli_debug: bool):
    from dotenv import load_dotenv

    logging.basicConfig(level=logging.INFO)
    logging.getLogger("httpx").setLevel(logging.ERROR)

    if cli_debug:
        logging.getLogger("takk").setLevel(level=logging.DEBUG)

    load_dotenv(".env")


def read_project_at(ref: str | None = None, env: Environments | None = None) -> Project:
    import sys

    if ref is None:
        ref = "project:project"

    path = Path.cwd().as_posix()
    if path not in sys.path:
        sys.path.append(path)

    return project_at(ref, env=env)


def project_at(ref: str, env: Environments | None = None) -> Project:
    import importlib
    import inspect
    import os

    if env:
        os.environ.update(
            TakkEnvironment(takk_env=env).model_dump()
        )

    module_name, attr_name = ref.split(":")

    module = importlib.import_module(module_name)
    project = getattr(module, attr_name)

    assert isinstance(project, Project), f"Expected a project got '{type(project)}'"

    project.project_file = inspect.getsource(module)
    return project


@cli.command(help="Deploy the project to a remote server.")
@click.option("--ref", help="Project reference in format 'module:attribute' (default: project:project).")
@click.option("--server", help="Override the server API URL.")
@click.option("--env", default="qa", help="Target environment (default: qa).")
@click.option("--no-push", is_flag=True, help="Skip building and pushing the Docker image.")
@click.option("--create-resources", is_flag=True, help="Create cloud resources after deployment.")
@click.option("--context", "-c", help="Docker build context directory.")
@click.option("--dockerfile", "-f", help="Path to Dockerfile.")
@async_
async def deploy(
    ref: str | None, 
    server: str | None, 
    env: str, 
    no_push: bool, 
    context: str | None = None,
    dockerfile: str | None = None,
    create_resources: bool = False
) -> None:
    import sys

    click.echo("Deploying project")

    path = Path.cwd().as_posix()

    if ref is None:
        ref = "project:project"

    if server:
        config = TakkServer(takk_api=server) # type: ignore
    else:
        config = TakkServer.read()

    if path not in sys.path:
        sys.path.append(path)

    project = project_at(ref, env)

    lockfile_info = packages_from_lockfile(
        find_lockfile()
    )
    # if not project.name:
    #     project.name = lockfile_info.current_package

    assert project.name, "A name needs to be specified in the `Project` config."

    client = TakkClient(settings=config)
    res = await client.update(project, env=env, packages=lockfile_info.packages)

    url = client.settings.takk_api.replace("/api/v1", "")
    console.print(f"View the project's '{env}' env at [bold blue]{url}/projects/env/{res.project_env_id}[/bold blue]")

    if res.missing_secrets_count > 0:
        console.print(Panel(
            f"Go to '{url}/projects/env/{res.project_env_id}/secrets' to type them in.",
            title=f"[bold]Found {res.missing_secrets_count} missing secrets![/bold]\n",
            border_style="yellow",
            title_align="left"
        ))


    if not no_push:
        compiled = CompiledProject.from_project(project, packages=lockfile_info.packages)

        push_default_image = compiled.jobs or compiled.workers or compiled.subscribers

        for app in compiled.network_apps:
            if app.docker_image:
                continue

            if app.docker_build:
                cfg = app.docker_build
                local_img = build_custom_image(
                    cfg.image_name, cfg.dockerfile, cfg.context, tags=[env, str(res.docker_tag)], args=cfg.args
                )
                await push_custom_image(project, env, cfg.image_name, local_img, client)
            else:
                push_default_image = True


        if push_default_image:
            local_image = build_image(
                project,
                tags=[env, str(res.docker_tag)],
                context=context,
                dockerfile_path=dockerfile
            )
            await push_image(project, env, local_image, client)

        click.echo(f"Source image '{env}' is updated")

    if create_resources:
        await client.deploy(res.project_env_id)



@cli.command(help="Run a specific component from the project.")
@click.argument("name", metavar="COMPONENT")
@click.option("--ref", help="Project reference in format 'module:attribute' (default: project:project).")
@click.option("--platform", help="Docker platform (default: linux/amd64).")
@click.option("--env-file", help="Path to environment variables file.")
@async_
async def run(name: str, ref: str | None, platform: str | None, env_file: str | None = None) -> None:
    import sys
    import inspect

    if ref is None:
        ref = "project:project"

    path = Path.cwd().as_posix()
    if path not in sys.path:
        sys.path.append(path)

    if platform is None:
        platform = "linux/amd64"

    project = project_at(ref)

    if name not in project.components:
        raise ValueError(f"Unable to find '{name}'")

    comp = project.components[name]

    logger.info(comp)

    if isinstance(comp, NetworkApp):
        command = comp.command
    elif isinstance(comp, Job):
        from dotenv import load_dotenv

        load_dotenv()

        if inspect.iscoroutinefunction(comp.main_function):
            await comp.main_function(comp.arguments)  # type: ignore[arg-type]
        else:
            comp.main_function(comp.arguments)  # type: ignore[arg-type]
        return
    elif isinstance(comp, Subscriber):
        return
    else:
        network_app_fn = getattr(comp, "network_app", None)
        if network_app_fn is None:
            raise ValueError(f"Component {name!r} does not support running directly")
        command = network_app_fn(Path.cwd()).command

    logger.info(f"Running command {command} in docker file {project.docker_image}")

    base_image = f"{project.name}:latest"
    if project.docker_image:
        base_image = project.docker_image

    assert command

    if env_file:
        command = ["docker", "run", f"--platform={platform}", f"--env-file={env_file}", base_image, *command]
    else:
        command = ["docker", "run", f"--platform={platform}", base_image, *command]

    _ = default_runner(command)




@cli.command(name="run-job", help="Execute a job function directly (used internally by the scheduler).")
@click.option("--project-name", required=False, help="Name of the project.")
@click.option("--job-id", required=True, help="Unique identifier for the job.")
@click.option("--file-ref", required=True, help="Function reference in format 'module:function'.")
@click.option("--args", help="JSON-encoded arguments for the job function.")
@async_
async def run_job(project_name: str | None, job_id: str, file_ref: str, args: str) -> None:
    import importlib
    import inspect

    click.echo(f"Running ref: {file_ref}")

    try:
        from logging_loki import LokiHandler # type: ignore
        from takk.secrets import LokiLoggerConfig

        config = LokiLoggerConfig() # type: ignore

        auth = None
        if config.loki_user and config.loki_token:
            auth = (config.loki_user, config.loki_token.get_secret_value())

        handler = LokiHandler(
            url=config.loki_push_endpoint,
            auth=auth,
            tags={"job_function": file_ref},
            version=f"{config.loki_logger_version}"
        )

        logging.basicConfig(level=logging.INFO)
        logging.getLogger("").addHandler(handler)
        logger.info("Managed to setup Loki logger")
    except Exception:
        print(f"Unable to setup Loki logger for '{file_ref}'. Make sure `logging_loki` is installed")

    logger.info(f"Running function at '{file_ref}'")
    file, function_name = file_ref.split(":")

    try:
        function_module = importlib.import_module(file)
        function = getattr(function_module, function_name)
    except Exception as e:
        logger.exception(e)
        raise ValueError("Unable to load job function to run.") from e


    assert callable(function)
    sign = inspect.signature(function)   
    params = sign.parameters
    if len(params) == 0:
        if inspect.iscoroutinefunction(function):
            await function()
        else:
            function()
        return

    assert len(params) == 1
    _, param = list(params.items())[0]

    arg_type = param.annotation
    assert not isinstance(arg_type, str), f"Make sure to not use string annotations for {arg_type}"
    assert issubclass(arg_type, BaseModel), f"Expected a subclass of BaseModel got {arg_type}"

    if args:
        encoded_args = arg_type.model_validate_json(args.strip("'"))
    else:
        encoded_args = arg_type()

    try:
        if inspect.iscoroutinefunction(function):
            await function(encoded_args)
        else:
            function(encoded_args)
    except Exception as e:
        logger.exception(e)

        with suppress(Exception):
            if project_name:
                client = TakkClient()
                await client.notify_about_failure(project_name, job_id=job_id, exception=e)
        raise e




@cli.command(name="process-queue", help="Start a worker to process messages from a queue.")
@click.argument("name", metavar="QUEUE_NAME")
@async_
async def process_queue(name: str) -> None:
    from takk.secrets import SqsConfig
    from takk.models import QueueMessage
    from takk.queue import QueueBroker, SqsQueueBroker

    project = read_project_at()
    assert project.workers, f"Expected at least one worker got {project.workers}"

    queue = next(queue for queue in project.workers if queue.name == name)
    broker: QueueBroker = SqsQueueBroker(
        config=SqsConfig(), # type: ignore
        queue_settings=queue.queue_settings 
    )
    queue = broker.with_name(name)

    logger.info(f"Ready to receive work at queue '{name}'")

    while True:
        messages = await queue.receive()
        while messages:
            message = messages[0]

            try:
                content = QueueMessage.model_validate_json(message.body)

                _, name = content.function_ref.split(":")
                logger.info(f"Running function named '{name}'")

                await content.run()
                await queue.delete(message)
            except Exception as e:
                logger.exception(e)

            if len(messages) > 1:
                messages = messages[1:]
            else:
                messages = await queue.receive()


@cli.command(help="Start a NATS subscriber for the specified component.")
@click.argument("name", metavar="SUBSCRIBER_NAME")
@async_
async def subscriber(name: str, ref: str | None = None) -> None:
    project = read_project_at(ref)

    sub = project.components[name]
    assert isinstance(sub, Subscriber)

    pub = await sub.pub_config.publisher(sub.subject)
    await pub.setup()

    logger.info(f"Subscriber '{name}' is listning to '{sub.subject}'")
    await sub.subscribe()



@cli.command(help="Stop and remove running containers.")
@click.option("--all", is_flag=True, help="Stop all takk containers, not just the current project.")
@async_
async def down(all: bool) -> None:
    client = DockerClient.from_env()

    container_labels = ["takk"]
    if not all:
        project = read_project_at()
        container_labels.append(project.name)

    conts: list = client.containers.list(
        all=True, filters={"label": container_labels}
    )

    for cont in conts:
        click.echo(f"Stopping container {cont.name}")
        cont.remove(force=True)

    click.echo("All container managed by Takk are down.")


@cli.command(help="""Start the local development environment.

\b
Examples:
  takk up                    Start all components
  takk up api worker         Start only api and worker
  takk up --env-file .env    Use custom environment file
""")
@click.argument("components", nargs=-1, metavar="[COMPONENTS]...")
@click.option("--env", default="dev", help="Target environment (default: dev).")
@click.option("--env-file", default=None, help="Path to environment variables file.")
@click.option("--write-volumes", "-w", is_flag=True, help="If the containers can write to the inserted volumes")
@click.option("--ref", help="The project reference (default project:project)")
@async_
async def up(
    components: list[str],
    env: str,
    ref: str | None = None,
    env_file: str | None = None,
    write_volumes: bool = False,
    use_ollama: bool = True,
) -> None:
    from takk.docker import compose
    from pathlib import Path 

    current_dir = Path.cwd()
    project = read_project_at(ref)

    project_container = prepare_project(project)
    volumes = dev_volumes(project, current_dir, project_container.source_dir, can_write=write_volumes)

    if env in ["prod", "test"]:
        console.print(Panel(
            f"Loading resources to connect to '[bold yellow]{env}[/bold yellow]'\n"
            "However, this is not supported yet but will be!",
            title="Environment Setup",
            border_style="yellow",
            title_align="left"
        ))
    else:
        console.print(Panel(
            "Setting up local '[bold green]dev[/bold green]' resources",
            title="Environment Setup",
            border_style="green",
            title_align="left"
        ))

    volume_names = [Path(path).name for path in volumes.keys()]
    volumes_text = Text()
    volumes_text.append("Mounted volumes: ", style="bold")
    volumes_text.append(", ".join(volume_names), style="cyan")
    console.print(volumes_text)

    if use_ollama:
        console.print("Using local Ollama instance for LLMBaseAPI, LLMBaseUrl and LLMToken")

    compose(
        project, 
        base_image=f"{project.name}:latest",
        volumes=volumes,
        env_file=env_file,
        components=components if components else None,
    )


@cli.command(help="Build the Docker image for the project.")
@click.option("--tag", help="Image tag (default: latest).")
@click.option("--push", is_flag=True, help="Push the image to the registry after building.")
@async_
async def build(
    push: bool,
    tag: str | None = None,
    ref: str | None = None,
) -> None:
    project = read_project_at(ref)

    if project.docker_image is not None:
        click.echo("Found docker image definition so will skip build.")
        return 

    if not tag:
        tag = "latest"

    prepare_project(project, tag, force_build=True)

    if push:
        await push_image(project, tag, f"{project.name}:{tag}", client=None)


@cli.command(help="Open an interactive shell inside the project's Docker container.")
@async_
async def shell() -> None:
    project = read_project_at(None)

    if project.docker_image is not None:
        click.echo("Found docker image definition so will skip build.")
        return 

    assert project.name

    default_runner([
        "docker", "run", "-it", "--network", project.name, "--platform=linux/amd64", project.name, "bash"
    ])



@cli.command(name="exec", help="""Execute a command in the project's Docker container with all resources running.

The command runs inside the project container with Postgres, Redis, and any
other declared resources started, and all shared secrets / environment
variables injected.

\b
Examples:
  takk exec "alembic upgrade head"
  takk exec "python -m myapp.scripts.seed_db"
  takk exec --ephemeral "python -c 'print(1)'"
  takk exec --services psql redis "python script.py"
  takk exec --no-services "python -c 'print(1)'"
""")
@click.argument("command", type=str)
@click.option("--context", "-c", default=None, help="Docker build context directory.")
@click.option("--dockerfile", "-f", default=None, help="Path to Dockerfile.")
@click.option("--env-file", default=None, help="Path to environment variables file.")
@click.option("--ephemeral", is_flag=True, default=False,
              help="Use temporary resource data (deleted after command finishes).")
@click.option("--read-only", is_flag=True, default=False,
              help="Mount source volumes as read-only (default is read-write).")
@click.option("--services", "-s", multiple=True,
              help="Only start specific services (e.g. psql, redis). Can be repeated.")
@click.option("--no-services", is_flag=True, default=False,
              help="Don't start any resource services.")
def exec_command(
    command: str,
    context: str | None = None,
    dockerfile: str | None = None,
    env_file: str | None = None,
    ephemeral: bool = False,
    read_only: bool = False,
    services: tuple[str, ...] = (),
    no_services: bool = False,
) -> None:
    import sys
    import tempfile
    from takk.docker import compose

    current_dir = Path.cwd()
    project = read_project_at()

    project_container = prepare_project(project)
    volumes = dev_volumes(project, current_dir, project_container.source_dir)

    if not read_only:
        for vol in volumes.values():
            vol["mode"] = "rw"

    volume_names = [Path(path).name for path in volumes.keys()]
    volumes_text = Text()
    volumes_text.append("Mounted volumes: ", style="bold")
    volumes_text.append(", ".join(volume_names), style="cyan")
    console.print(volumes_text)

    runner_name = "exec-runner"
    primary = CompiledJob(
        name=runner_name,
        function_ref="",
        custom_command=command,
        description="",
        arguments={},
        secrets=secrets_for(project.shared_secrets or []),
    )

    if no_services:
        components: list[str] | None = []
    elif services:
        components = list(services)
    else:
        components = None

    if ephemeral:
        with tempfile.TemporaryDirectory() as temp_dir:
            exit_code = compose(
                project,
                base_image=f"{project.name}:latest",
                volumes=volumes,
                env_file=env_file,
                data_dir=Path(temp_dir),
                primary_container=primary,
                components=components,
            )
    else:
        exit_code = compose(
            project,
            base_image=f"{project.name}:latest",
            volumes=volumes,
            env_file=env_file,
            primary_container=primary,
            components=components,
        )

    sys.exit(exit_code or 0)



@cli.group(help="Manage database revisions through alembic.")
def revisions():
    pass


@revisions.command(name="new", help="Create a new Alembic migration revision.")
@click.argument("message", type=str)
@click.option("--context", "-c", default=None, help="Docker build context directory.")
@click.option("--dockerfile", "-f", default=None, help="Path to Dockerfile.")
@click.pass_context
def new_revision(ctx, message: str, context: str | None, dockerfile: str | None) -> None:
    command = f"alembic revision --autogenerate -m '{message}'"
    ctx.invoke(exec_command, command=command, context=context, dockerfile=dockerfile, read_only=False, no_services=True)


@revisions.command(help="Upgrade the database to a given revision (default: head).")
@click.argument("target", default="head", type=str)
@click.option("--context", "-c", default=None, help="Docker build context directory.")
@click.option("--dockerfile", "-f", default=None, help="Path to Dockerfile.")
@click.pass_context
def upgrade(ctx, target: str, context: str | None, dockerfile: str | None) -> None:
    command = f"alembic upgrade {target}"
    ctx.invoke(exec_command, command=command, context=context, dockerfile=dockerfile, no_services=True)


@revisions.command(help="Downgrade the database to a given revision (default: -1).")
@click.argument("target", default="-1", type=str)
@click.option("--context", "-c", default=None, help="Docker build context directory.")
@click.option("--dockerfile", "-f", default=None, help="Path to Dockerfile.")
@click.pass_context
def downgrade(ctx, target: str, context: str | None, dockerfile: str | None) -> None:
    command = f"alembic downgrade {target}"
    ctx.invoke(exec_command, command=command, context=context, dockerfile=dockerfile, no_services=True)


@revisions.command(help="Create the first alembic revision when your database is empty.")
@click.option("--context", "-c", default=None, help="Docker build context directory.")
@click.option("--dockerfile", "-f", default=None, help="Path to Dockerfile.")
@click.pass_context
def init(ctx, context: str | None, dockerfile: str | None) -> None:
    command = "alembic revision --autogenerate -m 'Init alembic'"
    ctx.invoke(
        exec_command, 
        command=command, 
        context=context, 
        dockerfile=dockerfile, 
        no_services=True,
        ephemeral=True
    )


async def push_image(project: Project, tag: str, local_image: str, client: TakkClient | None) -> None:
    creds = await (client or TakkClient()).docker_creds(project.name)

    docker_client = DockerClient.from_env()

    first_part = creds.registry.split("/")
    default_runner(["docker", "logout", first_part[0]])
    docker_client.login(
        password=creds.password, 
        registry=creds.registry,
        username="nologin"
    )

    repo = f"{creds.registry}/{project.name}:{tag}"
    docker_client.images.get(local_image).tag(
        repository=repo, tag=tag
    )

    try:
        push_error = stream_docker_logs(
            docker_client.images.push(repo, tag=tag, stream=True, decode=True)
        )
    except (APIError, ReadTimeoutError) as e:
        console.print(f"[bold red]An unexpected error occured in Docker {e}. Try again later.[/bold red]")
        return

    if push_error:
        docker_client.images.remove(repo)
        raise click.ClickException(push_error)

    docker_client.images.remove(repo)


async def push_custom_image(project: Project, tag: str, image_name: str, local_image: str, client: TakkClient | None) -> None:
    creds = await (client or TakkClient()).docker_creds(project.name)

    docker_client = DockerClient.from_env()

    first_part = creds.registry.split("/")
    default_runner(["docker", "logout", first_part[0]])
    docker_client.login(
        password=creds.password,
        registry=creds.registry,
        username="nologin"
    )

    repo = f"{creds.registry}/{image_name}:{tag}"
    docker_client.images.get(local_image).tag(
        repository=repo, tag=tag
    )

    try:
        push_error = stream_docker_logs(
            docker_client.images.push(repo, tag=tag, stream=True, decode=True)
        )
    except (APIError, ReadTimeoutError) as e:
        console.print(f"[bold red]An unexpected error occured in Docker {e}. Try again later.[/bold red]")
        return

    if push_error:
        docker_client.images.remove(repo)
        raise click.ClickException(push_error)

    docker_client.images.remove(repo)


@cli.command(help="Authenticate with the takk server via browser.")
@click.option("--api", default=None, help="Override the API server URL.")
@async_
async def login(api: str | None) -> None:
    import webbrowser
    from takk.models import default_takk_file

    settings = TakkServer(takk_token=SecretStr("auth"))
    if api:
        settings.takk_api = api

    request_id = uuid4()
    non_api = settings.takk_api.removesuffix("/api/v1")    
    url = f"{non_api}/users/cli-login/{request_id}"
    webbrowser.open(url)

    client = TakkClient(settings)
    token = await client.auth_cli(request_id)
    settings.takk_token = SecretStr(secret_value=token)

    output = json.dumps({
        key: value.get_secret_value() if isinstance(value, SecretStr) else value
        for key, value in settings.model_dump().items()
    })
    default_takk_file.write_text(output)

    click.echo(f"Created token with info {output}")


@cli.command(name="dotenv", help="""Generate a .env file with all project secrets.

Required secrets (no default, not optional, not auto-filled) appear uncommented at the top.
Secrets that are optional, have a default value, or are auto-filled by a resource tag are
written as commented-out entries below.

If an existing .env file is found, its values are preserved in the new file.
""")
@click.option("--ref", help="Project reference in format 'module:attribute' (default: project:project).")
@click.option("--output", "-o", default=".env", help="Output file path (default: .env).")
def dotenv(ref: str | None, output: str) -> None:
    from takk.secrets import ResourceTags

    project = read_project_at(ref)

    # Map: secret_name -> list of config class names (in order of first encounter)
    secret_classes: dict[str, list[str]] = {}
    # Map: secret_name -> SecretValue (first encounter)
    secret_values: dict[str, SecretValue] = {}

    def collect(secret: SecretValue, cls_name: str) -> None:
        if secret.name not in secret_classes:
            secret_classes[secret.name] = []
            secret_values[secret.name] = secret
        if cls_name not in secret_classes[secret.name]:
            secret_classes[secret.name].append(cls_name)

    for settings_cls in (project.shared_secrets or []):
        for secret in secrets_for(settings_cls):
            collect(secret, settings_cls.__name__)

    for component in project.components.values():
        for settings_cls in _component_secrets(component):
            for secret in secrets_for(settings_cls):
                collect(secret, settings_cls.__name__)

    for worker in (project.workers or []):
        for settings_cls in _component_secrets(worker):
            for secret in secrets_for(settings_cls):
                collect(secret, settings_cls.__name__)

    # Group secrets by their (ordered) tuple of class names
    # Preserve section order by first appearance
    section_order: list[tuple[str, ...]] = []
    sections: dict[tuple[str, ...], list[SecretValue]] = {}
    for name, cls_names in secret_classes.items():
        key = tuple(cls_names)
        if key not in sections:
            section_order.append(key)
            sections[key] = []
        sections[key].append(secret_values[name])

    def is_commented(secret: SecretValue) -> bool:
        has_resource_tag = any(
            ResourceTags.is_tag(tag.split(":")[0]) or ServiceUrl.from_string(tag)
            for tag in secret.tags
        ) or ResourceTags.is_tag(secret.data_type)
        return has_resource_tag or secret.default_value is not None or secret.is_optional

    # Load existing values to preserve them
    existing: dict[str, str] = {}
    env_path = Path(output)
    if env_path.exists():
        for line in env_path.read_text().splitlines():
            stripped = line.strip()
            if stripped and not stripped.startswith("#") and "=" in stripped:
                key, _, value = stripped.partition("=")
                existing[key.strip()] = value.strip()

    lines: list[str] = []
    total_required = 0
    total_commented = 0

    for key in section_order:
        section_secrets = sections[key]
        header = " + ".join(key)
        lines.append(f"# {'=' * 3} {header} {'=' * 3}")

        required = [s for s in section_secrets if not is_commented(s)]
        commented = [s for s in section_secrets if is_commented(s)]

        if required:
            lines.append("# Required — must be set manually")
            for secret in required:
                if secret.description:
                    lines.append(f"# {secret.description}")
                value = existing.get(secret.name, "")
                lines.append(f"{secret.name}={value}")
            total_required += len(required)

        if commented:
            if required:
                lines.append("")
            lines.append("# Auto-filled, optional, or have defaults — uncomment to override")
            for secret in commented:
                if secret.description:
                    lines.append(f"# {secret.description}")
                value = existing.get(secret.name, secret.default_value or "")
                lines.append(f"# {secret.name}={value}")
            total_commented += len(commented)

        lines.append("")

    env_path.write_text("\n".join(lines))

    console.print(
        f"Generated [bold]{output}[/bold] with "
        f"[green]{total_required}[/green] required and "
        f"[yellow]{total_commented}[/yellow] optional/auto-filled secrets."
    )


@cli.command(help="Displays which user I am logged in as.")
@async_
async def whoami() -> None:
    settings = TakkServer.read()
    client = TakkClient(settings)

    content = await client.whoami()
    content["api_path"] = settings.takk_api
    console.print(content)


def _component_secrets(component) -> list[type[BaseModel]]:
    """Extract per-component secrets list from any component type."""
    if hasattr(component, "secrets") and component.secrets:
        s = component.secrets
        return s if isinstance(s, list) else [s]
    if hasattr(component, "secret_type") and component.secret_type:
        return component.secret_type
    return []


@cli.command(help="List all resources, showing which are shared across all services and which are service-specific.")
@click.option("--ref", help="Project reference in format 'module:attribute' (default: project:project).")
def resources(ref: str | None) -> None:
    from rich.table import Table

    project = read_project_at(ref)

    table = Table(title=f"Resources — {project.name}", show_lines=True)
    table.add_column("Resource", style="cyan", no_wrap=True)
    table.add_column("Type", style="green")
    table.add_column("Scope", style="yellow")
    table.add_column("Settings", style="magenta")

    # Shared resources
    for settings_cls in (project.shared_secrets or []):
        for secret in secrets_for(settings_cls):
            table.add_row(
                secret.name,
                secret.data_type,
                "Shared",
                settings_cls.__name__,
            )

    # Per-service resources (components)
    for comp_name, component in project.components.items():
        for settings_cls in _component_secrets(component):
            for secret in secrets_for(settings_cls):
                table.add_row(
                    secret.name,
                    secret.data_type,
                    f"Service: {comp_name}",
                    settings_cls.__name__,
                )

    # Per-service resources (workers)
    for worker in (project.workers or []):
        for settings_cls in _component_secrets(worker):
            for secret in secrets_for(settings_cls):
                table.add_row(
                    secret.name,
                    secret.data_type,
                    f"Service: {worker.name}",
                    settings_cls.__name__,
                )

    console.print(table)


@cli.command(help="""Run tests in isolated Docker containers.

\b
Examples:
  takk test                              Run pytest
  takk test --command "npm test"         Run npm tests
  takk test api db                       Start api and db for tests
""")
@click.argument("components", nargs=-1, metavar="[COMPONENTS]...")
@click.option("--env-file", default=None, help="Path to environment variables file.")
@click.option("--build", is_flag=True, default=False, help="If the docker image should be rebuilt")
@click.option("--log-resources", is_flag=True, default=False, help="If the resources should be logged")
@click.option("--command", "-cmd", default="python -m pytest",
              help="Test command to run (default: python -m pytest).")
@click.option("--no-migrations", is_flag=True, default=False,
              help="Skip running alembic migrations before tests.")
@async_
async def test(
    components: list[str],
    command: str,
    build: bool,
    log_resources: bool,
    no_migrations: bool,
    ref: str | None = None,
    env_file: str | None = None,
) -> None:
    import sys
    import tempfile
    from takk.docker import compose

    env = "test"

    current_dir = Path.cwd()
    project = read_project_at(ref, env=env)

    _ = prepare_project(project)
    project_container = prepare_project(
        project,
        tag="latest-test",
        uv_sync_args="--locked --no-editable --active --all-groups",
        force_build=build,
    )
    volumes = dev_volumes(project, current_dir, project_container.source_dir, with_tests=True)

    if not no_migrations:
        from takk.alembic import revisions_for_alembic_config
        alembic_ini = current_dir / "alembic.ini"
        if revisions_for_alembic_config(alembic_ini):
            command = f"alembic upgrade head && {command}"
            console.print("[bold cyan]Alembic migrations found — running upgrade head before tests.[/bold cyan]")


    console.print(Panel(
        f"Setting up project in '[bold green]{env}[/bold green]' mode.\n"
        "If you need further changes to setup integration testing, use the `current_env` function.",
        title="Environment Setup",
        border_style="yellow",
        title_align="left"
    ))

    volume_names = [Path(path).name for path in volumes.keys()]
    volumes_text = Text()
    volumes_text.append("Mounted volumes: ", style="bold")
    volumes_text.append(", ".join(volume_names), style="cyan")
    console.print(volumes_text)

    test_runner_name = "test-runner"

    with tempfile.TemporaryDirectory() as temp_dir:
        temp_data_dir = Path(temp_dir)

        log = "all" if log_resources else "services"

        exit_code = compose(
            project,
            base_image=f"{project.name}:latest-test",
            volumes=volumes,
            env_file=env_file,
            components=components if components else None,
            data_dir=temp_data_dir,
            primary_container=CompiledJob(
                name=test_runner_name,
                function_ref="",
                custom_command=command,
                description="",
                arguments={},
                secrets=secrets_for(project.shared_secrets or [])
            ),
            env=env,
            logs_listners=log
        )

    sys.exit(exit_code or 0)


if __name__ == "__main__":
    cli()
