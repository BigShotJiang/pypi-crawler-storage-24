import asyncio
from dataclasses import dataclass
import inspect
import logging

from typing import Awaitable, Callable, Literal, TypeVar

from nats.js.api import ConsumerConfig, StreamConfig
from pydantic import BaseModel, ValidationError


from nats.aio.client import Client


logger = logging.getLogger(__name__)

T = TypeVar("T", bound=BaseModel)

@dataclass
class NatsStream:

    conn: Client
    subject: str
    config: StreamConfig
    deduplicate_key: str | None = None

    async def setup(self) -> None:
        js = self.conn.jetstream()


        try:
            stream = await js.find_stream_name_by_subject(self.subject)
            if self.config.name == stream:
                await js.update_stream(config=self.config)
        except Exception:
            await js.add_stream(config=self.config)


    async def publish(self, content: BaseModel) -> None:
        js = self.conn.jetstream()

        headers = {}

        if self.deduplicate_key:
            headers["Nats-Msg-Id"] = str(getattr(content, self.deduplicate_key, None))

        await js.publish(self.subject, content.model_dump_json().encode(), headers=headers)


@dataclass
class NatsSubscriber:

    conn: Client
    subject: str
    guarantee: Literal["at-least-once", "at-most-once"] = "at-least-once"
    durable: str | None = None
    queue: str | None = None
    consume_config: ConsumerConfig | None = None
    max_iterations: int | None = None

    async def subscribe(self, handler: Callable[[T], None] | Callable[[T], Awaitable[None]], content_type: type[T]) -> None:

        js = self.conn.jetstream()

        subscription = await js.subscribe(
            subject=self.subject,
            durable=self.durable, 
            queue=self.queue,
            config=self.consume_config
        )

        iterations = 0

        while True:
            if self.max_iterations:
                iterations += 1
            try:
                message = await subscription.next_msg()
            except TimeoutError:
                if self.max_iterations and iterations >= self.max_iterations:
                    return 

                await asyncio.sleep(1)
                continue

            try:
                if self.guarantee == "at-most-once":
                    await message.ack()

                content = content_type.model_validate_json(message.data)
                if inspect.iscoroutinefunction(handler):
                    await handler(content)
                else:
                    handler(content)

                if self.guarantee == "at-least-once":
                    await message.ack()

            except ValidationError as e:
                logger.exception(e)
                logger.error("Unable to decode message")

                if self.guarantee == "at-least-once":
                    await message.nak()
            except Exception as e:
                logger.exception(e)
                if self.guarantee == "at-least-once":
                    await message.nak()

            if self.max_iterations and iterations >= self.max_iterations:
                return 
            


