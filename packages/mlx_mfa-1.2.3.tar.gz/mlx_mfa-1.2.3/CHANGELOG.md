# Changelog

All notable changes to mlx-mfa are documented here.

## [1.2.3] — 2026-03-09

### Changed (tech-debt remediation v2, Phases 1–4)

- **Phase 1 quick-wins** (commits 33d6c05):
  - J.1: Removed dead `_kv_cache_hit_count` / `_reset_count` attributes from `InferenceContext`
  - J.2: Removed stale `# Phase 4-E.1` comment superseded by I.1
  - J.3: Eliminated scalar-zero `mx.zeros([], ...)` in sparse backward; replaced with `mx.array(0.0)`
  - G.2: Removed redundant `mx.eval()` before `_mfa_scatter_kv_cpp` call
  - I.4: Extracted `_resolve_cache_seqlens()` utility; eliminated 6-way isinstance branching
  - F.3: Replaced O(B) positional scatter loop in `flash_attention_paged` with `mx.concatenate` + reshape

- **Phase 2 serialization fixes** (commit 5410d55):
  - H.3: `flash_attention_varlen` fallback now handles cu_seqlens mismatch gracefully
  - H.4: Uniform `cache_seqlens` shortcut in paged-append avoids per-batch loops when all offsets equal
  - H.1 safely reverted: per-batch `flash_attention` loop kept over single SDPA (avoids NaN from paged gather on uninitialized bytes)

- **Phase 3 structural changes** (commit c09bc5f):
  - F.2: Vectorised paged-append scatter targets — `O(1)` broadcast MLX ops replace `O(B×N_new)` Python loop; uses `seq_lens[:, None] + t_arange[None, :]` + gather `block_table[row_idx, blk_idxs]`
  - I.2: New `DenseKVCache` class — pre-allocated `[B, H, max_seq_len, D]` buffer; `append()` uses `__setitem__` (MLX `slice_update`) + `mx.eval()` for constant lazy-graph depth
  - G.1: Moved `mx.eval(q,k,v,O,L,dO)` fence from Python `_backward` into C++ `mfa_steel_backward` lambda (`mlx::core::eval(std::vector<array>{...})`); avoids one blocking Python-level GPU sync per backward pass

- **Phase 4 structural changes** (commits c4ae2f5, de37269):
  - I.1: `InferenceContext` now uses `DenseKVCache` write-pointer internally — eliminates `mx.concatenate` per decode step; lazy-graph depth stays constant; `k_cache`/`v_cache`/`seqlen` properties unchanged
  - E.3-partial: `block_table.tolist()` deferred to Python-loop fallback branch (avoids GPU sync on `_USE_SCATTER_KV` fast path); `mx.array(seq_lens_list_p)` replaced with `seq_lens.astype(mx.int32)` in scatter branch; E.3 comments added to all remaining `.tolist()` calls
  - F.1 skipped: Metal block-scoped scatter rewrite analyzed, found negligible benefit (~40 μs for 16 MB at 400 GB/s = 0.1% of decode step)

### Tests
- 486 tests pass (sage flaky test passes in isolation; pre-existing GPU cross-test noise)

---

## [1.2.2] — 2026-03-09

### Added

- **Phase 4-A.1+A.2 — Fused `MFAQuantizePerBlock` C++ primitive** (`csrc/mfa_quantize.hpp/.cpp`):
  - Single Metal JIT kernel: reads fp16/bf16 input, computes per-block absmax, scales, rounds, clips, outputs int8 + f32 scale in one GPU dispatch
  - Replaces 12+ sequential Python MLX ops in `quantize_per_block()` — the SageAttention bottleneck
  - Registered as `mfa_quantize_per_block` nanobind binding; `mlx_mfa/quantize.py` uses C++ path when available
  - `QuantizePerBlock = 12` added to `ShaderCache::KernelType`

- **Phase 4-C.1+E.2 — `mfa_scatter_kv` C++ primitive** (`csrc/mfa_scatter.hpp/.cpp`):
  - Single-pass Metal kernel: one thread per pool element; copies from `pool_in`, writes scatter token on `(blk, off)` match
  - Replaces O(num_blocks) Python concatenate loop in `PagedKVCache.append()` and paged-append mode of `flash_attention_kvcache`
  - `ScatterKV = 13` added to `ShaderCache::KernelType`; CPU fallback via memcpy

- **Phase 4-E.1 — `InferenceContext.step()` graph materialisation**:
  - mx.eval(k_cache, v_cache) after each mx.concatenate prevents O(N_steps) lazy graph depth
  - Eliminates memory pressure during long decode loops (>200 tokens)

- **Phase 3-B.1 — Logsumexp saved from forward pass**:
  - `_make_mfa_custom` returns `(O, L)` from `_impl()`; backward uses saved L for sparse/custom paths

- **Phase 3-D.5 — Contiguity checks in C++ bindings**:
  - `mfa_attention_forward`, `mfa_attention_forward_lse`, `mfa_paged_kv_gather` call `mlx::core::contiguous()` internally
  - Removes 3 Python-to-C++ round-trips from every MFA forward dispatch

- **Phase 3-E.4 — Batched paged/varlen backward**:
  - `_paged_backward` and `_varlen_backward` batch K/V across the B dimension; run one vjp instead of B sequential calls

- **Phase 2 fixes** (Python-only):
  - **B.2**: Causal mask in `_fallback_sdpa_with_lse` built once and recast
  - **C.3**: `backward=sdpa_sparse` emits `DeprecationWarning`; use `backward=steel_sparse`
  - **C.4**: Sparse backward: 7-tensor numpy round-trip replaced with mx.contiguous() (~10-50 ms saved)
  - **C.5**: `speculative_verify` O(B*N) Python loop replaced with `mx.take_along_axis`
  - **D.4**: `mlx_lm._steel_sdpa()` calls `_mfa_forward()` directly (saves ~2us/token)
  - **D.6**: `_make_mfa_sparse_custom` cached with `@lru_cache(32)` on `(scale, causal, head_dim, backward)`
  - **D.8**: mlx_lm stats: string-keyed dict replaced with module-level int counters
  - **D.9**: `hasattr(cache, attr)` replaced with `getattr(cache, attr, None)`

- **Phase 1 fixes** (trivial Python):
  - **D.1**: `_ext_available()` cached (removes ~3us/call import probe)
  - **D.2**: sage_attention import probe cached
  - **D.3**: `_VALID_BACKENDS` is now a module-scope frozenset
  - **A.3**: `x_blocked.astype(float32)` computed once in `quantize_per_block`
  - **B.3**: `_sever_lazy_graph()` uses contiguity fix instead of elementwise-add kernel
  - **E.5**: Identity transpose no-op removed from `_block_mask_to_float_bias`

### Performance (v1.2.2 vs v1.2.1 baseline)

| Metric | Before | After | Delta |
|--------|--------|-------|-------|
| SageAttention N=512 vs FA | 0.89x | **1.10x** | **+24%** |
| SageAttention N=1024 vs FA | 0.81x | **1.12x** | **+38%** |
| SageAttention N=4096 vs FA | 0.52x | 0.56x | +4% |
| STEEL fwd D=64 N=8192 causal | 1.40x | 1.37x | noise |
| Sliding window N=16384 w=512 | 13.24x | 13.17x | noise |
| Paged STEEL decode S=1024 | 1.54x | **1.60x** | +4% |
| Per-token Python overhead (32L) | ~138us | ~22us | **-84%** |

See `docs/benchmarks/COMPARISON_V1_2_2_ALL_PHASES.md`.

### Tests
- 486 tests pass

---

## [1.2.1] — 2026-03-09

### Added
- **Track LA — `window_size.right` in STEEL kernel**:
  - `flash_attention(..., window_size=(left, right))` with `right >= 0` now activates the right-side guard inside the STEEL Metal kernel
  - `MFASteelParams` gains `int window_right` field; Metal shader uses it to skip K-tiles wholly outside `[q - left, q + right]` and to clamp per-element scores
  - Previously `right > 0` raised `NotImplementedError`; now handled natively (f16/bf16) or via boolean mask fallback (f32)
  - 8 new tests in `TestWindowRight`

- **Track LB — 4-D sparse block masks**:
  - `flash_attention_sparse(q, k, v, block_mask)` accepts `[B, H, NQ, NK]` (per-batch-per-head) and `[H, NQ, NK]` (per-head broadcast) in addition to the existing `[NQ, NK]` shape
  - Implemented via `mask_batch_stride` / `mask_head_stride` fields in `MFASteelParams`; stride = 0 means "broadcast that dimension" — zero-copy broadcast
  - Backward path collapses 3-D/4-D masks to 2-D via `.any()` (conservative union of active blocks)
  - 14 new tests in `TestBlockMask4D`

- **Track LC — `InferenceContext` stateful lifecycle object**:
  - New class `mlx_mfa.InferenceContext` manages the growing KV cache for autoregressive generation
  - `prefill(q, k, v, *, scale, causal=True, softcap, window_size)` — full-sequence attention; initialises cache
  - `step(q, k_new, v_new, *, scale, softcap, window_size)` — appends new K/V tokens; calls `flash_attention_kvcache(causal=True)`
  - `reset()` — clears cache; returns `self` for chaining
  - Context-manager form: `__exit__` calls `reset()`
  - `seqlen`, `k_cache`, `v_cache` read-only properties
  - 21 new tests in `tests/test_inference_context.py`

### Fixed
- `attn_bias` docstring: explicitly marked as SDPA-only **architectural decision** (MFA's fused online-softmax kernel has no generic additive-bias buffer); directed users to `alibi_slopes` for native Metal relative-position biases
- `flash_attention_paged` dK/dV zeros text: already corrected in Track JA; confirmed clean

### Tests
- **486 tests pass** (up from 442 in v1.2.0)
- New test files: `tests/test_inference_context.py` (21 tests, Track LC)
- New test classes in `tests/test_attention.py`: `TestWindowRight` (8, Track LA), `TestBlockMask4D` (14, Track LB)

---

## [1.2.0] — 2026-03-09

### Added
- **Track KA — Quantization utilities** (`mlx_mfa/quantize.py`):
  - `quantize_per_block(x, block_size)` — per-block int8 quantization with float32 scales
  - `dequantize(x_int8, x_scale, block_size)` — reconstruct float32 from int8 + per-block scale
  - `smooth_k(k)` — per-channel mean subtraction; returns `(k_smooth, k_mean)` in float32
  - `sage_block_sizes(head_dim)` — returns `(BQ, BK)` for given D
  - `sage_output_correction` — included for completeness; **not called** by `sage_attention` (correction is mathematically a no-op)
- **Track KB — SageAttention Metal kernel** (`csrc/mfa_sage_fwd.cpp`):
  - `MFASagePrimitive` — MLX Primitive; `eval_gpu()` dispatches `SageForward` kernel
  - JIT Metal source gen: int8 Q/K dequantize in-register; V loaded at full precision; fp32 online softmax accumulator
  - Non-persistent grid `(ceil(N/BQ), H, B)` — one threadgroup per Q-tile
  - `SageForward` added as kernel type 11 in `shader_cache.hpp`
  - GQA: Q head `h` maps to KV head `h // gqa_factor`
  - `mfa_sage_forward` nanobind binding in `csrc/bindings.cpp`
- **Track KC — `sage_attention()` Python API** (`mlx_mfa/attention.py`):
  - `sage_attention(q, k, v, scale=None, causal=False, apply_smooth_k=True, stream=None)`
  - Optionally applies `smooth_k`; quantizes Q/K with `quantize_per_block`; calls `mfa_sage_forward`
  - No output correction applied (smooth_k bias cancels exactly in softmax denominator)
  - Falls back to `flash_attention` when C++ extension is unavailable
  - GQA supported: `H_kv < H_q` with `sage_attention(q, k, v)` where `k.shape[1] < q.shape[1]`
  - All new symbols exported from `mlx_mfa.__init__`
  - `get_supported_configs()["features"]["sage_attention"]` feature flag added
  - `kernel_types` count updated 8 → 9

### Tests
- 23 new tests in `tests/test_sage_attention.py`
  - `TestQuantizeUtils` (7): roundtrip shape/accuracy, non-multiple seq, smooth_k shape/zero-mean, block sizes, dequantize shape
  - `TestSageAPI` (7, always run): output shape/dtype (fp16/bf16), no NaN (causal + non-causal), smooth_k toggle, supported configs
  - `TestSageKernel` (9, extension required): D=64/128 × causal/non-causal, longer seq, GQA 2:1, batch>1, no-smooth correctness, D=256 finite

### Performance (M1 Max, f16, B=1 H=8)
| N | sage / flash_attention |
|---|------------------------|
| 1024 | 0.31× |
| 4096 | 0.52× |

Note: Current overhead is Python-side `quantize_per_block`. Speedup realized with
pre-quantized int8 KV caches between decode steps.

---

## [1.1.0] — 2026-03-09

### Added
- **`flash_attention_rope_unified`** (Track JB) — single entry point for all
  RoPE+attention combinations (standalone, first-step cache-append, subsequent
  cache-append). `flash_attention_rope` and `flash_attention_kvcache_rope_append`
  are now thin wrappers. Dispatch flag: `_cache_mode = (k_cache is not None) or
  return_updated_cache`. 7 new tests in `TestRoPEUnified`.
- **Paged-append in `flash_attention_kvcache`** (Track JC) — `k_new` +
  `block_table` combined is now supported (pool rebuilt via Python loop).
  `cache_batch_idx + paged-append` raises `NotImplementedError`. 2 new tests.
- **LLM inference helpers** (Track JD):
  - `flash_attention_speculative_verify` — target log-probs for draft sequences.
  - `make_shared_prefix_cache` — shared prefix KV cache for multi-request reuse.
  - `flash_attention_splitfuse` — combined prefill + decode routing.
  10 new tests across `TestSpeculativeVerify`, `TestSharedPrefixCache`, `TestSplitFuse`.
- **`patch_mlx_lm` enrichment** (Track JE): sliding window via `cache.max_kv_window`,
  `gqa_calls` + `sliding_window_calls` stats, `verbose_dispatch` param,
  `KNOWN_MODEL_CONFIGS` dict (22 families). 5 new tests.
- **Cross-attention** (Track JF): docstring section in `flash_attention_kvcache`,
  `examples/cross_attention.py`, 3 new tests in `TestCrossAttentionKVCache`.

### Fixed
- **`flash_attention_paged` docstring** (Track JA.1) — dK_pages/dV_pages are computed
  correctly via `_scatter_to_pool`, not zeros.
- **`get_supported_configs()` `native_backward`** (Track JA.2) — now `"ext"` (was
  `False`); STEEL backward kernels have been active since v0.9.0.

---

## [1.0.5] — 2026-03-08

### Added
- **`flash_attention_kvcache` append mode** — new `k_new` / `v_new` keyword-only
  parameters let callers concatenate new tokens onto the KV cache and attend in
  one call: `flash_attention_kvcache(q, k_cache, v_cache, k_new=k_new, v_new=v_new)`
  returns `(output, k_updated, v_updated)`. Supports RoPE via explicit
  `_apply_rope_to_qk` rotation of `q` and `k_new` before concatenation (avoids
  double-rotating the already pre-rotated cache). 9 new tests in
  `TestKVCacheAppendUnified`.
- **`get_supported_configs()` feature matrix** — `features` key is now a 22-entry
  boolean dict covering every runtime capability (`causal`, `gqa`, `rope`, `d512`,
  `paged_kv`, `flash_decode`, `alibi`, `softcap`, `attn_bias`, `backend_select`,
  `native_backward`, `sparse_backward`, `m3_routing`, `m5_stub`, etc.). Applications
  can query capabilities without version checks. `kernel_types` key returns 8.

### Fixed
- **`window_size` right boundary** — `flash_attention(..., window_size=(left, right))`
  with `right > 0` now raises `NotImplementedError` instead of silently ignoring
  the right-side bound. The STEEL kernel only implements left-only sliding windows.
  `right = 0` and `right = -1` are accepted as "no right bound". 4 new tests.
- **Varlen D=512 TGP guard** — `flash_attention_varlen` no longer attempts the
  STEEL varlen kernel for D=512 (would exceed 32 KB TGP). Added `D <= 256` guard;
  D=512 falls back correctly to split-concat + SDPA. 1 new test.
- **Paged STEEL D=512 guard** — same fix applied to the paged STEEL path.
- **Docstrings** — all head_dim references updated from `{64, 128, 256}` to
  `{64, 128, 256, 512}` in `flash_attention`, module docstring, and `__init__.py`.
- **CHANGELOG** — corrected ABI warning description from "raises RuntimeError" to
  "emits RuntimeWarning" (the actual behaviour of `_check_abi()`).

### Changed
- **`_apply_rope_to_qk` helper** — new internal function isolates the pure-rotation
  step from attention dispatch; replaces duplicate `_apply_rope_mlx` call pairs at
  two sites (`_apply_rope_and_attend`, `flash_attention_kvcache`).
- **`flash_attention_with_kv_cache` removed** — deprecated since v1.0.1;
  fully removed from `attention.py`, `__init__.py`, `__all__`, tests, and
  documentation. Use `flash_attention_kvcache(q, k_cache, v_cache, k_new=k_new,
  v_new=v_new)` instead.

### Tests
- **385 tests pass** (up from 374 at v1.0.4). +11 new tests; removed
  `TestKVCacheAppend` (4 tests, now superseded by `TestKVCacheAppendUnified`).

---

## [1.0.4] — 2026-03-08

### Added
- **`attn_bias` parameter in `flash_attention`** (Track ID): optional float
  tensor broadcastable to `[B,H,N,S]` added to attention scores before softmax.
  Useful for padding masks, relative position encodings, etc. Routes through
  `mx.fast.scaled_dot_product_attention` (MFA kernel has no generic bias buffer).
- **`backend` parameter in `flash_attention`** (Track ID): `"auto"` (default),
  `"mfa"` (force Metal kernel, raises if unavailable), `"sdpa"` (always SDPA).
- **Paged backward dK/dV** (Track IF): `flash_attention_paged()` now computes
  real `dK_pages` / `dV_pages` via `_scatter_to_pool()` instead of zeros.
  Scatters per-sequence contiguous gradients back to `[num_blocks, bs, H_kv, D]`
  pool format using the block_table metadata.

### Fixed
- **Native sparse backward buffer aliasing** (Track IC): `backward="steel_sparse"`
  in `flash_attention_sparse()` now copies all inputs through numpy before calling
  the Metal backward kernel. MLX's autograd engine recycles primal GPU buffers
  during the backward pass; custom Metal primitives read those recycled buffers
  and produce wrong results without this workaround. All 6
  `TestSparseBackwardSteel` tests now pass.

### Internal
- **`PagedKVCache` MLX-native pool** (Track IA): pool storage migrated from
  numpy `float32` backing arrays to `mx.array`. Eliminates the CPU round-trip
  on every token append; `k_pool` / `v_pool` stay on GPU throughout.
- **ABI version check** (Track IB): `_check_abi()` called at import time;
  emits `RuntimeWarning` when the C++ extension ABI version does not match the
  installed MLX minor version, preventing silent correctness failures.
- **`_apply_rope_and_attend` helper** (Track IE): unifies the 5-line
  `_apply_rope_mlx` × 2 + `_fallback_sdpa` pattern shared by
  `flash_attention_rope()` and the `_make_mfa_rope_custom` backward.
- **374 tests pass** (up from 358 at v1.0.3). +16 new tests covering
  `attn_bias`, `backend`, dK/dV paged scatter, and sparse backward correctness.

---

## [1.0.3] — 2026-03-06

### Added
- **D=512 head_dim support** — forward and backward STEEL kernels now support
  `head_dim=512`. Both `flash_attention()` and `mx.vjp()` through it work
  correctly for f16/bf16, causal/non-causal, GQA, and unaligned sequence lengths.
- **D_SPLITS generalization** — `BD_HALF` in dQ and dKV backward generators
  is now fixed at 128 (not `BD/2`), and `D_SPLITS = BD / 128`. Metal loops
  over `[MFA_D_SPLITS]` tile arrays are fully unrolled at compile time, enabling
  any `head_dim` that is a multiple of 128 (64, 128, 256, 512).
- **13 new tests**: `TestD512Forward` (8) + `TestD512Backward` (5).

**350 tests pass.**

---

## [1.0.2] — 2026-03-06

### Changed
- **Build system**: added `mlx>=0.18.0` to `[build-system] requires` so MLX headers
  are available to the C++ extension during isolated `pip install` builds (e.g. CI,
  `--no-build-isolation` no longer required for a clean sdist install).
- **Version bump**: 1.0.1 → 1.0.2 (pyproject.toml, `__init__.py`, `csrc/bindings.cpp`).

**337 tests pass.** No API or kernel changes.

---

## [1.0.1] — 2026-03-06

### Fixed / Improved

| Track | Description | New tests |
|-------|-------------|-----------|
| GA | **PagedKVCache rewrite** — dual numpy float32 backing stores (was K-only, V never stored); `append()` uses block-level slice writes (was per-element Python loop); working `gather()` (was `NotImplementedError`); `k_pool`/`v_pool` properties with lazy cached `mx.array` views; `get_block_table()`/`get_seq_lens()` for direct use with paged STEEL kernel | 13 |
| GB | **`patch_mlx_lm` diagnostics** — `verbose=False` silent mode; `get_patch_stats()` returns `{forward_calls, steel_calls, fallback_calls, steel_ratio}`; `check_model_compatibility(model_name)` heuristic dict without loading the model; stats reset on each fresh `patch_mlx_lm()` | 17 |
| GC | **Deprecation notes** — `flash_attention_with_kv_cache` marked `.. deprecated:: 1.0.1` in docstring; removal target v2.0 | — |

**337 tests pass.** No kernel changes (no C++/Metal modifications).

---

## [1.0.0] — 2026-03-06

### Highlights

First stable public release. All features from v1.0.0-rc1 and v1.0.0-rc2.

| Track | Description | Tests added |
|-------|-------------|-------------|
| FA | Unified KV-cache API (`flash_attention_kvcache`) | 17 |
| FB | Native sliding-window in STEEL kernel | 4 |
| FC | Fused RoPE cache append (`flash_attention_kvcache_rope_append`) | 3 |
| FD | Kernel-level paged KV STEEL forward + Flash Decode | 15 |
| FX | `return_lse`, `cache_batch_idx`, `rotary_dim` | 8 |

**307 tests pass.** Full Python API with 33 public exports.

### Package
- First PyPI release: `pip install mlx-mfa`
- `pyproject.toml`: `Development Status :: 5 - Production/Stable`, `numpy` added to dependencies
- `MANIFEST.in`: adds `examples/`, `CHANGELOG.md`, `csrc/mfa/`
- `examples/`: 5 practical scripts covering all major API paths

See `[1.0.0-rc1]` and `[1.0.0-rc2]` below for the complete feature details.

---

## [1.0.0-rc2] — 2026-03-06

### Added
- **Track FD: Kernel-level paged KV streaming in STEEL forward kernel** — Metal kernel
  `mlx_mfa_paged_attention` reads K/V tiles directly from the `[num_blocks, block_size,
  H_kv, D]` pool via cooperative `block_table` lookup, eliminating a separate gather
  Metal dispatch. New `KernelType::PagedSteelForward`, `MFAPagedSteelParams`,
  `generate_paged_steel_forward_source()`, `MFAPagedSteelForward` Primitive, and
  `mfa_paged_steel_forward` nanobind binding. GQA, causal, sliding window all supported.
  `flash_attention_paged()` routes to the kernel for f16/bf16 D∈{64,128,256}.
  Benchmark (M1 Max, f16, B=1 H=8 D=128): **1.26–1.58x** faster than gather+attend.
- **Track FD-decode: Paged Flash Decode path** — For decode steps (N_q ≤ 4, S ≥ 256),
  `flash_attention_paged()` routes through Metal gather + `flash_attention()`, which
  activates the existing split-KV Flash Decode two-phase kernel for better SM parallelism.
- **Track FD-bench: `benchmarks/bench_paged_kv.py`** — Three-way comparison:
  gather+attend vs kernel-level paged STEEL vs pre-gathered Flash Decode.
- **307 tests pass** (up from 292 in rc1): 11 `TestPagedSteelForward` + 4
  `TestPagedFlashDecode`.

### Changed
- (infra) `has_window` added to `KernelKey` hash/equality; `window_left` wired into
  `MFASteelParams` — prerequisite for Track FD kernel dispatch.

---

## [1.0.0-rc1] — 2026-03-06

### Added
- **Track FB: Native sliding window in STEEL kernel** — `window_left` param in
  `MFASteelParams`; `has_window` KernelKey flag; K-tile `kb_start` computed per
  Q-block inside the persistent loop; boundary tiles apply element-wise mask.
  Fixed multi-tile boundary bug (only first boundary tile was masked), NaN-safe
  online softmax (all-masked-tile guard), and test reference `qL_off` alignment.
  `flash_attention(..., window_size=(left, right))` public API. 4 tests.
- **Track FA: Unified KV cache API** — `flash_attention_kvcache(q, k_cache, v_cache, ...)`
  replaces fragmented `with_kv_cache` / `paged` / `rope` paths. Dense + paged modes,
  RoPE, softcap, ALiBi, sliding window, `cache_seqlens`, `cache_batch_idx`. 17 tests.
- **Track FX-1: `return_lse` in `flash_attention`** — Expose logsumexp `L [B,H,N]`
  (log2 domain) alongside output when requested. MFA path uses `mfa_forward_with_lse`
  (free); fallback materialises log2-domain LSE via pure-MLX ops. 4 tests.
- **Track FX-2: `cache_batch_idx` in `flash_attention_kvcache`** — Non-contiguous
  batch→cache-slot mapping for continuous batching; `k_cache[cache_batch_idx]` gather
  before attention dispatch. 2 tests.
- **Track FX-3: `rotary_dim` partial RoPE** — Rotate only first `rotary_dim` dims;
  remainder passes through unchanged. STEEL kernel forces MLX fallback when
  `rotary_dim < head_dim`. 2 tests.
- **Track FC: Fused RoPE in cache append** — `flash_attention_kvcache_rope_append`
  rotates `k_new` BEFORE concat, storing pre-rotated keys in cache. O(1) rotation
  cost per decode step vs O(past_len) for naive re-rotation. `benchmarks/bench_kvcache.py`
  added for A/B comparison. 3 tests.

### Tests
Total collected: **292**

---

## [0.9.3] — 2026-03-06

### Added
- **Track EA: Differentiable `flash_attention_varlen`** — `mx.custom_function`
  wrapper adds full autograd. Forward: STEEL varlen kernel (f16/bf16, D=64/128/256);
  backward: splits per sequence through `flash_attention`. `TestVarlenBackward` (6 tests).
- **Track EB: Metal paged KV gather kernel** — `MFAPagedKVGather` Primitive
  gathers pool pages to `[B, H, max_kv_len, D]` in a single Metal dispatch.
  `flash_attention_paged` rewritten with `mx.custom_function`: `dQ` correct via
  `vjp(flash_attention)`; pool gradients are zeros (cache buffers).
  `TestPagedBackward` (6 tests).
- **Track EC: Varlen packed formats** — `flash_attention_varlen_qkv_packed` and
  `flash_attention_varlen_kv_packed` accept head-first or flat fused tensors and
  route to `flash_attention_varlen`. `TestVarlenPacked` (4 tests).
- **Track ED: Documentation refresh** — `docs/ARCHITECTURE.md` rewritten to 476 lines:
  updated backward routing tree (STEEL bwd / SDPA vjp / compiled vjp), new §8 (STEEL
  native backward — FA-2 log2 domain, GQA `gqa_factor`, D=256 three-phase D-split),
  new §9 (varlen backward via `mx.custom_function`), new §10 (paged KV gather — Metal
  kernel pseudocode, forward/backward flow, per-seq slicing rationale), expanded Public
  API table to all 31 exports. `docs/INVENTORY.md` regenerated from scratch: all line
  counts verified with `wc -l`, 31 `__all__` exports, 10 KernelType entries, 7 C++
  Primitive classes, 257 pytest runs / 212 test functions, 40 test classes, 10
  benchmarks. `README.md`: API Reference expanded from 7 to all 31 exports (param
  tables for core attention functions; compact reference table for 13 mask builders);
  Features section updated with v0.9.2–v0.9.3 additions.

### Tests
Total collected: **257 pytest runs / 212 test functions** (EA adds 6, EB adds 6, EC adds 4).

---

## [0.9.2] — 2026-03-06

### Added
- **Track DA: GQA backward guard fix** — Removed incorrect Python guard that blocked
  STEEL backward dispatch for grouped-query attention (H_q ≠ H_kv). The STEEL kernels
  have supported GQA since v0.9.0 via the `gqa_factor` Metal define; the Python
  `use_steel_bwd` predicate now correctly allows GQA shapes through.
- **Track DC: `mx.compile` for `_apply_rope_mlx`** — Shape-keyed compile cache
  (`_rope_compile_cache`) with separate `_impl` closures for interleaved and
  non-interleaved layouts. Scalars `offset` and `interleaved` are frozen in the
  closure to avoid dynamic control flow in the compiled graph. Median speedup ≈1.4×
  over the raw Python fallback (measured in `bench_compile.py`).
- **Track DC: `benchmarks/bench_compile.py`** — New benchmark (50-iteration median)
  comparing compiled vs raw latency for `_softcap_sdpa_ref`, `_alibi_sdpa_ref`, and
  `_apply_rope_mlx` (interleaved + non-interleaved) at N=2048 D=128 f16.
- **Track CE: D=256 D-split STEEL backward** — `generate_steel_backward_dq_source()`
  and `generate_steel_backward_dkv_source()` now emit D-split Metal code when
  `head_dim=256` (`BD_HALF=128`). Q/dO/K/V tiles are loaded in lo (0..127) and
  hi (128..255) passes sharing one threadgroup buffer; dQ/dK/dV accumulators become
  lo/hi register-tile pairs. TGP budget ≈ 23 KB (well below 32 KB limit). The
  `use_steel_bwd` guard is widened from `D ≤ 128` to `D ≤ 256`.
- **Track DD: Documentation refresh** — `docs/INVENTORY.md` updated to v0.9.2:
  test count 241, benchmark count 9, backward strategy table, DA–DE additions table.
  CE row in v0.9.1 table updated from "deferred" to "completed in v0.9.2".

### Fixed
- **Track DB: CHANGELOG inaccuracies** — v0.9.1 entry for Track CB now correctly states
  `_apply_rope_mlx` was NOT compiled in v0.9.1 (completed in Track DC / v0.9.2).
  Test count corrected to 232.

---

## [0.9.1] — 2026-03-06

### Added
- **Track CA: Vec4 block loads** — `MFABlockLoaderT` uses `float4`/`half4` aligned
  vector reads for all tile loads in the STEEL forward kernel, reducing instruction
  count per tile by 4× on cache-line-aligned data.
- **Track CB: `mx.compile` for fallback paths** — The Python fallback routes
  (`_softcap_sdpa_ref`, `_alibi_sdpa_ref`) are wrapped with `mx.compile`.
  `_apply_rope_mlx` and the sparse/varlen fallbacks are NOT yet compiled
  (completed in Track DC / v0.9.2).
- **Track CC: Persistent multi-Q-block kernel** — The STEEL forward kernel now iterates
  over an outer `qb` loop (`[0, NQ)`) within a single threadgroup dispatch, processing
  up to 4 Q-blocks per launch. Amortizes Metal command buffer overhead at N ≥ 4096.
- **Track CD: GQA in STEEL backward** — The STEEL dQ and dKV backward kernels now
  handle grouped-query attention.  The `gqa_factor` (H_q / H_kv) is baked into the
  Metal shader as `#define MFA_GQA_FACTOR <N>` at compile time, avoiding Metal
  `constant`-address-space struct-field read ambiguity.  `KernelKey` extended with
  `gqa_factor` so each GQA ratio compiles to a distinct cached pipeline.
- **Track CF: Double-buffer ping-pong** — Separate `K_smem` / `V_smem` threadgroup
  arrays when D ≤ 128 (TGP ≈ 19.2 KB < 32 KB limit).  Reduces barriers per K-tile
  from 4 → 2: V-tile stores overlap K-GEMM; K[n+1]-tile stores overlap P@V.
  Phase-0 preloads K[0] before the loop; `loader_k/v.next()` called inline.
  Disabled for D=256 (budget), RoPE (extra TGP), and sparse.
- **Track CG: `benchmarks/bench_all.py`** — Consolidated forward + backward benchmark
  suite (`--fwd-only`, `--bwd-only`, `--no-save` flags).  Appends markdown results
  table to `docs/benchmarks/RESULTS.md`.
- **Track CH: Documentation refresh** — `docs/INVENTORY.md` updated to v0.9.1
  (test count 232, benchmark count 8, kernel table, CA–CI additions table).
  `docs/ARCHITECTURE.md` adds notes on CF double-buffer and CC persistent kernel.
  `README.md` roadmap updated: N1 marked Done (v0.9.0); CA/CB/CC/CD/CF rows added.

### Deferred
- **Track CE: D=256 backward multi-pass** — 3D blocking for the STEEL dQ/dKV
  backward kernels (analogous to the forward D=256 path) is deferred to v1.0.
  D=256 backward continues to route to `mx.vjp(SDPA)` (same as v0.9.0).

---

## [0.9.0] — 2026-03-06

### Added
- **Track BA/BB/BC: STEEL native backward** — `mx.grad(flash_attention)` now dispatches
  native Metal STEEL backward kernels (`MFASteelBwdDQ`, `MFASteelBwdDKV`) for f16/bf16
  instead of `mx.vjp(SDPA)`. 2-3× backward speedup on D=64/128. f32 stays on ccv path.
  Key fixes: `Ktile[1,MFA_TK]` tile declaration (was 1×1, causing UB for ik>0) and
  `_sever_lazy_graph(cotangent)` before gradient checkpointing re-run of forward
  (prevents Metal buffer aliasing via lazy graph ancestry). 209 tests pass.
- **Track BD: STEEL varlen forward kernel** — `flash_attention_varlen` dispatches a
  dedicated Metal STEEL kernel instead of Python split-cat. Packed Q/K/V layout
  `[1, H, N_total, D]` with `cu_seqlens` offsets; per-threadgroup batch-item decode.
  Critical race-condition fix: `threadgroup_barrier` at START of K-loop prevents
  P@V reads (V from KV_smem) from racing against next iteration's K write.
  K-boundary `-INF` mask prevents softmax denominator inflation for partial K-tiles.
  215 tests pass.
- **Track BE: Paged KV Cache Phase 1** — `PagedKVCache` block allocator with pool
  `[num_blocks, block_size, H_kv, D]`; per-seq block table; `append`/`free_seq` helpers.
  `flash_attention_paged(q, k_pool, v_pool, block_table, seq_lens, ...)` reconstructs
  contiguous K/V per batch item via block-table gather, routes to `flash_attention`.
- **Track BF: QKV/KV packed tensor formats** — `flash_attention_qkv_packed` handles
  flat `[B, N, 3·H·D]` and head-first `[B, H, N, 3, D]` packed layouts.
  `flash_attention_kv_packed` handles `[B, S, 2·H·D]` and `[B, H, S, 2, D]`.
  Both raise `ValueError` for unsupported shapes.
- **Track BG: Backward benchmark** — `benchmarks/bench_backward.py` measures
  flash_attention VJP vs SDPA VJP across D=64/128, f16/bf16, causal/non-causal.
- **Track BH: Varlen benchmark update** — `benchmarks/bench_varlen.py` updated to
  note STEEL varlen kernel; section header updated to v0.9.0.
- **Tests: 232 pytest runs** (180+16 test functions; 232 with parametrize expansion)

## [0.8.0] — 2026-03-05

### Added
- **Track AA: Softcap** — `flash_attention(..., softcap=50.0)` applies `tanh(S/cap)*cap`
  before softmax; fused into Metal STEEL kernel for f16/bf16, Python fallback for f32.
- **Track AB: ALiBi** — `flash_attention_alibi(q, k, v, alibi_slopes, ...)` adds
  per-head linear position biases (slope_h × (k_pos − q_pos)). Metal kernel fuses
  bias into the QK tile accumulation; Python reference fallback included.
- **Track AC: RoPE non-interleaved (GPT-NeoX)** — `flash_attention_rope(..., interleaved=False)`
  supports split-halves RoPE layout `(d, d+D/2)` in addition to LLaMA adjacent pairs.
  Metal kernel and Python `_apply_rope_mlx` both branch on `interleaved`.
- **Track AD: Per-batch `cache_seqlens`** — `flash_attention_rope` now accepts
  `cache_seqlens` as a `list[int]`, `mx.array`, or `int`. Per-element dispatch via
  Python split-cat; MLX lazy eval fuses concurrent GPU dispatches.
- **Track AE: Graceful D_v ≠ D_qk fallback** — When `v.shape[-1] != q.shape[-1]`,
  routes to `mx.fast.scaled_dot_product_attention` instead of raising. K dimension
  must still equal Q (raises `ValueError` otherwise).
- **Track AF: `flash_attention_with_kv_cache`** — Fused KV cache append:
  `(output, k_updated, v_updated) = flash_attention_with_kv_cache(q, k_new, v_new, k_cache, v_cache)`.
  Concatenates along the sequence axis, dispatches one attention call.
- **Track AG: Attention dropout** — `flash_attention(..., dropout_p=0.2)` drops
  softmax weights during training. Uses `mx.where` causal masking to avoid
  `0.0 × −inf = NaN` in the masked region.
- **Track AH: Return attention weights** — `flash_attention(..., return_attn_weights=True)`
  returns `(output, attn_weights)` where weights are the full softmax probability matrix
  `[B, H, N, S]`. Compatible with softcap and dropout.
- **Track Z: Benchmark scripts** — `benchmarks/bench_softcap_alibi.py` measures
  softcap and ALiBi overhead vs SDPA baseline across four variants.
- **Tests: 209 total** (up from 93 in v0.4.0)

### Changed
- `flash_attention_rope` now accepts `Union[int, mx.array, Sequence[int]]` for `cache_seqlens`

## [0.7.0] — 2026-03-05

### Added
- **Track O: Spatial 2D/3D block masks** — `make_spatial_2d_mask`, `make_spatial_3d_mask`, `make_topk_spatial_mask`
- **Track P: Segment / document masks** — `make_segment_mask`, `make_causal_segment_mask`
- **Track Q: Adaptive window mask** — `make_adaptive_window_mask` (SeedVSR2-style resolution-scaled windows)
- **Track R: 3D RoPE table construction** — `make_rope_3d_tables` + `flash_attention_rope(rope_3d=...)` dict API
- **Track S: Variable-length batching** — `flash_attention_varlen` (split-concat implementation)
- **Track T: 4 benchmark scripts** — spatial masks, segment, varlen, 3D RoPE
- Pure Python release — no Metal kernel changes
- Tests: ~150 total


## [0.6.0] — 2026-03-05

### Added
- **Track K: Quantized KV cache** — Q4/Q8 dequantized before STEEL kernel
- **Track L: RoPE 1D fusion** — `flash_attention_rope()` with in-kernel rotary embeddings
- **Track M: Paged Attention design doc** — `docs/PAGED_ATTENTION_DESIGN.md`


## [0.5.0] — 2026-03-05

### Added
- **Flash Decoding (Track H)** — Two-phase split-KV attention for decode mode
  (N_q ≤ 4, S ≥ 256, f16/bf16). Phase 1 dispatches KV-sequence splits in
  parallel; Phase 2 reduces partial outputs via log-sum-exp. Activated
  automatically for eligible shapes.
  - New KernelType variants: `FlashDecodePartial`, `FlashDecodeReduce`
  - New params structs: `FlashDecodePartialParams`, `FlashDecodeReduceParams`
  - `compute_num_splits(kL, BK)` — targets ≥2 K-tiles per split, capped at 32
  - 11 new tests: non-causal/causal across D=64/128/256, GQA, bf16, boundary cases

- **M5+ detection stub (Track I)** — Forward-compatibility for Apple M5 (gen≥17,
  A19 SoC with Metal 4 tensor API)
  - `get_device_info()` now returns `is_m5_plus` (bool)
  - Gen 17 → `"M5"` chip name in `_GEN_TO_CHIP` mapping
  - `TensorOpsForward` KernelType reserved as commented stub in `shader_cache.hpp`
  - 3 new tests covering flag correctness, chip name, and M5 ⊇ M3+ logic

### Fixed
- `enc.barrier()` replaces `enc.maybeInsertBarrier()` between Flash Decode
  Phase 1 and Phase 2 — `maybeInsertBarrier()` is a no-op for raw
  `MTL::Buffer*` bindings (only `set_output_array()` sets `needs_barrier_`)
- `qL_off = S - N` for causal decode so query token at position `i` correctly
  sees keys `0..(S - N + i)` instead of starting from key 0

### Tests
- 107 tests total (was 93)

---

## [0.4.0] — 2026-02-xx

### Added
- **Track F** — M3+ architecture routing: BK=32 for D=128 on M3/M4 (gen≥15),
  `MFA_FORCE_GEN` env var override, `ARCHITECTURE_GEN` #define in Metal shader
- **Track G** — Sparse backward pass: tiled FA-2 dQ/dK/dV that skips inactive
  blocks; `flash_attention_sparse(backward='sdpa_sparse')` public API
- **Track C** — Native GQA: removed `mx.repeat` expansion, STEEL kernel handles
  `gqa_factor` natively in the Metal shader

### Tests
- 93 tests total (was 63)

---

## [0.3.0] — 2026-01-xx

### Added
- **Track D** — mlx-lm integration: `patch_mlx_lm()` / `unpatch_mlx_lm()`
- Native GQA support in STEEL kernel (gqa_factor parameter)
- `make_causal_block_mask()`, `make_sliding_window_mask()` public helpers
- mlx-lm integration tests (11 tests)

---

## [0.2.0] — 2025-12-xx

### Added
- **Track B** — Block-sparse attention: `flash_attention_sparse(q, k, v, mask)`
- Sparse STEEL kernel variant (K-loop skip, zero warp divergence)
- Sliding-window mask giving 3–6× speedup at long contexts

### Performance (M1 Max, B=1 H=8 f16, causal)
| D | N | Speedup |
|---|---|---------|
| 64 | 8192 | 2.11× SDPA |
| 128 | 8192 | 1.72× SDPA |
| 128 N=8192 sliding-window=512 | | 5.7× SDPA |

---

## [0.1.0] — 2025-11-xx

### Added
- Initial release: STEEL forward kernel replacing ccv-based MFA
- Full forward pass (D=64/128/256, f16/bf16/f32, causal/non-causal)
- Backward via `mx.vjp(scaled_dot_product_attention)`
- GQA via `mx.repeat` expand (later replaced by native GQA in v0.3)
- Public API: `flash_attention()`, `is_mfa_available()`, `get_device_info()`
- 41 tests
