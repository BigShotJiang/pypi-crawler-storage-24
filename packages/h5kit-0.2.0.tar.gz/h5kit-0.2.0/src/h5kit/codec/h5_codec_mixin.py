from __future__ import annotations
from typing import ClassVar
from h5kit.aid.typevars import T
from h5kit.codec.h5_codec_layout import H5CodecLayout
from h5kit.codec.h5_codec_layout_ops import assert_layout_is_empty, clear_layout
from h5kit.codec.read_utils import require_obj_auto, require_obj_typed
from h5kit.io.h5reader import H5Reader
from h5kit.io.h5writer import H5Writer


class H5CodecMixin:
    LAYOUT: ClassVar[H5CodecLayout]
    VER: ClassVar[int]

    @classmethod
    def clear_before_write(cls, w: H5Writer) -> None:
        clear_layout(w, cls.LAYOUT)

    @classmethod
    def assert_clean_before_write(cls, w: H5Writer) -> None:
        assert_layout_is_empty(w, cls.LAYOUT)

    @classmethod
    def require_obj_auto(cls, r: H5Reader, key: str):
        return require_obj_auto(r, key=key, registry=r.registry, codec_name=cls.__name__)

    @classmethod
    def require_obj_typed(cls, r: H5Reader, key: str, typ: type[T]) -> T:
        return require_obj_typed(r, key=key, typ=typ, registry=r.registry,codec_name=cls.__name__)