from __future__ import annotations

from typing import TYPE_CHECKING

from h5kit.codec.h5_codec_layout import H5CodecLayout

if TYPE_CHECKING:
    from h5kit.io.h5writer import H5Writer


def find_layout_collisions(w: H5Writer, layout: H5CodecLayout) -> list[str]:
    collisions: list[str] = []

    for key in layout.children:
        if key in w.grp:
            collisions.append(f"child:{key}")

    for key in layout.all_attrs:
        if key in w.grp.attrs:
            collisions.append(f"attr:{key}")

    return collisions


def assert_layout_is_empty(w: H5Writer, layout: H5CodecLayout) -> None:
    collisions = find_layout_collisions(w, layout)
    if collisions:
        joined = ", ".join(collisions)
        raise ValueError(f"group '{w.grp.name}' already contains codec output keys: {joined}")


def clear_layout(w: H5Writer, layout: H5CodecLayout) -> None:
    for key in layout.children:
        if key in w.grp:
            del w.grp[key]

    for key in layout.all_attrs:
        if key in w.grp.attrs:
            del w.grp.attrs[key]