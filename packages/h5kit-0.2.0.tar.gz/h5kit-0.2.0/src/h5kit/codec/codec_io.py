from __future__ import annotations
from typing import TYPE_CHECKING
from h5kit.aid.aliases import H5CodecClassT, T
from h5kit.codec.codec_header import read_header, require_version, write_header
from h5kit.io.h5_write_policy import H5WritePolicy
if TYPE_CHECKING:
    from h5kit.io.h5reader import H5Reader
    from h5kit.io.h5writer import H5Writer

def write_codec_object(
    w: H5Writer,
    name: str,
    obj: T | None,
    codec: H5CodecClassT,
    *,
    policy: H5WritePolicy = H5WritePolicy.REPLACE,
) -> None:
    grp = w.group(name, policy=policy)
    write_header(grp, schema=codec.SCHEMA, ver=int(codec.VER), is_none=obj is None)
    if obj is not None:
        codec.write(grp, obj)

def read_codec_object(r: H5Reader, name: str, codec: H5CodecClassT) -> T | None:
    grp = r.group(name)
    hdr = read_header(grp)
    require_version(hdr, expected_schema=codec.SCHEMA, expected_ver=int(codec.VER))
    if hdr.is_none:
        return None
    return codec.read(grp)