from __future__ import annotations

from typing import TYPE_CHECKING, Any, ClassVar, Protocol

from h5kit.aid.aliases import T
from h5kit.codec.h5_codec_layout import H5CodecLayout

if TYPE_CHECKING:
    from h5kit.io.h5reader import H5Reader
    from h5kit.io.h5writer import H5Writer


class H5CodecLike(Protocol[T]):
    PY_TYPE: ClassVar[type[Any]]
    SCHEMA: ClassVar[str]
    VER: ClassVar[int]
    LAYOUT: ClassVar[H5CodecLayout]

    @classmethod
    def write(cls, w: H5Writer, obj: T) -> None: ...

    @classmethod
    def read(cls, r: H5Reader) -> T: ...