from __future__ import annotations
from typing import TYPE_CHECKING
import numpy as np
from h5kit.aid.aliases import T
from h5kit.codec.codec_io import read_codec_object
from h5kit.io.registry_io import read_registered_object
from h5kit.register.codec_registry import CodecRegistry

if TYPE_CHECKING:
    from h5kit.io.h5reader import H5Reader

def require_obj_auto(r: H5Reader, key: str, *, registry: CodecRegistry, codec_name: str):
    try:
        value = read_registered_object(r, key, registry=registry)
    except Exception as exc:
        raise ValueError(f"{codec_name}: failed to read '{key}'") from exc

    if value is None:
        raise ValueError(f"{codec_name}: '{key}' is missing or stored as None")
    return value

def require_obj_typed(r: H5Reader, key: str, typ: type[T], *, registry: CodecRegistry,codec_name: str) -> T:
    codec = registry.require_by_type(typ)
    try:
        value = read_codec_object(r, key, codec)
    except Exception as exc:
        raise ValueError(f"{codec_name}: failed to read '{key}' as {typ.__name__}") from exc

    if value is None:
        raise ValueError(f"{codec_name}: '{key}' is missing or stored as None (expected {typ.__name__})")
    if not isinstance(value, typ):
        raise ValueError(f"{codec_name}: '{key}' has unexpected type {type(value).__name__}, expected {typ.__name__}")
    return value