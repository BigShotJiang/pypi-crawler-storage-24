from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class H5CodecLayout:
    datasets: tuple[str, ...] = ()
    groups: tuple[str, ...] = ()
    attrs: tuple[str, ...] = ()

    optional_datasets: tuple[str, ...] = ()
    optional_groups: tuple[str, ...] = ()
    optional_attrs: tuple[str, ...] = ()

    @property
    def children(self) -> tuple[str, ...]:
        return (
            *self.datasets,
            *self.groups,
            *self.optional_datasets,
            *self.optional_groups,
        )

    @property
    def required_children(self) -> tuple[str, ...]:
        return *self.datasets, *self.groups

    @property
    def all_attrs(self) -> tuple[str, ...]:
        return *self.attrs, *self.optional_attrs

    @property
    def all_keys(self) -> tuple[str, ...]:
        return (
            *self.datasets,
            *self.groups,
            *self.attrs,
            *self.optional_datasets,
            *self.optional_groups,
            *self.optional_attrs,
        )