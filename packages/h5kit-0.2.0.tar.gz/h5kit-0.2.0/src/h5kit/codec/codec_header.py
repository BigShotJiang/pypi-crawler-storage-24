from __future__ import annotations
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from h5kit.io.h5reader import H5Reader
    from h5kit.io.h5writer import H5Writer

class CodecHeader:
    KEY_SCHEMA: str = "__schema__"
    KEY_VER:    str = "__schema_ver__"
    KEY_NONE:   str = "__is_none__"

@dataclass(frozen=True, slots=True)
class Header:
    schema: str
    ver: int
    is_none: bool

def write_header(w: H5Writer, *, schema: str, ver: int, is_none: bool) -> None:
    w.attr(CodecHeader.KEY_SCHEMA, schema)
    w.attr(CodecHeader.KEY_VER, int(ver))
    w.attr(CodecHeader.KEY_NONE, 1 if is_none else 0)

def read_header(r: H5Reader) -> Header:
    schema = str(r.require_attr(CodecHeader.KEY_SCHEMA))
    ver = int(r.require_attr(CodecHeader.KEY_VER))
    is_none = bool(int(r.attr(CodecHeader.KEY_NONE, 0)))
    return Header(schema=schema, ver=ver, is_none=is_none)

def require_version(header: Header, *, expected_schema: str, expected_ver: int) -> None:
    if header.schema != expected_schema:
        raise ValueError(f"Unsupported schema: {header.schema!r} (expected {expected_schema!r})")
    if header.ver != int(expected_ver):
        raise ValueError(f"Unsupported schema version for {expected_schema!r}: {header.ver} "
            f"(expected {expected_ver})")
