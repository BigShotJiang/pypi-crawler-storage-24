from __future__ import annotations

from enum import Enum
from typing import TypeVar

from h5kit.codec.h5_codec_layout import H5CodecLayout

E = TypeVar("E", bound=Enum)


def make_enum_codec(
    enum_cls: type[E],
    *,
    schema: str | None = None,
    ver: int = 1,
) -> type:
    schema_name = schema or f"{enum_cls.__module__}.{enum_cls.__qualname__}"

    class EnumCodec:
        PY_TYPE = enum_cls
        SCHEMA = schema_name
        VER = int(ver)
        KEY = enum_cls.__name__
        LAYOUT = H5CodecLayout(attrs=("name",))

        @classmethod
        def write(cls, w, obj: E) -> None:
            w.attr("name", obj.name)

        @classmethod
        def read(cls, r) -> E:
            name = r.require_attr("name")
            if not isinstance(name, str):
                raise ValueError(
                    f"{cls.__name__}: attr 'name' must be str, got {type(name).__name__}"
                )
            try:
                return enum_cls[name]
            except KeyError as exc:
                raise ValueError(
                    f"{cls.__name__}: unknown enum member {name!r} for {enum_cls.__name__}"
                ) from exc

    EnumCodec.__name__ = f"{enum_cls.__name__}Codec"
    EnumCodec.__qualname__ = EnumCodec.__name__
    EnumCodec.__module__ = enum_cls.__module__

    return EnumCodec