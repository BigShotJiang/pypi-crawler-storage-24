from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any
from h5kit.aid.aliases import H5CodecClass


@dataclass(slots=True)
class CodecRegistry:
    _by_schema: dict[str, H5CodecClass] = field(default_factory=dict)
    _by_type: dict[type[Any], H5CodecClass] = field(default_factory=dict)

    def register(
        self,
        codec: H5CodecClass,
        *,
        py_type: type[Any] | None = None,
        overwrite: bool = False,
    ) -> None:
        schema = getattr(codec, "SCHEMA", None)
        ver = getattr(codec, "VER", None)

        if not isinstance(schema, str) or not schema:
            raise TypeError("Codec must define SCHEMA: str (non-empty)")
        if not isinstance(ver, int):
            raise TypeError("Codec must define VER: int")

        if not overwrite and schema in self._by_schema:
            prev = self._by_schema[schema]
            raise ValueError(
                f"Codec for schema {schema!r} already registered: {prev!r}. "
                f"Pass overwrite=True to replace."
            )

        self._by_schema[schema] = codec

        if py_type is not None:
            if not overwrite and py_type in self._by_type:
                prev = self._by_type[py_type]
                raise ValueError(
                    f"Codec for type {py_type!r} already registered: {prev!r}. "
                    f"Pass overwrite=True to replace."
                )
            self._by_type[py_type] = codec

    def get(self, schema: str) -> H5CodecClass | None:
        return self._by_schema.get(schema)

    def require(self, schema: str) -> H5CodecClass:
        codec = self.get(schema)
        if codec is None:
            raise KeyError(f"No codec registered for schema {schema!r}")
        return codec

    def get_by_type(self, py_type: type[Any]) -> H5CodecClass | None:
        codec = self._by_type.get(py_type)
        if codec is not None:
            return codec

        for base in py_type.__mro__[1:]:
            codec = self._by_type.get(base)
            if codec is not None:
                return codec

        return None

    def require_by_type(self, py_type: type[Any]) -> H5CodecClass:
        codec = self.get_by_type(py_type)
        if codec is None:
            raise KeyError(f"No codec registered for type {py_type!r}")
        return codec