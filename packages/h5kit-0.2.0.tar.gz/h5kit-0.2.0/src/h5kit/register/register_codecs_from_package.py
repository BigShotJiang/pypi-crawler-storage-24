from __future__ import annotations
import importlib
import inspect
import logging
import pkgutil
from collections.abc import Iterator
from types import ModuleType
from typing import Any

from h5kit.register.validate_codec import validate_codec_class
from h5kit.codec.h5_codec_like import H5CodecLike

logger = logging.getLogger(__name__)


def iter_codec_classes(module: ModuleType) -> Iterator[type[H5CodecLike[Any]]]:
    logger.debug("Scanning module: %s", module.__name__)

    for name, obj in inspect.getmembers(module, inspect.isclass):
        if obj.__module__ != module.__name__:
            logger.debug("Skip (imported class): %s.%s", module.__name__, name)
            continue

        if getattr(obj, "__h5_codec__", False) is not True:
            logger.debug("Skip (not marked as codec): %s.%s", module.__name__, name)
            continue

        logger.debug("Candidate codec found: %s.%s", module.__name__, name)
        yield validate_codec_class(obj)


def register_codecs_from_package(registry, package_name: str) -> None:
    logger.info("Registering codecs from package: %s", package_name)

    try:
        package = importlib.import_module(package_name)
    except Exception:
        logger.exception("Failed to import package: %s", package_name)
        raise

    modules: list[ModuleType] = [package]

    if hasattr(package, "__path__"):
        for _, modname, _ in pkgutil.walk_packages(package.__path__, package.__name__ + "."):
            try:
                module = importlib.import_module(modname)
                modules.append(module)
                logger.debug("Imported module: %s", modname)
            except Exception:
                logger.exception("Failed to import module: %s", modname)
                raise
    else:
        logger.debug("Package has no __path__ (single module): %s", package_name)

    total_registered = 0

    for module in modules:
        for codec_cls in iter_codec_classes(module):
            try:
                registry.register(codec_cls, py_type=codec_cls.PY_TYPE)
                total_registered += 1

                logger.info("Registered codec: %s (schema=%s, ver=%s)",
                    codec_cls.__name__,
                    getattr(codec_cls, "SCHEMA", "?"),
                    getattr(codec_cls, "VER", "?"),
                )
            except Exception:
                logger.exception("Failed to register codec: %s.%s",module.__name__,codec_cls.__name__)
                raise

    logger.info("Finished registering codecs from %s: %d codecs",package_name,total_registered)