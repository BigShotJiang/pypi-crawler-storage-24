from __future__ import annotations
from typing import Any, cast
from h5kit.codec.h5_codec_like import H5CodecLike
from h5kit.codec.h5_codec_layout import H5CodecLayout

def validate_codec_class(cls: type[Any]) -> type[H5CodecLike[Any]]:
    schema = getattr(cls, "SCHEMA", None)
    ver = getattr(cls, "VER", None)
    write = getattr(cls, "write", None)
    read = getattr(cls, "read", None)

    if not isinstance(schema, str) or not schema:
        raise TypeError(f"{cls.__module__}.{cls.__name__}: invalid SCHEMA")
    if not isinstance(ver, int):
        raise TypeError(f"{cls.__module__}.{cls.__name__}: invalid VER")
    if not callable(write):
        raise TypeError(f"{cls.__module__}.{cls.__name__}: missing write()")
    if not callable(read):
        raise TypeError(f"{cls.__module__}.{cls.__name__}: missing read()")

    py_type = getattr(cls, "PY_TYPE", None)
    if not isinstance(py_type, type):
        raise TypeError(f"{cls.__module__}.{cls.__name__}: missing PY_TYPE")

    layout = getattr(cls, "LAYOUT", None)
    if not isinstance(layout, H5CodecLayout):
        raise TypeError(f"{cls.__name__}: LAYOUT must be H5CodecLayout")

    if not callable(getattr(cls, "write", None)):
        raise TypeError(f"{cls.__name__}: write() is missing")

    if not callable(getattr(cls, "read", None)):
        raise TypeError(f"{cls.__name__}: read() is missing")

    return cast(type[H5CodecLike[Any]], cls)