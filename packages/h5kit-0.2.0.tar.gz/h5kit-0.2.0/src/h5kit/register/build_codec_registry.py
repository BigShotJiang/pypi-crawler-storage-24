from __future__ import annotations

from collections.abc import Iterable

from h5kit.register.codec_registry import CodecRegistry
from h5kit.register.register_codecs_from_package import register_codecs_from_package


def build_codec_registry(codec_packages: str | Iterable[str]) -> CodecRegistry:
    registry = CodecRegistry()

    if isinstance(codec_packages, str):
        package_names = [codec_packages]
    else:
        package_names = list(codec_packages)

    for package_name in package_names:
        register_codecs_from_package(registry, package_name)

    return registry