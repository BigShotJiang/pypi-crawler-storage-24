from __future__ import annotations
from h5kit.aid.typevars import TCodec
from h5kit.register.validate_codec import validate_codec_class

def codec(cls: TCodec) -> TCodec:
    validate_codec_class(cls)
    setattr(cls, "__h5_codec__", True)
    return cls