from typing import Any, Mapping
from h5kit.aid.normalize_attr_value import normalize_attr_value

def write_attrs(h5obj: Any, attrs: Mapping[str, Any] | None) -> None:
    if not attrs:
        return
    for k, v in attrs.items():
        h5obj.attrs[k] = normalize_attr_value(v)
