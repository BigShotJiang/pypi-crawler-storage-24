from __future__ import annotations
from typing import Tuple


def suggest_chunks(shape: Tuple[int, ...]) -> Tuple[int, ...]:
    if len(shape) == 0:
        return ()
    if len(shape) == 1:
        return shape
    f_ndim = len(shape) - 2
    return (1,) * f_ndim + (shape[-2], shape[-1])