from typing import TypeVar


T = TypeVar("T")
TCodec = TypeVar("TCodec", bound=type)
