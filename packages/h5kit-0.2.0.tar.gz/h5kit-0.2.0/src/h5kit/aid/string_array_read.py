from __future__ import annotations

import h5py
import numpy as np


def string_array_read(group: h5py.Group, name: str) -> list[str]:
    if name not in group:
        raise KeyError(f"Dataset '{name}' not found in group '{group.name}'")

    data = group[name][()]
    arr = np.asarray(data)

    if arr.ndim == 0:
        v = arr.item()
        if isinstance(v, bytes):
            return [v.decode("utf-8")]
        return [str(v)]

    result: list[str] = []
    for v in arr:
        if isinstance(v, bytes):
            result.append(v.decode("utf-8"))
        else:
            result.append(str(v))
    return result