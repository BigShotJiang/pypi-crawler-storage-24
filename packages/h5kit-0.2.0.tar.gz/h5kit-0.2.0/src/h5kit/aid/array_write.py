from __future__ import annotations

from typing import Any, Mapping

import h5py
import numpy as np

from h5kit.aid.create_or_overwrite import prepare_child
from h5kit.aid.suggest_chunks import suggest_chunks
from h5kit.aid.write_attrs import write_attrs
from h5kit.io.h5_write_policy import H5WritePolicy

def array_write(
    group: h5py.Group,
    name: str,
    array: np.ndarray,
    *,
    compression: str | None = "gzip",
    compression_opts: int | None = 4,
    chunks: tuple[int, ...] | None = None,
    attrs: Mapping[str, Any] | None = None,
    policy: H5WritePolicy = H5WritePolicy.REPLACE,
) -> h5py.Dataset:
    if not isinstance(array, np.ndarray):
        raise TypeError(f"Expected np.ndarray, got {type(array)}")
    existing = prepare_child(group, name, policy=policy)

    if existing is not None:
        del group[name]

    is_empty = any(dim == 0 for dim in array.shape)

    if chunks is None and not is_empty:
        chunks = suggest_chunks(array.shape)

    kwargs: dict[str, Any] = {}

    if chunks is not None:
        kwargs["chunks"] = chunks

    if not is_empty and compression is not None:
        kwargs["compression"] = compression
        if compression_opts is not None:
            kwargs["compression_opts"] = compression_opts

    ds = group.create_dataset(name, data=array, **kwargs)
    write_attrs(ds, attrs)
    return ds