from __future__ import annotations
import enum
import numpy as np
from dataclasses import fields, is_dataclass
from typing import Any, Sequence, TYPE_CHECKING
from h5kit.aid.aliases import DATACLASS_LIST_CLS, DATACLASS_LIST_LEN, DATACLASS_LIST_NONE_SUFFIX

if TYPE_CHECKING:
    from h5kit.io.h5writer import H5Writer

def _is_enum_instance(v: object) -> bool:
    return isinstance(v, enum.Enum)


def _none_mask_name(field_name: str) -> str:
    return f"{field_name}{DATACLASS_LIST_NONE_SUFFIX}"


def dataclass_list_write(w: H5Writer, objs: Sequence[Any], *, cls: type[Any] | None = None,skip_none: bool = True) -> None:
    if len(objs) == 0:
        if cls is None:
            raise ValueError("dataclass_list_write: cls is required when objs is empty")
        if not is_dataclass(cls):
            raise TypeError(f"dataclass_list_write: cls must be a dataclass type, got {cls!r}")

        w.attr(DATACLASS_LIST_CLS, f"{cls.__module__}.{cls.__qualname__}")
        w.attr(DATACLASS_LIST_LEN, 0)
        return

    first = objs[0]
    if not is_dataclass(first):
        raise TypeError(f"dataclass_list_write: expected dataclass instances, got {type(first)!r}")

    inferred_cls = type(first)

    if cls is None:
        cls = inferred_cls
    else:
        if not is_dataclass(cls):
            raise TypeError(f"dataclass_list_write: cls must be a dataclass type, got {cls!r}")
        if cls is not inferred_cls:
            raise TypeError(f"dataclass_list_write: cls={cls!r} does not match object type {inferred_cls!r}")

    if not all(type(o) is cls for o in objs):
        bad_types = sorted({type(o).__name__ for o in objs if type(o) is not cls})
        raise TypeError(f"dataclass_list_write: all objects must have exact type {cls.__name__}, got mixed types including {bad_types}")

    n = len(objs)
    w.attr(DATACLASS_LIST_CLS, f"{cls.__module__}.{cls.__qualname__}")
    w.attr(DATACLASS_LIST_LEN, n)

    for f in fields(cls):
        name = f.name
        vals = [getattr(o, name) for o in objs]
        none_mask = np.asarray([v is None for v in vals], dtype=np.bool_)

        all_none = bool(np.all(none_mask))
        any_none = bool(np.any(none_mask))

        if all_none:
            if not skip_none:
                w.array(_none_mask_name(name), none_mask)
            continue

        non_none_vals = [v for v in vals if v is not None]
        v0 = non_none_vals[0]

        if any_none:
            w.array(_none_mask_name(name), none_mask)

        # str
        if isinstance(v0, str):
            data = ["" if v is None else str(v) for v in vals]
            w.strings(name, data)
            continue

        # ndarray
        if isinstance(v0, np.ndarray):
            if any(v is None for v in vals):
                template = np.asarray(v0)
                filled = [
                    np.zeros_like(template) if v is None else np.asarray(v)
                    for v in vals
                ]
            else:
                filled = [np.asarray(v) for v in vals]

            shapes = {tuple(x.shape) for x in filled}
            if len(shapes) != 1:
                raise ValueError(f"Field {name!r}: all ndarray values must have the same shape")

            data = np.stack(filled, axis=0)
            w.array(name, data)
            continue

        # numeric / bool / numpy scalar
        if isinstance(v0, (int, float, bool, np.generic)):
            if any_none:
                if isinstance(v0, (bool, np.bool_)):
                    fill_value = False
                elif isinstance(v0, (int, np.integer)):
                    fill_value = 0
                else:
                    fill_value = np.nan
                data = np.asarray([fill_value if v is None else v for v in vals])
            else:
                data = np.asarray(vals)

            w.array(name, data)
            continue

        # enum
        if _is_enum_instance(v0):
            base_vals = [None if v is None else v.value for v in vals]
            base0 = v0.value

            if isinstance(base0, str):
                data = ["" if v is None else str(v) for v in base_vals]
                w.strings(name, data)
            else:
                if any_none:
                    if isinstance(base0, (bool, np.bool_)):
                        fill_value = False
                    elif isinstance(base0, (int, np.integer)):
                        fill_value = 0
                    else:
                        fill_value = np.nan
                    data = np.asarray([fill_value if v is None else v for v in base_vals])
                else:
                    data = np.asarray(base_vals)

                w.array(name, data)
            continue
        raise TypeError(
            f"Field {name!r}: unsupported field type {type(v0)!r}. "
            "Supported types: str, ndarray, numeric, bool, numpy scalar, enum."
        )