from typing import TypeAlias,Any, TYPE_CHECKING
from h5kit.aid.typevars import T
if TYPE_CHECKING:
    from h5kit.codec.h5_codec_like import H5CodecLike

DATACLASS_LIST_CLS = "dataclass_cls"
DATACLASS_LIST_LEN = "dataclass_len"
DATACLASS_LIST_NONE_SUFFIX = "__is_none"

H5CodecClass: TypeAlias = "H5CodecLike[Any]"
H5CodecClassT: TypeAlias = "H5CodecLike[T]"


