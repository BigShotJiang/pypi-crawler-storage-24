from __future__ import annotations

from typing import Any, Mapping, Sequence

import h5py
import numpy as np

from h5kit.aid.create_or_overwrite import prepare_child
from h5kit.aid.write_attrs import write_attrs
from h5kit.io.h5_write_policy import H5WritePolicy


def string_array_write(
    group: h5py.Group,
    name: str,
    values: Sequence[str],
    *,
    compression: str | None = "gzip",
    attrs: Mapping[str, Any] | None = None,
    policy: H5WritePolicy = H5WritePolicy.REPLACE,
) -> h5py.Dataset:
    dt = h5py.string_dtype(encoding="utf-8")  # type: ignore[attr-defined]
    data = np.asarray(values, dtype=dt)

    existing = prepare_child(group, name, policy=policy)

    # dataset-level MERGE == REPLACE
    if existing is not None:
        del group[name]

    ds = group.create_dataset(name, data=data, compression=compression)
    write_attrs(ds, attrs)
    return ds