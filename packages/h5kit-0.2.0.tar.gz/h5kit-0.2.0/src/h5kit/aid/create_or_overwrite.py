from __future__ import annotations

import h5py

from h5kit.io.h5_write_policy import H5WritePolicy


def prepare_child(
    group: h5py.Group,
    name: str,
    *,
    policy: H5WritePolicy,
) -> h5py.Group | h5py.Dataset | None:
    if name not in group:
        return None

    if policy == H5WritePolicy.FAIL:
        raise KeyError(f"Node {name!r} already exists in group {group.name!r}")

    if policy == H5WritePolicy.REPLACE:
        del group[name]
        return None

    if policy == H5WritePolicy.MERGE:
        return group[name]

    raise ValueError(f"Unsupported write policy: {policy!r}")