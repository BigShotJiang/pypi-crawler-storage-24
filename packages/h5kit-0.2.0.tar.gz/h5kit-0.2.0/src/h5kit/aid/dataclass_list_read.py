from __future__ import annotations

import enum
from dataclasses import fields, is_dataclass
from importlib import import_module
from typing import TYPE_CHECKING, get_args, get_type_hints

import h5py
import numpy as np

from h5kit.aid.aliases import (
    DATACLASS_LIST_CLS,
    DATACLASS_LIST_LEN,
    DATACLASS_LIST_NONE_SUFFIX,
    T,
)

if TYPE_CHECKING:
    from h5kit.io.h5reader import H5Reader


def _import_class(full_name: str) -> type[T]:
    module_name, cls_name = full_name.rsplit(".", 1)
    module = import_module(module_name)
    return getattr(module, cls_name)


def _enum_class_from_type(tp: object) -> type[enum.Enum] | None:
    try:
        if isinstance(tp, type) and issubclass(tp, enum.Enum):
            return tp
    except TypeError:
        pass

    for arg in get_args(tp):
        try:
            if isinstance(arg, type) and issubclass(arg, enum.Enum):
                return arg
        except TypeError:
            continue

    return None


def _none_mask_name(field_name: str) -> str:
    return f"{field_name}{DATACLASS_LIST_NONE_SUFFIX}"


def _read_none_mask(r: H5Reader, field_name: str, n_items: int) -> np.ndarray | None:
    mask_name = _none_mask_name(field_name)
    if mask_name not in r.grp:
        return None

    mask = np.asarray(r.grp[mask_name][()], dtype=np.bool_)
    if mask.ndim != 1 or mask.shape[0] != n_items:
        raise ValueError(
            f"Field {field_name!r}: invalid None-mask shape {mask.shape}, expected ({n_items},)"
        )
    return mask


def dataclass_list_read(r: H5Reader) -> list[T]:
    cls_name = r.require_attr(DATACLASS_LIST_CLS)
    cls = _import_class(cls_name)

    if not is_dataclass(cls):
        raise TypeError(f"dataclass_list_read expects a dataclass type, got {cls!r}")

    n_items = int(r.require_attr(DATACLASS_LIST_LEN))
    type_hints = get_type_hints(cls)

    result: list[T] = []

    for i in range(n_items):
        kwargs: dict[str, object] = {}

        for f in fields(cls):
            name = f.name
            field_type = type_hints.get(name, f.type)

            has_data = name in r.grp
            none_mask = _read_none_mask(r, name, n_items)

            if not has_data:
                kwargs[name] = None
                continue

            obj = r.grp[name]
            if not isinstance(obj, h5py.Dataset):
                raise TypeError(f"Field {name!r} must be a dataset, got {type(obj)!r}")

            data = np.asarray(obj[()])
            if data.ndim == 0:
                raise ValueError(f"Field {name!r}: scalar dataset is not allowed in dataclass_list")
            if data.shape[0] != n_items:
                raise ValueError(f"Field {name!r}: invalid length {data.shape[0]}, expected {n_items}")

            is_none = none_mask is not None and bool(none_mask[i])
            if is_none:
                kwargs[name] = None
                continue

            v = data[i]

            if isinstance(v, np.generic):
                v = v.item()

            if isinstance(v, (bytes, bytearray)):
                v = v.decode("utf-8")

            enum_cls = _enum_class_from_type(field_type)
            if enum_cls is not None and v is not None:
                v = enum_cls(v)

            kwargs[name] = v

        result.append(cls(**kwargs))

    return result