from __future__ import annotations
from typing import Any
import numpy as np

def normalize_attr_value(
    v: Any,
    *,
    decode_bytes: bool = True,
    encoding: str = "utf-8",
    errors: str = "replace",
) -> Any:
    if v is None:
        return None

    # 0-d ndarray -> scalar
    if isinstance(v, np.ndarray) and v.shape == ():
        return normalize_attr_value(v[()], decode_bytes=decode_bytes, encoding=encoding, errors=errors)

    # numpy scalar -> python scalar
    if isinstance(v, np.generic):
        return normalize_attr_value(v.item(), decode_bytes=decode_bytes, encoding=encoding, errors=errors)

    # bytes -> str
    if isinstance(v, (bytes, bytearray, memoryview)):
        b = bytes(v)
        return b.decode(encoding, errors=errors) if decode_bytes else b

    # ndarray (non-scalar) -> python list (elementwise normalized)
    if isinstance(v, np.ndarray):
        return [normalize_attr_value(x, decode_bytes=decode_bytes, encoding=encoding, errors=errors) for x in v.tolist()]

    # container normalization (rare but nice)
    if isinstance(v, list):
        return [normalize_attr_value(x, decode_bytes=decode_bytes, encoding=encoding, errors=errors) for x in v]
    if isinstance(v, tuple):
        return tuple(normalize_attr_value(x, decode_bytes=decode_bytes, encoding=encoding, errors=errors) for x in v)
    if isinstance(v, dict):
        return {
            normalize_attr_value(k, decode_bytes=decode_bytes, encoding=encoding, errors=errors):
            normalize_attr_value(val, decode_bytes=decode_bytes, encoding=encoding, errors=errors)
            for k, val in v.items()
        }

    return v