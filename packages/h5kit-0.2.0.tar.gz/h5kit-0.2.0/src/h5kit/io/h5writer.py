from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Mapping, Sequence, Callable
import h5py
import numpy as np
from h5kit.aid.array_write import array_write
from h5kit.aid.create_or_overwrite import prepare_child
from h5kit.aid.dataclass_list_write import dataclass_list_write
from h5kit.aid.normalize_attr_value import normalize_attr_value
from h5kit.aid.string_array_write import string_array_write
from h5kit.io.h5_write_policy import H5WritePolicy
from h5kit.register import CodecRegistry


@dataclass(slots=True)
class H5Writer:
    grp: h5py.Group
    registry: CodecRegistry
    compression: str | None = "gzip"
    policy: H5WritePolicy = H5WritePolicy.REPLACE

    def __post_init__(self) -> None:
        if self.registry is None:
            raise ValueError("H5Writer: registry must not be None")

    def group(self, name: str, *, policy: H5WritePolicy | None = None) -> H5Writer:
        effective = self.policy if policy is None else policy
        existing = prepare_child(self.grp, name, policy=effective)
        if existing is None:
            grp = self.grp.create_group(name)
        else:
            grp = existing
        if not isinstance(grp, h5py.Group):
            raise TypeError(f"Node {name!r} exists in {self.grp.name!r}, but is not a group")
        return H5Writer(grp, registry=self.registry, compression=self.compression, policy=effective)

    def attr(self, key: str, value: Any) -> None:
        self.grp.attrs[key] = normalize_attr_value(value, decode_bytes=False)

    def attr_if_not_none(self,key: str,value: Any,*,transform: Callable[[Any], Any] | None = None) -> None:
        if value is None:
            return
        if transform is not None:
            value = transform(value)
        self.attr(key, value)

    def array(
        self,
        key: str,
        data: Any,
        *,
        compression: str | None = None,
        compression_opts: int | None = 4,
        chunks: tuple[int, ...] | None = None,
        attrs: Mapping[str, Any] | None = None,
        policy: H5WritePolicy | None = None,
    ) -> h5py.Dataset:
        arr = np.asarray(data)
        return array_write(
            self.grp,
            key,
            arr,
            compression=self.compression if compression is None else compression,
            compression_opts=compression_opts,
            chunks=chunks,
            attrs=attrs,
            policy=self.policy if policy is None else policy)

    def scalar(
        self,
        key: str,
        value: Any,
        *,
        policy: H5WritePolicy | None = None,
    ) -> h5py.Dataset:
        effective = self.policy if policy is None else policy
        existing = prepare_child(self.grp, key, policy=effective)
        if existing is not None:
            del self.grp[key]
        return self.grp.create_dataset(key, data=np.asarray(value))

    def strings(
        self,
        key: str,
        values: Sequence[str],
        *,
        attrs: Mapping[str, Any] | None = None,
        policy: H5WritePolicy | None = None,
    ) -> h5py.Dataset:
        return string_array_write(
            self.grp,
            key,
            values,
            compression=self.compression,
            attrs=attrs,
            policy=self.policy if policy is None else policy)

    def dataclass_list(self, objs: Sequence[Any], *, cls: type[Any] | None = None, skip_none: bool = True) -> None:
        dataclass_list_write(self, objs, cls=cls, skip_none=skip_none)