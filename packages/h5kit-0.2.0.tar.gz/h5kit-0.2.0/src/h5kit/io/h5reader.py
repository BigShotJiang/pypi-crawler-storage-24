from __future__ import annotations
import h5py
import numpy as np
from dataclasses import dataclass
from typing import Any, Callable
from h5kit.aid.dataclass_list_read import dataclass_list_read
from h5kit.aid.normalize_attr_value import normalize_attr_value
from h5kit.aid.string_array_read import string_array_read
from h5kit.register.codec_registry import CodecRegistry


@dataclass(slots=True)
class H5Reader:
    grp: h5py.Group
    registry: CodecRegistry

    def __post_init__(self) -> None:
        if self.registry is None:
            raise ValueError("H5Reader: registry must not be None")

    def _get_group(self, name: str) -> h5py.Group | None:
        obj = self.grp.get(name)
        if obj is None:
            return None
        if not isinstance(obj, h5py.Group):
            raise TypeError(f"Child {name!r} in {self.grp.name!r} is not a group")
        return obj

    def group(self, name: str) -> H5Reader | None:
        obj = self._get_group(name)
        if obj is None:
            return None
        return H5Reader(obj, registry=self.registry)

    def require_group(self, name: str) -> H5Reader:
        obj = self._get_group(name)
        if obj is None:
            raise KeyError(f"Group {name!r} not found in {self.grp.name!r}")
        return H5Reader(obj, registry=self.registry)

    def attr(
            self,
            key: str,
            default: Any = None,
            *,
            transform: Callable[[Any], Any] | None = None,
    ) -> Any:
        if key not in self.grp.attrs:
            return default

        value = normalize_attr_value(self.grp.attrs[key])
        if value is None:
            return None

        return transform(value) if transform is not None else value


    def require_attr(
            self,
            key: str,
            *,
            transform: Callable[[Any], Any] | None = None,
    ) -> Any:
        if key not in self.grp.attrs:
            raise ValueError(f"group '{self.grp.name}' has no attr '{key}'")

        value = normalize_attr_value(self.grp.attrs[key])
        if value is None:
            return None

        return transform(value) if transform is not None else value


    def ndarray(self, key: str) -> np.ndarray | None:
        if key not in self.grp:
            return None
        ds = self.grp[key]
        if not isinstance(ds, h5py.Dataset):
            return None
        return np.asarray(ds[()])

    def require_ndarray(self, key: str) -> np.ndarray:
        value = self.ndarray(key)
        if value is None:
            raise ValueError(f"group '{self.grp.name}' has no ndarray '{key}'")
        return value

    def scalar(self, key: str) -> Any:
        if key not in self.grp:
            raise KeyError(f"Dataset {key!r} not found in group {self.grp.name!r}")
        ds = self.grp[key]
        if not isinstance(ds, h5py.Dataset):
            raise TypeError(f"Child {key!r} in group {self.grp.name!r} is not a dataset")
        return normalize_attr_value(ds[()])

    def strings(self, key: str) -> list[str]:
        return string_array_read(self.grp, key)

    def dataclass_list(self) -> list[Any]:
        return dataclass_list_read(self)