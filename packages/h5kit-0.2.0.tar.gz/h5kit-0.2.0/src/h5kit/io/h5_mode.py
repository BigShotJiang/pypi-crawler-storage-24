from enum import Enum

class H5Mode(str, Enum):
    READ = "r"
    READ_WRITE = "r+"
    WRITE = "w"          # truncate if exists
    WRITE_EXCL = "w-"    # fail if exists
    CREATE_EXCL = "x"    # same idea as w- (supported by h5py)
    APPEND = "a"