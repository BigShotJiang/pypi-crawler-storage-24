from __future__ import annotations
from pathlib import Path
from typing import Any
import h5py
from h5kit.aid.aliases import H5CodecClassT, T
from h5kit.codec.codec_io import read_codec_object, write_codec_object
from h5kit.io.h5_mode import H5Mode
from h5kit.io.h5reader import H5Reader
from h5kit.io.h5writer import H5Writer
from h5kit.io.h5_write_policy import H5WritePolicy
from h5kit.register.codec_registry import CodecRegistry


def h5_save(
    path: Path,
    obj: Any,
    codec: H5CodecClassT,
    *,
    registry: CodecRegistry,
    root_name: str = "root",
    mode: H5Mode = H5Mode.WRITE,
    policy: H5WritePolicy = H5WritePolicy.REPLACE,
    use_lock: bool = False,
) -> None:
    def _do_write() -> None:
        with h5py.File(path, mode=mode.value) as f:
            write_codec_object(H5Writer(f, registry=registry, policy=policy),root_name,obj,codec,policy=policy)
    if not use_lock:
        _do_write()
        return
    from filelock import FileLock
    with FileLock(str(path) + ".lock"):
        _do_write()


def h5_load(
    path: Path,
    codec: H5CodecClassT,
    *,
    registry: CodecRegistry,
    root_name: str = "root",
) -> T | None:
    with h5py.File(path) as f:
        return read_codec_object(H5Reader(f, registry=registry), root_name, codec)