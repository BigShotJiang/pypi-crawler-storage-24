from __future__ import annotations
from pathlib import Path
from typing import Protocol, Self



class H5Compatible(Protocol):
    def save_to_h5(self, path: str | Path) -> None: ...

    @classmethod
    def load_from_h5(cls, path: str | Path) -> Self: ...