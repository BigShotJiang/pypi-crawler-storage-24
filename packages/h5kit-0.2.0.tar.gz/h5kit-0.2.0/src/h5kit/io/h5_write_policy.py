from __future__ import annotations

from enum import StrEnum


class H5WritePolicy(StrEnum):
    FAIL = "fail"
    REPLACE = "replace"
    MERGE = "merge"