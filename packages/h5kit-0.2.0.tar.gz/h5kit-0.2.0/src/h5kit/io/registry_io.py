from __future__ import annotations
from pathlib import Path
from typing import Any
from h5kit.aid.aliases import H5CodecClass
from h5kit.codec.codec_io import read_codec_object, write_codec_object
from h5kit.io.file_api import h5_load, h5_save
from h5kit.io.h5_mode import H5Mode
from h5kit.io.h5reader import H5Reader
from h5kit.io.h5writer import H5Writer
from h5kit.io.h5_write_policy import H5WritePolicy
from h5kit.register.codec_registry import CodecRegistry

def default_root_name(py_type: type[Any]) -> str:
    return py_type.__name__


def write_registered_object(
    w: H5Writer,
    name: str,
    obj: Any,
    *,
    registry: CodecRegistry,
    py_type: type[Any] | None = None,
    policy: H5WritePolicy = H5WritePolicy.REPLACE,
) -> None:
    actual_type = py_type if obj is None else type(obj)
    if actual_type is None:
        raise ValueError("py_type is required when obj is None")
    codec = registry.require_by_type(actual_type)
    write_codec_object(w, name, obj, codec, policy=policy)


def read_registered_object(r: H5Reader, name: str, *, registry: CodecRegistry) -> Any:
    grp = r.group(name)

    from h5kit.codec.codec_header import read_header
    hdr = read_header(grp)

    codec = registry.require(hdr.schema)

    return read_codec_object(r, name, codec)


def save_to_h5(
    path: Path,
    obj: object,
    *,
    registry: CodecRegistry,
    mode: H5Mode = H5Mode.WRITE,
    root_name: str | None = None,
) -> None:
    py_type = type(obj)
    codec = registry.require_by_type(py_type)
    actual_root_name = default_root_name(py_type) if root_name is None else root_name
    h5_save(
        path,
        obj,
        codec=codec,
        registry=registry,
        root_name=actual_root_name,
        mode=mode)


def load_from_h5(
    path: Path,
    py_type: type[Any],
    *,
    registry: CodecRegistry,
    root_name: str | None = None,
) -> Any:
    codec = registry.require_by_type(py_type)
    actual_root_name = default_root_name(py_type) if root_name is None else root_name
    obj = h5_load(
        path,
        codec=codec,
        registry=registry,
        root_name=actual_root_name)
    if obj is None:
        raise ValueError(f"Stored object is None: {path}:{actual_root_name}")
    return obj