from __future__ import annotations

import logging
from dataclasses import dataclass
from pathlib import Path

from allytools.logger import run_with_logging

from h5kit.aid.aliases import T
from h5kit.io.h5_mode import H5Mode
from h5kit.io.registry_io import load_from_h5, save_to_h5
from h5kit.register.codec_registry import CodecRegistry

log = logging.getLogger(__name__)


@dataclass(slots=True)
class H5IOManager:
    registry: CodecRegistry

    def __post_init__(self) -> None:
        if self.registry is None:
            raise ValueError("H5IOManager: registry must not be None")

    def save(
        self,
        path: str | Path,
        obj: object,
        *,
        mode: H5Mode = H5Mode.WRITE,
        root_name: str | None = None,
    ) -> None:
        h5_path = Path(path)
        obj_type = type(obj).__name__

        def _op() -> None:
            save_to_h5(
                h5_path,
                obj,
                registry=self.registry,
                mode=mode,
                root_name=root_name,
            )

        run_with_logging(
            op=_op,
            start_msg="H5 write started: path=%s obj_type=%s mode=%s root_name=%s",
            end_msg="H5 write finished: path=%s obj_type=%s elapsed_s=%.3f",
            fail_msg="H5 write failed: path=%s obj_type=%s elapsed_s=%.3f",
            start_args=(h5_path, obj_type, mode.name, root_name),
            end_args=(h5_path, obj_type),
            fail_args=(h5_path, obj_type),
        )

    def load(
        self,
        path: str | Path,
        py_type: type[T],
        *,
        root_name: str | None = None,
    ) -> T:
        h5_path = Path(path)

        def _op() -> T:
            return load_from_h5(
                h5_path,
                py_type,
                registry=self.registry,
                root_name=root_name,
            )

        return run_with_logging(
            op=_op,
            start_msg="H5 load started: path=%s py_type=%s root_name=%s",
            end_msg="H5 load finished: path=%s py_type=%s elapsed_s=%.3f",
            fail_msg="H5 load failed: path=%s py_type=%s elapsed_s=%.3f",
            start_args=(h5_path, py_type.__name__, root_name),
            end_args=(h5_path, py_type.__name__),
            fail_args=(h5_path, py_type.__name__),
        )