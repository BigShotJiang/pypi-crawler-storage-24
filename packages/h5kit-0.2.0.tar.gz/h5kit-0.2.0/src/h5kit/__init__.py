from h5kit.register.codec import codec
from h5kit.codec.h5_codec_like import H5CodecLike
from h5kit.io import H5Reader, H5Writer
__all__ = ["codec", "H5CodecLike","H5Reader", "H5Writer"]
