from __future__ import annotations
from h5kit.codec.h5_codec_layout import H5CodecLayout

def assert_matches_h5_layout(root, layout: H5CodecLayout) -> None:
    for key in layout.datasets:
        assert key in root, f"missing dataset: {key}"

    for key in layout.groups:
        assert key in root, f"missing group: {key}"

    for key in layout.attrs:
        assert key in root.attrs, f"missing attr: {key}"