from __future__ import annotations
from dataclasses import dataclass
from typing import Callable, Generic
from h5kit.aid.typevars import T
from h5kit.io.h5writer import H5Writer
from h5kit.io.h5reader import H5Reader

@dataclass(frozen=True)
class CodecHarness(Generic[T]):
    write: Callable[[H5Writer, T], None]
    read: Callable[[H5Reader], T]


def roundtrip(h5file, codec: CodecHarness[T], obj: T, *, registry, group: str = "x") -> T:
    grp = h5file.require_group(group)
    codec.write(H5Writer(grp, registry=registry), obj)
    return codec.read(H5Reader(grp, registry=registry))