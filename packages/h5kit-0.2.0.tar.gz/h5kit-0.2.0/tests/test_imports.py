
from __future__ import annotations

import importlib



def test_direct_h5writer_import_works():
    mod = importlib.import_module('h5kit.io.h5writer')
    assert hasattr(mod, 'H5Writer')


def test_direct_h5reader_import_works():
    mod = importlib.import_module('h5kit.io.h5reader')
    assert hasattr(mod, 'H5Reader')


def test_package_import_h5kit_io():
    importlib.import_module('h5kit.io')


def test_codec_io_import():
    mod = importlib.import_module('h5kit.codec.io')
    assert hasattr(mod, 'write')
    assert hasattr(mod, 'read')


def test_file_api_import():
    mod = importlib.import_module('h5kit.io.file_api')
    assert hasattr(mod, 'h5_save')
    assert hasattr(mod, 'h5_load')
