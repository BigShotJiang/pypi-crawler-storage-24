from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
import h5py
import numpy as np
import pytest
from h5kit.io.h5reader import H5Reader
from h5kit.io.h5writer import H5Writer


class Mode(Enum):
    A = 'a'
    B = 'b'


@dataclass(frozen=True)
class Item:
    idx: int
    value: float | None
    name: str | None
    payload: np.ndarray | None
    flag: bool
    mode: Mode | None


def test_dataclass_list_roundtrip(tmp_path):
    path = tmp_path / 'items.h5'
    items = [
        Item(1, 1.5, 'first', np.array([1, 2, 3], dtype=np.int32), True, Mode.A),
        Item(2, None, None, None, False, None),
        Item(3, 3.5, 'third', np.array([7, 8, 9], dtype=np.int32), True, Mode.B),
    ]

    with h5py.File(path, 'w') as f:
        H5Writer(f).dataclass_list('items', items)

    with h5py.File(path, 'r') as f:
        loaded = H5Reader(f).dataclass_list('items')

    assert len(loaded) == 3
    assert loaded[0].idx == 1
    assert loaded[0].value == 1.5
    assert loaded[0].name == 'first'
    np.testing.assert_array_equal(loaded[0].payload, np.array([1, 2, 3], dtype=np.int32))
    assert loaded[0].flag is True
    assert loaded[0].mode == Mode.A

    assert loaded[1].idx == 2
    assert loaded[1].value is None
    assert loaded[1].name is None
    assert loaded[1].payload is None
    assert loaded[1].flag is False
    assert loaded[1].mode is None

    assert loaded[2].idx == 3
    assert loaded[2].value == 3.5
    assert loaded[2].name == 'third'
    np.testing.assert_array_equal(loaded[2].payload, np.array([7, 8, 9], dtype=np.int32))
    assert loaded[2].flag is True
    assert loaded[2].mode == Mode.B


def test_dataclass_list_empty_requires_cls_on_write(tmp_path):
    path = tmp_path / 'empty.h5'
    with h5py.File(path, 'w') as f:
        with pytest.raises(ValueError, match='cls is required when objs is empty'):
            H5Writer(f).dataclass_list('items', [])


def test_dataclass_list_empty_roundtrip_with_cls(tmp_path):
    path = tmp_path / 'empty_ok.h5'
    with h5py.File(path, 'w') as f:
        H5Writer(f).dataclass_list('items', [], cls=Item)

    with h5py.File(path, 'r') as f:
        loaded = H5Reader(f).dataclass_list('items')

    assert loaded == []


def test_dataclass_list_rejects_mixed_types(tmp_path):
    @dataclass(frozen=True)
    class Other:
        idx: int

    path = tmp_path / 'mixed.h5'
    with h5py.File(path, 'w') as f:
        with pytest.raises(TypeError, match='all objects must have exact type'):
            H5Writer(f).dataclass_list('items', [Item(1, 1.0, 'x', None, True, Mode.A), Other(2)])


def test_dataclass_list_rejects_mismatched_ndarray_shapes(tmp_path):
    path = tmp_path / 'bad_shape.h5'
    items = [
        Item(1, 1.0, 'x', np.array([1, 2]), True, Mode.A),
        Item(2, 2.0, 'y', np.array([1, 2, 3]), False, Mode.B),
    ]
    with h5py.File(path, 'w') as f:
        with pytest.raises(ValueError, match='all ndarray values must have the same shape'):
            H5Writer(f).dataclass_list('items', items)
