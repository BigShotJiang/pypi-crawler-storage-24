# `mubit-langchain`

LangChain `BaseMemory` backed by [MuBit](https://mubit.ai).

This adapter provides `BaseMemory` and chat-oriented subclasses that route all memory operations through MuBit's control plane.

## Install

```bash
pip install mubit-langchain[langchain]
```

## Basic usage

### ConversationChain

```python
from mubit_langchain import MubitMemory
from langchain.chains import ConversationChain

memory = MubitMemory(api_key="mbt_...", session_id="chain-1")
chain = ConversationChain(llm=llm, memory=memory)
chain.run("Hello")  # auto-loads context, auto-saves interaction
```

### Chat-oriented (returns Message objects)

```python
from mubit_langchain import MubitChatMemory

memory = MubitChatMemory(api_key="mbt_...", session_id="chat-1")
# Returns SystemMessage objects instead of raw strings
```

## BaseMemory interface

| Method | MuBit mapping |
| --- | --- |
| `memory_variables` | Returns `[memory_key]` |
| `load_memory_variables(inputs)` | `control.context` — semantic context retrieval |
| `save_context(inputs, outputs)` | `control.ingest` — stores input/output pair |
| `clear()` | `control.delete_run` |

## MubitMemory vs MubitChatMemory

| Feature | MubitMemory | MubitChatMemory |
| --- | --- | --- |
| Return type | Raw string | `SystemMessage` list |
| Save behavior | Single combined trace | Individual messages |
| Default `return_messages` | `False` | `True` |

## Config

| Parameter | Default | Purpose |
| --- | --- | --- |
| `endpoint` | `http://127.0.0.1:3000` | MuBit HTTP endpoint |
| `api_key` | `""` | MuBit API key |
| `session_id` | `"default"` | Session/run scope |
| `memory_key` | `"history"` | Key in memory variables dict |
| `input_key` | `None` | Explicit input key (auto-detect if None) |
| `output_key` | `None` | Explicit output key (auto-detect if None) |
| `return_messages` | `False` | Return `SystemMessage` objects |
| `max_token_budget` | `2048` | Token budget for context retrieval |

## Development

```bash
PYTHONPATH=sdk/python/mubit-sdk/src:integrations/python \
python3 -m unittest integrations.python.mubit_langchain.tests.test_memory -v
```

## License

Apache-2.0
