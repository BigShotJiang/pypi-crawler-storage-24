"""MCP server for LLM trace interaction."""

from mcp_traces.server import mcp, main

__version__ = "0.1.0"
__all__ = ["mcp", "main"]
