#!/usr/bin/env python3
"""
Script to call FXiaoke Object Describe API and find field API names.
"""

import os
import sys
import json
from dotenv import load_dotenv

# Add src to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'src'))

from fxiaoke_auth import TokenManager

# Load environment variables
load_dotenv()

CRM_APP_ID = os.environ.get('CRM_APP_ID', '')
CRM_APP_SECRET = os.environ.get('CRM_APP_SECRET', '')
CRM_PERMANENT_CODE = os.environ.get('CRM_PERMANENT_CODE', '')

# API endpoint
DESCRIBE_ENDPOINT = "https://open.fxiaoke.com/cgi/crm/v2/object/describe"


def get_field_api_names():
    """Call the Object Describe API and find field API names."""

    if not all([CRM_APP_ID, CRM_APP_SECRET, CRM_PERMANENT_CODE]):
        print("Error: CRM credentials not configured")
        print("\nPlease set these environment variables:")
        print("  export CRM_APP_ID='FSAID_xxx'")
        print("  export CRM_APP_SECRET='xxx'")
        print("  export CRM_PERMANENT_CODE='xxx'")
        sys.exit(1)

    # Initialize token manager
    # Need user_mobile to get currentOpenUserId for the API call
    CRM_USER_MOBILE = os.environ.get('CRM_USER_MOBILE', '')

    token_manager = TokenManager(
        app_id=CRM_APP_ID,
        app_secret=CRM_APP_SECRET,
        permanent_code=CRM_PERMANENT_CODE,
        user_mobile=CRM_USER_MOBILE
    )

    # Get auth headers
    auth = token_manager.get_auth_headers()
    if not auth:
        print("Error: Failed to get auth token")
        sys.exit(1)

    # Build payload for Object Describe API
    # currentOpenUserId is required by this endpoint
    current_user_id = auth.get("currentOpenUserId", "")

    payload = {
        "corpAccessToken": auth["corpAccessToken"],
        "corpId": auth["corpId"],
        "currentOpenUserId": current_user_id,
        "apiName": "LeadsObj"  # The lead object
    }

    import requests

    try:
        print("Calling FXiaoke Object Describe API...")
        print(f"Endpoint: {DESCRIBE_ENDPOINT}")
        print(f"Object: LeadsObj")
        print()

        response = requests.post(
            DESCRIBE_ENDPOINT,
            json=payload,
            timeout=30
        )

        data = response.json()

        if data.get("errorCode") != 0:
            print(f"API Error: {data.get('errorMessage')}")
            print(f"Error Description: {data.get('errorDescription')}")
            sys.exit(1)

        # Debug: print full response structure
        print("\n--- DEBUG: Full response structure ---")
        print(f"Top-level keys: {list(data.keys())}")
        for key in ['errorCode', 'errorMessage', 'data']:
            if key in data:
                print(f"\n{key}:")
                print(f"  Type: {type(data[key])}")
                if key == 'data' and isinstance(data[key], dict):
                    print(f"  Data keys: {list(data[key].keys())}")
        print("--- END DEBUG ---\n")

        # Parse the response - fields might be nested under 'data' -> 'describe'
        fields = []
        if 'data' in data and isinstance(data['data'], dict):
            if 'describe' in data['data'] and isinstance(data['data']['describe'], dict):
                fields = data['data']['describe'].get('fields', [])
            else:
                fields = data['data'].get('fields', [])
        if not fields:
            fields = data.get('fields', [])

        print(f"Found {len(fields)} fields in LeadsObj")
        print()

        # Look for the fields we need
        target_labels = {
            "一级行业": [],
            "二级行业": [],
            "网址": [],
            "LinkedIn": [],
            "客户类型": [],
        }

        # Also search by partial matches
        partial_matches = {
            "industry": [],
            "website": [],
            "url": [],
            "linkedin": [],
            "type": [],
        }

        for field in fields:
            label = field.get("label", "")
            api_name = field.get("apiName", "")

            # Check for exact label matches
            for target in target_labels:
                if target in label:
                    target_labels[target].append({
                        "label": label,
                        "apiName": api_name,
                        "type": field.get("type"),
                    })

            # Check for partial matches (case-insensitive)
            label_lower = label.lower()
            api_lower = api_name.lower()
            for partial in partial_matches:
                if partial in label_lower or partial in api_lower:
                    partial_matches[partial].append({
                        "label": label,
                        "apiName": api_name,
                        "type": field.get("type"),
                    })

        # Print results
        print("=" * 60)
        print("SEARCH RESULTS FOR TARGET FIELDS")
        print("=" * 60)
        print()

        found_fields = {}

        for target, matches in target_labels.items():
            print(f"\n{target}:")
            if matches:
                for m in matches[:3]:  # Show top 3
                    print(f"  - {m['label']} => {m['apiName']} ({m['type']})")
                    found_fields[target] = m['apiName']
            else:
                print("  (No exact matches found)")

        print("\n" + "=" * 60)
        print("PARTIAL MATCHES (for reference)")
        print("=" * 60)

        for partial, matches in partial_matches.items():
            print(f"\n{partial}:")
            if matches:
                for m in matches[:5]:  # Show top 5
                    print(f"  - {m['label']} => {m['apiName']}")
            else:
                print("  (No matches)")

        # Print summary of found fields in the requested format
        print("\n" + "=" * 60)
        print("SUMMARY - ADD THESE TO YOUR FIELD_MAP")
        print("=" * 60)
        print()

        for label, api_name in found_fields.items():
            print(f"{label} = {api_name}")

        # Also save to file
        output_file = "found_fields.json"
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump({
                "target_fields": found_fields,
                "all_matches": {
                    "exact": target_labels,
                    "partial": partial_matches
                }
            }, f, ensure_ascii=False, indent=2)

        print(f"\nFull results saved to: {output_file}")

    except requests.exceptions.RequestException as e:
        print(f"Request failed: {e}")
        sys.exit(1)


if __name__ == '__main__':
    get_field_api_names()
