"""Tests for user lookup functionality."""
import unittest
from unittest.mock import Mock, patch


class TestUserLookup(unittest.TestCase):
    """Test user lookup by mobile and list all."""

    def setUp(self):
        """Set up test fixtures."""
        self.mock_auth = {
            'corpAccessToken': 'test_token',
            'corpId': 'test_corp',
            'currentOpenUserId': 'FSUID_TEST'
        }

        self.sample_user = {
            'name': '王雨檬',
            'openUserId': 'FSUID_4CF6AD1011C941AE32545CCC409CFD50',
            'mobile': '18102106041',
            'email': 'wangyumeng3@orionstar.com',
            'status': 'NORMAL',
            'fullName': '王雨檬',
            'account': '18102106041',
            'gender': 'F',
            'isActive': True
        }

    @patch('requests.post')
    @patch('src.cli.TokenManager')
    def test_lookup_by_mobile_success(self, mock_tm, mock_post):
        """Test successful mobile lookup."""
        # Setup mocks
        mock_tm.return_value.get_auth_headers.return_value = self.mock_auth

        mock_response = Mock()
        mock_response.json.return_value = {
            'errorCode': 0,
            'errorMessage': 'success',
            'empList': [self.sample_user]
        }
        mock_post.return_value = mock_response

        # Import and test
        from src.cli import cmd_lookup
        from unittest.mock import Mock as UnitMock

        args = UnitMock()
        args.mobile = '18102106041'
        args.list_all = False
        args.page_size = 100

        # Should not raise exception
        try:
            cmd_lookup(args)
        except SystemExit:
            pass  # Expected for successful execution

        # Verify API was called correctly
        mock_post.assert_called_once()
        call_args = mock_post.call_args
        self.assertEqual(call_args[0][0], 'https://open.fxiaoke.com/cgi/user/getByMobile')

    @patch('requests.post')
    @patch('src.cli.TokenManager')
    def test_lookup_by_mobile_not_found(self, mock_tm, mock_post):
        """Test mobile lookup with no results."""
        # Setup mocks
        mock_tm.return_value.get_auth_headers.return_value = self.mock_auth

        mock_response = Mock()
        mock_response.json.return_value = {
            'errorCode': 0,
            'errorMessage': 'success',
            'empList': []  # Empty list
        }
        mock_post.return_value = mock_response

        from src.cli import cmd_lookup
        from unittest.mock import Mock as UnitMock

        args = UnitMock()
        args.mobile = '18102106041'
        args.list_all = False
        args.page_size = 100

        # Should not raise exception
        try:
            cmd_lookup(args)
        except SystemExit:
            pass

    @patch('requests.post')
    @patch('src.cli.TokenManager')
    def test_lookup_list_all_pagination(self, mock_tm, mock_post):
        """Test listing all users with pagination."""
        # Setup mocks
        mock_tm.return_value.get_auth_headers.return_value = self.mock_auth

        # First page has results, second page is empty
        mock_responses = [
            Mock(json=Mock(return_value={
                'errorCode': 0,
                'errorMessage': 'success',
                'empList': [self.sample_user]
            })),
            Mock(json=Mock(return_value={
                'errorCode': 0,
                'errorMessage': 'success',
                'empList': []  # Empty to stop pagination
            }))
        ]
        mock_post.side_effect = mock_responses

        from src.cli import cmd_lookup
        from unittest.mock import Mock as UnitMock

        args = UnitMock()
        args.mobile = None
        args.list_all = True
        args.page_size = 1  # Small page size to test pagination

        # Should not raise exception
        try:
            cmd_lookup(args)
        except SystemExit:
            pass

        # Verify API was called twice (two pages)
        self.assertEqual(mock_post.call_count, 2)

    @patch('requests.post')
    @patch('src.cli.TokenManager')
    def test_lookup_api_error(self, mock_tm, mock_post):
        """Test handling of API errors."""
        # Setup mocks
        mock_tm.return_value.get_auth_headers.return_value = self.mock_auth

        mock_response = Mock()
        mock_response.json.return_value = {
            'errorCode': 1001,
            'errorMessage': 'Invalid token',
            'errorDescription': 'Token expired'
        }
        mock_post.return_value = mock_response

        from src.cli import cmd_lookup
        from unittest.mock import Mock as UnitMock

        args = UnitMock()
        args.mobile = '18102106041'
        args.list_all = False
        args.page_size = 100

        # Should not raise exception (handled gracefully)
        try:
            cmd_lookup(args)
        except SystemExit as e:
            # Expected to exit with error code
            self.assertEqual(e.code, 1)


if __name__ == '__main__':
    unittest.main()
