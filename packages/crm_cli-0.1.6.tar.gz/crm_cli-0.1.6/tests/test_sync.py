"""
Tests for the sync orchestrator (no Facebook dependencies).
"""

import unittest
import os
import sys
from unittest.mock import patch, MagicMock

# Add src directory to path
src_path = os.path.join(os.path.dirname(__file__), '..', 'src')
sys.path.insert(0, src_path)

from sync import SyncOrchestrator, SyncStats, SyncLeadResult
from crm import CreateClientResult


class TestSyncStats(unittest.TestCase):
    """Test SyncStats dataclass."""

    def test_default_values(self):
        """Test default stats values."""
        stats = SyncStats()
        self.assertEqual(stats.total_leads, 0)
        self.assertEqual(stats.created, 0)
        self.assertEqual(stats.duplicates, 0)
        self.assertEqual(stats.failures, 0)
        self.assertEqual(stats.duration_seconds, 0.0)

    def test_summary(self):
        """Test summary string generation."""
        stats = SyncStats(
            total_leads=100,
            created=80,
            duplicates=15,
            failures=5
        )
        summary = stats.summary()
        self.assertIn('Total: 100', summary)
        self.assertIn('Created: 80', summary)
        self.assertIn('Duplicates: 15', summary)
        self.assertIn('Failures: 5', summary)


class TestSyncLeadResult(unittest.TestCase):
    """Test SyncLeadResult dataclass."""

    def test_success_result(self):
        """Test successful sync result."""
        result = SyncLeadResult(
            lead_id='ext_123',
            company_name='Test Company',
            email='test@example.com',
            success=True,
            crm_client_id='crm_456'
        )
        self.assertTrue(result.success)
        self.assertEqual(result.crm_client_id, 'crm_456')
        self.assertFalse(result.is_duplicate)

    def test_duplicate_result(self):
        """Test duplicate sync result."""
        result = SyncLeadResult(
            lead_id='ext_123',
            company_name='Test Company',
            email='test@example.com',
            success=False,
            is_duplicate=True,
            error='Company exists'
        )
        self.assertFalse(result.success)
        self.assertTrue(result.is_duplicate)


class TestSyncOrchestrator(unittest.TestCase):
    """Test sync orchestrator functionality."""

    def setUp(self):
        """Set up test fixtures."""
        self.mock_crm_client = MagicMock()
        self.orchestrator = SyncOrchestrator(self.mock_crm_client)

    def test_initialization(self):
        """Test orchestrator initialization."""
        self.assertEqual(self.orchestrator.crm_client, self.mock_crm_client)

    def test_simulate_sync(self):
        """Test dry run simulation."""
        lead = {
            'source_id': 'ext_123',
            'company': 'Test Company',
            'email': 'test@example.com'
        }

        result = self.orchestrator._simulate_sync(lead)

        self.assertTrue(result.success)
        self.assertEqual(result.company_name, 'Test Company')
        self.assertEqual(result.email, 'test@example.com')
        self.assertIsNone(result.crm_client_id)

    def test_sync_leads_dry_run(self):
        """Test sync leads in dry run mode."""
        leads = [
            {'company': 'Company A', 'email': 'a@test.com'},
            {'company': 'Company B', 'email': 'b@test.com'}
        ]

        stats = self.orchestrator.sync_leads(leads, dry_run=True)

        # Should not call CRM
        self.mock_crm_client.create_client.assert_not_called()

        # Should have correct stats
        self.assertEqual(stats.total_leads, 2)
        self.assertEqual(stats.created, 0)
        self.assertEqual(stats.duplicates, 0)
        self.assertEqual(stats.failures, 0)

    def test_sync_leads_with_results(self):
        """Test sync leads with mixed results."""
        leads = [
            {'company': 'Company A', 'email': 'a@test.com'},
            {'company': 'Company B', 'email': 'b@test.com'},
            {'company': 'Company C', 'email': 'c@test.com'}
        ]

        # Mock CRM results: success, duplicate, failure
        self.mock_crm_client.create_client.side_effect = [
            CreateClientResult(success=True, crm_client_id='crm_1'),
            CreateClientResult(success=False, is_duplicate=True, warning='Duplicate'),
            CreateClientResult(success=False, error='API error')
        ]

        stats = self.orchestrator.sync_leads(leads)

        self.assertEqual(stats.total_leads, 3)
        self.assertEqual(stats.created, 1)
        self.assertEqual(stats.duplicates, 1)
        self.assertEqual(stats.failures, 1)

    def test_sync_leads_no_leads(self):
        """Test sync when no leads provided."""
        stats = self.orchestrator.sync_leads([])

        self.assertEqual(stats.total_leads, 0)
        self.assertEqual(stats.created, 0)
        self.mock_crm_client.create_client.assert_not_called()

    def test_sync_leads_progress_callback(self):
        """Test progress callback is called."""
        leads = [{'company': 'Company A', 'email': 'a@test.com'}]
        self.mock_crm_client.create_client.return_value = CreateClientResult(success=True)

        mock_callback = MagicMock()
        stats = self.orchestrator.sync_leads(leads, progress_callback=mock_callback)

        mock_callback.assert_called_once()

    def test_sync_single_lead_maps_fields(self):
        """Test that _sync_single_lead maps input fields correctly."""
        self.mock_crm_client.create_client.return_value = CreateClientResult(success=True)

        lead = {
            'company': 'Test Corp',
            'email': 'test@corp.com',
            'phone': '+44 123 456',
            'country': 'GB',
            'source_id': 'ext_123'
        }

        result = self.orchestrator._sync_single_lead(lead)

        # Verify CRM was called with mapped fields
        call_args = self.mock_crm_client.create_client.call_args[0][0]
        self.assertEqual(call_args['company_name'], 'Test Corp')
        self.assertEqual(call_args['email'], 'test@corp.com')
        self.assertEqual(call_args['phone_number'], '+44 123 456')
        self.assertEqual(call_args['country'], 'GB')
        self.assertEqual(call_args['id'], 'ext_123')


if __name__ == '__main__':
    unittest.main()