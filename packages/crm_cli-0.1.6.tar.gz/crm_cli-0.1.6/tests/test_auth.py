"""
Unit tests for TokenManager.
"""

import unittest
import os
import sys
import time
from unittest.mock import MagicMock, patch

# Add src directory to path
src_path = os.path.join(os.path.dirname(__file__), '..', 'src')
sys.path.insert(0, src_path)

from fxiaoke_auth import TokenManager


class TestTokenManager(unittest.TestCase):
    """Test TokenManager functionality."""

    def setUp(self):
        """Set up test fixtures."""
        self.token_manager = TokenManager(
            app_id="FSAID_132303a",
            app_secret="a86165bdb24f4bc68f5eda996c16e899",
            permanent_code="4B5FD25245A6003023A6F8B304429FC8",
            user_mobile="19957895939"
        )

    def tearDown(self):
        """Clean up."""
        self.token_manager.close()

    def test_token_manager_initialization(self):
        """Test TokenManager initializes with correct config"""
        manager = TokenManager(
            app_id="FSAID_132303a",
            app_secret="a86165bdb24f4bc68f5eda996c16e899",
            permanent_code="4B5FD25245A6003023A6F8B304429FC8"
        )
        self.assertEqual(manager.app_id, "FSAID_132303a")
        self.assertIsNone(manager.corp_access_token)  # Not fetched yet
        self.assertFalse(manager.is_token_valid())

    def test_token_cache_expiration(self):
        """Test token expires after 6650 seconds"""
        manager = TokenManager(
            app_id="test",
            app_secret="test",
            permanent_code="test"
        )
        # Manually set token with old timestamp
        manager.corp_access_token = "old_token"
        manager.token_fetched_at = 0  # Old timestamp
        self.assertFalse(manager.is_token_valid())

    def test_token_valid_when_recent(self):
        """Test token is valid when fetched recently"""
        manager = TokenManager(
            app_id="test",
            app_secret="test",
            permanent_code="test"
        )
        manager.corp_access_token = "valid_token"
        manager.token_fetched_at = time.time()  # Just fetched
        self.assertTrue(manager.is_token_valid())

    def test_get_corp_id_triggers_fetch(self):
        """Test get_corp_id triggers token fetch if not available"""
        # Initially None
        self.assertIsNone(self.token_manager.corp_id)

        # Mock the fetch method
        with patch.object(self.token_manager, '_fetch_token') as mock_fetch:
            mock_fetch.return_value = True
            self.token_manager.get_corp_id()
            mock_fetch.assert_called_once()

    def test_get_current_open_user_id_triggers_fetch(self):
        """Test get_current_open_user_id triggers user info fetch"""
        # Set token first (required for user info fetch)
        self.token_manager.corp_access_token = "test_token"
        self.token_manager.corp_id = 123

        with patch.object(self.token_manager, '_fetch_user_info') as mock_fetch:
            mock_fetch.return_value = True
            self.token_manager.get_current_open_user_id()
            mock_fetch.assert_called_once()

    def test_get_auth_headers_returns_all_fields(self):
        """Test get_auth_headers returns all required auth fields"""
        # Directly set cached values (bypassing is_token_valid check)
        self.token_manager.corp_access_token = "test_token"
        self.token_manager.corp_id = 772631
        self.token_manager.current_open_user_id = "FSUID_TEST"
        self.token_manager.token_fetched_at = time.time()  # Make token valid

        headers = self.token_manager.get_auth_headers()

        self.assertEqual(headers['corpAccessToken'], 'test_token')
        self.assertEqual(headers['corpId'], 772631)
        self.assertEqual(headers['currentOpenUserId'], 'FSUID_TEST')

    def test_get_auth_headers_returns_none_when_no_token(self):
        """Test get_auth_headers returns None when token not available"""
        # Set token_fetched_at to old time so is_token_valid returns False
        self.token_manager.corp_access_token = None
        self.token_manager.token_fetched_at = 0

        # Mock get_corp_access_token to return None (simulating auth failure)
        with patch.object(self.token_manager, 'get_corp_access_token') as mock_get:
            mock_get.return_value = None
            headers = self.token_manager.get_auth_headers()
            self.assertIsNone(headers)


@unittest.skipUnless(
    os.environ.get('CRM_APP_ID'),
    "CRM credentials not configured"
)
class TestTokenManagerIntegration(unittest.TestCase):
    """Integration tests with real FXiaoke API."""

    def test_real_token_fetch(self):
        """Test fetching real access token"""
        manager = TokenManager(
            app_id=os.environ['CRM_APP_ID'],
            app_secret=os.environ['CRM_APP_SECRET'],
            permanent_code=os.environ['CRM_PERMANENT_CODE'],
            user_mobile=os.environ.get('CRM_USER_MOBILE')
        )

        try:
            token = manager.get_corp_access_token()
            self.assertIsNotNone(token)
            self.assertTrue(manager.is_token_valid())
            print(f"\n✓ Token fetched: {token[:20]}...")
        finally:
            manager.close()

    def test_real_user_info_fetch(self):
        """Test fetching real user info"""
        manager = TokenManager(
            app_id=os.environ['CRM_APP_ID'],
            app_secret=os.environ['CRM_APP_SECRET'],
            permanent_code=os.environ['CRM_PERMANENT_CODE'],
            user_mobile=os.environ.get('CRM_USER_MOBILE')
        )

        try:
            # First get token
            token = manager.get_corp_access_token()
            self.assertIsNotNone(token)

            # Then get user info
            user_id = manager.get_current_open_user_id()
            self.assertIsNotNone(user_id)
            self.assertTrue(user_id.startswith('FSUID_'))
            print(f"\n✓ User ID fetched: {user_id}")
        finally:
            manager.close()


if __name__ == '__main__':
    unittest.main()
