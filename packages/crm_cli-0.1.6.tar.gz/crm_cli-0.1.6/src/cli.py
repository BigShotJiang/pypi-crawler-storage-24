#!/usr/bin/env python3
"""
CRM CLI - Main entry point.
Sync leads from JSON/CSV files to FXiaoke CRM.
"""

import os
import sys
import json
import csv
import argparse
import logging
from pathlib import Path
from typing import List, Dict, Any

from dotenv import load_dotenv

from .fxiaoke_auth import TokenManager
from .crm import CRMClient
from .sync import SyncOrchestrator

# Load environment variables
load_dotenv()

# Environment variables
CRM_APP_ID = os.environ.get('CRM_APP_ID', '')
CRM_APP_SECRET = os.environ.get('CRM_APP_SECRET', '')
CRM_PERMANENT_CODE = os.environ.get('CRM_PERMANENT_CODE', '')
CRM_USER_MOBILE = os.environ.get('CRM_USER_MOBILE', '')

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(message)s'
)
logger = logging.getLogger('crm_cli')


def print_error(code: str, message: str, hints: list = None):
    """Print an error message with optional hints."""
    print(f"\nError: {code}\n")
    print(message)
    if hints:
        print()
        for hint in hints:
            print(hint)
    print()


def print_success(message: str):
    """Print a success message."""
    print(f"✓ {message}")


def load_leads_from_file(filepath: str) -> List[Dict[str, Any]]:
    """
    Load leads from JSON or CSV file.

    Args:
        filepath: Path to the file

    Returns:
        List of lead dictionaries

    Raises:
        FileNotFoundError: If file doesn't exist
        ValueError: If file format is unsupported
    """
    path = Path(filepath)

    if not path.exists():
        raise FileNotFoundError(f"File not found: {filepath}")

    ext = path.suffix.lower()

    if ext == '.json':
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
            if isinstance(data, list):
                return data
            else:
                raise ValueError("JSON file must contain a list of leads")

    elif ext == '.csv':
        with open(path, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            return list(reader)

    else:
        raise ValueError(f"Unsupported file format: {ext}. Use .json or .csv")


def create_crm_client(owner_fsuid: str = None, pool_id: str = None) -> CRMClient:
    """
    Create a CRM client instance from environment variables.

    Args:
        owner_fsuid: Optional owner FSUID to assign leads to
        pool_id: Optional lead pool ID override

    Returns:
        CRMClient instance
    """
    if not all([CRM_APP_ID, CRM_APP_SECRET, CRM_PERMANENT_CODE]):
        print_error(
            'CONFIG_ERROR',
            'CRM credentials not configured',
            [
                'export CRM_APP_ID="FSAID_xxx"',
                'export CRM_APP_SECRET="xxx"',
                'export CRM_PERMANENT_CODE="xxx"',
            ]
        )
        sys.exit(1)

    token_manager = TokenManager(
        app_id=CRM_APP_ID,
        app_secret=CRM_APP_SECRET,
        permanent_code=CRM_PERMANENT_CODE,
        user_mobile=CRM_USER_MOBILE
    )

    return CRMClient(token_manager, owner_fsuid=owner_fsuid, pool_id=pool_id)


def cmd_sync(args):
    """Sync leads from file to CRM."""
    # Load leads from file
    try:
        leads = load_leads_from_file(args.file)
    except FileNotFoundError as e:
        print_error('FILE_NOT_FOUND', str(e))
        sys.exit(1)
    except json.JSONDecodeError as e:
        print_error('INVALID_JSON', f"Invalid JSON in file: {e}")
        sys.exit(1)
    except ValueError as e:
        print_error('INVALID_FORMAT', str(e))
        sys.exit(1)

    if not leads:
        print("No leads found in file.")
        return

    print(f"📥 Loaded {len(leads)} lead(s) from {args.file}")

    if args.dry_run:
        print("\n🔍 Dry run mode - no leads will be synced to CRM\n")

    # Create CRM client
    crm_client = create_crm_client(
        owner_fsuid=args.owner or args.assign,  # --assign is an alias for --owner
        pool_id=args.pool
    )

    # Create sync orchestrator
    orchestrator = SyncOrchestrator(crm_client)

    # Run sync
    stats = orchestrator.sync_leads(leads, dry_run=args.dry_run)

    # Print summary
    print()
    print("━" * 40)
    if args.dry_run:
        print(f"🔍 Dry run complete - no leads were synced to CRM")
        print(f"📊 Preview: {stats.total_leads} lead(s) would be synced")
    else:
        print(f"✓ Sync complete: {stats.created} created, {stats.duplicates} duplicates skipped")
        if stats.failures > 0:
            print(f"⚠ {stats.failures} failure(s)")
        print(f"⏱️  Duration: {stats.duration_seconds:.1f} seconds")
    print("━" * 40)


def main():
    """Main entry point for the CLI."""
    parser = argparse.ArgumentParser(
        prog='crm',
        description='FXiaoke CRM CLI - Sync leads from JSON/CSV files'
    )

    subparsers = parser.add_subparsers(dest='command', help='Commands')

    # sync command
    sync_parser = subparsers.add_parser('sync', help='Sync leads from file to CRM')
    sync_parser.add_argument('file', help='Path to JSON or CSV file with leads')
    sync_parser.add_argument('--dry-run', action='store_true', help='Preview without creating')
    sync_parser.add_argument('--owner', help='Owner FSUID to assign leads to (e.g., FSUID_xxx)')
    sync_parser.add_argument('--assign', help='Alias for --owner: assign leads to employee (FSUID format)')
    sync_parser.add_argument('--pool', help='Override lead pool ID (skip automatic routing)')
    sync_parser.set_defaults(func=cmd_sync)

    # lookup command
    lookup_parser = subparsers.add_parser('lookup', help='Lookup users/employees in CRM')
    lookup_parser.add_argument('--mobile', help='Find user by mobile number')
    lookup_parser.add_argument('--list-all', action='store_true', help='List all users (paginated)')
    lookup_parser.add_argument('--page-size', type=int, default=100, help='Page size for list (max 1000)')
    lookup_parser.set_defaults(func=cmd_lookup)

    # Parse arguments
    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        print("\nCommands:")
        print("  crm sync <file>           - Sync leads to CRM")
        print("  crm sync <file> --dry-run - Preview without creating")
        print("  crm lookup --mobile <num> - Lookup user by mobile")
        print("  crm lookup --list-all     - List all users")
        sys.exit(0)

    # Call the subcommand function
    args.func(args)


def cmd_lookup(args):
    """Lookup users/employees in CRM."""
    import requests

    # Check credentials
    if not all([CRM_APP_ID, CRM_APP_SECRET, CRM_PERMANENT_CODE]):
        print_error(
            'CONFIG_ERROR',
            'CRM credentials not configured',
            [
                'export CRM_APP_ID="FSAID_xxx"',
                'export CRM_APP_SECRET="xxx"',
                'export CRM_PERMANENT_CODE="xxx"',
            ]
        )
        sys.exit(1)

    # Initialize token manager
    token_manager = TokenManager(
        app_id=CRM_APP_ID,
        app_secret=CRM_APP_SECRET,
        permanent_code=CRM_PERMANENT_CODE,
        user_mobile=CRM_USER_MOBILE
    )

    # Get auth token
    auth = token_manager.get_auth_headers()
    if not auth:
        print_error('AUTH_ERROR', 'Failed to get auth token')
        sys.exit(1)

    # Lookup by mobile
    if args.mobile:
        print(f"Looking up user by mobile: {args.mobile}...\n")

        payload = {
            "corpAccessToken": auth["corpAccessToken"],
            "corpId": auth["corpId"],
            "mobile": args.mobile
        }

        try:
            response = requests.post(
                "https://open.fxiaoke.com/cgi/user/getByMobile",
                json=payload,
                timeout=30
            )
            data = response.json()

            if data.get("errorCode") == 0:
                emp_list = data.get("empList", [])
                if emp_list:
                    print("✓ User found:\n")
                    for emp in emp_list:
                        print(f"  Name: {emp.get('name', 'N/A')}")
                        print(f"  FSUID: {emp.get('openUserId', 'N/A')}")
                        print(f"  Mobile: {emp.get('mobile', 'N/A')}")
                        print(f"  Email: {emp.get('email', 'N/A')}")
                        print(f"  Status: {emp.get('status', 'N/A')}")
                        print()
                else:
                    print("✗ No user found with this mobile number")
            else:
                print_error(
                    'API_ERROR',
                    f"API returned error: {data.get('errorMessage', 'Unknown error')}"
                )

        except requests.exceptions.RequestException as e:
            print_error('REQUEST_ERROR', f"Request failed: {e}")

    # List all users
    elif args.list_all:
        print(f"Listing all users (page size: {args.page_size})...\n")

        page_number = 1
        total_found = 0

        while True:
            payload = {
                "corpAccessToken": auth["corpAccessToken"],
                "corpId": auth["corpId"],
                "pageSize": args.page_size,
                "pageNumber": page_number
            }

            try:
                response = requests.post(
                    "https://open.fxiaoke.com/cgi/user/get/batchByUpdTime",
                    json=payload,
                    timeout=30
                )
                data = response.json()

                if data.get("errorCode") == 0:
                    emp_list = data.get("empList", [])

                    if not emp_list:
                        break

                    for emp in emp_list:
                        total_found += 1
                        print(f"{total_found}. {emp.get('name', 'N/A')} - {emp.get('openUserId', 'N/A')} - {emp.get('mobile', 'N/A')}")

                    if len(emp_list) < args.page_size:
                        break

                    page_number += 1

                else:
                    print_error(
                        'API_ERROR',
                        f"API returned error: {data.get('errorMessage', 'Unknown error')}"
                    )
                    break

            except requests.exceptions.RequestException as e:
                print_error('REQUEST_ERROR', f"Request failed: {e}")
                break

        print(f"\n✓ Total users found: {total_found}")

    else:
        print("Please specify either --mobile <number> or --list-all")
        print("\nExamples:")
        print("  crm lookup --mobile 18102106041")
        print("  crm lookup --list-all")
        print("  crm lookup --list-all --page-size 100")


if __name__ == '__main__':
    main()