"""
FXiaoke CRM Authentication and Token Management.
Handles 2-step authentication with automatic token refresh.
"""

import time
import logging
from typing import Optional, Dict, Any

import requests

logger = logging.getLogger('fxiaoke_auth')

# API Configuration
BASE_URL = "https://open.fxiaoke.com"
TOKEN_ENDPOINT = f"{BASE_URL}/cgi/corpAccessToken/get/V2"
USER_BY_MOBILE_ENDPOINT = f"{BASE_URL}/cgi/user/getByMobile"

# Token refresh threshold (refresh before expiry)
TOKEN_VALID_SECONDS = 6650  # Refresh at 6650s (expires at 7200s)


class TokenManager:
    """
    Manages FXiaoke CRM authentication tokens.

    Authentication flow:
    1. Get corpAccessToken using AppID + AppSecret + PermanentCode
    2. Get currentOpenUserId using corpAccessToken + mobile
    3. Cache both and auto-refresh before expiry
    """

    def __init__(
        self,
        app_id: str,
        app_secret: str,
        permanent_code: str,
        user_mobile: str = None
    ):
        """
        Initialize TokenManager.

        Args:
            app_id: FXiaoke AppID (e.g., FSAID_132303a)
            app_secret: FXiaoke AppSecret
            permanent_code: Permanent authorization code
            user_mobile: User's mobile number for lookup (optional)
        """
        self.app_id = app_id
        self.app_secret = app_secret
        self.permanent_code = permanent_code
        self.user_mobile = user_mobile

        # Cached values
        self.corp_access_token: Optional[str] = None
        self.corp_id: Optional[int] = None
        self.current_open_user_id: Optional[str] = None
        self.token_fetched_at: float = 0

        # Session for connection pooling
        self.session = requests.Session()

    def get_corp_access_token(self, force_refresh: bool = False) -> Optional[str]:
        """
        Get valid corp access token, refreshing if necessary.

        Args:
            force_refresh: Force refresh even if token is valid

        Returns:
            Valid corp access token or None if failed
        """
        if force_refresh or not self.is_token_valid():
            logger.info("Fetching new corp access token...")
            success = self._fetch_token()
            if not success:
                return None
        return self.corp_access_token

    def get_corp_id(self) -> Optional[int]:
        """Get corp ID, fetching token if needed."""
        if not self.corp_id:
            self.get_corp_access_token()
        return self.corp_id

    def get_current_open_user_id(self) -> Optional[str]:
        """
        Get current open user ID, fetching if needed.

        Returns:
            User ID (FSUID_xxx format) or None
        """
        if not self.current_open_user_id and self.user_mobile:
            self._fetch_user_info()
        return self.current_open_user_id

    def is_token_valid(self) -> bool:
        """Check if current token is still valid."""
        if not self.corp_access_token:
            return False
        elapsed = time.time() - self.token_fetched_at
        return elapsed < TOKEN_VALID_SECONDS

    def _fetch_token(self) -> bool:
        """
        Fetch new corp access token from API.

        Returns:
            True if successful, False otherwise
        """
        payload = {
            "appId": self.app_id,
            "appSecret": self.app_secret,
            "permanentCode": self.permanent_code
        }

        try:
            response = self.session.post(
                TOKEN_ENDPOINT,
                json=payload,
                timeout=30
            )
            result = response.json()

            if result.get("errorCode") == 0:
                self.corp_access_token = result.get("corpAccessToken")
                self.corp_id = result.get("corpId")
                self.token_fetched_at = time.time()
                logger.info(f"Token fetched successfully (corp_id={self.corp_id})")
                return True
            else:
                logger.error(f"Token fetch failed: {result.get('errorDescription')}")
                return False

        except requests.exceptions.RequestException as e:
            logger.error(f"Token fetch error: {e}")
            return False

    def _fetch_user_info(self) -> bool:
        """
        Fetch user info by mobile number.

        Returns:
            True if successful, False otherwise
        """
        if not self.user_mobile or not self.corp_access_token:
            logger.warning("Cannot fetch user info: missing mobile or token")
            return False

        payload = {
            "corpAccessToken": self.corp_access_token,
            "corpId": self.corp_id,
            "mobile": self.user_mobile
        }

        try:
            response = self.session.post(
                USER_BY_MOBILE_ENDPOINT,
                json=payload,
                timeout=30
            )
            result = response.json()

            if result.get("errorCode") == 0:
                emp_list = result.get("empList", [])
                if emp_list:
                    self.current_open_user_id = emp_list[0].get("openUserId")
                    logger.info(f"User ID fetched: {self.current_open_user_id}")
                    return True
                else:
                    logger.error("No employee found for mobile")
                    return False
            else:
                logger.error(f"User fetch failed: {result.get('errorDescription')}")
                return False

        except requests.exceptions.RequestException as e:
            logger.error(f"User fetch error: {e}")
            return False

    def get_auth_headers(self) -> Dict[str, Any]:
        """
        Get authentication headers for API calls.

        Returns:
            Dict with corpAccessToken, corpId, currentOpenUserId
            or None if auth not available
        """
        token = self.get_corp_access_token()
        if not token:
            return None

        return {
            "corpAccessToken": token,
            "corpId": self.get_corp_id(),
            "currentOpenUserId": self.get_current_open_user_id()
        }

    def close(self):
        """Close the HTTP session."""
        self.session.close()
