# FXiaoke CRM API - Create Lead Documentation

## Endpoint

**URL:** `https://open.fxiaoke.com/cgi/crm/v2/data/create`
**Method:** POST + application/json

## Rate Limits

- **Per-endpoint:** 100 requests / 20 seconds
- **Daily total:** Based on purchased Open API resource pack (default: 100,000 requests/day)

Contact FXiaoke support to purchase dedicated database products for higher limits.

## Request Parameters

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `corpAccessToken` | String | Yes | Token from authentication endpoint |
| `corpId` | String | Yes | Corp ID from authentication endpoint |
| `currentOpenUserId` | String | Yes | User ID from phone lookup endpoint |
| `triggerApprovalFlow` | Boolean | No | Trigger approval workflow (default: true) |
| `triggerWorkFlow` | Boolean | No | Trigger workflow (default: true) |
| `hasSpecifyTime` | Boolean | No | Allow custom create_time (default: false) |
| `hasSpecifyCreatedBy` | Boolean | No | Allow custom created_by (default: false) |
| `includeDetailIds` | Boolean | No | Return detail object IDs for master-detail (default: false) |
| `data` | Map | Yes | Data object (see below) |

### Data Object Structure

```
data: {
  igonreMediaIdConvert: Boolean (default: true)
  object_data: Map (required) - Main object data
  details: Map (optional) - Detail/sub-object data
  optionInfo: Map (optional) - Validation options
}
```

### object_data Fields (for LeadsObj)

| Field | Type | Required | CRM Field Type | Description |
|-------|------|----------|----------------|-------------|
| `dataObjectApiName` | String | Yes | - | Fixed: `LeadsObj` |
| `name` | String | Yes | Text | Contact/Lead name |
| `object_describe_api_name` | String | Yes | Text | Object descriptor |
| `record_type` | String | Yes | Record Type | Business type |
| `email` | String | No | Email | Email address |
| `tel` | String | No | Phone | Phone number |
| `company` | String | No | Text | Company full name |
| `remark` | String | No | Text | Requirements/notes |
| `owner` | List<String> | No | Employee | Owner FSUID(s) |
| `leads_pool_id` | String | No | Single Select | Lead pool ID |
| `biz_status` | String | No | Single Select | Status: `un_assigned`, `un_processed`, etc. |
| `life_status` | String | No | Single Select | Life status: `ineffective`, `under_review`, `normal` |
| `leads_stage` | String | No | Single Select | Lead stage: `Lead`, `MQL`, `SQL`, `SAL`, etc. |
| `field_g60ab__c` | String | No | Single Select | Region: `1dKGudtaC` (Europe), `5yF9DohVi` (Asia) |
| `field_S737R__c` | String | No | Text | Contact phone number |
| `field_7dDlL__c` | String | No | Single Select | Follow status (S1-S7) |
| `source` | String | No | Single Select | Primary source: `1` (self), `2` (company), `3` (agent) |
| `country` | String | No | Single Select | Country field |

### optionInfo Fields

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `skipFuncValidate` | Boolean | false | Skip pre-function validation |
| `useValidationRule` | Boolean | - | Trigger validation rules |
| `isDuplicateSearch` | Boolean | - | Enable duplicate detection |

## Response

### Success Response

```json
{
  "errorCode": 0,
  "dataId": "created_record_id_here",
  "traceId": "request_trace_id"
}
```

### Error Response

```json
{
  "errorCode": <error_code>,
  "errorMessage": "Error message",
  "errorDescription": "Detailed description",
  "traceId": "request_trace_id"
}
```

### Common Error Codes

| Code | Description |
|------|-------------|
| 0 | Success |
| 20016 | Token expired - refresh and retry |
| Other | See FXiaoke error documentation |

## Known Lead Pool IDs

| Pool Name | ID |
|-----------|-----|
| 【欧洲】线索公海池 | `643d87b17be47e0a000190a715` |
| 【亚洲】线索公海池 | `643d87cda34e0a0001336093` |
| 日本线索池 | `6464a6451a3c2c0001c12369` |

## Known Region Values

| Region | Value |
|--------|-------|
| 欧洲 (Europe) | `1dKGudtaC` |
| 亚洲 (Asia) | `5yF9DohVi` |
| 非洲 (Africa) | `Kj32QZ486` |

## Known Follow Status Values

| Status | Value |
|--------|-------|
| S1-待跟进 | `7e8T541Vr` |
| S2-发起单向联系 | `tecn5DiCg` |
| S3-建立双向联系 | (call object describe API) |
| S4-已建立商机 | (call object describe API) |
| S5-商机赢单 | (call object describe API) |
| S6-商机输单 | (call object describe API) |
| S7-暂停跟进 | (call object describe API) |

## Known Source Values

| Source | Value |
|--------|-------|
| 销售自拓 | `1` |
| 公司投放 | `2` |
| 代理商报备 | `3` |
| 企业微信 | `enterprise_wechat` |

## Request Example

```json
{
  "corpAccessToken": "{corpAccessToken}",
  "corpId": "{corpId}",
  "currentOpenUserId": "{currentOpenUserId}",
  "hasSpecifyTime": true,
  "hasSpecifyCreatedBy": false,
  "triggerApprovalFlow": false,
  "triggerWorkFlow": false,
  "includeDetailIds": false,
  "data": {
    "igonreMediaIdConvert": true,
    "object_data": {
      "dataObjectApiName": "LeadsObj",
      "object_describe_api_name": "LeadsObj",
      "name": "Company Name",
      "record_type": "default__c",
      "email": "contact@example.com",
      "tel": "+441234567890",
      "company": "Company Full Name",
      "biz_status": "un_assigned",
      "life_status": "normal",
      "leads_pool_id": "643d87b17be47e0a000190a715",
      "field_g60ab__c": "1dKGudtaC",
      "field_S737R__c": "441234567890",
      "field_7dDlL__c": "7e8T541Vr",
      "remark": "Lead source notes"
    },
    "optionInfo": {
      "skipFuncValidate": false,
      "useValidationRule": true,
      "isDuplicateSearch": true
    }
  }
}
```

## Important Notes

1. **Do NOT use `message` field for logic** - `errorMessage` format may change
2. **Token expiry (20016)** - Refresh token and retry
3. **Duplicate handling** - Enable `isDuplicateSearch` to detect duplicates
4. **Timestamps** - Use milliseconds (e.g., `1619712000000`)
5. **Employee fields** - Use FSUID format: `["FSUID_xxx"]`
6. **Department fields** - Use department ID: `["1000"]`

## Reference

- API Documentation: https://open.fxiaoke.com/cgi/crm/v2/data/create
- Full field list: Call object describe API for complete field options