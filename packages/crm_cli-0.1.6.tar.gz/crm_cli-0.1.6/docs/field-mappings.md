# FXiaoke CRM Field Mappings

This document maps CRM field names to their FXiaoke API field identifiers for the `LeadsObj` (线索) object.

## Standard Field Mappings

| CRM Field Label | API Name | Type | Description |
|----------------|----------|------|-------------|
| 一级行业 | `field_e2eon__c` | select_one | Primary industry classification |
| 二级行业 | `field_e1Gqm__c` | select_one | Secondary industry classification |
| 公司网址 | `field_xmuU5__c` | url | Company website URL |
| linkedin profile | `field_Z4Ieq__c` | url | LinkedIn profile URL |
| 跟进状态 | `field_7dDlL__c` | select_one | Follow-up status (S1-S7) |
| 联系人手机号 | `field_S737R__c` | text | Contact phone number |
| S1阶段变更日期 | `field_aw71X__c` | date | S1 timestamp |
| 区域 | `field_g60ab__c` | select_one | Region (Europe/Asia) |
| 国家 | `field_IT92M__c` | select_one | Country |
| 公司全称 | `field_Hz8c3__c` | text | Company English name |

## Usage in crm-cli

Add these mappings to `src/crm.py` in the `FIELD_MAP` dictionary:

```python
FIELD_MAP = {
    # ... existing mappings ...
    "primary_industry": "field_e2eon__c",      # 一级行业
    "secondary_industry": "field_e1Gqm__c",    # 二级行业
    "website": "field_xmuU5__c",                # 公司网址
    "company_linkedin": "field_Z4Ieq__c",       # LinkedIn
}
```

## Field Value References

### Region Field (field_g60ab__c)

| Value | Label |
|-------|-------|
| `1dKGudtaC` | 欧洲 (Europe) |
| `5yF9DohVi` | 亚洲 (Asia) |
| `Kj32QZ486` | 非洲 (Africa) |

### Lead Pool IDs

| Pool Name | ID |
|-----------|-----|
| 【欧洲】线索公海池 | `643d87b17be47e0a000190a715` |
| 【亚洲】线索公海池 | `643d87cda34e0a0001336093` |
| 日本线索池 | `6464a6451a3c2c0001c12369` |

## Discovering Fields

To discover additional field mappings, use the Object Describe API:

```python
from fxiaoke_auth import TokenManager
import requests

token_manager = TokenManager(app_id, app_secret, permanent_code)
auth = token_manager.get_auth_headers()

payload = {
    "corpAccessToken": auth["corpAccessToken"],
    "corpId": auth["corpId"],
    "currentOpenUserId": auth["currentOpenUserId"],
    "apiName": "LeadsObj"
}

response = requests.post(
    "https://open.fxiaoke.com/cgi/crm/v2/object/describe",
    json=payload
)

data = response.json()
fields = data["data"]["describe"]["fields"]

# Print all field names
for api_name, field_info in fields.items():
    print(f"{api_name}: {field_info['label']} ({field_info['type']})")
```

## API Reference

For more information, see:
- [FXiaoke Create Lead API](fxiaoke-create-api.md) - Full API documentation
- [FXiaoke Open API Documentation](https://open.fxiaoke.com)
