


(define (problem mixed_f6_p8_u0_v0_d0_a0_n0_a0_b0_n0_f0)
   (:domain miconic)
   (:objects p0 p1 p2 p3 p4 p5 p6 p7 - passenger
             f0 f1 f2 f3 f4 f5 - floor)


(:init
(above f0 f1)
(above f0 f2)
(above f0 f3)
(above f0 f4)
(above f0 f5)

(above f1 f2)
(above f1 f3)
(above f1 f4)
(above f1 f5)

(above f2 f3)
(above f2 f4)
(above f2 f5)

(above f3 f4)
(above f3 f5)

(above f4 f5)



(origin p0 f3)
(destin p0 f4)

(origin p1 f5)
(destin p1 f3)

(origin p2 f2)
(destin p2 f0)

(origin p3 f1)
(destin p3 f2)

(origin p4 f5)
(destin p4 f4)

(origin p5 f0)
(destin p5 f3)

(origin p6 f0)
(destin p6 f5)

(origin p7 f3)
(destin p7 f1)






(lift_at f0)
)


(:goal


(and
(served p0)
(served p1)
(served p2)
(served p3)
(served p4)
(served p5)
(served p6)
(served p7)
))
)


