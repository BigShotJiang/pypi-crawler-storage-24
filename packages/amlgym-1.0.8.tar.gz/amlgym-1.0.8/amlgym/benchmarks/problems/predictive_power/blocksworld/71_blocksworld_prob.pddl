

(define (problem bw_rand_5)
(:domain blocksworld)
(:objects b1 b2 b3 b4 b5 - block)
(:init
(handempty)
(on b1 b3)
(ontable b2)
(ontable b3)
(on b4 b5)
(ontable b5)
(clear b1)
(clear b2)
(clear b4)
)
(:goal
(and
(on b1 b2)
(on b2 b4)
(on b3 b1))
)
)


