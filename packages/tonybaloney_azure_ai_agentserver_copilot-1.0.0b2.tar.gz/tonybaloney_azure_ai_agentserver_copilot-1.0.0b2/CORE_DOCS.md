# Copilot Agent SDK

A TypeScript SDK for building AI agents powered by GitHub Copilot Agent. The SDK provides a high-level interface for creating conversational agents with tool execution capabilities, session management, and extensibility through hooks and MCP (Model Context Protocol) servers.

## Installation

```bash
npm install @github/copilot
```

## Quick Start

### Basic Usage with Session

```typescript
import { Session } from "@github/copilot/sdk";

const session = new Session({
    modelProvider: {
        type: "openai",
        model: "gpt-4",
    },
});

// Listen for events
session.on("assistant.message", (event) => {
    console.log(event.data.content);
});

// Send a message
session.send({ prompt: "Help me refactor this code" });
```

### Functional API

For simple use cases, you can use the functional `query` API:

```typescript
import { query } from "@github/copilot/sdk";

for await (const event of query({
    prompt: "Create a new React component",
    modelProvider: {
        type: "anthropic",
        model: "claude-sonnet-4.5",
    },
})) {
    console.log(event);
}
```

## Core Concepts

### Session

The `Session` class is the main entry point for creating AI agents. It handles the full agentic loop including:

- Model interactions
- Tool execution
- Message history management
- Hook execution
- MCP server integration
- Event-driven architecture

**Key Features:**

- Multiple model provider support (OpenAI, Anthropic, Copilot)
- Built-in tools for file operations, shell commands, and more
- Permission system for tool execution
- Event-driven architecture for real-time updates
- Extensible through hooks

### Session Management

Sessions manage conversation state and message history. The SDK provides a `SessionManager` interface for managing multiple sessions:

#### SessionManager Interface

The `SessionManager` interface defines the contract for managing sessions. The SDK provides a default in-memory implementation:

```typescript
import { SessionManager } from "@github/copilot/sdk";

const sessionManager = new SessionManager();

// Create new session with options
const session = await sessionManager.createSession({
    modelProvider: { model: "gpt-4" },
});

// Resume last session
const lastSession = await sessionManager.getLastSession();

// Resume specific session by ID
const specificSession = await sessionManager.getSession({
    sessionId: "session-id",
});

// List all sessions
const sessions = await sessionManager.listSessions();
```

**Note:** The default `SessionManager` keeps sessions in memory only. For persistent sessions (saved to disk), use `LocalSessionManager` from `@github/copilot/cli` which implements the `SessionManager` interface.

#### Working with Sessions

Sessions maintain context across multiple interactions:

```typescript
import { Session } from "@github/copilot/sdk";

const session = new Session({
    modelProvider: { model: "gpt-4" },
});

// Set up event listeners
session.on("assistant.message", (event) => {
    console.log("Assistant:", event.data.content);
});

// First message
session.send({ prompt: "What is 2+2?" });

// Second message - maintains context
session.send({ prompt: "What about 3+3?" });
```

### Events

Sessions emit typed events during execution. You can listen for specific events or all events:

#### Event Types

| Event Type                      | Description                            |
| ------------------------------- | -------------------------------------- |
| `session.start`                 | Session initialization                 |
| `session.resume`                | Session resumed from disk              |
| `session.error`                 | Error occurred during execution        |
| `session.info`                  | Informational message                  |
| `session.model_change`          | Model selection changed                |
| `session.idle`                  | Session finished running loop          |
| `user.message`                  | User submitted a message               |
| `assistant.turn_start`          | Agent starts processing a turn         |
| `assistant.message`             | Assistant text response                |
| `assistant.turn_end`            | Agent completes a turn                 |
| `assistant.usage`               | Usage metrics (tokens, cost, duration) |
| `tool.user_requested`           | Tool execution requested by assistant  |
| `tool.execution_start`          | Tool execution begins                  |
| `tool.execution_partial_result` | Tool execution streaming updates       |
| `tool.execution_complete`       | Tool execution completed               |
| `abort`                         | Turn aborted by user                   |
| `hook.start`                    | Hook invocation begins                 |
| `hook.end`                      | Hook invocation completes              |
| `system.message`                | System message/prompt                  |

#### Listening to Events

```typescript
import { Session } from "@github/copilot/sdk";

const session = new Session({
    modelProvider: { model: "gpt-4" },
});

// Listen for specific event type
session.on("assistant.message", (event) => {
    console.log("Assistant:", event.data.content);
});

// Listen for tool execution
session.on("tool.execution_complete", (event) => {
    if (event.data.success) {
        console.log("Tool result:", event.data.result?.content);
    } else {
        console.error("Tool error:", event.data.error?.message);
    }
});

// Listen for errors
session.on("session.error", (event) => {
    console.error("Error:", event.data.message);
});

// Listen for all events
session.on("*", (event) => {
    console.log("Event:", event.type, event);
});

// Send message to start processing
session.send({ prompt: "List files in current directory" });
```

### Hooks

Hooks allow you to intercept and modify the agent's behavior at key points:

```typescript
import { Session, QueryHooks } from "@github/copilot/sdk";

const hooks: QueryHooks = {
    // Executed when session starts
    sessionStart: [
        async (input) => {
            console.log("Session starting:", input.source);
            return {
                additionalContext: "Remember to follow coding standards.",
            };
        },
    ],

    // Modify user prompts before processing
    userPromptSubmitted: [
        async (input) => {
            console.log("User submitted:", input.prompt);
            return {
                modifiedPrompt: input.prompt + "\nPlease be concise.",
            };
        },
    ],

    // Intercept tool calls before execution
    preToolUse: [
        async (input) => {
            console.log(`Tool requested: ${input.toolName}`);

            // Auto-deny dangerous operations
            if (input.toolName === "bash" && input.toolArgs.includes("rm -rf")) {
                return {
                    permissionDecision: "deny",
                    permissionDecisionReason: "Dangerous command blocked",
                };
            }

            // Modify tool arguments
            return {
                modifiedArgs: { ...input.toolArgs, verbose: true },
            };
        },
    ],

    // Modify tool results after execution
    postToolUse: [
        async (input) => {
            console.log(`Tool ${input.toolName} executed`);

            // Add context to tool results
            if (input.toolResult.content.length > 1000) {
                return {
                    additionalContext: "Note: Output was very long, consider filtering.",
                };
            }
        },
    ],

    // Executed when session ends
    sessionEnd: [
        async (input) => {
            console.log("Session ended:", input.reason);
            if (input.error) {
                console.error("Error:", input.error.message);
            }
        },
    ],
};

const session = new Session({
    modelProvider: { type: "openai", model: "gpt-4" },
    hooks,
});
```

### MCP Servers

Model Context Protocol (MCP) servers provide additional tools and context to your session:

```typescript
import { Session } from "@github/copilot/sdk";

const session = new Session({
    modelProvider: { type: "openai", model: "gpt-4" },
    mcpServers: {
        // Built-in filesystem server
        filesystem: {
            command: "npx",
            args: ["-y", "@modelcontextprotocol/server-filesystem", "/path/to/project"],
        },

        // Custom MCP server
        custom: {
            command: "node",
            args: ["./my-mcp-server.js"],
            env: {
                API_KEY: process.env.API_KEY,
            },
        },
    },
});
```

## Configuration Options

### SessionOptions

```typescript
export interface SessionOptions extends Partial<SessionMetadata> {
    // Session metadata
    sessionId?: string; // Unique session identifier (auto-generated if not provided)
    startTime?: Date; // Session creation time (defaults to current time)
    modifiedTime?: Date; // Last modification time (defaults to startTime)

    // Model configuration
    modelProvider?: ModelProvider;

    // Tool configuration
    availableTools?: string[]; // List of tools to make available (allowlist)
    excludedTools?: string[]; // List of tools to exclude (denylist)
    requestPermission?: (request: PermissionRequest) => Promise<PermissionRequestResult>;

    // MCP server configuration
    mcpServers?: Record<string, MCPServerConfig>;

    // Hooks for extending behavior
    hooks?: QueryHooks;

    // Logging
    logger?: RunnerLogger;

    // Environment
    workingDirectory?: string;
    env?: Record<string, string>;
    additionalDirectories?: string[];

    // Authentication (for Copilot provider)
    hmacKey?: string;
    copilotToken?: string;
}

export interface ModelProvider {
    type?: "openai" | "anthropic" | "copilot"; // Optional, defaults based on model
    model: string; // Model name (e.g., "gpt-4", "claude-sonnet-4.5")
}
```

## Advanced Examples

### Sending Messages with Attachments

```typescript
import { Session } from "@github/copilot/sdk";

const session = new Session({
    modelProvider: { model: "gpt-4" },
});

// Send message with file attachments
session.send({
    prompt: "Review these files",
    attachments: [
        {
            type: "file",
            path: "/path/to/file.ts",
            displayName: "file.ts",
        },
        {
            type: "directory",
            path: "/path/to/src",
            displayName: "src/",
        },
    ],
});
```

### Permission System

```typescript
const session = new Session({
    modelProvider: { model: "gpt-4" },
    requestPermission: async (request) => {
        console.log(`Permission requested for: ${request.toolName}`);
        console.log(`Arguments:`, request.args);

        // Auto-approve read-only tools
        if (request.toolName === "read_file") {
            return { granted: true };
        }

        // Ask user for destructive operations
        const userApproved = await promptUser(`Allow ${request.toolName} with args ${JSON.stringify(request.args)}?`);

        return { granted: userApproved };
    },
});
```

### Tool Filtering

```typescript
// Only allow specific tools
const session = new Session({
    modelProvider: { model: "gpt-4" },
    availableTools: ["read_file", "write_file", "bash"],
});

// Disable specific tools
const session2 = new Session({
    modelProvider: { model: "gpt-4" },
    excludedTools: ["bash"],
});
```

### Custom Logging

```typescript
import { NoopLogger } from "@github/copilot/sdk";

// Custom logger implementation
class CustomLogger {
    debug(message: string, ...args: any[]) {
        console.log(`[DEBUG] ${message}`, ...args);
    }
    info(message: string, ...args: any[]) {
        console.log(`[INFO] ${message}`, ...args);
    }
    warn(message: string, ...args: any[]) {
        console.warn(`[WARN] ${message}`, ...args);
    }
    error(message: string, ...args: any[]) {
        console.error(`[ERROR] ${message}`, ...args);
    }
}

const session = new Session({
    modelProvider: { model: "gpt-4" },
    logger: new CustomLogger(),
});
```

### Immediate vs Enqueued Messages

```typescript
const session = new Session({
    modelProvider: { model: "gpt-4" },
});

// Enqueued mode (default): waits for current turn to complete
session.send({ prompt: "First message" });

// Immediate mode: injects message into current turn
session.send({
    prompt: "Follow-up message",
    mode: "immediate",
});

// With abort controller for cancellation
const abortController = new AbortController();
session.send({
    prompt: "Long running task",
    abortController,
});

// Later: cancel the operation
abortController.abort();
```

## API Reference

### Main Exports

- **`Session`** - Main session class for managing conversations
- **`SessionManager`** - Interface for managing multiple sessions (default in-memory implementation provided)
- **`query`** - Functional query API for simple use cases
- **`QueryHooks`** - Hook interfaces and types
- **`SessionEvent`** - Union type of all session events
- **`SessionOptions`** - Configuration options for sessions (includes metadata like sessionId, startTime)
- **`SessionManagerOptions`** - Configuration options for session managers
- **`ModelProvider`** - Interface for model configuration
- **Logger exports** - `NoopLogger` and logger interface

### Type Exports

See source files for complete type definitions:

- `src/core/session.ts` - Session class and interfaces
- `src/core/sessionManager.ts` - SessionManager class
- `src/core/sessionEvent.ts` - All event types
- `src/core/hooks.ts` - Hook types and interfaces
- `src/core/query.ts` - Functional query API

## License

Copyright (c) Microsoft Corporation. All rights reserved.