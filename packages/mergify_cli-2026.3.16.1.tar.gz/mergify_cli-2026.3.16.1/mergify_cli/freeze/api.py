from __future__ import annotations

import typing


if typing.TYPE_CHECKING:
    import datetime
    import uuid

    import httpx


class ScheduledFreezeResponse(typing.TypedDict, total=False):
    id: typing.Required[str]
    reason: typing.Required[str]
    start: typing.Required[str]
    end: typing.Required[str | None]
    timezone: typing.Required[str]
    matching_conditions: list[str]
    exclude_conditions: list[str]


class CreateScheduledFreezePayload(typing.TypedDict, total=False):
    reason: typing.Required[str]
    start: typing.Required[str | None]
    end: typing.Required[str | None]
    timezone: typing.Required[str]
    matching_conditions: list[str]
    exclude_conditions: list[str]


class UpdateScheduledFreezePayload(typing.TypedDict, total=False):
    reason: str | None
    start: str | None
    end: str | None
    timezone: str | None
    matching_conditions: list[str] | None
    exclude_conditions: list[str] | None


async def list_freezes(
    client: httpx.AsyncClient,
    repository: str,
) -> list[ScheduledFreezeResponse]:
    response = await client.get(
        f"/v1/repos/{repository}/scheduled_freeze",
    )
    data: dict[str, list[ScheduledFreezeResponse]] = response.json()
    return data["scheduled_freezes"]


async def create_freeze(
    client: httpx.AsyncClient,
    repository: str,
    *,
    reason: str,
    timezone: str,
    matching_conditions: list[str] | None = None,
    start: datetime.datetime | None = None,
    end: datetime.datetime | None = None,
    exclude_conditions: list[str] | None = None,
) -> ScheduledFreezeResponse:
    payload: CreateScheduledFreezePayload = {
        "reason": reason,
        "start": start.isoformat() if start is not None else None,
        "end": end.isoformat() if end is not None else None,
        "timezone": timezone,
    }
    if matching_conditions is not None:
        payload["matching_conditions"] = matching_conditions
    if exclude_conditions:
        payload["exclude_conditions"] = exclude_conditions

    response = await client.post(
        f"/v1/repos/{repository}/scheduled_freeze",
        json=payload,
    )
    return response.json()  # type: ignore[no-any-return]


async def update_freeze(
    client: httpx.AsyncClient,
    repository: str,
    freeze_id: uuid.UUID,
    *,
    reason: str | None = None,
    timezone: str | None = None,
    matching_conditions: list[str] | None = None,
    start: datetime.datetime | None = None,
    end: datetime.datetime | None = None,
    exclude_conditions: list[str] | None = None,
) -> ScheduledFreezeResponse:
    payload: UpdateScheduledFreezePayload = {}
    if reason is not None:
        payload["reason"] = reason
    if timezone is not None:
        payload["timezone"] = timezone
    if matching_conditions is not None:
        payload["matching_conditions"] = matching_conditions
    if start is not None:
        payload["start"] = start.isoformat()
    if end is not None:
        payload["end"] = end.isoformat()
    if exclude_conditions is not None:
        payload["exclude_conditions"] = exclude_conditions

    response = await client.patch(
        f"/v1/repos/{repository}/scheduled_freeze/{freeze_id}",
        json=payload,
    )
    return response.json()  # type: ignore[no-any-return]


async def delete_freeze(
    client: httpx.AsyncClient,
    repository: str,
    freeze_id: uuid.UUID,
    *,
    delete_reason: str | None = None,
) -> None:
    url = f"/v1/repos/{repository}/scheduled_freeze/{freeze_id}/delete"
    payload: dict[str, str] = {}
    if delete_reason is not None:
        payload["delete_reason"] = delete_reason
    await client.post(url, json=payload)
