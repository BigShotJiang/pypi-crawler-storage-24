# airena-sdk

Thin Python SDK for AiRENA bots implementing the `openra.v1` protocol.

Handles protocol plumbing so bot authors can focus on strategy:
- JSONL I/O over stdin/stdout
- Message dispatch via `BotRunner`
- Typed observation and ruleset parsing
- Action builder helpers

Uses only the Python standard library. No external dependencies.

## Install

```bash
pip install airena-sdk
```

## Quick start

```python
from airena_sdk import BotRunner, Observation, Ruleset, log, send, move

bot = BotRunner()

@bot.on("ruleset")
def handle_ruleset(msg, state):
    state["rules"] = Ruleset.from_msg(msg)

@bot.on("tick")
def handle_tick(msg, state):
    obs = Observation.from_tick(msg)
    log(f"Tick {obs.tick}, cash={obs.self_info.resources.cash}")

    actions = []
    for unit in obs.units:
        if unit.current_order == "Idle":
            actions.append(move(unit.id, 64, 64))

    send({"type": "actions", "tick": obs.tick, "actions": actions})

@bot.on("game_over")
def handle_game_over(msg, state):
    log(f"Game over: {msg.get('result')}")

bot.run()
```

## API

### Protocol I/O

| Name | Description |
|------|-------------|
| `BotRunner` | Main loop with handler registration via `@bot.on("msg_type")` or `bot.register()` |
| `log(msg)` | Log to stderr (visible in runner logs, not parsed) |
| `send(obj)` | Send a JSON message to stdout |
| `send_error(msg)` | Send an error message |
| `PROTOCOL` | Protocol version string (`"openra.v1"`) |
| `__version__` | Package version string |

### Observation parser

Parse a raw tick message into frozen, typed dataclasses:

```python
obs = Observation.from_tick(msg)
```

| Class | Fields |
|-------|--------|
| `Observation` | `tick`, `self_info`, `units`, `enemies`, `nearby_resources`, `map`, `fow_enforced` |
| `SelfInfo` | `player_id`, `faction`, `resources`, `production_queues`, `placement_pending`, `placement_type_id`, `build_queue`, `action_results` |
| `Resources` | `cash`, `power` |
| `Unit` | `id`, `type_id`, `x`, `y`, `hp`, `max_hp`, `facing`, `cooldowns`, `can_deploy`, `current_order`, `cargo_ratio` |
| `EnemyUnit` | `id`, `type_id`, `x`, `y`, `hp`, `max_hp` |
| `ProductionQueue` | `queue_type`, `enabled`, `queue_length`, `items`, `buildable_items` |
| `ProductionItem` | `item_type_id`, `progress`, `done`, `paused`, `ticks_remaining`, `status` |
| `ActionResult` | `action`, `status`, `unit_id`, `detail`, `placement_detail` |
| `ResourceCell` | `x`, `y`, `kind`, `density` |
| `MapInfo` | `width`, `height`, `buildable` |

**Convenience methods on `SelfInfo`:**

```python
obs.self_info.queue_for("building")              # -> ProductionQueue | None (case-insensitive)
obs.self_info.buildable_in("infantry")            # -> tuple[str, ...] of type_ids
obs.self_info.find_action_result("queue_production")  # -> ActionResult | None
```

**On `ProductionQueue`:**

```python
queue.first_done()  # -> str | None (type_id of first completed item)
```

### Ruleset index

Parse the ruleset message into indexed lookups:

```python
rules = Ruleset.from_msg(msg)
```

| Class | Fields |
|-------|--------|
| `Ruleset` | `mod_id`, `ruleset_id`, `ruleset_version`, `unit_types` (dict), `weapons` (dict), `terrain` |
| `UnitType` | `type_id`, `display_name`, `is_building`, `max_hp`, `armor_type`, `speed`, `turn_speed`, `sight_range`, `cost`, `build_time`, `power_delta`, `weapons` |
| `Terrain` | `width`, `height`, `passability`, `terrain_types` |
| `Weapon` | `weapon_id`, `range`, `damage`, `reload_ticks`, `burst`, `min_range`, `projectile_speed`, `can_target`, `splash`, `versus` |

**Lookup methods on `Ruleset`:**

```python
rules.get_unit_type("e1")    # -> UnitType | None
rules.get_weapon("m60")      # -> Weapon | None
rules.weapon_range("e1")     # -> float (max range of first weapon, 0.0 if none)
rules.buildings()             # -> list[UnitType]
rules.mobile_units()          # -> list[UnitType]
```

### Action builders

Each returns a dict ready for the `actions` list:

| Function | Arguments |
|----------|-----------|
| `move(unit_id, x, y)` | Move a unit to a position |
| `attack_unit(unit_id, target_unit_id)` | Attack a specific target |
| `deploy(unit_id)` | Deploy/transform (e.g. MCV) |
| `stop(unit_id)` | Stop a unit |
| `harvest(unit_id, x, y)` | Send harvester to a resource cell |
| `capture(unit_id, target_id)` | Engineer captures a building |
| `queue_production(producer_id, item_type_id, count=1)` | Queue a unit/building for production |
| `place_building(building_type_id, x, y)` | Place a completed building |
| `noop()` | Do nothing |

### Decision helpers

Pure functions combining ruleset and observation data:

```python
from airena_sdk import can_afford, can_produce, dps, effective_dps, unit_dps_against
from airena_sdk import power_for, projected_power, decode_rle, can_build_at
```

| Function | Description |
|----------|-------------|
| `can_afford(ruleset, self_info, type_id)` | Check if cash >= cost |
| `can_produce(ruleset, self_info, type_id)` | Can afford AND item is in an enabled queue |
| `power_for(type_id, ruleset=None)` | Power delta for a building (uses ruleset if available, falls back to hardcoded table) |
| `projected_power(self_info, type_id, ruleset=None)` | Current power + power_for(type_id) |
| `dps(ruleset, type_id)` | Raw damage per second across all weapons |
| `effective_dps(ruleset, type_id, armor)` | DPS adjusted by versus multiplier |
| `unit_dps_against(ruleset, attacker, target)` | DPS of attacker against target's armor |
| `decode_rle(encoded)` | Decode RLE-encoded grid string (terrain, buildable) |
| `can_build_at(obs_map, x, y)` | Check if building can be placed at (x, y) using buildable grid |

## Requirements

Python 3.10+, stdlib only.

## Development

```bash
# Clone and install in development mode
git clone https://github.com/tyminski/airena-sdk-python.git
cd airena-sdk-python
pip install -e ".[test]"

# Run tests
pytest -v

# Build distribution
pip install build
python -m build
```

## Versioning

Version lives in the `VERSION` file (single source of truth). Git hooks handle the rest:

- **pre-commit** syncs `VERSION` → `pyproject.toml` automatically
- **post-commit** creates an annotated tag `v<version>` when VERSION changes

After cloning, enable the hooks:

```sh
git config core.hooksPath .githooks
```

## Release process

1. Update `VERSION` file.
2. Commit: `git commit -m "release: v0.X.0"` — hooks sync pyproject.toml and create the tag.
3. Push: `git push origin main --tags`
4. Create a GitHub Release from the tag.
5. The `publish.yml` workflow builds and publishes to PyPI via Trusted Publishing.

### First-time PyPI setup

Before the first release, a maintainer must configure Trusted Publishing on PyPI:

1. Go to https://pypi.org and log in (or create an account).
2. Go to **Your projects** → **Publishing** → **Add a new pending publisher**.
3. Fill in:
   - **PyPI project name**: `airena-sdk`
   - **Owner**: `tyminski`
   - **Repository**: `airena-sdk-python`
   - **Workflow name**: `publish.yml`
   - **Environment name**: `pypi`
4. Submit. This registers the trust relationship.
5. In the GitHub repo, go to **Settings** → **Environments** → create an environment named `pypi`.

After this one-time setup, every GitHub Release triggers automatic publishing.

## License

MIT
