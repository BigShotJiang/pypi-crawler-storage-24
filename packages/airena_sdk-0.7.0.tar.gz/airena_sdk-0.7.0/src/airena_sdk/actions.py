"""Action builder helpers for the openra.v1 protocol.

Each function returns a dict ready to be appended to the actions list.

Field names match the canonical actions.schema.json (source of truth).
"""


def move(unit_id: int, x: int, y: int) -> dict:
    """Move a unit to a position."""
    return {"action": "move", "unit_id": unit_id, "x": x, "y": y}


def attack_unit(unit_id: int, target_unit_id: int) -> dict:
    """Order a unit to attack a specific target.

    Args:
        unit_id: ID of the attacking unit.
        target_unit_id: ID of the target unit.
    """
    return {"action": "attack_unit", "unit_id": unit_id, "target_unit_id": target_unit_id}


def deploy(unit_id: int) -> dict:
    """Deploy a unit (e.g., MCV -> Construction Yard)."""
    return {"action": "deploy", "unit_id": unit_id}


def stop(unit_id: int) -> dict:
    """Stop a unit."""
    return {"action": "stop", "unit_id": unit_id}


def harvest(unit_id: int, x: int, y: int) -> dict:
    """Order a harvester to harvest at a position."""
    return {"action": "harvest", "unit_id": unit_id, "x": x, "y": y}


def queue_production(producer_id: int, item_type_id: str, count: int = 1) -> dict:
    """Queue production of a unit or building type at a production facility.

    Args:
        producer_id: ID of the production building (e.g. Construction Yard).
        item_type_id: Type ID of the item to produce (e.g. 'powr', 'e1').
        count: Number of items to queue (default 1).
    """
    return {
        "action": "queue_production",
        "producer_id": producer_id,
        "item_type_id": item_type_id,
        "count": count,
    }


def place_building(building_type_id: str, x: int, y: int) -> dict:
    """Place a completed building at a position.

    Requires a completed building item in the production queue.

    Args:
        building_type_id: Type ID of the building to place (e.g. 'powr').
        x: Target X coordinate for placement.
        y: Target Y coordinate for placement.
    """
    return {"action": "place_building", "building_type_id": building_type_id, "x": x, "y": y}


def capture(unit_id: int, target_id: int) -> dict:
    """Order an engineer to capture a target building.

    Args:
        unit_id: ID of the engineer unit.
        target_id: ID of the target building to capture.
    """
    return {"action": "capture", "unit_id": unit_id, "target_id": target_id}


def noop() -> dict:
    """Do nothing. Placeholder action."""
    return {"action": "noop"}


def guard(unit_id: int, target_unit_id: int) -> dict:
    """Order a unit to escort/guard another unit, auto-engaging threats."""
    return {"action": "guard", "unit_id": unit_id, "target_unit_id": target_unit_id}


def sell(building_id: int) -> dict:
    """Sell a building for partial credit refund."""
    return {"action": "sell", "building_id": building_id}


def repair(building_id: int) -> dict:
    """Toggle building repair (costs credits over time)."""
    return {"action": "repair", "building_id": building_id}


def stance(unit_id: int, stance: str) -> dict:
    """Set combat stance: attack_anything, defend, return_fire, hold_fire."""
    return {"action": "stance", "unit_id": unit_id, "stance": stance}


def scatter(unit_id: int) -> dict:
    """Dodge to random nearby position (counter splash damage)."""
    return {"action": "scatter", "unit_id": unit_id}


def force_fire(unit_id: int, x: int, y: int) -> dict:
    """Attack map coordinates (ground attack, area denial, fog shots)."""
    return {"action": "force_fire", "unit_id": unit_id, "x": x, "y": y}


def patrol(unit_id: int, waypoints: list[dict]) -> dict:
    """Patrol between waypoints (1-8), auto-engage enemies on route.

    Args:
        unit_id: ID of the unit to patrol.
        waypoints: List of {"x": int, "y": int} waypoints (1-8).
    """
    return {"action": "patrol", "unit_id": unit_id, "waypoints": waypoints}


def cancel_production(producer_id: int, item_type_id: str) -> dict:
    """Cancel a queued production item, partial refund based on progress.

    Args:
        producer_id: ID of the production building.
        item_type_id: Type ID of the item to cancel (e.g. 'powr', 'e1').
    """
    return {"action": "cancel_production", "producer_id": producer_id, "item_type_id": item_type_id}
