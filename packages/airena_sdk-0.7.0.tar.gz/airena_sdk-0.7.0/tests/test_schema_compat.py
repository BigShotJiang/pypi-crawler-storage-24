"""Validate SDK action payloads against the canonical actions.schema.json.

This test ensures the SDK stays in sync with the protocol schema.
It loads actions.schema.json, generates payloads from every SDK action builder,
and validates each payload against the schema.

Requires: pip install jsonschema (test dependency)
"""

import json
import pathlib
import pytest

# Schema path relative to repo root
# SDK repo is at airena/airena-sdk-python/, schema is at airena/airena-bot-protocol/
_SDK_ROOT = pathlib.Path(__file__).resolve().parents[1]  # airena-sdk-python/
_AIRENA_ROOT = _SDK_ROOT.parent  # airena/
SCHEMA_PATH = (
    _AIRENA_ROOT
    / "airena-bot-protocol"
    / "schemas"
    / "openra"
    / "v1"
    / "actions.schema.json"
)

try:
    import jsonschema
    HAS_JSONSCHEMA = True
except ImportError:
    HAS_JSONSCHEMA = False

from airena_sdk import (
    move,
    attack_unit,
    deploy,
    stop,
    harvest,
    capture,
    queue_production,
    place_building,
    noop,
    guard,
    sell,
    repair,
    stance,
    scatter,
    force_fire,
    patrol,
    cancel_production,
)


def _load_schema():
    with open(SCHEMA_PATH) as f:
        return json.load(f)


def _make_actions_message(tick: int, actions: list[dict]) -> dict:
    return {"type": "actions", "tick": tick, "actions": actions}


# All SDK action builders with sample arguments
SDK_ACTIONS = [
    ("move", lambda: move(1, 10, 20)),
    ("attack_unit", lambda: attack_unit(1, 99)),
    ("deploy", lambda: deploy(5)),
    ("stop", lambda: stop(7)),
    ("harvest", lambda: harvest(3, 50, 60)),
    ("capture", lambda: capture(2, 42)),
    ("queue_production", lambda: queue_production(10, "e1")),
    ("queue_production_count", lambda: queue_production(10, "e1", count=3)),
    ("place_building", lambda: place_building("powr", 100, 200)),
    ("noop", lambda: noop()),
    ("guard", lambda: guard(1, 2)),
    ("sell", lambda: sell(10)),
    ("repair", lambda: repair(10)),
    ("stance", lambda: stance(1, "defend")),
    ("scatter", lambda: scatter(1)),
    ("force_fire", lambda: force_fire(1, 50, 60)),
    ("patrol", lambda: patrol(1, [{"x": 10, "y": 20}, {"x": 30, "y": 40}])),
    ("cancel_production", lambda: cancel_production(10, "powr")),
]


@pytest.mark.skipif(not SCHEMA_PATH.exists(), reason="actions.schema.json not found")
@pytest.mark.skipif(not HAS_JSONSCHEMA, reason="jsonschema not installed")
@pytest.mark.parametrize("name,builder", SDK_ACTIONS, ids=[s[0] for s in SDK_ACTIONS])
def test_sdk_action_validates_against_schema(name, builder):
    """Each SDK action payload must validate against actions.schema.json."""
    schema = _load_schema()
    action_payload = builder()
    message = _make_actions_message(tick=0, actions=[action_payload])
    jsonschema.validate(instance=message, schema=schema)


@pytest.mark.skipif(not SCHEMA_PATH.exists(), reason="actions.schema.json not found")
def test_sdk_covers_all_schema_action_types():
    """Every action type in the schema must have a corresponding SDK builder."""
    schema = _load_schema()
    schema_action_types = set()
    for item_schema in schema["properties"]["actions"]["items"]["oneOf"]:
        action_const = item_schema["properties"]["action"]["const"]
        schema_action_types.add(action_const)

    sdk_action_types = {builder().get("action") for _, builder in SDK_ACTIONS}

    missing = schema_action_types - sdk_action_types
    assert not missing, f"Schema defines actions not covered by SDK: {missing}"


@pytest.mark.skipif(not SCHEMA_PATH.exists(), reason="actions.schema.json not found")
def test_sdk_has_no_extra_action_types():
    """SDK must not define action types that don't exist in the schema."""
    schema = _load_schema()
    schema_action_types = set()
    for item_schema in schema["properties"]["actions"]["items"]["oneOf"]:
        action_const = item_schema["properties"]["action"]["const"]
        schema_action_types.add(action_const)

    sdk_action_types = {builder().get("action") for _, builder in SDK_ACTIONS}

    extra = sdk_action_types - schema_action_types
    assert not extra, f"SDK defines actions not in schema: {extra}"


@pytest.mark.skipif(not SCHEMA_PATH.exists(), reason="actions.schema.json not found")
def test_sdk_field_names_match_schema():
    """SDK action field names must exactly match schema required + optional fields."""
    schema = _load_schema()

    schema_fields_by_type: dict[str, set[str]] = {}
    for item_schema in schema["properties"]["actions"]["items"]["oneOf"]:
        action_type = item_schema["properties"]["action"]["const"]
        schema_fields_by_type[action_type] = set(item_schema["properties"].keys())

    for name, builder in SDK_ACTIONS:
        payload = builder()
        action_type = payload["action"]
        sdk_fields = set(payload.keys())
        expected_fields = schema_fields_by_type.get(action_type, set())

        extra = sdk_fields - expected_fields
        assert not extra, (
            f"SDK action '{action_type}' (via {name}) has fields not in schema: {extra}"
        )

        required = set()
        for item_schema in schema["properties"]["actions"]["items"]["oneOf"]:
            if item_schema["properties"]["action"]["const"] == action_type:
                required = set(item_schema.get("required", []))
                break

        missing = required - sdk_fields
        assert not missing, (
            f"SDK action '{action_type}' (via {name}) missing required fields: {missing}"
        )
