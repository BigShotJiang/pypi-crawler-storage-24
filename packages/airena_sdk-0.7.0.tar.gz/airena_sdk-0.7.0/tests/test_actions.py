"""Tests for action builder helpers.

All field names must match actions.schema.json (source of truth).
"""

from airena_sdk import (
    move,
    attack_unit,
    deploy,
    stop,
    harvest,
    queue_production,
    place_building,
    noop,
)


def test_move():
    result = move(1, 10, 20)
    assert result == {"action": "move", "unit_id": 1, "x": 10, "y": 20}


def test_attack_unit():
    result = attack_unit(1, 99)
    assert result == {"action": "attack_unit", "unit_id": 1, "target_unit_id": 99}


def test_deploy():
    result = deploy(5)
    assert result == {"action": "deploy", "unit_id": 5}


def test_stop():
    result = stop(7)
    assert result == {"action": "stop", "unit_id": 7}


def test_harvest():
    result = harvest(3, 50, 60)
    assert result == {"action": "harvest", "unit_id": 3, "x": 50, "y": 60}


def test_queue_production():
    result = queue_production(10, "e1")
    assert result == {
        "action": "queue_production",
        "producer_id": 10,
        "item_type_id": "e1",
        "count": 1,
    }


def test_queue_production_count():
    result = queue_production(10, "e1", count=3)
    assert result == {
        "action": "queue_production",
        "producer_id": 10,
        "item_type_id": "e1",
        "count": 3,
    }


def test_place_building():
    result = place_building("powr", 100, 200)
    assert result == {"action": "place_building", "building_type_id": "powr", "x": 100, "y": 200}


def test_noop():
    result = noop()
    assert result == {"action": "noop"}


def test_all_return_dicts():
    """Every builder must return a plain dict."""
    results = [
        move(1, 0, 0),
        attack_unit(1, 2),
        deploy(1),
        stop(1),
        harvest(1, 0, 0),
        queue_production(1, "x"),
        place_building("x", 0, 0),
        noop(),
    ]
    for r in results:
        assert isinstance(r, dict)
        assert "action" in r


def test_attack_move_removed():
    """attack_move is not supported by the runtime and must not be in the SDK."""
    import airena_sdk
    assert not hasattr(airena_sdk, "attack_move")
    import airena_sdk.actions as actions_mod
    assert not hasattr(actions_mod, "attack_move")
