from pm4py.algo.discovery.declare import templates as t

all_templates = {
    t.EXISTENCE,
    t.EXACTLY_ONE,
    t.INIT,
    t.RESPONDED_EXISTENCE,
    t.RESPONSE,
    t.PRECEDENCE,
    t.SUCCESSION,
    t.ALTRESPONSE,
    t.ALTPRECEDENCE,
    t.ALTSUCCESSION,
    t.CHAINRESPONSE,
    t.CHAINPRECEDENCE,
    t.CHAINSUCCESSION,
    t.ABSENCE,
    t.COEXISTENCE,
    t.NONCOEXISTENCE,
    t.NONSUCCESSION,
    t.NONCHAINSUCCESSION,
}

excluded = {t.ABSENCE, t.NONCOEXISTENCE}
allowed = all_templates - excluded

