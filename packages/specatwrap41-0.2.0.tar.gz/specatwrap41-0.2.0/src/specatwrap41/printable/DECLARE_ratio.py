from typing import Any


def declare_counts_to_ratios(
    declare_model: dict[str, dict[Any, dict[str, int]]],
    num_cases: int,
) -> dict[str, dict[Any, dict[str, float]]]:
    """

    Convert PM4Py DECLARE output counts to ratios.

    Input shape:

      {

        "<template>": {

          <constraint_key>: {"support": int, "confidence": int},

          ...

        },

        ...

      }

    Output shape (same structure, ratios instead of counts):

      {

        "<template>": {

          <constraint_key>: {"support": float, "confidence": float},

          ...

        },

        ...

      }

    - support ratio = support_count / num_cases

    - confidence ratio = confidence_count / support_count (0.0 if support_count == 0)

    """

    if num_cases <= 0:
        raise ValueError("num_cases must be > 0")

    out: dict[str, dict[Any, dict[str, float]]] = {}

    for template, constraints in declare_model.items():
        out[template] = {}

        for constraint_key, metrics in constraints.items():
            support_count = float(metrics.get("support", 0))

            confidence_count = float(metrics.get("confidence", 0))

            support_ratio = support_count / float(num_cases)

            confidence_ratio = (
                confidence_count / support_count if support_count > 0 else 0.0
            )

            out[template][constraint_key] = {
                "support": support_ratio,
                "confidence": confidence_ratio,
            }

    return out
