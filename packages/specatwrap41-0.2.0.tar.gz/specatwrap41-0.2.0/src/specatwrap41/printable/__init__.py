"""
CLI command to copy Python files from the printable folder to clipboard.

This allows easy transfer of scripts on the remote protected machine.
"""

import subprocess
from pathlib import Path

import click


@click.command("print")
@click.argument("filename", required=False)
@click.option("--list", "-l", is_flag=True, help="List all available printable files")
@click.option("--imports", "-i", is_flag=True, help="Include import statements")
def print_file(filename: str | None, list: bool, imports: bool) -> None:
    """
    Copy Python files from the printable folder to clipboard.

    This command helps transfer code to the restricted environment by copying
    file contents directly to the Windows clipboard.

    By default, import statements are excluded. Use -i to include them.

    Usage:

        specatwrap print diagnosis_kpi

        specatwrap print diagnosis_kpi -i

        specatwrap print --list

    \b
    Arguments:
        FILENAME: Name of the file to copy (without .py extension)
    """
    printable_dir = Path(__file__).parent

    # List available files
    if list:
        python_files = sorted(printable_dir.glob("*.py"))
        python_files = [f for f in python_files if f.name != "__init__.py"]

        if not python_files:
            click.echo("No printable files available.")
            return

        click.echo("Available printable files:")
        for file in python_files:
            click.echo(f"  - {file.stem}")
        return

    # Print specific file
    if not filename:
        click.echo(
            "Error: Please provide a filename or use --list to see available files."
        )
        click.echo("Usage: specatwrap print <filename>")
        click.echo("       specatwrap print --list")
        raise click.Abort()

    # Add .py extension if not present
    if not filename.endswith(".py"):
        filename = f"{filename}.py"

    file_path = printable_dir / filename

    if not file_path.exists():
        click.echo(f"Error: File '{filename}' not found in printable folder.")
        click.echo("\nUse 'specatwrap print --list' to see available files.")
        raise click.Abort()

    # Read and copy to clipboard
    try:
        content = file_path.read_text()

        # Filter out import statements if -i flag is not set
        if not imports:
            lines = content.split("\n")
            filtered_lines = []

            for line in lines:
                stripped = line.strip()
                # Skip import and from...import statements
                if stripped.startswith("import ") or stripped.startswith("from "):
                    continue
                filtered_lines.append(line)

            content = "\n".join(filtered_lines)

        # Copy to clipboard using Windows clip.exe
        subprocess.run(["clip.exe"], input=content, text=True, check=True)

        import_status = "with imports" if imports else "without imports"
        click.echo(f"✓ Content of '{filename}' copied to clipboard ({import_status})!")

    except subprocess.CalledProcessError as e:
        click.echo(f"Error copying to clipboard: {e}")
        raise click.Abort()
    except Exception as e:
        click.echo(f"Error reading file: {e}")
        raise click.Abort()
