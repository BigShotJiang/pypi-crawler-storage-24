import polars as pl

lf = pl.scan_parquet("combined_diag_death.parquet").unique(
    subset=["case:PNR", "TDiag"], keep="first", maintain_order=True
)


# Computing the average time between diagnoses for each case, excluding the death event
lf = (
    lf.with_columns(pl.col("startTime").diff().over("case:PNR").alias("_tmp_diff"))
    .with_columns(
        pl.col("_tmp_diff")
        .filter(pl.col("TDiag") != "Death")
        .mean()
        .over("case:PNR")
        .alias("case:avg_inter_diagnosis_time")
    )
    .drop("_tmp_diff")
)

# Compute time to death from the last diagnosis for cases that ended with death, ensuring we only compute this if there are multiple events in the case (i.e., Death isn't the only event)
lf = lf.with_columns(
    pl.when(
        (pl.col("TDiag") == "Death")
        & (pl.len().over("case:PNR") > 1)  # Ensure Death isn't the only event
    )
    .then(pl.col("startTime") - pl.col("startTime").shift(1).over("case:PNR"))
    .otherwise(None)
    .alias("case:time_to_death_from_last_diag")
)

# Computing variants
# 1. Group by case to get the sequence of events as a "variant"
lf_tmp = (
    lf.group_by("case:PNR")
    .agg(
        pl.col("TDiag").str.join(">").str.replace(r">Death$", "").alias("variants"),
        pl.col("case:avg_inter_diagnosis_time").first(),
        pl.col("case:time_to_death_from_last_diag").last(),
        (pl.col("TDiag") != "Death").sum().alias("diagnosis_count"),
        (pl.col("TDiag") == "Death").any().alias("died"),
    )
    .with_columns(pl.col("died").mean().over("variants").alias("mortality_kpi"))
    .drop("died")
)

lf_summary = lf_tmp.group_by("variants").agg(
    pl.col("mortality_kpi").first(),
    pl.len().alias("count"),
    pl.col("diagnosis_count").first(),
    pl.col("case:avg_inter_diagnosis_time")
    .mean()
    .alias("avg_avg_inter_diagnosis_time"),
    pl.col("case:time_to_death_from_last_diag")
    .mean()
    .alias("avg_inter_diagnosis_time_to_death"),
)

# Joining the KPI back to the main log for further analysis or export
patient_kpi_map = lf_tmp.select(
    [
        pl.col("case:PNR"),
        pl.col("mortality_kpi").alias("case:mortality_kpi"),
        pl.col("case:avg_avg_inter_diagnosis_time"),
        pl.col("case:time_to_death_from_last_diag"),
        pl.col("diagnosis_count"),
    ]
)
lf = lf.join(patient_kpi_map, on="case:PNR", how="left")
