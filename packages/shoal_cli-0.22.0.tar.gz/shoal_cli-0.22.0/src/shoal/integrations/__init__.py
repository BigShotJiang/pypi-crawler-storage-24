"""Shell integrations for Shoal."""
