#!/usr/bin/env node
/**
 * live_logger.js (V3 - Properties Fix)
 */

'use strict';

const automator = require('miniprogram-automator');

async function main() {
    const portArg = process.argv.indexOf('--port');
    const durationArg = process.argv.indexOf('--duration');
    const port = parseInt(portArg !== -1 ? process.argv[portArg + 1] : '9420');
    const duration = parseInt(durationArg !== -1 ? process.argv[durationArg + 1] : '30');

    let miniProgram = null;

    try {
        miniProgram = await automator.connect({
            wsEndpoint: `ws://localhost:${port}`,
        });

        console.log(`\n\x1b[32m[LIVE] 已连接！监听实时日志 (${duration}秒)...\x1b[0m`);
        console.log('------------------------------------------------------------');

        const formatArg = (arg) => {
            if (typeof arg === 'object' && arg !== null) {
                try { return JSON.stringify(arg); } catch (e) { return '[Object]'; }
            }
            return String(arg);
        };

        miniProgram.on('console', (msg) => {
            const type = msg.type || 'log';
            const args = msg.args || [];
            const time = new Date().toLocaleTimeString('zh-CN', { hour12: false });
            const content = args.map(formatArg).join(' ');

            let prefix = `[${time}] [${type.toUpperCase()}]`;
            if (type === 'error') prefix = `\x1b[31m${prefix}\x1b[0m`;
            else if (type === 'warn') prefix = `\x1b[33m${prefix}\x1b[0m`;
            else prefix = `\x1b[36m${prefix}\x1b[0m`;

            console.log(`${prefix} ${content}`);
        });

        miniProgram.on('exception', (err) => {
            const time = new Date().toLocaleTimeString('zh-CN', { hour12: false });
            console.log(`\x1b[41m\x1b[37m[${time}] [EXCEPTION]\x1b[0m \x1b[31m${err.message || err}\x1b[0m`);
            if (err.stack) console.log(`\x1b[31m${err.stack}\x1b[0m`);
        });

        await new Promise(resolve => setTimeout(resolve, duration * 1000));

        console.log('------------------------------------------------------------');
        console.log(`[LIVE] 监听结束。\n`);
        await miniProgram.disconnect();

    } catch (err) {
        console.error(`\x1b[31m[ERROR] ${err.message || String(err)}\x1b[0m`);
        process.exit(0);
    }
}

main();
