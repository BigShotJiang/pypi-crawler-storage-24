#!/usr/bin/env node
/**
 * navigate_capture.js
 * 连接微信开发者工具自动化端口，跳转到指定页面，
 * 等待指定毫秒数后收集所有 console/exception 事件，输出为 JSON。
 *
 * 用法：
 *   node navigate_capture.js --port <端口> --page <页面路径> --wait <毫秒>
 *
 * 示例：
 *   node navigate_capture.js --port 9420 --page /pages/index/index --wait 3000
 */

'use strict';

const automator = require('miniprogram-automator');

function parseArgs(argv) {
    const args = { port: 9420, page: '', wait: 2000 };
    for (let i = 2; i < argv.length; i++) {
        switch (argv[i]) {
            case '--port':
                args.port = parseInt(argv[++i], 10);
                break;
            case '--page':
                args.page = argv[++i];
                break;
            case '--wait':
                args.wait = Math.min(Math.max(parseInt(argv[++i], 10), 100), 30000);
                break;
        }
    }
    return args;
}

function formatTime(ts) {
    const d = new Date(ts);
    return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}:${String(d.getSeconds()).padStart(2, '0')}.${String(d.getMilliseconds()).padStart(3, '0')}`;
}

async function main() {
    const args = parseArgs(process.argv);
    const { port, page, wait } = args;

    if (!page) {
        process.stdout.write(JSON.stringify({ success: false, error: '必须指定 --page 参数' }));
        process.exit(0);
        return;
    }

    const consoleLogs = [];
    const exceptions = [];
    let currentPageInfo = null;
    let miniProgram = null;

    try {
        miniProgram = await automator.connect({
            wsEndpoint: `ws://localhost:${port}`,
        });

        // 注册事件监听（需在跳转前注册）
        miniProgram.on('console', (msg) => {
            const ts = Date.now();
            consoleLogs.push({
                time: formatTime(ts),
                timestamp: ts,
                type: msg.type || 'log',
                args: msg.args || [],
            });
        });

        miniProgram.on('exception', (err) => {
            const ts = Date.now();
            exceptions.push({
                time: formatTime(ts),
                timestamp: ts,
                message: err.message || String(err),
                stack: err.stack || '',
            });
        });

        // 跳转页面
        const pagePath = page.startsWith('/') ? page : `/${page}`;
        const pageObj = await miniProgram.reLaunch(pagePath);

        // 等待页面稳定
        await new Promise((resolve) => setTimeout(resolve, wait));

        // 获取当前页面信息
        try {
            const currentPage = await miniProgram.currentPage();
            if (currentPage) {
                currentPageInfo = {
                    path: currentPage.path,
                    query: currentPage.query || {},
                };
            }
        } catch (_) {
            // 忽略页面信息读取失败
        }

        // 不调用 disconnect()，保持 IDE 自动化会话存活
    } catch (err) {
        const output = {
            success: false,
            error: err.message || String(err),
            port,
            page,
            wait_ms: wait,
            current_page: currentPageInfo,
            console_logs: consoleLogs,
            exceptions: exceptions,
        };
        process.stdout.write(JSON.stringify(output, null, 2));
        process.exit(0);
        return;
    }

    const output = {
        success: true,
        port,
        page,
        wait_ms: wait,
        current_page: currentPageInfo,
        console_logs: consoleLogs,
        exceptions: exceptions,
        summary: {
            total_logs: consoleLogs.length,
            errors: consoleLogs.filter(l => l.type === 'error').length,
            warnings: consoleLogs.filter(l => l.type === 'warn').length,
            exceptions: exceptions.length,
        },
    };
    process.stdout.write(JSON.stringify(output, null, 2));
    process.exit(0);
}

main().catch((err) => {
    process.stdout.write(JSON.stringify({ success: false, error: String(err) }, null, 2));
    process.exit(1);
});
