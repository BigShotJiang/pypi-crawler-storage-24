#!/usr/bin/env node
/**
 * ui_debug.js
 * 负责 UI 和状态相关的调试任务：截图、页面数据、Storage、执行代码。
 */

'use strict';

const automator = require('miniprogram-automator');
const path = require('path');
const fs = require('fs');

function parseArgs(argv) {
    const args = { port: 9420, action: '', path: '', key: '', code: '', segmentsDir: '', overlap: 50 };
    for (let i = 2; i < argv.length; i++) {
        switch (argv[i]) {
            case '--port': args.port = parseInt(argv[++i], 10); break;
            case '--action': args.action = argv[++i]; break; // screenshot, data, storage, evaluate, full_screenshot
            case '--path': args.path = argv[++i]; break; // screenshot path
            case '--key': args.key = argv[++i]; break; // storage key
            case '--code': args.code = argv[++i]; break; // evaluate code
            case '--segments-dir': args.segmentsDir = argv[++i]; break;
            case '--overlap': args.overlap = parseInt(argv[++i], 10); break;
        }
    }
    return args;
}

async function main() {
    const args = parseArgs(process.argv);
    const { port, action } = args;

    let miniProgram = null;

    try {
        miniProgram = await automator.connect({
            wsEndpoint: `ws://localhost:${port}`,
        });

        let result = { success: true };

        switch (action) {
            case 'full_screenshot': {
                if (!args.segmentsDir) throw new Error('缺失 --segments-dir 参数');
                const sysInfo = await miniProgram.systemInfo();
                const winH = sysInfo.windowHeight;

                const scrollH = await miniProgram.evaluate(function () {
                    return new Promise(resolve => {
                        wx.createSelectorQuery()
                            .selectViewport()
                            .scrollOffset(r => resolve(r.scrollHeight))
                            .exec();
                    });
                });

                const overlap = args.overlap || 50;
                const step = winH > overlap ? winH - overlap : winH;
                const segments = [];

                if (scrollH <= winH) {
                    const segPath = path.join(args.segmentsDir, `seg_0.png`);
                    await miniProgram.screenshot({ path: segPath });
                    segments.push({ path: segPath, offset: 0, winH });
                } else {
                    let offset = 0;
                    let segIndex = 0;

                    await miniProgram.pageScrollTo(0);
                    await new Promise(r => setTimeout(r, 600));

                    while (true) {
                        const segPath = path.join(args.segmentsDir, `seg_${segIndex}.png`);
                        await miniProgram.screenshot({ path: segPath });
                        segments.push({ path: segPath, offset, winH });

                        if (offset + winH >= scrollH) {
                            break;
                        }

                        offset += step;
                        if (offset + winH > scrollH) {
                            offset = scrollH - winH;
                        }

                        segIndex++;
                        await miniProgram.pageScrollTo(offset);
                        await new Promise(r => setTimeout(r, 600));
                    }
                    await miniProgram.pageScrollTo(0);
                }

                result.segments = segments;
                result.scrollHeight = scrollH;
                result.windowHeight = winH;
                break;
            }

            case 'screenshot':
                const savePath = args.path || path.join(process.cwd(), `screenshot_${Date.now()}.png`);
                await miniProgram.screenshot({ path: savePath });
                result.savePath = savePath;
                // 如果文件存在，读取并返回一小段确认信息
                if (fs.existsSync(savePath)) {
                    result.fileSize = fs.statSync(savePath).size;
                }
                break;

            case 'data':
                const page = await miniProgram.currentPage();
                if (page) {
                    result.data = await page.data();
                    result.path = page.path;
                } else {
                    result.success = false;
                    result.error = '无法获取当前页面';
                }
                break;

            case 'storage':
                if (args.key) {
                    const storageRes = await miniProgram.callWxMethod('getStorage', { key: args.key });
                    result.value = storageRes.data;
                } else {
                    const info = await miniProgram.callWxMethod('getStorageInfo');
                    result.keys = info.keys;
                    result.currentSize = info.currentSize;
                    result.limitSize = info.limitSize;
                }
                break;

            case 'evaluate':
                if (!args.code) {
                    throw new Error('缺失 --code 参数');
                }
                // 执行 eval
                result.result = await miniProgram.evaluate(new Function('return ' + args.code));
                break;

            default:
                throw new Error(`未知 action: ${action}`);
        }

        process.stdout.write(JSON.stringify(result, null, 2));
        // 不调用 disconnect()，保持 IDE 自动化会话存活
        process.exit(0);

    } catch (err) {
        process.stdout.write(JSON.stringify({
            success: false,
            error: err.message || String(err),
        }, null, 2));
        process.exit(0);
    }
}

main();
