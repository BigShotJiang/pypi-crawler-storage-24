const WebSocket = require('./node_modules/ws');
const http = require('http');

async function getTargets() {
    return new Promise((resolve, reject) => {
        const req = http.get('http://127.0.0.1:9222/json/list', (res) => {
            let data = '';
            res.on('data', (chunk) => data += chunk);
            res.on('end', () => {
                try {
                    resolve(JSON.parse(data));
                } catch (e) {
                    resolve([]);
                }
            });
        });
        req.on('error', reject);
        req.end();
    });
}

const duration = parseInt(process.argv[2]) || 15;
const activeConnections = new Map();
let logs = [];

function addLog(type, targetUrl, targetType, data) {
    logs.push({
        timestamp: new Date().toISOString(),
        type: type,
        url: targetUrl,
        targetType: targetType,
        content: data
    });
}

async function monitorTarget(target) {
    if (activeConnections.has(target.id)) return;

    // 排除 IDE 自身的 UI 界面，采集小程序相关的所有目标
    const isIdeUI = target.url && (target.url.startsWith('devtools://') || target.url.startsWith('chrome-extension://') || target.url === '微信开发者工具');
    if (isIdeUI && target.type !== 'webview') return;

    activeConnections.set(target.id, true);
    process.stderr.write(`[ATTACHING] ${target.type} - ${target.url}\n`);

    try {
        const ws = new WebSocket(target.webSocketDebuggerUrl);

        ws.on('open', () => {
            ws.send(JSON.stringify({ id: 1, method: 'Console.enable' }));
            ws.send(JSON.stringify({ id: 2, method: 'Runtime.enable' }));
            ws.send(JSON.stringify({ id: 3, method: 'Log.enable' }));
        });

        ws.on('message', (data) => {
            try {
                const msg = JSON.parse(data);
                const method = msg.method;
                const params = msg.params;

                if (!method) return;

                if (method === 'Console.messageAdded') {
                    addLog('CONSOLE', target.url, target.type, params.message);
                }
                else if (method === 'Runtime.consoleAPICalled') {
                    addLog('RUNTIME_CONSOLE', target.url, target.type, {
                        type: params.type,
                        args: params.args.map(a => a.value || a.description || 'unserializable')
                    });
                }
                else if (method === 'Runtime.exceptionThrown') {
                    addLog('EXCEPTION', target.url, target.type, params.exceptionDetails);
                }
            } catch (e) { }
        });

        ws.on('close', () => activeConnections.delete(target.id));
        ws.on('error', () => activeConnections.delete(target.id));
    } catch (e) {
        activeConnections.delete(target.id);
    }
}

async function run() {
    process.stderr.write(`Full capture monitoring for ${duration} seconds...\n`);

    setTimeout(() => {
        console.log(JSON.stringify(logs, null, 2));
        process.exit(0);
    }, duration * 1000);

    const interval = setInterval(async () => {
        try {
            const targets = await getTargets();
            for (const target of targets) {
                await monitorTarget(target);
            }
        } catch (e) { }
    }, 1000);
}

run();
