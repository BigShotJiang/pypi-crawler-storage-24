"""Bamboo Claw distributed client agent for OpenClaw gateways."""

__version__ = "0.1.0"
