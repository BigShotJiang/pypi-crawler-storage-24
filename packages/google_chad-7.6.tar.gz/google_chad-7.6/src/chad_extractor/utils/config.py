#!/usr/bin/env python3

APP_VERSION = "v7.6"

REPORT_EXTENSION = ".report.json"

def banner():
	"""
	Display the banner.
	"""
	print("#########################################################################")
	print("#                                                                       #")
	print("#                          Chad Extractor v7.6                          #")
	print("#                                                                       #")
	print("# Extract and validate data from Chad results or plaintext files.       #")
	print("# GitHub repository at github.com/ivan-sincek/chad.                     #")
	print("#                                                                       #")
	print("#########################################################################")
