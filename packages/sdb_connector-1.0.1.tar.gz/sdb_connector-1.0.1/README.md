# sdb_connector

Python package with Rust/PyO3 bindings for SurrealDB access and data preparation.

## Install

```bash
pip install sdb-connector
```

Import in Python:

```python
import sdb_connector
```

## Versioning

Version is taken from `Cargo.toml` (`[package].version`).

## Local Build

```bash
python -m pip install --upgrade maturin twine
maturin build --release --sdist --out dist
python -m twine check dist/*
```

## Publish Manually

### TestPyPI

```bash
export MATURIN_PYPI_TOKEN=<testpypi-token>
maturin publish --repository testpypi --username __token__ --password "$MATURIN_PYPI_TOKEN"
```

### PyPI

```bash
export MATURIN_PYPI_TOKEN=<pypi-token>
maturin publish --username __token__ --password "$MATURIN_PYPI_TOKEN"
```

## GitHub Actions Publish

A workflow is included at `.github/workflows/publish-pypi.yml`:

- `workflow_dispatch` -> publish to `testpypi` or `pypi`
- `release.published` -> publish to `pypi`

Recommended: configure Trusted Publishing in PyPI/TestPyPI for this repository.
