_Release Notes: v0.0.6 -> e5ce6e4c29df90116408e9863744bd595e5308a4_

-----

### :trophy: Features
* [(e5ce6e4)](https://github.com/google/ml-flashpoint/+/e5ce6e4c29df90116408e9863744bd595e5308a4) adapter/nemo: Allow `initial_write_buffer_size_bytes=None` to use default size (#76)
* [(78f20d7)](https://github.com/google/ml-flashpoint/+/78f20d70e658b03f54109e8de35024fd695e1509) Cache checkpoint saving plan in each local rank. (#60)

### :clock1: Performance
* [(ae95fb6)](https://github.com/google/ml-flashpoint/+/ae95fb61c564f1fdb94117fad38ddda6743c8d8e) adapter/pytorch: offload spawn manager creation to background thread (threading.Thread) (#73)

### :recycle: Refactoring
* [(984b718)](https://github.com/google/ml-flashpoint/+/984b71800ec85f408563121c09e14c4a87eb3d30) core/loader: abstract torch.distributed APIs in CheckpointLoader (#47)

### :notebook_with_decorative_cover: Documentation
* [(7c653cb)](https://github.com/google/ml-flashpoint/+/7c653cb7eefba5cd7694fcfc200f730a017bf71f) user-guide: document use_optimized_save and use_cached_ckpt_structure (#72)

### :arrows_clockwise: CI
* [(dcb28da)](https://github.com/google/ml-flashpoint/+/dcb28dabadf421434f06bd1b6d187f2e454f4161) remove docker dependency from GCB pipeline (#71)

### :nut_and_bolt: Chores
* [(d69def3)](https://github.com/google/ml-flashpoint/+/d69def3b1742f7482d8dbd27b776750bc265706a) Update PULL_REQUEST_TEMPLATE.md to include description of change (#77)

-----

_Generated with: `./scripts/create_release.py`_