"""Rio local client package."""
