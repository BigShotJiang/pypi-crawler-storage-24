#!/usr/bin/env python3
from pathlib import Path
from mcmicroprep.microscopes.base import MicroscopeHandler


class RareCyteHandler(MicroscopeHandler):
    name = "rarecyte"

    def validate_dataset(self, image_root: Path) -> None:
        slide_names = [
            p.name
            for p in image_root.iterdir()
            if p.is_dir()
            and p.name
            not in {"templates", "microscopes", "raw", "misc_files", "__pycache__"}
        ]
        if not slide_names:
            return

        missing = []
        for slide_name in slide_names:
            slide = image_root / slide_name
            has_rcpnl = any(path.is_file() for path in slide.rglob("*.rcpnl"))
            if not has_rcpnl:
                missing.append(slide)

        if missing:
            missing_str = "\n".join(f"- {p}" for p in missing)
            raise ValueError(
                "RareCyte dataset validation failed. No '*.rcpnl' files found in:\n"
                f"{missing_str}"
            )

    def restructure_raw(self, image_root: Path):
        def move_tree(src: Path, dst: Path) -> None:
            if src.is_dir():
                dst.mkdir(exist_ok=True)
                for child in list(src.iterdir()):
                    move_tree(child, dst / child.name)
                try:
                    src.rmdir()
                except OSError:
                    return
            else:
                if dst.exists():
                    return
                dst.parent.mkdir(parents=True, exist_ok=True)
                src.rename(dst)

        raw_root = image_root / "raw"
        misc_root = image_root / "misc_files"
        raw_root.mkdir(exist_ok=True)
        misc_root.mkdir(exist_ok=True)

        slide_dirs = [
            p
            for p in image_root.iterdir()
            if p.is_dir()
            and p.name
            not in {"templates", "microscopes", "raw", "misc_files", "__pycache__"}
        ]

        for slide in slide_dirs:
            raw_slide = raw_root / slide.name
            misc_slide = misc_root / slide.name
            raw_slide.mkdir(parents=True, exist_ok=True)
            misc_slide.mkdir(parents=True, exist_ok=True)

            for path in list(slide.rglob("*.rcpnl")):
                if raw_root in path.parents or misc_root in path.parents:
                    continue
                dest = raw_slide / path.name
                if dest.exists():
                    continue
                dest.parent.mkdir(parents=True, exist_ok=True)
                path.rename(dest)

            for item in list(slide.iterdir()):
                if item.name in {"raw", "misc_files"} and item.is_dir():
                    for child in list(item.iterdir()):
                        move_tree(child, misc_slide / child.name)
                    for path in sorted(
                        item.rglob("*"), key=lambda p: len(p.parts), reverse=True
                    ):
                        if path.is_dir():
                            try:
                                path.rmdir()
                            except OSError:
                                pass
                    try:
                        item.rmdir()
                    except OSError:
                        pass
                else:
                    move_tree(item, misc_slide / item.name)

            for path in sorted(
                slide.rglob("*"), key=lambda p: len(p.parts), reverse=True
            ):
                if path.is_dir():
                    try:
                        path.rmdir()
                    except OSError:
                        pass
            try:
                slide.rmdir()
            except OSError:
                pass

    def params_template(self) -> dict:
        return {}
