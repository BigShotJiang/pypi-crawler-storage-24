#!/usr/bin/env python3
import subprocess
import sys
import re
from pathlib import Path
from mcmicroprep.microscopes.base import MicroscopeHandler


class OlympusHandler(MicroscopeHandler):
    name = "olympus"

    def validate_dataset(self, image_root: Path) -> None:
        excluded = {
            "dataset",
            "templates",
            "microscopes",
            "raw",
            "misc_files",
            "__pycache__",
        }

        slide_roots = [
            p for p in image_root.iterdir() if p.is_dir() and p.name not in excluded
        ]
        if not slide_roots:
            raw_root = image_root / "raw"
            if raw_root.is_dir():
                slide_roots = [p for p in raw_root.iterdir() if p.is_dir()]

        if not slide_roots:
            return

        missing = []
        for slide in slide_roots:
            frames = [
                path
                for path in slide.rglob("*_frames")
                if path.is_dir() and "overview" not in path.name.lower()
            ]
            if not frames:
                missing.append(slide)
                continue

        if missing:
            missing_str = "\n".join(f"- {p}" for p in missing)
            raise ValueError(
                "Olympus dataset validation failed. No '*_frames' folders found in:\n"
                f"{missing_str}"
            )

    def restructure_raw(self, image_root: Path):
        def move_tree(src: Path, dst: Path) -> None:
            if src.is_dir():
                dst.mkdir(exist_ok=True)
                for child in list(src.iterdir()):
                    move_tree(child, dst / child.name)
                try:
                    src.rmdir()
                except OSError:
                    return
            else:
                if dst.exists():
                    return
                dst.parent.mkdir(parents=True, exist_ok=True)
                src.rename(dst)

        def normalize_frames_dir_name(frames_dir: Path) -> Path:
            if " " not in frames_dir.name:
                return frames_dir
            new_name = re.sub(r"\s+", "_", frames_dir.name).strip("_")
            if new_name == frames_dir.name:
                return frames_dir
            new_path = frames_dir.with_name(new_name)
            if new_path.exists():
                raise ValueError(
                    "Olympus restructure failed. Cannot rename frames folder due to name conflict:\n"
                    f"from: {frames_dir}\n"
                    f"to:   {new_path}"
                )
            print(
                "Renamed frames folder due to spaces:\n"
                f"from: {frames_dir}\n"
                f"to:   {new_path}"
            )
            frames_dir.rename(new_path)
            return new_path

        raw_root = image_root / "raw"
        misc_root = image_root / "misc_files"
        raw_root.mkdir(exist_ok=True)
        misc_root.mkdir(exist_ok=True)

        slide_dirs = [
            p
            for p in image_root.iterdir()
            if p.is_dir()
            and p.name
            not in {
                "dataset",
                "templates",
                "microscopes",
                "raw",
                "misc_files",
                "__pycache__",
            }
        ]

        for slide in slide_dirs:
            raw_slide = raw_root / slide.name
            misc_slide = misc_root / slide.name
            raw_slide.mkdir(parents=True, exist_ok=True)
            misc_slide.mkdir(parents=True, exist_ok=True)

            frames_with_spaces = [
                p for p in slide.rglob("*_frames") if p.is_dir() and " " in p.name
            ]
            for frames_dir in sorted(
                frames_with_spaces, key=lambda p: len(p.parts), reverse=True
            ):
                normalize_frames_dir_name(frames_dir)

            frames_dirs = [
                p
                for p in slide.rglob("*_frames")
                if p.is_dir()
                and raw_root not in p.parents
                and misc_root not in p.parents
                and p != raw_root
                and p != misc_root
            ]
            for frames_dir in frames_dirs:
                is_overview = "overview" in frames_dir.name.lower()
                dest = (misc_slide if is_overview else raw_slide) / frames_dir.name
                if dest.exists():
                    raise ValueError(
                        "Olympus restructure failed due to conflicting frames directory "
                        f"names: '{frames_dir}' and '{dest}'"
                    )
                dest.parent.mkdir(parents=True, exist_ok=True)
                frames_dir.rename(dest)

            for item in list(raw_slide.iterdir()):
                if (
                    item.is_dir()
                    and item.name.endswith("_frames")
                    and "overview" in item.name.lower()
                ):
                    dest = misc_slide / item.name
                    if not dest.exists():
                        item.rename(dest)

            for item in list(slide.iterdir()):
                if item.name in {"raw", "misc_files"} and item.is_dir():
                    for child in list(item.iterdir()):
                        move_tree(child, misc_slide / child.name)
                    for path in sorted(
                        item.rglob("*"), key=lambda p: len(p.parts), reverse=True
                    ):
                        if path.is_dir():
                            try:
                                path.rmdir()
                            except OSError:
                                pass
                    try:
                        item.rmdir()
                    except OSError:
                        pass
                else:
                    move_tree(item, misc_slide / item.name)

            for path in sorted(
                slide.rglob("*"), key=lambda p: len(p.parts), reverse=True
            ):
                if path.is_dir():
                    try:
                        path.rmdir()
                    except OSError:
                        pass
            try:
                slide.rmdir()
            except OSError:
                pass

        for frame in raw_root.rglob("*_frames"):
            if not frame.is_dir() or "overview" in frame.name.lower():
                continue
            ome = frame / "image.companion.ome"
            if not ome.exists():
                subprocess.run(
                    [sys.executable, "-m", "mcmicroprep.companion_script", str(frame)],
                    check=True,
                )

    def params_template(self) -> dict:
        # Not used when file-based params selection is preferred
        return {}
