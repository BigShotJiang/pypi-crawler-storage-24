#!/bin/bash
#SBATCH -p short
#SBATCH -J nextflow_O2
#SBATCH -t 0-12:00
#SBATCH --mem=1G
#SBATCH --mail-type=END

DATASETDIR="${1:-${SLURM_SUBMIT_DIR:-$(pwd)}}"
DATASETDIR="$(cd "$DATASETDIR" && pwd)"
DATASETID=$(basename "$DATASETDIR")

module purge
module load java

/n/groups/lsp/mcmicro/tools/o2/config_pre_reg.sh -s -u "$DATASETDIR" > "$DATASETDIR/memory.config"

/home/ajn16/softwares/nextflow run labsyspharm/mcmicro -profile O2,WSI,GPU --in "$DATASETDIR" -w /n/scratch/users/${USER:0:1}/$USER/work -c "$DATASETDIR/base.config"
