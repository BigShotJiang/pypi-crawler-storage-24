"""Identity JWT cache expiry check."""
import time
from typing import Any, Dict


def is_identity_token_expired(cached_payload: Dict[str, Any]) -> bool:
    """True if cached_payload has 'exp' and it is in the past."""
    exp = cached_payload.get("exp")
    if exp is None:
        return False
    try:
        return float(exp) < time.time()
    except (TypeError, ValueError):
        return False
