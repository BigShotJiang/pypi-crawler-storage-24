"""Role enums, auth methods, and RAC/Identity mappings for DTA services."""
from enum import StrEnum


class DTARoles(StrEnum):
    """DTA role levels for authorization."""

    SUPER = "SUPER"
    ORG_ADMIN = "ORG_ADMIN"
    TENANT_VIEWER = "TENANT_VIEWER"
    TENANT_ADMIN = "TENANT_ADMIN"
    AGENT_USER = "AGENT_USER"


class DTAAuthMethods(StrEnum):
    """Auth method identifier."""

    JWT = "JWT"
    API_KEY = "API_KEY"
    SERVICE_KEY = "SERVICE_KEY"


DTA_ISSUER = "dta.totvs.ai"

DTA_STUDIO_ROLE_NAMES = (
    "DTA Studio Admin",
    "DTA Studio Viewer",
    "DTA Studio User",
)

# RAC role display name -> DTARoles.
RAC_STUDIO_NAME_TO_DTA_ROLE = {
    "DTA Studio Admin": DTARoles.TENANT_ADMIN,
    "DTA Studio Viewer": DTARoles.TENANT_VIEWER,
    "DTA Studio User": DTARoles.AGENT_USER,
}

# DTA role name -> RAC permission string.
RAC_PERMISSIONS_MAPPING = {
    "DTA Studio Admin": "totvs.dta.studio.admin",
    "DTA Studio Viewer": "totvs.dta.studio.viewer",
    "DTA Studio User": "totvs.dta.studio.user",
}
