from datetime import datetime, timedelta
from typing import Annotated, Any

from arcade_mcp_server import Context, tool
from arcade_mcp_server.auth import Microsoft
from arcade_mcp_server.exceptions import ToolExecutionError
from arcade_mcp_server.metadata import (
    Behavior,
    Classification,
    Operation,
    ServiceDomain,
    ToolMetadata,
)
from arcade_microsoft_utils.utils import validate_pagination_url

from arcade_outlook_calendar._utils import (
    build_event_filter,
    convert_timezone_to_offset,
    get_default_calendar_timezone,
    prepare_search_events_request_config,
    replace_timezone_offset,
    validate_date_times,
)
from arcade_outlook_calendar.client import get_client
from arcade_outlook_calendar.enums import EventImportance
from arcade_outlook_calendar.models import Event


@tool(
    requires_auth=Microsoft(scopes=["MailboxSettings.Read", "Calendars.Read"]),
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.CALENDAR],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def search_events(
    context: Context,
    subject: Annotated[
        str | None,
        "Filter events whose subject contains this text (case-insensitive). "
        "Defaults to None (no subject filter).",
    ] = None,
    attendee_emails: Annotated[
        list[str] | None,
        "Filter events that include these attendees by exact email address. "
        "Multiple emails are combined with AND (all must be attendees). "
        "Defaults to None (no attendee filter).",
    ] = None,
    organizer_name: Annotated[
        str | None,
        "Filter events organized by this person's display name. "
        "Note: filtering by organizer email address is not supported by the "
        "Microsoft Graph API. Use the organizer's display name instead. "
        "Defaults to None (no organizer filter).",
    ] = None,
    importance: Annotated[
        EventImportance | None,
        "Filter by event importance level. Defaults to None (no filter).",
    ] = None,
    is_online_meeting: Annotated[
        bool | None,
        "Filter for online meetings (True) or in-person meetings (False). "
        "Defaults to None (no filter).",
    ] = None,
    start_date_time: Annotated[
        str | None,
        "The start of the time range, in ISO 8601 format. "
        "Timezone offset is ignored; the user's calendar timezone is used. "
        "Defaults to None (90 days before today).",
    ] = None,
    end_date_time: Annotated[
        str | None,
        "The end of the time range, in ISO 8601 format. "
        "Timezone offset is ignored; the user's calendar timezone is used. "
        "Defaults to None (90 days after today).",
    ] = None,
    calendar_id: Annotated[
        str | None,
        "ID of a specific calendar to search, including shared and delegated ones. "
        "When omitted, searches the user's default calendar.",
    ] = None,
    include_cancelled: Annotated[
        bool,
        "Whether to include cancelled events in the results. Defaults to False.",
    ] = False,
    limit: Annotated[
        int,
        "Maximum number of events to return. Max is 200. Defaults to 25.",
    ] = 25,
    pagination_token: Annotated[
        str | None,
        "The pagination token to continue a previous request.",
    ] = None,
) -> Annotated[dict, "A dictionary containing a list of matching calendar events."]:
    """Search calendar events within a time range with optional filters.

    Returns events filtered by subject keyword, attendee, organizer,
    importance, or online-meeting status. Results are in chronological order.

    By default, searches the user's primary calendar. Pass a calendar_id
    to search a shared or delegated calendar.

    Event bodies are truncated to 200 characters for efficient skimming.
    Use the event_id from the results to retrieve full event details.
    """
    client = get_client(context.get_auth_token_or_empty())

    if pagination_token:
        validate_pagination_url(pagination_token)
        response = await client.me.calendar.calendar_view.with_url(pagination_token).get()
        events = [
            Event.from_sdk(event).to_dict(max_body_length=200)
            for event in ((response.value if response else None) or [])
        ]
        result: dict = {
            "events": events,
            "num_events": len(events),
        }
        next_link = getattr(response, "odata_next_link", None)
        if next_link:
            result["pagination_token"] = next_link
        return result

    has_filter = any([subject, attendee_emails, organizer_name, importance, is_online_meeting])
    has_time_range = start_date_time is not None or end_date_time is not None
    if not has_filter and not has_time_range:
        raise ToolExecutionError(
            message="At least one search filter (subject, attendee_emails, organizer_name, "
            "importance, is_online_meeting) or a time range (start_date_time, end_date_time) "
            "is required."
        )

    now = datetime.now()
    resolved_start = start_date_time or (now - timedelta(days=90)).strftime("%Y-%m-%dT%H:%M:%S")
    resolved_end = end_date_time or (now + timedelta(days=90)).strftime("%Y-%m-%dT%H:%M:%S")
    validate_date_times(resolved_start, resolved_end)

    max_range_days = 1825
    start_naive = datetime.fromisoformat(resolved_start).replace(tzinfo=None)
    end_naive = datetime.fromisoformat(resolved_end).replace(tzinfo=None)
    if (end_naive - start_naive).days > max_range_days:
        raise ToolExecutionError(
            message=f"The time range exceeds the maximum allowed by the Microsoft Graph API "
            f"({max_range_days} days). Please narrow your start_date_time and/or end_date_time.",
        )

    time_zone = await get_default_calendar_timezone(client)
    time_zone_offset = convert_timezone_to_offset(time_zone)
    resolved_start = replace_timezone_offset(resolved_start, time_zone_offset)
    resolved_end = replace_timezone_offset(resolved_end, time_zone_offset)

    view_builder: Any
    if calendar_id:
        view_builder = client.me.calendars.by_calendar_id(calendar_id).calendar_view
    else:
        view_builder = client.me.calendar.calendar_view

    importance_value = importance.value if importance else None
    filter_expression = build_event_filter(
        subject=subject,
        attendee_emails=attendee_emails,
        organizer_name=organizer_name,
        importance=importance_value,
        is_online_meeting=is_online_meeting,
        include_cancelled=include_cancelled,
    )

    request_config = prepare_search_events_request_config(
        start_date_time=resolved_start,
        end_date_time=resolved_end,
        time_zone=time_zone,
        limit=limit,
        filter_expression=filter_expression,
    )
    response = await view_builder.get(request_configuration=request_config)

    events = [
        Event.from_sdk(event).to_dict(max_body_length=200)
        for event in ((response.value if response else None) or [])
    ]

    result = {
        "events": events,
        "num_events": len(events),
    }

    if filter_expression:
        result["filter_expression"] = filter_expression

    next_link = getattr(response, "odata_next_link", None)
    if next_link:
        result["pagination_token"] = next_link

    return result
