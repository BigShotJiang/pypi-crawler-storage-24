from typing import Annotated, Any

from arcade_mcp_server import Context, tool
from arcade_mcp_server.auth import Microsoft
from arcade_mcp_server.metadata import (
    Behavior,
    Classification,
    Operation,
    ServiceDomain,
    ToolMetadata,
)

from arcade_outlook_calendar.client import get_client
from arcade_outlook_calendar.who_am_i_util import build_who_am_i_response


@tool(
    requires_auth=Microsoft(
        scopes=[
            "User.Read",
            "Calendars.ReadBasic",
        ]
    ),
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.CALENDAR],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def who_am_i(
    context: Context,
) -> Annotated[
    dict[str, Any],
    "Get comprehensive user profile and Outlook Calendar information.",
]:
    """
    Get information about the current user and their Outlook Calendar environment.
    """
    client = get_client(context.get_auth_token_or_empty())
    user_info = await build_who_am_i_response(client)
    return dict(user_info)
