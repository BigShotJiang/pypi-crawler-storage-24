from typing import Annotated, Any

from arcade_mcp_server import Context, tool
from arcade_mcp_server.auth import Microsoft
from arcade_mcp_server.exceptions import ToolExecutionError
from arcade_mcp_server.metadata import (
    Behavior,
    Classification,
    Operation,
    ServiceDomain,
    ToolMetadata,
)
from arcade_microsoft_utils.utils import validate_pagination_url
from kiota_abstractions.api_error import APIError

from arcade_outlook_calendar._utils import prepare_list_event_attachments_request_config
from arcade_outlook_calendar.attachment import Attachment
from arcade_outlook_calendar.client import get_client


@tool(
    requires_auth=Microsoft(scopes=["Calendars.Read"]),
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.CALENDAR],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def list_event_attachments(
    context: Context,
    event_id: Annotated[str, "The ID of the calendar event to list attachments for."],
    calendar_id: Annotated[
        str | None,
        "ID of a specific calendar containing the event, including shared and "
        "delegated ones. When omitted, searches the user's default calendar.",
    ] = None,
    limit: Annotated[
        int, "The maximum number of attachments to return. Max is 100. Defaults to 25."
    ] = 25,
    pagination_token: Annotated[
        str | None, "The pagination token to continue a previous request."
    ] = None,
) -> Annotated[dict, "A dictionary containing a list of attachment metadata objects."]:
    """List attachment metadata for a calendar event.

    Returns metadata only (name, size, type, etc.). Attachment content is not included.
    Use this tool when the user wants to know what files are attached to a calendar event
    or meeting.

    Pass a calendar_id to list attachments on events in shared or delegated calendars.
    """
    client = get_client(context.get_auth_token_or_empty())
    request_config = prepare_list_event_attachments_request_config(limit)

    event_builder: Any
    if calendar_id:
        event_builder = client.me.calendars.by_calendar_id(calendar_id).events.by_event_id(event_id)
    else:
        event_builder = client.me.events.by_event_id(event_id)

    attachments_builder = event_builder.attachments

    try:
        if pagination_token:
            validate_pagination_url(pagination_token)
            response = await attachments_builder.with_url(pagination_token).get()
        else:
            response = await attachments_builder.get(request_configuration=request_config)
    except APIError as e:
        if e.response_status_code == 404:
            msg = f"Event not found: {event_id}"
            if calendar_id:
                msg += f" in calendar {calendar_id}"
            raise ToolExecutionError(message=msg) from e
        raise

    attachments = [
        Attachment.from_sdk(att).to_dict() for att in (response.value if response else None) or []
    ]

    result: dict = {
        "attachments": attachments,
        "num_attachments": len(attachments),
        "event_id": event_id,
    }

    if calendar_id:
        result["calendar_id"] = calendar_id

    next_link = getattr(response, "odata_next_link", None)
    if next_link:
        result["pagination_token"] = next_link

    return result
