from typing import Annotated

from arcade_mcp_server import Context, tool
from arcade_mcp_server.auth import Microsoft
from arcade_mcp_server.metadata import (
    Behavior,
    Classification,
    Operation,
    ServiceDomain,
    ToolMetadata,
)
from arcade_microsoft_utils.utils import validate_pagination_url
from kiota_abstractions.base_request_configuration import RequestConfiguration
from msgraph.generated.users.item.calendars.calendars_request_builder import (
    CalendarsRequestBuilder,
)

from arcade_outlook_calendar.client import get_client


@tool(
    requires_auth=Microsoft(scopes=["Calendars.ReadBasic"]),
    metadata=ToolMetadata(
        classification=Classification(
            service_domains=[ServiceDomain.CALENDAR],
        ),
        behavior=Behavior(
            operations=[Operation.READ],
            read_only=True,
            destructive=False,
            idempotent=True,
            open_world=True,
        ),
    ),
)
async def list_calendars(
    context: Context,
    limit: Annotated[
        int,
        "Maximum number of calendars to return. Max is 200. Defaults to 50.",
    ] = 50,
    pagination_token: Annotated[
        str | None,
        "The pagination token to continue a previous request.",
    ] = None,
) -> Annotated[dict, "A dictionary containing a list of available calendars."]:
    """List all calendars the user has access to.

    Returns the user's own calendars plus any shared or delegated calendars.
    Each calendar includes its ID, name, owner, and permissions.

    Use a calendar_id from the results to target a specific calendar
    in other calendar tools.
    """
    client = get_client(context.get_auth_token_or_empty())

    calendars_builder = client.me.calendars

    if pagination_token:
        validate_pagination_url(pagination_token)
        response = await calendars_builder.with_url(pagination_token).get()
    else:
        clamped_limit = max(1, min(limit, 200))
        query_params = CalendarsRequestBuilder.CalendarsRequestBuilderGetQueryParameters(
            top=clamped_limit,
        )
        config = RequestConfiguration(query_parameters=query_params)
        response = await calendars_builder.get(request_configuration=config)

    calendars = []
    for cal in (response.value if response else None) or []:
        calendars.append({
            "calendar_id": cal.id or "",
            "name": cal.name or "",
            "owner": {
                "name": cal.owner.name if cal.owner and cal.owner.name else "",
                "address": cal.owner.address if cal.owner and cal.owner.address else "",
            },
            "can_edit": bool(cal.can_edit),
            "is_default": bool(cal.is_default_calendar),
        })

    result: dict = {
        "calendars": calendars,
        "num_calendars": len(calendars),
    }

    next_link = getattr(response, "odata_next_link", None)
    if next_link:
        result["pagination_token"] = next_link

    return result
