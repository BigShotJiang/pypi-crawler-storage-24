from enum import Enum


class EventImportance(str, Enum):
    """Event importance level used in calendar filtering."""

    LOW = "low"
    NORMAL = "normal"
    HIGH = "high"
