"""
Tests for BSRN Physics modules.
BSRN 物理模块测试。
"""

import os
import sys
import unittest
import unittest.mock
import pandas as pd
import numpy as np

# Ensure 'src' is in path / 确保 'src' 在路径中
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "src")))

from bsrn.io.readers import read_station_to_archive
from bsrn.io.mcclear import _parse_mcclear
from bsrn.modeling.clear_sky import add_clearsky_columns
from bsrn.physics.geometry import add_solpos_columns

# **Users can change these variables to their own directory / 用户可以根据自己的情况更改目录**
# Path to a sample file and directory for testing
# 用于测试的示例文件和目录路径
SAMPLE_FILE = "/Volumes/Macintosh Research/Data/bsrn-qc/data/QIQ/qiq0124.dat.gz"

class TestBSRNPhysics(unittest.TestCase):
    """
    Test suite for BSRN physics and clear-sky models.
    BSRN 物理和晴空模型测试套件。
    """

    def setUp(self):
        self.sample_file = SAMPLE_FILE

    def test_add_clearsky(self):
        """
        Test adding clear-sky columns to a QIQ data frame.
        测试向 QIQ 数据框添加晴空列。
        """
        if not os.path.exists(self.sample_file):
            self.skipTest(f"Sample file not found at {self.sample_file}")
            
        # Read data / 读取数据
        df = read_station_to_archive(self.sample_file)
        self.assertIsNotNone(df)
        
        # Add clear-sky columns / 添加晴空列
        # QIQ is the station code / QIQ 是站点缩写
        df = add_solpos_columns(df, station_code="QIQ")
        df = add_clearsky_columns(df, station_code="QIQ")
        
        # Check columns / 检查列
        for col in ["ghi_clear", "bni_clear", "dhi_clear"]:
            self.assertIn(col, df.columns)
            self.assertFalse(df[col].isnull().all(), f"Column {col} is all NaN")
            
        print("\nClear-sky results for QIQ (first 2 rows):")
        print(df[["ghi", "ghi_clear", "bni", "bni_clear"]].head(2))
        
        # Basic physical check: clear-sky GHI should be > 0 during day / 基础物理检查：白天晴空 GHI 应 > 0
        # Since this is Jan in QIQ (high latitude), we check a noon value / QIQ 1月（高纬度），检查中午值
        noon_val = df.between_time("04:00", "05:00")["ghi_clear"] # QIQ noon is approx 04:00 UTC
        self.assertTrue((noon_val > 0).any())

    def test_parse_mcclear(self):
        """
        Test McClear parser from raw text payload.
        测试从原始文本载荷解析 McClear。
        """
        raw_text = "\n".join([
            "# latitude: 47.7957",
            "# longitude: 124.4852",
            "# altitude: 170",
            "# Summarization (integration) period: 0 year 0 month 0 day 0 h 1 min 0 s",
            "# Observation period;TOA;Clear sky GHI;Clear sky BHI;Clear sky DHI;Clear sky BNI;sza",
            "2024-01-01T00:00:00Z/2024-01-01T01:00:00Z;0;120;90;30;140;80",
            "2024-01-01T01:00:00Z/2024-01-01T02:00:00Z;0;100;70;30;120;82",
        ])
        data = _parse_mcclear(raw_text)
        self.assertIn("ghi_clear", data.columns)
        self.assertIn("bni_clear", data.columns)
        self.assertIn("dhi_clear", data.columns)
        self.assertIn("zenith", data.columns)
        self.assertEqual(str(data.index.tz), "UTC")

    @unittest.mock.patch("bsrn.modeling.clear_sky.fetch_mcclear")
    def test_add_clearsky_mcclear_with_mocked_data(self, mock_fetch_mcclear):
        """
        Test add_clearsky_columns with McClear model using mocked CAMS helper.
        使用模拟的 CAMS 辅助函数测试 McClear 模型下的 add_clearsky_columns。
        """
        idx = pd.date_range("2024-01-01 00:00:00", periods=3, freq="1h", tz="UTC")
        df = pd.DataFrame(
            {"ghi": [0.0, 50.0, 100.0], "bni": [0.0, 30.0, 70.0], "dhi": [0.0, 20.0, 30.0],
             "zenith": [80.0, 70.0, 60.0], "apparent_zenith": [80.0, 70.0, 60.0], "bni_extra": [1361.0, 1361.0, 1361.0]},
            index=idx,
        )
        mcclear_data = pd.DataFrame(
            {
                "ghi_clear": [0.0, 80.0, 160.0],
                "bni_clear": [0.0, 120.0, 220.0],
                "dhi_clear": [0.0, 15.0, 25.0],
            },
            index=idx,
        )
        mock_fetch_mcclear.return_value = mcclear_data

        out = add_clearsky_columns(
            df.copy(),
            lat=47.7957,
            lon=124.4852,
            elev=170.0,
            model="mcclear",
            mcclear_email="stevenwangzw@gmail.com",
        )
        np.testing.assert_allclose(out["ghi_clear"].values, mcclear_data["ghi_clear"].values)
        np.testing.assert_allclose(out["bni_clear"].values, mcclear_data["bni_clear"].values)
        np.testing.assert_allclose(out["dhi_clear"].values, mcclear_data["dhi_clear"].values)

if __name__ == "__main__":
    unittest.main()
