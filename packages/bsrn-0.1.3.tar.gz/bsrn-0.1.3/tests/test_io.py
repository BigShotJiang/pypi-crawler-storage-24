import os
import sys
import pandas as pd

# Ensure 'src' is in path / 确保 'src' 在路径中
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "src")))

from bsrn.io.readers import read_lr0100, read_lr0300, read_lr4000, read_station_to_archive

def test_tat_august_readers():
    # Use August 2024 TAT file / 使用 2024 年 8 月 TAT 文件
    file_path = os.path.join(os.path.dirname(__file__), "..", "data", "TAT", "tat0824.dat.gz")
    
    if not os.path.exists(file_path):
        print(f"Skipping: {file_path} not found.")
        return

    print(f"\nTesting file: {os.path.basename(file_path)}")
    
    # 1. Test LR0100 individually / 单独测试 LR0100
    print("Reading LR0100...")
    df_0100 = read_lr0100(file_path)
    if df_0100 is not None:
        print(f"LR0100 success: {df_0100.shape[0]} rows, columns: {list(df_0100.columns)}")
        assert "ghi" in df_0100.columns
        assert not df_0100.empty
    else:
        print("LR0100 failed to read.")

    # 2. Test LR0300 individually / 单独测试 LR0300
    print("\nReading LR0300...")
    df_0300 = read_lr0300(file_path)
    if df_0300 is not None:
        print(f"LR0300 success: {df_0300.shape[0]} rows, columns: {list(df_0300.columns)}")
        print("First few rows of LR0300:")
        print(df_0300.head())
        
        # In TAT, swu/lwu/net should be part of 0300
        # 根据 TAT 格式，0300 包含 swu, lwu, net
        assert "swu" in df_0300.columns
        assert "lwu" in df_0300.columns
        assert "net" in df_0300.columns
        assert not df_0300.empty
    else:
        print("LR0300 failed to read.")

    # 3. Test LR4000 individually / 单独测试 LR4000
    print("\nReading LR4000...")
    df_4000 = read_lr4000(file_path)
    if df_4000 is not None:
        print(f"LR4000 success: {df_4000.shape[0]} rows, columns: {list(df_4000.columns)}")
        print("First few rows of LR4000:")
        print(df_4000.head())
        
        # Check for downward dome temperature and thermopile
        assert "td_dome1" in df_4000.columns
        assert "td_tp" in df_4000.columns
        assert not df_4000.empty
    else:
        print("LR4000 failed to read (might not be present in this file).")

    # 4. Test wrapper with all three / 测试同时包含三个记录的包装器
    print("\nReading with wrapper (LR0100 + LR0300 + LR4000)...")
    df_combined = read_station_to_archive(file_path, logical_records=["lr0100", "lr0300", "lr4000"])
    if df_combined is not None:
        print(f"Combined success: {df_combined.shape[0]} rows, columns: {list(df_combined.columns)}")
        # Check if it merged correctly / 检查是否正确合并
        assert "ghi" in df_combined.columns
        assert "swu" in df_combined.columns
        assert "td_dome1" in df_combined.columns
    else:
        print("Wrapper failed to read.")

if __name__ == "__main__":
    test_tat_august_readers()
