import os
import sys

import numpy as np
import pandas as pd
import pytest

# Add src to python path to ensure bsrn is importable
sys.path.append(os.path.join(os.getcwd(), "src"))

try:
    from bsrn.visualization import (
        plot_bsrn_availability,
        plot_clearsky_calendar,
        plot_k_vs_kt,
    )
    from bsrn.visualization.timeseries import plot_bsrn_timeseries_booklet
    from bsrn.visualization.qc_table import plot_qc_table
    from bsrn.visualization.cspoints import plot_csd_booklet
    from bsrn.visualization.clearsky_models import plot_clearsky_models_booklet
    from bsrn.utils.quality import get_daily_stats
    from bsrn.modeling.clear_sky import add_clearsky_columns
    from bsrn.physics.geometry import add_solpos_columns
    import bsrn.io.readers as readers
    from bsrn.constants import BSRN_STATIONS
    from datetime import datetime
except ImportError as e:
    print("Error: Could not import bsrn. Make sure you are running from the project root.", e)
    sys.exit(1)

# Users can change these variables to their own directory / 用户可以根据自己的情况更改目录
# --- CONFIGURATION ---
BSRN_USER = "bsrnftp"  # Replace with your BSRN FTP username / 替换为您的 BSRN FTP 用户名
BSRN_PASSWORD = "bsrn1"  # Replace with your BSRN FTP password / 替换为您的 BSRN FTP 密码
# SoDa email for McClear API; set here or via MCCLEAR_EMAIL env to include McClear in booklet
MCCLEAR_EMAIL = os.environ.get("MCCLEAR_EMAIL", "yangdazhi.nus@gmail.com")  # e.g. "your@email.com"

# List of stations you want to check
STATIONS_TO_CHECK = ['ABS', 'ALE', 'ASP', 'BAR', 'BER', 'BIL'] 

# Year range
START_YEAR = 1992

# Test for station QIQ, December 2024
FILE_PATH = "data/QIQ/qiq1224.dat.gz"
# Test for station QIQ, August 2024 (for calendar plots)
FILE_PATH_AUG = "data/QIQ/qiq0824.dat.gz"
# CSD booklet: September (place qiq0924.dat.gz in data/QIQ for this test)
FILE_PATH_CSD_BOOKLET = "data/QIQ/qiq0924.dat.gz"
# Directory for full-year test: place 12 monthly files (qiq0124.dat.gz ... qiq1224.dat.gz) in data/QIQ
DATA_DIR_YEAR = "data/QIQ"

def test_availability():
    print(f"\n--- Testing Availability Heatmap ---")
    print(f"Initiating BSRN FTP search for: {STATIONS_TO_CHECK}")

    try:
        output_file = "bsrn_availability_heatmap.pdf"
        plot_bsrn_availability(
            stations=STATIONS_TO_CHECK,
            username=BSRN_USER,
            password=BSRN_PASSWORD,
            start_year=START_YEAR,
            output_file=output_file
        )
        print(f"Successfully generated heatmap: {output_file}")
    except Exception as e:
        print(f"Availability heatmap failed: {e}")


def test_timeseries():
    print(f"\n--- Testing Timeseries Booklet ---")

    if not os.path.exists(FILE_PATH):
        print(f"Skipping timeseries test: {FILE_PATH} not found.")
        return

    try:
        output_file = "test_qiq_booklet.pdf"
        print(f"Generating booklet for {FILE_PATH}...")
        plot_bsrn_timeseries_booklet(
            FILE_PATH,
            output_file,
            station_code="QIQ",
            apply_qc=False
        )
        print(f"Successfully generated booklet: {output_file}")
    except Exception as e:
        print(f"Timeseries booklet failed: {e}")

def test_qc_table():
    print(f"\n--- Testing QC Table Heatmap ---")
    
    if not os.path.exists(FILE_PATH):
        print(f"Skipping QC table test: {FILE_PATH} not found.")
        return

    try:
        output_file = "test_qiq_qc_table.pdf"
        print(f"Reading {FILE_PATH}...")
        df = readers.read_station_to_archive(FILE_PATH)
        if df is not None:
            station_code = "QIQ"
            meta = BSRN_STATIONS[station_code]
            station_name = meta["name"]
            print("Calculating QC stats...")
            daily_stats = get_daily_stats(df, meta["lat"], meta["lon"], meta["elev"])
            
            filename = os.path.basename(FILE_PATH)
            month_label = datetime.strptime(filename[3:7], "%m%y").strftime("%B %Y")
            title = f"BSRN quality flags and sunshine duration for {station_code}, {month_label}"
            
            print(f"Generating plot: {output_file}...")
            plot_qc_table(daily_stats, title, output_file)
            print(f"Successfully generated QC table: {output_file}")
    except Exception as e:
        print(f"QC table plot failed: {e}")
        import traceback
        traceback.print_exc()


def test_separation_k_vs_kt():
    """Test k vs kt plot: one row of facets, all four models; use a year of data if available."""
    print(f"\n--- Testing Separation k vs kt Plot ---")

    # Prefer full year from DATA_DIR_YEAR; fallback to single file FILE_PATH
    df = None
    if os.path.exists(FILE_PATH):
        df = readers.read_station_to_archive(FILE_PATH)
    else:
        print(f"Skipping separation plot test: {FILE_PATH} not found.")
        return

    if df is None or "ghi" not in df.columns or "dhi" not in df.columns:
        print("Skipping: no GHI/DHI in data.")
        return

    try:
        station_code = "QIQ"
        meta = BSRN_STATIONS[station_code]
        lat, lon = meta["lat"], meta["lon"]
        df = add_solpos_columns(df, station_code=station_code)
        df = add_clearsky_columns(df, station_code=station_code)
        from bsrn.modeling import engerer2_separation, yang4_separation
        res_e2 = engerer2_separation(
            df.index, df["ghi"].values, lat, lon,
            ghi_clear=df["ghi_clear"].values
        )
        res_y4 = yang4_separation(
            df.index, df["ghi"].values, lat, lon,
            ghi_clear=df["ghi_clear"].values
        )
        df = df.copy()
        df["k_engerer2"] = res_e2["k"].reindex(df.index).values
        df["k_yang4"] = res_y4["k"].reindex(df.index).values

        plot_k_vs_kt(
            df, models=("erbs", "brl", "engerer2", "yang4"), lat=lat, lon=lon,
            k_mod_cols={"engerer2": "k_engerer2", "yang4": "k_yang4"},
            output_file="k_vs_kt_facet.pdf"
        )
        print(f"Successfully generated k_vs_kt_facet.pdf (n={len(df)} points)")
    except Exception as e:
        print(f"Separation k vs kt plot failed: {e}")
        import traceback
        traceback.print_exc()


def test_clearsky_models_booklet():
    """Test clear-sky model comparison booklet for December (Ineichen, McClear if email set, REST2)."""
    print("\n--- Testing Clear-Sky Models Booklet (December) ---")
    if not os.path.exists(FILE_PATH):
        pytest.skip(f"Clear-sky booklet test requires data file: {FILE_PATH}")
    mcclear_email = MCCLEAR_EMAIL or os.environ.get("MCCLEAR_EMAIL")  # McClear in plot when set
    # MERRA-2 parquet for qiq1224 (Dec 2024); use if available
    merra2_path = "data/bsrn_static_assets/qiq/qiq1224_merra2.parquet"
    if not os.path.exists(merra2_path):
        merra2_path = None
    output_file = "clearsky_models_december.pdf"
    print(f"Generating {output_file} ...")
    plot_clearsky_models_booklet(
        file_path=FILE_PATH,
        output_file=output_file,
        station_code="QIQ",
        mcclear_email=mcclear_email,
        merra2_path=merra2_path,
    )
    print(f"Successfully generated {output_file}")


def test_clearsky_calendar_ghi_august():
    """Test calendar-style GHI clear-sky vs measured plot for August."""
    print("\n--- Testing Clear-Sky Calendar (August, GHI) ---")
    if not os.path.exists(FILE_PATH_AUG):
        pytest.skip(f"Calendar plot test requires data file: {FILE_PATH_AUG}")

    output_file = "clearsky_calendar_ghi_august.pdf"
    print(f"Generating {output_file} ...")
    plot_clearsky_calendar(
        file_path=FILE_PATH_AUG,
        output_file=output_file,
        station_code="QIQ",
        component="ghi",
        clearsky_model="ineichen",
    )
    print(f"Successfully generated {output_file}")


def test_csd_booklet():
    """Test CSD booklet for full month (file data only; one page per day). Uses FILE_PATH_CSD_BOOKLET (e.g. December)."""
    print("\n--- Testing CSD Booklet (Full Month) ---")
    if not os.path.exists(FILE_PATH_CSD_BOOKLET):
        pytest.skip(f"CSD booklet test requires data file: {FILE_PATH_CSD_BOOKLET}")
    station_code = "QIQ"
    df = readers.read_station_to_archive(FILE_PATH_CSD_BOOKLET)
    if df is None:
        pytest.skip(f"Failed to read {FILE_PATH_CSD_BOOKLET}.")
    n_days = df.index.normalize().nunique()
    df = add_solpos_columns(df, station_code)
    df = add_clearsky_columns(df, station_code)
    output_file = "csd_booklet_test.pdf"
    print(f"Generating {output_file} ({n_days} days) ...")
    plot_csd_booklet(None, output_file, station_code, df=df)
    print(f"Successfully generated {output_file}")


def main():
    """Run when executing this file directly (python tests/test_visualization.py).
    When using pytest (e.g. pytest tests/test_visualization.py), pytest discovers
    all test_* functions and runs them; tests marked @pytest.mark.skip are skipped."""
    # test_availability()
    # test_timeseries()
    # test_qc_table()
    # test_separation_k_vs_kt()
    # test_csd_booklet()
    test_clearsky_models_booklet()


if __name__ == "__main__":
    main()
