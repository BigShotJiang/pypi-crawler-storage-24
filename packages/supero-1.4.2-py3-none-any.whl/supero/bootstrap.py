#!/usr/bin/env python3
"""
bootstrap.py — One-call idempotent platform setup for Supero SDK

Location: ~/supero/platform/infra/libs/py/src/supero/bootstrap.py

Replaces the generated smart_setup.py (~400 lines), tenant.py (~300 lines),
and most of __main__.py (~80 lines) with a single function call.

Usage:
    from supero import bootstrap

    result = bootstrap(
        domain_name    = "wedding-planner",
        admin_email    = "admin@wedding-planner.com",
        admin_password = "Admin123!",
        schemas        = ALL_SCHEMAS,          # list of flat schema dicts
        tenants        = [
            {"name": "default-tenant", "display_name": "Default Tenant"},
        ],
    )

    print(f"✓ {result.domain_name} ready")
    print(f"  api_key:  {result.api_key[:20]}...")
    print(f"  Schemas:  {result.schemas_uploaded} uploaded, {result.schemas_skipped} skipped")

The call is safe to run on every deploy — all steps are idempotent.
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, TYPE_CHECKING

if TYPE_CHECKING:
    from supero.core import Supero


# ---------------------------------------------------------------------------
# Result dataclass
# ---------------------------------------------------------------------------

@dataclass
class BootstrapResult:
    """
    Result of a bootstrap() call.

    All counts reflect what happened during THIS call:
      - created = newly created
      - skipped = already existed (idempotent skip)
      - failed  = error during creation (non-fatal unless fail_fast=True)
    """

    # Domain
    domain_name: str = ""
    domain_uuid: str = ""

    # Project
    project_name: str = "default-project"
    project_uuid: str = ""

    # Default tenant (always present after successful bootstrap)
    tenant_uuid: str = ""
    tenant_name: str = "default-tenant"

    # API key for service-account access (from registration or login response)
    api_key: str = ""

    # Schema upload summary
    schemas_uploaded: int = 0
    schemas_updated:  int = 0
    schemas_skipped:  int = 0
    schemas_failed:   int = 0

    # Tenant creation summary
    tenants_created: int = 0
    tenants_skipped: int = 0
    tenants_failed:  int = 0

    # User creation summary
    users_created: int = 0
    users_skipped: int = 0
    users_failed:  int = 0

    # Errors — non-fatal unless fail_fast=True
    errors: List[str] = field(default_factory=list)

    # Live Supero instance — ready to use immediately after bootstrap
    org: Optional[Any] = field(default=None, repr=False)

    @property
    def success(self) -> bool:
        """True if no fatal errors occurred."""
        return len(self.errors) == 0 or all(
            "skipped" in e.lower() for e in self.errors
        )

    def print_summary(self) -> None:
        """Print a human-readable summary to stdout."""
        ok = "✓" if self.success else "✗"
        print(f"{ok} Bootstrap: {self.domain_name}/{self.project_name}")
        print(f"  Schemas  : {self.schemas_uploaded} uploaded, "
              f"{self.schemas_updated} updated, "
              f"{self.schemas_skipped} skipped, "
              f"{self.schemas_failed} failed")
        print(f"  Tenants  : {self.tenants_created} created, "
              f"{self.tenants_skipped} skipped")
        print(f"  Users    : {self.users_created} created, "
              f"{self.users_skipped} skipped")
        if self.api_key:
            print(f"  API Key  : {self.api_key[:20]}...")
        if self.errors:
            print(f"  Errors   : {len(self.errors)}")
            for e in self.errors:
                print(f"    - {e}")


# ---------------------------------------------------------------------------
# Bootstrap implementation
# ---------------------------------------------------------------------------

def _bootstrap(
    domain_name:    str,
    admin_email:    str,
    admin_password: str,
    *,
    project_name:   str = "default-project",
    schemas:        List[Dict] = None,
    tenants:        List[Dict] = None,
    users:          List[Dict] = None,
    idempotent:     bool = True,
    fail_fast:      bool = False,
    platform_core_host: str = None,
    platform_core_port: int = None,
    logger: logging.Logger = None,
) -> BootstrapResult:
    """
    Core bootstrap implementation.

    Called by Supero.bootstrap() class method and the module-level bootstrap()
    convenience function. Not intended to be imported directly.
    """
    from supero.core import Supero

    log = logger or logging.getLogger("supero.bootstrap")
    result = BootstrapResult(
        domain_name=domain_name,
        project_name=project_name,
    )

    # ─── Connection kwargs ────────────────────────────────────────────
    conn_kwargs: Dict[str, Any] = {}
    if platform_core_host:
        conn_kwargs["platform_core_host"] = platform_core_host
    if platform_core_port:
        conn_kwargs["platform_core_port"] = platform_core_port

    # =========================================================================
    # STEP 1 — Register domain (idempotent)
    # =========================================================================
    log.info(f"[bootstrap] Step 1 — register domain '{domain_name}'")

    try:
        reg_resp = _http_post(
            host=platform_core_host,
            port=platform_core_port,
            path="/api/v1/auth/register",
            json={
                "email":       admin_email,
                "password":    admin_password,
                "domain_name": domain_name,
                "full_name":   "Domain Admin",
            },
        )

        status = reg_resp.get("_status_code", 0)

        if status == 201:
            # Freshly registered — extract permanent api_key from auth block
            result.api_key      = reg_resp.get("auth", {}).get("api_key", "")
            result.domain_uuid  = reg_resp.get("context", {}).get("domain_uuid", "")
            result.project_uuid = reg_resp.get("context", {}).get("project_uuid", "")
            result.tenant_uuid  = reg_resp.get("context", {}).get("tenant_uuid", "")
            result.tenant_name  = reg_resp.get("context", {}).get("tenant", "default-tenant")
            log.info(f"[bootstrap] Domain '{domain_name}' registered")

        elif status in (200, 409) or reg_resp.get("idempotent"):
            # Already exists — fall through to login
            log.info(f"[bootstrap] Domain '{domain_name}' already exists, logging in")

        else:
            error = reg_resp.get("error") or reg_resp.get("message") or str(reg_resp)
            if not idempotent or "already" not in error.lower():
                msg = f"Domain registration failed (HTTP {status}): {error}"
                result.errors.append(msg)
                if fail_fast:
                    return result
                log.warning(f"[bootstrap] {msg}")

    except Exception as exc:
        msg = f"Domain registration error: {exc}"
        result.errors.append(msg)
        if fail_fast:
            return result
        log.warning(f"[bootstrap] {msg} — attempting login anyway")

    # =========================================================================
    # STEP 2 — Login as domain admin (always against default-project)
    #
    # We always log in against 'default-project' here, even when the caller
    # wants a different app project. Reason: the app project may not exist yet
    # (it gets created in Step 3). Logging into a non-existent project causes
    # the platform to fall back to default-project anyway, but the resulting
    # JWT would carry the wrong project context for schema upload (Step 4).
    #
    # After Step 3 creates the app project, we call org.switch_project() to
    # re-issue the JWT with the correct project context before schema upload.
    # =========================================================================
    log.info(f"[bootstrap] Step 2 — login as '{admin_email}' (via default-project)")

    org: Optional[Supero] = None
    try:
        org = Supero.login(
            domain_name=domain_name,
            email=admin_email,
            password=admin_password,
            project="default-project",   # always: app project may not exist yet
            **conn_kwargs,
        )
        result.org = org

        # Capture context from login
        if not result.domain_uuid:
            result.domain_uuid = org._domain_uuid or ""
        if not result.project_uuid:
            result.project_uuid = org.project_uuid or ""
        if not result.tenant_uuid:
            result.tenant_uuid = org.tenant_uuid or ""
        if not result.tenant_name:
            result.tenant_name = org.tenant_name or "default-tenant"

        # api_key: for existing domains, extract from raw login response.
        # The permanent api_key (not the short-lived JWT) lives at
        # auth.api_key in the login response. Fetch it via a direct call
        # so we don't store org.jwt_token (which expires in 8h) as the key.
        if not result.api_key:
            login_resp = _http_post(
                host=platform_core_host,
                port=platform_core_port,
                path="/api/v1/auth/login",
                json={
                    "email":       admin_email,
                    "password":    admin_password,
                    "domain_name": domain_name,
                },
            )
            result.api_key = login_resp.get("auth", {}).get("api_key", "")
            if result.api_key:
                log.info("[bootstrap] Permanent api_key retrieved from login response")
            else:
                log.warning(
                    "[bootstrap] No permanent api_key in login response — "
                    "SUPERO_API_KEY will be empty. Use the key from initial registration."
                )

        log.info(f"[bootstrap] Logged in — "
                 f"domain_uuid={result.domain_uuid[:8] if result.domain_uuid else '?'}...")

    except Exception as exc:
        msg = f"Login failed: {exc}"
        result.errors.append(msg)
        log.error(f"[bootstrap] {msg}")
        return result   # Cannot continue without a session

    # =========================================================================
    # STEP 3 — Create project (if not default-project), then switch context
    # =========================================================================
    if project_name and project_name != "default-project":
        log.info(f"[bootstrap] Step 3 — create project '{project_name}'")
        try:
            proj_resp = org.post(
                f"/crud/{domain_name}/project",
                json={
                    "name":         project_name,
                    "display_name": project_name.replace("-", " ").title(),
                    "parent_type":  "domain",
                },
            )
            # FIX: CRUD create returns {"uuid":..., "fq_name":[...]} with no "success" key
            p_error = proj_resp.get("error", "") or proj_resp.get("message", "")
            p_uuid  = proj_resp.get("uuid") or proj_resp.get("data", {}).get("uuid", "")
            p_success = (
                proj_resp.get("success") is True or
                bool(p_uuid) or
                bool(proj_resp.get("fq_name"))
            ) and not p_error

            if p_success:
                result.project_uuid = p_uuid or result.project_uuid

                proj_api_key = proj_resp.get("api_key", {}).get("key", "")
                if proj_api_key and not result.api_key:
                    result.api_key = proj_api_key
                    log.info("[bootstrap] Permanent api_key captured from project creation")

                log.info(f"[bootstrap] Project '{project_name}' created: {result.project_uuid}")
            else:
                error = p_error
                already = (
                    "already exists" in error.lower() or
                    "duplicate"      in error.lower() or
                    "exist"          in error.lower()
                )
                if idempotent and already:
                    log.info(f"[bootstrap] Project '{project_name}' already exists")
                    try:
                        existing = org.post(
                            f"/crud/{domain_name}/fq-name-to-uuid",
                            json={"type": "project",
                                  "fq_name": [domain_name, project_name]},
                        )
                        result.project_uuid = existing.get("uuid", result.project_uuid)
                    except Exception:
                        pass
                else:
                    msg = f"Project creation failed: {error or str(proj_resp)[:120]}"
                    result.errors.append(msg)
                    if fail_fast:
                        return result
                    log.warning(f"[bootstrap] {msg}")

        except Exception as exc:
            msg = f"Project creation error: {exc}"
            result.errors.append(msg)
            if fail_fast:
                return result
            log.warning(f"[bootstrap] {msg}")

        # ─── Ensure project UUID is resolved (created or existing) ───
        if not result.project_uuid:
            log.info(f"[bootstrap] Project UUID not captured — resolving via fq_name...")
            try:
                existing = org.post(
                    f"/crud/{domain_name}/fq-name-to-uuid",
                    json={"type": "project",
                          "fq_name": [domain_name, project_name]},
                )
                result.project_uuid = existing.get("uuid", "")
                if result.project_uuid:
                    log.info(f"[bootstrap] Resolved project UUID: {result.project_uuid[:8]}...")
            except Exception as e:
                log.warning(f"[bootstrap] fq-name-to-uuid failed: {e}")

        if not result.project_uuid:
            msg = (
                f"Cannot determine UUID for project '{project_name}' — "
                f"tenants and users would be created under wrong project. Aborting."
            )
            result.errors.append(msg)
            log.error(f"[bootstrap] {msg}")
            return result

        # ─── Switch to app project (always — fatal if fails) ───
        try:
            org.switch_project(project_name=project_name)
            log.info(
                f"[bootstrap] Switched to project '{project_name}' "
                f"({result.project_uuid[:8]}...)"
            )
        except Exception as sw_exc:
            msg = (
                f"switch_project('{project_name}') failed: {sw_exc} — "
                f"tenants and users would be created under default-project "
                f"instead of {project_name}. Aborting."
            )
            result.errors.append(msg)
            log.error(f"[bootstrap] {msg}")
            return result
    else:
        log.info("[bootstrap] Step 3 — using default-project (skip create)")

    # =========================================================================
    # STEP 4 — Upload schemas
    # =========================================================================
    if schemas:
        log.info(f"[bootstrap] Step 4 — upload {len(schemas)} schemas")
        try:
            upload_resp = org.post(
                "/schemas/upload",
                json={
                    "domain_name":  domain_name,
                    "schemas":      schemas,
                    "skip_existing": True,
                },
            )
            summary = upload_resp.get("summary", {})
            result.schemas_uploaded = summary.get("uploaded", 0)
            result.schemas_updated  = summary.get("updated", 0)
            result.schemas_skipped  = summary.get("skipped", 0)
            result.schemas_failed   = summary.get("failed", 0)

            log.info(
                f"[bootstrap] Schemas: {result.schemas_uploaded} uploaded, "
                f"{result.schemas_updated} updated, "
                f"{result.schemas_skipped} skipped, "
                f"{result.schemas_failed} failed"
            )

            if result.schemas_failed > 0:
                failed_names = [
                    f.get("name", "?") for f in upload_resp.get("failed", [])
                ]
                msg = f"Schema upload partial failure: {failed_names}"
                result.errors.append(msg)
                if fail_fast:
                    return result
                log.warning(f"[bootstrap] {msg}")

        except Exception as exc:
            msg = f"Schema upload error: {exc}"
            result.errors.append(msg)
            if fail_fast:
                return result
            log.error(f"[bootstrap] {msg}")
    else:
        log.info("[bootstrap] Step 4 — no schemas provided, skipping")

    # =========================================================================
    # STEP 5 — Create tenants
    # =========================================================================
    if tenants:
        log.info(f"[bootstrap] Step 5 — create {len(tenants)} tenant(s)")
        for tenant_def in tenants:
            tenant_name = tenant_def.get("name", "default-tenant")
            display     = tenant_def.get("display_name", tenant_name)
            try:
                t_resp = org.post(
                    f"/crud/{domain_name}/tenant",
                    json={
                        "name":         tenant_name,
                        "display_name": display,
                        "parent_type":  "project",
                    },
                )
                # FIX: CRUD create returns {"uuid":..., "fq_name":[...]}
                # with NO "success" key. Accept uuid OR fq_name as success.
                t_error = t_resp.get("error", "") or t_resp.get("message", "")
                t_uuid = (
                    t_resp.get("uuid") or
                    t_resp.get("data", {}).get("uuid", "")
                )
                t_success = (
                    t_resp.get("success") is True or
                    bool(t_uuid) or
                    bool(t_resp.get("fq_name"))
                ) and not t_error

                if t_success:
                    result.tenants_created += 1
                    if t_uuid:
                        result.tenant_uuid = t_uuid
                        result.tenant_name = tenant_name
                    log.info(f"[bootstrap] Tenant '{tenant_name}' created: {t_uuid[:8] if t_uuid else '?'}...")
                else:
                    error = t_error
                    # Tighter check: "does not exist" must NOT match as already-exists
                    already = (
                        "already exists" in error.lower() or
                        "duplicate"      in error.lower() or
                        "409"            in str(t_resp.get("status", ""))
                    )
                    if idempotent and already:
                        result.tenants_skipped += 1
                        log.info(f"[bootstrap] Tenant '{tenant_name}' already exists")
                    else:
                        result.tenants_failed += 1
                        msg = f"Tenant '{tenant_name}' creation failed: {error or str(t_resp)[:120]}"
                        result.errors.append(msg)
                        if fail_fast:
                            return result
                        log.warning(f"[bootstrap] {msg}")
            except Exception as exc:
                result.tenants_failed += 1
                msg = f"Tenant '{tenant_name}' error: {exc}"
                result.errors.append(msg)
                if fail_fast:
                    return result
                log.warning(f"[bootstrap] {msg}")
    else:
        log.info("[bootstrap] Step 5 — no tenants provided, skipping")

    # =========================================================================
    # STEP 6 — Create users
    # =========================================================================
    if users:
        log.info(f"[bootstrap] Step 6 — create {len(users)} user(s)")
        tenant_uuid_map: Dict[str, str] = {}
        if result.tenant_uuid and result.tenant_name:
            tenant_uuid_map[result.tenant_name] = result.tenant_uuid

        for user_def in users:
            email       = user_def.get("email") or user_def.get("name", "")
            password    = user_def.get("password", "")
            role        = user_def.get("role", "tenant_user")
            full_name   = user_def.get("full_name", "")
            first_name  = user_def.get("first_name", full_name.split()[0] if full_name else "")
            last_name   = user_def.get("last_name",  full_name.split()[-1] if full_name and " " in full_name else "")
            tenant_name = user_def.get("tenant", result.tenant_name or "default-tenant")
            tenant_uuid_to_use = tenant_uuid_map.get(tenant_name, result.tenant_uuid)

            if not email or not password:
                result.errors.append(f"User missing email or password: {user_def}")
                continue

            try:
                u_resp = org.post("/users/register", json={
                    "domain_name":  domain_name,
                    "domain_uuid":  result.domain_uuid,    # ← explicit
                    "project_uuid": result.project_uuid,   # ← explicit (app-project, not default)
                    "tenant_uuid":  tenant_uuid_to_use,    # ← explicit (from Fix #1 result)
                    "project_name": project_name,        # ← add this
                    "tenant_name":  tenant_name,          # ← add this
                    "email":        email,
                    "password":     password,
                    "first_name":   first_name,
                    "last_name":    last_name,
                    "role":         role,
                    "permissions":  [],
                })
                # /users/register returns {'message': 'User registered successfully', ...}
                # NOT {'success': True} — check message key, not success key
                error_msg    = u_resp.get("error", "")
                resp_message = u_resp.get("message", "")
                created      = not error_msg and (
                    "registered" in resp_message or
                    "success"    in resp_message.lower()
                )
                already_exists = (
                    "exist"     in error_msg.lower() or
                    "duplicate" in error_msg.lower() or
                    "already"   in error_msg.lower()
                )
                if created:
                    result.users_created += 1
                    log.info(f"[bootstrap] User '{email}' created (role={role})")
                elif already_exists and idempotent:
                    result.users_skipped += 1
                    log.info(f"[bootstrap] User '{email}' already exists — skipped")
                else:
                    result.users_failed += 1
                    msg = f"User '{email}' creation failed: {error_msg or str(u_resp)[:120]}"
                    result.errors.append(msg)
                    if fail_fast:
                        return result
                    log.warning(f"[bootstrap] {msg}")
            except Exception as exc:
                exc_str = str(exc)
                if idempotent and ("409" in exc_str or "already exists" in exc_str.lower()):
                    result.users_skipped += 1          # was tenants_skipped
                    log.info(f"[bootstrap] User '{email}' already exists")   # was tenant_name
                else:
                    result.users_failed += 1           # was tenants_failed
                    msg = f"User '{email}' error: {exc}"  # was tenant_name
                    result.errors.append(msg)
                    if fail_fast:
                        return result
                    log.warning(f"[bootstrap] {msg}")
    else:
        log.info("[bootstrap] Step 6 — no users provided, skipping")

    # =========================================================================
    # Done
    # =========================================================================
    log.info(
        f"[bootstrap] Complete — "
        f"domain={domain_name}, "
        f"schemas={result.schemas_uploaded}+{result.schemas_skipped}sk, "
        f"tenants={result.tenants_created}+{result.tenants_skipped}sk, "
        f"users={result.users_created}+{result.users_skipped}sk, "
        f"errors={len(result.errors)}"
    )
    return result


# ---------------------------------------------------------------------------
# HTTP helper (thin wrapper — avoids circular imports with core.py)
# ---------------------------------------------------------------------------

def _http_post(
    host: Optional[str],
    port: Optional[int],
    path: str,
    json: Dict,
) -> Dict:
    """
    Make a raw HTTP POST before a Supero session exists (Step 1 only).

    Uses requests directly since we have no org instance yet.
    Attaches _status_code to the response dict for caller inspection.
    """
    import requests as _requests

    _host = host or os.getenv("PLATFORM_CORE_HOST", "localhost")
    _port = port or int(os.getenv("PLATFORM_CORE_PORT", "8083"))
    protocol = "https" if _port == 443 else "http"
    url = f"{protocol}://{_host}:{_port}{path}"

    try:
        resp = _requests.post(url, json=json, timeout=30)
        data = resp.json() if resp.content else {}
        data["_status_code"] = resp.status_code
        return data
    except Exception as exc:
        return {"error": str(exc), "_status_code": 0}


# ---------------------------------------------------------------------------
# Module-level convenience function (mirrors Supero.bootstrap class method)
# ---------------------------------------------------------------------------

def bootstrap(
    domain_name:    str,
    admin_email:    str,
    admin_password: str,
    *,
    project_name:   str = "default-project",
    schemas:        List[Dict] = None,
    tenants:        List[Dict] = None,
    users:          List[Dict] = None,
    idempotent:     bool = True,
    fail_fast:      bool = False,
    platform_core_host: str = None,
    platform_core_port: int = None,
    logger: logging.Logger = None,
) -> BootstrapResult:
    """
    One-call idempotent platform bootstrap.

    Registers the domain (or logs in if it already exists), creates the
    project, uploads schemas, and creates tenants and users — all in one
    call that is safe to run on every deploy.

    Args:
        domain_name:    Domain to create/connect to (e.g. "wedding-planner")
        admin_email:    Admin user email
        admin_password: Admin user password (plaintext — platform hashes it)
        project_name:   App project name (default: "default-project")
        schemas:        List of flat schema dicts to upload
        tenants:        List of tenant dicts: [{"name": "acme", "display_name": "Acme"}]
        users:          List of user dicts: [{"email": ..., "password": ..., "role": ...}]
        idempotent:     Skip already-existing resources (default: True)
        fail_fast:      Raise on first error instead of collecting and continuing
        platform_core_host: Override platform host (default: PLATFORM_CORE_HOST env)
        platform_core_port: Override platform port (default: PLATFORM_CORE_PORT env)
        logger:         Custom logger (default: supero.bootstrap logger)

    Returns:
        BootstrapResult with counts, UUIDs, api_key, and live org instance

    Example::

        from supero import bootstrap
        from schemas import ALL_SCHEMAS

        result = bootstrap(
            domain_name    = "wedding-planner",
            admin_email    = "admin@wedding-planner.com",
            admin_password = "Admin123!",
            schemas        = ALL_SCHEMAS,
            tenants        = [{"name": "default-tenant"}],
        )
        result.print_summary()
        org = result.org   # ready-to-use Supero instance
    """
    return _bootstrap(
        domain_name=domain_name,
        admin_email=admin_email,
        admin_password=admin_password,
        project_name=project_name,
        schemas=schemas,
        tenants=tenants,
        users=users,
        idempotent=idempotent,
        fail_fast=fail_fast,
        platform_core_host=platform_core_host,
        platform_core_port=platform_core_port,
        logger=logger,
    )
