"""
supero.cli — Interactive app runner for Supero-generated apps.

Entry points:
  - python3 -m supero.cli        (from run.sh — preferred)
  - supero                        (pyproject console_scripts entry point)

The pyproject.toml entry point 'supero = "supero.cli:main"' calls
this package's main() function, which delegates to run.main().
"""


def main():
    """Entry point for pyproject console_scripts and python3 -m supero.cli."""
    from supero.cli.run import main as _main
    _main()


__all__ = ["main"]
