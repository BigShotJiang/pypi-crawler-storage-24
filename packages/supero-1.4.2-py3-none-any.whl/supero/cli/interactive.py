"""
supero.cli.interactive — Interactive prompts for domain setup.

Uses simple input() + getpass — no external dependencies.

This module ONLY collects credentials and writes .env.
All platform interaction (register, login, schema upload) is handled
by setup.py via the existing supero SDK's AppSetup.run().
"""

import getpass
from supero.cli.env_manager import EnvManager


def interactive_setup(env: EnvManager) -> EnvManager:
    """
    Guide user through .env configuration via terminal prompts.

    Collects domain name, API URL, credentials, and project name.
    Saves everything to .env so subsequent runs skip prompts.

    Returns the updated EnvManager instance.
    """

    has_domain = _prompt_yes_no(
        "Do you have a registered Supero domain?", default=False
    )

    if has_domain:
        # ── Existing domain — collect login credentials ──
        domain = _prompt("Domain name", default=env.get("SUPERO_DOMAIN"))
        api_url = _prompt(
            "API server URL",
            default=env.get("SUPERO_URL", "https://api.supero.dev")
        )
        email = _prompt("Admin email", default=env.get("SUPERO_ADMIN_EMAIL"))
        password = _prompt_password("Admin password")
        project = _prompt(
            "Project name",
            default=env.get("SUPERO_PROJECT", "default-project")
        )
    else:
        # ── New domain — collect registration info ──
        domain = _prompt("Choose a domain name")
        api_url = _prompt(
            "API server URL",
            default=env.get("SUPERO_URL", "https://api.supero.dev")
        )
        default_email = f"admin@{domain}.com"
        email = _prompt("Admin email", default=default_email)

        # Password with confirmation (loop, not recursion)
        for _attempt in range(5):
            password = _prompt_password("Choose a password")
            confirm = _prompt_password("Confirm password")
            if password == confirm:
                break
            print("  ❌ Passwords don't match. Please try again.\n")
        else:
            print("  ❌ Too many failed attempts. Using default password.")
            password = "Password123!"

        project = _prompt(
            "Project name",
            default="default-project"
        )

    # Port
    port = _prompt(
        "Server port",
        default=env.get("PORT", env.get("UI_PORT", "5648"))
    )

    # ── Save to .env ──
    env.set("SUPERO_URL", api_url)
    env.set("SUPERO_DOMAIN", domain)
    env.set("SUPERO_ADMIN_EMAIL", email)
    env.set("SUPERO_PASSWORD", password)
    env.set("SUPERO_PROJECT", project)
    env.set("PORT", port)
    env.set("UI_PORT", port)
    env.set("SUPERO_DEFAULT_TENANT", "default-tenant")
    env.save()

    print()
    print(f"  ✓ Configuration saved to .env")
    print(f"    Domain:  {domain}")
    print(f"    Project: {project}")
    print(f"    Email:   {email}")
    print(f"    API:     {api_url}")

    return env


# ── Prompt Helpers ──────────────────────────────────────

def _prompt(label: str, default: str = "") -> str:
    """Prompt for a value with an optional default."""
    if default:
        result = input(f"  {label} [{default}]: ").strip()
        return result or default
    while True:
        result = input(f"  {label}: ").strip()
        if result:
            return result
        print(f"    ↳ {label} is required")


def _prompt_password(label: str) -> str:
    """Prompt for a password (hidden input) with default fallback."""
    while True:
        try:
            result = getpass.getpass(f"  {label} [Password123!]: ")
            return result.strip() or "Password123!"
        except (EOFError, KeyboardInterrupt):
            print()
            return "Password123!"


def _prompt_yes_no(question: str, default: bool = True) -> bool:
    """Prompt for a yes/no answer."""
    suffix = "[Y/n]" if default else "[y/N]"
    try:
        result = input(f"  {question} {suffix}: ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        print()
        return default
    if not result:
        return default
    return result in ("y", "yes")
