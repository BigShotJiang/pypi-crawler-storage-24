"""
pymodel_system - Auto-generated Python models from JSON schemas.

This package provides 100% backward compatibility for:
- from pymodel.objects import *
- from pymodel.types import *
- from pymodel.enums import *

All class names are directly available after import without
needing to specify the module name.

Supports class inheritance via "extends" property.
Derived classes automatically include base class attributes.

Generated classes:
- Objects: 61 classes
  - AccessPolicy
  - AccessRule
  - ApiKey
  - AppGeneration
  - AuditLog
  - ... and 56 more
- Types: 59 classes
  - Address
  - Address
  - AddressType
  - ApiKeySecretType
  - AppArtifact
  - ... and 54 more
- Enums: 10 classes
  - BillingPlanTypes
  - BillingPlanTypes
  - InvocationStatus
  - InvocationStatus
  - PluginAuthType
  - ... and 5 more

Total: 130 classes generated
"""

# Package metadata
__version__ = "1.0.0"
__author__ = "Schema Code Generator"

# Optional: Import submodules for convenience
# from . import objects, types, enums

# For users who want to import everything at once (not recommended for large schemas):
# from .objects import *
# from .types import *
# from .enums import *
