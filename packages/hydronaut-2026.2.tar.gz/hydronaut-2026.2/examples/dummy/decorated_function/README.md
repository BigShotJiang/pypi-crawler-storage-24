---
title: Dummy Decorated Function Example README
---

# Synopsis

A decorated function is the simplest entry point for using the framework. The
user need only define a decorated function that accepts the configuration object
and the code can be run directly as a script without invocation through
`hydronaut-run`.

[The example](decorated_function.py) does the same thing as [dummy Experiment
subclass example](../experiment_subclass) except that there is no `setup`
step.

# Usage

~~~sh
python3 ./decorated_function.py
~~~
