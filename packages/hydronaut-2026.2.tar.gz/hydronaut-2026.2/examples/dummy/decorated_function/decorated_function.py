#!/usr/bin/env python3
"""
Dummy function with a decorator.
"""

import sys

from hydronaut.decorator import with_hydronaut


@with_hydronaut(config_path="conf/config.yaml")
def main(config):
    """
    Main function that accepts the configuration object passed by the decorator.
    It is based on the dummy Experiment subclass example.
    """
    # Get the experiment parameters from the config object.
    params = config.experiment.params

    # Return a numerical objective value based on the parameters. In a real
    # experiment, this would be a validation or test score after training and
    # fitting a model. Use the get method to retrieve the value of
    # "extra_parameter" with a default as it will not exist unless sweeping is
    # enabled.
    return (
        params.fixed_param * params.overridden_param * params.get("extra_parameter", 1)
    )


if __name__ == "__main__":
    sys.exit(main())  # pylint: disable=no-value-for-parameter
