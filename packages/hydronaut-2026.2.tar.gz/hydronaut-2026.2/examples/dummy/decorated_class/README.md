---
title: Dummy Decorated Class Example README
---

# Synopsis

A decorated user class is essentially just a simpler version of an `hydronaut.experiment.Experment` subclass:

* The class does not need to subclass the `Experiment` subclass.
* A `__call__` method must still be defined, which accepts no arguments and which returns one or more objective values.
* A `setup` method may be defines and will be invoked before `__call__` if it is.
* An `__init__` method must be defined and it must accept the configuration object as its only positional argument.
* To run the experiment, the class should be invoked directly via a script, usually as the main function. `hydronaut-run` is not required to run it, and `experiment.exp_class` is not required in the configuration file.

[The provided dummy example](decorated_class.py) does the same thing as the [dummy Experiment subclass example](../experiment_subclass). 


# Usage

~~~sh
python3 ./decorated_class.py
~~~
