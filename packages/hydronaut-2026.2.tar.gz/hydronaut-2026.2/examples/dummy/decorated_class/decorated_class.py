#!/usr/bin/env python3
"""
Dummy class with a decorator.
"""

import logging
import sys

from hydronaut.decorator import with_hydronaut

LOGGER = logging.getLogger(__name__)


@with_hydronaut(config_path="conf/config.yaml")
class DecoratedUserClass:
    """
    An example class to show the use of the Hydronaut decorator on custom user
    classes. The class does not need to be derived from
    hydronaut.experiment.Experiment but it must define an __init__ method that
    accepts the configuration object and a call method that accepts no arguments
    and which returns at least one numerical objective value.
    """

    def __init__(self, config):
        """
        Args:
            config:
                The configuration object which will be passed from the decorator
                at runtime.
        """
        self.config = config

    def setup(self):
        """
        An optional setup method will be called before __call__ at runtime. It can be
        used to prepare data for the experiment or perform other actions that
        need only be done once.
        """
        LOGGER.info("called setup()")

    def __call__(self):
        """
        The __call__ method definition is required. It should access the
        configuration object via the "config" attribute and then run the
        experiment based on the parameters therein. It should return one or more
        numeric objective values.
        """
        # Get the experiment parameters from the Hydra configuration object.
        params = self.config.experiment.params

        # Return a numerical objective value based on the parameters. In a real
        # experiment, this would be a validation or test score after training
        # and fitting a model. Use the get method to retrieve the value of
        # "extra_parameter" with a default as it will not exist unless sweeping
        # is enabled.
        return (
            params.fixed_param
            * params.overridden_param
            * params.get("extra_parameter", 1)
        )


if __name__ == "__main__":
    sys.exit(DecoratedUserClass())  # pylint: disable=no-value-for-parameter
