---
title: Dummy Experiment Subclass Example README
---

# Synopsis

This example shows how to define a [minimal subclass of the Experiment class](src/experiment.py) with `setup` and `__call__` methods. The `setup` method simply logs that it was called but in a real experiment it could be used for data retrieval and pre-processing. The `__call_` method accepts no arguments but accesses the configuration object via the parent class's `config` attribute, which will contain the parameters and other data in the [configuration file](conf/config.yaml).

The configured values are used to calculate a simple objective value that the `__call__` method returns. When an optimizer such as Optuna is enabled, the parameters will be optmized to minimize or maximize this value.

# Usage

The class must be specified via the `experiment.exp_class` field in the configuration file and the code must be invoked with `hydronaut-run`.

~~~sh
hydronaut-run --multirun
~~~

# Alternatives

Hydronaut also provides decorators for classes and functions that enable them to be invoked directly, without `hydronaut-run` and without specifying an experiment class in the configuration file. Please see the following examples for details:

* [decorated class](../decorated_class)
* [decorated function](../decorated_function)
