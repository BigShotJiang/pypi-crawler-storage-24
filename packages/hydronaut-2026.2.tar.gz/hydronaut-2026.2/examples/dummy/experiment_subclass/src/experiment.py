#!/usr/bin/env python3
"""
Dummy experiment.
"""

import logging

from hydronaut.experiment import Experiment

LOGGER = logging.getLogger(__name__)


class MyExperiment(Experiment):
    """
    Experiment subclass example. This class must be added to the Hydronaut
    configuration file as the value of experiment.exp_class field. The code can
    then be run with the hydronaut-run command.
    """

    # An __init__ method is not necessary as it is inherited from the parent
    # Experiment class. If defined, it must accept the configuration object as
    # its first positional argument and invoke the parent class's __init__
    # method with it. This is usually unnecessary as any experimental
    # initialization can usually be done in the setup() method below.
    #  def __init__(self, config):
    #      super().__init__(config)
    #      # ...

    def setup(self):
        """
        The setup method will be called before __call__ at runtime. It can be
        used to prepare data for the experiment or perform other actions that
        need only be done once before the experiment starts. Its definition is
        optional.
        """
        LOGGER.info("called setup()")

    def __call__(self):
        """
        This is the only method that the subclass is required to define. It
        should access the configuration object via the "config" attribute and
        then run the experiment based on the parameters therein. It should
        return one or more numeric objective values.
        """
        # The Hydra configuration object is accessible via the parent class's
        # "config" attribute. The experiment parameters can be retrieved from
        # it.
        params = self.config.experiment.params

        # Return a numerical objective value based on the parameters. In a real
        # experiment, this would be a validation or test score after training
        # and fitting a model. Use the get method to retrieve the value of
        # "extra_parameter" with a default as it will not exist unless sweeping
        # is enabled.
        return (
            params.fixed_param
            * params.overridden_param
            * params.get("extra_parameter", 1)
        )
