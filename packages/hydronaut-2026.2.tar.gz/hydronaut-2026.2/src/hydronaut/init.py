#!/usr/bin/env python3

# Single line for CodeMeta description.
"""Initialize a directory with default files for Hydronaut."""

import argparse
import logging
import pathlib
import re
import shutil
import stat
import sys

from hydronaut.file import backup_copy, safe_open
from hydronaut.log import configure_logging
from hydronaut.paths import PathManager

LOGGER = logging.getLogger()


DATA_DIR = pathlib.Path(__file__).resolve().parent / "data"


class Initializer:
    """
    Initialize a directory with default files.
    """

    def __init__(self) -> None:
        self.path_manager = PathManager()
        self.config_path = self.path_manager.get_config_path()
        self.pargs = None

    def parse_args(self, args: list[str] = None) -> None:
        """
        Parse the command-line arguments with argparse.

        Args:
            args:
                The list of arguments to parse. If None, the arguments are taken
                from the current system invocation.

        Returns:
            The parsed arguments.
        """
        parser = argparse.ArgumentParser(
            description="Generate default files for a Hydronaut project."
        )
        parser.add_argument(
            "-s", "--sweeper", choices=("optuna",), help="Use the given Hydra sweeper."
        )
        parser.add_argument(
            "-l",
            "--launcher",
            choices=("joblib",),
            help="Use the given Hydra launcher.",
        )
        parser.add_argument(
            "--multirun",
            action="store_true",
            help="Set the default Hydra run mode to MULTIRUN.",
        )

        entry_points = {
            "dfunc": "A decorated user function that can be run directly",
            "dclass": "A decorated user class that can be run directly",
            "class": "A hydronaut.experiment.Experiment subclass run with hydronaut-run",
        }
        ep_details = "; ".join(f"{k}: {v}" for (k, v) in entry_points.items())
        parser.add_argument(
            "-e",
            "--entry-point",
            choices=entry_points,
            default=list(entry_points)[0],
            help=f"The entry point for running the experiment: {ep_details}. Default: %(default)s",
        )

        self.pargs = parser.parse_args(args)

    def run(self, args: list[str] = None) -> None:
        """
        Process command-line arguments and generate the requested files.

        Args:
            args:
                Passed through to parse_args().
        """
        self.parse_args(args=args)
        self.create_config()
        self.create_entry_point()

    @property
    def config_template(self):
        """
        The configuration file template.
        """
        return (DATA_DIR / "config_template.yaml").read_text(encoding="utf-8")

    @staticmethod
    def configure_sections(config, section, include=False):
        """
        Configure named sections by removing the delimiters and optionally
        everything inbetween.

        Args:
            config:
                The configuration file template as a string.

            section:
                The section name, e.g. "OPTUNA".

            include:
                If True, keep the section, else remove it.
        """
        regex = re.compile(f"#%{section}/%\n(.*?)\n#%/{section}%\n\n", flags=re.DOTALL)
        if include:
            return regex.sub("\\1\n\n", config)
        return regex.sub("", config)

    def create_config(self) -> None:
        """
        Create the configuration file.
        """
        pargs = self.pargs
        config_path = self.config_path
        config = self.config_template
        config = self.configure_sections(
            config, "OPTUNA", include=pargs.sweeper == "optuna"
        )
        config = self.configure_sections(
            config, "JOBLIB", include=pargs.launcher == "joblib"
        )
        config = self.configure_sections(
            config, "EXPERIMENT_SUBCLASS", include=pargs.entry_point == "class"
        )
        if pargs.multirun:
            config = config.replace("# mode: MULTIRUN", "mode: MULTIRUN")
        LOGGER.info("Creating %s", config_path)
        with safe_open(config_path, "w", backup=True) as handle:
            handle.write(config)

    def create_entry_point(self) -> None:
        """
        Create a placeholder entry point.
        """
        pargs = self.pargs

        dst_path = None
        executable = False
        if pargs.entry_point == "class":
            src_path = DATA_DIR / "undecorated_class.py"
            dst_path = self.path_manager.get_src_path("experiment.py")

        elif pargs.entry_point == "dfunc":
            src_path = DATA_DIR / "decorated_function.py"

        elif pargs.entry_point == "dclass":
            src_path = DATA_DIR / "decorated_class.py"

        else:
            raise ValueError(f"Unrecognized entry point: {pargs.entry_point}")

        if dst_path is None:
            dst_path = pathlib.Path(src_path.name)
            executable = True

        LOGGER.info("Creating %s", dst_path)
        dst_path.parent.mkdir(parents=True, exist_ok=True)
        backup_copy(dst_path)
        shutil.copy(src_path, dst_path)
        if executable:
            dst_path.chmod(dst_path.stat().st_mode | stat.S_IXUSR)


def main(args: list[str] = None) -> None:
    """
    Initialize a directory with default files.
    """
    configure_logging()
    initializer = Initializer()
    try:
        initializer.run(args=args)
    except OSError as err:
        sys.exit(err)


if __name__ == "__main__":
    main()
