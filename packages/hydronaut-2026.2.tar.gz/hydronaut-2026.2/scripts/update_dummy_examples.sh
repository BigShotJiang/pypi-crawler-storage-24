#!/usr/bin/env bash
set -euo pipefail

SELF=$(realpath -L -s "${BASH_SOURCE[0]}")
DIR=${SELF%/*/*}

function update()
{
  pushd "$1"
  rm -vfr ./conf ./src *.py
  "$DIR/scripts/run_in_venv.sh" -v "$DIR/venv" hydronaut-init -s optuna --multirun -e "$2"
  popd
}

cd -- "$DIR/examples/dummy"
update experiment_subclass class
update decorated_class dclass
update decorated_function dfunc
