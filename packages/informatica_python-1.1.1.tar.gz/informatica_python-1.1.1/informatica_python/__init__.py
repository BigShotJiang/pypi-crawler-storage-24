from informatica_python.converter import InformaticaConverter

__version__ = "1.0.0"
__all__ = ["InformaticaConverter"]
