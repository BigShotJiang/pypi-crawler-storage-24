import re


INFA_FUNC_MAP = {
    "IIF": "iif_expr",
    "DECODE": "decode_expr",
    "LTRIM": "ltrim",
    "RTRIM": "rtrim",
    "UPPER": "upper",
    "LOWER": "lower",
    "SUBSTR": "substr",
    "LPAD": "lpad",
    "RPAD": "rpad",
    "TO_CHAR": "to_char",
    "TO_DATE": "to_date",
    "TO_INTEGER": "to_integer",
    "TO_BIGINT": "to_bigint",
    "TO_FLOAT": "to_float",
    "TO_DECIMAL": "to_decimal",
    "SYSDATE": "current_timestamp",
    "SYSTIMESTAMP": "current_timestamp",
    "SESSSTARTTIME": "session_start_time",
    "GET_DATE_PART": "get_date_part",
    "ADD_TO_DATE": "add_to_date",
    "TRUNC": "trunc",
    "ROUND": "round",
    "ABS": "abs",
    "CEIL": "ceil",
    "FLOOR": "floor",
    "MOD": "mod",
    "POWER": "power",
    "SQRT": "sqrt",
    "LENGTH": "length",
    "CONCAT": "concat",
    "INSTR": "instr",
    "REPLACECHR": "replacechr",
    "REPLACESTR": "replacestr",
    "REG_EXTRACT": "reg_extract",
    "REG_MATCH": "reg_match",
    "REG_REPLACE": "reg_replace",
    "IS_DATE": "is_date",
    "IS_NUMBER": "is_number",
    "IS_SPACES": "is_spaces",
    "NVL": "nvl",
    "NVL2": "nvl2",
    "ISNULL": "isnull",
    "ERROR": "raise_error",
    "ABORT": "abort_func",
    "LOOKUP": "lookup_func",
    "MAX": "max_val",
    "MIN": "min_val",
    "SUM": "sum_val",
    "COUNT": "count_val",
    "AVG": "avg_val",
    "FIRST": "first_val",
    "LAST": "last_val",
    "MOVINGAVG": "moving_avg",
    "MOVINGSUM": "moving_sum",
    "CUME": "cume",
    "SETCOUNTVARIABLE": "set_count_variable",
    "SETVARIABLE": "set_variable",
}


def convert_expression(expr):
    if not expr or not expr.strip():
        return "None"

    cleaned = expr.strip()

    if re.match(r'^[A-Za-z_][A-Za-z0-9_]*$', cleaned):
        return f'row["{cleaned}"]'

    if re.match(r'^-?\d+(\.\d+)?$', cleaned):
        return cleaned

    if cleaned.startswith("'") and cleaned.endswith("'"):
        return cleaned

    converted = cleaned

    for infa_func, py_func in INFA_FUNC_MAP.items():
        pattern = re.compile(r'\b' + re.escape(infa_func) + r'\s*\(', re.IGNORECASE)
        converted = pattern.sub(f'{py_func}(', converted)

    converted = converted.replace("||", " + ")

    converted = re.sub(r':LKP\.(\w+)\(', r'lookup_func("\1", ', converted)

    converted = re.sub(r'\$\$(\w+)', r'get_variable("\1")', converted)

    converted = re.sub(r':(\w+)', r'row["\1"]', converted)

    return converted


def convert_sql_expression(sql_expr):
    if not sql_expr or not sql_expr.strip():
        return ""

    converted = sql_expr.strip()
    converted = converted.replace("&#xD;&#xA;", "\n")
    converted = converted.replace("&#xD;", "\r")
    converted = converted.replace("&#xA;", "\n")
    converted = converted.replace("&#x9;", "\t")
    converted = converted.replace("&apos;", "'")
    converted = converted.replace("&quot;", '"')
    converted = converted.replace("&amp;", "&")
    converted = converted.replace("&lt;", "<")
    converted = converted.replace("&gt;", ">")

    return converted


def detect_sql_dialect(sql_text):
    if not sql_text:
        return "generic"

    sql_upper = sql_text.upper()

    if "GETDATE()" in sql_upper or "ISNULL(" in sql_upper or "TOP " in sql_upper:
        return "mssql"
    if "NVL(" in sql_upper or "SYSDATE" in sql_upper or "ROWNUM" in sql_upper:
        return "oracle"
    if "NOW()" in sql_upper or "COALESCE(" in sql_upper:
        return "postgresql"

    return "generic"
