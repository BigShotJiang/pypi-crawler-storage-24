import os
import sys
import json
import zipfile
import tempfile

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from informatica_python.converter import InformaticaConverter
from informatica_python.parser import InformaticaParser


TEST_XML_DIR = os.path.join(os.path.dirname(__file__), "..", "..", "attached_assets")


def test_parse_contact_mechanism():
    xml_file = os.path.join(TEST_XML_DIR, "wf_landing_party_contact_mechanism_delta_1773695180247.xml")
    if not os.path.exists(xml_file):
        print(f"SKIP: {xml_file} not found")
        return

    converter = InformaticaConverter()
    result = converter.parse_file(xml_file)

    assert result, "Parsed result should not be empty"
    assert "repositories" in result
    assert len(result["repositories"]) > 0

    repo = result["repositories"][0]
    assert repo["name"] == "pc105_repo_dev2_3"

    folder = repo["folders"][0]
    assert folder["name"] == "CDM_DEV3_DELTA"
    assert len(folder["sources"]) > 0
    assert len(folder["targets"]) > 0
    assert len(folder["mappings"]) > 0

    print(f"PASS: test_parse_contact_mechanism")
    print(f"  Sources: {len(folder['sources'])}")
    print(f"  Targets: {len(folder['targets'])}")
    print(f"  Mappings: {len(folder['mappings'])}")
    for m in folder["mappings"]:
        print(f"    - {m['name']}: {len(m['transformations'])} transformations, {len(m['connectors'])} connectors")


def test_parse_party_delta():
    xml_file = os.path.join(TEST_XML_DIR, "wf_landing_party_delta_1773695180248.xml")
    if not os.path.exists(xml_file):
        print(f"SKIP: {xml_file} not found")
        return

    converter = InformaticaConverter()
    result = converter.parse_file(xml_file)

    assert result
    folder = result["repositories"][0]["folders"][0]
    assert len(folder["sources"]) > 0
    assert len(folder["mappings"]) > 0
    print(f"PASS: test_parse_party_delta")
    print(f"  Sources: {len(folder['sources'])}")
    print(f"  Mappings: {len(folder['mappings'])}")


def test_parse_party_rel_delta():
    xml_file = os.path.join(TEST_XML_DIR, "wf_landing_party_rel_delta_1773695180248.xml")
    if not os.path.exists(xml_file):
        print(f"SKIP: {xml_file} not found")
        return

    converter = InformaticaConverter()
    result = converter.parse_file(xml_file)

    assert result
    folder = result["repositories"][0]["folders"][0]
    assert len(folder["sources"]) > 0
    print(f"PASS: test_parse_party_rel_delta")


def test_parse_party_role_delta():
    xml_file = os.path.join(TEST_XML_DIR, "wf_landing_party_role_delta_1773695180249.xml")
    if not os.path.exists(xml_file):
        print(f"SKIP: {xml_file} not found")
        return

    converter = InformaticaConverter()
    result = converter.parse_file(xml_file)

    assert result
    folder = result["repositories"][0]["folders"][0]
    assert len(folder["sources"]) > 0
    print(f"PASS: test_parse_party_role_delta")


def test_convert_to_files():
    xml_file = os.path.join(TEST_XML_DIR, "wf_landing_party_contact_mechanism_delta_1773695180247.xml")
    if not os.path.exists(xml_file):
        print(f"SKIP: {xml_file} not found")
        return

    with tempfile.TemporaryDirectory() as tmpdir:
        converter = InformaticaConverter(data_lib="pandas")
        output_dir = os.path.join(tmpdir, "output")
        converter.convert(xml_file, output_dir=output_dir)

        expected_files = [
            "helper_functions.py",
            "mapping_1.py",
            "workflow.py",
            "config.yml",
            "all_sql_queries.sql",
            "error_log.txt",
        ]

        for f in expected_files:
            filepath = os.path.join(output_dir, f)
            assert os.path.exists(filepath), f"{f} should exist"
            size = os.path.getsize(filepath)
            assert size > 0, f"{f} should not be empty"
            print(f"  {f}: {size} bytes")

        print(f"PASS: test_convert_to_files")


def test_convert_to_zip():
    xml_file = os.path.join(TEST_XML_DIR, "wf_landing_party_contact_mechanism_delta_1773695180247.xml")
    if not os.path.exists(xml_file):
        print(f"SKIP: {xml_file} not found")
        return

    with tempfile.TemporaryDirectory() as tmpdir:
        converter = InformaticaConverter(data_lib="pandas")
        zip_path = os.path.join(tmpdir, "output.zip")
        converter.convert(xml_file, output_zip=zip_path)

        assert os.path.exists(zip_path), "Zip file should exist"

        with zipfile.ZipFile(zip_path, "r") as zf:
            names = zf.namelist()
            assert "helper_functions.py" in names
            assert "workflow.py" in names
            assert "config.yml" in names
            assert "all_sql_queries.sql" in names
            assert "error_log.txt" in names

            mapping_files = [n for n in names if n.startswith("mapping_")]
            assert len(mapping_files) > 0, "Should have at least one mapping file"

            for name in names:
                print(f"  {name}: {zf.getinfo(name).file_size} bytes")

        print(f"PASS: test_convert_to_zip")


def test_convert_all_xmls_to_zip():
    xml_files = [
        "wf_landing_party_contact_mechanism_delta_1773695180247.xml",
        "wf_landing_party_delta_1773695180248.xml",
        "wf_landing_party_rel_delta_1773695180248.xml",
        "wf_landing_party_role_delta_1773695180249.xml",
    ]

    for xml_name in xml_files:
        xml_file = os.path.join(TEST_XML_DIR, xml_name)
        if not os.path.exists(xml_file):
            print(f"SKIP: {xml_name} not found")
            continue

        with tempfile.TemporaryDirectory() as tmpdir:
            converter = InformaticaConverter(data_lib="pandas")
            zip_path = os.path.join(tmpdir, f"{xml_name.replace('.xml', '')}.zip")
            converter.convert(xml_file, output_zip=zip_path)

            with zipfile.ZipFile(zip_path, "r") as zf:
                names = zf.namelist()
                mapping_count = len([n for n in names if n.startswith("mapping_")])
                print(f"  {xml_name}: {len(names)} files, {mapping_count} mappings")

    print(f"PASS: test_convert_all_xmls_to_zip")


def test_data_lib_options():
    xml_file = os.path.join(TEST_XML_DIR, "wf_landing_party_contact_mechanism_delta_1773695180247.xml")
    if not os.path.exists(xml_file):
        print(f"SKIP: {xml_file} not found")
        return

    for lib in ["pandas", "dask", "polars", "vaex", "modin"]:
        with tempfile.TemporaryDirectory() as tmpdir:
            converter = InformaticaConverter(data_lib=lib)
            output_dir = os.path.join(tmpdir, "output")
            converter.convert(xml_file, output_dir=output_dir)

            helper_file = os.path.join(output_dir, "helper_functions.py")
            with open(helper_file, "r") as f:
                content = f.read()

            if lib == "pandas":
                assert "import pandas as pd" in content
            elif lib == "dask":
                assert "import dask.dataframe as dd" in content
            elif lib == "polars":
                assert "import polars as pl" in content
            elif lib == "modin":
                assert "import modin.pandas as pd" in content

            print(f"  {lib}: OK")

    print(f"PASS: test_data_lib_options")


def test_json_output():
    xml_file = os.path.join(TEST_XML_DIR, "wf_landing_party_contact_mechanism_delta_1773695180247.xml")
    if not os.path.exists(xml_file):
        print(f"SKIP: {xml_file} not found")
        return

    converter = InformaticaConverter()
    result = converter.parse_file(xml_file)

    json_str = json.dumps(result, indent=2)
    parsed_back = json.loads(json_str)

    assert parsed_back["repositories"][0]["name"] == result["repositories"][0]["name"]
    print(f"PASS: test_json_output (JSON size: {len(json_str)} chars)")


if __name__ == "__main__":
    print("=" * 60)
    print("Running informatica-python tests")
    print("=" * 60)
    print()

    tests = [
        test_parse_contact_mechanism,
        test_parse_party_delta,
        test_parse_party_rel_delta,
        test_parse_party_role_delta,
        test_convert_to_files,
        test_convert_to_zip,
        test_convert_all_xmls_to_zip,
        test_data_lib_options,
        test_json_output,
    ]

    passed = 0
    failed = 0
    for test in tests:
        try:
            print(f"\nRunning: {test.__name__}")
            test()
            passed += 1
        except Exception as e:
            print(f"FAIL: {test.__name__}: {e}")
            import traceback
            traceback.print_exc()
            failed += 1

    print(f"\n{'=' * 60}")
    print(f"Results: {passed} passed, {failed} failed")
    print(f"{'=' * 60}")
