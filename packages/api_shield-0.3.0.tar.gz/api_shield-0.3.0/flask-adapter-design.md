# Flask Adapter Design

> Architecture and implementation plan for `shield.wsgi` and `shield.flask`.
> Finalised after researching the WSGI spec (PEP 3333), Flask async support,
> and asgiref internals.

---

## Background & Key Decisions

### Why Not `flask[async]`

`flask[async]` (which installs `asgiref`) was investigated as a potential sync→async
bridge. It was ruled out for one critical reason:

**Flask creates a new event loop per request.**

```
Request 1 → new event loop A → redis pool binds to loop A → request ends → loop A CLOSED
Request 2 → new event loop B → redis pool references closed loop A → RuntimeError
```

`flask[async]` is designed for view functions doing async I/O within a single request
lifecycle. `ShieldEngine` is a long-lived service with a connection pool that must persist
across all requests. These are incompatible.

### Why Pure WSGI Middleware (not `before_request` hook)

Using Flask's `before_request` hook would be Flask-specific. A pure WSGI middleware:

- Works with Flask, Django, Bottle, Falcon — any WSGI framework
- Sits below Flask's request dispatch — so it works equally for sync and async view
  functions without any special handling
- Lets a future `shield.django` reuse `shield.wsgi` with only a thin startup hook

### Sync/Async Bridge: Persistent Background Event Loop

Since WSGI is synchronous but `ShieldEngine` is async, we use a single daemon thread
running a persistent `asyncio` event loop. All engine calls go through
`asyncio.run_coroutine_threadsafe(coro, loop).result()`.

```
gunicorn thread 1 ─┐
gunicorn thread 2 ─┤──► asyncio.run_coroutine_threadsafe(coro, loop)
gunicorn thread 3 ─┘              │
                         single daemon thread
                         persistent event loop
                                  │
                         RedisBackend pool bound
                         to THIS loop — alive for
                         the lifetime of the process
```

`asyncio.run_coroutine_threadsafe` is explicitly thread-safe — it enqueues work via the
loop's internal queue. This is the same pattern used by `redis-py`'s own sync client.

---

## Module Layout

```
shield/
├── wsgi/                     # framework-agnostic WSGI enforcement layer
│   ├── __init__.py           # exports: ShieldWSGIMiddleware
│   ├── middleware.py         # pure WSGI middleware — no Flask import
│   └── _bridge.py            # persistent background loop + run_sync()
│
└── flask/                    # Flask-specific startup layer
    ├── __init__.py           # exports: ShieldFlask, ShieldBlueprint, decorators
    ├── extension.py          # ShieldFlask.init_app() — scans url_map at startup
    ├── blueprint.py          # ShieldBlueprint(Blueprint)
    └── decorators.py         # __shield_meta__ stamping — no fastapi/starlette imports
```

`shield.wsgi` has zero framework dependencies. `shield.flask` imports Flask but never
imports `shield.wsgi` internals — it only feeds the engine at startup.

---

## WSGI Response Flow

Unlike ASGI, WSGI never hands the response object back to the middleware. The response
travels through two separate channels:

| Channel | Mechanism |
|---|---|
| Status + headers | `start_response(status, headers)` callback — Flask calls this |
| Body | Return value — Flask returns an iterable of `bytes` chunks |

To intercept/modify a response the middleware **wraps `start_response`** before passing
it down, and optionally wraps the returned iterable.

```
Server → middleware(environ, start_response)
              │
              ├── engine.check() raises?
              │       └── call start_response directly + return error body
              │           Flask is never called
              │
              └── Flask(environ, wrapped_start_response)
                          │
                          ├── Flask calls wrapped_start_response("200 OK", headers)
                          │       └── wrapper injects extra headers → calls real start_response
                          │
                          └── Flask returns [b'{"ok": true}']
                                  │
              middleware receives iterable ◄────────────────┘
              returns it to server
```

---

## `shield/wsgi/_bridge.py`

```python
"""Persistent background event loop for bridging async ShieldEngine to sync WSGI."""

import asyncio
import threading
from typing import Any, Coroutine, TypeVar

T = TypeVar("T")

_loop: asyncio.AbstractEventLoop | None = None
_thread: threading.Thread | None = None
_lock = threading.Lock()


def _get_loop() -> asyncio.AbstractEventLoop:
    """Return the persistent background event loop, creating it if needed."""
    global _loop, _thread
    with _lock:
        if _loop is None or not _loop.is_running():
            _loop = asyncio.new_event_loop()
            _thread = threading.Thread(
                target=_loop.run_forever,
                daemon=True,
                name="shield-bg-loop",
            )
            _thread.start()
    return _loop


def run_sync(coro: Coroutine[Any, Any, T]) -> T:
    """Run an async coroutine from any sync (WSGI) thread.

    Thread-safe. Multiple WSGI worker threads can call this simultaneously.
    The coroutine is enqueued on the persistent background loop and the
    calling thread blocks until the result is ready.
    """
    future = asyncio.run_coroutine_threadsafe(coro, _get_loop())
    return future.result()
```

---

## `shield/wsgi/middleware.py`

```python
"""ShieldWSGIMiddleware — pure WSGI enforcement layer.

No Flask imports. Works with any WSGI framework.
"""

import json
from typing import Any, Callable, Iterable

from shield.core.engine import ShieldEngine
from shield.core.exceptions import EnvGatedException, MaintenanceException, RouteDisabledException
from shield.core.models import RouteStatus
from shield.wsgi._bridge import run_sync

_SKIP_PREFIXES = ("/shield/", "/static", "/docs", "/redoc", "/openapi.json")


class ShieldWSGIMiddleware:
    """WSGI middleware that enforces route lifecycle policies.

    Parameters
    ----------
    app:
        The WSGI application to wrap (e.g. Flask's ``app.wsgi_app``).
    engine:
        The ``ShieldEngine`` that owns all route state.
    force_active_paths:
        Set of path strings that bypass all shield checks. Populated by
        ``ShieldFlask.init_app()`` after scanning ``app.url_map``.
    responses:
        Optional mapping of shield status → response factory. Same semantics
        as the FastAPI adapter's ``responses=`` parameter.
    """

    def __init__(
        self,
        app: Callable,
        engine: ShieldEngine,
        force_active_paths: set[str] | None = None,
        responses: dict[str, Any] | None = None,
    ) -> None:
        self.app = app
        self.engine = engine
        self._force_active: set[str] = force_active_paths or set()
        self._default_responses: dict[str, Any] = responses or {}

    def __call__(self, environ: dict, start_response: Callable) -> Iterable[bytes]:
        path = environ.get("PATH_INFO", "")
        method = environ.get("REQUEST_METHOD", "GET")

        # Always skip internal prefixes.
        if any(path.startswith(p) for p in _SKIP_PREFIXES):
            return self.app(environ, start_response)

        # force_active routes bypass all checks.
        if path in self._force_active:
            return self.app(environ, start_response)

        # Run the shield check synchronously via background loop.
        try:
            run_sync(self.engine.check(path, method=method))
        except MaintenanceException as exc:
            return self._maintenance_response(start_response, path, exc)
        except RouteDisabledException as exc:
            return self._disabled_response(start_response, path, exc)
        except EnvGatedException:
            start_response("404 Not Found", [("Content-Type", "application/json")])
            return [b""]

        # Deprecated routes: pass through but inject RFC headers by wrapping
        # start_response so the headers are added when Flask calls it.
        state = run_sync(self.engine._resolve_state(path, method))
        if state and state.status == RouteStatus.DEPRECATED:
            return self.app(environ, self._wrap_deprecated(start_response, state))

        return self.app(environ, start_response)

    # ------------------------------------------------------------------
    # start_response wrappers
    # ------------------------------------------------------------------

    @staticmethod
    def _wrap_deprecated(start_response: Callable, state: Any) -> Callable:
        """Return a wrapped start_response that injects Deprecation headers."""
        def wrapped(status: str, headers: list, exc_info: Any = None) -> Any:
            headers = list(headers)
            headers.append(("Deprecation", "true"))
            if state.sunset_date:
                headers.append(("Sunset", state.sunset_date))
            if state.successor_path:
                headers.append(("Link", f'<{state.successor_path}>; rel="successor-version"'))
            return start_response(status, headers, exc_info)
        return wrapped

    # ------------------------------------------------------------------
    # Error response builders
    # ------------------------------------------------------------------

    @staticmethod
    def _maintenance_response(
        start_response: Callable, path: str, exc: MaintenanceException
    ) -> list[bytes]:
        retry_after = exc.retry_after.isoformat() if exc.retry_after else None
        body: dict = {
            "error": {
                "code": "MAINTENANCE_MODE",
                "message": "This endpoint is temporarily unavailable",
                "reason": exc.reason,
                "path": path,
            }
        }
        if retry_after:
            body["error"]["retry_after"] = retry_after
        headers = [("Content-Type", "application/json")]
        if retry_after:
            headers.append(("Retry-After", retry_after))
        start_response("503 Service Unavailable", headers)
        return [json.dumps(body).encode()]

    @staticmethod
    def _disabled_response(
        start_response: Callable, path: str, exc: RouteDisabledException
    ) -> list[bytes]:
        body = {
            "error": {
                "code": "ROUTE_DISABLED",
                "message": "This endpoint has been disabled",
                "reason": exc.reason,
                "path": path,
            }
        }
        start_response("503 Service Unavailable", [("Content-Type", "application/json")])
        return [json.dumps(body).encode()]
```

---

## `shield/flask/decorators.py`

These are **identical in behaviour** to the FastAPI decorators but have zero
`fastapi`/`starlette` imports. They only stamp `__shield_meta__` on the view function.
The WSGI middleware reads the registered state from the engine — not the meta dict
directly — so no dep injection machinery is needed.

```python
from functools import wraps
from typing import Any, Callable, TypeVar

F = TypeVar("F", bound=Callable[..., Any])


def _stamp(func: F, meta: dict[str, Any]) -> F:
    existing: dict[str, Any] = getattr(func, "__shield_meta__", {})
    existing.update(meta)
    func.__shield_meta__ = existing  # type: ignore[attr-defined]
    return func


def maintenance(reason: str = "", start=None, end=None) -> Callable[[F], F]:
    def decorator(func: F) -> F:
        return _stamp(wraps(func)(func), {"status": "maintenance", "reason": reason})
    return decorator


def env_only(*envs: str) -> Callable[[F], F]:
    def decorator(func: F) -> F:
        return _stamp(wraps(func)(func), {"status": "env_gated", "allowed_envs": list(envs)})
    return decorator


def disabled(reason: str = "") -> Callable[[F], F]:
    def decorator(func: F) -> F:
        return _stamp(wraps(func)(func), {"status": "disabled", "reason": reason})
    return decorator


def deprecated(sunset: str, use_instead: str = "") -> Callable[[F], F]:
    def decorator(func: F) -> F:
        return _stamp(wraps(func)(func), {
            "status": "deprecated",
            "sunset_date": sunset,
            "successor_path": use_instead or None,
        })
    return decorator


def force_active(func: F) -> F:
    return _stamp(wraps(func)(func), {"force_active": True})
```

---

## `shield/flask/extension.py`

```python
"""ShieldFlask — Flask extension for startup route scanning."""

import anyio
from flask import Flask

from shield.core.engine import ShieldEngine
from shield.wsgi._bridge import run_sync


class ShieldFlask:
    """Flask extension that scans ``app.url_map`` at startup and registers
    all decorated routes with the engine.

    Parameters
    ----------
    engine:
        The shared ``ShieldEngine`` instance.

    Usage::

        engine = ShieldEngine()
        shield = ShieldFlask(engine=engine)

        app = Flask(__name__)
        shield.init_app(app)
        app.wsgi_app = ShieldWSGIMiddleware(app.wsgi_app, engine,
                                            force_active_paths=shield.force_active_paths)
    """

    def __init__(self, engine: ShieldEngine) -> None:
        self.engine = engine
        self.force_active_paths: set[str] = set()

    def init_app(self, app: Flask) -> None:
        """Scan url_map and register all routes with the engine."""
        routes_to_register = []
        force_active: set[str] = set()

        for rule in app.url_map.iter_rules():
            if rule.endpoint == "static":
                continue
            view_func = app.view_functions.get(rule.endpoint)
            if view_func is None:
                continue
            meta = getattr(view_func, "__shield_meta__", {})
            if meta.get("force_active"):
                force_active.add(rule.rule)
                continue
            for method in sorted((rule.methods or set()) - {"HEAD", "OPTIONS"}):
                routes_to_register.append((f"{method}:{rule.rule}", meta))

        self.force_active_paths = force_active
        run_sync(self.engine.register_batch(routes_to_register))
```

---

## `shield/flask/blueprint.py`

```python
"""ShieldBlueprint — drop-in replacement for Flask's Blueprint."""

from flask import Blueprint

from shield.core.engine import ShieldEngine
from shield.wsgi._bridge import run_sync


class ShieldBlueprint(Blueprint):
    """Drop-in replacement for ``flask.Blueprint``.

    Automatically registers shield metadata with the engine when the
    blueprint is registered on a Flask app.

    Parameters
    ----------
    engine:
        The shared ``ShieldEngine`` instance.
    """

    def __init__(self, *args, engine: ShieldEngine, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self._shield_engine = engine
        self.record_once(self._on_register)

    def _on_register(self, state) -> None:
        """Called by Flask when the blueprint is registered on an app."""
        routes_to_register = []
        app = state.app

        for rule in app.url_map.iter_rules():
            if rule.endpoint.startswith(self.name + "."):
                view_func = app.view_functions.get(rule.endpoint)
                if view_func is None:
                    continue
                meta = getattr(view_func, "__shield_meta__", {})
                for method in sorted((rule.methods or set()) - {"HEAD", "OPTIONS"}):
                    routes_to_register.append((f"{method}:{rule.rule}", meta))

        run_sync(self._shield_engine.register_batch(routes_to_register))
```

---

## Target Usage

```python
from flask import Flask
from shield.core.engine import ShieldEngine
from shield.core.backends.redis import RedisBackend
from shield.wsgi import ShieldWSGIMiddleware
from shield.flask import ShieldFlask, ShieldBlueprint
from shield.flask.decorators import maintenance, disabled, force_active, env_only, deprecated

engine = ShieldEngine(backend=RedisBackend("redis://localhost:6379"))
shield = ShieldFlask(engine=engine)

bp = ShieldBlueprint("api", __name__, engine=engine)

@bp.route("/payments")
@maintenance(reason="DB migration")
def get_payments():
    return {"ok": True}

@bp.route("/debug")
@env_only("dev", "staging")
def debug():
    return {"env": "dev"}

@bp.route("/old-endpoint")
@disabled(reason="Use /v2/endpoint instead")
def old_endpoint():
    return {}

@bp.route("/v1/users")
@deprecated(sunset="Sat, 01 Jan 2027 00:00:00 GMT", use_instead="/v2/users")
def v1_users():
    return {}

@bp.route("/health")
@force_active
def health():
    return {"status": "ok"}

app = Flask(__name__)
shield.init_app(app)                    # scan url_map, register routes
app.register_blueprint(bp, url_prefix="/api")

# Wrap at WSGI level — works for both sync and async views
app.wsgi_app = ShieldWSGIMiddleware(
    app.wsgi_app,
    engine,
    force_active_paths=shield.force_active_paths,
)
```

---

## Sync + Async View Compatibility

Both sync and async Flask views are supported with **zero extra code**. The WSGI
middleware operates below Flask's dispatch layer. By the time Flask creates its
per-request event loop (for async views via asgiref), the shield check has already
completed. The two event loops never interact:

```
Our background loop (daemon thread, persistent)
  └── ShieldEngine / RedisBackend pool       ← lives here permanently

Flask per-request loop (worker thread, ephemeral — only with flask[async])
  └── async view functions                   ← lives and dies per request
```

---

## `pyproject.toml` Changes Needed

```toml
[project.optional-dependencies]
wsgi  = []                        # no extra deps — pure stdlib + shield.core
flask = ["flask>=2.0"]

all = [
    ...existing...
    "flask>=2.0",
]
```

---

## Test Plan

### `tests/wsgi/`
- `test_bridge.py` — `run_sync()` from multiple threads simultaneously; verify no race conditions
- `test_middleware.py` — spin up a minimal WSGI app (not Flask), assert correct status codes for each route state
- `test_deprecation_headers.py` — verify `start_response` wrapping injects headers correctly

### `tests/flask/`
- `test_extension.py` — `init_app()` registers routes; `force_active_paths` populated correctly
- `test_blueprint.py` — `ShieldBlueprint._on_register()` fires; routes appear in engine
- `test_decorators.py` — `__shield_meta__` stamped correctly on sync and async view functions
- `test_integration.py` — full Flask app with `ShieldWSGIMiddleware`; assert all decorator states
  produce correct HTTP responses using Flask's test client

---

## Implementation Order

1. `shield/wsgi/_bridge.py` — background loop + `run_sync()` (pure Python, no deps)
2. `shield/wsgi/middleware.py` — WSGI middleware
3. `shield/flask/decorators.py` — `__shield_meta__` stamping
4. `shield/flask/extension.py` — `ShieldFlask.init_app()`
5. `shield/flask/blueprint.py` — `ShieldBlueprint`
6. Tests for each module above
7. Update `pyproject.toml` with `wsgi` and `flask` extras
