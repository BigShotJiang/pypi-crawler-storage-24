# api-shield — Rate Limiting Implementation Spec

> This document is an implementation spec for adding rate limiting to api-shield.
> Read the existing codebase fully before starting. Understand the current
> ShieldEngine, ShieldBackend ABC, middleware pipeline, and decorator pattern.
> Follow every architectural rule in CLAUDE.md. Build in the order specified.
> Do not skip ahead. Run the full test suite after every module.

---

## Context and Approach

Rate limiting in api-shield wraps the `limits` Python library, which already
implements all rate limiting algorithms correctly. Do not reimplement any
algorithm logic. The `limits` library handles counting, window management,
and expiry. api-shield's job is to:

- Provide the decorator API developers actually use
- Wire `limits` storage to the existing ShieldBackend infrastructure
- Integrate rate limit checks into the existing `engine.check()` pipeline
- Expose rate limit state in the dashboard and CLI
- Produce correct RFC-compliant HTTP responses

Take inspiration from `slowapi` for the decorator API and request key
extraction patterns. Read the slowapi source before designing the key
extraction layer — it handles edge cases around proxied IPs, forwarded
headers, and async request parsing that are easy to get wrong.

---

## Dependencies

Rate limiting is an **optional feature**. The `limits` library is not
installed by default. Users must explicitly opt in via one of:

```bash
pip install api-shield[rate-limit]   # rate limiting only
pip install api-shield[all]          # everything including rate limiting
```

### `pyproject.toml` changes

Add a new optional dependency group:

```toml
[project.optional-dependencies]
rate-limit = ["limits>=3.6"]
all = [
    "limits>=3.6",          # add to existing all group
]
```

Do not add `limits` to the core `dependencies` list. It must remain
optional.

### Import guard pattern

Every module inside `shield/core/rate_limit/` must guard the `limits`
import at the top of the file:

```python
try:
    import limits
    HAS_LIMITS = True
except ImportError:
    HAS_LIMITS = False
```

In `ShieldEngine.__init__`, before initialising the rate limiter:

```python
if self._has_rate_limit_config:
    try:
        from shield.core.rate_limit.storage import create_rate_limit_storage
        from shield.core.rate_limit.limiter import ShieldRateLimiter
    except ImportError:
        raise ImportError(
            "Rate limiting requires the 'limits' library. "
            "Install it with: pip install api-shield[rate-limit]"
        ) from None
```

This means importing `shield` or using `ShieldEngine` without rate
limiting configured works with no extra dependencies. The ImportError
is only raised if a user actually configures rate limiting without
having installed the optional dependency — and the message tells them
exactly what to do.

`limits` is already used by `slowapi` internally — this means api-shield
and slowapi are compatible at the storage layer if a team is migrating.

---

---

## Module 1 — Core Models

**File to create:** `shield/core/rate_limit/models.py`

Define the following Pydantic v2 models. All models must use `model_validate`
and `model_dump`. No raw dicts anywhere in the rate limit layer.

### `RateLimitAlgorithm`

A `str` enum with these values:
- `FIXED_WINDOW` — counts requests in fixed time buckets. Simple, cheap,
  allows bursts at window boundaries.
- `SLIDING_WINDOW` — smooths out boundary bursts by tracking a rolling window.
  Higher memory usage but fairer. This is the default.
- `MOVING_WINDOW` — exact sliding window using per-request timestamps.
  Most accurate, highest memory usage.
- `TOKEN_BUCKET` — tokens accumulate over time up to a capacity. Best for
  allowing short bursts while enforcing an average rate.

### `RateLimitKeyStrategy`

A `str` enum with these values. **The default behaviour on a missing key
is defined per strategy and must be documented loudly — developers who
choose the wrong strategy for their route will get incorrect enforcement
with no runtime error to tell them.**

- `IP` — extract client IP from request headers/ASGI scope.
  **Default strategy. Never returns None.** Falls back to `"unknown"`
  if no IP can be determined — this is the only strategy with a
  guaranteed non-None result.

- `USER` — reads `request.state.user_id`.
  **Requires your auth middleware to set `request.state.user_id` before
  the rate limiter runs. If it is not set, behaviour is controlled by
  `on_missing_key` (default: `EXEMPT`).** Do not use this strategy on
  routes that allow unauthenticated access unless you explicitly set
  `on_missing_key` to declare what you want.

- `API_KEY` — reads the `X-API-Key` request header.
  **If the header is absent, behaviour is controlled by `on_missing_key`
  (default: `FALLBACK_IP`).** This means unauthenticated requests are
  still rate limited, just bucketed by IP rather than by key.

- `GLOBAL` — uses the route path as the key. Every client shares one
  counter. **Never missing.** Use for absolute throughput caps on a
  route regardless of who is calling.

- `CUSTOM` — caller provides an async callable `(Request) -> str | None`.
  **If the callable returns `None`, behaviour is controlled by
  `on_missing_key` (default: `EXEMPT`).** The callable must not raise —
  if it does, the exception propagates and the request fails. Handle
  errors inside the callable.

### `OnMissingKey`

Controls what happens when a key strategy cannot resolve a key for the
current request. This enum must be defined in `models.py` and imported
everywhere the key extraction logic runs.

```python
class OnMissingKey(str, Enum):
    EXEMPT      = "exempt"
    # Request bypasses the rate limit entirely. No counter is incremented.
    # The response is returned normally with no rate limit headers.
    # USE WHEN: the route requires auth and unauthenticated requests should
    # not be rate limited by this decorator (auth middleware handles them).

    FALLBACK_IP = "fallback_ip"
    # Falls back to the client IP as the key.
    # Counter increments against the IP bucket.
    # USE WHEN: you want to rate limit all callers but prefer per-identity
    # limiting for authenticated ones.

    BLOCK       = "block"
    # Returns 429 immediately. No counter is incremented.
    # USE WHEN: the route must have a resolvable identity and you want
    # missing identity to be treated as a rate limit violation.
    # NOTE: if you want a 401 or 403, use auth middleware — not this.
    # BLOCK deliberately returns 429 to keep the rate limiter semantically
    # consistent. Auth enforcement belongs in auth middleware.
```

**Per-strategy defaults (applied when `on_missing_key` is not set):**

| Strategy | Default `on_missing_key` | Rationale |
|---|---|---|
| `IP` | N/A — never missing | Falls back to `"unknown"` key |
| `USER` | `EXEMPT` | Missing user_id means unauthenticated — not this limiter's concern |
| `API_KEY` | `FALLBACK_IP` | No API key means public access — still worth limiting by IP |
| `GLOBAL` | N/A — never missing | Uses route path |
| `CUSTOM` | `EXEMPT` | Caller controls key resolution |

These defaults are chosen to be **safe, not silent**. A missing `USER`
key that silently falls back to IP is the most dangerous outcome — it
mixes authenticated and unauthenticated traffic in the same counter,
potentially blocking legitimate users because an unauthenticated scraper
shared their IP. `EXEMPT` avoids this at the cost of not rate limiting
unauthenticated requests, which is correct — if unauthenticated requests
are a concern, add auth middleware first.

### `RateLimitTier`

```python
class RateLimitTier(BaseModel):
    name: str               # "free", "pro", "enterprise"
    limit: str              # "100/day", "10000/day", "unlimited"
```

### `RateLimitPolicy`

```python
class RateLimitPolicy(BaseModel):
    path: str
    method: str
    limit: str                              # "100/minute", "1000/hour"
    algorithm: RateLimitAlgorithm = RateLimitAlgorithm.SLIDING_WINDOW
    key_strategy: RateLimitKeyStrategy = RateLimitKeyStrategy.IP
    on_missing_key: OnMissingKey | None = None
    # When None, the per-strategy default from the table above is used.
    # Set explicitly to override the default and make your intent clear.
    burst: int = 0                          # extra requests above limit
    tiers: list[RateLimitTier] = []        # if set, overrides limit per tier
    tier_resolver: str = "plan"             # request.state attribute to read tier from
    exempt_ips: list[str] = []             # CIDR notation supported
    exempt_roles: list[str] = []           # checked against request.state.user_roles
```

**Resolving the effective `on_missing_key` at runtime:**

```python
STRATEGY_DEFAULTS: dict[RateLimitKeyStrategy, OnMissingKey] = {
    RateLimitKeyStrategy.USER:   OnMissingKey.EXEMPT,
    RateLimitKeyStrategy.API_KEY: OnMissingKey.FALLBACK_IP,
    RateLimitKeyStrategy.CUSTOM: OnMissingKey.EXEMPT,
}

def resolve_on_missing_key(policy: RateLimitPolicy) -> OnMissingKey:
    if policy.on_missing_key is not None:
        return policy.on_missing_key
    return STRATEGY_DEFAULTS.get(policy.key_strategy, OnMissingKey.EXEMPT)
```

`IP` and `GLOBAL` are not in `STRATEGY_DEFAULTS` because they never
produce a missing key — the fallback is unreachable for those strategies.

### `RateLimitResult`

Returned by every rate limit check. Always populated — never None.

```python
class RateLimitResult(BaseModel):
    allowed: bool
    limit: str
    remaining: int
    reset_at: datetime
    retry_after_seconds: int               # only meaningful when allowed=False
    key: str                               # the actual key that was checked
    tier: str | None                       # which tier was applied, if any
    key_was_missing: bool = False          # True when on_missing_key was applied
    missing_key_behaviour: OnMissingKey | None = None  # which behaviour fired
```

`key_was_missing` and `missing_key_behaviour` are included so the
middleware and dashboard can surface this information. A high rate of
`key_was_missing=True` results on a route means the key strategy is
misconfigured — the developer set `USER` or `API_KEY` but auth
middleware is not running or not setting the expected attribute.

### `RateLimitHit`

Recorded to the audit/metrics layer every time a request is blocked.

```python
class RateLimitHit(BaseModel):
    id: str                                # uuid4
    timestamp: datetime
    path: str
    method: str
    key: str
    limit: str
    tier: str | None
    reset_at: datetime
```

---

## Module 2 — Storage Bridge

**File to create:** `shield/core/rate_limit/storage.py`

This module bridges the `limits` library storage layer with the existing
ShieldBackend infrastructure.

### Design intent

By default, rate limit counters live in the same backend as route state.
A user can optionally provide a dedicated `rate_limit_backend` to
`ShieldEngine` to separate the two concerns. When a dedicated backend is
provided, it is used exclusively for rate limit counter operations.

### `RateLimitStorage` ABC

Define an abstract base class with these methods:

```python
class RateLimitStorage(ABC):

    @abstractmethod
    async def increment(
        self,
        key: str,
        limit: str,
        algorithm: RateLimitAlgorithm,
    ) -> RateLimitResult: ...

    @abstractmethod
    async def get_remaining(self, key: str, limit: str) -> int: ...

    @abstractmethod
    async def reset(self, key: str) -> None: ...

    @abstractmethod
    async def reset_all_for_path(self, path: str) -> None: ...
```

### `MemoryRateLimitStorage`

Wraps `limits`'s `MemoryStorage`. Thread-safe via `asyncio.Lock`.
Correct for single-process, single-worker deployments only.
On instantiation, log a `DEBUG` message noting it is not safe for
multi-worker deployments — not a warning, just debug. The warning
is only raised when a user explicitly tries to use it in a
multi-worker context (which cannot be detected at init time, so
document the limitation clearly in docstrings).

### `RedisRateLimitStorage`

Wraps `limits`'s `RedisStorage`. Takes a `redis_url: str` parameter.
Uses the same Redis connection URL format as the existing `RedisBackend`.
If the existing backend is a `RedisBackend`, extract its URL and reuse
it rather than requiring duplicate config.

Implement `reset_all_for_path` by scanning keys matching
`shield:ratelimit:{path}:*` and deleting them. Use `SCAN` not `KEYS`
to avoid blocking Redis.

### `FileRateLimitStorage`

Extends `RateLimitStorage`. Uses a **window-aware snapshot pattern**:
counters live in-memory for hot-path speed, but are periodically
flushed to the shield state file and restored intelligently on startup.

**Why this works:** Rate limit counters are time-bounded. A counter
tracking "100 requests per minute" becomes irrelevant the moment its
60-second window expires. On restart, the storage checks whether each
counter's window has already elapsed. If it has, the counter resets
naturally — no restoration needed. If it hasn't, the counter is
restored with the correct remaining TTL so the window continues
uninterrupted across the restart.

This means:
- Long windows (daily, hourly) survive restarts with full accuracy
- Short windows (per-minute) survive if the restart is faster than
  the window duration, which is true for rolling deploys and crashes
- Windows that expired during downtime reset naturally — no stale
  counters leaked into the next window

**Snapshot format** — written under a `rate_limits` key in the
existing shield state file alongside route states and audit entries:

```json
{
  "states": { ... },
  "audit": [ ... ],
  "rate_limits": {
    "shield:ratelimit:GET:/api/payments:192.168.1.1": {
      "count": 45,
      "window_start": "2025-03-16T14:23:00Z",
      "window_duration_seconds": 60,
      "limit": "100/minute"
    }
  }
}
```

**Snapshot writes** happen in two ways:

1. **Background task** — an `asyncio.Task` flushes the snapshot to
   disk every `snapshot_interval_seconds` (default: 10). This is
   started when the first counter is created and cancelled on shutdown.
   10 seconds means at most 10 seconds of counter data is lost on an
   unclean shutdown.

2. **Graceful shutdown** — write a final snapshot immediately when
   the ASGI lifespan `shutdown` event fires. After a graceful restart
   (e.g. `uvicorn --reload`, deployment via process manager), zero
   counter data is lost.

**Startup restoration:**

```python
async def _restore_from_snapshot(self) -> None:
    snapshot = await self._load_snapshot()
    now = datetime.now(UTC)

    for key, entry in snapshot.items():
        window_start = datetime.fromisoformat(entry["window_start"])
        window_end = window_start + timedelta(seconds=entry["window_duration_seconds"])

        if now >= window_end:
            # Window has expired during downtime — counter resets naturally
            # Do not restore. The next request starts a fresh window.
            continue

        remaining_ttl = (window_end - now).total_seconds()

        # Restore counter into MemoryStorage with the remaining TTL
        # so the window expires at the correct time
        await self._memory_storage.restore(
            key=key,
            count=entry["count"],
            ttl_seconds=remaining_ttl,
        )
```

**Multi-worker limitation:** Same as `MemoryRateLimitStorage` — each
worker has its own counter. Emit `ShieldProductionWarning` on init:

```
FileBackend rate limiting uses in-memory counters with file-based
persistence. Counters survive restarts for active windows. This is
safe for single-process deployments only. Under multiple workers,
each worker enforces the limit independently. For multi-worker
deployments, use RedisBackend.
```

**`snapshot_interval_seconds` parameter** — configurable at init:

```python
FileRateLimitStorage(
    file_path="shield_state.json",
    snapshot_interval_seconds=10,   # default, adjust to taste
)
```

Lower values mean less data lost on unclean shutdown but more disk
writes. 10 seconds is a safe default for most deployments.

### Storage factory function

```python
def create_rate_limit_storage(
    backend: ShieldBackend,
    rate_limit_backend: ShieldBackend | None = None,
    snapshot_interval_seconds: int = 10,
) -> RateLimitStorage:
```

Logic:
1. If `rate_limit_backend` is explicitly provided, use it regardless
   of what the main backend is
2. If main backend is `RedisBackend`, create `RedisRateLimitStorage`
   using the same connection URL
3. If main backend is `MemoryBackend`, create `MemoryRateLimitStorage`
4. If main backend is `FileBackend`, create `FileRateLimitStorage`
   using the same file path, with `snapshot_interval_seconds` passed
   through. Emits `ShieldProductionWarning` (single-worker limitation).

No backend raises an error. All three backends support rate limiting
with clearly documented and meaningfully different persistence
characteristics.

---

## Module 3 — Key Extraction

**File to create:** `shield/core/rate_limit/keys.py`

This is the most subtle part of the rate limiter. Read slowapi's
`_get_remote_address` and key function implementation before writing
this module. Slowapi handles edge cases around:
- `X-Forwarded-For` headers (comma-separated, take the first)
- `X-Real-IP` headers
- Direct client IP from ASGI scope
- IPv6 normalisation

### Key extractor functions

Implement these as async callables that take a `Request` and return
`str | None`. Returning `None` signals a missing key — the caller
applies `on_missing_key` behaviour. Never raise from these functions.

**`extract_ip(request: Request) -> str`**

The only extractor that never returns `None`. Check in order:
1. `X-Forwarded-For` header — take the first IP in the comma-separated
   list, strip whitespace
2. `X-Real-IP` header
3. `request.client.host` from the ASGI scope
4. Return `"unknown"` — never raise, never return None

Strip port numbers from IPv4 addresses. Normalise IPv6 with
`ipaddress.ip_address(ip).compressed`.

**`extract_user(request: Request) -> str | None`**

Return `getattr(request.state, "user_id", None)`.
Return `None` if the attribute is not set. Do not fall back to IP —
that is the caller's responsibility via `on_missing_key`. Never raise.

**`extract_api_key(request: Request) -> str | None`**

Return `request.headers.get("X-API-Key")` or `None` if absent.
Do not fall back to IP — that is the caller's responsibility via
`on_missing_key`. Never raise.

**`extract_global(request: Request) -> str`**

Always return `request.url.path`. Never missing.

### `KeyExtractor`

```python
KeyExtractor = Callable[[Request], Awaitable[str | None]]
```

Note the return type is `str | None` — all extractors except `IP` and
`GLOBAL` may return `None`. The `None` case is handled by the limiter,
not by the extractor.

### `resolve_key_extractor`

```python
def resolve_key_extractor(
    strategy: RateLimitKeyStrategy,
    custom_func: KeyExtractor | None = None,
) -> KeyExtractor:
```

Maps strategy enum to the appropriate function. Raises `ValueError` if
strategy is `CUSTOM` and `custom_func` is None.

### Missing key handler

This is the central function that applies `on_missing_key` behaviour
when an extractor returns `None`. It belongs in `keys.py` and is called
from `ShieldRateLimiter.check()`.

```python
async def handle_missing_key(
    request: Request,
    policy: RateLimitPolicy,
    logger: logging.Logger,
) -> tuple[str | None, OnMissingKey]:
    """
    Called when a key extractor returns None.

    Returns (resolved_key, behaviour_applied):
    - If EXEMPT: returns (None, EXEMPT) — caller skips rate limiting
    - If FALLBACK_IP: returns (ip_key, FALLBACK_IP) — caller uses IP key
    - If BLOCK: returns (None, BLOCK) — caller returns 429 immediately

    Always logs a WARNING. A missing key is always a signal worth surfacing.
    """
    behaviour = resolve_on_missing_key(policy)

    logger.warning(
        "api-shield rate_limit: key strategy '%s' returned no value "
        "for %s %s — applying on_missing_key='%s'. "
        "If this is unexpected, check that your auth middleware sets "
        "the expected attribute on request.state before the rate "
        "limiter runs.",
        policy.key_strategy,
        request.method,
        request.url.path,
        behaviour,
    )

    if behaviour == OnMissingKey.EXEMPT:
        return None, behaviour

    if behaviour == OnMissingKey.FALLBACK_IP:
        ip_key = await extract_ip(request)
        return ip_key, behaviour

    if behaviour == OnMissingKey.BLOCK:
        return None, behaviour

    return None, OnMissingKey.EXEMPT  # unreachable but satisfies type checker
```

**The warning message is non-negotiable.** Every missing key must
produce a log entry. A high rate of these warnings in production logs
is a diagnostic signal — the developer configured a key strategy that
does not match their auth setup. The warning message tells them exactly
what to check.

### Exemption check

```python
async def is_exempt(
    request: Request,
    policy: RateLimitPolicy,
) -> bool:
```

Check:
1. Client IP is in `policy.exempt_ips` (support CIDR notation using
   `ipaddress.ip_network` — same pattern as the existing IP allowlist
   in the maintenance module)
2. `request.state.user_roles` intersects `policy.exempt_roles`
   (check `hasattr` before accessing — not all routes have auth)

Return `True` if either condition is met. Exempt requests skip the
rate limit check entirely and do not consume quota.

---

## Module 4 — Rate Limiter

**File to create:** `shield/core/rate_limit/limiter.py`

This is the central rate limiting engine. It wraps storage and key
extraction into a single `check` method that `ShieldEngine` calls.

### `ShieldRateLimiter`

```python
class ShieldRateLimiter:
    def __init__(
        self,
        storage: RateLimitStorage,
        default_algorithm: RateLimitAlgorithm = RateLimitAlgorithm.SLIDING_WINDOW,
    ): ...
```

**`async check(path, method, request, policy) -> RateLimitResult`**

1. Check exemptions via `is_exempt` — if exempt, return
   `RateLimitResult(allowed=True, remaining=policy_limit, ...)` immediately
2. Resolve the effective limit — if `policy.tiers` is set, read
   `getattr(request.state, policy.tier_resolver, None)` to get the tier
   name, find the matching `RateLimitTier`, use its limit. If no tier
   matches or tier_resolver is not set on request.state, fall back to
   `policy.limit`.
3. If effective limit is `"unlimited"`, return allowed immediately
   without touching storage
4. Extract the key using the resolved `KeyExtractor`
5. **If the extractor returns `None`, call `handle_missing_key()` and
   apply the result:**
   - `EXEMPT` → return `RateLimitResult(allowed=True, key="", key_was_missing=True, missing_key_behaviour=EXEMPT)` immediately. Do not touch storage. Do not increment any counter.
   - `FALLBACK_IP` → use the returned IP key. Continue to step 6 with the IP key. Set `key_was_missing=True` on the result.
   - `BLOCK` → return `RateLimitResult(allowed=False, key="", retry_after_seconds=0, key_was_missing=True, missing_key_behaviour=BLOCK)` immediately. Do not touch storage.
6. Prepend path and method to the key for namespacing:
   `f"shield:ratelimit:{method.upper()}:{path}:{key}"`
7. Call `storage.increment(namespaced_key, limit, algorithm)`
8. Return the `RateLimitResult`

**`async reset(path: str, method: str | None = None) -> None`**

Called when a route transitions out of maintenance (counters reset
so clients aren't penalised for retrying during maintenance).
Delegates to `storage.reset_all_for_path(path)`.

**`async get_state(path: str, method: str) -> RateLimitState | None`**

Returns current rate limit metrics for the dashboard. If no policy
exists for this path+method, return None.

---

## Module 5 — Decorator

**File to update:** `shield/fastapi/decorators.py`

Add the `@rate_limit` decorator alongside the existing decorators.
Follow the exact same `__shield_meta__` pattern used by `@maintenance`,
`@env_only`, `@disabled`, etc. The decorator stamps metadata. The
`ShieldRouter` reads it at startup and registers the policy. The
`ShieldRateLimiter` enforces it at request time.

### `rate_limit` decorator

```python
def rate_limit(
    limit: str | dict[str, str],
    *,
    algorithm: RateLimitAlgorithm = RateLimitAlgorithm.SLIDING_WINDOW,
    key: RateLimitKeyStrategy | KeyExtractor = RateLimitKeyStrategy.IP,
    on_missing_key: OnMissingKey | None = None,
    # When None, the per-strategy default is used (see OnMissingKey table).
    # Set explicitly to make your intent clear and avoid surprises.
    burst: int = 0,
    exempt_ips: list[str] = [],
    exempt_roles: list[str] = [],
    tier_resolver: str = "plan",
):
```

**Parameter handling:**

`limit` can be:
- A string: `"100/minute"` — single limit for all clients
- A dict: `{"free": "100/day", "pro": "10000/day", "enterprise": "unlimited"}`
  — tiered limits. When a dict is passed, convert to `list[RateLimitTier]`
  and set `key_strategy` to `USER` unless explicitly overridden (tiered
  limits imply authenticated users).

`key` can be:
- A `RateLimitKeyStrategy` enum value
- A custom async callable `(Request) -> str`

When `key` is a callable, set `key_strategy=RateLimitKeyStrategy.CUSTOM`
and store the callable separately in `__shield_meta__` under
`"rate_limit_key_func"`.

**`__shield_meta__` stamp:**

```python
func.__shield_meta__ = {
    **getattr(func, "__shield_meta__", {}),   # preserve existing meta
    "rate_limit": {
        "limit": limit_string,
        "algorithm": algorithm,
        "key_strategy": key_strategy,
        "on_missing_key": on_missing_key,     # None = use per-strategy default
        "burst": burst,
        "tiers": tiers,
        "tier_resolver": tier_resolver,
        "exempt_ips": exempt_ips,
        "exempt_roles": exempt_roles,
    }
}
```

Note: use `**getattr(func, "__shield_meta__", {})` to merge with any
existing meta (e.g., a route decorated with both `@maintenance` and
`@rate_limit`). Never overwrite existing `__shield_meta__` keys.

**Decorator must preserve async/sync nature of wrapped function.**
Use `asyncio.iscoroutinefunction(func)` to branch. The wrapper itself
does nothing at request time — all logic lives in the engine.

### `ShieldRouter` update

In `ShieldRouter.add_api_route()`, extend the existing `__shield_meta__`
scan to also read the `"rate_limit"` key. When found, call:

```python
await engine.register_rate_limit(
    path=path,
    method=method,
    policy=RateLimitPolicy(**meta["rate_limit"], path=path, method=method)
)
```

---

## Module 6 — Engine Integration

**File to update:** `shield/core/engine.py`

### Constructor changes

Add these parameters to `ShieldEngine.__init__`:

```python
rate_limit_backend: ShieldBackend | None = None,
default_rate_limit_algorithm: RateLimitAlgorithm = RateLimitAlgorithm.SLIDING_WINDOW,
rate_limit_snapshot_interval: int = 10,   # seconds, only used by FileBackend
```

Store all three as instance variables (`self._rate_limit_backend`,
`self._default_rate_limit_algorithm`, `self._rate_limit_snapshot_interval`).
Pass `rate_limit_snapshot_interval` through to `create_rate_limit_storage`
when the factory is called inside `register_rate_limit`.

In `__init__`, after existing backend initialisation:

```python
self._rate_limiter: ShieldRateLimiter | None = None
self._rate_limit_policies: dict[str, RateLimitPolicy] = {}

# Only initialise the rate limiter if a route will actually use it.
# Initialisation is deferred to first call to register_rate_limit()
# so the ImportError for missing limits library is only raised when
# rate limiting is actually configured, not on every ShieldEngine init.
```

Lazy initialisation in `register_rate_limit`:

```python
async def register_rate_limit(
    self,
    path: str,
    method: str,
    policy: RateLimitPolicy,
) -> None:
    if self._rate_limiter is None:
        try:
            from shield.core.rate_limit.storage import create_rate_limit_storage
            from shield.core.rate_limit.limiter import ShieldRateLimiter
        except ImportError:
            raise ImportError(
                "Rate limiting requires the 'limits' library. "
                "Install it with: pip install api-shield[rate-limit]"
            ) from None

        storage = create_rate_limit_storage(
            self.backend,
            self._rate_limit_backend,
        )
        self._rate_limiter = ShieldRateLimiter(
            storage=storage,
            default_algorithm=self._default_rate_limit_algorithm,
        )

    key = f"{method.upper()}:{path}"
    self._rate_limit_policies[key] = policy
```

This design means `import shield` and using `ShieldEngine` with no rate
limiting has zero dependency on the `limits` library. The library is only
imported when a `@rate_limit` decorated route is registered at startup.

### `register_rate_limit`

Covered in the constructor changes section above. The method handles
lazy initialisation of the rate limiter on first call, so the `limits`
library import only happens when rate limiting is actually used.

### `engine.check()` update

After the existing state checks (DISABLED, MAINTENANCE, ENV_GATED) and
circuit breaker check, add:

```python
rate_limit_result: RateLimitResult | None = None

if self._rate_limiter:
    policy_key = f"{context.get('method', 'GET').upper()}:{path}"
    policy = self._rate_limit_policies.get(policy_key)

    if policy:
        rate_limit_result = await self._rate_limiter.check(
            path=path,
            method=context.get("method", "GET"),
            request=context.get("request"),
            policy=policy,
        )

        if not rate_limit_result.allowed:
            await self._record_rate_limit_hit(path, policy, rate_limit_result)
            raise RateLimitExceededException(
                limit=rate_limit_result.limit,
                retry_after_seconds=rate_limit_result.retry_after_seconds,
                reset_at=rate_limit_result.reset_at,
                remaining=0,
                key=rate_limit_result.key,
            )
```

Update `CheckResult` to include `rate_limit_result` so middleware can
inject response headers.

### `enable()` update

When a route is re-enabled (transitions from MAINTENANCE or DISABLED to
ACTIVE), reset its rate limit counters:

```python
async def enable(self, path: str, actor: str = "system") -> RouteState:
    # ... existing enable logic ...

    # Reset rate limit counters so clients aren't penalised
    # for retrying during the maintenance window
    if self._rate_limiter:
        for method in ["GET", "POST", "PUT", "PATCH", "DELETE"]:
            await self._rate_limiter.reset(path=path, method=method)

    return new_state
```

### `_record_rate_limit_hit`

```python
async def _record_rate_limit_hit(
    self,
    path: str,
    policy: RateLimitPolicy,
    result: RateLimitResult,
) -> None:
```

Creates a `RateLimitHit` record and writes it to the backend using a
new `write_rate_limit_hit` method on `ShieldBackend`. Also increments
in-memory counters used by the dashboard analytics.

Wrap in try/except — a failure to record a hit must never affect the
request response.

---

## Module 7 — Exceptions

**File to update:** `shield/core/exceptions.py`

Add:

```python
class RateLimitExceededException(ShieldException):
    def __init__(
        self,
        limit: str,
        retry_after_seconds: int,
        reset_at: datetime,
        remaining: int,
        key: str,
    ):
        self.limit = limit
        self.retry_after_seconds = retry_after_seconds
        self.reset_at = reset_at
        self.remaining = remaining
        self.key = key
        super().__init__(f"Rate limit exceeded: {limit}")

class ShieldProductionWarning(UserWarning):
    """
    Emitted when a configuration is valid but has known limitations
    in production multi-worker deployments. The feature will work
    correctly for single-process deployments.
    """
    pass
```

`ShieldProductionWarning` is a `UserWarning` subclass, not an exception.
It uses Python's standard `warnings.warn` mechanism so users can suppress
it with `warnings.filterwarnings` if they understand and accept the
limitation. Never use `logging.warning` for this — `warnings.warn` is
the correct Python mechanism for "this works but you should know something."

---

## Module 8 — Middleware Update

**File to update:** `shield/fastapi/middleware.py`

### Pass `request` object in context

Update `dispatch` to pass the full `Request` object in the context dict
so the rate limiter can extract keys from headers and state:

```python
result = await self.engine.check(
    path=request.url.path,
    context={
        "ip": request.client.host if request.client else "unknown",
        "headers": dict(request.headers),
        "method": request.method,
        "request": request,          # add this
    }
)
```

### Handle `RateLimitExceededException`

```python
except RateLimitExceededException as e:
    return JSONResponse(
        status_code=429,
        content={
            "error": {
                "code": "RATE_LIMIT_EXCEEDED",
                "message": "Too many requests",
                "limit": e.limit,
                "retry_after_seconds": e.retry_after_seconds,
                "reset_at": e.reset_at.isoformat(),
                "path": request.url.path,
            }
        },
        headers={
            "Retry-After": str(e.retry_after_seconds),
            "X-RateLimit-Limit": e.limit,
            "X-RateLimit-Remaining": "0",
            "X-RateLimit-Reset": str(int(e.reset_at.timestamp())),
        }
    )
```

### Inject headers on passing requests

After `response = await call_next(request)`, inject rate limit headers
if the check result includes rate limit data:

```python
if result.rate_limit_result:
    rl = result.rate_limit_result
    response.headers["X-RateLimit-Limit"] = rl.limit
    response.headers["X-RateLimit-Remaining"] = str(rl.remaining)
    response.headers["X-RateLimit-Reset"] = str(int(rl.reset_at.timestamp()))
```

Inject these headers on every passing response, not just on 429s.
Well-behaved API clients use these headers to back off before being blocked.

---

## Module 9 — Backend ABC Update

**File to update:** `shield/core/backends/base.py`

Add these abstract methods to `ShieldBackend`:

```python
@abstractmethod
async def write_rate_limit_hit(self, hit: RateLimitHit) -> None: ...

@abstractmethod
async def get_rate_limit_hits(
    self,
    path: str | None = None,
    limit: int = 100,
) -> list[RateLimitHit]: ...
```

Implement in all three concrete backends (`MemoryBackend`, `FileBackend`,
`RedisBackend`). For `FileBackend`, this is allowed — storing rate limit
hit logs (for dashboard display) is different from storing live counters
(for enforcement). Hit logs are append-only and never read under
concurrency constraints.

For `RedisBackend`, store hits as a Redis list under key
`shield:ratelimit:hits` using `LPUSH`, capped at 10,000 entries with
`LTRIM` after each write.

---

## Module 10 — Dashboard Update

**File to update:** `shield/dashboard/routes.py` and relevant templates

### Route row update

Each route row in the dashboard already shows status, reason, and
environment. Extend it to show rate limit state when a policy exists:

Add to the route row partial (`route_row.html`) a rate limit badge that
shows when `route_state.rate_limit_policy` is not None:
- Green badge: "100/min" — shows the limit
- Amber badge when remaining < 20% of limit in the current window

### New dashboard endpoint

```
GET /shield/rate-limits
```

Returns a page (or HTMX partial when requested with `HX-Request` header)
showing:
- Table of all routes with rate limit policies
- Columns: Route, Method, Limit, Algorithm, Key Strategy, Hits (last hour),
  Blocked (last hour), Top keys being limited
- Auto-refreshes every 15 seconds via `hx-trigger="every 15s"` on the
  table body

### New API endpoint on parent app (optional mount)

```
GET /shield/api/rate-limits              # all rate limit policies + current state
GET /shield/api/rate-limits/{path}       # single route
DELETE /shield/api/rate-limits/{path}/reset   # reset counters for a route
```



### Navigation update

Add "Rate Limits" tab to the dashboard navigation bar.

---

## Module 11 — CLI Update

**File to update:** `shield/cli/main.py`

Add these commands:

```bash
# Show all rate limit policies and current state
shield rate-limits

# Show rate limit state for a specific route
shield rate-limits /api/payments

# Set a rate limit on a route at runtime (without redeploying)
shield rate-limits set /api/search "1000/hour" --algorithm sliding_window

# Reset counters for a route
shield rate-limits reset /api/payments

# Reset counters for all routes
shield rate-limits reset --all

# Show recent rate limit hits
shield rate-limits log
shield rate-limits log --route /api/payments --limit 50
```

CLI output for `shield rate-limits` should be a rich table with columns:
Route, Method, Limit, Algorithm, Key, Hits/min (live), Blocked/hr.

---

## Module 12 — Tests

**Files to create:**
- `tests/core/rate_limit/test_limiter.py`
- `tests/core/rate_limit/test_storage.py`
- `tests/core/rate_limit/test_keys.py`
- `tests/fastapi/test_rate_limit.py`

### `test_storage.py`

Run the same abstract test suite against `MemoryRateLimitStorage`,
`FileRateLimitStorage`, and `RedisRateLimitStorage` using
`pytest.mark.parametrize`. Use a real Redis instance for Redis tests
(or `fakeredis` for CI).

Tests must cover:
- Counter increments correctly on sequential requests
- Window resets after expiry
- `reset()` clears the counter
- `reset_all_for_path()` clears all keys matching the path
- `FileRateLimitStorage` emits `ShieldProductionWarning` on instantiation
  — use `pytest.warns(ShieldProductionWarning)` to assert this
- `FileRateLimitStorage` correctly enforces limits in a single-process
  test — it must not silently skip enforcement

**Persistence tests for `FileRateLimitStorage` specifically:**

- **Active window survives restart** — increment a counter to 45/100,
  call `flush_snapshot()` directly, create a new `FileRateLimitStorage`
  instance reading the same file, assert counter is restored to 45 and
  the remaining window TTL is correct (within 1 second tolerance)

- **Expired window resets on restart** — increment a counter, write a
  snapshot with a `window_start` backdated beyond the window duration,
  create a new instance reading the same file, assert counter starts
  at 0 (expired window is not restored)

- **Graceful shutdown writes final snapshot** — increment a counter,
  call `shutdown()`, delete the in-memory storage, create a new
  instance, assert counter is correctly restored from the shutdown
  snapshot with no data loss

- **Unclean shutdown loses at most `snapshot_interval_seconds` of data**
  — increment a counter 80 times, wait for one snapshot cycle, increment
  20 more times, simulate crash (create new instance without calling
  `shutdown()`), assert restored counter is between 80 and 100 (the
  snapshot captured the first 80, the last 20 may be lost)

### `test_keys.py`

Tests must cover:
- `extract_ip` correctly parses `X-Forwarded-For` (first IP in list)
- `extract_ip` falls back through `X-Real-IP` to `request.client.host`
- `extract_ip` returns `"unknown"` when no IP available — never raises,
  never returns None
- `extract_user` returns `None` when `user_id` not on request state —
  does NOT fall back to IP (that is `on_missing_key`'s job)
- `extract_api_key` returns `None` when `X-API-Key` header absent —
  does NOT fall back to IP
- `resolve_key_extractor` raises `ValueError` for CUSTOM with no func
- `is_exempt` correctly handles CIDR notation (`"10.0.0.0/24"`)
- `is_exempt` returns False for non-exempt IPs
- `handle_missing_key` with `EXEMPT` returns `(None, EXEMPT)` and
  does not call any storage method
- `handle_missing_key` with `FALLBACK_IP` returns `(ip_string, FALLBACK_IP)`
  where ip_string is the extracted client IP
- `handle_missing_key` with `BLOCK` returns `(None, BLOCK)`
- `handle_missing_key` always emits a `WARNING` log — assert with
  `caplog` fixture regardless of which behaviour fires
- `resolve_on_missing_key` returns correct defaults per strategy:
  USER→EXEMPT, API_KEY→FALLBACK_IP, CUSTOM→EXEMPT

### `test_limiter.py`

Tests must cover:
- `check()` returns `allowed=True` for first N requests within limit
- `check()` returns `allowed=False` on request N+1
- `check()` respects tier limits — free tier blocked at 100, pro at 10000
- `check()` returns `allowed=True` immediately for `"unlimited"` tier
- `check()` returns `allowed=True` for exempt IP without hitting storage
- `reset()` clears counters, next request is allowed
- Counter does not accumulate across algorithm types — each is isolated

### `test_rate_limit.py` (FastAPI integration)

Use `httpx.AsyncClient` with `ASGITransport`. Spin up a test FastAPI app
with `ShieldMiddleware` and routes decorated with `@rate_limit`.

Tests must cover:
- Request within limit → 200 with correct `X-RateLimit-*` headers
- Request exceeding limit → 429 with correct `Retry-After` and body
- `X-RateLimit-Remaining` decrements correctly across sequential requests
- `X-RateLimit-Remaining` header present on every response, not just 429s
- Route with `@maintenance` + `@rate_limit` → 503, no rate limit headers
  (maintenance takes priority, counter does not increment)
- Route with `@deprecated` + `@rate_limit` → 200 with deprecation headers
  AND rate limit headers (both apply)
- Exempt IP bypasses rate limit — 200 even after limit exceeded by others
- Tiered limits: requests with `plan="free"` blocked at 10, `plan="pro"`
  blocked at 1000
- FileBackend emits `ShieldProductionWarning` at engine startup when a
  `@rate_limit` decorated route is registered — use `pytest.warns` to
  assert the warning is raised with the correct message
- FileBackend rate limiting actually works for single-process tests —
  assert that a `@rate_limit("5/minute")` route with FileBackend correctly
  blocks the 6th request (confirming it is not silently skipped)

**`on_missing_key` integration tests — these are required, not optional:**

- `key=USER, on_missing_key=EXEMPT` (default): request with no `user_id`
  on `request.state` → 200, no rate limit headers, WARNING in logs,
  `key_was_missing=True` on internal result. Counter not incremented —
  confirm by sending 1000 requests and asserting none are blocked.

- `key=USER, on_missing_key=FALLBACK_IP`: request with no `user_id` →
  200, rate limit headers present using IP key, WARNING in logs.
  Counter increments against IP. Confirm by sending limit+1 requests
  and asserting the last is blocked with 429.

- `key=USER, on_missing_key=BLOCK`: request with no `user_id` → 429
  immediately, WARNING in logs. Counter not incremented — next request
  (still no user_id) also gets 429, not a different status.

- `key=API_KEY, on_missing_key=FALLBACK_IP` (default): request with no
  `X-API-Key` header → rate limited by IP. Request with `X-API-Key`
  header → rate limited by key value. Both are independent counters —
  exhausting one does not affect the other.

- `key=CUSTOM` with callable that returns `None`: request → EXEMPT by
  default, WARNING in logs.

- Warning message content test: assert the WARNING log for a missing
  USER key contains the route path, the strategy name, the behaviour
  applied, and the text "check that your auth middleware sets" — this
  text is the diagnostic hint and must be present verbatim.

---

## Module 13 — Documentation and README Update

**This module must be completed before the implementation is considered done.**

### README.md updates

Add rate limiting to:
1. The feature list section — new bullet point under the existing feature list,
   noting it requires `pip install api-shield[rate-limit]`
2. The quick start example — show `@rate_limit` alongside `@maintenance`
   and `@env_only` in the 30-second install example, with the optional
   install command shown first
3. The backend comparison table — add "Rate limiting" row showing:
   ✅ Memory (single worker), ⚠️ File (single worker, warns on init), ✅ Redis

### Docs site updates

**Create** `docs/tutorial/rate-limiting.md` with these sections:

**Installation**
Show the two install options clearly at the top:
```bash
pip install api-shield[rate-limit]   # rate limiting only
pip install api-shield[all]          # everything
```
Explain that rate limiting is optional and not bundled by default.

**Basic usage**
Show the simplest possible example — one route, one decorator, run it.
Show what the 429 response looks like. Show the response headers.

**Key strategies and missing key behaviour**

This section must be written with directness. Do not soften the
warnings — developers who misconfigure this will have broken rate
limiting in production with no error to tell them.

Explain each strategy with a code example AND an explicit statement
of what happens when the key cannot be resolved:

```python
# IP — never missing. Safe default for any route.
@rate_limit("100/minute")                           # key=IP is the default
@rate_limit("100/minute", key=RateLimitKeyStrategy.IP)

# USER — requires auth middleware to set request.state.user_id
# DEFAULT on missing: EXEMPT (unauthenticated requests bypass the limit)
@rate_limit("1000/hour", key=RateLimitKeyStrategy.USER)

# ⚠️ IMPORTANT: If your auth middleware does not set request.state.user_id
# before this route runs, ALL requests will be treated as missing-key and
# exempted. Your rate limit will not enforce for anyone. You will see
# WARNING logs — check them.

# To override the default:
@rate_limit(
    "1000/hour",
    key=RateLimitKeyStrategy.USER,
    on_missing_key=OnMissingKey.FALLBACK_IP,   # rate limit unauthenticated by IP
)
@rate_limit(
    "1000/hour",
    key=RateLimitKeyStrategy.USER,
    on_missing_key=OnMissingKey.BLOCK,         # 429 if no user identity
)

# API_KEY — reads X-API-Key header
# DEFAULT on missing: FALLBACK_IP (requests without a key are limited by IP)
@rate_limit("500/minute", key=RateLimitKeyStrategy.API_KEY)

# GLOBAL — one counter for all callers. Never missing.
@rate_limit("10000/hour", key=RateLimitKeyStrategy.GLOBAL)
```

Show the `on_missing_key` table from the models section again here
as a quick reference. Make the documentation self-contained — a
developer reading just this page should not need to go elsewhere to
understand what happens when a key is missing.

**Diagnosing misconfiguration:**

Include a section titled "What to do when rate limiting isn't working."
Explain that the single most common cause is a misconfigured key strategy:

1. Check your logs for `api-shield rate_limit: key strategy ... returned no value` warnings
2. If you see these warnings, your auth middleware is not setting the
   expected attribute before the rate limiter runs
3. Check middleware ordering — the auth middleware must run before
   `ShieldMiddleware` in the middleware stack
4. Either fix the middleware ordering, or set `on_missing_key` explicitly
   to match your actual intent

This section will answer the most common GitHub issue you will receive.
Write it as if you are answering that issue pre-emptively.

**Tiered rate limits**
Full example showing a SaaS API with free/pro/enterprise tiers.
Show how to set `request.state.plan` in an auth dependency so the
tier resolver can read it. This is the most common enterprise use case.

**Algorithm selection**
Explain the tradeoff between fixed window (simple, cheap, bursty at
boundaries) and sliding window (smooth, fair, slightly higher memory).
Recommend sliding window as the default. Mention token bucket for
APIs where short bursts are acceptable.

**Backend selection**

Explain all three backends with their meaningful differences — not just
"use Redis for production" but what each one actually gives you:

```python
# Memory — fastest, single worker, counters lost on restart
# Use for: development, testing, or when you don't care about restart continuity
engine = ShieldEngine(backend=MemoryBackend())

# File — fast, single worker, counters PERSIST across restarts
# Use for: single-process production apps, small deployments, simple ops
# ⚠️ Emits ShieldProductionWarning at startup — this is expected
engine = ShieldEngine(backend=FileBackend(path="state.json"))

# File with faster snapshot interval (default is 10 seconds)
engine = ShieldEngine(
    backend=FileBackend(path="state.json"),
    rate_limit_snapshot_interval=5,
)

# Redis — multi-worker safe, multi-instance, persistent, atomic
# Use for: any deployment with more than one worker
engine = ShieldEngine(backend=RedisBackend(url="redis://localhost"))

# Dedicated rate limit backend — route state in file, rate limits in Redis
# Use for: teams who want version-controlled route state but Redis enforcement
engine = ShieldEngine(
    backend=FileBackend(path="state.json"),
    rate_limit_backend=RedisBackend(url="redis://localhost"),
)
```

Explain the window-aware snapshot restoration for FileBackend — this
is the key differentiator from MemoryBackend and worth explaining with
a concrete example:

> A client has used 80 of their 100 daily requests. Your server
> restarts for a deploy. Without persistence, the counter resets to 0
> and the client gets a free 100 more requests they shouldn't have.
> With FileBackend, the counter is restored to 80 — the client's
> remaining quota is preserved across your restart.

Explain the `snapshot_interval_seconds` tradeoff and when to adjust it.

**Exemptions**
Show IP-based and role-based exemption. Explain the CIDR notation support.
Give a practical example: exempting internal monitoring services and
admin users from rate limits.

**Integration with other shield features**
Explain the check ordering explicitly:
1. Maintenance/disabled → 503, counter does not increment
2. Circuit open → 503, counter does not increment
3. Rate limit → 429 if exceeded, counter increments on every attempt
4. Deprecated → passes through, counter increments, deprecation headers added

Explain that counters reset when a route comes back from maintenance
so clients are not penalised for retrying during the maintenance window.

**Migration from slowapi**
Side-by-side comparison showing equivalent slowapi and api-shield code.
Explain that the underlying `limits` library is shared, so storage
backends are compatible. Show how to migrate one route at a time.

**Update** `docs/reference/decorators.md` — add `@rate_limit` with
full parameter documentation, type signatures, and examples.

**Update** `docs/reference/engine.md` — document the `rate_limit_backend`
constructor parameter and `register_rate_limit` method.

**Update** `docs/backends.md` — update the capability matrix table.
Rate limiting must show the correct status per backend:

| Feature | Memory | File | Redis |
|---|---|---|---|
| Rate limiting | ✅ single worker | ✅ single worker + persistent | ✅ multi-worker |
| Persists across restarts | ❌ | ✅ (snapshot, configurable interval) | ✅ |
| Multi-worker safe | ❌ | ❌ | ✅ |
| Atomic counter ops | ❌ | ❌ | ✅ |

**Update** `docs/changelog.md` under unreleased with this changes

---

## Acceptance Criteria

The implementation is complete when all of the following are true:

- `pip install api-shield` with no rate limiting configured works with
  zero dependency on the `limits` library — verify with a fresh venv
- `pip install api-shield[rate-limit]` and the README quick start example
  runs end-to-end with rate limiting working
- A route decorated with `@rate_limit("5/minute")` correctly blocks the 6th
  request within a minute and returns a valid 429 response
- Configuring `@rate_limit` without `pip install api-shield[rate-limit]`
  raises a clear `ImportError` with the correct install command — never
  a confusing `ModuleNotFoundError` or silent skip
- `X-RateLimit-Remaining` header decrements correctly on every request
  and is present on all responses from rate-limited routes, not just 429s
- A route with both `@maintenance` and `@rate_limit` returns 503 during
  maintenance and the rate limit counter does not increment
- A route with both `@deprecated` and `@rate_limit` returns 200 with both
  deprecation headers and rate limit headers present
- Tiered limits work correctly — a request with `plan="free"` on
  `request.state` is blocked at the free tier limit, not the pro limit
- `on_missing_key` behaviour is correct for all three values — EXEMPT
  bypasses with no counter increment, FALLBACK_IP uses IP and increments,
  BLOCK returns 429 with no counter increment
- Missing key always produces a WARNING log with the route path, strategy,
  and the diagnostic hint about checking auth middleware
- Per-strategy defaults are correct: USER→EXEMPT, API_KEY→FALLBACK_IP,
  CUSTOM→EXEMPT — no silent fallback to IP for USER strategy
- `FileBackend` persistence: a counter at 45/100 survives a simulated
  restart within the active window and is restored correctly to 45
- `FileBackend` persistence: a counter in an expired window resets to 0
  on restart — stale data is never restored
- `FileBackend` graceful shutdown: calling `shutdown()` flushes a final
  snapshot and the subsequent instance restores with zero data loss
- `RedisBackend` rate limiting is correct under simulated concurrent requests
  (no counter races in tests using concurrent asyncio tasks)
- The dashboard "Rate Limits" tab renders and shows correct state
- `shield rate-limits` CLI command produces formatted table output
- All documentation sections listed in Module 13 are written and accurate
- `shield.core` has zero FastAPI/Starlette imports after this change — verify
  explicitly with a grep or import check in CI

