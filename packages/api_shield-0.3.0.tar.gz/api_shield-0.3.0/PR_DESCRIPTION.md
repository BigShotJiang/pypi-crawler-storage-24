# Rate Limiting

Adds full rate limiting support to api-shield.

## What's new

**`@rate_limit` decorator**

- Limit requests per IP, user, API key, or globally with a single decorator
- Tiered limits (`{"free": "10/min", "pro": "100/min"}`) resolved from request state
- Burst allowance, exempt IPs, exempt roles
- Custom 429 response factory — per-route via `response=` or app-wide via `ShieldMiddleware(responses={"rate_limited": ...})`
- Works as `Depends()` without middleware
- Sync and async custom key functions supported

**Algorithms** — `fixed_window`, `sliding_window`, `moving_window`, `token_bucket` (via [limits](https://limits.readthedocs.io/en/stable/) >= 5.8.0)

**Storage** — auto-selected from the active backend: `MemoryRateLimitStorage`, `FileRateLimitStorage`, `RedisRateLimitStorage`. Pass `rate_limit_backend=` to use a different backend for counters.

**Dashboard** — Rate Limits tab at `/shield/rate-limits` with reset, edit, delete actions. Blocked requests log at `/shield/blocked`.

**CLI** — `shield rl list|set|reset|delete|hits` (`shield rate-limits` is an alias).

**Audit log** — policy changes recorded with action badges: `set`, `update`, `reset`, `delete`.

**Response headers** — `X-RateLimit-Limit`, `X-RateLimit-Remaining`, `X-RateLimit-Reset` on every request; `Retry-After` on 429s.

## Other changes

- `mypy --strict` passes across all 36 source files
- `ruff check` passes with no errors
- `limits` version constraint updated to `>=5.8.0`
- Dependency injection example corrected — decorator and `Depends()` are mutually exclusive patterns, not combined
- Full documentation added: rate limiting tutorial, reference, and updates to all relevant pages (README, adapters, CLI, dashboard, backends, changelog)
