# MemoryX ServerSDK

Server-side SDK for MemoryX API operations.

## Installation

```bash
pip install memoryx_serversdk
```

## Quick Start

```python
from memoryx_serversdk import MemoryxServerSDK

sdk = MemoryxServerSDK()

# Send memories with explicit API key
result = sdk.send_memories(
    api_key="your_api_key_here",
    memories=[
        {"content": "User prefers dark theme", "metadata": {"category": "semantic"}}
    ]
)

# Search memories
results = sdk.search(
    api_key="your_api_key_here",
    query="preferences"
)

# List memories
memories = sdk.list(
    api_key="your_api_key_here",
    limit=50
)

# Delete a memory
sdk.delete(
    api_key="your_api_key_here",
    memory_id="memory_id_here"
)
```

## Key Differences from Client SDK

| Feature | Client SDK | ServerSDK |
|---------|-----------|-----------|
| API Key Storage | Auto-saved locally | Explicit per-request |
| Registration | Auto-register | Manual via portal |
| Use Case | Single user/client | Server-side operations |

## API Reference

### MemoryxServerSDK

Main class for MemoryX server-side operations.

#### Constructor

```python
sdk = MemoryxServerSDK(api_base_url="https://memoryx.cloud/api")
```

#### Methods

| Method | Description |
|--------|-------------|
| `send_memories(api_key, memories)` | Send single or batch memories |
| `send_conversation(api_key, conversation_id, messages)` | Send conversation for extraction |
| `search(api_key, query, limit, ...)` | Search memories by semantic similarity |
| `list(api_key, limit, offset, ...)` | List memories by creation time |
| `delete(api_key, memory_id)` | Delete a memory |
| `get_task_status(api_key, task_id)` | Get async task status |
| `get_quota(api_key)` | Get quota information |
| `verify_api_key(api_key)` | Verify API key validity |

### MemoryxServerSDKError

Exception class for ServerSDK errors.

## License

MIT License - see LICENSE file for details.
