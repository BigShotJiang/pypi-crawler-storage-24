from setuptools import setup, find_packages

setup(
    name="memoryx_serversdk",
    version="1.0.1",
    description="MemoryX ServerSDK - Server-side SDK for MemoryX API",
    author="MemoryX Team",
    author_email="contact@memoryx.cloud",
    url="https://github.com/t0ken-ai/MemoryX",
    packages=find_packages(where="src"),
    package_dir={"": "src"},
    python_requires=">=3.8",
    install_requires=[],
    extras_require={
        "dev": [
            "twine>=3.0.0",
            "wheel>=0.37.0",
            "build>=0.10.0",
        ],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Software Development :: Libraries :: Python Modules",
    ],
    keywords="memoryx memory sdk api server",
)
