"""
MemoryX ServerSDK - Server-side SDK for MemoryX API
Supports operations with explicit API key authentication per request.
"""

import json
import time
from typing import Optional, List, Dict, Any


class MemoryxServerSDKError(Exception):
    """MemoryX ServerSDK Error"""
    pass


class MemoryxServerSDK:
    """
    MemoryX Server-side SDK

    Unlike the client SDK which auto-registers and stores api_key,
    MemoryxServerSDK requires explicit api_key parameter for each operation.

    All operations are scoped to the api_key owner.
    """

    DEFAULT_API_BASE = "https://memoryx.cloud/api"

    def __init__(self, api_base_url: Optional[str] = None):
        """
        Initialize MemoryxServerSDK

        Args:
            api_base_url: API base URL (default: https://memoryx.cloud/api)
        """
        self.api_base_url = api_base_url or self.DEFAULT_API_BASE

    def _request(
        self,
        method: str,
        endpoint: str,
        api_key: str,
        data: Optional[dict] = None
    ) -> dict:
        """
        Send HTTP request with API key authentication

        Args:
            method: HTTP method (GET, POST, DELETE, etc.)
            endpoint: API endpoint path
            api_key: API key for authentication
            data: Optional request body

        Returns:
            Response dict
        """
        from urllib.request import Request, urlopen
        from urllib.error import HTTPError

        url = f"{self.api_base_url}{endpoint}"
        headers = {
            "Content-Type": "application/json",
            "User-Agent": "memoryx-serversdk-python/1.0.0",
            "X-API-Key": api_key
        }

        req = Request(
            url,
            data=json.dumps(data).encode() if data else None,
            headers=headers,
            method=method
        )

        try:
            with urlopen(req, timeout=30) as response:
                return json.loads(response.read().decode())
        except HTTPError as e:
            error_body = e.read().decode()
            try:
                error_data = json.loads(error_body)
                raise MemoryxServerSDKError(
                    error_data.get("detail", error_data.get("message", f"HTTP {e.code}"))
                )
            except json.JSONDecodeError:
                raise MemoryxServerSDKError(f"HTTP {e.code}: {error_body}")
        except Exception as e:
            raise MemoryxServerSDKError(f"Request failed: {str(e)}")

    def send_memories(
        self,
        api_key: str,
        memories: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Send memories (single or batch)

        Args:
            api_key: API key for authentication
            memories: List of memory dicts, each with:
                - content: Memory content (required)
                - metadata: Optional metadata dict with category etc.

        Returns:
            {"success": True, "task_id": "...", "status": "..."}
        """
        if not api_key:
            raise MemoryxServerSDKError("api_key is required")

        if not memories:
            return {"success": True}

        if len(memories) == 1:
            data = {
                "content": memories[0]["content"],
                "metadata": memories[0].get("metadata", {})
            }
            result = self._request("POST", "/v1/memories", api_key, data)
        else:
            data = {"memories": memories}
            result = self._request("POST", "/v1/memories/batch", api_key, data)

        return {
            "success": True,
            "task_id": result.get("task_id"),
            "status": result.get("status")
        }

    def send_conversation(
        self,
        api_key: str,
        conversation_id: str,
        messages: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Send conversation messages for memory extraction

        Args:
            api_key: API key for authentication
            conversation_id: Unique conversation ID
            messages: List of message dicts with:
                - role: "user" or "assistant"
                - content: Message content
                - timestamp: Optional timestamp (ms)
                - tokens: Optional token count

        Returns:
            {"success": True, "task_id": "...", "status": "..."}
        """
        if not api_key:
            raise MemoryxServerSDKError("api_key is required")

        if not messages:
            return {"success": True}

        formatted_messages = []
        for m in messages:
            formatted_messages.append({
                "role": m["role"],
                "content": m["content"],
                "timestamp": m.get("timestamp", int(time.time() * 1000)),
                "tokens": m.get("tokens", 0)
            })

        data = {
            "conversation_id": conversation_id,
            "messages": formatted_messages
        }

        result = self._request("POST", "/v1/conversations/flush", api_key, data)

        return {
            "success": True,
            "task_id": result.get("task_id"),
            "status": result.get("status")
        }

    def search(
        self,
        api_key: str,
        query: str,
        limit: int = 10,
        time_filter: Optional[Dict[str, str]] = None,
        categories: Optional[List[str]] = None,
        tags: Optional[List[str]] = None,
        is_project_level: Optional[bool] = None,
    ) -> Dict[str, Any]:
        """
        Search memories by semantic similarity

        Args:
            api_key: API key for authentication
            query: Search query
            limit: Maximum results (default: 10)
            time_filter: Optional {"start": "YYYY-MM-DD HH:mm:ss", "end": "..."}
            categories: Optional list of category filter
            tags: Optional list of tag filter
            is_project_level: Optional

        Returns:
            {"success": True, "data": [...], "related_memories": [...], "remaining_quota": ...}
        """
        if not api_key:
            raise MemoryxServerSDKError("api_key is required")

        data = {"query": query, "limit": limit}
        if time_filter:
            data["time_filter"] = time_filter
        if categories:
            data["categories"] = categories
        if tags:
            data["tags"] = tags
        if is_project_level is not None:
            data["is_project_level"] = is_project_level

        result = self._request("POST", "/v1/memories/search", api_key, data)

        formatted_data = []
        for m in result.get("data", []):
            formatted_data.append({
                "id": m.get("id"),
                "content": m.get("memory") or m.get("content"),
                "category": m.get("category", "other"),
                "score": m.get("score", 0.5)
            })

        related = []
        for m in result.get("related_memories", []):
            related.append({
                "id": m.get("id"),
                "content": m.get("memory") or m.get("content"),
                "category": m.get("category", "other"),
                "score": m.get("score", 0)
            })

        return {
            "success": True,
            "data": formatted_data,
            "related_memories": related,
            "remaining_quota": result.get("remaining_quota")
        }

    def list(
        self,
        api_key: str,
        limit: int = 50,
        offset: int = 0,
        time_filter: Optional[Dict[str, str]] = None,
        categories: Optional[List[str]] = None,
        tags: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """
        List recent memories by creation time (newest first)

        Args:
            api_key: API key for authentication
            limit: Maximum results (default: 50)
            offset: Pagination offset (default: 0)
            time_filter: Optional {"start": "YYYY-MM-DD HH:mm:ss", "end": "..."}
            categories: Optional list of category filter
            tags: Optional list of tag filter

        Returns:
            {"success": True, "data": [...], "total": N}
        """
        if not api_key:
            raise MemoryxServerSDKError("api_key is required")

        params = [f"limit={limit}", f"offset={offset}"]
        if time_filter:
            if time_filter.get("start"):
                params.append(f"time_start={time_filter['start']}")
            if time_filter.get("end"):
                params.append(f"time_end={time_filter['end']}")
        if categories:
            params.append("categories=" + ",".join(categories))
        if tags:
            params.append("tags=" + ",".join(tags))

        result = self._request(
            "GET",
            f"/v1/memories/list?{'&'.join(params)}",
            api_key
        )

        formatted_data = []
        for m in result.get("data", []):
            formatted_data.append({
                "id": m.get("id"),
                "content": m.get("memory") or m.get("content"),
                "category": m.get("category", "other"),
                "score": 0
            })

        return {
            "success": True,
            "data": formatted_data,
            "total": result.get("total", 0)
        }

    def delete(
        self,
        api_key: str,
        memory_id: str
    ) -> Dict[str, Any]:
        """
        Delete a memory

        Args:
            api_key: API key for authentication
            memory_id: Memory ID to delete

        Returns:
            {"success": True}
        """
        if not api_key:
            raise MemoryxServerSDKError("api_key is required")

        self._request("DELETE", f"/v1/memories/{memory_id}", api_key)
        return {"success": True}

    def get_task_status(
        self,
        api_key: str,
        task_id: str
    ) -> Dict[str, Any]:
        """
        Get async task status

        Args:
            api_key: API key for authentication
            task_id: Task ID returned from send_memories/send_conversation

        Returns:
            {
                "task_id": "...",
                "status": "PENDING|STARTED|SUCCESS|FAILURE",
                "result": {...}
            }
        """
        if not api_key:
            raise MemoryxServerSDKError("api_key is required")

        return self._request("GET", f"/v1/memories/task/{task_id}", api_key)

    def get_quota(self, api_key: str) -> Dict[str, Any]:
        """
        Get quota information

        Args:
            api_key: API key for authentication

        Returns:
            Quota info dict
        """
        if not api_key:
            raise MemoryxServerSDKError("api_key is required")

        return self._request("GET", "/v1/quota", api_key)

    def verify_api_key(self, api_key: str) -> Dict[str, Any]:
        """
        Verify if an API key is valid and get its info

        Args:
            api_key: API key to verify

        Returns:
            {"valid": True, "owner": "...", "quota": {...}}
        """
        if not api_key:
            raise MemoryxServerSDKError("api_key is required")

        try:
            quota = self.get_quota(api_key)
            return {
                "valid": True,
                "quota": quota
            }
        except MemoryxServerSDKError as e:
            return {
                "valid": False,
                "error": str(e)
            }
