# -*- coding: utf-8 -*-
"""
    __author__ = 'Zehra Sarica'
    __email__ = ['sarica16@itu.edu.tr','zehraacar559@gmail.com']
"""

# Admissible pre-release markers:
#   X.YaN   # Alpha release
#   X.YbN   # Beta release
#   X.YrcN  # Release Candidate
#   X.Y     # Final release
#
# Dev branch marker is: 'X.Y.dev' or 'X.Y.devN' where N is an integer.
# 'X.Y.dev0' is the canonical version of 'X.Y.dev'
#

__version__ = "0.2.2"
__author__ = "Zehra Sarica <zehraacar559@gmail.com, sarica16@itu.edu.tr>"

import rinpy.logging_config

from rinpy.rin_process import RINProcess
from rinpy.network_comparator import NetworkComparator

__all__ = ["RINProcess", "NetworkComparator"]
