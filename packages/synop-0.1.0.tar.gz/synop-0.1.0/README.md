![Synop](logo.png)
# synop

**synop** is a uv-first CLI utility that generates structured video descriptions using OpenAI-compatible vision APIs (OpenRouter by default).

It samples key frames across your video timeline, combines them with technical media metadata, and writes generated output as JSON, plaintext, or Jinja-rendered BBCode.

![Python >=3.10](https://img.shields.io/badge/python-3.10%2B-blue)
![OpenAI Compatible](https://img.shields.io/badge/provider-OpenAI%20compatible-green)

## Features

- Smart frame sampling based on runtime length (4/8/12 frames)
- Metadata extraction (duration, resolution, codec)
- OpenRouter by default, with configurable OpenAI-compatible API base URL
- Persistent API key storage in user settings
- Custom output templates with Jinja2

## Installation

```bash
uv tool install synop-cli
```

## Quick Start

1) Save your API key once:

```bash
synop config set-key
```

2) Generate a description:

```bash
synop "path/to/video.mp4"
```

This writes `video_name_desc.json` next to the source video.

## Usage

```bash
synop "path/to/video.mp4" [OPTIONS]
```

Options:

- `-m, --model` Model ID (default: `x-ai/grok-4.20-beta`)
- `--api-base-url` OpenAI-compatible API base URL (default: `https://openrouter.ai/api/v1`)
- `-f, --format` Output format: `json` (default), `plaintext`, `bbcode`
- `-t, --template` Path to custom `.j2` or `.txt` template (only used with `--format bbcode`)
- `-o, --output` Output path for generated description
- `--thumb` Thumbnail URL/path to inject into `{{ video_thumb }}`
- `--generate-thumbnail` Generate thumby-style thumbnail sheet image
- `--thumbnail-output` Output path for generated thumbnail sheet
- `--screens-dir` Directory to save thumby-grid extracted screen images
- `--thumb-rows` Rows in thumbnail/screen grid (default: `9`)
- `--thumb-cols` Columns in thumbnail/screen grid (default: `3`)
- `--thumb-width` Grid tile width in pixels (default: `400`)
- `--thumb-skip` Seconds to skip from start for grid extraction (default: `10.0`)
- `--thumb-quality` JPEG quality for thumbnail/screens (default: `95`)

## Output Formats

By default, synop writes JSON output:

```json
{
  "title": "...",
  "short_summary": "...",
  "generated_description": "...",
  "duration": "01:42:33",
  "full_resolution": "1920x1080",
  "short_resolution": "1080p",
  "codec": "H.264",
  "video_thumb": ""
}
```

Use `--format plaintext` to write plain text output.

Use `--format bbcode` to render Jinja templates (defaults to bundled `example.j2` if `--template` is not set).

When thumbnail/screens generation is enabled, JSON output also includes:

- `thumbnail_path` (when `--generate-thumbnail` is used)
- `screens_dir`, `screens_count`, `screens` (when `--screens-dir` is used)

## Thumbnail and Screens

Generate a thumby-style thumbnail sheet:

```bash
synop "path/to/video.mp4" --generate-thumbnail
```

Save thumby-grid extracted frames into a screens folder:

```bash
synop "path/to/video.mp4" --screens-dir "./screens"
```

Generate both thumbnail and screens with custom grid settings:

```bash
synop "path/to/video.mp4" --generate-thumbnail --screens-dir "./screens" --thumb-rows 6 --thumb-cols 4 --thumb-width 360
```

Notes:

- `--screens-dir` always saves the thumby-grid frames (`rows * cols`) with ordered filenames.
- By default, saved screens are resized to 50% of the original video dimensions.
- When `--generate-thumbnail` is used and `--thumb` is not set, `video_thumb` is auto-filled with the generated thumbnail path.

## API Key Resolution

Synop resolves the key in this order:

1. `SYNOP_API_KEY` environment variable
2. Persisted settings file

## API Provider

By default, synop calls OpenRouter (`https://openrouter.ai/api/v1`).

You can point synop to another OpenAI-compatible endpoint:

```bash
synop "path/to/video.mp4" --api-base-url "https://your-provider.example/v1" --model "your-vision-model"
```

Settings path:

- Windows: `%APPDATA%\synop\settings.json`
- Linux/macOS: `$XDG_CONFIG_HOME/synop/settings.json` or `~/.config/synop/settings.json`

## Example BBCode Template

The previous default BBCode output is now provided as an example Jinja template in `src/synop/templates/example.j2`:

```text
[cast]
[font=Arial Black][size=4]{{ title }}[/size][/font]
{{ short_summary }}

[info]
[b]Duration:[/b] {{ duration }}
[b]Resolution:[/b] {{ full_resolution }} ({{ short_resolution }})
[b]Codec:[/b] {{ codec }}

[plot]
{{ generated_description }}

[screens]
[img]{{ video_thumb }}[/img]
```

Use it directly:

```bash
synop "path/to/video.mp4" --format bbcode --template src/synop/templates/example.j2
```

Template variables available in Jinja context:

- `title`
- `short_summary`
- `generated_description`
- `duration`
- `full_resolution`
- `short_resolution`
- `codec`
- `video_thumb`

## Requirements

- Python 3.10+
- FFmpeg runtime libraries (required by `av`)
