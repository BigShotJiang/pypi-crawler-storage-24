from __future__ import annotations

import asyncio
import os
import sys
from pathlib import Path
from typing import Literal, Optional

import typer
from rich.console import Console
from rich.progress import BarColumn, Progress, SpinnerColumn, TextColumn
from rich.text import Text

from . import __version__
from .ai_client import (
    DEFAULT_MODEL,
    OPENROUTER_BASE_URL,
    OpenRouterClient,
    OpenRouterError,
)
from .formatter import (
    render_json_output,
    render_plaintext_output,
    render_template_output,
)
from .settings import (
    clear_api_key,
    load_settings,
    resolve_api_key,
    set_api_key,
    settings_path,
)
from .thumbnailer import Thumbnailer, ThumbnailerParams
from .video import (
    build_sample_timestamps,
    determine_sample_count,
    extract_sample_jpegs,
    read_video_metadata,
)

ASCII_LOGO = r"""

╱╭━━━╮╱╭╮╱╱╭╮╱╭━╮╱╭╮╱╭━━━╮╱╭━━━╮
╱┃╭━╮┃╱┃╰╮╭╯┃╱┃┃╰╮┃┃╱┃╭━╮┃╱┃╭━╮┃
╱┃╰━━╮╱╰╮╰╯╭╯╱┃╭╮╰╯┃╱┃┃╱┃┃╱┃╰━╯┃
╱╰━━╮┃╱╱╰╮╭╯╱╱┃┃╰╮┃┃╱┃┃╱┃┃╱┃╭━━╯
╱┃╰━╯┃╱╱╱┃┃╱╱╱┃┃╱┃┃┃╱┃╰━╯┃╱┃┃╱╱╱
╱╰━━━╯╱╱╱╰╯╱╱╱╰╯╱╰━╯╱╰━━━╯╱╰╯╱╱╱

"""


def print_logo() -> None:
    console = Console()
    lines = ASCII_LOGO.strip("\n").split("\n")
    start_color = (0, 190, 155)
    end_color = (60, 90, 180)

    try:
        console.print(Text("\n"))
        for i, line in enumerate(lines):
            t = i / (len(lines) - 1) if len(lines) > 1 else 0
            r = int(start_color[0] + (end_color[0] - start_color[0]) * t)
            g = int(start_color[1] + (end_color[1] - start_color[1]) * t)
            b = int(start_color[2] + (end_color[2] - start_color[2]) * t)
            console.print(Text(line, style=f"rgb({r},{g},{b})"))
    except UnicodeEncodeError:
        return


app = typer.Typer(
    help="""
    Generate structured, AI-powered video descriptions.

    [bold]Primary Usage:[/bold]
    [green]synop "path/to/video.mp4" [OPTIONS][/green]

    [bold]API Key Setup:[/bold]
    Before first use, set your API key:
    [green]synop config set-key[/green]

    By default synop uses OpenRouter. You can pass another OpenAI-compatible API with --api-base-url.
    API key is read from [cyan]SYNOP_API_KEY[/cyan] or saved settings.
    """,
    pretty_exceptions_show_locals=False,
    rich_markup_mode="rich",
    no_args_is_help=True,
)

config_app = typer.Typer(help="Manage Synop settings and API keys.")


def version_callback(value: bool) -> None:
    if not value:
        return
    print_logo()
    typer.echo(f"synop {__version__}")
    raise typer.Exit()


@app.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    video_path: Optional[Path] = typer.Argument(
        None, help="Path to the video file.", show_default=False
    ),
    model: str = typer.Option(
        DEFAULT_MODEL,
        "--model",
        "-m",
        help="Model ID (must support image input).",
    ),
    api_base_url: str = typer.Option(
        OPENROUTER_BASE_URL,
        "--api-base-url",
        help="OpenAI-compatible API base URL (default: OpenRouter).",
    ),
    template: Optional[Path] = typer.Option(
        None,
        "--template",
        "-t",
        help="Path to custom Jinja2 template file (used with --format bbcode).",
    ),
    output: Optional[Path] = typer.Option(
        None, "--output", "-o", help="Output path for generated description."
    ),
    output_format: Literal["json", "plaintext", "bbcode"] = typer.Option(
        "json",
        "--format",
        "-f",
        help="Output format: json, plaintext, or bbcode.",
    ),
    thumb: str = typer.Option(
        "", "--thumb", help="Thumbnail URL or path to include in template output."
    ),
    generate_thumbnail: bool = typer.Option(
        False,
        "--generate-thumbnail",
        help="Generate a thumby-style thumbnail sheet image.",
    ),
    thumbnail_output: Optional[Path] = typer.Option(
        None,
        "--thumbnail-output",
        help="Output path for generated thumbnail sheet image.",
    ),
    screens_dir: Optional[Path] = typer.Option(
        None,
        "--screens-dir",
        help="Directory to save thumby-grid extracted screen images.",
    ),
    thumb_rows: int = typer.Option(
        9, "--thumb-rows", help="Rows used for thumbnail/screen grid extraction."
    ),
    thumb_cols: int = typer.Option(
        3, "--thumb-cols", help="Columns used for thumbnail/screen grid extraction."
    ),
    thumb_width: int = typer.Option(
        400,
        "--thumb-width",
        help="Tile width in pixels used for thumbnail/screen extraction.",
    ),
    thumb_skip: float = typer.Option(
        10.0,
        "--thumb-skip",
        help="Seconds to skip from start for thumbnail/screen extraction.",
    ),
    thumb_quality: int = typer.Option(
        95,
        "--thumb-quality",
        help="JPEG quality for thumbnail sheet and saved screens (1-100).",
    ),
    version: Optional[bool] = typer.Option(
        None,
        "--version",
        help="Show version and exit.",
        callback=version_callback,
        is_eager=True,
    ),
) -> None:
    """
    Generate a structured description for a video file using OpenRouter vision models.
    """
    if ctx.invoked_subcommand is not None:
        return

    if video_path is None:
        # This part might not be hit if no_args_is_help=True is set on Typer,
        # but it's good for safety.
        print_logo()
        typer.echo(ctx.get_help())
        raise typer.Exit()

    if not video_path.exists() or not video_path.is_file():
        typer.secho(f"Error: Video file not found: {video_path}", fg=typer.colors.RED)
        raise typer.Exit(code=1)

    if template is not None and output_format != "bbcode":
        typer.secho(
            "Error: --template can only be used with --format bbcode.",
            fg=typer.colors.RED,
        )
        raise typer.Exit(code=1)

    if thumb_rows <= 0 or thumb_cols <= 0:
        typer.secho(
            "Error: --thumb-rows and --thumb-cols must be positive.",
            fg=typer.colors.RED,
        )
        raise typer.Exit(code=1)

    if thumb_width <= 0:
        typer.secho("Error: --thumb-width must be positive.", fg=typer.colors.RED)
        raise typer.Exit(code=1)

    if thumb_quality < 1 or thumb_quality > 100:
        typer.secho(
            "Error: --thumb-quality must be between 1 and 100.", fg=typer.colors.RED
        )
        raise typer.Exit(code=1)

    print_logo()

    if output is None:
        suffix = ".json" if output_format == "json" else ".txt"
        output = video_path.with_name(f"{video_path.stem}_desc{suffix}")

    api_key = resolve_api_key()
    if not api_key:
        typer.secho(
            "Missing API key. Set SYNOP_API_KEY or run: synop config set-key",
            fg=typer.colors.RED,
        )
        raise typer.Exit(code=1)

    try:
        metadata = read_video_metadata(video_path)
        sample_count = determine_sample_count(metadata.duration_seconds)
        timestamps = build_sample_timestamps(metadata.duration_seconds, sample_count)
        thumbnail_path: Path | None = None
        saved_screens_dir: Path | None = None
        saved_screens: list[str] = []

        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
            TextColumn("({task.completed}/{task.total})"),
        ) as progress:
            extract_task = progress.add_task(
                "Extracting sample frames", total=sample_count
            )

            def progress_callback(done: int, total: int) -> None:
                progress.update(extract_task, completed=done, total=total)

            frame_jpegs = extract_sample_jpegs(
                video_path,
                timestamps,
                max_dimension=1024,
                jpeg_quality=60,
                progress_callback=progress_callback,
            )

            ai_task = progress.add_task("Generating AI description", total=1)
            ai_client = OpenRouterClient(
                api_key=api_key,
                model=model,
                api_base_url=api_base_url,
            )
            result = asyncio.run(ai_client.generate_description(frame_jpegs))
            progress.update(ai_task, completed=1)

            should_build_grid_artifacts = generate_thumbnail or screens_dir is not None
            if should_build_grid_artifacts:
                thumbnailer = Thumbnailer(
                    ThumbnailerParams(
                        rows=thumb_rows,
                        columns=thumb_cols,
                        tile_width=thumb_width,
                        skip_seconds=thumb_skip,
                        jpeg_quality=thumb_quality,
                    )
                )
                grid_total = thumb_rows * thumb_cols
                grid_task = progress.add_task(
                    "Extracting thumbnail grid frames", total=grid_total
                )

                def grid_progress_callback(done: int, total: int) -> None:
                    progress.update(grid_task, completed=done, total=total)

                grid_frames = thumbnailer.extract_grid_frames(
                    video_path,
                    metadata=metadata,
                    scale_width=None if screens_dir is not None else thumb_width,
                    progress_callback=grid_progress_callback,
                )

                if screens_dir is not None:
                    saved_screens_dir = screens_dir
                    saved_paths = thumbnailer.save_frames_with_size(
                        grid_frames,
                        saved_screens_dir,
                        target_size=thumbnailer.default_screens_size(metadata),
                    )
                    saved_screens = [str(path) for path in saved_paths]

                if generate_thumbnail:
                    if thumbnail_output is None:
                        thumbnail_output = video_path.with_name(
                            f"{video_path.stem}_preview.jpg"
                        )
                    thumbnailer.save_preview_sheet(
                        video_path,
                        thumbnail_output,
                        frames=grid_frames,
                        metadata=metadata,
                    )
                    thumbnail_path = thumbnail_output

        context: dict[str, object] = {
            "title": result.title,
            "short_summary": result.short_summary,
            "duration": metadata.duration_text,
            "full_resolution": metadata.full_resolution,
            "short_resolution": metadata.short_resolution,
            "codec": metadata.codec,
            "generated_description": result.generated_description,
            "video_thumb": thumb,
        }

        if thumbnail_path is not None:
            context["thumbnail_path"] = str(thumbnail_path)
            if not thumb:
                context["video_thumb"] = str(thumbnail_path)

        if saved_screens_dir is not None:
            context["screens_dir"] = str(saved_screens_dir)
            context["screens_count"] = len(saved_screens)
            context["screens"] = saved_screens

        if output_format == "json":
            rendered = render_json_output(context=context)
        elif output_format == "plaintext":
            rendered = render_plaintext_output(context=context)
        else:
            rendered = render_template_output(context=context, template_path=template)

        output.write_text(rendered, encoding="utf-8")

        typer.secho(f"\nSuccess! Description saved to: {output}", fg=typer.colors.GREEN)
        if thumbnail_path is not None:
            typer.secho(
                f"Thumbnail sheet saved to: {thumbnail_path}", fg=typer.colors.GREEN
            )
        if saved_screens_dir is not None:
            typer.secho(
                f"Saved {len(saved_screens)} screens to: {saved_screens_dir}",
                fg=typer.colors.GREEN,
            )
    except OpenRouterError as exc:
        typer.secho(f"\nAPI error: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1)
    except Exception as exc:
        typer.secho(f"\nError: {exc}", fg=typer.colors.RED)
        raise typer.Exit(code=1)


@config_app.command("set-key")
def config_set_key(
    api_key: Optional[str] = typer.Argument(None, help="API key to store."),
) -> None:
    """Persist API key in Synop settings."""
    key = api_key
    if not key:
        key = typer.prompt("API key", hide_input=True)

    try:
        saved_path = set_api_key(key)
    except ValueError as exc:
        typer.secho(str(exc), fg=typer.colors.RED)
        raise typer.Exit(code=1)

    typer.secho(f"Saved API key to: {saved_path}", fg=typer.colors.GREEN)


@config_app.command("clear-key")
def config_clear_key() -> None:
    """Remove persisted API key from Synop settings."""
    saved_path = clear_api_key()
    typer.secho(f"Cleared saved API key in: {saved_path}", fg=typer.colors.GREEN)


@config_app.command("show-settings")
def config_show_settings() -> None:
    """Display settings file location and key source hints."""
    path = settings_path()
    env_key = bool(os.getenv("SYNOP_API_KEY"))
    saved_key = bool(load_settings().api_key)
    if env_key:
        key_source = "SYNOP_API_KEY environment variable"
    else:
        key_source = "saved settings file" if saved_key else "not configured"

    typer.echo(f"Settings file: {path}")
    typer.echo(f"Key source: {key_source}")


def _reorder_main_args(args: list[str]) -> list[str]:
    if not args:
        return args

    value_options = {
        "--model",
        "-m",
        "--api-base-url",
        "--template",
        "-t",
        "--output",
        "-o",
        "--format",
        "-f",
        "--thumb",
        "--thumbnail-output",
        "--screens-dir",
        "--thumb-rows",
        "--thumb-cols",
        "--thumb-width",
        "--thumb-skip",
        "--thumb-quality",
    }
    flag_options = {
        "--generate-thumbnail",
        "--version",
        "--help",
        "-h",
        "--install-completion",
        "--show-completion",
    }

    first_positional_index: int | None = None
    for idx, token in enumerate(args):
        if token == "--":
            break
        if not token.startswith("-"):
            first_positional_index = idx
            break

    if first_positional_index is None:
        return args

    before = args[:first_positional_index]
    positional = [args[first_positional_index]]
    remainder = args[first_positional_index + 1 :]

    moved_options: list[str] = []
    kept_tokens: list[str] = []
    i = 0
    while i < len(remainder):
        token = remainder[i]

        if token.startswith("--") and "=" in token:
            option_name = token.split("=", 1)[0]
            if option_name in value_options:
                moved_options.append(token)
            else:
                kept_tokens.append(token)
            i += 1
            continue

        if token in flag_options:
            moved_options.append(token)
            i += 1
            continue

        if token in value_options:
            moved_options.append(token)
            if i + 1 < len(remainder):
                moved_options.append(remainder[i + 1])
                i += 2
            else:
                i += 1
            continue

        kept_tokens.append(token)
        i += 1

    return before + moved_options + positional + kept_tokens


def run() -> None:
    args = sys.argv[1:]

    if any(arg in ("-h", "--help") for arg in args):
        print_logo()

    if args and args[0] == "config":
        config_app(prog_name="synop config", args=args[1:])
        return

    app(prog_name="synop", args=_reorder_main_args(args))


if __name__ == "__main__":
    run()
