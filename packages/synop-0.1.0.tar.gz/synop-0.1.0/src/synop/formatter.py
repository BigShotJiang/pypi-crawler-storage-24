from __future__ import annotations

import json
from importlib.resources import files
from pathlib import Path

from jinja2 import Environment


EXAMPLE_BBCODE_TEMPLATE = """[cast]
[font=Arial Black][size=4]{{ title }}[/size][/font]
{{ short_summary }}

[info]
[b]Duration:[/b] {{ duration }}
[b]Resolution:[/b] {{ full_resolution }} ({{ short_resolution }})
[b]Codec:[/b] {{ codec }}

[plot]
{{ generated_description }}

[screens]
[img]{{ video_thumb }}[/img]
"""


def _render_template_text(template_text: str, context: dict[str, object]) -> str:
    env = Environment(autoescape=False, trim_blocks=False, lstrip_blocks=False)
    template = env.from_string(template_text)
    return template.render(**context)


def render_template_output(
    context: dict[str, object], template_path: Path | None = None
) -> str:
    if template_path is None:
        try:
            template_text = (files("synop") / "templates" / "example.j2").read_text(
                encoding="utf-8"
            )
        except FileNotFoundError:
            template_text = EXAMPLE_BBCODE_TEMPLATE
    else:
        template_text = template_path.read_text(encoding="utf-8")

    return _render_template_text(template_text=template_text, context=context)


def render_json_output(context: dict[str, object]) -> str:
    payload = {
        "title": context.get("title", ""),
        "short_summary": context.get("short_summary", ""),
        "generated_description": context.get("generated_description", ""),
        "duration": context.get("duration", ""),
        "full_resolution": context.get("full_resolution", ""),
        "short_resolution": context.get("short_resolution", ""),
        "codec": context.get("codec", ""),
        "video_thumb": context.get("video_thumb", ""),
    }

    if "thumbnail_path" in context:
        payload["thumbnail_path"] = context.get("thumbnail_path", "")
    if "screens_dir" in context:
        payload["screens_dir"] = context.get("screens_dir", "")
    if "screens_count" in context:
        payload["screens_count"] = context.get("screens_count", 0)
    if "screens" in context:
        payload["screens"] = context.get("screens", [])

    return json.dumps(payload, ensure_ascii=False, indent=2)


def render_plaintext_output(context: dict[str, object]) -> str:
    parts = [
        str(context.get("title", "")).strip(),
        "",
        str(context.get("short_summary", "")).strip(),
        "",
        f"Duration: {context.get('duration', '')}",
        (
            "Resolution: "
            f"{context.get('full_resolution', '')} "
            f"({context.get('short_resolution', '')})"
        ),
        f"Codec: {context.get('codec', '')}",
        "",
        str(context.get("generated_description", "")).strip(),
    ]

    thumbnail_path = str(context.get("thumbnail_path", "")).strip()
    if thumbnail_path:
        parts.extend(["", f"Thumbnail: {thumbnail_path}"])

    screens_dir = str(context.get("screens_dir", "")).strip()
    if screens_dir:
        screens_count = context.get("screens_count", 0)
        parts.append(f"Screens: {screens_dir} ({screens_count})")

    return "\n".join(parts).strip() + "\n"
