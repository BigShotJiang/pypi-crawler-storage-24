from __future__ import annotations

import io
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

import av
from PIL import Image
from pymediainfo import MediaInfo


@dataclass(slots=True)
class VideoMetadata:
    duration_seconds: float
    width: int
    height: int
    codec: str

    @property
    def duration_text(self) -> str:
        return format_seconds(self.duration_seconds)

    @property
    def full_resolution(self) -> str:
        return f"{self.width}x{self.height}"

    @property
    def short_resolution(self) -> str:
        if self.width >= 3840:
            return "2160p"
        if self.width >= 2560:
            return "1440p"
        if self.width >= 1920:
            return "1080p"
        if self.width >= 1280:
            return "720p"
        if self.width >= 854:
            return "480p"
        return f"{self.height}p"


def determine_sample_count(duration_seconds: float) -> int:
    if duration_seconds < 5 * 60:
        return 4
    if duration_seconds <= 60 * 60:
        return 8
    return 12


def build_sample_timestamps(duration_seconds: float, samples: int) -> list[float]:
    if duration_seconds <= 0:
        raise ValueError("Video has invalid duration")
    if samples <= 0:
        raise ValueError("Sample count must be positive")

    start = duration_seconds * 0.05
    end = duration_seconds * 0.95
    if end <= start:
        start = 0.0
        end = duration_seconds

    span = end - start
    step = span / samples
    return [start + (i + 0.5) * step for i in range(samples)]


def read_video_metadata(video_path: Path) -> VideoMetadata:
    general_track = None
    video_track = None

    media_info = MediaInfo.parse(str(video_path))
    for track in media_info.tracks:
        if track.track_type == "General" and general_track is None:
            general_track = track.to_data()
        elif track.track_type == "Video" and video_track is None:
            video_track = track.to_data()

    if video_track is None:
        raise ValueError(f"No video track found in file: {video_path}")

    duration_ms = _first_numeric(
        video_track.get("duration"),
        general_track.get("duration") if general_track else None,
        default=0.0,
    )
    duration_seconds = (duration_ms or 0.0) / 1000.0

    width = int(_first_numeric(video_track.get("width"), default=0.0) or 0)
    height = int(_first_numeric(video_track.get("height"), default=0.0) or 0)
    codec = str(
        video_track.get("commercial_name")
        or video_track.get("format")
        or video_track.get("codec_id")
        or "unknown"
    )

    if width <= 0 or height <= 0:
        with av.open(str(video_path)) as container:
            stream = container.streams.video[0]
            width = int(stream.width or 0)
            height = int(stream.height or 0)

    if duration_seconds <= 0:
        with av.open(str(video_path)) as container:
            stream = container.streams.video[0]
            if stream.duration and stream.time_base:
                duration_seconds = float(stream.duration * stream.time_base)

    if duration_seconds <= 0:
        raise ValueError(f"Unable to determine video duration for {video_path}")

    return VideoMetadata(
        duration_seconds=duration_seconds,
        width=max(width, 1),
        height=max(height, 1),
        codec=codec,
    )


def extract_sample_jpegs(
    video_path: Path,
    timestamps: list[float],
    max_dimension: int = 1024,
    jpeg_quality: int = 60,
    progress_callback: Callable[[int, int], None] | None = None,
) -> list[bytes]:
    if not timestamps:
        return []

    total = len(timestamps)
    extracted = 0
    images: list[bytes] = []

    if progress_callback is not None:
        progress_callback(0, total)

    with av.open(str(video_path)) as container:
        stream = container.streams.video[0]
        stream.thread_type = "AUTO"
        stream.thread_count = 0

        for target_second in timestamps:
            image = _seek_and_extract_image(container, stream, target_second)
            if image is not None:
                images.append(_to_jpeg_bytes(image, max_dimension, jpeg_quality))

            extracted += 1
            if progress_callback is not None:
                progress_callback(extracted, total)

    if images and len(images) < len(timestamps):
        last = images[-1]
        images.extend(last for _ in range(len(timestamps) - len(images)))

    if not images:
        raise ValueError("Unable to extract sample frames from video")

    return images


def _seek_and_extract_image(
    container: av.container.input.InputContainer,
    stream: av.video.stream.VideoStream,
    target_second: float,
) -> Image.Image | None:
    time_base = float(stream.time_base) if stream.time_base else 0.0
    if time_base <= 0.0:
        return None

    seek_position = int(max(target_second, 0.0) / time_base)
    if stream.start_time is not None:
        seek_position += int(stream.start_time)

    try:
        container.seek(seek_position, stream=stream, any_frame=False, backward=True)
        codec_context = getattr(stream, "codec_context", None)
        if codec_context is not None:
            codec_context.flush_buffers()
    except Exception:
        return None

    try:
        for frame in container.decode(video=stream.index):
            if frame.pts is None:
                continue
            return frame.to_image()
    except Exception:
        return None

    return None


def _to_jpeg_bytes(image: Image.Image, max_dimension: int, jpeg_quality: int) -> bytes:
    width, height = image.size
    if max(width, height) > max_dimension:
        scale = max_dimension / max(width, height)
        new_size = (max(1, int(width * scale)), max(1, int(height * scale)))
        image = image.resize(new_size, Image.Resampling.LANCZOS)

    if image.mode != "RGB":
        image = image.convert("RGB")

    output = io.BytesIO()
    image.save(output, format="JPEG", quality=jpeg_quality, optimize=True)
    return output.getvalue()


def _first_numeric(*values: object, default: float | None = None) -> float | None:
    for value in values:
        if value is None:
            continue
        if isinstance(value, (int, float)):
            return float(value)
        if isinstance(value, str):
            try:
                return float(value)
            except ValueError:
                continue
    return default


def format_seconds(total_seconds: float) -> str:
    total = int(max(total_seconds, 0.0))
    hours, remainder = divmod(total, 3600)
    minutes, seconds = divmod(remainder, 60)
    if hours:
        return f"{hours:02d}:{minutes:02d}:{seconds:02d}"
    return f"{minutes:02d}:{seconds:02d}"
