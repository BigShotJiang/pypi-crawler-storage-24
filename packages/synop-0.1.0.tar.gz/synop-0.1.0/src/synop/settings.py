from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path


SETTINGS_FILE_NAME = "settings.json"


@dataclass(slots=True)
class SynopSettings:
    api_key: str | None = None


def _settings_dir() -> Path:
    if os.name == "nt":
        app_data = os.getenv("APPDATA")
        if app_data:
            return Path(app_data) / "synop"
        return Path.home() / "AppData" / "Roaming" / "synop"

    xdg_config_home = os.getenv("XDG_CONFIG_HOME")
    if xdg_config_home:
        return Path(xdg_config_home) / "synop"
    return Path.home() / ".config" / "synop"


def settings_path() -> Path:
    return _settings_dir() / SETTINGS_FILE_NAME


def load_settings() -> SynopSettings:
    path = settings_path()
    if not path.exists():
        return SynopSettings()

    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return SynopSettings()

    api_key = payload.get("api_key")
    if isinstance(api_key, str) and api_key.strip():
        return SynopSettings(api_key=api_key.strip())
    return SynopSettings()


def save_settings(settings: SynopSettings) -> Path:
    path = settings_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    data = {"api_key": settings.api_key}
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")

    if os.name != "nt":
        try:
            path.chmod(0o600)
        except OSError:
            pass

    return path


def set_api_key(api_key: str) -> Path:
    sanitized = api_key.strip()
    if not sanitized:
        raise ValueError("API key cannot be empty")
    return save_settings(SynopSettings(api_key=sanitized))


def clear_api_key() -> Path:
    return save_settings(SynopSettings(api_key=None))


def resolve_api_key() -> str | None:
    env_key = os.getenv("SYNOP_API_KEY")
    if env_key and env_key.strip():
        return env_key.strip()

    return load_settings().api_key
