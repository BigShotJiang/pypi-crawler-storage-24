from pycid_dev.lib.property.constants import kInheritanceSourceTrait
from pycid_dev.lib.property.property import Property


def yes_or_no(question):
    while True:
        reply = str(input(question + " (y/n): ")).lower().strip()
        if reply[0] == "y":
            return True
        if reply[0] == "n":
            return False


class Component(object):
    """
    Wrapper for the "Component" Object
    """

    def __init__(self, client, raw_component):
        self.name = raw_component["name"]
        self.id = raw_component["id"]
        self._properties = raw_component["properties"]
        self.generic_component_ids = raw_component["template_ids"]
        self.tree_id = raw_component["tree_id"]

        # self._network_callbacks = network_callbacks
        self._client = client

        # # Make sure the necessary network callbacks are present
        # assert sorted(["component_resync_query",
        #                "component_resync_execute",
        #                "component_property_remove",
        #                "component_property_edit",
        #                ]
        #               ) == sorted(self._network_callbacks.keys())

    def __repr__(self):
        return f"Component({self.name}: {self.id}, {len(self._properties)} properties, {len(self.generic_component_ids)} generic components)"

    def rename(self, new_name):
        result = self._client.rename_node(self.tree_id, self.id, new_name)
        return {"edited": result["success"], "error": ""}

    def properties(self):
        return [
            Property(self._client, self.tree_id, self.id, property)
            for property in self._properties
        ]

    def get_property_by_id(self, property_id):
        for property in self._properties:
            if property["id"] == property_id:
                return Property(self._client, self.tree_id, self.id, property)
        return None

    def get_property_by_name(self, name, inheritance_source: str = None):
        for property in self._properties:
            if property["name"] == name:
                # If an inheritance_source was provided, check if it was inherited from
                if (
                    inheritance_source
                    and inheritance_source != property[kInheritanceSourceTrait]
                ):
                    continue

                return Property(self._client, self.tree_id, self.id, property)
        return None

    def has_property_by_name(self, name, inheritance_source: str = None):
        return self.get_property_by_name(name, inheritance_source) is not None

    def need_resync(self):
        result = self._client.node_analyze(self.id, self.tree_id)
        # Return if any changes are proposed
        return result["data_changed"]

    # def resync(self, ignore_prompt=False):
    #     if not ignore_prompt:
    #         if not yes_or_no(
    #                 f"Are you sure you want to resync {self.name} ({self.id})?"):
    #             return False

    #     result = self._network_callbacks["component_resync_execute"](
    #         self.id, self.tree_id)
    #     return {"error": result["error"], "changes_made": result["data_changed"]}

    def edit_property_by_id(
        self,
        property_id,
        new_property_name: str = None,
        new_property_value=None,
        new_property_aux=None,
    ):
        """
        new_property_aux: tuple with a key and value for the aux
        """
        property = next(a for a in self._properties if a["id"] == property_id)
        if not property:
            return (
                False,
                f'Could not find property in {self.name} with id "{property_id}"',
            )

        #
        # If new fields were not supplied then use the exiting ones
        #
        if (
            (not new_property_name)
            and (not new_property_value)
            and (not new_property_aux)
        ):
            return (
                False,
                f'Must provide something to edit for property with id "{property_id}"',
            )
        property_name = new_property_name if new_property_name else property["name"]
        property_value = new_property_value if new_property_value else property["value"]

        property_aux = {} if "aux" not in property else property["aux"]
        if new_property_aux:
            property_aux[new_property_aux[0]] = new_property_aux[1]

        property_traits = property["traits"]

        result = self._client.property_edit(
            self.id,
            property_name,
            property_id,
            property_value,
            property_traits,
            property_aux,
            self.tree_id,
        )
        # return {"edited": result["edited"], "error": result["error"]}
        # TODO support better error returns
        return {"edited": result["success"], "error": ""}

    def remove_property_by_id(self, property_id, ignore_prompt=False):
        if not any(property["id"] == property_id for property in self._properties):
            return (
                False,
                f'Could not find property in {self.name} with id "{property_id}"',
            )

        # Start with the removal
        if not ignore_prompt:
            if not yes_or_no(
                f"Are you sure you want to remove property from {self.name} (property: {property_id})?"
            ):
                return False

        result = self._client.property_remove(self.id, property_id, self.tree_id)
        return {"removed": result["removed"], "error": result["error"]}

    def remove_property_by_name(self, property_name, ignore_prompt=False):
        """
        Simply remove an property from this component with a specific name
        """
        property_id = None
        for property in self._properties:
            if property["name"] == property_name:
                property_id = property["id"]
                break
        if not property_id:
            return (
                False,
                f'Could not find property in {self.name} by name "{property_name}"',
            )

        return self.remove_property_by_id(property_id, ignore_prompt=ignore_prompt)
