def yes_or_no(question):
    while True:
        reply = str(input(question + " (y/n): ")).lower().strip()
        if reply[0] == "y":
            return True
        if reply[0] == "n":
            return False


class Property(object):
    """
    Wrapper for the "Property" Object
    """

    def __init__(self, client, tree_id, node_id, raw_property):
        self.id = raw_property["id"]
        self.name = raw_property["name"]
        # TODO metadata
        self.traits = raw_property["traits"]
        self.value = raw_property["value"]
        # Recursively make Property children objects
        self.children = []
        if "children" in raw_property:
            for child in raw_property["children"]:
                # TODO add the path here too
                self.children.append(Property(client, tree_id, node_id, child))

        self._raw_property = raw_property

        # Save upstream ids
        self.tree_id = tree_id
        self.node_id = node_id

        # Save client for network calls
        self._client = client

    def __repr__(self):
        return f"Property({self.name}: {self.id})"

    def set_value(self, new_value):
        result = self._client.property_value_update(
            self.tree_id,
            self.node_id,
            self.id,
            new_value,
        )
        return {"updated": result["success"], "error": ""}

