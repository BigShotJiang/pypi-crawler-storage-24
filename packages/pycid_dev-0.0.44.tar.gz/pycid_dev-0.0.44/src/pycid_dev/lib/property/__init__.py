from .property import Property  # re-export for convenience
from .constants import kInheritanceSourceTrait

