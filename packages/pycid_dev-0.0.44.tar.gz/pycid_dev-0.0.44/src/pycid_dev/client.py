#!/usr/bin/python3

import requests
from pycid_dev.lib.authentication.authentication import (
    AuthenticationInterface,
    NoAuthentication,
)
from pycid_dev.lib.craft.craft import Craft


class QueryException(Exception):
    """
    If query to the backend fails
    """

    def __init__(self, message="Unknown", errors=None):
        super().__init__(message)
        self.errors = errors


class LocalAuthenticationException(Exception):
    """
    If local auth stuffs fails
    """

    def __init__(self, message="Unknown", errors=None):
        super().__init__(message)
        self.errors = errors


class NtreeClient:
    def __init__(self, backend_url, auth: AuthenticationInterface):
        """
        Constructor
        """
        self._backend_url = backend_url
        self._auth = auth

        # Some caching of some stuff
        self._user_info = None

        # TODO can I add a periodic functionality or something here to do refreshes
        self._auth.refresh()

        # # self._auth()

        # if auth_config:

        #     # Note: we skip the refresh on init, instead we manually call refresh, if it actually needed to refresh,
        #     #       then we will sleep a second to make sure the new token propogates through the nTree backend infra.
        #     self._authentication = Authentication(
        #         verbose=True, skip_refresh_on_init=True, auth_path=path_to_auth)

        #     if self._authentication.refresh():
        #         time.sleep(0.2)  # sleeping is not ideal but should do the trick

        # self._user_info = self._fetch_user_info()

    # ##############################################################################
    # Public API
    # ##############################################################################

    def refresh_auth(self):
        self._auth.refresh()

    #
    # User information queries
    #
    def trees_info(self):
        """
        Gets the trees available and the elements that it is composed of.
        """
        if not self._user_info:
            self._user_info = self._fetch_user_info()
        return self._user_info["user"]["trees"]

    def fetch_tree(self, tree_id):
        """
        Pull all data for a tree from the network. Push it into a new Craft

        :returns A Craft object

        NOTE: this performs a network query
        """
        # # Find the elements that the tree is composed of
        # tree = None
        # # TODO woudl be good to expose an endpoint that has just the info we need.
        # for tree_info in self.trees_info():
        #     if tree_info["id"] == tree_id:
        #         tree = tree_info
        # if not tree:
        #     raise ValueError("Provided tree id could not be found: " + tree_id)
        # # I think this was there to support cherrypicks maybe, prob not. but we need cherrypick support. but currently we have tokens that cant have user info access. so we comment this out

        # Pull down all the crates associated with the tree
        # TODO might want to keep these separated? or at a minimum store a mapping from node id to crate id that it belongs to
        # Hacky, need to remove hashing/payloading from security checkpoint. Push it to backend.
        crate = None
        if isinstance(self._auth, NoAuthentication):
            crate = self._fetch_crate(tree_id)["crates"]
        else:
            crate = self._fetch_crate(tree_id)["crates"]

        # Pull down and create the tree
        the_tree = self._fetch_tree(tree_id)

        return Craft(
            self,
            # tree["name"],
            "<unknown tree name>",
            tree_id,
            crate,
            the_tree,
            #  {"component_resync_query": self._component_resync_query,
            #   "component_resync_execute": self._component_resync_execute,
            #   "component_property_edit": self._component_property_edit,
            #   "component_property_remove": self._component_property_remove,
            #   }
        )

    def get_account_info(self):
        """ """
        pass

    # ##############################################################################
    # Underlying client network requests
    # ##############################################################################

    #
    # Analyze stuff
    #
    def node_analyze(self, id, tree_id):
        """
        :param payload: The payload to attach while requesting
        """
        raise NotImplementedError("Not implemented")

        # return self._smart_get(
        #     "/v1/trees/{tree_id}/nodes/{node_id}/resync/analyze", tree_id=tree_id, node_id=id
        # )

    def node_resync_execute(self, id, tree_id):
        """
        :param payload: The payload to attach while requesting
        """
        raise NotImplementedError("Not implemented")
        # return self._smart_post(
        #     "/v1/instance/node/resync/execute", payload={"id": id, "tree_id": tree_id}
        # )

    #
    # Node stuff
    #
    def rename_node(self, tree_id, node_id, name):
        """
        :param tree_id: The crate id that the node belongs to
        :param node_id: The id of the node to rename
        :param name: The new name of the node
        """
        raise NotImplementedError("Not implemented")
        # return self._smart_patch(
        #     f"/v1/trees/{tree_id}/nodes/{node_id}",
        #     payload={"name": name},
        # )

    #
    # Property stuff
    #
    def property_edit(self, id, property_name, property_id, value, traits, tree_id):
        """
        :param payload: The payload to attach while requesting
        """
        # We must note that the trait has been overridden if it was inherited.
        if "inheritance_source" in traits:
            OVERRIDDEN_KEY = "overridden"
            traits[OVERRIDDEN_KEY] = True

        return self._smart_patch(
            f"/v1/trees/{tree_id}/nodes/{node_id}/properties/{property_id}",
            payload={
                "name": property_name,
                "value": value,
                "traits": traits,
            },
        )

    def property_value_update(self, tree_id, node_id, property_id, value):
        """
        :param tree_id: The tree id that the node belongs to
        :param node_id: The id of the node to with the property we're editing
        :param property_id: The id of the property we're editing
        :param value: The new value of the property
        """

        return self._smart_patch(
            f"/v1/trees/{tree_id}/nodes/{node_id}/properties/{property_id}",
            payload={
                "value": value,
            },
        )

    def property_remove(self, id, property_id, tree_id):
        """
        :param payload: The payload to attach while requesting
        """
        return self._smart_delete(
            f"/v1/trees/{tree_id}/nodes/{node_id}/properties/{property_id}",
        )

    # ##############################################################################
    # Private Helpers
    # ##############################################################################

    def _smart_post(self, end_point, payload=None):
        payload.update(
            {
                "username": "test_user",  # TODO remove this trash
                "password": "test_password",
                "isThirdParty": True,
            }
        )
        payload.update(self._auth.get_payload())
        headers = {}
        headers.update(self._auth.get_headers())

        result = requests.post(
            f"{self._backend_url}{end_point}", headers=headers, json=payload
        )
        if result.status_code != 200:
            raise QueryException(
                f"Failed to post {end_point}: {str(result.status_code)}: {result.text}"
            )

        resp = result.json()
        return resp["payload"]

    def _smart_get(self, end_point):
        headers = {}
        headers.update(self._auth.get_headers())

        result = requests.get(f"{self._backend_url}{end_point}", headers=headers)
        if result.status_code != 200:
            raise QueryException(
                f"Failed to get {end_point}: {str(result.status_code)}: {result.text}"
            )

        resp = result.json()
        return resp["payload"]

    def _smart_put(self, end_point, payload=None):
        payload.update(
            {
                "username": "test_user",  # TODO remove this trash
                "password": "test_password",
                "isThirdParty": True,
            }
        )
        payload.update(self._auth.get_payload())
        headers = {}
        headers.update(self._auth.get_headers())
        result = requests.put(
            f"{self._backend_url}{end_point}", headers=headers, json=payload
        )
        if result.status_code != 200:
            raise QueryException(
                f"Failed to put {end_point}: {str(result.status_code)}: {result.text}"
            )

        resp = result.json()
        return resp["payload"]

    def _smart_patch(self, end_point, payload=None):
        payload.update(
            {
                "username": "test_user",  # TODO remove this trash
                "password": "test_password",
                "isThirdParty": True,
            }
        )
        payload.update(self._auth.get_payload())
        headers = {}
        headers.update(self._auth.get_headers())
        result = requests.patch(
            f"{self._backend_url}{end_point}", headers=headers, json=payload
        )
        if result.status_code != 200:
            raise QueryException(
                f"Failed to patch {end_point}: {str(result.status_code)}: {result.text}"
            )

        resp = result.json()
        return resp["payload"]

    def _fetch_user_info(self):
        return self._smart_get("/v1/user")

    def _fetch_crate(self, tree_id):
        # TODO this api is named funy}
        return self._smart_get(
            f"/v1/trees/{tree_id}/nodes",
        )

    def _fetch_tree(self, tree_id):
        # TODO this api is named funy}
        return self._smart_get(
            f"/v1/trees/{tree_id}/frame?fetch_purpose=Machine",
        )
