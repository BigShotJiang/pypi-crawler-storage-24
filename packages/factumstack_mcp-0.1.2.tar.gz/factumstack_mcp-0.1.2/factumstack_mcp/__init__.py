# factumstack_mcp/__init__.py
# Vacío para que sea un paquete válido
