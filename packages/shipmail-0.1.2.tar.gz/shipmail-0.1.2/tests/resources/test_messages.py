from __future__ import annotations

import json

import httpx

from tests.conftest import json_response, make_client

mock_message = {
    "object": "message",
    "id": "msg_123",
    "mailbox_id": "mbx_456",
    "thread_id": "thr_789",
    "subject": "Hello",
    "from_address": "hello@example.com",
    "to_addresses": [{"address": "user@example.com", "name": "User"}],
    "cc_addresses": None,
    "bcc_addresses": None,
    "source": "api",
    "status": "queued",
    "created_at": "2025-01-01T00:00:00Z",
    "updated_at": "2025-01-01T00:00:00Z",
}


class TestSend:
    def test_sends_post_messages_with_full_body(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "POST"
            assert request.url.path == "/v1/messages"
            body = json.loads(request.content)
            assert body == {
                "mailbox_id": "mbx_456",
                "to": [{"address": "user@example.com", "name": "User"}],
                "subject": "Hello",
                "body_html": "<p>Hi there</p>",
            }
            return json_response(mock_message)

        client = make_client(handler)
        message = client.messages.send({
            "mailbox_id": "mbx_456",
            "to": [{"address": "user@example.com", "name": "User"}],
            "subject": "Hello",
            "body_html": "<p>Hi there</p>",
        })
        assert message["id"] == "msg_123"
        assert message["status"] == "queued"

    def test_sends_with_cc_bcc_and_reply_to(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            body = json.loads(request.content)
            assert body["cc"] == [{"address": "cc@example.com"}]
            assert body["bcc"] == [{"address": "bcc@example.com"}]
            assert body["reply_to"] == {"address": "reply@example.com", "name": "Reply"}
            return json_response(mock_message)

        client = make_client(handler)
        client.messages.send({
            "mailbox_id": "mbx_456",
            "to": [{"address": "user@example.com"}],
            "subject": "Test",
            "cc": [{"address": "cc@example.com"}],
            "bcc": [{"address": "bcc@example.com"}],
            "reply_to": {"address": "reply@example.com", "name": "Reply"},
        })

    def test_sends_with_body_text_only(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            body = json.loads(request.content)
            assert body["body_text"] == "Plain text"
            assert "body_html" not in body
            return json_response(mock_message)

        client = make_client(handler)
        client.messages.send({
            "mailbox_id": "mbx_456",
            "to": [{"address": "user@example.com"}],
            "subject": "Test",
            "body_text": "Plain text",
        })

    def test_sends_with_in_reply_to_and_references(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            body = json.loads(request.content)
            assert body["in_reply_to"] == "<msg-id-1@example.com>"
            assert body["references"] == ["<msg-id-0@example.com>", "<msg-id-1@example.com>"]
            return json_response(mock_message)

        client = make_client(handler)
        client.messages.send({
            "mailbox_id": "mbx_456",
            "to": [{"address": "user@example.com"}],
            "subject": "Re: Test",
            "body_html": "<p>Reply</p>",
            "in_reply_to": "<msg-id-1@example.com>",
            "references": ["<msg-id-0@example.com>", "<msg-id-1@example.com>"],
        })


class TestGet:
    def test_sends_get_messages_id(self) -> None:
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "GET"
            assert request.url.path == "/v1/messages/msg_123"
            return json_response(mock_message)

        client = make_client(handler)
        message = client.messages.get("msg_123")
        assert message["id"] == "msg_123"
        assert message["mailbox_id"] == "mbx_456"
        assert message["thread_id"] == "thr_789"
        assert message["source"] == "api"
