from __future__ import annotations

from typing import TYPE_CHECKING
from urllib.parse import quote

from .._base_client import RequestOptions

if TYPE_CHECKING:
    from .._client import AsyncShipMail, ShipMail
    from .._types.common import MethodOptions
    from .._types.message import Message, SendMessageParams


class SyncMessages:
    def __init__(self, client: ShipMail) -> None:
        self._client = client

    def send(self, params: SendMessageParams, options: MethodOptions | None = None) -> Message:
        return self._client.request(RequestOptions(method="POST", path="/messages", body=params, method_options=options))

    def get(self, id: str, options: MethodOptions | None = None) -> Message:
        return self._client.request(RequestOptions(method="GET", path=f"/messages/{quote(id, safe='')}", method_options=options))


class AsyncMessages:
    def __init__(self, client: AsyncShipMail) -> None:
        self._client = client

    async def send(self, params: SendMessageParams, options: MethodOptions | None = None) -> Message:
        return await self._client.request(RequestOptions(method="POST", path="/messages", body=params, method_options=options))

    async def get(self, id: str, options: MethodOptions | None = None) -> Message:
        return await self._client.request(RequestOptions(method="GET", path=f"/messages/{quote(id, safe='')}", method_options=options))
