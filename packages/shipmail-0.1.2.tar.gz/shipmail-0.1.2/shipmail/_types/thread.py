from __future__ import annotations

from typing import TypedDict

from .common import EmailRecipient, PaginationParams


class ListThreadsParams(PaginationParams, total=False):
    mailbox_id: str


class GetThreadParams(TypedDict, total=False):
    cursor: str
    limit: int


class ReplyToThreadParams(TypedDict, total=False):
    body_html: str
    body_text: str
    to: list[EmailRecipient]
    cc: list[EmailRecipient]
