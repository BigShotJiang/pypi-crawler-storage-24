from __future__ import annotations

from typing import Literal, TypedDict

from .common import EmailRecipient, MessageSource, MessageStatus


class Message(TypedDict):
    object: Literal["message"]
    id: str
    mailbox_id: str
    thread_id: str | None
    subject: str | None
    from_address: str | None
    to_addresses: list[EmailRecipient] | None
    cc_addresses: list[EmailRecipient] | None
    bcc_addresses: list[EmailRecipient] | None
    source: MessageSource
    status: MessageStatus
    created_at: str
    updated_at: str


class _SendMessageParamsRequired(TypedDict):
    mailbox_id: str
    to: list[EmailRecipient]


class SendMessageParams(_SendMessageParamsRequired, total=False):
    cc: list[EmailRecipient]
    bcc: list[EmailRecipient]
    reply_to: EmailRecipient
    subject: str
    body_html: str
    body_text: str
    in_reply_to: str
    references: list[str]
