# ShipMail Python SDK

Official Python SDK for the [ShipMail](https://shipmail.to) API. Provides both synchronous and asynchronous clients. Requires Python 3.10+.

## Installation

```bash
pip install shipmail
```

## Quick Start

```python
from shipmail import ShipMail

client = ShipMail("sm_live_...")

# Create a domain
domain = client.domains.create({"name": "example.com"})

# Send an email
message = client.messages.send({
    "mailbox_id": "mbx_...",
    "to": [{"address": "user@example.com"}],
    "subject": "Hello",
    "body_text": "Hi there",
})
```

### Async

```python
from shipmail import AsyncShipMail

async with AsyncShipMail("sm_live_...") as client:
    domain = await client.domains.create({"name": "example.com"})

    message = await client.messages.send({
        "mailbox_id": "mbx_...",
        "to": [{"address": "user@example.com"}],
        "subject": "Hello",
        "body_text": "Hi there",
    })
```

## Configuration

```python
from shipmail import ShipMail

client = ShipMail(
    "sm_live_...",
    base_url="https://shipmail.to/api/v1",  # default
    max_retries=2,      # default, retries on 5xx and 429
    timeout=30.0,       # default, in seconds
)
```

## Resources

### Domains

```python
domain = client.domains.create({"name": "example.com"})
domains = client.domains.list({"limit": 10})
domain = client.domains.get("dom_...")
updated = client.domains.update("dom_...", {"catch_all_mailbox_id": "mbx_..."})
client.domains.delete("dom_...")
result = client.domains.verify("dom_...")
```

### Mailboxes

```python
mailbox = client.mailboxes.create({
    "domain_id": "dom_...",
    "address": "hello",
    "display_name": "Hello",
})
mailboxes = client.mailboxes.list({"domain_id": "dom_..."})
mailbox = client.mailboxes.get("mbx_...")
updated = client.mailboxes.update("mbx_...", {"display_name": "New Name"})
client.mailboxes.delete("mbx_...")

# Avatar
with open("avatar.png", "rb") as f:
    result = client.mailboxes.upload_avatar("mbx_...", f.read(), "image/png")
client.mailboxes.delete_avatar("mbx_...")
```

### Messages

```python
message = client.messages.send({
    "mailbox_id": "mbx_...",
    "to": [{"address": "user@example.com", "name": "User"}],
    "cc": [{"address": "cc@example.com"}],
    "subject": "Hello",
    "body_html": "<p>Hi there</p>",
    "body_text": "Hi there",
})

message = client.messages.get("msg_...")
```

### Threads

```python
threads = client.threads.list({"mailbox_id": "mbx_..."})
thread = client.threads.get("thd_...")
reply = client.threads.reply("thd_...", {
    "body_text": "Thanks for your email",
    "to": [{"address": "user@example.com"}],
})
```

### Webhooks

```python
webhook = client.webhooks.create({
    "url": "https://example.com/webhook",
    "events": ["message.received", "message.sent"],
    "description": "My webhook",
})
# webhook["secret"] is only available at creation time

webhooks = client.webhooks.list()
webhook = client.webhooks.get("whk_...")
updated = client.webhooks.update("whk_...", {"active": False})
client.webhooks.delete("whk_...")

rotated = client.webhooks.rotate_secret("whk_...")
test = client.webhooks.test("whk_...")
deliveries = client.webhooks.list_deliveries("whk_...")
```

### Status

```python
status = client.status.get()
```

## Pagination

List methods return a paginated response with cursor-based pagination:

```python
page = client.domains.list({"limit": 10})
print(page["data"])        # list of domains
print(page["pagination"])  # {"next_cursor": ..., "has_more": ...}

# Fetch next page
if page["pagination"]["has_more"]:
    next_page = client.domains.list({
        "cursor": page["pagination"]["next_cursor"],
        "limit": 10,
    })
```

Auto-pagination iterates through all pages automatically:

```python
for domain in client.domains.list_auto_paginating(limit=25):
    print(domain["name"])

# Async
async for domain in client.domains.list_auto_paginating(limit=25):
    print(domain["name"])
```

## Webhook Verification

Verify incoming webhook signatures without instantiating a client:

```python
from shipmail import verify_webhook, WebhookVerificationError

try:
    event = verify_webhook(raw_body, headers, webhook_secret)
    print(event["event_type"])  # e.g., "message.received"
    print(event["data"])
except WebhookVerificationError:
    # Invalid signature
    pass
```

## Error Handling

The SDK raises typed exceptions that map to API error responses:

```python
from shipmail import (
    ShipMailError,
    AuthenticationError,
    AuthorizationError,
    ValidationError,
    NotFoundError,
    RateLimitError,
    ConflictError,
    InternalServerError,
    APIConnectionError,
)

try:
    client.domains.create({"name": ""})
except ValidationError as err:
    print(err)             # Error message
    print(err.details)     # Field-level validation errors
except RateLimitError as err:
    print(err.retry_after) # Seconds to wait
except ShipMailError as err:
    print(err.status)      # HTTP status code
    print(err.type)        # Error type string
    print(err.request_id)  # Request ID for support
    print(err.retryable)   # Whether the request can be retried
```

## Retries

The SDK automatically retries on 5xx errors and 429 (rate limit) responses with exponential backoff and jitter. Configure with `max_retries` (default: 2, meaning up to 3 total attempts).

```python
client = ShipMail("sm_live_...", max_retries=0)  # Disable retries
```

## License

MIT
