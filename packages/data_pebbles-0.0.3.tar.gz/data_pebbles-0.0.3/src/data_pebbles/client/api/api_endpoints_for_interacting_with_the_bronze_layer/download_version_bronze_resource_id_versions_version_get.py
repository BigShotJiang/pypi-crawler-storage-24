from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...types import Response


def _get_kwargs(
	resource_id: int,
	version: int,
) -> dict[str, Any]:

	_kwargs: dict[str, Any] = {
		"method": "get",
		"url": "/bronze/{resource_id}/versions/{version}".format(
			resource_id=quote(str(resource_id), safe=""),
			version=quote(str(version), safe=""),
		),
	}

	return _kwargs


def _parse_response(
	*, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | None:
	if response.status_code == 200:
		response_200 = response.json()
		return response_200

	if response.status_code == 422:
		response_422 = HTTPValidationError.from_dict(response.json())

		return response_422

	if client.raise_on_unexpected_status:
		raise errors.UnexpectedStatus(response.status_code, response.content)
	else:
		return None


def _build_response(
	*, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError]:
	return Response(
		status_code=HTTPStatus(response.status_code),
		content=response.content,
		headers=response.headers,
		parsed=_parse_response(client=client, response=response),
	)


def sync_detailed(
	resource_id: int,
	version: int,
	*,
	client: AuthenticatedClient | Client,
) -> Response[Any | HTTPValidationError]:
	"""Download Version

	Args:
	    resource_id (int):
	    version (int):

	Raises:
	    errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
	    httpx.TimeoutException: If the request takes longer than Client.timeout.

	Returns:
	    Response[Any | HTTPValidationError]
	"""

	kwargs = _get_kwargs(
		resource_id=resource_id,
		version=version,
	)

	response = client.get_httpx_client().request(
		**kwargs,
	)

	return _build_response(client=client, response=response)


def sync(
	resource_id: int,
	version: int,
	*,
	client: AuthenticatedClient | Client,
) -> Any | HTTPValidationError | None:
	"""Download Version

	Args:
	    resource_id (int):
	    version (int):

	Raises:
	    errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
	    httpx.TimeoutException: If the request takes longer than Client.timeout.

	Returns:
	    Any | HTTPValidationError
	"""

	return sync_detailed(
		resource_id=resource_id,
		version=version,
		client=client,
	).parsed


async def asyncio_detailed(
	resource_id: int,
	version: int,
	*,
	client: AuthenticatedClient | Client,
) -> Response[Any | HTTPValidationError]:
	"""Download Version

	Args:
	    resource_id (int):
	    version (int):

	Raises:
	    errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
	    httpx.TimeoutException: If the request takes longer than Client.timeout.

	Returns:
	    Response[Any | HTTPValidationError]
	"""

	kwargs = _get_kwargs(
		resource_id=resource_id,
		version=version,
	)

	response = await client.get_async_httpx_client().request(**kwargs)

	return _build_response(client=client, response=response)


async def asyncio(
	resource_id: int,
	version: int,
	*,
	client: AuthenticatedClient | Client,
) -> Any | HTTPValidationError | None:
	"""Download Version

	Args:
	    resource_id (int):
	    version (int):

	Raises:
	    errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
	    httpx.TimeoutException: If the request takes longer than Client.timeout.

	Returns:
	    Any | HTTPValidationError
	"""

	return (
		await asyncio_detailed(
			resource_id=resource_id,
			version=version,
			client=client,
		)
	).parsed
