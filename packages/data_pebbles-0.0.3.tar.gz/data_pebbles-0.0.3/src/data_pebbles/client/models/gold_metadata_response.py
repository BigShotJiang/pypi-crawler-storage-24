from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="GoldMetadataResponse")


@_attrs_define
class GoldMetadataResponse:
	"""
	Attributes:
	    id (int):
	    name (str):
	    description (None | str):
	    project_id (int):
	    created_at (str):
	"""

	id: int
	name: str
	description: None | str
	project_id: int
	created_at: str
	additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

	def to_dict(self) -> dict[str, Any]:
		id = self.id

		name = self.name

		description: None | str
		description = self.description

		project_id = self.project_id

		created_at = self.created_at

		field_dict: dict[str, Any] = {}
		field_dict.update(self.additional_properties)
		field_dict.update(
			{
				"id": id,
				"name": name,
				"description": description,
				"project_id": project_id,
				"created_at": created_at,
			}
		)

		return field_dict

	@classmethod
	def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
		d = dict(src_dict)
		id = d.pop("id")

		name = d.pop("name")

		def _parse_description(data: object) -> None | str:
			if data is None:
				return data
			return cast(None | str, data)

		description = _parse_description(d.pop("description"))

		project_id = d.pop("project_id")

		created_at = d.pop("created_at")

		gold_metadata_response = cls(
			id=id,
			name=name,
			description=description,
			project_id=project_id,
			created_at=created_at,
		)

		gold_metadata_response.additional_properties = d
		return gold_metadata_response

	@property
	def additional_keys(self) -> list[str]:
		return list(self.additional_properties.keys())

	def __getitem__(self, key: str) -> Any:
		return self.additional_properties[key]

	def __setitem__(self, key: str, value: Any) -> None:
		self.additional_properties[key] = value

	def __delitem__(self, key: str) -> None:
		del self.additional_properties[key]

	def __contains__(self, key: str) -> bool:
		return key in self.additional_properties
