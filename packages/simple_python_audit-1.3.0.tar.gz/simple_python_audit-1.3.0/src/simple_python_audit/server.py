import argparse
import http.server
import os
import urllib.parse
import datetime
import json
from io import BytesIO
from datetime import timezone, timedelta

class LogManagerHandler(http.server.SimpleHTTPRequestHandler):
    def get_fortaleza_time(self, timestamp):
        tz_fortaleza = timezone(timedelta(hours=-3))
        dt = datetime.datetime.fromtimestamp(timestamp, tz=timezone.utc)
        return dt.astimezone(tz_fortaleza).strftime('%d/%m/%Y %H:%M:%S')

    def do_POST(self):
        try:
            content_length = int(self.headers.get('Content-Length', 0))
            body = self.rfile.read(content_length).decode('utf-8')
            data = json.loads(body)
            filenames = data.get('files', [])
            
            deleted_count = 0
            for name in filenames:
                full_path = os.path.normpath(os.path.join(self.directory, urllib.parse.unquote(name)))
                if full_path.startswith(os.path.abspath(self.directory)) and os.path.isfile(full_path):
                    os.remove(full_path)
                    deleted_count += 1
            
            self.send_response(200)
            self.end_headers()
            self.wfile.write(f"{deleted_count} removidos".encode())
        except Exception as e:
            self.send_error(500, str(e))

    def list_directory(self, path):
        try:
            list_dir = [n for n in os.listdir(path) if not os.path.isdir(os.path.join(path, n))]
        except OSError:
            self.send_error(404, "Sem permissão")
            return None
        
        list_dir.sort(key=lambda a: a.lower())
        displaypath = urllib.parse.unquote(self.path)
        
        r = []
        r.append('<!DOCTYPE HTML><html><head><meta charset="utf-8">')
        r.append(f'<title>Logs Fortaleza: {displaypath}</title>')
        r.append("""
            <style>
                body { font-family: 'Segoe UI', sans-serif; margin: 30px; background: #f0f4f8; }
                .container { max-width: 1000px; margin: auto; background: white; padding: 25px; border-radius: 12px; box-shadow: 0 5px 15px rgba(0,0,0,0.08); }
                h1 { color: #1a365d; font-size: 1.4rem; border-left: 5px solid #3182ce; padding-left: 15px; }
                .timezone-badge { font-size: 0.8rem; background: #ebf8ff; color: #2b6cb0; padding: 4px 8px; border-radius: 4px; float: right; }
                .toolbar { display: flex; align-items: center; gap: 12px; margin-top: 16px; flex-wrap: wrap; }
                .filter-input { flex: 1; min-width: 180px; padding: 8px 12px; border: 1px solid #cbd5e0; border-radius: 6px; font-size: 0.9rem; outline: none; }
                .filter-input:focus { border-color: #3182ce; box-shadow: 0 0 0 2px rgba(49,130,206,0.2); }
                .file-count { font-size: 0.82rem; color: #718096; white-space: nowrap; }
                table { width: 100%; border-collapse: collapse; margin-top: 16px; }
                th, td { padding: 12px; text-align: left; border-bottom: 1px solid #e2e8f0; }
                th { background: #edf2f7; color: #4a5568; font-size: 0.85rem; }
                th.sortable { cursor: pointer; user-select: none; white-space: nowrap; }
                th.sortable:hover { background: #e2e8f0; }
                th.sort-asc::after { content: ' ▲'; font-size: 0.7rem; }
                th.sort-desc::after { content: ' ▼'; font-size: 0.7rem; }
                .btn { padding: 8px 18px; border-radius: 6px; cursor: pointer; border: none; font-weight: bold; }
                .btn-danger { background: #e53e3e; color: white; }
                .btn-danger:disabled { background: #fc8181; opacity: 0.6; }
                input[type="checkbox"] { width: 18px; height: 18px; cursor: pointer; }
                tr.hidden { display: none; }
            </style>
            <script>
                let sortCol = null, sortAsc = true;

                function toggleAll(master) {
                    document.querySelectorAll('.file-check:not([style*="none"])').forEach(cb => {
                        const row = cb.closest('tr');
                        if (!row.classList.contains('hidden')) cb.checked = master.checked;
                    });
                    updateButton();
                }
                function updateButton() {
                    const count = document.querySelectorAll('.file-check:checked').length;
                    document.getElementById('del-btn').innerText = `Excluir Selecionados (${count})`;
                    document.getElementById('del-btn').disabled = count === 0;
                }
                async function deleteSelected() {
                    const files = Array.from(document.querySelectorAll('.file-check:checked')).map(cb => cb.value);
                    if (confirm(`Remover ${files.length} arquivo(s)?`)) {
                        const res = await fetch('/', {
                            method: 'POST',
                            headers: {'Content-Type': 'application/json'},
                            body: JSON.stringify({files})
                        });
                        if (res.ok) location.reload();
                    }
                }
                function filterTable() {
                    const q = document.getElementById('filter-input').value.toLowerCase();
                    let visible = 0;
                    document.querySelectorAll('#file-tbody tr').forEach(row => {
                        const name = row.dataset.name || '';
                        const show = name.toLowerCase().includes(q);
                        row.classList.toggle('hidden', !show);
                        if (show) visible++;
                    });
                    document.getElementById('file-count').textContent = `${visible} arquivo(s)`;
                    document.getElementById('del-btn').disabled = true;
                    document.getElementById('del-btn').innerText = 'Excluir Selecionados (0)';
                    document.querySelector('thead input[type=checkbox]').checked = false;
                }
                function sortTable(col) {
                    const tbody = document.getElementById('file-tbody');
                    if (sortCol === col) { sortAsc = !sortAsc; }
                    else { sortCol = col; sortAsc = true; }

                    document.querySelectorAll('th.sortable').forEach(th => {
                        th.classList.remove('sort-asc', 'sort-desc');
                        if (th.dataset.col === col) th.classList.add(sortAsc ? 'sort-asc' : 'sort-desc');
                    });

                    const rows = Array.from(tbody.querySelectorAll('tr'));
                    rows.sort((a, b) => {
                        let va = a.dataset[col] || '';
                        let vb = b.dataset[col] || '';
                        if (col === 'size' || col === 'mtime') {
                            va = parseFloat(va); vb = parseFloat(vb);
                            return sortAsc ? va - vb : vb - va;
                        }
                        return sortAsc ? va.localeCompare(vb) : vb.localeCompare(va);
                    });
                    rows.forEach(r => tbody.appendChild(r));
                }
            </script>
        </head><body><div class="container">""")
        
        r.append(f'<span class="timezone-badge">Timezone: Fortaleza (UTC-3)</span>')
        r.append(f'<h1>Logs: {displaypath}</h1>')
        r.append(f'<div class="toolbar">')
        r.append('<button id="del-btn" class="btn btn-danger" onclick="deleteSelected()" disabled>Excluir Selecionados (0)</button>')
        r.append('<input id="filter-input" class="filter-input" type="text" placeholder="Filtrar por nome..." oninput="filterTable()">')
        r.append(f'<span id="file-count" class="file-count">{len(list_dir)} arquivo(s)</span>')
        r.append('</div>')

        r.append('<table><thead><tr>')
        r.append('<th><input type="checkbox" onclick="toggleAll(this)"></th>')
        r.append('<th class="sortable" data-col="name" onclick="sortTable(\'name\')">Nome do Arquivo</th>')
        r.append('<th class="sortable" data-col="size" onclick="sortTable(\'size\')">Tamanho</th>')
        r.append('<th class="sortable" data-col="mtime" onclick="sortTable(\'mtime\')">Última Modificação</th>')
        r.append('</tr></thead><tbody id="file-tbody">')

        for name in list_dir:
            fullname = os.path.join(path, name)
            stats = os.stat(fullname)
            
            # Formatação de Tamanho
            size = stats.st_size
            readable_size = f"{size} B"
            for unit in ['KB', 'MB', 'GB']:
                if size < 1024: break
                size /= 1024
                readable_size = f"{size:.1f} {unit}"
            
            # DATA EM HORÁRIO DE FORTALEZA
            mtime_fortaleza = self.get_fortaleza_time(stats.st_mtime)

            r.append(f'<tr data-name="{name}" data-size="{stats.st_size}" data-mtime="{stats.st_mtime}">')
            r.append(f'<td><input type="checkbox" class="file-check" value="{urllib.parse.quote(name)}" onclick="updateButton()"></td>')
            r.append(f'<td><a href="{urllib.parse.quote(name)}">{name}</a></td>')
            r.append(f'<td>{readable_size}</td>')
            r.append(f'<td>{mtime_fortaleza}</td>')
            r.append('</tr>')

        r.append('</tbody></table></div></body></html>')
        
        content = "\n".join(r).encode('utf-8')
        f = BytesIO(content)
        self.send_response(200)
        self.send_header("Content-type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(content)))
        self.end_headers()
        return f

def start_server(port=8000, directory="/tmp/simple_python_audit_perf"):
    abs_target = os.path.abspath(directory)
    if not os.path.exists(abs_target): os.makedirs(abs_target)
    def handler_factory(*args, **kwargs):
        return LogManagerHandler(*args, directory=abs_target, **kwargs)
    print(f"📍 Simple Python Audit Server [Fortaleza]\n📂 Pasta: {abs_target}\n🔗 http://0.0.0.0:{port}")
    http.server.HTTPServer(('0.0.0.0', port), handler_factory).serve_forever()

def cli():
    parser = argparse.ArgumentParser(description="Simple Python Audit Log Server")
    parser.add_argument("--port", type=int, default=8000)
    parser.add_argument("--dir", type=str, default="/tmp/simple_python_audit_perf")
    args = parser.parse_args()
    start_server(port=args.port, directory=args.dir)