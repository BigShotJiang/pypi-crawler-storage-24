import os
import csv as _csv
import time
import json
import sys
import logging
import tracemalloc
from functools import wraps
from pyinstrument import Profiler
from collections import defaultdict

_logger = logging.getLogger(__name__)

def html_escape(text):
    return str(text).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")

def _print_terminal(func_name, duration, cpu_total, current_mem, peak_mem,
                    total_calls, stats_data, mem_stats_data, trace):
    """Print audit metrics as a formatted table to stdout."""
    cpu_pct = round(cpu_total / duration * 100, 1) if duration > 0 else 0
    mem_current_mb = round(current_mem / 1024 / 1024, 3)
    mem_peak_mb = round(peak_mem / 1024 / 1024, 3)
    mem_avg = f"{round(peak_mem / total_calls / 1024, 2)} KB/call" if total_calls > 0 else "N/A"

    width = 62
    sep = "=" * width
    thin = "-" * width

    print(f"\n{sep}")
    print(f"  AUDIT: {func_name}  |  {duration:.4f}s")
    print(sep)
    print(f"  {'CPU Total:':<22} {cpu_total:.4f}s")
    print(f"  {'CPU Usage:':<22} {cpu_pct}%")
    print(f"  {'Memory Current:':<22} {mem_current_mb} MB")
    print(f"  {'Memory Peak:':<22} {mem_peak_mb} MB")
    print(f"  {'Memory Avg/Call:':<22} {mem_avg}")
    if trace:
        print(f"  {'Total Calls Traced:':<22} {total_calls}")
    print(thin)

    if trace and stats_data:
        print(f"  Top Functions by CPU Time:")
        header = f"  {'Function':<30} {'Calls':>6} {'Total':>9} {'Avg':>9} {'Peak':>9}"
        print(header)
        print(f"  {'-'*30} {'-'*6} {'-'*9} {'-'*9} {'-'*9}")
        for s in stats_data[:15]:
            name = s['name'][:30]
            print(f"  {name:<30} {s['count']:>6} {s['total']:>8}s {s['avg']:>8}s {s['peak']:>8}s")
        print(thin)

    if trace and mem_stats_data:
        print(f"  Top Functions by Memory:")
        header = f"  {'Function':<30} {'Calls':>6} {'Total KB':>10} {'Avg KB':>8} {'Peak KB':>8}"
        print(header)
        print(f"  {'-'*30} {'-'*6} {'-'*10} {'-'*8} {'-'*8}")
        for s in mem_stats_data[:15]:
            name = s['name'][:30]
            print(f"  {name:<30} {s['count']:>6} {s['total_mem']:>10} {s['avg_mem']:>8} {s['peak_mem']:>8}")
        print(thin)

    print()


def _save_csv(output_path, func_name, timestamp, duration, cpu_total, current_mem, peak_mem,
              total_calls, stats_data, mem_stats_data, trace):
    """
    Save audit metrics to CSV files suitable for pandas/AI analysis.

    Generates two files:
    - AUDIT_{func_name}_{timestamp}_summary.csv : one row with all summary metrics
    - AUDIT_{func_name}_{timestamp}_trace.csv   : per-function trace rows (when trace=True)
    """
    cpu_pct = round(cpu_total / duration * 100, 1) if duration > 0 else 0

    # --- Summary CSV ---
    summary_path = os.path.join(output_path, f"AUDIT_{func_name}_{timestamp}_summary.csv")
    summary_row = {
        "timestamp": timestamp,
        "func_name": func_name,
        "duration_s": round(duration, 6),
        "cpu_total_s": round(cpu_total, 6),
        "cpu_pct": cpu_pct,
        "mem_current_mb": round(current_mem / 1024 / 1024, 6),
        "mem_peak_mb": round(peak_mem / 1024 / 1024, 6),
        "mem_avg_kb_per_call": round(peak_mem / total_calls / 1024, 4) if total_calls > 0 else None,
        "total_calls_traced": total_calls if trace else None,
    }
    with open(summary_path, "w", newline="", encoding="utf-8") as f:
        writer = _csv.DictWriter(f, fieldnames=list(summary_row.keys()))
        writer.writeheader()
        writer.writerow(summary_row)

    # --- Trace CSV (only when trace=True) ---
    if trace and (stats_data or mem_stats_data):
        trace_path = os.path.join(output_path, f"AUDIT_{func_name}_{timestamp}_trace.csv")
        # Merge cpu and mem stats by function name
        mem_by_name = {s["name"]: s for s in mem_stats_data}
        fieldnames = [
            "timestamp", "func_name", "called_function",
            "call_count",
            "total_time_s", "avg_time_s", "peak_time_s",
            "total_mem_kb", "avg_mem_kb", "peak_mem_kb",
        ]
        with open(trace_path, "w", newline="", encoding="utf-8") as f:
            writer = _csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for s in stats_data:
                mem = mem_by_name.get(s["name"], {})
                writer.writerow({
                    "timestamp": timestamp,
                    "func_name": func_name,
                    "called_function": s["name"],
                    "call_count": s["count"],
                    "total_time_s": s["total"],
                    "avg_time_s": s["avg"],
                    "peak_time_s": s["peak"],
                    "total_mem_kb": mem.get("total_mem", None),
                    "avg_mem_kb": mem.get("avg_mem", None),
                    "peak_mem_kb": mem.get("peak_mem", None),
                })

    return summary_path


def profile(html=False, output_path="/tmp/simple_python_audit_perf", deep=False, trace=False,
            print_terminal=False, save_csv=False):
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            interval = 0.0001 if deep else 0.001
            profiler = Profiler(interval=interval)
            call_stats = defaultdict(lambda: {
                'count': 0, 'total_time': 0.0, 'peak_time': 0.0,
                'total_mem': 0, 'peak_mem': 0,
                'stack': [], 'mem_stack': []
            })

            def trace_calls(frame, event, arg):
                if event == 'call':
                    f_name = frame.f_code.co_name
                    call_stats[f_name]['count'] += 1
                    call_stats[f_name]['stack'].append(time.time())
                    call_stats[f_name]['mem_stack'].append(
                        tracemalloc.get_traced_memory()[0] if tracemalloc.is_tracing() else 0
                    )
                elif event == 'return':
                    f_name = frame.f_code.co_name
                    if call_stats[f_name]['stack']:
                        elapsed = time.time() - call_stats[f_name]['stack'].pop()
                        call_stats[f_name]['total_time'] += elapsed
                        call_stats[f_name]['peak_time'] = max(call_stats[f_name]['peak_time'], elapsed)
                    if call_stats[f_name]['mem_stack']:
                        start_mem = call_stats[f_name]['mem_stack'].pop()
                        if tracemalloc.is_tracing():
                            mem_delta = max(0, tracemalloc.get_traced_memory()[0] - start_mem)
                            call_stats[f_name]['total_mem'] += mem_delta
                            call_stats[f_name]['peak_mem'] = max(call_stats[f_name]['peak_mem'], mem_delta)
                return trace_calls

            needs_output = html or print_terminal or save_csv
            if needs_output:
                _was_tracing = tracemalloc.is_tracing()
                if not _was_tracing:
                    tracemalloc.start()
                cpu_start = time.process_time()

            if trace:
                sys.settrace(trace_calls)

            profiler.start()
            start_real_time = time.time()
            try:
                return func(*args, **kwargs)
            finally:
                profiler.stop()
                if trace:
                    sys.settrace(None)

                duration = time.time() - start_real_time

                if needs_output:
                    cpu_total = time.process_time() - cpu_start
                    if tracemalloc.is_tracing():
                        current_mem, peak_mem = tracemalloc.get_traced_memory()
                    else:
                        current_mem, peak_mem = 0, 0
                    if not _was_tracing:
                        tracemalloc.stop()

                    if not os.path.exists(output_path):
                        os.makedirs(output_path)

                    stats_data = []
                    mem_stats_data = []
                    if trace:
                        stats_data = [
                            {
                                "name": k,
                                "count": v['count'],
                                "total": round(v['total_time'], 4),
                                "avg": round(v['total_time'] / v['count'], 5),
                                "peak": round(v['peak_time'], 5),
                            }
                            for k, v in sorted(call_stats.items(), key=lambda x: x[1]['total_time'], reverse=True)
                            if v['count'] > 0
                        ][:50]
                        mem_stats_data = [
                            {
                                "name": k,
                                "count": v['count'],
                                "total_mem": round(v['total_mem'] / 1024, 2),
                                "avg_mem": round(v['total_mem'] / v['count'] / 1024, 2) if v['count'] > 0 else 0,
                                "peak_mem": round(v['peak_mem'] / 1024, 2),
                            }
                            for k, v in sorted(call_stats.items(), key=lambda x: x[1]['total_mem'], reverse=True)
                            if v['count'] > 0
                        ][:50]

                    total_calls = sum(v['count'] for v in call_stats.values()) if trace else 0

                    if html:
                        vars_snap = {"args": [str(a)[:500] for a in args], "kwargs": {k: str(v)[:500] for k, v in kwargs.items()}}
                        perf_data = {
                            "func": func.__name__,
                            "dur": f"{duration:.4f}s",
                            "cpu_total": f"{cpu_total:.4f}s",
                            "cpu_pct": f"{round(cpu_total / duration * 100, 1) if duration > 0 else 0}%",
                            "mem_current": f"{round(current_mem / 1024 / 1024, 3)} MB",
                            "mem_peak": f"{round(peak_mem / 1024 / 1024, 3)} MB",
                            "mem_avg": f"{round(peak_mem / total_calls / 1024, 2)} KB/call" if total_calls > 0 else "N/A",
                            "has_trace": trace,
                            "stats": stats_data,
                            "mem_stats": mem_stats_data,
                        }

                        injection_script = f"""
                        <script>
                        (function() {{
                            const d = {{ func: "{func.__name__}", dur: "{duration:.4f}s", vars: {json.dumps(vars_snap)}, stats: {json.dumps(stats_data)} }};
                            const p = {json.dumps(perf_data)};
                            function render() {{
                                if (document.getElementById('odoo-audit-host')) return;
                                const host = document.createElement('div');
                                host.id = 'odoo-audit-host';
                                host.style = 'position:fixed;bottom:20px;right:20px;z-index:2147483647;';
                                document.documentElement.appendChild(host);
                                const shadow = host.attachShadow({{mode:'open'}});
                                const root = document.createElement('div');
                                root.innerHTML = `
                                    <style>
                                        :host {{ all: initial; }}
                                        .fab {{ width:55px;height:55px;color:white;border-radius:50%;display:flex;align-items:center;justify-content:center;cursor:pointer;box-shadow:0 4px 15px rgba(0,0,0,0.4);font-size:22px;border:2px solid white;position:fixed;bottom:20px;transition:0.2s; }}
                                        .fab:hover {{ transform:scale(1.1); }}
                                        .fab1 {{ background:#714B67;right:20px; }}
                                        .fab2 {{ background:#1a6b8a;right:85px; }}
                                        .modal {{ display:none;position:fixed;bottom:85px;right:20px;width:500px;max-height:75vh;background:white;border-radius:12px;box-shadow:0 10px 40px rgba(0,0,0,0.4);flex-direction:column;font-family:sans-serif;overflow:hidden; }}
                                        .modal.open {{ display:flex; }}
                                        .hdr {{ color:white;padding:12px;display:flex;justify-content:space-between;font-weight:bold; }}
                                        .hdr1 {{ background:#714B67; }}
                                        .hdr2 {{ background:#1a6b8a; }}
                                        .body {{ padding:15px;overflow-y:auto;background:white;color:#333; }}
                                        input[type=text] {{ width:95%;padding:8px;margin:10px 0;border:1px solid #ddd;border-radius:4px; }}
                                        table {{ width:100%;border-collapse:collapse;font-size:12px; }}
                                        th {{ background:#f4f4f4;padding:8px;text-align:left;position:sticky;top:0; }}
                                        td {{ padding:8px;border-bottom:1px solid #eee; }}
                                        pre {{ background:#1e1e1e;color:#9cdcfe;padding:10px;font-size:11px;border-radius:4px;max-height:150px;overflow:auto; }}
                                        .grid {{ display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:12px; }}
                                        .card {{ background:#f8f9fa;border-radius:8px;padding:10px;border-left:4px solid #1a6b8a; }}
                                        .card.warn {{ border-left-color:#e53e3e; }}
                                        .card .lbl {{ font-size:10px;color:#666;text-transform:uppercase;letter-spacing:.5px; }}
                                        .card .val {{ font-size:17px;font-weight:bold;color:#1a6b8a;margin-top:3px; }}
                                        .card.warn .val {{ color:#e53e3e; }}
                                        .sec {{ font-size:12px;font-weight:bold;color:#444;margin:10px 0 5px;border-bottom:1px solid #eee;padding-bottom:3px; }}
                                        .no-trace {{ background:#fff3cd;padding:10px;border-radius:6px;font-size:12px;color:#856404;text-align:center;margin:8px 0; }}
                                    </style>
                                    <div class="modal" id="m1">
                                        <div class="hdr hdr1"><span>🚀 ${{d.func}}</span><span>${{d.dur}}</span></div>
                                        <div class="body">
                                            <details><summary style="cursor:pointer;color:#714B67">📦 Vars</summary><pre>${{JSON.stringify(d.vars,null,2)}}</pre></details>
                                            <input type="text" id="s1" placeholder="Buscar função...">
                                            <table><thead><tr><th>Função</th><th>Calls</th><th>Total</th><th>Média</th><th>Pico</th></tr></thead>
                                            <tbody id="tb1">${{d.stats.map(s=>`<tr class="r1"><td class="n1" style="font-family:monospace">${{s.name}}</td><td align="center">${{s.count}}</td><td align="right">${{s.total}}s</td><td align="right">${{s.avg}}s</td><td align="right">${{s.peak||'-'}}s</td></tr>`).join('')}}</tbody>
                                            </table>
                                        </div>
                                    </div>
                                    <div class="modal" id="m2">
                                        <div class="hdr hdr2"><span>📊 ${{p.func}}</span><span>${{p.dur}}</span></div>
                                        <div class="body">
                                            <div class="grid">
                                                <div class="card"><div class="lbl">CPU Total</div><div class="val">${{p.cpu_total}}</div></div>
                                                <div class="card"><div class="lbl">Uso de CPU</div><div class="val">${{p.cpu_pct}}</div></div>
                                                <div class="card"><div class="lbl">Memória Final</div><div class="val">${{p.mem_current}}</div></div>
                                                <div class="card warn"><div class="lbl">Pico de Memória</div><div class="val">${{p.mem_peak}}</div></div>
                                                <div class="card" style="grid-column:1/-1"><div class="lbl">Memória Média por Chamada</div><div class="val">${{p.mem_avg}}</div></div>
                                            </div>
                                            ${{p.has_trace ?
                                                `<div class="sec">⏱ CPU por Função</div>
                                                <input type="text" id="s2" placeholder="Buscar função...">
                                                <table><thead><tr><th>Função</th><th>Calls</th><th>Total</th><th>Média</th><th>Pico</th></tr></thead>
                                                <tbody id="tb2">${{p.stats.map(s=>`<tr class="r2"><td class="n2" style="font-family:monospace">${{s.name}}</td><td align="center">${{s.count}}</td><td align="right">${{s.total}}s</td><td align="right">${{s.avg}}s</td><td align="right">${{s.peak}}s</td></tr>`).join('')}}</tbody>
                                                </table>
                                                <div class="sec">💾 Memória por Função</div>
                                                <table><thead><tr><th>Função</th><th>Calls</th><th>Total (KB)</th><th>Média (KB)</th><th>Pico (KB)</th></tr></thead>
                                                <tbody>${{p.mem_stats.map(s=>`<tr><td style="font-family:monospace">${{s.name}}</td><td align="center">${{s.count}}</td><td align="right">${{s.total_mem}}</td><td align="right">${{s.avg_mem}}</td><td align="right">${{s.peak_mem}}</td></tr>`).join('')}}</tbody>
                                                </table>`
                                            : `<div class="no-trace">⚠️ Habilite <b>trace=True</b> para métricas por função</div>`
                                            }}
                                        </div>
                                    </div>
                                    <div class="fab fab1" id="b1">🚀</div>
                                    <div class="fab fab2" id="b2">📊</div>
                                `;
                                const m1 = root.querySelector('#m1');
                                const m2 = root.querySelector('#m2');
                                root.querySelector('#b1').onclick = () => {{ m1.classList.toggle('open'); m2.classList.remove('open'); }};
                                root.querySelector('#b2').onclick = () => {{ m2.classList.toggle('open'); m1.classList.remove('open'); }};
                                root.querySelector('#s1').oninput = (e) => {{
                                    const v = e.target.value.toLowerCase();
                                    root.querySelectorAll('.r1').forEach(r => r.style.display = r.querySelector('.n1').textContent.toLowerCase().includes(v) ? '' : 'none');
                                }};
                                const s2 = root.querySelector('#s2');
                                if (s2) s2.oninput = (e) => {{
                                    const v = e.target.value.toLowerCase();
                                    root.querySelectorAll('.r2').forEach(r => r.style.display = r.querySelector('.n2').textContent.toLowerCase().includes(v) ? '' : 'none');
                                }};
                                shadow.appendChild(root);
                            }}
                            setInterval(render, 1000); render();
                        }})();
                        </script>
                        """
                        pyinstrument_html = profiler.output_html()
                        final_html = pyinstrument_html.replace('</html>', f'{injection_script}</html>')
                        filepath = os.path.join(output_path, f"AUDIT_{func.__name__}_{int(time.time())}.html")
                        with open(filepath, "w", encoding="utf-8") as f:
                            f.write(final_html)

                    if print_terminal:
                        _print_terminal(
                            func.__name__, duration, cpu_total, current_mem, peak_mem,
                            total_calls, stats_data, mem_stats_data, trace,
                        )

                    if save_csv:
                        _save_csv(
                            output_path, func.__name__, int(time.time()),
                            duration, cpu_total, current_mem, peak_mem,
                            total_calls, stats_data, mem_stats_data, trace,
                        )

        return wrapper
    return decorator
