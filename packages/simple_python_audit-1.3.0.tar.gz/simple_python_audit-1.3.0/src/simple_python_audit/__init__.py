from .engine import profile
from .server import start_server

# Se estiver no Odoo, tenta injetar automaticamente
try:
    from odoo import api
    setattr(api, 'profile', profile)
except ImportError:
    pass