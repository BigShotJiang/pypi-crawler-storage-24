interface Env {
  GITHUB_TOKEN: string;
  FEEDBACK_KV: KVNamespace;
}

interface RecipePayload {
  type: "recipe";
  recipe_id: string;
  source_name: string;
  description?: string;
  code: string;
  version: number;
  times_used: number;
  created_at: string;
  updated_at?: string;
}

interface BugPayload {
  type: "bug";
  title: string;
  error: string;
  traceback?: string;
  log_events?: Record<string, unknown>[];
  system_info?: {
    os: string;
    python: string;
    datarep: string;
  };
}

type FeedbackRequest = RecipePayload | BugPayload;

const REPO = "datarep-ai/datarep";
const RATE_LIMIT_MAX = 10;
const RATE_LIMIT_WINDOW_SECONDS = 3600;

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
};

async function checkRateLimit(ip: string, kv: KVNamespace): Promise<boolean> {
  const key = `ratelimit:${ip}`;
  const current = await kv.get(key);
  const count = current ? parseInt(current, 10) : 0;

  if (count >= RATE_LIMIT_MAX) {
    return false;
  }

  await kv.put(key, String(count + 1), {
    expirationTtl: RATE_LIMIT_WINDOW_SECONDS,
  });
  return true;
}

function buildRecipeBody(body: RecipePayload): string {
  let md = `**Source type:** \`${body.source_name}\`\n`;
  md += `**Description:** ${body.description || "No description"}\n`;
  md += `**Version:** ${body.version}\n`;
  md += `**Used:** ${body.times_used} times\n`;
  md += `**Created:** ${body.created_at}\n`;
  if (body.updated_at) {
    md += `**Last updated:** ${body.updated_at}\n`;
  }
  md += `\n\`\`\`python\n${body.code}\n\`\`\`\n`;
  md += "\n_Submitted via datarep feedback_\n";
  return md;
}

function buildBugBody(body: BugPayload): string {
  let md = "## Error\n\n";
  md += body.error + "\n";

  if (body.system_info) {
    md += "\n## System\n\n";
    md += `- **OS:** ${body.system_info.os}\n`;
    md += `- **Python:** ${body.system_info.python}\n`;
    md += `- **datarep:** ${body.system_info.datarep}\n`;
  }

  if (body.traceback) {
    md += "\n## Traceback\n\n```\n" + body.traceback + "\n```\n";
  }

  if (body.log_events && body.log_events.length > 0) {
    const recent = body.log_events.slice(-20);
    md += "\n<details>\n<summary>Agent log (last " + recent.length + " events)</summary>\n\n```json\n";
    for (const event of recent) {
      md += JSON.stringify(event) + "\n";
    }
    md += "```\n\n</details>\n";
  }

  md += "\n_Auto-reported by datarep_\n";
  return md;
}

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    if (request.method === "OPTIONS") {
      return new Response(null, { status: 204, headers: corsHeaders });
    }

    if (request.method !== "POST") {
      return Response.json(
        { success: false, error: "Method not allowed" },
        { status: 405, headers: corsHeaders }
      );
    }

    const clientIp = request.headers.get("CF-Connecting-IP") || "unknown";
    const allowed = await checkRateLimit(clientIp, env.FEEDBACK_KV);
    if (!allowed) {
      return Response.json(
        { success: false, error: "Rate limit exceeded. Please try again later." },
        { status: 429, headers: corsHeaders }
      );
    }

    let body: FeedbackRequest;
    try {
      body = await request.json();
    } catch {
      return Response.json(
        { success: false, error: "Invalid JSON" },
        { status: 400, headers: corsHeaders }
      );
    }

    if (!body.type || !["recipe", "bug"].includes(body.type)) {
      return Response.json(
        { success: false, error: "type must be 'recipe' or 'bug'" },
        { status: 400, headers: corsHeaders }
      );
    }

    let title: string;
    let issueBody: string;
    let labels: string[];

    if (body.type === "recipe") {
      const rb = body as RecipePayload;
      if (!rb.recipe_id || !rb.code) {
        return Response.json(
          { success: false, error: "recipe_id and code are required" },
          { status: 400, headers: corsHeaders }
        );
      }
      const desc = rb.description || "No description";
      title = `[Recipe] ${rb.recipe_id}: ${desc}`;
      issueBody = buildRecipeBody(rb);
      labels = ["community-recipe"];
    } else {
      const bb = body as BugPayload;
      if (!bb.title || !bb.error) {
        return Response.json(
          { success: false, error: "title and error are required" },
          { status: 400, headers: corsHeaders }
        );
      }
      title = `[Bug] ${bb.title}`;
      issueBody = buildBugBody(bb);
      labels = ["bug"];
    }

    const ghResponse = await fetch(
      `https://api.github.com/repos/${REPO}/issues`,
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${env.GITHUB_TOKEN}`,
          Accept: "application/vnd.github+json",
          "User-Agent": "datarep-feedback-worker",
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ title, body: issueBody, labels }),
      }
    );

    if (!ghResponse.ok) {
      const errorText = await ghResponse.text();
      console.error("GitHub API error:", ghResponse.status, errorText);
      return Response.json(
        { success: false, error: "Failed to submit feedback" },
        { status: 502, headers: corsHeaders }
      );
    }

    const issue = (await ghResponse.json()) as { number: number };

    return Response.json(
      { success: true, issueNumber: issue.number },
      { status: 201, headers: corsHeaders }
    );
  },
};
