"""datarep — a user-authorized agent runtime for delegated data retrieval."""

from __future__ import annotations

__version__ = "1.0.0"

import asyncio
import json
from pathlib import Path
from typing import Any

from datarep.config import ensure_home, get_home
from datarep.db import get_connection
from datarep.agent import RetrievalAgent
from datarep.app_auth import AppAuthManager
from datarep.credentials import CredentialStore, OAuthFlow
from datarep.recipes import RecipeStore
from datarep.registry import SourceRegistry
from datarep.sync_state import SyncStateManager


class DataRep:
    """High-level Python API for datarep.

    Usage:
        rep = DataRep()
        rep.add_source("imessage", source_type="local_db",
                       config={"path": "~/Library/Messages/chat.db"})
        result = rep.get("imessage", query="messages from last 7 days")
    """

    def __init__(self, home: str | Path | None = None):
        if home:
            import os
            os.environ["DATAREP_HOME"] = str(home)
        ensure_home()
        self._conn = get_connection()
        self._registry = SourceRegistry(self._conn)
        self._cred_store = CredentialStore(self._conn)
        self._recipe_store = RecipeStore(self._conn)
        self._sync_state = SyncStateManager(self._conn)
        self._app_auth = AppAuthManager(self._conn)
        self._agent: RetrievalAgent | None = None

    def _get_agent(self) -> RetrievalAgent:
        if self._agent is None:
            self._agent = RetrievalAgent(
                self._conn,
                registry=self._registry,
                cred_store=self._cred_store,
                recipe_store=self._recipe_store,
                sync_state=self._sync_state,
            )
        return self._agent

    # --- Source management ---

    def add_source(
        self,
        name: str,
        source_type: str,
        config: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        return self._registry.add(name, source_type, config)

    def list_sources(self) -> list[dict[str, Any]]:
        return self._registry.list()

    def remove_source(self, name: str) -> bool:
        return self._registry.remove(name)

    # --- Credentials ---

    def set_credentials(
        self,
        source: str,
        cred_type: str,
        data: dict[str, Any],
        expires_at: str | None = None,
    ) -> None:
        self._cred_store.store(source, cred_type, data, expires_at)

    def run_oauth(self, source: str, timeout: int = 120) -> dict[str, Any]:
        """Run a browser-based OAuth flow for a source."""
        src = self._registry.get(source)
        if src is None:
            raise ValueError(f"Source '{source}' not found.")
        config = src["config"]
        flow = OAuthFlow(
            auth_url=config["auth_url"],
            token_url=config["token_url"],
            client_id=config["client_id"],
            client_secret=config["client_secret"],
            scopes=config.get("scopes", []),
        )
        tokens = flow.run(timeout=timeout)
        self._cred_store.store(source, "oauth2", {
            **tokens,
            "client_id": config["client_id"],
            "client_secret": config["client_secret"],
            "token_url": config["token_url"],
        })
        return tokens

    # --- Retrieval ---

    def get(self, source: str, query: str) -> dict[str, Any]:
        """Agent-driven data retrieval."""
        agent = self._get_agent()
        return asyncio.run(agent.run(source, query))

    def sync(self, source: str, query: str = "") -> dict[str, Any]:
        """Incremental sync for a source."""
        agent = self._get_agent()
        q = query or f"Incremental sync for {source}"
        return asyncio.run(agent.run(source, q))

    def run_recipe(self, recipe_id: str) -> dict[str, Any]:
        """Run a saved recipe (no LLM call)."""
        agent = self._get_agent()
        return asyncio.run(agent.run_recipe(recipe_id))

    # --- Recipes ---

    def list_recipes(self, source: str | None = None) -> list[dict[str, Any]]:
        return self._recipe_store.list(source_name=source)

    def get_recipe(self, recipe_id: str) -> dict[str, Any] | None:
        return self._recipe_store.get(recipe_id)

    # --- Apps ---

    def register_app(
        self, name: str, allowed_sources: list[str] | None = None
    ) -> tuple[str, str]:
        """Register a consuming app. Returns (app_id, api_key)."""
        return self._app_auth.register_app(name, allowed_sources)

    def list_apps(self) -> list[dict[str, Any]]:
        return self._app_auth.list_apps()

    def revoke_app(self, app_id: str) -> bool:
        return self._app_auth.revoke(app_id)

    # --- Sync state ---

    def get_sync_state(self, source: str) -> dict[str, Any] | None:
        return self._sync_state.get(source)
