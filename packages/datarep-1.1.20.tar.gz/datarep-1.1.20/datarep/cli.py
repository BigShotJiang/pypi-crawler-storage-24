"""Click CLI for datarep — setup, app management, debugging, and server control."""

from __future__ import annotations

import asyncio
import json
import os
import signal
import sys
from pathlib import Path

import click

from datarep.config import ensure_home, get_home, get_server_port, get_server_host


def _get_pid_file() -> Path:
    return get_home() / "datarep.pid"


@click.group()
def cli():
    """datarep — delegated data retrieval for agentic apps."""
    pass


# --- Server commands ---

@cli.command()
@click.option("--port", default=None, type=int, help="Port to listen on.")
@click.option("--host", default=None, help="Host to bind to.")
@click.option("--daemon/--no-daemon", default=False, help="Run in background.")
def start(port: int | None, host: str | None, daemon: bool):
    """Start the datarep server (HTTP + MCP)."""
    ensure_home()
    port = port or get_server_port()
    host = host or get_server_host()

    if daemon:
        pid = os.fork()
        if pid > 0:
            _get_pid_file().write_text(str(pid))
            click.echo(f"datarep server started (pid {pid}) on {host}:{port}")
            return
        os.setsid()

    import uvicorn
    from datarep.server import app
    click.echo(f"Starting datarep on {host}:{port}")
    uvicorn.run(app, host=host, port=port, log_level="info")


@cli.command()
def stop():
    """Stop the datarep server."""
    pid_file = _get_pid_file()
    if not pid_file.exists():
        click.echo("No running server found.")
        return
    pid = int(pid_file.read_text().strip())
    try:
        os.kill(pid, signal.SIGTERM)
        click.echo(f"Server stopped (pid {pid}).")
    except ProcessLookupError:
        click.echo("Server process not found (already stopped).")
    pid_file.unlink(missing_ok=True)


@cli.command("init")
def init_cmd():
    """Initialize datarep (~/.datarep/) and seed built-in recipes."""
    home = ensure_home()
    from datarep.db import get_connection
    from datarep.recipes import RecipeStore

    conn = get_connection()
    store = RecipeStore(conn)
    seeded = store.seed_builtin_recipes()
    click.echo(f"datarep initialized at {home}")
    if seeded:
        click.echo(f"  Seeded {len(seeded)} built-in recipe(s): {', '.join(seeded)}")


# --- Source commands ---

@cli.group()
def source():
    """Manage data sources."""
    pass


@source.command("add")
@click.argument("name")
@click.option("--type", "source_type", required=True, type=click.Choice(["local_db", "rest_api", "local_files"]))
@click.option("--path", default=None, help="Path for local_db or local_files sources.")
@click.option("--base-url", default=None, help="Base URL for rest_api sources.")
@click.option("--config-json", default=None, help="Full config as JSON string.")
def source_add(name: str, source_type: str, path: str | None, base_url: str | None, config_json: str | None):
    """Register a new data source."""
    from datarep.db import get_connection
    from datarep.registry import SourceRegistry

    ensure_home()
    conn = get_connection()
    registry = SourceRegistry(conn)

    config = {}
    if config_json:
        config = json.loads(config_json)
    if path:
        config["path"] = path
    if base_url:
        config["base_url"] = base_url

    try:
        result = registry.add(name, source_type, config)
        click.echo(f"Source '{name}' registered ({source_type}).")
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@source.command("list")
def source_list():
    """List registered sources."""
    from datarep.db import get_connection
    from datarep.registry import SourceRegistry
    from datarep.sync_state import SyncStateManager

    ensure_home()
    conn = get_connection()
    registry = SourceRegistry(conn)
    sync = SyncStateManager(conn)

    sources = registry.list()
    if not sources:
        click.echo("No sources registered.")
        return
    for s in sources:
        state = sync.get(s["name"])
        status = f" (last sync: {state['last_run_at']})" if state else ""
        click.echo(f"  {s['name']}  [{s['source_type']}]{status}")


@source.command("remove")
@click.argument("name")
def source_remove(name: str):
    """Remove a data source."""
    from datarep.db import get_connection
    from datarep.registry import SourceRegistry

    ensure_home()
    conn = get_connection()
    registry = SourceRegistry(conn)

    if registry.remove(name):
        click.echo(f"Source '{name}' removed.")
    else:
        click.echo(f"Source '{name}' not found.")


# --- Auth commands ---

@cli.group()
def auth():
    """Manage source authentication."""
    pass


@auth.command("oauth")
@click.argument("source_name")
def auth_oauth(source_name: str):
    """Run browser-based OAuth flow for a source."""
    from datarep.db import get_connection
    from datarep.registry import SourceRegistry
    from datarep.credentials import CredentialStore, OAuthFlow

    ensure_home()
    conn = get_connection()
    registry = SourceRegistry(conn)
    cred_store = CredentialStore(conn)
    source = registry.get(source_name)

    if source is None:
        click.echo(f"Source '{source_name}' not found.", err=True)
        sys.exit(1)

    config = source["config"]
    required = ["auth_url", "token_url", "client_id", "client_secret"]
    missing = [k for k in required if k not in config]
    if missing:
        click.echo(f"Source config missing: {', '.join(missing)}", err=True)
        sys.exit(1)

    flow = OAuthFlow(
        auth_url=config["auth_url"],
        token_url=config["token_url"],
        client_id=config["client_id"],
        client_secret=config["client_secret"],
        scopes=config.get("scopes", []),
    )
    click.echo("Opening browser for authorization...")
    try:
        tokens = flow.run()
        cred_store.store(source_name, "oauth2", {
            **tokens,
            "client_id": config["client_id"],
            "client_secret": config["client_secret"],
            "token_url": config["token_url"],
        })
        click.echo(f"OAuth flow completed for '{source_name}'.")
    except Exception as e:
        click.echo(f"OAuth failed: {e}", err=True)
        sys.exit(1)


@auth.command("api-key")
@click.argument("source_name")
@click.argument("key")
def auth_api_key(source_name: str, key: str):
    """Store an API key for a source."""
    from datarep.db import get_connection
    from datarep.credentials import CredentialStore

    ensure_home()
    conn = get_connection()
    cred_store = CredentialStore(conn)
    cred_store.store(source_name, "api_key", {"api_key": key})
    click.echo(f"API key stored for '{source_name}'.")


# --- App commands ---

@cli.group()
def app():
    """Manage consuming apps."""
    pass


@app.command("register")
@click.argument("name")
@click.option("--sources", default=None, help="Comma-separated list of allowed sources (omit for all).")
def app_register(name: str, sources: str | None):
    """Register a consuming app and print its API key."""
    from datarep.db import get_connection
    from datarep.app_auth import AppAuthManager

    ensure_home()
    conn = get_connection()
    auth_mgr = AppAuthManager(conn)
    allowed = sources.split(",") if sources else None
    app_id, api_key = auth_mgr.register_app(name, allowed)
    click.echo(f"App registered: {name}")
    click.echo(f"  App ID:  {app_id}")
    click.echo(f"  API Key: {api_key}")
    click.echo("  (Save this key — it won't be shown again.)")


@app.command("list")
def app_list():
    """List registered apps."""
    from datarep.db import get_connection
    from datarep.app_auth import AppAuthManager

    ensure_home()
    conn = get_connection()
    auth_mgr = AppAuthManager(conn)
    apps = auth_mgr.list_apps()
    if not apps:
        click.echo("No apps registered.")
        return
    for a in apps:
        status = " [REVOKED]" if a["revoked_at"] else ""
        sources = f" (sources: {', '.join(a['allowed_sources'])})" if a["allowed_sources"] else " (all sources)"
        click.echo(f"  {a['app_id']}  {a['name']}{sources}{status}")


@app.command("revoke")
@click.argument("app_id")
def app_revoke(app_id: str):
    """Revoke an app's access."""
    from datarep.db import get_connection
    from datarep.app_auth import AppAuthManager

    ensure_home()
    conn = get_connection()
    auth_mgr = AppAuthManager(conn)
    if auth_mgr.revoke(app_id):
        click.echo(f"App '{app_id}' revoked.")
    else:
        click.echo(f"App '{app_id}' not found or already revoked.")


# --- Retrieval commands ---

@cli.command("get")
@click.argument("query")
@click.option("--source", default=None, help="Optional source name for recipe lookup.")
def get_data(query: str, source: str | None):
    """Agent-driven data retrieval. Just describe what you want."""
    from datarep.db import get_connection
    from datarep.agent import RetrievalAgent

    ensure_home()
    conn = get_connection()
    try:
        agent = RetrievalAgent(conn)
    except ValueError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)

    result = asyncio.run(agent.run(query, source_name=source))

    while result.get("status") == "question":
        answer = click.prompt(result["question"])
        result = asyncio.run(agent.resume(result["session_id"], answer))

    click.echo(json.dumps(result, indent=2))


@cli.command("sync")
@click.argument("source_name")
@click.option("--query", default="", help="Optional query for the sync.")
def sync_data(source_name: str, query: str):
    """Incremental sync using saved recipe or agent."""
    from datarep.db import get_connection
    from datarep.agent import RetrievalAgent

    ensure_home()
    conn = get_connection()
    try:
        agent = RetrievalAgent(conn)
    except ValueError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)

    query = query or f"Incremental sync for {source_name}"
    result = asyncio.run(agent.run(query, source_name=source_name))
    click.echo(json.dumps(result, indent=2))


# --- Recipe commands ---

@cli.group()
def recipe():
    """Manage retrieval recipes."""
    pass


@recipe.command("list")
@click.option("--source", default=None, help="Filter by source name.")
def recipe_list(source: str | None):
    """List saved recipes."""
    from datarep.db import get_connection
    from datarep.recipes import RecipeStore

    ensure_home()
    conn = get_connection()
    store = RecipeStore(conn)
    recipes = store.list(source_name=source)
    if not recipes:
        click.echo("No recipes saved.")
        return
    for r in recipes:
        used = f" (used {r['times_used']}x)" if r["times_used"] else ""
        click.echo(f"  {r['id']}  [{r['source_name']}]  {r['description'] or ''}{used}")


@recipe.command("run")
@click.argument("recipe_id")
def recipe_run(recipe_id: str):
    """Replay a saved recipe."""
    from datarep.db import get_connection
    from datarep.agent import RetrievalAgent

    ensure_home()
    conn = get_connection()
    try:
        agent = RetrievalAgent(conn)
    except ValueError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)

    result = asyncio.run(agent.run_recipe(recipe_id))
    click.echo(json.dumps(result, indent=2))


@recipe.command("show")
@click.argument("recipe_id")
def recipe_show(recipe_id: str):
    """Print the code for a saved recipe."""
    from datarep.db import get_connection
    from datarep.recipes import RecipeStore

    ensure_home()
    conn = get_connection()
    store = RecipeStore(conn)
    recipe = store.get(recipe_id)
    if recipe is None:
        click.echo(f"Recipe '{recipe_id}' not found.")
        return
    click.echo(f"# Recipe: {recipe['id']}")
    click.echo(f"# Source: {recipe['source_name']}")
    click.echo(f"# Description: {recipe['description'] or 'N/A'}")
    click.echo()
    click.echo(recipe["code"])


@recipe.command("share")
@click.argument("recipe_id")
def recipe_share(recipe_id: str):
    """Share a recipe to the datarep GitHub repo."""
    from datarep.db import get_connection
    from datarep.feedback import GitHubFeedback
    from datarep.recipes import RecipeStore

    ensure_home()
    conn = get_connection()
    store = RecipeStore(conn)
    recipe = store.get(recipe_id)
    if recipe is None:
        click.echo(f"Recipe '{recipe_id}' not found.", err=True)
        sys.exit(1)

    try:
        fb = GitHubFeedback()
        result = fb.share_recipe(recipe)
        click.echo(f"Recipe shared (issue #{result['issueNumber']})")
    except Exception as e:
        click.echo(f"Error sharing recipe: {e}", err=True)
        sys.exit(1)


# --- Report command ---

@cli.command("report")
@click.option("--title", required=True, help="Short description of the bug.")
@click.option("--log", "log_file", default=None, type=click.Path(exists=True), help="Path to a JSONL log file.")
def report_bug(title: str, log_file: str | None):
    """Report a bug to the datarep GitHub repo."""
    from datarep.config import get_logs_dir
    from datarep.feedback import GitHubFeedback

    log_events = None
    log_path = None
    if log_file:
        log_path = Path(log_file)
    else:
        logs_dir = get_logs_dir()
        if logs_dir.exists():
            log_files = sorted(logs_dir.glob("*.jsonl"), key=lambda p: p.stat().st_mtime, reverse=True)
            if log_files:
                log_path = log_files[0]

    error_text = title
    traceback_text = None
    if log_path and log_path.exists():
        try:
            lines = log_path.read_text().strip().splitlines()
            log_events = [json.loads(line) for line in lines if line.strip()]
            for event in reversed(log_events):
                if event.get("event") == "error" or (
                    event.get("event") == "complete" and event.get("status") == "error"
                ):
                    error_text = event.get("error", title)
                    traceback_text = event.get("traceback")
                    break
        except Exception:
            pass

    try:
        fb = GitHubFeedback()
        result = fb.report_bug(
            title=title,
            error=error_text,
            traceback=traceback_text,
            log_events=log_events,
        )
        click.echo(f"Bug reported (issue #{result['issueNumber']})")
    except Exception as e:
        click.echo(f"Error reporting bug: {e}", err=True)
        sys.exit(1)


# --- Logs command ---

@cli.command("logs")
@click.option("--source", default=None, help="Filter by source name.")
@click.option("--app-id", "app_id", default=None, help="Filter by app ID.")
@click.option("--limit", default=50, help="Number of log entries.")
def show_logs(source: str | None, app_id: str | None, limit: int):
    """View the audit log."""
    from datarep.db import get_connection
    from datarep.app_auth import AppAuthManager

    ensure_home()
    conn = get_connection()
    auth_mgr = AppAuthManager(conn)
    logs = auth_mgr.get_logs(app_id=app_id, source_name=source, limit=limit)
    if not logs:
        click.echo("No log entries.")
        return
    for entry in logs:
        src = f" [{entry['source_name']}]" if entry["source_name"] else ""
        click.echo(f"  {entry['timestamp']}  {entry['app_id']}  {entry['action']}{src}  {entry['status']}")


if __name__ == "__main__":
    cli()
