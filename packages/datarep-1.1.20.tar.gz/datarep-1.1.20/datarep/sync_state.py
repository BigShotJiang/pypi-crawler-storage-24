"""Per-source sync state tracking — cursors, timestamps, status."""

from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timezone
from typing import Any


class SyncStateManager:
    """Tracks sync progress per source and recipe."""

    def __init__(self, conn: sqlite3.Connection):
        self._conn = conn

    def get(self, source_name: str, recipe_id: str | None = None) -> dict[str, Any] | None:
        if recipe_id:
            row = self._conn.execute(
                """SELECT source_name, recipe_id, last_cursor, last_status, last_run_at, items_retrieved
                   FROM sync_state WHERE source_name = ? AND recipe_id = ?""",
                (source_name, recipe_id),
            ).fetchone()
        else:
            row = self._conn.execute(
                """SELECT source_name, recipe_id, last_cursor, last_status, last_run_at, items_retrieved
                   FROM sync_state WHERE source_name = ?
                   ORDER BY last_run_at DESC LIMIT 1""",
                (source_name,),
            ).fetchone()
        if row is None:
            return None
        cursor_val = row["last_cursor"]
        try:
            cursor_val = json.loads(cursor_val) if cursor_val else None
        except (json.JSONDecodeError, TypeError):
            pass
        return {
            "source_name": row["source_name"],
            "recipe_id": row["recipe_id"],
            "last_cursor": cursor_val,
            "last_status": row["last_status"],
            "last_run_at": row["last_run_at"],
            "items_retrieved": row["items_retrieved"],
        }

    def set(
        self,
        source_name: str,
        recipe_id: str,
        cursor: Any = None,
        status: str = "success",
        items_retrieved: int = 0,
    ) -> None:
        now = datetime.now(timezone.utc).isoformat()
        cursor_str = json.dumps(cursor) if cursor is not None else None
        self._conn.execute(
            """INSERT OR REPLACE INTO sync_state
               (source_name, recipe_id, last_cursor, last_status, last_run_at, items_retrieved)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (source_name, recipe_id, cursor_str, status, now, items_retrieved),
        )
        self._conn.commit()

    def clear(self, source_name: str, recipe_id: str | None = None) -> None:
        if recipe_id:
            self._conn.execute(
                "DELETE FROM sync_state WHERE source_name = ? AND recipe_id = ?",
                (source_name, recipe_id),
            )
        else:
            self._conn.execute(
                "DELETE FROM sync_state WHERE source_name = ?",
                (source_name,),
            )
        self._conn.commit()

    def list_for_source(self, source_name: str) -> list[dict[str, Any]]:
        rows = self._conn.execute(
            """SELECT source_name, recipe_id, last_cursor, last_status, last_run_at, items_retrieved
               FROM sync_state WHERE source_name = ?""",
            (source_name,),
        ).fetchall()
        results = []
        for row in rows:
            cursor_val = row["last_cursor"]
            try:
                cursor_val = json.loads(cursor_val) if cursor_val else None
            except (json.JSONDecodeError, TypeError):
                pass
            results.append({
                "source_name": row["source_name"],
                "recipe_id": row["recipe_id"],
                "last_cursor": cursor_val,
                "last_status": row["last_status"],
                "last_run_at": row["last_run_at"],
                "items_retrieved": row["items_retrieved"],
            })
        return results
