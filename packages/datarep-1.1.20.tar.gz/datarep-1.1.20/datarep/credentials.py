"""Encrypted credential storage, OAuth browser flows, and token refresh."""

from __future__ import annotations

import json
import os
import secrets
import sqlite3
import threading
import time
import webbrowser
from datetime import datetime, timezone
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from typing import Any
from urllib.parse import urlencode, urlparse, parse_qs

import httpx
from cryptography.fernet import Fernet

from datarep.config import get_master_key_path


def _load_or_create_key(key_path: Path | None = None) -> bytes:
    """Load the Fernet master key, or create one if it doesn't exist."""
    if key_path is None:
        key_path = get_master_key_path()
    if key_path.exists():
        return key_path.read_bytes().strip()
    key = Fernet.generate_key()
    key_path.parent.mkdir(parents=True, exist_ok=True)
    key_path.write_bytes(key)
    os.chmod(str(key_path), 0o600)
    return key


class CredentialStore:
    """Manages encrypted credential storage and retrieval."""

    def __init__(self, conn: sqlite3.Connection, key_path: Path | None = None):
        self._conn = conn
        env_key = os.environ.get("DATAREP_KEY")
        if env_key:
            self._fernet = Fernet(env_key.encode() if isinstance(env_key, str) else env_key)
        else:
            self._fernet = Fernet(_load_or_create_key(key_path))

    def store(
        self,
        source_name: str,
        cred_type: str,
        data: dict[str, Any],
        expires_at: str | None = None,
    ) -> None:
        encrypted = self._fernet.encrypt(json.dumps(data).encode())
        now = datetime.now(timezone.utc).isoformat()
        self._conn.execute(
            """INSERT OR REPLACE INTO credentials
               (source_name, cred_type, encrypted_data, expires_at, created_at, updated_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (source_name, cred_type, encrypted, expires_at, now, now),
        )
        self._conn.commit()

    def retrieve(self, source_name: str) -> dict[str, Any] | None:
        row = self._conn.execute(
            "SELECT cred_type, encrypted_data, expires_at FROM credentials WHERE source_name = ?",
            (source_name,),
        ).fetchone()
        if row is None:
            return None
        data = json.loads(self._fernet.decrypt(row["encrypted_data"]))
        return {
            "cred_type": row["cred_type"],
            "expires_at": row["expires_at"],
            **data,
        }

    def delete(self, source_name: str) -> bool:
        cursor = self._conn.execute(
            "DELETE FROM credentials WHERE source_name = ?", (source_name,)
        )
        self._conn.commit()
        return cursor.rowcount > 0

    def get_for_injection(self, source_name: str) -> dict[str, str]:
        """Get credentials as flat env-var-safe strings for sandbox injection."""
        creds = self.retrieve(source_name)
        if creds is None:
            return {}
        env_vars: dict[str, str] = {}
        cred_type = creds.pop("cred_type", "custom")
        creds.pop("expires_at", None)
        if cred_type == "oauth2":
            creds = self._maybe_refresh_oauth(source_name, creds)
            if "access_token" in creds:
                env_vars["DATAREP_ACCESS_TOKEN"] = creds["access_token"]
            if "refresh_token" in creds:
                env_vars["DATAREP_REFRESH_TOKEN"] = creds["refresh_token"]
        elif cred_type == "api_key":
            if "api_key" in creds:
                env_vars["DATAREP_API_KEY"] = creds["api_key"]
        env_vars["DATAREP_CRED_JSON"] = json.dumps(creds)
        return env_vars

    def _maybe_refresh_oauth(self, source_name: str, creds: dict) -> dict:
        """Refresh OAuth tokens if expired."""
        expires_at_str = creds.get("expires_at")
        if expires_at_str:
            try:
                expires_at = datetime.fromisoformat(expires_at_str)
                if expires_at > datetime.now(timezone.utc):
                    return creds
            except (ValueError, TypeError):
                pass

        token_url = creds.get("token_url")
        refresh_token = creds.get("refresh_token")
        client_id = creds.get("client_id")
        client_secret = creds.get("client_secret")

        if not all([token_url, refresh_token, client_id, client_secret]):
            return creds

        try:
            resp = httpx.post(
                token_url,
                data={
                    "grant_type": "refresh_token",
                    "refresh_token": refresh_token,
                    "client_id": client_id,
                    "client_secret": client_secret,
                },
                timeout=30,
            )
            resp.raise_for_status()
            token_data = resp.json()

            creds["access_token"] = token_data["access_token"]
            if "refresh_token" in token_data:
                creds["refresh_token"] = token_data["refresh_token"]

            new_expires_at = None
            if "expires_in" in token_data:
                from datetime import timedelta
                new_expires_at = (
                    datetime.now(timezone.utc) + timedelta(seconds=token_data["expires_in"])
                ).isoformat()
                creds["expires_at"] = new_expires_at

            self.store(source_name, "oauth2", creds, expires_at=new_expires_at)
            return creds
        except Exception:
            return creds

    def needs_action(self, source_name: str) -> dict[str, Any] | None:
        """Check if a source needs user action for credentials. Returns action_required dict or None."""
        source_row = self._conn.execute(
            "SELECT source_type, config FROM sources WHERE name = ?", (source_name,)
        ).fetchone()
        if source_row is None:
            return None

        source_type = source_row["source_type"]
        if source_type in ("local_db", "local_files"):
            return None

        creds = self.retrieve(source_name)
        if creds is None:
            config = json.loads(source_row["config"]) if source_row else {}

            if config.get("auth_url"):
                return {
                    "status": "action_required",
                    "action_type": "oauth_login",
                    "source": source_name,
                    "explanation": f"Access to {source_name} requires signing in and granting permission.",
                    "provider": config.get("provider", source_name),
                    "initiate_endpoint": "/auth/oauth",
                    "initiate_body": {"source": source_name},
                    "retryable": True,
                }
            return {
                "status": "action_required",
                "action_type": "api_key_needed",
                "source": source_name,
                "explanation": f"Credentials are needed for {source_name}. Please provide an API key or configure authentication.",
                "retryable": True,
            }
        return None


class OAuthFlow:
    """Browser-based OAuth2 authorization code flow."""

    def __init__(
        self,
        auth_url: str,
        token_url: str,
        client_id: str,
        client_secret: str,
        scopes: list[str] | None = None,
        redirect_port: int = 0,
    ):
        self.auth_url = auth_url
        self.token_url = token_url
        self.client_id = client_id
        self.client_secret = client_secret
        self.scopes = scopes or []
        self.redirect_port = redirect_port
        self._auth_code: str | None = None
        self._state = secrets.token_urlsafe(32)

    def run(self, timeout: int = 120) -> dict[str, Any]:
        """Run the full OAuth flow: start server, open browser, wait for callback, exchange code."""
        server = self._start_callback_server()
        actual_port = server.server_address[1]
        redirect_uri = f"http://localhost:{actual_port}/callback"

        params = {
            "client_id": self.client_id,
            "redirect_uri": redirect_uri,
            "response_type": "code",
            "state": self._state,
            "access_type": "offline",
            "prompt": "consent",
        }
        if self.scopes:
            params["scope"] = " ".join(self.scopes)

        auth_url_full = f"{self.auth_url}?{urlencode(params)}"
        webbrowser.open(auth_url_full)

        server_thread = threading.Thread(target=server.handle_request, daemon=True)
        server_thread.start()
        server_thread.join(timeout=timeout)
        server.server_close()

        if self._auth_code is None:
            raise TimeoutError("OAuth callback was not received within the timeout period.")

        return self._exchange_code(self._auth_code, redirect_uri)

    def _start_callback_server(self) -> HTTPServer:
        flow = self

        class CallbackHandler(BaseHTTPRequestHandler):
            def do_GET(self):
                parsed = urlparse(self.path)
                params = parse_qs(parsed.query)
                state = params.get("state", [None])[0]
                code = params.get("code", [None])[0]

                if state != flow._state:
                    self.send_response(400)
                    self.end_headers()
                    self.wfile.write(b"State mismatch.")
                    return

                if code:
                    flow._auth_code = code
                    self.send_response(200)
                    self.send_header("Content-Type", "text/html")
                    self.end_headers()
                    self.wfile.write(
                        b"<html><body><h2>Authorization successful.</h2>"
                        b"<p>You can close this tab and return to your app.</p></body></html>"
                    )
                else:
                    error = params.get("error", ["unknown"])[0]
                    self.send_response(400)
                    self.end_headers()
                    self.wfile.write(f"OAuth error: {error}".encode())

            def log_message(self, *args):
                pass

        server = HTTPServer(("127.0.0.1", self.redirect_port), CallbackHandler)
        return server

    def _exchange_code(self, code: str, redirect_uri: str) -> dict[str, Any]:
        resp = httpx.post(
            self.token_url,
            data={
                "grant_type": "authorization_code",
                "code": code,
                "redirect_uri": redirect_uri,
                "client_id": self.client_id,
                "client_secret": self.client_secret,
            },
            timeout=30,
        )
        resp.raise_for_status()
        return resp.json()
