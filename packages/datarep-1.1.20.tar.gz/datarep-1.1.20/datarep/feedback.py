"""GitHub feedback — share recipes and report bugs via the datarep feedback worker."""

from __future__ import annotations

import json
import os
import platform
import re
from typing import Any

import httpx

FEEDBACK_URL = "https://datarep-feedback.jfru.workers.dev"

_SECRET_PATTERNS = [
    re.compile(r"sk-ant-[A-Za-z0-9_-]+"),
    re.compile(r"sk-[A-Za-z0-9_-]{20,}"),
    re.compile(r"ghp_[A-Za-z0-9]{36,}"),
    re.compile(r"gho_[A-Za-z0-9]{36,}"),
    re.compile(r"Bearer\s+[A-Za-z0-9._\-]+", re.IGNORECASE),
]

_HOME_RE = re.compile(re.escape(str(os.path.expanduser("~"))))


def _sanitize(text: str) -> str:
    """Remove API keys, tokens, and absolute home paths from text."""
    for pat in _SECRET_PATTERNS:
        text = pat.sub("[REDACTED]", text)
    text = _HOME_RE.sub("~", text)
    return text


def _get_system_info() -> dict[str, str]:
    """Collect OS, Python version, and datarep version."""
    try:
        from importlib.metadata import version
        datarep_version = version("datarep")
    except Exception:
        datarep_version = "unknown"
    return {
        "os": f"{platform.system()} {platform.release()}",
        "python": platform.python_version(),
        "datarep": datarep_version,
    }


class GitHubFeedback:
    """Send feedback to the datarep GitHub repo via the feedback worker."""

    def __init__(self, url: str = FEEDBACK_URL):
        self._url = url
        self._client = httpx.Client(timeout=30)

    def share_recipe(self, recipe: dict[str, Any]) -> dict[str, Any]:
        """Share a recipe via the feedback worker."""
        payload = {
            "type": "recipe",
            "recipe_id": recipe["id"],
            "source_name": recipe["source_name"],
            "description": recipe.get("description"),
            "code": _sanitize(recipe["code"]),
            "version": recipe.get("version", 1),
            "times_used": recipe.get("times_used", 0),
            "created_at": recipe.get("created_at", "unknown"),
            "updated_at": recipe.get("updated_at"),
        }
        return self._post(payload)

    def report_bug(
        self,
        title: str,
        error: str,
        traceback: str | None = None,
        log_events: list[dict[str, Any]] | None = None,
    ) -> dict[str, Any]:
        """Report a bug via the feedback worker."""
        sanitized_events = None
        if log_events:
            sanitized_events = [
                json.loads(_sanitize(json.dumps(e, default=str)))
                for e in log_events[-20:]
            ]

        payload: dict[str, Any] = {
            "type": "bug",
            "title": title,
            "error": _sanitize(error),
            "system_info": _get_system_info(),
        }
        if traceback:
            payload["traceback"] = _sanitize(traceback)
        if sanitized_events:
            payload["log_events"] = sanitized_events

        return self._post(payload)

    def _post(self, payload: dict[str, Any]) -> dict[str, Any]:
        """POST to the feedback worker and return the response."""
        resp = self._client.post(self._url, json=payload)
        resp.raise_for_status()
        return resp.json()
