"""App authentication — API key issuance, verification, and audit logging."""

from __future__ import annotations

import json
import secrets
import sqlite3
from datetime import datetime, timezone
from typing import Any

import bcrypt


class AppAuthManager:
    """Manages API keys for consuming apps and audit logging."""

    def __init__(self, conn: sqlite3.Connection):
        self._conn = conn

    def register_app(
        self,
        name: str,
        allowed_sources: list[str] | None = None,
    ) -> tuple[str, str]:
        """Register a new app, returning (app_id, api_key). The key is shown once."""
        app_id = f"app_{secrets.token_hex(8)}"
        api_key = f"dr_{secrets.token_urlsafe(32)}"
        key_hash = bcrypt.hashpw(api_key.encode(), bcrypt.gensalt()).decode()
        now = datetime.now(timezone.utc).isoformat()
        sources_json = json.dumps(allowed_sources) if allowed_sources else None

        self._conn.execute(
            """INSERT INTO apps (app_id, name, api_key_hash, allowed_sources, created_at)
               VALUES (?, ?, ?, ?, ?)""",
            (app_id, name, key_hash, sources_json, now),
        )
        self._conn.commit()
        return app_id, api_key

    def verify_key(self, api_key: str) -> dict[str, Any] | None:
        """Verify an API key. Returns app info if valid, None if invalid."""
        rows = self._conn.execute(
            "SELECT app_id, name, api_key_hash, allowed_sources, revoked_at FROM apps"
        ).fetchall()

        for row in rows:
            if row["revoked_at"] is not None:
                continue
            if bcrypt.checkpw(api_key.encode(), row["api_key_hash"].encode()):
                now = datetime.now(timezone.utc).isoformat()
                self._conn.execute(
                    "UPDATE apps SET last_used_at = ? WHERE app_id = ?",
                    (now, row["app_id"]),
                )
                self._conn.commit()

                allowed = None
                if row["allowed_sources"]:
                    allowed = json.loads(row["allowed_sources"])

                return {
                    "app_id": row["app_id"],
                    "name": row["name"],
                    "allowed_sources": allowed,
                }
        return None

    def check_source_access(self, app_info: dict[str, Any], source_name: str) -> bool:
        """Check if an app is allowed to access a specific source."""
        allowed = app_info.get("allowed_sources")
        if allowed is None:
            return True
        return source_name in allowed

    def revoke(self, app_id: str) -> bool:
        now = datetime.now(timezone.utc).isoformat()
        cursor = self._conn.execute(
            "UPDATE apps SET revoked_at = ? WHERE app_id = ? AND revoked_at IS NULL",
            (now, app_id),
        )
        self._conn.commit()
        return cursor.rowcount > 0

    def list_apps(self) -> list[dict[str, Any]]:
        rows = self._conn.execute(
            "SELECT app_id, name, allowed_sources, created_at, last_used_at, revoked_at FROM apps"
        ).fetchall()
        return [
            {
                "app_id": r["app_id"],
                "name": r["name"],
                "allowed_sources": json.loads(r["allowed_sources"]) if r["allowed_sources"] else None,
                "created_at": r["created_at"],
                "last_used_at": r["last_used_at"],
                "revoked_at": r["revoked_at"],
            }
            for r in rows
        ]

    def log(
        self,
        app_id: str,
        action: str,
        source_name: str | None = None,
        status: str = "success",
        details: dict[str, Any] | None = None,
    ) -> None:
        now = datetime.now(timezone.utc).isoformat()
        self._conn.execute(
            """INSERT INTO audit_log (app_id, action, source_name, status, timestamp, details)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (app_id, action, source_name, status, now, json.dumps(details) if details else None),
        )
        self._conn.commit()

    def get_logs(
        self,
        app_id: str | None = None,
        source_name: str | None = None,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        query = "SELECT * FROM audit_log WHERE 1=1"
        params: list[Any] = []
        if app_id:
            query += " AND app_id = ?"
            params.append(app_id)
        if source_name:
            query += " AND source_name = ?"
            params.append(source_name)
        query += " ORDER BY timestamp DESC LIMIT ?"
        params.append(limit)

        rows = self._conn.execute(query, params).fetchall()
        return [
            {
                "id": r["id"],
                "app_id": r["app_id"],
                "action": r["action"],
                "source_name": r["source_name"],
                "status": r["status"],
                "timestamp": r["timestamp"],
                "details": json.loads(r["details"]) if r["details"] else None,
            }
            for r in rows
        ]
