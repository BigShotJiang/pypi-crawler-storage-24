"""Configuration and paths for datarep."""

from __future__ import annotations

import os
from pathlib import Path


def get_home() -> Path:
    """Return the datarep home directory (~/.datarep or DATAREP_HOME)."""
    return Path(os.environ.get("DATAREP_HOME", Path.home() / ".datarep"))


def get_db_path() -> Path:
    return get_home() / "datarep.db"


def get_recipes_dir() -> Path:
    return get_home() / "recipes"


def get_logs_dir() -> Path:
    return get_home() / "logs"


def get_master_key_path() -> Path:
    return get_home() / "master.key"


def get_server_port() -> int:
    return int(os.environ.get("DATAREP_PORT", "7080"))


def get_server_host() -> str:
    return os.environ.get("DATAREP_HOST", "127.0.0.1")


def get_anthropic_api_key() -> str | None:
    return os.environ.get("ANTHROPIC_API_KEY")


def get_anthropic_base_url() -> str | None:
    return os.environ.get("ANTHROPIC_BASE_URL")


def get_anthropic_model() -> str:
    return os.environ.get("DATAREP_MODEL", "claude-opus-4-6")


def ensure_home() -> Path:
    """Create the datarep home directory and subdirectories if they don't exist."""
    home = get_home()
    home.mkdir(parents=True, exist_ok=True)
    get_recipes_dir().mkdir(exist_ok=True)
    get_logs_dir().mkdir(exist_ok=True)
    return home
