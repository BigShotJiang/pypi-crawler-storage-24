"""
Extracts WhatsApp Web messages via Safari JavaScript injection.

Injects JavaScript into an active WhatsApp Web Safari tab using AppleScript
to access decrypted messages through WhatsApp's internal module system.
Outputs NDJSON to stdout.

Prerequisites:
  - Safari open with web.whatsapp.com logged in
  - Safari > Settings > Developer > "Allow JavaScript from Apple Events"
  - macOS Automation permission granted for Safari
"""

import json
import os
import re
import subprocess
import sys
import time
from datetime import datetime, timezone

JS_PAYLOAD = r'''
window._thyself = 'working';
window._thyselfMessages = [];
(async () => {
    try {
        const { ChatCollection } = self.require('WAWebChatCollection');
        const { loadRecentMsgs } = self.require('WAWebChatLoadMessages');
        const { decryptDataInMsgModel } = self.require('WAWebMsgOpaqueData');
        const chats = ChatCollection.getModelsArray();

        const cutoffTs = __CUTOFF_TS__;
        const allMsgs = [];
        let loadErrors = 0;
        let totalMsgsScanned = 0;
        let chatsWithMsgs = 0;
        let filteredByType = 0;
        let filteredByTime = 0;
        let filteredByBody = 0;

        for (const chat of chats) {
            try {
                await loadRecentMsgs(chat);
            } catch (e) {
                loadErrors++;
            }

            const msgs = chat.msgs ? chat.msgs.getModelsArray() : [];
            if (msgs.length > 0) chatsWithMsgs++;
            totalMsgsScanned += msgs.length;

            for (const m of msgs) {
                if (!m.t || m.t < cutoffTs) { filteredByTime++; continue; }
                if (m.type !== 'chat') { filteredByType++; continue; }
                if (!m.body && m.msgRowOpaqueData) {
                    try { await decryptDataInMsgModel(m); } catch (e) {}
                }
                if (!m.body) { filteredByBody++; continue; }
                allMsgs.push({
                    id: m.id ? m.id._serialized : null,
                    body: m.body,
                    from: m.from ? m.from._serialized : null,
                    to: m.to ? m.to._serialized : null,
                    chat: chat.id ? chat.id._serialized : null,
                    chatName: chat.name || chat.formattedTitle || null,
                    timestamp: m.t,
                    fromMe: m.id ? m.id.fromMe : false,
                    type: m.type,
                    isGroup: chat.isGroup || false
                });
            }
            if (allMsgs.length % 100 === 0 && allMsgs.length > 0) {
                await new Promise(r => setTimeout(r, 50));
            }
        }
        window._thyselfMessages = allMsgs;
        window._thyself = JSON.stringify({
            status: 'done', count: allMsgs.length,
            totalChats: chats.length, chatsWithMsgs: chatsWithMsgs,
            totalMsgsScanned: totalMsgsScanned, loadErrors: loadErrors,
            filteredByTime: filteredByTime, filteredByType: filteredByType,
            filteredByBody: filteredByBody, cutoffUsed: cutoffTs
        });
    } catch (e) {
        window._thyself = JSON.stringify({
            status: 'error', error: e.message,
            stack: e.stack ? e.stack.substring(0, 500) : ''
        });
    }
})();
'''

retry_ids = json.loads(os.environ.get("DATAREP_RETRY_ROW_IDS", "null"))
sync_cursor = os.environ.get("DATAREP_SYNC_CURSOR")


def run_applescript(script):
    result = subprocess.run(
        ["osascript", "-e", script],
        capture_output=True, text=True, timeout=60,
    )
    if result.returncode != 0:
        raise RuntimeError(f"AppleScript error: {result.stderr.strip()}")
    return result.stdout.strip()


def find_whatsapp_tab():
    script = '''
    tell application "Safari"
        repeat with w from 1 to count of windows
            repeat with t from 1 to count of tabs of window w
                if URL of tab t of window w contains "whatsapp" then
                    return (w as text) & "," & (t as text)
                end if
            end repeat
        end repeat
        return "not_found"
    end tell
    '''
    result = run_applescript(script)
    if result == "not_found":
        raise RuntimeError(
            "No WhatsApp Web tab found in Safari. "
            "Open web.whatsapp.com in Safari and log in first."
        )
    parts = result.split(",")
    return int(parts[0]), int(parts[1])


def inject_js(window_idx, tab_idx, js_code):
    escaped = js_code.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n")
    script = f'''
    tell application "Safari"
        do JavaScript "{escaped}" in tab {tab_idx} of window {window_idx}
    end tell
    '''
    return run_applescript(script)


def poll_result(window_idx, tab_idx, timeout=120, interval=3):
    deadline = time.time() + timeout
    while time.time() < deadline:
        time.sleep(interval)
        result = inject_js(window_idx, tab_idx, "window._thyself")
        if result and result != "working":
            return result
    raise TimeoutError("Timed out waiting for WhatsApp Web extraction")


def read_messages_in_batches(window_idx, tab_idx, total, batch_size=50):
    all_messages = []
    for offset in range(0, total, batch_size):
        js = f"JSON.stringify(window._thyselfMessages.slice({offset}, {offset + batch_size}))"
        raw = inject_js(window_idx, tab_idx, js)
        try:
            batch = json.loads(raw)
            all_messages.extend(batch)
        except json.JSONDecodeError:
            print(f"Warning: failed to parse batch at offset {offset}", file=sys.stderr)
    return all_messages


# Determine cutoff timestamp for incremental sync
cutoff_ts = 0
if sync_cursor:
    try:
        cutoff_ts = int(float(sync_cursor)) - 3600
    except ValueError:
        pass

try:
    window_idx, tab_idx = find_whatsapp_tab()
    print(f"Found WhatsApp Web tab (window {window_idx}, tab {tab_idx})", file=sys.stderr)

    title = inject_js(window_idx, tab_idx, "document.title")
    if "WhatsApp" not in title:
        raise RuntimeError(f"Tab doesn't appear to be WhatsApp Web (title: {title})")

    js_with_cutoff = JS_PAYLOAD.replace("__CUTOFF_TS__", str(cutoff_ts))
    inject_js(window_idx, tab_idx, js_with_cutoff)
    raw = poll_result(window_idx, tab_idx)

    data = json.loads(raw)
    if data.get("status") == "error":
        raise RuntimeError(f"Extraction error: {data.get('error')}")

    total = data.get("count", 0)
    print(f"Extraction complete: {total} messages from {data.get('totalChats', '?')} chats", file=sys.stderr)

    if total == 0:
        print(json.dumps({"_stream_complete": True, "rows_delivered": 0, "rows_failed": 0, "failed_row_ids": []}))
        sys.exit(0)

    messages = read_messages_in_batches(window_idx, tab_idx, total)

    success_count = 0
    error_count = 0
    failed_row_ids = []
    max_timestamp = 0

    for msg in messages:
        msg_id = msg.get("id")
        if not msg_id:
            continue

        if retry_ids is not None and msg_id not in retry_ids:
            continue

        try:
            timestamp = msg.get("timestamp", 0)
            sent_at = (
                datetime.fromtimestamp(timestamp, tz=timezone.utc).isoformat()
                if timestamp else None
            )

            record = {
                "message_id": msg_id,
                "content": msg.get("body", ""),
                "sent_at": sent_at,
                "timestamp": timestamp,
                "is_from_me": msg.get("fromMe", False),
                "sender_jid": msg.get("from"),
                "recipient_jid": msg.get("to"),
                "chat_jid": msg.get("chat"),
                "chat_name": msg.get("chatName"),
                "is_group": msg.get("isGroup", False),
                "source": "whatsapp_web",
            }

            print(json.dumps(record, ensure_ascii=False))
            success_count += 1

            if timestamp and timestamp > max_timestamp:
                max_timestamp = timestamp

        except Exception as e:
            error_count += 1
            failed_row_ids.append(msg_id)
            print(json.dumps({"_row_error": True, "row_id": msg_id, "error": str(e)}), file=sys.stderr)

    print(json.dumps({
        "_stream_complete": True,
        "rows_delivered": success_count,
        "rows_failed": error_count,
        "failed_row_ids": failed_row_ids,
        "max_timestamp": max_timestamp,
    }))

except Exception as e:
    print(json.dumps({
        "_stream_complete": True,
        "rows_delivered": 0,
        "rows_failed": 1,
        "failed_row_ids": [],
        "error": str(e),
    }))
    sys.exit(1)
