"""
Extracts ChatGPT conversations via Safari JavaScript injection.

Calls ChatGPT's internal backend API from within an active Safari tab
(bypassing Cloudflare) to fetch conversations and messages.
Outputs NDJSON to stdout.

Prerequisites:
  - Safari open with chatgpt.com logged in
  - Safari > Settings > Developer > "Allow JavaScript from Apple Events"
  - macOS Automation permission granted for Safari
"""

import json
import os
import subprocess
import sys
import time
from datetime import datetime, timezone

BATCH_SIZE = 28
MAX_CONVERSATIONS = 500

retry_ids = json.loads(os.environ.get("DATAREP_RETRY_ROW_IDS", "null"))
sync_cursor = os.environ.get("DATAREP_SYNC_CURSOR")

last_sync_time = 0
if sync_cursor:
    try:
        last_sync_time = float(sync_cursor)
    except ValueError:
        pass


def run_applescript(script):
    result = subprocess.run(
        ["osascript", "-e", script],
        capture_output=True, text=True, timeout=60,
    )
    if result.returncode != 0:
        raise RuntimeError(f"AppleScript error: {result.stderr.strip()}")
    return result.stdout.strip()


def find_chatgpt_tab():
    script = '''
    tell application "Safari"
        repeat with w from 1 to count of windows
            repeat with t from 1 to count of tabs of window w
                if URL of tab t of window w contains "chatgpt.com" then
                    return (w as text) & "," & (t as text)
                end if
            end repeat
        end repeat
        return "not_found"
    end tell
    '''
    result = run_applescript(script)
    if result == "not_found":
        raise RuntimeError(
            "No ChatGPT tab found in Safari. "
            "Open chatgpt.com in Safari and log in first."
        )
    parts = result.split(",")
    return int(parts[0]), int(parts[1])


def safari_js(window_idx, tab_idx, js_code):
    escaped = js_code.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n")
    script = f'''
    tell application "Safari"
        do JavaScript "{escaped}" in tab {tab_idx} of window {window_idx}
    end tell
    '''
    return run_applescript(script)


def get_access_token(window_idx, tab_idx):
    js = """
    (function() {
        var xhr = new XMLHttpRequest();
        xhr.open("GET", "/api/auth/session", false);
        xhr.withCredentials = true;
        xhr.send();
        try { return JSON.parse(xhr.responseText).accessToken; }
        catch(e) { return "ERROR:" + e.message; }
    })()
    """
    token = safari_js(window_idx, tab_idx, js)
    if not token or token.startswith("ERROR:"):
        raise RuntimeError(f"Failed to get ChatGPT access token: {token}")
    return token


def api_call(window_idx, tab_idx, token, endpoint):
    js = f"""
    (function() {{
        var xhr = new XMLHttpRequest();
        xhr.open("GET", "{endpoint}", false);
        xhr.setRequestHeader("Authorization", "Bearer " + "{token}");
        xhr.send();
        if (xhr.status !== 200) return JSON.stringify({{"error": xhr.status, "body": xhr.responseText.substring(0, 200)}});
        return xhr.responseText;
    }})()
    """
    raw = safari_js(window_idx, tab_idx, js)
    if not raw:
        raise RuntimeError(f"Empty response from {endpoint}")
    return json.loads(raw)


def api_call_chunked(window_idx, tab_idx, token, endpoint):
    store_js = f"""
    (function() {{
        var xhr = new XMLHttpRequest();
        xhr.open("GET", "{endpoint}", false);
        xhr.setRequestHeader("Authorization", "Bearer " + "{token}");
        xhr.send();
        if (xhr.status !== 200) {{
            window._thyself_chatgpt = JSON.stringify({{"error": xhr.status}});
        }} else {{
            window._thyself_chatgpt = xhr.responseText;
        }}
        return String(window._thyself_chatgpt.length);
    }})()
    """
    length_str = safari_js(window_idx, tab_idx, store_js)
    if not length_str:
        raise RuntimeError(f"Empty length response from {endpoint}")
    total_len = int(length_str)

    if total_len < 60000:
        raw = safari_js(window_idx, tab_idx, "window._thyself_chatgpt")
        return json.loads(raw)

    chunks = []
    chunk_size = 50000
    for offset in range(0, total_len, chunk_size):
        chunk = safari_js(
            window_idx, tab_idx,
            f"window._thyself_chatgpt.substring({offset}, {offset + chunk_size})"
        )
        chunks.append(chunk)

    full = "".join(chunks)
    safari_js(window_idx, tab_idx, "delete window._thyself_chatgpt")
    return json.loads(full)


def extract_text(content):
    if not content:
        return None
    parts = content.get("parts", [])
    text_parts = []
    for p in parts:
        if isinstance(p, str):
            text_parts.append(p)
        elif isinstance(p, dict) and p.get("content_type") == "image_asset_pointer":
            text_parts.append("[image]")
    combined = "\n".join(text_parts).strip()
    return combined if combined else None


def linearize_messages(mapping):
    root_id = None
    for nid, node in mapping.items():
        if node.get("parent") is None:
            root_id = nid
            break
    if root_id is None:
        return []

    messages = []
    current_id = root_id
    while current_id:
        node = mapping.get(current_id)
        if not node:
            break
        msg = node.get("message")
        if msg:
            content = msg.get("content", {})
            ct = content.get("content_type", "")
            text = extract_text(content) if ct in ("text", "multimodal_text") else None
            role = msg.get("author", {}).get("role", "unknown")
            messages.append({
                "id": msg.get("id", current_id),
                "parent_id": node.get("parent"),
                "role": role,
                "content_type": ct,
                "text": text,
                "model_slug": msg.get("metadata", {}).get("model_slug"),
                "status": msg.get("status"),
                "create_time": msg.get("create_time"),
                "update_time": msg.get("update_time"),
                "weight": msg.get("weight"),
            })
        children = node.get("children", [])
        current_id = children[-1] if children else None

    return messages


try:
    window_idx, tab_idx = find_chatgpt_tab()
    print(f"Found ChatGPT tab (window {window_idx}, tab {tab_idx})", file=sys.stderr)

    token = get_access_token(window_idx, tab_idx)
    print(f"Got access token ({len(token)} chars)", file=sys.stderr)

    new_conv_ids = []
    offset = 0
    done = False
    while not done and offset < MAX_CONVERSATIONS:
        endpoint = f"/backend-api/conversations?offset={offset}&limit={BATCH_SIZE}&order=updated"
        batch = api_call(window_idx, tab_idx, token, endpoint)
        items = batch.get("items", [])
        if not items:
            break

        for item in items:
            update_time = item.get("update_time")
            if isinstance(update_time, str):
                try:
                    ut = datetime.fromisoformat(update_time.replace("Z", "+00:00")).timestamp()
                except ValueError:
                    ut = 0
            else:
                ut = update_time or 0

            if ut <= last_sync_time:
                done = True
                break
            new_conv_ids.append(item["id"])

        offset += len(items)
        if len(items) < BATCH_SIZE:
            break

    print(f"{len(new_conv_ids)} conversations updated since last sync", file=sys.stderr)

    success_count = 0
    error_count = 0
    failed_row_ids = []
    max_create_time = last_sync_time

    for i, conv_id in enumerate(new_conv_ids):
        try:
            conv_data = api_call_chunked(window_idx, tab_idx, token, f"/backend-api/conversation/{conv_id}")
        except Exception as e:
            print(f"Failed to fetch conversation {conv_id}: {e}", file=sys.stderr)
            error_count += 1
            failed_row_ids.append(conv_id)
            continue

        if "error" in conv_data:
            print(f"API error for {conv_id}: {conv_data['error']}", file=sys.stderr)
            error_count += 1
            failed_row_ids.append(conv_id)
            continue

        mapping = conv_data.get("mapping", {})
        messages = linearize_messages(mapping)
        storable = [
            m for m in messages
            if m["role"] in ("user", "assistant", "system")
            and (m["text"] is not None or m["role"] == "system")
        ]

        if not storable:
            continue

        model_slugs = [m["model_slug"] for m in storable if m.get("model_slug")]
        primary_model = model_slugs[-1] if model_slugs else None

        for pos, msg in enumerate(storable):
            if retry_ids is not None and msg["id"] not in retry_ids:
                continue

            try:
                create_time = msg.get("create_time")
                sent_at = (
                    datetime.fromtimestamp(create_time, tz=timezone.utc).isoformat()
                    if create_time else None
                )

                record = {
                    "message_id": msg["id"],
                    "conversation_id": conv_id,
                    "conversation_title": conv_data.get("title"),
                    "parent_id": msg.get("parent_id"),
                    "role": msg["role"],
                    "content_type": msg.get("content_type"),
                    "content": msg.get("text"),
                    "model_slug": msg.get("model_slug"),
                    "model": primary_model,
                    "status": msg.get("status"),
                    "create_time": create_time,
                    "sent_at": sent_at,
                    "update_time": msg.get("update_time"),
                    "position": pos,
                    "weight": msg.get("weight"),
                }

                print(json.dumps(record, ensure_ascii=False))
                success_count += 1

                if create_time and create_time > max_create_time:
                    max_create_time = create_time

            except Exception as e:
                error_count += 1
                failed_row_ids.append(msg["id"])
                print(json.dumps({"_row_error": True, "row_id": msg["id"], "error": str(e)}), file=sys.stderr)

        if (i + 1) % 10 == 0:
            print(f"Processed {i + 1}/{len(new_conv_ids)} conversations ({success_count} messages)", file=sys.stderr)

    print(json.dumps({
        "_stream_complete": True,
        "rows_delivered": success_count,
        "rows_failed": error_count,
        "failed_row_ids": failed_row_ids,
        "max_create_time": max_create_time,
    }))

except Exception as e:
    print(json.dumps({
        "_stream_complete": True,
        "rows_delivered": 0,
        "rows_failed": 1,
        "failed_row_ids": [],
        "error": str(e),
    }))
    sys.exit(1)
