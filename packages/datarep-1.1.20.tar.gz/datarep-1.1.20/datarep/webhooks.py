"""Webhook receiver for push-based data sources."""

from __future__ import annotations

import hashlib
import hmac
import json
from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from datarep.agent import RetrievalAgent
    from datarep.app_auth import AppAuthManager
    from datarep.registry import SourceRegistry


async def handle_webhook(
    source_name: str,
    body: bytes,
    headers: dict[str, str],
    registry: SourceRegistry,
    agent: RetrievalAgent | None,
    app_auth: AppAuthManager | None,
) -> dict[str, Any]:
    """Handle an incoming webhook push from a data source.

    Verifies the signature if a webhook_secret is configured,
    then triggers an incremental sync for the affected source.
    """
    source = registry.get(source_name)
    if source is None:
        return {"status": "error", "error": f"Source '{source_name}' not found."}

    config = source["config"]
    webhook_secret = config.get("webhook_secret")

    if webhook_secret:
        if not _verify_signature(body, headers, webhook_secret):
            return {"status": "error", "error": "Invalid webhook signature."}

    if app_auth:
        app_auth.log("webhook", "webhook_received", source_name, "success",
                     details={"body_size": len(body)})

    try:
        payload = json.loads(body)
    except (json.JSONDecodeError, ValueError):
        payload = {"raw": body.decode("utf-8", errors="replace")}

    event_type = _extract_event_type(payload, headers)

    if agent is not None:
        query = f"Webhook-triggered incremental sync. Event: {event_type}. Payload summary: {json.dumps(payload)[:500]}"
        result = await agent.run(source_name, query)
        return {"status": "accepted", "sync_result": result}

    return {"status": "accepted", "message": "Webhook received but no agent available for sync."}


def _verify_signature(body: bytes, headers: dict[str, str], secret: str) -> bool:
    """Verify webhook signature. Supports common patterns (HMAC-SHA256)."""
    sig_header = (
        headers.get("x-signature-256")
        or headers.get("x-square-hmacsha256-signature")
        or headers.get("x-hub-signature-256")
    )
    if sig_header is None:
        return False

    expected = hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
    sig_value = sig_header.replace("sha256=", "")
    return hmac.compare_digest(expected, sig_value)


def _extract_event_type(payload: dict, headers: dict[str, str]) -> str:
    """Try to extract event type from common webhook patterns."""
    for key in ("type", "event_type", "event", "action"):
        if key in payload:
            return str(payload[key])
    for header in ("x-event-type", "x-github-event", "x-square-event"):
        if header in headers:
            return headers[header]
    return "unknown"
