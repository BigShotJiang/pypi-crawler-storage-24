from datarep.cli import cli

cli()
