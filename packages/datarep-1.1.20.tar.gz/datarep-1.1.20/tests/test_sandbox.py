"""Tests for sandbox execution."""

import asyncio
import json

from datarep.sandbox import execute_code


def test_simple_execution():
    result = asyncio.run(execute_code("print('hello world')"))
    assert result.success
    assert "hello world" in result.stdout


def test_exit_code():
    result = asyncio.run(execute_code("import sys; sys.exit(1)"))
    assert not result.success
    assert result.exit_code == 1


def test_stderr_capture():
    result = asyncio.run(execute_code("import sys; print('err', file=sys.stderr)"))
    assert result.success
    assert "err" in result.stderr


def test_env_injection():
    result = asyncio.run(execute_code(
        "import os; print(os.environ.get('TEST_VAR', 'missing'))",
        env={"TEST_VAR": "injected_value"},
    ))
    assert result.success
    assert "injected_value" in result.stdout


def test_timeout():
    result = asyncio.run(execute_code(
        "import time; time.sleep(10)",
        timeout_seconds=1,
    ))
    assert result.timed_out
    assert not result.success


def test_json_output():
    code = """
import json
for i in range(3):
    print(json.dumps({"item": i}))
"""
    result = asyncio.run(execute_code(code))
    assert result.success
    lines = [l for l in result.stdout.strip().split("\n") if l]
    assert len(lines) == 3
    for i, line in enumerate(lines):
        data = json.loads(line)
        assert data["item"] == i


def test_workdir_env_var():
    code = "import os; print(os.environ.get('DATAREP_WORKDIR', 'missing'))"
    result = asyncio.run(execute_code(code))
    assert result.success
    assert result.stdout.strip() != "missing"


def test_output_file():
    code = """
import os, json
output_path = os.environ['DATAREP_OUTPUT_FILE']
with open(output_path, 'w') as f:
    json.dump({"data": [1, 2, 3]}, f)
print("wrote output file")
"""
    result = asyncio.run(execute_code(code))
    assert result.success
    assert "wrote output file" in result.stdout
