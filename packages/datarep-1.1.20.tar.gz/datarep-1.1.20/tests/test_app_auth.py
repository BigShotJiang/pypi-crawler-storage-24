"""Tests for app authentication."""

from pathlib import Path

from datarep.db import get_connection
from datarep.app_auth import AppAuthManager


def _make_auth(tmp_path: Path):
    db_path = tmp_path / "test.db"
    conn = get_connection(db_path)
    return AppAuthManager(conn), conn


def test_register_and_verify(tmp_path):
    auth, _ = _make_auth(tmp_path)
    app_id, api_key = auth.register_app("test-app")
    assert app_id.startswith("app_")
    assert api_key.startswith("dr_")
    info = auth.verify_key(api_key)
    assert info is not None
    assert info["name"] == "test-app"
    assert info["app_id"] == app_id


def test_invalid_key(tmp_path):
    auth, _ = _make_auth(tmp_path)
    assert auth.verify_key("dr_invalid_key") is None


def test_revoke(tmp_path):
    auth, _ = _make_auth(tmp_path)
    app_id, api_key = auth.register_app("revoke-test")
    assert auth.verify_key(api_key) is not None
    assert auth.revoke(app_id) is True
    assert auth.verify_key(api_key) is None


def test_allowed_sources(tmp_path):
    auth, _ = _make_auth(tmp_path)
    _, api_key = auth.register_app("restricted", allowed_sources=["src1", "src2"])
    info = auth.verify_key(api_key)
    assert info["allowed_sources"] == ["src1", "src2"]
    assert auth.check_source_access(info, "src1") is True
    assert auth.check_source_access(info, "src3") is False


def test_unrestricted_access(tmp_path):
    auth, _ = _make_auth(tmp_path)
    _, api_key = auth.register_app("unrestricted")
    info = auth.verify_key(api_key)
    assert info["allowed_sources"] is None
    assert auth.check_source_access(info, "anything") is True


def test_audit_log(tmp_path):
    auth, _ = _make_auth(tmp_path)
    app_id, _ = auth.register_app("logger")
    auth.log(app_id, "get", "my_source", "success", {"items": 42})
    logs = auth.get_logs(app_id=app_id)
    assert len(logs) == 1
    assert logs[0]["action"] == "get"
    assert logs[0]["source_name"] == "my_source"
    assert logs[0]["details"]["items"] == 42


def test_list_apps(tmp_path):
    auth, _ = _make_auth(tmp_path)
    auth.register_app("app1")
    auth.register_app("app2")
    apps = auth.list_apps()
    assert len(apps) == 2
    names = {a["name"] for a in apps}
    assert names == {"app1", "app2"}
