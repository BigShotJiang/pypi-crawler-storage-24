"""Tests for webhook handling."""

import asyncio
import hashlib
import hmac
import json
from pathlib import Path

from datarep.db import get_connection
from datarep.registry import SourceRegistry
from datarep.webhooks import handle_webhook, _verify_signature, _extract_event_type


def test_verify_signature_valid():
    body = b'{"test": true}'
    secret = "my_secret"
    sig = hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
    headers = {"x-hub-signature-256": f"sha256={sig}"}
    assert _verify_signature(body, headers, secret) is True


def test_verify_signature_invalid():
    body = b'{"test": true}'
    headers = {"x-hub-signature-256": "sha256=bad"}
    assert _verify_signature(body, headers, "my_secret") is False


def test_verify_signature_missing_header():
    assert _verify_signature(b"body", {}, "secret") is False


def test_extract_event_type_from_payload():
    assert _extract_event_type({"type": "order.updated"}, {}) == "order.updated"
    assert _extract_event_type({"event_type": "payment"}, {}) == "payment"


def test_extract_event_type_from_headers():
    assert _extract_event_type({}, {"x-github-event": "push"}) == "push"


def test_extract_event_type_unknown():
    assert _extract_event_type({}, {}) == "unknown"


def test_webhook_unknown_source(tmp_path):
    db_path = tmp_path / "test.db"
    conn = get_connection(db_path)
    registry = SourceRegistry(conn)
    result = asyncio.run(handle_webhook(
        "nonexistent", b'{}', {}, registry, None, None
    ))
    assert result["status"] == "error"


def test_webhook_invalid_signature(tmp_path):
    db_path = tmp_path / "test.db"
    conn = get_connection(db_path)
    registry = SourceRegistry(conn)
    registry.add("webhook_src", "rest_api", {
        "base_url": "https://example.com",
        "webhook_secret": "my_secret",
    })
    result = asyncio.run(handle_webhook(
        "webhook_src", b'{}', {"x-hub-signature-256": "sha256=bad"},
        registry, None, None
    ))
    assert result["status"] == "error"
    assert "signature" in result["error"].lower()


def test_webhook_no_agent(tmp_path):
    db_path = tmp_path / "test.db"
    conn = get_connection(db_path)
    registry = SourceRegistry(conn)
    registry.add("webhook_src", "rest_api", {"base_url": "https://example.com"})
    result = asyncio.run(handle_webhook(
        "webhook_src", b'{"type": "test"}', {}, registry, None, None
    ))
    assert result["status"] == "accepted"
    assert "no agent" in result["message"].lower()
