"""Tests for feedback — recipe sharing and bug reporting via the feedback worker."""

import json
import os

import httpx
import pytest

from datarep.feedback import GitHubFeedback, _sanitize, _get_system_info, FEEDBACK_URL


MOCK_WORKER_RESPONSE = {"success": True, "issueNumber": 42}


def _mock_worker(httpx_mock, *, status=201, body=None):
    httpx_mock.add_response(
        url=FEEDBACK_URL,
        method="POST",
        status_code=status,
        json=body or MOCK_WORKER_RESPONSE,
    )


def test_share_recipe(httpx_mock):
    _mock_worker(httpx_mock)
    fb = GitHubFeedback()

    recipe = {
        "id": "imessage_messages",
        "source_name": "imessage",
        "description": "Get recent messages",
        "code": "import sqlite3\nprint('hello')",
        "version": 3,
        "times_used": 12,
        "created_at": "2025-01-10T00:00:00+00:00",
        "updated_at": "2025-06-15T00:00:00+00:00",
    }

    result = fb.share_recipe(recipe)
    assert result["success"] is True
    assert result["issueNumber"] == 42

    request = httpx_mock.get_request()
    payload = json.loads(request.content)
    assert payload["type"] == "recipe"
    assert payload["recipe_id"] == "imessage_messages"
    assert payload["version"] == 3
    assert payload["times_used"] == 12
    assert "import sqlite3" in payload["code"]


def test_share_recipe_no_updated_at(httpx_mock):
    _mock_worker(httpx_mock)
    fb = GitHubFeedback()

    recipe = {
        "id": "test_recipe",
        "source_name": "test_src",
        "description": "A test",
        "code": "print(1)",
        "version": 1,
        "times_used": 0,
        "created_at": "2025-01-10T00:00:00+00:00",
        "updated_at": None,
    }

    result = fb.share_recipe(recipe)
    assert result["success"] is True

    request = httpx_mock.get_request()
    payload = json.loads(request.content)
    assert payload["updated_at"] is None


def test_report_bug(httpx_mock):
    _mock_worker(httpx_mock)
    fb = GitHubFeedback()

    result = fb.report_bug(
        title="Agent crashes on empty DB",
        error="sqlite3.OperationalError: no such table: messages",
        traceback="Traceback (most recent call last):\n  File ...\nsqlite3.OperationalError",
    )
    assert result["success"] is True
    assert result["issueNumber"] == 42

    request = httpx_mock.get_request()
    payload = json.loads(request.content)
    assert payload["type"] == "bug"
    assert payload["title"] == "Agent crashes on empty DB"
    assert "sqlite3.OperationalError" in payload["error"]
    assert "traceback" in payload
    assert "system_info" in payload
    assert "os" in payload["system_info"]


def test_report_bug_with_log_events(httpx_mock):
    _mock_worker(httpx_mock)
    fb = GitHubFeedback()

    log_events = [
        {"event": "started", "source": "imessage", "timestamp": "2025-01-10T00:00:00"},
        {"event": "error", "error": "something broke", "timestamp": "2025-01-10T00:00:01"},
    ]

    result = fb.report_bug(
        title="Test bug",
        error="something broke",
        log_events=log_events,
    )
    assert result["success"] is True

    request = httpx_mock.get_request()
    payload = json.loads(request.content)
    assert "log_events" in payload
    assert len(payload["log_events"]) == 2


def test_sanitize_api_keys():
    text = "Using key sk-ant-api03-abc123xyz for auth"
    result = _sanitize(text)
    assert "sk-ant-" not in result
    assert "[REDACTED]" in result

    text2 = "Token: sk-proj-abcdef1234567890abcdef"
    result2 = _sanitize(text2)
    assert "sk-proj-" not in result2
    assert "[REDACTED]" in result2


def test_sanitize_github_tokens():
    text = "GITHUB_TOKEN=ghp_ABCDEFabcdef1234567890abcdefABCDEFab"
    result = _sanitize(text)
    assert "ghp_" not in result
    assert "[REDACTED]" in result


def test_sanitize_bearer_tokens():
    text = "Authorization: Bearer eyJhbGciOiJIUzI1NiJ9.payload.signature"
    result = _sanitize(text)
    assert "eyJhbGciOiJ" not in result
    assert "[REDACTED]" in result


def test_sanitize_paths():
    home = os.path.expanduser("~")
    text = f"Reading from {home}/Library/Messages/chat.db"
    result = _sanitize(text)
    assert home not in result
    assert "~/Library/Messages/chat.db" in result


def test_sanitize_preserves_safe_text():
    text = "Recipe ran successfully with 42 rows"
    assert _sanitize(text) == text


def test_get_system_info():
    info = _get_system_info()
    assert "os" in info
    assert "python" in info
    assert "datarep" in info


def test_worker_error(httpx_mock):
    httpx_mock.add_response(
        url=FEEDBACK_URL,
        method="POST",
        status_code=429,
        json={"success": False, "error": "Rate limit exceeded"},
    )
    fb = GitHubFeedback()

    with pytest.raises(httpx.HTTPStatusError):
        fb.share_recipe({
            "id": "test",
            "source_name": "src",
            "code": "print(1)",
        })
