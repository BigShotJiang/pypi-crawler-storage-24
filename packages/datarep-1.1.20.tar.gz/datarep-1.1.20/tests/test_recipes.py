"""Tests for recipe store."""

import os
from pathlib import Path

from datarep.db import get_connection
from datarep.recipes import RecipeStore
from datarep.registry import SourceRegistry


def _make_store(tmp_path: Path):
    db_path = tmp_path / "test.db"
    os.environ["DATAREP_HOME"] = str(tmp_path)
    conn = get_connection(db_path)
    registry = SourceRegistry(conn)
    registry.add("test_src", "local_db", {"path": "/tmp/test.db"})
    return RecipeStore(conn), conn


def test_save_and_get(tmp_path):
    store, _ = _make_store(tmp_path)
    result = store.save("recipe_1", "test_src", "print('hello')", "Test recipe")
    assert result["id"] == "recipe_1"
    assert result["version"] == 1

    recipe = store.get("recipe_1")
    assert recipe is not None
    assert recipe["code"] == "print('hello')"
    assert recipe["description"] == "Test recipe"
    assert recipe["source_name"] == "test_src"
    assert recipe["version"] == 1
    assert recipe["updated_at"] is not None


def test_list(tmp_path):
    store, _ = _make_store(tmp_path)
    store.save("r1", "test_src", "code1", "Recipe 1")
    store.save("r2", "test_src", "code2", "Recipe 2")
    recipes = store.list()
    assert len(recipes) == 2


def test_list_by_source(tmp_path):
    store, conn = _make_store(tmp_path)
    registry = SourceRegistry(conn)
    registry.add("other_src", "rest_api", {"base_url": "https://example.com"})
    store.save("r1", "test_src", "code1")
    store.save("r2", "other_src", "code2")
    recipes = store.list(source_name="test_src")
    assert len(recipes) == 1
    assert recipes[0]["id"] == "r1"


def test_record_use(tmp_path):
    store, _ = _make_store(tmp_path)
    store.save("r1", "test_src", "code")
    assert store.get("r1")["times_used"] == 0
    store.record_use("r1")
    assert store.get("r1")["times_used"] == 1
    store.record_use("r1")
    assert store.get("r1")["times_used"] == 2


def test_delete(tmp_path):
    store, _ = _make_store(tmp_path)
    store.save("r1", "test_src", "code")
    assert store.delete("r1") is True
    assert store.get("r1") is None
    assert store.delete("r1") is False


def test_find_for_source(tmp_path):
    store, _ = _make_store(tmp_path)
    store.save("r1", "test_src", "code1", "First")
    store.save("r2", "test_src", "code2", "Second")
    store.record_use("r1")
    result = store.find_for_source("test_src")
    assert result is not None
    assert result["id"] == "r1"


def test_file_saved(tmp_path):
    store, _ = _make_store(tmp_path)
    store.save("my_recipe", "test_src", "print('hi')", "A recipe")
    recipe_file = tmp_path / "recipes" / "my_recipe.py"
    assert recipe_file.exists()
    content = recipe_file.read_text()
    assert "print('hi')" in content
    assert "my_recipe" in content


def test_save_preserves_stats_on_update(tmp_path):
    store, _ = _make_store(tmp_path)
    result = store.save("r1", "test_src", "code_v1", "First version")
    original_created_at = result["created_at"]
    assert result["version"] == 1

    store.record_use("r1")
    store.record_use("r1")
    store.record_use("r1")
    assert store.get("r1")["times_used"] == 3

    result = store.save("r1", "test_src", "code_v2", "Updated version")
    assert result["version"] == 2
    assert result["created_at"] == original_created_at
    assert result["updated_at"] is not None

    recipe = store.get("r1")
    assert recipe["code"] == "code_v2"
    assert recipe["description"] == "Updated version"
    assert recipe["times_used"] == 3
    assert recipe["created_at"] == original_created_at
    assert recipe["last_used_at"] is not None


def test_version_increments(tmp_path):
    store, _ = _make_store(tmp_path)
    r1 = store.save("r1", "test_src", "code_v1")
    assert r1["version"] == 1

    r2 = store.save("r1", "test_src", "code_v2")
    assert r2["version"] == 2

    r3 = store.save("r1", "test_src", "code_v3")
    assert r3["version"] == 3

    recipe = store.get("r1")
    assert recipe["version"] == 3
    assert recipe["code"] == "code_v3"
