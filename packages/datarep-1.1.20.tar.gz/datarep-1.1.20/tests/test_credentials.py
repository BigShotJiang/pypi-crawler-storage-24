"""Tests for credential store."""

import os
import tempfile
from pathlib import Path

from datarep.db import get_connection
from datarep.credentials import CredentialStore


def _make_store(tmp_path: Path):
    db_path = tmp_path / "test.db"
    key_path = tmp_path / "test.key"
    conn = get_connection(db_path)
    return CredentialStore(conn, key_path=key_path), conn


def test_store_and_retrieve(tmp_path):
    store, _ = _make_store(tmp_path)
    store.store("test_source", "api_key", {"api_key": "sk-123", "extra": "data"})
    result = store.retrieve("test_source")
    assert result is not None
    assert result["api_key"] == "sk-123"
    assert result["extra"] == "data"
    assert result["cred_type"] == "api_key"


def test_retrieve_nonexistent(tmp_path):
    store, _ = _make_store(tmp_path)
    assert store.retrieve("nonexistent") is None


def test_delete(tmp_path):
    store, _ = _make_store(tmp_path)
    store.store("to_delete", "api_key", {"api_key": "x"})
    assert store.delete("to_delete") is True
    assert store.retrieve("to_delete") is None
    assert store.delete("to_delete") is False


def test_overwrite(tmp_path):
    store, _ = _make_store(tmp_path)
    store.store("src", "api_key", {"api_key": "old"})
    store.store("src", "api_key", {"api_key": "new"})
    result = store.retrieve("src")
    assert result["api_key"] == "new"


def test_get_for_injection_api_key(tmp_path):
    store, _ = _make_store(tmp_path)
    store.store("src", "api_key", {"api_key": "my-key"})
    env = store.get_for_injection("src")
    assert env["DATAREP_API_KEY"] == "my-key"
    assert "DATAREP_CRED_JSON" in env


def test_get_for_injection_oauth(tmp_path):
    store, _ = _make_store(tmp_path)
    store.store("src", "oauth2", {
        "access_token": "at-123",
        "refresh_token": "rt-456",
    })
    env = store.get_for_injection("src")
    assert env["DATAREP_ACCESS_TOKEN"] == "at-123"
    assert env["DATAREP_REFRESH_TOKEN"] == "rt-456"


def test_needs_action_no_creds(tmp_path):
    store, conn = _make_store(tmp_path)
    from datarep.registry import SourceRegistry
    registry = SourceRegistry(conn)
    registry.add("api_src", "rest_api", {"base_url": "https://example.com"})
    action = store.needs_action("api_src")
    assert action is not None
    assert action["status"] == "action_required"
    assert action["action_type"] == "api_key_needed"


def test_needs_action_has_creds(tmp_path):
    store, conn = _make_store(tmp_path)
    from datarep.registry import SourceRegistry
    registry = SourceRegistry(conn)
    registry.add("src", "rest_api", {"base_url": "https://example.com"})
    store.store("src", "api_key", {"api_key": "k"})
    assert store.needs_action("src") is None
