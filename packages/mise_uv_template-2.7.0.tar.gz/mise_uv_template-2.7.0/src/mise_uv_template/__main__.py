"""Entry point: python -m mise_uv_template"""


def main() -> None:
    print("Hello from mise_uv_template!")


if __name__ == "__main__":
    main()
