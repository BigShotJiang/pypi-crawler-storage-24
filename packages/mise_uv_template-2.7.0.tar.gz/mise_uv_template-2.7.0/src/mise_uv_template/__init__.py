"""mise_uv_template — generated from mise-uv-template."""

__version__ = "0.1.0"
