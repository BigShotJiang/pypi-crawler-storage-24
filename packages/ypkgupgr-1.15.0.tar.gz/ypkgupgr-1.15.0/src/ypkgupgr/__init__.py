import asyncio
import subprocess
import sys
from pathlib import Path
from typing import Optional

import click
import pyperclip

from .altbuf import alternate_buffer
from .appdata import create_appdata_dirs, log_dir
from .colors import Colors
from .graphics import clear_screen, progress_ring, progress_update
from .ignored import get_ignored_packages, ignore_packages, ignored, unignore_packages
from .ignored import unignore_all as actually_unignore_all
from .logs import init_logging, log_debug, log_info, logger
from .misc import (
    failed,
    finished_count,
    line_count,
    outdated_count,
    ran_from_script,
    ypkgupgr_outdated,
)
from .venv import get_venv_python, is_in_venv, find_venv_in_parents

venv_python: str = sys.executable


def get_python_executable(
    venv_path: Optional[str] = None, no_venv: bool = False
) -> str:
    """Get the appropriate Python executable to use."""
    if no_venv:
        if sys.platform == "win32":
            system_python = Path(sys.base_prefix) / "python.exe"
        else:
            system_python = Path(sys.base_prefix) / "bin" / "python"
        if system_python.exists():
            return str(system_python)
        return sys.executable

    venv_python_path = get_venv_python(venv_path if venv_path else None)
    if venv_python_path:
        return str(venv_python_path)

    if venv_path:
        raise click.ClickException(f"Invalid virtual environment path: {venv_path}")

    return sys.executable


def log_venv_selection(venv_path: Optional[str], no_venv: bool, venv_python: str):
    """Log which Python interpreter is being used."""
    detected_venv = None if no_venv or venv_path else find_venv_in_parents()

    if venv_path:
        log_info(f"Using specified virtual environment: {venv_python}")
    elif detected_venv:
        log_info(f"Using detected virtual environment: {venv_python}")
    elif no_venv or not is_in_venv():
        log_info(f"Using system Python: {venv_python}")
    else:
        log_info(f"Using current virtual environment: {venv_python}")


def check_ignored(name: str, line: int) -> bool:
    """
    Checks if a package is ignored, log and update progress if it is.
    """

    global finished_count

    if name in ignored:  # Package in ignored
        logger.info(f"Package {name} ignored.")
        progress_update(line, f"{name}: {Colors.YELLOW}Ignored")
        finished_count += 1
        progress = int((finished_count / outdated_count) * 100)
        progress_ring(progress)
        return True
    return False


def check_ypkgupgr_script(name: str, line: int) -> bool:
    """
    Checks if the user is on Windows and if this package is updated using the script. Fixes issue #11 (https://github.com/yesseruser/ypkgupgr/issues/11).
    Logs and updates progress if it is.
    """

    global failed
    global ypkgupgr_outdated
    global finished_count

    if name == "ypkgupgr" and ran_from_script and sys.platform == "win32":
        ypkgupgr_outdated = True
        finished_count += 1
        progress = int((finished_count / outdated_count) * 100)
        progress_ring(progress)
        progress_update(line, f"{name}: {Colors.YELLOW}Skipped")
        logger.info("Skipping ypkgupgr. See bottom of the logs for details.")

        if failed == "":
            failed = name
        else:
            failed += ", " + name

        logger.debug("Added ypkgupgr into failed.")

        return True
    return False


def post_update(name: str, line: int, stdout: bytes, return_code: int):
    """
    Checks return code and logs properly. Updates progress.
    """

    global finished_count
    global failed
    global outdated_count

    logger.debug(f"Subprocess ended with code {return_code}")

    # Adds a finished and updates the progress ring.
    finished_count += 1
    progress = int((finished_count / outdated_count) * 100)
    progress_ring(progress)

    # Checks for update success and if failed, logs the package's name into the failed list.
    if return_code == 0:
        progress_update(line, f"{name}: {Colors.GREEN}Done")
        # print(f"Successfully updated {name} ({progress}% - {finished_count}/{outdated_count} complete or failed)")
        logger.info(f"Successfully updated {name}.")
    else:
        logger.error(f"{name} failed to update; below is pip output:")

        # Separates the output string by lines.
        for errline in stdout.strip().decode().splitlines():
            logger.error(errline)

        logger.info("End of pip output.")

        progress_update(line, f"{name}: {Colors.RED}Error")
        # print(f"{name} failed to update. ({progress}% - {finished_count}/{outdated_count} complete or failed)")

        if failed == "":
            failed = name
        else:
            failed += ", " + name

        logger.debug(f"Added {name} to failed.")


async def update(name: str, line: int):
    """
    Updates the package using its name.
    """

    global failed
    global outdated_count
    global finished_count

    get_ignored_packages()

    if check_ignored(name, line):
        return

    if check_ypkgupgr_script(name, line):
        return

    logger.info(f"Updating {name}")
    progress_update(line, f"{name}: {Colors.WHITE}Updating...")

    # Updates the package using python -m pip install --upgrade <name>
    process = await asyncio.create_subprocess_exec(
        venv_python,
        "-m",
        "pip",
        "install",
        "--upgrade",
        name,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )

    logger.debug("Subprocess shell created.")

    # Gets this process' return code.
    return_code = await process.wait()

    post_update(name, line, (await process.communicate())[0], return_code)


def update_sync(name: str, line: int):
    """
    Updates the package using its name synchronously.
    """

    global failed
    global outdated_count
    global finished_count

    get_ignored_packages()

    if check_ignored(name, line):
        return

    if check_ypkgupgr_script(name, line):
        return

    logger.info(f"Updating {name} synchronously")
    progress_update(line, f"{name}: {Colors.WHITE}Updating...")

    # Updates the package using python -m pip install --upgrade <name>
    result = subprocess.run(
        [venv_python, "-m", "pip", "install", "--upgrade", name],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )

    # Gets this process' return code.
    return_code = result.returncode

    logger.debug(f"Subprocess ended with code {return_code}")

    post_update(name, line, result.stdout, return_code)


async def start_updates(lines: list[str]):
    """Updates each package."""
    global line_count

    tasks = []

    line_no = 3  # Tasks start at line 3, because there was 1 line already printed + one to separate.
    for line in lines:
        package_info = line.split()
        package_name = package_info[0]

        logger.debug(f"Starting to update {package_name}")
        tasks.append(asyncio.create_task(update(package_name, line_no)))

        line_no += 1

    line_count = line_no

    for task in tasks:
        await task


def start_updates_sync(lines: list[str]):
    """Updates each package synchronously."""
    global line_count

    line_no = 3
    for line in lines:
        package_info = line.split()
        package_name = package_info[0]

        logger.debug(f"Starting to (synchronously) update {package_name}")
        update_sync(package_name, line_no)

        line_no += 1

    line_count = line_no


def update_packages(non_interactive: bool = False, sync: bool = False):
    """
    If calling from a python file, please use a subprocess instead.
    """

    global outdated_count
    global ypkgupgr_outdated

    logger.info(f"Starting update. Platform: {sys.platform}")

    with alternate_buffer():
        # Clears the screen.
        clear_screen()

        progress_ring(progress=0, intermediate=True)

        # Remember to change string in misc.current_lines if changing this
        print("Getting outdated pip packages...")
        logger.info("Getting outdated packages.")

        # Runs the pip list --outdated command to get the outdated packages.
        outdated_packages = subprocess.check_output(
            [
                venv_python,
                "-m",
                "pip",
                "list",
                "--outdated",
                "--disable-pip-version-check",
            ]
        ).decode("utf-8")

        # Splits the output into lines and ignore the header.
        lines = outdated_packages.strip().split("\n")[2:]

        # Checks if there are any outdated packages.
        if len(lines) <= 0:
            progress_ring(progress=100, complete=True)
            print("No outdated packages found.")
            logger.info("No outdated packages.")

            if not non_interactive:
                input("Press Enter to exit.")

            return

        outdated_count = len(lines)

        logger.info(f"Outdated packages: {lines}")

        clear_screen()

        # Remember to change string in misc.current_lines if changing this
        print("Updating packages using pip...")

        logger.info("Starting to update packages...")

        if sync:
            start_updates_sync(lines)
        else:
            asyncio.run(start_updates(lines))

        logger.info("Finished updating packages.")

        # Empty line before conclusion.
        print(f"\033[{line_count};1H" + Colors.RESET)

        # Prints conclusion.
        if len(failed) == 0:
            print(
                "All outdated packages have been updated. Thank you for using this package."
            )
            logger.info(
                f"All outdated packages updated with a total of {outdated_count} packages."
            )
        else:
            print("The following packages failed to install: " + failed + "\n")
            logger.info(f"The following packages failed to install: {failed}")

        # Warns the user if ypkgupgr hasn't been updated.
        if ypkgupgr_outdated:
            print(
                f'The ypkgupgr package is outdated, and you are using the script. Please use "{sys.executable} -m ypkgupgr" to update it.\n'
            )
            logger.info("ypkgupgr is outdated and the script is used on Windows.")

        progress_ring(progress=100, complete=True)

        if not non_interactive:
            input("Press Enter to exit.")


@click.group(
    context_settings=dict(help_option_names=["-?", "--help"]),
    invoke_without_command=True,
)
@click.option(
    "--clear-log", is_flag=True, help="Clear the log file before writing to it."
)
@click.option(
    "--log-debug", "log_debug_var", is_flag=True, help="Log debug information."
)
@click.option(
    "--ignore", help="Add the package to the ignored file and exit.", multiple=True
)
@click.option(
    "--unignore",
    help="Remove the package from the ignored file (if present) and exit.",
    multiple=True,
)
@click.option(
    "--unignore-all",
    "unignore_all_var",
    is_flag=True,
    help="Clear the ignored file and exit.",
)
@click.option(
    "--non-interactive",
    "non_interactive",
    is_flag=True,
    help="Skip any dialogs that require user input.",
)
@click.option(
    "--sync",
    "sync",
    is_flag=True,
    help="Updates packages synchronously (one-by-one)",
)
@click.option(
    "--venv",
    "venv_path",
    type=str,
    default=None,
    help="Path to virtual environment to use (default: auto-detect)",
)
@click.option(
    "--no-venv",
    "no_venv",
    is_flag=True,
    help="Disable automatic venv detection, use system Python",
)
@click.pass_context
def update_command(
    ctx,
    clear_log,
    log_debug_var,
    ignore,
    unignore,
    unignore_all_var,
    non_interactive,
    sync,
    venv_path,
    no_venv,
):
    global outdated_count
    global ypkgupgr_outdated
    global ran_from_script
    global venv_python

    if venv_path and no_venv:
        raise click.UsageError("Cannot use --venv with --no-venv")

    create_appdata_dirs()

    venv_python = get_python_executable(venv_path, no_venv)
    log_venv_selection(venv_path, no_venv, venv_python)

    # Log commands are handled in init_logging.
    init_logging(clear_log, log_debug_var)

    if ran_from_script:
        log_info("Running from script.")

    if ctx.invoked_subcommand is not None:
        log_info(f"Starting command {ctx.invoked_subcommand}.")
        return

    log_info(
        f"Starting command. Options: {clear_log}, {log_debug_var}, {ignore}, {unignore}, {unignore_all_var}, {non_interactive}, {sync}"
    )

    if len(ignore) > 0:
        ignore_packages(list(ignore))
        # ^ ignores everything after --ignore.

    if len(unignore) > 0:
        unignore_packages(list(unignore))
        # ^ unignores everything after --unignore.

    if unignore_all_var:
        actually_unignore_all()

    # Return after both ignoring and unignoring packages.
    if len(ignore) > 0 or len(unignore) > 0 or unignore_all_var:
        return

    update_packages(non_interactive, sync)


@update_command.command(
    help="Add all packages in the given arguments to the ignored file and exit."
)
@click.argument("to_ignore", nargs=-1)
@click.option(
    "--clear-log", is_flag=True, help="Clear the log file before writing to it."
)
@click.option(
    "--log-debug", "log_debug_var", is_flag=True, help="Log debug information."
)
def ignore(to_ignore, clear_log, log_debug_var):
    init_logging(clear_log, log_debug_var)

    if len(to_ignore) > 0:
        ignore_packages(to_ignore)


@update_command.command(
    help="Remove all packages in the given arguments from the ignored file and exit."
)
@click.option(
    "--clear-log", is_flag=True, help="Clear the log file before writing to it."
)
@click.option(
    "--log-debug", "log_debug_var", is_flag=True, help="Log debug information."
)
@click.argument("to_unignore", nargs=-1)
def unignore(to_unignore, clear_log, log_debug_var):
    init_logging(clear_log, log_debug_var)

    if len(to_unignore) > 0:
        unignore_packages(to_unignore)


@update_command.command(help="Clear the ignored file and exit.")
@click.option(
    "--clear-log", is_flag=True, help="Clear the log file before writing to it."
)
@click.option(
    "--log-debug", "log_debug_var", is_flag=True, help="Log debug information."
)
def unignore_all(clear_log, log_debug_var):
    init_logging(clear_log, log_debug_var)

    actually_unignore_all()


@update_command.command(
    help="Open the logs directory with your default file explorer and exit."
)
@click.option(
    "--clear-log", is_flag=True, help="Clear the log file before writing to it."
)
@click.option(
    "--log-debug", "log_debug_var", is_flag=True, help="Log debug information."
)
def open_logs(clear_log, log_debug_var):
    init_logging(clear_log, log_debug_var)
    click.launch(log_dir)
    log_debug("Opened logs directory.")


@update_command.command(help="Show and copy the path to the logs directory and exit.")
@click.option(
    "--clear-log", is_flag=True, help="Clear the log file before writing to it."
)
@click.option(
    "--log-debug", "log_debug_var", is_flag=True, help="Log debug information."
)
def log_path(clear_log, log_debug_var):
    init_logging(clear_log, log_debug_var)
    print("Log path:")
    print(log_dir)
    pyperclip.copy(log_dir)
    print("Path copied to clipboard.")

    log_debug(f"Copied path to clipboard: {log_dir}")


def run_from_script():
    """
    Runs update_packages() and sets ran_from_script to True.
    That contributes to fixing issue #11 of the original repo. (https://github.com/yesseruser/yesserpackageupdater/issues/11)
    """

    global ran_from_script

    ran_from_script = True

    update_command()
