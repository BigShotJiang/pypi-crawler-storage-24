from unittest.mock import patch

from ypkgupgr import graphics


class TestGraphics:
    """Tests for graphics functionality."""

    def test_clear_screen_calls_subprocess(self):
        """clear_screen should call subprocess.run."""
        with patch("ypkgupgr.graphics.subprocess.run") as mock_run:
            graphics.clear_screen()
            mock_run.assert_called_once()

    def test_clear_screen_uses_clear_on_unix(self):
        """clear_screen should use 'clear' on non-Windows."""
        with patch("ypkgupgr.graphics.subprocess.run") as mock_run:
            with patch("ypkgupgr.graphics.os.name", "posix"):
                graphics.clear_screen()
                mock_run.assert_called_with(["clear"], check=False)

    def test_clear_screen_uses_cls_on_windows(self):
        """clear_screen should use 'cls' on Windows."""
        with patch("ypkgupgr.graphics.subprocess.run") as mock_run:
            with patch("ypkgupgr.graphics.os.name", "nt"):
                graphics.clear_screen()
                mock_run.assert_called_with(["cls"], check=False)

    def test_progress_ring_no_op_without_wt_session(self, monkeypatch):
        """progress_ring should not print without WT_SESSION."""
        monkeypatch.delenv("WT_SESSION", raising=False)

        with patch("ypkgupgr.graphics.failed", ""):
            with patch("builtins.print") as mock_print:
                graphics.progress_ring(50)
                mock_print.assert_not_called()

    def test_progress_ring_prints_with_wt_session(self, monkeypatch):
        """progress_ring should print with WT_SESSION set."""
        monkeypatch.setenv("WT_SESSION", "1")

        with patch("ypkgupgr.graphics.failed", ""):
            with patch("builtins.print") as mock_print:
                graphics.progress_ring(50)
                mock_print.assert_called()

    def test_progress_ring_complete_state(self, monkeypatch):
        """progress_ring should use state 0 when complete."""
        monkeypatch.setenv("WT_SESSION", "1")

        with patch("ypkgupgr.graphics.failed", ""):
            with patch("builtins.print") as mock_print:
                graphics.progress_ring(100, complete=True)
                call_args = mock_print.call_args[0][0]
                assert ";0;" in call_args

    def test_progress_ring_intermediate_state(self, monkeypatch):
        """progress_ring should use state 3 when intermediate."""
        monkeypatch.setenv("WT_SESSION", "1")

        with patch("ypkgupgr.graphics.failed", ""):
            with patch("builtins.print") as mock_print:
                graphics.progress_ring(0, intermediate=True)
                call_args = mock_print.call_args[0][0]
                assert ";3;" in call_args

    def test_progress_ring_error_state(self, monkeypatch):
        """progress_ring should use state 2 when failed."""
        monkeypatch.setenv("WT_SESSION", "1")

        with patch("ypkgupgr.graphics.failed", "some_error"):
            with patch("builtins.print") as mock_print:
                graphics.progress_ring(50)
                call_args = mock_print.call_args[0][0]
                assert ";2;" in call_args

    def test_progress_ring_progress_state(self, monkeypatch):
        """progress_ring should use state 1 when in progress."""
        monkeypatch.setenv("WT_SESSION", "1")

        with patch("ypkgupgr.graphics.failed", ""):
            with patch("builtins.print") as mock_print:
                graphics.progress_ring(50)
                call_args = mock_print.call_args[0][0]
                assert ";1;" in call_args

    def test_progress_update_calls_clear_screen(self):
        """progress_update should call clear_screen."""
        with patch("ypkgupgr.graphics.clear_screen") as mock_clear:
            with patch("ypkgupgr.graphics.current_lines", []):
                graphics.progress_update(0, "New line")
                mock_clear.assert_called_once()

    def test_graphics_module_imports(self):
        """Verify the graphics module can be imported."""
        from ypkgupgr import graphics

        assert hasattr(graphics, "clear_screen")
        assert hasattr(graphics, "progress_ring")
        assert hasattr(graphics, "progress_update")
