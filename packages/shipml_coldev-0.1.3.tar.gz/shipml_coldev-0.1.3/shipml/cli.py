"""
MLX CLI - Vercel para modelos de ML
====================================
Uso:
    python mlx.py deploy ./model.pkl --name iris-demo
    python mlx.py list
    python mlx.py logs iris-demo
    python mlx.py delete iris-demo
"""

import json
import pickle
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich import print as rprint

# ─────────────────────────────────────────────
# SETUP
# ─────────────────────────────────────────────

app = typer.Typer(
    name="shipml",
    help="ShipML — despliega modelos de ML en producción con un comando.",
    add_completion=False,
    rich_markup_mode="rich",
)
console = Console()

# Base de datos local de deploys (JSON simple por ahora)
MLX_HOME = Path.home() / ".mlx"
DEPLOYS_FILE = MLX_HOME / "deploys.json"

RAILWAY_CMD = (
    shutil.which("railway")
    or shutil.which("railway.cmd")
    or str(Path.home() / "AppData/Roaming/npm/railway.cmd")
)


def load_deploys() -> dict:
    MLX_HOME.mkdir(exist_ok=True)
    if not DEPLOYS_FILE.exists():
        return {}
    return json.loads(DEPLOYS_FILE.read_text(encoding="utf-8"))


def save_deploys(deploys: dict) -> None:
    MLX_HOME.mkdir(exist_ok=True)
    DEPLOYS_FILE.write_text(json.dumps(deploys, indent=2), encoding="utf-8")


# ─────────────────────────────────────────────
# LÓGICA CORE (del PoC, refactorizada)
# ─────────────────────────────────────────────

def _detect_model(model_path: Path) -> dict:
    with open(model_path, "rb") as f:
        model = pickle.load(f)

    module = type(model).__module__
    if module.startswith("sklearn"):
        framework = "scikit-learn"
    elif module.startswith("xgboost"):
        framework = "xgboost"
    elif module.startswith("lightgbm"):
        framework = "lightgbm"
    else:
        framework = f"unknown ({module})"

    n_features = None
    for attr in ("n_features_in_", "n_features_", "coef_"):
        if hasattr(model, attr):
            val = getattr(model, attr)
            n_features = val.shape[-1] if attr == "coef_" else int(val)
            break

    return {
        "framework": framework,
        "model_type": type(model).__name__,
        "n_features": n_features,
        "has_proba": hasattr(model, "predict_proba"),
    }


def _generate_server(meta: dict, output_dir: Path) -> None:
    n_features = meta["n_features"]
    has_proba = meta["has_proba"]
    model_type = meta["model_type"]

    if n_features:
        fields = "\n".join(
            f'    x{i}: float = Field(..., description="Feature {i}")'
            for i in range(n_features)
        )
        input_body = f"\nclass PredictInput(BaseModel):\n{fields}\n\n    def to_list(self):\n        return [{', '.join(f'self.x{i}' for i in range(n_features))}]\n"
        input_param = "body: PredictInput"
        features_expr = "[body.to_list()]"
    else:
        input_body = "\nclass PredictInput(BaseModel):\n    features: list[float] = Field(...)\n"
        input_param = "body: PredictInput"
        features_expr = "[body.features]"

    proba_endpoint = ""
    if has_proba:
        proba_endpoint = f"\n@app.post('/predict/proba')\ndef predict_proba({input_param}):\n    return {{\"probabilities\": MODEL.predict_proba({features_expr}).tolist()}}\n"

    server_code = f'''"""Auto-generado por MLX - {model_type}"""
import pickle, os, time
import numpy as np
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
import uvicorn

app = FastAPI(title="MLX - {model_type}", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

with open("model.pkl", "rb") as f:
    MODEL = pickle.load(f)

START_TIME = time.time()
{input_body}
@app.get("/health")
def health():
    return {{"status": "ok", "model": "{model_type}", "uptime_seconds": round(time.time() - START_TIME, 2)}}

@app.post("/predict")
def predict({input_param}):
    try:
        return {{"prediction": MODEL.predict({features_expr}).tolist()}}
    except Exception as e:
        raise HTTPException(status_code=422, detail=str(e))
{proba_endpoint}
if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=int(os.environ.get("PORT", 8080)))
'''
    (output_dir / "server.py").write_text(server_code, encoding="utf-8")


def _generate_dockerfile(output_dir: Path) -> None:
    (output_dir / "Dockerfile").write_text(
        "FROM python:3.11-slim\nWORKDIR /app\nENV PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1\n"
        "COPY requirements.txt .\nRUN pip install --no-cache-dir -r requirements.txt\n"
        "COPY model.pkl .\nCOPY server.py .\n"
        "CMD uvicorn server:app --host 0.0.0.0 --port $PORT\n",
        encoding="utf-8",
    )


def _generate_requirements(output_dir: Path) -> None:
    (output_dir / "requirements.txt").write_text(
        "fastapi==0.111.0\nuvicorn[standard]==0.29.0\nscikit-learn==1.4.2\nnumpy==1.26.4\npydantic==2.7.1\n",
        encoding="utf-8",
    )


def _generate_railway_config(output_dir: Path) -> None:
    config = {
        "$schema": "https://railway.app/railway.schema.json",
        "build": {"builder": "DOCKERFILE", "dockerfilePath": "Dockerfile"},
        "deploy": {"restartPolicyType": "ON_FAILURE", "restartPolicyMaxRetries": 3},
    }
    (output_dir / "railway.json").write_text(json.dumps(config, indent=2), encoding="utf-8")


def _build_docker(app_name: str, output_dir: Path) -> None:
    result = subprocess.run(
        ["docker", "build", "-t", f"mlx-{app_name}:latest", "."],
        cwd=output_dir,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    if result.returncode != 0:
        console.print(result.stderr[-1000:], style="red")
        raise typer.Exit(1)


def _deploy_railway(app_name: str, output_dir: Path) -> str:
    subprocess.run(
        [RAILWAY_CMD, "init", "--name", app_name],
        cwd=output_dir,
        text=True,
    )
    result = subprocess.run(
        [RAILWAY_CMD, "up", "--detach"],
        cwd=output_dir,
        text=True,
    )
    if result.returncode != 0:
        raise typer.Exit(1)

    # Obtener URL
    subprocess.run([RAILWAY_CMD, "domain"], cwd=output_dir, capture_output=True, text=True)
    url_result = subprocess.run(
        [RAILWAY_CMD, "domain"],
        cwd=output_dir,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    url = url_result.stdout.strip().splitlines()[-1] if url_result.stdout.strip() else ""
    if not url.startswith("http"):
        url = f"https://{url}" if url else f"https://{app_name}.up.railway.app"
    return url


# ─────────────────────────────────────────────
# COMANDOS
# ─────────────────────────────────────────────

@app.command()
def deploy(
    model: Path = typer.Argument(..., help="Ruta al modelo .pkl"),
    name: Optional[str] = typer.Option(None, "--name", "-n", help="Nombre del deploy"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Genera archivos sin desplegar"),
):
    """
    Despliega un modelo de ML en producción.

    Ejemplo: mlx deploy ./model.pkl --name iris-demo
    """
    # Validaciones
    if not model.exists():
        console.print(f"[red]Error:[/red] Archivo no encontrado: {model}")
        raise typer.Exit(1)
    if model.suffix not in (".pkl", ".pickle"):
        console.print(f"[red]Error:[/red] Formato no soportado: {model.suffix} (usa .pkl)")
        raise typer.Exit(1)

    app_name = (name or model.stem).lower().replace("_", "-").replace(" ", "-")

    console.print(f"\n[bold cyan]MLX Deploy[/bold cyan] — {model.name}")
    console.rule()

    build_dir = Path(tempfile.mkdtemp(prefix="mlx_build_"))

    try:
        # Detectar
        with Progress(SpinnerColumn(), TextColumn("{task.description}"), console=console) as p:
            task = p.add_task("Detectando modelo...", total=None)
            meta = _detect_model(model)
            p.update(task, description=f"[green]✓[/green] {meta['framework']} — {meta['model_type']} ({meta['n_features']} features)")
            p.stop()

        shutil.copy(model, build_dir / "model.pkl")

        # Generar archivos
        with Progress(SpinnerColumn(), TextColumn("{task.description}"), console=console) as p:
            task = p.add_task("Generando servidor FastAPI...", total=None)
            _generate_server(meta, build_dir)
            _generate_requirements(build_dir)
            _generate_dockerfile(build_dir)
            _generate_railway_config(build_dir)
            p.update(task, description="[green]✓[/green] Archivos generados (server.py, Dockerfile, railway.json)")
            p.stop()

        if dry_run:
            console.print(f"\n[yellow]Dry run completo.[/yellow] Archivos en: {build_dir}")
            for f in sorted(build_dir.iterdir()):
                console.print(f"  {f.name:25s} [dim]{f.stat().st_size} bytes[/dim]")
            return

        # Docker
        with Progress(SpinnerColumn(), TextColumn("{task.description}"), console=console) as p:
            task = p.add_task(f"Construyendo imagen Docker...", total=None)
            _build_docker(app_name, build_dir)
            p.update(task, description=f"[green]✓[/green] Imagen Docker: mlx-{app_name}:latest")
            p.stop()

        # Railway
        console.print("\n[bold]Desplegando en Railway...[/bold]")
        url = _deploy_railway(app_name, build_dir)

        # Guardar deploy localmente
        deploys = load_deploys()
        deploys[app_name] = {
            "name": app_name,
            "url": url,
            "model": str(model.resolve()),
            "framework": meta["framework"],
            "model_type": meta["model_type"],
            "n_features": meta["n_features"],
        }
        save_deploys(deploys)

        # Output final
        console.rule()
        console.print(f"\n[bold green]Deploy exitoso![/bold green]")
        console.print(f"  [bold]URL[/bold]     : {url}")
        console.print(f"  [bold]Health[/bold]  : {url}/health")
        console.print(f"  [bold]Predict[/bold] : POST {url}/predict")
        console.print(f"  [bold]Docs[/bold]    : {url}/docs\n")

        if meta["n_features"]:
            sample = {f"x{i}": 0.0 for i in range(min(meta["n_features"], 4))}
            console.print("[dim]Ejemplo:[/dim]")
            console.print(f'[dim]  curl -X POST {url}/predict -H "Content-Type: application/json" -d \'{json.dumps(sample)}\'[/dim]')

    except Exception as e:
        console.print(f"\n[red]Error:[/red] {e}")
        raise typer.Exit(1)
    finally:
        if not dry_run:
            shutil.rmtree(build_dir, ignore_errors=True)


@app.command(name="list")
def list_deploys():
    """
    Lista todos los modelos desplegados.

    Ejemplo: mlx list
    """
    deploys = load_deploys()

    if not deploys:
        console.print("[yellow]No hay deploys registrados.[/yellow]")
        console.print("Ejecuta [bold]mlx deploy ./model.pkl[/bold] para desplegar tu primer modelo.")
        return

    table = Table(title="MLX — Modelos en producción", show_lines=True)
    table.add_column("Nombre", style="cyan bold")
    table.add_column("Framework", style="green")
    table.add_column("Tipo")
    table.add_column("Features", justify="right")
    table.add_column("URL", style="blue")

    for name, d in deploys.items():
        table.add_row(
            d["name"],
            d.get("framework", "—"),
            d.get("model_type", "—"),
            str(d.get("n_features", "—")),
            d.get("url", "—"),
        )

    console.print(table)


@app.command()
def logs(
    name: str = typer.Argument(..., help="Nombre del deploy"),
):
    """
    Muestra los logs de un modelo desplegado.

    Ejemplo: mlx logs iris-demo
    """
    deploys = load_deploys()

    if name not in deploys:
        console.print(f"[red]Error:[/red] Deploy '{name}' no encontrado.")
        console.print("Ejecuta [bold]mlx list[/bold] para ver los deploys disponibles.")
        raise typer.Exit(1)

    console.print(f"\n[bold cyan]Logs de {name}[/bold cyan]")
    console.rule()

    subprocess.run([RAILWAY_CMD, "logs", "--tail", "100"], text=True)


@app.command()
def delete(
    name: str = typer.Argument(..., help="Nombre del deploy a eliminar"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Confirmar sin preguntar"),
):
    """
    Elimina un modelo desplegado.

    Ejemplo: mlx delete iris-demo
    """
    deploys = load_deploys()

    if name not in deploys:
        console.print(f"[red]Error:[/red] Deploy '{name}' no encontrado.")
        console.print("Ejecuta [bold]mlx list[/bold] para ver los deploys disponibles.")
        raise typer.Exit(1)

    if not yes:
        confirmed = typer.confirm(f"Eliminar '{name}'? Esta accion no se puede deshacer")
        if not confirmed:
            console.print("Cancelado.")
            raise typer.Exit(0)

    with Progress(SpinnerColumn(), TextColumn("{task.description}"), console=console) as p:
        task = p.add_task(f"Eliminando {name}...", total=None)
        result = subprocess.run(
            [RAILWAY_CMD, "down", "--yes"],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
        )
        if result.returncode != 0:
            p.stop()
            console.print(f"[yellow]Aviso:[/yellow] No se pudo eliminar de Railway. Elimina manualmente en railway.com")
        else:
            p.update(task, description=f"[green]✓[/green] {name} eliminado de Railway")
            p.stop()

    # Eliminar del registro local
    del deploys[name]
    save_deploys(deploys)
    console.print(f"[green]✓[/green] '{name}' eliminado del registro local.")


# ─────────────────────────────────────────────
# ENTRY POINT
# ─────────────────────────────────────────────

if __name__ == "__main__":
    app()