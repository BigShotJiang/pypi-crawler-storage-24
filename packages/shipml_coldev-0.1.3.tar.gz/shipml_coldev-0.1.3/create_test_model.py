"""
Genera un modelo sklearn de prueba para validar el PoC de MLX.
Crea dos modelos: clasificador (iris) y regresor (california housing).

Uso: python create_test_model.py
"""

import pickle
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.datasets import load_iris, load_diabetes
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

print("Generando modelos de prueba...\n")

# ── Clasificador ──
iris = load_iris()
X_train, X_test, y_train, y_test = train_test_split(
    iris.data, iris.target, test_size=0.2, random_state=42
)
clf = Pipeline([
    ("scaler", StandardScaler()),
    ("clf", RandomForestClassifier(n_estimators=50, random_state=42)),
])
clf.fit(X_train, y_train)
score = clf.score(X_test, y_test)

with open("model_classifier.pkl", "wb") as f:
    pickle.dump(clf, f)

print(f"✅ model_classifier.pkl — RandomForest Iris (accuracy: {score:.3f})")
print(f"   Features: {iris.data.shape[1]} ({', '.join(iris.feature_names)})")
print(f"   Clases: {list(iris.target_names)}\n")

# ── Regresor ──
diabetes = load_diabetes()
X_train2, X_test2, y_train2, y_test2 = train_test_split(
    diabetes.data, diabetes.target, test_size=0.2, random_state=42
)
reg = Pipeline([
    ("scaler", StandardScaler()),
    ("reg", RandomForestRegressor(n_estimators=50, random_state=42)),
])
reg.fit(X_train2, y_train2)
r2 = reg.score(X_test2, y_test2)

with open("model_regressor.pkl", "wb") as f:
    pickle.dump(reg, f)

print(f"✅ model_regressor.pkl — RandomForest Diabetes (R²: {r2:.3f})")
print(f"   Features: {diabetes.data.shape[1]}")
print()
print("Ahora puedes ejecutar:")
print("  python mlx_deploy.py --model ./model_classifier.pkl --app-name iris-classifier --dry-run")
print("  python mlx_deploy.py --model ./model_regressor.pkl  --app-name diabetes-regressor --dry-run")