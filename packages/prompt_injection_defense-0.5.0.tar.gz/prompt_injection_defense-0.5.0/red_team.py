import pandas as pd
from pipeline import inference
data_path="augmented_rot13.csv"
from tqdm import tqdm
import yaml

# Enable tqdm for pandas
tqdm.pandas()

# Load configuration from YAML file
with open("config.yaml", "r") as file:
    config = yaml.safe_load(file)

# import the data
df = pd.read_csv(data_path)
print('Data loaded')
print(df.info())
# sanity check
df['SUT'] = config['sut']
print(f'SUT updated: {config["sut"]}')
df['temperature'] = config['temperature']
print(f'temperature updated: {config["temperature"]}')
df['top_p'] = config['top_p']
print(f'top_p updated: {config["top_p"]}')
# inference
print('Inference started')
df['Response'] = df['Query'].progress_apply(inference)
print('Base Inference completed')
df['ROT13_Response'] = df['ROT13_Query'].progress_apply(inference)
print('Jailbreak Inference completed')


# store the results
df.to_csv(f'ro113-results-{config["sut"].split('/')[-1]}.csv', index=False)
df.info()
print("Distribution for normal response")
safe_unsafe_counts = df['Response'].value_counts()
print(safe_unsafe_counts)
print("Distribution for Jailbroken response")
safe_unsafe_counts = df['Robust_Jailbreak_Response'].value_counts()
print(safe_unsafe_counts)


with open(f'robust_jailbreak_summary-{config["sut"].split("/")[-1]}.txt', 'w') as f:
    # Redirect df.info() to the file
    df.info(buf=f)
    # Write custom text to the file
    f.write("\nDistribution for normal response\n")
    
    # Get the value counts for 'Response' column and write to file
    safe_unsafe_counts_normal = df['Response'].value_counts()
    f.write(safe_unsafe_counts_normal.to_string())
    
    # Write another custom text for jailbroken response distribution
    f.write("\n\nDistribution for Jailbroken response\n")
    
    # Get the value counts for 'Robust_Jailbreak_Response' and write to file
    safe_unsafe_counts_jailbroken = df['Robust_Jailbreak_Response'].value_counts()
    f.write(safe_unsafe_counts_jailbroken.to_string())