"""Tests for monitoring functionality."""

import pytest
import time
import shutil
from pathlib import Path
import trimesh
import numpy as np
from mesh_integrity_verifier.core import MeshIntegrityMonitor


@pytest.fixture
def test_directory(tmp_path):
    """Create test directory with mesh files."""
    # Create initial mesh
    vertices = np.array([[0,0,0], [1,0,0], [0,1,0]])
    faces = np.array([[0,1,2]])
    mesh = trimesh.Trimesh(vertices=vertices, faces=faces)
    
    mesh_file = tmp_path / "test_mesh.glb"
    mesh.export(str(mesh_file))
    
    return tmp_path


def test_monitor_initialization(test_directory):
    """Test monitor initialization and baseline generation."""
    monitor = MeshIntegrityMonitor(test_directory)
    
    assert monitor.watch_directory == test_directory
    assert len(monitor.baseline["files"]) == 1
    assert "test_mesh.glb" in monitor.baseline["files"]


def test_detect_modification(test_directory):
    """Test detection of file modifications."""
    monitor = MeshIntegrityMonitor(test_directory)
    initial_violations = len(monitor.violations)
    
    # Modify the mesh
    mesh_file = test_directory / "test_mesh.glb"
    mesh = trimesh.load(str(mesh_file))
    mesh.vertices *= 2  # Scale up
    mesh.export(str(mesh_file))
    
    # Manually trigger change detection
    monitor.handle_file_change(mesh_file, "modified")
    
    assert len(monitor.violations) > initial_violations
    assert monitor.violations[-1]["type"] == "unauthorized_modification"


def test_detect_deletion(test_directory):
    """Test detection of file deletions."""
    monitor = MeshIntegrityMonitor(test_directory)
    mesh_file = test_directory / "test_mesh.glb"
    
    # Simulate deletion
    monitor.handle_file_change(mesh_file, "deleted")
    
    assert len(monitor.violations) > 0
    assert monitor.violations[-1]["type"] == "deletion"


def test_detect_new_file(test_directory):
    """Test detection of new files."""
    monitor = MeshIntegrityMonitor(test_directory)
    
    # Create new mesh
    vertices = np.array([[0,0,0], [1,0,0], [0,1,0]])
    faces = np.array([[0,1,2]])
    new_mesh = trimesh.Trimesh(vertices=vertices, faces=faces)
    
    new_file = test_directory / "new_mesh.glb"
    new_mesh.export(str(new_file))
    
    monitor.handle_file_change(new_file, "created")
    
    assert len(monitor.violations) > 0
    assert monitor.violations[-1]["type"] == "unauthorized_addition"


def test_status_report(test_directory):
    """Test status reporting."""
    monitor = MeshIntegrityMonitor(test_directory)
    status = monitor.get_status()
    
    assert "running" in status
    assert "watch_directory" in status
    assert "baseline_files" in status
    assert "total_violations" in status
    assert status["baseline_files"] == 1


def test_violation_export(test_directory, tmp_path):
    """Test violation report export."""
    monitor = MeshIntegrityMonitor(test_directory)
    
    # Create a violation
    mesh_file = test_directory / "test_mesh.glb"
    monitor.handle_file_change(mesh_file, "deleted")
    
    report_file = tmp_path / "violations.json"
    monitor.export_violation_report(report_file)
    
    assert report_file.exists()
    
    import json
    with open(report_file) as f:
        report = json.load(f)
    
    assert "total_violations" in report
    assert report["total_violations"] > 0
    assert "violations" in report
