"""Tests for mesh diff functionality."""

import pytest
from pathlib import Path
import trimesh
import numpy as np
from mesh_integrity_verifier.diff import MeshDiffer


@pytest.fixture
def mesh_pair():
    """Create two related test meshes."""
    vertices_a = np.array([[0,0,0], [1,0,0], [0,1,0], [0,0,1]])
    faces_a = np.array([[0,1,2], [0,1,3]])
    mesh_a = trimesh.Trimesh(vertices=vertices_a, faces=faces_a)
    
    # Create modified version (scaled up)
    mesh_b = mesh_a.copy()
    mesh_b.vertices *= 1.5
    
    return mesh_a, mesh_b


def test_compare_identical_meshes(mesh_pair):
    """Test comparison of identical meshes."""
    mesh_a, _ = mesh_pair
    differ = MeshDiffer()
    
    result = differ.compare_meshes(mesh_a, mesh_a)
    
    assert result["vertex_diff"] == 0
    assert result["face_diff"] == 0
    assert result["similarity"] > 0.99  # Should be very similar


def test_compare_different_meshes(mesh_pair):
    """Test comparison of different meshes."""
    mesh_a, mesh_b = mesh_pair
    differ = MeshDiffer()
    
    result = differ.compare_meshes(mesh_a, mesh_b)
    
    assert result["vertex_diff"] == 0  # Same vertex count
    assert result["face_diff"] == 0    # Same face count
    assert result["volume_change"] > 0  # Volume increased
    assert 0 < result["similarity"] < 1  # Somewhat similar but not identical


def test_html_report_generation(mesh_pair, tmp_path):
    """Test HTML report generation."""
    mesh_a, mesh_b = mesh_pair
    differ = MeshDiffer()
    
    # Save test meshes
    file_a = tmp_path / "original.glb"
    file_b = tmp_path / "modified.glb"
    mesh_a.export(str(file_a))
    mesh_b.export(str(file_b))
    
    output_file = tmp_path / "report.html"
    result = differ.generate_html_report(file_a, file_b, output_file)
    
    assert output_file.exists()
    assert "summary" in result
    assert result["summary"]["vertex_diff"] == 0
    
    # Verify HTML content
    html_content = output_file.read_text()
    assert "Mesh Integrity Diff Report" in html_content
    assert "original.glb" in html_content
    assert "modified.glb" in html_content
