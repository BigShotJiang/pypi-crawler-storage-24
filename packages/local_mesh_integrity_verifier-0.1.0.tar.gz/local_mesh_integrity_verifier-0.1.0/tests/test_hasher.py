"""Tests for mesh hashing functionality."""

import pytest
from pathlib import Path
import trimesh
import numpy as np
from mesh_integrity_verifier.hasher import MeshHasher


@pytest.fixture
def test_mesh():
    """Create a simple test mesh."""
    vertices = np.array([
        [0, 0, 0],
        [1, 0, 0],
        [0, 1, 0],
        [0, 0, 1]
    ])
    faces = np.array([
        [0, 1, 2],
        [0, 1, 3],
        [0, 2, 3],
        [1, 2, 3]
    ])
    return trimesh.Trimesh(vertices=vertices, faces=faces)


def test_hash_consistency(test_mesh):
    """Test that identical meshes produce identical hashes."""
    hasher = MeshHasher()
    hash1 = hasher.hash_mesh_geometry(test_mesh)
    hash2 = hasher.hash_mesh_geometry(test_mesh)
    assert hash1 == hash2


def test_hash_changes_with_geometry(test_mesh):
    """Test that hash changes when geometry changes."""
    hasher = MeshHasher()
    original_hash = hasher.hash_mesh_geometry(test_mesh)
    
    # Modify vertices
    modified_mesh = test_mesh.copy()
    modified_mesh.vertices[0] = [0.1, 0, 0]
    modified_hash = hasher.hash_mesh_geometry(modified_mesh)
    
    assert original_hash != modified_hash


def test_hash_ignores_minor_precision(test_mesh):
    """Test that hash ignores floating point noise below threshold."""
    hasher = MeshHasher()
    original_hash = hasher.hash_mesh_geometry(test_mesh)
    
    # Add tiny noise (below normalization threshold)
    noisy_mesh = test_mesh.copy()
    noisy_mesh.vertices += np.random.randn(*noisy_mesh.vertices.shape) * 1e-8
    noisy_hash = hasher.hash_mesh_geometry(noisy_mesh)
    
    assert original_hash == noisy_hash


def test_file_hash_includes_metadata(tmp_path):
    """Test that file hashing captures metadata."""
    hasher = MeshHasher()
    
    # Create test mesh file
    vertices = np.array([[0,0,0], [1,0,0], [0,1,0]])
    faces = np.array([[0,1,2]])
    mesh = trimesh.Trimesh(vertices=vertices, faces=faces)
    
    test_file = tmp_path / "test.glb"
    mesh.export(str(test_file))
    
    result = hasher.hash_file(test_file)
    
    assert "hash" in result
    assert "vertices" in result
    assert "faces" in result
    assert "file_size" in result
    assert result["vertices"] == 3
    assert result["faces"] == 1
