# Unity Integration Example

Monitor your Unity project's mesh assets in real-time while working in the editor.

## Setup

1. **Generate baseline for your Unity project:**

```bash
cd /path/to/UnityProject
mesh-integrity baseline ./Assets/Models -o mesh_baseline.json
```

2. **Start monitoring with web dashboard:**

```bash
mesh-integrity watch ./Assets/Models --manifest mesh_baseline.json --web
```

3. **Open dashboard** at `http://localhost:5050`

## Workflow

### During Development

The monitor runs in the background while you work in Unity:

1. Import new mesh from Blender → **Alert: New file detected**
2. Modify mesh in Unity editor → **Alert: Geometry changed**
3. Delete unused asset → **Alert: File deleted**

### Before Committing

Check integrity before pushing to Git:

```bash
mesh-integrity verify ./Assets/Models mesh_baseline.json
```

If violations are detected:

```bash
# Generate diff for each modified file
mesh-integrity diff Assets/Models/original.glb Assets/Models/modified.glb -o review.html
```

Review `review.html` to decide if changes should be committed.

### Updating Baseline

After intentional changes:

```bash
# Regenerate baseline
mesh-integrity baseline ./Assets/Models -o mesh_baseline.json

# Commit updated baseline
git add mesh_baseline.json
git commit -m "Update mesh baseline after character model revision"
```

## CI/CD Integration

Add to your Unity Cloud Build post-build script:

```bash
#!/bin/bash
# Verify asset integrity before deploying
mesh-integrity verify ./Assets/Models mesh_baseline.json

if [ $? -ne 0 ]; then
  echo "Asset integrity check failed! Build aborted."
  exit 1
fi

echo "Asset integrity verified ✓"
```

## Monitoring Multiple Projects

Use different ports for each project:

```bash
# Project A
cd ~/UnityProjects/ProjectA
mesh-integrity watch ./Assets/Models --web --port 5050 &

# Project B
cd ~/UnityProjects/ProjectB
mesh-integrity watch ./Assets/Models --web --port 5051 &

# Access at localhost:5050 and localhost:5051
```

## Performance Tips

- **Only monitor mesh directories**, not entire Assets folder
- **Use .gitignore** to exclude generated files:
  ```
  # .gitignore
  *.violation_report.json
  *_diff_report.html
  ```
- **Baseline large projects in chunks** if initial scan is slow
