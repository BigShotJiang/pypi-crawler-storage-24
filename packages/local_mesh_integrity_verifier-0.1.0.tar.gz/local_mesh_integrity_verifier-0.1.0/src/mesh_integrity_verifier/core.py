"""Core monitoring logic for mesh integrity verification."""

import json
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Set
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler, FileSystemEvent
from .hasher import MeshHasher


class MeshFileHandler(FileSystemEventHandler):
    """Handles file system events for mesh files."""

    def __init__(self, monitor: "MeshIntegrityMonitor"):
        self.monitor = monitor

    def on_modified(self, event: FileSystemEvent):
        if event.is_directory:
            return
        path = Path(event.src_path)
        if path.suffix.lower() in self.monitor.extensions:
            self.monitor.handle_file_change(path, "modified")

    def on_created(self, event: FileSystemEvent):
        if event.is_directory:
            return
        path = Path(event.src_path)
        if path.suffix.lower() in self.monitor.extensions:
            self.monitor.handle_file_change(path, "created")

    def on_deleted(self, event: FileSystemEvent):
        if event.is_directory:
            return
        path = Path(event.src_path)
        if path.suffix.lower() in self.monitor.extensions:
            self.monitor.handle_file_change(path, "deleted")


class MeshIntegrityMonitor:
    """Real-time monitoring system for 3D asset integrity."""

    def __init__(
        self,
        watch_directory: Path,
        baseline_manifest: Optional[Path] = None,
        extensions: Optional[List[str]] = None,
    ):
        self.watch_directory = Path(watch_directory).resolve()
        self.extensions = set(extensions or [".glb", ".gltf", ".fbx", ".obj", ".usdz"])
        self.hasher = MeshHasher()

        # Load or generate baseline
        if baseline_manifest and baseline_manifest.exists():
            with open(baseline_manifest) as f:
                self.baseline = json.load(f)
        else:
            print("📋 Generating initial baseline...")
            self.baseline = self.hasher.generate_directory_manifest(
                self.watch_directory, list(self.extensions)
            )

        self.violations: List[Dict] = []
        self.observer: Optional[Observer] = None
        self._running = False

    def handle_file_change(self, file_path: Path, event_type: str):
        """Process a file change event."""
        rel_path = str(file_path.relative_to(self.watch_directory))
        timestamp = datetime.now().isoformat()

        if event_type == "deleted":
            if rel_path in self.baseline["files"]:
                violation = {
                    "type": "deletion",
                    "file": rel_path,
                    "timestamp": timestamp,
                    "original_hash": self.baseline["files"][rel_path]["hash"],
                }
                self.violations.append(violation)
                print(f"🚨 [{timestamp}] DELETED: {rel_path}")
            return

        # For created/modified files, compute new hash
        try:
            file_data = self.hasher.hash_file(file_path)
            current_hash = file_data["hash"]

            if event_type == "created":
                if rel_path not in self.baseline["files"]:
                    violation = {
                        "type": "unauthorized_addition",
                        "file": rel_path,
                        "timestamp": timestamp,
                        "new_hash": current_hash,
                        "vertices": file_data["vertices"],
                        "faces": file_data["faces"],
                    }
                    self.violations.append(violation)
                    print(f"➕ [{timestamp}] NEW FILE: {rel_path}")
                return

            # Modified file
            if rel_path in self.baseline["files"]:
                baseline_hash = self.baseline["files"][rel_path]["hash"]
                if current_hash != baseline_hash:
                    violation = {
                        "type": "unauthorized_modification",
                        "file": rel_path,
                        "timestamp": timestamp,
                        "original_hash": baseline_hash,
                        "new_hash": current_hash,
                        "original_vertices": self.baseline["files"][rel_path]["vertices"],
                        "new_vertices": file_data["vertices"],
                        "original_faces": self.baseline["files"][rel_path]["faces"],
                        "new_faces": file_data["faces"],
                    }
                    self.violations.append(violation)
                    print(f"⚠️  [{timestamp}] MODIFIED: {rel_path}")
                    print(
                        f"    Vertices: {violation['original_vertices']} → {violation['new_vertices']}"
                    )
                    print(f"    Faces: {violation['original_faces']} → {violation['new_faces']}")

        except Exception as e:
            print(f"❌ Error processing {rel_path}: {e}")

    def start_monitoring(self):
        """Start the file system watcher."""
        self._running = True
        event_handler = MeshFileHandler(self)
        self.observer = Observer()
        self.observer.schedule(event_handler, str(self.watch_directory), recursive=True)
        self.observer.start()

        try:
            while self._running:
                time.sleep(1)
        except KeyboardInterrupt:
            self.stop_monitoring()

    def stop_monitoring(self):
        """Stop the file system watcher."""
        if self.observer:
            self.observer.stop()
            self.observer.join()
        self._running = False

    def get_status(self) -> Dict:
        """Get current monitoring status."""
        return {
            "running": self._running,
            "watch_directory": str(self.watch_directory),
            "baseline_files": len(self.baseline["files"]),
            "total_violations": len(self.violations),
            "recent_violations": self.violations[-10:],
            "extensions": list(self.extensions),
        }

    def export_violation_report(self, output_path: Path):
        """Export violations to JSON report."""
        report = {
            "generated_at": datetime.now().isoformat(),
            "watch_directory": str(self.watch_directory),
            "baseline_timestamp": self.baseline["generated_at"],
            "total_violations": len(self.violations),
            "violations": self.violations,
        }

        with open(output_path, "w") as f:
            json.dump(report, f, indent=2)
