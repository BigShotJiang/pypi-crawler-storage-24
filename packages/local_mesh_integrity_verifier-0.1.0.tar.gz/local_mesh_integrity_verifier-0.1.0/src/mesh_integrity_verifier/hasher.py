"""Cryptographic hashing utilities for 3D mesh files."""

import hashlib
import json
from datetime import datetime
from pathlib import Path
from typing import Dict, List
import trimesh
import numpy as np


class MeshHasher:
    """Generates cryptographic hashes for 3D mesh geometry."""

    def hash_mesh_geometry(self, mesh: trimesh.Trimesh) -> str:
        """
        Generate SHA-256 hash of mesh geometry (vertices + faces).
        Normalizes floating point precision to avoid false positives.
        """
        # Round vertices to 6 decimal places for consistency
        vertices_normalized = np.round(mesh.vertices, decimals=6)
        faces_normalized = mesh.faces

        # Concatenate and hash
        vertex_bytes = vertices_normalized.tobytes()
        face_bytes = faces_normalized.tobytes()

        hasher = hashlib.sha256()
        hasher.update(vertex_bytes)
        hasher.update(face_bytes)

        return hasher.hexdigest()

    def hash_file(self, file_path: Path) -> Dict:
        """
        Load mesh file and return hash + metadata.
        Supports GLB, GLTF, FBX, OBJ, USDZ formats.
        """
        try:
            # trimesh can load most formats
            mesh = trimesh.load(str(file_path), force="mesh")

            # Handle scene vs single mesh
            if isinstance(mesh, trimesh.Scene):
                # Combine all meshes in scene
                combined = trimesh.util.concatenate(
                    [geom for geom in mesh.geometry.values() if isinstance(geom, trimesh.Trimesh)]
                )
                mesh = combined

            geometry_hash = self.hash_mesh_geometry(mesh)

            return {
                "hash": geometry_hash,
                "file_size": file_path.stat().st_size,
                "vertices": len(mesh.vertices),
                "faces": len(mesh.faces),
                "bounds": mesh.bounds.tolist(),
                "format": file_path.suffix.lower(),
                "timestamp": datetime.fromtimestamp(file_path.stat().st_mtime).isoformat(),
            }

        except Exception as e:
            raise ValueError(f"Failed to process {file_path.name}: {str(e)}")

    def generate_directory_manifest(self, directory: Path, extensions: List[str]) -> Dict:
        """
        Scan directory recursively and generate integrity manifest.
        """
        manifest = {
            "generated_at": datetime.now().isoformat(),
            "directory": str(directory.resolve()),
            "extensions": extensions,
            "files": {},
            "stats": {"total_files": 0, "total_vertices": 0, "total_faces": 0},
        }

        for ext in extensions:
            for file_path in directory.rglob(f"*{ext}"):
                try:
                    rel_path = str(file_path.relative_to(directory))
                    file_data = self.hash_file(file_path)

                    manifest["files"][rel_path] = file_data
                    manifest["stats"]["total_files"] += 1
                    manifest["stats"]["total_vertices"] += file_data["vertices"]
                    manifest["stats"]["total_faces"] += file_data["faces"]

                    print(f"✓ {rel_path}")

                except Exception as e:
                    print(f"✗ {file_path.name}: {e}")

        return manifest
