"""Visual diff generation for mesh geometry changes."""

from pathlib import Path
from typing import Dict, Tuple
import trimesh
import numpy as np
from PIL import Image, ImageDraw, ImageFont
import matplotlib
matplotlib.use('Agg')  # Non-interactive backend
import matplotlib.pyplot as plt
from io import BytesIO
import base64


class MeshDiffer:
    """Generates visual difference reports between mesh versions."""

    def compare_meshes(self, mesh_a: trimesh.Trimesh, mesh_b: trimesh.Trimesh) -> Dict:
        """
        Compare two meshes and return detailed diff metrics.
        """
        # Vertex comparison
        vertex_diff = len(mesh_b.vertices) - len(mesh_a.vertices)
        face_diff = len(mesh_b.faces) - len(mesh_a.faces)

        # Bounding box comparison
        bounds_a = mesh_a.bounds
        bounds_b = mesh_b.bounds
        volume_a = np.prod(bounds_a[1] - bounds_a[0])
        volume_b = np.prod(bounds_b[1] - bounds_b[0])

        # Compute geometry similarity (Hausdorff-like approximation)
        # Sample points from both meshes and compute distance
        samples = min(1000, len(mesh_a.vertices), len(mesh_b.vertices))
        if samples > 0:
            points_a = mesh_a.vertices[np.random.choice(len(mesh_a.vertices), samples, replace=False)]
            points_b = mesh_b.vertices[np.random.choice(len(mesh_b.vertices), samples, replace=False)]

            # Compute average nearest-neighbor distance
            from scipy.spatial import cKDTree
            tree_b = cKDTree(points_b)
            distances, _ = tree_b.query(points_a)
            avg_distance = np.mean(distances)

            # Normalize by bounding box diagonal
            diagonal_a = np.linalg.norm(bounds_a[1] - bounds_a[0])
            similarity = max(0, 1 - (avg_distance / diagonal_a))
        else:
            similarity = 0.0

        return {
            "vertex_diff": vertex_diff,
            "face_diff": face_diff,
            "volume_change": volume_b - volume_a,
            "similarity": similarity,
            "bounds_a": bounds_a.tolist(),
            "bounds_b": bounds_b.tolist(),
        }

    def render_mesh_thumbnail(self, mesh: trimesh.Trimesh, size: Tuple[int, int] = (400, 400)) -> str:
        """
        Render mesh to base64-encoded PNG for HTML embedding.
        """
        fig = plt.figure(figsize=(4, 4))
        ax = fig.add_subplot(111, projection='3d')

        # Simple wireframe visualization
        vertices = mesh.vertices
        faces = mesh.faces

        # Plot faces
        for face in faces[::max(1, len(faces)//500)]:  # Subsample for performance
            triangle = vertices[face]
            ax.plot(triangle[[0, 1, 2, 0], 0],
                   triangle[[0, 1, 2, 0], 1],
                   triangle[[0, 1, 2, 0], 2],
                   'b-', linewidth=0.5, alpha=0.3)

        ax.set_xlabel('X')
        ax.set_ylabel('Y')
        ax.set_zlabel('Z')
        ax.set_title(f'Vertices: {len(vertices):,} | Faces: {len(faces):,}')

        # Equal aspect ratio
        max_range = np.array([
            vertices[:, 0].max()-vertices[:, 0].min(),
            vertices[:, 1].max()-vertices[:, 1].min(),
            vertices[:, 2].max()-vertices[:, 2].min()
        ]).max() / 2.0

        mid_x = (vertices[:, 0].max()+vertices[:, 0].min()) * 0.5
        mid_y = (vertices[:, 1].max()+vertices[:, 1].min()) * 0.5
        mid_z = (vertices[:, 2].max()+vertices[:, 2].min()) * 0.5

        ax.set_xlim(mid_x - max_range, mid_x + max_range)
        ax.set_ylim(mid_y - max_range, mid_y + max_range)
        ax.set_zlim(mid_z - max_range, mid_z + max_range)

        # Save to base64
        buf = BytesIO()
        plt.savefig(buf, format='png', dpi=100, bbox_inches='tight')
        plt.close(fig)
        buf.seek(0)

        return base64.b64encode(buf.read()).decode('utf-8')

    def generate_html_report(self, original_path: Path, modified_path: Path, output_path: Path) -> Dict:
        """
        Generate comprehensive HTML diff report with visualizations.
        """
        mesh_a = trimesh.load(str(original_path), force='mesh')
        mesh_b = trimesh.load(str(modified_path), force='mesh')

        # Handle scenes
        if isinstance(mesh_a, trimesh.Scene):
            mesh_a = trimesh.util.concatenate([g for g in mesh_a.geometry.values() if isinstance(g, trimesh.Trimesh)])
        if isinstance(mesh_b, trimesh.Scene):
            mesh_b = trimesh.util.concatenate([g for g in mesh_b.geometry.values() if isinstance(g, trimesh.Trimesh)])

        diff_data = self.compare_meshes(mesh_a, mesh_b)

        # Render thumbnails
        thumb_a = self.render_mesh_thumbnail(mesh_a)
        thumb_b = self.render_mesh_thumbnail(mesh_b)

        # Generate HTML
        html = f"""
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Mesh Integrity Diff Report</title>
    <style>
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            margin: 0;
            padding: 20px;
            background: #f5f5f5;
        }}
        .container {{
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }}
        h1 {{
            color: #333;
            border-bottom: 3px solid #007bff;
            padding-bottom: 10px;
        }}
        .summary {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin: 30px 0;
        }}
        .metric {{
            background: #f8f9fa;
            padding: 20px;
            border-radius: 6px;
            border-left: 4px solid #007bff;
        }}
        .metric-label {{
            font-size: 12px;
            color: #666;
            text-transform: uppercase;
            margin-bottom: 5px;
        }}
        .metric-value {{
            font-size: 24px;
            font-weight: bold;
            color: #333;
        }}
        .positive {{ color: #28a745; }}
        .negative {{ color: #dc3545; }}
        .comparison {{
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
            margin: 30px 0;
        }}
        .mesh-view {{
            text-align: center;
        }}
        .mesh-view h3 {{
            color: #666;
            font-size: 14px;
            text-transform: uppercase;
            margin-bottom: 15px;
        }}
        .mesh-view img {{
            max-width: 100%;
            border: 1px solid #ddd;
            border-radius: 4px;
        }}
        .details {{
            background: #f8f9fa;
            padding: 20px;
            border-radius: 6px;
            margin-top: 30px;
        }}
        .details h3 {{
            margin-top: 0;
        }}
        .detail-row {{
            display: flex;
            justify-content: space-between;
            padding: 10px 0;
            border-bottom: 1px solid #e0e0e0;
        }}
        .detail-row:last-child {{
            border-bottom: none;
        }}
    </style>
</head>
<body>
    <div class="container">
        <h1>🔍 Mesh Integrity Diff Report</h1>
        
        <div class="summary">
            <div class="metric">
                <div class="metric-label">Vertex Change</div>
                <div class="metric-value {('positive' if diff_data['vertex_diff'] >= 0 else 'negative')}">
                    {diff_data['vertex_diff']:+,}
                </div>
            </div>
            <div class="metric">
                <div class="metric-label">Face Change</div>
                <div class="metric-value {('positive' if diff_data['face_diff'] >= 0 else 'negative')}">
                    {diff_data['face_diff']:+,}
                </div>
            </div>
            <div class="metric">
                <div class="metric-label">Geometry Similarity</div>
                <div class="metric-value">
                    {diff_data['similarity']*100:.1f}%
                </div>
            </div>
            <div class="metric">
                <div class="metric-label">Volume Change</div>
                <div class="metric-value {('positive' if diff_data['volume_change'] >= 0 else 'negative')}">
                    {diff_data['volume_change']:+.2f}
                </div>
            </div>
        </div>

        <div class="comparison">
            <div class="mesh-view">
                <h3>Original: {original_path.name}</h3>
                <img src="data:image/png;base64,{thumb_a}" alt="Original mesh">
                <p>{len(mesh_a.vertices):,} vertices | {len(mesh_a.faces):,} faces</p>
            </div>
            <div class="mesh-view">
                <h3>Modified: {modified_path.name}</h3>
                <img src="data:image/png;base64,{thumb_b}" alt="Modified mesh">
                <p>{len(mesh_b.vertices):,} vertices | {len(mesh_b.faces):,} faces</p>
            </div>
        </div>

        <div class="details">
            <h3>Technical Details</h3>
            <div class="detail-row">
                <span>Original File</span>
                <span>{original_path.name}</span>
            </div>
            <div class="detail-row">
                <span>Modified File</span>
                <span>{modified_path.name}</span>
            </div>
            <div class="detail-row">
                <span>Original Bounds</span>
                <span>{diff_data['bounds_a']}</span>
            </div>
            <div class="detail-row">
                <span>Modified Bounds</span>
                <span>{diff_data['bounds_b']}</span>
            </div>
        </div>
    </div>
</body>
</html>
"""

        with open(output_path, 'w') as f:
            f.write(html)

        return {
            "summary": diff_data,
            "output_path": str(output_path),
        }
