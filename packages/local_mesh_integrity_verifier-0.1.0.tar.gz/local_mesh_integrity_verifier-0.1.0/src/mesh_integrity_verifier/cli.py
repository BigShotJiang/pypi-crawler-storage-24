#!/usr/bin/env python3
"""Command-line interface for mesh integrity monitoring."""

import argparse
import json
import sys
from pathlib import Path
from .core import MeshIntegrityMonitor
from .web import start_web_dashboard


def main():
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        description="Monitor 3D asset files for unauthorized modifications",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Monitor a Unity project's Assets folder
  mesh-integrity watch ./Assets/Models --web

  # Generate baseline integrity manifest
  mesh-integrity baseline ./Assets/Models -o manifest.json

  # Verify current state against baseline
  mesh-integrity verify ./Assets/Models manifest.json

  # Export visual diff report
  mesh-integrity diff original.glb modified.glb -o report.html
        """,
    )

    subparsers = parser.add_subparsers(dest="command", help="Available commands")

    # Watch command
    watch_parser = subparsers.add_parser("watch", help="Start real-time monitoring")
    watch_parser.add_argument("directory", type=Path, help="Directory to monitor")
    watch_parser.add_argument(
        "--manifest", "-m", type=Path, help="Baseline manifest to compare against"
    )
    watch_parser.add_argument(
        "--web", action="store_true", help="Launch web dashboard (default: localhost:5050)"
    )
    watch_parser.add_argument("--port", type=int, default=5050, help="Web dashboard port")
    watch_parser.add_argument(
        "--extensions",
        nargs="+",
        default=[".glb", ".gltf", ".fbx", ".obj", ".usdz"],
        help="File extensions to monitor",
    )

    # Baseline command
    baseline_parser = subparsers.add_parser(
        "baseline", help="Generate cryptographic baseline manifest"
    )
    baseline_parser.add_argument("directory", type=Path, help="Directory to scan")
    baseline_parser.add_argument(
        "-o", "--output", type=Path, default="integrity_manifest.json", help="Output file"
    )
    baseline_parser.add_argument(
        "--extensions",
        nargs="+",
        default=[".glb", ".gltf", ".fbx", ".obj", ".usdz"],
        help="File extensions to scan",
    )

    # Verify command
    verify_parser = subparsers.add_parser("verify", help="Verify integrity against baseline")
    verify_parser.add_argument("directory", type=Path, help="Directory to verify")
    verify_parser.add_argument("manifest", type=Path, help="Baseline manifest file")
    verify_parser.add_argument("--verbose", "-v", action="store_true", help="Detailed output")

    # Diff command
    diff_parser = subparsers.add_parser("diff", help="Generate visual diff report")
    diff_parser.add_argument("original", type=Path, help="Original mesh file")
    diff_parser.add_argument("modified", type=Path, help="Modified mesh file")
    diff_parser.add_argument(
        "-o", "--output", type=Path, default="diff_report.html", help="Output HTML file"
    )

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        return 1

    try:
        if args.command == "watch":
            monitor = MeshIntegrityMonitor(
                watch_directory=args.directory,
                baseline_manifest=args.manifest,
                extensions=args.extensions,
            )

            if args.web:
                print(f"🚀 Starting web dashboard at http://localhost:{args.port}")
                print(f"📂 Monitoring: {args.directory.resolve()}")
                print("Press Ctrl+C to stop\n")
                start_web_dashboard(monitor, port=args.port)
            else:
                print(f"👀 Monitoring {args.directory.resolve()}")
                print("Press Ctrl+C to stop\n")
                monitor.start_monitoring()

        elif args.command == "baseline":
            from .hasher import MeshHasher

            print(f"🔍 Scanning {args.directory.resolve()}...")
            hasher = MeshHasher()
            manifest = hasher.generate_directory_manifest(args.directory, args.extensions)

            with open(args.output, "w") as f:
                json.dump(manifest, f, indent=2)

            print(f"✅ Baseline manifest saved to {args.output}")
            print(f"   Files tracked: {len(manifest['files'])}")
            print(f"   Total vertices: {manifest['stats']['total_vertices']:,}")
            print(f"   Total faces: {manifest['stats']['total_faces']:,}")

        elif args.command == "verify":
            from .hasher import MeshHasher

            with open(args.manifest) as f:
                baseline = json.load(f)

            print(f"🔍 Verifying {args.directory.resolve()}...")
            hasher = MeshHasher()
            current = hasher.generate_directory_manifest(
                args.directory, baseline.get("extensions", [".glb", ".gltf"])
            )

            violations = []
            for file_path, file_data in baseline["files"].items():
                if file_path not in current["files"]:
                    violations.append(f"❌ DELETED: {file_path}")
                elif current["files"][file_path]["hash"] != file_data["hash"]:
                    violations.append(f"⚠️  MODIFIED: {file_path}")

            for file_path in current["files"]:
                if file_path not in baseline["files"]:
                    violations.append(f"➕ NEW: {file_path}")

            if violations:
                print(f"\n🚨 {len(violations)} integrity violation(s) detected:\n")
                for v in violations:
                    print(f"  {v}")
                return 1
            else:
                print("\n✅ All files match baseline - integrity verified!")
                return 0

        elif args.command == "diff":
            from .diff import MeshDiffer

            print(f"🔍 Analyzing differences...")
            differ = MeshDiffer()
            report = differ.generate_html_report(args.original, args.modified, args.output)

            print(f"✅ Visual diff report saved to {args.output}")
            print(f"   Vertex changes: {report['summary']['vertex_diff']}")
            print(f"   Face changes: {report['summary']['face_diff']}")
            print(f"   Geometry similarity: {report['summary']['similarity']:.1%}")

    except KeyboardInterrupt:
        print("\n\n👋 Monitoring stopped")
        return 0
    except Exception as e:
        print(f"\n❌ Error: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
