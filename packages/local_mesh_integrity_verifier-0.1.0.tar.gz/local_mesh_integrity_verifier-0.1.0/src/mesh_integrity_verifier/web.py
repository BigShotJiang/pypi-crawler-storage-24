"""Web dashboard for real-time monitoring visualization."""

from flask import Flask, render_template_string, jsonify
from pathlib import Path
from .core import MeshIntegrityMonitor
import threading


def create_dashboard_html():
    """Generate HTML for the monitoring dashboard."""
    return """
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Mesh Integrity Monitor</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
            background: #0f0f0f;
            color: #e0e0e0;
            padding: 20px;
        }
        .container {
            max-width: 1400px;
            margin: 0 auto;
        }
        header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 30px;
        }
        h1 {
            font-size: 32px;
            margin-bottom: 10px;
        }
        .status {
            display: inline-block;
            padding: 5px 15px;
            background: #28a745;
            border-radius: 20px;
            font-size: 14px;
            font-weight: bold;
        }
        .metrics {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        .metric-card {
            background: #1a1a1a;
            padding: 25px;
            border-radius: 10px;
            border: 1px solid #333;
        }
        .metric-label {
            font-size: 12px;
            color: #888;
            text-transform: uppercase;
            margin-bottom: 10px;
        }
        .metric-value {
            font-size: 36px;
            font-weight: bold;
            color: #667eea;
        }
        .violations {
            background: #1a1a1a;
            border-radius: 10px;
            border: 1px solid #333;
            overflow: hidden;
        }
        .violations-header {
            background: #252525;
            padding: 20px;
            border-bottom: 1px solid #333;
        }
        .violations-header h2 {
            font-size: 20px;
        }
        .violation-list {
            max-height: 500px;
            overflow-y: auto;
        }
        .violation-item {
            padding: 20px;
            border-bottom: 1px solid #2a2a2a;
            transition: background 0.2s;
        }
        .violation-item:hover {
            background: #252525;
        }
        .violation-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
        }
        .violation-type {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: bold;
            text-transform: uppercase;
        }
        .type-modification {
            background: #ffc107;
            color: #000;
        }
        .type-deletion {
            background: #dc3545;
            color: #fff;
        }
        .type-addition {
            background: #17a2b8;
            color: #fff;
        }
        .violation-file {
            font-size: 16px;
            font-weight: 500;
            color: #fff;
            font-family: 'Courier New', monospace;
        }
        .violation-time {
            font-size: 12px;
            color: #888;
        }
        .violation-details {
            font-size: 13px;
            color: #aaa;
            margin-top: 10px;
        }
        .no-violations {
            padding: 40px;
            text-align: center;
            color: #666;
        }
        .auto-refresh {
            position: fixed;
            bottom: 20px;
            right: 20px;
            background: #667eea;
            color: white;
            padding: 10px 20px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1>🛡️ Mesh Integrity Monitor</h1>
            <span class="status" id="status">● ACTIVE</span>
        </header>

        <div class="metrics">
            <div class="metric-card">
                <div class="metric-label">Baseline Files</div>
                <div class="metric-value" id="baseline-files">-</div>
            </div>
            <div class="metric-card">
                <div class="metric-label">Total Violations</div>
                <div class="metric-value" id="total-violations">-</div>
            </div>
            <div class="metric-card">
                <div class="metric-label">Watch Directory</div>
                <div class="metric-value" style="font-size: 16px;" id="watch-dir">-</div>
            </div>
        </div>

        <div class="violations">
            <div class="violations-header">
                <h2>Recent Violations</h2>
            </div>
            <div class="violation-list" id="violation-list">
                <div class="no-violations">
                    ✓ No violations detected
                </div>
            </div>
        </div>

        <div class="auto-refresh">⟳ Auto-refresh: 2s</div>
    </div>

    <script>
        function updateDashboard() {
            fetch('/api/status')
                .then(r => r.json())
                .then(data => {
                    document.getElementById('baseline-files').textContent = 
                        data.baseline_files.toLocaleString();
                    document.getElementById('total-violations').textContent = 
                        data.total_violations.toLocaleString();
                    document.getElementById('watch-dir').textContent = 
                        data.watch_directory.split('/').pop();

                    const violationList = document.getElementById('violation-list');
                    
                    if (data.recent_violations.length === 0) {
                        violationList.innerHTML = 
                            '<div class="no-violations">✓ No violations detected</div>';
                    } else {
                        violationList.innerHTML = data.recent_violations
                            .reverse()
                            .map(v => {
                                const typeClass = v.type.replace('unauthorized_', '');
                                const typeLabel = v.type
                                    .replace('unauthorized_', '')
                                    .replace('_', ' ');
                                
                                let details = '';
                                if (v.type === 'unauthorized_modification') {
                                    details = `Vertices: ${v.original_vertices?.toLocaleString() || '?'} → ${v.new_vertices?.toLocaleString() || '?'} | Faces: ${v.original_faces?.toLocaleString() || '?'} → ${v.new_faces?.toLocaleString() || '?'}`;
                                } else if (v.type === 'unauthorized_addition') {
                                    details = `Vertices: ${v.vertices?.toLocaleString() || '?'} | Faces: ${v.faces?.toLocaleString() || '?'}`;
                                } else if (v.type === 'deletion') {
                                    details = `Original hash: ${v.original_hash?.substring(0, 16) || '?'}...`;
                                }

                                return `
                                    <div class="violation-item">
                                        <div class="violation-header">
                                            <div>
                                                <span class="violation-type type-${typeClass}">${typeLabel}</span>
                                            </div>
                                            <span class="violation-time">${new Date(v.timestamp).toLocaleString()}</span>
                                        </div>
                                        <div class="violation-file">${v.file}</div>
                                        <div class="violation-details">${details}</div>
                                    </div>
                                `;
                            })
                            .join('');
                    }
                });
        }

        // Initial load
        updateDashboard();

        // Auto-refresh every 2 seconds
        setInterval(updateDashboard, 2000);
    </script>
</body>
</html>
"""


def start_web_dashboard(monitor: MeshIntegrityMonitor, port: int = 5050):
    """Launch Flask web server for dashboard."""
    app = Flask(__name__)

    @app.route('/')
    def dashboard():
        return render_template_string(create_dashboard_html())

    @app.route('/api/status')
    def api_status():
        return jsonify(monitor.get_status())

    # Start monitoring in background thread
    monitor_thread = threading.Thread(target=monitor.start_monitoring, daemon=True)
    monitor_thread.start()

    # Run Flask
    app.run(host='0.0.0.0', port=port, debug=False)
