# Local Mesh Integrity Verifier

**Real-time cryptographic monitoring for 3D asset files—detect unauthorized mesh modifications instantly.**

## What is this?

Local Mesh Integrity Verifier is a lightweight desktop application that continuously monitors 3D asset files in your project directory, detects unauthorized modifications, and generates cryptographic integrity reports. It bridges the gap between asset provenance and ongoing compliance by providing real-time file watching, visual diff detection for mesh geometry changes, and tamper-proof integrity hashes. Perfect for game studios and VR developers who need continuous asset security alongside your existing Phantom Rack/SplitScreen workflows.

## Features

- **Real-time file monitoring** – Watch directories for changes to GLB, USDZ, FBX, and OBJ files
- **Cryptographic integrity hashing** – SHA-256 based verification of mesh geometry and metadata
- **Visual diff viewer** – Detect and visualize mesh geometry changes with geometric comparison
- **Integrity reports** – Generate detailed audit logs of all file modifications
- **Web dashboard** – Browser-based UI for monitoring and reporting
- **CLI interface** – Scriptable for CI/CD pipelines and automation
- **Zero configuration** – Works out-of-the-box with sensible defaults
- **Compliance-ready** – Exportable reports for audit trails and regulatory requirements

## Quick Start

### Installation

```bash
pip install local-mesh-integrity-verifier
```

Or install from source:

```bash
git clone https://github.com/your-org/local-mesh-integrity-verifier.git
cd local-mesh-integrity-verifier
pip install -e .
```

### Basic Usage

Monitor a directory for changes:

```bash
mesh-verifier watch /path/to/assets --output reports/
```

Generate an integrity baseline:

```bash
mesh-verifier baseline /path/to/assets --save baseline.json
```

Start the web dashboard:

```bash
mesh-verifier serve --port 8080
```

Verify a single file:

```bash
mesh-verifier verify model.glb --baseline baseline.json
```

## Usage Examples

### Monitor a Game Project

```bash
# Watch your Assets/Models directory
mesh-verifier watch ./Assets/Models \
  --output ./integrity-reports \
  --interval 300  # Check every 5 minutes
```

### Generate Audit Reports

```bash
# Create a compliance-ready report
mesh-verifier report \
  --baseline original-baseline.json \
  --current ./integrity-reports/latest.json \
  --format pdf \
  --output audit-2025-03.pdf
```

### CI/CD Integration

```yaml
# Example: GitHub Actions workflow
- name: Verify mesh integrity
  run: |
    mesh-verifier verify ./Assets/Models \
      --baseline .github/mesh-baseline.json \
      --fail-on-drift
```

### Unity Integration

See `examples/unity_integration.md` for detailed setup instructions for Unity projects.

## Tech Stack

- **Python 3.9+** – Core runtime
- **Watchdog** – Real-time file system monitoring
- **Trimesh** – 3D mesh parsing and geometry comparison
- **FastAPI** – Web dashboard backend
- **SQLite** – Local audit log storage
- **PyTest** – Test suite

## Project Structure

```
src/mesh_integrity_verifier/
├── cli.py          # Command-line interface
├── core.py         # File monitoring and verification logic
├── hasher.py       # Cryptographic hashing for mesh files
├── diff.py         # Geometry comparison and visual diffing
├── web.py          # Web dashboard and API
└── __init__.py     # Package initialization

tests/
├── test_hasher.py
├── test_diff.py
└── test_monitor.py
```

## Configuration

Create a `.mesh-verifier.json` in your project root:

```json
{
  "watch_paths": ["./Assets/Models", "./Assets/Meshes"],
  "ignore_patterns": ["*.tmp", ".DS_Store"],
  "hash_algorithm": "sha256",
  "check_interval_seconds": 300,
  "report_format": "json"
}
```

## License

MIT

---

**Need help?** Check `OVERVIEW.md` for architecture details or open an issue on GitHub.