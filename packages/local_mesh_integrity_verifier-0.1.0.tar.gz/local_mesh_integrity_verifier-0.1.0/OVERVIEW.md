# local-mesh-integrity-verifier

A lightweight desktop app that continuously monitors 3D asset files in a project directory, detects unauthorized modifications, and generates cryptographic integrity reports. Fills the gap between your 3D asset provenance work and the existing compliance tools—this provides ongoing asset security for game studios and VR developers who already use your Phantom Rack/SplitScreen projects. Real-time file watching + visual diff viewer for mesh geometry changes.
