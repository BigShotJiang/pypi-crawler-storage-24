from __future__ import annotations

import dataclasses
import tempfile
from pathlib import Path
from typing import Optional, Any, Dict

from aiogram import Bot
from aiogram.types import Message, PhotoSize
from PIL import Image
import exifread


@dataclasses.dataclass
class JojogramConfig:
    """
    Настройки работы анализатора.

    Сейчас только один параметр — нужно ли читать EXIF.
    Если EXIF не нужен, библиотека работает быстрее и без exifread.
    """

    read_exif: bool = True


@dataclasses.dataclass
class PhotoAnalysisResult:
    """
    Результат анализа фото.
    """

    # Источник сообщения
    from_user_id: Optional[int]
    from_user_username: Optional[str]
    from_user_full_name: Optional[str]

    # Базовая информация о фото
    file_id: str
    file_unique_id: str
    file_size_bytes: Optional[int]
    width: Optional[int]
    height: Optional[int]
    mime_type: Optional[str]
    file_path: Optional[str]

    # Информация из самого файла
    image_format: Optional[str]
    mode: Optional[str]

    # Данные EXIF (если есть)
    exif: Dict[str, Any]

    # Полезная “готовая” строка для ответа пользователю
    human_readable: str


async def _download_telegram_photo(bot: Bot, photo: PhotoSize) -> Path:
    """
    Скачивает фото из Telegram во временный файл и возвращает путь.
    """

    file = await bot.get_file(photo.file_id)
    suffix = Path(file.file_path or "").suffix or ".jpg"
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=suffix)
    tmp_path = Path(tmp.name)
    await bot.download_file(file.file_path, destination=tmp_path)
    tmp.close()
    return tmp_path


def _read_image_info(path: Path) -> Dict[str, Any]:
    """
    Чтение базовой информации о картинке через Pillow.
    """

    info: Dict[str, Any] = {}
    try:
        with Image.open(path) as img:
            info["image_format"] = img.format
            info["mode"] = img.mode
            info["width"], info["height"] = img.size
    except Exception:
        # Если не удалось прочитать — просто вернём пустой словарь
        pass
    return info


def _read_exif_info(path: Path) -> Dict[str, Any]:
    """
    Чтение EXIF‑метаданных (автор, камера и т.п.).
    """

    exif_data: Dict[str, Any] = {}
    try:
        with open(path, "rb") as f:
            tags = exifread.process_file(f, details=False)
        for key, value in tags.items():
            # Преобразуем в строку для удобства сериализации
            exif_data[key] = str(value)
    except Exception:
        pass
    return exif_data


async def analyze_photo_message(
    message: Message,
    bot: Optional[Bot] = None,
    config: Optional[JojogramConfig] = None,
) -> PhotoAnalysisResult:
    """
    Высокоуровневая функция: принимает сообщение с фотографией и
    возвращает структурированный результат анализа.

    Использование:

        result = await analyze_photo_message(message)
        await message.answer(result.human_readable)
    """

    if not message.photo:
        raise ValueError("В сообщении нет фото.")

    config = config or JojogramConfig()

    # Берём самое крупное фото из списка
    photo = max(message.photo, key=lambda p: p.file_size or 0)

    # Получаем экземпляр бота
    if bot is None:
        if message.bot is None:
            raise RuntimeError("Не удалось получить экземпляр Bot.")
        bot = message.bot

    tmp_path: Optional[Path] = None

    try:
        tmp_path = await _download_telegram_photo(bot, photo)

        image_info = _read_image_info(tmp_path)
        exif_info: Dict[str, Any] = {}
        if config.read_exif:
            exif_info = _read_exif_info(tmp_path)

        # Информация о пользователе
        from_user = message.from_user
        from_user_id = from_user.id if from_user else None
        from_user_username = from_user.username if from_user else None
        if from_user:
            full_name = " ".join(
                part
                for part in [from_user.first_name, from_user.last_name]
                if part
            )
        else:
            full_name = None

        # Информация о файле
        file_id = photo.file_id
        file_unique_id = photo.file_unique_id
        file_size_bytes = photo.file_size
        mime_type = getattr(photo, "mime_type", None)

        tg_file = await bot.get_file(photo.file_id)
        file_path = tg_file.file_path

        width = image_info.get("width") or photo.width
        height = image_info.get("height") or photo.height

        result = PhotoAnalysisResult(
            from_user_id=from_user_id,
            from_user_username=from_user_username,
            from_user_full_name=full_name,
            file_id=file_id,
            file_unique_id=file_unique_id,
            file_size_bytes=file_size_bytes,
            width=width,
            height=height,
            mime_type=mime_type,
            file_path=file_path,
            image_format=image_info.get("image_format"),
            mode=image_info.get("mode"),
            exif=exif_info,
            human_readable="",  # заполним ниже
        )

        # Сформируем человекочитаемое описание
        parts = []
        if result.from_user_full_name or result.from_user_username:
            who = result.from_user_full_name or ""
            if result.from_user_username:
                who = (who + f" (@{result.from_user_username})").strip()
            parts.append(f"Фото отправил: {who or 'неизвестный пользователь'}")
        else:
            parts.append("Фото отправил: неизвестный пользователь")

        if result.width and result.height:
            parts.append(f"Размер: {result.width}x{result.height}px")

        if result.file_size_bytes:
            kb = result.file_size_bytes / 1024
            parts.append(f"Размер файла: ~{kb:.1f} KB")

        if result.image_format:
            parts.append(f"Формат изображения: {result.image_format}")

        if result.mime_type:
            parts.append(f"MIME‑тип: {result.mime_type}")

        if result.exif:
            artist = result.exif.get("Image Artist") or result.exif.get(
                "Image Copyright"
            )
            if artist:
                parts.append(f"Автор по EXIF: {artist}")

        result.human_readable = "\n".join(parts)
        return result

    finally:
        # Удаляем временный файл
        if tmp_path and tmp_path.exists():
            try:
                tmp_path.unlink()
            except Exception:
                pass

