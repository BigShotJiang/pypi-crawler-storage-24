class PaymentSDKError(Exception):
    """Base exception for InventPay SDK errors."""

    def __init__(self, message, status_code=None, details=None):
        self.message = message
        self.status_code = status_code
        self.details = details
        super().__init__(self.message)


class AuthenticationError(PaymentSDKError):
    """Authentication related errors."""
    pass


class ValidationError(PaymentSDKError):
    """Request validation errors."""
    pass


class RateLimitError(PaymentSDKError):
    """Rate limit exceeded errors."""
    pass


class ServerError(PaymentSDKError):
    """Server/internal errors."""
    pass