from typing import Dict, List, Optional, Any, Union
from dataclasses import dataclass
from datetime import datetime

@dataclass
class SDKConfig:
    api_key: str
    withdrawal_api_key: Optional[str] = None
    base_url: str = "https://api.inventpay.io"
    timeout: int = 30

@dataclass
class PaymentRequest:
    amount: float
    amount_currency: str = "USD"
    currency: str = "USDT_BEP20"
    order_id: Optional[str] = None
    description: Optional[str] = None
    callback_url: Optional[str] = None
    expiration_minutes: Optional[int] = None

@dataclass
class InvoiceRequest:
    amount: float
    amount_currency: str = "USD"
    order_id: Optional[str] = None
    description: Optional[str] = None
    callback_url: Optional[str] = None
    expiration_minutes: Optional[int] = None

@dataclass
class WithdrawalRequest:
    amount: float
    currency: str
    destination_address: str
    description: Optional[str] = None

@dataclass
class WebhookConfig:
    webhook_url: str

@dataclass
class PaymentResponse:
    success: bool
    data: Dict[str, Any]

@dataclass
class BalanceResponse:
    success: bool
    data: Dict[str, Any]

@dataclass
class WithdrawalResponse:
    success: bool
    data: Dict[str, Any]

@dataclass
class PaymentStatusResponse:
    status: str
    current_balance: str
    confirmations: int

@dataclass
class WebhookDelivery:
    id: str
    payment_id: str
    url: str
    http_status: Optional[int]
    attempts: int
    success: bool
    last_attempt_at: str
    created_at: str

@dataclass
class WebhookEvent:
    event: str
    timestamp: str
    data: Dict[str, Any]

# ==================== STORE TYPES ====================

@dataclass
class CreateStoreRequest:
    name: str
    description: Optional[str] = None
    settings: Optional[Dict[str, Any]] = None

@dataclass
class UpdateStoreRequest:
    name: Optional[str] = None
    description: Optional[str] = None
    logo: Optional[str] = None
    banner: Optional[str] = None
    is_published: Optional[bool] = None
    settings: Optional[Dict[str, Any]] = None

@dataclass
class CreateProductRequest:
    name: str
    price: float
    currency: str = "USD"
    description: Optional[str] = None
    images: Optional[List[str]] = None
    stock: Optional[int] = None
    digital_content: Optional[Dict[str, Any]] = None

@dataclass
class UpdateProductRequest:
    name: Optional[str] = None
    description: Optional[str] = None
    price: Optional[float] = None
    currency: Optional[str] = None
    images: Optional[List[str]] = None
    stock: Optional[int] = None
    is_active: Optional[bool] = None
    digital_content: Optional[Dict[str, Any]] = None

@dataclass
class StoreResponse:
    success: bool
    data: Dict[str, Any]

@dataclass
class ProductResponse:
    success: bool
    data: Dict[str, Any]

@dataclass
class ProductListResponse:
    success: bool
    data: Dict[str, Any]

@dataclass
class OrderResponse:
    success: bool
    data: Dict[str, Any]

@dataclass
class OrderListResponse:
    success: bool
    data: Dict[str, Any]