#!/usr/bin/env bash
#
# Licensed to the Apache Software Foundation (ASF) under one
# or more contributor license agreements.  See the NOTICE file
# distributed with this work for additional information
# regarding copyright ownership.  The ASF licenses this file
# to you under the Apache License, Version 2.0 (the
# "License"); you may not use this file except in compliance
# with the License.  You may obtain a copy of the License at
#
#   https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing,
# software distributed under the License is distributed on an
# "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
# KIND, either express or implied.  See the License for the
# specific language governing permissions and limitations
# under the License.
#

set -euo pipefail

# Build and publish the Veculo Python SDK to PyPI
# Usage:
#   ./publish.sh              # Build + upload to PyPI
#   ./publish.sh --test       # Build + upload to TestPyPI
#   ./publish.sh --build-only # Build only, no upload

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
ACTION="${1:-}"
VENV_DIR="/tmp/veculo-publish-venv"

echo "=== Veculo Python SDK Publisher ==="

# Clean previous builds
rm -rf "$SCRIPT_DIR/dist" "$SCRIPT_DIR/build" "$SCRIPT_DIR/src/*.egg-info"

# Create clean venv
echo "Creating clean virtual environment..."
python3 -m venv "$VENV_DIR"
source "$VENV_DIR/bin/activate"

# Install build tools
pip install --quiet --upgrade pip build twine

# Build
echo "Building package..."
cd "$SCRIPT_DIR"
python -m build

echo ""
echo "Built artifacts:"
ls -lh dist/

# Run twine check
echo ""
echo "Validating package..."
twine check dist/*

if [ "$ACTION" = "--build-only" ]; then
  echo ""
  echo "Build complete. Skipping upload."
elif [ "$ACTION" = "--test" ]; then
  echo ""
  echo "Uploading to TestPyPI..."
  twine upload --repository testpypi dist/*
  echo ""
  echo "Test install: pip install --index-url https://test.pypi.org/simple/ veculo"
else
  echo ""
  echo "Uploading to PyPI..."
  twine upload dist/*
  echo ""
  echo "Install: pip install veculo"
fi

# Cleanup venv
deactivate
rm -rf "$VENV_DIR"

echo ""
echo "Done."
