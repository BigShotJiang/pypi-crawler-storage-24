"""Veculo Python SDK — managed graph+vector database client."""

from veculo.client import VeculoClient
from veculo.errors import AuthenticationError, NotFoundError, ValidationError, VeculoError
from veculo.models import Edge, QueryResult, VectorResult, Vertex

__version__ = "0.1.0"

__all__ = [
    "VeculoClient",
    "VeculoError",
    "AuthenticationError",
    "NotFoundError",
    "ValidationError",
    "Vertex",
    "Edge",
    "VectorResult",
    "QueryResult",
    "__version__",
]
