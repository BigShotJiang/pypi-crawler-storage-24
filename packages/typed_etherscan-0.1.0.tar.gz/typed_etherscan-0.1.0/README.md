# Typed Etherscan

> A fully typed, validated async client for the Etherscan API

**Use autocomplete instead of documentation.**

```python
from etherscan import Etherscan

async with Etherscan.new() as client:
  result = await client.data.ticker(...)
  print(result)
```

## Why Typed Etherscan?

- **🎯 Precise Types**: Strong typing throughout, so your editor can help before runtime does.
- **✅ Automatic Validation**: Catch upstream API changes earlier, where they are easier to debug.
- **⚡ Async First**: Built for concurrent, network-heavy workflows.
- **🔒 Safer Usage**: Typed inputs and explicit errors reduce avoidable mistakes.
- **🎨 Better DX**: Clear routing, sensible defaults, and minimal ceremony.
- **📦 Practical Extras**: A place for pagination, streams, and client-specific helpers when they add real value.

## Installation

```bash
pip install typed-etherscan
```

## Documentation

> [**Read the docs**](https://etherscan.tribulnation.com)

🚧 Under construction.
