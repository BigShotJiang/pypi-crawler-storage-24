from .block_by_time import BlockByTime

class Blocks(BlockByTime):
  ...