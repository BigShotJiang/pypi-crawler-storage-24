from etherscan.core import Router

from .blocks import Blocks
from .account import Account

class Etherscan(Router):
  blocks: Blocks
  account: Account