## Typing stubs for WTForms

This is a [type stub package](https://typing.python.org/en/latest/tutorials/external_libraries.html)
for the [`WTForms`](https://github.com/pallets-eco/wtforms) package. It can be used by type checkers
to check code that uses `WTForms`. This version of
`types-WTForms` aims to provide accurate annotations for
`WTForms~=3.2.1`.

This package is part of the [typeshed project](https://github.com/python/typeshed).
All fixes for types and metadata should be contributed there.
See [the README](https://github.com/python/typeshed/blob/main/README.md)
for more details. The source for this package can be found in the
[`stubs/WTForms`](https://github.com/python/typeshed/tree/main/stubs/WTForms)
directory.

This package was tested with the following type checkers:
* [mypy](https://github.com/python/mypy/) 1.19.1
* [pyright](https://github.com/microsoft/pyright) 1.1.408

It was generated from typeshed commit
[`25438e5f21be7f0ac15fe305c7183d74dc2e6923`](https://github.com/python/typeshed/commit/25438e5f21be7f0ac15fe305c7183d74dc2e6923).