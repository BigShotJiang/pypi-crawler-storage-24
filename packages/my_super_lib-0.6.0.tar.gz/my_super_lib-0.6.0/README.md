# My Super Lib

[![PyPI version](https://badge.fury.io/py/my-super-lib.svg)](https://badge.fury.io/py/my-super-lib)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python Versions](https://img.shields.io/pypi/pyversions/my-super-lib.svg)](https://pypi.org/project/my-super-lib/)

# My new project