"""Demo fixture assets."""
