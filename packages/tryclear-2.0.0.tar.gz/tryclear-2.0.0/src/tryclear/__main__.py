"""Entry point for python -m tryclear."""

from tryclear.cli import main

if __name__ == "__main__":
    main()
