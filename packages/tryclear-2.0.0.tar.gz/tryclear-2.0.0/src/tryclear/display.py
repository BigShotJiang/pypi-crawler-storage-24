"""Display utilities for Clear CLI."""

import os
import sys
import tempfile
import time
from typing import Optional

from rich.console import Console
from rich.panel import Panel
from rich.text import Text

from tryclear import __version__

# Verdict display
VERDICT_STYLES = {
    "clear": ("green", "CLEAR"),
    "benign": ("green", "CLEAR"),
    "suspicious": ("yellow", "SUSPICIOUS"),
    "malicious": ("red", "MALICIOUS"),
    "blocked": ("red", "BLOCKED"),
    "error": ("red", "ERROR"),
}

RISK_STYLES = {
    "low": "green",
    "medium": "yellow",
    "high": "red",
    "critical": "red",
}

# URL classification rendering (all 9 API states)
URL_CLASSIFICATION = {
    "verified_official": ("\u2713", "green", "VERIFIED_OFFICIAL"),
    "known_malicious": ("\u2717", "red", "KNOWN_MALICIOUS"),
    "semantic_malicious": ("\u2717", "red", "SEMANTIC_MALICIOUS"),
    "malicious_targets": ("\u2717", "red", "MALICIOUS_TARGET"),
    "suspicious_pattern": ("!", "yellow", "SUSPICIOUS"),
    "context_mismatch": ("!", "yellow", "CONTEXT_MISMATCH"),
    "unverified_context": ("?", "yellow", "UNVERIFIED"),
    "unassociated": ("\u25cb", "dim", "UNASSOCIATED"),
    "extracted_neutral": ("\u25cb", "dim", "NEUTRAL"),
}

# Severity ranking for URL dedup (higher = more severe)
_URL_SEVERITY = {
    "malicious_targets": 5,
    "known_malicious": 5,
    "semantic_malicious": 4,
    "suspicious_pattern": 3,
    "context_mismatch": 2,
    "unverified_context": 1,
    "unassociated": 0,
    "extracted_neutral": 0,
    "verified_official": 0,
}


def deduplicate_urls(indicators: dict) -> list:
    """Deduplicate URLs across classification buckets.

    When the same URL appears in multiple buckets, keep the most severe
    classification. Returns list of (url_str, classification_key) tuples,
    ordered by severity (most severe first).
    """
    best = {}  # url_str -> classification_key
    for key in URL_CLASSIFICATION:
        for url in indicators.get(key, []):
            url_str = url.get("url", str(url)) if isinstance(url, dict) else str(url)
            existing = best.get(url_str)
            if existing is None or _URL_SEVERITY.get(key, 0) > _URL_SEVERITY.get(existing, 0):
                best[url_str] = key
    # Sort by severity descending
    return sorted(best.items(), key=lambda x: _URL_SEVERITY.get(x[1], 0), reverse=True)


def is_tty() -> bool:
    """Check if stdout is a terminal."""
    return hasattr(sys.stdout, "isatty") and sys.stdout.isatty()


def get_console(force_terminal: Optional[bool] = None) -> Console:
    """Get a Rich console, respecting TTY detection."""
    if force_terminal is None:
        force_terminal = is_tty()
    return Console(force_terminal=force_terminal, highlight=False)


def print_error(console: Console, message: str) -> None:
    """Print an error message."""
    console.print(f"[red]\u2717[/red] {message}")


def print_success(console: Console, message: str) -> None:
    """Print a success message."""
    console.print(f"[green]\u2713[/green] {message}")


def print_warning(console: Console, message: str) -> None:
    """Print a warning message."""
    console.print(f"[yellow]![/yellow] {message}")


# ---------------------------------------------------------------------------
# Brand line / session marker
# ---------------------------------------------------------------------------

_SESSION_FILE = os.path.join(tempfile.gettempdir(), "tryclear-session")
_SESSION_WINDOW = 1800  # 30 minutes


def should_show_brand() -> bool:
    """Check if brand line should be shown (first eval of session)."""
    try:
        if os.path.exists(_SESSION_FILE):
            mtime = os.path.getmtime(_SESSION_FILE)
            if time.time() - mtime < _SESSION_WINDOW:
                return False
    except OSError:
        pass
    return True


def mark_brand_shown() -> None:
    """Mark that brand line was shown for this session."""
    try:
        with open(_SESSION_FILE, "w") as f:
            f.write("")
    except OSError:
        pass


def print_brand_line(
    console: Console,
    tier: Optional[str] = None,
    remaining: Optional[int] = None,
) -> None:
    """Print brand line: TryClear v2.0.0 · Pro · 847 evals remaining."""
    parts = [f"[bold]TryClear[/bold] v{__version__}"]
    if tier:
        parts.append(tier.capitalize())
    if remaining is not None and remaining >= 0:
        parts.append(f"{remaining} evals remaining")
    line = " \u00b7 ".join(parts)
    console.print(f"  [cyan]\u25c6[/cyan] {line}")


def print_welcome(console: Console) -> None:
    """Print first-run welcome message when no API key is configured."""
    console.print()
    console.print(f"  [cyan]\u25c6[/cyan] [bold]Welcome to TryClear[/bold]")
    console.print()
    console.print("  Get started:")
    console.print("    1. Get your API key at [dim]https://tryclear.io/settings[/dim]")
    console.print("    2. Run: [bold]clear auth[/bold]")
    console.print()


# ---------------------------------------------------------------------------
# URL defanging
# ---------------------------------------------------------------------------

def defang_url(url: str) -> str:
    """Defang URL for safe terminal display."""
    url = url.replace("https://", "hxxps://").replace("http://", "hxxp://")
    try:
        proto_end = url.index("//") + 2
        rest = url[proto_end:]
        slash_idx = rest.find("/")
        if slash_idx == -1:
            domain = rest
            path = ""
        else:
            domain = rest[:slash_idx]
            path = rest[slash_idx:]
        domain = domain.replace(".", "[.]")
        return url[:proto_end] + domain + path
    except ValueError:
        return url


# ---------------------------------------------------------------------------
# File info
# ---------------------------------------------------------------------------

def _format_size(size_bytes) -> str:
    """Format file size in human-readable form."""
    try:
        size_bytes = float(size_bytes)
    except (TypeError, ValueError):
        return "unknown"
    if size_bytes < 1024:
        return f"{int(size_bytes)} B"
    elif size_bytes < 1024 * 1024:
        return f"{size_bytes / 1024:.0f} KB"
    else:
        return f"{size_bytes / (1024 * 1024):.1f} MB"


def print_file_info(
    console: Console,
    filename: str,
    size_bytes=None,
    content_type: Optional[str] = None,
) -> None:
    """Print file info line: filename · size · type."""
    parts = [f"[bold]{filename}[/bold]"]
    if size_bytes is not None:
        parts.append(_format_size(size_bytes))
    if content_type:
        parts.append(content_type)
    console.print("  " + " \u00b7 ".join(parts))


# ---------------------------------------------------------------------------
# Spinner / polling
# ---------------------------------------------------------------------------

def wait_with_spinner(
    client,
    analysis_id: str,
    console: Console,
    max_wait: float = 300.0,
) -> dict:
    """Wait for evaluation with adaptive polling.

    Polling intervals:
        0-10s:  every 1s  (most evals finish here)
        10-30s: every 2s
        30s+:   every 5s
    """
    start_time = time.time()

    with console.status("", spinner="dots", spinner_style="cyan") as spinner:
        while True:
            elapsed = time.time() - start_time
            elapsed_int = int(elapsed)
            spinner.update(f"  [dim]evaluating... ({elapsed_int}s)[/dim]")

            result = client.status(analysis_id)

            if result.get("status") in ("done", "failed", "error"):
                if result.get("cache_hit"):
                    console.print("  [dim]Matched prior eval in <1s[/dim]")
                else:
                    elapsed_final = int(time.time() - start_time)
                    console.print(f"  [dim]Evaluated in {elapsed_final}s[/dim]")
                console.print()
                return result

            if elapsed >= max_wait:
                raise TimeoutError(
                    f"Evaluation did not complete within {int(max_wait)} seconds"
                )

            # Adaptive polling
            if elapsed < 10:
                time.sleep(1.0)
            elif elapsed < 30:
                time.sleep(2.0)
            else:
                time.sleep(5.0)


# ---------------------------------------------------------------------------
# Full evaluation report
# ---------------------------------------------------------------------------

def format_eval_report(console: Console, data: dict) -> None:
    """Render the CLI evaluation report.

    Layout:
        VERDICT · Risk
        Cache hit line      (if cache_hit=true)
        Hook                (one-line plain English)
        What we concluded   (verdict_brief prose + confirmation/warning bullets)
        What we found       (detection signals, conditional by verdict)
        URLs                (classified URLs, hidden for CLEAR)
        MITRE               (if present, hidden for CLEAR)
        Full report → link
    """
    summary_data = data.get("summary", {})
    verdict = summary_data.get("verdict", data.get("verdict", "unknown")).lower()
    risk = summary_data.get("risk", data.get("risk", "unknown")).lower()
    narrative = data.get("verdict_narrative", {})
    is_clear = verdict in ("clear", "benign")

    # -- Verdict bar --
    style_info = VERDICT_STYLES.get(verdict, ("white", verdict.upper()))
    color, label = style_info
    # CLEAR always shows "Low Risk" regardless of API value
    if is_clear:
        risk_display = "Low"
    else:
        risk_display = risk.capitalize() if risk and risk != "unknown" else ""

    verdict_text = f"  {label}"
    if risk_display:
        verdict_text += f" \u00b7 {risk_display} Risk"

    panel = Panel(
        Text(verdict_text, style=f"bold {color}"),
        border_style=color,
        padding=(0, 1),
        expand=True,
    )
    console.print(panel)

    # -- Cache hit line --
    if data.get("cache_hit"):
        seen_count = (data.get("cache_enrichment") or {}).get("seen_count", 1)
        if seen_count and seen_count > 1:
            cache_msg = f"we've seen this {seen_count} times before."
        else:
            cache_msg = "we've seen this once before."
        console.print(f"  [dim]\u21bb Cache hit \u2014 {cache_msg}[/dim]")

    console.print()

    # -- Hook (one-line plain English) --
    hook = narrative.get("plain_english", "")
    if not hook:
        hook = summary_data.get("reason", data.get("reason", ""))
    if hook:
        console.print(f"  {hook}")
        console.print()

    # -- What we concluded (verdict_brief prose + confirmation/warning bullets) --
    _render_concluded_section(console, data, verdict, is_clear)

    # -- What we found (detection signals) --
    signals = _build_signals(data)
    if signals:
        # CLEAR: only show if there are actual signals
        # SUSPICIOUS/MALICIOUS: always show
        if not is_clear or signals:
            console.print("  [bold]What we found[/bold]")
            for signal in signals:
                console.print(f"    [dim]\u2022[/dim] {signal}")
            console.print()

    # -- URLs (hidden for CLEAR) --
    if not is_clear and _has_any_urls(data):
        _render_urls_section(console, data)

    # -- MITRE (hidden for CLEAR) --
    if not is_clear:
        mitre = data.get("forensics", {}).get("mitre_tactics", [])
        if mitre:
            mitre_str = ", ".join(mitre)
            console.print(f"  [dim]MITRE {mitre_str}[/dim]")
            console.print()

    # -- Full report link --
    analysis_id = data.get("id", "")
    if analysis_id:
        report_url = "https://tryclear.io/report/%s" % analysis_id
        console.print(f"  Full report \u2192 [dim]{report_url}[/dim]")
        console.print()


# ---------------------------------------------------------------------------
# Report helpers
# ---------------------------------------------------------------------------

def _render_concluded_section(
    console: Console, data: dict, verdict: str, is_clear: bool
) -> None:
    """Render 'What we concluded' section: verdict_brief prose + bullets."""
    # Build prose: verdict_brief → reasoning_trace → final_pass.explanation
    prose = data.get("verdict_brief", "")
    if not prose:
        prose = (data.get("forensics") or {}).get("reasoning_trace", "")
    if not prose:
        final_pass = data.get("verdict_narrative", {}).get("final_pass", {})
        prose = final_pass.get("explanation", "")

    # Build confirmation/warning bullets from final_pass.confirmed
    bullets = (
        data.get("verdict_narrative", {}).get("final_pass", {}).get("confirmed", [])
    )

    if not prose and not bullets:
        return

    console.print("  [bold]What we concluded[/bold]")
    if prose:
        console.print(f"    {_defang_prose(prose)}")

    # Bullets: ✓ for CLEAR, ⚠ for everything else
    if bullets:
        if prose:
            console.print()  # blank line between prose and bullets
        icon = "[green]\u2713[/green]" if is_clear else "[yellow]\u26a0[/yellow]"
        for bullet in bullets:
            console.print(f"    {icon} {bullet}")

    console.print()


def _defang_prose(text: str) -> str:
    """Defang any URLs embedded in prose text."""
    import re
    return re.sub(
        r'https?://[^\s)\]]+',
        lambda m: defang_url(m.group(0)),
        text,
    )


def _build_signals(data: dict) -> list:
    """Build bullet list of detection signals."""
    signals = []
    detection = data.get("detection", {})

    # Brands
    for brand in detection.get("brands_detected", []):
        if isinstance(brand, dict):
            name = brand.get("brand", brand.get("name", str(brand)))
            confidence = brand.get("confidence")
            if confidence is not None:
                signals.append(f"{name} branding ({confidence:.2f})")
            else:
                signals.append(f"{name} branding")
        else:
            signals.append(f"{brand} branding")

    # Login form
    ui_elements = detection.get("ui_elements", [])
    if _has_login_signals(ui_elements):
        signals.append("Login form detected")

    # QR codes
    for qr in detection.get("qr_data", [])[:2]:
        defanged = defang_url(str(qr))
        signals.append(f"QR code \u2192 {defanged}")

    # Honey words
    honey_words = detection.get("honey_words_matched", [])
    if honey_words:
        words = ", ".join(f'"{w}"' for w in honey_words[:4])
        if len(honey_words) > 4:
            words += f" (+{len(honey_words) - 4} more)"
        signals.append(f"Honey words: {words}")

    return signals


def _has_any_urls(data: dict) -> bool:
    """Check if any classified or raw URLs exist."""
    indicators = data.get("indicators", {})
    for key in URL_CLASSIFICATION:
        if indicators.get(key):
            return True
    iocs = data.get("iocs", {})
    if iocs.get("urls"):
        return True
    classified = iocs.get("classified", {})
    for key in URL_CLASSIFICATION:
        if classified.get(key):
            return True
    return False


def _render_urls_section(console: Console, data: dict) -> None:
    """Render classified URLs as standalone section (deduplicated)."""
    indicators = data.get("indicators", {})

    # Fall back to iocs.classified if indicators empty
    if not any(indicators.get(k) for k in URL_CLASSIFICATION):
        iocs = data.get("iocs", {})
        indicators = iocs.get("classified", indicators)

    console.print("  [bold]URLs[/bold]")

    # Deduplicate: same URL with multiple classifications → show worst
    deduped = deduplicate_urls(indicators)
    seen_urls = set()
    for url_str, key in deduped:
        seen_urls.add(url_str)
        icon, color, label = URL_CLASSIFICATION[key]
        defanged = defang_url(url_str)
        console.print(
            f"    [{color}]{icon}[/{color}] {defanged}    [{color}]{label}[/{color}]"
        )

    # Unclassified URLs from iocs.urls
    iocs = data.get("iocs", {})
    for url in iocs.get("urls", []):
        url_str = str(url)
        if url_str not in seen_urls:
            defanged = defang_url(url_str)
            console.print(f"    [dim]\u25cb[/dim] {defanged}")

    console.print()




# ---------------------------------------------------------------------------
# JSON output (eval --json)
# ---------------------------------------------------------------------------

def build_eval_json(data: dict) -> dict:
    """Build curated JSON output for eval --json.

    Mirrors format_eval_report() field sourcing and fallback logic.
    Shape scales by verdict: CLEAR omits what_we_found/urls/mitre,
    SUSPICIOUS omits mitre, MALICIOUS includes all.
    Empty sections are omitted entirely (keys absent, not null).
    """
    summary_data = data.get("summary", {})
    verdict_raw = summary_data.get("verdict", data.get("verdict", "unknown")).lower()
    risk = summary_data.get("risk", data.get("risk", "unknown")).lower()
    narrative = data.get("verdict_narrative", {})
    is_clear = verdict_raw in ("clear", "benign")

    # Normalize verdict label
    style_info = VERDICT_STYLES.get(verdict_raw, ("white", verdict_raw.upper()))
    _, label = style_info

    # Risk: CLEAR always "Low Risk"
    if is_clear:
        risk_display = "Low Risk"
    else:
        risk_display = f"{risk.capitalize()} Risk" if risk and risk != "unknown" else ""

    # Hook: plain_english → summary.reason → data.reason
    hook = narrative.get("plain_english", "")
    if not hook:
        hook = summary_data.get("reason", data.get("reason", ""))
    if hook:
        hook = _defang_prose(hook)

    # Concluded narrative: verdict_brief → reasoning_trace → explanation
    prose = data.get("verdict_brief", "")
    if not prose:
        prose = (data.get("forensics") or {}).get("reasoning_trace", "")
    if not prose:
        final_pass = narrative.get("final_pass", {})
        prose = final_pass.get("explanation", "")
    if prose:
        prose = _defang_prose(prose)

    # Bullets from final_pass.confirmed — strip icon prefixes
    raw_bullets = narrative.get("final_pass", {}).get("confirmed", [])
    bullets = [b.lstrip("\u2713\u26a0 ") for b in raw_bullets] if raw_bullets else []

    # -- Build result --
    result = {}
    result["verdict"] = label
    if risk_display:
        result["risk_level"] = risk_display

    if hook:
        result["hook"] = hook

    # What we concluded
    concluded = {}
    if prose:
        concluded["narrative"] = prose
    if bullets:
        if is_clear:
            concluded["confirmations"] = bullets
        else:
            concluded["warnings"] = bullets
    if concluded:
        result["what_we_concluded"] = concluded

    # What we found (omit for CLEAR)
    if not is_clear:
        found = _build_found_json(data)
        if found:
            result["what_we_found"] = found

    # URLs (omit for CLEAR)
    if not is_clear:
        urls = _build_urls_json(data)
        if urls:
            result["urls"] = urls

    # MITRE (MALICIOUS only)
    if verdict_raw in ("malicious", "blocked"):
        mitre = data.get("forensics", {}).get("mitre_tactics", [])
        if mitre:
            result["mitre_techniques"] = list(mitre)

    # Report URL
    analysis_id = data.get("id", "")
    if analysis_id:
        result["report_url"] = f"https://tryclear.io/report/{analysis_id}"

    # Cache
    result["cached"] = bool(data.get("cache_hit"))
    if result["cached"]:
        result["cache_seen_count"] = (data.get("cache_enrichment") or {}).get("seen_count", 1)

    return result


def _build_found_json(data: dict) -> dict:
    """Build what_we_found section from detection signals."""
    found = {}
    detection = data.get("detection", {})

    # Brands — normalize to {name, confidence}
    brands = []
    for brand in detection.get("brands_detected", []):
        if isinstance(brand, dict):
            name = brand.get("brand", brand.get("name", str(brand)))
            confidence = brand.get("confidence")
            try:
                confidence = float(confidence) if confidence is not None else 0.0
            except (TypeError, ValueError):
                confidence = 0.0
            brands.append({"name": name, "confidence": round(confidence, 2)})
        else:
            brands.append({"name": str(brand), "confidence": 0.0})
    if brands:
        found["brands"] = brands

    # Signals — same three sources as _build_signals()
    signals = []
    ui_elements = detection.get("ui_elements", [])
    if _has_login_signals(ui_elements):
        signals.append("Login form detected")

    for qr in detection.get("qr_data", [])[:2]:
        defanged = defang_url(str(qr))
        signals.append(f"QR code: {defanged}")

    honey_words = detection.get("honey_words_matched", [])
    if honey_words:
        words = ", ".join(f'"{w}"' for w in honey_words[:4])
        if len(honey_words) > 4:
            words += f" (+{len(honey_words) - 4} more)"
        signals.append(f"Honey words: {words}")

    if signals:
        found["signals"] = signals

    return found


def _build_urls_json(data: dict) -> list:
    """Build classified URL list, deduplicated by severity."""
    indicators = data.get("indicators", {})

    # Fall back to iocs.classified if indicators empty
    if not any(indicators.get(k) for k in URL_CLASSIFICATION):
        iocs = data.get("iocs", {})
        indicators = iocs.get("classified", indicators)

    # Deduplicate: same URL → worst classification wins
    deduped = deduplicate_urls(indicators)
    seen_urls = set()
    urls = []
    for url_str, key in deduped:
        seen_urls.add(url_str)
        _, _, classification_label = URL_CLASSIFICATION[key]
        urls.append({
            "url": defang_url(url_str),
            "classification": classification_label,
        })

    # Unclassified from iocs.urls
    iocs = data.get("iocs", {})
    for url in iocs.get("urls", []):
        url_str = str(url)
        if url_str not in seen_urls:
            urls.append({
                "url": defang_url(url_str),
                "classification": "UNCLASSIFIED",
            })

    return urls


# ---------------------------------------------------------------------------
# JSON output (report --json)
# ---------------------------------------------------------------------------

# UI element prettifier: snake_case → display label
_UI_ELEMENT_LABELS = {
    "login_form": "Login Fields",
    "email_phone_field": "Email/Phone Field",
    "password_field": "Password Input",
    "submit_button": "Submit Button",
    "navigation_menu": "Navigation Menu",
    "remember_me": "Remember Me",
    "social_login": "Social Login",
}


def build_report_json(data: dict) -> dict:
    """Build curated JSON output for report --json.

    Mirrors the web UI's 6-section report structure.
    Empty sections/keys are omitted entirely.
    """
    summary_data = data.get("summary", {})
    verdict_raw = summary_data.get("verdict", data.get("verdict", "unknown")).lower()
    risk = summary_data.get("risk", data.get("risk", "unknown")).lower()
    is_clear = verdict_raw in ("clear", "benign")

    style_info = VERDICT_STYLES.get(verdict_raw, ("white", verdict_raw.upper()))
    _, label = style_info

    if is_clear:
        risk_display = "Low Risk"
    else:
        risk_display = f"{risk.capitalize()} Risk" if risk and risk != "unknown" else ""

    result = {"verdict": label}
    if risk_display:
        result["risk_level"] = risk_display

    # verdict_brief → array of paragraphs
    vb = data.get("verdict_brief", "")
    if vb:
        import re
        paragraphs = [_defang_prose(p.strip()) for p in re.split(r'\n\n+', vb) if p.strip()]
        if paragraphs:
            result["verdict_brief"] = paragraphs

    # -- Section 01: What Clear Observed --
    s01 = _build_section_01(data)
    if s01:
        result["01_what_clear_observed"] = s01

    # -- Section 02: How Clear Investigated --
    s02 = _build_section_02(data)
    if s02:
        result["02_how_clear_investigated"] = s02

    # -- Section 03: What We Concluded --
    s03 = _build_section_03(data, label, risk_display, is_clear)
    if s03:
        result["03_what_we_concluded"] = s03

    # -- Section 04: VPI Evidence (conditional — only when ISVI detected) --
    s_vpi = _build_section_vpi(data)
    if s_vpi:
        result["04_vpi_evidence"] = s_vpi

    # -- Section 05: URL Intelligence (omit for CLEAR) --
    if not is_clear:
        s05 = _build_section_04(data)
        if s05:
            result["05_url_intelligence"] = s05

    # -- Section 06: History --
    s06 = _build_section_05(data)
    if s06:
        result["06_history"] = s06

    # -- Section 07: Technical Details --
    s07 = _build_section_06(data)
    if s07:
        result["07_technical_details"] = s07

    # Report URL
    analysis_id = data.get("id", "")
    if analysis_id:
        result["report_url"] = f"https://tryclear.io/report/{analysis_id}"

    return result


def _build_section_01(data: dict) -> dict:
    """Section 01: What Clear Observed."""
    section = {}
    detection = data.get("detection", {})

    # Brand recognition — same normalization as build_eval_json
    brands = []
    for brand in detection.get("brands_detected", []):
        if isinstance(brand, dict):
            name = brand.get("brand", brand.get("name", str(brand)))
            confidence = brand.get("confidence")
            try:
                confidence = float(confidence) if confidence is not None else 0.0
            except (TypeError, ValueError):
                confidence = 0.0
            brands.append({"name": name, "confidence": round(confidence, 2)})
        else:
            brands.append({"name": str(brand), "confidence": 0.0})
    if brands:
        section["brand_recognition"] = brands

    # Page composition — prettify ui_elements
    ui_elements = detection.get("ui_elements", [])
    if ui_elements:
        labels = []
        for el in ui_elements:
            el_str = str(el).lower().strip()
            pretty = _UI_ELEMENT_LABELS.get(el_str)
            if not pretty:
                pretty = el_str.replace("_", " ").title()
            labels.append(pretty)
        if labels:
            section["page_composition"] = labels

    # QR codes — defanged
    qr_data = detection.get("qr_data", [])
    if qr_data:
        section["qr_codes"] = [defang_url(str(qr)) for qr in qr_data]

    # Auth providers
    narrative = data.get("verdict_narrative", {})
    auth = narrative.get("auth_providers")
    if auth and isinstance(auth, dict):
        ap = {}
        if auth.get("title"):
            ap["title"] = auth["title"]
        if auth.get("description"):
            ap["description"] = auth["description"]
        if auth.get("providers"):
            ap["providers"] = list(auth["providers"])
        if ap:
            section["auth_providers"] = ap

    return section


def _build_section_02(data: dict) -> dict:
    """Section 02: How Clear Investigated."""
    section = {}
    narrative = data.get("verdict_narrative") or {}
    hardening = data.get("hardening") or {}

    # Shield intercept
    if hardening.get("code"):
        si = {"code": hardening["code"]}
        if hardening.get("title"):
            si["title"] = hardening["title"]
        if hardening.get("reason"):
            si["description"] = hardening["reason"]
        section["shield_intercept"] = si

    # Three investigation passes
    fp = narrative.get("first_pass")
    if fp and isinstance(fp, dict):
        entry = {}
        if fp.get("title"):
            entry["title"] = fp["title"]
        if fp.get("spotted"):
            entry["spotted"] = list(fp["spotted"])
        if fp.get("outcome"):
            entry["outcome"] = fp["outcome"]
        if entry:
            section["first_pass"] = entry

    sp = narrative.get("second_pass")
    if sp and isinstance(sp, dict):
        entry = {}
        if sp.get("title"):
            entry["title"] = sp["title"]
        if sp.get("found"):
            entry["found"] = list(sp["found"])
        if sp.get("outcome"):
            entry["outcome"] = sp["outcome"]
        if entry:
            section["second_pass"] = entry

    flp = narrative.get("final_pass")
    if flp and isinstance(flp, dict):
        entry = {}
        if flp.get("title"):
            entry["title"] = flp["title"]
        if flp.get("explanation"):
            entry["explanation"] = _defang_prose(flp["explanation"])
        if entry:
            section["final_pass"] = entry

    # If no narrative at all, fall back to reasoning_trace
    if not section or (not narrative.get("first_pass") and not narrative.get("final_pass")):
        trace = (data.get("forensics") or {}).get("reasoning_trace", "")
        if trace:
            section["reasoning"] = _defang_prose(trace)

    return section


def _build_section_03(data: dict, label: str, risk_display: str, is_clear: bool) -> dict:
    """Section 03: What We Concluded."""
    section = {"verdict": label}
    summary_data = data.get("summary", {})
    narrative = data.get("verdict_narrative", {})

    # Risk — omit for CLEAR
    if not is_clear and risk_display:
        section["risk_level"] = risk_display

    # Reason
    reason = summary_data.get("reason", data.get("reason", ""))
    if reason:
        section["reason"] = reason

    # Confirmed bullets — strip icon prefixes
    raw_bullets = narrative.get("final_pass", {}).get("confirmed", [])
    if raw_bullets:
        section["confirmed"] = [b.lstrip("\u2713\u26a0 ") for b in raw_bullets]

    # MITRE — omit for CLEAR
    if not is_clear:
        mitre = data.get("forensics", {}).get("mitre_tactics", [])
        if mitre:
            section["mitre_techniques"] = list(mitre)

    return section


def _build_section_vpi(data: dict) -> dict:
    """Visual Prompt Injection Evidence. Only included when ISVI detected."""
    isvi = data.get("isvi_metadata") or {}
    if not isvi.get("isvi_detected"):
        return {}

    directives = data.get("agent_directives") or {}
    section = {
        "title": "Visual Prompt Injection (VPI)",
        "subtitle": "Hidden instructions found in this image, designed to hijack automated systems",
        "isvi_score": isvi.get("isvi_score"),
        "isvi_signals": isvi.get("isvi_signals"),
        "isvi_summary": isvi.get("isvi_summary"),
        "directive_text": directives.get("directive_text"),
        "instructions_found": directives.get("instructions_found"),
        "intent_assessment": directives.get("intent_assessment"),
        "ocr_full_corpus": data.get("ocr_full_corpus"),
    }
    return {k: v for k, v in section.items() if v is not None}


def _build_section_04(data: dict) -> dict:
    """Section 04: URL Intelligence."""
    detection = data.get("detection", {})
    indicators = data.get("indicators", {})

    # Fall back to iocs.classified
    if not any(indicators.get(k) for k in URL_CLASSIFICATION):
        iocs = data.get("iocs", {})
        indicators = iocs.get("classified", indicators)

    # Build URL entries with full metadata
    deduped = deduplicate_urls(indicators)
    seen_urls = set()
    urls = []
    for url_str, key in deduped:
        seen_urls.add(url_str)
        # Find the original entry dict for metadata
        entry_meta = _find_url_entry(indicators, key, url_str)
        url_obj = {
            "url": defang_url(url_str),
            "classification": key,
        }
        if entry_meta.get("description"):
            url_obj["reason"] = entry_meta["description"]
        elif entry_meta.get("reason"):
            url_obj["reason"] = entry_meta["reason"]
        if entry_meta.get("source"):
            url_obj["source"] = entry_meta["source"]
        if entry_meta.get("matched_brand"):
            url_obj["matched_brand"] = entry_meta["matched_brand"]
        urls.append(url_obj)

    # Unclassified from iocs.urls
    iocs = data.get("iocs", {})
    for url in iocs.get("urls", []):
        url_str = str(url)
        if url_str not in seen_urls:
            urls.append({
                "url": defang_url(url_str),
                "classification": "unclassified",
            })

    if not urls:
        return {}

    section = {}

    # Brand context — primary brand
    brands = detection.get("brands_detected", [])
    if brands:
        first = brands[0]
        if isinstance(first, dict):
            section["brand_context"] = first.get("brand", first.get("name", str(first)))
        else:
            section["brand_context"] = str(first)

    section["urls"] = urls
    return section


def _find_url_entry(indicators: dict, bucket: str, url_str: str) -> dict:
    """Find the original URL entry dict in a classification bucket."""
    for entry in indicators.get(bucket, []):
        if isinstance(entry, dict):
            if entry.get("url", "") == url_str:
                return entry
        elif str(entry) == url_str:
            return {}
    return {}


def _build_section_05(data: dict) -> dict:
    """Section 05: History."""
    cache = data.get("cache_enrichment") or {}
    campaign = data.get("campaign") or {}
    has_cache = bool(cache)
    is_campaign = bool(campaign.get("is_campaign") or (campaign.get("seen_count") and int(campaign.get("seen_count", 0)) > 50))

    if not has_cache and not is_campaign:
        return {}

    section = {}
    if cache.get("first_seen_at"):
        section["first_seen"] = cache["first_seen_at"]
    if cache.get("last_seen_at"):
        section["last_seen"] = cache["last_seen_at"]

    seen = cache.get("seen_count") or cache.get("hit_count")
    if seen is not None:
        try:
            section["times_seen"] = int(seen)
        except (TypeError, ValueError):
            pass

    if cache.get("source_analysis_id"):
        section["original_analysis_id"] = cache["source_analysis_id"]

    if is_campaign:
        camp = {}
        if campaign.get("campaign_id"):
            camp["campaign_id"] = campaign["campaign_id"]
        if campaign.get("seen_count"):
            try:
                camp["seen_count"] = int(campaign["seen_count"])
            except (TypeError, ValueError):
                pass
        if campaign.get("first_seen_at"):
            camp["first_seen"] = campaign["first_seen_at"]
        if camp:
            section["campaign"] = camp

    return section


def _build_section_06(data: dict) -> dict:
    """Section 06: Technical Details."""
    section = {}
    input_data = data.get("input") or {}

    analysis_id = data.get("id", "")
    if analysis_id:
        section["analysis_id"] = analysis_id

    ct = input_data.get("content_type")
    if ct:
        section["content_type"] = ct

    size = input_data.get("size_bytes")
    if size is not None:
        try:
            section["file_size_bytes"] = int(size)
        except (TypeError, ValueError):
            pass

    created = data.get("created_at")
    completed = data.get("completed_at")
    if created:
        section["submitted"] = created
    if completed:
        section["completed"] = completed

    # Processing time — compute delta in ms
    if created and completed:
        try:
            from datetime import datetime
            fmt = "%Y-%m-%dT%H:%M:%S"
            # Handle fractional seconds and Z suffix
            c_str = str(created).replace("Z", "+00:00")
            d_str = str(completed).replace("Z", "+00:00")
            # Strip timezone for simple parsing
            c_clean = c_str.split("+")[0].split(".")[0]
            d_clean = d_str.split("+")[0].split(".")[0]
            t_created = datetime.strptime(c_clean, fmt)
            t_completed = datetime.strptime(d_clean, fmt)
            delta_ms = int((t_completed - t_created).total_seconds() * 1000)
            if delta_ms >= 0:
                section["processing_time_ms"] = delta_ms
        except (ValueError, TypeError):
            pass

    sha = input_data.get("sha256")
    if sha:
        section["sha256"] = sha

    # Threat artifacts
    iocs = data.get("iocs") or {}
    artifacts = {}
    raw_urls = iocs.get("urls", [])
    if raw_urls:
        artifacts["urls"] = [defang_url(str(u)) for u in raw_urls]
    if iocs.get("domains"):
        artifacts["domains"] = list(iocs["domains"])
    if iocs.get("ips"):
        artifacts["ips"] = list(iocs["ips"])
    if iocs.get("hashes"):
        artifacts["hashes"] = list(iocs["hashes"])
    if artifacts:
        section["threat_artifacts"] = artifacts

    # OCR extract — first 500 chars
    ocr = (data.get("detection") or {}).get("ocr_snippet", "")
    if ocr:
        section["ocr_extract"] = str(ocr)[:500]

    return section


# ---------------------------------------------------------------------------
# Findings detection
# ---------------------------------------------------------------------------

def _has_findings(data: dict) -> bool:
    """Check if there are any findings to display."""
    indicators = data.get("indicators", {})
    detection = data.get("detection", {})
    iocs = data.get("iocs", {})

    has_urls = any(
        indicators.get(k) for k in URL_CLASSIFICATION
    )
    if not has_urls:
        classified = iocs.get("classified", {})
        has_urls = bool(iocs.get("urls")) or any(
            classified.get(k) for k in URL_CLASSIFICATION
        )

    has_brands = bool(detection.get("brands_detected"))
    has_signals = (
        bool(detection.get("honey_words_matched"))
        or bool(detection.get("qr_data"))
        or _has_login_signals(detection.get("ui_elements", []))
    )

    return has_urls or has_brands or has_signals


def _has_login_signals(ui_elements: list) -> bool:
    """Check if ui_elements contain meaningful signals."""
    if not ui_elements:
        return False
    login_keywords = {
        "login", "password", "username", "email",
        "signin", "sign_in", "login_form",
    }
    return any(
        any(k in str(e).lower() for k in login_keywords)
        for e in ui_elements
    )


# ---------------------------------------------------------------------------
# Brief status display
# ---------------------------------------------------------------------------

def format_status(console: Console, status_data: dict) -> None:
    """Print brief analysis status."""
    status = status_data.get("status", "unknown")
    analysis_id = status_data.get("id", "unknown")

    if status == "done":
        summary = status_data.get("summary", {})
        verdict = summary.get("verdict", status_data.get("verdict", "unknown"))
        risk = summary.get("risk", status_data.get("risk"))
        reason = summary.get("reason", status_data.get("reason"))

        style_info = VERDICT_STYLES.get(verdict.lower(), ("white", verdict.upper()))
        color, label = style_info

        console.print(f"  [bold]Status[/bold]   [green]done[/green]")
        console.print(f"  [bold]Verdict[/bold]  [{color}]{label}[/{color}]")

        if risk:
            risk_color = RISK_STYLES.get(risk.lower(), "white")
            console.print(
                f"  [bold]Risk[/bold]     [{risk_color}]{risk.capitalize()}[/{risk_color}]"
            )

        if reason:
            console.print(f"  [bold]Reason[/bold]   {reason}")

        console.print()
        console.print(
            f"  Run [bold]clear report {analysis_id}[/bold] for full details."
        )

    elif status in ("failed", "error"):
        console.print(f"  [bold]Status[/bold]  [red]{status}[/red]")
        error = status_data.get("error", "Unknown error")
        console.print(f"  [bold]Error[/bold]   {error}")

    elif status in ("queued", "running"):
        console.print(f"  [bold]Status[/bold]  [yellow]{status}[/yellow]")
        console.print()
        console.print(
            f"  Still processing. Run [bold]clear status {analysis_id}[/bold] again shortly."
        )

    else:
        console.print(f"  [bold]Status[/bold]  {status}")
