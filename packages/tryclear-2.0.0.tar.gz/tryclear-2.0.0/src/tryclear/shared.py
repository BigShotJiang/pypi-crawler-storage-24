"""Shared constants and utilities for Clear CLI."""

# Exit codes
EXIT_CLEAR = 0
EXIT_SUSPICIOUS = 1
EXIT_MALICIOUS = 2
EXIT_ERROR = 3


def verdict_to_exit_code(verdict: str) -> int:
    """Convert verdict string to exit code."""
    v = verdict.lower()
    if v in ("benign", "clear"):
        return EXIT_CLEAR
    elif v == "suspicious":
        return EXIT_SUSPICIOUS
    elif v in ("malicious", "blocked"):
        return EXIT_MALICIOUS
    return EXIT_ERROR
