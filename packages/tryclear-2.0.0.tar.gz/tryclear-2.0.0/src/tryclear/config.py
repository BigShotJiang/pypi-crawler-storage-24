"""Configuration management for Clear CLI."""

import json
import os
import sys
from pathlib import Path
from typing import Optional

DEFAULT_API_URL = "https://api.tryclear.io/v1"


def get_config_dir() -> Path:
    """Get platform-appropriate config directory."""
    if sys.platform == "win32":
        base = os.environ.get("APPDATA")
        if base:
            return Path(base) / "clear"
        return Path.home() / "AppData" / "Roaming" / "clear"
    else:
        xdg_config = os.environ.get("XDG_CONFIG_HOME")
        if xdg_config:
            return Path(xdg_config) / "clear"
        return Path.home() / ".config" / "clear"


def get_legacy_config_dir() -> Path:
    """Get legacy tryclear config directory for migration."""
    if sys.platform == "win32":
        base = os.environ.get("APPDATA")
        if base:
            return Path(base) / "tryclear"
        return Path.home() / "AppData" / "Roaming" / "tryclear"
    else:
        xdg_config = os.environ.get("XDG_CONFIG_HOME")
        if xdg_config:
            return Path(xdg_config) / "tryclear"
        return Path.home() / ".config" / "tryclear"


def get_config_path() -> Path:
    """Get path to config file."""
    return get_config_dir() / "config.json"


def get_legacy_config_path() -> Path:
    """Get path to legacy config file."""
    return get_legacy_config_dir() / "config.json"


def load_config() -> Optional[dict]:
    """Load config from file. Checks new location first, then legacy."""
    config_path = get_config_path()
    if config_path.exists():
        try:
            with open(config_path, "r") as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            return None

    # Fall back to legacy location
    legacy_path = get_legacy_config_path()
    if legacy_path.exists():
        try:
            with open(legacy_path, "r") as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError):
            return None

    return None


def save_config(
    api_key: str,
    api_url: str = DEFAULT_API_URL,
    tier: Optional[str] = None,
    monthly_remaining: Optional[int] = None,
) -> Path:
    """Save config to file. Returns path where saved."""
    config_dir = get_config_dir()
    config_dir.mkdir(parents=True, exist_ok=True)

    config_path = get_config_path()
    config = {
        "api_key": api_key,
        "api_url": api_url,
    }
    if tier:
        config["tier"] = tier
    if monthly_remaining is not None:
        config["monthly_remaining"] = monthly_remaining

    with open(config_path, "w") as f:
        json.dump(config, f, indent=2)

    # Set restrictive permissions on Unix
    if sys.platform != "win32":
        os.chmod(config_path, 0o600)

    return config_path


def get_api_key() -> Optional[str]:
    """Get API key from env or config. New env var takes precedence."""
    # CLEAR_API_KEY (new) > TRYCLEAR_API_KEY (legacy) > config file
    env_key = os.environ.get("CLEAR_API_KEY") or os.environ.get("TRYCLEAR_API_KEY")
    if env_key:
        return env_key

    config = load_config()
    if config:
        return config.get("api_key")

    return None


def get_api_url() -> str:
    """Get API URL from env or config."""
    env_url = os.environ.get("CLEAR_API_URL") or os.environ.get("TRYCLEAR_API_URL")
    if env_url:
        return env_url

    config = load_config()
    if config:
        return config.get("api_url", DEFAULT_API_URL)

    return DEFAULT_API_URL


def get_brand_info() -> dict:
    """Get tier and remaining evals from config (cached from auth)."""
    config = load_config()
    if not config:
        return {}
    result = {}
    if config.get("tier"):
        result["tier"] = config["tier"]
    if config.get("monthly_remaining") is not None:
        result["monthly_remaining"] = config["monthly_remaining"]
    return result


def has_legacy_config() -> bool:
    """Check if legacy tryclear config exists but new config does not."""
    return get_legacy_config_path().exists() and not get_config_path().exists()


def validate_api_key(key: str) -> bool:
    """Validate API key format."""
    return key.startswith("sk_live_") or key.startswith("sk_test_")
