"""CLI entry point for Clear."""

import argparse
import sys
from typing import List, Optional

from tryclear import __version__
from tryclear.display import get_console, print_error
from tryclear.commands import auth, eval as eval_cmd, status, report
from tryclear.shared import EXIT_ERROR


def create_parser() -> argparse.ArgumentParser:
    """Create argument parser."""
    parser = argparse.ArgumentParser(
        prog="clear",
        description="Clear — Image evaluation from the command line",
        epilog="Get started: https://tryclear.io",
    )

    parser.add_argument(
        "--version",
        action="version",
        version=f"clear {__version__}",
    )

    parser.add_argument(
        "--json",
        action="store_true",
        help="Output in JSON format",
    )

    parser.add_argument(
        "--quiet",
        action="store_true",
        help="Suppress output, exit code only",
    )

    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Show request/response details",
    )

    subparsers = parser.add_subparsers(dest="command", help="Commands")

    # auth
    auth_parser = subparsers.add_parser(
        "auth",
        help="Validate and store your API key",
    )
    auth_parser.add_argument(
        "--api-key",
        help="API key (or enter interactively)",
    )
    auth_parser.add_argument(
        "--api-url",
        help="API URL (advanced)",
    )

    # eval
    eval_parser = subparsers.add_parser(
        "eval",
        help="Evaluate an image file",
    )
    eval_parser.add_argument(
        "file",
        help="File to evaluate",
    )
    eval_parser.add_argument(
        "--async",
        dest="async_mode",
        action="store_true",
        help="Submit without waiting for result",
    )
    eval_parser.add_argument(
        "--timeout",
        type=float,
        default=300.0,
        help="Max seconds to wait (default: 300)",
    )

    # status
    status_parser = subparsers.add_parser(
        "status",
        help="Check evaluation status",
    )
    status_parser.add_argument(
        "id",
        help="Analysis ID",
    )

    # report
    report_parser = subparsers.add_parser(
        "report",
        help="Get full evaluation report",
    )
    report_parser.add_argument(
        "id",
        help="Analysis ID",
    )

    return parser


def main(argv: Optional[List[str]] = None) -> int:
    """Main entry point. Returns exit code."""
    # Legacy aliases — rewrite before argparse sees them
    if argv is None:
        argv = sys.argv[1:]
    else:
        argv = list(argv)
    if argv and argv[0] == "configure":
        argv[0] = "auth"
    elif argv and argv[0] == "scan":
        argv[0] = "eval"

    parser = create_parser()
    args = parser.parse_args(argv)

    # Console setup — disable colors for json/quiet
    force_terminal = None
    if args.json or args.quiet:
        force_terminal = False
    console = get_console(force_terminal)

    # No command — show help
    if not args.command:
        parser.print_help()
        return 0

    try:
        if args.command == "auth":
            return auth.run(
                console,
                api_key=args.api_key,
                api_url=args.api_url,
            )

        elif args.command == "eval":
            return eval_cmd.run(
                console,
                file_path=args.file,
                async_mode=args.async_mode,
                json_output=args.json,
                quiet=args.quiet,
                verbose=args.verbose,
                timeout=args.timeout,
            )

        elif args.command == "status":
            return status.run(
                console,
                analysis_id=args.id,
                json_output=args.json,
                quiet=args.quiet,
            )

        elif args.command == "report":
            return report.run(
                console,
                analysis_id=args.id,
                json_output=args.json,
                quiet=args.quiet,
            )

        else:
            print_error(console, f"Unknown command: {args.command}")
            return EXIT_ERROR

    except KeyboardInterrupt:
        console.print()
        print_error(console, "Interrupted")
        return EXIT_ERROR
    except Exception as e:
        print_error(console, f"Unexpected error: {e}")
        return EXIT_ERROR


def cli():
    """Console script entry point."""
    sys.exit(main())


if __name__ == "__main__":
    cli()
