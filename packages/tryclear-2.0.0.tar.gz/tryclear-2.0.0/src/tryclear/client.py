"""API client for Clear."""

import mimetypes
from pathlib import Path
from typing import Optional

import requests

from tryclear import __version__


class TryClearError(Exception):
    """Base exception for API errors."""

    pass


class AuthError(TryClearError):
    """Authentication failed (invalid or revoked API key)."""

    pass


class NotFoundError(TryClearError):
    """Resource not found."""

    pass


class RateLimitError(TryClearError):
    """Rate limit exceeded."""

    def __init__(self, message: str, retry_after: Optional[int] = None):
        super().__init__(message)
        self.retry_after = retry_after


class QuotaExceededError(TryClearError):
    """Monthly or daily quota exceeded."""

    def __init__(self, message: str, quota: Optional[dict] = None, upgrade_url: Optional[str] = None):
        super().__init__(message)
        self.quota = quota
        self.upgrade_url = upgrade_url


class UpgradeRequiredError(TryClearError):
    """Feature requires a higher tier plan."""

    pass


class APIError(TryClearError):
    """Generic API error."""

    def __init__(self, message: str, status_code: int):
        super().__init__(message)
        self.status_code = status_code


class TryClearClient:
    """Client for Clear API."""

    def __init__(self, api_key: str, api_url: str, timeout: float = 30.0):
        self.api_key = api_key
        self.api_url = api_url.rstrip("/")
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers["Authorization"] = f"Bearer {api_key}"
        self.session.headers["User-Agent"] = f"clear-cli/{__version__}"

    def _handle_response(self, response: requests.Response) -> dict:
        """Handle API response, raising appropriate exceptions."""
        if response.status_code == 401:
            raise AuthError("Invalid or revoked API key")

        if response.status_code == 403:
            try:
                data = response.json()
                if data.get("error") == "upgrade_required":
                    raise UpgradeRequiredError(
                        "This feature requires a Pro or Enterprise plan"
                    )
                if data.get("error") == "feature_not_available":
                    feature = data.get("feature", "this feature")
                    raise UpgradeRequiredError(data.get("message", f"{feature} requires a higher plan"))
            except (ValueError, KeyError):
                pass
            raise AuthError("Access denied")

        if response.status_code == 404:
            raise NotFoundError("Analysis not found")

        if response.status_code == 429:
            try:
                data = response.json()
                if data.get("error") == "quota_exceeded":
                    raise QuotaExceededError(
                        data.get("message", "Quota exceeded"),
                        quota=data.get("quota"),
                        upgrade_url=data.get("upgrade_url"),
                    )
            except (ValueError, KeyError):
                pass
            retry_after = response.headers.get("Retry-After")
            raise RateLimitError(
                "Rate limit exceeded",
                retry_after=int(retry_after) if retry_after else None,
            )

        if response.status_code >= 500:
            raise APIError(f"Server error: {response.status_code}", response.status_code)

        if response.status_code >= 400:
            try:
                data = response.json()
                message = data.get("error", f"Request failed: {response.status_code}")
            except ValueError:
                message = f"Request failed: {response.status_code}"
            raise APIError(message, response.status_code)

        return response.json()

    def submit(self, file_path: Path) -> dict:
        """Submit a file for evaluation."""
        mime_type, _ = mimetypes.guess_type(str(file_path))
        content_type = mime_type or "application/octet-stream"

        with open(file_path, "rb") as f:
            response = self.session.post(
                f"{self.api_url}/analyses",
                files={"file": (file_path.name, f, content_type)},
                timeout=self.timeout,
            )

        return self._handle_response(response)

    def status(self, analysis_id: str) -> dict:
        """Get analysis status (full data when complete)."""
        response = self.session.get(
            f"{self.api_url}/analyses/{analysis_id}",
            timeout=self.timeout,
        )

        return self._handle_response(response)

    def report(self, analysis_id: str) -> dict:
        """Get analysis report (simplified view)."""
        response = self.session.get(
            f"{self.api_url}/analyses/{analysis_id}/report",
            timeout=self.timeout,
        )

        return self._handle_response(response)

    def usage(self) -> dict:
        """Get usage/quota info. May require JWT auth."""
        response = self.session.get(
            f"{self.api_url}/user/usage",
            timeout=self.timeout,
        )

        return self._handle_response(response)

    def list_analyses(self) -> dict:
        """List user's analyses. Works with API key auth."""
        response = self.session.get(
            f"{self.api_url}/user/analyses",
            timeout=self.timeout,
        )

        return self._handle_response(response)
