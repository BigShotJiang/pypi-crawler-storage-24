"""Clear — Image evaluation from the command line."""

__version__ = "2.0.0"
