"""Auth command — validate and store API key."""

import getpass
from typing import Optional

from rich.console import Console

from tryclear.client import TryClearClient, AuthError, APIError
from tryclear.config import (
    get_config_path,
    has_legacy_config,
    save_config,
    validate_api_key,
    DEFAULT_API_URL,
)
from tryclear.display import print_error, print_success, print_warning
from tryclear.shared import EXIT_CLEAR, EXIT_ERROR


def run(
    console: Console,
    api_key: Optional[str] = None,
    api_url: Optional[str] = None,
) -> int:
    """
    Authenticate with Clear API.

    Validates the key against the API before saving.
    """
    # Migration hint
    if has_legacy_config():
        print_warning(
            console,
            "Found legacy config at ~/.config/tryclear/. "
            "Run [bold]clear auth[/bold] to migrate.",
        )
        console.print()

    # Prompt for API key if not provided
    if not api_key:
        console.print("  Enter your API key [dim](from https://tryclear.io/settings)[/dim]:")
        try:
            api_key = getpass.getpass(prompt="  API key: ")
        except (KeyboardInterrupt, EOFError):
            console.print()
            print_error(console, "Cancelled")
            return EXIT_ERROR

    if not api_key or not api_key.strip():
        print_error(console, "API key cannot be empty")
        return EXIT_ERROR

    api_key = api_key.strip()

    # Validate format
    if not validate_api_key(api_key):
        print_error(
            console,
            "Invalid key format. Keys start with 'sk_live_' or 'sk_test_'",
        )
        return EXIT_ERROR

    # Use default URL if not provided
    if not api_url:
        api_url = DEFAULT_API_URL

    # Validate key against the API
    client = TryClearClient(api_key, api_url)
    tier_display = None
    remaining = None

    try:
        # Try usage endpoint first (has tier + quota info)
        usage = client.usage()
        tier_display = usage.get("tier_display", usage.get("tier", ""))
        monthly_remaining = usage.get("monthly_remaining")
        if monthly_remaining is not None and monthly_remaining != -1:
            remaining = monthly_remaining
        elif monthly_remaining == -1:
            remaining = None  # unlimited
    except (AuthError, APIError):
        # Usage endpoint may require JWT — fall back to list_analyses
        try:
            client.list_analyses()
        except AuthError:
            print_error(console, "Invalid or revoked API key")
            return EXIT_ERROR
        except Exception as e:
            print_error(console, f"Could not verify key: {e}")
            return EXIT_ERROR

    # Key is valid — save it (include tier/remaining for brand line)
    try:
        config_path = save_config(
            api_key, api_url,
            tier=tier_display,
            monthly_remaining=remaining,
        )
    except (IOError, OSError) as e:
        print_error(console, f"Failed to save config: {e}")
        return EXIT_ERROR

    # Build success message
    parts = ["Verified"]
    if tier_display:
        parts.append(f"{tier_display} tier")
    if remaining is not None:
        parts.append(f"{remaining} evaluations remaining")

    print_success(console, " — ".join(parts))
    console.print(f"  [dim]Key saved to {config_path}[/dim]")

    return EXIT_CLEAR
