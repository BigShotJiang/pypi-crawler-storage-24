"""Eval command — evaluate an image file."""

import json
import mimetypes
import sys
from pathlib import Path
from typing import Optional

from rich.console import Console

from tryclear.client import (
    TryClearClient,
    AuthError,
    RateLimitError,
    QuotaExceededError,
    APIError,
)
from tryclear.config import get_api_key, get_api_url, get_brand_info
from tryclear.display import (
    print_error,
    print_success,
    print_file_info,
    print_brand_line,
    print_welcome,
    wait_with_spinner,
    format_eval_report,
    build_eval_json,
    should_show_brand,
    mark_brand_shown,
    _format_size,
)
from tryclear.shared import EXIT_CLEAR, EXIT_ERROR, verdict_to_exit_code

ALLOWED_EXTENSIONS = {
    '.png', '.jpg', '.jpeg', '.bmp', '.tiff', '.tif',
    '.svg', '.webp', '.heic', '.heif',
}
SUPPORTED_FORMATS = "Supported formats: PNG, JPG, JPEG, BMP, TIFF, SVG, WebP, HEIC/HEIF"


def run(
    console: Console,
    file_path: str,
    async_mode: bool = False,
    json_output: bool = False,
    quiet: bool = False,
    verbose: bool = False,
    timeout: float = 300.0,
) -> int:
    """
    Evaluate a file.

    Returns:
        0 (clear), 1 (suspicious), 2 (malicious), or 3 (error)
    """
    # Validate file exists
    path = Path(file_path)
    if not path.exists():
        if json_output:
            print(json.dumps({"error": "File not found", "path": str(path)}))
        elif not quiet:
            print_error(console, f"File not found: {path}")
        return EXIT_ERROR

    if not path.is_file():
        if json_output:
            print(json.dumps({"error": "Not a file", "path": str(path)}))
        elif not quiet:
            print_error(console, f"Not a file: {path}")
        return EXIT_ERROR

    # Validate file type
    ext = path.suffix.lower()
    if ext not in ALLOWED_EXTENSIONS:
        if json_output:
            print(json.dumps({"error": f"Unsupported file type: {ext}", "supported": SUPPORTED_FORMATS}))
        elif not quiet:
            print_error(console, f"Unsupported file type: [bold]{ext or '(none)'}[/bold]")
            console.print(f"  {SUPPORTED_FORMATS}")
        return EXIT_ERROR

    # Get API credentials
    api_key = get_api_key()
    if not api_key:
        if json_output:
            print(json.dumps({"error": "Not authenticated. Run 'clear auth' first."}))
        elif not quiet:
            print_welcome(console)
        return EXIT_ERROR

    api_url = get_api_url()
    client = TryClearClient(api_key, api_url)

    # Display: brand line + file info
    if not quiet and not json_output:
        console.print()
        if should_show_brand():
            brand_info = get_brand_info()
            tier = brand_info.get("tier")
            remaining = brand_info.get("monthly_remaining")
            print_brand_line(console, tier, remaining)
            mark_brand_shown()
            console.print()
        size_bytes = path.stat().st_size
        mime_type, _ = mimetypes.guess_type(str(path))
        print_file_info(console, path.name, size_bytes, mime_type)

    # Submit

    if verbose:
        sys.stderr.write(f"POST {api_url}/analyses\n")

    try:
        result = client.submit(path)
    except AuthError:
        if json_output:
            print(json.dumps({"error": "Invalid or revoked API key"}))
        elif not quiet:
            print_error(console, "Invalid or revoked API key. Run [bold]clear auth[/bold] to reconfigure.")
        return EXIT_ERROR
    except QuotaExceededError as e:
        if json_output:
            output = {"error": "quota_exceeded", "message": str(e)}
            if e.quota:
                output["quota"] = e.quota
            print(json.dumps(output))
        elif not quiet:
            print_error(console, str(e))
        return EXIT_ERROR
    except RateLimitError as e:
        msg = "Rate limit exceeded"
        if e.retry_after:
            msg += f". Try again in {e.retry_after}s"
        if json_output:
            print(json.dumps({"error": msg}))
        elif not quiet:
            print_error(console, msg)
        return EXIT_ERROR
    except APIError as e:
        if json_output:
            print(json.dumps({"error": str(e)}))
        elif not quiet:
            print_error(console, str(e))
        return EXIT_ERROR
    except Exception as e:
        if json_output:
            print(json.dumps({"error": f"Request failed: {e}"}))
        elif not quiet:
            print_error(console, f"Request failed: {e}")
        return EXIT_ERROR

    analysis_id = result.get("id")

    if verbose:
        sys.stderr.write(f"  → {analysis_id} ({result.get('status')})\n")

    # Async mode — just return the ID
    if async_mode:
        if json_output:
            print(json.dumps({"id": analysis_id, "status": "queued"}))
        elif not quiet:
            print_success(console, f"Submitted: {analysis_id}")
            console.print(f"  Run [bold]clear status {analysis_id}[/bold] to check progress.")
        return EXIT_CLEAR

    # Sync mode — wait for completion
    try:
        final_result = wait_with_spinner(client, analysis_id, console, max_wait=timeout)
    except TimeoutError:
        if json_output:
            print(json.dumps({"id": analysis_id, "error": "Evaluation timed out"}))
        elif not quiet:
            print_error(console, "Evaluation timed out")
            console.print(f"  Run [bold]clear status {analysis_id}[/bold] to check later.")
        return EXIT_ERROR
    except Exception as e:
        if json_output:
            print(json.dumps({"id": analysis_id, "error": str(e)}))
        elif not quiet:
            print_error(console, str(e))
        return EXIT_ERROR

    # Handle failure
    if final_result.get("status") in ("failed", "error"):
        error = final_result.get("error", "Evaluation failed")
        if json_output:
            print(json.dumps({"id": analysis_id, "status": "failed", "error": error}))
        elif not quiet:
            print_error(console, error)
        return EXIT_ERROR

    # Extract verdict
    summary = final_result.get("summary", {})
    verdict = summary.get("verdict", final_result.get("verdict", "unknown"))

    if json_output:
        print(json.dumps(build_eval_json(final_result), default=str))
    elif not quiet:
        format_eval_report(console, final_result)

    return verdict_to_exit_code(verdict)
