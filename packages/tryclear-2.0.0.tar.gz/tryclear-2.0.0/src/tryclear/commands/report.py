"""Report command — get full evaluation report."""

import json

from rich.console import Console

from tryclear.client import (
    TryClearClient,
    AuthError,
    NotFoundError,
    UpgradeRequiredError,
    APIError,
)
from tryclear.config import get_api_key, get_api_url
from tryclear.display import print_error, format_eval_report, build_report_json
from tryclear.shared import EXIT_ERROR, verdict_to_exit_code


def run(
    console: Console,
    analysis_id: str,
    json_output: bool = False,
    quiet: bool = False,
) -> int:
    """
    Get full evaluation report.

    Uses status endpoint (full data) rather than report endpoint (simplified).
    """
    api_key = get_api_key()
    if not api_key:
        if json_output:
            print(json.dumps({"error": "Not configured. Run 'clear auth' first."}))
        elif not quiet:
            print_error(console, "Not configured. Run [bold]clear auth[/bold] first.")
        return EXIT_ERROR

    api_url = get_api_url()
    client = TryClearClient(api_key, api_url)

    try:
        result = client.status(analysis_id)
    except AuthError:
        if json_output:
            print(json.dumps({"error": "Invalid or revoked API key"}))
        elif not quiet:
            print_error(console, "Invalid or revoked API key")
        return EXIT_ERROR
    except NotFoundError:
        if json_output:
            print(json.dumps({"error": "Analysis not found"}))
        elif not quiet:
            print_error(console, "Analysis not found")
            console.print()
            console.print("  This could mean:")
            console.print("  [dim]\u2022[/dim] The analysis ID is incorrect")
            console.print("  [dim]\u2022[/dim] You're using a different API key")
            console.print()
            console.print("  Run [bold]clear auth[/bold] to check your key.")
        return EXIT_ERROR
    except APIError as e:
        if json_output:
            print(json.dumps({"error": str(e)}))
        elif not quiet:
            print_error(console, str(e))
        return EXIT_ERROR
    except Exception as e:
        if json_output:
            print(json.dumps({"error": f"Request failed: {e}"}))
        elif not quiet:
            print_error(console, f"Request failed: {e}")
        return EXIT_ERROR

    # Check if analysis is complete
    status = result.get("status")
    if status not in ("done", "failed", "error"):
        if json_output:
            print(json.dumps(result, default=str))
        elif not quiet:
            console.print(f"  Evaluation still {status}. Run [bold]clear status {analysis_id}[/bold] to check.")
        return EXIT_ERROR

    if json_output:
        print(json.dumps(build_report_json(result), default=str))
    elif not quiet:
        console.print()
        format_eval_report(console, result)

    # Determine exit code
    summary = result.get("summary", {})
    verdict = summary.get("verdict", result.get("verdict", "unknown"))
    return verdict_to_exit_code(verdict)
