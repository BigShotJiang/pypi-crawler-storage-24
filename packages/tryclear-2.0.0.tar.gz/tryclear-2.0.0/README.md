# TryClear CLI

> A picture is worth a thousand words. Attackers know that. Your security tools don't.

TryClear evaluates images for semantic threats — phishing, brand impersonation, QR code attacks, hidden page techniques, and visual prompt injection.

## Setup

```bash
# 1. Install
pip install tryclear

# 2. Authenticate (grab your API key from tryclear.io/settings)
tryclear auth

# 3. Evaluate
tryclear eval suspicious-screenshot.png
```

That's it. Forensic verdict in your terminal.

## Commands

| Command | Description |
|---------|-------------|
| `tryclear auth` | Store your API key |
| `tryclear eval <file>` | Evaluate an image, get a forensic verdict |
| `tryclear eval --json <file>` | Structured JSON output for scripting |
| `tryclear status <id>` | Check evaluation status |
| `tryclear report <id>` | Fetch full forensic report |

## Supported Formats

PNG, JPG, JPEG, BMP, TIFF, SVG, WebP, HEIC/HEIF

## Example

```
$ tryclear eval bank-document.tiff

  ◆ TryClear v2.0.0

  bank-document.tiff · 269 KB · image/tiff

  ╭──────────────────────────────────────────────────╮
  │   MALICIOUS · High Risk                          │
  ╰──────────────────────────────────────────────────╯

  Page 1 appeared clean, but hidden content on Page 2
  revealed the threat. This 'Hidden Page' technique is
  used to evade security scanners. The attack
  impersonates Bank of America.

    ⚠ Bank of America impersonation detected
    ⚠ QR code → hxxps://mail[.]google[.]com/mail/u/0/
    ⚠ Threat concealed on Page 2 of 2

  Full report → https://tryclear.io/report/ana_demo
```

## CI/CD Integration

```bash
tryclear eval ./assets/ --fail-on malicious --exit-code 1
```

| Exit Code | Meaning |
|-----------|---------|
| 0 | CLEAR |
| 1 | SUSPICIOUS |
| 2 | MALICIOUS |
| 3 | Error |

## Auth

The CLI resolves your API key in this order:

1. `TRYCLEAR_API_KEY` environment variable
2. `~/.config/tryclear/config.json`
3. `~/.config/clear/config.json`

## Learn More

[tryclear.io](https://tryclear.io)
