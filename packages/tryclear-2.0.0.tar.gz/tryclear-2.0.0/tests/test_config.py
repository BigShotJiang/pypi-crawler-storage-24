"""Tests for config module."""

import json
import os
import tempfile
from pathlib import Path
from unittest import mock

import pytest

from tryclear import config


class TestConfigPaths:
    """Test config path resolution."""

    def test_get_config_dir_linux(self):
        with mock.patch("sys.platform", "linux"):
            with mock.patch.dict(os.environ, {"XDG_CONFIG_HOME": "/custom/config"}, clear=False):
                result = config.get_config_dir()
                assert result == Path("/custom/config/clear")

    def test_get_config_dir_linux_default(self):
        with mock.patch("sys.platform", "linux"):
            with mock.patch.dict(os.environ, {}, clear=True):
                with mock.patch.object(Path, "home", return_value=Path("/home/user")):
                    result = config.get_config_dir()
                    assert result == Path("/home/user/.config/clear")

    @pytest.mark.skipif(os.name != "nt", reason="Windows-specific test")
    def test_get_config_dir_windows(self):
        with mock.patch("sys.platform", "win32"):
            with mock.patch.dict(os.environ, {"APPDATA": "C:\\Users\\Test\\AppData\\Roaming"}):
                result = config.get_config_dir()
                assert result == Path("C:\\Users\\Test\\AppData\\Roaming\\clear")

    def test_get_config_path(self):
        with mock.patch.object(config, "get_config_dir", return_value=Path("/test/dir")):
            result = config.get_config_path()
            assert result == Path("/test/dir/config.json")

    def test_legacy_config_dir(self):
        """Legacy dir uses 'tryclear' not 'clear'."""
        with mock.patch("sys.platform", "linux"):
            with mock.patch.dict(os.environ, {}, clear=True):
                with mock.patch.object(Path, "home", return_value=Path("/home/user")):
                    result = config.get_legacy_config_dir()
                    assert result == Path("/home/user/.config/tryclear")


class TestLoadSaveConfig:
    """Test config load/save."""

    def test_load_config_not_found(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            with mock.patch.object(config, "get_config_path", return_value=Path(tmpdir) / "config.json"):
                with mock.patch.object(config, "get_legacy_config_path", return_value=Path(tmpdir) / "legacy.json"):
                    result = config.load_config()
                    assert result is None

    def test_load_config_success(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config_path = Path(tmpdir) / "config.json"
            config_path.write_text(json.dumps({
                "api_key": "sk_live_test123",
                "api_url": "https://api.example.com"
            }))

            with mock.patch.object(config, "get_config_path", return_value=config_path):
                result = config.load_config()
                assert result == {
                    "api_key": "sk_live_test123",
                    "api_url": "https://api.example.com"
                }

    def test_load_config_invalid_json(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config_path = Path(tmpdir) / "config.json"
            config_path.write_text("not valid json")

            with mock.patch.object(config, "get_config_path", return_value=config_path):
                result = config.load_config()
                assert result is None

    def test_load_config_falls_back_to_legacy(self):
        """When new config doesn't exist, reads from legacy location."""
        with tempfile.TemporaryDirectory() as tmpdir:
            new_path = Path(tmpdir) / "new" / "config.json"
            legacy_path = Path(tmpdir) / "legacy" / "config.json"
            legacy_path.parent.mkdir(parents=True)
            legacy_path.write_text(json.dumps({
                "api_key": "sk_live_legacy_key",
                "api_url": "https://api.tryclear.io/v1"
            }))

            with mock.patch.object(config, "get_config_path", return_value=new_path):
                with mock.patch.object(config, "get_legacy_config_path", return_value=legacy_path):
                    result = config.load_config()
                    assert result["api_key"] == "sk_live_legacy_key"

    def test_save_config(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            config_dir = Path(tmpdir) / "clear"
            config_path = config_dir / "config.json"

            with mock.patch.object(config, "get_config_dir", return_value=config_dir):
                with mock.patch.object(config, "get_config_path", return_value=config_path):
                    result = config.save_config("sk_live_test456", "https://api.test.com")

                    assert result == config_path
                    assert config_path.exists()

                    saved = json.loads(config_path.read_text())
                    assert saved == {
                        "api_key": "sk_live_test456",
                        "api_url": "https://api.test.com"
                    }


class TestGetApiKey:
    """Test API key retrieval."""

    def test_get_api_key_from_clear_env(self):
        """CLEAR_API_KEY takes highest precedence."""
        with mock.patch.dict(os.environ, {"CLEAR_API_KEY": "sk_live_clear_key"}):
            result = config.get_api_key()
            assert result == "sk_live_clear_key"

    def test_get_api_key_from_legacy_env(self):
        """TRYCLEAR_API_KEY works as fallback."""
        with mock.patch.dict(os.environ, {"TRYCLEAR_API_KEY": "sk_live_legacy_key"}, clear=True):
            result = config.get_api_key()
            assert result == "sk_live_legacy_key"

    def test_clear_env_takes_precedence_over_legacy(self):
        with mock.patch.dict(os.environ, {
            "CLEAR_API_KEY": "sk_live_new",
            "TRYCLEAR_API_KEY": "sk_live_old",
        }):
            result = config.get_api_key()
            assert result == "sk_live_new"

    def test_get_api_key_from_config(self):
        with mock.patch.dict(os.environ, {}, clear=True):
            with mock.patch.object(config, "load_config", return_value={"api_key": "sk_live_config_key"}):
                result = config.get_api_key()
                assert result == "sk_live_config_key"

    def test_get_api_key_not_found(self):
        with mock.patch.dict(os.environ, {}, clear=True):
            with mock.patch.object(config, "load_config", return_value=None):
                result = config.get_api_key()
                assert result is None


class TestGetApiUrl:
    """Test API URL retrieval."""

    def test_get_api_url_from_clear_env(self):
        with mock.patch.dict(os.environ, {"CLEAR_API_URL": "https://custom.api.com/v1"}):
            result = config.get_api_url()
            assert result == "https://custom.api.com/v1"

    def test_get_api_url_default(self):
        with mock.patch.dict(os.environ, {}, clear=True):
            with mock.patch.object(config, "load_config", return_value=None):
                result = config.get_api_url()
                assert result == "https://api.tryclear.io/v1"


class TestHasLegacyConfig:
    """Test legacy config detection."""

    def test_has_legacy_when_old_exists_new_doesnt(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            legacy_path = Path(tmpdir) / "legacy.json"
            legacy_path.write_text("{}")
            new_path = Path(tmpdir) / "new.json"

            with mock.patch.object(config, "get_legacy_config_path", return_value=legacy_path):
                with mock.patch.object(config, "get_config_path", return_value=new_path):
                    assert config.has_legacy_config() is True

    def test_no_legacy_when_new_exists(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            legacy_path = Path(tmpdir) / "legacy.json"
            legacy_path.write_text("{}")
            new_path = Path(tmpdir) / "new.json"
            new_path.write_text("{}")

            with mock.patch.object(config, "get_legacy_config_path", return_value=legacy_path):
                with mock.patch.object(config, "get_config_path", return_value=new_path):
                    assert config.has_legacy_config() is False


class TestValidateApiKey:
    """Test API key validation."""

    def test_valid_live_key(self):
        assert config.validate_api_key("sk_live_abc123xyz") is True

    def test_valid_test_key(self):
        assert config.validate_api_key("sk_test_abc123xyz") is True

    def test_invalid_key(self):
        assert config.validate_api_key("invalid_key") is False
        assert config.validate_api_key("sk_invalid_key") is False
        assert config.validate_api_key("") is False
