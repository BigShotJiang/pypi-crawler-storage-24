"""Tests for API client."""

import tempfile
from pathlib import Path
from unittest import mock

import pytest
import responses

from tryclear.client import (
    TryClearClient,
    AuthError,
    NotFoundError,
    RateLimitError,
    QuotaExceededError,
    UpgradeRequiredError,
    APIError,
)


class TestTryClearClient:
    """Test API client."""

    @pytest.fixture
    def client(self):
        return TryClearClient(
            api_key="sk_live_test123",
            api_url="https://api.test.com/v1",
        )

    @responses.activate
    def test_submit_success(self, client):
        responses.add(
            responses.POST,
            "https://api.test.com/v1/analyses",
            json={"id": "ana_test123", "status": "queued"},
            status=200,
        )

        with tempfile.NamedTemporaryFile(delete=False, suffix=".txt") as f:
            f.write(b"test content")
            f.flush()

            result = client.submit(Path(f.name))

            assert result == {"id": "ana_test123", "status": "queued"}

    @responses.activate
    def test_submit_auth_error(self, client):
        responses.add(
            responses.POST,
            "https://api.test.com/v1/analyses",
            json={"error": "Unauthorized"},
            status=401,
        )

        with tempfile.NamedTemporaryFile(delete=False, suffix=".txt") as f:
            f.write(b"test")
            f.flush()

            with pytest.raises(AuthError):
                client.submit(Path(f.name))

    @responses.activate
    def test_submit_rate_limit(self, client):
        responses.add(
            responses.POST,
            "https://api.test.com/v1/analyses",
            json={"error": "Rate limit exceeded"},
            status=429,
            headers={"Retry-After": "60"},
        )

        with tempfile.NamedTemporaryFile(delete=False, suffix=".txt") as f:
            f.write(b"test")
            f.flush()

            with pytest.raises(RateLimitError) as exc:
                client.submit(Path(f.name))

            assert exc.value.retry_after == 60

    @responses.activate
    def test_submit_quota_exceeded(self, client):
        responses.add(
            responses.POST,
            "https://api.test.com/v1/analyses",
            json={
                "error": "quota_exceeded",
                "message": "You've used all 50 evaluations",
                "quota": {"tier": "free", "monthly_used": 50, "monthly_limit": 50},
                "upgrade_url": "https://tryclear.io/upgrade",
            },
            status=429,
        )

        with tempfile.NamedTemporaryFile(delete=False, suffix=".txt") as f:
            f.write(b"test")
            f.flush()

            with pytest.raises(QuotaExceededError) as exc:
                client.submit(Path(f.name))

            assert exc.value.quota["tier"] == "free"
            assert exc.value.upgrade_url == "https://tryclear.io/upgrade"

    @responses.activate
    def test_status_success(self, client):
        responses.add(
            responses.GET,
            "https://api.test.com/v1/analyses/ana_test123",
            json={
                "id": "ana_test123",
                "status": "done",
                "summary": {"verdict": "clear", "risk": "low"},
            },
            status=200,
        )

        result = client.status("ana_test123")

        assert result["summary"]["verdict"] == "clear"
        assert result["status"] == "done"

    @responses.activate
    def test_status_not_found(self, client):
        responses.add(
            responses.GET,
            "https://api.test.com/v1/analyses/ana_invalid",
            json={"error": "Not found"},
            status=404,
        )

        with pytest.raises(NotFoundError):
            client.status("ana_invalid")

    @responses.activate
    def test_report_success(self, client):
        responses.add(
            responses.GET,
            "https://api.test.com/v1/analyses/ana_test123/report",
            json={
                "id": "ana_test123",
                "verdict": "malicious",
                "risk": "high",
                "findings": [{"title": "QR Code", "description": "Malicious URL"}],
            },
            status=200,
        )

        result = client.report("ana_test123")

        assert result["verdict"] == "malicious"
        assert len(result["findings"]) == 1

    @responses.activate
    def test_report_upgrade_required(self, client):
        responses.add(
            responses.GET,
            "https://api.test.com/v1/analyses/ana_test123/report",
            json={"error": "upgrade_required"},
            status=403,
        )

        with pytest.raises(UpgradeRequiredError):
            client.report("ana_test123")

    @responses.activate
    def test_server_error(self, client):
        responses.add(
            responses.GET,
            "https://api.test.com/v1/analyses/ana_test123",
            json={"error": "Internal server error"},
            status=500,
        )

        with pytest.raises(APIError) as exc:
            client.status("ana_test123")

        assert exc.value.status_code == 500

    @responses.activate
    def test_usage_success(self, client):
        responses.add(
            responses.GET,
            "https://api.test.com/v1/user/usage",
            json={
                "tier": "pro",
                "tier_display": "Pro",
                "monthly_remaining": 847,
            },
            status=200,
        )

        result = client.usage()
        assert result["tier"] == "pro"

    @responses.activate
    def test_list_analyses_success(self, client):
        responses.add(
            responses.GET,
            "https://api.test.com/v1/user/analyses",
            json={"analyses": [{"id": "ana_test123", "status": "done"}]},
            status=200,
        )

        result = client.list_analyses()
        assert len(result["analyses"]) == 1

    @responses.activate
    def test_feature_not_available(self, client):
        responses.add(
            responses.GET,
            "https://api.test.com/v1/analyses/ana_test123/report",
            json={
                "error": "feature_not_available",
                "feature": "report",
                "message": "Reports require a Pro plan.",
            },
            status=403,
        )

        with pytest.raises(UpgradeRequiredError):
            client.report("ana_test123")

    def test_user_agent_contains_version(self, client):
        assert "clear-cli/" in client.session.headers["User-Agent"]
