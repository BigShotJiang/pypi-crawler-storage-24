"""Tests for display module."""

import io
import time
from unittest import mock

import pytest

from tryclear.display import (
    defang_url,
    deduplicate_urls,
    _brand_status_label,
    _defang_prose,
    _format_size,
    _has_findings,
    _build_why_section,
    _build_signals,
    _build_summary,
    format_eval_report,
    format_status,
    print_file_info,
    print_brand_line,
    print_welcome,
    should_show_brand,
    mark_brand_shown,
    get_console,
    wait_with_spinner,
    _SESSION_FILE,
    _SESSION_WINDOW,
)


class TestDefangUrl:
    """Test URL defanging."""

    def test_https_defanged(self):
        result = defang_url("https://example.com")
        assert "hxxps://" in result
        assert "[.]" in result

    def test_http_defanged(self):
        result = defang_url("http://evil.com/path")
        assert "hxxp://" in result
        assert "[.]" in result

    def test_domain_dots_replaced(self):
        result = defang_url("https://sub.domain.example.com/path")
        assert result == "hxxps://sub[.]domain[.]example[.]com/path"

    def test_path_dots_preserved(self):
        result = defang_url("https://example.com/file.png")
        assert result == "hxxps://example[.]com/file.png"

    def test_no_protocol(self):
        result = defang_url("just-text")
        assert result == "just-text"


class TestFormatSize:
    """Test file size formatting."""

    def test_bytes(self):
        assert _format_size(500) == "500 B"

    def test_kilobytes(self):
        assert _format_size(245000) == "239 KB"

    def test_megabytes(self):
        assert _format_size(5242880) == "5.0 MB"

    def test_none(self):
        assert _format_size(None) == "unknown"

    def test_string_input(self):
        assert _format_size("1024") == "1 KB"


class TestHasFindings:
    """Test findings detection."""

    def test_empty_data(self):
        assert _has_findings({}) is False

    def test_clean_image(self):
        data = {
            "indicators": {
                "extracted_neutral": [],
                "malicious_targets": [],
                "verified_official": [],
                "semantic_malicious": [],
            },
            "detection": {
                "ui_elements": [],
                "honey_words_matched": [],
                "qr_data": [],
                "brands_detected": [],
            },
        }
        assert _has_findings(data) is False

    def test_has_malicious_urls(self):
        data = {
            "indicators": {
                "semantic_malicious": ["https://evil.com"],
            },
            "detection": {},
        }
        assert _has_findings(data) is True

    def test_has_brands(self):
        data = {
            "indicators": {},
            "detection": {
                "brands_detected": [{"brand": "PayPal", "confidence": 0.95}],
            },
        }
        assert _has_findings(data) is True

    def test_has_honey_words(self):
        data = {
            "indicators": {},
            "detection": {
                "honey_words_matched": ["verify your account"],
            },
        }
        assert _has_findings(data) is True


class TestBuildWhySection:
    """Test 'Why it's X' — prefers reasoning_trace, falls back to final_pass."""

    def test_reasoning_trace_preferred(self):
        """reasoning_trace is used when available."""
        data = {
            "forensics": {"reasoning_trace": "QR code phishing: Coinbase login with QR to evil domain."},
            "verdict_narrative": {
                "final_pass": {"explanation": "QR code redirects away from the displayed brand."},
            },
        }
        result = _build_why_section(data)
        assert "QR code phishing" in result
        # Template from final_pass is NOT used when reasoning_trace exists
        assert "redirects away" not in result

    def test_fallback_to_final_pass(self):
        """When reasoning_trace is absent, falls back to final_pass.explanation."""
        data = {
            "forensics": {},
            "verdict_narrative": {
                "final_pass": {"explanation": "Fake login page."},
            },
        }
        result = _build_why_section(data)
        assert result == "Fake login page."

    def test_empty_data(self):
        assert _build_why_section({}) == ""

    def test_empty_reasoning_trace_falls_back(self):
        """Empty string reasoning_trace falls back to final_pass."""
        data = {
            "forensics": {"reasoning_trace": ""},
            "verdict_narrative": {
                "final_pass": {"explanation": "Template explanation."},
            },
        }
        result = _build_why_section(data)
        assert result == "Template explanation."

    def test_no_final_pass_returns_empty(self):
        """No reasoning_trace and no final_pass returns empty."""
        data = {
            "forensics": {},
            "verdict_narrative": {
                "second_pass": {"concern": "Some concern."},
            },
        }
        result = _build_why_section(data)
        assert result == ""


class TestBuildSignals:
    """Test signal bullet list construction."""

    def test_brands(self):
        data = {
            "detection": {
                "brands_detected": [{"brand": "PayPal", "confidence": 0.97}],
            },
        }
        signals = _build_signals(data)
        assert any("PayPal" in s and "0.97" in s for s in signals)

    def test_login_form(self):
        data = {
            "detection": {"ui_elements": ["login_form", "password_field"]},
        }
        signals = _build_signals(data)
        assert "Login form detected" in signals

    def test_qr_code(self):
        data = {
            "detection": {"qr_data": ["https://bit.ly/3xK9mQ"]},
        }
        signals = _build_signals(data)
        assert any("QR code" in s for s in signals)

    def test_honey_words(self):
        data = {
            "detection": {"honey_words_matched": ["verify your account"]},
        }
        signals = _build_signals(data)
        assert any("Honey words" in s for s in signals)

    def test_empty(self):
        assert _build_signals({"detection": {}}) == []


class TestBuildSummary:
    """Test summary paragraph construction."""

    def test_starts_with_evidence_not_hook(self):
        """Summary does NOT repeat plain_english — starts with brand evidence."""
        data = {
            "summary": {"verdict": "malicious"},
            "verdict_narrative": {"plain_english": "Fake PayPal login page."},
            "detection": {
                "brands_detected": [{"brand": "PayPal", "confidence": 0.97}],
            },
            "indicators": {},
            "forensics": {"threat_type": "TC-108", "mitre_tactics": ["T1566"]},
        }
        result = _build_summary(data)
        # plain_english NOT in summary (shown as hook at top)
        assert "Fake PayPal login page." not in result
        # Evidence IS in summary
        assert "PayPal branding" in result
        assert "0.97 confidence" in result
        assert "TC-108" in result
        assert "T1566" in result

    def test_includes_threat_urls(self):
        data = {
            "summary": {},
            "verdict_narrative": {"plain_english": "Phishing page."},
            "detection": {},
            "indicators": {
                "semantic_malicious": [{"url": "https://evil.com"}],
            },
            "forensics": {},
        }
        result = _build_summary(data)
        assert "evil" in result
        assert "SEMANTIC_MALICIOUS" in result

    def test_includes_cache_enrichment(self):
        data = {
            "summary": {"verdict": "malicious"},
            "verdict_narrative": {
                "plain_english": "Known threat.",
            },
            "cache_enrichment": {"seen_count": 4},
            "detection": {},
            "indicators": {},
            "forensics": {},
            "cache_hit": True,
        }
        result = _build_summary(data)
        assert "Matched prior eval" in result
        assert "seen 4 times" in result

    def test_cache_hit_without_enrichment(self):
        data = {
            "summary": {"verdict": "malicious"},
            "verdict_narrative": {"plain_english": "Known threat."},
            "detection": {},
            "indicators": {},
            "forensics": {},
            "cache_hit": True,
        }
        result = _build_summary(data)
        assert "Matched prior eval." in result
        assert "seen" not in result


class TestFormatEvalReport:
    """Test full report rendering."""

    def _capture_output(self, data):
        console = get_console(force_terminal=False)
        buf = io.StringIO()
        console.file = buf
        format_eval_report(console, data)
        return buf.getvalue()

    def test_clear_report_minimal(self):
        """Clear image: verdict + hook + link, no extra sections."""
        data = {
            "id": "ana_test123",
            "status": "done",
            "summary": {"verdict": "clear", "risk": "low"},
            "verdict_narrative": {
                "plain_english": "Standard photo. Nothing found."
            },
            "indicators": {},
            "detection": {},
            "forensics": {},
            "analysis_path": [],
        }
        output = self._capture_output(data)
        assert "CLEAR" in output
        assert "Standard photo" in output
        assert "Full report" in output
        assert "ana_test123" in output
        # No extra sections for clean images
        assert "Why it's" not in output
        assert "What we found" not in output
        assert "Summary" not in output

    def test_malicious_report_full(self):
        """Malicious image shows all sections."""
        data = {
            "id": "ana_evil456",
            "status": "done",
            "summary": {"verdict": "malicious", "risk": "high"},
            "verdict_narrative": {
                "first_pass": {"concern": "QR code and login form detected."},
                "second_pass": {"concern": "URL does not match PayPal."},
                "final_pass": {"explanation": "Fake login page collecting credentials."},
                "plain_english": "Fake PayPal login page.",
            },
            "indicators": {
                "semantic_malicious": ["https://paypa1-secure.com"],
                "verified_official": [],
                "malicious_targets": [],
                "extracted_neutral": [],
            },
            "detection": {
                "brands_detected": [{"brand": "PayPal", "confidence": 0.97}],
                "honey_words_matched": ["Verify your account"],
                "qr_data": [],
                "ui_elements": ["login_form", "password_field"],
            },
            "forensics": {
                "reasoning_trace": "PayPal credential harvesting via fake login page at paypa1-secure.com.",
                "threat_type": "TC-108 Credential Harvesting",
                "mitre_tactics": ["T1566"],
            },
            "analysis_path": [],
            "cache_hit": False,
        }
        output = self._capture_output(data)
        normalized = " ".join(output.split())
        # Verdict bar
        assert "MALICIOUS" in output
        # Hook
        assert "Fake PayPal" in output
        # Why section uses reasoning_trace
        assert "Why it's malicious" in output
        assert "credential harvesting" in normalized
        # What we found
        assert "What we found" in output
        assert "PayPal branding" in output
        assert "Login form" in output
        assert "Honey words" in output
        # URLs
        assert "paypa1-secure" in output
        assert "SEMANTIC_MALICIOUS" in output
        # MITRE
        assert "T1566" in output
        # Summary (no hook duplication, verdict-aware brand label)
        assert "Summary" in output
        assert "TC-108" in output
        assert "impersonated" in normalized
        # Link
        assert "Full report" in output

    def test_suspicious_report(self):
        data = {
            "id": "ana_sus789",
            "status": "done",
            "summary": {"verdict": "suspicious", "risk": "medium"},
            "verdict_narrative": {"plain_english": "Blurry screenshot with QR code."},
            "indicators": {
                "suspicious_pattern": [{"url": "https://bit.ly/3xK9mQ"}],
            },
            "detection": {
                "qr_data": ["https://bit.ly/3xK9mQ"],
                "brands_detected": [],
                "honey_words_matched": [],
                "ui_elements": [],
            },
            "forensics": {},
            "analysis_path": [],
        }
        output = self._capture_output(data)
        assert "SUSPICIOUS" in output
        assert "QR code" in output
        assert "Summary" in output

    def test_fallback_to_summary_reason(self):
        """When no verdict_narrative, falls back to summary.reason."""
        data = {
            "id": "ana_fb",
            "status": "done",
            "summary": {"verdict": "clear", "risk": "low", "reason": "Fallback text here"},
            "indicators": {},
            "detection": {},
            "forensics": {},
        }
        output = self._capture_output(data)
        assert "Fallback text here" in output

    def test_why_section_skipped_for_clear(self):
        """CLEAR verdicts never show 'Why it's clear'."""
        data = {
            "id": "ana_clear",
            "status": "done",
            "summary": {"verdict": "clear", "risk": "low"},
            "verdict_narrative": {
                "first_pass": {"concern": "Some concern."},
                "plain_english": "Clean image.",
            },
            "indicators": {},
            "detection": {},
            "forensics": {},
        }
        output = self._capture_output(data)
        assert "Why it's" not in output

    def test_cache_hit_in_summary(self):
        """Cache hit info appears in summary, not as standalone section."""
        data = {
            "id": "ana_cache1",
            "status": "done",
            "summary": {"verdict": "malicious", "risk": "high"},
            "verdict_narrative": {
                "plain_english": "Known phishing page.",
            },
            "cache_enrichment": {
                "source_analysis_id": "ana_original",
                "seen_count": 4,
            },
            "indicators": {},
            "detection": {
                "brands_detected": [{"brand": "PayPal", "confidence": 0.95}],
            },
            "forensics": {},
            "analysis_path": [],
            "cache_hit": True,
        }
        output = self._capture_output(data)
        normalized = " ".join(output.split())
        assert "Matched prior eval" in normalized
        assert "seen 4 times" in normalized
        assert "Summary" in output

    def test_expanded_url_classifications(self):
        """All 9 URL classification states render correctly."""
        data = {
            "id": "ana_urls",
            "status": "done",
            "summary": {"verdict": "suspicious", "risk": "medium"},
            "verdict_narrative": {"plain_english": "Multiple URL types found."},
            "indicators": {
                "context_mismatch": [{"url": "https://evil.com/login"}],
                "unverified_context": [{"url": "https://unknown-bank.com"}],
                "suspicious_pattern": [{"url": "https://paypa1.com"}],
            },
            "detection": {},
            "forensics": {},
            "analysis_path": [],
        }
        output = self._capture_output(data)
        assert "URLs" in output
        assert "CONTEXT_MISMATCH" in output
        assert "UNVERIFIED" in output
        assert "SUSPICIOUS" in output

    def test_clear_with_findings_shows_summary(self):
        """CLEAR with findings shows What we found + Summary with 'verified' label."""
        data = {
            "id": "ana_clear_findings",
            "status": "done",
            "summary": {"verdict": "clear", "risk": "low"},
            "verdict_narrative": {"plain_english": "Official Microsoft page."},
            "indicators": {
                "verified_official": [{"url": "https://microsoft.com"}],
            },
            "detection": {
                "brands_detected": [{"brand": "Microsoft", "confidence": 0.99}],
            },
            "forensics": {},
        }
        output = self._capture_output(data)
        assert "CLEAR" in output
        assert "What we found" in output
        assert "Microsoft branding" in output
        assert "Summary" in output
        assert "verified" in output  # CLEAR + verified_official = "verified"
        assert "Why it's" not in output

    def test_full_report_link(self):
        """Report link uses correct format."""
        data = {
            "id": "ana_link",
            "status": "done",
            "summary": {"verdict": "clear", "risk": "low"},
            "verdict_narrative": {"plain_english": "Clean."},
            "indicators": {},
            "detection": {},
            "forensics": {},
        }
        output = self._capture_output(data)
        assert "Full report" in output
        assert "tryclear.io/report/ana_link" in output


class TestFormatStatus:
    """Test brief status display."""

    def _capture_output(self, data):
        console = get_console(force_terminal=False)
        buf = io.StringIO()
        console.file = buf
        format_status(console, data)
        return buf.getvalue()

    def test_done_status(self):
        data = {
            "id": "ana_test123",
            "status": "done",
            "summary": {"verdict": "clear", "risk": "low", "reason": "Clean photo"},
        }
        output = self._capture_output(data)
        assert "done" in output
        assert "CLEAR" in output

    def test_running_status(self):
        data = {"id": "ana_test123", "status": "running"}
        output = self._capture_output(data)
        assert "running" in output

    def test_failed_status(self):
        data = {"id": "ana_test123", "status": "failed", "error": "Boom"}
        output = self._capture_output(data)
        assert "failed" in output
        assert "Boom" in output


class TestPrintFileInfo:
    """Test file info display."""

    def test_file_info_all_parts(self):
        console = get_console(force_terminal=False)
        buf = io.StringIO()
        console.file = buf
        print_file_info(console, "test.png", 245000, "image/png")
        output = buf.getvalue()
        assert "test.png" in output
        assert "KB" in output
        assert "image/png" in output

    def test_file_info_name_only(self):
        console = get_console(force_terminal=False)
        buf = io.StringIO()
        console.file = buf
        print_file_info(console, "test.png")
        output = buf.getvalue()
        assert "test.png" in output


# ---------------------------------------------------------------------------
# Fix 1: Cache hit timing line
# ---------------------------------------------------------------------------

class TestCacheHitTimingLine:
    """Cache hits should say 'Matched prior eval in <1s', not 'Evaluated in Xs'."""

    def test_cache_hit_shows_matched_prior_eval(self):
        """When cache_hit=true, timing line says 'Matched prior eval in <1s'."""
        console = get_console(force_terminal=False)
        buf = io.StringIO()
        console.file = buf

        mock_client = mock.MagicMock()
        mock_client.status.return_value = {
            "status": "done",
            "cache_hit": True,
            "summary": {"verdict": "malicious", "risk": "high"},
        }
        result = wait_with_spinner(mock_client, "ana_test", console, max_wait=10)
        output = buf.getvalue()
        assert "Matched prior eval in <1s" in output
        assert "Evaluated in" not in output
        assert result["cache_hit"] is True

    def test_non_cache_hit_shows_evaluated_in(self):
        """Normal evals show 'Evaluated in Xs'."""
        console = get_console(force_terminal=False)
        buf = io.StringIO()
        console.file = buf

        mock_client = mock.MagicMock()
        mock_client.status.return_value = {
            "status": "done",
            "cache_hit": False,
            "summary": {"verdict": "clear", "risk": "low"},
        }
        result = wait_with_spinner(mock_client, "ana_test", console, max_wait=10)
        output = buf.getvalue()
        assert "Evaluated in" in output
        assert "Matched prior eval" not in output

    def test_no_cache_hit_field_shows_evaluated_in(self):
        """When cache_hit is absent, default to 'Evaluated in Xs'."""
        console = get_console(force_terminal=False)
        buf = io.StringIO()
        console.file = buf

        mock_client = mock.MagicMock()
        mock_client.status.return_value = {
            "status": "done",
            "summary": {"verdict": "clear", "risk": "low"},
        }
        result = wait_with_spinner(mock_client, "ana_test", console, max_wait=10)
        output = buf.getvalue()
        assert "Evaluated in" in output
        assert "Matched prior eval" not in output


# ---------------------------------------------------------------------------
# Fix 2: "Why it's X" field mapping
# ---------------------------------------------------------------------------

class TestWhySectionReasoningTrace:
    """'Why it's X' should prefer reasoning_trace, fall back to final_pass."""

    def test_reasoning_trace_over_templates(self):
        """reasoning_trace is preferred over both second_pass and final_pass."""
        data = {
            "forensics": {
                "reasoning_trace": "Coinbase login page with QR pointing to evil.coib8ce.net.",
            },
            "verdict_narrative": {
                "second_pass": {"concern": "URL behavioral analysis detected malicious intent."},
                "final_pass": {"explanation": "QR code redirects away from the displayed brand."},
            },
        }
        result = _build_why_section(data)
        assert "Coinbase login page" in result
        assert "evil" in result
        # Templates NOT used
        assert "behavioral analysis" not in result
        assert "redirects away" not in result

    def test_reasoning_trace_urls_defanged(self):
        """URLs in reasoning_trace are defanged for safe display."""
        data = {
            "forensics": {
                "reasoning_trace": "QR points to https://evil.coib8ce.net/myaccount.",
            },
            "verdict_narrative": {},
        }
        result = _build_why_section(data)
        assert "hxxps://" in result
        assert "[.]" in result
        assert "https://" not in result

    def test_fallback_final_pass_when_no_trace(self):
        """Falls back to final_pass.explanation when reasoning_trace absent."""
        data = {
            "forensics": {},
            "verdict_narrative": {
                "final_pass": {"explanation": "Fake login page for credential harvesting."},
            },
        }
        result = _build_why_section(data)
        assert result == "Fake login page for credential harvesting."

    def test_empty_trace_falls_back(self):
        """Empty reasoning_trace string falls back to final_pass."""
        data = {
            "forensics": {"reasoning_trace": ""},
            "verdict_narrative": {
                "final_pass": {"explanation": "Template explanation."},
            },
        }
        result = _build_why_section(data)
        assert result == "Template explanation."

    def test_in_full_report_reasoning_trace_used(self):
        """Integration: rendered report uses reasoning_trace, not templates."""
        console = get_console(force_terminal=False)
        buf = io.StringIO()
        console.file = buf
        data = {
            "id": "ana_fix1",
            "status": "done",
            "summary": {"verdict": "malicious", "risk": "high"},
            "verdict_narrative": {
                "second_pass": {"concern": "URL behavioral analysis detected malicious intent."},
                "final_pass": {"explanation": "QR code redirects away from the displayed brand."},
                "plain_english": "Fake Coinbase login page.",
            },
            "indicators": {},
            "detection": {},
            "forensics": {
                "reasoning_trace": "QR code phishing: Coinbase page with QR to https://evil.coib8ce.net/myaccount.",
            },
        }
        format_eval_report(console, data)
        output = buf.getvalue()
        normalized = " ".join(output.split())
        # reasoning_trace is used (with defanged URL)
        assert "QR code phishing" in normalized
        assert "hxxps://" in output
        # Templates NOT shown
        assert "behavioral analysis" not in output
        assert "redirects away" not in output


# ---------------------------------------------------------------------------
# Fix 3: URL dedup in signal table
# ---------------------------------------------------------------------------

class TestDeduplicateUrls:
    """Test URL deduplication helper."""

    def test_same_url_two_classifications_keeps_worst(self):
        """Same URL as SEMANTIC_MALICIOUS and MALICIOUS_TARGET → MALICIOUS_TARGET wins."""
        indicators = {
            "semantic_malicious": [{"url": "https://evil.com/phish"}],
            "malicious_targets": [{"url": "https://evil.com/phish"}],
        }
        result = deduplicate_urls(indicators)
        urls = [url for url, _ in result]
        assert urls.count("https://evil.com/phish") == 1
        # MALICIOUS_TARGET has higher severity
        assert result[0] == ("https://evil.com/phish", "malicious_targets")

    def test_different_urls_preserved(self):
        """Different URLs are all preserved."""
        indicators = {
            "semantic_malicious": [{"url": "https://evil.com"}],
            "suspicious_pattern": [{"url": "https://sus.com"}],
        }
        result = deduplicate_urls(indicators)
        urls = [url for url, _ in result]
        assert "https://evil.com" in urls
        assert "https://sus.com" in urls
        assert len(result) == 2

    def test_severity_order(self):
        """Results are ordered by severity, most severe first."""
        indicators = {
            "extracted_neutral": [{"url": "https://safe.com"}],
            "malicious_targets": [{"url": "https://evil.com"}],
            "suspicious_pattern": [{"url": "https://sus.com"}],
        }
        result = deduplicate_urls(indicators)
        keys = [key for _, key in result]
        assert keys.index("malicious_targets") < keys.index("suspicious_pattern")
        assert keys.index("suspicious_pattern") < keys.index("extracted_neutral")

    def test_empty_indicators(self):
        """Empty indicators returns empty list."""
        assert deduplicate_urls({}) == []

    def test_string_urls_handled(self):
        """String URLs (not dict) are handled."""
        indicators = {
            "semantic_malicious": ["https://evil.com"],
            "malicious_targets": ["https://evil.com"],
        }
        result = deduplicate_urls(indicators)
        assert len(result) == 1
        assert result[0][1] == "malicious_targets"

    def test_render_urls_section_deduplicates(self):
        """Integration: rendered URLs section shows each URL once."""
        console = get_console(force_terminal=False)
        buf = io.StringIO()
        console.file = buf
        data = {
            "id": "ana_dedup",
            "status": "done",
            "summary": {"verdict": "malicious", "risk": "high"},
            "verdict_narrative": {"plain_english": "Phishing."},
            "indicators": {
                "semantic_malicious": [{"url": "https://evil.coib8ce.net/myaccount"}],
                "malicious_targets": [{"url": "https://evil.coib8ce.net/myaccount"}],
            },
            "detection": {},
            "forensics": {},
        }
        format_eval_report(console, data)
        output = buf.getvalue()
        # URL should appear exactly once in the URLs section
        url_fragment = "evil[.]coib8ce[.]net/myaccount"
        assert output.count(url_fragment) == 2  # once in URLs, once in Summary


# ---------------------------------------------------------------------------
# Fix 4: URL dedup in summary paragraph
# ---------------------------------------------------------------------------

class TestSummaryUrlDedup:
    """Summary paragraph should not duplicate URLs."""

    def test_duplicate_url_appears_once_in_summary(self):
        """Same URL in two classification buckets → one mention in summary."""
        data = {
            "summary": {"verdict": "malicious"},
            "verdict_narrative": {"plain_english": "Phishing page."},
            "detection": {},
            "indicators": {
                "semantic_malicious": [{"url": "https://evil.com/phish"}],
                "malicious_targets": [{"url": "https://evil.com/phish"}],
            },
            "forensics": {},
        }
        result = _build_summary(data)
        # The URL should appear exactly once (with the worst classification)
        assert result.count("evil[.]com/phish") == 1
        assert "MALICIOUS_TARGET" in result

    def test_different_urls_both_in_summary(self):
        """Different URLs each appear once."""
        data = {
            "summary": {"verdict": "malicious"},
            "verdict_narrative": {"plain_english": "Multiple threats."},
            "detection": {},
            "indicators": {
                "semantic_malicious": [{"url": "https://evil.com"}],
                "suspicious_pattern": [{"url": "https://sus.com"}],
            },
            "forensics": {},
        }
        result = _build_summary(data)
        assert "evil[.]com" in result
        assert "sus[.]com" in result

    def test_neutral_urls_excluded_from_summary(self):
        """Neutral/verified URLs don't appear in summary threat section."""
        data = {
            "summary": {"verdict": "clear"},
            "verdict_narrative": {"plain_english": "Clean page."},
            "detection": {},
            "indicators": {
                "verified_official": [{"url": "https://google.com"}],
                "extracted_neutral": [{"url": "https://cdn.example.com"}],
            },
            "forensics": {},
        }
        result = _build_summary(data)
        assert "classified" not in result


# ---------------------------------------------------------------------------
# Session 50 Fix 1: reasoning_trace in "Why it's X"
# ---------------------------------------------------------------------------

class TestDefangProse:
    """Test URL defanging in prose text."""

    def test_defangs_https_urls(self):
        text = "QR points to https://evil.coib8ce.net/myaccount."
        result = _defang_prose(text)
        assert "hxxps://evil[.]coib8ce[.]net/myaccount" in result
        assert "https://" not in result

    def test_defangs_http_urls(self):
        text = "Redirects to http://phish.example.com/login page."
        result = _defang_prose(text)
        assert "hxxp://phish[.]example[.]com/login" in result

    def test_multiple_urls(self):
        text = "Found https://evil.com and https://bad.org in image."
        result = _defang_prose(text)
        assert "hxxps://evil[.]com" in result
        assert "hxxps://bad[.]org" in result

    def test_no_urls_unchanged(self):
        text = "Clean photo. No threats."
        assert _defang_prose(text) == text

    def test_url_in_parens(self):
        text = "QR code (https://evil.com/path)."
        result = _defang_prose(text)
        assert "hxxps://evil[.]com/path" in result


# ---------------------------------------------------------------------------
# Session 50 Fix 2: Summary starts with evidence, not hook
# ---------------------------------------------------------------------------

class TestSummaryNoHookDuplication:
    """Summary should NOT contain plain_english (it's the hook at the top)."""

    def test_plain_english_not_in_summary(self):
        """The hook sentence is not repeated in the summary."""
        data = {
            "summary": {"verdict": "malicious"},
            "verdict_narrative": {
                "plain_english": "Fake PayPal page targeting credentials.",
            },
            "detection": {
                "brands_detected": [{"brand": "PayPal", "confidence": 0.97}],
            },
            "indicators": {
                "semantic_malicious": [{"url": "https://evil.com"}],
            },
            "forensics": {"threat_type": "TC-108"},
        }
        result = _build_summary(data)
        assert "Fake PayPal page targeting credentials." not in result
        # Evidence IS present
        assert "PayPal branding" in result
        assert "evil" in result
        assert "TC-108" in result

    def test_summary_starts_with_brand(self):
        """When brands exist, summary starts with brand evidence."""
        data = {
            "summary": {"verdict": "malicious"},
            "verdict_narrative": {"plain_english": "Coinbase impersonation."},
            "detection": {
                "brands_detected": [{"brand": "Coinbase", "confidence": 0.99}],
            },
            "indicators": {},
            "forensics": {},
        }
        result = _build_summary(data)
        assert result.startswith("Coinbase branding")

    def test_empty_summary_when_no_evidence(self):
        """Summary with no brands, no URLs, no technique returns empty."""
        data = {
            "summary": {"verdict": "suspicious"},
            "verdict_narrative": {"plain_english": "Something suspicious."},
            "detection": {},
            "indicators": {},
            "forensics": {},
        }
        result = _build_summary(data)
        assert result == ""


# ---------------------------------------------------------------------------
# Session 50 Fix 3: Verdict-aware brand label
# ---------------------------------------------------------------------------

class TestBrandStatusLabel:
    """Brand label changes based on verdict."""

    def test_malicious_shows_impersonated(self):
        assert _brand_status_label("malicious", True) == "impersonated"
        assert _brand_status_label("malicious", False) == "impersonated"

    def test_blocked_shows_impersonated(self):
        assert _brand_status_label("blocked", True) == "impersonated"

    def test_suspicious_shows_unconfirmed(self):
        assert _brand_status_label("suspicious", True) == "unconfirmed"
        assert _brand_status_label("suspicious", False) == "unconfirmed"

    def test_clear_verified_shows_verified(self):
        assert _brand_status_label("clear", True) == "verified"

    def test_clear_unverified_shows_unverified(self):
        assert _brand_status_label("clear", False) == "unverified"

    def test_benign_verified_shows_verified(self):
        assert _brand_status_label("benign", True) == "verified"

    def test_in_summary_malicious_impersonated(self):
        """Integration: malicious verdict produces 'impersonated' in summary."""
        data = {
            "summary": {"verdict": "malicious"},
            "verdict_narrative": {},
            "detection": {
                "brands_detected": [{"brand": "Coinbase", "confidence": 0.99}],
            },
            "indicators": {
                "verified_official": [{"url": "https://coinbase.com"}],
            },
            "forensics": {},
        }
        result = _build_summary(data)
        assert "impersonated" in result
        assert "verified)" not in result

    def test_in_summary_clear_verified(self):
        """Integration: clear verdict + verified_official produces 'verified'."""
        data = {
            "summary": {"verdict": "clear"},
            "verdict_narrative": {},
            "detection": {
                "brands_detected": [{"brand": "Google", "confidence": 0.98}],
            },
            "indicators": {
                "verified_official": [{"url": "https://google.com"}],
            },
            "forensics": {},
        }
        result = _build_summary(data)
        assert "verified)" in result
        assert "impersonated" not in result

    def test_in_summary_suspicious_unconfirmed(self):
        """Integration: suspicious verdict produces 'unconfirmed'."""
        data = {
            "summary": {"verdict": "suspicious"},
            "verdict_narrative": {},
            "detection": {
                "brands_detected": [{"brand": "PayPal", "confidence": 0.90}],
            },
            "indicators": {},
            "forensics": {},
        }
        result = _build_summary(data)
        assert "unconfirmed" in result


# ---------------------------------------------------------------------------
# Polish 1: Brand line + session marker
# ---------------------------------------------------------------------------

class TestBrandLine:
    """Brand line rendering with tier and quota info."""

    def test_full_brand_line(self):
        """Brand line shows version, tier, and remaining evals."""
        console = get_console(force_terminal=False)
        buf = io.StringIO()
        console.file = buf
        print_brand_line(console, tier="pro", remaining=847)
        output = buf.getvalue()
        normalized = " ".join(output.split())
        assert "TryClear" in output
        assert "v2.0.0" in output
        assert "Pro" in output
        assert "847 evals remaining" in normalized

    def test_brand_line_version_only(self):
        """Brand line shows just version when tier/quota unavailable."""
        console = get_console(force_terminal=False)
        buf = io.StringIO()
        console.file = buf
        print_brand_line(console)
        output = buf.getvalue()
        assert "TryClear" in output
        assert "v2.0.0" in output
        assert "evals remaining" not in output

    def test_brand_line_no_remaining(self):
        """Brand line with tier but no remaining (unlimited plan)."""
        console = get_console(force_terminal=False)
        buf = io.StringIO()
        console.file = buf
        print_brand_line(console, tier="enterprise", remaining=None)
        output = buf.getvalue()
        assert "Enterprise" in output
        assert "evals remaining" not in output

    def test_brand_line_zero_remaining(self):
        """Brand line shows 0 evals remaining."""
        console = get_console(force_terminal=False)
        buf = io.StringIO()
        console.file = buf
        print_brand_line(console, tier="free", remaining=0)
        output = buf.getvalue()
        normalized = " ".join(output.split())
        assert "0 evals remaining" in normalized


class TestSessionMarker:
    """Session marker controls brand line visibility."""

    def test_first_call_shows_brand(self):
        """First eval in session should show brand line."""
        # Remove session file to simulate fresh session
        import os
        try:
            os.unlink(_SESSION_FILE)
        except FileNotFoundError:
            pass
        assert should_show_brand() is True

    def test_second_call_hides_brand(self):
        """Second eval within session window should NOT show brand."""
        mark_brand_shown()
        assert should_show_brand() is False

    def test_expired_session_shows_brand(self):
        """Brand shows again after session window expires."""
        import os
        # Write session file with old timestamp
        with open(_SESSION_FILE, "w") as f:
            f.write("")
        # Set mtime to beyond session window
        old_time = time.time() - _SESSION_WINDOW - 60
        os.utime(_SESSION_FILE, (old_time, old_time))
        assert should_show_brand() is True

    def test_mark_brand_creates_file(self):
        """mark_brand_shown() creates session marker file."""
        import os
        try:
            os.unlink(_SESSION_FILE)
        except FileNotFoundError:
            pass
        mark_brand_shown()
        assert os.path.exists(_SESSION_FILE)


# ---------------------------------------------------------------------------
# Polish 3: First-run welcome message
# ---------------------------------------------------------------------------

class TestWelcomeMessage:
    """Welcome message for unconfigured users."""

    def test_welcome_shows_auth_command(self):
        """Welcome message includes 'clear auth' command."""
        console = get_console(force_terminal=False)
        buf = io.StringIO()
        console.file = buf
        print_welcome(console)
        output = buf.getvalue()
        assert "clear auth" in output

    def test_welcome_shows_signup_url(self):
        """Welcome message includes signup URL."""
        console = get_console(force_terminal=False)
        buf = io.StringIO()
        console.file = buf
        print_welcome(console)
        output = buf.getvalue()
        assert "tryclear.io/settings" in output

    def test_welcome_shows_tryclear_name(self):
        """Welcome message includes product name."""
        console = get_console(force_terminal=False)
        buf = io.StringIO()
        console.file = buf
        print_welcome(console)
        output = buf.getvalue()
        assert "Welcome to TryClear" in output


# ---------------------------------------------------------------------------
# Polish 5: Help output cleanup
# ---------------------------------------------------------------------------

class TestHelpOutput:
    """Help output should be clean — no ==SUPPRESS== leak."""

    def test_help_no_suppress_leak(self):
        """==SUPPRESS== should not appear in help output."""
        from tryclear.cli import create_parser
        parser = create_parser()
        buf = io.StringIO()
        parser.print_help(buf)
        output = buf.getvalue()
        assert "SUPPRESS" not in output
        assert "configure" not in output
        assert "scan" not in output

    def test_help_shows_real_commands(self):
        """Help output shows auth, eval, status, report."""
        from tryclear.cli import create_parser
        parser = create_parser()
        buf = io.StringIO()
        parser.print_help(buf)
        output = buf.getvalue()
        assert "auth" in output
        assert "eval" in output
        assert "status" in output
        assert "report" in output

    def test_legacy_scan_still_works(self):
        """Legacy 'scan' command is rewritten to 'eval'."""
        from tryclear.cli import main
        # scan without a file should fail with the same error as eval without a file
        # (argparse error about missing 'file' arg)
        import pytest
        with pytest.raises(SystemExit):
            main(["scan"])

    def test_legacy_configure_still_works(self):
        """Legacy 'configure' command is rewritten to 'auth'."""
        from tryclear.cli import main
        # configure with invalid key should work (it goes through auth flow)
        # Just verify it doesn't crash with "unknown command"
        with mock.patch("tryclear.commands.auth.run", return_value=0) as mock_auth:
            result = main(["configure", "--api-key", "sk_test_abc"])
            assert result == 0
            mock_auth.assert_called_once()
