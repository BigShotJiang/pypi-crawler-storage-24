"""Tests for CLI entry point and commands."""

import json
import tempfile
from pathlib import Path
from unittest import mock

import pytest

from tryclear import cli
from tryclear.client import AuthError, NotFoundError, UpgradeRequiredError, QuotaExceededError


class TestArgParser:
    """Test argument parsing."""

    def test_version(self, capsys):
        with pytest.raises(SystemExit) as exc:
            cli.main(["--version"])
        assert exc.value.code == 0

    def test_help(self, capsys):
        with pytest.raises(SystemExit) as exc:
            cli.main(["--help"])
        assert exc.value.code == 0

    def test_no_command(self, capsys):
        result = cli.main([])
        assert result == 0

    def test_eval_requires_file(self, capsys):
        with pytest.raises(SystemExit):
            cli.main(["eval"])

    def test_status_requires_id(self, capsys):
        with pytest.raises(SystemExit):
            cli.main(["status"])


class TestLegacyAliases:
    """Test that legacy command names still work."""

    def test_configure_alias(self):
        with mock.patch("tryclear.commands.auth.getpass.getpass", return_value="sk_live_test123"):
            with mock.patch("tryclear.commands.auth.save_config", return_value=Path("/test/config.json")):
                with mock.patch("tryclear.commands.auth.TryClearClient") as mock_client_cls:
                    mock_client = mock.MagicMock()
                    mock_client.usage.return_value = {"tier": "free", "tier_display": "Free", "monthly_remaining": 50}
                    mock_client_cls.return_value = mock_client
                    result = cli.main(["configure"])
                    assert result == 0

    def test_scan_alias(self):
        with tempfile.NamedTemporaryFile(delete=False, suffix=".png") as f:
            f.write(b"test")
            f.flush()

            with mock.patch("tryclear.commands.eval.get_api_key", return_value="sk_live_test"):
                with mock.patch("tryclear.commands.eval.get_api_url", return_value="https://api.test.com"):
                    mock_client = mock.MagicMock()
                    mock_client.submit.return_value = {"id": "ana_test123", "status": "queued"}

                    with mock.patch("tryclear.commands.eval.TryClearClient", return_value=mock_client):
                        result = cli.main(["scan", f.name, "--async"])
                        assert result == 0


class TestAuthCommand:
    """Test auth command."""

    def test_auth_success_with_usage(self):
        with mock.patch("tryclear.commands.auth.getpass.getpass", return_value="sk_live_test123"):
            with mock.patch("tryclear.commands.auth.save_config", return_value=Path("/test/config.json")):
                with mock.patch("tryclear.commands.auth.TryClearClient") as mock_client_cls:
                    mock_client = mock.MagicMock()
                    mock_client.usage.return_value = {
                        "tier": "pro",
                        "tier_display": "Pro",
                        "monthly_remaining": 847,
                    }
                    mock_client_cls.return_value = mock_client
                    result = cli.main(["auth"])
                    assert result == 0

    def test_auth_success_fallback_to_list(self):
        """When usage endpoint fails, falls back to list_analyses."""
        with mock.patch("tryclear.commands.auth.getpass.getpass", return_value="sk_live_test123"):
            with mock.patch("tryclear.commands.auth.save_config", return_value=Path("/test/config.json")):
                with mock.patch("tryclear.commands.auth.TryClearClient") as mock_client_cls:
                    mock_client = mock.MagicMock()
                    mock_client.usage.side_effect = AuthError("JWT required")
                    mock_client.list_analyses.return_value = {"analyses": []}
                    mock_client_cls.return_value = mock_client
                    result = cli.main(["auth"])
                    assert result == 0

    def test_auth_invalid_key_format(self):
        with mock.patch("tryclear.commands.auth.getpass.getpass", return_value="invalid_key"):
            result = cli.main(["auth"])
            assert result == 3

    def test_auth_api_key_flag(self):
        with mock.patch("tryclear.commands.auth.save_config", return_value=Path("/test/config.json")):
            with mock.patch("tryclear.commands.auth.TryClearClient") as mock_client_cls:
                mock_client = mock.MagicMock()
                mock_client.usage.return_value = {"tier": "free", "tier_display": "Free", "monthly_remaining": 50}
                mock_client_cls.return_value = mock_client
                result = cli.main(["auth", "--api-key", "sk_live_test123"])
                assert result == 0

    def test_auth_rejected_by_api(self):
        """API rejects the key — should NOT save."""
        with mock.patch("tryclear.commands.auth.getpass.getpass", return_value="sk_live_bad_key"):
            with mock.patch("tryclear.commands.auth.TryClearClient") as mock_client_cls:
                mock_client = mock.MagicMock()
                mock_client.usage.side_effect = AuthError("Invalid key")
                mock_client.list_analyses.side_effect = AuthError("Invalid key")
                mock_client_cls.return_value = mock_client

                with mock.patch("tryclear.commands.auth.save_config") as mock_save:
                    result = cli.main(["auth"])
                    assert result == 3
                    mock_save.assert_not_called()


class TestEvalCommand:
    """Test eval command."""

    def test_eval_file_not_found(self):
        result = cli.main(["eval", "/nonexistent/file.png"])
        assert result == 3

    def test_eval_not_configured(self):
        with tempfile.NamedTemporaryFile(delete=False, suffix=".png") as f:
            f.write(b"test")
            f.flush()

            with mock.patch("tryclear.commands.eval.get_api_key", return_value=None):
                result = cli.main(["eval", f.name])
                assert result == 3

    def test_eval_async_success(self):
        with tempfile.NamedTemporaryFile(delete=False, suffix=".png") as f:
            f.write(b"test")
            f.flush()

            with mock.patch("tryclear.commands.eval.get_api_key", return_value="sk_live_test"):
                with mock.patch("tryclear.commands.eval.get_api_url", return_value="https://api.test.com"):
                    mock_client = mock.MagicMock()
                    mock_client.submit.return_value = {"id": "ana_test123", "status": "queued"}

                    with mock.patch("tryclear.commands.eval.TryClearClient", return_value=mock_client):
                        result = cli.main(["eval", f.name, "--async"])
                        assert result == 0

    def test_eval_sync_clear(self):
        with tempfile.NamedTemporaryFile(delete=False, suffix=".png") as f:
            f.write(b"test")
            f.flush()

            with mock.patch("tryclear.commands.eval.get_api_key", return_value="sk_live_test"):
                with mock.patch("tryclear.commands.eval.get_api_url", return_value="https://api.test.com"):
                    mock_client = mock.MagicMock()
                    mock_client.submit.return_value = {"id": "ana_test123", "status": "queued"}

                    with mock.patch("tryclear.commands.eval.TryClearClient", return_value=mock_client):
                        with mock.patch("tryclear.commands.eval.wait_with_spinner") as mock_wait:
                            mock_wait.return_value = {
                                "status": "done",
                                "summary": {"verdict": "clear", "risk": "low"},
                            }
                            result = cli.main(["eval", f.name])
                            assert result == 0

    def test_eval_sync_malicious(self):
        with tempfile.NamedTemporaryFile(delete=False, suffix=".png") as f:
            f.write(b"test")
            f.flush()

            with mock.patch("tryclear.commands.eval.get_api_key", return_value="sk_live_test"):
                with mock.patch("tryclear.commands.eval.get_api_url", return_value="https://api.test.com"):
                    mock_client = mock.MagicMock()
                    mock_client.submit.return_value = {"id": "ana_test123", "status": "queued"}

                    with mock.patch("tryclear.commands.eval.TryClearClient", return_value=mock_client):
                        with mock.patch("tryclear.commands.eval.wait_with_spinner") as mock_wait:
                            mock_wait.return_value = {
                                "status": "done",
                                "summary": {"verdict": "malicious", "risk": "high"},
                            }
                            result = cli.main(["eval", f.name])
                            assert result == 2

    def test_eval_json_output(self, capsys):
        from tryclear.commands import eval as eval_cmd
        from tryclear.display import get_console

        with tempfile.NamedTemporaryFile(delete=False, suffix=".png") as f:
            f.write(b"test")
            f.flush()

            with mock.patch.object(eval_cmd, "get_api_key", return_value="sk_live_test"):
                with mock.patch.object(eval_cmd, "get_api_url", return_value="https://api.test.com"):
                    mock_client = mock.MagicMock()
                    mock_client.submit.return_value = {"id": "ana_test123", "status": "queued"}

                    with mock.patch.object(eval_cmd, "TryClearClient", return_value=mock_client):
                        console = get_console(force_terminal=False)
                        result = eval_cmd.run(
                            console,
                            file_path=f.name,
                            async_mode=True,
                            json_output=True,
                            quiet=False,
                        )

                        assert result == 0
                        captured = capsys.readouterr()
                        output = json.loads(captured.out)
                        assert output["id"] == "ana_test123"

    def test_eval_quota_exceeded(self):
        with tempfile.NamedTemporaryFile(delete=False, suffix=".png") as f:
            f.write(b"test")
            f.flush()

            with mock.patch("tryclear.commands.eval.get_api_key", return_value="sk_live_test"):
                with mock.patch("tryclear.commands.eval.get_api_url", return_value="https://api.test.com"):
                    mock_client = mock.MagicMock()
                    mock_client.submit.side_effect = QuotaExceededError(
                        "You've used all 50 evaluations",
                        quota={"tier": "free", "monthly_used": 50, "monthly_limit": 50},
                    )

                    with mock.patch("tryclear.commands.eval.TryClearClient", return_value=mock_client):
                        result = cli.main(["eval", f.name])
                        assert result == 3

    def test_eval_timeout_flag(self):
        """Test custom timeout flag is passed through."""
        with tempfile.NamedTemporaryFile(delete=False, suffix=".png") as f:
            f.write(b"test")
            f.flush()

            with mock.patch("tryclear.commands.eval.get_api_key", return_value="sk_live_test"):
                with mock.patch("tryclear.commands.eval.get_api_url", return_value="https://api.test.com"):
                    mock_client = mock.MagicMock()
                    mock_client.submit.return_value = {"id": "ana_test123", "status": "queued"}

                    with mock.patch("tryclear.commands.eval.TryClearClient", return_value=mock_client):
                        with mock.patch("tryclear.commands.eval.wait_with_spinner") as mock_wait:
                            mock_wait.return_value = {
                                "status": "done",
                                "summary": {"verdict": "clear", "risk": "low"},
                            }
                            result = cli.main(["eval", f.name, "--timeout", "60"])
                            assert result == 0
                            _, kwargs = mock_wait.call_args
                            assert kwargs["max_wait"] == 60.0


class TestStatusCommand:
    """Test status command."""

    def test_status_not_configured(self):
        with mock.patch("tryclear.commands.status.get_api_key", return_value=None):
            result = cli.main(["status", "ana_test123"])
            assert result == 3

    def test_status_done(self):
        with mock.patch("tryclear.commands.status.get_api_key", return_value="sk_live_test"):
            with mock.patch("tryclear.commands.status.get_api_url", return_value="https://api.test.com"):
                mock_client = mock.MagicMock()
                mock_client.status.return_value = {
                    "id": "ana_test123",
                    "status": "done",
                    "summary": {"verdict": "suspicious", "risk": "medium"},
                }

                with mock.patch("tryclear.commands.status.TryClearClient", return_value=mock_client):
                    result = cli.main(["status", "ana_test123"])
                    assert result == 1

    def test_status_running(self):
        with mock.patch("tryclear.commands.status.get_api_key", return_value="sk_live_test"):
            with mock.patch("tryclear.commands.status.get_api_url", return_value="https://api.test.com"):
                mock_client = mock.MagicMock()
                mock_client.status.return_value = {
                    "id": "ana_test123",
                    "status": "running",
                }

                with mock.patch("tryclear.commands.status.TryClearClient", return_value=mock_client):
                    result = cli.main(["status", "ana_test123"])
                    assert result == 0

    def test_status_not_found(self):
        with mock.patch("tryclear.commands.status.get_api_key", return_value="sk_live_test"):
            with mock.patch("tryclear.commands.status.get_api_url", return_value="https://api.test.com"):
                mock_client = mock.MagicMock()
                mock_client.status.side_effect = NotFoundError("Not found")

                with mock.patch("tryclear.commands.status.TryClearClient", return_value=mock_client):
                    result = cli.main(["status", "ana_invalid"])
                    assert result == 3


class TestReportCommand:
    """Test report command."""

    def test_report_not_configured(self):
        with mock.patch("tryclear.commands.report.get_api_key", return_value=None):
            result = cli.main(["report", "ana_test123"])
            assert result == 3

    def test_report_success(self):
        """Report now uses status endpoint for full data."""
        with mock.patch("tryclear.commands.report.get_api_key", return_value="sk_live_test"):
            with mock.patch("tryclear.commands.report.get_api_url", return_value="https://api.test.com"):
                mock_client = mock.MagicMock()
                mock_client.status.return_value = {
                    "id": "ana_test123",
                    "status": "done",
                    "summary": {"verdict": "malicious", "risk": "high"},
                    "indicators": {},
                    "detection": {},
                    "forensics": {},
                }

                with mock.patch("tryclear.commands.report.TryClearClient", return_value=mock_client):
                    result = cli.main(["report", "ana_test123"])
                    assert result == 2

    def test_report_not_found(self):
        with mock.patch("tryclear.commands.report.get_api_key", return_value="sk_live_test"):
            with mock.patch("tryclear.commands.report.get_api_url", return_value="https://api.test.com"):
                mock_client = mock.MagicMock()
                mock_client.status.side_effect = NotFoundError("Not found")

                with mock.patch("tryclear.commands.report.TryClearClient", return_value=mock_client):
                    result = cli.main(["report", "ana_test123"])
                    assert result == 3

    def test_report_json_output(self, capsys):
        from tryclear.commands import report as report_cmd
        from tryclear.display import get_console

        with mock.patch.object(report_cmd, "get_api_key", return_value="sk_live_test"):
            with mock.patch.object(report_cmd, "get_api_url", return_value="https://api.test.com"):
                mock_client = mock.MagicMock()
                mock_client.status.return_value = {
                    "id": "ana_test123",
                    "status": "done",
                    "summary": {"verdict": "clear", "risk": "low"},
                }

                with mock.patch.object(report_cmd, "TryClearClient", return_value=mock_client):
                    console = get_console(force_terminal=False)
                    result = report_cmd.run(
                        console,
                        analysis_id="ana_test123",
                        json_output=True,
                        quiet=False,
                    )

                    assert result == 0
                    captured = capsys.readouterr()
                    output = json.loads(captured.out)
                    assert output["verdict"] == "CLEAR"
                    assert output["report_url"] == "https://tryclear.io/report/ana_test123"

    def test_report_still_running(self):
        """Report on incomplete analysis returns error."""
        with mock.patch("tryclear.commands.report.get_api_key", return_value="sk_live_test"):
            with mock.patch("tryclear.commands.report.get_api_url", return_value="https://api.test.com"):
                mock_client = mock.MagicMock()
                mock_client.status.return_value = {
                    "id": "ana_test123",
                    "status": "running",
                }

                with mock.patch("tryclear.commands.report.TryClearClient", return_value=mock_client):
                    result = cli.main(["report", "ana_test123"])
                    assert result == 3


class TestEvalFileTypeValidation:
    """CLI must reject unsupported file types before API call."""

    def test_exe_rejected(self):
        with tempfile.NamedTemporaryFile(delete=False, suffix=".exe") as f:
            f.write(b"MZ\x90")
            f.flush()
            with mock.patch("tryclear.commands.eval.get_api_key", return_value="sk_live_test"):
                result = cli.main(["eval", f.name])
                assert result == 3

    def test_gif_rejected(self):
        with tempfile.NamedTemporaryFile(delete=False, suffix=".gif") as f:
            f.write(b"GIF89a")
            f.flush()
            with mock.patch("tryclear.commands.eval.get_api_key", return_value="sk_live_test"):
                result = cli.main(["eval", f.name])
                assert result == 3

    def test_mp4_rejected(self):
        with tempfile.NamedTemporaryFile(delete=False, suffix=".mp4") as f:
            f.write(b"fakemp4")
            f.flush()
            with mock.patch("tryclear.commands.eval.get_api_key", return_value="sk_live_test"):
                result = cli.main(["eval", f.name])
                assert result == 3

    def test_txt_rejected(self):
        with tempfile.NamedTemporaryFile(delete=False, suffix=".txt") as f:
            f.write(b"hello")
            f.flush()
            with mock.patch("tryclear.commands.eval.get_api_key", return_value="sk_live_test"):
                result = cli.main(["eval", f.name])
                assert result == 3

    def test_no_extension_rejected(self):
        with tempfile.NamedTemporaryFile(delete=False, suffix="") as f:
            f.write(b"data")
            f.flush()
            with mock.patch("tryclear.commands.eval.get_api_key", return_value="sk_live_test"):
                result = cli.main(["eval", f.name])
                assert result == 3

    def test_json_output_on_rejection(self, capsys):
        from tryclear.commands import eval as eval_cmd
        from tryclear.display import get_console

        with tempfile.NamedTemporaryFile(delete=False, suffix=".zip") as f:
            f.write(b"PK")
            f.flush()
            with mock.patch.object(eval_cmd, "get_api_key", return_value="sk_live_test"):
                console = get_console(force_terminal=False)
                result = eval_cmd.run(console, f.name, json_output=True)
                assert result == 3
                captured = capsys.readouterr()
                output = json.loads(captured.out)
                assert "Unsupported file type" in output["error"]

    def test_png_not_rejected(self):
        """PNG should pass extension check (fails later on missing API)."""
        with tempfile.NamedTemporaryFile(delete=False, suffix=".png") as f:
            f.write(b"test")
            f.flush()
            with mock.patch("tryclear.commands.eval.get_api_key", return_value="sk_live_test"):
                with mock.patch("tryclear.commands.eval.get_api_url", return_value="https://api.test.com"):
                    mock_client = mock.MagicMock()
                    mock_client.submit.return_value = {"id": "ana_test", "status": "queued"}
                    with mock.patch("tryclear.commands.eval.TryClearClient", return_value=mock_client):
                        with mock.patch("tryclear.commands.eval.wait_with_spinner") as mock_wait:
                            mock_wait.return_value = {"status": "done", "summary": {"verdict": "clear"}}
                            result = cli.main(["eval", f.name])
                            assert result == 0

    def test_heic_not_rejected(self):
        """HEIC should pass extension check."""
        with tempfile.NamedTemporaryFile(delete=False, suffix=".heic") as f:
            f.write(b"test")
            f.flush()
            with mock.patch("tryclear.commands.eval.get_api_key", return_value="sk_live_test"):
                with mock.patch("tryclear.commands.eval.get_api_url", return_value="https://api.test.com"):
                    mock_client = mock.MagicMock()
                    mock_client.submit.return_value = {"id": "ana_test", "status": "queued"}
                    with mock.patch("tryclear.commands.eval.TryClearClient", return_value=mock_client):
                        with mock.patch("tryclear.commands.eval.wait_with_spinner") as mock_wait:
                            mock_wait.return_value = {"status": "done", "summary": {"verdict": "clear"}}
                            result = cli.main(["eval", f.name])
                            assert result == 0
