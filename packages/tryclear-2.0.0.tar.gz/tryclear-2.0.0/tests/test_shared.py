"""Tests for shared module."""

from tryclear.shared import verdict_to_exit_code, EXIT_CLEAR, EXIT_SUSPICIOUS, EXIT_MALICIOUS, EXIT_ERROR


class TestVerdictToExitCode:
    """Test verdict mapping."""

    def test_clear(self):
        assert verdict_to_exit_code("clear") == EXIT_CLEAR

    def test_benign(self):
        assert verdict_to_exit_code("benign") == EXIT_CLEAR

    def test_suspicious(self):
        assert verdict_to_exit_code("suspicious") == EXIT_SUSPICIOUS

    def test_malicious(self):
        assert verdict_to_exit_code("malicious") == EXIT_MALICIOUS

    def test_blocked(self):
        assert verdict_to_exit_code("blocked") == EXIT_MALICIOUS

    def test_unknown(self):
        assert verdict_to_exit_code("unknown") == EXIT_ERROR

    def test_case_insensitive(self):
        assert verdict_to_exit_code("CLEAR") == EXIT_CLEAR
        assert verdict_to_exit_code("Malicious") == EXIT_MALICIOUS
