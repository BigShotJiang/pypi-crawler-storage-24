# kigo/app.py
from __future__ import annotations

import sys
import math
import random
from typing import List, Dict, Any, Tuple

from kigo.qt import (
    QApplication, QWidget, QVBoxLayout, QFrame, Qt
)

# ============================================================
# Hardware acceleration detection (v2.1 core rule)
# ============================================================

def _detect_hw():
    caps = {
        "quick": False,
        "quick_widget": False,
        "opengl": False,
    }
    try:
        from qtpy import QtQuick  # noqa
        caps["quick"] = True
    except Exception:
        pass

    try:
        from qtpy import QtQuickWidgets  # noqa
        caps["quick_widget"] = True
    except Exception:
        pass

    try:
        from qtpy import QtOpenGLWidgets  # noqa
        caps["opengl"] = True
    except Exception:
        caps["opengl"] = hasattr(QWidget, "QOpenGLWidget")

    return caps


_HW = _detect_hw()


# ============================================================
# Physics Mount (unchanged, still correct)
# ============================================================

class _PhysicsMount(QFrame):
    """
    A thin container that holds one child QWidget and lets us apply per-frame
    pixel offsets (dx, dy) without fighting the outer layout.
    """
    def __init__(self, child_widget, pad_x: int = 24, pad_y: int = 24, parent=None):
        super().__init__(parent)
        self.setObjectName("_kigo_physics_mount")
        self.setStyleSheet(
            "QFrame#_kigo_physics_mount { background: transparent; border: none; }"
        )
        self.setLayout(None)

        self.child = getattr(child_widget, "qt_widget", child_widget)
        self.child.setParent(self)

        hint = self.child.sizeHint()
        self._pad_x = max(0, int(pad_x))
        self._pad_y = max(0, int(pad_y))
        self._base_x = self._pad_x
        self._base_y = self._pad_y

        self.resize(hint.width() + 2 * self._pad_x,
                    hint.height() + 2 * self._pad_y)
        self.child.resize(hint)
        self.child.move(self._base_x, self._base_y)

    def update_offset(self, dx_px: int, dy_px: int):
        dx_px = max(-self._pad_x, min(self._pad_x, int(dx_px)))
        dy_px = max(-self._pad_y, min(self._pad_y, int(dy_px)))
        self.child.move(self._base_x + dx_px, self._base_y + dy_px)


# ============================================================
# App (v2.1 – Hardware Accelerated)
# ============================================================

class App:
    """
    Kigo App v2.1
    Hardware-accelerated UI when available (Qt Quick),
    Bullet-driven physics when enabled (CPU physics, GPU render only).

    Acceleration policy:
      Quick → OpenGL → QWidget
    """

    def __init__(
        self,
        title: str = "Kigo App",
        size: Tuple[int, int] = (800, 600),
        physics: str | bool = "No",
        *,
        hardware_accel: str = "auto",   # auto | quick | off
        physics_fps: int = 120,
        pad_x_px: int = 24,
        pad_y_px: int = 24,
        pixels_per_meter: float = 80.0,
        bullet_gui: bool = False,
    ):
        # ----------------------------------------------------
        # QApplication
        # ----------------------------------------------------
        self.qt_app = QApplication.instance() or QApplication(sys.argv)
        QApplication.setAttribute(Qt.ApplicationAttribute.AA_EnableHighDpiScaling, True)
        QApplication.setAttribute(Qt.ApplicationAttribute.AA_UseHighDpiPixmaps, True)

        # ----------------------------------------------------
        # Root window
        # ----------------------------------------------------
        self.root = QWidget()
        self.root.setWindowTitle(title)
        self.root.resize(*size)

        self.layout = QVBoxLayout(self.root)

        # ----------------------------------------------------
        # Hardware acceleration choice
        # ----------------------------------------------------
        self.hardware_accel = (hardware_accel or "auto").lower()
        self.ui_backend = self._pick_ui_backend()

        # ----------------------------------------------------
        # Physics config
        # ----------------------------------------------------
        self.physics_enabled = self._as_bool(physics)
        self._physics_fps = max(1, int(physics_fps))
        self._px_per_m = float(pixels_per_meter)
        self._pad_x = int(pad_x_px)
        self._pad_y = int(pad_y_px)
        self._bullet_gui = bool(bullet_gui)

        self._engine = None
        self._entries: List[Dict[str, Any]] = []

        if self.physics_enabled:
            self._enable_physics_engine()

        print(
            f"[Kigo v2.1] UI={self.ui_backend.upper()} | "
            f"Physics={'ON' if self.physics_enabled else 'OFF'}"
        )

    # =====================================================
    # UI backend selection
    # =====================================================

    def _pick_ui_backend(self) -> str:
        if self.hardware_accel in ("off", "none"):
            return "widgets"

        if self.hardware_accel in ("quick", "qtquick"):
            return "quick" if _HW["quick_widget"] else "widgets"

        # auto
        if _HW["quick_widget"]:
            return "quick"
        return "widgets"

    # =====================================================
    # Public API
    # =====================================================

    def add_widget(self, widget, *, effect: str = "bounce", **effect_params):
        w = widget.qt_widget if hasattr(widget, "qt_widget") else widget

        # -------------------------------------------------
        # If physics OFF → add normally
        # -------------------------------------------------
        if not self.physics_enabled:
            self.layout.addWidget(w)
            return

        effect = (effect or "bounce").strip().lower()
        self._validate_effect(effect)

        mount = _PhysicsMount(w, pad_x=self._pad_x, pad_y=self._pad_y)
        self.layout.addWidget(mount)

        body_id, origin = self._spawn_body_for_widget(effect)
        params = {
            **self._default_params_for(effect),
            **effect_params
        }

        self._entries.append({
            "mount": mount,
            "body": body_id,
            "origin": origin,
            "last_pos": origin,
            "effect": effect,
            "params": params,
            "phase": random.uniform(0.0, math.tau),
            "done": False,
        })

    def run(self):
        self.root.show()
        sys.exit(self.qt_app.exec())

    # =====================================================
    # Physics engine
    # =====================================================

    def _enable_physics_engine(self):
        if self._engine is not None:
            return
        from kigo.physics import PhysicsEngine
        self._engine = PhysicsEngine(
            use_gui=self._bullet_gui,
            fps=self._physics_fps
        )
        self._engine.setup_scene()
        self._engine.frame_updated.connect(self._on_bullet_frame)  # type: ignore
        self._engine.toggle_simulation(True)

    # =====================================================
    # Bullet update loop
    # =====================================================

    def _on_bullet_frame(self):
        if not self._engine or not self._entries:
            return

        dt = 1.0 / self._physics_fps

        for entry in list(self._entries):
            if entry["done"]:
                continue

            body = entry["body"]
            x0, y0, z0 = entry["origin"]
            lx, ly, lz = entry["last_pos"]
            effect = entry["effect"]
            params = entry["params"]

            x, y, z = self._engine.get_pos(body)
            vx = (x - lx) / dt
            vz = (z - lz) / dt
            entry["last_pos"] = (x, y, z)

            # ------------------------------------------------
            # Effects
            # ------------------------------------------------
            if effect == "spring":
                k = params["k"]
                c = params["c"]
                fz = -k * (z - z0) - c * vz
                self._engine.apply_impulse(body, (0, 0, fz))

            elif effect == "bounce":
                phase = entry["phase"] + math.tau * params["freq"] * dt
                entry["phase"] = phase
                fz = max(0.0, params["force"] * math.sin(phase))
                if fz:
                    self._engine.apply_impulse(body, (0, 0, fz))

            elif effect == "fall":
                if z <= params["eps"] and abs(vz) < params["v_eps"]:
                    entry["done"] = True

            elif effect == "move":
                phase = entry["phase"] + math.tau * params["freq"] * dt
                entry["phase"] = phase
                fx = params["force"] * math.sin(phase)
                self._engine.apply_impulse(body, (fx, 0, 0))

            # ------------------------------------------------
            # Map physics → pixels
            # ------------------------------------------------
            dx_px = (x - x0) * self._px_per_m if effect == "move" else 0.0
            dy_px = (z - z0) * self._px_per_m
            entry["mount"].update_offset(int(dx_px), int(dy_px))

    # =====================================================
    # Helper v2.1 (this has been through changes)
    # =====================================================

    def _spawn_body_for_widget(self, effect: str):
        z0 = random.uniform(0.7, 1.3)
        x0 = random.uniform(-0.1, 0.1)
        y0 = 0.0
        body = self._engine.spawn_object(
            shape="cube",
            position=(x0, y0, z0),
            size=0.1,
            mass=1.0
        )
        return body, (x0, y0, z0)

    @staticmethod
    def _as_bool(v):
        if isinstance(v, str):
            return v.strip().lower() in ("1", "true", "yes", "on")
        return bool(v)

    @staticmethod
    def _validate_effect(effect: str):
        if effect not in {"spring", "bounce", "fall", "gravity", "move"}:
            raise ValueError(f"Unknown effect '{effect}'")

    @staticmethod
    def _default_params_for(effect: str):
        return {
            "spring": {"k": 40.0, "c": 4.0},
            "bounce": {"freq": 0.8, "force": 12.0},
            "fall": {"eps": 0.01, "v_eps": 0.05},
            "gravity": {},
            "move": {"freq": 0.6, "force": 6.0},
        }.get(effect, {})
