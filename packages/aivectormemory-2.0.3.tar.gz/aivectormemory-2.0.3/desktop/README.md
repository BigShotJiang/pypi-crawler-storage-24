# README

## About

This is the official Wails Vue-TS template.

You can configure the project by editing `wails.json`. More information about the project settings can be found
here: https://wails.io/docs/reference/project-config

## Live Development

To run in live development mode, run `wails dev` in the project directory. This will run a Vite development
server that will provide very fast hot reload of your frontend changes. If you want to develop in a browser
and have access to your Go methods, there is also a dev server that runs on http://localhost:34115. Connect
to this in your browser, and you can call your Go code from devtools.

## Building

To build a redistributable, production mode package, use `wails build`.

For a macOS drag-install image that lets users drop the app into `Applications`, run:

```bash
cd desktop
/tmp/gopath/bin/wails build -clean -platform darwin/amd64 -m -nosyncgomod
./build/package_dmg.sh
```

The resulting installer image is written to `build/bin/AIVectorMemory-darwin-amd64.dmg`.
The DMG window automatically uses `docs/image.png` as the background and applies a 60% white overlay without additional decorative elements.
