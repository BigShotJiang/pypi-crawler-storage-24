# File : adapter.py
# Author : Sébastien Deriaz
# License : GPL

"""
Adapters provide a common abstraction for the media layers (physical + data link + network)

The user calls methods of the Adapter class synchronously.

An adapter is meant to work with bytes objects but it can accept strings.
Strings will automatically be converted to bytes using utf-8 encoding

Each adapter contains a worker thread that monitors the low-level communication layers.
This approach allows for precise time management (when each fragment is sent/received) and allows
for asynchronous events (fragment received).

Async facade:
- aopen/awrite/aread/aread_detailed simply await the SAME underlying worker-thread commands
  using asyncio.wrap_future (no extra threads are spawned).
"""

import asyncio
import threading
import weakref
from abc import abstractmethod
from collections.abc import Callable
from enum import Enum
from types import EllipsisType
from typing import Generic, TypeVar

from syndesi.adapters.stop_conditions import StopCondition
from syndesi.tools.errors import AdapterError

from ..component import Component, Descriptor, Frame, ReadScope
from ..tools.log_settings import LoggerAlias
from ..tools.types import is_number
from .adapterworkerbase import (  # SetDescriptorCommand,
    AdapterEvent,
    AdapterWorkerBase,
    AdapterWorkerInterface,
    AddEventCallbackCommand,
    CloseCommand,
    FlushReadCommand,
    IsOpenCommand,
    OpenCommand,
    ReadCommand,
    SetTimeoutCommand,
    StopThreadCommand,
    WriteCommand,
)
from .timeout import Timeout, TimeoutType, any_to_timeout

DataT = TypeVar("DataT")


# pylint: disable=too-many-public-methods, too-many-instance-attributes
class AdapterBase(Generic[DataT], AdapterWorkerInterface[DataT], Component[DataT]):
    """
    Adapter class

    An adapter manages communication with a hardware device.
    """

    class WorkerTimeout(Enum):
        """Timeout value for each worker command scenario"""

        OPEN = 2
        STOP = 1
        IMMEDIATE_COMMAND = 0.2
        CLOSE = 0.5
        WRITE = 0.5
        READ = None

    def __init__(
        self,
        *,
        worker: AdapterWorkerBase[DataT],
        descriptor: Descriptor,
        timeout: TimeoutType,
        # stop_conditions : StopCondition | list[StopCondition] | EllipsisType,
        alias: str,
        # encoding: str = "utf-8",
        auto_open: bool = True,
    ) -> None:
        Component.__init__(self, LoggerAlias.ADAPTER)
        AdapterWorkerInterface.__init__(self, descriptor)

        self._alias = alias
        self._event_callbacks: list[Callable[[AdapterEvent], None]] = []
        self._worker = worker
        self._auto_open = auto_open

        # Default timeout
        self.is_default_timeout = timeout is Ellipsis

        if timeout is Ellipsis:
            self._initial_timeout = self._default_timeout()
        elif isinstance(timeout, Timeout):
            self._initial_timeout = timeout
        elif is_number(timeout):
            self._initial_timeout = Timeout(timeout)
        elif timeout is None:
            self._initial_timeout = Timeout(None)
        else:
            raise ValueError(f"Invalid timeout : {timeout}")

        # Serialize read/write/query ordering for sync callers.
        self._sync_io_lock = threading.Lock()
        # Serialize read/write/query ordering for async callers.
        self._async_io_lock = asyncio.Lock()

        self._logger.info(f"Setting up {self._descriptor} adapter ")
        self.set_timeout(self._initial_timeout)

        if self._descriptor.is_initialized() and self._auto_open:
            self.open()

        weakref.finalize(self, self._cleanup)

    def get_descriptor(self) -> Descriptor:
        """
        Return the adapter's descriptor

        Returns
        -------
        descriptor : Descriptor
        """
        return self._descriptor

    # ┌──────────────────────────┐
    # │ Defaults / configuration │
    # └──────────────────────────┘

    def _stop(self) -> None:
        self._worker.stop()
        cmd = StopThreadCommand()
        self._worker.send_command(cmd)
        try:
            cmd.result(self.WorkerTimeout.STOP.value)
        except AdapterError:
            pass

    @abstractmethod
    def _default_timeout(self) -> Timeout:
        raise NotImplementedError

    def __str__(self) -> str:
        return str(self._descriptor)

    def __repr__(self) -> str:
        return self.__str__()

    def _cleanup(self) -> None:
        try:
            if self.is_open():
                self.close()
        except AdapterError:
            pass
        self._stop()

    # ┌────────────┐
    # │ Public API │
    # └────────────┘

    def set_timeout(self, timeout: Timeout | None | float) -> None:
        """
        Set adapter timeout

        Parameters
        ----------
        timeout : Timeout, float or None
        """
        # This is read by the worker when ReadCommand.timeout is ...
        timeout_instance = any_to_timeout(timeout)
        cmd = SetTimeoutCommand(timeout_instance)
        self._worker.send_command(cmd)
        cmd.result(self.WorkerTimeout.IMMEDIATE_COMMAND.value)

    def set_default_timeout(self, default_timeout: Timeout | None) -> None:
        """
        Configure adapter default timeout. Timeout will only be set if none
        has been configured before

        Parameters
        ----------
        default_timeout : Timeout or None
        """
        if self.is_default_timeout:
            new_timeout = any_to_timeout(default_timeout)
            self._logger.debug(f"Setting default timeout to {new_timeout}")
            self.set_timeout(new_timeout)

    def register_event_callback(self, callback: Callable[[AdapterEvent], None]) -> None:
        """
        Configure event callback. Event callback is called as such :

        callback(event : AdapterEvent)

        Parameters
        ----------
        callback : callable

        """
        cmd = AddEventCallbackCommand(callback)
        self._worker.send_command(cmd)
        cmd.result(self.WorkerTimeout.IMMEDIATE_COMMAND.value)

    # ==== open ====

    def _open_future(self) -> OpenCommand:
        cmd = OpenCommand()
        self._worker.send_command(cmd)
        return cmd

    def open(self) -> None:
        """
        Open adapter communication with the target (blocking)
        """
        return self._open_future().result(self.WorkerTimeout.OPEN.value)

    async def aopen(self) -> None:
        """
        Open adapter communication with the target (async)
        """
        await asyncio.wrap_future(self._open_future())

    # ==== close ====

    def _close_future(self) -> CloseCommand:
        cmd = CloseCommand()
        self._worker.send_command(cmd)
        return cmd

    def close(self) -> None:
        """
        Close adapter communication with the target (blocking)
        """
        self._close_future().result(self.WorkerTimeout.CLOSE.value)

    async def aclose(self) -> None:
        """
        Close adapter communication with the target (async)
        """
        await asyncio.wrap_future(self._close_future())

    # ==== read_detailed ====

    def _read_detailed_future(
        self,
        timeout: TimeoutType,
        scope: str,
        stop_conditions: StopCondition | EllipsisType | list[StopCondition],
    ) -> ReadCommand[DataT]:
        cmd: ReadCommand[DataT] = ReadCommand(
            timeout=timeout, scope=ReadScope(scope), stop_conditions=stop_conditions
        )
        self._worker.send_command(cmd)
        return cmd

    def read_detailed(
        self,
        timeout: TimeoutType = ...,
        scope: str = ReadScope.BUFFERED.value,
        stop_conditions: StopCondition | EllipsisType | list[StopCondition] = ...,
    ) -> Frame[DataT]:
        with self._sync_io_lock:
            result = self._read_detailed_future(
                timeout=timeout, scope=scope, stop_conditions=stop_conditions
            ).result(self.WorkerTimeout.READ.value)
        return result

    async def aread_detailed(
        self,
        timeout: TimeoutType = ...,
        scope: str = ReadScope.BUFFERED.value,
        stop_conditions: StopCondition | EllipsisType | list[StopCondition] = ...,
    ) -> Frame[DataT]:
        async with self._async_io_lock:
            return await asyncio.wrap_future(
                self._read_detailed_future(
                    timeout=timeout, scope=scope, stop_conditions=stop_conditions
                )
            )

    # ==== read ====

    def read(
        self,
        timeout: TimeoutType = ...,
        scope: str = ReadScope.BUFFERED.value,
        stop_conditions: StopCondition | EllipsisType | list[StopCondition] = ...,
    ) -> DataT:
        frame = self.read_detailed(
            timeout=timeout, scope=scope, stop_conditions=stop_conditions
        )
        return frame.data

    async def aread(
        self,
        timeout: TimeoutType = ...,
        scope: str = ReadScope.BUFFERED.value,
        stop_conditions: StopCondition | EllipsisType | list[StopCondition] = ...,
    ) -> DataT:
        frame = await self.aread_detailed(
            timeout=timeout, scope=scope, stop_conditions=stop_conditions
        )
        return frame.data

    # ==== flush_read ====

    def _flush_read_future(self) -> FlushReadCommand:
        cmd = FlushReadCommand()
        self._worker.send_command(cmd)
        return cmd

    async def aflush_read(self) -> None:
        """
        Clear buffered completed frames and reset current fragment assembly (async)
        """
        async with self._async_io_lock:
            await asyncio.wrap_future(self._flush_read_future())

    def flush_read(self) -> None:
        """
        Clear buffered completed frames and reset current fragment assembly (blocking)
        """
        with self._sync_io_lock:
            self._flush_read_future().result(self.WorkerTimeout.IMMEDIATE_COMMAND.value)

    # ==== write ====

    def _write_future(self, data: DataT) -> WriteCommand[DataT]:
        cmd = WriteCommand(data)
        self._worker.send_command(cmd)
        return cmd

    def write(self, data: DataT) -> None:
        with self._sync_io_lock:
            self._write_future(data).result(self.WorkerTimeout.WRITE.value)

    async def awrite(self, data: DataT) -> None:
        async with self._async_io_lock:
            await asyncio.wrap_future(self._write_future(data))

    # ==== query ====

    async def aquery_detailed(
        self,
        payload: DataT,
        timeout: Timeout | None | EllipsisType = ...,
        scope: str = ReadScope.BUFFERED.value,
        stop_conditions: StopCondition | EllipsisType | list[StopCondition] = ...,
    ) -> Frame[DataT]:
        async with self._async_io_lock:
            await asyncio.wrap_future(self._flush_read_future())
            await asyncio.wrap_future(self._write_future(payload))
            return await asyncio.wrap_future(
                self._read_detailed_future(
                    timeout=timeout, scope=scope, stop_conditions=stop_conditions
                )
            )

    def query_detailed(
        self,
        payload: DataT,
        timeout: Timeout | None | EllipsisType = ...,
        scope: str = ReadScope.BUFFERED.value,
        stop_conditions: StopCondition | EllipsisType | list[StopCondition] = ...,
    ) -> Frame[DataT]:

        with self._sync_io_lock:
            self._flush_read_future().result(self.WorkerTimeout.IMMEDIATE_COMMAND.value)
            self._write_future(payload).result(self.WorkerTimeout.WRITE.value)
            output = self._read_detailed_future(
                timeout=timeout, scope=scope, stop_conditions=stop_conditions
            ).result(self.WorkerTimeout.READ.value)
        return output

    # ==== Other ====

    def _is_open_future(self) -> IsOpenCommand:
        cmd = IsOpenCommand()
        self._worker.send_command(cmd)
        return cmd

    def is_open(self) -> bool:
        """Check if the adapter is open"""
        return self._is_open_future().result(self.WorkerTimeout.IMMEDIATE_COMMAND.value)

    async def ais_open(self) -> bool:
        """Asynchronously check if the adapter is open"""
        return await asyncio.wrap_future(self._is_open_future())
