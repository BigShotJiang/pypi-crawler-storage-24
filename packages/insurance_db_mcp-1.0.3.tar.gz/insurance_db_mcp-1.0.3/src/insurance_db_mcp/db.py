"""数据库连接与操作模块"""
import pymysql
import json
from decimal import Decimal
from datetime import datetime, date

# 数据库配置
DB_CONFIG = {
    "host": "43.143.125.184",
    "port": 23306,
    "user": "root",
    "password": "12345678q",
    "database": "insurance_db",
    "charset": "utf8mb4",
    "connect_timeout": 10,
    "cursorclass": pymysql.cursors.DictCursor,
}

# 数据库Schema信息
SCHEMA_INFO = """
数据库: insurance_db (保险业务数据库)

表结构:

1. customers (客户信息表)
   - customer_id VARCHAR(50) PRIMARY KEY -- 客户ID
   - name VARCHAR(100) -- 客户姓名
   - gender VARCHAR(10) -- 性别
   - birth_date DATE -- 出生日期
   - city VARCHAR(50) -- 城市
   - registration_date DATETIME -- 注册日期
   - customer_level VARCHAR(20) -- 客户等级
   - total_premium DECIMAL(18,2) -- 总保费

2. policies (保单信息表)
   - id INT AUTO_INCREMENT PRIMARY KEY
   - policy_id VARCHAR(50) -- 保单ID
   - customer_id VARCHAR(50) -- 客户ID (关联customers.customer_id)
   - policy_type VARCHAR(50) -- 保单类型
   - premium DECIMAL(18,2) -- 保费
   - start_date DATETIME -- 起始日期
   - end_date DATETIME -- 结束日期
   - status VARCHAR(20) -- 状态
   - INDEX idx_customer_id (customer_id)
   - INDEX idx_policy_type (policy_type)

3. claims (理赔记录表)
   - id INT AUTO_INCREMENT PRIMARY KEY
   - claim_id VARCHAR(50) -- 理赔ID
   - policy_id VARCHAR(50) -- 保单ID (关联policies.policy_id)
   - customer_id VARCHAR(50) -- 客户ID (关联customers.customer_id)
   - claim_amount DECIMAL(18,2) -- 理赔金额
   - claim_date DATETIME -- 理赔日期
   - status VARCHAR(20) -- 状态
   - INDEX idx_customer_id (customer_id)

4. premiums (缴费记录表)
   - id INT AUTO_INCREMENT PRIMARY KEY
   - premium_id VARCHAR(50) -- 缴费ID
   - policy_id VARCHAR(50) -- 保单ID (关联policies.policy_id)
   - customer_id VARCHAR(50) -- 客户ID (关联customers.customer_id)
   - amount DECIMAL(18,2) -- 缴费金额
   - payment_date DATETIME -- 缴费日期
   - payment_method VARCHAR(50) -- 支付方式
   - INDEX idx_customer_id (customer_id)

表之间的关系:
- policies.customer_id -> customers.customer_id
- claims.customer_id -> customers.customer_id
- claims.policy_id -> policies.policy_id
- premiums.customer_id -> customers.customer_id
- premiums.policy_id -> policies.policy_id
""".strip()


class JSONEncoder(json.JSONEncoder):
    """自定义JSON编码器，处理Decimal和datetime等类型"""
    def default(self, obj):
        if isinstance(obj, Decimal):
            return float(obj)
        if isinstance(obj, (datetime, date)):
            return obj.isoformat()
        return super().default(obj)


def get_connection():
    """获取数据库连接"""
    return pymysql.connect(**DB_CONFIG)


def execute_query(sql: str, params: tuple = None) -> dict:
    """
    执行SQL查询并返回结果
    """
    conn = None
    try:
        conn = get_connection()
        with conn.cursor() as cursor:
            cursor.execute(sql, params)
            
            # 判断是否为SELECT查询
            sql_upper = sql.strip().upper()
            if sql_upper.startswith("SELECT") or sql_upper.startswith("SHOW") or sql_upper.startswith("DESC"):
                rows = cursor.fetchall()
                columns = [desc[0] for desc in cursor.description] if cursor.description else []
                # 序列化结果
                serialized_rows = json.loads(json.dumps(rows, cls=JSONEncoder))
                return {
                    "success": True,
                    "data": serialized_rows,
                    "columns": columns,
                    "row_count": len(rows),
                }
            else:
                conn.commit()
                return {
                    "success": True,
                    "affected_rows": cursor.rowcount,
                    "message": f"操作成功，影响了 {cursor.rowcount} 行",
                }
    except pymysql.Error as e:
        return {
            "success": False,
            "error": str(e),
            "error_code": e.args[0] if e.args else None,
        }
    except Exception as e:
        return {
            "success": False,
            "error": str(e),
        }
    finally:
        if conn:
            conn.close()


def test_connection() -> bool:
    """测试数据库连接"""
    try:
        result = execute_query("SELECT 1 as test")
        return result.get("success", False)
    except Exception:
        return False


def get_table_stats() -> dict:
    """获取各表的数据统计"""
    tables = ["customers", "policies", "claims", "premiums"]
    stats = {}
    for table in tables:
        result = execute_query(f"SELECT COUNT(*) as cnt FROM {table}")
        if result["success"] and result["data"]:
            stats[table] = result["data"][0]["cnt"]
        else:
            stats[table] = "error"
    return stats
