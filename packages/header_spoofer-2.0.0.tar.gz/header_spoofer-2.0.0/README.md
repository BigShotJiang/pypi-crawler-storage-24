# header-spoofer

Discord browser fingerprint & header spoofing library. Generates realistic Chrome headers, X-Super-Properties, cookies, and fingerprints tied to a deterministic browser profile — making selfbot requests indistinguishable from a real browser session.

## Install

```
pip install header-spoofer
```

## Features

- Deterministic `BrowserProfile` per token (consistent UA, locale, timezone, resolution)
- Auto-fetches and caches Discord build number from live JS assets
- Fetches real fingerprint + cookies from Discord's `/experiments` endpoint
- Builds accurate `X-Super-Properties` with all client metadata
- Full header sets for REST, multipart, WebSocket, and science endpoints
- Pre-built payload helpers for messages, reactions, profiles, statuses, threads, and more

## Usage

```python
from header_spoofer import HeaderSpoofer

spoofer = HeaderSpoofer("your_token_here")

# REST headers (chat context)
headers = spoofer.get_headers()

# Custom referer + context
headers = spoofer.get_headers(
    referer="https://discord.com/channels/123/456",
    context_location="chat_input",
)

# WebSocket headers
ws_headers = spoofer.get_websocket_headers()

# Multipart (file upload)
mp_headers = spoofer.get_multipart_headers("multipart/form-data; boundary=----boundary")

# Build a message payload
payload = spoofer.build_message_payload("hello world")

# Full send_message bundle (url + headers + json)
bundle = spoofer.send_message(channel_id="123456", content="hi", guild_id="789")
```

## Methods

| Method | Description |
|---|---|
| `get_headers(...)` | Standard REST headers with Authorization |
| `get_websocket_headers()` | Headers for WS upgrade handshake |
| `get_multipart_headers(content_type)` | Headers for file/multipart uploads |
| `get_science_headers()` | Headers for Discord science/analytics endpoint |
| `fetch_fingerprint()` | Fetch and cache fingerprint + cookies |
| `refresh_build_number()` | Force re-fetch of Discord build number |
| `build_message_payload(...)` | Message JSON with optional reply, attachments, stickers |
| `build_status_payload(...)` | Status + custom status JSON |
| `build_profile_payload(...)` | Profile patch JSON (bio, banner, effects) |
| `send_message(...)` | Ready-to-use `{url, headers, json}` bundle |
| `join_guild(invite_code)` | Join guild bundle |
| `add_friend(username)` | Add friend bundle |
| `patch_avatar(image_bytes)` | Avatar patch bundle |

## License

Source Available — free to use, not to steal. See [LICENSE](LICENSE).  
Made by **nox** · [github.com/pulbv](https://github.com/pulbv)