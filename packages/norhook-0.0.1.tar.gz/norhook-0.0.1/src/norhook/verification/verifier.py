from datetime import datetime
from typing import List, Union

from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.asymmetric import rsa, ed25519, padding

from norhook.core.canonical import canonicalize
from norhook.core.encoding import b64url_decode
from norhook.core.hashing import sha256_bytes
from norhook.core.schema import AIReceipt, Mode, EventType
from norhook.core.receipt_builder import _build_unsigned_payload
from norhook.core.fingerprint import receipt_fingerprint, payload_fingerprint
from norhook.governance.versioning import validate_versions
from norhook.verification.result import VerificationResult
from norhook.verification.mode_validators import (
    validate_human_confirmation,
    validate_delegation,
)
from norhook.verification.interfaces import (
    ReplayChecker,
    TransparencyChecker,
)


MAX_RECEIPT_SIZE_BYTES = 64 * 1024
ALLOWED_SIGNATURE_ALGORITHMS = {"ed25519", "rsa-pss"}
MIN_RSA_KEY_SIZE = 3072
MIN_KEY_ID_LENGTH = 16


def verify_receipt(
    receipt_dict: dict,
    public_keys: Union[bytes, List[bytes]],
    verification_time: datetime | None = None,
    replay_checker: ReplayChecker | None = None,
    transparency_checker: TransparencyChecker | None = None,
    trusted_public_keys: List[bytes] | None = None,
    time_provider=None,
    revoked_key_ids: List[str] | None = None,
) -> VerificationResult:

    control_ids: List[str] = []

    # ------------------------------------------------------------------
    # Size Guard (canonicalized deterministic size enforcement)
    # ------------------------------------------------------------------
    try:
        raw_bytes = canonicalize(receipt_dict)
    except Exception:
        return VerificationResult(False, "Invalid receipt structure", "high")

    if len(raw_bytes) > MAX_RECEIPT_SIZE_BYTES:
        return VerificationResult(False, "Receipt exceeds size limit", "high")

    control_ids.append("NORHOOK-STRUCT-001")

    # ------------------------------------------------------------------
    # Normalize Public Keys
    # ------------------------------------------------------------------
    if isinstance(public_keys, bytes):
        public_keys = [public_keys]

    # ------------------------------------------------------------------
    # Trusted Public Key Allowlist
    # ------------------------------------------------------------------
    if trusted_public_keys is not None:
        public_keys = [pk for pk in public_keys if pk in trusted_public_keys]
        if not public_keys:
            return VerificationResult(False, "Public key not trusted", "high")

        control_ids.append("NORHOOK-TRUST-001")

    # ------------------------------------------------------------------
    # Parse Receipt (Schema-level structural validation)
    # ------------------------------------------------------------------
    try:
        receipt = AIReceipt(**receipt_dict)
    except Exception as e:
        return VerificationResult(False, str(e), "high")

    control_ids.append("NORHOOK-SCHEMA-001")

    # ------------------------------------------------------------------
    # Algorithm Allowlist
    # ------------------------------------------------------------------
    if receipt.signature_algorithm not in ALLOWED_SIGNATURE_ALGORITHMS:
        return VerificationResult(False, "Unsupported signature algorithm", "high")

    control_ids.append("NORHOOK-ALG-001")

    # ------------------------------------------------------------------
    # Deterministic Nonce Enforcement
    # ------------------------------------------------------------------
    if not receipt.nonce:
        return VerificationResult(False, "Missing nonce", "high")

    control_ids.append("NORHOOK-NONCE-001")

    # ------------------------------------------------------------------
    # Key ID Structural Enforcement
    # ------------------------------------------------------------------
    if len(receipt.key_id) < MIN_KEY_ID_LENGTH:
        return VerificationResult(False, "Invalid key_id length", "high")

    control_ids.append("NORHOOK-KEYSTRUCT-001")

    # ------------------------------------------------------------------
    # Trusted Time Resolution
    # ------------------------------------------------------------------
    if verification_time is None:
        verification_time = time_provider() if time_provider else receipt.timestamp

    # ------------------------------------------------------------------
    # Recompute receipt_id (unsigned deterministic structure)
    # ------------------------------------------------------------------
    base_payload = _build_unsigned_payload(
        protocol_version=receipt.protocol_version,
        schema_version=receipt.schema_version,
        receipt_version=receipt.receipt_version,
        algorithm_policy_version=receipt.algorithm_policy_version,
        timestamp=receipt.timestamp.isoformat(),
        nonce=receipt.nonce,
        event_type=receipt.event_type.value,
        ai=receipt.ai.model_dump(mode="json"),
        mode=receipt.mode.value,
        crypto_profile=receipt.crypto_profile.model_dump(mode="json"),
        signature_algorithm=receipt.signature_algorithm,
        key_id=receipt.key_id,
        previous_hash=receipt.previous_hash,
        tenant_id=receipt.tenant_id,
        output_hash=receipt.output_hash,
        human=receipt.human.model_dump(mode="json") if receipt.human else None,
        delegation=receipt.delegation.model_dump(mode="json") if receipt.delegation else None,
        action=receipt.action.model_dump(mode="json") if receipt.action else None,
        tool_call=receipt.tool_call.model_dump(mode="json") if receipt.tool_call else None,
        intervention=receipt.intervention.model_dump(mode="json") if receipt.intervention else None,
        artifact=receipt.artifact.model_dump(mode="json") if receipt.artifact else None,
        external_timestamp=receipt.external_timestamp.model_dump(mode="json")
        if receipt.external_timestamp
        else None,
    )

    expected_id = sha256_bytes(canonicalize(base_payload))

    if expected_id != receipt.receipt_id:
        return VerificationResult(False, "Receipt ID mismatch", "high")

    control_ids.append("NORHOOK-ID-001")

    # ------------------------------------------------------------------
    # Recompute Full Payload
    # ------------------------------------------------------------------
    reconstructed = _build_unsigned_payload(
        protocol_version=receipt.protocol_version,
        schema_version=receipt.schema_version,
        receipt_version=receipt.receipt_version,
        algorithm_policy_version=receipt.algorithm_policy_version,
        timestamp=receipt.timestamp.isoformat(),
        nonce=receipt.nonce,
        event_type=receipt.event_type.value,
        ai=receipt.ai.model_dump(mode="json"),
        mode=receipt.mode.value,
        crypto_profile=receipt.crypto_profile.model_dump(mode="json"),
        signature_algorithm=receipt.signature_algorithm,
        key_id=receipt.key_id,
        receipt_id=receipt.receipt_id,
        previous_hash=receipt.previous_hash,
        tenant_id=receipt.tenant_id,
        output_hash=receipt.output_hash,
        human=receipt.human.model_dump(mode="json") if receipt.human else None,
        delegation=receipt.delegation.model_dump(mode="json") if receipt.delegation else None,
        action=receipt.action.model_dump(mode="json") if receipt.action else None,
        tool_call=receipt.tool_call.model_dump(mode="json") if receipt.tool_call else None,
        intervention=receipt.intervention.model_dump(mode="json") if receipt.intervention else None,
        artifact=receipt.artifact.model_dump(mode="json") if receipt.artifact else None,
        external_timestamp=receipt.external_timestamp.model_dump(mode="json")
        if receipt.external_timestamp
        else None,
    )

    payload = canonicalize(reconstructed)

    if receipt.receipt_hash != sha256_bytes(payload):
        return VerificationResult(False, "Receipt hash mismatch", "high")

    control_ids.append("NORHOOK-HASH-001")

    # ------------------------------------------------------------------
    # Signature Verification
    # ------------------------------------------------------------------
    signature_bytes = b64url_decode(receipt.signature)
    verified_key = None

    for public_key_pem in public_keys:
        try:
            public_key = serialization.load_pem_public_key(public_key_pem)

            if isinstance(public_key, ed25519.Ed25519PublicKey):
                public_key.verify(signature_bytes, payload)

            elif isinstance(public_key, rsa.RSAPublicKey):
                if public_key.key_size < MIN_RSA_KEY_SIZE:
                    return VerificationResult(False, "RSA key too small", "high")

                public_key.verify(
                    signature_bytes,
                    payload,
                    padding.PSS(
                        mgf=padding.MGF1(hashes.SHA256()),
                        salt_length=padding.PSS.MAX_LENGTH,
                    ),
                    hashes.SHA256(),
                )
            else:
                continue

            verified_key = public_key
            break

        except Exception:
            continue

    if not verified_key:
        return VerificationResult(False, "Signature invalid", "critical")

    control_ids.append("NORHOOK-SIG-001")

    # ------------------------------------------------------------------
    # key_id Derivation Check
    # ------------------------------------------------------------------
    derived_key_id = sha256_bytes(
        verified_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        )
    )[:MIN_KEY_ID_LENGTH]

    if derived_key_id != receipt.key_id:
        return VerificationResult(False, "Key ID mismatch", "critical")

    control_ids.append("NORHOOK-KEY-001")

    # ------------------------------------------------------------------
    # Revocation Check
    # ------------------------------------------------------------------
    if revoked_key_ids and receipt.key_id in revoked_key_ids:
        return VerificationResult(False, "Signing key revoked", "critical")

    if revoked_key_ids is not None:
        control_ids.append("NORHOOK-REV-001")

    # ------------------------------------------------------------------
    # Version Validation
    # ------------------------------------------------------------------
    ok, reason = validate_versions(receipt)
    if not ok:
        return VerificationResult(False, reason, "medium")

    control_ids.append("NORHOOK-VERSION-001")

    # ------------------------------------------------------------------
    # Mode Validation
    # ------------------------------------------------------------------
    ok, reason = validate_human_confirmation(receipt)
    if not ok:
        return VerificationResult(False, reason, "high")

    ok, reason = validate_delegation(receipt, verification_time)
    if not ok:
        return VerificationResult(False, reason, "high")

    control_ids.append("NORHOOK-MODE-001")

    # ------------------------------------------------------------------
    # Replay Detection (Operational Control)
    # ------------------------------------------------------------------
    if replay_checker:
        fingerprint = receipt_fingerprint(receipt_dict)

        if hasattr(replay_checker, "check"):
            is_replay, _ = replay_checker.check(fingerprint)
        else:
            is_replay = replay_checker.is_replayed(fingerprint)

        if is_replay:
            return VerificationResult(False, "Replay detected", "critical", control_ids)

        control_ids.append("NORHOOK-REPLAY-001")

    # ------------------------------------------------------------------
    # Transparency Inclusion Check (Accountability Anchor)
    # ------------------------------------------------------------------
    if transparency_checker:
        pf = payload_fingerprint(receipt)
        included = transparency_checker.verify_inclusion(pf)

        if not included:
            return VerificationResult(False, "Transparency inclusion failed", "high", control_ids)

        control_ids.append("NORHOOK-TRANSPARENCY-001")

    # ------------------------------------------------------------------
    # Success
    # ------------------------------------------------------------------
    return VerificationResult(True, None, "info", control_ids)
