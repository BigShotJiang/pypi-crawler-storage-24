from typing import Protocol, Tuple, Optional, runtime_checkable


# ---------------------------------------------------------------------
# Replay Detection Interfaces
# ---------------------------------------------------------------------

@runtime_checkable
class ReplayChecker(Protocol):
    """
    Minimal replay detection contract.

    Implementations MUST be:
    - Deterministic
    - Idempotent
    - Storage-backed (external to AIL core)
    """

    def is_replayed(self, fingerprint: str) -> bool:
        """
        Returns True if the fingerprint has already been observed.
        Must NOT mutate external state.
        """
        ...


@runtime_checkable
class EnhancedReplayChecker(Protocol):
    """
    Extended replay detection contract.

    Allows single-call insert + check semantics.
    """

    def check(self, fingerprint: str) -> Tuple[bool, bool]:
        """
        Returns:
            (is_replay, is_first_seen)

        is_replay:
            True if fingerprint already exists.

        is_first_seen:
            True if this call inserted the fingerprint.

        Implementation must guarantee atomicity.
        """
        ...


# ---------------------------------------------------------------------
# Transparency Interfaces
# ---------------------------------------------------------------------

@runtime_checkable
class TransparencyChecker(Protocol):
    """
    Transparency inclusion verification contract.

    Designed for:
    - Merkle tree inclusion verification
    - Append-only log validation
    - Public transparency anchor validation

    AIL core remains storage-agnostic.
    """

    def verify_inclusion(
        self,
        payload_fingerprint: str,
        proof: Optional[dict] = None,
    ) -> bool:
        """
        Verifies inclusion of payload fingerprint in transparency log.

        Parameters:
            payload_fingerprint:
                Deterministic fingerprint of unsigned payload.

            proof:
                Optional inclusion proof structure (e.g. Merkle branch).

        Must NOT perform network calls implicitly.
        Must remain deterministic.
        """
        ...
