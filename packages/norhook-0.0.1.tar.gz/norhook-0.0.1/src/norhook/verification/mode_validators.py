from datetime import datetime
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa, ed25519, padding
from cryptography.hazmat.primitives import hashes

from norhook.core.canonical import canonicalize
from norhook.core.encoding import b64url_decode
from norhook.core.hashing import sha256_bytes
from norhook.core.schema import Mode


# ---------------------------------------------------------------------
# Human Confirmation Validation
# ---------------------------------------------------------------------

def validate_human_confirmation(receipt):
    """
    Validates HUMAN_CONFIRMED mode integrity.

    Guarantees:
    - Human block exists
    - output_hash present
    - Temporal ordering correct
    - Signature verified against deterministic input
    """

    if receipt.mode != Mode.HUMAN_CONFIRMED:
        return True, None

    if receipt.human is None:
        return False, "Missing human block"

    if receipt.output_hash is None:
        return False, "Missing output_hash"

    if receipt.human.confirmed_at.tzinfo is None:
        return False, "Human confirmation timestamp must be timezone-aware"

    if receipt.human.confirmed_at > receipt.timestamp:
        return False, "Human confirmation occurs after receipt timestamp"

    try:
        public_key = serialization.load_pem_public_key(
            receipt.human.signature_public_key.encode("utf-8")
        )

        message = receipt.output_hash.encode("utf-8")
        signature = b64url_decode(receipt.human.signature)

        if isinstance(public_key, ed25519.Ed25519PublicKey):
            public_key.verify(signature, message)

        elif isinstance(public_key, rsa.RSAPublicKey):
            if public_key.key_size < 3072:
                return False, "Human RSA key too small"

            public_key.verify(
                signature,
                message,
                padding.PSS(
                    mgf=padding.MGF1(hashes.SHA256()),
                    salt_length=padding.PSS.MAX_LENGTH,
                ),
                hashes.SHA256(),
            )
        else:
            return False, "Unsupported human signature key type"

    except Exception:
        return False, "Invalid human signature"

    return True, None


# ---------------------------------------------------------------------
# Delegation Validation
# ---------------------------------------------------------------------

def validate_delegation(receipt, verification_time: datetime):
    """
    Validates DELEGATED mode integrity.

    Guarantees:
    - Delegation and action blocks exist
    - Delegation window valid
    - Action executed within delegation window
    - Delegation signature verified deterministically
    - Key strength enforcement
    """

    if receipt.mode != Mode.DELEGATED:
        return True, None

    if receipt.delegation is None or receipt.action is None:
        return False, "Delegation and action blocks required"

    delegation = receipt.delegation
    action = receipt.action

    if delegation.delegation_id != action.delegation_id:
        return False, "Delegation ID mismatch"

    if action.executed_at.tzinfo is None:
        return False, "Action timestamp must be timezone-aware"

    if not (delegation.valid_from <= action.executed_at <= delegation.valid_until):
        return False, "Action outside delegation validity window"

    if not (delegation.valid_from <= verification_time <= delegation.valid_until):
        return False, "Delegation expired at verification time"

    # Build deterministic delegation payload (exclude signature)
    delegation_payload = delegation.model_dump(mode="json")
    signature = delegation_payload.pop("signature")

    canonical_payload = canonicalize(delegation_payload)
    signature_bytes = b64url_decode(signature)

    try:
        public_key = serialization.load_pem_public_key(
            delegation.signature_public_key.encode("utf-8")
        )

        if isinstance(public_key, ed25519.Ed25519PublicKey):
            public_key.verify(signature_bytes, canonical_payload)

        elif isinstance(public_key, rsa.RSAPublicKey):
            if public_key.key_size < 3072:
                return False, "Delegation RSA key too small"

            public_key.verify(
                signature_bytes,
                canonical_payload,
                padding.PSS(
                    mgf=padding.MGF1(hashes.SHA256()),
                    salt_length=padding.PSS.MAX_LENGTH,
                ),
                hashes.SHA256(),
            )
        else:
            return False, "Unsupported delegation signature key type"

    except Exception:
        return False, "Invalid delegation signature"

    return True, None
