from dataclasses import dataclass, field
from typing import Optional, List, Literal


SeverityLevel = Literal["info", "low", "medium", "high", "critical"]


@dataclass(frozen=True)
class VerificationResult:
    """
    Immutable verification result.

    Designed for:
    - SIEM export
    - Compliance evidence reporting
    - Deterministic audit logging
    - Offline verification tooling
    """

    valid: bool
    reason: Optional[str] = None
    severity: SeverityLevel = "info"
    control_ids: List[str] = field(default_factory=list)

    def __post_init__(self):
        # Enforce severity discipline
        allowed = {"info", "low", "medium", "high", "critical"}
        if self.severity not in allowed:
            raise ValueError("Invalid severity level")

        # Enforce deterministic control ID ordering
        object.__setattr__(self, "control_ids", sorted(set(self.control_ids)))
