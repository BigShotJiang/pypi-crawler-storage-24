from dataclasses import dataclass
from typing import List

from norhook.core.schema import AIReceipt, Mode


@dataclass(frozen=True)
class PolicyResult:
    compliant: bool
    violations: List[str]


class PolicyEngine:
    """
    Structural governance validation engine.

    IMPORTANT:
        - This is NOT a dynamic policy framework.
        - This does NOT implement regulatory compliance.
        - This validates structural invariants only.

    Invariants:
        - Deterministic
        - Stateless
        - Schema-aligned
        - No external dependencies
        - No configuration drift
    """

    # ------------------------------------------------------------------
    # Evaluation
    # ------------------------------------------------------------------

    def evaluate(self, receipt: AIReceipt) -> PolicyResult:

        violations: List[str] = []

        # ------------------------------------------------------------------
        # Mode-Structure Alignment
        # ------------------------------------------------------------------

        if receipt.mode == Mode.DELEGATED:
            if receipt.delegation is None:
                violations.append("Missing delegation block")
            if receipt.action is None:
                violations.append("Missing delegated action block")

        if receipt.mode == Mode.HUMAN_CONFIRMED:
            if receipt.human is None:
                violations.append("Missing human confirmation block")

        # ------------------------------------------------------------------
        # Structural Chain Integrity (Optional)
        # ------------------------------------------------------------------

        # If previous_hash exists, ensure it is hex and correct length
        if receipt.previous_hash is not None:
            if not isinstance(receipt.previous_hash, str):
                violations.append("Invalid previous_hash type")
            elif len(receipt.previous_hash) != 64:
                violations.append("Invalid previous_hash length")

        # ------------------------------------------------------------------
        # Tenant Boundary Integrity (Optional)
        # ------------------------------------------------------------------

        if receipt.tenant_id is not None:
            if not isinstance(receipt.tenant_id, str):
                violations.append("Invalid tenant_id type")
            elif not receipt.tenant_id.strip():
                violations.append("Empty tenant_id")

        # ------------------------------------------------------------------
        # Nonce Enforcement
        # ------------------------------------------------------------------

        if not isinstance(receipt.nonce, str) or not receipt.nonce:
            violations.append("Invalid nonce")

        # ------------------------------------------------------------------
        # Final Result
        # ------------------------------------------------------------------

        return PolicyResult(
            compliant=len(violations) == 0,
            violations=violations,
        )
