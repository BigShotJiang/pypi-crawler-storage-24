from typing import Literal

from norhook.core.schema import AIReceipt, Mode


RiskLevel = Literal["informational", "low", "medium", "high"]


def derive_risk(receipt: AIReceipt) -> RiskLevel:
    """
    Deterministic structural risk classification.

    This is NOT a dynamic risk engine.
    It provides structural execution classification only.

    Invariants:
        - Pure function (no side effects)
        - Deterministic
        - Based solely on receipt structure
        - No policy drift
        - No runtime configuration
    """

    # ------------------------------------------------------------------
    # Delegated Mode
    # ------------------------------------------------------------------

    if receipt.mode == Mode.DELEGATED:

        # Delegated execution implies autonomous action
        # Risk elevated structurally
        return "medium"

    # ------------------------------------------------------------------
    # Human Confirmed Mode
    # ------------------------------------------------------------------

    if receipt.mode == Mode.HUMAN_CONFIRMED:

        # Human confirmation reduces structural autonomy risk
        return "low"

    # ------------------------------------------------------------------
    # Assistive Mode
    # ------------------------------------------------------------------

    if receipt.mode == Mode.ASSISTIVE:
        return "informational"

    # ------------------------------------------------------------------
    # Defensive Default
    # ------------------------------------------------------------------

    return "high"
