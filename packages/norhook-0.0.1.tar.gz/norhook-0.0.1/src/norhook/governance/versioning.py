from typing import Tuple

from norhook.core.schema import AIReceipt


# ------------------------------------------------------------------
# Supported Versions (Explicit, Deterministic)
# ------------------------------------------------------------------

SUPPORTED_PROTOCOL_VERSIONS = {"1.0"}
SUPPORTED_SCHEMA_VERSIONS = {"v1"}
SUPPORTED_RECEIPT_VERSIONS = {"1.0"}
SUPPORTED_CANONICALIZATION_VERSIONS = {"1.0"}
SUPPORTED_ALGORITHM_POLICY_VERSIONS = {"1.0"}


# ------------------------------------------------------------------
# Version Validation
# ------------------------------------------------------------------

def validate_versions(receipt: AIReceipt) -> Tuple[bool, str | None]:
    """
    Validates protocol, schema, receipt, canonicalization,
    and algorithm policy versions.

    This function enforces strict compatibility to prevent:
    - Silent forward drift
    - Downgrade attacks
    - Undefined cryptographic behavior
    """

    # ------------------------------------------------------------------
    # Protocol Version
    # ------------------------------------------------------------------

    if receipt.protocol_version not in SUPPORTED_PROTOCOL_VERSIONS:
        return False, "Unsupported protocol version"

    # ------------------------------------------------------------------
    # Schema Version
    # ------------------------------------------------------------------

    if receipt.schema_version not in SUPPORTED_SCHEMA_VERSIONS:
        return False, "Unsupported schema version"

    # ------------------------------------------------------------------
    # Receipt Version
    # ------------------------------------------------------------------

    if receipt.receipt_version not in SUPPORTED_RECEIPT_VERSIONS:
        return False, "Unsupported receipt version"

    # ------------------------------------------------------------------
    # Canonicalization Version
    # ------------------------------------------------------------------

    if receipt.canonicalization_version not in SUPPORTED_CANONICALIZATION_VERSIONS:
        return False, "Unsupported canonicalization version"

    # ------------------------------------------------------------------
    # Algorithm Policy Version
    # ------------------------------------------------------------------

    if receipt.algorithm_policy_version not in SUPPORTED_ALGORITHM_POLICY_VERSIONS:
        return False, "Unsupported algorithm policy version"

    return True, None
