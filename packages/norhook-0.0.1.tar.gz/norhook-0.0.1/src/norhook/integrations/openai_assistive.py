import os
from datetime import datetime, timezone
from openai import OpenAI

from norhook.core.receipt_builder import ReceiptBuilder
from norhook.core.schema import AIIdentity, Mode
from norhook.signing.ed25519 import Ed25519Signer # Or whatever signer you use
# from norhook.config.runtime import norhook_ENVIRONMENT # REMOVED: No global runtime

client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))

def assistive_llm_call(
    prompt: str,
    private_key_pem: bytes,
    issuer_name: str = "openai"
) -> dict:
    """
    Executes a real OpenAI LLM call and returns receipt.
    """
    # 1. Call OpenAI
    response = client.chat.completions.create(
        model="gpt-4-turbo",
        messages=[{"role": "user", "content": prompt}]
    )
    ai_output = response.choices[0].message.content

    # 2. Build Identity
    ai_identity = AIIdentity(
        issuer=issuer_name,
        model=response.model,
        version="v1" 
    )

    # 3. Create Receipt
    # Initialize signer & builder
    signer = Ed25519Signer(private_key_pem)
    builder = ReceiptBuilder(protocol_version="1.0", schema_version="v1")
    
    # In Assistive mode, we hash the output
    from norhook.core.hashing import sha256_bytes
    output_hash = sha256_bytes(ai_output.encode("utf-8"))

    receipt = builder.build(
        ai_identity=ai_identity,
        mode=Mode.ASSISTIVE,
        timestamp=datetime.now(timezone.utc),
        signer=signer,
        output_hash=output_hash
    )

    return {
        "output": ai_output,
        "receipt": receipt.model_dump(mode="json")
    }
