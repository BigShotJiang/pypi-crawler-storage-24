from abc import ABC, abstractmethod
from typing import Dict


class SignerError(Exception):
    """Raised when signer contract is violated."""


class Signer(ABC):
    """
    Abstract cryptographic signer interface.

    Design Guarantees:
    - Stateless signing contract
    - Deterministic public key exposure
    - Deterministic key_id derivation
    - Explicit algorithm declaration
    - No storage coupling
    - No SaaS logic
    """

    # ------------------------------------------------------------------
    # Signing
    # ------------------------------------------------------------------

    @abstractmethod
    def sign(self, payload: bytes) -> str:
        """
        Sign canonicalized payload.

        Payload MUST already be canonicalized bytes.
        Returns Base64URL-encoded signature.
        """
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Public Key Exposure
    # ------------------------------------------------------------------

    @abstractmethod
    def public_key_bytes(self) -> bytes:
        """
        Returns public key in deterministic PEM format.

        Must remain stable across process restarts.
        """
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Algorithm Declaration
    # ------------------------------------------------------------------

    @property
    @abstractmethod
    def algorithm_name(self) -> str:
        """
        Must match:
            - receipt.signature_algorithm
            - crypto_profile.signature

        Example values:
            - "ed25519"
            - "rsa-pss"
        """
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Crypto Profile Declaration
    # ------------------------------------------------------------------

    @property
    @abstractmethod
    def crypto_profile(self) -> Dict[str, str]:
        """
        Must contain:
            {
                "hash": "sha256",
                "signature": <algorithm_name>
            }

        Must remain deterministic.
        """
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Key Identity
    # ------------------------------------------------------------------

    @property
    @abstractmethod
    def key_id(self) -> str:
        """
        Deterministic key identifier.

        Must:
            - Be derived from public_key_bytes()
            - Use sha256
            - Be truncated consistently
            - Be collision-resistant

        Must match verifier derivation logic.
        """
        raise NotImplementedError

    # ------------------------------------------------------------------
    # Optional: Algorithm Policy Version
    # ------------------------------------------------------------------

    @property
    def algorithm_policy_version(self) -> str:
        """
        Optional algorithm lifecycle policy identifier.

        Defaults to "1.0" for backward compatibility.

        Used to support:
            - Crypto deprecation strategies
            - Compliance lifecycle documentation
            - Future algorithm migration

        Stateless by design.
        """
        return "1.0"
