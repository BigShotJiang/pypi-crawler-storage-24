from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives import serialization

from norhook.core.encoding import b64url_encode
from norhook.core.hashing import sha256_bytes
from .base import Signer, SignerError


MIN_KEY_ID_LENGTH = 16


class Ed25519Signer(Signer):
    """
    Deterministic Ed25519 signer.

    Guarantees:
    - Stateless signing
    - Deterministic PEM public key encoding
    - Deterministic key_id derivation
    - Strict payload discipline
    """

    def __init__(self, private_key_pem: bytes):

        if not isinstance(private_key_pem, (bytes, bytearray)):
            raise SignerError("Private key must be bytes")

        private_key = serialization.load_pem_private_key(
            private_key_pem,
            password=None,
        )

        if not isinstance(private_key, Ed25519PrivateKey):
            raise SignerError("Provided key is not Ed25519")

        self._private_key = private_key

    # ------------------------------------------------------------------
    # Signing
    # ------------------------------------------------------------------

    def sign(self, payload: bytes) -> str:

        if not isinstance(payload, (bytes, bytearray)):
            raise SignerError("Payload must be canonicalized bytes")

        signature = self._private_key.sign(payload)

        return b64url_encode(signature)

    # ------------------------------------------------------------------
    # Public Key Exposure
    # ------------------------------------------------------------------

    def public_key_bytes(self) -> bytes:
        """
        Deterministic PEM encoding of public key.
        """
        public_key = self._private_key.public_key()

        return public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        )

    # ------------------------------------------------------------------
    # Algorithm Declaration
    # ------------------------------------------------------------------

    @property
    def algorithm_name(self) -> str:
        return "ed25519"

    # ------------------------------------------------------------------
    # Crypto Profile
    # ------------------------------------------------------------------

    @property
    def crypto_profile(self) -> dict:
        return {
            "hash": "sha256",
            "signature": "ed25519",
        }

    # ------------------------------------------------------------------
    # Key Identity
    # ------------------------------------------------------------------

    @property
    def key_id(self) -> str:
        """
        Deterministic key identifier derived from public key.
        Must match verifier derivation logic.
        """
        derived = sha256_bytes(self.public_key_bytes())[:MIN_KEY_ID_LENGTH]

        if len(derived) < MIN_KEY_ID_LENGTH:
            raise SignerError("Derived key_id length insufficient")

        return derived
