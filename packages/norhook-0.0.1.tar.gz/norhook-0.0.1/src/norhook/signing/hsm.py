from typing import Any

from norhook.core.hashing import sha256_bytes
from .base import Signer, SignerError


MIN_KEY_ID_LENGTH = 16


class HSMSigner(Signer):
    """
    Hardware-backed signer adapter.

    Requirements for client:
        - sign(payload: bytes) -> str (Base64URL encoded)
        - public_key_bytes() -> bytes
        - algorithm_name (str)
        - crypto_profile (dict)
        - key_id (optional)

    This class enforces deterministic behavior
    while remaining storage-agnostic and stateless.
    """

    def __init__(self, client: Any):

        if client is None:
            raise SignerError("HSM client cannot be None")

        if not hasattr(client, "sign"):
            raise SignerError("HSM client must implement sign()")

        if not hasattr(client, "public_key_bytes"):
            raise SignerError("HSM client must implement public_key_bytes()")

        self._client = client

    # ------------------------------------------------------------------
    # Signing
    # ------------------------------------------------------------------

    def sign(self, payload: bytes) -> str:

        if not isinstance(payload, (bytes, bytearray)):
            raise SignerError("Payload must be canonicalized bytes")

        signature = self._client.sign(payload)

        if not isinstance(signature, str):
            raise SignerError("HSM sign() must return Base64URL string")

        return signature

    # ------------------------------------------------------------------
    # Public Key Exposure
    # ------------------------------------------------------------------

    def public_key_bytes(self) -> bytes:

        public_key = self._client.public_key_bytes()

        if not isinstance(public_key, (bytes, bytearray)):
            raise SignerError("public_key_bytes() must return bytes")

        return public_key

    # ------------------------------------------------------------------
    # Algorithm Declaration
    # ------------------------------------------------------------------

    @property
    def algorithm_name(self) -> str:

        algorithm = getattr(self._client, "algorithm_name", None)

        if not algorithm or not isinstance(algorithm, str):
            raise SignerError("HSM client must define algorithm_name")

        return algorithm

    # ------------------------------------------------------------------
    # Crypto Profile
    # ------------------------------------------------------------------

    @property
    def crypto_profile(self) -> dict:

        profile = getattr(self._client, "crypto_profile", None)

        if not isinstance(profile, dict):
            raise SignerError("HSM client must define crypto_profile dict")

        if "hash" not in profile or "signature" not in profile:
            raise SignerError("crypto_profile must include hash and signature")

        return profile

    # ------------------------------------------------------------------
    # Key Identity
    # ------------------------------------------------------------------

    @property
    def key_id(self) -> str:
        """
        Deterministic key identifier.
        If client provides key_id, validate it.
        Otherwise derive from public key.
        """

        provided = getattr(self._client, "key_id", None)

        if provided:

            if not isinstance(provided, str):
                raise SignerError("HSM client key_id must be string")

            if len(provided) < MIN_KEY_ID_LENGTH:
                raise SignerError("HSM client key_id too short")

            return provided

        # Deterministic fallback
        derived = sha256_bytes(self.public_key_bytes())[:MIN_KEY_ID_LENGTH]

        if len(derived) < MIN_KEY_ID_LENGTH:
            raise SignerError("Derived key_id length insufficient")

        return derived
