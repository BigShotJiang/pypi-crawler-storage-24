import json
from typing import Optional
from urllib.parse import urlparse

import requests

from norhook.core.schema import AIReceipt
from norhook.core.canonical import canonicalize


DEFAULT_TIMEOUT_SECONDS = 5


class WebhookError(Exception):
    pass


def send_webhook(
    receipt: AIReceipt,
    endpoint: str,
    api_key: Optional[str] = None,
    timeout: int = DEFAULT_TIMEOUT_SECONDS,
) -> None:
    """
    Deterministic webhook sender.

    Invariants:
        - Stateless
        - HTTPS enforced
        - Deterministic JSON serialization
        - No retries
        - No storage
        - No background jobs
        - No mutation of receipt
    """

    # ------------------------------------------------------------------
    # Endpoint Validation
    # ------------------------------------------------------------------

    parsed = urlparse(endpoint)

    if parsed.scheme.lower() != "https":
        raise WebhookError("Webhook endpoint must use HTTPS")

    if not parsed.netloc:
        raise WebhookError("Invalid webhook endpoint")

    # ------------------------------------------------------------------
    # Deterministic Serialization
    # ------------------------------------------------------------------

    # Convert receipt to dict using Pydantic
    receipt_dict = receipt.model_dump(mode="json")

    # Canonicalize for deterministic structure
    canonical_payload = canonicalize(receipt_dict)

    # Convert canonical bytes back to JSON string
    json_payload = json.loads(canonical_payload.decode("utf-8"))

    headers = {
        "Content-Type": "application/json",
    }

    if api_key:
        if not isinstance(api_key, str):
            raise WebhookError("API key must be string")
        headers["Authorization"] = f"Bearer {api_key}"

    # ------------------------------------------------------------------
    # Network Call
    # ------------------------------------------------------------------

    try:
        response = requests.post(
            endpoint,
            json=json_payload,
            headers=headers,
            timeout=timeout,
        )

        response.raise_for_status()

    except requests.RequestException as exc:
        raise WebhookError(f"Webhook delivery failed: {exc}") from exc
