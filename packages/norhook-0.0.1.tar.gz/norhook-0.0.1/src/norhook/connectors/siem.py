from typing import Dict

from norhook.core.schema import AIReceipt
from norhook.governance.risk import derive_risk


def format_for_siem(receipt: AIReceipt) -> Dict[str, object]:
    """
    Deterministic SIEM formatter.

    IMPORTANT:
        - Stateless
        - Schema-aligned
        - Vendor-agnostic
        - No network coupling
        - No storage coupling
        - No mutation of receipt
    """

    return {
        "event_type": "AI_GOVERNANCE_EVENT",
        "receipt_id": receipt.receipt_id,
        "protocol_version": receipt.protocol_version,
        "schema_version": receipt.schema_version,
        "receipt_version": receipt.receipt_version,
        "algorithm_policy_version": receipt.algorithm_policy_version,
        "tenant_id": receipt.tenant_id,
        "mode": receipt.mode.value,
        "issuer": receipt.ai.issuer,
        "model": receipt.ai.model,
        "model_version": receipt.ai.version,
        "timestamp": receipt.timestamp.isoformat(),
        "nonce": receipt.nonce,
        "previous_hash": receipt.previous_hash,
        "risk_level": derive_risk(receipt),
        "signature_algorithm": receipt.signature_algorithm,
        "key_id": receipt.key_id,
    }
