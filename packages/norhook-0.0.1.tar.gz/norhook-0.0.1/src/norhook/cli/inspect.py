import argparse
import json
import sys
from pathlib import Path

from norhook.verification.verifier import verify_receipt
from norhook.verification.result import VerificationResult


EXIT_SUCCESS = 0
EXIT_INVALID = 2
EXIT_ERROR = 3


def _load_json(path: Path) -> dict:
    try:
        with path.open("r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as exc:
        raise RuntimeError(f"Failed to load receipt JSON: {exc}") from exc


def _load_public_key(path: Path) -> bytes:
    try:
        with path.open("rb") as f:
            return f.read()
    except Exception as exc:
        raise RuntimeError(f"Failed to load public key: {exc}") from exc


def _print_result(result: VerificationResult) -> None:
    output = {
        "valid": result.valid,
        "severity": result.severity,
        "reason": result.reason,
        "control_ids": result.control_ids,
    }

    print(json.dumps(output, indent=2, sort_keys=True))


def main() -> None:

    parser = argparse.ArgumentParser(
        prog="NORHOOK-inspect",
        description="Offline verification tool for AIL receipts.",
    )

    parser.add_argument(
        "receipt",
        type=Path,
        help="Path to receipt JSON file",
    )

    parser.add_argument(
        "public_key",
        type=Path,
        help="Path to PEM-encoded public key",
    )

    args = parser.parse_args()

    try:
        receipt_dict = _load_json(args.receipt)
        public_key_bytes = _load_public_key(args.public_key)

        result = verify_receipt(receipt_dict, public_key_bytes)

        _print_result(result)

        if result.valid:
            sys.exit(EXIT_SUCCESS)

        sys.exit(EXIT_INVALID)

    except Exception as exc:
        print(
            json.dumps(
                {
                    "valid": False,
                    "severity": "critical",
                    "reason": str(exc),
                    "control_ids": [],
                },
                indent=2,
                sort_keys=True,
            )
        )
        sys.exit(EXIT_ERROR)


if __name__ == "__main__":
    main()
