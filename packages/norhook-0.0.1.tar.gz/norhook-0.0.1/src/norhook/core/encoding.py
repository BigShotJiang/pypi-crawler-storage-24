import base64
import re


class EncodingError(Exception):
    """Raised when Base64URL encoding/decoding fails validation."""


# Strict Base64URL character set (RFC 4648 URL-safe, no padding)
_B64URL_PATTERN = re.compile(r"^[A-Za-z0-9_-]*$")


def b64url_encode(data: bytes) -> str:
    """
    Strict Base64URL encode without padding.

    Guarantees:
    - URL-safe encoding
    - No '=' padding
    - ASCII output
    """

    if not isinstance(data, (bytes, bytearray)):
        raise EncodingError("b64url_encode expects bytes")

    encoded = base64.urlsafe_b64encode(data).rstrip(b"=")

    try:
        return encoded.decode("ascii")
    except Exception:
        raise EncodingError("Encoding produced non-ASCII output")


def b64url_decode(data: str) -> bytes:
    """
    Strict Base64URL decode with validation.

    Guarantees:
    - Only URL-safe characters allowed
    - No whitespace permitted
    - Padding normalized internally
    """

    if not isinstance(data, str):
        raise EncodingError("b64url_decode expects string")

    if not data:
        raise EncodingError("Base64URL input cannot be empty")

    if not _B64URL_PATTERN.fullmatch(data):
        raise EncodingError("Invalid Base64URL character detected")

    # Restore padding deterministically
    padding = "=" * (-len(data) % 4)

    try:
        return base64.urlsafe_b64decode(data + padding)
    except Exception:
        raise EncodingError("Invalid Base64URL encoding")
