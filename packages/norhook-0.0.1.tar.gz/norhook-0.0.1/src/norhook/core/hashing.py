import hashlib
from typing import Literal


class HashingError(Exception):
    """Raised when hashing constraints are violated."""


# Supported hash algorithms (explicit policy boundary)
SUPPORTED_HASH_ALGORITHMS = {"sha256"}


def sha256_bytes(data: bytes) -> str:
    """
    Deterministic SHA-256 hex digest.

    Guarantees:
    - Hex lowercase output
    - 64-character digest
    - Deterministic across platforms
    """

    if not isinstance(data, (bytes, bytearray)):
        raise HashingError("sha256_bytes expects bytes input")

    digest = hashlib.sha256(data).hexdigest()

    # Defensive invariant enforcement
    if len(digest) != 64:
        raise HashingError("Invalid SHA-256 digest length")

    return digest


def hash_bytes(data: bytes, algorithm: Literal["sha256"] = "sha256") -> str:
    """
    Controlled hash dispatch function.

    Designed for future algorithm agility without silent drift.
    """

    if algorithm not in SUPPORTED_HASH_ALGORITHMS:
        raise HashingError(f"Unsupported hash algorithm: {algorithm}")

    if algorithm == "sha256":
        return sha256_bytes(data)

    # Defensive fallback (should never reach here)
    raise HashingError("Hash dispatch failure")
