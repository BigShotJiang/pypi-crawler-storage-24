import json
from datetime import datetime, timezone
from typing import Any

# Canonical format version must change if structural rules change
CANONICALIZATION_VERSION = "1.0"

# Hard safety limits (enterprise-grade guardrails)
_MAX_RECURSION_DEPTH = 50
_MAX_KEYS_PER_OBJECT = 10_000


class CanonicalizationError(Exception):
    """Raised when canonicalization constraints are violated."""


def _normalize(obj: Any, *, _depth: int = 0) -> Any:
    if _depth > _MAX_RECURSION_DEPTH:
        raise CanonicalizationError("Maximum canonicalization depth exceeded")

    if isinstance(obj, float):
        raise CanonicalizationError("Floats are not permitted in canonical payloads")

    if isinstance(obj, datetime):
        if obj.tzinfo is None:
            raise CanonicalizationError("Datetime must be timezone-aware")
        return obj.astimezone(timezone.utc).isoformat()

    if isinstance(obj, dict):
        if len(obj) > _MAX_KEYS_PER_OBJECT:
            raise CanonicalizationError("Object exceeds maximum allowed keys")

        # Enforce string keys only
        for k in obj.keys():
            if not isinstance(k, str):
                raise CanonicalizationError("All dictionary keys must be strings")

        return {
            k: _normalize(v, _depth=_depth + 1)
            for k, v in obj.items()
        }

    if isinstance(obj, list):
        return [_normalize(i, _depth=_depth + 1) for i in obj]

    return obj


def canonicalize(data: dict) -> bytes:
    """
    Deterministic canonical JSON encoding.

    Guarantees:
    - Sorted keys
    - No floats
    - UTF-8 encoding
    - No whitespace variance
    - Timezone-normalized datetimes (UTC)
    - Deterministic structural representation
    """

    if not isinstance(data, dict):
        raise CanonicalizationError("Canonicalization requires dictionary input")

    normalized = _normalize(data)

    return json.dumps(
        normalized,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
    ).encode("utf-8")
