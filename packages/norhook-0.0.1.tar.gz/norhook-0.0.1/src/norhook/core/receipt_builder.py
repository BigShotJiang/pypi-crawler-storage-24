from datetime import datetime, timezone
from typing import Optional

from norhook.core.schema import (
    AIReceipt,
    AIIdentity,
    Mode,
    HumanConfirmation,
    DelegationScope,
    DelegatedAction,
    ToolCall,
    InterventionEvent,
    ArtifactAnchor,
    ExternalTimestamp,
    EventType,
)
from norhook.core.canonical import canonicalize, CANONICALIZATION_VERSION
from norhook.core.hashing import sha256_bytes
from norhook.signing.base import Signer


RECEIPT_VERSION = "1.0"
ALGORITHM_POLICY_VERSION = "1.0"


def _iso(dt: datetime) -> str:
    if dt.tzinfo is None:
        raise ValueError("Datetime must be timezone-aware")
    return dt.astimezone(timezone.utc).isoformat()


def _build_unsigned_payload(
    *,
    protocol_version: str,
    schema_version: str,
    receipt_version: str,
    algorithm_policy_version: str,
    timestamp: str,
    nonce: str,
    event_type: str,
    ai: dict,
    mode: str,
    crypto_profile: dict,
    signature_algorithm: str,
    key_id: str,
    receipt_id: Optional[str] = None,
    previous_hash: Optional[str] = None,
    tenant_id: Optional[str] = None,
    output_hash: Optional[str] = None,
    human: Optional[dict] = None,
    delegation: Optional[dict] = None,
    action: Optional[dict] = None,
    tool_call: Optional[dict] = None,
    intervention: Optional[dict] = None,
    artifact: Optional[dict] = None,
    external_timestamp: Optional[dict] = None,
):

    payload = {
        "protocol": "NORHOOK",
        "canonicalization_version": CANONICALIZATION_VERSION,
        "protocol_version": protocol_version,
        "schema_version": schema_version,
        "receipt_version": receipt_version,
        "algorithm_policy_version": algorithm_policy_version,
        "timestamp": timestamp,
        "nonce": nonce,
        "event_type": event_type,
        "ai": ai,
        "mode": mode,
        "crypto_profile": crypto_profile,
        "signature_algorithm": signature_algorithm,
        "key_id": key_id,
    }

    if tenant_id:
        payload["tenant_id"] = tenant_id

    if previous_hash:
        payload["previous_hash"] = previous_hash

    if output_hash:
        payload["output_hash"] = output_hash

    if human:
        payload["human"] = human

    if delegation:
        payload["delegation"] = delegation

    if action:
        payload["action"] = action

    if tool_call:
        payload["tool_call"] = tool_call

    if intervention:
        payload["intervention"] = intervention

    if artifact:
        payload["artifact"] = artifact

    if external_timestamp:
        payload["external_timestamp"] = external_timestamp

    if receipt_id:
        payload["receipt_id"] = receipt_id

    return payload


class ReceiptBuilder:

    def __init__(self, protocol_version: str, schema_version: str):
        self.protocol_version = protocol_version
        self.schema_version = schema_version

    def build(
        self,
        *,
        ai_identity: AIIdentity,
        mode: Mode,
        event_type: EventType,
        timestamp: datetime,
        nonce: str,
        signer: Signer,
        output_hash: Optional[str] = None,
        human: Optional[HumanConfirmation] = None,
        delegation: Optional[DelegationScope] = None,
        action: Optional[DelegatedAction] = None,
        tool_call: Optional[ToolCall] = None,
        intervention: Optional[InterventionEvent] = None,
        artifact: Optional[ArtifactAnchor] = None,
        previous_hash: Optional[str] = None,
        tenant_id: Optional[str] = None,
        external_timestamp: Optional[ExternalTimestamp] = None,
    ) -> AIReceipt:

        if not nonce:
            raise ValueError("Nonce is mandatory")

        if not isinstance(event_type, EventType):
            raise ValueError("Invalid event_type")

        crypto_profile = signer.crypto_profile
        signature_algorithm = signer.algorithm_name
        key_id = signer.key_id

        # ---------------------------------------------------------
        # Step 1: Build Base Payload (without receipt_id)
        # ---------------------------------------------------------
        base_payload = _build_unsigned_payload(
            protocol_version=self.protocol_version,
            schema_version=self.schema_version,
            receipt_version=RECEIPT_VERSION,
            algorithm_policy_version=ALGORITHM_POLICY_VERSION,
            timestamp=_iso(timestamp),
            nonce=nonce,
            event_type=event_type.value,
            ai=ai_identity.model_dump(mode="json"),
            mode=mode.value,
            crypto_profile=crypto_profile,
            signature_algorithm=signature_algorithm,
            key_id=key_id,
            previous_hash=previous_hash,
            tenant_id=tenant_id,
            output_hash=output_hash,
            human=human.model_dump(mode="json") if human else None,
            delegation=delegation.model_dump(mode="json") if delegation else None,
            action=action.model_dump(mode="json") if action else None,
            tool_call=tool_call.model_dump(mode="json") if tool_call else None,
            intervention=intervention.model_dump(mode="json") if intervention else None,
            artifact=artifact.model_dump(mode="json") if artifact else None,
            external_timestamp=external_timestamp.model_dump(mode="json")
            if external_timestamp
            else None,
        )

        receipt_id = sha256_bytes(canonicalize(base_payload))

        # ---------------------------------------------------------
        # Step 2: Build Final Payload (with receipt_id)
        # ---------------------------------------------------------
        final_payload = _build_unsigned_payload(
            protocol_version=self.protocol_version,
            schema_version=self.schema_version,
            receipt_version=RECEIPT_VERSION,
            algorithm_policy_version=ALGORITHM_POLICY_VERSION,
            timestamp=_iso(timestamp),
            nonce=nonce,
            event_type=event_type.value,
            ai=ai_identity.model_dump(mode="json"),
            mode=mode.value,
            crypto_profile=crypto_profile,
            signature_algorithm=signature_algorithm,
            key_id=key_id,
            receipt_id=receipt_id,
            previous_hash=previous_hash,
            tenant_id=tenant_id,
            output_hash=output_hash,
            human=human.model_dump(mode="json") if human else None,
            delegation=delegation.model_dump(mode="json") if delegation else None,
            action=action.model_dump(mode="json") if action else None,
            tool_call=tool_call.model_dump(mode="json") if tool_call else None,
            intervention=intervention.model_dump(mode="json") if intervention else None,
            artifact=artifact.model_dump(mode="json") if artifact else None,
            external_timestamp=external_timestamp.model_dump(mode="json")
            if external_timestamp
            else None,
        )

        canonical_final = canonicalize(final_payload)
        signature = signer.sign(canonical_final)
        receipt_hash = sha256_bytes(canonical_final)

        final_payload["signature"] = signature
        final_payload["receipt_hash"] = receipt_hash

        return AIReceipt(**final_payload)
