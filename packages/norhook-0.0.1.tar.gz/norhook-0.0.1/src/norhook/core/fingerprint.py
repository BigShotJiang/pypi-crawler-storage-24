from typing import Dict, Any

from norhook.core.hashing import sha256_bytes
from norhook.core.canonical import canonicalize
from norhook.core.schema import AIReceipt


class FingerprintError(Exception):
    """Raised when fingerprint derivation fails."""


def _strip_fields(data: Dict[str, Any], exclude: set[str]) -> Dict[str, Any]:
    """
    Returns a shallow copy of dictionary excluding specified fields.
    Deterministic exclusion boundary for fingerprint derivation.
    """
    return {k: v for k, v in data.items() if k not in exclude}


def receipt_fingerprint(receipt_dict: dict) -> str:
    """
    Stable replay detection fingerprint.

    Includes full receipt including signature.
    Used strictly for replay detection.
    """

    if not isinstance(receipt_dict, dict):
        raise FingerprintError("receipt_fingerprint expects dictionary input")

    return sha256_bytes(canonicalize(receipt_dict))


def payload_fingerprint(receipt: AIReceipt) -> str:
    """
    Deterministic fingerprint of the unsigned payload.

    Explicitly excludes:
    - signature
    - receipt_hash

    Includes:
    - nonce
    - event_type
    - tenant_id
    - previous_hash
    - tool_call
    - intervention
    - artifact
    - external_timestamp
    - crypto_profile
    - algorithm_policy_version

    Designed for:
    - Transparency logs
    - Merkle tree anchoring
    - Cross-system audit integrity
    """

    if not isinstance(receipt, AIReceipt):
        raise FingerprintError("payload_fingerprint expects AIReceipt instance")

    # Convert full receipt to deterministic JSON representation
    receipt_dict = receipt.model_dump(mode="json")

    # Explicitly remove fields that must NOT affect payload fingerprint
    stripped = _strip_fields(
        receipt_dict,
        exclude={"signature", "receipt_hash"},
    )

    return sha256_bytes(canonicalize(stripped))
