from enum import Enum
from typing import Optional
from datetime import datetime
from pydantic import BaseModel, Field, model_validator


# ---------------------------------------------------------------------
# Core Enums
# ---------------------------------------------------------------------

class Mode(str, Enum):
    ASSISTIVE = "assistive"
    HUMAN_CONFIRMED = "human-confirmed"
    DELEGATED = "delegated"


class EventType(str, Enum):
    EXECUTION = "execution"
    TOOL_CALL = "tool-call"
    INTERVENTION = "intervention"
    ARTIFACT = "artifact"


# ---------------------------------------------------------------------
# Cryptographic Profile
# ---------------------------------------------------------------------

class CryptoProfile(BaseModel):
    hash: str
    signature: str


# ---------------------------------------------------------------------
# Identity
# ---------------------------------------------------------------------

class AIIdentity(BaseModel):
    issuer: str
    model: str
    version: str


# ---------------------------------------------------------------------
# Human Confirmation
# ---------------------------------------------------------------------

class HumanConfirmation(BaseModel):
    actor_id: str
    signature: str
    signature_public_key: str
    confirmed_at: datetime

    @model_validator(mode="after")
    def validate_timezone(self):
        if self.confirmed_at.tzinfo is None:
            raise ValueError("confirmed_at must be timezone-aware")
        return self


# ---------------------------------------------------------------------
# Delegation
# ---------------------------------------------------------------------

class DelegationScope(BaseModel):
    delegation_id: str
    actor_id: str
    scope: str
    valid_from: datetime
    valid_until: datetime
    signature: str
    signature_public_key: str

    @model_validator(mode="after")
    def validate_window(self):
        if self.valid_from.tzinfo is None or self.valid_until.tzinfo is None:
            raise ValueError("Delegation timestamps must be timezone-aware")
        if self.valid_from >= self.valid_until:
            raise ValueError("Delegation valid_from must be before valid_until")
        return self


class DelegatedAction(BaseModel):
    delegation_id: str
    action_hash: str
    executed_at: datetime

    @model_validator(mode="after")
    def validate_timezone(self):
        if self.executed_at.tzinfo is None:
            raise ValueError("executed_at must be timezone-aware")
        return self


# ---------------------------------------------------------------------
# Tool Call Block (AIUC relevance)
# ---------------------------------------------------------------------

class ToolCall(BaseModel):
    tool_name: str
    input_hash: str
    output_hash: Optional[str] = None
    executed_at: datetime

    @model_validator(mode="after")
    def validate_timezone(self):
        if self.executed_at.tzinfo is None:
            raise ValueError("tool_call executed_at must be timezone-aware")
        return self


# ---------------------------------------------------------------------
# Intervention Block (EU Article 14 relevance)
# ---------------------------------------------------------------------

class InterventionEvent(BaseModel):
    actor_id: str
    reason: str
    occurred_at: datetime

    @model_validator(mode="after")
    def validate_timezone(self):
        if self.occurred_at.tzinfo is None:
            raise ValueError("intervention occurred_at must be timezone-aware")
        return self


# ---------------------------------------------------------------------
# Artifact Anchoring (ISO relevance)
# ---------------------------------------------------------------------

class ArtifactAnchor(BaseModel):
    artifact_id: str
    artifact_hash: str
    artifact_type: str


# ---------------------------------------------------------------------
# External Timestamp (Trusted Time Anchoring)
# ---------------------------------------------------------------------

class ExternalTimestamp(BaseModel):
    source: str
    anchored_at: datetime
    proof: Optional[str] = None

    @model_validator(mode="after")
    def validate_timezone(self):
        if self.anchored_at.tzinfo is None:
            raise ValueError("external_timestamp anchored_at must be timezone-aware")
        return self


# ---------------------------------------------------------------------
# AI Receipt (Enterprise Structural Core)
# ---------------------------------------------------------------------

class AIReceipt(BaseModel):

    # Protocol
    protocol: str = Field(default="NORHOOK")

    canonicalization_version: str
    protocol_version: str
    schema_version: str
    receipt_version: str
    algorithm_policy_version: str

    # Deterministic Identity
    receipt_id: str
    receipt_hash: str
    key_id: str
    nonce: str
    event_type: EventType

    # Time
    timestamp: datetime
    external_timestamp: Optional[ExternalTimestamp] = None

    # Identity
    ai: AIIdentity
    tenant_id: Optional[str] = None

    # Ledger
    previous_hash: Optional[str] = None

    # Mode
    mode: Mode

    # Output / Actions
    output_hash: Optional[str] = None
    human: Optional[HumanConfirmation] = None
    delegation: Optional[DelegationScope] = None
    action: Optional[DelegatedAction] = None
    tool_call: Optional[ToolCall] = None
    intervention: Optional[InterventionEvent] = None
    artifact: Optional[ArtifactAnchor] = None

    # Crypto
    crypto_profile: CryptoProfile
    signature_algorithm: str
    signature: str

    # -----------------------------------------------------------------
    # Structural Integrity Enforcement
    # -----------------------------------------------------------------

    @model_validator(mode="after")
    def validate_integrity(self):

        if self.protocol != "NORHOOK":
            raise ValueError("Invalid protocol identifier")

        if self.timestamp.tzinfo is None:
            raise ValueError("Receipt timestamp must be timezone-aware")

        if not self.nonce:
            raise ValueError("Nonce is mandatory")

        if len(self.key_id) < 16:
            raise ValueError("key_id length insufficient")

        if self.signature_algorithm != self.crypto_profile.signature:
            raise ValueError("Signature algorithm mismatch")

        if self.crypto_profile.hash != "sha256":
            raise ValueError("Unsupported hash algorithm")

        # Mode constraints
        if self.mode == Mode.HUMAN_CONFIRMED and not self.human:
            raise ValueError("Human block required for human-confirmed mode")

        if self.mode == Mode.DELEGATED and (not self.delegation or not self.action):
            raise ValueError("Delegation and action required for delegated mode")

        # EventType gating
        if self.event_type == EventType.TOOL_CALL and not self.tool_call:
            raise ValueError("tool_call block required for tool-call event")

        if self.event_type == EventType.INTERVENTION and not self.intervention:
            raise ValueError("intervention block required for intervention event")

        if self.event_type == EventType.ARTIFACT and not self.artifact:
            raise ValueError("artifact block required for artifact event")

        return self
