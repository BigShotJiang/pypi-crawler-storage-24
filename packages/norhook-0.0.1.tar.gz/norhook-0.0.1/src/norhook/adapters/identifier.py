import re
from typing import Optional


IDENTIFIER_PREFIX = "norhook"
IDENTIFIER_VERSION = "v1"
RECEIPT_ID_PATTERN = re.compile(r"^[a-f0-9]{64}$")


class IdentifierError(Exception):
    pass


def generate_reference(
    receipt_id: str,
    tenant_id: Optional[str] = None,
) -> str:
    """
    Generates a deterministic Norhook reference identifier.

    Format:
        norhook:v1[:tenant_id]:<receipt_id>

    Invariants:
        - Stateless
        - Deterministic
        - No external dependency
        - No storage coupling
        - Validated receipt_id
        - Optional tenant isolation
    """

    # ------------------------------------------------------------------
    # Receipt ID Validation
    # ------------------------------------------------------------------

    if not isinstance(receipt_id, str):
        raise IdentifierError("receipt_id must be string")

    if not RECEIPT_ID_PATTERN.fullmatch(receipt_id):
        raise IdentifierError("receipt_id must be 64-char lowercase hex")

    # ------------------------------------------------------------------
    # Tenant Validation (Optional)
    # ------------------------------------------------------------------

    if tenant_id is not None:
        if not isinstance(tenant_id, str):
            raise IdentifierError("tenant_id must be string")

        if not tenant_id.strip():
            raise IdentifierError("tenant_id cannot be empty")

        return f"{IDENTIFIER_PREFIX}:{IDENTIFIER_VERSION}:{tenant_id}:{receipt_id}"

    return f"{IDENTIFIER_PREFIX}:{IDENTIFIER_VERSION}:{receipt_id}"
