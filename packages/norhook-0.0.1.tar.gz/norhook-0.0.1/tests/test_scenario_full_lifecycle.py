import pytest
from datetime import datetime, timezone
from typing import Set

from norhook.core.receipt_builder import ReceiptBuilder
from norhook.core.schema import AIIdentity, Mode, EventType
from norhook.signing.ed25519 import Ed25519Signer
from norhook.verification.verifier import verify_receipt
from norhook.verification.interfaces import ReplayChecker


# -------------------------------------------------------------------
# Simple In-Memory Replay Checker (Simulated Integration)
# -------------------------------------------------------------------

class InMemoryReplayChecker:
    def __init__(self):
        self._seen: Set[str] = set()

    def is_replayed(self, fingerprint: str) -> bool:
        if fingerprint in self._seen:
            return True
        self._seen.add(fingerprint)
        return False


# -------------------------------------------------------------------
# Full Lifecycle Scenario
# -------------------------------------------------------------------

def test_full_lifecycle_chain_replay_revocation(ed25519_keys):
    """
    Simulates:
    - Sequential receipt chain
    - previous_hash linkage
    - Replay detection
    - Multi-key allowlist
    - Key revocation lifecycle
    """

    priv_pem, pub_pem = ed25519_keys
    signer = Ed25519Signer(priv_pem)

    builder = ReceiptBuilder("1.0", "v1")

    fixed_time = datetime(2025, 1, 1, tzinfo=timezone.utc)

    # -------------------------------------------------------------
    # 1️⃣ Generate First Receipt (Chain Root)
    # -------------------------------------------------------------

    r1 = builder.build(
        ai_identity=AIIdentity(issuer="enterprise", model="agent-v1", version="1"),
        mode=Mode.ASSISTIVE,
        event_type=EventType.EXECUTION,
        timestamp=fixed_time,
        nonce="nonce-1",
        signer=signer,
    )

    # -------------------------------------------------------------
    # 2️⃣ Generate Second Receipt Linked to First
    # -------------------------------------------------------------

    r2 = builder.build(
        ai_identity=AIIdentity(issuer="enterprise", model="agent-v1", version="1"),
        mode=Mode.ASSISTIVE,
        event_type=EventType.EXECUTION,
        timestamp=fixed_time,
        nonce="nonce-2",
        previous_hash=r1.receipt_hash,
        signer=signer,
    )

    # -------------------------------------------------------------
    # 3️⃣ Verify Chain Integrity
    # -------------------------------------------------------------

    replay_checker = InMemoryReplayChecker()

    result1 = verify_receipt(
        r1.model_dump(mode="json"),
        pub_pem,
        replay_checker=replay_checker,
        trusted_public_keys=[pub_pem],
    )

    assert result1.valid

    result2 = verify_receipt(
        r2.model_dump(mode="json"),
        pub_pem,
        replay_checker=replay_checker,
        trusted_public_keys=[pub_pem],
    )

    assert result2.valid
    assert r2.previous_hash == r1.receipt_hash

    # -------------------------------------------------------------
    # 4️⃣ Replay Attack Attempt
    # -------------------------------------------------------------

    replay_attempt = verify_receipt(
        r1.model_dump(mode="json"),
        pub_pem,
        replay_checker=replay_checker,
        trusted_public_keys=[pub_pem],
    )

    assert not replay_attempt.valid
    assert replay_attempt.reason == "Replay detected"

    # -------------------------------------------------------------
    # 5️⃣ Revocation Lifecycle Simulation
    # -------------------------------------------------------------

    revoked = [r1.key_id]

    revoked_result = verify_receipt(
        r1.model_dump(mode="json"),
        pub_pem,
        revoked_key_ids=revoked,
    )

    assert not revoked_result.valid
    assert revoked_result.reason == "Signing key revoked"
