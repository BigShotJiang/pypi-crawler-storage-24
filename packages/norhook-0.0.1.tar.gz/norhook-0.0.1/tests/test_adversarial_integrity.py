from datetime import datetime, timezone

from norhook.core.receipt_builder import ReceiptBuilder
from norhook.core.schema import AIIdentity, Mode, EventType
from norhook.signing.ed25519 import Ed25519Signer
from norhook.verification.verifier import verify_receipt


def build_valid_receipt(private_pem, nonce):
    signer = Ed25519Signer(private_pem)
    builder = ReceiptBuilder("1.0", "v1")

    receipt = builder.build(
        ai_identity=AIIdentity(issuer="x", model="y", version="1"),
        mode=Mode.ASSISTIVE,
        event_type=EventType.EXECUTION,
        timestamp=datetime.now(timezone.utc),
        nonce=nonce,
        signer=signer,
    )
    return receipt


def test_receipt_id_tampering_detected(ed25519_keys, fixed_nonce):
    private_pem, public_pem = ed25519_keys
    receipt = build_valid_receipt(private_pem, fixed_nonce)

    broken = receipt.model_dump(mode="json")
    broken["receipt_id"] = broken["receipt_id"][:-4]

    result = verify_receipt(broken, public_pem)
    assert not result.valid


def test_receipt_hash_tampering_detected(ed25519_keys, fixed_nonce):
    private_pem, public_pem = ed25519_keys
    receipt = build_valid_receipt(private_pem, fixed_nonce)

    broken = receipt.model_dump(mode="json")
    broken["receipt_hash"] = broken["receipt_hash"][:-4]

    result = verify_receipt(broken, public_pem)
    assert not result.valid


def test_signature_tampering_detected(ed25519_keys, fixed_nonce):
    private_pem, public_pem = ed25519_keys
    receipt = build_valid_receipt(private_pem, fixed_nonce)

    broken = receipt.model_dump(mode="json")
    broken["signature"] = broken["signature"][:-4]

    result = verify_receipt(broken, public_pem)
    assert not result.valid


def test_nonce_tampering_detected(ed25519_keys, fixed_nonce):
    private_pem, public_pem = ed25519_keys
    receipt = build_valid_receipt(private_pem, fixed_nonce)

    broken = receipt.model_dump(mode="json")
    broken["nonce"] = "evil-nonce"

    result = verify_receipt(broken, public_pem)
    assert not result.valid


def test_algorithm_policy_version_tampering_detected(ed25519_keys, fixed_nonce):
    private_pem, public_pem = ed25519_keys
    receipt = build_valid_receipt(private_pem, fixed_nonce)

    broken = receipt.model_dump(mode="json")
    broken["algorithm_policy_version"] = "999.0"

    result = verify_receipt(broken, public_pem)
    assert not result.valid


def test_canonicalization_version_tampering_detected(ed25519_keys, fixed_nonce):
    private_pem, public_pem = ed25519_keys
    receipt = build_valid_receipt(private_pem, fixed_nonce)

    broken = receipt.model_dump(mode="json")
    broken["canonicalization_version"] = "999.0"

    result = verify_receipt(broken, public_pem)
    assert not result.valid
