from datetime import datetime, timezone

from norhook.core.receipt_builder import ReceiptBuilder
from norhook.core.schema import AIIdentity, Mode, EventType
from norhook.signing.ed25519 import Ed25519Signer
from norhook.core.canonical import canonicalize
from norhook.core.hashing import sha256_bytes
from norhook.verification.verifier import verify_receipt


def test_basic_assistive_receipt_structure(ed25519_keys, fixed_nonce):
    private_pem, public_pem = ed25519_keys
    signer = Ed25519Signer(private_pem)

    builder = ReceiptBuilder("1.0", "v1")

    timestamp = datetime.now(timezone.utc)

    receipt = builder.build(
        ai_identity=AIIdentity(issuer="test", model="gpt-x", version="1"),
        mode=Mode.ASSISTIVE,
        event_type=EventType.EXECUTION,
        timestamp=timestamp,
        nonce=fixed_nonce,
        signer=signer,
    )

    # -----------------------------
    # Core Structural Assertions
    # -----------------------------
    assert receipt.protocol == "NORHOOK"
    assert receipt.nonce == fixed_nonce
    assert receipt.event_type == EventType.EXECUTION

    assert receipt.receipt_id is not None
    assert receipt.receipt_hash is not None
    assert receipt.signature is not None

    # -----------------------------
    # Crypto Profile Integrity
    # -----------------------------
    assert receipt.crypto_profile.hash == "sha256"
    assert receipt.signature_algorithm == receipt.crypto_profile.signature

    # -----------------------------
    # Key Integrity
    # -----------------------------
    assert len(receipt.key_id) >= 16

    # -----------------------------
    # Version Discipline
    # -----------------------------
    assert receipt.protocol_version == "1.0"
    assert receipt.schema_version == "v1"
    assert receipt.receipt_version == "1.0"
    assert receipt.algorithm_policy_version == "1.0"
    assert receipt.canonicalization_version == "1.0"

    # -----------------------------
    # Deterministic Hash Integrity
    # Recompute receipt_hash
    # -----------------------------
    payload = receipt.model_dump(mode="json")
    signature = payload.pop("signature")
    receipt_hash = payload.pop("receipt_hash")

    result = verify_receipt(receipt.model_dump(mode="json"), public_pem)
    assert result.valid
