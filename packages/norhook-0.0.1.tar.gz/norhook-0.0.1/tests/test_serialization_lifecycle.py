import json
from datetime import datetime, timezone

from norhook.core.receipt_builder import ReceiptBuilder
from norhook.core.schema import AIIdentity, Mode, EventType
from norhook.signing.ed25519 import Ed25519Signer
from norhook.verification.verifier import verify_receipt


def test_full_serialization_loop(ed25519_keys):
    """
    Simulates writing to disk and reading back.
    Ensures:
    - Datetime survives JSON roundtrip
    - Signature remains valid
    - Canonicalization stable after json.loads
    """

    priv_pem, pub_pem = ed25519_keys
    signer = Ed25519Signer(priv_pem)

    builder = ReceiptBuilder("1.0", "v1")

    fixed_timestamp = datetime(2025, 1, 1, tzinfo=timezone.utc)

    original_receipt = builder.build(
        ai_identity=AIIdentity(
            issuer="openai",
            model="gpt-4",
            version="preview"
        ),
        mode=Mode.ASSISTIVE,
        event_type=EventType.EXECUTION,
        timestamp=fixed_timestamp,
        nonce="serialization-test-nonce",
        signer=signer,
    )

    # 1. Dump to JSON string (simulating disk/network)
    json_str = original_receipt.model_dump_json()

    # 2. Load back using standard json
    loaded_dict = json.loads(json_str)

    # 3. Verify round-tripped structure
    result = verify_receipt(loaded_dict, pub_pem)

    assert result.valid
    assert loaded_dict["signature"] == original_receipt.signature
    assert loaded_dict["receipt_id"] == original_receipt.receipt_id
