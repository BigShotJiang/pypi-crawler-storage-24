from datetime import datetime, timezone

from norhook.core.receipt_builder import ReceiptBuilder
from norhook.core.schema import AIIdentity, Mode, EventType
from norhook.signing.ed25519 import Ed25519Signer


def test_receipt_id_stable_for_same_input(ed25519_keys):
    private_pem, _ = ed25519_keys
    signer = Ed25519Signer(private_pem)

    builder = ReceiptBuilder("1.0", "v1")
    timestamp = datetime(2025, 1, 1, tzinfo=timezone.utc)

    r1 = builder.build(
        ai_identity=AIIdentity(issuer="x", model="y", version="1"),
        mode=Mode.ASSISTIVE,
        event_type=EventType.EXECUTION,
        timestamp=timestamp,
        nonce="deterministic-nonce",
        signer=signer,
    )

    r2 = builder.build(
        ai_identity=AIIdentity(issuer="x", model="y", version="1"),
        mode=Mode.ASSISTIVE,
        event_type=EventType.EXECUTION,
        timestamp=timestamp,
        nonce="deterministic-nonce",
        signer=signer,
    )

    assert r1.receipt_id == r2.receipt_id


def test_receipt_id_changes_with_nonce(ed25519_keys):
    private_pem, _ = ed25519_keys
    signer = Ed25519Signer(private_pem)

    builder = ReceiptBuilder("1.0", "v1")
    timestamp = datetime(2025, 1, 1, tzinfo=timezone.utc)

    r1 = builder.build(
        ai_identity=AIIdentity(issuer="x", model="y", version="1"),
        mode=Mode.ASSISTIVE,
        event_type=EventType.EXECUTION,
        timestamp=timestamp,
        nonce="nonce-1",
        signer=signer,
    )

    r2 = builder.build(
        ai_identity=AIIdentity(issuer="x", model="y", version="1"),
        mode=Mode.ASSISTIVE,
        event_type=EventType.EXECUTION,
        timestamp=timestamp,
        nonce="nonce-2",
        signer=signer,
    )

    assert r1.receipt_id != r2.receipt_id
