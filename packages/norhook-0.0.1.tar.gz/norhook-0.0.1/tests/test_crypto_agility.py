from datetime import datetime, timezone
import pytest

from norhook.core.receipt_builder import ReceiptBuilder
from norhook.core.schema import AIIdentity, Mode, EventType
from norhook.signing.rsa_pss import RSAPSSSigner
from norhook.signing.base import SignerError
from norhook.verification.verifier import verify_receipt


def test_rsa_4096_signing_verification(rsa_4096_keys, fixed_nonce):
    """
    Ensures RSA-4096 works correctly with:
    - PSS padding
    - SHA256
    - Key size enforcement
    - Deterministic key_id derivation
    """

    priv_pem, pub_pem = rsa_4096_keys

    signer = RSAPSSSigner(priv_pem)
    builder = ReceiptBuilder("1.0", "v1")

    receipt = builder.build(
        ai_identity=AIIdentity(issuer="bank-legacy", model="old-v1", version="1"),
        mode=Mode.ASSISTIVE,
        event_type=EventType.EXECUTION,
        timestamp=datetime.now(timezone.utc),
        nonce=fixed_nonce,
        signer=signer,
    )

    result = verify_receipt(receipt.model_dump(mode="json"), pub_pem)

    assert result.valid
    assert receipt.crypto_profile.signature == "rsa-pss"
    assert len(receipt.key_id) >= 16


def test_rsa_2048_rejected(rsa_2048_keys):
    """
    Ensures RSA < 3072 is rejected at signer level.
    """

    priv_pem, _ = rsa_2048_keys

    with pytest.raises(SignerError):
        RSAPSSSigner(priv_pem)
