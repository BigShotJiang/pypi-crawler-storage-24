import pytest
from datetime import datetime, timedelta, timezone
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives import serialization
from pydantic import ValidationError

from norhook.core.receipt_builder import ReceiptBuilder
from norhook.core.schema import (
    AIIdentity,
    Mode,
    HumanConfirmation,
    DelegationScope,
    DelegatedAction,
    EventType,
)
from norhook.signing.ed25519 import Ed25519Signer
from norhook.verification.verifier import verify_receipt
from norhook.core.hashing import sha256_bytes
from norhook.core.canonical import canonicalize


def generate_extra_keypair():
    private = Ed25519PrivateKey.generate()
    private_pem = private.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )
    public_pem = private.public_key().public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    )
    return private_pem, public_pem


def test_human_signature_binding(ed25519_keys, fixed_nonce):
    system_priv, system_pub = ed25519_keys
    human_priv, human_pub = generate_extra_keypair()

    signer = Ed25519Signer(system_priv)
    builder = ReceiptBuilder("1.0", "v1")

    output_hash = sha256_bytes(b"approve-loan")
    ts = datetime.now(timezone.utc)

    human_signature = Ed25519Signer(human_priv).sign(
        output_hash.encode("utf-8")
    )

    receipt = builder.build(
        ai_identity=AIIdentity(issuer="x", model="y", version="1"),
        mode=Mode.HUMAN_CONFIRMED,
        event_type=EventType.EXECUTION,
        timestamp=ts,
        nonce=fixed_nonce,
        signer=signer,
        output_hash=output_hash,
        human=HumanConfirmation(
            actor_id="user-1",
            signature=human_signature,
            signature_public_key=human_pub.decode(),
            confirmed_at=ts,
        ),
    )

    result = verify_receipt(receipt.model_dump(mode="json"), system_pub)
    assert result.valid


def test_delegation_signature_validation(ed25519_keys, fixed_nonce):
    system_priv, system_pub = ed25519_keys
    human_priv, human_pub = generate_extra_keypair()

    signer = Ed25519Signer(system_priv)
    builder = ReceiptBuilder("1.0", "v1")

    delegation_id = sha256_bytes(b"delegation-1")
    ts = datetime.now(timezone.utc)

    valid_from = ts
    valid_until = ts + timedelta(days=1)

    # Build temp scope to match verifier canonicalization exactly
    temp_scope = DelegationScope(
        delegation_id=delegation_id,
        actor_id="admin",
        scope="refund <= 500",
        valid_from=valid_from,
        valid_until=valid_until,
        signature="placeholder",
        signature_public_key=human_pub.decode(),
    )

    delegation_payload = temp_scope.model_dump(mode="json")
    delegation_payload.pop("signature")

    delegation_signature = Ed25519Signer(human_priv).sign(
        canonicalize(delegation_payload)
    )

    receipt = builder.build(
        ai_identity=AIIdentity(issuer="x", model="y", version="1"),
        mode=Mode.DELEGATED,
        event_type=EventType.EXECUTION,
        timestamp=ts,
        nonce=fixed_nonce,
        signer=signer,
        delegation=DelegationScope(
            delegation_id=delegation_id,
            actor_id="admin",
            scope="refund <= 500",
            valid_from=valid_from,
            valid_until=valid_until,
            signature=delegation_signature,
            signature_public_key=human_pub.decode(),
        ),
        action=DelegatedAction(
            delegation_id=delegation_id,
            action_hash=sha256_bytes(b"refund-300"),
            executed_at=ts,
        ),
    )

    result = verify_receipt(receipt.model_dump(mode="json"), system_pub)
    assert result.valid

def test_invalid_delegation_window_rejected():
    ts = datetime.now(timezone.utc)

    with pytest.raises(ValidationError):
        DelegationScope(
            delegation_id="x",
            actor_id="admin",
            scope="refund <= 500",
            valid_from=ts,
            valid_until=ts - timedelta(seconds=1),
            signature="fake",
            signature_public_key="fake",
        )


def test_delegation_expiry_rejected(ed25519_keys, fixed_nonce):
    system_priv, system_pub = ed25519_keys
    human_priv, human_pub = generate_extra_keypair()

    signer = Ed25519Signer(system_priv)
    builder = ReceiptBuilder("1.0", "v1")

    delegation_id = sha256_bytes(b"delegation-expired")
    ts = datetime.now(timezone.utc)

    valid_from = ts - timedelta(days=2)
    valid_until = ts - timedelta(days=1)  # already expired

    # Build temp scope to match canonical structure
    temp_scope = DelegationScope(
        delegation_id=delegation_id,
        actor_id="admin",
        scope="refund <= 500",
        valid_from=valid_from,
        valid_until=valid_until,
        signature="placeholder",
        signature_public_key=human_pub.decode(),
    )

    delegation_payload = temp_scope.model_dump(mode="json")
    delegation_payload.pop("signature")

    delegation_signature = Ed25519Signer(human_priv).sign(
        canonicalize(delegation_payload)
    )

    receipt = builder.build(
        ai_identity=AIIdentity(issuer="x", model="y", version="1"),
        mode=Mode.DELEGATED,
        event_type=EventType.EXECUTION,
        timestamp=ts,
        nonce=fixed_nonce,
        signer=signer,
        delegation=DelegationScope(
            delegation_id=delegation_id,
            actor_id="admin",
            scope="refund <= 500",
            valid_from=valid_from,
            valid_until=valid_until,
            signature=delegation_signature,
            signature_public_key=human_pub.decode(),
        ),
        action=DelegatedAction(
            delegation_id=delegation_id,
            action_hash=sha256_bytes(b"refund-300"),
            executed_at=valid_from,
        ),
    )

    result = verify_receipt(receipt.model_dump(mode="json"), system_pub)
    assert not result.valid

def test_sdk_payload_modification_detected(ed25519_keys, fixed_nonce):
    system_priv, system_pub = ed25519_keys
    signer = Ed25519Signer(system_priv)
    builder = ReceiptBuilder("1.0", "v1")

    receipt = builder.build(
        ai_identity=AIIdentity(issuer="x", model="y", version="1"),
        mode=Mode.ASSISTIVE,
        event_type=EventType.EXECUTION,
        timestamp=datetime.now(timezone.utc),
        nonce=fixed_nonce,
        signer=signer,
    )

    hacked = receipt.model_dump(mode="json")
    hacked["ai"]["model"] = "evil-model"

    result = verify_receipt(hacked, system_pub)
    assert not result.valid


def test_field_removal_detected(ed25519_keys, fixed_nonce):
    system_priv, system_pub = ed25519_keys
    signer = Ed25519Signer(system_priv)
    builder = ReceiptBuilder("1.0", "v1")

    receipt = builder.build(
        ai_identity=AIIdentity(issuer="x", model="y", version="1"),
        mode=Mode.ASSISTIVE,
        event_type=EventType.EXECUTION,
        timestamp=datetime.now(timezone.utc),
        nonce=fixed_nonce,
        signer=signer,
    )

    corrupted = receipt.model_dump(mode="json")
    del corrupted["receipt_id"]

    result = verify_receipt(corrupted, system_pub)
    assert not result.valid
