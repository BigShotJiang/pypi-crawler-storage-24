from datetime import datetime, timezone
import pytest

from norhook.core.receipt_builder import ReceiptBuilder
from norhook.core.schema import (
    AIIdentity,
    Mode,
    EventType,
)
from norhook.signing.ed25519 import Ed25519Signer


def test_missing_human_block_raises(ed25519_keys):
    private_pem, _ = ed25519_keys
    signer = Ed25519Signer(private_pem)
    builder = ReceiptBuilder("1.0", "v1")

    # HUMAN_CONFIRMED requires human block
    with pytest.raises(ValueError):
        builder.build(
            ai_identity=AIIdentity(issuer="a", model="b", version="1"),
            mode=Mode.HUMAN_CONFIRMED,
            event_type=EventType.EXECUTION,
            timestamp=datetime.now(timezone.utc),
            nonce="test-nonce-1",
            signer=signer,
            output_hash="abc123",
        )


def test_missing_delegation_blocks_raise(ed25519_keys):
    private_pem, _ = ed25519_keys
    signer = Ed25519Signer(private_pem)
    builder = ReceiptBuilder("1.0", "v1")

    # DELEGATED requires both delegation + action
    with pytest.raises(ValueError):
        builder.build(
            ai_identity=AIIdentity(issuer="a", model="b", version="1"),
            mode=Mode.DELEGATED,
            event_type=EventType.EXECUTION,
            timestamp=datetime.now(timezone.utc),
            nonce="test-nonce-2",
            signer=signer,
        )


def test_missing_tool_block_raises(ed25519_keys):
    private_pem, _ = ed25519_keys
    signer = Ed25519Signer(private_pem)
    builder = ReceiptBuilder("1.0", "v1")

    # TOOL_CALL event_type requires tool_call block
    with pytest.raises(ValueError):
        builder.build(
            ai_identity=AIIdentity(issuer="a", model="b", version="1"),
            mode=Mode.ASSISTIVE,
            event_type=EventType.TOOL_CALL,
            timestamp=datetime.now(timezone.utc),
            nonce="test-nonce-3",
            signer=signer,
        )
