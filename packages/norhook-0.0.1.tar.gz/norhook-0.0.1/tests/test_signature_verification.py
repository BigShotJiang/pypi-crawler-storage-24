from datetime import datetime, timezone

from norhook.core.receipt_builder import ReceiptBuilder
from norhook.core.schema import AIIdentity, Mode, EventType
from norhook.signing.ed25519 import Ed25519Signer
from norhook.verification.verifier import verify_receipt


def test_signature_verification_passes(ed25519_keys):
    private_pem, public_pem = ed25519_keys
    signer = Ed25519Signer(private_pem)

    builder = ReceiptBuilder("1.0", "v1")

    fixed_timestamp = datetime(2025, 1, 1, tzinfo=timezone.utc)

    receipt = builder.build(
        ai_identity=AIIdentity(
            issuer="test",
            model="gpt-x",
            version="1"
        ),
        mode=Mode.ASSISTIVE,
        event_type=EventType.EXECUTION,
        timestamp=fixed_timestamp,
        nonce="sig-test-nonce",
        signer=signer,
    )

    result = verify_receipt(receipt.model_dump(mode="json"), public_pem)

    assert result.valid
    assert result.severity == "info"
    assert "NORHOOK-SIG-001" in result.control_ids
    assert "NORHOOK-HASH-001" in result.control_ids
    assert receipt.crypto_profile.signature == "ed25519"
