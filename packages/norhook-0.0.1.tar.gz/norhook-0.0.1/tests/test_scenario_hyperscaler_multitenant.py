from datetime import datetime, timezone

from norhook.core.receipt_builder import ReceiptBuilder
from norhook.core.schema import AIIdentity, Mode, EventType
from norhook.signing.ed25519 import Ed25519Signer
from norhook.verification.verifier import verify_receipt


def test_multitenant_isolation_and_key_rotation(ed25519_keys):
    """
    Simulates hyperscaler environment:

    - Two tenants
    - Two signing keys
    - Key rotation event
    - Trusted key allowlist enforcement
    - Cross-tenant misuse attempt
    """

    # ---------------------------------------------------------
    # Tenant A Key
    # ---------------------------------------------------------
    priv_a, pub_a = ed25519_keys
    signer_a = Ed25519Signer(priv_a)

    # ---------------------------------------------------------
    # Tenant B Key (new keypair)
    # ---------------------------------------------------------
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    from cryptography.hazmat.primitives import serialization

    priv_b_obj = Ed25519PrivateKey.generate()
    priv_b = priv_b_obj.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )
    pub_b = priv_b_obj.public_key().public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    )

    signer_b = Ed25519Signer(priv_b)

    builder = ReceiptBuilder("1.0", "v1")
    fixed_time = datetime(2025, 1, 1, tzinfo=timezone.utc)

    # ---------------------------------------------------------
    # 1️⃣ Tenant A Generates Receipt
    # ---------------------------------------------------------
    receipt_a = builder.build(
        ai_identity=AIIdentity(issuer="tenant-a", model="agent-v1", version="1"),
        mode=Mode.ASSISTIVE,
        event_type=EventType.EXECUTION,
        timestamp=fixed_time,
        nonce="tenant-a-nonce",
        tenant_id="tenant-a",
        signer=signer_a,
    )

    # ---------------------------------------------------------
    # 2️⃣ Tenant B Generates Receipt
    # ---------------------------------------------------------
    receipt_b = builder.build(
        ai_identity=AIIdentity(issuer="tenant-b", model="agent-v2", version="1"),
        mode=Mode.ASSISTIVE,
        event_type=EventType.EXECUTION,
        timestamp=fixed_time,
        nonce="tenant-b-nonce",
        tenant_id="tenant-b",
        signer=signer_b,
    )

    # ---------------------------------------------------------
    # 3️⃣ Verify With Correct Allowlist
    # ---------------------------------------------------------
    result_a = verify_receipt(
        receipt_a.model_dump(mode="json"),
        [pub_a, pub_b],
        trusted_public_keys=[pub_a, pub_b],
    )

    result_b = verify_receipt(
        receipt_b.model_dump(mode="json"),
        [pub_a, pub_b],
        trusted_public_keys=[pub_a, pub_b],
    )

    assert result_a.valid
    assert result_b.valid

    # ---------------------------------------------------------
    # 4️⃣ Cross-Tenant Misuse Attempt
    # Try verifying tenant A receipt using only tenant B key
    # ---------------------------------------------------------
    cross_attempt = verify_receipt(
        receipt_a.model_dump(mode="json"),
        pub_b,
        trusted_public_keys=[pub_b],
    )

    assert not cross_attempt.valid

    # ---------------------------------------------------------
    # 5️⃣ Key Rotation Scenario
    # Tenant A rotates key
    # ---------------------------------------------------------

    priv_a_new_obj = Ed25519PrivateKey.generate()
    priv_a_new = priv_a_new_obj.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    )
    pub_a_new = priv_a_new_obj.public_key().public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    )

    signer_a_new = Ed25519Signer(priv_a_new)

    rotated_receipt = builder.build(
        ai_identity=AIIdentity(issuer="tenant-a", model="agent-v1", version="2"),
        mode=Mode.ASSISTIVE,
        event_type=EventType.EXECUTION,
        timestamp=fixed_time,
        nonce="tenant-a-rotated",
        tenant_id="tenant-a",
        signer=signer_a_new,
    )

    # Old key should fail if allowlist updated
    rotation_fail = verify_receipt(
        rotated_receipt.model_dump(mode="json"),
        pub_a,
        trusted_public_keys=[pub_a],
    )

    assert not rotation_fail.valid

    # New key should pass
    rotation_pass = verify_receipt(
        rotated_receipt.model_dump(mode="json"),
        pub_a_new,
        trusted_public_keys=[pub_a_new],
    )

    assert rotation_pass.valid
