import json
import copy
from datetime import datetime, timezone

from norhook.core.receipt_builder import ReceiptBuilder
from norhook.core.schema import AIIdentity, Mode, EventType
from norhook.signing.ed25519 import Ed25519Signer
from norhook.verification.verifier import verify_receipt


def test_extreme_adversarial_conditions(ed25519_keys):
    """
    Simulates extreme adversarial abuse:

    - Oversized receipt payload
    - Algorithm downgrade attempt
    - Signature stripping
    - previous_hash corruption
    - Revoked key usage
    """

    priv_pem, pub_pem = ed25519_keys
    signer = Ed25519Signer(priv_pem)

    builder = ReceiptBuilder("1.0", "v1")
    fixed_time = datetime(2025, 1, 1, tzinfo=timezone.utc)

    # ---------------------------------------------------------
    # 1️⃣ Build Valid Receipt
    # ---------------------------------------------------------

    receipt = builder.build(
        ai_identity=AIIdentity(
            issuer="extreme-test",
            model="agent-v1",
            version="1"
        ),
        mode=Mode.ASSISTIVE,
        event_type=EventType.EXECUTION,
        timestamp=fixed_time,
        nonce="extreme-nonce",
        signer=signer,
    )

    valid_dict = copy.deepcopy(receipt.model_dump(mode="json"))

    # ---------------------------------------------------------
    # 2️⃣ Oversized Payload Attack
    # ---------------------------------------------------------

    oversized = copy.deepcopy(valid_dict)
    oversized["padding"] = "X" * (70 * 1024)  # exceeds MAX_RECEIPT_SIZE_BYTES

    size_result = verify_receipt(oversized, pub_pem)
    assert not size_result.valid
    assert size_result.reason == "Receipt exceeds size limit"

    # ---------------------------------------------------------
    # 3️⃣ Algorithm Downgrade Attempt
    # ---------------------------------------------------------

    downgraded = copy.deepcopy(valid_dict)
    downgraded["signature_algorithm"] = "md5"
    downgraded["crypto_profile"]["signature"] = "md5"

    downgrade_result = verify_receipt(downgraded, pub_pem)
    assert not downgrade_result.valid
    assert downgrade_result.reason == "Unsupported signature algorithm"

    # ---------------------------------------------------------
    # 4️⃣ Signature Stripping Attempt
    # ---------------------------------------------------------

    stripped = copy.deepcopy(valid_dict)
    del stripped["signature"]

    stripped_result = verify_receipt(stripped, pub_pem)
    assert not stripped_result.valid

    # ---------------------------------------------------------
    # 5️⃣ previous_hash Corruption Attempt
    # ---------------------------------------------------------

    corrupted_chain = copy.deepcopy(valid_dict)
    corrupted_chain["previous_hash"] = "fake_previous_hash"

    corrupted_result = verify_receipt(corrupted_chain, pub_pem)
    assert not corrupted_result.valid

    # ---------------------------------------------------------
    # 6️⃣ Revoked Key Usage
    # ---------------------------------------------------------

    revoked_result = verify_receipt(
        valid_dict,
        pub_pem,
        revoked_key_ids=[receipt.key_id],
    )

    assert not revoked_result.valid
    assert revoked_result.reason == "Signing key revoked"

    # ---------------------------------------------------------
    # 7️⃣ Massive JSON Reformat Attack
    # Attempt structural mutation through JSON manipulation
    # ---------------------------------------------------------

    json_str = json.dumps(valid_dict)
    mutated = json.loads(json_str)

    # Inject malicious field
    mutated["ai"]["issuer"] = "attacker"

    mutation_result = verify_receipt(mutated, pub_pem)
    assert not mutation_result.valid
