from datetime import datetime, timezone
import json
from copy import deepcopy

from norhook.core.receipt_builder import ReceiptBuilder
from norhook.core.schema import AIIdentity, Mode, EventType
from norhook.signing.ed25519 import Ed25519Signer
from norhook.verification.verifier import verify_receipt


def test_json_reordering_does_not_break_verification(ed25519_keys, fixed_nonce):
    private_pem, public_pem = ed25519_keys
    signer = Ed25519Signer(private_pem)

    builder = ReceiptBuilder("1.0", "v1")

    receipt = builder.build(
        ai_identity=AIIdentity(issuer="a", model="b", version="1"),
        mode=Mode.ASSISTIVE,
        event_type=EventType.EXECUTION,
        timestamp=datetime.now(timezone.utc),
        nonce=fixed_nonce,
        signer=signer,
    )

    original_dump = receipt.model_dump(mode="json")

    # -----------------------------
    # Reverse top-level keys
    # -----------------------------
    reordered_top = dict(reversed(list(original_dump.items())))
    result_top = verify_receipt(reordered_top, public_pem)
    assert result_top.valid

    # -----------------------------
    # Reverse nested "ai" block
    # -----------------------------
    reordered_nested = deepcopy(original_dump)
    reordered_nested["ai"] = dict(
        reversed(list(reordered_nested["ai"].items()))
    )

    result_nested = verify_receipt(reordered_nested, public_pem)
    assert result_nested.valid

    # -----------------------------
    # Serialize + deserialize via JSON
    # -----------------------------
    json_roundtrip = json.loads(json.dumps(original_dump))
    result_roundtrip = verify_receipt(json_roundtrip, public_pem)
    assert result_roundtrip.valid


def test_canonicalization_version_mismatch_rejected(ed25519_keys, fixed_nonce):
    private_pem, public_pem = ed25519_keys
    signer = Ed25519Signer(private_pem)

    builder = ReceiptBuilder("1.0", "v1")

    receipt = builder.build(
        ai_identity=AIIdentity(issuer="a", model="b", version="1"),
        mode=Mode.ASSISTIVE,
        event_type=EventType.EXECUTION,
        timestamp=datetime.now(timezone.utc),
        nonce=fixed_nonce,
        signer=signer,
    )

    broken = receipt.model_dump(mode="json")
    broken["canonicalization_version"] = "999.0"

    result = verify_receipt(broken, public_pem)
    assert not result.valid
