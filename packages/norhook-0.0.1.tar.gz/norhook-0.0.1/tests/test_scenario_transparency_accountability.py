from datetime import datetime, timezone
from typing import Set

from norhook.core.receipt_builder import ReceiptBuilder
from norhook.core.schema import (
    AIIdentity,
    Mode,
    EventType,
    ExternalTimestamp,
)
from norhook.signing.ed25519 import Ed25519Signer
from norhook.verification.verifier import verify_receipt
from norhook.verification.interfaces import TransparencyChecker
from norhook.core.fingerprint import payload_fingerprint


# ---------------------------------------------------------------------
# In-Memory Transparency Log Simulation
# ---------------------------------------------------------------------

class InMemoryTransparencyLog:
    """
    Simulates an append-only transparency log.

    Stores payload fingerprints.
    """

    def __init__(self):
        self._entries: Set[str] = set()

    def append(self, fingerprint: str):
        self._entries.add(fingerprint)

    def verify_inclusion(self, fingerprint: str) -> bool:
        return fingerprint in self._entries


# ---------------------------------------------------------------------
# Transparency Scenario
# ---------------------------------------------------------------------

def test_transparency_log_and_external_timestamp(ed25519_keys):
    """
    Simulates:

    - Payload fingerprint anchoring
    - External trusted timestamp presence
    - Transparency inclusion verification
    - Tampered inclusion rejection
    """

    priv_pem, pub_pem = ed25519_keys
    signer = Ed25519Signer(priv_pem)

    builder = ReceiptBuilder("1.0", "v1")
    fixed_time = datetime(2025, 1, 1, tzinfo=timezone.utc)

    transparency_log = InMemoryTransparencyLog()

    # -------------------------------------------------------------
    # 1️⃣ Generate Receipt With External Timestamp
    # -------------------------------------------------------------

    receipt = builder.build(
        ai_identity=AIIdentity(
            issuer="regulator-test",
            model="agent-v1",
            version="1"
        ),
        mode=Mode.ASSISTIVE,
        event_type=EventType.EXECUTION,
        timestamp=fixed_time,
        nonce="transparency-nonce",
        signer=signer,
        external_timestamp=ExternalTimestamp(
            source="trusted-time-authority",
            anchored_at=fixed_time,
            proof="opaque-proof-placeholder"
        ),
    )

    # -------------------------------------------------------------
    # 2️⃣ Append Payload Fingerprint To Transparency Log
    # -------------------------------------------------------------

    pf = payload_fingerprint(receipt)
    transparency_log.append(pf)

    # -------------------------------------------------------------
    # 3️⃣ Verify With Transparency Inclusion
    # -------------------------------------------------------------

    result = verify_receipt(
        receipt.model_dump(mode="json"),
        pub_pem,
        transparency_checker=transparency_log,
    )

    assert result.valid
    assert "NORHOOK-TRANSPARENCY-001" in result.control_ids

    # -------------------------------------------------------------
    # 4️⃣ Tamper Transparency Log (Remove Entry)
    # -------------------------------------------------------------

    transparency_log._entries.remove(pf)

    tampered_result = verify_receipt(
        receipt.model_dump(mode="json"),
        pub_pem,
        transparency_checker=transparency_log,
    )

    assert not tampered_result.valid
    assert tampered_result.reason == "Transparency inclusion failed"
