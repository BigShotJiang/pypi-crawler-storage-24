import pytest

from norhook.verification.verifier import verify_receipt
from norhook.verification.result import VerificationResult


def test_missing_signature_field():
    result = verify_receipt({}, b"fake_key")

    assert isinstance(result, VerificationResult)
    assert not result.valid
    assert result.severity in ("high", "critical")


def test_non_dict_input():
    result = verify_receipt("not-a-dict", b"fake_key")

    assert isinstance(result, VerificationResult)
    assert not result.valid
    assert result.severity in ("high", "critical")


def test_invalid_types():
    bad = {
        "protocol": "NORHOOK",
        "signature": 12345
    }

    result = verify_receipt(bad, b"fake_key")

    assert isinstance(result, VerificationResult)
    assert not result.valid
    assert result.severity in ("high", "critical")


def test_none_input():
    result = verify_receipt(None, b"fake_key")

    assert isinstance(result, VerificationResult)
    assert not result.valid
    assert result.severity in ("high", "critical")
