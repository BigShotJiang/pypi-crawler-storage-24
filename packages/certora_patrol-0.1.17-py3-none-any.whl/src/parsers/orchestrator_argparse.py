"""
Argparse configuration for the PreAudit Orchestrator.
"""

import argparse
from pathlib import Path
from typing import List, Optional

from src.utils.types import ContractHandle


def create_parser():
    """Create and return the argument parser for the orchestrator."""
    parser = argparse.ArgumentParser(
        description="PreAudit Orchestrator - Run Certora verification tools with intelligent caching",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Usage Examples:
  # Run all checkers (default behavior)
  python orchestrator.py Contract.sol

  # Run with verbose output
  python orchestrator.py -v Contract1.sol Contract2.sol

  # Advanced ExternalCallChecker with non-zero target assertions
  python orchestrator.py --extcall-mode advanced --extcall-check-non-zero Contract.sol

  # Disable specific checkers
  python orchestrator.py --disable-extcall Contract.sol
  python orchestrator.py --disable-privileged Contract.sol

  # Skip warmup phase
  python orchestrator.py --skip-warmup Contract.sol

  # Pass additional certoraRun arguments
  python orchestrator.py Contract.sol --server prover --prover_version master
  python orchestrator.py Contract.sol --timeout 300 --settings mySettings

  # Pass additional certoraRun arguments using --extra-args (as quoted string)
  python orchestrator.py --extra-args "--server prover --prover_version master" Contract.sol
  python orchestrator.py --extra-args "--timeout 300 --settings mySettings" Contract.sol

  # All options combined
  python orchestrator.py -v --extcall-mode advanced --disable-privileged Contract.sol --server prover --timeout 300

  # Contract are always split - run each verification separately for each contract
  python orchestrator.py Token.sol Vault.sol

  # Include additional contracts in scene without verification (e.g., harness files)
  python orchestrator.py --additional-contracts harness/Helper.sol Contract.sol

  # Skip breadcrumb fetching for faster debugging
  python orchestrator.py --skip-breadcrumbs Contract.sol

  # Run only sanity setup (no rule generation or verification)
  python orchestrator.py --skip-checkers Contract.sol

  # Debug summaries generation by stopping after that phase
  python orchestrator.py --stop-after-summaries Contract.sol

  # Skip LLM analysis for faster debugging (static analysis only)
  python orchestrator.py --skip-llm Contract.sol

  # Cache management
  python orchestrator.py --cache-status                  # Show cache status
  python orchestrator.py --clear-cache Contract.sol  # Clear cache before running
  python orchestrator.py --no-cache Contract.sol     # Disable caching

Generator Options:
  --disable-extcall         Disable ExternalCallChecker (enabled by default)
  --extcall-mode {simple,advanced}  ExternalCallChecker complexity mode
  --extcall-check-non-zero  Use assertions instead of requires for target > 0
  --disable-privileged      Disable PrivilegedOperations checker (enabled by default)

Cache Options:
  --no-cache               Disable caching (always run fresh verifications)
  --clear-cache            Clear all cached results before running
  --cache-status           Show cache status and exit

Submission Options:
  --require-all-submissions  Require all configurations to be successfully submitted (default: True)
  --allow-submission-failures Allow orchestrator to continue even if some configurations fail to submit

Retry Options:
  --retry-difficult         Retry rules with timeout/unknown methods when verification shows promise (experimental)
                           Retries occur only when at least one rule (excluding envfreeFuncsStaticCheck)
                           has a real result (VERIFIED or VIOLATED), indicating there is "hope" for success.
                           Creates individual retry jobs for each rule with timeout/unknown methods.

Prerequisites: NONE! All generators run automatically as needed.
Caching: Results are cached based on file hashes to avoid redundant runs.
Default Behavior: By default, all configurations must be successfully submitted. Use --allow-submission-failures to override.
        """
    )

    parser.add_argument(
        'contract_files_and_name',
        nargs='*',  # Changed from '+' to '*' to allow zero arguments
        help='List of Solidity contract files (.sol) optionally with contract names (file.sol:ContractName)'
    )

    parser.add_argument(
        '-v', '--verbose',
        action='count',
        default=0,
        help='Increase verbosity level (can be used multiple times: -v, -vv, -vvv)'
    )

    parser.add_argument(
        '--build-system',
        choices=['auto', 'foundry', 'hardhat'],
        default='auto',
        help='Specify build system to use (default: auto - detect from project structure)'
    )

    parser.add_argument(
        '--profile',
        type=str,
        default=None,
        help='Build system profile to use (e.g. Foundry profile name). Default: auto-detect'
    )

    parser.add_argument(
        '--skip-warmup',
        action='store_true',
        help='Skip cache warmup phase'
    )

    # Generator options (all enabled by default)
    parser.add_argument(
        '--disable-extcall',
        action='store_true',
        help='Disable ExternalCallChecker generator (enabled by default)'
    )

    parser.add_argument(
        '--extcall-mode',
        choices=['simple', 'advanced'],
        default='simple',
        help='ExternalCallChecker mode (default: simple)'
    )

    parser.add_argument(
        '--extcall-check-non-zero',
        action='store_true',
        help='Assert target > 0 in ExternalCallChecker specs (default: use require)'
    )

    parser.add_argument(
        '--disable-privileged',
        action='store_true',
        help='Disable PrivilegedOperations generator (enabled by default)'
    )

    # Cache management options
    parser.add_argument(
        '--no-cache',
        action='store_true',
        help='Disable caching (always run fresh verifications)'
    )

    parser.add_argument(
        '--clear-cache',
        action='store_true',
        help='Clear all cached results before running'
    )

    parser.add_argument(
        '--cache-status',
        action='store_true',
        help='Show cache status and exit'
    )

    parser.add_argument(
        '--max-configs',
        type=int,
        metavar='N',
        help='Limit the number of config files to run (for testing purposes)'
    )

    parser.add_argument(
        '--force-llm-regenerate',
        action='store_true',
        help='Force regeneration of LLM summaries even if they already exist'
    )

    parser.add_argument(
        '--skip-breadcrumbs',
        action='store_true',
        help='Skip breadcrumb fetching for faster debugging'
    )

    parser.add_argument(
        '--stop-after-summaries',
        action='store_true',
        help='Stop execution after function summaries generation (for debugging summaries setup)'
    )

    parser.add_argument(
        '--skip-llm',
        action='store_true',
        help='Skip LLM analysis entirely for faster debugging (only use static analysis)'
    )


    parser.add_argument(
        '--skip-checkers',
        action='store_true',
        help='Run only sanity phases (summaries, call resolution, loop/hashing optimization) then stop before rule generation and verification'
    )

    parser.add_argument(
        '--skip-sanity-setup',
        action='store_true',
        help='Skip sanity bounds optimization (loop_iter and hashing_length_bound)'
    )

    parser.add_argument(
        '--skip-call-resolution',
        action='store_true',
        help='Skip call resolution phase (linking and dispatching) - enabled by default'
    )
    
    parser.add_argument(
        '--skip-setup-check',
        action='store_true',
        help='Skip setup completeness checking after prover runs'
    )

    parser.add_argument(
        '--certora-run-command',
        default='certoraRun',
        help='Command to use for running Certora verification (default: certoraRun)'
    )

    parser.add_argument(
        '--extra-args',
        type=str,
        help='Extra arguments to pass to certoraRun as a quoted string (e.g., "--server prover --timeout 300")'
    )

    parser.add_argument(
        '--main-contract',
        type=str,
        required=True,
        help='Main contract file to verify (e.g., Contract.sol:MainContract)'
    )

    parser.add_argument(
        '--additional-contracts',
        type=str,
        nargs='*',
        default=[],
        help='Additional contract files to include in the scene without verification (e.g., harness files)'
    )

    parser.add_argument(
        '--require-all-submissions',
        action='store_true',
        default=True,  # Default to True - require all submissions to succeed
        help='Require all configurations to be successfully submitted (default: True)'
    )

    parser.add_argument(
        '--allow-submission-failures',
        action='store_false',
        dest='require_all_submissions',
        help='Allow the orchestrator to continue even if some configurations fail to submit'
    )

    parser.add_argument(
        '--retry-difficult',
        action='store_true',
        default=False,
        help='Enable retry of rules with timeout/unknown methods when verification shows promise (experimental)'
    )

    parser.add_argument(
        '--use-local-runner',
        action='store_true',
        default=False,
        help='Use local prover runner instead of cloud runner (runs certoraRun locally)'
    )

    parser.add_argument(
        '--dummy-erc20',
        type=int,
        metavar='N',
        default=1,
        help='Specify an integer value for the number of dummy ERC20 contracts to include (default: 1)'
    )

    parser.add_argument(
        '--keep-intermediate-typechecker-files',
        action='store_true',
        help='Keep intermediate typechecker files instead of overwriting them'
    )

    parser.add_argument(
        '--solc-default',
        type=str,
        default='solc8.33',
        metavar='VERSION',
        help='Default Solidity compiler version for compiler_map (default: solc8.33). Example: solc8.26'
    )

    parser.add_argument(
        '--no-cancel-jobs-on-cleanup',
        action='store_true',
        help='Do not cancel cloud jobs when cleaning up (jobs continue running on Certora servers)'
    )

    parser.add_argument(
        '--exclude-foundry-packages',
        action='store_true',
        help='Exclude packages from foundry config in generated configurations (default: packages are included)'
    )

    parser.add_argument(
        '--ambiguous-files',
        nargs='*',
        default=[],
        help='List of contract specifications for files with multiple contracts, specify only one contract per file (format: file.sol:ContractName)'
    )

    parser.add_argument(
        '--auto-ambiguous-contracts-resolve',
        action='store_true',
        help='Automatically resolve ambiguous files by selecting the contract name that matches the filename exactly. Explicit --ambiguous-files specifications take precedence.'
    )

    parser.add_argument(
        '--reports-dir',
        type=str,
        default=None,
        help='Directory for report output (default: .CertoraPatrolReports/<timestamp>)',
    )

    # AutoCVL integration options
    parser.add_argument(
        '--enable-autocvl',
        action='store_true',
        default=False,
        help='Enable AutoCVL automatic CVL specification generation'
    )

    parser.add_argument(
        '--disable-autocvl',
        action='store_false',
        dest='enable_autocvl',
        help='Disable AutoCVL specification generation (default)'
    )

    parser.add_argument(
        '--autocvl-iterative',
        action='store_true',
        default=False,
        help='Enable iterative AutoCVL flow with violation feedback loop (requires --enable-autocvl)'
    )

    parser.add_argument(
        '--autocvl-max-iterations',
        type=int,
        default=3,
        metavar='N',
        help='Maximum iterations for iterative AutoCVL mode (default: 3)'
    )

    return parser


def parse_contract_files(
    contract_specs: List[str],
    project_root: Optional[Path] = None,
    strict: bool = True
) -> List[ContractHandle]:
    """
    Parse contract file specifications that may include contract names.

    Args:
        contract_specs: List of file specifications with optional contract names
        project_root: Optional root directory for resolving relative paths to absolute paths
        strict: If True (default), validates files exist and raises errors for non-.sol files.
                If False, skips non-.sol files and missing files gracefully.

    Returns:
        List of ContractHandle objects

    Raises:
        ValueError: If validation fails (when strict=True)

    Examples:
        ['file1.sol', 'file2.sol:MyContract'] ->
        [ContractHandle('file1', 'file1.sol'), ContractHandle('MyContract', 'file2.sol')]
    """
    if strict and len(contract_specs) < 1:
        raise ValueError("Must provide at least one .sol file")

    contract_handles = []

    for spec in contract_specs:
        if ':' in spec:
            # Format: file.sol:ContractName
            file_path, contract_name = spec.split(':', 1)
        else:
            # Format: file.sol (infer contract name from filename)
            file_path = spec
            # Use stem of filename as contract name
            contract_name = Path(spec).stem

        # Validate or filter file extension
        if not file_path.endswith(".sol"):
            if not strict:
                continue
            raise ValueError(f"Error: {file_path} is not a .sol file")

        # Change to absolute path if requested
        file_path = Path(file_path)
        if not file_path.is_absolute() and project_root:
            file_path = project_root / file_path

        # Final validation
        if not file_path.exists():
            if not strict:
                continue
            raise ValueError(f"Error: File {file_path} does not exist")

        contract_handles.append(ContractHandle(contract_name=contract_name, source_file=str(file_path)))

    return contract_handles
