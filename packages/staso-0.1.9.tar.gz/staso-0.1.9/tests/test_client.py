"""Tests for staso.client and staso.init/shutdown."""
from __future__ import annotations

import pytest

import staso as st
from staso.client import _set_client, get_client
from staso.config import Config
from staso.provider import TracerProvider


class TestInit:
    def test_init_returns_client(self):
        client = st.init(api_key="ak_test", agent_id="test-agent", enabled=False)
        assert isinstance(client, st.Client)

    def test_init_sets_global_client(self):
        assert get_client() is None
        st.init(api_key="ak_test", agent_id="test-agent", enabled=False)
        assert get_client() is not None

    def test_init_config_passed_through(self):
        client = st.init(
            api_key="ak_123",
            agent_id="agent-x",
            environment="staging",
            enabled=False,
        )
        assert client.config.api_key == "ak_123"
        assert client.config.agent_id == "agent-x"
        assert client.config.environment == "staging"

    def test_init_keyword_only(self):
        with pytest.raises(TypeError):
            st.init("ak_test", "agent")  # type: ignore[misc]


class TestClient:
    def test_config_property(self):
        cfg = Config(api_key="ak_test", agent_id="test", enabled=False)
        client = st.Client(cfg)
        assert client.config is cfg

    def test_provider_property(self):
        cfg = Config(api_key="ak_test", agent_id="test", enabled=False)
        client = st.Client(cfg)
        assert isinstance(client.provider, TracerProvider)

    def test_no_transport_when_disabled(self):
        cfg = Config(api_key="ak_test", agent_id="test", enabled=False)
        client = st.Client(cfg)
        assert client._transport is None

    def test_transport_created_when_enabled(self):
        client = st.init(api_key="ak_test", agent_id="test", enabled=True)
        assert client._transport is not None
        client.shutdown()


class TestShutdown:
    def test_shutdown_without_init(self):
        st.shutdown()  # Should not raise

    def test_shutdown_after_init(self):
        st.init(api_key="ak_test", agent_id="test", enabled=False)
        st.shutdown()


class TestGetClient:
    def test_returns_none_before_init(self):
        _set_client(None)  # type: ignore[arg-type]
        assert get_client() is None

    def test_returns_client_after_init(self):
        client = st.init(api_key="ak_test", agent_id="test", enabled=False)
        assert get_client() is client
