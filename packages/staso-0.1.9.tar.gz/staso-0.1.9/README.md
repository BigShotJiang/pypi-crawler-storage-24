# Staso Python SDK

You're shipping AI agents to production. You need to know what they're actually doing — which tools they called, what the LLM returned, where they failed, and how much it cost. Staso gives you that.

```bash
pip install staso
```

```python
import staso as st

st.init(api_key="ak_...", agent_id="my-agent")

@st.agent(name="support-agent")
def handle_request(message: str) -> str:
    context = search_kb(message)
    return call_llm(context, message)

@st.tool(name="search_kb")
def search_kb(query: str) -> str:
    return db.search(query)

with st.session("conversation-123"):
    handle_request("How do I reset my password?")

st.shutdown()
```

That's it. Open your [Staso dashboard](https://staso.ai) and you'll see the full execution tree — every agent run, tool call, LLM interaction, token count, latency, and error.

### Auto-Instrument LLM Calls

```bash
pip install "staso[anthropic]"
```

```python
st.integrations.patch_anthropic()
# Every Anthropic API call is now traced automatically.
```

### Docs

- [Quickstart](./documentation/getting-started/quickstart.md)
- [Tracing your code](./documentation/guides/tracing.md)
- [Sessions](./documentation/guides/sessions.md)
- [LLM integrations](./documentation/integrations/anthropic.md)
- [Configuration](./documentation/configuration/options.md)
- [Troubleshooting](./documentation/troubleshooting.md)

Python 3.11+ &middot; [Apache 2.0](LICENSE)
