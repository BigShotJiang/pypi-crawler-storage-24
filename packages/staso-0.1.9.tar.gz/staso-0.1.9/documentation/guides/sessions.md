# Sessions

Group related traces together — conversations, workflows, whatever makes sense for your use case.

## Usage

```python
with st.session("conversation-42"):
    run_agent("What's my balance?")
    run_agent("Transfer $50")
```

Both runs and all their child spans get tagged with `conversation-42`.

## Common Patterns

```python
# Conversations
with st.session(f"conv-{conversation_id}"):
    for message in messages:
        run_agent(message)

# Workflows
with st.session(f"workflow-{job_id}"):
    step_1()
    step_2()

# Per-request
with st.session(request_id):
    handle_request(payload)
```

## Propagation

Session IDs flow automatically through your entire call stack, including async code. You don't pass them around:

```python
with st.session("my-session"):
    run_agent("hello")
    # Every @tool, @trace, and LLM call inside
    # is automatically tagged with "my-session"
```

## Optional

Sessions are optional. Without them, traces still work — they just aren't grouped on the dashboard.

## Nesting

Innermost session wins:

```python
with st.session("outer"):
    run_agent("A")           # session = "outer"
    with st.session("inner"):
        run_agent("B")       # session = "inner"
    run_agent("C")           # session = "outer"
```
