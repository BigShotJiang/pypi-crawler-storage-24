# Configuration

Everything goes through `st.init()`.

## Minimal

```python
st.init(api_key="ak_...", agent_id="my-agent")
```

## All Options

```python
st.init(
    api_key="ak_...",                     # Required — your Staso API key
    agent_id="my-agent",                  # Required — name for this agent
    base_url="https://api.staso.ai",      # Staso backend URL
    environment="production",              # Tag traces by environment
    workspace_slug="my-workspace",         # Workspace identifier
    batch_size=100,                        # Spans buffered before sending
    flush_interval=5.0,                    # Max seconds between sends
    max_queue_size=10_000,                 # Max buffered spans
    enabled=True,                          # False to disable without removing code
    debug=False,                           # SDK debug logs
)
```

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `api_key` | `str` | *required* | Your Staso API key |
| `agent_id` | `str` | *required* | Agent name, shown on dashboard |
| `base_url` | `str` | `http://localhost:6999` | Backend URL |
| `environment` | `str` | `"default"` | Environment tag (`"staging"`, `"production"`) |
| `workspace_slug` | `str` | `""` | Workspace identifier |
| `batch_size` | `int` | `100` | Flush after this many spans |
| `flush_interval` | `float` | `5.0` | Flush after this many seconds |
| `max_queue_size` | `int` | `10_000` | Drops new spans when full |
| `enabled` | `bool` | `True` | Kill switch — decorators stay, no data sent |
| `debug` | `bool` | `False` | Debug logging on `staso` logger |

## Environment Variables

```python
import os

st.init(
    api_key=os.environ["STASO_API_KEY"],
    agent_id="my-agent",
    base_url=os.environ.get("STASO_BASE_URL", "https://api.staso.ai"),
    environment=os.environ.get("STASO_ENV", "production"),
)
```

## Disabling

Keep all decorators in your code, send nothing:

```python
st.init(api_key="ak_...", agent_id="my-agent", enabled=False)
```

## Shutdown

Always call before exit:

```python
st.shutdown()
```

There's an `atexit` hook as a fallback, but explicit is better.
