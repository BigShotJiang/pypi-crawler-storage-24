# LLM Integrations

One line of code to auto-trace LLM provider calls. No wrappers, no code changes.

## Available

| Provider | Install | Enable |
|----------|---------|--------|
| [Anthropic](./anthropic.md) | `pip install "staso[anthropic]"` | `st.integrations.patch_anthropic()` |

## How It Works

Call the patch function. Every API call to that provider automatically emits an LLM span — model, tokens, latency, errors.

```python
st.integrations.patch_anthropic()

# Use Anthropic normally — traces happen automatically
client = anthropic.Anthropic()
response = client.messages.create(model="claude-sonnet-4-20250514", ...)
```

## Other Providers

For providers without a built-in integration, use `@st.trace(kind="LLM")`:

```python
@st.trace(name="openai_call", kind="LLM")
def call_openai(prompt: str) -> str:
    response = openai.chat.completions.create(...)
    return response.choices[0].message.content
```

You get timing and error tracking, but not automatic token extraction.
