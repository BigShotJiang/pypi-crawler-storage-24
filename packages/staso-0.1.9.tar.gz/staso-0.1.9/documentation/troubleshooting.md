# Troubleshooting

## Traces Not Showing Up

**1. Check API key and URL:**

```python
st.init(api_key="ak_...", base_url="https://api.staso.ai", ...)
```

**2. Call `st.shutdown()` before exit.** Without it, traces can be lost if the process exits before the background sender finishes.

**3. Turn on debug logging:**

```python
st.init(..., debug=True)
```

Look for `ingest returned 401` (bad API key) or `ingest error` (network issue).

**4. Make sure `enabled` isn't `False`.**

## Anthropic Integration Not Working

Install the extra:

```bash
pip install "staso[anthropic]"
```

Call `patch_anthropic()` **before** creating your Anthropic client:

```python
st.init(...)
st.integrations.patch_anthropic()  # First
client = anthropic.Anthropic()     # Then this
```

## Missing Tool Inputs/Outputs

`@st.tool` captures inputs and outputs. `@st.trace` doesn't.

```python
@st.tool(name="search")       # Captures args + return value
def search(query: str) -> str: ...

@st.trace(name="search")      # Only timing + errors
def search(query: str) -> str: ...
```

## Queue Full Warnings

Your agent is emitting spans faster than they can be sent. Options:

```python
st.init(
    ...,
    max_queue_size=50_000,   # Bigger buffer
    batch_size=500,          # More per request
    flush_interval=1.0,      # Send more often
)
```

## Python Version

The SDK needs Python 3.11+. Check with `python --version`.

## Something Else?

The SDK is designed to never crash your application — all SDK code paths catch exceptions silently. If you're seeing SDK-related errors, open an issue at [github.com/staso-ai/python-sdk](https://github.com/staso-ai/python-sdk/issues).

Your exceptions always propagate normally. The SDK records them on the span but never swallows them.
