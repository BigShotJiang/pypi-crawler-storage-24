/// CAN Watch Data v1 — 8-byte packed struct for single CAN 2.0 frame
///
/// Layout (little-endian):
///   [0..4] position: f32  — multi-turn position in radians
///   [4..6] speed:    i16  — velocity in 0.1 rad/s units (range ±3276.7 rad/s)
///   [6..8] current:  i16  — q-axis current in 0.01A units (range ±327.67A)

const SPEED_SCALE: f32 = 10.0;
const CURRENT_SCALE: f32 = 100.0;

#[derive(Debug, Clone, Copy, PartialEq)]
pub struct WatchData {
    pub position: f32,
    pub speed: i16,
    pub current: i16,
}

impl WatchData {
    pub fn new(position: f32, speed: f32, current: f32) -> Self {
        Self {
            position,
            speed: (speed * SPEED_SCALE).clamp(i16::MIN as f32, i16::MAX as f32) as i16,
            current: (current * CURRENT_SCALE).clamp(i16::MIN as f32, i16::MAX as f32) as i16,
        }
    }

    pub fn to_bytes(self) -> [u8; 8] {
        let mut buf = [0u8; 8];
        buf[0..4].copy_from_slice(&self.position.to_le_bytes());
        buf[4..6].copy_from_slice(&self.speed.to_le_bytes());
        buf[6..8].copy_from_slice(&self.current.to_le_bytes());
        buf
    }

    pub fn from_bytes(buf: &[u8; 8]) -> Self {
        Self {
            position: f32::from_le_bytes([buf[0], buf[1], buf[2], buf[3]]),
            speed: i16::from_le_bytes([buf[4], buf[5]]),
            current: i16::from_le_bytes([buf[6], buf[7]]),
        }
    }

    pub fn speed_f32(&self) -> f32 {
        self.speed as f32 / SPEED_SCALE
    }

    pub fn current_f32(&self) -> f32 {
        self.current as f32 / CURRENT_SCALE
    }
}
