pub mod device;
pub mod protocol;

use std::{
    io,
    sync::{Arc, Mutex},
};
use tokio::task::JoinHandle;

use crate::{
    comm::{can::CanDeviceAsync, v1::WatchData as V1WatchData},
    instance::motor::{
        device::Device,
        protocol::{FocControlMode, WatchData},
    },
    runtime::RUNTIME,
};

/// 广播式电机控制器
///
/// Motor 持有一个 CAN 设备，管理最多 4 个 [`Device`]。
/// 每次调用 [`broadcast`](Motor::broadcast) 时，将所有 Device 的目标值
/// 打包成一条 8 字节 CAN 广播帧（4 × i16 little-endian）发出。
///
/// 同时在后台持续接收各 Device 的回传帧（按 `feedback_id` 路由），
/// 解析后存入对应 Device 的 `watch_data`。
pub struct Motor {
    can_device: Arc<CanDeviceAsync>,
    broadcast_id: u32,
    /// 已注册的 Device 列表（最多 4 个，slot_index 不得重复）
    devices: Arc<Mutex<Vec<Arc<Device>>>>,
    receive_task_handle: Option<JoinHandle<()>>,
}

impl Motor {
    /// 创建 Motor
    ///
    /// # Arguments
    /// * `interface`    - CAN 接口名（如 `"can0"`）
    /// * `broadcast_id` - 广播控制帧的 CAN ID
    pub fn new(interface: &str, broadcast_id: u32) -> Result<Self, io::Error> {
        let can_device = Arc::new(CanDeviceAsync::new(interface)?);
        let devices: Arc<Mutex<Vec<Arc<Device>>>> = Arc::new(Mutex::new(Vec::new()));
        let receive_task_handle =
            Self::start_receive_task(devices.clone(), can_device.clone());

        Ok(Self {
            can_device,
            broadcast_id,
            devices,
            receive_task_handle: Some(receive_task_handle),
        })
    }

    /// 启动后台接收任务，按 feedback_id 将回传帧路由到对应 Device
    fn start_receive_task(
        devices: Arc<Mutex<Vec<Arc<Device>>>>,
        can_device: Arc<CanDeviceAsync>,
    ) -> JoinHandle<()> {
        RUNTIME.spawn(async move {
            loop {
                let Some(message) = can_device.receive_timeout_async(100).await else {
                    continue;
                };
                if message.data.len() != 8 {
                    eprintln!(
                        "Warning: ignoring CAN frame 0x{:X} with unexpected length {}",
                        message.id,
                        message.data.len()
                    );
                    continue;
                }

                let mut buf = [0u8; 8];
                buf.copy_from_slice(&message.data[..8]);
                let v1 = V1WatchData::from_bytes(&buf);
                let watch = WatchData::new(v1.position, v1.speed_f32(), v1.current_f32());

                // 找到匹配的 Device（短暂持锁，释放后再 await）
                let matched = {
                    let devs = devices.lock().unwrap();
                    devs.iter()
                        .find(|d| d.feedback_id == message.id)
                        .cloned()
                };
                match matched {
                    Some(device) => device.update_watch_data(watch).await,
                    None => eprintln!(
                        "[Motor] unmatched feedback frame: id=0x{:X}, data={:?}",
                        message.id, &buf
                    ),
                }
            }
        })
    }

    /// 添加一个 Device 到广播组
    ///
    /// # Arguments
    /// * `slot_index`   - 广播帧槽位（0–3），对应驱动器的 `target_index`
    /// * `feedback_id`  - 驱动器回传帧的 CAN ID
    /// * `mode`         - FOC 控制模式，决定目标值缩放系数
    ///
    /// # Returns
    /// 返回 `Arc<Device>`，调用方持有该引用后可随时设置目标值并读取回传数据
    pub fn add_device(
        &self,
        slot_index: u8,
        feedback_id: u32,
        mode: FocControlMode,
    ) -> Arc<Device> {
        let device = Device::new(slot_index, feedback_id, mode);
        self.devices.lock().unwrap().push(device.clone());
        device
    }

    /// 将所有 Device 的目标值打包成一条 CAN 广播帧并发送
    ///
    /// 帧格式：8 字节，4 × i16 little-endian
    /// - bytes [slot*2 .. slot*2+2] ← device.encoded_target()
    /// - 未注册槽位保持 0x0000
    pub fn broadcast(&self) -> Result<(), io::Error> {
        let mut data = [0u8; 8];
        let devs = self.devices.lock().unwrap();
        for device in devs.iter() {
            let slot = device.slot_index as usize; // already clamped to 0–3 in Device::new
            let raw = device.encoded_target();
            let offset = slot * 2;
            data[offset..offset + 2].copy_from_slice(&raw.to_le_bytes());
        }
        drop(devs);
        self.can_device
            .send_nonblocking(self.broadcast_id, data.to_vec())
    }

    /// 获取广播 CAN ID
    pub fn broadcast_id(&self) -> u32 {
        self.broadcast_id
    }

    /// 通过槽位索引直接设置目标值
    ///
    /// 等价于先找到对应 `Device` 再调用 `device.set_target(value)`。
    /// 若该槽位尚未注册 Device，调用将被忽略。
    pub fn set_target(&self, slot_index: u8, value: f32) {
        let device = {
            let devs = self.devices.lock().unwrap();
            devs.iter().find(|d| d.slot_index == slot_index).cloned()
        };
        if let Some(d) = device {
            d.set_target(value);
        }
    }

    /// 通过槽位索引获取回传数据（阻塞）
    ///
    /// 若该槽位尚未注册 Device，返回 `None`。
    pub fn get_watch_data(&self, slot_index: u8) -> Option<WatchData> {
        // 先 clone Arc，释放锁，再阻塞读取；避免持锁期间接收任务无法路由帧
        let device = {
            let devs = self.devices.lock().unwrap();
            devs.iter()
                .find(|d| d.slot_index == slot_index)
                .cloned()
        };
        device.map(|d| d.get_watch_data_blocking())
    }

    /// 返回当前已注册的 Device 列表（克隆）
    pub fn devices(&self) -> Vec<Arc<Device>> {
        self.devices.lock().unwrap().clone()
    }
}

impl Drop for Motor {
    fn drop(&mut self) {
        if let Some(handle) = self.receive_task_handle.take() {
            handle.abort();
        }
    }
}
