use std::sync::{Arc, Mutex};
use tokio::sync::Mutex as AsyncMutex;

use crate::instance::motor::protocol::{FocControlMode, WatchData};

/// 广播组中单个电机驱动器的收发管理单元
///
/// - `slot_index`（0–3）决定该驱动器的目标值在广播帧中的位置
/// - 广播帧布局：4 × i16 little-endian，共 8 字节
///   - [0..2] slot 0
///   - [2..4] slot 1
///   - [4..6] slot 2
///   - [6..8] slot 3
/// - 驱动器回传帧通过 `feedback_id` 过滤，解析后存入 `watch_data`
pub struct Device {
    /// 在广播帧中的槽位（0–3）
    pub slot_index: u8,
    /// 驱动器回传帧的 CAN ID
    pub feedback_id: u32,
    /// FOC 控制模式（决定目标值的缩放系数）
    pub mode: FocControlMode,
    /// 待发送的目标值（物理量，f32）
    target: Mutex<f32>,
    /// 最新回传数据
    watch_data: Arc<AsyncMutex<WatchData>>,
}

impl Device {
    pub fn new(slot_index: u8, feedback_id: u32, mode: FocControlMode) -> Arc<Self> {
        Arc::new(Self {
            slot_index: slot_index.min(3),
            feedback_id,
            mode,
            target: Mutex::new(0.0),
            watch_data: Arc::new(AsyncMutex::new(WatchData::default())),
        })
    }

    /// 设置目标值（物理量，下次 broadcast 时编码进帧）
    pub fn set_target(&self, value: f32) {
        if let Ok(mut t) = self.target.lock() {
            *t = value;
        }
    }

    /// 读取当前目标值
    pub fn get_target(&self) -> f32 {
        self.target.lock().map(|t| *t).unwrap_or(0.0)
    }

    /// 将目标值编码为广播帧所需的 i16 定点数
    pub(crate) fn encoded_target(&self) -> i16 {
        self.mode.encode(self.get_target())
    }

    /// 获取最新回传数据（阻塞，供 Python 调用）
    pub fn get_watch_data_blocking(&self) -> WatchData {
        tokio::task::block_in_place(|| {
            crate::runtime::RUNTIME.block_on(async { *self.watch_data.lock().await })
        })
    }

    /// 获取最新回传数据（异步）
    pub async fn get_watch_data(&self) -> WatchData {
        *self.watch_data.lock().await
    }

    /// 由接收任务调用，更新回传数据
    pub(crate) async fn update_watch_data(&self, data: WatchData) {
        *self.watch_data.lock().await = data;
    }
}
