use pyo3::exceptions::PyIOError;
use pyo3::prelude::*;
mod comm;
mod core;
mod instance;
mod runtime;

use comm::can::{CanDeviceAsync, CanDeviceSync};
use core::{
    block_all, block_until, get_task_manager, precision_timer, run_async, shutdown_all,
    timer_decorator, AsyncHandle, PrecisionTimer, PyTaskManager, RunAsync, Timer, TimerHandle,
    TimerWrapper,
};
use instance::motor::{device::Device as RustDevice, protocol::FocControlMode, Motor as RustMotor};
use std::sync::Arc;

/// 简单模式 CAN 设备（阻塞 API）
///
/// 这个版本使用同步 API，适合简单场景
#[pyclass]
struct CanDevice {
    inner: CanDeviceSync,
}

#[pymethods]
impl CanDevice {
    /// Create a new CAN device (simple/blocking mode)
    ///
    /// Args:
    ///     interface: CAN interface name (e.g., "can0")
    #[new]
    fn new(interface: &str) -> PyResult<Self> {
        let inner = CanDeviceSync::new(interface).map_err(|e| PyIOError::new_err(e.to_string()))?;
        Ok(Self { inner })
    }

    /// Send a CAN frame (blocking)
    ///
    /// Args:
    ///     id: CAN frame ID
    ///     data: Data bytes to send (up to 8 bytes)
    fn send(&mut self, id: u32, data: Vec<u8>) -> PyResult<()> {
        self.inner
            .send(id, &data)
            .map_err(|e| PyIOError::new_err(e.to_string()))
    }

    /// Receive a CAN frame (blocking)
    ///
    /// Returns:
    ///     Tuple of (id, data) where id is u32 and data is bytes
    fn receive(&mut self) -> PyResult<(u32, Vec<u8>)> {
        self.inner
            .receive()
            .map_err(|e| PyIOError::new_err(e.to_string()))
    }

    /// Get the interface name
    fn interface(&self) -> &str {
        self.inner.interface()
    }
}

/// 高级异步 CAN 设备（非阻塞 API）
///
/// 使用后台 Tokio 任务处理 CAN 通信，提供非阻塞 API
#[pyclass]
struct CanDeviceNonBlocking {
    inner: CanDeviceAsync,
}

#[pymethods]
impl CanDeviceNonBlocking {
    /// Create a new CAN device with background task
    ///
    /// Args:
    ///     interface: CAN interface name (e.g., "can0")
    #[new]
    fn new(interface: &str) -> PyResult<Self> {
        let inner =
            CanDeviceAsync::new(interface).map_err(|e| PyIOError::new_err(e.to_string()))?;
        Ok(Self { inner })
    }

    /// Send a CAN frame (non-blocking)
    ///
    /// Args:
    ///     id: CAN frame ID
    ///     data: Data bytes to send (up to 8 bytes)
    fn send(&self, id: u32, data: Vec<u8>) -> PyResult<()> {
        self.inner
            .send_nonblocking(id, data)
            .map_err(|e| PyIOError::new_err(e.to_string()))
    }

    /// Try to receive a CAN frame (non-blocking)
    ///
    /// Returns:
    ///     Tuple of (id, data) if message available, None otherwise
    fn try_receive(&self) -> Option<(u32, Vec<u8>)> {
        self.inner.try_receive().map(|msg| (msg.id, msg.data))
    }

    /// Receive a CAN frame with timeout
    ///
    /// Args:
    ///     timeout_ms: Timeout in milliseconds
    ///
    /// Returns:
    ///     Tuple of (id, data) if message received, None if timeout
    fn receive_timeout(&self, timeout_ms: u64) -> Option<(u32, Vec<u8>)> {
        self.inner
            .receive_timeout(timeout_ms)
            .map(|msg| (msg.id, msg.data))
    }

    /// Get the interface name
    fn interface(&self) -> &str {
        self.inner.interface()
    }
}

/// 广播组中单个电机驱动器的收发管理单元
///
/// 通过 `Motor.add_device()` 创建，持有该对象后可随时：
/// - 调用 `set_target(value)` 设置下次广播的目标值
/// - 调用 `get_watch_data()` 读取最新回传数据
///
/// 广播帧格式（8 字节，4 × i16 little-endian）：
/// - [0..2] slot 0，[2..4] slot 1，[4..6] slot 2，[6..8] slot 3
#[pyclass]
struct Device {
    inner: Arc<RustDevice>,
}

#[pymethods]
impl Device {
    /// 设置目标值（物理量）
    ///
    /// Args:
    ///     value: 目标值
    ///       - Current 模式：安培 (A)
    ///       - Speed   模式：弧度/秒 (rad/s)
    ///       - Position 模式：弧度 (rad)
    ///
    /// 该值在下次 `Motor.broadcast()` 时编码为 i16 写入广播帧。
    ///
    /// Example:
    ///     >>> device.set_target(10.0)
    fn set_target(&self, value: f32) {
        self.inner.set_target(value);
    }

    /// 读取当前目标值
    fn get_target(&self) -> f32 {
        self.inner.get_target()
    }

    /// 获取最新回传数据
    ///
    /// Returns:
    ///     dict with keys: ``position`` (rad), ``speed`` (rad/s), ``current`` (A)
    ///
    /// Example:
    ///     >>> data = device.get_watch_data()
    ///     >>> print(f"pos={data['position']:.3f} rad, spd={data['speed']:.2f} rad/s")
    fn get_watch_data(&self) -> PyResult<pyo3::Py<pyo3::types::PyDict>> {
        use pyo3::Python;
        let wd = self.inner.get_watch_data_blocking();
        Python::attach(|py| {
            let dict = pyo3::types::PyDict::new(py);
            dict.set_item("position", wd.position)?;
            dict.set_item("speed", wd.speed)?;
            dict.set_item("current", wd.current)?;
            Ok(dict.unbind())
        })
    }

    /// 槽位索引（0–3）
    #[getter]
    fn slot_index(&self) -> u8 {
        self.inner.slot_index
    }

    /// 回传帧 CAN ID
    #[getter]
    fn feedback_id(&self) -> u32 {
        self.inner.feedback_id
    }

    fn __repr__(&self) -> String {
        format!(
            "Device(slot={}, feedback_id=0x{:X}, target={:.4})",
            self.inner.slot_index,
            self.inner.feedback_id,
            self.inner.get_target()
        )
    }
}

/// 广播式电机控制器
///
/// 一个 Motor 对应一路 CAN 接口。通过 `add_device()` 注册最多 4 个驱动器，
/// 每次调用 `broadcast()` 将所有驱动器的目标值打包成一条 CAN 帧广播出去。
///
/// Example:
///     >>> motor = Motor("can0", broadcast_id=0x100)
///     >>> d1 = motor.add_device(slot_index=0, feedback_id=0x201, mode="speed")
///     >>> d2 = motor.add_device(slot_index=1, feedback_id=0x202, mode="speed")
///     >>> d1.set_target(10.0)   # 10 rad/s
///     >>> d2.set_target(-5.0)
///     >>> motor.broadcast()     # 一帧搞定两个驱动器
#[pyclass]
struct Motor {
    inner: RustMotor,
}

fn parse_foc_mode(mode: &str) -> PyResult<FocControlMode> {
    match mode.to_lowercase().as_str() {
        "current" => Ok(FocControlMode::Current),
        "speed" => Ok(FocControlMode::Speed),
        "position" => Ok(FocControlMode::Position),
        other => Err(pyo3::exceptions::PyValueError::new_err(format!(
            "unknown mode '{}', expected 'current', 'speed', or 'position'",
            other
        ))),
    }
}

#[pymethods]
impl Motor {
    /// 创建广播式电机控制器
    ///
    /// Args:
    ///     interface:    CAN 接口名称（例如 ``"can0"``）
    ///     broadcast_id: 广播控制帧的 CAN ID
    ///
    /// Example:
    ///     >>> motor = Motor("can0", broadcast_id=0x100)
    #[new]
    fn new(interface: &str, broadcast_id: u32) -> PyResult<Self> {
        let inner = RustMotor::new(interface, broadcast_id)
            .map_err(|e| PyIOError::new_err(e.to_string()))?;
        Ok(Self { inner })
    }

    /// 向广播组添加一个驱动器
    ///
    /// Args:
    ///     slot_index:  广播帧槽位（0–3），须与驱动器固件中的 ``target_index`` 一致
    ///     feedback_id: 驱动器回传帧的 CAN ID
    ///     mode:        FOC 控制模式字符串，可选 ``"current"`` / ``"speed"`` / ``"position"``
    ///
    /// Returns:
    ///     Device 实例，持有后可设置目标值并读取回传数据
    ///
    /// Example:
    ///     >>> d = motor.add_device(slot_index=0, feedback_id=0x201, mode="speed")
    fn add_device(
        &self,
        slot_index: u8,
        feedback_id: u32,
        mode: &str,
    ) -> PyResult<Device> {
        let foc_mode = parse_foc_mode(mode)?;
        let inner = self.inner.add_device(slot_index, feedback_id, foc_mode);
        Ok(Device { inner })
    }

    /// 通过槽位索引直接设置目标值
    ///
    /// Args:
    ///     slot_index: 广播帧槽位（0–3）
    ///     value:      目标值（物理量，与 Device 的 mode 对应）
    ///
    /// 若该槽位尚未注册 Device，调用将被忽略。
    ///
    /// Example:
    ///     >>> motor.set_target(0, 10.0)   # slot 0 → 10 rad/s
    ///     >>> motor.set_target(1, -5.0)   # slot 1 → -5 rad/s
    ///     >>> motor.broadcast()
    fn set_target(&self, slot_index: u8, value: f32) {
        self.inner.set_target(slot_index, value);
    }

    /// 将所有 Device 的目标值打包成一条 CAN 广播帧并发送
    ///
    /// 帧格式：8 字节，4 × i16 little-endian；未注册的槽位填 0。
    ///
    /// Example:
    ///     >>> motor.broadcast()
    fn broadcast(&self) -> PyResult<()> {
        self.inner
            .broadcast()
            .map_err(|e| PyIOError::new_err(e.to_string()))
    }

    /// 通过槽位索引获取回传数据
    ///
    /// Args:
    ///     slot_index: 广播帧槽位（0–3）
    ///
    /// Returns:
    ///     dict with keys ``position`` (rad), ``speed`` (rad/s), ``current`` (A)，
    ///     若该槽位未注册则返回 ``None``
    ///
    /// Example:
    ///     >>> data = motor.get_watch_data(0)
    ///     >>> print(f"pos={data['position']:.3f}, spd={data['speed']:.2f}")
    fn get_watch_data(&self, slot_index: u8) -> PyResult<Option<pyo3::Py<pyo3::types::PyDict>>> {
        use pyo3::Python;
        let Some(wd) = self.inner.get_watch_data(slot_index) else {
            return Ok(None);
        };
        Python::attach(|py| {
            let dict = pyo3::types::PyDict::new(py);
            dict.set_item("position", wd.position)?;
            dict.set_item("speed", wd.speed)?;
            dict.set_item("current", wd.current)?;
            Ok(Some(dict.unbind()))
        })
    }

    /// 广播控制帧 CAN ID
    #[getter]
    fn broadcast_id(&self) -> u32 {
        self.inner.broadcast_id()
    }

    fn __repr__(&self) -> String {
        format!(
            "Motor(broadcast_id=0x{:X}, devices={})",
            self.inner.broadcast_id(),
            self.inner.devices().len()
        )
    }
}

/// A Python module implemented in Rust.
#[pymodule]
mod cawlib {
    #[pymodule_export]
    use super::{
        AsyncHandle, CanDevice, CanDeviceNonBlocking, Device, Motor, PrecisionTimer,
        PyTaskManager, RunAsync, Timer, TimerHandle, TimerWrapper,
    };

    /// 普通定时器装饰器（精度约 1-10ms）
    ///
    /// 以固定频率重复执行被装饰的函数
    ///
    /// Args:
    ///     frequency_hz: 执行频率（Hz）
    ///
    /// Example:
    ///     >>> @timer(10.0)  # 每秒执行 10 次
    ///     ... def update():
    ///     ...     print("tick")
    ///     ...
    ///     >>> handle = update()  # 启动定时器
    ///     >>> handle.stop()       # 停止定时器
    #[pymodule_export]
    use super::timer_decorator;

    /// 高精度定时器装饰器（精度约 10-100μs）
    ///
    /// Args:
    ///     frequency_hz: 执行频率（Hz）
    ///     realtime: 是否使用实时模式（独立线程，精度最高但 CPU 密集）
    ///
    /// Example:
    ///     >>> @precision_timer(100.0)  # 高精度模式
    ///     ... def control():
    ///     ...     pass
    ///     ...
    ///     >>> @precision_timer(1000.0, realtime=True)  # 1kHz 实时模式
    ///     ... def realtime_control():
    ///     ...     pass
    #[pymodule_export]
    use super::precision_timer;

    /// 异步任务装饰器
    ///
    /// 将被装饰的函数放到独立的异步任务中执行
    ///
    /// Example:
    ///     >>> @run_async
    ///     ... def heavy_task(x):
    ///     ...     import time
    ///     ...     time.sleep(1)
    ///     ...     return x * 2
    ///     ...
    ///     >>> handle = heavy_task(21)
    ///     >>> result = handle.wait()  # 等待结果: 42
    #[pymodule_export]
    use super::run_async;

    /// 获取全局任务管理器
    ///
    /// Returns:
    ///     TaskManager: 全局任务管理器实例
    ///
    /// Example:
    ///     >>> manager = get_task_manager()
    ///     >>> print(manager.running_count)
    #[pymodule_export]
    use super::get_task_manager;

    /// 优雅关闭所有任务
    ///
    /// Args:
    ///     timeout_ms: 超时时间（毫秒），None 表示无限等待
    ///
    /// Returns:
    ///     bool: 如果所有任务完成返回 True，超时返回 False
    ///
    /// Example:
    ///     >>> shutdown_all(timeout_ms=5000)
    #[pymodule_export]
    use super::shutdown_all;

    /// 阻塞等待系统退出信号，然后优雅关闭所有任务
    ///
    /// 此函数会阻塞当前线程，直到收到系统退出信号（SIGINT/Ctrl+C 或 SIGTERM），
    /// 然后自动执行优雅关闭。
    ///
    /// Args:
    ///     timeout_ms: 收到信号后等待任务完成的超时时间（毫秒）
    ///
    /// Returns:
    ///     str: 收到的信号名称
    ///
    /// Example:
    ///     >>> handle = my_timer()
    ///     >>> signal = block_all(timeout_ms=5000)  # 阻塞直到 Ctrl+C
    ///     >>> print(f"Received {signal}")
    #[pymodule_export]
    use super::block_all;

    /// 阻塞等待指定时间或退出信号，然后优雅关闭
    ///
    /// Args:
    ///     wait_ms: 最长等待时间（毫秒），None 表示无限等待
    ///     shutdown_timeout_ms: 关闭时等待任务完成的超时时间（毫秒）
    ///
    /// Returns:
    ///     tuple: (原因, 是否成功关闭)
    ///
    /// Example:
    ///     >>> reason, success = block_until(wait_ms=10000)  # 最多运行 10 秒
    #[pymodule_export]
    use super::block_until;
}
