# Building Intuitions Towards Evaluation Metrics for NLP Tasks

If you've ever felt overwhelmed by the alphabet soup of evaluation metrics in NLP—BLEU, ROUGE, F1, precision, recall—you're not alone. Most learning materials dive straight into formulas and technical definitions, which is great for quick reference during implementation or interview prep. But this approach often leaves us memorizing metrics without truly understanding when and why to use them.

Whether you're a data scientist just starting with NLP, part of a newly formed AI team, or simply looking for a clearer understanding of evaluation fundamentals, this article takes a different approach. Instead of starting with formulas, we'll build intuition through practical scenarios and real-world contexts. By the end, you'll understand not just what these metrics calculate, but when they matter and why they were designed the way they are.

## Starting Simple: The Foundation Question

Imagine you've just finished collecting 100 outputs from your language model, complete with a perfect ground truth dataset. You're ready to evaluate performance, but first you need to answer a fundamental question:

**"How good is the model?"**

To answer this, we need to break down what "good" actually means in concrete terms.

### The Naive Approach: Overall Accuracy

The most intuitive answer might be: "The model should get things right. More correct outputs = better model, fewer errors = better performance." If we assume exact matches with our ground truth, this gives us:

**Accuracy = (Number of correct outputs) ÷ (Total number of samples)**

Getting 100% accuracy would be ideal, but in the real world, models make mistakes. However, a model can still be excellent even with seemingly poor overall accuracy. Here's why.

## A Real-World Scenario: Hate Speech Detection

Let's add crucial context to our 100 outputs. Imagine we're building a system to detect hate speech in Reddit comments. We care primarily about catching `negative` (hateful) content, rather than perfectly classifying `positive` or `neutral` comments.

Here's a sample of what we might see:

| Sample | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 |
|--------|---|---|---|---|---|---|---|---|---|-----|
| **Ground truth** | **negative** | positive | neutral | neutral | neutral | positive | **negative** | positive | neutral | neutral |
| **Model output** | **negative** | neutral | positive | positive | positive | neutral | **negative** | neutral | positive | positive |

**Overall accuracy:** 2/10 = 20%

At first glance, this looks terrible! But look closer: the model successfully identified **both** instances of hate speech, which is exactly what we care about for this application. While it completely failed to distinguish between neutral and positive comments, it's **catching all the content that matters most**.

This suggests we need a more focused evaluation approach. Instead of looking at overall accuracy, let's **focus on the specific type of content we care about most**. This leads us to our first key question:

### Metric #1: "Did we catch everything important?"

"Of all the hate speech in our dataset, what fraction did the model successfully identify?"

**(Correct predictions of target type) ÷ (Total actual instances of target type) = 2 ÷ 2 = 100%**

This metric tells us about the model's ability to find what we're looking for.

## When One Metric Isn't Enough: Comparing Models

Now let's compare two different models on the same task:

| Sample | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 |
|--------|---|---|---|---|---|---|---|---|---|-----|
| **Ground truth** | **negative** | positive | neutral | neutral | neutral | positive | **negative** | positive | neutral | neutral |
| **Model 1 output** | **negative** | neutral | positive | positive | positive | neutral | **negative** | neutral | positive | positive |
| **Model 2 output** | **negative** | **negative** | **negative** | positive | **negative** | neutral | **negative** | neutral | positive | positive |

Using our "catch everything important" metric from above:

**Model 1:** 2/2 = 100%
**Model 2:** 2/2 = 100%

Both models score perfectly! But this doesn't tell the whole story. Model 2 is flagging many non-hateful comments as hate speech—a serious problem that would frustrate users and potentially suppress legitimate discourse.

### Metric #2: "When we flag something, are we right?"

This brings us to our second key question: "Of all the hate speech predictions our model made, what fraction were actually correct?"

**(Correct predictions of target type) ÷ (Total predictions of target type)**

Let's calculate this for both models:

**Model 1:** 2/2 = 100%
**Model 2:** 2/5 = 40%

Now we can clearly see that Model 1 performs much better than Model 2, since it doesn't generate any false alarms for hate speech detection.

### But Can Our Second Metric Replace Our First Metric?

You might wonder if our second metric alone is sufficient. Let's test this with a third model:

| Sample | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 |
|--------|---|---|---|---|---|---|---|---|---|-----|
| **Ground truth** | **negative** | positive | neutral | neutral | neutral | positive | **negative** | positive | neutral | neutral |
| **Model 1 output** | **negative** | neutral | positive | positive | positive | neutral | **negative** | neutral | positive | positive |
| **Model 3 output** | **negative** | neutral | positive | positive | positive | neutral | positive | neutral | positive | positive |

**Model 1:** 2/2 = 100%
**Model 3:** 1/1 = 100%

Both models score perfectly on our second metric, but Model 3 only caught **half** of the actual hate speech in our dataset. This shows us that **both metrics matter**—we need models that are both accurate when they make predictions and thorough in finding what we're looking for.

## Bringing It Together: A Combined Score

In practice, it's rare for a model to achieve 100% on both metrics. We often need to make trade-offs, and we want a single metric that balances both concerns. Since both metrics are rates (fractions), we use the harmonic mean rather than the arithmetic mean to combine them:

**2 × (First Metric × Second Metric) ÷ (First Metric + Second Metric)**

The harmonic mean gives **equal weight to both metrics** and is particularly sensitive to low values—if either metric is poor, the combined score will be poor too.

## The History Behind the Names

Now that we've built intuition for these concepts, let's connect them to their historical origins:

The first metric—our "did we catch everything important?" question—is called **Recall**. The second metric—our "when we flag something, are we right?" question—is called **Precision**. Both were first coined by Cyril Cleverdon in the 1960s during the Cranfield information-retrieval experiments. He needed ways to quantify how well document retrieval systems performed: precision measured the "exactness" of retrieved documents (were the retrieved documents actually relevant?), while recall measured "completeness" (did we find all the relevant documents?).

**The F1 Score** comes from the F_β effectiveness function defined by C. J. van Rijsbergen in his 1979 book *Information Retrieval*. The "F1" is simply the case where β = 1, giving equal weight to precision and recall. This metric was later popularized by the 1992 MUC-4 evaluation conference and became standard in NLP evaluation.

## Beyond Binary Classification: When Exact Matches Aren't Enough

Our hate speech example used binary classification with exact matches—either a comment was hate speech or it wasn't. But many NLP tasks involve more nuanced evaluation where exact matches don't capture the full picture.

Consider these scenarios:

- **Machine Translation**: "The cat sat on the mat" vs "A cat was sitting on the mat" - different words, similar meaning
- **Text Summarization**: Multiple valid ways to summarize the same document
- **Information Retrieval**: Output is a ranked list of documents, not a single prediction
- **Sentiment Analysis**: Multi-class outputs (positive, negative, neutral, mixed) with confidence scores

For these tasks, we can't simply use true/false differentiation because:
- **Translation**: Perfect word matches are too strict—good translations can use different words
- **Summarization**: Many correct summaries exist for the same source text
- **Information Retrieval**: We're evaluating an entire ranked list, not just one prediction
- **Multi-class tasks**: "Correct" and "wrong" don't capture partial credit when the model was close

This means our evaluation formulas have to **evolve and mutate** to fit these more complex scenarios. Let's explore a few examples to see how the same underlying precision/recall thinking adapts:

### Translation Tasks: BLEU Score

Remember our second metric: "When we flag something, are we right?" For translation, this becomes: "When our model produces words, how many have similar meaning to the reference translation?"

BLEU applies our second metric's thinking to translation by asking: "What fraction of the words and phrases in our translation actually appear in the reference?"

**Example:** 
- **Reference:** "The cat sat on the mat"
- **Model output:** "A cat was sitting on the mat"
- **Word-level matches:** cat, on, the, mat all appear in reference (4 out of 6 model words = 67%)
- **Phrase-level matches:** "on the", "the mat" both appear in reference (2 out of 5 possible phrases = 40%)

BLEU builds on our second metric by checking matches at both word and phrase levels—just like how we checked individual predictions in our hate speech example, but now applied to language generation.

**BLEU = BP × exp((1/N) × Σ log pₙ)**

where pₙ is the precision of n-grams and BP is a brevity penalty for short translations.

### Summarization Tasks: ROUGE Score

Now let's flip to our first metric: "Did we catch everything important?" For summarization, this becomes: "Did our summary capture the key information from the reference?"

ROUGE applies our first metric's thinking to summaries by asking: "What fraction of the important words and concepts from the reference summary appear in our model's summary?"

**Example:**
- **Reference summary:** "The study shows exercise improves mental health"
- **Model summary:** "Exercise helps mental health according to research"
- **Word-level coverage:** exercise, mental, health appear in model summary (3 out of 7 reference words = 43%)
- **Concept coverage:** The core idea "exercise improves mental health" is captured, even with different wording

ROUGE focuses on our first metric because a good summary should **capture the essential information** from the reference, just like how our hate speech detector needed to **catch all the problematic content**. The exact wording matters less than covering the key points.

**ROUGE-N = (Σ Countₘₐₜcₕ(gramₙ)) ÷ (Σ Count(gramₙ))**

where gramₙ refers to n-grams and Countₘₐₜcₕ counts n-grams that appear in both candidate and reference summaries.

### Information Retrieval: Evaluating Ranked Lists

For search and ranking, we're not evaluating a single prediction—we're evaluating an entire **ranked list** of results. Both our fundamental questions apply, but with a twist: "Of the first 10 results, how many are actually relevant?" and "Of all the relevant documents, how many appear in the top 10?"

Since we're dealing with lists, we adapt our metrics to focus on the top results (where users actually look):

**Example:** Searching for "machine learning papers"
- **Top 10 results:** 7 are actually about ML, 3 are irrelevant  
- **Total relevant papers in database:** 100 papers total
- **First metric @10:** 7/100 = 7% (we're only catching 7% of all the good papers)
- **Second metric @10:** 7/10 = 70% (when we show a result, we're right 70% of the time)

This is exactly the same thinking as our hate speech detection! The metrics help us balance: don't frustrate users with irrelevant results vs. don't miss important documents. The "@10" part just acknowledges that users typically only look at the first page of results.

**Precision@K = (Number of relevant documents in top K results) ÷ K**

**Recall@K = (Number of relevant documents in top K results) ÷ (Total number of relevant documents)**

## Key Takeaways

1. **Context drives metric choice**: The same model might need different evaluation approaches depending on whether you're detecting fraud (recall-focused) or filtering spam (precision-focused).

2. **No single metric tells the whole story**: Precision and recall capture different aspects of performance, and metrics like F1 help balance multiple concerns.

3. **Task complexity demands specialized metrics**: As NLP tasks moved beyond exact matching, metrics evolved to handle fuzzy matching (BLEU), content overlap (ROUGE), and ranking (Precision@K).

4. **Historical context illuminates design choices**: Understanding why metrics were created—from Cleverdon's document retrieval to van Rijsbergen's effectiveness functions—helps us choose the right tool for each job.

The next time you encounter an unfamiliar evaluation metric, try asking: What aspect of model performance is this trying to capture? What real-world problem was it designed to solve? Starting with these questions will help you build intuition much faster than memorizing formulas alone.

## What's Next: Beyond Single Correct Answers

In this article, we've explored how precision and recall thinking adapts to different NLP tasks. 

In our next exploration, we'll move beyond the comfortable world of binary classification into the messy, nuanced reality of human judgment—where the most interesting AI applications actually live. We'll dive into evaluation strategies including similarity-based approaches, alternative judging methods, and frameworks for handling contexts where "correct" is inherently pluralistic.
---

*Want to connect or learn more about me? Visit [here](http://arthurcho.notion.site/)*
