# Buil## Starting Si### The Naive Approach: OverThis suggests we need a more focused evaluation approach. Instead of looking at overall accuracy, let's **focus on the specific type of content we care about most**. This leads us to our first key question:

### Metric #1: "Did we catch everything important?"

"Of all the hate speech in our dataset, what fraction did the model successfully identify?"

$$\text{Recall} = \frac{\text{Correct predictions of target type}}{\text{Total actual instances of target type}} = \frac{2}{2} = 100\%$$

This metric tells us about the model's **completeness**—its ability to find what we're looking for.ccuracy

The most intuitive answer might be: "The model should get things right. More correct outputs = better model, fewer errors = better performance." If we assume exact matches with our ground truth, this gives us:

$$\text{Accuracy} = \frac{\text{Number of correct outputs}}{\text{Total number of samples}}$$

Getting 100% accuracy would be ideal, but in the real world, models make mistakes. However, a model can still be excellent even with seemingly poor overall accuracy. Here's why.he Foundation Question

Imagine you've just finished collecting 100 outputs from your language model, complete with a perfect ground truth dataset. You're ready to evaluate performance, but first you need to answer a fundamental question:

**"How good is the model?"**

To answer this, we need to break down what "good" actually means in concrete terms.tuitions Towards Evaluation Metrics for NLP Tasks

If you've ever felt overwhelmed by the alphabet soup of evaluation metrics in NLP—BLEU, ROUGE, F1, precision, recall—you're not alone. Most learning materials dive straight into formulas and technical definitions, which is great for quick reference during implementation or interview prep. But this approach often leaves us memorizing metrics without truly understanding when and why to use them.

Whether you're a data scientist just starting with NLP, part of a newly formed AI team, or simply looking for a clearer understanding of evaluation fundamentals, this article takes a different approach. Instead of starting with formulas, we'll build intuition through practical scenarios and real-world contexts. By the end, you'll understand not just what these metrics calculate, but when they matter and why they were designed the way they are.

Imagine you have collected 100 outputs from a large language model, with a perfect quality ground truth dataset for it.

First, what do you want to measure? let’s break down this question:

*“How good is the model?”*

To break it down, we need to define and quantify “good”:

Is the model getting things right? All the outputs from the model should be correct. The more correct outputs, the better the model; the less errors the better. (here we can assume an “exact match” with the ground truth set.):

*formula 1*

Accuracy = No. of ALL correct outputs/ No. of ALL references (entire sample)

Getting 100% accuracy is very ideal. In the real world, there is going to be **wrong** outputs from the model(`False` labels). But the model may still be getting all things right. Why so?

## A Real-World Scenario: Hate Speech Detection

Let's add crucial context to our 100 outputs. Imagine we're building a system to detect hate speech in Reddit comments. We care primarily about catching `negative` (hateful) content, rather than perfectly classifying `positive` or `neutral` comments.

Here's a sample of what we might see:

**Ground truth:** [**negative**, positive, neutral, neutral, neutral, positive, **negative**, positive, neutral, neutral]

**Model output:** [**negative**, neutral, positive, positive, positive, neutral, **negative**, neutral, positive, positive]

**Overall accuracy:** 2/10 = 20%

At first glance, this looks terrible! But look closer: the model successfully identified **both** instances of hate speech, which is exactly what we care about for this application. While it completely failed to distinguish between neutral and positive comments, it's **catching all the content that matters most**.

“Of all the references of that type, what fraction did the model find?”

*formula 2*

No. of correct outputs of a certain type/ No. of references of that type = 2/2 = 100%

Let’s add more context to this scenario- now, we need to compare the performance of 2 different models:

references: [**negative**, positive, neutral, neutral, neutral, positive, **negative,** positive, neutral, neutral]

model 1 outputs: [**negative**, neutral, positive, positive, positive, neutral, **negative,** neutral, positive, positive]

model 2 outputs: [**negative**, negative, negative, positive, negative, neutral, **negative,** neutral, positive, positive]

Let’s calculate their scores based on the formula above: 

Model 1:

No. of correct outputs of a certain type/ No. of references of that type = 2/2 = 100%

Model 2:

No. of correct outputs of a certain type/ No. of references of that type = 2/2 = 100%

The scores are the same. Can we say this is a tied? If we look at the outputs from model 2, many of them are `negative` . It means that model 2 will flag posts with negative sentiments even if they are not- compared to model 1, this cannot be considered a “good” model. In this case, we have to consider **switching the sample from reference level to output level:**

*formula 3*

No. of correct outputs for a certain type/ No. of outputs of that type

Model 1:

No. of correct outputs for a certain type/ No. of outputs of that type = 2/2 = 100%

Model 2:

No. of correct outputs for a certain type/ No. of outputs of that type = 2/5 = 40%

That way, when we compare the scores, we have a clear idea that Model 1 performs way better than Model 2, since it does not generate **any wrong `negative` labels.**

Can this formula replace the reference-level sample formula? Let’s look at another example:

references: [**negative**, positive, neutral, neutral, neutral, positive, **negative,** positive, neutral, neutral]

model 1 outputs: [**negative**, neutral, positive, positive, positive, neutral, **negative,** neutral, positive, positive]

model 3 outputs: [**negative**, neutral, positive, positive, positive, neutral, positive**,** neutral, positive, positive]

Model 1:

No. of correct outputs for a certain type/ No. of outputs of that type = 2/2 = 100%

Model 3:

No. of correct outputs for a certain type/ No. of outputs of that type = 1/1 = 100%

The simple answer is **no**. Even if the scores of both models are 100%, Model 3 could not **catch all `negative` labels** from the references.

Going back to our original question:

*“How good is the model?”*

Based on what we have explored so far, we can say that when we need to **focus** on evaluating the quality of **specific output type(s)** other than getting all things right (100% accuracy), a model is also “good enough” if all **references** of certain type(s) can **get caught by the model (**validated by *formula 2)*, and all **model outputs** of certain type(s) are **correct** (validated by *formula 3*).

And again, in reality, its not very common for a model to score 100% in both formula 2 and 3. We can create a composite metric from both scores. Since the 2 scores are rates in nature, we apply harmonic mean instead of arithmetic mean:

\text{HM} = \frac{n}{\sum_{i=1}^{n} \frac{1}{r_i}}

This gives **equal weight to the denominator** of the rate (e.g., each kilometer or unit), not to the rate itself.

*formula 4*

2 x (formula 2 score x formula 3 score)/formula 2 score + formula 3 score

Please note that I have not shared any names for the formula, because we do not want to fall into terms/ formula cramming or reciting when we are building our intuitions. Now its time to introduce them:

The formula 2 metric has the nature of indicating the level of **precision** from model outputs.

In data science domain, formula which share the same nature are coined with the word precision.

The formula 3 metric has the nature of the model’s ability to “catch/ **recall**” from references.

In data science domain, formula which share the same nature are coined with the word **recall**.

In other learning resources, you may come across with the term “exactness of model” for precision and “completeness of model” for recall, though I personally think these terms oversimplify the true meaning behind and may cause confusions.

These 2 terms are coined by Cyril Cleverdon in the Cranfield information-retrieval experiments to quantify the exactness of retrieved documents. 

The formula 4 metric is inherently called “F-1 score”, defined as the F_{\beta} effectiveness function by C. J. van Rijsbergen in his 1979 book *Information Retrieval* (β = 1 case), later branded the “F-measure” and popularized by the 1992 MUC-4 evaluation. 

How to describe correct/ wrong outputs? In the data domain, “True” means output is correct, “False” means output is wrong. You should have already come across with **false positives** since we all survived from the Covid-19 pandemic. Here, the word positive(or negative) means that we are receive “binary” outputs from the model. 

However, NLP tasks have different output types - take a step back from our hate speech detection task, the outputs that we collect from the model can be binary data(spam detection), multiple class with continuous score(sentiment analysis), generated word sequences (machine translation), or it could be a list of results (information retrieval). In the beginning, we assumed there’s only correct or wrong ( `true` or `false` ) for all outputs and they were defined by whether there’s an exact match with the reference (ground truth) set, but in reality, that’s not the case.

There are many measuring methods that go beyond true or false differentiation. We are not going to go through them different calculation methods one by one, yet this reminds us that in many cases, we could not put the number of “right” or “wrong” items and calculate accuracy/ precision/ recall. The evaluation formula/ metrics has to be **mutated:**

Example of translation task:

[formula]

[Explain]

Example of summarization task:

[formula]

[Explain]

Example of information retrieval task:

[formula]

[Explain]

[Recap]

[Conclusion]