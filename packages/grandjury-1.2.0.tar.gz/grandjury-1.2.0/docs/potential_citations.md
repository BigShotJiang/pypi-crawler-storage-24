Topic / claim in the draft
Author & title (year) → URL
Why it’s the right citation
modern generative models powering diverse tasks
Brown et al. “Language Models are Few-Shot Learners” (2020) → https://arxiv.org/abs/2005.14165
GPT-3 is the canonical evidence that scaling LLMs unlocks broad task-transfer 
LLMs behind enterprise-scale assistants & workflow automation
Wornow et al. “Automating the Enterprise with Foundation Models” (PVLDB 2024) → https://arxiv.org/abs/2405.03710
Demonstrates GPT-4-class FMs automating real hospital & business workflows 
dialog-oriented LLM capability
Thoppilan et al. “LaMDA: Language Models for Dialog Applications” (2022) → https://arxiv.org/abs/2201.08239
Google’s flagship work on conversation-specialised LLMs 
need to keep multiple “acceptable” answers (disagreement)
Basile et al. “We Need to Consider Disagreement in Evaluation” (2021) → https://pure.itu.dk/files/86006947/BPPF_21_Position_Paper_basile_et_al.pdf
Position paper arguing gold-label pluralism for NLP tasks 
low IAA & perspectives in subjective NLP
Uma et al. “Learning from Disagreement: A Survey” (JAIR 2021) → https://jair.org/index.php/jair/article/view/12752
Comprehensive survey covering annotator disagreement & perspectivism 
leaderboard chasing / benchmark pitfalls
Lipton & Steinhardt “Troubling Trends in Machine Learning Scholarship” (2018) → https://arxiv.org/abs/1807.03341
Classic critique of metric-driven research culture 
inherent limits of benchmarks for LLMs
Fodor “Line Goes Up? Inherent Limitations of Benchmarks for Evaluating LLMs” (2025) → https://arxiv.org/abs/2502.14318
Recent position paper detailing why soaring scores ≠ real ability 
generative-AI boom & GPT-4 capabilities
OpenAI “GPT-4 Technical Report” (2023) → https://arxiv.org/abs/2303.08774
Shows surge in capability & real-world adoption benchmarks 
classic BLEU metric citation
Papineni et al. “BLEU: a Method for Automatic Evaluation of MT” (2002) → https://aclanthology.org/P02-1040.pdf
Original BLEU definition; still the standard baseline
classic ROUGE metric citation
Lin “ROUGE: A Package for Automatic Evaluation of Summaries” (2004) → https://aclanthology.org/W04-1013.pdf
Source of ROUGE family used in summarisation
ROUGE / BLEU ↔ human-gap in summarisation
Fabbri et al. “SummEval: Re-Evaluating Summarization Evaluation” (TACL 2021) → https://aclanthology.org/2021.tacl-1.24/
Empirically shows weak corr. of ROUGE/BLEU with human judgements 
why NLG needs new metrics
Novikova et al. “Why We Need New Evaluation Metrics for NLG” (EMNLP 2017) → https://arxiv.org/abs/1707.06875
Early evidence that word-overlap metrics miss quality facets 
story-/dialogue metrics detach from humans
Liu et al. “How NOT to Evaluate Your Dialogue System” (2016) → https://arxiv.org/abs/1603.08023
Finds n-gram metrics barely correlate with human ratings in dialogue 
MMLU as flagship LLM benchmark
Hendrycks et al. “Measuring Massive Multitask Language Understanding” (ICLR 2021) → https://arxiv.org/abs/2009.03300
Defines the 57-task exam widely used in GPT-4 papers 
embedding-based metric BERTScore
Zhang et al. “BERTScore: Evaluating Text Generation with BERT” (ICLR 2020) → https://arxiv.org/abs/1904.09675
Token-embedding metric often adopted as modern alternative 
embedding-based metric MoverScore
Zhao et al. “MoverScore: Text Generation Evaluating with Contextualised Embeddings & EMD” (EMNLP 2019) → https://arxiv.org/abs/1909.02622
Semantic-distance metric across MT/sum/image-caption 
retrieval-augmented evaluation framework
Es et al. “RAGAS: Automated Evaluation of Retrieval-Augmented Generation” (ACL Demo 2024) → https://aclanthology.org/2024.eacl-demo.16/
First reference-free, multi-facet RAG evaluation suite 
community doubts around RAGAS stability
Reddit thread “Why is everyone using RAGAS for RAG evaluation?” (2025) → https://www.reddit.com/r/LangChain/comments/1bijg75/
Practitioners report unreliable scores; documents real concern 
LLMs as factual-consistency judges
Luo et al. “ChatGPT as a Factual Inconsistency Evaluator for Text Summarization” (2023) → https://arxiv.org/abs/2303.15621
Shows GPT-3.5/GPT-4 outperform QA- and NLI-based metrics 
LLM-as-Judge paradigm survey
Gu et al. “A Survey on LLM-as-a-Judge” (2024) → https://arxiv.org/abs/2411.15594
Comprehensive overview + reliability benchmark 
open-source judge model
Kim et al. “Prometheus: Inducing Fine-Grained Evaluation Capability in LLMs” (ICLR 2024) → https://arxiv.org/abs/2310.08491
13B model matching GPT-4 on correlation with humans 
scalable judge via fine-tuning
Zhu et al. “JudgeLM: Fine-Tuned Large Language Models are Scalable Judges” (2023) → https://arxiv.org/abs/2310.17631
Shows 7-33B models judging 5 k samples in minutes 
bias in judge models (length, self-preference…)
Park et al. “OffsetBias: Leveraging Debiased Data for Tuning Evaluators” (Findings EMNLP 2024) → https://aclanthology.org/2024.findings-emnlp.57.pdf
Defines six systematic biases & releases EvalBiasBench 
self-preference bias in GPT-4 judges
Wataoka et al. “Self-Preference Bias in LLM-as-a-Judge” (2024) → https://arxiv.org/abs/2410.21819
Quantifies GPT-4 favouring its own outputs 
constitutional alignment & HHH framing
Bai et al. “Constitutional AI: Harmlessness from AI Feedback” (2022) → https://arxiv.org/abs/2212.08073
Introduces the Helpful-Honest-Harmless paradigm for tuning evaluators 
disputed sentiment labels (κ < 0.3 example)
Kenyon-Dean et al. “Sentiment Analysis: It’s Complicated!” (EMNLP 2018) → https://aclanthology.org/N18-1171/
Finds >30 % tweets recieve conflicting crowd labels 
