"""CLI composition root."""
import json
import sys
from pathlib import Path

import click

from locram.adapters.db import init_db
from locram.adapters.sqlite_page_repo import SqlitePageRepository
from locram.config import DB_PATH, VAULT_PATH
from locram.entrypoints.server import main as _serve
from locram.services.link_service import LinkService
from locram.services.page_service import PageService
from locram.services.search_service import SearchService
from locram.vault.watcher import install_watcher, uninstall_watcher
from locram.vault.writer import ObsidianVaultStore


def make_services() -> tuple[
    SqlitePageRepository, ObsidianVaultStore, PageService, LinkService, SearchService
]:
    repo = SqlitePageRepository()
    vault = ObsidianVaultStore()
    return repo, vault, PageService(repo, vault), LinkService(repo, vault), SearchService(repo)


def out(data: object) -> None:
    click.echo(json.dumps(data, ensure_ascii=False, indent=2))


@click.group()
def main():
    """locram — local Zettelkasten for LLM agents."""


@main.command()
def serve():
    """Start the MCP stdio server."""
    _serve()


@main.command()
def init():
    """Create DB, vault directories, and Obsidian config."""
    init_db()
    vault = ObsidianVaultStore()
    vault.setup_obsidian()
    click.echo("locram initialised.")
    click.echo(f"  DB:    {vault.db_path}")
    click.echo(f"  Vault: {vault.vault_path}")
    click.echo()
    if sys.platform == "darwin":
        click.echo("Obsidian → DB sync requires the watcher:")
        click.echo("    locram watch-install   (macOS launchd, runs automatically)")
        click.echo("    locram sync            (manual, works everywhere)")
    else:
        click.echo("Obsidian → DB sync is manual on this platform:")
        click.echo("    locram sync            (run after editing in Obsidian)")


@main.command()
@click.option("--file", "file_path", default=None, help="Sync a single .md file.")
def sync(file_path: str | None) -> None:
    """Sync vault → DB. Full-vault reconcile by default (used by launchd watcher)."""
    init_db()
    vault = ObsidianVaultStore()
    path = Path(file_path) if file_path else None
    stats = vault.sync(path)
    out(stats)


@main.command("vault-rebuild")
def vault_rebuild():
    """Rebuild all .md files from DB (DB → vault)."""
    init_db()
    repo, vault, pages_svc, _, _ = make_services()
    records = repo.list_pages(status="active", limit=10000)
    count = 0
    for r in records:
        page = pages_svc.get_page(r["id"])
        if page:
            vault.write(page)
            count += 1
    click.echo(f"Rebuilt {count} notes.")


@main.command("watch-install")
def watch_install() -> None:
    """Install macOS launchd watcher (WatchPaths → debounced full sync)."""
    path = install_watcher()
    click.echo(f"Watcher installed: {path}")


@main.command("watch-uninstall")
def watch_uninstall() -> None:
    """Remove macOS launchd watcher."""
    uninstall_watcher()
    click.echo("Watcher removed.")


@main.command()
@click.option("--title", required=True)
@click.option("--content", default="")
@click.option("--type", "page_type", default="fleeting")
@click.option("--subject", multiple=True)
@click.option("--tag", multiple=True)
def create(title, content, page_type, subject, tag):
    """Create a note."""
    init_db()
    _, _, pages_svc, _, _ = make_services()
    page = pages_svc.create_page(
        title=title, content=content, type=page_type,
        subject=list(subject), tags=list(tag),
    )
    out({"id": page.id, "title": page.title, "type": page.type.value})


@main.command()
@click.argument("page_id")
def get(page_id):
    """Get a note by ID."""
    init_db()
    _, _, pages_svc, _, _ = make_services()
    page = pages_svc.get_page(page_id)
    if page is None:
        click.echo(f"Not found: {page_id}", err=True)
        sys.exit(1)
    out({
        "id": page.id, "title": page.title, "type": page.type.value,
        "status": page.status.value, "content": page.content,
        "connected_to": page.connected_to, "sub_items": page.sub_items,
    })


@main.command()
@click.argument("query")
@click.option("--limit", default=20)
def search(query, limit):
    """FTS5 full-text search."""
    init_db()
    _, _, _, _, search_svc = make_services()
    out(search_svc.search(query, limit=limit))


@main.command("list")
@click.option("--type", "page_type", default=None)
@click.option("--status", default=None)
@click.option("--limit", default=50)
def list_cmd(page_type, status, limit):
    """List notes."""
    init_db()
    repo, _, _, _, _ = make_services()
    out(repo.list_pages(type=page_type, status=status, limit=limit))


@main.command()
@click.argument("source_id")
@click.argument("target_id")
@click.option("--type", "link_type", default="related")
def link(source_id, target_id, link_type):
    """Create a typed link between two notes."""
    init_db()
    _, _, _, links_svc, _ = make_services()
    out(links_svc.link_pages(source_id, target_id, link_type))


@main.command()
def reset() -> None:
    """DELETE ALL DATA and recreate DB + vault from scratch."""
    click.confirm(
        "This will DELETE all notes, links, and vault files. Continue?",
        abort=True,
    )

    if DB_PATH.exists():
        DB_PATH.unlink()
        click.echo(f"Deleted {DB_PATH}")

    for f in VAULT_PATH.glob("*.md"):
        f.unlink()
    click.echo("Cleared vault .md files")

    init_db()
    vault = ObsidianVaultStore()
    vault.setup_obsidian()
    click.echo("locram reset complete.")


if __name__ == "__main__":
    main()
