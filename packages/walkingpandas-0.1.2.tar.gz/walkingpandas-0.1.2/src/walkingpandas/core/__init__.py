"""Core classes for Network and WalkFrame."""
