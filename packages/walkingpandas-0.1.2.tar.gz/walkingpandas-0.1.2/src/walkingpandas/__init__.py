"""
walkingpandas: A Python library for massive-scale mobility/traversal data analysis.

Bridges static graph theory (network topologies) with massive-scale mobility data
(walks/paths) using DuckDB as the analytical engine and Parquet as the storage layer.
"""

from ._utils import BoundingBox
from .core.network import Network
from .core.walk import WalkFrame
from .io.ingest import read_dataset, read_duckdb, write_duckdb, connect

__version__ = "0.1.0"

__all__ = [
    'BoundingBox',
    'Network',
    'WalkFrame',
    'read_dataset',
    'read_duckdb',
    'write_duckdb',
    'connect',
]
