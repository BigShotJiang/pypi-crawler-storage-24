"""Spatial filtering and optimization utilities."""
