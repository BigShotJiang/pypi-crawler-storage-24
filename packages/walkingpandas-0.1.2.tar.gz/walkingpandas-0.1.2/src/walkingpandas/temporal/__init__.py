"""Temporal query builders and edge analysis."""
