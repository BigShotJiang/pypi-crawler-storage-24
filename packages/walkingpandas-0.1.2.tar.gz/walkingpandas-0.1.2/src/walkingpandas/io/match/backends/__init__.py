"""
Map-matching backends.

Each backend implements the BaseMatcher interface (match_trajectory).
"""

from ..base import BaseMatcher
from .valhalla import ValhallaMatcher

__all__ = [
    "BaseMatcher",
    "ValhallaMatcher",
]
