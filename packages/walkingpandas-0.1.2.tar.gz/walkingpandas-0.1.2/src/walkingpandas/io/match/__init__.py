"""
Map-matching module.

Converts raw GPS trajectories into walkingpandas WalkFrames using
an efficient out-of-core streaming architecture and topological snapping.
"""

from .base import BaseMatcher
from .gps import GPSDataset
from .core import match_trajectories
from .backends.valhalla import ValhallaMatcher, decode_valhalla

__all__ = [
    "BaseMatcher",
    "GPSDataset",
    "match_trajectories",
    "ValhallaMatcher",
    "decode_valhalla",
]
