"""Graph validation and path analysis utilities."""
