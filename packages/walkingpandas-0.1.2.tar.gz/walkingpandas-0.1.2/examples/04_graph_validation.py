"""
04 — Graph validation: only_simple_paths(), only_cycles(), only_complex_walks().

This example creates small datasets: one with only simple paths, one with a
cycle (first node = last node), and one with a walk that revisits a node.
It demonstrates how only_simple_paths(), only_cycles(), and only_complex_walks()
change the result (number of walk_ids or rows).
"""

import shutil
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import walkingpandas as wp

from _data_helpers import make_simple_network_gdf, make_simple_walks_df, write_to_temp_parquet


def main():
    print("=" * 60)
    print("04 — Graph validation")
    print("=" * 60)

    nodes_gdf, edges_gdf = make_simple_network_gdf()
    walks_df = make_simple_walks_df()
    temp_dir = write_to_temp_parquet(nodes_gdf, edges_gdf, walks_df)

    try:
        network = wp.Network(nodes=temp_dir / "nodes.parquet", edges=temp_dir / "edges.parquet")
        walks = wp.WalkFrame(temp_dir / "walks.parquet", network=network)

        # Baseline: all rows
        all_rows = walks.compute()
        print(f"\n1. All walks: {len(all_rows)} rows, walk_ids = {sorted(all_rows['walk_id'].unique())}")

        # Only simple paths (no node visited twice)
        simple = walks.only_simple_paths().compute()
        print(f"\n2. only_simple_paths(): {len(simple)} rows, walk_ids = {sorted(simple['walk_id'].unique())}")
        print("   (walk3 is a cycle A→B→C→D→A and has repeated A; walk1, walk2 are simple)")

        # Only cycles (first node = last node)
        cycles = walks.only_cycles().compute()
        print(f"\n3. only_cycles(): {len(cycles)} rows, walk_ids = {sorted(cycles['walk_id'].unique())}")

        # Only complex walks (repeated nodes; not simple paths)
        non_simple = walks.only_complex_walks().compute()
        print(f"\n4. only_complex_walks(): {len(non_simple)} rows (walks that revisit a node)")
        print(f"   walk_ids = {sorted(non_simple['walk_id'].unique())}")

        print("\nDone.")
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)


if __name__ == "__main__":
    main()
