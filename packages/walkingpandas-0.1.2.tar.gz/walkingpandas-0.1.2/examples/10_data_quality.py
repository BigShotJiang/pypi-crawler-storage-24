"""
10 — Data quality: get_orphaned_records().

This example creates walk data that references a node_id or exit_edge not in the
network (orphans). It shows get_orphaned_records(), displays the returned
DataFrame, and explains that joins will drop or null out orphans and this is
for diagnostics.
"""

import shutil
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import pandas as pd
import walkingpandas as wp

from _data_helpers import make_simple_network_gdf, write_to_temp_parquet


def main():
    print("=" * 60)
    print("10 — Data quality")
    print("=" * 60)

    nodes_gdf, edges_gdf = make_simple_network_gdf()
    # Walks with orphans: walk2 uses node 5 and edge 5, which are not in the network
    walks_df = pd.DataFrame([
        {"walk_id": "walk1", "sequence_idx": 0, "node_id": 0, "exit_edge": 0},
        {"walk_id": "walk1", "sequence_idx": 1, "node_id": 1, "exit_edge": 1},
        {"walk_id": "walk1", "sequence_idx": 2, "node_id": 2, "exit_edge": None},
        {"walk_id": "walk2", "sequence_idx": 0, "node_id": 5, "exit_edge": 5},
        {"walk_id": "walk2", "sequence_idx": 1, "node_id": 6, "exit_edge": None},
    ])
    temp_dir = write_to_temp_parquet(nodes_gdf, edges_gdf, walks_df)

    try:
        network = wp.Network(nodes=temp_dir / "nodes.parquet", edges=temp_dir / "edges.parquet")
        walks = wp.WalkFrame(temp_dir / "walks.parquet", network=network)

        orphans = walks.get_orphaned_records()
        print("\nget_orphaned_records() — rows with node_id or exit_edge not in Network")
        print("(Joins in queries may drop or null these; use this for diagnostics.)")
        print(orphans.to_string(index=False))

        print("\nDone.")
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)


if __name__ == "__main__":
    main()
