"""
07 — Aggregations: edge_frequencies(), node_frequencies(), walk_lengths().

This example shows edge_frequencies() (count distinct walk_id per exit_edge),
node_frequencies() (count distinct walk_id per node_id), and walk_lengths()
(steps per walk_id). Optionally combines with filters (e.g. only_simple_paths
then edge_frequencies).
"""

import shutil
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import walkingpandas as wp

from _data_helpers import make_simple_network_gdf, make_simple_walks_df, write_to_temp_parquet


def main():
    print("=" * 60)
    print("07 — Aggregations")
    print("=" * 60)

    nodes_gdf, edges_gdf = make_simple_network_gdf()
    walks_df = make_simple_walks_df()
    temp_dir = write_to_temp_parquet(nodes_gdf, edges_gdf, walks_df)

    try:
        network = wp.Network(nodes=temp_dir / "nodes.parquet", edges=temp_dir / "edges.parquet")
        walks = wp.WalkFrame(temp_dir / "walks.parquet", network=network)

        # edge_frequencies: count distinct walk_id per exit_edge
        ef = walks.edge_frequencies().compute()
        print("\n1. edge_frequencies() — distinct walks per edge")
        print(ef.to_string(index=False))

        # node_frequencies: count distinct walk_id per node_id
        nf = walks.node_frequencies().compute()
        print("\n2. node_frequencies() — distinct walks per node")
        print(nf.to_string(index=False))

        # walk_lengths: steps per walk_id
        wl = walks.walk_lengths().compute()
        print("\n3. walk_lengths() — steps per walk")
        print(wl.to_string(index=False))

        # Combine filter + aggregation: only simple paths, then edge frequencies
        ef_simple = walks.only_simple_paths().edge_frequencies().compute()
        print("\n4. only_simple_paths().edge_frequencies().compute()")
        print(ef_simple.to_string(index=False))

        print("\nDone.")
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)


if __name__ == "__main__":
    main()
