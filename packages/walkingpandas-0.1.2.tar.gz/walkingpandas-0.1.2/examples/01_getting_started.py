"""
01 — Getting started: Network, WalkFrame, and lazy compute().

This example creates a tiny network and a few walk rows, writes them to a temp
directory as Parquet, then shows how to build a Network, a WalkFrame, and run
a query with .compute(). It explains that queries are lazy until .compute().
"""
import shutil
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import walkingpandas as wp

from _data_helpers import make_simple_network_gdf, make_simple_walks_df, write_to_temp_parquet


def main():
    print("=" * 60)
    print("01 — Getting started")
    print("=" * 60)

    # Create small data in memory (no external files)
    nodes_gdf, edges_gdf = make_simple_network_gdf()
    walks_df = make_simple_walks_df()

    # Write to a temp directory so we can load from Parquet (as in real use)
    temp_dir = write_to_temp_parquet(nodes_gdf, edges_gdf, walks_df)
    try:
        nodes_path = temp_dir / "nodes.parquet"
        edges_path = temp_dir / "edges.parquet"
        walks_path = temp_dir / "walks.parquet"

        # Build a Network from Parquet paths
        network = wp.Network(nodes=nodes_path, edges=edges_path)
        print("\n✓ Network created from nodes.parquet and edges.parquet")

        # Build a WalkFrame: it wraps the walks Parquet and uses the network
        walks = wp.WalkFrame(walks_path, network=network)
        # Same via named constructor: walks = wp.WalkFrame.from_parquet(walks_path, network=network)
        print("✓ WalkFrame created (lazy — no query run yet)")

        # Alternative: pass nodes/edges directly (network is built internally)
        # walks = wp.WalkFrame(walks_path, nodes=nodes_gdf, edges=edges_gdf)
        # You can always access the underlying network: walks.network
        print(f"   (underlying network has {len(walks.network.get_nodes())} nodes)")

        # Queries are lazy: we build a chain and only run it on .compute()
        result = walks.compute()
        print(f"\n✓ .compute() ran the query. Result has {len(result)} rows:")
        print(result.to_string(index=False))

        # Chaining: filter then compute
        filtered = walks.filter(walk_id="walk1").compute()
        print(f"\n✓ Chained .filter(walk_id='walk1').compute() → {len(filtered)} rows")
        print(filtered[["walk_id", "sequence_idx", "node_id"]].to_string(index=False))
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)

    print("\nDone.")


if __name__ == "__main__":
    main()
