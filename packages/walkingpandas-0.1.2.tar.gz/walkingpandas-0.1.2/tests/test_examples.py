"""
Smoke tests: run each tutorial example's main block to ensure no errors.
"""

import subprocess
import sys
from pathlib import Path

import pytest

# Scripts in examples/ that have a main block
EXAMPLE_SCRIPTS = [
    "01_getting_started.py",
    "02_network_creation.py",
    "03_walkframe_basics.py",
    "04_graph_validation.py",
    "05_spatial_filtering.py",
    "06_temporal_queries.py",
    "07_aggregations.py",
    "08_ingestion_io.py",
    "09_persistence.py",
    "10_data_quality.py",
    "11_full_workflow.py",
]


@pytest.mark.parametrize("script", EXAMPLE_SCRIPTS)
def test_example_script_runs(script):
    """Run examples/NN_*.py from project root; expect exit 0."""
    root = Path(__file__).resolve().parent.parent
    path = root / "examples" / script
    assert path.exists(), f"Example script missing: {path}"
    result = subprocess.run(
        [sys.executable, str(path)],
        cwd=str(root),
        capture_output=True,
        text=True,
        timeout=60,
    )
    assert result.returncode == 0, (
        f"{script} failed (exit {result.returncode}):\n"
        f"stdout:\n{result.stdout}\nstderr:\n{result.stderr}"
    )
