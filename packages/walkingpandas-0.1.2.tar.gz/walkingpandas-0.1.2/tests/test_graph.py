"""Tests for graph validation methods."""

import pytest
from walkingpandas import WalkFrame


def test_only_simple_paths(sample_walkframe, sample_walks_simple_paths):
    """Test filtering simple paths."""
    _, walks_path = sample_walks_simple_paths
    walkframe = WalkFrame(walks_path, network=sample_walkframe._network)
    
    simple = walkframe.only_simple_paths()
    result = simple.compute()
    
    # All walks should be simple paths (no repeated nodes)
    assert len(result) > 0


def test_only_cycles(sample_walkframe, sample_walks_cycles):
    """Test filtering cycles."""
    _, walks_path = sample_walks_cycles
    walkframe = WalkFrame(walks_path, network=sample_walkframe._network)
    
    cycles = walkframe.only_cycles()
    result = cycles.compute()
    
    # Should find cycles
    assert len(result) > 0


def test_only_complex_walks(sample_walkframe, sample_walks_cycles):
    """Test filtering to only complex walks (with repeated nodes)."""
    _, walks_path = sample_walks_cycles
    walkframe = WalkFrame(walks_path, network=sample_walkframe._network)
    
    # cycle1 has repeated node A (start and end), so it's a walk with repetition
    non_simple = walkframe.only_complex_walks()
    result = non_simple.compute()
    # Should include walks where count != distinct count
    assert isinstance(result, type(walkframe.compute()))


def test_only_walks_deprecated(sample_walkframe, sample_walks_cycles):
    """Test that only_walks() still works and issues DeprecationWarning."""
    import warnings
    _, walks_path = sample_walks_cycles
    walkframe = WalkFrame(walks_path, network=sample_walkframe._network)
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        non_simple = walkframe.only_walks()
        result = non_simple.compute()
    assert len([x for x in w if issubclass(x.category, DeprecationWarning)]) >= 1
    assert isinstance(result, type(walkframe.compute()))
