# Performance

## Integer IDs

All node and edge identifiers are stored as BIGINT (64-bit integers). Compared to VARCHAR keys this yields:

- **Smaller Parquet files** -- fixed-width encoding instead of variable-length strings
- **Faster DuckDB joins and GROUP BY** -- integer comparison is a single CPU instruction
- **Reduced memory** -- 8 bytes per ID vs. variable-length string allocations

If your source data uses string identifiers, the auto-translation layer maps them to dense integers on ingestion and decodes them back on output -- no manual work required.

## Spatial optimization (geo-enabled networks)

When nodes carry coordinates, walkingpandas uses **reverse spatial filtering** for performance:

1. Query the small Network (in-memory) first to get node/edge IDs
2. Use fast integer `IN` clauses on Parquet data
3. Avoid expensive spatial operations on billions of rows

```python
# This query is optimized automatically
walks.within_bounds((-122.5, 37.7, -122.3, 37.8))
```

## Temporal data handling

Timestamps are optional. walkingpandas gracefully handles three scenarios:

### Time-less data

Both `timestamp` and `dwell_time` are NULL.

- Temporal queries return empty results or warn
- Topological queries work normally

### Single-timestamp data

Only `timestamp` is present.

- Uses `LEAD()` window function to infer edge traversal time
- Calculates duration from step N to step N+1

### Dwell-time data

Both `timestamp` and `dwell_time` are present.

- Edge traversal starts at `timestamp + dwell_time`
- Ends at next step's `timestamp`
