# Network

::: walkingpandas.core.network.Network
    options:
      members_order: source
      show_root_heading: true
      show_source: false
      merge_init_into_class: true
