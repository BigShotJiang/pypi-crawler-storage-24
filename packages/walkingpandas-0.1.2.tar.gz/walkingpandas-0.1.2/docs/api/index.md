# API reference

Auto-generated documentation from source code docstrings.

## Top-level API

```python
import walkingpandas as wp

wp.Network         # Static network topology
wp.WalkFrame       # Lazy walk/path data view
wp.read_dataset    # Build Network + WalkFrame from Parquet paths
wp.connect         # Load Network from DuckDB and attach walks
wp.write_duckdb    # Write Network + walks to a single DuckDB file
```

## Modules

- [Network](network.md) -- static network topology management
- [WalkFrame](walkframe.md) -- lazy-evaluated walk/path data analysis
- [I/O and ingestion](io.md) -- data ingestion, schema validation, persistence
- [Map matching](match.md) -- GPS-to-walk pipeline and backends
