# Map matching

The map-matching pipeline turns raw GPS trajectories into walks on a road/path network. It is built around a pluggable backend interface (`BaseMatcher`); the shipped backend is `ValhallaMatcher`.

## Pipeline

::: walkingpandas.io.match.core.match_trajectories
    options:
      show_root_heading: true
      show_source: false

## Backend interface

::: walkingpandas.io.match.base.BaseMatcher
    options:
      show_root_heading: true
      show_source: false
      members_order: source

## Valhalla backend

::: walkingpandas.io.match.backends.valhalla.ValhallaMatcher
    options:
      show_root_heading: true
      show_source: false
      members_order: source
      merge_init_into_class: true

## GPS data loading

::: walkingpandas.io.match.gps.GPSDataset
    options:
      show_root_heading: true
      show_source: false
      members_order: source
      merge_init_into_class: true
