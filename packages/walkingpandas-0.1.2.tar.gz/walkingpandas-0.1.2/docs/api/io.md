# I/O and ingestion

## Top-level functions

::: walkingpandas.io.ingest.read_dataset
    options:
      show_root_heading: true
      show_source: false

::: walkingpandas.io.ingest.connect
    options:
      show_root_heading: true
      show_source: false

::: walkingpandas.io.ingest.write_duckdb
    options:
      show_root_heading: true
      show_source: false

::: walkingpandas.io.ingest.write_walks
    options:
      show_root_heading: true
      show_source: false

## Schema helpers

::: walkingpandas.io.ingest.validate_schema
    options:
      show_root_heading: true
      show_source: false

::: walkingpandas.io.ingest.convert_to_superset_format
    options:
      show_root_heading: true
      show_source: false

## Deprecated

::: walkingpandas.io.ingest.read_duckdb
    options:
      show_root_heading: true
      show_source: false
