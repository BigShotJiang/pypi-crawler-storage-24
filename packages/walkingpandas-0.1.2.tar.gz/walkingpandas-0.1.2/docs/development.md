# Development

## Project structure

```
walkingpandas/
├── src/walkingpandas/
│   ├── core/          # Network and WalkFrame classes
│   ├── graph/         # Graph validation (simple paths, cycles)
│   ├── spatial/       # Spatial filtering (reverse spatial)
│   ├── temporal/      # Temporal queries and edge analysis
│   └── io/            # Data ingestion, I/O, and map matching
│       └── match/     # Map-matching pipeline and backends
├── examples/          # Tutorial scripts (01-11)
├── tests/             # Test suite
├── docs/              # MkDocs documentation source
└── pyproject.toml     # Project metadata and dependencies
```

## Setting up a development environment

```bash
git clone https://github.com/cisgroup/walkingpandas.git
cd walkingpandas
pip install -e ".[dev,docs]"
```

Or with [uv](https://docs.astral.sh/uv/):

```bash
uv sync --extra dev --extra docs
```

## Running tests

```bash
pytest tests/
```

With coverage:

```bash
pytest tests/ --cov=walkingpandas --cov-report=term-missing
```

## Building documentation

Serve locally with live reload:

```bash
mkdocs serve
```

Build static site:

```bash
mkdocs build
```

The built site is output to `site/` (git-ignored).

## License

MIT License -- see the [LICENSE](https://github.com/cisgroup/walkingpandas/blob/main/LICENSE) file for details.

## Contributing

Contributions welcome! Please open an issue or submit a pull request on [GitHub](https://github.com/cisgroup/walkingpandas).

## Citation

If you use walkingpandas in your research, please cite:

```bibtex
@software{walkingpandas,
  title = {walkingpandas: Massive-Scale Walk and Path Analysis on Network Topologies},
  author = {Jürgen Hackl},
  year = {2026},
  url = {https://github.com/cisgroup/walkingpandas}
}
```
