"""Empyrean Pro — Full-featured astrodynamics engine with covariance propagation and orbit determination."""

__version__ = "0.0.1"


class LicenseError(Exception):
    pass


def _check_license():
    import os

    key = os.environ.get("EMPYREAN_LICENSE")
    if not key:
        raise LicenseError(
            "Empyrean Pro requires a license key.\n"
            "Set the EMPYREAN_LICENSE environment variable or visit\n"
            "https://www.empyrean-dynamics.com for more information."
        )
    return key


_check_license()
