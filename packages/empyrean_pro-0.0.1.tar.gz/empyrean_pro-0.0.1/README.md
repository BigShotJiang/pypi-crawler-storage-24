# Empyrean Pro

by [Empyrean Dynamics](https://www.empyrean-dynamics.com)

Full-featured astrodynamics engine, built on [empyrean](https://pypi.org/project/empyrean/).

## Features

Everything in `empyrean`, plus:

- **Relativistic force models** — full post-Newtonian dynamics
- **Covariance propagation** — automatic via the AD pipeline
- **Close approach detection** — with root-finding refinement
- **Impact probability** — from mapped uncertainties at encounter
- **Ephemeris generation** — observer-centric astrometry
- **Orbit determination** — differential corrections, IOD, residual fitting

## License

Empyrean Pro requires a license key. Visit
[www.empyrean-dynamics.com](https://www.empyrean-dynamics.com) for pricing
and access.

```bash
pip install empyrean-pro
export EMPYREAN_LICENSE="your-key-here"
```

```python
from empyrean_pro import propagate_full

result = propagate_full(
    epoch=60000.0,
    elements=[0.5, 0.9, 1.2, 2.0, 1.5, 59900.0],
    coordinate_type="cometary",
    times=[60010.0, 60020.0, 60030.0],
    force_model="full",
    covariance=[...],
)
```
