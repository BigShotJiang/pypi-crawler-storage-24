"""CostGuard CLI — thin wrapper between CI/CD pipelines and the CostGuard API.

Usage:
    costguard-validate --plan <file> [--format terminal|markdown|json|html]
                       [--api-url URL] [--api-key KEY] [--budget-code CODE]
                       [--iac-type terraform|cloudformation]
                       [--skip-budget] [--skip-narrative] [--skip-guardrails]
                       [--include-calculations] [--auto-approve]
                       [--cached result.json] [--post-comment]
                       [--output-file FILE]

Exit codes:
    0 = ALLOW   — deployment permitted
    1 = BLOCK   — deployment blocked by guardrails
    2 = WARN    — deployment allowed with warnings
    3 = ERROR   — validation could not complete
"""

import argparse
import json
import os
import sys
import time
from pathlib import Path
from typing import Optional

import requests

from costguard_cli import __version__
from costguard_cli.formatters import FORMATTERS
from costguard_cli.platforms import post_ci_comment

# ---------------------------------------------------------------------------
# Exit codes
# ---------------------------------------------------------------------------
EXIT_ALLOW = 0
EXIT_BLOCK = 1
EXIT_WARN = 2
EXIT_ERROR = 3

DECISION_EXIT_MAP = {
    "ALLOW": EXIT_ALLOW,
    "BLOCK": EXIT_BLOCK,
    "WARN": EXIT_WARN,
    "ERROR": EXIT_ERROR,
}

DEFAULT_API_URL = "https://api.skyxops.com"
DEFAULT_CACHE_PATH = "costguard-result.json"
MAX_RETRIES = 3
RETRY_BACKOFF_BASE = 1  # seconds: 1, 2, 4
RETRYABLE_STATUS_CODES = {429, 502, 503, 504}


# ---------------------------------------------------------------------------
# Argument parsing
# ---------------------------------------------------------------------------
def build_parser() -> argparse.ArgumentParser:
    """Build the CLI argument parser."""
    parser = argparse.ArgumentParser(
        prog="costguard-validate",
        description="CostGuard shift-left cost validation for CI/CD pipelines.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Exit codes:\n"
            "  0  ALLOW  — deployment permitted\n"
            "  1  BLOCK  — deployment blocked by guardrails\n"
            "  2  WARN   — deployment allowed with warnings\n"
            "  3  ERROR  — validation could not complete\n"
        ),
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )
    parser.add_argument(
        "--plan",
        required=False,
        help="Path to the Terraform/CloudFormation plan JSON file.",
    )
    parser.add_argument(
        "--iac-type",
        choices=["terraform", "cloudformation"],
        default=None,
        help="IaC type (default: auto-detect from plan content).",
    )
    parser.add_argument(
        "--format",
        dest="output_format",
        choices=["terminal", "markdown", "json", "html"],
        default="terminal",
        help="Output format (default: terminal).",
    )
    parser.add_argument(
        "--api-url",
        default=None,
        help="CostGuard API base URL (env: COSTGUARD_API_URL).",
    )
    parser.add_argument(
        "--api-key",
        default=None,
        help="CostGuard API key (env: COSTGUARD_API_KEY).",
    )
    parser.add_argument(
        "--budget-code",
        default=None,
        help="Budget code to validate against, e.g. CS-FY2026-M01 (env: COSTGUARD_BUDGET_CODE).",
    )

    # Pipeline options
    pipeline_group = parser.add_argument_group("pipeline options")
    pipeline_group.add_argument(
        "--skip-budget",
        action="store_true",
        default=False,
        help="Skip budget validation (pricing-only mode).",
    )
    pipeline_group.add_argument(
        "--skip-narrative",
        action="store_true",
        default=False,
        help="Skip AI narrative generation (faster response).",
    )
    pipeline_group.add_argument(
        "--skip-guardrails",
        action="store_true",
        default=False,
        help="Skip guardrail evaluation.",
    )
    pipeline_group.add_argument(
        "--include-calculations",
        action="store_true",
        default=False,
        help="Include detailed UPS calculation breakdown in response.",
    )
    pipeline_group.add_argument(
        "--auto-approve",
        action="store_true",
        default=False,
        help="Auto-approve if no budget is found (default: block).",
    )

    # Output options
    output_group = parser.add_argument_group("output options")
    output_group.add_argument(
        "--no-color",
        action="store_true",
        default=False,
        help="Disable ANSI color codes in terminal output (also respects NO_COLOR env var).",
    )
    output_group.add_argument(
        "--cached",
        default=None,
        metavar="FILE",
        help="Use a cached result JSON instead of calling the API.",
    )
    output_group.add_argument(
        "--post-comment",
        action="store_true",
        default=False,
        help="Auto-detect CI platform and post result as a PR/MR comment.",
    )
    output_group.add_argument(
        "--output-file",
        default=None,
        metavar="FILE",
        help="Write formatted output to a file.",
    )
    output_group.add_argument(
        "--cache-path",
        default=DEFAULT_CACHE_PATH,
        metavar="FILE",
        help=f"Path to cache the API response (default: {DEFAULT_CACHE_PATH}).",
    )
    return parser


# ---------------------------------------------------------------------------
# Plan file reading
# ---------------------------------------------------------------------------
def read_plan_file(plan_path: str) -> dict:
    """Read and parse the IaC plan JSON file."""
    path = Path(plan_path)
    if not path.exists():
        raise FileNotFoundError(f"Plan file not found: {plan_path}")
    if not path.is_file():
        raise ValueError(f"Plan path is not a file: {plan_path}")

    try:
        with open(path, "r", encoding="utf-8") as fh:
            return json.load(fh)
    except json.JSONDecodeError as exc:
        raise ValueError(f"Invalid JSON in plan file: {exc}") from exc


# ---------------------------------------------------------------------------
# API interaction
# ---------------------------------------------------------------------------
def detect_iac_type(plan_content: dict) -> str:
    """Auto-detect IaC type from plan content.

    Detection rules:
    - Terraform plan JSON: has 'terraform_version' or 'resource_changes'
    - CloudFormation template: has 'AWSTemplateFormatVersion' or 'Resources' (without TF markers)
    - CloudFormation changeset: has 'Changes'
    - Unknown: defaults to 'terraform' (most common in CI/CD)
    """
    if "terraform_version" in plan_content or "resource_changes" in plan_content:
        return "terraform"
    if (
        "AWSTemplateFormatVersion" in plan_content
        or "Changes" in plan_content
        or ("Resources" in plan_content and "terraform_version" not in plan_content)
    ):
        return "cloudformation"
    return "terraform"


def call_costguard_api(
    api_url: str,
    api_key: str,
    plan_content: dict,
    iac_type: str,
    budget_code: Optional[str] = None,
    options: Optional[dict] = None,
) -> dict:
    """POST the plan to the CostGuard analyze endpoint and return the response.

    Retries up to MAX_RETRIES times with exponential backoff on transient
    errors (429, 502, 503, 504, timeouts, connection resets).
    Client errors (400, 401, 403, 404) fail immediately.
    """
    url = f"{api_url.rstrip('/')}/v1/costguard/analyze"

    headers = {
        "x-api-key": api_key,
        "Content-Type": "application/json",
    }

    body: dict = {
        "iac_plan": plan_content,
        "iac_type": iac_type,
    }
    if budget_code:
        body["budget_code"] = budget_code
    if options:
        body["options"] = options

    last_exc: Exception | None = None

    for attempt in range(1, MAX_RETRIES + 1):
        try:
            resp = requests.post(url, headers=headers, json=body, timeout=120)
            resp.raise_for_status()
            return resp.json()
        except requests.exceptions.Timeout as exc:
            last_exc = exc
            if attempt < MAX_RETRIES:
                wait = RETRY_BACKOFF_BASE * (2 ** (attempt - 1))
                print(f"[CostGuard] Timeout (attempt {attempt}/{MAX_RETRIES}), retrying in {wait}s...", file=sys.stderr)
                time.sleep(wait)
                continue
        except requests.exceptions.ConnectionError as exc:
            last_exc = exc
            if attempt < MAX_RETRIES:
                wait = RETRY_BACKOFF_BASE * (2 ** (attempt - 1))
                print(f"[CostGuard] Connection error (attempt {attempt}/{MAX_RETRIES}), retrying in {wait}s...", file=sys.stderr)
                time.sleep(wait)
                continue
        except requests.exceptions.HTTPError as exc:
            status = exc.response.status_code if exc.response is not None else 0
            if status in RETRYABLE_STATUS_CODES and attempt < MAX_RETRIES:
                wait = RETRY_BACKOFF_BASE * (2 ** (attempt - 1))
                print(f"[CostGuard] HTTP {status} (attempt {attempt}/{MAX_RETRIES}), retrying in {wait}s...", file=sys.stderr)
                time.sleep(wait)
                last_exc = exc
                continue
            # Non-retryable HTTP error — fail immediately
            detail = ""
            if exc.response is not None:
                try:
                    err_body = exc.response.json()
                    detail = err_body.get("message") or err_body.get("detail") or exc.response.text[:500]
                except Exception:
                    detail = exc.response.text[:500]
            raise RuntimeError(f"CostGuard API returned HTTP {status}: {detail}") from exc

    # All retries exhausted
    if isinstance(last_exc, requests.exceptions.Timeout):
        raise RuntimeError(f"CostGuard API request timed out after {MAX_RETRIES} attempts.") from last_exc
    if isinstance(last_exc, requests.exceptions.ConnectionError):
        raise RuntimeError(f"Could not connect to CostGuard API at {url} after {MAX_RETRIES} attempts.") from last_exc
    raise RuntimeError(f"CostGuard API failed after {MAX_RETRIES} attempts.") from last_exc


# ---------------------------------------------------------------------------
# Cache management
# ---------------------------------------------------------------------------
def save_cache(response: dict, cache_path: str) -> None:
    """Write the API response to a cache file."""
    with open(cache_path, "w", encoding="utf-8") as fh:
        json.dump(response, fh, indent=2, default=str)


def load_cache(cache_path: str) -> dict:
    """Load a cached API response."""
    path = Path(cache_path)
    if not path.exists():
        raise FileNotFoundError(f"Cached result file not found: {cache_path}")
    with open(path, "r", encoding="utf-8") as fh:
        return json.load(fh)


# ---------------------------------------------------------------------------
# Output handling
# ---------------------------------------------------------------------------
def format_output(response: dict, output_format: str, no_color: bool = False) -> str:
    """Format the API response using the selected formatter."""
    formatter_cls = FORMATTERS.get(output_format)
    if formatter_cls is None:
        raise ValueError(f"Unknown output format: {output_format}")

    if output_format == "terminal":
        force_color = False if no_color else None  # None = auto-detect
        formatter = formatter_cls(force_color=force_color)
    else:
        formatter = formatter_cls()
    return formatter.format(response)


def write_output_file(content: str, output_path: str) -> None:
    """Write formatted content to a file."""
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(content)
    print(f"[CostGuard] Output written to {output_path}", file=sys.stderr)


def resolve_decision(response: dict) -> str:
    """Extract the decision from the API response."""
    # Try direct response field first (v1 API)
    decision = response.get("decision")
    if not decision:
        # Fallback to nested endpoint_data (legacy)
        endpoint_data = response.get("endpoint_data") or {}
        decision = endpoint_data.get("decision", "ERROR")
    return decision.upper()


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------
def main() -> None:
    """CLI entry point for costguard-validate."""
    # Ensure UTF-8 output on Windows (box-drawing chars, progress bars)
    if sys.stdout.encoding and sys.stdout.encoding.lower() not in ("utf-8", "utf8"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    if sys.stderr.encoding and sys.stderr.encoding.lower() not in ("utf-8", "utf8"):
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")

    parser = build_parser()
    args = parser.parse_args()

    # Resolve defaults from environment variables
    api_url = args.api_url or os.environ.get("COSTGUARD_API_URL", DEFAULT_API_URL)
    api_key = args.api_key or os.environ.get("COSTGUARD_API_KEY", "")
    budget_code = args.budget_code or os.environ.get("COSTGUARD_BUDGET_CODE")

    # ---- Obtain the CostGuard response ----
    response: dict = {}

    if args.cached:
        # Use cached result — skip API call
        try:
            response = load_cache(args.cached)
            print("[CostGuard] Loaded cached result from:", args.cached, file=sys.stderr)
        except (FileNotFoundError, json.JSONDecodeError) as exc:
            print(f"[CostGuard] ERROR: {exc}", file=sys.stderr)
            sys.exit(EXIT_ERROR)
    else:
        # Validate required inputs
        if not args.plan:
            print("[CostGuard] ERROR: --plan is required unless --cached is provided.", file=sys.stderr)
            parser.print_usage(sys.stderr)
            sys.exit(EXIT_ERROR)

        if not api_key:
            print("[CostGuard] ERROR: API key required. Use --api-key or set COSTGUARD_API_KEY.", file=sys.stderr)
            sys.exit(EXIT_ERROR)

        # Read the plan file
        try:
            plan_content = read_plan_file(args.plan)
        except (FileNotFoundError, ValueError) as exc:
            print(f"[CostGuard] ERROR: {exc}", file=sys.stderr)
            sys.exit(EXIT_ERROR)

        # Determine IaC type
        iac_type = args.iac_type or detect_iac_type(plan_content)

        # Warn if no budget code and no skip — API will reject
        if not budget_code and not args.skip_budget:
            print(
                "[CostGuard] WARNING: No --budget-code provided. Use --skip-budget for pricing-only mode,\n"
                "            or set COSTGUARD_BUDGET_CODE / --budget-code for full budget validation.",
                file=sys.stderr,
            )

        # Build pipeline options from flags
        options = {}
        if args.skip_budget:
            options["skip_budget"] = True
        if args.skip_narrative:
            options["skip_narrative"] = True
        if args.skip_guardrails:
            options["skip_guardrails"] = True
        if args.include_calculations:
            options["include_calculations"] = True
        if args.auto_approve:
            options["auto_approve"] = True

        # Call CostGuard API
        try:
            response = call_costguard_api(
                api_url, api_key, plan_content, iac_type, budget_code,
                options=options if options else None,
            )
        except RuntimeError as exc:
            print(f"[CostGuard] ERROR: {exc}", file=sys.stderr)
            sys.exit(EXIT_ERROR)

        # Cache the response
        try:
            save_cache(response, args.cache_path)
        except OSError as exc:
            print(f"[CostGuard] WARNING: Could not cache response: {exc}", file=sys.stderr)

    # ---- Format and output ----
    try:
        formatted = format_output(response, args.output_format, no_color=args.no_color)
    except Exception as exc:
        print(f"[CostGuard] ERROR formatting output: {exc}", file=sys.stderr)
        sys.exit(EXIT_ERROR)

    # Print to stdout
    print(formatted)

    # Write to file if requested
    if args.output_file:
        try:
            write_output_file(formatted, args.output_file)
        except OSError as exc:
            print(f"[CostGuard] ERROR writing output file: {exc}", file=sys.stderr)

    # Post CI comment if requested
    if args.post_comment:
        # For CI comments, prefer markdown format for readability
        comment_format = "markdown" if args.output_format != "markdown" else args.output_format
        try:
            comment_content = format_output(response, comment_format)
            post_ci_comment(comment_content)
        except Exception as exc:
            print(f"[CostGuard] ERROR posting comment: {exc}", file=sys.stderr)

    # ---- Warn if budget was not found ----
    budget = response.get("budget", {})
    if budget.get("budget_found") is False:
        reason = budget.get("decision_reason", "No applicable budget found")
        print(
            f"[CostGuard] WARNING: {reason}\n"
            "            Check your --budget-code value or use --auto-approve.",
            file=sys.stderr,
        )

    # ---- Exit with decision code ----
    decision = resolve_decision(response)
    exit_code = DECISION_EXIT_MAP.get(decision, EXIT_ERROR)
    sys.exit(exit_code)


if __name__ == "__main__":
    main()
