"""Markdown formatter — PR/MR comment format for CostGuard results."""


class MarkdownFormatter:
    """Renders CostGuard API responses as Markdown suitable for PR/MR comments."""

    DECISION_BADGES = {
        "ALLOW": "![ALLOW](https://img.shields.io/badge/CostGuard-ALLOW-brightgreen)",
        "WARN": "![WARN](https://img.shields.io/badge/CostGuard-WARN-yellow)",
        "BLOCK": "![BLOCK](https://img.shields.io/badge/CostGuard-BLOCK-red)",
        "ERROR": "![ERROR](https://img.shields.io/badge/CostGuard-ERROR-lightgrey)",
    }

    SEVERITY_ICONS = {
        "high": "🔴",
        "medium": "🟡",
        "low": "🔵",
    }

    def format(self, response: dict) -> str:
        """Format the full CostGuard API response as Markdown."""
        sections: list[str] = []

        # Support both flat (v1 API) and nested (legacy) response shapes
        if "endpoint_data" in response:
            endpoint_data = response["endpoint_data"]
            results = response.get("results") or {}
        else:
            endpoint_data = response
            results = response

        decision = (endpoint_data.get("decision") or "ERROR").upper()

        # Header with decision badge
        sections.append(self._header(decision))

        # Cost summary
        sections.append(self._cost_summary(results))

        # Resource cost table
        resources = results.get("resources") or []
        if resources:
            sections.append(self._resource_table(resources))

        # Budget section
        budget = endpoint_data.get("budget")
        if budget:
            sections.append(self._budget_section(budget))

        # Violations
        violations = endpoint_data.get("violations") or []
        if violations:
            sections.append(self._violations_section(violations, endpoint_data.get("guardrails")))

        # AI narrative
        narrative = results.get("narrative")
        if narrative:
            sections.append(self._narrative_section(narrative))

        # Collapsible full breakdown
        sections.append(self._collapsible_details(response))

        # Errors
        errors = results.get("errors") or []
        if errors:
            sections.append(self._errors_section(errors))

        # Footer
        sections.append(self._footer(response))

        return "\n\n".join(sections)

    # ------------------------------------------------------------------
    # Section renderers
    # ------------------------------------------------------------------

    def _header(self, decision: str) -> str:
        badge = self.DECISION_BADGES.get(decision, self.DECISION_BADGES["ERROR"])
        return (
            f"## CostGuard Infrastructure Cost Analysis\n\n"
            f"{badge}\n\n"
            f"**Decision: {decision}**"
        )

    def _cost_summary(self, results: dict) -> str:
        summary = results.get("summary") or {}
        total = summary.get("total_monthly_cost") or results.get("total_monthly_usd")
        currency = summary.get("currency") or results.get("currency", "USD")
        resource_count = summary.get("total_resources") or len(results.get("resources") or [])

        total_str = f"${total:,.2f}" if total is not None else "N/A"
        return (
            f"### Cost Summary\n\n"
            f"| Metric | Value |\n"
            f"|--------|-------|\n"
            f"| **Estimated Monthly Cost** | **{total_str} {currency}** |\n"
            f"| Resources Analyzed | {resource_count} |"
        )

    def _resource_table(self, resources: list[dict]) -> str:
        lines = [
            "### Per-Resource Costs\n",
            "| Resource | Type | Region | Monthly Cost |",
            "|----------|------|--------|-------------:|",
        ]

        for r in resources:
            name = r.get("resource_name") or r.get("resource_id", "unknown")
            rtype = r.get("resource_type", "unknown")
            region = r.get("region", "-")
            mc = r.get("monthly_cost")
            cost_str = f"${mc:,.2f}" if mc is not None else "N/A"
            success = r.get("success", True)
            status = "" if success else " (failed)"

            lines.append(f"| `{name}` | {rtype} | {region} | {cost_str}{status} |")

        return "\n".join(lines)

    def _budget_section(self, budget: dict) -> str:
        budget_name = budget.get("budget_name", "Unknown")

        # Budget not found — show clear message
        if budget.get("budget_found") is False:
            reason = budget.get("decision_reason", "No applicable budget found")
            lines = [
                "### Budget\n",
                f"> **Budget not found:** {reason}",
                ">",
                "> Check your `--budget-code` value or use `--auto-approve` to allow deployment without a matching budget.\n",
            ]
            return "\n".join(lines)

        lines = [f"### Budget: {budget_name}\n"]

        # Full budget fields
        monthly_limit = budget.get("monthly_limit")
        if monthly_limit is not None:
            current_usage = budget.get("current_usage", 0)
            pct = (current_usage / monthly_limit * 100) if monthly_limit > 0 else 0
            bar_filled = int(min(pct, 100) / 5)
            bar_empty = 20 - bar_filled
            bar = "█" * bar_filled + "░" * bar_empty

            lines.append("```")
            lines.append(f"[{bar}] {pct:.0f}% used")
            lines.append("```\n")

            lines.append("| Metric | Amount |")
            lines.append("|--------|-------:|")
            lines.append(f"| Monthly Limit | ${monthly_limit:,.2f} |")
            lines.append(f"| Current Usage | ${current_usage:,.2f} |")

            projected_usage = budget.get("projected_usage")
            if projected_usage is not None:
                lines.append(f"| Projected Usage | ${projected_usage:,.2f} |")
            remaining = budget.get("remaining")
            if remaining is not None:
                lines.append(f"| Remaining | ${remaining:,.2f} |")

        # CostGuard UnifiedResponse fields
        headroom = budget.get("available_headroom")
        consumption_pct = budget.get("projected_consumption_pct")

        if (headroom is not None or consumption_pct is not None) and monthly_limit is None:
            if consumption_pct is not None:
                bar_filled = int(min(consumption_pct, 100) / 5)
                bar_empty = 20 - bar_filled
                bar = "█" * bar_filled + "░" * bar_empty
                lines.append("```")
                lines.append(f"[{bar}] {consumption_pct:.0f}% consumed")
                lines.append("```\n")

            lines.append("| Metric | Value |")
            lines.append("|--------|------:|")
            if consumption_pct is not None:
                lines.append(f"| Consumption | {consumption_pct:.1f}% |")
            if headroom is not None:
                lines.append(f"| Available Headroom | ${headroom:,.2f} |")

        return "\n".join(lines)

    def _violations_section(self, violations: list[dict], guardrails: dict | None = None) -> str:
        lines = ["### Guardrail Violations\n"]

        if guardrails:
            gs = guardrails.get("summary") or {}
            total = gs.get("rules_evaluated") or guardrails.get("evaluated") or guardrails.get("total", 0)
            passed = gs.get("rules_passed") or guardrails.get("passed", 0)
            failed = gs.get("rules_failed") or guardrails.get("failed", 0)
            lines.append(f"**{passed}/{total}** guardrails passed | **{failed}** failed\n")

        for v in violations:
            severity = (v.get("severity") or "low").lower()
            icon = self.SEVERITY_ICONS.get(severity, "🔵")
            rule = v.get("rule", "unknown")
            message = v.get("message", "")
            resource = v.get("resource", "")
            recommendation = v.get("recommendation", "")

            lines.append(f"- {icon} **[{severity.upper()}]** `{rule}`")
            if message:
                lines.append(f"  - {message}")
            if resource:
                lines.append(f"  - Resource: `{resource}`")
            if recommendation:
                lines.append(f"  - *Recommendation: {recommendation}*")

        return "\n".join(lines)

    def _narrative_section(self, narrative) -> str:
        import re
        if isinstance(narrative, dict):
            narrative = narrative.get("html") or narrative.get("text", "")
        # Strip HTML tags for markdown display
        narrative = re.sub(r'<[^>]+>', '', narrative).strip()
        quoted = "\n".join(f"> {line}" for line in narrative.split("\n"))
        return f"### AI Analysis\n\n{quoted}"

    def _collapsible_details(self, response: dict) -> str:
        if "endpoint_data" in response:
            results = response.get("results") or {}
            endpoint_data = response.get("endpoint_data") or {}
        else:
            results = response
            endpoint_data = response

        detail_lines = [
            "<details>",
            "<summary>Full Analysis Details</summary>\n",
        ]

        # Request metadata
        request_id = response.get("request_id", "N/A")
        timestamp = response.get("timestamp", "N/A")
        processing_time = response.get("processing_time_ms", "N/A")
        iac_type = endpoint_data.get("iac_type", "N/A")
        schema_version = response.get("schema_version", "N/A")

        detail_lines.append("| Property | Value |")
        detail_lines.append("|----------|-------|")
        detail_lines.append(f"| Request ID | `{request_id}` |")
        detail_lines.append(f"| Timestamp | {timestamp} |")
        detail_lines.append(f"| Processing Time | {processing_time}ms |")
        detail_lines.append(f"| IaC Type | {iac_type} |")
        detail_lines.append(f"| Schema Version | {schema_version} |")

        # Per-resource hourly costs
        resources = results.get("resources") or []
        if resources:
            detail_lines.append("\n**Hourly Cost Breakdown:**\n")
            detail_lines.append("| Resource | Hourly Cost |")
            detail_lines.append("|----------|------------:|")
            for r in resources:
                name = r.get("resource_name") or r.get("resource_id", "unknown")
                hourly = r.get("hourly_cost")
                hourly_str = f"${hourly:,.4f}" if hourly is not None else "N/A"
                detail_lines.append(f"| `{name}` | {hourly_str} |")

        detail_lines.append("\n</details>")
        return "\n".join(detail_lines)

    def _errors_section(self, errors: list) -> str:
        lines = ["### Errors\n"]
        for err in errors:
            if isinstance(err, dict):
                lines.append(f"- {err.get('message', str(err))}")
            else:
                lines.append(f"- {err}")
        return "\n".join(lines)

    def _footer(self, response: dict) -> str:
        processing_time = response.get("processing_time_ms")
        time_str = f" in {processing_time}ms" if processing_time is not None else ""

        return (
            f"---\n"
            f"*Generated by [CostGuard](https://skyxops.com/costguard){time_str} "
            f"-- SKYXOPS shift-left cost governance*"
        )
