# oprelay

Agent operational state relay — append-only ledger for multi-agent systems.

Coming soon. Follow progress at https://oprelay.com