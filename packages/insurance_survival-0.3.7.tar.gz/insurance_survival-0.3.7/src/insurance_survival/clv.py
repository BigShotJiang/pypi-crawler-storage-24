"""
SurvivalCLV: survival-adjusted customer lifetime value.

Integrates survival retention probability with premium income and expected
loss costs across a planning horizon:

    CLV(x) = sum_{t=1}^{T} S(t|x(t)) * (P_t - C_t) * (1+r)^{-t}

The key complication vs a simple NPV calculation is that the covariate path
x(t) changes over time: NCD level advances year by year via a Markov chain,
and survival probability at year t depends on the entire covariate path.

This module handles that integration. NCD path marginalisation uses the exact
Markov chain expectation — no Monte Carlo required.

Post-PS21/11 (Consumer Duty), CLV analysis with documented methodology is
required for fair value assessment. The predict() output is designed to be
audit-friendly: it returns S(t) at every year, cure probability, and expected
tenure alongside the headline CLV figure.
"""

from __future__ import annotations

from typing import Any

import numpy as np
import polars as pl

from ._utils import (
    build_ncd_transition_matrix,
    default_uk_ncd_transitions,
    expected_ncd_path,
    to_polars,
)


class SurvivalCLV:
    """Survival-adjusted customer lifetime value for UK personal lines.

    Computes per-policy CLV integrating survival retention probability with
    premium income and expected loss cost:

        CLV(x) = sum_{t=1}^{T} S(t|x(t)) * (P_t - C_t) * (1+r)^{-t}

    where S(t|x(t)) uses projected covariate paths for x(t): NCD level
    advances via a Markov transition model, premium may be projected at a
    constant real level or with a supplied schedule.

    This is the primary output pricing teams need post-PS21/11 for discount
    targeting: whether to offer a loyalty discount of £d is a CLV decision —
    accept the discount if CLV(with discount) > CLV(without discount).

    Parameters
    ----------
    survival_model : Any
        A fitted lifelines fitter (WeibullAFTFitter, CoxPHFitter, or
        WeibullMixtureCureFitter) with a predict_survival_function method.
    horizon : int
        Planning horizon in years. Default 5.
    discount_rate : float
        Annual discount rate. Default 0.05.
    ncd_transitions : pl.DataFrame | None
        NCD Markov transition table (see Section 4.4 of design spec).
        If None, uses UK motor standard 1-step-up, 2-step-back rules.
    claim_freq_model : Any | None
        Optional model with predict(X) returning claim probability per policy.
        If None, a flat claim frequency from the ncd_transitions table is used.

    Examples
    --------
    >>> from lifelines import WeibullAFTFitter
    >>> from insurance_survival import SurvivalCLV
    >>>
    >>> aft = WeibullAFTFitter()
    >>> aft.fit(survival_df, duration_col="stop", event_col="event")
    >>>
    >>> clv = SurvivalCLV(survival_model=aft, horizon=5, discount_rate=0.05)
    >>> results = clv.predict(
    ...     policies,
    ...     premium_col="annual_premium",
    ...     loss_col="expected_loss",
    ... )
    >>> results.select(["policy_id", "clv", "cure_prob", "expected_tenure"])
    """

    def __init__(
        self,
        survival_model: Any,
        horizon: int = 5,
        discount_rate: float = 0.05,
        ncd_transitions: pl.DataFrame | None = None,
        claim_freq_model: Any | None = None,
    ) -> None:
        self.survival_model = survival_model
        self.horizon = horizon
        self.discount_rate = discount_rate
        self.claim_freq_model = claim_freq_model

        if ncd_transitions is None:
            self._ncd_transitions = default_uk_ncd_transitions()
        else:
            self._ncd_transitions = to_polars(ncd_transitions)

        # Determine max NCD from transitions table
        self._max_ncd = int(self._ncd_transitions["from_ncd"].max())
        self._transition_matrix = build_ncd_transition_matrix(
            self._ncd_transitions, self._max_ncd
        )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def predict(
        self,
        df: pl.DataFrame,
        premium_col: str = "annual_premium",
        loss_col: str = "expected_loss",
        premium_schedule: pl.DataFrame | None = None,
    ) -> pl.DataFrame:
        """Compute CLV for each policy in df.

        Parameters
        ----------
        df : pl.DataFrame
            Current policy covariates (one row per policy).
        premium_col : str
            Column with current annual premium. Used as the flat rate when
            premium_schedule is None.
        loss_col : str
            Column with expected annual loss cost. Used as the flat rate when
            premium_schedule is None.
        premium_schedule : pl.DataFrame | None
            Per-policy, per-year schedule. Must contain policy_id, policy_year,
            annual_premium, expected_loss. If None, flat schedule is used (i.e.
            current-year premium and loss are repeated for every horizon year).
            When provided, year t uses the row where policy_year == t; any year
            not present in the schedule falls back to the flat value.

        Returns
        -------
        pl.DataFrame
            One row per policy. Columns:
            policy_id, clv, survival_integral, cure_prob, s_yr1 ... s_yr{T}.
        """
        df = to_polars(df)

        has_policy_id = "policy_id" in df.columns
        if not has_policy_id:
            df = df.with_row_index("policy_id")

        premiums = df[premium_col].to_numpy()
        losses = df[loss_col].to_numpy() if loss_col in df.columns else np.zeros(len(df))

        # Build schedule lookups keyed by (policy_id, year) if provided.
        # premium_schedule must have columns: policy_id, policy_year,
        # annual_premium, expected_loss.
        sched_premiums: dict[tuple, float] | None = None
        sched_losses: dict[tuple, float] | None = None
        if premium_schedule is not None:
            sched_premium_col = "annual_premium"
            sched_loss_col = "expected_loss"
            sched_premiums = {}
            sched_losses = {}
            for row in premium_schedule.iter_rows(named=True):
                key = (row["policy_id"], int(row["policy_year"]))
                sched_premiums[key] = float(row[sched_premium_col])
                if sched_loss_col in premium_schedule.columns:
                    sched_losses[key] = float(row[sched_loss_col])

        ncd_col = "ncd_years" if "ncd_years" in df.columns else None

        # Survival probabilities per year for each policy
        surv_matrix = self._compute_survival_path(df, ncd_col)
        # surv_matrix shape: (n_policies, horizon)

        # Discount factors: (1+r)^{-t} for t = 1 .. T
        discount_factors = np.array(
            [1.0 / (1.0 + self.discount_rate) ** t for t in range(1, self.horizon + 1)]
        )

        policy_ids = df["policy_id"].to_list()

        # Compute CLV per policy
        clv_values = np.zeros(len(df))
        for t_idx in range(self.horizon):
            t = t_idx + 1  # 1-indexed year

            if sched_premiums is not None:
                # Use schedule values year-by-year; fall back to flat if missing
                p_t = np.array([
                    sched_premiums.get((pid, t), premiums[i])
                    for i, pid in enumerate(policy_ids)
                ])
                l_t = np.array([
                    sched_losses.get((pid, t), losses[i]) if sched_losses else losses[i]
                    for i, pid in enumerate(policy_ids)
                ])
            else:
                p_t = premiums
                l_t = losses

            net_profit = p_t - l_t
            clv_values += surv_matrix[:, t_idx] * net_profit * discount_factors[t_idx]

        # Expected tenure = sum of survival probabilities
        survival_integral = surv_matrix.sum(axis=1)

        # Cure probabilities (available for WeibullMixtureCureFitter)
        cure_probs = self._get_cure_probs(df)

        # Build output DataFrame
        result_dict: dict[str, Any] = {
            "policy_id": policy_ids,
            "clv": clv_values.tolist(),
            "survival_integral": survival_integral.tolist(),
            "cure_prob": cure_probs,
        }
        for t_idx in range(self.horizon):
            result_dict[f"s_yr{t_idx + 1}"] = surv_matrix[:, t_idx].tolist()

        return pl.DataFrame(result_dict)

    def discount_sensitivity(
        self,
        df: pl.DataFrame,
        discount_amounts: list[float],
        retention_lift_model: Any | None = None,
        price_elasticity: float = -0.5,
        premium_schedule: pl.DataFrame | None = None,
    ) -> pl.DataFrame:
        """Compute CLV under a range of loyalty discount amounts.

        For each discount d in discount_amounts, computes CLV with two effects:
        1. Revenue effect: annual premium is reduced by d.
        2. Retention effect: survival probabilities are adjusted upward to
           reflect that a lower price makes the customer more likely to renew.

        Retention adjustment
        --------------------
        If ``retention_lift_model`` is None, a simple price-elasticity model is
        applied: the survival probability at each year is scaled by

            adjustment = exp(price_elasticity * log(P_discounted / P_base))

        where ``price_elasticity`` defaults to -0.5 (i.e. a 10% price reduction
        increases retention probability by ~5%). This is multiplicative on the
        survival function and is the minimum viable model.

        If ``retention_lift_model`` is provided, it must implement a
        predict_retention_multiplier(df, discount_amounts) method that returns
        a (n_policies,) array of survival multipliers for each discount amount.

        The ``premium_schedule`` parameter, if provided, overrides the flat
        premium in ``df`` for Year 1 and is passed through to predict().

        Parameters
        ----------
        df : pl.DataFrame
            Current policy covariates. Must contain ``annual_premium``.
        discount_amounts : list[float]
            Discount amounts in GBP to test (e.g. [25, 50, 100]).
        retention_lift_model : Any | None
            Optional model implementing predict_retention_multiplier().
            If None, uses price elasticity formula above.
        price_elasticity : float
            Price elasticity of retention (negative: lower price -> higher
            retention). Only used when retention_lift_model is None.
            Default -0.5. Set to 0.0 to model revenue-only effect.
        premium_schedule : pl.DataFrame | None
            Per-policy, per-year schedule passed to predict(). If None, flat
            premium from df is used for all years.

        Returns
        -------
        pl.DataFrame
            Columns: policy_id, discount_amount, clv_with_discount,
            clv_without_discount, incremental_clv, discount_justified,
            retention_multiplier.
        """
        df = to_polars(df)

        has_policy_id = "policy_id" in df.columns
        if not has_policy_id:
            df = df.with_row_index("policy_id")

        premium_col = "annual_premium"
        if premium_col not in df.columns:
            raise ValueError(f"Column '{premium_col}' not found in df.")

        base_premiums = df[premium_col].to_numpy()

        # Baseline CLV without discount
        base_result = self.predict(df, premium_schedule=premium_schedule)
        base_clv = np.array(base_result["clv"].to_list())
        policy_ids = df["policy_id"].to_list()

        # Year-by-year discount factors (1+r)^{-t} for proper NPV weighting.
        # Using an average discount factor across the horizon is wrong: it
        # over-weights far-future cash flows relative to a proper NPV.
        discount_factors = np.array(
            [1.0 / (1.0 + self.discount_rate) ** t for t in range(1, self.horizon + 1)]
        )

        rows: list[dict[str, Any]] = []
        for d_amount in discount_amounts:
            discounted_premiums = base_premiums - float(d_amount)
            # Avoid zero or negative premiums
            price_ratio = np.where(
                base_premiums > 0,
                np.maximum(discounted_premiums, 1e-3) / base_premiums,
                1.0,
            )

            if retention_lift_model is not None:
                # Use provided model: must return array of multipliers (n_policies,)
                retention_multipliers = np.asarray(
                    retention_lift_model.predict_retention_multiplier(df, d_amount)
                )
            else:
                # Simple price elasticity: exp(elasticity * log(price_ratio))
                # For elasticity=-0.5 and a 10% price cut (ratio=0.9):
                #   multiplier = 0.9^(-0.5) ≈ 1.054  -> 5.4% retention lift
                retention_multipliers = np.exp(
                    price_elasticity * np.log(np.maximum(price_ratio, 1e-6))
                )

            # Build discounted df with reduced premium
            df_discounted = df.with_columns(
                pl.Series(premium_col, discounted_premiums.tolist())
            )

            # Compute survival with retention adjustment applied to the base
            # survival matrix, then recompute CLV with discounted premiums.
            # We do this by temporarily monkey-patching the survival model
            # prediction via a wrapper that scales S(t) by the multiplier.
            # For simplicity: predict CLV with discounted premium (revenue
            # effect), then scale the survival integral by the retention
            # multiplier to get the retention-adjusted CLV.
            disc_result = self.predict(df_discounted, premium_schedule=premium_schedule)
            disc_clv_revenue_only = np.array(disc_result["clv"].to_list())

            # Retention-adjusted CLV: the discounted premium CLV already
            # accounts for the lower revenue. We add back the incremental
            # value from retaining more customers (higher survival integral).
            # Use the baseline survival integral as the reference for scaling,
            # not the discounted-premium survival integral, because the
            # retention adjustment is applied to the *base* survival curve.
            disc_surv_integral = np.array(disc_result["survival_integral"].to_list())
            base_surv_integral = np.array(base_result["survival_integral"].to_list())

            # Adjusted survival integral = base * retention_multiplier (capped at 2x)
            adj_surv_integral = base_surv_integral * np.minimum(retention_multipliers, 2.0)
            # Incremental from better retention
            net_profit = discounted_premiums - (
                df["expected_loss"].to_numpy() if "expected_loss" in df.columns
                else np.zeros(len(df))
            )
            # Use the mean of year-by-year discount factors to convert the
            # incremental survival integral (in years) to a present-value
            # equivalent. This is an approximation but consistent with the
            # CLV formula above — each year's incremental retained customer
            # is weighted by the correct time-value factor on average.
            # Note: this is NOT the same as using avg_discount_factor of the
            # base series; we compute it from the proper NPV weights.
            mean_discount_factor = float(np.mean(discount_factors))
            retention_clv_adj = (
                (adj_surv_integral - base_surv_integral)
                * net_profit
                * mean_discount_factor
            )
            disc_clv = disc_clv_revenue_only + retention_clv_adj

            for i, pid in enumerate(policy_ids):
                rows.append({
                    "policy_id": pid,
                    "discount_amount": float(d_amount),
                    "clv_with_discount": float(disc_clv[i]),
                    "clv_without_discount": float(base_clv[i]),
                    "incremental_clv": float(disc_clv[i] - base_clv[i]),
                    "discount_justified": bool(disc_clv[i] >= base_clv[i]),
                    "retention_multiplier": float(retention_multipliers[i]),
                })

        return pl.DataFrame(rows)

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _compute_survival_path(
        self,
        df: pl.DataFrame,
        ncd_col: str | None,
    ) -> np.ndarray:
        """Compute S(t) for t = 1 .. horizon for each policy.

        Returns np.ndarray of shape (n_policies, horizon).
        """
        n = len(df)
        horizon = self.horizon
        surv_matrix = np.zeros((n, horizon))

        # For lifelines fitters: use predict_survival_function
        # For WeibullMixtureCureFitter: use our own predict_survival_function
        from ._cure_legacy import WeibullMixtureCureFitter

        is_cure_model = isinstance(self.survival_model, WeibullMixtureCureFitter)

        if is_cure_model:
            # WeibullMixtureCureFitter: predict_survival_function returns a Polars DF
            # with columns S_t1, S_t2, ...
            times = list(range(1, horizon + 1))
            surv_df = self.survival_model.predict_survival_function(df, times=times)
            for t_idx, t in enumerate(times):
                col = f"S_t{t_idx + 1}"
                surv_matrix[:, t_idx] = surv_df[col].to_numpy()
        else:
            # lifelines fitter: predict_survival_function returns pd.DataFrame
            # where index is time and columns are individual predictions
            # We need per-year S(t) for each policy, accounting for NCD path
            times = list(range(1, horizon + 1))

            try:
                # Attempt time-varying covariate path
                if ncd_col is not None and hasattr(self, "_transition_matrix"):
                    surv_matrix = self._compute_lifelines_path_varying(
                        df, ncd_col, times
                    )
                else:
                    surv_matrix = self._compute_lifelines_static(df, times)
            except Exception:
                # Fall back to static prediction
                surv_matrix = self._compute_lifelines_static(df, times)

        return surv_matrix

    def _compute_lifelines_static(
        self,
        df: pl.DataFrame,
        times: list[int],
    ) -> np.ndarray:
        """Predict survival at fixed times using lifelines model (static covariates)."""
        import pandas as pd

        pdf = df.to_pandas()
        # Drop non-numeric string columns that lifelines cannot use as covariates.
        # lifelines predict_survival_function only needs the covariates that were
        # present at fit time; extra columns cause casting errors.
        object_cols = [c for c in pdf.columns if pdf[c].dtype == object]
        if object_cols:
            pdf = pdf.drop(columns=object_cols)
        sf = self.survival_model.predict_survival_function(
            pdf, times=times
        )
        # sf is (len(times), n_policies) in lifelines
        return sf.values.T  # -> (n_policies, len(times))

    def _compute_lifelines_path_varying(
        self,
        df: pl.DataFrame,
        ncd_col: str,
        times: list[int],
    ) -> np.ndarray:
        """Predict survival with NCD path marginalisation.

        For each policy:
        - Compute E[NCD(t)] by running the Markov chain t steps forward
        - Build updated covariate vector with expected NCD at each year
        - Compute S(t) using those updated covariates

        This is the path-marginalised approximation. It evaluates the survival
        function at each year with covariates updated to the expected NCD level,
        treating integer-year boundaries as covariate update points.
        """
        import pandas as pd

        n = len(df)
        horizon = len(times)
        surv_matrix = np.zeros((n, horizon))

        ncd_yearss = df[ncd_col].to_numpy()

        for i in range(n):
            ncd_0 = int(ncd_yearss[i]) if not np.isnan(ncd_yearss[i]) else 0
            ncd_0 = max(0, min(ncd_0, self._max_ncd))

            # Expected NCD at each future year
            exp_ncd = expected_ncd_path(ncd_0, horizon, self._transition_matrix)

            for t_idx, t in enumerate(times):
                # Build updated covariate row
                updated = df[i, :].to_frame().T if False else df[i:i+1, :]
                updated = updated.with_columns(
                    pl.lit(float(exp_ncd[t_idx])).alias(ncd_col)
                )
                pdf = updated.to_pandas()
                sf_val = self.survival_model.predict_survival_function(
                    pdf, times=[t]
                )
                surv_matrix[i, t_idx] = float(sf_val.iloc[0, 0])

        return surv_matrix

    def _get_cure_probs(self, df: pl.DataFrame) -> list[float]:
        """Extract cure probabilities if model supports it."""
        from ._cure_legacy import WeibullMixtureCureFitter

        if isinstance(self.survival_model, WeibullMixtureCureFitter):
            probs = self.survival_model.predict_cure(df)
            return probs.to_list()
        else:
            return [float("nan")] * len(df)
