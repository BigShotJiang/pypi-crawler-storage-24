import random
import sys

from terminaltexteffects.effects import (
    effect_beams,
    effect_fireworks,
    effect_middleout,
    effect_rain,
    effect_rings,
    effect_slide,
    effect_spray,
    effect_swarm,
    effect_waves,
    effect_wipe,
)

EFFECTS_MAP = {
    "beams":     effect_beams.Beams,
    "fireworks": effect_fireworks.Fireworks,
    "middleout": effect_middleout.MiddleOut,
    "rain":      effect_rain.Rain,
    "rings":     effect_rings.Rings,
    "slide":     effect_slide.Slide,
    "spray":     effect_spray.Spray,
    "swarm":     effect_swarm.Swarm,
    "waves":     effect_waves.Waves,
    "wipe":      effect_wipe.Wipe,
}

CARD = """
╔══════════════════════════════════════════════════╗
║                                                  ║
║                  Rui Watanabe                    ║
║                   📍 Japan                       ║
║                                                  ║
║  ──────────────────────────────────────────────  ║
║                                                  ║
║  Company : Nissan Motor Co., Ltd.  |  R&D        ║
║  X       : @iocomk                               ║
║  Web     : https://iocomk.github.io              ║
║                                                  ║
║  Card    : uvx r-watanabe                        ║
║                                                  ║
╚══════════════════════════════════════════════════╝
""".strip()


def _tune(effect):
    """各エフェクトの速度パラメータを最大化する"""
    effect.terminal_config.frame_rate = 80
    cfg = effect.effect_config
    name = type(effect).__name__.lower()

    if name == "beams":
        cfg.beam_delay = 1
        cfg.beam_row_speed_range = (40, 80)
        cfg.beam_column_speed_range = (20, 40)
        cfg.final_gradient_frames = 1
        cfg.final_wipe_speed = 5
    elif name == "fireworks":
        cfg.launch_delay = 5
    elif name == "middleout":
        cfg.center_movement_speed = 1.5
        cfg.full_movement_speed = 1.5
    elif name == "rain":
        cfg.movement_speed = (0.5, 1.0)
    elif name == "rings":
        cfg.spin_speed = (2.0, 4.0)
    elif name == "slide":
        cfg.movement_speed = 3.0
        cfg.final_gradient_frames = 1
    elif name == "spray":
        cfg.movement_speed_range = (2.0, 4.0)
    elif name == "wipe":
        cfg.wipe_ease_stepsize = 0.05
        cfg.final_gradient_frames = 1
    # waves / swarm / middleout は frame_rate=0 で十分速い


def apply_effect(name: str, text: str = CARD):
    effect = EFFECTS_MAP[name](text)
    _tune(effect)
    with effect.terminal_output() as terminal:
        for frame in effect:
            terminal.print(frame)


FAST_EFFECTS = ["beams", "middleout", "slide", "wipe", "spray", "rain", "matrix", "decrypt"]


def main():
    """Rui Watanabe's digital business card."""
    arg = sys.argv[1].lower() if len(sys.argv) > 1 else None
    name = arg if arg in EFFECTS_MAP else random.choice(FAST_EFFECTS)
    apply_effect(name)


if __name__ == "__main__":
    main()
