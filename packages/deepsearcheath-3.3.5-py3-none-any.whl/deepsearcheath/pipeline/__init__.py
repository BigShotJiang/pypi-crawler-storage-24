# =============================================================================
# pipeline/ — 데이터 수집·가공·캐싱 계층
# =============================================================================
#
# DeepSearchClient(client/) 위에서 동작하는 상위 레이어.
# 비동기 API 호출, 캐싱, 유니버스 관리 등 데이터 파이프라인을 담당한다.
#
# -----------------------------------------------------------------------------
# 모듈별 설명
# -----------------------------------------------------------------------------
#
# market.py — 시세 데이터 수집 및 준비
#   - prepare_market_data()     : 종목 리스트의 주가 데이터를 비동기 수집하고
#                                 parquet 캐시로 관리하는 메인 파이프라인.
#                                 "ALL_US", "ALL_KO" 키워드로 전체 시장 대상 가능.
#                                 1년 단위 날짜 청킹, 세마포어 동시성 제어, 지수 백오프 재시도.
#   - get_krx_market_price()    : KRX Open API를 통해 특정 일자의 유가증권/코스닥
#                                 전 종목 시세(종가, 시총, 거래량 등)를 조회.
#   - get_krx_market_price_period() : 기간별 KRX 시세를 일자별로 수집 후 통합.
#                                     갭 수익률(GAP_RT) 계산 포함.
#
# news.py — 뉴스 데이터 수집 및 가공
#   - prepare_news_data()       : 종목/키워드 기반 뉴스를 비동기 수집하고 캐싱.
#                                 페이징 자동 처리, 원본 JSON 저장 옵션.
#   - collect_news_frozen()     : 대용량 뉴스 고정 수집 (배치 단위 parquet 저장).
#                                 이미 수집된 배치는 건너뛰는 안전 수집 방식.
#   - collect_news_liquid()     : 증분 업데이트 방식의 뉴스 수집.
#                                 기존 parquet의 마지막 날짜부터 이어서 수집.
#   - load_and_preprocess_news(): 저장된 parquet 뉴스 데이터를 로드하고
#                                 섹션/언론사/날짜 필터링 적용.
#   - filter_news_by_symbol()   : 뉴스 DataFrame에서 특정 종목 관련 기사만 필터링.
#   - split_news_by_session()   : 뉴스를 장중(Intraday)/장후(Aftermarket)/
#                                 야간(Overnight) 시간대별로 분리.
#
# disclosure.py — 공시 데이터 수집 및 가공
#   - prepare_disclosure_data()  : 종목/키워드 기반 공시를 비동기 수집하고 캐싱.
#                                  페이징 자동 처리, 원본 JSON 저장 옵션.
#   - collect_disclosure_frozen(): 대용량 공시 고정 수집 (배치 단위 parquet 저장).
#                                  이미 수집된 배치는 건너뛰는 안전 수집 방식.
#
# store.py — 캐시 저장소
#   - MarketDataCache           : 가격/뉴스/메타데이터를 parquet으로 관리하는 dataclass.
#                                 get_price(), get_news(), get_market_matrices() 등
#                                 데이터 조회 인터페이스 제공.
#                                 종가·시총·거래량·수익률 행렬(pivot) 변환 지원.
#
# universe.py — 종목 유니버스 관리
#   - UniverseManager           : NASDAQ/NYSE FTP 및 DeepSearch API를 통해
#                                 미국·한국 전체 상장 종목 목록을 가져오고 캐싱.
#                                 ETF 제외, 특수문자 종목 제외 등 정제 로직 포함.
#
# llm.py — LLM 호출
#   - gemini()                   : Google Gemini API 단일 호출 (무상태).
#                                  prompt, model, max_tokens만 지정하면 텍스트 반환.
#                                  data= 로 DataFrame 전달 시 메타정보+샘플 자동 첨부.
#   - GeminiChat                 : 멀티턴 대화 클래스 (유상태).
#                                  send()로 메시지 전송, 히스토리 자동 누적.
#                                  reset()으로 대화 초기화.
#   - 사용 가능한 모델: https://ai.google.dev/gemini-api/docs/models
#
# constants.py — 상수 정의
#   - MAINSTREAM_NEWS_VENDORS   : 한국 주요 언론사 47개 목록 (set).
#                                 뉴스 필터링 시 mainstream_only 옵션에 사용.
#
# =============================================================================

from .market import prepare_market_data, get_krx_market_price, get_krx_market_price_period
from .news import prepare_news_data, collect_news_frozen, collect_news_liquid
from .disclosure import prepare_disclosure_data, collect_disclosure_frozen
from .llm import gemini, GeminiChat
from .prompts import METHODOLOGIES
from .store import MarketDataCache
from .universe import UniverseManager
from .constants import MAINSTREAM_NEWS_VENDORS
from .collection_index import CollectionIndex

__all__ = [
    "prepare_market_data",
    "get_krx_market_price",
    "get_krx_market_price_period",
    "prepare_news_data",
    "collect_news_frozen",
    "collect_news_liquid",
    "prepare_disclosure_data",
    "collect_disclosure_frozen",
    "gemini",
    "GeminiChat",
    "METHODOLOGIES",
    "MarketDataCache",
    "UniverseManager",
    "MAINSTREAM_NEWS_VENDORS",
    "CollectionIndex",
]
