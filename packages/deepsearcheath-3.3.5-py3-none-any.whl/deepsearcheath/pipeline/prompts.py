# =============================================================================
# 반복 사용되는 LLM 방법론/프롬프트 템플릿 상수
#
# 사용법:
#   from deepsearcheath.pipeline.prompts import METHODOLOGIES
#   text = METHODOLOGIES["keyword"]
#
#   또는 gemini() / GeminiChat에서 methodology="keyword" 파라미터로 자동 주입
# =============================================================================

KEYWORD_METHODOLOGY = """
[최신화된 키워드 추출 방법론: 계층적 원자화 프로토콜(HAP) v2.0]

이 방법론은 분석 대상인 '최상위 컨테이너(Root)'를 설정하고, 그 내부를 구성하는 실체적 '원자적 부품(Atoms)'만을 키워드로 채택하여 기업의 기술적 해자를 판별합니다.

[Rule 1] 구조적 원자성 (Structural Atomicity)
- 키워드는 산업 설계도 상에서 더 이상 분해하기 어려운 최소 단위의 '구체 명사(Concrete Noun)'여야 함.
- 포함: 소재(Materials), 부품(Components), 단위 장치(Unit Devices), 코어 소프트웨어 모듈.
- 배제: 거시적 환경(Context), 시장 상태(Status), 추상적 경영 이슈.

[Rule 2] 계층적 하위 종속 (Hierarchical Subordination)
- 키워드의 논리적 위계는 반드시 'Root'보다 낮아야 하며, Root의 내부 구성 요소('Part-of')여야 함.
- 원리: Root를 도구로 사용하는 '상위 시스템'이나 '활용처(Target Market)'는 제외함.
- 예시: Root가 'ESS'인 경우, 'LFP(소재)'는 포함하나 'VPP(활용처/플랫폼)'는 배제함.

[Rule 3] 분류학적 앵커링 (Taxonomic Anchoring)
- 키워드는 특정 종목을 해당 섹터에 물리적으로 고정(Anchor)할 수 있는 기준이어야 함.
- 기준: "이 키워드(기술/제품)가 소멸했을 때, 해당 기업이 이 산업군(Root)에 존재할 물리적 근거가 사라지는가?"
- 배제: 타 산업(전기차, 가전 등)에서도 광범위하게 쓰이는 범용적 형용사(예: 고효율, 슬림형).

[Rule 4] 실체적 노드 중심주의 (Entity-Based Specificity)
- 키워드는 '어떤 방식(How)'을 나타내는 형용사적 속성이 아닌, '무엇(What)'을 나타내는 실체적 노드여야 함.
- 원리: 설계 스타일이나 형용사적 분류는 배제하고, 물리적 실체가 있는 장치/기술명만 채택함.

[Rule 5] 기술적 해자(Tech-Moat)의 변곡점
- 산업의 표준(Standard)이 이동하는 방향을 나타내는 기술적 이정표여야 함.
- 기업 간의 기술적 격차를 구별하는 구체적인 '역할 명사' 혹은 '원천 기술명'이어야 함.
""".strip()

# 방법론 레지스트리 — methodology 파라미터로 키 이름을 지정하면 자동 주입
METHODOLOGIES = {
    "keyword": KEYWORD_METHODOLOGY,
}
