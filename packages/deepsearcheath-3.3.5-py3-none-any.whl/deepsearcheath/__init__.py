# =============================================================================
# deepsearcheath
# =============================================================================
#
# 새 아키텍처:
#   from deepsearcheath import DeepSearch
#   ds = DeepSearch()
#   price, mktcap = await ds.stock.get(["AAPL"], "2024-01-01", "2025-01-01")
#
# 레거시:
#   from deepsearcheath import deepsearch as ds
#   ds.DeepSearchGlobalAPI()
#
# -----------------------------------------------------------------------------
# LLM (Gemini) 사용법
# -----------------------------------------------------------------------------
#
# 환경변수: GEMINI_API_KEY 설정 필요
# 사용 가능한 모델: https://ai.google.dev/gemini-api/docs/models
#
# 1) 단일 호출 (무상태):
#   import deepsearcheath as ds
#
#   # 텍스트만
#   result = await ds.gemini("ESS 시장 전망을 알려줘")
#
#   # DataFrame 분석 (메타정보 + 샘플 자동 첨부)
#   result = await ds.gemini("이 데이터의 추이를 분석해줘", data=df)
#
#   # 복수 DataFrame
#   result = await ds.gemini("뉴스와 주가의 상관관계를 분석해줘", data=[news_df, price_df])
#
#   # 모델/토큰/온도 지정
#   result = await ds.gemini("요약해줘", data=df, model="gemini-2.5-pro", max_tokens=2048)
#
# 2) 멀티턴 대화 (유상태):
#   chat = ds.GeminiChat(system_instruction="한국어로 답변해줘")
#
#   r1 = await chat.send("이 데이터의 추이를 분석해줘", data=df)
#   r2 = await chat.send("그 중 감성이 가장 부정적인 날짜는?")
#   r3 = await chat.send("그 날짜의 뉴스 제목을 정리해줘")
#
#   chat.turn_count  # 현재 턴 수
#   chat.history     # 전체 대화 히스토리
#   chat.reset()     # 대화 초기화
#
# =============================================================================

from .core import DeepSearch
from .client.http import DeepSearchClient, KRXClient
from .client.gemini import GeminiClient
from .pipeline.market import prepare_market_data
from .pipeline.llm import gemini, GeminiChat
from .pipeline.news import prepare_news_data, collect_news_frozen, collect_news_liquid
from .pipeline.disclosure import prepare_disclosure_data, collect_disclosure_frozen

__version__ = "3.3.5"

__all__ = [
    "DeepSearch",
    "DeepSearchClient",
    "KRXClient",
    "prepare_market_data",
    "prepare_news_data",
    "collect_news_frozen",
    "collect_news_liquid",
    "prepare_disclosure_data",
    "collect_disclosure_frozen",
    "GeminiClient",
    "gemini",
    "GeminiChat",
]
