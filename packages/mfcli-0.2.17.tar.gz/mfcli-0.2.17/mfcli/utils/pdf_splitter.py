import tempfile
from pathlib import Path
from uuid import uuid4

import pikepdf
from io import BytesIO

from mfcli.utils.logger import get_logger

logger = get_logger(__name__)

# PDF magic bytes — all valid PDFs start with "%PDF"
_PDF_MAGIC = b"%PDF"


class CorruptedPDFError(ValueError):
    """Raised when a PDF file is corrupted, truncated, or is not actually a PDF.

    Callers should treat this as a warning-level event, not a hard error.
    The file may be an HTML error page saved with a .pdf extension, a
    zero-byte file, or a genuinely damaged document.
    """


def validate_pdf_bytes(content: bytes, name: str = "") -> None:
    """Quick pre-flight check: does *content* start with the PDF magic bytes?

    Raises :class:`CorruptedPDFError` if the check fails so callers can
    skip/delete the file without printing a huge pikepdf traceback.
    """
    if not content:
        raise CorruptedPDFError(f"PDF file is empty: {name!r}")
    if not content[:16].startswith(_PDF_MAGIC):
        snippet = content[:80].decode("utf-8", errors="replace")
        raise CorruptedPDFError(
            f"File does not start with %PDF magic bytes — "
            f"likely an HTML error page or truncated download: {name!r}. "
            f"First 80 bytes: {snippet!r}"
        )


class PDFSplitter:
    def __init__(self, file_name: str, content: bytes):
        self._name = file_name
        self._content = content
        # Validate upfront so callers get a clean error before we try pikepdf
        validate_pdf_bytes(content, file_name)

    @staticmethod
    def _head_page_limit(total_pages: int) -> int:
        if total_pages <= 30:
            return 10
        elif total_pages <= 100:
            return 20
        else:
            return 30

    def _open_pdf(self) -> pikepdf.Pdf:
        try:
            return pikepdf.open(BytesIO(self._content))
        except pikepdf._core.PdfError as exc:
            raise CorruptedPDFError(
                f"pikepdf could not open PDF '{self._name}': {exc}"
            ) from exc

    def split_pdf_head(self) -> Path:
        """
        Split the first N pages of a PDF into a separate file.
        
        Returns:
            Path to the temporary PDF file containing the head pages.
            The caller is responsible for deleting this file when done.
        """
        with self._open_pdf() as src:
            total_pages = len(src.pages)
            page_limit = self._head_page_limit(total_pages)

            dst = pikepdf.Pdf.new()
            dst.pages.extend(src.pages[:page_limit])

            # Use NamedTemporaryFile with delete=False to keep file until we're done with it
            # This prevents the file from being deleted prematurely
            with tempfile.NamedTemporaryFile(suffix=".pdf", delete=False) as tmp:
                output_path = Path(tmp.name)
            
            # Save the PDF to the temp file
            dst.save(output_path)
            
            logger.debug(f"Created temp PDF head: {output_path}")

            return output_path

    def extract_range(
            self,
            start_page: int,
            end_page: int,
            output_folder: Path,
    ) -> Path:
        logger.debug(f"Splitting PDF: {self._name}")

        output_folder.mkdir(parents=True, exist_ok=True)

        with self._open_pdf() as src:
            dst = pikepdf.Pdf.new()
            dst.pages.extend(src.pages[start_page:end_page + 1])

            output_path = output_folder / f"{uuid4().hex}.pdf"
            dst.save(output_path)

        logger.debug(f"Output PDF part to: {output_path}")
        logger.debug(f"PDF splitter finished: {self._name}")

        return output_path
