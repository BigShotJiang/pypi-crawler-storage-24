"""Interactive configuration wizard for mfcli."""
import os
import sys
from pathlib import Path
from typing import Optional

import requests

from mfcli.utils.directory_manager import app_dirs


def get_env_path() -> Path:
    """Get the path to the .env file."""
    return app_dirs.env_file_path


def read_existing_env() -> dict:
    """Read existing environment variables from .env file."""
    env_path = get_env_path()
    env_vars = {}
    
    if env_path.exists():
        with open(env_path, 'r') as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#') and '=' in line:
                    key, value = line.split('=', 1)
                    env_vars[key.strip()] = value.strip()
    
    return env_vars


def write_env_file(env_vars: dict) -> None:
    """Write environment variables to .env file."""
    env_path = get_env_path()
    env_path.parent.mkdir(parents=True, exist_ok=True)
    
    # Read the template
    template_path = Path(__file__).parent.parent / '.env.example'
    if not template_path.exists():
        # Fallback: create basic template
        template_content = []
        for key in env_vars:
            template_content.append(f"{key}={env_vars[key]}")
        content = '\n'.join(template_content)
    else:
        with open(template_path, 'r') as f:
            template_content = f.read()
        
        # Replace placeholder values with actual values
        content = template_content
        for key, value in env_vars.items():
            # Replace the placeholder value in the template
            content = content.replace(f"{key}=your_{key.lower()}_here", f"{key}={value}")
            content = content.replace(f"{key}=your_{key.replace('_', ' ').lower()}_here", f"{key}={value}")
            # Handle specific patterns
            if key == 'google_api_key':
                content = content.replace(f"{key}=your_google_api_key_here", f"{key}={value}")
            elif key == 'openai_api_key':
                content = content.replace(f"{key}=your_openai_api_key_here", f"{key}={value}")
            elif key == 'digikey_client_id':
                content = content.replace(f"{key}=your_digikey_client_id_here", f"{key}={value}")
            elif key == 'digikey_client_secret':
                content = content.replace(f"{key}=your_digikey_client_secret_here", f"{key}={value}")
            elif key == 'datasheet_quarry_api_key':
                # Template has empty value, replace the empty assignment
                content = content.replace(f"{key}=\n", f"{key}={value}\n")
                content = content.replace(f"{key}=\r", f"{key}={value}\r")
                # Also handle if it already has a value
                import re
                content = re.sub(rf"^{key}=.*$", f"{key}={value}", content, flags=re.MULTILINE)
            elif key == 'datasheet_quarry_url':
                # Uncomment and set the URL if provided
                content = content.replace(
                    f"# {key}=http://136.109.26.167",
                    f"{key}={value}"
                )
    
    with open(env_path, 'w') as f:
        f.write(content)


def prompt_for_value(
    key: str,
    description: str,
    link: Optional[str] = None,
    current_value: Optional[str] = None,
    required: bool = True
) -> Optional[str]:
    """Prompt user for a configuration value."""
    print(f"\n{'='*70}")
    print(f"  {description}")
    if link:
        print(f"  Get your key: {link}")
    if current_value and current_value != f"your_{key.lower()}_here":
        print(f"  Current value: {current_value[:20]}..." if len(current_value) > 20 else f"  Current value: {current_value}")
        prompt = f"  Enter new value (press Enter to keep current): "
    else:
        prompt = f"  Enter value{' (required)' if required else ' (optional)'}: "
    
    print(f"{'='*70}")
    
    value = input(prompt).strip()
    
    if not value:
        if current_value and current_value != f"your_{key.lower()}_here":
            return current_value
        elif not required:
            return None
        else:
            print("  ❌ This value is required!")
            return prompt_for_value(key, description, link, current_value, required)
    
    return value


def validate_api_key(key_name: str, api_key: str) -> bool:
    """Validate an API key by making a test request."""
    print(f"\n  Validating {key_name}...", end=' ')
    sys.stdout.flush()
    
    try:
        if key_name == "Google API":
            import google.generativeai as genai
            genai.configure(api_key=api_key)
            # Test with a simple list models call
            list(genai.list_models())
            print("✅")
            return True
        
        elif key_name == "OpenAI API":
            from openai import OpenAI
            client = OpenAI(api_key=api_key)
            # Test with a simple models list call
            client.models.list()
            print("✅")
            return True
        
        
        elif key_name == "DigiKey API":
            # DigiKey validation would require OAuth flow, so we'll just check format
            if len(api_key) > 10:
                print("✅ (format check)")
                return True
            else:
                print("❌ Invalid format")
                return False
        
    except Exception as e:
        print(f"❌ ({str(e)[:50]}...)")
        return False
    
    return True


def run_configuration_wizard() -> None:
    """Run the interactive configuration wizard."""
    print("\n" + "="*70)
    print("  MFCLI CONFIGURATION WIZARD")
    print("="*70)
    print("\n  This wizard will help you configure mfcli with your API keys.")
    print("  You can press Ctrl+C at any time to exit.\n")
    
    try:
        # Read existing configuration
        existing_env = read_existing_env()
        new_env = existing_env.copy()
        
        # Google API Key
        value = prompt_for_value(
            "google_api_key",
            "Google Gemini API Key",
            "https://aistudio.google.com/app/apikey",
            existing_env.get("google_api_key"),
            required=True
        )
        if value:
            new_env["google_api_key"] = value
            validate_api_key("Google API", value)
        
        # OpenAI API Key
        value = prompt_for_value(
            "openai_api_key",
            "OpenAI API Key (for embeddings)",
            "https://platform.openai.com/api-keys",
            existing_env.get("openai_api_key"),
            required=True
        )
        if value:
            new_env["openai_api_key"] = value
            validate_api_key("OpenAI API", value)
        
        # Datasheet Quarry (cloud datasheet service)
        print("\n" + "="*70)
        print("  Datasheet Quarry (Cloud Datasheet Service)")
        print("="*70)
        print("  Datasheet Quarry provides cloud-based datasheet lookup with")
        print("  better search, pre-processed bundles, and caching.")
        print("  If configured, it replaces direct DigiKey calls.")
        print("  DigiKey credentials become the fallback.\n")

        existing_quarry_key = existing_env.get("datasheet_quarry_api_key", "")
        if existing_quarry_key and existing_quarry_key.startswith("dsq_"):
            masked = existing_quarry_key[:12] + "..."
            print(f"  Current API key: {masked}")
            change_quarry = input("  Reconfigure Datasheet Quarry? (y/N): ").strip().lower()
            if change_quarry != 'y':
                new_env["datasheet_quarry_api_key"] = existing_quarry_key
                # Preserve existing URL override if any
                if existing_env.get("datasheet_quarry_url"):
                    new_env["datasheet_quarry_url"] = existing_env["datasheet_quarry_url"]
            else:
                _configure_quarry(new_env, existing_env)
        else:
            setup_quarry = input("  Set up Datasheet Quarry? (Y/n): ").strip().lower()
            if setup_quarry != 'n':
                _configure_quarry(new_env, existing_env)
            else:
                print("  Skipped. You can set it up later with: mfcli quarry-setup")

        # DigiKey Client ID (optional if Quarry is configured)
        quarry_configured = new_env.get("datasheet_quarry_api_key", "").startswith("dsq_")
        digikey_required = not quarry_configured

        if quarry_configured:
            print("\n" + "="*70)
            print("  DigiKey API Credentials (optional — Datasheet Quarry is primary)")
            print("="*70)
            print("  Since Datasheet Quarry is configured, DigiKey is only used as")
            print("  a fallback if the cloud service is unavailable.")

        value = prompt_for_value(
            "digikey_client_id",
            "DigiKey Client ID (for datasheet downloads)" if not quarry_configured
            else "DigiKey Client ID (fallback, press Enter to skip)",
            "https://developer.digikey.com/",
            existing_env.get("digikey_client_id"),
            required=digikey_required
        )
        if value:
            new_env["digikey_client_id"] = value
            validate_api_key("DigiKey API", value)

        # DigiKey Client Secret
        value = prompt_for_value(
            "digikey_client_secret",
            "DigiKey Client Secret" if not quarry_configured
            else "DigiKey Client Secret (fallback, press Enter to skip)",
            None,
            existing_env.get("digikey_client_secret"),
            required=digikey_required
        )
        if value:
            new_env["digikey_client_secret"] = value
        
        # Embedding configuration
        print("\n" + "="*70)
        print("  Vector Database Configuration")
        print("="*70)
        print("  Using default values:")
        print("  - Chunk size: 1000")
        print("  - Chunk overlap: 200")
        print("  - Embedding model: text-embedding-3-small")
        print("  - Embedding dimensions: 1536")
        
        change_defaults = input("\n  Change these defaults? (y/N): ").strip().lower()
        
        if change_defaults == 'y':
            value = input("  Chunk size [1000]: ").strip()
            new_env["chunk_size"] = value if value else "1000"
            
            value = input("  Chunk overlap [200]: ").strip()
            new_env["chunk_overlap"] = value if value else "200"
            
            value = input("  Embedding model [text-embedding-3-small]: ").strip()
            new_env["embedding_model"] = value if value else "text-embedding-3-small"
            
            value = input("  Embedding dimensions [1536]: ").strip()
            new_env["embedding_dimensions"] = value if value else "1536"
        else:
            new_env["chunk_size"] = existing_env.get("chunk_size", "1000")
            new_env["chunk_overlap"] = existing_env.get("chunk_overlap", "200")
            new_env["embedding_model"] = existing_env.get("embedding_model", "text-embedding-3-small")
            new_env["embedding_dimensions"] = existing_env.get("embedding_dimensions", "1536")
        
        # Write configuration
        write_env_file(new_env)
        
        env_path = get_env_path()
        print("\n" + "="*70)
        print("  ✅ Configuration saved successfully!")
        print(f"  Location: {env_path}")
        print("="*70)
        print("\n  Next steps:")
        print("  1. Run 'mfcli init' in your hardware project directory")
        print("  2. Run 'mfcli run' to process your documents")
        print("  3. (Optional) Run 'mfcli setup-mcp' to configure MCP server")
        print("\n")
        
    except KeyboardInterrupt:
        print("\n\n  ⚠️  Configuration cancelled.")
        sys.exit(0)


def _configure_quarry(new_env: dict, existing_env: dict) -> None:
    """Configure Datasheet Quarry API key (register or enter existing)."""
    print("\n  Options:")
    print("    1. Request a new API key (sent to your email)")
    print("    2. Enter an existing API key")
    choice = input("\n  Choose (1/2): ").strip()

    if choice == "1":
        # Request API key via email (public self-registration)
        email = input("  Enter your email address: ").strip()
        if not email or "@" not in email:
            print("  ❌ Invalid email address. Skipping.")
            return

        base_url = existing_env.get("datasheet_quarry_url", "")
        if not base_url:
            base_url = None

        print(f"\n  Requesting API key from Datasheet Quarry...", end=" ")
        sys.stdout.flush()
        try:
            from mfcli.client.datasheet_quarry import request_api_key
            result = request_api_key(email=email, base_url=base_url)
            print("✅")
            print(f"\n  📧 {result.get('message', 'API key has been sent to your email.')}")
            print(f"  Check your inbox at: {email}")
            print("\n  Once you receive the key, enter it below.")
            api_key = input("  Paste your API key (dsq_...): ").strip()
            if api_key and api_key.startswith("dsq_"):
                new_env["datasheet_quarry_api_key"] = api_key
                if base_url:
                    new_env["datasheet_quarry_url"] = base_url
                print("  ✅ API key saved.")
            elif api_key:
                print("  ⚠️  Key should start with 'dsq_'. Skipping.")
            else:
                print("  Skipped. You can add the key later with: mfcli quarry-setup")
        except requests.HTTPError as e:
            print(f"❌")
            status = e.response.status_code if hasattr(e, 'response') and e.response is not None else "?"
            if status == 429:
                print("  Rate limited — too many requests. Try again later.")
            elif status == 502:
                print("  Account created but email delivery failed.")
                print("  Try again in a few minutes with: mfcli quarry-setup")
            else:
                print(f"  Error: {e}")
            print("  You can try again later with: mfcli quarry-setup")
        except Exception as e:
            print(f"❌")
            print(f"  Connection error: {e}")
            print("  You can try again later with: mfcli quarry-setup")
    elif choice == "2":
        value = input("  Enter your Datasheet Quarry API key (dsq_...): ").strip()
        if value and value.startswith("dsq_"):
            new_env["datasheet_quarry_api_key"] = value
            # Validate by doing a health check
            print("  Validating API key...", end=" ")
            sys.stdout.flush()
            try:
                from mfcli.client.datasheet_quarry import DatasheetQuarryClient
                client = DatasheetQuarryClient(api_key=value)
                if client.health_check():
                    print("✅")
                else:
                    print("⚠️  Service unreachable (key saved anyway)")
            except Exception as e:
                print(f"⚠️  Could not validate ({e})")
        elif value:
            print("  ⚠️  Key should start with 'dsq_'. Skipping.")
        else:
            print("  Skipped.")
    else:
        print("  Skipped.")


def save_quarry_api_key(api_key: str, base_url: Optional[str] = None) -> None:
    """Save a Datasheet Quarry API key to the .env file."""
    env_path = get_env_path()

    if not env_path.exists():
        env_path.parent.mkdir(parents=True, exist_ok=True)
        env_path.touch()

    with open(env_path, 'r') as f:
        lines = f.readlines()

    # Update or append the API key
    key_updated = False
    url_updated = False
    new_lines = []

    for line in lines:
        stripped = line.strip()
        if stripped.startswith('datasheet_quarry_api_key='):
            new_lines.append(f"datasheet_quarry_api_key={api_key}\n")
            key_updated = True
        elif base_url and stripped.startswith('datasheet_quarry_url='):
            new_lines.append(f"datasheet_quarry_url={base_url}\n")
            url_updated = True
        else:
            new_lines.append(line)

    if not key_updated:
        new_lines.append(f"\n# Datasheet Quarry Configuration\n")
        new_lines.append(f"datasheet_quarry_api_key={api_key}\n")

    if base_url and not url_updated:
        new_lines.append(f"datasheet_quarry_url={base_url}\n")

    with open(env_path, 'w') as f:
        f.writelines(new_lines)


def run_quarry_setup() -> None:
    """Standalone interactive setup for Datasheet Quarry API key."""
    print("\n" + "="*70)
    print("  DATASHEET QUARRY SETUP")
    print("="*70)
    print("\n  Datasheet Quarry is a cloud service that provides:")
    print("    • Better part search (dual-strategy DigiKey + Octopart)")
    print("    • Pre-processed datasheet bundles (PDF + chunks + embeddings)")
    print("    • Cloud caching (no redundant API calls)")
    print("    • Centralized API key management")
    print("\n  This replaces direct DigiKey API calls for datasheet lookups.")

    existing_env = read_existing_env()
    existing_key = existing_env.get("datasheet_quarry_api_key", "")

    if existing_key and existing_key.startswith("dsq_"):
        masked = existing_key[:12] + "..."
        print(f"\n  Current API key: {masked}")
        proceed = input("  Replace existing key? (y/N): ").strip().lower()
        if proceed != 'y':
            print("\n  No changes made.")

            # Show quota info if possible
            try:
                from mfcli.client.datasheet_quarry import DatasheetQuarryClient
                client = DatasheetQuarryClient()
                if client.is_configured and client.health_check():
                    quota = client.get_quota()
                    print(f"\n  Quota: {quota.get('current_usage', '?')}/{quota.get('monthly_limit', '?')} "
                          f"(resets {quota.get('reset_date', 'N/A')})")
            except Exception:
                pass

            print("="*70 + "\n")
            return

    print("\n  Options:")
    print("    1. Request a new API key (sent to your email)")
    print("    2. Enter an existing API key manually")
    choice = input("\n  Choose (1/2): ").strip()

    if choice == "1":
        # Request API key via email (public self-registration)
        email = input("  Enter your email address: ").strip()
        if not email or "@" not in email:
            print("  ❌ Invalid email address.")
            print("=" * 70 + "\n")
            return

        print(f"\n  Requesting API key from Datasheet Quarry...", end=" ")
        sys.stdout.flush()
        try:
            from mfcli.client.datasheet_quarry import request_api_key
            result = request_api_key(email=email)
            print("✅")
            print(f"\n  📧 {result.get('message', 'API key has been sent to your email.')}")
            print(f"  Check your inbox at: {email}")
            print("\n  Once you receive the key, enter it below.")
            print("  (Or press Enter to skip and run 'mfcli quarry-setup' later)")
            api_key = input("\n  Paste your API key (dsq_...): ").strip()
            if api_key and api_key.startswith("dsq_"):
                save_quarry_api_key(api_key)
                env_path = get_env_path()
                print(f"\n  ✅ API key saved to: {env_path}")
            elif api_key:
                print("  ❌ Key should start with 'dsq_'. Not saved.")
            else:
                print("  Skipped. Run 'mfcli quarry-setup' after you receive the email.")

        except requests.HTTPError as e:
            print(f"❌")
            status = e.response.status_code if hasattr(e, 'response') and e.response is not None else "?"
            if status == 429:
                print("  Rate limited — too many requests. Try again later.")
            elif status == 502:
                print("  Account created but email delivery failed.")
                print("  Try again in a few minutes.")
            else:
                print(f"  Error: {e}")
                if hasattr(e, 'response') and e.response is not None:
                    try:
                        detail = e.response.json()
                        print(f"  Detail: {detail}")
                    except Exception:
                        pass

        except Exception as e:
            print(f"❌")
            print(f"  Connection error: {e}")
            print("  Check your network connection and try again.")

    elif choice == "2":
        api_key = input("  Enter your Datasheet Quarry API key (dsq_...): ").strip()
        if not api_key or not api_key.startswith("dsq_"):
            print("  ❌ Invalid key format. Must start with 'dsq_'.")
            print("="*70 + "\n")
            return

        # Validate
        print("  Validating...", end=" ")
        sys.stdout.flush()
        try:
            from mfcli.client.datasheet_quarry import DatasheetQuarryClient
            client = DatasheetQuarryClient(api_key=api_key)
            if client.health_check():
                print("✅ Service is healthy")
            else:
                print("⚠️  Service unreachable (saving key anyway)")
        except Exception as e:
            print(f"⚠️  {e}")

        save_quarry_api_key(api_key)
        env_path = get_env_path()
        print(f"\n  ✅ API key saved to: {env_path}")
    else:
        print("  Cancelled.")

    print("="*70 + "\n")


def check_configuration() -> None:
    """Check and validate existing configuration."""
    print("\n" + "="*70)
    print("  CONFIGURATION CHECK")
    print("="*70)
    
    env_path = get_env_path()
    
    if not env_path.exists():
        print(f"\n  ❌ Configuration file not found: {env_path}")
        print("\n  Run 'mfcli configure' to create your configuration.")
        return
    
    print(f"\n  Configuration file: {env_path}")
    
    env_vars = read_existing_env()

    # Check Datasheet Quarry
    quarry_key = env_vars.get("datasheet_quarry_api_key", "")
    quarry_configured = bool(quarry_key and quarry_key.startswith("dsq_"))

    print("\n  Datasheet Quarry (cloud datasheet service):")
    if quarry_configured:
        masked = quarry_key[:12] + "..."
        print(f"    ✅ API Key: {masked}")
        quarry_url = env_vars.get("datasheet_quarry_url", "http://136.109.26.167")
        quarry_local = env_vars.get("datasheet_quarry_local", "false").lower() in ("true", "1", "yes")
        if quarry_local:
            print(f"    🏠 LOCAL MODE → http://localhost:8080")
            print(f"    (Config URL ignored while local mode is active)")
        else:
            print(f"    URL: {quarry_url}")
    else:
        print(f"    ⚠️  Not configured (using DigiKey directly)")
        print(f"    Set up with: mfcli quarry-setup")

    required_keys = [
        ("google_api_key", "Google Gemini API"),
        ("openai_api_key", "OpenAI API"),
    ]

    # DigiKey is only required if Quarry is not configured
    if not quarry_configured:
        required_keys.extend([
            ("digikey_client_id", "DigiKey Client ID"),
            ("digikey_client_secret", "DigiKey Client Secret"),
        ])

    print("\n  Required API keys:")
    all_valid = True
    
    for key, name in required_keys:
        value = env_vars.get(key)
        if not value or value.startswith("your_"):
            print(f"    ❌ {name}: Not configured")
            all_valid = False
        else:
            masked_value = value[:8] + "..." if len(value) > 8 else value
            print(f"    ✅ {name}: {masked_value}")

    # Show DigiKey status as optional if Quarry is configured
    if quarry_configured:
        print("\n  Optional fallback keys:")
        for key, name in [("digikey_client_id", "DigiKey Client ID"),
                          ("digikey_client_secret", "DigiKey Client Secret")]:
            value = env_vars.get(key)
            if not value or value.startswith("your_"):
                print(f"    ⚠️  {name}: Not configured (OK — Quarry is primary)")
            else:
                masked_value = value[:8] + "..." if len(value) > 8 else value
                print(f"    ✅ {name}: {masked_value}")
    
    print("\n  Vector database configuration:")
    print(f"    - Chunk size: {env_vars.get('chunk_size', 'Not set')}")
    print(f"    - Chunk overlap: {env_vars.get('chunk_overlap', 'Not set')}")
    print(f"    - Embedding model: {env_vars.get('embedding_model', 'Not set')}")
    print(f"    - Embedding dimensions: {env_vars.get('embedding_dimensions', 'Not set')}")
    
    if all_valid:
        print("\n  ✅ All required configuration values are set!")
        print("\n  To validate API keys, run: mfcli doctor")
    else:
        print("\n  ⚠️  Some configuration values are missing.")
        print("  Run 'mfcli configure' to complete your configuration.")
    
    print("="*70 + "\n")


def set_log_level(level: str = None) -> None:
    """View or set the logging level in the .env file."""
    env_path = get_env_path()
    
    # If no level provided, display current level
    if level is None:
        if not env_path.exists():
            print("\n" + "="*70)
            print("  CURRENT LOG LEVEL")
            print("="*70)
            print("\n  ⚠️  Configuration file not found.")
            print(f"  Expected location: {env_path}")
            print("\n  Using default: INFO")
            print("\n  Run 'mfcli log-level <LEVEL>' to set a log level.")
            print("  Available levels: DEBUG, INFO, WARNING, ERROR, CRITICAL")
            print("="*70 + "\n")
            return
        
        # Read current log level
        env_vars = read_existing_env()
        current_level = env_vars.get('log_level', env_vars.get('LOG_LEVEL', 'INFO'))
        
        print("\n" + "="*70)
        print("  CURRENT LOG LEVEL")
        print("="*70)
        print(f"\n  Current level: {current_level}")
        print(f"  Configuration file: {env_path}")
        print("\n  To change the log level, run:")
        print("  mfcli log-level <LEVEL>")
        print("\n  Available levels: DEBUG, INFO, WARNING, ERROR, CRITICAL")
        print("="*70 + "\n")
        return
    
    # Ensure the env file exists
    if not env_path.exists():
        env_path.parent.mkdir(parents=True, exist_ok=True)
        env_path.touch()
    
    # Read the existing file content
    with open(env_path, 'r') as f:
        lines = f.readlines()
    
    # Check if log_level already exists
    updated = False
    new_lines = []
    
    for line in lines:
        stripped = line.strip()
        if stripped.startswith('log_level=') or stripped.startswith('LOG_LEVEL='):
            # Replace existing log_level
            new_lines.append(f"log_level={level}\n")
            updated = True
        else:
            new_lines.append(line)
    
    # If log_level wasn't found, add it
    if not updated:
        # Add it after configuration section or at the end
        new_lines.append(f"\n# Logging Configuration\n")
        new_lines.append(f"log_level={level}\n")
    
    # Write back to file
    with open(env_path, 'w') as f:
        f.writelines(new_lines)
    
    print("\n" + "="*70)
    print("  LOG LEVEL UPDATED")
    print("="*70)
    print(f"\n  ✅ Log level set to: {level}")
    print(f"  Configuration file: {env_path}")
    print("\n  This will take effect on the next mfcli command.")
    print("="*70 + "\n")
