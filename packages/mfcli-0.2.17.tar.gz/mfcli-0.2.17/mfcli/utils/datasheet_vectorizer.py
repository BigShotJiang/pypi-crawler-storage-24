import io
import json
import os
import re
import zipfile
from urllib.parse import urlparse, unquote

from playwright.async_api import async_playwright, Browser
from requests import RequestException
from sqlmodel import select

from mfcli.client.chroma_db import ChromaClient, VectorDBChunk
from mfcli.client.docling import DoclingChunker
from mfcli.client.vector_db import DocumentVectorizer
from mfcli.constants.file_types import PDFMimeTypes
from mfcli.digikey.digikey import DigiKey
from mfcli.models.bom import BOM
from mfcli.models.datasheet import Datasheet
from mfcli.pipeline.extractors.pdf import extract_text_from_pdf
from mfcli.utils.directory_manager import app_dirs
from mfcli.utils.http_requests import http_request
from mfcli.utils.config import get_config
from mfcli.utils.logger import get_logger
from mfcli.utils.orm import Session
from mfcli.utils.tools import get_mime_type_from_bytes

logger = get_logger(__name__)


class DatasheetVectorizer:
    def __init__(self, chroma_db: ChromaClient):
        self._vectorizer = DocumentVectorizer(chroma_db)
        self._docling = DoclingChunker()

    def _vectorize_text(self, text: str, file_name: str, purpose: str, additional_metadata: dict = None):
        """
        Shared method to vectorize text with metadata
        :param text: Extracted text content
        :param file_name: Name of the file
        :param purpose: Purpose of the vectorization (e.g., 'datasheet', 'bom', 'errata')
        :param additional_metadata: Optional additional metadata to include
        """
        metadata = {"file_name": file_name, "purpose": purpose}
        if additional_metadata:
            metadata.update(additional_metadata)
        self._vectorizer.vectorize(text, metadata)
        logger.debug(f"File vectorized: {file_name} (purpose: {purpose})")

    @staticmethod
    async def _fetch_with_playwright(browser: Browser, url: str):
        context = await browser.new_context()
        response = await context.request.get(url)
        body = await response.body()
        return body

    @staticmethod
    def _parse_ti_url(url: str) -> str:
        """
        Texas Instruments URLs may have goTo param which is the real URL of the PDF
        :param url: TI URL
        :return: URL from goTo param
        """
        url_query_params = urlparse(url).query
        if not url_query_params:
            return url
        params = url_query_params.split('&')
        for param in params:
            name = param.split('=')[0]
            value = param.split('=')[1]
            if not name == 'gotoUrl':
                continue
            return unquote(value)
        return url

    @staticmethod
    def _save_datasheet(name: str, content: bytes):
        file_path = app_dirs.data_sheets_dir / name
        with open(file_path, "wb") as f:
            f.write(content)

    async def _download(self, browser: Browser, url: str, purpose: str = "datasheet"):
        logger.debug(f"Fetching datasheet: {url}")
        try:
            ti_url_regex = r"^https?://www.ti.com/.+$"
            if re.match(ti_url_regex, url, re.I):
                logger.debug(f"URL is a TI URL: {url}")
                url = self._parse_ti_url(url)
                logger.debug(f"Parsed TI URL: {url}")
            url_path = urlparse(url).path
        except ValueError as e:
            logger.debug(f"Unable to parse datasheet URL: {url}")
            logger.debug(e)
            return
        file_name = os.path.basename(url_path)
        if not file_name.endswith(".pdf"):
            file_name = f"{file_name}.pdf"
        try:
            content = http_request(method='GET', url=url).content
            mime_type = get_mime_type_from_bytes(content, file_name)
            if mime_type not in PDFMimeTypes:
                logger.debug(f"Retrieved PDF is not PDF MIME type: {url}")
                logger.debug(f"Retrying with playwright: {url}")
                content = await self._fetch_with_playwright(browser, url)
        except RequestException as e:
            logger.debug(e)
            logger.debug(f"HTTP error fetching PDF: {url}")
            logger.debug(f"Retrying with playwright: {url}")
            content = await self._fetch_with_playwright(browser, url)
        except Exception as e:
            logger.debug(f"Unhandled error fetching datasheet URL: {url}")
            logger.debug(e)
            return
        mime_type = get_mime_type_from_bytes(content, file_name)
        if mime_type not in PDFMimeTypes:
            logger.debug(f"Could not fetch PDF even with playwright: {url}")
            return
        try:
            self._save_datasheet(file_name, content)
        except Exception as e:
            logger.debug(e)
            logger.debug(f"Error saving datasheet: {file_name}")

    async def download(self, urls: list[str], purpose: str = "datasheet"):
        if not urls:
            logger.debug(f"No datasheets to vectorize, exiting")
            return
        logger.debug(f"Vectorizing {len(urls)} documents (purpose: {purpose})")
        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=True)
            try:
                for url in urls:
                    try:
                        await self._download(browser, url, purpose)
                    except Exception as e:
                        logger.debug(e)
                        logger.debug(f"Error processing document: {url}")
            finally:
                await browser.close()

    def vectorize_local_file(self, file_path: str, purpose: str, additional_metadata: dict = None):
        """
        Vectorize a local file (e.g., generated by agents)
        :param file_path: Path to the local file
        :param purpose: Purpose of the vectorization (e.g., 'bom', 'errata', 'functional_blocks')
        :param additional_metadata: Optional additional metadata to include
        """
        try:
            logger.debug(f"Vectorizing local file: {file_path} (purpose: {purpose})")
            file_name = os.path.basename(file_path)

            # Check if file exists
            if not os.path.exists(file_path):
                logger.error(f"File does not exist: {file_path}")
                return

            # Extract text based on file type
            with open(file_path, 'rb') as f:
                content = f.read()

            mime_type = get_mime_type_from_bytes(content, file_name)

            if mime_type in PDFMimeTypes:
                text = extract_text_from_pdf(content)
            else:
                # For non-PDF files, decode as text
                text = content.decode(errors='ignore')

            logger.debug(f"Text extracted from local file: {file_path}")
            self._vectorize_text(text, file_name, purpose, additional_metadata)

        except Exception as e:
            logger.error(f"Error vectorizing local file: {file_path}")
            logger.exception(e)
            raise

    def vectorize_local_files(self, file_paths: list[str], purpose: str, additional_metadata: dict = None):
        """
        Vectorize multiple local files
        :param file_paths: List of paths to local files
        :param purpose: Purpose of the vectorization (e.g., 'bom', 'errata', 'functional_blocks')
        :param additional_metadata: Optional additional metadata to include
        """
        if not file_paths:
            logger.debug(f"No files to vectorize, exiting")
            return

        logger.debug(f"Vectorizing {len(file_paths)} local files (purpose: {purpose})")
        for file_path in file_paths:
            try:
                self.vectorize_local_file(file_path, purpose, additional_metadata)
            except Exception as e:
                logger.exception(e)
                logger.error(f"Error processing local file: {file_path}")
        logger.debug(f"Finished vectorizing {len(file_paths)} local files")

    def vectorize_text_content(self, text: str, file_name: str, purpose: str, additional_metadata: dict = None):
        """
        Vectorize text content directly (e.g., from agent output)
        :param text: Text content to vectorize
        :param file_name: Name to associate with this content
        :param purpose: Purpose of the vectorization (e.g., 'bom', 'errata', 'functional_blocks')
        :param additional_metadata: Optional additional metadata to include
        """
        try:
            logger.debug(f"Vectorizing text content: {file_name} (purpose: {purpose})")
            self._vectorize_text(text, file_name, purpose, additional_metadata)
        except Exception as e:
            logger.error(f"Error vectorizing text content: {file_name}")
            logger.exception(e)
            raise

    def vectorize_file_buf(
            self,
            file_bytes: bytes,
            file_name: str,
            purpose: str,
            additional_metadata: dict = None
    ) -> None:
        """
        Vectorize a file from a buffer. This vectorizer uses DoclingChunker.
        :param file_bytes: file bytes
        :param file_name: file name
        :param purpose: file purpose
        :param additional_metadata: dict of metadata
        :return: None
        """
        chunks = self._docling.chunk(file_name, file_bytes)
        metadata = {"file_name": file_name, "purpose": purpose}
        if additional_metadata:
            metadata.update(additional_metadata)
        self._vectorizer.vectorize_chunks(chunks, metadata)


def _get_quarry_client():
    """
    Try to create and validate a Datasheet Quarry client.
    Returns the client if configured and healthy, otherwise None.
    """
    try:
        from mfcli.client.datasheet_quarry import DatasheetQuarryClient
        quarry = DatasheetQuarryClient()
        if not quarry.is_configured:
            logger.debug("Datasheet Quarry API key not configured, using DigiKey directly")
            return None
        if not quarry.health_check():
            logger.debug("Datasheet Quarry service not available, falling back to DigiKey")
            return None
        logger.info("Using Datasheet Quarry cloud API for datasheet lookups")
        return quarry
    except Exception as e:
        logger.debug(f"Datasheet Quarry client init failed: {e}")
        return None


_PDF_MAGIC = b"%PDF"


def _download_quarry_pdf(quarry, datasheet_id: str, part_number: str) -> str | None:
    """Download a PDF from the Quarry via the authenticated client and save locally.

    Validates that the response is actually a PDF (starts with ``%PDF``) before
    writing it to disk so that corrupted / HTML-error files are never persisted.

    Returns a ``quarry://<id>/pdf`` sentinel URL on success, or ``None``.
    """
    try:
        pdf_bytes = quarry.download_pdf(datasheet_id)
        if not pdf_bytes or len(pdf_bytes) <= 100:
            logger.warning(f"Empty / too-small PDF response for {part_number} ({len(pdf_bytes or b'')} bytes)")
            return None

        # Reject HTML error pages saved with a .pdf extension
        if not pdf_bytes[:16].startswith(_PDF_MAGIC):
            snippet = pdf_bytes[:80].decode("utf-8", errors="replace")
            logger.warning(
                "Quarry returned non-PDF content for %s — skipping. First 80 bytes: %r",
                part_number, snippet,
            )
            return None

        pdf_filename = f"{part_number}.pdf"
        pdf_path = app_dirs.data_sheets_dir / pdf_filename
        with open(pdf_path, "wb") as f:
            f.write(pdf_bytes)
        logger.info(f"Saved datasheet: {pdf_path} ({len(pdf_bytes)} bytes)")
        return f"quarry://{datasheet_id}/pdf"
    except Exception as e:
        logger.warning(f"Failed to download PDF for {part_number}: {e}")
        return None


def _fetch_via_quarry(quarry, part_number: str) -> tuple[str | None, str | None]:
    """
    Fetch a datasheet URL via the Datasheet Quarry API.

    Returns a tuple of (datasheet_url, datasheet_id).
    datasheet_url is the URL if found, or None.
    datasheet_id is the quarry UUID if the datasheet was processed, or None.

    When the datasheet is already processed (status == "completed"), the PDF
    is downloaded directly via the authenticated Quarry client and saved to
    the local data_sheets folder.  A ``quarry://<id>/pdf`` sentinel URL is
    returned so the caller knows *not* to download it again via an
    unauthenticated HTTP request.
    """
    result = quarry.fetch_datasheet(part_number, retry_on_rate_limit=True)
    if not result.success:
        logger.debug(f"Datasheet Quarry: no result for {part_number}: {result.error}")
        return None, None

    did = result.datasheet_id

    # If already processed, download the PDF via the authenticated client
    if result.processing_status == "completed" and did:
        sentinel = _download_quarry_pdf(quarry, did, part_number)
        if sentinel:
            return sentinel, did

    # If the datasheet URL is directly available (not yet processed)
    if result.datasheet_url:
        return result.datasheet_url, did

    # If pending/processing, wait for completion then download
    if did and result.processing_status in ("pending", "processing"):
        try:
            logger.debug(f"Waiting for Datasheet Quarry to process {part_number}...")
            quarry.wait_for_processing(did, timeout=120, part_number=part_number)
            sentinel = _download_quarry_pdf(quarry, did, part_number)
            if sentinel:
                return sentinel, did
        except (TimeoutError, RuntimeError) as e:
            logger.warning(f"Datasheet Quarry processing issue for {part_number}: {e}")
            return None, None

    return result.datasheet_url, did


def _batch_fetch_via_quarry(quarry, part_numbers: list[str]) -> tuple[dict[str, str | None], dict[str, str]]:
    """
    Fetch datasheets for multiple part numbers via batch request.

    For completed datasheets, downloads the PDF directly from the Quarry API
    (with auth) and saves it to the data_sheets folder.

    Returns:
        A tuple of (results, completed_ids) where:
        - results: dict mapping part_number -> sentinel URL or None
        - completed_ids: dict mapping datasheet_id -> part_number for
          datasheets that completed processing (used for embedding import)
    """
    results = {}
    pending_ids = {}  # datasheet_id -> part_number for items that need processing
    completed_ids = {}  # datasheet_id -> part_number for items ready to download

    batch_results = quarry.batch_fetch_datasheets(
        part_numbers,
        delay_between_requests=0.5,
        retry_on_rate_limit=True,
    )

    for part_number, result in batch_results.items():
        if not result.success:
            logger.debug(f"Datasheet Quarry: no result for {part_number}: {result.error}")
            results[part_number] = None
            continue

        did = result.datasheet_id

        if result.processing_status == "completed" and did:
            completed_ids[did] = part_number
        elif did and result.processing_status in ("pending", "processing"):
            pending_ids[did] = part_number
        else:
            results[part_number] = result.datasheet_url

    # Wait for any pending datasheets to finish processing
    if pending_ids:
        logger.info(f"Waiting for {len(pending_ids)} datasheets to finish processing...")
        for did, part_number in pending_ids.items():
            try:
                quarry.wait_for_processing(did, timeout=120, poll_interval=3, part_number=part_number)
                completed_ids[did] = part_number
                logger.debug(f"Processing completed for {part_number}")
            except (TimeoutError, RuntimeError) as e:
                logger.warning(f"Processing issue for {part_number}: {e}")
                results[part_number] = None

    # Download PDFs for all completed datasheets directly via the authenticated client
    if completed_ids:
        logger.info(f"Downloading {len(completed_ids)} PDFs from Datasheet Quarry...")
        for did, part_number in completed_ids.items():
            try:
                pdf_bytes = quarry.download_pdf(did)
                if pdf_bytes and len(pdf_bytes) > 100:
                    pdf_filename = f"{part_number}.pdf"
                    pdf_path = app_dirs.data_sheets_dir / pdf_filename
                    with open(pdf_path, "wb") as f:
                        f.write(pdf_bytes)
                    logger.info(f"Saved datasheet: {pdf_path} ({len(pdf_bytes)} bytes)")
                    # Store a sentinel URL so mfcli records it in the local DB
                    results[part_number] = f"quarry://{did}/pdf"
                else:
                    logger.warning(f"Empty/invalid PDF for {part_number}")
                    results[part_number] = None
            except Exception as e:
                logger.warning(f"Failed to download PDF for {part_number}: {e}")
                results[part_number] = None

    return results, completed_ids


def _import_quarry_embeddings(quarry, chroma_db: ChromaClient, completed_ids: dict[str, str]):
    """
    Download embeddings from Datasheet Quarry and import into local ChromaDB.

    If the quarry's embedding model matches the local config, imports the
    pre-computed embeddings directly (fast, no extra API cost).  Otherwise,
    downloads the text chunks and re-embeds locally with the configured model
    to ensure vector-space consistency in the ChromaDB collection.

    Args:
        quarry: DatasheetQuarryClient instance
        chroma_db: ChromaClient instance for the project
        completed_ids: Dict mapping datasheet_id -> part_number for completed datasheets
    """
    if not completed_ids:
        return

    config = get_config()
    imported_count = 0

    logger.info(f"Importing embeddings for {len(completed_ids)} datasheets into ChromaDB...")

    for did, part_number in completed_ids.items():
        try:
            # Download the embeddings JSON (includes model info + vectors)
            embeddings_bytes = quarry.download_embeddings(did)
            embeddings_data = json.loads(embeddings_bytes)

            quarry_model = embeddings_data.get("embedding_model", "")
            quarry_dimensions = embeddings_data.get("embedding_dimensions", 0)
            chunks = embeddings_data.get("chunks", [])

            if not chunks:
                logger.debug(f"No embedding chunks found for {part_number}")
                continue

            # Check if the quarry embedding model matches the local model
            models_match = (
                quarry_model == config.embedding_model
                and quarry_dimensions == config.embedding_dimensions
            )

            if models_match:
                _import_precomputed_embeddings(chroma_db, did, part_number, chunks)
            else:
                logger.info(
                    f"Embedding model mismatch for {part_number}: "
                    f"quarry={quarry_model}/{quarry_dimensions}, "
                    f"local={config.embedding_model}/{config.embedding_dimensions}. "
                    f"Re-embedding chunks locally."
                )
                _reembed_chunks_locally(chroma_db, did, part_number, chunks)

            imported_count += 1

        except Exception as e:
            logger.warning(f"Failed to import embeddings for {part_number}: {e}")

    if imported_count:
        logger.info(f"Successfully imported embeddings for {imported_count}/{len(completed_ids)} datasheets")


def _import_precomputed_embeddings(
    chroma_db: ChromaClient,
    datasheet_id: str,
    part_number: str,
    chunks: list[dict],
):
    """
    Import pre-computed embeddings directly into ChromaDB.

    Used when the quarry's embedding model matches the local config,
    so no re-embedding is needed.
    """
    # Lowercase file_name to match pipeline convention (classifier.py lowercases all file names)
    normalized_file_name = f"{part_number}.pdf".lower()
    vector_chunks = []
    for chunk in chunks:
        vector_chunks.append(VectorDBChunk(
            id=f"{datasheet_id}_chunk_{chunk.get('chunk_index', 0)}",
            document=chunk["text"],
            metadata={
                "file_name": normalized_file_name,
                "purpose": "datasheet",
                "part_number": part_number,
                "page": chunk.get("page", 0),
                "chunk_index": chunk.get("chunk_index", 0),
            },
            embedding=chunk["embedding"],
        ))

    chroma_db.add(vector_chunks)
    logger.info(
        f"Imported {len(vector_chunks)} pre-computed embeddings for {part_number}"
    )


def _reembed_chunks_locally(
    chroma_db: ChromaClient,
    datasheet_id: str,
    part_number: str,
    chunks: list[dict],
):
    """
    Re-embed quarry text chunks locally using the configured embedding model.

    Used when the quarry's embedding model differs from the local config.
    The text content from the quarry is reused (saving PDF extraction work),
    but embeddings are regenerated with the local model for consistency.
    """
    vectorizer = DocumentVectorizer(chroma_db)
    chunk_texts = [chunk["text"] for chunk in chunks]
    # Lowercase file_name to match pipeline convention (classifier.py lowercases all file names)
    metadata = {
        "file_name": f"{part_number}.pdf".lower(),
        "purpose": "datasheet",
        "part_number": part_number,
    }
    vectorizer.vectorize_chunks(chunk_texts, metadata)
    logger.info(
        f"Re-embedded {len(chunk_texts)} chunks locally for {part_number}"
    )


def import_quarry_bundle(quarry, chroma_db: ChromaClient, datasheet_id: str, part_number: str):
    """
    Download and import a Datasheet Quarry bundle directly into ChromaDB.

    The bundle contains pre-computed PDF, text chunks, and embeddings,
    so mfcli can skip expensive local processing.

    Supports both the new descriptive filename format (``{part}_{mfr}_{date}.pdf``
    introduced in 2026-02) and the legacy ``datasheet.pdf`` / ``chunks.json`` /
    ``embeddings.json`` naming for bundles generated before that change.  The
    authoritative filenames are stored in ``metadata.json`` under the
    ``filenames`` key; when absent, the legacy names are used as a fallback.
    """
    try:
        bundle_bytes = quarry.download_bundle(datasheet_id)
    except Exception as e:
        logger.warning(f"Failed to download bundle for {part_number}: {e}")
        return

    try:
        with zipfile.ZipFile(io.BytesIO(bundle_bytes)) as zf:
            available_names = set(zf.namelist())

            # Read metadata (always named metadata.json)
            metadata = json.loads(zf.read("metadata.json"))
            resolved_part = metadata.get("part_number", part_number)

            # Determine the actual filenames inside the ZIP.
            # New bundles store descriptive names in metadata["filenames"];
            # legacy bundles use the fixed names below.
            filenames = metadata.get("filenames", {})
            pdf_name = filenames.get("pdf") or "datasheet.pdf"
            embeddings_name = filenames.get("embeddings") or "embeddings.json"

            # Save PDF locally using the component part number as the filename
            # so it's human-readable on disk regardless of what it's called inside
            # the ZIP.
            if pdf_name in available_names:
                try:
                    pdf_content = zf.read(pdf_name)
                    pdf_filename = f"{resolved_part}.pdf"
                    pdf_path = app_dirs.data_sheets_dir / pdf_filename
                    with open(pdf_path, "wb") as f:
                        f.write(pdf_content)
                    logger.info(f"Saved datasheet PDF: {pdf_path}")
                except Exception as pdf_err:
                    logger.debug(f"Could not save PDF from bundle for {part_number}: {pdf_err}")
            else:
                logger.debug(f"No PDF in bundle for {part_number} (looked for '{pdf_name}')")

            # Read and import pre-computed embeddings
            if embeddings_name in available_names:
                try:
                    embeddings_data = json.loads(zf.read(embeddings_name))
                    chunks = embeddings_data.get("chunks", [])

                    if not chunks:
                        logger.debug(f"No embeddings in bundle for {part_number}")
                        return

                    # Check model compatibility before importing
                    config = get_config()
                    quarry_model = embeddings_data.get("embedding_model", "")
                    quarry_dimensions = embeddings_data.get("embedding_dimensions", 0)

                    if (quarry_model == config.embedding_model
                            and quarry_dimensions == config.embedding_dimensions):
                        _import_precomputed_embeddings(
                            chroma_db, datasheet_id, part_number, chunks
                        )
                    else:
                        logger.info(
                            f"Bundle embedding model mismatch for {part_number}, "
                            f"re-embedding locally"
                        )
                        _reembed_chunks_locally(
                            chroma_db, datasheet_id, part_number, chunks
                        )
                except Exception as emb_err:
                    logger.debug(f"Could not import embeddings from bundle for {part_number}: {emb_err}")
            else:
                logger.debug(f"No embeddings in bundle for {part_number} (looked for '{embeddings_name}')")

    except zipfile.BadZipFile:
        logger.warning(f"Invalid bundle ZIP for {part_number}")
    except Exception as e:
        logger.error(f"Error importing bundle for {part_number}: {e}")


async def get_datasheets_for_bom_entries(db: Session, chroma_db: ChromaClient, entries: list[BOM]):
    logger.info(f"Fetching datasheets for {len(entries)} BOM entries")
    part_numbers = {entry.value for entry in entries}
    logger.debug("Fetching existing datasheets for part numbers")

    # Fetch existing datasheets from local DB
    stmt = select(Datasheet).where(Datasheet.part_number.in_(part_numbers))
    datasheets: list[Datasheet] = db.execute(stmt).scalars().all()
    datasheet_map = {d.part_number: d.datasheet for d in datasheets}

    logger.debug(f"Datasheet map: {datasheet_map}")

    # Get Datasheet Quarry client - REQUIRED
    quarry = _get_quarry_client()
    
    if quarry is None:
        logger.error("Datasheet Quarry is not configured! Cannot fetch datasheets.")
        logger.error("Please configure your Datasheet Quarry API key.")
        logger.error("Run 'mfcli quarry-setup' to configure Datasheet Quarry.")
        
        # Prompt user to set up Datasheet Quarry
        try:
            import sys
            print("\n" + "="*70)
            print("  ⚠️  DATASHEET QUARRY NOT CONFIGURED")
            print("="*70)
            print("\n  Datasheet Quarry is required for downloading component datasheets.")
            print("  It provides cloud-based datasheet lookup with better search,")
            print("  pre-processed bundles, and caching.")
            print("\n  Would you like to set up Datasheet Quarry now?")
            print("="*70)
            
            response = input("\n  Set up Datasheet Quarry? (Y/n): ").strip().lower()
            
            if response in ['', 'y', 'yes']:
                print("\n  Starting Datasheet Quarry setup...\n")
                from mfcli.utils.configurator import run_quarry_setup
                run_quarry_setup()
                
                # Try to get the client again after setup
                quarry = _get_quarry_client()
                if quarry is None:
                    print("\n  ⚠️  Datasheet Quarry setup was not completed.")
                    print("  You can run 'mfcli quarry-setup' later to configure it.")
                    print("\n  Continuing without datasheet downloads...\n")
                    return
                else:
                    print("\n  ✅ Datasheet Quarry configured successfully!")
                    print("  Continuing with datasheet downloads...\n")
            else:
                print("\n  Skipping Datasheet Quarry setup.")
                print("  You can run 'mfcli quarry-setup' later to configure it.")
                print("\n  Continuing without datasheet downloads...\n")
                return
        except KeyboardInterrupt:
            print("\n\n  Setup cancelled by user.")
            print("  Run 'mfcli quarry-setup' to configure Datasheet Quarry later.\n")
            return
        except Exception as e:
            logger.error(f"Error during setup prompt: {e}")
            print("\n  ⚠️  Unable to start setup. Please run 'mfcli quarry-setup' manually.\n")
            return

    new_datasheets: list[Datasheet] = []
    datasheet_urls: list[str] = []
    # Track completed quarry datasheet IDs for embedding import
    all_completed_ids: dict[str, str] = {}  # datasheet_id -> part_number

    # Filter entries that need datasheet lookup
    entries_to_fetch = []
    for entry in entries:
        # Skip resistors, capacitors, inductors, connectors, test points, diodes
        ref = entry.reference
        if ref.startswith(('R', 'C', 'L', 'J', 'T', 'D')):
            logger.debug(f"Skipping BOM entry {entry.value} with reference: {ref}")
            continue
        
        existing_datasheet = datasheet_map.get(entry.value)
        if existing_datasheet:
            entry.datasheet = existing_datasheet
            continue
        
        entries_to_fetch.append(entry)

    # Use batch fetch if we have multiple entries, otherwise individual requests
    if entries_to_fetch:
        part_numbers_to_fetch = [entry.value for entry in entries_to_fetch]
        logger.info(f"Entries to fetch: {len(part_numbers_to_fetch)} (after filtering passives and existing)")
        logger.debug(f"Part numbers to fetch: {part_numbers_to_fetch[:5]}...")  # Log first 5
        
        if len(part_numbers_to_fetch) > 1:
            # Use batch fetch for efficiency
            logger.info(f"✓ Using BATCH FETCH for {len(part_numbers_to_fetch)} part numbers via Datasheet Quarry")
            try:
                batch_results, completed_ids = _batch_fetch_via_quarry(quarry, part_numbers_to_fetch)
                all_completed_ids.update(completed_ids)
                
                for entry in entries_to_fetch:
                    datasheet_url = batch_results.get(entry.value)
                    
                    if not datasheet_url:
                        logger.warning(f"Datasheet not found for {entry.value}")
                    
                    entry.datasheet = datasheet_url
                    
                    if datasheet_url:
                        logger.debug(f"Adding new datasheet for {entry.value}: {datasheet_url}")
                        new_datasheets.append(Datasheet(part_number=entry.value, datasheet=datasheet_url))
                        datasheet_urls.append(datasheet_url)
                        
            except Exception as e:
                logger.error(f"Batch fetch failed: {e}, falling back to individual Quarry requests")
                # Fall back to individual Quarry requests on batch failure
                for entry in entries_to_fetch:
                    try:
                        datasheet_url, did = _fetch_via_quarry(quarry, entry.value)
                        entry.datasheet = datasheet_url
                        
                        if datasheet_url:
                            logger.debug(f"Adding new datasheet for {entry.value}: {datasheet_url}")
                            new_datasheets.append(Datasheet(part_number=entry.value, datasheet=datasheet_url))
                            datasheet_urls.append(datasheet_url)
                            if did:
                                all_completed_ids[did] = entry.value
                        else:
                            logger.warning(f"Datasheet not found for {entry.value}")
                    except Exception as e:
                        logger.error(f"Error fetching datasheet for {entry.value}: {e}")
        else:
            # Single entry - use individual request
            logger.info(f"Using individual fetch for single part number via Datasheet Quarry")
            for entry in entries_to_fetch:
                try:
                    logger.debug(f"Processing BOM entry: {entry.value}")
                    datasheet_url, did = _fetch_via_quarry(quarry, entry.value)
                    entry.datasheet = datasheet_url

                    if datasheet_url:
                        logger.debug(f"Adding new datasheet for {entry.value}: {datasheet_url}")
                        new_datasheets.append(Datasheet(part_number=entry.value, datasheet=datasheet_url))
                        datasheet_urls.append(datasheet_url)
                        if did:
                            all_completed_ids[did] = entry.value
                    else:
                        logger.warning(f"Datasheet not found for {entry.value}")

                except Exception as e:
                    logger.error(f"Error adding datasheet for BOM entry: {entry.value}")
                    logger.exception(e)

    if new_datasheets:
        db.add_all(new_datasheets)
        logger.debug(f"Adding new data sheets: {new_datasheets}")

    if datasheet_urls:
        # Filter out quarry:// URLs — those PDFs were already downloaded
        # directly by _batch_fetch_via_quarry and saved to data_sheets/
        urls_to_download = [u for u in datasheet_urls if not u.startswith("quarry://")]
        quarry_count = len(datasheet_urls) - len(urls_to_download)
        if quarry_count:
            logger.info(f"{quarry_count} PDFs already downloaded from Datasheet Quarry")
        if urls_to_download:
            logger.debug(f"About to download {len(urls_to_download)} datasheets via URL: {urls_to_download}")
            try:
                await DatasheetVectorizer(chroma_db).download(urls_to_download)
            except Exception as e:
                logger.error("Error vectorizing datasheets for BOM")
                raise e

    # Import embeddings from Datasheet Quarry into local ChromaDB
    if all_completed_ids and quarry:
        try:
            _import_quarry_embeddings(quarry, chroma_db, all_completed_ids)
        except Exception as e:
            logger.error(f"Error importing quarry embeddings: {e}")
            logger.exception(e)

    logger.debug("Finished adding datasheets")
