# Schematic parsers and detectors
