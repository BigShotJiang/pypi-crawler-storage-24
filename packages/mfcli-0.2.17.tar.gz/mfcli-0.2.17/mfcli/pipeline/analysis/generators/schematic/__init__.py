# Schematic cheat sheet generator
