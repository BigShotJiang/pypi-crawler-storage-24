from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass
from io import BytesIO
from pathlib import Path
from typing import Optional

import fitz

from mfcli.pipeline.indexing.models import Anchor, CatalogEntry, Section, SectionRef
from mfcli.utils.logger import get_logger

logger = get_logger(__name__)


@dataclass(frozen=True)
class IndexPaths:
    """Resolved paths for a single document index output.

    Attributes:
        sections_path: JSON file path for section metadata.
    """
    sections_path: Path


class DocumentIndexer:
    """Build a deterministic, page-anchored index for PDF documents."""
    def __init__(self, base_dir: Path, root_dir: Optional[Path] = None) -> None:
        """Initialize the indexer with a base output directory.

        Args:
            base_dir: Root directory to store index artifacts.
            root_dir: Optional repo root used to make paths relative.
        """
        self._base_dir = Path(base_dir)
        self._root_dir = root_dir
        self._catalog_path = self._base_dir / "index.json"
        self._sections_dir = self._base_dir / "sections"
        self._ensure_dirs()

    def index_pdf(
        self,
        file_path: str,
        file_bytes: bytes,
        title: Optional[str] = None,
    ) -> CatalogEntry:
        """Index a PDF and update the catalog entry.

        Args:
            file_path: Path to the PDF file (used for catalog path).
            file_bytes: PDF contents as bytes.
            title: Optional title override.

        Returns:
            CatalogEntry describing the indexed document.
        """
        file_name = Path(file_path).name
        doc_title = title or Path(file_name).stem
        doc_id = self._build_doc_id(doc_title, file_bytes)
        paths = self._index_paths(doc_id)

        logger.debug(f"Indexing PDF: {file_path} -> {doc_id}")

        with fitz.open(stream=BytesIO(file_bytes), filetype="pdf") as doc:
            page_count = doc.page_count
            sections = self._extract_sections(doc, page_count)
            summary = self._summarize_document(doc, sections)
            key_sections = self._key_sections(sections)
            self._write_sections(paths.sections_path, sections)

        entry = CatalogEntry(
            doc_id=doc_id,
            title=doc_title,
            file=self._relative_path(file_path),
            summary=summary,
            key_sections=key_sections,
            pages=page_count,
        )
        self._update_catalog(entry)
        return entry

    def _ensure_dirs(self) -> None:
        """Ensure base index directories exist."""
        self._base_dir.mkdir(parents=True, exist_ok=True)
        self._sections_dir.mkdir(parents=True, exist_ok=True)

    def _index_paths(self, doc_id: str) -> IndexPaths:
        """Return the output paths for a document id.

        Args:
            doc_id: Document identifier.

        Returns:
            IndexPaths with resolved output locations.
        """
        sections_path = self._sections_dir / f"{doc_id}.json"
        return IndexPaths(sections_path=sections_path)

    @staticmethod
    def _sha256(data: bytes) -> str:
        """Return sha256 hex digest for a byte blob.

        Args:
            data: Raw bytes to hash.

        Returns:
            Hex-encoded sha256 digest.
        """
        return hashlib.sha256(data).hexdigest()

    @staticmethod
    def _slugify(value: str) -> str:
        """Convert text into a URL-safe slug.

        Args:
            value: Input string to slugify.

        Returns:
            Slugified string.
        """
        slug = re.sub(r"[^A-Za-z0-9]+", "-", value).strip("-").lower()
        return slug or "document"

    def _build_doc_id(self, title: str, file_bytes: bytes) -> str:
        """Create a stable document id from title and file bytes.

        Args:
            title: Document title.
            file_bytes: PDF contents as bytes.

        Returns:
            Stable document id.
        """
        checksum = self._sha256(file_bytes)
        return f"{self._slugify(title)}_{checksum[:8]}"

    def _relative_path(self, file_path: str) -> str:
        """Return a path relative to root_dir when possible.

        Args:
            file_path: Absolute or relative file path.

        Returns:
            Path relative to root_dir if possible; otherwise original path.
        """
        path = Path(file_path)
        if self._root_dir:
            try:
                return str(path.resolve().relative_to(self._root_dir.resolve()))
            except ValueError:
                return str(path)
        return str(path)

    def _extract_sections(self, doc: fitz.Document, page_count: int) -> list[Section]:
        """Extract sections from the PDF table of contents.

        Args:
            doc: Opened PDF document.
            page_count: Total number of pages.

        Returns:
            List of Section entries derived from the outline.
        """
        toc = doc.get_toc(simple=True)
        if not toc:
            return []
        sections: list[Section] = []
        for idx, (level, title, page) in enumerate(toc):
            start_page = max(1, min(page, page_count))
            if idx + 1 < len(toc):
                next_page = toc[idx + 1][2]
                end_page = max(start_page, min(next_page - 1, page_count))
            else:
                end_page = page_count
            section_id = idx + 1
            sections.append(
                Section(
                    id=section_id,
                    title=title,
                    level=level,
                    page_start=start_page,
                    page_end=end_page,
                    anchor=Anchor(page=start_page, bbox=None),
                )
            )
        return sections

    @staticmethod
    def _key_sections(sections: list[Section], limit: int = 30) -> list[SectionRef]:
        """Return a limited list of section references.

        Args:
            sections: Extracted sections.
            limit: Maximum number of titles.

        Returns:
            Ordered list of section summaries.
        """
        summaries = [
            SectionRef(id=section.id, title=section.title.strip())
            for section in sections
            if section.title.strip()
        ]
        if not summaries:
            return []
        return summaries[:limit]


    def _summarize_document(self, doc: fitz.Document, sections: list[Section]) -> Optional[str]:
        """Create a summary using preferred sections, falling back to page one.

        Args:
            doc: Opened PDF document.
            sections: Extracted sections.

        Returns:
            Summary string if found, otherwise None.
        """
        if doc.page_count == 0:
            return None
        summary = self._summarize_from_sections(doc, sections)
        if summary:
            return summary
        return self._summarize_first_page(doc)

    def _summarize_from_sections(self, doc: fitz.Document, sections: list[Section]) -> Optional[str]:
        """Try to summarize from a preferred section page.

        Args:
            doc: Opened PDF document.
            sections: Extracted sections.

        Returns:
            Summary string if found, otherwise None.
        """
        if not sections:
            return None
        preferred = [
            "description",
            "device overview",
            "overview",
            "general description",
            "introduction",
            "features",
        ]
        for key in preferred:
            for section in sections:
                if key in section.title.lower():
                    page_index = max(0, section.page_start - 1)
                    text = doc.load_page(page_index).get_text("text") or ""
                    summary = self._summary_from_text(text, section.title)
                    if summary:
                        return summary
        return None

    @staticmethod
    def _summary_from_text(text: str, heading: Optional[str] = None) -> Optional[str]:
        """Extract a clean summary from raw page text.

        Args:
            text: Raw page text.
            heading: Optional section heading to anchor after.

        Returns:
            Summary string if found, otherwise None.
        """
        lines = [line.strip() for line in text.splitlines() if line.strip()]
        if not lines:
            return None
        start_index = 0
        if heading:
            heading_norm = DocumentIndexer._normalize_heading(heading)
            for i, line in enumerate(lines):
                if heading_norm and heading_norm in DocumentIndexer._normalize_heading(line):
                    start_index = i + 1
                    break
        candidate_lines = []
        for line in lines[start_index:]:
            if DocumentIndexer._is_boilerplate_line(line):
                continue
            if DocumentIndexer._is_heading_line(line):
                continue
            if len(line.split()) < 4:
                continue
            candidate_lines.append(line)
            if len(candidate_lines) >= 3:
                break
        if not candidate_lines:
            return None
        summary = " ".join(candidate_lines)
        summary = re.sub(r"\s+", " ", summary).strip()
        if len(summary.split()) < 8:
            return None
        return summary[:500]

    @staticmethod
    def _summarize_first_page(doc: fitz.Document) -> Optional[str]:
        """Summarize the first page text.

        Args:
            doc: Opened PDF document.

        Returns:
            Summary string if found, otherwise None.
        """
        text = doc.load_page(0).get_text("text") or ""
        return DocumentIndexer._summary_from_text(text)

    @staticmethod
    def _normalize_heading(text: str) -> str:
        """Normalize headings for approximate matching.

        Args:
            text: Raw heading text.

        Returns:
            Normalized heading text.
        """
        value = text.lower()
        value = re.sub(r"[^a-z0-9\s]+", " ", value)
        value = re.sub(r"\s+", " ", value).strip()
        return value

    @staticmethod
    def _is_heading_line(line: str) -> bool:
        """Heuristic check for heading-like lines.

        Args:
            line: Line of text.

        Returns:
            True if the line looks like a heading.
        """
        tokens = line.split()
        if not tokens:
            return True
        if line.isupper() and len(tokens) <= 6:
            return True
        if len(tokens) <= 3 and line.endswith(":"):
            return True
        return False

    @staticmethod
    def _is_boilerplate_line(line: str) -> bool:
        """Heuristic check for boilerplate lines.

        Args:
            line: Line of text.

        Returns:
            True if the line is boilerplate.
        """
        lower = line.lower()
        boilerplate = [
            "product folder",
            "order now",
            "technical",
            "www.",
            "http://",
            "https://",
            "ti.com",
            "revision history",
            "page ",
        ]
        if any(token in lower for token in boilerplate):
            return True
        return False

    def _write_sections(self, sections_path: Path, sections: list[Section]) -> None:
        """Persist section metadata to JSON.

        Args:
            sections_path: Destination JSON path.
            sections: Extracted section metadata.
        """
        payload = [section.model_dump() for section in sections]
        sections_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    def _load_catalog(self) -> list[CatalogEntry]:
        """Load the catalog file, if it exists.

        Returns:
            List of CatalogEntry items.
        """
        if not self._catalog_path.exists():
            return []
        data = json.loads(self._catalog_path.read_text(encoding="utf-8"))
        return [CatalogEntry(**entry) for entry in data]

    def _save_catalog(self, entries: list[CatalogEntry]) -> None:
        """Persist the catalog list.

        Args:
            entries: Catalog entries to write.
        """
        payload = [entry.model_dump() for entry in entries]
        self._catalog_path.write_text(
            json.dumps(payload, separators=(",", ":")),
            encoding="utf-8"
        )

    def _update_catalog(self, entry: CatalogEntry) -> None:
        """Replace or append a catalog entry, then save.

        Args:
            entry: Catalog entry to upsert.
        """
        entries = self._load_catalog()
        filtered = [
            existing
            for existing in entries
            if existing.doc_id != entry.doc_id and existing.file != entry.file
        ]
        filtered.append(entry)
        self._save_catalog(filtered)
