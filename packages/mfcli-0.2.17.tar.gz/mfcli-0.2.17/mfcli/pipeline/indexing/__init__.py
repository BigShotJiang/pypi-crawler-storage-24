from mfcli.pipeline.indexing.indexer import DocumentIndexer

__all__ = ["DocumentIndexer"]
