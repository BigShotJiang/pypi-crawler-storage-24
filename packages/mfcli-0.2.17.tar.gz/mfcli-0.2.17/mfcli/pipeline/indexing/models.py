from __future__ import annotations

from typing import Optional

from pydantic import BaseModel, Field


class Anchor(BaseModel):
    """Page anchor for an extracted item.

    Attributes:
        page: 1-based page number.
        bbox: Optional [x0, y0, x1, y1] bounding box in PDF points.
    """
    page: int
    bbox: Optional[list[float]] = None


class SectionRef(BaseModel):
    """Lightweight section reference for catalogs.

    Attributes:
        id: Stable section identifier (1-based integer).
        title: Section title text.
    """
    id: int
    title: str


class Section(SectionRef):
    """Full document section derived from the PDF outline.

    Attributes:
        id: Stable section identifier (1-based integer).
        title: Section title text.
        level: Outline level (1 is top-level).
        page_start: 1-based starting page for the section.
        page_end: 1-based ending page for the section.
        anchor: Anchor pointing to the section start.
    """
    page_start: int
    page_end: int
    anchor: Anchor


class CatalogEntry(BaseModel):
    """Catalog entry describing a single indexed document.

    Attributes:
        doc_id: Stable document id derived from title and file hash.
        title: Human-friendly title (usually filename stem).
        file: Relative or absolute path to the source file.
        pages: Total page count.
        summary: Optional heuristic summary text.
        key_sections: Ordered list of section references.
    """
    doc_id: str
    title: str
    file: str
    pages: int
    summary: Optional[str] = None
    key_sections: list[SectionRef] = Field(default_factory=list)
