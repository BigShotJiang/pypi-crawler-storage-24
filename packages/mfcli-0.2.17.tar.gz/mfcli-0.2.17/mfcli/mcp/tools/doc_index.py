import hashlib
import json
import os
import re
from pathlib import Path
from typing import Annotated, Optional

from pydantic import BaseModel, Field

from mfcli.pipeline.indexing.models import Section, CatalogEntry

from mfcli.mcp.mcp_instance import mcp
from mfcli.utils.directory_manager import app_dirs, init_directory_structure


_TOKEN_PATTERN = re.compile(r"^[a-z0-9][a-z0-9_\-]*$", re.IGNORECASE)
DocId = Annotated[str, "Document id from index.json (required)"]
SectionId = Annotated[int, "Section id from sections JSON (1-based integer)"]


def _ensure_doc_index_dir() -> Path:
    """Ensure the doc_index directory is initialized.

    Returns:
        Path to the doc_index directory.
    """
    if app_dirs.doc_index_dir is None:
        init_directory_structure(os.getcwd())
    return app_dirs.doc_index_dir


def _validate_token(name: str, value: str) -> None:
    """Validate a simple token used in file paths.

    Args:
        name: Token name for error reporting.
        value: Token value to validate.
    """
    if not _TOKEN_PATTERN.match(value):
        raise ValueError(f"Invalid {name}: {value}")


def _validate_section_id(section_id: int) -> None:
    """Validate a section id integer.

    Args:
        section_id: Section id value.
    """
    if section_id <= 0:
        raise ValueError("section_id must be >= 1")


def _read_json(path: Path) -> list[dict]:
    """Read a JSON list from disk as dictionaries.

    Args:
        path: JSON file path.

    Returns:
        Parsed list of dict entries.
    """
    return json.loads(path.read_text(encoding="utf-8"))


def _load_catalog_entry(doc_id: str) -> Optional[dict]:
    """Load a catalog entry by doc_id.

    Args:
        doc_id: Document id to locate.

    Returns:
        Catalog entry dict if found, otherwise None.
    """
    doc_index_dir = _ensure_doc_index_dir()
    catalog_path = doc_index_dir / "index.json"
    if not catalog_path.exists():
        return None
    entries = _read_json(catalog_path)
    for entry in entries:
        model = CatalogEntry.model_validate(entry)
        if model.doc_id == doc_id:
            return model.model_dump()
    return None


def _resolve_doc_path(doc_id: str) -> Optional[Path]:
    """Resolve the source PDF path for a doc_id.

    Args:
        doc_id: Document id to locate.

    Returns:
        Absolute path to the PDF if found, otherwise None.
    """
    entry = _load_catalog_entry(doc_id)
    if not entry:
        return None
    file_path = Path(entry.get("file", ""))
    if file_path.is_absolute():
        return file_path if file_path.exists() else None

    doc_index_dir = _ensure_doc_index_dir()
    derived_root = doc_index_dir.parent.parent if doc_index_dir.name == "doc_index" else doc_index_dir.parent
    candidates = [
        (app_dirs.root_dir / file_path) if app_dirs.root_dir else None,
        derived_root / file_path,
        Path.cwd() / file_path,
    ]
    for candidate in candidates:
        if candidate and candidate.exists():
            return candidate
    return None


def _build_slice_dir(doc_id: str, section_ids: list[int]) -> Path:
    """Create a deterministic output directory for sliced page images.

    Args:
        doc_id: Document id from the catalog.
        section_ids: Section ids included in the slice.

    Returns:
        Path to a directory where rendered page images should be saved.
    """
    _validate_token("doc_id", doc_id)
    doc_index_dir = _ensure_doc_index_dir()
    ordered_ids = sorted(section_ids)
    key = f"{doc_id}:{','.join(str(section_id) for section_id in ordered_ids)}"
    digest = hashlib.sha1(key.encode("utf-8")).hexdigest()[:12]
    slice_dir = doc_index_dir / "slices" / doc_id / digest
    slice_dir.mkdir(parents=True, exist_ok=True)
    return slice_dir


class MCPError(BaseModel):
    """Structured error payload for MCP tools."""

    message: str


class DocumentCatalogResponse(BaseModel):
    """Response payload for list_indexed_documents."""

    documents: list[CatalogEntry] = Field(default_factory=list)
    error: Optional[MCPError] = None


class DocumentSectionRangeResponse(BaseModel):
    """Internal payload for section range resolution."""

    doc_id: str
    section_id: int
    title: str = ""
    page_start: int = 0
    page_end: int = 0
    error: Optional[MCPError] = None


class PdfPageImage(BaseModel):
    """Rendered PDF page image.

    Attributes:
        page: 1-based index in the stitched output order.
        image_path: Absolute path to the rendered image file.
        format: Image format (for now always "png").
    """

    page: int = Field(..., description="1-based index in stitched output order.")
    image_path: str = Field(..., description="Absolute path to the image file.")
    format: str = Field(..., description="Image format (e.g., png).")


class DocumentSliceResponse(BaseModel):
    """Response payload for slice_document_pdf.

    Attributes:
        doc_id: Document id from the catalog.
        section_ids: Section ids included in the slice.
        pages: Rendered page images in output order.
        error: Error details when slicing fails.
    """

    doc_id: str
    section_ids: list[int] = Field(default_factory=list)
    pages: list[PdfPageImage] = Field(default_factory=list)
    error: Optional[MCPError] = None


@mcp.tool()
def list_indexed_documents(
    task_progress: Annotated[Optional[str], "Task progress checklist (optional, ignored by tool)"] = None
) -> DocumentCatalogResponse:
    """List documents from the deterministic PDF index.

    Use this tool FIRST to choose which document to slice and read.
    It returns the catalog entries with key_sections (id/title).

    When to use:
        - The user asks which document contains specific info.
        - You need a doc_id and section ids before calling slice_document_pdf.

    Returns:
        DocumentCatalogResponse including catalog entries with key_sections
        and an optional error field.
    """
    doc_index_dir = _ensure_doc_index_dir()
    catalog_path = doc_index_dir / "index.json"
    if not catalog_path.exists():
        return DocumentCatalogResponse(
            documents=[],
            error=MCPError(message="index.json not found; run mfcli with --index first."),
        )
    documents = [CatalogEntry.model_validate(item) for item in _read_json(catalog_path)]
    return DocumentCatalogResponse(
        documents=documents,
    )


def _get_document_sections(doc_id: DocId) -> list[Section]:
    """Internal helper to load sections for a document."""
    _validate_token("doc_id", doc_id)
    doc_index_dir = _ensure_doc_index_dir()
    sections_path = doc_index_dir / "sections" / f"{doc_id}.json"
    if not sections_path.exists():
        return []
    return [Section.model_validate(item) for item in _read_json(sections_path)]


def _get_document_section_range(
    doc_id: DocId,
    section_id: SectionId,
) -> DocumentSectionRangeResponse:
    """Resolve a section id to its page range.

    Args:
        doc_id: Document id from the catalog.
        section_id: Section id from sections JSON.

    Returns:
        DocumentSectionRangeResponse with title and page range, or error.
    """
    _validate_token("doc_id", doc_id)
    _validate_section_id(section_id)
    doc_index_dir = _ensure_doc_index_dir()
    sections_path = doc_index_dir / "sections" / f"{doc_id}.json"
    if not sections_path.exists():
        return DocumentSectionRangeResponse(
            doc_id=doc_id,
            section_id=section_id,
            title="",
            page_start=0,
            page_end=0,
            error=MCPError(message="sections file not found for doc_id."),
        )
    sections = _get_document_sections(doc_id)
    for section in sections:
        if section.id == section_id:
            return DocumentSectionRangeResponse(
                doc_id=doc_id,
                section_id=section_id,
                title=section.title,
                page_start=section.page_start,
                page_end=section.page_end,
            )
    return DocumentSectionRangeResponse(
        doc_id=doc_id,
        section_id=section_id,
        title="",
        page_start=0,
        page_end=0,
        error=MCPError(message="section_id not found in sections list."),
    )


@mcp.tool()
def slice_document_pdf(
    doc_id: DocId,
    section_ids: Annotated[list[SectionId], "List of section ids to include (required)"],
    task_progress: Annotated[Optional[str], "Task progress checklist (optional, ignored by tool)"] = None
) -> DocumentSliceResponse:
    """Slice a PDF by section ids and return rendered page images.

    Use this tool to render only the pages for the selected sections.
    The response includes image file paths so tables/diagrams remain
    visible to vision-capable models or UIs.

    Workflow:
        1. First, use list_indexed_documents() to see available docs and sections
        2. Then, use slice_document_pdf(doc_id, section_ids) to get pages
        3. Use Read tool on returned image paths to view content with tables/diagrams

    When to use:
        - You want to view only relevant sections from a datasheet
        - You need to see tables, diagrams, schematics, or formatted content
        - You already have the section ids from list_indexed_documents

    When NOT to use:
        - If you don't know which sections are relevant → use list_indexed_documents first

    Args:
        doc_id: Document id from the catalog (e.g., "msp430g2112-pdf_6c08b168")
        section_ids: List of section ids to include (e.g., [7, 9, 12])

    Returns:
        DocumentSliceResponse containing:
        - doc_id: Document id
        - section_ids: Section ids included
        - pages: List of dicts with:
            - page: Page number (int)
            - image_path: Full path to PNG file (str)
            - format: Image format, typically "png" (str)
        - error: Error message if any, null on success

    Example:
        # Step 1: Get document catalog
        docs = list_indexed_documents()
        # Returns: {"documents": [{"doc_id": "msp430g2112-pdf_6c08b168", 
        #                          "key_sections": [{"id": 7, "title": "CPU"}, ...]}]}
        
        # Step 2: Slice sections 7, 9, 12 from MSP430 datasheet
        result = slice_document_pdf(
            doc_id="msp430g2112-pdf_6c08b168",
            section_ids=[7, 9, 12]
        )
        # Returns: {"pages": [{"page": 1, "image_path": "/path/to/page_001.png", "format": "png"}, ...]}
        
        # Step 3: Read the rendered pages to view CPU, Operating Modes, Memory tables
        for page in result["pages"]:
            Read(page["image_path"])
    """
    _validate_token("doc_id", doc_id)
    _ensure_doc_index_dir()
    if not section_ids:
        return DocumentSliceResponse(
            doc_id=doc_id,
            section_ids=[],
            error=MCPError(message="Provide at least one section_id."),
        )

    for section_id in section_ids:
        _validate_section_id(section_id)

    section_ranges: list[DocumentSectionRangeResponse] = []
    for section_id in section_ids:
        range_resp = _get_document_section_range(doc_id=doc_id, section_id=section_id)
        if range_resp.error:
            return DocumentSliceResponse(
                doc_id=doc_id,
                section_ids=section_ids,
                error=range_resp.error,
            )
        section_ranges.append(range_resp)

    ordered_ranges = sorted(
        [(section.page_start, section.page_end) for section in section_ranges],
        key=lambda pair: (pair[0], pair[1]),
    )
    # Keep ordering for stitching; no need to return page spans.
    source_path = _resolve_doc_path(doc_id)
    if not source_path:
        return DocumentSliceResponse(
            doc_id=doc_id,
            section_ids=section_ids,
            error=MCPError(message="Source PDF not found for doc_id."),
        )

    import fitz

    slice_dir = _build_slice_dir(doc_id, section_ids)
    with fitz.open(source_path) as src:
        total_pages = src.page_count
        new_doc = fitz.open()
        for start, end in ordered_ranges:
            start = max(1, start)
            end = min(end, total_pages)
            if end < start:
                continue
            new_doc.insert_pdf(src, from_page=start - 1, to_page=end - 1)
        pages: list[PdfPageImage] = []
        for idx in range(new_doc.page_count):
            page = new_doc.load_page(idx)
            pix = page.get_pixmap()
            image_path = slice_dir / f"page_{idx + 1:03d}.png"
            pix.save(str(image_path))
            pages.append(
                PdfPageImage(
                    page=idx + 1,
                    image_path=str(image_path),
                    format="png",
                )
            )
        new_doc.close()
    return DocumentSliceResponse(
        doc_id=doc_id,
        section_ids=section_ids,
        pages=pages,
    )
