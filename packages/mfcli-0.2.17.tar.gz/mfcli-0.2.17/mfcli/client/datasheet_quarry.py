"""Client for the Datasheet Quarry cloud API.

Provides datasheet lookup, status polling, bundle download,
and API key registration capabilities.
"""
import time
import logging
from dataclasses import dataclass, field
from typing import Optional, List

import requests

from mfcli.utils.config import get_config

logger = logging.getLogger(__name__)

DEFAULT_QUARRY_URL = "http://136.109.26.167"
LOCAL_QUARRY_URL = "http://localhost:8080"


@dataclass
class QuarryDatasheetResult:
    """Result from a Datasheet Quarry lookup."""
    success: bool
    part_number: str
    datasheet_url: Optional[str] = None
    datasheet_id: Optional[str] = None
    manufacturer: Optional[str] = None
    description: Optional[str] = None
    processing_status: Optional[str] = None
    bundle_url: Optional[str] = None
    download_urls: Optional[dict] = field(default_factory=dict)
    error: Optional[str] = None


class DatasheetQuarryClient:
    """
    Client for the Datasheet Quarry API.

    Provides datasheet lookup, status polling, and bundle download
    capabilities via the cloud API. Falls back gracefully when
    the service is unavailable.
    """

    def __init__(self, base_url: Optional[str] = None, api_key: Optional[str] = None):
        """
        Initialize the client.

        Args:
            base_url: Override the base URL (defaults to config or production URL).
                      If datasheet_quarry_local=true in .env, automatically uses
                      http://localhost:8080 unless base_url is explicitly provided.
            api_key: Override the API key (defaults to config value).
        """
        config = get_config()

        # Resolve base URL: explicit arg > local flag > config > default
        if base_url:
            self._base_url = base_url.rstrip("/")
        elif config.datasheet_quarry_local:
            self._base_url = LOCAL_QUARRY_URL
            logger.info("Datasheet Quarry LOCAL mode enabled → %s", LOCAL_QUARRY_URL)
        else:
            self._base_url = (config.datasheet_quarry_url or DEFAULT_QUARRY_URL).rstrip("/")

        self._is_local = config.datasheet_quarry_local
        self._api_key = api_key or config.datasheet_quarry_api_key
        self._session = requests.Session()
        self._session.headers.update({
            "X-API-Key": self._api_key,
            "Content-Type": "application/json",
            "Accept": "application/json",
        })

    @property
    def is_local(self) -> bool:
        """Check if the client is targeting a local Datasheet Quarry instance."""
        return self._is_local

    @property
    def is_configured(self) -> bool:
        """Check if Datasheet Quarry is configured with a valid API key."""
        return bool(self._api_key and self._api_key.startswith("dsq_"))

    def health_check(self) -> bool:
        """Check if the Datasheet Quarry service is healthy."""
        try:
            resp = self._session.get(f"{self._base_url}/health", timeout=5)
            return resp.status_code == 200
        except Exception:
            return False

    def fetch_datasheet(self, part_number: str, retry_on_rate_limit: bool = True, max_retries: int = 3) -> QuarryDatasheetResult:
        """
        Request a datasheet for a part number.

        This triggers the cloud service to search DigiKey (dual-strategy)
        and Octopart, then process the PDF if found. If the datasheet is
        already cached in the cloud, it returns immediately with download URLs.

        Args:
            part_number: Component part number (e.g., "TPS73533DRBT")
            retry_on_rate_limit: Whether to retry on 429 errors with exponential backoff
            max_retries: Maximum number of retries for rate limit errors

        Returns:
            QuarryDatasheetResult with datasheet info and processing status
        """
        retries = 0
        backoff_seconds = 1
        
        while True:
            try:
                resp = self._session.post(
                    f"{self._base_url}/v1/datasheets/fetch",
                    json={"part_number": part_number},
                    timeout=30,
                )

                if resp.status_code == 404:
                    return QuarryDatasheetResult(
                        success=False,
                        part_number=part_number,
                        error="Part not found in any source",
                    )
                
                # Handle rate limiting with exponential backoff
                if resp.status_code == 429 and retry_on_rate_limit and retries < max_retries:
                    retries += 1
                    logger.warning(f"Rate limited for {part_number}, retrying in {backoff_seconds}s (attempt {retries}/{max_retries})")
                    time.sleep(backoff_seconds)
                    backoff_seconds *= 2  # Exponential backoff
                    continue

                resp.raise_for_status()
                data = resp.json()

                download_urls = data.get("download_urls") or {}
                return QuarryDatasheetResult(
                    success=True,
                    part_number=part_number,
                    datasheet_id=data.get("id"),
                    datasheet_url=data.get("datasheet_url"),
                    manufacturer=data.get("manufacturer"),
                    description=data.get("description"),
                    processing_status=data.get("processing_status"),
                    bundle_url=download_urls.get("bundle"),
                    download_urls=download_urls,
                )

            except requests.HTTPError as e:
                logger.error("Datasheet Quarry API error for %s: %s", part_number, e)
                return QuarryDatasheetResult(
                    success=False,
                    part_number=part_number,
                    error=f"API error: {e}",
                )
            except Exception as e:
                logger.error("Datasheet Quarry connection error: %s", e)
                return QuarryDatasheetResult(
                    success=False,
                    part_number=part_number,
                    error=f"Connection error: {e}",
                )

    def batch_fetch_datasheets(
        self, 
        part_numbers: List[str],
        delay_between_requests: float = 0.5,
        retry_on_rate_limit: bool = True
    ) -> dict[str, QuarryDatasheetResult]:
        """
        Fetch datasheets for multiple part numbers with rate limiting.
        
        This method attempts to use a batch endpoint if available, otherwise
        falls back to sequential requests with rate limiting to avoid 429 errors.

        Args:
            part_numbers: List of component part numbers
            delay_between_requests: Delay in seconds between requests (for sequential mode)
            retry_on_rate_limit: Whether to retry on 429 errors

        Returns:
            Dictionary mapping part numbers to QuarryDatasheetResult objects
        """
        results = {}
        
        # Try batch endpoint first (if implemented by API)
        try:
            resp = self._session.post(
                f"{self._base_url}/v1/datasheets/batch-fetch",
                json={"part_numbers": part_numbers},
                timeout=60,
            )
            
            if resp.status_code in (200, 202):
                data = resp.json()
                batch_results = data.get("results", {})
                
                # The batch endpoint returns results as a dict keyed by part number
                # e.g. {"NE555P": {"status": "success", "datasheet_id": "...", ...}}
                if isinstance(batch_results, dict):
                    logger.info(f"Successfully batch fetched {len(batch_results)} datasheets")
                    for pn, item in batch_results.items():
                        is_success = item.get("status") == "success"
                        results[pn] = QuarryDatasheetResult(
                            success=is_success,
                            part_number=pn,
                            datasheet_id=item.get("datasheet_id"),
                            processing_status=item.get("processing_status"),
                            error=item.get("error"),
                        )
                elif isinstance(batch_results, list):
                    logger.info(f"Successfully batch fetched {len(batch_results)} datasheets")
                    for item in batch_results:
                        pn = item.get("part_number")
                        download_urls = item.get("download_urls") or {}
                        results[pn] = QuarryDatasheetResult(
                            success=item.get("success", False),
                            part_number=pn,
                            datasheet_id=item.get("id"),
                            datasheet_url=item.get("datasheet_url"),
                            manufacturer=item.get("manufacturer"),
                            description=item.get("description"),
                            processing_status=item.get("processing_status"),
                            bundle_url=download_urls.get("bundle"),
                            download_urls=download_urls,
                            error=item.get("error"),
                        )
                
                return results
            elif resp.status_code == 404:
                # Batch endpoint not implemented, fall back to sequential
                logger.debug("Batch endpoint not available, falling back to sequential requests")
            else:
                logger.warning(f"Batch endpoint returned {resp.status_code}, falling back to sequential requests")
                
        except Exception as e:
            logger.debug(f"Batch endpoint not available: {e}, falling back to sequential requests")
        
        # Fall back to sequential requests with rate limiting
        logger.info(f"Fetching {len(part_numbers)} datasheets sequentially with rate limiting")
        for i, part_number in enumerate(part_numbers):
            if i > 0:
                time.sleep(delay_between_requests)
            
            result = self.fetch_datasheet(part_number, retry_on_rate_limit=retry_on_rate_limit)
            results[part_number] = result
            
            if (i + 1) % 10 == 0:
                logger.info(f"Progress: {i + 1}/{len(part_numbers)} datasheets fetched")
        
        return results

    def get_status(self, datasheet_id: str) -> dict:
        """
        Get the current processing status of a datasheet.

        Args:
            datasheet_id: UUID of the datasheet

        Returns:
            Full datasheet response dict
        """
        resp = self._session.get(
            f"{self._base_url}/v1/datasheets/{datasheet_id}",
            timeout=15,
        )
        resp.raise_for_status()
        return resp.json()

    def wait_for_processing(
        self,
        datasheet_id: str,
        timeout: int = 300,
        poll_interval: int = 5,
        part_number: Optional[str] = None,
    ) -> dict:
        """
        Poll until processing completes or times out.

        Args:
            datasheet_id: UUID of the datasheet
            timeout: Max seconds to wait (default: 5 minutes)
            poll_interval: Seconds between polls (default: 5)
            part_number: Human-readable part number for log/error messages
                         (falls back to short UUID when not provided)

        Returns:
            Final datasheet response dict

        Raises:
            TimeoutError: If processing doesn't complete in time
            RuntimeError: If processing fails
        """
        # Use part number for human-readable messages; fall back to a short
        # UUID prefix so messages remain identifiable without being cryptic.
        label = part_number or datasheet_id[:8]

        start = time.time()
        while time.time() - start < timeout:
            data = self.get_status(datasheet_id)
            status = data.get("processing_status")

            # Prefer the part number from the API response if we don't already have one
            if not part_number:
                label = data.get("part_number") or datasheet_id[:8]

            if status == "completed":
                return data
            elif status == "failed":
                raise RuntimeError(
                    f"Datasheet '{label}' processing failed"
                )

            logger.debug(
                "Datasheet '%s' status: %s, waiting %ds...",
                label, status, poll_interval,
            )
            time.sleep(poll_interval)

        raise TimeoutError(
            f"Datasheet '{label}' processing timed out after {timeout}s"
        )

    def download_bundle(self, datasheet_id: str) -> bytes:
        """
        Download the processed ZIP bundle.

        The bundle contains:
        - datasheet.pdf (original PDF)
        - chunks.json (text segments)
        - embeddings.json (chunks + embeddings)
        - metadata.json (part metadata)

        Args:
            datasheet_id: UUID of the datasheet

        Returns:
            ZIP file content as bytes
        """
        resp = self._session.get(
            f"{self._base_url}/v1/datasheets/{datasheet_id}/download/bundle",
            timeout=60,
            allow_redirects=True,
        )
        resp.raise_for_status()
        return resp.content

    def download_pdf(self, datasheet_id: str) -> bytes:
        """Download just the PDF."""
        resp = self._session.get(
            f"{self._base_url}/v1/datasheets/{datasheet_id}/download/pdf",
            timeout=60,
            allow_redirects=True,
        )
        resp.raise_for_status()
        return resp.content

    def download_embeddings(self, datasheet_id: str) -> bytes:
        """Download the embeddings JSON (chunks with pre-computed embedding vectors)."""
        resp = self._session.get(
            f"{self._base_url}/v1/datasheets/{datasheet_id}/download/embeddings",
            timeout=60,
            allow_redirects=True,
        )
        resp.raise_for_status()
        return resp.content

    def download_chunks(self, datasheet_id: str) -> bytes:
        """Download the chunks JSON (text chunks without embedding vectors)."""
        resp = self._session.get(
            f"{self._base_url}/v1/datasheets/{datasheet_id}/download/chunks",
            timeout=60,
            allow_redirects=True,
        )
        resp.raise_for_status()
        return resp.content

    def get_quota(self) -> dict:
        """
        Get current API quota usage.

        Returns:
            Dict with keys: monthly_limit, current_usage, reset_date, remaining
        """
        resp = self._session.get(
            f"{self._base_url}/v1/users/me/quota",
            timeout=10,
        )
        resp.raise_for_status()
        return resp.json()

    def get_sync(self, since: str, limit: int = 100, offset: int = 0) -> dict:
        """
        Get datasheets updated since a timestamp.

        Args:
            since: ISO 8601 timestamp string
            limit: Max results per page
            offset: Pagination offset

        Returns:
            Dict with keys: since, results, total, limit, offset, has_more
        """
        resp = self._session.get(
            f"{self._base_url}/v1/datasheets/sync",
            params={"since": since, "limit": limit, "offset": offset},
            timeout=15,
        )
        resp.raise_for_status()
        return resp.json()

    def export_search_index(self) -> dict:
        """
        Export the lightweight search index of all processed datasheets.

        Returns:
            Dict with keys: version, generated_at, datasheets, count
        """
        resp = self._session.get(
            f"{self._base_url}/v1/datasheets/index/export",
            timeout=15,
        )
        resp.raise_for_status()
        return resp.json()


def request_api_key(email: str, base_url: Optional[str] = None) -> dict:
    """
    Request a new API key via the public self-registration endpoint.

    No authentication required. The API key will be generated and sent
    to the provided email address. Creates a free-tier account for new
    users; generates a new key for existing users.

    Args:
        email: Email address to receive the API key
        base_url: Override the base URL (defaults to production)

    Returns:
        Dict with keys: message, email

    Raises:
        requests.HTTPError: If the request fails (429 if rate-limited)
    """
    url = (base_url or DEFAULT_QUARRY_URL).rstrip("/")
    resp = requests.post(
        f"{url}/v1/api-keys/request",
        json={"email": email},
        headers={"Content-Type": "application/json"},
        timeout=15,
    )
    resp.raise_for_status()
    return resp.json()


def create_additional_api_key(
    existing_api_key: str,
    name: str = "mfcli-integration",
    base_url: Optional[str] = None,
) -> dict:
    """
    Create an additional API key using an existing authenticated key.

    Requires an existing valid API key. Use this when a user already has
    a key and wants to generate a new one (e.g., for a different machine).

    Args:
        existing_api_key: A valid dsq_ API key for authentication
        name: Display name for the new API key
        base_url: Override the base URL (defaults to production)

    Returns:
        Dict with keys: id, key, key_prefix, name, created_at, is_active

    Raises:
        requests.HTTPError: If the request fails (401 if key is invalid)
    """
    url = (base_url or DEFAULT_QUARRY_URL).rstrip("/")
    resp = requests.post(
        f"{url}/v1/api-keys",
        json={"name": name},
        headers={
            "Content-Type": "application/json",
            "X-API-Key": existing_api_key,
        },
        timeout=15,
    )
    resp.raise_for_status()
    return resp.json()
