import asyncio
import os
import traceback
from pathlib import Path
from typing import Type, Literal, List

from google import genai
from google.genai.client import AsyncClient
from google.genai.types import GenerateContentConfig, HttpRetryOptionsDict, HttpOptions, File
from pydantic import BaseModel, ValidationError
from typing_extensions import TypeVar

from mfcli.agents.tools.general import format_instructions
from mfcli.utils.config import get_config
from mfcli.utils.logger import get_logger

logger = get_logger(__name__)

T = TypeVar(name='T', bound=BaseModel)

GeminiSupportedModels = Literal['gemini-2.5-flash', 'gemini-2.5-pro', 'gemini-3-pro-preview']
DefaultGeminiModel = 'gemini-2.5-pro'


class GeminiFileEntity(BaseModel):
    path: Path
    mime_type: str


GeminiFileInput = GeminiFileEntity | str | Path


class Gemini:
    def __init__(self):
        self._config = get_config()
        self._client: AsyncClient = genai.Client(api_key=self._config.google_api_key).aio

    @staticmethod
    def _get_request_config(
            timeout: int,
            instructions: str,
            response_model: Type[T]
    ) -> GenerateContentConfig:
        retry_options = HttpRetryOptionsDict(
            attempts=3,
            initial_delay=1,
            max_delay=10,
            exp_base=2
        )
        http_options = HttpOptions(
            retry_options=retry_options,
            timeout=timeout * 1000
        )
        return GenerateContentConfig(
            system_instruction=instructions,
            response_mime_type="application/json",
            response_json_schema=response_model.model_json_schema(),
            http_options=http_options
        )

    @staticmethod
    def _file_access_check(file_path: str):
        file_path_obj = Path(file_path)

        # Validate file exists and is readable
        if not file_path_obj.exists():
            raise ValueError(f"File does not exist: {file_path}")
        if not os.access(file_path_obj, os.R_OK):
            raise ValueError(f"File is not readable: {file_path}")

    async def upload(self, file: GeminiFileInput, timeout: int = 300) -> File:
        """
        Upload a file to Gemini API with retry logic for transient network errors.
        
        Args:
            file: File to upload (can be path string, Path object, or GeminiFileEntity)
            timeout: Timeout in seconds (default 300s = 5 minutes for large PDFs)
        
        Returns:
            Uploaded File object from Gemini API
        """
        config = None
        if isinstance(file, GeminiFileEntity):
            file_path = str(file.path)
            config = {"mime_type": file.mime_type}
        else:
            file_path = str(file)
        
        self._file_access_check(file_path)
        
        # Retry logic for transient network errors (similar to _generate_with_retry)
        attempts = 3
        backoff = 2.0
        delay = 2.0
        last_err = None
        
        for attempt in range(1, attempts + 1):
            try:
                logger.debug(f"Uploading file (attempt {attempt}/{attempts}): {Path(file_path).name}")
                
                # Upload with timeout configuration
                # Note: The google.genai client doesn't support timeout at upload level,
                # but we can catch and retry timeout errors
                upload_result = await self._client.files.upload(
                    file=file_path,
                    config=config
                )
                
                logger.debug(f"Successfully uploaded: {Path(file_path).name}")
                return upload_result
                
            except Exception as e:
                last_err = e
                error_msg = str(e)
                
                # Check if this is a retryable error
                is_timeout = "timeout" in error_msg.lower() or "WinError 121" in error_msg
                is_network = "ClientOSError" in str(type(e).__name__) or "aiohttp" in str(type(e).__module__)
                
                # INVALID_ARGUMENT usually means the file is corrupted or invalid - don't retry
                is_invalid_file = "INVALID_ARGUMENT" in error_msg or "Failed to create file" in error_msg
                
                if is_invalid_file:
                    # Don't retry invalid files - fail immediately with helpful message
                    logger.error(
                        f"File rejected by Gemini API: {Path(file_path).name}. "
                        f"The file may be corrupted or in an unsupported format. Error: {error_msg}"
                    )
                    raise ValueError(
                        f"Gemini API rejected file {Path(file_path).name}. "
                        f"The file may be corrupted, incomplete, or in an unsupported format. "
                        f"Please verify the file integrity."
                    ) from e
                
                if attempt < attempts and (is_timeout or is_network):
                    logger.warning(
                        f"Upload failed (attempt {attempt}/{attempts}): {error_msg}. "
                        f"Retrying in {delay:.1f}s..."
                    )
                    await asyncio.sleep(delay)
                    delay *= backoff
                else:
                    # Last attempt or non-retryable error
                    break
        
        # All attempts failed
        raise RuntimeError(
            f"Failed to upload file after {attempts} attempts: {Path(file_path).name}"
        ) from last_err

    async def _generate_once(
            self,
            prompt: str,
            instructions: str,
            response_model: Type[T],
            model: GeminiSupportedModels,
            files: List[File] | None = None,
            timeout: int = 60
    ) -> str:
        contents = [prompt]
        if files:
            contents += files
        response = await self._client.models.generate_content(
            model=str(model),
            contents=contents,
            config=self._get_request_config(timeout, instructions, response_model),
        )
        return response.text

    async def _generate_with_retry(
            self,
            prompt: str,
            instructions: str,
            response_model: Type[T],
            model: GeminiSupportedModels,
            files: List[File] | None = None,
            timeout: int = 60
    ) -> T:

        attempts = 3
        backoff = 1.5
        delay = 1.0
        last_err = None

        for attempt in range(1, attempts + 1):

            try:
                # --- FIRST ATTEMPT (normal generation) ---
                raw = await self._generate_once(
                    prompt=prompt,
                    instructions=instructions,
                    response_model=response_model,
                    model=model,
                    files=files,
                    timeout=timeout
                )

                try:
                    # Try to parse normally
                    return response_model.model_validate_json(raw)

                except ValidationError as ve:
                    # --- SECOND CHANCE: RE-ASK THE MODEL TO FIX ITS OUTPUT ---
                    fix_prompt = (
                        "Your previous response did not match the required JSON schema.\n\n"
                        f"Validation error:\n{ve}\n\n"
                        f"Invalid response:\n{raw}\n\n"
                        "Please correct the response so that it validates successfully."
                    )

                    corrected_raw = await self._generate_once(
                        prompt=fix_prompt,
                        instructions=instructions,
                        response_model=response_model,
                        model=model,
                        files=files,
                        timeout=timeout
                    )

                    # Parse corrected output
                    return response_model.model_validate_json(corrected_raw)

            except Exception as e:
                # network/SDK/parsing failures that aren't validation-related
                last_err = e
                if attempt == attempts:
                    break

                logger.debug(f"[Gemini retry] Attempt {attempt}/{attempts} failed: {e}")
                await asyncio.sleep(delay)
                delay *= backoff

        raise RuntimeError(
            f"Gemini generate_with_retry failed after {attempts} attempts"
        ) from last_err

    async def generate_and_validate_with(
            self,
            prompt: str,
            instructions: str,
            response_model: Type[T],
            validation_func,
            model: GeminiSupportedModels = DefaultGeminiModel,
            files: List[File] | None = None,
            timeout: int = 60
    ) -> T:

        original_user_prompt = prompt

        async def run_generation(p: str) -> T:
            return await self.generate(
                prompt=p,
                instructions=instructions,
                response_model=response_model,
                model=model,
                files=files,
                timeout=timeout
            )

        # --- First attempt ---
        resp: T = await run_generation(original_user_prompt)

        try:
            validation_func(resp)
            return resp
        except Exception:
            first_error = traceback.format_exc()

        # --- Retry attempt ---
        retry_prompt = format_instructions(
            f"""
            You previously generated an invalid response.
            Correct it.
        
            User Prompt:
            {original_user_prompt}
        
            Error raised by validator:
            {first_error}
        
            Your previous output:
            {resp}
            """
        )

        resp_retry: T = await run_generation(retry_prompt)

        try:
            validation_func(resp_retry)
            return resp_retry
        except Exception as e:
            second_error = traceback.format_exc()
            raise RuntimeError(
                f"Model failed validation twice.\n"
                f"First error:\n{first_error}\n\n"
                f"Second error:\n{second_error}\n\n"
                f"Last model output:\n{resp_retry}"
            ) from e

    async def generate(
            self,
            prompt: str,
            instructions: str,
            response_model: Type[T],
            model: GeminiSupportedModels = DefaultGeminiModel,
            files: List[File] | None = None,
            timeout: int = 60
    ) -> T:
        logger.debug(f"Generating for model: {response_model}")
        parsed_response = await self._generate_with_retry(
            prompt=prompt,
            instructions=instructions,
            response_model=response_model,
            model=model,
            files=files,
            timeout=timeout
        )
        logger.debug(f"Finished generating for model: {response_model}")
        return parsed_response
