from gtranslate import GoogleTranslator


def test_language_details_for_fr():
    details = GoogleTranslator.get_language_details('fr')
    assert details['code'] == 'fr'
    assert details['language'] == 'French'


def test_supports_composite_code_mapping():
    translator = GoogleTranslator(source='auto', target='zh-CN')
    assert translator.get_target_details()['code'] == 'zh-CN'
