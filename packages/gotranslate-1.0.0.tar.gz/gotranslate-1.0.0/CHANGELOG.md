# Changelog

## 1.0.0

- Initial public package structure
- Google translation support
- Language detection
- Full source/target metadata
- Supported languages JSON export
- Supported languages with emoji flags
- CLI entrypoint
