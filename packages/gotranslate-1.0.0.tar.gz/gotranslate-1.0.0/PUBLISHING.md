# Publish gotranslate on PyPI (Windows 11)

## Files changed

You need these updated files:

- `pyproject.toml`
- `README.md`
- `.github/workflows/publish.yml`

Your Python package folder can stay as:

```text
gtranslate/
```

So users will install with:

```bash
pip install gotranslate
```

and import with:

```python
from gtranslate import GoogleTranslator
```

That is valid in Python packaging.

---

## Step 1 - Revoke the exposed token

Because your previous PyPI token appeared on screen, delete it now:

1. Open PyPI
2. Click your account
3. Open **Account settings**
4. Open **API tokens**
5. Delete the exposed token
6. Create a new token

Keep the new token ready.

---

## Step 2 - Replace the files

Copy these files into your project:

- `pyproject.toml`
- `README.md`
- `.github/workflows/publish.yml`

---

## Step 3 - Check your project structure

Your project should look like this:

```text
MY_FILES/
└── PYPI/
    ├── gtranslate/
    │   ├── __init__.py
    │   ├── cli.py
    │   ├── constants.py
    │   ├── exceptions.py
    │   ├── google_trans.py
    │   └── parent.py
    ├── .github/
    │   └── workflows/
    │       └── publish.yml
    ├── LICENSE
    ├── README.md
    └── pyproject.toml
```

---

## Step 4 - Remove old build files

Open PowerShell in your project folder and run:

```powershell
Remove-Item -Recurse -Force build, dist, gtranslate.egg-info
```

If one of them does not exist, that is fine.

---

## Step 5 - Build the new package

Run:

```powershell
python -m build
```

Then verify:

```powershell
python -m twine check dist/*
```

You should now see files like:

- `gotranslate-1.0.0.tar.gz`
- `gotranslate-1.0.0-py3-none-any.whl`

---

## Step 6 - Upload to PyPI

Use this command exactly:

```powershell
python -m twine upload dist/* -u __token__ -p "YOUR_NEW_PYPI_TOKEN"
```

Important:

- username must be exactly `__token__`
- password must be the full token starting with `pypi-`

---

## Step 7 - Verify on PyPI

Open PyPI and check your new package page.

If the upload succeeded, people can install it with:

```bash
pip install gotranslate
```

---

## Step 8 - Test installation locally

Open another terminal and run:

```powershell
pip install gotranslate
```

Then test:

```powershell
python
```

```python
from gtranslate import GoogleTranslator

translator = GoogleTranslator(source="auto", target="fr")
print(translator.translate("Hello world"))
```

---

## Step 9 - Publish future versions

For the next release:

1. Change version in `pyproject.toml`

Example:

```toml
version = "1.0.1"
```

2. Rebuild:

```powershell
Remove-Item -Recurse -Force build, dist, gtranslate.egg-info
python -m build
python -m twine check dist/*
```

3. Upload again:

```powershell
python -m twine upload dist/* -u __token__ -p "YOUR_NEW_PYPI_TOKEN"
```

PyPI does not allow re-uploading the same version number.

---

## GitHub automatic publishing later

The included workflow file is ready for GitHub Actions if you want to automate publishing later.

For now, manual upload with Twine is the easiest path.
