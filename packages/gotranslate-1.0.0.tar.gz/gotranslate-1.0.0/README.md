# gotranslate

`gotranslate` is a lightweight Python library built around `GoogleTranslator` for:

- text translation
- language detection
- language metadata
- supported languages export in JSON format
- emoji flags for detected and target languages
- translation details in a single response

It is designed for developers who want a simple and practical translation library for Python projects and APIs.

---

## Installation

```bash
pip install gotranslate
```

---

## Quick Start

```python
from gtranslate import GoogleTranslator

translator = GoogleTranslator(source="auto", target="fr")
print(translator.translate("Hello world"))
print(translator.detect_language("Hello world"))
print(translator.translate_with_details("Hello world"))
```

---

## Features

- Translate text with Google Translate
- Detect source language automatically
- Return translation with full metadata
- Get supported languages as Python dict or JSON
- Get language details:
  - language name
  - language code
  - emoji flag
- Get source and target language details together
- Easy integration with Flask APIs and backend services

---

## Example Output

```json
{
  "text": "Hello world",
  "translation": "Bonjour le monde",
  "source": {
    "language": "English",
    "code": "en",
    "flag": "🇬🇧"
  },
  "target": {
    "language": "French",
    "code": "fr",
    "flag": "🇫🇷"
  }
}
```

---

## Support This Project

If this project helps you and you want to support its development, you can send a small contribution via PayPal.

<p align="center">
  <a href="https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=andryrlnew%40gmail.com&currency_code=USD&item_name=Support%20gotranslate" target="_blank" rel="noopener noreferrer">
    <img src="https://www.paypalobjects.com/webstatic/icon/pp258.png" alt="PayPal" width="22" />
    <strong> Buy me a coffee with PayPal</strong>
  </a>
</p>

**PayPal account:** `andryrlnew@gmail.com`

Thank you very much for your support.

---

## Repository

- Homepage: `https://github.com/lantoandryerics/gotranslate`
- Repository: `https://github.com/lantoandryerics/gotranslate`
- Issues: `https://github.com/lantoandryerics/gotranslate/issues`

---

## License

MIT License
