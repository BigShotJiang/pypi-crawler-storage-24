"""Console script for gtranslate."""
import argparse
import json
import sys

from gtranslate import GoogleTranslator


def main():
    parser = argparse.ArgumentParser(description='Translate text with GoogleTranslator')
    parser.add_argument('text', nargs='?', help='Text to translate')
    parser.add_argument('--source', default='auto', help='Source language code or name')
    parser.add_argument('--target', default='en', help='Target language code or name')
    parser.add_argument('--details', action='store_true', help='Return translation details as JSON')
    args = parser.parse_args()

    if not args.text:
        parser.print_help()
        return 1

    translator = GoogleTranslator(source=args.source, target=args.target)
    if args.details:
        print(json.dumps(translator.translate_with_details(args.text), ensure_ascii=False, indent=2))
    else:
        print(translator.translate(args.text))
    return 0


if __name__ == '__main__':
    sys.exit(main())
