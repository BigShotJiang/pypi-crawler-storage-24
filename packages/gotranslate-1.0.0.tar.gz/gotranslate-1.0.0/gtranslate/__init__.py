"""Top-level package for gtranslate."""

from .google_trans import GoogleTranslator

__author__ = 'Andry Erics'
__email__ = 'andryerics@gmail.com'
__version__ = '1.0.0'

__all__ = ['GoogleTranslator']
