"""Specification validation package."""
