from hestia_earth.utils.log import get_logger

logger = get_logger("hestia_earth.validation")
