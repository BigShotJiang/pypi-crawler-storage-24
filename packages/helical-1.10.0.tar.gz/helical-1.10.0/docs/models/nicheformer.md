::: helical.models.nicheformer.Nicheformer
    handler: python
    options:
      members:
        - process_data
        - get_embeddings
      show_root_heading: True
      show_source: True
