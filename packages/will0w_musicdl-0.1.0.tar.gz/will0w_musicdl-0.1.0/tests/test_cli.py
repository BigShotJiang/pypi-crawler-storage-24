from pathlib import Path
from types import SimpleNamespace
import sys

from musicdl.cli import main
from musicdl.types import DownloadResult, Playlist, Song


# ---------- Single-song CLI (--artist / --title / --album) ----------


def test_single_song_download_via_artist_title(monkeypatch, tmp_path: Path) -> None:
    """--artist and --title should download a single song without a playlist."""
    download_calls: list[Song] = []
    fake_file = tmp_path / "Artist - Title.mp3"
    fake_file.write_bytes(b"mp3")

    def fake_download(song: Song) -> DownloadResult:
        download_calls.append(song)
        return DownloadResult(
            song=song,
            success=True,
            file_path=fake_file,
            source_used="youtube",
        )

    monkeypatch.setattr(
        "musicdl.cli.DownloadEngine",
        lambda _output_dir: SimpleNamespace(
            download_song=fake_download,
            target_file_path=lambda _song: tmp_path / "nonexistent.mp3",
        ),
    )
    monkeypatch.setattr(
        "musicdl.cli.write_mp3_tags",
        lambda *_args, **_kwargs: None,
    )
    monkeypatch.setattr(
        sys,
        "argv",
        [
            "musicdl",
            "--artist",
            "Daft Punk",
            "--title",
            "One More Time",
            "-o",
            str(tmp_path),
        ],
    )

    exit_code = main()

    assert exit_code == 0
    assert len(download_calls) == 1
    assert download_calls[0].artist == "Daft Punk"
    assert download_calls[0].title == "One More Time"
    assert download_calls[0].album is None


def test_single_song_with_album(monkeypatch, tmp_path: Path) -> None:
    """--album should attach album metadata to the Song."""
    download_calls: list[Song] = []
    fake_file = tmp_path / "Artist - Title.mp3"
    fake_file.write_bytes(b"mp3")

    def fake_download(song: Song) -> DownloadResult:
        download_calls.append(song)
        return DownloadResult(
            song=song,
            success=True,
            file_path=fake_file,
            source_used="youtube",
        )

    monkeypatch.setattr(
        "musicdl.cli.DownloadEngine",
        lambda _output_dir: SimpleNamespace(
            download_song=fake_download,
            target_file_path=lambda _song: tmp_path / "nonexistent.mp3",
        ),
    )
    monkeypatch.setattr(
        "musicdl.cli.write_mp3_tags",
        lambda *_args, **_kwargs: None,
    )
    monkeypatch.setattr(
        sys,
        "argv",
        [
            "musicdl",
            "--artist",
            "Daft Punk",
            "--title",
            "One More Time",
            "--album",
            "Discovery",
            "-o",
            str(tmp_path),
        ],
    )

    exit_code = main()

    assert exit_code == 0
    assert len(download_calls) == 1
    assert download_calls[0].album == "Discovery"


def test_single_song_artist_without_title(monkeypatch) -> None:
    """--artist without --title should fail with exit code 2."""
    monkeypatch.setattr(sys, "argv", ["musicdl", "--artist", "Daft Punk"])
    assert main() == 2


def test_single_song_title_without_artist(monkeypatch) -> None:
    """--title without --artist should fail with exit code 2."""
    monkeypatch.setattr(sys, "argv", ["musicdl", "--title", "One More Time"])
    assert main() == 2


def test_url_with_flags_overrides_provider_metadata(
    monkeypatch, tmp_path: Path
) -> None:
    """--artist/--title/--album with a URL should override provider metadata."""
    download_calls: list[Song] = []
    staging = tmp_path / "staging"
    staging.mkdir()
    fake_file = staging / "CLI Artist - CLI Title.mp3"
    fake_file.write_bytes(b"mp3")

    playlist = Playlist(
        source="ytdlp-metadata",
        name="Single Track",
        songs=[
            Song(
                artist="Provider Artist",
                title="Provider Title",
                album="Provider Album",
                source_url="https://www.youtube.com/watch?v=abc",
            )
        ],
    )

    def fake_download(song: Song) -> DownloadResult:
        download_calls.append(song)
        return DownloadResult(
            song=song,
            success=True,
            file_path=fake_file,
            source_used="direct-url",
        )

    monkeypatch.setattr(
        "musicdl.cli.ProviderResolver",
        lambda: SimpleNamespace(resolve=lambda _playlist_input: playlist),
    )
    monkeypatch.setattr(
        "musicdl.cli.DownloadEngine",
        lambda _output_dir: SimpleNamespace(
            download_song=fake_download,
            target_file_path=lambda _song: tmp_path / "nonexistent.mp3",
        ),
    )
    monkeypatch.setattr(
        "musicdl.cli.write_mp3_tags",
        lambda *_args, **_kwargs: None,
    )
    monkeypatch.setattr(
        sys,
        "argv",
        [
            "musicdl",
            "https://www.youtube.com/watch?v=abc",
            "--artist",
            "CLI Artist",
            "--title",
            "CLI Title",
            "--album",
            "CLI Album",
            "-o",
            str(tmp_path),
        ],
    )

    exit_code = main()

    assert exit_code == 0
    assert len(download_calls) == 1
    # CLI flags override provider metadata
    assert download_calls[0].artist == "CLI Artist"
    assert download_calls[0].title == "CLI Title"
    assert download_calls[0].album == "CLI Album"
    assert download_calls[0].source_url == "https://www.youtube.com/watch?v=abc"


def test_url_with_flags_fills_missing_metadata(monkeypatch, tmp_path: Path) -> None:
    """--artist/--title/--album with a URL should fill in missing provider fields."""
    download_calls: list[Song] = []
    staging = tmp_path / "staging"
    staging.mkdir()
    fake_file = staging / "Unknown Artist - Some Title.mp3"
    fake_file.write_bytes(b"mp3")

    playlist = Playlist(
        source="ytdlp-metadata",
        name="Single Track",
        songs=[
            Song(
                artist="",
                title="",
                source_url="https://www.youtube.com/watch?v=abc",
            )
        ],
    )

    def fake_download(song: Song) -> DownloadResult:
        download_calls.append(song)
        return DownloadResult(
            song=song,
            success=True,
            file_path=fake_file,
            source_used="direct-url",
        )

    monkeypatch.setattr(
        "musicdl.cli.ProviderResolver",
        lambda: SimpleNamespace(resolve=lambda _playlist_input: playlist),
    )
    monkeypatch.setattr(
        "musicdl.cli.DownloadEngine",
        lambda _output_dir: SimpleNamespace(
            download_song=fake_download,
            target_file_path=lambda _song: tmp_path / "nonexistent.mp3",
        ),
    )
    monkeypatch.setattr(
        "musicdl.cli.write_mp3_tags",
        lambda *_args, **_kwargs: None,
    )
    monkeypatch.setattr(
        sys,
        "argv",
        [
            "musicdl",
            "https://www.youtube.com/watch?v=abc",
            "--artist",
            "Fallback Artist",
            "--title",
            "Fallback Title",
            "--album",
            "Fallback Album",
            "-o",
            str(tmp_path),
        ],
    )

    exit_code = main()

    assert exit_code == 0
    assert len(download_calls) == 1
    # CLI flags fill in because provider returned empty strings
    assert download_calls[0].artist == "Fallback Artist"
    assert download_calls[0].title == "Fallback Title"
    assert download_calls[0].album == "Fallback Album"
    assert download_calls[0].source_url == "https://www.youtube.com/watch?v=abc"


def test_album_without_artist_title_rejected(monkeypatch) -> None:
    """--album alone (without --artist and --title or a URL) should fail."""
    monkeypatch.setattr(sys, "argv", ["musicdl", "--album", "Discovery"])
    assert main() == 2


def test_url_with_album_fallback_fills_missing(monkeypatch, tmp_path: Path) -> None:
    """--album with a URL should fill in album only when the provider didn't return one."""
    download_calls: list[Song] = []
    staging = tmp_path / "staging"
    staging.mkdir()
    fake_file = staging / "Original Artist - Original Title.mp3"
    fake_file.write_bytes(b"mp3")

    playlist = Playlist(
        source="ytdlp-metadata",
        name="Single Track",
        songs=[
            Song(
                artist="Original Artist",
                title="Original Title",
                source_url="https://www.youtube.com/watch?v=abc",
            )
        ],
    )

    def fake_download(song: Song) -> DownloadResult:
        download_calls.append(song)
        return DownloadResult(
            song=song,
            success=True,
            file_path=fake_file,
            source_used="direct-url",
        )

    monkeypatch.setattr(
        "musicdl.cli.ProviderResolver",
        lambda: SimpleNamespace(resolve=lambda _playlist_input: playlist),
    )
    monkeypatch.setattr(
        "musicdl.cli.DownloadEngine",
        lambda _output_dir: SimpleNamespace(
            download_song=fake_download,
            target_file_path=lambda _song: tmp_path / "nonexistent.mp3",
        ),
    )
    monkeypatch.setattr(
        "musicdl.cli.write_mp3_tags",
        lambda *_args, **_kwargs: None,
    )
    monkeypatch.setattr(
        sys,
        "argv",
        [
            "musicdl",
            "https://www.youtube.com/watch?v=abc",
            "--album",
            "Fallback Album",
            "-o",
            str(tmp_path),
        ],
    )

    exit_code = main()

    assert exit_code == 0
    assert len(download_calls) == 1
    assert download_calls[0].artist == "Original Artist"
    assert download_calls[0].title == "Original Title"
    # Album was missing from provider, so CLI flag fills it in
    assert download_calls[0].album == "Fallback Album"


def test_single_song_with_download_failed_rejected(monkeypatch) -> None:
    """--artist/--title cannot be combined with --download-failed."""
    monkeypatch.setattr(
        sys,
        "argv",
        ["musicdl", "--artist", "X", "--title", "Y", "--download-failed"],
    )
    assert main() == 2


def test_main_backfills_existing_file_from_playlist(
    monkeypatch, tmp_path: Path
) -> None:
    existing_file = tmp_path / "Daft Punk - One More Time.mp3"
    existing_file.write_bytes(b"x")
    backfill_calls: list[tuple[Path, dict[str, object]]] = []

    playlist = Playlist(
        source="spotify",
        name="Discovery Mix",
        songs=[
            Song(
                artist="Daft Punk",
                title="One More Time",
                album="Discovery",
                track_number=1,
                release_date="2001-11-30",
                isrc="GBDUW0000059",
                artwork_url="https://example.com/discovery.jpg",
                genres=("French house", "disco house"),
            )
        ],
    )

    monkeypatch.setattr(
        "musicdl.cli.ProviderResolver",
        lambda: SimpleNamespace(resolve=lambda _playlist_input: playlist),
    )
    monkeypatch.setattr(
        "musicdl.cli.backfill_missing_mp3_tags",
        lambda path, **kwargs: backfill_calls.append((path, kwargs)),
    )
    monkeypatch.setattr(
        sys,
        "argv",
        [
            "musicdl",
            "https://open.spotify.com/playlist/test",
            "-o",
            str(tmp_path),
        ],
    )

    exit_code = main()

    assert exit_code == 0
    assert backfill_calls == [
        (
            existing_file,
            {
                "artist": "Daft Punk",
                "title": "One More Time",
                "album": "Discovery",
                "track_number": 1,
                "release_date": "2001-11-30",
                "isrc": "GBDUW0000059",
                "artwork_url": "https://example.com/discovery.jpg",
                "genres": ("French house", "disco house"),
            },
        )
    ]
