"""Song matching, candidate scoring, and audio download orchestration."""

from __future__ import annotations

from difflib import SequenceMatcher
import json
import re
import shutil
import subprocess
from pathlib import Path

from musicdl.styles import print_update
from musicdl.types import DownloadResult, Song


class DownloadEngine:
    """Search for candidate uploads, choose the best match, and download it."""

    def __init__(self, output_dir: Path) -> None:
        """Initialize the engine and configure backend search precedence."""

        self.output_dir = output_dir
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.search_backends = [
            ("youtube-music-query", "ytsearch5"),
            ("youtube", "ytsearch5"),
            ("soundcloud", "scsearch3"),
        ]

    def download_song(self, song: Song) -> DownloadResult:
        """Attempt to download a single song by iterating across search backends."""

        if not shutil.which("yt-dlp"):
            return DownloadResult(
                song=song,
                success=False,
                error="yt-dlp is not installed or not available in PATH.",
            )

        # When a direct source URL is available, try downloading from it first.
        if song.source_url:
            result = self._download_from_url(song, song.source_url)
            if result.success:
                return result

        for backend_name, prefix in self.search_backends:
            print_update(f"Matching {song.artist} - {song.title} via {backend_name}")
            query = self._build_query(song, backend_name)
            candidate = self._select_candidate(song, f"{prefix}:{query}")
            if not candidate:
                continue
            if self._has_unwanted_variant(song.title, candidate, song.artist):
                continue

            target = self._candidate_target_url(candidate)
            if not target:
                continue

            print_update(f"Downloading {song.artist} - {song.title} via {backend_name}")

            # Use a temporary output template to avoid metadata extraction issues
            output_template = str(self.output_dir / "%(id)s.%(ext)s")
            cmd = [
                "yt-dlp",
                "--extract-audio",
                "--audio-format",
                "mp3",
                "--audio-quality",
                "0",
                "--no-playlist",
                "--quiet",
                "--no-warnings",
                "-o",
                output_template,
                target,
            ]
            proc = subprocess.run(cmd, capture_output=True, text=True)

            if proc.returncode == 0:
                downloaded = self._most_recent_file()
                if downloaded:
                    # Rename to proper format: Artist - Title.mp3
                    chosen_artist = self._effective_artist(
                        song.artist, candidate.get("uploader")
                    )
                    final_path = self.target_file_path(
                        song, artist_override=chosen_artist
                    )
                    downloaded.rename(final_path)
                    return DownloadResult(
                        song=song,
                        success=True,
                        file_path=final_path,
                        source_used=backend_name,
                        matched_title=candidate.get("title"),
                        matched_artist=candidate.get("uploader"),
                        matched_url=target,
                    )

        last_error = (
            (proc.stderr or "").strip()
            if "proc" in locals()
            else "No backend attempted"
        )
        return DownloadResult(
            song=song, success=False, error=last_error or "All backends failed"
        )

    def _download_from_url(self, song: Song, url: str) -> DownloadResult:
        """Download directly from a known URL, skipping search and scoring."""

        print_update(f"Downloading {song.artist} - {song.title} from source URL")
        output_template = str(self.output_dir / "%(id)s.%(ext)s")
        cmd = [
            "yt-dlp",
            "--extract-audio",
            "--audio-format",
            "mp3",
            "--audio-quality",
            "0",
            "--no-playlist",
            "--quiet",
            "--no-warnings",
            "-o",
            output_template,
            url,
        ]
        proc = subprocess.run(cmd, capture_output=True, text=True)

        if proc.returncode == 0:
            downloaded = self._most_recent_file()
            if downloaded:
                final_path = self.target_file_path(song)
                downloaded.rename(final_path)
                return DownloadResult(
                    song=song,
                    success=True,
                    file_path=final_path,
                    source_used="direct-url",
                    matched_url=url,
                )

        return DownloadResult(
            song=song,
            success=False,
            error=(proc.stderr or "").strip() or "Direct URL download failed",
        )

    def _select_candidate(
        self, song: Song, search_target: str
    ) -> dict[str, object] | None:
        """Fetch and rank candidate search results, returning the strongest match."""

        cmd = [
            "yt-dlp",
            "--dump-single-json",
            "--quiet",
            "--no-warnings",
            search_target,
        ]
        proc = subprocess.run(cmd, capture_output=True, text=True)
        if proc.returncode != 0:
            return None

        try:
            payload = json.loads(proc.stdout)
        except json.JSONDecodeError:
            return None

        entries = payload.get("entries") if isinstance(payload, dict) else None
        if not isinstance(entries, list):
            return None

        scored: list[tuple[int, dict[str, object]]] = []
        for item in entries:
            if not isinstance(item, dict):
                continue
            score = self._score_candidate(song, item)
            if score > 0:
                scored.append((score, item))

        if not scored:
            return None

        # Prefer clean track sources over variants/noisy versions when possible.
        clean_scored = [
            pair
            for pair in scored
            if not self._is_music_video_candidate(pair[1])
            and not self._has_unwanted_variant(song.title, pair[1], song.artist)
        ]
        if clean_scored:
            scored = clean_scored

        scored.sort(key=lambda pair: pair[0], reverse=True)
        return scored[0][1]

    def _score_candidate(self, song: Song, candidate: dict[str, object]) -> int:
        """Compute a heuristic relevance score for one candidate result."""

        title = (candidate.get("title") or "").lower()
        uploader = (candidate.get("uploader") or "").lower()
        combined = f"{title} {uploader}"
        webpage_url = str(candidate.get("webpage_url") or "")
        stream_url = str(candidate.get("url") or "")
        collapsed_candidate_title = re.sub(r"[^a-z0-9]+", "", title)

        if not title:
            return 0

        if self._is_preview_url(webpage_url) or self._is_preview_url(stream_url):
            return 0

        blocked_terms = ("podcast", "episode", "audiobook")
        if any(term in combined for term in blocked_terms):
            return 0

        requested_title = self._canonical_title(song.title)
        context_tokens = self._context_tokens_from_title(song.title)
        title_tokens = self._important_tokens(
            requested_title, include_collapsed=True, min_token_length=2
        )
        artist_tokens = self._important_tokens(song.artist, include_collapsed=True)
        normalized_uploader = self._normalized_phrase(
            str(candidate.get("uploader") or ""), include_collapsed=True
        )
        normalized_requested_title = self._normalized_phrase(
            requested_title, include_collapsed=False, min_token_length=2
        )
        normalized_candidate_title = self._normalized_phrase(
            str(candidate.get("title") or ""),
            include_collapsed=False,
            min_token_length=2,
        )

        title_hits = sum(
            1
            for t in title_tokens
            if t in normalized_candidate_title or t in collapsed_candidate_title
        )
        artist_hits_in_title = sum(
            1
            for t in artist_tokens
            if t in normalized_candidate_title or t in collapsed_candidate_title
        )
        artist_hits_in_uploader = sum(
            1 for t in artist_tokens if t in normalized_uploader
        )
        artist_hits = artist_hits_in_title + artist_hits_in_uploader
        title_coverage = title_hits / len(title_tokens) if title_tokens else 0.0
        artist_coverage = artist_hits / len(artist_tokens) if artist_tokens else 0.0
        exact_title_phrase = bool(
            normalized_requested_title
            and normalized_requested_title in normalized_candidate_title
        )
        title_similarity = SequenceMatcher(
            None, normalized_requested_title, normalized_candidate_title
        ).ratio()
        context_hits = sum(
            1
            for t in context_tokens
            if t in normalized_candidate_title
            or t in collapsed_candidate_title
            or t in normalized_uploader
        )
        context_coverage = context_hits / len(context_tokens) if context_tokens else 0.0

        if title_hits == 0:
            return 0

        # Generic titles with a "From ..." clause need context evidence to avoid
        # cross-franchise mismatches (for example one "Theme" matched to another).
        if context_tokens and len(title_tokens) <= 2 and context_hits == 0:
            return 0

        if title_coverage < 0.5 and title_similarity < 0.72 and not exact_title_phrase:
            return 0

        if (
            len(title_tokens) <= 2
            and not exact_title_phrase
            and title_similarity < 0.85
        ):
            return 0

        if (
            self._requires_uploader_artist_match(song.artist)
            and artist_hits_in_uploader == 0
        ):
            return 0

        if not self._is_unknown_artist(song.artist):
            if artist_tokens and artist_hits == 0 and title_similarity < 0.95:
                return 0
            if (
                artist_tokens
                and artist_hits_in_uploader == 0
                and title_similarity < 0.92
                and not exact_title_phrase
            ):
                return 0
            if artist_tokens and artist_coverage < 0.34 and title_similarity < 0.82:
                return 0
        else:
            # Unknown artist is too ambiguous; only allow very strong title matches.
            if len(title_tokens) < 2:
                return 0
            if (
                title_coverage < 0.8
                and title_similarity < 0.9
                and not exact_title_phrase
            ):
                return 0
            if (
                len(title_tokens) <= 2
                and title_similarity < 0.95
                and not exact_title_phrase
            ):
                return 0

        score = title_hits * 4 + artist_hits * 3
        score += int(title_coverage * 6)
        score += int(title_similarity * 6)
        score += int(context_coverage * 8)

        # Prefer track-like uploads over music videos when both are available.
        if self._is_track_like_source(title, uploader):
            score += 3
        if self._is_music_video_source(title, uploader):
            score -= 4

        if "official" in title and "video" not in title:
            score += 1
        if "lyrics" in title:
            score -= 1

        duration = candidate.get("duration")
        if isinstance(duration, (int, float)):
            duration_seconds = int(duration)
            expected = song.duration_seconds
            if expected is not None:
                delta = abs(duration_seconds - expected)
                if delta <= 8:
                    score += 4
                elif delta <= 20:
                    score += 2
                elif delta <= 45:
                    score += 1
                elif delta >= 120:
                    score -= 4
                elif delta >= 60:
                    score -= 2

            # Short tracks are still allowed, just slightly less preferred.
            if duration_seconds < 45:
                score -= 3
            elif duration_seconds < 75:
                score -= 1

        return score

    @staticmethod
    def _important_tokens(
        value: str, include_collapsed: bool = False, min_token_length: int = 3
    ) -> list[str]:
        """Extract normalized tokens while removing low-signal stop words."""

        lowered = value.lower()
        tokens = re.findall(r"[a-z0-9]+", lowered)
        collapsed = re.sub(r"[^a-z0-9]+", "", lowered)
        stop_words = {
            "the",
            "and",
            "for",
            "with",
            "what",
            "your",
            "this",
            "that",
            "from",
            "into",
            "feat",
            "featuring",
            "official",
            "video",
            "audio",
            "music",
            "song",
        }
        filtered = [
            t for t in tokens if len(t) >= min_token_length and t not in stop_words
        ]
        if (
            include_collapsed
            and len(collapsed) >= 3
            and collapsed not in stop_words
            and collapsed not in filtered
        ):
            filtered.append(collapsed)
        return filtered

    @staticmethod
    def _normalized_phrase(
        value: str, include_collapsed: bool = False, min_token_length: int = 3
    ) -> str:
        """Return a normalized token phrase for heuristic matching."""

        return " ".join(
            DownloadEngine._important_tokens(
                value,
                include_collapsed=include_collapsed,
                min_token_length=min_token_length,
            )
        )

    @staticmethod
    def _requires_uploader_artist_match(value: str) -> bool:
        """Return whether artist ambiguity requires stronger uploader evidence."""

        tokens = DownloadEngine._important_tokens(value, include_collapsed=True)
        return len(tokens) == 1 and len(tokens[0]) <= 4

    @staticmethod
    def _is_preview_url(value: str) -> bool:
        """Return whether a candidate URL looks like a short preview rather than a song."""

        lowered = value.lower()
        return "cf-preview-media.sndcdn.com" in lowered or "/preview/" in lowered

    @staticmethod
    def _is_track_like_source(title: str, uploader: str) -> bool:
        """Return whether source metadata suggests an audio-first upload."""

        combined = f"{title} {uploader}".lower()
        hints = (
            " - topic",
            "provided to youtube",
            "official audio",
            "audio only",
            "visualizer",
        )
        return any(h in combined for h in hints)

    @staticmethod
    def _is_music_video_source(title: str, uploader: str) -> bool:
        """Return whether source metadata suggests a music-video style upload."""

        combined = f"{title} {uploader}".lower()
        hints = (
            "official video",
            "music video",
            "official mv",
        )
        return any(h in combined for h in hints)

    @staticmethod
    def _is_music_video_candidate(candidate: dict[str, object]) -> bool:
        """Return whether a full candidate object looks like a music video."""

        title = str(candidate.get("title") or "")
        uploader = str(candidate.get("uploader") or "")
        return DownloadEngine._is_music_video_source(title, uploader)

    @staticmethod
    def _has_unwanted_variant(
        requested_title: str,
        candidate: dict[str, object],
        requested_artist: str | None = None,
    ) -> bool:
        """Return whether a candidate appears to be the wrong version of a song."""

        req = requested_title.lower()
        title = str(candidate.get("title") or "").lower()
        uploader = str(candidate.get("uploader") or "").lower()
        combined = f"{title} {uploader}"

        variant_patterns = (
            r"\bacoustic\b",
            r"\blive\b",
            r"\bremaster(?:ed)?\b",
            r"\bremix\b",
            r"\bcover\b",
            r"\binstrumental\b",
            r"\bkaraoke\b",
            r"\bslowed\b",
            r"\breverb\b",
            r"\bnightcore\b",
            r"\bsped up\b",
            r"\bsecret session\b",
            r"\bsession\b",
            r"\b(?:club|dance|extended|dub|radio) mix\b",
            r"\b(?:radio|club) edit\b",
        )

        for pattern in variant_patterns:
            if re.search(pattern, combined) and not re.search(pattern, req):
                return True

        if requested_artist and DownloadEngine._is_collab_variant(
            requested_artist, str(candidate.get("title") or "")
        ):
            return True
        return False

    @staticmethod
    def _is_collab_variant(requested_artist: str, candidate_title: str) -> bool:
        """Detect collaborator-expanded titles for requests that name a single artist."""

        req_artist = requested_artist.lower()
        # If the requested artist already signals collaboration, allow it.
        if any(token in req_artist for token in ("&", " feat", " ft", " x ", ",")):
            return False

        if " - " not in candidate_title:
            return False

        artist_part = candidate_title.split(" - ", 1)[0].lower()
        if req_artist not in artist_part:
            return False

        # Reject titles that add extra collaborator markers in artist segment.
        return any(
            token in artist_part for token in (" & ", " feat", " ft", " x ", ",")
        )

    @staticmethod
    def _candidate_target_url(candidate: dict[str, object]) -> str | None:
        """Choose the best usable playback or webpage URL from a candidate record."""

        for key in ("webpage_url", "original_url", "url"):
            value = candidate.get(key)
            if not isinstance(value, str) or not value:
                continue
            if DownloadEngine._is_preview_url(value):
                continue
            return value
        return None

    def _most_recent_file(self) -> Path | None:
        """Return the newest downloaded `.mp3` in the output directory, if any."""

        files = list(self.output_dir.glob("*.mp3"))
        if not files:
            return None
        return max(files, key=lambda path: path.stat().st_mtime)

    def target_file_path(self, song: Song, artist_override: str | None = None) -> Path:
        """Return the canonical output path for a downloaded song."""

        safe_artist = self._sanitize_filename(artist_override or song.artist)
        safe_title = self._sanitize_filename(song.title)
        return self.output_dir / f"{safe_artist} - {safe_title}.mp3"

    @staticmethod
    def _effective_artist(song_artist: str, matched_artist: str | None) -> str:
        """Prefer the matched artist when the requested artist is intentionally unknown."""

        if DownloadEngine._is_unknown_artist(song_artist) and matched_artist:
            return matched_artist
        return song_artist

    @staticmethod
    def _is_unknown_artist(value: str) -> bool:
        """Return whether the artist string represents an unknown placeholder."""

        return value.strip().lower() in {"unknown artist", "unknown"}

    @staticmethod
    def _canonical_title(value: str) -> str:
        """Strip metadata suffixes that hurt matching quality."""
        cleaned = value.strip()
        cleaned = re.sub(r"\s+-\s+from\b.*$", "", cleaned, flags=re.IGNORECASE)
        cleaned = re.sub(r"\s+\(from\b.*\)$", "", cleaned, flags=re.IGNORECASE)
        cleaned = re.sub(r"\s+\[from\b.*\]$", "", cleaned, flags=re.IGNORECASE)
        return cleaned or value

    @staticmethod
    def _context_tokens_from_title(value: str) -> list[str]:
        """Extract franchise/context tokens from '(From ...)' style titles."""
        match = re.search(r"\(from\s+(.+?)\)", value, flags=re.IGNORECASE)
        if not match:
            match = re.search(r"-\s+from\s+(.+)$", value, flags=re.IGNORECASE)
        if not match:
            return []

        context = match.group(1)
        context = re.sub(r"[_\"'`]+", " ", context)
        context = re.sub(
            r"\b(soundtrack|score|theme)\b", " ", context, flags=re.IGNORECASE
        )
        context = re.sub(r"\s+", " ", context).strip()
        if not context:
            return []
        return DownloadEngine._important_tokens(
            context,
            include_collapsed=False,
            min_token_length=2,
        )

    @staticmethod
    def _sanitize_filename(filename: str) -> str:
        """Remove/replace characters invalid in filenames."""
        invalid_chars = ["/", "\\", ":", "*", "?", '"', "<", ">", "|"]
        for char in invalid_chars:
            filename = filename.replace(char, "_")
        return filename

    @staticmethod
    def _build_query(song: Song, backend_name: str) -> str:
        """Build a backend-specific search query for a requested song."""

        artist = song.artist
        title = DownloadEngine._canonical_title(song.title)
        context_tokens = DownloadEngine._context_tokens_from_title(song.title)
        if (
            context_tokens
            and len(
                DownloadEngine._important_tokens(
                    title, include_collapsed=False, min_token_length=2
                )
            )
            <= 2
        ):
            title = f"{title} {' '.join(context_tokens)}"
        if DownloadEngine._requires_uploader_artist_match(song.artist) or re.search(
            r"[^A-Za-z0-9\s]", song.artist
        ):
            artist = f'"{song.artist}"'
        if backend_name == "youtube-music-query":
            return f"{artist} - {title} topic"
        return f"{artist} - {title}"
