---
name: Legalis MCP Project Security Context
description: Security architecture overview and key findings for the legalis-mcp Python MCP server
type: project
---

Legalis MCP is a Python MCP (Model Context Protocol) server that acts as an authenticated proxy between an LLM (Claude) and the Legalis REST API (Brazilian legal document platform). It handles OAuth 2.0 + PKCE auth, stores credentials locally, and exposes ~25 MCP tools wrapping CRUD API calls.

**Key security-relevant facts:**
- OAuth PKCE flow implemented in auth.py — state parameter checked, S256 challenge used
- Credentials stored at ~/.legalis/credentials.json with chmod 0o600
- Access token + refresh token loaded from env vars (LEGALIS_ACCESS_TOKEN / LEGALIS_REFRESH_TOKEN) or disk
- All API calls go to a hardcoded Railway production URL (`https://hai-production-612f.up.railway.app`)
- Singleton HTTP client (`get_client()`) shared across all MCP tool calls in a single server process
- No UUID format validation on `case_id`, `doc_id`, `task_id`, etc. before interpolating into URL paths
- No input length limits enforced client-side on any tool parameter
- `section_key` is interpolated directly into URL paths without sanitization
- CI pipeline uses PyPI Trusted Publishing (no API token in workflow) — good practice

**Confirmed issues from first review (2026-03-27):**
- Path traversal via unvalidated IDs in URL construction (medium-high)
- Credential exposure through env var logging risk
- Singleton client not thread-safe for concurrent requests
- No TLS certificate pinning (acceptable for general HTTP client)
- No rate limiting or quota enforcement client-side

**Why:** Initial security review performed on full codebase at v0.3.0.
**How to apply:** Use as baseline when reviewing future changes or additions to this project.
