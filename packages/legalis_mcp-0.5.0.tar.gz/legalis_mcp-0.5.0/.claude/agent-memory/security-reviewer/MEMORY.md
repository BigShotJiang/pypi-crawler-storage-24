# Security Reviewer Memory Index

- [Legalis MCP Project Security Context](project_legalis_mcp.md) — Security architecture overview and confirmed findings from v0.3.0 review (2026-03-27)
