"""Simple manual check for the TeleStore list_files helpers.

Usage:
    python scripts/list_files_check.py --api-key sk-... [--base-url https://...]

The script fetches the caller's file metadata twice—once via list_files()
(full payload) and once via list_file_ids()—and asserts that the sets of
IDs match.  It then prints a short summary so you can visually confirm the
results.
"""
from __future__ import annotations

import argparse
import sys
from typing import Any, Dict, List, Sequence, cast

from telestore import TeleStoreClient


def parse_args(argv: Sequence[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Validate TeleStore list APIs")
    parser.add_argument("--api-key", default="sk-....", help="TeleStore API key")
    parser.add_argument(
        "--base-url",
        default="http://localhost:8000",
        help="TeleStore base URL (default: hosted instance)",
    )
    parser.add_argument(
        "--ids-only",
        action="store_true",
        help="Print only file_id values (one per line)",
    )
    return parser.parse_args(argv)


def main(argv: Sequence[str] | None = None) -> int:
    args = parse_args(argv or sys.argv[1:])

    client = TeleStoreClient(api_key=args.api_key, base_url=args.base_url)

    files = cast(List[Dict[str, Any]], client.list_files())
    ids = cast(List[str], client.list_file_ids())
    ids_from_full = [entry["file_id"] for entry in files]

    if set(ids) != set(ids_from_full):
        print("Mismatch between list_files() and list_file_ids() output", file=sys.stderr)
        return 1

    if args.ids_only:
        for file_id in ids:
            print(file_id)
    else:
        print(f"Fetched {len(files)} file(s) from {args.base_url}.")
        for entry in files:
            print(
                f"- {entry['file_id']} :: {entry['original_filename']} :: {entry['size_bytes']} bytes"
            )

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
