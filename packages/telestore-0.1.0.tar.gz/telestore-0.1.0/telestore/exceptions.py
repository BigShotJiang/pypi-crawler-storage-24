"""
Custom exceptions for the TeleStore client library.

All exceptions inherit from :class:`TeleStoreError`, so callers can catch
the base class if they don't need fine-grained handling.
"""


class TeleStoreError(Exception):
    """Base exception for all TeleStore errors."""


class AuthenticationError(TeleStoreError):
    """
    Raised when the API key is missing, empty, or rejected by the server (HTTP 401).
    """


class UploadError(TeleStoreError):
    """
    Raised when a file upload fails for reasons other than authentication
    (e.g. server returned a non-200 response or an ``{"error": "..."}`` body).
    """


class DownloadError(TeleStoreError):
    """
    Raised when a file download fails (e.g. the server returns a non-200 response
    or the connection is interrupted).
    """


class FileSizeError(TeleStoreError):
    """
    Raised before the upload request is even made when the source file exceeds
    the maximum allowed size (2 GB).
    """


class FileNotFoundError(TeleStoreError):  # noqa: A001 — intentionally shadows built-in in this namespace
    """
    Raised when the requested ``file_id`` does not exist on the TeleStore server
    (HTTP 404).
    """


class ServerError(TeleStoreError):
    """
    Raised when the TeleStore server returns an HTTP 5xx response, indicating an
    internal server error unrelated to the client request.
    """
