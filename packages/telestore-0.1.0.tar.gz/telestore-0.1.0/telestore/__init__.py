"""
telestore — Python client library for TeleStore.

Exposes :class:`TeleStoreClient` as the primary entry point plus all custom
exception classes and the :class:`UploadedFile` dataclass.

Example::

    from telestore import TeleStoreClient

    client = TeleStoreClient(api_key="sk-...")
    result = client.upload("photo.jpg")
    print(result.view_url)
"""

from .client import TeleStoreClient
from .exceptions import (
    AuthenticationError,
    DownloadError,
    FileSizeError,
    FileNotFoundError,
    ServerError,
    TeleStoreError,
    UploadError,
)
from .models import UploadedFile

__version__ = "0.1.0"

__all__ = [
    "TeleStoreClient",
    "UploadedFile",
    "TeleStoreError",
    "AuthenticationError",
    "UploadError",
    "DownloadError",
    "FileSizeError",
    "FileNotFoundError",
    "ServerError",
]
