"""
Data models returned by the TeleStore client.
"""
from dataclasses import dataclass


@dataclass
class UploadedFile:
    """
    Represents a file that has been successfully uploaded to TeleStore.

    Attributes
    ----------
    file_id:
        Opaque identifier assigned by TeleStore (may be a Telegram ``file_id``
        string or a Telegram ``message_id`` integer stored as a string for
        files larger than 50 MB).  Treat it as a secret — view/download URLs
        are publicly accessible to anyone who knows the ``file_id``.
    view_url:
        URL that serves the file inline (for use in ``<img>``, ``<video>``,
        ``<iframe>``, etc.).  No authentication required.
    download_url:
        URL that serves the file as an attachment (triggers a browser download
        prompt).  No authentication required.
    original_filename:
        The filename that was used when uploading the file.
    size_bytes:
        Size of the uploaded content in bytes.
    mime_type:
        MIME type detected at upload time (e.g. ``"image/jpeg"``,
        ``"application/json"``).
    """

    file_id: str
    view_url: str
    download_url: str
    original_filename: str
    size_bytes: int
    mime_type: str
