import math
import warnings
from abc import ABC, abstractmethod
from dataclasses import dataclass
from enum import IntEnum

import jax
import jax.numpy as jnp
import jax_healpy as jhp
import numpy as np
from astropy.coordinates import SkyCoord
from astropy.wcs import WCS
from jax.tree_util import register_static
from jaxtyping import Array, DTypeLike, Float, Integer, Key, PyTree, ScalarLike, Shaped

from furax.math.quaternion import qrot_zaxis, to_iso_angles
from furax.obs._samplings import Sampling
from furax.obs.stokes import Stokes, ValidStokesType


@register_static
class Landscape(ABC):
    def __init__(self, shape: tuple[int, ...], dtype: DTypeLike = np.float64):
        self.shape = shape
        self.dtype = dtype

    def __len__(self) -> int:
        return math.prod(self.shape)

    @property
    def size(self) -> int:
        return len(self)

    @abstractmethod
    def normal(self, key: Key[Array, '']) -> PyTree[Shaped[Array, '...']]: ...

    @abstractmethod
    def uniform(
        self, key: Key[Array, ''], minval: float = 0.0, maxval: float = 1.0
    ) -> PyTree[Shaped[Array, '...']]: ...

    @abstractmethod
    def full(self, fill_value: ScalarLike) -> PyTree[Shaped[Array, '...']]: ...

    def zeros(self) -> PyTree[Shaped[Array, '...']]:
        return self.full(0)

    def ones(self) -> PyTree[Shaped[Array, '...']]:
        return self.full(1)


@register_static
class StokesLandscape(Landscape):
    """Class representing a multidimensional map of Stokes vectors.

    We assume that integer pixel values fall at the center of pixels (as in the FITS WCS standard,
    see Section 2.1.4 of Greisen et al., 2002, A&A 446, 747).

    Attributes:
        shape: The shape of the array that stores the map values. The dimensions are in the reverse
            order of the FITS NAXIS* keywords. For a 2-dimensional map, the shape corresponds to
            (NAXIS2, NAXIS1) or (:math:`n_\\mathrm{row}`, :math:`n_\\mathrm{col}`), i.e. (:math:`n_y`, :math:`n_x`).
        pixel_shape: The shape in reversed order. For a 2-dimensional map, the shape corresponds to
            (NAXIS1, NAXIS2) or (:math:`n_\\mathrm{col}`, :math:`n_\\mathrm{row}`), i.e. (:math:`n_x`, :math:`n_y`).
        stokes: The identifier for the Stokes vectors (`I`, `QU`, `IQU` or `IQUV`)
        dtype: The data type for the values of the landscape.
    """

    def __init__(
        self,
        shape: tuple[int, ...] | None = None,
        stokes: ValidStokesType = 'IQU',
        dtype: DTypeLike = np.float64,
        pixel_shape: tuple[int, ...] | None = None,
    ):
        if shape is None and pixel_shape is None:
            raise TypeError('The shape is not specified.')
        if shape is not None and pixel_shape is not None:
            raise TypeError('Either the shape or pixel_shape should be specified.')
        shape = shape if pixel_shape is None else pixel_shape[::-1]
        assert shape is not None  # mypy assert
        super().__init__(shape, dtype)
        self.stokes = stokes
        self.pixel_shape = shape[::-1]

    @property
    def size(self) -> int:
        return len(self.stokes) * len(self)

    @property
    def structure(self) -> PyTree[jax.ShapeDtypeStruct]:
        cls = Stokes.class_for(self.stokes)
        return cls.structure_for(self.shape, self.dtype)

    def full(self, fill_value: ScalarLike) -> PyTree[Shaped[Array, ' {self.npixel}']]:
        cls = Stokes.class_for(self.stokes)
        return cls.full(self.shape, fill_value, self.dtype)

    def normal(self, key: Key[Array, '']) -> PyTree[Shaped[Array, ' {self.npixel}']]:
        cls = Stokes.class_for(self.stokes)
        return cls.normal(key, self.shape, self.dtype)

    def uniform(
        self, key: Key[Array, ''], minval: float = 0.0, maxval: float = 1.0
    ) -> PyTree[Shaped[Array, ' {self.npixel}']]:
        cls = Stokes.class_for(self.stokes)
        return cls.uniform(self.shape, key, self.dtype, minval, maxval)

    def get_coverage(self, arg: Sampling) -> Integer[Array, ' {self.npixel}']:
        indices = self.world2index(arg.theta, arg.phi)
        unique_indices, counts = jnp.unique(indices, return_counts=True)
        coverage = jnp.zeros(len(self), dtype=np.int64)
        coverage = coverage.at[unique_indices].add(
            counts, indices_are_sorted=True, unique_indices=True
        )
        return coverage.reshape(self.shape)

    def world2index(
        self, theta: Float[Array, ' *dims'], phi: Float[Array, ' *dims']
    ) -> Integer[Array, ' *dims']:
        pixels = self.world2pixel(theta, phi)
        return self.pixel2index(*pixels)

    @abstractmethod
    def world2pixel(
        self, theta: Float[Array, ' *dims'], phi: Float[Array, ' *dims']
    ) -> tuple[Float[Array, ' *dims'], ...]:
        r"""Converts angles from WCS to pixel coordinates

        Args:
            theta (float): Spherical :math:`\theta` angle.
            phi (float): Spherical :math:`\phi` angle.

        Returns:
            tuple[float, ...]: x, y, z, ... pixel coordinates
        """

    def pixel2index(self, *coords: Float[Array, ' *dims']) -> Integer[Array, ' *ndims']:
        r"""Converts multidimensional pixel coordinates into 1-dimensional indices.

        For a map of shape :math:`(n_y, n_x)`, the indices of the pixels are walked from the
        rightmost dimension :math:`n_x` to the leftmost dimension :math:`n_y` (row-major layout).
        In such a map, the pixel with float coordinates :math:`(p_x, p_y)` has an index
        :math:`i = round(p_x) + n_x round(p_y)`.

        The indices travel from bottom to top, like the Y-coordinates.

        Integer values of the pixel coordinates correspond to the pixel centers. The points
        :math:`(p_x, p_y)` strictly inside a pixel centered on the integer coordinates
        :math:`(i_x, i_y)` verify

            - :math:`i_x - ½ < p_x < i_x + ½`
            - :math:`i_y - ½ < p_y < i_y + ½`

        The convention for pixels and indices is that the first one starts at zero.

        Arguments:
            *coords: The floating-point pixel coordinates along the X, Y, Z, ... axes.

        Returns:
            The 1-dimensional integer indices associated to the pixel coordinates. The data type is
            int32, unless the landscape largest index would overflow, in which case it is int64.
        """
        dtype: DTypeLike
        if len(self) - 1 <= np.iinfo(np.iinfo(np.int32)).max:
            dtype = np.int32
        else:
            dtype = np.int64
        if len(coords) == 0:
            raise TypeError('Pixel coordinates are not specified.')

        stride = self.pixel_shape[0]
        indices = jnp.round(coords[0]).astype(dtype)
        valid = (0 <= indices) & (indices < self.pixel_shape[0])
        for coord, dim in zip(coords[1:], self.pixel_shape[1:]):
            indices_axis = jnp.round(coord).astype(dtype)
            valid &= (0 <= indices_axis) & (indices_axis < dim)
            indices += indices_axis * stride
            stride *= dim
        return jnp.where(valid, indices, -1)

    def quat2pixel(self, quat: Float[Array, '*dims 4']) -> tuple[Float[Array, ' *dims'], ...]:
        """Converts quaternion to floating-point pixel coordinates."""
        theta, phi, _ = to_iso_angles(quat)  # psi not needed
        return self.world2pixel(theta, phi)

    def quat2index(self, quat: Float[Array, '*dims 4']) -> Integer[Array, ' *dims']:
        """Converts quaternion to 1-dimensional pixel indices."""
        return self.pixel2index(*self.quat2pixel(quat))


class ProjectionType(IntEnum):
    """Supported WCS projection types."""

    CAR = 0


@register_static
@dataclass
class WCSProjection:
    """Class that holds basic WCS projection paramters."""

    crpix: tuple[float, float]
    """Reference pixel ``(crpix_x, crpix_y)`` in 1-indexed FITS convention."""
    crval: tuple[float, float]
    """Reference coordinate ``(lon_deg, lat_deg)`` in degrees."""
    cdelt: tuple[float, float]
    """Pixel scale ``(cdelt_x_deg, cdelt_y_deg)`` in degrees per pixel."""
    type: ProjectionType = ProjectionType.CAR
    """Projection type (only CAR is supported for now)."""

    def __post_init__(self) -> None:
        if self.cdelt[0] > 0:
            warnings.warn(
                f'cdelt_ra = {self.cdelt[0]} is positive; FITS convention requires cdelt_ra < 0'
                ' (RA decreases left-to-right).',
                UserWarning,
                stacklevel=2,
            )

    @classmethod
    def from_astropy(cls, wcs: WCS) -> 'WCSProjection':
        """Extract a WCSProjection from an astropy WCS object."""
        projection = ProjectionType[wcs.wcs.ctype[0].split('-')[-1]]
        return cls(
            crpix=(float(wcs.wcs.crpix[0]), float(wcs.wcs.crpix[1])),
            crval=(float(wcs.wcs.crval[0]), float(wcs.wcs.crval[1])),
            cdelt=(float(wcs.wcs.cdelt[0]), float(wcs.wcs.cdelt[1])),
            type=projection,
        )


@register_static
class WCSLandscape(StokesLandscape):
    """Base class for WCS-projected Stokes landscapes."""

    def __init__(
        self,
        shape: tuple[int, int],
        projection: WCSProjection,
        stokes: ValidStokesType = 'IQU',
        dtype: DTypeLike = np.float64,
    ) -> None:
        super().__init__(shape, stokes, dtype)
        self.projection = projection

    @property
    def crpix(self) -> tuple[float, float]:
        return self.projection.crpix

    @property
    def crval(self) -> tuple[float, float]:
        return self.projection.crval

    @property
    def cdelt(self) -> tuple[float, float]:
        return self.projection.cdelt

    def to_wcs(self) -> WCS:
        """Reconstruct an astropy WCS object from the stored projection parameters."""
        proj = self.projection.type.name
        wcs = WCS(naxis=2)
        wcs.wcs.ctype = [f'RA---{proj}', f'DEC--{proj}']
        wcs.wcs.crpix = list(self.crpix)
        wcs.wcs.crval = list(self.crval)
        wcs.wcs.cdelt = list(self.cdelt)
        wcs.wcs.set()
        return wcs

    @classmethod
    def class_for(cls, projection_type: ProjectionType) -> type['WCSLandscape']:
        """Return the WCSLandscape subclass for the given projection type."""
        if projection_type == ProjectionType.CAR:
            return CARLandscape
        raise ValueError(f'Unsupported projection type: {projection_type!r}')

    @classmethod
    def from_wcs(
        cls,
        shape: tuple[int, int],
        wcs: WCS,
        stokes: ValidStokesType = 'IQU',
        dtype: DTypeLike = np.float64,
    ) -> 'WCSLandscape':
        """Create a WCSLandscape subclass instance from an astropy WCS object.

        Dispatches to the appropriate subclass based on the projection type.
        """
        projection = WCSProjection.from_astropy(wcs)
        return cls.class_for(projection.type)(shape, projection, stokes, dtype)


@register_static
class CARLandscape(WCSLandscape):
    r"""Class representing a CAR (Plate Carrée) projected map of Stokes vectors.

    CAR maps native coordinates linearly to the projection plane (``x = φ, y = θ``).
    Requiring ``phi_0 = 0`` aligns the native and celestial equators, reducing the
    celestial-to-native rotation to a pure RA shift and making the full world-to-pixel
    mapping linear in ``(RA, Dec)``:

    .. math::

        p_x = \frac{\Delta\lambda}{\delta_x} + (c_x - 1)

        p_y = \frac{\phi}{\delta_y} + (c_y - 1)

    where :math:`\Delta\lambda = ((\lambda - \lambda_0 + 180) \bmod 360) - 180` handles
    the 0°/360° RA wrap, :math:`(\lambda_0, 0.0)` is ``crval``, :math:`(\delta_x, \delta_y)`
    is ``cdelt`` in degrees, and :math:`(c_x, c_y)` is ``crpix`` (1-indexed FITS convention).
    """

    def __init__(
        self,
        shape: tuple[int, int],
        projection: WCSProjection,
        stokes: ValidStokesType = 'IQU',
        dtype: DTypeLike = np.float64,
    ) -> None:
        if projection.crval[1] != 0.0:
            msg = (
                f'CAR projection requires crval_dec = 0 (native and celestial equators must'
                f' coincide), got {projection.crval[1]}'
            )
            raise ValueError(msg)
        super().__init__(shape, projection, stokes, dtype)

    @jax.jit
    def world2pixel(
        self, theta: Float[Array, ' *dims'], phi: Float[Array, ' *dims']
    ) -> tuple[Float[Array, ' *dims'], Float[Array, ' *dims']]:
        r"""Convert spherical angles to CAR pixel coordinates in pure JAX.

        Args:
            theta (float): Spherical :math:`\theta` angle (co-latitude, 0 at north pole).
            phi (float): Spherical :math:`\phi` angle (longitude).

        Returns:
            Pixel coordinate pair ``(pix_x, pix_y)`` as float arrays.
        """
        lon_deg = jnp.degrees(phi)
        lat_deg = jnp.degrees(jnp.pi / 2 - theta)
        lon_diff = ((lon_deg - self.crval[0]) + 180) % 360 - 180
        pix_x = lon_diff / self.cdelt[0] + (self.crpix[0] - 1)
        pix_y = lat_deg / self.cdelt[1] + (self.crpix[1] - 1)
        return pix_x, pix_y


@register_static
class HealpixLandscape(StokesLandscape):
    """Class representing a Healpix-projected map of Stokes vectors."""

    def __init__(
        self, nside: int, stokes: ValidStokesType = 'IQU', dtype: DTypeLike = np.float64
    ) -> None:
        shape = (12 * nside**2,)
        super().__init__(shape, stokes, dtype)
        self.nside = nside

    @jax.jit
    def quat2index(self, quat: Float[Array, '*dims 4']) -> Integer[Array, ' *dims']:
        r"""Convert quaternion to HEALPix index in ring ordering.

        Args:
            quat (float): Quaternion.

        Returns:
            int: HEALPix map index for ring ordering scheme.
        """
        # we want the 3 dimensions on the left
        vec = jnp.moveaxis(qrot_zaxis(quat), -1, 0)
        pix: Integer[Array, ' *dims'] = jhp.vec2pix(self.nside, *vec)
        return pix

    @jax.jit
    def world2pixel(
        self, theta: Float[Array, ' *dims'], phi: Float[Array, ' *dims']
    ) -> tuple[Integer[Array, ' *dims'], ...]:
        r"""Convert angles to HEALPix index for HEALPix ring ordering scheme.

        Args:
            theta (float): Spherical :math:`\theta` angle.
            phi (float): Spherical :math:`\phi` angle.

        Returns:
            int: HEALPix map index for ring ordering scheme.
        """
        return (jhp.ang2pix(self.nside, theta, phi),)


@register_static
class FrequencyLandscape(HealpixLandscape):
    def __init__(
        self,
        nside: int,
        frequencies: Array,
        stokes: ValidStokesType = 'IQU',
        dtype: DTypeLike = np.float64,
    ):
        super().__init__(nside, stokes, dtype)
        self.frequencies = frequencies
        self.shape = (len(frequencies), 12 * nside**2)


@register_static
class AstropyWCSLandscape(StokesLandscape):
    """Class representing an astropy WCS map of Stokes vectors."""

    def __init__(
        self,
        shape: tuple[int, ...],
        wcs: WCS,
        stokes: ValidStokesType = 'IQU',
        dtype: DTypeLike = np.float64,
    ) -> None:
        super().__init__(shape, stokes, dtype)
        self.wcs = wcs

    @jax.jit
    def world2pixel(
        self, theta: Float[Array, ' *dims'], phi: Float[Array, ' *dims']
    ) -> tuple[Float[Array, ' *dims'], Float[Array, ' *dims']]:
        r"""Convert angles to WCS map indices.

        Args:
            theta (float): Spherical :math:`\theta` angle.
            phi (float): Spherical :math:`\phi` angle.

        Returns:
            WCS map index pairs
        """

        def f(theta, phi):  # type: ignore[no-untyped-def]
            # SkyCoord takes (lon,lat)
            pix_i, pix_j = self.wcs.world_to_pixel(SkyCoord(phi, (np.pi / 2 - theta), unit='rad'))
            return np.array(pix_i), np.array(pix_j)

        struct = jax.ShapeDtypeStruct(theta.shape, theta.dtype)
        result_shape = (struct, struct)

        return jax.pure_callback(f, result_shape, theta, phi)  # type: ignore[no-any-return]


@register_static
class HorizonLandscape(StokesLandscape):
    """Class representing a map of Stokes vectors in horizon (ground) coordinates.
    Contains two axes:
        AXIS1: altitude (elevation) in radians
        AXIS2: azimuth in radians
    """

    def __init__(
        self,
        shape: tuple[int, ...],
        altitude_limits: tuple[Array, Array],
        azimuth_limits: tuple[Array, Array],
        stokes: ValidStokesType = 'IQU',
        dtype: DTypeLike = np.float64,
    ) -> None:
        super().__init__(shape, stokes, dtype)
        self.altitude_limits = altitude_limits
        self.azimuth_limits = azimuth_limits

    def bin_edges(self) -> tuple[Float[Array, ' bins+1'], Float[Array, ' bins+1']]:
        """Return the bin edges of the map."""
        alt_min, alt_max = self.altitude_limits
        az_min, az_max = self.azimuth_limits
        n_az, n_alt = self.shape
        return jnp.linspace(alt_min, alt_max, n_alt + 1), jnp.linspace(az_min, az_max, n_az + 1)

    def bin_centers(self) -> tuple[Float[Array, ' bins'], Float[Array, ' bins']]:
        """Return the bin centers of the map."""
        alt_edges, az_edges = self.bin_edges()
        alt_centers = 0.5 * (alt_edges[:-1] + alt_edges[1:])
        az_centers = 0.5 * (az_edges[:-1] + az_edges[1:])
        return alt_centers, az_centers

    @jax.jit
    def world2pixel(
        self, theta: Float[Array, ' *dims'], phi: Float[Array, ' *dims']
    ) -> tuple[Integer[Array, ' *dims'], Integer[Array, ' *dims']]:
        r"""Convert angles in radians to Horizon map indices.

        Args:
            theta (float): Spherical :math:`\theta` angle = pi/2 - altitude.
            phi (float): Spherical :math:`\phi` angle = -azimuth.

        Returns:
            Ground map index pairs
        """
        alt_min, alt_max = self.altitude_limits
        az_min, az_max = self.azimuth_limits
        n_az, n_alt = self.shape  # Note self.shape has reverse order: [AXIS2, AXIS1]
        dalt = (alt_max - alt_min) / n_alt
        daz = (az_max - az_min) / n_az

        altitude = jnp.pi / 2 - theta
        azimuth = -phi

        pix_i = jnp.round((altitude - alt_min) / dalt - 0.5).astype(jnp.int64)
        pix_j = jnp.round(((azimuth - az_min) % (2 * jnp.pi)) / daz - 0.5).astype(jnp.int64)

        return pix_i, pix_j
