# main.py


from configurator.cli.commands import main

if __name__ == "__main__":
    main()
