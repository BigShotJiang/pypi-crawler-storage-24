# NOTICE

## Trademarks and non-affiliation

Hunter Douglas® and PowerRise® (and any other Hunter Douglas product or service names) are trademarks and/or registered trademarks of Hunter Douglas.

This software is an independent, unofficial project. No claim is made to any Hunter Douglas trademarks, and use of such marks is for descriptive and compatibility purposes only.

Hunter Douglas is not affiliated with, has not endorsed, and is not involved in the development, distribution, or support of this software.

## AI-assisted development

AI coding tools were used to assist in creating and maintaining portions of this software. All outputs were reviewed and integrated by the project maintainers.

## Acknowledgements

This project was inspired by prior community work. In particular:

- Sander Teunissen’s `aio-powerview-api` project, which provided valuable inspiration and reference patterns:
  https://github.com/sander76/aio-powerview-api
- Schwark Satyavolu’s `smartthings-hunterdouglasplatinum` project, which helped inform protocol behavior and integration approaches:
  https://github.com/schwark/smartthings-hunterdouglasplatinum
