"""Protocol parser for Hunter Douglas PowerRise Platinum.

Parses the line-based text protocol returned by the hub.
Each line starts with a $ prefix identifying the data type.

Wire format examples (from $dat response):
  $cr01-02-------Living Room        (room: index=01, brand=02, name after offset 16)
  $cs03-01-00---Shade Name          (shade: index=03, room=01, group=00, name)
  $cm00-----Scene Name              (scene: index=00, name after offset 6)
  $cp01-04-128-                     (position: shade=01, feature=04, pos=128)
  $cq00-03-01-                      (scene link: scene=00, shade=03, linked=01)
  $cx00-01-04-128-                  (scene room pos: scene=00, room=01, cmd=04, pos=128)
  $ct-----House Name                (title)
  $ca...                            (timed event)
  $firm00-0018                      (firmware)
  $LEDl128-                         (LED brightness)
  $upd01-...                        (end of data)
"""

from __future__ import annotations

import logging
from typing import Any

from aiopowerrise.const import (
    RESP_DONE,
    RESP_ERROR,
    RESP_FIRMWARE,
    RESP_LED_BRIGHTNESS,
    RESP_ROOM,
    RESP_SCENE,
    RESP_SCENE_LINK,
    RESP_SCENE_ROOM_POS,
    RESP_SHADE,
    RESP_SHADE_POSITION,
    RESP_TIMED_EVENT,
    RESP_TITLE,
    RESP_UPDATE,
    END_SENTINELS,
)
from aiopowerrise.exceptions import HunterDouglasError, ParseError
from aiopowerrise.models import (
    Bridge,
    House,
    Room,
    Scene,
    SceneLink,
    SceneRoomPosition,
    Shade,
    TimedEvent,
)

_LOGGER = logging.getLogger(__name__)


def parse_all_data(lines: list[str]) -> House:
    """Parse the full $dat response into a House object.

    Args:
        lines: List of text lines received from the hub after sending $dat.

    Returns:
        House object with all parsed data.
    """
    house = House()
    bridge = Bridge()

    rooms_list: list[Room] = []
    shades_list: list[Shade] = []
    scenes_list: list[Scene] = []
    timed_events: list[TimedEvent] = []
    is_update_section = False

    for line in lines:
        line = line.strip()
        if not line:
            continue

        try:
            # Check for end sentinel
            if _is_end_sentinel(line):
                break

            # LED brightness
            if RESP_LED_BRIGHTNESS in line:
                bridge.led_brightness_bits = _parse_led_brightness(line)
                continue

            # Firmware
            if RESP_FIRMWARE in line:
                bridge.firmware_version = _parse_firmware(line)
                continue

            # Update section marker - data starts after $upd00-
            if "$upd00-" in line:
                is_update_section = True
                continue

            if not is_update_section:
                continue

            # Room
            if RESP_ROOM in line and RESP_SCENE_ROOM_POS not in line:
                room = parse_room(line)
                if room:
                    rooms_list.append(room)
                continue

            # Shade (but not shade position)
            if RESP_SHADE in line and RESP_SHADE_POSITION not in line:
                shade = parse_shade(line, rooms_list)
                if shade:
                    shades_list.append(shade)
                continue

            # Title
            if RESP_TITLE in line:
                house.name = _parse_title(line)
                continue

            # Scene
            if RESP_SCENE in line and RESP_SCENE_LINK not in line and RESP_SCENE_ROOM_POS not in line:
                scene = parse_scene(line)
                if scene:
                    scenes_list.append(scene)
                continue

            # Timed event
            if RESP_TIMED_EVENT in line:
                event = parse_timed_event(line, scenes_list)
                if event:
                    timed_events.append(event)
                continue

            # Scene link
            if RESP_SCENE_LINK in line:
                _parse_scene_link(line, shades_list, scenes_list)
                continue

            # Scene room position
            if RESP_SCENE_ROOM_POS in line:
                _parse_scene_room_position(line, scenes_list, rooms_list)
                continue

            # Shade position
            if RESP_SHADE_POSITION in line:
                _parse_shade_position(line, shades_list)
                continue

        except (ValueError, IndexError) as exc:
            _LOGGER.warning("Failed to parse line '%s': %s", line, exc)
            continue

    # Build indexed dicts
    house.bridge = bridge
    house.rooms = {room.id: room for room in rooms_list}
    house.shades = {shade.id: shade for shade in shades_list}
    house.scenes = {scene.id: scene for scene in scenes_list}
    house.timed_events = timed_events

    # Associate shades with rooms; stamp tilt capability onto each shade
    for shade in shades_list:
        if shade.room_id in house.rooms:
            room = house.rooms[shade.room_id]
            room.shades.append(shade.id)
            shade.supports_tilt = room.supports_tilt
            shade.supports_tilt_reverse = room.supports_tilt_reverse

    _LOGGER.debug(
        "Parsed house: %d rooms, %d shades, %d scenes",
        len(house.rooms),
        len(house.shades),
        len(house.scenes),
    )
    return house


def _is_end_sentinel(line: str) -> bool:
    """Check if a line is an end-of-data sentinel."""
    for sentinel in END_SENTINELS:
        if sentinel in line:
            return True
    return False


def parse_room(data: str) -> Room | None:
    """Parse a room line.

    Format: $crII-BB--------Name
    Where II = 2-digit index (offset 3-5)
          BB = 2-digit brand index (offset 6-8)
          Name starts at offset 16

    The Room.brand_name, Room.shade_type, Room.supports_tilt and
    Room.supports_secondary_position properties are derived automatically
    from brand_index via BRAND_MAP / BRAND_SHADE_TYPE_MAP in const.py.
    """
    try:
        # Find the $cr prefix and work from there
        idx = data.rfind(RESP_ROOM)
        s = data[idx:]

        room = Room()
        room.id = int(s[3:5])
        room.brand_index = int(s[6:8])
        room.name = s[16:].strip() if len(s) > 16 else ""
        _LOGGER.debug(
            "Parsed room %d '%s': brand_index=%d (%s)",
            room.id,
            room.name,
            room.brand_index,
            room.brand_name,
        )
        return room
    except (ValueError, IndexError) as exc:
        _LOGGER.warning("Failed to parse room: '%s' - %s", data, exc)
        return None


def parse_shade(data: str, rooms: list[Room]) -> Shade | None:
    """Parse a shade line.

    Format: $csII-RR-GG---Name
    Where II = shade index (offset 3-5)
          RR = room index (offset 6-8)
          GG = group number (offset 9-11)
          Name follows after separator
    """
    try:
        idx = data.rfind(RESP_SHADE)
        s = data[idx:]

        shade = Shade()
        shade.id = int(s[3:5])
        shade.room_id = int(s[6:8])

        # Group number if present
        if len(s) > 11:
            try:
                shade.group_number = int(s[9:11])
            except ValueError:
                shade.group_number = 0

        # Name - find after the last '-' in the header section
        # The name is typically after offset ~12-15, following separator dashes
        name_part = s[9:]  # everything after room index
        dash_idx = name_part.find("-")
        if dash_idx >= 0:
            name_candidate = name_part[dash_idx + 1:]
            # Strip leading dashes and digits that are part of the format
            while name_candidate and name_candidate[0] == "-":
                name_candidate = name_candidate[1:]
            shade.name = name_candidate.strip()
        else:
            shade.name = name_part.strip()

        return shade
    except (ValueError, IndexError) as exc:
        _LOGGER.warning("Failed to parse shade: '%s' - %s", data, exc)
        return None


def parse_scene(data: str) -> Scene | None:
    """Parse a scene line.

    Format: $cmII-----Name
    Where II = scene index (offset 3-5)
          Name starts at offset 6
    """
    if not data or len(data.strip()) == 0:
        return None
    try:
        idx = data.rfind(RESP_SCENE)
        s = data[idx:]

        scene = Scene()
        scene.id = int(s[3:5])
        raw_name = s[6:] if len(s) > 6 else ""
        # Strip leading dashes from name (format: $cmII-----Name)
        scene.name = raw_name.lstrip("-").strip()
        return scene
    except (ValueError, IndexError) as exc:
        _LOGGER.warning("Failed to parse scene: '%s' - %s", data, exc)
        return None


def parse_timed_event(data: str, scenes: list[Scene]) -> TimedEvent | None:
    """Parse a timed event line.

    Format: $caII-HH-MM-DD-EE-
    Where II = scene index
          HH = hour
          MM = minute
          DD = day bits
          EE = enabled flag
    """
    try:
        idx = data.rfind(RESP_TIMED_EVENT)
        s = data[idx:]

        event = TimedEvent()
        event.scene_index = int(s[3:5])
        event.hour = int(s[6:8])
        event.minute = int(s[9:11])
        event.day_bits = int(s[12:14])
        event.enabled = s[15:17].strip() != "00" if len(s) > 17 else False
        return event
    except (ValueError, IndexError) as exc:
        _LOGGER.warning("Failed to parse timed event: '%s' - %s", data, exc)
        return None


def _parse_shade_position(data: str, shades: list[Shade]) -> None:
    """Parse a shade position line and update the shade.

    Format: $cpII-CC-PPP-
    Where II = shade index (offset 3-5)
          CC = command/feature (offset 6-8)  – "04" = shade, "07" = tilt,
               "19" = reverse tilt (Luminette)
          PPP = position value (offset 9-12)

    Position is stored in two separate fields on :class:`Shade` so that a
    tilt update never overwrites the primary position and vice versa:
    * feature 04         → ``shade.position``
    * feature 07 or 19   → ``shade.tilt_position``
    """
    try:
        idx = data.rfind(RESP_SHADE_POSITION)
        s = data[idx:]

        shade_index = int(s[3:5])
        command = int(s[6:8])
        position = int(s[9:12])

        for shade in shades:
            if shade.id == shade_index:
                if command in (7, 19):  # FEATURE_TILT / FEATURE_TILT_REVERSE
                    # Tilt implies the hardware has closed the shade first;
                    # zero the primary position to reflect that.
                    shade.position = 0
                    shade.tilt_position = position
                    shade.tilt_command = command
                else:
                    # Primary shade movement (04, 10, 12, …);
                    # clear any tilt that was previously active.
                    shade.tilt_position = 0
                    shade.tilt_command = 7
                    shade.position = position
                break
    except (ValueError, IndexError) as exc:
        _LOGGER.warning("Failed to parse shade position: '%s' - %s", data, exc)


def _parse_scene_link(
    data: str, shades: list[Shade], scenes: list[Scene]
) -> SceneLink | None:
    """Parse a scene link line.

    Format: $cqSS-HH-LL-
    Where SS = scene index (offset 3-5)
          HH = shade index (offset 6-8)
          LL = linked status (offset 9-12, "00" = not linked)
    """
    try:
        idx = data.rfind(RESP_SCENE_LINK)
        s = data[idx:]

        scene_index_str = s[3:5]
        shade_index_str = s[6:8]
        is_linked_str = s[9:12].strip().replace("-", "")

        scene_index = int(scene_index_str)
        shade_index = int(shade_index_str)
        is_linked = is_linked_str != "00"

        link = SceneLink(shade_id=shade_index, is_linked=is_linked)

        # Add to scene
        if scene_index < len(scenes):
            scene = scenes[scene_index]
            # Check if link already exists
            existing = [lnk for lnk in scene.links if lnk.shade_id == shade_index]
            if existing:
                existing[0].is_linked = is_linked
            elif is_linked:
                scene.links.append(link)

        return link
    except (ValueError, IndexError) as exc:
        _LOGGER.warning("Failed to parse scene link: '%s' - %s", data, exc)
        return None


def _parse_scene_room_position(
    data: str, scenes: list[Scene], rooms: list[Room]
) -> None:
    """Parse a scene room position line.

    Format: $cxSS-RR-CC-PPP-
    Where SS = scene index (offset 3-5)
          RR = room index (offset 6-8)
          CC = command (offset 9-11)
          PPP = position (offset 12-15)
    """
    try:
        idx = data.rfind(RESP_SCENE_ROOM_POS)
        s = data[idx:]

        scene_index = int(s[3:5])
        room_index = int(s[6:8])
        command_str = s[9:11]
        position = int(s[12:15])

        srp = SceneRoomPosition(
            room_id=room_index,
            scene_index=scene_index,
            command=command_str,
            position=position,
        )

        if scene_index < len(scenes):
            scenes[scene_index].room_positions.append(srp)
    except (ValueError, IndexError) as exc:
        _LOGGER.warning("Failed to parse scene room position: '%s' - %s", data, exc)


def _parse_title(data: str) -> str:
    """Parse the house title from a $ct line."""
    idx = data.rfind(RESP_TITLE)
    s = data[idx:]
    # Title starts after a header section, typically at offset ~8+
    # From smali: the title parsing extracts name after fixed prefix
    # We'll extract everything after "$ct" + some padding
    # Simple approach: skip "$ct" and strip dashes
    raw = s[3:]
    # Strip leading dashes and digits
    while raw and (raw[0] == "-" or raw[0].isdigit()):
        raw = raw[1:]
    return raw.strip()


def _parse_led_brightness(data: str) -> int:
    """Parse LED brightness from a $LEDl line."""
    idx = data.rfind(RESP_LED_BRIGHTNESS)
    s = data[idx:]
    # Format: $LEDlNNN- where NNN is the brightness value
    value_str = s[5:]
    # Strip trailing dash/newline
    value_str = value_str.rstrip("-").rstrip()
    return int(value_str)


def _parse_firmware(data: str) -> int:
    """Parse firmware version from a $firm line."""
    idx = data.rfind(RESP_FIRMWARE)
    s = data[idx:]
    # Format: $firmXX-YYYY where YYYY at offset 8-12 is the version
    return int(s[8:12])


def get_command_line(lines: list[str], command: str) -> str | None:
    """Find the first line containing the given command prefix.

    Raises HunterDouglasError if an error response is found.
    """
    for line in lines:
        line = line.strip()
        if not line:
            continue
        if RESP_ERROR in line:
            error_code = _find_error_type(line)
            raise HunterDouglasError(error_code)
        if command in line:
            return line
    return None


def _find_error_type(error_line: str) -> str:
    """Extract error code from an error line."""
    for code in ("09", "08", "07", "06", "05", "04", "03", "02", "01", "00"):
        if code in error_line:
            return code
    return "00"


def parse_line(line: str, house: "House") -> str | None:  # noqa: F821
    """Parse a single unsolicited line from the hub and update *house* in-place.

    Returns a short description string of what changed (useful for logging
    and CLI output), or ``None`` if the line was not recognised / not parsed.

    Designed to be called from the background listener callback.
    """
    from aiopowerrise.models import House  # local import to avoid circular

    line = line.strip()
    if not line:
        return None

    shades_list = list(house.shades.values())
    scenes_list = list(house.scenes.values())
    rooms_list = list(house.rooms.values())

    # Shade position update: $cpII-CC-PPP-
    if RESP_SHADE_POSITION in line and RESP_SCENE_ROOM_POS not in line:
        _parse_shade_position(line, shades_list)
        try:
            idx_s = line.rfind(RESP_SHADE_POSITION)
            s = line[idx_s:]
            shade_id = int(s[3:5])
            command = int(s[6:8])
            shade = house.shades.get(shade_id)
            if shade:
                if command in (7, 19):  # tilt / reverse tilt
                    return (
                        f"shade {shade_id} ({shade.name}) "
                        f"tilt={shade.tilt_percent}% (wire={shade.tilt_position})"
                    )
                return (
                    f"shade {shade_id} ({shade.name}) "
                    f"position={shade.position_percent}% (wire={shade.position})"
                )
        except (ValueError, IndexError):
            pass
        return f"shade position update: {line}"

    # Room update
    if RESP_ROOM in line and RESP_SCENE_ROOM_POS not in line:
        room = parse_room(line)
        if room:
            house.rooms[room.id] = room
            return f"room {room.id} ({room.name}) updated"

    # Scene link update
    if RESP_SCENE_LINK in line:
        _parse_scene_link(line, shades_list, scenes_list)
        return f"scene link update: {line}"

    # Scene room position update
    if RESP_SCENE_ROOM_POS in line:
        _parse_scene_room_position(line, scenes_list, rooms_list)
        return f"scene room position update: {line}"

    # Firmware update notification
    if RESP_FIRMWARE in line:
        house.bridge.firmware_version = _parse_firmware(line)
        return f"firmware version updated: {house.bridge.firmware_version}"

    # LED brightness update
    if RESP_LED_BRIGHTNESS in line:
        house.bridge.led_brightness_bits = _parse_led_brightness(line)
        return f"LED brightness updated: {house.bridge.led_brightness_bits}"

    return None
