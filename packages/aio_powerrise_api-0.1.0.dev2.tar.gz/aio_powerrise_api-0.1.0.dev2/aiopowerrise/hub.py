"""Hub class for Hunter Douglas PowerRise Platinum.

This is the main entry point for the library, analogous to the Hub class
in aio-powerview-api.  It manages the connection to the bridge and provides
access to shades, scenes, and rooms.
"""

from __future__ import annotations

import asyncio
import contextlib
import logging
from collections.abc import Callable
from typing import Any

from aiopowerrise.const import CMD_DUMMY, CMD_GET_DATA, DEFAULT_PORT, RESP_ACK, RESP_ROOM, RESP_SHADE_POSITION
from aiopowerrise.models import House, Shade
from aiopowerrise.protocol import parse_all_data, parse_line
from aiopowerrise.resources import Shades
from aiopowerrise.resources.rooms import Rooms
from aiopowerrise.resources.scenes import Scenes
from aiopowerrise.transport import Transport

_LOGGER = logging.getLogger(__name__)


class Hub:
    """PowerRise Platinum Hub.

    Provides the top-level API for communicating with the hub.

    Usage:
        hub = Hub("192.168.1.100")
        await hub.connect()
        house = await hub.get_data()
        await hub.shades.move(shade_id=1, position=50)
        await hub.scenes.activate(scene_id=0)
        await hub.close()
    """

    def __init__(self, host: str, port: int = DEFAULT_PORT) -> None:
        """Initialize the hub.

        Args:
            host: IP address or hostname of the hub.
            port: TCP port (default 522).
        """
        self._transport = Transport(host, port)
        self._shades = Shades(self._transport)
        self._scenes = Scenes(self._transport)
        self._rooms = Rooms(self._transport)
        self._house: House | None = None
        # Callbacks registered via add_listener()
        self._listeners: list[Callable[[str, Any], None]] = []

    @property
    def host(self) -> str:
        """Return the hub host address."""
        return self._transport.host

    @property
    def port(self) -> int:
        """Return the hub port."""
        return self._transport.port

    @property
    def connected(self) -> bool:
        """Return True if connected to the hub."""
        return self._transport.connected

    @property
    def shades(self) -> Shades:
        """Return the Shades resource manager."""
        return self._shades

    @property
    def scenes(self) -> Scenes:
        """Return the Scenes resource manager."""
        return self._scenes

    @property
    def rooms(self) -> Rooms:
        """Return the Rooms resource manager."""
        return self._rooms

    @property
    def house(self) -> House | None:
        """Return the last retrieved House data."""
        return self._house

    @property
    def name(self) -> str | None:
        """Return the house name if data has been fetched."""
        return self._house.name if self._house else None

    @property
    def firmware_version(self) -> int | None:
        """Return the bridge firmware version if data has been fetched."""
        if self._house and self._house.bridge:
            return self._house.bridge.firmware_version
        return None

    async def connect(self) -> None:
        """Connect to the hub and fetch initial state.

        Opens the TCP connection, starts keep-alive, and immediately fetches
        all hub data via ``$dat`` so that :attr:`house` is populated before
        any caller needs it.  This is the only time ``$dat`` should be sent
        under normal operation; subsequent state updates arrive as unsolicited
        push lines from the hub.

        Also registers an internal disconnect callback so that if the
        connection drops unexpectedly the hub will reconnect and re-fetch
        state automatically.
        """
        await self._transport.connect()
        self._transport.start_keepalive()
        self._transport.set_disconnect_callback(self._on_disconnect)
        self._transport.set_reconnect_callback(self.get_data)
        _LOGGER.info("Hub connected at %s:%d", self.host, self.port)
        await self.get_data()

    async def _reconnect_and_refresh(self) -> None:
        """Reconnect to the hub and re-fetch state after an unexpected disconnect."""
        if self._transport.connected:
            return  # already reconnected
        try:
            await self._transport.reconnect()
            self._transport.set_disconnect_callback(self._on_disconnect)
            self._transport.set_reconnect_callback(self.get_data)
            _LOGGER.info("Hub reconnected at %s:%d", self.host, self.port)
            await self.get_data()
        except Exception:
            _LOGGER.exception("Hub reconnect failed")

    def _on_disconnect(self) -> None:
        """Called by Transport when the connection is unexpectedly lost."""
        if self._transport.connected:
            return  # already reconnected by a command
        _LOGGER.warning("Hub connection lost — scheduling reconnect")
        asyncio.get_running_loop().create_task(self._reconnect_and_refresh())

    async def close(self) -> None:
        """Close the connection to the hub."""
        self.stop_listening()
        await self._transport.close()
        _LOGGER.info("Hub connection closed")

    # ------------------------------------------------------------------
    # Listener / live-state API
    # ------------------------------------------------------------------

    def add_listener(self, callback: Callable[[str, Any], None]) -> Callable[[], None]:
        """Register a callback for live hub updates.

        The callback is called with ``(event_type, data)`` where:

        * ``event_type`` is a string like ``"shade"`` or ``"room"``.
        * ``data`` is the updated model object (e.g. a :class:`Shade`).

        Returns a *remove* callable; call it to unregister.

        Example::

            def on_update(event_type, data):
                print(f"{event_type} updated: {data}")

            remove = hub.add_listener(on_update)
            # … later …
            remove()
        """
        self._listeners.append(callback)

        def _remove() -> None:
            with contextlib.suppress(ValueError):
                self._listeners.remove(callback)

        return _remove

    def start_listening(self) -> None:
        """Start the background listener and live state updates.

        Must be called after :meth:`connect`.  The hub will continuously
        read unsolicited lines from the hub, update ``hub.house`` in-place
        and fire registered listeners.

        It is safe to call :meth:`get_data` while listening; the listener
        will yield while commands are active.
        """
        self._transport.set_line_callback(self._on_line)
        self._transport.start_listener()
        _LOGGER.debug("Hub listener started")

    def stop_listening(self) -> None:
        """Stop the background listener."""
        self._transport.set_line_callback(None)
        _LOGGER.debug("Hub listener stopped")

    def set_disconnect_callback(self, callback: Any | None) -> None:
        """Register a callback invoked when the connection is unexpectedly lost.

        The callback is called with no arguments from the reader loop task when
        the TCP connection drops (EOF or OSError).  It is NOT called on a clean
        :meth:`close`.  Use this to schedule a reconnect.
        """
        self._transport.set_disconnect_callback(callback)

    def _on_line(self, line: str) -> None:
        """Called by Transport for every unsolicited line."""
        house = self._house
        if house is None:
            return  # No data yet; ignore unsolicited lines

        description = parse_line(line, house)
        if description is None:
            return  # Line not recognised

        _LOGGER.debug("Live update: %s", description)

        # Fire registered listeners with typed event data
        if not self._listeners:
            return

        # Determine event type and payload
        if RESP_SHADE_POSITION in line:
            try:
                idx = line.rfind(RESP_SHADE_POSITION)
                shade_id = int(line[idx + 3 : idx + 5])
                shade = house.shades.get(shade_id)
                if shade:
                    self._fire_listeners("shade", shade)
            except (ValueError, IndexError):
                pass
        elif RESP_ROOM in line:
            try:
                idx = line.rfind(RESP_ROOM)
                room_id = int(line[idx + 3 : idx + 5])
                room = house.rooms.get(room_id)
                if room:
                    self._fire_listeners("room", room)
            except (ValueError, IndexError):
                pass
        else:
            # Generic update
            self._fire_listeners("update", line)

    def _fire_listeners(self, event_type: str, data: Any) -> None:
        """Invoke all registered listeners."""
        for cb in list(self._listeners):
            try:
                cb(event_type, data)
            except Exception:  # noqa: BLE001
                _LOGGER.exception("Error in hub listener callback")

    async def get_data(self) -> House:
        """Retrieve all data from the hub.

        Sends the $dat command and parses the full response into a House
        object containing rooms, shades, scenes, etc.

        Returns:
            House object with all parsed data.
        """
        lines = await self._transport.send_command(CMD_GET_DATA, sentinel="$upd01-", timeout=30.0)
        self._house = parse_all_data(lines)
        _LOGGER.info(
            "Retrieved data: %d rooms, %d shades, %d scenes",
            len(self._house.rooms),
            len(self._house.shades),
            len(self._house.scenes),
        )
        return self._house

    async def ping(self) -> bool:
        """Send a keep-alive ping to the hub.

        Returns:
            True if the hub responded.
        """
        try:
            lines = await self._transport.send_command(CMD_DUMMY, sentinel=RESP_ACK, timeout=5.0)
            return len(lines) > 0
        except Exception:  # noqa: BLE001
            return False

    async def __aenter__(self) -> Hub:
        """Async context manager entry."""
        await self.connect()
        return self

    async def __aexit__(self, *args: Any) -> None:
        """Async context manager exit."""
        await self.close()
