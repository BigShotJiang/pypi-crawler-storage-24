"""Exceptions for Hunter Douglas PowerRise Platinum."""


class PowerRiseError(Exception):
    """Base exception for PowerRise errors."""


class PowerRiseConnectionError(PowerRiseError):
    """Raised when the connection to the hub fails."""


# Backwards-compatible alias
ConnectionError = PowerRiseConnectionError


class CommandError(PowerRiseError):
    """Raised when a command fails."""


class HunterDouglasError(PowerRiseError):
    """Raised when the hub returns an error response ($error)."""

    ERROR_CODES: dict[str, str] = {
        "00": "Unknown error",
        "01": "Invalid command",
        "02": "Invalid parameter",
        "03": "Shade not found",
        "04": "Room not found",
        "05": "Scene not found",
        "06": "Communication error",
        "07": "Timeout",
        "08": "Buffer overflow",
        "09": "System busy",
    }

    def __init__(self, error_code: str = "00") -> None:
        """Initialize with error code."""
        self.error_code = error_code
        message = self.ERROR_CODES.get(error_code, f"Unknown error code: {error_code}")
        super().__init__(message)


class ParseError(PowerRiseError):
    """Raised when parsing a response fails."""


class PowerRiseTimeoutError(PowerRiseError):
    """Raised when a command times out."""

# Backwards-compatible alias
TimeoutError = PowerRiseTimeoutError
