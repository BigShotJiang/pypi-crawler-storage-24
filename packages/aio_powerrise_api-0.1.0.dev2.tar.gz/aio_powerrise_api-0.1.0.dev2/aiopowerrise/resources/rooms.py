"""Rooms resource manager for Hunter Douglas PowerRise Platinum.

Provides an interface similar to aio-powerview-api's Rooms class.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from aiopowerrise.models import Room

if TYPE_CHECKING:
    from aiopowerrise.transport import Transport

_LOGGER = logging.getLogger(__name__)


class Rooms:
    """Manage room operations on the hub.

    Rooms are primarily read-only in normal Home Assistant operation.
    The hub returns room data as part of the $dat response.
    """

    def __init__(self, transport: Transport) -> None:
        """Initialize with a transport."""
        self._transport = transport
