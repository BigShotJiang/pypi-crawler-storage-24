"""Scenes resource manager for Hunter Douglas PowerRise Platinum.

Provides an interface similar to aio-powerview-api's Scenes class.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from aiopowerrise.const import CMD_INVOKE_SCENE
from aiopowerrise.models import Scene

if TYPE_CHECKING:
    from aiopowerrise.transport import Transport

_LOGGER = logging.getLogger(__name__)


class Scenes:
    """Manage scene operations on the hub."""

    def __init__(self, transport: Transport) -> None:
        """Initialize with a transport."""
        self._transport = transport

    async def activate(self, scene_id: int) -> None:
        """Activate a scene.

        Args:
            scene_id: The scene index to invoke.
        """
        command = f"{CMD_INVOKE_SCENE}{scene_id:02d}-"
        _LOGGER.info("Activating scene %d", scene_id)
        # The invoke command uses $act00-00- as sentinel
        await self._transport.send_command(command, sentinel="$act00-00-")
