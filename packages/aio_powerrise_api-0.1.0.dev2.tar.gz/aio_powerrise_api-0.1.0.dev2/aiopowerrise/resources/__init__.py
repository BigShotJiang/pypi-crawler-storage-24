"""Shades resource manager for Hunter Douglas PowerRise Platinum.

Provides an interface similar to aio-powerview-api's Shades class.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from aiopowerrise.const import (
    CMD_POSITION_SHADE,
    CMD_RELEASE_SHADE,
    FEATURE_SHADE,
    FEATURE_TILT,
    FEATURE_TILT_REVERSE,
    RESP_DONE,
    SHADE_CMD_STOP,
    WIRE_MAX_POSITION,
)
from aiopowerrise.models import House, Shade, ShadePosition
from aiopowerrise.protocol import get_command_line

if TYPE_CHECKING:
    from aiopowerrise.transport import Transport

_LOGGER = logging.getLogger(__name__)


class Shades:
    """Manage shade operations on the hub."""

    def __init__(self, transport: Transport) -> None:
        """Initialize with a transport."""
        self._transport = transport

    async def move(
        self,
        shade_id: int,
        position: int,
        feature: str = FEATURE_SHADE,
        wire_override: int | None = None,
        shade: Shade | None = None,
    ) -> None:
        """Move a shade to a position.

        Args:
            shade_id: The shade index.
            position: Target position as percentage (0-100).
            feature: Feature code (default "04" for main shade).
            wire_override: If provided, send this raw wire value (0-255) instead
                           of converting ``position`` from a percentage.  Used for
                           bidirectional tilt where each half has its own scale.
            shade: If provided, the shade's state is updated in-place to reflect
                   the hardware side-effects of the command (tilt is cleared when
                   the primary position changes).
        """
        wire_pos = wire_override if wire_override is not None else ShadePosition.to_wire(position)
        command = f"{CMD_POSITION_SHADE}{shade_id:02d}-{feature}-{wire_pos:03d}-"
        _LOGGER.info("Moving shade %d to %d%% (wire: %d)", shade_id, position, wire_pos)
        await self._transport.send_command(command, sentinel=RESP_DONE)
        # $rls is fire-and-forget — the hub sends no response to it.
        # Any $act00-00- that follows is an unsolicited push from the shade finishing
        # its movement, not a direct reply.
        await self._transport.send_nowait(CMD_RELEASE_SHADE)
        if shade is not None and feature == FEATURE_SHADE:
            shade.apply_move(position)

    async def open(self, shade_id: int, shade: Shade | None = None) -> None:
        """Fully open a shade."""
        await self.move(shade_id, 100, shade=shade)

    async def close(self, shade_id: int, shade: Shade | None = None) -> None:
        """Fully close a shade."""
        await self.move(shade_id, 0, shade=shade)

    async def stop(self, shade_id: int, wait: bool = False) -> None:
        """Stop a shade at its current position (intermediate stop).

        By default this is fire-and-forget because some hubs do not emit a
        ``$done`` reply for intermediate-stop commands.  Callers that require
        confirmation can pass ``wait=True`` to await the hub's ``$done`` reply
        (backwards-compatible behaviour).
        """
        # Command 10 = intermediate stop, with a specific position value
        # From the smali: moveShadeToIntermediateStopPosition uses cmd=10, percentage≈0.0274
        # In practice the value doesn't matter much for stop
        command = f"{CMD_POSITION_SHADE}{shade_id:02d}-{SHADE_CMD_STOP}-000-"
        if wait:
            await self._transport.send_command(command, sentinel=RESP_DONE)
        else:
            # Fire-and-forget: do not block waiting for a reply that may never come.
            await self._transport.send_nowait(command)

    async def tilt(
        self,
        shade_id: int,
        tilt_percent: int,
        supports_tilt_reverse: bool = False,
        shade: Shade | None = None,
    ) -> None:
        """Tilt a shade's vanes.

        For standard tilt shades (Pirouette, Silhouette):
          Sends a single cmd-07 command, wire 0-255 for 0-100%.

        For bidirectional tilt shades (Luminette, ``supports_tilt_reverse=True``):
          The logical 0-100% range is split across two commands:
            0-50%   → cmd 19 (reverse), wire 0-255  (closed → open)
            50-100% → cmd 07 (forward), wire 255-0  (open   → closed)

        Args:
            shade_id: The shade index.
            tilt_percent: Logical tilt position (0-100%).
            supports_tilt_reverse: True for Luminette-type shades.
            shade: If provided, the shade's state is updated in-place to reflect
                   the hardware side-effects (position is driven to 0 for tilt).
        """
        clamped = max(0, min(100, tilt_percent))
        if supports_tilt_reverse:
            if clamped <= 50:
                wire = round(clamped * 255 / 50)
                await self.move(shade_id, 0, feature=FEATURE_TILT_REVERSE, wire_override=wire)
            else:
                wire = round((100 - clamped) * 255 / 50)
                await self.move(shade_id, 0, feature=FEATURE_TILT, wire_override=wire)
        else:
            await self.move(shade_id, clamped, feature=FEATURE_TILT)
        if shade is not None:
            shade.apply_tilt(clamped)

    async def jog(self, shade_id: int) -> None:
        """Jog a shade (brief movement for identification).

        Uses the test shade command (cmd=12) with position 0.
        """
        command = f"{CMD_POSITION_SHADE}{shade_id:02d}-12-000-"
        await self._transport.send_command(command, sentinel=RESP_DONE)
