"""NetBIOS discovery for Hunter Douglas PowerRise Platinum hubs.

The hub advertises itself with the NetBIOS name "PlatLink-PDBU" (or
"PLATLINK-PDBU").  This module implements a minimal NetBIOS name query to
discover the hub's IP address on the local network.
"""

from __future__ import annotations

import asyncio
import contextlib
import logging
import socket
import struct
import sys

from aiopowerrise.const import DEFAULT_PORT, NETBIOS_NAME, NETBIOS_PORT

_LOGGER = logging.getLogger(__name__)

# Python 3.11+ has asyncio.timeout; older versions need a shim
if sys.version_info >= (3, 11):
    _timeout = asyncio.timeout
else:
    @contextlib.asynccontextmanager  # type: ignore[arg-type]
    async def _timeout(delay: float | None):  # type: ignore[no-untyped-def]
        """Minimal asyncio.timeout shim for Python < 3.11."""
        loop = asyncio.get_running_loop()
        task = asyncio.current_task()
        assert task is not None
        handle = loop.call_later(delay, task.cancel) if delay is not None else None
        try:
            yield
        except asyncio.CancelledError:
            raise asyncio.TimeoutError() from None
        finally:
            if handle is not None:
                handle.cancel()


def _netbios_encode(name: str, service_type: int = 0x20) -> bytes:
    """Encode a NetBIOS name into first-level encoding.

    Each byte is split into two nibbles, each offset by ord('A').
    The name is padded to 15 characters and the 16th byte is the service type.
    """
    name = name.upper().ljust(15)[:15] + chr(service_type)
    encoded = b""
    for ch in name:
        b = ord(ch)
        encoded += bytes([((b >> 4) & 0x0F) + ord("A"), (b & 0x0F) + ord("A")])
    # Prepend length byte (32)
    return bytes([len(encoded)]) + encoded


def _build_nbns_query(name: str) -> bytes:
    """Build a NetBIOS Name Service query packet."""
    transaction_id = b"\x00\x01"
    flags = b"\x01\x10"  # broadcast, recursion desired
    rest = b"\x00\x01\x00\x00\x00\x00\x00\x00"  # questions=1, answers/auth/additional=0
    encoded_name = _netbios_encode(name)
    suffix = b"\x00\x20\x00\x01"  # type NB (0x0020), class IN (0x0001)
    # NetBIOS name must be terminated with a zero length octet before the
    # type/class fields (like DNS). Append the name terminator 0x00.
    return transaction_id + flags + rest + encoded_name + b"\x00" + suffix


async def discover_hub(
    name: str = NETBIOS_NAME,
    timeout: float = 5.0,
    broadcast_addr: str = "255.255.255.255",
) -> str | None:
    """Discover a PowerRise Platinum hub via NetBIOS name query.

    Args:
        name: NetBIOS name to search for (default "PlatLink-PDBU").
        timeout: How long to wait for a response.
        broadcast_addr: Broadcast address to use.

    Returns:
        IP address string if found, None otherwise.
    """
    query = _build_nbns_query(name)
    loop = asyncio.get_running_loop()

    # Create UDP socket and send query
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    # Allow reuse and broadcast
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    # Bind to all interfaces on an ephemeral port so the OS selects the source
    # address appropriately for the outbound interface.
    try:
        sock.bind(("", 0))
    except OSError:
        # Some platforms may reject bind for UDP sockets; continue anyway.
        pass
    sock.setblocking(False)
    sock.settimeout(0)

    try:
        try:
            sent = sock.sendto(query, (broadcast_addr, NETBIOS_PORT))
            _LOGGER.debug("Sent NetBIOS query for '%s' (%d bytes)", name, sent)
        except OSError as exc:
            _LOGGER.exception("Failed to send NetBIOS query: %s", exc)
            return None

        # Wait for response
        try:
            async with _timeout(timeout):
                while True:
                    try:
                        data, addr = await _recvfrom(loop, sock, 1024)
                        ip = addr[0]
                        _LOGGER.info("NetBIOS response from %s", ip)
                        return ip
                    except BlockingIOError:
                        await asyncio.sleep(0.1)
        except (asyncio.TimeoutError, asyncio.CancelledError):
            _LOGGER.warning("NetBIOS discovery timed out for '%s'", name)
            return None
    finally:
        sock.close()


async def _recvfrom(loop: asyncio.AbstractEventLoop, sock: socket.socket, n: int):
    """Receive from socket using loop.sock_recvfrom when available,
    otherwise fall back to run_in_executor to call blocking recvfrom in a
    thread. This handles selector-based event loops that don't implement
    sock_recvfrom (common on macOS Python builds).
    Returns a (data, addr) tuple like socket.recvfrom.
    """
    if hasattr(loop, "sock_recvfrom"):
        return await loop.sock_recvfrom(sock, n)

    # Fallback: temporarily use blocking recvfrom in a ThreadPool
    # Ensure socket is blocking for the blocking call, restore afterward.
    blocking = sock.getblocking()
    try:
        sock.setblocking(True)
        return await loop.run_in_executor(None, sock.recvfrom, n)
    finally:
        try:
            sock.setblocking(blocking)
        except Exception:
            pass

    # (module-level code moved into discover_hub)


async def discover_hubs(
    name: str = NETBIOS_NAME,
    timeout: float = 5.0,
    broadcast_addr: str = "255.255.255.255",
) -> list[str]:
    """Discover all PowerRise Platinum hubs on the network.

    Returns:
        List of IP addresses found.
    """
    query = _build_nbns_query(name)
    results: list[str] = []

    loop = asyncio.get_running_loop()

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    sock.setblocking(False)
    sock.settimeout(0)

    try:
        sock.sendto(query, (broadcast_addr, NETBIOS_PORT))

        try:
            async with _timeout(timeout):
                while True:
                    try:
                        data, addr = await _recvfrom(loop, sock, 1024)
                        ip = addr[0]
                        if ip not in results:
                            results.append(ip)
                            _LOGGER.info("Found hub at %s", ip)
                    except BlockingIOError:
                        await asyncio.sleep(0.1)
        except (asyncio.TimeoutError, asyncio.CancelledError):
            pass
    finally:
        sock.close()

    return results
