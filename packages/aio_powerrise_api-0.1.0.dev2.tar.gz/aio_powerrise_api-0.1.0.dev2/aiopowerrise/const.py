"""Constants for Hunter Douglas PowerRise Platinum."""

# Network
DEFAULT_PORT: int = 522
NETBIOS_NAME: str = "PlatLink-PDBU"
NETBIOS_PORT: int = 137

# Position limits (0-25# Brand indexes whose shade type supports tilt (vane/slat movement).
# Pirouette (9), Silhouette (10, 21), Luminette Privacy (6), Luminette Dual (8).
BRAND_INDEXES_WITH_TILT: frozenset[int] = frozenset({6, 8, 9, 10, 21})

# Brand indexes that support bidirectional / reverse tilt (Luminette SLAT types only).
# For these shades the logical 0-100% tilt range is split in two halves:
#   0-50%   → cmd 19 (reverse),  wire maps  0 → 255  (closed → open)
#   50-100% → cmd 07 (forward),  wire maps  255 → 0  (open   → closed)
# At 50% both halves meet at wire 255 (fully open vanes in both directions).
BRAND_INDEXES_WITH_TILT_REVERSE: frozenset[int] = frozenset({6, 8})

# Brand indexes that have a secondary (top-down) rail in addition to thewire, exposed as 0-100 percentage)
MIN_POSITION: int = 0
MAX_POSITION: int = 100
WIRE_MIN_POSITION: int = 0
WIRE_MAX_POSITION: int = 255

# Shade feature codes (from the $cp command field)
FEATURE_SHADE: str = "04"
FEATURE_TILT: str = "07"
FEATURE_TILT_REVERSE: str = "19"

# Protocol commands
CMD_GET_DATA: str = "$dat"
CMD_DUMMY: str = "$dmy"
CMD_SET_DATE: str = "$sdt"
CMD_SET_TIME: str = "$stm"
CMD_POSITION_SHADE: str = "$pss"
CMD_RELEASE_SHADE: str = "$rls"
CMD_INVOKE_SCENE: str = "$inm"
CMD_POSITION_SCENE_ROOM: str = "$mrp"
CMD_SET_SCENE_LINK: str = "$sml"
CMD_ADD_ROOM: str = "$ar"
CMD_EDIT_ROOM: str = "$mer"
CMD_REMOVE_ROOM: str = "$rr"
CMD_ADD_SHADE: str = "$as"
CMD_EDIT_SHADE: str = "$mes"
CMD_REMOVE_SHADE: str = "$rs"
CMD_SYNC_SHADE: str = "$rsc"
CMD_STOP_SYNC: str = "$stps"
CMD_TEST_SHADE: str = "$tss"
CMD_ADD_SCENE: str = "$am"
CMD_EDIT_SCENE: str = "$cmn"
CMD_REMOVE_SCENE: str = "$rm"
CMD_SET_LED_BRIGHTNESS: str = "$LEDl"
CMD_BRIDGE_BOOTLOADER: str = "$BdgBtl"

# Response prefixes
RESP_ROOM: str = "$cr"
RESP_SHADE: str = "$cs"
RESP_SCENE: str = "$cm"
RESP_SHADE_POSITION: str = "$cp"
RESP_SCENE_LINK: str = "$cq"
RESP_SCENE_ROOM_POS: str = "$cx"
RESP_TITLE: str = "$ct"
RESP_TIMED_EVENT: str = "$ca"
RESP_FIRMWARE: str = "$firm"
RESP_LED_BRIGHTNESS: str = "$LEDl"
RESP_UPDATE: str = "$upd"
RESP_DONE: str = "$done"
RESP_ACK: str = "$ack"
RESP_ERROR: str = "$error"

# End of data sentinels
END_SENTINELS: tuple[str, ...] = ("$done", "$act00-00-", "$upd01-", "$error")

# Timeouts
CONNECT_TIMEOUT: float = 10.0
COMMAND_TIMEOUT: float = 15.0
READ_TIMEOUT: float = 10.0
KEEPALIVE_INTERVAL: float = 60.0

# Shade commands / feature types for positionShade
SHADE_CMD_OPEN: int = 4   # Feature code used in $pss
SHADE_CMD_CLOSE: int = 4
SHADE_CMD_STOP: int = 10  # Intermediate stop
SHADE_CMD_TEST: int = 12
SHADE_CMD_TILT: int = 7            # Vane / slat tilt (Silhouette, Pirouette, Luminette)
SHADE_CMD_TILT_REVERSE: int = 19   # Slat reverse tilt (Luminette only, past midpoint)

# ---------------------------------------------------------------------------
# Brand index constants
# ---------------------------------------------------------------------------
BRAND_ALUSTRA: int = 0
BRAND_DUETTE_STANDARD: int = 1
BRAND_DUETTE_DUO_LITE: int = 2
BRAND_DUETTE_TOP_DOWN: int = 3
BRAND_DUETTE_SKYLIFT: int = 4
BRAND_DESIGNER_SCREEN: int = 5
BRAND_LUMINETTE_PRIVACY: int = 6
BRAND_LUMINETTE_MODERN_FULL: int = 7
BRAND_LUMINETTE_MODERN_DUAL: int = 8
BRAND_PIROUETTE: int = 9
BRAND_SILHOUETTE: int = 10
BRAND_VIGNETTE_TRADITIONAL: int = 11
BRAND_VIGNETTE_TIERED: int = 12
BRAND_VIGNETTE_TIERED_TOPDOWN: int = 13
BRAND_SKYLINE: int = 14
BRAND_PLEATED: int = 15
BRAND_ALUSTRA_ROMAN: int = 16
BRAND_SOLERA: int = 17
BRAND_DESIGN_STUDIO_ROMAN: int = 18
BRAND_SILHOUETTE_NANTUCKET_DEUX: int = 21
BRAND_PROVENANCE_STANDARD: int = 22
BRAND_PROVENANCE_INDEPENDENT: int = 23
BRAND_PROVENANCE_VERTICAL: int = 24
BRAND_PROVENANCE_TOPDOWN: int = 25
BRAND_ALUSTRA_INDEPENDENT: int = 30

# Human-readable product names keyed by brand index.
BRAND_MAP: dict[int, str] = {
    0:  "Alustra® Woven Textures® Roller",
    1:  "Duette® & Applause® Honeycomb Shades",
    2:  "Duette® & Applause® Honeycomb Shades DuoLite™ & Top-Down/Bottom-Up",
    3:  "Duette® & Applause® Honeycomb Shades Top-Down",
    4:  "Duette® & Applause® Honeycomb Shades Skylift",
    5:  "Designer Roller & Screen Shades",
    6:  "Luminette® Privacy Sheers",
    7:  "Luminette® Modern Draperies Full Panel",
    8:  "Luminette® Modern Draperies Dual Panel",
    9:  "Pirouette® Window Shadings",
    10: "Silhouette® & Nantucket™ Window Shadings",
    11: "Vignette® Modern Roman Shades Traditional",
    12: "Vignette® Modern Roman Shades Tiered™",
    13: "Vignette® Modern Roman Shades Tiered™ Top-Down/Bottom-Up",
    14: "Skyline® Gliding Window Panels",
    15: "Pleated Shades",
    16: "Alustra® Woven Textures® Roman",
    17: "Solera® Soft Shades",
    18: "Design Studio™ Roman Shades",
    21: "Silhouette® & Nantucket™ Window Shadings A Deux™ Room Darkening Shade",
    22: "Provenance® Woven Wood Shades",
    23: "Provenance® Woven Wood Shades Independent Operable Liner",
    24: "Provenance® Woven Wood Shades Vertical Drapery",
    25: "Provenance® Woven Wood Shades Top-Down/Bottom-Up",
    30: "Alustra® Woven Textures® Independently Operated Liner",
}

# ---------------------------------------------------------------------------
# Shade type codes (internal UI classification from BrandIndexes.getShadeType)
# ---------------------------------------------------------------------------
SHADE_TYPE_BOTTOM_BAR_UP: int = 1500  # Standard roller / honeycomb
SHADE_TYPE_TOP_BAR_DOWN: int = 1600   # Top-down only
SHADE_TYPE_DUAL_SLIDERS: int = 1700   # Top-down/bottom-up
SHADE_TYPE_SLAT: int = 1800           # Luminette – horizontal vanes (tilt)
SHADE_TYPE_VANE: int = 1900           # Pirouette / Silhouette – vanes (tilt)

# Mapping from brand index to shade type.
BRAND_SHADE_TYPE_MAP: dict[int, int] = {
    0:  SHADE_TYPE_BOTTOM_BAR_UP,
    1:  SHADE_TYPE_BOTTOM_BAR_UP,
    2:  SHADE_TYPE_DUAL_SLIDERS,
    3:  SHADE_TYPE_TOP_BAR_DOWN,
    4:  SHADE_TYPE_BOTTOM_BAR_UP,
    5:  SHADE_TYPE_BOTTOM_BAR_UP,
    6:  SHADE_TYPE_SLAT,
    7:  SHADE_TYPE_BOTTOM_BAR_UP,
    8:  SHADE_TYPE_SLAT,
    9:  SHADE_TYPE_VANE,
    10: SHADE_TYPE_VANE,
    11: SHADE_TYPE_BOTTOM_BAR_UP,
    12: SHADE_TYPE_BOTTOM_BAR_UP,
    13: SHADE_TYPE_DUAL_SLIDERS,
    14: SHADE_TYPE_BOTTOM_BAR_UP,
    15: SHADE_TYPE_BOTTOM_BAR_UP,
    16: SHADE_TYPE_BOTTOM_BAR_UP,
    17: SHADE_TYPE_BOTTOM_BAR_UP,
    18: SHADE_TYPE_BOTTOM_BAR_UP,
    21: SHADE_TYPE_BOTTOM_BAR_UP,
    22: SHADE_TYPE_BOTTOM_BAR_UP,
    23: SHADE_TYPE_BOTTOM_BAR_UP,
    24: SHADE_TYPE_BOTTOM_BAR_UP,
    25: SHADE_TYPE_DUAL_SLIDERS,
    30: SHADE_TYPE_BOTTOM_BAR_UP,
}

# Brand indexes whose shade type supports tilt (vane/slat movement).
# Pirouette (9), Silhouette (10), Luminette Privacy (6), Luminette Dual (8).
BRAND_INDEXES_WITH_TILT: frozenset[int] = frozenset({6, 8, 9, 10, 21})

# Brand indexes that have a secondary (top-down) rail in addition to the
# primary bottom-up bar (DuoLite, TDBU variants, Vignette TDBU, Provenance TDBU).
BRAND_INDEXES_WITH_SECONDARY: frozenset[int] = frozenset({2, 3, 13, 25})
