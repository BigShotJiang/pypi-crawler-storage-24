"""Tests for live-state listener (Transport callback + Hub integration)."""

from __future__ import annotations

import asyncio
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from aiopowerrise.hub import Hub
from aiopowerrise.models import House, Shade, Bridge
from aiopowerrise.protocol import parse_line


# ---------------------------------------------------------------------------
# parse_line unit tests
# ---------------------------------------------------------------------------


def _make_house() -> House:
    house = House(name="Test House", bridge=Bridge())
    shade = Shade(id=3, name="Living Room Door", room_id=1, position=0, tilt_position=128)
    house.shades = {3: shade}
    return house


def test_parse_line_shade_position_updates_shade():
    house = _make_house()
    result = parse_line("$cp03-07-064-", house)
    assert result is not None
    assert "shade 3" in result
    assert house.shades[3].tilt_position == 64


def test_parse_line_shade_position_returns_description():
    house = _make_house()
    result = parse_line("$cp03-07-255-", house)
    assert result is not None
    assert "tilt=100%" in result or "wire=255" in result


def test_parse_line_unknown_line_returns_none():
    house = _make_house()
    result = parse_line("$dmy", house)
    assert result is None


def test_parse_line_empty_returns_none():
    house = _make_house()
    assert parse_line("", house) is None
    assert parse_line("   ", house) is None


def test_parse_line_unknown_shade_id_returns_string():
    """Shade ID not in house still returns a description string."""
    house = _make_house()
    result = parse_line("$cp99-07-128-", house)
    # Should still return something (shade not in house but position line parsed)
    assert result is not None


def test_parse_line_led_brightness():
    house = _make_house()
    result = parse_line("$LEDl128-", house)
    assert result is not None
    assert house.bridge.led_brightness_bits == 128


def test_parse_line_firmware():
    house = _make_house()
    result = parse_line("$firm02-2018-HD gateway", house)
    assert result is not None
    assert house.bridge.firmware_version == 2018


# ---------------------------------------------------------------------------
# Transport.set_line_callback / start_listener
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_transport_callback_called_for_incoming_line():
    """Background reader calls the registered callback with each line."""
    from aiopowerrise.transport import Transport

    transport = Transport("127.0.0.1", 522)
    received: list[str] = []

    transport.set_line_callback(received.append)

    # Simulate a reader that yields one line then raises CancelledError
    reader = AsyncMock()
    reader.readline = AsyncMock(side_effect=[b"$cp03-07-064-\r\n", asyncio.CancelledError()])
    transport._reader = reader
    transport._writer = MagicMock()
    transport._connected = True

    task = asyncio.create_task(transport._reader_loop())
    await asyncio.sleep(0.1)
    task.cancel()
    try:
        await task
    except asyncio.CancelledError, Exception:
        pass

    assert any("$cp03-07-064-" in line for line in received)


@pytest.mark.asyncio
async def test_transport_no_callback_no_error():
    """Reader runs without callback without raising."""
    from aiopowerrise.transport import Transport

    transport = Transport("127.0.0.1", 522)
    # No callback set

    reader = AsyncMock()
    reader.readline = AsyncMock(side_effect=[b"$cp03-07-064-\r\n", asyncio.CancelledError()])
    transport._reader = reader
    transport._writer = MagicMock()
    transport._connected = True

    task = asyncio.create_task(transport._reader_loop())
    await asyncio.sleep(0.1)
    task.cancel()
    try:
        await task
    except asyncio.CancelledError, Exception:
        pass


# ---------------------------------------------------------------------------
# Hub.add_listener / start_listening / stop_listening
# ---------------------------------------------------------------------------


def _make_hub_with_house() -> Hub:
    hub = Hub("127.0.0.1", 522)
    hub._house = _make_house()
    return hub


def test_hub_add_listener_returns_remove():
    hub = _make_hub_with_house()
    events: list[tuple] = []
    remove = hub.add_listener(lambda et, d: events.append((et, d)))
    assert callable(remove)
    assert len(hub._listeners) == 1
    remove()
    assert len(hub._listeners) == 0


def test_hub_on_line_fires_shade_listener():
    hub = _make_hub_with_house()
    events: list[tuple] = []
    hub.add_listener(lambda et, d: events.append((et, d)))

    hub._on_line("$cp03-07-064-")

    assert len(events) == 1
    event_type, shade = events[0]
    assert event_type == "shade"
    assert shade.id == 3
    assert shade.tilt_position == 64


def test_hub_on_line_updates_house_in_place():
    hub = _make_hub_with_house()
    hub._on_line("$cp03-07-200-")
    assert hub.house.shades[3].tilt_position == 200  # type: ignore[union-attr]


def test_hub_on_line_no_house_no_error():
    hub = Hub("127.0.0.1", 522)
    hub._house = None
    # Should not raise
    hub._on_line("$cp03-07-064-")


def test_hub_multiple_listeners():
    hub = _make_hub_with_house()
    a_events: list = []
    b_events: list = []
    hub.add_listener(lambda et, d: a_events.append((et, d)))
    hub.add_listener(lambda et, d: b_events.append((et, d)))

    hub._on_line("$cp03-07-064-")

    assert len(a_events) == 1
    assert len(b_events) == 1


def test_hub_listener_exception_does_not_propagate():
    hub = _make_hub_with_house()

    def bad_cb(et, d):
        raise RuntimeError("boom")

    hub.add_listener(bad_cb)
    # Should not raise
    hub._on_line("$cp03-07-064-")


def test_hub_stop_listening_clears_callback():
    hub = _make_hub_with_house()
    hub._transport.set_line_callback(lambda line: None)
    hub.stop_listening()
    assert hub._transport._line_callback is None


@pytest.mark.asyncio
async def test_hub_start_listening_attaches_callback_and_starts_task():
    hub = Hub("127.0.0.1", 522)
    hub._house = _make_house()

    # Patch Transport so it doesn't actually connect
    reader = AsyncMock()
    # Return one real line then keep timing out so the loop keeps running
    reader.readline = AsyncMock(return_value=b"")
    hub._transport._reader = reader
    hub._transport._writer = MagicMock()
    hub._transport._connected = True

    hub.start_listening()
    await asyncio.sleep(0.05)

    assert hub._transport._line_callback is not None
    assert hub._transport._reader_task is not None

    # Tear down cleanly
    hub._transport._connected = False
    hub.stop_listening()
    if hub._transport._reader_task and not hub._transport._reader_task.done():
        hub._transport._reader_task.cancel()
        await asyncio.sleep(0.05)
