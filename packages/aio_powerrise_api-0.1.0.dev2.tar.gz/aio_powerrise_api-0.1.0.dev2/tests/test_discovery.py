"""Tests for aiopowerrise.discovery."""

from __future__ import annotations

import pytest

from aiopowerrise.discovery import _build_nbns_query, _netbios_encode


# ---------------------------------------------------------------------------
# NetBIOS name encoding
# ---------------------------------------------------------------------------


class TestNetBIOSEncode:
    def test_encoding_length(self) -> None:
        """Encoded name is always 32 bytes + 1 length byte = 33."""
        result = _netbios_encode("PLATLINK-PDBU")
        assert len(result) == 33  # 1 byte length + 32 bytes encoded
        assert result[0] == 32   # length prefix

    def test_encoding_pad_short_name(self) -> None:
        """Short names are padded to 15 characters."""
        result = _netbios_encode("AB")
        assert len(result) == 33

    def test_encoding_truncate_long_name(self) -> None:
        """Names longer than 15 chars are truncated."""
        result = _netbios_encode("A" * 20)
        assert len(result) == 33

    def test_encoding_uppercase(self) -> None:
        """Names are converted to uppercase."""
        r1 = _netbios_encode("platlink-pdbu")
        r2 = _netbios_encode("PLATLINK-PDBU")
        assert r1 == r2

    def test_first_char_encoding(self) -> None:
        """Verify encoding of 'P' (0x50) -> 'F' (0x45+5=70) + 'A' (65+0=65)."""
        result = _netbios_encode("P")
        # First encoded byte pair after length byte should be for 'P' (0x50)
        # High nibble: (0x50 >> 4) & 0x0F = 5, + ord('A') = 70 = 'F'
        # Low nibble: 0x50 & 0x0F = 0, + ord('A') = 65 = 'A'
        assert result[1] == ord("F")
        assert result[2] == ord("A")


# ---------------------------------------------------------------------------
# NBNS query packet
# ---------------------------------------------------------------------------


class TestBuildNBNSQuery:
    def test_query_structure(self) -> None:
        """Packet starts with transaction ID and contains the encoded name."""
        packet = _build_nbns_query("PlatLink-PDBU")
        # Transaction ID
        assert packet[0:2] == b"\x00\x01"
        # Flags: broadcast + recursion desired
        assert packet[2:4] == b"\x01\x10"
        # Questions = 1
        assert packet[4:6] == b"\x00\x01"
        # Should end with type NB (0x0020) + class IN (0x0001)
        assert packet[-4:] == b"\x00\x20\x00\x01"

    def test_query_contains_encoded_name(self) -> None:
        """The packet contains the encoded NetBIOS name."""
        packet = _build_nbns_query("PlatLink-PDBU")
        encoded = _netbios_encode("PlatLink-PDBU")
        # The encoded name should be somewhere in the packet
        assert encoded in packet

    def test_query_length_reasonable(self) -> None:
        """A NetBIOS name query should be about 50 bytes."""
        packet = _build_nbns_query("PlatLink-PDBU")
        # 2 (txid) + 2 (flags) + 8 (counts) + 33 (name) + 1 (null terminator) + 4 (type+class) = 50
        assert len(packet) == 50
