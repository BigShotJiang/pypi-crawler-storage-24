"""Tests for aiopowerrise.models."""

from __future__ import annotations

import pytest

from aiopowerrise.const import MAX_POSITION, MIN_POSITION, WIRE_MAX_POSITION
from aiopowerrise.models import (
    Bridge,
    House,
    Room,
    Scene,
    SceneLink,
    SceneRoomPosition,
    Shade,
    ShadePosition,
    TimedEvent,
)


# ---------------------------------------------------------------------------
# ShadePosition
# ---------------------------------------------------------------------------


class TestShadePosition:
    """Tests for the ShadePosition dataclass."""

    def test_defaults(self) -> None:
        pos = ShadePosition()
        assert pos.primary is None
        assert pos.secondary is None
        assert pos.tilt is None

    def test_with_values(self) -> None:
        pos = ShadePosition(primary=50, secondary=25, tilt=75)
        assert pos.primary == 50
        assert pos.secondary == 25
        assert pos.tilt == 75

    # -- from_wire -----------------------------------------------------------

    @pytest.mark.parametrize(
        ("wire", "expected_pct"),
        [
            (0, 0),
            (255, 100),
            (128, 50),  # round(128 * 100 / 255) = 50
            (1, 0),  # round(1 * 100 / 255) = 0
            (254, 100),  # round(254 * 100 / 255) = 100
            (127, 50),  # round(127 * 100 / 255) = 50
        ],
    )
    def test_from_wire(self, wire: int, expected_pct: int) -> None:
        assert ShadePosition.from_wire(wire) == expected_pct

    def test_from_wire_boundary_zero(self) -> None:
        assert ShadePosition.from_wire(0) == 0

    def test_from_wire_boundary_max(self) -> None:
        assert ShadePosition.from_wire(255) == 100

    # -- to_wire -------------------------------------------------------------

    @pytest.mark.parametrize(
        ("pct", "expected_wire"),
        [
            (0, 0),
            (100, 255),
            (50, 128),  # round(50 * 255 / 100) = 128
            (1, 3),  # round(1 * 255 / 100) = 3
            (99, 252),  # round(99 * 255 / 100) = 252
        ],
    )
    def test_to_wire(self, pct: int, expected_wire: int) -> None:
        assert ShadePosition.to_wire(pct) == expected_wire

    def test_to_wire_clamps_below(self) -> None:
        assert ShadePosition.to_wire(-10) == 0

    def test_to_wire_clamps_above(self) -> None:
        assert ShadePosition.to_wire(200) == 255

    # -- round-trip ----------------------------------------------------------

    def test_round_trip_zero(self) -> None:
        assert ShadePosition.from_wire(ShadePosition.to_wire(0)) == 0

    def test_round_trip_max(self) -> None:
        assert ShadePosition.from_wire(ShadePosition.to_wire(100)) == 100

    def test_round_trip_mid(self) -> None:
        pct = ShadePosition.from_wire(ShadePosition.to_wire(50))
        assert abs(pct - 50) <= 1  # Allow rounding tolerance


# ---------------------------------------------------------------------------
# Bridge
# ---------------------------------------------------------------------------


class TestBridge:
    def test_defaults(self) -> None:
        b = Bridge()
        assert b.firmware_version == 0
        assert b.led_brightness_bits == 0
        assert b.needs_firmware_update is False

    def test_led_brightness_percentage_zero(self) -> None:
        b = Bridge(led_brightness_bits=0)
        assert b.led_brightness_percentage == 0.0

    def test_led_brightness_percentage_full(self) -> None:
        b = Bridge(led_brightness_bits=255)
        assert b.led_brightness_percentage == 1.0

    def test_led_brightness_percentage_half(self) -> None:
        b = Bridge(led_brightness_bits=128)
        assert abs(b.led_brightness_percentage - 128 / 255) < 0.001

    def test_led_brightness_percentage_negative(self) -> None:
        b = Bridge(led_brightness_bits=-1)
        assert b.led_brightness_percentage == 0.0


# ---------------------------------------------------------------------------
# Room
# ---------------------------------------------------------------------------


class TestRoom:
    def test_defaults(self) -> None:
        r = Room()
        assert r.id == 0
        assert r.name == ""
        assert r.brand_index == 0
        assert r.shades == []

    def test_raw_data(self) -> None:
        r = Room(id=2, name="Kitchen", brand_index=1)
        raw = r.raw_data
        assert raw["id"] == 2
        assert raw["name"] == "Kitchen"
        assert raw["brandIndex"] == 1
        # brand_name is auto-derived from brand_index via BRAND_MAP
        assert raw["brandName"] == "Duette® & Applause® Honeycomb Shades"
        assert raw["shadeType"] == 1500  # SHADE_TYPE_BOTTOM_BAR_UP
        assert raw["supportsTilt"] is False
        assert raw["supportsSecondaryPosition"] is False

    def test_shades_list_is_independent(self) -> None:
        """Default mutable list should not be shared between instances."""
        r1 = Room()
        r2 = Room()
        r1.shades.append(1)
        assert r2.shades == []

    # --- brand_name property -------------------------------------------

    def test_brand_name_silhouette(self) -> None:
        r = Room(brand_index=10)
        assert r.brand_name == "Silhouette® & Nantucket™ Window Shadings"

    def test_brand_name_pirouette(self) -> None:
        r = Room(brand_index=9)
        assert r.brand_name == "Pirouette® Window Shadings"

    def test_brand_name_duette_standard(self) -> None:
        r = Room(brand_index=1)
        assert r.brand_name == "Duette® & Applause® Honeycomb Shades"

    def test_brand_name_luminette_privacy(self) -> None:
        r = Room(brand_index=6)
        assert r.brand_name == "Luminette® Privacy Sheers"

    def test_brand_name_unknown_index(self) -> None:
        r = Room(brand_index=99)
        assert r.brand_name == "Unknown"

    def test_brand_name_default_index_0(self) -> None:
        r = Room(brand_index=0)
        assert r.brand_name == "Alustra® Woven Textures® Roller"

    # --- supports_tilt --------------------------------------------------

    def test_supports_tilt_silhouette(self) -> None:
        assert Room(brand_index=10).supports_tilt is True  # Silhouette

    def test_supports_tilt_silhouette_deux(self) -> None:
        assert Room(brand_index=21).supports_tilt is True  # Silhouette A Deux

    def test_supports_tilt_pirouette(self) -> None:
        assert Room(brand_index=9).supports_tilt is True  # Pirouette

    def test_supports_tilt_luminette_privacy(self) -> None:
        assert Room(brand_index=6).supports_tilt is True  # Luminette Privacy

    def test_supports_tilt_luminette_dual(self) -> None:
        assert Room(brand_index=8).supports_tilt is True  # Luminette Dual

    def test_no_tilt_duette(self) -> None:
        assert Room(brand_index=1).supports_tilt is False  # Duette

    def test_no_tilt_designer_screen(self) -> None:
        assert Room(brand_index=5).supports_tilt is False

    def test_no_tilt_provenance(self) -> None:
        assert Room(brand_index=22).supports_tilt is False

    # --- supports_secondary_position ------------------------------------

    def test_secondary_duette_duolite(self) -> None:
        assert Room(brand_index=2).supports_secondary_position is True

    def test_secondary_duette_topdown(self) -> None:
        assert Room(brand_index=3).supports_secondary_position is True

    def test_secondary_vignette_tdbu(self) -> None:
        assert Room(brand_index=13).supports_secondary_position is True

    def test_secondary_provenance_tdbu(self) -> None:
        assert Room(brand_index=25).supports_secondary_position is True

    def test_no_secondary_standard_duette(self) -> None:
        assert Room(brand_index=1).supports_secondary_position is False

    # --- shade_type / is_top_down / is_dual_action ----------------------

    def test_shade_type_vane(self) -> None:
        from aiopowerrise.const import SHADE_TYPE_VANE

        assert Room(brand_index=10).shade_type == SHADE_TYPE_VANE  # Silhouette
        assert Room(brand_index=9).shade_type == SHADE_TYPE_VANE  # Pirouette

    def test_shade_type_slat(self) -> None:
        from aiopowerrise.const import SHADE_TYPE_SLAT

        assert Room(brand_index=6).shade_type == SHADE_TYPE_SLAT  # Luminette Privacy
        assert Room(brand_index=8).shade_type == SHADE_TYPE_SLAT  # Luminette Dual

    def test_shade_type_top_bar_down(self) -> None:
        from aiopowerrise.const import SHADE_TYPE_TOP_BAR_DOWN

        assert Room(brand_index=3).shade_type == SHADE_TYPE_TOP_BAR_DOWN
        assert Room(brand_index=3).is_top_down is True

    def test_shade_type_dual_sliders(self) -> None:
        from aiopowerrise.const import SHADE_TYPE_DUAL_SLIDERS

        assert Room(brand_index=2).shade_type == SHADE_TYPE_DUAL_SLIDERS
        assert Room(brand_index=2).is_dual_action is True

    def test_shade_type_bottom_bar_up(self) -> None:
        from aiopowerrise.const import SHADE_TYPE_BOTTOM_BAR_UP

        assert Room(brand_index=1).shade_type == SHADE_TYPE_BOTTOM_BAR_UP
        assert Room(brand_index=1).is_top_down is False
        assert Room(brand_index=1).is_dual_action is False

    def test_shade_type_unknown(self) -> None:
        assert Room(brand_index=99).shade_type == 0


# ---------------------------------------------------------------------------
# Shade
# ---------------------------------------------------------------------------


class TestShade:
    def test_defaults(self) -> None:
        s = Shade()
        assert s.id == 0
        assert s.position == 0
        assert s.tilt_position == 0

    def test_position_percent_closed(self) -> None:
        s = Shade(position=0)
        assert s.position_percent == 0

    def test_position_percent_open(self) -> None:
        s = Shade(position=255)
        assert s.position_percent == 100

    def test_position_percent_mid(self) -> None:
        s = Shade(position=128)
        assert s.position_percent == 50

    def test_position_percent_setter(self) -> None:
        s = Shade()
        s.position_percent = 75
        assert s.position == ShadePosition.to_wire(75)

    def test_tilt_percent_zero(self) -> None:
        s = Shade(tilt_position=0)
        assert s.tilt_percent == 0

    def test_tilt_percent_full(self) -> None:
        s = Shade(tilt_position=255)
        assert s.tilt_percent == 100

    def test_tilt_percent_mid(self) -> None:
        s = Shade(tilt_position=128)
        assert s.tilt_percent == 50

    def test_tilt_percent_setter(self) -> None:
        s = Shade()
        s.tilt_percent = 50
        assert s.tilt_position == ShadePosition.to_wire(50)

    def test_is_open_true(self) -> None:
        s = Shade(position=255)
        assert s.is_open is True

    def test_is_open_false(self) -> None:
        s = Shade(position=128)
        assert s.is_open is False

    def test_is_closed_true(self) -> None:
        s = Shade(position=0)
        assert s.is_closed is True

    def test_is_closed_false(self) -> None:
        s = Shade(position=128)
        assert s.is_closed is False

    def test_is_closed_when_tilt_active(self) -> None:
        """A shade with an active tilt is always considered closed."""
        s = Shade(position=0, tilt_position=128)
        assert s.is_closed is True

    def test_is_closed_tilt_zero_position_open(self) -> None:
        """No tilt active, position open → not closed."""
        s = Shade(position=255, tilt_position=0)
        assert s.is_closed is False

    # --- current_position -----------------------------------------------

    def test_current_position_no_tilt_support(self) -> None:
        """Non-tilt shade: tilt is always None regardless of tilt_position."""
        s = Shade(position=128, tilt_position=0, supports_tilt=False)
        pos = s.current_position
        assert pos.primary == 50
        assert pos.tilt is None

    def test_current_position_tilt_capable_at_zero(self) -> None:
        """Tilt-capable shade with tilt=0: tilt reported as 0% (not None)."""
        s = Shade(position=128, tilt_position=0, supports_tilt=True)
        pos = s.current_position
        assert pos.primary == 50
        assert pos.tilt == 0

    def test_current_position_with_tilt(self) -> None:
        """Tilt-capable shade with active tilt: position zeroed, tilt reported."""
        s = Shade(position=0, tilt_position=128, supports_tilt=True)
        pos = s.current_position
        assert pos.primary == 0
        assert pos.tilt == 50

    def test_current_position_tilt_and_position_mutually_exclusive(self) -> None:
        """Parser ensures position=0 when tilt is active; primary reads as 0."""
        s = Shade(position=0, tilt_position=128, supports_tilt=True)
        pos = s.current_position
        assert pos.primary == 0
        assert pos.tilt == 50

    def test_current_position_tilt_zero_non_tilt_shade_means_no_tilt(self) -> None:
        """Non-tilt shade: tilt_position=0, supports_tilt=False → tilt is None."""
        s = Shade(position=0, tilt_position=0, supports_tilt=False)
        pos = s.current_position
        assert pos.primary == 0
        assert pos.tilt is None

    # --- bidirectional tilt (Luminette) ---------------------------------

    def test_tilt_percent_forward_half(self) -> None:
        """Luminette cmd-19 reverse: wire 0→0%, wire 128→25%, wire 255→50%."""
        s = Shade(supports_tilt=True, supports_tilt_reverse=True, tilt_command=19)
        s.tilt_position = 0
        assert s.tilt_percent == 0
        s.tilt_position = 128
        assert s.tilt_percent == round(128 * 50 / 255)
        s.tilt_position = 255
        assert s.tilt_percent == 50

    def test_tilt_percent_reverse_half(self) -> None:
        """Luminette cmd-07 forward: wire 255→50%, wire 128→75%, wire 0→100%."""
        s = Shade(supports_tilt=True, supports_tilt_reverse=True, tilt_command=7)
        s.tilt_position = 255
        assert s.tilt_percent == 50
        s.tilt_position = 128
        assert s.tilt_percent == 50 + round((255 - 128) * 50 / 255)
        s.tilt_position = 0
        assert s.tilt_percent == 100

    def test_tilt_percent_setter_forward(self) -> None:
        """Setting tilt_percent 0-50% on a Luminette sets cmd=19 and correct wire."""
        s = Shade(supports_tilt=True, supports_tilt_reverse=True)
        s.tilt_percent = 25
        assert s.tilt_command == 19
        assert s.tilt_position == round(25 * 255 / 50)

    def test_tilt_percent_setter_reverse(self) -> None:
        """Setting tilt_percent >50% on a Luminette sets cmd=07 and correct wire."""
        s = Shade(supports_tilt=True, supports_tilt_reverse=True)
        s.tilt_percent = 75
        assert s.tilt_command == 7
        assert s.tilt_position == round((100 - 75) * 255 / 50)

    def test_tilt_percent_setter_midpoint(self) -> None:
        """50% on a Luminette → cmd=19, wire=255 (fully open reverse)."""
        s = Shade(supports_tilt=True, supports_tilt_reverse=True)
        s.tilt_percent = 50
        assert s.tilt_command == 19
        assert s.tilt_position == 255

    def test_tilt_percent_setter_standard(self) -> None:
        """Standard tilt shade: setter uses full 0-255 wire range."""
        s = Shade(supports_tilt=True, supports_tilt_reverse=False)
        s.tilt_percent = 50
        assert s.tilt_position == 128  # round(50 * 255 / 100)
        assert s.tilt_command == 7  # unchanged default

    # --- raw_data -------------------------------------------------------

    def test_raw_data(self) -> None:
        s = Shade(id=3, name="Test", room_id=1, group_number=0, position=128, tilt_position=0)
        raw = s.raw_data
        assert raw["id"] == 3
        assert raw["name"] == "Test"
        assert raw["roomId"] == 1
        assert raw["position"] == 128
        assert raw["tiltPosition"] == 0
        assert raw["positionPercent"] == 50
        assert raw["tiltPercent"] is None

    def test_raw_data_with_tilt(self) -> None:
        s = Shade(id=1, name="Silhouette", room_id=0, position=0, tilt_position=128, supports_tilt=True)
        raw = s.raw_data
        assert raw["position"] == 0
        assert raw["tiltPosition"] == 128
        assert raw["positionPercent"] == 0
        assert raw["tiltPercent"] == 50


# ---------------------------------------------------------------------------
# Scene
# ---------------------------------------------------------------------------


class TestScene:
    def test_defaults(self) -> None:
        sc = Scene()
        assert sc.id == 0
        assert sc.name == ""
        assert sc.links == []
        assert sc.room_positions == []

    def test_raw_data(self) -> None:
        sc = Scene(id=1, name="Evening")
        assert sc.raw_data == {"id": 1, "name": "Evening"}

    def test_links_independent(self) -> None:
        s1 = Scene()
        s2 = Scene()
        s1.links.append(SceneLink(shade_id=0))
        assert s2.links == []


# ---------------------------------------------------------------------------
# Shade.apply_move / apply_tilt
# ---------------------------------------------------------------------------


class TestShadeCommandSideEffects:
    """Tests for Shade.apply_move() and Shade.apply_tilt().

    These methods encode the hardware's side-effects:
    - Moving the primary position clears any existing tilt (vanes return flat).
    - Tilting the vanes closes the shade first (position driven to 0).
    """

    def test_apply_move_sets_position(self) -> None:
        shade = Shade(id=1, supports_tilt=True)
        shade.position = 0
        shade.apply_move(75)
        assert shade.position_percent == 75

    def test_apply_move_clears_tilt(self) -> None:
        shade = Shade(id=1, supports_tilt=True)
        shade.tilt_position = 128  # some active tilt
        shade.apply_move(50)
        assert shade.tilt_position == 0

    def test_apply_move_clears_tilt_even_when_closing(self) -> None:
        shade = Shade(id=1, supports_tilt=True)
        shade.tilt_position = 200
        shade.apply_move(0)
        assert shade.position_percent == 0
        assert shade.tilt_position == 0

    def test_apply_tilt_zeroes_position(self) -> None:
        shade = Shade(id=1, supports_tilt=True)
        shade.position = 200  # shade was open
        shade.apply_tilt(50)
        assert shade.position == 0

    def test_apply_tilt_sets_tilt_percent(self) -> None:
        shade = Shade(id=1, supports_tilt=True)
        shade.apply_tilt(75)
        assert shade.tilt_percent == 75

    def test_apply_tilt_zero(self) -> None:
        shade = Shade(id=1, supports_tilt=True)
        shade.position = 128
        shade.tilt_position = 200
        shade.apply_tilt(0)
        assert shade.position == 0
        assert shade.tilt_percent == 0

    def test_apply_tilt_reverse_updates_tilt_command(self) -> None:
        shade = Shade(id=1, supports_tilt=True, supports_tilt_reverse=True)
        shade.apply_tilt(25)  # lower half → cmd 19
        assert shade.tilt_command == 19
        assert shade.position == 0

    def test_apply_move_non_tilt_shade(self) -> None:
        shade = Shade(id=1, supports_tilt=False)
        shade.apply_move(60)
        assert shade.position_percent == 60
        assert shade.tilt_position == 0


# ---------------------------------------------------------------------------
# TimedEvent
# ---------------------------------------------------------------------------


class TestTimedEvent:
    def test_defaults(self) -> None:
        te = TimedEvent()
        assert te.scene_index == 0
        assert te.hour == 0
        assert te.minute == 0
        assert te.day_bits == 0
        assert te.enabled is False

    def test_with_values(self) -> None:
        te = TimedEvent(scene_index=1, hour=7, minute=30, day_bits=31, enabled=True)
        assert te.scene_index == 1
        assert te.hour == 7
        assert te.minute == 30
        assert te.day_bits == 31
        assert te.enabled is True


# ---------------------------------------------------------------------------
# House
# ---------------------------------------------------------------------------


class TestHouse:
    def test_defaults(self) -> None:
        h = House()
        assert h.name == ""
        assert h.rooms == {}
        assert h.shades == {}
        assert h.scenes == {}
        assert h.timed_events == []

    def test_dicts_are_independent(self) -> None:
        h1 = House()
        h2 = House()
        h1.rooms[0] = Room(id=0, name="Room A")
        assert h2.rooms == {}
