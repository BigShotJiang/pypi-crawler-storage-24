"""Tests for aiopowerrise.transport."""

from __future__ import annotations

import asyncio
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from aiopowerrise.exceptions import PowerRiseConnectionError, PowerRiseTimeoutError
from aiopowerrise.transport import Transport


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_reader(lines: list[str]) -> AsyncMock:
    """Create a mock StreamReader that yields the given lines."""
    reader = AsyncMock(spec=asyncio.StreamReader)
    responses = [(line + "\r\n").encode("ascii") for line in lines]
    # After all lines are read, return empty to signal EOF
    responses.append(b"")
    reader.readline = AsyncMock(side_effect=responses)
    return reader


def _make_writer() -> MagicMock:
    """Create a mock StreamWriter."""
    writer = MagicMock(spec=asyncio.StreamWriter)
    writer.write = MagicMock()
    writer.drain = AsyncMock()
    writer.close = MagicMock()
    writer.wait_closed = AsyncMock()
    return writer


# ---------------------------------------------------------------------------
# Connection
# ---------------------------------------------------------------------------


class TestConnect:
    @pytest.mark.asyncio
    async def test_connect_success(self) -> None:
        """Successful connection reads banner and sets connected."""
        reader = _make_reader(["Shade Controller V3.0"])
        writer = _make_writer()

        with patch("aiopowerrise.transport.asyncio.open_connection", new_callable=AsyncMock) as mock_open:
            mock_open.return_value = (reader, writer)
            transport = Transport("192.168.1.100")
            await transport.connect()
            assert transport.connected is True
            mock_open.assert_called_once()

    @pytest.mark.asyncio
    async def test_connect_timeout(self) -> None:
        """Connection timeout raises PowerRiseConnectionError."""
        with patch("aiopowerrise.transport.asyncio.open_connection", new_callable=AsyncMock) as mock_open:
            mock_open.side_effect = asyncio.TimeoutError()
            transport = Transport("192.168.1.100")

            with patch("aiopowerrise.transport.asyncio.wait_for", side_effect=asyncio.TimeoutError()):
                # The connect method wraps the open in wait_for
                with pytest.raises(PowerRiseConnectionError):
                    await transport.connect()
            assert transport.connected is False

    @pytest.mark.asyncio
    async def test_connect_os_error(self) -> None:
        """OS-level connection failure raises PowerRiseConnectionError."""
        with patch("aiopowerrise.transport.asyncio.wait_for", side_effect=OSError("Connection refused")):
            transport = Transport("192.168.1.100")
            with pytest.raises(PowerRiseConnectionError):
                await transport.connect()
            assert transport.connected is False

    @pytest.mark.asyncio
    async def test_already_connected(self) -> None:
        """Calling connect when already connected is a no-op."""
        reader = _make_reader(["Shade Controller V3.0"])
        writer = _make_writer()

        with patch("aiopowerrise.transport.asyncio.open_connection", new_callable=AsyncMock) as mock_open:
            mock_open.return_value = (reader, writer)
            transport = Transport("192.168.1.100")
            await transport.connect()
            # Second call should be a no-op
            await transport.connect()
            mock_open.assert_called_once()


# ---------------------------------------------------------------------------
# Close
# ---------------------------------------------------------------------------


class TestClose:
    @pytest.mark.asyncio
    async def test_close(self) -> None:
        reader = _make_reader(["Shade Controller V3.0"])
        writer = _make_writer()

        with patch("aiopowerrise.transport.asyncio.open_connection", new_callable=AsyncMock) as mock_open:
            mock_open.return_value = (reader, writer)
            transport = Transport("192.168.1.100")
            await transport.connect()
            assert transport.connected is True

            await transport.close()
            assert transport.connected is False
            writer.close.assert_called_once()


# ---------------------------------------------------------------------------
# Send command
# ---------------------------------------------------------------------------


class TestSendCommand:
    @pytest.mark.asyncio
    async def test_send_command_not_connected(self) -> None:
        transport = Transport("192.168.1.100")
        with pytest.raises(PowerRiseConnectionError):
            await transport.send_command("$dat", sentinel="$upd01-")

    @pytest.mark.asyncio
    async def test_send_command_with_sentinel(self) -> None:
        """Send a command and read until sentinel via the reader loop."""
        banner_lines = ["Shade Controller V3.0"]
        response_lines = ["$cr00-01--------Room A", "$upd01-"]
        all_lines = banner_lines + response_lines

        reader = _make_reader(all_lines)
        writer = _make_writer()

        with patch("aiopowerrise.transport.asyncio.open_connection", new_callable=AsyncMock) as mock_open:
            mock_open.return_value = (reader, writer)
            transport = Transport("192.168.1.100")
            await transport.connect()

            # Reset reader to provide command response and start reader loop
            reader.readline = AsyncMock(
                side_effect=[
                    b"$cr00-01--------Room A\r\n",
                    b"$upd01-\r\n",
                    b"",
                ]
            )
            transport.start_listener()

            lines = await transport.send_command("$dat", sentinel="$upd01-")
            assert len(lines) >= 1
            writer.write.assert_called()
            await transport.close()

    @pytest.mark.asyncio
    async def test_send_nowait_not_connected(self) -> None:
        transport = Transport("192.168.1.100")
        with pytest.raises(PowerRiseConnectionError):
            await transport.send_nowait("$rls")

    @pytest.mark.asyncio
    async def test_send_nowait_writes_without_reading(self) -> None:
        """send_nowait should write the command but not touch the reader."""
        banner_lines = ["Shade Controller V3.0"]
        reader = _make_reader(banner_lines)
        writer = _make_writer()

        with patch("aiopowerrise.transport.asyncio.open_connection", new_callable=AsyncMock) as mock_open:
            mock_open.return_value = (reader, writer)
            transport = Transport("192.168.1.100")
            await transport.connect()

            # Provide lines for the reader loop so it doesn't block the test
            reader.readline = AsyncMock(side_effect=[b""])

            writer.write.reset_mock()
            await transport.send_nowait("$rls")

            writer.write.assert_called_once_with(b"$rls\r\n")
            await transport.close()


# ---------------------------------------------------------------------------
# Properties
# ---------------------------------------------------------------------------


class TestProperties:
    def test_host(self) -> None:
        transport = Transport("192.168.1.50", port=1234)
        assert transport.host == "192.168.1.50"

    def test_port_default(self) -> None:
        transport = Transport("192.168.1.50")
        assert transport.port == 522

    def test_port_custom(self) -> None:
        transport = Transport("192.168.1.50", port=9999)
        assert transport.port == 9999

    def test_connected_default(self) -> None:
        transport = Transport("192.168.1.50")
        assert transport.connected is False


# ---------------------------------------------------------------------------
# Keepalive
# ---------------------------------------------------------------------------


class TestKeepalive:
    @pytest.mark.asyncio
    async def test_start_keepalive(self) -> None:
        """Starting keepalive creates a background task."""
        reader = _make_reader(["Shade Controller V3.0"])
        writer = _make_writer()

        with patch("aiopowerrise.transport.asyncio.open_connection", new_callable=AsyncMock) as mock_open:
            mock_open.return_value = (reader, writer)
            transport = Transport("192.168.1.100")
            await transport.connect()

            transport.start_keepalive()
            assert transport._keepalive_task is not None
            assert not transport._keepalive_task.done()

            # Clean up
            await transport.close()


# ---------------------------------------------------------------------------
# Listener loop error handling
# ---------------------------------------------------------------------------


class TestListenerLoop:
    @pytest.mark.asyncio
    async def test_connection_reset_stops_listener(self) -> None:
        """ConnectionResetError in readline sets connected=False and exits cleanly."""
        reader = AsyncMock(spec=asyncio.StreamReader)
        reader.readline = AsyncMock(side_effect=ConnectionResetError("[Errno 54] Connection reset by peer"))
        writer = _make_writer()

        with patch("aiopowerrise.transport.asyncio.open_connection", new_callable=AsyncMock) as mock_open:
            mock_open.return_value = (reader, writer)
            transport = Transport("192.168.1.100")
            transport._reader = reader
            transport._writer = writer
            transport._connected = True

            # Run _reader_loop; it should exit after the first OSError
            await transport._reader_loop()

        assert not transport.connected

    @pytest.mark.asyncio
    async def test_os_error_stops_listener(self) -> None:
        """Any OSError (broken pipe, reset, etc.) in readline disconnects cleanly."""
        reader = AsyncMock(spec=asyncio.StreamReader)
        reader.readline = AsyncMock(side_effect=OSError("Broken pipe"))
        writer = _make_writer()

        with patch("aiopowerrise.transport.asyncio.open_connection", new_callable=AsyncMock) as mock_open:
            mock_open.return_value = (reader, writer)
            transport = Transport("192.168.1.100")
            transport._reader = reader
            transport._writer = writer
            transport._connected = True

            await transport._reader_loop()

        assert not transport.connected

    @pytest.mark.asyncio
    async def test_clean_eof_stops_listener(self) -> None:
        """Empty readline (clean EOF) sets connected=False."""
        reader = AsyncMock(spec=asyncio.StreamReader)
        reader.readline = AsyncMock(return_value=b"")
        writer = _make_writer()

        with patch("aiopowerrise.transport.asyncio.open_connection", new_callable=AsyncMock) as mock_open:
            mock_open.return_value = (reader, writer)
            transport = Transport("192.168.1.100")
            transport._reader = reader
            transport._writer = writer
            transport._connected = True

            await transport._reader_loop()

        assert not transport.connected


# ---------------------------------------------------------------------------
# Connection number
# ---------------------------------------------------------------------------


class TestConnectionNumber:
    def test_connection_number_initially_none(self) -> None:
        """Before connecting, connection_number is None."""
        transport = Transport("192.168.1.100")
        assert transport.connection_number is None

    @pytest.mark.asyncio
    async def test_connection_number_parsed_from_banner(self) -> None:
        """The connection number is extracted from the hub's banner line."""
        # Hub sends "3 HunterDouglas Shade Controller" as banner
        reader = _make_reader(["3 HunterDouglas Shade Controller"])
        writer = _make_writer()

        with patch("aiopowerrise.transport.asyncio.open_connection", new_callable=AsyncMock) as mock_open:
            mock_open.return_value = (reader, writer)
            transport = Transport("192.168.1.100")
            await transport.connect()
            assert transport.connection_number == 3
            await transport.close()

    @pytest.mark.asyncio
    async def test_connection_number_bare_banner(self) -> None:
        """A banner without a leading number leaves connection_number as None."""
        reader = _make_reader(["Shade Controller V3.0"])
        writer = _make_writer()

        with patch("aiopowerrise.transport.asyncio.open_connection", new_callable=AsyncMock) as mock_open:
            mock_open.return_value = (reader, writer)
            transport = Transport("192.168.1.100")
            await transport.connect()
            assert transport.connection_number is None
            await transport.close()


# ---------------------------------------------------------------------------
# Connection-number prefix stripping in reader loop
# ---------------------------------------------------------------------------


class TestConnPrefixStripping:
    @pytest.mark.asyncio
    async def test_reader_loop_strips_conn_prefix(self) -> None:
        """Lines delivered to the callback must have the 'N ' prefix removed."""
        received: list[str] = []

        reader = AsyncMock(spec=asyncio.StreamReader)
        reader.readline = AsyncMock(
            side_effect=[
                b"3 $ack\r\n",
                b"3 $cr00-01--------Room A\r\n",
                b"",  # EOF
            ]
        )
        writer = _make_writer()

        transport = Transport("192.168.1.100")
        transport._reader = reader
        transport._writer = writer
        transport._connected = True
        transport.set_line_callback(received.append)

        await transport._reader_loop()

        assert received == ["$ack", "$cr00-01--------Room A"]

    @pytest.mark.asyncio
    async def test_reader_loop_passes_unprefixed_lines_unchanged(self) -> None:
        """Lines that have no 'N ' prefix are passed through unchanged."""
        received: list[str] = []

        reader = AsyncMock(spec=asyncio.StreamReader)
        reader.readline = AsyncMock(
            side_effect=[
                b"$ack\r\n",
                b"",  # EOF
            ]
        )
        writer = _make_writer()

        transport = Transport("192.168.1.100")
        transport._reader = reader
        transport._writer = writer
        transport._connected = True
        transport.set_line_callback(received.append)

        await transport._reader_loop()

        assert received == ["$ack"]


# ---------------------------------------------------------------------------
# Reconnect callback — fired after implicit send_command reconnect
# ---------------------------------------------------------------------------


class TestReconnectCallback:
    def test_set_reconnect_callback_stores_callable(self) -> None:
        """set_reconnect_callback stores the provided callable."""
        transport = Transport("192.168.1.100")
        cb = AsyncMock()
        transport.set_reconnect_callback(cb)
        assert transport._reconnect_callback is cb

    def test_set_reconnect_callback_accepts_none(self) -> None:
        """set_reconnect_callback(None) clears the callback."""
        transport = Transport("192.168.1.100")
        transport.set_reconnect_callback(AsyncMock())
        transport.set_reconnect_callback(None)
        assert transport._reconnect_callback is None

    @pytest.mark.asyncio
    async def test_reconnect_callback_called_after_auto_reconnect(self) -> None:
        """After an OSError forces a reconnect in send_command the reconnect
        callback should be scheduled as a task."""
        callback_called = asyncio.Event()

        async def _cb() -> None:
            callback_called.set()

        transport = Transport("192.168.1.100")
        transport._connected = True

        call_count = 0

        async def _fake_reconnect() -> None:
            # After reconnect the transport is "back up"
            pass

        async def _fake_collect(q: asyncio.Queue, sentinel: str | None, timeout: float) -> list[str]:
            return ["$ack"]

        with patch.object(transport, "reconnect", side_effect=_fake_reconnect):
            with patch.object(transport, "_collect_response", side_effect=_fake_collect):
                writer = MagicMock()
                writer.drain = AsyncMock()

                # First write raises OSError; after that the reconnect writer succeeds
                first_write = True

                def _raising_write(data: bytes) -> None:
                    nonlocal first_write
                    if first_write:
                        first_write = False
                        raise OSError("broken pipe")

                writer.write = _raising_write
                transport._writer = writer

                transport.set_reconnect_callback(_cb)

                result = await transport.send_command("$ack", sentinel="$ack", timeout=2.0)
                assert result == ["$ack"]

        # Give the event loop a chance to run the callback task
        await asyncio.sleep(0)
        assert callback_called.is_set()
