"""Tests for aiopowerrise.exceptions."""

from __future__ import annotations

import pytest

from aiopowerrise.exceptions import (
    CommandError,
    ConnectionError,
    HunterDouglasError,
    ParseError,
    PowerRiseError,
    TimeoutError,
)


class TestExceptionHierarchy:
    """All exceptions should inherit from PowerRiseError."""

    def test_connection_error(self) -> None:
        assert issubclass(ConnectionError, PowerRiseError)

    def test_command_error(self) -> None:
        assert issubclass(CommandError, PowerRiseError)

    def test_hunter_douglas_error(self) -> None:
        assert issubclass(HunterDouglasError, PowerRiseError)

    def test_parse_error(self) -> None:
        assert issubclass(ParseError, PowerRiseError)

    def test_timeout_error(self) -> None:
        assert issubclass(TimeoutError, PowerRiseError)


class TestHunterDouglasError:
    def test_known_error_code(self) -> None:
        exc = HunterDouglasError("03")
        assert exc.error_code == "03"
        assert "Shade not found" in str(exc)

    def test_unknown_error_code(self) -> None:
        exc = HunterDouglasError("99")
        assert exc.error_code == "99"
        assert "Unknown error code" in str(exc)

    def test_default_error_code(self) -> None:
        exc = HunterDouglasError()
        assert exc.error_code == "00"
        assert "Unknown error" in str(exc)

    @pytest.mark.parametrize(
        ("code", "expected_msg"),
        [
            ("01", "Invalid command"),
            ("02", "Invalid parameter"),
            ("03", "Shade not found"),
            ("04", "Room not found"),
            ("05", "Scene not found"),
            ("06", "Communication error"),
            ("07", "Timeout"),
            ("08", "Buffer overflow"),
            ("09", "System busy"),
        ],
    )
    def test_all_known_codes(self, code: str, expected_msg: str) -> None:
        exc = HunterDouglasError(code)
        assert expected_msg in str(exc)
