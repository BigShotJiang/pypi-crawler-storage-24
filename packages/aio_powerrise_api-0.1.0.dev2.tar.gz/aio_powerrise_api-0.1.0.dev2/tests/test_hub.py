"""Tests for aiopowerrise.hub."""

from __future__ import annotations

import asyncio
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from aiopowerrise.hub import Hub
from aiopowerrise.models import House
from tests.test_data import SAMPLE_DAT_RESPONSE


# ---------------------------------------------------------------------------
# Hub construction
# ---------------------------------------------------------------------------


class TestHubInit:
    def test_default_port(self) -> None:
        hub = Hub("192.168.1.100")
        assert hub.host == "192.168.1.100"
        assert hub.port == 522

    def test_custom_port(self) -> None:
        hub = Hub("192.168.1.100", port=9999)
        assert hub.port == 9999

    def test_not_connected(self) -> None:
        hub = Hub("192.168.1.100")
        assert hub.connected is False

    def test_house_initially_none(self) -> None:
        hub = Hub("192.168.1.100")
        assert hub.house is None
        assert hub.name is None
        assert hub.firmware_version is None

    def test_resource_managers(self) -> None:
        hub = Hub("192.168.1.100")
        assert hub.shades is not None
        assert hub.scenes is not None
        assert hub.rooms is not None


# ---------------------------------------------------------------------------
# Hub.get_data with mocked transport
# ---------------------------------------------------------------------------


class TestHubGetData:
    @pytest.mark.asyncio
    async def test_get_data_returns_house(self) -> None:
        hub = Hub("192.168.1.100")
        # Mock the transport's send_command to return sample data
        hub._transport.send_command = AsyncMock(return_value=SAMPLE_DAT_RESPONSE)
        hub._transport._connected = True
        hub._transport._writer = MagicMock()  # make connected property True

        house = await hub.get_data()
        assert isinstance(house, House)
        assert house.name == "My Home"
        assert len(house.rooms) == 3
        assert len(house.shades) == 4
        assert len(house.scenes) == 3

    @pytest.mark.asyncio
    async def test_get_data_stores_house(self) -> None:
        hub = Hub("192.168.1.100")
        hub._transport.send_command = AsyncMock(return_value=SAMPLE_DAT_RESPONSE)
        hub._transport._connected = True
        hub._transport._writer = MagicMock()

        await hub.get_data()
        assert hub.house is not None
        assert hub.name == "My Home"
        assert hub.firmware_version == 18


# ---------------------------------------------------------------------------
# Hub.ping
# ---------------------------------------------------------------------------


class TestHubPing:
    @pytest.mark.asyncio
    async def test_ping_success(self) -> None:
        hub = Hub("192.168.1.100")
        hub._transport.send_command = AsyncMock(return_value=["$ack"])
        hub._transport._connected = True
        hub._transport._writer = MagicMock()

        result = await hub.ping()
        assert result is True

    @pytest.mark.asyncio
    async def test_ping_failure(self) -> None:
        hub = Hub("192.168.1.100")
        hub._transport.send_command = AsyncMock(side_effect=Exception("timeout"))
        hub._transport._connected = True
        hub._transport._writer = MagicMock()

        result = await hub.ping()
        assert result is False


# ---------------------------------------------------------------------------
# Hub.connect — fetches $dat automatically
# ---------------------------------------------------------------------------


class TestHubConnect:
    @pytest.mark.asyncio
    async def test_connect_calls_get_data(self) -> None:
        """Hub.connect() should call get_data() so hub.house is populated."""
        hub = Hub("192.168.1.100")
        hub._transport.connect = AsyncMock()
        hub._transport.start_keepalive = MagicMock()
        hub._transport.set_disconnect_callback = MagicMock()
        hub._transport.set_reconnect_callback = MagicMock()
        hub._transport.send_command = AsyncMock(return_value=SAMPLE_DAT_RESPONSE)
        hub._transport._connected = True
        hub._transport._writer = MagicMock()

        await hub.connect()

        assert hub.house is not None
        hub._transport.set_disconnect_callback.assert_called_once()
        hub._transport.set_reconnect_callback.assert_called_once()

    @pytest.mark.asyncio
    async def test_connect_house_populated_after_connect(self) -> None:
        """house attribute is not None after a successful connect."""
        hub = Hub("192.168.1.100")
        hub._transport.connect = AsyncMock()
        hub._transport.start_keepalive = MagicMock()
        hub._transport.set_disconnect_callback = MagicMock()
        hub._transport.set_reconnect_callback = MagicMock()
        hub._transport.send_command = AsyncMock(return_value=SAMPLE_DAT_RESPONSE)
        hub._transport._connected = True
        hub._transport._writer = MagicMock()

        assert hub.house is None
        await hub.connect()
        assert hub.house is not None


# ---------------------------------------------------------------------------
# Hub reconnect callback — transport triggers get_data after auto-reconnect
# ---------------------------------------------------------------------------


class TestHubReconnectCallback:
    @pytest.mark.asyncio
    async def test_reconnect_callback_is_get_data(self) -> None:
        """Hub registers its get_data method as the transport reconnect callback."""
        hub = Hub("192.168.1.100")
        hub._transport.connect = AsyncMock()
        hub._transport.start_keepalive = MagicMock()
        hub._transport.set_disconnect_callback = MagicMock()
        hub._transport.set_reconnect_callback = MagicMock()
        hub._transport.send_command = AsyncMock(return_value=SAMPLE_DAT_RESPONSE)
        hub._transport._connected = True
        hub._transport._writer = MagicMock()

        await hub.connect()

        # The reconnect callback should be hub.get_data (bound method)
        args, _ = hub._transport.set_reconnect_callback.call_args
        cb = args[0]
        assert cb.__func__ is Hub.get_data
        assert cb.__self__ is hub


# ---------------------------------------------------------------------------
# Hub._on_disconnect — schedules a reconnect task
# ---------------------------------------------------------------------------


class TestHubOnDisconnect:
    @pytest.mark.asyncio
    async def test_on_disconnect_schedules_reconnect(self) -> None:
        """_on_disconnect creates a task that calls _reconnect_and_refresh."""
        hub = Hub("192.168.1.100")
        refreshed = asyncio.Event()

        async def fake_refresh() -> None:
            refreshed.set()

        with patch.object(hub, "_reconnect_and_refresh", side_effect=fake_refresh):
            hub._on_disconnect()
            # Give the event loop a tick to run the created task
            await asyncio.sleep(0)

        assert refreshed.is_set()


# ---------------------------------------------------------------------------
# Context manager
# ---------------------------------------------------------------------------


class TestHubContextManager:
    @pytest.mark.asyncio
    async def test_context_manager(self) -> None:
        """async with Hub() should connect and close."""
        with (
            patch.object(Hub, "connect", new_callable=AsyncMock) as mock_connect,
            patch.object(Hub, "close", new_callable=AsyncMock) as mock_close,
        ):
            async with Hub("192.168.1.100") as hub:
                mock_connect.assert_called_once()
            mock_close.assert_called_once()
