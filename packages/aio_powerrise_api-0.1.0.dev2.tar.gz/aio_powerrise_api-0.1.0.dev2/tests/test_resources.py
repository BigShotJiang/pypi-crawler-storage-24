"""Tests for aiopowerrise.resources (Shades, Scenes)."""

from __future__ import annotations

import asyncio
from unittest.mock import AsyncMock, MagicMock

import pytest

from aiopowerrise.const import (
    CMD_INVOKE_SCENE,
    CMD_POSITION_SHADE,
    CMD_RELEASE_SHADE,
    FEATURE_SHADE,
    FEATURE_TILT,
    FEATURE_TILT_REVERSE,
    RESP_DONE,
    SHADE_CMD_STOP,
)
from aiopowerrise.models import ShadePosition
from aiopowerrise.resources import Shades
from aiopowerrise.resources.scenes import Scenes


def _mock_transport() -> MagicMock:
    """Create a mock transport."""
    transport = MagicMock()
    transport.send_command = AsyncMock(return_value=["$done"])
    transport.send_nowait = AsyncMock(return_value=None)
    return transport


# ---------------------------------------------------------------------------
# Shades
# ---------------------------------------------------------------------------


class TestShades:
    @pytest.mark.asyncio
    async def test_move(self) -> None:
        transport = _mock_transport()
        shades = Shades(transport)
        await shades.move(shade_id=1, position=50)

        # $pss goes through send_command (expects $done response)
        assert transport.send_command.call_count == 1
        first_call = transport.send_command.call_args_list[0]
        cmd = first_call.args[0]
        assert cmd.startswith(CMD_POSITION_SHADE)
        assert "01" in cmd  # shade_id
        assert f"{FEATURE_SHADE}" in cmd
        wire = ShadePosition.to_wire(50)
        assert f"{wire:03d}" in cmd
        # $rls is fire-and-forget via send_nowait (no response expected)
        transport.send_nowait.assert_called_once_with(CMD_RELEASE_SHADE)

    @pytest.mark.asyncio
    async def test_open(self) -> None:
        transport = _mock_transport()
        shades = Shades(transport)
        await shades.open(shade_id=0)

        first_call = transport.send_command.call_args_list[0]
        cmd = first_call.args[0]
        wire = ShadePosition.to_wire(100)
        assert f"{wire:03d}" in cmd

    @pytest.mark.asyncio
    async def test_close(self) -> None:
        transport = _mock_transport()
        shades = Shades(transport)
        await shades.close(shade_id=0)

        first_call = transport.send_command.call_args_list[0]
        cmd = first_call.args[0]
        assert "000" in cmd  # wire position for 0%

    @pytest.mark.asyncio
    async def test_stop(self) -> None:
        transport = _mock_transport()
        shades = Shades(transport)
        await shades.stop(shade_id=2)
        # stop() is fire-and-forget by default but may also await a response
        # when wait=True; accept either behaviour for the test.
        if transport.send_nowait.call_count:
            transport.send_nowait.assert_called()
            # ensure it was sent as a $pss command
            args, _ = transport.send_nowait.call_args
            assert f"{SHADE_CMD_STOP}" in args[0]
        else:
            assert transport.send_command.call_count == 1
            cmd = transport.send_command.call_args_list[0].args[0]
            assert f"{SHADE_CMD_STOP}" in cmd

    @pytest.mark.asyncio
    async def test_tilt(self) -> None:
        transport = _mock_transport()
        shades = Shades(transport)
        await shades.tilt(shade_id=3, tilt_percent=75)

        # tilt() → move() → send_command($pss) + send_nowait($rls)
        assert transport.send_command.call_count == 1
        tilt_cmd = transport.send_command.call_args_list[0].args[0]
        assert FEATURE_TILT in tilt_cmd  # feature 07
        assert "03" in tilt_cmd  # shade_id 3
        transport.send_nowait.assert_called_once_with(CMD_RELEASE_SHADE)

    @pytest.mark.asyncio
    async def test_tilt_reverse_forward_half(self) -> None:
        """Luminette 0-50%: uses cmd 19 (reverse), wire 0-255."""
        transport = _mock_transport()
        shades = Shades(transport)
        # 25% of 0-50 range → wire = round(25 * 255 / 50) = 128
        await shades.tilt(shade_id=6, tilt_percent=25, supports_tilt_reverse=True)

        assert transport.send_command.call_count == 1
        tilt_cmd = transport.send_command.call_args_list[0].args[0]
        assert FEATURE_TILT_REVERSE in tilt_cmd  # cmd 19
        assert FEATURE_TILT not in tilt_cmd.replace(FEATURE_TILT_REVERSE, "")
        assert "128" in tilt_cmd  # wire 128
        transport.send_nowait.assert_called_once_with(CMD_RELEASE_SHADE)

    @pytest.mark.asyncio
    async def test_tilt_reverse_reverse_half(self) -> None:
        """Luminette 50-100%: uses cmd 07 (forward), wire 255-0."""
        transport = _mock_transport()
        shades = Shades(transport)
        # 75% → second half: wire = round((100-75) * 255 / 50) = 128
        await shades.tilt(shade_id=6, tilt_percent=75, supports_tilt_reverse=True)

        assert transport.send_command.call_count == 1
        tilt_cmd = transport.send_command.call_args_list[0].args[0]
        assert FEATURE_TILT in tilt_cmd  # cmd 07
        assert FEATURE_TILT_REVERSE not in tilt_cmd
        assert "128" in tilt_cmd  # wire 128
        transport.send_nowait.assert_called_once_with(CMD_RELEASE_SHADE)

    @pytest.mark.asyncio
    async def test_tilt_reverse_midpoint(self) -> None:
        """Luminette at 50%: reverse cmd 19, wire 255 (fully open)."""
        transport = _mock_transport()
        shades = Shades(transport)
        await shades.tilt(shade_id=6, tilt_percent=50, supports_tilt_reverse=True)

        assert transport.send_command.call_count == 1
        tilt_cmd = transport.send_command.call_args_list[0].args[0]
        assert FEATURE_TILT_REVERSE in tilt_cmd
        assert "255" in tilt_cmd  # wire max = fully open
        transport.send_nowait.assert_called_once_with(CMD_RELEASE_SHADE)

    @pytest.mark.asyncio
    async def test_jog(self) -> None:
        transport = _mock_transport()
        shades = Shades(transport)
        await shades.jog(shade_id=1)

        assert transport.send_command.call_count == 1
        cmd = transport.send_command.call_args_list[0].args[0]
        assert "12" in cmd  # test command code
        assert "000" in cmd  # position 0

    # -- shade= side-effect parameter ----------------------------------------

    @pytest.mark.asyncio
    async def test_move_updates_shade_position_and_clears_tilt(self) -> None:
        from aiopowerrise.models import Shade

        transport = _mock_transport()
        shades = Shades(transport)
        shade = Shade(id=1, supports_tilt=True)
        shade.tilt_position = 128  # had active tilt
        await shades.move(shade_id=1, position=60, shade=shade)
        assert shade.position_percent == 60
        assert shade.tilt_position == 0  # cleared by apply_move

    @pytest.mark.asyncio
    async def test_open_updates_shade(self) -> None:
        from aiopowerrise.models import Shade

        transport = _mock_transport()
        shades = Shades(transport)
        shade = Shade(id=1, supports_tilt=True)
        shade.tilt_position = 100
        await shades.open(shade_id=1, shade=shade)
        assert shade.position_percent == 100
        assert shade.tilt_position == 0

    @pytest.mark.asyncio
    async def test_close_updates_shade(self) -> None:
        from aiopowerrise.models import Shade

        transport = _mock_transport()
        shades = Shades(transport)
        shade = Shade(id=1, supports_tilt=True)
        shade.position = 200
        await shades.close(shade_id=1, shade=shade)
        assert shade.position_percent == 0
        assert shade.tilt_position == 0

    @pytest.mark.asyncio
    async def test_tilt_updates_shade_and_closes_position(self) -> None:
        from aiopowerrise.models import Shade

        transport = _mock_transport()
        shades = Shades(transport)
        shade = Shade(id=1, supports_tilt=True)
        shade.position = 200  # was open
        await shades.tilt(shade_id=1, tilt_percent=50, shade=shade)
        assert shade.position == 0  # closed by apply_tilt
        assert shade.tilt_percent == 50

    @pytest.mark.asyncio
    async def test_tilt_reverse_updates_shade(self) -> None:
        from aiopowerrise.models import Shade

        transport = _mock_transport()
        shades = Shades(transport)
        shade = Shade(id=1, supports_tilt=True, supports_tilt_reverse=True)
        shade.position = 150
        await shades.tilt(shade_id=1, tilt_percent=25, supports_tilt_reverse=True, shade=shade)
        assert shade.position == 0
        assert shade.tilt_command == 19  # lower half → cmd 19

    @pytest.mark.asyncio
    async def test_move_without_shade_no_error(self) -> None:
        """shade=None should still work and not crash."""
        transport = _mock_transport()
        shades = Shades(transport)
        await shades.move(shade_id=1, position=50)  # no shade= kwarg
        assert transport.send_command.call_count == 1
        transport.send_nowait.assert_called_once_with(CMD_RELEASE_SHADE)

    @pytest.mark.asyncio
    async def test_move_tilt_feature_does_not_call_apply_move(self) -> None:
        """Passing a tilt feature code to move() should NOT call apply_move."""
        from aiopowerrise.models import Shade

        transport = _mock_transport()
        shades = Shades(transport)
        shade = Shade(id=1, supports_tilt=True)
        shade.position = 200
        # Call with a tilt feature — apply_move should be skipped
        await shades.move(shade_id=1, position=50, feature=FEATURE_TILT, shade=shade)
        # position should be unchanged (apply_move not called for tilt features)
        assert shade.position == 200


# ---------------------------------------------------------------------------
# Scenes
# ---------------------------------------------------------------------------


class TestScenes:
    @pytest.mark.asyncio
    async def test_activate(self) -> None:
        transport = _mock_transport()
        scenes = Scenes(transport)
        await scenes.activate(scene_id=2)

        transport.send_command.assert_called_once()
        cmd = transport.send_command.call_args.args[0]
        assert cmd == f"{CMD_INVOKE_SCENE}02-"
