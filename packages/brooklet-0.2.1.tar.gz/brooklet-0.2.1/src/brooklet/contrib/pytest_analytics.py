# ABOUTME: pytest-reportlog adapter — consumes pytest JSONL and produces run stats
# ABOUTME: Exercises brooklet register/consume/produce with a non-Claude-Code source

import glob as glob_module
import hashlib
import json
import sys
from collections.abc import Iterator
from dataclasses import dataclass, field
from pathlib import Path
from typing import Annotated

import typer

import brooklet
from brooklet.plugins import hookimpl
from brooklet.types import Mode

RECOGNIZED_REPORT_TYPES = {"SessionStart", "CollectReport", "TestReport", "SessionFinish"}


# ---------------------------------------------------------------------------
# Layer 1: Parsing (pure functions, no I/O)
# ---------------------------------------------------------------------------


def parse_test_event(event: dict) -> dict | None:
    """Extract fields from a single pytest-reportlog JSONL event.

    Returns a normalized dict with report_type, nodeid, outcome, when,
    duration, and longrepr. Returns None if the event lacks a recognized
    $report_type.
    """
    report_type = event.get("$report_type")
    if report_type not in RECOGNIZED_REPORT_TYPES:
        return None

    raw_duration = event.get("duration")
    duration = float(raw_duration) if isinstance(raw_duration, (int, float)) else 0.0

    return {
        "report_type": report_type,
        "nodeid": event.get("nodeid"),
        "outcome": event.get("outcome"),
        "when": event.get("when"),
        "duration": duration,
        "longrepr": event.get("longrepr"),
    }


def is_test_result(parsed: dict) -> bool:
    """Return True if the parsed event is an actual test execution result.

    Filters to TestReport events in the "call" phase, excluding
    setup/teardown lifecycle events and session-level reports.
    """
    return parsed.get("report_type") == "TestReport" and parsed.get("when") == "call"


@dataclass
class RunStats:
    """Aggregated statistics for a single pytest test run."""

    run_id: str
    total: int = 0
    passed: int = 0
    failed: int = 0
    skipped: int = 0
    errored: int = 0
    duration_s: float = 0.0
    slowest: list[dict] = field(default_factory=list)
    failures: list[dict] = field(default_factory=list)

    def to_dict(self) -> dict:
        """Convert to a plain dict for JSONL serialization."""
        return {
            "run_id": self.run_id,
            "total": self.total,
            "passed": self.passed,
            "failed": self.failed,
            "skipped": self.skipped,
            "errored": self.errored,
            "duration_s": self.duration_s,
            "slowest": list(self.slowest),
            "failures": list(self.failures),
        }


def aggregate_run(run_id: str, events: list[dict]) -> RunStats:
    """Aggregate raw pytest-reportlog events into per-run statistics.

    Parses events, filters to test results (TestReport + call phase),
    then counts outcomes, sums duration, and collects slowest/failures.

    Args:
        run_id: Identifier for this run (typically filename stem).
        events: List of raw event dicts from the JSONL file.
    """
    stats = RunStats(run_id=run_id)

    parsed_results = []
    for raw in events:
        parsed = parse_test_event(raw)
        if parsed is not None and is_test_result(parsed):
            parsed_results.append(parsed)

    stats.total = len(parsed_results)

    for result in parsed_results:
        outcome = result["outcome"]
        if outcome == "passed":
            stats.passed += 1
        elif outcome == "failed":
            stats.failed += 1
            stats.failures.append(
                {
                    "nodeid": result["nodeid"],
                    "longrepr": result.get("longrepr") or "",
                }
            )
        elif outcome == "skipped":
            stats.skipped += 1
        elif outcome == "error":
            stats.errored += 1

        stats.duration_s += result.get("duration", 0.0) or 0.0

    # Slowest 5 tests by duration (descending)
    by_duration = sorted(parsed_results, key=lambda r: r.get("duration", 0.0), reverse=True)
    stats.slowest = [{"nodeid": r["nodeid"], "duration": r["duration"]} for r in by_duration[:5]]

    return stats


# ---------------------------------------------------------------------------
# Layer 2: Consumer integration (uses brooklet API)
# ---------------------------------------------------------------------------


def _run_id_from_path(filepath: str) -> str:
    """Extract run ID from a JSONL filename (stem)."""
    return Path(filepath).stem


def _topic_for_path(path: str) -> str:
    """Derive a unique topic name from a file path or glob pattern.

    Uses a short hash of the absolute path to avoid offset collisions
    when different files are consumed from the same stream directory.
    """
    abs_path = str(Path(path).resolve())
    short_hash = hashlib.sha256(abs_path.encode()).hexdigest()[:8]
    return f"pytest/{short_hash}"


def _parse_file_events(filepath: str) -> list[dict]:
    """Parse all events from a single pytest-reportlog JSONL file.

    Reads the file directly without brooklet offset tracking.
    Used in batch mode where we want to see all results every run.
    """
    events = []
    skipped_lines = 0
    total_lines = 0
    with open(filepath) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            total_lines += 1
            try:
                events.append(json.loads(line))
            except json.JSONDecodeError:
                skipped_lines += 1
                continue
    if skipped_lines and total_lines:
        print(
            f"Warning: {filepath}: {skipped_lines}/{total_lines} lines failed JSON parsing",
            file=sys.stderr,
        )
    return events


def scan_runs(
    path: str,
    mode: Mode = "single-file",
    follow: bool = False,
    stream: brooklet.Stream | None = None,
) -> Iterator[RunStats]:
    """Scan pytest report log(s) and yield per-run statistics.

    In batch mode (follow=False), reads files directly — no offset tracking,
    so every invocation sees all results. In follow mode, uses brooklet's
    consumer API for offset tracking and tailing.

    Args:
        path: File path (single-file) or glob pattern (glob mode).
        mode: Either "single-file" or "glob".
        follow: If True, tail for new events via brooklet consumer.
        stream: Optional brooklet Stream to use (follow mode only).

    Raises:
        ValueError: If mode is not "single-file" or "glob".
        FileNotFoundError: If path does not exist in single-file mode.
    """
    valid_modes = {"single-file", "glob"}
    if mode not in valid_modes:
        msg = f"mode must be one of {valid_modes}, got {mode!r}"
        raise ValueError(msg)

    if mode == "single-file" and not Path(path).exists():
        msg = f"Report log not found: {path}"
        raise FileNotFoundError(msg)

    if follow:
        # Follow mode: use brooklet consumer for offset tracking and tailing
        if stream is None:
            parent_dir = str(Path(path).parent)
            stream = brooklet.open(parent_dir)

        topic = _topic_for_path(path)
        stream.register(topic, path, mode)
        with stream.consume(topic, group="pytest-analytics", follow=True) as consumer:
            run_id = _run_id_from_path(path)
            events: list[dict] = []
            for event in consumer:
                events.append(event)
                yield aggregate_run(run_id, events)
    elif mode == "single-file":
        # Batch: read file directly, no offsets
        events = _parse_file_events(path)
        if events:
            run_id = _run_id_from_path(path)
            yield aggregate_run(run_id, events)
    elif mode == "glob":
        # Batch: each file is a separate run, read directly
        filepaths = sorted(glob_module.glob(path))
        for filepath in filepaths:
            events = _parse_file_events(filepath)
            if events:
                run_id = _run_id_from_path(filepath)
                yield aggregate_run(run_id, events)


# ---------------------------------------------------------------------------
# Layer 3: Output renderers and CLI
# ---------------------------------------------------------------------------


def _format_duration(seconds: float) -> str:
    """Format seconds into human-readable duration."""
    if seconds < 1:
        return f"{seconds * 1000:.0f}ms"
    if seconds < 60:
        return f"{seconds:.1f}s"
    return f"{seconds / 60:.1f}m"


def render_run_block(stats: RunStats) -> str:
    """Render a single run's stats as plain text."""
    lines = []
    lines.append(f"--- run {stats.run_id} ---")
    lines.append(
        f"  {stats.total} tests: "
        f"{stats.passed} passed, {stats.failed} failed, "
        f"{stats.skipped} skipped, {stats.errored} errored"
    )
    lines.append(f"  duration: {_format_duration(stats.duration_s)}")

    if stats.slowest:
        lines.append("  slowest:")
        for entry in stats.slowest[:5]:
            lines.append(f"    {_format_duration(entry['duration'])}  {entry['nodeid']}")

    if stats.failures:
        lines.append("  failures:")
        for entry in stats.failures:
            short = (entry["longrepr"] or "").split("\n")[0][:120]
            lines.append(f"    FAIL {entry['nodeid']}")
            if short:
                lines.append(f"         {short}")

    return "\n".join(lines)


def render_cumulative(runs: list[RunStats]) -> str:
    """Render aggregate totals across all runs."""
    if not runs:
        return "No runs processed."

    total = sum(r.total for r in runs)
    passed = sum(r.passed for r in runs)
    failed = sum(r.failed for r in runs)
    skipped = sum(r.skipped for r in runs)
    errored = sum(r.errored for r in runs)
    duration = sum(r.duration_s for r in runs)

    lines = []
    lines.append(f"\n=== {len(runs)} runs totals ===")
    lines.append(
        f"  {total} tests: {passed} passed, {failed} failed, {skipped} skipped, {errored} errored"
    )
    lines.append(f"  duration: {_format_duration(duration)}")
    return "\n".join(lines)


class PytestPlugin:
    """Pluggy plugin that registers pytest CLI commands."""

    @hookimpl
    def brooklet_commands(self, cli):
        pytest_app = typer.Typer(help="pytest-reportlog analytics")

        @pytest_app.command()
        def scan(
            path: Annotated[str, typer.Argument(help="Path to report log file or glob pattern.")],
            glob: Annotated[bool, typer.Option(help="Treat path as a glob pattern.")] = False,
            follow: Annotated[bool, typer.Option(help="Tail for new test events.")] = False,
            output: Annotated[
                str | None, typer.Option(help="Produce stats to a brooklet topic.")
            ] = None,
            stream_dir: Annotated[
                Path | None,
                typer.Option(
                    "--stream-dir",
                    envvar="BROOKLET_DIR",
                    help="Stream directory for --output topic. Defaults to report file's parent.",
                ),
            ] = None,
        ) -> None:
            """Consume pytest-reportlog JSONL and report test analytics."""
            mode = "glob" if glob else "single-file"

            if not glob and not Path(path).exists():
                typer.echo(f"Error: File not found: {path}", err=True)
                raise typer.Exit(code=1)

            runs: list[RunStats] = []
            try:
                parent_dir = str(Path(path).resolve().parent)
                # Only open a stream when needed — batch mode reads files directly
                stream = None
                if output or follow:
                    stream = brooklet.open(stream_dir or parent_dir)

                stats_iter = scan_runs(path=path, mode=mode, follow=follow, stream=stream)

                if output:
                    original_iter = stats_iter

                    def producing_iter():
                        for stats in original_iter:
                            try:
                                stream.produce(output, stats.to_dict(), source="pytest-analytics")
                            except (OSError, ValueError, TypeError) as e:
                                typer.echo(
                                    f"Warning: failed to produce run {stats.run_id} "
                                    f"to topic {output!r}: {e}",
                                    err=True,
                                )
                            yield stats

                    stats_iter = producing_iter()

                for stats in stats_iter:
                    runs.append(stats)
                    typer.echo(render_run_block(stats))
                typer.echo(render_cumulative(runs))
            except KeyboardInterrupt:
                if runs:
                    typer.echo(render_cumulative(runs))
            except BrokenPipeError:
                pass
            except (FileNotFoundError, ValueError) as e:
                typer.echo(f"Error: {e}", err=True)
                raise typer.Exit(code=1) from None

        cli.add_typer(pytest_app, name="pytest")
