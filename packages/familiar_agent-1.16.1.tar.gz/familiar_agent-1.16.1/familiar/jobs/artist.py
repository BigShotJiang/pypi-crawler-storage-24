# Familiar - Self-Hosted AI Companion Platform
# Copyright (c) 2026 George Scott Foley
# ORCID: 0009-0006-4957-0540
# Email: Georgescottfoley@proton.me
# Licensed under the MIT License - see LICENSE file for details

"""Artist job class — studio management, commissions, shows, inventory, and sales."""

from . import JobClass, register_job_class

ARTIST = JobClass(
    key="artist",
    name="Artist",
    icon="fa-palette",
    description="Studio management, commissions, shows, inventory, and sales",
    prompt_fragment="""You are operating in Artist mode — a studio and gallery management assistant. Your focus areas:
- **Piece tracking**: Track artwork through the full lifecycle — concept, in-progress, drying, firing, glazing, finished, listed, sold. Document materials, dimensions, and photos.
- **Commission management**: Track custom orders from inquiry to delivery — pricing, deposits, due dates, client communication, progress updates.
- **Shows & events**: Manage gallery shows, craft markets, studio tours, and exhibitions — submissions, booth fees, inventory selection, logistics.
- **Materials inventory**: Track supplies (clay, glazes, oxides, tools, kiln supplies) with reorder points. Calculate material costs per piece.
- **Client relations**: Maintain collector/buyer contacts with purchase history, preferences, and follow-up reminders. Build mailing list for shows.
- **Pricing**: Help calculate pricing based on materials, time, kiln costs, overhead, and market positioning. Track what sells at what price points.
- **Classes & workshops**: Schedule teaching sessions, track students, manage class materials and capacity.
- **Kiln management**: Log firing schedules, temperatures, cone ratings, and results. Track kiln maintenance.
- **Consignment**: Track pieces placed at other galleries — location, terms, sell-through rates.
- **Social & marketing**: Help plan content for social media, document process shots, draft artist statements and show applications.""",
    skill_weights={
        "write_note": 0.9,
        "search_notes": 0.8,
        "calendar_create": 0.8,
        "calendar_list": 0.7,
        "send_email": 0.7,
        "draft_email": 0.8,
        "contact_add": 0.7,
        "contact_search": 0.7,
        "bookkeeping_add": 0.8,
        "bookkeeping_summary": 0.7,
        "web_search": 0.6,
        "web_read": 0.6,
        "remember": 0.8,
        "recall": 0.8,
        "query_chairman": 0.7,
        "smart_intake": 0.5,
        "review_intake": 0.4,
    },
    species_flavor={
        "fox": (
            "Your fox brings creative charm — networking at openings,"
            " finding opportunities, and making each piece tell a story."
        ),
        "owl": (
            "Your owl brings methodical craft — precise kiln logs,"
            " detailed cost tracking, and carefully documented glazes."
        ),
        "cat": (
            "Your cat brings artistic instinct — curating shows with effortless taste,"
            " pricing with confidence, and knowing what collectors want."
        ),
        "dragon": (
            "Your dragon brings bold vision — ambitious commissions,"
            " commanding gallery presence, and fierce creative drive."
        ),
        "wolf": (
            "Your wolf brings steady dedication — building lasting collector"
            " relationships, maintaining consistent practice, and reliable delivery."
        ),
        "frog": (
            "Your frog brings playful experimentation — wild glaze tests,"
            " unexpected forms, and the joy of happy accidents at the wheel."
        ),
    },
    recommended_connects=[
        "email",
        "calendar",
        "etsy",
        "stripe",
        "square",
        "todoist",
        "instagram",
        "cloudinary_img",
    ],
    proactive_focus=[
        "check on commission deadlines",
        "remind about upcoming show submission dates",
        "flag materials running low",
        "follow up with clients after purchases",
        "kiln firing schedule reminders",
    ],
    workspace={
        "label": "Studio Manager",
        "icon": "fa-palette",
        "description": (
            "Your studio hub — track pieces, commissions,"
            " shows, materials, and clients all in one place."
        ),
        "overview": {
            "cards": [
                {
                    "key": "server_setup_cta",
                    "type": "cta",
                    "icon": "fa-palette",
                    "color": "#c084fc",
                    "label": "Studio Server",
                    "message": (
                        "Set up your studio's own server — Gitea for version"
                        " control, Jellyfin for media, Nextcloud for files,"
                        " and GoToSocial for sharing your work."
                        " One click, no tech skills needed."
                    ),
                    "button_label": "Set Up Studio Server",
                    "button_action": "full_server_setup",
                    "source": "server",
                    "show_when": "needs_setup",
                    "service_keys": ["gitea", "jellyfin", "nextcloud", "gotosocial"],
                },
                {
                    "key": "studio_services",
                    "type": "service_status",
                    "icon": "fa-palette",
                    "color": "#c084fc",
                    "label": "Studio Services",
                    "source": "server",
                    "service_keys": [
                        "gitea",
                        "jellyfin",
                        "nextcloud",
                        "gotosocial",
                    ],
                },
                {
                    "key": "active_pieces",
                    "label": "In Progress",
                    "icon": "fa-hands",
                    "color": "#60a5fa",
                    "source": "studio",
                    "metric": "pieces.in_progress_count",
                    "format": "number",
                },
                {
                    "key": "open_commissions",
                    "label": "Commissions",
                    "icon": "fa-file-signature",
                    "color": "#fbbf24",
                    "source": "studio",
                    "metric": "commissions.open_count",
                    "format": "number",
                },
                {
                    "key": "upcoming_shows",
                    "label": "Upcoming Shows",
                    "icon": "fa-calendar-star",
                    "color": "#c084fc",
                    "source": "studio",
                    "metric": "shows.upcoming_count",
                    "format": "number",
                },
                {
                    "key": "revenue_mtd",
                    "label": "Sales (MTD)",
                    "icon": "fa-dollar-sign",
                    "color": "#4ade80",
                    "source": "studio",
                    "metric": "revenue_mtd",
                    "format": "currency",
                },
                {
                    "key": "low_materials",
                    "label": "Low Stock",
                    "icon": "fa-triangle-exclamation",
                    "color": "#f87171",
                    "source": "studio",
                    "metric": "materials.low_stock_count",
                    "format": "number",
                },
                {
                    "key": "total_clients",
                    "label": "Clients",
                    "icon": "fa-address-book",
                    "color": "#fb923c",
                    "source": "studio",
                    "metric": "clients.count",
                    "format": "number",
                },
            ],
        },
        "sections": [
            {
                "key": "pieces",
                "label": "Pieces",
                "icon": "fa-hands",
                "type": "pipeline",
                "source": "studio",
                "source_key": "pieces",
                "empty_message": "No pieces tracked yet. Tell me about something you're working on and I'll start tracking it!",
                "service_key": "jellyfin",
                "stages": [
                    "concept",
                    "in_progress",
                    "drying",
                    "bisque_fire",
                    "glazing",
                    "glaze_fire",
                    "finished",
                    "listed",
                    "sold",
                ],
                "stage_field": "status",
                "card_title_field": "name",
                "card_subtitle_field": "type",
                "card_badge_field": "price",
                "card_badge_format": "currency",
            },
            {
                "key": "commissions",
                "label": "Commissions",
                "icon": "fa-file-signature",
                "type": "table",
                "source": "studio",
                "source_key": "commissions",
                "empty_message": "No commissions yet. When a client requests a piece, use 'New Commission' to track it here!",
                "columns": [
                    {"key": "client", "label": "Client", "type": "text", "sortable": True},
                    {
                        "key": "description",
                        "label": "Description",
                        "type": "text",
                        "sortable": False,
                    },
                    {"key": "price", "label": "Price", "type": "currency", "sortable": True},
                    {"key": "deposit", "label": "Deposit", "type": "currency", "sortable": True},
                    {"key": "due_date", "label": "Due", "type": "date", "sortable": True},
                    {"key": "status", "label": "Status", "type": "badge", "sortable": True},
                ],
                "default_sort": "due_date",
                "default_sort_dir": "asc",
                "row_actions": [
                    {
                        "key": "update_client",
                        "label": "Update Client",
                        "icon": "fa-envelope",
                        "mode": "agent",
                        "prompt_template": (
                            "Draft a progress update email to {client}"
                            " about their commission: {description}."
                            " Status: {status}."
                        ),
                    },
                ],
            },
            {
                "key": "shows",
                "label": "Shows & Events",
                "icon": "fa-store",
                "type": "table",
                "source": "studio",
                "source_key": "shows",
                "empty_message": "No shows scheduled yet. Tell me about an upcoming show or market and I'll help you prepare!",
                "columns": [
                    {"key": "name", "label": "Event", "type": "text", "sortable": True},
                    {"key": "venue", "label": "Venue", "type": "text", "sortable": True},
                    {"key": "date", "label": "Date", "type": "date", "sortable": True},
                    {"key": "type", "label": "Type", "type": "badge", "sortable": True},
                    {
                        "key": "pieces_count",
                        "label": "Pieces",
                        "type": "number",
                        "sortable": True,
                    },
                    {"key": "status", "label": "Status", "type": "badge", "sortable": True},
                ],
                "default_sort": "date",
                "default_sort_dir": "asc",
                "row_actions": [
                    {
                        "key": "select_pieces",
                        "label": "Select Pieces",
                        "icon": "fa-hand-pointer",
                        "mode": "agent",
                        "prompt_template": (
                            "Help me select pieces for {name} at {venue}."
                            " Show me what's available in my finished inventory"
                            " and recommend a cohesive selection."
                        ),
                    },
                ],
            },
            {
                "key": "materials",
                "label": "Materials",
                "icon": "fa-boxes-stacked",
                "type": "table",
                "source": "studio",
                "source_key": "materials",
                "empty_message": "No materials tracked yet. Tell me what supplies you use and I'll track stock levels for you!",
                "columns": [
                    {"key": "name", "label": "Material", "type": "text", "sortable": True},
                    {"key": "category", "label": "Category", "type": "badge", "sortable": True},
                    {
                        "key": "quantity",
                        "label": "Qty",
                        "type": "number",
                        "sortable": True,
                    },
                    {"key": "unit", "label": "Unit", "type": "text", "sortable": False},
                    {
                        "key": "reorder_at",
                        "label": "Reorder At",
                        "type": "number",
                        "sortable": True,
                    },
                    {"key": "supplier", "label": "Supplier", "type": "text", "sortable": True},
                ],
                "default_sort": "category",
                "default_sort_dir": "asc",
                "row_actions": [
                    {
                        "key": "reorder",
                        "label": "Reorder",
                        "icon": "fa-cart-shopping",
                        "mode": "agent",
                        "prompt_template": (
                            "I need to reorder {name} from {supplier}."
                            " Current qty: {quantity} {unit},"
                            " reorder point: {reorder_at}."
                        ),
                    },
                ],
            },
            {
                "key": "clients",
                "label": "Clients",
                "icon": "fa-address-book",
                "type": "table",
                "source": "studio",
                "source_key": "clients",
                "empty_message": "No clients yet. I'll add people here as you make sales or take commissions!",
                "service_key": "nextcloud",
                "columns": [
                    {"key": "name", "label": "Name", "type": "text", "sortable": True},
                    {"key": "email", "label": "Email", "type": "text", "sortable": True},
                    {
                        "key": "total_spent",
                        "label": "Total Spent",
                        "type": "currency",
                        "sortable": True,
                    },
                    {
                        "key": "pieces_owned",
                        "label": "Pieces",
                        "type": "number",
                        "sortable": True,
                    },
                    {
                        "key": "last_purchase",
                        "label": "Last Purchase",
                        "type": "date",
                        "sortable": True,
                    },
                    {"key": "notes", "label": "Notes", "type": "text", "sortable": False},
                ],
                "default_sort": "total_spent",
                "default_sort_dir": "desc",
                "row_actions": [
                    {
                        "key": "invite",
                        "label": "Invite to Show",
                        "icon": "fa-envelope",
                        "mode": "agent",
                        "prompt_template": (
                            "Draft an invitation email to {name} ({email})"
                            " for my next upcoming show. Personalize it based"
                            " on their collection interests."
                        ),
                    },
                ],
            },
        ],
        "quick_actions": [
            {
                "key": "log_piece",
                "label": "Log New Piece",
                "icon": "fa-plus",
                "mode": "js",
                "js_fn": "artShowPieceModal",
            },
            {
                "key": "new_commission",
                "label": "New Commission",
                "icon": "fa-file-signature",
                "mode": "js",
                "js_fn": "artShowCommissionModal",
            },
            {
                "key": "add_show",
                "label": "Add Show",
                "icon": "fa-calendar-plus",
                "mode": "js",
                "js_fn": "artShowShowModal",
            },
            {
                "key": "material_order",
                "label": "Material Order",
                "icon": "fa-cart-shopping",
                "mode": "agent",
                "prompt": (
                    "Help me check which materials are running low"
                    " and draft supply orders to the appropriate suppliers."
                ),
            },
            {
                "key": "price_calculator",
                "label": "Price Calculator",
                "icon": "fa-calculator",
                "mode": "agent",
                "prompt": (
                    "Help me price a piece. I'll tell you the materials,"
                    " time spent, kiln costs, and you'll help me calculate"
                    " a fair price based on costs and market positioning."
                ),
            },
            {
                "key": "kiln_log",
                "label": "Kiln Log",
                "icon": "fa-fire-burner",
                "mode": "agent",
                "prompt": (
                    "I want to log a kiln firing."
                    " Help me record the date, cone/temperature,"
                    " firing type (bisque/glaze/lustre),"
                    " pieces loaded, and results."
                ),
            },
            {
                "key": "generate_image",
                "label": "Generate Image",
                "icon": "fa-wand-magic-sparkles",
                "mode": "js",
                "js_fn": "artShowGenModal",
            },
            {
                "key": "view_gallery",
                "label": "View Gallery",
                "icon": "fa-images",
                "mode": "navigate",
                "target": "gallery",
            },
            {
                "key": "register_artwork",
                "label": "Register Artwork",
                "icon": "fa-certificate",
                "mode": "agent",
                "prompt": (
                    "I want to register an artwork in my gallery"
                    " with provenance chain verification."
                    " Ask me for the image file, title, medium,"
                    " dimensions, and whether I want visible"
                    " watermark, invisible steganography, or QR code."
                ),
            },
        ],
    },
)

register_job_class(ARTIST)
