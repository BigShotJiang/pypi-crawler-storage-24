# Hybrid optimizers
