"""
K线形态识别模块 - 基于CandleKit库实现

本模块使用CandleKit专业K线形态识别库，提供科学、可靠的形态识别功能。
CandleKit基于Steve Nison的《Japanese Candlestick Charting Techniques》实现。
"""

import json
from typing import Dict, List, Optional, Union
from enum import Enum

import pandas as pd

# CandleKit 库
from candlekit import CandlePatterns, scan_symbol_df, detect_pattern_at_index
from candlekit.entity import CandleStick


# --------------------------------------------------------------------------- #
#  形态元数据映射 - 将CandleKit的形态映射到中文名称和详细描述                  #
# --------------------------------------------------------------------------- #


class PatternType(Enum):
    """形态类型"""

    SINGLE = "single"
    DOUBLE = "double"
    TRIPLE = "triple"
    FIVE = "five"


# 形态元数据：{CandlePatterns枚举: (中文名, 英文名, 默认强度, 描述)}
PATTERN_METADATA: Dict[CandlePatterns, Dict] = {
    # ==================== 单蜡烛形态 ====================
    CandlePatterns.Doji: {
        "name": "十字星",
        "name_en": "Doji",
        "type": PatternType.SINGLE,
        "strength": 2,
        "description": "多空均衡，趋势可能转变，需结合前后K线判断",
    },
    CandlePatterns.Hammer: {
        "name": "锤子线",
        "name_en": "Hammer",
        "type": PatternType.SINGLE,
        "strength": 4,
        "description": "卖方把价格大力压低后买方强力反弹，出现在下跌底部时为有效底部反转信号，需次日阳线确认",
    },
    CandlePatterns.ShootingStar: {
        "name": "射击之星",
        "name_en": "Shooting Star",
        "type": PatternType.SINGLE,
        "strength": 4,
        "description": "买方将价格推高后被卖方大力压回，出现在上涨趋势顶部时为强烈顶部反转信号",
    },
    CandlePatterns.BullishMarubozu: {
        "name": "光头光脚阳线",
        "name_en": "Bullish Marubozu",
        "type": PatternType.SINGLE,
        "strength": 5,
        "description": "全程买方控制，开盘即最低、收盘即最高，极强多头信号",
    },
    CandlePatterns.BearishMarubozu: {
        "name": "光头光脚阴线",
        "name_en": "Bearish Marubozu",
        "type": PatternType.SINGLE,
        "strength": 5,
        "description": "全程卖方控制，开盘即最高、收盘即最低，极强空头信号",
    },
    CandlePatterns.BullishBeltHold: {
        "name": "捉腰带阳线",
        "name_en": "Bullish Belt Hold",
        "type": PatternType.SINGLE,
        "strength": 4,
        "description": "无下影线，开盘即最低，全程上涨，买方力量强劲",
    },
    CandlePatterns.BearishBeltHold: {
        "name": "捉腰带阴线",
        "name_en": "Bearish Belt Hold",
        "type": PatternType.SINGLE,
        "strength": 4,
        "description": "无上影线，开盘即最高，全程下跌，卖方力量强劲",
    },
    # ==================== 双蜡烛形态 ====================
    CandlePatterns.BullishEngulfing: {
        "name": "看涨吞噬",
        "name_en": "Bullish Engulfing",
        "type": PatternType.DOUBLE,
        "strength": 5,
        "description": "阳线实体完全吞没前根阴线实体，多方强势逆转，为强烈底部反转信号",
    },
    CandlePatterns.BearishEngulfing: {
        "name": "看跌吞噬",
        "name_en": "Bearish Engulfing",
        "type": PatternType.DOUBLE,
        "strength": 5,
        "description": "阴线实体完全吞没前根阳线实体，空方强势逆转，为强烈顶部反转信号",
    },
    CandlePatterns.PiercingLine: {
        "name": "刺穿形态",
        "name_en": "Piercing Line",
        "type": PatternType.DOUBLE,
        "strength": 4,
        "description": "阳线跳空低开后强力反弹，收盘超越前阴线实体中点，底部看涨反转信号",
    },
    CandlePatterns.DarkCloudCover: {
        "name": "乌云盖顶",
        "name_en": "Dark Cloud Cover",
        "type": PatternType.DOUBLE,
        "strength": 4,
        "description": "阴线跳空高开后大幅下跌，收盘低于前阳线实体中点，顶部看跌反转信号",
    },
    CandlePatterns.HaramiCrossBullish: {
        "name": "看涨孕十字",
        "name_en": "Bullish Harami Cross",
        "type": PatternType.DOUBLE,
        "strength": 4,
        "description": "十字星完全包含在前根大阴线实体内，比普通看涨孕线反转信号更强",
    },
    CandlePatterns.HaramiCrossBearish: {
        "name": "看跌孕十字",
        "name_en": "Bearish Harami Cross",
        "type": PatternType.DOUBLE,
        "strength": 4,
        "description": "十字星完全包含在前根大阳线实体内，比普通看跌孕线反转信号更强",
    },
    CandlePatterns.KickingBullish: {
        "name": "看涨踢脚线",
        "name_en": "Bullish Kicker",
        "type": PatternType.DOUBLE,
        "strength": 5,
        "description": "跳空高开大阳线完全脱离前阴线，极强看涨反转信号，多空力量骤然逆转",
    },
    CandlePatterns.KickingBearish: {
        "name": "看跌踢脚线",
        "name_en": "Bearish Kicker",
        "type": PatternType.DOUBLE,
        "strength": 5,
        "description": "跳空低开大阴线完全脱离前阳线，极强看跌反转信号，多空力量骤然逆转",
    },
    # ==================== 三蜡烛形态 ====================
    CandlePatterns.MorningStar: {
        "name": "早晨之星",
        "name_en": "Morning Star",
        "type": PatternType.TRIPLE,
        "strength": 5,
        "description": "大阴线→小实体→大阳线，第三根深入第一根实体一半以上，经典底部反转形态",
    },
    CandlePatterns.EveningStar: {
        "name": "黄昏之星",
        "name_en": "Evening Star",
        "type": PatternType.TRIPLE,
        "strength": 5,
        "description": "大阳线→小实体→大阴线，第三根深入第一根实体一半以上，经典顶部反转形态",
    },
    CandlePatterns.MorningDojiStar: {
        "name": "早晨十字星",
        "name_en": "Morning Doji Star",
        "type": PatternType.TRIPLE,
        "strength": 5,
        "description": "大阴线→十字星→大阳线，十字星增强反转信号，极强底部反转形态",
    },
    CandlePatterns.EveningDojiStar: {
        "name": "黄昏十字星",
        "name_en": "Evening Doji Star",
        "type": PatternType.TRIPLE,
        "strength": 5,
        "description": "大阳线→十字星→大阴线，十字星增强反转信号，极强顶部反转形态",
    },
    CandlePatterns.ThreeWhiteSoldiers: {
        "name": "三白兵",
        "name_en": "Three White Soldiers",
        "type": PatternType.TRIPLE,
        "strength": 5,
        "description": "连续三根阳线逐步推高，每根开盘在前根实体内，收盘创新高，极强上涨信号",
    },
    CandlePatterns.ThreeBlackCrows: {
        "name": "三只乌鸦",
        "name_en": "Three Black Crows",
        "type": PatternType.TRIPLE,
        "strength": 5,
        "description": "连续三根阴线逐步下压，每根开盘在前根实体内，收盘创新低，极强下跌信号",
    },
    CandlePatterns.ThreeInsideUp: {
        "name": "三内部上涨",
        "name_en": "Three Inside Up",
        "type": PatternType.TRIPLE,
        "strength": 4,
        "description": "看涨孕线后出现大阳线突破，三根K线确认底部，可靠性高",
    },
    CandlePatterns.ThreeOutsideUp: {
        "name": "三外部上涨",
        "name_en": "Three Outside Up",
        "type": PatternType.TRIPLE,
        "strength": 4,
        "description": "看涨吞噬后继续上涨确认，三根K线完整确认底部反转",
    },
    # ==================== 五蜡烛形态 ====================
    CandlePatterns.RisingThreeMethods: {
        "name": "上升三法",
        "name_en": "Rising Three Methods",
        "type": PatternType.FIVE,
        "strength": 3,
        "description": "大阳线后小阴线回调整理，随后大阳线突破前高，上涨趋势持续信号",
    },
    CandlePatterns.FallingThreeMethods: {
        "name": "下降三法",
        "name_en": "Falling Three Methods",
        "type": PatternType.FIVE,
        "strength": 3,
        "description": "大阴线后小阳线回调整理，随后大阴线跌破前低，下跌趋势持续信号",
    },
    CandlePatterns.MatHold: {
        "name": "垫高持有",
        "name_en": "Mat Hold",
        "type": PatternType.FIVE,
        "strength": 4,
        "description": "强势上涨中继形态，回调幅度较小，多头力量持续",
    },
}


# 枚举名称快速查找字典，避免每次线性遍历所有枚举
_PATTERN_NAME_MAP: Dict[str, CandlePatterns] = {p.pattern_name: p for p in CandlePatterns}


def _get_pattern_info(pattern: CandlePatterns, signal_type: str) -> Dict:
    """
    获取形态的完整信息

    Args:
        pattern: CandleKit的形态枚举
        signal_type: CandleKit返回的信号类型 ("bullish"/"bearish"/"neutral")

    Returns:
        包含形态完整信息的字典
    """
    meta = PATTERN_METADATA.get(pattern, {})

    return {
        "name": meta.get("name", pattern.pattern_name),
        "name_en": meta.get("name_en", pattern.pattern_name),
        "type": meta.get("type", PatternType.SINGLE).value,
        "signal": signal_type,
        "strength": meta.get("strength", 3),
        "description": meta.get("description", f"{pattern.pattern_name}形态"),
    }


def _prepare_dataframe(
    data: Union[pd.DataFrame, List[Dict]], recent_n: Optional[int] = None
) -> pd.DataFrame:
    """
    准备数据用于形态识别

    Args:
        data: 输入数据，可以是DataFrame或List[Dict]
        recent_n: 仅分析最近N根K线

    Returns:
        处理后的DataFrame，包含标准化的列名
    """
    if isinstance(data, list):
        df = pd.DataFrame(data)
    else:
        df = data.copy()

    if df.empty:
        return df

    # 确保日期格式正确
    if "trade_date" in df.columns:
        if not pd.api.types.is_datetime64_any_dtype(df["trade_date"]):
            df["trade_date"] = pd.to_datetime(
                df["trade_date"].astype(str), errors="coerce"
            )
        df = df.sort_values("trade_date").reset_index(drop=True)

    # 截取最近N根
    if recent_n is not None:
        df = df.tail(recent_n).reset_index(drop=True)

    return df


def read_candles(data: Union[pd.DataFrame, List[Dict]], recent_n: Optional[int] = None) -> str:
    """
    使用CandleKit识别K线形态，返回JSON字符串。

    本方法基于CandleKit专业形态识别库，遵循Steve Nison的经典理论，
    提供科学、可靠的形态识别结果。

    Args:
        data: 输入数据，可以是Tushare DataFrame或List[Dict]
              必须包含列: trade_date, open, high, low, close
        recent_n: 仅分析最近N根K线，默认None表示使用全量数据

    Returns:
        JSON字符串，结构如下：
        {
            "as_of_date": "YYYY-MM-DD",
            "single": {
                "date": "YYYY-MM-DD",
                "patterns": [{"name": "...", "signal": "...", ...}]
            },
            "double": {
                "dates": ["YYYY-MM-DD", "YYYY-MM-DD"],
                "patterns": [...]
            },
            "triple": {
                "dates": ["YYYY-MM-DD", "YYYY-MM-DD", "YYYY-MM-DD"],
                "patterns": [...]
            },
            "five": {
                "dates": ["YYYY-MM-DD", ..., "YYYY-MM-DD"],
                "patterns": [...]
            }
        }
    """
    # 准备数据
    df = _prepare_dataframe(data, recent_n)

    if df.empty:
        return json.dumps(
            {
                "as_of_date": None,
                "single": {"date": None, "patterns": []},
                "double": {"dates": None, "patterns": []},
                "triple": {"dates": None, "patterns": []},
                "five": {"dates": None, "patterns": []},
            },
            ensure_ascii=False,
        )

    # 获取日期列表
    def get_date(idx: int) -> Optional[str]:
        if idx < 0 or idx >= len(df):
            return None
        dt = df["trade_date"].iloc[idx]
        return str(dt)[:10] if pd.notna(dt) else None

    n = len(df)
    last_idx = n - 1

    # 使用CandleKit扫描全部形态
    # scan_symbol_df返回DataFrame，列: index, pattern_name, signal_type, candles
    results_df = scan_symbol_df(df)

    # 按形态类型分组
    single_patterns: List[Dict] = []
    double_patterns: List[Dict] = []
    triple_patterns: List[Dict] = []
    five_patterns: List[Dict] = []

    single_date: Optional[str] = None
    double_dates: Optional[List[Optional[str]]] = None
    triple_dates: Optional[List[Optional[str]]] = None
    five_dates: Optional[List[Optional[str]]] = None

    if not results_df.empty:
        # 按索引分组，找到每个位置检测到的所有形态
        for idx in range(n - 1, -1, -1):
            # 获取该索引的所有形态
            idx_patterns = results_df[results_df["index"] == idx]

            if idx_patterns.empty:
                continue

            # 按蜡烛数量分组
            for _, row in idx_patterns.iterrows():
                pattern_enum = _PATTERN_NAME_MAP.get(row["pattern_name"])

                if pattern_enum is None:
                    continue

                signal_type = row["signal_type"]
                candle_count = row["candles"]

                pattern_info = _get_pattern_info(pattern_enum, signal_type)

                if candle_count == 1:
                    if not single_patterns:  # 只取最近的
                        single_patterns.append(pattern_info)
                        single_date = get_date(idx)

                elif candle_count == 2:
                    if not double_patterns:
                        double_patterns.append(pattern_info)
                        double_dates = [get_date(idx - 1), get_date(idx)]

                elif candle_count == 3:
                    if not triple_patterns:
                        triple_patterns.append(pattern_info)
                        triple_dates = [get_date(idx - 2), get_date(idx - 1), get_date(idx)]

                elif candle_count == 5:
                    if not five_patterns:
                        five_patterns.append(pattern_info)
                        five_dates = [
                            get_date(idx - 4),
                            get_date(idx - 3),
                            get_date(idx - 2),
                            get_date(idx - 1),
                            get_date(idx),
                        ]

    # 按强度排序
    def sort_by_strength(patterns: List[Dict]) -> List[Dict]:
        return sorted(patterns, key=lambda x: -x.get("strength", 0))

    # 判断形态日期是否离 as_of_date 太远
    as_of = pd.Timestamp(df["trade_date"].iloc[last_idx])

    def is_too_old(dates: Optional[List[Optional[str]]], max_days: int) -> bool:
        """取 dates 中最新的一个日期，判断与 as_of_date 的距离是否超过 max_days 个交易日"""
        if not dates:
            return False
        valid = [d for d in dates if d is not None]
        if not valid:
            return False
        latest_str = max(valid)
        latest_dt = pd.to_datetime(latest_str)

        bars_since = (df["trade_date"] > latest_dt).sum()
        return bars_since > max_days
    def maybe_stale(
        dates: Optional[List[Optional[str]]],
        patterns: List[Dict],
        max_days: int,
    ) -> List[Dict]:
        if not patterns or is_too_old(dates, max_days):
            return [{"name": "近期没有明显的形态", "name_en": "No recent pattern", "type": None, "signal": None, "strength": None, "description": None}]
        return sort_by_strength(patterns)

    output = {
        "as_of_date": get_date(last_idx),
        "single": {"date": single_date, "patterns": sort_by_strength(single_patterns)},
        "double": {"dates": double_dates, "patterns": maybe_stale(double_dates, double_patterns, 10)},
        "triple": {"dates": triple_dates, "patterns": maybe_stale(triple_dates, triple_patterns, 20)},
        "five": {"dates": five_dates, "patterns": maybe_stale(five_dates, five_patterns, 30)},
    }

    return json.dumps(output, ensure_ascii=False, indent=2)


def read_candles_full(
    data: Union[pd.DataFrame, List[Dict]], recent_n: Optional[int] = None
) -> Dict:
    """
    使用CandleKit识别K线形态，返回所有检测到的形态（不仅是最近的）

    与read_candles不同，本方法返回全部检测到的形态，便于更详细的分析。

    Args:
        data: 输入数据
        recent_n: 仅分析最近N根K线

    Returns:
        包含所有形态识别结果的字典
    """
    df = _prepare_dataframe(data, recent_n)

    if df.empty:
        return {"count": 0, "candles": []}

    results_df = scan_symbol_df(df)

    if results_df.empty:
        return {"count": len(df), "candles": []}

    def get_date(idx: int) -> Optional[str]:
        if idx < 0 or idx >= len(df):
            return None
        dt = df["trade_date"].iloc[idx]
        return str(dt)[:10] if pd.notna(dt) else None

    # 构建每个K线的形态信息
    candles_data = []

    for idx in range(len(df)):
        idx_patterns = results_df[results_df["index"] == idx]

        patterns_list = []
        for _, row in idx_patterns.iterrows():
            pattern_enum = _PATTERN_NAME_MAP.get(row["pattern_name"])

            if pattern_enum:
                pattern_info = _get_pattern_info(pattern_enum, row["signal_type"])
                patterns_list.append(pattern_info)

        candle_info = {
            "date": get_date(idx),
            "open": float(df["open"].iloc[idx]),
            "high": float(df["high"].iloc[idx]),
            "low": float(df["low"].iloc[idx]),
            "close": float(df["close"].iloc[idx]),
            "patterns": sorted(patterns_list, key=lambda x: -x.get("strength", 0)),
        }
        candles_data.append(candle_info)

    return {"count": len(df), "candles": candles_data}