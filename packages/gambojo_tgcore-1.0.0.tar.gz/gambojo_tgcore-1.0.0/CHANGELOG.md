# Changelog

All notable changes to this project will be documented in this file.
The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [1.0.0] - 2026-03-15

## [0.0.0] - 2026-03-15

### Added
- `Settings` — базовый класс конфигурации на pydantic-settings
- `UserMixin` — миксин с базовыми полями пользователя
- `TimestampMixin` — миксин `created_at` / `updated_at` для любой модели
- `Base`, `get_session`, `get_session_factory`, `init_db` — асинхронный слой SQLAlchemy
- `AntiSpamMiddleware` — ограничение частоты сообщений на пользователя
- `UserMiddleware` — автоматическое получение/создание пользователя и инжект в handler
- `paginate` — инлайн-клавиатура с пагинацией
- `confirm_cancel` — клавиатура подтверждения действия
- `back_button` — кнопка назад
- `main_menu` — reply-клавиатура из списка строк
- `url_button` — инлайн-кнопка со ссылкой
- `create_admin_router` — фабрика роутера админки с `/stats`, `/broadcast`, `/ban`, `/unban`, `/user`
- `create_schema.py` — внешний скрипт создания схемы БД
