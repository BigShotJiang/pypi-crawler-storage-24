# ------------------------------------------------------------------
# Database
# ------------------------------------------------------------------
from tg_core.db import (
    Base,
    get_session,
    get_session_factory,
    init_db,
    ensure_admins,
    run_migrations,
)

# ------------------------------------------------------------------
# Models
# ------------------------------------------------------------------
from tg_core.models import (
    TimestampMixin,
    UserMixin,
)

# ------------------------------------------------------------------
# Config
# ------------------------------------------------------------------
from tg_core.config import Settings

# ------------------------------------------------------------------
# Middleware
# ------------------------------------------------------------------
from tg_core.middleware import (
    AntiSpamMiddleware,
    UserMiddleware,
)

# ------------------------------------------------------------------
# Keyboards
# ------------------------------------------------------------------
from tg_core.keyboards import (
    back_button,
    confirm_cancel,
    main_menu,
    paginate,
    url_button,
)

# ------------------------------------------------------------------
# Admin
# ------------------------------------------------------------------
from tg_core.admin_base import create_admin_router

# ------------------------------------------------------------------
# Публичный API — явно объявляем что экспортируется
# Всё что не здесь — детали реализации
# ------------------------------------------------------------------
__all__ = [
    # database
    "Base",
    "get_session",
    "get_session_factory",
    "init_db",
    "ensure_admins",
    "run_migrations",
    # models
    "TimestampMixin",
    "UserMixin",
    # config
    "Settings",
    # middleware
    "AntiSpamMiddleware",
    "UserMiddleware",
    # keyboards
    "back_button",
    "confirm_cancel",
    "main_menu",
    "paginate",
    "url_button",
    # admin
    "create_admin_router",
]

__version__ = "1.0.0"
