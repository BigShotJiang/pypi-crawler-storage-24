from datetime import datetime
from sqlalchemy import func, BigInteger
from sqlalchemy.orm import Mapped, mapped_column, DeclarativeBase


# ------------------------------------------------------------------
# Базовый класс для всех моделей проекта
# Шаблон импортирует его и наследует свои модели от него
# ------------------------------------------------------------------
class Base(DeclarativeBase):
    pass


# ------------------------------------------------------------------
# Миксин временных меток
# Добавляет created_at и updated_at к любой модели
# ------------------------------------------------------------------
class TimestampMixin:
    created_at: Mapped[datetime] = mapped_column(
        server_default=func.now(),
        nullable=False,
    )
    updated_at: Mapped[datetime] = mapped_column(
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )


# ------------------------------------------------------------------
# Миксин пользователя
# Шаблон создаёт свой класс User наследуясь от этого миксина и Base
#
# Пример в шаблоне:
#   from tg_core.models import UserMixin, Base
#   class User(UserMixin, Base):
#       phone: Mapped[str | None]
# ------------------------------------------------------------------
class UserMixin(TimestampMixin):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(
        primary_key=True,
        autoincrement=True,
    )
    telegram_id: Mapped[int] = mapped_column(
        BigInteger,
        unique=True,
        nullable=False,
        index=True,               # часто ищем по telegram_id
    )
    username: Mapped[str | None] = mapped_column(
        nullable=True,
    )
    full_name: Mapped[str] = mapped_column(
        nullable=False,
    )
    is_banned: Mapped[bool] = mapped_column(
        default=False,
        nullable=False,
    )
    is_admin: Mapped[bool] = mapped_column(
        default=False,
        nullable=False,
    )
    last_active: Mapped[datetime] = mapped_column(
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )
    referred_by: Mapped[int | None] = mapped_column(
        BigInteger,
        nullable=True,
        default=None,
    )
