from collections import defaultdict
from datetime import datetime
from typing import Any, Awaitable, Callable

from aiogram import BaseMiddleware
from aiogram.types import TelegramObject, Update
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.exc import IntegrityError

from tg_core.db import get_session_factory

# ------------------------------------------------------------------
# AntiSpamMiddleware
# Ограничивает количество сообщений от одного пользователя
# ------------------------------------------------------------------
class AntiSpamMiddleware(BaseMiddleware):
    def __init__(self, limit: int, window: int) -> None:
        """
        Args:
            limit:  максимум сообщений за окно
            window: размер окна в секундах
        """
        self.limit = limit
        self.window = window
        self._counters: dict[int, list[datetime]] = defaultdict(list)

    async def __call__(
        self,
        handler: Callable[[TelegramObject, dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: dict[str, Any],
    ) -> Any:
        # извлекаем user_id из любого типа апдейта
        user = data.get("event_from_user")
        if user is None:
            return await handler(event, data)

        user_id = user.id
        now = datetime.now()

        # чистим устаревшие метки
        self._counters[user_id] = [
            ts for ts in self._counters[user_id]
            if (now - ts).total_seconds() < self.window
        ]

        if len(self._counters[user_id]) >= self.limit:
            # тихо игнорируем — не отвечаем спамеру
            return

        self._counters[user_id].append(now)
        return await handler(event, data)


# ------------------------------------------------------------------
# UserMiddleware
# Достаёт или создаёт пользователя и инжектит в data["user"]
# Шаблон передаёт свою модель User через параметр user_model
# ------------------------------------------------------------------
class UserMiddleware(BaseMiddleware):
    def __init__(self, user_model: type, admin_ids: list[int] | None = None) -> None:
        """
        Args:
            user_model: класс модели User из шаблона
                        (наследует UserMixin + Base)

        Использование в main.py шаблона:
            from db.models import User
            dp.update.middleware(UserMiddleware(user_model=User))
        """
        self.user_model = user_model
        self.admin_ids = admin_ids or []

    async def __call__(
        self,
        handler: Callable[[TelegramObject, dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: dict[str, Any],
    ) -> Any:
        factory = get_session_factory()
        async with factory() as session:
            tg_user = data.get("event_from_user")

            if not tg_user:
                return await handler(event, data)

            referred_by = data.get("referred_by")

            user, is_new_user = await self._get_or_create(session, tg_user, referred_by)

            data["user"] = user
            data["is_new_user"] = is_new_user
            data["session"] = session

            try:
                result = await handler(event, data)
                await session.commit()
                return result
            except Exception:
                await session.rollback()
                raise

    async def _get_or_create(
        self,
        session: AsyncSession,
        tg_user: Any,
        referred_by: int | None = None,
    ) -> tuple[Any, bool]:
        """Возвращает (user, is_new_user)"""
        stmt = select(self.user_model).where(
            self.user_model.telegram_id == tg_user.id
        )
        result = await session.execute(stmt)
        user = result.scalar_one_or_none()

        if user:
            user.full_name = tg_user.full_name
            user.username = tg_user.username
            user.last_active = datetime.now()
            await session.flush()
            return user, False

        user = self.user_model(
            telegram_id=tg_user.id,
            username=tg_user.username,
            full_name=tg_user.full_name,
            referred_by=referred_by,
            is_admin=tg_user.id in self.admin_ids,
        )
        session.add(user)
        try:
            await session.flush()
            return user, True
        except IntegrityError:
            await session.rollback()
            result = await session.execute(stmt)
            user = result.scalar_one()
            return user, False
