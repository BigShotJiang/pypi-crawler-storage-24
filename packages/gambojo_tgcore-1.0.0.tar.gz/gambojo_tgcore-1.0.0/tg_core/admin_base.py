from collections.abc import Awaitable, Callable
from typing import Any

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, Message
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from tg_core.keyboards import confirm_cancel


# ------------------------------------------------------------------
# FSM состояния рассылки
# ------------------------------------------------------------------
class BroadcastStates(StatesGroup):
    waiting_text = State()
    waiting_confirm = State()


# ------------------------------------------------------------------
# Фильтр администратора
# Проверяет что user.is_admin == True
# UserMiddleware уже достал юзера из БД — просто проверяем флаг
# ------------------------------------------------------------------
class IsAdmin(object):
    async def __call__(self, message: Message, user: Any) -> bool:
        return user is not None and user.is_admin


# ------------------------------------------------------------------
# Фабрика
# ------------------------------------------------------------------
def create_admin_router(
    user_model: type,
    extra_routers: list[Router] | None = None,
    stats_callback: Callable[[], Awaitable[str]] | None = None,
) -> Router:
    """
    Создаёт роутер админки.

    Args:
        user_model:      модель User из шаблона — нужна для запросов
        extra_routers:   доп. роутеры из шаблона (свои команды)
        stats_callback:  async функция возвращающая строку с доп. статистикой

    Использование в main.py шаблона:
        from db.models import User
        from tg_core.admin_base import create_admin_router

        admin_router = create_admin_router(
            user_model=User,
            extra_routers=[shop_admin_router],
            stats_callback=get_shop_stats,
        )
        dp.include_router(admin_router)

    Использование stats_callback в шаблоне:
        async def get_shop_stats() -> str:
            orders_count = await ...
            return f"📦 Заказов сегодня: {orders_count}"
    """
    router = Router(name="admin")
    is_admin = IsAdmin()

    # ------------------------------------------------------------------
    # /stats
    # ------------------------------------------------------------------
    @router.message(Command("stats"), is_admin)
    async def cmd_stats(
        message: Message,
        session: AsyncSession,
    ) -> None:
        # базовая статистика по пользователям
        from datetime import datetime, timedelta

        now = datetime.now()
        today = now.replace(hour=0, minute=0, second=0, microsecond=0)
        week_ago = now - timedelta(days=7)

        total = await session.scalar(
            select(func.count()).select_from(user_model)
        )
        today_count = await session.scalar(
            select(func.count())
            .select_from(user_model)
            .where(user_model.created_at >= today)
        )
        week_count = await session.scalar(
            select(func.count())
            .select_from(user_model)
            .where(user_model.created_at >= week_ago)
        )
        banned_count = await session.scalar(
            select(func.count())
            .select_from(user_model)
            .where(user_model.is_banned == True)  # noqa: E712
        )

        text = (
            "📊 <b>Статистика</b>\n\n"
            f"👥 Всего пользователей: <b>{total}</b>\n"
            f"📅 Новых сегодня: <b>{today_count}</b>\n"
            f"📆 Новых за неделю: <b>{week_count}</b>\n"
            f"🚫 Заблокировано: <b>{banned_count}</b>\n"
        )

        # доп. статистика из шаблона
        if stats_callback is not None:
            extra = await stats_callback()
            if extra:
                text += f"\n{extra}"

        await message.answer(text, parse_mode="HTML")

    # ------------------------------------------------------------------
    # /broadcast — шаг 1: запрос текста
    # ------------------------------------------------------------------
    @router.message(Command("broadcast"), is_admin)
    async def cmd_broadcast(
        message: Message,
        state: FSMContext,
    ) -> None:
        await state.set_state(BroadcastStates.waiting_text)
        await message.answer(
            "📢 Введите текст рассылки.\n"
            "Поддерживается HTML-разметка.\n\n"
            "/cancel — отменить"
        )

    # ------------------------------------------------------------------
    # /broadcast — шаг 2: превью и подтверждение
    # ------------------------------------------------------------------
    @router.message(BroadcastStates.waiting_text, is_admin)
    async def broadcast_preview(
        message: Message,
        state: FSMContext,
    ) -> None:
        await state.update_data(text=message.text)
        await state.set_state(BroadcastStates.waiting_confirm)
        await message.answer(
            f"Превью сообщения:\n\n{message.text}",
            parse_mode="HTML",
        )
        await message.answer(
            "Отправить рассылку?",
            reply_markup=confirm_cancel(
                confirm_callback="broadcast:confirm",
                cancel_callback="broadcast:cancel",
            ),
        )

    # ------------------------------------------------------------------
    # /broadcast — шаг 3: подтверждение
    # ------------------------------------------------------------------
    @router.callback_query(
        F.data == "broadcast:confirm",
        BroadcastStates.waiting_confirm,
    )
    async def broadcast_confirm(
        callback: CallbackQuery,
        state: FSMContext,
        session: AsyncSession,
    ) -> None:
        data = await state.get_data()
        text = data["text"]
        await state.clear()

        # получаем всех не заблокированных пользователей
        result = await session.execute(
            select(user_model.telegram_id).where(
                user_model.is_banned == False  # noqa: E712
            )
        )
        user_ids = result.scalars().all()

        await callback.message.edit_text(
            f"⏳ Отправляю {len(user_ids)} пользователям..."
        )

        bot = callback.bot
        sent = 0
        failed = 0

        for user_id in user_ids:
            try:
                await bot.send_message(user_id, text, parse_mode="HTML")
                sent += 1
            except Exception:
                failed += 1

        await callback.message.answer(
            f"✅ Рассылка завершена\n\n"
            f"📨 Отправлено: {sent}\n"
            f"❌ Ошибок: {failed}"
        )

    # ------------------------------------------------------------------
    # /broadcast — отмена
    # ------------------------------------------------------------------
    @router.callback_query(F.data == "broadcast:cancel")
    @router.message(Command("cancel"), is_admin)
    async def broadcast_cancel(
        event: Message | CallbackQuery,
        state: FSMContext,
    ) -> None:
        await state.clear()
        text = "❌ Рассылка отменена."
        if isinstance(event, CallbackQuery):
            await event.message.edit_text(text)
        else:
            await event.answer(text)

    # ------------------------------------------------------------------
    # /ban
    # ------------------------------------------------------------------
    @router.message(Command("ban"), is_admin)
    async def cmd_ban(
        message: Message,
        session: AsyncSession,
    ) -> None:
        args = message.text.split()
        if len(args) < 2 or not args[1].isdigit():
            await message.answer("Использование: /ban &lt;telegram_id&gt;")
            return

        telegram_id = int(args[1])
        result = await session.execute(
            select(user_model).where(user_model.telegram_id == telegram_id)
        )
        target = result.scalar_one_or_none()

        if target is None:
            await message.answer("❌ Пользователь не найден.")
            return

        if target.is_admin:
            await message.answer("❌ Нельзя заблокировать администратора.")
            return

        target.is_banned = True
        await message.answer(
            f"🚫 Пользователь <b>{target.full_name}</b> "
            f"(<code>{telegram_id}</code>) заблокирован.",
            parse_mode="HTML",
        )

    # ------------------------------------------------------------------
    # /unban
    # ------------------------------------------------------------------
    @router.message(Command("unban"), is_admin)
    async def cmd_unban(
        message: Message,
        session: AsyncSession,
    ) -> None:
        args = message.text.split()
        if len(args) < 2 or not args[1].isdigit():
            await message.answer("Использование: /unban &lt;telegram_id&gt;")
            return

        telegram_id = int(args[1])
        result = await session.execute(
            select(user_model).where(user_model.telegram_id == telegram_id)
        )
        target = result.scalar_one_or_none()

        if target is None:
            await message.answer("❌ Пользователь не найден.")
            return

        target.is_banned = False
        await message.answer(
            f"✅ Пользователь <b>{target.full_name}</b> "
            f"(<code>{telegram_id}</code>) разблокирован.",
            parse_mode="HTML",
        )

    # ------------------------------------------------------------------
    # /user
    # ------------------------------------------------------------------
    @router.message(Command("user"), is_admin)
    async def cmd_user(
        message: Message,
        session: AsyncSession,
    ) -> None:
        args = message.text.split()
        if len(args) < 2 or not args[1].isdigit():
            await message.answer("Использование: /user &lt;telegram_id&gt;")
            return

        telegram_id = int(args[1])
        result = await session.execute(
            select(user_model).where(user_model.telegram_id == telegram_id)
        )
        target = result.scalar_one_or_none()

        if target is None:
            await message.answer("❌ Пользователь не найден.")
            return

        await message.answer(
            f"👤 <b>Пользователь</b>\n\n"
            f"ID: <code>{target.telegram_id}</code>\n"
            f"Имя: <b>{target.full_name}</b>\n"
            f"Username: @{target.username or '—'}\n"
            f"Админ: {'✅' if target.is_admin else '❌'}\n"
            f"Заблокирован: {'🚫' if target.is_banned else '✅'}\n"
            f"Зарегистрирован: <b>{target.created_at.strftime('%d.%m.%Y %H:%M')}</b>\n"
            f"Последняя активность: <b>{target.last_active.strftime('%d.%m.%Y %H:%M')}</b>",
            parse_mode="HTML",
        )

    # ------------------------------------------------------------------
    # Подключаем доп. роутеры из шаблона
    # ------------------------------------------------------------------
    if extra_routers:
        for extra_router in extra_routers:
            router.include_router(extra_router)

    return router
