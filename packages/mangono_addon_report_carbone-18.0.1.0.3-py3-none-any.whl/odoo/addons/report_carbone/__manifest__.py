#
#    Copyright (C) 2025 Mangono.
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

{
    "name": "Report Generator | Carbone.io",
    "version": "18.0.1.0.3",
    "author": "Mangono",
    "maintainer": "Mangono",
    "summary": """
    Automate documents with Carbone.io – the universal, most efficient no-code document generation solution. Generate
    custom documents and reports from Odoo data using customizable templates in Word, Excel, PowerPoint, LibreOffice,
    or Google Docs. Convert and export to 100+ formats, including PDF, DOCX, XLSX, PPTX, CSV, HTML, XML, JPG, and PNG,
    with enterprise features like charts, barcodes, images, forms, e-signatures, E-reporting, Factur-X, ZUGFeRD,
    i18n, multi-language support, HTML rendering, and PDF merging. Use cases: Generate invoices, contracts, quotes,
    delivery notes, payslips, purchase orders, sales presentations, sales reports, brochures, datasheets, SLAs, NDAs,
    meeting notes, daybook reports, sales analysis, inventory reports, and product category reports.
    """,
    "category": "Reporting",
    "depends": ["base", "base_setup", "web", "export_json"],
    "description": "Report Generator | Carbone.io",
    "website": "https://carbone.io/integration/odoo.html",
    "data": [
        "security/groups.xml",
        "security/ir.model.access.csv",
        "data/carbone_guide_attachment.xml",
        "data/carbone_demo_template_purchase_order.xml",
        "views/base/ir_actions_report.xml",
        "views/base/ir_exports.xml",
        "views/res/res_config_settings_carbone.xml",
        "views/carbone/carbone_print_by_action.xml",
        "views/carbone/report_carbone_menu.xml",
        "views/carbone/carbone_translate.xml",
        "views/carbone/carbone_translate_line.xml",
        "views/carbone/carbone_create_report_wizard.xml",
    ],
    "assets": {
        "web.assets_backend": [
            "report_carbone/static/src/js/report/action_manager_report.js",
            "report_carbone/static/src/js/report/action_create_ir_report.js",
            "report_carbone/static/src/js/report/copy_export_json.js",
            "report_carbone/static/src/js/report/initiate_studio.js",
            "report_carbone/static/src/scss/carbone.scss",
            "report_carbone/static/src/xml/list_template.xml",
        ],
    },
    "test": [],
    "images": ["static/description/banner.png"],
    "installable": True,
    "auto_install": False,
    "license": "AGPL-3",
    "application": False,
    "post_init_hook": "set_res_config_settings",
}
