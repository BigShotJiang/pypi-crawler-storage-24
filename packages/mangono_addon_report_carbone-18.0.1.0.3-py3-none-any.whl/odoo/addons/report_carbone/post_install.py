STUDIO_JS_URL = "https://bin.carbone.io/studio/5.1.1/carbone-studio.min.js"
API_REPORT_URL = "https://api.carbone.io"


def set_res_config_settings(env):
    env["ir.config_parameter"].set_param("report-engine.carbone_studio_url", API_REPORT_URL)
    env["ir.config_parameter"].set_param("report-engine.carbone_js_file_url", STUDIO_JS_URL)
    env["ir.config_parameter"].set_param("report-engine.is_stage_mode", True)
