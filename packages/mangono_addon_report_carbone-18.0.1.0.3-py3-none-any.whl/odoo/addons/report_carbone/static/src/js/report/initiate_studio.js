/** @odoo-module **/

import {registry} from "@web/core/registry";
import {loadJS} from "@web/core/assets";
import {rpc} from "@web/core/network/rpc";
import {user} from "@web/core/user";
import {formatJsonData} from "@report_carbone/js/report/copy_export_json";
import {FormController} from "@web/views/form/form_controller";
import {patch} from "@web/core/utils/patch";

// ========== CONSTANTS ==========
//  /!\ You must leave a minimum of 450ms, because when creating a new report, you must allow
// Carbone time to deploy the new template, otherwise it cannot be displayed directly.
// Between two recording changes, a minimum of 250 ms is required.
const DEBOUNCE_DELAY = 450;
const DEFAULT_OPTIONS = ["{}", "{}", "en", "UTC", "USD", "", ""];
const CARBONE_STUDIO_SELECTOR = "carbone-studio";

// ========== DOM UTILITY==========
class DOMUtils {
    static setDisplayNone(element) {
        if (!element) return;
        Object.assign(element.style, {
            display: "none",
            width: "0%",
            height: "0%",
        });
    }

    static waitForElement(selector, callback) {
        const element = document.querySelector(selector);
        if (element) {
            callback(element);
            return null;
        }

        const observer = new MutationObserver(() => {
            const found = document.querySelector(selector);
            if (found) {
                observer.disconnect();
                callback(found);
            }
        });

        observer.observe(document.body, {childList: true, subtree: true});
        return observer;
    }

    static improveOdooRecordView() {
        const node = document.querySelector("div.o_group.row.align-items-start");
        if (!node) return;

        node.childNodes.forEach((childNode) => {
            if (childNode.nodeName === "DIV") {
                childNode.classList.add("col-lg-12");
            }
        });
    }
}

// ========== CARBONE HANDLER==========
class CarboneStudioManager {
    constructor() {
        this.observer = null;
        this.studioURL = null;
        this.carboneToken = null;
        this.startIrReportId = null;
        this.isInitialized = false;
        this.debounceTimer = null;
        this.optionsList = [...DEFAULT_OPTIONS];
        this.currentStudio = null;
        this.isTemplateLoading = false;
    }

    async initialize() {
        if (!this.isInitialized) {
            this.studioURL = await CarboneAPI.importCarboneJs();
            this.carboneToken = await CarboneAPI.getCarboneApiKey();
            this.isInitialized = true;
        }
        return {
            studioURL: this.studioURL,
            carboneToken: this.carboneToken,
        };
    }

    cleanup() {
        if (this.observer) {
            this.observer.disconnect();
            this.observer = null;
        }

        if (this.isTemplateLoading && this.currentStudio) {
            try {
                this.currentStudio.closeTemplate();
            } catch (e) {
                console.error("Error closing template:", e);
            }
            this.isTemplateLoading = false;
        }
    }

    resetOptions() {
        this.optionsList = [...DEFAULT_OPTIONS];
    }

    async refreshStudio(irReportId = null, services) {
        if (this.debounceTimer) {
            clearTimeout(this.debounceTimer);
        }

        return new Promise((resolve) => {
            this.debounceTimer = setTimeout(async () => {
                try {
                    this.cleanup();
                    this.resetOptions();

                    const config = await this.initialize();
                    const isCarboneManager = await CarboneAPI.isCarboneManagerUser();
                    const isCarboneReport = this.getIsCarboneReport(services);

                    if (!isCarboneReport || !isCarboneManager) {
                        this.handleHideStudio(config);
                        resolve();
                        return;
                    }

                    if (irReportId) {
                        this.startIrReportId = irReportId;
                        const options = await CarboneAPI.getDefaultOptionParameter(irReportId);
                        if (options) {
                            this.optionsList = options;
                        }
                    }

                    this.observer = DOMUtils.waitForElement(CARBONE_STUDIO_SELECTOR, (studio) => {
                        this.setupStudio(studio, config);
                    });

                    resolve();
                } catch (error) {
                    console.error("Error refreshing Carbone Studio:", error);
                    this.isTemplateLoading = false;
                    resolve();
                }
            }, DEBOUNCE_DELAY);
        });
    }

    setupStudio(studio, config) {
        if (this.currentStudio && this.isTemplateLoading) {
            try {
                this.currentStudio.closeTemplate();
            } catch (e) {
                console.error("Error closing previous template:", e);
            }
        }

        this.currentStudio = studio;
        Object.assign(studio.style, {
            display: "",
            width: "100%",
            height: "100%",
        });
        DOMUtils.improveOdooRecordView();
        this.isTemplateLoading = true;
        this.launchCarbone(studio, config.studioURL, config.carboneToken);
        this.addStudioListeners(studio);
    }

    handleHideStudio(config) {
        DOMUtils.waitForElement(CARBONE_STUDIO_SELECTOR, (studio) => {
            if (!config.studioURL || !config.carboneToken) {
                DOMUtils.setDisplayNone(studio);
            }
        });
    }
    getIsCarboneReport(services) {
        try {
            const actionService = services.action;
            if (!actionService?.currentController?.action) {
                return false;
            }

            const currentController = actionService.currentController;
            this.startIrReportId = currentController.currentState?.resId;
            return currentController.action.context?.default_report_type === "carbone";
        } catch (error) {
            console.error("Error getting current ir.actions.report:", error);
            return false;
        }
    }

    async launchCarbone(studio, studioURL, carboneToken) {
        if (!studio || !studioURL || !carboneToken) {
            DOMUtils.setDisplayNone(studio);
            return false;
        }

        studio.setConfig({origin: studioURL, token: carboneToken, mode: "embedded-versioning"});

        const options = this.buildStudioOptions();
        const template = this.buildTemplateConfig();

        await this.safeOpenTemplate(studio, template, options);
        this.isTemplateLoading = false;

        return true;
    }

    buildStudioOptions() {
        if (!this.optionsList || this.optionsList.length < 5) {
            this.optionsList = [...DEFAULT_OPTIONS];
        }

        return {
            data: JSON.parse(this.optionsList[0]),
            translations: JSON.parse(this.optionsList[1]),
            lang: this.optionsList[2],
            timezone: this.optionsList[3],
            currencySource: this.optionsList[4],
            currencyTarget: this.optionsList[4],
        };
    }

    buildTemplateConfig() {
        const template = {templateId: this.optionsList[5]};
        const extensionName = this.optionsList[6];

        if (extensionName !== false) {
            template.extension = extensionName;
        }

        return template;
    }

    safeOpenTemplate(studio, template, options) {
        return new Promise((resolve) => {
            try {
                // openTemplateId is async (fetches template from Carbone API).
                // When the template finishes loading, the web component may reset
                // render options to defaults, discarding what we set synchronously.
                // Listen for the first options:updated event (emitted after template
                // load) and re-apply our options with forceRefreshPreview=true.
                studio.addEventListener(
                    "options:updated",
                    () => {
                        studio.setRenderOptions(options, true);
                    },
                    {once: true}
                );
                studio.openTemplateId(template["templateId"]);
                // Note : si le listener options:updated est consommé prematurement par notre propre appel
                // setRenderOptions (selon le comportement interne du web component Carbone), il faudrait alors retirer
                // l'appel synchrone et ne garder que le listener. A tester
                studio.setRenderOptions(options, true);
            } catch (e) {
                console.error("Error opening template:", e);
            }
            queueMicrotask(() => resolve());
        });
    }

    addStudioListeners(studio) {
        const events = {
            connected: "studio connected.",
            disconnected: "studio disconnected.",
            "options:updated": null,
        };

        Object.entries(events).forEach(([event, message]) => {
            studio.addEventListener(event, (e) => {
                if (message) {
                    console.log(message, e);
                } else {
                    console.log(e.detail);
                }
            });
        });
    }
}

// ========== API CARBONE ==========
class CarboneAPI {
    static async isCarboneManagerUser() {
        if (!user) return false;
        return await user.hasGroup("report_carbone.group_report_carbone_manager");
    }

    static async importCarboneJs() {
        try {
            const res = await rpc("/carbone_config/carbone_studio_params");
            await loadJS(res.js_url);
            return res.studio_url;
        } catch (e) {
            console.error(`Failed to launch Carbone Studio: ${e.message}`);
            return null;
        }
    }

    static async getCarboneApiKey() {
        try {
            const res = await rpc("/carbone_config/carbone_api_key", {});
            return res.token;
        } catch (e) {
            console.error("Failed to retrieve API key:", e);
            return null;
        }
    }

    static async getDefaultOptionParameter(irReportId) {
        try {
            const res = await rpc("/web/dataset/call_kw", {
                model: "ir.actions.report",
                method: "action_setup_carbone_studio_options",
                args: [[irReportId]],
                kwargs: {},
            });

            return [
                formatJsonData(res.context.json_data),
                formatJsonData(res.context.json_translate_data),
                res.context.lang,
                res.context.timezone,
                res.context.currency,
                res.context.template,
                res.context.extension,
            ];
        } catch (e) {
            console.error("Failed to retrieve options from backend:", e);
            return null;
        }
    }
}

// ========== PATCH FORM CONTROLLER ==========
patch(FormController.prototype, {
    // Allows you to systematically refresh the studio, either by scrolling through records using the arrows or
    // by switching back and forth between the list view.
    onWillLoadRoot(nextConfiguration) {
        super.onWillLoadRoot(...arguments);
        this.handleCarboneStudio(nextConfiguration.resId);
    },

    async onPagerUpdate(params) {
        await super.onPagerUpdate(...arguments);
        this.handleCarboneStudio(this.model.root.resId);
    },

    async onRecordSaved(record, changes) {
        await super.onRecordSaved(...arguments);
        this.handleCarboneStudio(this.model.root.resId);
    },

    handleCarboneStudio(resId) {
        const dynamicService = this.env.services.dynamic_element_service;
        const isCarbone = this.props.context.default_report_type === "carbone";

        if (!isCarbone) {
            this.waitForStudioThenRemove();
            return;
        }

        dynamicService?.refreshCarboneStudio(resId);
    },

    waitForStudioThenRemove() {
        DOMUtils.waitForElement(CARBONE_STUDIO_SELECTOR, (studio) => {
            DOMUtils.setDisplayNone(studio);
        });
    },
});

// ========== SERVICE DYNAMIC ELEMENT ==========
export const dynamicElementService = {
    dependencies: ["action"],
    start(env, services) {
        const manager = new CarboneStudioManager();

        async function refreshCarboneStudio(irReportId = null) {
            return await manager.refreshStudio(irReportId, services);
        }

        async function actionRefreshCarboneStudio() {
            await refreshCarboneStudio(manager.startIrReportId);
        }

        registry.category("actions").add("action_refresh_carbone_studio", actionRefreshCarboneStudio);

        return {refreshCarboneStudio};
    },
};

registry.category("services").add("dynamic_element_service", dynamicElementService);
