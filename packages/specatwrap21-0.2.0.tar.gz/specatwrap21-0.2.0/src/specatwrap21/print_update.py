"""
CLI command to print the standalone update script for the restricted environment.
"""

import click


@click.command("print-update-script")
def print_update_script():
    """
    Print a standalone Python script for updating specatwrap on the restricted environment.

    The script finds the currently installed version (e.g., specatwrap10),
    uninstalls it, and installs the next version (specatwrap11).

    Usage on development machine:

        specatwrap print-update-script > update_specatwrap.py

    Then transfer update_specatwrap.py to the restricted environment and run:

        python update_specatwrap.py
    """
    script = '''#!/usr/bin/env python3
"""
Standalone update script for specatwrap package.

This script:
1. Finds the currently installed specatwrap version (e.g., specatwrap10)
2. Uninstalls it without confirmation
3. Installs the next version (e.g., specatwrap11)

Usage:
    python update_specatwrap.py
"""

import subprocess
import sys
import re


def run_command(cmd, capture=True):
    """Run a shell command and return the result."""
    try:
        result = subprocess.run(
            cmd,
            shell=True,
            capture_output=capture,
            text=True,
            check=False
        )
        return result
    except Exception as e:
        print(f"Error running command: {e}")
        sys.exit(1)


def find_installed_version():
    """Find the currently installed specatwrap package."""
    result = run_command("pip list")
    
    if result.returncode != 0:
        print("Error: Failed to run 'pip list'")
        print(result.stderr)
        sys.exit(1)
    
    # Look for specatwrap packages in pip list output
    lines = result.stdout.split('\\n')
    specatwrap_packages = []
    
    for line in lines:
        # Match lines starting with specatwrap (with or without version number)
        match = re.match(r'^(specatwrap\\d*)\\s+', line.strip())
        if match:
            specatwrap_packages.append(match.group(1))
    
    if not specatwrap_packages:
        print("Error: No specatwrap package found.")
        print("Please install specatwrap manually first.")
        sys.exit(1)
    
    if len(specatwrap_packages) > 1:
        print(f"Error: Multiple specatwrap packages found: {specatwrap_packages}")
        print("Please uninstall extra versions manually.")
        sys.exit(1)
    
    return specatwrap_packages[0]


def parse_version(package_name):
    """Extract version number from package name."""
    # Match specatwrap followed by digits
    match = re.match(r'^specatwrap(\\d+)$', package_name)
    
    if not match:
        # Package is just "specatwrap" without a number
        print(f"Error: Found '{package_name}' without version number.")
        print("This should not exist in the mirror.")
        sys.exit(1)
    
    return int(match.group(1))


def main():
    print("=" * 60)
    print("specatwrap Update Script")
    print("=" * 60)
    
    # Step 1: Find currently installed version
    print("\\n[1/3] Finding currently installed version...")
    current_package = find_installed_version()
    print(f"Found: {current_package}")
    
    # Parse version number and calculate next version
    current_version = parse_version(current_package)
    next_version = current_version + 1
    next_package = f"specatwrap{next_version}"
    
    print(f"Will update: {current_package} -> {next_package}")
    
    # Step 2: Uninstall old version
    print(f"\\n[2/3] Uninstalling {current_package}...")
    result = run_command(f"pip uninstall -y {current_package}", capture=False)
    
    if result.returncode != 0:
        print(f"\\nError: Failed to uninstall {current_package}")
        sys.exit(1)
    
    print(f"Successfully uninstalled {current_package}")
    
    # Step 3: Install new version
    print(f"\\n[3/3] Installing {next_package}...")
    result = run_command(f"pip install {next_package}", capture=False)
    
    if result.returncode != 0:
        print(f"\\nError: Failed to install {next_package}")
        print("\\nPossible reasons:")
        print("  - The new version may not be available yet in the PyPI mirror")
        print("  - The mirror updates once daily")
        print("  - Please try again later or check if the package was published")
        sys.exit(1)
    
    print(f"\\nSuccessfully installed {next_package}")
    
    print("\\n" + "=" * 60)
    print("Update complete!")
    print("=" * 60)
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("\\nUpdate cancelled.")
        sys.exit(1)
    except Exception as e:
        print(f"\\nUnexpected error: {e}")
        sys.exit(1)
'''
    click.echo(script)
