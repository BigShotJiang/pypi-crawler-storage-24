"""Placeholder package; real implementation will ship in a later release."""

__version__ = "0.0.1"
