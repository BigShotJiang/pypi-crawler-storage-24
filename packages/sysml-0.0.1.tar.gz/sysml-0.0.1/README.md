# sysml (PyPI name hold)

This is a **minimal placeholder** on PyPI to reserve the `sysml` distribution name for the Starforge / related tooling effort.

- **Do not depend on this package** for production use until a real release is published.
- Replace `Source` / URLs in `pyproject.toml` with the canonical repository before wider publication.

## Build and upload (maintainers)

```bash
cd sysml
python -m pip install --upgrade build twine
python -m build
twine check dist/*
twine upload dist/*
```

Use [TestPyPI](https://test.pypi.org/) first if you want a dry run:

```bash
twine upload --repository testpypi dist/*
```
