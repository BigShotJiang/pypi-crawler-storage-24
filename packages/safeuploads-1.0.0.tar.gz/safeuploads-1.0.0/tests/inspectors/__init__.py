"""Tests for inspector modules."""
