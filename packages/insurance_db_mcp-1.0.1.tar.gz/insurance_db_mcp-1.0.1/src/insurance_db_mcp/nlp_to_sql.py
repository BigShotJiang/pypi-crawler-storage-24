"""NLP转SQL模块 - 将自然语言转换为SQL查询"""
import httpx
import json
import re
from db import SCHEMA_INFO

# ============================
# LLM方式：通过大模型API转换
# ============================

SYSTEM_PROMPT = f"""你是一个专业的SQL专家。根据用户的自然语言描述，生成对应的MySQL SQL查询语句。

数据库结构如下：
{SCHEMA_INFO}

严格规则：
1. 只返回纯SQL语句，不要任何解释、注释或markdown格式
2. SQL语句末尾不要加分号
3. 使用合适的JOIN来关联表
4. 如果查询涉及中文值，注意使用正确的字段匹配
5. 对于模糊查询使用LIKE
6. 日期相关查询使用合适的MySQL日期函数
7. 默认限制返回100条记录(除非用户指定了数量)
8. 支持SELECT/INSERT/UPDATE/DELETE所有操作
9. 对于写操作(INSERT/UPDATE/DELETE)，必须确保SQL是正确且安全的
"""


async def nlp_to_sql_with_llm(
    natural_language: str,
    api_url: str,
    api_key: str,
    model: str = "gpt-3.5-turbo",
) -> dict:
    """使用LLM API将自然语言转换为SQL"""
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.post(
                api_url,
                headers={
                    "Content-Type": "application/json",
                    "Authorization": f"Bearer {api_key}",
                },
                json={
                    "model": model,
                    "messages": [
                        {"role": "system", "content": SYSTEM_PROMPT},
                        {"role": "user", "content": natural_language},
                    ],
                    "temperature": 0.1,
                    "max_tokens": 1000,
                },
            )
            response.raise_for_status()
            data = response.json()
            sql = data.get("choices", [{}])[0].get("message", {}).get("content", "").strip()
            if not sql:
                raise ValueError("LLM返回空结果")
            # 清理SQL
            sql = re.sub(r"```sql\n?", "", sql, flags=re.IGNORECASE)
            sql = re.sub(r"```\n?", "", sql)
            sql = sql.strip().rstrip(";")
            return {"sql": sql, "method": "llm", "model": model}
    except Exception as e:
        raise RuntimeError(f"LLM转换失败: {e}")


# ============================
# 内置方式：基于规则的NLP解析
# ============================

TABLE_MAP = {
    "客户": "customers", "用户": "customers", "customer": "customers",
    "保单": "policies", "保险单": "policies", "policy": "policies",
    "理赔": "claims", "理赔记录": "claims", "claim": "claims",
    "缴费": "premiums", "缴费记录": "premiums", "付款": "premiums",
    "支付": "premiums", "premium": "premiums",
}

FIELD_MAP = {
    "customers": {
        "客户id": "customer_id", "客户编号": "customer_id", "姓名": "name", "名字": "name",
        "性别": "gender", "出生日期": "birth_date", "生日": "birth_date",
        "城市": "city", "地区": "city", "注册日期": "registration_date",
        "客户等级": "customer_level", "等级": "customer_level", "级别": "customer_level",
        "总保费": "total_premium", "保费总额": "total_premium",
    },
    "policies": {
        "保单id": "policy_id", "保单编号": "policy_id", "客户id": "customer_id",
        "保单类型": "policy_type", "类型": "policy_type", "保费": "premium",
        "开始日期": "start_date", "起始日期": "start_date", "生效日期": "start_date",
        "结束日期": "end_date", "到期日期": "end_date", "状态": "status",
    },
    "claims": {
        "理赔id": "claim_id", "理赔编号": "claim_id", "保单id": "policy_id",
        "客户id": "customer_id", "理赔金额": "claim_amount", "金额": "claim_amount",
        "理赔日期": "claim_date", "日期": "claim_date", "状态": "status",
    },
    "premiums": {
        "缴费id": "premium_id", "缴费编号": "premium_id", "保单id": "policy_id",
        "客户id": "customer_id", "缴费金额": "amount", "金额": "amount",
        "缴费日期": "payment_date", "日期": "payment_date",
        "支付方式": "payment_method", "缴费方式": "payment_method",
    },
}

AGG_MAP = {
    "总数": "COUNT(*)", "数量": "COUNT(*)", "个数": "COUNT(*)", "多少": "COUNT(*)", "几个": "COUNT(*)",
    "总计": "SUM", "总额": "SUM", "合计": "SUM", "总和": "SUM",
    "平均": "AVG", "均值": "AVG", "平均值": "AVG",
    "最大": "MAX", "最高": "MAX", "最多": "MAX",
    "最小": "MIN", "最低": "MIN", "最少": "MIN",
}


def _detect_table(query: str) -> str:
    for keyword, table in TABLE_MAP.items():
        if keyword in query:
            return table
    return "customers"


def _detect_aggregation(query: str, table: str) -> tuple:
    for keyword, func in AGG_MAP.items():
        if keyword in query:
            if func == "COUNT(*)":
                return True, "COUNT(*)", None
            # 找聚合字段
            default_fields = {
                "customers": "total_premium", "policies": "premium",
                "claims": "claim_amount", "premiums": "amount",
            }
            field = None
            for fk, fn in FIELD_MAP.get(table, {}).items():
                if fk in query:
                    field = fn
                    break
            if not field:
                field = default_fields.get(table, "*")
            return True, func, field
    return False, None, None


def _detect_group_by(query: str, table: str) -> str:
    triggers = ["按", "每个", "各", "分别", "group by", "各个"]
    if not any(t in query for t in triggers):
        return None
    group_keywords = {
        "城市": "city", "地区": "city", "类型": "policy_type",
        "等级": "customer_level", "级别": "customer_level",
        "状态": "status", "性别": "gender",
        "支付方式": "payment_method", "缴费方式": "payment_method",
    }
    for kw, field in group_keywords.items():
        if kw in query:
            return field
    # 时间分组
    date_field_map = {
        "customers": "registration_date", "policies": "start_date",
        "claims": "claim_date", "premiums": "payment_date",
    }
    df = date_field_map.get(table)
    if df:
        if "月" in query or "月份" in query:
            return f"DATE_FORMAT({df}, '%Y-%m')"
        if "年" in query:
            return f"YEAR({df})"
    return None


def _detect_conditions(query: str, table: str) -> list:
    conditions = []
    # 状态
    status_patterns = [
        (r"(?:有效|生效|active)", "active"),
        (r"(?:过期|失效|expired)", "expired"),
        (r"(?:待处理|pending)", "pending"),
        (r"(?:已完成|completed|已结案|已赔付)", "completed"),
        (r"(?:已拒绝|rejected|拒赔)", "rejected"),
        (r"(?:已取消|cancelled|canceled)", "cancelled"),
    ]
    for pat, val in status_patterns:
        if re.search(pat, query):
            conditions.append(f"status = '{val}'")
            break
    # 通用字段=值
    generic = [
        (r"城市(?:为|是|在|=)\s*[\"']?(\S+?)[\"']?(?:\s|$|，|。|的)", "city"),
        (r"性别(?:为|是|=)\s*[\"']?(\S+?)[\"']?(?:\s|$|，|。)", "gender"),
        (r"(?:等级|级别)(?:为|是|=)\s*[\"']?(\S+?)[\"']?(?:\s|$|，|。)", "customer_level"),
        (r"(?:保单)?类型(?:为|是|=)\s*[\"']?(\S+?)[\"']?(?:\s|$|，|。)", "policy_type"),
        (r"(?:姓名|名字)(?:为|是|叫)\s*[\"']?(\S+?)[\"']?(?:\s|$|，|。)", "name"),
    ]
    for pat, field in generic:
        m = re.search(pat, query)
        if m:
            conditions.append(f"{field} = '{m.group(1)}'")
    # 数值比较
    numeric_fields = ["total_premium", "premium", "claim_amount", "amount"]
    cmp_ops = [
        (r"(?:大于|超过|高于)\s*(\d+(?:\.\d+)?)", ">"),
        (r"(?:小于|低于|少于|不足)\s*(\d+(?:\.\d+)?)", "<"),
        (r"(?:大于等于|不小于|至少)\s*(\d+(?:\.\d+)?)", ">="),
        (r"(?:小于等于|不大于|不超过|至多)\s*(\d+(?:\.\d+)?)", "<="),
    ]
    for fk, fn in FIELD_MAP.get(table, {}).items():
        if fn in numeric_fields:
            for pat, op in cmp_ops:
                full_pat = f"{re.escape(fk)}\\s*{pat}"
                m = re.search(full_pat, query)
                if m:
                    conditions.append(f"{fn} {op} {m.group(1)}")
    # 最近X天/月/年
    date_field_map = {
        "customers": "registration_date", "policies": "start_date",
        "claims": "claim_date", "premiums": "payment_date",
    }
    df = date_field_map.get(table)
    if df:
        m = re.search(r"(?:最近|过去)\s*(\d+)\s*(天|月|年)", query)
        if m:
            num, unit = m.group(1), m.group(2)
            u = {"天": "DAY", "月": "MONTH", "年": "YEAR"}[unit]
            conditions.append(f"{df} >= DATE_SUB(NOW(), INTERVAL {num} {u})")
    return conditions


def _detect_order(query: str, table: str) -> str:
    direction = "DESC" if any(k in query for k in ["降序", "从高到低", "从大到小", "倒序"]) else "ASC"
    if any(k in query for k in ["升序", "从低到高", "从小到大", "正序"]):
        direction = "ASC"
    for fk, fn in FIELD_MAP.get(table, {}).items():
        if f"按{fk}" in query or f"根据{fk}" in query:
            return f"{fn} {direction}"
    defaults = {
        "customers": "registration_date DESC", "policies": "start_date DESC",
        "claims": "claim_date DESC", "premiums": "payment_date DESC",
    }
    return defaults.get(table)


def _detect_limit(query: str) -> str:
    m = re.search(r"(?:前|限制|只显示|只要|最多|top)\s*(\d+)", query, re.IGNORECASE)
    if m:
        return f" LIMIT {m.group(1)}"
    return " LIMIT 100"


def nlp_to_sql_builtin(natural_language: str) -> dict:
    """使用内置规则引擎将自然语言转换为SQL"""
    query = natural_language.lower().strip()
    table = _detect_table(query)
    is_agg, agg_func, agg_field = _detect_aggregation(query, table)
    group_by = _detect_group_by(query, table)
    conditions = _detect_conditions(query, table)
    order_by = _detect_order(query, table)
    limit = _detect_limit(query)

    if is_agg:
        if agg_func == "COUNT(*)":
            select = f"{'%s, ' % group_by if group_by else ''}COUNT(*) as count"
        else:
            select = f"{'%s, ' % group_by if group_by else ''}{agg_func}({agg_field}) as value"
        sql = f"SELECT {select} FROM {table}"
    else:
        sql = f"SELECT * FROM {table}"

    if conditions:
        sql += " WHERE " + " AND ".join(conditions)
    if group_by:
        sql += f" GROUP BY {group_by}"
    if order_by and not group_by:
        sql += f" ORDER BY {order_by}"
    sql += limit

    return {"sql": sql, "method": "builtin"}


# ============================
# 主入口
# ============================

async def nlp_to_sql(
    natural_language: str,
    llm_config: dict = None,
) -> dict:
    """
    将自然语言转换为SQL

    Args:
        natural_language: 自然语言查询
        llm_config: LLM配置 {"api_url": str, "api_key": str, "model": str}

    Returns:
        {"sql": str, "method": str}
    """
    if llm_config and llm_config.get("api_url") and llm_config.get("api_key"):
        try:
            return await nlp_to_sql_with_llm(
                natural_language,
                llm_config["api_url"],
                llm_config["api_key"],
                llm_config.get("model", "gpt-3.5-turbo"),
            )
        except Exception as e:
            # LLM失败时回退到内置引擎
            return nlp_to_sql_builtin(natural_language)
    return nlp_to_sql_builtin(natural_language)
