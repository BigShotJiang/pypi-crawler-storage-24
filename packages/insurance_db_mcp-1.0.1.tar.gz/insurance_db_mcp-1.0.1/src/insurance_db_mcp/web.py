"""
HTTP文档服务器 - 提供Web界面展示MCP工具的使用说明和接口文档
"""
import os
import asyncio
import json
from flask import Flask, jsonify, request
from flask_cors import CORS

# ✅ 修改为
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from db import execute_query, test_connection, get_table_stats, SCHEMA_INFO, JSONEncoder

from nlp_to_sql import (nlp_to_sql)

app = Flask(__name__)
CORS(app)

# LLM配置
LLM_CONFIG = {
    "api_url": os.environ.get("LLM_API_URL", ""),
    "api_key": os.environ.get("LLM_API_KEY", ""),
    "model": os.environ.get("LLM_MODEL", "gpt-3.5-turbo"),
}


@app.route("/")
def index():
    """返回服务说明与接口文档"""
    return """
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insurance DB MCP Tool - 服务文档</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #f5f7fa; color: #333; line-height: 1.6; }
        .container { max-width: 1200px; margin: 0 auto; padding: 40px 20px; }
        h1 { color: #2c3e50; margin-bottom: 10px; font-size: 2.5em; }
        .subtitle { color: #7f8c8d; margin-bottom: 30px; font-size: 1.1em; }
        .card { background: white; border-radius: 12px; padding: 30px; margin-bottom: 25px; box-shadow: 0 2px 12px rgba(0,0,0,0.08); }
        .card h2 { color: #2c3e50; border-bottom: 3px solid #3498db; padding-bottom: 12px; margin-bottom: 20px; font-size: 1.5em; }
        .card h3 { color: #34495e; margin: 20px 0 10px; font-size: 1.2em; }
        code { background: #f8f9fa; padding: 2px 6px; border-radius: 4px; font-family: 'Monaco', 'Menlo', monospace; font-size: 0.9em; color: #e74c3c; }
        pre { background: #2c3e50; color: #ecf0f1; padding: 20px; border-radius: 8px; overflow-x: auto; margin: 15px 0; font-size: 0.9em; }
        pre code { background: none; color: #ecf0f1; padding: 0; }
        .endpoint { background: #ecf0f1; padding: 15px; border-radius: 6px; margin: 10px 0; border-left: 4px solid #3498db; }
        .method { display: inline-block; padding: 4px 10px; border-radius: 4px; font-weight: bold; font-size: 0.85em; margin-right: 10px; }
        .get { background: #27ae60; color: white; }
        .post { background: #2980b9; color: white; }
        .param { display: inline-block; background: #f39c12; color: white; padding: 2px 8px; border-radius: 4px; font-size: 0.85em; margin-right: 8px; }
        .example { background: #e8f6f3; border-left: 4px solid #1abc9c; padding: 15px; margin: 15px 0; border-radius: 4px; }
        .badge { display: inline-block; padding: 4px 12px; border-radius: 20px; font-size: 0.85em; font-weight: 500; margin-right: 8px; }
        .badge-success { background: #d4edda; color: #155724; }
        .badge-info { background: #d1ecf1; color: #0c5460; }
        .badge-warning { background: #fff3cd; color: #856404; }
        table { width: 100%; border-collapse: collapse; margin: 15px 0; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background: #f8f9fa; font-weight: 600; color: #2c3e50; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔧 Insurance DB MCP Tool</h1>
        <p class="subtitle">通过自然语言操作保险数据库的MCP工具服务</p>

        <div class="card">
            <h2>📋 服务概述</h2>
            <p>这是一个基于 <strong>Model Context Protocol (MCP)</strong> 的工具服务，允许Agent通过自然语言查询和操作保险数据库，无需编写SQL。</p>
            <p style="margin-top: 15px;">
                <span class="badge badge-success">✅ 已连接数据库</span>
                <span class="badge badge-info">📊 4张数据表</span>
                <span class="badge badge-warning">🤖 支持NLP转SQL</span>
            </p>
        </div>

        <div class="card">
            <h2>🚀 MCP 加载方式</h2>
            <h3>方式1：通过 uv 直接运行</h3>
            <pre><code>cd /home/admin/workspace/mcp-db-tool
uv run insurance-db-mcp</code></pre>

            <h3>方式2：在 Claude Desktop / Cursor 中配置</h3>
            <pre><code>{
  "mcpServers": {
    "insurance-db": {
      "command": "uv",
      "args": ["--directory", "/path/to/mcp-db-tool", "run", "insurance-db-mcp"],
      "env": {
        "LLM_API_URL": "",
        "LLM_API_KEY": "",
        "LLM_MODEL": "gpt-3.5-turbo"
      }
    }
  }
}</code></pre>

            <h3>方式3：配置 LLM 增强 NLP 能力（可选）</h3>
            <pre><code>export LLM_API_URL="https://api.openai.com/v1/chat/completions"
export LLM_API_KEY="your-api-key"
export LLM_MODEL="gpt-3.5-turbo"</code></pre>
        </div>

        <div class="card">
            <h2>🛠️ MCP 工具列表</h2>

            <h3>1. query_by_natural_language</h3>
            <p>通过自然语言查询数据库（核心工具）</p>
            <div class="endpoint">
                <span class="method post">MCP Tool</span> <code>query_by_natural_language(question: str)</code>
            </div>
            <div class="endpoint" style="margin-top: 5px;">
                <span class="method post">HTTP API</span> <code>POST /api/nlp-query</code>
            </div>
            <p><strong>参数：</strong><span class="param">question</span> 自然语言查询问题</p>
            <div class="example">
                <strong>示例：</strong>
                <pre><code>curl -X POST /api/nlp-query \\
  -H "Content-Type: application/json" \\
  -d '{"question": "查询北京的VIP客户"}'</code></pre>
            </div>

            <h3>2. execute_sql_query</h3>
            <p>直接执行SQL查询</p>
            <div class="endpoint">
                <span class="method post">MCP Tool</span> <code>execute_sql_query(sql: str)</code>
            </div>
            <div class="endpoint" style="margin-top: 5px;">
                <span class="method post">HTTP API</span> <code>POST /api/sql-query</code>
            </div>

            <h3>3. get_database_schema</h3>
            <p>获取数据库完整结构信息</p>
            <div class="endpoint">
                <span class="method get">MCP Tool</span> <code>get_database_schema()</code>
            </div>
            <div class="endpoint" style="margin-top: 5px;">
                <span class="method get">HTTP API</span> <code>GET /api/schema</code>
            </div>

            <h3>4. get_database_stats</h3>
            <p>获取数据库统计信息</p>
            <div class="endpoint">
                <span class="method get">MCP Tool</span> <code>get_database_stats()</code>
            </div>
            <div class="endpoint" style="margin-top: 5px;">
                <span class="method get">HTTP API</span> <code>GET /api/stats</code>
            </div>

            <h3>5. get_table_sample</h3>
            <p>获取表的样本数据</p>
            <div class="endpoint">
                <span class="method get">MCP Tool</span> <code>get_table_sample(table_name: str, limit: int)</code>
            </div>
            <div class="endpoint" style="margin-top: 5px;">
                <span class="method get">HTTP API</span> <code>GET /api/table-sample?table_name=customers&limit=5</code>
            </div>

            <h3>6. test_db_connection</h3>
            <p>测试数据库连接状态</p>
            <div class="endpoint">
                <span class="method get">MCP Tool</span> <code>test_db_connection()</code>
            </div>
            <div class="endpoint" style="margin-top: 5px;">
                <span class="method get">HTTP API</span> <code>GET /api/test-connection</code>
            </div>
        </div>

        <div class="card">
            <h2>📊 数据库结构</h2>
            <table>
                <tr><th>表名</th><th>说明</th><th>主要字段</th></tr>
                <tr><td><code>customers</code></td><td>客户信息表</td><td>customer_id, name, gender, city, customer_level, total_premium</td></tr>
                <tr><td><code>policies</code></td><td>保单信息表</td><td>policy_id, customer_id, policy_type, premium, status</td></tr>
                <tr><td><code>claims</code></td><td>理赔记录表</td><td>claim_id, policy_id, customer_id, claim_amount, status</td></tr>
                <tr><td><code>premiums</code></td><td>缴费记录表</td><td>premium_id, policy_id, customer_id, amount, payment_method</td></tr>
            </table>
        </div>

        <div class="card">
            <h2>💡 自然语言查询示例</h2>
            <ul style="list-style: none; padding: 0;">
                <li style="padding: 8px 0;">🔹 "查询所有北京的客户"</li>
                <li style="padding: 8px 0;">🔹 "统计每个城市有多少客户"</li>
                <li style="padding: 8px 0;">🔹 "查看状态为有效的保单"</li>
                <li style="padding: 8px 0;">🔹 "最近30天的理赔记录"</li>
                <li style="padding: 8px 0;">🔹 "总保费超过10000的客户"</li>
                <li style="padding: 8px 0;">🔹 "每种保单类型的平均保费"</li>
                <li style="padding: 8px 0;">🔹 "前10个缴费金额最高的记录"</li>
            </ul>
        </div>
    </div>
</body>
</html>
    """


@app.route("/api/test-connection")
def test_connection_api():
    """测试数据库连接"""
    try:
        connected = test_connection()
        return jsonify({
            "success": True,
            "connected": connected,
            "message": "数据库连接正常" if connected else "数据库连接失败",
        })
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@app.route("/api/schema")
def get_schema_api():
    """获取数据库Schema"""
    return jsonify({"schema": SCHEMA_INFO})


@app.route("/api/stats")
def get_stats_api():
    """获取数据库统计"""
    try:
        stats = get_table_stats()
        return jsonify({
            "success": True,
            "database": "insurance_db",
            "tables": stats,
        })
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@app.route("/api/table-sample")
def get_table_sample_api():
    """获取表样本数据"""
    table_name = request.args.get("table_name", "customers")
    limit = int(request.args.get("limit", 5))
    valid_tables = ["customers", "policies", "claims", "premiums"]
    if table_name not in valid_tables:
        return jsonify({"success": False, "error": f"无效表名，可选: {', '.join(valid_tables)}"}), 400
    try:
        limit = min(limit, 50)
        sql = f"SELECT * FROM {table_name} LIMIT {limit}"
        result = execute_query(sql)
        return app.response_class(
            response=json.dumps(result, ensure_ascii=False, indent=2, cls=JSONEncoder),
            status=200,
            mimetype="application/json"
        )
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@app.route("/api/sql-query", methods=["POST"])
def execute_sql_api():
    """执行SQL查询"""
    data = request.get_json()
    sql = data.get("sql", "")
    if not sql:
        return jsonify({"success": False, "error": "SQL不能为空"}), 400
    try:
        result = execute_query(sql)
        return app.response_class(
            response=json.dumps(result, ensure_ascii=False, indent=2, cls=JSONEncoder),
            status=200,
            mimetype="application/json"
        )
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@app.route("/api/nlp-query", methods=["POST"])
def nlp_query_api():
    """自然语言查询 - 同步包装异步函数"""
    data = request.get_json()
    question = data.get("question", "")
    if not question:
        return jsonify({"success": False, "error": "问题不能为空"}), 400
    try:
        llm_cfg = LLM_CONFIG if LLM_CONFIG.get("api_url") else None
        # 使用 asyncio.run 来执行异步的 nlp_to_sql
        loop = asyncio.new_event_loop()
        try:
            conversion = loop.run_until_complete(nlp_to_sql(question, llm_config=llm_cfg))
        finally:
            loop.close()

        sql = conversion["sql"]
        method = conversion["method"]
        result = execute_query(sql)

        response_data = {
            "success": result.get("success", False),
            "question": question,
            "generated_sql": sql,
            "conversion_method": method,
        }

        if result.get("success"):
            if "data" in result:
                response_data["columns"] = result.get("columns", [])
                response_data["row_count"] = result.get("row_count", 0)
                response_data["data"] = result["data"]
            else:
                response_data["affected_rows"] = result.get("affected_rows", 0)
                response_data["message"] = result.get("message", "")
        else:
            response_data["error"] = result.get("error", "未知错误")

        return app.response_class(
            response=json.dumps(response_data, ensure_ascii=False, indent=2, cls=JSONEncoder),
            status=200,
            mimetype="application/json"
        )
    except Exception as e:
        return jsonify({
            "success": False,
            "question": question,
            "error": str(e),
        }), 500


def run_web_server(port: int = 3000):
    """启动HTTP文档服务器"""
    print(f"Starting Insurance DB MCP Tool HTTP Server on port {port}...")
    app.run(host="0.0.0.0", port=port, debug=False)


if __name__ == "__main__":
    run_web_server()
