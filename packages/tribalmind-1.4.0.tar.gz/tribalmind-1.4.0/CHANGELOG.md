# CHANGELOG

<!-- version list -->

## v1.4.0 (2026-03-14)

### Features

- Add Backboard dashboard UI with assistants, threads, and memory views
  ([`f37e539`](https://github.com/zachary-nguyen/TribalMind/commit/f37e5390fe6c8b466f59228498646dc1aa3ed384))


## v1.3.0 (2026-03-14)

### Features

- Enhance configuration loading and command handling
  ([`ab5a64a`](https://github.com/zachary-nguyen/TribalMind/commit/ab5a64aa3baf3a88bebb509f30be6618ca625e7a))


## v1.2.0 (2026-03-14)


## v1.1.0 (2026-03-14)


## v1.0.0 (2026-03-14)

- Initial Release
