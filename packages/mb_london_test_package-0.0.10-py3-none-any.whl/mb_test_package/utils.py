## utils functions

from dotenv import load_dotenv

def load_env(file_path: str = ".env"):
    """
    Load environment variables from a .env file.
    Args:
        file_path (str): Path to the .env file. Defaults to ".env".
    """
    load_dotenv(file_path)