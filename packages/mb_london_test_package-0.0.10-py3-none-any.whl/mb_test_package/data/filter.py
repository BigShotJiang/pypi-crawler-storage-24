## data filtering

from typing import List, Any
from mb.utils.logging import logg
import os
from collections import Counter
import re
import json
from PIL import Image
from mb.plt.utils import dynamic_plt
from PIL.ExifTags import TAGS

__all__ = ["DataModule"]


class DataModule:
    def __init__(self,logger=None):
        self.logger=logger
        logg.info('DataModule loader',self.logger)

    def _load_json_unquoted_keys(self,
                                 filepath: str):
        """
        Load JSON files that have unquoted keys by adding double quotes around them.
        """
        with open(filepath) as f:
            text = f.read()
        # Add double quotes around unquoted keys
        fixed = re.sub(r'(?<=[{,\n])\s*([A-Za-z_]\w*)\s*:', r' "\1":', text)
        return json.loads(fixed)        

    def _load_folder_data(self,
                          folder_path: str, 
                          confidence_threshold: int = 80):
        """
        Load image JSON data from a specific folder, filtering labels based on confidence threshold.
        Args:
            folder_path (str): Path to the folder containing image JSON files.
            confidence_threshold (float): Minimum confidence score for labels to be included in the output.
        """
        json_files = sorted([f for f in os.listdir(folder_path) if f.endswith('.jpg.json')])
        folder_data = {}
        for jf in json_files:
            img_name = jf.replace('.json', '')
            file_path = os.path.join(folder_path, jf)
            raw_data = self._load_json_unquoted_keys(file_path)
            
            label_count = Counter()
            all_labels = []
            confidence = []
            bboxes = []
            bboxes_labels = []
            for label in raw_data['Labels']:
                if label['Confidence'] < confidence_threshold:
                    continue
                num_instances = max(len(label['Instances']), 1)
                for i in range(num_instances):
                    label_count[label['Name']] += 1
                    all_labels.append(f"{label['Name']}_{label_count[label['Name']]}")
                    confidence.append(label['Confidence'])
                if label['Instances']:
                    for inst in label['Instances']:
                        bboxes.append({
                            'label': all_labels[-len(label['Instances']) + label['Instances'].index(inst)],
                            'bbox': inst['BoundingBox'],
                        })
                        bboxes_labels.append(bboxes[-1]['label'])
            
            img_file_path = file_path[:-5]
            exif_data = self._get_exif_data(img_file_path)

            folder_data[img_name] = {
                'file_path': file_path[:-5],
                'data': raw_data,
                'labels': all_labels,
                'confidence': confidence,
                'bboxes_labels': bboxes_labels,
                'bboxes': bboxes,
                'exif_data' : exif_data
            }
        return folder_data

    def load_all_data(self,
                      data_dir: str,
                    confidence_threshold: int = 80):
        """
        Load all image JSON data from all folders in the data directory.
        Args:
            data_dir (str): Path to the main data directory containing subfolders of images and JSON files.
            confidence_threshold (float): Minimum confidence score for labels to be included in the output.
        """
        all_data = {}
        folders = sorted([f for f in os.listdir(data_dir) if os.path.isdir(os.path.join(data_dir, f))])
        for folder in folders:
            folder_path = os.path.join(data_dir, folder)
            folder_data = self._load_folder_data(folder_path, confidence_threshold)
            all_data[folder] = folder_data
        logg.info(f"Loaded data for {len(all_data)} folders with confidence threshold {confidence_threshold}",
                   self.logger)
        return all_data

    def _get_bboxes_and_labels(self,
                               all_data: dict, 
                               folder: str):
        """
        Return per-image lists of bboxes (as x1,y1,x2,y2 in pixels) and labels.
        
        Args:
            all_data: Dictionary containing all loaded data.
            folder: Name of the folder to extract bboxes and labels from.
        Returns:
            imgs: List of image file paths.
            bbox_list: List of lists of bounding box coordinates for each image.
            label_list: List of lists of labels corresponding to each bounding box for each image.
        """
        imgs = []
        bbox_list = []
        label_list = []
        for img_name, img_info in all_data[folder].items():
            file_path = img_info['file_path']
            img = Image.open(file_path)
            w, h = img.size
            
            img_bboxes = []
            img_labels = []
            for b in img_info['bboxes']:
                bb = b['bbox']
                x1 = int(bb['Left'] * w)
                y1 = int(bb['Top'] * h)
                x2 = int((bb['Width']) * w)
                y2 = int((bb['Height']) * h)
                img_bboxes.append([x1, y1, x2, y2])
                img_labels.append(b['label'])
            
            imgs.append(file_path)
            bbox_list.append(img_bboxes)
            label_list.append(img_labels)
        return imgs, bbox_list, label_list

    def visualize_data(self,
                        imgs: List,
                        img_labels: List,
                        figsize: tuple = (16,14),
                        bboxes: List[List] = None,
                        bboxes_label: List[List] = None):
        """
        Visualize images with their corresponding labels and bounding boxes.
        Args:
            imgs (List): List of image file paths.  
            img_labels (List): List of lists of label names corresponding to each image.
            figsize (tuple): Size of the figure for visualization.
            bboxes (List[List]): List of lists of bounding box coordinates corresponding to each image.
            bboxes_label (List[List]): List of lists of labels corresponding to each bounding box.
        
        """
        assert len(imgs) == len(img_labels), "Length of imgs and img labels must be the same"
        if bboxes is not None:
            assert len(imgs) == len(bboxes), "Length of imgs and bboxes must be the same"
        if bboxes_label is not None:
            assert len(imgs) == len(bboxes_label), "Length of imgs and bboxes_label must be the same"
        dynamic_plt(imgs=imgs,
                    labels=img_labels,
                    num_cols=2,
                    figsize=figsize,
                    bboxes=bboxes,
                    bboxes_label=bboxes_label)

    def _get_exif_data(self, image_path):
        """
        Extract and print EXIF metadata from an image file.
        Args:
            image_path (str): Path to the image file.
        """
        try:
            with Image.open(image_path) as img:
                exif_data = img._getexif()

            if not exif_data:
                logg.info("No EXIF metadata found.", self.logger)
                return None

            result = {}
            for tag_id, value in exif_data.items():
                tag = TAGS.get(tag_id, tag_id)
                result[tag] = value
                if 'GPSInfo' in result:
                    return f"{result['GPSInfo']}"

            logg.info("No GPSInfo found in EXIF metadata.",self.logger)
            return None

        except Exception as e:
            logg.error(f"Failed to read EXIF data: {e}",self.logger)
            return None