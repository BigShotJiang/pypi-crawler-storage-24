"""
Document ingestion helpers for QuantumDrive.

Includes optional fact extraction wired to the QKGraphService.
"""

from __future__ import annotations

import logging
import os
from typing import Any, Dict, List, Optional

from agentfoundry.utils.agent_config import AgentConfig

from core.utils.qd_config import QDConfig
from core.kgraph.q_kgraph_service import get_q_kgraph_service
from core.kgraph.fact_extractor import FactExtractor

logger = logging.getLogger(__name__)


class DocumentIngestor:
    """Minimal ingestion helper that can extract facts into the KGraph."""

    def __init__(self, *, enable_fact_extraction: Optional[bool] = None) -> None:
        if enable_fact_extraction is None:
            enable_fact_extraction = os.getenv("QD_ENABLE_FACT_EXTRACTION", "true").lower() in ("1", "true", "yes", "on")
        self.enable_fact_extraction = enable_fact_extraction
        self._extractor = FactExtractor()

        qd_cfg = QDConfig.from_legacy_config()
        af_cfg = AgentConfig.from_dict(qd_cfg.get_af_config_dict())
        self._kgraph = get_q_kgraph_service(af_cfg)

    def ingest_text(
        self,
        text: str,
        *,
        metadata: Optional[Dict[str, Any]] = None,
        org_id: Optional[str] = None,
        user_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Ingest raw text and optionally extract facts into the knowledge graph.

        Returns a dict with counts and fact IDs.
        """
        meta = dict(metadata or {})
        if org_id is not None:
            meta.setdefault("org_id", org_id)
        if user_id is not None:
            meta.setdefault("user_id", user_id)

        fact_ids: List[str] = []
        if self.enable_fact_extraction and text:
            facts = self._extractor.extract(text, metadata=meta)
            for fact in facts:
                try:
                    fid = self._kgraph.upsert_fact(
                        fact.subject,
                        fact.predicate,
                        fact.obj,
                        metadata=fact.metadata,
                        org_id=meta.get("org_id"),
                        user_id=meta.get("user_id"),
                    )
                    fact_ids.append(fid)
                except Exception as exc:
                    logger.debug("Fact upsert failed: %s", exc)

        return {
            "facts_added": len(fact_ids),
            "fact_ids": fact_ids,
            "fact_extraction_enabled": self.enable_fact_extraction,
        }

    def ingest_source(
        self,
        source: Any,
        *,
        metadata: Optional[Dict[str, Any]] = None,
        org_id: Optional[str] = None,
        user_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Ingest a document source (path, URL, or file-like) and extract facts.

        This uses AgentFoundry's document_reader tool to normalize text.
        """
        from agentfoundry.agents.tools.document_reader import ingest_document

        text = ingest_document(source)
        return self.ingest_text(text, metadata=metadata, org_id=org_id, user_id=user_id)


def ingest_text_with_facts(
    text: str,
    *,
    metadata: Optional[Dict[str, Any]] = None,
    org_id: Optional[str] = None,
    user_id: Optional[str] = None,
    enable_fact_extraction: Optional[bool] = None,
) -> Dict[str, Any]:
    """Convenience helper to ingest text and extract facts."""
    ingestor = DocumentIngestor(enable_fact_extraction=enable_fact_extraction)
    return ingestor.ingest_text(text, metadata=metadata, org_id=org_id, user_id=user_id)


def ingest_source_with_facts(
    source: Any,
    *,
    metadata: Optional[Dict[str, Any]] = None,
    org_id: Optional[str] = None,
    user_id: Optional[str] = None,
    enable_fact_extraction: Optional[bool] = None,
) -> Dict[str, Any]:
    """Convenience helper to ingest a document source and extract facts."""
    ingestor = DocumentIngestor(enable_fact_extraction=enable_fact_extraction)
    return ingestor.ingest_source(source, metadata=metadata, org_id=org_id, user_id=user_id)
