"""
---
module: core.ai.prompts.elements_of_style
summary: Prompt partial for the Elements of Style text transformation skill.
description: >
  Defines the ELEMENTS_OF_STYLE prompt constant used by
  QAssistant.apply_elements_of_style() to revise text according to the
  core principles of Strunk & White's The Elements of Style. Focuses on
  omitting needless words, active voice, positive form, concrete language,
  and parallel structure.
exports:
  - ELEMENTS_OF_STYLE: str — the prompt instruction block
related:
  - core.ai.prompts.partials.PromptPartials
  - core.ai.prompts.registry (registered as "elements_of_style")
  - core.ai.q_assistant.QAssistant.apply_elements_of_style
  - webapp.app.api_elements_of_style
---
"""

ELEMENTS_OF_STYLE = """
### ELEMENTS OF STYLE
Revise the provided text by applying the core principles of Strunk & White's
*The Elements of Style*. Your goal is vigorous, clear prose.

PRINCIPLES TO ENFORCE:
1. **Omit needless words.** Every word must earn its place. Cut filler, redundancy,
   and throat-clearing ("It is interesting to note that...", "In order to...",
   "the fact that", "there is/are ... that").
2. **Use the active voice.** Prefer "the team delivered the report" over
   "the report was delivered by the team." Use passive only when the actor is
   unknown or irrelevant.
3. **Put statements in positive form.** Say what something IS, not what it is NOT.
   "He forgot" beats "He did not remember." Avoid noncommittal hedges
   ("not unlikely", "not insignificant").
4. **Use definite, specific, concrete language.** Replace vague generalities
   with precise details. "A period of unfavorable weather" becomes "it rained
   for three days."
5. **Prefer plain words.** Choose "use" over "utilize," "help" over "facilitate,"
   "start" over "commence." Fancy words do not make writing more persuasive.
6. **Keep related words together.** Subject near verb, modifier near the word
   it modifies. Avoid awkward splits and dangling modifiers.
7. **Express coordinate ideas in parallel form.** Items in a list or series
   should share the same grammatical structure.
8. **Place emphatic words at the end of a sentence.** The final position carries
   the most weight; use it for the idea you want to land.
9. **Favor nouns and verbs.** Strong writing depends on nouns and verbs, not
   adjectives and adverbs. Cut weak modifiers ("really", "quite", "very",
   "basically", "essentially").
10. **Revise and rewrite.** Tighten every sentence. If a paragraph says in
    fifty words what can be said in twenty, say it in twenty.

CONSTRAINTS:
- Preserve the original meaning, facts, and data exactly.
- Maintain existing formatting (Markdown headings, lists, code blocks, tables).
- Keep technical terms and domain-specific language intact.
- Do NOT add opinions, new information, or commentary.
- Output ONLY the revised text with no preamble or explanation.
"""
