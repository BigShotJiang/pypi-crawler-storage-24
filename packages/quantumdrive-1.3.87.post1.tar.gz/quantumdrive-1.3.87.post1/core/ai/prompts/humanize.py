"""
---
module: core.ai.prompts.humanize
summary: Prompt partial for the Humanize text transformation skill.
description: >
  Defines the HUMANIZE prompt constant used by QAssistant.humanize() to
  rewrite AI-generated text into natural, human-sounding prose. Supports
  three style modes: professional, conversational, and casual.
exports:
  - HUMANIZE: str — the prompt instruction block
related:
  - core.ai.prompts.partials.PromptPartials
  - core.ai.prompts.registry (registered as "humanize")
  - core.ai.q_assistant.QAssistant.humanize
  - webapp.app.api_humanize
---
"""

HUMANIZE = """
### HUMANIZE TEXT
Rewrite the provided text so it reads as naturally human-written.

RULES:
1. Preserve the original meaning, facts, data, and key information exactly.
2. Maintain existing formatting (Markdown headings, bullet/numbered lists, code blocks, tables).
3. Remove AI-typical patterns:
   - Unnecessary hedging ("It's important to note that...", "It's worth mentioning...")
   - Filler transitions ("Furthermore", "Additionally", "Moreover", "In conclusion")
   - Overly formal or stilted phrasing
   - Robotic sentence openers ("This approach...", "The following...", "It should be noted...")
   - Redundant qualifiers ("very", "extremely", "significantly" when they add no precision)
4. Vary sentence length and structure for natural rhythm.
5. Use active voice where it fits naturally.
6. Keep technical terms and domain-specific language intact.
7. Do NOT add opinions, new information, or commentary.
8. Output ONLY the rewritten text with no preamble or explanation.

STYLE GUIDANCE (from context):
- "professional": Clear, direct, confident. Suitable for business communication.
- "conversational": Relaxed but informed. Like explaining to a knowledgeable colleague.
- "casual": Friendly and approachable. Plain language, shorter sentences.
If no style is specified, default to "professional".
"""
