"""
---
module: core.ai.q_assistant
summary: Wrapper around agentfoundry Orchestrator with enriched logging.
responsibilities:
  - Initialize Orchestrator with registered tools and LLM
  - Provide a simple API to answer questions
  - Pass identity context (user_id, thread_id, org_id) to Orchestrator for memory scoping
logging:
  levels:
    - INFO: high-level lifecycle and outcomes
    - DEBUG: inputs, constructed configs, timings, sizes
  notes:
    - Exceptions include full tracebacks
    - Question text is truncated to avoid logging sensitive content in full
---

QAssistant: a wrapper around the agentfoundry Orchestrator with rich logging.

This module provides extensive instrumentation to make production diagnosis
easier. It captures initialization details, per-question timings, and the
identity context used to scope Orchestrator memory.
"""

from __future__ import annotations

import logging
import copy
import time
from typing import Optional, Union, Tuple, Any
import os

from agentfoundry.agents.orchestrator import Orchestrator

prompt_logger = logging.getLogger('quantify.prompts')

def _truncate(text: str, head: int = 200, tail: int = 200) -> str:
    """Return first *head* and last *tail* chars of *text*, eliding the middle."""
    s = str(text)
    if len(s) <= head + tail + 20:
        return s
    return f"{s[:head]}\n... ({len(s)} chars total) ...\n{s[-tail:]}"
from agentfoundry.cancellation import CancellationToken
from langgraph.checkpoint.memory import MemorySaver
from agentfoundry.registry.tool_registry import ToolRegistry
from agentfoundry.llm.llm_factory import LLMFactory
from agentfoundry.context.client_state import client_context_scope
from agentfoundry.agents.tools.system_introspection_tool import system_introspection_tool
from agentfoundry.agents.memory.thread_manager import ThreadManager

# Code Graph tools disabled — DuckDB single-writer lock causes cascading
# failures when any other process (Celery, scripts) holds the lock.
# Re-enable when CodeGraphTool moves to a shared-nothing architecture.
# from core.code_graph.tool import CodeGraphTool, build_tool
# from core.code_graph.builder import CodeGraphBuilder


ALLOWED_TOOL_NAMES = [
    # UI/page awareness
    "client_context_tool",
    "page_analyzer_tool",
    # System introspection and time
    "system_introspection",
    "current_date_time_tool",
    # Document/data helpers
    "document_reader",
    "pandas_explorer",
    "summarize_csv",
    "unzip_tool",
    "pdf_creator",
    # Scoped memory tools (user and active thread only by default)
    "save_thread_memory",
    "search_thread_memory",
    "save_user_memory",
    "search_user_memory",
    "search_org_memory",
    "summarize_any_memory",
    # External knowledge lookup
    "web_search_tool",
]

Q_SYSTEM_PROMPT = """You are Q, the intelligent AI companion for the Quantify application.
Your goal is to help users understand, navigate, and complete work in Quantify with accurate, concise answers.

Tool and context policy:
- Prefer already-provided context first: USER_MEMORY_HITS, FACT BLOCK, and KNOWLEDGE BASE CONTEXT.
- If that context answers the question, respond directly without extra tool calls.
- For "what am I looking at?", "what page is this?", or on-screen troubleshooting, use page_analyzer_tool first.
- If you are unsure what tools are available, call system_introspection with action="list_tools".
- If asked about app version/environment, use system_introspection with action="app_info" or "system_context".

Safety policy:
- Do not perform non-memory mutating actions unless the user explicitly asks in this turn and confirms intent.
- Non-memory mutating actions include scheduling jobs, executing code/commands, writing files, or external state changes.
- Never claim to have performed an action unless the corresponding tool succeeded.

Memory policy:
- Use thread memory for current-conversation details and user memory for durable user preferences/facts.
- Do not ask for facts already present in USER_MEMORY_HITS.
- Keep stored memory concise and relevant.

Response policy:
- Respond in Markdown: short headings, bullets/numbered lists, and fenced code blocks for code.
- Avoid raw HTML and do not embed paragraph tags in list elements.
"""


class QAssistant:
    """
    ---
    name: QAssistant
    summary: Thin facade over Orchestrator that adds logging and a convenient API.
    methods:
      - answer_question
      - run_task
      - humanize
      - apply_elements_of_style
    dependencies:
      - agentfoundry.agents.orchestrator.Orchestrator
      - agentfoundry.registry.tool_registry.ToolRegistry
      - agentfoundry.llm.llm_factory.LLMFactory
      - agentfoundry.agents.memory.thread_manager.ThreadManager
    logging:
      info:
        - Initialization progress and success
        - Each question processed and high-level outcome
        - Text transformation invocations and completions with sizes and timing
      debug:
        - Tool registry contents
        - IDs passed to Orchestrator and full config
        - Timings for chat calls
        - Prompt lengths and model role for text transformations
    ---

    A wrapper class for the Orchestrator to provide a simple interface for
    the digital assistant 'Q' to answer questions and apply text
    transformation skills (humanize, elements of style).
    """

    def __init__(self, user_id: str, org_id: str, orchestrator: Optional[Orchestrator] = None, allowed_tool_names: Optional[list[str]] = None) -> None:
        """Create a new class:`QAssistant` instance.

        The constructor tries to build a class: Orchestrator.  When
        *agentfoundry* is not available (e.g., in lightweight environments or
        during unit-testing), we transparently fall back to a *stub mode* that
        returns an informative placeholder string.  All execution paths are
        thoroughly logged.
        
        Args:
            user_id: The user identity.
            org_id: The organization identity.
            orchestrator: Optional existing Orchestrator instance.
        """

        self.logger = logging.getLogger(__name__)
        self.user_id = user_id
        self.org_id = org_id
        self.tool_registry: Optional[ToolRegistry] = None
        self.allowed_tool_names = allowed_tool_names or ALLOWED_TOOL_NAMES

        # Timestamp used to compute initialization duration later.
        _t0 = time.perf_counter()

        # Require agentfoundry components
        self.orchestrator: Orchestrator | None = orchestrator
        
        if ToolRegistry is None or LLMFactory is None or Orchestrator is None:
            self.logger.error("Agentfoundry dependencies missing; cannot initialize Orchestrator")
            raise RuntimeError("Agentfoundry unavailable: ToolRegistry/LLMFactory/Orchestrator missing")

        # -------------------------------------------------------------------
        # Real agent initialisation
        # -------------------------------------------------------------------
        if not self.orchestrator:
            try:
                # Resolve LLM provider/model via AgentFoundry config + env overrides.
                # Environment variables can be populated via Secrets Manager at startup.
                self.logger.debug("Creating LLM instances using factory/provider defaults")
                llm = LLMFactory.get_llm_by_role(role="reasoning")
                formatter_llm = LLMFactory.get_llm_by_role(role="formatting")

                self.tool_registry = ToolRegistry()
                project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
                shipped_tools_dir = os.path.join(project_root, "agentfoundry", "agents", "tools")
                local_quantify_tools_dir = os.path.join(project_root, "quantify", "tools")
                tool_directories_to_load = []
                if os.path.isdir(shipped_tools_dir):
                    tool_directories_to_load.append(shipped_tools_dir)
                else:
                    self.logger.warning("AgentFoundry shipped tools directory not found: %s", shipped_tools_dir)
                if os.path.isdir(local_quantify_tools_dir):
                    tool_directories_to_load.append(local_quantify_tools_dir)
                else:
                    self.logger.warning("Local Quantify tools directory not found: %s", local_quantify_tools_dir)
                if tool_directories_to_load:
                    self.logger.info("Loading tools from directories: %s", tool_directories_to_load)
                    self.tool_registry.load_tools_from_directory(directories=tool_directories_to_load)
                else:
                    self.logger.info("No explicit tool directories found; falling back to registry defaults.")
                    self.tool_registry.load_tools_from_directory()
                self.tool_registry.register_tool(system_introspection_tool)

                # Code Graph tools disabled (DuckDB lock issues)

                self.logger.info(f"Registered tools: {self.tool_registry.list_tools()}")

                # Ensure the orchestrator has an agent→tools map. If none is provided,
                # default to a single general agent with all registered tools.
                available_tools = self.tool_registry.as_langchain_tools()
                self.logger.info(f"QAssistant available tools: {[tool.name for tool in available_tools]}")
                allowed_names = set(self.allowed_tool_names)
                self.logger.info(f"QAssistant allowed tools: {allowed_names}")
                selected_tools = [t for t in available_tools if getattr(t, "name", "") in allowed_names]

                if not selected_tools:
                    missing = sorted(self.allowed_tool_names)
                    msg = (
                        "No tools matched the allowed list; aborting QAssistant init to avoid exposing all tools. "
                        f"Allowed list: {missing}"
                    )
                    self.logger.error(msg)
                    raise RuntimeError(msg)

                missing = allowed_names.difference({getattr(t, 'name', '') for t in selected_tools})
                if missing:
                    self.logger.warning(
                        "Some allowed tools were not found in registry and will be skipped: %s",
                        sorted(missing),
                    )
                self.logger.info("Filtered tools to %d allowed entries.", len(selected_tools))
                self.tool_registry.agent_tools = {"general_agent": selected_tools}
                self.logger.info("Configured agent_tools mapping with %d tools.", len(selected_tools))

                # Initialize the Orchestrator; failure is fatal
                self.orchestrator = Orchestrator(self.tool_registry, llm=llm, formatter_llm=formatter_llm, base_prompt=Q_SYSTEM_PROMPT)
                # Enforce QAssistant's allowed tool scope at the orchestrator level.
                self.orchestrator.master_tools = list(selected_tools)
                self.orchestrator._non_memory_tools = [  # pylint: disable=protected-access
                    t for t in self.orchestrator.master_tools
                    if getattr(t, "name", "") not in self.orchestrator._memory_tool_names  # pylint: disable=protected-access
                ]
                self.orchestrator.supervisor = self.orchestrator.load_orchestrator(
                    tools=self.orchestrator.master_tools,
                    prompt=self.orchestrator.base_prompt,
                    checkpointer=MemorySaver(),
                    name="supervisor",
                )
                self.logger.info("Applied allowed-tool scope to orchestrator (%d tools).", len(self.orchestrator.master_tools))
                self.logger.info("Orchestrator initialized successfully.")

            except Exception as e:  # pragma: no cover
                self.logger.exception(f"Failed to initialise Orchestrator: {e}")
                raise
        
        # --- NEW LOGIC START ---
        self.thread_manager = ThreadManager()
        
        # 1. Try to find the last active thread for this user/org
        latest_thread = self.thread_manager.get_latest_thread(user_id, org_id)
        
        if latest_thread:
            # Resume the existing conversation
            self.thread_id = latest_thread
            self.logger.info(f"Resuming existing thread: {self.thread_id}")
        else:
            # First time user? Start at "1" (or whatever your default is)
            self.thread_id = self.thread_manager.generate_next_thread_id(user_id, org_id)
            self.logger.info(f"Starting new thread: {self.thread_id}")
        # --- NEW LOGIC END ---

        self.memory = MemorySaver() # KEY CHANGE: QAssistant owns the session state now
        
        self.config = {
            "configurable": {
                "user_id": user_id,
                "thread_id": self.thread_id,
                "org_id": org_id
            }
        }

    def answer_question(
            self,
            question: str,
            client_context: Optional[dict] = None,
            user_assertion: Optional[str] = None,
            cancel_token: CancellationToken | None = None,
    ) -> str:
        """
        ---
        method: answer_question
        summary: Answer a user question using Orchestrator with memory scoped by IDs.
        parameters:
          question:
            type: str
            required: true
            description: The user's natural-language question.
        returns:
          type: str
          description: Assistant's reply.
        raises:
          - RuntimeError: if the underlying agent is not initialized.
          - Exception: any error raised by the Orchestrator; logged with traceback.
        logging:
          info:
            - Start/end of processing with truncated question and reply
          debug:
            - IDs used and constructed config
            - Call duration and reply length
        ---

        Answer a question using the underlying Orchestrator agent. The
        Orchestrator maintains memory keyed by the provided IDs.
        """

        self.logger.info(f"Processing question: {question[:85]} from user_id={self.user_id} thread_id={self.thread_id} org_id={self.org_id}...")

        if not self.orchestrator:
            self.logger.error("QAssistant agent not initialized; aborting")
            raise RuntimeError("QAssistant unavailable: Orchestrator not initialized")

        _t0 = time.perf_counter()
        try:
            self.logger.info("QAssistant mode=agent (chat)")
            messages = []
            # Opportunistic user-memory recall targeted to the question to
            # improve personal answers (e.g., "my eye color") even when the
            # agent chooses not to invoke tools on its own.
            try:
                if self.user_id and self.org_id:
                    from agentfoundry.agents.memory.user_memory import UserMemory as _UM
                    um = _UM(self.user_id, self.org_id)
                    hits = um.semantic_search(question, caller_role_level=0, k=5)
                    if hits:
                        snippet = "\n".join(f"- {h}" for h in hits)
                        self.logger.info("QAssistant preloaded %d user-memory hits for query", len(hits))
                        self.logger.info(
                            "QAssistant memory hit contents: %s",
                            snippet[:500]
                        )
                        messages.append({"role": "system", "content": f"USER_MEMORY_HITS:\n{snippet}"})
            except Exception as _um_ex:  # noqa: E722  (defensive)
                self.logger.debug("UserMemory preload failed: %s", _um_ex)

            # Optional Knowledge Graph fact block (high-precision facts)
            try:
                enable_fact_block = os.getenv("QD_ENABLE_FACT_BLOCK", "false").lower() in ("1", "true", "yes", "on")
                if enable_fact_block:
                    from core.kgraph.q_kgraph_service import get_q_kgraph_service
                    from core.utils.qd_config import QDConfig
                    from agentfoundry.utils.agent_config import AgentConfig
                    from agentfoundry.agents.memory.constants import SYSTEM_USER_ID

                    qd_cfg = QDConfig.from_legacy_config()
                    af_cfg = AgentConfig.from_dict(qd_cfg.get_af_config_dict())
                    kg = get_q_kgraph_service(af_cfg)

                    facts = kg.search(question, org_id=self.org_id, user_id=self.user_id, k=5) or []
                    if self.user_id != SYSTEM_USER_ID:
                        facts += kg.search(question, org_id=self.org_id, user_id=SYSTEM_USER_ID, k=5) or []

                    if facts:
                        lines = ["FACT BLOCK:"]
                        for f in facts:
                            subj = f.get("subject", "")
                            pred = f.get("predicate", "")
                            obj = f.get("object", "")
                            score = f.get("score")
                            if score is None:
                                lines.append(f"- {subj} | {pred} | {obj}")
                            else:
                                lines.append(f"- {subj} | {pred} | {obj} (score={score:.4f})")
                        fact_block = "\n".join(lines)
                        self.logger.info("QAssistant preloaded KGraph facts (%d items)", len(facts))
                        messages.append({"role": "system", "content": fact_block})
            except Exception as _kg_ex:
                self.logger.debug("KGraph fact preload failed: %s", _kg_ex)

            # Opportunistic VectorStore RAG — always consult the knowledge base
            try:
                from core.rag.q_rag_context import get_q_rag_context_service

                rag_svc = get_q_rag_context_service()
                rag_context = rag_svc.get_context(question, org_id=self.org_id)
                if rag_context:
                    self.logger.info("QAssistant preloaded VectorStore RAG context (%d chars)", len(rag_context))
                    messages.append({"role": "system", "content": rag_context})
            except Exception as _rag_ex:
                self.logger.debug("VectorStore RAG preload failed: %s", _rag_ex)

            messages.append({"role": "user", "content": question})
            
            self.logger.debug(
                "Calling orchestrator.process_request with ids user_id=%s thread_id=%s org_id=%s",
                self.config["configurable"]["user_id"], self.config["configurable"]["thread_id"], self.config["configurable"]["org_id"],
            )
            effective_config = copy.deepcopy(self.config)
            if user_assertion:
                effective_config["configurable"]["entra_user_assertion"] = user_assertion
                self.logger.debug("Added entra_user_assertion to config for this request.")
            with client_context_scope(client_context or {}):
                # Older Orchestrator expects positional message; avoid keyword mismatch
                response = self.orchestrator.process_request(messages, checkpointer=self.memory, config=effective_config, cancel_token=cancel_token)
            elapsed = time.perf_counter() - _t0
            self.logger.debug("agent.process_request completed in %.3f s (reply_len=%d)", elapsed, len(str(response)))
            self.logger.info("Response: %s", response)

            # --- Prompt/response log ---
            _sys_parts = [m["content"] for m in messages if m.get("role") == "system"]
            _sys_block = ("\n".join(_sys_parts) + "\n") if _sys_parts else ""
            prompt_logger.info(
                "PROMPT >>> [answer_question] elapsed=%.3fs\n%s%s\nRESPONSE <<<\n%s\n--- END ---",
                elapsed, _truncate(_sys_block), _truncate(question), _truncate(response),
            )

            return response
        except Exception:
            self.logger.exception("Exception while processing question: %s", question)
            raise

    def run_task(self, task: str, *, use_memory: bool = False, additional: bool = False,
                 allow_tools: bool = False, allowed_tool_names: list[str] | None = None,
                 file_ids: list | None = None, vector_store_id: str | None = None,
                 model_role: str = "reasoning",
                 cancel_token: CancellationToken | None = None) -> Union[str, Tuple[str, Any]]:
        """
        ---
        method: run_task
        summary: Execute a single-turn task via Orchestrator.run_task.
        notes:
          - Stateless helper intended for one-off operations or smoke tests.
          - Set use_memory=true to inject summarized memory context (optional).
        parameters:
          task:
            type: str
            required: true
            description: The instruction or question to execute.
          use_memory:
            type: bool
            required: false
            default: false
            description: When true, Orchestrator adds a summarized memory context.
          additional:
            type: bool
            required: false
            default: false
            description: When true, also returns full supervisor outputs.
        returns:
          type: str | tuple[str, Any]
          description: Assistant reply, optionally with the full responses' payload.
        raises:
          - RuntimeError: if the agent is not initialized.
          - Exception: bubbled up from the Orchestrator and logged with traceback.
        ---

        Execute a single-turn task through the Orchestrator's run_task helper.
        """
        self.logger.info(f"Running task (stateless): {task[:85]}...")
        try:
            _n_files = len(file_ids or [])
        except Exception:
            _n_files = 0
        self.logger.debug(
            "run_task params: use_memory=%s additional=%s allow_tools=%s allowed_tool_names=%s file_ids_count=%d vector_store_id=%s",
            use_memory, additional, allow_tools, bool(allowed_tool_names), _n_files, bool(vector_store_id),
        )

        if not self.orchestrator:
            self.logger.error("QAssistant agent not initialized; aborting")
            raise RuntimeError("QAssistant unavailable: Orchestrator not initialized")

        _t0 = time.perf_counter()
        try:
            # If file IDs are provided, route via chat() so the underlying
            # Orchestrator can attach files to the request (Responses API).
            if file_ids:
                self.logger.info(
                    "Routing run_task via chat() due to file attachments (files=%d)",
                    len(file_ids or []),
                )
                messages = [{"role": "user", "content": task}]
                # Use the same config path; Orchestrator.chat will include memory
                # as a system message automatically.
                result = self.orchestrator.chat(messages=messages, checkpointer=self.memory, config=self.config, additional=additional, file_ids=file_ids, vector_store_id=vector_store_id, cancel_token=cancel_token)
            else:
                self.logger.debug(
                    f"Calling orchestrator.run_task(use_memory={use_memory}, additional={additional}) without file attachments"
                )
                result = self.orchestrator.run_task(
                    task,
                    checkpointer=self.memory,
                    use_memory=use_memory,
                    additional=additional,
                    allow_tools=allow_tools,
                    allowed_tool_names=allowed_tool_names,
                    config=self.config,
                    model_role=model_role,
                    cancel_token=cancel_token,
                )
            elapsed = time.perf_counter() - _t0
            # Normalize logging for both return shapes
            if isinstance(result, tuple) and len(result) >= 1:
                reply = result[0]
            else:
                reply = result  # type: ignore[assignment]
            self.logger.debug(
                "run_task completed in %.3f s (reply_len=%d, routed_via=%s)",
                elapsed,
                len(str(reply)),
                ("chat" if file_ids else "run_task"),
            )
            self.logger.info("Task response head: %s", str(reply)[:300])

            # --- Prompt/response log ---
            prompt_logger.info(
                "PROMPT >>> [run_task] model_role=%s elapsed=%.3fs\n%s\nRESPONSE <<<\n%s\n--- END ---",
                model_role, elapsed, _truncate(task), _truncate(reply),
            )

            return result
        except Exception:
            self.logger.exception("Exception while running task: %s", task)
            raise

    _VALID_HUMANIZE_STYLES = {"professional", "conversational", "casual"}

    def humanize(
            self,
            text: str,
            style: str = "professional",
            cancel_token: CancellationToken | None = None,
    ) -> str:
        """
        ---
        method: humanize
        summary: Rewrite AI-generated text to sound more naturally human-written.
        parameters:
          text:
            type: str
            required: true
            description: The text to humanize.
          style:
            type: str
            required: false
            default: professional
            description: >
              Writing style — one of "professional", "conversational", or "casual".
              Invalid values raise ValueError.
        returns:
          type: str
          description: The humanized text.
        raises:
          - ValueError: if text is empty or style is invalid.
          - RuntimeError: if the Orchestrator is not initialized.
        logging:
          info:
            - Invocation with style and input length
            - Completion with output length and elapsed time
          debug:
            - Prompt length and model role
        related:
          - core.ai.prompts.humanize.HUMANIZE
          - webapp.app.api_humanize
        ---

        Post-process text through the LLM with humanize instructions.
        Uses the formatter LLM (model_role="formatting") with no tools
        or memory for a lightweight, single-turn transformation.
        """
        if not text or not text.strip():
            self.logger.warning("humanize called with empty text")
            raise ValueError("Cannot humanize empty text.")

        style = style.strip().lower() if isinstance(style, str) else "professional"
        if style not in self._VALID_HUMANIZE_STYLES:
            self.logger.warning("humanize called with invalid style=%r", style)
            raise ValueError(
                f"Invalid style {style!r}. Choose from: {', '.join(sorted(self._VALID_HUMANIZE_STYLES))}"
            )

        from core.ai.prompts import PromptPartials

        prompt = (
            "You are an expert editor and writer who transforms AI-generated "
            "text into natural, human-sounding prose.\n\n"
            f"{PromptPartials.HUMANIZE}\n\n"
            f"Style: {style}\n\n"
            f"Text to humanize:\n\n{text}"
        )

        self.logger.info(
            "Humanizing text (style=%s, input_len=%d, user_id=%s, org_id=%s)",
            style, len(text), self.user_id, self.org_id,
        )
        self.logger.debug(
            "humanize prompt_len=%d, model_role=formatting", len(prompt),
        )

        _t0 = time.perf_counter()
        try:
            result = self.run_task(
                prompt,
                use_memory=False,
                allow_tools=False,
                model_role="formatting",
                cancel_token=cancel_token,
            )
        except Exception:
            elapsed = time.perf_counter() - _t0
            self.logger.exception(
                "Humanize failed after %.3f s (style=%s, input_len=%d)",
                elapsed, style, len(text),
            )
            raise

        reply = result[0] if isinstance(result, tuple) else result
        elapsed = time.perf_counter() - _t0
        self.logger.info(
            "Humanize complete (output_len=%d, elapsed=%.3f s)", len(str(reply)), elapsed,
        )
        return reply

    def apply_elements_of_style(
            self,
            text: str,
            cancel_token: CancellationToken | None = None,
    ) -> str:
        """
        ---
        method: apply_elements_of_style
        summary: Revise text using Strunk & White's Elements of Style principles.
        parameters:
          text:
            type: str
            required: true
            description: The text to revise.
        returns:
          type: str
          description: The revised text.
        raises:
          - ValueError: if text is empty.
          - RuntimeError: if the Orchestrator is not initialized.
        logging:
          info:
            - Invocation with input length
            - Completion with output length and elapsed time
          debug:
            - Prompt length and model role
        related:
          - core.ai.prompts.elements_of_style.ELEMENTS_OF_STYLE
          - webapp.app.api_elements_of_style
        ---

        Post-process text through the LLM with Elements of Style instructions.
        Produces vigorous, clear prose by omitting needless words, preferring
        active voice, and applying other Strunk & White principles.
        Uses the formatter LLM with no tools or memory.
        """
        if not text or not text.strip():
            self.logger.warning("apply_elements_of_style called with empty text")
            raise ValueError("Cannot revise empty text.")

        from core.ai.prompts import PromptPartials

        prompt = (
            "You are an expert copyeditor who applies the principles of "
            "Strunk & White's Elements of Style to produce vigorous, clear prose.\n\n"
            f"{PromptPartials.ELEMENTS_OF_STYLE}\n\n"
            f"Text to revise:\n\n{text}"
        )

        self.logger.info(
            "Applying Elements of Style (input_len=%d, user_id=%s, org_id=%s)",
            len(text), self.user_id, self.org_id,
        )
        self.logger.debug(
            "elements_of_style prompt_len=%d, model_role=formatting", len(prompt),
        )

        _t0 = time.perf_counter()
        try:
            result = self.run_task(
                prompt,
                use_memory=False,
                allow_tools=False,
                model_role="formatting",
                cancel_token=cancel_token,
            )
        except Exception:
            elapsed = time.perf_counter() - _t0
            self.logger.exception(
                "Elements of Style revision failed after %.3f s (input_len=%d)",
                elapsed, len(text),
            )
            raise

        reply = result[0] if isinstance(result, tuple) else result
        elapsed = time.perf_counter() - _t0
        self.logger.info(
            "Elements of Style revision complete (output_len=%d, elapsed=%.3f s)",
            len(str(reply)), elapsed,
        )
        return reply


if __name__ == "__main__":
    # Initialize required components
    # Create a QAssistant instance
    assistant = QAssistant(user_id="123", org_id="test_org")

    # Test with a simple question
    question = "Who wrote the book 'Core Security Patterns'?"
    response = assistant.answer_question(question)

    # Verify response
    print(f"Response: {response}")
