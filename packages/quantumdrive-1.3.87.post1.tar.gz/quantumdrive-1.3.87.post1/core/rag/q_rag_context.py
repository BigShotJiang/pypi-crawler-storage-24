"""
QuantumDrive RAG context service.

Builds a provider-agnostic context block using QVectorStoreService.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Dict, List, Optional

from agentfoundry.utils.agent_config import AgentConfig

from core.utils.qd_config import QDConfig
from core.vectorstore.q_vectorstore_service import (
    QVectorStoreService,
    VectorStoreQueryResult,
    get_q_vectorstore_service,
)

logger = logging.getLogger(__name__)


@dataclass
class RAGContextChunk:
    doc_id: Optional[str]
    source: Optional[str]
    snippet: str
    metadata: Dict
    score: float


class QRAGContextService:
    """Builds a system message containing RAG context blocks."""

    def __init__(self, vs: QVectorStoreService) -> None:
        self._vs = vs

    def get_context(
        self,
        query: str,
        *,
        org_id: Optional[str] = None,
        filters: Optional[dict] = None,
        k: int = 6,
        max_chars: int = 4000,
    ) -> str:
        """Return a formatted context string for the assistant.

        Format:
            KNOWLEDGE BASE CONTEXT:
            - [score] source: ...
              snippet: ...
        """
        logger.debug("QRAGContextService.get_context: q=%r org_id=%s k=%d", query, org_id, k)
        results: List[VectorStoreQueryResult] = self._vs.similarity_search_with_score(
            query,
            k=k,
            filter=filters,
            org_id=org_id,
        )

        chunks: List[RAGContextChunk] = []
        for res in results:
            doc = res.doc
            metadata = getattr(doc, "metadata", {}) or {}
            chunk = RAGContextChunk(
                doc_id=getattr(doc, "id", None),
                source=metadata.get("source") or metadata.get("filename") or metadata.get("doc_type"),
                snippet=(doc.page_content or "").strip(),
                metadata=metadata,
                score=res.score,
            )
            chunks.append(chunk)

        if not chunks:
            return ""

        # Build context message
        lines: List[str] = ["KNOWLEDGE BASE CONTEXT:"]
        for c in chunks:
            snippet = c.snippet
            if len(snippet) > 800:
                snippet = snippet[:800] + "..."
            lines.append(f"- score={c.score:.4f} source={c.source or 'unknown'} id={c.doc_id or 'n/a'}")
            lines.append(f"  snippet: {snippet}")

        text = "\n".join(lines)
        if len(text) > max_chars:
            text = text[:max_chars] + "..."
        return text


_rag_singleton: Optional[QRAGContextService] = None


def get_q_rag_context_service() -> QRAGContextService:
    """Return a cached QRAGContextService instance based on QD/AF config."""
    global _rag_singleton
    if _rag_singleton is None:
        qd_cfg = QDConfig.from_legacy_config()
        af_cfg = AgentConfig.from_dict(qd_cfg.get_af_config_dict())
        vs = get_q_vectorstore_service(af_cfg)
        _rag_singleton = QRAGContextService(vs)
    return _rag_singleton
