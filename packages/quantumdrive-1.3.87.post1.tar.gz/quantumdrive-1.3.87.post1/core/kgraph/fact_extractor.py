"""
Lightweight fact extractor for proposal workflows.

This is intentionally conservative and should be paired with human review.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional


@dataclass
class ExtractedFact:
    subject: str
    predicate: str
    obj: str
    metadata: Dict[str, str]


class FactExtractor:
    """Heuristic extractor for common proposal facts."""

    _NAICS_RE = re.compile(r"\b(\d{6})\b")
    _CURRENCY_RE = re.compile(r"\$\s?\d{1,3}(?:,\d{3})*(?:\.\d+)?(?:\s?[MBK])?", re.IGNORECASE)
    _SOLICITATION_ID_RE = re.compile(r"\b(RFP|RFI|RFQ|IFB)\s*#?\s*([A-Z0-9\-_/]+)\b", re.IGNORECASE)
    _DATE_RE = re.compile(
        r"\b(?:\d{1,2}[/-]\d{1,2}[/-]\d{2,4}|(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+\d{1,2},\s*\d{4})\b",
        re.IGNORECASE,
    )
    _CERT_RE = re.compile(r"\b(ISO\s?9001|ISO\s?27001|SOC\s?2|CMMI\s?\d)\b", re.IGNORECASE)

    def extract(self, text: str, *, metadata: Optional[Dict[str, str]] = None) -> List[ExtractedFact]:
        meta = dict(metadata or {})
        subject = self._derive_subject(meta)
        facts: List[ExtractedFact] = []

        for naics in self._unique(self._NAICS_RE.findall(text)):
            facts.append(self._fact(subject, "has_naics", naics, meta))

        for value in self._unique(self._CURRENCY_RE.findall(text)):
            predicate = "contract_value"
            if meta.get("entity_type") == "past_performance":
                predicate = "past_performance_value"
            facts.append(self._fact(subject, predicate, value.strip(), meta))

        for match in self._SOLICITATION_ID_RE.findall(text):
            sol_type, sol_id = match
            facts.append(self._fact(subject, "solicitation_id", f"{sol_type.upper()} {sol_id}", meta))

        for date_str in self._unique(self._DATE_RE.findall(text)):
            facts.append(self._fact(subject, "mentions_date", date_str, meta))

        for cert in self._unique(self._CERT_RE.findall(text)):
            facts.append(self._fact(subject, "has_certification", cert.upper(), meta))

        return facts

    @staticmethod
    def _derive_subject(meta: Dict[str, str]) -> str:
        for key in ("entity_name", "title", "solicitation_id", "response_id", "filename"):
            value = meta.get(key)
            if value:
                return value
        return "document"

    @staticmethod
    def _fact(subject: str, predicate: str, obj: str, meta: Dict[str, str]) -> ExtractedFact:
        fact_meta = dict(meta)
        return ExtractedFact(subject=subject, predicate=predicate, obj=obj, metadata=fact_meta)

    @staticmethod
    def _unique(values: Iterable[str]) -> List[str]:
        seen = set()
        result: List[str] = []
        for v in values:
            if v in seen:
                continue
            seen.add(v)
            result.append(v)
        return result
