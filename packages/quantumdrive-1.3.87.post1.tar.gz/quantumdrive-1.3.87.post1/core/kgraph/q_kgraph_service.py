"""
Provider-agnostic Knowledge Graph facade for QuantumDrive.

This module exposes generic methods so applications never depend on
provider-specific KGraph implementations.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

from agentfoundry.kgraph.factory import KGraphFactory
from agentfoundry.utils.agent_config import AgentConfig

logger = logging.getLogger(__name__)


@dataclass
class KGraphFact:
    subject: str
    predicate: str
    obj: str
    metadata: Dict[str, Any]


class QKGraphService:
    """Facade over AgentFoundry KGraph provider."""

    def __init__(self, config: AgentConfig, *, data_dir: Optional[str] = None, backend: Optional[str] = None) -> None:
        self._config = config
        self._data_dir = data_dir or (str(config.data_dir) if config.data_dir else None)
        self._backend = backend
        self._kgraph = self._init_kgraph()
        logger.info("QKGraphService initialized backend=%s data_dir=%s", self._backend or "default", self._data_dir)

    def _init_kgraph(self):
        override: Dict[str, Any] = {}
        if self._data_dir:
            override["DATA_DIR"] = self._data_dir
        if self._backend:
            override["KGRAPH.BACKEND"] = self._backend
        return KGraphFactory.get_instance().get_kgraph(config_override=override or None)

    def health_check(self) -> bool:
        """Best-effort connectivity check.

        Returns True if the provider can be instantiated.
        """
        try:
            _ = self._kgraph
            return True
        except Exception:
            logger.exception("KGraph health check failed")
            return False

    def upsert_fact(
        self,
        subject: str,
        predicate: str,
        obj: str,
        *,
        metadata: Optional[Dict[str, Any]] = None,
        org_id: Optional[str] = None,
        user_id: Optional[str] = None,
    ) -> str:
        """Insert or update a fact."""
        meta = dict(metadata or {})
        if org_id is not None:
            meta.setdefault("org_id", org_id)
        if user_id is not None:
            meta.setdefault("user_id", user_id)
        return self._kgraph.upsert_fact(subject, predicate, obj, meta)

    def search(
        self,
        query: str,
        *,
        org_id: str,
        user_id: str,
        k: int = 5,
    ) -> List[Dict[str, Any]]:
        """Search the knowledge graph by semantic query."""
        return self._kgraph.search(query, org_id=org_id, user_id=user_id, k=k)

    def fetch_by_metadata(self, *, org_id: str, filters: Dict[str, str]) -> List[Dict[str, Any]]:
        """Fetch facts by metadata filters."""
        return self._kgraph.fetch_by_metadata(org_id=org_id, filters=filters)

    def get_neighbours(self, entity: str, depth: int = 2) -> List[Dict[str, Any]]:
        """Traverse graph neighbours from an entity."""
        return self._kgraph.get_neighbours(entity, depth=depth)

    def delete_context(self, *, org_id: str, graph_slice_id: str) -> int:
        """Delete facts linked to a graph slice id."""
        return self._kgraph.delete_context(org_id=org_id, graph_slice_id=graph_slice_id)

    def purge_expired(self, days: int = 90) -> None:
        """Purge expired facts from the graph."""
        return self._kgraph.purge_expired(days=days)


_service_singleton: Optional[QKGraphService] = None


def get_q_kgraph_service(config: AgentConfig) -> QKGraphService:
    """Return a cached QKGraphService instance."""
    global _service_singleton
    if _service_singleton is None:
        _service_singleton = QKGraphService(config)
    return _service_singleton
