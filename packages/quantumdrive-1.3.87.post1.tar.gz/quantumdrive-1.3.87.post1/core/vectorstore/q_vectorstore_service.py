"""
Provider-agnostic VectorStore facade for QuantumDrive.

This module exposes generic methods so applications never depend on
provider-specific classes (e.g., Milvus). It delegates to AgentFoundry's
VectorStoreFactory, which selects the configured provider.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Iterable, List, Optional, Sequence

from langchain_core.documents import Document

from agentfoundry.utils.agent_config import AgentConfig
from agentfoundry.vectorstores.factory import VectorStoreFactory

logger = logging.getLogger(__name__)


@dataclass
class VectorStoreQueryResult:
    """Normalized search result for UI and RAG.

    Attributes:
        doc: LangChain Document
        score: float (lower is better for some stores; treat as relative)
    """

    doc: Document
    score: float


class QVectorStoreService:
    """Facade over AgentFoundry VectorStore provider.

    All methods are provider-agnostic and safe for app usage.
    """

    def __init__(self, config: AgentConfig) -> None:
        self._config = config
        self._provider = VectorStoreFactory.get_provider(config=config)
        logger.info("QVectorStoreService initialized with provider=%s", type(self._provider).__name__)

    @classmethod
    def from_config(cls, config: AgentConfig) -> "QVectorStoreService":
        return cls(config=config)

    def verify_connectivity(self, org_id: str = "global") -> None:
        """Verify vector store connectivity for an org."""
        self._provider.verify_connectivity(org_id=org_id)

    def add_texts(
        self,
        texts: Sequence[str],
        metadatas: Optional[Sequence[dict]] = None,
        ids: Optional[Sequence[str]] = None,
        *,
        org_id: Optional[str] = None,
        allow_update: bool = False,
    ) -> None:
        """Add raw texts to the vector store.

        Uses provider's add_documents under the hood for compatibility.
        """
        documents: List[Document] = []
        metadatas = metadatas or [{} for _ in texts]
        ids = ids or [None for _ in texts]
        for text, meta, doc_id in zip(texts, metadatas, ids):
            documents.append(Document(page_content=text, metadata=meta or {}, id=doc_id))
        logger.debug("QVectorStoreService.add_texts: count=%d org_id=%s", len(documents), org_id)
        self._provider.add_documents(documents, ids=ids, org_id=org_id, allow_update=allow_update)

    def add_documents(
        self,
        documents: Iterable[Document],
        ids: Optional[Sequence[str]] = None,
        *,
        org_id: Optional[str] = None,
        allow_update: bool = False,
    ) -> None:
        """Add LangChain Documents to the vector store."""
        docs_list = list(documents)
        logger.debug("QVectorStoreService.add_documents: count=%d org_id=%s", len(docs_list), org_id)
        self._provider.add_documents(docs_list, ids=ids, org_id=org_id, allow_update=allow_update)

    def similarity_search(
        self,
        query: str,
        k: int = 4,
        *,
        filter: Optional[dict] = None,
        org_id: Optional[str] = None,
        **kwargs,
    ) -> List[Document]:
        """Return top-k matching documents."""
        logger.debug("QVectorStoreService.similarity_search: q=%r k=%d org_id=%s", query, k, org_id)
        return self._provider.similarity_search(query, k=k, filter=filter, org_id=org_id, **kwargs)

    def similarity_search_with_score(
        self,
        query: str,
        k: int = 4,
        *,
        filter: Optional[dict] = None,
        org_id: Optional[str] = None,
        **kwargs,
    ) -> List[VectorStoreQueryResult]:
        """Return top-k matches with scores normalized to a common result type."""
        logger.debug("QVectorStoreService.similarity_search_with_score: q=%r k=%d org_id=%s", query, k, org_id)
        results = self._provider.similarity_search_with_score(query, k=k, filter=filter, org_id=org_id, **kwargs)
        normalized: List[VectorStoreQueryResult] = []
        for doc, score in results:
            normalized.append(VectorStoreQueryResult(doc=doc, score=float(score)))
        return normalized

    def delete(self, ids: Sequence[str], *, org_id: Optional[str] = None) -> None:
        """Delete documents by ID."""
        if not ids:
            return None
        logger.debug("QVectorStoreService.delete: ids=%d org_id=%s", len(ids), org_id)
        self._provider.delete(ids=ids, org_id=org_id)


_service_singleton: Optional[QVectorStoreService] = None


def get_q_vectorstore_service(config: AgentConfig) -> QVectorStoreService:
    """Return a cached QVectorStoreService instance."""
    global _service_singleton
    if _service_singleton is None:
        _service_singleton = QVectorStoreService.from_config(config)
    return _service_singleton
