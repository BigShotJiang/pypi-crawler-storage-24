# tests/test_ollama_llm.py
import re

import pytest
from langchain_ollama import ChatOllama

from agentfoundry.llm.ollama_llm import OllamaLLM


class DummyResponse:
    def __init__(self, content: str):
        self.content = content


@pytest.fixture
def patched_chat_ollama_invoke(monkeypatch):
    """Patch ChatOllama.invoke to avoid network calls in tests."""
    def _dummy_invoke(self, messages, **kwargs):
        text = str(messages)
        if "add_numbers" in text or "Write a Python function" in text:
            return DummyResponse("def add_numbers(a, b):\n    return a + b")
        return DummyResponse("Use num1 + num2")

    monkeypatch.setattr(ChatOllama, "invoke", _dummy_invoke, raising=True)


def test_generate(patched_chat_ollama_invoke):
    """Test OllamaLLM.invoke with a code generation prompt."""
    llm = OllamaLLM(model="dummy")
    prompt = "Write a Python function with NO markdown or comments, called add_numbers to add two numbers."
    output = llm.invoke([{"role": "user", "content": prompt}]).content

    # Remove Markdown code block formatting (```python ... ```)
    output = re.sub(r"```(?:python)?\n?", "", output)
    output = re.sub(r"\n?```$", "", output)

    compiled_code = compile(output, "<string>", "exec")
    exec(compiled_code, globals())

    assert "add_numbers" in globals()
    result = add_numbers(3, 5)
    assert result == 8


def test_chat(patched_chat_ollama_invoke):
    """Test OllamaLLM.chat with a simple prompt."""
    llm = OllamaLLM(model="dummy")
    messages = [
        "Hello, how can you help me?",
        "How do I add two numbers, called num1 and num2, in Python?",
    ]
    output = llm.chat(messages)
    assert "num1 + num2" in output.lower()
