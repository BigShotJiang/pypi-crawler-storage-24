from setuptools import setup, find_packages

setup(
    name="saaslic",
    version="0.1.0",
    description="SaaSlic Python SDK - Software license verification made simple",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="LicenseKit",
    author_email="hi@saaslic.com",
    url="https://saaslic.com",
    packages=find_packages(),
    install_requires=["requests>=2.20.0"],
    python_requires=">=3.7",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Software Development :: Libraries",
    ],
    keywords="license activation software protection drm",
)
