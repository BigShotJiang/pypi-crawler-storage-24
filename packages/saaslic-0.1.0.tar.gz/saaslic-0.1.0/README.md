# SaaSlic Python SDK

软件授权验证 SDK，3 行代码接入 [LicenseKit](https://saaslic.com)。

## 安装

pip install saaslic

## 快速开始

from saaslic import LicenseKit

lk = LicenseKit("YOUR_PROJECT_CODE")
result = lk.verify("LIC-XXXXXXXX-XXXX")

if result["ok"]:
    print("验证成功！")
else:
    print("验证失败：", result["message"])

## 简洁写法

if lk.check("LIC-XXXXXXXX-XXXX"):
    print("授权有效，启动软件")
else:
    print("授权无效，退出")

## 文档

完整文档：https://saaslic.com/docs
