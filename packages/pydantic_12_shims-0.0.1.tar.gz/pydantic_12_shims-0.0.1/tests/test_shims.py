import pytest
from typing import List, Optional


def test_basic_model(pydantic_module):
    """Test basic BaseModel functionality"""

    class User(pydantic_module.BaseModel):
        name: str
        age: int

    user = User(name="John", age=30)
    assert user.name == "John"
    assert user.age == 30


def test_model_config_dict(pydantic_module):
    """Test ConfigDict usage"""

    class User(pydantic_module.BaseModel):
        model_config = pydantic_module.ConfigDict(frozen=True)

        name: str
        age: int

    user = User(name="John", age=30)
    with pytest.raises((pydantic_module.ValidationError, ValueError, TypeError)):
        user.name = "Jane"  # Should fail because model is frozen


def test_model_config_from_attributes(pydantic_module):
    """Test from_attributes config option"""

    class User(pydantic_module.BaseModel):
        model_config = pydantic_module.ConfigDict(from_attributes=True)

        name: str
        age: int

    class MockObject:
        def __init__(self):
            self.name = "John"
            self.age = 30

    obj = MockObject()
    user = User.model_validate(obj)
    assert user.name == "John"
    assert user.age == 30

    user2 = User.model_validate({"name": "Jane", "age": 25})
    assert user2.name == "Jane"
    assert user2.age == 25


def test_field_validator_before(pydantic_module):
    """Test field_validator with mode='before'"""

    class User(pydantic_module.BaseModel):
        name: str
        age: int

        @pydantic_module.field_validator("name", mode="before")
        @classmethod
        def validate_name(cls, v):
            if isinstance(v, str):
                return v.strip().title()
            return v

    user = User(name="  john  ", age=30)
    assert user.name == "John"


def test_field_validator_after(pydantic_module):
    """Test field_validator with mode='after'"""

    class User(pydantic_module.BaseModel):
        name: str
        age: int

        @pydantic_module.field_validator("age", mode="after")
        @classmethod
        def validate_age(cls, v):
            if v < 0:
                raise ValueError("Age must be non-negative")
            return v

    user = User(name="John", age=30)
    assert user.age == 30

    with pytest.raises(pydantic_module.ValidationError):
        User(name="John", age=-5)


def test_field_validator_multiple_fields(pydantic_module):
    """Test field_validator on multiple fields"""

    class User(pydantic_module.BaseModel):
        first_name: str
        last_name: str
        age: int

        @pydantic_module.field_validator("first_name", "last_name", mode="before")
        @classmethod
        def validate_names(cls, v):
            if isinstance(v, str):
                return v.strip().title()
            return v

    user = User(first_name="  john  ", last_name="  doe  ", age=30)
    assert user.first_name == "John"
    assert user.last_name == "Doe"


def test_model_validator_before(pydantic_module):
    """Test model_validator with mode='before'"""

    class User(pydantic_module.BaseModel):
        name: str
        age: int

        @pydantic_module.model_validator(mode="before")
        @classmethod
        def validate_model(cls, values):
            if isinstance(values, dict) and "full_name" in values:
                # Split full_name into name if provided
                full_name = values.pop("full_name")
                if "name" not in values:
                    values["name"] = full_name
            return values

    user = User(full_name="John Doe", age=30)
    assert user.name == "John Doe"
    assert user.age == 30


def test_model_validator_after(pydantic_module):
    """Test model_validator with mode='after'"""

    class User(pydantic_module.BaseModel):
        name: str
        age: int

        @pydantic_module.model_validator(mode="after")
        def validate_model_after(self):
            if self.age < 18 and "adult" in self.name.lower():
                raise ValueError("Cannot be adult if under 18")
            return self

    user = User(name="John", age=30)
    assert user.name == "John"

    with pytest.raises(pydantic_module.ValidationError):
        User(name="Adult John", age=16)


def test_model_validator_after_invalid_referenced_field(pydantic_module):
    class User(pydantic_module.BaseModel):
        name: str
        age: int

    class Course(pydantic_module.BaseModel):
        school: str
        students: List[User]

        @pydantic_module.model_validator(mode="after")
        def validate_eligibility(self):
            if self.school == "Upstate U":
                if any(student.age < 18 for student in self.students):
                    raise ValueError("All students must be at least 18 years old for Upstate U")

    with pytest.raises(pydantic_module.ValidationError):
        Course(
            school="Upstate U",
            students=[
                {"name": "Alice"},
            ],
        )


def test_model_construct(pydantic_module):
    """Test model_construct method"""

    class User(pydantic_module.BaseModel):
        name: str
        age: int

    user = User.model_construct(name="John", age=30)
    assert user.name == "John"
    assert user.age == 30


def test_model_copy(pydantic_module):
    """Test model_copy method"""

    class User(pydantic_module.BaseModel):
        name: str
        age: int

    user = User(name="John", age=30)
    user_copy = user.model_copy()
    assert user_copy.name == "John"
    assert user_copy.age == 30
    assert user_copy is not user

    # Test with updates
    user_copy_updated = user.model_copy(update={"age": 31})
    assert user_copy_updated.age == 31
    assert user_copy_updated.name == "John"


def test_model_dump(pydantic_module):
    """Test model_dump method"""

    class User(pydantic_module.BaseModel):
        name: str
        age: int

    user = User(name="John", age=30)
    data = user.model_dump()
    assert data == {"name": "John", "age": 30}


def test_model_dump_json(pydantic_module):
    """Test model_dump_json method"""

    class User(pydantic_module.BaseModel):
        name: str
        age: int

    user = User(name="John", age=30)
    json_str = user.model_dump_json()
    assert isinstance(json_str, (str, bytes))
    # Should contain the data in JSON format
    assert "John" in json_str
    assert "30" in json_str


def test_model_validate(pydantic_module):
    """Test model_validate method"""

    class User(pydantic_module.BaseModel):
        name: str
        age: int

    data = {"name": "John", "age": 30}
    user = User.model_validate(data)
    assert user.name == "John"
    assert user.age == 30


def test_model_json_schema(pydantic_module):
    """Test model_json_schema method"""

    class User(pydantic_module.BaseModel):
        name: str
        age: int

    schema = User.model_json_schema()
    assert isinstance(schema, dict)
    assert "properties" in schema
    assert "name" in schema["properties"]
    assert "age" in schema["properties"]


def test_model_fields(pydantic_module):
    """Test model_fields property"""

    class User(pydantic_module.BaseModel):
        name: str
        age: int

    fields = User.model_fields
    assert isinstance(fields, dict)
    assert "name" in fields
    assert "age" in fields


def test_model_rebuild(pydantic_module):
    """Test model_rebuild method"""

    class User(pydantic_module.BaseModel):
        name: str
        age: int

    # This should not raise an error
    User.model_rebuild()


def test_config_dict_populate_by_name(pydantic_module):
    """Test ConfigDict populate_by_name option"""

    class User(pydantic_module.BaseModel):
        model_config = pydantic_module.ConfigDict(populate_by_name=True)

        user_name: str
        age: int

    # Should work with both field name and alias
    user1 = User(user_name="John", age=30)
    assert user1.user_name == "John"


def test_nested_models(pydantic_module):
    """Test nested BaseModel usage"""

    class Address(pydantic_module.BaseModel):
        street: str
        city: str

    class User(pydantic_module.BaseModel):
        name: str
        address: Address

    user = User(name="John", address={"street": "123 Main St", "city": "Anytown"})
    assert user.name == "John"
    assert user.address.street == "123 Main St"
    assert user.address.city == "Anytown"


def test_optional_fields(pydantic_module):
    """Test optional fields"""

    class User(pydantic_module.BaseModel):
        name: str
        age: Optional[int] = None

    user1 = User(name="John")
    assert user1.name == "John"
    assert user1.age is None

    user2 = User(name="Jane", age=25)
    assert user2.name == "Jane"
    assert user2.age == 25


def test_list_fields(pydantic_module):
    """Test list fields"""

    class User(pydantic_module.BaseModel):
        name: str
        tags: List[str] = []

    user = User(name="John", tags=["admin", "user"])
    assert user.name == "John"
    assert user.tags == ["admin", "user"]


def test_validation_errors(pydantic_module):
    """Test that validation errors are properly raised"""

    class User(pydantic_module.BaseModel):
        name: str
        age: int

    with pytest.raises(pydantic_module.ValidationError):
        User(name="John")  # Missing required field

    with pytest.raises(pydantic_module.ValidationError):
        User(name="John", age="not_a_number")  # Wrong type


def test_field_validator_invalid_mode(pydantic_module):
    """Test field_validator with invalid mode parameter"""

    with pytest.raises((ValueError, AssertionError, KeyError), match="(Invalid mode|invalid mode|invalid)"):

        class User(pydantic_module.BaseModel):
            name: str

            @pydantic_module.field_validator("name", mode="invalid")
            @classmethod
            def validate_name(cls, v):
                return v


def test_model_validator_invalid_mode(pydantic_module):
    """Test model_validator with invalid mode parameter"""

    with pytest.raises((ValueError, AssertionError), match="(Invalid mode|invalid mode)"):

        class User(pydantic_module.BaseModel):
            name: str

            @pydantic_module.model_validator(mode="invalid")
            @classmethod
            def validate_model(cls, values):
                return values


def test_config_dict_comprehensive_mapping(pydantic_module):
    """Test comprehensive ConfigDict option mapping"""

    class User(pydantic_module.BaseModel):
        model_config = pydantic_module.ConfigDict(
            populate_by_name=True,
            frozen=True,
            str_to_lower=True,
            str_strip_whitespace=True,
            str_to_upper=False,
            str_max_length=100,
            str_min_length=1,
            json_schema_extra={"example": "test"},
            validate_default=True,
        )

        name: str
        age: int = 25

    # Test that the model can be created (config is applied correctly)
    # Note: str_to_lower=True will convert the name to lowercase
    user = User(name="John", age=30)
    assert user.name == "john"  # Should be lowercase due to str_to_lower=True
    assert user.age == 30

    # Test frozen behavior
    with pytest.raises((pydantic_module.ValidationError, ValueError, TypeError)):
        user.name = "Jane"


def test_model_validate_orm_mode(pydantic_module):
    """Test model_validate with ORM-like objects"""

    class User(pydantic_module.BaseModel):
        model_config = pydantic_module.ConfigDict(from_attributes=True)

        name: str
        age: int

    class MockORMObject:
        def __init__(self, name, age):
            self.name = name
            self.age = age

    # Test with ORM-like object
    orm_obj = MockORMObject("John", 30)
    user = User.model_validate(orm_obj)
    assert user.name == "John"
    assert user.age == 30

    # Test with dictionary (should still work)
    user2 = User.model_validate({"name": "Jane", "age": 25})
    assert user2.name == "Jane"
    assert user2.age == 25


def test_model_fields_property(pydantic_module):
    """Test model_fields property returns correct field information"""

    class User(pydantic_module.BaseModel):
        name: str
        age: int
        email: Optional[str] = None

    fields = User.model_fields
    assert isinstance(fields, dict)
    assert "name" in fields
    assert "age" in fields
    assert "email" in fields
    assert len(fields) == 3


def test_model_validator_after_with_validation_error(pydantic_module):
    """Test model_validator mode='after' that raises validation errors"""

    class User(pydantic_module.BaseModel):
        name: str
        age: int
        is_adult: bool = False

        @pydantic_module.model_validator(mode="after")
        def validate_adult_status(self):
            if self.age >= 18 and not self.is_adult:
                raise ValueError("Must be marked as adult if 18 or older")
            if self.age < 18 and self.is_adult:
                raise ValueError("Cannot be adult if under 18")
            return self

    # Valid cases
    user1 = User(name="John", age=20, is_adult=True)
    assert user1.is_adult is True

    user2 = User(name="Jane", age=16, is_adult=False)
    assert user2.is_adult is False

    # Invalid cases
    with pytest.raises(pydantic_module.ValidationError):
        User(name="John", age=20, is_adult=False)

    with pytest.raises(pydantic_module.ValidationError):
        User(name="Jane", age=16, is_adult=True)


def test_model_validator_after_modifies_instance(pydantic_module):
    """Test model_validator mode='after' that modifies the instance"""

    class User(pydantic_module.BaseModel):
        first_name: str
        last_name: str
        full_name: Optional[str] = None

        @pydantic_module.model_validator(mode="after")
        def set_full_name(self):
            if not self.full_name:
                self.full_name = f"{self.first_name} {self.last_name}"
            return self

    user = User(first_name="John", last_name="Doe")
    assert user.full_name == "John Doe"

    # Test when full_name is already provided
    user2 = User(first_name="Jane", last_name="Smith", full_name="Dr. Jane Smith")
    assert user2.full_name == "Dr. Jane Smith"


def test_config_dict_additional_options(pydantic_module):
    """Test additional ConfigDict options that get passed through"""

    class User(pydantic_module.BaseModel):
        model_config = pydantic_module.ConfigDict(
            validate_by_name=True,
            union_mode="smart",
            ignored_types=(str,),
            custom_option="test_value",  # Should be passed through
        )

        name: str
        age: int

    user = User(name="John", age=30)
    assert user.name == "John"
    assert user.age == 30


def test_model_construct_vs_regular_init(pydantic_module):
    """Test difference between model_construct and regular initialization"""

    class User(pydantic_module.BaseModel):
        name: str
        age: int

        @pydantic_module.field_validator("age", mode="after")
        @classmethod
        def validate_age(cls, v):
            if v < 0:
                raise ValueError("Age must be non-negative")
            return v

    # Regular init should run validation
    with pytest.raises(pydantic_module.ValidationError):
        User(name="John", age=-5)

    # model_construct should bypass validation
    user = User.model_construct(name="John", age=-5)
    assert user.name == "John"
    assert user.age == -5


def test_model_copy_with_deep_update(pydantic_module):
    """Test model_copy with nested updates"""

    class Address(pydantic_module.BaseModel):
        street: str
        city: str

    class User(pydantic_module.BaseModel):
        name: str
        age: int
        address: Address

    user = User(name="John", age=30, address={"street": "123 Main St", "city": "Anytown"})

    # Test basic copy
    user_copy = user.model_copy()
    assert user_copy.name == "John"
    assert user_copy.address.street == "123 Main St"
    assert user_copy is not user  # The main object should be different
    # Note: We don't test nested object identity as behavior varies between Pydantic versions

    # Test copy with updates
    user_updated = user.model_copy(update={"age": 31})
    assert user_updated.age == 31
    assert user_updated.name == "John"
    assert user_updated.address.street == "123 Main St"


def test_multiple_field_validators_same_field(pydantic_module):
    """Test multiple field validators on the same field"""

    class User(pydantic_module.BaseModel):
        name: str
        age: int

        @pydantic_module.field_validator("name", mode="before")
        @classmethod
        def strip_name(cls, v):
            if isinstance(v, str):
                return v.strip()
            return v

        @pydantic_module.field_validator("name", mode="after")
        @classmethod
        def title_name(cls, v):
            if isinstance(v, str):
                return v.title()
            return v

    user = User(name="  john doe  ", age=30)
    assert user.name == "John Doe"


def test_config_dict_construction(pydantic_module):
    """Test that ConfigDict construction works properly"""

    config = pydantic_module.ConfigDict(frozen=True, populate_by_name=True)
    assert config["frozen"] is True
    assert config["populate_by_name"] is True

    # Test that it's still a dict
    assert isinstance(config, dict)


def test_model_validate_edge_cases(pydantic_module):
    """Test model_validate with various edge cases"""

    class User(pydantic_module.BaseModel):
        model_config = pydantic_module.ConfigDict(from_attributes=True)
        name: str
        age: int

    # Test with None (should raise error)
    with pytest.raises((pydantic_module.ValidationError, TypeError, AttributeError)):
        User.model_validate(None)

    # Test with empty dict
    with pytest.raises(pydantic_module.ValidationError):
        User.model_validate({})

    # Test with object that has some but not all attributes
    class PartialObject:
        def __init__(self):
            self.name = "John"
            # Missing age attribute

    with pytest.raises((pydantic_module.ValidationError, AttributeError)):
        User.model_validate(PartialObject())


def test_metaclass_behavior(pydantic_module):
    """Test that the custom metaclass works correctly"""

    # Test class creation with model_config
    class UserWithConfig(pydantic_module.BaseModel):
        model_config = pydantic_module.ConfigDict(frozen=True)
        name: str
        age: int

    # Test that the model works correctly (the main functionality)
    user = UserWithConfig(name="John", age=30)
    assert user.name == "John"
    assert user.age == 30

    # Test frozen behavior works
    with pytest.raises((pydantic_module.ValidationError, ValueError, TypeError)):
        user.name = "Jane"

    # Config class only exists in Pydantic 1 (when using the shim)
    if hasattr(UserWithConfig, "Config"):
        assert hasattr(UserWithConfig.Config, "allow_mutation")
        assert UserWithConfig.Config.allow_mutation is False

    # Test class creation without model_config
    class UserWithoutConfig(pydantic_module.BaseModel):
        name: str
        age: int

    # Should work normally
    user2 = UserWithoutConfig(name="John", age=30)
    assert user2.name == "John"


def test_complex_nested_validation(pydantic_module):
    """Test complex nested model validation scenarios"""

    class Address(pydantic_module.BaseModel):
        street: str
        city: str

        @pydantic_module.field_validator("street", mode="before")
        @classmethod
        def validate_street(cls, v):
            if isinstance(v, str):
                return v.strip().title()
            return v

    class User(pydantic_module.BaseModel):
        name: str
        addresses: List[Address]

        @pydantic_module.model_validator(mode="after")
        def validate_addresses(self):
            if len(self.addresses) == 0:
                raise ValueError("User must have at least one address")
            return self

    # Test valid case
    user = User(
        name="John",
        addresses=[{"street": "  123 main st  ", "city": "Anytown"}, {"street": "456 oak ave", "city": "Other City"}],
    )
    assert user.addresses[0].street == "123 Main St"
    assert len(user.addresses) == 2

    # Test validation error
    with pytest.raises(pydantic_module.ValidationError):
        User(name="John", addresses=[])


def test_model_rebuild_functionality(pydantic_module):
    """Test model_rebuild method"""

    class User(pydantic_module.BaseModel):
        name: str
        age: int

    # Should not raise an error
    result = User.model_rebuild()
    # The return value might be None or the class itself
    assert result is None or result is User

    # Model should still work after rebuild
    user = User(name="John", age=30)
    assert user.name == "John"


def test_field_validator_with_kwargs(pydantic_module):
    """Test field_validator with additional keyword arguments"""

    class User(pydantic_module.BaseModel):
        name: str
        age: int

        @pydantic_module.field_validator("age", mode="after")
        @classmethod
        def validate_age_range(cls, v):
            if not 0 <= v <= 150:
                raise ValueError("Age must be between 0 and 150")
            return v

    # Valid case
    user = User(name="John", age=30)
    assert user.age == 30

    # Invalid cases
    with pytest.raises(pydantic_module.ValidationError):
        User(name="John", age=-5)

    with pytest.raises(pydantic_module.ValidationError):
        User(name="John", age=200)


def test_model_validate_json(pydantic_module):
    """Test model_validate_json method"""

    class User(pydantic_module.BaseModel):
        name: str
        age: int

    json_str = '{"name": "John", "age": 30}'
    user = User.model_validate_json(json_str)
    assert user.name == "John"
    assert user.age == 30

    # Test with invalid JSON
    with pytest.raises((pydantic_module.ValidationError, ValueError)):
        User.model_validate_json('{"name": "John", "age": "not_a_number"}')


def test_model_dump_exclude_include(pydantic_module):
    """Test model_dump with exclude and include parameters"""

    class User(pydantic_module.BaseModel):
        name: str
        age: int
        email: str

    user = User(name="John", age=30, email="john@example.com")

    # Test exclude
    data_excluded = user.model_dump(exclude={"email"})
    assert data_excluded == {"name": "John", "age": 30}
    assert "email" not in data_excluded

    # Test include
    data_included = user.model_dump(include={"name", "age"})
    assert data_included == {"name": "John", "age": 30}
    assert "email" not in data_included


def test_model_dump_by_alias(pydantic_module):
    """Test model_dump with by_alias parameter"""

    class User(pydantic_module.BaseModel):
        user_name: str = pydantic_module.Field(alias="username")
        age: int

    user = User(username="john_doe", age=30)

    # Test dump by alias
    data_by_alias = user.model_dump(by_alias=True)
    assert "username" in data_by_alias
    assert data_by_alias["username"] == "john_doe"

    # Test dump by field name (default)
    data_by_field = user.model_dump(by_alias=False)
    assert "user_name" in data_by_field
    assert data_by_field["user_name"] == "john_doe"


def test_field_validator_check_fields(pydantic_module):
    """Test field_validator with check_fields parameter"""

    class User(pydantic_module.BaseModel):
        name: str
        age: int

        @pydantic_module.field_validator("name", mode="before", check_fields=False)
        @classmethod
        def validate_name(cls, v):
            if isinstance(v, str):
                return v.strip().title()
            return v

    user = User(name="  john  ", age=30)
    assert user.name == "John"


def test_model_validator_before_with_dict_modification(pydantic_module):
    """Test model_validator mode='before' that modifies the input dict"""

    class User(pydantic_module.BaseModel):
        name: str
        age: int
        is_adult: bool = False

        @pydantic_module.model_validator(mode="before")
        @classmethod
        def set_adult_status(cls, values):
            if isinstance(values, dict):
                if values.get("age", 0) >= 18:
                    values["is_adult"] = True
            return values

    user = User(name="John", age=25)
    assert user.is_adult is True

    user2 = User(name="Jane", age=16)
    assert user2.is_adult is False


def test_model_copy_deep(pydantic_module):
    """Test model_copy with deep parameter"""

    class Address(pydantic_module.BaseModel):
        street: str
        city: str

    class User(pydantic_module.BaseModel):
        name: str
        address: Address

    user = User(name="John", address={"street": "123 Main St", "city": "Anytown"})

    # Test deep copy (default behavior)
    user_copy = user.model_copy(deep=True)
    assert user_copy.name == "John"
    assert user_copy.address.street == "123 Main St"
    assert user_copy is not user

    # Test shallow copy
    user_shallow = user.model_copy(deep=False)
    assert user_shallow.name == "John"
    assert user_shallow.address.street == "123 Main St"
    assert user_shallow is not user


def test_model_dump_mode(pydantic_module):
    """Test model_dump with mode parameter"""

    class User(pydantic_module.BaseModel):
        name: str
        age: int

    user = User(name="John", age=30)

    # Test python mode (default)
    data_python = user.model_dump(mode="python")
    assert data_python == {"name": "John", "age": 30}

    # Test json mode
    data_json = user.model_dump(mode="json")
    assert data_json == {"name": "John", "age": 30}


def test_config_dict_extra(pydantic_module):
    """Test ConfigDict with extra parameter"""

    class UserForbid(pydantic_module.BaseModel):
        model_config = pydantic_module.ConfigDict(extra="forbid")
        name: str
        age: int

    # Should work with exact fields
    user = UserForbid(name="John", age=30)
    assert user.name == "John"

    # Should fail with extra fields
    with pytest.raises(pydantic_module.ValidationError):
        UserForbid(name="John", age=30, email="john@example.com")

    class UserAllow(pydantic_module.BaseModel):
        model_config = pydantic_module.ConfigDict(extra="allow")
        name: str
        age: int

    # Should work with extra fields
    user2 = UserAllow(name="John", age=30, email="john@example.com")
    assert user2.name == "John"
    assert user2.email == "john@example.com"


def test_config_dict_use_enum_values(pydantic_module):
    """Test ConfigDict with use_enum_values parameter"""
    from enum import Enum

    class Color(Enum):
        RED = "red"
        GREEN = "green"
        BLUE = "blue"

    class Item(pydantic_module.BaseModel):
        model_config = pydantic_module.ConfigDict(use_enum_values=True)
        name: str
        color: Color

    item = Item(name="Apple", color=Color.RED)
    data = item.model_dump()
    assert data["color"] == "red"  # Should be the enum value, not the enum itself


def test_model_validate_strings(pydantic_module):
    """Test model_validate_strings method"""

    class User(pydantic_module.BaseModel):
        name: str
        age: int

    # Test with string values that need conversion
    user = User.model_validate_strings({"name": "John", "age": "30"})
    assert user.name == "John"
    assert user.age == 30
    assert isinstance(user.age, int)


def test_field_serializer(pydantic_module):
    """Test field serialization behavior"""
    from datetime import datetime

    class User(pydantic_module.BaseModel):
        name: str
        created_at: datetime

    user = User(name="John", created_at=datetime(2023, 1, 1, 12, 0, 0))
    data = user.model_dump()

    # Should serialize datetime properly
    assert data["name"] == "John"
    assert "created_at" in data


def test_computed_field_behavior(pydantic_module):
    """Test that computed fields work as expected"""

    class User(pydantic_module.BaseModel):
        first_name: str
        last_name: str

        @property
        def full_name(self) -> str:
            return f"{self.first_name} {self.last_name}"

    user = User(first_name="John", last_name="Doe")
    assert user.full_name == "John Doe"

    # Computed fields should not appear in model_dump by default
    data = user.model_dump()
    assert "full_name" not in data
    assert data == {"first_name": "John", "last_name": "Doe"}


def test_field_basic_usage(pydantic_module):
    """Test basic Field usage"""

    class User(pydantic_module.BaseModel):
        name: str = pydantic_module.Field(description="User's name")
        age: int = pydantic_module.Field(gt=0, description="User's age")

    user = User(name="John", age=30)
    assert user.name == "John"
    assert user.age == 30

    # Test validation
    with pytest.raises(pydantic_module.ValidationError):
        User(name="John", age=-5)


def test_field_min_max_length_remapping(pydantic_module):
    """Test Field min_length/max_length remapping to min_items/max_items"""

    class User(pydantic_module.BaseModel):
        tags: List[str] = pydantic_module.Field(min_length=1, max_length=5)
        name: str = pydantic_module.Field(min_length=2, max_length=50)

    # Valid cases
    user = User(tags=["admin"], name="John")
    assert user.tags == ["admin"]
    assert user.name == "John"

    user2 = User(tags=["admin", "user", "moderator"], name="Jane Doe")
    assert len(user2.tags) == 3

    # Test min_length validation for lists
    with pytest.raises(pydantic_module.ValidationError):
        User(tags=[], name="John")

    # Test max_length validation for lists
    with pytest.raises(pydantic_module.ValidationError):
        User(tags=["a", "b", "c", "d", "e", "f"], name="John")

    # Test min_length validation for strings
    with pytest.raises(pydantic_module.ValidationError):
        User(tags=["admin"], name="J")

    # Test max_length validation for strings
    with pytest.raises(pydantic_module.ValidationError):
        User(tags=["admin"], name="J" * 51)


def test_field_pattern_remapping(pydantic_module):
    """Test Field pattern remapping to regex"""

    class User(pydantic_module.BaseModel):
        email: str = pydantic_module.Field(pattern=r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$")

    # Valid email
    user = User(email="john@example.com")
    assert user.email == "john@example.com"

    # Invalid email
    with pytest.raises(pydantic_module.ValidationError):
        User(email="invalid-email")


def test_field_json_schema_extra(pydantic_module):
    """Test Field json_schema_extra parameter"""

    class User(pydantic_module.BaseModel):
        name: str = pydantic_module.Field(json_schema_extra={"example": "John Doe", "format": "name"})
        age: int = pydantic_module.Field(json_schema_extra={"example": 30, "minimum": 0})

    user = User(name="John", age=30)
    assert user.name == "John"
    assert user.age == 30

    # Test that schema generation works (the extra data should be included)
    schema = User.model_json_schema()
    assert isinstance(schema, dict)
    assert "properties" in schema


def test_field_alias_behavior(pydantic_module):
    """Test Field alias behavior"""

    class User(pydantic_module.BaseModel):
        user_name: str = pydantic_module.Field(alias="username")
        age: int

    # Should work with alias
    user = User(username="john_doe", age=30)
    assert user.user_name == "john_doe"
    assert user.age == 30

    # Test model_dump with alias
    data_by_alias = user.model_dump(by_alias=True)
    assert "username" in data_by_alias
    assert data_by_alias["username"] == "john_doe"

    data_by_field = user.model_dump(by_alias=False)
    assert "user_name" in data_by_field
    assert data_by_field["user_name"] == "john_doe"


def test_field_default_values(pydantic_module):
    """Test Field with default values"""

    class User(pydantic_module.BaseModel):
        name: str
        age: int = pydantic_module.Field(default=25, description="Default age")
        is_active: bool = pydantic_module.Field(default=True)

    # With all fields
    user1 = User(name="John", age=30, is_active=False)
    assert user1.name == "John"
    assert user1.age == 30
    assert user1.is_active is False

    # With defaults
    user2 = User(name="Jane")
    assert user2.name == "Jane"
    assert user2.age == 25
    assert user2.is_active is True


def test_field_validation_constraints(pydantic_module):
    """Test Field with various validation constraints"""

    class Product(pydantic_module.BaseModel):
        name: str = pydantic_module.Field(min_length=1, max_length=100)
        price: float = pydantic_module.Field(gt=0, le=10000)
        quantity: int = pydantic_module.Field(ge=0)
        tags: List[str] = pydantic_module.Field(min_length=0, max_length=10)

    # Valid product
    product = Product(name="Widget", price=19.99, quantity=50, tags=["electronics", "gadget"])
    assert product.name == "Widget"
    assert product.price == 19.99
    assert product.quantity == 50
    assert product.tags == ["electronics", "gadget"]

    # Test price validation
    with pytest.raises(pydantic_module.ValidationError):
        Product(name="Widget", price=0, quantity=50, tags=[])

    with pytest.raises(pydantic_module.ValidationError):
        Product(name="Widget", price=10001, quantity=50, tags=[])

    # Test quantity validation
    with pytest.raises(pydantic_module.ValidationError):
        Product(name="Widget", price=19.99, quantity=-1, tags=[])

    # Test tags length validation
    with pytest.raises(pydantic_module.ValidationError):
        Product(name="Widget", price=19.99, quantity=50, tags=["tag"] * 11)


def test_field_with_complex_types(pydantic_module):
    """Test Field with complex type annotations"""

    class Address(pydantic_module.BaseModel):
        street: str
        city: str

    class User(pydantic_module.BaseModel):
        name: str = pydantic_module.Field(description="Full name")
        addresses: List[Address] = pydantic_module.Field(min_length=1, description="User addresses")
        metadata: Optional[dict] = pydantic_module.Field(default=None, description="Additional data")

    # Valid user
    user = User(name="John Doe", addresses=[{"street": "123 Main St", "city": "Anytown"}], metadata={"role": "admin"})
    assert user.name == "John Doe"
    assert len(user.addresses) == 1
    assert user.addresses[0].street == "123 Main St"
    assert user.metadata == {"role": "admin"}

    # Test with defaults
    user2 = User(name="Jane Doe", addresses=[{"street": "456 Oak Ave", "city": "Other City"}])
    assert user2.metadata is None

    # Test min_length validation for addresses
    with pytest.raises(pydantic_module.ValidationError):
        User(name="John", addresses=[])


def test_field_multiple_constraints(pydantic_module):
    """Test Field with multiple constraints combined"""

    class User(pydantic_module.BaseModel):
        username: str = pydantic_module.Field(
            min_length=3,
            max_length=20,
            pattern=r"^[a-zA-Z0-9_]+$",
            description="Username with alphanumeric characters and underscores",
        )
        email: str = pydantic_module.Field(
            pattern=r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$", description="Valid email address"
        )
        age: int = pydantic_module.Field(ge=13, le=120, description="Age between 13 and 120")

    # Valid user
    user = User(username="john_doe", email="john@example.com", age=25)
    assert user.username == "john_doe"
    assert user.email == "john@example.com"
    assert user.age == 25

    # Test username pattern validation
    with pytest.raises(pydantic_module.ValidationError):
        User(username="john-doe", email="john@example.com", age=25)

    # Test username length validation
    with pytest.raises(pydantic_module.ValidationError):
        User(username="jo", email="john@example.com", age=25)

    with pytest.raises(pydantic_module.ValidationError):
        User(username="j" * 21, email="john@example.com", age=25)

    # Test email pattern validation
    with pytest.raises(pydantic_module.ValidationError):
        User(username="john_doe", email="invalid-email", age=25)

    # Test age range validation
    with pytest.raises(pydantic_module.ValidationError):
        User(username="john_doe", email="john@example.com", age=12)

    with pytest.raises(pydantic_module.ValidationError):
        User(username="john_doe", email="john@example.com", age=121)


def test_field_with_json_schema_extra_dict(pydantic_module):
    """Test Field json_schema_extra with dictionary"""

    class User(pydantic_module.BaseModel):
        name: str = pydantic_module.Field(
            json_schema_extra={"example": "John Doe", "format": "full-name", "custom_property": "test_value"}
        )
        age: int = pydantic_module.Field(json_schema_extra={"example": 30, "minimum": 0, "maximum": 150})

    user = User(name="John", age=30)
    assert user.name == "John"
    assert user.age == 30

    # Verify schema generation works
    schema = User.model_json_schema()
    assert isinstance(schema, dict)
    assert "properties" in schema
    assert "name" in schema["properties"]
    assert "age" in schema["properties"]


def test_field_backwards_compatibility(pydantic_module):
    """Test that Field works with existing Pydantic patterns"""

    class User(pydantic_module.BaseModel):
        # Mix of old and new style Field usage
        name: str = pydantic_module.Field(..., description="Required name")
        age: int = pydantic_module.Field(default=25, gt=0, description="Age with default")
        tags: List[str] = pydantic_module.Field(default_factory=list, min_length=0, max_length=5)
        is_active: bool = pydantic_module.Field(True, description="Active status")

    # Test with minimal data
    user1 = User(name="John")
    assert user1.name == "John"
    assert user1.age == 25
    assert user1.tags == []
    assert user1.is_active is True

    # Test with full data
    user2 = User(name="Jane", age=30, tags=["admin", "user"], is_active=False)
    assert user2.name == "Jane"
    assert user2.age == 30
    assert user2.tags == ["admin", "user"]
    assert user2.is_active is False

    # Test validation still works
    with pytest.raises(pydantic_module.ValidationError):
        User(name="John", age=-5)

    with pytest.raises(pydantic_module.ValidationError):
        User(name="John", tags=["a", "b", "c", "d", "e", "f"])


def test_field_optional_string_min_length(pydantic_module):
    """Test Field min_length with Optional[str]"""

    class User(pydantic_module.BaseModel):
        name: str
        nickname: Optional[str] = pydantic_module.Field(default=None, min_length=2)
        bio: Optional[str] = pydantic_module.Field(default="", min_length=1, max_length=100)

    # Test with None (should be allowed)
    user1 = User(name="John", nickname=None)
    assert user1.name == "John"
    assert user1.nickname is None
    assert user1.bio == ""

    # Test with valid optional string
    user2 = User(name="Jane", nickname="JD", bio="Software developer")
    assert user2.nickname == "JD"
    assert user2.bio == "Software developer"

    # Test min_length validation on optional string when provided
    with pytest.raises(pydantic_module.ValidationError):
        User(name="John", nickname="J")  # Too short

    # Test max_length validation on optional string
    with pytest.raises(pydantic_module.ValidationError):
        User(name="John", bio="x" * 101)  # Too long

    # Test empty string with min_length (should fail if min_length > 0)
    with pytest.raises(pydantic_module.ValidationError):
        User(name="John", bio="")  # Empty string but min_length=1


def test_field_optional_list_min_length(pydantic_module):
    """Test Field min_length with Optional[List[str]]"""

    class User(pydantic_module.BaseModel):
        name: str
        tags: Optional[List[str]] = pydantic_module.Field(default=None, min_length=1, max_length=5)
        skills: Optional[List[str]] = pydantic_module.Field(default_factory=list, min_length=0, max_length=3)

    # Test with None (should be allowed)
    user1 = User(name="John", tags=None)
    assert user1.name == "John"
    assert user1.tags is None
    assert user1.skills == []

    # Test with valid optional list
    user2 = User(name="Jane", tags=["admin", "user"], skills=["python", "javascript"])
    assert user2.tags == ["admin", "user"]
    assert user2.skills == ["python", "javascript"]

    # Test min_length validation on optional list when provided
    with pytest.raises(pydantic_module.ValidationError):
        User(name="John", tags=[])  # Empty list but min_length=1

    # Test max_length validation on optional list
    with pytest.raises(pydantic_module.ValidationError):
        User(name="John", tags=["a", "b", "c", "d", "e", "f"])  # Too many items

    with pytest.raises(pydantic_module.ValidationError):
        User(name="John", skills=["python", "javascript", "go", "rust"])  # Too many skills


def test_field_nested_optional_types(pydantic_module):
    """Test Field with more complex Optional type combinations"""

    class Address(pydantic_module.BaseModel):
        street: str
        city: str

    class User(pydantic_module.BaseModel):
        name: str
        addresses: Optional[List[Address]] = pydantic_module.Field(default=None, min_length=1, max_length=3)
        tags: Optional[List[str]] = pydantic_module.Field(default=None, min_length=2)
        description: Optional[str] = pydantic_module.Field(default=None, min_length=5, max_length=200)

    # Test with all None values
    user1 = User(name="John")
    assert user1.name == "John"
    assert user1.addresses is None
    assert user1.tags is None
    assert user1.description is None

    # Test with valid values
    user2 = User(
        name="Jane",
        addresses=[{"street": "123 Main St", "city": "Anytown"}],
        tags=["admin", "developer"],
        description="Experienced software developer",
    )
    assert len(user2.addresses) == 1
    assert user2.addresses[0].street == "123 Main St"
    assert user2.tags == ["admin", "developer"]
    assert user2.description == "Experienced software developer"

    # Test validation failures
    with pytest.raises(pydantic_module.ValidationError):
        User(name="John", addresses=[])  # Empty list but min_length=1

    with pytest.raises(pydantic_module.ValidationError):
        User(name="John", tags=["admin"])  # Only one tag but min_length=2

    with pytest.raises(pydantic_module.ValidationError):
        User(name="John", description="Hi")  # Too short description


def test_private_attr(pydantic_module):
    """Test PrivateAttr functionality"""

    class User(pydantic_module.BaseModel):
        name: str
        age: int
        _private_data: str = pydantic_module.PrivateAttr(default="secret")
        _counter: int = pydantic_module.PrivateAttr(default=0)
        _computed: Optional[str] = pydantic_module.PrivateAttr(default=None)

        def increment_counter(self):
            self._counter += 1

        def set_computed(self, value: str):
            self._computed = value

    # Test basic creation
    user = User(name="John", age=30)
    assert user.name == "John"
    assert user.age == 30
    assert user._private_data == "secret"
    assert user._counter == 0
    assert user._computed is None

    # Test private attribute access and modification
    user._private_data = "new_secret"
    assert user._private_data == "new_secret"

    user.increment_counter()
    assert user._counter == 1

    user.set_computed("computed_value")
    assert user._computed == "computed_value"

    # Test that private attributes don't appear in model_dump
    data = user.model_dump()
    assert data == {"name": "John", "age": 30}
    assert "_private_data" not in data
    assert "_counter" not in data
    assert "_computed" not in data

    # Test that private attributes don't appear in model_dump_json
    json_str = user.model_dump_json()
    assert "_private_data" not in json_str
    assert "_counter" not in json_str
    assert "_computed" not in json_str

    # Test model_copy preserves private attributes
    user_copy = user.model_copy()
    assert user_copy._private_data == "new_secret"
    assert user_copy._counter == 1
    assert user_copy._computed == "computed_value"
    assert user_copy is not user

    # Test that private attributes are not part of validation
    # (i.e., they can't be set during initialization)
    user2 = User(name="Jane", age=25)
    assert user2._private_data == "secret"  # Default value
    assert user2._counter == 0  # Default value


def test_private_attr_with_default_factory(pydantic_module):
    """Test PrivateAttr with default_factory"""

    class User(pydantic_module.BaseModel):
        name: str
        _created_at: str = pydantic_module.PrivateAttr(default_factory=lambda: "2023-01-01")
        _tags: List[str] = pydantic_module.PrivateAttr(default_factory=list)
        _metadata: dict = pydantic_module.PrivateAttr(default_factory=dict)

    user1 = User(name="John")
    assert user1._created_at == "2023-01-01"
    assert user1._tags == []
    assert user1._metadata == {}

    user2 = User(name="Jane")
    assert user2._created_at == "2023-01-01"
    assert user2._tags == []
    assert user2._metadata == {}

    # Test that default_factory creates separate instances
    user1._tags.append("admin")
    user1._metadata["role"] = "admin"

    assert user1._tags == ["admin"]
    assert user1._metadata == {"role": "admin"}
    assert user2._tags == []  # Should still be empty
    assert user2._metadata == {}  # Should still be empty

    # Test that private attributes don't appear in serialization
    data = user1.model_dump()
    assert data == {"name": "John"}


def test_private_attr_inheritance(pydantic_module):
    """Test PrivateAttr with model inheritance"""

    class BaseUser(pydantic_module.BaseModel):
        name: str
        _base_private: str = pydantic_module.PrivateAttr(default="base")

    class ExtendedUser(BaseUser):
        age: int
        _extended_private: int = pydantic_module.PrivateAttr(default=42)

    user = ExtendedUser(name="John", age=30)
    assert user.name == "John"
    assert user.age == 30
    assert user._base_private == "base"
    assert user._extended_private == 42

    # Test that both private attributes are preserved
    data = user.model_dump()
    assert data == {"name": "John", "age": 30}
    assert "_base_private" not in data
    assert "_extended_private" not in data

    # Test model_copy preserves both private attributes
    user_copy = user.model_copy()
    assert user_copy._base_private == "base"
    assert user_copy._extended_private == 42


def test_field_validator_reuse(pydantic_module):
    """
    Test that the same method can be reused as a field validator for multiple fields
    (disallowed by the llow_reuse=False default in Pydantic 1). Pydantic 2 allows
    re-using the same validator method
    """

    def validate_non_five(cls, v):
        if v == 5:
            raise ValueError("Value cannot be 5")
        return v

    class Model(pydantic_module.BaseModel):
        a: int
        b: int

        _validate_a = pydantic_module.field_validator("a", mode="before")(classmethod(validate_non_five))
        _validate_b = pydantic_module.field_validator("b", mode="before")(classmethod(validate_non_five))

    Model(a=3, b=4)  # Should work
    with pytest.raises(pydantic_module.ValidationError):
        Model(a=5, b=4)
    with pytest.raises(pydantic_module.ValidationError):
        Model(a=3, b=5)
