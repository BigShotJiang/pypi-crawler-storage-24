from typing import Generic, TypeVar

import pytest

T = TypeVar("T")


@pytest.fixture
def generic_model(pydantic_module):
    class MyGenericModel(pydantic_module.GenericModel, Generic[T]):
        value: T

    return MyGenericModel


def test_model_validation_scalar_int(pydantic_module, generic_model):
    model_class = generic_model[int]
    model_instance = model_class.model_validate({"value": "123"})
    assert model_instance.value == 123

    with pytest.raises(pydantic_module.ValidationError):
        model_class.model_validate({"value": "abc"})


def test_model_validation_list_of_ints(pydantic_module, generic_model):
    model_class = generic_model[list[int]]
    model_instance = model_class.model_validate({"value": ["1", 2, 3]})
    assert model_instance.value == [1, 2, 3]

    with pytest.raises(pydantic_module.ValidationError):
        model_class.model_validate({"value": ["1", "two", 3]})


def test_model_validation_scalar_pydantic_model(pydantic_module, generic_model):
    class InnerModel(pydantic_module.BaseModel):
        x: int

    model_class = generic_model[InnerModel]
    model_instance = model_class.model_validate({"value": {"x": "123"}})
    assert model_instance.value.x == 123

    with pytest.raises(pydantic_module.ValidationError):
        model_class.model_validate({"value": 1})


def test_model_validation_list_of_pydantic_models(pydantic_module, generic_model):
    class InnerModel(pydantic_module.BaseModel):
        x: int

    model_class = generic_model[list[InnerModel]]
    model_instance = model_class.model_validate({"value": [{"x": "1"}, {"x": 2}]})
    assert [m.x for m in model_instance.value] == [1, 2]

    with pytest.raises(pydantic_module.ValidationError):
        model_class.model_validate({"value": [{"x": "1"}, {"x": "two"}]})


def test_model_validation_nested_generics(pydantic_module, generic_model):
    InnerGenericModel = generic_model[int]
    model_class = generic_model[InnerGenericModel]
    model_instance = model_class.model_validate({"value": {"value": "123"}})
    assert model_instance.value.value == 123

    with pytest.raises(pydantic_module.ValidationError):
        model_class.model_validate({"value": {"value": "abc"}})


def test_model_dump(generic_model):
    model_class = generic_model[int]
    model_instance = model_class.model_validate({"value": "123"})
    assert model_instance.value == 123
    dumped_model = model_instance.model_dump()
    assert isinstance(dumped_model, dict)
    assert dumped_model["value"] == 123
