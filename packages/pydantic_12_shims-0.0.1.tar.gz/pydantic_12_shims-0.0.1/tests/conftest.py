import os
import importlib
import pytest

from pydantic_12_shims import PYDANTIC1


@pytest.fixture(autouse=True, params=["pydantic_12_shims", "pydantic_12_shims.v1", "pydantic_12_shims.v1:OFF"])
def pydantic_module(request, monkeypatch):
    import pydantic_12_shims
    import pydantic_12_shims.v1

    if PYDANTIC1:
        # Pydantic 1 maintained a global cache of validators
        # which is incompatible with defining a validator
        # inside a local function multiple times.
        # This means that anything which uses the parameterized fixture
        # could fail if we don't clear that cahce.
        # Fortunately, pydantic 2 does not have this issue.
        from pydantic.class_validators import _FUNCS

        _FUNCS.clear()
    if request.param == "pydantic_12_shims":
        yield pydantic_12_shims
    elif request.param == "pydantic_12_shims.v1":
        importlib.reload(pydantic_12_shims.v1)
        yield pydantic_12_shims.v1
    elif request.param == "pydantic_12_shims.v1:OFF":
        monkeypatch.setitem(os.environ, "TURN_PYDANTIC_V1_OFF", "true")
        importlib.reload(pydantic_12_shims.v1)
        yield pydantic_12_shims.v1
    else:
        assert False, f"Invalid pydantic module requested {request.param=}"
