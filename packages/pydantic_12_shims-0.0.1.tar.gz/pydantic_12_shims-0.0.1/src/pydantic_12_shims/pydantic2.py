from pydantic import BaseModel, field_validator, model_validator, ConfigDict, Field, ValidationError, PrivateAttr  # noqa: F401

GenericModel = BaseModel  # in pydantic v2 generics are supported by BaseModel out of the box
