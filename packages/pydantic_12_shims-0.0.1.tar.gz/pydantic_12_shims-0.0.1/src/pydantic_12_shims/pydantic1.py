import functools
import sys
import types
import typing
from unittest import mock
from typing import (
    TYPE_CHECKING,
    Any,
    ClassVar,
    Dict,
    ForwardRef,
    Generic,
    Iterator,
    List,
    Mapping,
    Optional,
    Tuple,
    Type,
    TypeVar,
    Union,
    cast,
)
from typing_extensions import Annotated, Literal as ExtLiteral
from weakref import WeakKeyDictionary, WeakValueDictionary

if sys.version_info >= (3, 10):
    from typing import _UnionGenericAlias
from typing import Literal

from pydantic import __version__ as pydantic_version

if pydantic_version.startswith("1."):
    from pydantic import (
        BaseModel as PydanticBaseModel,
        validator as pydantic_validator,
        root_validator as pydantic_root_validator,
        Field as PydanticField,
        ValidationError,
        PrivateAttr,
    )
    from pydantic.class_validators import gather_all_validators
    from pydantic.fields import DeferredType
    from pydantic.main import create_model
    from pydantic.types import JsonWrapper
    from pydantic.typing import display_as_type, get_all_type_hints, get_args, get_origin, typing_base
    from pydantic.utils import all_identical, lenient_issubclass
    import pydantic.schema as _pydantic_schema
else:
    from pydantic.v1 import (
        BaseModel as PydanticBaseModel,
        validator as pydantic_validator,
        root_validator as pydantic_root_validator,
        Field as PydanticField,
        ValidationError,
        PrivateAttr,
    )
    from pydantic.v1.class_validators import gather_all_validators
    from pydantic.v1.fields import DeferredType
    from pydantic.v1.main import create_model
    from pydantic.v1.types import JsonWrapper
    from pydantic.v1.typing import display_as_type, get_all_type_hints, get_args, get_origin, typing_base
    from pydantic.v1.utils import all_identical, lenient_issubclass
    import pydantic.v1.schema as _pydantic_schema


def construct_config_class_from_config_dict(config_dict):
    """
    See https://docs.pydantic.dev/latest/migration/#changes-to-config

    This takes in the pydantic v2 config dict names and constructs a v1-compatible Config class.

    This allows pydantic-2 style ConfigDict invocations to work using the shim BaseModel class
    below.
    """
    cls_dict = {}
    for key, value in config_dict.items():
        if key in ("populate_by_name", "validate_by_name"):
            cls_dict["allow_population_by_field_name"] = value
        elif key == "frozen":
            cls_dict["allow_mutation"] = not value
        elif key == "union_mode":
            cls_dict["smart_union"] = value == "smart"
        elif key == "str_to_lower":
            cls_dict["anystr_lower"] = value
        elif key == "str_strip_whitespace":
            cls_dict["anystr_strip_whitespace"] = value
        elif key == "str_to_upper":
            cls_dict["anystr_upper"] = value
        elif key == "ignored_types":
            cls_dict["keep_untouched"] = value
        elif key == "str_max_length":
            cls_dict["max_anystr_length"] = value
        elif key == "str_min_length":
            cls_dict["min_anystr_length"] = value
        elif key == "from_attributes":
            cls_dict["orm_mode"] = value
        elif key == "json_schema_extra":
            cls_dict["schema_extra"] = value
        elif key == "validate_default":
            cls_dict["validate_all"] = value
        else:
            # For any config options that don't need mapping, pass them through
            cls_dict[key] = value
    cls_dict = {**config_dict, **cls_dict}
    return type("Config", (), cls_dict)


orig_get_annotation_from_field_info = _pydantic_schema.get_annotation_from_field_info


def annotation_matches_type(annotation: Any, target, depth=0) -> bool:
    """
    Checks whether `annotation` includes the `target` type.

    Subtleties: list[whatever], list, Optional[list], Optional[list[whatever]], etc.
    """
    if depth > 10:
        return False  # Prevent infinite recursion in case of circular references
    if annotation is target:
        return True
    origin = typing.get_origin(annotation)
    if origin is target:
        return True
    elif origin is typing.Union:
        if any(annotation_matches_type(arg, target, depth + 1) for arg in typing.get_args(annotation)):
            return True
    return False


@functools.wraps(orig_get_annotation_from_field_info)
def get_annotation_from_field_info(
    annotation: Any,
    field_info,
    field_name: str,
    validate_assignment: bool = False,
) -> Type[Any]:
    """
    Monkey patch to handle the min_items/min_length issue.

    When `Field(min_length=...)` is used, there is no way to tell (in pydantic 1) whether it's being
    used for a string or a list. Pydantic 2 removed the `min_items` and `max_items` keywords, so we
    need to pass both values in and disable pydantic's "unused constraints" failure for those particular
    cases.

    The only way to do this without copying the entire body of the BaseModel metaclass __new__ method
    is monkeypatching.
    See https://github.com/pydantic/pydantic/blob/v1.10.22/pydantic/schema.py#L1001-L1025
    for original code.
    """
    if field_info.extra.get("__is_shim_field__", False):
        constraints = field_info.get_constraints()
        try:
            # check if the annotation is list-y, e.g. list, List[whatver], Optional[list], etc.
            if annotation_matches_type(annotation, list):
                if "min_length" in constraints:
                    field_info.min_items = field_info.min_length
                    field_info.min_length = None
                if "max_length" in constraints:
                    field_info.max_items = field_info.max_length
                    field_info.max_length = None
        except TypeError:
            pass
        field_info.extra.pop("__is_shim_field__", None)
    return orig_get_annotation_from_field_info(
        annotation,
        field_info,
        field_name,
        validate_assignment,
    )


mock.patch.object(_pydantic_schema, "get_annotation_from_field_info", get_annotation_from_field_info).start()


class CustomModelMetaclass(type(PydanticBaseModel)):
    def __new__(cls, name, bases, attrs, **kwargs):
        # Map model_config (pydantic 2) to a Config class (pydantic 1).
        if "model_config" in attrs:
            attrs["Config"] = construct_config_class_from_config_dict(attrs["model_config"])
            del attrs["model_config"]
        return super().__new__(cls, name, bases, attrs, **kwargs)


class BaseModel(PydanticBaseModel, metaclass=CustomModelMetaclass):
    # https://docs.pydantic.dev/latest/migration/#changes-to-pydanticbasemodel

    @classmethod
    def model_construct(cls, *args, **kwargs):
        if hasattr(PydanticBaseModel, "model_construct"):
            return super().model_construct(*args, **kwargs)
        else:
            return super().construct(*args, **kwargs)

    def model_copy(self, *args, **kwargs):
        if hasattr(PydanticBaseModel, "model_copy"):
            return super().model_copy(*args, **kwargs)
        else:
            return super().copy(*args, **kwargs)

    @classmethod
    def model_json_schema(cls, *args, **kwargs):
        if hasattr(PydanticBaseModel, "model_json_schema"):
            return super().model_json_schema(*args, **kwargs)
        else:
            return super().schema(*args, **kwargs)

    def model_dump(self, *args, **kwargs):
        if hasattr(PydanticBaseModel, "model_dump"):
            return super().model_dump(*args, **kwargs)
        else:
            # Remove Pydantic 2 specific parameters that don't exist in Pydantic 1
            filtered_kwargs = {k: v for k, v in kwargs.items() if k != "mode"}
            return super().dict(*args, **filtered_kwargs)

    def model_dump_json(self, *args, **kwargs):
        if hasattr(PydanticBaseModel, "model_dump_json"):
            return super().model_dump_json(*args, **kwargs)
        else:
            return super().json(*args, **kwargs)

    @classmethod
    @property
    def model_fields(cls):
        if "model_fields" in cls.__dict__:
            return cls.__dict__["model_fields"]
        else:
            return cls.__dict__["__fields__"]

    @classmethod
    def model_validate(cls, *args, **kwargs):
        if hasattr(PydanticBaseModel, "model_validate"):
            return super().model_validate(*args, **kwargs)
        else:
            if getattr(cls.Config, "orm_mode", False) and not kwargs:
                # If orm_mode is set to True and no kwargs are provided,
                # assume the first argument is an ORM object.
                obj = args[0] if args else None
                if not isinstance(obj, dict):
                    return cls.from_orm(obj)
                # otherwise, default parse_obj behavior is correct, so carry on
            return super().parse_obj(*args, **kwargs)

    @classmethod
    def model_rebuild(cls):
        if hasattr(PydanticBaseModel, "model_rebuild"):
            return super().model_rebuild()
        else:
            return super().update_forward_refs()

    @classmethod
    def model_validate_strings(cls, obj, *args, **kwargs):
        if hasattr(PydanticBaseModel, "model_validate_strings"):
            return super().model_validate_strings(obj, *args, **kwargs)
        else:
            # In Pydantic 1, we can use parse_obj_as with string conversion
            # This will automatically convert string values to appropriate types
            return cls.parse_obj(obj)

    @classmethod
    def model_validate_json(cls, json_data, *args, **kwargs):
        if hasattr(PydanticBaseModel, "model_validate_json"):
            return super().model_validate_json(json_data, *args, **kwargs)
        else:
            return cls.parse_raw(json_data, *args, **kwargs)


class ConfigDict(dict):
    pass


def field_validator(field_name, /, *fields, mode="before", check_fields=True):
    # In Pydantic 1, the check_fields parameter doesn't exist, so we ignore it
    # but accept it for compatibility with Pydantic 2
    if mode == "before":
        return pydantic_validator(field_name, *fields, pre=True, allow_reuse=True)
    elif mode == "after":
        return pydantic_validator(field_name, *fields, pre=False, allow_reuse=True)
    else:
        raise ValueError(f"Invalid mode: {mode}. Use 'before' or 'after'.")


def model_validator(*, mode: Literal["wrap", "before", "after"]):
    if mode == "before":
        return pydantic_root_validator(pre=True, allow_reuse=True)
    elif mode == "after":

        def wrapper(func):
            @classmethod
            def wrapped(cls, values):
                # Construct an instance without running validation.
                # since the field and pre validators have already been run, these values should already be valid.
                # In pydantic 1, @root_validator(pre=False) expects a dictionary of values, but in pydantic 2,
                # model_validatory(mode="after") expects an instance of the model.
                instance = cls.construct(**values)
                validated = func(instance)
                # Return the validated values, preserving nested model instances
                fields = cls.model_fields
                return {k: v for k, v in validated.__dict__.items() if k in fields}

            return pydantic_root_validator(pre=False, allow_reuse=True, skip_on_failure=True)(wrapped)

        return wrapper
    else:
        # TODO: handle mode="wrap"?
        raise ValueError(f"Invalid mode: {mode}. Use 'before' or 'after'.")


def Field(*args, **kwargs):
    """
    Field shim that maps Pydantic v2 Field arguments to Pydantic v1 equivalents.
    """
    # Handle parameter remapping from v2 to v1
    # Note that min_length and max_length were valid keywords in v1, but only applied
    # to strings, not lists. In v2, these keywords apply to lists as well, but the
    # min_items and max_items keywords were deleted to make it harder to upgrade.
    # Those cases are handled in get_annotation_from_field_info above.

    if "pattern" in kwargs:
        kwargs["regex"] = kwargs.pop("pattern")

    # Handle json_schema_extra - in v1, extra kwargs are added directly to schema
    if "json_schema_extra" in kwargs:
        extra_schema = kwargs.pop("json_schema_extra")
        if isinstance(extra_schema, dict):
            kwargs.update(extra_schema)
    kwargs["__is_shim_field__"] = True
    return PydanticField(*args, **kwargs)


# Re-implement GenericModel from pydantic.generics (or pydantic.v1.generics)
# Portions of code copied and adapted from: https://github.com/pydantic/pydantic/blob/f42171c760d43b9522fde513ae6e209790f7fefb/pydantic/v1/generics.py
# The MIT License (MIT)
#
# Copyright (c) 2017 to present Pydantic Services Inc. and individual contributors.
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
TypeVarType = Any  # since mypy doesn't allow the use of TypeVar as a type
GenericModelT = TypeVar("GenericModelT", bound="GenericModel")

CacheKey = Tuple[Type[Any], Any, Tuple[Any, ...]]
Parametrization = Mapping[TypeVarType, Type[Any]]
GenericTypesCache = WeakValueDictionary[CacheKey, Type[BaseModel]]
AssignedParameters = WeakKeyDictionary[Type[BaseModel], Parametrization]

# _generic_types_cache is a Mapping from __class_getitem__ arguments to the parametrized version of generic models.
# This ensures multiple calls of e.g. A[B] return always the same class.
_generic_types_cache = GenericTypesCache()

# _assigned_parameters is a Mapping from parametrized version of generic models to assigned types of parametrizations
# as captured during construction of the class (not instances).
# E.g., for generic model `Model[A, B]`, when parametrized model `Model[int, str]` is created,
# `Model[int, str]`: {A: int, B: str}` will be stored in `_assigned_parameters`.
# (This information is only otherwise available after creation from the class name string).
_assigned_parameters = AssignedParameters()


class GenericModel(BaseModel):
    __slots__ = ()
    __concrete__: ClassVar[bool] = False

    if TYPE_CHECKING:
        # Putting this in a TYPE_CHECKING block allows us to replace `if Generic not in cls.__bases__` with
        # `not hasattr(cls, "__parameters__")`. This means we don't need to force non-concrete subclasses of
        # `GenericModel` to also inherit from `Generic`, which would require changes to the use of `create_model` below.
        __parameters__: ClassVar[Tuple[TypeVarType, ...]]

    # Setting the return type as Type[Any] instead of Type[BaseModel] prevents PyCharm warnings
    def __class_getitem__(cls: Type[GenericModelT], params: Union[Type[Any], Tuple[Type[Any], ...]]) -> Type[Any]:
        """Instantiates a new class from a generic class `cls` and type variables `params`.

        :param params: Tuple of types the class . Given a generic class
            `Model` with 2 type variables and a concrete model `Model[str, int]`,
            the value `(str, int)` would be passed to `params`.
        :return: New model class inheriting from `cls` with instantiated
            types described by `params`. If no parameters are given, `cls` is
            returned as is.

        """

        def _cache_key(_params: Any) -> CacheKey:
            args = get_args(_params)
            # python returns a list for Callables, which is not hashable
            if len(args) == 2 and isinstance(args[0], list):
                args = (tuple(args[0]), args[1])
            return cls, _params, args

        cached = _generic_types_cache.get(_cache_key(params))
        if cached is not None:
            return cached
        if cls.__concrete__ and Generic not in cls.__bases__:
            raise TypeError("Cannot parameterize a concrete instantiation of a generic model")
        if not isinstance(params, tuple):
            params = (params,)
        if cls is GenericModel and any(isinstance(param, TypeVar) for param in params):
            raise TypeError("Type parameters should be placed on typing.Generic, not GenericModel")
        if not hasattr(cls, "__parameters__"):
            raise TypeError(f"Type {cls.__name__} must inherit from typing.Generic before being parameterized")

        check_parameters_count(cls, params)
        # Build map from generic typevars to passed params
        typevars_map: Dict[TypeVarType, Type[Any]] = dict(zip(cls.__parameters__, params))
        if all_identical(typevars_map.keys(), typevars_map.values()) and typevars_map:
            return cls  # if arguments are equal to parameters it's the same object

        # Create new model with original model as parent inserting fields with DeferredType.
        model_name = cls.__concrete_name__(params)
        validators = gather_all_validators(cls)

        type_hints = get_all_type_hints(cls).items()
        instance_type_hints = {k: v for k, v in type_hints if get_origin(v) is not ClassVar}

        fields = {k: (DeferredType(), cls.__fields__[k].field_info) for k in instance_type_hints if k in cls.__fields__}

        model_module, called_globally = get_caller_frame_info()
        created_model = cast(
            Type[GenericModel],  # casting ensures mypy is aware of the __concrete__ and __parameters__ attributes
            create_model(
                model_name,
                __module__=model_module or cls.__module__,
                __base__=(cls,) + tuple(cls.__parameterized_bases__(typevars_map)),
                __config__=None,
                __validators__=validators,
                __cls_kwargs__=None,
                **fields,
            ),
        )

        _assigned_parameters[created_model] = typevars_map

        if called_globally:  # create global reference and therefore allow pickling
            object_by_reference = None
            reference_name = model_name
            reference_module_globals = sys.modules[created_model.__module__].__dict__
            while object_by_reference is not created_model:
                object_by_reference = reference_module_globals.setdefault(reference_name, created_model)
                reference_name += "_"

        created_model.Config = cls.Config

        # Find any typevars that are still present in the model.
        # If none are left, the model is fully "concrete", otherwise the new
        # class is a generic class as well taking the found typevars as
        # parameters.
        new_params = tuple(
            {param: None for param in iter_contained_typevars(typevars_map.values())}
        )  # use dict as ordered set
        created_model.__concrete__ = not new_params
        if new_params:
            created_model.__parameters__ = new_params

        # Save created model in cache so we don't end up creating duplicate
        # models that should be identical.
        _generic_types_cache[_cache_key(params)] = created_model
        if len(params) == 1:
            _generic_types_cache[_cache_key(params[0])] = created_model

        # Recursively walk class type hints and replace generic typevars
        # with concrete types that were passed.
        _prepare_model_fields(created_model, fields, instance_type_hints, typevars_map)

        return created_model

    @classmethod
    def __concrete_name__(cls: Type[Any], params: Tuple[Type[Any], ...]) -> str:
        """Compute class name for child classes.

        :param params: Tuple of types the class . Given a generic class
            `Model` with 2 type variables and a concrete model `Model[str, int]`,
            the value `(str, int)` would be passed to `params`.
        :return: String representing a the new class where `params` are
            passed to `cls` as type variables.

        This method can be overridden to achieve a custom naming scheme for GenericModels.
        """
        param_names = [display_as_type(param) for param in params]
        params_component = ", ".join(param_names)
        return f"{cls.__name__}[{params_component}]"

    @classmethod
    def __parameterized_bases__(cls, typevars_map: Parametrization) -> Iterator[Type[Any]]:
        """
        Returns unbound bases of cls parameterised to given type variables

        :param typevars_map: Dictionary of type applications for binding subclasses.
            Given a generic class `Model` with 2 type variables [S, T]
            and a concrete model `Model[str, int]`,
            the value `{S: str, T: int}` would be passed to `typevars_map`.
        :return: an iterator of generic sub classes, parameterised by `typevars_map`
            and other assigned parameters of `cls`

        e.g.:
        ```
        class A(GenericModel, Generic[T]):
            ...

        class B(A[V], Generic[V]):
            ...

        assert A[int] in B.__parameterized_bases__({V: int})
        ```
        """

        def build_base_model(
            base_model: Type[GenericModel], mapped_types: Parametrization
        ) -> Iterator[Type[GenericModel]]:
            base_parameters = tuple(mapped_types[param] for param in base_model.__parameters__)
            parameterized_base = base_model.__class_getitem__(base_parameters)
            if parameterized_base is base_model or parameterized_base is cls:
                # Avoid duplication in MRO
                return
            yield parameterized_base

        for base_model in cls.__bases__:
            if not issubclass(base_model, GenericModel):
                # not a class that can be meaningfully parameterized
                continue
            elif not getattr(base_model, "__parameters__", None):
                # base_model is "GenericModel"  (and has no __parameters__)
                # or
                # base_model is already concrete, and will be included transitively via cls.
                continue
            elif cls in _assigned_parameters:
                if base_model in _assigned_parameters:
                    # cls is partially parameterised but not from base_model
                    # e.g. cls = B[S], base_model = A[S]
                    # B[S][int] should subclass A[int],  (and will be transitively via B[int])
                    # but it's not viable to consistently subclass types with arbitrary construction
                    # So don't attempt to include A[S][int]
                    continue
                else:  # base_model not in _assigned_parameters:
                    # cls is partially parameterized, base_model is original generic
                    # e.g.  cls = B[str, T], base_model = B[S, T]
                    # Need to determine the mapping for the base_model parameters
                    mapped_types: Parametrization = {
                        key: typevars_map.get(value, value) for key, value in _assigned_parameters[cls].items()
                    }
                    yield from build_base_model(base_model, mapped_types)
            else:
                # cls is base generic, so base_class has a distinct base
                # can construct the Parameterised base model using typevars_map directly
                yield from build_base_model(base_model, typevars_map)


def replace_types(type_: Any, type_map: Mapping[Any, Any]) -> Any:
    """Return type with all occurrences of `type_map` keys recursively replaced with their values.

    :param type_: Any type, class or generic alias
    :param type_map: Mapping from `TypeVar` instance to concrete types.
    :return: New type representing the basic structure of `type_` with all
        `typevar_map` keys recursively replaced.

    >>> replace_types(Tuple[str, Union[List[str], float]], {str: int})
    Tuple[int, Union[List[int], float]]

    """
    if not type_map:
        return type_

    type_args = get_args(type_)
    origin_type = get_origin(type_)

    if origin_type is Annotated:
        annotated_type, *annotations = type_args
        return Annotated[replace_types(annotated_type, type_map), tuple(annotations)]

    if (origin_type is ExtLiteral) or (sys.version_info >= (3, 8) and origin_type is Literal):
        return type_map.get(type_, type_)
    # Having type args is a good indicator that this is a typing module
    # class instantiation or a generic alias of some sort.
    if type_args:
        resolved_type_args = tuple(replace_types(arg, type_map) for arg in type_args)
        if all_identical(type_args, resolved_type_args):
            # If all arguments are the same, there is no need to modify the
            # type or create a new object at all
            return type_
        if (
            origin_type is not None
            and isinstance(type_, typing_base)
            and not isinstance(origin_type, typing_base)
            and getattr(type_, "_name", None) is not None
        ):
            # In python < 3.9 generic aliases don't exist so any of these like `list`,
            # `type` or `collections.abc.Callable` need to be translated.
            # See: https://www.python.org/dev/peps/pep-0585
            origin_type = getattr(typing, type_._name)
        assert origin_type is not None
        # PEP-604 syntax (Ex.: list | str) is represented with a types.UnionType object that does not have __getitem__.
        # We also cannot use isinstance() since we have to compare types.
        if sys.version_info >= (3, 10) and origin_type is types.UnionType:  # noqa: E721
            return _UnionGenericAlias(origin_type, resolved_type_args)
        return origin_type[resolved_type_args]

    # We handle pydantic generic models separately as they don't have the same
    # semantics as "typing" classes or generic aliases
    if not origin_type and lenient_issubclass(type_, GenericModel) and not type_.__concrete__:
        type_args = type_.__parameters__
        resolved_type_args = tuple(replace_types(t, type_map) for t in type_args)
        if all_identical(type_args, resolved_type_args):
            return type_
        return type_[resolved_type_args]

    # Handle special case for typehints that can have lists as arguments.
    # `typing.Callable[[int, str], int]` is an example for this.
    if isinstance(type_, (List, list)):
        resolved_list = list(replace_types(element, type_map) for element in type_)
        if all_identical(type_, resolved_list):
            return type_
        return resolved_list

    # For JsonWrapperValue, need to handle its inner type to allow correct parsing
    # of generic Json arguments like Json[T]
    if not origin_type and lenient_issubclass(type_, JsonWrapper):
        type_.inner_type = replace_types(type_.inner_type, type_map)
        return type_

    # If all else fails, we try to resolve the type directly and otherwise just
    # return the input with no modifications.
    new_type = type_map.get(type_, type_)
    # Convert string to ForwardRef
    if isinstance(new_type, str):
        return ForwardRef(new_type)
    else:
        return new_type


def check_parameters_count(cls: Type[GenericModel], parameters: Tuple[Any, ...]) -> None:
    actual = len(parameters)
    expected = len(cls.__parameters__)
    if actual != expected:
        description = "many" if actual > expected else "few"
        raise TypeError(f"Too {description} parameters for {cls.__name__}; actual {actual}, expected {expected}")


DictValues: Type[Any] = {}.values().__class__


def iter_contained_typevars(v: Any) -> Iterator[TypeVarType]:
    """Recursively iterate through all subtypes and type args of `v` and yield any typevars that are found."""
    if isinstance(v, TypeVar):
        yield v
    elif hasattr(v, "__parameters__") and not get_origin(v) and lenient_issubclass(v, GenericModel):
        yield from v.__parameters__
    elif isinstance(v, (DictValues, list)):
        for var in v:
            yield from iter_contained_typevars(var)
    else:
        args = get_args(v)
        for arg in args:
            yield from iter_contained_typevars(arg)


def get_caller_frame_info() -> Tuple[Optional[str], bool]:
    """
    Used inside a function to check whether it was called globally

    Will only work against non-compiled code, therefore used only in pydantic.generics

    :returns Tuple[module_name, called_globally]
    """
    try:
        previous_caller_frame = sys._getframe(2)
    except ValueError as e:
        raise RuntimeError("This function must be used inside another function") from e
    except AttributeError:  # sys module does not have _getframe function, so there's nothing we can do about it
        return None, False
    frame_globals = previous_caller_frame.f_globals
    return frame_globals.get("__name__"), previous_caller_frame.f_locals is frame_globals


def _prepare_model_fields(
    created_model: Type[GenericModel],
    fields: Mapping[str, Any],
    instance_type_hints: Mapping[str, type],
    typevars_map: Mapping[Any, type],
) -> None:
    """
    Replace DeferredType fields with concrete type hints and prepare them.
    """

    for key, field in created_model.__fields__.items():
        if key not in fields:
            assert field.type_.__class__ is not DeferredType
            # https://github.com/nedbat/coveragepy/issues/198
            continue  # pragma: no cover

        assert field.type_.__class__ is DeferredType, field.type_.__class__

        field_type_hint = instance_type_hints[key]
        concrete_type = replace_types(field_type_hint, typevars_map)
        field.type_ = concrete_type
        field.outer_type_ = concrete_type
        field.prepare()
        created_model.__annotations__[key] = concrete_type


# End of re-implementation of GenericModel from pydantic.generics (or pydantic.v1.generics)


__all__ = [
    "BaseModel",
    "ConfigDict",
    "GenericModel",
    "field_validator",
    "model_validator",
    "Field",
    "ValidationError",
    "PrivateAttr",
]
