"""
This module has the following behavior:
* On pydantic 1, it behaves like pydantic1.py and wraps ordinary
  models to work similarly to pydantic2 models.
* On pydantic 2, it wraps the pydantic.v1 shims that the pydantic team added.
  These were a frustrating half-measure, since they aren't intercompatible
  with pydantic.BaseModel, and so spread through a some zombifying fungus.

The approach here allows migrating back off of pydantic.v1 by making them behave
like pydantic 2 modules. Once every use of pydantic.v1 is replaced with
pydantic_12_shims.v1, then you can substitute ordinary pydantic models.
"""
import os
from . import PYDANTIC2

if PYDANTIC2 and os.getenv("TURN_PYDANTIC_V1_OFF", "0").lower() in "true yes 1".split():
    # If the environment variable is set, we disable pydantic.v1
    # and use the pydantic2 module directly.
    from .pydantic2 import *  # noqa: F401, F403
else:
    from .pydantic1 import *  # noqa: F401, F403
