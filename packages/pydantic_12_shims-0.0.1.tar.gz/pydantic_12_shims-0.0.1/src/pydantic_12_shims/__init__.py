import pydantic

__pydantic_version__ = pydantic.__version__
PYDANTIC1 = __pydantic_version__.startswith("1.")
PYDANTIC2 = __pydantic_version__.startswith("2.")
if PYDANTIC1:
    from .pydantic1 import (
        BaseModel,
        ConfigDict,
        GenericModel,
        field_validator,
        model_validator,
        Field,
        ValidationError,
        PrivateAttr,
    )
else:
    from .pydantic2 import (
        BaseModel,
        ConfigDict,
        GenericModel,
        field_validator,
        model_validator,
        Field,
        ValidationError,
        PrivateAttr,
    )


__all__ = [
    "PYDANTIC1",
    "PYDANTIC2",
    "BaseModel",
    "ConfigDict",
    "GenericModel",
    "field_validator",
    "model_validator",
    "Field",
    "ValidationError",
    "PrivateAttr",
]
