WARN = '#cc5533'
INFO = '#ccaa33'

HINT = '#3366cc'
CORRECT = '#33cc33'
SOLUTION = '#33cc99'
INCORRECT = '#cc3333'
