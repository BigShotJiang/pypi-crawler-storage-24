import{b as r}from"./_baseUniq-NLJhsO_V.js";var e=4;function a(o){return r(o,e)}export{a as c};
