from dataclasses import field
from typing import Literal

from pydantic.dataclasses import dataclass

from kumoapi.task import TaskType

TargetTransform = Literal['clip', 'power', 'quantile']


@dataclass
class InferenceConfig:
    num_estimators: int = 1
    column_shuffle: bool = False
    category_shuffle: bool = False
    hop_shuffle: bool = False

    @classmethod
    def from_task_type(cls, task_type: TaskType) -> 'InferenceConfig':
        if task_type.is_classification:
            return ClassificationInferenceConfig()
        if task_type in {TaskType.REGRESSION, TaskType.FORECASTING}:
            return RegressionInferenceConfig()
        return InferenceConfig()


@dataclass
class ClassificationInferenceConfig(InferenceConfig):
    class_shuffle: bool = False


@dataclass
class RegressionInferenceConfig(InferenceConfig):
    target_transforms: list[TargetTransform | None] = field(
        default_factory=lambda: ['quantile'])
