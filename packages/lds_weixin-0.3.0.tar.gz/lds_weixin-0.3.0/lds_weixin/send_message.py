from typing import Union, List, Dict, Any

from .api import QYWeiXin


class QYWeiXinMessage(QYWeiXin):
    """
    发送应用消息(常用的消息类型)

    https://developer.work.weixin.qq.com/document/path/90236
    """

    def send_text(self,
                  content: str,
                  touser: Union[str, List[str]] = None,
                  toparty: Union[str, List[str]] = None,
                  totag: Union[str, List[str]] = None,
                  **kwargs) -> dict:
        """
        发送文本消息
        :param content: 消息内容，支持换行、以及A标签
        :param touser: 指定接收消息的成员，成员ID列表（最多支持1000个）
        :param toparty: 指定接收消息的部门，部门ID列表，最多支持100个
        :param totag: 指定接收消息的标签，标签ID列表，最多支持100个
        :param kwargs: 支持 safe, enable_duplicate_check 等额外参数
        """
        msg_data = {
            "text": {
                "content": content
            }
        }
        return self.send_app_message("text", msg_data, touser, toparty, totag, **kwargs)

    def send_image(self,
                   media_id: str,
                   touser: Union[str, List[str]] = None,
                   toparty: Union[str, List[str]] = None,
                   totag: Union[str, List[str]] = None,
                   **kwargs) -> dict:
        """
        发送图片消息
        :param media_id: 图片媒体文件id，可以调用上传临时素材接口获取
        :param touser: 指定接收消息的成员，成员ID列表（最多支持1000个）
        :param toparty: 指定接收消息的部门，部门ID列表，最多支持100个
        :param totag: 指定接收消息的标签，标签ID列表，最多支持100个
        """
        msg_data = {
            "image": {
                "media_id": media_id
            }
        }
        return self.send_app_message("image", msg_data, touser, toparty, totag, **kwargs)

    def send_voice(self,
                   media_id: str,
                   touser: Union[str, List[str]] = None,
                   toparty: Union[str, List[str]] = None,
                   totag: Union[str, List[str]] = None,
                   **kwargs) -> dict:
        """
        发送语音消息
        """
        msg_data = {
            "voice": {
                "media_id": media_id
            }
        }
        return self.send_app_message("voice", msg_data, touser, toparty, totag, **kwargs)

    def send_video(self,
                   media_id: str,
                   title: str = "",
                   description: str = "",
                   touser: Union[str, List[str]] = None,
                   toparty: Union[str, List[str]] = None,
                   totag: Union[str, List[str]] = None,
                   **kwargs) -> dict:
        """
        发送视频消息
        title	否	视频消息的标题，不超过128个字节，超过会自动截断
        description	否	视频消息的描述，不超过512个字节，超过会自动截断
        """
        msg_data = {
            "video": {
                "media_id": media_id,
                "title": title,
                "description": description
            }
        }
        return self.send_app_message("video", msg_data, touser, toparty, totag, **kwargs)

    def send_file(self,
                  media_id: str,
                  touser: Union[str, List[str]] = None,
                  toparty: Union[str, List[str]] = None,
                  totag: Union[str, List[str]] = None,
                  **kwargs) -> dict:
        """
        发送文件消息
        """
        msg_data = {
            "file": {
                "media_id": media_id
            }
        }
        return self.send_app_message("file", msg_data, touser, toparty, totag, **kwargs)

    def send_text_card(self,
                       title: str,
                       description: str,
                       url: str,
                       btn_txt: str = "详情",
                       touser: Union[str, List[str]] = None,
                       toparty: Union[str, List[str]] = None,
                       totag: Union[str, List[str]] = None,
                       **kwargs) -> dict:
        """
        发送文本卡片消息
        title	是	标题，不超过128个字符，超过会自动截断（支持id转译）
        description	是	描述，不超过512个字符，超过会自动截断（支持id转译）
        url	是	点击后跳转的链接。最长2048字节，请确保包含了协议头(http/https)
        btntxt	否	按钮文字。 默认为“详情”， 不超过4个文字，超过自动截断。
        """
        msg_data = {
            "textcard": {
                "title": title,
                "description": description,
                "url": url,
                "btntxt": btn_txt
            }
        }
        return self.send_app_message("textcard", msg_data, touser, toparty, totag, **kwargs)

    def send_news(self,
                  articles: List[Dict[str, str]],
                  touser: Union[str, List[str]] = None,
                  toparty: Union[str, List[str]] = None,
                  totag: Union[str, List[str]] = None,
                  **kwargs) -> dict:
        """
        发送图文消息

        :param articles: 图文消息列表，一个图文消息支持1到8条图文，每个 item 包含 title, description, url, picurl等
        title	是	标题，不超过128个字节，超过会自动截断（支持id转译）
        description	否	描述，不超过512个字节，超过会自动截断（支持id转译）
        url	否	点击后跳转的链接。 最长2048字节，请确保包含了协议头(http/https)，小程序或者url必须填写一个
        picurl	否	图文消息的图片链接，最长2048字节，支持JPG、PNG格式，较好的效果为大图 1068*455，小图150*150。
        appid	否	小程序appid，必须是与当前应用关联的小程序，appid和pagepath必须同时填写，填写后会忽略url字段
        pagepath	否	点击消息卡片后的小程序页面，最长128字节，仅限本小程序内的页面。appid和pagepath必须同时填写，填写后会忽略url字段

        示例:
        [
            {
               "title" : "中秋节礼品领取",
               "description" : "今年中秋节公司有豪礼相送",
               "url" : "URL",
               "picurl" : "https://res.mail.qq.com/node/ww/wwopenmng/images/independent/doc/test_pic_msg1.png",
               # 优先使用小程序的设置
			   "appid": "wx123123123123123",
        	   "pagepath": "pages/index?userid=zhangsan&orderid=123123123"
            }
        ]
        """
        msg_data = {
            "news": {
                "articles": articles
            }
        }
        return self.send_app_message("news", msg_data, touser, toparty, totag, **kwargs)
