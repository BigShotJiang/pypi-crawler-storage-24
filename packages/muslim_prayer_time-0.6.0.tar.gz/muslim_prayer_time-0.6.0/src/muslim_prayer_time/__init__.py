"""Accurate prayer times for Muslims by location and date."""

from .core import (
    PrayerTimes,
    get_prayer_times,
    get_yearly_prayer_times,
    get_supported_methods,
    geocode_location,
    get_prayer_times_by_location,
    get_prayer_times_by_city,
)
from .cities import list_cities, find_city, register_city

__all__ = [
    "PrayerTimes",
    "get_prayer_times",
    "get_yearly_prayer_times",
    "get_supported_methods",
    "geocode_location",
    "get_prayer_times_by_location",
    "get_prayer_times_by_city",
    "list_cities",
    "find_city",
    "register_city",
]
