from __future__ import annotations

import json
from dataclasses import dataclass
from datetime import date, datetime
from typing import Dict, Iterable, List, Optional
from zoneinfo import ZoneInfo
from importlib import resources


@dataclass(frozen=True)
class City:
    name: str
    country: str
    lat: float
    lon: float
    tz: str
    aliases: List[str]


_CITY_INDEX: Dict[str, List[City]] = {}
_CITIES: List[City] = []


def _normalize(text: str) -> str:
    return " ".join(text.strip().lower().replace("-", " ").split())


def _load_cities() -> List[City]:
    global _CITIES
    if _CITIES:
        return _CITIES

    data_path = resources.files("muslim_prayer_time").joinpath("data/cities.json")
    raw = json.loads(data_path.read_text(encoding="utf-8"))
    _CITIES = [
        City(
            name=item["name"],
            country=item["country"],
            lat=float(item["lat"]),
            lon=float(item["lon"]),
            tz=item["tz"],
            aliases=list(item.get("aliases", [])),
        )
        for item in raw
    ]
    return _CITIES


def _build_index() -> None:
    if _CITY_INDEX:
        return
    for city in _load_cities():
        keys = [city.name, f"{city.name}, {city.country}"] + city.aliases
        for key in keys:
            norm = _normalize(key)
            _CITY_INDEX.setdefault(norm, []).append(city)


def list_cities() -> List[str]:
    _build_index()
    return sorted({f"{c.name}, {c.country}" for c in _CITIES})


def find_city(name: str) -> List[City]:
    _build_index()
    return list(_CITY_INDEX.get(_normalize(name), []))


def get_city(name: str, country: Optional[str] = None) -> City:
    matches = find_city(name)
    if not matches:
        raise ValueError(f"City not found: {name}")
    if country:
        matches = [c for c in matches if c.country.lower() == country.lower()]
    if len(matches) != 1:
        opts = ", ".join(f"{c.name}, {c.country}" for c in matches)
        raise ValueError(f"Ambiguous city name: {name}. Options: {opts}")
    return matches[0]


def register_city(
    name: str,
    country: str,
    lat: float,
    lon: float,
    tz: str,
    aliases: Optional[Iterable[str]] = None,
) -> None:
    city = City(name=name, country=country, lat=lat, lon=lon, tz=tz, aliases=list(aliases or []))
    _CITIES.append(city)
    _CITY_INDEX.clear()


def timezone_offset_hours(tz_name: str, d: date) -> float:
    dt = datetime(d.year, d.month, d.day, 12, 0, tzinfo=ZoneInfo(tz_name))
    offset = dt.utcoffset()
    if offset is None:
        raise ValueError(f"Unable to resolve timezone offset for {tz_name}")
    return offset.total_seconds() / 3600.0
