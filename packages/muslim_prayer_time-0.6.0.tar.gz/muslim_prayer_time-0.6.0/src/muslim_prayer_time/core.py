import math
from dataclasses import dataclass
from datetime import date, timedelta
from typing import Dict, Optional, Mapping, Tuple
from urllib.parse import urlencode
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

from .cities import get_city, timezone_offset_hours
import json
import time


@dataclass(frozen=True)
class PrayerTimes:
    fajr: str
    sunrise: str
    dhuhr: str
    asr: str
    sunset: str
    maghrib: str
    isha: str

    def to_dict(self) -> Dict[str, str]:
        return {
            "fajr": self.fajr,
            "sunrise": self.sunrise,
            "dhuhr": self.dhuhr,
            "asr": self.asr,
            "sunset": self.sunset,
            "maghrib": self.maghrib,
            "isha": self.isha,
        }


_METHODS = {
    "MWL": {"fajr": 18.0, "isha": 17.0, "maghrib": 0.0, "maghrib_is_offset": True},
    "ISNA": {"fajr": 15.0, "isha": 15.0, "maghrib": 0.0, "maghrib_is_offset": True},
    "Egypt": {"fajr": 19.5, "isha": 17.5, "maghrib": 0.0, "maghrib_is_offset": True},
    "Makkah": {"fajr": 18.5, "isha": 90.0, "maghrib": 0.0, "maghrib_is_offset": True},  # isha 90 min
    "UmmAlQura": {"fajr": 18.5, "isha": 90.0, "maghrib": 0.0, "maghrib_is_offset": True},
    "Karachi": {"fajr": 18.0, "isha": 18.0, "maghrib": 0.0, "maghrib_is_offset": True},
    "Tehran": {"fajr": 17.7, "isha": 14.0, "maghrib": 4.5, "maghrib_is_offset": False},
    "Jafari": {"fajr": 16.0, "isha": 14.0, "maghrib": 4.0, "maghrib_is_offset": False},
    "France": {"fajr": 12.0, "isha": 12.0, "maghrib": 0.0, "maghrib_is_offset": True},
    "Russia": {"fajr": 16.0, "isha": 15.0, "maghrib": 0.0, "maghrib_is_offset": True},
    "Singapore": {"fajr": 20.0, "isha": 18.0, "maghrib": 0.0, "maghrib_is_offset": True},
    "Moonsighting": {"fajr": 18.0, "isha": 18.0, "maghrib": 0.0, "maghrib_is_offset": True},
}

_HIGH_LAT_RULES = {"angle", "midnight", "one_seventh"}
_NOMINATIM_URL = "https://nominatim.openstreetmap.org/search"
_LAST_GEOCODE_TS = 0.0


# ---------- math helpers ----------

def _fix_angle(deg: float) -> float:
    return deg - 360.0 * math.floor(deg / 360.0)


def _fix_hour(hour: float) -> float:
    return hour - 24.0 * math.floor(hour / 24.0)


def _deg2rad(deg: float) -> float:
    return deg * math.pi / 180.0


def _rad2deg(rad: float) -> float:
    return rad * 180.0 / math.pi


def _sin(deg: float) -> float:
    return math.sin(_deg2rad(deg))


def _cos(deg: float) -> float:
    return math.cos(_deg2rad(deg))


def _tan(deg: float) -> float:
    return math.tan(_deg2rad(deg))


def _arccos(x: float) -> float:
    return _rad2deg(math.acos(x))


def _arcsin(x: float) -> float:
    return _rad2deg(math.asin(x))


def _arctan(x: float) -> float:
    return _rad2deg(math.atan(x))


def _arctan2(y: float, x: float) -> float:
    return _rad2deg(math.atan2(y, x))


# ---------- solar calculations ----------

def _julian_date(d: date) -> float:
    y = d.year
    m = d.month
    day = d.day
    if m <= 2:
        y -= 1
        m += 12
    a = math.floor(y / 100)
    b = 2 - a + math.floor(a / 4)
    jd = math.floor(365.25 * (y + 4716)) + math.floor(30.6001 * (m + 1)) + day + b - 1524.5
    return jd


def _sun_position(jd: float):
    d = jd - 2451545.0
    g = _fix_angle(357.529 + 0.98560028 * d)
    q = _fix_angle(280.459 + 0.98564736 * d)
    l = _fix_angle(q + 1.915 * _sin(g) + 0.020 * _sin(2 * g))
    e = 23.439 - 0.00000036 * d

    ra = _arctan2(_cos(e) * _sin(l), _cos(l)) / 15.0
    eqt = q / 15.0 - _fix_hour(ra)
    decl = _arcsin(_sin(e) * _sin(l))
    return decl, eqt


def _mid_day(jd: float, timezone: float, longitude: float) -> float:
    decl, eqt = _sun_position(jd)
    return _fix_hour(12.0 + timezone - longitude / 15.0 - eqt)


def _sun_angle_time(
    angle: float,
    jd: float,
    timezone: float,
    longitude: float,
    latitude: float,
    direction: str,
) -> float:
    decl, eqt = _sun_position(jd)
    noon = _fix_hour(12.0 + timezone - longitude / 15.0 - eqt)
    numerator = _sin(angle) - _sin(latitude) * _sin(decl)
    denominator = _cos(latitude) * _cos(decl)

    # clamp for numerical stability
    x = numerator / denominator
    if x < -1.0:
        x = -1.0
    if x > 1.0:
        x = 1.0

    t = _arccos(x) / 15.0
    if direction == "ccw":
        return _fix_hour(noon - t)
    return _fix_hour(noon + t)


def _asr_time(factor: int, jd: float, timezone: float, longitude: float, latitude: float) -> float:
    decl, _ = _sun_position(jd)
    # Asr uses a positive sun altitude angle
    angle = _arctan(1.0 / (factor + _tan(abs(latitude - decl))))
    return _sun_angle_time(angle, jd, timezone, longitude, latitude, "cw")


def _float_to_time_str(hour_float: float) -> str:
    hour_float = _fix_hour(hour_float + 0.5 / 60.0)  # rounding
    hours = int(math.floor(hour_float))
    minutes = int(math.floor((hour_float - hours) * 60.0))
    return f"{hours:02d}:{minutes:02d}"


def _night_portion(angle: float, rule: str) -> float:
    if rule == "angle":
        return angle / 60.0
    if rule == "midnight":
        return 0.5
    return 1.0 / 7.0


def _adjust_high_lat_times(
    fajr: float,
    isha: float,
    sunrise: float,
    sunset: float,
    fajr_angle: float,
    isha_angle: Optional[float],
    rule: str,
) -> (float, float):
    if rule not in _HIGH_LAT_RULES:
        return fajr, isha

    night = _fix_hour(sunrise - sunset)

    fajr_portion = _night_portion(fajr_angle, rule)
    fajr_limit = _fix_hour(sunrise - fajr_portion * night)
    if fajr is None or _time_diff(fajr, sunrise) > _time_diff(fajr_limit, sunrise):
        fajr = fajr_limit

    if isha_angle is not None:
        isha_portion = _night_portion(isha_angle, rule)
        isha_limit = _fix_hour(sunset + isha_portion * night)
        if isha is None or _time_diff(sunset, isha) > _time_diff(sunset, isha_limit):
            isha = isha_limit

    return fajr, isha


def _time_diff(time1: float, time2: float) -> float:
    return _fix_hour(time2 - time1)


# ---------- public API ----------

def get_prayer_times(
    d: date,
    latitude: float,
    longitude: float,
    timezone: float,
    method: str = "MWL",
    asr_method: str = "standard",
    high_latitude_rule: str = "angle",
    altitude: float = 0.0,
    adjustments: Optional[Mapping[str, int]] = None,
    makkah_isha_offset_minutes: Optional[int] = None,
) -> PrayerTimes:
    """
    Calculate prayer times for a single date.

    method:
        MWL, ISNA, Egypt, Makkah, UmmAlQura, Karachi, Tehran, Jafari, France, Russia, Singapore, Moonsighting
    asr_method:
        standard (Shafi) or hanafi
    high_latitude_rule:
        angle, midnight, one_seventh
    altitude:
        meters above sea level (affects sunrise/sunset)
    adjustments:
        dict of minute adjustments per prayer name (e.g., {"fajr": 2, "isha": -1})
    makkah_isha_offset_minutes:
        override Isha offset minutes for Makkah/UmmAlQura (e.g., 120 in Ramadan)
    """
    if method not in _METHODS:
        raise ValueError(f"Unknown method: {method}")
    if high_latitude_rule not in _HIGH_LAT_RULES:
        raise ValueError(f"Unknown high_latitude_rule: {high_latitude_rule}")

    method_cfg = _METHODS[method]
    factor = 2 if asr_method.lower() == "hanafi" else 1

    jd = _julian_date(d)

    # Sunrise/sunset correction for altitude
    # 0.0347 * sqrt(altitude) approximates elevation angle in degrees
    altitude_corr = 0.0347 * math.sqrt(max(altitude, 0.0))

    fajr = _sun_angle_time(-method_cfg["fajr"], jd, timezone, longitude, latitude, "ccw")
    sunrise = _sun_angle_time(-0.833 - altitude_corr, jd, timezone, longitude, latitude, "ccw")
    dhuhr = _mid_day(jd, timezone, longitude)
    asr = _asr_time(factor, jd, timezone, longitude, latitude)
    sunset = _sun_angle_time(-0.833 - altitude_corr, jd, timezone, longitude, latitude, "cw")

    if method_cfg["maghrib_is_offset"]:
        maghrib = sunset
    else:
        maghrib = _sun_angle_time(-method_cfg["maghrib"], jd, timezone, longitude, latitude, "cw")

    if method in {"Makkah", "UmmAlQura"}:
        offset_minutes = method_cfg["isha"]
        if makkah_isha_offset_minutes is not None:
            offset_minutes = float(makkah_isha_offset_minutes)
        isha = _fix_hour(maghrib + offset_minutes / 60.0)
        isha_angle = None
    else:
        isha = _sun_angle_time(-method_cfg["isha"], jd, timezone, longitude, latitude, "cw")
        isha_angle = method_cfg["isha"]

    fajr, isha = _adjust_high_lat_times(
        fajr,
        isha,
        sunrise,
        sunset,
        method_cfg["fajr"],
        isha_angle,
        high_latitude_rule,
    )

    if adjustments:
        fajr = _fix_hour(fajr + adjustments.get("fajr", 0) / 60.0)
        sunrise = _fix_hour(sunrise + adjustments.get("sunrise", 0) / 60.0)
        dhuhr = _fix_hour(dhuhr + adjustments.get("dhuhr", 0) / 60.0)
        asr = _fix_hour(asr + adjustments.get("asr", 0) / 60.0)
        sunset = _fix_hour(sunset + adjustments.get("sunset", 0) / 60.0)
        maghrib = _fix_hour(maghrib + adjustments.get("maghrib", 0) / 60.0)
        isha = _fix_hour(isha + adjustments.get("isha", 0) / 60.0)

    return PrayerTimes(
        fajr=_float_to_time_str(fajr),
        sunrise=_float_to_time_str(sunrise),
        dhuhr=_float_to_time_str(dhuhr),
        asr=_float_to_time_str(asr),
        sunset=_float_to_time_str(sunset),
        maghrib=_float_to_time_str(maghrib),
        isha=_float_to_time_str(isha),
    )


def get_yearly_prayer_times(
    year: int,
    latitude: float,
    longitude: float,
    timezone: float,
    method: str = "MWL",
    asr_method: str = "standard",
    high_latitude_rule: str = "angle",
    altitude: float = 0.0,
    adjustments: Optional[Mapping[str, int]] = None,
    makkah_isha_offset_minutes: Optional[int] = None,
) -> Dict[date, PrayerTimes]:
    """
    Calculate prayer times for every day in a year.
    Returns a dict: date -> PrayerTimes
    """
    start = date(year, 1, 1)
    end = date(year + 1, 1, 1)
    out: Dict[date, PrayerTimes] = {}
    current = start
    while current < end:
        out[current] = get_prayer_times(
            current,
            latitude,
            longitude,
            timezone,
            method,
            asr_method,
            high_latitude_rule,
            altitude,
            adjustments,
            makkah_isha_offset_minutes,
        )
        current += timedelta(days=1)
    return out


def get_supported_methods() -> Dict[str, Dict[str, float]]:
    return {k: dict(v) for k, v in _METHODS.items()}


def geocode_location(
    location: str,
    *,
    user_agent: str,
    email: Optional[str] = None,
    country_codes: Optional[str] = None,
    limit: int = 1,
    rate_limit_seconds: float = 1.0,
) -> Tuple[float, float, str]:
    """
    Resolve a location name to (latitude, longitude, display_name)
    using OpenStreetMap Nominatim.

    Note: You must provide a custom User-Agent and respect usage limits.
    """
    global _LAST_GEOCODE_TS
    if not user_agent or user_agent.lower().startswith("python-urllib"):
        raise ValueError("user_agent is required and must identify your application.")

    if rate_limit_seconds > 0:
        now = time.time()
        wait = rate_limit_seconds - (now - _LAST_GEOCODE_TS)
        if wait > 0:
            time.sleep(wait)

    params = {
        "q": location,
        "format": "jsonv2",
        "limit": str(max(1, int(limit))),
    }
    if email:
        params["email"] = email
    if country_codes:
        params["countrycodes"] = country_codes

    url = f"{_NOMINATIM_URL}?{urlencode(params)}"
    req = Request(url, headers={"User-Agent": user_agent, "Accept-Language": "en"})
    try:
        with urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except HTTPError as exc:
        if exc.code == 403:
            raise ValueError(
                "Geocoding request was forbidden (HTTP 403). "
                "Ensure you set a clear User-Agent with contact info and "
                "respect rate limits."
            ) from exc
        raise
    except URLError as exc:
        raise ValueError("Geocoding request failed. Check network access.") from exc

    _LAST_GEOCODE_TS = time.time()

    if not data:
        raise ValueError(f"Location not found: {location}")

    item = data[0]
    return float(item["lat"]), float(item["lon"]), item.get("display_name", "")


def get_prayer_times_by_location(
    d: date,
    location: str,
    timezone: float,
    *,
    user_agent: str,
    email: Optional[str] = None,
    country_codes: Optional[str] = None,
    method: str = "MWL",
    asr_method: str = "standard",
    high_latitude_rule: str = "angle",
    altitude: float = 0.0,
    adjustments: Optional[Mapping[str, int]] = None,
    makkah_isha_offset_minutes: Optional[int] = None,
    rate_limit_seconds: float = 1.0,
) -> PrayerTimes:
    """
    Convenience helper: geocode location name then compute prayer times.
    """
    lat, lon, _ = geocode_location(
        location,
        user_agent=user_agent,
        email=email,
        country_codes=country_codes,
        rate_limit_seconds=rate_limit_seconds,
    )
    return get_prayer_times(
        d=d,
        latitude=lat,
        longitude=lon,
        timezone=timezone,
        method=method,
        asr_method=asr_method,
        high_latitude_rule=high_latitude_rule,
        altitude=altitude,
        adjustments=adjustments,
        makkah_isha_offset_minutes=makkah_isha_offset_minutes,
    )


def get_prayer_times_by_city(
    d: date,
    city: str,
    *,
    country: Optional[str] = None,
    method: str = "MWL",
    asr_method: str = "standard",
    high_latitude_rule: str = "angle",
    altitude: float = 0.0,
    adjustments: Optional[Mapping[str, int]] = None,
    makkah_isha_offset_minutes: Optional[int] = None,
) -> PrayerTimes:
    """
    Compute prayer times by city name using the built-in offline city database.
    """
    info = get_city(city, country=country)
    tz_offset = timezone_offset_hours(info.tz, d)
    return get_prayer_times(
        d=d,
        latitude=info.lat,
        longitude=info.lon,
        timezone=tz_offset,
        method=method,
        asr_method=asr_method,
        high_latitude_rule=high_latitude_rule,
        altitude=altitude,
        adjustments=adjustments,
        makkah_isha_offset_minutes=makkah_isha_offset_minutes,
    )
