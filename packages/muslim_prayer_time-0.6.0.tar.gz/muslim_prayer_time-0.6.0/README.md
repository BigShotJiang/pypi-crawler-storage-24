# muslim_prayer_time

Accurate prayer times for Muslims by location and date.

## Install

```bash
pip install muslim_prayer_time
```


```python
from datetime import date
from muslim_prayer_time import get_prayer_times, get_prayer_times_by_location, get_prayer_times_by_city

# Riyadh example
pt = get_prayer_times(
    d=date(2025, 1, 15),
    latitude=24.7136,
    longitude=46.6753,
    timezone=3,
    method="MWL",
    asr_method="standard",
    high_latitude_rule="angle",
    altitude=0.0,
)

print(pt)
print(pt.fajr, pt.isha)

# By location name (requires a User-Agent and internet access)
pt2 = get_prayer_times_by_location(
    d=date(2025, 1, 15),
    location="Riyadh, Saudi Arabia",
    timezone=3,
    user_agent="muslim_prayer_time/0.4 (your_email@example.com)",
    email="your_email@example.com",
)
print(pt2)

# By city name (offline built-in database)
pt3 = get_prayer_times_by_city(
    d=date(2025, 1, 15),
    city="Riyadh",
    country="Saudi Arabia",
    method="MWL",
)
print(pt3)
```

## Methods

Supported methods:
- `MWL`
- `ISNA`
- `Egypt`
- `Makkah`
- `UmmAlQura`
- `Karachi`
- `Tehran`
- `Jafari`
- `France`
- `Russia`
- `Singapore`
- `Moonsighting`

## High Latitude Rules

- `angle`
- `midnight`
- `one_seventh`

## Notes

- `timezone` is the local UTC offset (e.g., `3` for UTC+3).
- `altitude` is meters above sea level; it slightly affects sunrise/sunset.
- `Makkah`/`UmmAlQura` use Isha at 90 minutes after Maghrib; you can override via `makkah_isha_offset_minutes` (e.g., 120 in Ramadan).
- `Tehran` Isha angle is not explicitly defined in the source table; this library uses the common 14° default.
- `Moonsighting` uses 18°/18° angles here (seasonal adjustments are not included).
- Built-in city database uses IANA timezones to account for DST when computing the offset.

## العربية

مكتبة دقيقة لحساب مواقيت الصلاة حسب الموقع والتاريخ.

### مثال سريع

```python
from datetime import date
from muslim_prayer_time import get_prayer_times

pt = get_prayer_times(
    d=date(2025, 1, 15),
    latitude=24.7136,
    longitude=46.6753,
    timezone=3,
    method="UmmAlQura",
    asr_method="standard",
    high_latitude_rule="angle",
    altitude=0.0,
    makkah_isha_offset_minutes=120,  # رمضان
    adjustments={"fajr": 2, "isha": -1},  # تعديل بالدقائق
)
print(pt)
```

### استخدام اسم الموقع فقط (Geocoding)

> ملاحظة: يلزم توفير `user_agent` واضح واحترام حد الطلبات لخدمة Nominatim.

```python
from datetime import date
from muslim_prayer_time import get_prayer_times_by_location

pt = get_prayer_times_by_location(
    d=date(2025, 1, 15),
    location="Riyadh, Saudi Arabia",
    timezone=3,
    user_agent="muslim_prayer_time/0.4 (your_email@example.com)",
    email="your_email@example.com",
)
print(pt)
```

### استخدام اسم المدينة (بدون إنترنت)

```python
from datetime import date
from muslim_prayer_time import get_prayer_times_by_city, list_cities

print(list_cities()[:10])  # عرض أول 10 مدن

pt = get_prayer_times_by_city(
    d=date(2025, 1, 15),
    city="الرياض",
    country="Saudi Arabia",
    method="UmmAlQura",
)
print(pt)
```

## License

MIT
