# Changelog

All notable changes to `argus-sdk` (Python) will be documented here.

## [0.1.0] - 2026-03-12

### Added
- `ArgusClient` — core client for sending LLM calls, tool calls, and actions to Argus
- `ArgusLangChainHandler` — drop-in LangChain callback handler (requires `langchain` extra)
- `wrap_openai` — wraps an OpenAI client to automatically audit all chat completion calls
