"""
argus-sdk — Python SDK for Argus

Captures AI agent events (LLM calls, tool calls, actions) and sends them
to Argus for risk scoring, alerting, and audit trail.

Works standalone or as a LangChain callback handler / OpenAI wrapper.

Usage:
    from argus_sdk import ArgusClient

    argus = ArgusClient(api_key="sk_live_...", actor_id="my-agent")
    argus.llm_call(input_text=prompt, output_text=response, input_tokens=512, output_tokens=128)
    argus.tool_call(action_type="search_web", payload={"query": q})
"""

import uuid
import requests
from typing import Any, Optional

__version__ = "0.1.0"
__all__ = ["ArgusClient", "ArgusLangChainHandler", "wrap_openai"]


# ─── ArgusClient ──────────────────────────────────────────────────────────────

class ArgusClient:
    """Core client for sending agent events to Argus."""

    def __init__(
        self,
        api_key: str,
        actor_id: str,
        base_url: str = "https://app.argus.ai",
    ):
        self.api_key = api_key
        self.actor_id = actor_id
        self.base_url = base_url.rstrip("/")

    def send(self, payload: dict) -> Optional[dict]:
        """Send a single event to Argus. Returns the parsed response or None on failure."""
        try:
            res = requests.post(
                f"{self.base_url}/api/v1/events",
                json={"actorType": "agent", "actorId": self.actor_id, **payload},
                headers={
                    "Content-Type": "application/json",
                    "Authorization": f"Bearer {self.api_key}",
                },
                timeout=5,
            )
            if not res.ok:
                print(f"[Argus] Failed to send event: {res.status_code} {res.text}")
                return None
            return res.json()
        except Exception as e:
            print(f"[Argus] Network error sending event: {e}")
            return None

    def llm_call(
        self,
        input_text: Optional[str] = None,
        output_text: Optional[str] = None,
        input_tokens: Optional[int] = None,
        output_tokens: Optional[int] = None,
        correlation_id: Optional[str] = None,
        payload: Optional[dict] = None,
    ) -> Optional[dict]:
        return self.send({
            "source": "proxy",
            "eventType": "llm_call",
            "inputText": input_text,
            "outputText": output_text,
            "inputTokens": input_tokens,
            "outputTokens": output_tokens,
            "correlationId": correlation_id,
            "payload": payload or {},
        })

    def tool_call(
        self,
        action_type: Optional[str] = None,
        input_text: Optional[str] = None,
        output_text: Optional[str] = None,
        correlation_id: Optional[str] = None,
        payload: Optional[dict] = None,
    ) -> Optional[dict]:
        return self.send({
            "source": "proxy",
            "eventType": "tool_call",
            "actionType": action_type,
            "inputText": input_text,
            "outputText": output_text,
            "correlationId": correlation_id,
            "payload": payload or {},
        })

    def action(
        self,
        action_type: Optional[str] = None,
        input_text: Optional[str] = None,
        output_text: Optional[str] = None,
        correlation_id: Optional[str] = None,
        payload: Optional[dict] = None,
    ) -> Optional[dict]:
        return self.send({
            "source": "proxy",
            "eventType": "action",
            "actionType": action_type,
            "inputText": input_text,
            "outputText": output_text,
            "correlationId": correlation_id,
            "payload": payload or {},
        })


# ─── LangChain callback handler ───────────────────────────────────────────────

try:
    from langchain.callbacks.base import BaseCallbackHandler

    class ArgusLangChainHandler(BaseCallbackHandler):
        """
        Drop-in LangChain callback handler. Pass to any chain or agent to
        automatically capture all LLM calls and tool calls.

        Example:
            argus = ArgusClient(api_key="sk_live_...", actor_id="my-agent")
            handler = ArgusLangChainHandler(argus)
            chain = LLMChain(llm=llm, prompt=prompt, callbacks=[handler])
        """

        def __init__(self, audit: ArgusClient):
            self.audit = audit
            self._run_correlations: dict[str, str] = {}
            self._input_texts: dict[str, str] = {}

        def on_llm_start(self, serialized: dict, prompts: list[str], *, run_id: Any, **kwargs: Any) -> None:
            correlation_id = str(uuid.uuid4())
            self._run_correlations[str(run_id)] = correlation_id
            self._input_texts[str(run_id)] = prompts[0] if prompts else ""

        def on_llm_end(self, response: Any, *, run_id: Any, **kwargs: Any) -> None:
            run_key = str(run_id)
            correlation_id = self._run_correlations.pop(run_key, run_key)
            input_text = self._input_texts.pop(run_key, None)
            output_text = response.generations[0][0].text if response.generations else None
            token_usage = getattr(response, "llm_output", {}) or {}
            usage = token_usage.get("token_usage", {})
            self.audit.llm_call(
                input_text=input_text,
                output_text=output_text,
                input_tokens=usage.get("prompt_tokens"),
                output_tokens=usage.get("completion_tokens"),
                correlation_id=correlation_id,
            )

        def on_tool_start(self, serialized: dict, input_str: str, *, run_id: Any, **kwargs: Any) -> None:
            self.audit.tool_call(
                action_type=serialized.get("name"),
                input_text=input_str,
                correlation_id=str(run_id),
            )

        def on_tool_end(self, output: Any, *, run_id: Any, **kwargs: Any) -> None:
            self.audit.tool_call(
                action_type="tool_result",
                output_text=str(output),
                correlation_id=str(run_id),
            )

except ImportError:
    pass  # LangChain not installed — ArgusLangChainHandler not available


# ─── OpenAI wrapper ────────────────────────────────────────────────────────────

def wrap_openai(client: Any, audit: ArgusClient) -> Any:
    """
    Wrap an OpenAI client to automatically audit all chat completion calls.

    Example:
        from openai import OpenAI
        from argus_sdk import ArgusClient, wrap_openai

        client = wrap_openai(OpenAI(), ArgusClient(api_key="sk_live_...", actor_id="my-agent"))
        # All client.chat.completions.create() calls are now audited
    """
    original_create = client.chat.completions.create

    def audited_create(**kwargs: Any) -> Any:
        messages = kwargs.get("messages", [])
        input_text = "\n".join(f"{m['role']}: {m['content']}" for m in messages)
        result = original_create(**kwargs)
        output_text = result.choices[0].message.content if result.choices else None
        usage = result.usage
        audit.llm_call(
            input_text=input_text,
            output_text=output_text,
            input_tokens=usage.prompt_tokens if usage else None,
            output_tokens=usage.completion_tokens if usage else None,
            payload={"model": kwargs.get("model")},
        )
        return result

    client.chat.completions.create = audited_create
    return client
