# feed_forward.py

import torch
import torch.nn as nn
import torch.nn.functional as F


class FFN(nn.Module):
    """Standard FFN. Used in original Transformer, BERT."""
    def __init__(self, dim: int, hidden: int):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(dim, hidden),
            nn.GELU(),
            nn.Linear(hidden, dim)
        )

    def forward(self, x):
        return self.net(x)


class SwiGLU(nn.Module):
    """Gated FFN with Swish. Used in LLaMA, Mistral, PaLM."""
    def __init__(self, dim: int, hidden: int):
        super().__init__()
        self.w1 = nn.Linear(dim, hidden, bias=False)
        self.w2 = nn.Linear(hidden, dim, bias=False)
        self.w3 = nn.Linear(dim, hidden, bias=False)

    def forward(self, x):
        return self.w2(F.silu(self.w1(x)) * self.w3(x))


class MoE(nn.Module):
    """
    Mixture of Experts. Used in Mixtral, GPT-4 (rumoured).

    Returns (output, aux_loss). The auxiliary load-balancing loss must be
    added to the main cross-entropy loss during training:

        logits, aux = model(x)          # if model surfaces aux_loss
        loss = F.cross_entropy(...) + aux_weight * aux_loss

    Without the aux loss, all tokens collapse onto 1-2 experts after a few
    hundred steps and the remaining experts never get trained.

    aux_weight is a hyperparameter — 0.01 is a safe default (Mixtral uses 0.02).
    """
    def __init__(self, dim: int, hidden: int, n_experts: int, top_k: int = 2,
                 aux_weight: float = 0.01):
        super().__init__()
        self.top_k      = top_k
        self.n_experts  = n_experts
        self.aux_weight = aux_weight
        self.gate       = nn.Linear(dim, n_experts, bias=False)
        self.experts    = nn.ModuleList([SwiGLU(dim, hidden) for _ in range(n_experts)])

    def forward(self, x):
        B, T, C = x.shape
        x_flat = x.view(-1, C)                                   # [N, C]  N = B*T

        gate_logits      = self.gate(x_flat)                     # [N, n_experts]
        weights, idx         = gate_logits.topk(self.top_k, dim=-1)  # [N, top_k]
        weights              = F.softmax(weights, dim=-1)        # [N, top_k]

        out = torch.zeros_like(x_flat)

        for i, expert in enumerate(self.experts):
            for k in range(self.top_k):
                token_mask = (idx[:, k] == i)
                # deduplicate: skip tokens already routed here by an earlier slot
                if k > 0:
                    already    = (idx[:, :k] == i).any(dim=-1)
                    token_mask = token_mask & ~already
                if not token_mask.any():
                    continue
                w = weights[token_mask, k].unsqueeze(-1)         # [n_sel, 1]
                out[token_mask] += w * expert(x_flat[token_mask])

        # ── load-balancing auxiliary loss (Switch Transformer / Mixtral style) ──
        # Encourages uniform expert utilisation. Without this, routing collapses.
        #   f_i  = fraction of tokens dispatched to expert i
        #   p_i  = mean routing probability for expert i across the batch
        #   loss = n_experts * sum(f_i * p_i)   (minimised when uniform)
        router_probs = F.softmax(gate_logits, dim=-1)            # [N, n_experts]
        # one-hot assignment for top-1 slot only (standard Switch loss)
        ones         = torch.zeros_like(router_probs)
        ones.scatter_(1, idx[:, 0:1], 1.0)
        f_i   = ones.mean(dim=0)                                 # [n_experts]
        p_i   = router_probs.mean(dim=0)                         # [n_experts]
        aux_loss = self.n_experts * (f_i * p_i).sum()

        return out.view(B, T, C), aux_loss
