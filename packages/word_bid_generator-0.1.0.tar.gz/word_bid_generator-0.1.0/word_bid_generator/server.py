# word_generator_mcp.py
# 基于 MCP Python SDK 开发

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import Tool, TextContent
import oss2
from docx import Document
from docx.shared import Pt, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
import json, os, uuid, datetime

app = Server("word-generator")

@app.list_tools()
async def list_tools():
    return [
        Tool(
            name="generate_bid_document",
            description="根据投标书结构化内容生成Word格式(.docx)的投标响应文件，返回OSS下载链接",
            inputSchema={
                "type": "object",
                "properties": {
                    "project_name": {
                        "type": "string",
                        "description": "招标项目名称，用于生成文件名"
                    },
                    "document_content": {
                        "type": "object", 
                        "description": "投标书各章节内容的JSON结构，包含章节标题和正文"
                    }
                },
                "required": ["project_name", "document_content"]
            }
        )
    ]

@app.call_tool()
async def call_tool(name: str, arguments: dict):
    if name == "generate_bid_document":
        # 1. 创建Word文档
        doc = Document()
        
        # 设置全局字体
        style = doc.styles['Normal']
        style.font.name = '宋体'
        style.font.size = Pt(12)
        
        project_name = arguments["project_name"]
        content = arguments["document_content"]
        
        # 2. 生成封面
        doc.add_heading(project_name, 0).alignment = WD_ALIGN_PARAGRAPH.CENTER
        doc.add_heading("投标响应文件", 1).alignment = WD_ALIGN_PARAGRAPH.CENTER
        doc.add_page_break()
        
        # 3. 按章节写入内容
        for section in content.get("sections", []):
            doc.add_heading(section["title"], level=section.get("level", 1))
            doc.add_paragraph(section["content"])
        
        # 4. 保存到临时文件
        filename = f"{project_name}_投标响应文件_{datetime.date.today()}.docx"
        tmp_path = f"/tmp/{filename}"
        doc.save(tmp_path)
        
        # 5. 上传OSS并获取下载链接
        auth = oss2.Auth(os.environ['OSS_ACCESS_KEY'], os.environ['OSS_SECRET_KEY'])
        bucket = oss2.Bucket(auth, os.environ['OSS_ENDPOINT'], os.environ['OSS_BUCKET'])
        oss_key = f"bid-documents/{uuid.uuid4()}/{filename}"
        bucket.put_object_from_file(oss_key, tmp_path)
        
        # 生成1小时有效的下载链接
        download_url = bucket.sign_url('GET', oss_key, 3600)
        
        return [TextContent(
            type="text",
            text=f"✅ Word文档已生成！\n文件名：{filename}\n下载链接（1小时有效）：{download_url}"
        )]

# pyproject.toml里的入口指向它
def main():
    import asyncio
    from mcp.server.stdio import stdio_server
    asyncio.run(stdio_server(app))

