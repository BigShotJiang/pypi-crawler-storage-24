"""
Quan ly thu muc Chrome profile duoi ~/.sora-tool/profiles/
"""
from __future__ import annotations

from pathlib import Path

from .constants import APP_DATA_DIR

PROFILES_DIR = APP_DATA_DIR / "profiles"


def get_profile_path(profile_id: str) -> Path:
    """Tra ve duong dan thu muc cua mot profile."""
    return PROFILES_DIR / profile_id


def ensure_profile_exists(profile_id: str) -> Path:
    """Tao thu muc profile neu chua ton tai, tra ve Path."""
    path = get_profile_path(profile_id)
    path.mkdir(parents=True, exist_ok=True)
    return path


def list_profile_dirs() -> list[Path]:
    """Liet ke tat ca thu muc profile da co."""
    if not PROFILES_DIR.exists():
        return []
    return sorted(p for p in PROFILES_DIR.iterdir() if p.is_dir())
