# sora_video_tool

Manage multiple isolated Chrome profiles and automate Sora video generation.

---

## Project structure

```
sora_video_tool/
├── main.py            # CLI entry point
├── config.py          # Global settings (URLs, paths, browser options)
├── profile_manager.py # Create / list persistent profile directories
├── browser_launcher.py# Launch Chromium with persistent contexts
├── sora_bot.py        # Automation logic (stubs – fill in when ready)
├── data_provider.py   # Mock prompt/image data source
├── requirements.txt
└── profiles/          # Auto-created; one sub-folder per profile
    ├── profile_1/
    ├── profile_2/
    └── ...
```

---

## 1 — Install dependencies

```bash
# (Recommended) create a virtual environment first
python -m venv .venv
source .venv/bin/activate        # macOS / Linux
# .venv\Scripts\activate         # Windows

# Install Python packages
pip install -r requirements.txt
```

## 2 — Install Playwright browsers

```bash
playwright install chromium
```

> Only Chromium is needed.  Run `playwright install` if you also want
> Firefox and WebKit.

---

## 3 — Run the tool

### Create + launch N profiles and navigate each to Sora

```bash
python main.py --profiles 3
```

This will:
1. Create `profiles/profile_1`, `profiles/profile_2`, `profiles/profile_3`
2. Open three Chromium windows simultaneously, each with its own profile
3. Navigate each window to `https://sora.com`

Log in to **Google** and **Sora** manually in each window.
Your session (cookies, tokens) is saved automatically inside the profile folder.
Close all windows when done — next time you run the tool, you will still be logged in.

---

### Other usage examples

```bash
# Create profiles without opening a browser
python main.py --profiles 3 --no-launch

# Open browsers but skip auto-navigation to Sora
python main.py --profiles 3 --no-sora

# Use the default (1 profile)
python main.py
```

---

## 4 — Adding automation later

1. Open `sora_bot.py` and implement the stub functions (`open_sora`,
   `upload_image`, `submit_prompt`, `create_video`).
2. Use `data_provider.py` → `get_next_job()` to feed prompts and images.
3. Call your bot from `main.py` after the browser context is created.

Each profile's `BrowserContext` is already authenticated — no extra login
logic is required once you have logged in manually.

---

## Configuration

Edit `config.py` to change:

| Setting               | Default         | Description                              |
|-----------------------|-----------------|------------------------------------------|
| `PROFILES_DIR`        | `./profiles`    | Where profile folders are stored         |
| `DEFAULT_PROFILE_COUNT` | `1`           | Profiles used when `--profiles` is omitted |
| `SORA_URL`            | `https://sora.com` | URL opened on launch                  |
| `BROWSER_HEADLESS`    | `False`         | Set `True` for headless / CI runs        |
| `BROWSER_CHANNEL`     | `"chromium"`    | `"chrome"` to use system Chrome          |
| `BROWSER_SLOW_MO`     | `0`             | ms delay between actions (for debugging) |
