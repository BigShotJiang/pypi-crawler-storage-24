"""
Hằng số toàn cục.  Không lưu thông tin nhạy cảm ở đây.
"""
from pathlib import Path
import sys

# ── App data directory (settings, profiles, logs) ─────────────────────────────
APP_DATA_DIR = Path.home() / ".sora-tool"

# ── API ────────────────────────────────────────────────────────────────────────
API_BASE_URL = "https://api.dsora.fun"  # TODO: thay bằng URL thật

# ── Automation ─────────────────────────────────────────────────────────────────
PRODUCTS_PER_PROFILE = 5
WAIT_BETWEEN_PRODUCTS_SEC = 600  # 10 phút

# ── Chrome ─────────────────────────────────────────────────────────────────────
CDP_PORT_BASE = 9222
CHROME_LAUNCH_TIMEOUT_SEC = 15

if sys.platform == "darwin":
    CHROME_BINARY = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
elif sys.platform == "win32":
    CHROME_BINARY = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
else:
    CHROME_BINARY = "/usr/bin/google-chrome"

# ── Sora ───────────────────────────────────────────────────────────────────────
SORA_URL = "https://sora.com"

# Selectors
SEL_TEXTAREA   = "textarea[placeholder='Describe your video...']"
SEL_FILE_INPUT = "input[type='file'][accept='image/jpeg,image/png,image/webp']"
SEL_CREATE_BTN = "button:has(span.sr-only:text('Create video'))"

# ── Assets ─────────────────────────────────────────────────────────────────────
DEFAULT_IMAGE_PATH = Path(__file__).parent / "assets" / "tshirt.png"

# ── Browser ────────────────────────────────────────────────────────────────────
BROWSER_SLOW_MO = 0
