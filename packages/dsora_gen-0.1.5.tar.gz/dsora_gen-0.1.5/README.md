# dsora-gen

Công cụ tự động tạo video Sora theo batch với nhiều Chrome profile, hỗ trợ thông báo Telegram và theo dõi tiến trình.

---

## Yêu cầu

- **Python 3.11+** — kiểm tra bằng `python3 --version`
- **Google Chrome** đã được cài đặt trên máy
- Tài khoản [Sora](https://sora.com) đã đăng ký và được cấp quyền

---

## Cài đặt

### Khuyến khích — dùng `pipx` (macOS)

[pipx](https://pipx.pypa.io) cài CLI tool vào môi trường **riêng biệt**, tránh xung đột với các package Python khác trên hệ thống. Đây là cách được khuyến khích nhất trên macOS.

```bash
# Cài pipx nếu chưa có
brew install pipx
pipx ensurepath

# Cài dsora-gen
pipx install dsora-gen
```

Sau đó dùng lệnh `dsg` bình thường ở bất kỳ đâu trong terminal.

---

### Cài bằng pip (thay thế)

**macOS / Linux:**
```bash
pip3 install dsora-gen
```

**Windows:**
```bash
pip install dsora-gen
```

> Nếu lệnh `dsg` không nhận sau khi cài bằng `pip3`, thêm dòng sau vào `~/.zshrc`:
> ```bash
> export PATH="$HOME/Library/Python/3.x/bin:$PATH"
> ```
> Thay `3.x` bằng phiên bản Python bạn đang dùng (ví dụ `3.11`), sau đó chạy `source ~/.zshrc`.

---

> Lần đầu chạy lệnh `dsg` bất kỳ, tool sẽ **tự động cài Playwright Chromium** — bạn không cần thêm bước nào.

---

## Hướng dẫn sử dụng

### Bước 1 — Thiết lập ban đầu

```bash
dsg setup
```

Tool sẽ hỏi lần lượt các thông tin sau:

| Thông tin | Bắt buộc | Mô tả |
|---|:---:|---|
| Số lượng profile | ✅ | Mỗi profile = 1 tài khoản Sora, xử lý tối đa 5 sản phẩm |
| Tên alias cho từng profile | ❌ | Tên gợi nhớ, ví dụ: `tai_khoan_1` |
| Username dsora | ✅ | Dùng để lấy danh sách sản phẩm từ API |
| Backend key | ✅ | Key xác thực để cập nhật trạng thái sản phẩm |
| Telegram Bot Token | ❌ | Nhận thông báo tự động qua Telegram |
| Telegram Channel ID | ❌ | ID kênh hoặc nhóm nhận thông báo |

Sau khi nhập xong, Chrome sẽ tự mở từng cửa sổ. Bạn cần thao tác thủ công trong mỗi cửa sổ:

1. Đăng nhập tài khoản **Google**
2. Truy cập [sora.com](https://sora.com) và **đăng nhập**
3. Đóng Chrome khi hoàn tất — session đăng nhập sẽ được lưu lại tự động

---

### Bước 2 — Chạy tự động

```bash
dsg run
```

Khi chạy, tool sẽ thực hiện tuần tự:

1. Gọi API lấy danh sách sản phẩm chưa xử lý (`GET /products/pending`)
2. Tính số profile cần dùng — nếu sản phẩm ít hơn capacity thì chỉ mở đúng số profile cần thiết
3. Với mỗi profile:
   - Mở Chrome sử dụng session đã đăng nhập
   - Lần lượt xử lý từng sản phẩm: điền prompt → upload ảnh → chọn cài đặt → tạo video
   - Sau mỗi sản phẩm: gọi API cập nhật trạng thái, gửi thông báo Telegram, chờ **10 phút**
   - Sau khi xử lý xong 5 sản phẩm: đóng Chrome, ghi log, gửi thông báo tổng kết profile
4. Hiển thị tổng kết toàn bộ khi hoàn tất

---

### Đăng nhập lại một profile

Dùng khi một profile bị đăng xuất khỏi Google hoặc Sora:

```bash
dsg setup --retry
```

Tool sẽ hiển thị danh sách profile hiện có, nhập số thứ tự để mở Chrome đăng nhập lại.

---

### Mở Chrome cho một profile cụ thể

```bash
dsg open <alias>

# Ví dụ:
dsg open tai_khoan_1
```

---

### Cập nhật lên phiên bản mới nhất

```bash
dsg update
```

Tool tự động nhận biết bạn cài qua `pipx` hay `pip` và chạy lệnh nâng cấp phù hợp.

---

### Xem danh sách lệnh

```bash
dsg help
dsg --help
```

---

## Dữ liệu lưu trữ

Toàn bộ dữ liệu lưu tại `~/.sora-tool/` — **không** nằm trong thư mục cài đặt Python:

| Đường dẫn | Nội dung |
|---|---|
| `~/.sora-tool/settings.json` | Cấu hình: username, backend key, telegram, danh sách profiles |
| `~/.sora-tool/run_log.json` | Lịch sử chạy từng profile theo ngày |
| `~/.sora-tool/profiles/profile_1/` | Chrome session & cookies của profile 1 |
| `~/.sora-tool/profiles/profile_N/` | Chrome session & cookies của profile N |

> ⚠️ **Không xóa thư mục `profiles/`** — đây là nơi lưu session đăng nhập. Nếu xóa, bạn phải đăng nhập lại toàn bộ.

---

## Gỡ lỗi thường gặp

**`dsg: command not found`**
> Thêm pip bin vào PATH. Trên macOS: thêm dòng sau vào `~/.zshrc` rồi chạy `source ~/.zshrc`:
> ```bash
> export PATH="$HOME/Library/Python/3.x/bin:$PATH"
> ```

**Chrome không khởi động được**
> Đảm bảo Google Chrome đã được cài tại đường dẫn mặc định:
> - macOS: `/Applications/Google Chrome.app/Contents/MacOS/Google Chrome`
> - Linux: `/usr/bin/google-chrome`
> - Windows: `C:\Program Files\Google\Chrome\Application\chrome.exe`

**Không tìm thấy nút tạo video / bị timeout**
> Profile có thể đã bị đăng xuất. Chạy `dsg setup --retry` để đăng nhập lại profile đó.

**API trả về lỗi 401**
> Backend key không hợp lệ hoặc đã hết hạn. Chạy `dsg setup` và nhập lại backend key mới.

**Lỗi `Only 3 jobs can run at a time`**
> Tool sẽ tự động chờ 5 phút rồi thử lại — không cần làm gì thêm.

---

## Phát hành phiên bản mới (dành cho developer)

```bash
# Bump version trong pyproject.toml và __init__.py, sau đó:
rm -rf dist/
python3 -m build
twine upload dist/*
```
