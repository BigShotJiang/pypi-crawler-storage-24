from typing import Callable, Optional
from abc import ABC

import numpy as np


class KernelBackendNumpy(ABC):
    def __init__(
        self,
        func: Callable,
        X: Optional[np.ndarray] = None,
        alpha: float = 1e-6,
        chunk_size: Optional[int] = None,
    ):
        super().__init__()

        self._X = X if X is not None else np.empty((0, 0))

        self.func = func
        self.alpha = alpha
        self.chunk_size = chunk_size

        self._full_K = None

    @property
    def X(self) -> np.ndarray:
        return self._X

    @property
    def N(self) -> int:
        return self.X.shape[0]

    def _get_full_matrix(self):
        if self._full_K is None:
            K = self.func(self.X, self.X)

            if self.alpha > 0:
                np.fill_diagonal(K, K.diagonal() + self.alpha)

            self._full_K = K

        return self._full_K

    def __getitem__(self, key):
        if self.chunk_size is None:
            return self._get_full_matrix()[key]

        if isinstance(key, tuple):
            row_idx, col_idx = key
            x_eval = np.atleast_2d(self.X[row_idx])
            y_eval = np.atleast_2d(self.X[col_idx])
            return self(x_eval, y_eval)

        x_eval = np.atleast_2d(self.X[key])
        return self(x_eval, self.X)

    def __call__(self, x: np.ndarray, y: Optional[np.ndarray] = None):
        n_x = x.shape[0]
        y_eval = y if y is not None else self.X
        n_y = y_eval.shape[0]

        if self.chunk_size is None:
            K = self.func(x, y_eval)
            if self.alpha > 0 and (y is None or x is y):
                np.fill_diagonal(K, K.diagonal() + self.alpha)
            return K

        chunk = self.chunk_size
        result = np.zeros((n_x, n_y), dtype=x.dtype)

        for i in range(0, n_x, chunk):
            end_i = min(i + chunk, n_x)
            x_chunk = x[i:end_i]

            for j in range(0, n_y, chunk):
                end_j = min(j + chunk, n_y)
                y_chunk = y_eval[j:end_j]

                K_block = self.func(x_chunk, y_chunk)

                if self.alpha > 0 and (y is None or x is y):
                    rel_start = max(i, j)
                    rel_end = min(end_i, end_j)

                    for k in range(rel_start, rel_end):
                        K_block[k - i, k - j] += self.alpha

                result[i:end_i, j:end_j] = K_block

        return result

    def __matmul__(self, v):
        v = np.asanyarray(v)
        if self.chunk_size is None:
            return self._get_full_matrix() @ v

        v_reshaped = v.reshape(self.N, -1)
        result = np.zeros((self.N, v_reshaped.shape[1]), dtype=self.X.dtype)
        chunk = self.chunk_size

        for i in range(0, self.N, chunk):
            end_i = min(i + chunk, self.N)
            x_chunk = self.X[i:end_i]

            for j in range(0, self.N, chunk):
                end_j = min(j + chunk, self.N)
                y_chunk = self.X[j:end_j]
                v_chunk = v_reshaped[j:end_j]

                K_block = self.func(x_chunk, y_chunk)
                result[i:end_i] += K_block @ v_chunk

        return result.reshape(v.shape) + self.alpha * v

    def apply_v(self, X: np.ndarray, v: np.ndarray) -> np.ndarray:
        v = np.asanyarray(v)
        n_new = X.shape[0]
        D_v = v.shape[1] if v.ndim > 1 else 1
        v_reshaped = v.reshape(self.N, D_v)

        result = np.zeros((n_new, D_v), dtype=X.dtype)
        chunk = self.chunk_size if self.chunk_size is not None else n_new

        for i in range(0, n_new, chunk):
            end_i = min(i + chunk, n_new)
            x_chunk = X[i:end_i]

            for j in range(0, self.N, chunk):
                end_j = min(j + chunk, self.N)
                y_chunk = self.X[j:end_j]
                v_chunk = v_reshaped[j:end_j]

                K_chunk = self.func(x_chunk, y_chunk)
                result[i:end_i] += K_chunk @ v_chunk

        if self.alpha > 0 and X is self.X:
            result += self.alpha * v_reshaped

        return result.reshape(-1, D_v) if v.ndim > 1 else result.ravel()

    def trace(self):
        if self.chunk_size is None:
            return float(np.trace(self._get_full_matrix()))

        trace_val = 0
        chunk = self.chunk_size

        for i in range(0, self.N, chunk):
            end = min(i + chunk, self.N)
            x_chunk = self.X[i:end]

            K_chunk_diag = self.func(x_chunk, x_chunk).diagonal()
            trace_val += np.sum(K_chunk_diag) + (end - i) * self.alpha

        return float(trace_val)

    def _normalize_idx(self, key, limit) -> np.ndarray:
        if isinstance(key, slice):
            return np.arange(*key.indices(limit))
        if isinstance(key, (int, np.integer)):
            return np.array([key if key >= 0 else limit + key])
        return np.asanyarray(key)
