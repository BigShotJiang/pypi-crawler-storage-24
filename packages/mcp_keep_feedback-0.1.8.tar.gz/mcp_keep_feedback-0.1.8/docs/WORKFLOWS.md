# GitHub Actions 工作流程說明

## 🏗️ 工作流程架構

### 發佈工作流程 (publish.yml)

**用途**: 版本管理與 PyPI 發佈

**觸發條件**: 手動觸發 (workflow_dispatch)

**功能**:
- 版本號管理（自動或自訂）
- 發佈至 PyPI
- 建立 GitHub Release

## 🚀 發佈新版本

1. 在 GitHub Actions 頁面執行 "Auto Release to PyPI"
2. 選擇發佈選項（如 `version_type`: patch/minor/major）
3. 發佈後驗證：`uvx mcp-keep-feedback@latest`

## 🔧 故障排除

- **版本衝突**: 確認 PyPI 上尚無相同版本
- **權限**: 確認 `PYPI_API_TOKEN` 等密鑰已正確設定
