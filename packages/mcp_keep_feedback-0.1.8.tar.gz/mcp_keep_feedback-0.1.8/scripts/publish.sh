#!/bin/bash
# PyPI 发布脚本
# 使用方法:
#   ./scripts/publish.sh [--test]              使用当前版本发布
#   ./scripts/publish.sh VERSION [--test]      先更新版本号到 VERSION，再发布（会确认）
# 示例: ./scripts/publish.sh 0.1.5
#       ./scripts/publish.sh 0.1.5 --test

set -e  # 遇到错误立即退出

# 获取脚本所在目录的项目根目录
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
cd "$PROJECT_ROOT"

# 加载 .env 文件
load_env() {
    local env_file="$PROJECT_ROOT/.env"
    if [ -f "$env_file" ]; then
        set -a
        source "$env_file"
        set +a
    fi
}

# 加载环境变量
load_env

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# 打印带颜色的消息
print_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# 检查环境变量
check_token() {
    if [ -z "$PYPI_TOKEN" ]; then
        print_error "PYPI_TOKEN 环境变量未设置"
        print_info "请在 .env 文件中设置: PYPI_TOKEN=pypi-xxx"
        print_info "或设置环境变量: export PYPI_TOKEN='pypi-xxx'"
        exit 1
    fi
}

# 获取版本号
get_version() {
    grep -Po '(?<=^version = ")[^"]*' pyproject.toml || echo "unknown"
}

# 交互确认，提示信息 $1，默认 N；确认返回 0，否则 1
confirm_yn() {
    local prompt="$1"
    echo -e "${YELLOW}${prompt} [y/N]${NC}"
    read -r ans
    case "$ans" in
        [yY]|[yY][eE][sS]) return 0 ;;
        *) return 1 ;;
    esac
}

# 将 pyproject.toml 和 __init__.py 中的版本号改为 $1，并生成发布用 commit
update_version() {
    local new_ver="$1"
    print_info "正在将版本号更新为 ${new_ver} ..."
    sed -i "s/^version = \"[^\"]*\"/version = \"${new_ver}\"/" pyproject.toml
    sed -i "s/^__version__ = \"[^\"]*\"/__version__ = \"${new_ver}\"/" src/mcp_keep_feedback/__init__.py
    print_success "已更新 pyproject.toml 与 src/mcp_keep_feedback/__init__.py"
    print_info "正在生成发布 commit ..."
    git add pyproject.toml src/mcp_keep_feedback/__init__.py
    git commit -m "mod: 发布版本 ${new_ver}"
    print_success "已提交: mod: 发布版本 ${new_ver}"
}

# 清理旧的构建产物
clean_build() {
    print_info "清理旧的构建产物..."
    rm -rf build/ dist/ *.egg-info src/*.egg-info
    print_success "清理完成"
}

# 构建分发包
build_package() {
    print_info "构建分发包..."
    uv build
    print_success "构建完成"
    
    # 显示构建产物
    echo ""
    print_info "构建产物:"
    ls -lh dist/
    echo ""
}

# 上传到 PyPI（调用前应由调用方完成确认）
upload_pypi() {
    local test_mode=$1
    
    print_info "上传到 PyPI..."
    
    if [ "$test_mode" = true ]; then
        print_warning "测试模式：上传到 TestPyPI"
        uv run twine upload dist/* -u __token__ -p "$PYPI_TOKEN" --repository testpypi
    else
        uv run twine upload dist/* -u __token__ -p "$PYPI_TOKEN"
    fi
    
    local version=$(get_version)
    
    echo ""
    print_success "发布成功！"
    echo ""
    
    if [ "$test_mode" = true ]; then
        echo -e "🌐 TestPyPI 地址: ${GREEN}https://test.pypi.org/project/mcp-keep-feedback/${version}/${NC}"
    else
        echo -e "🌐 PyPI 地址: ${GREEN}https://pypi.org/project/mcp-keep-feedback/${version}/${NC}"
    fi
    echo ""
}

# 主流程
main() {
    local test_mode=false
    local new_version=""
    
    # 解析参数：第一个非 --test 的参数若形如 x.y.z 则视为版本号
    while [ -n "$1" ]; do
        if [ "$1" = "--test" ]; then
            test_mode=true
        elif [[ "$1" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
            new_version="$1"
        fi
        shift
    done
    
    echo ""
    echo "========================================"
    echo "  PyPI 发布脚本"
    echo "========================================"
    echo ""
    
    local version=$(get_version)
    print_info "当前版本: v${version}"
    
    if [ -n "$new_version" ]; then
        echo ""
        if ! confirm_yn "将把版本从 v${version} 更新为 v${new_version}，并随后执行构建与发布。确认？"; then
            print_warning "已取消"
            exit 0
        fi
        update_version "$new_version"
        version="$new_version"
        echo ""
    fi
    
    echo ""
    
    # 检查环境
    check_token
    
    if ! confirm_yn "确认上传当前版本 v${version} 到 PyPI？"; then
        print_warning "已取消上传"
        exit 0
    fi
    echo ""
    
    # 清理
    clean_build
    
    # 构建
    build_package
    
    # 上传
    upload_pypi $test_mode
}

# 执行主流程
main "$@"
