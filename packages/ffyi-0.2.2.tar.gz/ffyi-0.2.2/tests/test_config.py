from pathlib import Path

from fyi.config import (
    BASE_URL,
    CONFIG_DIR,
    TOKEN_PATH,
    load_token,
    save_token,
)


def test_load_defaults_when_missing(tmp_path, monkeypatch):
    monkeypatch.setattr("fyi.config.CONFIG_DIR", tmp_path / "cfg")
    monkeypatch.setattr("fyi.config.TOKEN_PATH", tmp_path / "cfg" / "token")

    assert load_token() is None


def test_save_and_load_round_trip(tmp_path, monkeypatch):
    config_dir = tmp_path / "cfg"
    token_path = config_dir / "token"
    monkeypatch.setattr("fyi.config.CONFIG_DIR", config_dir)
    monkeypatch.setattr("fyi.config.TOKEN_PATH", token_path)

    save_token("fyi_abc")

    assert load_token() == "fyi_abc"


def test_config_constants():
    assert isinstance(CONFIG_DIR, Path)
    assert isinstance(TOKEN_PATH, Path)
    assert BASE_URL == "https://friends.fyi"
