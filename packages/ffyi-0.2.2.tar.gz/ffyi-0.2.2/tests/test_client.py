import httpx
import pytest

from fyi.client import FyiClient


class DummyClient(FyiClient):
    def __init__(self):
        super().__init__(api_key="fyi_test")
        self.calls: list[dict[str, object]] = []

    def _request(self, method, path, *, content=None, json=None, headers=None, authenticated=True):  # noqa: A003
        self.calls.append(
            {
                "method": method,
                "path": path,
                "content": content,
                "json": json,
                "headers": headers,
                "authenticated": authenticated,
            }
        )
        return {"ok": True}


def test_send_plain_message():
    client = DummyClient()
    client.send("alice", body="hi")

    call = client.calls[0]
    assert call["method"] == "POST"
    assert call["path"] == "/inbox/alice"
    assert call["content"] == b"hi"
    assert call["headers"] == {"Content-Type": "text/plain"}


def test_send_with_idempotency_header():
    client = DummyClient()
    client.send("alice", body='{"x":1}', content_type="application/json", idempotency_key="abc123")

    call = client.calls[0]
    assert call["headers"] == {
        "Content-Type": "application/json",
        "Idempotency-Key": "abc123",
    }


def test_inbox_query_string():
    client = DummyClient()
    client.inbox(limit=5, offset=10, sender="deploy bot", user_agent="fyi-cli", type="release")
    call = client.calls[0]
    assert call["path"] == "/inbox?limit=5&offset=10&sender=deploy+bot&user_agent=fyi-cli&type=release"


def test_send_can_be_unauthenticated():
    client = DummyClient()
    client.send("alice", body="hello", authenticated=False)
    call = client.calls[0]
    assert call["authenticated"] is False


def test_headers_include_api_key():
    client = FyiClient(api_key="fyi_abc")
    headers = client._headers()
    assert headers["Authorization"] == "Bearer fyi_abc"
    assert headers["User-Agent"] == "fyi-cli"


def test_authenticated_headers_require_api_key():
    client = FyiClient(api_key=None)
    with pytest.raises(ValueError, match="api_key is required"):
        client._headers()


def test_request_raises_on_http_error(monkeypatch):
    client = FyiClient(api_key="fyi_abc")

    class FakeResponse:
        content = b""

        def raise_for_status(self):
            raise httpx.HTTPStatusError(
                "bad",
                request=httpx.Request("GET", "https://x"),
                response=httpx.Response(500),
            )

    class FakeHttpxClient:
        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc, tb):
            return False

        def request(self, *args, **kwargs):
            return FakeResponse()

    monkeypatch.setattr(httpx, "Client", lambda *a, **k: FakeHttpxClient())

    try:
        client.whoami()
        assert False, "Expected HTTPStatusError"
    except httpx.HTTPStatusError:
        pass
