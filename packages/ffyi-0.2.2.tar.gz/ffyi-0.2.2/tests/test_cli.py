from typer.testing import CliRunner

from fyi import cli


runner = CliRunner()


class StubClient:
    def __init__(self, *args, **kwargs):
        pass

    def whoami(self):
        return {"user": {"username": "wil", "github_username": "wil"}}

    def send(self, *args, **kwargs):
        return {"id": "msg_1"}

    def inbox(self, *args, **kwargs):
        return {"items": [], "total": 0}

    def inbox_item(self, *args, **kwargs):
        return {"id": "msg_1"}


def test_auth_stores_token(monkeypatch):
    stored: dict[str, str] = {}
    monkeypatch.setattr(cli, "save_token", lambda token: stored.setdefault("token", token))

    result = runner.invoke(cli.app, ["auth", "fyi_abc"])
    assert result.exit_code == 0
    assert stored["token"] == "fyi_abc"


def test_whoami(monkeypatch):
    monkeypatch.setattr(cli, "FyiClient", StubClient)
    monkeypatch.setattr(cli, "load_token", lambda: "fyi_stub")

    result = runner.invoke(cli.app, ["whoami", "--json"])
    assert result.exit_code == 0
    assert "wil" in result.output


def test_send_requires_message_or_payload(monkeypatch):
    monkeypatch.setattr(cli, "FyiClient", StubClient)
    monkeypatch.setattr(cli, "load_token", lambda: "fyi_stub")

    result = runner.invoke(cli.app, ["send", "friend"])
    assert result.exit_code != 0
    assert "Provide a message argument or pipe via stdin" in result.output


def test_send_supports_curl_style_headers_and_no_auth(monkeypatch):
    captured: dict[str, object] = {}

    class RecorderClient:
        def __init__(self, *args, **kwargs):
            captured["init"] = kwargs

        def send(self, username, **kwargs):
            captured["username"] = username
            captured["send"] = kwargs
            return {"id": "msg_1"}

    monkeypatch.setattr(cli, "FyiClient", RecorderClient)
    monkeypatch.setattr(cli, "load_token", lambda: None)

    result = runner.invoke(
        cli.app,
        [
            "send",
            "alice",
            '{"event":"deploy"}',
            "--type",
            "alert",
            "--header",
            "X-Env: prod",
            "--no-auth",
        ],
    )
    assert result.exit_code == 0
    assert captured["init"] == {"api_key": None}
    assert captured["username"] == "alice"
    assert captured["send"] == {
        "body": '{"event":"deploy"}',
        "content_type": "application/json",
        "sender": None,
        "idempotency_key": None,
        "headers": {"X-Env": "prod", "X-Type": "alert"},
        "authenticated": False,
    }


def test_send_rejects_invalid_header(monkeypatch):
    monkeypatch.setattr(cli, "FyiClient", StubClient)
    monkeypatch.setattr(cli, "load_token", lambda: "fyi_stub")

    result = runner.invoke(cli.app, ["send", "alice", "hello", "--header", "invalid"])
    assert result.exit_code != 0
    assert "Invalid --header value" in result.output


def test_no_keys_commands():
    result = runner.invoke(cli.app, ["keys", "--help"])
    assert result.exit_code != 0


def test_inbox_single_item(monkeypatch):
    monkeypatch.setattr(cli, "FyiClient", StubClient)
    monkeypatch.setattr(cli, "load_token", lambda: "fyi_stub")

    result = runner.invoke(cli.app, ["inbox", "msg_1", "--json"])
    assert result.exit_code == 0
    assert "msg_1" in result.output
