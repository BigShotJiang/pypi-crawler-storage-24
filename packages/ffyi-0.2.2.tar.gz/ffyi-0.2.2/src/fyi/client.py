from __future__ import annotations

from typing import Any
from urllib.parse import urlencode

import httpx

from .config import BASE_URL


class FyiClient:
    def __init__(self, *, api_key: str | None = None, timeout: float = 20.0) -> None:
        self.api_key = api_key
        self.base_url = BASE_URL
        self.timeout = timeout

    def _headers(self, extra: dict[str, str] | None = None, *, authenticated: bool = True) -> dict[str, str]:
        headers: dict[str, str] = {"User-Agent": "fyi-cli"}

        if authenticated:
            if not self.api_key:
                raise ValueError("api_key is required for authenticated requests")
            headers["Authorization"] = f"Bearer {self.api_key}"

        if extra:
            headers.update(extra)
        return headers

    def _request(
        self,
        method: str,
        path: str,
        *,
        content: bytes | None = None,
        json: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
        authenticated: bool = True,
    ) -> Any:
        url = f"{self.base_url}{path}"
        with httpx.Client(timeout=self.timeout) as client:
            response = client.request(
                method,
                url,
                content=content,
                json=json,
                headers=self._headers(headers, authenticated=authenticated),
            )
        response.raise_for_status()
        if response.content:
            return response.json()
        return None

    def send(
        self,
        username: str,
        *,
        body: str,
        content_type: str = "text/plain",
        sender: str | None = None,
        idempotency_key: str | None = None,
        headers: dict[str, str] | None = None,
        authenticated: bool = True,
    ) -> dict[str, Any]:
        request_headers: dict[str, str] = {"Content-Type": content_type}
        if sender:
            request_headers["Sender"] = sender
        if idempotency_key:
            request_headers["Idempotency-Key"] = idempotency_key
        if headers:
            request_headers.update(headers)
        return self._request(
            "POST",
            f"/inbox/{username}",
            content=body.encode(),
            headers=request_headers,
            authenticated=authenticated,
        )

    def inbox(
        self,
        *,
        limit: int = 50,
        offset: int = 0,
        sender: str | None = None,
        user_agent: str | None = None,
        type: str | None = None,
    ) -> dict[str, Any]:
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if sender:
            params["sender"] = sender
        if user_agent:
            params["user_agent"] = user_agent
        if type:
            params["type"] = type
        query = urlencode(params)
        return self._request("GET", f"/inbox?{query}")

    def inbox_item(self, item_id: str) -> dict[str, Any]:
        return self._request("GET", f"/inbox/{item_id}")

    def whoami(self) -> dict[str, Any]:
        return self._request("GET", "/api/me")
