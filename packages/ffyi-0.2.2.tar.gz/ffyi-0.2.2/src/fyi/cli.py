from __future__ import annotations

import json
import sys
from datetime import datetime, timezone
from typing import Any

import typer

import httpx

from .client import FyiClient
from .config import load_token, save_token

app = typer.Typer(help="friends.fyi CLI")

HIDDEN_HEADER_NAMES = {
    "authorization",
    "cf-connecting-ip",
    "cf-ray",
    "forwarded",
    "host",
    "x-forwarded-for",
    "x-forwarded-host",
    "x-forwarded-port",
    "x-forwarded-proto",
    "x-real-ip",
    "x-request-start",
}
HIDDEN_HEADER_PREFIXES = (
    "_",
    "x-railway-",
)


def _resolve_client(
    *,
    api_key: str | None = None,
    require_token: bool = True,
) -> FyiClient:
    resolved_key = api_key or load_token()
    if require_token and not resolved_key:
        raise typer.BadParameter("No token found. Run `fyi auth <TOKEN>` first.")
    return FyiClient(api_key=resolved_key)


def _handle_http_error(error: httpx.HTTPStatusError) -> None:
    status = error.response.status_code
    try:
        detail = error.response.json().get("detail", error.response.text)
    except Exception:
        detail = error.response.text
    typer.echo(f"Error {status}: {detail}", err=True)
    raise typer.Exit(code=1)


def _print_json(value: Any) -> None:
    typer.echo(json.dumps(value, indent=2, sort_keys=True, default=str))


def _sanitize_headers_for_display(headers: dict[str, Any]) -> dict[str, Any]:
    visible: dict[str, Any] = {}
    for key, value in headers.items():
        normalized = key.strip().lower()
        if normalized in HIDDEN_HEADER_NAMES:
            continue
        if any(normalized.startswith(prefix) for prefix in HIDDEN_HEADER_PREFIXES):
            continue
        visible[normalized] = value
    return visible


def _parse_extra_headers(values: list[str] | None) -> dict[str, str]:
    parsed: dict[str, str] = {}
    for raw in values or []:
        if ":" not in raw:
            raise typer.BadParameter("Invalid --header value. Use 'Name: Value'.")
        name, value = raw.split(":", 1)
        header_name = name.strip()
        if not header_name:
            raise typer.BadParameter("Invalid --header value. Header name cannot be empty.")
        parsed[header_name] = value.strip()
    return parsed


def _infer_content_type(body: str) -> str:
    try:
        json.loads(body)
        return "application/json"
    except (json.JSONDecodeError, ValueError):
        return "text/plain"


def _time_ago(iso: str) -> str:
    try:
        then = datetime.fromisoformat(iso.replace("Z", "+00:00"))
        now = datetime.now(timezone.utc)
        seconds = int((now - then).total_seconds())
        if seconds < 60:
            return "just now"
        minutes = seconds // 60
        if minutes < 60:
            return f"{minutes}m ago"
        hours = minutes // 60
        if hours < 24:
            return f"{hours}h ago"
        days = hours // 24
        return f"{days}d ago"
    except Exception:
        return iso


@app.command()
def auth(
    token: str = typer.Argument(..., help="Your friends.fyi API token"),
) -> None:
    """Store your API token."""
    save_token(token)
    typer.echo("Token saved to ~/.config/fyi/token")


@app.command()
def whoami(
    api_key: str | None = typer.Option(None, "--api-key", help="Override API key"),
    json_output: bool = typer.Option(False, "--json", help="JSON output"),
) -> None:
    """Show current authenticated user."""
    client = _resolve_client(api_key=api_key)
    try:
        me = client.whoami()
    except httpx.HTTPStatusError as e:
        _handle_http_error(e)
    if json_output:
        _print_json(me)
    else:
        user = me.get("user", {})
        typer.echo(f"{user.get('username')} ({user.get('github_username')})")


@app.command()
def send(
    username: str = typer.Argument(..., help="Recipient username"),
    message: str | None = typer.Argument(None, help="Raw request body (or pipe via stdin)"),
    sender: str | None = typer.Option(None, "--sender", "-s", help="Sender display name"),
    type: str | None = typer.Option(None, "--type", "-t", help="Set X-Type header"),
    content_type: str | None = typer.Option(None, "--content-type", help="Force Content-Type"),
    header: list[str] | None = typer.Option(None, "--header", "-H", help="Extra header, e.g. -H 'X-Env: prod'"),
    idempotency_key: str | None = typer.Option(None, "--idempotency-key", "-k", help="Idempotency key"),
    no_auth: bool = typer.Option(False, "--no-auth", help="Send without Authorization header"),
    api_key: str | None = typer.Option(None, "--api-key", help="Override API key"),
    json_output: bool = typer.Option(False, "--json", help="JSON output"),
) -> None:
    """Send a message to someone's inbox (curl-style)."""
    client = _resolve_client(api_key=api_key, require_token=not no_auth)

    body: str

    if message is not None:
        body = message
    elif not sys.stdin.isatty():
        body = sys.stdin.read()
        if not body.strip():
            raise typer.BadParameter("Provide a message argument or pipe via stdin")
    else:
        raise typer.BadParameter("Provide a message argument or pipe via stdin")

    resolved_content_type = content_type or _infer_content_type(body)
    extra_headers = _parse_extra_headers(header)
    if type:
        extra_headers["X-Type"] = type

    try:
        result = client.send(
            username,
            body=body,
            content_type=resolved_content_type,
            sender=sender,
            idempotency_key=idempotency_key,
            headers=extra_headers or None,
            authenticated=not no_auth,
        )
    except httpx.HTTPStatusError as e:
        _handle_http_error(e)
    if json_output:
        _print_json(result)
    else:
        typer.echo(f"Sent to {username} (id: {result.get('id', 'unknown')})")


@app.command(name="inbox")
def inbox_list(
    item_id: str | None = typer.Argument(None, help="Message ID to read"),
    limit: int = typer.Option(20, "--limit", "-n", min=1, max=200, help="Number of messages"),
    offset: int = typer.Option(0, "--offset", min=0, help="Skip N messages"),
    count: bool = typer.Option(False, "--count", "-c", help="Show only total count"),
    sender: str | None = typer.Option(None, "--sender", help="Filter by sender"),
    user_agent: str | None = typer.Option(None, "--user-agent", help="Filter by user-agent"),
    type: str | None = typer.Option(None, "--type", "-t", help="Filter by X-Type"),
    api_key: str | None = typer.Option(None, "--api-key", help="Override API key"),
    json_output: bool = typer.Option(False, "--json", help="JSON output"),
) -> None:
    """List inbox messages, or read a specific one by ID."""
    client = _resolve_client(api_key=api_key)

    if item_id is not None:
        try:
            result = client.inbox_item(item_id)
        except httpx.HTTPStatusError as e:
            _handle_http_error(e)
        if json_output:
            _print_json(result)
        else:
            _print_item_detail(result)
        return

    try:
        result = client.inbox(limit=limit, offset=offset, sender=sender, user_agent=user_agent, type=type)
    except httpx.HTTPStatusError as e:
        _handle_http_error(e)

    if json_output:
        _print_json(result)
        return

    total = result.get("total", 0)

    if count:
        typer.echo(total)
        return

    items = result.get("items", [])
    if not items:
        typer.echo("No messages.")
        return

    typer.echo(f"Showing {len(items)} of {total} messages\n")

    for item in items:
        item_id_short = item.get("id", "")[:8]
        sender_display = item.get("sender") or item.get("user_agent") or "unknown"
        age = _time_ago(item.get("created_at", ""))
        x_type = (item.get("headers") or {}).get("x-type", "")
        type_tag = f"  [{x_type}]" if x_type else ""

        body = item.get("body") or ""
        body_preview = body[:80].replace("\n", " ")
        if len(body) > 80:
            body_preview += "..."

        typer.echo(f"{item_id_short}  {age:>10}  {sender_display}{type_tag}")
        if body_preview:
            typer.echo(f"          {body_preview}")
        typer.echo("")


def _print_item_detail(item: dict[str, Any]) -> None:
    typer.echo(f"ID:      {item.get('id')}")
    typer.echo(f"Sender:  {item.get('sender') or item.get('user_agent') or 'unknown'}")
    typer.echo(f"Method:  {item.get('method')} {item.get('path')}")
    typer.echo(f"Time:    {item.get('created_at')}")

    x_type = (item.get("headers") or {}).get("x-type")
    if x_type:
        typer.echo(f"Type:    {x_type}")

    if item.get("idempotency_key"):
        typer.echo(f"Idemp:   {item['idempotency_key']}")

    body = item.get("body")
    if body:
        typer.echo("\n--- Body ---")
        try:
            parsed = json.loads(body)
            typer.echo(json.dumps(parsed, indent=2))
        except (json.JSONDecodeError, ValueError):
            typer.echo(body)

    headers = item.get("headers", {})
    display_headers = _sanitize_headers_for_display(headers)
    if display_headers:
        typer.echo("\n--- Headers ---")
        for key, value in display_headers.items():
            typer.echo(f"{key}: {value}")


def main() -> None:
    app()


if __name__ == "__main__":
    main()
