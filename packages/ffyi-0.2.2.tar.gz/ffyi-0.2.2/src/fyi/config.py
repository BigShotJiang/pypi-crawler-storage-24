from __future__ import annotations

from pathlib import Path

CONFIG_DIR = Path.home() / ".config" / "fyi"
TOKEN_PATH = CONFIG_DIR / "token"

BASE_URL = "https://friends.fyi"


def load_token() -> str | None:
    if TOKEN_PATH.exists():
        return TOKEN_PATH.read_text().strip() or None
    return None


def save_token(token: str) -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    TOKEN_PATH.write_text(token.strip())
    TOKEN_PATH.chmod(0o600)
