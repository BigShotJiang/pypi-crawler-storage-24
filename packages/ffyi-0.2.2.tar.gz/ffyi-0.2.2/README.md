# ffyi

CLI for [friends.fyi](https://friends.fyi).

## Install

```bash
uv tool install ffyi
```

Installed commands: `ffyi` and `fyi` (alias).

## CLI usage

```bash
fyi auth <token>
fyi whoami
fyi send alice "hello"
echo '{"status":"ok"}' | fyi send alice --sender "Deploy Bot"
fyi send alice '{"status":"ok"}' --type alert -H "X-Env: prod"
fyi send alice "anonymous ping" --no-auth
fyi inbox
fyi inbox --sender "Deploy Bot" --user-agent fyi-cli --type alert
fyi inbox --json
```
