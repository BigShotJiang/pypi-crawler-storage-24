/*
 * Wrapper around a NumPy ndarray.
 *
 * Author: Malte J. Ziebarth (malte.ziebarth@tum.de)
 *
 * Copyright (C) 2026 Technische Universität München
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 *
 *    1. Redistributions of source code must retain the above copyright notice, this
 *       list of conditions and the following disclaimer.
 *    2. Redistributions in binary form must reproduce the above copyright notice,
 *       this list of conditions and the following disclaimer in the documentation
 *       and/or other materials provided with the distribution.
 *    3. Neither the name of the copyright holder nor the names of its contributors
 *       may be used to endorse or promote products derived from this software
 *       without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * SPDX-FileCopyrightText: 2026 Technical University of Munich
 * SPDX-License-Identifier: BSD-3-Clause
 * SPDX-FileContributor: Malte J. Ziebarth <malte.ziebarth@tum.de>
 */

#ifndef FUNKTIONSKLEMPNER_NDARRAY_HPP
#define FUNKTIONSKLEMPNER_NDARRAY_HPP

#include <funktionsklempner/numpytypes.hpp>

#include <ranges>
#include <string>

namespace funktionsklempner {



namespace ndarray {

template<NumPyDType T, bool bounds_check=true>
class NDArray
{
public:
    constexpr NDArray(T* data, size_t N, const char* dtype)
       : data(data), N(N)
    {
        if (!data)
            throw std::runtime_error(
                "Initialized NDArray with an empty buffer."
            );

        /* Then make sure that the information passed from the
         * Python side with regards to the data type adds up:
         */
        validate_dtype<std::decay_t<T>>(dtype);
    }

    constexpr NDArray(NDArray&&) noexcept = default;
    constexpr NDArray(const NDArray&) noexcept = default;

    constexpr size_t size() const noexcept
    {
        return N;
    }

    constexpr T* begin() const noexcept
    {
        return data;
    }

    constexpr T* end() const noexcept
    {
        return data + N;
    }


    constexpr T& operator[](size_t i) const
    {
        if constexpr (bounds_check){
            if (i >= N){
                std::string msg(
                    "Tried to access element outside bounds ("
                    "index "
                );
                msg += std::to_string(i);
                msg += " for NDArray with size ";
                msg += std::to_string(N);
                msg += ").";
                throw std::runtime_error(msg);
            }
        }
        return data[i];
    }

private:
    T* data;
    size_t N;
};

} // namespace ndarray


/*
 * Specialize the NDArray for input and output.
 * This allows specifying input and output arguments
 * via type names.
 *
 * InputNDArray: for input to the C++ world from the Python world
 *               (i.e. just read access in C++).
 * OutputNDArray: for output from the C++ world to the Python world
 *                (i.e. read and write access in C++).
 */
template<NonConstNumPyDType T>
using InputNDArray = ndarray::NDArray<const T>;

template<NonConstNumPyDType T>
using OutputNDArray = ndarray::NDArray<T>;

}

#endif