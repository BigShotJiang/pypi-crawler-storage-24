# A hack to get the subproject wrappers out of the
# subprojects directory.
#
# Author: Malte J. Ziebarth (malte.ziebarth@tum.de)
#
# Copyright (C) 2026 Technische Universität München
#
# Licensed under the EUPL, Version 1.2 or – as soon they will be approved by
# the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
#
# https://joinup.ec.europa.eu/collection/eupl/eupl-text-eupl-12
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the Licence is distributed on an "AS IS" basis,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and
# limitations under the Licence.
#
# SPDX-FileCopyrightText: 2026 Technical University of Munich
# SPDX-License-Identifier: EUPL-1.2
# SPDX-FileContributor: Malte J. Ziebarth <malte.ziebarth@tum.de>


from sys import argv
from pathlib import Path
from shutil import copyfile
from itertools import islice

# Parse the relative input directory path:
inpath_rel = argv[1].split('/')

# Compose the absolute input directory path based on the
# script location:
scriptpath = Path(argv[0])
inpath = scriptpath.parent / inpath_rel[0]
for s in islice(inpath_rel, 1, None):
    inpath /= s

# Compose the output path(s). This will also
# tell us the output name:
for o in islice(argv, 2, None):
    outpath = Path(o)
    # Check if outpath ends in '.XY', where XY is a number.
    # This is a hack to circumvent the colliding target restriction
    # of Meson.
    if outpath.name.split('.')[-1].isnumeric():
        infile = ".".join(outpath.name.split('.')[:-1])
    else:
        infile = outpath.name
    copyfile(inpath / infile, outpath)