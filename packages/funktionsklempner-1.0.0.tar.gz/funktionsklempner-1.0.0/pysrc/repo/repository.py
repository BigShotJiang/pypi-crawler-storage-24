# Reflection of a code repository.
#
# Author: Malte J. Ziebarth (malte.ziebarth@tum.de)
#
# Copyright (C) 2025 Technische Universität München
#
# Licensed under the EUPL, Version 1.2 or – as soon they will be approved by
# the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
#
# https://joinup.ec.europa.eu/collection/eupl/eupl-text-eupl-12
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the Licence is distributed on an "AS IS" basis,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and
# limitations under the Licence.
#
# SPDX-FileCopyrightText: 2025 Technical University of Munich
# SPDX-License-Identifier: EUPL-1.2
# SPDX-FileContributor: Malte J. Ziebarth <malte.ziebarth@tum.de>

from pathlib import Path
from .paths import RelativePath


class Repository:
    """
    Reflection of the relevant parts of a repository.
    """
    root: Path
    python_package_root: RelativePath
    package_name: str

    def __init__(self,
            root: Path,
            python_package_root: RelativePath,
            package_name: str
        ):
        assert isinstance(root, Path)
        assert isinstance(python_package_root, RelativePath)
        assert python_package_root.is_relative_to(root)
        assert isinstance(package_name, str)
        self.root = root
        self.python_package_root = python_package_root
        self.package_name = package_name