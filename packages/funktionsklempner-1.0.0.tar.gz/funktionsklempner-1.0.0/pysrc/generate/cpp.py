# Generate C++ wrapper codes.
#
# Author: Malte J. Ziebarth (malte.ziebarth@tum.de)
#
# Copyright (C) 2025-2026 Technische Universität München
#
# Licensed under the EUPL, Version 1.2 or – as soon they will be approved by
# the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
#
# https://joinup.ec.europa.eu/collection/eupl/eupl-text-eupl-12
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the Licence is distributed on an "AS IS" basis,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and
# limitations under the Licence.
#
# SPDX-FileCopyrightText: 2025 Technical University of Munich
# SPDX-License-Identifier: EUPL-1.2
# SPDX-FileContributor: Malte J. Ziebarth <malte.ziebarth@tum.de>

from typing import Iterable
from ..wrap.library import WrappedLibrary
from .boilerplate import generate_boilerplate
from ..repo import include_statement


def generate_cpp_source(
        lib: WrappedLibrary
    ) -> Iterable[str]:
    """
    Writes the C++ source.
    """
    # Boilerplate:
    yield from generate_boilerplate(lib, 80, 'C++')

    yield (
        "/* For error handling: */\n"
        "#include <funktionsklempner/strings.hpp>\n\n"
        "#include <funktionsklempner/call.hpp>\n\n"
       f"{include_statement(lib.wrapper_include(), delimiter='""')}\n\n"
    )

    for f in lib.functions:
        yield from f.compose_cpp_body()


def generate_cpp_header(
        lib: WrappedLibrary
    ) -> Iterable[str]:
    """
    Writes the C++ header.
    """
    # Boilerplate:
    yield from generate_boilerplate(lib, 80, 'C++')
    yield "\n"

    includeguard = (
        f"{"_".join(lib.module()).upper()}_HPP"
    )
    yield (
       f"#ifndef {includeguard}\n#define {includeguard}\n\n"
        "/* For uint64_t and the like: */\n"
        "#include <cstdint>\n\n"
        "\n"
        "\n"
       f"{include_statement(lib.header_include(), '""')}\n"
        "\n"
        'extern "C" {\n'
        "\n"
        "\n"
    )

    for f in lib.functions:
        yield from f.compose_cpp_head(True)
        yield "\n"

    yield (
        "\n"
        "\n"
        "}\n"
        "\n"
        "#endif\n"
    )