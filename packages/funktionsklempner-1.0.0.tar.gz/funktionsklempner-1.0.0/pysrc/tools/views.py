# Join view.
#
# Author: Malte J. Ziebarth (malte.ziebarth@tum.de)
#
# Copyright (C) 2026 Technische Universität München
#
# Licensed under the EUPL, Version 1.2 or – as soon they will be approved by
# the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
#
# https://joinup.ec.europa.eu/collection/eupl/eupl-text-eupl-12
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the Licence is distributed on an "AS IS" basis,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and
# limitations under the Licence.
#
# SPDX-FileCopyrightText: 2026 Technical University of Munich
# SPDX-License-Identifier: EUPL-1.2
# SPDX-FileContributor: Malte J. Ziebarth <malte.ziebarth@tum.de>

from typing import Iterable

def join(strings: Iterable[str], delimiter: str) -> Iterable[str]:
    """
    Similar to `delimiter.join(strings)`, but as an iterable
    over the unjoined components of that resulting string.
    """
    it = strings.__iter__()
    try:
        yield it.__next__()
        while True:
            next = it.__next__()
            yield delimiter
            yield next
    except StopIteration:
        pass


def prepend(
        strings: Iterable[str],
        prefix: str
    ) -> Iterable[str]:
    """
    Similar to `delimiter.join(strings)`, but as an iterable
    over the unjoined components of that resulting string.
    """
    it = strings.__iter__()
    try:
        while True:
            next = it.__next__()
            yield prefix
            yield next

    except StopIteration:
        pass



def append(
        strings: Iterable[str],
        suffix: str
    ) -> Iterable[str]:
    """
    Similar to `delimiter.join(strings)`, but as an iterable
    over the unjoined components of that resulting string.
    """
    it = strings.__iter__()
    try:
        while True:
            next = it.__next__()
            yield next
            yield suffix

    except StopIteration:
        pass



def enclose(
        strings: Iterable[str],
        prefix: str,
        suffix: str
    ) -> Iterable[str]:
    """
    Similar to `delimiter.join(strings)`, but as an iterable
    over the unjoined components of that resulting string.
    """
    it = strings.__iter__()
    try:
        while True:
            next = it.__next__()
            yield prefix
            yield next
            yield suffix

    except StopIteration:
        pass