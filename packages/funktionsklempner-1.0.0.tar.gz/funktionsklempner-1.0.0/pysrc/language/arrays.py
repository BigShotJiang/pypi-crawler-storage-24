# Funktionsklempner array types.
#
# Author: Malte J. Ziebarth (malte.ziebarth@tum.de)
#
# Copyright (C) 2025-2026 Technische Universität München
#
# Licensed under the EUPL, Version 1.2 or – as soon they will be approved by
# the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
#
# https://joinup.ec.europa.eu/collection/eupl/eupl-text-eupl-12
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the Licence is distributed on an "AS IS" basis,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and
# limitations under the Licence.
#
# SPDX-FileCopyrightText: 2025-2026 Technical University of Munich
# SPDX-License-Identifier: EUPL-1.2
# SPDX-FileContributor: Malte J. Ziebarth <malte.ziebarth@tum.de>

from typing import Any
from .fundamental import FundamentalBaseType, CTypeBaseType
from .conversion import TYPE_MAP
from .abstract import Const


class NDArray:
    dtype: FundamentalBaseType | Const[FundamentalBaseType]
    size_control: "NDArray | QuantityArray | None"

    def __init__(self,
            dtype: FundamentalBaseType | Const[FundamentalBaseType]
        ):
        self.dtype = dtype
        self.size_control = None

    def __repr__(self):
        return "NDArray(" + self.dtype.__repr__() + ")"

    def __eq__(self, other: Any) -> bool:
        if isinstance(other, NDArray):
            return self.dtype == other.dtype # pyright: ignore
        return False

    def ctypes_type(self) -> CTypeBaseType:
        if isinstance(self.dtype, Const):
            return TYPE_MAP[self.dtype.val]
        return TYPE_MAP[self.dtype]



class QuantityArray:
    dtype: FundamentalBaseType | Const[FundamentalBaseType]
    boost_unit: str
    size_control: "NDArray | QuantityArray | None"

    def __init__(self,
            dtype: FundamentalBaseType | Const[FundamentalBaseType],
            boost_unit: str
        ):
        self.dtype = dtype
        self.boost_unit = boost_unit
        self.size_control = None

    def __repr__(self):
        return f"QuantityArray({self.dtype.__repr__()}, {self.boost_unit})"

    def __eq__(self, other: Any) -> bool:
        if isinstance(other, QuantityArray):
            return (
                self.dtype == other.dtype # pyright: ignore
                and self.boost_unit == other.boost_unit
            )
        return False

    def ctypes_type(self) -> CTypeBaseType:
        if isinstance(self.dtype, Const):
            return TYPE_MAP[self.dtype.val]
        return TYPE_MAP[self.dtype]