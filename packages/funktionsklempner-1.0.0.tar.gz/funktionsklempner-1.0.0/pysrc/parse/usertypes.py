# A dictionary of user types.
#
# Author: Malte J. Ziebarth (malte.ziebarth@tum.de)
#
# Copyright (C) 2026 Technische Universität München
#
# Licensed under the EUPL, Version 1.2 or – as soon they will be approved by
# the European Commission - subsequent versions of the EUPL (the "Licence");
# You may not use this work except in compliance with the Licence.
# You may obtain a copy of the Licence at:
#
# https://joinup.ec.europa.eu/collection/eupl/eupl-text-eupl-12
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the Licence is distributed on an "AS IS" basis,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the Licence for the specific language governing permissions and
# limitations under the Licence.
#
# SPDX-FileCopyrightText: 2026 Technical University of Munich
# SPDX-License-Identifier: EUPL-1.2
# SPDX-FileContributor: Malte J. Ziebarth <malte.ziebarth@tum.de>

from ..language.abstract import Struct
from ..language.cpp import L1Type



class UserTypeDict:
    """
    For code clarity, this class bundles user types (i.e.
    user-defined structs) in a dictionary.
    """
    types: dict[str, Struct[L1Type]]

    def __init__(self):
        self.types = dict()


    def __contains__(self, typename: str):
        return typename in self.types


    def __getitem__(self, typename: str) -> Struct[L1Type]:
        return self.types[typename]


    def __setitem__(self, typename: str, t: Struct[L1Type]):
        self.types[typename] = t