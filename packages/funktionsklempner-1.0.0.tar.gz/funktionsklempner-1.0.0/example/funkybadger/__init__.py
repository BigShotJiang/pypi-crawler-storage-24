# This is a very empty init file.
# Note: the `example` module will be automatically generated,
# so this demonstrates how to work with that.
#
# SPDX-FileCopyrightText: 2025 Technical University of Munich
# SPDX-License-Identifier: BSD-3-Clause
from .example import test_function