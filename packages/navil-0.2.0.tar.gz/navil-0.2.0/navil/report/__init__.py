"""Report generators for Navil scan results."""

from navil.report.state_of_mcp import generate_state_of_mcp_report

__all__ = ["generate_state_of_mcp_report"]
