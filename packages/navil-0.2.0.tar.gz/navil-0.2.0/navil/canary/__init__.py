"""MCP Canary Kit — standalone, open-source-ready honeypot package.

A lightweight MCP honeypot that can be deployed independently:

    python -m navil.canary --profile dev-tools --port 8080

Minimal dependencies: just the MCP server + logging, no ML/Redis required.
Optionally contributes anonymized detection data back to the Navil
threat intelligence pool.
"""

from navil.canary.kit import CanaryKit

__all__ = ["CanaryKit"]
