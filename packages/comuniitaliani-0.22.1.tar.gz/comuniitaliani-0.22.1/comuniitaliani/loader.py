import csv
import io
import json
import os
import re
import unicodedata
import zipfile
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from typing import Dict, Iterable, List, Optional, Protocol, Set

import requests

ISTAT_CSV_URL = "https://www.istat.it/storage/codici-unita-amministrative/Elenco-comuni-italiani.csv"
GARDA_DATASET_PAGE_URL = "https://www.gardainformatica.it/database-comuni-italiani"
GARDA_ZIP_URL_RE = re.compile(r"https://www\.gardainformatica\.it/gi_db_comuni/gi_db_comuni-[^\"']+\.zip", re.IGNORECASE)

# Percorso della directory "database" basato sul file corrente
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DEFAULT_CSV_PATH = os.path.join(BASE_DIR, "database/comuni.csv")
DEFAULT_GARDA_CAP_CSV_PATH = os.path.join(BASE_DIR, "database/garda_cap.csv")
DEFAULT_GARDA_CAP_METADATA_PATH = os.path.join(BASE_DIR, "database/garda_cap_metadata.json")
DEFAULT_TIMEOUT = 10

COLUMN_MAPPING = {
    "denominazione_in_italiano": "denominazione_italiana",
    "sigla_automobilistica": "sigla_provincia",
    "denominazione_regione": "regione",
    "denominazione_dell'unità_territoriale_sovracomunale_(valida_a_fini_statistici)": "provincia",
    "codice_catastale_del_comune": "codice_catastale",
    "codice_comune_formato_alfanumerico": "codice_istat",
    "codice_comune_formato_numerico": "codice_istat_numerico",
}

GARDA_CODE_COLUMNS = (
    "codice_istat",
    "codice_istat_alfanumerico",
    "codice_comune",
    "codice_comune_formato_alfanumerico",
    "istat",
)
GARDA_NUMERIC_CODE_COLUMNS = (
    "codice_istat_numerico",
    "codice_comune_numerico",
    "codice_comune_formato_numerico",
    "istat_numerico",
)
GARDA_CATASTALE_COLUMNS = (
    "codice_catastale",
    "codice_catastale_del_comune",
)
GARDA_NAME_COLUMNS = (
    "comune",
    "nome",
    "denominazione",
    "denominazione_italiana",
    "denominazione_in_italiano",
)
GARDA_PROV_SIGLA_COLUMNS = (
    "sigla",
    "sigla_provincia",
    "sigla_automobilistica",
    "provincia_sigla",
)
GARDA_CAP_COLUMNS = (
    "cap",
    "caps",
    "codice_avviamento_postale",
)


class _SessionLike(Protocol):
    def head(self, url: str, **kwargs):
        ...

    def get(self, url: str, **kwargs):
        ...


def clean_column_names(columns: Iterable[str]) -> List[str]:
    """Pulisce i nomi delle colonne per renderli coerenti."""
    cleaned = []
    for col in columns:
        if col is None:
            continue
        col = col.strip()
        col = col.replace("\n", " ")
        col = re.sub(r"\s+", "_", col)
        cleaned.append(col.lower())
    return cleaned


def _normalize_text(value: str) -> str:
    if not isinstance(value, str):
        return ""
    normalized = unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode("ascii")
    return normalized.lower().strip()


def _parse_http_date(value: str) -> Optional[datetime]:
    """Converte una stringa HTTP-date in datetime."""
    try:
        return parsedate_to_datetime(value)
    except Exception:
        return None


def get_remote_last_modified(session: Optional[_SessionLike] = None, timeout: int = DEFAULT_TIMEOUT) -> Optional[datetime]:
    """Recupera la data dell'ultima modifica del CSV remoto."""
    sess = session or requests
    try:
        response = sess.head(ISTAT_CSV_URL, allow_redirects=True, timeout=timeout)
        response.raise_for_status()
    except Exception as exc:
        print(f"Impossibile ottenere la data di ultima modifica del file remoto: {exc}")
        return None

    remote_last_modified = response.headers.get("Last-Modified")
    if not remote_last_modified:
        return None

    parsed = _parse_http_date(remote_last_modified)
    if parsed and parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=timezone.utc)
    return parsed


def get_local_last_modified(local_path: str) -> Optional[datetime]:
    """Recupera la data di ultima modifica del file locale."""
    if os.path.exists(local_path):
        return datetime.fromtimestamp(os.path.getmtime(local_path), tz=timezone.utc)
    return None


def is_csv_updated(local_path: str = DEFAULT_CSV_PATH, session: Optional[requests.Session] = None, timeout: int = DEFAULT_TIMEOUT) -> bool:
    """Controlla se il file CSV locale è aggiornato rispetto alla versione remota."""
    remote_last_modified = get_remote_last_modified(session=session, timeout=timeout)
    local_last_modified = get_local_last_modified(local_path)

    # Se non è possibile ottenere la data remota, consideriamo il file locale valido
    if remote_last_modified is None:
        print("Non è stato possibile verificare l'aggiornamento remoto. Uso il file locale.")
        return os.path.exists(local_path)

    if local_last_modified is None or local_last_modified < remote_last_modified:
        return False  # Non aggiornato
    return True  # Aggiornato


def download_csv(local_path: str = DEFAULT_CSV_PATH, session: Optional[_SessionLike] = None, timeout: int = DEFAULT_TIMEOUT) -> None:
    """Scarica il file CSV dell'ISTAT e lo salva localmente."""
    sess = session or requests
    try:
        response = sess.get(ISTAT_CSV_URL, stream=True, timeout=timeout)
        response.raise_for_status()
    except Exception as exc:
        raise Exception(f"Errore durante il download del file CSV: {exc}") from exc

    os.makedirs(os.path.dirname(local_path), exist_ok=True)
    with open(local_path, "wb") as file:
        for chunk in response.iter_content(chunk_size=8192):
            file.write(chunk)
    print(f"CSV scaricato correttamente: {local_path}")


def _ensure_local_csv(csv_file: str, allow_download: bool, session: Optional[requests.Session], timeout: int) -> None:
    """Verifica che il CSV esista e sia aggiornato, eventualmente scaricandolo."""
    if not allow_download:
        if not os.path.exists(csv_file):
            raise FileNotFoundError(f"File CSV non trovato e download disattivato: {csv_file}")
        return

    if not os.path.exists(csv_file):
        print("Il file CSV non esiste. Download in corso...")
        download_csv(csv_file, session=session, timeout=timeout)
        return

    if not is_csv_updated(csv_file, session=session, timeout=timeout):
        print("Il file CSV non è aggiornato. Download in corso...")
        download_csv(csv_file, session=session, timeout=timeout)
    else:
        print("Il file CSV è già aggiornato.")


def _read_raw_rows(csv_file: str) -> List[Dict[str, str]]:
    """Legge il CSV grezzo e restituisce righe con intestazioni pulite."""

    def _read_with_encoding(encoding: str) -> List[Dict[str, str]]:
        with open(csv_file, "r", encoding=encoding, newline="") as handle:
            return _read_csv_rows(handle)

    try:
        return _read_with_encoding("utf-8")
    except UnicodeDecodeError:
        return _read_with_encoding("latin1")


def _read_csv_rows(handle: io.TextIOBase) -> List[Dict[str, str]]:
    reader = csv.reader(handle, delimiter=";")
    try:
        header = next(reader)
    except StopIteration:
        raise ValueError("Il file CSV è vuoto.")

    cleaned_header = clean_column_names(header)
    rows: List[Dict[str, str]] = []
    for raw_row in reader:
        if not raw_row or not any(raw_row):
            continue
        row_data = {}
        for idx, value in enumerate(raw_row):
            if idx >= len(cleaned_header):
                continue
            row_data[cleaned_header[idx]] = value.strip()
        rows.append(row_data)
    return rows


def _extract_relevant_columns(rows: List[Dict[str, str]]) -> List[Dict[str, str]]:
    """Riduce le righe alle colonne di interesse rinominate."""
    cleaned_rows: List[Dict[str, str]] = []
    for row in rows:
        record: Dict[str, str] = {}
        for raw_column, target_column in COLUMN_MAPPING.items():
            record[target_column] = row.get(raw_column, "")

        if not record.get("denominazione_italiana"):
            continue  # ignora righe incomplete
        cleaned_rows.append(record)
    return cleaned_rows


def _collect_row_values(row: Dict[str, str], candidates: Iterable[str]) -> List[str]:
    values: List[str] = []
    for column in candidates:
        value = row.get(column, "")
        if value:
            values.append(value)
    return values


def _numeric_lookup_values(value: str) -> Set[str]:
    cleaned = value.strip()
    if not cleaned:
        return set()
    digits_only = re.sub(r"\D", "", cleaned)
    if not digits_only:
        return set()
    return {digits_only, digits_only.zfill(5), digits_only.zfill(6)}


def _record_lookup_keys(record: Dict[str, str]) -> Set[str]:
    keys: Set[str] = set()

    codice_istat = record.get("codice_istat", "").upper().strip()
    if codice_istat:
        keys.add(f"istat:{codice_istat}")

    codice_catastale = record.get("codice_catastale", "").upper().strip()
    if codice_catastale:
        keys.add(f"cat:{codice_catastale}")

    for numeric_value in _numeric_lookup_values(record.get("codice_istat_numerico", "")):
        keys.add(f"istat_num:{numeric_value}")

    normalized_name = _normalize_text(record.get("denominazione_italiana", ""))
    if normalized_name:
        sigla = record.get("sigla_provincia", "").upper().strip()
        if sigla:
            keys.add(f"nameprov:{normalized_name}|{sigla}")

    return keys


def _row_lookup_keys(row: Dict[str, str]) -> Set[str]:
    keys: Set[str] = set()

    for value in _collect_row_values(row, GARDA_CODE_COLUMNS):
        cleaned = value.upper().strip()
        if cleaned:
            keys.add(f"istat:{cleaned}")

    for value in _collect_row_values(row, GARDA_NUMERIC_CODE_COLUMNS):
        for numeric_value in _numeric_lookup_values(value):
            keys.add(f"istat_num:{numeric_value}")

    for value in _collect_row_values(row, GARDA_CATASTALE_COLUMNS):
        cleaned = value.upper().strip()
        if cleaned:
            keys.add(f"cat:{cleaned}")

    names = [_normalize_text(value) for value in _collect_row_values(row, GARDA_NAME_COLUMNS)]
    sigle = [value.upper().strip() for value in _collect_row_values(row, GARDA_PROV_SIGLA_COLUMNS)]
    for normalized_name in names:
        if not normalized_name:
            continue
        for sigla in sigle:
            if sigla:
                keys.add(f"nameprov:{normalized_name}|{sigla}")

    return keys


def _extract_caps(row: Dict[str, str]) -> List[str]:
    caps: List[str] = []
    for column in GARDA_CAP_COLUMNS:
        value = row.get(column, "")
        if not value:
            continue
        matches = re.findall(r"\b\d{5}\b", value)
        for match in matches:
            if match not in caps:
                caps.append(match)
    return caps


def resolve_garda_latest_zip_url(session: Optional[_SessionLike] = None, timeout: int = DEFAULT_TIMEOUT) -> Optional[str]:
    """Recupera il link ZIP più recente dalla pagina di download Garda Informatica."""
    sess = session or requests
    try:
        response = sess.get(GARDA_DATASET_PAGE_URL, timeout=timeout)
        response.raise_for_status()
    except Exception as exc:
        print(f"Impossibile leggere la pagina del dataset Garda Informatica: {exc}")
        return None

    response_text = getattr(response, "text", "")
    match = GARDA_ZIP_URL_RE.search(response_text)
    if not match:
        print("Nessun link ZIP Garda Informatica trovato nella pagina di download.")
        return None
    return match.group(0)


def _load_garda_metadata(metadata_path: str) -> Dict[str, str]:
    if not os.path.exists(metadata_path):
        return {}
    try:
        with open(metadata_path, "r", encoding="utf-8") as handle:
            data = json.load(handle)
    except Exception:
        return {}
    if isinstance(data, dict):
        return {str(key): str(value) for key, value in data.items()}
    return {}


def _write_garda_metadata(metadata_path: str, metadata: Dict[str, str]) -> None:
    os.makedirs(os.path.dirname(metadata_path), exist_ok=True)
    with open(metadata_path, "w", encoding="utf-8") as handle:
        json.dump(metadata, handle, ensure_ascii=True, indent=2, sort_keys=True)


def _garda_zip_needs_update(cap_csv_path: str, metadata_path: str, latest_zip_url: str) -> bool:
    if not os.path.exists(cap_csv_path):
        return True
    metadata = _load_garda_metadata(metadata_path)
    return metadata.get("zip_url") != latest_zip_url


def _extract_garda_csv_from_zip_bytes(payload: bytes, cap_csv_path: str) -> str:
    with zipfile.ZipFile(io.BytesIO(payload)) as archive:
        members = [name for name in archive.namelist() if name.lower().endswith(".csv")]
        if not members:
            raise ValueError("Archivio Garda privo di CSV.")

        preferred_members = sorted(
            members,
            key=lambda name: (
                0 if os.path.basename(name).lower().startswith("gi_cap") else
                1 if os.path.basename(name).lower().startswith("gi_comuni_cap") else
                2,
                name.lower(),
            ),
        )
        member_name = preferred_members[0]

        os.makedirs(os.path.dirname(cap_csv_path), exist_ok=True)
        with archive.open(member_name) as source, open(cap_csv_path, "wb") as target:
            target.write(source.read())
        return member_name


def download_garda_cap_csv(
    cap_csv_path: str = DEFAULT_GARDA_CAP_CSV_PATH,
    metadata_path: str = DEFAULT_GARDA_CAP_METADATA_PATH,
    session: Optional[_SessionLike] = None,
    timeout: int = DEFAULT_TIMEOUT,
    latest_zip_url: Optional[str] = None,
) -> None:
    """Scarica ed estrae il CSV CAP più recente da Garda Informatica."""
    sess = session or requests
    latest_zip_url = latest_zip_url or resolve_garda_latest_zip_url(session=sess, timeout=timeout)
    if not latest_zip_url:
        raise Exception("Impossibile determinare il link di download Garda Informatica.")

    try:
        response = sess.get(latest_zip_url, timeout=timeout)
        response.raise_for_status()
    except Exception as exc:
        raise Exception(f"Errore durante il download del dataset Garda Informatica: {exc}") from exc

    member_name = _extract_garda_csv_from_zip_bytes(response.content, cap_csv_path)
    _write_garda_metadata(
        metadata_path,
        {
            "downloaded_at": datetime.now(timezone.utc).isoformat(),
            "member_name": member_name,
            "zip_url": latest_zip_url,
        },
    )
    print(f"Dataset CAP Garda scaricato correttamente: {cap_csv_path}")


def ensure_garda_cap_csv(
    cap_csv_path: str = DEFAULT_GARDA_CAP_CSV_PATH,
    *,
    allow_download: bool = True,
    session: Optional[_SessionLike] = None,
    timeout: int = DEFAULT_TIMEOUT,
    metadata_path: str = DEFAULT_GARDA_CAP_METADATA_PATH,
) -> Optional[str]:
    """Garantisce la presenza del CSV CAP Garda più recente, se disponibile."""
    if not allow_download:
        return cap_csv_path if os.path.exists(cap_csv_path) else None

    latest_zip_url = resolve_garda_latest_zip_url(session=session, timeout=timeout)
    if not latest_zip_url:
        return cap_csv_path if os.path.exists(cap_csv_path) else None

    if _garda_zip_needs_update(cap_csv_path, metadata_path, latest_zip_url):
        try:
            download_garda_cap_csv(
                cap_csv_path,
                metadata_path=metadata_path,
                session=session,
                timeout=timeout,
                latest_zip_url=latest_zip_url,
            )
        except Exception as exc:
            print(f"Impossibile aggiornare il dataset CAP Garda: {exc}")
    return cap_csv_path if os.path.exists(cap_csv_path) else None


def load_garda_cap_data(
    cap_csv_file: str = DEFAULT_GARDA_CAP_CSV_PATH,
    *,
    allow_download: bool = True,
    session: Optional[requests.Session] = None,
    timeout: int = DEFAULT_TIMEOUT,
    metadata_path: str = DEFAULT_GARDA_CAP_METADATA_PATH,
) -> Dict[str, List[str]]:
    """Carica una mappa di lookup per associare i CAP ai comuni."""
    local_cap_path = ensure_garda_cap_csv(
        cap_csv_file,
        allow_download=allow_download,
        session=session,
        timeout=timeout,
        metadata_path=metadata_path,
    )
    if not local_cap_path:
        return {}

    try:
        rows = _read_raw_rows(local_cap_path)
    except Exception as exc:
        print(f"Impossibile leggere il dataset CAP Garda locale: {exc}")
        return {}

    caps_by_lookup_key: Dict[str, List[str]] = {}
    for row in rows:
        caps = _extract_caps(row)
        lookup_keys = _row_lookup_keys(row)
        if not caps or not lookup_keys:
            continue
        for lookup_key in lookup_keys:
            bucket = caps_by_lookup_key.setdefault(lookup_key, [])
            for cap in caps:
                if cap not in bucket:
                    bucket.append(cap)
    return caps_by_lookup_key


def enrich_records_with_caps(records: List[Dict[str, str]], caps_by_lookup_key: Dict[str, List[str]]) -> List[Dict[str, str]]:
    """Aggiunge la lista dei CAP ai record ISTAT in base ai lookup disponibili."""
    if not caps_by_lookup_key:
        for record in records:
            record["cap"] = []
        return records

    for record in records:
        lookup_priority: List[str] = []

        codice_istat = record.get("codice_istat", "").upper().strip()
        if codice_istat:
            lookup_priority.append(f"istat:{codice_istat}")

        for numeric_value in sorted(_numeric_lookup_values(record.get("codice_istat_numerico", "")), key=len, reverse=True):
            lookup_priority.append(f"istat_num:{numeric_value}")

        codice_catastale = record.get("codice_catastale", "").upper().strip()
        if codice_catastale:
            lookup_priority.append(f"cat:{codice_catastale}")

        normalized_name = _normalize_text(record.get("denominazione_italiana", ""))
        sigla = record.get("sigla_provincia", "").upper().strip()
        if normalized_name and sigla:
            lookup_priority.append(f"nameprov:{normalized_name}|{sigla}")

        resolved_caps: List[str] = []
        for lookup_key in lookup_priority:
            candidate_caps = caps_by_lookup_key.get(lookup_key, [])
            if candidate_caps:
                resolved_caps = sorted(candidate_caps)
                break

        record["cap"] = resolved_caps
    return records


def load_comuni_data(csv_file: str = DEFAULT_CSV_PATH, *, allow_download: bool = True, session: Optional[requests.Session] = None, timeout: int = DEFAULT_TIMEOUT) -> List[Dict[str, str]]:
    """
    Carica i dati dei comuni dal file CSV, aggiornandolo se necessario.

    :param csv_file: Percorso del CSV locale.
    :param allow_download: Se True prova a scaricare/aggiornare i dati dal sito ISTAT.
    :param session: Sessione requests riutilizzabile (utile nei test).
    :param timeout: Timeout per le richieste HTTP.
    """
    _ensure_local_csv(csv_file, allow_download=allow_download, session=session, timeout=timeout)
    rows = _read_raw_rows(csv_file)
    return _extract_relevant_columns(rows)
