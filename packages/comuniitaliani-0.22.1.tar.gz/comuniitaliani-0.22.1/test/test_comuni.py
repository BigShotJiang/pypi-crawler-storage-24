import os
import time
import zipfile
from io import BytesIO
from pathlib import Path

import pytest

from comuniitaliani import Comuni
from comuniitaliani import comuni as comuni_module
from comuniitaliani import loader
from comuniitaliani.exceptions import ComuneNotFoundError


@pytest.fixture()
def sample_csv(tmp_path: Path) -> Path:
    fixture = Path(__file__).parent / "fixtures" / "comuni_sample.csv"
    target = tmp_path / "comuni.csv"
    target.write_bytes(fixture.read_bytes())
    return target


def test_cerca_comune_is_case_and_accent_insensitive(sample_csv: Path) -> None:
    comuni = Comuni(csv_file=str(sample_csv), allow_download=False)

    result = comuni.cerca_comune("AGLIE")

    assert result["nome"] == "Agliè"
    assert result["sigla_provincia"] == "TO"
    assert result["regione"] == "Piemonte"
    assert result["cap"] == []


def test_cerca_comune_returns_cap_list_from_local_garda_csv(sample_csv: Path, tmp_path: Path) -> None:
    cap_csv = tmp_path / "garda_cap.csv"
    cap_csv.write_text(
        "codice_istat_numerico;cap\n"
        "1001;10080\n"
        "1001;10081\n"
        "2001;00118,00119\n",
        encoding="utf-8",
    )

    comuni = Comuni(csv_file=str(sample_csv), cap_csv_file=str(cap_csv), allow_download=False)

    assert comuni.cerca_comune("Agliè")["cap"] == ["10080", "10081"]
    assert comuni.cerca_comune("Roma")["cap"] == ["00118", "00119"]


def test_cerca_per_cap_returns_matching_comuni(sample_csv: Path, tmp_path: Path) -> None:
    cap_csv = tmp_path / "garda_cap.csv"
    cap_csv.write_text(
        "codice_istat_numerico;cap\n"
        "1001;10080\n"
        "2001;00118\n"
        "3001;47521\n",
        encoding="utf-8",
    )

    comuni = Comuni(csv_file=str(sample_csv), cap_csv_file=str(cap_csv), allow_download=False)

    assert comuni.cerca_per_cap("10080") == [
        {
            "nome": "Agliè",
            "provincia": "Torino",
            "sigla_provincia": "TO",
            "regione": "Piemonte",
            "codice_catastale": "A074",
            "cap": ["10080"],
        }
    ]


def test_comuni_per_provincia_returns_sorted_list(sample_csv: Path) -> None:
    comuni = Comuni(csv_file=str(sample_csv), allow_download=False)

    torino = comuni.comuni_per_provincia("to")
    lazio = comuni.comuni_per_provincia("RM")

    assert [item["nome"] for item in torino] == ["Agliè"]
    assert [item["nome"] for item in lazio] == ["Roma"]


def test_cerca_per_codice_catastale_not_found(sample_csv: Path) -> None:
    comuni = Comuni(csv_file=str(sample_csv), allow_download=False)

    with pytest.raises(ComuneNotFoundError):
        comuni.cerca_per_codice_catastale("ZZZZ")


def test_cerca_per_cap_not_found(sample_csv: Path) -> None:
    comuni = Comuni(csv_file=str(sample_csv), allow_download=False)

    with pytest.raises(ComuneNotFoundError):
        comuni.cerca_per_cap("99999")


def test_load_cap_false_skips_garda_loading(monkeypatch: pytest.MonkeyPatch, sample_csv: Path) -> None:
    def _fail(*args, **kwargs):
        raise AssertionError("Il layer CAP non dovrebbe essere caricato.")

    monkeypatch.setattr(comuni_module, "load_garda_cap_data", _fail)

    comuni = Comuni(csv_file=str(sample_csv), load_cap=False, allow_download=False)

    assert comuni.cerca_comune("Agliè")["cap"] == []


def test_enrich_records_with_caps_prefers_strongest_lookup_key() -> None:
    records = [
        {
            "denominazione_italiana": "Roma",
            "provincia": "Roma",
            "sigla_provincia": "RM",
            "regione": "Lazio",
            "codice_catastale": "H501",
            "codice_istat": "H501",
            "codice_istat_numerico": "2001",
        }
    ]

    caps_by_lookup_key = {
        "istat:H501": ["00118"],
        "istat_num:02001": ["00119"],
        "cat:H501": ["00120"],
        "nameprov:roma|RM": ["00121"],
    }

    enriched = loader.enrich_records_with_caps(records, caps_by_lookup_key)

    assert enriched[0]["cap"] == ["00118"]


def test_enrich_records_with_caps_does_not_use_name_without_province() -> None:
    records = [
        {
            "denominazione_italiana": "Roma",
            "provincia": "Roma",
            "sigla_provincia": "RM",
            "regione": "Lazio",
            "codice_catastale": "",
            "codice_istat": "",
            "codice_istat_numerico": "",
        }
    ]

    caps_by_lookup_key = {
        "name:roma": ["00118"],
    }

    enriched = loader.enrich_records_with_caps(records, caps_by_lookup_key)

    assert enriched[0]["cap"] == []


def test_offline_mode_does_not_hit_network(monkeypatch: pytest.MonkeyPatch, sample_csv: Path) -> None:
    def _fail(*args, **kwargs):
        raise AssertionError("Non dovrebbe essere effettuata alcuna richiesta HTTP in modalità offline.")

    monkeypatch.setattr(loader.requests, "head", _fail)
    monkeypatch.setattr(loader.requests, "get", _fail)

    comuni = Comuni(csv_file=str(sample_csv), allow_download=False)
    assert comuni.cerca_comune("Agliè")["nome"] == "Agliè"


def test_download_triggers_when_remote_newer(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    local_csv = tmp_path / "comuni.csv"
    # Vecchio contenuto
    local_csv.write_text(
        "denominazione_in_italiano;sigla_automobilistica;denominazione_regione;denominazione_dell'unità_territoriale_sovracomunale_(valida_a_fini_statistici);codice_catastale_del_comune\n"
        "Vecchio;VC;Piemonte;Vercelli;Z999\n",
        encoding="latin1",
    )
    # Imposta una mtime vecchia
    old_time = time.time() - 10_000
    os.utime(local_csv, (old_time, old_time))

    new_csv_body = (
        "denominazione_in_italiano;sigla_automobilistica;denominazione_regione;denominazione_dell'unità_territoriale_sovracomunale_(valida_a_fini_statistici);codice_catastale_del_comune\n"
        "Nuovo;RM;Lazio;Roma;H501\n"
    ).encode("latin1")

    class _FakeHeadResponse:
        headers = {"Last-Modified": "Wed, 01 Jan 2099 00:00:00 GMT"}

        @staticmethod
        def raise_for_status():
            return None

    class _FakeGetResponse:
        def __init__(self, payload: bytes):
            self.payload = payload

        @staticmethod
        def raise_for_status():
            return None

        def iter_content(self, chunk_size: int):
            yield self.payload

    monkeypatch.setattr(loader.requests, "head", lambda *_, **__: _FakeHeadResponse())
    monkeypatch.setattr(loader.requests, "get", lambda *_, **__: _FakeGetResponse(new_csv_body))

    comuni = Comuni(csv_file=str(local_csv), allow_download=True)
    assert comuni.cerca_comune("Nuovo")["sigla_provincia"] == "RM"


def test_load_garda_cap_data_downloads_latest_zip_from_page(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    cap_csv = tmp_path / "garda_cap.csv"
    metadata_path = tmp_path / "garda_cap_metadata.json"

    zip_buffer = BytesIO()
    with zipfile.ZipFile(zip_buffer, "w") as archive:
        archive.writestr("gi_cap.csv", "codice_istat_numerico;cap\n1001;10080\n1001;10081\n")
    zip_payload = zip_buffer.getvalue()

    class _FakeResponse:
        def __init__(self, text: str = "", content: bytes = b""):
            self.text = text
            self.content = content

        @staticmethod
        def raise_for_status():
            return None

    calls = []

    def _fake_get(url, *_, **__):
        calls.append(url)
        if url == loader.GARDA_DATASET_PAGE_URL:
            return _FakeResponse(
                text=(
                    '<a href="https://www.gardainformatica.it/gi_db_comuni/'
                    'gi_db_comuni-2026-01-31-6fcd8.zip">Scarica</a>'
                )
            )
        if url == "https://www.gardainformatica.it/gi_db_comuni/gi_db_comuni-2026-01-31-6fcd8.zip":
            return _FakeResponse(content=zip_payload)
        raise AssertionError(f"URL inatteso: {url}")

    monkeypatch.setattr(loader.requests, "get", _fake_get)

    caps_by_lookup_key = loader.load_garda_cap_data(
        str(cap_csv),
        allow_download=True,
        session=None,
        timeout=10,
        metadata_path=str(metadata_path),
    )

    assert cap_csv.exists()
    assert metadata_path.exists()
    assert caps_by_lookup_key["istat_num:1001"] == ["10080", "10081"]
    assert calls == [
        loader.GARDA_DATASET_PAGE_URL,
        "https://www.gardainformatica.it/gi_db_comuni/gi_db_comuni-2026-01-31-6fcd8.zip",
    ]


def test_load_garda_cap_data_uses_local_copy_when_page_is_unavailable(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    cap_csv = tmp_path / "garda_cap.csv"
    cap_csv.write_text("codice_istat_numerico;cap\n1001;10080\n", encoding="utf-8")

    def _fail(*args, **kwargs):
        raise RuntimeError("network down")

    monkeypatch.setattr(loader.requests, "get", _fail)

    caps_by_lookup_key = loader.load_garda_cap_data(str(cap_csv), allow_download=True)

    assert caps_by_lookup_key["istat_num:1001"] == ["10080"]
