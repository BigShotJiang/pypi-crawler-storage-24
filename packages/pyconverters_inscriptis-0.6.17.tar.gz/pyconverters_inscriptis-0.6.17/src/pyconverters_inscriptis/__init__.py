"""Sherpa HTML inscriptis converter"""

__version__ = "0.6.17"
