import logging
import os
import datetime
import getpass

from pathlib import Path
from omegaconf import OmegaConf

import slide2vec.distributed as distributed
from slide2vec.utils import initialize_wandb, fix_random_seeds, get_sha, setup_logging
from slide2vec.configs import default_preprocessing_config, default_model_config

logger = logging.getLogger("slide2vec")


def validate_removed_options(cfg) -> None:
    if "restrict_to_tissue" in cfg.model:
        raise ValueError(
            "model.restrict_to_tissue is no longer supported in slide2vec."
        )
    if "visualize" in cfg:
        raise ValueError(
            "visualize is no longer supported in slide2vec; use save_previews instead."
        )
    if "visu_params" in cfg.tiling:
        raise ValueError(
            "tiling.visu_params is no longer supported in slide2vec; use tiling.preview instead."
        )


def write_config(cfg, output_dir, name="config.yaml"):
    logger.info(OmegaConf.to_yaml(cfg))
    saved_cfg_path = os.path.join(output_dir, name)
    with open(saved_cfg_path, "w") as f:
        OmegaConf.save(config=cfg, f=f)
    return saved_cfg_path


def get_cfg_from_args(args):
    if args.output_dir is not None:
        args.output_dir = os.path.abspath(args.output_dir)
        args.opts += [f"output_dir={args.output_dir}"]
    default_preprocessing_cfg = OmegaConf.create(default_preprocessing_config)
    default_model_cfg = OmegaConf.create(default_model_config)
    default_cfg = OmegaConf.merge(default_preprocessing_cfg, default_model_cfg)
    cfg = OmegaConf.load(args.config_file)
    cfg = OmegaConf.merge(default_cfg, cfg, OmegaConf.from_cli(args.opts))
    OmegaConf.resolve(cfg)
    validate_removed_options(cfg)
    return cfg


def setup(args):
    """
    Basic configuration setup without any distributed or GPU-specific initialization.
    This function:
      - Loads the config from file and command-line options.
      - Sets up logging.
      - Fixes random seeds.
      - Creates the output directory.
    """
    cfg = get_cfg_from_args(args)

    if cfg.resume:
        run_id = cfg.resume_dirname
    elif not args.skip_datetime:
        run_id = datetime.datetime.now().strftime("%Y-%m-%d_%H_%M")
    else:
        run_id = ""

    if cfg.wandb.enable:
        key = os.environ.get("WANDB_API_KEY")
        wandb_run = initialize_wandb(cfg, key=key)
        wandb_run.define_metric("processed", summary="max")
        run_id = wandb_run.id

    output_dir = Path(cfg.output_dir, run_id)
    if distributed.is_main_process():
        output_dir.mkdir(exist_ok=cfg.resume or args.skip_datetime, parents=True)
    cfg.output_dir = str(output_dir)

    fix_random_seeds(0)
    setup_logging(output=cfg.output_dir, level=logging.INFO)
    logger.info("git:\n  {}\n".format(get_sha()))
    cfg_path = write_config(cfg, cfg.output_dir)
    if cfg.wandb.enable:
        wandb_run.save(cfg_path)
    return cfg, cfg_path
def hf_login():
    from huggingface_hub import login

    if "HF_TOKEN" not in os.environ and distributed.is_main_process():
        hf_token = getpass.getpass(
            "Enter your Hugging Face API token (input will not be visible): "
        )
        os.environ["HF_TOKEN"] = hf_token
    if distributed.is_enabled_and_multiple_gpus():
        import torch.distributed as dist

        dist.barrier()
    if distributed.is_main_process():
        login(os.environ["HF_TOKEN"])
