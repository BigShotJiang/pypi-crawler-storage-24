from __future__ import (
    annotations,
)

import inspect
import logging
from dataclasses import (
    dataclass,
)
from typing import Protocol

from fa_purity import (
    Cmd,
    Coproduct,
    Result,
    ResultE,
)
from fluidattacks_etl_utils.bug import Bug
from fluidattacks_etl_utils.secrets import (
    SecretsManager,
    SecretsManagerFactory,
)
from fluidattacks_etl_utils.typing import (
    Callable,
    TypeVar,
)
from snowflake_client import (
    ClientFactory,
    ConnectionFactory,
    SchemaClient,
    SnowflakeConnection,
    SnowflakeCredentials,
    SnowflakeCursor,
    SnowflakeDatabase,
    SnowflakeWarehouse,
    TableClient,
)

from fluidattacks_connection_manager import (
    _utils,
)

from . import _setup
from ._core import (
    ConnectionConf,
    Databases,
    Roles,
    SetupException,
    Warehouses,
)

LOG = logging.getLogger(__name__)
_T = TypeVar("_T")
_F = TypeVar("_F")


@dataclass(frozen=True)
class DbClients:
    connection: SnowflakeConnection
    new_table_client: Callable[[SnowflakeCursor], TableClient]
    new_schema_client: Callable[[SnowflakeCursor], SchemaClient]


class ExecuteWithSnowflake(Protocol):
    def __call__(
        self,
        f: Callable[[DbClients], Cmd[Result[_T, _F]]],
        conf: ConnectionConf,
        /,
    ) -> Cmd[Result[_T, Coproduct[_F, SetupException]]]: ...


@dataclass(frozen=True)
class ConnectionManager:
    snowflake_connection: Callable[[ConnectionConf], Cmd[ResultE[SnowflakeConnection]]]
    execute_with_snowflake: ExecuteWithSnowflake


def _snowflake_connection(
    creds: SnowflakeCredentials,
    conf: ConnectionConf,
) -> Cmd[ResultE[SnowflakeConnection]]:
    return ConnectionFactory.snowflake_connection(
        SnowflakeDatabase(conf.database.value),
        SnowflakeWarehouse(conf.warehouse.value),
        SnowflakeCredentials(
            user=creds.user,
            private_key=creds.private_key,
            account=creds.account,
        ),
    ).map(lambda c: Result.success(c))


def _execute_with_snowflake(
    new_connection: Callable[[ConnectionConf], Cmd[ResultE[SnowflakeConnection]]],
    action: Callable[[DbClients], Cmd[Result[_T, _F]]],
    conf: ConnectionConf,
) -> Cmd[Result[_T, Coproduct[_F, SetupException]]]:
    return _utils.chain_cmd_result(
        new_connection(conf).map(lambda r: r.alt(SetupException).alt(Coproduct.inr)),
        lambda db: SnowflakeConnection.connect_and_execute(
            Cmd.wrap_value(db),
            lambda c: _utils.chain_cmd_result(
                _setup.setup_connection(c, conf, LOG).map(lambda r: r.alt(Coproduct.inr)),
                lambda _: action(
                    DbClients(
                        c,
                        ClientFactory.new_table_client,
                        ClientFactory.new_schema_client,
                    ),
                ).map(lambda r: r.alt(Coproduct.inl)),
            ),
        ),
    )


def _manager_from_creds(creds: SnowflakeCredentials) -> ConnectionManager:
    def _with_snowflake(
        action: Callable[[DbClients], Cmd[Result[_T, _F]]],
        conf: ConnectionConf,
    ) -> Cmd[Result[_T, Coproduct[_F, SetupException]]]:
        return _execute_with_snowflake(
            lambda conf: _snowflake_connection(creds, conf),
            action,
            conf,
        )

    return ConnectionManager(
        lambda conf: _snowflake_connection(creds, conf),
        _with_snowflake,
    )


def _snowflake_etl_access(secrets: SecretsManager) -> Cmd[SnowflakeCredentials]:
    return (
        secrets.get_secrets(("SNOWFLAKE_ETL_PRIVATE_KEY", "SNOWFLAKE_ACCOUNT"))
        .map(lambda r: Bug.assume_success("_snowflake_etl_access", inspect.currentframe(), (), r))
        .map(
            lambda t: SnowflakeCredentials(
                user="ETL_USER",
                private_key=t[0].value,
                account=t[1].value,
            ),
        )
    )


def _observes_manager(secrets: SecretsManager) -> ConnectionManager:
    def _with_snowflake(
        action: Callable[[DbClients], Cmd[Result[_T, _F]]],
        conf: ConnectionConf,
    ) -> Cmd[Result[_T, Coproduct[_F, SetupException]]]:
        return _execute_with_snowflake(
            lambda conf: _snowflake_etl_access(secrets).bind(
                lambda c: _snowflake_connection(c, conf),
            ),
            action,
            conf,
        )

    return ConnectionManager(
        lambda conf: _snowflake_etl_access(secrets).bind(
            lambda c: _snowflake_connection(c, conf),
        ),
        _with_snowflake,
    )


@dataclass(frozen=True)
class ConnectionManagerFactory:
    @staticmethod
    def custom_manager(creds: SnowflakeCredentials) -> ConnectionManager:
        return _manager_from_creds(creds)

    @staticmethod
    def observes_manager() -> Cmd[ResultE[ConnectionManager]]:
        return SecretsManagerFactory.observes().map(lambda r: r.map(_observes_manager))


__all__ = [
    "ConnectionConf",
    "Databases",
    "Roles",
    "SetupException",
    "Warehouses",
]
