"""ORM model definitions."""

from .account import Account
from .api_key import ApiKey
from .api_usage import ApiUsage
from .audit_log import AuditLog
from .base import Base
from .comment import Comment
from .issue import EmbeddingModel, Issue, IssueEmbedding
from .issue_duplicate import IssueDuplicate
from .organization import Organization
from .project import Project
from .tracker import Tracker, TrackerType
from .client_version_log import ClientVersionLog
from .ai_model import AIModel
from .flow import Flow
from .flow_execution import FlowExecution
from .flow_execution_log import FlowExecutionLog
from .webhook import Webhook
from .tracker_scope_rule import TrackerScopeRule
from .issue_compliance_result import IssueComplianceResult
from .plan import Plan, Subscription, MonthlyUsage
from .issue_relationship import IssueRelationship
from .issue_set import IssueSet
from .tool_configuration import ToolConfiguration, ApprovalWorkflow
from .mcp_server import MCPServer
from .mcp_tool import MCPTool
from .approval_request import ApprovalRequest, ApprovalRequestStatus
from .approval_event import ApprovalEvent
from .tool_access_rule import ToolAccessRule
from .notification_preferences import NotificationPreferences
from .registration_token import RegistrationToken
from .team import Team, TeamMembership
from .user import User, UserSource
from .permission import Permission, Role, RolePermission, UserRole, TeamRole
from .user_invitation import UserInvitation, UserInvitationStatus
from .event import Event
from .instance import Instance
from .github_app_installation import OAuthAppInstallation, GitHubAppInstallation
from .github_oauth_token import OAuthToken, GitHubOAuthToken
from .policy_snapshot import PolicySnapshot

__all__ = [
    "Base",
    "Account",
    "Tracker",
    "TrackerType",
    "Organization",
    "Project",
    "Issue",
    "EmbeddingModel",
    "IssueEmbedding",
    "IssueDuplicate",
    "ApiKey",
    "ApiUsage",
    "AuditLog",
    "ClientVersionLog",
    "Comment",
    "AIModel",
    "Flow",
    "FlowExecution",
    "FlowExecutionLog",
    "Webhook",
    "TrackerScopeRule",
    "IssueComplianceResult",
    "Plan",
    "Subscription",
    "MonthlyUsage",
    "IssueRelationship",
    "IssueSet",
    "ToolConfiguration",
    "ApprovalWorkflow",
    "MCPServer",
    "MCPTool",
    "ApprovalRequest",
    "ApprovalRequestStatus",
    "ApprovalEvent",
    "ToolAccessRule",
    "NotificationPreferences",
    "RegistrationToken",
    "Team",
    "TeamMembership",
    "User",
    "UserSource",
    "Permission",
    "Role",
    "RolePermission",
    "UserRole",
    "TeamRole",
    "UserInvitation",
    "UserInvitationStatus",
    "Event",
    "Instance",
    "OAuthAppInstallation",
    "GitHubAppInstallation",  # Backward compatibility alias
    "OAuthToken",
    "GitHubOAuthToken",  # Backward compatibility alias
    "PolicySnapshot",
]
