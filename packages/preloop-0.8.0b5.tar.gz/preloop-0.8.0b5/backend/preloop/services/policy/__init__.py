"""Policy service for YAML-based policy-as-code configuration.

This module provides declarative policy management for MCP governance:

- schema: Pydantic models for policy YAML/JSON schema
- loader: Load, validate, and apply policy files
"""

from preloop.services.policy.schema import (
    ApprovalWorkflowDefinition,
    ApprovalWorkflowType,
    ConditionAction,
    DefaultsDefinition,
    MCPServerAuthType,
    MCPServerDefinition,
    MCPServerTransport,
    PolicyDiffItem,
    PolicyDiffResult,
    PolicyDocument,
    PolicyImportResult,
    PolicyMetadata,
    PolicyValidationError,
    PolicyValidationResult,
    PolicyVersion,
    ToolCondition,
    ToolDefinition,
    ToolSource,
    UnknownToolsPolicy,
)
from preloop.services.policy.loader import (
    PolicyApplier,
    PolicyLoadError,
    compute_policy_diff,
    export_current_policy,
    export_policy_to_json,
    export_policy_to_yaml,
    load_policy_from_file,
    load_policy_from_string,
)

__all__ = [
    # Core schema
    "PolicyDocument",
    "PolicyVersion",
    "PolicyMetadata",
    # MCP servers
    "MCPServerDefinition",
    "MCPServerAuthType",
    "MCPServerTransport",
    # Approval policies
    "ApprovalWorkflowDefinition",
    "ApprovalWorkflowType",
    # Tools
    "ToolDefinition",
    "ToolSource",
    "ToolCondition",
    "ConditionAction",
    # Defaults
    "DefaultsDefinition",
    "UnknownToolsPolicy",
    # Results
    "PolicyValidationError",
    "PolicyValidationResult",
    "PolicyDiffItem",
    "PolicyDiffResult",
    "PolicyImportResult",
    # Loader functions
    "load_policy_from_string",
    "load_policy_from_file",
    "export_policy_to_yaml",
    "export_policy_to_json",
    "compute_policy_diff",
    "export_current_policy",
    "PolicyApplier",
    "PolicyLoadError",
]
