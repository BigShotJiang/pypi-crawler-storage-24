"""Strategy monitoring utilities."""
