# Copyright (c) 2021 Ilia Sotnikov
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""
Provides support for basic commands of G90 alarm panel.
"""
from __future__ import annotations
import logging
import json
import asyncio
from asyncio import Future
from asyncio.protocols import DatagramProtocol
from asyncio.transports import DatagramTransport, BaseTransport
from typing import Optional, Tuple, List, Any, TypeVar, Generic, TYPE_CHECKING
from dataclasses import dataclass
from ..exceptions import (
    G90Error, G90TimeoutError, G90RetryableError,
    G90CommandFailure, G90CommandError
)
from ..const import G90Commands, G90CommandsBase
if TYPE_CHECKING:
    from typing_extensions import Self

_LOGGER = logging.getLogger(__name__)

CommandT = TypeVar('CommandT', bound=G90CommandsBase)
CommandDataT = TypeVar('CommandDataT')


class G90Command(DatagramProtocol, Generic[CommandT, CommandDataT]):
    """
    Base class for command handling for alarm panel protocol.
    """
    # pylint: disable=too-many-instance-attributes
    # Lock need to be shared across all of the class instances
    _sk_lock = asyncio.Lock()

    # pylint: disable=too-many-positional-arguments,too-many-arguments
    def __init__(self, host: str, port: int, code: CommandT,
                 data: Optional[CommandDataT] = None,
                 local_port: Optional[int] = None,
                 timeout: float = 3.0, retries: int = 3) -> None:
        self._remote_host = host
        self._remote_port = port
        self._local_port = local_port
        self._code = code
        self._timeout = timeout
        self._retries = retries
        self._result: Optional[CommandDataT] = None
        self._connection_result: Optional[
            Future[Tuple[str, int, bytes]]
        ] = None
        self._data = self.encode_data(data)
        self._transport: Optional[DatagramTransport] = None

    # Implementation of datagram protocol,
    # https://docs.python.org/3/library/asyncio-protocol.html#datagram-protocols
    def connection_made(self, transport: BaseTransport) -> None:
        """
        Invoked when connection is established.
        """

    def connection_lost(self, exc: Optional[Exception]) -> None:
        """
        Invoked when connection is lost.
        """

    def datagram_received(self, data: bytes, addr: Tuple[str, int]) -> None:
        """
        Invoked when datagram is received.
        """
        if asyncio.isfuture(self._connection_result):
            if self._connection_result.done():
                _LOGGER.debug(
                    'Excessive packet received from %s:%s: %s',
                    addr[0], addr[1], data
                )
                return
            self._connection_result.set_result((*addr, data))

    def error_received(self, exc: Exception) -> None:
        """
        Invoked when error is received.
        """
        if (
            asyncio.isfuture(self._connection_result) and not
            self._connection_result.done()
        ):
            self._connection_result.set_exception(exc)

    async def _create_connection(self) -> None:
        """
        Creates UDP connection to the alarm panel.
        """
        loop = asyncio.get_running_loop()

        _LOGGER.debug('Creating UDP endpoint for %s:%s',
                      self.host, self.port)
        local_addr = None
        if self._local_port:
            local_addr = ('0.0.0.0', self._local_port)

        self._transport, _ = await loop.create_datagram_endpoint(
            lambda: self,
            remote_addr=(self.host, self.port),
            allow_broadcast=True,
            local_addr=local_addr)

    def _close_connection(self) -> None:
        """
        Closes the connection to the alarm panel.
        """
        if self._transport is not None:
            self._transport.close()
        self._transport = None

    def _validate_response_sender(self, host: str, port: int) -> None:
        """
        Verifies the response is from the expected host and port.
        Closes the transport and raises G90Error if not.
        """
        if self.host != '255.255.255.255':
            if self.host != host or host == '255.255.255.255':
                self._close_connection()
                raise G90Error(
                    f'Received response from wrong host '
                    f'{host}, expected from {self.host}'
                )
        if self.port != port:
            self._close_connection()
            raise G90Error(
                f'Received response from wrong port '
                f'{port}, expected from {self.port}'
            )

    async def _send_only(self) -> None:
        """
        Sends the command without waiting for a response.
        Used when expects_response is False.
        """
        assert self._transport is not None, 'Connection not established'

        async with self._sk_lock:
            _LOGGER.debug(
                '(code %s) Sending request to %s:%s',
                self._code, self.host, self.port
            )
            self._transport.sendto(self.to_wire())
        self._result = None

    async def _send_and_wait_for_response(
        self
    ) -> Optional[Tuple[str, int, bytes]]:
        """
        Sends the command and waits for a response.
        Returns (host, port, data) on success, or None on timeout.
        """
        assert self._transport is not None, 'Connection not established'

        loop = asyncio.get_running_loop()
        self._connection_result = loop.create_future()
        async with self._sk_lock:
            _LOGGER.debug(
                '(code %s) Sending request to %s:%s',
                self._code, self.host, self.port
            )
            self._transport.sendto(self.to_wire())
        done, _ = await asyncio.wait(
            [self._connection_result], timeout=self._timeout
        )
        if self._connection_result in done:
            return self._connection_result.result()
        return None

    def encode_data(self, data: Optional[CommandDataT]) -> str:
        """
        Encodes the command data to JSON string.
        """
        raise NotImplementedError()

    def decode_data(self, payload: Optional[str]) -> CommandDataT:
        """
        Decodes the command data from JSON string.
        """
        raise NotImplementedError()

    def to_wire(self) -> bytes:
        """
        Serializes the command to wire format.
        """
        raise NotImplementedError()

    def from_wire(self, data: bytes) -> Optional[CommandDataT]:
        """
        Deserializes the command from wire format.
        """
        raise NotImplementedError()

    @property
    def result(self) -> CommandDataT:
        """
        The result of the command.
        """
        raise NotImplementedError()

    @property
    def host(self) -> str:
        """
        The hostname/IP address of the alarm panel.
        """
        return self._remote_host

    @property
    def port(self) -> int:
        """
        The port of the alarm panel.
        """
        return self._remote_port

    @property
    def expects_response(self) -> bool:
        """
        Indicates whether the command expects a response.
        """
        return True

    async def process(self) -> Self:  # G90Command[CommandT, CommandDataT]:
        """
        Processes the command.
        """
        # Disallow using `NONE` command, which is intended to use by inheriting
        # classes overriding `process()` method
        if self._code == G90Commands.NONE:
            raise G90Error("'NONE' command code is disallowed")

        await self._create_connection()
        try:
            if not self.expects_response:
                await self._send_only()
                return self

            attempts = self._retries
            while True:
                attempts = attempts - 1
                response = await self._send_and_wait_for_response()
                if response is None:
                    if self._connection_result is not None:
                        self._connection_result.cancel()
                    if not attempts:
                        raise G90TimeoutError()
                    _LOGGER.debug('Timed out, retrying')
                    continue

                host, port, data = response
                _LOGGER.debug('Received response from %s:%s', host, port)
                self._validate_response_sender(host, port)
                try:
                    self._result = self.from_wire(data)
                    break
                except G90RetryableError as exc:
                    if not attempts:
                        raise
                    _LOGGER.debug('Retryable error (%s), retrying', exc)
        finally:
            self._close_connection()
        return self

    def __repr__(self) -> str:
        """
        Returns string representation of the command.
        """
        return f'Command: {self._code}, request: {self._data},' \
            f' response: {self.result}'


BaseCommandsT = G90Commands
BaseCommandsDataT = List[Any]


@dataclass
class G90Header:
    """
    Represents JSON structure of the header used in base panel commands.

    :meta private:
    """
    code: Optional[int] = None
    data: Optional[BaseCommandsDataT] = None


class G90BaseCommand(G90Command[BaseCommandsT, BaseCommandsDataT]):
    """
    Class for handling base G90 panel commands.
    """
    def __init__(self, *args: Any, **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self._resp = G90Header()

    def encode_data(self, data: Optional[BaseCommandsDataT]) -> str:
        """
        Encodes the command data to JSON string.
        """
        if data is None:
            return '""'
        return json.dumps([self._code, data],
                          # No newlines to be inserted
                          indent=None,
                          # No whitespace around entities
                          separators=(',', ':'))

    def decode_data(self, payload: Optional[str]) -> BaseCommandsDataT:
        """
        Decodes the command data from JSON string.
        """
        # Also, panel may report an error supplying specific reason, e.g.
        # command and its arguments that have failed
        if not payload:
            return []
        if payload.startswith('error'):
            error = payload[5:]
            raise G90CommandError(
                f"Command {self._code.name}"
                f" (code={self._code.value}) failed"
                f" with error: '{error}'")

        resp = None
        try:
            resp = json.loads(payload, strict=False)
        except json.JSONDecodeError as exc:
            raise G90Error(
                f"Unable to parse response as JSON: '{payload}'"
            ) from exc

        if not isinstance(resp, list):
            raise G90Error(
                f"Malformed response, 'list' expected: '{payload}'"
            )

        if resp is not None:
            self._resp = G90Header(*resp)
            _LOGGER.debug('Parsed from wire: %s', self._resp)

            if not self._resp.code:
                raise G90Error(f"Missing code in response: '{payload}'")
            # Check there is data if the response is non-empty
            if not self._resp.data:
                raise G90Error(f"Missing data in response: '{payload}'")

            if self._resp.code != self._code:
                raise G90RetryableError(
                    'Wrong response - received code '
                    f"{self._resp.code}, expected code {self._code}")

        return self._resp.data or []

    def to_wire(self) -> bytes:
        """
        Returns the command in wire format.
        """
        wire = bytes(f'ISTART[{self._code},{self._code},{self._data}]IEND\0',
                     'utf-8')
        _LOGGER.debug('Encoded to wire format %s', wire)
        return wire

    def from_wire(self, data: bytes) -> BaseCommandsDataT:
        """
        Parses the response from the alarm panel.
        """
        _LOGGER.debug('To be decoded from wire format %s', data)
        try:
            decoded_data = data.decode('utf-8')
            if not decoded_data.startswith('ISTART'):
                raise G90Error('Missing start marker in data')
            if not decoded_data.endswith('IEND\0'):
                raise G90Error('Missing end marker in data')
            payload = decoded_data[6:-5]
            _LOGGER.debug("Decoded from wire: string '%s'", payload)

            if not payload:
                return []

            # Panel may report the last command has failed
            if payload == 'fail':
                raise G90CommandFailure(
                    f"Command {self._code.name}"
                    f" (code={self._code.value}) failed"
                )

            return self.decode_data(payload)
        except UnicodeDecodeError as exc:
            raise G90Error(
                'Unable to decode response from UTF-8'
            ) from exc

    @property
    def result(self) -> BaseCommandsDataT:
        """
        The result of the command.
        """
        if self._result is None:
            return []
        return self._result
