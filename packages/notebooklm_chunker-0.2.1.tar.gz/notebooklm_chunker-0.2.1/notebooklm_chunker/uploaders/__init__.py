"""Uploader implementations."""
