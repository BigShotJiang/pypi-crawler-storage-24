"""
Classes Module

Contains all class definitions used throughout the application.
"""

__version__ = "1.0.10"
__author__ = "GUIBRUSHR Team"
__description__ = "Classes Module for GUIBRUSHR"

import importlib
import sys

def __getattr__(name):
    """
    Lazy import classes when accessed (prevents circular imports).
    """
    class_module_map = {
        'Target': '.Target',
        'Instrument': '.Instrument',
        'Night': '.Night',
        'TemperatureProfile': '.TemperatureProfile',
        'UserTemperatureProfile': '.UserTemperatureProfile',
        'BestFitParametersAndResults': '.BestFitParametersAndResults',
        'ValueErrorTP': '.ValueErrorTP',
        'PDFViewer': '.PDFViewer'
    }

    if name in class_module_map:
        module = importlib.import_module(class_module_map[name], package=__name__)
        sys.modules[f"{__name__}.{name}"] = module
        return getattr(module, name)

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

__all__ = [
    'Target',
    'Instrument',
    'Night',
    'TemperatureProfile',
    'UserTemperatureProfile',
    'BestFitParametersAndResults',
    'ValueErrorTP',
    'PDFViewer'
]