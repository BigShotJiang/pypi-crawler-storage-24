import numpy as np

from GUIBRUSHR.General_Constants.Classes.TemperatureProfile import TemperatureProfile


class UserTemperatureProfile(TemperatureProfile):
    """
    User-extensible subclass of TemperatureProfile.

    Allows users to define custom temperature profile methods while
    inheriting all built-in profile types (isothermal, Guillot, Madhu, etc.).
    """

    def __init__(self, pressures, parameters, gravity, error, rng):
        """
        Initialize UserTemperatureProfile.

        Args:
            pressures (np.ndarray): Array of pressure levels.
            parameters (dict): Dictionary of parameter objects with values and errors.
            gravity (float): Gravitational acceleration.
            error (bool): Whether to compute error profiles.
            rng (np.random.Generator): Random number generator for error propagation.
        """
        super().__init__(pressures, parameters, gravity, error, rng)

