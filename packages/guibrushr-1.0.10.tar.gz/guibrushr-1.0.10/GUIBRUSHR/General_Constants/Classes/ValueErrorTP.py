"""
Value-error pair container for temperature profile parameters.

This module contains the ValueErrorTP class which stores a value
and its associated uncertainty, commonly used for temperature-pressure
profile parameters in atmospheric retrieval.
"""


class ValueErrorTP:
    """
    Container for storing a value with its associated error.

    This simple data class holds a parameter value and its optional
    uncertainty. It is primarily used for temperature profile (TP)
    parameters where both the central value and error estimate need
    to be tracked together.

    Attributes:
        value: The central parameter value
        error: The uncertainty/error on the value (optional)
    """

    def __init__(self, value, error=None):
        """
        Initialize a value-error pair.

        Args:
            value: The parameter value
            error: The uncertainty on the value (optional, defaults to None)
        """
        self.value = value
        self.error = error
