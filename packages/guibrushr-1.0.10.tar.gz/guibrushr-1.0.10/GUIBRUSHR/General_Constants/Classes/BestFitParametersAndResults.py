"""
Best-fit parameters and results data container for MCMC retrieval analysis.

This module contains the BestFitParametersAndResults class which stores
statistical results from MCMC atmospheric retrieval runs, including chain
medians, best-fit parameters, and likelihood values.
"""


class BestFitParametersAndResults:
    """
    Data container for MCMC retrieval statistics and results.

    This class stores the statistical outputs from MCMC retrieval runs,
    including chain quality metrics, best-fit parameters, medians, and
    likelihood values. It serves as a structured container for passing
    retrieval results between analysis components.

    Attributes:
        number_bad_chains: Number of chains identified as poor/outliers
        last_max_LH: Maximum log-likelihood from previous iteration
        current_max_likelihood: Current maximum log-likelihood value
        chi2_monodimensional: Flattened chi-square values from all chains
        list_best_pars: List of best-fit parameter values
        arr1: Array of parameter distributions (flattened chains)
        best_fit_parameters: Median values for each parameter
        value_fix: Values of fixed (non-fitted) parameters
        lista_par_fix: List of fixed parameter names
        lista_parametri: List of all parameter names (fitted + fixed)
        list_best_pars_labels: Labels corresponding to best-fit parameters
    """

    def __init__(self,
        number_bad_chains, last_max_LH, current_max_likelihood, chi2_monodimensional, list_best_pars, arr1, best_fit_parameters,
        value_fix, lista_par_fix, lista_parametri, list_best_pars_labels
    ):
        """
        Initialize the BestFitParametersAndResults data container.

        Args:
            number_bad_chains: Number of chains identified as outliers
            last_max_LH: Previous maximum log-likelihood
            current_max_likelihood: Current maximum log-likelihood
            chi2_monodimensional: Flattened chi-square array
            list_best_pars: Best-fit parameter values
            arr1: Flattened parameter chains
            best_fit_parameters: Parameter median values
            value_fix: Fixed parameter values
            lista_par_fix: Fixed parameter names
            lista_parametri: All parameter names
            list_best_pars_labels: Best-fit parameter labels
        """
        self.number_bad_chains = number_bad_chains
        self.last_max_LH = last_max_LH
        self.current_max_likelihood = current_max_likelihood
        self.chi2_monodimensional = chi2_monodimensional
        self.list_best_pars = list_best_pars
        self.arr1 = arr1
        self.best_fit_parameters = best_fit_parameters
        self.value_fix = value_fix
        self.lista_par_fix = lista_par_fix
        self.lista_parametri = lista_parametri
        self.list_best_pars_labels = list_best_pars_labels
