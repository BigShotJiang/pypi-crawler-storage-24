from numpy import array, append


class Instrument:
    """
    Represents an astronomical instrument with its spectral properties and observation nights.

    Attributes:
        name (str): Instrument name.
        path_instrument (str): Path to instrument data directory.
        resolution (float): Spectral resolution.
        hwhm_km_s (float): Half-width at half-maximum in km/s.
        wl_min (float): Minimum wavelength.
        wl_max (float): Maximum wavelength.
        nights (str): Underscore-separated observation date identifiers.
        dates (list): Individual date identifiers parsed from nights.
        ndate (int): Number of dates.
        nights_unique_bool (NDArray): Boolean array flagging unique night entries.
        night_arr (NDArray): Array of Night objects.
        lr_data: Low-resolution data associated with this instrument.
    """

    def __init__(self, name, path_instrument, resolution, hwhm_km_s=None, wl_min=None, wl_max=None, nights=None, lr_data=None):
        self.name = name
        self.path_instrument = path_instrument
        self.resolution = resolution
        self.hwhm_km_s = hwhm_km_s
        self.wl_min = wl_min
        self.wl_max = wl_max
        self.nights = nights
        if self.nights is not None:
            self.dates = self.nights.split('_')
            self.ndate = len(self.dates)
            nights = [
                night.replace('A', '').replace('B', '')
                for night in self.dates
            ]
            unique_night_flag = [
                night not in nights[0:i]
                for i, night in enumerate(nights)
            ]
            self.nights_unique_bool = array(unique_night_flag)
            self.night_arr = array([])
        else:
            self.ndate = self.dates = self.night_arr = self.nights_unique_bool = None
        self.lr_data = lr_data

    def append_night_obj(self, night_obj):
        """Append a Night object to the night_arr array."""
        self.night_arr = append(self.night_arr, night_obj)
