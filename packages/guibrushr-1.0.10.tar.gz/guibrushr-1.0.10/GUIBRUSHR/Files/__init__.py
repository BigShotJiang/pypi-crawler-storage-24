"""
Files package for GUIBRUSHR.
Contains data files, configuration, and resources.
"""
