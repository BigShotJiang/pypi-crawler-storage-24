# GUIBRUSHR/scripts/edit_config.py
"""
Configuration file manager for GUIBRUSHR.
Creates configuration.csv if missing, then opens it with nano.
"""

import subprocess
from pathlib import Path


def _get_config_path() -> Path:
    # __file__ = site-packages/GUIBRUSHR/scripts/edit_config.py
    return Path(__file__).parent.parent.resolve() / "Files" / "Configuration_Path" / "configuration.csv"


def edit_config_cli():
    config_path = _get_config_path()

    print("\n" + "=" * 50)
    print("GUIBRUSHR - Configuration File Manager")
    print("=" * 50)
    print(f"  Config path: {config_path}")
    print("=" * 50 + "\n")

    if not config_path.exists():
        print("Configuration file not found. Let's create it.\n")

        prt_path = input("Enter petitRADTRANS input_data path: ").strip()
        if not prt_path:
            print("Aborted: path cannot be empty.")
            return

        target_path = input("Enter target folders path: ").strip()
        if not target_path:
            print("Aborted: path cannot be empty.")
            return

        config_path.parent.mkdir(parents=True, exist_ok=True)
        with open(config_path, "w") as f:
            f.write("Element,Path\n")
            f.write(f"petitRadTrans_path,{prt_path}\n")
            f.write(f"path_target_folders,{target_path}\n")

        print(f"\n✓ Configuration file created at {config_path}")

    print(f"Opening {config_path.name} with nano...\n")
    subprocess.run(["nano", str(config_path)])


if __name__ == "__main__":
    edit_config_cli()
