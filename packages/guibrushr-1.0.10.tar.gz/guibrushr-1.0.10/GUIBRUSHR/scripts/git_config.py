# GUIBRUSHR/scripts/git_config.py
"""
Git configuration helper for GUIBRUSHR.
Marks configuration YAML files as skip-worktree so local
modifications are not tracked by Git.
Run once after cloning the repository.
"""

import subprocess
from pathlib import Path

YAML_FILENAMES = [
    "condensed.yaml",
    "general.yaml",
    "graphics.yaml",
    "hybrid_elements.yaml",
    "molecules.yaml",
    "parameters.yaml",
]

# ── Helpers ───────────────────────────────────────────────────────────────────

def _get_yaml_dir() -> Path:
    return Path(__file__).parent.parent.resolve() / "Files" / "Configuration_Yaml"

def _get_repo_root() -> Path | None:
    result = subprocess.run(
        ["git", "rev-parse", "--show-toplevel"],
        capture_output=True, text=True
    )
    return Path(result.stdout.strip()) if result.returncode == 0 else None

# ── Main ──────────────────────────────────────────────────────────────────────

def git_config_cli():
    print("\n" + "=" * 50)
    print("GUIBRUSHR - Git Configuration")
    print("=" * 50)

    repo_root = _get_repo_root()
    if repo_root is None:
        print("\n ✗ Not inside a Git repository.")
        print("   This command is only needed for Git-cloned installations.\n")
        return

    yaml_dir = _get_yaml_dir()
    try:
        rel_yaml_dir = yaml_dir.relative_to(repo_root)
    except ValueError:
        print(f"\n ✗ YAML directory is not inside the Git repository.")
        print(f"   YAML dir : {yaml_dir}")
        print(f"   Repo root: {repo_root}\n")
        return

    print(f"\n Repository : {repo_root}")
    print(f" YAML folder: {rel_yaml_dir}\n")

    errors = []
    for name in YAML_FILENAMES:
        rel_path = str(rel_yaml_dir / name)
        result = subprocess.run(
            ["git", "update-index", "--skip-worktree", rel_path],
            capture_output=True, text=True,
            cwd=repo_root
        )
        if result.returncode == 0:
            print(f"  ✓ {name}")
        else:
            print(f"  ✗ {name} — {result.stderr.strip()}")
            errors.append(name)

    if not errors:
        print("\n ✓ Done. Local changes to these files will not be tracked by Git.")
        print("   Run 'guibrushr-check-yaml-online' to detect upstream updates.\n")
    else:
        print(f"\n ⚠  {len(errors)} file(s) could not be configured.")
        print("    They may not exist yet. Run 'guibrushr-download' first.\n")

if __name__ == "__main__":
    git_config_cli()
