# GUIBRUSHR/scripts/help.py
"""
Help command for GUIBRUSHR.
Displays all available CLI commands with short descriptions.
"""

import importlib.metadata

# ── Command registry ──────────────────────────────────────────────────────────

_SECTIONS = [
    ("── Main ─────────────────────────────────────────────", [
        ("guibrushr",
         "Launch the GUIBRUSHR graphical user interface."),
    ]),
    ("── Setup & Data ──────────────────────────────────────", [
        ("guibrushr-download",
         "Download GUIBRUSHR data files on first run (~160 MB)."),
        ("guibrushr-tutorial-download",
         "Download tutorial data: petitRADTRANS opacities (~12 GB)\n"
         "    and WASP-77Ab target dataset (~200 MB)."),
    ]),
    ("── Configuration ─────────────────────────────────────", [
        ("guibrushr-config",
         "Create or edit the configuration file\n"
         "    (petitRADTRANS path, target folders path)."),
        ("guibrushr-yaml",
         "Interactively select and edit a configuration YAML file with nano."),
    ]),
    ("── Database ──────────────────────────────────────────", [
        ("guibrushr-db",
         "View and manage the database\n"
         "    (instruments, observatories, retrieval runs)."),
    ]),
    ("── Git / YAML Sync ───────────────────────────────────", [
        ("guibrushr-git-config",
         "Mark configuration YAML files as skip-worktree in Git\n"
         "    so local edits are never accidentally committed.\n"
         "    Run once after cloning the repository."),
        ("guibrushr-backup-yaml",
         "Save timestamped copies of all configuration YAML files\n"
         "    to Files/backup_yaml/ (local only, never synced)."),
        ("guibrushr-check-yaml-online",
         "Check whether configuration YAML files were updated remotely.\n"
         "    Git clone → compares with origin.\n"
         "    pip install → compares installed version with PyPI."),
    ]),
]

# ── Main ──────────────────────────────────────────────────────────────────────

def help_cli():
    try:
        version = importlib.metadata.version("guibrushr")
    except importlib.metadata.PackageNotFoundError:
        version = "unknown"

    print("\n" + "=" * 60)
    print(f"  GUIBRUSHR  v{version}  —  Available Commands")
    print("=" * 60)

    for section_title, commands in _SECTIONS:
        print(f"\n  {section_title}\n")
        for cmd, desc in commands:
            print(f"  {cmd}")
            for line in desc.split("\n"):
                print(f"    {line}")

    print("\n" + "=" * 60 + "\n")

if __name__ == "__main__":
    help_cli()
