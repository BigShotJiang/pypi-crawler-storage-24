# GUIBRUSHR/scripts/edit_yaml.py
"""
Interactive YAML editor launcher for GUIBRUSHR.
Opens a menu to select and edit configuration YAML files.
"""

import os
import subprocess
from pathlib import Path


def _get_yaml_dir() -> Path:
    # __file__ = site-packages/GUIBRUSHR/scripts/edit_yaml.py
    return Path(__file__).parent.parent.resolve() / "Files" / "Configuration_Yaml"


def edit_yaml_cli():
    yaml_dir = _get_yaml_dir()
    yaml_files = sorted(yaml_dir.glob("*.yaml"))

    if not yaml_files:
        print("No YAML files found in Configuration_Yaml/")
        return

    print("\n" + "=" * 50)
    print("GUIBRUSHR - Configuration YAML Editor")
    print("=" * 50)
    for i, f in enumerate(yaml_files, start=1):
        print(f"  {i}. {f.name}")
    print("  0. Exit")
    print("=" * 50)

    try:
        choice = int(input("\nSelect file to edit: "))
    except ValueError:
        print("Invalid input.")
        return

    if choice == 0:
        return

    if not (1 <= choice <= len(yaml_files)):
        print(f"Invalid choice. Please select between 1 and {len(yaml_files)}.")
        return

    selected = yaml_files[choice - 1]
    print(f"\nOpening {selected.name}...")
    subprocess.run(["nano", str(selected)])


if __name__ == "__main__":
    edit_yaml_cli()
