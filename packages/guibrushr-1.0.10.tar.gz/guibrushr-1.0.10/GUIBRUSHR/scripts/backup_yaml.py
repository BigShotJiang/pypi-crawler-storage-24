# GUIBRUSHR/scripts/backup_yaml.py
"""
Backup utility for GUIBRUSHR configuration YAML files.
Saves timestamped copies to Files/backup_yaml/.
That folder is listed in .gitignore: backups are never synced.
"""

import shutil
from datetime import datetime
from pathlib import Path

YAML_FILENAMES = [
    "condensed.yaml",
    "general.yaml",
    "graphics.yaml",
    "hybrid_elements.yaml",
    "molecules.yaml",
    "parameters.yaml",
]

# ── Helpers ───────────────────────────────────────────────────────────────────

def _get_yaml_dir() -> Path:
    return Path(__file__).parent.parent.resolve() / "Files" / "Configuration_Yaml"

def _get_backup_dir() -> Path:
    return Path(__file__).parent.parent.resolve() / "Files" / "backup_yaml"

# ── Main ──────────────────────────────────────────────────────────────────────

def backup_yaml_cli():
    print("\n" + "=" * 50)
    print("GUIBRUSHR - Configuration YAML Backup")
    print("=" * 50)

    yaml_dir = _get_yaml_dir()
    backup_dir = _get_backup_dir()
    backup_dir.mkdir(parents=True, exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    print(f"\n Timestamp : {timestamp}")
    print(f" Backup dir: {backup_dir}\n")

    backed_up = 0
    for name in YAML_FILENAMES:
        src = yaml_dir / name
        if src.exists():
            dst = backup_dir / f"{src.stem}_{timestamp}{src.suffix}"
            shutil.copy2(src, dst)
            print(f"  ✓ {name} → {dst.name}")
            backed_up += 1
        else:
            print(f"  ✗ {name} — not found, skipped.")

    print(f"\n ✓ Backup complete: {backed_up}/{len(YAML_FILENAMES)} files saved.\n")

if __name__ == "__main__":
    backup_yaml_cli()
