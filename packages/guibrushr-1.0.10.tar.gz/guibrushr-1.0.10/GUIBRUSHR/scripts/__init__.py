"""
Scripts Module for GUIBRUSHR

Contains utility scripts for setup, data download, and maintenance.
"""

__version__ = "1.0.10"
__author__ = "GUIBRUSHR Team"
__description__ = "Scripts Module for GUIBRUSHR"

import importlib
import sys


def __getattr__(name):
    if name in {"downloader", "edit_yaml", "edit_config", "edit_db", "download_test_data"}:
        module = importlib.import_module(f".{name}", package=__name__)
        sys.modules[f"{__name__}.{name}"] = module
        return module
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    "downloader",
    "edit_yaml",
    "edit_config",
    "edit_db",
    "download_test_data",
]
