import tkinter as tk

from GUIBRUSHR.General_Constants.Classes.PDFViewer import PDFViewer


class MyPDFWindow(tk.Toplevel):
    """
    A standalone Toplevel window for displaying PDF documents.

    Uses the PDFViewer class for rendering. Follows the same pattern as MyFigure.
    """

    def __init__(self, path_pdf, title="PDF Viewer"):
        """
        Initialize the PDF viewer window.

        Args:
            path_pdf: Path to the PDF file to display.
            title: Window title.
        """
        super().__init__()
        self.title(title)
        self.protocol("WM_DELETE_WINDOW", self.close_window)

        self.pdf_widget = PDFViewer(self, width=100, height=40, spacing3=5, bg="white")
        self.pdf_widget.pack(fill="both", expand=True)

        self.close_button = tk.Button(self, text="Close", command=self.close_window)
        self.close_button.pack()

        self.pdf_widget.show(path_pdf)

    def close_window(self):
        """Close and destroy the PDF viewer window."""
        self.destroy()
