from pathlib import Path
from tkinter import Frame
from typing import Any, Dict

from GUIBRUSHR.General_Constants.Classes.PDFViewer import PDFViewer


class MyPDF(Frame):
    """
    A custom PDF viewer widget that displays PDF documents in a Frame.
    
    This class creates a PDF viewer widget that can display PDF documents with customizable
    dimensions and styling. It uses a custom PDFViewer class for the actual PDF rendering.
    
    Attributes:
        path_test_pdf (str): Path to the default test PDF file
        width (int): Width of the PDF viewer
        height (int): Height of the PDF viewer
        pdf_widget (PDFViewer): The underlying PDF viewer widget
    """

    def __init__(
        self,
        parent: Any,
        row: int,
        column: int,
        width: int,
        height: int,
        path_default: [Path, str],
        columnspan: int = 2,
        rowspan: int = 1,
        **kwargs: Dict[str, Any]
    ) -> None:
        """
        Initialize the MyPDF widget.

        Args:
            parent: The parent widget
            row: Row position in the parent's grid
            column: Column position in the parent's grid
            width: Width of the PDF viewer
            height: Height of the PDF viewer
            path_default: Base path for finding the test PDF file
            columnspan: Number of columns the widget should span
            rowspan: Number of rows the widget should span
            **kwargs: Additional keyword arguments passed to the Frame widget
        """
        super().__init__(
            parent,
            bg="#FFFFFF",
            width=width,
            height=height,
            highlightbackground="black",
            highlightthickness=1,
            padx=5,
            pady=2,
            **kwargs,
        )
        
        # Grid the frame into the parent
        self.grid(row=row, column=column, columnspan=columnspan, rowspan=rowspan)
        
        # Set up the test PDF path
        self.path_test_pdf = str(Path.joinpath(path_default, "GUIBRUSHR", "Files", "Test", "test.pdf"))
        
        # Store dimensions
        self.width = width
        self.height = height
        
        # Create and configure the PDF viewer widget
        self.pdf_widget = PDFViewer(
            self,
            width=width,
            height=height,
            spacing3=5,
            bg='blue'
        )
        self.pdf_widget.grid(row=0, column=0, sticky='nsew')
        
        # Show the default test PDF
        self.show_pdf(self.path_test_pdf)

    def show_pdf(self, path_pdf: str) -> None:
        """
        Display a PDF file in the viewer.

        Args:
            path_pdf: Path to the PDF file to display
        """
        self.pdf_widget.show(path_pdf)
