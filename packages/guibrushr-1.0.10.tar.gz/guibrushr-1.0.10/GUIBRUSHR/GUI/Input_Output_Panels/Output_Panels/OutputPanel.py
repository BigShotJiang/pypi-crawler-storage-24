"""
Output Panel module for GUIBRUSHR application.

This module contains the OutputPanel class which serves as a container for output-related
components including a table panel and button panel for data retrieval.

The OutputPanel is responsible for:
- Displaying data in a tabular format
- Providing buttons for data retrieval operations
- Managing the layout of output components
- Handling exceptions during data operations
"""

from GUIBRUSHR.GUI.LAYOUT.MyPanel import MyPanel
from GUIBRUSHR.GUI.Input_Output_Panels.Output_Panels.PanelButtonRetrieval import PanelButtonRetrieval
from GUIBRUSHR.GUI.Input_Output_Panels.Output_Panels.PanelTableRetrieval import PanelTableRetrieval


class OutputPanel(MyPanel):
    """
    A panel class that manages the output interface components of the application.
    
    This class extends MyPanel to create a container that holds both a table panel
    for displaying data and a button panel for data retrieval operations.
    
    The panel is organized in a grid layout with:
    - Table panel on the left (column 1)
    - Button panel on the right (column 2)
    
    Attributes:
        width_GUI (int): The width of the GUI panel in pixels
        parent: The parent widget of this panel
        path_default (str): Default path for file operations
        panel_table (PanelTableRetrieval): Panel for displaying data in table format
        panel_buttons (PanelButtonRetrieval): Panel containing retrieval operation buttons
        global_exc (int): Global exception counter for tracking errors
    """

    def __init__(self, parent, row, column, color, path_default, width_GUI, height_frame, window, **kwargs):
        """
        Initialize the OutputPanel with its components.

        Args:
            parent: The parent widget that contains this panel
            row (int): Row position in the grid layout
            column (int): Column position in the grid layout
            color (str): Background color of the panel
            path_default (Path, str): Default path for file operations
            width_GUI (int): Width of the GUI panel in pixels
            height_frame (int): Height of the frame in pixels
            window: The main window instance
            **kwargs: Additional keyword arguments passed to the parent class

        Note:
            The panel is initialized with two sub-panels:
            1. A table panel for data display (PanelTableRetrieval)
            2. A button panel for data operations (PanelButtonRetrieval)
        """
        # Initialize the parent MyPanel class
        super().__init__(window, color, row, column, width=width_GUI, height=height_frame, **kwargs)
        
        # Store instance variables for panel configuration
        self.width_GUI = width_GUI
        self.parent = parent
        self.path_default = path_default
        
        # Initialize sub-panels with specific positions in the grid
        # Table panel is placed in column 0
        self.panel_table = PanelTableRetrieval(self, color, 0, 1, width_GUI)
        # Button panel is placed in column 1
        self.panel_buttons = PanelButtonRetrieval(self, color, 0, 2)
        
        # Initialize global exception counter for error tracking
        self.global_exc = 1







