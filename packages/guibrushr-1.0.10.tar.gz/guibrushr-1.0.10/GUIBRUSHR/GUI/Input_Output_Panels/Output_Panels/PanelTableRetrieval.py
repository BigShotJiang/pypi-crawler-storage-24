from GUIBRUSHR.GUI.LAYOUT.MyPanel import MyPanel
from GUIBRUSHR.GUI.WIDGET.MyTable import MyTable
from GUIBRUSHR.General_Constants.FunctionsAndConstants.Constant_Variables import ConstantVariables
from typing import Any, Dict


class PanelTableRetrieval(MyPanel):
    """
    A panel class that displays a table for data retrieval in the GUI.
    
    This panel creates and manages a table widget that displays output data
    with specific column widths calculated based on the GUI width.
    
    Attributes:
        parent: The parent widget of this panel
        table: The table widget instance for displaying data
        global_exc: A global exception counter or flag
    """

    def __init__(self, parent: Any, color: str, row: int, column: int, width_GUI: int, **kwargs: Dict[str, Any]) -> None:
        """
        Initialize the PanelTableRetrieval.

        Args:
            parent: The parent widget
            color: Background color for the panel
            row: Row position in the parent layout
            column: Column position in the parent layout
            width_GUI: Total width of the GUI window
            **kwargs: Additional keyword arguments passed to the parent class
        """
        super().__init__(parent, color, row, column, **kwargs)
        self.parent = parent
        
        # Calculate minimum block size based on GUI width (reduced to make space for help button)
        minimum_block = int((width_GUI - 150) / 25)

        # Define column widths based on minimum block size
        width_columns = [
            minimum_block * 3,  # Column 1: PID
            minimum_block * 3,  # Column 2: Target
            minimum_block * 3,  # Column 3: Instruments
            minimum_block * 3,  # Column 4: ID
            minimum_block * 12, # Column 5: Output (reduced to make space for help button)
        ]
        
        # Initialize the table with specified columns and height
        self.table = MyTable(
            self,
            ConstantVariables.LIST_OUTPUT_TABLE_COLUMN,
            width_columns,
            height=6
        )
        
        # Initialize global exception counter
        self.global_exc = 1




