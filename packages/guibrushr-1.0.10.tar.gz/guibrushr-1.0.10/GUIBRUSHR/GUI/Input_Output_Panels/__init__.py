"""
Input/Output Panels Module

Contains all input and output panel components for the GUI.
"""

__version__ = "1.0.10"
__author__ = "GUIBRUSHR Team"
__description__ = "Input/Output Panels Module for GUIBRUSHR"

# ---------------------------------------------------------------------
# Lazy loading to prevent circular imports
# ---------------------------------------------------------------------
import importlib
import sys

def __getattr__(name):
    """
    Lazy import panel submodules when accessed (prevents circular imports).
    """
    if name in {"Input_Panels", "Output_Panels"}:
        module = importlib.import_module(f".{name}", package=__name__)
        sys.modules[f"{__name__}.{name}"] = module
        return module

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

__all__ = [
    'Input_Panels',
    'Output_Panels'
]