"""
Frame Filter Table Module.

This module contains the FrameFilterTable class which combines frame filtering,
table display, and frame visualization functionality in a unified panel.
"""

from GUIBRUSHR.GUI.Input_Output_Panels.Input_Panels.TabPanels.Frame_Retrieval_Analysis.FrameFilterTable.FrameDisplay import (
    FrameDisplay
)
from GUIBRUSHR.GUI.LAYOUT.MyPanel import MyPanel
from GUIBRUSHR.GUI.Input_Output_Panels.Input_Panels.TabPanels.Frame_Retrieval_Analysis.FrameFilterTable.FrameTable import (
    FrameTable
)
from GUIBRUSHR.GUI.Input_Output_Panels.Input_Panels.TabPanels.Frame_Retrieval_Analysis.FrameFilterTable.FrameFilter import (
    FrameFilter
)
from GUIBRUSHR.General_Constants.FunctionsAndConstants.Constant_Variables import ConstantVariables


class FrameFilterTable(MyPanel):
    """
    A composite panel that combines frame filtering, table display, and frame visualization.
    
    This class creates a unified interface containing three main components:
    - Frame filter controls for searching and filtering
    - Frame table for displaying filtered results
    - Frame display for visualizing selected frames
    
    The class inherits from MyPanel and organizes the components in a vertical layout.
    """

    def __init__(self, parent, row, column, color, width_GUI, path_default, frame_input, **kwargs):
        """
        Initialize the FrameFilterTable panel.
        
        Args:
            parent: The parent widget
            row: Grid row position
            column: Grid column position
            color: Background color for the panel
            width_GUI: Width of the GUI components
            path_default: Default path for file operations
            frame_input: Input frame data
            **kwargs: Additional keyword arguments passed to parent class
        """
        # Store parent reference
        self.parent = parent
        
        # Initialize parent class with layout parameters
        super(FrameFilterTable, self).__init__(
            parent, color, row, column, width=width_GUI, **kwargs
        )
        
        # Initialize frame filter component (row 0)
        # Provides search and filtering controls
        self.frame_filter = FrameFilter(
            self, 0, 1, ConstantVariables.COLOR_SUB_NOTEBOOK_2, width_GUI, path_default
        )
        
        # Initialize frame table component (row 1)
        # Displays filtered frame data in tabular format
        self.frame_table = FrameTable(
            self, 1, 1, ConstantVariables.COLOR_SUB_NOTEBOOK_2, width_GUI, path_default
        )
        
        # Initialize frame display component (row 2)
        # Provides visual representation of selected frames
        self.frame_display = FrameDisplay(
            self, 2, 1, ConstantVariables.COLOR_SUB_NOTEBOOK_2, frame_input
        )
        
        # Connect filter search button to table update functionality
        # This ensures that when search is triggered, the table refreshes with filtered results
        self.frame_filter.search_button.button.configure(command=self.frame_table.update_table)
        
        # Global exception flag (purpose to be documented based on usage context)
        self.global_exc = 1



