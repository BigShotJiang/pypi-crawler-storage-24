"""
FrameDBInteractions module for handling database interaction panels in the GUI.

This module provides the main panel for database interactions, including target,
instrument, observatory, and molecule parameters frame management.
"""

# Standard library imports
# Third-party imports
# Local application imports
from GUIBRUSHR.GUI.Input_Output_Panels.Input_Panels.TabPanels.FrameDBInteractions.FrameInstrument import FrameInstrument
from GUIBRUSHR.GUI.Input_Output_Panels.Input_Panels.TabPanels.FrameDBInteractions.FrameObservatories import FrameObservatories
from GUIBRUSHR.GUI.Input_Output_Panels.Input_Panels.TabPanels.FrameDBInteractions.Frame_Target import FrameTarget
from GUIBRUSHR.GUI.Input_Output_Panels.Input_Panels.TabPanels.FrameDBInteractions.FrameParams import FrameParams
from GUIBRUSHR.GUI.Input_Output_Panels.Input_Panels.TabPanels.FrameDBInteractions.FrameConvertOpacity import FrameConvertOpacity
from GUIBRUSHR.GUI.LAYOUT.MyPanel import MyPanel


class FrameDBInteractions(MyPanel):
    """
    Panel class for managing database interactions in the GUI.

    This class creates and manages the target, instrument, observatory, and molecule parameters
    frames for database interactions, inheriting from MyPanel for basic panel functionality.
    """

    def __init__(self, parent, color, row, column, path_default, frame_input, window, **kwargs):
        """
        Initialize the FrameDBInteractions panel.

        Args:
            parent: Parent widget
            color: Color scheme for the panel
            row: Row position in the parent layout
            column: Column position in the parent layout
            path_default: Default path for file operations
            frame_input: Input frame reference
            window: Main window reference
            **kwargs: Additional keyword arguments for parent class
        """
        # Initialize parent class
        super().__init__(parent, color, row, column, **kwargs)

        # Store instance variables
        self.path_folder_targets = frame_input.frame_path.path_folder_targets.get_text()
        self.global_exc = 0
        self.frame_input = frame_input
        self.path_default = path_default
        self.window = window
        self.color = color

        # Initialize sub-frames
        self.frame_target = FrameTarget(
            self, color, 0, 1, path_default, frame_input, window, columnspan=2
        )
        self.frame_instrument = FrameInstrument(
            self, color, 1, 1, path_default, frame_input, window, columnspan=2
        )
        self.frame_observatories = FrameObservatories(
            self, color, 2, 1, path_default, frame_input, window, columnspan=2
        )
        self.frame_params = FrameParams(
            self, color, 3, 1, path_default
        )
        self.frame_convert_opacity = FrameConvertOpacity(
            self, color, 3, 2, path_default
        )

