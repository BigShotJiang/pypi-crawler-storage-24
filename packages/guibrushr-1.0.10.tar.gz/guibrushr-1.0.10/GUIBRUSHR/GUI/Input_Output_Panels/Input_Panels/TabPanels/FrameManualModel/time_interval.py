#!/usr/bin/env python3
"""
Time interval sleep utility.

This script takes a time interval in milliseconds as a command-line argument
and pauses execution for the specified duration.
"""

import sys
import time


def sleep_for_interval(interval_ms: int) -> None:
    """
    Sleep for the specified time interval in milliseconds.

    Args:
        interval_ms: Time interval in milliseconds to sleep for
    """
    time.sleep(interval_ms / 1000)


def main() -> None:
    """Main function to handle command-line argument and execute sleep."""
    if len(sys.argv) != 2:
        print("Usage: python time_interval.py <interval_ms>")
        sys.exit(1)

    try:
        interval = int(sys.argv[1])
        sleep_for_interval(interval)
    except ValueError:
        print("Error: Interval must be a valid integer")
        sys.exit(1)


if __name__ == "__main__":
    main()
