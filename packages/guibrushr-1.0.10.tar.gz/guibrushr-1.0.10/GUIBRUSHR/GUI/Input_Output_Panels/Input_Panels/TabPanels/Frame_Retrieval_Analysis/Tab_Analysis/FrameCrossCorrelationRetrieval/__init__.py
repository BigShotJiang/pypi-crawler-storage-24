"""
Frame Cross Correlation Retrieval Module

Contains components for cross-correlation retrieval analysis.
"""

__version__ = "1.0.10"
__author__ = "GUIBRUSHR Team"
__description__ = "Frame Cross Correlation Retrieval Module for GUIBRUSHR"

# ---------------------------------------------------------------------
# Lazy loading to prevent circular imports
# ---------------------------------------------------------------------
import importlib
import sys

def __getattr__(name):
    """
    Lazy import cross-correlation retrieval components when accessed (prevents circular imports).
    """
    if name == "FrameCCRetrieval":
        module = importlib.import_module(".FrameCCRetrieval", package=__name__)
        sys.modules[f"{__name__}.FrameCCRetrieval"] = module
        return getattr(module, name)

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

__all__ = [
    "FrameCCRetrieval"
]
