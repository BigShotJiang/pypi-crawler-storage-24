"""
ManualModelObjClass module for handling manual model parameters and configurations.

This class manages the parameters and settings for manual model calculations,
including molecular data, resolution settings, temperature ranges, and various
model configurations.
"""


class ManualModelObjClass:
    """
    A class to handle manual model parameters and configurations.

    This class stores and manages all parameters needed for manual model calculations,
    including molecular data, resolution settings, temperature ranges, and various
    model configurations.
    """

    def __init__(
        self,
        param_array,
        molecs,
        condensed,
        hybrid,
        resolution,
        continum_opacity,
        target,
        chemistry,
        ecc_opi,
        # model_reprocessing,
        format_temperature,
        table_output_file,
        filename_results,
        id_process,
        path_results,
        mass_vector,
        temp_min,
        temp_max,
        temp_step,
        rad_mode,
        retrieval_model,
        manual_model_composition,
        maxsteps=1,
        rv_sampling=0.1,
        stellar_spectrum=None,
        path_targets="",
        additional_opac=False
    ):
        """
        Initialize the ManualModelObjClass with all necessary parameters.

        Args:
            param_array: Array of parameters for the model
            molecs: Molecular data
            condensed: Condensed data
            hybrid: hybrid list parameters
            resolution: Resolution settings
            continum_opacity: Continuum opacity settings
            target: Target object
            chemistry: Chemistry settings
            ecc_opi: ECC opacity settings
            format_temperature: Temperature format
            table_output_file: Output table file
            filename_results: Results filename
            id_process: Process ID
            path_results: Path to results
            mass_vector: Mass vector data
            temp_min: Minimum temperature
            temp_max: Maximum temperature
            temp_step: Temperature step
            rad_mode: Radiation mode
            retrieval_model: Retrieval model settings
            manual_model_composition: Manual model composition
            maxsteps: Maximum number of steps (default: 1)
            rv_sampling: RV sampling value (default: 0.1)
            stellar_spectrum: Path to stellar spectrum (default: None)
            path_targets: Path to targets (default: "")
            additional_opac: Additional opacity flag (default: False)
        """
        # Model parameters
        self.param_array = param_array
        self.molecs = molecs
        self.condensed = condensed
        self.hybrid = hybrid
        self.resolution = resolution
        
        # Instrument settings
        self.instruments_HR = []
        self.instruments_LR = []
        
        # Opacity and target settings
        self.continum_opacity = continum_opacity.split(",")
        self.target = target
        self.chemistry = chemistry
        self.ecc_opi = ecc_opi
        self.tell_rm_method = ""
        self.model_reprocessing = None
        self.standardize_PCA = None
        
        # Output settings
        self.format_temperature = format_temperature
        self.table_output_file = table_output_file
        self.filename_results = filename_results
        self.order_sel = ""
        self.id_process = id_process
        self.path_results = path_results
        
        # Temperature and mass settings
        self.mass_vector = mass_vector
        self.temp_min = temp_min
        self.temp_max = temp_max
        self.temp_step = temp_step
        
        # Model configuration
        self.rad_mode = rad_mode
        self.retrieval_model = retrieval_model
        self.manual_model_composition = manual_model_composition
        self.maxsteps = maxsteps
        self.rv_sampling = rv_sampling
        
        # Path settings
        self.path_stellar_spectrum = stellar_spectrum
        self.path_targets = path_targets
        self.additional_opac = additional_opac
