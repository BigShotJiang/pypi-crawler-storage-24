"""
Frame Cross-Correlation Retrieval Module.

This module provides the FrameCCRetrieval class which manages cross-correlation
retrieval analysis functionality in the GUI application. It creates a panel
containing a cross-correlation notebook for data analysis operations.

The module integrates with the broader GUIBRUSHR framework to provide
cross-correlation analysis capabilities for spectroscopic data retrieval.
"""

# Standard library imports
# (None required for this module)

# Third-party imports
# (None required for this module)

# Local application imports
from GUIBRUSHR.GUI.Input_Output_Panels.Input_Panels.Frame_Cross_Correlation.Notebook_Cross_Correlation import (
    NotebookCrossCorrelation
)
from GUIBRUSHR.GUI.LAYOUT.MyPanel import MyPanel
from GUIBRUSHR.General_Constants.FunctionsAndConstants.Constant_Variables import ConstantVariables


class FrameCCRetrieval(MyPanel):
    """
    Frame for Cross-Correlation Retrieval Analysis.
    
    This class creates a panel that manages cross-correlation retrieval analysis
    functionality. It inherits from MyPanel and contains a NotebookCrossCorrelation
    widget for organizing cross-correlation analysis operations.
    
    The panel serves as a container for cross-correlation analysis tools and
    provides integration with the main GUI framework for data retrieval operations.
    
    Attributes:
        global_exc (int): Global exception flag for initialization tracking
        frame_input: Reference to the input frame widget
        frame_input_big: Reference to the larger input frame widget
        path_default: Default path for file operations
        window: Reference to the main application window
        color (str): Background color of the panel
        notebook_CC (NotebookCrossCorrelation): Cross-correlation notebook widget
    """

    def __init__(self, parent, color, row, column, path_default, frame_input, 
                 frame_input_big, width_GUI, height_GUI, window, **kwargs):
        """
        Initialize the FrameCCRetrieval panel.
        
        Creates a cross-correlation retrieval panel with a notebook widget
        for organizing analysis operations. The initialization follows a specific
        sequence to ensure proper widget creation and configuration.
        
        Args:
            parent: Parent widget that contains this panel
            color (str): Background color for the panel
            row (int): Row position in the parent's grid layout
            column (int): Column position in the parent's grid layout
            path_default: Default path for file operations and data storage
            frame_input: Reference to the input frame widget
            frame_input_big: Reference to the larger input frame widget
            width_GUI (int): Width of the GUI panel in pixels
            height_GUI (int): Height of the GUI panel in pixels
            window: Reference to the main application window
            **kwargs: Additional keyword arguments passed to the parent class
        """
        # Initialize global exception flag to prevent premature execution
        # This flag is used to control when the panel is fully initialized
        self.global_exc = 0
        
        # Store essential references for cross-correlation operations
        self.frame_input = frame_input
        self.frame_input_big = frame_input_big
        self.path_default = path_default
        self.window = window
        self.color = color
        
        # Initialize the parent MyPanel class with grid positioning
        super().__init__(parent, color, row, column, **kwargs)
        
        # Create the cross-correlation notebook widget
        # This notebook contains tabs for different cross-correlation analysis operations
        self.notebook_CC = NotebookCrossCorrelation(
            parent=self,
            color=color,
            row=0,
            column=1,
            path_default=path_default,
            frame_input=frame_input_big,
            window=window,
            tab_list=ConstantVariables.list_tab_cross_correlation_1,
            width_gui=width_GUI,
            height_gui=height_GUI,
            filters_and_table=self.frame_input.frame_filter_table
        )
        
        # Mark initialization as complete
        # This allows other components to safely interact with this panel
        self.global_exc = 1
