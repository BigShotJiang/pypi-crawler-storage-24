"""
FrameParameter module that handles the main parameter frame for the GUI application.
This module manages the interaction between different parameter panels and their updates.
"""

from pathlib import Path
from typing import Any, Dict

from GUIBRUSHR.GUI.Input_Output_Panels.Input_Panels.TabPanels.Frame_Parameters.PanelParameters import PanelParameters
from GUIBRUSHR.GUI.Input_Output_Panels.Input_Panels.TabPanels.Frame_Parameters.PanelStart import PanelStart
from GUIBRUSHR.GUI.Input_Output_Panels.Input_Panels.TabPanels.Frame_Parameters.PanelInfo import PanelInfo
from GUIBRUSHR.GUI.LAYOUT.MyPanel import MyPanel


class FrameParameter(MyPanel):
    """
    A frame that manages parameter panels and their interactions in the GUI.

    This class coordinates between different parameter panels (Info, Parameters, Start)
    and handles their update callbacks.
    """

    def __init__(
        self,
        parent: Any,
        row: int,
        column: int,
        color: str,
        path_default: str,
        frame_input: Any,
        **kwargs: Dict[str, Any]
    ) -> None:
        """
        Initialize the FrameParameter.

        Args:
            parent: The parent widget
            row: Row position in the grid
            column: Column position in the grid
            color: Background color for the frame
            path_default: Default path for configuration files
            frame_input: Input frame reference
            **kwargs: Additional keyword arguments passed to the parent class
        """
        self.path_default = path_default
        self.frame_input = frame_input

        # Initialize parent class
        super(FrameParameter, self).__init__(parent, color, row, column, **kwargs)

        self.color = color
        # Initialize panels
        self._initialize_panels()

        # Set up event bindings
        self._setup_event_bindings()

        # Global execution flag
        self.global_exc = 1

    def _initialize_panels(self) -> None:
        """Initialize all parameter panels."""
        self.panel_info = PanelInfo(self, 0, 0, self.color, self.path_default)
        self.panel_param = PanelParameters(self, 1, 0, self.color, self.path_default)
        self.panel_start = PanelStart(
            self,
            2,
            0,
            self.color,
            str(Path(self.path_default, "GUIBRUSHR", "Retrieval", "main.py")),
            self.path_default
        )

    def _setup_event_bindings(self) -> None:
        """Set up all event bindings between panels."""
        # Temperature profile updates
        self.panel_info.dropdown_t_p_profile.chosen_var.trace(
            "w", lambda *args: self.panel_param.update_tp_params()
        )

        # Instrument-specific updates
        self.panel_info.dropdown_hr_instrument.chosen_var.trace(
            "w", lambda *args: self.panel_param.update_hr_pixeldv()
        )
        self.panel_info.dropdown_lr_instrument.chosen_var.trace(
            "w", lambda *args: self.panel_param.update_lr_pixeldv()
        )

        # Chemistry and target updates
        self.panel_info.dropdown_chemistry.chosen_var.trace(
            "w", lambda *args: self.panel_param.update_chemistry()
        )
        self.panel_info.dropdown_target.chosen_var.trace(
            "w", lambda *args: self.panel_param.update_target()
        )

        # Resolution updates
        self.panel_info.dropdown_resolution.chosen_var.trace(
            "w", lambda *args: self.panel_param.update_LR()
        )

        # Checkbox updates
        self.panel_info.check_ecc_opi.var.trace(
            "w", lambda *args: self.panel_param.ecc_opi_check()
        )
        self.panel_info.check_scattering.var.trace(
            "w", lambda *args: self.panel_param.scattering_check()
        )
        self.panel_info.check_nights_sim.var.trace(
            "w", lambda *args: self.panel_param.update_night_sim()
        )
        self.panel_info.checkbox_include_h_m.var.trace(
            "w", lambda *args: self.panel_param.include_h_m()
        )

        self.panel_info.checkbox_use_hr_linelist_for_lr.var.trace(
            "w", lambda *args: self.panel_param.adjust_LR_list(
                False, self.panel_info.checkbox_use_hr_linelist_for_lr.get_value()
            )
        )

        # Radiation mode updates
        self.panel_info.dropdown_rad_mode.chosen_var.trace(
            "w", lambda *args: self.panel_param.update_from_rad_mode()
        )

