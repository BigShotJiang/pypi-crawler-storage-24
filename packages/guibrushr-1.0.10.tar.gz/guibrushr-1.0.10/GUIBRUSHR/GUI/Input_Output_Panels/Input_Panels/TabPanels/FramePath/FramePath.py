from pathlib import Path
from pandas import read_csv
import webbrowser

from GUIBRUSHR.GUI.LAYOUT.MyPanel import MyPanel
from GUIBRUSHR.GUI.LAYOUT.ScaleManager import ScaleManager
from GUIBRUSHR.GUI.WIDGET.MyImage import MyImage
from GUIBRUSHR.GUI.WIDGET.MyLabel import MyLabel
from GUIBRUSHR.GUI.WIDGET.MyTextField import MyTextField
from GUIBRUSHR.General_Constants.Classes.HelpButton import HelpButton


class FramePath(MyPanel):
    """
    A panel class that manages path configurations and displays the GUIBRUSHR logo.
    
    This class creates a panel with text fields for various path configurations
    and displays the GUIBRUSHR logo image. It reads path configurations from a CSV file
    and allows users to modify these paths through text fields.
    
    Attributes:
        frame_input: Parent frame input reference
        path_default: Default base path for the application
        panel_path: Panel containing path configuration text fields
        panel_picture: Panel containing the GUIBRUSHR logo
        guibrush: Image widget displaying the GUIBRUSHR logo
        global_exc: Global exception flag
    """

    def __init__(self, parent, row, column, color, path_default, frame_input, width, height, **kwargs):
        """
        Initialize the FramePath panel.

        Args:
            parent: Parent widget
            row (int): Row position in the parent grid
            column (int): Column position in the parent grid
            color (str): Background color for the panel
            path_default (Path): Default base path for the application
            frame_input: Reference to the input frame
            width (int): Width of the panel
            height (int): Height of the panel
            **kwargs: Additional keyword arguments passed to the parent class
        """
        self.frame_input = frame_input
        super().__init__(parent, color, row, column, **kwargs)
        self.path_default = path_default

        # Read path configurations from CSV file
        config_path = Path(self.path_default, "GUIBRUSHR", "Files", "Configuration_Path", "configuration.csv")
        df = read_csv(str(config_path))
        paths = df["Path"]

        # Create panel for path configurations
        self.panel_path = MyPanel(self, color, 0, 1)

        # Help text dictionary
        help_text = {
            "petitRADTRANS path": "Absolute path to the petitRADTRANS input_data directory. This directory contains all opacity tables, line lists, and molecular data required for radiative transfer calculations. Must match the 'prt_input_data_path' in the petitRADTRANS configuration file (~/.petitradtrans/petitradtrans_config_file.ini). Example: /path/to/petitRADTRANS/input_data/",

            "Input targets": "Absolute path to the root directory containing all target observation data. Each subdirectory within this path should correspond to a specific target (exoplanet) and contain organized observational data from different instruments and observing nights. Structure: /path/to/targets/[TargetName]/[RadMode]/[Instrument]/[Date]/..."
        }

        # Create help button
        self.help_button = HelpButton(
            self.panel_path, 0, 0,
            "Path Configuration Help",
            help_text,
            columnspan=1
        )
        self.help_button.button.grid(rowspan=2)  # Span across both rows

        # Initialize path configuration text fields
        self.path_petitRADTRANS = MyTextField(
            self.panel_path, 0, 1,
            text=str(paths[0]),
            label_text="petitRADTRANS path",
            color=color
        )

        self.path_folder_targets = MyTextField(
            self.panel_path, 1, 1,
            text=str(paths[1]),
            label_text="Input targets",
            color=color
        )

        # Create panel for the GUIBRUSHR logo
        self.panel_link = MyPanel(self, color, 1, 1)

        # Add manual link section - Label text
        self.manual_label = MyLabel(
            self.panel_link, 0, 1,
            color=color,
            label_text="To see the complete manual go to:",
            font=ScaleManager.get().font_label_normal if ScaleManager.get() else ("Arial", 10, "normal")
        )

        # Clickable link
        manual_url = "https://www.ict.inaf.it/gitlab/guibrushr/guibrushr/-/blob/main/GUIBRUSHR_Manual.pdf"  # Update with actual documentation URL
        self.manual_link = MyLabel(
            self.panel_link, 0, 2,
            color=color,
            label_text=manual_url,
            font=ScaleManager.get().font_link if ScaleManager.get() else ("Arial", 10, "underline"),
            fg="blue",
            cursor="hand2"
        )

        # Bind click event to open URL
        self.manual_link.label.bind("<Button-1>", lambda e: webbrowser.open_new(manual_url))


        # Create panel for the GUIBRUSHR logo
        self.panel_picture = MyPanel(self, color, 2, 1)

        # Calculate logo dimensions
        width_plot = int(width / 1.6)
        height_plot = int(height / 1.6)

        # Initialize GUIBRUSH logo image
        logo_path = Path.joinpath(path_default, "GUIBRUSHR", "Files", "guibrushr.jpeg")
        self.guibrush = MyImage(
            self.panel_picture, 6, 1,
            width_plot, height_plot,
            str(logo_path),
            columnspan=8,
            rowspan=2
        )

        # Initialize global exception flag
        self.global_exc = 1


