from GUIBRUSHR.GUI.Input_Output_Panels.Input_Panels.TabPanels.Frame_Retrieval_Analysis.Tab_Analysis.FrameCrossCorrelationRetrieval.FrameCCRetrieval import FrameCCRetrieval
from GUIBRUSHR.GUI.LAYOUT.MyPanel import MyPanel
from GUIBRUSHR.GUI.LAYOUT.MyTabPanel import MyTabPanel
from GUIBRUSHR.GUI.Input_Output_Panels.Input_Panels.TabPanels.Frame_Retrieval_Analysis.FrameFilterTable.FrameFilterTable import FrameFilterTable
from GUIBRUSHR.GUI.Input_Output_Panels.Input_Panels.TabPanels.Frame_Retrieval_Analysis.Tab_Analysis.FrameCornerPlot.FrameCornerPlot import FrameCornerPlot
from GUIBRUSHR.GUI.Input_Output_Panels.Input_Panels.TabPanels.Frame_Retrieval_Analysis.Tab_Analysis.Frame_Model_Plot.Frame_Model_Plot import FrameModelPlot
from GUIBRUSHR.GUI.Input_Output_Panels.Input_Panels.TabPanels.Frame_Retrieval_Analysis.Tab_Analysis.Frame_Delete_Retrieval.Frame_Delete_Retrieval import FrameDeleteRetrieval
from GUIBRUSHR.General_Constants.FunctionsAndConstants.Constant_Variables import ConstantVariables


class FrameRetrievalAnalysis(MyPanel):

    def __init__(self, parent, row, column, color, path_default, frame_input, width_GUI, height_GUI, window, **kwargs):
        self.path_default = path_default
        self.frame_input = frame_input
        super().__init__(parent, color, row, column, **kwargs)
        # Filter Table Panel
        self.frame_filter_table = FrameFilterTable(self, 0, 0, ConstantVariables.COLOR_SUB_NOTEBOOK_2, width_GUI, path_default, frame_input)
        # Tab Manager
        self.tab_manager = MyTabPanel(parent=self, tab_list=ConstantVariables.list_tab_analysis, row=1, column=0, width=width_GUI + 100)
        # frame corner
        self.frame_corner_plot = FrameCornerPlot(self.tab_manager.tab_list[0], ConstantVariables.COLOR_SUB_NOTEBOOK_2, 0, 1, path_default, self, width_GUI, height_GUI, window)
        # frame model
        self.frame_model_plot = FrameModelPlot(self.tab_manager.tab_list[1], ConstantVariables.COLOR_SUB_NOTEBOOK_2, 0, 1, path_default, self, width_GUI, height_GUI, window)
        # frame cc retrieval
        self.frame_cc_retrieval = FrameCCRetrieval(
            self.tab_manager.tab_list[2], ConstantVariables.COLOR_SUB_NOTEBOOK_2, 0, 1, path_default,
            self, frame_input, width_GUI, height_GUI, window,
        )
        # frame delete
        self.frame_delete_retrieval = FrameDeleteRetrieval(self.tab_manager.tab_list[3], ConstantVariables.COLOR_SUB_NOTEBOOK_2, 0, 1, path_default, self, window)
        self.global_exc = 1
