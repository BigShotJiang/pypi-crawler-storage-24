"""
Frame Manual Model Module

Contains components for manual model configuration and input.
"""

__version__ = "1.0.10"
__author__ = "GUIBRUSHR Team"
__description__ = "Frame Manual Model Module for GUIBRUSHR"

# ---------------------------------------------------------------------
# Lazy loading to prevent circular imports
# ---------------------------------------------------------------------
import importlib
import sys

def __getattr__(name):
    """
    Lazy import manual model components when accessed (prevents circular imports).
    """
    # Currently no components defined, but structure is ready for future additions
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

__all__ = []
