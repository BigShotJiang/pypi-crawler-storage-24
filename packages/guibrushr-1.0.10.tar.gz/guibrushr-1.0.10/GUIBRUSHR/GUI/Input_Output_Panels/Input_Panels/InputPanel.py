"""
Input Panel Module

This module defines the InputPanel class which serves as the main container for all input-related panels
in the GUI application. It manages multiple tab panels for different input functionalities.
"""

from GUIBRUSHR.GUI.Input_Output_Panels.Input_Panels.TabPanels.FrameCCNIght.FrameCCNight import FrameCCNight
from GUIBRUSHR.GUI.Input_Output_Panels.Input_Panels.TabPanels.FrameGenerationHRData.FrameGenerationHRData import \
    FrameGenerationHRData
from GUIBRUSHR.GUI.LAYOUT.MyPanel import MyPanel
from GUIBRUSHR.GUI.LAYOUT.MyTabPanel import MyTabPanel
from GUIBRUSHR.GUI.Input_Output_Panels.Input_Panels.TabPanels.FramePath.FramePath import FramePath
from GUIBRUSHR.GUI.Input_Output_Panels.Input_Panels.TabPanels.FrameTellRem.FrameTellRem import FrameTellRem
from GUIBRUSHR.GUI.Input_Output_Panels.Input_Panels.TabPanels.Frame_Parameters.FrameParameter import FrameParameter
from GUIBRUSHR.GUI.Input_Output_Panels.Input_Panels.TabPanels.FrameManualModel.FrameManualModel import FrameManualModel
from GUIBRUSHR.GUI.Input_Output_Panels.Input_Panels.TabPanels.Frame_Retrieval_Analysis.FrameRetrievalAnalysis import FrameRetrievalAnalysis
from GUIBRUSHR.General_Constants.FunctionsAndConstants.Constant_Variables import ConstantVariables
from GUIBRUSHR.GUI.Input_Output_Panels.Input_Panels.TabPanels.FrameDBInteractions.FrameDBInteractions import FrameDBInteractions


class InputPanel(MyPanel):
    """
    A panel class that manages multiple input-related tab panels in the GUI application.
    
    This class inherits from MyPanel and serves as a container for various input panels
    organized in tabs. Each tab represents a different input functionality of the application.
    
    Attributes:
        width_GUI (int): Width of the GUI panel
        parent: Parent widget of the panel
        path_default (str): Default path for file operations
        tab_manager (MyTabPanel): Manager for the tab panels
        frame_path (FramePath): Panel for path-related inputs
        frame_parameter (FrameParameter): Panel for parameter inputs
        frame_retrieval_analysis (FrameRetrievalAnalysis): Panel for retrieval analysis
        frame_tell_rem (FrameTellRem): Panel for TellRem functionality
        frame_manual_model (FrameManualModel): Panel for manual model inputs
        frame_cc_night (FrameCCNight): Panel for CC night functionality
        frame_simulation_HR (FrameGenerationHRData): Panel for HR data simulation
        frame_db_interactions (FrameDBInteractions): Panel for database interactions
    """

    def __init__(self, parent, row, column, color, path_default, width_GUI, height_frame, window, **kwargs):
        """
        Initialize the InputPanel with its components and layout.

        Args:
            parent: Parent widget
            row (int): Row position in the grid
            column (int): Column position in the grid
            color (str): Background color of the panel
            path_default (str, Path): Default path for file operations
            width_GUI (int): Width of the GUI panel
            height_frame (int): Height of the frame
            window: Main window instance
            **kwargs: Additional keyword arguments passed to the parent class
        """
        # Initialize parent class
        super().__init__(window, color, row, column, width=width_GUI, height=height_frame, **kwargs)
        
        # Store instance variables
        self.width_GUI = width_GUI
        self.parent = parent
        self.path_default = path_default

        # Initialize tab manager with predefined tab list
        self.tab_manager = MyTabPanel(
            parent=self,
            tab_list=ConstantVariables.LIST_TAB_MACRO,
            row=0,
            column=0,
            width=width_GUI + 100
        )

        # Initialize all frame panels
        self._initialize_frame_panels(window, width_GUI, height_frame)

    def _initialize_frame_panels(self, window, width_GUI, height_frame):
        """
        Initialize all frame panels with their respective configurations.

        Args:
            window: Main window instance
            width_GUI (int): Width of the GUI panel
            height_frame (int): Height of the frame
        """
        # Path frame panel
        self.frame_path = FramePath(
            self.tab_manager.tab_list[0],
            0, 1,
            ConstantVariables.COLOR_SUB_NOTEBOOK,
            self.path_default,
            self,
            width_GUI,
            int(height_frame)
        )

        # Parameter frame panel
        self.frame_parameter = FrameParameter(
            self.tab_manager.tab_list[1],
            0, 1,
            ConstantVariables.COLOR_SUB_NOTEBOOK,
            self.path_default,
            self
        )

        # Retrieval analysis frame panel
        self.frame_retrieval_analysis = FrameRetrievalAnalysis(
            self.tab_manager.tab_list[2],
            0, 1,
            ConstantVariables.COLOR_SUB_NOTEBOOK,
            self.path_default,
            self,
            width_GUI,
            height_frame,
            window
        )

        # TellRem frame panel
        self.frame_tell_rem = FrameTellRem(
            self.tab_manager.tab_list[3],
            0, 1,
            ConstantVariables.COLOR_SUB_NOTEBOOK,
            self.path_default,
            self,
            window
        )

        # Manual model frame panel
        self.frame_manual_model = FrameManualModel(
            self.tab_manager.tab_list[4],
            0, 1,
            ConstantVariables.COLOR_SUB_NOTEBOOK,
            self.path_default,
            self,
            width_GUI,
            height_frame,
            window
        )

        # CC Night frame panel
        self.frame_cc_night = FrameCCNight(
            self.tab_manager.tab_list[5],
            ConstantVariables.COLOR_SUB_NOTEBOOK,
            0, 1,
            self.path_default,
            self,
            width_GUI,
            height_frame,
            window
        )

        # Simulation HR frame panel
        self.frame_simulation_HR = FrameGenerationHRData(
            self.tab_manager.tab_list[6],
            ConstantVariables.COLOR_SUB_NOTEBOOK,
            0, 1,
            self.path_default,
            self,
            window,
            width_GUI,
            height_frame
        )

        # Database interactions frame panel
        self.frame_db_interactions = FrameDBInteractions(
            self.tab_manager.tab_list[7],
            ConstantVariables.COLOR_SUB_NOTEBOOK,
            0, 1,
            self.path_default,
            self,
            window
        )
