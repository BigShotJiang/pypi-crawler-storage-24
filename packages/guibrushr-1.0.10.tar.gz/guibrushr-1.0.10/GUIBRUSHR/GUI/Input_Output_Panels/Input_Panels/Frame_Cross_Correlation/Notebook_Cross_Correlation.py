"""
Cross Correlation Notebook Module.

This module contains the NotebookCrossCorrelation class which manages
a tabbed interface for cross-correlation analysis functionality.
"""

from GUIBRUSHR.GUI.LAYOUT.MyPanel import MyPanel
from GUIBRUSHR.GUI.LAYOUT.MyTabPanel import MyTabPanel
from GUIBRUSHR.GUI.Input_Output_Panels.Input_Panels.Frame_Cross_Correlation.Frame_run_CC import FrameRunCC
from GUIBRUSHR.GUI.Input_Output_Panels.Input_Panels.Frame_Cross_Correlation.Frame_sum_CC import FrameSumCC
from GUIBRUSHR.GUI.Input_Output_Panels.Input_Panels.Frame_Cross_Correlation.Frame_LH import FrameLH
from GUIBRUSHR.General_Constants.FunctionsAndConstants.Constant_Variables import ConstantVariables


# noinspection PyTypeChecker
class NotebookCrossCorrelation(MyPanel):
    """
    A notebook widget for managing cross-correlation analysis tabs.
    
    This class creates a tabbed interface containing different frames for
    cross-correlation operations including run CC, sum CC, and LH analysis.
    Inherits from MyPanel to provide basic panel functionality.
    """

    def __init__(self, parent, color, row, column, path_default, frame_input, 
                 window, tab_list, width_gui, height_gui, filters_and_table=None, 
                 widget_nights=None, **kwargs):
        """
        Initialize the Cross Correlation Notebook.
        
        Creates a tabbed interface with cross-correlation analysis frames.
        The initialization follows a specific sequence: setting up instance
        variables, calling parent constructor, creating tab manager, and
        initializing individual frames based on the provided tab list.
        
        Args:
            parent: Parent widget container
            color: Background color for the notebook
            row: Grid row position
            column: Grid column position
            path_default: Default file path for operations
            frame_input: Input frame reference
            window: Main window reference
            tab_list: List of tab configurations
            width_gui: GUI width dimension
            height_gui: GUI height dimension
            filters_and_table: Optional filters and table configuration
            widget_nights: Optional nights widget reference
            **kwargs: Additional keyword arguments passed to parent
        """
        # Initialize global exception flag (used for initialization tracking)
        self.global_exc = 0
        
        # Store essential references for frame operations
        self.frame_input = frame_input
        self.path_default = path_default
        self.window = window
        self.color = color
        
        # Initialize parent panel with provided parameters
        super().__init__(parent, color, row, column, **kwargs)
        
        # Create tab manager for organizing cross-correlation frames
        self.tab_manager = MyTabPanel(
            parent=self, 
            tab_list=tab_list, 
            row=1, 
            column=0, 
            width=width_gui
        )
        
        # Initialize Run Cross Correlation frame (first tab)
        self.frame_run_cc = FrameRunCC(
            self.tab_manager.tab_list[0], 
            ConstantVariables.COLOR_SUB_NOTEBOOK_3, 
            0, 
            1, 
            path_default,
            frame_input, 
            window,
            filters_and_table, 
            widget_nights
        )
        
        # Initialize Sum Cross Correlation frame (second tab)
        self.frame_sum_cc = FrameSumCC(
            self.tab_manager.tab_list[1], 
            ConstantVariables.COLOR_SUB_NOTEBOOK_3, 
            0, 
            1, 
            path_default, 
            frame_input, 
            window, 
            width_gui, 
            height_gui, 
            filters_and_table, 
            widget_nights
        )
        
        # Initialize LH frame (third tab, if available)
        # Only create LH frame if more than 2 tabs are specified
        if len(tab_list) > 2:
            self.frame_lh = FrameLH(
                self.tab_manager.tab_list[2], 
                ConstantVariables.COLOR_SUB_NOTEBOOK_3, 
                0, 
                1, 
                path_default, 
                frame_input, 
                window, 
                width_gui, 
                height_gui, 
                widget_nights
            )
        
        # Mark initialization as complete
        self.global_exc = 1
