"""
Wavelength class for handling wavelength range parameters.

This module contains the Wavelength class which manages wavelength ranges
for both low resolution (lr) and high resolution (hr) configurations.
"""


class Wavelength:
    """
    A class to represent wavelength range parameters.
    
    This class stores minimum and maximum wavelength values for both
    low resolution (lr) and high resolution (hr) configurations.
    
    Attributes:
        min_wl_hr: Minimum wavelength for high resolution
        max_wl_hr: Maximum wavelength for high resolution  
        min_wl_lr: Minimum wavelength for low resolution
        max_wl_lr: Maximum wavelength for low resolution
    """
    
    def __init__(
        self, 
        min_wl_lr=None, 
        max_wl_lr=None, 
        min_wl_hr=None, 
        max_wl_hr=None
    ):
        """
        Initialize the Wavelength object with wavelength range parameters.
        
        Args:
            min_wl_lr: Minimum wavelength for low resolution (default: None)
            max_wl_lr: Maximum wavelength for low resolution (default: None)
            min_wl_hr: Minimum wavelength for high resolution (default: None)
            max_wl_hr: Maximum wavelength for high resolution (default: None)
        """
        # Store high resolution wavelength parameters
        self.min_wl_hr = min_wl_hr
        self.max_wl_hr = max_wl_hr
        
        # Store low resolution wavelength parameters
        self.min_wl_lr = min_wl_lr
        self.max_wl_lr = max_wl_lr

