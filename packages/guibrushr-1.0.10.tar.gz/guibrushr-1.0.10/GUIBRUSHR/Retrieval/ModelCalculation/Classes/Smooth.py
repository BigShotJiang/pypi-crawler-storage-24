"""
Smooth class for handling smoothing operations.

This module contains the Smooth class which manages smoothing parameters
for data processing operations.
"""


class Smooth:
    """
    A class to handle smoothing parameters and operations.
    
    This class stores configuration parameters for smoothing operations,
    including whether smoothing is enabled and the size of the smoothing window.
    
    Attributes:
        smooth_on: Flag indicating whether smoothing is enabled
        smooth_size: Size parameter for the smoothing operation
    """
    
    def __init__(self, smooth_on, smooth_size):
        """
        Initialize the Smooth object with smoothing parameters.
        
        Args:
            smooth_on: Boolean or flag indicating if smoothing should be applied
            smooth_size: Numeric value representing the size/window for smoothing
        """
        # Store smoothing activation flag
        self.smooth_on = smooth_on
        
        # Store smoothing size parameter
        self.smooth_size = smooth_size
