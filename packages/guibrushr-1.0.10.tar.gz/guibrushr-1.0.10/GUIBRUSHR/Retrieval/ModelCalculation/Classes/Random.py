"""
Random number generator wrapper class.

This module provides a wrapper around NumPy's random number generator
with seed management capabilities.
"""

from numpy.random import default_rng


class Random:
    """
    A wrapper class for NumPy's random number generator.
    
    This class encapsulates a random number generator with a specific seed,
    providing a consistent interface for random number generation throughout
    the application.
    
    Attributes:
        seed: The seed value used for random number generation
        rng: The NumPy random number generator instance
    """
    
    def __init__(self, seme):
        """
        Initialize the Random class with a seed value.
        
        Args:
            seme: The seed value for the random number generator
        """
        # Store the seed value for potential future reference
        self.seed = seme
        
        # Initialize the NumPy random number generator with the provided seed
        self.rng = default_rng(seed=seme)
