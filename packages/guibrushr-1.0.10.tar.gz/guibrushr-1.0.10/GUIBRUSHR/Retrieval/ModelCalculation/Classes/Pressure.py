"""
Pressure module for atmospheric model calculations.

This module contains the Pressure class for generating logarithmically
spaced pressure values across atmospheric layers.
"""

from numpy import logspace


class Pressure:
    """
    A class to represent atmospheric pressure distribution across layers.
    
    This class generates logarithmically spaced pressure values between
    specified minimum and maximum pressure ranges for a given number of
    atmospheric layers.
    
    Attributes:
        pressures: Array of logarithmically spaced pressure values
        range_min_pressures: Minimum pressure range (log scale)
        range_max_pressures: Maximum pressure range (log scale)
        n_layers: Number of atmospheric layers
    """
    
    def __init__(self, range_min_pressures, range_max_pressures, n_layers):
        """
        Initialize the Pressure object with specified parameters.
        
        Args:
            range_min_pressures: Minimum pressure range value (log scale)
            range_max_pressures: Maximum pressure range value (log scale)
            n_layers: Number of atmospheric layers to generate
        """
        # Generate logarithmically spaced pressure values
        self.pressures = logspace(range_min_pressures, range_max_pressures, n_layers)
        
        # Store initialization parameters for reference
        self.range_min_pressures = range_min_pressures
        self.range_max_pressures = range_max_pressures
        self.n_layers = n_layers
