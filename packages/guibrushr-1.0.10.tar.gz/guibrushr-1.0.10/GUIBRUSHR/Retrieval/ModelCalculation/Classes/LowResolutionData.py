"""
Low resolution data class for atmospheric retrieval calculations.

This module contains the LowResolutionData class which manages low-resolution
spectroscopic data used in atmospheric retrieval algorithms.
"""
import numpy as np
from scipy.interpolate import splrep


class LowResolutionData:
    """
    Manages low-resolution spectroscopic data for atmospheric retrieval.
    
    This class handles the storage and processing of low-resolution spectroscopic
    data including wavelengths, spectral data, error estimates, and related
    parameters for atmospheric retrieval calculations.
    
    Attributes:
        instrument: Name or identifier of the instrument
        ldata_LR: Wavelength data for low resolution
        step_LR: Wavelength step size for low resolution
        rdata_LR: Spectral reflectance/radiance data for low resolution
        errdata_LR_plus: Upper error/uncertainty data for low resolution
        errdata_LR_minus: Lower error/uncertainty data for low resolution
        vsys: Target system velocity
        npix: Number of pixels
        lbottom: Bottom wavelength boundary
        ltop: Top wavelength boundary
    """

    def __init__(self, instrument, spectr, lambd, lambdr, sigma_plus, sigma_minus, npix, target_vsys, flux_norm=False):
        """
        Initialize the LowResolutionData object.

        Args:
            instrument: Instrument name or identifier
            spectr: Spectral data array
            lambd: Wavelength data array
            lambdr: Wavelength step size array
            sigma_plus: Upper error/uncertainty data array
            sigma_minus: Lower error/uncertainty data array
            npix: Number of pixels in the data
            target_vsys: Target system velocity
            flux_norm: Flag indicating whether flux data is normalized to 1
        """
        # Store instrument information
        self.instrument = instrument

        # Store wavelength and spectral data
        self.ldata_LR       = lambd
        self.step_LR        = lambdr
        self.ldata_LR_micron = lambd / 1e3
        self.step_LR_micron  = lambdr / 1e3
        self.rdata_LR       = spectr
        self.errdata_LR_plus  = sigma_plus    # Upper error data
        self.errdata_LR_minus = sigma_minus   # Lower error data
        self.flux_norm      = flux_norm

        delta_lambda = np.diff(lambd)
        R_mean = np.mean(lambd) / np.mean(delta_lambda)
        self.resolution_dataset = R_mean
        self.spline_dataset = splrep(self.ldata_LR, self.rdata_LR)

        # Store system parameters
        self.vsys = target_vsys
        self.npix = npix

        # Calculate wavelength boundaries
        self.lbottom = self.ldata_LR - self.step_LR
        self.ltop    = self.ldata_LR + self.step_LR
