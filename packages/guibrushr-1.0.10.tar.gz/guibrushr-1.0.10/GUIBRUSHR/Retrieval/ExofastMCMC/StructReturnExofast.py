"""
Module containing the StructReturnExofast class for MCMC return data structure.

This module defines a data structure used to store and manage the results
from Exofast MCMC (Markov Chain Monte Carlo) computations.
"""


class StructReturnExofast:
    """
    Data structure for storing Exofast MCMC return values.

    This class encapsulates the results from an Exofast MCMC run, including
    acceptance statistics, parameters, chi-squared values, and determinant values.
    """
    
    # Class attributes initialized to None (default values)
    naccept = None
    oldpars = None
    oldchi2 = None
    olddet = None

    def __init__(self, naccept, pars, chi2, det):
        """
        Initialize the StructReturnExofast instance.
        
        Args:
            naccept: Number of accepted MCMC steps
            pars: Current parameter values
            chi2: Current chi-squared value
            det: Current determinant value
        """
        # Store the acceptance count
        self.naccept = naccept
        
        # Store current parameter values
        self.pars = pars
        
        # Store current chi-squared value
        self.chi2 = chi2
        
        # Store current determinant value
        self.det = det
