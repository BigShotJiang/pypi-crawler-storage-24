import numpy as np
from shapely.geometry import Point
from shapely.ops import unary_union
from scipy.optimize import fsolve
import matplotlib.pyplot as plt

def find_3venn_intersection(area_a, area_b, area_c, area_ab, area_ac, area_bc):
    A_area = area_a
    B_area = area_b
    C_area = area_c
    AB_area = area_ab
    AC_area = area_ac
    BC_area = area_bc

    # --------------------------
    # GEOMETRY FUNCTIONS
    # --------------------------

    def area_to_radius(area):
        return np.sqrt(area / np.pi)

    def overlap_area(r1, r2, d):
        """Return area of overlap of two circles radius r1, r2, distance d."""
        if d >= r1 + r2:
            return 0.0
        if d <= abs(r1 - r2):
            return np.pi * min(r1, r2)**2

        part1 = r1*r1*np.arccos((d*d + r1*r1 - r2*r2)/(2*d*r1))
        part2 = r2*r2*np.arccos((d*d + r2*r2 - r1*r1)/(2*d*r2))
        part3 = 0.5*np.sqrt((-d+r1+r2)*(d+r1-r2)*(d-r1+r2)*(d+r1+r2))
        return part1 + part2 - part3

    # --------------------------
    # SOLVE FOR DISTANCES
    # --------------------------

    rA = area_to_radius(A_area)
    rB = area_to_radius(B_area)
    rC = area_to_radius(C_area)

    def equations(vars):
        dAB, dAC, dBC = vars
        return [
            overlap_area(rA, rB, dAB) - AB_area,
            overlap_area(rA, rC, dAC) - AC_area,
            overlap_area(rB, rC, dBC) - BC_area,
        ]

    dAB, dAC, dBC = fsolve(equations, (1, 1, 1))

    print("Distances:", dAB, dAC, dBC)

    # --------------------------
    # SOLVE FOR C COORDINATES
    # --------------------------

    # Place A at (0,0)
    Ax, Ay = 0, 0

    # Place B at (dAB, 0)
    Bx, By = dAB, 0

    # Solve for C coordinates
    def eq_C(vars):
        x, y = vars
        return [
            np.hypot(x - Ax, y - Ay) - dAC,
            np.hypot(x - Bx, y - By) - dBC,
        ]

    Cx, Cy = fsolve(eq_C, (1, 1))

    print("Centers:")
    print("A:", Ax, Ay)
    print("B:", Bx, By)
    print("C:", Cx, Cy)

    # --------------------------
    # BUILD SHAPELY CIRCLES
    # --------------------------

    circleA = Point(Ax, Ay).buffer(rA, resolution=512)
    circleB = Point(Bx, By).buffer(rB, resolution=512)
    circleC = Point(Cx, Cy).buffer(rC, resolution=512)

    # --------------------------
    # COMPUTE TRIPLE INTERSECTION
    # --------------------------

    ABC_region = circleA.intersection(circleB).intersection(circleC)
    ABC_area = ABC_region.area

    print("Triple intersection area:", ABC_area)
    return dAB, dAC, dBC, ABC_area

