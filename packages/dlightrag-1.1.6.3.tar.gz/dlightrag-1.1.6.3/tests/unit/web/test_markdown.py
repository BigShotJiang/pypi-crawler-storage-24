"""Tests for Markdown rendering in web UI."""

from __future__ import annotations


def test_render_markdown_bold():
    from dlightrag.web.markdown import render_markdown

    result = render_markdown("**bold text**")
    assert "<strong>bold text</strong>" in result


def test_render_markdown_gfm_table():
    from dlightrag.web.markdown import render_markdown

    md = "| A | B |\n|---|---|\n| 1 | 2 |"
    result = render_markdown(md)
    assert "<table>" in result
    assert "<td>1</td>" in result
    assert "<td>2</td>" in result


def test_render_markdown_fenced_code_highlighted():
    from dlightrag.web.markdown import render_markdown

    md = "```python\nprint('hello')\n```"
    result = render_markdown(md)
    # Pygments output is wrapped in <pre class="highlight">
    assert 'class="highlight"' in result
    assert "print" in result


def test_render_markdown_no_double_pre_wrapping():
    from dlightrag.web.markdown import render_markdown

    result = render_markdown("```python\nx = 1\n```")
    # Should not have double <pre> wrapping
    assert result.count("<pre") == 1


def test_render_markdown_fenced_code_unknown_lang():
    from dlightrag.web.markdown import render_markdown

    md = "```unknownlang\nfoo bar\n```"
    result = render_markdown(md)
    # Falls back to plain <pre><code>
    assert "<code>" in result
    assert "foo bar" in result


def test_render_markdown_fenced_code_no_lang():
    from dlightrag.web.markdown import render_markdown

    md = "```\nplain code\n```"
    result = render_markdown(md)
    assert "<code>" in result
    assert "plain code" in result


def test_render_markdown_inline_code():
    from dlightrag.web.markdown import render_markdown

    result = render_markdown("use `foo()` here")
    assert "<code>foo()</code>" in result


def test_render_markdown_latex_passthrough():
    """Dollar-sign math should pass through as literal text (KaTeX handles client-side)."""
    from dlightrag.web.markdown import render_markdown

    result = render_markdown("The formula $E=mc^2$ is famous.")
    assert "$E=mc^2$" in result


def test_render_markdown_display_latex_passthrough():
    from dlightrag.web.markdown import render_markdown

    result = render_markdown("$$\\sum_{i=1}^n x_i$$")
    assert "$$" in result


def test_render_markdown_xss_script_escaped():
    """Raw HTML <script> must be escaped, not passed through."""
    from dlightrag.web.markdown import render_markdown

    result = render_markdown("<script>alert('xss')</script>")
    assert "<script>" not in result
    assert "&lt;script&gt;" in result


def test_render_markdown_lists():
    from dlightrag.web.markdown import render_markdown

    md = "- item 1\n- item 2\n"
    result = render_markdown(md)
    assert "<li>" in result
    assert "item 1" in result


def test_citation_badges_basic():
    """[1-2] in plain text becomes a citation badge."""
    from dlightrag.web.deps import _citation_badges

    result = str(_citation_badges("See [1-2] for details."))
    assert 'class="citation-badge"' in result
    assert 'data-ref="1"' in result
    assert 'data-chunk="2"' in result


def test_citation_badges_doc_level():
    """[3] doc-level citation becomes a badge."""
    from dlightrag.web.deps import _citation_badges

    result = str(_citation_badges("See [3] for details."))
    assert 'class="citation-badge"' in result
    assert 'data-ref="3"' in result


def test_citation_badges_in_inline_code_skipped():
    """[1-2] inside inline code must NOT become a badge."""
    from dlightrag.web.deps import _citation_badges

    result = str(_citation_badges("Use `array[1-2]` in code."))
    # The [1-2] is inside <code>, should not be a badge
    assert "<code>" in result
    assert result.count('class="citation-badge"') == 0


def test_citation_badges_in_fenced_code_skipped():
    """[1-2] inside fenced code must NOT become a badge."""
    from dlightrag.web.deps import _citation_badges

    md = "```\narray[1-2] = value\n```\n\nSee [1-2] for info."
    result = str(_citation_badges(md))
    # Only the [1-2] outside code should be a badge
    assert result.count('class="citation-badge"') == 1


def test_citation_badges_in_table():
    """[1-2] in a table cell should become a badge."""
    from dlightrag.web.deps import _citation_badges

    md = "| Source | Note |\n|---|---|\n| [1-2] | data |"
    result = str(_citation_badges(md))
    assert 'class="citation-badge"' in result


def test_citation_badges_markdown_rendering():
    """Verify markdown is actually rendered (not just escaped)."""
    from dlightrag.web.deps import _citation_badges

    result = str(_citation_badges("**bold** text [1-1]"))
    assert "<strong>bold</strong>" in result
    assert 'class="citation-badge"' in result
