# Copyright 2025-2026 Hanlian Lu. SPDX-License-Identifier: Apache-2.0
"""Tests for UnifiedRepresentEngine orchestrator."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import numpy as np
import pytest
from PIL import Image

from dlightrag.core.retrieval.protocols import RetrievalResult
from dlightrag.unifiedrepresent.engine import UnifiedRepresentEngine
from dlightrag.unifiedrepresent.renderer import RenderResult

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def _make_config() -> MagicMock:
    config = MagicMock()
    config.page_render_dpi = 250
    config.embedding_model = "test-model"
    config.embedding_dim = 1024
    config.effective_embedding_provider = "openai"
    config._get_url = MagicMock(return_value="http://localhost:8000/v1")
    config._get_provider_api_key = MagicMock(return_value="test-key")
    config.kg_entity_types = ["Person", "Organization"]
    config.enable_rerank = False
    config.default_mode = "mix"
    config.top_k = 60
    config.chunk_top_k = 10
    return config


def _make_lightrag() -> MagicMock:
    lightrag = MagicMock()
    lightrag.full_docs = MagicMock()
    lightrag.full_docs.upsert = AsyncMock()
    lightrag.text_chunks = MagicMock()
    lightrag.text_chunks.upsert = AsyncMock()
    lightrag.chunks_vdb = MagicMock()
    lightrag.chunks_vdb.upsert = AsyncMock()
    lightrag.chunks_vdb.embedding_func = MagicMock()
    return lightrag


# ---------------------------------------------------------------------------
# TestUnifiedEngineInit
# ---------------------------------------------------------------------------


class TestUpsertWithVisualVectors:
    """Test _upsert_with_visual_vectors embedding swap logic."""

    @patch("dlightrag.unifiedrepresent.engine.VisualRetriever")
    @patch("dlightrag.unifiedrepresent.engine.EntityExtractor")
    @patch("dlightrag.unifiedrepresent.engine.VisualEmbedder")
    @patch("dlightrag.unifiedrepresent.engine.PageRenderer")
    async def test_upsert_swaps_embedding_and_restores(
        self,
        _renderer: MagicMock,
        _embedder: MagicMock,
        _extractor: MagicMock,
        _retriever: MagicMock,
    ) -> None:
        config = _make_config()
        lightrag = _make_lightrag()
        original_func = lightrag.chunks_vdb.embedding_func

        engine = UnifiedRepresentEngine(
            lightrag=lightrag,
            visual_chunks=MagicMock(),
            config=config,
        )

        chunks_data = {
            "chunk-001": {"content": "page one text", "full_doc_id": "doc-1"},
            "chunk-002": {"content": "page two text", "full_doc_id": "doc-1"},
        }
        vectors = np.random.rand(2, 1024).astype(np.float32)

        await engine._upsert_with_visual_vectors(chunks_data, vectors)

        lightrag.chunks_vdb.upsert.assert_awaited_once_with(chunks_data)
        # Original embedding func should be restored
        assert lightrag.chunks_vdb.embedding_func is original_func

    @patch("dlightrag.unifiedrepresent.engine.VisualRetriever")
    @patch("dlightrag.unifiedrepresent.engine.EntityExtractor")
    @patch("dlightrag.unifiedrepresent.engine.VisualEmbedder")
    @patch("dlightrag.unifiedrepresent.engine.PageRenderer")
    async def test_upsert_restores_on_error(
        self,
        _renderer: MagicMock,
        _embedder: MagicMock,
        _extractor: MagicMock,
        _retriever: MagicMock,
    ) -> None:
        config = _make_config()
        lightrag = _make_lightrag()
        original_func = lightrag.chunks_vdb.embedding_func
        lightrag.chunks_vdb.upsert = AsyncMock(side_effect=RuntimeError("boom"))

        engine = UnifiedRepresentEngine(
            lightrag=lightrag,
            visual_chunks=MagicMock(),
            config=config,
        )

        chunks_data = {"chunk-001": {"content": "text", "full_doc_id": "d1"}}
        vectors = np.random.rand(1, 1024).astype(np.float32)

        with pytest.raises(RuntimeError, match="boom"):
            await engine._upsert_with_visual_vectors(chunks_data, vectors)

        # Embedding func restored despite error
        assert lightrag.chunks_vdb.embedding_func is original_func


# ---------------------------------------------------------------------------
# TestAingest
# ---------------------------------------------------------------------------


class TestAingest:
    """Test aingest() pipeline end-to-end with mocked sub-components."""

    @patch("dlightrag.unifiedrepresent.engine.VisualRetriever")
    @patch("dlightrag.unifiedrepresent.engine.EntityExtractor")
    @patch("dlightrag.unifiedrepresent.engine.VisualEmbedder")
    @patch("dlightrag.unifiedrepresent.engine.PageRenderer")
    async def test_aingest_two_pages(
        self,
        _renderer_cls: MagicMock,
        _embedder_cls: MagicMock,
        _extractor_cls: MagicMock,
        _retriever_cls: MagicMock,
    ) -> None:
        config = _make_config()
        lightrag = _make_lightrag()
        visual_chunks = MagicMock()
        visual_chunks.upsert = AsyncMock()

        engine = UnifiedRepresentEngine(
            lightrag=lightrag,
            visual_chunks=visual_chunks,
            config=config,
        )

        # Mock renderer: returns 2 pages
        img_0 = Image.new("RGB", (100, 100), "white")
        img_1 = Image.new("RGB", (100, 100), "blue")
        render_result = RenderResult(
            pages=[(0, img_0), (1, img_1)],
            metadata={
                "title": "Test Doc",
                "author": "Tester",
                "creation_date": "2025-01-01",
                "page_count": 2,
                "original_format": "pdf",
            },
        )
        engine.renderer.render_file = AsyncMock(return_value=render_result)

        # Mock embedder: returns (2, 1024) vectors
        vectors = np.zeros((2, 1024), dtype=np.float32)
        engine.embedder.embed_pages = AsyncMock(return_value=vectors)

        # Mock extractor: returns page_infos
        page_infos = [
            {
                "chunk_id": "chunk-aaa",
                "page_index": 0,
                "content": "Page one description",
            },
            {
                "chunk_id": "chunk-bbb",
                "page_index": 1,
                "content": "Page two description",
            },
        ]
        engine.extractor.extract_from_pages = AsyncMock(return_value=page_infos)

        # Mock _upsert_with_visual_vectors
        engine._upsert_with_visual_vectors = AsyncMock()

        result = await engine.aingest("/fake/doc.pdf", doc_id="doc-test")

        # Verify return value
        assert result["doc_id"] == "doc-test"
        assert result["page_count"] == 2
        assert result["file_path"] == "/fake/doc.pdf"

        # Verify full_docs.upsert called
        lightrag.full_docs.upsert.assert_awaited_once()
        upsert_arg = lightrag.full_docs.upsert.call_args[0][0]
        assert "doc-test" in upsert_arg

        # Verify text_chunks.upsert called with correct data
        lightrag.text_chunks.upsert.assert_awaited_once()
        tc_arg = lightrag.text_chunks.upsert.call_args[0][0]
        assert "chunk-aaa" in tc_arg
        assert "chunk-bbb" in tc_arg
        assert tc_arg["chunk-aaa"]["source_type"] == "unified_represent"
        assert tc_arg["chunk-bbb"]["chunk_order_index"] == 1

        # Verify visual_chunks.upsert called with image data
        visual_chunks.upsert.assert_awaited_once()
        vc_arg = visual_chunks.upsert.call_args[0][0]
        assert "chunk-aaa" in vc_arg
        assert "image_data" in vc_arg["chunk-aaa"]
        assert vc_arg["chunk-aaa"]["full_doc_id"] == "doc-test"
        assert vc_arg["chunk-aaa"]["file_path"] == "/fake/doc.pdf"
        assert vc_arg["chunk-aaa"]["doc_title"] == "Test Doc"
        assert "content" not in vc_arg["chunk-aaa"]

        # Verify _upsert_with_visual_vectors called
        engine._upsert_with_visual_vectors.assert_awaited_once()


# ---------------------------------------------------------------------------
# TestAingestEmptyFile
# ---------------------------------------------------------------------------


class TestAingestEmptyFile:
    """Test aingest raises ValueError when renderer returns 0 pages."""

    @patch("dlightrag.unifiedrepresent.engine.VisualRetriever")
    @patch("dlightrag.unifiedrepresent.engine.EntityExtractor")
    @patch("dlightrag.unifiedrepresent.engine.VisualEmbedder")
    @patch("dlightrag.unifiedrepresent.engine.PageRenderer")
    async def test_empty_render_raises(
        self,
        _renderer_cls: MagicMock,
        _embedder_cls: MagicMock,
        _extractor_cls: MagicMock,
        _retriever_cls: MagicMock,
    ) -> None:
        config = _make_config()
        lightrag = _make_lightrag()

        engine = UnifiedRepresentEngine(
            lightrag=lightrag,
            visual_chunks=MagicMock(),
            config=config,
        )

        # Empty render result
        engine.renderer.render_file = AsyncMock(return_value=RenderResult(pages=[], metadata={}))

        with pytest.raises(ValueError, match="No pages rendered"):
            await engine.aingest("/fake/empty.pdf")


# ---------------------------------------------------------------------------
# TestAretrieve
# ---------------------------------------------------------------------------


class TestAretrieve:
    """Test aretrieve delegates to retriever.retrieve."""

    @patch("dlightrag.unifiedrepresent.engine.VisualRetriever")
    @patch("dlightrag.unifiedrepresent.engine.EntityExtractor")
    @patch("dlightrag.unifiedrepresent.engine.VisualEmbedder")
    @patch("dlightrag.unifiedrepresent.engine.PageRenderer")
    async def test_delegates_to_retriever(
        self,
        _renderer_cls: MagicMock,
        _embedder_cls: MagicMock,
        _extractor_cls: MagicMock,
        _retriever_cls: MagicMock,
    ) -> None:
        config = _make_config()
        lightrag = _make_lightrag()

        engine = UnifiedRepresentEngine(
            lightrag=lightrag,
            visual_chunks=MagicMock(),
            config=config,
        )

        expected = {
            "contexts": {"entities": [], "relationships": [], "chunks": []},
        }
        engine.retriever.retrieve = AsyncMock(return_value=expected)

        result = await engine.aretrieve("test query")

        engine.retriever.retrieve.assert_awaited_once_with(
            query="test query",
            mode="mix",
            top_k=60,
            chunk_top_k=10,
            images=None,
            conversation_context=None,
        )
        assert isinstance(result, RetrievalResult)
        assert result.answer is None
        assert result.contexts == expected.get("contexts", {})


# ---------------------------------------------------------------------------
# TestAanswer
# ---------------------------------------------------------------------------


class TestAanswer:
    """Test aanswer delegates to retriever.answer."""

    @patch("dlightrag.unifiedrepresent.engine.VisualRetriever")
    @patch("dlightrag.unifiedrepresent.engine.EntityExtractor")
    @patch("dlightrag.unifiedrepresent.engine.VisualEmbedder")
    @patch("dlightrag.unifiedrepresent.engine.PageRenderer")
    async def test_delegates_to_retriever_answer(
        self,
        _renderer_cls: MagicMock,
        _embedder_cls: MagicMock,
        _extractor_cls: MagicMock,
        _retriever_cls: MagicMock,
    ) -> None:
        config = _make_config()
        lightrag = _make_lightrag()

        engine = UnifiedRepresentEngine(
            lightrag=lightrag,
            visual_chunks=MagicMock(),
            config=config,
        )

        expected = {
            "answer": "test answer",
            "contexts": {"entities": [], "relationships": [], "chunks": []},
        }
        engine.retriever.answer = AsyncMock(return_value=expected)

        result = await engine.aanswer("what is X?")

        engine.retriever.answer.assert_awaited_once_with(
            query="what is X?",
            mode="mix",
            top_k=60,
            chunk_top_k=10,
            images=None,
            conversation_context=None,
        )
        assert isinstance(result, RetrievalResult)
        assert result.answer == expected.get("answer")


# ---------------------------------------------------------------------------
# TestAdeleteDoc
# ---------------------------------------------------------------------------


class TestAdeleteDoc:
    """Test adelete_doc cleans visual_chunks by page_count."""

    @patch("dlightrag.unifiedrepresent.engine.VisualRetriever")
    @patch("dlightrag.unifiedrepresent.engine.EntityExtractor")
    @patch("dlightrag.unifiedrepresent.engine.VisualEmbedder")
    @patch("dlightrag.unifiedrepresent.engine.PageRenderer")
    async def test_deletes_visual_chunks_by_page_count(
        self,
        _renderer: MagicMock,
        _embedder: MagicMock,
        _extractor: MagicMock,
        _retriever: MagicMock,
    ) -> None:
        config = _make_config()
        lightrag = _make_lightrag()
        visual_chunks = MagicMock()
        visual_chunks.delete = AsyncMock()

        # full_docs returns doc data with page_count
        lightrag.full_docs.get_by_id = AsyncMock(
            return_value={"content": "", "file_path": "/f.pdf", "page_count": 3}
        )

        engine = UnifiedRepresentEngine(
            lightrag=lightrag,
            visual_chunks=visual_chunks,
            config=config,
        )

        result = await engine.adelete_doc("doc-abc")

        assert result["visual_chunks_deleted"] == 3
        assert visual_chunks.delete.await_count == 3

        # Verify exact chunk_ids passed — the formula must match aingest
        from lightrag.utils import compute_mdhash_id

        expected_ids = [
            compute_mdhash_id("doc-abc:page:0", prefix="chunk-"),
            compute_mdhash_id("doc-abc:page:1", prefix="chunk-"),
            compute_mdhash_id("doc-abc:page:2", prefix="chunk-"),
        ]
        actual_ids = [call.args[0][0] for call in visual_chunks.delete.call_args_list]
        assert actual_ids == expected_ids


# ---------------------------------------------------------------------------
# TestProtocolCompliance
# ---------------------------------------------------------------------------


class TestProtocolCompliance:
    """Test that UnifiedRepresentEngine satisfies RetrievalBackend Protocol."""

    @patch("dlightrag.unifiedrepresent.engine.VisualRetriever")
    @patch("dlightrag.unifiedrepresent.engine.EntityExtractor")
    @patch("dlightrag.unifiedrepresent.engine.VisualEmbedder")
    @patch("dlightrag.unifiedrepresent.engine.PageRenderer")
    async def test_aretrieve_returns_retrieval_result(self, _r, _em, _ex, _ret):
        config = _make_config()
        lightrag = _make_lightrag()
        engine = UnifiedRepresentEngine(
            lightrag=lightrag,
            visual_chunks=MagicMock(),
            config=config,
        )
        engine.retriever.retrieve = AsyncMock(
            return_value={
                "contexts": {"chunks": []},
            }
        )
        result = await engine.aretrieve("test query")
        assert isinstance(result, RetrievalResult)
        assert result.answer is None
        assert result.contexts == {"chunks": []}

    @patch("dlightrag.unifiedrepresent.engine.VisualRetriever")
    @patch("dlightrag.unifiedrepresent.engine.EntityExtractor")
    @patch("dlightrag.unifiedrepresent.engine.VisualEmbedder")
    @patch("dlightrag.unifiedrepresent.engine.PageRenderer")
    async def test_aanswer_returns_retrieval_result(self, _r, _em, _ex, _ret):
        config = _make_config()
        lightrag = _make_lightrag()
        engine = UnifiedRepresentEngine(
            lightrag=lightrag,
            visual_chunks=MagicMock(),
            config=config,
        )
        engine.retriever.answer = AsyncMock(
            return_value={
                "answer": "the answer",
                "contexts": {"chunks": []},
            }
        )
        result = await engine.aanswer("what is X?")
        assert isinstance(result, RetrievalResult)
        assert result.answer == "the answer"

    @patch("dlightrag.unifiedrepresent.engine.VisualRetriever")
    @patch("dlightrag.unifiedrepresent.engine.EntityExtractor")
    @patch("dlightrag.unifiedrepresent.engine.VisualEmbedder")
    @patch("dlightrag.unifiedrepresent.engine.PageRenderer")
    async def test_accepts_kwargs(self, _r, _em, _ex, _ret):
        config = _make_config()
        lightrag = _make_lightrag()
        engine = UnifiedRepresentEngine(
            lightrag=lightrag,
            visual_chunks=MagicMock(),
            config=config,
        )
        engine.retriever.retrieve = AsyncMock(return_value={"contexts": {}})
        # Should not raise — **kwargs absorbs multimodal_content
        result = await engine.aretrieve("q", multimodal_content=[{"type": "image"}])
        assert isinstance(result, RetrievalResult)
