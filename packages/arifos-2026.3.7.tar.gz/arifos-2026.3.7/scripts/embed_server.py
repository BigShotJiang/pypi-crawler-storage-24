from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel
from typing import List, Union, Any
from sentence_transformers import SentenceTransformer
import uvicorn
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="Local BGE Embedding Server")
security = HTTPBearer()

API_TOKEN = "SK-ARIFOS-FORGE"

def verify_token(credentials: HTTPAuthorizationCredentials = Depends(security)):
    if credentials.credentials != API_TOKEN:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid authentication credentials",
        )
    return credentials.credentials

model_name = "/opt/arifos-embeddings/bge-arifOS"
logger.info(f"Loading model: {model_name}")
model = SentenceTransformer(model_name)
logger.info("Model loaded successfully.")

class EmbeddingRequest(BaseModel):
    model: str
    input: Union[str, List[str]]
    user: str | None = None

class EmbeddingData(BaseModel):
    object: str = "embedding"
    embedding: List[float]
    index: int

class UsageStats(BaseModel):
    prompt_tokens: int = 0
    total_tokens: int = 0

class EmbeddingResponse(BaseModel):
    object: str = "list"
    data: List[EmbeddingData]
    model: str
    usage: UsageStats

@app.post("/v1/embeddings", response_model=EmbeddingResponse)
async def create_embeddings(request: EmbeddingRequest, token: str = Depends(verify_token)):
    inputs = request.input if isinstance(request.input, list) else [request.input]
    
    embeddings = model.encode(inputs, normalize_embeddings=True).tolist()
    
    data = [
        EmbeddingData(embedding=emb, index=i)
        for i, emb in enumerate(embeddings)
    ]
    
    return EmbeddingResponse(
        data=data,
        model=request.model,
        usage=UsageStats() 
    )

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8001)
