import json

config_path = "/root/openclaw_data/config/openclaw.json"

with open(config_path, "r") as f:
    config = json.load(f)

config["memory"] = {
    "provider": "local-bge",
    "providers": {
        "local-bge": {
            "type": "openai",
            "baseURL": "http://172.17.0.1:8000/v1",
            "apiKey": "dummy_key_888"
        }
    }
}

with open(config_path, "w") as f:
    json.dump(config, f, indent=2)

print("Updated openclaw.json with local-bge memory provider.")
