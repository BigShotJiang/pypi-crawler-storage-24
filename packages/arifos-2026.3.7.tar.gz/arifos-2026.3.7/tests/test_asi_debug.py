"""Debug ASI engine issue."""
import sys
import asyncio

# Ensure we import from project root, not tests/
sys.path.insert(0, '.')

async def debug_asi():
    from core import empathize
    from core.shared.physics import ConstitutionalTensor, TrinityTensor, UncertaintyBand, GeniusDial, Peace2
    
    # Create a mock tensor
    tensor = ConstitutionalTensor(
        witness=TrinityTensor(H=0.95, A=0.95, S=0.95),
        entropy_delta=0.0,
        humility=UncertaintyBand(omega_0=0.04),
        genius=GeniusDial(A=0.9, P=0.9, X=0.9, E=1.0),
        peace=Peace2({}),
        empathy=0.95,
        truth_score=0.95
    )
    
    print(f"Tensor type: {type(tensor)}")
    print(f"Has metrics attr: {hasattr(tensor, 'metrics')}")
    
    # Call empathize
    try:
        result = await empathize("test query", tensor, "test-session")
        print(f"Empathize result type: {type(result)}")
        print(f"Has floor_scores: {hasattr(result, 'floor_scores')}")
        if hasattr(result, "floor_scores"):
            print(f"Floor scores: {result.floor_scores}")
    except Exception as e:
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(debug_asi())
