# ----------------------------------------------------------------------------------------
#   gitlab_api
#   ----------
#
#   GitLab REST API client for accessing the package registry and group structures.
#   Uses only Python stdlib (urllib.request) - no external dependencies.
#
#   Supports:
#   - Auto-detecting whether a path is a group or project
#   - Listing all projects within a group (including subgroups)
#   - Listing packages and their files
#   - Downloading package files
#   - Uploading files to the generic package registry
#
#   License
#   -------
#   MIT License - Copyright 2026 Cyber Assessment Labs
#
#   Authors
#   -------
#   bena (via claude)
#
#   Version History
#   ---------------
#   Mar 2026 - Created
# ----------------------------------------------------------------------------------------

# ----------------------------------------------------------------------------------------
#   Imports
# ----------------------------------------------------------------------------------------

import json
import logging
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from dataclasses import field
from pathlib import Path
from typing import Any

# ----------------------------------------------------------------------------------------
#   Types
# ----------------------------------------------------------------------------------------


@dataclass
class ProjectInfo:
    """Information about a GitLab project."""

    id: int
    name: str
    path_with_namespace: str


@dataclass
class PackageFileInfo:
    """A file within a package version."""

    id: int
    package_id: int
    file_name: str
    size: int
    file_sha256: str
    created_at: str


@dataclass
class PackageInfo:
    """Information about a package within a project."""

    id: int
    name: str
    version: str
    package_type: str
    created_at: str
    project_id: int
    project_path: str = ""
    files: list[PackageFileInfo] = field(
        default_factory=lambda: list[PackageFileInfo]()
    )


# ----------------------------------------------------------------------------------------
#   Helpers
# ----------------------------------------------------------------------------------------


# ----------------------------------------------------------------------------------------
def _parse_pypi_filename(file_path: Path) -> tuple[str, str, str]:
    """
    Parse a Python package filename to extract name, version, and filetype.

    Supports wheels (.whl) and source distributions (.tar.gz).

    Parameters:
        file_path: Path to the package file

    Returns:
        Tuple of (package_name, version, filetype)

    Raises:
        ValueError: If the filename cannot be parsed
    """
    name = file_path.name

    if name.endswith(".whl"):
        # Wheel: {name}-{version}(-{build})?-{python}-{abi}-{platform}.whl
        parts = file_path.stem.split("-")
        if len(parts) < 5:
            raise ValueError(f"Invalid wheel filename: {name}")
        return parts[0].replace("_", "-"), parts[1], "bdist_wheel"

    if name.endswith(".tar.gz"):
        # Sdist: {name}-{version}.tar.gz
        stem = name.removesuffix(".tar.gz")
        parts = stem.rsplit("-", 1)
        if len(parts) != 2:
            raise ValueError(f"Invalid sdist filename: {name}")
        return parts[0].replace("_", "-"), parts[1], "sdist"

    raise ValueError(f"Unsupported PyPI file type: {name}")


# ----------------------------------------------------------------------------------------
#   GitLab Client
# ----------------------------------------------------------------------------------------


# ----------------------------------------------------------------------------------------
class GitLabClient:
    """
    Client for interacting with GitLab's Package Registry and Groups API.

    Supports both public and private projects (via access token).
    """

    # ------------------------------------------------------------------------------------
    def __init__(self, gitlab_url: str, token: str | None = None):
        """
        Initialise the GitLab client.

        Parameters:
            gitlab_url: Base URL of the GitLab instance (e.g., https://gitlab.com)
            token: Optional private access token for authentication
        """
        # Ensure URL has a scheme
        url = gitlab_url.rstrip("/")
        if not url.startswith(("http://", "https://")):
            url = "https://" + url
        self.gitlab_url = url
        self.token = token
        self.logger = logging.getLogger(__name__)

    # ------------------------------------------------------------------------------------
    def _api_url(self, endpoint: str) -> str:
        """Build full API URL for an endpoint."""
        return f"{self.gitlab_url}/api/v4{endpoint}"

    # ------------------------------------------------------------------------------------
    def _request(self, url: str) -> Any:
        """
        Make an HTTP GET request and return parsed JSON response.

        Parameters:
            url: Full URL to request

        Returns:
            Parsed JSON response

        Raises:
            urllib.error.HTTPError: On HTTP errors
            urllib.error.URLError: On connection errors
        """
        self.logger.debug(f"GET {url}")

        request = urllib.request.Request(url)
        request.add_header("Accept", "application/json")
        if self.token:
            request.add_header("PRIVATE-TOKEN", self.token)

        with urllib.request.urlopen(request) as response:
            data = response.read().decode("utf-8")
            return json.loads(data)

    # ------------------------------------------------------------------------------------
    def _paginated_request(self, url: str) -> list[Any]:
        """
        Make paginated API requests and return all results.

        Fetches page 1 first to discover the total page count, then fetches
        all remaining pages in parallel for speed.

        Parameters:
            url: Base URL (without pagination parameters)

        Returns:
            List of all results across all pages
        """
        per_page = 100
        separator = "&" if "?" in url else "?"

        def fetch_page(page: int) -> list[Any]:
            paginated_url = f"{url}{separator}page={page}&per_page={per_page}"
            self.logger.debug(f"GET {paginated_url}")
            request = urllib.request.Request(paginated_url)
            request.add_header("Accept", "application/json")
            if self.token:
                request.add_header("PRIVATE-TOKEN", self.token)
            with urllib.request.urlopen(request) as response:
                data = response.read().decode("utf-8")
                return json.loads(data)

        # Fetch page 1 to discover total pages
        first_url = f"{url}{separator}page=1&per_page={per_page}"
        self.logger.debug(f"GET {first_url}")
        request = urllib.request.Request(first_url)
        request.add_header("Accept", "application/json")
        if self.token:
            request.add_header("PRIVATE-TOKEN", self.token)

        with urllib.request.urlopen(request) as response:
            data = response.read().decode("utf-8")
            results: list[Any] = json.loads(data)

            if not results:
                return []

            total_pages_header = response.headers.get("X-Total-Pages")

        if not total_pages_header:
            # No pagination headers — fall back to sequential fetching
            if len(results) < per_page:
                return results
            page = 2
            while True:
                page_results = fetch_page(page)
                if not page_results:
                    break
                results.extend(page_results)
                if len(page_results) < per_page:
                    break
                page += 1
            return results

        total_pages = int(total_pages_header)
        if total_pages <= 1:
            return results

        # Fetch remaining pages in parallel
        from concurrent.futures import ThreadPoolExecutor

        with ThreadPoolExecutor(max_workers=min(total_pages - 1, 32)) as executor:
            remaining = list(executor.map(fetch_page, range(2, total_pages + 1)))

        for page_results in remaining:
            results.extend(page_results)

        return results

    # ------------------------------------------------------------------------------------
    def _put_file(self, url: str, file_path: Path) -> Any:
        """
        Upload a file via HTTP PUT.

        Parameters:
            url: Full URL to PUT to
            file_path: Path to the file to upload

        Returns:
            Parsed JSON response

        Raises:
            urllib.error.HTTPError: On HTTP errors
            urllib.error.URLError: On connection errors
        """
        self.logger.debug(f"PUT {url}")

        file_data = file_path.read_bytes()

        request = urllib.request.Request(url, data=file_data, method="PUT")
        request.add_header("Content-Type", "application/octet-stream")
        request.add_header("Accept", "application/json")
        if self.token:
            request.add_header("PRIVATE-TOKEN", self.token)

        with urllib.request.urlopen(request) as response:
            return json.loads(response.read().decode("utf-8"))

    # ------------------------------------------------------------------------------------
    def resolve_path(self, path: str) -> tuple[str, int]:
        """
        Determine whether a GitLab path refers to a group or a project.

        Tries the project API first, then the group API.

        Parameters:
            path: GitLab path (e.g., "group/subgroup/project" or "group/subgroup")

        Returns:
            Tuple of (path_type, id) where path_type is "project" or "group"

        Raises:
            ValueError: If the path is neither a valid project nor group
            urllib.error.URLError: On connection errors
        """
        encoded_path = urllib.parse.quote(path, safe="")

        # Try as a project first
        try:
            project_data = self._request(self._api_url(f"/projects/{encoded_path}"))
            return ("project", int(project_data["id"]))
        except (urllib.error.HTTPError, TypeError, KeyError) as e:
            if isinstance(e, urllib.error.HTTPError) and e.code != 404:
                raise

        # Try as a group
        try:
            group_data = self._request(self._api_url(f"/groups/{encoded_path}"))
            return ("group", int(group_data["id"]))
        except (urllib.error.HTTPError, TypeError, KeyError) as e:
            if isinstance(e, urllib.error.HTTPError) and e.code != 404:
                raise

        raise ValueError(f"Path not found as project or group: {path}")

    # ------------------------------------------------------------------------------------
    def get_group_projects(
        self,
        group_id: int,
        project_filter: str | None = None,
        project_exclude: list[str] | None = None,
    ) -> list[ProjectInfo]:
        """
        List all projects within a group, including subgroups.

        Parameters:
            group_id: The numeric group ID
            project_filter: Optional substring filter for project paths
            project_exclude: Optional list of substrings; projects matching
                any entry are excluded (case-insensitive)

        Returns:
            List of ProjectInfo objects
        """
        url = self._api_url(
            f"/groups/{group_id}/projects"
            "?include_subgroups=true&simple=true&archived=false"
            "&order_by=path&sort=asc"
        )

        try:
            projects_data = self._paginated_request(url)
        except urllib.error.HTTPError as e:
            if e.code == 404:
                self.logger.warning(f"Group not found: {group_id}")
                return []
            raise

        projects: list[ProjectInfo] = []
        for proj in projects_data:
            # Skip projects pending deletion
            if proj.get("marked_for_deletion_at"):
                continue

            info = ProjectInfo(
                id=proj["id"],
                name=proj["name"],
                path_with_namespace=proj["path_with_namespace"],
            )

            # Apply project filter if specified
            if project_filter:
                if project_filter.lower() not in info.path_with_namespace.lower():
                    continue

            # Apply project exclusions
            if project_exclude:
                path_lower = info.path_with_namespace.lower()
                if any(ex.lower() in path_lower for ex in project_exclude):
                    continue

            projects.append(info)

        projects.sort(key=lambda p: p.path_with_namespace)
        return projects

    # ------------------------------------------------------------------------------------
    def get_project_info(self, project_id: int) -> ProjectInfo | None:
        """
        Get project information by ID.

        Parameters:
            project_id: The numeric project ID

        Returns:
            ProjectInfo if found, None otherwise
        """
        url = self._api_url(f"/projects/{project_id}")

        try:
            data = self._request(url)
            return ProjectInfo(
                id=data["id"],
                name=data["name"],
                path_with_namespace=data["path_with_namespace"],
            )
        except urllib.error.HTTPError as e:
            if e.code == 404:
                return None
            raise

    # ------------------------------------------------------------------------------------
    def list_packages(
        self,
        project_id: int,
        package_type: str | None = None,
    ) -> list[PackageInfo]:
        """
        List all packages for a project.

        Parameters:
            project_id: The numeric project ID
            package_type: Optional package type filter (e.g., "generic", "pypi")

        Returns:
            List of PackageInfo objects (without files populated)
        """
        url = self._api_url(f"/projects/{project_id}/packages?order_by=name&sort=asc")

        if package_type:
            url += f"&package_type={urllib.parse.quote(package_type, safe='')}"

        try:
            packages_data = self._paginated_request(url)
        except urllib.error.HTTPError as e:
            if e.code == 404:
                self.logger.warning(f"No packages found for project: {project_id}")
                return []
            raise

        packages: list[PackageInfo] = []
        for pkg in packages_data:
            # Skip packages in error state
            if pkg.get("status") == "error":
                continue

            packages.append(
                PackageInfo(
                    id=pkg["id"],
                    name=pkg["name"],
                    version=pkg["version"],
                    package_type=pkg["package_type"],
                    created_at=pkg.get("created_at", ""),
                    project_id=project_id,
                )
            )

        return packages

    # ------------------------------------------------------------------------------------
    def list_group_packages(
        self,
        group_id: int,
        package_type: str | None = None,
    ) -> list[PackageInfo]:
        """
        List all packages across all projects in a group (including subgroups).

        This is much more efficient than calling list_packages per project,
        as it requires only 1-2 paginated API calls for the entire group.

        Parameters:
            group_id: The numeric group ID
            package_type: Optional package type filter (e.g., "generic", "pypi")

        Returns:
            List of PackageInfo objects (without files populated)
        """
        url = self._api_url(
            f"/groups/{group_id}/packages"
            "?order_by=created_at&sort=desc&exclude_subgroups=false"
        )

        if package_type:
            url += f"&package_type={urllib.parse.quote(package_type, safe='')}"

        try:
            packages_data = self._paginated_request(url)
        except urllib.error.HTTPError as e:
            if e.code == 404:
                self.logger.warning(f"No packages found for group: {group_id}")
                return []
            raise

        packages: list[PackageInfo] = []
        for pkg in packages_data:
            if pkg.get("status") == "error":
                continue

            packages.append(
                PackageInfo(
                    id=pkg["id"],
                    name=pkg["name"],
                    version=pkg["version"],
                    package_type=pkg["package_type"],
                    created_at=pkg.get("created_at", ""),
                    project_id=pkg.get("project_id", 0),
                    project_path=pkg.get("project_path", ""),
                )
            )

        return packages

    # ------------------------------------------------------------------------------------
    def list_package_files(
        self,
        project_id: int,
        package_id: int,
    ) -> list[PackageFileInfo]:
        """
        List all files for a specific package.

        Parameters:
            project_id: The numeric project ID
            package_id: The numeric package ID

        Returns:
            List of PackageFileInfo objects
        """
        url = self._api_url(
            f"/projects/{project_id}/packages/{package_id}/package_files"
        )

        try:
            files_data = self._paginated_request(url)
        except urllib.error.HTTPError as e:
            if e.code == 404:
                self.logger.warning(f"No files found for package: {package_id}")
                return []
            raise

        files: list[PackageFileInfo] = []
        for f in files_data:
            files.append(
                PackageFileInfo(
                    id=f["id"],
                    package_id=package_id,
                    file_name=f["file_name"],
                    size=f.get("size", 0),
                    file_sha256=f.get("file_sha256", ""),
                    created_at=f.get("created_at", ""),
                )
            )

        return files

    # ------------------------------------------------------------------------------------
    def download_package_file(
        self,
        project_id: int,
        package_id: int,
        package_file_id: int,
        dest: Path,
    ) -> None:
        """
        Download a package file by its ID, streaming directly to disk.

        Uses the package file download endpoint which works for all package types.

        Parameters:
            project_id: The numeric project ID
            package_id: The numeric package ID
            package_file_id: The numeric package file ID
            dest: Destination file path

        Raises:
            urllib.error.HTTPError: On HTTP errors
        """
        url = self._api_url(
            f"/projects/{project_id}/packages/{package_id}"
            f"/package_files/{package_file_id}/download"
        )

        self.logger.debug(f"Downloading: {url}")
        request = urllib.request.Request(url)
        if self.token:
            request.add_header("PRIVATE-TOKEN", self.token)

        try:
            with urllib.request.urlopen(request) as response:
                with dest.open("wb") as f:
                    while chunk := response.read(65536):
                        f.write(chunk)
        except urllib.error.HTTPError as e:
            e.read()
            raise

    # ------------------------------------------------------------------------------------
    def upload_generic_package_file(
        self,
        project_id: int,
        package_name: str,
        package_version: str,
        file_path: Path,
    ) -> None:
        """
        Upload a file to the generic package registry.

        Parameters:
            project_id: The numeric project ID
            package_name: Name of the package
            package_version: Version of the package
            file_path: Path to the file to upload

        Raises:
            urllib.error.HTTPError: On API errors
        """
        encoded_name = urllib.parse.quote(package_name, safe="")
        encoded_version = urllib.parse.quote(package_version, safe="")
        encoded_file = urllib.parse.quote(file_path.name, safe="")

        url = self._api_url(
            f"/projects/{project_id}/packages/generic"
            f"/{encoded_name}/{encoded_version}/{encoded_file}"
        )

        self._put_file(url, file_path)

    # ------------------------------------------------------------------------------------
    def upload_pypi_package_file(
        self,
        project_id: int,
        file_path: Path,
    ) -> None:
        """
        Upload a file to the PyPI package registry.

        Uses the standard PyPI upload protocol (multipart form POST) so that
        the file appears as a proper PyPI package on the destination GitLab.

        Supports both wheels (.whl) and source distributions (.tar.gz).

        Parameters:
            project_id: The numeric project ID
            file_path: Path to the .whl or .tar.gz file to upload

        Raises:
            urllib.error.HTTPError: On API errors
            ValueError: If the filename cannot be parsed
        """
        import hashlib
        import uuid

        pkg_name, pkg_version, filetype = _parse_pypi_filename(file_path)

        url = self._api_url(f"/projects/{project_id}/packages/pypi")

        # Compute SHA256 by streaming (don't load entire file for hash)
        sha = hashlib.sha256()
        with file_path.open("rb") as f:
            while chunk := f.read(65536):
                sha.update(chunk)
        sha256 = sha.hexdigest()

        # Read file data for multipart body (unavoidable — urllib needs
        # the full body as bytes for Content-Length)
        file_data = file_path.read_bytes()
        boundary = uuid.uuid4().hex

        # Build multipart form body
        fields = {
            ":action": "file_upload",
            "name": pkg_name,
            "version": pkg_version,
            "sha256_digest": sha256,
            "filetype": filetype,
            "protocol_version": "1",
        }

        body = b""
        for name, value in fields.items():
            body += f"--{boundary}\r\n".encode()
            body += f'Content-Disposition: form-data; name="{name}"\r\n\r\n'.encode()
            body += f"{value}\r\n".encode()

        body += f"--{boundary}\r\n".encode()
        body += (
            f'Content-Disposition: form-data; name="content";'
            f' filename="{file_path.name}"\r\n'
        ).encode()
        body += b"Content-Type: application/octet-stream\r\n\r\n"
        body += file_data
        body += f"\r\n--{boundary}--\r\n".encode()

        self.logger.debug(f"POST {url}")
        request = urllib.request.Request(url, data=body, method="POST")
        request.add_header("Content-Type", f"multipart/form-data; boundary={boundary}")
        if self.token:
            request.add_header("PRIVATE-TOKEN", self.token)

        with urllib.request.urlopen(request) as response:
            response.read()

    # ------------------------------------------------------------------------------------
    def list_existing_package_files(
        self,
        project_id: int,
        package_name: str,
        package_version: str,
        package_type: str = "generic",
    ) -> list[PackageFileInfo]:
        """
        List files for a specific package version.

        This fetches the package by name/version/type and then lists its files,
        returning full file info including SHA256 for existence and integrity
        checking.

        Parameters:
            project_id: The numeric project ID
            package_name: Name of the package
            package_version: Version of the package
            package_type: Package type (e.g., "generic", "pypi")

        Returns:
            List of PackageFileInfo objects in the package version
        """
        # Find the package by name and version
        encoded_name = urllib.parse.quote(package_name, safe="")
        encoded_version = urllib.parse.quote(package_version, safe="")
        encoded_type = urllib.parse.quote(package_type, safe="")
        url = self._api_url(
            f"/projects/{project_id}/packages"
            f"?package_name={encoded_name}&package_version={encoded_version}"
            f"&package_type={encoded_type}"
        )

        try:
            packages_data = self._request(url)
        except urllib.error.HTTPError as e:
            if e.code == 404:
                return []
            raise

        if not packages_data:
            return []

        # Get files for the first matching package
        package_id = packages_data[0]["id"]
        return self.list_package_files(project_id, package_id)
