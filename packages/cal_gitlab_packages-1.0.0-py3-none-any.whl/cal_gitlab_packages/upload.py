# ----------------------------------------------------------------------------------------
#   upload
#   ------
#
#   Core upload orchestration - scans a directory of package files (in the same
#   structure produced by `download`), and uploads them to the GitLab generic
#   package registry.
#
#   Expected input directory structure:
#
#       input_dir/
#           relative/project/path/
#               package_name/
#                   version/
#                       file_1
#                       file_2
#
#   The relative project path is prepended with the --path (base group) to form
#   the full GitLab project path for each discovered project.
#
#   License
#   -------
#   MIT License - Copyright 2026 Cyber Assessment Labs
#
#   Authors
#   -------
#   bena (via claude)
#
#   Version History
#   ---------------
#   Mar 2026 - Created
# ----------------------------------------------------------------------------------------

# ----------------------------------------------------------------------------------------
#   Imports
# ----------------------------------------------------------------------------------------

import hashlib
import json
import logging
import urllib.error
from concurrent.futures import ThreadPoolExecutor
from concurrent.futures import as_completed
from dataclasses import dataclass
from pathlib import Path
from .colour import bold
from .colour import cyan
from .colour import green
from .colour import red
from .colour import yellow
from .gitlab_api import GitLabClient
from .version_filter import matches_version_filter

# ----------------------------------------------------------------------------------------
#   Types
# ----------------------------------------------------------------------------------------


@dataclass
class UploadResult:
    """Result of an upload operation."""

    success: bool
    total_projects: int = 0
    total_packages: int = 0
    total_files: int = 0
    uploaded_files: int = 0
    skipped_files: int = 0
    failed_files: int = 0
    error_message: str | None = None


@dataclass
class UploadConfig:
    """Configuration for the upload operation."""

    gitlab_url: str
    path: str
    input_dir: Path
    token: str | None = None
    version_filter: str = "all"
    project_filter: str | None = None
    project_exclude: list[str] | None = None
    parallel: int = 32
    dry_run: bool = False


@dataclass
class _UploadTask:
    """A single file upload task."""

    project_id: int
    package_name: str
    package_version: str
    file_path: Path
    file_name: str
    relative_key: str
    project_path: str
    package_type: str = "generic"


# ----------------------------------------------------------------------------------------
#   Functions
# ----------------------------------------------------------------------------------------


# ----------------------------------------------------------------------------------------
def upload_packages(config: UploadConfig) -> UploadResult:
    """
    Upload package files to GitLab projects via the generic package registry.

    Scans the input directory for package files, and uploads them to the
    generic package registry on the target GitLab instance.

    Parameters:
        config: Upload configuration

    Returns:
        UploadResult with statistics about the upload
    """
    logger = logging.getLogger(__name__)

    # Validate input directory
    if not config.input_dir.exists():
        return UploadResult(
            success=False,
            error_message=f"Input directory not found: {config.input_dir}",
        )

    if not config.input_dir.is_dir():
        return UploadResult(
            success=False,
            error_message=f"Not a directory: {config.input_dir}",
        )

    # Create GitLab client
    client = GitLabClient(config.gitlab_url, token=config.token)

    # Scan input directory
    print(f"Scanning {config.input_dir}...")
    projects_data = _scan_input_directory(config.input_dir)

    if not projects_data:
        print("No package files found in input directory.")
        return UploadResult(success=True)

    print(f"Found {len(projects_data)} project(s) with package files")

    result = UploadResult(success=True, total_projects=len(projects_data))

    # Phase 1: Resolve projects, check existing packages, gather upload tasks
    all_tasks: list[_UploadTask] = []

    print(f"Connecting to {config.gitlab_url}...")

    for relative_path in sorted(projects_data):
        packages = projects_data[relative_path]

        # Build full project path
        if relative_path:
            full_path = f"{config.path}/{relative_path}"
        else:
            full_path = config.path

        # Apply project filter and exclusions
        if config.project_filter:
            if config.project_filter.lower() not in full_path.lower():
                result.total_projects -= 1
                continue
        if config.project_exclude:
            path_lower = full_path.lower()
            if any(ex.lower() in path_lower for ex in config.project_exclude):
                result.total_projects -= 1
                continue

        print(f"\n{bold(full_path)}")

        # Resolve project on GitLab
        try:
            path_type, project_id = client.resolve_path(full_path)
            if path_type != "project":
                print(f"  {red('Error')} - Path is a group, not a project: {full_path}")
                file_count = sum(
                    len(files)
                    for versions in packages.values()
                    for files in versions.values()
                )
                result.failed_files += file_count
                result.total_files += file_count
                continue
        except ValueError:
            print(f"  {red('Error')} - Project not found: {full_path}")
            file_count = sum(
                len(files)
                for versions in packages.values()
                for files in versions.values()
            )
            result.failed_files += file_count
            result.total_files += file_count
            continue
        except urllib.error.URLError as e:
            print(f"  {red('Error')} - Connection failed: {e}")
            file_count = sum(
                len(files)
                for versions in packages.values()
                for files in versions.values()
            )
            result.failed_files += file_count
            result.total_files += file_count
            continue

        # Process each package
        for package_name in sorted(packages):
            versions = packages[package_name]

            for version in sorted(versions):
                files = versions[version]

                # Apply version filter
                if not matches_version_filter(version, config.version_filter):
                    logger.debug(f"Skipping {package_name}/{version} (version filter)")
                    continue

                # Read package type from metadata (skip if missing)
                package_type = _read_package_type(files[0].parent)
                if not package_type:
                    continue

                # Exclude metadata files from upload
                upload_files = [f for f in files if f.name != ".package-meta.json"]
                if not upload_files:
                    continue

                result.total_packages += 1
                result.total_files += len(upload_files)

                # Check which files already exist on the package registry
                # For pypi packages, the name in the registry uses hyphens
                check_name = (
                    package_name.replace("_", "-")
                    if package_type == "pypi"
                    else package_name
                )
                existing_sha: dict[str, str] = {}
                try:
                    existing_file_infos = client.list_existing_package_files(
                        project_id, check_name, version, package_type
                    )
                    existing_sha = {
                        f.file_name: f.file_sha256 for f in existing_file_infos
                    }
                except urllib.error.HTTPError:
                    pass

                # Gather upload tasks for this version
                for file_path in upload_files:
                    # Check if already exists and compare SHA256
                    if file_path.name in existing_sha:
                        result.skipped_files += 1
                        remote_sha = existing_sha[file_path.name]
                        local_sha = _file_sha256(file_path)
                        if remote_sha and local_sha != remote_sha:
                            print(
                                f"  {yellow('Mismatch')}   - "
                                f"{package_name}/{version}: {file_path.name}"
                                f" (SHA256 differs, cannot overwrite)"
                            )
                        else:
                            print(
                                f"  {yellow('Skipped')}    - "
                                f"{package_name}/{version}: {file_path.name}"
                                f" (already in registry)"
                            )
                        continue

                    all_tasks.append(
                        _UploadTask(
                            project_id=project_id,
                            package_name=package_name,
                            package_version=version,
                            file_path=file_path,
                            file_name=file_path.name,
                            relative_key=str(file_path.relative_to(config.input_dir)),
                            project_path=full_path,
                            package_type=package_type,
                        )
                    )

    if not all_tasks:
        return result

    if config.dry_run:
        print(f"\nDry run: would upload {len(all_tasks)} file(s)")
        for task in all_tasks:
            print(
                f"  {cyan('Would upload')} - "
                f"{task.package_name}/{task.package_version}: {task.file_name}"
            )
        result.uploaded_files = len(all_tasks)
        return result

    # Phase 2: Upload files in parallel
    print(f"\nUploading {len(all_tasks)} file(s) with {config.parallel} threads...")

    with ThreadPoolExecutor(max_workers=config.parallel) as executor:
        futures_list = [
            executor.submit(_upload_single_file, client, task) for task in all_tasks
        ]
        future_to_idx = {f: i for i, f in enumerate(futures_list)}
        completed_ul: dict[int, BaseException | None] = {}
        next_to_print = 0
        printed = 0

        for future in as_completed(future_to_idx):
            idx = future_to_idx[future]
            error: BaseException | None = None
            try:
                future.result()
            except (
                urllib.error.HTTPError,
                urllib.error.URLError,
                OSError,
                ValueError,
            ) as e:
                error = e
            completed_ul[idx] = error

            # Flush consecutive results in submission order
            while next_to_print in completed_ul:
                err = completed_ul.pop(next_to_print)
                task = all_tasks[next_to_print]
                printed += 1
                progress = f"[{printed}/{len(all_tasks)}]"

                if err is None:
                    result.uploaded_files += 1
                    print(
                        f"  {green('Uploaded')}   - "
                        f"{task.package_name}/{task.package_version}: "
                        f"{task.file_name}  {progress}"
                    )
                else:
                    logger.debug(f"Failed to upload {task.file_name}: {err}")
                    result.failed_files += 1
                    reason = ""
                    if isinstance(err, urllib.error.HTTPError):
                        reason = f" ({err.code})"
                    print(
                        f"  {red('Error')}{reason:6s} - "
                        f"{task.package_name}/{task.package_version}: "
                        f"{task.file_name}  {progress}"
                    )
                next_to_print += 1

    return result


# ----------------------------------------------------------------------------------------
def _file_sha256(file_path: Path) -> str:
    """
    Compute the SHA256 hex digest of a file.

    Parameters:
        file_path: Path to the file

    Returns:
        Hex-encoded SHA256 digest
    """
    h = hashlib.sha256()
    with file_path.open("rb") as f:
        while chunk := f.read(65536):
            h.update(chunk)
    return h.hexdigest()


# ----------------------------------------------------------------------------------------
def _read_package_type(version_dir: Path) -> str | None:
    """
    Read the package type from .package-meta.json in a version directory.

    Parameters:
        version_dir: Path to the version directory

    Returns:
        Package type string, or None if no metadata found
    """
    meta_path = version_dir / ".package-meta.json"
    if not meta_path.exists():
        return None
    try:
        with meta_path.open() as f:
            data = json.load(f)
            return str(data.get("package_type", ""))
    except (json.JSONDecodeError, OSError):
        return None


# ----------------------------------------------------------------------------------------
def _upload_single_file(client: GitLabClient, task: _UploadTask) -> None:
    """
    Upload a single file to the appropriate package registry.

    Routes to the correct upload API based on the package type:
    - pypi: Uses the PyPI upload protocol (multipart POST)
    - generic (default): Uses the generic package registry (PUT)

    This function runs in a worker thread.

    Parameters:
        client: GitLab API client
        task: Upload task with file path and package info
    """
    try:
        if task.package_type == "pypi":
            client.upload_pypi_package_file(
                task.project_id,
                task.file_path,
            )
        else:
            client.upload_generic_package_file(
                task.project_id,
                task.package_name,
                task.package_version,
                task.file_path,
            )
    except urllib.error.HTTPError as e:
        if e.code in (403, 409):
            # File already exists — treat as success (idempotent)
            return
        raise


# ----------------------------------------------------------------------------------------
def _scan_input_directory(
    input_dir: Path,
) -> dict[str, dict[str, dict[str, list[Path]]]]:
    """
    Scan the input directory for package files.

    Identifies the directory structure as:
        input_dir/project_path/package_name/version/files

    A version directory is one that contains actual files. The package name
    directory is its parent, and the project path is everything above that
    relative to input_dir.

    Parameters:
        input_dir: Root directory to scan

    Returns:
        Dict mapping relative_project_path -> {package_name -> {version -> [file_paths]}}
        An empty relative_project_path ("") means files are directly under
        input_dir/package_name/version/ (single project mode).
    """
    result: dict[str, dict[str, dict[str, list[Path]]]] = {}

    for item in sorted(input_dir.rglob("*")):
        if not item.is_dir():
            continue

        # A version directory is one that contains actual files
        files = sorted(f for f in item.iterdir() if f.is_file())
        if not files:
            continue

        version = item.name
        package_name_dir = item.parent

        # Must have at least package_name/version depth
        try:
            rel_to_input = package_name_dir.relative_to(input_dir)
        except ValueError:
            continue

        # The package name is the immediate parent of the version dir
        package_name = package_name_dir.name

        # The project path is everything above the package name dir
        try:
            project_rel = package_name_dir.parent.relative_to(input_dir)
        except ValueError:
            continue

        project_path = str(project_rel) if str(project_rel) != "." else ""

        # Ensure the package_name is not just the input_dir itself
        if str(rel_to_input) == ".":
            continue

        if project_path not in result:
            result[project_path] = {}
        if package_name not in result[project_path]:
            result[project_path][package_name] = {}
        result[project_path][package_name][version] = files

    return result


# ----------------------------------------------------------------------------------------
def format_result_summary(result: UploadResult) -> str:
    """
    Format a human-readable summary of the upload result.

    Parameters:
        result: The upload result to summarise

    Returns:
        Formatted summary string
    """
    lines: list[str] = []
    lines.append("")
    lines.append("Upload Summary")
    lines.append("==============")
    lines.append(f"Total projects:  {result.total_projects}")
    lines.append(f"Total packages:  {result.total_packages}")
    lines.append(f"Total files:     {result.total_files}")
    lines.append(f"Uploaded:        {result.uploaded_files}")

    if result.skipped_files > 0:
        lines.append(f"Skipped:         {result.skipped_files} (already exist)")

    if result.failed_files > 0:
        lines.append(f"Failed:          {result.failed_files}")

    return "\n".join(lines)
