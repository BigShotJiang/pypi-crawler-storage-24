# ----------------------------------------------------------------------------------------
#   download
#   --------
#
#   Core download orchestration - resolves GitLab paths (group or project), fetches
#   package files, and saves them to disk. Skips already-downloaded files by default.
#
#   Downloads are parallelised using a thread pool for fast I/O throughput.
#
#   Output directory structure:
#
#       output_dir/
#           relative/project/path/
#               package_name/
#                   version/
#                       file_1
#                       file_2
#
#   License
#   -------
#   MIT License - Copyright 2026 Cyber Assessment Labs
#
#   Authors
#   -------
#   bena (via claude)
#
#   Version History
#   ---------------
#   Mar 2026 - Created
# ----------------------------------------------------------------------------------------

# ----------------------------------------------------------------------------------------
#   Imports
# ----------------------------------------------------------------------------------------

import json
import logging
import sys
import urllib.error
from collections.abc import Iterator
from concurrent.futures import ThreadPoolExecutor
from concurrent.futures import as_completed
from dataclasses import dataclass
from dataclasses import field
from datetime import UTC
from datetime import datetime
from pathlib import Path
from typing import Any
from .colour import bold
from .colour import green
from .colour import red
from .colour import yellow
from .gitlab_api import GitLabClient
from .gitlab_api import PackageFileInfo
from .gitlab_api import PackageInfo
from .gitlab_api import ProjectInfo
from .version_filter import matches_version_filter

# ----------------------------------------------------------------------------------------
#   Constants
# ----------------------------------------------------------------------------------------

# Package types we can download and re-upload.  Other types (npm, maven, etc.)
# require registry-specific upload protocols we don't support yet.
SUPPORTED_PACKAGE_TYPES = {"generic", "pypi"}

# ----------------------------------------------------------------------------------------
#   Types
# ----------------------------------------------------------------------------------------


@dataclass
class DownloadResult:
    """Result of a download operation."""

    success: bool
    total_projects: int = 0
    total_packages: int = 0
    total_files: int = 0
    downloaded_files: int = 0
    skipped_files: int = 0
    failed_files: int = 0
    error_message: str | None = None
    downloaded_paths: list[Path] = field(default_factory=lambda: list[Path]())


@dataclass
class DownloadConfig:
    """Configuration for the download operation."""

    gitlab_url: str
    path: str
    output_dir: Path
    token: str | None = None
    version_filter: str = "release"
    project_filter: str | None = None
    project_exclude: list[str] | None = None
    package_type: str | None = None
    overwrite: bool = False
    flat: bool = False
    parallel: int = 32
    manifest_path: Path | None = None
    max_file_size: int | None = None
    max_total_size: int | None = None


@dataclass
class _DownloadTask:
    """A single file download task."""

    project_id: int
    package_id: int
    package_file_id: int
    file_path: Path
    package_name: str
    package_version: str
    file_name: str
    file_size: int
    project_path: str


# ----------------------------------------------------------------------------------------
#   Functions
# ----------------------------------------------------------------------------------------


# ----------------------------------------------------------------------------------------
def download_packages(config: DownloadConfig) -> DownloadResult:
    """
    Download package files from a GitLab project or group.

    If the path is a group, all projects within the group (including subgroups)
    are processed. If the path is a project, only that project is processed.

    Downloads are executed in parallel using a thread pool.

    Parameters:
        config: Download configuration

    Returns:
        DownloadResult with statistics about the download
    """
    logger = logging.getLogger(__name__)

    print(f"Downloading packages from {config.gitlab_url} ({config.path})...")

    # Validate output directory
    output_dir = config.output_dir
    if not output_dir.exists():
        output_dir.mkdir(parents=True, exist_ok=True)

    # Create GitLab client
    client = GitLabClient(config.gitlab_url, token=config.token)

    # Resolve path to group or project
    try:
        path_type, path_id = client.resolve_path(config.path)
    except ValueError as e:
        return DownloadResult(success=False, error_message=str(e))
    except urllib.error.URLError as e:
        return DownloadResult(
            success=False,
            error_message=f"Failed to connect to GitLab: {e}",
        )

    # Load manifest for incremental downloads
    manifest: dict[str, dict[str, str]] = {}
    if config.manifest_path:
        manifest = _load_manifest(config.manifest_path)

    # Fetch all packages — use the group-level API for groups (1-2 paginated
    # calls) instead of per-project calls (80+).  For single projects, use
    # the project-level API.
    all_packages: list[PackageInfo] = []

    if path_type == "group":
        try:
            all_packages = client.list_group_packages(
                path_id, package_type=config.package_type
            )
        except urllib.error.HTTPError as e:
            return DownloadResult(
                success=False,
                error_message=f"Failed to list group packages: {e}",
            )
    else:
        try:
            all_packages = client.list_packages(
                path_id, package_type=config.package_type
            )
        except urllib.error.HTTPError as e:
            return DownloadResult(
                success=False,
                error_message=f"Failed to list project packages: {e}",
            )

    # Filter to supported package types (unless a specific type was requested)
    if not config.package_type:
        all_packages = [
            p for p in all_packages if p.package_type in SUPPORTED_PACKAGE_TYPES
        ]

    # Apply version filter
    all_packages = [
        p
        for p in all_packages
        if matches_version_filter(p.version, config.version_filter)
    ]

    # Track the newest package timestamp for the manifest
    newest_created_at = max(p.created_at for p in all_packages) if all_packages else ""

    # Early exit: check if the newest package is older than our last scan
    if config.manifest_path and manifest and newest_created_at:
        last_seen = manifest.get("__meta__", {}).get("last_seen_at", "")
        if last_seen and newest_created_at <= last_seen:
            print("  No new packages since last run")
            return DownloadResult(success=True)

    # Group packages by project, applying filters/exclusions
    project_packages: dict[int, list[PackageInfo]] = {}
    project_paths: dict[int, str] = {}

    for pkg in all_packages:
        proj_path = _get_package_project_path(pkg, config.path, path_type)

        # Apply project filter
        if config.project_filter:
            if config.project_filter.lower() not in proj_path.lower():
                continue

        # Apply project exclusions
        if config.project_exclude:
            path_lower = proj_path.lower()
            if any(ex.lower() in path_lower for ex in config.project_exclude):
                continue

        if pkg.project_id not in project_packages:
            project_packages[pkg.project_id] = []
            project_paths[pkg.project_id] = proj_path
        project_packages[pkg.project_id].append(pkg)

    result = DownloadResult(
        success=True,
        total_projects=len(project_packages),
    )

    if not project_packages:
        return result

    # Phase 1: Fetch file listings and gather download tasks
    all_tasks: list[_DownloadTask] = []
    is_group = path_type == "group"
    group_path = config.path if is_group else None

    # Build per-project structures and collect packages needing file listings
    sorted_project_ids = sorted(project_packages, key=lambda k: project_paths[k])
    project_infos: dict[int, ProjectInfo] = {}
    project_dirs: dict[int, Path] = {}
    packages_needing_files: list[tuple[int, PackageInfo]] = []

    for project_id in sorted_project_ids:
        packages = project_packages[project_id]
        proj_path = project_paths[project_id]

        project = ProjectInfo(
            id=project_id,
            name=proj_path.rsplit("/", 1)[-1],
            path_with_namespace=proj_path,
        )
        project_infos[project_id] = project

        # Determine project output directory
        if config.flat:
            project_dir = output_dir
        elif is_group and group_path:
            relative_path = proj_path
            if relative_path.startswith(group_path + "/"):
                relative_path = relative_path[len(group_path) + 1 :]
            project_dir = output_dir / relative_path
        else:
            project_dir = output_dir
        project_dirs[project_id] = project_dir

        for pkg in packages:
            packages_needing_files.append((project_id, pkg))

    # Fetch all file listings in a single parallel pool
    logger = logging.getLogger(__name__)

    def fetch_files(item: tuple[int, PackageInfo]) -> list[PackageFileInfo]:
        pid, pkg = item
        try:
            return client.list_package_files(pid, pkg.id)
        except urllib.error.HTTPError as e:
            logger.warning(f"Failed to list files for {pkg.name}/{pkg.version}: {e}")
            return []

    fetched_files: dict[int, list[PackageFileInfo]] = {}
    if packages_needing_files:
        with ThreadPoolExecutor(max_workers=config.parallel) as executor:
            file_results = list(executor.map(fetch_files, packages_needing_files))
        for (_, pkg), files in zip(packages_needing_files, file_results, strict=True):
            fetched_files[pkg.id] = files

    # Gather download tasks per project
    projects_with_packages = 0
    for project_id in sorted_project_ids:
        packages = project_packages[project_id]
        project = project_infos[project_id]
        project_dir = project_dirs[project_id]
        proj_path = project_paths[project_id]

        proj_tasks: list[_DownloadTask] = []
        proj_skipped = 0

        for pkg in packages:
            pkg.files = fetched_files.get(pkg.id, [])
            pkg_tasks, pkg_skipped = _gather_package_tasks(
                package=pkg,
                project_dir=project_dir,
                output_dir=output_dir,
                config=config,
                project=project,
                manifest=manifest,
            )
            proj_tasks.extend(pkg_tasks)
            proj_skipped += pkg_skipped

        if not proj_tasks and not proj_skipped:
            continue
        projects_with_packages += 1
        all_tasks.extend(proj_tasks)
        result.skipped_files += proj_skipped
        result.total_packages += len(packages)

        # Print per-project status line
        parts: list[str] = []
        if proj_tasks:
            parts.append(f"{len(proj_tasks)} new")
        if proj_skipped:
            parts.append(f"{proj_skipped} skipped")
        status = ", ".join(parts)
        counter = f"[{projects_with_packages}]"
        print(f"  {proj_path}: {status}  {counter}")

    # Apply max-total-size budget: trim the task list so cumulative size
    # stays within budget.  Tasks with unknown size (0) are kept.
    if config.max_total_size is not None and all_tasks:
        budget = config.max_total_size
        kept: list[_DownloadTask] = []
        for task in all_tasks:
            if task.file_size > 0:
                if budget - task.file_size < 0:
                    result.skipped_files += 1
                    continue
                budget -= task.file_size
            kept.append(task)
        all_tasks = kept

    result.total_files = len(all_tasks) + result.skipped_files

    if not all_tasks:
        if config.manifest_path:
            if newest_created_at:
                manifest["__meta__"] = {"last_seen_at": newest_created_at}
            _save_manifest(config.manifest_path, manifest)
        return result

    # Phase 2: Download in parallel
    print(f"Downloading {len(all_tasks)} file(s)...")

    with ThreadPoolExecutor(max_workers=config.parallel) as executor:
        futures_list = [
            executor.submit(_download_single_file, client, task) for task in all_tasks
        ]
        future_to_idx = {f: i for i, f in enumerate(futures_list)}
        completed_dl: dict[int, BaseException | None] = {}
        next_to_print = 0
        printed = 0

        for future in as_completed(future_to_idx):
            idx = future_to_idx[future]
            error: BaseException | None = None
            try:
                future.result()
            except (urllib.error.HTTPError, urllib.error.URLError) as e:
                error = e
            completed_dl[idx] = error

            # Flush consecutive results in submission order
            while next_to_print in completed_dl:
                err = completed_dl.pop(next_to_print)
                task = all_tasks[next_to_print]
                printed += 1
                progress = f"[{printed}/{len(all_tasks)}]"

                if err is None:
                    result.downloaded_files += 1
                    result.downloaded_paths.append(task.file_path)
                    print(
                        f"  {green('Downloaded')} - "
                        f"{task.package_name}/{task.package_version}: "
                        f"{task.file_name}  {progress}"
                    )
                else:
                    logger.debug(f"Failed to download {task.file_name}: {err}")
                    result.failed_files += 1
                    reason = ""
                    if isinstance(err, urllib.error.HTTPError):
                        reason = f" ({err.code})"
                    print(
                        f"  {red('Error')}{reason:6s} - "
                        f"{task.package_name}/{task.package_version}: "
                        f"{task.file_name}  {progress}"
                    )
                next_to_print += 1

    # Update manifest with all attempted downloads (successful and failed)
    if config.manifest_path:
        now = datetime.now(UTC).isoformat()
        for task in all_tasks:
            key = str(task.file_path.relative_to(output_dir))
            status = (
                "downloaded" if task.file_path in result.downloaded_paths else "failed"
            )
            manifest[key] = {"path": key, "status": status, "downloaded": now}
        if newest_created_at:
            manifest["__meta__"] = {"last_seen_at": newest_created_at}
        _save_manifest(config.manifest_path, manifest)

    return result


# ----------------------------------------------------------------------------------------
def _get_package_project_path(
    pkg: PackageInfo, config_path: str, path_type: str
) -> str:
    """
    Determine the full project path for a package.

    For group-level listings, project_path comes from the API response.
    For single-project mode, use the config path.

    Parameters:
        pkg: Package info
        config_path: The --path value from config
        path_type: "group" or "project"

    Returns:
        Full project path (e.g., "cyberassessmentlabs/private/tools/acqd")
    """
    if path_type == "project" or not pkg.project_path:
        return config_path
    return pkg.project_path


# ----------------------------------------------------------------------------------------
def _fetch_packages_streaming(
    client: GitLabClient,
    projects: list[ProjectInfo],
    max_workers: int,
    package_type: str | None,
) -> Iterator[tuple[ProjectInfo, list[PackageInfo]]]:
    """
    Fetch package listings for multiple projects in parallel, yielding results
    in the original project order as they become available.

    Results are buffered so that earlier projects are always yielded first,
    even if later projects finish sooner.

    Parameters:
        client: GitLab API client
        projects: Projects to fetch packages for
        max_workers: Number of parallel threads
        package_type: Optional package type filter

    Yields:
        (project, packages) tuples in the original project order
    """
    logger = logging.getLogger(__name__)

    def fetch(project: ProjectInfo) -> list[PackageInfo]:
        try:
            return client.list_packages(project.id, package_type=package_type)
        except urllib.error.HTTPError as e:
            logger.warning(
                f"Failed to list packages for {project.path_with_namespace}: {e}"
            )
            return []

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures_list = [executor.submit(fetch, p) for p in projects]
        future_to_idx = {f: i for i, f in enumerate(futures_list)}
        completed: dict[int, list[PackageInfo]] = {}
        next_idx = 0

        for future in as_completed(future_to_idx):
            idx = future_to_idx[future]
            completed[idx] = future.result()

            while next_idx in completed:
                yield projects[next_idx], completed.pop(next_idx)
                next_idx += 1


# ----------------------------------------------------------------------------------------
def _gather_package_tasks(
    *,
    package: PackageInfo,
    project_dir: Path,
    output_dir: Path,
    config: DownloadConfig,
    project: ProjectInfo,
    manifest: dict[str, dict[str, str]],
) -> tuple[list[_DownloadTask], int]:
    """
    Gather download tasks for a single package.

    Parameters:
        package: Package to gather tasks from
        project_dir: Project output directory
        output_dir: Base output directory (for computing manifest keys)
        config: Download configuration
        project: Project info for display
        manifest: Dict mapping relative paths to manifest entries

    Returns:
        Tuple of (download_tasks, skipped_count)
    """
    if not package.files:
        return [], 0

    if config.flat:
        version_dir = output_dir
    else:
        version_dir = project_dir / package.name / package.version

    dir_created = False

    tasks: list[_DownloadTask] = []
    skipped = 0

    for pkg_file in package.files:
        file_path = version_dir / pkg_file.file_name
        relative_key = str(file_path.relative_to(output_dir))

        # Skip if already in manifest or file exists on disk
        if not config.overwrite:
            if relative_key in manifest or file_path.exists():
                if relative_key not in manifest:
                    manifest[relative_key] = {"path": relative_key, "status": "exists"}
                skipped += 1
                continue

        # Skip if file exceeds per-file size limit
        if (
            config.max_file_size is not None
            and pkg_file.size > 0
            and pkg_file.size > config.max_file_size
        ):
            skipped += 1
            continue

        if not dir_created:
            version_dir.mkdir(parents=True, exist_ok=True)
            _save_package_meta(version_dir, package.package_type)
            dir_created = True

        tasks.append(
            _DownloadTask(
                project_id=project.id,
                package_id=package.id,
                package_file_id=pkg_file.id,
                file_path=file_path,
                package_name=package.name,
                package_version=package.version,
                file_name=pkg_file.file_name,
                file_size=pkg_file.size,
                project_path=project.path_with_namespace,
            )
        )

    return tasks, skipped


# ----------------------------------------------------------------------------------------
def _save_package_meta(version_dir: Path, package_type: str) -> None:
    """
    Save package metadata to a version directory.

    Writes a .package-meta.json file so the upload side knows which registry
    API to use (e.g., generic vs pypi).

    Parameters:
        version_dir: The version directory to save metadata in
        package_type: The package type (e.g., "generic", "pypi")
    """
    meta_path = version_dir / ".package-meta.json"
    if meta_path.exists():
        return
    try:
        with meta_path.open("w") as f:
            json.dump({"package_type": package_type}, f)
            f.write("\n")
    except OSError:
        pass


# ----------------------------------------------------------------------------------------
def _download_single_file(client: GitLabClient, task: _DownloadTask) -> None:
    """
    Download a single file and write it to disk.

    This function runs in a worker thread.

    Parameters:
        client: GitLab API client
        task: Download task with project/package/file IDs and destination path
    """
    client.download_package_file(
        task.project_id, task.package_id, task.package_file_id, task.file_path
    )


# ----------------------------------------------------------------------------------------
def _load_manifest(manifest_path: Path) -> dict[str, dict[str, str]]:
    """
    Load the download manifest from disk.

    Parameters:
        manifest_path: Path to the manifest JSON file

    Returns:
        Dict mapping relative file paths to entry dicts (status, downloaded)
    """
    if not manifest_path.exists():
        return {}

    try:
        with manifest_path.open() as f:
            data: dict[str, Any] = json.load(f)
            entries: list[dict[str, str]] = data.get("entries", [])
            result: dict[str, dict[str, str]] = {
                e["path"]: e for e in entries if "path" in e
            }
            meta: dict[str, str] | None = data.get("meta")
            if meta:
                result["__meta__"] = meta
            return result
    except (json.JSONDecodeError, OSError, TypeError) as e:
        print(
            yellow(f"Warning: Could not read manifest {manifest_path}: {e}"),
            file=sys.stderr,
        )

    return {}


# ----------------------------------------------------------------------------------------
def _save_manifest(manifest_path: Path, manifest: dict[str, dict[str, str]]) -> None:
    """
    Save the download manifest to disk.

    Parameters:
        manifest_path: Path to the manifest JSON file
        manifest: Dict mapping relative file paths to entry dicts
    """
    meta = manifest.pop("__meta__", None)
    entries = sorted(manifest.values(), key=lambda e: e.get("path", ""))
    data: dict[str, Any] = {"entries": entries}
    if meta:
        data["meta"] = meta
        manifest["__meta__"] = meta  # Restore for caller
    try:
        with manifest_path.open("w") as f:
            json.dump(data, f, indent=2)
            f.write("\n")
    except OSError as e:
        print(
            yellow(f"Warning: Could not write manifest {manifest_path}: {e}"),
            file=sys.stderr,
        )


# ----------------------------------------------------------------------------------------
def list_projects(config: DownloadConfig, *, json_output: bool = False) -> int:
    """
    List projects for the given path and exit.

    Parameters:
        config: Download configuration
        json_output: If True, output as JSON

    Returns:
        Exit code (0 for success, 1 for error)
    """
    client = GitLabClient(config.gitlab_url, token=config.token)

    try:
        path_type, path_id = client.resolve_path(config.path)
    except ValueError as e:
        print(f"Error: {e}")
        return 1
    except urllib.error.URLError as e:
        print(f"Error: Failed to connect to GitLab: {e}")
        return 1

    projects: list[ProjectInfo] = []

    if path_type == "group":
        try:
            projects = client.get_group_projects(
                path_id,
                project_filter=config.project_filter,
                project_exclude=config.project_exclude,
            )
        except urllib.error.HTTPError as e:
            print(f"Error: Failed to list group projects: {e}")
            return 1
    else:
        project_info = client.get_project_info(path_id)
        if project_info is None:
            print(f"Error: Project not found: {config.path}")
            return 1
        projects = [project_info]

    if json_output:
        json_list: list[dict[str, object]] = [
            {"id": p.id, "path": p.path_with_namespace, "name": p.name}
            for p in projects
        ]
        print(json.dumps(json_list, indent=2))
    else:
        for project in projects:
            print(project.path_with_namespace)

    return 0


# ----------------------------------------------------------------------------------------
def list_packages(config: DownloadConfig, *, json_output: bool = False) -> int:
    """
    List packages for the given path and exit.

    Parameters:
        config: Download configuration
        json_output: If True, output as JSON

    Returns:
        Exit code (0 for success, 1 for error)
    """
    client = GitLabClient(config.gitlab_url, token=config.token)

    try:
        path_type, path_id = client.resolve_path(config.path)
    except ValueError as e:
        print(f"Error: {e}")
        return 1
    except urllib.error.URLError as e:
        print(f"Error: Failed to connect to GitLab: {e}")
        return 1

    projects: list[ProjectInfo] = []

    if path_type == "group":
        try:
            projects = client.get_group_projects(
                path_id,
                project_filter=config.project_filter,
                project_exclude=config.project_exclude,
            )
        except urllib.error.HTTPError as e:
            print(f"Error: Failed to list group projects: {e}")
            return 1
    else:
        project_info = client.get_project_info(path_id)
        if project_info is None:
            print(f"Error: Project not found: {config.path}")
            return 1
        projects = [project_info]

    json_data: list[dict[str, object]] = []

    # Fetch package listings in parallel, processing each project as results arrive
    for project, packages in _fetch_packages_streaming(
        client, projects, config.parallel, config.package_type
    ):
        if not packages:
            continue

        if not json_output:
            print(f"{bold(project.path_with_namespace)}")

        # Filter packages by version
        filtered = [
            p
            for p in packages
            if matches_version_filter(p.version, config.version_filter)
        ]

        if not json_output and len(filtered) < len(packages):
            print(
                f"  Filtered to {len(filtered)} of {len(packages)} package(s) "
                f"(mode: {config.version_filter})"
            )

        if json_output:
            for package in filtered:
                json_data.append(
                    {
                        "project": project.path_with_namespace,
                        "name": package.name,
                        "version": package.version,
                        "type": package.package_type,
                    }
                )
        else:
            for package in filtered:
                print(f"  {package.name} {package.version} ({package.package_type})")

    if json_output:
        print(json.dumps(json_data, indent=2))

    return 0


# ----------------------------------------------------------------------------------------
def format_result_summary(result: DownloadResult) -> str:
    """
    Format a human-readable summary of the download result.

    Parameters:
        result: The download result to summarise

    Returns:
        Formatted summary string
    """
    lines: list[str] = []
    lines.append("")
    lines.append("Download Summary")
    lines.append("================")
    lines.append(f"Total projects: {result.total_projects}")
    lines.append(f"Total packages: {result.total_packages}")
    lines.append(f"Total files:    {result.total_files}")
    lines.append(f"Downloaded:     {result.downloaded_files}")

    if result.skipped_files > 0:
        lines.append(f"Skipped:        {result.skipped_files} (already exist)")

    if result.failed_files > 0:
        lines.append(f"Failed:         {result.failed_files}")

    return "\n".join(lines)
