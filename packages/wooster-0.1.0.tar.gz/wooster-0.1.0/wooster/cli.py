import argparse

from . import __version__
from .commands import (
    cmd_add, cmd_bar, cmd_clear, cmd_default, cmd_done, cmd_kill, cmd_list,
    cmd_rm, cmd_scan, cmd_show, cmd_todo, cmd_todo_done, cmd_top, cmd_update,
    cmd_watch,
)


def main():
    parser = argparse.ArgumentParser(
        prog="wooster",
        description="Track AI agents (Claude Code, Codex, Gemini, etc.) in real time.",
    )
    parser.add_argument("-v", "--version", action="version", version=f"%(prog)s {__version__}")
    sub = parser.add_subparsers(dest="command")

    p_list = sub.add_parser("list", aliases=["ls"], help="Auto-scan + list all agents")
    p_list.add_argument("--no-scan", action="store_true", help="Skip auto-scan, show DB state only")

    p_watch = sub.add_parser("watch", aliases=["w"], help="Re-scan and print every N seconds")
    p_watch.add_argument("-n", "--interval", type=int, default=2, help="Refresh interval in seconds (default: 2)")

    sub.add_parser("scan", help="One-shot scan, show raw process info")

    p_show = sub.add_parser("show", help="Show agent detail + todos")
    p_show.add_argument("id", type=int)

    p_add = sub.add_parser("add", help="Manually register an agent")
    p_add.add_argument("name", help="Agent name/label")
    p_add.add_argument("-t", "--type", default="claude",
                       choices=["claude", "codex", "gemini", "gpt", "copilot", "cursor", "aider", "other"])
    p_add.add_argument("-s", "--summary", help="What this agent is working on")
    p_add.add_argument(
        "--status",
        default="paused",
        choices=["running", "done", "error", "paused", "waiting"],
        help="Initial status for manual entries (default: paused)",
    )

    p_upd = sub.add_parser("update", help="Update an agent")
    p_upd.add_argument("id", type=int)
    p_upd.add_argument("-s", "--status", choices=["running", "done", "error", "paused", "waiting"])
    p_upd.add_argument("--summary")
    p_upd.add_argument("--name")
    p_upd.add_argument("-t", "--type")

    p_done = sub.add_parser("done", help="Mark agent as done")
    p_done.add_argument("id", type=int)

    p_todo = sub.add_parser("todo", help="Add a todo to an agent")
    p_todo.add_argument("agent_id", type=int)
    p_todo.add_argument("description")

    p_td = sub.add_parser("todo-done", help="Mark a todo as completed")
    p_td.add_argument("agent_id", type=int)
    p_td.add_argument("todo_id", type=int)

    p_kill = sub.add_parser("kill", help="Terminate an agent's process")
    p_kill.add_argument("id", type=int)

    p_rm = sub.add_parser("rm", help="Remove an agent from the list")
    p_rm.add_argument("id", type=int)

    p_top = sub.add_parser("top", help="Interactive htop-style agent monitor")
    p_top.add_argument("-n", "--interval", type=int, default=2, help="Refresh interval in seconds (default: 2)")

    p_bar = sub.add_parser("bar", help="Single-line compact status (for tmux/small panes)")
    p_bar.add_argument("--watch", action="store_true", help="Continuously update the status line")
    p_bar.add_argument("-n", "--interval", type=int, default=5, help="Refresh interval in seconds (default: 5)")

    sub.add_parser("clear", help="Remove all agents")

    args = parser.parse_args()

    cmd_map = {
        "list": cmd_list, "ls": cmd_list,
        "watch": cmd_watch, "w": cmd_watch,
        "scan": cmd_scan,
        "show": cmd_show,
        "add": cmd_add,
        "update": cmd_update,
        "done": cmd_done,
        "todo": cmd_todo,
        "todo-done": cmd_todo_done,
        "kill": cmd_kill,
        "top": cmd_top,
        "rm": cmd_rm,
        "bar": cmd_bar,
        "clear": cmd_clear,
    }

    handler = cmd_map.get(args.command, cmd_default)
    handler(args)


if __name__ == "__main__":
    main()
