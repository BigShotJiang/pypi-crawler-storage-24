# Changelog

All notable changes to this project will be documented in this file.

## [0.1.0] - 2026-03-21

### Added

- Initial release
- CLI entry point with argparse subcommands
- SQLite database storage at `~/.wooster/wooster.db` with WAL mode
- **Auto-discovery**: scans `ps` for running Claude Code, Codex, Gemini, Aider, Copilot, Cursor, and GPT CLI processes
- **Child process deduplication**: filters out subprocess forks, only tracks leader processes
- **Duplicate numbering**: multiple sessions in the same directory get `#1`, `#2`, etc.
- **Idle heuristic**: flags likely-idle agents with sleeping state + low CPU + no network activity as `🔔 idle?`
- **CWD resolution**: uses `lsof` to find the working directory of each agent process
- **Watch mode**: `wooster watch [-n SECONDS]` for continuous terminal refresh
- **Manual agent management**: `add`, `update`, `done`, `rm`, `clear`
- **Todo system**: attach and complete todos per agent
- **Sorted output**: waiting agents at top, done agents at bottom
- **Stats bar**: summary counts with timestamp
- **Emoji icons**: per-type and per-status visual indicators
