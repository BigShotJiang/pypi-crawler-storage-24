"""Test the ExecBlock class."""
