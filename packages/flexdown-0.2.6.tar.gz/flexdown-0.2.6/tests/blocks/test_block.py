"""Test the block class."""
