"""Test the EvalBlock class."""
