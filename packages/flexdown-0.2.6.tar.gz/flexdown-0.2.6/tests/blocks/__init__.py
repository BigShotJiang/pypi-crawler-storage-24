"""Test the block classes."""
