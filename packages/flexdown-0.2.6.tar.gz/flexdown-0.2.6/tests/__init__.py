"""Test the flexdown classes."""
