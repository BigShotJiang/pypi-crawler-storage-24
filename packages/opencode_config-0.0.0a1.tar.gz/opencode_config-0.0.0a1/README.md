# opencode-config

Tool for statically configuring OpenCode CLI
