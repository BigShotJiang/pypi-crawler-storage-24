"""Tool for statically configuring OpenCode CLI"""

__version__ = "0.0.0a1"
