# SciTeX Skills

Auto-generated AI agent skill pages for the [SciTeX](https://scitex.ai) ecosystem.

Updated daily from PyPI via GitHub Actions.

## How it works

A daily CI workflow:
1. Installs `scitex-dev` from PyPI
2. Calls `export_skills(source="pypi")` to download all SciTeX wheels
3. Extracts `_skills/` markdown files from each wheel
4. Commits any changes to `skills/`

## Browse Skills

See the [`skills/`](skills/) directory for all available skill pages.

## Manual Update

```bash
pip install scitex-dev
python -c "from pathlib import Path; from scitex_dev.skills import export_skills; export_skills(source='pypi', dest=Path('skills'))"
```
