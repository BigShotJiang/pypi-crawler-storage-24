---
name: scitex
description: SciTeX ecosystem skills — general standards, package-specific guides, and workflow references. Use when working on any SciTeX package.
user-invocable: false
---

# SciTeX Ecosystem Skills

## General Standards
- For ecosystem-wide standards, see [general/SKILL.md](general/SKILL.md)

## Package Skills
- [crossref-local](crossref-local/SKILL.md)
- [figrecipe](figrecipe/SKILL.md)
- [references](references/SKILL.md)
- [scitex](scitex/SKILL.md)
- [scitex-app](scitex-app/SKILL.md)
- [scitex-audio](scitex-audio/SKILL.md)
- [scitex-clew](scitex-clew/SKILL.md)
- [scitex-dataset](scitex-dataset/SKILL.md)
- [scitex-dev](scitex-dev/SKILL.md)
- [scitex-io](scitex-io/SKILL.md)
- [scitex-stats](scitex-stats/SKILL.md)
- [scitex-writer](scitex-writer/SKILL.md)
