#!/usr/bin/env python

# This Source Code Form is subject to the terms of the Mozilla Public
# License, v. 2.0. If a copy of the MPL was not distributed with this
# file, You can obtain one at http://mozilla.org/MPL/2.0/.


import os
import subprocess

from SCons.Script import Builder
from SCons.Script import Environment

from scons_xo_exts_lib.BuildSupport import NodeMangling


def _get_elm_exe(env: Environment) -> str:
    """
    Get the Elm compiler from PATH.
    """

    return env.get("ELM_EXE", "elm")


def _get_elm_json(source: list):
    """
    Find the 1st elm.json - the main project file from Elm-based projects.
    """

    for source_node in source:
        path = source_node.abspath

        if "elm.json" in path:
            return path

    raise RuntimeError("No elm-project in specified sources")


def _elm_make_command(
    env: Environment,
    cwd: str,
    cmd_args: list[str],
    srcs: list[str],
    output_path: str,
) -> int:
    """
    Build a Elm "binary" JS file.
    """

    elm_exe = _get_elm_exe(env)

    elm_flags = env.get("ELM_FLAGS", "")
    elm_make_flags = env.get("ELM_MAKE_FLAGS", "--optimize")

    cmd_args_str: str = " ".join(cmd_args)
    srcs_str: str = " ".join(srcs)

    cmd = (
        f"{elm_exe} make {cmd_args_str} {elm_flags} {elm_make_flags} "
        + f"--output={output_path} {srcs_str}"
    )
    print(cmd)

    result = subprocess.run(
        args=cmd,
        capture_output=False,
        check=False,
        cwd=cwd,
        shell=True,
    )

    return result.returncode


def elm_build_action(target, source, env) -> int:
    """
    SCons build action for the ElmBinary.
    """

    elm_project = _get_elm_json(source=source)
    elm_base_dir = os.path.dirname(elm_project)

    elm_pure_srcs = [os.path.abspath(str(s)) for s in source if str(s).endswith(".elm")]

    output_path = NodeMangling.get_first_node(target).abspath

    result = _elm_make_command(
        env=env,
        cwd=elm_base_dir,
        cmd_args=[],
        srcs=elm_pure_srcs,
        output_path=output_path,
    )

    return result


def generate(env: Environment) -> None:
    elm_binary_builder = Builder(action=elm_build_action)

    env.Append(
        BUILDERS={
            "ElmBinary": elm_binary_builder,
        },
    )


def exists(env: Environment):
    return env.Detect("elm")
