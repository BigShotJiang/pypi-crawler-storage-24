def fucn1():
    return "Привет из модуля 1Э"
