def func2():
	return "Привет из модуля 2"
