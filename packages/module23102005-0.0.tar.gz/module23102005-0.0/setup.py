from setuptools import setup

setup(name='module23102005',
      version='0.0',
      description='Test packet',
      packages=['module23102005'],
      author_email='straikman1@gmail.com',
      zip_safe=False)
