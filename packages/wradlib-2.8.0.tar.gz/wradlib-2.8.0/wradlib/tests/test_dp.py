#!/usr/bin/env python
# Copyright (c) 2011-2025, wradlib developers.
# Distributed under the MIT License. See LICENSE.txt for more info.

from dataclasses import dataclass

import numpy as np
import pytest
from scipy import integrate

from wradlib import dp, util


@pytest.fixture(params=["lstsq", "cov", "matrix_inv", "lanczos_conv", "lanczos_dot"])
def derivation_method(request):
    return request.param


@pytest.fixture(params=[11, 13, 15])
def window(request):
    return request.param


@pytest.fixture(params=[True, False])
def copy(request):
    return request.param


@pytest.fixture(params=[3, 5])
def ndespeckle(request):
    return request.param


@pytest.fixture
def dp_data():
    @dataclass(init=False, repr=False, eq=False)
    class TestKDPFromPHIDP:
        np.random.seed(42)
        # Synthetic truth
        dr = 0.5
        r = np.arange(0, 100, dr)
        kdp_true0 = np.sin(0.3 * r)
        kdp_true0[kdp_true0 < 0] = 0.0
        phidp_true0 = np.cumsum(kdp_true0) * 2 * dr
        # Synthetic observation of PhiDP with a random noise and gaps
        phidp_raw0 = phidp_true0 + np.random.uniform(-2, 2, len(phidp_true0))
        gaps = np.random.uniform(0, len(r), 20).astype("int")
        phidp_raw0[gaps] = np.nan
        rho = np.random.uniform(0.8, 1.0, len(r))

        # for derivation tests
        window = 7
        az = 360
        rng = 1000
        pad = window // 2
        kdp_true = np.arange(az * rng, dtype=np.float64).reshape(az, rng)
        phidp_true = np.power(kdp_true, 2)
        dr = 0.1
        kdp_true /= dr
        phidp_true_nan = phidp_true.copy()
        phidp_true_nan[:, window:-1:10] = np.nan

    yield TestKDPFromPHIDP


def test_phidp_kdp_vulpiani(derivation_method, window, copy):
    # Todo: move data setup into fixture
    np.random.seed(42000)
    # Synthetic truth
    dr = 0.5
    r = np.arange(0, 500, dr)

    kdp_true0 = np.sin(0.3 * r)
    kdp_true0[kdp_true0 < 0] = 0.0
    phidp_true0 = 2 * integrate.cumulative_trapezoid(
        kdp_true0, axis=-1, initial=0, dx=dr
    )
    fillval = phidp_true0[200]
    phidp_true0 = np.concatenate(
        (phidp_true0[:200], np.ones(20) * fillval, phidp_true0[200:])
    )
    phidp_true0 = np.stack([phidp_true0, phidp_true0], axis=0)

    # first, no noise, no folding, no gaps, offset
    phidp_raw0 = phidp_true0.copy() + 30.0

    # second, noise, no folding, no gaps
    phidp_raw1 = phidp_raw0.copy()
    phidp_raw1 += np.random.uniform(-2, 2, phidp_raw1.shape[-1])

    # third, noise, folding, no gaps
    phidp_raw2 = phidp_raw1.copy()
    phidp_raw2[phidp_raw2 > 180] -= 360

    # fourth, noise, folding, large gap
    phidp_raw3 = phidp_raw2.copy()
    phidp_raw3[:, 200:220] = np.nan

    # fifth, noise, folding, large gap, small gaps
    phidp_raw4 = phidp_raw3.copy()
    gaps = np.random.uniform(0, phidp_raw4.shape[-1], 50).astype("int")
    phidp_raw4[:, gaps] = np.nan

    in0 = phidp_raw0.copy()
    out0 = dp.phidp_kdp_vulpiani(
        in0,
        dr=dr,
        copy=copy,
        winlen=window,
        method=derivation_method,
        pad_mode="reflect",
        pad_kwargs={"reflect_type": "odd"},
        niter=1,
    )
    np.testing.assert_array_equal(in0, phidp_raw0)
    np.testing.assert_allclose(out0[0], phidp_true0, atol=0.6, rtol=0.02)

    out1 = dp.phidp_kdp_vulpiani(
        phidp_raw1.copy(),
        dr=dr,
        copy=copy,
        winlen=window,
        method=derivation_method,
        pad_mode="reflect",
        pad_kwargs={"reflect_type": "even"},
        niter=1,
    )
    np.testing.assert_allclose(out1[0], phidp_true0, atol=0.8, rtol=0.02)

    out2 = dp.phidp_kdp_vulpiani(
        phidp_raw1.copy(),
        dr=dr,
        copy=copy,
        winlen=window,
        method=derivation_method,
        pad_mode="reflect",
        pad_kwargs={"reflect_type": "even"},
        niter=1,
    )
    np.testing.assert_allclose(out2[0], phidp_true0, atol=0.8, rtol=0.02)

    out3 = dp.phidp_kdp_vulpiani(
        phidp_raw1.copy(),
        dr=dr,
        copy=copy,
        winlen=window,
        method=derivation_method,
        pad_mode="reflect",
        pad_kwargs={"reflect_type": "even"},
        niter=1,
    )
    np.testing.assert_allclose(out3[0], phidp_true0, atol=0.8, rtol=0.02)

    in4 = phidp_raw4.copy()
    out4 = dp.phidp_kdp_vulpiani(
        in4,
        dr=dr,
        copy=copy,
        winlen=window,
        method=derivation_method,
        pad_mode="reflect",
        pad_kwargs={"reflect_type": "even"},
        niter=1,
    )
    np.testing.assert_allclose(out4[0], phidp_true0, atol=1.0, rtol=0.02)

    # check copy
    if copy:
        np.testing.assert_array_equal(in4, phidp_raw4)
    else:
        assert not np.array_equal(in4, phidp_raw4)


def test_kdp_from_phidp_nan(dp_data, derivation_method):
    window = 7

    # intercompare with lanczos method without NaN-handling
    out0 = dp.kdp_from_phidp(
        dp_data.phidp_true_nan.copy(),
        dr=dp_data.dr,
        method="lanczos_conv",
        skipna=False,
        winlen=window,
    )
    outx = dp.kdp_from_phidp(
        dp_data.phidp_true_nan.copy(),
        dr=dp_data.dr,
        method=derivation_method,
        skipna=False,
        winlen=window,
    )
    np.testing.assert_array_almost_equal(outx, out0, decimal=4)


def test_kdp_from_phidp(dp_data, derivation_method):
    window = 7

    # compare with true kdp
    out = dp.kdp_from_phidp(
        dp_data.phidp_true.copy(),
        dr=dp_data.dr,
        method=derivation_method,
        winlen=window,
    )
    outx = out[:, dp_data.pad : -dp_data.pad]
    res = dp_data.kdp_true[:, dp_data.pad : -dp_data.pad]
    np.testing.assert_array_almost_equal(outx, res, decimal=4)

    # intercompare with lanczos method with NaN handling
    out0 = dp.kdp_from_phidp(
        dp_data.phidp_true.copy(), dr=dp_data.dr, method="lanczos_conv", winlen=window
    )
    np.testing.assert_array_almost_equal(out, out0, decimal=4)


def test_linear_despeckle(dp_data, ndespeckle):
    util.despeckle(dp_data.phidp_raw0, n=ndespeckle, copy=True)


def test_unfold_phi(dp_data):
    dp.unfold_phi(dp_data.phidp_raw0, dp_data.rho)
    dp.unfold_phi(dp_data.phidp_raw0, dp_data.rho, copy=True)


def test_unfold_phi_vulpiani():
    phi_true = np.arange(600)
    phi_raw1 = phi_true.copy()
    phi_raw1[phi_raw1 > 540] -= 360
    phi_raw2 = phi_raw1.copy()
    phi_raw2[phi_raw2 > 180] -= 360
    kdp1 = dp.kdp_from_phidp(phi_raw1)
    kdp2 = dp.kdp_from_phidp(phi_raw2)

    out1 = dp.unfold_phi_vulpiani(phi_raw1.copy(), kdp1)
    out2 = dp.unfold_phi_vulpiani(phi_raw2.copy(), kdp2)
    kdp3 = dp.kdp_from_phidp(out2)
    out3 = dp.unfold_phi_vulpiani(out2.copy(), kdp3)

    np.testing.assert_array_equal(out1, phi_true)
    np.testing.assert_array_equal(out2, phi_raw1)
    np.testing.assert_array_equal(out3, phi_true)


def test__fill_sweep(dp_data):
    dp._fill_sweep(dp_data.phidp_raw0, kind="linear")


def test_texture_deprecation():
    with pytest.warns(DeprecationWarning):
        data = np.zeros((360, 1000))
        dp.texture(data)


def test_depolarization():
    zdr = np.linspace(-0.5, 0.5, 10)
    rho = np.linspace(0.0, 1.0, 10)

    dr_0 = [
        -12.719937,
        -12.746507,
        -12.766551,
        -12.779969,
        -12.786695,
        -12.786695,
        -12.779969,
        -12.766551,
        -12.746507,
        -12.719937,
    ]
    dr_1 = [
        0.0,
        -0.96266,
        -1.949568,
        -2.988849,
        -4.118078,
        -5.394812,
        -6.921361,
        -8.919312,
        -12.067837,
        -24.806473,
    ]

    np.testing.assert_array_almost_equal(dp.depolarization(zdr, 0.9), dr_0)
    np.testing.assert_array_almost_equal(dp.depolarization(1.0, rho), dr_1)


def test_depolarization_xarray(gamic_swp):
    gamic_swp.wrl.dp.depolarization(zdr="ZDR", rho="RHOHV")


def test_kdp_from_phidp_xarray(gamic_swp):
    gamic_swp.PHIDP.wrl.dp.kdp_from_phidp()


def test_phidp_kdp_vulpiani_xarray(gamic_swp):
    gamic_swp.PHIDP.wrl.dp.phidp_kdp_vulpiani()


def test_unfold_phi_xarray(gamic_swp):
    gamic_swp.wrl.dp.unfold_phi(phidp="PHIDP", rho="RHOHV")


def test_unfold_phi_vulpiani_xarray(gamic_swp):
    gamic_swp.wrl.dp.unfold_phi_vulpiani(phidp="PHIDP", kdp="KDP")
