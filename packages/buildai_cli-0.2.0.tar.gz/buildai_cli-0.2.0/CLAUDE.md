# Build AI CLI

Applies to `apps/buildai-cli/`.

Read first:

- [../../CLAUDE.md](../../CLAUDE.md)
- [../../core/CLAUDE.md](../../core/CLAUDE.md)

## Mental Model

The CLI has two planes:

- data plane: SDK-backed commands that work with a standalone `buildai-cli` install
- ops plane: DAL-backed commands that require repo-local `ops` extras and DB access

## Hard Rules

1. From the repo, run `uv run buildai` from repo root.
2. Mutations need both the correct profile and `--write`.
3. DB access goes through `core/data/` with `CLIContext`.
4. The `query` command stays read-safe by default.
5. Do not pull `infra` imports into CLI module scope where they affect startup.

## Verify Instead Of Infer

- Verify whether a command belongs in the data plane or the ops plane.
- Verify whether the command should work in standalone mode or only in the workspace install.
- Verify registration in `cli/main.py`.
- Verify whether auth behavior belongs in `auth_lite` or `auth_ops`.

## Canonical Commands

```bash
uv run buildai --profile internal_viewer schema tables
uv run buildai --profile internal_viewer jobs list
uv run buildai --profile internal_viewer stats overview
uv run buildai auth status
```

Install paths:

```bash
# Workspace install
uv pip install -e "apps/buildai-cli[ops]" -e core -e services -e apps/buildai-sdk

# Standalone Homebrew install
brew tap build-ai-ego/homebrew-tap
brew install buildai-cli

# Standalone Python tool install
uv tool install buildai-cli
```

## Common Traps

- `uv run buildai` failing after a pull usually means the workspace install needs to be refreshed.
- Data-plane commands need API auth, not DB creds.
- Ops-plane commands need DB access plus the `ops` extras.
- Auth ops commands are not wired the same way as most other ops groups.

## Done Means

- the command is in the correct plane
- registration is correct
- safety flags are explicit for mutations
- command output still behaves correctly for TTY and non-TTY use

## Related Docs

- [../../README.md](../../README.md)
- [../../core/CLAUDE.md](../../core/CLAUDE.md)
- [../../docs/gotchas.md](../../docs/gotchas.md)
