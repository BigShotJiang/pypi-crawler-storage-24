"""CLI commands for assets."""

from __future__ import annotations

import sys

import typer

from cli.output import OutputFormat, auto_format, render
from cli.sdk_client import get_sdk_client

app = typer.Typer(
    name="assets", help="Inspect asset metadata and signed URLs.", no_args_is_help=True
)


@app.command("list")
def assets_list(
    clip_id: str | None = typer.Option(None, "--clip-id"),
    frame_id: str | None = typer.Option(None, "--frame-id"),
    asset_type: str | None = typer.Option(None, "--asset-type"),
    output: OutputFormat | None = typer.Option(None, "-o", "--output"),
) -> None:
    client = get_sdk_client()
    try:
        page = client.assets.list(clip_id=clip_id, frame_id=frame_id, asset_type=asset_type)
    finally:
        client.close()
    render(
        page.data,
        format=output or auto_format(),
        columns=["id", "asset_type", "clip_id", "frame_id", "size_bytes"],
    )


@app.command("get")
def assets_get(
    asset_id: str = typer.Argument(..., help="Asset UUID."),
    output: OutputFormat | None = typer.Option(None, "-o", "--output"),
) -> None:
    client = get_sdk_client()
    try:
        asset = client.assets.get(asset_id)
    finally:
        client.close()
    render(asset, format=output or auto_format())


@app.command("sign")
def assets_sign(
    asset_id: str = typer.Argument(..., help="Asset UUID."),
    ttl: int = typer.Option(3600, "--ttl", help="Signed URL TTL in seconds."),
) -> None:
    client = get_sdk_client()
    try:
        signed = client.assets.sign(asset_id, ttl_seconds=ttl)
    finally:
        client.close()

    if sys.stdout.isatty():
        render(
            {
                "asset_id": asset_id,
                "signed_url": signed.signed_url,
                "gs_uri": signed.gs_uri,
                "expires_at": signed.expires_at,
            },
            format=OutputFormat.TABLE,
            columns=["asset_id", "signed_url", "gs_uri", "expires_at"],
        )
        return

    print(signed.signed_url)
