"""API-backed query command."""

from __future__ import annotations

from typing import Any

import typer

from cli.output import OutputFormat, auto_format, render
from cli.sdk_client import get_internal_sdk_client


def _append_offset(sql: str, offset: int) -> str:
    return f"{sql.rstrip().rstrip(';')} OFFSET {offset}"


def _fetch_all_rows(client: Any, sql: str, limit: int) -> tuple[list[dict[str, Any]], list[str]]:
    offset = 0
    rows: list[dict[str, Any]] = []
    columns: list[str] = []

    while True:
        result = client.query.run(_append_offset(sql, offset) if offset else sql, limit=limit)
        columns = result.columns or columns
        rows.extend(result.rows)
        if not result.truncated or not result.rows:
            return rows, columns
        offset += limit


def query(
    sql: str = typer.Argument(..., help="Read-only SQL query to execute through the API."),
    limit: int = typer.Option(500, "--limit", help="Maximum rows to fetch per request."),
    output: OutputFormat | None = typer.Option(
        None,
        "-o",
        "--output",
        help="Override output format: table, json, jsonl, csv.",
    ),
) -> None:
    """Execute a read-only SQL query via POST /v1/query."""
    client = get_internal_sdk_client()
    try:
        fmt = output or auto_format()
        if fmt in {OutputFormat.JSONL, OutputFormat.CSV}:
            rows, columns = _fetch_all_rows(client, sql, limit)
            render(rows, format=fmt, columns=columns)
            return

        result = client.query.run(sql, limit=limit)
        if fmt == OutputFormat.JSON:
            render(result.model_dump(mode="json"), format=fmt)
            return
        render(result.rows, format=fmt, columns=result.columns)
    finally:
        client.close()
