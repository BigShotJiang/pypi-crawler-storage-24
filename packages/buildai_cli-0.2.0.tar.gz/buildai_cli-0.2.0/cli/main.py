#!/usr/bin/env python3
"""BuildAI CLI entry point."""

from __future__ import annotations

from importlib.metadata import version as pkg_version

import typer
from dotenv import load_dotenv

from cli._has_core import has_core
from cli.commands.assets_cli import app as assets_app
from cli.commands.auth_lite import login, logout, whoami
from cli.commands.clips import app as clips_app
from cli.commands.jobs import app as jobs_app
from cli.commands.predictions import app as predictions_app
from cli.commands.query_api import query
from cli.console import set_verbose

load_dotenv()


def _version_callback(value: bool) -> None:
    if value:
        try:
            v = pkg_version("buildai-cli")
        except Exception:
            v = "dev"
        print(f"buildai-cli {v}")
        raise typer.Exit()


def _empty_group(name: str, help_text: str) -> typer.Typer:
    group = typer.Typer(name=name, help=help_text, no_args_is_help=True)

    @group.callback()
    def _callback() -> None:
        return None

    return group


app = typer.Typer(
    name="buildai",
    help="Build AI CLI.",
    no_args_is_help=True,
)


@app.callback()
def main_callback(
    verbose: bool = typer.Option(False, "--verbose", "-v"),
    version: bool | None = typer.Option(
        None,
        "--version",
        callback=_version_callback,
        is_eager=True,
        help="Show version and exit.",
    ),
) -> None:
    del version
    set_verbose(verbose)


app.command("login")(login)
app.command("whoami")(whoami)
app.command("logout")(logout)
app.command("query")(query)

app.add_typer(clips_app, name="clips")
app.add_typer(_empty_group("factories", "Factory commands."), name="factories")
app.add_typer(_empty_group("workers", "Worker commands."), name="workers")
app.add_typer(_empty_group("sessions", "Session commands."), name="sessions")
app.add_typer(_empty_group("streams", "Stream commands."), name="streams")
app.add_typer(_empty_group("frames", "Frame commands."), name="frames")
app.add_typer(assets_app, name="assets")
app.add_typer(predictions_app, name="predictions")
app.add_typer(jobs_app, name="jobs")
app.add_typer(_empty_group("search", "Search commands."), name="search")
app.add_typer(_empty_group("schema", "Schema commands."), name="schema")
app.add_typer(_empty_group("embeddings", "Embedding commands."), name="embeddings")

admin_app = typer.Typer(
    name="admin", help="Administrative and ops-plane commands.", no_args_is_help=True
)

if has_core():
    from cli.commands.database import app as database_app
    from cli.commands.embed import app as embed_app
    from cli.commands.external import app as external_app
    from cli.commands.keys import app as keys_app
    from cli.commands.medoid import app as medoid_app
    from cli.commands.operations import app as operations_app
    from cli.commands.partners import app as partners_app
    from cli.commands.permissions import app as permissions_app
    from cli.commands.projection import app as projection_app
    from cli.commands.query import query as admin_query
    from cli.commands.schema import app as schema_app
    from cli.commands.stats import app as stats_app

    admin_app.command("query")(admin_query)
    admin_app.add_typer(operations_app, name="operations")
    admin_app.add_typer(partners_app, name="partners")
    admin_app.add_typer(keys_app, name="keys")
    admin_app.add_typer(stats_app, name="stats")
    admin_app.add_typer(schema_app, name="schema")
    admin_app.add_typer(embed_app, name="embeddings")
    admin_app.add_typer(database_app, name="database")
    admin_app.add_typer(external_app, name="external")
    admin_app.add_typer(permissions_app, name="permissions")
    admin_app.add_typer(projection_app, name="projection")
    admin_app.add_typer(medoid_app, name="medoid")

app.add_typer(admin_app, name="admin")


def main() -> None:
    app()
