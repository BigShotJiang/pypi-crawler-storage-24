# divami-agents

Bootstrap a `.agents` folder into the current directory.

## Usage

```bash
uvx --from divami-agents divami-agents setup
```

## Development

```bash
uv build
```
