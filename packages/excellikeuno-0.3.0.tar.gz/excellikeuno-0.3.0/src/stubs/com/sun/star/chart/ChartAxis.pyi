from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.beans import XPropertySet
from com.sun.star.chart import XAxis
from com.sun.star.drawing import LineProperties
from com.sun.star.style import CharacterProperties
from com.sun.star.xml import UserDefinedAttributesSupplier

@runtime_checkable
class ChartAxis(LineProperties, CharacterProperties, UserDefinedAttributesSupplier, XAxis, XPropertySet, Protocol):
    Max: float
    Min: float
    StepMain: float
    StepHelpCount: int
    StepHelp: float
    AutoMax: bool
    AutoMin: bool
    AutoStepMain: bool
    AutoStepHelp: bool
    Logarithmic: bool
    AxisType: int
    TimeIncrement: TimeIncrement
    ReverseDirection: bool
    CrossoverPosition: ChartAxisPosition
    CrossoverValue: float
    Origin: float
    AutoOrigin: bool
    Marks: int
    HelpMarks: int
    MarkPosition: ChartAxisMarkPosition
    DisplayLabels: bool
    NumberFormat: int
    LinkNumberFormatToSource: bool
    LabelPosition: ChartAxisLabelPosition
    TextRotation: int
    ArrangeOrder: ChartAxisArrangeOrderType
    TextBreak: bool
    TextCanOverlap: bool
    Overlap: int
    GapWidth: int
