from __future__ import annotations
from typing import Any
from enum import IntEnum
from enum import auto

class DataPointCustomLabelFieldType(IntEnum):
    TEXT = auto()
    VALUE = auto()
    SERIESNAME = auto()
    CATEGORYNAME = auto()
    CELLREF = auto()
    NEWLINE = auto()
    PERCENTAGE = auto()
    CELLRANGE = auto()
