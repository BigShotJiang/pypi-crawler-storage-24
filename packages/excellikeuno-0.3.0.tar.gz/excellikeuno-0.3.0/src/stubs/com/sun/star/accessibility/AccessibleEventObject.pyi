from __future__ import annotations
from typing import Any, TypedDict
from .com.sun.star.lang import EventObject

class AccessibleEventObject(TypedDict, total=False):
    EventId: int
    NewValue: Any
    OldValue: Any
    IndexHint: int
