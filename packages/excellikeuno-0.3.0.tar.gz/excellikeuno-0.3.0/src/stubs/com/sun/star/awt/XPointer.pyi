from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.uno import XInterface

@runtime_checkable
class XPointer(XInterface, Protocol):
    def setType(self, nType: int) -> None: ...
    def getType(self) -> int: ...
