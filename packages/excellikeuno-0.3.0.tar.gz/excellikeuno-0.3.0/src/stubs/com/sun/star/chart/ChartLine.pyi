from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.beans import XPropertySet
from com.sun.star.drawing import LineProperties

@runtime_checkable
class ChartLine(LineProperties, XPropertySet, Protocol):
    ...
