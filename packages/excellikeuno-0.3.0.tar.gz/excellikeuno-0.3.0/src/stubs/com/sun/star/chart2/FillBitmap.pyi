from __future__ import annotations
from typing import Any, TypedDict

class FillBitmap(TypedDict, total=False):
    aURL: str
    aOffset: Point
    aPositionOffset: Point
    aRectanglePoint: RectanglePoint
    bLogicalSize: bool
    aSize: Size
    aBitmapMode: BitmapMode
