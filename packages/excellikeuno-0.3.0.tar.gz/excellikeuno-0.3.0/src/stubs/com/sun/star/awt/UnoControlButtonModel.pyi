from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.awt import UnoControlModel

@runtime_checkable
class UnoControlButtonModel(UnoControlModel, Protocol):
    Align: int
    BackgroundColor: Color
    DefaultButton: bool
    Enabled: bool
    FocusOnClick: bool
    FontDescriptor: FontDescriptor
    FontEmphasisMark: int
    FontRelief: int
    HelpText: str
    HelpURL: str
    ImageAlign: int
    ImagePosition: int
    ImageURL: str
    Graphic: XGraphic
    Label: str
    MultiLine: bool
    Printable: bool
    PushButtonType: int
    Repeat: bool
    RepeatDelay: int
    State: int
    Tabstop: bool
    TextColor: Color
    TextLineColor: Color
    Toggle: bool
    VerticalAlign: VerticalAlignment
