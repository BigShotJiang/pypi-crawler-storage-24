from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.awt import UnoControlEdit
from com.sun.star.awt import XDateField
from com.sun.star.awt import XSpinField

@runtime_checkable
class UnoControlDateField(UnoControlEdit, XSpinField, XDateField, Protocol):
    ...
