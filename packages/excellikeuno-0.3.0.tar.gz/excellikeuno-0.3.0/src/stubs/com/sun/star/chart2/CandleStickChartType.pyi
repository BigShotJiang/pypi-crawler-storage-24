from __future__ import annotations
from typing import Any, Protocol, runtime_checkable

@runtime_checkable
class CandleStickChartType(ChartType, Protocol):
    Japanese: bool
    WhiteDay: XPropertySet
    BlackDay: XPropertySet
    ShowFirst: bool
    ShowHighLow: bool
