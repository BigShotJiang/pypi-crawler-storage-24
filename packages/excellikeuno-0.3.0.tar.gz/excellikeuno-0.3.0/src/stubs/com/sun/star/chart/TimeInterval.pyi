from __future__ import annotations
from typing import Any, TypedDict

class TimeInterval(TypedDict, total=False):
    Number: int
    TimeUnit: int
