from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.awt import UnoControl
from com.sun.star.awt import XFixedHyperlink
from com.sun.star.awt import XLayoutConstrains

@runtime_checkable
class UnoControlFixedHyperlink(UnoControl, XFixedHyperlink, XLayoutConstrains, Protocol):
    ...
