from __future__ import annotations
from typing import Any
from enum import IntEnum
from enum import auto

class ChartDataRowSource(IntEnum):
    ROWS = auto()
    COLUMNS = auto()
