from __future__ import annotations
from typing import Any, TypedDict

class Gradient2(TypedDict, total=False):
    ColorStops: ColorStopSequence
