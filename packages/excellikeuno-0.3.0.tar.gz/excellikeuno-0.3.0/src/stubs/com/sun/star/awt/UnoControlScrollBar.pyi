from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.awt import UnoControl
from com.sun.star.awt import XScrollBar

@runtime_checkable
class UnoControlScrollBar(UnoControl, XScrollBar, Protocol):
    ...
