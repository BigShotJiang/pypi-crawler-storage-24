from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.awt import XDialog

@runtime_checkable
class XDialog2(XDialog, Protocol):
    def endDialog(self, Result: int) -> None: ...
    def setHelpId(self, Id: str) -> None: ...
