from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.chart import XAxisXSupplier

@runtime_checkable
class XTwoAxisXSupplier(XAxisXSupplier, Protocol):
    def getSecondaryXAxis(self) -> XPropertySet: ...
