from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.awt import UnoControlEdit
from com.sun.star.awt import XComboBox

@runtime_checkable
class UnoControlComboBox(UnoControlEdit, XComboBox, Protocol):
    ...
