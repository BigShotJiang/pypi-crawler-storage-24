from __future__ import annotations
from typing import Any, TypedDict
from com.sun.star.lang import EventObject

class DockingEvent(TypedDict, total=False):
    TrackingRectangle: Rectangle
    MousePos: Point
    bLiveMode: bool
    bInteractive: bool
