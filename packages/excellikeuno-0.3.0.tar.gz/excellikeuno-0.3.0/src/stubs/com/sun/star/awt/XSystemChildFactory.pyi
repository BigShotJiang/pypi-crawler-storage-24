from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.uno import XInterface

@runtime_checkable
class XSystemChildFactory(XInterface, Protocol):
    def createSystemChild(self, Parent: Any, ProcessId: sequence< byte >, SystemType: int) -> XWindowPeer: ...
