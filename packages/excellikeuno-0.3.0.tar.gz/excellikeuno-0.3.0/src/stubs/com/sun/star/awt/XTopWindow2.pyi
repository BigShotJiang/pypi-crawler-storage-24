from __future__ import annotations
from typing import Any, Protocol, runtime_checkable

@runtime_checkable
class XTopWindow2(XTopWindow, Protocol):
    def raises(self, param0: IndexOutOfBoundsException) -> set: ...
