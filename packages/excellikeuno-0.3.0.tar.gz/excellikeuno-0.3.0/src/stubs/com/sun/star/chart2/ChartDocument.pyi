from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from data import XDataReceiver

@runtime_checkable
class ChartDocument(XChartDocument, XDataReceiver, XTitled, Protocol):
    ...
