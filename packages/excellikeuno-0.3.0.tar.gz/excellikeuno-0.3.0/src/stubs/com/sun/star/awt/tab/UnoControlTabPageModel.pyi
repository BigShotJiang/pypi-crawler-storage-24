from __future__ import annotations
from typing import Any, Protocol, runtime_checkable

@runtime_checkable
class UnoControlTabPageModel(XTabPageModel, Protocol):
    Title: str
    HelpText: str
    HelpURL: str
    HScroll: bool
    VScroll: bool
    ScrollLeft: int
    ScrollTop: int
    ScrollWidth: int
    ScrollHeight: int
