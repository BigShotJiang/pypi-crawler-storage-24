from __future__ import annotations
from typing import Any
from enum import IntEnum
from enum import auto

class ChartRegressionCurveType(IntEnum):
    NONE = auto()
    LINEAR = auto()
    LOGARITHM = auto()
    EXPONENTIAL = auto()
    POLYNOMIAL = auto()
    POWER = auto()
