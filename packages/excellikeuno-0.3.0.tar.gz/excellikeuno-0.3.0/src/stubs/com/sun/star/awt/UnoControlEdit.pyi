from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.awt import UnoControl
from com.sun.star.awt import XLayoutConstrains
from com.sun.star.awt import XTextComponent
from com.sun.star.awt import XTextLayoutConstrains

@runtime_checkable
class UnoControlEdit(UnoControl, XTextComponent, XLayoutConstrains, XTextLayoutConstrains, Protocol):
    ...
