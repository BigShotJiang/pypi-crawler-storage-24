from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from .com.sun.star.accessibility import XAccessibleText

@runtime_checkable
class XAccessibleHypertext(XAccessibleText, Protocol):
    def getHyperLinkCount(self) -> int: ...
