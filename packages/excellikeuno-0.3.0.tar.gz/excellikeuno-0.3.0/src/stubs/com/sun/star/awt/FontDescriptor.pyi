from __future__ import annotations
from typing import Any, TypedDict

class FontDescriptor(TypedDict, total=False):
    Name: str
    Height: int
    Width: int
    StyleName: str
    Family: int
    CharSet: int
    Pitch: int
    CharacterWidth: float
    Weight: float
    Slant: FontSlant
    Underline: int
    Strikeout: int
    Orientation: float
    Kerning: bool
    WordLineMode: bool
    Type: int
