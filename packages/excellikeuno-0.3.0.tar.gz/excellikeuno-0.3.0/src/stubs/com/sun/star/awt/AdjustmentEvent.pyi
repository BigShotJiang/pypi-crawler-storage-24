from __future__ import annotations
from typing import Any, TypedDict
from com.sun.star.lang import EventObject

class AdjustmentEvent(TypedDict, total=False):
    Value: int
    Type: AdjustmentType
