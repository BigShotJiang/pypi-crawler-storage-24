from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from .com.sun.star.lang import XComponent

@runtime_checkable
class XMSAAService(XComponent, Protocol):
    def getAccObjectPtr(self, hWnd: int, lParam: int, wParam: int) -> int: ...
    def handleWindowOpened(self, i: int) -> None: ...
