from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.uno import XInterface

@runtime_checkable
class XTextLayoutConstrains(XInterface, Protocol):
    def getMinimumSize(self, nCols: int, nLines: int) -> Size: ...
    def getColumnsAndLines(self, nCols: int, nLines: int) -> None: ...
