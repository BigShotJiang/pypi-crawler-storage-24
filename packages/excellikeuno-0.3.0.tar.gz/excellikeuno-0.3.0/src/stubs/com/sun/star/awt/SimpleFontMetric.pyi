from __future__ import annotations
from typing import Any, TypedDict

class SimpleFontMetric(TypedDict, total=False):
    Ascent: int
    Descent: int
    Leading: int
    Slant: int
    FirstChar: str
    LastChar: str
