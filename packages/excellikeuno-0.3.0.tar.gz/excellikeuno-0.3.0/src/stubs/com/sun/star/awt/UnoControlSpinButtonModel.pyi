from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.awt import UnoControlModel

@runtime_checkable
class UnoControlSpinButtonModel(UnoControlModel, Protocol):
    Border: int
    BorderColor: int
    Enabled: bool
    HelpText: str
    HelpURL: str
    SpinIncrement: int
    Orientation: int
    Printable: bool
    SpinValue: int
    SpinValueMin: int
    SpinValueMax: int
    BackgroundColor: Color
    SymbolColor: Color
    Repeat: bool
    RepeatDelay: int
    MouseWheelBehavior: int
