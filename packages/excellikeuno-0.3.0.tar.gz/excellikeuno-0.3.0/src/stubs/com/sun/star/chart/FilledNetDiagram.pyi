from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.chart import ChartAxisXSupplier
from com.sun.star.chart import ChartAxisYSupplier
from com.sun.star.chart import Diagram
from com.sun.star.chart import StackableDiagram

@runtime_checkable
class FilledNetDiagram(Diagram, ChartAxisXSupplier, ChartAxisYSupplier, StackableDiagram, Protocol):
    ...
