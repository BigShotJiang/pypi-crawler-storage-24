from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.awt import UnoControl
from com.sun.star.awt import XCheckBox
from com.sun.star.awt import XLayoutConstrains

@runtime_checkable
class UnoControlCheckBox(UnoControl, XCheckBox, XLayoutConstrains, Protocol):
    ...
