from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.awt import UnoControl
from com.sun.star.awt import XLayoutConstrains
from com.sun.star.awt import XRadioButton

@runtime_checkable
class UnoControlRadioButton(UnoControl, XRadioButton, XLayoutConstrains, Protocol):
    ...
