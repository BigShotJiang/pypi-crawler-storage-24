from __future__ import annotations
from typing import Any, TypedDict

class DataPointLabel(TypedDict, total=False):
    ShowNumber: bool
    ShowNumberInPercent: bool
    ShowCategoryName: bool
    ShowLegendSymbol: bool
    ShowCustomLabel: bool
    ShowSeriesName: bool
