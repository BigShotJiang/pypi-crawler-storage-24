from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from .com.sun.star.awt import XDialogProvider

@runtime_checkable
class XDialogProvider2(XDialogProvider, Protocol):
    ...
