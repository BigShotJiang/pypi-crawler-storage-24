from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.lang import XEventListener

@runtime_checkable
class XMouseMotionListener(XEventListener, Protocol):
    def mouseDragged(self, e: MouseEvent) -> None: ...
    def mouseMoved(self, e: MouseEvent) -> None: ...
