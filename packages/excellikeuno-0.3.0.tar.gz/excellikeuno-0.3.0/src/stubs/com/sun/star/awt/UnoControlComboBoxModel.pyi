from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.awt import UnoControlModel

@runtime_checkable
class UnoControlComboBoxModel(UnoControlModel, XItemList, Protocol):
    Align: int
    Autocomplete: bool
    BackgroundColor: Color
    Border: int
    BorderColor: int
    Dropdown: bool
    Enabled: bool
    FontDescriptor: FontDescriptor
    FontEmphasisMark: int
    FontRelief: int
    HelpText: str
    HelpURL: str
    HideInactiveSelection: bool
    LineCount: int
    MaxTextLen: int
    Printable: bool
    ReadOnly: bool
    StringItemList: list[str]
    Tabstop: bool
    Text: str
    TextColor: Color
    TextLineColor: Color
    WritingMode: int
    MouseWheelBehavior: int
    TypedItemList: list[Any]
    HighlightColor: Color
    HighlightTextColor: Color
