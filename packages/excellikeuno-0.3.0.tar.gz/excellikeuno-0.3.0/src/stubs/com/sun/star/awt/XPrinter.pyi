from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.awt import XPrinterPropertySet

@runtime_checkable
class XPrinter(XPrinterPropertySet, Protocol):
    def terminate(self) -> None: ...
