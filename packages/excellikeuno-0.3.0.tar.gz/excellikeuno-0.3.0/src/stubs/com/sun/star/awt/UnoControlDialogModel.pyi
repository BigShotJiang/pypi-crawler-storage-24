from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.awt import UnoControlModel
from com.sun.star.container import XContainer
from com.sun.star.container import XNameContainer
from com.sun.star.lang import XMultiServiceFactory

@runtime_checkable
class UnoControlDialogModel(UnoControlModel, XMultiServiceFactory, XContainer, XNameContainer, Protocol):
    BackgroundColor: Color
    Closeable: bool
    Enabled: bool
    FontDescriptor: FontDescriptor
    FontEmphasisMark: int
    FontRelief: int
    HelpText: str
    HelpURL: str
    Moveable: bool
    Sizeable: bool
    TextColor: Color
    TextLineColor: Color
    Title: str
    DesktopAsParent: bool
    ImageURL: str
    Graphic: XGraphic
    HScroll: bool
    VScroll: bool
    ScrollLeft: int
    ScrollTop: int
    ScrollWidth: int
    ScrollHeight: int
