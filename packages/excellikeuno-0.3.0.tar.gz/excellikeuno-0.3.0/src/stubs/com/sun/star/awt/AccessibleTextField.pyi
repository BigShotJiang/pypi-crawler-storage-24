from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.accessibility import AccessibleContext
from com.sun.star.accessibility import XAccessibleComponent
from com.sun.star.accessibility import XAccessibleExtendedComponent
from com.sun.star.accessibility import XAccessibleText

@runtime_checkable
class AccessibleTextField(AccessibleContext, XAccessibleText, XAccessibleComponent, XAccessibleExtendedComponent, Protocol):
    ...
