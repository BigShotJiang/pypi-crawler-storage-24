from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.chart import ChartAxisXSupplier
from com.sun.star.chart import ChartStatistics
from com.sun.star.chart import ChartTwoAxisYSupplier
from com.sun.star.chart import Diagram
from com.sun.star.chart import XStatisticDisplay

@runtime_checkable
class StockDiagram(XStatisticDisplay, ChartStatistics, Diagram, ChartAxisXSupplier, ChartTwoAxisYSupplier, Protocol):
    Volume: bool
    UpDown: bool
