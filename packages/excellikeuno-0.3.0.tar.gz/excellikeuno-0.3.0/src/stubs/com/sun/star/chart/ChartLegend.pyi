from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.drawing import Shape
from com.sun.star.style import CharacterProperties
from com.sun.star.xml import UserDefinedAttributesSupplier

@runtime_checkable
class ChartLegend(Shape, CharacterProperties, UserDefinedAttributesSupplier, Protocol):
    AutomaticPosition: bool
    Alignment: ChartLegendPosition
