from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.awt import UnoControlEdit

@runtime_checkable
class UnoControlFileControl(UnoControlEdit, Protocol):
    ...
