from __future__ import annotations
from typing import Any, TypedDict

class Rectangle(TypedDict, total=False):
    X: int
    Y: int
    Width: int
    Height: int
