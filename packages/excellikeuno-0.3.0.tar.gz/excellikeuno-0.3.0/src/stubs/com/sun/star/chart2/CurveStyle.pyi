from __future__ import annotations
from typing import Any
from enum import IntEnum
from enum import auto

class CurveStyle(IntEnum):
    LINES = auto()
    CUBIC_SPLINES = auto()
    B_SPLINES = auto()
    NURBS = auto()
    STEP_START = auto()
    STEP_END = auto()
    STEP_CENTER_X = auto()
    STEP_CENTER_Y = auto()
