from __future__ import annotations
from typing import Any, TypedDict
from com.sun.star.lang import EventObject

class GridDataEvent(TypedDict, total=False):
    FirstColumn: int
    LastColumn: int
    FirstRow: int
    LastRow: int
