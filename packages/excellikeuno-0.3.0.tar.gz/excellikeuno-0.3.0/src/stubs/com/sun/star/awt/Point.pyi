from __future__ import annotations
from typing import Any, TypedDict

class Point(TypedDict, total=False):
    X: int
    Y: int
