from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.awt import UnoControlModel

@runtime_checkable
class UnoControlPatternFieldModel(UnoControlModel, Protocol):
    BackgroundColor: Color
    Border: int
    BorderColor: int
    EditMask: str
    Enabled: bool
    FontDescriptor: FontDescriptor
    FontEmphasisMark: int
    FontRelief: int
    HelpText: str
    HelpURL: str
    HideInactiveSelection: bool
    LiteralMask: str
    MaxTextLen: int
    Printable: bool
    ReadOnly: bool
    StrictFormat: bool
    Tabstop: bool
    Text: str
    TextColor: Color
    TextLineColor: Color
    WritingMode: int
    MouseWheelBehavior: int
    VerticalAlign: VerticalAlignment
    HighlightColor: Color
    HighlightTextColor: Color
