from __future__ import annotations
from typing import Any, TypedDict

class ValuePair(TypedDict, total=False):
    First: Any
    Second: Any
