from __future__ import annotations
from typing import Any, TypedDict

class ChartDataValue(TypedDict, total=False):
    Value: float
    HighError: float
    LowError: float
