from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from .com.sun.star.uno import XInterface

@runtime_checkable
class XDialogEventHandler(XInterface, Protocol):
    def getSupportedMethodNames(self) -> list[str]: ...
