from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from .com.sun.star.awt import XPrinterServer

@runtime_checkable
class XPrinterServer2(XPrinterServer, Protocol):
    def getDefaultPrinterName(self) -> str: ...
