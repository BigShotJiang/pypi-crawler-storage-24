from __future__ import annotations
from typing import Any
from enum import IntEnum
from enum import auto

class FontSlant(IntEnum):
    NONE = auto()
    OBLIQUE = auto()
    ITALIC = auto()
    DONTKNOW = auto()
    REVERSE_OBLIQUE = auto()
    REVERSE_ITALIC = auto()
