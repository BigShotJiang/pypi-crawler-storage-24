from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.chart import ChartAxisYSupplier
from com.sun.star.chart import XTwoAxisYSupplier

@runtime_checkable
class ChartTwoAxisYSupplier(XTwoAxisYSupplier, ChartAxisYSupplier, Protocol):
    HasSecondaryYAxis: bool
    HasSecondaryYAxisDescription: bool
    HasSecondaryYAxisTitle: bool
