from __future__ import annotations
from typing import Any, TypedDict

class TextSegment(TypedDict, total=False):
    SegmentText: str
    SegmentStart: int
    SegmentEnd: int
