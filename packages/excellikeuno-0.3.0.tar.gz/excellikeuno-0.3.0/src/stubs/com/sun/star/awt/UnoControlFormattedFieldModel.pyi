from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.awt import UnoControlModel

@runtime_checkable
class UnoControlFormattedFieldModel(UnoControlModel, Protocol):
    Align: int
    BackgroundColor: Color
    Border: int
    BorderColor: int
    EffectiveDefault: Any
    EffectiveMax: float
    EffectiveMin: float
    EffectiveValue: float
    Enabled: bool
    FontDescriptor: FontDescriptor
    FontEmphasisMark: int
    FontRelief: int
    FormatKey: int
    FormatsSupplier: XNumberFormatsSupplier
    HelpText: str
    HelpURL: str
    HideInactiveSelection: bool
    MaxTextLen: int
    Printable: bool
    ReadOnly: bool
    Repeat: bool
    RepeatDelay: int
    Spin: bool
    StrictFormat: bool
    Tabstop: bool
    Text: str
    TextColor: Color
    TextLineColor: Color
    TreatAsNumber: bool
    WritingMode: int
    MouseWheelBehavior: int
    VerticalAlign: VerticalAlignment
    HighlightColor: Color
    HighlightTextColor: Color
