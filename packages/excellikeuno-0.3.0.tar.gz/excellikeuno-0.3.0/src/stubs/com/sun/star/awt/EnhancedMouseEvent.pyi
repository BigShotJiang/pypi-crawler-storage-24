from __future__ import annotations
from typing import Any, TypedDict
from com.sun.star.awt import MouseEvent

class EnhancedMouseEvent(TypedDict, total=False):
    Target: XInterface
