from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.lang import XEventListener

@runtime_checkable
class XFocusListener(XEventListener, Protocol):
    def focusGained(self, e: FocusEvent) -> None: ...
    def focusLost(self, e: FocusEvent) -> None: ...
