from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.beans import XPropertySet

@runtime_checkable
class ChartStatistics(XPropertySet, Protocol):
    ConstantErrorLow: float
    ConstantErrorHigh: float
    MeanValue: bool
    ErrorCategory: ChartErrorCategory
    ErrorBarStyle: int
    PercentageError: float
    ErrorMargin: float
    ErrorIndicator: ChartErrorIndicatorType
    RegressionCurves: ChartRegressionCurveType
    ErrorBarRangePositive: str
    ErrorBarRangeNegative: str
