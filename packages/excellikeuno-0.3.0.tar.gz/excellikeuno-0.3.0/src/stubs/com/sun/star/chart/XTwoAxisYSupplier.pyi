from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.chart import XAxisYSupplier

@runtime_checkable
class XTwoAxisYSupplier(XAxisYSupplier, Protocol):
    def getSecondaryYAxis(self) -> XPropertySet: ...
