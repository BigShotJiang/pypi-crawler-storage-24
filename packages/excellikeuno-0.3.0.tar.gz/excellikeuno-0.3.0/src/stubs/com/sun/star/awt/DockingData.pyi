from __future__ import annotations
from typing import Any, TypedDict

class DockingData(TypedDict, total=False):
    TrackingRectangle: Rectangle
    bFloating: bool
