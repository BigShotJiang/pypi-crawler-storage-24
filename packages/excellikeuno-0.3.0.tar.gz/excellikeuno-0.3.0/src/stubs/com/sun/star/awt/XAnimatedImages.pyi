from __future__ import annotations
from typing import Any, Protocol, runtime_checkable

@runtime_checkable
class XAnimatedImages(Protocol):
    def raises(self, param0: IllegalArgumentException) -> set: ...
