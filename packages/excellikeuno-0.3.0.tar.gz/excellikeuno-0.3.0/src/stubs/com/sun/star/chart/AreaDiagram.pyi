from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.chart import ChartAxisXSupplier
from com.sun.star.chart import ChartAxisZSupplier
from com.sun.star.chart import ChartStatistics
from com.sun.star.chart import ChartTwoAxisYSupplier
from com.sun.star.chart import Diagram
from com.sun.star.chart import Dim3DDiagram
from com.sun.star.chart import StackableDiagram

@runtime_checkable
class AreaDiagram(Diagram, ChartStatistics, ChartAxisXSupplier, ChartTwoAxisYSupplier, ChartAxisZSupplier, Dim3DDiagram, StackableDiagram, Protocol):
    ...
