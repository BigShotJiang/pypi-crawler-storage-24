from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.chart2 import XChartTypeContainer
from com.sun.star.util import XCloneable

@runtime_checkable
class CoordinateSystem(XCoordinateSystem, XChartTypeContainer, XCloneable, Protocol):
    SwapXAndYAxis: bool
