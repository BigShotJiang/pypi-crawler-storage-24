from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.awt import UnoControlEdit
from com.sun.star.awt import XSpinField
from com.sun.star.awt import XTimeField

@runtime_checkable
class UnoControlTimeField(UnoControlEdit, XSpinField, XTimeField, Protocol):
    ...
