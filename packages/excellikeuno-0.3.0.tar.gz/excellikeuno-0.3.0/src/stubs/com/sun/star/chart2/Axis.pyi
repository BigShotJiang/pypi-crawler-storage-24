from __future__ import annotations
from typing import Any, Protocol, runtime_checkable

@runtime_checkable
class Axis(Protocol):
    Show: bool
    CrossoverPosition: ChartAxisPosition
    CrossoverValue: float
    DisplayLabels: bool
    LabelPosition: ChartAxisLabelPosition
    TextBreak: bool
    TextOverlap: bool
    StackCharacters: bool
    TextRotation: float
    NumberFormat: int
    MajorTickmarks: int
    MinorTickmarks: int
    MarkPosition: ChartAxisMarkPosition
    DisplayUnits: bool
    BuiltInUnit: str
    TryStaggeringFirst: bool
    MajorOrigin: int
