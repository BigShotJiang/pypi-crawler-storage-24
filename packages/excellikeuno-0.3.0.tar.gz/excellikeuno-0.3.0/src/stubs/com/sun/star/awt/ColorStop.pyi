from __future__ import annotations
from typing import Any, TypedDict

class ColorStop(TypedDict, total=False):
    StopOffset: float
    StopColor: RGBColor
