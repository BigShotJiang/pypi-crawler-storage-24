from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.awt import UnoControl
from com.sun.star.awt import XProgressBar

@runtime_checkable
class UnoControlProgressBar(UnoControl, XProgressBar, Protocol):
    ...
