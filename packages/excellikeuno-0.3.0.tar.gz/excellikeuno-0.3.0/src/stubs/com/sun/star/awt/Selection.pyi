from __future__ import annotations
from typing import Any, TypedDict

class Selection(TypedDict, total=False):
    Min: int
    Max: int
