from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.chart import XAxisZSupplier

@runtime_checkable
class ChartAxisZSupplier(XAxisZSupplier, Protocol):
    HasZAxis: bool
    HasZAxisDescription: bool
    HasZAxisGrid: bool
    HasZAxisHelpGrid: bool
    HasZAxisTitle: bool
