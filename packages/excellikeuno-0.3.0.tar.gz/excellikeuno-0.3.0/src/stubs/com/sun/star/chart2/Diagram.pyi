from __future__ import annotations
from typing import Any, Protocol, runtime_checkable

@runtime_checkable
class Diagram(XTitled, Protocol):
    PosSizeExcludeLabels: bool
    SortByXValues: bool
    ConnectBars: bool
    GroupBarsPerAxis: bool
    StartingAngle: int
    RightAngledAxes: bool
    Perspective: int
    RotationHorizontal: int
    RotationVertical: int
    MissingValueTreatment: int
    ExternalData: str
