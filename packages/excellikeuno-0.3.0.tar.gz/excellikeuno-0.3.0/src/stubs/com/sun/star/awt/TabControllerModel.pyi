from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.awt import XTabControllerModel
from com.sun.star.io import XPersistObject

@runtime_checkable
class TabControllerModel(XTabControllerModel, XPersistObject, Protocol):
    ...
