from __future__ import annotations
from typing import Any, Protocol, runtime_checkable

@runtime_checkable
class XSortableGridData(Protocol):
    def removeColumnSort(self) -> None: ...
    def getCurrentSortOrder(self) -> boolean >: ...
