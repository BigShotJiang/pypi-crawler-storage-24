from __future__ import annotations
from typing import Any, Protocol, runtime_checkable

@runtime_checkable
class DataPointProperties(Protocol):
    Color: int
    Transparency: int
    TransparencyGradientName: str
    GradientName: str
    HatchName: str
    FillBitmapName: str
    FillBackground: bool
    BorderColor: int
    BorderWidth: int
    BorderDashName: str
    BorderTransparency: int
    LineWidth: int
    LineDashName: str
    FillBitmapOffsetX: int
    FillBitmapOffsetY: int
    FillBitmapPositionOffsetX: int
    FillBitmapPositionOffsetY: int
    FillBitmapRectanglePoint: RectanglePoint
    FillBitmapLogicalSize: bool
    FillBitmapSizeX: int
    FillBitmapSizeY: int
    FillBitmapMode: BitmapMode
    Symbol: Symbol
    Offset: float
    Geometry3D: int
    Label: DataPointLabel
    CustomLabelFields: list[XDataPointCustomLabelField]
    LabelSeparator: str
    TextWordWrap: bool
    NumberFormat: int
    PercentageNumberFormat: int
    LabelPlacement: int
    ReferencePageSize: Size
    ErrorBarX: XPropertySet
    ErrorBarY: XPropertySet
    ShowErrorBox: bool
    PercentDiagonal: int
