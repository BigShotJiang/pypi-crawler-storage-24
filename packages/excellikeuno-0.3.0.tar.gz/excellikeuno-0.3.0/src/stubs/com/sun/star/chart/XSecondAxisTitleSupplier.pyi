from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.uno import XInterface

@runtime_checkable
class XSecondAxisTitleSupplier(XInterface, Protocol):
    def getSecondXAxisTitle(self) -> XShape: ...
    def getSecondYAxisTitle(self) -> XShape: ...
