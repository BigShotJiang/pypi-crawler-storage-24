from __future__ import annotations
from typing import Any, TypedDict
from com.sun.star.lang import EventObject

class EndDockingEvent(TypedDict, total=False):
    WindowRectangle: Rectangle
    bFloating: bool
    bCancelled: bool
