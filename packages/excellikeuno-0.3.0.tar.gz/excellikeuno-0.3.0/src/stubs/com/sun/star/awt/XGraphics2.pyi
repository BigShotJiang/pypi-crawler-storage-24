from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.awt import XGraphics

@runtime_checkable
class XGraphics2(XGraphics, Protocol):
    def clear(self, aRect: Rectangle) -> None: ...
    def drawImage(self, nX: int, nY: int, nWidth: int, nHeight: int, nStyle: int, aGraphic: XGraphic) -> None: ...
