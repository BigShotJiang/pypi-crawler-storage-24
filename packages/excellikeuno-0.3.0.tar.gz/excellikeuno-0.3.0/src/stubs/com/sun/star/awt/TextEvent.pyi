from __future__ import annotations
from typing import Any, TypedDict
from com.sun.star.lang import EventObject

class TextEvent(TypedDict, total=False):
    dummy1: int
