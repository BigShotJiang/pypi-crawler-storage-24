from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.drawing import Shape
from com.sun.star.xml import UserDefinedAttributesSupplier

@runtime_checkable
class ChartTitle(Shape, UserDefinedAttributesSupplier, Protocol):
    AutomaticPosition: bool
    TextRotation: int
    String: str
