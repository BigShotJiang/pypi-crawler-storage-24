from __future__ import annotations
from typing import Any, Protocol, runtime_checkable

@runtime_checkable
class XWindowListener2(XWindowListener, Protocol):
    def windowEnabled(self, e: EventObject) -> None: ...
    def windowDisabled(self, e: EventObject) -> None: ...
