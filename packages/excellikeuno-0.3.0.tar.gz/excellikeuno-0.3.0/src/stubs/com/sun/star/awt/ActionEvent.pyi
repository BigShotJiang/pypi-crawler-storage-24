from __future__ import annotations
from typing import Any, TypedDict
from com.sun.star.lang import EventObject

class ActionEvent(TypedDict, total=False):
    ActionCommand: str
