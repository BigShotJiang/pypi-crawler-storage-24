from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.beans import XPropertySet
from com.sun.star.chart import ChartDataPointProperties

@runtime_checkable
class ChartPieSegmentProperties(ChartDataPointProperties, XPropertySet, Protocol):
    SegmentOffset: int
