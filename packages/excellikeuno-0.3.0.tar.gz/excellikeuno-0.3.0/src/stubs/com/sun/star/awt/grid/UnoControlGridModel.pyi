from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.awt import UnoControlModel

@runtime_checkable
class UnoControlGridModel(UnoControlModel, Protocol):
    ShowRowHeader: bool
    RowHeaderWidth: int
    ShowColumnHeader: bool
    ColumnHeaderHeight: int
    RowHeight: int
    ColumnModel: XGridColumnModel
    GridDataModel: XGridDataModel
    HScroll: bool
    VScroll: bool
    Tabstop: bool
    UseGridLines: bool
    RowBackgroundColors: list[Color]
    VerticalAlign: VerticalAlignment
    FontDescriptor: FontDescriptor
    TextLineColor: Color
    FontEmphasisMark: int
    FontRelief: int
    HelpText: str
    HelpURL: str
