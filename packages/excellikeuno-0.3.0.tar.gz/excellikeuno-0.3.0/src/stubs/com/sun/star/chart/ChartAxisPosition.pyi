from __future__ import annotations
from typing import Any
from enum import IntEnum
from enum import auto

class ChartAxisPosition(IntEnum):
    ZERO = auto()
    START = auto()
    END = auto()
    VALUE = auto()
