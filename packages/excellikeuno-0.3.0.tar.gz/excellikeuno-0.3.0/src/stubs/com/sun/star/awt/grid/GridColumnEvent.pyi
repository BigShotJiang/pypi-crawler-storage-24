from __future__ import annotations
from typing import Any, TypedDict
from .com.sun.star.lang import EventObject

class GridColumnEvent(TypedDict, total=False):
    AttributeName: str
    OldValue: Any
    NewValue: Any
    ColumnIndex: int
