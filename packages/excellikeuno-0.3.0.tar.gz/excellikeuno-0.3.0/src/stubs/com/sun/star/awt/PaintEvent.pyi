from __future__ import annotations
from typing import Any, TypedDict
from com.sun.star.lang import EventObject

class PaintEvent(TypedDict, total=False):
    UpdateRect: Rectangle
    Count: int
