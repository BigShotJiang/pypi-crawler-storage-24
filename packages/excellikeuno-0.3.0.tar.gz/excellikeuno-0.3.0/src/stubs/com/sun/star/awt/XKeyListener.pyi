from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.lang import XEventListener

@runtime_checkable
class XKeyListener(XEventListener, Protocol):
    def keyPressed(self, e: KeyEvent) -> None: ...
    def keyReleased(self, e: KeyEvent) -> None: ...
