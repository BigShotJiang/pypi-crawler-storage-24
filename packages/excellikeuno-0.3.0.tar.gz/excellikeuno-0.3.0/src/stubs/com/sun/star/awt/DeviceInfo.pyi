from __future__ import annotations
from typing import Any, TypedDict

class DeviceInfo(TypedDict, total=False):
    Width: int
    Height: int
    LeftInset: int
    TopInset: int
    RightInset: int
    BottomInset: int
    PixelPerMeterX: float
    PixelPerMeterY: float
    BitsPerPixel: int
    Capabilities: int
