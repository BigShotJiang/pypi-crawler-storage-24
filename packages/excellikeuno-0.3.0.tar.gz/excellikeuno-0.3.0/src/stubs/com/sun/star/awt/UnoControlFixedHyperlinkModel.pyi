from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.awt import UnoControlModel

@runtime_checkable
class UnoControlFixedHyperlinkModel(UnoControlModel, Protocol):
    Align: int
    BackgroundColor: Color
    Border: int
    BorderColor: int
    Enabled: bool
    FontDescriptor: FontDescriptor
    FontEmphasisMark: int
    FontRelief: int
    HelpText: str
    HelpURL: str
    Label: str
    MultiLine: bool
    Printable: bool
    TextColor: Color
    TextLineColor: Color
    URL: str
    VerticalAlign: VerticalAlignment
