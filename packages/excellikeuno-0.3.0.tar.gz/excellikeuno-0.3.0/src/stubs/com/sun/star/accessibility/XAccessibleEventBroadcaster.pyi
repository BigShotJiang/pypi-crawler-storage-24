from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from .com.sun.star.uno import XInterface

@runtime_checkable
class XAccessibleEventBroadcaster(XInterface, Protocol):
    def addAccessibleEventListener(self, xListener: XAccessibleEventListener) -> None: ...
    def removeAccessibleEventListener(self, xListener: XAccessibleEventListener) -> None: ...
