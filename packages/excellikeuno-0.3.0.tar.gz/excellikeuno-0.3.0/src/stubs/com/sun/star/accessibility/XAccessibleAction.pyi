from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from .com.sun.star.uno import XInterface

@runtime_checkable
class XAccessibleAction(XInterface, Protocol):
    def getAccessibleActionCount(self) -> int: ...
