from __future__ import annotations
from typing import Any
from enum import IntEnum
from enum import auto

class ChartDataChangeType(IntEnum):
    ALL = auto()
    DATA_RANGE = auto()
    COLUMN_INSERTED = auto()
    ROW_INSERTED = auto()
    COLUMN_DELETED = auto()
    ROW_DELETED = auto()
