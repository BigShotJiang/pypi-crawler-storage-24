from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.chart import XAxisYSupplier

@runtime_checkable
class ChartAxisYSupplier(XAxisYSupplier, Protocol):
    HasYAxis: bool
    HasYAxisDescription: bool
    HasYAxisGrid: bool
    HasYAxisHelpGrid: bool
    HasYAxisTitle: bool
