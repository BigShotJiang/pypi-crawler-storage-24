from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.awt import UnoControlModel

@runtime_checkable
class UnoControlFixedLineModel(UnoControlModel, Protocol):
    Enabled: bool
    FontDescriptor: FontDescriptor
    FontEmphasisMark: int
    FontRelief: int
    HelpText: str
    HelpURL: str
    Label: str
    Orientation: int
    Printable: bool
    TextColor: Color
    TextLineColor: Color
