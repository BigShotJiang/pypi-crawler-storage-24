from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.awt import UnoControlModel

@runtime_checkable
class UnoControlGroupBoxModel(UnoControlModel, Protocol):
    Enabled: bool
    FontDescriptor: FontDescriptor
    FontEmphasisMark: int
    FontRelief: int
    HelpText: str
    HelpURL: str
    Label: str
    Printable: bool
    TextColor: Color
    TextLineColor: Color
    WritingMode: int
