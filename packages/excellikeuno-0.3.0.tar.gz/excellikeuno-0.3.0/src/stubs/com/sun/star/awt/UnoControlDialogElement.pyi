from __future__ import annotations
from typing import Any, Protocol, runtime_checkable

@runtime_checkable
class UnoControlDialogElement(Protocol):
    Height: int
    Name: str
    PositionX: str
    PositionY: str
    Step: int
    TabIndex: int
    Tag: str
    Width: int
