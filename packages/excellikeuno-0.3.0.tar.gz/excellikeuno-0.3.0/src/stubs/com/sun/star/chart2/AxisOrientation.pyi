from __future__ import annotations
from typing import Any
from enum import IntEnum
from enum import auto

class AxisOrientation(IntEnum):
    MATHEMATICAL = auto()
    REVERSE = auto()
