from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.awt import UnoControlModel

@runtime_checkable
class UnoControlCurrencyFieldModel(UnoControlModel, Protocol):
    BackgroundColor: Color
    Border: int
    BorderColor: int
    CurrencySymbol: str
    DecimalAccuracy: int
    Enabled: bool
    FontDescriptor: FontDescriptor
    FontEmphasisMark: int
    FontRelief: int
    HelpText: str
    HelpURL: str
    HideInactiveSelection: bool
    PrependCurrencySymbol: bool
    Printable: bool
    ReadOnly: bool
    Repeat: bool
    RepeatDelay: int
    ShowThousandsSeparator: bool
    Spin: bool
    StrictFormat: bool
    Tabstop: bool
    TextColor: Color
    TextLineColor: Color
    Value: float
    ValueMax: float
    ValueMin: float
    ValueStep: float
    WritingMode: int
    MouseWheelBehavior: int
    VerticalAlign: VerticalAlignment
    HighlightColor: Color
    HighlightTextColor: Color
