from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.awt import UnoControlModel

@runtime_checkable
class AnimatedImagesControlModel(UnoControlModel, XAnimatedImages, Protocol):
    ...
