from __future__ import annotations
from typing import Any
from enum import IntEnum
from enum import auto

class ChartAxisMarkPosition(IntEnum):
    AT_LABELS = auto()
    AT_AXIS = auto()
    AT_LABELS_AND_AXIS = auto()
