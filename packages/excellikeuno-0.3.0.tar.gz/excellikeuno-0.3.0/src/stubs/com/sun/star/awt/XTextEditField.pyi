from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.uno import XInterface

@runtime_checkable
class XTextEditField(XInterface, Protocol):
    def setEchoChar(self, cEcho: str) -> None: ...
