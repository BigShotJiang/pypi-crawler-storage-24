from __future__ import annotations
from typing import Any
from enum import IntEnum
from enum import auto

class GradientStyle(IntEnum):
    LINEAR = auto()
    AXIAL = auto()
    RADIAL = auto()
    ELLIPTICAL = auto()
    SQUARE = auto()
    RECT = auto()
