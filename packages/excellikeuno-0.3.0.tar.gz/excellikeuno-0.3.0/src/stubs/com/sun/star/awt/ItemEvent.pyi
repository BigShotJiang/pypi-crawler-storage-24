from __future__ import annotations
from typing import Any, TypedDict
from com.sun.star.lang import EventObject

class ItemEvent(TypedDict, total=False):
    Selected: int
    Highlighted: int
    ItemId: int
