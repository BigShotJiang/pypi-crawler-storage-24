from __future__ import annotations
from typing import Any
from enum import IntEnum
from enum import auto

class ChartAxisLabelPosition(IntEnum):
    NEAR_AXIS = auto()
    NEAR_AXIS_OTHER_SIDE = auto()
    OUTSIDE_START = auto()
    OUTSIDE_END = auto()
