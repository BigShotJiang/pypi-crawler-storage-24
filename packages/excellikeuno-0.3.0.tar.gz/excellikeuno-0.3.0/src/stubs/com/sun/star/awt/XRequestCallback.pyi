from __future__ import annotations
from typing import Any, Protocol, runtime_checkable

@runtime_checkable
class XRequestCallback(Protocol):
    def addCallback(self, xCallback: XCallback, aData: Any) -> None: ...
