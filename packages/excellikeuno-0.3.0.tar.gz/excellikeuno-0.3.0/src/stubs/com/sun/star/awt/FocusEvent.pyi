from __future__ import annotations
from typing import Any, TypedDict
from com.sun.star.lang import EventObject

class FocusEvent(TypedDict, total=False):
    FocusFlags: int
    NextFocus: XInterface
    Temporary: bool
