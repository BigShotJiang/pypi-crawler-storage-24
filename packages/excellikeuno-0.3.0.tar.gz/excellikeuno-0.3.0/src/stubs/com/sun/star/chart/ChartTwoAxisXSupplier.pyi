from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.chart import ChartAxisXSupplier
from com.sun.star.chart import XTwoAxisXSupplier

@runtime_checkable
class ChartTwoAxisXSupplier(XTwoAxisXSupplier, ChartAxisXSupplier, Protocol):
    HasSecondaryXAxis: bool
    HasSecondaryXAxisDescription: bool
    HasSecondaryXAxisTitle: bool
