from __future__ import annotations
from typing import Any, TypedDict
from .com.sun.star.lang import EventObject

class ItemListEvent(TypedDict, total=False):
    ItemPosition: int
    ItemText: Optional< string >
    ItemImageURL: Optional< string >
