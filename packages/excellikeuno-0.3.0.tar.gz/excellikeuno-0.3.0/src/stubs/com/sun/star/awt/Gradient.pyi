from __future__ import annotations
from typing import Any, TypedDict

class Gradient(TypedDict, total=False):
    Style: GradientStyle
    StartColor: Color
    EndColor: Color
    Angle: int
    Border: int
    XOffset: int
    YOffset: int
    StartIntensity: int
    EndIntensity: int
    StepCount: int
