from __future__ import annotations
from typing import Any, TypedDict

class Event(TypedDict, total=False):
    Source: Any
    Trigger: int
    Offset: Any
    Repeat: int
