from __future__ import annotations
from typing import Any, TypedDict

class SystemDependentXWindow(TypedDict, total=False):
    WindowHandle: int
    DisplayPointer: int
