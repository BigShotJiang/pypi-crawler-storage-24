from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.chart import ChartAxisYSupplier
from com.sun.star.chart import Diagram
from com.sun.star.chart import StackableDiagram

@runtime_checkable
class NetDiagram(Diagram, StackableDiagram, ChartAxisYSupplier, Protocol):
    ...
