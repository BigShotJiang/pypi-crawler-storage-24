from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.awt import XFont

@runtime_checkable
class XFont2(XFont, Protocol):
    def hasGlyphs(self, aText: str) -> bool: ...
