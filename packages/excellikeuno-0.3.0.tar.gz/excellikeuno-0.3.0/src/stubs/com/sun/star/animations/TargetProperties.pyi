from __future__ import annotations
from typing import Any, TypedDict

class TargetProperties(TypedDict, total=False):
    Target: Any
    Properties: list[NamedValue]
