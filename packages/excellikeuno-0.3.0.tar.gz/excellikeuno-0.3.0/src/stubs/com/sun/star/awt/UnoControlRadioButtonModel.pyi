from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.awt import UnoControlModel

@runtime_checkable
class UnoControlRadioButtonModel(UnoControlModel, Protocol):
    Align: int
    BackgroundColor: int
    Enabled: bool
    FontDescriptor: FontDescriptor
    FontEmphasisMark: int
    FontRelief: int
    HelpText: str
    HelpURL: str
    ImagePosition: int
    ImageURL: str
    Graphic: XGraphic
    Label: str
    MultiLine: bool
    Printable: bool
    State: int
    Tabstop: bool
    TextColor: Color
    TextLineColor: Color
    VerticalAlign: VerticalAlignment
    VisualEffect: int
    WritingMode: int
