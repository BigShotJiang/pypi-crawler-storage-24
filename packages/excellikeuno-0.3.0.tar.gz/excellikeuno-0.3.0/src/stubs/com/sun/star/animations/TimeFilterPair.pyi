from __future__ import annotations
from typing import Any, TypedDict

class TimeFilterPair(TypedDict, total=False):
    Time: float
    Progress: float
