from __future__ import annotations
from typing import Any
from enum import IntEnum
from enum import auto

class ChartLegendExpansion(IntEnum):
    WIDE = auto()
    HIGH = auto()
    BALANCED = auto()
    CUSTOM = auto()
