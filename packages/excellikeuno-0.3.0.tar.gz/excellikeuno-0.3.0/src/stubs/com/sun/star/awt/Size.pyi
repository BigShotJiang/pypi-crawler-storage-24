from __future__ import annotations
from typing import Any, TypedDict

class Size(TypedDict, total=False):
    Width: int
    Height: int
