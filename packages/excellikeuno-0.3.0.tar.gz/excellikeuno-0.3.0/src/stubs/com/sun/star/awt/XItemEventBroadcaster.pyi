from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.uno import XInterface

@runtime_checkable
class XItemEventBroadcaster(XInterface, Protocol):
    def addItemListener(self, l: XItemListener) -> None: ...
    def removeItemListener(self, l: XItemListener) -> None: ...
