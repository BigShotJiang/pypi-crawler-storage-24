from __future__ import annotations
from typing import Any, TypedDict
from com.sun.star.lang import EventObject

class GridSelectionEvent(TypedDict, total=False):
    SelectedRowIndexes: list[int]
    SelectedColumnIndexes: list[int]
