from __future__ import annotations
from typing import Any, Protocol, runtime_checkable

@runtime_checkable
class DataPoint(DataPointProperties, Protocol):
    Offset: float
