from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.awt import UnoControlModel

@runtime_checkable
class UnoControlImageControlModel(UnoControlModel, Protocol):
    BackgroundColor: Color
    Border: int
    BorderColor: int
    Enabled: bool
    HelpText: str
    HelpURL: str
    ImageURL: str
    Graphic: XGraphic
    Printable: bool
    ScaleImage: bool
    ScaleMode: int
    Tabstop: bool
