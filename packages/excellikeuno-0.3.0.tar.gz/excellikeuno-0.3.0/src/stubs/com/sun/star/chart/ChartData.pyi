from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.chart import XChartData

@runtime_checkable
class ChartData(XChartData, Protocol):
    ...
