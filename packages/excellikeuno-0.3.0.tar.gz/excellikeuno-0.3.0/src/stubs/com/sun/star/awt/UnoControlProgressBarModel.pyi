from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.awt import UnoControlModel

@runtime_checkable
class UnoControlProgressBarModel(UnoControlModel, Protocol):
    BackgroundColor: Color
    Border: int
    BorderColor: int
    Enabled: bool
    FillColor: Color
    HelpText: str
    HelpURL: str
    Printable: bool
    ProgressValue: int
    ProgressValueMax: int
    ProgressValueMin: int
