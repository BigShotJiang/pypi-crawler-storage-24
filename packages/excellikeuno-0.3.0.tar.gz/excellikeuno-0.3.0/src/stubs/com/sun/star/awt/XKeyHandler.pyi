from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from .com.sun.star.lang import XEventListener

@runtime_checkable
class XKeyHandler(XEventListener, Protocol):
    def keyPressed(self, aEvent: KeyEvent) -> bool: ...
    def keyReleased(self, aEvent: KeyEvent) -> bool: ...
