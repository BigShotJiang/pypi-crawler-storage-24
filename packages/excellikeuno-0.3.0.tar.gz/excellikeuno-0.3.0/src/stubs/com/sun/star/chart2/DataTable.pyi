from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.beans import PropertySet
from com.sun.star.drawing import FillProperties
from com.sun.star.drawing import LineProperties

@runtime_checkable
class DataTable(PropertySet, FillProperties, LineProperties, Protocol):
    HBorder: bool
    VBorder: bool
    Outline: bool
    Keys: bool
