from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.awt import UnoControlDialogElement
from com.sun.star.awt import XControlModel
from com.sun.star.beans import XMultiPropertySet
from com.sun.star.beans import XPropertySet
from com.sun.star.io import XPersistObject
from com.sun.star.lang import XComponent
from com.sun.star.util import XCloneable

@runtime_checkable
class UnoControlModel(UnoControlDialogElement, XControlModel, XComponent, XPropertySet, XMultiPropertySet, XPersistObject, XCloneable, Protocol):
    DefaultControl: str
