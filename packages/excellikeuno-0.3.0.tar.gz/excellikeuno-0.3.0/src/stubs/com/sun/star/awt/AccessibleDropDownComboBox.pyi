from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.accessibility import AccessibleContext
from com.sun.star.accessibility import XAccessibleAction
from com.sun.star.accessibility import XAccessibleComponent
from com.sun.star.accessibility import XAccessibleExtendedComponent

@runtime_checkable
class AccessibleDropDownComboBox(AccessibleContext, XAccessibleComponent, XAccessibleExtendedComponent, XAccessibleAction, Protocol):
    ...
