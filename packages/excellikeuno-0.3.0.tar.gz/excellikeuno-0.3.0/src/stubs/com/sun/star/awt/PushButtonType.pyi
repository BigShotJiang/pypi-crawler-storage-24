from __future__ import annotations
from typing import Any
from enum import IntEnum
from enum import auto

class PushButtonType(IntEnum):
    STANDARD = auto()
    OK = auto()
    CANCEL = auto()
    HELP = auto()
