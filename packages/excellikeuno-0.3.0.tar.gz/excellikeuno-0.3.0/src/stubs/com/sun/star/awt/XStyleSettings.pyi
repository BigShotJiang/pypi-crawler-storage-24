from __future__ import annotations
from typing import Any, Protocol, runtime_checkable

@runtime_checkable
class XStyleSettings(Protocol):
    def addStyleChangeListener(self, Listener: XStyleChangeListener) -> None: ...
    def removeStyleChangeListener(self, Listener: XStyleChangeListener) -> None: ...
