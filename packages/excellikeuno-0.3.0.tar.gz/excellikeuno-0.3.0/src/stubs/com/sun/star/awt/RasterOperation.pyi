from __future__ import annotations
from typing import Any
from enum import IntEnum
from enum import auto

class RasterOperation(IntEnum):
    OVERPAINT = auto()
    XOR = auto()
    ZEROBITS = auto()
    ALLBITS = auto()
    INVERT = auto()
