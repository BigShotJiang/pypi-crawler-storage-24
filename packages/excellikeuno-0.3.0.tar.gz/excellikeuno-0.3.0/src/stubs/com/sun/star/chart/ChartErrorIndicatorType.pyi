from __future__ import annotations
from typing import Any
from enum import IntEnum
from enum import auto

class ChartErrorIndicatorType(IntEnum):
    NONE = auto()
    TOP_AND_BOTTOM = auto()
    UPPER = auto()
    LOWER = auto()
