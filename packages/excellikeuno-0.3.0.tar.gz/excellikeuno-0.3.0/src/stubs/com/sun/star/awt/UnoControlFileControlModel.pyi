from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.awt import UnoControlModel

@runtime_checkable
class UnoControlFileControlModel(UnoControlModel, Protocol):
    BackgroundColor: Color
    Border: int
    BorderColor: int
    Enabled: bool
    FontDescriptor: FontDescriptor
    FontEmphasisMark: int
    FontRelief: int
    HelpText: str
    HelpURL: str
    HideInactiveSelection: bool
    Printable: bool
    ReadOnly: bool
    Tabstop: bool
    Text: str
    TextColor: Color
    TextLineColor: Color
    VerticalAlign: VerticalAlignment
