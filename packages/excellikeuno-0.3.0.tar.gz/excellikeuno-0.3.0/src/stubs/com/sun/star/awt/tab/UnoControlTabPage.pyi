from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.awt import UnoControlContainer

@runtime_checkable
class UnoControlTabPage(UnoControlContainer, XTabPage, Protocol):
    ...
