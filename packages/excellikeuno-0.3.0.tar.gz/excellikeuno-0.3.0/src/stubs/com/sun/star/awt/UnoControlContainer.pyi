from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.awt import UnoControl
from com.sun.star.awt import XControlContainer
from com.sun.star.awt import XUnoControlContainer
from com.sun.star.container import XContainer

@runtime_checkable
class UnoControlContainer(UnoControl, XUnoControlContainer, XControlContainer, XContainer, Protocol):
    ...
