from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from .com.sun.star.accessibility import XAccessibleText

@runtime_checkable
class XAccessibleMultiLineText(XAccessibleText, Protocol):
    def getTextAtLineWithCaret(self) -> TextSegment: ...
    def getNumberOfLineWithCaret(self) -> int: ...
