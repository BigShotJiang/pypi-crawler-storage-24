from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.beans import XPropertySet
from com.sun.star.chart import XAxisSupplier
from com.sun.star.chart import XDiagram
from com.sun.star.chart import XDiagramPositioning
from com.sun.star.chart import XSecondAxisTitleSupplier
from com.sun.star.xml import UserDefinedAttributesSupplier

@runtime_checkable
class Diagram(XDiagram, XAxisSupplier, XSecondAxisTitleSupplier, XDiagramPositioning, XPropertySet, UserDefinedAttributesSupplier, Protocol):
    AutomaticPosition: bool
    AutomaticSize: bool
    DataRowSource: ChartDataRowSource
    DataCaption: int
    MissingValueTreatment: int
