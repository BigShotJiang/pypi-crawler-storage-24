from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.beans import XPropertySet

@runtime_checkable
class XPrinterPropertySet(XPropertySet, Protocol):
    def getFormDescriptions(self) -> list[str]: ...
    def getBinarySetup(self) -> list[int]: ...
