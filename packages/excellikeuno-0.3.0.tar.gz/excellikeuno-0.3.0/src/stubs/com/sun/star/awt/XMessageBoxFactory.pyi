from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.uno import XInterface

@runtime_checkable
class XMessageBoxFactory(XInterface, Protocol):
    def createMessageBox(self, aParent: XWindowPeer, eType: MessageBoxType, nButtons: int, sTitle: str, sMessage: str) -> XMessageBox: ...
