from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.awt import UnoControlModel
from com.sun.star.awt.tab import XTabPageContainerModel

@runtime_checkable
class UnoControlTabPageContainerModel(UnoControlModel, XTabPageContainerModel, Protocol):
    ...
