from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.beans import XPropertySet
from com.sun.star.chart import ChartDataPointProperties
from com.sun.star.chart import ChartStatistics
from com.sun.star.xml import UserDefinedAttributesSupplier

@runtime_checkable
class ChartDataRowProperties(ChartDataPointProperties, ChartStatistics, UserDefinedAttributesSupplier, XPropertySet, Protocol):
    Axis: int
    DataRegressionProperties: XPropertySet
    DataErrorProperties: XPropertySet
    DataMeanValueProperties: XPropertySet
