from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.chart import X3DDisplay

@runtime_checkable
class Dim3DDiagram(X3DDisplay, Protocol):
    Dim3D: bool
    Perspective: int
    RotationHorizontal: int
    RotationVertical: int
