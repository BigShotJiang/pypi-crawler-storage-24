from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.awt import UnoControlModel

@runtime_checkable
class UnoControlContainerModel(UnoControlModel, Protocol):
    BackgroundColor: Color
    Enabled: bool
    Border: int
    BorderColor: int
    Printable: bool
    Text: str
    HelpText: str
    HelpURL: str
