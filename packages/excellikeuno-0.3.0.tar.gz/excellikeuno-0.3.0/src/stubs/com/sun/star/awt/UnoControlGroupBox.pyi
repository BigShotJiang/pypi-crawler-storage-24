from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.awt import UnoControl

@runtime_checkable
class UnoControlGroupBox(UnoControl, Protocol):
    ...
