from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from .com.sun.star.auth import XSSOContext

@runtime_checkable
class XSSOAcceptorContext(XSSOContext, Protocol):
    ...
