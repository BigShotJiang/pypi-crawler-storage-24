from __future__ import annotations
from typing import Any, TypedDict
from com.sun.star.awt import InputEvent

class MouseEvent(TypedDict, total=False):
    Buttons: int
    X: int
    Y: int
    ClickCount: int
    PopupTrigger: bool
