from __future__ import annotations
from typing import Any, Protocol, runtime_checkable

@runtime_checkable
class XMutableTreeDataModel(XTreeDataModel, Protocol):
    def createNode(self, DisplayValue: Any, ChildrenOnDemand: bool) -> XMutableTreeNode: ...
