from __future__ import annotations
from typing import Any, TypedDict

class KeyStroke(TypedDict, total=False):
    Modifiers: int
    KeyCode: int
    KeyChar: str
    KeyFunc: int
