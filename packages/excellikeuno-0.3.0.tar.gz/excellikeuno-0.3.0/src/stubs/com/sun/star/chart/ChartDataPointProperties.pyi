from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.beans import XPropertySet
from com.sun.star.chart import Chart3DBarProperties
from com.sun.star.drawing import FillProperties
from com.sun.star.drawing import LineProperties
from com.sun.star.style import CharacterProperties
from com.sun.star.xml import UserDefinedAttributesSupplier

@runtime_checkable
class ChartDataPointProperties(FillProperties, LineProperties, CharacterProperties, UserDefinedAttributesSupplier, Chart3DBarProperties, XPropertySet, Protocol):
    DataCaption: int
    LabelSeparator: str
    NumberFormat: int
    PercentageNumberFormat: int
    LabelPlacement: int
    SymbolType: int
    SymbolBitmapURL: str
    SegmentOffset: int
    TextWordWrap: bool
    SymbolBitmap: XGraphic
