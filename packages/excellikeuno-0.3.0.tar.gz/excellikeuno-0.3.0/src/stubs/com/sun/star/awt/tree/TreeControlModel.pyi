from __future__ import annotations
from typing import Any, Protocol, runtime_checkable

@runtime_checkable
class TreeControlModel(Protocol):
    DataModel: XTreeDataModel
    RootDisplayed: bool
    ShowsHandles: bool
    ShowsRootHandles: bool
    RowHeight: int
    Editable: bool
    InvokesStopNodeEditing: bool
