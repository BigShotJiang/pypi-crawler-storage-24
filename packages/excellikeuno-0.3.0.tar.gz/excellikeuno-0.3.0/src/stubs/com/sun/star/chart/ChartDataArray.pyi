from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.chart import ChartData
from com.sun.star.chart import XChartDataArray

@runtime_checkable
class ChartDataArray(ChartData, XChartDataArray, Protocol):
    ...
