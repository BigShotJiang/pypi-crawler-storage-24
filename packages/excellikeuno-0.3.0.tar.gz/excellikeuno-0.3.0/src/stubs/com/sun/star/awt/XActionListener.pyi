from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.lang import XEventListener

@runtime_checkable
class XActionListener(XEventListener, Protocol):
    def actionPerformed(self, rEvent: ActionEvent) -> None: ...
