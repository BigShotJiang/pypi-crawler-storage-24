from __future__ import annotations
from typing import Any, Protocol, runtime_checkable

@runtime_checkable
class RoadmapItem(Protocol):
    ID: int
    Label: str
    Interactive: bool
    Enabled: bool
