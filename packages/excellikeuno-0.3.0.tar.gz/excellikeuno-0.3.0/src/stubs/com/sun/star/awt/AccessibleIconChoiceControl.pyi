from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.accessibility import AccessibleContext
from com.sun.star.accessibility import XAccessibleComponent
from com.sun.star.accessibility import XAccessibleSelection

@runtime_checkable
class AccessibleIconChoiceControl(AccessibleContext, XAccessibleComponent, XAccessibleSelection, Protocol):
    ...
