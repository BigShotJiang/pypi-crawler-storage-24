from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.awt import UnoControl
from com.sun.star.awt import XLayoutConstrains
from com.sun.star.awt import XListBox
from com.sun.star.awt import XTextLayoutConstrains

@runtime_checkable
class UnoControlListBox(UnoControl, XListBox, XLayoutConstrains, XTextLayoutConstrains, Protocol):
    ...
