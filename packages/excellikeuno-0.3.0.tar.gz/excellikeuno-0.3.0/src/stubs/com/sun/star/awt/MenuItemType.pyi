from __future__ import annotations
from typing import Any
from enum import IntEnum
from enum import auto

class MenuItemType(IntEnum):
    DONTKNOW = auto()
    STRING = auto()
    IMAGE = auto()
    STRINGIMAGE = auto()
    SEPARATOR = auto()
