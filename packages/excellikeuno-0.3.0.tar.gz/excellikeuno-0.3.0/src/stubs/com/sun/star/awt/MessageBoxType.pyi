from __future__ import annotations
from typing import Any
from enum import IntEnum
from enum import auto

class MessageBoxType(IntEnum):
    MESSAGEBOX = auto()
    INFOBOX = auto()
    WARNINGBOX = auto()
    ERRORBOX = auto()
    QUERYBOX = auto()
