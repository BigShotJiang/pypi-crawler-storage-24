from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.awt.grid import XGridColumn

@runtime_checkable
class GridColumn(XGridColumn, Protocol):
    ...
