from __future__ import annotations
from typing import Any
from enum import IntEnum
from enum import auto

class WindowClass(IntEnum):
    TOP = auto()
    MODALTOP = auto()
    CONTAINER = auto()
    SIMPLE = auto()
