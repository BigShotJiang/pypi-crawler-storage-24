from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from .com.sun.star.container import XChild

@runtime_checkable
class XAnimationNode(XChild, Protocol):
    ...
