from __future__ import annotations
from typing import Any, Protocol, runtime_checkable

@runtime_checkable
class XTabPageContainerModel(Protocol):
    def createTabPage(self, TabPageID: int) -> XTabPageModel: ...
    def loadTabPage(self, TabPageID: int, ResourceURL: str) -> XTabPageModel: ...
