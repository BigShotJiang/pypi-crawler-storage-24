from __future__ import annotations
from typing import Any
from enum import IntEnum
from enum import auto

class AdjustmentType(IntEnum):
    ADJUST_LINE = auto()
    ADJUST_PAGE = auto()
    ADJUST_ABS = auto()
