from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.awt import UnoControlModel

@runtime_checkable
class UnoControlListBoxModel(UnoControlModel, XItemList, Protocol):
    Align: int
    BackgroundColor: Color
    Border: int
    BorderColor: int
    Dropdown: bool
    Enabled: bool
    FontDescriptor: FontDescriptor
    FontEmphasisMark: int
    FontRelief: int
    HelpText: str
    HelpURL: str
    LineCount: int
    MultiSelection: bool
    Printable: bool
    ReadOnly: bool
    SelectedItems: list[int]
    StringItemList: list[str]
    Tabstop: bool
    TextColor: Color
    TextLineColor: Color
    WritingMode: int
    MouseWheelBehavior: int
    ItemSeparatorPos: int
    TypedItemList: list[Any]
    HighlightColor: Color
    HighlightTextColor: Color
