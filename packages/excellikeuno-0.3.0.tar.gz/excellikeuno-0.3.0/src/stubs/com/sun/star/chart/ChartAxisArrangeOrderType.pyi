from __future__ import annotations
from typing import Any
from enum import IntEnum
from enum import auto

class ChartAxisArrangeOrderType(IntEnum):
    AUTO = auto()
    SIDE_BY_SIDE = auto()
    STAGGER_EVEN = auto()
    STAGGER_ODD = auto()
