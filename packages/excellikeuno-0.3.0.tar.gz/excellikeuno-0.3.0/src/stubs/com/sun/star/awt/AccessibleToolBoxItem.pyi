from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.accessibility import AccessibleContext
from com.sun.star.accessibility import XAccessibleAction
from com.sun.star.accessibility import XAccessibleComponent
from com.sun.star.accessibility import XAccessibleExtendedComponent
from com.sun.star.accessibility import XAccessibleText
from com.sun.star.accessibility import XAccessibleValue

@runtime_checkable
class AccessibleToolBoxItem(AccessibleContext, XAccessibleComponent, XAccessibleExtendedComponent, XAccessibleAction, XAccessibleText, XAccessibleValue, Protocol):
    ...
