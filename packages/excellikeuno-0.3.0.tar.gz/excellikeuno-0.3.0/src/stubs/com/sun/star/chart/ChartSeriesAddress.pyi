from __future__ import annotations
from typing import Any, TypedDict

class ChartSeriesAddress(TypedDict, total=False):
    DataRangeAddress: str
    LabelAddress: str
    DomainRangeAddresses: list[str]
