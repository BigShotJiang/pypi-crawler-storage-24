from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.awt import UnoControlModel

@runtime_checkable
class UnoControlEditModel(UnoControlModel, Protocol):
    Align: int
    AutoHScroll: bool
    AutoVScroll: bool
    BackgroundColor: Color
    Border: int
    BorderColor: int
    EchoChar: int
    Enabled: bool
    FontDescriptor: FontDescriptor
    FontEmphasisMark: int
    FontRelief: int
    HardLineBreaks: bool
    HelpText: str
    HelpURL: str
    HideInactiveSelection: bool
    HScroll: bool
    LineEndFormat: int
    MaxTextLen: int
    MultiLine: bool
    PaintTransparent: bool
    Printable: bool
    ReadOnly: bool
    Tabstop: bool
    Text: str
    TextColor: Color
    TextLineColor: Color
    VScroll: bool
    WritingMode: int
    VerticalAlign: VerticalAlignment
    HighlightColor: Color
    HighlightTextColor: Color
