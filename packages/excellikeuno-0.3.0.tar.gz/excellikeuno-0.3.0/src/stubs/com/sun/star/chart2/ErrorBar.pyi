from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from data import XDataSink
from data import XDataSource

@runtime_checkable
class ErrorBar(XDataSink, XDataSource, Protocol):
    ErrorBarStyle: int
    PositiveError: float
    NegativeError: float
    Weight: float
    ShowPositiveError: bool
    ShowNegativeError: bool
