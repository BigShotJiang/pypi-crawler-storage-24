from __future__ import annotations
from typing import Any, TypedDict
from .com.sun.star.lang import EventObject

class TreeDataModelEvent(TypedDict, total=False):
    Nodes: list[XTreeNode]
    ParentNode: XTreeNode
