from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from .com.sun.star.uno import XInterface

@runtime_checkable
class XAxisSupplier(XInterface, Protocol):
    def getAxis(self, nDimensionIndex: int) -> XAxis: ...
    def getSecondaryAxis(self, nDimensionIndex: int) -> XAxis: ...
