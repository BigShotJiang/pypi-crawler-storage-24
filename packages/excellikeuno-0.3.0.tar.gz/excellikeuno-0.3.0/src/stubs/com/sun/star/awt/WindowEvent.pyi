from __future__ import annotations
from typing import Any, TypedDict
from com.sun.star.lang import EventObject

class WindowEvent(TypedDict, total=False):
    X: int
    Y: int
    Width: int
    Height: int
    LeftInset: int
    TopInset: int
    RightInset: int
    BottomInset: int
