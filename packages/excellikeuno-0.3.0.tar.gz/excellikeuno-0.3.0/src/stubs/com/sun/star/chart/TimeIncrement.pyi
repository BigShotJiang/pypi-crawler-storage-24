from __future__ import annotations
from typing import Any, TypedDict

class TimeIncrement(TypedDict, total=False):
    MajorTimeInterval: Any
    MinorTimeInterval: Any
    TimeResolution: Any
