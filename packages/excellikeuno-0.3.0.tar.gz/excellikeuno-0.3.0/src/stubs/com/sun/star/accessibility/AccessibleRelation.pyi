from __future__ import annotations
from typing import Any, TypedDict

class AccessibleRelation(TypedDict, total=False):
    RelationType: AccessibleRelationType
    TargetSet: list[XAccessible]
