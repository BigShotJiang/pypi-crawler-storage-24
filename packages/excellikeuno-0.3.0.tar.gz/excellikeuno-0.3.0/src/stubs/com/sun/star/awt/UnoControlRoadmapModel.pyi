from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.awt import UnoControlModel
from com.sun.star.container import XIndexContainer

@runtime_checkable
class UnoControlRoadmapModel(UnoControlModel, XIndexContainer, Protocol):
    BackgroundColor: int
    Interactive: bool
    Complete: bool
    ImageURL: str
    Graphic: XGraphic
    Border: int
    Printable: bool
    Text: str
    CurrentItemID: int
    HelpText: str
    HelpURL: str
