from __future__ import annotations
from typing import Any, TypedDict

class ChartDataRow(TypedDict, total=False):
    Name: str
    Points: list[list[ChartDataValue]]
