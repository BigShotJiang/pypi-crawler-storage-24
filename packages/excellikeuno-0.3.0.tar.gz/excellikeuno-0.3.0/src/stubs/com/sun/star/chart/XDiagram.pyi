from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.drawing import XShape

@runtime_checkable
class XDiagram(XShape, Protocol):
    def getDiagramType(self) -> str: ...
