from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.chart import ChartAxisXSupplier
from com.sun.star.chart import ChartStatistics
from com.sun.star.chart import ChartTwoAxisYSupplier
from com.sun.star.chart import Diagram

@runtime_checkable
class BubbleDiagram(Diagram, ChartAxisXSupplier, ChartTwoAxisYSupplier, ChartStatistics, Protocol):
    ...
