from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.awt import UnoControlModel

@runtime_checkable
class UnoControlScrollBarModel(UnoControlModel, Protocol):
    BackgroundColor: Color
    BlockIncrement: int
    Border: int
    BorderColor: int
    Enabled: bool
    HelpText: str
    HelpURL: str
    LineIncrement: int
    LiveScroll: bool
    Orientation: int
    Printable: bool
    RepeatDelay: int
    ScrollValue: int
    ScrollValueMin: int
    ScrollValueMax: int
    SymbolColor: Color
    Tabstop: bool
    VisibleSize: int
