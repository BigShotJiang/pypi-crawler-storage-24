from __future__ import annotations
from typing import Any
from enum import IntEnum
from enum import auto

class AccessibleRelationType(IntEnum):
    INVALID = auto()
    CONTENT_FLOWS_FROM = auto()
    CONTENT_FLOWS_TO = auto()
    CONTROLLED_BY = auto()
    CONTROLLER_FOR = auto()
    LABEL_FOR = auto()
    LABELED_BY = auto()
    MEMBER_OF = auto()
    SUB_WINDOW_OF = auto()
    NODE_CHILD_OF = auto()
    DESCRIBED_BY = auto()
