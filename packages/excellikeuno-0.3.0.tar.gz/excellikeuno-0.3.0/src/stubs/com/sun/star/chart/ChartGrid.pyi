from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.beans import XPropertySet
from com.sun.star.drawing import LineProperties
from com.sun.star.xml import UserDefinedAttributesSupplier

@runtime_checkable
class ChartGrid(LineProperties, UserDefinedAttributesSupplier, XPropertySet, Protocol):
    ...
