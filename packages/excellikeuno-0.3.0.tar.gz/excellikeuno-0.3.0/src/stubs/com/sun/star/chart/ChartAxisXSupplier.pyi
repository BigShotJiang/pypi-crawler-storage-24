from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.chart import XAxisXSupplier

@runtime_checkable
class ChartAxisXSupplier(XAxisXSupplier, Protocol):
    HasXAxis: bool
    HasXAxisDescription: bool
    HasXAxisGrid: bool
    HasXAxisHelpGrid: bool
    HasXAxisTitle: bool
