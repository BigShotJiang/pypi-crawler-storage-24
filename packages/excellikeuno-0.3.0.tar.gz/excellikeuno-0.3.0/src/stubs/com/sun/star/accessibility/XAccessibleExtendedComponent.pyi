from __future__ import annotations
from typing import Any, Protocol, runtime_checkable

@runtime_checkable
class XAccessibleExtendedComponent(XAccessibleComponent, Protocol):
    def getTitledBorderText(self) -> str: ...
    def getToolTipText(self) -> str: ...
