from __future__ import annotations
from typing import Any
from enum import IntEnum
from enum import auto

class AccessibleScrollType(IntEnum):
    SCROLL_TOP_LEFT = auto()
    SCROLL_BOTTOM_RIGHT = auto()
    SCROLL_TOP_EDGE = auto()
    SCROLL_BOTTOM_EDGE = auto()
    SCROLL_LEFT_EDGE = auto()
    SCROLL_RIGHT_EDGE = auto()
    SCROLL_ANYWHERE = auto()
