from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.accessibility import AccessibleContext
from com.sun.star.accessibility import XAccessibleComponent
from com.sun.star.accessibility import XAccessibleText

@runtime_checkable
class AccessibleListItem(AccessibleContext, XAccessibleComponent, XAccessibleText, Protocol):
    ...
