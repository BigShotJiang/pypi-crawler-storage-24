from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from .com.sun.star.accessibility import XAccessibleContext

@runtime_checkable
class XAccessibleContext2(XAccessibleContext, Protocol):
    def getAccessibleId(self) -> str: ...
