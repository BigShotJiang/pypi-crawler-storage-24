from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.lang import XEventListener

@runtime_checkable
class XActivateListener(XEventListener, Protocol):
    def windowActivated(self, e: EventObject) -> None: ...
    def windowDeactivated(self, e: EventObject) -> None: ...
