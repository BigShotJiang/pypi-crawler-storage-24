from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.accessibility import XAccessible
from com.sun.star.awt import XControl
from com.sun.star.awt import XView
from com.sun.star.awt import XWindow
from com.sun.star.lang import XComponent

@runtime_checkable
class UnoControl(XComponent, XControl, XWindow, XView, XAccessible, Protocol):
    ...
