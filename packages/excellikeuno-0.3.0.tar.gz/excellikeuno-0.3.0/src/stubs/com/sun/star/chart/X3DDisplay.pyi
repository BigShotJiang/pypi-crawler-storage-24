from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.uno import XInterface

@runtime_checkable
class X3DDisplay(XInterface, Protocol):
    def getWall(self) -> XPropertySet: ...
    def getFloor(self) -> XPropertySet: ...
