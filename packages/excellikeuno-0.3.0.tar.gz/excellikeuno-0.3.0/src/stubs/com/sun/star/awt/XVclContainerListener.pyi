from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.lang import XEventListener

@runtime_checkable
class XVclContainerListener(XEventListener, Protocol):
    def windowAdded(self, e: VclContainerEvent) -> None: ...
    def windowRemoved(self, e: VclContainerEvent) -> None: ...
