from __future__ import annotations
from typing import Any, TypedDict

class XFontMappingUseItem(TypedDict, total=False):
    originalFont: str
    usedFonts: list[str]
    count: int
