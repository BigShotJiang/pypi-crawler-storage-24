from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.awt import UnoControlEdit
from com.sun.star.awt import XNumericField
from com.sun.star.awt import XSpinField

@runtime_checkable
class UnoControlNumericField(UnoControlEdit, XSpinField, XNumericField, Protocol):
    ...
