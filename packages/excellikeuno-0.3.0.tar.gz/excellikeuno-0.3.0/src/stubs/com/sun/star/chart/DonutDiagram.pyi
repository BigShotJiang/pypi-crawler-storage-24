from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.chart import Diagram

@runtime_checkable
class DonutDiagram(Diagram, Protocol):
    ...
