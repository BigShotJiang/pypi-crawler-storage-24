from __future__ import annotations
from typing import Any
from enum import IntEnum
from enum import auto

class ChartLegendPosition(IntEnum):
    NONE = auto()
    LEFT = auto()
    TOP = auto()
    RIGHT = auto()
    BOTTOM = auto()
