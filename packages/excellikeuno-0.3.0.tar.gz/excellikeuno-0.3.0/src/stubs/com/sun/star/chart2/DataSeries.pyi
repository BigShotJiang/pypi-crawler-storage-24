from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from data import XDataSink
from data import XDataSource

@runtime_checkable
class DataSeries(DataPointProperties, XDataSeries, XDataSink, XDataSource, XRegressionCurveContainer, Protocol):
    AttributedDataPoints: list[int]
    StackingDirection: StackingDirection
    VaryColorsByPoint: bool
    AttachedAxisIndex: int
    ShowLegendEntry: bool
    DeletedLegendEntries: list[int]
    ShowCustomLeaderLines: bool
