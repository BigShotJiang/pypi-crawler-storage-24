from __future__ import annotations
from typing import Any, TypedDict

class WindowDescriptor(TypedDict, total=False):
    Type: WindowClass
    WindowServiceName: str
    Parent: XWindowPeer
    ParentIndex: int
    Bounds: Rectangle
    WindowAttributes: int
