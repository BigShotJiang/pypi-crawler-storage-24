from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.awt import UnoControlModel

@runtime_checkable
class UnoControlTimeFieldModel(UnoControlModel, Protocol):
    BackgroundColor: Color
    Border: int
    BorderColor: int
    Enabled: bool
    FontDescriptor: FontDescriptor
    FontEmphasisMark: int
    FontRelief: int
    HelpText: str
    HelpURL: str
    HideInactiveSelection: bool
    Printable: bool
    ReadOnly: bool
    Repeat: bool
    RepeatDelay: int
    Spin: bool
    StrictFormat: bool
    Tabstop: bool
    Text: str
    TextColor: Color
    TextLineColor: Color
    Time: Time
    TimeFormat: int
    TimeMax: Time
    TimeMin: Time
    WritingMode: int
    MouseWheelBehavior: int
    VerticalAlign: VerticalAlignment
    HighlightColor: Color
    HighlightTextColor: Color
