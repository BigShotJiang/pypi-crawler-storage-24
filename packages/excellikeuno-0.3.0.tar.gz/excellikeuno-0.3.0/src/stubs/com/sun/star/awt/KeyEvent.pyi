from __future__ import annotations
from typing import Any, TypedDict
from com.sun.star.awt import InputEvent

class KeyEvent(TypedDict, total=False):
    KeyCode: int
    KeyChar: str
    KeyFunc: int
