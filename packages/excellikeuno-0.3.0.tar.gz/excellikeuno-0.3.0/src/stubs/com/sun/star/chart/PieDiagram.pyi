from __future__ import annotations
from typing import Any, Protocol, runtime_checkable
from com.sun.star.chart import Diagram
from com.sun.star.chart import Dim3DDiagram

@runtime_checkable
class PieDiagram(Diagram, Dim3DDiagram, Protocol):
    ...
