from __future__ import annotations
from typing import Any, TypedDict

class AccessibleTableModelChange(TypedDict, total=False):
    Type: int
    FirstRow: int
    LastRow: int
    FirstColumn: int
    LastColumn: int
