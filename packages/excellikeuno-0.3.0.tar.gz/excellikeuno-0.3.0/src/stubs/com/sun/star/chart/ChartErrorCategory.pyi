from __future__ import annotations
from typing import Any
from enum import IntEnum
from enum import auto

class ChartErrorCategory(IntEnum):
    NONE = auto()
    VARIANCE = auto()
    STANDARD_DEVIATION = auto()
    PERCENT = auto()
    ERROR_MARGIN = auto()
    CONSTANT_VALUE = auto()
