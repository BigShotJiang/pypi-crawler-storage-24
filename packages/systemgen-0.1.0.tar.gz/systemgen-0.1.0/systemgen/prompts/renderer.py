def render_prompt(profile: dict, user_prompt: str | None) -> str:
    """Render a profile dict + user intent into a final AI prompt."""
    lines = []

    project = profile.get("project", {})
    database = profile.get("database", {})
    auth = profile.get("auth", {})
    validation = profile.get("validation", {})
    structure = profile.get("structure", {})
    conventions = profile.get("conventions", {})

    framework = project.get("framework", "")
    language = project.get("language", "")
    version = project.get("language_version", "")
    project_type = project.get("type") or ""

    if framework:
        suffix = f" and {language.capitalize()} {version}" if language and version else ""
        lines.append(
            f"You are working on a {project_type.lower()} project using "
            f"{framework}{suffix}."
        )

    engine = database.get("engine")
    orm = database.get("orm")
    mode = database.get("mode")
    if engine:
        orm_str = f" with {orm}" if orm else ""
        mode_str = f" ({mode})" if mode else ""
        lines.append(f"Use {engine}{orm_str} as the database{mode_str}.")

    auth_method = auth.get("method")
    if auth_method:
        lines.append(f"Authentication is {auth_method}-based.")

    validation_lib = validation.get("library")
    if validation_lib:
        lines.append(f"Use {validation_lib} for all validation and schemas.")

    struct_keys = [k for k in structure if k != "test_convention"]
    test_convention = structure.get("test_convention")

    convention_note = None
    if test_convention:
        tc_lower = test_convention.lower()
        convention_note = (
            "mirror app structure" if "mirror" in tc_lower else tc_lower
        )

    def _path_starts_with_tests(path: str) -> bool:
        return (path or "").strip().lower().startswith("tests")

    tests_merge_key = next(
        (k for k in struct_keys if _path_starts_with_tests(structure[k])),
        None,
    )

    if struct_keys:
        lines.append("\nStructure the project as follows:")
        for k in struct_keys:
            path = structure[k]
            if k == tests_merge_key and convention_note:
                lines.append(f"- {path}           ({convention_note})")
            else:
                lines.append(f"- {path}")

    if convention_note and tests_merge_key is None:
        lines.append(f"- tests/           ({convention_note})")

    convention_notes = conventions.get("notes")
    if convention_notes:
        lines.append(f"\nNaming conventions: {convention_notes}")

    lines.append("\nDo not deviate from this structure unless explicitly asked.")

    if user_prompt:
        lines.append(f"\nBuild the following: {user_prompt}")

    return "\n".join(lines)
