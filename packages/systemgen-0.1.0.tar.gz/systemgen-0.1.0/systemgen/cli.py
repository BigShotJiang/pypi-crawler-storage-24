import click
import questionary

from systemgen.commands import init, gen, profile, update
from systemgen.profiles.store import list_profiles


@click.group(invoke_without_command=True)
@click.pass_context
def cli(ctx):
    """systemgen — generate reusable AI context profiles for any project."""
    if ctx.invoked_subcommand is None:
        _default_menu()


def _default_menu():
    profiles = list_profiles()
    ctx = click.get_current_context()

    if not profiles:
        click.echo("\nWelcome to systemgen.")
        click.echo("No profiles found.\n")
        choice = questionary.select(
            "What would you like to do?",
            choices=[
                "Create a new profile",
                "View library templates",
                "Exit",
            ],
        ).ask()

        if choice == "Create a new profile":
            ctx.invoke(init.init_cmd)
        elif choice == "View library templates":
            ctx.invoke(profile.library)
        else:
            raise SystemExit(0)
        return

    click.echo("\nWelcome to systemgen.\n")
    choice = questionary.select(
        "What would you like to do?",
        choices=[
            "Generate prompt from a profile",
            "Create a new profile",
            "View library templates",
            "Exit",
        ],
    ).ask()

    if choice == "Generate prompt from a profile":
        ctx.invoke(gen.gen_cmd)
    elif choice == "Create a new profile":
        ctx.invoke(init.init_cmd)
    elif choice == "View library templates":
        ctx.invoke(profile.library)
    else:
        raise SystemExit(0)


cli.add_command(init.init_cmd, name="init")
cli.add_command(gen.gen_cmd, name="gen")
cli.add_command(update.update_cmd, name="update")
cli.add_command(profile.profile_group, name="profile")
