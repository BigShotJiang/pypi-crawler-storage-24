TEMPLATES: dict[str, dict] = {
    "fastapi": {
        "description": "Backend API — FastAPI, PostgreSQL, SQLAlchemy",
        "data": {
            "project": {
                "type": "Backend API",
                "framework": "FastAPI",
                "language": "python",
                "language_version": "3.11",
            },
            "database": {
                "engine": "PostgreSQL",
                "orm": "SQLAlchemy (async)",
                "mode": "async",
            },
            "auth": {"method": "JWT"},
            "validation": {"library": "Pydantic v2"},
            "structure": {
                "routers": "app/routers/",
                "services": "app/services/",
                "models": "app/models/",
                "schemas": "app/schemas/",
                "tests": "tests/",
                "test_convention": "Mirror app structure",
            },
            "conventions": {
                "notes": (
                    "snake_case files, plural routers, service suffix for business logic"
                ),
            },
        },
    },
    "django": {
        "description": "Backend API — Django, PostgreSQL",
        "data": {
            "project": {
                "type": "Backend API",
                "framework": "Django",
                "language": "python",
                "language_version": "3.11",
            },
            "database": {"engine": "PostgreSQL", "orm": "Django ORM"},
            "auth": {"method": "Session / Token"},
            "validation": {"library": "Django REST Framework serializers"},
            "structure": {
                "apps": "apps/",
                "tests": "tests/",
                "test_convention": "Mirror app structure",
            },
            "conventions": {"notes": "snake_case, one app per domain"},
        },
    },
    "flutter": {
        "description": "Mobile — Flutter, Dart",
        "data": {
            "project": {
                "type": "Mobile",
                "framework": "Flutter",
                "language": "dart",
                "language_version": "3.x",
            },
            "database": {"engine": "SQLite", "orm": "drift"},
            "auth": {"method": "JWT"},
            "validation": {"library": "None"},
            "structure": {
                "screens": "lib/screens/",
                "widgets": "lib/widgets/",
                "services": "lib/services/",
                "models": "lib/models/",
                "tests": "test/",
                "test_convention": "Mirror lib structure",
            },
            "conventions": {"notes": "camelCase, feature-first folder structure"},
        },
    },
    "nextjs": {
        "description": "Full Stack — Next.js, TypeScript",
        "data": {
            "project": {
                "type": "Full Stack",
                "framework": "Next.js",
                "language": "typescript",
                "language_version": "5.x",
            },
            "database": {"engine": "PostgreSQL", "orm": "Prisma"},
            "auth": {"method": "NextAuth"},
            "validation": {"library": "Zod"},
            "structure": {
                "app": "app/",
                "components": "components/",
                "lib": "lib/",
                "tests": "__tests__/",
                "test_convention": "Mirror app structure",
            },
            "conventions": {"notes": "PascalCase components, camelCase utilities"},
        },
    },
    "cli-python": {
        "description": "CLI Tool — Python, Click",
        "data": {
            "project": {
                "type": "CLI Tool",
                "framework": "Click",
                "language": "python",
                "language_version": "3.11",
            },
            "database": {"engine": "None"},
            "auth": {"method": "None"},
            "validation": {"library": "None"},
            "structure": {
                "commands": "src/commands/",
                "utils": "src/utils/",
                "tests": "tests/",
                "test_convention": "Mirror src structure",
            },
            "conventions": {"notes": "snake_case, one command per file"},
        },
    },
    "react": {
        "description": "Frontend — React, TypeScript",
        "data": {
            "project": {
                "type": "Frontend",
                "framework": "React",
                "language": "typescript",
                "language_version": "5.x",
            },
            "database": {"engine": "None"},
            "auth": {"method": "None"},
            "validation": {"library": "Zod"},
            "structure": {
                "components": "src/components/",
                "hooks": "src/hooks/",
                "pages": "src/pages/",
                "utils": "src/utils/",
                "tests": "src/__tests__/",
                "test_convention": "Mirror src structure",
            },
            "conventions": {"notes": "PascalCase components, camelCase hooks"},
        },
    },
}
