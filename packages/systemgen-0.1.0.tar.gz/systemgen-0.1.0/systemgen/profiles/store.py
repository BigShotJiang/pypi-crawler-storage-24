import json
from pathlib import Path

try:
    import tomllib
except ImportError:
    # stdlib tomllib is 3.11+; this branch is for older versions only
    # https://docs.python.org/3/library/tomllib.html
    import tomli as tomllib

import tomli_w

PROFILES_DIR = Path.home() / ".systemgen" / "profiles"


def _ensure_dir():
    PROFILES_DIR.mkdir(parents=True, exist_ok=True)


def save_profile(name: str, data: dict, fmt: str) -> list[str]:
    """Save profile in TOML, JSON, or both. Returns list of saved paths."""
    _ensure_dir()
    paths = []

    save_toml = "TOML" in fmt or "Both" in fmt or "Terminal" in fmt
    save_json = "JSON" in fmt or "Both" in fmt or "IDE" in fmt

    if save_toml:
        path = PROFILES_DIR / f"{name}.toml"
        with open(path, "wb") as f:
            tomli_w.dump(_clean(data), f)
        paths.append(str(path))

    if save_json:
        path = PROFILES_DIR / f"{name}.json"
        with open(path, "w") as f:
            json.dump(_clean(data), f, indent=2)
        paths.append(str(path))

    return paths


def load_profile(name: str) -> dict | None:
    """Load a profile by name. Prefers TOML, falls back to JSON."""
    toml_path = PROFILES_DIR / f"{name}.toml"
    json_path = PROFILES_DIR / f"{name}.json"

    if toml_path.exists():
        with open(toml_path, "rb") as f:
            return tomllib.load(f)

    if json_path.exists():
        with open(json_path) as f:
            return json.load(f)

    return None


def list_profiles() -> list[dict]:
    """Return list of profile dicts with name and formats."""
    _ensure_dir()
    found: dict[str, dict] = {}

    for f in PROFILES_DIR.iterdir():
        if f.suffix == ".toml":
            name = f.stem
            found.setdefault(name, {"name": name, "formats": []})
            found[name]["formats"].append(str(f))
        elif f.suffix == ".json":
            name = f.stem
            found.setdefault(name, {"name": name, "formats": []})
            found[name]["formats"].append(str(f))

    return [*found.values()]


def delete_profile(name: str, fmt: str) -> list[str]:
    """Delete a profile. Returns list of deleted paths."""
    deleted = []

    delete_toml = "TOML" in fmt or "Both" in fmt
    delete_json = "JSON" in fmt or "Both" in fmt

    toml_path = PROFILES_DIR / f"{name}.toml"
    json_path = PROFILES_DIR / f"{name}.json"

    if delete_toml and toml_path.exists():
        toml_path.unlink()
        deleted.append(str(toml_path))

    if delete_json and json_path.exists():
        json_path.unlink()
        deleted.append(str(json_path))

    return deleted


def _clean(data: dict) -> dict:
    return {
        k: (_clean(v) if isinstance(v, dict) else v)
        for k, v in data.items()
        if v not in (None, "")
    }
