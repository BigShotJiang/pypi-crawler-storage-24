import click

from systemgen.commands.questions import (
    ask_auth,
    ask_conventions,
    ask_database,
    ask_format,
    ask_framework,
    ask_language,
    ask_language_version,
    ask_orm,
    ask_profile_name,
    ask_project_name,
    ask_project_type,
    ask_structure,
    ask_test_convention,
    ask_validation,
)
from systemgen.profiles.store import save_profile


def collect_profile_data(*, current_profile: dict | None = None) -> dict:
    has = current_profile is not None
    project = (current_profile.get("project") or {}) if has else {}
    database = (current_profile.get("database") or {}) if has else {}
    structure_full = (current_profile.get("structure") or {}) if has else {}
    auth_prev = (current_profile.get("auth") or {}) if has else {}
    validation_prev = (current_profile.get("validation") or {}) if has else {}
    conventions_prev = (current_profile.get("conventions") or {}) if has else {}

    if has:
        framework = ask_framework(current=project.get("framework"))
        language = ask_language(framework, current=project.get("language"))
        orm, orm_mode = ask_orm(current=(database.get("orm"), database.get("mode")))
        structure_paths = ask_structure(framework, current=structure_full)
        test_convention = ask_test_convention(
            current=structure_full.get("test_convention")
        )
        auth_method = ask_auth(current=auth_prev.get("method"))
        conventions = ask_conventions(current=conventions_prev.get("notes"))
        project_name = ask_project_name(current=project.get("name"))
        project_type = ask_project_type(current=project.get("type"))
        language_version = ask_language_version(
            current=project.get("language_version")
        )
        db_engine = ask_database(current=database.get("engine"))
        validation_lib = ask_validation(current=validation_prev.get("library"))
    else:
        framework = ask_framework()
        language = ask_language(framework)
        orm, orm_mode = ask_orm()
        structure_paths = ask_structure(framework)
        test_convention = ask_test_convention()
        auth_method = ask_auth()
        conventions = ask_conventions()
        project_name = ask_project_name()
        project_type = ask_project_type()
        language_version = ask_language_version()
        db_engine = ask_database()
        validation_lib = ask_validation()

    structure = {**structure_paths}
    if test_convention:
        structure["test_convention"] = test_convention

    data: dict = {
        "project": _compact(
            {
                "name": project_name,
                "type": project_type,
                "framework": framework,
                "language": language,
                "language_version": language_version,
            }
        ),
        "database": _compact(
            {
                "engine": db_engine,
                "orm": orm,
                "mode": orm_mode,
            }
        ),
        "validation": _compact({"library": validation_lib}),
        "structure": structure,
    }

    if auth_method:
        data["auth"] = {"method": auth_method}

    if conventions:
        data["conventions"] = {"notes": conventions}

    return data


@click.command()
def init_cmd():
    """Create a new profile from scratch."""
    click.echo("")

    data = collect_profile_data()
    name = ask_profile_name()
    fmt = ask_format()

    paths = save_profile(name, data, fmt)
    click.echo("")
    for path in paths:
        click.echo(f"✓ Profile saved to {path}")


def _compact(d: dict) -> dict:
    return {k: v for k, v in d.items() if v is not None}
