import subprocess
import sys

import click
import questionary
import pyperclip

from systemgen.commands.questions import ask_prompt_input
from systemgen.profiles.store import list_profiles, load_profile
from systemgen.prompts.renderer import render_prompt


@click.command()
@click.option("--profile", "profile_name", default=None, help="Profile name to use.")
def gen_cmd(profile_name):
    """Generate a prompt from a saved profile."""
    profiles = list_profiles()

    if not profiles:
        click.echo("\n✗ No profiles found. Run `systemgen init` first.\n")
        return

    if not profile_name:
        profile_name = questionary.select(
            "Select a profile:",
            choices=[p["name"] for p in profiles],
        ).ask()

    profile_data = load_profile(profile_name)
    if not profile_data:
        click.echo(f"\n✗ Profile '{profile_name}' not found.\n")
        return

    user_prompt, prompt_file = ask_prompt_input()

    if prompt_file:
        click.echo(f"\n✓ Loaded prompt from {prompt_file}")

    click.echo(
        f"\n✓ Combining your profile{' with your prompt' if user_prompt else ''}...\n"
    )

    final_prompt = render_prompt(profile_data, user_prompt)

    click.echo("✓ Final prompt ready:\n")
    click.echo("─" * 60)
    click.echo(final_prompt)
    click.echo("─" * 60)
    click.echo("")

    if not user_prompt:
        destination = questionary.select(
            "What would you like to do with the profile prompt?",
            choices=[
                "Copy to clipboard",
                "Save to file",
                "Exit",
            ],
        ).ask()
    else:
        destination = questionary.select(
            "Pipe to:",
            choices=[
                "Claude (terminal)",
                "Ollama",
                "Copy to clipboard",
                "Save to file",
                "Exit",
            ],
        ).ask()

    if destination == "Claude (terminal)":
        _pipe_to_claude(final_prompt)
    elif destination == "Ollama":
        _pipe_to_ollama(final_prompt)
    elif destination == "Copy to clipboard":
        pyperclip.copy(final_prompt)
        click.echo("✓ Copied to clipboard.")
    elif destination == "Save to file":
        path = questionary.text("Save to file path:").ask().strip()
        with open(path, "w") as f:
            f.write(final_prompt)
        click.echo(f"✓ Saved to {path}")
    else:
        raise SystemExit(0)


def _pipe_to_claude(prompt: str):
    try:
        cmd = "claude.cmd" if sys.platform == "win32" else "claude"
        result = subprocess.run(
            [cmd, prompt],
            text=True,
        )
        if result.returncode != 0:
            click.echo("✗ Claude exited with an error.")
    except FileNotFoundError:
        click.echo(
            "✗ Claude CLI not found. Install it with: npm install -g @anthropic-ai/claude-code"
        )


_DEFAULT_OLLAMA_MODELS = ["mistral", "llama3.1", "codellama", "Custom"]


def _ollama_model_choices() -> list[str]:
    try:
        result = subprocess.run(
            ["ollama", "list"],
            capture_output=True,
            text=True,
        )
        if result.returncode != 0 or not (result.stdout or "").strip():
            return list(_DEFAULT_OLLAMA_MODELS)
        raw_lines = result.stdout.strip().splitlines()
        if len(raw_lines) < 2:
            return list(_DEFAULT_OLLAMA_MODELS)
        names = []
        for line in raw_lines[1:]:
            line = line.strip()
            if not line:
                continue
            name = line.split()[0]
            if name and name not in names:
                names.append(name)
        if not names:
            return list(_DEFAULT_OLLAMA_MODELS)
        return names + ["Custom"]
    except FileNotFoundError:
        return list(_DEFAULT_OLLAMA_MODELS)


def _pipe_to_ollama(prompt: str):
    models = _ollama_model_choices()
    model = questionary.select("Select Ollama model:", choices=models).ask()

    if model == "Custom":
        model = questionary.text("Enter model name:").ask().strip()

    click.echo(f"\n✓ Piping to Ollama ({model})...\n")

    try:
        result = subprocess.run(["ollama", "run", model], input=prompt, text=True)
        if result.returncode != 0:
            click.echo("✗ Ollama exited with an error.")
    except FileNotFoundError:
        click.echo("✗ Ollama not found. Install it from https://ollama.com")
