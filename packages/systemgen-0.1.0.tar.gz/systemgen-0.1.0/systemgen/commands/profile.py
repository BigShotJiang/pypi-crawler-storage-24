import click
import questionary

from systemgen.commands.questions import (
    ask_auth,
    ask_conventions,
    ask_database,
    ask_format,
    ask_framework,
    ask_language,
    ask_language_version,
    ask_orm,
    ask_test_convention,
    ask_validation,
)
from systemgen.profiles.store import (
    delete_profile,
    list_profiles,
    save_profile,
)
from systemgen.templates.library import TEMPLATES


@click.group()
def profile_group():
    """Manage saved profiles."""
    pass


@profile_group.command()
def list():
    """List all saved profiles."""
    profiles = list_profiles()

    if not profiles:
        click.echo("\nNo profiles found. Run `systemgen init` to create one.\n")
        return

    click.echo("\nSaved profiles:")
    for p in profiles:
        formats = "  |  ".join(p["formats"])
        click.echo(f"  - {p['name']:<16} {formats}")

    click.echo("")

    choice = questionary.select(
        "What would you like to do?",
        choices=[
            "Generate prompt from a profile",
            "Delete a profile",
            "Back",
        ],
    ).ask()

    ctx = click.get_current_context()
    if choice == "Generate prompt from a profile":
        from systemgen.commands.gen import gen_cmd

        ctx.invoke(gen_cmd)
    elif choice == "Delete a profile":
        ctx.invoke(delete)


@profile_group.command()
@click.argument("name", required=False)
def delete(name):
    """Delete a saved profile."""
    profiles = list_profiles()

    if not profiles:
        click.echo("\nNo profiles found.\n")
        return

    if not name:
        name = questionary.select(
            "Select profile to delete:",
            choices=[p["name"] for p in profiles],
        ).ask()

    fmt = questionary.select(
        "Delete which format?",
        choices=["TOML only", "JSON only", "Both"],
    ).ask()

    confirm = questionary.confirm(f"Are you sure you want to delete '{name}'?").ask()
    if confirm:
        deleted = delete_profile(name, fmt)
        click.echo("")
        for path in deleted:
            click.echo(f"✓ Deleted: {path}")
    else:
        click.echo("Cancelled.")


@profile_group.command()
def library():
    """Browse and import built-in templates."""
    click.echo("\nAvailable templates:")
    for key, tmpl in TEMPLATES.items():
        click.echo(f"  {key:<16} {tmpl['description']}")

    click.echo("")

    choices = [*TEMPLATES.keys(), "custom — Start from scratch"]
    selected = questionary.select(
        "Select a template to use as a starting point, or start from scratch:",
        choices=choices,
    ).ask()

    if selected.startswith("custom"):
        from systemgen.commands.init import init_cmd

        ctx = click.get_current_context()
        ctx.invoke(init_cmd)
        return

    template_data = TEMPLATES[selected]["data"].copy()
    name = questionary.text("Save as profile name:").ask().strip()
    fmt = ask_format()

    paths = save_profile(name, template_data, fmt)
    click.echo("\n✓ Template loaded.")
    for path in paths:
        click.echo(f"✓ Profile saved to {path}")


def run_field_edit_loop(data: dict) -> None:
    fields = {
        "Framework": lambda: setattr_nested(
            data,
            ["project", "framework"],
            ask_framework(current=data.get("project", {}).get("framework")),
        ),
        "Language": lambda: setattr_nested(
            data,
            ["project", "language"],
            ask_language(
                data.get("project", {}).get("framework"),
                current=data.get("project", {}).get("language"),
            ),
        ),
        "Database": lambda: setattr_nested(
            data,
            ["database", "engine"],
            ask_database(current=data.get("database", {}).get("engine")),
        ),
        "ORM / query layer": lambda: _apply_orm_from_ask(data),
        "Authentication": lambda: setattr_nested(
            data,
            ["auth", "method"],
            ask_auth(current=data.get("auth", {}).get("method")),
        ),
        "Validation library": lambda: setattr_nested(
            data,
            ["validation", "library"],
            ask_validation(current=data.get("validation", {}).get("library")),
        ),
        "Test convention": lambda: setattr_nested(
            data,
            ["structure", "test_convention"],
            ask_test_convention(
                current=data.get("structure", {}).get("test_convention")
            ),
        ),
        "Language version": lambda: setattr_nested(
            data,
            ["project", "language_version"],
            ask_language_version(
                current=data.get("project", {}).get("language_version")
            ),
        ),
        "Naming conventions": lambda: setattr_nested(
            data,
            ["conventions", "notes"],
            ask_conventions(current=data.get("conventions", {}).get("notes")),
        ),
    }

    while True:
        choice = questionary.select(
            "What would you like to edit?",
            choices=[*fields.keys(), "Done"],
        ).ask()

        if choice == "Done":
            break

        fields[choice]()


def setattr_nested(d: dict, keys: list, value):
    for key in keys[:-1]:
        d = d.setdefault(key, {})
    d[keys[-1]] = value


def _apply_orm_from_ask(data: dict):
    db = data.setdefault("database", {})
    orm, mode = ask_orm(current=(db.get("orm"), db.get("mode")))
    db["orm"] = orm
    if mode is not None:
        db["mode"] = mode
    else:
        db.pop("mode", None)
