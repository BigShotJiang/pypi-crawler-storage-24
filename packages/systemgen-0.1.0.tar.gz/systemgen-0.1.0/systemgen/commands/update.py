import click
import questionary

from systemgen.commands.init import collect_profile_data
from systemgen.commands.profile import run_field_edit_loop
from systemgen.commands.questions import ask_format
from systemgen.profiles.store import list_profiles, load_profile, save_profile


@click.command("update")
@click.option("--profile", "profile_name", default=None, help="Profile name to update.")
def update_cmd(profile_name):
    """Show current profile, then full re-run, field-by-field edits, or cancel."""
    profiles = list_profiles()

    if not profiles:
        click.echo("\n✗ No profiles found. Run `systemgen init` first.\n")
        return

    if not profile_name:
        profile_name = questionary.select(
            "Select a profile to update:",
            choices=[p["name"] for p in profiles],
        ).ask()

    existing = load_profile(profile_name)
    if not existing:
        click.echo(f"\n✗ Profile '{profile_name}' not found.\n")
        return

    project = existing.get("project") or {}
    database = existing.get("database") or {}
    auth = existing.get("auth") or {}
    validation = existing.get("validation") or {}
    conventions = existing.get("conventions") or {}

    click.echo("\nCurrent profile values:")
    click.echo(f"  framework:      {project.get('framework')}")
    click.echo(f"  language:       {project.get('language')}")
    click.echo(f"  database:       {database.get('engine')}")
    click.echo(f"  orm:            {database.get('orm')}")
    click.echo(f"  auth:           {auth.get('method')}")
    click.echo(f"  validation:     {validation.get('library')}")
    click.echo(f"  language ver:   {project.get('language_version')}")
    click.echo(f"  conventions:    {conventions.get('notes')}")
    click.echo("")

    action = questionary.select(
        "What would you like to do?",
        choices=[
            "Edit specific fields",
            "Full re-run",
            "Cancel",
        ],
    ).ask()

    if action == "Cancel":
        click.echo("No changes made.")
        return

    if action == "Edit specific fields":
        run_field_edit_loop(existing)
        fmt = ask_format()
        paths = save_profile(profile_name, existing, fmt)
        click.echo("")
        for path in paths:
            click.echo(f"✓ Profile updated: {path}")
        return

    data = collect_profile_data(current_profile=existing)
    fmt = ask_format()

    paths = save_profile(profile_name, data, fmt)
    click.echo("")
    for path in paths:
        click.echo(f"✓ Profile updated: {path}")
