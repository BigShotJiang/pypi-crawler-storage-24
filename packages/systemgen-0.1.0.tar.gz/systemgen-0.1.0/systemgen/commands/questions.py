from pathlib import Path

import click
import questionary

CUSTOM = "Custom"
NONE = "None"

# singleton: kwarg omitted vs explicitly passing None (means "None" option when updating)
_MISSING = object()

_ASYNC_ORMS = {
    "SQLAlchemy (async)": ("sqlalchemy", "async"),
}

_ORM_NORMALISE = {
    "SQLAlchemy (async)": "sqlalchemy",
    "Tortoise ORM": "tortoise",
    "Raw SQL": "raw",
}

_LANGUAGE_LABEL_TO_STORED = {
    "Python": "python",
    "TypeScript": "typescript",
    "Dart": "dart",
    "JavaScript": "javascript",
    "Go": "go",
    "Rust": "rust",
}

_STORED_TO_LANGUAGE_LABEL = {v: k for k, v in _LANGUAGE_LABEL_TO_STORED.items()}

_ORM_OPTIONS = ["SQLAlchemy (async)", "Tortoise ORM", "Raw SQL"]


def _default_language_label_for_framework(framework: str | None) -> str:
    fw = (framework or "").lower()
    if fw == "flutter":
        return "Dart"
    if fw in ("next.js", "nextjs", "react"):
        return "TypeScript"
    return "Python"


def _orm_select_default(orm: str | None, mode: str | None) -> tuple[str, str]:
    # (select default, prefilled text when choice is custom)
    if orm is None and mode is None:
        return NONE, ""
    if orm == "sqlalchemy" and mode == "async":
        return "SQLAlchemy (async)", ""
    if orm == "tortoise":
        return "Tortoise ORM", ""
    if orm == "raw":
        return "Raw SQL", ""
    return CUSTOM, orm or ""


def ask_with_custom(
    question: str,
    options: list[str],
    *,
    current=_MISSING,
) -> str | None:
    choices = options + [CUSTOM, NONE]
    select_kwargs = {}
    text_default = ""

    if current is not _MISSING:
        if current is None:
            select_kwargs["default"] = NONE
        else:
            cur = (current or "").strip()
            matched = next((c for c in options if c.lower() == cur.lower()), None)
            if matched is not None:
                select_kwargs["default"] = matched
            elif cur in choices:
                select_kwargs["default"] = cur
            else:
                select_kwargs["default"] = CUSTOM
                text_default = cur

    answer = questionary.select(question, choices=choices, **select_kwargs).ask()

    if answer == NONE:
        return None
    if answer == CUSTOM:
        custom = questionary.text("Enter value:", default=text_default).ask()
        return custom.strip() if custom else None
    return answer


def ask_project_name(*, current=_MISSING) -> str:
    default = "" if current is _MISSING else (current or "")
    return questionary.text("Project name:", default=default).ask().strip()


def ask_project_type(*, current=_MISSING) -> str | None:
    return ask_with_custom(
        "Project type:",
        ["Backend API", "Frontend", "CLI Tool", "Full Stack", "Data Pipeline"],
        current=current,
    )


def ask_framework(*, current=_MISSING) -> str | None:
    return ask_with_custom(
        "Framework:",
        ["FastAPI", "Django", "Flask", "Express", "Next.js"],
        current=current,
    )


def ask_language(framework: str | None, *, current=_MISSING) -> str | None:
    options = list(_LANGUAGE_LABEL_TO_STORED.keys())
    choices = options + [CUSTOM, NONE]
    select_kwargs = {}
    text_default = ""

    if current is _MISSING:
        select_kwargs["default"] = _default_language_label_for_framework(framework)
    elif current is None:
        select_kwargs["default"] = NONE
    else:
        stored = (current or "").strip().lower()
        label = _STORED_TO_LANGUAGE_LABEL.get(stored)
        if label is not None:
            select_kwargs["default"] = label
        else:
            select_kwargs["default"] = CUSTOM
            text_default = current or ""

    answer = questionary.select("Language:", choices=choices, **select_kwargs).ask()

    if answer == NONE:
        return None
    if answer == CUSTOM:
        custom = questionary.text("Enter value:", default=text_default).ask()
        if not custom or not custom.strip():
            return None
        return custom.strip().lower()
    return _LANGUAGE_LABEL_TO_STORED[answer]


def ask_database(*, current=_MISSING) -> str | None:
    return ask_with_custom(
        "Database:",
        ["PostgreSQL", "MySQL", "SQLite", "MongoDB"],
        current=current,
    )


def ask_orm(*, current=_MISSING) -> tuple[str | None, str | None]:
    choices = _ORM_OPTIONS + [CUSTOM, NONE]
    select_kwargs = {}
    text_default = ""

    if current is not _MISSING:
        orm, mode = current if isinstance(current, tuple) and len(current) == 2 else (None, None)
        default_choice, text_default = _orm_select_default(orm, mode)
        select_kwargs["default"] = default_choice

    answer = questionary.select(
        "ORM / query layer:",
        choices=choices,
        **select_kwargs,
    ).ask()

    if answer == NONE:
        return None, None
    if answer == CUSTOM:
        custom = questionary.text("Enter value:", default=text_default).ask()
        if not custom or not custom.strip():
            return None, None
        c = custom.strip().lower()
        return c, None
    if answer in _ASYNC_ORMS:
        pair = _ASYNC_ORMS[answer]
        return pair[0], pair[1]
    normalised = _ORM_NORMALISE.get(answer, answer.lower())
    return normalised, None


def ask_auth(*, current=_MISSING) -> str | None:
    return ask_with_custom(
        "Authentication:",
        ["JWT", "OAuth2", "API Key"],
        current=current,
    )


def ask_validation(*, current=_MISSING) -> str | None:
    return ask_with_custom(
        "Validation library:",
        ["Pydantic v2", "Marshmallow", "Cerberus"],
        current=current,
    )


def ask_test_convention(*, current=_MISSING) -> str | None:
    return ask_with_custom(
        "Test folder convention:",
        ["Mirror app structure", "Flat"],
        current=current,
    )


def ask_language_version(*, current=_MISSING) -> str:
    default = "" if current is _MISSING else (current or "")
    return questionary.text(
        "Preferred language version (e.g. 3.11):",
        default=default,
    ).ask().strip()


def ask_conventions(*, current=_MISSING) -> str | None:
    default = "" if current is _MISSING else (current or "")
    answer = questionary.text(
        "Any naming conventions? (leave blank to skip):",
        default=default,
    ).ask().strip()
    return answer if answer else None


def ask_profile_name(*, current=_MISSING) -> str:
    default = "" if current is _MISSING else (current or "")
    return questionary.text("Save as profile name:", default=default).ask().strip()


def ask_format() -> str:
    return questionary.select(
        "Where will you use this profile?",
        choices=[
            "Terminal (Claude Code, Ollama) — saves as TOML",
            "IDE (Cursor, Windsurf, Copilot) — saves as JSON",
            "Both",
        ],
    ).ask()


def ask_structure(framework: str | None, *, current=_MISSING) -> dict:
    defaults = _structure_defaults(framework)
    prev = {}
    if current is not _MISSING and current:
        prev = {k: v for k, v in current.items() if k != "test_convention"}

    ordered_keys = list(defaults.keys())
    key_defaults = {k: prev.get(k, defaults[k]) for k in ordered_keys}
    for k in sorted(prev.keys()):
        if k not in key_defaults:
            ordered_keys.append(k)
            key_defaults[k] = prev[k]

    click.echo("\nDefine your folder structure (leave blank to skip a folder):")

    paths = {}
    for key in ordered_keys:
        answer = questionary.text(
            f"  {key}/ path:",
            default=key_defaults[key],
        ).ask()
        if answer and answer.strip():
            paths[key] = answer.strip()

    while True:
        extra = questionary.text(
            "  Add another folder? (enter label or leave blank to finish):"
        ).ask().strip()
        if not extra:
            break
        path = questionary.text(f"  {extra}/ path:").ask().strip()
        if path:
            paths[extra] = path

    return paths


def _structure_defaults(framework: str | None) -> dict:
    fw = (framework or "").lower()
    if fw in ("fastapi", "flask", "litestar", "django"):
        return {
            "routers": "app/routers/",
            "services": "app/services/",
            "models": "app/models/",
            "schemas": "app/schemas/",
            "tests": "tests/",
        }
    if fw in ("next.js", "nextjs", "react"):
        return {
            "components": "components/",
            "pages": "app/",
            "lib": "lib/",
            "tests": "__tests__/",
        }
    if fw == "flutter":
        return {
            "screens": "lib/screens/",
            "widgets": "lib/widgets/",
            "services": "lib/services/",
            "models": "lib/models/",
            "tests": "test/",
        }
    return {
        "src": "src/",
        "tests": "tests/",
    }


def ask_prompt_input() -> tuple[str | None, str | None]:
    choice = questionary.select(
        "How do you want to provide your build prompt?",
        choices=[
            "Type it now",
            "Load from a text file",
            "Skip — I'll write the prompt in my AI tool",
        ],
    ).ask()

    if choice == "Type it now":
        text = questionary.text("What do you want to build?").ask().strip()
        return text or None, None

    if choice == "Load from a text file":
        while True:
            path_str = questionary.text(
                "Path to prompt file (.txt or .md):"
            ).ask().strip()
            path = Path(path_str)
            if path.exists() and path.is_file():
                return path.read_text(encoding="utf-8").strip(), str(path)
            click.echo(f"✗ File not found: {path_str}. Please try again.")

    return None, None
