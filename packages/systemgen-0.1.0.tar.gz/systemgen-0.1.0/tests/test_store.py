import json

from systemgen.profiles.store import (
    _clean,
    delete_profile,
    load_profile,
    save_profile,
)


def test_clean_strips_none_and_empty_strings():
    dirty = {
        "a": 1,
        "b": None,
        "c": "",
        "nested": {"x": None, "y": "ok", "z": ""},
    }
    assert _clean(dirty) == {"a": 1, "nested": {"y": "ok"}}


def test_load_missing_returns_none(profiles_dir):
    assert load_profile("nope") is None


def test_save_toml_round_trip(profiles_dir):
    data = {"project": {"name": "p", "language": "python"}}
    save_profile(
        "t",
        data,
        "Terminal (Claude Code, Ollama) — saves as TOML",
    )
    assert load_profile("t") == data


def test_save_json_round_trip(profiles_dir):
    data = {"project": {"name": "p"}, "database": {"engine": "PostgreSQL"}}
    save_profile(
        "j",
        data,
        "IDE (Cursor, Windsurf, Copilot) — saves as JSON",
    )
    assert load_profile("j") == data


def test_json_on_disk_has_cleaned_nested_none(profiles_dir):
    data = {"project": {"name": "x", "type": None}}
    save_profile(
        "empty",
        data,
        "IDE (Cursor, Windsurf, Copilot) — saves as JSON",
    )
    raw = json.loads((profiles_dir / "empty.json").read_text(encoding="utf-8"))
    assert "type" not in raw["project"]


def test_delete_toml_only_leaves_json(profiles_dir):
    data = {"project": {"name": "d"}}
    save_profile("d", data, "Both")
    deleted = delete_profile("d", "TOML only")
    assert len(deleted) == 1
    assert not (profiles_dir / "d.toml").exists()
    assert (profiles_dir / "d.json").exists()
