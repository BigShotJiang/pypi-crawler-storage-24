from systemgen.prompts.renderer import render_prompt


def test_full_profile_renders_core_sections():
    profile = {
        "project": {
            "type": "Backend API",
            "framework": "FastAPI",
            "language": "python",
            "language_version": "3.11",
        },
        "database": {"engine": "PostgreSQL", "orm": "sqlalchemy", "mode": "async"},
        "auth": {"method": "JWT"},
        "validation": {"library": "Pydantic v2"},
        "structure": {
            "routers": "app/routers/",
            "tests": "tests/",
            "test_convention": "Mirror app structure",
        },
        "conventions": {"notes": "use snake_case"},
    }
    out = render_prompt(profile, "add a health check endpoint")
    assert "FastAPI" in out and "Python" in out and "3.11" in out
    assert "PostgreSQL" in out and "sqlalchemy" in out and "async" in out
    assert "JWT" in out and "Pydantic" in out
    assert "app/routers/" in out
    assert "mirror app structure" in out
    assert out.count("- tests/") == 1
    assert "snake_case" in out
    assert "Build the following: add a health check endpoint" in out


def test_missing_optional_sections_omitted():
    profile = {
        "project": {
            "type": "CLI Tool",
            "framework": "Click",
            "language": "python",
            "language_version": "3.11",
        },
        "structure": {},
    }
    out = render_prompt(profile, None)
    assert "Authentication" not in out
    assert "validation" not in out.lower()
    assert "Build the following" not in out


def test_none_user_prompt_omits_build_line():
    profile = {
        "project": {
            "type": "Backend API",
            "framework": "Django",
            "language": "python",
            "language_version": "3.11",
        },
        "database": {"engine": "PostgreSQL"},
    }
    out = render_prompt(profile, None)
    assert "Build the following" not in out


def test_structure_section_lists_paths_and_test_convention():
    profile = {
        "project": {
            "type": "Backend API",
            "framework": "FastAPI",
            "language": "python",
            "language_version": "3.11",
        },
        "structure": {
            "services": "app/services/",
            "test_convention": "Flat",
        },
    }
    out = render_prompt(profile, "task")
    assert "\nStructure the project as follows:" in out
    assert "- app/services/" in out
    assert "- tests/" in out
    assert "flat" in out
