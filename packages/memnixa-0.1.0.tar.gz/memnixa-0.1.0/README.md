# Memnixa Docs

- [中文文档](README.zh-CN.md)
- [English Docs](README.en.md)

## 中文

这是 Memnixa 的双语文档入口页。

- 项目总览与使用说明：[`README.zh-CN.md`](README.zh-CN.md)
- 架构说明：[`docs/architecture.zh-CN.md`](docs/architecture.zh-CN.md)

## English

This is the bilingual documentation index for Memnixa.

- Project overview and usage guide: [`README.en.md`](README.en.md)
- Architecture guide: [`docs/architecture.en.md`](docs/architecture.en.md)
