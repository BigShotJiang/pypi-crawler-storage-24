from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from memnixa.runtime_env import detect_runtime_execution


class RuntimeEnvTests(unittest.TestCase):
    def test_detect_runtime_execution_prefers_source_tree_for_project_venv(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            project_root = Path(temp_dir)
            (project_root / "pyproject.toml").write_text("[project]\nname='demo'\n")
            package_root = project_root / "src" / "memnixa"
            package_root.mkdir(parents=True)

            info = self._detect(
                package_root=package_root,
                entrypoint_path=project_root / ".venv" / "bin" / "memnixa",
                python_executable=project_root / ".venv" / "bin" / "python",
                dist_info_path=project_root
                / ".venv"
                / "lib"
                / "python3.13"
                / "site-packages"
                / "memnixa-0.1.0.dist-info",
                direct_url={
                    "url": f"file://{project_root}",
                    "dir_info": {"editable": True},
                },
            )

        self.assertEqual(info.runtime_mode, "development")
        self.assertEqual(info.install_mode, "source_tree")

    def test_detect_runtime_execution_marks_editable_tool_install(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            project_root = Path(temp_dir)
            (project_root / "pyproject.toml").write_text("[project]\nname='demo'\n")
            package_root = project_root / "src" / "memnixa"
            package_root.mkdir(parents=True)

            info = self._detect(
                package_root=package_root,
                entrypoint_path=Path("/home/demo/.local/bin/memnixa"),
                python_executable=Path(
                    "/home/demo/.local/share/uv/tools/memnixa/bin/python"
                ),
                dist_info_path=Path(
                    "/home/demo/.local/share/uv/tools/memnixa/lib/python3.13/site-packages/memnixa-0.1.0.dist-info"
                ),
                direct_url={
                    "url": f"file://{project_root}",
                    "dir_info": {"editable": True},
                },
            )

        self.assertEqual(info.runtime_mode, "installed")
        self.assertEqual(info.install_mode, "editable")

    def test_detect_runtime_execution_marks_standard_install(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            project_root = Path(temp_dir)
            (project_root / "pyproject.toml").write_text("[project]\nname='demo'\n")
            package_root = project_root / "src" / "memnixa"
            package_root.mkdir(parents=True)

            info = self._detect(
                package_root=package_root,
                entrypoint_path=Path("/usr/local/bin/memnixa"),
                python_executable=Path("/usr/bin/python3.13"),
                dist_info_path=Path(
                    "/usr/lib/python3.13/site-packages/memnixa-0.1.0.dist-info"
                ),
                direct_url=None,
            )

        self.assertEqual(info.runtime_mode, "installed")
        self.assertEqual(info.install_mode, "standard")

    @staticmethod
    def _detect(
        *,
        package_root: Path,
        entrypoint_path: Path,
        python_executable: Path,
        dist_info_path: Path,
        direct_url: dict[str, object] | None,
    ):
        with patch(
            "memnixa.runtime_env._load_distribution_metadata",
            return_value=(str(dist_info_path), direct_url),
        ):
            return detect_runtime_execution(
                package_root=package_root,
                entrypoint_path=str(entrypoint_path),
                python_executable=str(python_executable),
            )


if __name__ == "__main__":
    unittest.main()
