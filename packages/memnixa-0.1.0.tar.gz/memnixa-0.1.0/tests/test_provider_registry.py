from __future__ import annotations

import unittest

from memnixa.providers.registry import get_provider_spec


class ProviderRegistryTests(unittest.TestCase):
    def test_zhipu_coding_plan_preset_exists(self) -> None:
        spec = get_provider_spec("zhipu_coding_plan")
        self.assertEqual(
            spec.default_base_url, "https://open.bigmodel.cn/api/coding/paas/v4"
        )
        self.assertEqual(spec.default_model, "glm-4.7")

    def test_siliconflow_preset_exists(self) -> None:
        spec = get_provider_spec("siliconflow")
        self.assertEqual(spec.default_base_url, "https://api.siliconflow.cn/v1")
        self.assertEqual(spec.default_model, "deepseek-ai/DeepSeek-V3")


if __name__ == "__main__":
    unittest.main()
