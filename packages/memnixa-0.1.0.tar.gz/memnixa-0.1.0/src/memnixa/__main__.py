from memnixa.gateway.cli import main


if __name__ == "__main__":
    main()
