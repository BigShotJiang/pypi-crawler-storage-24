"""Provider abstractions."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass

from memnixa.models import LLMResponse


@dataclass(frozen=True, slots=True)
class ProviderSpec:
    """Provider preset metadata."""

    name: str
    label: str
    default_base_url: str
    default_model: str
    default_context_window_tokens: int | None = None
    default_max_output_tokens: int | None = None


class LLMProvider(ABC):
    """Normalized provider interface."""

    @abstractmethod
    def chat(
        self, messages: list[dict], tools: list[dict] | None = None
    ) -> LLMResponse:
        """Execute one chat completion call."""

    def estimate_prompt_tokens(
        self, messages: list[dict], tools: list[dict] | None = None
    ) -> tuple[int, str] | None:
        """Estimate prompt usage for one request if supported."""
        return None

    @property
    @abstractmethod
    def model_name(self) -> str:
        """Resolved model identifier."""
