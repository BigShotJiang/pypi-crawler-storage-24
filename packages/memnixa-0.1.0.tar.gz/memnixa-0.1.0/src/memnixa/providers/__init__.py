"""Provider helpers."""

from __future__ import annotations

from typing import TYPE_CHECKING

from memnixa.config import ProviderConfig
from memnixa.providers.manager import ProviderManager
from memnixa.providers.registry import get_provider_spec

if TYPE_CHECKING:
    from memnixa.providers.openai_compatible import OpenAICompatibleProvider


def build_provider(
    profile: ProviderConfig, *, timeout: int = 120
) -> OpenAICompatibleProvider:
    """Build one configured provider client."""
    from memnixa.providers.openai_compatible import OpenAICompatibleProvider

    spec = get_provider_spec(profile.preset)
    return OpenAICompatibleProvider(
        spec=spec,
        api_key=profile.api_key,
        api_base=profile.api_base or spec.default_base_url,
        _model_name=profile.model or spec.default_model,
        timeout=timeout,
    )


__all__ = ["ProviderManager", "build_provider"]
