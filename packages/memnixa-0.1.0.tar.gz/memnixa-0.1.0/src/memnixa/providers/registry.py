"""Provider registry."""

from __future__ import annotations

from memnixa.providers.base import ProviderSpec


PROVIDERS: dict[str, ProviderSpec] = {
    "openai_chatgpt": ProviderSpec(
        name="openai_chatgpt",
        label="OpenAI ChatGPT",
        default_base_url="https://api.openai.com/v1",
        default_model="gpt-4.1-mini",
        default_context_window_tokens=128000,
        default_max_output_tokens=8192,
    ),
    "zhipu_coding_plan": ProviderSpec(
        name="zhipu_coding_plan",
        label="Zhipu Coding Plan",
        default_base_url="https://open.bigmodel.cn/api/coding/paas/v4",
        default_model="glm-4.7",
        default_context_window_tokens=128000,
        default_max_output_tokens=8192,
    ),
    "siliconflow": ProviderSpec(
        name="siliconflow",
        label="SiliconFlow",
        default_base_url="https://api.siliconflow.cn/v1",
        default_model="deepseek-ai/DeepSeek-V3",
        default_context_window_tokens=128000,
        default_max_output_tokens=8192,
    ),
    "custom_openai_compatible": ProviderSpec(
        name="custom_openai_compatible",
        label="Custom OpenAI-Compatible",
        default_base_url="http://localhost:8000/v1",
        default_model="default",
        default_context_window_tokens=16384,
        default_max_output_tokens=4096,
    ),
}


def list_provider_specs() -> list[ProviderSpec]:
    """Return all built-in provider presets."""
    return list(PROVIDERS.values())


def get_provider_spec(name: str) -> ProviderSpec:
    """Return a provider preset by name."""
    try:
        return PROVIDERS[name]
    except KeyError as exc:
        available = ", ".join(sorted(PROVIDERS))
        raise ValueError(
            f"unknown provider '{name}', expected one of: {available}"
        ) from exc
