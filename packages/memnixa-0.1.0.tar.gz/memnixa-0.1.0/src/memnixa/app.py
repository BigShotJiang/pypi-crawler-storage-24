"""Shared application builders."""

from __future__ import annotations

from dataclasses import dataclass

from memnixa.agent import AgentRuntime
from memnixa.config import AppConfig
from memnixa.context import ContextBuilder
from memnixa.providers import ProviderManager
from memnixa.session import SessionStore
from memnixa.tools import build_default_tool_registry


@dataclass(slots=True)
class MemnixaApp:
    """Resolved application dependencies."""

    config: AppConfig
    runtime: AgentRuntime


def build_app(config: AppConfig) -> MemnixaApp:
    """Build a runtime app from config."""
    runtime = AgentRuntime(
        config=config,
        providers=ProviderManager(config),
        session=SessionStore(config.storage_path),
        tools=build_default_tool_registry(
            config.workspace,
            jina_api_key=config.jina_api_key,
            request_timeout=config.request_timeout,
        ),
        context_builder=ContextBuilder(config),
    )
    return MemnixaApp(config=config, runtime=runtime)
