"""Shared runtime models."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(slots=True)
class ToolCall:
    """Model-emitted tool call."""

    id: str
    name: str
    arguments: dict[str, Any]

    def as_openai_payload(self) -> dict[str, Any]:
        """Return OpenAI-style tool call payload for assistant messages."""
        import json

        return {
            "id": self.id,
            "type": "function",
            "function": {
                "name": self.name,
                "arguments": json.dumps(self.arguments, ensure_ascii=False),
            },
        }


@dataclass(slots=True)
class LLMResponse:
    """Normalized LLM output."""

    content: str | None = None
    tool_calls: list[ToolCall] = field(default_factory=list)
    finish_reason: str = "stop"
    usage: dict[str, Any] | None = None
    raw: dict[str, Any] | None = None

    @property
    def has_tool_calls(self) -> bool:
        return bool(self.tool_calls)


@dataclass(slots=True)
class RunTurnResult:
    """One user turn execution result."""

    reply: str
    iterations: int
    tool_events: list[dict[str, Any]] = field(default_factory=list)
    runtime_events: list[dict[str, Any]] = field(default_factory=list)
    provider_id: str | None = None
    provider_label: str | None = None
    model_name: str | None = None
