"""Built-in tools."""

from pathlib import Path

from memnixa.tools.base import ToolRegistry
from memnixa.tools.filesystem import ListDirTool, ReadFileTool, WriteFileTool
from memnixa.tools.shell import RunCommandTool
from memnixa.tools.web import ReadUrlTool, SearchWebTool


def build_default_tool_registry(
    workspace: Path,
    *,
    jina_api_key: str = "",
    request_timeout: int = 120,
) -> ToolRegistry:
    """Create the default tool registry."""
    registry = ToolRegistry()
    registry.register(ListDirTool(workspace))
    registry.register(ReadFileTool(workspace))
    registry.register(WriteFileTool(workspace))
    registry.register(RunCommandTool(workspace))
    registry.register(ReadUrlTool(api_key=jina_api_key, timeout=request_timeout))
    registry.register(SearchWebTool(api_key=jina_api_key, timeout=request_timeout))
    return registry
