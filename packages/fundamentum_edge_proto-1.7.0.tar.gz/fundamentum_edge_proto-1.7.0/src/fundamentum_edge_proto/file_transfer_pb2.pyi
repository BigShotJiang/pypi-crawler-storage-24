from google.protobuf import empty_pb2 as _empty_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ActionId(_message.Message):
    __slots__ = ("id",)
    ID_FIELD_NUMBER: _ClassVar[int]
    id: int
    def __init__(self, id: _Optional[int] = ...) -> None: ...

class FileTransferRequest(_message.Message):
    __slots__ = ("action_id", "serial_numbers", "download", "upload")
    class Download(_message.Message):
        __slots__ = ("file_path", "size", "hash", "overwrite", "metadata")
        FILE_PATH_FIELD_NUMBER: _ClassVar[int]
        SIZE_FIELD_NUMBER: _ClassVar[int]
        HASH_FIELD_NUMBER: _ClassVar[int]
        OVERWRITE_FIELD_NUMBER: _ClassVar[int]
        METADATA_FIELD_NUMBER: _ClassVar[int]
        file_path: str
        size: int
        hash: str
        overwrite: bool
        metadata: str
        def __init__(self, file_path: _Optional[str] = ..., size: _Optional[int] = ..., hash: _Optional[str] = ..., overwrite: bool = ..., metadata: _Optional[str] = ...) -> None: ...
    class Upload(_message.Message):
        __slots__ = ("file_path",)
        FILE_PATH_FIELD_NUMBER: _ClassVar[int]
        file_path: str
        def __init__(self, file_path: _Optional[str] = ...) -> None: ...
    ACTION_ID_FIELD_NUMBER: _ClassVar[int]
    SERIAL_NUMBERS_FIELD_NUMBER: _ClassVar[int]
    DOWNLOAD_FIELD_NUMBER: _ClassVar[int]
    UPLOAD_FIELD_NUMBER: _ClassVar[int]
    action_id: ActionId
    serial_numbers: _containers.RepeatedScalarFieldContainer[str]
    download: FileTransferRequest.Download
    upload: FileTransferRequest.Upload
    def __init__(self, action_id: _Optional[_Union[ActionId, _Mapping]] = ..., serial_numbers: _Optional[_Iterable[str]] = ..., download: _Optional[_Union[FileTransferRequest.Download, _Mapping]] = ..., upload: _Optional[_Union[FileTransferRequest.Upload, _Mapping]] = ...) -> None: ...

class DownloadFileRequest(_message.Message):
    __slots__ = ("action_id", "chunk_size")
    ACTION_ID_FIELD_NUMBER: _ClassVar[int]
    CHUNK_SIZE_FIELD_NUMBER: _ClassVar[int]
    action_id: ActionId
    chunk_size: int
    def __init__(self, action_id: _Optional[_Union[ActionId, _Mapping]] = ..., chunk_size: _Optional[int] = ...) -> None: ...

class DownloadFileResponse(_message.Message):
    __slots__ = ("chunk",)
    CHUNK_FIELD_NUMBER: _ClassVar[int]
    chunk: FileChunk
    def __init__(self, chunk: _Optional[_Union[FileChunk, _Mapping]] = ...) -> None: ...

class FileChunk(_message.Message):
    __slots__ = ("index", "data")
    INDEX_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    index: int
    data: bytes
    def __init__(self, index: _Optional[int] = ..., data: _Optional[bytes] = ...) -> None: ...

class UploadFileRequest(_message.Message):
    __slots__ = ("header", "chunk")
    class Header(_message.Message):
        __slots__ = ("action_id", "size", "hash")
        ACTION_ID_FIELD_NUMBER: _ClassVar[int]
        SIZE_FIELD_NUMBER: _ClassVar[int]
        HASH_FIELD_NUMBER: _ClassVar[int]
        action_id: ActionId
        size: int
        hash: str
        def __init__(self, action_id: _Optional[_Union[ActionId, _Mapping]] = ..., size: _Optional[int] = ..., hash: _Optional[str] = ...) -> None: ...
    class Chunk(_message.Message):
        __slots__ = ("inner",)
        INNER_FIELD_NUMBER: _ClassVar[int]
        inner: FileChunk
        def __init__(self, inner: _Optional[_Union[FileChunk, _Mapping]] = ...) -> None: ...
    HEADER_FIELD_NUMBER: _ClassVar[int]
    CHUNK_FIELD_NUMBER: _ClassVar[int]
    header: UploadFileRequest.Header
    chunk: UploadFileRequest.Chunk
    def __init__(self, header: _Optional[_Union[UploadFileRequest.Header, _Mapping]] = ..., chunk: _Optional[_Union[UploadFileRequest.Chunk, _Mapping]] = ...) -> None: ...

class FileTransferStatus(_message.Message):
    __slots__ = ("action_id", "serial_number", "message", "ongoing", "success", "error")
    class OngoingStatus(_message.Message):
        __slots__ = ("progress",)
        PROGRESS_FIELD_NUMBER: _ClassVar[int]
        progress: float
        def __init__(self, progress: _Optional[float] = ...) -> None: ...
    class SuccessStatus(_message.Message):
        __slots__ = ()
        def __init__(self) -> None: ...
    class ErrorStatus(_message.Message):
        __slots__ = ("code",)
        class Code(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
            __slots__ = ()
            CODE_UNSPECIFIED: _ClassVar[FileTransferStatus.ErrorStatus.Code]
            CODE_DOWNLOAD_NOT_SUPPORTED: _ClassVar[FileTransferStatus.ErrorStatus.Code]
            CODE_UPLOAD_NOT_SUPPORTED: _ClassVar[FileTransferStatus.ErrorStatus.Code]
            CODE_NO_ENOUGH_STORAGE: _ClassVar[FileTransferStatus.ErrorStatus.Code]
            CODE_REJECTED: _ClassVar[FileTransferStatus.ErrorStatus.Code]
        CODE_UNSPECIFIED: FileTransferStatus.ErrorStatus.Code
        CODE_DOWNLOAD_NOT_SUPPORTED: FileTransferStatus.ErrorStatus.Code
        CODE_UPLOAD_NOT_SUPPORTED: FileTransferStatus.ErrorStatus.Code
        CODE_NO_ENOUGH_STORAGE: FileTransferStatus.ErrorStatus.Code
        CODE_REJECTED: FileTransferStatus.ErrorStatus.Code
        CODE_FIELD_NUMBER: _ClassVar[int]
        code: FileTransferStatus.ErrorStatus.Code
        def __init__(self, code: _Optional[_Union[FileTransferStatus.ErrorStatus.Code, str]] = ...) -> None: ...
    ACTION_ID_FIELD_NUMBER: _ClassVar[int]
    SERIAL_NUMBER_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    ONGOING_FIELD_NUMBER: _ClassVar[int]
    SUCCESS_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    action_id: ActionId
    serial_number: _containers.RepeatedScalarFieldContainer[str]
    message: str
    ongoing: FileTransferStatus.OngoingStatus
    success: FileTransferStatus.SuccessStatus
    error: FileTransferStatus.ErrorStatus
    def __init__(self, action_id: _Optional[_Union[ActionId, _Mapping]] = ..., serial_number: _Optional[_Iterable[str]] = ..., message: _Optional[str] = ..., ongoing: _Optional[_Union[FileTransferStatus.OngoingStatus, _Mapping]] = ..., success: _Optional[_Union[FileTransferStatus.SuccessStatus, _Mapping]] = ..., error: _Optional[_Union[FileTransferStatus.ErrorStatus, _Mapping]] = ...) -> None: ...
