from google.protobuf import empty_pb2 as _empty_pb2
from fundamentum_edge_proto import qos_pb2 as _qos_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class SubDeviceHeartbeat(_message.Message):
    __slots__ = ("serial_number", "uptime")
    SERIAL_NUMBER_FIELD_NUMBER: _ClassVar[int]
    UPTIME_FIELD_NUMBER: _ClassVar[int]
    serial_number: str
    uptime: int
    def __init__(self, serial_number: _Optional[str] = ..., uptime: _Optional[int] = ...) -> None: ...

class HeartbeatRequest(_message.Message):
    __slots__ = ("uptime", "sub_devices", "qos")
    UPTIME_FIELD_NUMBER: _ClassVar[int]
    SUB_DEVICES_FIELD_NUMBER: _ClassVar[int]
    QOS_FIELD_NUMBER: _ClassVar[int]
    uptime: int
    sub_devices: _containers.RepeatedCompositeFieldContainer[SubDeviceHeartbeat]
    qos: _qos_pb2.Qos
    def __init__(self, uptime: _Optional[int] = ..., sub_devices: _Optional[_Iterable[_Union[SubDeviceHeartbeat, _Mapping]]] = ..., qos: _Optional[_Union[_qos_pb2.Qos, str]] = ...) -> None: ...
