"""Compile proto files with patched imports for Python package structure."""

import shutil
import subprocess
import tempfile
from pathlib import Path

PROTO_FILES = [
    "fundamentum_edge_proto/actions.proto",
    "fundamentum_edge_proto/configuration.proto",
    "fundamentum_edge_proto/file_transfer.proto",
    "fundamentum_edge_proto/heartbeat.proto",
    "fundamentum_edge_proto/provisioning.proto",
    "fundamentum_edge_proto/qos.proto",
    "fundamentum_edge_proto/states.proto",
    "fundamentum_edge_proto/telemetry.proto",
    "fundamentum_edge_proto/update.proto",
]


def main() -> None:
    project_root = Path(__file__).parent
    proto_src = project_root / "proto"
    output_dir = project_root / "src"

    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_proto = Path(tmp_dir) / "proto"

        # Copy proto files to temp directory (preserving proto/fundamentum_edge_proto structure)
        shutil.copytree(proto_src, tmp_proto)

        # Patch imports in temp copies
        for proto_file in tmp_proto.glob("fundamentum_edge_proto/*.proto"):
            content = proto_file.read_text()
            patched = content.replace('import "qos.proto"', 'import "fundamentum_edge_proto/qos.proto"')
            proto_file.write_text(patched)

        # Compile protos
        subprocess.run(  # noqa: S603
            [  # noqa: S607
                "uv",
                "run",
                "python",
                "-m",
                "grpc_tools.protoc",
                f"--proto_path={tmp_proto}",
                f"--python_out={output_dir}",
                f"--pyi_out={output_dir}",
                f"--grpc_python_out={output_dir}",
                f"--mypy_grpc_out={output_dir}",
                *PROTO_FILES,
            ],
            check=True,
        )


if __name__ == "__main__":
    main()
