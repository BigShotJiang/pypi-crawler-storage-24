"""MCP Trust Gateway — Trust verification for agent-tool connections."""
__version__ = "0.0.1"
