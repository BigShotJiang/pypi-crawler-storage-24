from __future__ import annotations

from typing import Any, Literal, TypedDict

ErrorType = Literal[
    "validation_error",
    "authentication_error",
    "authorization_error",
    "quota_exceeded",
    "not_found",
    "rate_limit_error",
    "conflict",
    "internal_error",
]

DOMAIN_STATUSES = ("pending", "verifying", "verified", "degraded", "failed")
DomainStatus = Literal["pending", "verifying", "verified", "degraded", "failed"]

MESSAGE_STATUSES = ("queued", "sent", "delivered", "bounced", "complained", "failed")
MessageStatus = Literal["queued", "sent", "delivered", "bounced", "complained", "failed"]

MESSAGE_SOURCES = ("api", "dashboard", "inbound", "smtp")
MessageSource = Literal["api", "dashboard", "inbound", "smtp"]

WEBHOOK_EVENT_TYPES = (
    "message.received",
    "message.sent",
    "message.delivered",
    "message.bounced",
    "message.complained",
    "domain.verified",
    "domain.verification_failed",
    "domain.degraded",
)
WebhookEventType = Literal[
    "message.received",
    "message.sent",
    "message.delivered",
    "message.bounced",
    "message.complained",
    "domain.verified",
    "domain.verification_failed",
    "domain.degraded",
]

WEBHOOK_DELIVERY_STATUSES = ("pending", "delivered", "failed")
WebhookDeliveryStatus = Literal["pending", "delivered", "failed"]


class PaginationParams(TypedDict, total=False):
    cursor: str
    limit: int


class Pagination(TypedDict):
    next_cursor: str | None
    has_more: bool


class PaginatedResponse(TypedDict):
    data: list[Any]
    pagination: Pagination


class EmailRecipient(TypedDict, total=False):
    address: str  # Required but total=False allows partial construction
    name: str | None


class ApiErrorDetail(TypedDict):
    field: str
    message: str


class ApiErrorInfo(TypedDict, total=False):
    type: str
    message: str
    request_id: str
    details: list[ApiErrorDetail]
    retry_after: int


class ApiErrorBody(TypedDict):
    error: ApiErrorInfo


class StatusResponse(TypedDict):
    status: str
    version: str
    time: str
    request_id: str


class MethodOptions(TypedDict, total=False):
    timeout: float
    headers: dict[str, str]
    idempotency_key: str


class ShipMailConfig(TypedDict, total=False):
    api_key: str
    base_url: str
    max_retries: int
    timeout: float
    default_headers: dict[str, str]
