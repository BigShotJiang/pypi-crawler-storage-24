from __future__ import annotations

from typing import Any, TypedDict

from .common import PaginationParams, WebhookDeliveryStatus, WebhookEventType


class Webhook(TypedDict):
    object: str
    id: str
    url: str
    events: list[str]
    active: bool
    description: str | None
    created_at: str
    updated_at: str


class WebhookWithSecret(Webhook):
    secret: str


class CreateWebhookParams(TypedDict, total=False):
    url: str
    events: list[WebhookEventType]
    description: str


class UpdateWebhookParams(TypedDict, total=False):
    url: str
    events: list[WebhookEventType]
    description: str | None
    active: bool


ListWebhooksParams = PaginationParams


class RotateSecretResponse(TypedDict):
    secret: str
    previous_secret_expires_at: str


class TestWebhookResponse(TypedDict):
    event_id: str


class WebhookDelivery(TypedDict):
    object: str
    id: str
    event_id: str
    event_type: str
    status: WebhookDeliveryStatus
    attempts: int
    last_status_code: int | None
    last_error: str | None
    created_at: str
    delivered_at: str | None


class ListDeliveriesParams(PaginationParams, total=False):
    status: str
    event_type: str


class WebhookEvent(TypedDict):
    event_id: str
    event_type: WebhookEventType
    created_at: str
    data: Any
