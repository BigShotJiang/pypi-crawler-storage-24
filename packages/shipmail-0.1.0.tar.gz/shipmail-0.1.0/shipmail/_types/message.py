from __future__ import annotations

from typing import Any, TypedDict

from .common import EmailRecipient, MessageSource, MessageStatus


class Message(TypedDict):
    object: str
    id: str
    mailbox_id: str
    thread_id: str | None
    subject: str | None
    from_address: str | None
    to_addresses: list[dict[str, Any]] | None
    cc_addresses: list[dict[str, Any]] | None
    bcc_addresses: list[dict[str, Any]] | None
    source: MessageSource
    status: MessageStatus
    created_at: str
    updated_at: str


class SendMessageParams(TypedDict, total=False):
    mailbox_id: str
    to: list[EmailRecipient]
    cc: list[EmailRecipient]
    bcc: list[EmailRecipient]
    reply_to: EmailRecipient
    subject: str
    body_html: str
    body_text: str
    in_reply_to: str
    references: list[str]
