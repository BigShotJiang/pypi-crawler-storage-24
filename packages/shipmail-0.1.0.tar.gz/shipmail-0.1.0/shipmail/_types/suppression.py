from __future__ import annotations

from typing import TypedDict

from .common import PaginationParams


class Suppression(TypedDict):
    object: str
    email_address: str
    reason: str
    created_at: str


class ListSuppressionsParams(PaginationParams, total=False):
    pass
