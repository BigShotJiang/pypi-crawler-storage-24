from __future__ import annotations

from typing import TypedDict

from .common import PaginationParams


class Mailbox(TypedDict):
    object: str
    id: str
    domain_id: str
    address: str
    display_name: str | None
    avatar_url: str | None
    created_at: str
    updated_at: str


class CreateMailboxParams(TypedDict, total=False):
    domain_id: str
    address: str
    display_name: str


class UpdateMailboxParams(TypedDict, total=False):
    display_name: str | None


class ListMailboxesParams(PaginationParams, total=False):
    domain_id: str


UploadAvatarResponse = Mailbox
