# Changelog

## 0.1.0 (Unreleased)

Initial release of the ShipMail Python SDK.

- Sync client (`ShipMail`) and async client (`AsyncShipMail`)
- All API resources: Domains, Mailboxes, Messages, Threads, Webhooks, Suppressions, Status
- Cursor-based auto-pagination (sync and async iterators)
- Webhook signature verification with HMAC-SHA256
- Typed error hierarchy matching API error responses
- Automatic retries with exponential backoff on 5xx and 429 responses
- Context manager support for client lifecycle
- PEP 561 typed package
