"""
CostWise MCP SDK — Managed Cost Policy for AI workloads.

Automatically reduces AI costs by classifying task complexity and
selecting the cheapest model that can handle the task.

Usage:
    from costwise_mcp import CostPolicy

    policy = CostPolicy(api_key="cw_...")

    decision = policy.optimize(
        prompt="Translate 'hello' to French",
        model="gpt-4",
    )

    print(decision.recommended_model)  # "gpt-4o-mini"
    print(decision.max_tokens)         # 256
    print(decision.estimated_cost)     # 0.0003

    # Use the decision with your LLM client
    response = openai.chat.completions.create(
        model=decision.recommended_model,
        messages=[{"role": "user", "content": prompt}],
        max_tokens=decision.max_tokens,
    )

    # Report actual usage (async, non-blocking)
    policy.report(decision, actual_tokens=response.usage.total_tokens)
"""

from costwise_mcp.client import CostPolicy
from costwise_mcp.models import Decision, TaskComplexity
from costwise_mcp.pricing import PRICING

__version__ = "0.1.0"
__all__ = ["CostPolicy", "Decision", "TaskComplexity", "PRICING"]
