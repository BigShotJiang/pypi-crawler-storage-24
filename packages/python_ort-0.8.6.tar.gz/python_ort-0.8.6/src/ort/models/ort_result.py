# SPDX-FileCopyrightText: 2025 Helio Chissini de Castro <dev@heliocastro.info
# SPDX-License-Identifier: MIT


from pydantic import BaseModel, ConfigDict, Field

from .advisor_run import AdvisorRun
from .analyzer_run import AnalyzerRun
from .evaluator_run import EvaluatorRun
from .repository import Repository
from .scanner_run import ScannerRun


class OrtResult(BaseModel):
    """
    The common output format for the analyzer and scanner. It contains information about the scanned repository,
    and the analyzer and scanner will add their result to it.

    Attributes:
        repository(Repository): Information about the repository that was used as input.
        analyzer(AnalyzerRun): An [AnalyzerRun] containing details about the analyzer that was run using [repository]
            as input. Can be null if the [repository] was not yet analyzed.

    """

    model_config = ConfigDict(
        extra="ignore",
    )
    repository: Repository = Field(
        description="Information about the repository that was used as input.",
    )
    analyzer: AnalyzerRun | None = Field(
        default=None,
        description="An [AnalyzerRun] containing details about the analyzer that was run using [repository]"
        "as input. Can be null if the [repository] was not yet analyzed.",
    )
    scanner: ScannerRun | None = Field(
        default=None,
        description="A [ScannerRun] containing details about the scanner that was run using the result"
        "from [analyzer] as input. Can be null if no scanner was run.",
    )
    advisor: AdvisorRun | None = Field(
        default=None,
        description="An [AdvisorRun] containing details about the advisor that was run using the result from"
        "[analyzer] as input. Can be null if no advisor was run.",
    )
    evaluator: EvaluatorRun | None = Field(
        default=None,
        description="A [ResolvedConfiguration] containing data resolved during the analysis which augments the"
        "automatically determined data.",
    )
    labels: dict[str, str] = Field(
        default_factory=dict,
        description="User defined labels associated to this result. Labels are not used by ORT itself, "
        "but can be used in parts of ORT which are customizable by the user, for example in evaluator"
        "rules or in the notice reporter.",
    )
