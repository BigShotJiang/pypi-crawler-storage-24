# SPDX-FileCopyrightText: 2025 Helio Chissini de Castro <dev@heliocastro.info>
# # SPDX-FileCopyrightText: 2026 CARIAD SE
# SPDX-License-Identifier: MIT

from datetime import datetime

from pydantic import BaseModel, ConfigDict, Field

from ort.utils.environment import Environment


class BaseRun(BaseModel):
    """
    The summary of a single run of the analyzer.

    """

    model_config = ConfigDict(
        extra="forbid",
    )
    start_time: datetime = Field(
        description="The time the analyzer was started.",
    )
    end_time: datetime = Field(
        description="The time the analyzer has finished.",
    )
    environment: Environment = Field(
        description="The [Environment] in which the analyzer was executed.",
    )
