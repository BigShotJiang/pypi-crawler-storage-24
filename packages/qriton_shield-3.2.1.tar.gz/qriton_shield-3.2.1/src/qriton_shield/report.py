"""Report Generator — HTML/JSON/CSV reports with threat statistics."""

from __future__ import annotations
import json
import os
from datetime import datetime
from .types import ReportConfig, ShieldStats, SubnetInfo


class ReportGenerator:
    def __init__(self, config: ReportConfig | None = None):
        cfg = config or ReportConfig()
        self._enabled = cfg.enabled
        self._output_dir = cfg.output_dir
        self._formats = cfg.formats
        self._retention_days = cfg.retention_days
        self._include_top_threats = cfg.include_top_threats

    def generate(self, stats: ShieldStats, blocked_ips: list[str],
                 banned_subnets: list[SubnetInfo], report_type: str = "daily",
                 threat_profiles: dict | None = None) -> dict[str, str]:
        if not self._enabled:
            return {}
        os.makedirs(self._output_dir, exist_ok=True)
        now = datetime.now()
        base_name = f"shield_{report_type}_{now.strftime('%Y-%m-%d_%H%M%S')}"
        paths = {}
        report_data = {
            "type": report_type,
            "generated_at": now.isoformat(),
            "stats": {
                "ips_tracked": stats.ips_tracked,
                "ips_blocked": stats.ips_blocked,
                "ips_rate_limited": stats.ips_rate_limited,
                "subnets_banned": stats.subnets_banned,
                "total_requests": stats.total_requests,
                "anomalies_detected": stats.anomalies_detected,
                "threat_mode": stats.current_threat_mode,
                "hopfield_trained": stats.hopfield_trained,
                "pattern_count": stats.pattern_count,
                "uptime_hours": round(stats.uptime / 3600000, 1),
            },
            "blocked_ips": blocked_ips[:self._include_top_threats],
            "banned_subnets": [{"range": s.range, "reason": s.reason} for s in banned_subnets],
        }
        if "json" in self._formats:
            path = os.path.join(self._output_dir, f"{base_name}.json")
            with open(path, "w") as f:
                json.dump(report_data, f, indent=2)
            paths["json"] = path
        if "html" in self._formats:
            path = os.path.join(self._output_dir, f"{base_name}.html")
            with open(path, "w") as f:
                f.write(self._render_html(report_data))
            paths["html"] = path
        if "csv" in self._formats:
            path = os.path.join(self._output_dir, f"{base_name}.csv")
            with open(path, "w") as f:
                f.write("ip,status\n")
                for ip in blocked_ips:
                    f.write(f"{ip},blocked\n")
                for s in banned_subnets:
                    f.write(f"{s.range},subnet_ban\n")
            paths["csv"] = path
        return paths

    @staticmethod
    def _render_html(data: dict) -> str:
        stats = data["stats"]
        blocked = data["blocked_ips"]
        subnets = data["banned_subnets"]
        rows_blocked = "".join(f"<tr><td>{ip}</td><td>blocked</td></tr>" for ip in blocked)
        rows_subnets = "".join(f"<tr><td>{s['range']}</td><td>{s['reason']}</td></tr>" for s in subnets)
        return f'''<!DOCTYPE html><html><head><title>Qriton Shield Report - {data["type"]}</title>
<style>body{{font-family:sans-serif;margin:20px}}table{{border-collapse:collapse;width:100%}}
th,td{{border:1px solid #ddd;padding:8px;text-align:left}}th{{background:#f4f4f4}}
.stat{{display:inline-block;margin:10px;padding:15px;background:#f8f8f8;border-radius:8px}}</style></head>
<body><h1>Qriton Shield Report — {data["type"].title()}</h1>
<p>Generated: {data["generated_at"]}</p>
<div><div class="stat"><strong>IPs Tracked</strong><br>{stats["ips_tracked"]}</div>
<div class="stat"><strong>IPs Blocked</strong><br>{stats["ips_blocked"]}</div>
<div class="stat"><strong>Subnets Banned</strong><br>{stats["subnets_banned"]}</div>
<div class="stat"><strong>Total Requests</strong><br>{stats["total_requests"]}</div>
<div class="stat"><strong>Anomalies</strong><br>{stats["anomalies_detected"]}</div>
<div class="stat"><strong>Threat Mode</strong><br>{stats["threat_mode"]}</div>
<div class="stat"><strong>Uptime</strong><br>{stats["uptime_hours"]}h</div></div>
<h2>Blocked IPs ({len(blocked)})</h2><table><tr><th>IP</th><th>Status</th></tr>{rows_blocked}</table>
<h2>Banned Subnets ({len(subnets)})</h2><table><tr><th>Range</th><th>Reason</th></tr>{rows_subnets}</table>
<footer><p>Qriton Shield v3.2.1</p></footer></body></html>'''
