"""Traffic Feature Extraction — 20-feature vectors for Hopfield analysis."""

from __future__ import annotations
import math
from datetime import datetime

from .types import TrafficFeatures, HttpRequest, ConnectionInfo, ProxyConfig


def calculate_entropy(items: list[str]) -> float:
    if not items:
        return 0.0
    counts: dict[str, int] = {}
    for item in items:
        counts[item] = counts.get(item, 0) + 1
    entropy = 0.0
    n = len(items)
    for count in counts.values():
        p = count / n
        if p > 0:
            entropy -= p * math.log2(p)
    return entropy


def calculate_interval_variance(timestamps: list[datetime]) -> float:
    if len(timestamps) < 2:
        return 0.0
    sorted_ms = sorted(t.timestamp() * 1000 for t in timestamps)
    intervals = [sorted_ms[i] - sorted_ms[i - 1] for i in range(1, len(sorted_ms))]
    mean = sum(intervals) / len(intervals)
    variance = sum((v - mean) ** 2 for v in intervals) / len(intervals)
    return variance


def get_subnet(ip: str) -> str:
    parts = ip.split(".")
    if len(parts) != 4:
        return ip
    return f"{parts[0]}.{parts[1]}.{parts[2]}.0/24"


def ip_to_number(ip: str) -> int:
    parts = [int(p) for p in ip.split(".")]
    return (parts[0] << 24) | (parts[1] << 16) | (parts[2] << 8) | parts[3]


def is_ip_in_range(ip: str, cidr: str) -> bool:
    try:
        range_ip, bits_str = cidr.split("/")
        bits = int(bits_str)
        mask = ~((1 << (32 - bits)) - 1) & 0xFFFFFFFF
        ip_num = ip_to_number(ip) & 0xFFFFFFFF
        range_num = ip_to_number(range_ip) & 0xFFFFFFFF
        return (ip_num & mask) == (range_num & mask)
    except (ValueError, IndexError):
        return False


def is_valid_ip(ip: str) -> bool:
    parts = ip.split(".")
    if len(parts) != 4:
        return False
    for part in parts:
        try:
            num = int(part)
            if num < 0 or num > 255 or part != str(num):
                return False
        except ValueError:
            return False
    return True


def extract_real_ip(client_ip: str, headers: dict[str, str],
                    config: ProxyConfig | None = None) -> tuple[str, list[str]]:
    if config is None or not config.trust_proxy:
        return client_ip, []
    normalized = {k.lower(): v for k, v in headers.items()}
    proxy_chain: list[str] = []
    for header_name in (config.header_priority or []):
        value = normalized.get(header_name.lower())
        if not value:
            continue
        if header_name.lower() == "x-forwarded-for":
            ips = [ip.strip() for ip in value.split(",") if is_valid_ip(ip.strip())]
            if ips:
                proxy_chain.extend(ips)
                for ip in ips:
                    if not _is_proxy_trusted(ip, config.trusted_proxies or []):
                        return ip, proxy_chain
                return ips[0], proxy_chain
        else:
            ip = value.strip()
            if is_valid_ip(ip):
                proxy_chain.append(ip)
                return ip, proxy_chain
    return client_ip, proxy_chain


def _is_proxy_trusted(ip: str, trusted_proxies: list[str]) -> bool:
    for trusted in trusted_proxies:
        if "/" in trusted:
            if is_ip_in_range(ip, trusted):
                return True
        elif trusted == ip:
            return True
    return False


def enrich_request(request: HttpRequest, headers: dict[str, str],
                   config: ProxyConfig | None = None) -> tuple[HttpRequest, str, list[str]]:
    real_ip, proxy_chain = extract_real_ip(request.client_ip, headers, config)
    return request, real_ip, proxy_chain


class TrafficFeatureExtractor:
    def __init__(self, window_ms: int = 60000):
        self._window_ms = window_ms
        self._connections: list[ConnectionInfo] = []
        self._requests: list[HttpRequest] = []

    def add_connection(self, conn: ConnectionInfo) -> None:
        self._connections.append(conn)
        self._cleanup()

    def add_request(self, req: HttpRequest) -> None:
        self._requests.append(req)
        self._cleanup()

    def _cleanup(self) -> None:
        cutoff = datetime.now().timestamp() - self._window_ms / 1000
        self._connections = [c for c in self._connections if c.timestamp.timestamp() > cutoff]
        self._requests = [r for r in self._requests if r.timestamp.timestamp() > cutoff]

    def extract(self) -> TrafficFeatures:
        self._cleanup()
        unique_ips = set(c.source_ip for c in self._connections)
        syn_count = sum(1 for c in self._connections if c.state == "SYN_RECEIVED")
        established_count = sum(1 for c in self._connections if c.state == "ESTABLISHED")
        total_conn = len(self._connections)
        error_404_count = sum(1 for r in self._requests if r.status_code == 404)
        post_count = sum(1 for r in self._requests if r.method == "POST")
        endpoints = [r.url for r in self._requests]
        user_agents = [r.user_agent or "" for r in self._requests]
        countries = [r.country or "unknown" for r in self._requests]
        total_bytes = sum(r.bytes_sent + r.bytes_received for r in self._requests)
        failed_states = {"SYN_SENT", "FIN_WAIT", "CLOSE_WAIT", "CLOSED"}
        failed_conns = sum(1 for c in self._connections if c.state in failed_states)
        failed_connection_rate = failed_conns / total_conn if total_conn > 0 else 0
        standard_ports = {80, 443, 8080, 8443, 22, 25, 53, 3000, 3389, 5000, 5432, 3306}
        rare_port_conns = sum(1 for c in self._connections if c.dest_port not in standard_ports)
        rare_port_ratio = rare_port_conns / total_conn if total_conn > 0 else 0
        outbound_data_anomaly = 0.0
        if len(self._requests) > 5:
            sent_values = [r.bytes_sent for r in self._requests]
            mean = sum(sent_values) / len(sent_values)
            std = math.sqrt(sum((v - mean) ** 2 for v in sent_values) / len(sent_values))
            if std > 0:
                latest = sent_values[-1]
                outbound_data_anomaly = max(-5, min(5, (latest - mean) / std))
        beaconing_score = 0.0
        if len(self._requests) > 5:
            sorted_ts = sorted(r.timestamp.timestamp() * 1000 for r in self._requests)
            intervals = [sorted_ts[i] - sorted_ts[i - 1] for i in range(1, len(sorted_ts))]
            mean_interval = sum(intervals) / len(intervals)
            if mean_interval > 0:
                std = math.sqrt(sum((v - mean_interval) ** 2 for v in intervals) / len(intervals))
                cv = std / mean_interval
                beaconing_score = max(0, min(1, 1 - cv))
        n_req = len(self._requests)
        return TrafficFeatures(
            connections_total=total_conn,
            syn_count=syn_count,
            established_count=established_count,
            unique_ips=len(unique_ips),
            connections_per_ip=total_conn / len(unique_ips) if unique_ips else 0,
            syn_ratio=syn_count / total_conn if total_conn > 0 else 0,
            established_ratio=established_count / total_conn if total_conn > 0 else 0,
            requests_per_minute=n_req,
            error_404_rate=error_404_count / n_req if n_req > 0 else 0,
            post_rate=post_count / n_req if n_req > 0 else 0,
            endpoint_entropy=calculate_entropy(endpoints),
            user_agent_variance=len(set(user_agents)) / max(1, n_req),
            geo_entropy=calculate_entropy(countries),
            interval_variance=calculate_interval_variance([r.timestamp for r in self._requests]),
            payload_size_avg=total_bytes / n_req if n_req > 0 else 0,
            dns_query_rate=0,
            failed_connection_rate=failed_connection_rate,
            rare_port_ratio=rare_port_ratio,
            outbound_data_anomaly=outbound_data_anomaly,
            beaconing_score=beaconing_score,
        )

    def extract_array(self) -> list[float]:
        f = self.extract()
        return [
            f.connections_total, f.syn_count, f.established_count, f.unique_ips,
            f.connections_per_ip, f.syn_ratio, f.established_ratio, f.requests_per_minute,
            f.error_404_rate, f.post_rate, f.endpoint_entropy, f.user_agent_variance,
            f.geo_entropy, f.interval_variance, f.payload_size_avg, f.dns_query_rate,
            f.failed_connection_rate, f.rare_port_ratio, f.outbound_data_anomaly, f.beaconing_score,
        ]

    def clear(self) -> None:
        self._connections.clear()
        self._requests.clear()
