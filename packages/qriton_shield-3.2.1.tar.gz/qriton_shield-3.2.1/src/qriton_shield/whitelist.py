"""Whitelist Manager — CDN and known-good IP range management."""

from __future__ import annotations
from .types import WhitelistConfig, DEFAULT_CDN_PROVIDERS
from .features import is_ip_in_range


class WhitelistManager:
    def __init__(self, config: WhitelistConfig | None = None):
        cfg = config or WhitelistConfig()
        self._enabled = cfg.enabled
        self._bypass_all = cfg.bypass_all_checks
        self._ranges: list[str] = list(cfg.custom_ranges or [])
        for provider in (cfg.providers or DEFAULT_CDN_PROVIDERS):
            if provider.enabled:
                self._ranges.extend(provider.ranges)

    def should_bypass_checks(self, ip: str) -> bool:
        if not self._enabled:
            return False
        return any(is_ip_in_range(ip, cidr) for cidr in self._ranges)

    def add_range(self, cidr: str) -> None:
        if cidr not in self._ranges:
            self._ranges.append(cidr)

    def remove_range(self, cidr: str) -> None:
        if cidr in self._ranges:
            self._ranges.remove(cidr)

    @property
    def ranges(self) -> list[str]:
        return list(self._ranges)
