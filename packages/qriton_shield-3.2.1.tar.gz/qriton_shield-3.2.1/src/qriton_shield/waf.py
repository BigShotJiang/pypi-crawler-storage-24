"""Web Application Firewall — OWASP Top 10 pattern detection."""

from __future__ import annotations
import re
from .types import WafConfig, WafMatch, WafRule


_DEFAULT_RULES: list[WafRule] = [
    WafRule("sqli_union", "sqli", re.compile(r"(?i)\bunion\b.*\bselect\b"), 80),
    WafRule("sqli_or", "sqli", re.compile(r"(?i)\bor\b\s+\d+\s*=\s*\d+"), 70),
    WafRule("sqli_comment", "sqli", re.compile(r"(?:--|#|/\*)\s*$"), 50),
    WafRule("sqli_quote", "sqli", re.compile(r"['\"];\s*(?:DROP|DELETE|UPDATE|INSERT|ALTER)\b", re.I), 90),
    WafRule("sqli_sleep", "sqli", re.compile(r"(?i)\b(?:sleep|benchmark|waitfor)\b\s*\("), 80),
    WafRule("xss_script", "xss", re.compile(r"<script[^>]*>", re.I), 80),
    WafRule("xss_event", "xss", re.compile(r"\bon\w+\s*=", re.I), 60),
    WafRule("xss_javascript", "xss", re.compile(r"javascript\s*:", re.I), 70),
    WafRule("xss_img", "xss", re.compile(r"<img[^>]+onerror", re.I), 70),
    WafRule("path_traversal", "path_traversal", re.compile(r"\.\./|\.\.\\"), 70),
    WafRule("path_traversal_encoded", "path_traversal", re.compile(r"%2e%2e[/\\%]", re.I), 80),
    WafRule("path_null_byte", "path_traversal", re.compile(r"%00"), 90),
    WafRule("cmd_injection_pipe", "cmd_injection", re.compile(r"[;&|`]\s*(?:cat|ls|dir|whoami|id|uname|curl|wget|nc|bash|sh|cmd|powershell)\b", re.I), 90),
    WafRule("cmd_injection_backtick", "cmd_injection", re.compile(r"`[^`]+`"), 70),
    WafRule("cmd_injection_dollar", "cmd_injection", re.compile(r"\$\([^)]+\)"), 70),
    WafRule("header_injection_crlf", "header_injection", re.compile(r"%0[da]|\\r\\n", re.I), 80),
]


class WafEngine:
    def __init__(self, config: WafConfig | None = None):
        cfg = config or WafConfig()
        self._enabled = cfg.enabled
        self._block_on_match = cfg.block_on_match
        self._rules = list(_DEFAULT_RULES)
        for pat_str in (cfg.custom_patterns or []):
            try:
                self._rules.append(WafRule(f"custom_{len(self._rules)}", "custom", re.compile(pat_str), 60))
            except re.error:
                pass

    def check(self, url: str, query: str | None = None, user_agent: str | None = None,
              body: str | None = None) -> WafMatch | None:
        if not self._enabled:
            return None
        targets = [url]
        if query:
            targets.append(query)
        if user_agent:
            targets.append(user_agent)
        if body:
            targets.append(body)
        for rule in self._rules:
            for target in targets:
                m = rule.pattern.search(target)
                if m:
                    return WafMatch(rule_name=rule.name, category=rule.category,
                                    score=rule.score, matched_value=m.group()[:100])
        return None

    @property
    def enabled(self) -> bool:
        return self._enabled

    @property
    def rule_count(self) -> int:
        return len(self._rules)
