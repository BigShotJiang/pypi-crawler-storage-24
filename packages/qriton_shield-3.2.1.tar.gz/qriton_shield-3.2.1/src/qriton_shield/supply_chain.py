"""Supply Chain Scanner — npm/pip package security scanning."""

from __future__ import annotations
import json
import os
import re
from dataclasses import dataclass, field


@dataclass
class ScanFinding:
    severity: str
    rule: str
    description: str
    file: str
    line: int = 0

@dataclass
class ScanResult:
    safe: bool
    findings: list[ScanFinding] = field(default_factory=list)
    files_scanned: int = 0


_DANGEROUS_PATTERNS = [
    ("eval/exec usage", re.compile(r"\b(?:eval|exec)\s*\("), "high"),
    ("subprocess call", re.compile(r"\bsubprocess\b"), "medium"),
    ("os.system call", re.compile(r"\bos\.system\b"), "high"),
    ("network access", re.compile(r"\b(?:urllib|requests|httpx|aiohttp)\b.*(?:get|post|put|delete)\b", re.I), "medium"),
    ("file write", re.compile(r"\bopen\s*\([^)]*['\"]w['\"]"), "medium"),
    ("environment access", re.compile(r"\bos\.environ\b"), "low"),
    ("base64 decode", re.compile(r"\bbase64\.b64decode\b"), "low"),
    ("install hook", re.compile(r"(?:pre|post)_?install|setup\.py.*install", re.I), "high"),
    ("obfuscated code", re.compile(r"(?:exec|eval)\s*\(\s*(?:compile|__import__|getattr)"), "critical"),
    ("credential pattern", re.compile(r"AKIA[0-9A-Z]{16}|-----BEGIN\s+PRIVATE\s+KEY"), "critical"),
]


class SupplyChainScanner:
    def __init__(self, max_file_size: int = 5 * 1024 * 1024):
        self._max_file_size = max_file_size

    def scan_directory(self, path: str) -> ScanResult:
        findings: list[ScanFinding] = []
        files_scanned = 0
        for root, _, files in os.walk(path):
            for fname in files:
                if not fname.endswith((".py", ".js", ".ts", ".sh", ".bat")):
                    continue
                fpath = os.path.join(root, fname)
                try:
                    if os.path.getsize(fpath) > self._max_file_size:
                        continue
                    with open(fpath, "r", encoding="utf-8", errors="ignore") as f:
                        content = f.read()
                    files_scanned += 1
                    for rule_name, pattern, severity in _DANGEROUS_PATTERNS:
                        for i, line in enumerate(content.splitlines(), 1):
                            if pattern.search(line):
                                findings.append(ScanFinding(
                                    severity=severity, rule=rule_name,
                                    description=f"Found {rule_name} in {fname}",
                                    file=fpath, line=i,
                                ))
                                break
                except OSError:
                    continue
        return ScanResult(safe=len(findings) == 0, findings=findings, files_scanned=files_scanned)

    def scan_file(self, path: str) -> ScanResult:
        try:
            with open(path, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read()
        except OSError:
            return ScanResult(safe=True, files_scanned=0)
        findings = []
        for rule_name, pattern, severity in _DANGEROUS_PATTERNS:
            for i, line in enumerate(content.splitlines(), 1):
                if pattern.search(line):
                    findings.append(ScanFinding(
                        severity=severity, rule=rule_name,
                        description=f"Found {rule_name}",
                        file=path, line=i,
                    ))
                    break
        return ScanResult(safe=len(findings) == 0, findings=findings, files_scanned=1)
