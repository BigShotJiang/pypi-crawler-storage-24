"""DasData Reporter — Threat intelligence reporting to central hub."""

from __future__ import annotations
import hashlib
import hmac
import json
import threading
import time
import urllib.request
import urllib.error
from datetime import datetime
from .types import DasDataConfig, ThreatProfile


class DasDataReporter:
    def __init__(self, config: DasDataConfig | None = None):
        cfg = config or DasDataConfig()
        self._enabled = cfg.enabled
        self._endpoint = cfg.api_endpoint
        self._shield_id = cfg.shield_id
        self._api_key = cfg.api_key
        self._secret_key = cfg.secret_key
        self._batch_size = cfg.batch_size
        self._batch_interval = cfg.batch_interval_seconds
        self._timeout = cfg.timeout / 1000
        self._retry_attempts = cfg.retry_attempts
        self._queue: list[dict] = []
        self._lock = threading.Lock()
        self._timer: threading.Timer | None = None
        self._listeners: dict[str, list] = {}
        self._hopfield_state: dict | None = None

    def on(self, event: str, callback) -> None:
        self._listeners.setdefault(event, []).append(callback)

    def _emit(self, event: str, data=None) -> None:
        for cb in self._listeners.get(event, []):
            try:
                cb(data)
            except Exception:
                pass

    def start(self) -> None:
        if self._enabled:
            self._schedule_batch()

    def stop(self) -> None:
        if self._timer:
            self._timer.cancel()
            self._timer = None
        self._flush()

    def _schedule_batch(self) -> None:
        self._flush()
        self._timer = threading.Timer(self._batch_interval, self._schedule_batch)
        self._timer.daemon = True
        self._timer.start()

    def report_block(self, profile: ThreatProfile, reason: str) -> None:
        if not self._enabled:
            return
        report = {
            "ip": profile.ip,
            "reason": reason,
            "threat_score": profile.threat_score,
            "threat_type": profile.threat_type or "unknown",
            "block_count": profile.block_count,
            "timestamp": datetime.now().isoformat(),
        }
        with self._lock:
            self._queue.append(report)
            if len(self._queue) > 500:
                self._queue.pop(0)

    def update_hopfield_state(self, state: dict) -> None:
        self._hopfield_state = state

    def _flush(self) -> None:
        with self._lock:
            if not self._queue:
                return
            batch = self._queue[:self._batch_size]
            self._queue = self._queue[self._batch_size:]
        body = json.dumps({"reports": batch, "hopfield": self._hopfield_state})
        for attempt in range(self._retry_attempts):
            try:
                self._send(body)
                self._emit("batch_sent", {"count": len(batch)})
                return
            except Exception as e:
                if attempt == self._retry_attempts - 1:
                    self._emit("error", {"error": str(e)})
                    with self._lock:
                        self._queue = batch + self._queue

    def _send(self, body: str) -> None:
        timestamp = str(int(time.time()))
        signature_data = f"{self._shield_id}{timestamp}{body}"
        signature = hmac.new(self._secret_key.encode(), signature_data.encode(), hashlib.sha256).hexdigest()
        headers = {
            "Content-Type": "application/json",
            "X-Shield-Id": self._shield_id,
            "X-Shield-Key": self._api_key,
            "X-Shield-Timestamp": timestamp,
            "X-Shield-Signature": signature,
        }
        req = urllib.request.Request(
            f"{self._endpoint}/api/report",
            data=body.encode(),
            headers=headers,
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=self._timeout):
            pass

    async def upload_model(self, model: dict) -> bool:
        return False

    async def download_model(self):
        return None

    @property
    def enabled(self) -> bool:
        return self._enabled

    @property
    def queue_size(self) -> int:
        return len(self._queue)
