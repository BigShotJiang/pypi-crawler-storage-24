"""MCPGuard — Shield-powered firewall for Claude MCP tool calls."""

from __future__ import annotations
import json
import os
import re
import time
from .types import MCPGuardConfig


_DANGEROUS_PATTERNS = [
    re.compile(r"(?i)ignore\s+(?:all\s+)?(?:previous|above|prior)\s+instructions?"),
    re.compile(r"(?i)you\s+are\s+now\s+(?:a|an|in)\s+"),
    re.compile(r"(?i)system\s*:\s*you\s+(?:are|must|should|will)"),
    re.compile(r"(?i)(?:do\s+not|don'?t)\s+(?:follow|obey|listen)"),
    re.compile(r"(?i)override\s+(?:your|the|all)\s+(?:instructions?|rules?|constraints?)"),
    re.compile(r"(?i)(?:execute|run|eval)\s*\([^)]*(?:curl|wget|bash|sh|cmd|powershell)"),
    re.compile(r"(?i)(?:read|cat|type)\s+(?:/etc/(?:passwd|shadow)|~/.ssh|\.env)"),
    re.compile(r"(?i)(?:rm|del|remove)\s+-[rf]+\s+/"),
    re.compile(r"AKIA[0-9A-Z]{16}"),
    re.compile(r"-----BEGIN\s+(?:RSA\s+)?PRIVATE\s+KEY-----"),
]


class MCPGuard:
    def __init__(self, config: MCPGuardConfig | None = None):
        cfg = config or MCPGuardConfig()
        self._enabled = cfg.enabled
        self._audit_path = cfg.audit_log_path
        self._block_on_threat = cfg.block_on_threat
        self._threshold = cfg.semantic_threshold
        self._audit_file = None

    def start(self) -> None:
        if self._audit_path:
            os.makedirs(os.path.dirname(self._audit_path) or ".", exist_ok=True)
            self._audit_file = open(self._audit_path, "a")

    def stop(self) -> None:
        if self._audit_file:
            self._audit_file.close()
            self._audit_file = None

    def check_tool_call(self, tool_name: str, arguments: dict) -> dict:
        if not self._enabled:
            return {"allowed": True, "score": 0, "reason": "Guard disabled"}
        content = json.dumps({"tool": tool_name, "arguments": arguments})
        findings = []
        score = 0.0
        for pattern in _DANGEROUS_PATTERNS:
            m = pattern.search(content)
            if m:
                findings.append({"pattern": pattern.pattern[:60], "match": m.group()[:50]})
                score += 0.3
        score = min(1.0, score)
        allowed = score < self._threshold
        if self._block_on_threat and not allowed:
            allowed = False
        result = {
            "allowed": allowed,
            "score": score,
            "findings": findings,
            "reason": "Clean" if allowed else f"Threat detected (score: {score:.2f})",
        }
        self._log_decision(tool_name, arguments, result)
        return result

    def _log_decision(self, tool_name: str, arguments: dict, result: dict) -> None:
        if not self._audit_file:
            return
        entry = {
            "timestamp": time.time(),
            "tool": tool_name,
            "allowed": result["allowed"],
            "score": result["score"],
            "reason": result["reason"],
        }
        try:
            self._audit_file.write(json.dumps(entry) + "\n")
            self._audit_file.flush()
        except OSError:
            pass

    @property
    def enabled(self) -> bool:
        return self._enabled
