"""Blacklist Manager — Spamhaus, Firehol, AbuseIPDB integration."""

from __future__ import annotations
import threading
import urllib.request
import urllib.error
from .types import BlacklistConfig, DEFAULT_BLACKLIST_SOURCES
from .features import is_ip_in_range


class BlacklistManager:
    def __init__(self, config: BlacklistConfig | None = None):
        cfg = config or BlacklistConfig()
        self._enabled = cfg.enabled
        self._sources = cfg.sources or list(DEFAULT_BLACKLIST_SOURCES)
        self._update_interval_ms = cfg.update_interval_ms
        self._max_entries = cfg.max_entries
        self._ranges: list[str] = list(cfg.custom_blacklist or [])
        self._ips: set[str] = set()
        self._lock = threading.Lock()
        self._update_timer: threading.Timer | None = None

    def start(self) -> None:
        if self._enabled:
            self.refresh()

    def stop(self) -> None:
        if self._update_timer:
            self._update_timer.cancel()
            self._update_timer = None

    def refresh(self) -> int:
        total = 0
        for source in self._sources:
            if not source.enabled:
                continue
            try:
                req = urllib.request.Request(source.url, headers={"User-Agent": "QritonShield/3.2"})
                with urllib.request.urlopen(req, timeout=30) as resp:
                    content = resp.read().decode("utf-8", errors="ignore")
                    for line in content.splitlines():
                        line = line.strip()
                        if not line or line.startswith("#") or line.startswith(";"):
                            continue
                        entry = line.split(";")[0].strip().split()[0].strip()
                        if not entry:
                            continue
                        with self._lock:
                            if len(self._ranges) + len(self._ips) >= self._max_entries:
                                break
                            if "/" in entry:
                                self._ranges.append(entry)
                            else:
                                self._ips.add(entry)
                            total += 1
            except (urllib.error.URLError, OSError, ValueError):
                pass
        if self._update_interval_ms > 0:
            self._update_timer = threading.Timer(self._update_interval_ms / 1000, self.refresh)
            self._update_timer.daemon = True
            self._update_timer.start()
        return total

    def is_blacklisted(self, ip: str) -> tuple[bool, str]:
        if not self._enabled:
            return False, ""
        with self._lock:
            if ip in self._ips:
                return True, "blacklist_ip"
            for cidr in self._ranges:
                if is_ip_in_range(ip, cidr):
                    return True, f"blacklist_range:{cidr}"
        return False, ""

    @property
    def entry_count(self) -> int:
        return len(self._ranges) + len(self._ips)
