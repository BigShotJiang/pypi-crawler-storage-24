"""Modern Continuous Hopfield Network with LogSumExp energy function."""

from __future__ import annotations
import math
from dataclasses import dataclass

from .types import RecallResult, PatternComposition, HopfieldConfig, EnergyType


class ContinuousHopfieldNetwork:
    def __init__(self, size: int, *, energy_type: EnergyType = "logsumexp",
                 beta: float = 1.0, learning_rate: float = 0.1,
                 convergence_threshold: float = 1e-6, max_iterations: int = 100,
                 max_patterns: int = 200):
        self.size = size
        self._energy_type = energy_type
        self._beta = beta
        self._learning_rate = learning_rate
        self._convergence_threshold = convergence_threshold
        self._max_iterations = max_iterations
        self._max_patterns = max_patterns
        self._patterns: list[list[float]] = []
        self._weights: list[float] | None = None
        if energy_type == "quadratic":
            self._weights = [0.0] * (size * size)

    def train(self, patterns: list[list[float]]) -> None:
        self._patterns = [self._normalize(p) for p in patterns]
        if self._energy_type == "quadratic" and self._weights is not None:
            self._weights = [0.0] * (self.size * self.size)
            for pattern in self._patterns:
                n = len(self._patterns)
                for i in range(self.size):
                    for j in range(i + 1, self.size):
                        delta = pattern[i] * pattern[j] / n
                        self._weights[i * self.size + j] += delta
                        self._weights[j * self.size + i] += delta

    def add_pattern(self, pattern: list[float]) -> None:
        normalized = self._normalize(pattern)
        if len(self._patterns) >= self._max_patterns:
            self._patterns.pop(20) if len(self._patterns) > 20 else self._patterns.pop(0)
        self._patterns.append(normalized)
        if self._energy_type == "quadratic" and self._weights is not None:
            n = len(self._patterns)
            for i in range(self.size):
                for j in range(i + 1, self.size):
                    delta = normalized[i] * normalized[j] / n
                    self._weights[i * self.size + j] += delta
                    self._weights[j * self.size + i] += delta

    def _normalize(self, state: list[float]) -> list[float]:
        return [max(-1.0, min(1.0, x)) for x in state]

    def energy(self, state: list[float]) -> float:
        if self._energy_type == "logsumexp":
            return self._energy_logsumexp(state)
        return self._energy_quadratic(state)

    def _energy_logsumexp(self, state: list[float]) -> float:
        if not self._patterns:
            return 0.0
        similarities = [self._beta * self._dot_product(p, state) for p in self._patterns]
        lse = self._logsumexp(similarities)
        norm_sq = self._dot_product(state, state)
        return -lse / self._beta + 0.5 * norm_sq

    def _energy_quadratic(self, state: list[float]) -> float:
        if self._weights is None:
            return 0.0
        energy = 0.0
        for i in range(self.size):
            for j in range(i + 1, self.size):
                energy -= self._weights[i * self.size + j] * state[i] * state[j]
        return energy

    def gradient(self, state: list[float]) -> list[float]:
        if self._energy_type == "logsumexp":
            return self._gradient_logsumexp(state)
        return self._gradient_quadratic(state)

    def _gradient_logsumexp(self, state: list[float]) -> list[float]:
        if not self._patterns:
            return [0.0] * self.size
        similarities = [self._beta * self._dot_product(p, state) for p in self._patterns]
        attention = self._softmax(similarities)
        grad = list(state)
        for i in range(self.size):
            for p_idx in range(len(self._patterns)):
                grad[i] -= attention[p_idx] * self._patterns[p_idx][i]
        return grad

    def _gradient_quadratic(self, state: list[float]) -> list[float]:
        if self._weights is None:
            return [0.0] * self.size
        grad = [0.0] * self.size
        for i in range(self.size):
            for j in range(self.size):
                grad[i] -= self._weights[i * self.size + j] * state[j]
        return grad

    def recall(self, input_state: list[float]) -> RecallResult:
        state = self._normalize(input_state)
        energy_path = [self.energy(state)]
        iterations = 0
        converged = False
        for it in range(self._max_iterations):
            grad = self.gradient(state)
            max_change = 0.0
            for i in range(self.size):
                new_val = max(-1.0, min(1.0, state[i] - self._learning_rate * grad[i]))
                max_change = max(max_change, abs(new_val - state[i]))
                state[i] = new_val
            energy_path.append(self.energy(state))
            iterations = it + 1
            if max_change < self._convergence_threshold:
                converged = True
                break
        return RecallResult(state=state, iterations=iterations, converged=converged,
                           energy_path=energy_path, final_energy=energy_path[-1])

    def compute_composition(self, state: list[float]) -> list[PatternComposition]:
        if not self._patterns:
            return []
        similarities = [self._dot_product(p, state) for p in self._patterns]
        attention = self._softmax([self._beta * s for s in similarities])
        result = [
            PatternComposition(pattern_index=i, similarity=similarities[i], percentage=attention[i] * 100)
            for i in range(len(self._patterns))
        ]
        result.sort(key=lambda x: x.percentage, reverse=True)
        return result

    def get_attention(self, state: list[float]) -> list[float]:
        if not self._patterns:
            return []
        similarities = [self._beta * self._dot_product(p, state) for p in self._patterns]
        return self._softmax(similarities)

    def get_gradient_norm(self, state: list[float]) -> float:
        grad = self.gradient(state)
        return math.sqrt(self._dot_product(grad, grad))

    @staticmethod
    def _logsumexp(arr: list[float]) -> float:
        if not arr:
            return 0.0
        max_val = max(arr)
        total = sum(math.exp(x - max_val) for x in arr)
        return max_val + math.log(total)

    @staticmethod
    def _softmax(arr: list[float]) -> list[float]:
        if not arr:
            return []
        max_val = max(arr)
        exp_vals = [math.exp(x - max_val) for x in arr]
        total = sum(exp_vals)
        return [e / total for e in exp_vals]

    @staticmethod
    def _dot_product(a: list[float], b: list[float]) -> float:
        return sum(x * y for x, y in zip(a, b))

    @property
    def pattern_count(self) -> int:
        return len(self._patterns)

    @property
    def network_size(self) -> int:
        return self.size

    @property
    def is_trained(self) -> bool:
        return len(self._patterns) > 0

    def get_patterns(self) -> list[list[float]]:
        return [list(p) for p in self._patterns]

    def set_patterns(self, patterns: list[list[float]]) -> None:
        self._patterns = [self._normalize(p) for p in patterns]

    def to_dict(self) -> dict:
        return {
            "size": self.size,
            "energy_type": self._energy_type,
            "beta": self._beta,
            "learning_rate": self._learning_rate,
            "convergence_threshold": self._convergence_threshold,
            "max_iterations": self._max_iterations,
            "max_patterns": self._max_patterns,
            "patterns": self._patterns,
            "weights": self._weights,
        }

    @classmethod
    def from_dict(cls, data: dict) -> ContinuousHopfieldNetwork:
        net = cls(data["size"], energy_type=data.get("energy_type", "logsumexp"),
                  beta=data.get("beta", 1.0), learning_rate=data.get("learning_rate", 0.1),
                  convergence_threshold=data.get("convergence_threshold", 1e-6),
                  max_iterations=data.get("max_iterations", 100),
                  max_patterns=data.get("max_patterns", 200))
        net._patterns = data.get("patterns", [])
        if data.get("weights") is not None:
            net._weights = data["weights"]
        return net
