"""Firewall Manager — Cross-platform IP blocking (Windows routes, Linux iptables)."""

from __future__ import annotations
import subprocess
import sys
import threading
from .types import FirewallConfig


class FirewallManager:
    def __init__(self, config: FirewallConfig | None = None):
        cfg = config or FirewallConfig()
        self._enabled = cfg.enabled
        self._platform = cfg.platform
        if self._platform == "auto":
            self._platform = "windows" if sys.platform == "win32" else "linux" if sys.platform == "linux" else "darwin"
        self._chain_name = cfg.chain_name
        self._rule_prefix = cfg.rule_prefix
        self._max_rules = cfg.max_rules
        self._custom_block = cfg.custom_block_command
        self._custom_unblock = cfg.custom_unblock_command
        self._blocked: set[str] = set()
        self._lock = threading.Lock()

    def block(self, ip: str, reason: str = "") -> bool:
        if not self._enabled or ip in self._blocked:
            return False
        if len(self._blocked) >= self._max_rules:
            return False
        with self._lock:
            try:
                if self._custom_block:
                    cmd = self._custom_block.replace("{ip}", ip).replace("{reason}", reason)
                    subprocess.run(cmd, shell=True, capture_output=True, timeout=10)
                elif self._platform == "windows":
                    subprocess.run(
                        ["route", "add", ip, "mask", "255.255.255.255", "0.0.0.0", "-p"],
                        capture_output=True, timeout=10,
                    )
                elif self._platform == "linux":
                    subprocess.run(
                        ["iptables", "-A", self._chain_name, "-s", ip, "-j", "DROP"],
                        capture_output=True, timeout=10,
                    )
                elif self._platform == "darwin":
                    subprocess.run(
                        ["pfctl", "-t", self._chain_name, "-T", "add", ip],
                        capture_output=True, timeout=10,
                    )
                self._blocked.add(ip)
                return True
            except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
                return False

    def unblock(self, ip: str) -> bool:
        if not self._enabled or ip not in self._blocked:
            return False
        with self._lock:
            try:
                if self._custom_unblock:
                    cmd = self._custom_unblock.replace("{ip}", ip)
                    subprocess.run(cmd, shell=True, capture_output=True, timeout=10)
                elif self._platform == "windows":
                    subprocess.run(["route", "delete", ip], capture_output=True, timeout=10)
                elif self._platform == "linux":
                    subprocess.run(
                        ["iptables", "-D", self._chain_name, "-s", ip, "-j", "DROP"],
                        capture_output=True, timeout=10,
                    )
                elif self._platform == "darwin":
                    subprocess.run(
                        ["pfctl", "-t", self._chain_name, "-T", "delete", ip],
                        capture_output=True, timeout=10,
                    )
                self._blocked.discard(ip)
                return True
            except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
                return False

    def block_subnet(self, cidr: str, reason: str = "") -> bool:
        if not self._enabled:
            return False
        with self._lock:
            try:
                if self._platform == "windows":
                    name = f"{self._rule_prefix}{cidr.replace('/', '_').replace('.', '_')}"
                    subprocess.run(
                        ["netsh", "advfirewall", "firewall", "add", "rule",
                         f"name={name}", "dir=in", "action=block", f"remoteip={cidr}"],
                        capture_output=True, timeout=10,
                    )
                elif self._platform == "linux":
                    subprocess.run(
                        ["iptables", "-A", self._chain_name, "-s", cidr, "-j", "DROP"],
                        capture_output=True, timeout=10,
                    )
                return True
            except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
                return False

    @property
    def blocked_ips(self) -> set[str]:
        return set(self._blocked)

    @property
    def blocked_count(self) -> int:
        return len(self._blocked)
