"""API Server — HTTP REST API for Shield stats and management."""

from __future__ import annotations
import json
import threading
from http.server import HTTPServer, BaseHTTPRequestHandler
from .types import ApiServerConfig


class _ShieldHandler(BaseHTTPRequestHandler):
    shield = None

    def do_GET(self):
        if not self.shield:
            self._json_response(500, {"error": "Shield not initialized"})
            return
        path = self.path.split("?")[0]
        if path == "/health":
            self._json_response(200, {"status": "ok", "running": self.shield.running})
        elif path == "/stats":
            stats = self.shield.get_stats()
            self._json_response(200, {
                "ips_tracked": stats.ips_tracked,
                "ips_blocked": stats.ips_blocked,
                "ips_rate_limited": stats.ips_rate_limited,
                "subnets_banned": stats.subnets_banned,
                "total_requests": stats.total_requests,
                "current_threat_mode": stats.current_threat_mode,
                "hopfield_trained": stats.hopfield_trained,
                "pattern_count": stats.pattern_count,
                "uptime_ms": stats.uptime,
            })
        elif path == "/blocked":
            self._json_response(200, {"ips": self.shield.get_blocked_ips()})
        elif path == "/blocked/subnets":
            subnets = [{"range": s.range, "reason": s.reason} for s in self.shield.get_banned_subnets()]
            self._json_response(200, {"subnets": subnets})
        elif path == "/audit":
            self._json_response(200, self.shield.audit())
        else:
            self._json_response(404, {"error": "Not found"})

    def _json_response(self, status: int, data: dict):
        body = json.dumps(data).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, format, *args):
        pass  # Suppress default logging


class ApiServer:
    def __init__(self, shield, config: ApiServerConfig | None = None):
        cfg = config or ApiServerConfig()
        self._enabled = cfg.enabled
        self._host = cfg.host
        self._port = cfg.port
        self._server: HTTPServer | None = None
        self._thread: threading.Thread | None = None
        _ShieldHandler.shield = shield

    def start(self) -> None:
        if not self._enabled:
            return
        self._server = HTTPServer((self._host, self._port), _ShieldHandler)
        self._thread = threading.Thread(target=self._server.serve_forever, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        if self._server:
            self._server.shutdown()
            self._server = None

    @property
    def port(self) -> int:
        return self._port
