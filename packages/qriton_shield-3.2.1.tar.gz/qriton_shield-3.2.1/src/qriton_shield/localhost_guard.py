"""LocalhostGuard — Origin-aware connection guard for localhost services."""

from __future__ import annotations
import threading
import time
from .types import LocalhostGuardConfig


class LocalhostGuard:
    def __init__(self, config: LocalhostGuardConfig | None = None):
        cfg = config or LocalhostGuardConfig()
        self._allow_origins = cfg.allow_origins
        self._max_auth_attempts = cfg.max_auth_attempts
        self._lockout_seconds = cfg.lockout_seconds
        self._rate_limit = cfg.rate_limit_per_second
        self._max_connections = cfg.max_concurrent_connections
        self._connection_states: dict[str, dict] = {}
        self._request_counts: dict[str, list[float]] = {}
        self._lock = threading.Lock()

    def check_connection(self, remote_address: str, origin: str | None = None) -> dict:
        with self._lock:
            if origin is not None and origin not in self._allow_origins:
                return {"allowed": False, "reason": f"Origin rejected: {origin}"}
            state = self._connection_states.get(remote_address, {})
            if state.get("locked_until") and time.time() < state["locked_until"]:
                return {"allowed": False, "reason": "Account locked"}
            now = time.time()
            times = self._request_counts.get(remote_address, [])
            times = [t for t in times if now - t < 1]
            if len(times) >= self._rate_limit:
                return {"allowed": False, "reason": "Rate limited"}
            times.append(now)
            self._request_counts[remote_address] = times
            return {"allowed": True, "reason": "OK"}

    def record_auth_failure(self, remote_address: str) -> None:
        with self._lock:
            if remote_address not in self._connection_states:
                self._connection_states[remote_address] = {"auth_attempts": 0}
            state = self._connection_states[remote_address]
            state["auth_attempts"] = state.get("auth_attempts", 0) + 1
            if state["auth_attempts"] >= self._max_auth_attempts:
                state["locked_until"] = time.time() + self._lockout_seconds

    def reset(self, remote_address: str) -> None:
        with self._lock:
            self._connection_states.pop(remote_address, None)
            self._request_counts.pop(remote_address, None)


def localhost_guard(config: LocalhostGuardConfig | None = None) -> LocalhostGuard:
    return LocalhostGuard(config)
