"""Troll Mode — Attacker entertainment: rickrolls, tarpits, honeypots."""

from __future__ import annotations
import random
import time
from .types import TrollConfig


class TrollMode:
    def __init__(self, config: TrollConfig | None = None):
        cfg = config or TrollConfig()
        self._enabled = cfg.enabled
        self._responses = cfg.responses
        self._probability = cfg.probability
        self._min_delay = cfg.min_delay_ms
        self._max_delay = cfg.max_delay_ms
        self._tarpit_bps = cfg.tarpit_bytes_per_second
        self._honeypot_paths = cfg.honeypot_paths
        self._rickroll_url = cfg.rickroll_url
        self._capture_credentials = cfg.capture_credentials
        self._credential_log = cfg.credential_log_path
        self._stats = {
            "rickrolls": 0, "tarpit_victims": 0, "honeypot_captures": 0,
            "redirect_loops": 0, "fake_vuln_hits": 0, "captcha_failures": 0,
        }

    @property
    def enabled(self) -> bool:
        return self._enabled

    def should_troll(self, path: str) -> bool:
        if not self._enabled:
            return False
        if path in self._honeypot_paths:
            return True
        return random.random() < self._probability

    def get_response(self, path: str, ip: str = "") -> dict:
        if not self._enabled:
            return {"type": "pass"}
        response_type = random.choice(self._responses)
        if response_type == "rickroll":
            self._stats["rickrolls"] += 1
            return {"type": "redirect", "url": self._rickroll_url, "status": 302}
        elif response_type == "tarpit":
            self._stats["tarpit_victims"] += 1
            return {
                "type": "tarpit",
                "content": self._generate_tarpit_content(),
                "bytes_per_second": self._tarpit_bps,
                "delay_ms": random.randint(self._min_delay, self._max_delay),
            }
        elif response_type == "fake_login":
            self._stats["honeypot_captures"] += 1
            return {"type": "html", "content": self._fake_login_page(), "status": 200}
        elif response_type == "redirect_loop":
            self._stats["redirect_loops"] += 1
            n = random.randint(1, 100)
            return {"type": "redirect", "url": f"/admin{n}", "status": 302}
        elif response_type == "slow_response":
            return {
                "type": "slow",
                "content": "Processing your request..." + " " * 1000,
                "delay_ms": random.randint(self._min_delay, self._max_delay),
            }
        elif response_type == "honeypot":
            return {"type": "html", "content": self._fake_vulnerability(path), "status": 200}
        else:
            return {"type": "html", "content": "<html><body>" + "A" * 10000 + "</body></html>", "status": 200}

    def capture_credentials(self, ip: str, username: str, password: str) -> None:
        if not self._capture_credentials or not self._credential_log:
            return
        import json, os
        entry = {"ip": ip, "username": username, "password": password, "timestamp": time.time()}
        try:
            with open(self._credential_log, "a") as f:
                f.write(json.dumps(entry) + "\n")
        except OSError:
            pass

    @staticmethod
    def _generate_tarpit_content() -> str:
        return "<!DOCTYPE html><html><head><title>Loading...</title></head><body>" + ("<p>Please wait...</p>\n" * 100) + "</body></html>"

    @staticmethod
    def _fake_login_page() -> str:
        return '''<!DOCTYPE html><html><head><title>Admin Login</title></head>
<body><h1>Admin Panel</h1><form method="POST">
<input name="username" placeholder="Username"><br>
<input name="password" type="password" placeholder="Password"><br>
<button type="submit">Login</button></form></body></html>'''

    @staticmethod
    def _fake_vulnerability(path: str) -> str:
        if ".env" in path:
            return "DB_HOST=localhost\nDB_USER=admin\nDB_PASS=hunter2\nSECRET_KEY=totally-real-key-1234"
        if "passwd" in path:
            return "root:x:0:0:root:/root:/bin/bash\nnobody:x:65534:65534:nobody:/nonexistent:/usr/sbin/nologin"
        if "wp-config" in path:
            return "<?php\ndefine('DB_NAME', 'wordpress');\ndefine('DB_USER', 'wp_admin');\ndefine('DB_PASSWORD', 'definitely_real_password');"
        if ".git" in path:
            return "[core]\n\trepositoryformatversion = 0\n\tfilemode = true\n\tbare = false"
        return "<html><body><h1>404 Not Found</h1></body></html>"

    @property
    def stats(self) -> dict:
        return dict(self._stats)
