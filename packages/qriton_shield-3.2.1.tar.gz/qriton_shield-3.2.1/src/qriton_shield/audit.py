"""Audit Log — Hash-chain tamper-evident decision trail."""

from __future__ import annotations
import hashlib
import json
import os
import uuid
from datetime import datetime
from .types import AuditEntry, LayerSignal


class AuditLog:
    def __init__(self, log_path: str):
        self._log_path = log_path
        self._prev_hash = "0" * 64
        self._count = 0
        self._file = None

    def start(self) -> None:
        os.makedirs(os.path.dirname(self._log_path) or ".", exist_ok=True)
        self._file = open(self._log_path, "a")

    def stop(self) -> None:
        if self._file:
            self._file.close()
            self._file = None

    def append(self, action: str, decision: str, client_ip: str,
               signals: list[LayerSignal], score: float) -> AuditEntry:
        entry_id = str(uuid.uuid4())
        ts = datetime.now().isoformat()
        data = f"{ts}{entry_id}{action}{decision}{client_ip}{score}{self._prev_hash}"
        entry_hash = hashlib.sha256(data.encode()).hexdigest()
        entry = AuditEntry(
            timestamp=ts, id=entry_id, action=action, decision=decision,
            client_ip=client_ip, signals=signals, score=score,
            prev_hash=self._prev_hash, hash=entry_hash,
        )
        self._prev_hash = entry_hash
        self._count += 1
        if self._file:
            record = {
                "timestamp": ts, "id": entry_id, "action": action,
                "decision": decision, "client_ip": client_ip, "score": score,
                "prev_hash": entry.prev_hash, "hash": entry_hash,
            }
            self._file.write(json.dumps(record) + "\n")
            self._file.flush()
        return entry

    @property
    def count(self) -> int:
        return self._count
