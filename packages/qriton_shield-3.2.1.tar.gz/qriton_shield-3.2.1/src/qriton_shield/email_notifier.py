"""Email Notifier — SMTP email alerts for Shield events."""

from __future__ import annotations
import smtplib
import threading
import time
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from .types import EmailConfig


class EmailNotifier:
    def __init__(self, config: EmailConfig | None = None):
        cfg = config or EmailConfig()
        self._enabled = cfg.enabled
        self._smtp = cfg.smtp
        self._from = cfg.from_addr
        self._to = cfg.to
        self._cc = cfg.cc
        self._prefix = cfg.subject_prefix
        self._triggers = set(cfg.triggers)
        self._throttle_minutes = cfg.throttle_minutes
        self._max_per_hour = cfg.max_emails_per_hour
        self._last_sent: dict[str, float] = {}
        self._sent_count = 0
        self._hour_start = time.time()
        self._lock = threading.Lock()

    def send(self, subject: str, body: str, event_type: str = "", html: bool = False) -> bool:
        if not self._enabled or not self._to:
            return False
        if event_type and event_type not in self._triggers:
            return False
        with self._lock:
            now = time.time()
            if now - self._hour_start > 3600:
                self._sent_count = 0
                self._hour_start = now
            if self._sent_count >= self._max_per_hour:
                return False
            if event_type:
                last = self._last_sent.get(event_type, 0)
                if now - last < self._throttle_minutes * 60:
                    return False
            try:
                msg = MIMEMultipart("alternative")
                msg["From"] = self._from
                msg["To"] = ", ".join(self._to)
                if self._cc:
                    msg["Cc"] = ", ".join(self._cc)
                msg["Subject"] = f"{self._prefix} {subject}"
                content_type = "html" if html else "plain"
                msg.attach(MIMEText(body, content_type))
                with smtplib.SMTP(self._smtp.host, self._smtp.port) as server:
                    if self._smtp.secure:
                        server.starttls()
                    if self._smtp.username and self._smtp.password:
                        server.login(self._smtp.username, self._smtp.password)
                    recipients = list(self._to) + list(self._cc or [])
                    server.sendmail(self._from, recipients, msg.as_string())
                self._sent_count += 1
                if event_type:
                    self._last_sent[event_type] = now
                return True
            except (smtplib.SMTPException, OSError):
                return False

    @property
    def enabled(self) -> bool:
        return self._enabled
