"""Challenge Service — Behavioral verification for suspicious IPs."""

from __future__ import annotations
import hashlib
import secrets
import threading
from datetime import datetime, timedelta
from .types import ChallengeConfig, BehaviorFingerprint, PendingChallenge, TrustedEntry


class ChallengeService:
    def __init__(self, config: ChallengeConfig | None = None):
        cfg = config or ChallengeConfig()
        self._enabled = cfg.enabled
        self._secret_key = cfg.secret_key or secrets.token_hex(32)
        self._trust_duration_hours = cfg.trust_duration_hours
        self._max_attempts = cfg.max_attempts_per_ip
        self._timeout_seconds = cfg.challenge_timeout_seconds
        self._exempt_reasons = cfg.exempt_reasons
        self._behavior = cfg.behavior
        self._pending: dict[str, PendingChallenge] = {}
        self._trusted: dict[str, TrustedEntry] = {}
        self._failed_ips: set[str] = set()
        self._lock = threading.Lock()
        self._cleanup_timer: threading.Timer | None = None

    def start(self) -> None:
        self._schedule_cleanup()

    def stop(self) -> None:
        if self._cleanup_timer:
            self._cleanup_timer.cancel()
            self._cleanup_timer = None

    def _schedule_cleanup(self) -> None:
        self._cleanup_expired()
        self._cleanup_timer = threading.Timer(60.0, self._schedule_cleanup)
        self._cleanup_timer.daemon = True
        self._cleanup_timer.start()

    def _cleanup_expired(self) -> None:
        now = datetime.now()
        with self._lock:
            expired_pending = [ip for ip, c in self._pending.items() if c.expires_at < now]
            for ip in expired_pending:
                del self._pending[ip]
            expired_trusted = [ip for ip, t in self._trusted.items() if t.expires_at < now]
            for ip in expired_trusted:
                del self._trusted[ip]

    @property
    def enabled(self) -> bool:
        return self._enabled

    def is_trusted(self, ip: str) -> bool:
        with self._lock:
            entry = self._trusted.get(ip)
            if entry and entry.expires_at > datetime.now():
                return True
            if entry:
                del self._trusted[ip]
            return False

    def should_challenge(self, ip: str, reason: str, subnet_under_attack: bool = False) -> bool:
        if not self._enabled:
            return False
        if ip in self._failed_ips:
            return False
        if any(r in reason.upper() for r in self._exempt_reasons):
            return False
        if subnet_under_attack:
            return True
        return True

    def create_challenge(self, ip: str, reason: str) -> str | None:
        if ip in self._failed_ips:
            return None
        with self._lock:
            existing = self._pending.get(ip)
            if existing and existing.attempts >= self._max_attempts:
                self._failed_ips.add(ip)
                return None
            token = hashlib.sha256(f"{ip}{self._secret_key}{secrets.token_hex(16)}".encode()).hexdigest()[:32]
            now = datetime.now()
            self._pending[ip] = PendingChallenge(
                ip=ip, token=token, block_reason=reason, created_at=now,
                expires_at=now + timedelta(seconds=self._timeout_seconds),
                attempts=(existing.attempts + 1) if existing else 0,
            )
            return token

    def verify_challenge(self, ip: str, token: str, fingerprint: BehaviorFingerprint,
                         client_score: int) -> dict:
        with self._lock:
            challenge = self._pending.get(ip)
            if not challenge:
                return {"success": False, "error": "No pending challenge"}
            if challenge.token != token:
                return {"success": False, "error": "Invalid token"}
            if challenge.expires_at < datetime.now():
                del self._pending[ip]
                return {"success": False, "error": "Challenge expired"}
            score = self._evaluate_behavior(fingerprint, client_score)
            if score < self._behavior.required_score:
                challenge.attempts += 1
                if challenge.attempts >= self._max_attempts:
                    self._failed_ips.add(ip)
                    del self._pending[ip]
                return {"success": False, "error": "Behavior check failed"}
            del self._pending[ip]
            trust_token = secrets.token_hex(16)
            expires = datetime.now() + timedelta(hours=self._trust_duration_hours)
            self._trusted[ip] = TrustedEntry(
                ip=ip, trust_time=datetime.now(), expires_at=expires,
                challenge_reason=challenge.block_reason, token=trust_token,
            )
            return {"success": True, "trust_token": trust_token, "expires_at": expires}

    def _evaluate_behavior(self, fp: BehaviorFingerprint, client_score: int) -> int:
        score = client_score
        if self._behavior.require_mouse_movement and fp.mouse_events < 3:
            score -= 30
        if fp.observation_time < self._behavior.min_observation_ms:
            score -= 20
        if fp.observation_time > self._behavior.max_observation_ms:
            score -= 10
        return max(0, min(100, score))

    def trust_ip(self, ip: str, reason: str = "Manual trust", hours: int = 24) -> None:
        with self._lock:
            self._trusted[ip] = TrustedEntry(
                ip=ip, trust_time=datetime.now(),
                expires_at=datetime.now() + timedelta(hours=hours),
                challenge_reason=reason, token=secrets.token_hex(16),
            )

    def untrust_ip(self, ip: str) -> None:
        with self._lock:
            self._trusted.pop(ip, None)

    def get_trusted_ips(self) -> list[TrustedEntry]:
        with self._lock:
            return list(self._trusted.values())

    def get_pending_challenge(self, ip: str) -> PendingChallenge | None:
        return self._pending.get(ip)

    def get_stats(self) -> dict:
        return {
            "pending": len(self._pending),
            "trusted": len(self._trusted),
            "failed": len(self._failed_ips),
        }
