"""Log Monitor — Real-time web server log file monitoring."""

from __future__ import annotations
import os
import threading
import time
from datetime import datetime
from .types import LogMonitorConfig, HttpRequest


class LogMonitor:
    def __init__(self, config: LogMonitorConfig | None = None):
        cfg = config or LogMonitorConfig()
        self._enabled = cfg.enabled
        self._log_path = cfg.log_path
        self._format = cfg.format
        self._poll_interval = cfg.poll_interval_ms / 1000
        self._encoding = cfg.encoding
        self._tail_lines = cfg.tail_lines
        self._position = 0
        self._timer: threading.Timer | None = None
        self._listeners: dict[str, list] = {}
        self._fields: list[str] = []

    def on(self, event: str, callback) -> None:
        self._listeners.setdefault(event, []).append(callback)

    def _emit(self, event: str, data=None) -> None:
        for cb in self._listeners.get(event, []):
            try:
                cb(data)
            except Exception:
                pass

    def start(self) -> None:
        if not self._enabled or not self._log_path:
            return
        if os.path.exists(self._log_path):
            self._position = os.path.getsize(self._log_path)
        self._schedule_poll()

    def stop(self) -> None:
        if self._timer:
            self._timer.cancel()
            self._timer = None

    def _schedule_poll(self) -> None:
        self._poll()
        self._timer = threading.Timer(self._poll_interval, self._schedule_poll)
        self._timer.daemon = True
        self._timer.start()

    def _poll(self) -> None:
        if not self._log_path or not os.path.exists(self._log_path):
            return
        try:
            size = os.path.getsize(self._log_path)
            if size < self._position:
                self._position = 0
            if size <= self._position:
                return
            with open(self._log_path, "r", encoding=self._encoding, errors="ignore") as f:
                f.seek(self._position)
                lines = f.readlines()
                self._position = f.tell()
            for line in lines:
                line = line.strip()
                if not line or line.startswith("#"):
                    if line.startswith("#Fields:"):
                        self._fields = line.split(":")[1].strip().split()
                    continue
                req = self._parse_line(line)
                if req:
                    self._emit("request", req)
        except OSError:
            pass

    def _parse_line(self, line: str) -> HttpRequest | None:
        if self._format == "w3c":
            return self._parse_w3c(line)
        elif self._format == "combined":
            return self._parse_combined(line)
        return None

    def _parse_w3c(self, line: str) -> HttpRequest | None:
        parts = line.split()
        if len(parts) < 5:
            return None
        try:
            field_map = {}
            for i, field in enumerate(self._fields or []):
                if i < len(parts):
                    field_map[field] = parts[i]
            return HttpRequest(
                timestamp=datetime.now(),
                client_ip=field_map.get("c-ip", field_map.get("s-ip", parts[2] if len(parts) > 2 else "0.0.0.0")),
                method=field_map.get("cs-method", parts[3] if len(parts) > 3 else "GET"),
                url=field_map.get("cs-uri-stem", parts[4] if len(parts) > 4 else "/"),
                status_code=int(field_map.get("sc-status", parts[5] if len(parts) > 5 else "200")),
                bytes_sent=int(field_map.get("sc-bytes", parts[6] if len(parts) > 6 else "0")),
                bytes_received=int(field_map.get("cs-bytes", "0")),
                user_agent=field_map.get("cs(User-Agent)", ""),
            )
        except (ValueError, IndexError):
            return None

    def _parse_combined(self, line: str) -> HttpRequest | None:
        import re
        m = re.match(r'(\S+) \S+ \S+ \[([^\]]+)\] "(\S+) (\S+)[^"]*" (\d+) (\d+|-) "([^"]*)" "([^"]*)"', line)
        if not m:
            return None
        try:
            return HttpRequest(
                timestamp=datetime.now(),
                client_ip=m.group(1),
                method=m.group(3),
                url=m.group(4),
                status_code=int(m.group(5)),
                bytes_sent=int(m.group(6)) if m.group(6) != "-" else 0,
                bytes_received=0,
                user_agent=m.group(8),
                referer=m.group(7),
            )
        except ValueError:
            return None
