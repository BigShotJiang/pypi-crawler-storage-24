"""CLI — Command-line interface for Qriton Shield."""

from __future__ import annotations
import argparse
import json
import signal
import sys
import time

from .shield import Shield
from .api_server import ApiServer
from .types import ShieldConfig, ApiServerConfig


def main():
    parser = argparse.ArgumentParser(
        prog="shield",
        description="Qriton Shield — Real-time IP threat intelligence with Hopfield AI",
    )
    parser.add_argument("-c", "--config", help="Path to config file (JSON)")
    parser.add_argument("-p", "--port", type=int, default=8765, help="API server port")
    parser.add_argument("-m", "--mode", choices=["relaxed", "balanced", "aggressive", "lockdown"],
                        default="balanced", help="Initial threat mode")
    parser.add_argument("-l", "--log", help="Log file to monitor")
    parser.add_argument("--state", help="Path for state persistence")
    parser.add_argument("--no-api", action="store_true", help="Disable API server")
    parser.add_argument("command", nargs="?", default="run",
                        choices=["run", "audit", "version"], help="Command to execute")
    args = parser.parse_args()

    if args.command == "version":
        print("Qriton Shield v3.2.1 (Python)")
        return

    config = ShieldConfig()
    if args.config:
        try:
            with open(args.config) as f:
                data = json.load(f)
            if "threat_mode" in data:
                config.threat_mode = data["threat_mode"]
            if "state_path" in data:
                config.state_path = data["state_path"]
        except (OSError, json.JSONDecodeError) as e:
            print(f"Error loading config: {e}", file=sys.stderr)
            sys.exit(1)

    config.threat_mode = args.mode
    if args.state:
        config.state_path = args.state

    shield = Shield(config)

    if args.command == "audit":
        report = shield.audit()
        print(f"\nQriton Shield Security Audit")
        print(f"{'=' * 40}")
        for check in report["checks"]:
            status = "PASS" if check["passed"] else "FAIL"
            print(f"  [{status}] {check['name']}: {check['message']}")
        print(f"\nScore: {report['score']}/100 (Grade: {report['grade']})")
        print(f"Summary: {report['summary']}")
        return

    # Run mode
    shield.on("block", lambda d: print(f"[BLOCK] {d['ip']} — {d['reason']}"))
    shield.on("rate_limit", lambda d: print(f"[RATE_LIMIT] {d['ip']} — {d['reason']}"))
    shield.on("mode_change", lambda d: print(f"[MODE] {d['from']} -> {d['to']} ({d['reason']})"))
    shield.on("anomaly", lambda d: print(f"[ANOMALY] Score: {d['score']:.1f}, Tier: {d['tier']}"))
    shield.on("subnet_ban", lambda d: print(f"[SUBNET_BAN] {d['range']} — {d['reason']}"))
    shield.on("trained", lambda d: print(f"[TRAINED] Hopfield network trained with {d['pattern_count']} patterns"))

    shield.start()
    print(f"Qriton Shield v3.2.1 started (mode: {shield.threat_mode})")

    api = None
    if not args.no_api:
        api_config = ApiServerConfig(enabled=True, port=args.port, host="127.0.0.1")
        api = ApiServer(shield, api_config)
        api.start()
        print(f"API server listening on http://127.0.0.1:{args.port}")

    if args.log:
        from .log_monitor import LogMonitor
        from .types import LogMonitorConfig
        monitor = LogMonitor(LogMonitorConfig(enabled=True, log_path=args.log))
        monitor.on("request", lambda req: shield.process_request(req))
        monitor.start()
        print(f"Monitoring log: {args.log}")

    def shutdown(*_):
        print("\nShutting down...")
        shield.stop()
        if api:
            api.stop()
        sys.exit(0)

    signal.signal(signal.SIGINT, shutdown)
    signal.signal(signal.SIGTERM, shutdown)
    print("Press Ctrl+C to stop")

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        shutdown()


if __name__ == "__main__":
    main()
