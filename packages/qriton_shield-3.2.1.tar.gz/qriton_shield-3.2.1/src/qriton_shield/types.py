"""Shield Types — Core type definitions for Qriton Shield."""

from __future__ import annotations
import re
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any, Callable, Literal, Protocol, runtime_checkable

# Feature types
FEATURE_NAMES: list[str] = [
    "connections_total", "syn_count", "established_count", "unique_ips",
    "connections_per_ip", "syn_ratio", "established_ratio", "requests_per_minute",
    "error_404_rate", "post_rate", "endpoint_entropy", "user_agent_variance",
    "geo_entropy", "interval_variance", "payload_size_avg", "dns_query_rate",
    "failed_connection_rate", "rare_port_ratio", "outbound_data_anomaly", "beaconing_score",
]

@dataclass
class FeatureRange:
    min: float
    max: float

DEFAULT_FEATURE_RANGES: dict[str, FeatureRange] = {
    "connections_total": FeatureRange(0, 10000),
    "syn_count": FeatureRange(0, 5000),
    "established_count": FeatureRange(0, 5000),
    "unique_ips": FeatureRange(0, 5000),
    "connections_per_ip": FeatureRange(0, 100),
    "syn_ratio": FeatureRange(0, 1),
    "established_ratio": FeatureRange(0, 1),
    "requests_per_minute": FeatureRange(0, 10000),
    "error_404_rate": FeatureRange(0, 1),
    "post_rate": FeatureRange(0, 1),
    "endpoint_entropy": FeatureRange(0, 10),
    "user_agent_variance": FeatureRange(0, 1),
    "geo_entropy": FeatureRange(0, 5),
    "interval_variance": FeatureRange(0, 1000),
    "payload_size_avg": FeatureRange(0, 100000),
    "dns_query_rate": FeatureRange(0, 500),
    "failed_connection_rate": FeatureRange(0, 1),
    "rare_port_ratio": FeatureRange(0, 1),
    "outbound_data_anomaly": FeatureRange(-5, 5),
    "beaconing_score": FeatureRange(0, 1),
}

# Use Literal for string union types
ThreatMode = Literal["relaxed", "balanced", "aggressive", "lockdown"]
ResponseTier = Literal["allow", "rate_limit", "challenge", "block"]
EnergyType = Literal["logsumexp", "quadratic"]
ConnectionState = Literal["SYN_SENT", "SYN_RECEIVED", "ESTABLISHED", "FIN_WAIT", "CLOSE_WAIT", "TIME_WAIT", "CLOSED"]
ThreatType = Literal["syn_flood", "http_flood", "slowloris", "botnet", "scanner", "scraper", "credential_stuffing", "blacklisted", "geo_blocked", "fingerprint_match", "manual", "unknown"]
LogFormat = Literal["w3c", "combined", "common", "json", "custom"]
FirewallPlatform = Literal["auto", "windows", "linux", "darwin", "custom"]
ReportFormat = Literal["html", "json", "csv", "text"]
ReportType = Literal["daily", "weekly", "monthly", "yearly", "custom"]
TrollResponse = Literal["rickroll", "tarpit", "fake_login", "redirect_loop", "fake_error", "slow_response", "garbage", "honeypot"]
WafCategory = Literal["sqli", "xss", "path_traversal", "cmd_injection", "header_injection", "custom"]
LayerDecision = Literal["allow", "deny", "rate_limit", "challenge", "continue"]
EntityType = Literal["human", "agent", "service", "unknown"]
CapabilityDomain = Literal["network", "filesystem", "process", "crypto", "env", "prompt", "tool", "memory"]
SemanticThreatClass = Literal["instruction_override", "tool_invocation", "exfiltration", "encoding_evasion", "memory_poisoning", "privilege_escalation", "chain_injection"]
EmailTrigger = Literal["block", "subnet_ban", "mode_change", "anomaly", "threshold_breach", "report_generated", "critical_memory", "exfiltration_detected"]

# Hopfield config
@dataclass
class HopfieldConfig:
    feature_count: int = 20
    snapshot_length: int = 5
    energy_type: EnergyType = "logsumexp"
    beta: float = 1.0
    learning_rate: float = 0.1
    convergence_threshold: float = 1e-6
    max_iterations: int = 100
    max_patterns: int = 200

@dataclass
class RecallResult:
    state: list[float]
    iterations: int
    converged: bool
    energy_path: list[float]
    final_energy: float

@dataclass
class PatternComposition:
    pattern_index: int
    similarity: float
    percentage: float

@dataclass
class FeatureImpact:
    name: str
    index: int
    value: float
    contribution: float
    energy_delta: float

@dataclass
class BaselineStats:
    energy: dict  # {mean, std}
    gradient_norm: dict  # {mean, std}
    max_composition: dict  # {mean, std}

@dataclass
class AnomalyResult:
    is_anomaly: bool
    anomaly_score: float
    normalized_score: float
    confidence: float
    metrics: dict
    feature_impact: list[FeatureImpact]
    composition: list[PatternComposition]
    processing_time_ms: float

@dataclass
class FederatedModel:
    patterns: list[list[float]]
    baseline: BaselineStats | None
    threshold: float
    data_points_processed: int
    pattern_size: int
    feature_count: int

# Threat mode profiles
@dataclass
class ThreatModeProfile:
    anomaly_threshold: float
    syn_timeout: int
    learning_threshold: int
    subnet_threshold: int
    http_requests_per_minute: int
    http_404_threshold: int
    http_post_threshold: int

THREAT_MODE_PROFILES: dict[str, ThreatModeProfile] = {
    "relaxed": ThreatModeProfile(0.8, 60, 100, 50, 500, 100, 200),
    "balanced": ThreatModeProfile(0.6, 45, 50, 25, 300, 50, 100),
    "aggressive": ThreatModeProfile(0.4, 10, 20, 10, 100, 20, 50),
    "lockdown": ThreatModeProfile(0.2, 5, 10, 5, 30, 10, 20),
}

THREAT_TYPE_SEVERITY: dict[str, int] = {
    "syn_flood": 90, "http_flood": 85, "slowloris": 80, "botnet": 95,
    "scanner": 60, "scraper": 50, "credential_stuffing": 88, "blacklisted": 100,
    "geo_blocked": 70, "fingerprint_match": 75, "manual": 100, "unknown": 50,
}

# Request types
@dataclass
class HttpRequest:
    timestamp: datetime
    client_ip: str
    method: str
    url: str
    status_code: int
    bytes_sent: int
    bytes_received: int
    user_agent: str = ""
    referer: str = ""
    country: str = ""

@dataclass
class ConnectionInfo:
    source_ip: str
    source_port: int
    dest_port: int
    state: ConnectionState
    timestamp: datetime

# Traffic features
@dataclass
class TrafficFeatures:
    connections_total: int = 0
    syn_count: int = 0
    established_count: int = 0
    unique_ips: int = 0
    connections_per_ip: float = 0.0
    syn_ratio: float = 0.0
    established_ratio: float = 0.0
    requests_per_minute: int = 0
    error_404_rate: float = 0.0
    post_rate: float = 0.0
    endpoint_entropy: float = 0.0
    user_agent_variance: float = 0.0
    geo_entropy: float = 0.0
    interval_variance: float = 0.0
    payload_size_avg: float = 0.0
    dns_query_rate: float = 0.0
    failed_connection_rate: float = 0.0
    rare_port_ratio: float = 0.0
    outbound_data_anomaly: float = 0.0
    beaconing_score: float = 0.0

# Shield types
@dataclass
class ThreatProfile:
    ip: str
    total_connections: int = 0
    syn_count: int = 0
    established_count: int = 0
    first_seen: datetime = field(default_factory=datetime.now)
    last_seen: datetime = field(default_factory=datetime.now)
    connection_times: list[datetime] = field(default_factory=list)
    ports_accessed: set[int] = field(default_factory=set)
    block_count: int = 0
    threat_score: float = 0.0
    anomaly_score: float = 0.0
    hopfield_score: float = 0.0
    threat_type: str | None = None
    is_rate_limited: bool = False
    is_blocked: bool = False
    http_401_count: int = 0
    http_post_count: int = 0
    http_404_count: int = 0
    rpm_history: list[dict] = field(default_factory=list)

@dataclass
class DetectionResult:
    decision: ResponseTier
    tier: int
    anomaly_score: float
    threat_score: float
    reason: str
    feature_impact: list[FeatureImpact]
    threat_mode: ThreatMode
    processing_time_ms: float
    subnet_action: dict | None = None

@dataclass
class SubnetInfo:
    range: str
    blocked_ips: list[str]
    block_time: datetime
    reason: str

@dataclass
class ShieldStats:
    ips_tracked: int
    ips_blocked: int
    ips_rate_limited: int
    subnets_banned: int
    total_requests: int
    anomalies_detected: int
    current_threat_mode: ThreatMode
    hopfield_trained: bool
    pattern_count: int
    uptime: float

# Configuration types
@dataclass
class NightModeConfig:
    enabled: bool = False
    start_hour: int = 22
    end_hour: int = 6
    minimum_mode: ThreatMode = "balanced"

@dataclass
class AutoModeConfig:
    enabled: bool = True
    escalate_threshold: int = 50
    deescalate_threshold: int = 10
    escalate_cooldown_minutes: int = 5
    deescalate_cooldown_minutes: int = 15
    max_auto_mode: ThreatMode = "aggressive"

@dataclass
class SubnetBlockingConfig:
    enabled: bool = True
    velocity_window_seconds: int = 60
    velocity_threshold: int = 3

@dataclass
class FirewallConfig:
    enabled: bool = False
    platform: FirewallPlatform = "auto"
    chain_name: str = "SHIELD"
    rule_prefix: str = "shield_block_"
    block_timeout_seconds: int = 3600
    max_rules: int = 10000
    custom_block_command: str | None = None
    custom_unblock_command: str | None = None

@dataclass
class LogMonitorConfig:
    enabled: bool = False
    log_path: str | None = None
    format: LogFormat = "w3c"
    poll_interval_ms: int = 1000
    encoding: str = "utf-8"
    tail_lines: int = 100

@dataclass
class MemoryConfig:
    enabled: bool = True
    warning_threshold_mb: int = 500
    critical_threshold_mb: int = 800
    check_interval_ms: int = 30000
    auto_cleanup: bool = True
    cleanup_target_mb: int = 400

@dataclass
class TrollConfig:
    enabled: bool = False
    responses: list[str] = field(default_factory=lambda: ["tarpit", "slow_response", "rickroll"])
    probability: float = 1.0
    min_delay_ms: int = 5000
    max_delay_ms: int = 30000
    tarpit_bytes_per_second: int = 10
    honeypot_paths: list[str] = field(default_factory=lambda: ["/admin", "/wp-admin", "/phpmyadmin", "/.env", "/config"])
    rickroll_url: str = "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
    capture_credentials: bool = False
    credential_log_path: str | None = None

@dataclass
class GeoConfig:
    enabled: bool = False
    whitelist: list[str] = field(default_factory=list)
    blacklist: list[str] = field(default_factory=list)
    high_risk_countries: list[str] = field(default_factory=lambda: ["CN", "RU", "KP", "IR"])
    high_risk_multiplier: float = 1.5
    default_action: str = "allow"
    geo_db_path: str | None = None
    lookup_service: str = "local"

@dataclass
class BlacklistSource:
    name: str
    url: str
    format: str
    enabled: bool

DEFAULT_BLACKLIST_SOURCES: list[BlacklistSource] = [
    BlacklistSource("spamhaus_drop", "https://www.spamhaus.org/drop/drop.txt", "cidr", True),
    BlacklistSource("spamhaus_edrop", "https://www.spamhaus.org/drop/edrop.txt", "cidr", True),
    BlacklistSource("firehol_level1", "https://raw.githubusercontent.com/firehol/blocklist-ipsets/master/firehol_level1.netset", "cidr", True),
]

@dataclass
class BlacklistConfig:
    enabled: bool = False
    sources: list[BlacklistSource] = field(default_factory=lambda: list(DEFAULT_BLACKLIST_SOURCES))
    update_interval_ms: int = 3600000
    max_entries: int = 100000
    custom_blacklist: list[str] = field(default_factory=list)

@dataclass
class WhitelistProvider:
    name: str
    ranges: list[str]
    enabled: bool

DEFAULT_CDN_PROVIDERS: list[WhitelistProvider] = [
    WhitelistProvider("cloudflare", [
        "173.245.48.0/20", "103.21.244.0/22", "103.22.200.0/22", "103.31.4.0/22",
        "141.101.64.0/18", "108.162.192.0/18", "190.93.240.0/20", "188.114.96.0/20",
        "197.234.240.0/22", "198.41.128.0/17", "162.158.0.0/15", "104.16.0.0/13",
        "104.24.0.0/14", "172.64.0.0/13", "131.0.72.0/22",
    ], True),
    WhitelistProvider("google", ["35.190.0.0/16", "35.191.0.0/16", "130.211.0.0/22", "35.220.0.0/14"], True),
    WhitelistProvider("aws_cloudfront", [
        "13.32.0.0/15", "13.35.0.0/16", "52.46.0.0/18", "52.84.0.0/15",
        "54.182.0.0/16", "54.192.0.0/16", "54.230.0.0/17", "54.239.128.0/18",
        "70.132.0.0/18", "99.84.0.0/16", "143.204.0.0/16", "204.246.164.0/22",
        "204.246.168.0/22", "205.251.192.0/19", "216.137.32.0/19",
    ], True),
    WhitelistProvider("fastly", [
        "23.235.32.0/20", "43.249.72.0/22", "103.244.50.0/24", "103.245.222.0/23",
        "103.245.224.0/24", "104.156.80.0/20", "151.101.0.0/16",
    ], True),
]

@dataclass
class WhitelistConfig:
    enabled: bool = True
    providers: list[WhitelistProvider] = field(default_factory=lambda: list(DEFAULT_CDN_PROVIDERS))
    custom_ranges: list[str] = field(default_factory=list)
    auto_update: bool = False
    update_interval_ms: int = 86400000
    bypass_all_checks: bool = False

@dataclass
class FingerprintConfig:
    enabled: bool = True
    threshold: int = 10
    window_seconds: int = 60
    hash_fields: list[str] = field(default_factory=lambda: ["method", "url", "user_agent"])
    max_fingerprints: int = 10000
    botnet_threshold: int = 5

@dataclass
class ProxyConfig:
    trust_proxy: bool = False
    trusted_proxies: list[str] = field(default_factory=list)
    header_priority: list[str] = field(default_factory=lambda: ["cf-connecting-ip", "x-real-ip", "x-forwarded-for"])
    max_forwarded_ips: int = 1

@dataclass
class ApiServerConfig:
    enabled: bool = False
    port: int = 8765
    host: str = "127.0.0.1"
    auth_token: str | None = None
    enable_cors: bool = False
    cors_origins: list[str] = field(default_factory=list)
    rate_limit_requests: int = 100
    rate_limit_window_ms: int = 60000

@dataclass
class ReportSchedule:
    type: ReportType
    enabled: bool
    hour: int = 0
    day_of_week: int | None = None
    day_of_month: int | None = None

@dataclass
class ReportConfig:
    enabled: bool = False
    output_dir: str = "./reports"
    formats: list[str] = field(default_factory=lambda: ["html", "json"])
    schedules: list[ReportSchedule] = field(default_factory=lambda: [
        ReportSchedule("daily", True, 0),
        ReportSchedule("weekly", True, 0, day_of_week=0),
        ReportSchedule("monthly", False, 0, day_of_month=1),
    ])
    retention_days: int = 90
    include_hopfield_state: bool = True
    include_top_threats: int = 20
    include_geo_breakdown: bool = True

@dataclass
class SmtpConfig:
    host: str = ""
    port: int = 587
    secure: bool = True
    username: str = ""
    password: str = ""

@dataclass
class EmailConfig:
    enabled: bool = False
    smtp: SmtpConfig = field(default_factory=SmtpConfig)
    from_addr: str = "shield@localhost"
    to: list[str] = field(default_factory=list)
    cc: list[str] = field(default_factory=list)
    subject_prefix: str = "[SHIELD]"
    triggers: list[str] = field(default_factory=lambda: ["block", "subnet_ban", "mode_change", "exfiltration_detected"])
    throttle_minutes: int = 5
    batch_interval_seconds: int = 30
    max_emails_per_hour: int = 50

@dataclass
class DasDataConfig:
    enabled: bool = False
    api_endpoint: str = "https://shield.qriton.com"
    shield_id: str = ""
    api_key: str = ""
    secret_key: str = ""
    organization_id: str = ""
    batch_size: int = 50
    batch_interval_seconds: int = 10
    report_types: list[str] = field(default_factory=lambda: ["syn_flood", "http_flood", "botnet", "scanner", "credential_stuffing", "blacklisted", "unknown"])
    include_request_details: bool = True
    include_geo_data: bool = True
    retry_attempts: int = 3
    retry_delay_ms: int = 1000
    timeout: int = 30000

@dataclass
class SensitivePattern:
    name: str
    pattern: str
    severity: str
    action: str

DEFAULT_SENSITIVE_PATTERNS: list[SensitivePattern] = [
    SensitivePattern("credit_card", r"\b(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|3[47][0-9]{13})\b", "critical", "block"),
    SensitivePattern("ssn", r"\b\d{3}-\d{2}-\d{4}\b", "critical", "block"),
    SensitivePattern("api_key", r'(?:api[_-]?key|apikey)[\s]*[=:][\s]*["\']?([a-zA-Z0-9_\-]{20,})', "high", "alert"),
    SensitivePattern("aws_key", r"AKIA[0-9A-Z]{16}", "critical", "block"),
    SensitivePattern("private_key", r"-----BEGIN (?:RSA |EC |DSA |OPENSSH )?PRIVATE KEY-----", "critical", "block"),
    SensitivePattern("password_field", r'(?:password|passwd|pwd)[\s]*[=:][\s]*["\']?([^"\'\s]{8,})', "high", "alert"),
    SensitivePattern("bearer_token", r"Bearer\s+[a-zA-Z0-9_\-\.]+", "high", "alert"),
    SensitivePattern("jwt_token", r"eyJ[a-zA-Z0-9_-]*\.eyJ[a-zA-Z0-9_-]*\.[a-zA-Z0-9_-]*", "high", "alert"),
    SensitivePattern("database_url", r"(?:mysql|postgres|mongodb|redis)://[^\s]+", "high", "alert"),
    SensitivePattern("email_list", r"([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}[,;\s]){5,}", "medium", "log"),
    SensitivePattern("base64_large", r"(?:[A-Za-z0-9+/]{4}){100,}(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?", "medium", "log"),
]

@dataclass
class ExfiltrationConfig:
    enabled: bool = False
    monitor_outbound: bool = True
    monitor_files: bool = False
    sensitive_patterns: list[SensitivePattern] = field(default_factory=lambda: list(DEFAULT_SENSITIVE_PATTERNS))
    sensitive_file_extensions: list[str] = field(default_factory=lambda: [".env", ".pem", ".key", ".pfx", ".p12", ".sql", ".bak", ".dump"])
    whitelist_destinations: list[str] = field(default_factory=list)
    max_payload_scan_bytes: int = 1048576
    alert_threshold: int = 3
    block_on_detection: bool = False
    log_path: str | None = None

@dataclass
class BehaviorSettings:
    required_score: int = 70
    min_observation_ms: int = 2000
    max_observation_ms: int = 30000
    require_mouse_movement: bool = True
    require_natural_path: bool = True

@dataclass
class ChallengeConfig:
    enabled: bool = True
    secret_key: str = ""
    trust_duration_hours: int = 24
    max_attempts_per_ip: int = 5
    challenge_timeout_seconds: int = 30
    exempt_reasons: list[str] = field(default_factory=lambda: ["BLACKLIST", "BOTNET", "BRUTE_FORCE", "HTTP_FLOOD", "SCANNER", "PORT_SCAN"])
    behavior: BehaviorSettings = field(default_factory=BehaviorSettings)

@dataclass
class WafConfig:
    enabled: bool = True
    block_on_match: bool = True
    custom_patterns: list[str] = field(default_factory=list)

@dataclass
class FederatedConfig:
    enabled: bool = False
    sync_interval_minutes: int = 30
    local_weight: float = 0.7
    remote_weight: float = 0.3

# WAF types
@dataclass
class WafRule:
    name: str
    category: WafCategory
    pattern: re.Pattern
    score: int

@dataclass
class WafMatch:
    rule_name: str
    category: WafCategory
    score: int
    matched_value: str

# Challenge types
@dataclass
class BehaviorFingerprint:
    screen: str
    timezone: str
    language: str
    platform: str
    mouse_events: int
    scroll_events: int
    observation_time: int
    score: int

@dataclass
class PendingChallenge:
    ip: str
    token: str
    block_reason: str
    created_at: datetime
    expires_at: datetime
    attempts: int = 0
    completed: bool = False

@dataclass
class TrustedEntry:
    ip: str
    trust_time: datetime
    expires_at: datetime
    challenge_reason: str
    token: str

# v2 Layer types
@dataclass
class LayerSignal:
    layer: int
    name: str
    decision: LayerDecision
    score: float
    confidence: float
    reason: str
    tags: list[str]
    latency_ms: float
    metadata: dict[str, Any] | None = None

@dataclass
class RequestContext:
    id: str
    timestamp: datetime
    client_ip: str
    method: str
    url: str
    headers: dict[str, str]
    body: str | None = None
    status_code: int | None = None
    bytes_sent: int | None = None
    bytes_received: int | None = None
    user_agent: str | None = None
    country: str | None = None
    entity_id: str | None = None
    entity_type: EntityType | None = None
    capabilities: list | None = None

@dataclass
class Explainability:
    dominant_layer: int
    dominant_signal: str
    feature_impact: list[FeatureImpact]
    layer_latencies: dict[str, float]

@dataclass
class ShieldDecision:
    action: ResponseTier
    tier: int
    signals: list[LayerSignal]
    aggregate_score: float
    confidence: float
    reason: str
    tags: list[str]
    threat_mode: ThreatMode
    processing_time_ms: float
    audit_hash: str | None = None
    explainability: Explainability | None = None

@runtime_checkable
class ShieldLayer(Protocol):
    @property
    def name(self) -> str: ...
    @property
    def layer(self) -> int: ...
    @property
    def enabled(self) -> bool: ...
    @enabled.setter
    def enabled(self, value: bool) -> None: ...
    def evaluate(self, ctx: RequestContext) -> LayerSignal | None: ...

# Entity/Capability types
@dataclass
class EntityProfile:
    id: str
    type: EntityType
    registered_at: datetime
    last_seen: datetime
    request_count: int = 0
    behavior_baseline: dict = field(default_factory=lambda: {
        "avg_requests_per_minute": 0, "typical_methods": [], "typical_paths": [], "avg_payload_size": 0
    })
    trust_score: float = 0.5
    tags: list[str] = field(default_factory=list)

@dataclass
class Capability:
    domain: CapabilityDomain
    action: str
    granted_to: str
    granted_at: datetime
    resource: str | None = None
    expires_at: datetime | None = None

# Audit types
@dataclass
class AuditEntry:
    timestamp: str
    id: str
    action: str
    decision: str
    client_ip: str
    signals: list[LayerSignal]
    score: float
    prev_hash: str
    hash: str

@dataclass
class AuditCheck:
    id: str
    name: str
    category: str
    severity: str
    passed: bool
    message: str
    details: dict[str, Any] | None = None

@dataclass
class AuditReport:
    timestamp: str
    checks: list[AuditCheck]
    score: int
    grade: str
    summary: str

# Semantic types
@dataclass
class SemanticSignature:
    id: str
    threat_class: SemanticThreatClass
    severity: str
    pattern: re.Pattern

@dataclass
class SemanticMatch:
    signature_id: str
    threat_class: SemanticThreatClass
    severity: str
    matched_text: str
    position: int

@dataclass
class SemanticAnalysis:
    detected: bool
    score: float
    decision: str
    matches: list[SemanticMatch]
    source: str
    latency_ms: float
    requires_hlm: bool = False

# LocalhostGuard types
@dataclass
class LocalhostGuardConfig:
    allow_origins: list[str | None] = field(default_factory=lambda: [None, "file://"])
    max_auth_attempts: int = 5
    lockout_seconds: int = 300
    rate_limit_per_second: int = 10
    upgrade_rate_limit_per_second: int = 3
    max_concurrent_connections: int = 20
    max_tracked_sources: int = 1000
    state_eviction_ms: int = 600000
    require_device_approval: bool = False

# MCP Guard types
@dataclass
class MCPGuardConfig:
    enabled: bool = True
    audit_log_path: str | None = None
    block_on_threat: bool = True
    semantic_threshold: float = 0.7

# Consolidated Shield config
@dataclass
class ShieldConfig:
    threat_mode: ThreatMode = "balanced"
    max_threat_profiles: int = 5000
    stale_profile_minutes: int = 10
    state_path: str | None = None
    save_interval_ms: int = 300000
    night_mode: NightModeConfig = field(default_factory=NightModeConfig)
    auto_mode: AutoModeConfig = field(default_factory=AutoModeConfig)
    subnet_blocking: SubnetBlockingConfig = field(default_factory=SubnetBlockingConfig)
    feature_ranges: dict[str, FeatureRange] = field(default_factory=dict)
    firewall: FirewallConfig = field(default_factory=FirewallConfig)
    log_monitor: LogMonitorConfig = field(default_factory=LogMonitorConfig)
    memory: MemoryConfig = field(default_factory=MemoryConfig)
    troll: TrollConfig = field(default_factory=TrollConfig)
    geo: GeoConfig = field(default_factory=GeoConfig)
    blacklist: BlacklistConfig = field(default_factory=BlacklistConfig)
    whitelist: WhitelistConfig = field(default_factory=WhitelistConfig)
    fingerprint: FingerprintConfig = field(default_factory=FingerprintConfig)
    proxy: ProxyConfig = field(default_factory=ProxyConfig)
    api_server: ApiServerConfig = field(default_factory=ApiServerConfig)
    reports: ReportConfig = field(default_factory=ReportConfig)
    email: EmailConfig = field(default_factory=EmailConfig)
    das_data: DasDataConfig = field(default_factory=DasDataConfig)
    exfiltration: ExfiltrationConfig = field(default_factory=ExfiltrationConfig)
    challenge: ChallengeConfig = field(default_factory=ChallengeConfig)
    waf: WafConfig = field(default_factory=WafConfig)
    federated: FederatedConfig = field(default_factory=FederatedConfig)
    audit_log_path: str | None = None
