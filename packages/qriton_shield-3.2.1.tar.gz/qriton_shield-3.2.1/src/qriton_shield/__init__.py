"""
Qriton Shield — Real-time IP threat intelligence with Modern Hopfield Networks.

Usage:
    from qriton_shield import Shield

    shield = Shield()
    shield.start()
    result = shield.process_request(request)
"""

__version__ = "3.2.1"

# Core
from .shield import Shield
from .hopfield import ContinuousHopfieldNetwork
from .detector import HopfieldAnomalyDetector
from .features import (
    TrafficFeatureExtractor,
    calculate_entropy,
    calculate_interval_variance,
    get_subnet,
    is_ip_in_range,
    is_valid_ip,
    extract_real_ip,
    enrich_request,
)

# Security modules
from .waf import WafEngine
from .firewall import FirewallManager
from .blacklists import BlacklistManager
from .whitelist import WhitelistManager
from .fingerprint import FingerprintDetector
from .geo import GeoFencing
from .challenge import ChallengeService

# Monitoring
from .dasdata import DasDataReporter
from .log_monitor import LogMonitor
from .exfiltration import ExfiltrationMonitor
from .memory import MemoryManager

# Reporting
from .report import ReportGenerator
from .email_notifier import EmailNotifier
from .audit import AuditLog

# Protection
from .troll import TrollMode
from .localhost_guard import LocalhostGuard, localhost_guard
from .mcp_guard import MCPGuard

# Supply chain
from .supply_chain import SupplyChainScanner, ScanResult, ScanFinding

# API
from .api_server import ApiServer

# v2 Layer Architecture
from .layers import (
    LayerPipeline,
    PipelineResult,
    DecisionEngine,
    L1NetworkLayer,
    L2TransportLayer,
    L3IdentityLayer,
    L4CapabilityLayer,
    L5SemanticLayer,
    L6StateLayer,
    L7CollectiveLayer,
)

# Types
from .types import (
    FEATURE_NAMES,
    DEFAULT_FEATURE_RANGES,
    THREAT_MODE_PROFILES,
    THREAT_TYPE_SEVERITY,
    FeatureRange,
    TrafficFeatures,
    HopfieldConfig,
    RecallResult,
    PatternComposition,
    FeatureImpact,
    BaselineStats,
    AnomalyResult,
    FederatedModel,
    ThreatMode,
    ResponseTier,
    ThreatModeProfile,
    ThreatProfile,
    DetectionResult,
    SubnetInfo,
    ShieldStats,
    HttpRequest,
    ConnectionInfo,
    ShieldConfig,
    NightModeConfig,
    AutoModeConfig,
    SubnetBlockingConfig,
    FirewallConfig,
    LogMonitorConfig,
    MemoryConfig,
    TrollConfig,
    GeoConfig,
    BlacklistConfig,
    WhitelistConfig,
    FingerprintConfig,
    ProxyConfig,
    ApiServerConfig,
    ReportConfig,
    EmailConfig,
    DasDataConfig,
    ExfiltrationConfig,
    ChallengeConfig,
    WafConfig,
    FederatedConfig,
    WafMatch,
    BehaviorFingerprint,
    PendingChallenge,
    TrustedEntry,
    LayerSignal,
    RequestContext,
    ShieldDecision,
    MCPGuardConfig,
    LocalhostGuardConfig,
    AuditEntry,
    AuditReport,
)

__all__ = [
    "Shield",
    "ContinuousHopfieldNetwork",
    "HopfieldAnomalyDetector",
    "TrafficFeatureExtractor",
    "WafEngine",
    "FirewallManager",
    "BlacklistManager",
    "WhitelistManager",
    "FingerprintDetector",
    "GeoFencing",
    "ChallengeService",
    "DasDataReporter",
    "LogMonitor",
    "ExfiltrationMonitor",
    "MemoryManager",
    "ReportGenerator",
    "EmailNotifier",
    "AuditLog",
    "TrollMode",
    "LocalhostGuard",
    "localhost_guard",
    "MCPGuard",
    "SupplyChainScanner",
    "ApiServer",
    "LayerPipeline",
    "DecisionEngine",
    "L1NetworkLayer",
    "L2TransportLayer",
    "L3IdentityLayer",
    "L4CapabilityLayer",
    "L5SemanticLayer",
    "L6StateLayer",
    "L7CollectiveLayer",
]
