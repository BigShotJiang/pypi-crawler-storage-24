"""Shield — Traffic Defense System with Modern Hopfield Networks."""

from __future__ import annotations
import json
import os
import threading
import time
import uuid
from datetime import datetime
from pathlib import Path

from .detector import HopfieldAnomalyDetector
from .features import TrafficFeatureExtractor, get_subnet
from .whitelist import WhitelistManager
from .challenge import ChallengeService
from .waf import WafEngine
from .types import (
    ShieldConfig, ShieldStats, ThreatMode, ResponseTier, DetectionResult,
    ThreatProfile, SubnetInfo, HttpRequest, ConnectionInfo, FeatureImpact,
    BehaviorFingerprint, TrustedEntry, HopfieldConfig,
    THREAT_MODE_PROFILES,
)

THREAT_MODES: list[ThreatMode] = ["relaxed", "balanced", "aggressive", "lockdown"]


class Shield:
    def __init__(self, config: ShieldConfig | None = None):
        cfg = config or ShieldConfig()
        self._config = cfg
        self._current_mode: ThreatMode = cfg.threat_mode
        self._detector = HopfieldAnomalyDetector(HopfieldConfig(feature_count=20, snapshot_length=5))
        self._detector.train_canonical_patterns(HopfieldAnomalyDetector.get_canonical_patterns())
        self._feature_extractor = TrafficFeatureExtractor(60000)
        self._waf = WafEngine(cfg.waf)
        self._whitelist = WhitelistManager(cfg.whitelist)
        self._challenge = ChallengeService(cfg.challenge)
        self._training_patterns: list[list[float]] = []
        self._auto_train_threshold = 50
        self._threat_profiles: dict[str, ThreatProfile] = {}
        self._blocked_ips: set[str] = set()
        self._rate_limited_ips: dict[str, dict] = {}
        self._banned_subnets: dict[str, SubnetInfo] = {}
        self._subnet_velocity: dict[str, list[datetime]] = {}
        self._recent_blocks: list[datetime] = []
        self._cross_subnet_window: dict[str, float] = {}
        self._start_time: datetime | None = None
        self._is_running = False
        self._last_mode_change = datetime.now()
        self._state_path = cfg.state_path
        self._save_interval_ms = cfg.save_interval_ms
        self._listeners: dict[str, list] = {}
        self._cleanup_timer: threading.Timer | None = None
        self._save_timer: threading.Timer | None = None
        if self._state_path:
            self._load_state()

    def on(self, event: str, callback) -> None:
        self._listeners.setdefault(event, []).append(callback)

    def emit(self, event: str, data=None) -> None:
        for cb in self._listeners.get(event, []):
            try:
                cb(data)
            except Exception:
                pass

    def start(self) -> None:
        if self._is_running:
            return
        self._is_running = True
        self._start_time = datetime.now()
        self._schedule_cleanup()
        if self._state_path:
            self._schedule_save()
        self._challenge.start()
        self.emit("started")

    def stop(self) -> None:
        if not self._is_running:
            return
        self._is_running = False
        if self._cleanup_timer:
            self._cleanup_timer.cancel()
        if self._save_timer:
            self._save_timer.cancel()
        if self._state_path:
            self.save_state()
        self._challenge.stop()
        self.emit("stopped")

    def _schedule_cleanup(self) -> None:
        self._cleanup_stale_profiles()
        self._cleanup_timer = threading.Timer(60.0, self._schedule_cleanup)
        self._cleanup_timer.daemon = True
        self._cleanup_timer.start()

    def _schedule_save(self) -> None:
        self.save_state()
        self._save_timer = threading.Timer(self._save_interval_ms / 1000, self._schedule_save)
        self._save_timer.daemon = True
        self._save_timer.start()

    def train(self, patterns: list[list[float]]) -> None:
        self._detector.train(patterns)

    def process_request(self, request: HttpRequest) -> DetectionResult:
        start = time.perf_counter()
        self._feature_extractor.add_request(request)
        if self._whitelist.should_bypass_checks(request.client_ip):
            return self._create_result("allow", 0, 0, 0, "Whitelisted IP", [], start)
        if self._challenge.is_trusted(request.client_ip):
            return self._create_result("allow", 0, 0, 0, "Trusted IP (passed challenge)", [], start)
        if self.is_blocked(request.client_ip):
            return self._create_result("block", 3, 100, 100, "IP is blocked", [], start)
        subnet = get_subnet(request.client_ip)
        if subnet in self._banned_subnets:
            return self._create_result("block", 3, 100, 100, "Subnet is banned", [], start)
        profile = self._get_or_create_profile(request.client_ip)
        profile.last_seen = request.timestamp
        profile.total_connections += 1
        profile.connection_times.append(request.timestamp)
        if request.method.upper() == "POST":
            profile.http_post_count += 1
        if request.status_code in (401, 403):
            profile.http_401_count += 1
        if request.status_code == 404:
            profile.http_404_count += 1
        now_ms = time.time() * 1000
        current_rpm = sum(1 for t in profile.connection_times if (now_ms - t.timestamp() * 1000) < 60000)
        if not profile.rpm_history or (now_ms - profile.rpm_history[-1]["time"]) >= 5000:
            profile.rpm_history.append({"time": now_ms, "rpm": current_rpm})
            if len(profile.rpm_history) > 10:
                profile.rpm_history.pop(0)
        threat_score = self._compute_threat_score(profile, request)
        profile.threat_score = threat_score
        features = self._feature_extractor.extract_array()
        ready = self._detector.add_data_point(features)
        anomaly_score = 0.0
        feature_impact: list[FeatureImpact] = []
        if not self._detector.is_trained and threat_score < 30:
            self._training_patterns.append(features)
            if len(self._training_patterns) >= self._auto_train_threshold:
                self._detector.train(self._training_patterns)
                self.emit("trained", {"pattern_count": len(self._training_patterns)})
                self._training_patterns.clear()
        if ready and self._detector.is_trained:
            anomaly_result = self._detector.detect()
            anomaly_score = anomaly_result.normalized_score
            feature_impact = anomaly_result.feature_impact
            profile.hopfield_score = anomaly_score
            profile.anomaly_score = anomaly_result.anomaly_score
            if anomaly_result.is_anomaly:
                self.emit("anomaly", {"score": anomaly_score, "tier": self._get_hopfield_tier(anomaly_score)})
        tier, decision, reason = self._determine_response(threat_score, anomaly_score, profile)
        self._execute_response(decision, profile, reason, threat_score)
        self._check_night_mode()
        self._check_auto_mode_switch()
        return self._create_result(decision, tier, anomaly_score, threat_score, reason, feature_impact, start)

    def process_connection(self, conn: ConnectionInfo) -> None:
        self._feature_extractor.add_connection(conn)
        profile = self._get_or_create_profile(conn.source_ip)
        profile.last_seen = conn.timestamp
        profile.total_connections += 1
        profile.ports_accessed.add(conn.dest_port)
        if conn.state == "SYN_RECEIVED":
            profile.syn_count += 1
        elif conn.state == "ESTABLISHED":
            profile.established_count += 1

    def _determine_response(self, threat_score: float, anomaly_score: float,
                            _profile: ThreatProfile) -> tuple[int, ResponseTier, str]:
        combined = max(threat_score, anomaly_score)
        if combined < 30:
            return 0, "allow", "Normal traffic"
        if combined < 60:
            return 1, "rate_limit", f"Elevated score: {combined:.1f}"
        if combined < 80:
            return 2, "challenge", f"High score: {combined:.1f}"
        return 3, "block", f"Critical score: {combined:.1f}"

    def _execute_response(self, decision: ResponseTier, profile: ThreatProfile,
                          reason: str, score: float) -> None:
        ip = profile.ip
        if decision == "rate_limit":
            if not profile.is_rate_limited:
                profile.is_rate_limited = True
                self._rate_limited_ips[ip] = {"count": 0, "reset_time": time.time() + 60}
                self.emit("rate_limit", {"ip": ip, "reason": reason, "score": score})
        elif decision == "challenge":
            if self._challenge.enabled:
                token = self._challenge.create_challenge(ip, reason)
                self.emit("challenge", {"ip": ip, "reason": reason, "score": score, "token": token})
            else:
                profile.threat_score *= 1.5
                self.emit("challenge", {"ip": ip, "reason": reason, "score": score})
        elif decision == "block":
            if not profile.is_blocked:
                profile.is_blocked = True
                profile.block_count += 1
                self._blocked_ips.add(ip)
                self._recent_blocks.append(datetime.now())
                self.emit("block", {"ip": ip, "reason": reason, "score": score})
                self._check_subnet_velocity(ip)

    def _compute_threat_score(self, profile: ThreatProfile, request: HttpRequest) -> float:
        score = 0.0
        mode_profile = THREAT_MODE_PROFILES[self._current_mode]
        now_ms = time.time() * 1000
        recent_requests = sum(1 for t in profile.connection_times if (now_ms - t.timestamp() * 1000) < 60000)
        if recent_requests > mode_profile.http_requests_per_minute:
            score += 50 + (recent_requests - mode_profile.http_requests_per_minute) * 0.1
        if profile.syn_count > mode_profile.syn_timeout * 10:
            score += 50 + profile.syn_count * 0.005
        if len(profile.ports_accessed) >= 4:
            score += len(profile.ports_accessed) * 8
        if request.status_code == 404 and len(profile.connection_times) > mode_profile.http_404_threshold:
            score += 30
        if profile.hopfield_score > 0:
            score = min(100, score * (1 + profile.hopfield_score / 100))
        # Credential stuffing
        if profile.http_401_count > 20:
            score += 30 + min(profile.http_401_count - 20, 20)
            profile.threat_type = profile.threat_type or "credential_stuffing"
        if profile.http_post_count > 5 and profile.http_401_count > 0:
            fail_ratio = profile.http_401_count / profile.http_post_count
            if fail_ratio > 0.5:
                score *= 1.0 + fail_ratio
                profile.threat_type = "credential_stuffing"
        # Rate acceleration
        accel_score = self._compute_rate_acceleration(profile.rpm_history, mode_profile.http_requests_per_minute)
        if accel_score > 0:
            score += accel_score
            profile.threat_type = profile.threat_type or "http_flood"
        # Sub-threshold proximity
        elapsed = (time.time() - profile.first_seen.timestamp()) / 60
        if elapsed > 2 and recent_requests > mode_profile.http_requests_per_minute * 0.6:
            sustained = recent_requests / mode_profile.http_requests_per_minute
            if sustained >= 0.75:
                time_mult = min(1.0, max(0.1, (elapsed - 2) / 3.0))
                score += min(50, 25 * sustained * time_mult)
            elif sustained >= 0.6:
                score += min(40, 15 + (sustained - 0.6) * 50)
            profile.threat_type = profile.threat_type or "slowloris"
        # Cross-subnet coordination
        if score > 20:
            cross_boost = self._check_cross_subnet_coordination(request.client_ip)
            if cross_boost > 0:
                score += cross_boost
                profile.threat_type = profile.threat_type or "botnet"
        # WAF check
        waf_match = self._waf.check(request.url, user_agent=request.user_agent)
        if waf_match:
            score += waf_match.score
            profile.threat_type = waf_match.category
            self.emit("waf_match", {"ip": request.client_ip, "rule": waf_match.rule_name, "category": waf_match.category})
        return min(100, score)

    def _compute_rate_acceleration(self, history: list[dict], threshold: int) -> float:
        if len(history) < 3:
            return 0.0
        monotonic = True
        for i in range(1, len(history)):
            if history[i]["rpm"] < history[i - 1]["rpm"] * 0.95:
                monotonic = False
                break
        if not monotonic or history[-1]["rpm"] < threshold * 0.5:
            return 0.0
        values = [h["rpm"] for h in history]
        n = len(values)
        sum_x = n * (n - 1) / 2
        sum_y = sum(values)
        sum_xy = sum(x * y for x, y in enumerate(values))
        sum_xx = n * (n - 1) * (2 * n - 1) / 6
        denom = n * sum_xx - sum_x * sum_x
        if denom == 0:
            return 0.0
        slope = (n * sum_xy - sum_x * sum_y) / denom
        if slope <= 0:
            return 0.0
        return min(25, slope * (history[-1]["rpm"] / threshold) * 10)

    def _check_cross_subnet_coordination(self, ip: str) -> float:
        now = time.time()
        self._cross_subnet_window[ip] = now
        self._cross_subnet_window = {k: t for k, t in self._cross_subnet_window.items() if now - t <= 30}
        subnets: dict[str, int] = {}
        for k in self._cross_subnet_window:
            sub = get_subnet(k)
            subnets[sub] = subnets.get(sub, 0) + 1
        return 15.0 if len(subnets) >= 3 else 0.0

    def _check_subnet_velocity(self, ip: str) -> None:
        if not self._config.subnet_blocking.enabled:
            return
        subnet = get_subnet(ip)
        now = datetime.now()
        cutoff_ts = now.timestamp() - self._config.subnet_blocking.velocity_window_seconds
        times = self._subnet_velocity.get(subnet, [])
        times.append(now)
        times = [t for t in times if t.timestamp() > cutoff_ts]
        self._subnet_velocity[subnet] = times
        if len(times) >= self._config.subnet_blocking.velocity_threshold:
            self.ban_subnet(subnet, "Velocity threshold exceeded")

    def ban_subnet(self, subnet: str, reason: str) -> None:
        if subnet in self._banned_subnets:
            return
        blocked = [ip for ip in self._blocked_ips if get_subnet(ip) == subnet]
        self._banned_subnets[subnet] = SubnetInfo(range=subnet, blocked_ips=blocked,
                                                   block_time=datetime.now(), reason=reason)
        for _ in range(10):
            self._recent_blocks.append(datetime.now())
        self.emit("subnet_ban", {"range": subnet, "reason": reason, "ips": blocked})

    def _check_night_mode(self) -> None:
        nm = self._config.night_mode
        if not nm.enabled:
            return
        hour = datetime.now().hour
        is_night = (hour >= nm.start_hour or hour < nm.end_hour) if nm.start_hour > nm.end_hour else (nm.start_hour <= hour < nm.end_hour)
        if is_night:
            min_idx = THREAT_MODES.index(nm.minimum_mode)
            cur_idx = THREAT_MODES.index(self._current_mode)
            if cur_idx < min_idx:
                self.set_threat_mode(nm.minimum_mode, "Night mode enforcement")

    def _check_auto_mode_switch(self) -> None:
        am = self._config.auto_mode
        if not am.enabled:
            return
        now = datetime.now()
        cutoff = now.timestamp() - 60
        self._recent_blocks = [t for t in self._recent_blocks if t.timestamp() > cutoff]
        block_rate = len(self._recent_blocks)
        cooldown = (now.timestamp() - self._last_mode_change.timestamp()) / 60
        if block_rate >= am.escalate_threshold and cooldown >= am.escalate_cooldown_minutes:
            self._escalate_mode("High block rate")
        elif block_rate <= am.deescalate_threshold and cooldown >= am.deescalate_cooldown_minutes:
            self._deescalate_mode("Low block rate")

    def _escalate_mode(self, reason: str) -> None:
        idx = THREAT_MODES.index(self._current_mode)
        max_idx = THREAT_MODES.index(self._config.auto_mode.max_auto_mode)
        if idx < max_idx:
            self.set_threat_mode(THREAT_MODES[idx + 1], reason)

    def _deescalate_mode(self, reason: str) -> None:
        idx = THREAT_MODES.index(self._current_mode)
        if idx > 0:
            self.set_threat_mode(THREAT_MODES[idx - 1], reason)

    def set_threat_mode(self, mode: ThreatMode, reason: str = "Manual") -> None:
        if mode == self._current_mode:
            return
        old = self._current_mode
        self._current_mode = mode
        self._last_mode_change = datetime.now()
        self._detector.set_threshold(THREAT_MODE_PROFILES[mode].anomaly_threshold)
        self.emit("mode_change", {"from": old, "to": mode, "reason": reason})

    def block_ip(self, ip: str, reason: str = "Manual block") -> None:
        profile = self._get_or_create_profile(ip)
        profile.is_blocked = True
        profile.block_count += 1
        self._blocked_ips.add(ip)
        self.emit("block", {"ip": ip, "reason": reason, "score": 100})

    def unblock_ip(self, ip: str) -> None:
        profile = self._threat_profiles.get(ip)
        if profile:
            profile.is_blocked = False
        self._blocked_ips.discard(ip)

    def is_blocked(self, ip: str) -> bool:
        return ip in self._blocked_ips

    def is_trusted(self, ip: str) -> bool:
        return self._challenge.is_trusted(ip)

    def create_challenge(self, ip: str, reason: str) -> str | None:
        return self._challenge.create_challenge(ip, reason)

    def verify_challenge(self, ip: str, token: str, fingerprint: BehaviorFingerprint,
                         client_score: int) -> dict:
        return self._challenge.verify_challenge(ip, token, fingerprint, client_score)

    def trust_ip(self, ip: str, reason: str = "Manual trust", hours: int = 24) -> None:
        self._challenge.trust_ip(ip, reason, hours)

    def untrust_ip(self, ip: str) -> None:
        self._challenge.untrust_ip(ip)

    def get_trusted_ips(self) -> list[TrustedEntry]:
        return self._challenge.get_trusted_ips()

    def get_challenge_stats(self) -> dict:
        return self._challenge.get_stats()

    def get_pending_challenge(self, ip: str) -> dict | None:
        c = self._challenge.get_pending_challenge(ip)
        if not c:
            return None
        return {"token": c.token, "reason": c.block_reason, "expires_at": c.expires_at}

    def _get_or_create_profile(self, ip: str) -> ThreatProfile:
        if ip not in self._threat_profiles:
            self._threat_profiles[ip] = ThreatProfile(ip=ip)
        return self._threat_profiles[ip]

    def _cleanup_stale_profiles(self) -> None:
        cutoff = time.time() - self._config.stale_profile_minutes * 60
        stale = [ip for ip, p in self._threat_profiles.items()
                 if p.last_seen.timestamp() < cutoff and not p.is_blocked]
        for ip in stale:
            del self._threat_profiles[ip]
            self._cross_subnet_window.pop(ip, None)
        if len(self._threat_profiles) > self._config.max_threat_profiles:
            sorted_profiles = sorted(self._threat_profiles.items(), key=lambda x: x[1].last_seen.timestamp())
            to_remove = len(self._threat_profiles) - self._config.max_threat_profiles
            for ip, _ in sorted_profiles[:to_remove]:
                if ip not in self._blocked_ips:
                    del self._threat_profiles[ip]

    @staticmethod
    def _get_hopfield_tier(score: float) -> int:
        if score < 30:
            return 0
        if score < 60:
            return 1
        if score < 80:
            return 2
        return 3

    def _create_result(self, decision: ResponseTier, tier: int, anomaly_score: float,
                       threat_score: float, reason: str, feature_impact: list[FeatureImpact],
                       start: float) -> DetectionResult:
        return DetectionResult(
            decision=decision, tier=tier, anomaly_score=anomaly_score,
            threat_score=threat_score, reason=reason, feature_impact=feature_impact,
            threat_mode=self._current_mode,
            processing_time_ms=(time.perf_counter() - start) * 1000,
        )

    def get_stats(self) -> ShieldStats:
        return ShieldStats(
            ips_tracked=len(self._threat_profiles),
            ips_blocked=len(self._blocked_ips),
            ips_rate_limited=len(self._rate_limited_ips),
            subnets_banned=len(self._banned_subnets),
            total_requests=sum(p.total_connections for p in self._threat_profiles.values()),
            anomalies_detected=sum(1 for p in self._threat_profiles.values() if p.anomaly_score > 0.3),
            current_threat_mode=self._current_mode,
            hopfield_trained=self._detector.is_trained,
            pattern_count=self._detector.pattern_count,
            uptime=(time.time() - self._start_time.timestamp()) * 1000 if self._start_time else 0,
        )

    @property
    def threat_mode(self) -> ThreatMode:
        return self._current_mode

    @property
    def running(self) -> bool:
        return self._is_running

    def get_blocked_ips(self) -> list[str]:
        return list(self._blocked_ips)

    def get_rate_limited_ips(self) -> list[str]:
        return list(self._rate_limited_ips.keys())

    def get_banned_subnets(self) -> list[SubnetInfo]:
        return list(self._banned_subnets.values())

    def get_threat_profiles(self) -> dict[str, ThreatProfile]:
        return dict(self._threat_profiles)

    def save_state(self) -> None:
        if not self._state_path:
            return
        try:
            state = {
                "version": 1,
                "saved_at": datetime.now().isoformat(),
                "detector": self._detector.to_dict(),
                "blocked_ips": list(self._blocked_ips),
                "banned_subnets": [
                    {"range": k, "reason": v.reason, "block_time": v.block_time.isoformat()}
                    for k, v in self._banned_subnets.items()
                ],
                "threat_mode": self._current_mode,
            }
            tmp_path = self._state_path + ".tmp"
            with open(tmp_path, "w") as f:
                json.dump(state, f)
            os.replace(tmp_path, self._state_path)
            self.emit("state_saved", {"path": self._state_path})
        except OSError as e:
            self.emit("state_error", {"op": "save", "error": str(e)})

    def _load_state(self) -> None:
        if not self._state_path or not Path(self._state_path).exists():
            return
        try:
            with open(self._state_path) as f:
                state = json.load(f)
            if state.get("version") != 1:
                return
            if state.get("detector"):
                self._detector = HopfieldAnomalyDetector.from_dict(state["detector"])
            if state.get("blocked_ips"):
                self._blocked_ips.update(state["blocked_ips"])
            if state.get("banned_subnets"):
                for s in state["banned_subnets"]:
                    self._banned_subnets[s["range"]] = SubnetInfo(
                        range=s["range"], reason=s["reason"],
                        block_time=datetime.fromisoformat(s["block_time"]), blocked_ips=[],
                    )
            if state.get("threat_mode") in THREAT_MODES:
                self._current_mode = state["threat_mode"]
            self.emit("state_loaded", {"path": self._state_path, "blocked_ips": len(self._blocked_ips)})
        except (OSError, json.JSONDecodeError) as e:
            self.emit("state_error", {"op": "load", "error": str(e)})

    def scan_skill(self, content: str) -> dict:
        import re
        findings = []
        dangerous = [
            r"\bsubprocess\b", r"\bos\.system\b", r"\beval\s*\(", r"\bexec\s*\(",
            r"\b__import__\b", r"\bopen\s*\(.*/etc/", r"\bcurl\b.*\|\s*sh\b",
            r"\bwget\b.*sh\b", r"\bos\.environ\b",
        ]
        for pat in dangerous:
            if re.search(pat, content):
                findings.append(f"Dangerous pattern: {pat}")
        return {"safe": len(findings) == 0, "findings": findings}

    def audit(self) -> dict:
        checks = []

        def c(id_, name, cat, sev, passed, msg):
            checks.append({"id": id_, "name": name, "category": cat, "severity": sev, "passed": passed, "message": msg})

        c("A01", "Threat mode not relaxed", "config", "medium", self._current_mode != "relaxed", f"Mode: {self._current_mode}")
        c("A02", "Auto-mode enabled", "config", "medium", self._config.auto_mode.enabled, "Auto-escalation active")
        c("A03", "WAF enabled", "defense", "high", self._config.waf.enabled, "WAF protects against OWASP top 10")
        c("A04", "Whitelist configured", "config", "low", self._config.whitelist.enabled, "CDN whitelist active")
        c("A05", "DasData reporting", "intel", "medium", self._config.das_data.enabled, "Threat intelligence sharing")
        c("A06", "Challenge service", "defense", "medium", self._config.challenge.enabled, "Behavior-based verification")
        c("A07", "Hopfield trained", "ai", "high", self._detector.is_trained, f"Patterns: {self._detector.pattern_count}")
        c("A08", "Night mode", "config", "low", self._config.night_mode.enabled, "Off-hours protection")
        c("A09", "Subnet blocking", "defense", "medium", self._config.subnet_blocking.enabled, "Auto-aggregate to /24")
        c("A10", "State persistence", "resilience", "medium", bool(self._state_path), "State survives restarts")

        passed = sum(1 for ch in checks if ch["passed"])
        total = len(checks)
        score = round((passed / total) * 100)
        grade = "A" if score >= 90 else "B" if score >= 75 else "C" if score >= 60 else "D" if score >= 40 else "F"
        return {"timestamp": datetime.now().isoformat(), "checks": checks, "score": score, "grade": grade,
                "summary": f"{passed}/{total} checks passed ({grade})"}
