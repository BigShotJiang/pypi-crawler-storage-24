"""Exfiltration Monitor — Credential and PII data leak detection."""

from __future__ import annotations
import re
from .types import ExfiltrationConfig, DEFAULT_SENSITIVE_PATTERNS


class ExfiltrationMonitor:
    def __init__(self, config: ExfiltrationConfig | None = None):
        cfg = config or ExfiltrationConfig()
        self._enabled = cfg.enabled
        self._max_scan_bytes = cfg.max_payload_scan_bytes
        self._block_on_detection = cfg.block_on_detection
        self._alert_threshold = cfg.alert_threshold
        self._whitelist_destinations = set(cfg.whitelist_destinations or [])
        self._patterns: list[tuple[str, re.Pattern, str, str]] = []
        for sp in (cfg.sensitive_patterns or DEFAULT_SENSITIVE_PATTERNS):
            try:
                self._patterns.append((sp.name, re.compile(sp.pattern), sp.severity, sp.action))
            except re.error:
                pass
        self._alert_counts: dict[str, int] = {}

    def scan(self, content: str, source_ip: str = "", destination: str = "") -> list[dict]:
        if not self._enabled:
            return []
        if destination in self._whitelist_destinations:
            return []
        text = content[:self._max_scan_bytes]
        findings = []
        for name, pattern, severity, action in self._patterns:
            matches = pattern.findall(text)
            if matches:
                findings.append({
                    "name": name, "severity": severity, "action": action,
                    "match_count": len(matches), "source_ip": source_ip,
                })
        if findings:
            self._alert_counts[source_ip] = self._alert_counts.get(source_ip, 0) + len(findings)
        return findings

    def should_block(self, source_ip: str) -> bool:
        if not self._block_on_detection:
            return False
        return self._alert_counts.get(source_ip, 0) >= self._alert_threshold

    @property
    def enabled(self) -> bool:
        return self._enabled
