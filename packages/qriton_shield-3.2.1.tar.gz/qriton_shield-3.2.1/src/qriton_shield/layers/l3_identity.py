"""L3 Identity Layer — Entity identification and profiling."""

from __future__ import annotations
from datetime import datetime
from ..types import RequestContext, LayerSignal, EntityProfile


class L3IdentityLayer:
    def __init__(self):
        self._enabled = True
        self._entities: dict[str, EntityProfile] = {}

    @property
    def name(self) -> str:
        return "L3-Identity"

    @property
    def layer(self) -> int:
        return 3

    @property
    def enabled(self) -> bool:
        return self._enabled

    @enabled.setter
    def enabled(self, value: bool) -> None:
        self._enabled = value

    def evaluate(self, ctx: RequestContext) -> LayerSignal | None:
        entity_id = ctx.entity_id or ctx.client_ip
        entity = self._entities.get(entity_id)
        if entity:
            entity.last_seen = ctx.timestamp
            entity.request_count += 1
            if entity.trust_score < 0.3:
                return LayerSignal(layer=3, name=self.name, decision="challenge", score=60,
                                 confidence=0.7, reason="Low trust entity",
                                 tags=["low_trust"], latency_ms=0)
        return None

    def register_entity(self, entity: EntityProfile) -> None:
        self._entities[entity.id] = entity
