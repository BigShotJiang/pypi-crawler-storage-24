"""L6 State Layer — File integrity and state verification."""

from __future__ import annotations
import hashlib
import os
from ..types import RequestContext, LayerSignal


class L6StateLayer:
    def __init__(self):
        self._enabled = True
        self._watched: dict[str, dict] = {}

    @property
    def name(self) -> str:
        return "L6-State"

    @property
    def layer(self) -> int:
        return 6

    @property
    def enabled(self) -> bool:
        return self._enabled

    @enabled.setter
    def enabled(self, value: bool) -> None:
        self._enabled = value

    def evaluate(self, ctx: RequestContext) -> LayerSignal | None:
        return None

    def watch(self, path: str) -> None:
        if os.path.exists(path):
            self._watched[path] = {
                "hash": self._hash_file(path),
                "size": os.path.getsize(path),
                "mtime": os.path.getmtime(path),
            }

    def check_integrity(self) -> list[dict]:
        violations = []
        for path, baseline in self._watched.items():
            if not os.path.exists(path):
                violations.append({"path": path, "issue": "deleted"})
                continue
            current_hash = self._hash_file(path)
            if current_hash != baseline["hash"]:
                violations.append({"path": path, "issue": "modified", "expected": baseline["hash"], "actual": current_hash})
        return violations

    @staticmethod
    def _hash_file(path: str) -> str:
        h = hashlib.sha256()
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(8192), b""):
                h.update(chunk)
        return h.hexdigest()
