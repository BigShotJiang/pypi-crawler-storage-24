"""L5 Semantic Layer — Prompt injection and semantic threat detection."""

from __future__ import annotations
import re
from ..types import RequestContext, LayerSignal, SemanticMatch


_SIGNATURES = [
    ("PI001", "instruction_override", "critical", re.compile(r"(?i)ignore\s+(?:all\s+)?(?:previous|above|prior)\s+instructions?")),
    ("PI002", "instruction_override", "critical", re.compile(r"(?i)you\s+are\s+now\s+(?:a|an)\s+")),
    ("PI003", "instruction_override", "high", re.compile(r"(?i)system\s*:\s*you\s+(?:are|must|should)")),
    ("PI004", "instruction_override", "high", re.compile(r"(?i)(?:do\s+not|don'?t)\s+(?:follow|obey|listen)")),
    ("PI005", "privilege_escalation", "critical", re.compile(r"(?i)override\s+(?:your|the|all)\s+(?:instructions?|rules?|constraints?)")),
    ("TI001", "tool_invocation", "high", re.compile(r"(?i)(?:execute|run|call)\s+(?:tool|function|command)\s+")),
    ("TI002", "tool_invocation", "critical", re.compile(r"(?i)(?:rm|del|remove)\s+-[rf]+\s+/")),
    ("EX001", "exfiltration", "high", re.compile(r"(?i)(?:send|post|upload|exfiltrate)\s+(?:to|data|credentials)")),
    ("EE001", "encoding_evasion", "medium", re.compile(r"(?i)base64\s+(?:decode|encode)\s+")),
    ("EE002", "encoding_evasion", "medium", re.compile(r"\\u[0-9a-fA-F]{4}")),
    ("MP001", "memory_poisoning", "high", re.compile(r"(?i)(?:remember|store|save)\s+(?:that|this)\s+(?:instruction|rule)")),
    ("CI001", "chain_injection", "critical", re.compile(r"(?i)(?:when|after)\s+(?:you|the)\s+(?:receive|get|see)\s+")),
]


class L5SemanticLayer:
    def __init__(self, threshold: float = 0.7):
        self._enabled = True
        self._threshold = threshold

    @property
    def name(self) -> str:
        return "L5-Semantic"

    @property
    def layer(self) -> int:
        return 5

    @property
    def enabled(self) -> bool:
        return self._enabled

    @enabled.setter
    def enabled(self, value: bool) -> None:
        self._enabled = value

    def evaluate(self, ctx: RequestContext) -> LayerSignal | None:
        content = ctx.body or ""
        if not content:
            content = ctx.url
        matches: list[SemanticMatch] = []
        score = 0.0
        severity_weights = {"critical": 0.4, "high": 0.25, "medium": 0.15, "low": 0.05}
        for sig_id, threat_class, severity, pattern in _SIGNATURES:
            m = pattern.search(content)
            if m:
                matches.append(SemanticMatch(
                    signature_id=sig_id, threat_class=threat_class,
                    severity=severity, matched_text=m.group()[:50],
                    position=m.start(),
                ))
                score += severity_weights.get(severity, 0.1)
        score = min(1.0, score)
        if score < self._threshold and not matches:
            return None
        decision = "deny" if score >= self._threshold else "challenge" if score >= 0.4 else "continue"
        return LayerSignal(
            layer=5, name=self.name, decision=decision,
            score=score * 100, confidence=min(1.0, score + 0.2),
            reason=f"Semantic threats: {len(matches)} matches",
            tags=[m.threat_class for m in matches],
            latency_ms=0,
            metadata={"matches": [{"id": m.signature_id, "class": m.threat_class, "text": m.matched_text} for m in matches]},
        )
