"""L4 Capability Layer — Fine-grained capability/permission checks."""

from __future__ import annotations
from datetime import datetime
from ..types import RequestContext, LayerSignal, Capability


class L4CapabilityLayer:
    def __init__(self):
        self._enabled = True
        self._capabilities: list[Capability] = []
        self._deny_all = True

    @property
    def name(self) -> str:
        return "L4-Capability"

    @property
    def layer(self) -> int:
        return 4

    @property
    def enabled(self) -> bool:
        return self._enabled

    @enabled.setter
    def enabled(self, value: bool) -> None:
        self._enabled = value

    def evaluate(self, ctx: RequestContext) -> LayerSignal | None:
        if not self._deny_all:
            return None
        entity_id = ctx.entity_id
        if not entity_id:
            return None
        now = datetime.now()
        has_cap = any(
            c.granted_to == entity_id and (not c.expires_at or c.expires_at > now)
            for c in self._capabilities
        )
        if not has_cap:
            return LayerSignal(layer=4, name=self.name, decision="deny", score=90,
                             confidence=0.9, reason="No capability granted",
                             tags=["no_capability"], latency_ms=0)
        return None

    def grant(self, capability: Capability) -> None:
        self._capabilities.append(capability)
