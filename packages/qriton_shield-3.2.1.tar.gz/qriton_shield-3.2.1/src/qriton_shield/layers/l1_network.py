"""L1 Network Layer — Network-level threat detection."""

from __future__ import annotations
from ..types import RequestContext, LayerSignal
from ..features import is_valid_ip, get_subnet


class L1NetworkLayer:
    def __init__(self):
        self._enabled = True
        self._blocked_ips: set[str] = set()
        self._blocked_subnets: set[str] = set()

    @property
    def name(self) -> str:
        return "L1-Network"

    @property
    def layer(self) -> int:
        return 1

    @property
    def enabled(self) -> bool:
        return self._enabled

    @enabled.setter
    def enabled(self, value: bool) -> None:
        self._enabled = value

    def evaluate(self, ctx: RequestContext) -> LayerSignal | None:
        if not is_valid_ip(ctx.client_ip):
            return LayerSignal(layer=1, name=self.name, decision="deny", score=100,
                             confidence=1.0, reason="Invalid IP", tags=["invalid_ip"], latency_ms=0)
        if ctx.client_ip in self._blocked_ips:
            return LayerSignal(layer=1, name=self.name, decision="deny", score=100,
                             confidence=1.0, reason="Blocked IP", tags=["blocked"], latency_ms=0)
        subnet = get_subnet(ctx.client_ip)
        if subnet in self._blocked_subnets:
            return LayerSignal(layer=1, name=self.name, decision="deny", score=100,
                             confidence=1.0, reason="Blocked subnet", tags=["subnet_blocked"], latency_ms=0)
        return LayerSignal(layer=1, name=self.name, decision="continue", score=0,
                         confidence=1.0, reason="Clean", tags=[], latency_ms=0)

    def block_ip(self, ip: str) -> None:
        self._blocked_ips.add(ip)

    def block_subnet(self, subnet: str) -> None:
        self._blocked_subnets.add(subnet)
