"""L2 Transport Layer — Transport-level threat detection."""

from __future__ import annotations
from ..types import RequestContext, LayerSignal


class L2TransportLayer:
    def __init__(self):
        self._enabled = True
        self._trusted_origins: list[str] = []

    @property
    def name(self) -> str:
        return "L2-Transport"

    @property
    def layer(self) -> int:
        return 2

    @property
    def enabled(self) -> bool:
        return self._enabled

    @enabled.setter
    def enabled(self, value: bool) -> None:
        self._enabled = value

    def evaluate(self, ctx: RequestContext) -> LayerSignal | None:
        origin = ctx.headers.get("origin", "")
        if origin and self._trusted_origins and origin not in self._trusted_origins:
            return LayerSignal(layer=2, name=self.name, decision="deny", score=80,
                             confidence=0.8, reason=f"Untrusted origin: {origin}",
                             tags=["untrusted_origin"], latency_ms=0)
        upgrade = ctx.headers.get("upgrade", "").lower()
        if upgrade == "websocket":
            if not origin:
                return LayerSignal(layer=2, name=self.name, decision="challenge", score=50,
                                 confidence=0.6, reason="WebSocket without origin",
                                 tags=["ws_no_origin"], latency_ms=0)
        return None
