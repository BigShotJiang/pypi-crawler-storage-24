"""Layer Pipeline — Multi-layer request evaluation."""

from __future__ import annotations
import time
from dataclasses import dataclass, field
from ..types import RequestContext, LayerSignal, ShieldLayer


@dataclass
class PipelineResult:
    signals: list[LayerSignal] = field(default_factory=list)
    latencies: dict[str, float] = field(default_factory=dict)


class LayerPipeline:
    def __init__(self):
        self._layers: dict[int, ShieldLayer] = {}

    def add_layer(self, layer: ShieldLayer) -> None:
        self._layers[layer.layer] = layer

    def enable_layer(self, layer_number: int) -> None:
        if layer_number in self._layers:
            self._layers[layer_number].enabled = True

    def disable_layer(self, layer_number: int) -> None:
        if layer_number in self._layers:
            self._layers[layer_number].enabled = False

    def get_layer(self, layer_number: int) -> ShieldLayer | None:
        return self._layers.get(layer_number)

    def evaluate(self, ctx: RequestContext) -> PipelineResult:
        result = PipelineResult()
        for num in sorted(self._layers.keys()):
            layer = self._layers[num]
            if not layer.enabled:
                continue
            start = time.perf_counter()
            try:
                signal = layer.evaluate(ctx)
                elapsed = (time.perf_counter() - start) * 1000
                result.latencies[layer.name] = elapsed
                if signal:
                    signal.latency_ms = elapsed
                    result.signals.append(signal)
                    if signal.decision == "deny":
                        break
            except Exception:
                pass
        return result

    @property
    def active_layers(self) -> list[ShieldLayer]:
        return [l for l in self._layers.values() if l.enabled]

    @property
    def all_layers(self) -> list[ShieldLayer]:
        return list(self._layers.values())
