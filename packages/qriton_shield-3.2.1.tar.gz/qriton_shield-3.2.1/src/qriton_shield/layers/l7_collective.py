"""L7 Collective Layer — Federated intelligence aggregation."""

from __future__ import annotations
from ..types import RequestContext, LayerSignal


class L7CollectiveLayer:
    def __init__(self):
        self._enabled = True
        self._shared_blocked: set[str] = set()

    @property
    def name(self) -> str:
        return "L7-Collective"

    @property
    def layer(self) -> int:
        return 7

    @property
    def enabled(self) -> bool:
        return self._enabled

    @enabled.setter
    def enabled(self, value: bool) -> None:
        self._enabled = value

    def evaluate(self, ctx: RequestContext) -> LayerSignal | None:
        if ctx.client_ip in self._shared_blocked:
            return LayerSignal(layer=7, name=self.name, decision="deny", score=85,
                             confidence=0.8, reason="Blocked by collective intelligence",
                             tags=["collective_block"], latency_ms=0)
        return None

    def add_shared_block(self, ip: str) -> None:
        self._shared_blocked.add(ip)
