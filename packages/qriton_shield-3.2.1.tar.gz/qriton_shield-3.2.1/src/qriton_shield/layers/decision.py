"""Decision Engine — Aggregates layer signals into final decision."""

from __future__ import annotations
from ..types import (
    ShieldDecision, LayerSignal, ThreatMode, ResponseTier,
    Explainability, FeatureImpact, THREAT_MODE_PROFILES,
)


class DecisionEngine:
    def __init__(self, mode: ThreatMode = "balanced"):
        self._mode = mode

    def set_mode(self, mode: ThreatMode) -> None:
        self._mode = mode

    def aggregate(self, pipeline_result) -> ShieldDecision:
        signals = pipeline_result.signals
        if not signals:
            return self._allow("No signals")
        total_score = 0.0
        max_confidence = 0.0
        tags: list[str] = []
        dominant_layer = 0
        dominant_signal = ""
        dominant_score = 0.0
        for signal in signals:
            weighted = signal.score * signal.confidence
            total_score += weighted
            max_confidence = max(max_confidence, signal.confidence)
            tags.extend(signal.tags)
            if weighted > dominant_score:
                dominant_score = weighted
                dominant_layer = signal.layer
                dominant_signal = signal.reason
        avg_score = total_score / len(signals)
        threshold = THREAT_MODE_PROFILES[self._mode].anomaly_threshold
        action: ResponseTier
        tier: int
        if avg_score < 30:
            action, tier = "allow", 0
        elif avg_score < 60:
            action, tier = "rate_limit", 1
        elif avg_score < 80:
            action, tier = "challenge", 2
        else:
            action, tier = "block", 3
        deny_signals = [s for s in signals if s.decision == "deny"]
        if deny_signals:
            action, tier = "block", 3
        reason = dominant_signal or f"Score: {avg_score:.1f}"
        return ShieldDecision(
            action=action, tier=tier, signals=signals,
            aggregate_score=avg_score, confidence=max_confidence,
            reason=reason, tags=list(set(tags)), threat_mode=self._mode,
            processing_time_ms=0,
            explainability=Explainability(
                dominant_layer=dominant_layer,
                dominant_signal=dominant_signal,
                feature_impact=[],
                layer_latencies=pipeline_result.latencies,
            ),
        )

    def _allow(self, reason: str) -> ShieldDecision:
        return ShieldDecision(
            action="allow", tier=0, signals=[], aggregate_score=0,
            confidence=1.0, reason=reason, tags=[], threat_mode=self._mode,
            processing_time_ms=0,
            explainability=Explainability(dominant_layer=0, dominant_signal=reason,
                                          feature_impact=[], layer_latencies={}),
        )
