"""Fingerprint Detector — Botnet detection via request fingerprinting."""

from __future__ import annotations
import hashlib
import time
import threading
from .types import FingerprintConfig


class FingerprintDetector:
    def __init__(self, config: FingerprintConfig | None = None):
        cfg = config or FingerprintConfig()
        self._enabled = cfg.enabled
        self._threshold = cfg.threshold
        self._window_seconds = cfg.window_seconds
        self._hash_fields = cfg.hash_fields
        self._max_fingerprints = cfg.max_fingerprints
        self._botnet_threshold = cfg.botnet_threshold
        self._fingerprints: dict[str, list[tuple[str, float]]] = {}
        self._lock = threading.Lock()

    def add_request(self, ip: str, method: str, url: str, user_agent: str = "",
                    headers: dict[str, str] | None = None, body_hash: str = "") -> dict | None:
        if not self._enabled:
            return None
        parts = []
        for field in self._hash_fields:
            if field == "method":
                parts.append(method)
            elif field == "url":
                parts.append(url)
            elif field == "user_agent":
                parts.append(user_agent)
            elif field == "body_hash":
                parts.append(body_hash)
        fp_hash = hashlib.sha256("|".join(parts).encode()).hexdigest()[:16]
        now = time.time()
        with self._lock:
            if len(self._fingerprints) >= self._max_fingerprints:
                oldest_key = min(self._fingerprints, key=lambda k: self._fingerprints[k][-1][1] if self._fingerprints[k] else 0)
                del self._fingerprints[oldest_key]
            if fp_hash not in self._fingerprints:
                self._fingerprints[fp_hash] = []
            cutoff = now - self._window_seconds
            entries = [(i, t) for i, t in self._fingerprints[fp_hash] if t > cutoff]
            entries.append((ip, now))
            self._fingerprints[fp_hash] = entries
            unique_ips = set(i for i, _ in entries)
            if len(unique_ips) >= self._botnet_threshold:
                return {
                    "is_botnet": True,
                    "fingerprint": fp_hash,
                    "unique_ips": len(unique_ips),
                    "count": len(entries),
                }
        return None

    def get_stats(self) -> dict:
        with self._lock:
            total = sum(len(v) for v in self._fingerprints.values())
            return {"fingerprints": len(self._fingerprints), "total_entries": total}
