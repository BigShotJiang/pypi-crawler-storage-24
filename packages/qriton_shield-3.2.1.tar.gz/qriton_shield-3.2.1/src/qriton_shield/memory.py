"""Memory Manager — Usage monitoring and auto-cleanup."""

from __future__ import annotations
import os
import threading
from .types import MemoryConfig


class MemoryManager:
    def __init__(self, config: MemoryConfig | None = None):
        cfg = config or MemoryConfig()
        self._enabled = cfg.enabled
        self._warning_mb = cfg.warning_threshold_mb
        self._critical_mb = cfg.critical_threshold_mb
        self._check_interval_ms = cfg.check_interval_ms
        self._auto_cleanup = cfg.auto_cleanup
        self._cleanup_target_mb = cfg.cleanup_target_mb
        self._timer: threading.Timer | None = None
        self._listeners: dict[str, list] = {}

    def on(self, event: str, callback) -> None:
        self._listeners.setdefault(event, []).append(callback)

    def _emit(self, event: str, data=None) -> None:
        for cb in self._listeners.get(event, []):
            try:
                cb(data)
            except Exception:
                pass

    def start(self) -> None:
        if self._enabled:
            self._schedule_check()

    def stop(self) -> None:
        if self._timer:
            self._timer.cancel()
            self._timer = None

    def _schedule_check(self) -> None:
        usage = self.get_usage_mb()
        if usage > self._critical_mb:
            self._emit("critical", {"usage_mb": usage})
        elif usage > self._warning_mb:
            self._emit("warning", {"usage_mb": usage})
        self._timer = threading.Timer(self._check_interval_ms / 1000, self._schedule_check)
        self._timer.daemon = True
        self._timer.start()

    @staticmethod
    def get_usage_mb() -> float:
        try:
            import psutil
            return psutil.Process(os.getpid()).memory_info().rss / (1024 * 1024)
        except ImportError:
            import resource
            try:
                return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024
            except Exception:
                return 0.0
