"""Hopfield Anomaly Detector — 20-feature traffic analysis with explainable AI."""

from __future__ import annotations
import math
import time

from .hopfield import ContinuousHopfieldNetwork
from .types import (
    AnomalyResult, BaselineStats, FederatedModel, FeatureImpact,
    HopfieldConfig, PatternComposition, FEATURE_NAMES, DEFAULT_FEATURE_RANGES,
)


class HopfieldAnomalyDetector:
    def __init__(self, config: HopfieldConfig | None = None):
        cfg = config or HopfieldConfig()
        self._feature_count = cfg.feature_count
        self._snapshot_length = cfg.snapshot_length
        self._pattern_size = self._feature_count * self._snapshot_length
        self._network = ContinuousHopfieldNetwork(
            self._pattern_size,
            energy_type=cfg.energy_type,
            beta=cfg.beta,
            learning_rate=cfg.learning_rate,
        )
        self._buffer: list[list[float]] = []
        self._baseline: BaselineStats | None = None
        self._anomaly_threshold = 0.3
        self._feature_ranges = dict(DEFAULT_FEATURE_RANGES)
        self._score_history: list[float] = []

    def train(self, patterns: list[list[float]]) -> None:
        normalized = [self._normalize_features(p) for p in patterns]
        self._network.train(normalized)
        self._compute_baseline(normalized)

    def add_data_point(self, features: list[float]) -> bool:
        normalized = self._normalize_features(features)
        self._buffer.append(normalized)
        if len(self._buffer) > self._snapshot_length:
            self._buffer.pop(0)
        return len(self._buffer) == self._snapshot_length

    def detect(self) -> AnomalyResult:
        start = time.perf_counter()
        if len(self._buffer) < self._snapshot_length:
            return self._empty_result(start)
        snapshot: list[float] = []
        for buf in self._buffer:
            snapshot.extend(buf)
        recall_result = self._network.recall(snapshot)
        energy = recall_result.final_energy
        gradient_norm = self._network.get_gradient_norm(recall_result.state)
        composition = self._network.compute_composition(recall_result.state)
        max_composition = composition[0].percentage if composition else 0.0
        z_energy = z_gradient = z_composition = 0.0
        if self._baseline:
            z_energy = self._z_score(energy, self._baseline.energy["mean"], self._baseline.energy["std"])
            z_gradient = self._z_score(gradient_norm, self._baseline.gradient_norm["mean"], self._baseline.gradient_norm["std"])
            z_composition = self._z_score(100 - max_composition, self._baseline.max_composition["mean"], self._baseline.max_composition["std"])
        raw_score = 0.3 * max(0, z_energy) + 0.4 * max(0, z_gradient) + 0.3 * max(0, z_composition)
        thresh = self._anomaly_threshold if self._anomaly_threshold > 0 else 0.75
        ratio = (0.0 if math.isnan(raw_score) else raw_score) / thresh
        if ratio <= 1.0:
            normalized_score = max(0, min(50, ratio * 50))
        else:
            normalized_score = max(50, min(100, 50 + 50 * math.log10(ratio) / 2.0))
        self._update_adaptive_threshold(raw_score)
        feature_impact = self._compute_feature_impact(snapshot, recall_result.state)
        elapsed = (time.perf_counter() - start) * 1000
        return AnomalyResult(
            is_anomaly=raw_score > self._anomaly_threshold,
            anomaly_score=raw_score,
            normalized_score=normalized_score,
            confidence=abs(raw_score - self._anomaly_threshold),
            metrics={
                "energy": energy, "gradient_norm": gradient_norm, "max_composition": max_composition,
                "z_energy": z_energy, "z_gradient": z_gradient, "z_composition": z_composition,
            },
            feature_impact=feature_impact,
            composition=composition,
            processing_time_ms=elapsed,
        )

    def _normalize_features(self, features: list[float]) -> list[float]:
        result = []
        for i, value in enumerate(features):
            name = FEATURE_NAMES[i % self._feature_count]
            fr = self._feature_ranges.get(name)
            if fr:
                result.append(self._normalize(value, fr.min, fr.max))
            else:
                result.append(self._normalize(value, 0, 1))
        return result

    @staticmethod
    def _normalize(value: float, min_val: float, max_val: float) -> float:
        if max_val == min_val:
            return 0.0
        return max(-1.0, min(1.0, 2 * (value - min_val) / (max_val - min_val) - 1))

    @staticmethod
    def _z_score(value: float, mean: float, std: float) -> float:
        if math.isnan(value) or math.isnan(mean) or math.isnan(std):
            return 0.0
        return (value - mean) / max(std, 0.001)

    def _compute_baseline(self, patterns: list[list[float]]) -> None:
        energies, gradients, compositions = [], [], []
        for pattern in patterns:
            result = self._network.recall(pattern)
            energies.append(result.final_energy)
            gradients.append(self._network.get_gradient_norm(result.state))
            comp = self._network.compute_composition(result.state)
            compositions.append(100 - comp[0].percentage if comp else 100)
        self._baseline = BaselineStats(
            energy=self._compute_stats(energies),
            gradient_norm=self._compute_stats(gradients),
            max_composition=self._compute_stats(compositions),
        )

    @staticmethod
    def _compute_stats(values: list[float]) -> dict:
        if not values:
            return {"mean": 0.0, "std": 0.0}
        mean = sum(values) / len(values)
        variance = sum((v - mean) ** 2 for v in values) / len(values)
        return {"mean": mean, "std": math.sqrt(variance)}

    def _compute_feature_impact(self, input_vec: list[float], recalled: list[float]) -> list[FeatureImpact]:
        impacts = []
        for i in range(self._feature_count):
            total_contribution = 0.0
            for s in range(self._snapshot_length):
                idx = s * self._feature_count + i
                total_contribution += abs(input_vec[idx] - recalled[idx])
            impacts.append(FeatureImpact(
                name=FEATURE_NAMES[i], index=i, value=input_vec[i],
                contribution=total_contribution / self._snapshot_length,
                energy_delta=total_contribution,
            ))
        impacts.sort(key=lambda x: x.contribution, reverse=True)
        return impacts

    def _update_adaptive_threshold(self, score: float) -> None:
        self._score_history.append(score)
        if len(self._score_history) > 100:
            self._score_history.pop(0)
        if len(self._score_history) >= 20:
            sorted_scores = sorted(self._score_history)
            new_threshold = sorted_scores[int(len(sorted_scores) * 0.95)]
            self._anomaly_threshold = 0.9 * self._anomaly_threshold + 0.1 * new_threshold
            self._anomaly_threshold = max(0.1, min(0.9, self._anomaly_threshold))

    def set_threshold(self, threshold: float) -> None:
        self._anomaly_threshold = max(0.1, min(0.9, threshold))

    def feedback_false_positive(self) -> None:
        self._anomaly_threshold = min(0.9, self._anomaly_threshold + 0.05)

    def feedback_false_negative(self) -> None:
        self._anomaly_threshold = max(0.1, self._anomaly_threshold - 0.05)

    def _empty_result(self, start: float) -> AnomalyResult:
        return AnomalyResult(
            is_anomaly=False, anomaly_score=0.0, normalized_score=0.0, confidence=0.0,
            metrics={"energy": 0, "gradient_norm": 0, "max_composition": 0, "z_energy": 0, "z_gradient": 0, "z_composition": 0},
            feature_impact=[], composition=[], processing_time_ms=(time.perf_counter() - start) * 1000,
        )

    @property
    def is_trained(self) -> bool:
        return self._network.is_trained

    @property
    def threshold(self) -> float:
        return self._anomaly_threshold

    @property
    def pattern_count(self) -> int:
        return self._network.pattern_count

    @property
    def data_points_processed(self) -> int:
        return len(self._buffer)

    @property
    def anomaly_rate(self) -> float:
        return self._anomaly_threshold

    def train_canonical_patterns(self, patterns: list[list[float]]) -> None:
        expanded = []
        for p in patterns:
            full: list[float] = []
            for _ in range(self._snapshot_length):
                full.extend(p)
            expanded.append(full)
        self.train(expanded)

    @staticmethod
    def get_canonical_patterns() -> list[list[float]]:
        return [
            [8000, 7500, 100, 50, 160, 0.94, 0.01, 200, 0.0, 0.0, 0.5, 0.1, 0.3, 10, 0, 0, 0.8, 0.1, 0, 0],
            [3000, 100, 2800, 20, 150, 0.03, 0.93, 9000, 0.05, 0.3, 1.0, 0.05, 0.2, 5, 500, 0, 0.05, 0, 0, 0],
            [500, 200, 100, 5, 100, 0.4, 0.2, 50, 0.8, 0.0, 0.3, 0.1, 0.1, 800, 0, 0, 0.6, 0.8, 0, 0],
            [200, 10, 190, 3, 67, 0.05, 0.95, 5, 0.0, 0.0, 0.2, 0.05, 0.1, 900, 100, 0, 0.1, 0, 0, 0],
            [5000, 500, 4000, 500, 10, 0.1, 0.8, 5000, 0.1, 0.2, 0.8, 0.02, 3.5, 2, 300, 50, 0.2, 0.3, 1, 0.7],
            [300, 50, 200, 10, 30, 0.17, 0.67, 100, 0.7, 0.0, 4.0, 0.3, 0.5, 500, 0, 100, 0.4, 0.5, 0, 0],
            [1000, 50, 900, 15, 67, 0.05, 0.9, 500, 0.0, 0.95, 0.1, 0.08, 0.2, 3, 200, 0, 0.3, 0, 0.5, 0],
            [9000, 8000, 500, 1000, 9, 0.89, 0.06, 8000, 0.0, 0.0, 0.3, 0.15, 4.0, 1, 50000, 400, 0.6, 0.4, 4, 0],
            [100, 10, 90, 3, 33, 0.1, 0.9, 20, 0.0, 0.8, 0.3, 0.1, 0.1, 600, 90000, 0, 0.1, 0.3, 4.5, 0.3],
            [50, 5, 45, 2, 25, 0.1, 0.9, 10, 0.0, 0.3, 0.1, 0.05, 0.1, 1, 150, 200, 0.3, 0.6, 0.5, 0.9],
        ]

    def export_model(self) -> FederatedModel:
        return FederatedModel(
            patterns=self._network.get_patterns(),
            baseline=self._baseline,
            threshold=self._anomaly_threshold,
            data_points_processed=len(self._buffer),
            pattern_size=self._pattern_size,
            feature_count=self._feature_count,
        )

    def merge_federated_model(self, remote: FederatedModel, local_weight: float = 0.7, remote_weight: float = 0.3) -> None:
        if not remote.patterns or remote.pattern_size != self._pattern_size:
            return
        local_patterns = self._network.get_patterns()
        if not local_patterns:
            self._network.set_patterns(remote.patterns)
            return
        merged_count = max(len(local_patterns), len(remote.patterns))
        merged: list[list[float]] = []
        for i in range(merged_count):
            has_local = i < len(local_patterns)
            has_remote = i < len(remote.patterns)
            if has_local and has_remote:
                merged.append([
                    v * local_weight + remote.patterns[i][j] * remote_weight
                    for j, v in enumerate(local_patterns[i])
                ])
            elif has_local:
                merged.append(list(local_patterns[i]))
            else:
                merged.append(list(remote.patterns[i]))
        self._network.set_patterns(merged)
        if remote.baseline and self._baseline:
            self._baseline = BaselineStats(
                energy={
                    "mean": self._baseline.energy["mean"] * local_weight + remote.baseline.energy["mean"] * remote_weight,
                    "std": self._baseline.energy["std"] * local_weight + remote.baseline.energy["std"] * remote_weight,
                },
                gradient_norm={
                    "mean": self._baseline.gradient_norm["mean"] * local_weight + remote.baseline.gradient_norm["mean"] * remote_weight,
                    "std": self._baseline.gradient_norm["std"] * local_weight + remote.baseline.gradient_norm["std"] * remote_weight,
                },
                max_composition={
                    "mean": self._baseline.max_composition["mean"] * local_weight + remote.baseline.max_composition["mean"] * remote_weight,
                    "std": self._baseline.max_composition["std"] * local_weight + remote.baseline.max_composition["std"] * remote_weight,
                },
            )

    def to_dict(self) -> dict:
        return {
            "network": self._network.to_dict(),
            "feature_count": self._feature_count,
            "snapshot_length": self._snapshot_length,
            "anomaly_threshold": self._anomaly_threshold,
            "baseline": {
                "energy": self._baseline.energy,
                "gradient_norm": self._baseline.gradient_norm,
                "max_composition": self._baseline.max_composition,
            } if self._baseline else None,
            "feature_ranges": {k: {"min": v.min, "max": v.max} for k, v in self._feature_ranges.items()},
        }

    @classmethod
    def from_dict(cls, data: dict) -> HopfieldAnomalyDetector:
        from .types import FeatureRange
        detector = cls(HopfieldConfig(feature_count=data["feature_count"], snapshot_length=data["snapshot_length"]))
        detector._network = ContinuousHopfieldNetwork.from_dict(data["network"])
        detector._anomaly_threshold = data["anomaly_threshold"]
        if data.get("baseline"):
            detector._baseline = BaselineStats(
                energy=data["baseline"]["energy"],
                gradient_norm=data["baseline"]["gradient_norm"],
                max_composition=data["baseline"]["max_composition"],
            )
        if data.get("feature_ranges"):
            detector._feature_ranges = {k: FeatureRange(**v) for k, v in data["feature_ranges"].items()}
        return detector
