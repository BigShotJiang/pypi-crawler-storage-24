# SPDX-License-Identifier: Zlib
# app.py — Kigo demo app with Studio (Esc-toggleable)

import sys

# --- Qt shim (matches your existing kigo.qt style) ---
from PyQt6 import QtWidgets, QtCore, QtGui

Qt = QtCore.Qt
QEvent = QtCore.QEvent


# =====================================================
# Kigo Studio Overlay
# =====================================================

class StudioOverlay(QtWidgets.QWidget):
    """
    Semi-transparent developer overlay.
    Shown/hidden via Esc key.
    """

    def __init__(self, parent=None):
        super().__init__(parent)

        self.setWindowFlags(
            Qt.WindowType.Tool |
            Qt.WindowType.FramelessWindowHint |
            Qt.WindowType.WindowStaysOnTopHint
        )

        self.setAttribute(Qt.WidgetAttribute.WA_NoSystemBackground, True)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground, True)

        self.setStyleSheet("""
            QWidget {
                background-color: rgba(20, 20, 20, 210);
                color: #dddddd;
                font-family: Consolas, monospace;
            }
        """)

        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 24)
        layout.setSpacing(12)

        title = QtWidgets.QLabel("Kigo Studio")
        title.setStyleSheet("font-size: 20px; font-weight: bold;")

        subtitle = QtWidgets.QLabel(
            "Esc — toggle studio\n"
            "Inspector, performance panel, live controls coming soon."
        )

        layout.addWidget(title)
        layout.addWidget(subtitle)
        layout.addStretch(1)

    def showEvent(self, event):
        if self.parent():
            self.setGeometry(self.parent().rect())
        super().showEvent(event)


# =====================================================
# Kigo Studio Controller (global Esc handler)
# =====================================================

class StudioController(QtCore.QObject):
    """
    Global controller that toggles Studio with Esc.
    Implemented via Qt event filter (focus-independent).
    """

    def __init__(self, qt_app: QtWidgets.QApplication, overlay: StudioOverlay):
        super().__init__()
        self.overlay = overlay
        qt_app.installEventFilter(self)

    def eventFilter(self, obj, event):
        if event.type() == QEvent.Type.KeyPress:
            if event.key() == Qt.Key.Key_Escape:
                self.toggle()
                return True  # consume Esc
        return False

    def toggle(self):
        if self.overlay.isVisible():
            self.overlay.hide()
        else:
            self.overlay.show()
            self.overlay.raise_()


# =====================================================
# Demo Kigo App Window
# =====================================================

class MainWindow(QtWidgets.QMainWindow):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("Kigo App — Studio Demo")
        self.resize(900, 600)

        central = QtWidgets.QWidget()
        self.setCentralWidget(central)

        layout = QtWidgets.QVBoxLayout(central)
        layout.setSpacing(16)

        label = QtWidgets.QLabel(
            "This is a normal Kigo app.\n\n"
            "Press ESC to toggle Kigo Studio."
        )
        label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        label.setStyleSheet("font-size: 16px;")

        button = QtWidgets.QPushButton("Example Button")

        layout.addStretch(1)
        layout.addWidget(label)
        layout.addWidget(button, alignment=Qt.AlignmentFlag.AlignCenter)
        layout.addStretch(1)


# =====================================================
# App Entry Point
# =====================================================

def main():
    dev = True        # dev-only feature gate
    studio = True     # enable studio

    app = QtWidgets.QApplication(sys.argv)

    window = MainWindow()
    window.show()

    # ---- Studio wiring (dev-only) ----
    if dev and studio:
        studio_overlay = StudioOverlay(parent=window)
        StudioController(app, studio_overlay)

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
