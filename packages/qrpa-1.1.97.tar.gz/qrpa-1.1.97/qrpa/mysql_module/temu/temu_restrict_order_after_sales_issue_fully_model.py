#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TEMU订单售后问题详情表模型
frozenType: order_after_sales_issue_fully
"""

from sqlalchemy import create_engine, Column, String, Text, DateTime, Integer, DECIMAL, Date, Index
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from datetime import datetime, date
import json
import re

Base = declarative_base()


class TemuRestrictOrderAfterSalesIssueFully(Base):
    """
    TEMU订单售后问题详情表
    """
    __tablename__ = 'temu_restrict_order_after_sales_issue_fully'

    # 主键ID (自增)
    id = Column(Integer, primary_key=True, autoincrement=True, comment='主键ID')

    # 商城和日期
    mall_id = Column(String(50), nullable=False, comment='商城ID')
    record_date = Column(Date, nullable=False, comment='记录日期')

    # 详情字段
    order_sn = Column(String(100), nullable=True, comment='子订单号')
    after_sale_sn = Column(String(100), nullable=True, comment='售后子单号')
    sku_id = Column(String(50), nullable=True, comment='SKU ID')
    goods_name = Column(String(500), nullable=True, comment='商品名称')
    amount = Column(String(50), nullable=True, comment='限制金额文本')
    amount_value = Column(DECIMAL(12, 2), nullable=True, comment='限制金额数值')
    currency = Column(String(10), nullable=True, comment='货币类型')
    state = Column(String(50), nullable=True, comment='状态')
    freeze_start_time = Column(DateTime, nullable=True, comment='限制开始时间')
    source_dr = Column(String(50), nullable=True, comment='地区')

    # 时间戳
    created_at = Column(DateTime, default=datetime.now, comment='创建时间')
    updated_at = Column(DateTime, default=datetime.now, onupdate=datetime.now, comment='更新时间')

    # 定义索引
    __table_args__ = (
        Index('ix_order_after_sales_mall_id', 'mall_id'),
        Index('ix_order_after_sales_record_date', 'record_date'),
        Index('ix_order_after_sales_order_sn', 'order_sn'),
        Index('ix_order_after_sales_after_sale_sn', 'after_sale_sn'),
        Index('ix_order_after_sales_mall_date', 'mall_id', 'record_date'),
        Index('ix_order_after_sales_unique', 'mall_id', 'record_date', 'after_sale_sn', unique=True),
    )

    def __repr__(self):
        return f"<TemuRestrictOrderAfterSalesIssueFully(id={self.id}, order_sn='{self.order_sn}', after_sale_sn='{self.after_sale_sn}')>"


class TemuRestrictOrderAfterSalesIssueFullyManager:
    """
    TEMU订单售后问题数据管理器
    """

    def __init__(self, database_url):
        self.engine = create_engine(database_url, echo=False)
        self.Session = sessionmaker(bind=self.engine)

    def create_tables(self):
        Base.metadata.create_all(self.engine)
        print("TEMU订单售后问题表创建成功！")

    def drop_tables(self):
        Base.metadata.drop_all(self.engine)
        print("TEMU订单售后问题表删除成功！")

    def _parse_amount_value(self, amount_str):
        if not amount_str:
            return None
        try:
            cleaned = re.sub(r'[￥¥$€£+,\s]', '', str(amount_str))
            return float(cleaned) if cleaned else None
        except:
            return None

    def _parse_timestamp(self, timestamp_ms):
        if not timestamp_ms:
            return None
        try:
            return datetime.fromtimestamp(timestamp_ms / 1000)
        except:
            return None

    def upsert_data(self, mall_id, record_date, data):
        """
        插入或更新数据
        """
        session = self.Session()
        try:
            details_rows = data.get('detailsRows', [])
            insert_count = 0
            update_count = 0
            skip_count = 0

            for row in details_rows:
                after_sale_sn = row.get('afterSaleSn')
                
                # 如果没有售后单号，使用freeze_start_time和amount作为唯一标识
                if not after_sale_sn:
                    # 生成一个临时的唯一标识
                    freeze_time = row.get('freezeStartTime', 0)
                    amount = row.get('amount', '')
                    after_sale_sn = f"AUTO_{freeze_time}_{amount}"

                existing = session.query(TemuRestrictOrderAfterSalesIssueFully).filter_by(
                    mall_id=mall_id,
                    record_date=record_date,
                    after_sale_sn=after_sale_sn
                ).first()

                if existing:
                    existing.order_sn = row.get('orderSn')
                    existing.sku_id = row.get('skuId')
                    existing.goods_name = row.get('goodsName')
                    existing.amount = row.get('amount')
                    existing.amount_value = self._parse_amount_value(row.get('amount'))
                    existing.currency = row.get('currency')
                    existing.state = row.get('state')
                    existing.freeze_start_time = self._parse_timestamp(row.get('freezeStartTime'))
                    existing.source_dr = row.get('sourceDR')
                    existing.updated_at = datetime.now()
                    update_count += 1
                else:
                    new_record = TemuRestrictOrderAfterSalesIssueFully(
                        mall_id=mall_id,
                        record_date=record_date,
                        order_sn=row.get('orderSn'),
                        after_sale_sn=after_sale_sn,
                        sku_id=row.get('skuId'),
                        goods_name=row.get('goodsName'),
                        amount=row.get('amount'),
                        amount_value=self._parse_amount_value(row.get('amount')),
                        currency=row.get('currency'),
                        state=row.get('state'),
                        freeze_start_time=self._parse_timestamp(row.get('freezeStartTime')),
                        source_dr=row.get('sourceDR')
                    )
                    session.add(new_record)
                    insert_count += 1

            session.commit()
            print(f"TEMU订单售后问题: 新增 {insert_count} 条，更新 {update_count} 条")

        except Exception as e:
            session.rollback()
            print(f"处理数据失败: {e}")
            raise
        finally:
            session.close()

    def import_from_json_file(self, json_file_path, mall_id, record_date):
        with open(json_file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
            self.upsert_data(mall_id, record_date, data)
