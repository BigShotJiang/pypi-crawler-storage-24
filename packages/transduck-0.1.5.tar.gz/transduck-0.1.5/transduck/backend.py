"""OpenAI translation backend."""

import json as _json

import openai


_SYSTEM_TEMPLATE = (
    "You are a professional translator. Translate the given text from {source_lang} "
    "to {target_lang}. Return ONLY the translated text, nothing else. Preserve any "
    "placeholders like {{name}}, {{{{count}}}}, %s, ${{value}} exactly as they appear. "
    "Preserve brand names. Match the tone and formality of the original.\n\n"
    "Project context: {project_context}"
)

_USER_TEMPLATE = 'Translate: "{source_text}"\nString context: {string_context}'


def build_messages(
    source_text: str,
    source_lang: str,
    target_lang: str,
    project_context: str,
    string_context: str | None,
) -> list[dict]:
    system_msg = _SYSTEM_TEMPLATE.format(
        source_lang=source_lang,
        target_lang=target_lang,
        project_context=project_context,
    )
    user_msg = _USER_TEMPLATE.format(
        source_text=source_text,
        string_context=string_context or "none",
    )
    return [
        {"role": "system", "content": system_msg},
        {"role": "user", "content": user_msg},
    ]


def translate(
    source_text: str,
    source_lang: str,
    target_lang: str,
    project_context: str,
    string_context: str | None,
    api_key: str,
    model: str,
    timeout: int,
    max_retries: int,
) -> str:
    client = openai.OpenAI(api_key=api_key, timeout=timeout, max_retries=max_retries)
    messages = build_messages(source_text, source_lang, target_lang, project_context, string_context)
    response = client.chat.completions.create(model=model, messages=messages, temperature=0.3)
    return response.choices[0].message.content.strip()


_PLURAL_SYSTEM_TEMPLATE = (
    "You are a professional translator. You will be given two plural forms "
    "(one and other) in {source_lang}. Generate ALL plural forms needed in "
    "{target_lang} according to CLDR plural rules. Return ONLY a JSON object "
    "mapping plural categories to translated strings. Do not include explanation.\n\n"
    "CRITICAL: Placeholders like {count}, {name}, %s, ${value} are SOFTWARE VARIABLES "
    "that will be replaced by code at runtime. You MUST include them exactly as written "
    "in EVERY plural form, even for zero, one, and two categories where the language "
    "would not normally use a numeral. For example, for Arabic zero: use \"{count} ...\" "
    "not \"لا توجد ...\". For Arabic one: use \"{count} ...\" not \"واحدة ...\".\n\n"
    "Preserve brand names. Match the tone and formality of the original.\n\n"
    "CLDR plural categories are: zero, one, two, few, many, other.\n"
    "Only include categories that {target_lang} actually uses.\n\n"
    "Project context: {project_context}"
)

_PLURAL_USER_TEMPLATE = (
    'Source one form: "{one}"\n'
    'Source other form: "{other}"\n'
    'String context: {string_context}'
)


def _safe_render(template: str, **kwargs) -> str:
    """Render a template using safe string replacement (not str.format)."""
    result = template
    for key, value in kwargs.items():
        result = result.replace(f"{{{key}}}", str(value))
    return result


def build_plural_messages(
    one: str,
    other: str,
    source_lang: str,
    target_lang: str,
    project_context: str,
    string_context: str | None,
) -> list[dict]:
    system_msg = _safe_render(
        _PLURAL_SYSTEM_TEMPLATE,
        source_lang=source_lang,
        target_lang=target_lang,
        project_context=project_context,
    )
    user_msg = _safe_render(
        _PLURAL_USER_TEMPLATE,
        one=one,
        other=other,
        string_context=string_context or "none",
    )
    return [
        {"role": "system", "content": system_msg},
        {"role": "user", "content": user_msg},
    ]


def translate_plural(
    one: str,
    other: str,
    source_lang: str,
    target_lang: str,
    project_context: str,
    string_context: str | None,
    api_key: str,
    model: str,
    timeout: int,
    max_retries: int,
) -> dict[str, str]:
    """Call OpenAI to generate all plural forms. Returns {category: translation}."""
    client = openai.OpenAI(api_key=api_key, timeout=timeout, max_retries=max_retries)
    messages = build_plural_messages(one, other, source_lang, target_lang, project_context, string_context)
    response = client.chat.completions.create(model=model, messages=messages, temperature=0.3)
    raw = response.choices[0].message.content.strip()
    return _json.loads(raw)
