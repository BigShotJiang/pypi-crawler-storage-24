"""Configuration loading and discovery for transduck."""

import os
from dataclasses import dataclass
from pathlib import Path

import yaml


CONFIG_FILENAME = "transduck.yaml"


@dataclass(frozen=True)
class TransduckConfig:
    project_name: str
    project_context: str
    source_lang: str
    target_langs: list[str]
    storage_path: Path
    api_key_env: str
    backend_model: str
    backend_timeout: int
    backend_max_retries: int
    read_only: bool


def _find_config() -> Path:
    env_path = os.environ.get("TRANSDUCK_CONFIG")
    if env_path:
        p = Path(env_path)
        if p.is_file():
            return p
        raise FileNotFoundError(f"TRANSDUCK_CONFIG points to {env_path} which does not exist")

    current = Path.cwd()
    while True:
        candidate = current / CONFIG_FILENAME
        if candidate.is_file():
            return candidate
        parent = current.parent
        if parent == current:
            break
        current = parent

    raise FileNotFoundError(
        f"Could not find {CONFIG_FILENAME}. Run 'transduck init' or set TRANSDUCK_CONFIG."
    )


def load_config(path: Path | None = None) -> TransduckConfig:
    if path is None:
        path = _find_config()
    path = Path(path)

    with open(path) as f:
        raw = yaml.safe_load(f)

    config_dir = path.parent
    storage_rel = raw["storage"]["path"]
    storage_path = (config_dir / storage_rel).resolve()

    return TransduckConfig(
        project_name=raw["project"]["name"],
        project_context=raw["project"]["context"],
        source_lang=raw["languages"]["source"].upper(),
        target_langs=[lang.upper() for lang in raw["languages"]["targets"]],
        storage_path=storage_path,
        api_key_env=raw["backend"]["api_key_env"],
        backend_model=raw["backend"]["model"],
        backend_timeout=raw["backend"]["timeout_seconds"],
        backend_max_retries=raw["backend"]["max_retries"],
        read_only=raw.get("runtime", {}).get("read_only", False),
    )
