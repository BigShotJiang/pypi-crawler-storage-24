"""
Mooré number to text converter.
"""

# Mapping for 0-10
UNITS = {
    0: "Zaalem",
    1: "Ye",
    2: "Yiibu",
    3: "Taabo",
    4: "Naassé",
    5: "Nu",
    6: "Yoobé",
    7: "Yoopoé",
    8: "Nii",
    9: "Wuè",
    10: "Piiga"
}

# Mapping for 10-19 (using Piig la a ...)
# For combinations, 1 is "ye" and 2 is "yii"
UNITS_COMB = {
    1: "ye",
    2: "yii",
    3: "taabo",
    4: "naase",
    5: "nu",
    6: "yoobe",
    7: "yoopoé",
    8: "nii",
    9: "wuè"
}

# Mapping for tens (20-90)
TENS = {
    20: "Pisi",
    30: "Pis-tã",
    40: "Pis-naasé",
    50: "Pis-nu",
    60: "Pis-yoobe",
    70: "Pis-yoopoé",
    80: "Pis-nii",
    90: "Pis-wue"
}

def convert_to_text(n: int, is_comb: bool = False, is_money: bool = False) -> str:
    """Converts an integer to its Mooré text representation."""
    if is_money:
        # For money, 5 CFA = 1 unit in Mooré counting
        n = n // 5

    return _convert_to_text_internal(n, is_comb)

def _convert_to_text_internal(n: int, is_comb: bool = False) -> str:
    if n < 0:
        return "Nindre " + _convert_to_text_internal(abs(n))
    
    if n <= 10:
        if is_comb and n in UNITS_COMB:
            return UNITS_COMB[n]
        return UNITS[n]
    
    if n < 20:
        return f"Piig la a {UNITS_COMB[n-10]}"
    
    if n < 100:
        ten = (n // 10) * 10
        unit = n % 10
        if unit == 0:
             # TENS handles plural/suffix forms like Pis-tã
            return TENS[ten]
        else:
            return f"{TENS[ten]} la a {UNITS_COMB[unit]}"
            
    if n < 1000:
        hundreds = n // 100
        remainder = n % 100
        if hundreds == 1:
            prefix = "Koabga"
        else:
            prefix = f"Koabg {_convert_to_text_internal(hundreds).lower()}"
        
        if remainder == 0:
            return prefix
        else:
            return f"{prefix} la {_convert_to_text_internal(remainder, is_comb=True).lower()}"

    if n < 1_000_000:
        thousands = n // 1000
        remainder = n % 1000
        if thousands == 1:
            prefix = "Toukouli"
        else:
            prefix = f"Tus {_convert_to_text_internal(thousands).lower()}"
            
        if remainder == 0:
            return prefix
        else:
            return f"{prefix} la {_convert_to_text_internal(remainder, is_comb=True).lower()}"

    if n < 1_000_000_000:
        millions = n // 1_000_000
        remainder = n % 1_000_000
        if millions == 1:
            prefix = "milyõ a ye"
        else:
            prefix = f"{_convert_to_text_internal(millions)} milyõ"
            
        if remainder == 0:
            return prefix
        else:
            return f"{prefix} la {_convert_to_text_internal(remainder, is_comb=True).lower()}"

    if n < 1_000_000_000_000:
        billions = n // 1_000_000_000
        remainder = n % 1_000_000_000
        if billions == 1:
            prefix = "Milyar ye"
        else:
            prefix = f"Milyar {_convert_to_text_internal(billions).lower()}"
            
        if remainder == 0:
            return prefix
        else:
            return f"{prefix} la {_convert_to_text_internal(remainder, is_comb=True).lower()}"

    return str(n)

# Reverse mapping for units and tens
REVERSE_UNITS = {v.lower(): k for k, v in UNITS.items()}
REVERSE_UNITS_COMB = {v.lower(): k for k, v in UNITS_COMB.items()}
REVERSE_TENS = {v.lower(): k for k, v in TENS.items()}

def text_to_num(text: str, is_money: bool = False) -> int:
    """Converts Mooré text representation back to an integer."""
    text = text.lower().strip()
    
    # Simple lookup for 0-10
    if text in REVERSE_UNITS:
        val = REVERSE_UNITS[text]
    elif text in REVERSE_UNITS_COMB:
        val = REVERSE_UNITS_COMB[text]
    else:
        # Parsing logic for complex numbers
        val = 0
        
        # Split by major blocks (billions, millions, thousands, hundreds)
        if "milyar" in text:
            parts = text.split("milyar")
            billions_part = parts[0].strip()
            # "milyar ye" or "milyar [num]"
            billions_count = 1
            if "ye" in parts[1]:
                billions_count = 1
            elif billions_part:
                billions_count = text_to_num(billions_part)
            
            val += billions_count * 1_000_000_000
            text = parts[1].replace("ye", "").strip()
            if text.startswith("la "): text = text[3:].strip()

        if "milyõ" in text:
            if "milyõ a ye" in text:
                val += 1_000_000
                text = text.replace("milyõ a ye", "").strip()
            else:
                parts = text.split("milyõ")
                millions_count = text_to_num(parts[0].strip())
                val += millions_count * 1_000_000
                text = parts[1].strip()
            if text.startswith("la "): text = text[3:].strip()

        if "toukouli" in text:
            val += 1000
            text = text.replace("toukouli", "").strip()
            if text.startswith("la "): text = text[3:].strip()
        elif "tus" in text:
            parts = text.split("tus")
            # If "tus" is at the start, it's followed by count? No, "tus [count]"
            remaining = parts[1].strip()
            # We need to find where the count ends and remainder starts (if any)
            # Usually internal logic suggests "tus [count] la [remainder]"
            tus_parts = remaining.split(" la ")
            tus_count_text = tus_parts[0].strip()
            val += text_to_num(tus_count_text) * 1000
            text = " la ".join(tus_parts[1:]) if len(tus_parts) > 1 else ""

        if "koabga" in text:
            val += 100
            text = text.replace("koabga", "").strip()
            if text.startswith("la "): text = text[3:].strip()
        elif "koabg" in text:
            parts = text.split("koabg")
            remaining = parts[1].strip()
            koabg_parts = remaining.split(" la ")
            count_text = koabg_parts[0].strip()
            val += text_to_num(count_text) * 100
            text = " la ".join(koabg_parts[1:]) if len(koabg_parts) > 1 else ""

        # Handle tens and units
        if text:
            # Check for "pisi la a nu" or "pisi" or "piig la a yii"
            if " la a " in text:
                subparts = text.split(" la a ")
                ten_text = subparts[0].strip()
                unit_text = subparts[1].strip()
                if ten_text == "piig":
                    val += 10 + REVERSE_UNITS_COMB.get(unit_text, 0)
                else:
                    val += REVERSE_TENS.get(ten_text, 0) + REVERSE_UNITS_COMB.get(unit_text, 0)
            elif text in REVERSE_TENS:
                val += REVERSE_TENS[text]
            elif text in REVERSE_UNITS:
                val += REVERSE_UNITS[text]
            elif text in REVERSE_UNITS_COMB:
                val += REVERSE_UNITS_COMB[text]

    if is_money:
        return val * 5
    return val
