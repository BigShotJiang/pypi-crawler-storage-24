"""
Daemon helpers for zero-config local use.

Shared by cli.py and client.py to avoid circular imports.
"""
from __future__ import annotations

import json
import os
import platform
import secrets
import socket
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Dict, Optional

import requests

try:
    import fcntl  # type: ignore
except ImportError:  # Windows
    fcntl = None  # sentinel

from .exceptions import (
    PrajnyavanAuthError,
    PrajnyavanConfigError,
    PrajnyavanConnectionError,
    PrajnyavanSetupError,
)

BASE_DIR = Path.home() / ".prajnyavan"
DEV_CONFIG = BASE_DIR / "dev.json"
PID_FILE = BASE_DIR / "prajnyavan.pid"
STARTUP_LOCK = BASE_DIR / "startup.lock"
DAEMON_LOG = BASE_DIR / "daemon.log"
MODEL_CACHE = BASE_DIR / "models"
DEFAULT_ADDR = "127.0.0.1"
DEFAULT_PORT = 9999
PORT_RANGE = 10
GITHUB_RELEASES = "https://github.com/prajnyavan/prajnyavan/releases/download"
USE_UDS = os.environ.get("PRAJNYAVAN_USE_UDS", "0") == "1"
UDS_PATH = BASE_DIR / "prajnyavan.sock"


def _platform_dir() -> str:
    system = platform.system().lower()
    machine = platform.machine().lower()
    if system.startswith("linux"):
        return "linux-arm64" if machine in ("aarch64", "arm64") else "linux"
    if system.startswith("darwin"):
        return "macos"
    if system.startswith("windows"):
        return "windows"
    return system


def _binary_path() -> Path:
    name = "prajnyavan_service.exe" if platform.system().lower().startswith("windows") else "prajnyavan_service"
    path = Path(__file__).resolve().parent / "bin" / _platform_dir() / name
    if path.exists() and not platform.system().lower().startswith("windows"):
        # ensure executable bit
        path.chmod(path.stat().st_mode | 0o111)
    return path


def _pid_alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except Exception:
        return False


def _find_free_port(start: int = DEFAULT_PORT) -> int:
    for i in range(PORT_RANGE):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                s.bind((DEFAULT_ADDR, start + i))
                return start + i
            except OSError:
                continue
    raise PrajnyavanSetupError(f"No free port in {DEFAULT_PORT}-{DEFAULT_PORT + PORT_RANGE}")


def _wait_healthy(url: str, timeout: float = 30.0) -> bool:
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            if requests.get(url, timeout=2).ok:
                return True
        except Exception:
            pass
        time.sleep(0.5)
    return False


def _load_config() -> Optional[Dict[str, Any]]:
    try:
        return json.loads(DEV_CONFIG.read_text()) if DEV_CONFIG.exists() else None
    except Exception:
        return None


def _save_config(data: Dict[str, Any]) -> None:
    BASE_DIR.mkdir(parents=True, exist_ok=True)
    DEV_CONFIG.write_text(json.dumps(data, indent=2))
    try:
        DEV_CONFIG.chmod(0o600)
    except Exception:
        pass


def _tail_log(n: int = 20) -> str:
    try:
        return "\n".join(DAEMON_LOG.read_text().splitlines()[-n:])
    except Exception:
        return ""


def _get_token(base_url: str) -> str:
    resp = requests.post(
        f"{base_url}/auth/token",
        json={"user_id": "developer", "capabilities": ["read", "write"]},
        timeout=8,
    )
    resp.raise_for_status()
    return f"Bearer {resp.json()['token']}"


def _try_download_binary(dest: Path) -> None:
    import urllib.request
    try:
        from importlib.metadata import version
        pkg_version = version("prajnyavan")
    except Exception:
        pkg_version = "latest"

    plat = _platform_dir()
    name = "prajnyavan_service.exe" if plat == "windows" else "prajnyavan_service"
    url = f"{GITHUB_RELEASES}/v{pkg_version}/{plat}/{name}"

    print(f"[prajnyavan] Binary not found. Downloading from {url} ...")
    dest.parent.mkdir(parents=True, exist_ok=True)
    try:
        urllib.request.urlretrieve(url, dest)
        if not plat.startswith("windows"):
            dest.chmod(dest.stat().st_mode | 0o111)
        print(f"[prajnyavan] Binary downloaded to {dest}")
    except Exception as e:
        if dest.exists():
            dest.unlink()
        raise PrajnyavanSetupError(
            f"Failed to download binary: {e}\n"
            f"Manual fix: download {name} from {GITHUB_RELEASES}/v{{version}}/ and place at {dest}"
        ) from e


def _lock_file(fd):
    if platform.system().lower().startswith("windows"):
        import msvcrt

        try:
            msvcrt.locking(fd.fileno(), msvcrt.LK_NBLCK, 1)
            return True
        except Exception:
            return False
    if fcntl is None:
        return True
    fcntl.flock(fd, fcntl.LOCK_EX)
    return True


def _unlock_file(fd):
    if platform.system().lower().startswith("windows"):
        import msvcrt

        try:
            msvcrt.locking(fd.fileno(), msvcrt.LK_UNLCK, 1)
        except Exception:
            pass
    elif fcntl:
        try:
            fcntl.flock(fd, fcntl.LOCK_UN)
        except Exception:
            pass


def ensure_daemon_running() -> Dict[str, Any]:
    """
    Idempotently start the bundled service and return dev config (base_url, token, pid).
    """
    BASE_DIR.mkdir(parents=True, exist_ok=True)
    lock_fd = open(STARTUP_LOCK, "w")
    try:
        _lock_file(lock_fd)

        cfg = _load_config()
        if cfg:
            pid = cfg.get("pid")
            if pid and _pid_alive(pid):
                try:
                    if requests.get(f"{cfg['base_url']}/health", timeout=2).ok:
                        return cfg
                except Exception:
                    pass
            DEV_CONFIG.unlink(missing_ok=True)
            PID_FILE.unlink(missing_ok=True)

        # Scan for already-running daemon
        for port in range(DEFAULT_PORT, DEFAULT_PORT + PORT_RANGE):
            url = f"http://{DEFAULT_ADDR}:{port}"
            try:
                if requests.get(f"{url}/health", timeout=1).ok:
                    token = _get_token(url)
                    cfg = {
                        "base_url": url,
                        "port": port,
                        "pid": None,
                        "token": token,
                        "started_at": int(time.time()),
                    }
                    _save_config(cfg)
                    return cfg
            except Exception:
                pass

        binary = _binary_path()
        if not binary.exists():
            _try_download_binary(binary)
        if not binary.exists():
            raise PrajnyavanSetupError(
                f"Binary not found at {binary}. "
                "Fix: pip install --upgrade prajnyavan\n"
                f"Log: {DAEMON_LOG}"
            )

        secret = os.environ.get("BRAIN_SECRET_KEY") or secrets.token_urlsafe(32)
        env = os.environ.copy()
        env.update({"BRAIN_SECRET_KEY": secret})

        if USE_UDS and not platform.system().lower().startswith("windows"):
            uds_path = str(UDS_PATH)
            env["PRAJNYAVAN_UDS"] = uds_path
            base_url = f"http+unix://{UDS_PATH}"
            args = [str(binary), "--uds", uds_path]
        else:
            port = _find_free_port()
            env["BIND_ADDR"] = DEFAULT_ADDR
            env["PORT"] = str(port)
            base_url = f"http://{DEFAULT_ADDR}:{port}"
            args = [str(binary)]

        log_fh = open(DAEMON_LOG, "a")
        creationflags = subprocess.CREATE_NO_WINDOW if platform.system().lower().startswith("windows") else 0
        proc = subprocess.Popen(args, stdout=log_fh, stderr=log_fh, cwd=str(BASE_DIR), env=env, creationflags=creationflags)
        PID_FILE.write_text(str(proc.pid))

        health_url = f"{base_url}/health"
        if not _wait_healthy(health_url, timeout=30):
            proc.kill()
            log_tail = _tail_log()
            raise PrajnyavanSetupError(
                f"Daemon failed to start within 30s.\nLast log lines:\n{log_tail}\nFull log: {DAEMON_LOG}"
            )

        token = _get_token(base_url)
        cfg = {
            "base_url": base_url,
            "port": env.get("PORT"),
            "pid": proc.pid,
            "token": token,
            "started_at": int(time.time()),
        }
        _save_config(cfg)
        print(f"[prajnyavan] daemon started on {base_url} (pid={proc.pid})")
        return cfg
    finally:
        _unlock_file(lock_fd)
        lock_fd.close()


__all__ = [
    "ensure_daemon_running",
    "_load_config",
    "_save_config",
    "_pid_alive",
    "_binary_path",
    "_platform_dir",
    "_try_download_binary",
    "DEV_CONFIG",
    "DAEMON_LOG",
    "MODEL_CACHE",
    "BASE_DIR",
    "PID_FILE",
    "UDS_PATH",
    "USE_UDS",
]
