"""
Prajnyavan — persistent, emotionally-weighted memory for any LLM.

Quick start:
    pip install prajnyavan[openai]

    from prajnyavan import MemoryClient, get_token
"""

from .client import MemoryClient, get_token, auto_client
from .exceptions import (
    PrajnyavanError,
    PrajnyavanConnectionError,
    PrajnyavanAuthError,
    PrajnyavanSetupError,
    PrajnyavanConfigError,
)

__version__ = "0.1.7"
__all__ = [
    "MemoryClient",
    "get_token",
    "auto_client",
    "PrajnyavanError",
    "PrajnyavanConnectionError",
    "PrajnyavanAuthError",
    "PrajnyavanSetupError",
    "PrajnyavanConfigError",
]
