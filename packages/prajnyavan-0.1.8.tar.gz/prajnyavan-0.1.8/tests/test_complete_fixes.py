import os
import time
import requests
import pytest

from prajnyavan import MemoryClient

pytestmark = pytest.mark.skipif(
    not os.environ.get("RUN_PRAJNYAVAN_INTEGRATION"),
    reason="Set RUN_PRAJNYAVAN_INTEGRATION=1 to run",
)


@pytest.fixture(scope="module")
def mem():
    return MemoryClient.dev()


# P-1: category filter --------------------------------------------------------
def test_category_filter_works(mem):
    uid = "test_category_fix"
    mem.store(uid, "I love hiking mountains", category="hobbies", importance=0.8)
    mem.store(uid, "Q3 financial report submitted", category="work", importance=0.8)
    time.sleep(0.2)

    results = mem.search(uid, "activities", category="hobbies")
    categories = [
        t.replace("category:", "")
        for r in results
        for t in r.get("tags", [])
        if t.startswith("category:")
    ]
    assert all(c == "hobbies" for c in categories), f"Expected only hobbies, got: {categories}"

    results_work = mem.search(uid, "activities", category="work")
    work_cats = [
        t
        for r in results_work
        for t in r.get("tags", [])
        if t.startswith("category:") and t != "category:work"
    ]
    assert not work_cats, f"Work filter leaked other categories: {work_cats}"


# P-2: min_importance filter --------------------------------------------------
def test_min_importance_filter(mem):
    uid = "test_importance_fix"
    mem.store(uid, "trivial thought", importance=0.1)
    mem.store(uid, "critical insight", importance=0.9)
    time.sleep(0.2)

    results = mem.search(uid, "thought insight", min_importance=0.7)
    for r in results:
        assert r.get("importance", 0) >= 0.7, f"Got importance {r.get('importance')} below threshold 0.7"


# P-3: exact_match server-side -----------------------------------------------
def test_exact_match_server_side(mem):
    uid = "test_exact_match_fix"
    needle = "xyzzy_unique_token_9f3a"
    mem.store(uid, f"This memory contains {needle} right here", importance=0.5)
    time.sleep(0.2)

    results = mem.search(uid, needle, k=1, exact_match=True)
    contents = [r.get("content_text", "") for r in results]
    assert any(needle in c for c in contents), f"exact_match=True should find '{needle}' even at k=1"

    results_no = mem.search(uid, "completely different query", exact_match=True)
    contents_no = [r.get("content_text", "") for r in results_no]
    assert all("completely different query" in c for c in contents_no) or len(contents_no) == 0


# P-4: store returns emotion --------------------------------------------------
def test_store_returns_emotion(mem):
    uid = "test_emotion_return"
    result = mem.store(uid, "I am so happy and excited!", importance=0.8, return_metadata=True)
    assert "primary_emotion" in result
    assert "valence" in result
    assert "importance" in result
    assert isinstance(result["valence"], float)


# P-5: new SDK methods --------------------------------------------------------
def test_get_memory(mem):
    uid = "test_get_memory"
    mid = mem.store(uid, "retrievable memory content")
    result = mem.get_memory(mid)
    assert result.get("id") == mid
    assert "content_text" in result


def test_store_and_get_related(mem):
    uid = "test_graph"
    id1 = mem.store(uid, "Python programming language", category="tech")
    id2 = mem.store(uid, "Rust programming language", category="tech")
    time.sleep(0.2)
    mem.associate(id1, id2, edge_type=1, strength=0.9)
    related = mem.get_related(id1, depth=1)
    ids = [r.get("id") for r in related]
    assert id2 in ids, f"id2 should appear in related for id1; got {ids}"


def test_store_profile(mem):
    uid = "test_profile"
    result = mem.store_profile(uid, "role", "Engineer", importance=0.9)
    assert result.get("status") in ("created", "updated")
    result2 = mem.store_profile(uid, "role", "Senior Engineer", importance=0.9)
    assert result2.get("status") == "updated"


def test_update(mem):
    uid = "test_update"
    mid = mem.store(uid, "original content", importance=0.3)
    ok = mem.update(mid, {"importance": 0.95})
    assert ok
    updated = mem.get_memory(mid)
    assert updated.get("importance", 0) >= 0.9


def test_stats(mem):
    stats = mem.stats()
    assert "total_stores" in stats
    assert "p95_store_ms" in stats


def test_get_emotion(mem):
    emotion = mem.get_emotion()
    assert "primary_emotion" in emotion
    assert "valence" in emotion

def test_get_user_emotion(mem):
    uid = "user_emotion_test"
    mem.store(uid, "I feel joyful today", importance=0.7)
    snapshot = mem.get_user_emotion(uid)
    assert snapshot.get("memory_count", 0) >= 1
    assert "primary_emotion" in snapshot
    assert "valence" in snapshot


def test_forget_with_options(mem):
    uid = "test_forget"
    mid = mem.store(uid, "to be forgotten", importance=0.5)
    ok = mem.forget(mid, "test_delete", tombstone_only=False, purge_archive=True)
    assert ok


def test_compact(mem):
    assert mem.compact("semantic")
    assert mem.compact("episodic")
    assert mem.compact("graph")


def test_recover_from_wal(mem):
    assert mem.recover_from_wal()


# P-7: current_memory_count ---------------------------------------------------
def test_health_memory_count(mem):
    cfg_url = mem.base_url
    health = requests.get(f"{cfg_url}/health", timeout=3).json()
    assert "current_memory_count" in health
    assert "total_stores_ever" in health
    assert health["current_memory_count"] <= health["total_stores_ever"]
