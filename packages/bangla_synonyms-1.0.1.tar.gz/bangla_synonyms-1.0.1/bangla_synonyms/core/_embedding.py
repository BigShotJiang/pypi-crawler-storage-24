"""
bangla_synonyms.core._embedding
--------------------------------
Embedding-based synonym source — finds semantically similar Bangla words
using pre-trained vector models from the BNLP toolkit.

Unlike the web-scraping sources (Wiktionary, Shabdkosh, English-Bangla),
this source works entirely offline once the model is downloaded.  It finds
words whose vector representations are close to the query word in the
embedding space, so it can surface valid synonyms that the scraping sources
miss (e.g. less common literary words).

Three backends are supported
----------------------------
``"word2vec"``  (default)
    ``bnwiki_word2vec.model`` — gensim Word2Vec trained on Bengali Wikipedia
    and news articles.  300-dimensional vectors.  Most accurate for
    synonym retrieval because it captures substitution contexts well.
    Model size: ~200 MB.  Auto-downloaded to ``~/bnlp/models/``.

``"glove"``
    ``bn_glove.39M.100d.txt`` — GloVe vectors trained on 39 M Bengali tokens.
    100-dimensional.  Loaded entirely into memory as a dict.
    Model size: ~150 MB.  Auto-downloaded.

``"fasttext"``
    ``bengali_fasttext_wiki.bin`` — FastText binary trained on Bengali
    Wikipedia.  300-dimensional.  Handles OOV words via subword n-grams
    (good for morphologically rich Bengali words).
    Requires: ``pip install fasttext``
    Model size: ~700 MB.  Auto-downloaded.

Source contract
---------------
The function exposed to the SOURCES registry follows the same contract as
every other source in this package:

    fetch_embedding(word, session, timeout) -> list[str] | None

    list[str]  — similar words found (may be empty if word is OOV)
    None       — model unavailable (not installed / download failed)

``session`` and ``timeout`` are accepted for API compatibility but are not
used — this source makes no HTTP calls.

Registration
------------
Call ``register_embedding_source()`` once at startup to add the source to the
SOURCES registry.  It is NOT in DEFAULT_SOURCES by default because the model
download is large (~200 MB+) and the caller must opt in explicitly:

    from bangla_synonyms.core._embedding import register_embedding_source
    register_embedding_source()                    # default: word2vec, topn=10

    # or with options:
    register_embedding_source(backend="glove", topn=15, min_similarity=0.6)
    register_embedding_source(backend="fasttext", topn=20)

After registration the source is available everywhere:

    import bangla_synonyms as bs
    bs.get("চোখ", sources=["embedding"])
    bs.get("চোখ", sources=["wiktionary", "embedding"])
    bs.get("চোখ")   # if also added to DEFAULT_SOURCES

Public helpers
--------------
    EmbeddingSource          — class wrapping one backend, reusable directly
    register_embedding_source(backend, topn, min_similarity, model_path)
    fetch_embedding(word, session, timeout) -> list[str] | None
"""
from __future__ import annotations

import logging
from typing import Any

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Supported backends
# ---------------------------------------------------------------------------
SUPPORTED_BACKENDS = ("word2vec", "glove", "fasttext")

# Default values
_DEFAULT_BACKEND        = "word2vec"
_DEFAULT_TOPN           = 10
_DEFAULT_MIN_SIMILARITY = 0.5   # cosine similarity floor (word2vec / fasttext)
                                 # euclidean distance is used for glove — see note below


# ---------------------------------------------------------------------------
# EmbeddingSource — wraps one backend model
# ---------------------------------------------------------------------------

class EmbeddingSource:
    """
    Thin wrapper around a BNLP embedding model that exposes a uniform
    ``get_similar(word, topn)`` interface regardless of which backend is used.

    Parameters
    ----------
    backend
        One of ``"word2vec"``, ``"glove"``, ``"fasttext"``.
    topn
        Maximum number of similar words to return.
    min_similarity
        Cosine-similarity floor for word2vec / fasttext results.
        Candidates below this threshold are discarded.
        Not applicable to GloVe (which uses Euclidean distance ranking).
    model_path
        Optional path to a pre-downloaded model file.  When omitted the
        BNLP auto-downloader fetches the default pre-trained model.

    Notes on GloVe similarity
    -------------------------
    BNLP's ``BengaliGlove.get_closest_word()`` returns words sorted by
    Euclidean distance but does not expose the distance value.  We therefore
    cannot apply a similarity threshold for GloVe — all ``topn`` results are
    returned.  For threshold-based filtering use word2vec or fasttext.
    """

    def __init__(
        self,
        backend:        str   = _DEFAULT_BACKEND,
        topn:           int   = _DEFAULT_TOPN,
        min_similarity: float = _DEFAULT_MIN_SIMILARITY,
        model_path:     str   = "",
    ) -> None:
        if backend not in SUPPORTED_BACKENDS:
            raise ValueError(
                f"Unknown backend '{backend}'. "
                f"Choose from: {SUPPORTED_BACKENDS}"
            )
        self.backend        = backend
        self.topn           = topn
        self.min_similarity = min_similarity
        self.model_path     = model_path
        self._model: Any    = None   # lazy-loaded on first call

    # -----------------------------------------------------------------------
    # Lazy model loader
    # -----------------------------------------------------------------------

    def _load(self) -> bool:
        """
        Load the model on first use.  Returns ``True`` on success.

        The model is cached in ``self._model`` so subsequent calls are free.
        Returns ``False`` (and logs a warning) when the backend package is
        missing or the download fails — the caller treats this as ``None``
        (source unavailable) rather than raising.
        """
        if self._model is not None:
            return True

        try:
            if self.backend == "word2vec":
                self._model = self._load_word2vec()

            elif self.backend == "glove":
                self._model = self._load_glove()

            elif self.backend == "fasttext":
                self._model = self._load_fasttext()

            return self._model is not None

        except Exception as exc:
            log.warning(
                "[embedding] failed to load %s model: %s", self.backend, exc
            )
            return False

    def _load_word2vec(self):
        from bnlp import BengaliWord2Vec
        kwargs = {"model_path": self.model_path} if self.model_path else {}
        log.info("[embedding] loading word2vec model (first call may download ~200 MB)...")
        return BengaliWord2Vec(**kwargs)

    def _load_glove(self):
        from bnlp import BengaliGlove
        kwargs = {"glove_vector_path": self.model_path} if self.model_path else {}
        log.info("[embedding] loading GloVe model (first call may download ~150 MB)...")
        return BengaliGlove(**kwargs)

    def _load_fasttext(self):
        try:
            import fasttext  # noqa: F401
        except ImportError:
            raise ImportError(
                "fasttext is not installed. "
                "Install it with: pip install fasttext"
            )
        from bnlp.embedding.fasttext import BengaliFasttext
        kwargs = {"model_path": self.model_path} if self.model_path else {}
        log.info("[embedding] loading FastText model (first call may download ~700 MB)...")
        return BengaliFasttext(**kwargs)

    # -----------------------------------------------------------------------
    # Unified interface
    # -----------------------------------------------------------------------

    def get_similar(self, word: str) -> list[str]:
        """
        Return up to ``self.topn`` words similar to ``word``.

        Returns an empty list when the word is out-of-vocabulary (OOV) for
        word2vec / GloVe, or when the model is unavailable.  FastText handles
        OOV words via subword n-grams and rarely returns empty.

        Similarity filtering
        --------------------
        word2vec and fasttext return ``(word, score)`` pairs where ``score``
        is cosine similarity in [0, 1].  Candidates with score below
        ``self.min_similarity`` are dropped before the ``topn`` cap is applied,
        so the actual number of results may be fewer than ``topn``.

        GloVe returns only word strings (no score), so no threshold is applied.
        """
        if not self._load():
            return []

        try:
            if self.backend == "word2vec":
                return self._similar_word2vec(word)
            elif self.backend == "glove":
                return self._similar_glove(word)
            elif self.backend == "fasttext":
                return self._similar_fasttext(word)
        except KeyError:
            # OOV for word2vec / GloVe — word not in vocabulary
            log.debug("[embedding] '%s' is OOV for %s model", word, self.backend)
        except Exception as exc:
            log.warning("[embedding] error getting similar words for '%s': %s", word, exc)

        return []

    def _similar_word2vec(self, word: str) -> list[str]:
        # get_most_similar_words returns List[Tuple[str, float]] (cosine sim)
        raw: list[tuple[str, float]] = self._model.get_most_similar_words(
            word, topn=self.topn * 3   # fetch extra; some will be filtered
        )
        return [
            w for w, score in raw
            if score >= self.min_similarity
        ][:self.topn]

    def _similar_glove(self, word: str) -> list[str]:
        # get_closest_word returns List[str] sorted by Euclidean distance.
        # Index 0 is the word itself, so skip it.
        raw: list[str] = self._model.get_closest_word(word)
        return [w for w in raw if w != word][:self.topn]

    def _similar_fasttext(self, word: str) -> list[str]:
        # FastText model from BNLP uses gensim-style API when loaded from .vec
        # but the BNLP BengaliFasttext class wraps the binary .bin model which
        # only exposes get_word_vector().  We use gensim KeyedVectors to load
        # the binary and call most_similar().
        #
        # Approach: use the underlying fasttext model's get_nearest_neighbors()
        # which is available on the native fasttext.FastText object.
        ft_model = self._model.model   # fasttext.FastText object
        # get_nearest_neighbors returns List[Tuple[float, str]] (score, word)
        raw = ft_model.get_nearest_neighbors(word, k=self.topn * 3)
        return [
            w for score, w in raw
            if score >= self.min_similarity
        ][:self.topn]

    def __repr__(self) -> str:
        loaded = self._model is not None
        return (
            f"EmbeddingSource(backend={self.backend!r}, "
            f"topn={self.topn}, "
            f"min_similarity={self.min_similarity}, "
            f"loaded={loaded})"
        )


# ---------------------------------------------------------------------------
# Module-level singleton — one model instance shared across all calls
# ---------------------------------------------------------------------------

_active_source: EmbeddingSource | None = None


# ---------------------------------------------------------------------------
# Source contract function — registered in SOURCES
# ---------------------------------------------------------------------------

def fetch_embedding(
    word:    str,
    session: Any,    # unused — accepted for API compatibility
    timeout: int,    # unused — accepted for API compatibility
) -> list[str] | None:
    """
    Return embedding-similar words for ``word``.

    Follows the standard source contract:
        list[str]  — results (may be empty if word is OOV)
        None       — source unavailable (model not loaded / import error)

    ``session`` and ``timeout`` are unused; this source is fully offline.

    The active ``EmbeddingSource`` instance must be configured before this
    function is called.  Use ``register_embedding_source()`` to set it up.
    """
    global _active_source
    if _active_source is None:
        log.warning(
            "[embedding] fetch_embedding called but no source registered. "
            "Call register_embedding_source() first."
        )
        return None

    results = _active_source.get_similar(word)

    # Return None only when the model itself is broken (not just OOV).
    # An empty list means OOV — the caller will try the next source.
    if results is None:
        return None

    return results


# ---------------------------------------------------------------------------
# Registration helper
# ---------------------------------------------------------------------------

def register_embedding_source(
    backend:        str   = _DEFAULT_BACKEND,
    topn:           int   = _DEFAULT_TOPN,
    min_similarity: float = _DEFAULT_MIN_SIMILARITY,
    model_path:     str   = "",
    add_to_defaults: bool = False,
) -> None:
    """
    Configure the embedding source and register it in the SOURCES registry.

    Must be called once before passing ``"embedding"`` to any ``sources=``
    argument or before adding it to DEFAULT_SOURCES.

    Parameters
    ----------
    backend
        Embedding model to use: ``"word2vec"`` (default), ``"glove"``,
        or ``"fasttext"``.
    topn
        Maximum similar words to return per query (default: 10).
    min_similarity
        Cosine-similarity floor for word2vec / fasttext (default: 0.5).
        Not applied to GloVe.
    model_path
        Path to a pre-downloaded model file.  Leave empty to use BNLP's
        auto-downloader (model saved to ``~/bnlp/models/``).
    add_to_defaults
        If ``True``, also append ``"embedding"`` to ``DEFAULT_SOURCES`` so
        it is queried automatically when ``sources=None``.

    Examples
    --------
        from bangla_synonyms.core._embedding import register_embedding_source

        # word2vec, default settings
        register_embedding_source()

        # GloVe, more results
        register_embedding_source(backend="glove", topn=20)

        # FastText, stricter threshold, add to default pipeline
        register_embedding_source(
            backend="fasttext",
            topn=15,
            min_similarity=0.65,
            add_to_defaults=True,
        )

        # Then use normally:
        import bangla_synonyms as bs
        bs.get("চোখ", sources=["wiktionary", "embedding"])
    """
    global _active_source

    _active_source = EmbeddingSource(
        backend        = backend,
        topn           = topn,
        min_similarity = min_similarity,
        model_path     = model_path,
    )

    # Register in the SOURCES dict (import here to avoid circular imports)
    from bangla_synonyms.core import SOURCES, DEFAULT_SOURCES
    SOURCES["embedding"] = fetch_embedding

    if add_to_defaults and "embedding" not in DEFAULT_SOURCES:
        DEFAULT_SOURCES.append("embedding")

    log.info(
        "[embedding] registered source: backend=%s, topn=%d, "
        "min_similarity=%s, in_defaults=%s",
        backend, topn, min_similarity, add_to_defaults,
    )
    print(
        f"[bangla-synonyms] embedding source registered "
        f"(backend={backend!r}, topn={topn}, "
        f"min_similarity={min_similarity})"
    )