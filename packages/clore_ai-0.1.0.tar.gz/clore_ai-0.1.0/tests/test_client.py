"""Tests for Clore.ai client."""

import pytest
from unittest.mock import Mock, patch

from clore_ai import CloreAI
from clore_ai.exceptions import AuthError, RateLimitError


@pytest.fixture
def mock_response():
    """Mock HTTP response."""
    response = Mock()
    response.status_code = 200
    response.raise_for_status = Mock()
    return response


@pytest.fixture
def client():
    """Create test client."""
    return CloreAI(api_key="test_key")


def test_client_initialization():
    """Test client can be initialized."""
    client = CloreAI(api_key="test_key")
    assert client.api_key == "test_key"
    assert client.base_url == "https://api.clore.ai/v1"


def test_client_no_api_key():
    """Test client works without API key for public endpoints."""
    client = CloreAI()
    assert client.api_key is None


def test_auth_required(client):
    """Test authentication error when API key missing."""
    client.api_key = None
    with pytest.raises(AuthError):
        client.wallets()


@patch("httpx.Client.get")
def test_marketplace_public(mock_get, mock_response):
    """Test marketplace works without auth."""
    mock_response.json = Mock(return_value={"code": 0, "servers": []})
    mock_get.return_value = mock_response

    client = CloreAI()  # No API key
    servers = client.marketplace()
    assert isinstance(servers, list)


@patch("httpx.Client.get")
def test_wallets_success(mock_get, mock_response, client):
    """Test successful wallets retrieval."""
    mock_response.json = Mock(
        return_value={
            "code": 0,
            "wallets": [
                {"currency": "BTC", "balance": 0.001, "address": "bc1..."},
                {"currency": "ETH", "balance": 0.1, "address": "0x..."},
            ],
        }
    )
    mock_get.return_value = mock_response

    wallets = client.wallets()
    assert len(wallets) == 2
    assert wallets[0].currency == "BTC"
    assert wallets[1].balance == 0.1


@patch("httpx.Client.get")
def test_marketplace_with_filters(mock_get, mock_response, client):
    """Test marketplace filtering."""
    mock_response.json = Mock(
        return_value={
            "code": 0,
            "servers": [
                {
                    "id": 1,
                    "gpu": "RTX 4090",
                    "gpu_count": 2,
                    "ram": 64.0,
                    "price": 3.5,
                    "available": True,
                },
                {
                    "id": 2,
                    "gpu": "RTX 3090",
                    "gpu_count": 1,
                    "ram": 32.0,
                    "price": 1.2,
                    "available": True,
                },
            ],
        }
    )
    mock_get.return_value = mock_response

    servers = client.marketplace(gpu="RTX 4090", max_price_usd=5.0)
    assert len(servers) == 1
    assert servers[0].gpu_model == "RTX 4090"


@patch("httpx.Client.get")
def test_rate_limit_error(mock_get, mock_response, client):
    """Test rate limit handling."""
    mock_response.json = Mock(return_value={"code": 5, "message": "Rate limit exceeded"})
    mock_get.return_value = mock_response

    with pytest.raises(RateLimitError):
        client.wallets()


@patch("httpx.Client.post")
def test_create_order(mock_post, mock_response, client):
    """Test order creation."""
    mock_response.json = Mock(
        return_value={
            "code": 0,
            "order": {
                "id": 123,
                "renting_server": 456,
                "type": "on-demand",
                "status": "active",
                "pub_cluster": "1.2.3.4",
            },
        }
    )
    mock_post.return_value = mock_response

    order = client.create_order(
        server_id=456,
        image="ubuntu",
        type="on-demand",
        currency="bitcoin",
        ssh_password="secret",
    )

    assert order.id == 123
    assert order.pub_cluster == "1.2.3.4"


@patch("httpx.Client.post")
def test_cancel_order(mock_post, mock_response, client):
    """Test order cancellation."""
    mock_response.json = Mock(return_value={"code": 0, "message": "Order cancelled"})
    mock_post.return_value = mock_response

    result = client.cancel_order(order_id=123, issue="Test cancellation")
    assert result["code"] == 0


def test_context_manager():
    """Test client context manager."""
    with CloreAI(api_key="test") as client:
        assert client.api_key == "test"
    # Client should be closed after context exit
