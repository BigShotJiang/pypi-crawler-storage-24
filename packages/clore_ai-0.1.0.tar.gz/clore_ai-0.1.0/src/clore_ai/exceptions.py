"""Custom exceptions for Clore.ai SDK."""


class CloreAPIError(Exception):
    """Base exception for all Clore.ai API errors."""

    def __init__(self, message: str, code: int | None = None, response: dict | None = None):
        self.code = code
        self.response = response
        super().__init__(message)


class DBError(CloreAPIError):
    """Database error (code 1)."""

    pass


class InvalidInputError(CloreAPIError):
    """Invalid input provided (code 2)."""

    pass


class AuthError(CloreAPIError):
    """Authentication failed (code 3)."""

    pass


class InvalidEndpointError(CloreAPIError):
    """Invalid endpoint requested (code 4)."""

    pass


class RateLimitError(CloreAPIError):
    """Rate limit exceeded (code 5)."""

    pass


class FieldError(CloreAPIError):
    """Error in specific field (code 6)."""

    pass


ERROR_MAP = {
    1: DBError,
    2: InvalidInputError,
    3: AuthError,
    4: InvalidEndpointError,
    5: RateLimitError,
    6: FieldError,
}
