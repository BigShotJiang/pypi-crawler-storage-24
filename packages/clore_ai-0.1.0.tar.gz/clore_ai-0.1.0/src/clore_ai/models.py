"""Pydantic models for Clore.ai API responses."""

from typing import Any, Dict, Optional
from pydantic import BaseModel, ConfigDict, Field


class Wallet(BaseModel):
    """Wallet balance information."""

    currency: str
    balance: float
    address: Optional[str] = None


class Server(BaseModel):
    """GPU server in marketplace."""

    model_config = ConfigDict(populate_by_name=True)

    id: int
    name: Optional[str] = None
    gpu_model: Optional[str] = Field(None, alias="gpu")
    gpu_count: Optional[int] = None
    ram_gb: Optional[float] = Field(None, alias="ram")
    cpu_cores: Optional[int] = Field(None, alias="cpu")
    disk_gb: Optional[float] = Field(None, alias="disk")
    price_usd_per_hour: Optional[float] = Field(None, alias="price")
    available: Optional[bool] = None
    location: Optional[str] = None


class Order(BaseModel):
    """Active or completed order."""

    model_config = ConfigDict(populate_by_name=True)

    id: int
    server_id: Optional[int] = Field(None, alias="renting_server")
    type: str  # "on-demand" or "spot"
    status: Optional[str] = None
    image: Optional[str] = None
    currency: Optional[str] = None
    price: Optional[float] = None
    created_at: Optional[str] = None
    pub_cluster: Optional[str] = None  # Public IP
    tcp_ports: Optional[Dict[str, int]] = None  # Port mappings
    env: Optional[Dict[str, str]] = None
    ssh_password: Optional[str] = None


class ServerConfig(BaseModel):
    """Server configuration details."""

    model_config = ConfigDict(populate_by_name=True)

    name: str
    availability: Optional[bool] = None
    mrl: Optional[int] = None  # Minimum rental length
    on_demand_price: Optional[float] = Field(None, alias="on_demand")
    spot_price: Optional[float] = Field(None, alias="spot")
    specs: Optional[Dict[str, Any]] = None


class SpotOffer(BaseModel):
    """Spot market offer."""

    model_config = ConfigDict(populate_by_name=True)

    order_id: int
    price: float
    server_id: Optional[int] = None


class APIResponse(BaseModel):
    """Generic API response wrapper."""

    code: int
    message: Optional[str] = None
    data: Optional[Any] = None
