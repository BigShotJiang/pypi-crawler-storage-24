# Minimal shim for editable installs with older pip versions (< 21.3)
# pyproject.toml is the authoritative build config.
from setuptools import setup

setup()
