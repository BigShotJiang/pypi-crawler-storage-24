"""
Climeter Python SDK
The billing layer for AI tools — CLI Billing & Metering

Quick start::

    from climeter import meter

    # Configure once (or set CLIMETER_API_KEY env var)
    meter.configure(api_key="clm_xxx")

    # Decorator — fire-and-forget, never blocks
    @meter.track(price=0.01)
    def my_command(args):
        ...

    # Context manager
    with meter.track_usage("my-command", price=0.01):
        result = do_work()

    # Functional
    meter.record("my-command", price=0.01)
"""

from .client import ClimeterClient
from .meter import Meter, call, InsufficientBalanceError, check_balance, set_cache_ttl, clear_cache
from .context import detect_caller_type, detect_caller_id, caller_info
from .pricing import TieredPricing, PricingPresets

# Global meter instance — import and use directly
meter = Meter()

__version__ = "0.1.4"
__all__ = [
    "ClimeterClient",
    "Meter",
    "meter",
    "call",
    "InsufficientBalanceError",
    "check_balance",
    "set_cache_ttl",
    "clear_cache",
    "configure",
    "detect_caller_type",
    "detect_caller_id",
    "caller_info",
    "TieredPricing",
    "PricingPresets",
]


def configure(
    api_key: str,
    api_url: str = "https://api.climeter.ai",
    tool_slug: str = "",
) -> None:
    """
    Module-level shortcut for ``meter.configure(...)``.

    Example::

        import climeter
        climeter.configure(api_key="clm_xxx", tool_slug="my-tool")
    """
    meter.configure(api_key=api_key, api_url=api_url, tool_slug=tool_slug)
