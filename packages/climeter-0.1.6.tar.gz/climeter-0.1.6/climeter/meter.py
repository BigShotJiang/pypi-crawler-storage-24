"""
Meter — the main developer-facing interface.

Usage:
    from climeter import meter

    # Configure once (or via CLIMETER_API_KEY env var)
    meter.configure(api_key="clm_xxx")

    # Decorator — pricing is set in your CLIMeter dashboard, not in code
    @meter.track(command="search")
    def search(query: str):
        ...

    # Context manager
    with meter.track_usage("search"):
        result = do_search(query)

    # Async decorator
    @meter.track(command="search")
    async def search(query: str):
        ...

    # Pre-flight balance check
    from climeter import check_balance
    balance = check_balance("my-tool")

Note:
    Pricing (price_per_call) is configured in the CLIMeter dashboard per tool.
    The SDK does not accept a price argument — the server enforces the price
    set in your dashboard for security and billing integrity.
"""

import asyncio
import contextlib
import datetime
import functools
import json
import os
import sys
import threading
import time
import urllib.error
import urllib.request
from typing import Any, Callable, Dict, Iterator, Optional, TypeVar

from .client import ClimeterClient, DEFAULT_BASE_URL

F = TypeVar("F", bound=Callable[..., Any])

# Module-level balance cache (TTL 60s by default)
_balance_cache: Dict[str, Any] = {
    "balance": None,
    "ts": 0,
    "ttl": 60,  # seconds
    "calls_remaining": 0,
    "free_calls_remaining": 0,
}
_CACHE_LOCK = threading.Lock()

_NO_KEY_WARNING_SHOWN = False
_WARNING_LOCK = threading.Lock()

# SDK Version
SDK_VERSION = "python/0.1.5"


class InsufficientBalanceError(Exception):
    """Raised when the user's wallet has insufficient balance."""

    def __init__(self, message: str, checkout_url: str, balance: float, cost: float):
        super().__init__(message)
        self.checkout_url = checkout_url
        self.balance = balance
        self.cost = cost


def _warn_once(message: str) -> None:
    global _NO_KEY_WARNING_SHOWN
    with _WARNING_LOCK:
        if not _NO_KEY_WARNING_SHOWN:
            print(f"[climeter] WARNING: {message}", flush=True)
            _NO_KEY_WARNING_SHOWN = True


def _utc_now() -> str:
    return datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")


# ------------------------------------------------------------------
# Cache management functions
# ------------------------------------------------------------------

def set_cache_ttl(seconds: int) -> None:
    """
    Override the balance cache TTL.

    Args:
        seconds: Time-to-live in seconds (default: 60)
    """
    global _balance_cache
    with _CACHE_LOCK:
        _balance_cache["ttl"] = seconds


def clear_cache() -> None:
    """Force-refresh the balance cache."""
    global _balance_cache
    with _CACHE_LOCK:
        _balance_cache["balance"] = None
        _balance_cache["ts"] = 0
        _balance_cache["calls_remaining"] = 0
        _balance_cache["free_calls_remaining"] = 0


def _get_cached_balance(tool: str = "") -> Optional[Dict[str, Any]]:
    """Return cached balance if fresh, else None."""
    with _CACHE_LOCK:
        if _balance_cache["balance"] is None:
            return None
        if time.time() - _balance_cache["ts"] < _balance_cache["ttl"]:
            return {
                "balance": _balance_cache["balance"],
                "calls_remaining": _balance_cache["calls_remaining"],
                "free_calls_remaining": _balance_cache["free_calls_remaining"],
                "tool": tool,
            }
    return None


def _update_cache(balance: float, calls_remaining: int = 0, free_calls_remaining: int = 0) -> None:
    """Update the balance cache after a successful call."""
    global _balance_cache
    with _CACHE_LOCK:
        _balance_cache["balance"] = balance
        _balance_cache["ts"] = time.time()
        _balance_cache["calls_remaining"] = calls_remaining
        _balance_cache["free_calls_remaining"] = free_calls_remaining


def check_balance(tool: str = "") -> Dict[str, Any]:
    """
    Pre-flight balance check.

    Calls GET /v1/consumer/balance?tool={tool} (or uses cache if fresh).
    Returns {"balance": 4.98, "calls_remaining": 2490, "free_calls_remaining": 0}.

    Args:
        tool: Optional tool slug to calculate calls_remaining

    Returns:
        dict with keys: balance, calls_remaining, free_calls_remaining

    Example::

        from climeter import check_balance
        balance = check_balance("my-tool")
        print(f"Balance: ${balance['balance']:.2f}")
    """
    cached = _get_cached_balance(tool)
    if cached:
        return cached

    _api_key = os.environ.get("CLIMETER_API_KEY", "")
    _api_url = os.environ.get("CLIMETER_API_URL", DEFAULT_BASE_URL).rstrip("/")

    if not _api_key:
        raise ValueError("CLIMETER_API_KEY is not set")

    url = f"{_api_url}/v1/consumer/balance"
    if tool:
        url += f"?tool={tool}"

    req = urllib.request.Request(
        url,
        headers={
            "Authorization": f"Bearer {_api_key}",
            "X-CLIMeter-SDK-Version": SDK_VERSION,
        },
        method="GET",
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode())
            _update_cache(
                data.get("balance", 0),
                data.get("calls_remaining", 0),
                data.get("free_calls_remaining", 0),
            )
            return data
    except urllib.error.HTTPError as e:
        body = json.loads(e.read().decode())
        raise Exception(f"Balance check failed: {body.get('error', 'unknown error')}")
    except Exception as e:
        raise Exception(f"Balance check failed: {str(e)}")


class Meter:
    """
    Thread-safe meter interface. Lazily initialises from environment variables.
    All operations are fire-and-forget — they never block the caller.

    Pricing is configured per-tool in the CLIMeter dashboard.
    The SDK never accepts or sends a price — the server enforces it.
    """

    def __init__(self) -> None:
        self._client: Optional[ClimeterClient] = None
        self._tool_slug: str = ""
        self._lock = threading.Lock()

    # ------------------------------------------------------------------
    # Configuration
    # ------------------------------------------------------------------

    def configure(
        self,
        api_key: str,
        api_url: str = DEFAULT_BASE_URL,
        tool_slug: str = "",
    ) -> None:
        """
        Configure the meter globally.

        Args:
            api_key:   Your CLIMeter API key (clim_v1_...)
            api_url:   Override the API base URL (default: https://api.climeter.ai)
            tool_slug: Optional slug identifying this tool across events
        """
        with self._lock:
            self._client = ClimeterClient(api_key=api_key, base_url=api_url)
            self._tool_slug = tool_slug

    _configure = configure

    def _get_client(self) -> Optional[ClimeterClient]:
        """Return initialised client, or None (with a one-time warning) if unconfigured."""
        if self._client is None:
            with self._lock:
                if self._client is None:
                    api_key = os.environ.get("CLIMETER_API_KEY", "")
                    api_url = os.environ.get("CLIMETER_API_URL", DEFAULT_BASE_URL)
                    tool_slug = os.environ.get("CLIMETER_TOOL_SLUG", "")
                    if not api_key:
                        _warn_once(
                            "CLIMETER_API_KEY is not set. Metering is disabled. "
                            "Set the env var or call meter.configure(api_key='...')."
                        )
                        return None
                    self._client = ClimeterClient(api_key=api_key, base_url=api_url)
                    self._tool_slug = tool_slug
        return self._client

    # ------------------------------------------------------------------
    # Core record
    # ------------------------------------------------------------------

    def record(
        self,
        event_name: str,
        *,
        tool_slug: str = "",
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        """
        Fire-and-forget: enqueue a single usage event.
        Returns immediately — never blocks.

        Pricing is set in your CLIMeter dashboard, not here.
        """
        client = self._get_client()
        if client is None:
            return

        tool_id_or_slug = tool_slug or self._tool_slug or event_name

        payload: Dict[str, Any] = {
            "command": event_name,
            "status": "success",
            "tool_slug": tool_id_or_slug,
            "metadata": metadata or {},
            "timestamp": _utc_now(),
        }
        client.enqueue(payload)

    # ------------------------------------------------------------------
    # Decorator
    # ------------------------------------------------------------------

    def track(
        self,
        command: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Callable[[F], F]:
        """
        Decorator that automatically records a usage event after each call.

        Pricing is set per-tool in the CLIMeter dashboard — not in code.

        Args:
            command:  Event name (defaults to function name)
            metadata: Extra key-value pairs attached to the event

        Example::

            @meter.track(command="search")
            def search(query: str):
                ...

            # command defaults to function name if omitted:
            @meter.track()
            def summarise(text: str):
                ...
        """

        def decorator(fn: F) -> F:
            event_name = command or fn.__name__

            if asyncio.iscoroutinefunction(fn):
                @functools.wraps(fn)
                async def async_wrapper(*args, **kwargs):
                    try:
                        return await fn(*args, **kwargs)
                    finally:
                        self.record(event_name, metadata=metadata)
                        self._maybe_print_badge()

                return async_wrapper  # type: ignore
            else:
                @functools.wraps(fn)
                def sync_wrapper(*args, **kwargs):
                    try:
                        return fn(*args, **kwargs)
                    finally:
                        self.record(event_name, metadata=metadata)
                        self._maybe_print_badge()

                return sync_wrapper  # type: ignore

        return decorator

    # ------------------------------------------------------------------
    # Context manager
    # ------------------------------------------------------------------

    @contextlib.contextmanager
    def track_usage(
        self,
        event_name: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> Iterator[None]:
        """
        Context manager that records a usage event on exit.

        Pricing is set per-tool in the CLIMeter dashboard — not here.

        Example::

            with meter.track_usage("search"):
                result = do_search(query)
        """
        try:
            yield
        finally:
            self.record(event_name, metadata=metadata)

    # ------------------------------------------------------------------
    # Async context manager
    # ------------------------------------------------------------------

    @contextlib.asynccontextmanager
    async def track_usage_async(
        self,
        event_name: str,
        metadata: Optional[Dict[str, Any]] = None,
    ):
        """
        Async context manager version of track_usage.

        Example::

            async with meter.track_usage_async("search"):
                result = await do_async_search(query)
        """
        try:
            yield
        finally:
            self.record(event_name, metadata=metadata)

    # ------------------------------------------------------------------
    # Lifecycle helpers
    # ------------------------------------------------------------------

    def flush(self) -> None:
        """Manually flush pending events. Call before process exit if needed."""
        if self._client:
            self._client.flush()

    def shutdown(self) -> None:
        """Graceful shutdown — flushes then stops the background thread."""
        if self._client:
            self._client.shutdown()

    # ------------------------------------------------------------------
    # Diagnostics
    # ------------------------------------------------------------------

    def status(self) -> dict:
        """Return current meter state for debugging."""
        client = self._get_client()
        return {
            "configured": client is not None,
            "tool_slug": self._tool_slug,
            "queue_size": client.queue_size() if client else 0,
        }

    def _maybe_print_badge(self) -> None:
        """Print 'Powered by CLIMeter' to stderr if on the Free tier.

        Suppressed by setting CLIMETER_NO_BADGE=1 in the environment.
        Badge state is determined by the API response (show_badge field)
        and cached in the client — it reflects whether the developer has
        crossed the $1,000 lifetime earnings threshold.
        """
        if os.environ.get("CLIMETER_NO_BADGE", "").lower() in ("1", "true", "yes"):
            return
        client = self._get_client()
        if client is None:
            return
        # show_badge is None until first batch response — don't show until known
        if client.show_badge is True:
            print("\033[2m⚡ Powered by CLIMeter · climeter.ai\033[0m", file=sys.stderr)


def call(
    tool_id: str,
    event_name: str = "call",
    metadata: Optional[Dict[str, Any]] = None,
    api_key: Optional[str] = None,
    api_url: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Call a CLIMeter-powered tool as a consumer.

    Deducts from the user's wallet (or free tier). Raises InsufficientBalanceError
    if the wallet balance is too low, with a checkout_url to top up.

    Args:
        tool_id:    UUID of the CLIMeter tool to call
        event_name: Event name (default: "call")
        metadata:   Optional metadata dict
        api_key:    API key override (default: CLIMETER_API_KEY env var)
        api_url:    API URL override (default: https://api.climeter.ai)

    Returns:
        dict with keys: success, balance_remaining, calls_remaining, free_calls_remaining, cost

    Raises:
        InsufficientBalanceError: when wallet balance is insufficient

    Example::

        from climeter import call

        result = call("3fa85f64-5717-4562-b3fc-2c963f66afa6")
        print(f"Remaining balance: ${result['balance_remaining']:.4f}")
    """
    _api_key = api_key or os.environ.get("CLIMETER_API_KEY", "")
    _api_url = (api_url or os.environ.get("CLIMETER_API_URL", DEFAULT_BASE_URL)).rstrip("/")

    if not _api_key:
        raise ValueError("CLIMETER_API_KEY is not set")

    payload = json.dumps({
        "tool_id": tool_id,
        "event_name": event_name,
        "metadata": metadata or {},
    }).encode()

    fail_strict = os.environ.get("CLIMETER_FAIL_STRICT", "").lower() == "true"

    req = urllib.request.Request(
        f"{_api_url}/v1/consumer/call",
        data=payload,
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {_api_key}",
            "X-CLIMeter-SDK-Version": SDK_VERSION,
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            result = json.loads(resp.read().decode())
            _update_cache(
                result.get("balance_remaining", 0),
                result.get("calls_remaining", 0),
                result.get("free_calls_remaining", 0),
            )
            return result
    except urllib.error.HTTPError as e:
        body = json.loads(e.read().decode())
        if body.get("error") == "insufficient_balance":
            raise InsufficientBalanceError(
                message=body.get("message", "Insufficient balance"),
                checkout_url=body.get("checkout_url", "https://climeter.ai/wallet"),
                balance=body.get("balance", 0.0),
                cost=body.get("cost", 0.0),
            )
        raise
    except Exception as e:
        if fail_strict:
            raise
        print(f"[climeter] WARNING: Metering API call failed ({e}). Continuing in fail-open mode.", flush=True)
        return {
            "success": True,
            "balance_remaining": 0,
            "calls_remaining": 0,
            "free_calls_remaining": 0,
            "cost": 0,
            "_offline": True,
        }
