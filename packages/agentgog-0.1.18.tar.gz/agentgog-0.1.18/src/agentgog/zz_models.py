"""Data models for agentgog."""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional


@dataclass
class Task:
    """Represents a test task loaded from YAML."""
    id: str
    question: str
    expected: str
    validate: str  # 'exact', 'semantic', or 'numeric'
    model: Optional[str] = None
    provider: Optional[str] = None
    category: Optional[str] = None
    difficulty: Optional[str] = None
    timeout: Optional[int] = None
    metadata: dict = field(default_factory=dict)


@dataclass
class Result:
    """Represents the result of running a task."""
    task_id: str
    model: str
    provider: str
    timestamp: str
    time_sec: float
    success: bool
    mode: str = "chat"  # Mode: chat, code, agent, etc.
    correct: Optional[bool] = None
    output: Optional[str] = None
    expected: Optional[str] = None
    error: Optional[str] = None
    validation_type: Optional[str] = None
    numeric_diff: Optional[float] = None  # For numeric validation
    verification_result: Optional[str] = None  # Raw result from agata compare (e.g., 'same', 'similar', 'different')

    def to_dict(self) -> dict:
        """Convert result to dictionary for JSON serialization."""
        return {
            'task_id': self.task_id,
            'model': self.model,
            'provider': self.provider,
            'timestamp': self.timestamp,
            'time_sec': self.time_sec,
            'success': self.success,
            'mode': self.mode,
            'correct': self.correct,
            'output': self.output,
            'expected': self.expected,
            'error': self.error,
            'validation_type': self.validation_type,
            'numeric_diff': self.numeric_diff,
            'verification_result': self.verification_result,
        }
