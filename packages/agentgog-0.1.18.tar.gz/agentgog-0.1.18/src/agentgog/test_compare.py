#!/usr/bin/env python3
"""
Test script for compare command functionality
"""
import sys
import os
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from cli import extract_expected_from_yaml


def test_extract_expected_from_yaml():
    """Test YAML extraction function"""
    print("Testing extract_expected_from_yaml...")
    
    # Test 1: Simple YAML without frontmatter
    with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
        f.write("expected: This is the expected result\n")
        temp_file = f.name
    
    result = extract_expected_from_yaml(temp_file)
    assert result == "This is the expected result", f"Expected 'This is the expected result', got '{result}'"
    os.unlink(temp_file)
    print("  ✓ Test 1 passed: Simple YAML extraction")
    
    # Test 2: YAML with frontmatter markers
    with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
        f.write("---\n")
        f.write("expected: Expected with frontmatter\n")
        f.write("---\n")
        f.write("Some other content\n")
        temp_file = f.name
    
    result = extract_expected_from_yaml(temp_file)
    assert result == "Expected with frontmatter", f"Expected 'Expected with frontmatter', got '{result}'"
    os.unlink(temp_file)
    print("  ✓ Test 2 passed: YAML with frontmatter markers")
    
    # Test 3: YAML without expected key
    with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
        f.write("other_key: Some value\n")
        temp_file = f.name
    
    result = extract_expected_from_yaml(temp_file)
    assert result is None, f"Expected None, got '{result}'"
    os.unlink(temp_file)
    print("  ✓ Test 3 passed: YAML without expected key returns None")
    
    # Test 4: Multiline expected value
    with tempfile.NamedTemporaryFile(mode='w', suffix='.yaml', delete=False) as f:
        f.write("expected: |\n")
        f.write("  Line 1\n")
        f.write("  Line 2\n")
        f.write("  Line 3\n")
        temp_file = f.name
    
    result = extract_expected_from_yaml(temp_file)
    assert "Line 1" in result, f"Expected multiline content, got '{result}'"
    os.unlink(temp_file)
    print("  ✓ Test 4 passed: Multiline expected value")
    
    print("\nAll tests passed!")


if __name__ == "__main__":
    test_extract_expected_from_yaml()
