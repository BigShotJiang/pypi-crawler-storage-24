#!/usr/bin/env python3
"""Unit tests for comparison_spectrum module."""

import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from comparison_spectrum import (
    SPECTRUM,
    PASS_RESULTS,
    TECHNICAL_FAILURE,
    is_valid_result,
    is_passing_result,
    normalize_result,
    get_all_valid_results,
)


def test_spectrum_constants():
    """Test that spectrum constants are defined correctly."""
    print("Testing spectrum constants...")
    
    assert SPECTRUM == ["same", "similar", "differ"], f"Unexpected SPECTRUM: {SPECTRUM}"
    print("  ✓ SPECTRUM is correct")
    
    assert PASS_RESULTS == ["same", "similar"], f"Unexpected PASS_RESULTS: {PASS_RESULTS}"
    print("  ✓ PASS_RESULTS is correct")
    
    assert TECHNICAL_FAILURE == "none", f"Unexpected TECHNICAL_FAILURE: {TECHNICAL_FAILURE}"
    print("  ✓ TECHNICAL_FAILURE is correct")
    
    all_results = get_all_valid_results()
    assert all_results == ["same", "similar", "differ", "none"], f"Unexpected all results: {all_results}"
    print("  ✓ get_all_valid_results() is correct")
    
    print()


def test_is_valid_result():
    """Test is_valid_result function."""
    print("Testing is_valid_result...")
    
    # Valid results
    assert is_valid_result("same") is True, "same should be valid"
    assert is_valid_result("similar") is True, "similar should be valid"
    assert is_valid_result("differ") is True, "differ should be valid"
    print("  ✓ Valid results recognized")
    
    # Case insensitive
    assert is_valid_result("SAME") is True, "SAME should be valid"
    assert is_valid_result("Similar") is True, "Similar should be valid"
    print("  ✓ Case insensitive matching works")
    
    # Invalid results
    assert is_valid_result("none") is False, "none should not be valid (it's technical failure)"
    assert is_valid_result("invalid") is False, "invalid should not be valid"
    assert is_valid_result("") is False, "empty string should not be valid"
    assert is_valid_result(None) is False, "None should not be valid"
    print("  ✓ Invalid results rejected")
    
    print()


def test_is_passing_result():
    """Test is_passing_result function."""
    print("Testing is_passing_result...")
    
    # Passing results
    assert is_passing_result("same") is True, "same should be passing"
    assert is_passing_result("similar") is True, "similar should be passing"
    print("  ✓ Passing results recognized")
    
    # Case insensitive
    assert is_passing_result("SAME") is True, "SAME should be passing"
    assert is_passing_result("Similar") is True, "Similar should be passing"
    print("  ✓ Case insensitive matching works")
    
    # Failing results
    assert is_passing_result("differ") is False, "differ should not be passing"
    assert is_passing_result("none") is False, "none should not be passing"
    assert is_passing_result("invalid") is False, "invalid should not be passing"
    assert is_passing_result("") is False, "empty string should not be passing"
    assert is_passing_result(None) is False, "None should not be passing"
    print("  ✓ Failing results rejected")
    
    print()


def test_normalize_result():
    """Test normalize_result function."""
    print("Testing normalize_result...")
    
    # Valid results (normalized to lowercase)
    assert normalize_result("same") == "same", "same should normalize to same"
    assert normalize_result("SAME") == "same", "SAME should normalize to same"
    assert normalize_result("Same") == "same", "Same should normalize to same"
    assert normalize_result("  same  ") == "same", "padded same should normalize to same"
    print("  ✓ Valid results normalized correctly")
    
    assert normalize_result("similar") == "similar", "similar should normalize to similar"
    assert normalize_result("SIMILAR") == "similar", "SIMILAR should normalize to similar"
    print("  ✓ Similar results normalized correctly")
    
    assert normalize_result("differ") == "differ", "differ should normalize to differ"
    assert normalize_result("DIFFER") == "differ", "DIFFER should normalize to differ"
    print("  ✓ Differ results normalized correctly")
    
    # Technical failure preserved
    assert normalize_result("none") == "none", "none should be preserved"
    assert normalize_result("NONE") == "none", "NONE should normalize to none"
    assert normalize_result("None") == "none", "None should normalize to none"
    print("  ✓ Technical failure (none) preserved")
    
    # Invalid results default to differ
    assert normalize_result("invalid") == "differ", "invalid should default to differ"
    assert normalize_result("yes") == "differ", "yes should default to differ"
    assert normalize_result("true") == "differ", "true should default to differ"
    assert normalize_result("") == "differ", "empty string should default to differ"
    assert normalize_result(None) == "differ", "None should default to differ"
    print("  ✓ Invalid results default to differ")
    
    # Extraction from string
    assert normalize_result("The result is same") == "same", "Should extract same from string"
    assert normalize_result("Output: similar") == "similar", "Should extract similar from string"
    print("  ✓ Extraction from strings works")
    
    print()


def run_all_tests():
    """Run all tests."""
    print("=" * 50)
    print("Running comparison_spectrum tests")
    print("=" * 50)
    print()
    
    test_spectrum_constants()
    test_is_valid_result()
    test_is_passing_result()
    test_normalize_result()
    
    print("=" * 50)
    print("All tests passed!")
    print("=" * 50)


if __name__ == "__main__":
    run_all_tests()
