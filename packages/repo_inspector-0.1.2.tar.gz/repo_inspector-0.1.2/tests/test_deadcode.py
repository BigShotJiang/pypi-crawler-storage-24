from __future__ import annotations

import ast
import textwrap
from pathlib import Path

import pytest

from repo_inspector.analysis.deadcode import analyze
from repo_inspector.utils.ast_parser import FunctionInfo, ClassInfo, ModuleInfo, ProjectIndex


# ---------------------------------------------------------------------------
# Fixture helpers
# ---------------------------------------------------------------------------

def _make_index(tmp_path: Path, files: dict[str, str]) -> ProjectIndex:
    """
    Build a ProjectIndex from {module_key: source_code}.
    Files are written to tmp_path so the analyzer can re-parse them.
    """
    mod_infos: dict[str, ModuleInfo] = {}
    py_files: list[Path] = []

    for key, source in files.items():
        rel_path = Path(key.replace(".", "/") + ".py")
        abs_path = tmp_path / rel_path
        abs_path.parent.mkdir(parents=True, exist_ok=True)
        abs_path.write_text(source)

        lines = source.count("\n") + (1 if source and not source.endswith("\n") else 0)
        tree = ast.parse(source)

        functions = []
        classes = []
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                end = getattr(node, "end_lineno", node.lineno)
                functions.append(FunctionInfo(
                    name=node.name, start_line=node.lineno, end_line=end,
                    complexity=0, is_called=False,
                ))
            elif isinstance(node, ast.ClassDef):
                end = getattr(node, "end_lineno", node.lineno)
                classes.append(ClassInfo(name=node.name, start_line=node.lineno, end_line=end))

        # imports stored as raw module strings
        imports = []
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    imports.append(alias.name)
            elif isinstance(node, ast.ImportFrom) and node.module:
                imports.append(node.module)

        mod_infos[key] = ModuleInfo(
            path=abs_path, lines=lines,
            functions=functions, classes=classes, imports=imports,
        )
        py_files.append(abs_path)

    return ProjectIndex(
        root_path=tmp_path,
        python_files=py_files,
        all_files=py_files,
        total_lines=sum(m.lines for m in mod_infos.values()),
        modules=mod_infos,
    )


# ---------------------------------------------------------------------------
# Unused function detection
# ---------------------------------------------------------------------------

def test_unused_function_detected(tmp_path):
    source = textwrap.dedent("""\
        def used():
            return 1

        def unused_func():
            return 2

        result = used()
    """)
    index = _make_index(tmp_path, {"mymod": source})
    result = analyze(index)
    fn_findings = [f for f in result.findings if "unused_func" in f.message]
    assert len(fn_findings) == 1
    assert fn_findings[0].severity == "info"


def test_called_function_not_flagged(tmp_path):
    source = textwrap.dedent("""\
        def helper():
            return 42

        x = helper()
    """)
    index = _make_index(tmp_path, {"mod": source})
    result = analyze(index)
    fn_findings = [f for f in result.findings if "helper" in f.message]
    assert fn_findings == []


def test_function_called_from_another_module(tmp_path):
    files = {
        "lib": "def shared_fn():\n    pass\n",
        "app": "from lib import shared_fn\nx = shared_fn()\n",
    }
    index = _make_index(tmp_path, files)
    result = analyze(index)
    fn_findings = [f for f in result.findings if "shared_fn" in f.message]
    assert fn_findings == []


def test_dunder_methods_not_flagged(tmp_path):
    source = textwrap.dedent("""\
        class MyClass:
            def __init__(self):
                pass
            def __repr__(self):
                return "x"
    """)
    index = _make_index(tmp_path, {"mclass": source})
    result = analyze(index)
    dunder_findings = [f for f in result.findings
                       if "__init__" in f.message or "__repr__" in f.message]
    assert dunder_findings == []


def test_test_functions_not_flagged(tmp_path):
    source = textwrap.dedent("""\
        def test_something():
            assert True

        def test_another():
            assert 1 == 1
    """)
    index = _make_index(tmp_path, {"test_stuff": source})
    result = analyze(index)
    fn_findings = [f for f in result.findings if "Function" in f.message]
    assert fn_findings == []


def test_unused_function_finding_has_heuristic_note(tmp_path):
    source = "def orphan(): pass\n"
    index = _make_index(tmp_path, {"orphan_mod": source})
    result = analyze(index)
    fn_findings = [f for f in result.findings if "orphan" in f.message]
    assert len(fn_findings) == 1
    assert "heuristic detection - verify manually" in fn_findings[0].message


def test_unused_function_location_format(tmp_path):
    source = "def lone(): pass\n"
    index = _make_index(tmp_path, {"pkg.sub": source})
    result = analyze(index)
    fn_findings = [f for f in result.findings if "lone" in f.message]
    assert len(fn_findings) == 1
    loc = fn_findings[0].location
    assert loc is not None
    assert "lone" in loc
    assert ".py" in loc


# ---------------------------------------------------------------------------
# Unused class detection
# ---------------------------------------------------------------------------

def test_unused_class_detected(tmp_path):
    source = textwrap.dedent("""\
        class UsedClass:
            pass

        class DeadClass:
            pass

        x = UsedClass()
    """)
    index = _make_index(tmp_path, {"classes": source})
    result = analyze(index)
    dead_findings = [f for f in result.findings if "DeadClass" in f.message]
    assert len(dead_findings) == 1
    assert dead_findings[0].severity == "info"


def test_base_class_not_flagged(tmp_path):
    source = textwrap.dedent("""\
        class Base:
            pass

        class Child(Base):
            pass
    """)
    index = _make_index(tmp_path, {"hierarchy": source})
    result = analyze(index)
    base_findings = [f for f in result.findings if "Base" in f.message]
    assert base_findings == []


# ---------------------------------------------------------------------------
# Unreferenced file detection
# ---------------------------------------------------------------------------

def test_unreferenced_file_detected(tmp_path):
    files = {
        "app": "import utils\n",
        "utils": "def helper(): pass\n",
        "orphan": "def do_nothing(): pass\n",   # never imported
    }
    index = _make_index(tmp_path, files)
    result = analyze(index)
    file_findings = [f for f in result.findings
                     if "not imported" in f.message]
    locations = [f.location for f in file_findings]
    assert any("orphan" in str(loc) for loc in locations)


def test_imported_file_not_flagged_as_unreferenced(tmp_path):
    files = {
        "app": "import utils\n",
        "utils": "x = 1\n",
    }
    index = _make_index(tmp_path, files)
    result = analyze(index)
    file_findings = [f for f in result.findings
                     if "not imported" in f.message and "utils" in str(f.location)]
    assert file_findings == []


def test_cli_module_not_flagged_as_unreferenced(tmp_path):
    files = {
        "cli": "import utils\n",
        "utils": "x = 1\n",
    }
    index = _make_index(tmp_path, files)
    result = analyze(index)
    cli_findings = [f for f in result.findings
                    if f.location and "cli" in f.location]
    assert cli_findings == []


def test_unreferenced_file_heuristic_note(tmp_path):
    files = {
        "main": "pass\n",
        "stray": "pass\n",
    }
    index = _make_index(tmp_path, files)
    result = analyze(index)
    file_findings = [f for f in result.findings if "not imported" in f.message]
    for f in file_findings:
        assert "heuristic detection - verify manually" in f.message


# ---------------------------------------------------------------------------
# Summary fields
# ---------------------------------------------------------------------------

def test_summary_keys_present(tmp_path):
    index = _make_index(tmp_path, {"a": "def f(): pass\n"})
    result = analyze(index)
    assert "unused_functions_count" in result.summary
    assert "unreferenced_files_count" in result.summary


def test_summary_unused_functions_count(tmp_path):
    source = "def dead1(): pass\ndef dead2(): pass\n"
    index = _make_index(tmp_path, {"mods": source})
    result = analyze(index)
    assert result.summary["unused_functions_count"] == 2


def test_summary_unreferenced_files_count(tmp_path):
    files = {
        "app": "import lib\n",
        "lib": "x = 1\n",
        "stray": "y = 2\n",
    }
    index = _make_index(tmp_path, files)
    result = analyze(index)
    # "stray" is not imported and not an entry-point name → counted
    assert result.summary["unreferenced_files_count"] >= 1


def test_all_findings_severity_info(tmp_path):
    source = "def orphan(): pass\n"
    files = {"dead_mod": source, "stray": "pass\n"}
    index = _make_index(tmp_path, files)
    result = analyze(index)
    for finding in result.findings:
        assert finding.severity == "info"


def test_analyzer_name(tmp_path):
    index = ProjectIndex(
        root_path=tmp_path, python_files=[], all_files=[], total_lines=0, modules={}
    )
    result = analyze(index)
    assert result.analyzer_name == "Dead Code Analysis"


def test_empty_project(tmp_path):
    index = ProjectIndex(
        root_path=tmp_path, python_files=[], all_files=[], total_lines=0, modules={}
    )
    result = analyze(index)
    assert result.findings == []
    assert result.summary["unused_functions_count"] == 0
    assert result.summary["unreferenced_files_count"] == 0
