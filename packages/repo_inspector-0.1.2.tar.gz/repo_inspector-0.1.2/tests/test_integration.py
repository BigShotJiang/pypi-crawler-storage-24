"""
Integration tests: exercise the CLI as an end-to-end subprocess.
"""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import pytest

# Root of the installed package — used as the scan target
_PACKAGE_DIR = Path(__file__).parent.parent / "repo_inspector"


def _run(*args: str) -> subprocess.CompletedProcess:
    return subprocess.run(
        [sys.executable, "-m", "repo_inspector.cli", *args],
        capture_output=True,
        text=True,
    )


def _run_cli(*args: str) -> subprocess.CompletedProcess:
    return subprocess.run(
        ["repo-inspector", *args],
        capture_output=True,
        text=True,
    )


# ---------------------------------------------------------------------------
# repo-inspector scan
# ---------------------------------------------------------------------------

class TestScanCommand:
    def test_exit_code_zero(self):
        result = _run_cli("scan", str(_PACKAGE_DIR))
        assert result.returncode == 0, result.stderr

    def test_output_contains_health(self):
        result = _run_cli("scan", str(_PACKAGE_DIR))
        assert "Health" in result.stdout, result.stdout

    def test_output_contains_project_analysis_summary(self):
        result = _run_cli("scan", str(_PACKAGE_DIR))
        assert "Project Analysis Summary" in result.stdout

    def test_output_contains_health_score_line(self):
        result = _run_cli("scan", str(_PACKAGE_DIR))
        assert "Health Score" in result.stdout

    def test_output_contains_analyzer_table(self):
        result = _run_cli("scan", str(_PACKAGE_DIR))
        for analyzer in ("Complexity", "Coupling", "Dead Code", "Duplication"):
            assert analyzer in result.stdout, f"Missing analyzer row: {analyzer}"

    def test_full_flag_prints_individual_findings(self):
        result = _run_cli("scan", str(_PACKAGE_DIR), "--full")
        assert result.returncode == 0, result.stderr
        # --full should print individual analyzer section headers
        assert "Complexity Analysis" in result.stdout

    def test_output_json_flag(self, tmp_path):
        out_file = tmp_path / "report.json"
        result = _run_cli("scan", str(_PACKAGE_DIR), "--output", str(out_file))
        assert result.returncode == 0, result.stderr
        assert out_file.exists()
        data = json.loads(out_file.read_text())
        assert "health_score" in data
        assert "analyzers" in data
        assert set(data["analyzers"].keys()) >= {
            "complexity", "imports", "coupling", "deadcode", "similarity", "todos", "health"
        }

    def test_nonexistent_path_exits_nonzero(self):
        result = _run_cli("scan", "/nonexistent/path/xyz")
        assert result.returncode != 0


# ---------------------------------------------------------------------------
# repo-inspector complexity
# ---------------------------------------------------------------------------

class TestComplexityCommand:
    def test_exit_code_zero(self):
        result = _run_cli("complexity", str(_PACKAGE_DIR))
        assert result.returncode == 0, result.stderr

    def test_output_contains_complexity_analysis(self):
        result = _run_cli("complexity", str(_PACKAGE_DIR))
        assert "Complexity Analysis" in result.stdout


# ---------------------------------------------------------------------------
# repo-inspector imports
# ---------------------------------------------------------------------------

class TestImportsCommand:
    def test_exit_code_zero(self):
        result = _run_cli("imports", str(_PACKAGE_DIR))
        assert result.returncode == 0, result.stderr

    def test_output_contains_import_graph(self):
        result = _run_cli("imports", str(_PACKAGE_DIR))
        assert "Import" in result.stdout


# ---------------------------------------------------------------------------
# repo-inspector coupling
# ---------------------------------------------------------------------------

class TestCouplingCommand:
    def test_exit_code_zero(self):
        result = _run_cli("coupling", str(_PACKAGE_DIR))
        assert result.returncode == 0, result.stderr


# ---------------------------------------------------------------------------
# repo-inspector deadcode
# ---------------------------------------------------------------------------

class TestDeadcodeCommand:
    def test_exit_code_zero(self):
        result = _run_cli("deadcode", str(_PACKAGE_DIR))
        assert result.returncode == 0, result.stderr


# ---------------------------------------------------------------------------
# repo-inspector health
# ---------------------------------------------------------------------------

class TestHealthCommand:
    def test_exit_code_zero(self):
        result = _run_cli("health", str(_PACKAGE_DIR))
        assert result.returncode == 0, result.stderr

    def test_output_contains_health(self):
        result = _run_cli("health", str(_PACKAGE_DIR))
        assert "Health" in result.stdout


# ---------------------------------------------------------------------------
# repo-inspector duplication
# ---------------------------------------------------------------------------

class TestDuplicationCommand:
    def test_exit_code_zero(self):
        result = _run_cli("duplication", str(_PACKAGE_DIR))
        assert result.returncode == 0, result.stderr


# ---------------------------------------------------------------------------
# repo-inspector todos
# ---------------------------------------------------------------------------

class TestTodosCommand:
    def test_exit_code_zero(self):
        result = _run_cli("todos", str(_PACKAGE_DIR))
        assert result.returncode == 0, result.stderr


# ---------------------------------------------------------------------------
# repo-inspector impact
# ---------------------------------------------------------------------------

class TestImpactCommand:
    def test_exit_code_zero(self):
        target = str(_PACKAGE_DIR / "utils" / "ast_parser.py")
        result = _run_cli("impact", str(_PACKAGE_DIR), target)
        assert result.returncode == 0, result.stderr

    def test_output_contains_impact_analysis(self):
        target = str(_PACKAGE_DIR / "utils" / "ast_parser.py")
        result = _run_cli("impact", str(_PACKAGE_DIR), target)
        assert "Impact Analysis" in result.stdout


# ---------------------------------------------------------------------------
# Shared fixture smoke-tests (conftest fixtures)
# ---------------------------------------------------------------------------

class TestConftestFixtures:
    def test_make_module_info_empty(self, make_module_info):
        mi = make_module_info("mymod")
        assert mi.lines == 0
        assert mi.functions == []
        assert mi.imports == []

    def test_make_module_info_with_source(self, make_module_info):
        mi = make_module_info("mymod", source="def f(): return 1\n")
        assert mi.lines == 1
        assert len(mi.functions) == 1
        assert mi.functions[0].name == "f"

    def test_make_module_info_explicit_imports(self, make_module_info):
        mi = make_module_info("mymod", imports=["os", "sys"])
        assert mi.imports == ["os", "sys"]

    def test_make_project_index_source_style(self, make_project_index):
        idx = make_project_index({
            "app": "import utils\n",
            "utils": "def helper(): return 42\n",
        })
        assert "app" in idx.modules
        assert "utils" in idx.modules
        assert len(idx.python_files) == 2

    def test_make_project_index_import_style(self, make_project_index):
        idx = make_project_index(
            {"a": ["b", "c"], "b": [], "c": []},
            source=False,
        )
        assert idx.modules["a"].imports == ["b", "c"]
        assert idx.modules["b"].imports == []

    def test_realistic_project_index_shape(self, realistic_project_index):
        idx = realistic_project_index
        assert len(idx.python_files) == 4
        assert "app" in idx.modules
        assert "utils" in idx.modules
        assert "models" in idx.modules
        assert "tests.test_app" in idx.modules

    def test_realistic_project_index_has_functions(self, realistic_project_index):
        utils_mod = realistic_project_index.modules["utils"]
        fn_names = {f.name for f in utils_mod.functions}
        assert "helper" in fn_names
        assert "format_output" in fn_names

    def test_realistic_project_index_has_classes(self, realistic_project_index):
        models_mod = realistic_project_index.modules["models"]
        class_names = {c.name for c in models_mod.classes}
        assert "Record" in class_names
