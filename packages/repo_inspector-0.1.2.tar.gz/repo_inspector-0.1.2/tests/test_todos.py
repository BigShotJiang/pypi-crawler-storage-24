from __future__ import annotations

from pathlib import Path

import pytest

from repo_inspector.analysis.todos import analyze
from repo_inspector.utils.ast_parser import ModuleInfo, ProjectIndex


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_index(tmp_path: Path, files: dict[str, str]) -> ProjectIndex:
    mod_infos: dict[str, ModuleInfo] = {}
    py_files: list[Path] = []

    for key, source in files.items():
        rel_path = Path(key.replace(".", "/") + ".py")
        abs_path = tmp_path / rel_path
        abs_path.parent.mkdir(parents=True, exist_ok=True)
        abs_path.write_text(source)
        lines = source.count("\n") + (1 if source and not source.endswith("\n") else 0)
        mod_infos[key] = ModuleInfo(path=abs_path, lines=lines)
        py_files.append(abs_path)

    return ProjectIndex(
        root_path=tmp_path,
        python_files=py_files,
        all_files=py_files,
        total_lines=sum(m.lines for m in mod_infos.values()),
        modules=mod_infos,
    )


# ---------------------------------------------------------------------------
# Tag detection
# ---------------------------------------------------------------------------

def test_todo_detected(tmp_path):
    index = _make_index(tmp_path, {"mod": "x = 1  # TODO: fix this\n"})
    result = analyze(index)
    assert any("TODO" in f.message for f in result.findings)


def test_fixme_detected(tmp_path):
    index = _make_index(tmp_path, {"mod": "x = 1  # FIXME broken\n"})
    result = analyze(index)
    assert any("FIXME" in f.message for f in result.findings)


def test_hack_detected(tmp_path):
    index = _make_index(tmp_path, {"mod": "x = 1  # HACK workaround\n"})
    result = analyze(index)
    assert any("HACK" in f.message for f in result.findings)


def test_noqa_detected(tmp_path):
    index = _make_index(tmp_path, {"mod": "import os  # noqa\n"})
    result = analyze(index)
    assert any("NOQA" in f.message for f in result.findings)


def test_xxx_detected(tmp_path):
    index = _make_index(tmp_path, {"mod": "# XXX investigate\n"})
    result = analyze(index)
    assert any("XXX" in f.message for f in result.findings)


def test_case_insensitive_todo(tmp_path):
    index = _make_index(tmp_path, {"mod": "# todo: lower case\n"})
    result = analyze(index)
    assert any("TODO" in f.message for f in result.findings)


def test_no_tag_no_finding(tmp_path):
    index = _make_index(tmp_path, {"mod": "# just a normal comment\nx = 1\n"})
    result = analyze(index)
    assert result.findings == []


def test_multiple_tags_in_one_file(tmp_path):
    source = "# TODO first\n# FIXME second\nx = 1\n"
    index = _make_index(tmp_path, {"multi": source})
    result = analyze(index)
    assert len(result.findings) == 2


def test_tag_in_inline_comment(tmp_path):
    index = _make_index(tmp_path, {"mod": "x = expensive()  # FIXME: slow path\n"})
    result = analyze(index)
    assert len(result.findings) == 1
    assert "FIXME" in result.findings[0].message


# ---------------------------------------------------------------------------
# Location format
# ---------------------------------------------------------------------------

def test_location_includes_filename_and_line(tmp_path):
    index = _make_index(tmp_path, {"myfile": "# TODO: something\n"})
    result = analyze(index)
    assert len(result.findings) == 1
    loc = result.findings[0].location
    assert loc is not None
    assert "myfile.py" in loc
    assert ":1" in loc


def test_location_correct_line_number(tmp_path):
    source = "x = 1\ny = 2\n# TODO on line 3\nz = 3\n"
    index = _make_index(tmp_path, {"lined": source})
    result = analyze(index)
    assert len(result.findings) == 1
    assert result.findings[0].location.endswith(":3")


def test_location_across_multiple_files(tmp_path):
    files = {
        "a": "# TODO in a\n",
        "b": "# FIXME in b\n",
    }
    index = _make_index(tmp_path, files)
    result = analyze(index)
    locations = [f.location for f in result.findings]
    assert any("a.py" in str(loc) for loc in locations)
    assert any("b.py" in str(loc) for loc in locations)


# ---------------------------------------------------------------------------
# Severity
# ---------------------------------------------------------------------------

def test_all_findings_severity_info(tmp_path):
    source = "# TODO a\n# FIXME b\n# HACK c\n"
    index = _make_index(tmp_path, {"sev": source})
    result = analyze(index)
    for finding in result.findings:
        assert finding.severity == "info"


# ---------------------------------------------------------------------------
# Message content
# ---------------------------------------------------------------------------

def test_message_includes_comment_text(tmp_path):
    index = _make_index(tmp_path, {"mod": "# TODO: refactor this soon\n"})
    result = analyze(index)
    assert len(result.findings) == 1
    assert "refactor this soon" in result.findings[0].message


def test_bare_tag_no_text_still_recorded(tmp_path):
    index = _make_index(tmp_path, {"mod": "# TODO\n"})
    result = analyze(index)
    assert len(result.findings) == 1
    assert "TODO" in result.findings[0].message


# ---------------------------------------------------------------------------
# Summary
# ---------------------------------------------------------------------------

def test_summary_total_count(tmp_path):
    source = "# TODO one\n# FIXME two\n# TODO three\n"
    index = _make_index(tmp_path, {"s": source})
    result = analyze(index)
    assert result.summary["total_count"] == 3


def test_summary_per_tag_counts(tmp_path):
    source = "# TODO a\n# TODO b\n# FIXME c\n"
    index = _make_index(tmp_path, {"s": source})
    result = analyze(index)
    assert result.summary["TODO"] == 2
    assert result.summary["FIXME"] == 1


def test_summary_keys_present(tmp_path):
    index = _make_index(tmp_path, {"s": "x = 1\n"})
    result = analyze(index)
    assert "total_count" in result.summary
    for tag in ("TODO", "FIXME", "HACK", "NOQA", "XXX"):
        assert tag in result.summary


def test_summary_zero_when_no_tags(tmp_path):
    index = _make_index(tmp_path, {"clean": "x = 1\n"})
    result = analyze(index)
    assert result.summary["total_count"] == 0
    assert result.summary["TODO"] == 0


# ---------------------------------------------------------------------------
# Edge cases
# ---------------------------------------------------------------------------

def test_empty_project(tmp_path):
    index = ProjectIndex(
        root_path=tmp_path, python_files=[], all_files=[], total_lines=0, modules={}
    )
    result = analyze(index)
    assert result.findings == []
    assert result.summary["total_count"] == 0


def test_analyzer_name(tmp_path):
    index = ProjectIndex(
        root_path=tmp_path, python_files=[], all_files=[], total_lines=0, modules={}
    )
    result = analyze(index)
    assert result.analyzer_name == "TODO/FIXME Analysis"


def test_tag_not_in_code_only_in_string(tmp_path):
    # A TODO inside a string literal has no leading '#', so it is NOT matched
    index = _make_index(tmp_path, {"s": 'msg = "TODO: not a comment"\n'})
    result = analyze(index)
    # The regex only matches inside comment text (after '#'), so this should be empty
    assert result.findings == []
