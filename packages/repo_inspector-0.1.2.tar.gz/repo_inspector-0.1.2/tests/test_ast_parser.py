from pathlib import Path

from repo_inspector.utils.ast_parser import (
    AnalysisResult,
    ClassInfo,
    Finding,
    FunctionInfo,
    ModuleInfo,
    ProjectIndex,
)


def test_finding_fields():
    f = Finding(severity="warning", message="something smells", location="foo.py:10")
    assert f.severity == "warning"
    assert f.message == "something smells"
    assert f.location == "foo.py:10"


def test_finding_location_optional():
    f = Finding(severity="info", message="just noting")
    assert f.location is None


def test_function_info_fields():
    fn = FunctionInfo(name="my_func", start_line=5, end_line=20, complexity=3, is_called=True)
    assert fn.name == "my_func"
    assert fn.start_line == 5
    assert fn.end_line == 20
    assert fn.complexity == 3
    assert fn.is_called is True


def test_class_info_fields():
    cls = ClassInfo(name="MyClass", start_line=1, end_line=40)
    assert cls.name == "MyClass"
    assert cls.start_line == 1
    assert cls.end_line == 40


def test_module_info_defaults():
    mi = ModuleInfo(path=Path("foo.py"), lines=100)
    assert mi.path == Path("foo.py")
    assert mi.lines == 100
    assert mi.functions == []
    assert mi.classes == []
    assert mi.imports == []


def test_module_info_with_children():
    fn = FunctionInfo(name="f", start_line=1, end_line=5, complexity=1, is_called=False)
    cls = ClassInfo(name="C", start_line=10, end_line=20)
    mi = ModuleInfo(path=Path("bar.py"), lines=50, functions=[fn], classes=[cls], imports=["os"])
    assert len(mi.functions) == 1
    assert len(mi.classes) == 1
    assert mi.imports == ["os"]


def test_project_index_fields():
    mi = ModuleInfo(path=Path("a.py"), lines=10)
    idx = ProjectIndex(
        root_path=Path("/project"),
        python_files=[Path("a.py")],
        all_files=[Path("a.py"), Path("README.md")],
        total_lines=10,
        modules={"a": mi},
    )
    assert idx.root_path == Path("/project")
    assert len(idx.python_files) == 1
    assert len(idx.all_files) == 2
    assert idx.total_lines == 10
    assert "a" in idx.modules


def test_project_index_is_frozen():
    idx = ProjectIndex(
        root_path=Path("/project"),
        python_files=[],
        all_files=[],
        total_lines=0,
        modules={},
    )
    try:
        idx.total_lines = 99  # type: ignore[misc]
        assert False, "expected FrozenInstanceError"
    except Exception:
        pass


def test_analysis_result_defaults():
    result = AnalysisResult(analyzer_name="complexity")
    assert result.analyzer_name == "complexity"
    assert result.findings == []
    assert result.summary == {}


def test_analysis_result_with_findings():
    f = Finding(severity="critical", message="too complex", location="heavy.py:5")
    result = AnalysisResult(
        analyzer_name="complexity",
        findings=[f],
        summary={"max_complexity": 25},
    )
    assert len(result.findings) == 1
    assert result.summary["max_complexity"] == 25
