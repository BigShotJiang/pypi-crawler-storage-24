import textwrap
from pathlib import Path

import pytest

from repo_inspector.scanner.project_scanner import scan_project


@pytest.fixture()
def project_dir(tmp_path: Path) -> Path:
    """Create a small synthetic project."""
    # foo.py — one function, one class, one import
    (tmp_path / "foo.py").write_text(
        textwrap.dedent("""\
            import os

            class Foo:
                pass

            def bar():
                return 1
        """)
    )

    # subpkg/baz.py — two functions, one import-from
    subpkg = tmp_path / "subpkg"
    subpkg.mkdir()
    (subpkg / "__init__.py").write_text("")
    (subpkg / "baz.py").write_text(
        textwrap.dedent("""\
            from pathlib import Path

            def alpha():
                pass

            def beta():
                pass
        """)
    )

    # non-python file — must appear in all_files but not python_files
    (tmp_path / "README.md").write_text("# readme\n")

    return tmp_path


def test_python_files_collected(project_dir: Path):
    idx = scan_project(project_dir)
    names = {p.name for p in idx.python_files}
    assert "__init__.py" in names
    assert "foo.py" in names
    assert "baz.py" in names


def test_all_files_includes_non_python(project_dir: Path):
    idx = scan_project(project_dir)
    names = {p.name for p in idx.all_files}
    assert "README.md" in names


def test_total_lines(project_dir: Path):
    idx = scan_project(project_dir)
    # sum lines from all python files
    expected = sum(
        m.lines for m in idx.modules.values()
    )
    assert idx.total_lines == expected
    assert idx.total_lines > 0


def test_module_keys_are_dotted(project_dir: Path):
    idx = scan_project(project_dir)
    assert "foo" in idx.modules
    assert "subpkg.baz" in idx.modules
    assert "subpkg.__init__" in idx.modules


def test_functions_extracted(project_dir: Path):
    idx = scan_project(project_dir)
    foo_mod = idx.modules["foo"]
    func_names = {f.name for f in foo_mod.functions}
    assert "bar" in func_names


def test_classes_extracted(project_dir: Path):
    idx = scan_project(project_dir)
    foo_mod = idx.modules["foo"]
    class_names = {c.name for c in foo_mod.classes}
    assert "Foo" in class_names


def test_imports_extracted(project_dir: Path):
    idx = scan_project(project_dir)
    foo_mod = idx.modules["foo"]
    assert "os" in foo_mod.imports

    baz_mod = idx.modules["subpkg.baz"]
    assert "pathlib" in baz_mod.imports


def test_multiple_functions_in_submodule(project_dir: Path):
    idx = scan_project(project_dir)
    baz_mod = idx.modules["subpkg.baz"]
    func_names = {f.name for f in baz_mod.functions}
    assert "alpha" in func_names
    assert "beta" in func_names


def test_function_line_numbers(project_dir: Path):
    idx = scan_project(project_dir)
    foo_mod = idx.modules["foo"]
    bar = next(f for f in foo_mod.functions if f.name == "bar")
    assert bar.start_line > 0
    assert bar.end_line >= bar.start_line


def test_project_index_is_frozen(project_dir: Path):
    idx = scan_project(project_dir)
    with pytest.raises(Exception):
        idx.total_lines = 0  # type: ignore[misc]


def test_gitignore_exclusion(tmp_path: Path):
    """Files matched by .gitignore must not appear in the index."""
    (tmp_path / ".gitignore").write_text("secret.py\n")
    (tmp_path / "secret.py").write_text("PASSWORD = 'hunter2'\n")
    (tmp_path / "public.py").write_text("x = 1\n")

    idx = scan_project(tmp_path)

    py_names = {p.name for p in idx.python_files}
    assert "public.py" in py_names
    assert "secret.py" not in py_names


def test_always_excluded_dirs(tmp_path: Path):
    """__pycache__, .git, .venv etc. must always be excluded."""
    for excluded_dir in ("__pycache__", ".git", ".venv", "dist", "build"):
        d = tmp_path / excluded_dir
        d.mkdir()
        (d / "module.py").write_text("x = 1\n")

    (tmp_path / "real.py").write_text("y = 2\n")

    idx = scan_project(tmp_path)

    py_names = {p.name for p in idx.python_files}
    assert py_names == {"real.py"}


def test_egg_info_excluded(tmp_path: Path):
    egg = tmp_path / "mypackage.egg-info"
    egg.mkdir()
    (egg / "PKG-INFO").write_text("metadata\n")
    (egg / "top_level.txt").write_text("mypackage\n")
    (tmp_path / "real.py").write_text("pass\n")

    idx = scan_project(tmp_path)

    assert all("egg-info" not in str(p) for p in idx.all_files)


def test_empty_project(tmp_path: Path):
    idx = scan_project(tmp_path)
    assert idx.python_files == []
    assert idx.total_lines == 0
    assert idx.modules == {}


def test_syntax_error_file_still_indexed(tmp_path: Path):
    """A file with a syntax error should still appear; functions/classes default to empty."""
    (tmp_path / "broken.py").write_text("def (:\n    pass\n")

    idx = scan_project(tmp_path)

    assert "broken" in idx.modules
    broken = idx.modules["broken"]
    assert broken.functions == []
    assert broken.classes == []
