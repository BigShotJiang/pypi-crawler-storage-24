from __future__ import annotations

from pathlib import Path

import pytest

from repo_inspector.analysis.imports import analyze
from repo_inspector.utils.ast_parser import ModuleInfo, ProjectIndex
from repo_inspector.utils.graph_builder import build_import_graph


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_index(tmp_path: Path, modules: dict[str, list[str]]) -> ProjectIndex:
    """
    Build a minimal ProjectIndex from {module_key: [import_keys]} without real
    file content.  We write empty stub files so Path objects are valid.
    """
    mod_infos: dict[str, ModuleInfo] = {}
    py_files: list[Path] = []

    for key, imports in modules.items():
        # Turn dotted key back into a relative path
        rel_path = Path(key.replace(".", "/") + ".py")
        abs_path = tmp_path / rel_path
        abs_path.parent.mkdir(parents=True, exist_ok=True)
        abs_path.write_text("")
        mod_infos[key] = ModuleInfo(path=abs_path, lines=1, imports=imports)
        py_files.append(abs_path)

    return ProjectIndex(
        root_path=tmp_path,
        python_files=py_files,
        all_files=py_files,
        total_lines=len(modules),
        modules=mod_infos,
    )


# ---------------------------------------------------------------------------
# graph_builder tests
# ---------------------------------------------------------------------------

def test_nodes_created_for_all_modules(tmp_path):
    index = _make_index(tmp_path, {"a": [], "b": [], "c": []})
    g = build_import_graph(index)
    assert set(g.nodes) == {"a", "b", "c"}


def test_edge_added_for_known_import(tmp_path):
    index = _make_index(tmp_path, {"a": ["b"], "b": []})
    g = build_import_graph(index)
    assert g.has_edge("a", "b")


def test_no_edge_for_external_import(tmp_path):
    index = _make_index(tmp_path, {"a": ["os", "sys"], "b": []})
    g = build_import_graph(index)
    assert g.number_of_edges() == 0


def test_no_self_loop(tmp_path):
    # A module listing itself as an import should not create a self-loop
    index = _make_index(tmp_path, {"a": ["a"]})
    g = build_import_graph(index)
    assert not g.has_edge("a", "a")


def test_multiple_edges(tmp_path):
    index = _make_index(tmp_path, {
        "app": ["models", "utils"],
        "models": ["utils"],
        "utils": [],
    })
    g = build_import_graph(index)
    assert g.has_edge("app", "models")
    assert g.has_edge("app", "utils")
    assert g.has_edge("models", "utils")
    assert g.number_of_edges() == 3


def test_prefix_resolution(tmp_path):
    """An import of 'pkg.sub' should resolve to module key 'pkg.sub' if it exists."""
    index = _make_index(tmp_path, {"a": ["pkg.sub"], "pkg.sub": []})
    g = build_import_graph(index)
    assert g.has_edge("a", "pkg.sub")


# ---------------------------------------------------------------------------
# analyze() — cycle detection
# ---------------------------------------------------------------------------

def test_no_cycles_clean_graph(tmp_path):
    index = _make_index(tmp_path, {"a": ["b"], "b": ["c"], "c": []})
    result = analyze(index)
    assert result.summary["circular_cycles_found"] == 0
    cycle_findings = [f for f in result.findings if f.severity == "critical"]
    assert cycle_findings == []


def test_simple_two_node_cycle(tmp_path):
    index = _make_index(tmp_path, {"a": ["b"], "b": ["a"]})
    result = analyze(index)
    assert result.summary["circular_cycles_found"] >= 1
    cycle_findings = [f for f in result.findings if f.severity == "critical"]
    assert len(cycle_findings) >= 1


def test_three_node_cycle(tmp_path):
    index = _make_index(tmp_path, {
        "x": ["y"],
        "y": ["z"],
        "z": ["x"],
    })
    result = analyze(index)
    assert result.summary["circular_cycles_found"] >= 1
    assert any("x" in f.message and "y" in f.message for f in result.findings)


def test_cycle_finding_severity_is_critical(tmp_path):
    index = _make_index(tmp_path, {"a": ["b"], "b": ["a"]})
    result = analyze(index)
    for finding in result.findings:
        assert finding.severity == "critical"


def test_cycle_finding_message_contains_arrow(tmp_path):
    index = _make_index(tmp_path, {"a": ["b"], "b": ["a"]})
    result = analyze(index)
    assert any("→" in f.message for f in result.findings)


def test_multiple_independent_cycles(tmp_path):
    """Two separate cycles should each produce a finding."""
    index = _make_index(tmp_path, {
        "a": ["b"], "b": ["a"],   # cycle 1
        "c": ["d"], "d": ["c"],   # cycle 2
    })
    result = analyze(index)
    assert result.summary["circular_cycles_found"] >= 2


def test_diamond_no_cycle(tmp_path):
    """A → B, A → C, B → D, C → D is not a cycle."""
    index = _make_index(tmp_path, {
        "a": ["b", "c"],
        "b": ["d"],
        "c": ["d"],
        "d": [],
    })
    result = analyze(index)
    assert result.summary["circular_cycles_found"] == 0


# ---------------------------------------------------------------------------
# analyze() — summary fields
# ---------------------------------------------------------------------------

def test_summary_keys_present(tmp_path):
    index = _make_index(tmp_path, {"a": ["b"], "b": []})
    result = analyze(index)
    for key in ("total_modules", "total_edges", "circular_cycles_found"):
        assert key in result.summary


def test_summary_total_edges(tmp_path):
    index = _make_index(tmp_path, {"a": ["b"], "b": ["c"], "c": []})
    result = analyze(index)
    assert result.summary["total_edges"] == 2


def test_summary_total_modules(tmp_path):
    index = _make_index(tmp_path, {"a": [], "b": [], "c": []})
    result = analyze(index)
    assert result.summary["total_modules"] == 3


def test_analyzer_name(tmp_path):
    index = _make_index(tmp_path, {})
    result = analyze(index)
    assert result.analyzer_name == "Import Analysis"


def test_empty_project(tmp_path):
    index = ProjectIndex(
        root_path=tmp_path, python_files=[], all_files=[], total_lines=0, modules={}
    )
    result = analyze(index)
    assert result.summary["circular_cycles_found"] == 0
    assert result.summary["total_edges"] == 0
    assert result.findings == []
