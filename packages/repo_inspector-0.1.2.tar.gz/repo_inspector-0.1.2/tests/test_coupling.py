from __future__ import annotations

from pathlib import Path

import pytest

from repo_inspector.analysis.coupling import analyze
from repo_inspector.utils.ast_parser import ModuleInfo, ProjectIndex


def _make_index(tmp_path: Path, modules: dict[str, list[str]]) -> ProjectIndex:
    """Build a ProjectIndex from {module_key: [imported_module_keys]}."""
    mod_infos: dict[str, ModuleInfo] = {}
    py_files: list[Path] = []

    for key, imports in modules.items():
        rel_path = Path(key.replace(".", "/") + ".py")
        abs_path = tmp_path / rel_path
        abs_path.parent.mkdir(parents=True, exist_ok=True)
        abs_path.write_text("")
        mod_infos[key] = ModuleInfo(path=abs_path, lines=1, imports=imports)
        py_files.append(abs_path)

    return ProjectIndex(
        root_path=tmp_path,
        python_files=py_files,
        all_files=py_files,
        total_lines=len(modules),
        modules=mod_infos,
    )


# ---------------------------------------------------------------------------
# Basic score calculations
# ---------------------------------------------------------------------------

def test_isolated_module_score_zero(tmp_path):
    index = _make_index(tmp_path, {"a": [], "b": []})
    result = analyze(index)
    # No edges → no findings
    assert result.findings == []


def test_fan_out_counts_correctly(tmp_path):
    # "hub" imports 3 others → fan_out=3, fan_in=0, score=3
    index = _make_index(tmp_path, {
        "hub": ["x", "y", "z"],
        "x": [], "y": [], "z": [],
    })
    result = analyze(index)
    # score=3 is below warning threshold; no findings expected
    assert result.findings == []
    assert result.summary["most_coupled_module"] == "hub"


def test_fan_in_counts_correctly(tmp_path):
    # "shared" is imported by 3 modules → fan_in=3, fan_out=0, score=3
    index = _make_index(tmp_path, {
        "a": ["shared"], "b": ["shared"], "c": ["shared"],
        "shared": [],
    })
    result = analyze(index)
    assert result.summary["most_coupled_module"] == "shared"


def test_combined_fan_in_and_out(tmp_path):
    # "mid" imports 2 and is imported by 2 → score=4
    index = _make_index(tmp_path, {
        "a": ["mid"], "b": ["mid"],
        "mid": ["x", "y"],
        "x": [], "y": [],
    })
    result = analyze(index)
    assert result.summary["most_coupled_module"] == "mid"
    assert result.summary["avg_coupling_score"] > 0


# ---------------------------------------------------------------------------
# Warning / critical thresholds
# ---------------------------------------------------------------------------

def _make_high_coupling_index(tmp_path: Path, n_importers: int, n_imports: int) -> ProjectIndex:
    """Hub imports n_imports modules and is imported by n_importers modules."""
    mods: dict[str, list[str]] = {}
    imported = [f"dep_{i}" for i in range(n_imports)]
    importers = [f"user_{i}" for i in range(n_importers)]
    mods["hub"] = imported
    for m in imported:
        mods[m] = []
    for m in importers:
        mods[m] = ["hub"]
    return _make_index(tmp_path, mods)


def test_warning_threshold(tmp_path):
    # fan_in=5 + fan_out=5 = 10 → warning
    index = _make_high_coupling_index(tmp_path, n_importers=5, n_imports=5)
    result = analyze(index)
    hub_findings = [f for f in result.findings if f.location == "hub"]
    assert len(hub_findings) == 1
    assert hub_findings[0].severity == "warning"


def test_critical_threshold(tmp_path):
    # fan_in=10 + fan_out=10 = 20 → critical
    index = _make_high_coupling_index(tmp_path, n_importers=10, n_imports=10)
    result = analyze(index)
    hub_findings = [f for f in result.findings if f.location == "hub"]
    assert len(hub_findings) == 1
    assert hub_findings[0].severity == "critical"


def test_below_warning_no_finding(tmp_path):
    # score=9 → no finding
    index = _make_high_coupling_index(tmp_path, n_importers=5, n_imports=4)
    result = analyze(index)
    hub_findings = [f for f in result.findings if f.location == "hub"]
    assert hub_findings == []


def test_finding_message_contains_fan_info(tmp_path):
    index = _make_high_coupling_index(tmp_path, n_importers=5, n_imports=5)
    result = analyze(index)
    hub_finding = next(f for f in result.findings if f.location == "hub")
    assert "fan-in" in hub_finding.message
    assert "fan-out" in hub_finding.message


def test_finding_location_is_module_key(tmp_path):
    index = _make_high_coupling_index(tmp_path, n_importers=5, n_imports=5)
    result = analyze(index)
    assert any(f.location == "hub" for f in result.findings)


# ---------------------------------------------------------------------------
# Summary fields
# ---------------------------------------------------------------------------

def test_summary_keys_present(tmp_path):
    index = _make_index(tmp_path, {"a": ["b"], "b": []})
    result = analyze(index)
    for key in ("most_coupled_module", "avg_coupling_score", "modules_above_warning"):
        assert key in result.summary


def test_modules_above_warning_count(tmp_path):
    # Two hubs each at score=10
    mods: dict[str, list[str]] = {}
    for hub in ("hub1", "hub2"):
        deps = [f"{hub}_dep_{i}" for i in range(5)]
        users = [f"{hub}_user_{i}" for i in range(5)]
        mods[hub] = deps
        for m in deps:
            mods[m] = []
        for m in users:
            mods[m] = [hub]
    index = _make_index(tmp_path, mods)
    result = analyze(index)
    assert result.summary["modules_above_warning"] >= 2


def test_avg_coupling_score_computed(tmp_path):
    # 2 modules, one edge: scores are [1, 1] → avg=1.0
    index = _make_index(tmp_path, {"a": ["b"], "b": []})
    result = analyze(index)
    assert result.summary["avg_coupling_score"] == 1.0


def test_most_coupled_module_is_highest_score(tmp_path):
    index = _make_index(tmp_path, {
        "a": ["shared"], "b": ["shared"], "c": ["shared"],
        "shared": ["ext"],
        "ext": [],
    })
    result = analyze(index)
    # shared: fan_in=3 fan_out=1 → score=4; all others lower
    assert result.summary["most_coupled_module"] == "shared"


def test_analyzer_name(tmp_path):
    index = ProjectIndex(
        root_path=tmp_path, python_files=[], all_files=[], total_lines=0, modules={}
    )
    result = analyze(index)
    assert result.analyzer_name == "Coupling Analysis"


def test_empty_project(tmp_path):
    index = ProjectIndex(
        root_path=tmp_path, python_files=[], all_files=[], total_lines=0, modules={}
    )
    result = analyze(index)
    assert result.findings == []
    assert result.summary["avg_coupling_score"] == 0
    assert result.summary["modules_above_warning"] == 0
