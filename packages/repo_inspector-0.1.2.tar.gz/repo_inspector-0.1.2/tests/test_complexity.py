import textwrap
from pathlib import Path

import pytest

from repo_inspector.analysis.complexity import analyze
from repo_inspector.utils.ast_parser import FunctionInfo, ModuleInfo, ProjectIndex


def _make_index(tmp_path: Path, files: dict[str, str]) -> ProjectIndex:
    """
    Build a ProjectIndex from a dict of {relative_name: source_code}.
    Files are written to tmp_path so radon can read them.
    """
    python_files = []
    modules = {}
    total_lines = 0

    for rel_name, source in files.items():
        file_path = tmp_path / rel_name
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_text(source)

        lines = source.count("\n") + (1 if source and not source.endswith("\n") else 0)
        total_lines += lines

        import ast as _ast
        tree = _ast.parse(source)
        functions = []
        for node in _ast.walk(tree):
            if isinstance(node, (_ast.FunctionDef, _ast.AsyncFunctionDef)):
                end = getattr(node, "end_lineno", node.lineno)
                functions.append(FunctionInfo(
                    name=node.name,
                    start_line=node.lineno,
                    end_line=end,
                    complexity=0,
                    is_called=False,
                ))

        module_key = rel_name.replace("/", ".").removesuffix(".py")
        modules[module_key] = ModuleInfo(path=file_path, lines=lines, functions=functions)
        python_files.append(file_path)

    return ProjectIndex(
        root_path=tmp_path,
        python_files=python_files,
        all_files=python_files,
        total_lines=total_lines,
        modules=modules,
    )


# ---------------------------------------------------------------------------
# Cyclomatic complexity findings
# ---------------------------------------------------------------------------

def test_simple_function_no_findings(tmp_path):
    source = textwrap.dedent("""\
        def hello():
            return 1
    """)
    index = _make_index(tmp_path, {"simple.py": source})
    result = analyze(index)
    cc_findings = [f for f in result.findings if "complexity" in f.message.lower()]
    assert cc_findings == []


def test_complex_function_warning(tmp_path):
    # Build a function with many branches to push CC >= 10
    branches = "\n".join(f"    if x == {i}: pass" for i in range(10))
    source = f"def branchy(x):\n{branches}\n"
    index = _make_index(tmp_path, {"branchy.py": source})
    result = analyze(index)
    cc_findings = [f for f in result.findings if "complexity" in f.message.lower()]
    assert len(cc_findings) >= 1
    severities = {f.severity for f in cc_findings}
    assert "warning" in severities or "critical" in severities


def test_critical_complexity_finding(tmp_path):
    # 20 branches → CC >= 21 → critical
    branches = "\n".join(f"    if x == {i}: pass" for i in range(21))
    source = f"def huge(x):\n{branches}\n"
    index = _make_index(tmp_path, {"huge.py": source})
    result = analyze(index)
    cc_findings = [f for f in result.findings
                   if "complexity" in f.message.lower() and f.severity == "critical"]
    assert len(cc_findings) >= 1


def test_finding_location_format(tmp_path):
    branches = "\n".join(f"    if x == {i}: pass" for i in range(10))
    source = f"def branchy(x):\n{branches}\n"
    index = _make_index(tmp_path, {"loc_test.py": source})
    result = analyze(index)
    cc_findings = [f for f in result.findings if "complexity" in f.message.lower()]
    assert len(cc_findings) >= 1
    loc = cc_findings[0].location
    assert loc is not None
    assert "loc_test.py" in loc
    assert "branchy" in loc


# ---------------------------------------------------------------------------
# Function size findings
# ---------------------------------------------------------------------------

def test_long_function_warning(tmp_path):
    # 55 lines → warning
    body = "\n".join(f"    x{i} = {i}" for i in range(54))
    source = f"def long_func():\n{body}\n"
    index = _make_index(tmp_path, {"long.py": source})
    result = analyze(index)
    size_findings = [f for f in result.findings if "lines long" in f.message]
    assert len(size_findings) >= 1
    assert any(f.severity == "warning" for f in size_findings)


def test_long_function_critical(tmp_path):
    # 85 lines → critical
    body = "\n".join(f"    x{i} = {i}" for i in range(84))
    source = f"def very_long():\n{body}\n"
    index = _make_index(tmp_path, {"verylong.py": source})
    result = analyze(index)
    size_findings = [f for f in result.findings if "lines long" in f.message]
    assert any(f.severity == "critical" for f in size_findings)


def test_short_function_no_size_finding(tmp_path):
    source = textwrap.dedent("""\
        def tiny():
            a = 1
            b = 2
            return a + b
    """)
    index = _make_index(tmp_path, {"tiny.py": source})
    result = analyze(index)
    size_findings = [f for f in result.findings if "lines long" in f.message]
    assert size_findings == []


# ---------------------------------------------------------------------------
# God Object (file size) findings
# ---------------------------------------------------------------------------

def test_god_object_warning(tmp_path):
    # 500 lines
    lines = ["x = 1"] * 500
    source = "\n".join(lines) + "\n"
    index = _make_index(tmp_path, {"big.py": source})
    result = analyze(index)
    god_findings = [f for f in result.findings if "lines" in f.message and "File" in f.message]
    assert len(god_findings) >= 1
    assert any(f.severity == "warning" for f in god_findings)


def test_god_object_critical(tmp_path):
    lines = ["x = 1"] * 1000
    source = "\n".join(lines) + "\n"
    index = _make_index(tmp_path, {"giant.py": source})
    result = analyze(index)
    god_findings = [f for f in result.findings if "lines" in f.message and "File" in f.message]
    assert any(f.severity == "critical" for f in god_findings)


def test_small_file_no_god_object(tmp_path):
    source = "x = 1\n"
    index = _make_index(tmp_path, {"small.py": source})
    result = analyze(index)
    god_findings = [f for f in result.findings if "God Object" in f.message or "large file" in f.message]
    assert god_findings == []


# ---------------------------------------------------------------------------
# Summary dict
# ---------------------------------------------------------------------------

def test_summary_keys_present(tmp_path):
    source = "def f(): return 1\n"
    index = _make_index(tmp_path, {"s.py": source})
    result = analyze(index)
    for key in ("max_complexity", "avg_complexity", "functions_above_warning", "functions_above_critical"):
        assert key in result.summary


def test_summary_values_empty_project(tmp_path):
    index = ProjectIndex(
        root_path=tmp_path,
        python_files=[],
        all_files=[],
        total_lines=0,
        modules={},
    )
    result = analyze(index)
    assert result.summary["max_complexity"] == 0
    assert result.summary["avg_complexity"] == 0
    assert result.summary["functions_above_warning"] == 0
    assert result.summary["functions_above_critical"] == 0


def test_summary_counts_above_thresholds(tmp_path):
    # One function with CC >= 10 and one clean
    branches = "\n".join(f"    if x == {i}: pass" for i in range(10))
    source = f"def branchy(x):\n{branches}\ndef clean(): pass\n"
    index = _make_index(tmp_path, {"mixed.py": source})
    result = analyze(index)
    assert result.summary["functions_above_warning"] >= 1
    assert result.summary["max_complexity"] >= 10


def test_analyzer_name(tmp_path):
    index = ProjectIndex(
        root_path=tmp_path, python_files=[], all_files=[], total_lines=0, modules={}
    )
    result = analyze(index)
    assert result.analyzer_name == "Complexity Analysis"


# ---------------------------------------------------------------------------
# Multiple files
# ---------------------------------------------------------------------------

def test_multiple_files(tmp_path):
    files = {
        "a.py": "def fa(): return 1\n",
        "b.py": "def fb(): return 2\n",
    }
    index = _make_index(tmp_path, files)
    result = analyze(index)
    # Two functions total → avg_complexity should be numeric
    assert isinstance(result.summary["avg_complexity"], (int, float))
