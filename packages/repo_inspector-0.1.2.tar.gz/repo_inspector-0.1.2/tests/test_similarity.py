from __future__ import annotations

import textwrap
from pathlib import Path

import pytest

from repo_inspector.analysis.similarity import analyze
from repo_inspector.utils.ast_parser import ModuleInfo, ProjectIndex


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_index(tmp_path: Path, files: dict[str, str]) -> ProjectIndex:
    mod_infos: dict[str, ModuleInfo] = {}
    py_files: list[Path] = []

    for key, source in files.items():
        rel_path = Path(key.replace(".", "/") + ".py")
        abs_path = tmp_path / rel_path
        abs_path.parent.mkdir(parents=True, exist_ok=True)
        abs_path.write_text(source)
        lines = source.count("\n") + (1 if source and not source.endswith("\n") else 0)
        mod_infos[key] = ModuleInfo(path=abs_path, lines=lines)
        py_files.append(abs_path)

    return ProjectIndex(
        root_path=tmp_path,
        python_files=py_files,
        all_files=py_files,
        total_lines=sum(m.lines for m in mod_infos.values()),
        modules=mod_infos,
    )


# ---------------------------------------------------------------------------
# Core duplicate detection
# ---------------------------------------------------------------------------

def test_identical_functions_different_names_detected(tmp_path):
    source = textwrap.dedent("""\
        def alpha(x, y):
            result = x + y
            return result

        def beta(a, b):
            result = a + b
            return result
    """)
    index = _make_index(tmp_path, {"mod": source})
    result = analyze(index)
    assert result.summary["duplicate_groups_found"] == 1
    assert result.summary["total_duplicate_functions"] == 2


def test_identical_functions_across_files(tmp_path):
    body = textwrap.dedent("""\
        def compute(x, y):
            total = x + y
            return total
    """)
    index = _make_index(tmp_path, {"file_a": body, "file_b": body})
    result = analyze(index)
    assert result.summary["duplicate_groups_found"] == 1
    assert result.summary["total_duplicate_functions"] == 2


def test_unique_functions_no_findings(tmp_path):
    source = textwrap.dedent("""\
        def add(a, b):
            return a + b

        def multiply(a, b):
            return a * b
    """)
    index = _make_index(tmp_path, {"mod": source})
    result = analyze(index)
    assert result.summary["duplicate_groups_found"] == 0
    assert result.findings == []


def test_three_way_duplicate(tmp_path):
    body = "    x = val + 1\n    return x\n"
    source = (
        f"def f1(val):\n{body}"
        f"def f2(val):\n{body}"
        f"def f3(val):\n{body}"
    )
    index = _make_index(tmp_path, {"mod": source})
    result = analyze(index)
    assert result.summary["duplicate_groups_found"] == 1
    assert result.summary["total_duplicate_functions"] == 3


def test_two_separate_duplicate_groups(tmp_path):
    source = textwrap.dedent("""\
        def a1(x):
            y = x * 2
            return y

        def a2(n):
            y = n * 2
            return y

        def b1(s):
            out = s + "!"
            return out

        def b2(t):
            out = t + "!"
            return out
    """)
    index = _make_index(tmp_path, {"mod": source})
    result = analyze(index)
    assert result.summary["duplicate_groups_found"] == 2
    assert result.summary["total_duplicate_functions"] == 4


# ---------------------------------------------------------------------------
# Normalisation correctness
# ---------------------------------------------------------------------------

def test_different_variable_names_still_match(tmp_path):
    """Renaming local variables must not break the match."""
    source = textwrap.dedent("""\
        def version1(input_val):
            intermediate = input_val + 10
            return intermediate

        def version2(data):
            result = data + 10
            return result
    """)
    index = _make_index(tmp_path, {"mod": source})
    result = analyze(index)
    assert result.summary["duplicate_groups_found"] == 1


def test_different_constants_do_not_match(tmp_path):
    """Constants are normalised too, so different literal values still match."""
    source = textwrap.dedent("""\
        def f1(x):
            return x + 1

        def f2(x):
            return x + 99
    """)
    index = _make_index(tmp_path, {"mod": source})
    result = analyze(index)
    # Both constants are normalised to the same placeholder → still a duplicate
    assert result.summary["duplicate_groups_found"] == 1


def test_structurally_different_bodies_no_match(tmp_path):
    source = textwrap.dedent("""\
        def f1(x):
            return x + 1

        def f2(x):
            if x:
                return x
            return 0
    """)
    index = _make_index(tmp_path, {"mod": source})
    result = analyze(index)
    assert result.summary["duplicate_groups_found"] == 0


# ---------------------------------------------------------------------------
# Trivial body filtering
# ---------------------------------------------------------------------------

def test_pass_only_functions_not_flagged(tmp_path):
    source = textwrap.dedent("""\
        def stub1():
            pass

        def stub2():
            pass
    """)
    index = _make_index(tmp_path, {"mod": source})
    result = analyze(index)
    assert result.summary["duplicate_groups_found"] == 0


def test_docstring_only_functions_not_flagged(tmp_path):
    source = textwrap.dedent('''\
        def doc1():
            """Does something."""

        def doc2():
            """Does something."""
    ''')
    index = _make_index(tmp_path, {"mod": source})
    result = analyze(index)
    assert result.summary["duplicate_groups_found"] == 0


# ---------------------------------------------------------------------------
# Finding format
# ---------------------------------------------------------------------------

def test_finding_severity_is_warning(tmp_path):
    source = textwrap.dedent("""\
        def dup1(x):
            return x + 1

        def dup2(y):
            return y + 1
    """)
    index = _make_index(tmp_path, {"mod": source})
    result = analyze(index)
    assert len(result.findings) == 1
    assert result.findings[0].severity == "warning"


def test_finding_message_lists_both_locations(tmp_path):
    source = textwrap.dedent("""\
        def dup1(x):
            return x + 1

        def dup2(y):
            return y + 1
    """)
    index = _make_index(tmp_path, {"mod": source})
    result = analyze(index)
    assert len(result.findings) == 1
    msg = result.findings[0].message
    assert "dup1" in msg
    assert "dup2" in msg


def test_finding_message_contains_file_path(tmp_path):
    source = textwrap.dedent("""\
        def dup1(x):
            return x + 1

        def dup2(y):
            return y + 1
    """)
    index = _make_index(tmp_path, {"mymodule": source})
    result = analyze(index)
    assert "mymodule.py" in result.findings[0].message


# ---------------------------------------------------------------------------
# Summary and metadata
# ---------------------------------------------------------------------------

def test_summary_keys_present(tmp_path):
    index = _make_index(tmp_path, {"s": "def f(): return 1\n"})
    result = analyze(index)
    assert "duplicate_groups_found" in result.summary
    assert "total_duplicate_functions" in result.summary


def test_analyzer_name(tmp_path):
    index = ProjectIndex(
        root_path=tmp_path, python_files=[], all_files=[], total_lines=0, modules={}
    )
    result = analyze(index)
    assert result.analyzer_name == "Duplication Analysis"


def test_empty_project(tmp_path):
    index = ProjectIndex(
        root_path=tmp_path, python_files=[], all_files=[], total_lines=0, modules={}
    )
    result = analyze(index)
    assert result.findings == []
    assert result.summary["duplicate_groups_found"] == 0
    assert result.summary["total_duplicate_functions"] == 0
