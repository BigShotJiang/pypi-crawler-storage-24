from __future__ import annotations

from pathlib import Path

import pytest

from repo_inspector.analysis.impact import analyze
from repo_inspector.utils.ast_parser import ModuleInfo, ProjectIndex


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_index(tmp_path: Path, modules: dict[str, list[str]]) -> ProjectIndex:
    """Build a ProjectIndex from {module_key: [imported_module_keys]}."""
    mod_infos: dict[str, ModuleInfo] = {}
    py_files: list[Path] = []

    for key, imports in modules.items():
        rel_path = Path(key.replace(".", "/") + ".py")
        abs_path = tmp_path / rel_path
        abs_path.parent.mkdir(parents=True, exist_ok=True)
        abs_path.write_text("")
        mod_infos[key] = ModuleInfo(path=abs_path, lines=1, imports=imports)
        py_files.append(abs_path)

    return ProjectIndex(
        root_path=tmp_path,
        python_files=py_files,
        all_files=py_files,
        total_lines=len(modules),
        modules=mod_infos,
    )


def _target(tmp_path: Path, module_key: str) -> str:
    """Return the relative path string for a module key (as a CLI user would pass)."""
    return str(Path(module_key.replace(".", "/") + ".py"))


# ---------------------------------------------------------------------------
# Direct importer detection
# ---------------------------------------------------------------------------

def test_direct_importer_detected(tmp_path):
    index = _make_index(tmp_path, {"app": ["lib"], "lib": []})
    result = analyze(index, _target(tmp_path, "lib"))
    affected = result.summary["affected_modules"]
    assert "app" in affected


def test_non_importer_not_affected(tmp_path):
    index = _make_index(tmp_path, {"app": ["lib"], "other": [], "lib": []})
    result = analyze(index, _target(tmp_path, "lib"))
    affected = result.summary["affected_modules"]
    assert "other" not in affected


def test_target_itself_not_in_affected(tmp_path):
    index = _make_index(tmp_path, {"app": ["lib"], "lib": []})
    result = analyze(index, _target(tmp_path, "lib"))
    affected = result.summary["affected_modules"]
    assert "lib" not in affected


# ---------------------------------------------------------------------------
# Transitive impact (BFS)
# ---------------------------------------------------------------------------

def test_transitive_importer_detected(tmp_path):
    # a → b → c: changing c affects b and a
    index = _make_index(tmp_path, {"a": ["b"], "b": ["c"], "c": []})
    result = analyze(index, _target(tmp_path, "c"))
    affected = result.summary["affected_modules"]
    assert "b" in affected
    assert "a" in affected


def test_transitive_chain_depth_three(tmp_path):
    # d → c → b → a
    index = _make_index(tmp_path, {
        "d": ["c"], "c": ["b"], "b": ["a"], "a": [],
    })
    result = analyze(index, _target(tmp_path, "a"))
    affected = result.summary["affected_modules"]
    assert set(affected) == {"b", "c", "d"}


def test_diamond_all_affected(tmp_path):
    # top imports left and right; both import base
    index = _make_index(tmp_path, {
        "top": ["left", "right"],
        "left": ["base"],
        "right": ["base"],
        "base": [],
    })
    result = analyze(index, _target(tmp_path, "base"))
    affected = set(result.summary["affected_modules"])
    assert "left" in affected
    assert "right" in affected
    assert "top" in affected


def test_isolated_module_no_impact(tmp_path):
    index = _make_index(tmp_path, {"a": [], "b": []})
    result = analyze(index, _target(tmp_path, "a"))
    assert result.summary["affected_modules_count"] == 0
    assert result.findings == []


# ---------------------------------------------------------------------------
# Finding format
# ---------------------------------------------------------------------------

def test_finding_severity_is_info(tmp_path):
    index = _make_index(tmp_path, {"app": ["lib"], "lib": []})
    result = analyze(index, _target(tmp_path, "lib"))
    for finding in result.findings:
        assert finding.severity == "info"


def test_finding_location_is_module_key(tmp_path):
    index = _make_index(tmp_path, {"app": ["lib"], "lib": []})
    result = analyze(index, _target(tmp_path, "lib"))
    assert any(f.location == "app" for f in result.findings)


def test_finding_message_mentions_target(tmp_path):
    index = _make_index(tmp_path, {"app": ["lib"], "lib": []})
    result = analyze(index, _target(tmp_path, "lib"))
    assert all("lib" in f.message for f in result.findings)


def test_finding_count_matches_affected_count(tmp_path):
    index = _make_index(tmp_path, {"a": ["c"], "b": ["c"], "c": []})
    result = analyze(index, _target(tmp_path, "c"))
    assert len(result.findings) == result.summary["affected_modules_count"]


# ---------------------------------------------------------------------------
# Summary fields
# ---------------------------------------------------------------------------

def test_summary_keys_present(tmp_path):
    index = _make_index(tmp_path, {"a": ["b"], "b": []})
    result = analyze(index, _target(tmp_path, "b"))
    for key in ("target_file", "affected_modules_count", "affected_modules"):
        assert key in result.summary


def test_summary_target_file_preserved(tmp_path):
    index = _make_index(tmp_path, {"a": ["b"], "b": []})
    target = _target(tmp_path, "b")
    result = analyze(index, target)
    assert result.summary["target_file"] == target


def test_summary_affected_count_correct(tmp_path):
    index = _make_index(tmp_path, {"a": ["c"], "b": ["c"], "c": []})
    result = analyze(index, _target(tmp_path, "c"))
    assert result.summary["affected_modules_count"] == 2
    assert len(result.summary["affected_modules"]) == 2


def test_summary_affected_modules_sorted(tmp_path):
    index = _make_index(tmp_path, {
        "z_mod": ["shared"], "a_mod": ["shared"], "shared": []
    })
    result = analyze(index, _target(tmp_path, "shared"))
    mods = result.summary["affected_modules"]
    assert mods == sorted(mods)


# ---------------------------------------------------------------------------
# Unknown target
# ---------------------------------------------------------------------------

def test_unknown_target_returns_empty_findings(tmp_path):
    index = _make_index(tmp_path, {"a": [], "b": []})
    result = analyze(index, "nonexistent.py")
    assert result.findings == []
    assert result.summary["affected_modules_count"] == 0


def test_unknown_target_error_in_summary(tmp_path):
    index = _make_index(tmp_path, {"a": []})
    result = analyze(index, "ghost.py")
    assert "error" in result.summary


def test_analyzer_name(tmp_path):
    index = ProjectIndex(
        root_path=tmp_path, python_files=[], all_files=[], total_lines=0, modules={}
    )
    result = analyze(index, "anything.py")
    assert result.analyzer_name == "Impact Analysis"


# ---------------------------------------------------------------------------
# Absolute path target
# ---------------------------------------------------------------------------

def test_absolute_path_resolves(tmp_path):
    index = _make_index(tmp_path, {"app": ["lib"], "lib": []})
    abs_target = str((tmp_path / "lib.py").resolve())
    result = analyze(index, abs_target)
    assert "app" in result.summary["affected_modules"]
