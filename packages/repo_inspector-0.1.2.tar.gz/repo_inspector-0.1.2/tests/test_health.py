from __future__ import annotations

import ast
import textwrap
from pathlib import Path

import pytest

from repo_inspector.analysis.health import (
    _WEIGHTS,
    _avg_complexity_score,
    _dead_code_ratio,
    _documentation_ratio,
    _has_ci_pipeline,
    _has_linting_config,
    _test_coverage_estimate,
    analyze,
)
from repo_inspector.utils.ast_parser import FunctionInfo, ModuleInfo, ProjectIndex


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_index(tmp_path: Path, files: dict[str, str]) -> ProjectIndex:
    """Build ProjectIndex from {module_key: source}. Writes real files."""
    mod_infos: dict[str, ModuleInfo] = {}
    py_files: list[Path] = []

    for key, source in files.items():
        rel_path = Path(key.replace(".", "/") + ".py")
        abs_path = tmp_path / rel_path
        abs_path.parent.mkdir(parents=True, exist_ok=True)
        abs_path.write_text(source)
        lines = source.count("\n") + (1 if source and not source.endswith("\n") else 0)

        tree = ast.parse(source)
        functions = []
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                end = getattr(node, "end_lineno", node.lineno)
                functions.append(FunctionInfo(
                    name=node.name, start_line=node.lineno, end_line=end,
                    complexity=0, is_called=False,
                ))

        mod_infos[key] = ModuleInfo(path=abs_path, lines=lines, functions=functions)
        py_files.append(abs_path)

    return ProjectIndex(
        root_path=tmp_path,
        python_files=py_files,
        all_files=py_files,
        total_lines=sum(m.lines for m in mod_infos.values()),
        modules=mod_infos,
    )


# ---------------------------------------------------------------------------
# Weight contract
# ---------------------------------------------------------------------------

def test_weights_sum_to_one():
    total = sum(_WEIGHTS.values())
    assert abs(total - 1.0) < 1e-9


def test_weights_keys():
    expected = {
        "test_coverage_estimate", "avg_complexity_score", "documentation_ratio",
        "has_ci_pipeline", "dead_code_ratio", "has_linting_config",
    }
    assert set(_WEIGHTS.keys()) == expected


# ---------------------------------------------------------------------------
# CI pipeline detection
# ---------------------------------------------------------------------------

def test_ci_detected_github_workflows(tmp_path):
    (tmp_path / ".github" / "workflows").mkdir(parents=True)
    assert _has_ci_pipeline(tmp_path) is True


def test_ci_detected_gitlab(tmp_path):
    (tmp_path / ".gitlab-ci.yml").write_text("stages: []")
    assert _has_ci_pipeline(tmp_path) is True


def test_ci_detected_jenkinsfile(tmp_path):
    (tmp_path / "Jenkinsfile").write_text("pipeline {}")
    assert _has_ci_pipeline(tmp_path) is True


def test_ci_not_detected(tmp_path):
    assert _has_ci_pipeline(tmp_path) is False


# ---------------------------------------------------------------------------
# Linting config detection
# ---------------------------------------------------------------------------

def test_lint_detected_flake8(tmp_path):
    (tmp_path / ".flake8").write_text("[flake8]\nmax-line-length = 88\n")
    assert _has_linting_config(tmp_path) is True


def test_lint_detected_pylintrc(tmp_path):
    (tmp_path / ".pylintrc").write_text("[MASTER]\n")
    assert _has_linting_config(tmp_path) is True


def test_lint_detected_pyproject_ruff(tmp_path):
    (tmp_path / "pyproject.toml").write_text("[tool.ruff]\nline-length = 88\n")
    assert _has_linting_config(tmp_path) is True


def test_lint_detected_pyproject_pylint(tmp_path):
    (tmp_path / "pyproject.toml").write_text("[tool.pylint.messages_control]\n")
    assert _has_linting_config(tmp_path) is True


def test_lint_not_detected_empty_pyproject(tmp_path):
    (tmp_path / "pyproject.toml").write_text("[project]\nname = 'x'\n")
    assert _has_linting_config(tmp_path) is False


def test_lint_not_detected(tmp_path):
    assert _has_linting_config(tmp_path) is False


# ---------------------------------------------------------------------------
# Test coverage estimate
# ---------------------------------------------------------------------------

def test_coverage_all_test_files(tmp_path):
    index = _make_index(tmp_path, {
        "tests.test_a": "def test_foo(): pass\n",
        "tests.test_b": "def test_bar(): pass\n",
    })
    # All files are under tests/ → ratio = 2/0 → capped at 1.0
    assert _test_coverage_estimate(index) == 1.0


def test_coverage_no_test_files(tmp_path):
    index = _make_index(tmp_path, {
        "app": "x = 1\n",
        "lib": "y = 2\n",
    })
    assert _test_coverage_estimate(index) == 0.0


def test_coverage_equal_ratio(tmp_path):
    index = _make_index(tmp_path, {
        "app": "x = 1\n",
        "tests.test_app": "def test_x(): pass\n",
    })
    ratio = _test_coverage_estimate(index)
    assert ratio == 1.0  # 1 test / 1 non-test = 1.0


def test_coverage_partial(tmp_path):
    index = _make_index(tmp_path, {
        "a": "x = 1\n",
        "b": "y = 2\n",
        "tests.test_a": "def test_x(): pass\n",
    })
    ratio = _test_coverage_estimate(index)
    assert 0.0 < ratio < 1.0


# ---------------------------------------------------------------------------
# Avg complexity score
# ---------------------------------------------------------------------------

def test_complexity_score_no_functions(tmp_path):
    index = _make_index(tmp_path, {"empty": "x = 1\n"})
    # No functions → score defaults to 1.0
    assert _avg_complexity_score(index) == 1.0


def test_complexity_score_simple_functions(tmp_path):
    source = "def f(): return 1\ndef g(): return 2\n"
    index = _make_index(tmp_path, {"mod": source})
    score = _avg_complexity_score(index)
    assert 0.0 <= score <= 1.0
    # Simple functions have CC=1 → should give a high score
    assert score > 0.8


def test_complexity_score_empty_project(tmp_path):
    index = ProjectIndex(
        root_path=tmp_path, python_files=[], all_files=[], total_lines=0, modules={}
    )
    assert _avg_complexity_score(index) == 1.0


# ---------------------------------------------------------------------------
# Documentation ratio
# ---------------------------------------------------------------------------

def test_doc_ratio_all_documented(tmp_path):
    source = textwrap.dedent('''\
        def f():
            """Does f."""
            return 1

        def g():
            """Does g."""
            return 2
    ''')
    index = _make_index(tmp_path, {"mod": source})
    assert _documentation_ratio(index) == 1.0


def test_doc_ratio_none_documented(tmp_path):
    source = "def f(): return 1\ndef g(): return 2\n"
    index = _make_index(tmp_path, {"mod": source})
    assert _documentation_ratio(index) == 0.0


def test_doc_ratio_half_documented(tmp_path):
    source = textwrap.dedent('''\
        def f():
            """Has docstring."""
            return 1

        def g():
            return 2
    ''')
    index = _make_index(tmp_path, {"mod": source})
    assert _documentation_ratio(index) == 0.5


def test_doc_ratio_no_functions(tmp_path):
    index = _make_index(tmp_path, {"empty": "x = 1\n"})
    assert _documentation_ratio(index) == 1.0


# ---------------------------------------------------------------------------
# Dead code ratio
# ---------------------------------------------------------------------------

def test_dead_code_ratio_no_functions(tmp_path):
    index = ProjectIndex(
        root_path=tmp_path, python_files=[], all_files=[], total_lines=0, modules={}
    )
    assert _dead_code_ratio(index) == 1.0


def test_dead_code_ratio_all_used(tmp_path):
    source = "def helper(): return 1\nresult = helper()\n"
    index = _make_index(tmp_path, {"mod": source})
    ratio = _dead_code_ratio(index)
    # helper is referenced → dead ratio should be close to 1.0
    assert ratio > 0.5


def test_dead_code_ratio_bounded(tmp_path):
    source = "def orphan(): pass\n"
    index = _make_index(tmp_path, {"mod": source})
    ratio = _dead_code_ratio(index)
    assert 0.0 <= ratio <= 1.0


# ---------------------------------------------------------------------------
# Full analyze()
# ---------------------------------------------------------------------------

def test_analyze_returns_analysis_result(tmp_path):
    index = _make_index(tmp_path, {"mod": "x = 1\n"})
    result = analyze(index)
    assert result.analyzer_name == "Health Analysis"


def test_score_in_summary(tmp_path):
    index = _make_index(tmp_path, {"mod": "x = 1\n"})
    result = analyze(index)
    assert "score" in result.summary
    score = result.summary["score"]
    assert 0.0 <= score <= 10.0


def test_breakdown_in_summary(tmp_path):
    index = _make_index(tmp_path, {"mod": "x = 1\n"})
    result = analyze(index)
    breakdown = result.summary["breakdown"]
    for key in _WEIGHTS:
        assert key in breakdown


def test_score_is_rounded_to_one_decimal(tmp_path):
    index = _make_index(tmp_path, {"mod": "x = 1\n"})
    result = analyze(index)
    score = result.summary["score"]
    assert score == round(score, 1)


def test_one_finding_emitted(tmp_path):
    index = _make_index(tmp_path, {"mod": "x = 1\n"})
    result = analyze(index)
    assert len(result.findings) == 1


def test_high_score_info_severity(tmp_path):
    # Maximise every signal: test files, documented functions, simple code
    source = textwrap.dedent('''\
        def f():
            """Documented."""
            return 1
    ''')
    files = {
        "lib": source,
        "tests.test_lib": "def test_f(): pass\n",
    }
    index = _make_index(tmp_path, files)
    # Add linting config to the tmp root
    (tmp_path / "pyproject.toml").write_text("[tool.ruff]\n")
    (tmp_path / ".github" / "workflows").mkdir(parents=True)
    result = analyze(index)
    assert result.findings[0].severity in ("info", "warning")


def test_low_score_critical_severity(tmp_path):
    # Minimal project: no tests, no docs, no CI, no lint
    source = "\n".join(
        [f"if x == {i}: pass" for i in range(20)]
    )
    index = _make_index(tmp_path, {"big": f"def heavy(x):\n" + "\n".join(
        f"    if x == {i}: pass" for i in range(20)
    ) + "\n"})
    result = analyze(index)
    # No tests, no CI, no lint → score will be low
    score = result.summary["score"]
    severity = result.findings[0].severity
    if score < 4.0:
        assert severity == "critical"
    elif score < 7.0:
        assert severity == "warning"
    else:
        assert severity == "info"


def test_weights_in_breakdown(tmp_path):
    index = _make_index(tmp_path, {"mod": "x = 1\n"})
    result = analyze(index)
    assert "weights" in result.summary["breakdown"]
    assert result.summary["breakdown"]["weights"] == _WEIGHTS
