"""
Shared pytest fixtures for repo-inspector tests.

Two factory fixtures are provided:

  make_module_info  — builds a single ModuleInfo (optionally with source)
  make_project_index — builds a full ProjectIndex from either:
      * {module_key: source_code}  (source=True, default)
      * {module_key: [import_keys]} (source=False)
"""
from __future__ import annotations

import ast
from pathlib import Path
from typing import Callable

import pytest

from repo_inspector.utils.ast_parser import (
    ClassInfo,
    FunctionInfo,
    ModuleInfo,
    ProjectIndex,
)


def _line_count(source: str) -> int:
    return source.count("\n") + (1 if source and not source.endswith("\n") else 0)


def _functions_from_source(source: str) -> list[FunctionInfo]:
    tree = ast.parse(source)
    functions: list[FunctionInfo] = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            end = getattr(node, "end_lineno", node.lineno)
            functions.append(FunctionInfo(
                name=node.name,
                start_line=node.lineno,
                end_line=end,
                complexity=0,
                is_called=False,
            ))
    return functions


def _classes_from_source(source: str) -> list[ClassInfo]:
    tree = ast.parse(source)
    classes: list[ClassInfo] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.ClassDef):
            end = getattr(node, "end_lineno", node.lineno)
            classes.append(ClassInfo(name=node.name, start_line=node.lineno, end_line=end))
    return classes


def _imports_from_source(source: str) -> list[str]:
    tree = ast.parse(source)
    imports: list[str] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                imports.append(alias.name)
        elif isinstance(node, ast.ImportFrom) and node.module:
            imports.append(node.module)
    return imports


@pytest.fixture
def make_module_info(tmp_path: Path) -> Callable[..., ModuleInfo]:
    """
    Factory fixture: returns a function that builds a ModuleInfo.

    Usage::

        def test_foo(make_module_info):
            mi = make_module_info("mymod", source="def f(): pass\\n")
            # or without source (empty file):
            mi = make_module_info("pkg.sub", imports=["os", "sys"])
    """
    def _factory(
        key: str,
        source: str = "",
        imports: list[str] | None = None,
        lines: int | None = None,
    ) -> ModuleInfo:
        rel_path = Path(key.replace(".", "/") + ".py")
        abs_path = tmp_path / rel_path
        abs_path.parent.mkdir(parents=True, exist_ok=True)
        abs_path.write_text(source)

        computed_lines = lines if lines is not None else _line_count(source)

        if source:
            try:
                functions = _functions_from_source(source)
                classes = _classes_from_source(source)
                parsed_imports = _imports_from_source(source)
            except SyntaxError:
                functions, classes, parsed_imports = [], [], []
        else:
            functions, classes, parsed_imports = [], [], []

        effective_imports = imports if imports is not None else parsed_imports

        return ModuleInfo(
            path=abs_path,
            lines=computed_lines,
            functions=functions,
            classes=classes,
            imports=effective_imports,
        )

    return _factory


@pytest.fixture
def make_project_index(tmp_path: Path, make_module_info: Callable) -> Callable[..., ProjectIndex]:
    """
    Factory fixture: returns a function that builds a ProjectIndex.

    Two calling styles:

    **Source style** (default) — dict values are Python source strings::

        def test_foo(make_project_index):
            idx = make_project_index({
                "app": "import utils\\nx = 1\\n",
                "utils": "def helper(): return 42\\n",
            })

    **Import-graph style** — dict values are lists of imported module keys::

        def test_bar(make_project_index):
            idx = make_project_index(
                {"a": ["b", "c"], "b": [], "c": []},
                source=False,
            )
    """
    def _factory(
        spec: dict[str, str] | dict[str, list[str]],
        source: bool = True,
    ) -> ProjectIndex:
        mod_infos: dict[str, ModuleInfo] = {}
        py_files: list[Path] = []

        for key, value in spec.items():
            if source:
                mi = make_module_info(key, source=value)  # type: ignore[arg-type]
            else:
                mi = make_module_info(key, imports=value)  # type: ignore[arg-type]
            mod_infos[key] = mi
            py_files.append(mi.path)

        return ProjectIndex(
            root_path=tmp_path,
            python_files=py_files,
            all_files=py_files,
            total_lines=sum(m.lines for m in mod_infos.values()),
            modules=mod_infos,
        )

    return _factory


@pytest.fixture
def realistic_project_index(make_project_index: Callable) -> ProjectIndex:
    """
    A ready-made realistic ProjectIndex for tests that just need *something*
    without caring about specific content.

    Contains:
      - app.py        : one function, one import
      - utils.py      : two utility functions with docstrings
      - models.py     : one class
      - tests/test_app: one test function
    """
    return make_project_index({
        "app": (
            "import utils\n\n"
            "def run():\n"
            "    return utils.helper()\n"
        ),
        "utils": (
            "def helper():\n"
            '    """Return a constant."""\n'
            "    return 42\n\n"
            "def format_output(value):\n"
            '    """Format the output."""\n'
            "    return str(value)\n"
        ),
        "models": (
            "class Record:\n"
            "    def __init__(self, name):\n"
            "        self.name = name\n"
        ),
        "tests.test_app": (
            "from app import run\n\n"
            "def test_run():\n"
            "    assert run() == 42\n"
        ),
    })
