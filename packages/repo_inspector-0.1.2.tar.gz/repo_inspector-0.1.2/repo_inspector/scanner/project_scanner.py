from __future__ import annotations

from pathlib import Path

import pathspec

from repo_inspector.utils.ast_parser import (
    ClassInfo,
    FunctionInfo,
    ModuleInfo,
    ProjectIndex,
    extract_classes,
    extract_functions,
    extract_imports,
    parse_file,
)

# Directories always excluded regardless of .gitignore
_ALWAYS_EXCLUDE = frozenset({
    ".git",
    "__pycache__",
    ".venv",
    "venv",
    "dist",
    "build",
})


def _load_gitignore(root: Path) -> pathspec.PathSpec | None:
    gitignore = root / ".gitignore"
    if gitignore.is_file():
        lines = gitignore.read_text(encoding="utf-8", errors="replace").splitlines()
        return pathspec.PathSpec.from_lines("gitignore", lines)
    return None


def _is_excluded(path: Path, root: Path, spec: pathspec.PathSpec | None) -> bool:
    """Return True if this path should be skipped."""
    # Check every component of the relative path against the always-exclude set
    try:
        rel = path.relative_to(root)
    except ValueError:
        return False

    for part in rel.parts:
        if part in _ALWAYS_EXCLUDE:
            return True
        # *.egg-info directories
        if part.endswith(".egg-info"):
            return True

    if spec is not None:
        # pathspec.match_file expects a posix-style relative string
        if spec.match_file(rel.as_posix()):
            return True

    return False


def _iter_files(root: Path, spec: pathspec.PathSpec | None) -> list[Path]:
    """Walk root and return all non-excluded files."""
    result: list[Path] = []
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        if _is_excluded(path, root, spec):
            continue
        result.append(path)
    return result


def _module_key(path: Path, root: Path) -> str:
    """Convert a file path to a dotted module key relative to root."""
    try:
        rel = path.relative_to(root)
    except ValueError:
        return str(path)
    parts = list(rel.parts)
    if parts[-1].endswith(".py"):
        parts[-1] = parts[-1][:-3]
    return ".".join(parts)


def scan_project(root_path: Path) -> ProjectIndex:
    """Scan a Python project and return a fully populated ProjectIndex."""
    root_path = root_path.resolve()
    spec = _load_gitignore(root_path)

    all_files = _iter_files(root_path, spec)
    python_files = [f for f in all_files if f.suffix == ".py"]

    modules: dict[str, ModuleInfo] = {}
    total_lines = 0

    for py_file in python_files:
        source = py_file.read_text(encoding="utf-8", errors="replace")
        line_count = source.count("\n") + (1 if source and not source.endswith("\n") else 0)
        total_lines += line_count

        tree = parse_file(py_file)

        functions: list[FunctionInfo] = []
        classes: list[ClassInfo] = []
        imports: list[str] = []

        if tree is not None:
            functions = extract_functions(tree)
            classes = extract_classes(tree)
            imports = extract_imports(tree)

        key = _module_key(py_file, root_path)
        modules[key] = ModuleInfo(
            path=py_file,
            lines=line_count,
            functions=functions,
            classes=classes,
            imports=imports,
        )

    return ProjectIndex(
        root_path=root_path,
        python_files=python_files,
        all_files=all_files,
        total_lines=total_lines,
        modules=modules,
    )
