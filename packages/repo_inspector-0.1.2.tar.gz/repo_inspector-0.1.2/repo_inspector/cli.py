from __future__ import annotations

import sys
from importlib.metadata import version as pkg_version
from pathlib import Path
from typing import Optional

import typer

from repo_inspector.analysis import complexity as complexity_analyzer
from repo_inspector.analysis import coupling as coupling_analyzer
from repo_inspector.analysis import deadcode as deadcode_analyzer
from repo_inspector.analysis import health as health_analyzer
from repo_inspector.analysis import impact as impact_analyzer
from repo_inspector.analysis import imports as imports_analyzer
from repo_inspector.analysis import similarity as similarity_analyzer
from repo_inspector.analysis import todos as todos_analyzer
from repo_inspector.report.formatter import (
    print_findings,
    print_scan_summary,
    print_section_header,
)
from repo_inspector.scanner.project_scanner import scan_project

_HELP = """\
[bold]Repo Inspector[/bold] — offline static analysis for Python repositories.

Parses your project with the standard-library [cyan]ast[/cyan] module and surfaces code
quality metrics, architectural problems, and technical debt — no internet, no API keys.

[bold]Analyzers[/bold]

  [cyan]scan[/cyan]         Full summary — runs all analyzers at once
  [cyan]complexity[/cyan]   Cyclomatic complexity per function; God Object file detection
  [cyan]deadcode[/cyan]     Unreferenced functions, classes, and files (heuristic)
  [cyan]coupling[/cyan]     Fan-in / fan-out module coupling scores
  [cyan]imports[/cyan]      Dependency tree visualisation; circular import detection
  [cyan]impact[/cyan]       Blast radius of a change via reverse-dependency BFS
  [cyan]health[/cyan]       Weighted 0–10 score (tests, docs, CI, complexity …)
  [cyan]duplication[/cyan]  Structurally identical function bodies via AST hashing
  [cyan]todos[/cyan]        TODO / FIXME / HACK / NOQA / XXX comment inventory

[bold]Quick start[/bold]

  [green]repo-inspector scan .[/green]                 # summary of the current directory
  [green]repo-inspector scan . --full[/green]          # summary + all individual findings
  [green]repo-inspector scan . --output out.json[/green]   # also write a JSON report
  [green]repo-inspector complexity /path/to/repo[/green]
  [green]repo-inspector impact . src/auth.py[/green]

[bold]Thresholds[/bold]

  Cyclomatic complexity  warning ≥ 10  critical ≥ 20
  Function size (lines)  warning ≥ 50  critical ≥ 80
  File size (lines)      warning ≥ 500 critical ≥ 1000
  Coupling score         warning ≥ 10  critical ≥ 20

[bold]More info[/bold]  https://github.com/samcab28/Repo-Inspector
"""

app = typer.Typer(
    name="repo-inspector",
    help=_HELP,
    no_args_is_help=True,
    add_completion=False,
    rich_markup_mode="rich",
)


def _version_callback(value: bool) -> None:
    if value:
        try:
            v = pkg_version("repo-inspector")
        except Exception:
            v = "unknown"
        typer.echo(f"repo-inspector {v}")
        raise typer.Exit()


@app.callback(invoke_without_command=True)
def _main(
    ctx: typer.Context,
    version: Optional[bool] = typer.Option(
        None,
        "--version",
        "-V",
        help="Show version and exit.",
        callback=_version_callback,
        is_eager=True,
    ),
) -> None:
    pass


def _resolve_path(path: Path) -> Path:
    resolved = path.resolve()
    if not resolved.exists():
        typer.echo(f"Error: path does not exist: {path}", err=True)
        raise typer.Exit(1)
    if not resolved.is_dir():
        typer.echo(f"Error: path is not a directory: {path}", err=True)
        raise typer.Exit(1)
    return resolved


@app.command()
def scan(
    path: Path = typer.Argument(..., help="Path to the repository to analyze"),
    full: bool = typer.Option(False, "--full", help="Also print all individual findings"),
    output: str = typer.Option("", "--output", help="Write JSON report to this file path"),
):
    """Full analysis summary of a repository."""
    import json

    root = _resolve_path(path)
    index = scan_project(root)

    results: dict = {
        "complexity":  complexity_analyzer.analyze(index),
        "imports":     imports_analyzer.analyze(index, render_tree=False),
        "coupling":    coupling_analyzer.analyze(index),
        "deadcode":    deadcode_analyzer.analyze(index),
        "similarity":  similarity_analyzer.analyze(index),
        "todos":       todos_analyzer.analyze(index),
        "health":      health_analyzer.analyze(index),
    }

    health_score = results["health"].summary.get("score")
    print_scan_summary(index, results, health_score=health_score)

    if full:
        for result in results.values():
            print_findings(result)

    if output:
        report: dict = {
            "root_path": str(index.root_path),
            "python_files": len(index.python_files),
            "total_lines": index.total_lines,
            "health_score": health_score,
            "analyzers": {
                key: {
                    "findings": [
                        {"severity": f.severity, "message": f.message, "location": f.location}
                        for f in result.findings
                    ],
                    "summary": {
                        k: v for k, v in result.summary.items()
                        if not isinstance(v, (list, dict))
                    },
                }
                for key, result in results.items()
            },
        }
        out_path = Path(output)
        out_path.write_text(json.dumps(report, indent=2))
        typer.echo(f"Report written to {out_path}")


@app.command()
def complexity(path: Path = typer.Argument(..., help="Path to the repository to analyze")):
    """Cyclomatic complexity report."""
    root = _resolve_path(path)
    index = scan_project(root)
    result = complexity_analyzer.analyze(index)
    print_findings(result)


@app.command()
def deadcode(path: Path = typer.Argument(..., help="Path to the repository to analyze")):
    """Dead code detection."""
    root = _resolve_path(path)
    index = scan_project(root)
    result = deadcode_analyzer.analyze(index)
    print_findings(result)


@app.command()
def coupling(path: Path = typer.Argument(..., help="Path to the repository to analyze")):
    """Module coupling analysis."""
    root = _resolve_path(path)
    index = scan_project(root)
    result = coupling_analyzer.analyze(index)
    print_findings(result)


@app.command()
def imports(path: Path = typer.Argument(..., help="Path to the repository to analyze")):
    """Import graph visualization."""
    root = _resolve_path(path)
    index = scan_project(root)
    print_section_header("Import Graph")
    result = imports_analyzer.analyze(index, render_tree=True)
    if result.findings or result.summary:
        print_findings(result)


@app.command()
def impact(
    path: Path = typer.Argument(..., help="Path to the repository to analyze"),
    file: Path = typer.Argument(..., help="File to analyze change impact for"),
):
    """Change impact analysis for a specific file."""
    root = _resolve_path(path)
    index = scan_project(root)
    result = impact_analyzer.analyze(index, str(file))
    print_findings(result)


@app.command()
def health(path: Path = typer.Argument(..., help="Path to the repository to analyze")):
    """Repository health score."""
    root = _resolve_path(path)
    index = scan_project(root)
    result = health_analyzer.analyze(index)
    print_findings(result)


@app.command()
def duplication(path: Path = typer.Argument(..., help="Path to the repository to analyze")):
    """Duplicate code detection."""
    root = _resolve_path(path)
    index = scan_project(root)
    result = similarity_analyzer.analyze(index)
    print_findings(result)


@app.command()
def todos(path: Path = typer.Argument(..., help="Path to the repository to analyze")):
    """TODO/FIXME comment scanner."""
    root = _resolve_path(path)
    index = scan_project(root)
    result = todos_analyzer.analyze(index)
    print_findings(result)


if __name__ == "__main__":
    app()
