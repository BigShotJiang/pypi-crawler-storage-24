from __future__ import annotations

import networkx as nx

from repo_inspector.utils.ast_parser import ProjectIndex


def _import_to_module_key(import_name: str, known_keys: frozenset[str]) -> str | None:
    """
    Try to resolve a raw import string (e.g. "repo_inspector.analysis.imports")
    to a key that exists in the ProjectIndex modules dict.

    Tries the full name first, then progressively shorter prefixes so that
    "from subpkg import foo" recorded as "subpkg" still resolves to "subpkg"
    if that key exists.
    """
    if import_name in known_keys:
        return import_name
    # Try dot-separated prefixes (longest first)
    parts = import_name.split(".")
    for length in range(len(parts), 0, -1):
        candidate = ".".join(parts[:length])
        if candidate in known_keys:
            return candidate
    return None


def build_import_graph(index: ProjectIndex) -> nx.DiGraph:
    """
    Build a directed import graph from a ProjectIndex.

    Nodes  : module keys (dotted relative paths, e.g. "repo_inspector.cli")
    Edges  : A → B means module A imports module B (internal imports only)
    """
    graph = nx.DiGraph()
    known_keys = frozenset(index.modules.keys())

    # Add every module as a node so isolated modules still appear
    for key in known_keys:
        graph.add_node(key)

    for src_key, module in index.modules.items():
        for raw_import in module.imports:
            target_key = _import_to_module_key(raw_import, known_keys)
            if target_key is not None and target_key != src_key:
                graph.add_edge(src_key, target_key)

    return graph
