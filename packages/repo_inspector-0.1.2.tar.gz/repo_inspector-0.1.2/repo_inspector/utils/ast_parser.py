from __future__ import annotations

import ast
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal


@dataclass
class Finding:
    severity: Literal["info", "warning", "critical"]
    message: str
    location: str | None = None


@dataclass
class FunctionInfo:
    name: str
    start_line: int
    end_line: int
    complexity: int
    is_called: bool


@dataclass
class ClassInfo:
    name: str
    start_line: int
    end_line: int


@dataclass
class ModuleInfo:
    path: Path
    lines: int
    functions: list[FunctionInfo] = field(default_factory=list)
    classes: list[ClassInfo] = field(default_factory=list)
    imports: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class ProjectIndex:
    root_path: Path
    python_files: list[Path]
    all_files: list[Path]
    total_lines: int
    modules: dict[str, ModuleInfo]


@dataclass
class AnalysisResult:
    analyzer_name: str
    findings: list[Finding] = field(default_factory=list)
    summary: dict[str, Any] = field(default_factory=dict)


def parse_file(path: Path) -> ast.Module | None:
    """Parse a Python file and return its AST, or None on syntax error."""
    try:
        source = path.read_text(encoding="utf-8", errors="replace")
        return ast.parse(source, filename=str(path))
    except SyntaxError:
        return None


def extract_functions(tree: ast.Module) -> list[FunctionInfo]:
    """Extract all function definitions from an AST."""
    functions: list[FunctionInfo] = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            end_line = getattr(node, "end_lineno", node.lineno)
            functions.append(
                FunctionInfo(
                    name=node.name,
                    start_line=node.lineno,
                    end_line=end_line,
                    complexity=0,
                    is_called=False,
                )
            )
    return functions


def extract_classes(tree: ast.Module) -> list[ClassInfo]:
    """Extract class definitions from an AST."""
    classes: list[ClassInfo] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.ClassDef):
            end_line = getattr(node, "end_lineno", node.lineno)
            classes.append(
                ClassInfo(name=node.name, start_line=node.lineno, end_line=end_line)
            )
    return classes


def extract_imports(tree: ast.Module) -> list[str]:
    """Extract imported module names from an AST."""
    imports: list[str] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                imports.append(alias.name)
        elif isinstance(node, ast.ImportFrom):
            if node.module:
                imports.append(node.module)
    return imports
