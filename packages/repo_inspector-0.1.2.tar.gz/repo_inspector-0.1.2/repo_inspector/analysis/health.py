from __future__ import annotations

import ast
from pathlib import Path

from repo_inspector.analysis.complexity import analyze as complexity_analyze
from repo_inspector.analysis.deadcode import analyze as deadcode_analyze
from repo_inspector.utils.ast_parser import AnalysisResult, Finding, ProjectIndex

# ---------------------------------------------------------------------------
# Weights — all must sum to 1.0
# ---------------------------------------------------------------------------
_WEIGHTS: dict[str, float] = {
    "test_coverage_estimate": 0.25,
    "avg_complexity_score":   0.20,
    "documentation_ratio":    0.20,
    "has_ci_pipeline":        0.15,
    "dead_code_ratio":        0.10,
    "has_linting_config":     0.10,
}

# CI pipeline marker files / directories
_CI_MARKERS = (
    ".github/workflows",
    ".gitlab-ci.yml",
    "Jenkinsfile",
)

# Linting / formatting config indicators
_LINT_FILES = (
    ".flake8",
    ".pylintrc",
    "setup.cfg",
    ".ruff.toml",
    "tox.ini",
)
_PYPROJECT_LINT_SECTIONS = (
    "[tool.ruff]",
    "[tool.pylint",
    "[tool.flake8]",
    "[tool.mypy]",
)


def _has_ci_pipeline(root: Path) -> bool:
    for marker in _CI_MARKERS:
        if (root / marker).exists():
            return True
    return False


def _has_linting_config(root: Path) -> bool:
    for fname in _LINT_FILES:
        if (root / fname).is_file():
            return True
    pyproject = root / "pyproject.toml"
    if pyproject.is_file():
        content = pyproject.read_text(encoding="utf-8", errors="replace")
        if any(section in content for section in _PYPROJECT_LINT_SECTIONS):
            return True
    return False


def _test_coverage_estimate(index: ProjectIndex) -> float:
    """Ratio of test files to non-test files, capped at 1.0."""
    test_files = [
        p for p in index.python_files
        if p.name.startswith("test_") or p.stem.endswith("_test")
        or "tests" in p.parts
    ]
    non_test_files = len(index.python_files) - len(test_files)
    if non_test_files == 0:
        return 1.0
    return min(len(test_files) / non_test_files, 1.0)


def _avg_complexity_score(index: ProjectIndex) -> float:
    """
    Invert average cyclomatic complexity to a 0-1 score.
    avg CC of 1 → 1.0;  avg CC of 10 → 0.0;  capped at both ends.
    """
    if not index.modules:
        return 1.0
    result = complexity_analyze(index)
    avg_cc = float(result.summary.get("avg_complexity", 1))
    # Linear scale: 1 → 1.0, 10 → 0.0
    score = 1.0 - (avg_cc - 1.0) / 9.0
    return max(0.0, min(1.0, score))


def _documentation_ratio(index: ProjectIndex) -> float:
    """Fraction of functions that have a docstring."""
    total = 0
    documented = 0
    for module in index.modules.values():
        tree_text = None
        try:
            tree_text = module.path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        try:
            tree = ast.parse(tree_text)
        except SyntaxError:
            continue
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                total += 1
                if (
                    node.body
                    and isinstance(node.body[0], ast.Expr)
                    and isinstance(node.body[0].value, ast.Constant)
                    and isinstance(node.body[0].value.value, str)
                ):
                    documented += 1
    if total == 0:
        return 1.0
    return documented / total


def _dead_code_ratio(index: ProjectIndex) -> float:
    """
    Inverted ratio of unused functions to total functions → 0-1 score.
    0 dead functions → 1.0;  all dead → 0.0.
    """
    total_functions = sum(len(m.functions) for m in index.modules.values())
    if total_functions == 0:
        return 1.0
    result = deadcode_analyze(index)
    unused = int(result.summary.get("unused_functions_count", 0))
    dead_ratio = unused / total_functions
    return max(0.0, 1.0 - dead_ratio)


def analyze(index: ProjectIndex) -> AnalysisResult:
    root = index.root_path

    signals: dict[str, float] = {
        "test_coverage_estimate": _test_coverage_estimate(index),
        "avg_complexity_score":   _avg_complexity_score(index),
        "documentation_ratio":    _documentation_ratio(index),
        "has_ci_pipeline":        1.0 if _has_ci_pipeline(root) else 0.0,
        "dead_code_ratio":        _dead_code_ratio(index),
        "has_linting_config":     1.0 if _has_linting_config(root) else 0.0,
    }

    weighted_sum = sum(_WEIGHTS[k] * v for k, v in signals.items())
    score = round(weighted_sum * 10, 1)

    findings: list[Finding] = []
    if score < 4.0:
        findings.append(Finding(severity="critical", message=f"Repository health score is low: {score}/10"))
    elif score < 7.0:
        findings.append(Finding(severity="warning", message=f"Repository health score needs improvement: {score}/10"))
    else:
        findings.append(Finding(severity="info", message=f"Repository health score: {score}/10"))

    breakdown = {k: round(v, 3) for k, v in signals.items()}
    breakdown["weights"] = {k: _WEIGHTS[k] for k in _WEIGHTS}

    return AnalysisResult(
        analyzer_name="Health Analysis",
        findings=findings,
        summary={"score": score, "breakdown": breakdown},
    )
