from __future__ import annotations

import re
from pathlib import Path

from repo_inspector.utils.ast_parser import AnalysisResult, Finding, ProjectIndex

# Tags to scan for (case-insensitive in source, normalised to upper in summary)
_TAGS = ("TODO", "FIXME", "HACK", "NOQA", "XXX")
_TAG_PATTERN = re.compile(
    r"#.*?\b(" + "|".join(_TAGS) + r")\b(.*)",
    re.IGNORECASE,
)


def _scan_file(path: Path, rel: str) -> list[Finding]:
    """Return one Finding per tagged comment line in the file."""
    findings: list[Finding] = []
    try:
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return findings

    for lineno, line in enumerate(lines, start=1):
        match = _TAG_PATTERN.search(line)
        if match:
            tag = match.group(1).upper()
            tail = match.group(2).strip().lstrip(":").strip()
            message = f"{tag}: {tail}" if tail else tag
            findings.append(Finding(
                severity="info",
                message=message,
                location=f"{rel}:{lineno}",
            ))
    return findings


def analyze(index: ProjectIndex) -> AnalysisResult:
    findings: list[Finding] = []
    tag_counts: dict[str, int] = {tag: 0 for tag in _TAGS}

    for module in index.modules.values():
        try:
            rel = str(module.path.relative_to(index.root_path))
        except ValueError:
            rel = str(module.path)

        for finding in _scan_file(module.path, rel):
            findings.append(finding)
            # Extract tag from the message prefix (e.g. "TODO: fix this" → "TODO")
            tag = finding.message.split(":")[0].split()[0].upper()
            if tag in tag_counts:
                tag_counts[tag] += 1

    summary: dict = {"total_count": len(findings)}
    summary.update(tag_counts)

    return AnalysisResult(
        analyzer_name="TODO/FIXME Analysis",
        findings=findings,
        summary=summary,
    )
