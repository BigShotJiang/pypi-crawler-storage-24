from __future__ import annotations

import ast
from pathlib import Path

from repo_inspector.utils.ast_parser import AnalysisResult, Finding, ProjectIndex
from repo_inspector.utils.graph_builder import build_import_graph

_ALWAYS_LIVE = frozenset({
    # Common entry-point and protocol names that are never explicitly called
    "main", "__init__", "__new__", "__repr__", "__str__", "__len__",
    "__iter__", "__next__", "__enter__", "__exit__", "__call__",
    "__getitem__", "__setitem__", "__delitem__", "__contains__",
    "__eq__", "__hash__", "__lt__", "__le__", "__gt__", "__ge__",
    "__add__", "__sub__", "__mul__", "__truediv__", "__floordiv__",
    "__mod__", "__pow__", "__and__", "__or__", "__xor__",
    "__iadd__", "__isub__", "__imul__", "__itruediv__",
    "__get__", "__set__", "__delete__",
    "__class_getitem__", "__init_subclass__",
    "setUp", "tearDown", "setUpClass", "tearDownClass",  # unittest
})


def _collect_references(tree: ast.Module) -> set[str]:
    """
    Return every name that is *used* in the AST:
    - function/method calls  (foo(), obj.foo())
    - base class names       (class X(Base):)
    - plain name loads       (x = foo)
    """
    refs: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Call):
            func = node.func
            if isinstance(func, ast.Name):
                refs.add(func.id)
            elif isinstance(func, ast.Attribute):
                refs.add(func.attr)
        elif isinstance(node, ast.ClassDef):
            for base in node.bases:
                if isinstance(base, ast.Name):
                    refs.add(base.id)
                elif isinstance(base, ast.Attribute):
                    refs.add(base.attr)
        elif isinstance(node, ast.Name) and isinstance(node.ctx, ast.Load):
            refs.add(node.id)
        elif isinstance(node, ast.Attribute) and isinstance(node.ctx, ast.Load):
            refs.add(node.attr)
    return refs


def _parse_source(path: Path) -> ast.Module | None:
    try:
        return ast.parse(path.read_text(encoding="utf-8", errors="replace"),
                         filename=str(path))
    except SyntaxError:
        return None


def analyze(index: ProjectIndex) -> AnalysisResult:
    findings: list[Finding] = []

    # -----------------------------------------------------------------------
    # Step 1: collect all defined names and all referenced names across repo
    # -----------------------------------------------------------------------
    all_references: set[str] = set()
    defined_functions: list[tuple[str, str, str]] = []   # (module_key, name, location)
    defined_classes: list[tuple[str, str, str]] = []

    for module_key, module in index.modules.items():
        tree = _parse_source(module.path)
        if tree is None:
            continue

        refs = _collect_references(tree)
        all_references.update(refs)

        try:
            rel = str(module.path.relative_to(index.root_path))
        except ValueError:
            rel = str(module.path)

        for fn in module.functions:
            defined_functions.append((module_key, fn.name, f"{rel}:{fn.name}"))

        for cls in module.classes:
            defined_classes.append((module_key, cls.name, f"{rel}:{cls.name}"))

    # -----------------------------------------------------------------------
    # Step 2: functions/classes defined but never referenced anywhere
    # -----------------------------------------------------------------------
    unused_functions = 0
    for _mod_key, name, location in defined_functions:
        if name in _ALWAYS_LIVE:
            continue
        if name.startswith("test_") or name.startswith("Test"):
            continue
        if name not in all_references:
            unused_functions += 1
            findings.append(Finding(
                severity="info",
                message=f"Function '{name}' is never referenced — heuristic detection - verify manually",
                location=location,
            ))

    for _mod_key, name, location in defined_classes:
        if name in _ALWAYS_LIVE:
            continue
        if name.startswith("Test"):
            continue
        if name not in all_references:
            findings.append(Finding(
                severity="info",
                message=f"Class '{name}' is never referenced — heuristic detection - verify manually",
                location=location,
            ))

    # -----------------------------------------------------------------------
    # Step 3: files that are never imported by any other internal module
    # -----------------------------------------------------------------------
    graph = build_import_graph(index)
    unreferenced_files = 0

    for module_key in sorted(index.modules):
        if graph.in_degree(module_key) == 0:
            # Not imported by anyone — skip obvious entry points
            mod_name = module_key.split(".")[-1]
            if mod_name in ("__init__", "__main__", "cli", "main", "conftest"):
                continue
            # Skip test files
            if mod_name.startswith("test_") or "test" in module_key.split(".")[0]:
                continue
            unreferenced_files += 1
            try:
                rel = str(index.modules[module_key].path.relative_to(index.root_path))
            except ValueError:
                rel = module_key
            findings.append(Finding(
                severity="info",
                message=(
                    f"File is not imported by any other module — "
                    "heuristic detection - verify manually"
                ),
                location=rel,
            ))

    return AnalysisResult(
        analyzer_name="Dead Code Analysis",
        findings=findings,
        summary={
            "unused_functions_count": unused_functions,
            "unreferenced_files_count": unreferenced_files,
        },
    )
