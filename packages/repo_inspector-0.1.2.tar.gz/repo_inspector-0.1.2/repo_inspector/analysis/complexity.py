from __future__ import annotations

from pathlib import Path

from radon.complexity import cc_visit

from repo_inspector.utils.ast_parser import (
    AnalysisResult,
    Finding,
    ProjectIndex,
)

_CC_WARNING = 10
_CC_CRITICAL = 20
_FUNC_WARNING_LINES = 50
_FUNC_CRITICAL_LINES = 80
_FILE_WARNING_LINES = 500
_FILE_CRITICAL_LINES = 1000


def _cc_for_file(path: Path) -> dict[str, int]:
    """Return {function_name: complexity} for a single file via radon."""
    try:
        source = path.read_text(encoding="utf-8", errors="replace")
        return {block.name: block.complexity for block in cc_visit(source)}
    except Exception:
        return {}


def analyze(index: ProjectIndex) -> AnalysisResult:
    findings: list[Finding] = []
    all_complexities: list[int] = []

    for module_key, module in index.modules.items():
        rel = str(module.path.relative_to(index.root_path))

        # --- God Object (file size) ---
        if module.lines >= _FILE_CRITICAL_LINES:
            findings.append(Finding(
                severity="critical",
                message=f"File has {module.lines} lines (God Object)",
                location=rel,
            ))
        elif module.lines >= _FILE_WARNING_LINES:
            findings.append(Finding(
                severity="warning",
                message=f"File has {module.lines} lines (large file)",
                location=rel,
            ))

        # Complexity map for this file
        cc_map = _cc_for_file(module.path)

        for fn in module.functions:
            fn_loc = f"{rel}:{fn.name}"
            fn_lines = fn.end_line - fn.start_line + 1

            # --- Function size ---
            if fn_lines >= _FUNC_CRITICAL_LINES:
                findings.append(Finding(
                    severity="critical",
                    message=f"Function is {fn_lines} lines long",
                    location=fn_loc,
                ))
            elif fn_lines >= _FUNC_WARNING_LINES:
                findings.append(Finding(
                    severity="warning",
                    message=f"Function is {fn_lines} lines long",
                    location=fn_loc,
                ))

            # --- Cyclomatic complexity ---
            cc = cc_map.get(fn.name, 1)
            all_complexities.append(cc)

            if cc >= _CC_CRITICAL:
                findings.append(Finding(
                    severity="critical",
                    message=f"Cyclomatic complexity is {cc}",
                    location=fn_loc,
                ))
            elif cc >= _CC_WARNING:
                findings.append(Finding(
                    severity="warning",
                    message=f"Cyclomatic complexity is {cc}",
                    location=fn_loc,
                ))

    if all_complexities:
        max_cc = max(all_complexities)
        avg_cc = round(sum(all_complexities) / len(all_complexities), 2)
        above_warning = sum(1 for c in all_complexities if c >= _CC_WARNING)
        above_critical = sum(1 for c in all_complexities if c >= _CC_CRITICAL)
    else:
        max_cc = avg_cc = above_warning = above_critical = 0

    return AnalysisResult(
        analyzer_name="Complexity Analysis",
        findings=findings,
        summary={
            "max_complexity": max_cc,
            "avg_complexity": avg_cc,
            "functions_above_warning": above_warning,
            "functions_above_critical": above_critical,
        },
    )
