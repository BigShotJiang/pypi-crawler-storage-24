from __future__ import annotations

from repo_inspector.utils.ast_parser import AnalysisResult, Finding, ProjectIndex
from repo_inspector.utils.graph_builder import build_import_graph

_COUPLING_WARNING = 10
_COUPLING_CRITICAL = 20


def analyze(index: ProjectIndex) -> AnalysisResult:
    graph = build_import_graph(index)

    findings: list[Finding] = []
    scores: list[int] = []
    most_coupled_module = ""
    max_score = -1

    for module in sorted(graph.nodes):
        fan_out = graph.out_degree(module)
        fan_in = graph.in_degree(module)
        score = fan_in + fan_out
        scores.append(score)

        if score > max_score:
            max_score = score
            most_coupled_module = module

        if score >= _COUPLING_CRITICAL:
            findings.append(Finding(
                severity="critical",
                message=(
                    f"Coupling score {score} "
                    f"(fan-in={fan_in}, fan-out={fan_out})"
                ),
                location=module,
            ))
        elif score >= _COUPLING_WARNING:
            findings.append(Finding(
                severity="warning",
                message=(
                    f"Coupling score {score} "
                    f"(fan-in={fan_in}, fan-out={fan_out})"
                ),
                location=module,
            ))

    avg_score = round(sum(scores) / len(scores), 2) if scores else 0
    modules_above_warning = sum(1 for s in scores if s >= _COUPLING_WARNING)

    return AnalysisResult(
        analyzer_name="Coupling Analysis",
        findings=findings,
        summary={
            "most_coupled_module": most_coupled_module,
            "avg_coupling_score": avg_score,
            "modules_above_warning": modules_above_warning,
        },
    )
