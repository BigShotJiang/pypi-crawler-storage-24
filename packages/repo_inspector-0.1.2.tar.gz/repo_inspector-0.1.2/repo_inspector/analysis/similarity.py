from __future__ import annotations

import ast
import copy
import hashlib
from collections import defaultdict
from pathlib import Path

from repo_inspector.utils.ast_parser import AnalysisResult, Finding, ProjectIndex


class _Normalizer(ast.NodeTransformer):
    """Replace all Name ids and arg names with a fixed placeholder."""

    _PLACEHOLDER = "_"

    def visit_Name(self, node: ast.Name) -> ast.Name:
        return ast.Name(id=self._PLACEHOLDER, ctx=node.ctx)

    def visit_arg(self, node: ast.arg) -> ast.arg:
        node = copy.copy(node)
        node.arg = self._PLACEHOLDER
        node.annotation = None
        return node

    def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.FunctionDef:
        # Strip the function name and decorators; recurse into body
        node = copy.copy(node)
        node.name = self._PLACEHOLDER
        node.decorator_list = []
        node.returns = None
        self.generic_visit(node)
        return node

    visit_AsyncFunctionDef = visit_FunctionDef  # type: ignore[assignment]

    def visit_Constant(self, node: ast.Constant) -> ast.Constant:
        # Normalise all constants to a single placeholder value
        return ast.Constant(value=self._PLACEHOLDER)


_normalizer = _Normalizer()


def _function_hash(func_node: ast.FunctionDef | ast.AsyncFunctionDef) -> str:
    """Return an MD5 hash of the normalised AST dump of a function body."""
    cloned = copy.deepcopy(func_node)
    normalised = _normalizer.visit(cloned)
    dump = ast.dump(normalised)
    return hashlib.md5(dump.encode()).hexdigest()


def _parse_source(path: Path) -> ast.Module | None:
    try:
        return ast.parse(path.read_text(encoding="utf-8", errors="replace"),
                         filename=str(path))
    except SyntaxError:
        return None


def analyze(index: ProjectIndex) -> AnalysisResult:
    # Map hash → list of (location_str, function_name)
    hash_to_locations: dict[str, list[tuple[str, str]]] = defaultdict(list)

    for module in index.modules.values():
        tree = _parse_source(module.path)
        if tree is None:
            continue

        try:
            rel = str(module.path.relative_to(index.root_path))
        except ValueError:
            rel = str(module.path)

        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                # Skip trivial bodies: just a pass, ellipsis, or single docstring
                body = node.body
                if len(body) == 1 and isinstance(body[0], (ast.Pass, ast.Expr)):
                    if isinstance(body[0], ast.Expr) and isinstance(
                        body[0].value, ast.Constant
                    ):
                        continue  # docstring-only
                    if isinstance(body[0], ast.Pass):
                        continue

                h = _function_hash(node)
                location = f"{rel}:{node.lineno}"
                hash_to_locations[h].append((location, node.name))

    findings: list[Finding] = []
    duplicate_groups = 0
    total_duplicate_functions = 0

    for locations in hash_to_locations.values():
        if len(locations) < 2:
            continue
        duplicate_groups += 1
        total_duplicate_functions += len(locations)
        locs_str = ", ".join(f"{loc} ({name})" for loc, name in locations)
        findings.append(Finding(
            severity="warning",
            message=f"Duplicate function body detected in {len(locations)} places: {locs_str}",
            location=None,
        ))

    return AnalysisResult(
        analyzer_name="Duplication Analysis",
        findings=findings,
        summary={
            "duplicate_groups_found": duplicate_groups,
            "total_duplicate_functions": total_duplicate_functions,
        },
    )
