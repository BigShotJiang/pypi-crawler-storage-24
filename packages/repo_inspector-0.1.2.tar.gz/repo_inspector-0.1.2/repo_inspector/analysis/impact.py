from __future__ import annotations

from pathlib import Path

import networkx as nx

from repo_inspector.utils.ast_parser import AnalysisResult, Finding, ProjectIndex
from repo_inspector.utils.graph_builder import build_import_graph


def _file_to_module_key(target_file: str, index: ProjectIndex) -> str | None:
    """
    Resolve a target_file string (relative or absolute path) to a module key
    present in the ProjectIndex.
    """
    # Normalise to an absolute path
    target = Path(target_file)
    if not target.is_absolute():
        target = (index.root_path / target).resolve()
    else:
        target = target.resolve()

    for key, module in index.modules.items():
        if module.path.resolve() == target:
            return key
    return None


def analyze(index: ProjectIndex, target_file: str) -> AnalysisResult:
    graph = build_import_graph(index)
    reversed_graph = graph.reverse(copy=True)

    target_key = _file_to_module_key(target_file, index)

    if target_key is None or target_key not in reversed_graph:
        # Unknown target — return an empty result with a note in the summary
        return AnalysisResult(
            analyzer_name="Impact Analysis",
            findings=[],
            summary={
                "target_file": target_file,
                "affected_modules_count": 0,
                "affected_modules": [],
                "error": f"Module '{target_file}' not found in project index",
            },
        )

    # BFS from target_key in the reversed graph
    affected: list[str] = []
    for node in nx.bfs_tree(reversed_graph, target_key).nodes:
        if node != target_key:
            affected.append(node)

    affected.sort()

    findings: list[Finding] = [
        Finding(
            severity="info",
            message=f"Module '{mod}' imports (directly or transitively) '{target_key}'",
            location=mod,
        )
        for mod in affected
    ]

    return AnalysisResult(
        analyzer_name="Impact Analysis",
        findings=findings,
        summary={
            "target_file": target_file,
            "affected_modules_count": len(affected),
            "affected_modules": affected,
        },
    )
