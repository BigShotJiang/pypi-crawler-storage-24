from __future__ import annotations

import networkx as nx
from rich.console import Console
from rich.tree import Tree

from repo_inspector.utils.ast_parser import AnalysisResult, Finding, ProjectIndex
from repo_inspector.utils.graph_builder import build_import_graph

_console = Console()


def _render_import_tree(graph: nx.DiGraph) -> None:
    """Print the import graph as a Rich tree rooted at each node with outgoing edges."""
    # Only show nodes that have at least one edge (either direction)
    connected = {n for n, d in graph.degree() if d > 0}
    if not connected:
        _console.print("  [dim]No internal imports found.[/dim]")
        return

    # Sort for deterministic output; show each root (no incoming internal edges) as a tree
    roots = sorted(n for n in connected if graph.in_degree(n) == 0)
    # Fall back: if everything is in cycles, just use all connected nodes
    if not roots:
        roots = sorted(connected)

    printed: set[str] = set()

    def _add_children(tree_node: Tree, module: str, visited: set[str]) -> None:
        for child in sorted(graph.successors(module)):
            label = child if child not in visited else f"[dim]{child} (cycle)[/dim]"
            branch = tree_node.add(label)
            if child not in visited:
                _add_children(branch, child, visited | {child})

    for root in roots:
        if root in printed:
            continue
        tree = Tree(f"[bold cyan]{root}[/bold cyan]")
        _add_children(tree, root, {root})
        _console.print(tree)
        printed.add(root)


def analyze(index: ProjectIndex, render_tree: bool = False) -> AnalysisResult:
    graph = build_import_graph(index)

    cycles = list(nx.simple_cycles(graph))

    findings: list[Finding] = []
    for cycle in cycles:
        cycle_str = " → ".join(cycle + [cycle[0]])
        findings.append(Finding(
            severity="critical",
            message=f"Circular dependency: {cycle_str}",
            location=None,
        ))

    if render_tree:
        _render_import_tree(graph)

    return AnalysisResult(
        analyzer_name="Import Analysis",
        findings=findings,
        summary={
            "total_modules": graph.number_of_nodes(),
            "total_edges": graph.number_of_edges(),
            "circular_cycles_found": len(cycles),
        },
    )
