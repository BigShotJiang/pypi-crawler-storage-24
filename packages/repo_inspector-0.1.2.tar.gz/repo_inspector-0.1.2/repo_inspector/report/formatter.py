from __future__ import annotations

from pathlib import Path

from rich.console import Console
from rich.panel import Panel
from rich.rule import Rule
from rich.table import Table
from rich.text import Text

from repo_inspector.utils.ast_parser import AnalysisResult, ProjectIndex

console = Console()

_SEVERITY_STYLE = {
    "critical": "bold red",
    "warning": "yellow",
    "info": "bold blue",
}

_SEVERITY_LABEL = {
    "critical": "CRITICAL",
    "warning": "WARNING ",
    "info": "INFO    ",
}


def print_section_header(title: str) -> None:
    console.print()
    console.print(Rule(f"[bold]{title}[/bold]", style="dim"))


def print_project_summary(index: ProjectIndex) -> None:
    print_section_header("Project Summary")

    total_functions = sum(len(m.functions) for m in index.modules.values())
    total_classes = sum(len(m.classes) for m in index.modules.values())

    table = Table(show_header=True, header_style="bold cyan", box=None, padding=(0, 2))
    table.add_column("Metric", style="dim", no_wrap=True)
    table.add_column("Value", justify="right")

    table.add_row("Root path", str(index.root_path))
    table.add_row("Total files", str(len(index.all_files)))
    table.add_row("Python files", str(len(index.python_files)))
    table.add_row("Lines of code", f"{index.total_lines:,}")
    table.add_row("Functions", str(total_functions))
    table.add_row("Classes", str(total_classes))

    console.print(table)


def print_findings(result: AnalysisResult) -> None:
    print_section_header(result.analyzer_name)

    if not result.findings:
        console.print("  [dim]No findings.[/dim]")
        return

    # Group by severity for display order: critical → warning → info
    grouped: dict[str, list] = {"critical": [], "warning": [], "info": []}
    for finding in result.findings:
        grouped.setdefault(finding.severity, []).append(finding)

    for severity in ("critical", "warning", "info"):
        items = grouped.get(severity, [])
        if not items:
            continue

        style = _SEVERITY_STYLE[severity]
        label = _SEVERITY_LABEL[severity]

        for finding in items:
            line = Text()
            line.append(f"  [{label}]  ", style=style)
            if finding.location:
                line.append(finding.location, style="dim")
                line.append("  ")
            line.append(finding.message)
            console.print(line)

    # Summary block if present
    if result.summary:
        console.print()
        summary_table = Table(show_header=False, box=None, padding=(0, 2))
        summary_table.add_column(style="dim")
        summary_table.add_column(justify="right")
        for key, value in result.summary.items():
            summary_table.add_row(key, str(value))
        console.print(summary_table)


def print_scan_summary(
    index: ProjectIndex,
    results: dict[str, AnalysisResult],
    health_score: float | None = None,
) -> None:
    """Render the unified Project Analysis Summary for `scan`."""
    print_section_header("Project Analysis Summary")

    total_functions = sum(len(m.functions) for m in index.modules.values())
    total_classes = sum(len(m.classes) for m in index.modules.values())

    # ── Project stats ──────────────────────────────────────────────────────
    stats = Table(show_header=False, box=None, padding=(0, 3))
    stats.add_column(style="dim", no_wrap=True)
    stats.add_column(justify="right")
    stats.add_row("Root path", str(index.root_path))
    stats.add_row("Total files", str(len(index.all_files)))
    stats.add_row("Python files", str(len(index.python_files)))
    stats.add_row("Lines of code", f"{index.total_lines:,}")
    stats.add_row("Functions", str(total_functions))
    stats.add_row("Classes", str(total_classes))
    console.print(stats)
    console.print()

    # ── Per-analyzer finding counts ────────────────────────────────────────
    tbl = Table(show_header=True, header_style="bold", box=None, padding=(0, 2))
    tbl.add_column("Analyzer", style="bold", no_wrap=True)
    tbl.add_column("Critical", justify="right", style="bold red")
    tbl.add_column("Warning",  justify="right", style="yellow")
    tbl.add_column("Info",     justify="right", style="bold blue")

    for result in results.values():
        counts = {"critical": 0, "warning": 0, "info": 0}
        for f in result.findings:
            counts[f.severity] = counts.get(f.severity, 0) + 1
        tbl.add_row(
            result.analyzer_name,
            str(counts["critical"]) if counts["critical"] else "[dim]0[/dim]",
            str(counts["warning"])  if counts["warning"]  else "[dim]0[/dim]",
            str(counts["info"])     if counts["info"]     else "[dim]0[/dim]",
        )

    console.print(tbl)

    # ── Health score bar ───────────────────────────────────────────────────
    if health_score is not None:
        console.print()
        filled = int(round(health_score))
        bar = "█" * filled + "░" * (10 - filled)
        if health_score >= 7.0:
            score_style = "bold green"
        elif health_score >= 4.0:
            score_style = "bold yellow"
        else:
            score_style = "bold red"

        score_line = Text()
        score_line.append("  Health Score  ", style="dim")
        score_line.append(bar, style=score_style)
        score_line.append(f"  {health_score}/10", style=score_style)
        console.print(score_line)


def print_file_list(python_files: list[Path], root: Path) -> None:
    print_section_header("Python Files")
    for path in sorted(python_files):
        try:
            rel = path.relative_to(root)
        except ValueError:
            rel = path
        console.print(f"  [dim]{rel}[/dim]")
