"""Runtime switch control, probes, and telemetry for qpatch.

Provides auto-detection of which patches are needed, runtime
enable/disable, and hit-count telemetry showing which patches
actually intercepted issues during training.
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any

logger = logging.getLogger("qpatch")


# ═══════════════════════════════════════════════════════════════════
# Probes — detect whether each bug exists in the current environment
# ═══════════════════════════════════════════════════════════════════


def _probe_safetensors_metadata() -> bool:
    """True if transformers + safetensors are installed (bug could manifest)."""
    try:
        import safetensors  # noqa: F401
        import transformers.modeling_utils  # noqa: F401

        return True
    except ImportError:
        return False


def _probe_lora_dtype_cast() -> bool:
    """True if peft's Linear4bit exists (bug could manifest)."""
    try:
        import peft.tuners.lora.bnb as lora_bnb

        return hasattr(lora_bnb, "Linear4bit")
    except ImportError:
        return False


def _probe_moe_dtype_mismatch() -> bool:
    """True if index_add_ raises on mismatched dtypes (bug exists)."""
    import torch

    try:
        t = torch.zeros(2, 2, dtype=torch.float16)
        s = torch.ones(2, 2, dtype=torch.float32)
        t.index_add_(0, torch.tensor([0, 1]), s)
        return False  # PyTorch handles it natively
    except RuntimeError:
        return True


def _probe_fused_kernel_bypass() -> bool:
    """True if any cached model files contain the fused kernel pattern."""
    import glob
    import os

    pattern = "if self.training and cache_params is None:"
    for base in ["~/.cache/huggingface/modules", "~/.cache/huggingface/hub"]:
        d = os.path.expanduser(base)
        if not os.path.exists(d):
            continue
        for path in glob.glob(os.path.join(d, "**", "modeling_*.py"), recursive=True):
            try:
                with open(path, encoding="utf-8") as f:
                    if pattern in f.read():
                        return True
            except (OSError, UnicodeDecodeError):
                continue
    return False


_probes: dict[str, Any] = {
    "safetensors_metadata": _probe_safetensors_metadata,
    "lora_dtype_cast": _probe_lora_dtype_cast,
    "moe_dtype_mismatch": _probe_moe_dtype_mismatch,
    "fused_kernel_bypass": _probe_fused_kernel_bypass,
}


# ═══════════════════════════════════════════════════════════════════
# Telemetry and status
# ═══════════════════════════════════════════════════════════════════


def report() -> dict[str, dict[str, Any]]:
    """Return telemetry for all patches.

    Returns:
        Dict mapping patch name to ``{"active": bool, "hits": int,
        "last_hit": float | None}`` where ``last_hit`` is a Unix
        timestamp or None.
    """
    from qpatch.patches import PATCH_NAMES, _applied, _telemetry

    result = {}
    for name in PATCH_NAMES:
        tel = _telemetry.get(name, {"hits": 0, "last_hit": None})
        result[name] = {
            "active": name in _applied,
            "hits": tel["hits"],
            "last_hit": tel["last_hit"],
        }
    return result


def status() -> None:
    """Print a formatted table of patch status to stdout."""
    import qpatch

    data = report()
    print(f"qpatch v{qpatch.__version__}")
    print(f"{'Patch':<28} {'Active':>8} {'Hits':>8} {'Last Hit':>20}")
    print("-" * 68)
    for name, info in data.items():
        active = "ON" if info["active"] else "OFF"
        if info["last_hit"] is not None:
            dt = datetime.fromtimestamp(info["last_hit"], tz=timezone.utc)
            last = dt.strftime("%H:%M:%S UTC")
        else:
            last = "-"
        print(f"{name:<28} {active:>8} {info['hits']:>8} {last:>20}")


# ═══════════════════════════════════════════════════════════════════
# Runtime enable / disable
# ═══════════════════════════════════════════════════════════════════


def disable(name: str) -> None:
    """Disable a patch at runtime by restoring the original function.

    Warning: Disabling patches during active training may cause
    immediate errors if the patched bug is encountered.

    The ``fused_kernel_bypass`` patch modifies files on disk and
    cannot be reversed at runtime.
    """
    from qpatch.patches import _applied, _originals

    if name not in _applied:
        logger.warning("Patch '%s' is not active", name)
        return

    orig = _originals.get(name)
    if orig is None:
        logger.warning(
            "Cannot disable '%s' — file-based patch, changes are permanent "
            "until HuggingFace cache is cleared",
            name,
        )
        return

    target_obj, attr_name, original_fn = orig
    setattr(target_obj, attr_name, original_fn)
    _applied.discard(name)
    logger.info("qpatch: disabled '%s'", name)


def enable(name: str) -> None:
    """Re-enable a previously disabled patch."""
    from qpatch.patches import (
        PATCH_NAMES,
        _applied,
        patch_fused_kernel_bypass,
        patch_lora_dtype_cast,
        patch_moe_dtype_mismatch,
        patch_safetensors_metadata,
    )

    if name not in PATCH_NAMES:
        raise ValueError(f"Unknown patch: {name!r}. Valid: {PATCH_NAMES}")

    if name in _applied:
        logger.info("Patch '%s' is already active", name)
        return

    _fns: dict[str, Any] = {
        "safetensors_metadata": patch_safetensors_metadata,
        "lora_dtype_cast": patch_lora_dtype_cast,
        "moe_dtype_mismatch": patch_moe_dtype_mismatch,
        "fused_kernel_bypass": patch_fused_kernel_bypass,
    }
    _fns[name]()
