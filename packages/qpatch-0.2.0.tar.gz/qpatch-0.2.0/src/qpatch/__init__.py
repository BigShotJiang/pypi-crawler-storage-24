"""qpatch: Automatic fixes for quantized model fine-tuning.

Patches known incompatibilities when training 4-bit/8-bit quantized models
with LoRA adapters, especially on custom architectures (Mamba, MoE, RWKV, etc.).

Usage:
    import qpatch
    qpatch.patch_all()

    # Then load and train as normal — issues are handled automatically
    model = AutoModelForCausalLM.from_pretrained(..., load_in_4bit=True)
    model = get_peft_model(model, lora_config)
    trainer.train()  # Just works

v0.2 adds runtime switch control:
    qpatch.patch_all(auto=True)   # Only apply needed patches
    qpatch.status()               # Show what's active and hit counts
    qpatch.disable("moe_dtype_mismatch")  # Turn off at runtime
    qpatch.report()               # Get telemetry dict
"""

__version__ = "0.2.0"

from qpatch.patches import (
    patch_all,
    patch_fused_kernel_bypass,
    patch_lora_dtype_cast,
    patch_moe_dtype_mismatch,
    patch_safetensors_metadata,
)
from qpatch.switch import disable, enable, report, status

__all__ = [
    "patch_all",
    "patch_safetensors_metadata",
    "patch_lora_dtype_cast",
    "patch_moe_dtype_mismatch",
    "patch_fused_kernel_bypass",
    "status",
    "report",
    "enable",
    "disable",
]
