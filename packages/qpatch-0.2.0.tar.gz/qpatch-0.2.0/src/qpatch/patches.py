"""Core patches for quantized model fine-tuning.

Each patch targets a specific failure mode encountered when combining
4-bit/8-bit quantization with LoRA adapters on custom architectures.

All patches are idempotent — calling them multiple times is safe.
"""

from __future__ import annotations

import logging
import time
from typing import Any

import torch

logger = logging.getLogger("qpatch")

_applied: set[str] = set()
_telemetry: dict[str, dict[str, Any]] = {}
_originals: dict[str, tuple[Any, str, Any] | None] = {}

PATCH_NAMES = (
    "safetensors_metadata",
    "lora_dtype_cast",
    "moe_dtype_mismatch",
    "fused_kernel_bypass",
)


def _mark(name: str) -> bool:
    """Mark a patch as applied. Returns True if already applied."""
    if name in _applied:
        logger.debug("Patch '%s' already applied, skipping", name)
        return True
    _applied.add(name)
    return False


def _record_hit(name: str) -> None:
    """Record that a patch intercepted and fixed an issue at runtime."""
    entry = _telemetry.setdefault(name, {"hits": 0, "last_hit": None})
    entry["hits"] += 1
    entry["last_hit"] = time.time()


# ═══════════════════════════════════════════════════════════════════
# Patch 1: Safetensors metadata bug
# ═══════════════════════════════════════════════════════════════════


def patch_safetensors_metadata() -> None:
    """Fix safetensors files with None metadata.

    Some model checkpoints (e.g., Nemotron, certain HuggingFace uploads)
    have safetensors files where ``metadata()`` returns None instead of
    a dict. Transformers' ``load_state_dict`` calls ``metadata.get("format")``
    which raises ``AttributeError: 'NoneType' object has no attribute 'get'``.

    This patch intercepts the load and falls back to ``load_file()`` when
    metadata is None.
    """
    if _mark("safetensors_metadata"):
        return

    try:
        import transformers.modeling_utils as mu
    except ImportError:
        logger.warning("transformers not installed, skipping safetensors patch")
        return

    original = mu.load_state_dict
    _originals["safetensors_metadata"] = (mu, "load_state_dict", original)

    def patched(checkpoint_file: str, *args: Any, **kwargs: Any) -> dict:
        if str(checkpoint_file).endswith(".safetensors"):
            try:
                from safetensors import safe_open
                from safetensors.torch import load_file

                with safe_open(checkpoint_file, framework="pt") as f:
                    metadata = f.metadata()
                if metadata is None:
                    _record_hit("safetensors_metadata")
                    logger.info("qpatch: safetensors metadata is None, using load_file fallback")
                    return load_file(checkpoint_file)
            except ImportError:
                pass
        return original(checkpoint_file, *args, **kwargs)

    mu.load_state_dict = patched
    logger.info("qpatch: patched safetensors metadata handling")


# ═══════════════════════════════════════════════════════════════════
# Patch 2: LoRA dtype cast for quantized inputs
# ═══════════════════════════════════════════════════════════════════


def patch_lora_dtype_cast(compute_dtype: torch.dtype = torch.float16) -> None:
    """Fix LoRA forward pass receiving uint8 inputs from quantized layers.

    When a base model layer is 4-bit quantized, its output may be uint8.
    The LoRA adapter's Linear layers expect float inputs. Without this
    patch, you get:
        ``RuntimeError: expected mat1 and mat2 to have the same dtype,
        but got: unsigned char != c10::Half``
    or:
        ``RuntimeError: "fused_dropout" not implemented for 'Byte'``

    This patch auto-casts uint8 inputs to the compute dtype before the
    LoRA forward pass.
    """
    if _mark("lora_dtype_cast"):
        return

    try:
        import peft.tuners.lora.bnb as lora_bnb
    except ImportError:
        logger.warning("peft not installed, skipping LoRA dtype patch")
        return

    if not hasattr(lora_bnb, "Linear4bit"):
        logger.debug("peft.tuners.lora.bnb.Linear4bit not found, skipping")
        return

    original = lora_bnb.Linear4bit.forward
    _originals["lora_dtype_cast"] = (lora_bnb.Linear4bit, "forward", original)

    def patched(self: Any, x: torch.Tensor, *args: Any, **kwargs: Any) -> torch.Tensor:
        if x.dtype == torch.uint8:
            _record_hit("lora_dtype_cast")
            x = x.to(compute_dtype)
        return original(self, x, *args, **kwargs)

    lora_bnb.Linear4bit.forward = patched
    logger.info("qpatch: patched LoRA Linear4bit dtype casting (-> %s)", compute_dtype)


# ═══════════════════════════════════════════════════════════════════
# Patch 3: MoE index_add_ dtype mismatch
# ═══════════════════════════════════════════════════════════════════


def patch_moe_dtype_mismatch() -> None:
    """Fix dtype mismatch in Mixture-of-Experts layers.

    MoE architectures use ``index_add_`` to scatter expert outputs back
    into the hidden state tensor. Under mixed precision, the expert output
    (float32 from autocast) may not match the hidden state (bfloat16/float16),
    causing:
        ``RuntimeError: index_add_(): self (BFloat16) and source (Float)
        must have the same scalar type``

    This patch wraps ``torch.Tensor.index_add_`` to auto-cast the source
    tensor when dtypes mismatch.
    """
    if _mark("moe_dtype_mismatch"):
        return

    original = torch.Tensor.index_add_
    _originals["moe_dtype_mismatch"] = (torch.Tensor, "index_add_", original)

    def patched(
        self: torch.Tensor, dim: int, index: torch.Tensor, source: torch.Tensor, **kwargs: Any
    ) -> torch.Tensor:
        if source.dtype != self.dtype:
            _record_hit("moe_dtype_mismatch")
            source = source.to(self.dtype)
        return original(self, dim, index, source, **kwargs)

    torch.Tensor.index_add_ = patched
    logger.info("qpatch: patched index_add_ dtype auto-casting for MoE layers")


# ═══════════════════════════════════════════════════════════════════
# Patch 4: Fused kernel bypass for quantized models
# ═══════════════════════════════════════════════════════════════════


def patch_fused_kernel_bypass() -> None:
    """Bypass fused CUDA kernels that are incompatible with quantized weights.

    Models with custom fused kernels (e.g., Mamba's ``mamba_split_conv1d_scan_combined``,
    fused attention) pass weight tensors directly to CUDA ops. When those weights
    are 4-bit quantized (stored as packed uint8), the fused kernel receives a
    shape like ``(1, 5505024)`` instead of ``(1344, 4096)``, causing:
        ``RuntimeError: mat1 and mat2 shapes cannot be multiplied``

    This patch scans HuggingFace's cached model code for the fused-path
    condition ``if self.training and cache_params is None:`` and replaces it
    with ``if False:`` to force the non-fused (but quantization-safe) code path.

    Note: This reduces training throughput (~20-30% slower) but is the only
    way to train quantized Mamba/hybrid models without rewriting the kernels.
    """
    if _mark("fused_kernel_bypass"):
        return

    _originals["fused_kernel_bypass"] = None  # file-based, not reversible

    import glob
    import os

    cache_dirs = [
        os.path.expanduser("~/.cache/huggingface/modules"),
        os.path.expanduser("~/.cache/huggingface/hub"),
    ]

    old = "if self.training and cache_params is None:"
    new = "if False:  # qpatch: bypass fused kernels for quantized weights"

    patched_count = 0
    for cache_dir in cache_dirs:
        if not os.path.exists(cache_dir):
            continue
        for path in glob.glob(os.path.join(cache_dir, "**", "modeling_*.py"), recursive=True):
            try:
                with open(path, encoding="utf-8") as f:
                    content = f.read()
                if old in content:
                    content = content.replace(old, new)
                    with open(path, "w", encoding="utf-8") as f:
                        f.write(content)
                    patched_count += 1
                    _record_hit("fused_kernel_bypass")
                    logger.info("qpatch: bypassed fused kernels in %s", path)

                    # Clear __pycache__
                    pycache = os.path.join(os.path.dirname(path), "__pycache__")
                    if os.path.exists(pycache):
                        import shutil

                        shutil.rmtree(pycache)
            except (OSError, UnicodeDecodeError):
                continue

    if patched_count:
        logger.info("qpatch: bypassed fused kernels in %d model file(s)", patched_count)
    else:
        logger.debug("qpatch: no fused kernel paths found to bypass")


# ═══════════════════════════════════════════════════════════════════
# Convenience: apply all patches
# ═══════════════════════════════════════════════════════════════════


def patch_all(
    compute_dtype: torch.dtype = torch.float16,
    auto: bool = False,
) -> None:
    """Apply all qpatch fixes.

    Call this once before loading your quantized model. All patches
    are idempotent — calling multiple times is safe.

    Args:
        compute_dtype: dtype to cast uint8 quantized tensors to.
            Use ``torch.float16`` for Volta/Ampere or ``torch.bfloat16``
            for Ampere+ GPUs.
        auto: If True, probe each bug before patching and skip patches
            that aren't needed in the current environment.

    Example::

        import qpatch
        qpatch.patch_all()

        model = AutoModelForCausalLM.from_pretrained(
            "nvidia/Nemotron-3-Nano-30B", load_in_4bit=True, device_map="auto"
        )
        model = get_peft_model(model, lora_config)
        trainer.train()  # Just works
    """
    if auto:
        from qpatch.switch import _probes

    _patches = [
        ("safetensors_metadata", patch_safetensors_metadata, {}),
        ("lora_dtype_cast", patch_lora_dtype_cast, {"compute_dtype": compute_dtype}),
        ("moe_dtype_mismatch", patch_moe_dtype_mismatch, {}),
        ("fused_kernel_bypass", patch_fused_kernel_bypass, {}),
    ]

    for name, fn, kwargs in _patches:
        if auto:
            probe = _probes.get(name)
            if probe and not probe():
                logger.info("qpatch: skipping '%s' (probe: not needed)", name)
                continue
        fn(**kwargs)

    logger.info("qpatch: all patches applied")
