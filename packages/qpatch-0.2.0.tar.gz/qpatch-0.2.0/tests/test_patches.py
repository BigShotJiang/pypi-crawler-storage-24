"""Tests for qpatch — all run without GPU or model downloads."""

from __future__ import annotations

import os
import sys
from unittest.mock import patch

import pytest
import torch

import qpatch
import qpatch.patches as _pm


@pytest.fixture(autouse=True)
def reset_patches():
    """Reset patch tracking between tests."""
    _pm._applied.clear()
    _pm._telemetry.clear()
    _pm._originals.clear()
    yield
    _pm._applied.clear()
    _pm._telemetry.clear()
    _pm._originals.clear()


def applied():
    """Return current applied set (always from the module, not a stale ref)."""
    return _pm._applied


# ═══════════════════════════════════════════════════════════════
# patch_all
# ═══════════════════════════════════════════════════════════════


class TestPatchAll:
    def test_patch_all_runs_without_error(self):
        qpatch.patch_all()

    def test_patch_all_idempotent(self):
        qpatch.patch_all()
        qpatch.patch_all()
        assert len(applied()) == 4

    def test_patch_all_accepts_compute_dtype(self):
        qpatch.patch_all(compute_dtype=torch.bfloat16)

    def test_version_exists(self):
        assert hasattr(qpatch, "__version__")
        assert isinstance(qpatch.__version__, str)

    def test_all_exports(self):
        for name in qpatch.__all__:
            assert hasattr(qpatch, name)


# ═══════════════════════════════════════════════════════════════
# patch_safetensors_metadata
# ═══════════════════════════════════════════════════════════════


class TestSafetensorsMetadata:
    def test_patch_applies(self):
        qpatch.patch_safetensors_metadata()
        assert "safetensors_metadata" in applied()

    def test_idempotent(self):
        qpatch.patch_safetensors_metadata()
        qpatch.patch_safetensors_metadata()
        assert "safetensors_metadata" in applied()

    def test_wraps_load_state_dict(self):
        """Patched load_state_dict should be a different function."""
        import transformers.modeling_utils as mu

        original = mu.load_state_dict
        qpatch.patch_safetensors_metadata()
        assert mu.load_state_dict is not original

    def test_none_metadata_fallback(self, tmp_path):
        """Verify None metadata triggers load_file fallback."""
        try:
            from safetensors.torch import save_file
        except ImportError:
            pytest.skip("safetensors not installed")

        tensors = {"weight": torch.randn(4, 4)}
        path = tmp_path / "test.safetensors"
        save_file(tensors, str(path))

        qpatch.patch_safetensors_metadata()
        import transformers.modeling_utils as mu

        result = mu.load_state_dict(str(path))
        assert "weight" in result
        assert result["weight"].shape == (4, 4)

    def test_missing_transformers_graceful(self):
        """Should not crash if transformers is missing."""
        with patch.dict(sys.modules, {"transformers.modeling_utils": None}):
            _pm._applied.clear()
            qpatch.patch_safetensors_metadata()
            assert "safetensors_metadata" in applied()

    def test_safetensors_import_error_passthrough(self, tmp_path):
        """When safetensors can't be imported, fall through to original."""
        qpatch.patch_safetensors_metadata()
        import transformers.modeling_utils as mu

        # Create a real safetensors file
        try:
            from safetensors.torch import save_file
        except ImportError:
            pytest.skip("safetensors not installed")

        tensors = {"w": torch.randn(2, 2)}
        path = tmp_path / "model.safetensors"
        save_file(tensors, str(path))

        # Even with safetensors importable, the .safetensors path should work
        result = mu.load_state_dict(str(path))
        assert "w" in result


# ═══════════════════════════════════════════════════════════════
# patch_lora_dtype_cast
# ═══════════════════════════════════════════════════════════════


HAS_PEFT_BNB = False
try:
    import peft.tuners.lora.bnb as _lora_bnb

    HAS_PEFT_BNB = hasattr(_lora_bnb, "Linear4bit")
except ImportError:
    pass


class TestLoraDtypeCast:
    def test_patch_applies(self):
        qpatch.patch_lora_dtype_cast()
        # _mark is called before import check, so always in applied
        assert "lora_dtype_cast" in applied()

    def test_custom_compute_dtype(self):
        qpatch.patch_lora_dtype_cast(compute_dtype=torch.bfloat16)
        # Just verify no crash

    @pytest.mark.skipif(not HAS_PEFT_BNB, reason="peft[bnb] not installed")
    def test_forward_wraps_original(self):
        """Verify the forward method is replaced."""
        import peft.tuners.lora.bnb as lora_bnb

        original_forward = lora_bnb.Linear4bit.forward
        qpatch.patch_lora_dtype_cast(compute_dtype=torch.float16)
        assert lora_bnb.Linear4bit.forward is not original_forward

    def test_missing_peft_graceful(self):
        """Should not crash if peft is not installed."""
        mods = {
            "peft": None,
            "peft.tuners": None,
            "peft.tuners.lora": None,
            "peft.tuners.lora.bnb": None,
        }
        with patch.dict(sys.modules, mods):
            _pm._applied.clear()
            qpatch.patch_lora_dtype_cast()
            # _mark is called before import, so it's in applied even if peft missing
            assert "lora_dtype_cast" in applied()

    @pytest.mark.skipif(not HAS_PEFT_BNB, reason="peft[bnb] not installed")
    def test_missing_linear4bit_graceful(self):
        """Should skip if Linear4bit doesn't exist on the module."""
        import peft.tuners.lora.bnb as lora_bnb

        original = lora_bnb.Linear4bit
        try:
            delattr(lora_bnb, "Linear4bit")
            _pm._applied.clear()
            qpatch.patch_lora_dtype_cast()
            # _mark is called but the actual monkey-patch is skipped
            assert "lora_dtype_cast" in applied()
        finally:
            lora_bnb.Linear4bit = original


# ═══════════════════════════════════════════════════════════════
# patch_moe_dtype_mismatch
# ═══════════════════════════════════════════════════════════════


class TestMoeDtypeMismatch:
    def test_patch_applies(self):
        qpatch.patch_moe_dtype_mismatch()
        assert "moe_dtype_mismatch" in applied()

    def test_auto_cast_on_mismatch(self):
        """Verify index_add_ auto-casts source when dtypes differ."""
        qpatch.patch_moe_dtype_mismatch()

        target = torch.zeros(4, 8, dtype=torch.float16)
        index = torch.tensor([0, 1, 2, 3])
        source = torch.ones(4, 8, dtype=torch.float32)

        result = target.index_add_(0, index, source)
        assert result.dtype == torch.float16
        assert result.sum().item() == pytest.approx(32.0, rel=0.01)

    def test_no_cast_when_matching(self):
        """Verify no unnecessary cast when dtypes match."""
        qpatch.patch_moe_dtype_mismatch()

        target = torch.zeros(4, 8, dtype=torch.float32)
        index = torch.tensor([0, 1, 2, 3])
        source = torch.ones(4, 8, dtype=torch.float32)

        result = target.index_add_(0, index, source)
        assert result.dtype == torch.float32

    def test_bfloat16_to_float32_cast(self):
        """Verify bf16 target with f32 source works."""
        qpatch.patch_moe_dtype_mismatch()

        target = torch.zeros(2, 4, dtype=torch.bfloat16)
        index = torch.tensor([0, 1])
        source = torch.ones(2, 4, dtype=torch.float32)

        result = target.index_add_(0, index, source)
        assert result.dtype == torch.bfloat16

    def test_preserves_values(self):
        """Verify the actual values are correct after patched index_add_."""
        qpatch.patch_moe_dtype_mismatch()

        target = torch.tensor([[1.0, 2.0], [3.0, 4.0]], dtype=torch.float16)
        index = torch.tensor([1, 0])
        source = torch.tensor([[10.0, 20.0], [30.0, 40.0]], dtype=torch.float32)

        result = target.index_add_(0, index, source)
        assert result[0, 0].item() == pytest.approx(31.0, rel=0.01)
        assert result[0, 1].item() == pytest.approx(42.0, rel=0.01)
        assert result[1, 0].item() == pytest.approx(13.0, rel=0.01)
        assert result[1, 1].item() == pytest.approx(24.0, rel=0.01)

    def test_idempotent(self):
        """Applying twice should not break index_add_."""
        qpatch.patch_moe_dtype_mismatch()
        qpatch.patch_moe_dtype_mismatch()

        target = torch.zeros(2, 2, dtype=torch.float16)
        index = torch.tensor([0, 1])
        source = torch.ones(2, 2, dtype=torch.float32)

        result = target.index_add_(0, index, source)
        assert result.sum().item() == pytest.approx(4.0, rel=0.01)


# ═══════════════════════════════════════════════════════════════
# patch_fused_kernel_bypass
# ═══════════════════════════════════════════════════════════════


class TestFusedKernelBypass:
    def test_patch_applies(self):
        qpatch.patch_fused_kernel_bypass()
        assert "fused_kernel_bypass" in applied()

    def test_idempotent(self):
        qpatch.patch_fused_kernel_bypass()
        qpatch.patch_fused_kernel_bypass()
        assert "fused_kernel_bypass" in applied()

    def test_patches_matching_files(self, tmp_path, monkeypatch):
        """Verify that model files with the fused pattern are patched."""
        # Create fake HF cache structure under tmp_path/modules
        model_dir = tmp_path / "modules" / "transformers_modules" / "model"
        model_dir.mkdir(parents=True)
        model_file = model_dir / "modeling_test.py"
        model_file.write_text(
            "class TestModel:\n"
            "    def forward(self):\n"
            "        if self.training and cache_params is None:\n"
            "            return self.fused_path()\n"
            "        return self.slow_path()\n"
        )

        # Add __pycache__ to verify cleanup
        pycache = model_dir / "__pycache__"
        pycache.mkdir()
        (pycache / "modeling_test.cpython-312.pyc").write_bytes(b"fake")

        # Monkeypatch so patch scans our tmp dir
        monkeypatch.setattr(
            os.path, "expanduser",
            lambda p: str(tmp_path / "modules") if "modules" in p
            else str(tmp_path / "hub") if "hub" in p
            else p,
        )

        qpatch.patch_fused_kernel_bypass()

        patched_content = model_file.read_text()
        assert "if False:" in patched_content
        assert "if self.training and cache_params is None:" not in patched_content
        assert not pycache.exists()

    def test_no_files_to_patch(self, tmp_path, monkeypatch):
        """Verify graceful handling when no model files exist."""
        empty = tmp_path / "empty"
        empty.mkdir()
        monkeypatch.setattr(
            os.path, "expanduser",
            lambda p: str(empty),
        )
        qpatch.patch_fused_kernel_bypass()
        assert "fused_kernel_bypass" in applied()

    def test_skips_non_matching_files(self, tmp_path, monkeypatch):
        """Files without the fused pattern should be untouched."""
        model_dir = tmp_path / "modules" / "model"
        model_dir.mkdir(parents=True)
        model_file = model_dir / "modeling_clean.py"
        original_content = "class CleanModel:\n    pass\n"
        model_file.write_text(original_content)

        monkeypatch.setattr(
            os.path, "expanduser",
            lambda p: str(tmp_path / "modules"),
        )

        qpatch.patch_fused_kernel_bypass()
        assert model_file.read_text() == original_content

    def test_skips_already_patched_files(self, tmp_path, monkeypatch):
        """Files with 'if False:' already should not be modified."""
        model_dir = tmp_path / "modules" / "model"
        model_dir.mkdir(parents=True)
        model_file = model_dir / "modeling_patched.py"
        content = (
            "if False:  # qpatch: bypass fused kernels for quantized weights\n"
            "    pass\n"
        )
        model_file.write_text(content)

        monkeypatch.setattr(
            os.path, "expanduser",
            lambda p: str(tmp_path / "modules"),
        )

        qpatch.patch_fused_kernel_bypass()
        assert model_file.read_text() == content


# ═══════════════════════════════════════════════════════════════
# Internal helpers
# ═══════════════════════════════════════════════════════════════


class TestMark:
    def test_first_call_returns_false(self):
        assert _pm._mark("test_patch") is False

    def test_second_call_returns_true(self):
        _pm._mark("test_patch")
        assert _pm._mark("test_patch") is True

    def test_different_names_independent(self):
        assert _pm._mark("a") is False
        assert _pm._mark("b") is False
        assert _pm._mark("a") is True


# ═══════════════════════════════════════════════════════════════
# Integration
# ═══════════════════════════════════════════════════════════════


class TestIntegration:
    def test_all_patches_registered(self):
        """patch_all should register exactly 4 patches."""
        qpatch.patch_all()
        assert applied() == {
            "safetensors_metadata",
            "lora_dtype_cast",
            "moe_dtype_mismatch",
            "fused_kernel_bypass",
        }

    def test_individual_then_all(self):
        """Calling individuals then patch_all should not double-apply."""
        qpatch.patch_safetensors_metadata()
        qpatch.patch_moe_dtype_mismatch()
        qpatch.patch_all()
        assert len(applied()) == 4
