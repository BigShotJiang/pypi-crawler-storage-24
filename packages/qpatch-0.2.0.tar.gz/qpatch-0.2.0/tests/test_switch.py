"""Tests for qpatch switch: probes, telemetry, enable/disable."""

from __future__ import annotations

import os
from io import StringIO
from unittest.mock import patch

import pytest
import torch

import qpatch
import qpatch.patches as _pm
from qpatch.switch import (
    _probe_fused_kernel_bypass,
    _probe_lora_dtype_cast,
    _probe_moe_dtype_mismatch,
    _probe_safetensors_metadata,
    _probes,
)


@pytest.fixture(autouse=True)
def reset_state():
    """Reset all patch state between tests."""
    _pm._applied.clear()
    _pm._telemetry.clear()
    _pm._originals.clear()
    yield
    _pm._applied.clear()
    _pm._telemetry.clear()
    _pm._originals.clear()


# ═══════════════════════════════════════════════════════════════
# Probes
# ═══════════════════════════════════════════════════════════════


class TestProbes:
    def test_safetensors_probe_returns_bool(self):
        result = _probe_safetensors_metadata()
        assert isinstance(result, bool)

    def test_lora_probe_returns_bool(self):
        result = _probe_lora_dtype_cast()
        assert isinstance(result, bool)

    def test_moe_probe_returns_bool(self):
        result = _probe_moe_dtype_mismatch()
        assert isinstance(result, bool)

    def test_fused_probe_returns_bool(self):
        result = _probe_fused_kernel_bypass()
        assert isinstance(result, bool)

    def test_all_probes_registered(self):
        assert set(_probes.keys()) == set(_pm.PATCH_NAMES)

    def test_fused_probe_detects_pattern(self, tmp_path, monkeypatch):
        """Probe should detect files with the fused kernel pattern."""
        model_dir = tmp_path / "modules" / "model"
        model_dir.mkdir(parents=True)
        (model_dir / "modeling_test.py").write_text(
            "if self.training and cache_params is None:\n    pass\n"
        )
        monkeypatch.setattr(
            os.path, "expanduser",
            lambda p: str(tmp_path / "modules") if "modules" in p
            else str(tmp_path / "hub"),
        )
        assert _probe_fused_kernel_bypass() is True

    def test_fused_probe_empty_cache(self, tmp_path, monkeypatch):
        """Probe should return False when no model files exist."""
        monkeypatch.setattr(
            os.path, "expanduser",
            lambda p: str(tmp_path / "nonexistent"),
        )
        assert _probe_fused_kernel_bypass() is False


# ═══════════════════════════════════════════════════════════════
# Telemetry
# ═══════════════════════════════════════════════════════════════


class TestTelemetry:
    def test_report_empty_before_patching(self):
        data = qpatch.report()
        assert len(data) == 4
        for info in data.values():
            assert info["active"] is False
            assert info["hits"] == 0
            assert info["last_hit"] is None

    def test_report_after_patch_all(self):
        qpatch.patch_all()
        data = qpatch.report()
        for info in data.values():
            assert info["active"] is True

    def test_moe_hit_counter(self):
        """index_add_ with mismatched dtypes should increment hit count."""
        qpatch.patch_moe_dtype_mismatch()

        target = torch.zeros(2, 2, dtype=torch.float16)
        source = torch.ones(2, 2, dtype=torch.float32)
        target.index_add_(0, torch.tensor([0, 1]), source)

        data = qpatch.report()
        assert data["moe_dtype_mismatch"]["hits"] == 1
        assert data["moe_dtype_mismatch"]["last_hit"] is not None

    def test_moe_no_hit_on_matching_dtype(self):
        """index_add_ with matching dtypes should not increment."""
        qpatch.patch_moe_dtype_mismatch()

        target = torch.zeros(2, 2, dtype=torch.float32)
        source = torch.ones(2, 2, dtype=torch.float32)
        target.index_add_(0, torch.tensor([0, 1]), source)

        data = qpatch.report()
        assert data["moe_dtype_mismatch"]["hits"] == 0

    def test_multiple_hits_accumulate(self):
        qpatch.patch_moe_dtype_mismatch()

        for _ in range(5):
            target = torch.zeros(2, 2, dtype=torch.float16)
            source = torch.ones(2, 2, dtype=torch.float32)
            target.index_add_(0, torch.tensor([0, 1]), source)

        data = qpatch.report()
        assert data["moe_dtype_mismatch"]["hits"] == 5


# ═══════════════════════════════════════════════════════════════
# Status display
# ═══════════════════════════════════════════════════════════════


class TestStatus:
    def test_status_prints(self, capsys):
        qpatch.patch_all()
        qpatch.status()
        captured = capsys.readouterr()
        assert "qpatch v" in captured.out
        assert "safetensors_metadata" in captured.out
        assert "ON" in captured.out

    def test_status_shows_off(self, capsys):
        qpatch.status()
        captured = capsys.readouterr()
        assert "OFF" in captured.out


# ═══════════════════════════════════════════════════════════════
# Enable / Disable
# ═══════════════════════════════════════════════════════════════


class TestDisable:
    def test_disable_moe(self):
        """Disabling moe patch should restore original index_add_."""
        original = torch.Tensor.index_add_
        qpatch.patch_moe_dtype_mismatch()
        assert torch.Tensor.index_add_ is not original

        qpatch.disable("moe_dtype_mismatch")
        assert torch.Tensor.index_add_ is original
        assert "moe_dtype_mismatch" not in _pm._applied

    def test_disable_inactive_warns(self, caplog):
        qpatch.disable("moe_dtype_mismatch")
        assert "not active" in caplog.text

    def test_disable_fused_warns(self, caplog):
        qpatch.patch_fused_kernel_bypass()
        qpatch.disable("fused_kernel_bypass")
        assert "file-based" in caplog.text or "permanent" in caplog.text

    def test_report_reflects_disable(self):
        qpatch.patch_moe_dtype_mismatch()
        assert qpatch.report()["moe_dtype_mismatch"]["active"] is True

        qpatch.disable("moe_dtype_mismatch")
        assert qpatch.report()["moe_dtype_mismatch"]["active"] is False


class TestEnable:
    def test_enable_after_disable(self):
        qpatch.patch_moe_dtype_mismatch()
        qpatch.disable("moe_dtype_mismatch")
        assert "moe_dtype_mismatch" not in _pm._applied

        qpatch.enable("moe_dtype_mismatch")
        assert "moe_dtype_mismatch" in _pm._applied

    def test_enable_already_active(self, caplog):
        import logging

        with caplog.at_level(logging.INFO, logger="qpatch"):
            qpatch.patch_moe_dtype_mismatch()
            qpatch.enable("moe_dtype_mismatch")
        assert "already active" in caplog.text

    def test_enable_unknown_raises(self):
        with pytest.raises(ValueError, match="Unknown patch"):
            qpatch.enable("nonexistent_patch")


# ═══════════════════════════════════════════════════════════════
# Auto mode
# ═══════════════════════════════════════════════════════════════


class TestAutoMode:
    def test_auto_false_applies_all(self):
        qpatch.patch_all(auto=False)
        assert len(_pm._applied) == 4

    def test_auto_true_skips_unneeded(self):
        """With all probes returning False, no patches should apply."""
        with patch.dict(_probes, {k: lambda: False for k in _probes}):
            qpatch.patch_all(auto=True)
        assert len(_pm._applied) == 0

    def test_auto_true_applies_needed(self):
        """With all probes returning True, all patches should apply."""
        with patch.dict(_probes, {k: lambda: True for k in _probes}):
            qpatch.patch_all(auto=True)
        assert len(_pm._applied) == 4

    def test_auto_selective(self):
        """Only patches whose probes return True should be applied."""
        custom_probes = {
            "safetensors_metadata": lambda: True,
            "lora_dtype_cast": lambda: False,
            "moe_dtype_mismatch": lambda: True,
            "fused_kernel_bypass": lambda: False,
        }
        with patch.dict(_probes, custom_probes):
            qpatch.patch_all(auto=True)
        assert "safetensors_metadata" in _pm._applied
        assert "lora_dtype_cast" not in _pm._applied
        assert "moe_dtype_mismatch" in _pm._applied
        assert "fused_kernel_bypass" not in _pm._applied
