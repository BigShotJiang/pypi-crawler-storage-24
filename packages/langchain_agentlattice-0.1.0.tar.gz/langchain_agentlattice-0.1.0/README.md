# langchain-agentlattice

AgentLattice governance wrapper for LangChain tools. Gates every tool invocation through AgentLattice's audit trail, policy engine, and approval flow.

## Install

```bash
pip install langchain-agentlattice
```

## Quickstart

```python
import os
from agentlattice import AgentLattice
from langchain_agentlattice import govern
from langchain_community.tools import DuckDuckGoSearchRun

al = AgentLattice(api_key=os.environ["AL_API_KEY"])
search = DuckDuckGoSearchRun()

# Wrap any LangChain tool — gate() runs before every invocation
governed_search = govern(search, al=al)

# Drop-in replacement — same name, description, interface
tools = [governed_search]
```

Handle denials:

```python
from agentlattice import AgentLatticeDeniedError, AgentLatticeTimeoutError

try:
    result = await governed_search._arun("latest AI news")
except AgentLatticeDeniedError as e:
    print(f"Denied: {e.reason}, policy: {e.policy}")
except AgentLatticeTimeoutError as e:
    print(f"Approval timed out: {e.approval_id}")
```

## How it works

`govern()` wraps any `BaseTool` in a `GovernedTool` that:
1. Calls `al.gate(action_type)` before executing
2. If approved → delegates to the wrapped tool's `_arun()` / `_run()`
3. If denied → raises `AgentLatticeDeniedError` (tool does **not** execute)
4. If timed out → raises `AgentLatticeTimeoutError`

This is a **tool wrapper**, not a callback handler. LangChain callbacks are
notifications — they cannot block tool execution. Only the wrapper pattern
preserves the gate() semantics.

## Custom action types

```python
# Default: "tool.{tool.name}"
governed = govern(my_tool, al=al)

# Override
governed = govern(my_tool, al=al, action_type="search.web.execute")
```
