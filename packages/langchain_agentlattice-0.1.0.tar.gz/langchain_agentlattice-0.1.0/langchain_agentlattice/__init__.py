"""
langchain-agentlattice — AgentLattice governance wrapper for LangChain tools.

Usage:
    from langchain_agentlattice import govern
    from agentlattice import AgentLattice

    al = AgentLattice(api_key=os.environ["AL_API_KEY"])

    # Wrap any LangChain tool — gate() runs before every tool invocation
    tools = [govern(my_tool, al=al)]

    # Override the action type (defaults to "tool.{tool.name}")
    tools = [govern(my_tool, al=al, action_type="search.execute")]
"""

from langchain_agentlattice.govern import govern, GovernedTool

__all__ = ["govern", "GovernedTool"]
__version__ = "0.1.0"
