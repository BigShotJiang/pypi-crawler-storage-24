"""
AgentLattice governance wrapper for LangChain tools.

Pattern: tool wrapper (not callback handler).
Rationale: LangChain callbacks are notifications — they cannot block tool
execution. Only a tool wrapper can call gate() and prevent execution on denial.

Usage:
    governed = govern(my_tool, al=al)
    # governed.name, governed.description — same as wrapped tool
    # governed._arun() → await al.gate(action_type) → my_tool._arun()
    # governed._run()  → al.gate_sync(action_type)  → my_tool._run()
"""

from __future__ import annotations

from typing import Any, Optional

import pydantic
from langchain_core.tools import BaseTool

from agentlattice import AgentLattice


class GovernedTool(BaseTool):
    """
    A LangChain BaseTool wrapper that gates every invocation through AgentLattice.

    Do not instantiate directly — use govern() instead.

    Execution flow:
        _arun(input) → await al.gate(action_type) → wrapped._arun(input)
        _run(input)  → al.gate_sync(action_type)  → wrapped._run(input)

    On AgentLatticeDeniedError or AgentLatticeTimeoutError, the exception
    propagates — the wrapped tool's _run/_arun is never called.
    """

    # BaseTool requires name + description as fields
    name: str
    description: str
    action_type: str

    # Private — not included in serialization or Pydantic schema
    _al: AgentLattice = pydantic.PrivateAttr()
    _wrapped: BaseTool = pydantic.PrivateAttr()

    def __init__(
        self,
        *,
        tool: BaseTool,
        al: AgentLattice,
        action_type: str,
        **kwargs: Any,
    ) -> None:
        super().__init__(
            name=tool.name,
            description=tool.description,
            action_type=action_type,
            args_schema=tool.args_schema,
            return_direct=tool.return_direct,
            **kwargs,
        )
        self._al = al
        self._wrapped = tool

    def _run(self, tool_input: str, **kwargs: Any) -> Any:
        """Sync path: gate_sync() → wrapped._run()."""
        self._al.gate_sync(self.action_type)
        return self._wrapped._run(tool_input, **kwargs)

    async def _arun(self, tool_input: str, **kwargs: Any) -> Any:
        """Async path: gate() → wrapped._arun()."""
        await self._al.gate(self.action_type)
        return await self._wrapped._arun(tool_input, **kwargs)


def govern(
    tool: BaseTool,
    *,
    al: AgentLattice,
    action_type: Optional[str] = None,
) -> GovernedTool:
    """
    Wrap a LangChain tool with AgentLattice governance.

    Every call to the tool's _run() or _arun() will first call al.gate()
    (or al.gate_sync() for sync calls). If the action is denied or times out,
    an AgentLatticeDeniedError or AgentLatticeTimeoutError is raised and the
    tool does not execute.

    Args:
        tool: Any LangChain BaseTool to wrap.
        al: An AgentLattice client instance.
        action_type: The action type string for the audit record.
            Defaults to "tool.{tool.name}".

    Returns:
        A GovernedTool that behaves identically to the wrapped tool
        but gates every execution through AgentLattice.

    Example:
        al = AgentLattice(api_key=os.environ["AL_API_KEY"])
        governed_search = govern(search_tool, al=al)
        # Drop-in replacement — same name, description, interface
        agent = initialize_agent(tools=[governed_search], ...)
    """
    safe_name = tool.name.lower().replace(" ", "_")
    return GovernedTool(
        tool=tool,
        al=al,
        action_type=action_type or f"tool.{safe_name}",
    )
