"""
Tests for langchain-agentlattice govern() wrapper.

Mocks AgentLattice methods directly — no HTTP required.
"""

import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from langchain_core.tools import BaseTool

from langchain_agentlattice import govern, GovernedTool
from agentlattice import AgentLattice, AgentLatticeDeniedError, AgentLatticeTimeoutError


# ── Fixtures ──────────────────────────────────────────────────────────────────

class EchoTool(BaseTool):
    """Simple tool that echoes its input."""
    name: str = "echo"
    description: str = "Echoes the input."

    def _run(self, tool_input: str, **kwargs) -> str:
        return f"echo: {tool_input}"

    async def _arun(self, tool_input: str, **kwargs) -> str:
        return f"async echo: {tool_input}"


def make_al(*, gate_raises=None, gate_sync_raises=None) -> AgentLattice:
    """Return a mock AgentLattice with configurable gate behavior."""
    al = MagicMock(spec=AgentLattice)
    if gate_raises:
        al.gate = AsyncMock(side_effect=gate_raises)
    else:
        al.gate = AsyncMock(return_value=None)

    if gate_sync_raises:
        al.gate_sync = MagicMock(side_effect=gate_sync_raises)
    else:
        al.gate_sync = MagicMock(return_value=None)
    return al


# ── govern() factory ──────────────────────────────────────────────────────────

def test_govern_preserves_tool_name():
    al = make_al()
    governed = govern(EchoTool(), al=al)
    assert governed.name == "echo"


def test_govern_preserves_tool_description():
    al = make_al()
    governed = govern(EchoTool(), al=al)
    assert governed.description == "Echoes the input."


def test_govern_default_action_type_is_tool_dot_name():
    al = make_al()
    governed = govern(EchoTool(), al=al)
    assert governed.action_type == "tool.echo"


def test_govern_custom_action_type():
    al = make_al()
    governed = govern(EchoTool(), al=al, action_type="search.execute")
    assert governed.action_type == "search.execute"


def test_govern_returns_governed_tool_instance():
    al = make_al()
    governed = govern(EchoTool(), al=al)
    assert isinstance(governed, GovernedTool)


# ── Async path: _arun() ───────────────────────────────────────────────────────

async def test_arun_calls_gate_before_tool():
    al = make_al()
    governed = govern(EchoTool(), al=al)
    result = await governed._arun("hello")
    al.gate.assert_called_once_with("tool.echo")
    assert result == "async echo: hello"


async def test_arun_does_not_execute_tool_on_denied():
    al = make_al(gate_raises=AgentLatticeDeniedError(None, "CONDITIONS_DENIED"))
    tool = EchoTool()
    governed = govern(tool, al=al)

    with pytest.raises(AgentLatticeDeniedError):
        await governed._arun("hello")

    # Verify the underlying tool's _arun was never invoked
    with patch.object(tool, "_arun", new_callable=AsyncMock) as mock_arun:
        try:
            await governed._arun("hello")
        except AgentLatticeDeniedError:
            pass
        mock_arun.assert_not_called()


async def test_arun_propagates_timeout_error():
    al = make_al(gate_raises=AgentLatticeTimeoutError("apr-test"))
    governed = govern(EchoTool(), al=al)

    with pytest.raises(AgentLatticeTimeoutError) as exc_info:
        await governed._arun("hello")
    assert exc_info.value.approval_id == "apr-test"


# ── Sync path: _run() ─────────────────────────────────────────────────────────

def test_run_calls_gate_sync_before_tool():
    al = make_al()
    governed = govern(EchoTool(), al=al)
    result = governed._run("world")
    al.gate_sync.assert_called_once_with("tool.echo")
    assert result == "echo: world"


def test_run_does_not_execute_tool_on_denied():
    al = make_al(gate_sync_raises=AgentLatticeDeniedError(None, "CONDITIONS_DENIED"))
    governed = govern(EchoTool(), al=al)

    with pytest.raises(AgentLatticeDeniedError):
        governed._run("world")
