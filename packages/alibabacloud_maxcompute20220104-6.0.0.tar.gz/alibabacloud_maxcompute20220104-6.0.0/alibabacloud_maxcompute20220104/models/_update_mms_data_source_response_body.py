# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from alibabacloud_maxcompute20220104 import models as main_models
from darabonba.model import DaraModel

class UpdateMmsDataSourceResponseBody(DaraModel):
    def __init__(
        self,
        data: main_models.UpdateMmsDataSourceResponseBodyData = None,
        request_id: str = None,
    ):
        # The result of the request.
        self.data = data
        # The request ID.
        self.request_id = request_id

    def validate(self):
        if self.data:
            self.data.validate()

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.data is not None:
            result['data'] = self.data.to_map()

        if self.request_id is not None:
            result['requestId'] = self.request_id

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('data') is not None:
            temp_model = main_models.UpdateMmsDataSourceResponseBodyData()
            self.data = temp_model.from_map(m.get('data'))

        if m.get('requestId') is not None:
            self.request_id = m.get('requestId')

        return self

class UpdateMmsDataSourceResponseBodyData(DaraModel):
    def __init__(
        self,
        async_task_id: int = None,
        source_id: int = None,
    ):
        # The ID of the asynchronous task. When you test the data source configuration, this ID is used to obtain the test result.
        self.async_task_id = async_task_id
        # The ID of the data source.
        self.source_id = source_id

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.async_task_id is not None:
            result['asyncTaskId'] = self.async_task_id

        if self.source_id is not None:
            result['sourceId'] = self.source_id

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('asyncTaskId') is not None:
            self.async_task_id = m.get('asyncTaskId')

        if m.get('sourceId') is not None:
            self.source_id = m.get('sourceId')

        return self

