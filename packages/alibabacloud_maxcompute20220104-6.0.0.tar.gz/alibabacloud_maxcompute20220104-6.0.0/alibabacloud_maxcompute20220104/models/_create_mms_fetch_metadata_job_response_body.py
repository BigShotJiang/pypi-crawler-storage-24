# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from alibabacloud_maxcompute20220104 import models as main_models
from darabonba.model import DaraModel

class CreateMmsFetchMetadataJobResponseBody(DaraModel):
    def __init__(
        self,
        data: main_models.CreateMmsFetchMetadataJobResponseBodyData = None,
        request_id: str = None,
    ):
        # The returned result.
        self.data = data
        # The request ID.
        self.request_id = request_id

    def validate(self):
        if self.data:
            self.data.validate()

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.data is not None:
            result['data'] = self.data.to_map()

        if self.request_id is not None:
            result['requestId'] = self.request_id

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('data') is not None:
            temp_model = main_models.CreateMmsFetchMetadataJobResponseBodyData()
            self.data = temp_model.from_map(m.get('data'))

        if m.get('requestId') is not None:
            self.request_id = m.get('requestId')

        return self

class CreateMmsFetchMetadataJobResponseBodyData(DaraModel):
    def __init__(
        self,
        scan_id: int = None,
    ):
        # The ID of the asynchronous task that syncs metadata.
        self.scan_id = scan_id

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.scan_id is not None:
            result['scanId'] = self.scan_id

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('scanId') is not None:
            self.scan_id = m.get('scanId')

        return self

