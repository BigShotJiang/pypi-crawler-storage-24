# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from typing import Dict, Any, List

from darabonba.model import DaraModel

class CreateMmsJobRequest(DaraModel):
    def __init__(
        self,
        column_mapping: Dict[str, str] = None,
        dst_db_name: str = None,
        dst_schema_name: str = None,
        enable_data_migration: bool = None,
        enable_schema_migration: bool = None,
        enable_verification: bool = None,
        eta: str = None,
        increment: bool = None,
        name: str = None,
        others: Dict[str, Any] = None,
        partition_filters: Dict[str, str] = None,
        partitions: List[int] = None,
        schema_only: bool = None,
        source_id: int = None,
        source_name: str = None,
        src_db_name: str = None,
        src_schema_name: str = None,
        table_black_list: List[str] = None,
        table_mapping: Dict[str, str] = None,
        table_white_list: List[str] = None,
        tables: List[str] = None,
        task_type: str = None,
    ):
        # {Source column name: Destination column name}
        self.column_mapping = column_mapping
        # The destination MaxCompute project.
        self.dst_db_name = dst_db_name
        # The destination MaxCompute schema.
        self.dst_schema_name = dst_schema_name
        # Specifies whether to migrate table data.
        self.enable_data_migration = enable_data_migration
        # Specifies whether to migrate table schemas.
        self.enable_schema_migration = enable_schema_migration
        # Specifies whether to enable data verification. The current verification method is to execute SELECT COUNT(\\*) on the source and destination to compare the number of rows.
        self.enable_verification = enable_verification
        # The expected completion time of the migration. Note: A smaller eta value gives the migration task higher priority.
        self.eta = eta
        # Specifies whether to perform an incremental migration. In an incremental migration, only new or changed partitions are migrated. Note that changed partitions are re-migrated.
        self.increment = increment
        # The name of the migration job.
        self.name = name
        # Other configuration information.
        self.others = others
        # {Table name: Partition filter expression}
        self.partition_filters = partition_filters
        # The list of partition IDs.
        self.partitions = partitions
        # Specifies whether to migrate only metadata.
        self.schema_only = schema_only
        # The ID of the data source.
        self.source_id = source_id
        # The name of the data source.
        self.source_name = source_name
        # The name of the source database.
        self.src_db_name = src_db_name
        # The name of the source schema. This is the schema in a Layer 3 namespace.
        self.src_schema_name = src_schema_name
        # The blacklist of tables.
        self.table_black_list = table_black_list
        # {Source table: Destination table}
        self.table_mapping = table_mapping
        # The whitelist of tables. Note: If you configure both a whitelist and a blacklist, only the blacklist takes effect.
        self.table_white_list = table_white_list
        # The list of table names.
        self.tables = tables
        # The type of the migration task.
        self.task_type = task_type

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.column_mapping is not None:
            result['columnMapping'] = self.column_mapping

        if self.dst_db_name is not None:
            result['dstDbName'] = self.dst_db_name

        if self.dst_schema_name is not None:
            result['dstSchemaName'] = self.dst_schema_name

        if self.enable_data_migration is not None:
            result['enableDataMigration'] = self.enable_data_migration

        if self.enable_schema_migration is not None:
            result['enableSchemaMigration'] = self.enable_schema_migration

        if self.enable_verification is not None:
            result['enableVerification'] = self.enable_verification

        if self.eta is not None:
            result['eta'] = self.eta

        if self.increment is not None:
            result['increment'] = self.increment

        if self.name is not None:
            result['name'] = self.name

        if self.others is not None:
            result['others'] = self.others

        if self.partition_filters is not None:
            result['partitionFilters'] = self.partition_filters

        if self.partitions is not None:
            result['partitions'] = self.partitions

        if self.schema_only is not None:
            result['schemaOnly'] = self.schema_only

        if self.source_id is not None:
            result['sourceId'] = self.source_id

        if self.source_name is not None:
            result['sourceName'] = self.source_name

        if self.src_db_name is not None:
            result['srcDbName'] = self.src_db_name

        if self.src_schema_name is not None:
            result['srcSchemaName'] = self.src_schema_name

        if self.table_black_list is not None:
            result['tableBlackList'] = self.table_black_list

        if self.table_mapping is not None:
            result['tableMapping'] = self.table_mapping

        if self.table_white_list is not None:
            result['tableWhiteList'] = self.table_white_list

        if self.tables is not None:
            result['tables'] = self.tables

        if self.task_type is not None:
            result['taskType'] = self.task_type

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('columnMapping') is not None:
            self.column_mapping = m.get('columnMapping')

        if m.get('dstDbName') is not None:
            self.dst_db_name = m.get('dstDbName')

        if m.get('dstSchemaName') is not None:
            self.dst_schema_name = m.get('dstSchemaName')

        if m.get('enableDataMigration') is not None:
            self.enable_data_migration = m.get('enableDataMigration')

        if m.get('enableSchemaMigration') is not None:
            self.enable_schema_migration = m.get('enableSchemaMigration')

        if m.get('enableVerification') is not None:
            self.enable_verification = m.get('enableVerification')

        if m.get('eta') is not None:
            self.eta = m.get('eta')

        if m.get('increment') is not None:
            self.increment = m.get('increment')

        if m.get('name') is not None:
            self.name = m.get('name')

        if m.get('others') is not None:
            self.others = m.get('others')

        if m.get('partitionFilters') is not None:
            self.partition_filters = m.get('partitionFilters')

        if m.get('partitions') is not None:
            self.partitions = m.get('partitions')

        if m.get('schemaOnly') is not None:
            self.schema_only = m.get('schemaOnly')

        if m.get('sourceId') is not None:
            self.source_id = m.get('sourceId')

        if m.get('sourceName') is not None:
            self.source_name = m.get('sourceName')

        if m.get('srcDbName') is not None:
            self.src_db_name = m.get('srcDbName')

        if m.get('srcSchemaName') is not None:
            self.src_schema_name = m.get('srcSchemaName')

        if m.get('tableBlackList') is not None:
            self.table_black_list = m.get('tableBlackList')

        if m.get('tableMapping') is not None:
            self.table_mapping = m.get('tableMapping')

        if m.get('tableWhiteList') is not None:
            self.table_white_list = m.get('tableWhiteList')

        if m.get('tables') is not None:
            self.tables = m.get('tables')

        if m.get('taskType') is not None:
            self.task_type = m.get('taskType')

        return self

