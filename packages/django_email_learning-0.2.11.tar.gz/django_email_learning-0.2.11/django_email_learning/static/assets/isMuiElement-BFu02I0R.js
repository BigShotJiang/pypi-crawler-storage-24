import{r}from"./render-BE5DrXtX.js";function e(i,a){return r.isValidElement(i)&&a.indexOf(i.type.muiName??i.type?._payload?.value?.muiName)!==-1}export{e as i};
//# sourceMappingURL=isMuiElement-BFu02I0R.js.map
