import{i as o,j as s}from"./render-BE5DrXtX.js";const h=o(s.jsx("path",{d:"M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6z"}));export{h as A};
//# sourceMappingURL=Add-BkzW9-CX.js.map
