# -*- coding: utf-8 -*-
# Copyright (c) 2014-2026 Richard Hull and contributors
# See LICENSE.rst for details.

"""
OLED display driver for SSD1305, SSD1306, SSD1309, SSD1315, SSD1316, SSD1322,
SSD1325, SSD1327, SSD1331, SSD1351, SSD1362, SH1106 and SH1107 devices.
"""

__version__ = '3.15.0'
