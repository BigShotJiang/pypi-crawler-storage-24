use super::drag::{drag_and_partials, drag_force};
use super::point_gravity::{point_gravity, point_gravity_and_partials};
use super::settings::PropSettings;

use crate::lpephem;
use crate::ode;
use crate::ode::ODEError;
use crate::ode::ODEResult;
use crate::ode::RKAdaptive;
use crate::ode::Rosenbrock;
use crate::orbitprop::Precomputed;
use crate::{Duration, Instant, TimeLike};
use lpephem::sun::shadowfunc;

use anyhow::{Context, Result};

use crate::mathtypes::*;

use crate::consts;
use crate::orbitprop::SatProperties;
use num_traits::identities::Zero;

use thiserror::Error;

use nalgebra as na;

use serde::{Deserialize, Serialize};

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct PropagationResult<const T: usize> {
    pub time_begin: Instant,
    pub state_begin: Matrix<6, T>,
    pub time_end: Instant,
    pub state_end: Matrix<6, T>,
    pub accepted_steps: u32,
    pub rejected_steps: u32,
    pub num_eval: u32,
    pub odesol: Option<ode::ODESolution<Matrix<6, T>>>,
    pub integrator: super::settings::Integrator,
}

impl<const T: usize> PropagationResult<T> {
    pub fn interp<U: TimeLike>(&self, time: &U) -> Result<Matrix<6, T>> {
        interp_propresult(self, time)
    }
}

pub type StateType<const C: usize> = na::SMatrix<f64, 6, C>;

// Simple state with position & velocity
pub type SimpleState = StateType<1>;

// Covariance State in includes
pub type CovState = StateType<7>;

#[derive(Debug, Error)]
pub enum PropagationError {
    #[error("Invalid number of columns: {c}")]
    InvalidStateColumns { c: usize },
    #[error("No Dense Output in Solution")]
    NoDenseOutputInSolution,
    #[error("ODE Error: {0}")]
    ODEError(ode::ODEError),
    #[error("RODAS4 does not support state transition matrix propagation")]
    RODAS4NoSTM,
}

//
// This actually implements the force model that is used to
// integrate the ODE to get position and velocity
//
// State is position and velocity
// Force is computed and integrated to get velocity
// Velocity is integrated to get position
//
// If C=7, a 6x6 state transition matrix is appended as additional
// colums, making the integrated "state" a 6x7 matrix
// The state transition matrix can be used to propagate covariances
//
// See Montenbruk & Gill for details (Chapter 7)
//

/// Solar radiation pressure acceleration in GCRF
fn solar_pressure_accel(
    sun_gcrf: &Vector3,
    pos_gcrf: &Vector3,
    time: &Instant,
    props: &dyn SatProperties,
    state: &SimpleState,
) -> Vector3 {
    -shadowfunc(sun_gcrf, pos_gcrf) * props.cr_a_over_m(time, state) * 4.56e-6 * sun_gcrf
        / sun_gcrf.norm()
}

///
/// High-precision propagation of a satellite state from a given begin time
/// to a given end time, with input settings and
/// satellite properties
///
/// Uses Runge-Kutta methods for integrating the force equations
///
/// The default propagator uses a Runge-Kutta 9(8) integrator
/// with coefficients computed by Verner:
/// <https://www.sfu.a/~jverner//>
///
/// This works much better than lower-order Runge-Kutta solvers such as
/// Dormand-Prince, and I don't know why it isn't more popular in
/// numerical packages
///
/// # Forces included in the propagator:
///
/// * Earth gravity with higher-order zonal terms
/// * Gravitational pull of sun, moon
/// * Solar radiation pressure
/// * Atmospheric drag: NRL-MSISE 2000 model, with option to include space weather
///   (effects can be large)
///
/// # Arguments:
///
/// * `state` - The satellite state, represented as:
///    * `SimpleState` - a 6x1 matrix where the 1st three elements represent GCRF position in meters,
///      and the 2nd three elements represent GCRF velocity in meters / second
///    * `CovState` - a 6x7 matrix where the first column is the same as SimpleState above, and columns
///      2-7 represent the 6x6 state transition matrix, dS/dS0
///      The state transition matrix should be initialized to identity when running
///      The output of the state transition matrix can be used to compute the evolution of the
///      state covariance  (see Montenbruck and Gill for details)
///  * `begin` - The time at the initial state
///  * `end` - Propagate to this time from the begin
///  * `step_seconds` - An optional value representing intervals between `begin` and `end` at which
///    the new state will be computed
///  * `settings` - Settings for the Runge-Kutta propagator
///  * `satprops` - Properties of the satellite, such as ballistic coefficient & susceptibility to
///    radiation pressure
///
/// # Returns
/// * `PropagationResult` object with details of the propagation compute, the final state, and intermediate states if step size
///   is set
///
/// # Example:
///
/// ```
/// // Setup a simple Geosynchronous orbit with initial position along the x axis
/// // and initial velocity along the y axis
/// let mut state = satkit::orbitprop::SimpleState::zeros();
/// state[0] = satkit::consts::GEO_R;
/// state[4] = (satkit::consts::MU_EARTH / satkit::consts::GEO_R).sqrt();
///
/// // Setup the details of the propagation
/// let mut settings = satkit::orbitprop::PropSettings::default();
/// settings.abs_error = 1.0e-9;
/// settings.rel_error = 1.0e-14;
/// settings.gravity_degree = 4;
///
/// // Pick an arbitrary begin time
/// let begintime = satkit::Instant::from_datetime(2015, 3, 20, 0, 0, 0.0).unwrap();
/// // Propagate to 1/2 day ahead
/// let endtime = begintime + satkit::Duration::from_days(0.5);
///
/// // Look at the results
/// let res = satkit::orbitprop::propagate(&state, &begintime, &endtime, &settings, None).unwrap();
///
/// println!("results = {:?}", res);
/// // Expect:
/// // res = PropagationResult { time: [Instant { mjd_tai: 57101.50040509259 }],
/// //                           state: [[[-42153870.84175911, -379423.6616440884, -26.239180898423687,
/// //                                     27.66411233952899, -3075.146656613106, 0.0020580348953689828]]],
/// //                           accepted_steps: 45, rejected_steps: 0, num_eval: 722
/// //                          }
/// ```
///
/// # Example 2:
///
/// ```
/// // Now, propagate the state transition matrix
///
/// // Setup a simple Geosynchronous orbit with initial position along the x axis
/// // and initial velocity along the y axis
/// use nalgebra as na;
/// let mut state = satkit::orbitprop::CovState::zeros();
/// state.fixed_view_mut::<3, 1>(0, 0).copy_from(&na::vector![satkit::consts::GEO_R, 0.0, 0.0]);
/// state.fixed_view_mut::<3, 1>(3, 0).copy_from(&na::vector![0.0, (satkit::consts::MU_EARTH/satkit::consts::GEO_R).sqrt(), 0.0]);
/// // initialize state transition matrix to zero
/// state.fixed_view_mut::<6, 6>(0, 1).copy_from(&na::Matrix6::<f64>::identity());
///
///
/// // Setup the details of the propagation
/// let mut settings = satkit::orbitprop::PropSettings::default();
/// settings.abs_error = 1.0e-9;
/// settings.rel_error = 1.0e-14;
/// settings.gravity_degree = 4;
///
/// // Pick an arbitrary begin time
/// let begintime = satkit::Instant::from_datetime(2015, 3, 20, 0, 0, 0.0).unwrap();
/// // Propagate to 1/2 day ahead
/// let endtime = begintime + satkit::Duration::from_days(0.5);
///
/// // Look at the results
/// let res = satkit::orbitprop::propagate(&state, &begintime, &endtime, &settings, None).unwrap();
///
/// println!("results = {:?}", res);
/// ```
///
///
pub fn propagate<const C: usize, T: TimeLike>(
    state: &StateType<C>,
    begin: &T,
    end: &T,
    settings: &PropSettings,
    satprops: Option<&dyn SatProperties>,
) -> Result<PropagationResult<C>> {
    let begin = begin.as_instant();
    let end = end.as_instant();

    // Check for zero-duration case and return immediately
    if end == begin {
        return Ok(PropagationResult {
            time_begin: begin,
            state_begin: *state,
            time_end: end,
            state_end: *state,
            accepted_steps: 0,
            rejected_steps: 0,
            num_eval: 0,
            odesol: None,
            integrator: settings.integrator,
        });
    }

    // RODAS4 does not support state transition matrix (C==7)
    if C == 7 && settings.integrator == crate::orbitprop::Integrator::RODAS4 {
        return Err(PropagationError::RODAS4NoSTM.into());
    }

    // Duration to end of integration, in seconds
    let x_end: f64 = (end - begin).as_seconds();

    let odesettings = crate::ode::RKAdaptiveSettings {
        abserror: settings.abs_error,
        relerror: settings.rel_error,
        dense_output: settings.enable_interp,
        ..Default::default()
    };

    // Get or create precomputed ephemeris data
    let (tmin, tmax) = if end > begin { (begin, end) } else { (end, begin) };
    let interp: &Precomputed = match &settings.precomputed {
        Some(p) if tmin >= p.begin && tmax <= p.end => p,
        _ => &Precomputed::new(&begin, &end)
            .context("Cannot compute precomputed interpolation data")?,
    };

    let gravity = settings.gravity_model.get();

    let ydot = |x: f64, y: &Matrix<6, C>| -> ODEResult<Matrix<6, C>> {
        let time: Instant = begin + Duration::from_seconds(x);
        let pos_gcrf: na::Vector3<f64> = y.fixed_view::<3, 1>(0, 0).into();
        let vel_gcrf: na::Vector3<f64> = y.fixed_view::<3, 1>(3, 0).into();

        let (qgcrf2itrf, sun_gcrf, moon_gcrf) = match interp.interp(&time) {
            Ok(v) => v,
            Err(e) => return Err(ODEError::YDotError(e.to_string())),
        };
        let qitrf2gcrf = qgcrf2itrf.conjugate();
        let pos_itrf = qgcrf2itrf * pos_gcrf;

        // Decide whether to compute partials:
        // - C == 7: always (state transition matrix)
        // - C == 1: never (explicit integrators don't need partials in ydot)
        let need_partials = C == 7;

        let (mut accel, mut dadr, mut dadv) = if need_partials {
            let (ga, gp) = gravity.accel_and_partials(
                &pos_itrf,
                settings.gravity_degree as usize,
                settings.gravity_order as usize,
            );
            let ritrf2gcrf = qitrf2gcrf.to_rotation_matrix();
            (
                qitrf2gcrf * ga,
                ritrf2gcrf * gp * ritrf2gcrf.transpose(),
                Matrix3::zeros(),
            )
        } else {
            (
                qitrf2gcrf
                    * gravity.accel(
                        &pos_itrf,
                        settings.gravity_degree as usize,
                        settings.gravity_order as usize,
                    ),
                Matrix3::zeros(),
                Matrix3::zeros(),
            )
        };

        if settings.use_sun_gravity {
            if need_partials {
                let (a, p) = point_gravity_and_partials(&pos_gcrf, &sun_gcrf, consts::MU_SUN);
                accel += a;
                dadr += p;
            } else {
                accel += point_gravity(&pos_gcrf, &sun_gcrf, consts::MU_SUN);
            }
        }
        if settings.use_moon_gravity {
            if need_partials {
                let (a, p) = point_gravity_and_partials(&pos_gcrf, &moon_gcrf, consts::MU_MOON);
                accel += a;
                dadr += p;
            } else {
                accel += point_gravity(&pos_gcrf, &moon_gcrf, consts::MU_MOON);
            }
        }

        if let Some(props) = satprops {
            let ss: SimpleState = y.fixed_view::<6, 1>(0, 0).into();
            accel += solar_pressure_accel(&sun_gcrf, &pos_gcrf, &time, props, &ss);
            if pos_gcrf.norm() < 700.0e3 + consts::EARTH_RADIUS {
                let cd_a_over_m = props.cd_a_over_m(&time, &ss);
                if cd_a_over_m > 1e-6 {
                    if need_partials {
                        let (drag_a, drag_dr, drag_dv) = drag_and_partials(
                            &pos_gcrf, &qgcrf2itrf, &vel_gcrf, &time,
                            cd_a_over_m, settings.use_spaceweather,
                        );
                        accel += drag_a;
                        dadr += drag_dr;
                        dadv = drag_dv;
                    } else {
                        accel += drag_force(
                            &pos_gcrf, &pos_itrf, &vel_gcrf, &time,
                            cd_a_over_m, settings.use_spaceweather,
                        );
                    }
                }
            }
        }

        if C == 1 {
            let mut dy = Matrix::<6, C>::zeros();
            dy.fixed_view_mut::<3, 1>(0, 0).copy_from(&vel_gcrf);
            dy.fixed_view_mut::<3, 1>(3, 0).copy_from(&accel);
            Ok(dy)
        } else if C == 7 {
            // Equation 7.42: dfdy * state_transition_matrix
            let mut dfdy = StateType::<6>::zeros();
            dfdy.fixed_view_mut::<3, 3>(0, 3)
                .copy_from(&na::Matrix3::<f64>::identity());
            dfdy.fixed_view_mut::<3, 3>(3, 0).copy_from(&dadr);
            dfdy.fixed_view_mut::<3, 3>(3, 3).copy_from(&dadv);
            let dphi = dfdy * y.fixed_view::<6, 6>(0, 1);

            let mut dy = Matrix::<6, C>::zero();
            dy.fixed_view_mut::<3, 1>(0, 0).copy_from(&vel_gcrf);
            dy.fixed_view_mut::<3, 1>(3, 0).copy_from(&accel);
            dy.fixed_view_mut::<6, 6>(0, 1).copy_from(&dphi);
            Ok(dy)
        } else {
            ODEError::YDotError(PropagationError::InvalidStateColumns { c: C }.to_string()).into()
        }
    };

    // Jacobian closure for RODAS4: computes the 6x6 ∂f/∂y matrix
    let jac_fn = |x: f64, y: &Matrix<6, C>| -> ODEResult<na::SMatrix<f64, 6, 6>> {
        let time: Instant = begin + Duration::from_seconds(x);
        let pos_gcrf: na::Vector3<f64> = y.fixed_view::<3, 1>(0, 0).into();
        let vel_gcrf: na::Vector3<f64> = y.fixed_view::<3, 1>(3, 0).into();

        let (qgcrf2itrf, sun_gcrf, moon_gcrf) = match interp.interp(&time) {
            Ok(v) => v,
            Err(e) => return Err(ODEError::YDotError(e.to_string())),
        };
        let qitrf2gcrf = qgcrf2itrf.conjugate();
        let pos_itrf = qgcrf2itrf * pos_gcrf;

        let (_, gp) = gravity.accel_and_partials(
            &pos_itrf,
            settings.gravity_degree as usize,
            settings.gravity_order as usize,
        );
        let ritrf2gcrf = qitrf2gcrf.to_rotation_matrix();
        let mut dadr = ritrf2gcrf * gp * ritrf2gcrf.transpose();
        let mut dadv = Matrix3::zeros();

        if settings.use_sun_gravity {
            let (_, p) = point_gravity_and_partials(&pos_gcrf, &sun_gcrf, consts::MU_SUN);
            dadr += p;
        }
        if settings.use_moon_gravity {
            let (_, p) = point_gravity_and_partials(&pos_gcrf, &moon_gcrf, consts::MU_MOON);
            dadr += p;
        }

        if let Some(props) = satprops {
            let ss: SimpleState = y.fixed_view::<6, 1>(0, 0).into();
            if pos_gcrf.norm() < 700.0e3 + consts::EARTH_RADIUS {
                let cd_a_over_m = props.cd_a_over_m(&time, &ss);
                if cd_a_over_m > 1e-6 {
                    let (_, drag_dr, drag_dv) = drag_and_partials(
                        &pos_gcrf, &qgcrf2itrf, &vel_gcrf, &time,
                        cd_a_over_m, settings.use_spaceweather,
                    );
                    dadr += drag_dr;
                    dadv = drag_dv;
                }
            }
        }

        // Build the 6x6 Jacobian: df/dy where f = [vel; accel]
        let mut dfdy = na::SMatrix::<f64, 6, 6>::zeros();
        dfdy.fixed_view_mut::<3, 3>(0, 3)
            .copy_from(&na::Matrix3::<f64>::identity());
        dfdy.fixed_view_mut::<3, 3>(3, 0).copy_from(&dadr);
        dfdy.fixed_view_mut::<3, 3>(3, 3).copy_from(&dadv);
        Ok(dfdy)
    };

    use crate::ode::solvers;
    use crate::orbitprop::Integrator;

    let res = match settings.integrator {
        Integrator::RKV98 => {
            solvers::RKV98::integrate(0.0, x_end, state, &ydot, &odesettings)
        }
        Integrator::RKV98NoInterp => {
            solvers::RKV98NoInterp::integrate(0.0, x_end, state, &ydot, &odesettings)
        }
        Integrator::RKV87 => {
            solvers::RKV87::integrate(0.0, x_end, state, &ydot, &odesettings)
        }
        Integrator::RKV65 => {
            solvers::RKV65::integrate(0.0, x_end, state, &ydot, &odesettings)
        }
        Integrator::RKTS54 => {
            solvers::RKTS54::integrate(0.0, x_end, state, &ydot, &odesettings)
        }
        Integrator::RODAS4 => {
            solvers::RODAS4::integrate(0.0, x_end, state, &ydot, &jac_fn, &odesettings)
        }
    }
    .map_err(PropagationError::ODEError)?;

    Ok(PropagationResult {
        time_begin: begin,
        state_begin: *state,
        time_end: end,
        state_end: res.y,
        accepted_steps: res.naccept as u32,
        rejected_steps: res.nreject as u32,
        num_eval: res.nevals as u32,
        odesol: Some(res),
        integrator: settings.integrator,
    })
}

pub fn interp_propresult<const C: usize, T: TimeLike>(
    res: &PropagationResult<C>,
    time: &T,
) -> Result<StateType<C>> {
    use crate::ode::solvers;
    use crate::orbitprop::Integrator;

    let sol = res
        .odesol
        .as_ref()
        .filter(|s| s.dense.is_some())
        .ok_or(PropagationError::NoDenseOutputInSolution)?;
    let time = time.as_instant();
    if time == res.time_begin {
        return Ok(res.state_begin);
    }
    let x = (time - res.time_begin).as_seconds();
    Ok(match res.integrator {
        Integrator::RKV98 => solvers::RKV98::interpolate(x, sol)?,
        Integrator::RKV98NoInterp => solvers::RKV98NoInterp::interpolate(x, sol)?,
        Integrator::RKV87 => solvers::RKV87::interpolate(x, sol)?,
        Integrator::RKV65 => solvers::RKV65::interpolate(x, sol)?,
        Integrator::RKTS54 => solvers::RKTS54::interpolate(x, sol)?,
        Integrator::RODAS4 => solvers::RODAS4::interpolate(x, sol)?,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{consts, orbitprop::SatPropertiesStatic};
    use std::f64::consts::PI;

    use std::fs::File;

    use crate::Duration;
    use std::io::{self, BufRead};

    #[test]
    fn test_short_propagate() -> Result<()> {
        let starttime = Instant::from_datetime(2015, 3, 20, 0, 0, 0.0)?;
        let stoptime = starttime + Duration::from_seconds(0.1);

        let mut state: SimpleState = SimpleState::zeros();

        state[0] = consts::GEO_R;
        state[4] = (consts::MU_EARTH / consts::GEO_R).sqrt();

        let settings = PropSettings {
            abs_error: 1.0e-9,
            rel_error: 1.0e-14,
            gravity_degree: 4,
            ..Default::default()
        };

        let _res1 = propagate(&state, &starttime, &stoptime, &settings, None)?;

        Ok(())
    }

    #[test]
    fn test_propagate() -> Result<()> {
        let starttime = Instant::from_datetime(2015, 3, 20, 0, 0, 0.0)?;
        let stoptime = starttime + Duration::from_days(0.25);

        let mut state: SimpleState = SimpleState::zeros();

        state[0] = consts::GEO_R;
        state[4] = (consts::MU_EARTH / consts::GEO_R).sqrt();

        let mut settings = PropSettings {
            abs_error: 1.0e-9,
            rel_error: 1.0e-14,
            gravity_degree: 4,
            ..Default::default()
        };
        settings.precompute_terms(&starttime, &stoptime)?;

        let res1 = propagate(&state, &starttime, &stoptime, &settings, None)?;
        // Try to propagate back to original time
        let res2 = propagate(&res1.state_end, &stoptime, &starttime, &settings, None)?;
        // See if propagating back to original time matches
        for ix in 0..6_usize {
            assert!((res2.state_end[ix] - state[ix]).abs() < 1.0)
        }

        Ok(())
    }

    #[test]
    fn test_interp() -> Result<()> {
        let starttime = Instant::from_datetime(2015, 3, 20, 0, 0, 0.0)?;
        let stoptime = starttime + Duration::from_days(1.0);

        let mut state: SimpleState = SimpleState::zeros();

        state[0] = consts::GEO_R;
        state[4] = (consts::MU_EARTH / consts::GEO_R).sqrt();

        let settings = PropSettings {
            abs_error: 1.0e-9,
            rel_error: 1.0e-14,
            gravity_degree: 4,
            ..Default::default()
        };

        // Propagate forward
        let res = propagate(&state, &starttime, &stoptime, &settings, None)?;
        // propagate backward to original time
        let res2 = propagate(&res.state_end, &stoptime, &starttime, &settings, None)?;
        // Check that we recover the original state
        for ix in 0..6_usize {
            assert!((state[ix] - res2.state_end[ix]).abs() < 1.0e-3);
        }

        // Check interpolation forward and backward return the same result
        let newtime = starttime + Duration::from_days(0.45);
        let interp = res.interp(&newtime)?;
        let interp2 = res2.interp(&newtime)?;
        for ix in 0..6_usize {
            assert!((interp[ix] - interp2[ix]).abs() < 1e-3);
        }
        Ok(())
    }

    #[test]
    fn test_state_transition() -> Result<()> {
        // Check the state transition matrix:
        // Explicitly propagate two slightly different states,
        // separated by "dstate",
        // and compare with difference in final states as predicted
        // by state transition matrix
        // Note also: drag partials are very small relative to other terms,
        // making it difficult to confirm that calculations are correct.

        let starttime = Instant::from_datetime(2015, 3, 20, 0, 0, 0.0)?;
        let stoptime = starttime + Duration::from_days(0.5);

        let mut state: CovState = CovState::zeros();

        let theta = PI / 6.0;
        state[0] = consts::GEO_R * theta.cos();
        state[2] = consts::GEO_R * theta.sin();
        state[4] = (consts::MU_EARTH / consts::GEO_R).sqrt() * theta.cos();
        state[5] = (consts::MU_EARTH / consts::GEO_R).sqrt() * theta.sin();
        state
            .fixed_view_mut::<6, 6>(0, 1)
            .copy_from(&na::Matrix6::<f64>::identity());

        let settings = PropSettings {
            abs_error: 1.0e-9,
            rel_error: 1.0e-14,
            gravity_degree: 4,
            ..Default::default()
        };

        // Made-up small variations in the state
        let dstate = na::vector![6.0, -10.0, 120.5, 0.1, 0.2, -0.3];

        // Propagate state (and state-transition matrix)
        let res = propagate(&state, &starttime, &stoptime, &settings, None)?;

        // Explicitly propagate state + dstate
        let res2 = propagate(
            &(state.fixed_view::<6, 1>(0, 0) + dstate),
            &starttime,
            &stoptime,
            &settings,
            None,
        )?;

        // Difference in states from explicitly propagating with
        // "dstate" change in initial conditions
        let dstate_prop = res2.state_end - res.state_end.fixed_view::<6, 1>(0, 0);

        // Difference in states estimated from state transition matrix
        let dstate_phi = res.state_end.fixed_view::<6, 6>(0, 1) * dstate;
        for ix in 0..6_usize {
            assert!((dstate_prop[ix] - dstate_phi[ix]).abs() / dstate_prop[ix] < 1e-3);
        }

        Ok(())
    }

    #[test]
    fn test_state_transition_drag() -> Result<()> {
        // Check the state transition matrix:
        // Explicitly propagate two slightly different states,
        // separated by "dstate",
        // and compare with difference in final states as predicted
        // by state transition matrix
        // This version has a low-altitude satellite and we will
        // set a fininte cdaoverm value so that there is drag
        // and we can check drag partials

        let starttime = Instant::from_datetime(2015, 3, 20, 0, 0, 0.0)?;
        let stoptime = starttime + crate::Duration::from_days(0.2);

        let mut state: CovState = CovState::zeros();

        let pgcrf = na::vector![3059573.85713792, 5855177.98848048, -7191.45042671];
        let vgcrf = na::vector![916.08123489, -468.22498656, 7700.48460839];

        // 30-deg inclination
        state.fixed_view_mut::<3, 1>(0, 0).copy_from(&pgcrf);
        state.fixed_view_mut::<3, 1>(3, 0).copy_from(&vgcrf);
        state
            .fixed_view_mut::<6, 6>(0, 1)
            .copy_from(&na::Matrix6::<f64>::identity());

        let settings = PropSettings {
            abs_error: 1.0e-9,
            rel_error: 1.0e-14,
            gravity_degree: 4,
            ..Default::default()
        };

        let satprops: SatPropertiesStatic = SatPropertiesStatic::new(2.0 * 0.3 * 0.1 / 5.0, 0.0);

        // Made-up small variations in the state
        let dstate = na::vector![2.0, -4.0, 20.5, 0.05, 0.02, -0.01];

        // Propagate state (and state-transition matrix)

        let res = propagate(&state, &starttime, &stoptime, &settings, Some(&satprops))?;

        // Explicitly propagate state + dstate
        let res2 = propagate(
            &(state.fixed_view::<6, 1>(0, 0) + dstate),
            &starttime,
            &stoptime,
            &settings,
            Some(&satprops),
        )?;

        // Difference in states from explicitly propagating with
        // "dstate" change in initial conditions
        let dstate_prop = res2.state_end - res.state_end.fixed_view::<6, 1>(0, 0);

        let dstate_phi = res.state_end.fixed_view::<6, 6>(0, 1) * dstate;

        // Are differences within 1%?
        for ix in 0..6_usize {
            assert!((dstate_prop[ix] - dstate_phi[ix]).abs() / dstate_prop[ix] < 0.1);
        }

        Ok(())
    }

    #[test]
    fn test_gps() -> Result<()> {
        let testvecfile = crate::utils::test::get_testvec_dir()
            .unwrap()
            .join("orbitprop")
            .join("ESA0OPSFIN_20233640000_01D_05M_ORB.SP3");

        if !testvecfile.is_file() {
            anyhow::bail!(
                "Required GPS SP3 File: \"{}\" does not exist.
                Clone test vectors from:
                <https://storage.googleapis.com/satkit-testvecs/>
                or using python script in satkit repo: `python/test/download_testvecs.py`
                or set \"SATKIT_TESTVEC_ROOT\" to point to directory",
                testvecfile.to_string_lossy()
            );
        }
        let file: File = File::open(testvecfile.clone())?;

        let times: Vec<crate::Instant> = io::BufReader::new(file)
            .lines()
            .filter(|x: &Result<String, io::Error>| x.as_ref().unwrap().starts_with('*'))
            .map(|rline| -> Result<crate::Instant> {
                let line = rline.unwrap();
                let lvals: Vec<&str> = line.split_whitespace().collect();
                let year: i32 = lvals[1].parse()?;
                let mon: i32 = lvals[2].parse()?;
                let day: i32 = lvals[3].parse()?;
                let hour: i32 = lvals[4].parse()?;
                let min: i32 = lvals[5].parse()?;
                let sec: f64 = lvals[6].parse()?;
                Instant::from_datetime(year, mon, day, hour, min, sec)
            })
            .collect::<Result<Vec<crate::Instant>, _>>()?;

        let file: File = File::open(testvecfile)?;

        let satnum: usize = 20;
        let satstr = format!("PG{}", satnum);
        let pitrf: Vec<na::Vector3<f64>> = io::BufReader::new(file)
            .lines()
            .filter(|x| {
                let rline = &x.as_ref().unwrap()[0..4];
                rline == satstr
            })
            .map(|rline| -> Result<na::Vector3<f64>> {
                let line = rline.unwrap();
                let lvals: Vec<&str> = line.split_whitespace().collect();
                let px: f64 = lvals[1].parse()?;
                let py: f64 = lvals[2].parse()?;
                let pz: f64 = lvals[3].parse()?;
                Ok(na::vector![px, py, pz] * 1.0e3)
            })
            .collect::<Result<Vec<na::Vector3<f64>>>>()?;

        assert!(times.len() == pitrf.len());
        let pgcrf: Vec<na::Vector3<f64>> = pitrf
            .iter()
            .enumerate()
            .map(|(idx, p)| {
                let q = crate::frametransform::qitrf2gcrf(&times[idx]);
                q * p
            })
            .collect();

        let v0 = na::vector![
            2.47130562e+03,
            2.94682753e+03,
            -5.34172176e+02,
            2.32565692e-02
        ];

        let state0 = na::vector![pgcrf[0][0], pgcrf[0][1], pgcrf[0][2], v0[0], v0[1], v0[2]];
        let satprops: SatPropertiesStatic = SatPropertiesStatic::new(0.0, v0[3]);

        let settings = PropSettings {
            enable_interp: true,
            ..Default::default()
        };

        let res = propagate(
            &state0,
            &times[0],
            &times[times.len() - 1],
            &settings,
            Some(&satprops),
        )?;

        // We've propagated over a day; assert that the difference in position on all three coordinate axes
        // is less than 10 meters for all 5-minute intervals
        for iv in 0..(pgcrf.len()) {
            let interp_state = res.interp(&times[iv])?;
            for ix in 0..3 {
                assert!((pgcrf[iv][ix] - interp_state[ix]).abs() < 8.0);
            }
        }

        Ok(())
    }

    #[test]
    fn test_sun_moon_toggles() -> Result<()> {
        // Verify that disabling sun/moon gravity produces different results
        let starttime = Instant::from_datetime(2015, 3, 20, 0, 0, 0.0)?;
        let stoptime = starttime + Duration::from_days(0.5);

        let mut state: SimpleState = SimpleState::zeros();
        state[0] = consts::GEO_R;
        state[4] = (consts::MU_EARTH / consts::GEO_R).sqrt();

        let settings_all = PropSettings {
            abs_error: 1.0e-9,
            rel_error: 1.0e-14,
            gravity_degree: 4,
            ..Default::default()
        };

        let settings_no_sun = PropSettings {
            use_sun_gravity: false,
            ..settings_all.clone()
        };

        let settings_no_moon = PropSettings {
            use_moon_gravity: false,
            ..settings_all.clone()
        };

        let settings_no_both = PropSettings {
            use_sun_gravity: false,
            use_moon_gravity: false,
            ..settings_all.clone()
        };

        let res_all = propagate(&state, &starttime, &stoptime, &settings_all, None)?;
        let res_no_sun = propagate(&state, &starttime, &stoptime, &settings_no_sun, None)?;
        let res_no_moon = propagate(&state, &starttime, &stoptime, &settings_no_moon, None)?;
        let res_no_both = propagate(&state, &starttime, &stoptime, &settings_no_both, None)?;

        // All results should be different from each other
        let pos_all = res_all.state_end.fixed_view::<3, 1>(0, 0);
        let pos_no_sun = res_no_sun.state_end.fixed_view::<3, 1>(0, 0);
        let pos_no_moon = res_no_moon.state_end.fixed_view::<3, 1>(0, 0);
        let pos_no_both = res_no_both.state_end.fixed_view::<3, 1>(0, 0);

        let diff_sun = (pos_all - pos_no_sun).norm();
        let diff_moon = (pos_all - pos_no_moon).norm();
        let diff_both = (pos_all - pos_no_both).norm();

        // Sun and moon perturbations should be measurable over half a day at GEO
        assert!(
            diff_sun > 1.0,
            "Disabling sun gravity should matter, diff = {} m",
            diff_sun
        );
        assert!(
            diff_moon > 1.0,
            "Disabling moon gravity should matter, diff = {} m",
            diff_moon
        );
        assert!(
            diff_both > diff_sun,
            "Disabling both should differ more than just sun"
        );

        Ok(())
    }

    #[test]
    fn test_gravity_degree_order_in_propagator() -> Result<()> {
        // Verify that separate degree and order affect propagation results
        let starttime = Instant::from_datetime(2015, 3, 20, 0, 0, 0.0)?;
        let stoptime = starttime + Duration::from_days(0.25);

        let mut state: SimpleState = SimpleState::zeros();
        // Use an inclined orbit so tesseral harmonics matter
        let r = 7000.0e3;
        let v = (consts::MU_EARTH / r).sqrt();
        let inc: f64 = std::f64::consts::PI / 4.0;
        state[0] = r;
        state[4] = v * inc.cos();
        state[5] = v * inc.sin();

        let settings_full = PropSettings {
            abs_error: 1.0e-9,
            rel_error: 1.0e-14,
            gravity_degree: 8,
            gravity_order: 8,
            ..Default::default()
        };

        let settings_zonal = PropSettings {
            gravity_order: 0,
            ..settings_full.clone()
        };

        let res_full = propagate(&state, &starttime, &stoptime, &settings_full, None)?;
        let res_zonal = propagate(&state, &starttime, &stoptime, &settings_zonal, None)?;

        let pos_full = res_full.state_end.fixed_view::<3, 1>(0, 0);
        let pos_zonal = res_zonal.state_end.fixed_view::<3, 1>(0, 0);
        let diff = (pos_full - pos_zonal).norm();

        assert!(
            diff > 0.1,
            "degree=8,order=8 vs degree=8,order=0 should differ, diff = {} m",
            diff
        );

        Ok(())
    }

    #[test]
    fn test_state_transition_with_toggles() -> Result<()> {
        // Verify state transition matrix still works with sun/moon disabled
        let starttime = Instant::from_datetime(2015, 3, 20, 0, 0, 0.0)?;
        let stoptime = starttime + Duration::from_days(0.5);

        let mut state: CovState = CovState::zeros();
        let theta = PI / 6.0;
        state[0] = consts::GEO_R * theta.cos();
        state[2] = consts::GEO_R * theta.sin();
        state[4] = (consts::MU_EARTH / consts::GEO_R).sqrt() * theta.cos();
        state[5] = (consts::MU_EARTH / consts::GEO_R).sqrt() * theta.sin();
        state
            .fixed_view_mut::<6, 6>(0, 1)
            .copy_from(&na::Matrix6::<f64>::identity());

        let settings = PropSettings {
            abs_error: 1.0e-9,
            rel_error: 1.0e-14,
            gravity_degree: 4,
            use_sun_gravity: false,
            use_moon_gravity: false,
            ..Default::default()
        };

        let dstate = na::vector![6.0, -10.0, 120.5, 0.1, 0.2, -0.3];

        let res = propagate(&state, &starttime, &stoptime, &settings, None)?;
        let res2 = propagate(
            &(state.fixed_view::<6, 1>(0, 0) + dstate),
            &starttime,
            &stoptime,
            &settings,
            None,
        )?;

        let dstate_prop = res2.state_end - res.state_end.fixed_view::<6, 1>(0, 0);
        let dstate_phi = res.state_end.fixed_view::<6, 6>(0, 1) * dstate;

        for ix in 0..6_usize {
            assert!(
                (dstate_prop[ix] - dstate_phi[ix]).abs() / dstate_prop[ix] < 1e-3,
                "State transition matrix mismatch at index {}",
                ix
            );
        }

        Ok(())
    }

    #[test]
    fn test_rodas4_low_orbit() -> Result<()> {
        // Propagate a low orbit (200 km) with drag using RODAS4.
        // Compare result with the default RKV98 integrator to verify consistency.
        let starttime = Instant::from_datetime(2015, 3, 20, 0, 0, 0.0)?;
        let stoptime = starttime + Duration::from_hours(2.0);

        let mut state: SimpleState = SimpleState::zeros();

        // ~200 km altitude circular orbit
        let r = consts::EARTH_RADIUS + 200.0e3;
        state[0] = r;
        state[4] = (consts::MU_EARTH / r).sqrt();

        // Typical small satellite: Cd=2.2, A=0.01 m², mass=1 kg
        let satprops = SatPropertiesStatic::new(2.2 * 0.01 / 1.0, 0.0);

        let settings_rodas4 = PropSettings {
            abs_error: 1.0e-8,
            rel_error: 1.0e-8,
            gravity_degree: 4,
            integrator: crate::orbitprop::Integrator::RODAS4,
            ..Default::default()
        };

        let settings_rkv98 = PropSettings {
            abs_error: 1.0e-8,
            rel_error: 1.0e-8,
            gravity_degree: 4,
            ..Default::default()
        };

        let res_rodas4 = propagate(
            &state, &starttime, &stoptime, &settings_rodas4, Some(&satprops),
        )?;
        let res_rkv98 = propagate(
            &state, &starttime, &stoptime, &settings_rkv98, Some(&satprops),
        )?;

        // Position agreement within 100 m over 2 hours at this altitude
        let pos_diff = (res_rodas4.state_end.fixed_view::<3, 1>(0, 0)
            - res_rkv98.state_end.fixed_view::<3, 1>(0, 0))
        .norm();
        assert!(
            pos_diff < 100.0,
            "RODAS4 vs RKV98 position diff = {} m (expected < 100 m)",
            pos_diff
        );

        Ok(())
    }

    #[test]
    fn test_rodas4_rejects_stm() {
        // RODAS4 should return an error when asked to propagate with STM
        let starttime = Instant::from_datetime(2015, 3, 20, 0, 0, 0.0).unwrap();
        let stoptime = starttime + Duration::from_hours(1.0);

        let mut state: CovState = CovState::zeros();
        state[0] = consts::EARTH_RADIUS + 400.0e3;
        state[4] = (consts::MU_EARTH / state[0]).sqrt();
        state
            .fixed_view_mut::<6, 6>(0, 1)
            .copy_from(&na::Matrix6::<f64>::identity());

        let settings = PropSettings {
            integrator: crate::orbitprop::Integrator::RODAS4,
            ..Default::default()
        };

        let result = propagate(&state, &starttime, &stoptime, &settings, None);
        assert!(result.is_err());
        let err_msg = result.unwrap_err().to_string();
        assert!(
            err_msg.contains("state transition matrix"),
            "Expected STM error, got: {}",
            err_msg
        );
    }
}
