from lfx.base.agents.events import ExceptionWithMessageError
from lfx.log.logger import logger
from lfx.schema.data import Data
from lfx.schema.message import Message
from .custom_base_agent_comp import BaseAgentComponent


class AgentComponent(BaseAgentComponent):
    """在 BaseAgentComponent 基础上，为使用含前置下划线参数名的 MCP tool 提供兼容支持。

    重写的方法
    ----------
    message_response  -- 全程激活 json_schema create_model patch
    json_response     -- 同上
    """

    display_name: str = "Agent(custom)"
    description: str = "Define the agent's instructions, then enter a task to complete using tools."
    documentation: str = "https://docs.langflow.org/agents"
    icon = "bot"
    beta = False
    name = "Agent"

    # ------------------------------------------------------------------
    # MCP patch 工具方法
    # ------------------------------------------------------------------

    @staticmethod
    def _apply_pydantic_patch() -> list[tuple]:
        """确保 lfx.schema.json_schema.create_model patch 已安装（幂等）。

        patch 将 MCP tool args_schema 中前置下划线字段名改为 field_xxx，
        使 Pydantic v2 能正常构建 model，不抛 NameError。
        返回空列表（patch 是进程级永久 patch，无需还原）。
        """
        try:
            import lfx.schema.json_schema as _js  # noqa: PLC2701
            if not getattr(_js, "_mcp_create_model_patched", False):
                from src.custom_mcp_comp import CustomMCPToolsComponent  # noqa: PLC2701
                CustomMCPToolsComponent._install_json_schema_create_model_patch()
        except Exception:
            pass
        return []

    @staticmethod
    def _restore_pydantic_patch(patches: list[tuple]) -> None:
        pass  # no-op：patch 是进程级永久 patch

    # ------------------------------------------------------------------
    # 重写父类方法：在 agent 生命周期内保持 patch 激活
    # ------------------------------------------------------------------

    async def message_response(self) -> Message:
        """重写：全程激活 MCP json_schema patch 后再运行 agent。"""
        patches = self._apply_pydantic_patch()
        try:
            return await super().message_response()
        except (ValueError, TypeError, KeyError, ExceptionWithMessageError):
            raise
        except Exception as e:
            await logger.aerror(f"Unexpected error: {e!s}")
            raise
        finally:
            self._restore_pydantic_patch(patches)

    async def json_response(self) -> Data:
        """重写：全程激活 MCP json_schema patch 后再运行结构化输出 agent。"""
        patches = self._apply_pydantic_patch()
        try:
            return await super().json_response()
        finally:
            self._restore_pydantic_patch(patches)
