from lfx.custom.custom_component.component import Component
from lfx.io import MessageTextInput, Output
from lfx.schema.message import Message


class Message2TextComponent(Component):
    display_name: str = "Message to Text"
    description: str = "Convert a message to a text prompt template."
    icon = "braces"
    name = "Message to Text"
    priority = 0  # Set priority to 0 to make it appear first

    inputs = [
        MessageTextInput(
            name="message",
            display_name="message",
            tool_mode=True,
        ),
    ]

    outputs = [
        Output(display_name="Text", name="text", method="build_text"),
    ]

    async def build_text(self) -> Message:
        return self.message

   

