# EAH AI Flow

A Python package for AI-powered workflows.

## Installation

```bash
pip install eah_langflow_comp
```

## Usage

```python
from eah_langflow_comp import AgentComponent
```

## License

MIT