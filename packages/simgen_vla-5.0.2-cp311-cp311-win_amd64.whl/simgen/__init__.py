"""
SimGen - High-Precision GPU Computing
======================================

Exact arithmetic on GPU with zero accumulation error.

Website: https://simgen.dev
License: Proprietary - All rights reserved
"""

__version__ = "5.0.2"
__author__ = "Clouthier Simulation Labs"

from . import vla

__all__ = [
    "vla",
    "__version__",
]
