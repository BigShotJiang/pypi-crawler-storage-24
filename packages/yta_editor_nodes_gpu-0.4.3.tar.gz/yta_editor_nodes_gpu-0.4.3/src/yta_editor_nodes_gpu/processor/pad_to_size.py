from yta_editor_nodes_gpu.processor.abstract import _NodeProcessorGPU
from yta_editor_time.evaluation_context import EvaluationContext
from yta_video_opengl.pipeline import _OpenGLPipeline

import moderngl


class _PadToSizePipelineGPU(_OpenGLPipeline):
    """
    *For internal use only*

    A OpenGL pipeline to modify the input to center
    it and fill the outside with transparency.

    This pipeline is specific and unique for its the
    Node with the same name.
    """

    @property
    def vertex_shader(
        self
    ):
        return (
            '''
            #version 330

            in vec2 in_vert;
            in vec2 in_texcoord;

            out vec2 v_uv;

            uniform vec2 scale;

            void main() {
                v_uv = in_texcoord;
                vec2 pos = in_vert * scale;
                gl_Position = vec4(pos, 0.0, 1.0);
            }
            '''
        )

    @property
    def fragment_shader(
        self
    ):
        return (
            '''
            #version 330

            uniform sampler2D base_texture;

            in vec2 v_uv;
            out vec4 output_color;

            void main() {
                output_color = texture(base_texture, v_uv);
            }
            '''
        )
    
    @property
    def _textures_expected(
        self
    ) -> dict:
        return {
            'base_texture': 0
        }
    
class PadToSizeNodeProcessorGPU(_NodeProcessorGPU):
    """
    A node to modify the input to center it and fill
    the outside with transparency.
    """

    def __init__(
        self,
        gpu_render_context: 'GPURenderContext'
    ):
        super().__init__(
            gpu_render_context = gpu_render_context,
            opengl_pipeline = _PadToSizePipelineGPU
        )

    def process(
        self,
        render_target: 'RenderTarget',
        inputs: dict[str, moderngl.Texture],
        evaluation_context: EvaluationContext,
        **kwargs
    ) -> 'RenderTarget':
        """
        Rescale the `inputs` provided and write the result
        to the `render_target`.

        The `scale` must be a tuple including the scale
        factors for the width and the height.
        """
        # TODO: I think the 'scale' must be calculated
        # according to the size of the 'base_input' provided
        base_texture = inputs['base_input']

        scale = (
            base_texture.width / render_target.width,
            base_texture.height / render_target.height
        )

        return super().process(
            render_target = render_target,
            inputs = inputs,
            scale = scale
        )