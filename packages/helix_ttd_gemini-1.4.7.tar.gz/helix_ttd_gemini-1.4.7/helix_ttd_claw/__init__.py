"""Helix-TTD Claw - Cryptographic audit trail and DBC identity modules.

[FACT] Distributed Blockchain of Custody for non-repudiable AI governance.
Version: 1.4.7
"""

__version__ = "1.4.7"
