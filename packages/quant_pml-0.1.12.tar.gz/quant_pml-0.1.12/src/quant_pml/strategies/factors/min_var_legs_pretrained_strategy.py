from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import pandas as pd

    from quant_pml.config.trading_config import TradingConfig
    from quant_pml.estimation.covariance.base_cov_estimator import BaseCovEstimator
    from quant_pml.strategies.optimization_data import PredictionData

from copy import deepcopy

import numpy as np

from quant_pml.strategies.factors.pretrained_strategy import PretrainedStrategy
from quant_pml.strategies.optimized.min_var import MinVariance


class MinVarLegsPretrainedStrategy(MinVariance, PretrainedStrategy):
    def __init__(
        self,
        cov_estimator: BaseCovEstimator,
        trading_config: TradingConfig,
        window_size: int,
    ) -> None:
        trading_config = deepcopy(trading_config)
        trading_config.min_exposure = 0.0
        trading_config.total_exposure = 1.0
        super().__init__(
            cov_estimator=cov_estimator,
            trading_config=trading_config,
            window_size=window_size,
        )

    def _get_weights(self, prediction_data: PredictionData, weights_: pd.DataFrame) -> pd.DataFrame:
        long_upper, short_lower = self._get_long_short_sets(prediction_data=prediction_data)

        true_available_assets = self.available_assets
        init_min_exposure = self.trading_config.min_exposure

        self.trading_config.min_exposure = 0.0

        if len(long_upper) > 0:
            self.available_assets = long_upper
            self.trading_config.total_exposure = (
                self.trading_config.max_exposure * len(long_upper) if self.trading_config.max_exposure else 1.0
            )
            weights_long = super()._get_weights(prediction_data=prediction_data, weights_=weights_.loc[:, long_upper]).to_numpy()
            vol_long = (
                weights_long @ self.cov_estimator.predict(prediction_data).loc[long_upper, long_upper].to_numpy() @ weights_long.T
            )
            vol_long = vol_long.item()

            weights_.loc[:, long_upper] = weights_long * 0.20 / (np.sqrt(vol_long * 252))

        if len(short_lower) > 0:
            self.available_assets = short_lower
            self.trading_config.total_exposure = (
                self.trading_config.max_exposure * len(short_lower) if self.trading_config.max_exposure else 1.0
            )
            weights_short = (
                super()._get_weights(prediction_data=prediction_data, weights_=weights_.loc[:, short_lower]).to_numpy()
            )
            vol_short = (
                weights_short
                @ self.cov_estimator.predict(prediction_data).loc[short_lower, short_lower].to_numpy()
                @ weights_short.T
            )
            vol_short = vol_short.item()
            weights_.loc[:, short_lower] = -weights_short * 0.20 / (np.sqrt(vol_short * 252))

        self.trading_config.min_exposure = init_min_exposure

        self.available_assets = true_available_assets
        return weights_
