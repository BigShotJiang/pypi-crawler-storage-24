from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import pandas as pd

    from quant_pml.strategies.optimization_data import PredictionData, TrainingData

from quant_pml.strategies.base_strategy import BaseStrategy


class PretrainedStrategy(BaseStrategy):
    def __init__(self) -> None:
        super().__init__()

    def _fit(self, training_data: TrainingData) -> None:
        pass

    def _get_long_short_sets(self, prediction_data: PredictionData) -> tuple[list[str], list[str]]:
        if prediction_data.macro_features is None:
            msg = "Asset features are required for this strategy."
            raise ValueError(msg)

        features = prediction_data.macro_features
        features = features[features.columns.intersection(self.available_assets)].iloc[0, :]

        long_upper = features[features > 0].index.tolist()
        short_lower = features[features < 0].index.tolist()

        return long_upper, short_lower

    def _get_weights(self, prediction_data: PredictionData, weights_: pd.DataFrame) -> pd.DataFrame:
        long_upper, short_lower = self._get_long_short_sets(prediction_data=prediction_data)

        if len(long_upper) > 0:
            weights_.loc[:, long_upper] = 1.0 / len(long_upper)

        if len(short_lower) > 0:
            weights_.loc[:, short_lower] = -1.0 / len(short_lower)

        return weights_
