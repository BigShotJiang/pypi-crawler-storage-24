# 🩺 Soflytics

**Zero-config data quality for humans.**

Point it at any data source — a DataFrame, a CSV — and get instant profiling, smart validation rules, and a gorgeous visual health report. No YAML, no boilerplate.

## Installation

```bash
pip install soflytics
```

## Quickstart

```python
import soflytics

# Audit any data source
report = soflytics.audit("data.csv")       # CSV file
report = soflytics.audit(df)               # Pandas DataFrame

# View results
report.to_console()     # Pretty terminal output
report.show()           # Opens browser dashboard
report.to_html("report.html")  # Save standalone HTML

# Smart rule suggestions
rules = report.suggest()          # Auto-generated rules
result = report.validate(rules)   # Run validation
```

## CLI

```bash
# Audit a CSV file
soflytics audit data.csv

# Launch interactive dashboard
soflytics dashboard data.csv
```

## What You Get

- **🧠 Auto-Profiling** — Nulls, duplicates, outliers, type mismatches, pattern detection
- **🤖 Smart Rules** — Plain-English rule suggestions based on your data
- **📊 Visual Dashboard** — Per-column health grades, quality heatmaps, drill-down details
- **⚡ Dead Simple** — One function call. Zero configuration.

## License

MIT
