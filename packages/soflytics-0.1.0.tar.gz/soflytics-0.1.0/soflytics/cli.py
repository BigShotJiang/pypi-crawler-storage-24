"""
Soflytics CLI — command-line interface.

Usage:
    soflytics audit data.csv
    soflytics audit data.csv --output html --open
    soflytics audit sample_data.db --table employees
    soflytics audit "sqlite:///my.db" --table users
    soflytics dashboard data.csv
"""

import click


@click.group()
@click.version_option(version="0.1.0", prog_name="soflytics")
def main():
    """🩺 Soflytics — Zero-config data quality for humans."""
    pass


@main.command()
@click.argument("source")
@click.option(
    "--output", "-o",
    type=click.Choice(["console", "html", "json"]),
    default="console",
    help="Output format",
)
@click.option("--table", "-t", default=None, help="Database table name (auto-detects if omitted)")
@click.option("--query", "-q", default=None, help="SQL query to run instead of reading a table")
@click.option("--html-path", default="soflytics_report.html", help="Path for HTML output")
@click.option("--open", "open_browser", is_flag=True, help="Open HTML report in browser")
@click.option("--validate", "run_validate", is_flag=True, help="Also run validation")
def audit(source, output, table, query, html_path, open_browser, run_validate):
    """Audit a data source for quality issues.

    SOURCE can be a file path (CSV, Parquet, JSON, Excel, .db) or a database URL
    (sqlite:///path.db, postgresql://user:pass@host/db, mysql://...).
    """
    import soflytics

    click.echo(f"\n  🩺 Auditing: {source}\n")

    report = soflytics.audit(source, table=table, query=query)

    if run_validate:
        report.validate()

    if output == "console":
        report.to_console()
    elif output == "html":
        path = report.to_html(html_path)
        click.echo(f"  📄 Report saved: {path}")
        if open_browser:
            import webbrowser
            webbrowser.open(f"file://{path}")
    elif output == "json":
        click.echo(report.to_json())


@main.command()
@click.argument("source")
@click.option("--table", "-t", default=None, help="Database table name")
@click.option("--port", "-p", default=8765, help="Dashboard port")
def dashboard(source, table, port):
    """Launch the interactive dashboard for a data source.

    SOURCE can be a file path or database URL.
    """
    import soflytics

    click.echo(f"\n  🩺 Profiling: {source}\n")
    report = soflytics.audit(source, table=table)
    report.show(port=port)


if __name__ == "__main__":
    main()
