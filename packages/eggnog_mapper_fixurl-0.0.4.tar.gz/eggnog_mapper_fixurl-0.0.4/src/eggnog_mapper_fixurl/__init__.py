"""Fix outdated URLS in eggnog-mapper's download_eggnog_data.py
"""

from eggnog_mapper_fixurl.version import __version__
from eggnog_mapper_fixurl.eggnog_mapper_fixurl import fixurl

fixurl()
