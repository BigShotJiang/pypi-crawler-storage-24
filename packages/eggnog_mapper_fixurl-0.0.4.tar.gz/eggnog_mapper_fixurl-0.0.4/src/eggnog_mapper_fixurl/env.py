import tomllib
import os
from pathlib import Path
from shutil import which

EGGNOG_MAPPER_FIXURL_CONFIG = os.environ.get(
    'EGGNOG_MAPPER_FIXURL_CONFIG',
    Path.home() / '.eggnog-mapper-fixurl-config.toml'
)

if Path(EGGNOG_MAPPER_FIXURL_CONFIG).is_file():
    with open(EGGNOG_MAPPER_FIXURL_CONFIG, 'rb') as f:
        config = tomllib.load(f)
else:
    config = {}

DOWNLOAD_EGGNOG_DATA_PYSCRIPT = os.environ.get(
    'DOWNLOAD_EGGNOG_DATA_PYSCRIPT',
    config.get('download_eggnog_data_pysript', which('download_eggnog_data.py'))
)
