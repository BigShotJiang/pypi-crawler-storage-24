const source{{INDEX}} = vtk.Filters.Sources.vtkPlaneSource.newInstance({
  origin: [{{ORIGIN_X}}, {{ORIGIN_Y}}, {{ORIGIN_Z}}],
  point1: [{{POINT1_X}}, {{POINT1_Y}}, {{POINT1_Z}}],
  point2: [{{POINT2_X}}, {{POINT2_Y}}, {{POINT2_Z}}],
  xResolution: {{I_RESOLUTION}},
  yResolution: {{J_RESOLUTION}},
});
