from abc import ABC, abstractmethod
from typing import List


class Pager(ABC):
    """Create pages"""

    @abstractmethod
    def create_pages(self, messages: List[str], next_key: str, previous_key: str) -> List[str]:
        """modify list of string with navigation options"""


class DefaultPager(Pager):
    """add next and previous key and text"""

    def create_pages(self, messages: List[str], next_key: str, previous_key: str) -> List[str]:
        next_text = f"\n{next_key} Next"
        previous_text = f"\n{previous_key} Previous"

        last_index = len(messages) - 1
        pages: List[str] = []
        for index, content in enumerate(messages):
            msg = content
            if index > 0:
                msg += previous_text
            if index < last_index:
                msg += next_text
            # MessageSplitter is budget-aware; no need to truncate here.
            pages.append(msg)

        return pages


class PagerFactory:
    @staticmethod
    def default():
        return DefaultPager()
