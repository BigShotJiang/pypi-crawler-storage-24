from abc import ABC, abstractmethod
from typing import List


class MessageSplitter(ABC):
    """Split response message into manageable chunks"""

    @abstractmethod
    def should_split(self, message: str) -> bool:
        """check if the message requires splitting"""

    @abstractmethod
    def split(self, message: str) -> List[str]:
        """split message into chunks"""


class DefaultMessageSplitter(MessageSplitter):
    """Split messages into a defined chunk size"""

    message_limit: int = 140
    next_text = "\n# Next"
    previous_text = "\n0 Previous"

    def should_split(self, message: str) -> bool:
        return len(message) > self.message_limit

    def split(self, message: str) -> List[str]:
        lines = message.splitlines(keepends=True)
        pages: List[str] = []
        i = 0

        while i < len(lines):
            has_prev = bool(pages)

            # Reserve next budget for every page
            reserved = (len(self.previous_text) if has_prev else 0) + len(self.next_text)
            budget = max(0, self.message_limit - reserved)

            content = ""
            while i < len(lines) and len(content) + len(lines[i]) <= budget:
                content += lines[i]
                i += 1

            # If a single line is longer than budget, slice it.
            if content == "":
                chunk = lines[i][:budget]
                remainder = lines[i][budget:]
                content = chunk
                if remainder:
                    lines[i] = remainder
                else:
                    i += 1

            pages.append(content.rstrip("\n"))

        pages = list(filter(lambda m: len(m.strip()) > 0, pages))
        return pages


class MessageSplitterFactory:
    @staticmethod
    def default() -> MessageSplitter:
        return DefaultMessageSplitter()
