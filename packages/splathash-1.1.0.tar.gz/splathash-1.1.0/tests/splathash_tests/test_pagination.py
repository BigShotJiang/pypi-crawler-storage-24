from splathash.engine.pagination.pager.pager import PagerFactory
from splathash.engine.pagination.splitter.message_splitter import MessageSplitterFactory


def _make_long_menu_message() -> str:
    base = (
        "The Real Man Movie Premiering @ Royal View,\n"
        "National Theatre, Liberia Road, Accra, Ghana\n"
        "at 3:00 PM\n"
        "1. Buy my Ticket.\n"
        "2. Buy for Others.\n"
    )

    filler_lines = []
    # Create many additional line-based menu entries so pagination is guaranteed.
    for i in range(3, 80):
        filler_lines.append(
            f"{i}. Extra option {i} - some extra text to grow the message content.\n"
        )

    return base + "".join(filler_lines)


def test_splitter_pager_produces_expected_hints_and_lengths():
    splitter = MessageSplitterFactory.default()
    pager = PagerFactory.default()

    message = _make_long_menu_message()

    assert splitter.should_split(message)

    content_pages = splitter.split(message)
    assert len(content_pages) >= 2

    # Splitter should return content pages only (no nav hints appended).
    for cp in content_pages:
        assert "# Next" not in cp
        assert "0 Previous" not in cp

    pages = pager.create_pages(content_pages, next_key="#", previous_key="0")
    assert len(pages) == len(content_pages)
    assert len(pages) >= 2

    last_index = len(pages) - 1
    for index, page in enumerate(pages):
        # Safety: hints must stay within the screen budget.
        assert len(page) <= 140

        if index == 0:
            assert "# Next" in page
            assert "0 Previous" not in page
        elif index == last_index:
            assert "0 Previous" in page
            assert "# Next" not in page
        else:
            assert "# Next" in page
            assert "0 Previous" in page
            # Pager appends "Previous" first, then "Next".
            assert page.find("0 Previous") < page.find("# Next")
