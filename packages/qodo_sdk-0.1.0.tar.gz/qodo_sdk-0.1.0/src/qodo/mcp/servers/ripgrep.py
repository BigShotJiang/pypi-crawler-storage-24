"""
Enhanced Ripgrep MCP server.

Provides fast code search using ripgrep with bundled
binary detection and JSON output parsing.
"""

from __future__ import annotations

import json
import logging
import platform
import shutil
import subprocess
from typing import Any

from qodo.mcp.base_server import BuiltinTool, InternalMCPBaseServer

logger = logging.getLogger(__name__)


class RipgrepServerEnhanced(InternalMCPBaseServer):
    """
    Enhanced Ripgrep server.

    Provides 2 tools (both auto-approved):
    - ripgrep_search
    - ripgrep_file_types
    """

    def __init__(self) -> None:
        self._initialized = False
        self._ripgrep_path: str | None = None
        self._using_bundled_binary = False

    @property
    def name(self) -> str:
        return "ripgrep"

    @property
    def version(self) -> str:
        return "1.1.0"

    async def initialize(self) -> bool:
        """Initialize the ripgrep server by finding the ripgrep binary."""
        try:
            # Try to find ripgrep
            self._ripgrep_path = self._find_ripgrep()

            if not self._ripgrep_path:
                logger.warning(
                    "[@qodo/sdk] ripgrep (rg) not found. The ripgrep_search tool will be unavailable.\n"
                    "  Install ripgrep for fast code search: https://github.com/BurntSushi/ripgrep#installation\n"
                    "  - macOS: brew install ripgrep\n"
                    "  - Ubuntu/Debian: apt install ripgrep\n"
                    "  - Windows: choco install ripgrep"
                )
                # ripgrep binary not available; tool will be disabled via self._initialized = False
                return True

            # Verify it works
            result = subprocess.run(
                [self._ripgrep_path, "--version"],
                capture_output=True,
                text=True,
                timeout=5,
            )
            if result.returncode == 0:
                self._initialized = True

        except Exception as e:
            # Version check or binary discovery failed after finding a path;
            # log so the issue is diagnosable rather than silently disabling the tool
            logger.warning("[@qodo/sdk] ripgrep initialization failed: %s", e)

        # Always return True to not block MCP handshake
        return True

    def _find_ripgrep(self) -> str | None:
        """Find ripgrep binary in system PATH."""
        # Check for rg in PATH
        rg_path = shutil.which("rg")
        if rg_path:
            return rg_path

        # Windows-specific check
        if platform.system() == "Windows":
            rg_path = shutil.which("rg.exe")
            if rg_path:
                return rg_path

        return None

    async def list_tools(self) -> dict[str, list[BuiltinTool]]:
        """List all ripgrep tools."""
        if not self._initialized:
            return {"tools": []}

        tools = [
            BuiltinTool(
                name="ripgrep_search",
                description="Search for patterns in files using ripgrep. Supports regex patterns, file type filtering, and various search options.",
                input_schema={
                    "type": "object",
                    "properties": {
                        "pattern": {
                            "type": "string",
                            "description": "The search pattern (can be regex)",
                        },
                        "path": {
                            "type": "string",
                            "description": "Directory or file path to search in (default: '.')",
                            "default": ".",
                        },
                        "fileTypes": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "File types to include (e.g., ['js', 'ts', 'py'])",
                        },
                        "caseSensitive": {
                            "type": "boolean",
                            "description": "Case sensitive search (default: false)",
                            "default": False,
                        },
                        "maxResults": {
                            "type": "number",
                            "description": "Maximum number of results (default: 100)",
                            "default": 100,
                        },
                    },
                    "required": ["pattern", "fileTypes"],
                },
                auto_approved=True,
            ),
            BuiltinTool(
                name="ripgrep_file_types",
                description="List all supported file types that can be used with ripgrep",
                input_schema={
                    "type": "object",
                    "properties": {},
                    "required": [],
                },
                auto_approved=True,
            ),
        ]
        return {"tools": tools}

    async def call_tool(
        self,
        request: dict[str, Any],
        extra: dict[str, Any] | None = None,
    ) -> Any:
        """Execute a ripgrep tool."""
        if not self._initialized or not self._ripgrep_path:
            return {
                "content": [
                    {"type": "text", "text": "ripgrep is not available. Please install ripgrep."}
                ],
                "isError": True,
            }

        name = request.get("name", "")
        args = request.get("arguments", {})

        try:
            if name == "ripgrep_search":
                return await self._ripgrep_search(args)
            elif name == "ripgrep_file_types":
                return await self._ripgrep_file_types()
            else:
                return {
                    "content": [{"type": "text", "text": f"Unknown tool: {name}"}],
                    "isError": True,
                }
        except Exception as e:
            return {"content": [{"type": "text", "text": str(e)}], "isError": True}

    async def _ripgrep_search(self, args: dict[str, Any]) -> dict[str, Any]:
        """Execute ripgrep search."""
        pattern = args.get("pattern", "")
        search_path = args.get("path", ".")
        file_types = args.get("fileTypes", [])
        case_sensitive = args.get("caseSensitive", False)
        max_results = args.get("maxResults", 100)

        if not pattern:
            return {"content": [{"type": "text", "text": "Pattern required"}], "isError": True}

        # Build ripgrep command
        assert self._ripgrep_path is not None
        rg_args: list[str] = [self._ripgrep_path, "--json"]

        if not case_sensitive:
            rg_args.append("--ignore-case")

        # Add file type filters
        if file_types and len(file_types) > 1:
            rg_args.extend(["--glob", f"*.{{{','.join(file_types)}}}"])
        elif file_types and len(file_types) == 1:
            rg_args.extend(["--glob", f"*.{file_types[0]}"])

        if max_results:
            rg_args.extend(["--max-count", str(max_results)])

        # Performance improvements
        rg_args.append("--text")
        rg_args.append("--no-heading")

        rg_args.extend([pattern, search_path])

        try:
            result = subprocess.run(
                rg_args,
                capture_output=True,
                text=True,
                timeout=30,
            )

            # Parse JSON output
            matches = []
            for line in result.stdout.strip().split("\n"):
                if not line.strip():
                    continue
                try:
                    parsed = json.loads(line)
                    if parsed.get("type") == "match":
                        data = parsed.get("data", {})
                        matches.append(
                            {
                                "file": data.get("path", {}).get("text", ""),
                                "line": data.get("line_number", 0),
                                "content": data.get("lines", {}).get("text", ""),
                            }
                        )
                except json.JSONDecodeError:
                    continue

            output = {
                "success": True,
                "matches": matches,
                "totalMatches": len(matches),
                "searchPath": search_path,
                "pattern": pattern,
            }

            return {
                "content": [{"type": "text", "text": json.dumps(output, indent=2)}],
                "isError": False,
            }

        except subprocess.TimeoutExpired:
            return {
                "content": [{"type": "text", "text": "Ripgrep search timed out after 30 seconds"}],
                "isError": True,
            }

    async def _ripgrep_file_types(self) -> dict[str, Any]:
        """Get list of supported file types."""
        try:
            assert self._ripgrep_path is not None
            result = subprocess.run(
                [self._ripgrep_path, "--type-list"],
                capture_output=True,
                text=True,
                timeout=10,
            )

            if result.returncode != 0:
                return {
                    "content": [
                        {"type": "text", "text": f"Failed to get file types: {result.stderr}"}
                    ],
                    "isError": True,
                }

            # Parse type list output
            types = []
            for line in result.stdout.strip().split("\n"):
                parts = line.split(":")
                if len(parts) >= 2:
                    name = parts[0].strip()
                    extensions = [ext.strip().replace("*.", "") for ext in parts[1].split(",")]
                    types.append({"name": name, "extensions": extensions})

            return {
                "content": [
                    {
                        "type": "text",
                        "text": json.dumps({"success": True, "fileTypes": types}, indent=2),
                    }
                ],
                "isError": False,
            }

        except subprocess.TimeoutExpired:
            return {
                "content": [{"type": "text", "text": "Timeout getting file types"}],
                "isError": True,
            }
