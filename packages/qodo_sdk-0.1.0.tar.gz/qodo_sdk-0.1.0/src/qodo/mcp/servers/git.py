"""
Enhanced Git MCP server.

Provides Git operations with proper error handling
and output formatting.
"""

from __future__ import annotations

import json
import subprocess
from typing import Any

from qodo.mcp.base_server import BuiltinTool, InternalMCPBaseServer


def run_git_command(args: list[str], cwd: str) -> tuple[str, str, int]:
    """
    Run a git command synchronously.

    Args:
        args: Git command arguments (without 'git' prefix).
        cwd: Working directory for the command.

    Returns:
        Tuple of (stdout, stderr, return_code).
    """
    try:
        result = subprocess.run(
            ["git"] + args,
            cwd=cwd,
            capture_output=True,
            text=True,
            timeout=60,
        )
        return result.stdout, result.stderr, result.returncode
    except subprocess.TimeoutExpired:
        return "", "Command timed out after 60 seconds", 1
    except Exception as e:
        return "", str(e), 1


def is_git_error(stdout: str, stderr: str, code: int) -> bool:
    """
    Determine if a git command result represents an error.

    Git often writes informational messages to stderr that aren't errors.
    """
    if code != 0:
        return True

    if not stderr:
        return False

    # Check for common error patterns in stderr
    error_patterns = [
        "error:",
        "fatal:",
        "warning:",
        "not a git repository",
        "does not exist",
        "cannot",
        "failed",
        "invalid",
        "unknown",
        "ambiguous",
    ]

    stderr_lower = stderr.lower()
    return any(pattern in stderr_lower for pattern in error_patterns)


def format_git_output(stdout: str, stderr: str, code: int) -> str:
    """Format output from a git command."""
    if stdout.strip():
        return stdout

    if stderr.strip() and not is_git_error(stdout, stderr, code):
        return stderr

    if is_git_error(stdout, stderr, code):
        parts = []
        if stdout.strip():
            parts.append(stdout.strip())
        if stderr.strip():
            parts.append(stderr.strip())
        return "\n".join(parts) or "Git command failed"

    return stdout or stderr or "No output"


class GitServerEnhanced(InternalMCPBaseServer):
    """
    Enhanced Git server.

    Provides 13 git tools:
    - git_status (auto-approved)
    - git_diff_unstaged (auto-approved)
    - git_diff_staged (auto-approved)
    - git_diff (auto-approved)
    - git_diff_files (auto-approved)
    - git_log (auto-approved)
    - git_show (auto-approved)
    - git_add
    - git_reset
    - git_commit
    - git_init
    - git_create_branch
    - git_checkout
    """

    def __init__(self) -> None:
        self._initialized = False

    @property
    def name(self) -> str:
        return "git"

    @property
    def version(self) -> str:
        return "1.0.0"

    async def initialize(self) -> bool:
        """Initialize the git server by checking if git is available."""
        try:
            stdout, stderr, code = run_git_command(["--version"], ".")
            if code == 0:
                self._initialized = True
            else:
                print(f"[GitServer] git not available: {stderr.strip() or stdout.strip()}")
        except Exception as e:
            print(f"[GitServer] failed to check git: {e}")

        # Always return True to not block MCP handshake
        return True

    async def list_tools(self) -> dict[str, list[BuiltinTool]]:
        """List all git tools."""
        if not self._initialized:
            return {"tools": []}

        tools = [
            BuiltinTool(
                name="git_status",
                description="Shows the working tree status",
                input_schema={
                    "type": "object",
                    "properties": {
                        "repo_path": {"type": "string", "description": "Path to Git repository"},
                    },
                    "required": ["repo_path"],
                },
                auto_approved=True,
            ),
            BuiltinTool(
                name="git_diff_unstaged",
                description="Shows changes in working directory not yet staged",
                input_schema={
                    "type": "object",
                    "properties": {
                        "repo_path": {"type": "string", "description": "Path to Git repository"},
                    },
                    "required": ["repo_path"],
                },
                auto_approved=True,
            ),
            BuiltinTool(
                name="git_diff_staged",
                description="Shows changes that are staged for commit",
                input_schema={
                    "type": "object",
                    "properties": {
                        "repo_path": {"type": "string", "description": "Path to Git repository"},
                    },
                    "required": ["repo_path"],
                },
                auto_approved=True,
            ),
            BuiltinTool(
                name="git_diff",
                description="Shows differences between branches or commits",
                input_schema={
                    "type": "object",
                    "properties": {
                        "repo_path": {"type": "string", "description": "Path to Git repository"},
                        "target": {
                            "type": "string",
                            "description": "Target branch or commit to compare with",
                        },
                    },
                    "required": ["repo_path", "target"],
                },
                auto_approved=True,
            ),
            BuiltinTool(
                name="git_diff_files",
                description="Returns file changes between branches or commits as a dictionary",
                input_schema={
                    "type": "object",
                    "properties": {
                        "repo_path": {"type": "string", "description": "Path to Git repository"},
                        "target": {
                            "type": "string",
                            "description": "Target branch or commit to compare with",
                        },
                    },
                    "required": ["repo_path", "target"],
                },
                auto_approved=True,
            ),
            BuiltinTool(
                name="git_log",
                description="Shows the commit logs",
                input_schema={
                    "type": "object",
                    "properties": {
                        "repo_path": {"type": "string", "description": "Path to Git repository"},
                        "max_count": {
                            "type": "number",
                            "description": "Maximum number of commits",
                            "default": 10,
                        },
                    },
                    "required": ["repo_path"],
                },
                auto_approved=True,
            ),
            BuiltinTool(
                name="git_show",
                description="Shows the contents of a commit",
                input_schema={
                    "type": "object",
                    "properties": {
                        "repo_path": {"type": "string", "description": "Path to Git repository"},
                        "revision": {"type": "string", "description": "The revision to show"},
                    },
                    "required": ["repo_path", "revision"],
                },
                auto_approved=True,
            ),
            BuiltinTool(
                name="git_add",
                description="Adds file contents to the staging area",
                input_schema={
                    "type": "object",
                    "properties": {
                        "repo_path": {"type": "string", "description": "Path to Git repository"},
                        "files": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "Array of file paths to stage",
                        },
                    },
                    "required": ["repo_path", "files"],
                },
                auto_approved=False,
            ),
            BuiltinTool(
                name="git_reset",
                description="Unstages all staged changes",
                input_schema={
                    "type": "object",
                    "properties": {
                        "repo_path": {"type": "string", "description": "Path to Git repository"},
                    },
                    "required": ["repo_path"],
                },
                auto_approved=False,
            ),
            BuiltinTool(
                name="git_commit",
                description="Records changes to the repository",
                input_schema={
                    "type": "object",
                    "properties": {
                        "repo_path": {"type": "string", "description": "Path to Git repository"},
                        "message": {"type": "string", "description": "Commit message"},
                    },
                    "required": ["repo_path", "message"],
                },
                auto_approved=False,
            ),
            BuiltinTool(
                name="git_init",
                description="Initializes a Git repository",
                input_schema={
                    "type": "object",
                    "properties": {
                        "repo_path": {"type": "string", "description": "Path to initialize"},
                    },
                    "required": ["repo_path"],
                },
                auto_approved=False,
            ),
            BuiltinTool(
                name="git_create_branch",
                description="Creates a new branch",
                input_schema={
                    "type": "object",
                    "properties": {
                        "repo_path": {"type": "string", "description": "Path to Git repository"},
                        "branch_name": {"type": "string", "description": "Name of the new branch"},
                        "start_point": {
                            "type": "string",
                            "description": "Starting point",
                            "default": "",
                        },
                    },
                    "required": ["repo_path", "branch_name"],
                },
                auto_approved=False,
            ),
            BuiltinTool(
                name="git_checkout",
                description="Switches branches",
                input_schema={
                    "type": "object",
                    "properties": {
                        "repo_path": {"type": "string", "description": "Path to Git repository"},
                        "branch_name": {
                            "type": "string",
                            "description": "Name of branch to checkout",
                        },
                    },
                    "required": ["repo_path", "branch_name"],
                },
                auto_approved=False,
            ),
        ]
        return {"tools": tools}

    async def call_tool(
        self,
        request: dict[str, Any],
        extra: dict[str, Any] | None = None,
    ) -> Any:
        """Execute a git tool."""
        if not self._initialized:
            return {
                "content": [{"type": "text", "text": "Git server not initialized."}],
                "isError": True,
            }

        name = request.get("name", "")
        args = request.get("arguments", {})

        try:
            if name == "git_status":
                return await self._git_status(args)
            elif name == "git_diff_unstaged":
                return await self._git_diff_unstaged(args)
            elif name == "git_diff_staged":
                return await self._git_diff_staged(args)
            elif name == "git_diff":
                return await self._git_diff(args)
            elif name == "git_diff_files":
                return await self._git_diff_files(args)
            elif name == "git_log":
                return await self._git_log(args)
            elif name == "git_show":
                return await self._git_show(args)
            elif name == "git_add":
                return await self._git_add(args)
            elif name == "git_reset":
                return await self._git_reset(args)
            elif name == "git_commit":
                return await self._git_commit(args)
            elif name == "git_init":
                return await self._git_init(args)
            elif name == "git_create_branch":
                return await self._git_create_branch(args)
            elif name == "git_checkout":
                return await self._git_checkout(args)
            else:
                return {
                    "content": [{"type": "text", "text": f"Unknown tool: {name}"}],
                    "isError": True,
                }
        except Exception as e:
            return {"content": [{"type": "text", "text": str(e)}], "isError": True}

    async def _git_status(self, args: dict[str, Any]) -> dict[str, Any]:
        repo_path = args.get("repo_path", ".")
        stdout, stderr, code = run_git_command(["status", "--porcelain=1", "-b"], repo_path)
        return {
            "content": [{"type": "text", "text": format_git_output(stdout, stderr, code)}],
            "isError": is_git_error(stdout, stderr, code),
        }

    async def _git_diff_unstaged(self, args: dict[str, Any]) -> dict[str, Any]:
        repo_path = args.get("repo_path", ".")
        stdout, stderr, code = run_git_command(["diff"], repo_path)
        output = format_git_output(stdout, stderr, code) or "(no changes)"
        return {
            "content": [{"type": "text", "text": output}],
            "isError": is_git_error(stdout, stderr, code),
        }

    async def _git_diff_staged(self, args: dict[str, Any]) -> dict[str, Any]:
        repo_path = args.get("repo_path", ".")
        stdout, stderr, code = run_git_command(["diff", "--cached"], repo_path)
        output = format_git_output(stdout, stderr, code) or "(no staged changes)"
        return {
            "content": [{"type": "text", "text": output}],
            "isError": is_git_error(stdout, stderr, code),
        }

    async def _git_diff(self, args: dict[str, Any]) -> dict[str, Any]:
        repo_path = args.get("repo_path", ".")
        target = args.get("target", "HEAD")
        stdout, stderr, code = run_git_command(["diff"] + target.split(), repo_path)
        output = format_git_output(stdout, stderr, code) or "(no diff)"
        return {
            "content": [{"type": "text", "text": output}],
            "isError": is_git_error(stdout, stderr, code),
        }

    async def _git_diff_files(self, args: dict[str, Any]) -> dict[str, Any]:
        repo_path = args.get("repo_path", ".")
        target = args.get("target", "HEAD")

        stdout, stderr, code = run_git_command(
            ["diff", "--name-status"] + target.split(), repo_path
        )
        if is_git_error(stdout, stderr, code):
            return {
                "content": [{"type": "text", "text": format_git_output(stdout, stderr, code)}],
                "isError": True,
            }

        file_changes = {}
        for line in stdout.strip().split("\n"):
            if not line.strip():
                continue
            parts = line.split("\t")
            if len(parts) >= 2:
                status, filename = parts[0], parts[1]
                file_changes[filename] = {"status": status}

        return {
            "content": [{"type": "text", "text": json.dumps(file_changes, indent=2)}],
            "isError": False,
        }

    async def _git_log(self, args: dict[str, Any]) -> dict[str, Any]:
        repo_path = args.get("repo_path", ".")
        max_count = args.get("max_count", 10)
        stdout, stderr, code = run_git_command(
            ["log", f"-n{max_count}", "--pretty=format:%H|%an|%ad|%s", "--date=iso"],
            repo_path,
        )
        return {
            "content": [{"type": "text", "text": format_git_output(stdout, stderr, code)}],
            "isError": is_git_error(stdout, stderr, code),
        }

    async def _git_show(self, args: dict[str, Any]) -> dict[str, Any]:
        repo_path = args.get("repo_path", ".")
        revision = args.get("revision")
        if not revision:
            return {"content": [{"type": "text", "text": "Revision required"}], "isError": True}

        stdout, stderr, code = run_git_command(["show", revision], repo_path)
        return {
            "content": [{"type": "text", "text": format_git_output(stdout, stderr, code)}],
            "isError": is_git_error(stdout, stderr, code),
        }

    async def _git_add(self, args: dict[str, Any]) -> dict[str, Any]:
        repo_path = args.get("repo_path", ".")
        files = args.get("files", [])
        if not files:
            return {"content": [{"type": "text", "text": "No files specified"}], "isError": True}

        stdout, stderr, code = run_git_command(["add"] + files, repo_path)
        output = format_git_output(stdout, stderr, code) or "Files staged successfully."
        return {
            "content": [{"type": "text", "text": output}],
            "isError": is_git_error(stdout, stderr, code),
        }

    async def _git_reset(self, args: dict[str, Any]) -> dict[str, Any]:
        repo_path = args.get("repo_path", ".")
        stdout, stderr, code = run_git_command(["reset"], repo_path)
        output = format_git_output(stdout, stderr, code) or "Reset successful."
        return {
            "content": [{"type": "text", "text": output}],
            "isError": is_git_error(stdout, stderr, code),
        }

    async def _git_commit(self, args: dict[str, Any]) -> dict[str, Any]:
        repo_path = args.get("repo_path", ".")
        message = args.get("message")
        if not message:
            return {
                "content": [{"type": "text", "text": "Commit message required"}],
                "isError": True,
            }

        stdout, stderr, code = run_git_command(["commit", "-m", message], repo_path)
        return {
            "content": [{"type": "text", "text": format_git_output(stdout, stderr, code)}],
            "isError": is_git_error(stdout, stderr, code),
        }

    async def _git_init(self, args: dict[str, Any]) -> dict[str, Any]:
        repo_path = args.get("repo_path", ".")
        stdout, stderr, code = run_git_command(["init"], repo_path)
        return {
            "content": [{"type": "text", "text": format_git_output(stdout, stderr, code)}],
            "isError": is_git_error(stdout, stderr, code),
        }

    async def _git_create_branch(self, args: dict[str, Any]) -> dict[str, Any]:
        repo_path = args.get("repo_path", ".")
        branch_name = args.get("branch_name")
        if not branch_name:
            return {"content": [{"type": "text", "text": "Branch name required"}], "isError": True}

        start_point = args.get("start_point", "")
        branch_args = ["branch", branch_name]
        if start_point:
            branch_args.append(start_point)

        stdout, stderr, code = run_git_command(branch_args, repo_path)
        output = format_git_output(stdout, stderr, code) or f"Branch '{branch_name}' created."
        return {
            "content": [{"type": "text", "text": output}],
            "isError": is_git_error(stdout, stderr, code),
        }

    async def _git_checkout(self, args: dict[str, Any]) -> dict[str, Any]:
        repo_path = args.get("repo_path", ".")
        branch_name = args.get("branch_name")
        if not branch_name:
            return {"content": [{"type": "text", "text": "Branch name required"}], "isError": True}

        stdout, stderr, code = run_git_command(["checkout", branch_name], repo_path)
        output = format_git_output(stdout, stderr, code) or f"Checked out to '{branch_name}'."
        return {
            "content": [{"type": "text", "text": output}],
            "isError": is_git_error(stdout, stderr, code),
        }
