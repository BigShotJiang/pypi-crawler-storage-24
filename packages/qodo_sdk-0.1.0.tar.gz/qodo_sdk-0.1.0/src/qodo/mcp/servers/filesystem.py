"""
Enhanced filesystem MCP server.

Provides file system operations with path validation
against allowed directories.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from qodo.mcp.base_server import BuiltinTool, InternalMCPBaseServer

# Default excluded directories for directory_tree
DEFAULT_EXCLUDED_DIRS = [
    ".git",
    "node_modules",
    ".idea",
    ".vscode",
    "dist",
    "build",
    "coverage",
    ".next",
    ".turbo",
    ".cache",
    "out",
    "target",
    "venv",
    ".venv",
    "__pycache__",
    ".pytest_cache",
    ".mypy_cache",
]

DEFAULT_MAX_DEPTH = 3
DEFAULT_MAX_DIRECTORIES = 2000


def matches_pattern(name: str, pattern: str) -> bool:
    """Check if a name matches a glob-like pattern."""
    lower_name = name.lower()
    lower_pattern = pattern.lower()

    if not lower_pattern:
        return False

    if lower_pattern == "*":
        return True

    if "*" in lower_pattern:
        parts = [p for p in lower_pattern.split("*") if p]
        current_index = 0
        for part in parts:
            index = lower_name.find(part, current_index)
            if index == -1:
                return False
            current_index = index + len(part)
        return True

    return lower_name == lower_pattern


class FilesystemServerEnhanced(InternalMCPBaseServer):
    """
    Enhanced filesystem server with path validation.

    Provides 10 filesystem tools:
    - read_files (auto-approved)
    - write_file
    - edit_file
    - create_directory
    - list_files_in_directories (auto-approved)
    - directory_tree (auto-approved)
    - move_file
    - get_file_info (auto-approved)
    - list_allowed_directories (auto-approved)
    - delete_files
    """

    def __init__(self, allowed_directories: list[str] | None = None):
        self._allowed_directories = [str(Path(d).resolve()) for d in (allowed_directories or [])]

    @property
    def name(self) -> str:
        return "filesystem"

    @property
    def version(self) -> str:
        return "1.0.0"

    async def initialize(self) -> bool:
        """Initialize the filesystem server."""
        for directory in self._allowed_directories:
            try:
                if not os.path.exists(directory):
                    print(f"Warning: Directory {directory} does not exist")
                elif not os.access(directory, os.R_OK):
                    print(f"Warning: Directory {directory} is not readable")
            except Exception as e:
                print(f"Warning: Cannot access directory {directory}: {e}")
        return True

    async def list_tools(self) -> dict[str, list[BuiltinTool]]:
        """List all filesystem tools."""
        tools = [
            BuiltinTool(
                name="read_files",
                description="Read the contents of one or more files. Returns the content of each file along with its path.",
                input_schema={
                    "type": "object",
                    "properties": {
                        "paths": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "Array of file paths to read",
                        },
                    },
                    "required": ["paths"],
                },
                auto_approved=True,
            ),
            BuiltinTool(
                name="write_file",
                description="Create a new file or completely overwrite an existing file with new content.",
                input_schema={
                    "type": "object",
                    "properties": {
                        "path": {"type": "string", "description": "Path where to write the file"},
                        "content": {"type": "string", "description": "Content to write"},
                    },
                    "required": ["path", "content"],
                },
                auto_approved=False,
            ),
            BuiltinTool(
                name="edit_file",
                description="Make precise line-based edits to a text file by replacing exact text matches.",
                input_schema={
                    "type": "object",
                    "properties": {
                        "path": {"type": "string", "description": "Path to the file to edit"},
                        "edits": {
                            "type": "array",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "oldText": {
                                        "type": "string",
                                        "description": "Text to search for",
                                    },
                                    "newText": {
                                        "type": "string",
                                        "description": "Text to replace with",
                                    },
                                },
                                "required": ["oldText", "newText"],
                            },
                            "description": "Array of edit operations",
                        },
                    },
                    "required": ["path", "edits"],
                },
                auto_approved=False,
            ),
            BuiltinTool(
                name="create_directory",
                description="Create a new directory or ensure a directory exists.",
                input_schema={
                    "type": "object",
                    "properties": {
                        "path": {
                            "type": "string",
                            "description": "Path of the directory to create",
                        },
                    },
                    "required": ["path"],
                },
                auto_approved=False,
            ),
            BuiltinTool(
                name="list_files_in_directories",
                description="List files and immediate subdirectories in one or more directories (non-recursive).",
                input_schema={
                    "type": "object",
                    "properties": {
                        "paths": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "Array of directory paths to list",
                        },
                    },
                    "required": ["paths"],
                },
                auto_approved=True,
            ),
            BuiltinTool(
                name="directory_tree",
                description="Get a recursive tree view of the folder structure as a JSON structure.",
                input_schema={
                    "type": "object",
                    "properties": {
                        "path": {
                            "type": "string",
                            "description": "Path of the directory to traverse",
                        },
                        "maxDepth": {"type": "number", "description": "Maximum depth (default: 3)"},
                        "maxDirectories": {
                            "type": "number",
                            "description": "Max directories (default: 2000)",
                        },
                        "exclude": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "Directory names to skip",
                        },
                    },
                    "required": ["path"],
                },
                auto_approved=True,
            ),
            BuiltinTool(
                name="move_file",
                description="Move or rename files and directories.",
                input_schema={
                    "type": "object",
                    "properties": {
                        "source": {"type": "string", "description": "Source path"},
                        "destination": {"type": "string", "description": "Destination path"},
                    },
                    "required": ["source", "destination"],
                },
                auto_approved=False,
            ),
            BuiltinTool(
                name="get_file_info",
                description="Retrieve detailed metadata about a file or directory.",
                input_schema={
                    "type": "object",
                    "properties": {
                        "path": {"type": "string", "description": "Path to get info for"},
                    },
                    "required": ["path"],
                },
                auto_approved=True,
            ),
            BuiltinTool(
                name="list_allowed_directories",
                description="Get the list of directories that the filesystem server is allowed to access.",
                input_schema={
                    "type": "object",
                    "properties": {},
                    "required": [],
                },
                auto_approved=True,
            ),
            BuiltinTool(
                name="delete_files",
                description="Delete files and/or directories simultaneously.",
                input_schema={
                    "type": "object",
                    "properties": {
                        "paths": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "Array of paths to delete",
                        },
                    },
                    "required": ["paths"],
                },
                auto_approved=False,
            ),
        ]
        return {"tools": tools}

    async def call_tool(
        self,
        request: dict[str, Any],
        extra: dict[str, Any] | None = None,
    ) -> Any:
        """Execute a filesystem tool."""
        name = request.get("name", "")
        args = request.get("arguments", {})

        try:
            if name == "read_files":
                return await self._read_files(args.get("paths", []))
            elif name == "write_file":
                return await self._write_file(args.get("path"), args.get("content", ""))
            elif name == "edit_file":
                return await self._edit_file(args.get("path"), args.get("edits", []))
            elif name == "create_directory":
                return await self._create_directory(args.get("path"))
            elif name == "list_files_in_directories":
                return await self._list_files_in_directories(args.get("paths", []))
            elif name == "directory_tree":
                return await self._directory_tree(args.get("path"), args)
            elif name == "move_file":
                return await self._move_file(args.get("source"), args.get("destination"))
            elif name == "get_file_info":
                return await self._get_file_info(args.get("path"))
            elif name == "list_allowed_directories":
                return await self._list_allowed_directories()
            elif name == "delete_files":
                return await self._delete_files(args.get("paths", []))
            else:
                raise ValueError(f"Unknown tool: {name}")
        except Exception as e:
            return {"content": [{"type": "text", "text": str(e)}], "isError": True}

    def _resolve_path(self, file_path: str) -> str:
        """Resolve a path, using allowed directories as base for relative paths."""
        if os.path.isabs(file_path):
            return str(Path(file_path).resolve())

        # Use first allowed directory as base for relative paths
        base_dir = self._allowed_directories[0] if self._allowed_directories else os.getcwd()
        return str(Path(base_dir, file_path).resolve())

    def _validate_path(self, file_path: str) -> str:
        """Validate that a path is within allowed directories."""
        resolved_path = self._resolve_path(file_path)

        # If no allowed directories, allow any path
        if not self._allowed_directories:
            return resolved_path

        # Check if path is within any allowed directory
        for allowed_dir in self._allowed_directories:
            try:
                Path(resolved_path).relative_to(allowed_dir)
                return resolved_path
            except ValueError:
                continue

        raise PermissionError(
            f"Access denied: Path {resolved_path} is not within allowed directories"
        )

    async def _read_files(self, paths: list[str]) -> dict[str, Any]:
        """Read multiple files."""
        results = []
        for path in paths:
            try:
                validated_path = self._validate_path(path)
                content = Path(validated_path).read_text()
                results.append({"path": path, "content": content})
            except Exception as e:
                results.append({"path": path, "error": str(e)})

        return {
            "content": [{"type": "text", "text": json.dumps(results, indent=2)}],
            "isError": False,
        }

    async def _write_file(self, path: str, content: str) -> dict[str, Any]:
        """Write content to a file."""
        validated_path = self._validate_path(path)

        # Ensure parent directory exists
        Path(validated_path).parent.mkdir(parents=True, exist_ok=True)
        Path(validated_path).write_text(content)

        return {
            "content": [{"type": "text", "text": f"Successfully wrote file: {path}"}],
            "isError": False,
        }

    async def _edit_file(self, path: str, edits: list[dict[str, str]]) -> dict[str, Any]:
        """Apply edits to a file."""
        validated_path = self._validate_path(path)
        content = Path(validated_path).read_text()

        for i, edit in enumerate(edits):
            old_text = edit.get("oldText", "")
            new_text = edit.get("newText", "")
            if old_text not in content:
                raise ValueError(f"Edit {i}: Text not found: '{old_text[:50]}...'")
            content = content.replace(old_text, new_text, 1)

        Path(validated_path).write_text(content)

        return {
            "content": [{"type": "text", "text": f"File edited successfully: {path}"}],
            "isError": False,
        }

    async def _create_directory(self, path: str) -> dict[str, Any]:
        """Create a directory."""
        validated_path = self._validate_path(path)
        Path(validated_path).mkdir(parents=True, exist_ok=True)

        return {
            "content": [{"type": "text", "text": f"Successfully created directory: {path}"}],
            "isError": False,
        }

    async def _list_files_in_directories(self, paths: list[str]) -> dict[str, Any]:
        """List files in directories."""
        results = []
        errors = []

        for dir_path in paths:
            try:
                validated_path = self._validate_path(dir_path)
                results.append(f"\n=== {dir_path} ===")

                entries = list(Path(validated_path).iterdir())
                if not entries:
                    results.append("(empty directory)")
                else:
                    for entry in entries:
                        prefix = "[DIR]" if entry.is_dir() else "[FILE]"
                        results.append(f"{prefix} {entry.name}")
            except Exception as e:
                errors.append(f"Failed to list {dir_path}: {e}")

        final_text = "\n".join(results)
        if errors:
            final_text += "\n\n=== Errors ===\n" + "\n".join(errors)

        return {
            "content": [{"type": "text", "text": final_text.strip()}],
            "isError": False,
        }

    async def _directory_tree(
        self, path: str, args: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        """Build directory tree."""
        validated_path = self._validate_path(path)
        args = args or {}

        max_depth = args.get("maxDepth", DEFAULT_MAX_DEPTH)
        max_directories = args.get("maxDirectories", DEFAULT_MAX_DIRECTORIES)
        exclude = args.get("exclude", DEFAULT_EXCLUDED_DIRS)

        state = {"directories_visited": 0, "truncated": False}
        tree = self._build_tree(validated_path, max_depth, max_directories, exclude, 1, state)

        result = {
            "name": tree.get("name", Path(validated_path).name)
            if tree
            else Path(validated_path).name,
            "type": "directory",
            "children": tree.get("children", []) if tree else [],
            "meta": {
                "truncated": state["truncated"],
                "maxDepth": max_depth,
                "maxDirectories": max_directories,
                "excluded": exclude,
            },
        }

        return {
            "content": [{"type": "text", "text": json.dumps(result, indent=2)}],
            "isError": False,
        }

    def _build_tree(
        self,
        dir_path: str,
        max_depth: int,
        max_directories: int,
        exclude: list[str],
        depth: int,
        state: dict[str, Any],
    ) -> dict[str, Any] | None:
        """Recursively build directory tree."""
        name = Path(dir_path).name

        # Check exclusions
        if any(matches_pattern(name, pattern) for pattern in exclude):
            return None

        if not Path(dir_path).is_dir():
            return None

        if depth > max_depth or state["directories_visited"] >= max_directories:
            state["truncated"] = True
            return {"name": name, "type": "directory", "children": []}

        state["directories_visited"] += 1

        try:
            entries = list(Path(dir_path).iterdir())
        except PermissionError:
            state["truncated"] = True
            return {"name": name, "type": "directory", "children": []}

        children = []
        for entry in entries:
            if not entry.is_dir():
                continue

            if state["directories_visited"] >= max_directories:
                state["truncated"] = True
                break

            child = self._build_tree(
                str(entry), max_depth, max_directories, exclude, depth + 1, state
            )
            if child:
                children.append(child)

            if state["truncated"]:
                break

        return {"name": name, "type": "directory", "children": children}

    async def _move_file(self, source: str, destination: str) -> dict[str, Any]:
        """Move a file or directory."""
        validated_source = self._validate_path(source)
        validated_dest = self._validate_path(destination)

        if Path(validated_dest).exists():
            raise FileExistsError(f"Destination already exists: {destination}")

        Path(validated_dest).parent.mkdir(parents=True, exist_ok=True)
        Path(validated_source).rename(validated_dest)

        return {
            "content": [{"type": "text", "text": f"Successfully moved {source} to {destination}"}],
            "isError": False,
        }

    async def _get_file_info(self, path: str) -> dict[str, Any]:
        """Get file information."""
        validated_path = self._validate_path(path)
        stat = os.stat(validated_path)

        file_info = {
            "name": Path(validated_path).name,
            "type": "directory" if Path(validated_path).is_dir() else "file",
            "size": stat.st_size,
            "modified": stat.st_mtime,
            "created": getattr(stat, "st_birthtime", stat.st_ctime),
            "permissions": oct(stat.st_mode)[-3:],
        }

        return {
            "content": [{"type": "text", "text": json.dumps(file_info, indent=2)}],
            "isError": False,
        }

    async def _list_allowed_directories(self) -> dict[str, Any]:
        """List allowed directories."""
        return {
            "content": [{"type": "text", "text": json.dumps(self._allowed_directories, indent=2)}],
            "isError": False,
        }

    async def _delete_files(self, paths: list[str]) -> dict[str, Any]:
        """Delete files and directories."""
        import shutil

        results = []
        success_count = 0
        error_count = 0

        for path in paths:
            try:
                validated_path = self._validate_path(path)
                p = Path(validated_path)
                item_type = "directory" if p.is_dir() else "file"

                if p.is_dir():
                    shutil.rmtree(validated_path)
                else:
                    p.unlink()

                results.append({"path": path, "success": True, "itemType": item_type})
                success_count += 1
            except Exception as e:
                results.append({"path": path, "error": str(e)})
                error_count += 1

        summary = f"Deletion completed: {success_count} successful, {error_count} failed"
        detailed_results = json.dumps(results, indent=2)

        return {
            "content": [
                {"type": "text", "text": f"{summary}\n\nDetailed results:\n{detailed_results}"}
            ],
            "isError": error_count > 0 and success_count == 0,
        }

    def update_allowed_directories(self, directories: list[str]) -> None:
        """Update the list of allowed directories."""
        self._allowed_directories = [str(Path(d).resolve()) for d in directories]
