"""
Enhanced Shell MCP server.

Provides shell command execution with safe command
whitelist checking and platform-specific handling.
"""

from __future__ import annotations

import os
import platform
import subprocess
from pathlib import Path
from typing import Any

from qodo.mcp.approved_tools import (
    SAFE_SHELL_COMMANDS,
    SAFE_SHELL_COMMANDS_WINDOWS,
    SAFE_SHELL_MODE_COMMANDS,
    SAFE_SHELL_MODE_COMMANDS_WINDOWS,
)
from qodo.mcp.base_server import BuiltinTool, InternalMCPBaseServer

DEFAULT_TIMEOUT = 30  # 30 seconds


def get_preferred_shell() -> str:
    """Get the preferred shell for the current platform."""
    if platform.system() == "Windows":
        comspec = os.environ.get("ComSpec") or os.environ.get("COMSPEC")
        if comspec and os.path.exists(comspec):
            return comspec
        return "powershell.exe"

    # Check for bash
    bash_paths = ["/bin/bash", "/usr/bin/bash", "/usr/local/bin/bash"]
    for bash_path in bash_paths:
        if os.path.exists(bash_path):
            return bash_path

    # Fall back to sh
    sh_paths = ["/bin/sh", "/usr/bin/sh"]
    for sh_path in sh_paths:
        if os.path.exists(sh_path):
            return sh_path

    return "/bin/sh"


def is_command_safe(command: str, use_shell: bool = False) -> bool:
    """
    Check if a command is in the safe whitelist.

    Args:
        command: The command to check.
        use_shell: Whether the command will be executed through a shell.

    Returns:
        True if the command is safe, False otherwise.
    """
    # Extract base command name
    base_command = os.path.basename(command.split()[0]).lower() if command else ""
    is_windows = platform.system() == "Windows"

    # More conservative whitelist when using shell mode
    if use_shell:
        if is_windows:
            return base_command in SAFE_SHELL_MODE_COMMANDS_WINDOWS
        return base_command in SAFE_SHELL_MODE_COMMANDS

    # Regular command execution
    if is_windows:
        return base_command in SAFE_SHELL_COMMANDS_WINDOWS
    return base_command in SAFE_SHELL_COMMANDS


class ShellServerEnhanced(InternalMCPBaseServer):
    """
    Enhanced Shell server.

    Provides 1 tool:
    - shell_execute (auto-approval based on command whitelist)
    """

    def __init__(self) -> None:
        self._health: dict[str, Any] | None = None

    @property
    def name(self) -> str:
        return "shell"

    @property
    def version(self) -> str:
        return "1.0.0"

    async def initialize(self) -> bool:
        """Initialize the shell server."""
        # Don't block on health check
        return True

    async def list_tools(self) -> dict[str, list[BuiltinTool]]:
        """List all shell tools."""
        tools = [
            BuiltinTool(
                name="shell_execute",
                description="Execute a shell command. Safe read-only commands (ls, pwd, etc.) run without confirmation.",
                input_schema={
                    "type": "object",
                    "properties": {
                        "command": {
                            "type": "string",
                            "description": "The command to execute (e.g., 'ls', 'git', 'python')",
                        },
                        "args": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "Command arguments as an array",
                        },
                        "cwd": {
                            "type": "string",
                            "description": "Working directory for command execution",
                        },
                        "timeout": {
                            "type": "number",
                            "description": "Command timeout in seconds (default: 30)",
                        },
                        "use_shell": {
                            "type": "boolean",
                            "description": "Execute through shell for piping/redirection (default: false)",
                        },
                    },
                    "required": ["command"],
                },
                # Auto-approval is determined per command via is_tool_auto_approved_for_args
                auto_approved=False,
            ),
        ]
        return {"tools": tools}

    def is_tool_auto_approved_for_args(
        self,
        tool_name: str,
        args: dict[str, Any],
    ) -> bool:
        """
        Check if the shell_execute tool should be auto-approved based on the command.

        Args:
            tool_name: Should be "shell_execute".
            args: Tool arguments including the command.

        Returns:
            True if the command is in the safe whitelist.
        """
        if tool_name != "shell_execute":
            return False

        command = args.get("command", "")
        use_shell = args.get("use_shell", False)

        if not command or not isinstance(command, str):
            return False

        return is_command_safe(command, use_shell)

    async def call_tool(
        self,
        request: dict[str, Any],
        extra: dict[str, Any] | None = None,
    ) -> Any:
        """Execute the shell_execute tool."""
        name = request.get("name", "")
        args = request.get("arguments", {})

        if name != "shell_execute":
            return {"content": [{"type": "text", "text": f"Unknown tool: {name}"}], "isError": True}

        try:
            return await self._execute_shell(args)
        except Exception as e:
            return {"content": [{"type": "text", "text": f"Error: {e}"}], "isError": True}

    async def _execute_shell(self, args: dict[str, Any]) -> dict[str, Any]:
        """Execute a shell command."""
        command = args.get("command", "")
        cmd_args = args.get("args", [])
        cwd = args.get("cwd")
        timeout = args.get("timeout", DEFAULT_TIMEOUT)
        use_shell = args.get("use_shell", False)

        # Validate command
        if not command or not isinstance(command, str):
            raise ValueError("Command must be a non-empty string")

        # Validate working directory
        if cwd:
            resolved_cwd = Path(cwd).resolve()
            if not resolved_cwd.exists():
                raise ValueError(f"Working directory does not exist: {cwd}")
            if not resolved_cwd.is_dir():
                raise ValueError(f"Working directory is not a directory: {cwd}")

        is_windows = platform.system() == "Windows"

        try:
            if use_shell:
                # Execute through shell
                full_command = f"{command} {' '.join(cmd_args)}" if cmd_args else command

                if is_windows:
                    result = subprocess.run(
                        full_command,
                        shell=True,
                        cwd=cwd,
                        capture_output=True,
                        text=True,
                        timeout=timeout,
                    )
                else:
                    preferred_shell = get_preferred_shell()
                    result = subprocess.run(
                        [preferred_shell, "-c", full_command],
                        cwd=cwd,
                        capture_output=True,
                        text=True,
                        timeout=timeout,
                    )
            else:
                # Direct execution (safer)
                cmd_list = [command] + (cmd_args or [])
                result = subprocess.run(
                    cmd_list,
                    cwd=cwd,
                    capture_output=True,
                    text=True,
                    timeout=timeout,
                )

            return self._format_result(
                command=command,
                cmd_args=cmd_args,
                cwd=cwd,
                use_shell=use_shell,
                stdout=result.stdout,
                stderr=result.stderr,
                code=result.returncode,
                timed_out=False,
                timeout=timeout,
            )

        except subprocess.TimeoutExpired:
            return self._format_result(
                command=command,
                cmd_args=cmd_args,
                cwd=cwd,
                use_shell=use_shell,
                stdout="",
                stderr=f"Command timed out after {timeout} seconds",
                code=1,
                timed_out=True,
                timeout=timeout,
            )

    def _format_result(
        self,
        command: str,
        cmd_args: list[str],
        cwd: str | None,
        use_shell: bool,
        stdout: str,
        stderr: str,
        code: int,
        timed_out: bool,
        timeout: int,
    ) -> dict[str, Any]:
        """Format the command result."""
        is_windows = platform.system() == "Windows"
        response_text = ""

        # Add command info
        if use_shell:
            full_command = f"{command} {' '.join(cmd_args)}" if cmd_args else command
            shell_used = "cmd.exe" if is_windows else os.path.basename(get_preferred_shell())
            response_text += f"Shell Command ({shell_used}): {full_command}\n"
        else:
            response_text += f"Command: {command}"
            if cmd_args:
                response_text += f" {' '.join(cmd_args)}"
            response_text += "\n"

        if cwd:
            response_text += f"Working Directory: {cwd}\n"

        response_text += f"Exit Code: {code}\n"

        if timed_out:
            response_text += f"Status: Command timed out after {timeout}s\n"

        response_text += "\n"

        if stdout:
            response_text += f"=== Output ===\n{stdout}"
            if not stdout.endswith("\n"):
                response_text += "\n"

        if stderr:
            response_text += f"\n=== Error Output ===\n{stderr}"
            if not stderr.endswith("\n"):
                response_text += "\n"

        return {
            "content": [{"type": "text", "text": response_text}],
            "isError": code != 0 or timed_out,
        }
