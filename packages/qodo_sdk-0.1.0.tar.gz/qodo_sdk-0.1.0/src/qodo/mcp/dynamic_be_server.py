"""
Dynamic Backend MCP server wrapper.

Wraps backend tools or internal servers to provide
a consistent InternalMCPBaseServer interface.
"""

from __future__ import annotations

from typing import Any

from qodo.mcp.base_server import BuiltinTool, InternalMCPBaseServer


class DynamicBEMCPServer(InternalMCPBaseServer):
    """
    Wrapper for backend tools or internal servers.

    Can wrap:
    1. Backend tools (from get-things API) - marks all as auto_approved=True
    2. Internal servers - delegates all methods to the internal server
    """

    def __init__(
        self,
        server_name: str,
        tools: list[dict[str, Any]],
        internal_server: InternalMCPBaseServer | None = None,
    ):
        """
        Initialize the dynamic server.

        Args:
            server_name: Name of the server.
            tools: List of tool definitions (for backend tools).
            internal_server: Optional internal server to delegate to.
        """
        self._name = server_name
        self._version = "1.0.0"
        self._internal_server = internal_server

        if internal_server:
            # Tools will be loaded from internal server
            self._tools: list[BuiltinTool] = []
        else:
            # Convert backend tools to BuiltinTool with auto_approved=True
            self._tools = [
                BuiltinTool(
                    name=tool.get("name", ""),
                    description=tool.get("description", ""),
                    input_schema=tool.get("inputSchema") or tool.get("input_schema", {}),
                    auto_approved=True,
                )
                for tool in tools
            ]

    @property
    def name(self) -> str:
        return self._name

    @property
    def version(self) -> str:
        return self._version

    async def initialize(self) -> bool:
        """Initialize the server."""
        if self._internal_server:
            return await self._internal_server.initialize()
        return True

    async def list_tools(self) -> dict[str, list[BuiltinTool]]:
        """List all available tools."""
        if self._internal_server:
            return await self._internal_server.list_tools()
        return {"tools": self._tools}

    async def call_tool(
        self,
        request: dict[str, Any],
        extra: dict[str, Any] | None = None,
    ) -> Any:
        """Execute a tool."""
        if self._internal_server:
            return await self._internal_server.call_tool(request, extra)

        # Backend tools are handled by the backend, not locally
        raise NotImplementedError("Backend tool execution should be handled by the backend")

    def is_tool_auto_approved_for_args(
        self,
        tool_name: str,
        args: dict[str, Any],
    ) -> bool:
        """Check if tool is auto-approved based on arguments."""
        if self._internal_server and hasattr(
            self._internal_server, "is_tool_auto_approved_for_args"
        ):
            return self._internal_server.is_tool_auto_approved_for_args(tool_name, args)
        return False
