"""
Type definitions for MCP module.

Contains dataclasses and enums used across the MCP components.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from enum import Enum
from typing import Any


class ServerType(str, Enum):
    """MCP server transport types."""

    BUILTIN = "builtin"  # Internal Python servers
    STDIO = "stdio"  # External CLI processes
    HTTP = "http"  # HTTP/SSE remote servers
    CUSTOM = "custom"  # Custom user-defined servers
    BACKEND = "backend"  # Backend-managed tools


@dataclass
class ServerConfig:
    """Configuration for an MCP server."""

    id: str
    type: ServerType
    command: str | None = None
    args: list[str] | None = None
    url: str | None = None
    env: dict[str, str] | None = None
    headers: dict[str, str] | None = None
    server_class: Any | None = None  # For builtin servers (InternalMCPBaseServer)
    # Async getters for args and env (used by TOML/mcp.json configs)
    get_args: Callable[[], list[str]] | None = None
    get_env: Callable[[], dict[str, str]] | None = None


@dataclass
class Tool:
    """MCP tool definition."""

    name: str
    description: str = ""
    input_schema: dict[str, Any] | None = None
    server_id: str = ""
    auto_approved: bool = False


@dataclass
class ToolResult:
    """Result from tool execution."""

    content: Any
    is_error: bool = False
    extra_content: dict[str, Any] | None = None


@dataclass
class ConnectionState:
    """MCP server connection state."""

    status: str  # "connecting", "connected", "failed"
    error_message: str | None = None


@dataclass
class ToolCallExtra:
    """
    Extra parameters passed to tool calls.

    Used for progress reporting during long-running operations.
    """

    progress_token: str | None = None
    report_progress: Callable[[Any], None] | None = None
