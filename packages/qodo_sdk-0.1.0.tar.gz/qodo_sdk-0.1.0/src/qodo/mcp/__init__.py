"""
MCP (Model Context Protocol) integration.

Provides the MCPManager for orchestrating MCP tool servers,
along with type definitions and server implementations.
"""

from qodo.mcp.approved_tools import (
    READ_ONLY_TOOLS,
    READ_ONLY_TOOLS_GROUP,
    SAFE_SHELL_COMMANDS,
    SAFE_SHELL_COMMANDS_WINDOWS,
    SAFE_SHELL_MODE_COMMANDS,
    SAFE_SHELL_MODE_COMMANDS_WINDOWS,
    get_tool_group,
    is_read_only_tool,
    is_unique_server,
)
from qodo.mcp.base_server import (
    BuiltinTool,
    InternalMCPBaseServer,
    InternalTransport,
)
from qodo.mcp.mcp_manager import MCPManager
from qodo.mcp.types import (
    ConnectionState,
    ServerConfig,
    ServerType,
    Tool,
    ToolCallExtra,
    ToolResult,
)

__all__ = [
    # Main manager
    "MCPManager",
    # Types
    "ConnectionState",
    "ServerConfig",
    "ServerType",
    "Tool",
    "ToolResult",
    "ToolCallExtra",
    # Base server
    "BuiltinTool",
    "InternalMCPBaseServer",
    "InternalTransport",
    # Approval logic
    "READ_ONLY_TOOLS",
    "READ_ONLY_TOOLS_GROUP",
    "SAFE_SHELL_COMMANDS",
    "SAFE_SHELL_COMMANDS_WINDOWS",
    "SAFE_SHELL_MODE_COMMANDS",
    "SAFE_SHELL_MODE_COMMANDS_WINDOWS",
    "get_tool_group",
    "is_unique_server",
    "is_read_only_tool",
]
