"""
MCPManager for MCP server orchestration.

Central manager for MCP tool servers, handling initialization,
tool discovery, and tool execution.

This is the refactored version that delegates to the modular architecture
while maintaining backward compatibility with the existing public API.
"""

from __future__ import annotations

import logging
import os
import platform
from typing import Any

from qodo.errors import QodoToolError
from qodo.mcp.approved_tools import (
    READ_ONLY_TOOLS,
    SAFE_SHELL_COMMANDS,
    SAFE_SHELL_COMMANDS_WINDOWS,
    SAFE_SHELL_MODE_COMMANDS,
    SAFE_SHELL_MODE_COMMANDS_WINDOWS,
)
from qodo.mcp.types import (
    ConnectionState,
    ServerConfig,
    ServerType,
    Tool,
    ToolResult,
)
from qodo.session.environment import get_current_environment, get_global_environment

logger = logging.getLogger(__name__)


class MCPManager:
    """
    Central orchestrator for MCP servers.

    Manages multiple MCP servers with different transport types:
    - Builtin: Internal Python tool implementations
    - Stdio: External CLI processes
    - HTTP/SSE: Remote servers
    - Backend: Backend-managed tools

    Uses environment-aware singleton pattern for multi-client isolation.
    """

    _instance: MCPManager | None = None

    def __init__(self) -> None:
        self._servers: dict[str, ServerConfig] = {}
        self._tools: dict[str, list[Tool]] = {}
        self._connection_states: dict[str, ConnectionState] = {}
        self._auto_approved_tools: dict[str, set[str]] = {}
        self._auto_approve_all: bool = False
        self._server_instances: dict[str, Any] = {}  # Cache for server instances

    @classmethod
    async def init(cls, force: bool = False) -> MCPManager:
        """
        Initialize MCPManager for the current environment.

        Args:
            force: If True, reinitialize even if already initialized.

        Returns:
            Initialized MCPManager instance.
        """
        env = get_current_environment()
        global_env = get_global_environment()

        # SDK mode: environment-scoped instance
        if env is not global_env:
            instance = env.mcp_manager
            if not instance or force:
                instance = cls()
                env.mcp_manager = instance
            await instance._initialize_servers()
            return instance

        # CLI mode: global singleton
        if not cls._instance or force:
            cls._instance = cls()
            if not global_env.mcp_manager:
                global_env.mcp_manager = cls._instance
        await cls._instance._initialize_servers()
        return cls._instance

    @classmethod
    def get_instance(cls) -> MCPManager:
        """Get the current MCPManager instance."""
        env = get_current_environment()
        global_env = get_global_environment()

        if env is not global_env:
            instance = env.mcp_manager
            if not instance:
                raise RuntimeError(
                    "MCPManager not initialized for this environment. Call MCPManager.init() first"
                )
            return instance  # type: ignore[no-any-return]

        if not cls._instance:
            raise RuntimeError("MCPManager not initialized. Call MCPManager.init() first")
        return cls._instance

    async def _initialize_servers(self) -> None:
        """Initialize all servers using the modular architecture."""
        from qodo.mcp.servers_registry import ServerRegistry

        # Initialize the server registry
        registry = ServerRegistry.init()
        await registry.load_all_servers()

        # Get all servers and convert to our internal format
        for server_config in registry.get_all_servers():
            await self._register_server_from_config(server_config)

    async def _register_server_from_config(self, config: ServerConfig) -> None:
        """Register a server from its configuration."""
        self._servers[config.id] = config
        self._connection_states[config.id] = ConnectionState(status="connected")

        # Get tools from the server
        if config.server_class:
            try:
                # Initialize the server
                await config.server_class.initialize()

                # Get tools from the server
                tools_result = await config.server_class.list_tools()
                tools_list = tools_result.get("tools", [])

                # Convert to Tool objects
                tools = []
                for tool in tools_list:
                    tools.append(
                        Tool(
                            name=tool.name,
                            description=tool.description,
                            input_schema=tool.input_schema,
                            server_id=config.id,
                            auto_approved=getattr(tool, "auto_approved", False),
                        )
                    )

                if tools:
                    self._tools[config.id] = tools
                    self._server_instances[config.id] = config.server_class

            except Exception as e:
                logger.debug(f"[MCPManager] Failed to initialize server {config.id}: {e}")

    def add_server(self, config: ServerConfig) -> None:
        """Add an MCP server configuration."""
        self._servers[config.id] = config
        self._connection_states[config.id] = ConnectionState(status="connecting")

    def get_all_tools(self) -> dict[str, list[Tool]]:
        """Get all tools from all servers."""
        return self._tools.copy()

    def get_enabled_tools(
        self,
        available_tools: list[str] | None = None,
        ignore_tools: list[str] | None = None,
    ) -> dict[str, list[Tool]]:
        """
        Get filtered tools based on availability and ignore lists.

        Args:
            available_tools: If provided, only include these tools.
            ignore_tools: Tools to exclude.

        Returns:
            Filtered tools by server.
        """
        all_tools = self.get_all_tools()

        enabled: dict[str, list[Tool]]
        if not available_tools:
            enabled = dict(all_tools)
        else:
            enabled = {}
            for spec in available_tools:
                parts = spec.split(".", 1)
                server_name = parts[0]
                tool_name = parts[1] if len(parts) > 1 else None

                if server_name in all_tools:
                    if tool_name:
                        tools = [t for t in all_tools[server_name] if t.name == tool_name]
                        if server_name in enabled:
                            enabled[server_name].extend(tools)
                        else:
                            enabled[server_name] = tools
                    else:
                        enabled[server_name] = all_tools[server_name]

        # Apply ignore filters
        if ignore_tools:
            for spec in ignore_tools:
                parts = spec.split(".", 1)
                server_name = parts[0]
                tool_name = parts[1] if len(parts) > 1 else None

                if server_name in enabled:
                    if tool_name:
                        enabled[server_name] = [
                            t for t in enabled[server_name] if t.name != tool_name
                        ]
                    else:
                        del enabled[server_name]

        return enabled

    def set_auto_approve_all_tools(self, approve: bool = True) -> None:
        """Enable/disable auto-approval for all tools."""
        self._auto_approve_all = approve

    def set_auto_approved_tool(self, server_id: str, tool_name: str) -> None:
        """Set a specific tool as auto-approved."""
        if server_id not in self._auto_approved_tools:
            self._auto_approved_tools[server_id] = set()
        self._auto_approved_tools[server_id].add(tool_name)

    def is_auto_approved_tool(
        self,
        server_id: str,
        tool_name: str,
        args: dict[str, Any] | None = None,
    ) -> bool:
        """
        Check if a tool call should be auto-approved.

        Approval hierarchy:
        1. Auto-approve-all flag
        2. Backend tools always approved
        3. Individual tool approval
        4. Server-specific argument-based approval
        5. Read-only tool group
        6. Safe shell command check
        """
        if self._auto_approve_all:
            return True

        # Backend tools always approved
        server = self._servers.get(server_id)
        if server and server.type == ServerType.BACKEND:
            return True

        # Individual tool approval
        if server_id in self._auto_approved_tools:
            if tool_name in self._auto_approved_tools[server_id]:
                return True

        # Check server-specific argument-based approval
        server_instance = self._server_instances.get(server_id)
        if server_instance and hasattr(server_instance, "is_tool_auto_approved_for_args"):
            if args and server_instance.is_tool_auto_approved_for_args(tool_name, args):
                return True

        # Read-only tools
        if tool_name in READ_ONLY_TOOLS:
            return True

        # Shell command check with platform-specific and use_shell handling
        if server_id == "shell" and tool_name == "shell_execute" and args:
            command = args.get("command", "")
            use_shell = args.get("use_shell", False)

            if not command:
                return False

            # Extract base command name
            cmd_parts = command.split()
            cmd_name = os.path.basename(cmd_parts[0]).lower() if cmd_parts else ""
            is_windows = platform.system() == "Windows"

            if use_shell:
                if is_windows:
                    return cmd_name in SAFE_SHELL_MODE_COMMANDS_WINDOWS
                return cmd_name in SAFE_SHELL_MODE_COMMANDS

            if is_windows:
                return cmd_name in SAFE_SHELL_COMMANDS_WINDOWS
            return cmd_name in SAFE_SHELL_COMMANDS

        return False

    async def call_tool(
        self,
        server_id: str,
        tool_name: str,
        args: Any,
    ) -> ToolResult:
        """
        Execute a tool call.

        Args:
            server_id: Server to call.
            tool_name: Tool name.
            args: Tool arguments.

        Returns:
            ToolResult with content and error status.

        Raises:
            QodoToolError: If tool execution fails.
        """
        server = self._servers.get(server_id)
        if not server:
            raise QodoToolError(f"Server not found: {server_id}")

        # Backend tools are handled by the backend, not locally
        if server.type == ServerType.BACKEND:
            return ToolResult(content=None, is_error=False)

        # Get server instance for builtin/custom tools
        server_instance = self._server_instances.get(server_id)
        if server_instance:
            try:
                result = await server_instance.call_tool({"name": tool_name, "arguments": args})

                # Convert result to ToolResult
                if isinstance(result, dict):
                    return ToolResult(
                        content=result.get("content"),
                        is_error=result.get("isError", False),
                        extra_content=result.get("extraContent"),
                    )
                return ToolResult(content=result, is_error=False)

            except Exception as e:
                return ToolResult(
                    content=[{"type": "text", "text": str(e)}],
                    is_error=True,
                )

        raise QodoToolError(f"Tool execution for {server.type} not yet implemented")

    async def dispose(self) -> None:
        """Clean up all resources."""
        self._servers.clear()
        self._tools.clear()
        self._connection_states.clear()
        self._auto_approved_tools.clear()
        self._server_instances.clear()


# Re-export types for backward compatibility
__all__ = [
    "MCPManager",
    "ServerType",
    "ServerConfig",
    "Tool",
    "ToolResult",
    "ConnectionState",
]
