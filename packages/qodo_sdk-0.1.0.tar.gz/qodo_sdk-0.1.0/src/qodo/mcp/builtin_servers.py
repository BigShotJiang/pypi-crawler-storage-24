"""
Built-in server registration.

Manages registration and configuration of built-in MCP servers
(filesystem, git, shell, ripgrep).
"""

from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import TYPE_CHECKING

from qodo.mcp.base_server import InternalMCPBaseServer
from qodo.mcp.types import ServerConfig, ServerType

logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    pass


class BuiltInServers:
    """
    Manages built-in MCP servers.

    Registers and provides access to:
    - filesystem: File system operations with path validation
    - git: Git repository operations
    - shell: Shell command execution with safe command whitelist
    - ripgrep: Fast code search using ripgrep
    """

    def __init__(self) -> None:
        self._servers: list[ServerConfig] = []
        self._server_instances: dict[str, InternalMCPBaseServer] = {}
        self._validated_directories: list[str] = []
        self._register_builtin_servers()

    def _register_builtin_servers(self) -> None:
        """Register all built-in servers."""
        from qodo.mcp.dynamic_be_server import DynamicBEMCPServer
        from qodo.mcp.servers.filesystem import FilesystemServerEnhanced
        from qodo.mcp.servers.git import GitServerEnhanced
        from qodo.mcp.servers.ripgrep import RipgrepServerEnhanced
        from qodo.mcp.servers.shell import ShellServerEnhanced

        # Register filesystem server (allowed directories populated later)
        filesystem_server = FilesystemServerEnhanced([])
        self._register_server(
            ServerConfig(
                id="filesystem",
                type=ServerType.BUILTIN,
                command=ServerType.BUILTIN.value,
                server_class=DynamicBEMCPServer("filesystem", [], filesystem_server),
            )
        )
        self._server_instances["filesystem"] = filesystem_server

        # Register git server
        git_server = GitServerEnhanced()
        self._register_server(
            ServerConfig(
                id="git",
                type=ServerType.BUILTIN,
                command=ServerType.BUILTIN.value,
                server_class=DynamicBEMCPServer("git", [], git_server),
            )
        )
        self._server_instances["git"] = git_server

        # Register shell server
        shell_server = ShellServerEnhanced()
        self._register_server(
            ServerConfig(
                id="shell",
                type=ServerType.BUILTIN,
                command=ServerType.BUILTIN.value,
                server_class=DynamicBEMCPServer("shell", [], shell_server),
            )
        )
        self._server_instances["shell"] = shell_server

        # Register ripgrep server
        ripgrep_server = RipgrepServerEnhanced()
        self._register_server(
            ServerConfig(
                id="ripgrep",
                type=ServerType.BUILTIN,
                command=ServerType.BUILTIN.value,
                server_class=DynamicBEMCPServer("ripgrep", [], ripgrep_server),
            )
        )
        self._server_instances["ripgrep"] = ripgrep_server

    def _register_server(self, config: ServerConfig) -> None:
        """Register a server configuration."""
        self._servers.append(config)

    async def get_servers(self) -> list[ServerConfig]:
        """
        Get all built-in server configurations.

        Updates filesystem server with session context if available.
        """
        # Try to get additional directories from session context
        try:
            from qodo.session.context import SessionContext  # type: ignore[import-not-found]

            session_context = SessionContext.get_instance()
            additional_directories = session_context.get_accessible_paths()
            if additional_directories:
                await self._update_filesystem_server(additional_directories)
        except Exception:
            pass  # expected: SessionContext not initialized yet

        return self._servers

    async def _update_filesystem_server(self, additional_directories: list[str]) -> None:
        """Update filesystem server with validated allowed directories."""
        from qodo.mcp.dynamic_be_server import DynamicBEMCPServer
        from qodo.mcp.servers.filesystem import FilesystemServerEnhanced

        # Find filesystem server index
        filesystem_index = None
        for i, server in enumerate(self._servers):
            if server.id == "filesystem":
                filesystem_index = i
                break

        if filesystem_index is None:
            return

        # Get execution cwd and accessible paths from session if available
        candidate_dirs: list[str] = []
        try:
            from qodo.session.context import SessionContext

            session_context = SessionContext.get_instance()
            exec_cwd = getattr(session_context, "get_execution_cwd", lambda: None)()
            accessible_paths = session_context.get_accessible_paths()

            if exec_cwd:
                candidate_dirs.append(exec_cwd)
            candidate_dirs.extend(accessible_paths)
        except Exception:
            pass  # expected: SessionContext not initialized yet

        candidate_dirs.extend(additional_directories)

        # Validate and deduplicate directories
        validated_directories: list[str] = []
        for directory in candidate_dirs:
            try:
                resolved_dir = str(Path(directory).resolve())
                if resolved_dir in validated_directories:
                    continue
                if os.access(resolved_dir, os.R_OK):
                    validated_directories.append(resolved_dir)
            except Exception as e:
                logger.warning("Directory %s is not accessible: %s", directory, e)

        # Create new filesystem server with validated directories
        filesystem_server = FilesystemServerEnhanced(validated_directories)
        self._validated_directories = validated_directories
        self._servers[filesystem_index] = ServerConfig(
            id="filesystem",
            type=ServerType.BUILTIN,
            command=ServerType.BUILTIN.value,
            server_class=DynamicBEMCPServer("filesystem", [], filesystem_server),
        )
        self._server_instances["filesystem"] = filesystem_server

    def get_validated_directories(self) -> list[str]:
        """Get the list of validated directories for filesystem access."""
        return self._validated_directories

    def get_builtin_server(self, server_id: str) -> InternalMCPBaseServer | None:
        """Get a built-in server instance by ID."""
        return self._server_instances.get(server_id)
