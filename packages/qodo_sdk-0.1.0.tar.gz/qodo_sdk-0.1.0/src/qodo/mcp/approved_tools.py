"""
Tool approval logic for MCP servers.

Contains sets of auto-approved tools and helper functions
for determining tool approval status.
"""

from __future__ import annotations

# Read-only tools that are auto-approved by default
READ_ONLY_TOOLS: set[str] = {
    # Filesystem read-only tools
    "read_files",
    "list_files_in_directories",
    "directory_tree",
    "get_file_info",
    "list_allowed_directories",
    # Git read-only tools
    "git_status",
    "git_diff_unstaged",
    "git_diff_staged",
    "git_diff",
    "git_diff_files",
    "git_log",
    "git_show",
    # Ripgrep tools (all read-only)
    "ripgrep_search",
    "ripgrep_file_types",
    # Other read-only tools
    "grep",
    "glob",
    "ls",
    "cat",
    "head",
    "tail",
    "stat",
}

# Read-only tools group identifier
READ_ONLY_TOOLS_GROUP = "read_only_tools"

# Safe read-only shell commands that are auto-approved (Unix/Linux/macOS)
SAFE_SHELL_COMMANDS: set[str] = {
    "ls",
    "wc",
    "pwd",
    "echo",
    "date",
    "whoami",
    "which",
    "env",
    "printenv",
    "cat",
    "head",
    "tail",
    "grep",
    "find",
    "ps",
    "df",
    "du",
    "hostname",
    "uname",
    "id",
    "groups",
}

# Safe shell commands for Windows
SAFE_SHELL_COMMANDS_WINDOWS: set[str] = {
    "dir",
    "echo",
    "ver",
    "where",
    "whoami",
    "hostname",
}

# Very basic commands that are safe even with use_shell=True
# (more conservative than SAFE_SHELL_COMMANDS)
SAFE_SHELL_MODE_COMMANDS: set[str] = {
    "pwd",
    "whoami",
    "date",
    "echo",
}

# Windows-specific safe commands for shell mode
SAFE_SHELL_MODE_COMMANDS_WINDOWS: set[str] = {
    "dir",
    "echo",
}

# Unique server IDs that should not be duplicated
UNIQUE_SERVER_IDS: set[str] = {
    "filesystem",
    "ripgrep",
    "git",
    "shell",
}


def get_tool_group(tool_name: str) -> str | None:
    """
    Get the tool group for a given tool name.

    Args:
        tool_name: Name of the tool.

    Returns:
        Group name if the tool belongs to a group, None otherwise.
    """
    if tool_name in READ_ONLY_TOOLS:
        return READ_ONLY_TOOLS_GROUP
    return None


def is_unique_server(server_id: str) -> bool:
    """
    Check if a server ID is a unique/builtin server.

    Unique servers should not have duplicates registered.

    Args:
        server_id: Server identifier.

    Returns:
        True if the server ID is unique, False otherwise.
    """
    return server_id.lower() in UNIQUE_SERVER_IDS


def is_read_only_tool(tool_name: str) -> bool:
    """
    Check if a tool is a read-only tool.

    Args:
        tool_name: Name of the tool.

    Returns:
        True if the tool is read-only, False otherwise.
    """
    return tool_name in READ_ONLY_TOOLS
