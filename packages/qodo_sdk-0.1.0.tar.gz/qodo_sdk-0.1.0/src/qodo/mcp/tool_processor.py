"""
Tool processor manager for middleware execution.

Orchestrates running pre- and post-execution middleware on tool calls,
with timeout protection and error isolation. Mirrors the TypeScript
SDK's toolProcessor.ts.
"""

from __future__ import annotations

import logging
from typing import Any

from qodo.errors import ToolMiddlewareError
from qodo.sdk.middleware import (
    MIDDLEWARE_TIMEOUT_MS,
    strip_protected_fields,
    with_timeout,
)

logger = logging.getLogger(__name__)


class ToolProcessorManager:
    """
    Manages tool middleware execution for pre- and post-processing of tool calls.

    Middleware is executed in order. Each middleware runs with timeout protection
    and error isolation — a failure in one middleware does not prevent subsequent
    middleware from executing.
    """

    def __init__(self, middleware: list[Any] | None = None) -> None:
        self._middleware: list[Any] = list(middleware) if middleware else []
        self._errors: list[ToolMiddlewareError] = []

    def add_middleware(self, mw: Any) -> None:
        """Add a middleware to the processing chain."""
        self._middleware.append(mw)

    def clear_middleware(self) -> None:
        """Remove all middleware from the processing chain."""
        self._middleware.clear()

    async def pre_process_tool(
        self,
        tool_name: str,
        server_name: str,
        args: dict[str, Any],
    ) -> dict[str, Any]:
        """
        Run all middleware pre_execute hooks in order.

        Protected fields are restored after each middleware to prevent
        accidental modification of critical identifiers.

        Args:
            tool_name: Name of the tool being invoked.
            server_name: Name of the server providing the tool.
            args: Original tool arguments.

        Returns:
            Processed arguments dictionary.
        """
        current_args = dict(args)

        for mw in self._middleware:
            pre_fn = getattr(mw, "pre_execute", None)
            if pre_fn is None or not callable(pre_fn):
                continue

            mw_name = type(mw).__name__
            try:
                modified = await with_timeout(
                    pre_fn(tool_name, server_name, dict(current_args)),
                    timeout_ms=MIDDLEWARE_TIMEOUT_MS,
                    label=mw_name,
                )
                if modified is not None:
                    current_args = strip_protected_fields(current_args, modified)
            except ToolMiddlewareError as e:
                logger.warning("Middleware %s pre_execute error: %s", mw_name, e)
                self._errors.append(e)
            except Exception as e:
                err = ToolMiddlewareError(
                    f"Middleware {mw_name} pre_execute failed: {e}",
                    middleware_name=mw_name,
                    phase="pre_execute",
                    cause=e,
                )
                logger.warning("Middleware %s pre_execute error: %s", mw_name, e)
                self._errors.append(err)

        return current_args

    async def post_process_tool(
        self,
        tool_name: str,
        server_name: str,
        result: dict[str, Any],
    ) -> dict[str, Any]:
        """
        Run all middleware post_execute hooks in order.

        Protected fields are restored after each middleware to prevent
        accidental modification of critical identifiers.

        Args:
            tool_name: Name of the tool that was invoked.
            server_name: Name of the server that provided the tool.
            result: Original tool result.

        Returns:
            Processed result dictionary.
        """
        current_result = dict(result)

        for mw in self._middleware:
            post_fn = getattr(mw, "post_execute", None)
            if post_fn is None or not callable(post_fn):
                continue

            mw_name = type(mw).__name__
            try:
                modified = await with_timeout(
                    post_fn(tool_name, server_name, dict(current_result)),
                    timeout_ms=MIDDLEWARE_TIMEOUT_MS,
                    label=mw_name,
                )
                if modified is not None:
                    current_result = strip_protected_fields(current_result, modified)
            except ToolMiddlewareError as e:
                logger.warning("Middleware %s post_execute error: %s", mw_name, e)
                self._errors.append(e)
            except Exception as e:
                err = ToolMiddlewareError(
                    f"Middleware {mw_name} post_execute failed: {e}",
                    middleware_name=mw_name,
                    phase="post_execute",
                    cause=e,
                )
                logger.warning("Middleware %s post_execute error: %s", mw_name, e)
                self._errors.append(err)

        return current_result

    def get_errors(self) -> list[ToolMiddlewareError]:
        """Return collected middleware errors."""
        return list(self._errors)

    def clear_errors(self) -> None:
        """Clear collected middleware errors."""
        self._errors.clear()

    async def dry_run_tool(
        self,
        tool_name: str,
        server_name: str,
        args: dict[str, Any],
    ) -> dict[str, Any]:
        """
        Generate a simulated tool response for dry-run mode.

        Returns a realistic-looking mock result marked with [DRY RUN].
        """
        mock_content = _get_dry_run_mock(tool_name, server_name)
        return {
            "isError": False,
            "content": mock_content,
        }

    @staticmethod
    def get_instance() -> ToolProcessorManager | None:
        """
        Get the ToolProcessorManager from the current environment.

        Falls back to the global environment if no context-local environment is set.

        Returns:
            The ToolProcessorManager instance, or None if not initialized.
        """
        from qodo.session.environment import get_current_environment, get_global_environment

        env = get_current_environment()
        tpm = getattr(env, "tool_processor_manager", None)
        if tpm is not None:
            return tpm  # type: ignore[no-any-return]

        global_env = get_global_environment()
        if env is not global_env:
            return getattr(global_env, "tool_processor_manager", None)

        return None


def _get_dry_run_mock(tool_name: str, server_name: str) -> str:
    """Get a realistic mock response for a dry-run tool call."""

    # Filesystem tools
    fs_mocks = {
        "read_files": (
            '[DRY RUN] File content:\n```\n# Example file content\nprint("hello world")\n```'
        ),
        "write_file": "[DRY RUN] File written successfully.",
        "edit_file": "[DRY RUN] File edited successfully. Changes applied.",
        "list_files_in_directories": (
            "[DRY RUN] Files:\n  src/main.py\n  src/utils.py\n  README.md"
        ),
        "directory_tree": (
            "[DRY RUN] Directory tree:\n"
            "\u251c\u2500\u2500 src/\n"
            "\u2502   \u251c\u2500\u2500 main.py\n"
            "\u2502   \u2514\u2500\u2500 utils.py\n"
            "\u251c\u2500\u2500 tests/\n"
            "\u2502   \u2514\u2500\u2500 test_main.py\n"
            "\u2514\u2500\u2500 README.md"
        ),
        "get_file_info": "[DRY RUN] File: example.py, Size: 1234 bytes, Modified: 2024-01-01",
        "list_allowed_directories": ("[DRY RUN] Allowed directories:\n  /project\n  /tmp"),
        "create_directory": "[DRY RUN] Directory created successfully.",
        "move_file": "[DRY RUN] File moved successfully.",
        "delete_files": "[DRY RUN] Files deleted successfully.",
    }

    # Git tools
    git_mocks = {
        "git_status": "[DRY RUN] On branch main\nnothing to commit, working tree clean",
        "git_diff": "[DRY RUN] No changes detected.",
        "git_diff_staged": "[DRY RUN] No staged changes.",
        "git_diff_branch": "[DRY RUN] No branch differences.",
        "git_log": (
            "[DRY RUN] commit abc1234 (HEAD -> main)\n"
            "Author: dev\nDate: today\n\n    Initial commit"
        ),
        "git_show": (
            "[DRY RUN] commit abc1234\n    Initial commit\n\n diff --git a/file.py b/file.py"
        ),
        "git_add": "[DRY RUN] Files staged successfully.",
        "git_commit": "[DRY RUN] Committed: abc1234",
        "git_create_branch": "[DRY RUN] Branch created successfully.",
        "git_checkout": "[DRY RUN] Switched to branch.",
        "git_reset": "[DRY RUN] Reset successful.",
        "git_init": "[DRY RUN] Repository initialized.",
    }

    # Ripgrep tools
    rg_mocks = {
        "ripgrep_search": "[DRY RUN] Search results:\n  src/main.py:10: matching line",
        "ripgrep_file_types": "[DRY RUN] Supported file types: py, js, ts, rs, go",
    }

    # Shell tools
    shell_mocks = {
        "shell_execute": "[DRY RUN] Command executed successfully.\nOutput: (simulated)",
    }

    # Check server-specific mocks
    if server_name in ("filesystem", "builtin"):
        if tool_name in fs_mocks:
            return fs_mocks[tool_name]

    if server_name == "git":
        if tool_name in git_mocks:
            return git_mocks[tool_name]

    if server_name == "ripgrep":
        if tool_name in rg_mocks:
            return rg_mocks[tool_name]

    if server_name == "shell":
        if tool_name in shell_mocks:
            return shell_mocks[tool_name]

    # Check all mock dicts regardless of server_name
    all_mocks = {**fs_mocks, **git_mocks, **rg_mocks, **shell_mocks}
    if tool_name in all_mocks:
        return all_mocks[tool_name]

    return (
        f"[DRY RUN] Tool '{tool_name}' on server '{server_name}' "
        f"executed successfully. (simulated response)"
    )
