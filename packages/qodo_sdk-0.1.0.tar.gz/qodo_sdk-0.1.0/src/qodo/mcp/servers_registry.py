"""
Server registry for MCP servers.

Manages server configurations from multiple sources:
- Built-in servers (filesystem, git, shell, ripgrep)
- Backend servers (from get-things API)
- Custom servers (from mcp.json files)
- TOML configuration servers
"""

from __future__ import annotations

import json
import logging
import os
from pathlib import Path
from typing import TYPE_CHECKING, Any

from qodo.mcp.types import ServerConfig, ServerType
from qodo.session.environment import get_current_environment, get_global_environment

if TYPE_CHECKING:
    from qodo.mcp.base_server import InternalMCPBaseServer
    from qodo.mcp.builtin_servers import BuiltInServers
    from qodo.parser.types import MCPConfig

logger = logging.getLogger(__name__)


class ConfigValidationError(Exception):
    """Exception raised when server configuration validation fails."""

    def __init__(self, message: str, details: Any | None = None):
        super().__init__(message)
        self.details = details


class ServerRegistry:
    """
    Central registry for MCP server configurations.

    Uses environment-aware singleton pattern:
    - SDK mode: per-environment instance for client isolation
    - CLI mode: global singleton for backward compatibility

    Servers are loaded from multiple sources with the following precedence:
    1. Built-in servers (lowest priority, can be overridden)
    2. Backend servers
    3. mcp.json custom servers
    4. TOML configuration servers (highest priority)
    """

    _instance: ServerRegistry | None = None

    def __init__(self, mcp_config_path: str | None = None):
        self._mcp_config_path = mcp_config_path
        self._servers: dict[str, ServerConfig] = {}
        self._toml_mcp_configs: dict[str, MCPConfig] = {}
        self._no_builtin: bool = os.environ.get("QODO_NO_BUILTIN", "").lower() == "true"
        self._builtin_servers: BuiltInServers | None = None
        self._loaded: bool = False

    @classmethod
    def init(cls, mcp_config_path: str | None = None) -> ServerRegistry:
        """
        Initialize the ServerRegistry singleton.

        Args:
            mcp_config_path: Optional path to mcp.json config file.

        Returns:
            Initialized ServerRegistry instance.
        """
        env = get_current_environment()
        global_env = get_global_environment()

        # SDK mode: environment-scoped instance
        if env is not global_env:
            instance = env.server_registry
            if not instance:
                instance = cls(mcp_config_path)
                env.server_registry = instance
            return instance

        # CLI mode: global singleton
        if not cls._instance:
            cls._instance = cls(mcp_config_path)
            if not global_env.server_registry:
                global_env.server_registry = cls._instance
        return cls._instance

    @classmethod
    def get_instance(cls) -> ServerRegistry:
        """Get the current ServerRegistry instance."""
        env = get_current_environment()
        global_env = get_global_environment()

        if env is not global_env:
            instance = env.server_registry
            if not instance:
                raise RuntimeError(
                    "ServerRegistry not initialized for this environment. "
                    "Call ServerRegistry.init() first"
                )
            return instance  # type: ignore[no-any-return]

        if not cls._instance:
            raise RuntimeError("ServerRegistry not initialized. Call ServerRegistry.init() first")
        return cls._instance

    def set_no_builtin(self, value: bool) -> None:
        """Enable/disable built-in servers."""
        self._no_builtin = value

    def set_toml_mcp_configs(self, mcp_configs: dict[str, MCPConfig]) -> None:
        """
        Set MCP configurations from TOML file.

        Args:
            mcp_configs: Dictionary mapping server IDs to MCPConfig objects.
        """
        self._toml_mcp_configs = mcp_configs

    def get_validated_directories(self) -> list[str]:
        """Get the list of validated directories for filesystem access."""
        if self._builtin_servers:
            return self._builtin_servers.get_validated_directories()
        return []

    async def load_all_servers(self) -> None:
        """
        Load all servers from all sources.

        Servers are loaded in order of precedence:
        1. Built-in servers
        2. Backend servers
        3. mcp.json custom servers
        4. TOML configuration servers
        """
        if self._loaded and self._servers:
            return

        if self._no_builtin:
            logger.info("Built-in MCP servers disabled via QODO_NO_BUILTIN flag")

        builtin_servers = {} if self._no_builtin else await self._load_builtin_servers()
        backend_servers = {} if self._no_builtin else await self._load_backend_servers()
        custom_servers = await self._load_servers_from_config()
        toml_servers = self._load_servers_from_toml_configs()

        # Check for duplicate server IDs
        self._check_for_duplicate_server_ids(
            builtin_servers, backend_servers, custom_servers, toml_servers
        )

        # Merge servers with precedence
        self._servers = {
            **builtin_servers,
            **backend_servers,
            **custom_servers,
            **toml_servers,
        }
        self._loaded = True

    async def _load_builtin_servers(self) -> dict[str, ServerConfig]:
        """Load built-in servers."""
        from qodo.mcp.builtin_servers import BuiltInServers

        temp_servers: dict[str, ServerConfig] = {}
        self._builtin_servers = BuiltInServers()
        servers = await self._builtin_servers.get_servers()

        for server in servers:
            temp_servers[server.id] = server

        return temp_servers

    async def _load_backend_servers(self) -> dict[str, ServerConfig]:
        """Load backend-provided servers from get-things API."""
        from qodo.mcp.dynamic_be_server import DynamicBEMCPServer

        temp_servers: dict[str, ServerConfig] = {}

        try:
            from qodo.session.server_data import ServerData

            server_data = await ServerData.init()
            mcp_tools = server_data.get_mcp_tools()

            for server_id, tools in mcp_tools.items():
                if not tools:
                    continue

                temp_servers[server_id] = ServerConfig(
                    id=server_id,
                    type=ServerType.BACKEND,
                    command=ServerType.BACKEND.value,
                    server_class=DynamicBEMCPServer(server_id, tools),
                )

        except Exception as e:
            logger.debug(f"Failed to load backend servers: {e}")

        return temp_servers

    async def _load_servers_from_config(self) -> dict[str, ServerConfig]:
        """Load servers from mcp.json config file."""
        temp_servers: dict[str, ServerConfig] = {}
        mcp_config = await self._read_mcp_config()

        if not mcp_config or "mcpServers" not in mcp_config:
            return temp_servers

        for server_id, raw_config in mcp_config.get("mcpServers", {}).items():
            try:
                valid_config = self._validate_server_config(raw_config)

                # Create async getters for args and env with env var substitution
                args = valid_config.get("args", [])
                env = valid_config.get("env", {})

                def get_args(a: Any = args) -> list[str]:
                    return self._substitute_env_vars(a)

                def get_env(e: Any = env) -> dict[str, str]:
                    return {k: os.path.expandvars(v) for k, v in e.items()}

                temp_servers[server_id] = ServerConfig(
                    id=server_id,
                    type=ServerType.CUSTOM,
                    command=valid_config.get("command"),
                    url=valid_config.get("url"),
                    get_args=get_args,
                    get_env=get_env,
                    headers=raw_config.get("headers"),
                )

            except ConfigValidationError as e:
                logger.error(f"Invalid server configuration for {server_id}: {e.details}")
            except Exception as e:
                logger.error(f"Error loading server configuration for {server_id}: {e}")

        return temp_servers

    def _load_servers_from_toml_configs(self) -> dict[str, ServerConfig]:
        """Load servers from TOML configuration."""
        temp_servers: dict[str, ServerConfig] = {}

        for server_id, server_config in self._toml_mcp_configs.items():
            try:
                args = server_config.args or []
                env = server_config.env or {}

                def get_args(a: Any = args) -> list[str]:
                    return self._substitute_env_vars(a)

                def get_env(e: Any = env) -> dict[str, str]:
                    return {k: os.path.expandvars(v) for k, v in e.items()}

                temp_servers[server_id] = ServerConfig(
                    id=server_id,
                    type=ServerType.CUSTOM,
                    command=server_config.command,
                    url=server_config.url,
                    get_args=get_args,
                    get_env=get_env,
                    headers=server_config.headers,
                )

            except ConfigValidationError as e:
                logger.error(f"Invalid TOML config for {server_id}: {e.details}")
            except Exception as e:
                logger.error(f"Error loading TOML config for {server_id}: {e}")

        return temp_servers

    def _validate_server_config(self, config: Any) -> dict[str, Any]:
        """Validate server configuration."""
        if not isinstance(config, dict):
            raise ConfigValidationError("Configuration must be a dictionary")

        # At least one of command or url must be provided
        if not config.get("command") and not config.get("url"):
            raise ConfigValidationError("Either 'command' or 'url' must be provided")

        return {
            "command": config.get("command"),
            "url": config.get("url"),
            "args": config.get("args", []),
            "env": config.get("env", {}),
        }

    def _substitute_env_vars(self, args: list[str]) -> list[str]:
        """Substitute environment variables in arguments."""
        return [os.path.expandvars(arg) for arg in args]

    async def _read_mcp_config(self) -> dict[str, Any]:
        """Read mcp.json configuration file."""
        config_path = await self._get_mcp_config_path()
        if not config_path:
            return {}

        try:
            with open(config_path) as f:
                return json.load(f)  # type: ignore[no-any-return]
        except Exception as e:
            logger.error(f"Error reading MCP config file: {e}")
            return {}

    async def _get_mcp_config_path(self) -> str | None:
        """Get the path to mcp.json config file."""
        if self._mcp_config_path:
            return self._mcp_config_path

        return await self._find_nearest_mcp_config()

    async def _find_nearest_mcp_config(self) -> str | None:
        """Find the nearest mcp.json file by traversing up from cwd."""
        current_dir = Path.cwd()
        repo_root = await self._find_repository_root(str(current_dir))
        root_dir = Path(repo_root) if repo_root else Path(current_dir.root)

        while current_dir != root_dir:
            config_path = current_dir / "mcp.json"
            if config_path.exists() and config_path.is_file():
                return str(config_path)
            current_dir = current_dir.parent

        # Check root directory
        root_config = root_dir / "mcp.json"
        if root_config.exists() and root_config.is_file():
            return str(root_config)

        return None

    async def _find_repository_root(self, start_path: str) -> str | None:
        """Find the git repository root by traversing up from start_path."""
        current_path = Path(start_path).resolve()

        if current_path.is_file():
            current_path = current_path.parent

        while current_path != current_path.parent:
            git_path = current_path / ".git"
            if git_path.exists():
                return str(current_path)
            current_path = current_path.parent

        return None

    def _check_for_duplicate_server_ids(
        self,
        builtin_servers: dict[str, ServerConfig],
        backend_servers: dict[str, ServerConfig],
        custom_servers: dict[str, ServerConfig],
        toml_servers: dict[str, ServerConfig],
    ) -> None:
        """Check for duplicate server IDs and handle appropriately."""
        server_sources = [
            ("built-in", builtin_servers, True),
            ("backend", backend_servers, True),
            ("mcp.json file", custom_servers, False),
            ("agent configuration", toml_servers, False),
        ]

        seen_ids: dict[str, list[tuple[str, bool]]] = {}

        for source_name, servers, is_builtin in server_sources:
            for server_id in servers.keys():
                if server_id not in seen_ids:
                    seen_ids[server_id] = []
                seen_ids[server_id].append((source_name, is_builtin))

        for server_id, sources in seen_ids.items():
            if len(sources) > 1:
                non_builtin_sources = [s[0] for s in sources if not s[1]]
                has_builtin = any(s[1] for s in sources)

                if has_builtin and non_builtin_sources:
                    # Fatal error: built-in server conflict
                    sources_list = ", ".join(non_builtin_sources)
                    raise ConfigValidationError(
                        f"MCP server conflict: Server '{server_id}' conflicts with "
                        f"a built-in server. Found in: {sources_list}. "
                        f"Change the server ID or use noBuiltin option."
                    )
                elif len(non_builtin_sources) > 1:
                    # Warning: custom server override
                    sources_list = ", ".join(non_builtin_sources)
                    logger.warning(
                        f"MCP Server Override: Duplicate server ID '{server_id}' "
                        f"found in: {sources_list}. Agent configuration will "
                        f"override mcp.json configuration."
                    )

    def get_all_servers(self) -> list[ServerConfig]:
        """Get all registered servers with session-based filtering."""
        # Try to get session filtering configuration
        session_available_tools: list[str] | None = None
        session_ignored_tools: list[str] | None = None

        try:
            from qodo.session.context import SessionContext  # type: ignore[import-not-found]

            session_context = SessionContext.get_instance()
            session_available_tools = session_context.get_available_tools()
            session_ignored_tools = session_context.get_ignore_tools()
        except Exception:
            pass  # expected: SessionContext may not be initialized yet

        available_servers: list[str] | None = None
        ignored_servers: list[str] | None = None

        if session_available_tools:
            available_servers = [tool.split(".")[0] for tool in session_available_tools]

        if session_ignored_tools:
            ignored_servers = [tool.split(".")[0] for tool in session_ignored_tools]

        return [
            server
            for server in self._servers.values()
            if self._should_include_server(server, available_servers, ignored_servers)
        ]

    def _should_include_server(
        self,
        server: ServerConfig,
        available_servers: list[str] | None,
        ignored_servers: list[str] | None,
    ) -> bool:
        """Check if a server should be included based on filters."""
        if available_servers:
            return server.id in available_servers

        if ignored_servers:
            return server.id not in ignored_servers

        return True

    def get_server(self, server_id: str) -> ServerConfig | None:
        """Get a specific server by ID."""
        return self._servers.get(server_id)

    def get_builtin_server(self, server_id: str) -> InternalMCPBaseServer | None:
        """Get a built-in server instance by ID."""
        if self._builtin_servers:
            return self._builtin_servers.get_builtin_server(server_id)
        return None
