"""
Base server interface for MCP tool servers.

Defines the abstract base class for all internal MCP servers.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any


@dataclass
class BuiltinTool:
    """
    Tool definition with auto-approval flag.

    Extends the basic tool definition to include whether
    the tool should be auto-approved without user confirmation.
    """

    name: str
    description: str
    input_schema: dict[str, Any]
    auto_approved: bool = False


class InternalMCPBaseServer(ABC):
    """
    Base interface for internal MCP tool servers.

    All builtin servers (filesystem, git, shell, ripgrep) must
    implement this interface to provide consistent tool registration
    and execution.
    """

    @property
    @abstractmethod
    def name(self) -> str:
        """Name of the server."""
        pass

    @property
    @abstractmethod
    def version(self) -> str:
        """Version of the server."""
        pass

    @abstractmethod
    async def initialize(self) -> bool:
        """
        Initialize the server.

        Returns:
            True if initialization was successful, False otherwise.

        Note:
            This method should not block or raise exceptions.
            Return True even on partial failure to allow the MCP
            handshake to complete.
        """
        pass

    @abstractmethod
    async def list_tools(self) -> dict[str, list[BuiltinTool]]:
        """
        List all available tools with their metadata and input schemas.

        Returns:
            Dictionary with 'tools' key containing list of BuiltinTool objects.
        """
        pass

    @abstractmethod
    async def call_tool(
        self,
        request: dict[str, Any],
        extra: dict[str, Any] | None = None,
    ) -> Any:
        """
        Execute a specific tool with provided arguments.

        Args:
            request: Dictionary containing 'name' and 'arguments' keys.
            extra: Optional dictionary with progress_token and report_progress callback.

        Returns:
            Tool execution result in MCP format:
            {"content": [...], "isError": bool}

        Raises:
            Exception: If tool is not found or execution fails.
        """
        pass

    def is_tool_auto_approved_for_args(
        self,
        tool_name: str,
        args: dict[str, Any],
    ) -> bool:
        """
        Check if a tool should be auto-approved based on its arguments.

        This is an optional method that servers can override for
        argument-based approval (e.g., shell server checking if
        the command is in the safe list).

        Args:
            tool_name: Name of the tool.
            args: Arguments for the tool.

        Returns:
            True if the tool should be auto-approved with these arguments.
        """
        return False


class InternalTransport:
    """
    Transport implementation that wraps InternalMCPBaseServer.

    Provides MCP protocol compatibility for internal servers,
    handling JSON-RPC message routing and progress notifications.
    """

    def __init__(self, internal_server: InternalMCPBaseServer):
        self._server = internal_server
        self._message_counter = 0
        self.on_message: Callable[[dict[str, Any]], None] | None = None
        self.on_error: Callable[[Exception], None] | None = None
        self.on_close: Callable[[], None] | None = None

    async def start(self) -> None:
        """Start the transport (no-op for internal servers)."""
        pass

    async def send(self, message: dict[str, Any]) -> Any:
        """
        Process an MCP protocol message.

        Args:
            message: JSON-RPC request message.

        Returns:
            None (responses are sent via on_message callback).
        """
        try:
            msg_id = message.get("id") or self._get_next_id()
            method = message.get("method", "")

            if method == "initialize":
                initialized = await self._server.initialize()
                if not initialized:
                    self._send_response(msg_id, None)
                else:
                    self._send_response(
                        msg_id,
                        {
                            "protocolVersion": "2024-11-05",
                            "capabilities": {"tools": {}},
                            "serverInfo": {
                                "name": self._server.name,
                                "version": self._server.version,
                            },
                        },
                    )

            elif method == "tools/list":
                result = await self._server.list_tools()
                self._send_response(msg_id, result)

            elif method == "tools/call":
                params = message.get("params", {})
                if not params or not isinstance(params, dict):
                    raise ValueError("Invalid parameters for tools/call")

                # Extract progress token and create progress reporter
                meta = params.get("_meta", {})
                progress_token = meta.get("progressToken")

                def report_progress(payload: Any) -> None:
                    if not progress_token:
                        return
                    try:
                        if self.on_message:
                            self.on_message(
                                {
                                    "jsonrpc": "2.0",
                                    "method": "notifications/progress",
                                    "params": {
                                        "progressToken": progress_token,
                                        "progress": payload,
                                    },
                                }
                            )
                    except Exception:
                        pass  # best-effort: progress notification is non-critical

                extra = {
                    "progress_token": progress_token,
                    "report_progress": report_progress,
                }

                result = await self._server.call_tool(
                    {"name": params.get("name"), "arguments": params.get("arguments", {})},
                    extra,
                )
                self._send_response(msg_id, result)

            else:
                raise ValueError(f"Unsupported method: {method}")

        except Exception as e:
            if self.on_error:
                self.on_error(e)

    async def close(self) -> None:
        """Close the transport."""
        if self.on_close:
            self.on_close()

    def _get_next_id(self) -> int:
        """Get the next message ID."""
        self._message_counter += 1
        return self._message_counter

    def _send_response(self, msg_id: Any, result: Any) -> None:
        """Send a JSON-RPC response."""
        if self.on_message:
            self.on_message(
                {
                    "jsonrpc": "2.0",
                    "id": msg_id,
                    "result": result,
                }
            )
