"""Version information for the Qodo SDK."""

__version__ = "0.1.0"
