"""
Qodo Python SDK for AI-powered agents.

This SDK provides a Python interface for building and running AI agents
using the Qodo platform.

Example usage:
    from qodo import QodoSDK, SdkEventType

    async with QodoSDK(project_path="/path/to/project") as sdk:
        result = await sdk.prompt("Hello, world!")
        print(result.success)

    # Streaming
    async for event in sdk.stream("my_command"):
        if event.type == SdkEventType.MESSAGE_DELTA:
            print(event.data.delta, end="")
"""

from qodo._version import __version__

# In-process runner
from qodo.api.in_process import InProcessGraphRunner

# Auth
from qodo.auth import AuthProvider

# Errors
from qodo.errors import (
    PipelineExecutionError,
    QodoAuthError,
    QodoBackendBootstrapError,
    QodoCancelledError,
    QodoConfigError,
    QodoConnectionError,
    QodoError,
    QodoOutputValidationError,
    QodoSchemaError,
    QodoTimeoutError,
    QodoToolError,
    ToolMiddlewareError,
)

# Tool Processor
from qodo.mcp.tool_processor import ToolProcessorManager

# Config types
from qodo.parser.types import (
    AIAssistantConfig,
    CommandArgument,
    CommandConfig,
    MCPConfig,
    ModeConfig,
    OutputSchema,
)

# Artifacts
from qodo.sdk.artifacts import (
    Artifact,
    ArtifactSerializer,
    ArtifactStore,
    ArtifactStoreOptions,
    PersistHook,
    json_serializer,
    with_artifacts,
)

# Builders
from qodo.sdk.builders import (
    sdk_agent,
    sdk_args,
    sdk_command,
)

# Events
# Main SDK
from qodo.sdk.events import (
    SDK_PROTOCOL_V2,
    EventEmitter,
    QodoSdkEvent,
    SdkEventType,
    create_sdk_event,
    get_sdk_version,
    match_sdk_event,
)

# Middleware
from qodo.sdk.middleware import (
    MIDDLEWARE_TIMEOUT_MS,
    PROTECTED_TOOL_FIELDS,
    ToolMiddleware,
    strip_protected_fields,
    with_timeout,
)

# Pipeline
from qodo.sdk.pipeline import (
    Pipeline,
    PipelineBuilder,
    PipelineResult,
    StepContext,
    StepLog,
    StepOptions,
    run_pipeline,
    sdk_pipeline,
)
from qodo.sdk.pipeline.types import (
    ErrorStrategy,
    GateFn,
    StepFn,
)

# Policies
from qodo.sdk.policies import (
    Policy,
    PolicyBuilder,
    PolicyDecision,
    PolicyEvalResult,
    PolicyMatcher,
    PolicyOptions,
    PolicyRule,
    glob_match,
    policy_from_rules,
    sdk_policy,
)
from qodo.sdk.qodo_sdk import (
    QodoSDK,
    QodoSDKOptions,
    QodoSDKRunResult,
    ToolApprovalRequest,
)

# Finalize utilities
from qodo.sdk.runner.finalize import (
    is_pydantic_model,
    validate_structured_output,
)

# Schemas
from qodo.sdk.schemas import (
    CoercibleTypes,
    JsonAny,
    JsonValue,
    json_any_schema,
    json_value_schema,
    parse_args_with_schema,
    pydantic_output_schema,
    zcoerce,
)

# Session/Environment
from qodo.session.environment import (
    EnvironmentContext,
    EnvironmentServices,
    get_current_environment,
    get_global_environment,
    is_debug_mode,
    is_sdk_mode,
    run_with_environment,
    run_with_environment_async,
)

# Tracing
from qodo.tracing import (
    OTelAPI,
    SdkTracer,
    create_sdk_tracer,
    trace_pipeline,
)

__all__ = [
    # Version
    "__version__",
    # Auth
    "AuthProvider",
    # Main SDK
    "QodoSDK",
    "QodoSDKOptions",
    "QodoSDKRunResult",
    "ToolApprovalRequest",
    "get_sdk_version",
    # Builders
    "sdk_agent",
    "sdk_command",
    "sdk_args",
    # Schemas
    "pydantic_output_schema",
    "parse_args_with_schema",
    "CoercibleTypes",
    "zcoerce",
    "json_value_schema",
    "json_any_schema",
    "JsonValue",
    "JsonAny",
    # Events
    "QodoSdkEvent",
    "SdkEventType",
    "SDK_PROTOCOL_V2",
    "match_sdk_event",
    "create_sdk_event",
    "EventEmitter",
    # Config types
    "AIAssistantConfig",
    "CommandConfig",
    "ModeConfig",
    "MCPConfig",
    "OutputSchema",
    "CommandArgument",
    # Environment
    "EnvironmentServices",
    "EnvironmentContext",
    "get_current_environment",
    "get_global_environment",
    "run_with_environment",
    "run_with_environment_async",
    "is_sdk_mode",
    "is_debug_mode",
    # Finalize utilities
    "is_pydantic_model",
    "validate_structured_output",
    # Middleware
    "ToolMiddleware",
    "ToolProcessorManager",
    "MIDDLEWARE_TIMEOUT_MS",
    "PROTECTED_TOOL_FIELDS",
    "strip_protected_fields",
    "with_timeout",
    # Policies
    "sdk_policy",
    "policy_from_rules",
    "Policy",
    "PolicyBuilder",
    "glob_match",
    "PolicyRule",
    "PolicyMatcher",
    "PolicyDecision",
    "PolicyEvalResult",
    "PolicyOptions",
    # Pipeline
    "sdk_pipeline",
    "PipelineBuilder",
    "Pipeline",
    "run_pipeline",
    "PipelineExecutionError",
    "StepContext",
    "StepFn",
    "GateFn",
    "ErrorStrategy",
    "PipelineResult",
    "StepLog",
    "StepOptions",
    # Artifacts
    "ArtifactStore",
    "Artifact",
    "ArtifactSerializer",
    "ArtifactStoreOptions",
    "json_serializer",
    "with_artifacts",
    "PersistHook",
    # Tracing
    "SdkTracer",
    "create_sdk_tracer",
    "trace_pipeline",
    "OTelAPI",
    # In-process runner
    "InProcessGraphRunner",
    # Errors
    "QodoError",
    "QodoAuthError",
    "QodoSchemaError",
    "QodoOutputValidationError",
    "QodoBackendBootstrapError",
    "QodoConnectionError",
    "QodoToolError",
    "ToolMiddlewareError",
    "QodoConfigError",
    "QodoTimeoutError",
    "QodoCancelledError",
]
