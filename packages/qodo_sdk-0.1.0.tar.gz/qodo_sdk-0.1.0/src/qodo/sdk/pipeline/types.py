"""Pipeline DSL types."""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from typing import (
    Any,
    Literal,
)


@dataclass
class StepContext:
    """Context passed to each step function at runtime."""

    state: dict[str, Any]
    run: Callable[..., Awaitable[Any]]  # (command_or_prompt, **kwargs) -> QodoSDKRunResult
    step_name: str


# Step function signature
StepFn = Callable[[StepContext], Awaitable[dict[str, Any]]]

# Gate predicate
GateFn = Callable[[dict[str, Any]], bool | Awaitable[bool]]

# Error strategy
ErrorStrategy = (
    Literal["skip", "throw"]
    | Callable[[Exception, dict[str, Any]], dict[str, Any] | Awaitable[dict[str, Any]]]
)


@dataclass
class PipelineStep:
    """Internal representation of a single pipeline step."""

    name: str
    fn: StepFn
    gate: GateFn | None = None
    on_error: ErrorStrategy = "throw"


@dataclass
class ParallelGroup:
    """A group of steps that run concurrently."""

    kind: str = "parallel"
    steps: list[PipelineStep] = field(default_factory=list)


# Union type for pipeline entries
PipelineEntry = PipelineStep | ParallelGroup


@dataclass
class StepLog:
    """Log entry for a pipeline step execution."""

    name: str
    status: Literal["completed", "skipped", "error"]
    duration_ms: float
    error: str | None = None


@dataclass
class PipelineResult:
    """Result of a pipeline execution."""

    state: dict[str, Any]
    steps: list[StepLog] = field(default_factory=list)


@dataclass
class StepOptions:
    """Options for a pipeline step."""

    gate: GateFn | None = None
    on_error: ErrorStrategy = "throw"
