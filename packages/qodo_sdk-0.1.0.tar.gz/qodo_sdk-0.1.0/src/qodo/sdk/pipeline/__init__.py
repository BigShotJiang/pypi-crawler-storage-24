"""Pipeline DSL for building multi-step agent workflows."""

from __future__ import annotations

from qodo.sdk.pipeline.builder import Pipeline, PipelineBuilder
from qodo.sdk.pipeline.runner import run_pipeline
from qodo.sdk.pipeline.types import (
    ErrorStrategy,
    GateFn,
    ParallelGroup,
    PipelineEntry,
    PipelineResult,
    PipelineStep,
    StepContext,
    StepFn,
    StepLog,
    StepOptions,
)


def sdk_pipeline() -> PipelineBuilder:
    """
    Create a new pipeline builder.

    Usage:
        from qodo.sdk.pipeline import sdk_pipeline, run_pipeline

        pipeline = sdk_pipeline()\\
            .step("analyze", analyze_fn)\\
            .step("summarize", summarize_fn)\\
            .build()

        result = await run_pipeline(sdk, pipeline, {"input": "data"})
    """
    return PipelineBuilder()


__all__ = [
    "sdk_pipeline",
    "PipelineBuilder",
    "Pipeline",
    "run_pipeline",
    "StepFn",
    "StepContext",
    "GateFn",
    "ErrorStrategy",
    "PipelineStep",
    "ParallelGroup",
    "PipelineEntry",
    "PipelineResult",
    "StepLog",
    "StepOptions",
]
