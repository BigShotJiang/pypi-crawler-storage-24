"""Pipeline execution engine."""

from __future__ import annotations

import asyncio
import time
from typing import Any

from qodo.errors import PipelineExecutionError
from qodo.sdk.pipeline.builder import Pipeline
from qodo.sdk.pipeline.types import (
    ParallelGroup,
    PipelineEntry,
    PipelineResult,
    PipelineStep,
    StepContext,
    StepLog,
)


async def run_pipeline(
    sdk: Any,  # QodoSDK -- avoid circular import
    pipeline: Pipeline,
    initial_state: dict[str, Any],
) -> PipelineResult:
    """
    Execute a pipeline with the given SDK instance and initial state.

    Args:
        sdk: A QodoSDK instance (used for step context's run()).
        pipeline: The pipeline to execute.
        initial_state: Starting state dict.

    Returns:
        PipelineResult with final state and step logs.
    """
    state: dict[str, Any] = {**initial_state}
    step_logs: list[StepLog] = []

    for entry in pipeline.entries:
        if _is_parallel_group(entry):
            assert isinstance(entry, ParallelGroup)
            new_state, logs = await _execute_parallel_group(sdk, entry, state)
            state = {**state, **new_state}
            step_logs.extend(logs)
        else:
            assert isinstance(entry, PipelineStep)
            new_state, log = await _execute_step(sdk, entry, state)
            state = {**state, **new_state}
            step_logs.append(log)

    return PipelineResult(state=state, steps=step_logs)


def _is_parallel_group(entry: PipelineEntry) -> bool:
    return isinstance(entry, ParallelGroup)


async def _execute_step(
    sdk: Any,
    step: PipelineStep,
    state: dict[str, Any],
) -> tuple[dict[str, Any], StepLog]:
    """Execute a single step."""
    start = time.monotonic()

    # Evaluate gate
    if step.gate is not None:
        try:
            result = step.gate(state)
            if asyncio.iscoroutine(result):
                gate_pass = await result
            else:
                gate_pass = result
        except Exception:
            gate_pass = False

        if not gate_pass:
            duration = (time.monotonic() - start) * 1000
            return {}, StepLog(name=step.name, status="skipped", duration_ms=duration)

    # Build step context
    ctx = StepContext(
        state=state,
        run=lambda cmd, **kwargs: sdk.run(cmd, **kwargs),
        step_name=step.name,
    )

    try:
        output = await step.fn(ctx)
        duration = (time.monotonic() - start) * 1000
        return output or {}, StepLog(name=step.name, status="completed", duration_ms=duration)
    except Exception as err:
        duration = (time.monotonic() - start) * 1000

        if step.on_error == "skip":
            return {}, StepLog(
                name=step.name, status="skipped", duration_ms=duration, error=str(err)
            )

        if callable(step.on_error):
            try:
                recovery_result = step.on_error(err, state)
                if asyncio.iscoroutine(recovery_result):
                    recovered = await recovery_result
                else:
                    recovered = recovery_result
                return recovered or {}, StepLog(
                    name=step.name, status="completed", duration_ms=duration
                )
            except Exception as recovery_err:
                raise PipelineExecutionError(
                    f'Step "{step.name}" recovery failed: {recovery_err}',
                    step_name=step.name,
                    cause=recovery_err,
                ) from recovery_err

        # 'throw' (default)
        raise PipelineExecutionError(
            f'Step "{step.name}" failed: {err}',
            step_name=step.name,
            cause=err,
        ) from err


async def _execute_parallel_group(
    sdk: Any,
    group: ParallelGroup,
    state: dict[str, Any],
) -> tuple[dict[str, Any], list[StepLog]]:
    """Execute a parallel group of steps."""
    tasks = [asyncio.create_task(_execute_step(sdk, step, state)) for step in group.steps]

    results = await asyncio.gather(*tasks, return_exceptions=True)

    merged: dict[str, Any] = {}
    logs: list[StepLog] = []

    for i, result in enumerate(results):
        if isinstance(result, Exception):
            step_name = group.steps[i].name
            raise PipelineExecutionError(
                f'Parallel step "{step_name}" failed: {result}',
                step_name=step_name,
                cause=result if isinstance(result, Exception) else None,
            ) from result
        else:
            new_state, log = result  # type: ignore[misc]
            merged = {**merged, **new_state}
            logs.append(log)

    return merged, logs
