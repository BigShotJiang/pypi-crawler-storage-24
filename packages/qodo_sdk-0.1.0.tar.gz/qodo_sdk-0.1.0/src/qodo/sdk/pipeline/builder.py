"""Fluent builder for constructing pipelines."""

from __future__ import annotations

from typing import Any

from qodo.sdk.pipeline.types import (
    ErrorStrategy,
    GateFn,
    ParallelGroup,
    PipelineEntry,
    PipelineStep,
    StepFn,
)


class PipelineBuilder:
    """
    Immutable pipeline builder.

    Each .step() / .parallel() call returns a NEW builder instance.
    State is dict[str, Any] -- Python cannot express TS intersection types.

    Usage:
        pipeline = sdk_pipeline()\\
            .step("lint", lint_fn)\\
            .parallel([
                {"name": "test", "fn": test_fn},
                {"name": "check", "fn": check_fn},
            ])\\
            .step("deploy", deploy_fn)\\
            .build()
    """

    def __init__(self, entries: list[PipelineEntry] | None = None) -> None:
        self._entries: list[PipelineEntry] = list(entries) if entries else []

    def step(
        self,
        name: str,
        fn: StepFn,
        *,
        gate: GateFn | None = None,
        on_error: ErrorStrategy = "throw",
    ) -> PipelineBuilder:
        """Add a sequential step. Returns a NEW builder."""
        entry = PipelineStep(name=name, fn=fn, gate=gate, on_error=on_error)
        return PipelineBuilder([*self._entries, entry])

    def parallel(
        self,
        steps: list[dict[str, Any]],
    ) -> PipelineBuilder:
        """
        Add a group of parallel steps. Returns a NEW builder.

        Each dict in steps should have: name, fn, and optionally gate, on_error.
        """
        group = ParallelGroup(
            kind="parallel",
            steps=[
                PipelineStep(
                    name=s["name"],
                    fn=s["fn"],
                    gate=s.get("gate"),
                    on_error=s.get("on_error", "throw"),
                )
                for s in steps
            ],
        )
        return PipelineBuilder([*self._entries, group])

    def build(self) -> Pipeline:
        """Finalize and return a frozen Pipeline."""
        return Pipeline(entries=tuple(self._entries))


class Pipeline:
    """Frozen, executable pipeline definition."""

    def __init__(self, entries: tuple[PipelineEntry, ...]) -> None:
        self.entries = entries
