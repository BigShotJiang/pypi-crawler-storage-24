"""
Main QodoSDK class.

The primary entry point for the Qodo Python SDK, providing methods
for running AI agents and streaming events.

Mirrors the TypeScript SDK's QodoSDK - uses MessageManager for state,
AgentRunnerCore for orchestration, and emits v2 protocol events.
"""

from __future__ import annotations

import asyncio
import logging
import os
import uuid
from collections.abc import AsyncIterator, Awaitable, Callable
from dataclasses import dataclass, field
from typing import Any

from qodo.api.websocket import ConnectionState
from qodo.config import ConfigManager
from qodo.context.message_manager import AIMessage, Message, MessageManager
from qodo.errors import QodoError
from qodo.mcp import MCPManager
from qodo.parser.types import AIAssistantConfig, CommandConfig
from qodo.sdk.events import (
    QodoSdkEvent,
    SdkErrorData,
    SdkEventType,
    SdkFinalData,
    SdkInitData,
    SdkMessageDeltaData,
    SdkMessageFullData,
    SdkProgressData,
    SdkRunStartedData,
    SdkToolApprovedData,
    SdkToolExecutedData,
    SdkToolRequestedData,
    create_sdk_event,
    get_sdk_version,
)
from qodo.sdk.runner import AgentRunnerCore, build_final_result, to_langchain_dict, to_openai_chat
from qodo.sdk.runner.progress import extract_progress
from qodo.session import SessionContext
from qodo.session.environment import (
    EnvironmentContext,
    EnvironmentServices,
    _env_context,
)

logger = logging.getLogger(__name__)


@dataclass
class ToolApprovalRequest:
    """Request for tool approval callback."""

    tool_call_id: str
    server_name: str
    tool_name: str
    tool_args: Any
    reasoning: str | None = None


@dataclass
class QodoSDKOptions:
    """
    Configuration options for QodoSDK.

    Attributes:
        agent_file: Path to agent config file (auto-discovered if omitted).
        agent_content: Inline TOML/YAML agent config string.
        agent_object: Programmatic agent config dictionary.
        mcp_file: Path to mcp.json file.
        mcp_servers: Inline MCP server configuration overrides.
        model: Model override.
        context_session_ids: Prefetch summaries from previous sessions.
        auto_approve_tools: Whether to auto-approve non-interactive tools.
        tool_approval: Callback for tool approval decisions.
        flags: Runtime flags.
        debug: Enable internal SDK logs.
        logger: Custom logger implementation.
        project_path: Primary project directory (falls back to cwd).
        additional_paths: Additional accessible directories.
        backend_base_url: Custom backend URL override.
        interactive_mode: Enable interactive mode for SDK agent.
    """

    api_key: str | None = None

    agent_file: str | None = None
    agent_content: str | None = None
    agent_object: dict[str, Any] | None = None

    mcp_file: str | None = None
    mcp_servers: dict[str, Any] | None = None

    model: str | None = None
    context_session_ids: list[str] | None = None

    auto_approve_tools: bool = True
    tool_approval: Callable[[ToolApprovalRequest], Awaitable[bool] | bool] | None = None

    flags: dict[str, Any] = field(default_factory=dict)
    debug: bool = False
    logger: Any | None = None

    project_path: str | None = None
    additional_paths: list[str] | None = None

    backend_base_url: str | None = None
    interactive_mode: bool | None = None
    tool_middleware: list[Any] | None = None


@dataclass
class QodoSDKRunResult:
    """
    Result from a completed SDK run.

    Attributes:
        success: Whether the run completed successfully.
        error: Error message if the run failed.
        model: The model used for the run.
        result: Result data including structured_output and final_output.
        messages: Conversation messages in langchain and openai formats.
        meta: Metadata about the run.
    """

    success: bool
    error: str | None = None
    model: str = ""
    result: dict[str, Any] = field(default_factory=dict)
    messages: dict[str, list[Any]] = field(default_factory=dict)
    meta: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_final_data(cls, data: SdkFinalData) -> QodoSDKRunResult:
        """Create a run result from final event data."""
        return cls(
            success=data.success,
            error=data.error,
            model=data.model,
            result=data.result,
            messages=data.messages,
            meta=data.meta,
        )


class QodoSDK:
    """
    Main entry point for the Qodo Python SDK.

    Provides async streaming and synchronous execution of agent commands.
    Mirrors the TypeScript SDK's architecture:
    - Uses MessageManager for central state
    - Uses AgentRunnerCore for orchestration
    - Emits qodo.sdk.v2 protocol events

    Example:
        # Basic usage with context manager
        async with QodoSDK(project_path="/path/to/project") as sdk:
            result = await sdk.prompt("Hello, world!")
            print(result.success)

        # Streaming events
        async with QodoSDK(project_path="/path/to/project") as sdk:
            async for event in sdk.stream_prompt("Write a greeting"):
                if event.type == SdkEventType.MESSAGE_DELTA:
                    print(event.data.delta, end="", flush=True)

        # Custom agent
        from pydantic import BaseModel, Field
        from qodo import sdk_agent, sdk_command

        agent = sdk_agent(
            commands={
                "review": sdk_command(name="review", ...)
            }
        )
        sdk = QodoSDK.from_agent(agent, project_path="/path/to/project")
    """

    def __init__(self, options: QodoSDKOptions | None = None, **kwargs: Any) -> None:
        """
        Initialize QodoSDK with options.

        Args:
            options: SDK configuration options.
            **kwargs: Alternative way to pass options as keyword arguments.
        """
        if options is None:
            options = QodoSDKOptions(**kwargs)
        self._options = options
        self._initialized = False

        # Create isolated environment for this SDK instance
        self._env = EnvironmentServices(
            sdk_mode=True,
            sdk_debug=options.debug,
        )

        # Per-run metadata
        self._run_id: str = ""
        self._seq: int = 0
        self._run_start_ms: int = 0

        # Components (created during initialization)
        self._session_context: SessionContext | None = None
        self._message_manager: MessageManager | None = None
        self._agent: Any | None = None  # AgentAPI
        self._core: AgentRunnerCore | None = None
        self._config_manager: ConfigManager | None = None
        self._mcp_manager: MCPManager | None = None

        # Event streaming state
        self._event_queue: list[QodoSdkEvent] = []
        self._pending_resolvers: list[Any] = []
        self._done: bool = False
        self._active_runs: int = 0

        # Delta tracking for sdk.message.delta
        self._last_ai_text: str = ""
        self._last_ai_message_id: str = ""

        # Tool lifecycle deduplication
        self._tool_requested_emitted: set[str] = set()
        self._tool_approval_emitted: set[str] = set()
        self._tool_approval_in_flight: set[str] = set()
        self._tool_executed_emitted: set[str] = set()
        self._tool_registry: dict[str, dict[str, str]] = {}

        # Init metadata
        self._last_init_meta: dict[str, Any] | None = None

        # In-process graph runner (set via from_in_process)
        self._in_process_runner: Any | None = None  # InProcessGraphRunner
        self._use_in_process: bool = False
        self._graph_builder: Any | None = None

        # Public clients (lazy initialized)
        self._info_client: Any | None = None
        self._sessions_client: Any | None = None

    @classmethod
    def from_agent(
        cls,
        agent_object: AIAssistantConfig | dict[str, Any],
        **options: Any,
    ) -> QodoSDK:
        """
        Create SDK instance from an agent configuration object.

        Args:
            agent_object: Agent configuration (AIAssistantConfig or dict).
            **options: Additional SDK options.

        Returns:
            A new QodoSDK instance configured with the agent.
        """
        if isinstance(agent_object, AIAssistantConfig):
            agent_dict = agent_object.model_dump(exclude_none=True)
        else:
            agent_dict = agent_object

        # Remove redundant 'name' from commands to avoid server-side conflict
        # (the name is already the dict key)
        if "commands" in agent_dict and isinstance(agent_dict["commands"], dict):
            for cmd_data in agent_dict["commands"].values():
                if isinstance(cmd_data, dict) and "name" in cmd_data:
                    del cmd_data["name"]

        return cls(QodoSDKOptions(agent_object=agent_dict, **options))

    @classmethod
    def from_in_process(
        cls,
        graph_builder: Callable[..., Any],
        **options: Any,
    ) -> QodoSDK:
        """
        Create an SDK instance that runs a LangGraph graph in-process.

        Bypasses auth, ServerData, SessionContext, and AgentAPI/WebSocket entirely.
        Only initializes MCPManager (for tool execution) and ConfigManager (for
        agent config resolution).

        Args:
            graph_builder: A callable that takes a MemorySaver checkpointer and
                returns a compiled LangGraph StateGraph. Typically this is the
                ``_build_sdk_graph`` function from Command Backend.
            **options: Additional QodoSDKOptions fields (project_path, model, etc.).

        Returns:
            A new QodoSDK instance configured for in-process execution.

        Example:
            from command.agents.graphs.sdk_graph import _build_sdk_graph

            sdk = QodoSDK.from_in_process(
                _build_sdk_graph,
                project_path="/path/to/project",
                model="gpt-4",
            )
            result = await sdk.run("Review this code")
        """
        instance = cls(QodoSDKOptions(**options))
        instance._use_in_process = True
        instance._graph_builder = graph_builder
        return instance

    def with_session(self, session_id: str) -> QodoSDK:
        """
        Create a new SDK instance bound to a specific session ID.

        Args:
            session_id: The session ID to bind to.

        Returns:
            A new QodoSDK instance with the session ID configured.
        """
        new_flags = {**self._options.flags, "sid": session_id}
        new_options = QodoSDKOptions(
            api_key=self._options.api_key,
            agent_file=self._options.agent_file,
            agent_content=self._options.agent_content,
            agent_object=self._options.agent_object,
            mcp_file=self._options.mcp_file,
            mcp_servers=self._options.mcp_servers,
            model=self._options.model,
            context_session_ids=self._options.context_session_ids,
            auto_approve_tools=self._options.auto_approve_tools,
            tool_approval=self._options.tool_approval,
            flags=new_flags,
            debug=self._options.debug,
            logger=self._options.logger,
            project_path=self._options.project_path,
            additional_paths=self._options.additional_paths,
            backend_base_url=self._options.backend_base_url,
        )
        return QodoSDK(new_options)

    @property
    def info(self) -> Any:
        """Get the QodoInfoClient for backend information."""
        if self._info_client is None:
            from qodo.clients.info import QodoInfoClient

            self._info_client = QodoInfoClient()
        return self._info_client

    @property
    def sessions(self) -> Any:
        """Get the QodoSessionsClient for session management."""
        if self._sessions_client is None:
            from qodo.clients.sessions import QodoSessionsClient

            self._sessions_client = QodoSessionsClient()
        return self._sessions_client

    def _convert_event_data(self, event_type: SdkEventType, data: Any) -> Any:
        """Convert raw dict data to appropriate dataclass based on event type."""
        if not isinstance(data, dict):
            return data

        type_map = {
            SdkEventType.INIT: SdkInitData,
            SdkEventType.RUN_STARTED: SdkRunStartedData,
            SdkEventType.MESSAGE_DELTA: SdkMessageDeltaData,
            SdkEventType.MESSAGE_FULL: SdkMessageFullData,
            SdkEventType.PROGRESS: SdkProgressData,
            SdkEventType.TOOL_REQUESTED: SdkToolRequestedData,
            SdkEventType.TOOL_APPROVED: SdkToolApprovedData,
            SdkEventType.TOOL_EXECUTED: SdkToolExecutedData,
            SdkEventType.ERROR: SdkErrorData,
            SdkEventType.FINAL: SdkFinalData,
        }

        dataclass_type = type_map.get(event_type)
        if dataclass_type is None:
            return data

        try:
            # Filter to only include fields that exist in the dataclass
            import dataclasses

            field_names = {f.name for f in dataclasses.fields(dataclass_type)}
            filtered_data = {k: v for k, v in data.items() if k in field_names}
            return dataclass_type(**filtered_data)
        except (TypeError, ValueError):
            # If conversion fails, return raw dict
            return data

    def _push_event(
        self,
        event_type: str | SdkEventType,
        session_id: str,
        data: Any,
        request_id: str | None = None,
    ) -> None:
        """Push an event to the queue."""
        elapsed_ms = (
            int((asyncio.get_event_loop().time() * 1000) - self._run_start_ms)
            if self._run_start_ms
            else None
        )

        self._seq += 1

        # Convert raw dict to appropriate dataclass
        typed_event_type = SdkEventType(event_type) if isinstance(event_type, str) else event_type
        converted_data = self._convert_event_data(typed_event_type, data)

        event = create_sdk_event(
            event_type=typed_event_type,
            run_id=self._run_id,
            seq=self._seq,
            session_id=session_id,
            data=converted_data,
            request_id=request_id,
            elapsed_ms=elapsed_ms,
        )

        if self._pending_resolvers:
            resolver = self._pending_resolvers.pop(0)
            resolver({"value": event, "done": False})
        else:
            self._event_queue.append(event)

    async def _ensure_initialized(self, desired_command_name: str | None = None) -> dict[str, Any]:
        """Ensure SDK is initialized and return init metadata."""
        if self._initialized:
            return self._last_init_meta or {
                "command_name": "",
                "prompt_mode": False,
                "project_path": self._options.project_path or os.getcwd(),
                "agent_source": {"source": "default"},
            }

        # In-process mode: skip auth, ServerData, SessionContext, AgentAPI
        if self._use_in_process:
            return await self._ensure_initialized_in_process(desired_command_name)

        from qodo.api.agent import AgentAPI
        from qodo.auth import AuthProvider
        from qodo.session.server_data import ServerData

        # Step 1: Create environment-scoped auth provider
        auth_provider = AuthProvider(self._options.api_key)
        self._env.auth_provider = auth_provider

        # Step 1b: Create ToolProcessorManager
        from qodo.mcp.tool_processor import ToolProcessorManager

        tpm = ToolProcessorManager(middleware=self._options.tool_middleware)
        self._env.tool_processor_manager = tpm

        # Step 2: Validate authentication
        try:
            auth_provider.validate()
        except Exception as e:
            raise QodoError(f"Authentication failed: {e}") from e

        # Step 3: Bootstrap backend
        try:
            server_data = await ServerData.init(base_url_override=self._options.backend_base_url)
            self._env.server_data = server_data
        except Exception as e:
            raise QodoError(f"Failed to connect to backend: {e}") from e

        # Flags setup
        flags: dict[str, Any] = {
            **self._options.flags,
            "sdk": True,
        }
        if self._options.debug:
            flags["debug"] = True
        if self._options.model:
            flags["model"] = self._options.model
        if self._options.interactive_mode is not None:
            flags["interactiveMode"] = self._options.interactive_mode

        # Resolve project path
        effective_cwd = self._options.project_path or os.getcwd()

        # Step 3: Agent config resolution
        agent_config: str | dict[str, Any] | AIAssistantConfig | None = None
        is_file_content = False
        agent_source: dict[str, Any] = {"source": "default"}

        if self._options.agent_object:
            agent_config = self._options.agent_object
            is_file_content = True
            agent_source = {"source": "object"}
        elif self._options.agent_content:
            agent_config = self._options.agent_content
            is_file_content = True
            agent_source = {"source": "content"}
        elif self._options.agent_file:
            agent_config = self._options.agent_file
            agent_source = {"source": "file", "path": self._options.agent_file}

        # Step 4: Initialize ConfigManager
        self._config_manager = await ConfigManager.init(
            agent_config=agent_config,
            is_file_content=is_file_content,
        )
        self._env.config_manager = self._config_manager

        # Step 5: Resolve command
        all_commands = self._config_manager.list_commands()
        desired_is_command = bool(desired_command_name and desired_command_name in all_commands)

        command: CommandConfig
        cmd_name = ""
        prompt_mode = False

        if desired_is_command:
            cmd_name = desired_command_name or ""
            command = self._config_manager.get_command_config(cmd_name)
        elif desired_command_name and desired_command_name.strip():
            # Treat as prompt
            cmd_name = ""
            prompt_mode = True
            command = self._config_manager.get_command_config(desired_command_name)
        elif all_commands:
            cmd_name = self._config_manager.get_single_command() or ""
            command = self._config_manager.get_command_config(cmd_name)
        else:
            # No commands: synthesize default
            cmd_name = ""
            prompt_mode = True
            command = self._config_manager.get_command_config("")

        # Step 6: Initialize SessionContext
        general_instructions = self._config_manager.get_general_instructions()
        system_prompt = self._config_manager.get_system_prompt()

        self._session_context = await SessionContext.new_session_context(
            flags=flags,
            command=command,
            general_instructions=general_instructions,
            system_prompt=system_prompt,
            session_id=self._options.flags.get("sid"),
        )
        self._env.session_context = self._session_context

        # Set model
        model = self._options.model or server_data.get_default_model()
        if model:
            self._session_context.set_model(model)

        # Set accessible paths
        self._session_context.set_current_working_directory(effective_cwd)
        paths_to_set = [effective_cwd]
        if self._options.additional_paths:
            paths_to_set.extend(self._options.additional_paths)
        await self._session_context.set_accessible_paths(paths_to_set)

        # Step 7: Initialize MCPManager
        self._mcp_manager = await MCPManager.init()
        self._env.mcp_manager = self._mcp_manager

        # Step 8: Emit init event
        self._push_event(
            SdkEventType.INIT,
            self._session_context.get_session_id(),
            {
                "sdk_version": get_sdk_version(),
                "protocol": "qodo.sdk.v2",
                "pid": os.getpid(),
                "backend": {
                    "base_url": server_data.get_base_url(),
                    "source": server_data.get_base_url_source(),
                },
                "model": self._session_context.get_model(),
            },
        )

        # Step 9: Create MessageManager and attach listeners
        self._message_manager = MessageManager()
        self._env.message_manager = self._message_manager
        self._setup_message_listeners()

        # Step 10: Create AgentAPI and AgentRunnerCore
        self._agent = AgentAPI(self._session_context)
        self._core = AgentRunnerCore(
            session_context=self._session_context,
            message_manager=self._message_manager,
            agent=self._agent,
            emit=lambda event_type, data: None,  # No-op: we emit via message listeners
            auto_approve_tools=self._options.auto_approve_tools,
        )

        # Step 11: Register connection state change handler for unexpected disconnects
        def on_connection_state_changed(state: ConnectionState) -> None:
            if state == ConnectionState.DISCONNECTED and not self._done:
                # Unexpected disconnect - emit FINAL event to unblock waiting consumers
                sid = self._session_context.get_session_id() if self._session_context else ""
                current_error = self._message_manager.get_error() if self._message_manager else None
                error_msg = current_error or "Connection closed unexpectedly"

                self._push_event(
                    SdkEventType.FINAL,
                    sid,
                    {
                        "success": False,
                        "error": error_msg,
                        "model": (
                            self._session_context.get_model() if self._session_context else ""
                        ),
                        "result": {},
                        "messages": {"langchain": [], "openai": []},
                        "meta": {
                            "tools_auto_approved": self._options.auto_approve_tools,
                            "subagents_used": False,
                        },
                    },
                )
                self._done = True

        self._agent.on_connection_state_changed(on_connection_state_changed)

        self._initialized = True
        self._last_init_meta = {
            "command_name": cmd_name,
            "prompt_mode": prompt_mode,
            "project_path": effective_cwd,
            "agent_source": agent_source,
        }

        return self._last_init_meta

    async def _ensure_initialized_in_process(
        self, desired_command_name: str | None = None
    ) -> dict[str, Any]:
        """Initialize SDK in in-process mode (no auth, no backend, no WebSocket).

        Only initializes MCPManager and ConfigManager, then creates the
        InProcessGraphRunner.
        """
        from qodo.api.in_process import InProcessGraphRunner
        from qodo.mcp.tool_processor import ToolProcessorManager

        # ToolProcessorManager (needed by MCPManager internals)
        tpm = ToolProcessorManager(middleware=self._options.tool_middleware)
        self._env.tool_processor_manager = tpm

        effective_cwd = self._options.project_path or os.getcwd()

        # Agent config resolution (same logic as standard path)
        agent_config: str | dict[str, Any] | AIAssistantConfig | None = None
        is_file_content = False
        agent_source: dict[str, Any] = {"source": "in_process"}

        if self._options.agent_object:
            agent_config = self._options.agent_object
            is_file_content = True
            agent_source = {"source": "object"}
        elif self._options.agent_content:
            agent_config = self._options.agent_content
            is_file_content = True
            agent_source = {"source": "content"}
        elif self._options.agent_file:
            agent_config = self._options.agent_file
            agent_source = {"source": "file", "path": self._options.agent_file}

        # Initialize ConfigManager
        self._config_manager = await ConfigManager.init(
            agent_config=agent_config,
            is_file_content=is_file_content,
        )
        self._env.config_manager = self._config_manager

        # Resolve command
        all_commands = self._config_manager.list_commands()
        desired_is_command = bool(desired_command_name and desired_command_name in all_commands)

        cmd_name = ""
        prompt_mode = False

        if desired_is_command:
            cmd_name = desired_command_name or ""
        elif desired_command_name and desired_command_name.strip():
            cmd_name = ""
            prompt_mode = True
        elif all_commands:
            cmd_name = self._config_manager.get_single_command() or ""
        else:
            cmd_name = ""
            prompt_mode = True

        # Initialize MCPManager for tool execution
        self._mcp_manager = await MCPManager.init()
        self._env.mcp_manager = self._mcp_manager

        # Create InProcessGraphRunner
        assert self._graph_builder is not None
        self._in_process_runner = InProcessGraphRunner(
            graph_builder=self._graph_builder,
            mcp_manager=self._mcp_manager,
            auto_approve_tools=self._options.auto_approve_tools,
        )

        self._initialized = True
        self._last_init_meta = {
            "command_name": cmd_name,
            "prompt_mode": prompt_mode,
            "project_path": effective_cwd,
            "agent_source": agent_source,
        }

        return self._last_init_meta

    def _setup_message_listeners(self) -> None:
        """Set up listeners on MessageManager for v2 events."""
        if not self._message_manager or not self._session_context:
            return

        # Message listener: emit sdk.message.full, sdk.message.delta, sdk.progress
        def on_messages(messages: list[Message]) -> None:
            lc = to_langchain_dict(messages)
            openai_msgs = to_openai_chat(messages)

            sid = self._session_context.get_session_id()  # type: ignore[union-attr]

            # Emit full message snapshot
            self._push_event(
                SdkEventType.MESSAGE_FULL,
                sid,
                {"messages": {"langchain": lc, "openai": openai_msgs}},
            )

            # Extract progress
            try:
                progress = extract_progress(messages)
                if progress:
                    self._push_event(SdkEventType.PROGRESS, sid, progress)
            except Exception:
                pass  # non-fatal: progress extraction is best-effort

            # Extract tool lifecycle
            try:
                self._extract_tool_lifecycle_from_langchain(lc, sid)
            except Exception:
                pass  # non-fatal: tool lifecycle extraction is best-effort

            # Delta: compare last AI message
            try:
                last_ai: AIMessage | None = None
                for msg in reversed(messages):
                    if isinstance(msg, AIMessage):
                        last_ai = msg
                        break

                if last_ai:
                    text = last_ai.content if isinstance(last_ai.content, str) else ""
                    message_id = last_ai.id or last_ai.additional_kwargs.get("id", "ai")

                    if message_id != self._last_ai_message_id:
                        self._last_ai_message_id = message_id
                        self._last_ai_text = ""

                    if text.startswith(self._last_ai_text) and len(text) > len(self._last_ai_text):
                        delta = text[len(self._last_ai_text) :]
                        if delta:
                            self._push_event(
                                SdkEventType.MESSAGE_DELTA,
                                sid,
                                {
                                    "message_id": str(message_id),
                                    "role": "assistant",
                                    "delta": delta,
                                },
                            )
                    self._last_ai_text = text
            except Exception:
                pass  # non-fatal: delta extraction is best-effort

        self._message_manager.add_message_listener(on_messages)

        # Loading listener: emit sdk.final when done
        def on_loading(is_loading: bool) -> None:
            if is_loading:
                return

            sid = self._session_context.get_session_id()  # type: ignore[union-attr]

            try:
                # Finish current task
                self._agent.finish_current_task(is_error=False)  # type: ignore[union-attr]
            except Exception:
                pass  # best-effort: must not block finalization

            try:
                finalized = build_final_result(self._message_manager)  # type: ignore[arg-type]
                current_error = self._message_manager.get_error()  # type: ignore[union-attr]
                success = not current_error

                result: dict[str, Any] = {}
                if finalized.get("structured_output"):
                    result["structured_output"] = finalized["structured_output"]
                if finalized.get("final_output"):
                    result["final_output"] = finalized["final_output"]

                meta: dict[str, Any] = {
                    "tools_auto_approved": self._options.auto_approve_tools,
                    "subagents_used": finalized.get("subagents_used", False),
                }
                if self._session_context and self._session_context.is_dry_run():
                    meta["dry_run"] = True

                self._push_event(
                    SdkEventType.FINAL,
                    sid,
                    {
                        "success": success,
                        **({"error": current_error} if current_error else {}),
                        "model": self._session_context.get_model(),  # type: ignore[union-attr]
                        "result": result,
                        "messages": {
                            "langchain": finalized.get("messages_lc", []),
                            "openai": finalized.get("messages_openai", []),
                        },
                        "meta": meta,
                    },
                )
                self._done = True
            except Exception as e:
                self._push_event(
                    SdkEventType.ERROR,
                    sid,
                    {"message": str(e) or "Failed to finalize"},
                )
                self._push_event(
                    SdkEventType.FINAL,
                    sid,
                    {
                        "success": False,
                        "error": str(e) or "Failed to finalize",
                        "model": self._session_context.get_model(),  # type: ignore[union-attr]
                        "result": {},
                        "messages": {"langchain": [], "openai": []},
                        "meta": {
                            "tools_auto_approved": self._options.auto_approve_tools,
                            "subagents_used": False,
                        },
                    },
                )
                self._done = True

        self._message_manager.add_loading_listener(on_loading)

        # Error listener: emit sdk.error
        def on_error(error: str | None) -> None:
            if not error:
                return

            sid = self._session_context.get_session_id()  # type: ignore[union-attr]
            self._push_event(SdkEventType.ERROR, sid, {"message": error})

            try:
                self._agent.finish_current_task(is_error=True)  # type: ignore[union-attr]
            except Exception:
                pass  # best-effort: must not block error handling

        self._message_manager.add_error_listener(on_error)

    def _extract_tool_lifecycle_from_langchain(
        self, lc_messages: list[dict[str, Any]], sid: str
    ) -> None:
        """Extract tool lifecycle events from LangChain format messages."""
        for msg in lc_messages:
            msg_type = msg.get("type")
            data = msg.get("data", {})

            if not msg_type or not data:
                continue

            # Tool request: AI message with tool_calls
            if msg_type == "ai" and data.get("tool_calls"):
                pending_approval = data.get("additional_kwargs", {}).get("pending_approval", False)
                server_name = data.get("additional_kwargs", {}).get("server_name", "unknown")

                for call in data.get("tool_calls", []):
                    tool_call_id = str(call.get("id") or data.get("id") or "unknown")
                    tool_name = str(call.get("name") or "unknown")

                    # Register for later sdk.tool.executed
                    if tool_call_id and tool_call_id != "unknown":
                        self._tool_registry[tool_call_id] = {
                            "server_name": server_name,
                            "tool_name": tool_name,
                        }

                    # Emit tool.requested once
                    if tool_call_id not in self._tool_requested_emitted:
                        self._push_event(
                            SdkEventType.TOOL_REQUESTED,
                            sid,
                            {
                                "tool_call_id": tool_call_id,
                                "server_name": server_name,
                                "tool_name": tool_name,
                                "tool_args": call.get("args"),
                                "reasoning": (
                                    data.get("content")
                                    if isinstance(data.get("content"), str)
                                    else None
                                ),
                                "pending_approval": pending_approval,
                            },
                        )
                        self._tool_requested_emitted.add(tool_call_id)

                    # Handle approval
                    if tool_call_id not in self._tool_approval_emitted:
                        if pending_approval:
                            # Approval required
                            asyncio.create_task(
                                self._maybe_approve_tool(
                                    sid=sid,
                                    tool_call_id=tool_call_id,
                                    server_name=server_name,
                                    tool_name=tool_name,
                                    tool_args=call.get("args"),
                                    reasoning=(
                                        data.get("content")
                                        if isinstance(data.get("content"), str)
                                        else None
                                    ),
                                )
                            )
                        else:
                            # Auto-approved
                            self._push_event(
                                SdkEventType.TOOL_APPROVED,
                                sid,
                                {"tool_call_id": tool_call_id, "approved": True},
                            )
                            self._tool_approval_emitted.add(tool_call_id)

            # Tool result: ToolMessage
            if msg_type == "tool":
                tool_call_id = str(data.get("tool_call_id") or data.get("id") or "unknown")

                if tool_call_id not in self._tool_executed_emitted:
                    registry_entry = self._tool_registry.get(tool_call_id, {})
                    server_name = str(
                        data.get("additional_kwargs", {}).get("server_name")
                        or registry_entry.get("server_name", "unknown")
                    )
                    tool_name = str(registry_entry.get("tool_name", "unknown"))
                    status = data.get("status")

                    self._push_event(
                        SdkEventType.TOOL_EXECUTED,
                        sid,
                        {
                            "tool_call_id": tool_call_id,
                            "server_name": server_name,
                            "tool_name": tool_name,
                            "result": {
                                "isError": status == "error",
                                "content": data.get("content"),
                                "raw": data,
                            },
                        },
                    )
                    self._tool_executed_emitted.add(tool_call_id)

    async def _maybe_approve_tool(
        self,
        sid: str,
        tool_call_id: str,
        server_name: str,
        tool_name: str,
        tool_args: Any,
        reasoning: str | None = None,
    ) -> None:
        """Handle tool approval decision."""
        if (
            tool_call_id in self._tool_approval_emitted
            or tool_call_id in self._tool_approval_in_flight
        ):
            return

        self._tool_approval_in_flight.add(tool_call_id)

        approved = self._options.auto_approve_tools
        reason: str | None = None

        if not self._options.auto_approve_tools:
            if self._options.tool_approval:
                try:
                    result = self._options.tool_approval(
                        ToolApprovalRequest(
                            tool_call_id=tool_call_id,
                            server_name=server_name,
                            tool_name=tool_name,
                            tool_args=tool_args,
                            reasoning=reasoning,
                        )
                    )
                    if asyncio.iscoroutine(result):
                        approved = await result
                    else:
                        approved = bool(result)

                    if not approved:
                        reason = "Declined by tool_approval callback"
                except Exception as e:
                    approved = False
                    reason = str(e) or "tool_approval callback threw"
            else:
                approved = False
                reason = "Auto-approval disabled and no tool_approval callback provided"

        # Emit decision
        event_data: dict[str, Any] = {"tool_call_id": tool_call_id, "approved": approved}
        if not approved and reason:
            event_data["reason"] = reason

        self._push_event(SdkEventType.TOOL_APPROVED, sid, event_data)
        self._tool_approval_emitted.add(tool_call_id)

        # Respond to backend
        try:
            await self._agent.tool_approval(tool_call_id, approved)  # type: ignore[union-attr]
        except Exception as e:
            self._push_event(
                SdkEventType.ERROR,
                sid,
                {
                    "message": f"Failed to submit tool approval for {tool_call_id}",
                    "cause": str(e),
                },
            )
        finally:
            self._tool_approval_in_flight.discard(tool_call_id)

    async def stream(
        self,
        command_or_prompt: str,
        *,
        extra_instructions: str | None = None,
        args: dict[str, Any] | None = None,
        output_schema: Any | None = None,
        timeout: int | None = None,
        dry_run: bool | None = None,
    ) -> AsyncIterator[QodoSdkEvent]:
        """
        Stream events from an agent run.

        Args:
            command_or_prompt: Command name or free-form prompt.
            extra_instructions: Additional instructions for the agent.
            args: Arguments for the command.
            output_schema: Pydantic model or JSON schema for structured output.
            timeout: Execution timeout in milliseconds.

        Yields:
            QodoSdkEvent instances for each event during execution.
        """
        # Delegate to another instance if already running
        if self._active_runs > 0:
            delegated = QodoSDK(self._options)
            try:
                async for event in delegated.stream(
                    command_or_prompt,
                    extra_instructions=extra_instructions,
                    args=args,
                    output_schema=output_schema,
                    timeout=timeout,
                    dry_run=dry_run,
                ):
                    yield event
            finally:
                await delegated.dispose()
            return

        self._active_runs += 1
        try:
            # Reset state for new run
            self._done = False
            self._event_queue = []
            self._pending_resolvers = []
            self._last_ai_text = ""
            self._last_ai_message_id = ""
            self._tool_requested_emitted.clear()
            self._tool_approval_emitted.clear()
            self._tool_approval_in_flight.clear()
            self._tool_executed_emitted.clear()
            self._tool_registry.clear()

            # Per-run metadata
            self._run_id = str(uuid.uuid4())
            self._seq = 0
            self._run_start_ms = int(asyncio.get_event_loop().time() * 1000)

            # Run with environment isolation
            # NOTE: We manually manage the context variable instead of using a context
            # manager because async generators can be cleaned up in a different context
            # (e.g., when the consumer breaks out of the loop), causing ContextVar.reset()
            # to fail with "was created in a different Context".
            env_token = _env_context.set(self._env)
            try:
                init_failed = False
                init_meta: dict[str, Any] | None = None

                try:
                    init_meta = await self._ensure_initialized(command_or_prompt)
                except Exception as e:
                    init_failed = True
                    self._push_event(SdkEventType.ERROR, "", {"message": str(e), "cause": str(e)})
                    self._push_event(
                        SdkEventType.FINAL,
                        "",
                        {
                            "success": False,
                            "error": str(e),
                            "model": self._options.model or "",
                            "result": {},
                            "messages": {"langchain": [], "openai": []},
                            "meta": {
                                "tools_auto_approved": self._options.auto_approve_tools,
                                "subagents_used": False,
                            },
                        },
                    )

                # In-process mode: delegate directly to InProcessGraphRunner
                if not init_failed and init_meta and self._in_process_runner:
                    try:
                        # Build the user request text
                        user_request = command_or_prompt or ""
                        if extra_instructions:
                            user_request = (
                                f"{user_request} {extra_instructions}".strip()
                                if user_request
                                else extra_instructions
                            )

                        # Build available_tools map from MCPManager
                        ip_available_tools: dict[str, list[dict[str, Any]]] = {}
                        if self._mcp_manager:
                            enabled = self._mcp_manager.get_enabled_tools()
                            for server_id, tool_list in enabled.items():
                                ip_available_tools[server_id] = [
                                    {
                                        "name": t.name,
                                        "description": t.description,
                                        "inputSchema": t.input_schema,
                                    }
                                    for t in tool_list
                                ]

                        # Resolve output_schema to dict
                        ip_output_schema = None
                        if output_schema is not None:
                            if hasattr(output_schema, "model_dump"):
                                ip_output_schema = output_schema.model_dump(exclude_none=True)
                            elif isinstance(output_schema, dict):
                                ip_output_schema = output_schema

                        # Get command config for instructions/system_prompt
                        cmd_config = None
                        if self._config_manager:
                            cmd_config = self._config_manager.get_command_config(
                                init_meta["command_name"]
                            )

                        instructions = (
                            getattr(cmd_config, "instructions", None) if cmd_config else None
                        )
                        system_prompt_val = None
                        if self._config_manager:
                            system_prompt_val = self._config_manager.get_system_prompt()

                        async for event in self._in_process_runner.execute(
                            command_config=cmd_config,
                            session_id=self._options.flags.get("sid", str(uuid.uuid4())),
                            workspace_path=init_meta["project_path"],
                            user_request=user_request,
                            available_tools=ip_available_tools,
                            output_schema=ip_output_schema,
                            custom_model=self._options.model,
                            instructions=instructions,
                            system_prompt=system_prompt_val,
                            additional_paths=self._options.additional_paths,
                            timeout=timeout,
                        ):
                            yield event
                    except Exception as e:
                        from qodo.sdk.events import EventEmitter

                        fallback_emitter = EventEmitter(
                            run_id=str(uuid.uuid4()),
                            session_id=self._options.flags.get("sid", ""),
                        )
                        yield fallback_emitter.error(str(e), cause=str(e))
                        yield fallback_emitter.final(
                            success=False,
                            model=self._options.model or "",
                            error=str(e),
                            meta={"tools_auto_approved": self._options.auto_approve_tools},
                        )

                elif not init_failed and init_meta:
                    # Thread dry_run flag
                    if dry_run and self._session_context:
                        self._session_context._flags["dry_run"] = True

                    # Emit run.started
                    assert self._session_context is not None
                    sid = self._session_context.get_session_id()
                    self._push_event(
                        SdkEventType.RUN_STARTED,
                        sid,
                        {
                            "session_id": sid,
                            "command": init_meta["command_name"],
                            "prompt_mode": init_meta["prompt_mode"],
                            "cwd": init_meta["project_path"],
                            "agent": init_meta["agent_source"],
                            "tools_auto_approved": self._options.auto_approve_tools,
                            "dry_run": dry_run or None,
                        },
                    )

                    # Determine prompt vs command mode
                    all_commands = (
                        self._config_manager.list_commands() if self._config_manager else []
                    )
                    if command_or_prompt and command_or_prompt in all_commands:
                        prompt = command_or_prompt
                        prompt_extra = extra_instructions or ""
                    else:
                        prompt = ""
                        if command_or_prompt:
                            prompt_extra = f"{command_or_prompt}"
                            if extra_instructions:
                                prompt_extra += f" {extra_instructions}"
                        else:
                            prompt_extra = extra_instructions or ""

                    if dry_run:
                        dry_run_playbook = (
                            "\n--- DRY RUN MODE ---\n"
                            "This run is executing in dry-run mode. Important rules:\n"
                            "1. Every tool call you make will be intercepted. You will "
                            "receive simulated (mock) responses marked with "
                            '"[DRY RUN]".\n'
                            "2. Treat simulated results as plausible placeholders "
                            "\u2014 reason about them as if they were real data.\n"
                            "3. Continue your analysis normally. Describe what actions "
                            "you would take and what results you would expect.\n"
                            "4. Do NOT tell the user that tools are unavailable or "
                            "that you cannot access the filesystem. Tools are working "
                            "\u2014 their results are simply simulated.\n"
                            "5. In your final answer, clearly summarize the plan of "
                            "actions you would execute in a real run, including which "
                            "tools you called and why.\n"
                            "--- END DRY RUN MODE ---\n"
                        )
                        prompt_extra = dry_run_playbook + "\n" + prompt_extra

                    try:
                        assert self._core is not None
                        await self._core.start(
                            prompt=prompt,
                            extra_instructions=prompt_extra,
                            command_args=args,
                            output_schema=output_schema,
                        )
                    except Exception as e:
                        self._push_event(SdkEventType.ERROR, sid, {"message": str(e)})
                        self._push_event(
                            SdkEventType.FINAL,
                            sid,
                            {
                                "success": False,
                                "error": str(e),
                                "model": self._session_context.get_model()
                                if self._session_context
                                else "",
                                "result": {},
                                "messages": {"langchain": [], "openai": []},
                                "meta": {
                                    "tools_auto_approved": self._options.auto_approve_tools,
                                    "subagents_used": False,
                                },
                            },
                        )

                # For in-process mode, all events have been yielded above; skip draining
                if not self._in_process_runner:
                    # Set up timeout if specified
                    timeout_task: asyncio.Task[None] | None = None
                    if timeout is not None and timeout > 0:

                        async def _timeout_handler() -> None:
                            await asyncio.sleep(timeout / 1000)  # ms to seconds
                            sid_for_timeout = (
                                self._session_context.get_session_id()
                                if self._session_context
                                else ""
                            )
                            self._push_event(
                                SdkEventType.ERROR,
                                sid_for_timeout,
                                {
                                    "message": (f"Execution timed out after {timeout}ms"),
                                },
                            )
                            self._push_event(
                                SdkEventType.FINAL,
                                sid_for_timeout,
                                {
                                    "success": False,
                                    "error": (f"Execution timed out after {timeout}ms"),
                                    "model": (
                                        self._session_context.get_model()
                                        if self._session_context
                                        else ""
                                    ),
                                    "result": {},
                                    "messages": {
                                        "langchain": [],
                                        "openai": [],
                                    },
                                    "meta": {
                                        "tools_auto_approved": (self._options.auto_approve_tools),
                                        "subagents_used": False,
                                        "timed_out": True,
                                    },
                                },
                            )
                            try:
                                self.cancel()
                            except Exception:
                                pass  # best-effort cancel

                        timeout_task = asyncio.create_task(_timeout_handler())

                    # Drain events
                    try:
                        while True:
                            if self._event_queue:
                                event = self._event_queue.pop(0)
                                yield event

                                if event.type == SdkEventType.FINAL:
                                    self._done = True
                                    # Drain remaining
                                    while self._event_queue:
                                        yield self._event_queue.pop(0)
                                    break
                            else:
                                # Wait for next event
                                next_event = await self._wait_for_event()
                                if next_event:
                                    yield next_event

                                    if next_event.type == SdkEventType.FINAL:
                                        self._done = True
                                        while self._event_queue:
                                            yield self._event_queue.pop(0)
                                        break

                            if self._done and not self._event_queue:
                                break
                    finally:
                        if timeout_task and not timeout_task.done():
                            timeout_task.cancel()
            finally:
                # Reset context variable, ignoring errors if context changed
                # (can happen when async generator is cleaned up in different context)
                try:
                    _env_context.reset(env_token)
                except ValueError:
                    pass  # expected: async generator cleanup may run in a different context

        finally:
            self._active_runs = max(0, self._active_runs - 1)

    async def _wait_for_event(self) -> QodoSdkEvent | None:
        """Wait for next event from queue."""
        future: asyncio.Future[dict[str, Any]] = asyncio.Future()

        def resolver(result: dict[str, Any]) -> None:
            if not future.done():
                future.set_result(result)

        self._pending_resolvers.append(resolver)

        # Check if event arrived while setting up
        if self._event_queue:
            event = self._event_queue.pop(0)
            if self._pending_resolvers:
                r = self._pending_resolvers.pop(0)
                r({"value": event, "done": False})

        result = await future
        if result.get("done"):
            return None
        return result.get("value")

    async def run(
        self,
        command_or_prompt: str,
        *,
        extra_instructions: str | None = None,
        args: dict[str, Any] | None = None,
        output_schema: Any | None = None,
        timeout: int | None = None,
        max_retries: int | None = None,
        dry_run: bool | None = None,
    ) -> QodoSDKRunResult:
        """
        Execute an agent run and return the final result.

        Args:
            command_or_prompt: Command name or free-form prompt.
            extra_instructions: Additional instructions for the agent.
            args: Arguments for the command.
            output_schema: Pydantic model or JSON schema for structured output.
            timeout: Execution timeout in milliseconds.
            max_retries: Number of retries after the first attempt.

        Returns:
            QodoSDKRunResult with the final run results.
        """
        max_attempts = (max_retries or 0) + 1
        last_result: QodoSDKRunResult | None = None

        for attempt in range(max_attempts):
            if attempt > 0:
                logger.info(f"Retrying run (attempt {attempt + 1}/{max_attempts})")
                await self.dispose()

            final_result: QodoSDKRunResult | None = None
            async for event in self.stream(
                command_or_prompt,
                extra_instructions=extra_instructions,
                args=args,
                output_schema=output_schema,
                timeout=timeout,
                dry_run=dry_run,
            ):
                if event.type == SdkEventType.FINAL:
                    data: Any = event.data
                    final_result = QodoSDKRunResult(
                        success=(
                            data.success if hasattr(data, "success") else data.get("success", False)
                        ),
                        error=(data.error if hasattr(data, "error") else data.get("error")),
                        model=(data.model if hasattr(data, "model") else data.get("model", "")),
                        result=(data.result if hasattr(data, "result") else data.get("result", {})),
                        messages=(
                            data.messages if hasattr(data, "messages") else data.get("messages", {})
                        ),
                        meta=(data.meta if hasattr(data, "meta") else data.get("meta", {})),
                    )

            last_result = final_result or QodoSDKRunResult(
                success=False, error="No final event received"
            )

            if last_result.success:
                return last_result

        return last_result or QodoSDKRunResult(success=False, error="No final event received")

    async def prompt(
        self,
        text: str,
        *,
        args: dict[str, Any] | None = None,
        output_schema: Any | None = None,
    ) -> QodoSDKRunResult:
        """
        Execute a free-form prompt (never a command name).

        Args:
            text: The prompt text.
            args: Optional arguments.
            output_schema: Pydantic model or JSON schema for structured output.

        Returns:
            QodoSDKRunResult with the final run results.
        """
        return await self.run("", extra_instructions=text, args=args, output_schema=output_schema)

    async def stream_prompt(
        self,
        text: str,
        *,
        args: dict[str, Any] | None = None,
        output_schema: Any | None = None,
    ) -> AsyncIterator[QodoSdkEvent]:
        """
        Stream events for a free-form prompt.

        Args:
            text: The prompt text.
            args: Optional arguments.
            output_schema: Pydantic model or JSON schema for structured output.

        Yields:
            QodoSdkEvent instances for each event during execution.
        """
        async for event in self.stream(
            "", extra_instructions=text, args=args, output_schema=output_schema
        ):
            yield event

    def cancel(self) -> None:
        """Cancel the current running task."""
        if not self._initialized or not self._core:
            return
        self._core.cancel()

    async def dispose(self) -> None:
        """Clean up resources."""
        if not self._initialized:
            return

        with EnvironmentContext(self._env):
            try:
                if self._core:
                    await self._core.dispose()
                if self._agent:
                    try:
                        await self._agent.cleanup()
                    except Exception:
                        pass  # cleanup: agent teardown must not throw
                if self._mcp_manager:
                    try:
                        await self._mcp_manager.dispose()
                    except Exception:
                        pass  # cleanup: MCP dispose must not throw
            finally:
                self._initialized = False
                self._core = None
                self._agent = None
                self._mcp_manager = None
                self._message_manager = None
                self._session_context = None
                self._config_manager = None
                self._in_process_runner = None

    async def __aenter__(self) -> QodoSDK:
        """Enter async context manager."""
        return self

    async def __aexit__(
        self,
        exc_type: type | None,
        exc_val: BaseException | None,
        exc_tb: Any | None,
    ) -> None:
        """Exit async context manager."""
        await self.dispose()


# get_sdk_version is imported from qodo.sdk.events and re-exported via __init__.py
