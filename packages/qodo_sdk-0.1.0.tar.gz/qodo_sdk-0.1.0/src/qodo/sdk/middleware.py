"""
Tool middleware protocol and utilities.

Provides a middleware system for intercepting tool calls before and after
execution, mirroring the TypeScript SDK's middleware architecture.
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any, runtime_checkable

from typing_extensions import Protocol

from qodo.errors import ToolMiddlewareError

logger = logging.getLogger(__name__)

MIDDLEWARE_TIMEOUT_MS: int = 10_000

PROTECTED_TOOL_FIELDS: frozenset[str] = frozenset(
    {
        "identifier",
        "server_name",
        "session_id",
    }
)


@runtime_checkable
class ToolMiddleware(Protocol):
    """
    Protocol for tool middleware.

    Implementors may define either or both of pre_execute and post_execute.
    Both methods are optional — a class that implements neither still satisfies
    the protocol (but does nothing).
    """

    async def pre_execute(
        self,
        tool_name: str,
        server_name: str,
        args: dict[str, Any],
    ) -> dict[str, Any] | None:
        """
        Called before tool execution.

        Args:
            tool_name: Name of the tool being invoked.
            server_name: Name of the server providing the tool.
            args: Tool arguments dictionary.

        Returns:
            Modified args dict, or None to keep original args.
        """
        ...

    async def post_execute(
        self,
        tool_name: str,
        server_name: str,
        result: dict[str, Any],
    ) -> dict[str, Any] | None:
        """
        Called after tool execution.

        Args:
            tool_name: Name of the tool that was invoked.
            server_name: Name of the server that provided the tool.
            result: Tool result dictionary.

        Returns:
            Modified result dict, or None to keep original result.
        """
        ...


def strip_protected_fields(original: dict[str, Any], modified: dict[str, Any]) -> dict[str, Any]:
    """
    Copy modified dict but restore protected fields from original.

    If modified is None, returns original unchanged.

    Args:
        original: The original dictionary with protected field values.
        modified: The modified dictionary that may have altered protected fields.

    Returns:
        A new dictionary with modifications applied but protected fields preserved.
    """
    if modified is None:
        return original

    result = dict(modified)
    for field in PROTECTED_TOOL_FIELDS:
        if field in original:
            result[field] = original[field]
        elif field in result:
            del result[field]
    return result


async def with_timeout(
    coro: Any,
    timeout_ms: int = MIDDLEWARE_TIMEOUT_MS,
    label: str = "",
) -> Any:
    """
    Wrap a coroutine with a timeout.

    Args:
        coro: The coroutine to execute.
        timeout_ms: Timeout in milliseconds.
        label: Human-readable label for error messages.

    Returns:
        The result of the coroutine.

    Raises:
        ToolMiddlewareError: If the coroutine exceeds the timeout.
    """
    try:
        return await asyncio.wait_for(coro, timeout=timeout_ms / 1000.0)
    except asyncio.TimeoutError as e:
        raise ToolMiddlewareError(
            f"Middleware timed out after {timeout_ms}ms: {label}",
            middleware_name=label,
            phase="timeout",
            cause=e,
        ) from e
