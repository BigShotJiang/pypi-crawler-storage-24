"""
Message format conversion utilities.

Converts messages to LangChain and OpenAI chat formats.
Mirrors the TypeScript SDK's formats.ts.
"""

from typing import Any

from qodo.context.message_manager import AIMessage, HumanMessage, Message, ToolMessage


def to_langchain_dict(messages: list[Message]) -> list[dict[str, Any]]:
    """
    Convert messages to LangChain dict format.

    Compatible with Python's messages_from_dict.

    Args:
        messages: List of Message objects.

    Returns:
        List of dicts in LangChain format.
    """
    result: list[dict[str, Any]] = []

    for msg in messages:
        if isinstance(msg, AIMessage):
            data: dict[str, Any] = {
                "content": msg.content,
                "additional_kwargs": msg.additional_kwargs or {},
            }
            if msg.tool_calls:
                data["tool_calls"] = [
                    {
                        "id": tc.get("id", ""),
                        "name": tc.get("name", ""),
                        "args": tc.get("args", {}),
                        "type": tc.get("type", "tool_call"),
                    }
                    for tc in msg.tool_calls
                ]
            else:
                data["tool_calls"] = []
            result.append({"type": "ai", "data": data})

        elif isinstance(msg, ToolMessage):
            result.append(
                {
                    "type": "tool",
                    "data": {
                        "content": msg.content,
                        "tool_call_id": msg.tool_call_id,
                        "additional_kwargs": msg.additional_kwargs or {},
                    },
                }
            )

        elif isinstance(msg, HumanMessage):
            result.append(
                {
                    "type": "human",
                    "data": {
                        "content": msg.content,
                        "additional_kwargs": msg.additional_kwargs or {},
                    },
                }
            )

        else:
            # Default fallback based on role
            if msg.role == "system":
                result.append(
                    {
                        "type": "system",
                        "data": {
                            "content": msg.content,
                            "additional_kwargs": msg.additional_kwargs or {},
                        },
                    }
                )
            elif msg.role == "user":
                result.append(
                    {
                        "type": "human",
                        "data": {
                            "content": msg.content,
                            "additional_kwargs": msg.additional_kwargs or {},
                        },
                    }
                )
            else:
                # Default to AI message
                result.append(
                    {
                        "type": "ai",
                        "data": {
                            "content": str(msg.content or ""),
                            "additional_kwargs": msg.additional_kwargs or {},
                        },
                    }
                )

    return result


def to_openai_chat(messages: list[Message]) -> list[dict[str, Any]]:
    """
    Convert messages to OpenAI chat format.

    Args:
        messages: List of Message objects.

    Returns:
        List of dicts in OpenAI chat format.
    """
    result: list[dict[str, Any]] = []

    for msg in messages:
        chat_msg: dict[str, Any] = {
            "role": msg.role,
            "content": msg.content,
        }

        if isinstance(msg, AIMessage):
            if msg.tool_calls:
                # Augment args with UI info if available
                tool_args_for_ui = msg.additional_kwargs.get("tool_args_for_ui")
                if tool_args_for_ui:
                    chat_msg["tool_calls"] = [
                        {
                            "id": tc.get("id", ""),
                            "type": "function",
                            "function": {
                                "name": tc.get("name", ""),
                                "arguments": {
                                    **tc.get("args", {}),
                                    "argsForUI": tool_args_for_ui,
                                },
                            },
                        }
                        for tc in msg.tool_calls
                    ]
                else:
                    chat_msg["tool_calls"] = [
                        {
                            "id": tc.get("id", ""),
                            "type": "function",
                            "function": {
                                "name": tc.get("name", ""),
                                "arguments": tc.get("args", {}),
                            },
                        }
                        for tc in msg.tool_calls
                    ]
            if msg.additional_kwargs:
                chat_msg["additional_kwargs"] = msg.additional_kwargs

        elif isinstance(msg, ToolMessage):
            if msg.tool_call_id:
                chat_msg["tool_call_id"] = msg.tool_call_id
            # Include status if available
            status = msg.additional_kwargs.get("status")
            if status:
                chat_msg["status"] = status

        result.append(chat_msg)

    return result
