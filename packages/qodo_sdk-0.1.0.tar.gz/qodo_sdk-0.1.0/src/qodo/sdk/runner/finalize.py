"""
Result finalization utilities.

Builds the final result from MessageManager state.
Mirrors the TypeScript SDK's finalize.ts.
"""

import json
from typing import Any

from qodo.context.message_manager import AIMessage, MessageManager, ToolMessage
from qodo.sdk.runner.formats import to_langchain_dict, to_openai_chat


def is_pydantic_model(value: Any) -> bool:
    """Check if value is a Pydantic v2 BaseModel subclass."""
    try:
        from pydantic import BaseModel

        return isinstance(value, type) and issubclass(value, BaseModel)
    except ImportError:
        return False


def validate_structured_output(schema: Any, output: Any) -> Any:
    """
    Validate structured output against a Pydantic model at runtime.

    Returns the validated (possibly coerced) data on success.
    Raises QodoOutputValidationError on failure.
    """
    from qodo.errors import QodoOutputValidationError

    if not is_pydantic_model(schema):
        raise TypeError(f"Expected a Pydantic BaseModel subclass, got {type(schema)}")

    try:
        validated = schema.model_validate(output)
        return validated.model_dump()
    except Exception as e:
        # Convert Pydantic ValidationError to QodoOutputValidationError
        issues: list[dict[str, str]] = []
        if hasattr(e, "errors"):
            for err in e.errors():
                path = ".".join(str(p) for p in err.get("loc", []))
                issues.append({"path": path or "(root)", "message": err.get("msg", str(err))})
        else:
            issues.append({"path": "(root)", "message": str(e)})

        raise QodoOutputValidationError(issues=issues, raw_output=output) from e


def build_final_result(message_manager: MessageManager) -> dict[str, Any]:
    """
    Build the final result from message manager state.

    Extracts structured_output, final_output, and message formats.
    Assumes pending accumulated responses have been flushed by the caller.

    Args:
        message_manager: The MessageManager instance.

    Returns:
        Dict containing:
        - structured_output: Parsed structured output if available
        - final_output: Final text output if available
        - messages_lc: Messages in LangChain format
        - messages_openai: Messages in OpenAI format
        - subagents_used: Whether subagents were used
    """
    last_structured = message_manager.get_last_ai_structured_output()

    # IMPORTANT:
    # The message list includes AIMessages that represent tool calls. Those messages typically have
    # `tool_calls` populated and `content` set to the tool reasoning. They are not user-facing output
    # and must not be surfaced as final_output.
    messages = message_manager.get_messages()

    # Find last plain AI message (not progress, not tool call)
    last_plain_ai: AIMessage | None = None
    for i in range(len(messages) - 1, -1, -1):
        m = messages[i]
        if not isinstance(m, AIMessage):
            continue
        if m.additional_kwargs.get("type") == "progress":
            continue
        if m.tool_calls and len(m.tool_calls) > 0:
            continue
        last_plain_ai = m
        break

    structured_output: Any = None
    final_output: str | None = None

    # Try to extract structured output from dedicated message
    if last_structured and last_structured.content:
        content = last_structured.content
        if isinstance(content, str):
            try:
                structured_output = json.loads(content)
            except json.JSONDecodeError:
                pass  # non-fatal: content may not be valid JSON
        elif isinstance(content, dict):
            structured_output = content

    # If no structured output, try to get final_output from last plain AI
    if not structured_output and last_plain_ai and last_plain_ai.content:
        if isinstance(last_plain_ai.content, str):
            final_output = last_plain_ai.content
        else:
            final_output = json.dumps(last_plain_ai.content)

        # Heuristic: if the assistant's final output is JSON, surface it as structured_output as well.
        # This improves DX for output_schema users even when the backend doesn't emit a dedicated
        # structured_output tool message.
        if final_output:
            trimmed = final_output.strip()
            if (trimmed.startswith("{") and trimmed.endswith("}")) or (
                trimmed.startswith("[") and trimmed.endswith("]")
            ):
                try:
                    parsed = json.loads(trimmed)
                    if parsed and isinstance(parsed, (dict, list)):
                        structured_output = parsed
                except json.JSONDecodeError:
                    pass  # non-fatal: heuristic JSON parse may fail on non-JSON content

    # Fallback: find the last meaningful AI message content (excluding tool-call messages)
    if not structured_output and (not final_output or not final_output.strip()):
        for i in range(len(messages) - 1, -1, -1):
            m = messages[i]
            if isinstance(m, AIMessage):
                if m.additional_kwargs.get("type") == "progress":
                    continue
                if m.tool_calls and len(m.tool_calls) > 0:
                    continue
                if isinstance(m.content, str) and m.content.strip():
                    final_output = m.content
                    break

    # Fallback 2: derive final_output from last ToolMessage content
    if not structured_output and (not final_output or not final_output.strip()):
        for i in range(len(messages) - 1, -1, -1):
            m = messages[i]
            if isinstance(m, ToolMessage):
                content = m.content
                if isinstance(content, str) and content.strip():
                    final_output = content
                    break
                if isinstance(content, list) and content:
                    # Find first text content
                    for item in content:
                        if isinstance(item, dict):
                            text = item.get("text") or ""
                            if text.strip():
                                final_output = text
                                break
                    if final_output:
                        break
                if not final_output and content and isinstance(content, dict):
                    try:
                        final_output = json.dumps(content)
                        break
                    except (TypeError, ValueError):
                        pass  # non-fatal: circular or non-serializable content

    messages_lc = to_langchain_dict(messages)
    messages_openai = to_openai_chat(messages)

    # Check if subagents were used
    subagents_used = any(
        isinstance(m, AIMessage) and m.additional_kwargs.get("server_name") == "subagent"
        for m in messages
    )

    result: dict[str, Any] = {
        "messages_lc": messages_lc,
        "messages_openai": messages_openai,
        "subagents_used": subagents_used,
    }

    if structured_output:
        result["structured_output"] = structured_output
    if final_output:
        result["final_output"] = final_output

    return result
