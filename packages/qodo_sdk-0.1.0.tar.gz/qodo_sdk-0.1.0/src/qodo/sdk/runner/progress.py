"""
Progress extraction utilities.

Extracts progress information from messages.
Mirrors the TypeScript SDK's progress.ts.
"""

import json
from typing import Any

from qodo.context.message_manager import AIMessage, Message


def extract_progress(messages: list[Message]) -> dict[str, Any] | None:
    """
    Extract progress information from the last message.

    Args:
        messages: List of messages to check.

    Returns:
        Progress dict if found, None otherwise.
    """
    if not messages:
        return None

    last = messages[-1]

    if isinstance(last, AIMessage):
        # Check if this is a progress message
        if last.additional_kwargs.get("type") == "progress":
            try:
                content = last.content
                if isinstance(content, str):
                    return json.loads(content)  # type: ignore[no-any-return]
                elif isinstance(content, dict):
                    return content
            except (json.JSONDecodeError, TypeError):
                return None

    return None
