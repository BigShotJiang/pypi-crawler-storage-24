"""
AgentRunnerCore - Orchestrator for SDK operations.

Mirrors the TypeScript SDK's AgentRunnerCore - sets up MessageManager listeners,
delegates to AgentAPI for backend communication, emits v1 protocol events.
"""

from __future__ import annotations

import logging
import os
import uuid
from collections.abc import Callable
from typing import TYPE_CHECKING, Any

from qodo.api.agent import AgentAPI, AgentSession
from qodo.context.message_manager import Message, MessageManager
from qodo.mcp import MCPManager
from qodo.sdk.runner.finalize import build_final_result
from qodo.sdk.runner.formats import to_langchain_dict, to_openai_chat
from qodo.sdk.runner.progress import extract_progress

if TYPE_CHECKING:
    from qodo.session import SessionContext

logger = logging.getLogger(__name__)


# Type alias for emit function
EmitFn = Callable[[str, Any], None]


class AgentRunnerCore:
    """
    Orchestrator for SDK agent operations.

    Mirrors the TypeScript SDK's AgentRunnerCore:
    - Sets up listeners on MessageManager
    - Delegates to AgentAPI for backend communication
    - Emits v1 protocol events based on listener triggers
    - Does NOT handle backend communication directly

    Example:
        def emit(event_type: str, data: Any) -> None:
            print(f"{event_type}: {data}")

        runner = AgentRunnerCore(
            session_context=ctx,
            message_manager=MessageManager.get_instance(),
            agent=AgentAPI(),
            emit=emit,
        )
        await runner.start(prompt="Hello", extra_instructions="")
    """

    def __init__(
        self,
        session_context: SessionContext,
        message_manager: MessageManager,
        agent: AgentAPI,
        emit: EmitFn,
        auto_approve_tools: bool = True,
    ) -> None:
        self._session_context = session_context
        self._message_manager = message_manager
        self._agent = agent
        self._emit = emit
        self._auto_approve_tools = auto_approve_tools
        self._unsubscribers: list[Callable[[], None]] = []
        self._final_emitted = False

        # Set auto-approval based on option
        try:
            MCPManager.get_instance().set_auto_approve_all_tools(self._auto_approve_tools)
        except Exception:
            pass  # MCP may not be initialized when tools are disabled

        # Announce protocol
        self._emit(
            "init",
            {
                "protocol": "qodo.sdk.v1",
                "model": self._session_context.get_model(),
                "pid": os.getpid(),
            },
        )

        # Say hello from SDK mode
        self._emit(
            "hello",
            {
                "message": "Hello from SDK mode!",
                "mode": "sdk",
                "ready": True,
            },
        )

        self._setup_listeners()

    def _setup_listeners(self) -> None:
        """Set up listeners on MessageManager."""

        # Messages listener
        def on_messages(messages: list[Message]) -> None:
            lc = to_langchain_dict(messages)
            openai = to_openai_chat(messages)
            self._emit("messages", {"messages": {"langchain": lc, "openai": openai}})

            progress = extract_progress(messages)
            if progress:
                self._emit("progress", progress)

        unsub_msg = self._message_manager.add_message_listener(on_messages)
        self._unsubscribers.append(unsub_msg)

        # Loading listener
        # IMPORTANT: Wrap in try-except to ensure emit_final is always called even if
        # finish_current_task throws. Without this, exceptions cause the SDK stream
        # to hang indefinitely waiting for the 'final' event.
        def on_loading(is_loading: bool) -> None:
            self._emit("isLoading", is_loading)
            if not is_loading:
                try:
                    # Note: This is sync callback, but we need to call async method
                    # In practice, AgentAPI.finish_current_task should be sync or
                    # we need to handle this differently
                    self._agent.finish_current_task(is_error=False)
                except Exception as e:
                    # Log but don't throw - we must emit final regardless
                    logger.debug(
                        f"[AgentRunnerCore] Error in finish_current_task (loading listener): {e}"
                    )
                self._emit_final()

        unsub_load = self._message_manager.add_loading_listener(on_loading)
        self._unsubscribers.append(unsub_load)

        # Error listener
        # IMPORTANT: Same try-except pattern to prevent hanging on exceptions.
        # Also note: error listener may fire before loading becomes false, so we
        # guard against double emit_final with the _final_emitted flag.
        def on_error(error: str | None) -> None:
            if error:
                self._emit("error", {"message": error})
                try:
                    self._agent.finish_current_task(is_error=True)
                except Exception as e:
                    # Log but don't throw - we must emit final regardless
                    logger.debug(
                        f"[AgentRunnerCore] Error in finish_current_task (error listener): {e}"
                    )
                self._emit_final(error)

        unsub_err = self._message_manager.add_error_listener(on_error)
        self._unsubscribers.append(unsub_err)

    def _flush_pending_user_responses(self) -> None:
        """Flush any pending accumulated responses."""
        if self._message_manager.has_pending_responses():
            pending = self._message_manager.get_all_accumulated_responses()
            for tool_id in pending.keys():
                self._message_manager.finalize_user_response(tool_id)

    def _emit_final(self, err: str | None = None) -> None:
        """Emit the final event."""
        # Guard against double emission - both error and loading listeners may call this
        if self._final_emitted:
            return
        self._final_emitted = True

        try:
            self._flush_pending_user_responses()
            finalized = build_final_result(self._message_manager)

            result: dict[str, Any] = {}
            if finalized.get("structured_output"):
                result["structured_output"] = finalized["structured_output"]
            if finalized.get("final_output"):
                result["final_output"] = finalized["final_output"]

            self._emit(
                "final",
                {
                    "success": not err,
                    "error": err,
                    "session_id": self._session_context.get_session_id(),
                    "model": self._session_context.get_model(),
                    "result": result,
                    "messages": {
                        "langchain": finalized.get("messages_lc", []),
                        "openai": finalized.get("messages_openai", []),
                    },
                    "meta": {
                        "tools_auto_approved": self._auto_approve_tools,
                        "subagents_used": finalized.get("subagents_used", []),
                    },
                },
            )
        except Exception as e:
            self._emit(
                "final",
                {
                    "success": False,
                    "error": str(e),
                },
            )

    async def start(
        self,
        prompt: str,
        extra_instructions: str,
        command_args: dict[str, Any] | None = None,
        output_schema: Any | None = None,
    ) -> None:
        """
        Start a new agent run.

        Args:
            prompt: The user's prompt/query.
            extra_instructions: Additional instructions.
            command_args: Optional command arguments.
            output_schema: Optional output schema for structured output.
        """
        # Reset final emission guard for new run
        self._final_emitted = False
        self._message_manager.set_loading(True)
        self._message_manager.set_error(None)

        # Load --with summaries as an AI message, like CLI
        try:
            prev_summaries = self._session_context.get_previous_sessions_summarization()
            if prev_summaries:
                from qodo.context.message_manager import AIMessage

                heading = f"Using context from {len(prev_summaries)} previous session(s):"
                sections = [
                    f"### Session {s['session_id']}\n{(s.get('summary') or '').strip()}"
                    for s in prev_summaries
                ]
                message = "\n\n---\n\n".join([heading, *sections])
                self._message_manager.add_message(AIMessage(content=message))
        except Exception:
            pass  # best-effort: session summary prefetch is non-critical

        if self._session_context.is_resumed_session():
            await self.resume(self._session_context.get_session_id())
            return

        # Add user message
        from qodo.context.user_input import get_user_input

        user_input = get_user_input(
            prompt or "",
            extra_instructions or "",
            self._session_context.get_command(),
        )
        from qodo.context.message_manager import HumanMessage

        self._message_manager.add_message(HumanMessage(content=user_input))

        # Normalize SDK-provided output schema
        normalized_output_schema: Any | None = None
        if output_schema:
            # If string (JSON schema in string form), parse it
            if isinstance(output_schema, str):
                try:
                    import json

                    normalized_output_schema = json.loads(output_schema)
                except json.JSONDecodeError as e:
                    raise ValueError(f"Invalid output_schema JSON: {e}") from e
            else:
                normalized_output_schema = output_schema

        command_cfg = self._session_context.get_command()
        from qodo.context.build_user_context import build_user_context_from_args

        enriched_context = build_user_context_from_args(command_args, command_cfg)

        agent_session = AgentSession(
            session_id=self._session_context.get_session_id(),
            request_id=str(uuid.uuid4()),
            data={
                "user_request": extra_instructions or prompt,
                "user_context": enriched_context,
                **({"output_schema": normalized_output_schema} if normalized_output_schema else {}),
                "ci_mode": True,  # non-interactive behavior
            },
            user_engagement_callback=self._message_manager.create_user_engagement_callback(
                stream=True
            ),
            command=command_cfg,
        )

        await self._agent.start_task(agent_session)

    async def resume(self, session_id: str) -> None:
        """
        Resume an existing session.

        Args:
            session_id: The session ID to resume.
        """
        agent_session = AgentSession(
            session_id=session_id,
            request_id=str(uuid.uuid4()),
            data={
                "ci_mode": True,  # ensure SDK runner stays non-interactive on resume
            },
            user_engagement_callback=self._message_manager.create_user_engagement_callback(
                stream=True
            ),
            command=self._session_context.get_command(),
        )
        await self._agent.resume_task(agent_session)

    def cancel(self) -> None:
        """Cancel the current session."""
        self._agent.cancel_current_session()

    async def dispose(self) -> None:
        """Clean up resources."""
        # Remove listeners
        for unsub in self._unsubscribers:
            try:
                unsub()
            except Exception:
                pass  # cleanup: listener removal must not throw
        self._unsubscribers.clear()

        try:
            self._agent.remove_all_listeners()
        except Exception:
            pass  # cleanup: agent teardown must not throw
