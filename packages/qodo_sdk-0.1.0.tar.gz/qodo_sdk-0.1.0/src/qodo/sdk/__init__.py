"""SDK core components."""

from qodo.sdk.builders import (
    sdk_agent,
    sdk_args,
    sdk_command,
)
from qodo.sdk.events import (
    SDK_PROTOCOL_V2,
    EventEmitter,
    QodoSdkEvent,
    SdkErrorData,
    SdkEventEnvelope,
    SdkEventType,
    SdkFinalData,
    SdkInitData,
    SdkMessageDeltaData,
    SdkMessageFullData,
    SdkProgressData,
    SdkRunStartedData,
    SdkToolApprovedData,
    SdkToolExecutedData,
    SdkToolRequestedData,
    create_sdk_event,
    get_sdk_version,
    match_sdk_event,
)
from qodo.sdk.qodo_sdk import (
    QodoSDK,
    QodoSDKOptions,
    QodoSDKRunResult,
    ToolApprovalRequest,
)
from qodo.sdk.schemas import (
    CoercibleTypes,
    parse_args_with_schema,
    pydantic_output_schema,
    zcoerce,
)

__all__ = [
    # Main SDK
    "QodoSDK",
    "QodoSDKOptions",
    "QodoSDKRunResult",
    "ToolApprovalRequest",
    "get_sdk_version",
    # Builders
    "sdk_agent",
    "sdk_command",
    "sdk_args",
    # Schemas
    "pydantic_output_schema",
    "parse_args_with_schema",
    "CoercibleTypes",
    "zcoerce",
    # Protocol
    "SDK_PROTOCOL_V2",
    # Event types
    "SdkEventType",
    "QodoSdkEvent",
    "SdkEventEnvelope",
    # Event data classes
    "SdkInitData",
    "SdkRunStartedData",
    "SdkMessageDeltaData",
    "SdkMessageFullData",
    "SdkProgressData",
    "SdkToolRequestedData",
    "SdkToolApprovedData",
    "SdkToolExecutedData",
    "SdkErrorData",
    "SdkFinalData",
    # Helpers
    "create_sdk_event",
    "match_sdk_event",
    "EventEmitter",
]
