"""Artifact store for typed intermediate pipeline results."""

from __future__ import annotations

import inspect
import json
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Generic, Protocol, TypeVar

from qodo.sdk.pipeline.types import StepContext, StepFn

T = TypeVar("T")


class ArtifactSerializer(Protocol):
    """Protocol for artifact serialization."""

    def serialize(self, data: Any) -> str: ...

    def deserialize(self, raw: str) -> Any: ...

    @property
    def content_type(self) -> str: ...


class JsonSerializer:
    """Default JSON serializer with 2-space indent."""

    def serialize(self, data: Any) -> str:
        return json.dumps(data, indent=2)

    def deserialize(self, raw: str) -> Any:
        return json.loads(raw)

    @property
    def content_type(self) -> str:
        return "application/json"


json_serializer = JsonSerializer()


@dataclass
class Artifact(Generic[T]):
    """A stored artifact from a pipeline step."""

    step_name: str
    data: T
    serialized: str
    content_type: str
    created_at: str  # ISO 8601 timestamp


# Persist hook can be sync or async
PersistHook = Callable[[Artifact[Any]], None | Awaitable[None]]


@dataclass
class ArtifactStoreOptions:
    """Options for ArtifactStore."""

    serializer: ArtifactSerializer | None = None
    on_persist: PersistHook | None = None


class ArtifactStore:
    """Store for typed intermediate pipeline results."""

    def __init__(self, options: ArtifactStoreOptions | None = None) -> None:
        opts = options or ArtifactStoreOptions()
        self._serializer: ArtifactSerializer = opts.serializer or json_serializer
        self._on_persist = opts.on_persist
        self._artifacts: dict[str, Artifact[Any]] = {}
        self._errors: list[dict[str, Any]] = []

    async def set(self, step_name: str, data: Any) -> Artifact[Any]:
        """Store an artifact. Calls on_persist hook if configured."""
        serialized = self._serializer.serialize(data)
        artifact: Artifact[Any] = Artifact(
            step_name=step_name,
            data=data,
            serialized=serialized,
            content_type=self._serializer.content_type,
            created_at=datetime.now(timezone.utc).isoformat(),
        )
        self._artifacts[step_name] = artifact

        if self._on_persist:
            try:
                result = self._on_persist(artifact)
                if inspect.isawaitable(result):
                    await result
            except Exception as exc:
                self._errors.append(
                    {
                        "step_name": step_name,
                        "error": exc if isinstance(exc, Exception) else Exception(str(exc)),
                    }
                )

        return artifact

    def get_errors(self) -> list[dict[str, Any]]:
        """Get persistence errors that occurred during set() calls."""
        return list(self._errors)

    def get(self, step_name: str) -> Artifact[Any] | None:
        """Retrieve an artifact by step name."""
        return self._artifacts.get(step_name)

    def has(self, step_name: str) -> bool:
        """Check if an artifact exists for the given step name."""
        return step_name in self._artifacts

    def all(self) -> list[Artifact[Any]]:
        """Return all artifacts in insertion order."""
        return list(self._artifacts.values())

    def step_names(self) -> list[str]:
        """Return all step names in insertion order."""
        return list(self._artifacts.keys())

    def delete(self, step_name: str) -> bool:
        """Remove an artifact. Returns True if it existed."""
        if step_name in self._artifacts:
            del self._artifacts[step_name]
            return True
        return False

    def clear(self) -> None:
        """Remove all artifacts."""
        self._artifacts.clear()

    @property
    def size(self) -> int:
        """Return the number of stored artifacts."""
        return len(self._artifacts)

    def deserialize(self, raw: str) -> Any:
        """Deserialize a raw string using the configured serializer."""
        return self._serializer.deserialize(raw)


def with_artifacts(store: ArtifactStore, step_fn: StepFn) -> StepFn:
    """Wrap a step function to automatically store its output as an artifact."""

    async def wrapped(ctx: StepContext) -> dict[str, Any]:
        result = await step_fn(ctx)
        await store.set(ctx.step_name, result)
        return result

    return wrapped
