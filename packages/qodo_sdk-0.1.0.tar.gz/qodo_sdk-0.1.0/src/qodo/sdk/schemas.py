"""
Schema utilities for Pydantic-based validation.

Provides helpers for converting Pydantic models to Qodo output schemas
and validating command arguments.
"""

from __future__ import annotations

import json
from typing import Any, TypeVar, Union, get_args, get_origin

from pydantic import BaseModel, ValidationError

from qodo.errors import QodoSchemaError

T = TypeVar("T", bound=BaseModel)

# Type aliases for JSON values
JsonValue = str | int | float | bool | None
"""Type alias for JSON primitive values (string, number, boolean, null)."""

JsonAny = str | int | float | bool | None | list[Any] | dict[str, Any]
"""Type alias for any JSON value including arrays and objects."""


def json_value_schema(description: str) -> dict[str, Any]:
    """
    Create a JSON schema for flexible primitive JSON values.

    Use this when you need to accept any JSON primitive (string, number, boolean, null)
    but want to avoid using typing.Any which produces invalid schemas.

    The schema can be used in Pydantic Field's json_schema_extra parameter.

    Args:
        description: Description of what this field represents.

    Returns:
        A dict suitable for use with Field(json_schema_extra=...).

    Example:
        class Output(BaseModel):
            value: Any = Field(
                description="Flexible value",
                json_schema_extra=json_value_schema("A flexible primitive value")
            )

        # Or use directly with anyOf pattern:
        class Output(BaseModel):
            value: str | int | float | bool | None = Field(
                description="Flexible value"
            )
    """
    return {
        "description": description,
        "anyOf": [
            {"type": "string"},
            {"type": "number"},
            {"type": "boolean"},
            {"type": "null"},
        ],
    }


def json_any_schema(description: str) -> dict[str, Any]:
    """
    Create a JSON schema for any JSON value including arrays and objects.

    Use this instead of typing.Any when you need maximum flexibility in output schemas.
    The generated schema is compatible with OpenAI's structured output requirements.

    For deeply nested structures, consider using more specific types for better
    type safety and clearer LLM guidance.

    Args:
        description: Description of what this field represents.

    Returns:
        A dict suitable for use with Field(json_schema_extra=...).

    Example:
        class Output(BaseModel):
            data: Any = Field(
                description="Flexible data",
                json_schema_extra=json_any_schema("Arbitrary JSON data")
            )
    """
    # Primitives that can appear in arrays/objects
    primitives = [
        {"type": "string"},
        {"type": "number"},
        {"type": "boolean"},
        {"type": "null"},
    ]

    return {
        "description": description,
        "anyOf": [
            {"type": "string"},
            {"type": "number"},
            {"type": "boolean"},
            {"type": "null"},
            {
                "type": "array",
                "items": {"anyOf": primitives},
            },
            {
                "type": "object",
                "additionalProperties": {"anyOf": primitives},
            },
        ],
    }


def pydantic_output_schema(
    name: str,
    model: type[BaseModel],
    strict: bool = True,
) -> dict[str, Any]:
    """
    Convert a Pydantic model to the Qodo OutputSchema format.

    Enforces the same rules as the TypeScript SDK:
    - All properties must have descriptions
    - No typing.Any usage (produces invalid JSON schemas)

    Args:
        name: Schema name for the output.
        model: Pydantic model class.
        strict: Whether to enable strict JSON schema mode.

    Returns:
        OutputSchema dictionary ready for use with the SDK.

    Raises:
        QodoSchemaError: If any properties are missing descriptions or use Any.

    Example:
        from pydantic import BaseModel, Field

        class ReviewOutput(BaseModel):
            issues: list[str] = Field(description="Found issues")
            score: float = Field(description="Quality score 0-10")

        schema = pydantic_output_schema("review_output", ReviewOutput)
    """
    # Detect Any type usage before conversion
    any_paths = _detect_any_type(model)
    if any_paths:
        raise QodoSchemaError(
            f"Output schema contains typing.Any at: {', '.join(any_paths)}. "
            "Any types produce incomplete JSON schemas that OpenAI rejects. "
            "Use specific types like str, int, dict[str, str], list[str], or for "
            "flexible typing use json_value_schema() (primitives) or json_any_schema() "
            "(primitives + arrays/objects) with Field(json_schema_extra=...)."
        )

    schema = model.model_json_schema()

    # Validate descriptions are present
    missing = _collect_missing_descriptions(schema)
    if missing:
        raise QodoSchemaError(
            f"Output schema is missing description for: {', '.join(missing)}. "
            "Every output property must have a description using Field(description=...)."
        )

    return {
        "type": "json_schema",
        "json_schema": {
            "name": name,
            "strict": strict,
            "schema": schema,
        },
    }


def parse_args_with_schema(schema: type[T], args: Any) -> T:
    """
    Validate and coerce args using a Pydantic model.

    Args:
        schema: Pydantic model class for validation.
        args: Arguments to validate (dict or object).

    Returns:
        Validated instance of the schema model.

    Raises:
        QodoSchemaError: If validation fails, with actionable message.

    Example:
        class ReviewArgs(BaseModel):
            files: list[str]
            depth: int = 1

        validated = parse_args_with_schema(ReviewArgs, {"files": ["main.py"]})
        print(validated.files)  # ["main.py"]
        print(validated.depth)  # 1
    """
    try:
        if isinstance(args, dict):
            return schema.model_validate(args)
        elif args is None:
            return schema.model_validate({})
        else:
            return schema.model_validate(args)
    except ValidationError as e:
        messages = [f"{'.'.join(str(x) for x in err['loc'])}: {err['msg']}" for err in e.errors()]
        raise QodoSchemaError(f"Invalid command args: {'; '.join(messages)}") from e


def _detect_any_type(
    model: type[BaseModel],
    path: str = "",
) -> list[str]:
    """
    Detect typing.Any usage in a Pydantic model's fields.

    Recursively checks all fields for Any types, untyped fields,
    and generic containers without type parameters.

    Args:
        model: Pydantic model class to check.
        path: Current path for nested models (used in recursion).

    Returns:
        List of paths where Any or equivalent is used.
    """
    found: list[str] = []

    for field_name, field_info in model.model_fields.items():
        full_path = f"{path}.{field_name}" if path else field_name
        annotation = field_info.annotation

        # Check for typing.Any
        if annotation is Any:
            found.append(full_path)
            continue

        # Check for unparameterized list/dict (bare `list` or `dict` without type params)
        if annotation is list:
            found.append(f"{full_path} (unparameterized list)")
            continue
        if annotation is dict:
            found.append(f"{full_path} (unparameterized dict)")
            continue

        # Get origin for generic types (list, dict, etc.)
        origin = get_origin(annotation)
        args = get_args(annotation)

        if origin is not None:
            # Check Union types (including Optional which is Union[T, None])
            if origin is Union:
                for arg in args:
                    if arg is Any:
                        found.append(full_path)
                        break
                    # Check if arg is a BaseModel subclass
                    if isinstance(arg, type) and issubclass(arg, BaseModel):
                        found.extend(_detect_any_type(arg, full_path))

            # Check list/List - must have type parameter
            elif origin is list:
                if not args:
                    found.append(f"{full_path} (unparameterized list)")
                else:
                    for arg in args:
                        if arg is Any:
                            found.append(full_path)
                        elif isinstance(arg, type) and issubclass(arg, BaseModel):
                            found.extend(_detect_any_type(arg, f"{full_path}[]"))

            # Check dict/Dict - must have type parameters
            elif origin is dict:
                if not args or len(args) < 2:
                    found.append(f"{full_path} (unparameterized dict)")
                else:
                    for arg in args:
                        if arg is Any:
                            found.append(full_path)
                        elif isinstance(arg, type) and issubclass(arg, BaseModel):
                            found.extend(_detect_any_type(arg, f"{full_path}[value]"))

        # Check for nested Pydantic models
        elif isinstance(annotation, type) and issubclass(annotation, BaseModel):
            found.extend(_detect_any_type(annotation, full_path))

    return found


def _collect_missing_descriptions(
    schema: dict[str, Any],
    path: str = "",
) -> list[str]:
    """
    Find properties missing descriptions in a JSON schema.

    Recursively checks nested objects and arrays.
    """
    missing: list[str] = []
    props = schema.get("properties", {})

    for name, prop_def in props.items():
        full_path = f"{path}.{name}" if path else name

        # Check for description
        if not prop_def.get("description"):
            missing.append(full_path)

        # Recursively check nested objects
        if prop_def.get("type") == "object" and "properties" in prop_def:
            missing.extend(_collect_missing_descriptions(prop_def, full_path))

        # Check array items
        if prop_def.get("type") == "array" and "items" in prop_def:
            items = prop_def["items"]
            if isinstance(items, dict) and items.get("type") == "object":
                missing.extend(_collect_missing_descriptions(items, f"{full_path}[]"))

    # Check $defs for referenced schemas
    defs = schema.get("$defs", {})
    for def_name, def_schema in defs.items():
        if def_schema.get("type") == "object" and "properties" in def_schema:
            # Only report missing if referenced
            missing.extend(_collect_missing_descriptions(def_schema, f"${def_name}"))

    return missing


class CoercibleTypes:
    """
    CLI-style type coercion helpers.

    Provides validators that accept both native types and string representations,
    useful for command-line style argument parsing.
    """

    @staticmethod
    def boolean(value: Any) -> bool:
        """
        Coerce a value to boolean.

        Accepts:
        - True/False
        - "true"/"false" (case-insensitive)
        - 1/0
        - "1"/"0"
        """
        if isinstance(value, bool):
            return value
        if isinstance(value, str):
            lower = value.lower()
            if lower in ("true", "1", "yes"):
                return True
            if lower in ("false", "0", "no"):
                return False
            raise ValueError(f"Cannot coerce '{value}' to boolean")
        if isinstance(value, (int, float)):
            return bool(value)
        raise ValueError(f"Cannot coerce {type(value).__name__} to boolean")

    @staticmethod
    def number(value: Any) -> float:
        """
        Coerce a value to number.

        Accepts:
        - int/float
        - numeric string
        """
        if isinstance(value, (int, float)):
            return float(value)
        if isinstance(value, str):
            try:
                return float(value)
            except ValueError as e:
                raise ValueError(f"Cannot coerce '{value}' to number") from e
        raise ValueError(f"Cannot coerce {type(value).__name__} to number")

    @staticmethod
    def integer(value: Any) -> int:
        """
        Coerce a value to integer.

        Accepts:
        - int
        - integer string
        - float (truncated)
        """
        if isinstance(value, int) and not isinstance(value, bool):
            return value
        if isinstance(value, float):
            return int(value)
        if isinstance(value, str):
            try:
                return int(value)
            except ValueError:
                try:
                    return int(float(value))
                except ValueError as e:
                    raise ValueError(f"Cannot coerce '{value}' to integer") from e
        raise ValueError(f"Cannot coerce {type(value).__name__} to integer")

    @staticmethod
    def json_array(value: Any) -> list[Any]:
        """
        Coerce a value to list.

        Accepts:
        - list (returned as-is)
        - JSON string that parses to a list

        Args:
            value: The value to coerce.

        Returns:
            A list.

        Raises:
            ValueError: If the value cannot be coerced to a list.
        """
        if isinstance(value, list):
            return value
        if isinstance(value, str):
            try:
                parsed = json.loads(value)
                if isinstance(parsed, list):
                    return parsed
            except json.JSONDecodeError:
                pass
        raise ValueError(f"Cannot coerce {type(value).__name__} to list")

    @staticmethod
    def json_object(value: Any) -> dict[str, Any]:
        """
        Coerce a value to dict.

        Accepts:
        - dict (returned as-is)
        - JSON string that parses to an object

        Args:
            value: The value to coerce.

        Returns:
            A dict.

        Raises:
            ValueError: If the value cannot be coerced to a dict.
        """
        if isinstance(value, dict):
            return value
        if isinstance(value, str):
            try:
                parsed = json.loads(value)
                if isinstance(parsed, dict):
                    return parsed
            except json.JSONDecodeError:
                pass
        raise ValueError(f"Cannot coerce {type(value).__name__} to dict")


# Convenience alias
zcoerce = CoercibleTypes
