"""
SDK builders for creating agents and commands programmatically.

Provides Pydantic-first builders that mirror the TypeScript SDK's
sdkAgent(), sdkCommand(), and sdkArgs() functions.
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, create_model

from qodo.errors import QodoSchemaError
from qodo.parser.types import (
    AIAssistantConfig,
    CommandArgument,
    CommandConfig,
    OutputSchema,
)
from qodo.sdk.schemas import pydantic_output_schema


def sdk_command(
    name: str,
    *,
    description: str | None = None,
    instructions: str | None = None,
    available_tools: list[str] | None = None,
    ignore_tools: list[str] | None = None,
    permissions: str = "rwx",
    args: type[BaseModel] | None = None,
    output: type[BaseModel] | None = None,
    output_name: str | None = None,
    output_strict: bool = True,
    output_json_schema: dict[str, Any] | None = None,
    model: str | None = None,
    max_iterations: int | None = None,
    execution_strategy: Literal["plan", "act"] | None = None,
) -> CommandConfig:
    """
    SDK v2 command builder (Pydantic-first).

    Creates a CommandConfig from Pydantic models for type-safe
    argument validation and structured output.

    Args:
        name: Command name (required).
        description: Human-readable description.
        instructions: Instructions for the agent when running this command.
        available_tools: List of tools to enable (e.g., ["filesystem", "git"]).
        ignore_tools: List of tools to disable.
        permissions: File system permissions ('r', 'rw', 'rwx', '-').
        args: Pydantic model for argument validation.
        output: Pydantic model for structured output schema.
        output_name: Name for the output schema (defaults to {name}_output).
        output_strict: Enable strict JSON schema mode.
        output_json_schema: Raw JSON schema (mutually exclusive with output).
        model: Model override for this command.
        max_iterations: Maximum agent iterations.
        execution_strategy: 'plan' or 'act' mode.

    Returns:
        CommandConfig ready for use with sdk_agent() or QodoSDK.

    Raises:
        QodoSchemaError: If both output and output_json_schema are provided,
                        or if output schema is missing descriptions.

    Example:
        from pydantic import BaseModel, Field

        class ReviewArgs(BaseModel):
            files: list[str] = Field(description="Files to review")
            depth: int = Field(default=1, description="Review depth")

        class ReviewOutput(BaseModel):
            issues: list[str] = Field(description="Found issues")
            score: float = Field(description="Overall score 0-10")

        cmd = sdk_command(
            name="review",
            description="Review code files",
            args=ReviewArgs,
            output=ReviewOutput,
            available_tools=["filesystem", "git"],
        )
    """
    if output and output_json_schema:
        raise QodoSchemaError(
            "Provide either `output` (Pydantic model) or `output_json_schema`, not both."
        )

    # Build the command config
    cmd = CommandConfig(
        name=name,
        description=description,
        instructions=instructions,
        available_tools=available_tools,
        ignore_tools=ignore_tools,
        permissions=permissions,
        model=model,
        max_iterations=max_iterations,
        execution_strategy=execution_strategy,
    )

    # Store SDK metadata for runtime use
    cmd._sdk_meta = {}

    # Process args schema
    if args:
        cmd._sdk_meta["args_schema"] = args
        cmd.arguments = _derive_arguments_from_pydantic(args)

    # Process output schema
    if output:
        out_name = output_name or f"{name}_output"
        schema_dict = pydantic_output_schema(out_name, output, output_strict)
        cmd.output_schema = OutputSchema(**schema_dict)
        cmd._sdk_meta["output_schema"] = output
    elif output_json_schema:
        cmd.output_schema = output_json_schema

    return cmd


def sdk_agent(
    commands: dict[str, CommandConfig],
    *,
    instructions: str | None = None,
    system_prompt: str | None = None,
    model: str | None = None,
    available_tools: list[str] | None = None,
    ignore_tools: list[str] | None = None,
    execution_strategy: Literal["plan", "act"] | None = None,
    max_iterations: int | None = None,
) -> AIAssistantConfig:
    """
    SDK v2 agent builder.

    Creates an AIAssistantConfig from command definitions.

    Args:
        commands: Dictionary of command name to CommandConfig.
        instructions: Global instructions for the agent.
        system_prompt: System prompt (typically internal use).
        model: Default model for the agent.
        available_tools: Default tools available to all commands.
        ignore_tools: Tools to disable for all commands.
        execution_strategy: Default execution strategy.
        max_iterations: Default max iterations.

    Returns:
        AIAssistantConfig ready for use with QodoSDK.from_agent().

    Example:
        agent = sdk_agent(
            commands={
                "review": sdk_command(name="review", ...),
                "fix": sdk_command(name="fix", ...),
            },
            model="gpt-4",
            instructions="You are a helpful code reviewer.",
            available_tools=["filesystem", "git"],
        )

        sdk = QodoSDK.from_agent(agent, project_path="/path/to/project")
    """
    return AIAssistantConfig(
        version="1.0",
        _system_prompt=system_prompt,
        instructions=instructions,
        model=model,
        available_tools=available_tools or [],
        ignore_tools=ignore_tools or [],
        commands=commands,
        modes={},
        mcp_servers={},
        execution_strategy=execution_strategy,
        max_iterations=max_iterations,
    )


def sdk_args(**fields: Any) -> type[BaseModel]:
    """
    Convenience helper for creating a Pydantic args schema.

    Creates a Pydantic model dynamically from field definitions.

    Args:
        **fields: Field definitions. Each can be:
            - A type: str, int, list[str], etc. (required field)
            - A tuple of (type, Field(...)): for optional/default/described fields

    Returns:
        A Pydantic BaseModel subclass.

    Example:
        # Simple required fields
        Args1 = sdk_args(
            files=list[str],
            verbose=bool,
        )

        # With defaults and descriptions
        from pydantic import Field

        Args2 = sdk_args(
            files=(list[str], Field(description="Files to process")),
            depth=(int, Field(default=1, description="Processing depth")),
            verbose=(bool, Field(default=False)),
        )

        # Use with sdk_command
        cmd = sdk_command(name="process", args=Args2, ...)
    """
    field_definitions: dict[str, Any] = {}

    for name, field_type in fields.items():
        if isinstance(field_type, tuple):
            # (type, Field(...)) format
            field_definitions[name] = field_type
        else:
            # Just a type - make it required
            field_definitions[name] = (field_type, ...)

    return create_model("Args", **field_definitions)


def _derive_arguments_from_pydantic(model: type[BaseModel]) -> list[CommandArgument]:
    """
    Derive CommandArgument list from a Pydantic model.

    Extracts field information from the Pydantic model's JSON schema
    and converts it to CommandArgument format.
    """
    schema = model.model_json_schema()
    props = schema.get("properties", {})
    required = set(schema.get("required", []))

    arguments: list[CommandArgument] = []

    for prop_name, prop_def in props.items():
        # Map JSON schema type to CommandArgument type
        json_type = prop_def.get("type", "string")
        arg_type = _map_json_schema_type(json_type)

        arguments.append(
            CommandArgument(
                name=prop_name,
                type=arg_type,
                required=prop_name in required,
                description=prop_def.get("description", ""),
                default=prop_def.get("default"),
            )
        )

    return arguments


def _map_json_schema_type(
    json_type: Any,
) -> Literal["string", "number", "boolean", "array", "object"]:
    """Map JSON schema type to CommandArgument type."""
    # Handle union types (e.g., ["string", "null"])
    if isinstance(json_type, list):
        # Find the non-null type
        for t in json_type:
            if t != "null":
                json_type = t
                break
        else:
            json_type = "string"

    mapping: dict[str, Literal["string", "number", "boolean", "array", "object"]] = {
        "string": "string",
        "number": "number",
        "integer": "number",
        "boolean": "boolean",
        "array": "array",
        "object": "object",
    }

    return mapping.get(str(json_type), "string")
