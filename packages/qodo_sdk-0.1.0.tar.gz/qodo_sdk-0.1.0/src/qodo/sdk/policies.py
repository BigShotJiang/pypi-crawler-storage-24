"""Tool approval policy DSL for the Qodo SDK."""

from __future__ import annotations

import re
from collections.abc import Sequence
from dataclasses import dataclass
from typing import Any, Literal

PolicyDecision = Literal["approve", "deny", "require_human"]


def glob_to_regex(pattern: str) -> str:
    """Convert a glob pattern to a regex string.

    * matches any characters (including /), ** is an alias for *.
    ? matches exactly one character. Special regex chars are escaped.
    """
    if not pattern:
        return r"(?!)"  # matches nothing

    result: list[str] = []
    i = 0
    while i < len(pattern):
        ch = pattern[i]
        if ch == "*":
            # consume consecutive *
            while i < len(pattern) and pattern[i] == "*":
                i += 1
            # Skip trailing / after ** (for src/**/file patterns)
            if i > 1 and i < len(pattern) and pattern[i] == "/":
                i += 1
            result.append(".*")
        elif ch == "?":
            result.append(".")
            i += 1
        elif ch in r".+^$|()[]{}":
            result.append("\\" + ch)
            i += 1
        else:
            result.append(re.escape(ch) if ch in r"\\" else ch)
            i += 1

    return "".join(result)


def glob_match(pattern: str, text: str) -> bool:
    """Test whether *text* matches the glob *pattern* (case-insensitive)."""
    if not pattern:
        return False
    regex = glob_to_regex(pattern)
    return re.fullmatch(regex, text, re.IGNORECASE) is not None


@dataclass
class PolicyMatcher:
    tools: list[str] | None = None
    servers: list[str] | None = None
    args: dict[str, str] | None = None


@dataclass
class PolicyRule:
    match: PolicyMatcher
    decision: PolicyDecision
    name: str | None = None


@dataclass
class PolicyEvalResult:
    decision: PolicyDecision
    matched_rule: PolicyRule | None = None
    is_default: bool = True


@dataclass
class PolicyOptions:
    """Options for Policy construction."""

    default_decision: PolicyDecision = "approve"


def _matches_patterns(patterns: list[str], value: str) -> bool:
    """Return True if *value* matches any of the glob *patterns*."""
    return any(glob_match(p, value) for p in patterns)


def _matcher_matches(
    matcher: PolicyMatcher,
    tool_name: str,
    server_name: str,
    tool_args: dict[str, Any] | None,
) -> bool:
    """Return True when ALL non-None fields in *matcher* match the request."""
    has_any_field = False

    if matcher.tools is not None:
        if not matcher.tools:
            return False  # empty list never matches
        has_any_field = True
        if not _matches_patterns(matcher.tools, tool_name):
            return False

    if matcher.servers is not None:
        if not matcher.servers:
            return False
        has_any_field = True
        if not _matches_patterns(matcher.servers, server_name):
            return False

    if matcher.args is not None:
        if not matcher.args:
            return False  # empty dict never matches
        has_any_field = True
        request_args = tool_args or {}
        for key, pattern in matcher.args.items():
            if key not in request_args:
                return False
            val = str(request_args[key])
            if not glob_match(pattern, val):
                return False

    if not has_any_field:
        return False  # all-None matcher never matches

    return True


class Policy:
    """Immutable set of ordered rules evaluated first-match-wins."""

    def __init__(
        self,
        rules: Sequence[PolicyRule],
        options: PolicyOptions | None = None,
    ) -> None:
        self._rules = tuple(rules)
        self._default_decision = options.default_decision if options else "approve"

    @property
    def rules(self) -> tuple[PolicyRule, ...]:
        return self._rules

    @property
    def default_decision(self) -> PolicyDecision:
        return self._default_decision

    def evaluate_detailed(
        self,
        req: dict[str, Any],
    ) -> PolicyEvalResult:
        """Evaluate tool request against rules. First matching rule wins."""
        tool_name = req.get("tool_name", "")
        server_name = req.get("server_name", "")
        tool_args = req.get("tool_args")
        for rule in self._rules:
            if _matcher_matches(rule.match, tool_name, server_name, tool_args):
                return PolicyEvalResult(
                    decision=rule.decision,
                    matched_rule=rule,
                    is_default=False,
                )
        return PolicyEvalResult(decision=self._default_decision, is_default=True)

    async def evaluate(
        self,
        req: dict[str, Any],
    ) -> dict[str, Any]:
        """Evaluate and return simplified result compatible with toolApproval callback."""
        result = self.evaluate_detailed(req)

        if result.decision == "approve":
            return {"approved": True}
        elif result.decision == "deny":
            reason = (
                f"Denied by policy rule: {result.matched_rule.name}"
                if result.matched_rule and result.matched_rule.name
                else "Denied by policy"
            )
            return {"approved": False, "reason": reason}
        else:  # require_human
            reason = (
                f"Requires human approval: {result.matched_rule.name}"
                if result.matched_rule and result.matched_rule.name
                else "Requires human approval"
            )
            return {"approved": False, "reason": reason}


def _to_matcher(match: PolicyMatcher | dict[str, Any]) -> PolicyMatcher:
    if isinstance(match, PolicyMatcher):
        return match
    return PolicyMatcher(**match)


class PolicyBuilder:
    """Fluent builder for constructing a Policy."""

    def __init__(self) -> None:
        self._rules: list[PolicyRule] = []
        self._default: PolicyDecision = "approve"

    def approve(
        self,
        match: PolicyMatcher | dict[str, Any],
        *,
        name: str | None = None,
    ) -> PolicyBuilder:
        """Add an approve rule."""
        self._rules.append(PolicyRule(match=_to_matcher(match), decision="approve", name=name))
        return self

    def deny(
        self,
        match: PolicyMatcher | dict[str, Any],
        *,
        name: str | None = None,
    ) -> PolicyBuilder:
        """Add a deny rule."""
        self._rules.append(PolicyRule(match=_to_matcher(match), decision="deny", name=name))
        return self

    def require_human(
        self,
        match: PolicyMatcher | dict[str, Any],
        *,
        name: str | None = None,
    ) -> PolicyBuilder:
        """Add a require_human rule."""
        self._rules.append(
            PolicyRule(match=_to_matcher(match), decision="require_human", name=name)
        )
        return self

    def rule(self, rule: PolicyRule) -> PolicyBuilder:
        """Add a raw rule."""
        self._rules.append(rule)
        return self

    def default(self, decision: PolicyDecision) -> PolicyBuilder:
        """Set default decision when no rules match."""
        self._default = decision
        return self

    def build(self) -> Policy:
        """Build the policy. Rules are frozen after this."""
        return Policy(self._rules, PolicyOptions(default_decision=self._default))


def sdk_policy() -> PolicyBuilder:
    """Create a new PolicyBuilder."""
    return PolicyBuilder()


def policy_from_rules(
    rules: Sequence[PolicyRule],
    *,
    default: PolicyDecision = "approve",
) -> Policy:
    """Create a Policy directly from a list of rules."""
    return Policy(rules, PolicyOptions(default_decision=default))
