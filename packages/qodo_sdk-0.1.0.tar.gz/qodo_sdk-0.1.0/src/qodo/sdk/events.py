"""
SDK Event types and helpers.

Defines the qodo.sdk.v2 protocol for streaming events between the SDK
and consuming applications. These event types must match the TypeScript
SDK for backend compatibility.
"""

from __future__ import annotations

import time
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, TypeVar

from qodo._version import __version__


def get_sdk_version() -> str:
    """Get the current SDK version."""
    return __version__


# Protocol version constant
SDK_PROTOCOL_V2 = "qodo.sdk.v2"


class SdkEventType(str, Enum):
    """
    SDK event type constants.

    These match the TypeScript SDK's event types for protocol compatibility.
    """

    INIT = "sdk.init"
    RUN_STARTED = "sdk.run.started"
    MESSAGE_DELTA = "sdk.message.delta"
    MESSAGE_FULL = "sdk.message.full"
    PROGRESS = "sdk.progress"
    TOOL_REQUESTED = "sdk.tool.requested"
    TOOL_APPROVED = "sdk.tool.approved"
    TOOL_EXECUTED = "sdk.tool.executed"
    ERROR = "sdk.error"
    FINAL = "sdk.final"


@dataclass
class SdkInitData:
    """Data for sdk.init event - initialization metadata."""

    sdk_version: str
    protocol: str = SDK_PROTOCOL_V2
    pid: int | None = None
    backend: dict[str, str] | None = None
    model: str | None = None


@dataclass
class SdkRunStartedData:
    """Data for sdk.run.started event - run start details."""

    session_id: str
    command: str
    prompt_mode: bool
    cwd: str
    agent: dict[str, Any]
    tools_auto_approved: bool
    dry_run: bool | None = None


@dataclass
class SdkMessageDeltaData:
    """Data for sdk.message.delta event - incremental text chunk."""

    message_id: str
    role: str = "assistant"
    delta: str = ""


@dataclass
class SdkMessageFullData:
    """Data for sdk.message.full event - complete message snapshot."""

    messages: dict[str, list[Any]] = field(default_factory=dict)


@dataclass
class SdkProgressData:
    """Data for sdk.progress event - progress update."""

    title: str | None = None
    status: str | None = None
    percent: float | None = None
    raw: Any | None = None


@dataclass
class SdkToolRequestedData:
    """Data for sdk.tool.requested event - tool invocation request."""

    tool_call_id: str
    server_name: str
    tool_name: str
    tool_args: Any
    pending_approval: bool
    reasoning: str | None = None


@dataclass
class SdkToolApprovedData:
    """Data for sdk.tool.approved event - approval decision."""

    tool_call_id: str
    approved: bool
    reason: str | None = None


@dataclass
class SdkToolExecutedData:
    """Data for sdk.tool.executed event - tool execution result."""

    tool_call_id: str
    server_name: str
    tool_name: str
    result: dict[str, Any] = field(default_factory=dict)
    dry_run: bool | None = None


@dataclass
class SdkErrorData:
    """Data for sdk.error event - error notification."""

    message: str
    cause: Any | None = None


@dataclass
class SdkFinalData:
    """Data for sdk.final event - terminal result."""

    success: bool
    model: str
    result: dict[str, Any] = field(default_factory=dict)
    messages: dict[str, list[Any]] = field(default_factory=dict)
    meta: dict[str, Any] = field(default_factory=dict)
    error: str | None = None


# Union type for all event data types
SdkEventData = (
    SdkInitData
    | SdkRunStartedData
    | SdkMessageDeltaData
    | SdkMessageFullData
    | SdkProgressData
    | SdkToolRequestedData
    | SdkToolApprovedData
    | SdkToolExecutedData
    | SdkErrorData
    | SdkFinalData
    | dict[str, Any]  # Allow raw dict for flexibility
)


@dataclass
class SdkEventEnvelope:
    """
    Base envelope for all SDK events.

    All events follow this structure with a protocol version,
    event type, timestamps, and the event-specific data payload.
    """

    protocol: str
    type: SdkEventType
    timestamp: int
    seq: int
    run_id: str
    session_id: str
    data: SdkEventData
    request_id: str | None = None
    elapsed_ms: int | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert event to dictionary for serialization."""
        result: dict[str, Any] = {
            "protocol": self.protocol,
            "type": self.type.value if isinstance(self.type, SdkEventType) else self.type,
            "timestamp": self.timestamp,
            "seq": self.seq,
            "run_id": self.run_id,
            "session_id": self.session_id,
        }

        if self.request_id:
            result["request_id"] = self.request_id
        if self.elapsed_ms is not None:
            result["elapsed_ms"] = self.elapsed_ms

        # Convert data to dict if it's a dataclass
        if hasattr(self.data, "__dataclass_fields__"):
            result["data"] = {k: v for k, v in self.data.__dict__.items() if v is not None}
        else:
            result["data"] = self.data

        return result


# Type aliases for SDK events
QodoSdkEvent = SdkEventEnvelope
SdkEvent = SdkEventEnvelope


def create_sdk_event(
    event_type: SdkEventType,
    run_id: str,
    seq: int,
    session_id: str,
    data: SdkEventData,
    *,
    request_id: str | None = None,
    elapsed_ms: int | None = None,
    start_time: float | None = None,
) -> SdkEventEnvelope:
    """
    Create a new SDK event envelope.

    Args:
        event_type: The type of event.
        run_id: Unique identifier for this run.
        seq: Monotonic sequence number for this run.
        session_id: Backend session ID.
        data: Event-specific data payload.
        request_id: Backend request ID (optional).
        elapsed_ms: Elapsed time since stream start (optional).
        start_time: Start time for calculating elapsed_ms (optional).

    Returns:
        A new SdkEventEnvelope.

    Example:
        event = create_sdk_event(
            event_type=SdkEventType.MESSAGE_DELTA,
            run_id="run-123",
            seq=1,
            session_id="session-456",
            data=SdkMessageDeltaData(
                message_id="msg-1",
                delta="Hello",
            ),
        )
    """
    timestamp = int(time.time() * 1000)

    # Calculate elapsed_ms if start_time provided
    if elapsed_ms is None and start_time is not None:
        elapsed_ms = int((time.time() - start_time) * 1000)

    return SdkEventEnvelope(
        protocol=SDK_PROTOCOL_V2,
        type=event_type,
        timestamp=timestamp,
        seq=seq,
        run_id=run_id,
        session_id=session_id,
        data=data,
        request_id=request_id,
        elapsed_ms=elapsed_ms,
    )


T = TypeVar("T")


def match_sdk_event(
    event: QodoSdkEvent,
    handlers: dict[SdkEventType, Callable[[QodoSdkEvent], T]],
    default: Callable[[QodoSdkEvent], T] | None = None,
) -> T | None:
    """
    Route an event to the appropriate handler.

    Provides type-safe event matching similar to a switch statement.

    Args:
        event: The event to match.
        handlers: Dictionary mapping event types to handler functions.
        default: Optional default handler for unmatched events.

    Returns:
        The return value of the matched handler, or None if no match.

    Example:
        def handle_delta(e: QodoSdkEvent) -> None:
            print(e.data.delta, end="")

        def handle_error(e: QodoSdkEvent) -> None:
            print(f"Error: {e.data.message}")

        match_sdk_event(event, {
            SdkEventType.MESSAGE_DELTA: handle_delta,
            SdkEventType.ERROR: handle_error,
        })
    """
    handler = handlers.get(event.type)
    if handler:
        return handler(event)
    if default:
        return default(event)
    return None


class EventEmitter:
    """
    Helper class for emitting SDK events with automatic sequencing.

    Maintains run state (run_id, session_id, seq counter) and provides
    convenient methods for emitting each event type.
    """

    def __init__(
        self,
        run_id: str,
        session_id: str,
        request_id: str | None = None,
    ) -> None:
        self.run_id = run_id
        self.session_id = session_id
        self.request_id = request_id
        self._seq = 0
        self._start_time = time.time()

    def _next_seq(self) -> int:
        """Get next sequence number."""
        self._seq += 1
        return self._seq

    def _elapsed_ms(self) -> int:
        """Calculate elapsed time since start."""
        return int((time.time() - self._start_time) * 1000)

    def emit(
        self,
        event_type: SdkEventType,
        data: SdkEventData,
    ) -> SdkEventEnvelope:
        """Emit an event with automatic sequencing."""
        return create_sdk_event(
            event_type=event_type,
            run_id=self.run_id,
            seq=self._next_seq(),
            session_id=self.session_id,
            data=data,
            request_id=self.request_id,
            elapsed_ms=self._elapsed_ms(),
        )

    def init(
        self,
        sdk_version: str,
        *,
        pid: int | None = None,
        backend: dict[str, str] | None = None,
        model: str | None = None,
    ) -> SdkEventEnvelope:
        """Emit sdk.init event."""
        return self.emit(
            SdkEventType.INIT,
            SdkInitData(
                sdk_version=sdk_version,
                protocol=SDK_PROTOCOL_V2,
                pid=pid,
                backend=backend,
                model=model,
            ),
        )

    def run_started(
        self,
        command: str,
        prompt_mode: bool,
        cwd: str,
        agent: dict[str, Any],
        tools_auto_approved: bool,
    ) -> SdkEventEnvelope:
        """Emit sdk.run.started event."""
        return self.emit(
            SdkEventType.RUN_STARTED,
            SdkRunStartedData(
                session_id=self.session_id,
                command=command,
                prompt_mode=prompt_mode,
                cwd=cwd,
                agent=agent,
                tools_auto_approved=tools_auto_approved,
            ),
        )

    def message_delta(
        self,
        message_id: str,
        delta: str,
        role: str = "assistant",
    ) -> SdkEventEnvelope:
        """Emit sdk.message.delta event."""
        return self.emit(
            SdkEventType.MESSAGE_DELTA,
            SdkMessageDeltaData(
                message_id=message_id,
                role=role,
                delta=delta,
            ),
        )

    def message_full(
        self,
        messages: dict[str, list[Any]],
    ) -> SdkEventEnvelope:
        """Emit sdk.message.full event."""
        return self.emit(
            SdkEventType.MESSAGE_FULL,
            SdkMessageFullData(messages=messages),
        )

    def progress(
        self,
        *,
        title: str | None = None,
        status: str | None = None,
        percent: float | None = None,
        raw: Any | None = None,
    ) -> SdkEventEnvelope:
        """Emit sdk.progress event."""
        return self.emit(
            SdkEventType.PROGRESS,
            SdkProgressData(
                title=title,
                status=status,
                percent=percent,
                raw=raw,
            ),
        )

    def tool_requested(
        self,
        tool_call_id: str,
        server_name: str,
        tool_name: str,
        tool_args: Any,
        pending_approval: bool,
        reasoning: str | None = None,
    ) -> SdkEventEnvelope:
        """Emit sdk.tool.requested event."""
        return self.emit(
            SdkEventType.TOOL_REQUESTED,
            SdkToolRequestedData(
                tool_call_id=tool_call_id,
                server_name=server_name,
                tool_name=tool_name,
                tool_args=tool_args,
                pending_approval=pending_approval,
                reasoning=reasoning,
            ),
        )

    def tool_approved(
        self,
        tool_call_id: str,
        approved: bool,
        reason: str | None = None,
    ) -> SdkEventEnvelope:
        """Emit sdk.tool.approved event."""
        return self.emit(
            SdkEventType.TOOL_APPROVED,
            SdkToolApprovedData(
                tool_call_id=tool_call_id,
                approved=approved,
                reason=reason,
            ),
        )

    def tool_executed(
        self,
        tool_call_id: str,
        server_name: str,
        tool_name: str,
        result: dict[str, Any],
    ) -> SdkEventEnvelope:
        """Emit sdk.tool.executed event."""
        return self.emit(
            SdkEventType.TOOL_EXECUTED,
            SdkToolExecutedData(
                tool_call_id=tool_call_id,
                server_name=server_name,
                tool_name=tool_name,
                result=result,
            ),
        )

    def error(
        self,
        message: str,
        cause: Any | None = None,
    ) -> SdkEventEnvelope:
        """Emit sdk.error event."""
        return self.emit(
            SdkEventType.ERROR,
            SdkErrorData(
                message=message,
                cause=cause,
            ),
        )

    def final(
        self,
        success: bool,
        model: str,
        *,
        result: dict[str, Any] | None = None,
        messages: dict[str, list[Any]] | None = None,
        meta: dict[str, Any] | None = None,
        error: str | None = None,
    ) -> SdkEventEnvelope:
        """Emit sdk.final event."""
        return self.emit(
            SdkEventType.FINAL,
            SdkFinalData(
                success=success,
                model=model,
                result=result or {},
                messages=messages or {},
                meta=meta or {},
                error=error,
            ),
        )
