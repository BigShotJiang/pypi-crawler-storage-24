"""
HTTP client for Qodo backend communication.

Provides async HTTP request functionality with authentication and error handling.
"""

from __future__ import annotations

import uuid
from typing import Any, Literal

import httpx

from qodo.auth import get_auth_config
from qodo.errors import QodoBackendBootstrapError, QodoTimeoutError
from qodo.session.environment import get_current_environment

# Default timeout in milliseconds
DEFAULT_TIMEOUT_MS = 30000

# HTTP methods
HttpMethod = Literal["GET", "POST", "DELETE", "PUT", "PATCH"]


async def http_request(
    method: HttpMethod,
    url: str,
    *,
    data: dict[str, Any] | None = None,
    base_url: str | None = None,
    timeout_ms: int = DEFAULT_TIMEOUT_MS,
    request_id: str | None = None,
    session_id: str | None = None,
    headers: dict[str, str] | None = None,
) -> Any:
    """
    Make an HTTP request to the Qodo backend.

    Args:
        method: HTTP method (GET, POST, DELETE, PUT, PATCH).
        url: URL path (will be joined with base_url).
        data: Request body for POST/PUT/PATCH requests.
        base_url: Base URL override. If not provided, uses auth endpoint.
        timeout_ms: Request timeout in milliseconds.
        request_id: Optional request ID for tracking.
        session_id: Optional session ID for tracking.
        headers: Additional headers to include.

    Returns:
        Response JSON data.

    Raises:
        QodoAuthError: If authentication fails (401 response).
        QodoBackendBootstrapError: For other HTTP errors.
        QodoTimeoutError: If request times out.

    Example:
        response = await http_request(
            "GET",
            "/v2/info/get-things",
            session_id="abc123",
        )
    """
    # Get base URL
    if base_url is None:
        from qodo.auth import get_api_endpoint

        base_url = get_api_endpoint()

    # Build full URL
    full_url = f"{base_url.rstrip('/')}/{url.lstrip('/')}"

    # Get auth token (environment-scoped AuthProvider takes precedence)
    env = get_current_environment()
    auth_config = env.auth_provider.get_auth_config() if env.auth_provider else get_auth_config()

    # Build headers
    request_headers = {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "Authorization": f"Bearer {auth_config.token}",
    }

    if request_id:
        request_headers["Request-id"] = request_id
    else:
        request_headers["Request-id"] = str(uuid.uuid4())

    if session_id:
        request_headers["Session-id"] = session_id
    else:
        request_headers["Session-id"] = str(uuid.uuid4())

    if headers:
        request_headers.update(headers)

    # Convert timeout to seconds
    timeout_seconds = timeout_ms / 1000

    try:
        async with httpx.AsyncClient(timeout=timeout_seconds) as client:
            if method == "GET":
                response = await client.get(full_url, headers=request_headers)
            elif method == "POST":
                response = await client.post(full_url, headers=request_headers, json=data)
            elif method == "DELETE":
                response = await client.delete(full_url, headers=request_headers)
            elif method == "PUT":
                response = await client.put(full_url, headers=request_headers, json=data)
            elif method == "PATCH":
                response = await client.patch(full_url, headers=request_headers, json=data)
            else:
                raise ValueError(f"Unsupported HTTP method: {method}")

            # Handle 401 errors
            if response.status_code == 401:
                from qodo.auth import handle_401_error

                if env.auth_provider:
                    env.auth_provider.handle_401_error()
                else:
                    handle_401_error()

            # Raise for other errors
            response.raise_for_status()

            # Parse response
            return response.json()

    except httpx.TimeoutException as e:
        raise QodoTimeoutError(f"Request timed out after {timeout_ms}ms: {e}") from e
    except httpx.HTTPStatusError as e:
        raise QodoBackendBootstrapError(
            f"HTTP error {e.response.status_code}: {e.response.text}"
        ) from e
    except httpx.RequestError as e:
        raise QodoBackendBootstrapError(f"Request failed: {e}") from e


async def http_get(
    url: str,
    *,
    base_url: str | None = None,
    timeout_ms: int = DEFAULT_TIMEOUT_MS,
    request_id: str | None = None,
    session_id: str | None = None,
    headers: dict[str, str] | None = None,
) -> Any:
    """
    Make an HTTP GET request.

    Convenience wrapper around http_request().
    """
    return await http_request(
        "GET",
        url,
        base_url=base_url,
        timeout_ms=timeout_ms,
        request_id=request_id,
        session_id=session_id,
        headers=headers,
    )


async def http_post(
    url: str,
    data: dict[str, Any] | None = None,
    *,
    base_url: str | None = None,
    timeout_ms: int = DEFAULT_TIMEOUT_MS,
    request_id: str | None = None,
    session_id: str | None = None,
    headers: dict[str, str] | None = None,
) -> Any:
    """
    Make an HTTP POST request.

    Convenience wrapper around http_request().
    """
    return await http_request(
        "POST",
        url,
        data=data,
        base_url=base_url,
        timeout_ms=timeout_ms,
        request_id=request_id,
        session_id=session_id,
        headers=headers,
    )


async def http_delete(
    url: str,
    *,
    base_url: str | None = None,
    timeout_ms: int = DEFAULT_TIMEOUT_MS,
    request_id: str | None = None,
    session_id: str | None = None,
    headers: dict[str, str] | None = None,
) -> Any:
    """
    Make an HTTP DELETE request.

    Convenience wrapper around http_request().
    """
    return await http_request(
        "DELETE",
        url,
        base_url=base_url,
        timeout_ms=timeout_ms,
        request_id=request_id,
        session_id=session_id,
        headers=headers,
    )


class HttpClient:
    """
    Stateful HTTP client for repeated requests.

    Maintains session_id and base_url across requests.
    """

    def __init__(
        self,
        base_url: str | None = None,
        session_id: str | None = None,
        timeout_ms: int = DEFAULT_TIMEOUT_MS,
    ) -> None:
        self.base_url = base_url
        self.session_id = session_id or str(uuid.uuid4())
        self.timeout_ms = timeout_ms

    async def get(
        self,
        url: str,
        *,
        request_id: str | None = None,
        headers: dict[str, str] | None = None,
    ) -> Any:
        """Make a GET request."""
        return await http_get(
            url,
            base_url=self.base_url,
            timeout_ms=self.timeout_ms,
            request_id=request_id,
            session_id=self.session_id,
            headers=headers,
        )

    async def post(
        self,
        url: str,
        data: dict[str, Any] | None = None,
        *,
        request_id: str | None = None,
        headers: dict[str, str] | None = None,
    ) -> Any:
        """Make a POST request."""
        return await http_post(
            url,
            data=data,
            base_url=self.base_url,
            timeout_ms=self.timeout_ms,
            request_id=request_id,
            session_id=self.session_id,
            headers=headers,
        )

    async def delete(
        self,
        url: str,
        *,
        request_id: str | None = None,
        headers: dict[str, str] | None = None,
    ) -> Any:
        """Make a DELETE request."""
        return await http_delete(
            url,
            base_url=self.base_url,
            timeout_ms=self.timeout_ms,
            request_id=request_id,
            session_id=self.session_id,
            headers=headers,
        )
