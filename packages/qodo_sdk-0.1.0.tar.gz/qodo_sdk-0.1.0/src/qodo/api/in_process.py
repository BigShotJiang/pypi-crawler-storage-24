"""
In-process graph runner for executing LangGraph SDK graphs directly.

Bypasses the WebSocket-based AgentAPI entirely, running the Command Backend's
LangGraph graph in the same process. Uses MCPManager for local tool execution
and the interrupt-resume pattern for IDE tool calls.
"""

from __future__ import annotations

import asyncio
import logging
import os
import uuid
from collections.abc import AsyncGenerator, Callable
from typing import Any

from qodo.sdk.events import (
    EventEmitter,
    QodoSdkEvent,
    get_sdk_version,
)

logger = logging.getLogger(__name__)

# Default timeout for a single graph execution (10 minutes)
DEFAULT_GRAPH_TIMEOUT_S = 600


class InProcessGraphRunner:
    """Runs a LangGraph SDK graph directly, with MCP tool execution via MCPManager.

    Uses the interrupt-resume pattern:
    1. Start graph -> it runs until IDEMCPNode interrupts for a tool call
    2. Extract tool request from graph output
    3. Execute tool via MCPManager
    4. Resume graph with ToolMessage
    5. Repeat until completion
    """

    def __init__(
        self,
        graph_builder: Callable[..., Any],
        mcp_manager: Any,
        *,
        auto_approve_tools: bool = True,
    ) -> None:
        """
        Args:
            graph_builder: A callable that takes a MemorySaver checkpointer and
                returns a compiled LangGraph StateGraph.
            mcp_manager: An initialized MCPManager instance for tool execution.
            auto_approve_tools: Whether to auto-approve all tool calls.
        """
        self._graph_builder = graph_builder
        self._mcp_manager = mcp_manager
        self._auto_approve_tools = auto_approve_tools
        # Interrupt-resume state (per-execution, but initialized defensively)
        self._resume_state: dict[str, Any] = {}
        self._resume_as_node: str | None = None

    async def execute(
        self,
        *,
        command_config: Any,
        session_id: str,
        workspace_path: str,
        user_request: str,
        available_tools: dict[str, list[dict[str, Any]]],
        output_schema: dict[str, Any] | None = None,
        custom_model: str | None = None,
        instructions: str | None = None,
        system_prompt: str | None = None,
        additional_paths: list[str] | None = None,
        execution_strategy: str | None = None,
        timeout: int | None = None,
    ) -> AsyncGenerator[QodoSdkEvent, None]:
        """Run a command through the graph, yielding SDK events.

        Args:
            command_config: The resolved CommandConfig for this run.
            session_id: Unique session identifier.
            workspace_path: Primary project directory.
            user_request: The user's prompt / command text.
            available_tools: Tools map {server_id: [tool_dicts]}.
            output_schema: Optional JSON schema for structured output.
            custom_model: Optional model override.
            instructions: Optional agent instructions.
            system_prompt: Optional system prompt.
            additional_paths: Optional additional accessible directories.
            execution_strategy: Optional execution strategy ('plan' or 'act').
            timeout: Timeout in milliseconds. Defaults to DEFAULT_GRAPH_TIMEOUT_S * 1000.

        Yields:
            QodoSdkEvent instances following the qodo.sdk.v2 protocol.
        """
        run_id = str(uuid.uuid4())
        emitter = EventEmitter(
            run_id=run_id,
            session_id=session_id,
        )

        # Emit init
        yield emitter.init(
            sdk_version=get_sdk_version(),
            pid=os.getpid(),
            backend={"base_url": "in-process", "source": "in_process"},
            model=custom_model or "",
        )

        # Emit run.started
        yield emitter.run_started(
            command=getattr(command_config, "name", "") or "",
            prompt_mode=True,
            cwd=workspace_path,
            agent={"source": "in_process"},
            tools_auto_approved=self._auto_approve_tools,
        )

        timeout_s = (timeout / 1000) if timeout else DEFAULT_GRAPH_TIMEOUT_S

        try:
            # Build the graph with an in-memory checkpointer
            from langgraph.checkpoint.memory import MemorySaver

            checkpointer = MemorySaver()
            compiled_graph = self._graph_builder(checkpointer)

            # Build QodoAgentState initial values
            from command.agents.consts import AgentType
            from command.agents.graphs.graph_orchestrator import GraphOrchestrator

            projects_root = [workspace_path]
            if additional_paths:
                projects_root.extend(additional_paths)

            initial_state = {
                "messages": [],
                "session_id": session_id,
                "user_request": user_request,
                "available_tools": available_tools,
                "cwd": workspace_path,
                "projects_root_path": projects_root,
                "agent_type": AgentType.SDK,
            }

            if output_schema is not None:
                initial_state["output_schema"] = output_schema
            if custom_model is not None:
                initial_state["custom_model"] = custom_model
            if instructions is not None:
                initial_state["instructions"] = instructions
            if system_prompt is not None:
                initial_state["system_prompt"] = system_prompt
            if execution_strategy is not None:
                initial_state["execution_strategy"] = execution_strategy

            orchestrator = GraphOrchestrator(
                graph=compiled_graph,
                session_id=session_id,
            )

            # Run the graph with interrupt-resume loop
            accumulated_text = ""
            message_id = str(uuid.uuid4())

            async for event in self._run_graph_loop(
                orchestrator=orchestrator,
                initial_state=initial_state,
                emitter=emitter,
                timeout_s=timeout_s,
                accumulated_text_ref={"text": accumulated_text, "message_id": message_id},
            ):
                yield event

        except asyncio.TimeoutError:
            yield emitter.error(f"Execution timed out after {timeout_s}s")
            yield emitter.final(
                success=False,
                model=custom_model or "",
                error=f"Execution timed out after {timeout_s}s",
                meta={"timed_out": True, "tools_auto_approved": self._auto_approve_tools},
            )
        except Exception as e:
            logger.exception("In-process graph execution failed")
            yield emitter.error(str(e), cause=str(e))
            yield emitter.final(
                success=False,
                model=custom_model or "",
                error=str(e),
                meta={"tools_auto_approved": self._auto_approve_tools},
            )

    async def _run_graph_loop(
        self,
        *,
        orchestrator: Any,
        initial_state: dict[str, Any],
        emitter: EventEmitter,
        timeout_s: float,
        accumulated_text_ref: dict[str, str],
    ) -> AsyncGenerator[QodoSdkEvent, None]:
        """Core interrupt-resume loop.

        Starts the graph, handles IDE tool interrupts via MCPManager,
        and resumes until the graph completes.
        """
        is_first_run = True
        graph_complete = False

        while not graph_complete:
            try:
                if is_first_run:
                    stream = orchestrator.start(initial_state)
                    is_first_run = False
                else:
                    # We need to resume -- the resume state is set before re-entering the loop
                    stream = orchestrator.resume(
                        self._resume_state,
                        as_node=self._resume_as_node,
                    )

                # Consume stream with per-item timeout
                async for graph_response in stream:
                    # Process streamed output (e.g., UserResponse messages)
                    delta_events = self._process_graph_stream_event(
                        graph_response, emitter, accumulated_text_ref
                    )
                    for evt in delta_events:
                        yield evt

            except asyncio.TimeoutError:
                raise  # Propagate to outer handler

            # After the stream completes, check if the graph is interrupted
            state_snapshot = await orchestrator.get_current_state()
            next_nodes = state_snapshot.next if state_snapshot else ()

            if not next_nodes:
                # Graph finished
                graph_complete = True
                # Extract final result from state
                final_state = state_snapshot.values if state_snapshot else {}
                async for evt in self._emit_final(final_state, emitter, accumulated_text_ref):
                    yield evt
            else:
                # Graph interrupted -- extract tool request and execute
                async for evt in self._handle_interrupt(
                    state_snapshot, emitter, accumulated_text_ref, timeout_s
                ):
                    yield evt

    def _process_graph_stream_event(
        self,
        graph_response: Any,
        emitter: EventEmitter,
        accumulated_text_ref: dict[str, str],
    ) -> list[QodoSdkEvent]:
        """Process a single streamed event from the graph.

        The graph uses stream_mode="custom", so responses are whatever nodes
        emit via StreamWriter. Typically these are dict payloads like:
        {"type": "answer", "data": {...}} for tool requests/results, or
        text content from UserResponse.
        """
        events: list[QodoSdkEvent] = []

        if not isinstance(graph_response, dict):
            return events

        # Handle streamed text (UserResponse-style messages)
        data = graph_response.get("data", {})
        if isinstance(data, dict):
            tool = data.get("tool")
            if tool == "UserResponse":
                # Extract text content from tool_args
                tool_args = data.get("tool_args", {})
                text = tool_args.get("response", "")
                if text:
                    old_text = accumulated_text_ref["text"]
                    delta = text[len(old_text) :] if text.startswith(old_text) else text
                    if delta:
                        accumulated_text_ref["text"] = text
                        events.append(
                            emitter.message_delta(
                                message_id=accumulated_text_ref["message_id"],
                                delta=delta,
                            )
                        )

        return events

    async def _handle_interrupt(
        self,
        state_snapshot: Any,
        emitter: EventEmitter,
        accumulated_text_ref: dict[str, str],
        timeout_s: float,
    ) -> AsyncGenerator[QodoSdkEvent, None]:
        """Handle graph interrupt by extracting tool request and executing it.

        When the graph pauses (IDEMCPNode interrupt_after=True), the last
        message in state is an AIMessage with tool_calls. We extract the
        tool call, execute it via MCPManager, and set up the resume state.
        """
        state_values = state_snapshot.values if state_snapshot else {}
        messages = state_values.get("messages", [])

        if not messages:
            logger.error("Graph interrupted but no messages in state")
            self._resume_state = {"messages": []}
            self._resume_as_node = None
            return

        # The streamed data from the interrupt node contains the tool request
        # We need to check the end_of_node_responses_data or the state tasks
        # The last message should be an AIMessage with tool_calls
        last_message = messages[-1]

        # Extract tool call info from the AIMessage
        tool_calls = getattr(last_message, "tool_calls", None)
        if not tool_calls:
            # Try dict access for non-LangChain message objects
            if isinstance(last_message, dict):
                tool_calls = last_message.get("tool_calls", [])

        if not tool_calls:
            logger.warning("Graph interrupted but no tool_calls found in last message")
            self._resume_state = {"messages": []}
            self._resume_as_node = None
            return

        # Process each tool call (typically one at a time for IDE tools)
        from langchain_core.messages import ToolMessage

        tool_messages = []
        for tool_call in tool_calls:
            if isinstance(tool_call, dict):
                tool_call_id = tool_call.get("id", str(uuid.uuid4()))
                tool_name = tool_call.get("name", "unknown")
                tool_args = tool_call.get("args", {})
            else:
                tool_call_id = getattr(tool_call, "id", str(uuid.uuid4()))
                tool_name = getattr(tool_call, "name", "unknown")
                tool_args = getattr(tool_call, "args", {})

            # Determine server name from the tool registry in graph state
            server_name = self._resolve_server_name(tool_name, state_values)

            # Emit tool.requested
            yield emitter.tool_requested(
                tool_call_id=tool_call_id,
                server_name=server_name,
                tool_name=tool_name,
                tool_args=tool_args,
                pending_approval=False,
            )

            # Emit tool.approved (auto-approved in in-process mode)
            yield emitter.tool_approved(
                tool_call_id=tool_call_id,
                approved=True,
            )

            # Execute tool via MCPManager
            try:
                result = await asyncio.wait_for(
                    self._mcp_manager.call_tool(
                        server_name,
                        tool_name,
                        tool_args,
                    ),
                    timeout=timeout_s,
                )

                # Format result content
                content_text = ""
                if result.content:
                    if isinstance(result.content, list):
                        for item in result.content:
                            if isinstance(item, dict) and item.get("type") == "text":
                                content_text = item.get("text", "")
                                break
                    else:
                        content_text = str(result.content)

                tool_result = {
                    "isError": result.is_error,
                    "content": [{"type": "text", "text": content_text}],
                }

                # Emit tool.executed
                yield emitter.tool_executed(
                    tool_call_id=tool_call_id,
                    server_name=server_name,
                    tool_name=tool_name,
                    result=tool_result,
                )

                # Build ToolMessage for graph resume
                tool_messages.append(
                    ToolMessage(
                        content=content_text,
                        tool_call_id=tool_call_id,
                        additional_kwargs={"source": None},
                    )
                )

            except asyncio.TimeoutError:
                error_msg = f"Tool {tool_name} timed out"
                yield emitter.tool_executed(
                    tool_call_id=tool_call_id,
                    server_name=server_name,
                    tool_name=tool_name,
                    result={"isError": True, "content": [{"type": "text", "text": error_msg}]},
                )
                tool_messages.append(
                    ToolMessage(
                        content=error_msg,
                        tool_call_id=tool_call_id,
                        additional_kwargs={"source": None},
                    )
                )

            except Exception as e:
                error_msg = f"Tool {tool_name} failed: {e}"
                logger.exception("Tool execution failed in in-process runner")
                yield emitter.tool_executed(
                    tool_call_id=tool_call_id,
                    server_name=server_name,
                    tool_name=tool_name,
                    result={"isError": True, "content": [{"type": "text", "text": error_msg}]},
                )
                tool_messages.append(
                    ToolMessage(
                        content=error_msg,
                        tool_call_id=tool_call_id,
                        additional_kwargs={"source": None},
                    )
                )

        # Set up resume state
        self._resume_state = {"messages": tool_messages}
        self._resume_as_node = None

    def _resolve_server_name(self, tool_name: str, state_values: dict[str, Any]) -> str:
        """Resolve the MCP server name for a given tool name.

        Looks up in the available_tools map from graph state, then falls
        back to MCPManager's tool registry.
        """
        # Check available_tools in state
        available_tools = state_values.get("available_tools", {})
        for server_id, tools in available_tools.items():
            for tool in tools:
                name = tool.get("name", "") if isinstance(tool, dict) else getattr(tool, "name", "")
                if name == tool_name:
                    return str(server_id)

        # Fall back to MCPManager's internal registry
        all_tools = self._mcp_manager.get_all_tools()
        for server_id, tools in all_tools.items():
            for tool in tools:
                if tool.name == tool_name:
                    return str(server_id)

        return "unknown"

    async def _emit_final(
        self,
        final_state: dict[str, Any],
        emitter: EventEmitter,
        accumulated_text_ref: dict[str, str],
    ) -> AsyncGenerator[QodoSdkEvent, None]:
        """Emit the final event after graph completion."""
        from command.agents.consts import TaskStatus

        status = final_state.get("status", TaskStatus.Completed.name)
        success = status not in (
            TaskStatus.Failed.name,
            TaskStatus.Exception.name,
        )

        # Extract structured output
        result: dict[str, Any] = {}
        structured_output = final_state.get("last_structured_output")
        if structured_output:
            result["structured_output"] = structured_output

        # Extract final text from messages
        messages = final_state.get("messages", [])
        final_text = ""
        if messages:
            last_msg = messages[-1]
            content = getattr(last_msg, "content", None)
            if isinstance(content, str):
                final_text = content
            elif isinstance(last_msg, dict):
                final_text = last_msg.get("content", "")

        if final_text:
            result["final_output"] = final_text

        model = final_state.get("custom_model", "")

        # Emit a final message delta for any remaining text
        if final_text and final_text != accumulated_text_ref["text"]:
            delta = final_text[len(accumulated_text_ref["text"]) :]
            if delta:
                yield emitter.message_delta(
                    message_id=accumulated_text_ref["message_id"],
                    delta=delta,
                )

        error_msg = None
        if not success:
            error_msg = f"Graph ended with status: {status}"

        yield emitter.final(
            success=success,
            model=model or "",
            result=result,
            messages={"langchain": [], "openai": []},
            meta={"tools_auto_approved": self._auto_approve_tools, "in_process": True},
            error=error_msg,
        )
