"""
WebSocket client for Qodo backend communication.

Implements the Ready protocol state machine for reliable message delivery
with checkpoint recovery, heartbeat, and idle timeout handling.
"""

from __future__ import annotations

import asyncio
import json
import logging
import uuid
from collections.abc import Callable
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

import websockets
from websockets.asyncio.client import ClientConnection
from websockets.exceptions import ConnectionClosed

from qodo.errors import QodoConnectionError

logger = logging.getLogger(__name__)


class ConnectionState(str, Enum):
    """WebSocket connection states."""

    DISCONNECTED = "DISCONNECTED"
    CONNECTING = "CONNECTING"
    CONNECTED = "CONNECTED"
    RECONNECTING = "RECONNECTING"
    DISCONNECTING = "DISCONNECTING"
    FAILED = "FAILED"


class ReadyState(str, Enum):
    """
    Ready protocol states.

    The Ready protocol ensures reliable message delivery:
    1. Wait for initial Ready after connection
    2. Send message only when in READY state
    3. Wait for Ready after message to confirm processing
    4. Use checkpoint recovery if Ready not received in time
    """

    IDLE = "IDLE"
    WAITING_INITIAL_READY = "WAITING_INITIAL_READY"
    READY = "READY"
    MESSAGE_SENT = "MESSAGE_SENT"
    WAITING_READY = "WAITING_READY"
    CHECKPOINT_RECOVERY = "CHECKPOINT_RECOVERY"


@dataclass
class WebSocketConfig:
    """WebSocket client configuration."""

    idle_timeout_ms: int = 600000  # 10 minutes
    heartbeat_interval_ms: int = 30000  # 30 seconds
    heartbeat_timeout_ms: int = 60000  # 60 seconds
    connection_timeout_ms: int = 15000  # 15 seconds
    initial_reconnect_delay_ms: int = 1000  # 1 second
    max_reconnect_delay_ms: int = 30000  # 30 seconds
    reconnect_backoff_factor: float = 1.5
    ready_timeout_ms: int = 300000  # 5 minutes
    message_queue_max_size: int = 1000


@dataclass
class QueuedMessage:
    """A message queued for sending."""

    type: str
    data: Any
    timestamp: float = field(default_factory=lambda: asyncio.get_event_loop().time())


# Callback types
MessageCallback = Callable[[str], None]
StateCallback = Callable[[ConnectionState], None]
ReadyCallback = Callable[[str | None, ReadyState], None]


class WebSocketClient:
    """
    WebSocket client for Qodo backend communication.

    Implements the Ready protocol state machine for reliable message delivery
    with checkpoint recovery, heartbeat monitoring, and idle timeout.

    Example:
        client = WebSocketClient()
        client.on_message(lambda msg: print(f"Received: {msg}"))

        await client.connect(session_id="abc123")
        await client.send_message("UserQuery", {"user_request": "Hello"})

        # Later
        await client.disconnect()
    """

    def __init__(self, config: WebSocketConfig | None = None) -> None:
        self._config = config or WebSocketConfig()
        self._ws: ClientConnection | None = None
        self._state = ConnectionState.DISCONNECTED
        self._ready_state = ReadyState.IDLE

        # Session tracking
        self._session_id: str | None = None
        self._request_id: str | None = None
        self._connection_id: str | None = None
        self._latest_checkpoint_id: str | None = None

        # Message handling
        self._last_sent_message: QueuedMessage | None = None
        self._pending_outbox: list[QueuedMessage] = []
        self._received_responses_since_message = False

        # Callbacks
        self._on_message: MessageCallback | None = None
        self._on_state_changed: StateCallback | None = None
        self._on_ready_received: ReadyCallback | None = None

        # Async tasks
        self._heartbeat_task: asyncio.Task[None] | None = None
        self._idle_task: asyncio.Task[None] | None = None
        self._ready_timer_task: asyncio.Task[None] | None = None
        self._receiver_task: asyncio.Task[None] | None = None

        # Reconnection state
        self._reconnect_attempt = 0
        self._base_url: str | None = None

    @property
    def state(self) -> ConnectionState:
        """Get current connection state."""
        return self._state

    @property
    def ready_state(self) -> ReadyState:
        """Get current ready protocol state."""
        return self._ready_state

    @property
    def session_id(self) -> str | None:
        """Get current session ID."""
        return self._session_id

    def has_received_responses_since_last_message(self) -> bool:
        """Check if responses have been received since last message was sent."""
        return self._received_responses_since_message

    def on_message(self, callback: MessageCallback) -> None:
        """Register message callback."""
        self._on_message = callback

    def on_state_changed(self, callback: StateCallback) -> None:
        """Register state change callback."""
        self._on_state_changed = callback

    def on_ready_received(self, callback: ReadyCallback) -> None:
        """Register ready received callback."""
        self._on_ready_received = callback

    async def connect(
        self,
        session_id: str | None = None,
        request_id: str | None = None,
        base_url: str | None = None,
    ) -> None:
        """
        Connect to the WebSocket server.

        Args:
            session_id: Session ID for the connection.
            request_id: Request ID for tracking.
            base_url: Base URL override.
        """
        if session_id:
            self._session_id = session_id
        if request_id:
            self._request_id = request_id
        if base_url:
            self._base_url = base_url

        if self._state == ConnectionState.CONNECTED:
            self._reset_idle_timer()
            return

        await self._establish_connection()

    async def send_message(self, message_type: str, data: Any) -> None:
        """
        Send a message to the server.

        Args:
            message_type: Either 'UserQuery' or 'IDERetrievalAnswer'.
            data: Message payload.
        """
        self._reset_idle_timer()

        message = QueuedMessage(type=message_type, data=data)
        self._last_sent_message = message

        if (
            self._ready_state == ReadyState.READY
            and self._ws is not None
            and self._state == ConnectionState.CONNECTED
        ):
            self._received_responses_since_message = False
            await self._send_immediately(message)
            self._set_ready_state(ReadyState.MESSAGE_SENT, f"Sent {message_type} message")
            self._start_ready_timer()
        else:
            self._pending_outbox.append(message)
            if self._state == ConnectionState.DISCONNECTED:
                await self.connect()

    async def disconnect(self) -> None:
        """Disconnect from the server."""
        self._cancel_timers()
        self._connection_id = str(uuid.uuid4())

        if self._ws is not None:
            try:
                await self._ws.close(1000, "Normal closure")
            except Exception:
                pass  # cleanup: WS close during disconnect must not throw

        self._set_state(ConnectionState.DISCONNECTED)
        self._ws = None
        self._set_ready_state(ReadyState.IDLE, "Manual disconnect")

    async def cleanup(self) -> None:
        """Clean up all resources."""
        self._cancel_timers()
        await self.disconnect()
        self._pending_outbox.clear()
        self._latest_checkpoint_id = None
        self._last_sent_message = None

    def keep_alive(self) -> None:
        """Reset idle timer without sending a message."""
        self._reset_idle_timer()

    # Private methods

    async def _establish_connection(self) -> None:
        """Establish WebSocket connection."""
        self._set_state(ConnectionState.CONNECTING)
        self._connection_id = str(uuid.uuid4())

        url = self._build_websocket_url()
        token = self._get_auth_token()

        try:
            timeout = self._config.connection_timeout_ms / 1000
            self._ws = await asyncio.wait_for(
                websockets.connect(
                    url,
                    additional_headers={"Authorization": f"Bearer {token}"},
                ),
                timeout=timeout,
            )

            self._set_state(ConnectionState.CONNECTED)
            self._set_ready_state(
                ReadyState.WAITING_INITIAL_READY,
                "Connection opened, awaiting initial Ready",
            )
            self._reconnect_attempt = 0
            self._start_ready_timer()
            self._start_heartbeat()
            self._start_idle_timer()

            # Start message receiver
            self._receiver_task = asyncio.create_task(self._receive_messages())

        except asyncio.TimeoutError as e:
            self._set_state(ConnectionState.FAILED)
            raise QodoConnectionError(
                f"Connection timeout after {self._config.connection_timeout_ms}ms"
            ) from e
        except Exception as e:
            self._set_state(ConnectionState.FAILED)
            raise QodoConnectionError(f"Failed to connect: {e}") from e

    async def _receive_messages(self) -> None:
        """Receive and dispatch messages from the WebSocket."""
        connection_id = self._connection_id

        if self._ws is None:
            return

        try:
            async for message in self._ws:
                # Check if this connection is still valid
                if self._connection_id != connection_id:
                    break

                self._reset_idle_timer()

                if isinstance(message, bytes):
                    message = message.decode("utf-8")

                try:
                    # Try to parse as pure JSON first (backend may send without TYPE prefix)
                    json_str = message
                    if not message.startswith("{"):
                        # Parse the message (format: "TYPE JSON_DATA")
                        parts = message.split(" ", 1)
                        if len(parts) < 2:
                            continue
                        json_str = parts[1]

                    msg_data = json.loads(json_str)

                    # Check for Ready message
                    if msg_data.get("data", {}).get("tool") == "Ready":
                        await self._handle_ready_message(msg_data)
                        continue

                    # Track non-Ready, non-keepalive responses
                    # keepalive messages are protocol messages, not actual task responses
                    msg_type = msg_data.get("type", "")
                    if self._ready_state == ReadyState.MESSAGE_SENT and msg_type != "keepalive":
                        self._received_responses_since_message = True

                    # Dispatch to handler - pass the JSON string, not raw message with TYPE prefix
                    if self._on_message:
                        logger.debug(f"[WebSocket] Dispatching message: {json_str[:200]}...")
                        self._on_message(json_str)

                except json.JSONDecodeError:
                    # Non-JSON message, pass through as-is
                    if self._on_message:
                        self._on_message(message)

        except ConnectionClosed as e:
            self._handle_close(e.code, e.reason)
        except Exception as e:
            logger.debug(f"Error receiving messages: {e}")
            self._handle_close(None, str(e))

    async def _handle_ready_message(self, message: dict[str, Any]) -> None:
        """Handle Ready protocol message."""
        checkpoint_id = message.get("data", {}).get("tool_args", {}).get("checkpoint_id")
        previous_ready_state = self._ready_state

        if checkpoint_id and checkpoint_id != self._latest_checkpoint_id:
            self._latest_checkpoint_id = checkpoint_id

        # State machine transitions
        if self._ready_state == ReadyState.WAITING_INITIAL_READY:
            self._cancel_ready_timer()
            self._set_ready_state(ReadyState.READY, "Initial Ready received")
            await self._process_outbox()

        elif self._ready_state == ReadyState.MESSAGE_SENT:
            if not self._received_responses_since_message:
                # Ready without responses - something went wrong
                self._cancel_ready_timer()
                await self._initiate_checkpoint_recovery("Ready without responses")
                return

            self._cancel_ready_timer()
            self._set_ready_state(ReadyState.READY, "Ready received, processing complete")
            await self._process_outbox()

        if self._on_ready_received:
            self._on_ready_received(checkpoint_id, previous_ready_state)

    async def _send_immediately(self, msg: QueuedMessage) -> None:
        """Send message immediately."""
        if self._ws is None:
            return

        formatted = f"{msg.type} {json.dumps(msg.data)}\n"
        await self._ws.send(formatted)

    async def _process_outbox(self) -> None:
        """Process pending messages in the outbox."""
        if self._pending_outbox and self._ready_state == ReadyState.READY:
            msg = self._pending_outbox.pop(0)
            self._received_responses_since_message = False
            await self._send_immediately(msg)
            self._set_ready_state(ReadyState.MESSAGE_SENT, f"Sent queued {msg.type} message")
            self._start_ready_timer()

    async def _initiate_checkpoint_recovery(self, reason: str) -> None:
        """Initiate checkpoint recovery."""
        logger.debug(f"Initiating checkpoint recovery: {reason}")
        self._set_ready_state(ReadyState.CHECKPOINT_RECOVERY, reason)
        await self.disconnect()
        await self._establish_connection()

        # Re-queue the last sent message
        if self._last_sent_message:
            self._pending_outbox.insert(0, self._last_sent_message)

    def _set_state(self, new_state: ConnectionState) -> None:
        """Set connection state and notify callback."""
        if self._state != new_state:
            logger.debug(f"Connection state: {self._state} -> {new_state}")
            self._state = new_state
            if self._on_state_changed:
                self._on_state_changed(new_state)

    def _set_ready_state(self, new_state: ReadyState, context: str) -> None:
        """Set ready state with debug logging."""
        if self._ready_state != new_state:
            logger.debug(f"Ready state: {self._ready_state} -> {new_state} ({context})")
            self._ready_state = new_state

    def _build_websocket_url(self) -> str:
        """Build WebSocket URL with query parameters."""
        if self._base_url:
            base_url = self._base_url
        else:
            from qodo.auth import get_api_endpoint

            base_url = get_api_endpoint()

        # Convert http(s) to ws(s)
        ws_url = base_url.replace("https://", "wss://").replace("http://", "ws://")

        session_id = self._session_id or str(uuid.uuid4())
        url = f"{ws_url}/v2/agentic/ws/connect?session_id={session_id}"

        if self._request_id:
            url += f"&request_id={self._request_id}"

        # Include checkpoint for recovery
        if self._latest_checkpoint_id and self._ready_state == ReadyState.CHECKPOINT_RECOVERY:
            url += f"&checkpoint_id={self._latest_checkpoint_id}"

        # SDK mode: tell backend to use SDK graph
        url += "&agent_type=sdk"

        return url

    def _get_auth_token(self) -> str:
        """Get authentication token."""
        from qodo.auth import get_auth_config
        from qodo.session.environment import get_current_environment

        env = get_current_environment()
        if env.auth_provider:
            token: str = env.auth_provider.get_auth_config().token
            return token
        return get_auth_config().token

    def _handle_close(self, code: int | None, reason: str) -> None:
        """Handle connection close."""
        logger.debug(f"Connection closed: code={code}, reason={reason}")
        self._cancel_timers()

        # Normal closures don't trigger reconnect
        if code in (1000, 1001):
            self._set_state(ConnectionState.DISCONNECTED)
            return

        # Auth failure - don't reconnect
        if code == 1008:
            self._set_state(ConnectionState.FAILED)
            return

        # Unexpected closure - could reconnect
        self._set_state(ConnectionState.DISCONNECTED)

    # Timer management

    def _start_heartbeat(self) -> None:
        """Start heartbeat task."""
        self._cancel_heartbeat()

        async def heartbeat() -> None:
            interval = self._config.heartbeat_interval_ms / 1000
            while self._state == ConnectionState.CONNECTED and self._ws is not None:
                await asyncio.sleep(interval)
                if self._ws is not None:
                    try:
                        await self._ws.ping()
                    except Exception:
                        break  # connection lost: exit heartbeat loop

        self._heartbeat_task = asyncio.create_task(heartbeat())

    def _cancel_heartbeat(self) -> None:
        """Cancel heartbeat task."""
        if self._heartbeat_task:
            self._heartbeat_task.cancel()
            self._heartbeat_task = None

    def _start_idle_timer(self) -> None:
        """Start idle timeout timer."""
        self._cancel_idle_timer()

        async def idle_timeout() -> None:
            timeout = self._config.idle_timeout_ms / 1000
            await asyncio.sleep(timeout)
            logger.debug("Idle timeout reached, disconnecting")
            await self.disconnect()

        self._idle_task = asyncio.create_task(idle_timeout())

    def _reset_idle_timer(self) -> None:
        """Reset idle timer."""
        if self._state == ConnectionState.CONNECTED:
            self._start_idle_timer()

    def _cancel_idle_timer(self) -> None:
        """Cancel idle timer."""
        if self._idle_task:
            self._idle_task.cancel()
            self._idle_task = None

    def _start_ready_timer(self) -> None:
        """Start ready timeout timer."""
        self._cancel_ready_timer()

        async def ready_timeout() -> None:
            timeout = self._config.ready_timeout_ms / 1000
            await asyncio.sleep(timeout)
            logger.debug("Ready timeout reached, initiating recovery")
            await self._initiate_checkpoint_recovery("Ready timeout")

        self._ready_timer_task = asyncio.create_task(ready_timeout())

    def _cancel_ready_timer(self) -> None:
        """Cancel ready timer."""
        if self._ready_timer_task:
            self._ready_timer_task.cancel()
            self._ready_timer_task = None

    def _cancel_timers(self) -> None:
        """Cancel all timers."""
        self._cancel_idle_timer()
        self._cancel_ready_timer()
        self._cancel_heartbeat()
        if self._receiver_task:
            self._receiver_task.cancel()
            self._receiver_task = None
