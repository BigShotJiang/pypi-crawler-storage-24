"""
AgentAPI for WebSocket orchestration with the Qodo backend.

Mirrors the TypeScript SDK's AgentAPI - handles all backend communication,
tool execution, and response processing.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import uuid
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

from qodo.api.websocket import ConnectionState, ReadyState, WebSocketClient
from qodo.errors import QodoConnectionError
from qodo.session.environment import get_current_environment

logger = logging.getLogger(__name__)


# Configuration constants (matching TS SDK)
REQUEST_TIMEOUT = 210000
MAX_PENDING_TOOLS = 50
IDLE_TIMEOUT = 600000


@dataclass
class ToolData:
    """Tool data from backend response."""

    tool: str
    server_name: str | None = None
    tool_args: dict[str, Any] = field(default_factory=dict)
    tool_result: dict[str, Any] | None = None
    tool_reasoning: str | None = None
    identifier: str | None = None
    session_id: str | None = None


@dataclass
class AgentSession:
    """Agent session data."""

    session_id: str
    request_id: str
    data: dict[str, Any] = field(default_factory=dict)
    command: Any | None = None  # CommandConfig
    user_engagement_callback: Callable[[dict[str, Any]], None] | None = None
    waiting_for_response: bool = False
    last_packet_timestamp: int = 0
    abort_controller_cancelled: bool = False


@dataclass
class PendingToolData:
    """Data for a pending tool approval."""

    agent_session: AgentSession
    tool_data: ToolData


# Tool names
USER_RESPONSE = "UserResponse"
END_NODE = "EndNode"


class AgentAPI:
    """
    High-level API for agent communication with the Qodo backend.

    Mirrors the TypeScript SDK's AgentAPI:
    - Handles WebSocket connection via WebSocketClient
    - Sends UserQuery messages to backend
    - Processes responses (UserResponse, EndNode, tool calls)
    - Executes tools via MCPManager
    - Uses responseCallback pattern for message handling

    Example:
        api = AgentAPI(session_context)
        await api.start_task(agent_session)
        # ... responses flow through userEngagementCallback
        api.finish_current_task()
    """

    def __init__(self, session_context: Any | None = None) -> None:
        from qodo.mcp import MCPManager
        from qodo.session import SessionContext

        self._session_context = session_context or SessionContext.get_instance()
        self._ws_client = WebSocketClient()

        # Try to get MCPManager (may not be initialized if tools disabled)
        try:
            self._mcp_manager: MCPManager | None = MCPManager.get_instance()
        except Exception:
            self._mcp_manager = None  # MCP may not be initialized when tools are disabled

        # State
        self._current_session: AgentSession | None = None
        self._pending_tool_requests: dict[str, PendingToolData] = {}
        self._in_flight_tool_calls: set[str] = set()
        self._latest_session_id: str = ""
        self._last_tool_id: str = ""
        self._user_has_control: bool = False
        # Track async message processing to prevent race condition with Ready signal
        self._current_message_processing: asyncio.Task[None] | None = None

        # Event callbacks
        self._on_connection_state_changed: Callable[[ConnectionState], None] | None = None
        self._on_tool_requested: Callable[[ToolData, bool], None] | None = None
        self._on_tool_approved: Callable[[str, bool], None] | None = None
        self._on_tool_executed: Callable[[ToolData, dict[str, Any]], None] | None = None

        # Set up WebSocket handlers
        self._setup_websocket_handlers()

    def _should_debug_log(self) -> bool:
        """Check if debug logging is enabled."""
        env = get_current_environment()
        if env.sdk_mode:
            return env.sdk_debug or os.environ.get("QODO_DEBUG") == "true"
        return os.environ.get("QODO_DEBUG") == "true"

    def _debug(self, *args: Any) -> None:
        """Debug log if enabled."""
        if self._should_debug_log():
            logger.debug(" ".join(str(a) for a in args))

    def _setup_websocket_handlers(self) -> None:
        """Set up WebSocket event handlers."""
        # Message handler
        self._ws_client.on_message(self._handle_websocket_message)

        # State change handler
        self._ws_client.on_state_changed(self._handle_state_changed)

        # Ready received handler
        self._ws_client.on_ready_received(self._handle_ready_received)

    def _handle_websocket_message(self, message: str) -> None:
        """Handle incoming WebSocket message."""
        # Track the message processing task to prevent race condition with Ready signal
        self._current_message_processing = asyncio.create_task(self._process_message(message))

    def _handle_state_changed(self, state: ConnectionState) -> None:
        """Handle connection state change."""
        self._debug("WebSocket state changed to:", state)
        if self._on_connection_state_changed:
            self._on_connection_state_changed(state)

    def _handle_ready_received(
        self,
        checkpoint_id: str | None,
        previous_ready_state: ReadyState,
    ) -> None:
        """Handle Ready protocol message."""
        self._debug(
            "[AgentAPI] Server ready for next message",
            f"| Checkpoint: {checkpoint_id[:8]}" if checkpoint_id else "",
        )

        # Schedule the finalization check as a task that waits for message processing
        asyncio.create_task(self._finalize_if_ready(checkpoint_id, previous_ready_state))

    async def _finalize_if_ready(
        self,
        checkpoint_id: str | None,
        previous_ready_state: ReadyState,
    ) -> None:
        """
        Finalize the response if all conditions are met.

        This is called after Ready signal to handle race condition where
        structured_output messages may still be processing.
        """
        # Wait for any in-flight message processing to complete
        if self._current_message_processing is not None:
            try:
                await self._current_message_processing
            except Exception:
                # Ignore errors from message processing - they're handled elsewhere
                pass
            finally:
                self._current_message_processing = None

        # Only finalize when Ready arrives after MESSAGE_SENT
        # and there are no pending/in-flight tools
        has_responses = self._ws_client.has_received_responses_since_last_message()

        if (
            self._current_session
            and self._current_session.waiting_for_response
            and len(self._pending_tool_requests) == 0
            and len(self._in_flight_tool_calls) == 0
            and previous_ready_state == ReadyState.MESSAGE_SENT
            and has_responses
        ):
            self._current_session.waiting_for_response = False
            await self._response_callback({"forceStop": True})

    async def _ensure_connected(
        self,
        session_id: str | None = None,
        request_id: str | None = None,
    ) -> None:
        """Ensure WebSocket is connected."""
        from qodo.session.server_data import ServerData

        server_data = ServerData.get_instance()
        final_session_id = session_id

        if not final_session_id:
            if not self._latest_session_id:
                self._latest_session_id = await server_data.fetch_new_session_id()
                self._debug(f"Fetched new session ID: {self._latest_session_id}")
            final_session_id = self._latest_session_id
        else:
            self._latest_session_id = session_id or ""

        # Use base_url from ServerData to ensure WebSocket connects to the right backend
        base_url = server_data.get_base_url()
        await self._ws_client.connect(final_session_id, request_id, base_url=base_url)
        self._debug("WebSocket connected for session:", final_session_id)

    async def start_task(self, agent_session: AgentSession) -> None:
        """
        Start a new task.

        Args:
            agent_session: Session data including callback.
        """
        try:
            self._latest_session_id = agent_session.session_id
            self._current_session = agent_session

            # Ensure connected with correct session ID
            await self._ensure_connected(
                agent_session.session_id,
                agent_session.request_id,
            )

            # Send the task request
            await self._send_user_query()

        except Exception as error:
            await self._handle_error(error)

    async def resume_task(self, agent_session: AgentSession) -> None:
        """Resume an existing task."""
        await self.start_task(agent_session)

    def finish_current_task(self, is_error: bool = False) -> None:
        """Mark current task as finished."""
        # Task tracking would go here - sync method for callback compatibility
        pass

    def cancel_current_session(self) -> None:
        """Cancel the current session."""
        self._debug("Cancelling current session")
        if self._current_session:
            self._current_session.abort_controller_cancelled = True
        asyncio.create_task(self._ws_client.disconnect())

    def _get_user_data(self) -> dict[str, Any]:
        """Get user data for request (mirrors TypeScript getUserData)."""
        import platform
        import sys

        from qodo._version import __version__

        return {
            "extension_version": __version__,
            "os_platform": platform.system().lower(),
            "os_version": sys.version,
            "editor_type": "sdk",
        }

    def _get_git_sha1(self) -> str | None:
        """Get current git SHA1 (mirrors TypeScript getCurrentGitSha1)."""
        import subprocess

        try:
            cwd = self._session_context.get_execution_cwd()
            if not cwd:
                paths = self._session_context.get_accessible_paths()
                cwd = paths[0] if paths else None

            result = subprocess.run(
                ["git", "rev-parse", "HEAD"],
                cwd=cwd,
                capture_output=True,
                text=True,
                timeout=5,
            )
            if result.returncode == 0:
                return result.stdout.strip()
        except Exception:
            pass  # best-effort: git SHA retrieval should not block the request
        return None

    def _collect_base_data(self) -> dict[str, Any]:
        """Collect base data for request."""
        accessible_paths = self._session_context.get_accessible_paths()
        command = (
            self._current_session.command
            if self._current_session
            else self._session_context.get_command()
        )

        exec_cwd = self._session_context.get_execution_cwd()
        base_data: dict[str, Any] = {
            "projects_root_path": accessible_paths,
            "cwd": exec_cwd or (accessible_paths[0] if accessible_paths else ""),
        }

        # Add previous session summaries if any
        prev = self._session_context.get_previous_sessions_summarization()
        if prev:
            sections = [
                f"### Session {item.get('session_id', str(i + 1))}\n{(item.get('summary', '')).strip()}"
                for i, item in enumerate(prev)
            ]
            base_data["previous_sessions_summarization"] = "\n\n---\n\n".join(sections)

        # Add instructions
        if command and command.instructions:
            base_data["instructions"] = command.instructions
        elif self._session_context.get_general_instructions():
            base_data["instructions"] = self._session_context.get_general_instructions()

        if self._session_context.get_system_prompt():
            base_data["system_prompt"] = self._session_context.get_system_prompt()

        return base_data

    async def _send_user_query(self) -> None:
        """Send UserQuery message to backend."""
        if not self._current_session:
            return

        data = dict(self._current_session.data)
        base_data = self._collect_base_data()

        command = self._current_session.command or self._session_context.get_command()

        # Add output schema if present
        if command and command.output_schema:
            # Convert Pydantic model to dict if needed
            output_schema = command.output_schema
            if hasattr(output_schema, "model_dump"):
                output_schema = output_schema.model_dump(exclude_none=True)
            data["output_schema"] = output_schema

        # Add execution strategy
        execution_strategy = self._session_context.get_execution_strategy()
        if execution_strategy:
            data["execution_strategy"] = execution_strategy

        # Add model
        data["custom_model"] = self._session_context.get_model()

        # Build tools map
        tools = {}
        if self._mcp_manager:
            enabled_tools = self._mcp_manager.get_enabled_tools(
                self._session_context.get_available_tools(),
                self._session_context.get_ignore_tools(),
            )
            # Convert Tool objects to dicts for the backend
            for server_id, tool_list in enabled_tools.items():
                tools[server_id] = [
                    {
                        "name": t.name,
                        "description": t.description,
                        "inputSchema": t.input_schema,
                    }
                    for t in tool_list
                ]

        # Get user data (similar to TypeScript SDK's getUserData)
        user_data = self._get_user_data()

        # Get git SHA (similar to TypeScript SDK's getCurrentGitSha1)
        git_sha1 = self._get_git_sha1()

        request_data = {
            "agent_type": "sdk",
            "session_id": self._current_session.session_id,
            "user_data": user_data,
            "git_sha1": git_sha1,
            "tools": tools,
            "permissions": self._session_context.get_permissions(),
            "interactive_mode": False,  # SDK mode is non-interactive by default
            **base_data,
            **data,
        }

        self._debug(
            f"[AgentAPI] Sending UserQuery: tools={list(tools.keys())}, tool_counts={{k: len(v) for k, v in tools.items()}}"
        )
        self._current_session.waiting_for_response = True

        try:
            await self._ws_client.send_message("UserQuery", request_data)
        except Exception as error:
            logger.error(f"Error sending UserQuery: {error}")
            await self._handle_error(error)

    async def _process_message(self, message: str) -> None:
        """Process incoming WebSocket message."""
        if await self._check_cancellation():
            return

        if self._current_session:
            self._current_session.last_packet_timestamp = int(
                asyncio.get_event_loop().time() * 1000
            )

        try:
            data = json.loads(message)

            # Handle backend error envelope
            if isinstance(data, dict) and "error" in data and "message" in data:
                await self._response_callback({"error": str(data["message"])})
                if len(self._pending_tool_requests) == 0:
                    self.finish_current_task(True)
                    await self._response_callback({"forceStop": True})
                return

            await self._handle_task_response(data)

        except json.JSONDecodeError:
            pass  # non-JSON backend message; skip silently
        except Exception as error:
            raise QodoConnectionError(f"Failed to process message: {error}") from error

    async def _handle_task_response(self, response: dict[str, Any]) -> None:
        """Handle task response from backend."""
        if await self._check_cancellation():
            return

        self._debug(f"[AgentAPI] Received response: {response}")

        # Check for error response
        if response.get("type") == "error":
            error_msg = response.get("message", "Unknown error")
            await self._response_callback({"error": error_msg})
            self.finish_current_task(True)
            await self._response_callback({"forceStop": True})
            return

        # Validate response
        if not self._is_valid_task_response(response):
            self._debug(
                f"[AgentAPI] Invalid task response, skipping: session_id={response.get('session_id')}, data={response.get('data')}"
            )
            return

        tool_data = self._parse_tool_data(response.get("data", {}))

        # Ensure identifier is set
        if not tool_data.identifier:
            if tool_data.tool == USER_RESPONSE and self._last_tool_id:
                tool_data.identifier = self._last_tool_id
            else:
                tool_data.identifier = str(uuid.uuid4())
                if tool_data.tool == USER_RESPONSE:
                    self._last_tool_id = tool_data.identifier
        elif tool_data.tool != USER_RESPONSE:
            self._last_tool_id = ""

        # Route by tool type
        if tool_data.tool == USER_RESPONSE:
            await self._response_callback({"toolData": self._tool_data_to_dict(tool_data)})
        elif tool_data.tool == END_NODE:
            await self._handle_end_node()
        else:
            await self._handle_tool_execution(tool_data)

    def _is_valid_task_response(self, response: dict[str, Any]) -> bool:
        """Check if response is valid."""
        return bool(
            response.get("session_id")
            and response.get("data")
            and response.get("data", {}).get("tool")
        )

    def _parse_tool_data(self, data: dict[str, Any]) -> ToolData:
        """Parse tool data from response."""
        tool_args = data.get("tool_args", {})

        # Extract reasoning
        tool_reasoning = tool_args.pop("tool_reasoning", None)

        return ToolData(
            tool=data.get("tool", ""),
            server_name=data.get("server_name"),
            tool_args=tool_args,
            tool_result=data.get("tool_result"),
            tool_reasoning=tool_reasoning,
            identifier=data.get("identifier"),
            session_id=data.get("session_id"),
        )

    def _tool_data_to_dict(self, tool_data: ToolData) -> dict[str, Any]:
        """Convert ToolData to dict."""
        return {
            "tool": tool_data.tool,
            "server_name": tool_data.server_name,
            "tool_args": tool_data.tool_args,
            "tool_result": tool_data.tool_result,
            "tool_reasoning": tool_data.tool_reasoning,
            "identifier": tool_data.identifier,
            "session_id": tool_data.session_id,
        }

    async def _response_callback(self, response: dict[str, Any]) -> None:
        """Call the session's user engagement callback."""
        if not self._current_session:
            return
        try:
            if self._current_session.user_engagement_callback:
                self._current_session.user_engagement_callback(response)
        except Exception as error:
            logger.error(f"Error in response callback: {error}")

    async def _handle_end_node(self) -> None:
        """Handle EndNode (task complete)."""
        self.finish_current_task(False)
        await self._response_callback({"forceStop": True})

    async def _handle_tool_execution(self, tool_data: ToolData) -> None:
        """Handle tool execution request."""
        if await self._check_cancellation():
            return

        if not tool_data.server_name:
            return

        # Ensure identifier
        tool_data.identifier = tool_data.identifier or str(uuid.uuid4())
        tool_data.session_id = tool_data.session_id or (
            self._current_session.session_id if self._current_session else ""
        )

        # If tool already has result, process it
        if tool_data.tool_result:
            await self._process_tool_response(tool_data, tool_data.tool_result)
            return

        # Dry-run interception — simulate tool execution
        if (
            self._session_context
            and hasattr(self._session_context, "is_dry_run")
            and self._session_context.is_dry_run()
        ):
            from qodo.mcp.tool_processor import ToolProcessorManager

            tpm = ToolProcessorManager.get_instance()
            if tpm:
                dry_result = await tpm.dry_run_tool(
                    tool_data.tool, tool_data.server_name or "", tool_data.tool_args
                )
                await self._process_tool_response(tool_data, dry_result)
                await self._send_tool_response(tool_data, dry_result)
                return

        # Check if MCP is disabled
        if not self._mcp_manager:
            await self._handle_tool_decline(
                tool_data,
                "This agent was configured with tools disabled.",
            )
            return

        # Check auto-approval
        is_auto_approved = self._mcp_manager.is_auto_approved_tool(
            tool_data.server_name,
            tool_data.tool,
            tool_data.tool_args,
        )

        # Send tool reasoning to MessageManager (creates AIMessage with tool_calls)
        await self._process_tool_reasoning(tool_data, is_auto_approved)

        # Notify about tool request
        if self._on_tool_requested:
            self._on_tool_requested(tool_data, not is_auto_approved)

        if is_auto_approved:
            await self._call_tool(tool_data)
        else:
            # Add to pending for manual approval
            self._user_has_control = True
            assert self._current_session is not None
            self._pending_tool_requests[tool_data.identifier] = PendingToolData(
                agent_session=self._current_session,
                tool_data=tool_data,
            )

    async def tool_approval(self, identifier: str, approved: bool) -> None:
        """
        Handle tool approval decision.

        Args:
            identifier: Tool call identifier.
            approved: Whether the tool is approved.
        """
        pending = self._pending_tool_requests.get(identifier)
        if not pending:
            return

        # Notify about approval
        if self._on_tool_approved:
            self._on_tool_approved(identifier, approved)

        if approved:
            await self._call_tool(pending.tool_data)
        else:
            await self._handle_tool_decline(pending.tool_data)

        del self._pending_tool_requests[identifier]

    async def _handle_tool_decline(
        self,
        tool_data: ToolData,
        reason: str = "User declined tool execution",
    ) -> None:
        """Handle tool decline."""
        answer = {
            "isError": True,
            "content": [{"type": "text", "text": reason}],
        }
        if self._current_session:
            await self._process_tool_response(tool_data, answer)
            await self._send_tool_response(tool_data, answer)

    async def _call_tool(self, tool_data: ToolData) -> None:
        """Execute a tool call."""
        if await self._check_cancellation():
            return

        tool_call_id = tool_data.identifier or str(uuid.uuid4())
        tool_data.identifier = tool_call_id
        self._in_flight_tool_calls.add(tool_call_id)

        try:
            self._debug(f"Calling tool: {tool_data.tool} on server: {tool_data.server_name}")

            if not self._mcp_manager:
                await self._handle_tool_decline(
                    tool_data,
                    "MCP manager not available.",
                )
                return

            # Patch args with execution cwd if needed
            patched_args = dict(tool_data.tool_args)
            exec_cwd = self._session_context.get_execution_cwd()
            if exec_cwd:
                # Shell and ripgrep need cwd
                is_shell = tool_data.server_name == "shell" and tool_data.tool == "shell_execute"
                is_ripgrep = (
                    tool_data.server_name == "ripgrep" and tool_data.tool == "ripgrep_search"
                )
                if (is_shell or is_ripgrep) and "cwd" not in patched_args:
                    patched_args["cwd"] = exec_cwd

                # Git tools need repo_path
                is_git = tool_data.server_name == "git"
                if is_git and "repo_path" not in patched_args:
                    patched_args["repo_path"] = exec_cwd

            # Execute tool
            result = await self._mcp_manager.call_tool(
                tool_data.server_name or "",
                tool_data.tool,
                patched_args,
            )

            self._debug(f"Tool result: {'Error' if result.is_error else 'Success'}")

            # Format result - ToolResult has is_error (bool) and content fields
            # When there's an error, the error message is in content
            content_text = ""
            if result.content:
                # Content can be a list or string
                if isinstance(result.content, list):
                    # Extract text from content list
                    for item in result.content:
                        if isinstance(item, dict) and item.get("type") == "text":
                            content_text = item.get("text", "")
                            break
                else:
                    content_text = str(result.content)

            tool_result = {
                "isError": result.is_error,
                "content": [{"type": "text", "text": content_text}],
            }

            # Notify about execution
            if self._on_tool_executed:
                self._on_tool_executed(tool_data, tool_result)

            if self._current_session:
                await self._process_tool_response(tool_data, tool_result)
                await self._send_tool_response(tool_data, tool_result)

        except Exception as error:
            error_response = {
                "isError": True,
                "content": [{"type": "text", "text": str(error)}],
            }
            if self._current_session:
                await self._process_tool_response(tool_data, error_response)
                await self._send_tool_response(tool_data, error_response)
        finally:
            self._in_flight_tool_calls.discard(tool_call_id)

    async def _process_tool_reasoning(
        self,
        tool_data: ToolData,
        is_auto_approved: bool,
    ) -> None:
        """Send tool request to MessageManager for tracking."""
        if not self._current_session:
            return

        # Build toolData dict with pending_approval flag
        tool_dict = self._tool_data_to_dict(tool_data)
        if not is_auto_approved:
            tool_dict["pending_approval"] = True

        await self._response_callback({"toolData": tool_dict})

    async def _process_tool_response(
        self,
        tool_data: ToolData,
        result: dict[str, Any],
    ) -> None:
        """Process tool response for message tracking."""
        if not self._current_session:
            return

        # Send tool result to MessageManager
        tool_dict = self._tool_data_to_dict(tool_data)
        tool_dict["tool_result"] = result
        await self._response_callback({"toolData": tool_dict})

    async def _send_tool_response(
        self,
        tool_data: ToolData,
        result: dict[str, Any],
    ) -> None:
        """Send tool response back to backend."""
        # Build IDERetrievalAnswer format matching TypeScript SDK
        response_data = {
            "tool": tool_data.tool,
            "tool_id": tool_data.identifier,
            "answer": result,
            "tools": self._convert_tools_for_ide(),
            "user_data": self._get_user_data(),
            "agent_type": "sdk",
        }

        try:
            await self._ws_client.send_message("IDERetrievalAnswer", response_data)
        except Exception as error:
            logger.error(f"Error sending tool response: {error}")

    def _convert_tools_for_ide(self) -> dict[str, Any]:
        """Convert tools to IDE format for IDERetrievalAnswer."""
        # For IDERetrievalAnswer the backend expects a ToolType-keyed dict.
        # Use 'IDETool' with a flat array of tools.
        if not self._mcp_manager:
            return {"IDETool": []}

        enabled_tools = self._mcp_manager.get_enabled_tools(
            self._session_context.get_available_tools(),
            self._session_context.get_ignore_tools(),
        )

        # Flatten all tools from all servers into a single list
        ide_tools = []
        for _server_id, tool_list in enabled_tools.items():
            for tool in tool_list:
                ide_tools.append(
                    {
                        "name": tool.name,
                        "description": tool.description,
                        "inputSchema": tool.input_schema,
                    }
                )

        return {"IDETool": ide_tools}

    async def _check_cancellation(self) -> bool:
        """Check if current session is cancelled."""
        if self._current_session and self._current_session.abort_controller_cancelled:
            await self._handle_cancellation()
            return True
        return False

    async def _handle_cancellation(self) -> None:
        """Handle session cancellation."""
        self.finish_current_task(True)
        await self._response_callback({"forceStop": True})

    async def _handle_error(self, error: Any) -> None:
        """Handle error."""
        error_msg = str(error) if error else "Unknown error"
        await self._response_callback({"error": error_msg})
        self.finish_current_task(True)
        await self._response_callback({"forceStop": True})

    # Event registration

    def on_connection_state_changed(
        self,
        callback: Callable[[ConnectionState], None],
    ) -> None:
        """Register connection state change callback."""
        self._on_connection_state_changed = callback

    def on_tool_requested(
        self,
        callback: Callable[[ToolData, bool], None],
    ) -> None:
        """Register tool requested callback. Args: (tool_data, pending_approval)"""
        self._on_tool_requested = callback

    def on_tool_approved(
        self,
        callback: Callable[[str, bool], None],
    ) -> None:
        """Register tool approved callback. Args: (identifier, approved)"""
        self._on_tool_approved = callback

    def on_tool_executed(
        self,
        callback: Callable[[ToolData, dict[str, Any]], None],
    ) -> None:
        """Register tool executed callback. Args: (tool_data, result)"""
        self._on_tool_executed = callback

    # Properties

    @property
    def session_id(self) -> str:
        """Get current session ID."""
        return self._latest_session_id

    @property
    def has_pending_tools(self) -> bool:
        """Check if there are pending tool approvals."""
        return bool(self._pending_tool_requests)

    @property
    def pending_tool_ids(self) -> list[str]:
        """Get list of pending tool IDs."""
        return list(self._pending_tool_requests.keys())

    def remove_all_listeners(self) -> None:
        """Remove all event listeners."""
        self._on_connection_state_changed = None
        self._on_tool_requested = None
        self._on_tool_approved = None
        self._on_tool_executed = None

    async def cleanup(self) -> None:
        """Clean up resources."""
        await self._ws_client.cleanup()
        self._pending_tool_requests.clear()
        self._in_flight_tool_calls.clear()
        self.remove_all_listeners()
