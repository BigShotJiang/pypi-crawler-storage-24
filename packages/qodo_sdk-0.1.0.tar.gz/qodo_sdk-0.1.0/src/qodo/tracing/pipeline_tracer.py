"""Pipeline tracing with OpenTelemetry spans."""

from __future__ import annotations

from typing import Any

from qodo.sdk.pipeline.builder import Pipeline
from qodo.sdk.pipeline.runner import run_pipeline
from qodo.sdk.pipeline.types import PipelineResult
from qodo.tracing.types import OTelAPI, SpanKind, SpanStatus, SpanStatusCode


async def trace_pipeline(
    otel: OTelAPI,
    sdk: Any,  # QodoSDK instance
    pipeline: Pipeline,
    initial_state: dict[str, Any] | None = None,
) -> PipelineResult:
    """Run a pipeline with OpenTelemetry tracing."""
    pipeline_name = getattr(pipeline, "name", "unnamed")
    span = otel.tracer.start_span(  # type: ignore[attr-defined]
        f"qodo.pipeline {pipeline_name}",
        attributes={"qodo.pipeline.name": pipeline_name},
        kind=SpanKind.CLIENT,
    )
    try:
        result = await run_pipeline(sdk, pipeline, initial_state or {})
        if all(s.status != "error" for s in result.steps):
            span.set_status(SpanStatus(SpanStatusCode.OK))
        else:
            span.set_status(SpanStatus(SpanStatusCode.ERROR, "Pipeline had errors"))
        return result
    except Exception as exc:
        span.record_exception(exc)
        span.set_status(SpanStatus(SpanStatusCode.ERROR, str(exc)))
        raise
    finally:
        span.end()
