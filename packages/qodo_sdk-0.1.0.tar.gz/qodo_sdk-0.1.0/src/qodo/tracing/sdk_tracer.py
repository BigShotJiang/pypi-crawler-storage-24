"""SDK event-to-span adapter for OpenTelemetry — matches the TypeScript SdkTracer."""

from __future__ import annotations

from collections.abc import AsyncGenerator
from dataclasses import dataclass
from typing import Any

from qodo.sdk.events import QodoSdkEvent, SdkEventType
from qodo.tracing.types import OTelAPI, OTelContext, OTelSpan


@dataclass
class SdkTracerOptions:
    """Options for :class:`SdkTracer`.

    Attributes:
        tracer_name: Passed to ``otel.trace.get_tracer()``.  Defaults to
            ``"@qodo/sdk"`` (matching the TS SDK).
        tracer_version: Optional version passed to ``get_tracer()``.
        root_attributes: Extra attributes merged into every run root span.
    """

    tracer_name: str | None = None
    tracer_version: str | None = None
    root_attributes: dict[str, Any] | None = None


@dataclass
class _RunEntry:
    """Internal bookkeeping for an in-flight run."""

    span: OTelSpan
    context: OTelContext


class SdkTracer:
    """Translates ``QodoSdkEvent`` events into OpenTelemetry spans.

    Supports concurrent runs (keyed by ``run_id``) and concurrent tool
    invocations (keyed by ``{run_id}:{tool_call_id}``).
    """

    def __init__(self, otel: OTelAPI, options: SdkTracerOptions | None = None) -> None:
        self._otel = otel
        self._options = options or SdkTracerOptions()
        self._tracer = otel.trace.get_tracer(
            self._options.tracer_name or "@qodo/sdk",
            self._options.tracer_version,
        )
        # run_id -> { span, context }
        self._run_spans: dict[str, _RunEntry] = {}
        # "{run_id}:{tool_call_id}" -> span
        self._tool_spans: dict[str, OTelSpan] = {}

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def on_event(self, event: QodoSdkEvent) -> None:
        """Route an SDK event to the appropriate span handler."""
        handlers = {
            SdkEventType.RUN_STARTED: self._handle_run_started,
            SdkEventType.TOOL_REQUESTED: self._handle_tool_requested,
            SdkEventType.TOOL_APPROVED: self._handle_tool_approved,
            SdkEventType.TOOL_EXECUTED: self._handle_tool_executed,
            SdkEventType.ERROR: self._handle_error,
            SdkEventType.FINAL: self._handle_final,
            # INIT, MESSAGE_DELTA, MESSAGE_FULL, PROGRESS are ignored
        }
        handler = handlers.get(event.type)
        if handler:
            handler(event)

    async def wrap_stream(
        self, stream: AsyncGenerator[QodoSdkEvent, None]
    ) -> AsyncGenerator[QodoSdkEvent, None]:
        """Wrap an async event stream, calling ``on_event`` for each event.

        Has a ``try / finally`` block that calls :meth:`flush` on exit
        (matching the TS ``wrapStream``).
        """
        try:
            async for event in stream:
                self.on_event(event)
                yield event
        finally:
            self.flush()

    def flush(self) -> None:
        """End any orphaned spans with error status.

        The orphan message is ``'orphaned'`` (lowercase) matching the TS SDK.
        """
        status_code = self._otel.SpanStatusCode

        for _key, span in list(self._tool_spans.items()):
            span.set_status({"code": status_code.ERROR, "message": "orphaned"})
            span.end()
        self._tool_spans.clear()

        for _run_id, entry in list(self._run_spans.items()):
            entry.span.set_status({"code": status_code.ERROR, "message": "orphaned"})
            entry.span.end()
        self._run_spans.clear()

    # ------------------------------------------------------------------
    # Event handlers
    # ------------------------------------------------------------------

    def _handle_run_started(self, event: QodoSdkEvent) -> None:
        data = event.data
        run_id = event.run_id
        command = getattr(data, "command", "") or ""
        prompt_mode = getattr(data, "prompt_mode", False)

        name = f"qodo.run {command}" if command else "qodo.run prompt"

        attrs: dict[str, Any] = {
            "qodo.run_id": run_id,
            "qodo.session_id": getattr(data, "session_id", ""),
            "qodo.command": command or "(prompt)",
            "qodo.prompt_mode": prompt_mode,
            "qodo.tools_auto_approved": getattr(data, "tools_auto_approved", False),
            "qodo.cwd": getattr(data, "cwd", ""),
        }

        agent = getattr(data, "agent", None)
        if agent:
            source = (
                agent.get("source") if isinstance(agent, dict) else getattr(agent, "source", None)
            )
            if source:
                attrs["qodo.agent.source"] = source
            path = agent.get("path") if isinstance(agent, dict) else getattr(agent, "path", None)
            if path:
                attrs["qodo.agent.path"] = path

        dry_run = getattr(data, "dry_run", None)
        if dry_run:
            attrs["qodo.dry_run"] = True

        # Apply root_attributes from options
        if self._options.root_attributes:
            attrs.update(self._options.root_attributes)

        span = self._tracer.start_span(name, {"attributes": attrs})
        ctx = self._otel.trace.set_span(self._otel.context.active(), span)
        self._run_spans[run_id] = _RunEntry(span=span, context=ctx)

    def _handle_tool_requested(self, event: QodoSdkEvent) -> None:
        run_id = event.run_id
        parent = self._run_spans.get(run_id)
        if not parent:
            return

        data = event.data
        tool_call_id = getattr(data, "tool_call_id", "")
        server_name = getattr(data, "server_name", "")
        tool_name = getattr(data, "tool_name", "")

        tool_key = f"{run_id}:{tool_call_id}"

        attrs: dict[str, Any] = {
            "qodo.tool.call_id": tool_call_id,
            "qodo.tool.server_name": server_name,
            "qodo.tool.name": tool_name,
            "qodo.tool.pending_approval": getattr(data, "pending_approval", False),
        }

        reasoning = getattr(data, "reasoning", None)
        if reasoning:
            attrs["qodo.tool.reasoning"] = reasoning[:500]

        span = self._tracer.start_span(
            f"tool {server_name}/{tool_name}",
            {"attributes": attrs},
            parent.context,
        )
        self._tool_spans[tool_key] = span

    def _handle_tool_approved(self, event: QodoSdkEvent) -> None:
        data = event.data
        run_id = event.run_id
        tool_call_id = getattr(data, "tool_call_id", "")
        tool_key = f"{run_id}:{tool_call_id}"

        span = self._tool_spans.get(tool_key)
        if not span:
            return

        approved = getattr(data, "approved", False)
        span.set_attribute("qodo.tool.approved", approved)

        reason = getattr(data, "reason", None)
        if reason:
            span.set_attribute("qodo.tool.approval_reason", reason)

        if not approved:
            # Declined is OK with message 'declined', NOT ERROR
            status_code = self._otel.SpanStatusCode
            span.set_status({"code": status_code.OK, "message": "declined"})
            span.end()
            del self._tool_spans[tool_key]

    def _handle_tool_executed(self, event: QodoSdkEvent) -> None:
        data = event.data
        run_id = event.run_id
        tool_call_id = getattr(data, "tool_call_id", "")
        tool_key = f"{run_id}:{tool_call_id}"

        span = self._tool_spans.pop(tool_key, None)
        if not span:
            return

        result = getattr(data, "result", {})
        is_error = result.get("isError", False) if isinstance(result, dict) else False

        span.set_attribute("qodo.tool.is_error", is_error)

        dry_run = getattr(data, "dry_run", None)
        if dry_run:
            span.set_attribute("qodo.tool.dry_run", True)

        status_code = self._otel.SpanStatusCode

        if is_error:
            content = ""
            if isinstance(result, dict):
                content = str(result.get("content", ""))
            span.set_status({"code": status_code.ERROR, "message": content[:500]})
            span.record_exception(content[:1000])
        else:
            span.set_status({"code": status_code.OK})

        span.end()

    def _handle_error(self, event: QodoSdkEvent) -> None:
        run_id = event.run_id
        entry = self._run_spans.get(run_id)
        if not entry:
            return
        data = event.data
        message = getattr(data, "message", "unknown error")
        entry.span.record_exception(message)
        entry.span.add_event("sdk.error", {"error.message": message})

    def _handle_final(self, event: QodoSdkEvent) -> None:
        run_id = event.run_id
        entry = self._run_spans.pop(run_id, None)
        if not entry:
            return

        data = event.data
        success = getattr(data, "success", False)
        meta = getattr(data, "meta", {}) or {}
        model = getattr(data, "model", None)
        error = getattr(data, "error", None)

        span = entry.span
        span.set_attribute("qodo.success", success)

        if model:
            span.set_attribute("qodo.model", model)

        if meta.get("timed_out"):
            span.set_attribute("qodo.timed_out", True)

        if meta.get("dry_run"):
            span.set_attribute("qodo.dry_run", True)

        status_code = self._otel.SpanStatusCode

        if success:
            span.set_status({"code": status_code.OK})
        else:
            span.set_status({"code": status_code.ERROR, "message": error or "Run failed"})
            if error:
                span.record_exception(error)

        span.end()


def create_sdk_tracer(otel: OTelAPI, options: SdkTracerOptions | None = None) -> SdkTracer:
    """Factory function to create an SdkTracer."""
    return SdkTracer(otel, options)
