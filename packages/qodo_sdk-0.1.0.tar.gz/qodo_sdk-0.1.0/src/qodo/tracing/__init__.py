"""OpenTelemetry tracing adapter for the Qodo SDK."""

from qodo.tracing.pipeline_helpers import (
    execute_parallel_group_with_tracing,
    execute_step_with_tracing,
)
from qodo.tracing.pipeline_tracer import trace_pipeline
from qodo.tracing.sdk_tracer import SdkTracer, SdkTracerOptions, create_sdk_tracer
from qodo.tracing.types import (
    OTelAPI,
    OTelContext,
    OTelContextAPI,
    OTelSpan,
    OTelTraceAPI,
    OTelTracer,
    SpanKind,
    SpanStatus,
    SpanStatusCode,
)

__all__ = [
    "SdkTracer",
    "SdkTracerOptions",
    "create_sdk_tracer",
    "trace_pipeline",
    "execute_step_with_tracing",
    "execute_parallel_group_with_tracing",
    "OTelAPI",
    "OTelContext",
    "OTelContextAPI",
    "OTelSpan",
    "OTelTraceAPI",
    "OTelTracer",
    "SpanKind",
    "SpanStatus",
    "SpanStatusCode",
]
