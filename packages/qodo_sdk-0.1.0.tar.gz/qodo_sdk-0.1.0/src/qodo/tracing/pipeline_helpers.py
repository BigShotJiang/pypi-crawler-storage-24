"""Pipeline step execution helpers with tracing."""

from __future__ import annotations

import asyncio
from typing import Any

from qodo.sdk.pipeline.types import ParallelGroup, PipelineStep, StepContext
from qodo.tracing.types import OTelAPI, SpanKind, SpanStatus, SpanStatusCode


async def execute_step_with_tracing(
    otel: OTelAPI,
    step: PipelineStep,
    context: StepContext,
) -> dict[str, Any]:
    """Execute a pipeline step with OTel span wrapping."""
    span = otel.tracer.start_span(  # type: ignore[attr-defined]
        f"qodo.pipeline.step {step.name}",
        attributes={"qodo.step.name": step.name},
        kind=SpanKind.INTERNAL,
    )
    try:
        result = await step.fn(context)
        span.set_status(SpanStatus(SpanStatusCode.OK))
        return result
    except Exception as exc:
        span.record_exception(exc)
        span.set_status(SpanStatus(SpanStatusCode.ERROR, str(exc)))
        raise
    finally:
        span.end()


async def execute_parallel_group_with_tracing(
    otel: OTelAPI,
    group: ParallelGroup,
    context: StepContext,
) -> None:
    """Execute a parallel group with OTel span wrapping."""
    span = otel.tracer.start_span(  # type: ignore[attr-defined]
        "qodo.pipeline.parallel",
        kind=SpanKind.INTERNAL,
    )
    try:
        tasks = [step.fn(context) for step in group.steps]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        errors = [r for r in results if isinstance(r, Exception)]
        if errors:
            for err in errors:
                span.record_exception(err)
            span.set_status(SpanStatus(SpanStatusCode.ERROR, f"{len(errors)} step(s) failed"))
        else:
            span.set_status(SpanStatus(SpanStatusCode.OK))
    except Exception as exc:
        span.record_exception(exc)
        span.set_status(SpanStatus(SpanStatusCode.ERROR, str(exc)))
        raise
    finally:
        span.end()
