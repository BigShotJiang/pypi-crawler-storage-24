"""Protocol-based OpenTelemetry API types matching the TypeScript SDK structure.

The primary API surface matches the TS SDK's OTel interfaces:
  - OTelSpan, OTelContext, OTelTracer, OTelContextAPI, OTelTraceAPI, OTelAPI

Legacy aliases (SpanKind, SpanStatus, SpanStatusCode) are retained for backward
compatibility with the pipeline tracing helpers.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any, Protocol, runtime_checkable

# ---------------------------------------------------------------------------
# New TS-matching protocol types
# ---------------------------------------------------------------------------


@runtime_checkable
class OTelSpan(Protocol):
    """Protocol for OpenTelemetry Span — mirrors the TS ``OTelSpan`` interface."""

    def set_attribute(self, key: str, value: Any) -> Any: ...
    def set_status(self, status: dict[str, Any]) -> Any: ...
    def record_exception(self, exception: Any) -> None: ...
    def add_event(self, name: str, attributes: dict[str, Any] | None = None) -> Any: ...
    def end(self, end_time: int | None = None) -> None: ...


@runtime_checkable
class OTelContext(Protocol):
    """Opaque context type — mirrors the TS ``OTelContext`` interface."""

    ...


@runtime_checkable
class OTelContextAPI(Protocol):
    """Protocol for the OpenTelemetry Context API — mirrors TS ``OTelContextAPI``."""

    def active(self) -> OTelContext: ...


@runtime_checkable
class OTelTracer(Protocol):
    """Protocol for OpenTelemetry Tracer — mirrors TS ``OTelTracer``.

    ``start_span`` accepts an optional *options* dict (with ``attributes`` and
    ``start_time`` keys) and an optional *context* for parent propagation.
    """

    def start_span(
        self,
        name: str,
        options: dict[str, Any] | None = None,
        context: OTelContext | None = None,
    ) -> OTelSpan: ...


@runtime_checkable
class OTelTraceAPI(Protocol):
    """Protocol for the OpenTelemetry Trace API — mirrors TS ``OTelTraceAPI``."""

    def set_span(self, context: OTelContext, span: OTelSpan) -> OTelContext: ...
    def get_tracer(self, name: str, version: str | None = None) -> OTelTracer: ...


@runtime_checkable
class OTelAPI(Protocol):
    """The full OTel API surface the adapter needs — mirrors TS ``OTelAPI``.

    Attributes:
        trace: The Trace API (``get_tracer``, ``set_span``).
        context: The Context API (``active``).
        SpanStatusCode: An object with numeric ``OK`` and ``ERROR`` attributes.
    """

    trace: OTelTraceAPI
    context: OTelContextAPI
    SpanStatusCode: Any  # Has .OK (int) and .ERROR (int) attributes


# ---------------------------------------------------------------------------
# Legacy types — kept for backward compatibility with pipeline_helpers /
# pipeline_tracer which are *not* being rewritten in this change.
# ---------------------------------------------------------------------------


class SpanStatusCode(Enum):
    UNSET = 0
    OK = 1
    ERROR = 2


@dataclass
class SpanStatus:
    code: SpanStatusCode
    description: str | None = None


class SpanKind(Enum):
    INTERNAL = 0
    SERVER = 1
    CLIENT = 2
    PRODUCER = 3
    CONSUMER = 4
