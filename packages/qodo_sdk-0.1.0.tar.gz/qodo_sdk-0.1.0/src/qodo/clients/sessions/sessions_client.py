"""
QodoSessionsClient for session management.

Provides methods to list, retrieve, and manage session history.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class SessionMessage:
    """A single message in a session."""

    role: str
    content: Any


@dataclass
class RecentSession:
    """Summary of a recent session."""

    session_id: str
    last_update: int  # Unix timestamp
    description: str = ""


@dataclass
class SessionHistory:
    """Full session history."""

    session_id: str
    messages: list[SessionMessage] = field(default_factory=list)
    raw: dict[str, Any] | None = None


@dataclass
class QodoSessionsClientOptions:
    """Options for QodoSessionsClient."""

    base_url_override: str | None = None


class QodoSessionsClient:
    """
    Client for session history management.

    Provides methods to list recent sessions, retrieve full session
    history, and create new sessions.

    Example:
        sessions = QodoSessionsClient()

        # List recent sessions
        recent = await sessions.list_recent(limit=10)
        for session in recent:
            print(f"{session.session_id}: {session.last_update}")

        # Get full session history
        history = await sessions.get("session-id")
        for msg in history.messages:
            print(f"{msg.role}: {msg.content}")
    """

    def __init__(self, options: QodoSessionsClientOptions | None = None) -> None:
        self._options = options or QodoSessionsClientOptions()
        self._cached_recent: list[RecentSession] | None = None
        self._initialized: bool = False

    async def _ensure_initialized(self) -> None:
        """Ensure ServerData is initialized for backend access."""
        if self._initialized:
            return

        from qodo.session.server_data import ServerData

        await ServerData.init(self._options.base_url_override)
        self._initialized = True

    async def list_recent(
        self,
        *,
        limit: int = 10,
        force_refresh: bool = False,
    ) -> list[RecentSession]:
        """
        Get recent sessions.

        Args:
            limit: Maximum number of sessions to return.
            force_refresh: If True, bypass cache and fetch fresh data.

        Returns:
            List of recent sessions sorted by last_update (most recent first).
        """
        await self._ensure_initialized()

        from qodo.session.server_data import ServerData

        server_data = ServerData.get_instance()

        if force_refresh:
            # Fetch fresh data from backend
            await server_data.get_things("recent-sessions")

        # Get recent sessions from server data
        sessions = server_data.get_recent_sessions()

        # Sort by last_update descending and limit
        sorted_sessions = sorted(
            sessions,
            key=lambda s: s.last_update,
            reverse=True,
        )

        # Convert to our dataclass format
        result = [
            RecentSession(
                session_id=s.session_id,
                last_update=s.last_update,
                description=s.description,
            )
            for s in sorted_sessions[: max(0, limit)]
        ]

        self._cached_recent = result
        return result

    async def create_session_id(self) -> str:
        """
        Create a new backend session ID.

        Returns:
            A new unique session ID from the backend.
        """
        await self._ensure_initialized()

        from qodo.session.server_data import ServerData

        server_data = ServerData.get_instance()
        return await server_data.fetch_new_session_id()

    async def get(self, session_id: str) -> SessionHistory:
        """
        Fetch full session history.

        Args:
            session_id: The session ID to fetch.

        Returns:
            SessionHistory with all messages.

        Raises:
            Exception: If session not found or fetch fails.
        """
        await self._ensure_initialized()

        from qodo.api.http import http_post
        from qodo.session.server_data import ServerData

        server_data = ServerData.get_instance()

        # Make request to get-session endpoint
        payload = {
            "agent_type": "sdk",
            "session_id": session_id,
            "projects_root_path": [],
            "cwd": "",
            "tools": {},
        }

        try:
            response = await http_post(
                "/v2/agentic/get-session",
                data=payload,
                base_url=server_data.get_base_url(),
                timeout_ms=210000,
            )
        except Exception as e:
            raise Exception(f"Failed to fetch session history: {e}") from e

        if not response:
            raise Exception("No session history found")

        # Check for session not found error
        if (
            isinstance(response, dict)
            and response.get("type") == "answer"
            and response.get("sub_type") == "session-not-found"
            and response.get("data", {}).get("message")
        ):
            raise Exception(response["data"]["message"])

        # Check for other errors
        if isinstance(response, dict) and (response.get("error") or response.get("error_code")):
            raise Exception(response.get("message") or response.get("error") or "Unknown error")

        # Normalize messages
        messages = self._normalize_messages(response.get("messages", []))

        return SessionHistory(
            session_id=session_id,
            messages=messages,
            raw=response,
        )

    async def get_messages(self, session_id: str) -> list[SessionMessage]:
        """
        Fetch only the messages from a session.

        Args:
            session_id: The session ID to fetch.

        Returns:
            List of messages in the session.
        """
        history = await self.get(session_id)
        return history.messages

    def _normalize_messages(self, messages: Any) -> list[SessionMessage]:
        """
        Normalize raw message data to SessionMessage objects.

        Handles various message formats from the backend.
        """
        if not isinstance(messages, list):
            return []

        result = []
        for msg in messages:
            if isinstance(msg, dict):
                role = msg.get("role", "unknown")
                content = msg.get("content") or msg.get("text") or msg
            else:
                role = "unknown"
                content = msg

            result.append(SessionMessage(role=str(role), content=content))

        return result
