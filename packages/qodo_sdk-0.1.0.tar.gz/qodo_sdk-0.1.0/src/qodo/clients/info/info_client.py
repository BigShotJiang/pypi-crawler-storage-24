"""
QodoInfoClient for backend information.

Provides access to backend information such as available models,
default model, version, and rate limits.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class RateLimitInfo:
    """Rate limit information from the backend."""

    remaining: int | None = None
    reset: int | None = None
    limit: int | None = None


@dataclass
class QodoBackendInfo:
    """Comprehensive backend information."""

    base_url: str
    base_url_source: str  # 'user' | 'server' | 'default'
    version: str
    session_id: str
    default_model: str | None = None
    available_models: list[str] | None = None
    rate_limit: RateLimitInfo | None = None


class QodoInfoClient:
    """
    Client for backend information.

    Provides methods to fetch available models, default model,
    and other backend configuration.

    Example:
        info = QodoInfoClient()
        models = await info.get_available_models()
        print(f"Available models: {models}")

        default = await info.get_default_model()
        print(f"Default model: {default}")
    """

    def __init__(self) -> None:
        self._cached_info: QodoBackendInfo | None = None

    async def get_things(self, *, force_refresh: bool = False) -> QodoBackendInfo:
        """
        Get comprehensive backend information.

        Args:
            force_refresh: If True, bypass cache and fetch fresh data.

        Returns:
            QodoBackendInfo with all backend details.
        """
        if self._cached_info is not None and not force_refresh:
            return self._cached_info

        # TODO: Implement actual backend call
        # For now return placeholder
        self._cached_info = QodoBackendInfo(
            base_url="https://api.ng.command.qodo.ai",
            base_url_source="default",
            version="1.0.0",
            session_id="placeholder-session-id",
            default_model="gpt-4",
            available_models=["gpt-4", "gpt-3.5-turbo", "claude-3-opus"],
            rate_limit=RateLimitInfo(remaining=100, limit=100),
        )
        return self._cached_info

    async def get_available_models(self, *, force_refresh: bool = False) -> list[str]:
        """
        Get list of available models.

        Args:
            force_refresh: If True, bypass cache and fetch fresh data.

        Returns:
            List of available model names.
        """
        info = await self.get_things(force_refresh=force_refresh)
        return info.available_models or []

    async def get_default_model(self, *, force_refresh: bool = False) -> str | None:
        """
        Get the default model.

        Args:
            force_refresh: If True, bypass cache and fetch fresh data.

        Returns:
            The default model name, or None if not set.
        """
        info = await self.get_things(force_refresh=force_refresh)
        return info.default_model
