"""
Authentication handling for the Qodo SDK.

Manages API key validation from environment variables or configuration files.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Literal

from qodo.errors import QodoAuthError

# API endpoint constants
ENDPOINT_PRODUCTION = "https://api.ng.command.qodo.ai"
ENDPOINT_BETA = "https://api.ng.beta.command.qodo.ai"
ENDPOINT_LOCAL = "http://0.0.0.0:5432"
ENDPOINT_DEFAULT = ENDPOINT_PRODUCTION


@dataclass
class AuthConfig:
    """Authentication configuration containing token and its source."""

    token: str
    source: Literal["env", "file"]


# ---------------------------------------------------------------------------
# AuthProvider — environment-scoped auth state
# ---------------------------------------------------------------------------


class AuthProvider:
    """
    Encapsulates API-key resolution and validation as an instance so that
    multiple QodoSDK instances (each running in its own contextvars
    environment) can hold independent auth state without polluting module-level
    variables or os.environ.
    """

    def __init__(self, api_key: str | None = None) -> None:
        self._key: str | None = None
        self._key_source: Literal["env", "file"] = "env"

        if api_key:
            self._key = api_key
            self._key_source = "env"  # treat explicit key same as env-provided
            return

        # Read from environment (but NEVER mutate os.environ)
        env_key = os.environ.get("QODO_API_KEY")
        if env_key:
            self._key = env_key
            self._key_source = "env"

    def validate(self) -> None:
        """
        Validate that a key is available. Tries ~/.qodo/auth.key if not in env.

        Raises:
            QodoAuthError: If no valid key found.
        """
        if self._key:
            return

        # Try reading from auth file
        try:
            home = Path.home()
            auth_file = home / ".qodo" / "auth.key"
            if auth_file.exists():
                file_key = auth_file.read_text().strip()
                if file_key:
                    self._key = file_key
                    self._key_source = "file"
        except (OSError, PermissionError):
            # File read errors are non-fatal, will raise below if no key
            pass

        if not self._key:
            raise QodoAuthError(
                "Qodo API key not found. "
                "Set the QODO_API_KEY environment variable or create ~/.qodo/auth.key"
            )

    def get_auth_config(self) -> AuthConfig:
        """Return the current authentication configuration."""
        return AuthConfig(token=self._key or "", source=self._key_source)

    def handle_401_error(self) -> None:
        """
        Handle 401 authentication errors by raising QodoAuthError.

        Raises:
            QodoAuthError: Always raises with appropriate message.
        """
        if self._key_source == "env":
            msg = "Invalid API key. Please check your QODO_API_KEY environment variable."
        else:
            msg = "Invalid API key stored in ~/.qodo/auth.key"
        raise QodoAuthError(msg)


# ---------------------------------------------------------------------------
# Legacy free functions — kept for backward compatibility (CLI / non-SDK paths)
# ---------------------------------------------------------------------------

# Module-level state for auth config
_auth_config: AuthConfig | None = None


def validate_key() -> None:
    """
    Validate and load the API key from environment or file.

    Checks for API key in the following order:
    1. QODO_API_KEY environment variable
    2. ~/.qodo/auth.key file

    Raises:
        QodoAuthError: If no valid API key is found.
    """
    global _auth_config

    # Check environment variable first
    env_key = os.environ.get("QODO_API_KEY")
    if env_key:
        _auth_config = AuthConfig(token=env_key.strip(), source="env")
        return

    # Try to read from auth file
    try:
        home = Path.home()
        auth_file = home / ".qodo" / "auth.key"
        if auth_file.exists():
            file_key = auth_file.read_text().strip()
            if file_key:
                _auth_config = AuthConfig(token=file_key, source="file")
                return
    except (OSError, PermissionError):
        # File read errors are non-fatal
        pass

    # No key found
    raise QodoAuthError(
        "Qodo API key not found. "
        "Set the QODO_API_KEY environment variable or create ~/.qodo/auth.key"
    )


def get_auth_config() -> AuthConfig:
    """
    Get the current authentication configuration.

    Returns:
        AuthConfig with token and source.

    Raises:
        QodoAuthError: If validate_key() hasn't been called and no key is available.
    """
    global _auth_config

    if _auth_config is not None:
        return _auth_config

    # Try to load if not yet validated
    validate_key()
    assert _auth_config is not None
    return _auth_config


def handle_401_error() -> None:
    """
    Handle 401 authentication errors by raising QodoAuthError.

    Provides helpful error message based on where the API key came from.

    Raises:
        QodoAuthError: Always raises with appropriate message.
    """
    try:
        auth_config = get_auth_config()
        if auth_config.source == "env":
            msg = "Invalid API key. Please check your QODO_API_KEY environment variable."
        else:
            msg = "Invalid API key stored in ~/.qodo/auth.key"
    except QodoAuthError:
        msg = "Authentication failed. No API key configured."

    raise QodoAuthError(msg)


def is_beta_version() -> bool:
    """
    Check if the current SDK version is a beta release.

    Returns:
        True if the version string contains '-beta'.
    """
    from qodo._version import __version__

    return "-beta" in __version__


def get_api_endpoint() -> str:
    """
    Get the API endpoint URL.

    Priority:
    1. QODO_API_BASE_URL environment variable (if set)
    2. Beta endpoint (if running beta version)
    3. Production endpoint (default)

    Returns:
        The API endpoint URL.
    """
    # Check for explicit override
    custom_endpoint = os.environ.get("QODO_API_BASE_URL")
    if custom_endpoint:
        return custom_endpoint

    # Use beta endpoint for beta versions
    if is_beta_version():
        return ENDPOINT_BETA

    return ENDPOINT_PRODUCTION


def should_display_endpoint() -> bool:
    """
    Check if the current endpoint should be displayed to the user.

    Returns:
        True if not using the production endpoint.
    """
    return get_api_endpoint() != ENDPOINT_PRODUCTION


def get_endpoint_display_message() -> str | None:
    """
    Get a message describing the current endpoint, if non-standard.

    Returns:
        A message string if using a non-production endpoint, None otherwise.
    """
    if not should_display_endpoint():
        return None

    endpoint = get_api_endpoint()
    if endpoint == ENDPOINT_BETA:
        return f"Using beta endpoint: {endpoint}"

    return f"Using custom endpoint: {endpoint}"


def reset_auth() -> None:
    """
    Reset the authentication state.

    Useful for testing or when the API key changes.
    """
    global _auth_config
    _auth_config = None
