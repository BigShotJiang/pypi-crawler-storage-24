"""Authentication handling."""

from qodo.auth.auth import (
    ENDPOINT_BETA,
    ENDPOINT_DEFAULT,
    ENDPOINT_LOCAL,
    ENDPOINT_PRODUCTION,
    AuthConfig,
    AuthProvider,
    get_api_endpoint,
    get_auth_config,
    get_endpoint_display_message,
    handle_401_error,
    is_beta_version,
    reset_auth,
    should_display_endpoint,
    validate_key,
)

__all__ = [
    "AuthConfig",
    "AuthProvider",
    "ENDPOINT_BETA",
    "ENDPOINT_DEFAULT",
    "ENDPOINT_LOCAL",
    "ENDPOINT_PRODUCTION",
    "get_api_endpoint",
    "get_auth_config",
    "get_endpoint_display_message",
    "handle_401_error",
    "is_beta_version",
    "reset_auth",
    "should_display_endpoint",
    "validate_key",
]
