"""
Pydantic models for Qodo configuration types.

These models mirror the TypeScript SDK's configuration types for
agent.toml/agent.yaml files and provide runtime validation.
"""

from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field


class MCPConfig(BaseModel):
    """
    MCP server configuration.

    Can specify either a command-based (stdio) or URL-based (HTTP/SSE) server.

    Example (stdio):
        MCPConfig(
            command="python",
            args=["-m", "my_mcp_server"],
            env={"DEBUG": "true"}
        )

    Example (HTTP):
        MCPConfig(
            url="https://mcp.example.com/api",
            headers={"Authorization": "Bearer token"}
        )
    """

    model_config = ConfigDict(extra="allow")

    id: str | None = None
    type: str | None = None
    command: str | None = None
    url: str | None = None
    args: list[str] | None = None
    env: dict[str, str] | None = None
    headers: dict[str, str] | None = None


class CommandArgument(BaseModel):
    """
    Command argument definition.

    Defines a single argument for a command, including its type,
    whether it's required, and optional default value.
    """

    name: str
    type: Literal["string", "number", "boolean", "array", "object"] = "string"
    required: bool = True
    description: str = ""
    default: Any | None = None


class OutputSchema(BaseModel):
    """
    Structured output schema definition.

    Wraps a JSON schema for structured output validation.
    The schema is sent to the backend to enforce output format.
    """

    type: Literal["json_schema"] = "json_schema"
    json_schema: dict[str, Any] = Field(default_factory=dict)


class CommandConfig(BaseModel):
    """
    Command definition within an agent configuration.

    Commands are named entry points that can be invoked via sdk.run("command_name").
    They can have arguments, output schemas, and tool restrictions.

    Example:
        CommandConfig(
            name="review",
            description="Review code for issues",
            instructions="Analyze the code carefully...",
            available_tools=["filesystem", "git"],
            permissions="r",
        )
    """

    model_config = ConfigDict(extra="allow")

    name: str | None = None
    description: str | None = None
    instructions: str | None = None
    available_tools: list[str] | None = None
    ignore_tools: list[str] | None = None
    disable_mcp: bool | None = None
    model: str | None = None
    arguments: list[CommandArgument] | None = None
    mcp_servers: dict[str, MCPConfig] | None = None
    output_schema: str | OutputSchema | dict[str, Any] | None = None
    exit_expression: str | None = None
    execution_strategy: Literal["plan", "act"] | None = None
    chat_message: str | None = None
    permissions: str | None = None
    max_iterations: int | None = None

    # SDK runtime metadata (not serialized to config file)
    # Used internally for Pydantic schema references
    _sdk_meta: dict[str, Any] = {}


class ModeConfig(BaseModel):
    """
    Mode definition within an agent configuration.

    Modes are like commands but without arguments or triggers.
    They define a behavioral configuration for the agent.

    Example:
        ModeConfig(
            description="Code review mode",
            instructions="Focus on code quality...",
            available_tools=["filesystem", "git"],
        )
    """

    model_config = ConfigDict(extra="allow")

    description: str | None = None
    instructions: str = ""
    available_tools: list[str] | None = None
    ignore_tools: list[str] | None = None
    disable_mcp: bool | None = None
    model: str | None = None
    mcp_servers: dict[str, MCPConfig] | None = None
    output_schema: str | OutputSchema | dict[str, Any] | None = None
    exit_expression: str | None = None
    execution_strategy: Literal["plan", "act"] | None = None
    chat_message: str | None = None
    permissions: str | None = None


class AIAssistantConfig(BaseModel):
    """
    Top-level agent configuration.

    This is the root configuration model that corresponds to an agent.toml
    or agent.yaml file. It defines the agent's behavior, available commands,
    modes, and MCP server configurations.

    Example:
        AIAssistantConfig(
            version="1.0",
            instructions="You are a helpful coding assistant.",
            model="gpt-4",
            commands={
                "review": CommandConfig(name="review", ...),
                "fix": CommandConfig(name="fix", ...),
            },
            available_tools=["filesystem", "git", "shell"],
        )
    """

    model_config = ConfigDict(extra="allow", populate_by_name=True)

    version: str | None = None
    system_prompt: str | None = Field(default=None, alias="_system_prompt")
    instructions: str | None = None
    commands: dict[str, CommandConfig] | None = None
    modes: dict[str, ModeConfig] | None = None
    imports: list[str] | None = None
    mcp_servers: str | dict[str, MCPConfig] | None = None
    model: str | None = None
    available_tools: list[str] | None = None
    ignore_tools: list[str] | None = None
    disable_mcp: bool | None = None
    output_schema: str | OutputSchema | dict[str, Any] | None = None
    exit_expression: str | None = None
    execution_strategy: Literal["plan", "act"] | None = None
    permissions: str | None = None
    max_iterations: int | None = None


class ValidationError(BaseModel):
    """Single validation error with path and message."""

    path: str
    message: str


class ValidationResult(BaseModel):
    """Result of configuration validation."""

    valid: bool
    errors: list[ValidationError] = Field(default_factory=list)


# Type aliases for convenience
ToolsConfig = dict[str, list[dict[str, Any]]]
"""Mapping of server name to list of tool definitions."""

MessagesFormat = dict[str, list[Any]]
"""Message format dict with 'langchain' and 'openai' keys."""
