"""
Error hierarchy for the Qodo SDK.

All Qodo-specific exceptions inherit from QodoError, making it easy
to catch all SDK errors with a single except clause.
"""

from __future__ import annotations

from typing import Any


class QodoError(Exception):
    """
    Base exception for all Qodo SDK errors.

    All Qodo-specific exceptions inherit from this class.

    Example:
        try:
            await sdk.run("command")
        except QodoError as e:
            print(f"Qodo error: {e}")
    """

    pass


class QodoAuthError(QodoError):
    """
    Authentication error.

    Raised when:
    - API key is missing (not in QODO_API_KEY env var or ~/.qodo/auth.key)
    - API key is invalid (401 response from backend)
    - API key has expired or been revoked

    Example:
        try:
            sdk = QodoSDK()
        except QodoAuthError as e:
            print("Please set your QODO_API_KEY environment variable")
    """

    pass


class QodoSchemaError(QodoError):
    """
    Schema validation error.

    Raised when:
    - Output schema is missing required descriptions
    - Command args fail Pydantic validation
    - Invalid schema structure provided
    - JSON schema conversion fails

    Example:
        from pydantic import BaseModel

        class BadOutput(BaseModel):
            result: str  # Missing Field(description=...)

        # This will raise QodoSchemaError
        sdk_command(name="bad", output=BadOutput)
    """

    pass


class QodoBackendBootstrapError(QodoError):
    """
    Backend initialization error.

    Raised when:
    - Cannot connect to the Qodo backend
    - Backend returns invalid configuration
    - get-things endpoint fails or returns unexpected data
    - Network connectivity issues during bootstrap

    Example:
        try:
            sdk = QodoSDK()
            await sdk.run("command")
        except QodoBackendBootstrapError as e:
            print(f"Failed to connect to Qodo: {e}")
    """

    pass


class QodoConnectionError(QodoError):
    """
    WebSocket connection error.

    Raised when:
    - WebSocket connection timeout
    - Connection refused by server
    - Unexpected disconnection during operation
    - Failed to establish WebSocket handshake
    - Maximum reconnection attempts exceeded

    Example:
        try:
            async for event in sdk.stream("command"):
                ...
        except QodoConnectionError as e:
            print(f"Connection lost: {e}")
    """

    pass


class QodoToolError(QodoError):
    """
    Tool execution error.

    Raised when:
    - Requested tool not found
    - Tool execution fails internally
    - Permission denied for tool execution
    - Tool arguments are invalid
    - Tool timeout exceeded

    Example:
        try:
            result = await mcp_manager.call_tool("shell", "execute", {"cmd": "ls"})
        except QodoToolError as e:
            print(f"Tool failed: {e}")
    """

    pass


class ToolMiddlewareError(QodoToolError):
    """Tool middleware execution error."""

    def __init__(
        self,
        message: str,
        *,
        middleware_name: str = "",
        phase: str = "",
        cause: Exception | None = None,
    ) -> None:
        super().__init__(message)
        self.middleware_name = middleware_name
        self.phase = phase
        self.cause = cause


class QodoConfigError(QodoError):
    """
    Configuration error.

    Raised when:
    - Invalid agent.toml or agent.yaml syntax
    - Missing required configuration fields
    - Invalid command or mode configuration
    - Circular imports in agent config
    - Unknown configuration keys

    Example:
        try:
            config = ConfigManager.init("path/to/agent.toml")
        except QodoConfigError as e:
            print(f"Invalid config: {e}")
    """

    pass


class QodoTimeoutError(QodoError):
    """
    Operation timeout error.

    Raised when:
    - HTTP request timeout
    - WebSocket Ready protocol timeout
    - Tool execution timeout
    - Idle connection timeout

    Example:
        try:
            result = await sdk.run("long_command", timeout=30000)
        except QodoTimeoutError as e:
            print(f"Operation timed out: {e}")
    """

    pass


class QodoCancelledError(QodoError):
    """
    Operation cancelled error.

    Raised when:
    - User calls sdk.cancel() during execution
    - Operation is aborted via AbortController equivalent
    - Parent task is cancelled

    Example:
        async def run_with_timeout():
            task = asyncio.create_task(sdk.run("command"))
            await asyncio.sleep(5)
            sdk.cancel()
            try:
                await task
            except QodoCancelledError:
                print("Operation was cancelled")
    """

    pass


class QodoOutputValidationError(QodoError):
    """
    Structured output validation error.

    Raised when runtime validation of structured_output against a
    Pydantic model fails.
    """

    def __init__(
        self,
        issues: list[dict[str, str]] | None = None,
        raw_output: Any = None,
        message: str | None = None,
    ):
        issues = issues or []
        if message is None:
            parts = [f"{i.get('path', '(root)')}: {i.get('message', '?')}" for i in issues]
            message = f"Structured output validation failed: {'; '.join(parts)}"
        super().__init__(message)
        self.issues = issues
        self.raw_output = raw_output


class PipelineExecutionError(QodoError):
    """Pipeline step execution error."""

    def __init__(
        self,
        message: str,
        step_name: str = "",
        cause: Exception | None = None,
    ) -> None:
        super().__init__(message)
        self.step_name = step_name
        self.cause = cause
