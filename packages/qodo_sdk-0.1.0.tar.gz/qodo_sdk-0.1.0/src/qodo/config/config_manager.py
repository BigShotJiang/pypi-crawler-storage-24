"""
ConfigManager for loading and managing agent configurations.

Handles TOML/YAML parsing, config inheritance, and command resolution.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Any

from qodo.errors import QodoConfigError
from qodo.parser.types import (
    AIAssistantConfig,
    CommandConfig,
    MCPConfig,
    ModeConfig,
    ValidationResult,
)
from qodo.session.environment import get_current_environment, get_global_environment


def detect_config_format(file_path: str) -> str:
    """Detect config format from file extension."""
    ext = Path(file_path).suffix.lower()
    if ext in (".yaml", ".yml"):
        return "yaml"
    return "toml"


def parse_config_by_format(config_string: str, format: str) -> dict[str, Any]:
    """Parse config string based on format."""
    try:
        if format == "yaml":
            import yaml

            return yaml.safe_load(config_string) or {}
        else:
            if sys.version_info >= (3, 11):
                import tomllib

                return tomllib.loads(config_string)
            else:
                import tomli  # type: ignore[import-not-found]

                return tomli.loads(config_string)  # type: ignore[no-any-return]
    except Exception as e:
        raise QodoConfigError(f"Failed to parse {format.upper()} configuration: {e}") from e


class ConfigManager:
    """
    Manages agent configuration loading and resolution.

    Handles:
    - Loading config from file path, string content, or dict
    - TOML and YAML format detection
    - Config inheritance (commands inherit from top-level)
    - Command/mode resolution
    - Validation

    Uses environment-aware singleton pattern:
    - SDK mode: isolated instance per environment
    - CLI mode: global singleton
    """

    _instance: ConfigManager | None = None

    def __init__(
        self,
        agent_config_path: str | None = None,
        is_file_content: bool = False,
    ) -> None:
        self._agent_config_path = agent_config_path
        self._is_explicit_agent_file = is_file_content or bool(agent_config_path)
        self._config: AIAssistantConfig | None = None
        self._validation_result = ValidationResult(valid=True, errors=[])

    @classmethod
    async def init(
        cls,
        agent_config: str | dict[str, Any] | AIAssistantConfig | None = None,
        is_file_content: bool = False,
    ) -> ConfigManager:
        """
        Initialize ConfigManager for the current environment.

        Args:
            agent_config: Config source - file path, string content, or dict.
            is_file_content: If True, treat string as content not path.

        Returns:
            Initialized ConfigManager instance.
        """
        env = get_current_environment()
        global_env = get_global_environment()

        # SDK mode: environment-scoped instance
        if env is not global_env:
            instance = env.config_manager
            if not instance:
                path_arg = (
                    agent_config if not is_file_content and isinstance(agent_config, str) else None
                )
                instance = cls(path_arg, is_file_content)
                env.config_manager = instance

            await instance._load_config(
                agent_config if is_file_content or not isinstance(agent_config, str) else None
            )
            return instance

        # CLI mode: global singleton
        if not cls._instance:
            path_arg = (
                agent_config if not is_file_content and isinstance(agent_config, str) else None
            )
            cls._instance = cls(path_arg, is_file_content)
            if not global_env.config_manager:
                global_env.config_manager = cls._instance

        await cls._instance._load_config(
            agent_config if is_file_content or not isinstance(agent_config, str) else None
        )
        return cls._instance

    @classmethod
    def get_instance(cls) -> ConfigManager:
        """
        Get the current ConfigManager instance.

        Returns:
            Current ConfigManager.

        Raises:
            RuntimeError: If not initialized.
        """
        env = get_current_environment()
        global_env = get_global_environment()

        if env is not global_env:
            instance = env.config_manager
            if not instance:
                raise RuntimeError(
                    "ConfigManager not initialized for this environment. "
                    "Call ConfigManager.init() first"
                )
            return instance  # type: ignore[no-any-return]

        if not cls._instance:
            raise RuntimeError("ConfigManager not initialized. Call ConfigManager.init() first")
        return cls._instance

    def has_config(self) -> bool:
        """Check if config is loaded."""
        return self._config is not None

    def has_explicit_agent_file(self) -> bool:
        """Check if config was explicitly provided."""
        return self._is_explicit_agent_file

    async def _find_nearest_agent_config(self) -> str | None:
        """Find nearest agent config file by walking up directories."""
        current_dir = Path.cwd()
        root_dir = current_dir.anchor

        while str(current_dir) != root_dir:
            for filename in ["agent.toml", "agent.yaml", "agent.yml"]:
                config_path = current_dir / filename
                if config_path.exists() and os.access(config_path, os.R_OK):
                    return str(config_path)
            current_dir = current_dir.parent

        # Check root
        for filename in ["agent.toml", "agent.yaml", "agent.yml"]:
            root_path = Path(root_dir) / filename
            if root_path.exists():
                return str(root_path)

        return None

    async def _get_agent_config_path(self) -> str | None:
        """Get the agent config path to load."""
        if self._agent_config_path:
            path = Path(self._agent_config_path)
            if path.exists() and os.access(path, os.R_OK):
                return str(path)
            return None

        return await self._find_nearest_agent_config()

    async def _load_config(
        self,
        agent_content_or_object: str | dict[str, Any] | AIAssistantConfig | None = None,
    ) -> None:
        """Load configuration from source."""
        agent_config_path = await self._get_agent_config_path()

        if not agent_content_or_object and not agent_config_path:
            # No config found - this is okay for SDK, we'll use defaults
            return

        if agent_content_or_object:
            if isinstance(agent_content_or_object, str):
                # Load from string content
                self._config = self._parse_config_string(agent_content_or_object)
            elif isinstance(agent_content_or_object, AIAssistantConfig):
                # Already parsed
                self._config = agent_content_or_object
            else:
                # Dict - normalize to AIAssistantConfig
                self._config = self._normalize_config_object(agent_content_or_object)

            # Default execution strategy for SDK
            if self._config and not self._config.execution_strategy:
                self._config.execution_strategy = "act"

        elif agent_config_path:
            # Load from file
            self._config = await self._load_config_from_file(agent_config_path)

    def _parse_config_string(self, content: str) -> AIAssistantConfig:
        """Parse config from string (auto-detect format)."""
        # Try YAML first (it's more permissive), then TOML
        try:
            data = parse_config_by_format(content, "yaml")
        except Exception:
            data = parse_config_by_format(content, "toml")  # YAML failed; try TOML

        return self._normalize_config_object(data)

    async def _load_config_from_file(self, file_path: str) -> AIAssistantConfig:
        """Load config from file."""
        content = Path(file_path).read_text()
        format = detect_config_format(file_path)
        data = parse_config_by_format(content, format)
        return self._normalize_config_object(data)

    def _normalize_config_object(self, data: dict[str, Any]) -> AIAssistantConfig:
        """Normalize a raw config dict to AIAssistantConfig."""
        # Convert commands dict
        commands = {}
        for name, cmd_data in (data.get("commands") or {}).items():
            if isinstance(cmd_data, dict):
                # Avoid duplicate 'name' if already present in cmd_data
                if "name" not in cmd_data:
                    cmd_data = {**cmd_data, "name": name}
                commands[name] = CommandConfig(**cmd_data)
            elif isinstance(cmd_data, CommandConfig):
                commands[name] = cmd_data

        # Convert modes dict
        modes = {}
        for name, mode_data in (data.get("modes") or {}).items():
            if isinstance(mode_data, dict):
                modes[name] = ModeConfig(**mode_data)
            elif isinstance(mode_data, ModeConfig):
                modes[name] = mode_data

        # Convert mcp_servers
        mcp_servers = {}
        raw_mcp = data.get("mcp_servers") or data.get("mcpServers") or {}
        if isinstance(raw_mcp, dict):
            for name, server_data in raw_mcp.items():
                if isinstance(server_data, dict):
                    mcp_servers[name] = MCPConfig(**server_data)
                elif isinstance(server_data, MCPConfig):
                    mcp_servers[name] = server_data

        return AIAssistantConfig(
            version=data.get("version"),
            _system_prompt=data.get("system_prompt") or data.get("_system_prompt"),
            instructions=data.get("instructions"),
            model=data.get("model"),
            available_tools=data.get("available_tools"),
            ignore_tools=data.get("ignore_tools"),
            disable_mcp=data.get("disable_mcp"),
            output_schema=data.get("output_schema"),
            exit_expression=data.get("exit_expression"),
            execution_strategy=data.get("execution_strategy"),
            commands=commands or None,
            modes=modes or None,
            mcp_servers=mcp_servers or None,
            imports=data.get("imports"),
            max_iterations=data.get("max_iterations"),
            permissions=data.get("permissions"),
        )

    def get_mcp_servers(self) -> dict[str, MCPConfig]:
        """Get MCP server configurations."""
        if not self._config or not self._config.mcp_servers:
            return {}
        if isinstance(self._config.mcp_servers, dict):
            return self._config.mcp_servers
        return {}

    def get_general_instructions(self) -> str | None:
        """Get general agent instructions."""
        return self._config.instructions if self._config else None

    def get_system_prompt(self) -> str | None:
        """Get system prompt."""
        return self._config.system_prompt if self._config else None

    def list_commands(self) -> list[str]:
        """List available command names."""
        if not self._config or not self._config.commands:
            return []
        return list(self._config.commands.keys())

    def get_single_command(self) -> str | None:
        """Get command name if only one exists."""
        commands = self.list_commands()
        return commands[0] if len(commands) == 1 else None

    def get_validation_result(self) -> ValidationResult:
        """Get validation result."""
        return self._validation_result

    def get_raw_config(self) -> AIAssistantConfig | None:
        """Get raw merged config."""
        return self._config

    def list_modes(self) -> list[str]:
        """List available mode names."""
        if not self._config or not self._config.modes:
            return []
        return list(self._config.modes.keys())

    def get_mode_config(self, mode_name: str) -> ModeConfig | None:
        """Get mode config with inheritance applied."""
        if not self._config or not self._config.modes:
            return None

        mode = self._config.modes.get(mode_name)
        if not mode:
            return None

        # Clone and apply inheritance
        merged = ModeConfig(
            description=mode.description,
            instructions=mode.instructions,
            available_tools=mode.available_tools or self._config.available_tools,
            ignore_tools=mode.ignore_tools or self._config.ignore_tools,
            model=mode.model or self._config.model,
            output_schema=mode.output_schema or self._config.output_schema,
            exit_expression=mode.exit_expression or self._config.exit_expression,
            execution_strategy=mode.execution_strategy or self._config.execution_strategy,
            disable_mcp=mode.disable_mcp
            if mode.disable_mcp is not None
            else self._config.disable_mcp,
            permissions=mode.permissions,
        )

        return merged

    def get_command_config(self, command_name: str) -> CommandConfig:
        """
        Get command config with inheritance applied.

        If no commands defined, returns a default config that inherits
        top-level fields. This enables prompt-first SDK usage.
        """
        has_commands = bool(self._config and self._config.commands and self._config.commands)

        if has_commands and self._config and self._config.commands:
            raw_cmd = self._config.commands.get(command_name) or CommandConfig()
        else:
            raw_cmd = CommandConfig()

        # Apply inheritance from top-level config
        cmd = CommandConfig(
            name=command_name,
            description=raw_cmd.description,
            instructions=raw_cmd.instructions,
            available_tools=raw_cmd.available_tools
            or (self._config.available_tools if self._config else None),
            ignore_tools=raw_cmd.ignore_tools
            or (self._config.ignore_tools if self._config else None),
            model=raw_cmd.model or (self._config.model if self._config else None),
            output_schema=raw_cmd.output_schema
            or (self._config.output_schema if self._config else None),
            exit_expression=raw_cmd.exit_expression
            or (self._config.exit_expression if self._config else None),
            execution_strategy=raw_cmd.execution_strategy
            or (self._config.execution_strategy if self._config else None),
            disable_mcp=raw_cmd.disable_mcp
            if raw_cmd.disable_mcp is not None
            else (self._config.disable_mcp if self._config else None),
            permissions=raw_cmd.permissions or "rwx",
            max_iterations=raw_cmd.max_iterations
            or (self._config.max_iterations if self._config else None),
            mcp_servers=raw_cmd.mcp_servers,
            arguments=raw_cmd.arguments,
        )

        # Default execution strategy
        if not cmd.execution_strategy:
            cmd.execution_strategy = "plan" if cmd.instructions else "act"

        # Copy SDK metadata
        if hasattr(raw_cmd, "_sdk_meta"):
            cmd._sdk_meta = raw_cmd._sdk_meta

        return cmd

    async def cleanup(self) -> None:
        """Cleanup resources (compatibility method)."""
        pass

    @classmethod
    async def cleanup_class(cls) -> None:
        """Static cleanup method."""
        env = get_current_environment()
        instance = env.config_manager or cls._instance
        if instance:
            await instance.cleanup()


async def find_nearest_agent_config(start_dir: str | None = None) -> str | None:
    """
    Find the nearest agent config file.

    Args:
        start_dir: Directory to start search from (default: cwd).

    Returns:
        Path to config file or None.
    """
    current_dir = Path(start_dir) if start_dir else Path.cwd()
    root_dir = current_dir.anchor

    while str(current_dir) != root_dir:
        for filename in ["agent.toml", "agent.yaml", "agent.yml"]:
            config_path = current_dir / filename
            if config_path.exists():
                return str(config_path)
        current_dir = current_dir.parent

    return None
