"""
MessageManager for central message state management.

Mirrors the TypeScript SDK's MessageManager - central message state,
loading/error state, and listener pattern for state changes.
"""

from __future__ import annotations

import uuid
from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

from qodo.session.environment import get_current_environment, get_global_environment


@dataclass
class Message:
    """Base message class."""

    content: str
    role: str = "user"  # "user", "assistant", "tool"
    id: str | None = None
    additional_kwargs: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary format."""
        result = {
            "role": self.role,
            "content": self.content,
        }
        if self.id:
            result["id"] = self.id
        if self.additional_kwargs:
            result.update(self.additional_kwargs)
        return result


@dataclass
class HumanMessage(Message):
    """User message."""

    role: str = "user"


@dataclass
class AIMessage(Message):
    """Assistant message."""

    role: str = "assistant"
    tool_calls: list[dict[str, Any]] | None = None

    def to_dict(self) -> dict[str, Any]:
        result = super().to_dict()
        if self.tool_calls:
            result["tool_calls"] = self.tool_calls
        return result


@dataclass
class ToolMessage(Message):
    """Tool result message."""

    role: str = "tool"
    tool_call_id: str | None = None

    def to_dict(self) -> dict[str, Any]:
        result = super().to_dict()
        if self.tool_call_id:
            result["tool_call_id"] = self.tool_call_id
        return result


# Listener type aliases
MessageUpdateListener = Callable[[list[Message]], None]
LoadingStateListener = Callable[[bool], None]
ErrorListener = Callable[[str | None], None]


class MessageManager:
    """
    Central message state manager.

    Manages:
    - Message history (user, assistant, tool messages)
    - Loading state
    - Error state
    - Listener notifications for state changes

    Uses environment-aware singleton pattern:
    - SDK mode: isolated instance per environment
    - CLI mode: global singleton
    """

    _instance: MessageManager | None = None

    def __init__(self) -> None:
        self._messages: list[Message] = []
        self._structured_outputs: list[AIMessage] = []
        self._accumulated_responses: dict[str, str] = {}
        self._message_listeners: list[MessageUpdateListener] = []
        self._loading_listeners: list[LoadingStateListener] = []
        self._error_listeners: list[ErrorListener] = []
        self._is_loading: bool = False
        self._error: str | None = None

    @classmethod
    def get_instance(cls) -> MessageManager:
        """
        Get the MessageManager instance for the current environment.

        Returns:
            MessageManager instance.
        """
        env = get_current_environment()
        global_env = get_global_environment()

        instance = env.message_manager
        if not instance:
            instance = cls()
            env.message_manager = instance

            # Preserve legacy singleton only if we're in the global environment
            if env is global_env:
                cls._instance = instance
                if not global_env.message_manager:
                    global_env.message_manager = instance

        return instance

    # Getters

    def get_messages(self) -> list[Message]:
        """Get copy of all messages."""
        return list(self._messages)

    def get_last_message(self) -> list[Message]:
        """Get the last message as a list."""
        if self._messages:
            return [self._messages[-1]]
        return []

    def get_last_ai_message(self) -> AIMessage | None:
        """Get the last AI message."""
        for msg in reversed(self._messages):
            if isinstance(msg, AIMessage):
                return msg
        return None

    def get_last_ai_structured_output(self) -> AIMessage | None:
        """Get the last structured output message."""
        if self._structured_outputs:
            return self._structured_outputs[-1]
        return None

    def get_is_loading(self) -> bool:
        """Get loading state."""
        return self._is_loading

    def get_error(self) -> str | None:
        """Get error message."""
        return self._error

    # State modification methods

    def add_message(self, message: Message) -> None:
        """Add a message and notify listeners."""
        self._messages.append(message)
        self._notify_message_listeners()

    def set_messages(self, messages: list[Message], silent: bool = False) -> None:
        """Set all messages."""
        self._messages = list(messages)
        if not silent:
            self._notify_message_listeners()

    def set_loading(self, is_loading: bool) -> None:
        """Set loading state and notify listeners."""
        self._is_loading = is_loading
        self._notify_loading_listeners()

    def set_error(self, error: str | None) -> None:
        """Set error and notify listeners."""
        self._error = error
        self._notify_error_listeners()

    def reset(self) -> None:
        """Reset all state."""
        self._messages = []
        self.soft_reset()

    def soft_reset(self) -> None:
        """Reset non-message state."""
        self._accumulated_responses.clear()
        self._is_loading = False
        self._error = None
        self._notify_loading_listeners()
        self._notify_error_listeners()

    # Accumulated response handling (for streaming)

    def accumulate_response(self, tool_id: str, content: str) -> None:
        """Accumulate response content for a tool ID."""
        current = self._accumulated_responses.get(tool_id, "")
        self._accumulated_responses[tool_id] = current + content

    def get_accumulated_response(self, tool_id: str) -> str:
        """Get accumulated response for a tool ID."""
        return self._accumulated_responses.get(tool_id, "")

    def finalize_user_response(self, tool_id: str) -> None:
        """Finalize accumulated response as an AI message."""
        content = self._accumulated_responses.get(tool_id, "")
        if content:
            self.add_message(AIMessage(content=content, id=tool_id))
            del self._accumulated_responses[tool_id]

    def has_pending_responses(self) -> bool:
        """Check if there are pending accumulated responses."""
        return bool(self._accumulated_responses)

    def get_all_accumulated_responses(self) -> dict[str, str]:
        """Get all accumulated responses."""
        return dict(self._accumulated_responses)

    def add_structured_output(self, message: AIMessage) -> None:
        """Add a structured output message."""
        self._structured_outputs.append(message)

    # Listener management

    def add_message_listener(self, listener: MessageUpdateListener) -> Callable[[], None]:
        """
        Add a message listener.

        Args:
            listener: Callback that receives list of messages.

        Returns:
            Unsubscribe function.
        """
        self._message_listeners.append(listener)

        def unsubscribe() -> None:
            if listener in self._message_listeners:
                self._message_listeners.remove(listener)

        return unsubscribe

    def add_loading_listener(self, listener: LoadingStateListener) -> Callable[[], None]:
        """
        Add a loading state listener.

        Args:
            listener: Callback that receives loading state.

        Returns:
            Unsubscribe function.
        """
        self._loading_listeners.append(listener)

        def unsubscribe() -> None:
            if listener in self._loading_listeners:
                self._loading_listeners.remove(listener)

        return unsubscribe

    def add_error_listener(self, listener: ErrorListener) -> Callable[[], None]:
        """
        Add an error listener.

        Args:
            listener: Callback that receives error message or None.

        Returns:
            Unsubscribe function.
        """
        self._error_listeners.append(listener)

        def unsubscribe() -> None:
            if listener in self._error_listeners:
                self._error_listeners.remove(listener)

        return unsubscribe

    def _notify_message_listeners(self) -> None:
        """Notify all message listeners."""
        messages = self.get_messages()
        for listener in self._message_listeners:
            try:
                listener(messages)
            except Exception:
                pass  # non-fatal: listener errors must not propagate

    def _notify_loading_listeners(self) -> None:
        """Notify all loading listeners."""
        for listener in self._loading_listeners:
            try:
                listener(self._is_loading)
            except Exception:
                pass  # non-fatal: listener errors must not propagate

    def _notify_error_listeners(self) -> None:
        """Notify all error listeners."""
        for listener in self._error_listeners:
            try:
                listener(self._error)
            except Exception:
                pass  # non-fatal: listener errors must not propagate

    def create_user_engagement_callback(
        self,
        stream: bool = False,
    ) -> Callable[[dict[str, Any]], None]:
        """
        Create a callback for handling backend responses.

        This is used by AgentAPI to process UserResponse and other
        backend messages.

        Args:
            stream: Whether to update messages in real-time for streaming.

        Returns:
            Callback function for processing responses.
        """
        last_user_response_tool_id: str | None = None

        def finalize_pending() -> None:
            nonlocal last_user_response_tool_id
            if (
                last_user_response_tool_id is not None
                and last_user_response_tool_id in self._accumulated_responses
            ):
                self.finalize_user_response(last_user_response_tool_id)
                last_user_response_tool_id = None

        def callback(response: dict[str, Any]) -> None:
            nonlocal last_user_response_tool_id

            # Handle force stop
            if response.get("forceStop"):
                finalize_pending()
                self.set_loading(False)
                return

            # Handle error
            if response.get("error"):
                self.set_error(response["error"])
                return

            # Handle tool data (UserResponse from backend)
            tool_data = response.get("toolData")
            if not tool_data:
                return

            tool_id = tool_data.get("identifier", str(uuid.uuid4()))
            tool_args = tool_data.get("tool_args", {})
            tool_result = tool_data.get("tool_result")
            tool_name = tool_data.get("tool", "")

            # Handle tool call (tool request without result) vs tool result
            if tool_result:
                # Add tool result message
                finalize_pending()
                self.add_message(
                    ToolMessage(
                        content=tool_result.get("content", ""),
                        tool_call_id=tool_id,
                        additional_kwargs={
                            "server_name": tool_data.get("server_name", ""),
                            "status": "error" if tool_result.get("isError") else "success",
                        },
                    )
                )
                self._notify_message_listeners()
                return
            elif tool_name and tool_name != "UserResponse":
                # Add tool call message (tool request)
                finalize_pending()
                self.add_message(
                    AIMessage(
                        content=tool_data.get("tool_reasoning", "") or "",
                        tool_calls=[
                            {
                                "name": tool_name,
                                "args": tool_args,
                                "id": tool_id,
                                "type": "tool_call",
                            }
                        ],
                        additional_kwargs={
                            "server_name": tool_data.get("server_name", ""),
                            "pending_approval": tool_data.get("pending_approval", False),
                            "tool_args_for_ui": tool_data.get("tool_args_for_ui"),
                        },
                    )
                )
                self._notify_message_listeners()
                return

            # Handle UserResponse (streaming content)
            content = tool_args.get("content", "")
            message_type = tool_args.get("type")

            # Handle retry status messages
            if message_type == "retry_status":
                self.add_message(
                    AIMessage(
                        content=content,
                        id=tool_id,
                        additional_kwargs={"type": "retry_status", "isRetryStatus": True},
                    )
                )
                return

            # Handle structured output
            if message_type == "structured_output":
                self.add_structured_output(AIMessage(content=content, id=tool_id))

            # Finalize previous response if tool ID changed
            if (
                last_user_response_tool_id is not None
                and last_user_response_tool_id != tool_id
                and last_user_response_tool_id in self._accumulated_responses
            ):
                self.finalize_user_response(last_user_response_tool_id)

            # Update tracking
            last_user_response_tool_id = tool_id

            # Accumulate content
            self.accumulate_response(tool_id, content)

            # For streaming, update messages in real-time
            if stream:
                accumulated = self.get_accumulated_response(tool_id)
                # Find or create the AI message for this tool_id
                found = False
                for i, msg in enumerate(self._messages):
                    if isinstance(msg, AIMessage) and msg.id == tool_id:
                        # Update existing message
                        self._messages[i] = AIMessage(
                            content=accumulated,
                            id=tool_id,
                        )
                        found = True
                        break

                if not found:
                    # Find last user message index
                    last_user_idx = -1
                    for i, msg in enumerate(self._messages):
                        if isinstance(msg, HumanMessage):
                            last_user_idx = i

                    # Add new AI message after last user message
                    new_msg = AIMessage(content=accumulated, id=tool_id)
                    if last_user_idx >= 0:
                        self._messages.insert(last_user_idx + 1, new_msg)
                    else:
                        self._messages.append(new_msg)

                self._notify_message_listeners()

        return callback


# Format conversion utilities


def to_langchain_dict(messages: list[Message]) -> list[dict[str, Any]]:
    """Convert messages to LangChain dict format."""
    return [msg.to_dict() for msg in messages]


def to_openai_chat(messages: list[Message]) -> list[dict[str, Any]]:
    """Convert messages to OpenAI chat format."""
    result = []
    for msg in messages:
        chat_msg: dict[str, Any] = {
            "role": msg.role,
            "content": msg.content,
        }
        if isinstance(msg, AIMessage) and msg.tool_calls:
            chat_msg["tool_calls"] = msg.tool_calls
        if isinstance(msg, ToolMessage) and msg.tool_call_id:
            chat_msg["tool_call_id"] = msg.tool_call_id
        result.append(chat_msg)
    return result
