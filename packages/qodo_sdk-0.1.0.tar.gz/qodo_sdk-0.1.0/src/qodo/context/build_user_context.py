"""
User context utilities.

Builds enriched user context from command arguments.
Mirrors the TypeScript SDK's buildUserContext.ts.
"""

from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Optional

if TYPE_CHECKING:
    from qodo.parser.types import CommandConfig


@dataclass
class UserContextEntry:
    """
    Entry shape for enriched user_context when derived from command arguments.

    Only the value and the human-readable description are included, since those
    are the most useful pieces of information for the LLM.
    """

    value: Any
    description: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary format."""
        result: dict[str, Any] = {"value": self.value}
        if self.description:
            result["description"] = self.description
        return result


def build_user_context_from_args(
    raw_context: dict[str, Any] | None,
    command: Optional["CommandConfig"],
) -> dict[str, Any] | None:
    """
    Build a structured user_context map from raw command arguments.

    For keys that match defined command arguments, wraps them as { value, description }.
    For any unknown keys, leaves the value as-is so custom flags continue to work.

    Args:
        raw_context: Raw context dictionary from command arguments.
        command: Command configuration with argument definitions.

    Returns:
        Enriched user context dictionary, or None if empty.
    """
    if not raw_context:
        return None

    result: dict[str, Any] = {}

    # Build index of command arguments
    arg_index: dict[str, Any] = {}
    if command and hasattr(command, "arguments") and command.arguments:
        for arg in command.arguments:
            if hasattr(arg, "name"):
                arg_index[arg.name] = arg

    for key, value in raw_context.items():
        arg_cfg = arg_index.get(key)
        if arg_cfg:
            # Wrap as enriched entry
            entry: dict[str, Any] = {"value": value}
            if hasattr(arg_cfg, "description") and arg_cfg.description:
                entry["description"] = arg_cfg.description
            result[key] = entry
        else:
            # Not a declared command argument – keep as-is
            result[key] = value

    return result if result else None
