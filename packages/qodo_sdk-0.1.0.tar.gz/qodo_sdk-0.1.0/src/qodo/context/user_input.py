"""
User input utilities.

Builds the user input string from prompt and command config.
Mirrors the TypeScript SDK's userInput.ts.
"""

from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from qodo.parser.types import CommandConfig


def get_user_input(
    prompt: str,
    extra_instructions: str,
    command: Optional["CommandConfig"] = None,
) -> str:
    """
    Build the user input string from prompt and command configuration.

    Args:
        prompt: The user's raw prompt.
        extra_instructions: Additional instructions to append.
        command: Optional command configuration.

    Returns:
        The formatted user input string.
    """
    if command is None:
        from qodo.session import SessionContext

        command = SessionContext.get_instance().get_command()

    # If command has a chat_message, use it directly
    if command and hasattr(command, "chat_message") and command.chat_message:
        return command.chat_message

    # If prompt equals command name, clear it
    if command and hasattr(command, "name") and command.name == prompt:
        prompt = ""

    # Build user input from instructions and prompt
    if command and hasattr(command, "instructions") and command.instructions:
        user_input = f"{command.instructions}\n\n{prompt}"
    else:
        user_input = prompt or ""

    # Append extra instructions
    if extra_instructions:
        user_input += f" {extra_instructions}"

    return user_input
