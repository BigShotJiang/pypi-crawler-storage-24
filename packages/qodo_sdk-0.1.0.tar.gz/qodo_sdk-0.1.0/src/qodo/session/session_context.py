"""
SessionContext for managing session state.

Provides global session state that is shared across components, including
accessible paths, working directory, model, permissions, and session ID.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Literal

from qodo.parser.types import CommandConfig
from qodo.session.environment import get_current_environment, get_global_environment


def canonicalize_path(path_str: str) -> str:
    """Resolve and normalize a path."""
    return str(Path(path_str).resolve())


class SessionContext:
    """
    Manages global session state shared across components.

    Includes:
    - Accessible paths (project directories)
    - Working directory
    - Model selection
    - Permissions
    - Session ID
    - Tool configuration

    Uses environment-aware singleton pattern:
    - SDK mode: isolated instance per environment
    - CLI mode: global singleton
    """

    _instance: SessionContext | None = None

    def __init__(
        self,
        command: CommandConfig,
        general_instructions: str | None = None,
        system_prompt: str | None = None,
        flags: dict[str, Any] | None = None,
        model: str | None = None,
        session_id: str | None = None,
    ) -> None:
        self._command = command
        self._general_instructions = general_instructions
        self._system_prompt = system_prompt
        self._flags = flags or {}
        self._model = model or ""
        self._session_id = session_id

        self._accessible_paths: list[str] = []
        self._current_working_directory: str = ""
        self._execution_cwd: str | None = None
        self._permissions: str = "rwx"
        self._is_resumed_session: bool = False
        self._previous_sessions_summarization: dict[str, str] = {}

        # Extract tools from command
        self._available_tools = command.available_tools
        self._ignore_tools = command.ignore_tools

        # Set permissions from command if specified
        if command.permissions:
            self.set_permissions(command.permissions)

    @classmethod
    def get_instance(cls) -> SessionContext:
        """
        Get the current SessionContext instance.

        Returns:
            The current SessionContext.

        Raises:
            RuntimeError: If not initialized or no paths configured.
        """
        env = get_current_environment()
        instance = env.session_context or cls._instance

        if not instance:
            raise RuntimeError("SessionContext has not been initialized.")
        if not instance._accessible_paths:
            raise RuntimeError(
                "SessionContext has no project paths configured. "
                "Ensure QodoSDK is initialized with project_path."
            )
        return instance

    @classmethod
    async def new_session_context(
        cls,
        flags: dict[str, Any],
        command: CommandConfig,
        general_instructions: str | None = None,
        system_prompt: str | None = None,
        session_id: str | None = None,
    ) -> SessionContext:
        """
        Create a new SessionContext for SDK use.

        In SDK mode, generates a fresh session ID if none provided,
        ensuring each SDK instance gets independent session state.

        Args:
            flags: Runtime flags.
            command: Command configuration.
            general_instructions: Agent instructions.
            system_prompt: System prompt.
            session_id: Optional session ID override.

        Returns:
            New SessionContext instance.
        """
        from qodo.session.server_data import ServerData

        # Determine model
        model = flags.get("model") or command.model
        if model:
            ServerData.get_instance().check_model_input(model)

        # Generate session ID for SDK mode if not provided
        effective_session_id = session_id
        if not effective_session_id and flags.get("sdk"):
            # First try to use session ID from initial get_things response
            server_data = ServerData.get_instance()
            effective_session_id = server_data.get_session_id()
            if not effective_session_id:
                # Only fetch new one if not available
                effective_session_id = await server_data.fetch_new_session_id()

        # Create context
        context = cls(
            command=command,
            general_instructions=general_instructions,
            system_prompt=system_prompt,
            flags=flags,
            model=model or ServerData.get_instance().get_default_model() or "",
            session_id=effective_session_id,
        )

        # Register on current environment
        env = get_current_environment()
        env.session_context = context

        # Also set as global fallback if none exists
        if not cls._instance:
            cls._instance = context
            global_env = get_global_environment()
            if not global_env.session_context:
                global_env.session_context = context

        return context

    @classmethod
    async def initialize(
        cls,
        flags: dict[str, Any],
        command: CommandConfig,
        general_instructions: str | None = None,
        system_prompt: str | None = None,
        session_id: str | None = None,
    ) -> SessionContext:
        """
        Initialize session context (backward compatible with CLI).

        Args:
            flags: Runtime flags.
            command: Command configuration.
            general_instructions: Agent instructions.
            system_prompt: System prompt.
            session_id: Optional session ID.

        Returns:
            Initialized SessionContext.
        """
        return await cls.new_session_context(
            flags=flags,
            command=command,
            general_instructions=general_instructions,
            system_prompt=system_prompt,
            session_id=session_id,
        )

    def set_command(self, command: CommandConfig) -> None:
        """Update the current command configuration."""
        self._command = command
        if command.permissions:
            self.set_permissions(command.permissions)

    async def set_accessible_paths(self, paths: list[str]) -> list[str]:
        """
        Set accessible paths with validation.

        Args:
            paths: List of directory paths to make accessible.

        Returns:
            List of validated accessible paths.
        """

        cwd = (
            canonicalize_path(self._current_working_directory)
            if self._current_working_directory
            else ""
        )
        all_paths = [cwd, *paths] if cwd else paths

        # Check if CWD is already included
        cwd_included = (
            any(
                cwd == canonicalize_path(p) or cwd.startswith(canonicalize_path(p) + os.sep)
                for p in paths
            )
            if cwd
            else False
        )

        paths_to_validate = paths if cwd_included else all_paths

        # Validate access to each directory
        validated: list[str] = []
        for dir_path in paths_to_validate:
            try:
                resolved = canonicalize_path(dir_path)
                # Check if path exists and is readable
                if os.path.isdir(resolved) and os.access(resolved, os.R_OK):
                    validated.append(resolved)
            except Exception:
                pass  # best-effort: skip inaccessible paths

        # Remove duplicates
        self._accessible_paths = list(dict.fromkeys(validated))
        return self._accessible_paths.copy()

    def set_accessible_paths_sync(self, paths: list[str]) -> list[str]:
        """
        Set accessible paths synchronously.

        Args:
            paths: List of directory paths.

        Returns:
            List of validated paths.
        """
        cwd = (
            canonicalize_path(self._current_working_directory)
            if self._current_working_directory
            else ""
        )
        all_paths = [cwd, *paths] if cwd else paths

        validated: list[str] = []
        for dir_path in all_paths:
            try:
                resolved = canonicalize_path(dir_path)
                if os.path.isdir(resolved) and os.access(resolved, os.R_OK):
                    validated.append(resolved)
            except Exception:
                pass  # best-effort: skip inaccessible paths

        self._accessible_paths = list(dict.fromkeys(validated))
        return self._accessible_paths.copy()

    def get_accessible_paths(self) -> list[str]:
        """Get list of accessible paths."""
        return self._accessible_paths.copy()

    def get_available_tools(self) -> list[str] | None:
        """Get list of available tools."""
        return self._available_tools

    def get_ignore_tools(self) -> list[str] | None:
        """Get list of ignored tools."""
        return self._ignore_tools

    def get_session_id(self) -> str:
        """
        Get the session ID.

        Returns:
            Session ID string.

        Raises:
            RuntimeError: If no session ID is set.
        """
        from qodo.session.server_data import ServerData

        session_id = self._session_id or ServerData.get_instance().get_session_id()
        if not session_id:
            raise RuntimeError("Session ID is not set.")
        return session_id

    def get_general_instructions(self) -> str | None:
        """Get general agent instructions."""
        return self._general_instructions

    def get_system_prompt(self) -> str | None:
        """Get system prompt."""
        return self._system_prompt

    def get_command(self) -> CommandConfig:
        """Get current command configuration."""
        return self._command

    def get_flags(self) -> dict[str, Any]:
        """Get runtime flags."""
        return self._flags

    def is_resumed_session(self) -> bool:
        """Check if this is a resumed session."""
        return self._is_resumed_session

    def get_app_type(self) -> str:
        """Get application type (always 'sdk' for Python SDK)."""
        return "sdk"

    def set_model(self, model: str) -> None:
        """Set the model."""
        self._model = model

    def get_model(self) -> str:
        """Get the current model."""
        return self._model

    def get_execution_strategy(self) -> Literal["plan", "act"] | None:
        """Get the execution strategy."""
        if self._flags.get("plan") and self._flags.get("act"):
            raise ValueError("Cannot specify both plan and act flags.")
        if self._flags.get("plan"):
            return "plan"
        if self._flags.get("act"):
            return "act"
        if self._command.execution_strategy:
            return self._command.execution_strategy
        return None

    def get_permissions(self) -> str:
        """Get current permissions."""
        return self._permissions

    def set_permissions(self, permissions: str) -> None:
        """
        Set permissions.

        Args:
            permissions: Permission string (r, rw, rwx, -, etc.)
        """
        import re

        valid_pattern = r"^(r?w?x?|-|rw|rx|wx|rwx)$"
        if not re.match(valid_pattern, permissions):
            return  # Invalid, keep default
        self._permissions = permissions

    def is_dry_run(self) -> bool:
        """Check if the current session is in dry-run mode."""
        return bool(self._flags.get("dry_run"))

    def is_debug_mode(self) -> bool:
        """Check if debug mode is enabled."""
        return bool(self._flags.get("debug")) or os.environ.get("QODO_DEBUG") == "true"

    def set_execution_cwd(self, directory: str | None) -> None:
        """
        Set preferred execution CWD for tools.

        Args:
            directory: Directory path or None to clear.
        """
        if not directory:
            self._execution_cwd = None
            return
        try:
            resolved = canonicalize_path(directory)
            if os.path.isdir(resolved):
                self._execution_cwd = resolved
        except Exception:
            pass  # best-effort: path resolution may fail for invalid inputs

    def get_execution_cwd(self) -> str | None:
        """Get preferred execution CWD."""
        return self._execution_cwd

    def set_current_working_directory(self, directory: str) -> None:
        """Set the current working directory."""
        self._current_working_directory = canonicalize_path(directory)

    def get_current_working_directory(self) -> str:
        """Get the current working directory."""
        return self._current_working_directory

    def add_previous_session_summarization(self, session_id: str, summary: str) -> None:
        """Add a previous session summarization."""
        s = (summary or "").strip()
        sid = (session_id or "").strip()
        if s and sid:
            self._previous_sessions_summarization[sid] = s

    def get_previous_sessions_summarization(
        self,
    ) -> list[dict[str, str]]:
        """Get all previous session summarizations."""
        return [
            {"session_id": sid, "summary": summary}
            for sid, summary in self._previous_sessions_summarization.items()
        ]

    async def add_accessible_path(self, dir_path: str) -> bool:
        """
        Add a new accessible path.

        Args:
            dir_path: Directory path to add.

        Returns:
            True if added successfully.
        """
        try:
            resolved = canonicalize_path(dir_path)
            if os.path.isdir(resolved) and os.access(resolved, os.R_OK):
                if resolved not in self._accessible_paths:
                    self._accessible_paths.append(resolved)
                return True
        except Exception:
            pass  # best-effort: skip inaccessible paths
        return False

    def reset(self) -> None:
        """Reset the context (for testing or new sessions)."""
        self._accessible_paths = []
        self._execution_cwd = None

    def serialize(self) -> dict[str, Any]:
        """Serialize context to dictionary."""
        return {
            "accessible_paths": self._accessible_paths,
            "current_working_directory": self._current_working_directory,
            "execution_cwd": self._execution_cwd,
            "is_resumed_session": self._is_resumed_session,
            "available_tools": self._available_tools,
            "app_type": "sdk",
            "command": self._command.model_dump() if self._command else None,
            "general_instructions": self._general_instructions,
            "system_prompt": self._system_prompt,
            "flags": self._flags,
            "model": self._model,
            "permissions": self._permissions,
            "previous_sessions_summarization": self._previous_sessions_summarization,
            "ignore_tools": self._ignore_tools,
        }
