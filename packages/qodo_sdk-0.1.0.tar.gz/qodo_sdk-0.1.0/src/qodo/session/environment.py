"""
Environment isolation using contextvars.

This module provides AsyncLocalStorage-equivalent functionality for Python,
enabling multiple QodoSDK instances to coexist in the same process with
isolated state.

The pattern mirrors the TypeScript SDK's use of AsyncLocalStorage.
"""

from __future__ import annotations

from collections.abc import Callable
from contextvars import ContextVar, Token
from dataclasses import dataclass, field
from typing import Any, TypeVar

T = TypeVar("T")


@dataclass
class EnvironmentServices:
    """
    Container for environment-scoped services.

    Each QodoSDK instance can have its own isolated environment with
    independent instances of ConfigManager, SessionContext, MCPManager, etc.

    Attributes:
        sdk_mode: If True, indicates this is an SDK environment (not CLI).
                  Prevents process.exit() and enables isolation.
        sdk_debug: If True, enables debug logging for this environment.
        config_manager: Environment-scoped ConfigManager instance.
        session_context: Environment-scoped SessionContext instance.
        server_registry: Environment-scoped ServerRegistry instance.
        mcp_manager: Environment-scoped MCPManager instance.
        message_manager: Environment-scoped MessageManager instance.
        server_data: Environment-scoped ServerData instance.
    """

    sdk_mode: bool = False
    sdk_debug: bool = False

    auth_provider: Any | None = None
    tool_processor_manager: Any | None = None
    config_manager: Any | None = None
    session_context: Any | None = None
    server_registry: Any | None = None
    mcp_manager: Any | None = None
    message_manager: Any | None = None
    server_data: Any | None = None

    # Additional metadata
    metadata: dict[str, Any] = field(default_factory=dict)


# Context variable for environment isolation
# When set, provides an isolated environment for the current async context
_env_context: ContextVar[EnvironmentServices | None] = ContextVar("qodo_environment", default=None)

# Global fallback environment for legacy code paths (CLI mode)
_global_env = EnvironmentServices()


def get_current_environment() -> EnvironmentServices:
    """
    Get the current environment services.

    Returns the context-local environment if set (SDK mode),
    otherwise returns the global fallback environment (CLI mode).

    This allows singletons to check which environment they should use:
    - If env == global_env: use global singleton (CLI)
    - If env != global_env: use environment-scoped instance (SDK)

    Returns:
        The current EnvironmentServices instance.

    Example:
        env = get_current_environment()
        if env.sdk_mode:
            # Use environment-scoped resources
            manager = env.mcp_manager
        else:
            # Use global singleton
            manager = MCPManager.get_global_instance()
    """
    return _env_context.get() or _global_env


def get_global_environment() -> EnvironmentServices:
    """
    Get the global fallback environment.

    This is used for comparison to determine if code is running
    in an isolated SDK environment or in global CLI mode.

    Returns:
        The global EnvironmentServices instance.

    Example:
        env = get_current_environment()
        global_env = get_global_environment()
        if env is not global_env:
            # Running in isolated SDK environment
            pass
    """
    return _global_env


def run_with_environment(env: EnvironmentServices, fn: Callable[[], T]) -> T:
    """
    Run a synchronous function within a specific environment context.

    All nested calls to get_current_environment() within fn will
    return the provided environment.

    Args:
        env: The environment to use for the function execution.
        fn: The function to execute.

    Returns:
        The return value of fn().

    Example:
        env = EnvironmentServices(sdk_mode=True)
        result = run_with_environment(env, lambda: do_something())
    """
    token = _env_context.set(env)
    try:
        return fn()
    finally:
        _env_context.reset(token)


async def run_with_environment_async(env: EnvironmentServices, fn: Callable[[], Any]) -> Any:
    """
    Run an async function within a specific environment context.

    All nested calls to get_current_environment() within fn will
    return the provided environment, including across await boundaries.

    Args:
        env: The environment to use for the function execution.
        fn: The async function to execute (or sync function).

    Returns:
        The return value of fn().

    Example:
        env = EnvironmentServices(sdk_mode=True)
        result = await run_with_environment_async(env, async_operation)
    """
    token = _env_context.set(env)
    try:
        result = fn()
        # Handle both sync and async functions
        if hasattr(result, "__await__"):
            return await result
        return result
    finally:
        _env_context.reset(token)


class EnvironmentContext:
    """
    Context manager for running code within a specific environment.

    Provides a more Pythonic way to use environment isolation.

    Example:
        env = EnvironmentServices(sdk_mode=True)
        with EnvironmentContext(env):
            # All code here sees the isolated environment
            manager = MCPManager.init()

        # Or async:
        async with EnvironmentContext(env):
            result = await sdk.run("command")
    """

    def __init__(self, env: EnvironmentServices) -> None:
        self._env = env
        self._token: Token[EnvironmentServices | None] | None = None

    def __enter__(self) -> EnvironmentServices:
        self._token = _env_context.set(self._env)
        return self._env

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        if self._token is not None:
            _env_context.reset(self._token)

    async def __aenter__(self) -> EnvironmentServices:
        self._token = _env_context.set(self._env)
        return self._env

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        if self._token is not None:
            _env_context.reset(self._token)


def is_sdk_mode() -> bool:
    """
    Check if currently running in SDK mode.

    Returns:
        True if the current environment has sdk_mode=True.
    """
    return get_current_environment().sdk_mode


def is_debug_mode() -> bool:
    """
    Check if debug mode is enabled for the current environment.

    Returns:
        True if sdk_debug is True or QODO_DEBUG env var is set.
    """
    import os

    env = get_current_environment()
    return env.sdk_debug or os.environ.get("QODO_DEBUG") == "true"
