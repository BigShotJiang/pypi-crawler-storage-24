"""
ServerData for backend data caching.

Manages backend configuration fetched from the get-things endpoint,
including available models, session IDs, MCP tools, and rate limits.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any, Literal

from qodo.errors import QodoBackendBootstrapError
from qodo.session.environment import get_current_environment, get_global_environment


@dataclass
class RateLimitInfo:
    """Rate limit information from backend headers."""

    remaining: int | None = None
    reset: int | None = None
    limit: int | None = None


@dataclass
class RecentSession:
    """Recent session information."""

    session_id: str
    description: str = ""
    last_update: int = 0


class ServerData:
    """
    Manages backend configuration data.

    Fetches and caches data from the Qodo backend's get-things endpoint,
    including:
    - Default and available models
    - Session IDs
    - MCP tool definitions
    - Rate limit information
    - Backend version

    Uses environment-aware singleton pattern:
    - SDK mode: isolated instance per environment
    - CLI mode: global singleton
    """

    _instance: ServerData | None = None

    def __init__(self, base_url_override: str | None = None) -> None:
        self._data: dict[str, Any] = {}
        self._rate_limit = RateLimitInfo()
        self._initialized = False

        # Determine base URL
        if base_url_override:
            self._base_url = base_url_override
            self._base_url_source: Literal["user", "server", "default"] = "user"
        elif os.environ.get("QODO_BASE_URL"):
            self._base_url = os.environ["QODO_BASE_URL"]
            self._base_url_source = "user"
        else:
            from qodo.auth import get_api_endpoint

            self._base_url = get_api_endpoint()
            self._base_url_source = "default"

    @classmethod
    async def init(cls, base_url_override: str | None = None) -> ServerData:
        """
        Initialize ServerData for the current environment.

        Fetches backend configuration via get-things endpoint.

        Args:
            base_url_override: Optional URL override for the backend.

        Returns:
            Initialized ServerData instance.
        """
        env = get_current_environment()
        global_env = get_global_environment()

        # SDK mode: environment-scoped instance
        if env is not global_env:
            instance = env.server_data
            if not instance:
                instance = cls(base_url_override)
                env.server_data = instance
            if not instance._initialized:
                await instance.get_things()
                instance._initialized = True
            return instance

        # CLI mode: global singleton
        if not cls._instance:
            cls._instance = cls(base_url_override)
        if not cls._instance._initialized:
            await cls._instance.get_things()
            cls._instance._initialized = True
        return cls._instance

    @classmethod
    def get_instance(cls) -> ServerData:
        """
        Get the current ServerData instance.

        Returns existing instance or creates one without fetching.
        Prefer using init() for proper initialization.
        """
        env = get_current_environment()
        global_env = get_global_environment()

        if env is not global_env:
            instance = env.server_data
            if not instance:
                instance = cls()
                env.server_data = instance
            return instance

        if not cls._instance:
            cls._instance = cls()
        return cls._instance

    def get_base_url(self) -> str:
        """Get the current backend base URL."""
        return self._base_url

    def get_base_url_source(self) -> Literal["user", "server", "default"]:
        """Get the source of the base URL."""
        return self._base_url_source

    async def get_things(self, section: str | None = None) -> None:
        """
        Fetch configuration from the backend.

        Args:
            section: Optional section to fetch (e.g., "session-id").

        Raises:
            QodoBackendBootstrapError: If the request fails.
        """
        from qodo.api.http import http_request
        from qodo.auth import handle_401_error

        try:
            # Build URL with agent_type=sdk for SDK-appropriate tools
            url = "/v2/info/get-things?agent_type=sdk"
            if section:
                url += f"&section={section}"

            # Make request
            response = await http_request(
                "GET",
                url,
                base_url=self._base_url,
            )

            # Process response
            if isinstance(response, dict):
                self._data = response

                # Check for base_url redirect
                if response.get("base_url"):
                    new_base_url = self._process_base_url(response["base_url"])
                    if new_base_url != self._base_url:
                        self._base_url = new_base_url
                        self._base_url_source = "server"
                        # Recursively fetch with new URL
                        await self.get_things(section)
                        return

                if not response:
                    raise QodoBackendBootstrapError("No data found from the server.")

        except Exception as e:
            # Check for 401
            error_msg = str(e)
            if "401" in error_msg:
                env = get_current_environment()
                if env.auth_provider:
                    env.auth_provider.handle_401_error()
                else:
                    handle_401_error()

            if isinstance(e, QodoBackendBootstrapError):
                raise

            raise QodoBackendBootstrapError(
                f"Unable to connect to Qodo servers: {error_msg}"
            ) from e

    def _process_base_url(self, base_url: str) -> str:
        """Process and validate a base URL."""
        try:
            from urllib.parse import urlparse

            parsed = urlparse(base_url)
            if parsed.scheme and parsed.netloc:
                return base_url.rstrip("/")
        except Exception:
            pass  # best-effort: return raw URL if parsing fails
        return base_url

    def get_default_model(self) -> str | None:
        """Get the default model name."""
        return self._data.get("default_model")

    def get_available_models(self) -> list[str]:
        """Get list of available model names."""
        models = self._data.get("models", [])
        return [m.get("model_name", "") for m in models if isinstance(m, dict)]

    def check_model_input(self, model: str) -> None:
        """
        Validate that a model is available.

        Args:
            model: Model name to check.

        Raises:
            QodoBackendBootstrapError: If model is not available.
        """
        available = self.get_available_models()
        if not available:
            raise QodoBackendBootstrapError("No available models found.")
        if model not in available:
            raise QodoBackendBootstrapError(
                f'Model "{model}" is not available. Available models: {", ".join(available)}'
            )

    def get_version(self) -> str | None:
        """Get the backend version."""
        return self._data.get("version")

    def get_session_id(self) -> str | None:
        """Get the session ID from initial get-things response."""
        return self._data.get("session-id")

    async def fetch_new_session_id(self) -> str:
        """
        Fetch a new session ID from the backend.

        Returns:
            New session ID.

        Raises:
            QodoBackendBootstrapError: If fetch fails.
        """
        from qodo.api.http import http_request
        from qodo.auth import handle_401_error

        try:
            response = await http_request(
                "GET",
                "/v2/info/get-things?section=session-id",
                base_url=self._base_url,
            )
            if isinstance(response, dict) and response.get("session-id"):
                return str(response["session-id"])
            raise QodoBackendBootstrapError("No session-id in server response")
        except Exception as e:
            if "401" in str(e):
                env = get_current_environment()
                if env.auth_provider:
                    env.auth_provider.handle_401_error()
                else:
                    handle_401_error()
            raise QodoBackendBootstrapError(f"Failed to fetch session-id from server: {e}") from e

    def get_recent_sessions(self) -> list[RecentSession]:
        """Get list of recent sessions."""
        sessions = self._data.get("recent-sessions", [])
        return [
            RecentSession(
                session_id=s.get("session_id", ""),
                description=s.get("description", ""),
                last_update=s.get("last_update", 0),
            )
            for s in sessions
            if isinstance(s, dict)
        ]

    def get_rate_limit_remaining(self) -> int | None:
        """Get remaining rate limit."""
        return self._rate_limit.remaining

    def get_rate_limit_reset(self) -> int | None:
        """Get rate limit reset timestamp."""
        return self._rate_limit.reset

    def get_rate_limit_limit(self) -> int | None:
        """Get rate limit maximum."""
        return self._rate_limit.limit

    def get_mcp_tools(self) -> dict[str, list[Any]]:
        """Get MCP tool definitions from backend."""
        return self._data.get("mcp-tools", {})  # type: ignore[no-any-return]

    def update_rate_limits(
        self,
        remaining: int | None = None,
        reset: int | None = None,
        limit: int | None = None,
    ) -> None:
        """Update rate limit information."""
        if remaining is not None:
            self._rate_limit.remaining = remaining
        if reset is not None:
            self._rate_limit.reset = reset
        if limit is not None:
            self._rate_limit.limit = limit
