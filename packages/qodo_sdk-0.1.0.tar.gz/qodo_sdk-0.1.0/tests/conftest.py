"""Pytest configuration and shared fixtures."""

from __future__ import annotations

import asyncio
from typing import AsyncIterator, Iterator
from unittest.mock import AsyncMock, MagicMock

import pytest

from qodo import QodoSDK, QodoSDKOptions
from qodo.session.environment import EnvironmentServices


@pytest.fixture
def event_loop() -> Iterator[asyncio.AbstractEventLoop]:
    """Create event loop for async tests."""
    loop = asyncio.new_event_loop()
    yield loop
    loop.close()


@pytest.fixture
def mock_environment() -> EnvironmentServices:
    """Create isolated test environment."""
    return EnvironmentServices(sdk_mode=True, sdk_debug=True)


@pytest.fixture
def sdk_options() -> QodoSDKOptions:
    """Create default SDK options for testing."""
    return QodoSDKOptions(
        project_path="/tmp/test-project",
        debug=True,
    )


@pytest.fixture
async def sdk_instance(sdk_options: QodoSDKOptions) -> AsyncIterator[QodoSDK]:
    """Create SDK instance for testing."""
    sdk = QodoSDK(sdk_options)
    yield sdk
    await sdk.dispose()
