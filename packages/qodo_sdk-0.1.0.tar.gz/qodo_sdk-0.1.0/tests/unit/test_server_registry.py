"""Tests for ServerRegistry — mirrors server-registry.test.ts."""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from qodo.mcp.servers_registry import ConfigValidationError, ServerRegistry
from qodo.mcp.types import ServerType
from qodo.parser.types import MCPConfig
from qodo.session.environment import run_with_environment_async

from tests.helpers.test_env import fresh_env


def _mock_server_data():
    """Mock ServerData to avoid backend calls."""
    mock_sd = MagicMock()
    mock_sd.get_instance.return_value = mock_sd
    mock_sd.get_session_id.return_value = "mock-session-id"
    mock_sd.get_default_model.return_value = "mock-model"
    mock_sd.check_model_input.return_value = None
    mock_sd.fetch_new_session_id = AsyncMock(return_value="mock-new-session")
    mock_sd.get_base_url.return_value = "https://mock.api.qodo.ai"
    mock_sd.get_base_url_source.return_value = "default"
    mock_sd.get_mcp_tools.return_value = {}
    mock_sd.init = AsyncMock(return_value=mock_sd)
    return patch("qodo.session.server_data.ServerData", mock_sd)


class TestInitAndGetInstance:
    """ServerRegistry init and getInstance tests."""

    async def test_init_creates_environment_scoped_instance(self):
        async def run():
            registry = ServerRegistry.init()
            assert registry is not None
            assert ServerRegistry.get_instance() is registry

        await run_with_environment_async(fresh_env(), run)

    async def test_get_instance_throws_when_not_initialized_in_environment(self):
        async def run():
            # Fresh env without prior init should throw
            inner_env = fresh_env()
            async def inner():
                with pytest.raises(RuntimeError, match="ServerRegistry not initialized"):
                    ServerRegistry.get_instance()
            await run_with_environment_async(inner_env, inner)

        await run_with_environment_async(fresh_env(), run)

    async def test_two_environments_get_independent_server_registry_instances(self):
        env1 = fresh_env()
        env2 = fresh_env()

        reg1 = None
        reg2 = None

        async def run1():
            nonlocal reg1
            reg1 = ServerRegistry.init()

        async def run2():
            nonlocal reg2
            reg2 = ServerRegistry.init()

        await run_with_environment_async(env1, run1)
        await run_with_environment_async(env2, run2)

        assert reg1 is not reg2


class TestSetNoBuiltin:
    """ServerRegistry setNoBuiltin tests."""

    async def test_set_no_builtin_controls_builtin_server_loading(self):
        async def run():
            registry = ServerRegistry.init()
            registry.set_no_builtin(True)
            # Verify the setter doesn't throw
            registry.set_no_builtin(False)

        await run_with_environment_async(fresh_env(), run)


class TestSetTomlMCPConfigs:
    """ServerRegistry setTomlMCPConfigs tests."""

    async def test_sets_toml_configs_that_appear_in_load_all_servers(self):
        async def run():
            with _mock_server_data():
                registry = ServerRegistry.init()
                registry.set_no_builtin(True)
                registry.set_toml_mcp_configs({
                    "myTool": MCPConfig(command="node", args=["server.js"]),
                })
                await registry.load_all_servers()
                server = registry.get_server("myTool")
                assert server is not None
                assert server.id == "myTool"
                assert server.type == ServerType.CUSTOM
                assert server.command == "node"

        await run_with_environment_async(fresh_env(), run)

    async def test_toml_config_with_url_creates_server_entry(self):
        async def run():
            with _mock_server_data():
                registry = ServerRegistry.init()
                registry.set_no_builtin(True)
                registry.set_toml_mcp_configs({
                    "remoteTool": MCPConfig(url="https://example.com/mcp"),
                })
                await registry.load_all_servers()
                server = registry.get_server("remoteTool")
                assert server is not None
                assert server.url == "https://example.com/mcp"

        await run_with_environment_async(fresh_env(), run)


class TestLoadAllServers:
    """ServerRegistry loadAllServers tests."""

    async def test_does_not_reload_if_servers_already_loaded(self):
        async def run():
            with _mock_server_data():
                registry = ServerRegistry.init()
                registry.set_no_builtin(True)
                registry.set_toml_mcp_configs({
                    "first": MCPConfig(command="echo", args=["hi"]),
                })
                await registry.load_all_servers()
                assert registry.get_server("first") is not None

                # Second call should not clear existing servers
                registry.set_toml_mcp_configs({
                    "second": MCPConfig(command="echo", args=["bye"]),
                })
                await registry.load_all_servers()
                # 'first' should still be there (not reloaded)
                assert registry.get_server("first") is not None

        await run_with_environment_async(fresh_env(), run)


class TestGetAllServers:
    """ServerRegistry getAllServers tests."""

    async def test_returns_all_loaded_servers_as_list(self):
        async def run():
            with _mock_server_data():
                registry = ServerRegistry.init()
                registry.set_no_builtin(True)
                registry.set_toml_mcp_configs({
                    "alpha": MCPConfig(command="node", args=["a.js"]),
                    "beta": MCPConfig(command="node", args=["b.js"]),
                })
                await registry.load_all_servers()
                all_servers = registry.get_all_servers()
                assert len(all_servers) == 2
                ids = sorted(s.id for s in all_servers)
                assert ids == ["alpha", "beta"]

        await run_with_environment_async(fresh_env(), run)


class TestGetServer:
    """ServerRegistry getServer tests."""

    async def test_returns_none_for_non_existent_server(self):
        async def run():
            registry = ServerRegistry.init()
            assert registry.get_server("nonexistent") is None

        await run_with_environment_async(fresh_env(), run)


class TestDuplicateServerDetection:
    """ServerRegistry duplicate server detection tests."""

    async def test_throws_when_toml_config_conflicts_with_builtin_server(self):
        async def run():
            with _mock_server_data():
                registry = ServerRegistry.init()
                # Don't disable built-in — set a TOML config that conflicts
                registry.set_toml_mcp_configs({
                    "filesystem": MCPConfig(command="custom-fs"),
                })
                with pytest.raises(ConfigValidationError, match="MCP server conflict"):
                    await registry.load_all_servers()

        await run_with_environment_async(fresh_env(), run)


class TestServerTypeConstants:
    """ServerRegistry serverTypes constants tests."""

    def test_has_expected_server_type_values(self):
        assert ServerType.BUILTIN.value == "builtin"
        assert ServerType.CUSTOM.value == "custom"
        assert ServerType.BACKEND.value == "backend"
