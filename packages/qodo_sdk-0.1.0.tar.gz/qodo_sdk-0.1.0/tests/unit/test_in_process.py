"""Tests for the in-process graph runner."""

from __future__ import annotations

import asyncio
import sys
import uuid
from typing import Any, Dict, List
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from qodo.mcp.types import ToolResult
from qodo.sdk.events import SdkEventType


# ---------------------------------------------------------------------------
# Module-level mocking for langgraph and command backend
# ---------------------------------------------------------------------------

# We need to inject mock modules for langgraph and command.* before
# importing InProcessGraphRunner, since it does lazy imports.

_mock_memory_saver = MagicMock()

# Create mock module structure for langgraph
_langgraph_memory_mod = MagicMock()
_langgraph_memory_mod.MemorySaver = _mock_memory_saver

# Create mock module structure for command.agents
_mock_agent_type = MagicMock()
_mock_agent_type.SDK = "sdk"

_mock_consts_mod = MagicMock()
_mock_consts_mod.AgentType = _mock_agent_type

# TaskStatus mock
_mock_task_status = MagicMock()
_mock_task_status.Completed.name = "Completed"
_mock_task_status.Failed.name = "Failed"
_mock_task_status.Exception.name = "Exception"
_mock_consts_mod.TaskStatus = _mock_task_status


class FakeStateSnapshot:
    """Simulates the state snapshot returned by graph.aget_state()."""
    def __init__(self, next_nodes, values):
        self.next = next_nodes
        self.values = values


class FakeGraphOrchestrator:
    """Simulates the GraphOrchestrator from command backend."""
    def __init__(self, graph, session_id, debug=False):
        self.graph = graph
        self.session_id = session_id
        self.debug = debug
        self._initial_state = None

    async def start(self, state):
        self._initial_state = state
        if hasattr(self.graph, 'start_responses'):
            for resp in self.graph.start_responses:
                yield resp

    async def resume(self, updated_state, as_node=None):
        if hasattr(self.graph, 'resume_responses'):
            for resp in self.graph.resume_responses:
                yield resp

    async def get_current_state(self):
        if hasattr(self.graph, 'get_state'):
            return self.graph.get_state()
        return FakeStateSnapshot(next_nodes=(), values={"status": "Completed"})


_mock_orchestrator_mod = MagicMock()
_mock_orchestrator_mod.GraphOrchestrator = FakeGraphOrchestrator


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_mock_mcp_manager(
    tool_result: ToolResult | None = None,
    all_tools: Dict[str, list] | None = None,
) -> MagicMock:
    """Create a mock MCPManager."""
    mgr = MagicMock()
    mgr.call_tool = AsyncMock(
        return_value=tool_result or ToolResult(
            content=[{"type": "text", "text": "tool output"}],
            is_error=False,
        )
    )
    mgr.get_all_tools = MagicMock(return_value=all_tools or {})
    mgr.get_enabled_tools = MagicMock(return_value={})
    return mgr


def _make_simple_graph(final_state=None):
    """Create a simple fake graph that completes immediately."""
    class SimpleGraph:
        start_responses = []
        resume_responses = []

        def __init__(self):
            self._state = final_state or {"status": "Completed"}

        def get_state(self):
            return FakeStateSnapshot(next_nodes=(), values=self._state)

    return SimpleGraph()


def _make_interrupting_graph(
    tool_call_id="tc_123",
    tool_name="shell_execute",
    tool_args=None,
    server_name="shell",
    final_state=None,
):
    """Create a graph that interrupts once for a tool call, then completes."""
    tool_args = tool_args or {"command": "ls"}

    class InterruptingGraph:
        start_responses = []
        resume_responses = []

        def __init__(self):
            self._call_count = 0
            self._final_state = final_state or {"status": "Completed"}

        def get_state(self):
            self._call_count += 1
            if self._call_count == 1:
                # First call: return interrupted state with tool call
                tool_call = {"id": tool_call_id, "name": tool_name, "args": tool_args}
                ai_msg = MagicMock()
                ai_msg.tool_calls = [tool_call]
                ai_msg.content = "Let me execute a tool"
                return FakeStateSnapshot(
                    next_nodes=("ide_tool",),
                    values={
                        **self._final_state,
                        "messages": [ai_msg],
                        "available_tools": {server_name: [{"name": tool_name}]},
                    },
                )
            # Second call: completed
            return FakeStateSnapshot(next_nodes=(), values=self._final_state)

    return InterruptingGraph()


# Mock for langchain_core.messages.ToolMessage
class FakeToolMessage:
    """Simulates langchain_core.messages.ToolMessage."""
    def __init__(self, content="", tool_call_id="", additional_kwargs=None, **kwargs):
        self.content = content
        self.tool_call_id = tool_call_id
        self.additional_kwargs = additional_kwargs or {}

_mock_lc_messages_mod = MagicMock()
_mock_lc_messages_mod.ToolMessage = FakeToolMessage

# Patch targets for lazy imports in in_process.py
PATCH_TARGETS = {
    "langgraph.checkpoint.memory": _langgraph_memory_mod,
    "langgraph.checkpoint": MagicMock(),
    "langgraph": MagicMock(),
    "langchain_core": MagicMock(),
    "langchain_core.messages": _mock_lc_messages_mod,
    "command": MagicMock(),
    "command.agents": MagicMock(),
    "command.agents.consts": _mock_consts_mod,
    "command.agents.graphs": MagicMock(),
    "command.agents.graphs.graph_orchestrator": _mock_orchestrator_mod,
}


def _apply_module_patches():
    """Install mock modules into sys.modules for testing."""
    saved = {}
    for mod_name, mock_mod in PATCH_TARGETS.items():
        saved[mod_name] = sys.modules.get(mod_name)
        sys.modules[mod_name] = mock_mod
    return saved


def _remove_module_patches(saved):
    """Restore original sys.modules entries."""
    for mod_name, original in saved.items():
        if original is None:
            sys.modules.pop(mod_name, None)
        else:
            sys.modules[mod_name] = original


@pytest.fixture(autouse=True)
def mock_external_modules():
    """Automatically mock langgraph and command modules for all tests in this file."""
    saved = _apply_module_patches()
    yield
    _remove_module_patches(saved)


# Now import after fixture setup (but since autouse is per-test,
# we import at module level and rely on the fixture patching sys.modules)
from qodo.api.in_process import InProcessGraphRunner


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestInProcessGraphRunnerInit:
    """Test InProcessGraphRunner construction."""

    def test_init(self):
        mgr = _make_mock_mcp_manager()
        runner = InProcessGraphRunner(
            graph_builder=lambda cp: None,
            mcp_manager=mgr,
        )
        assert runner._graph_builder is not None
        assert runner._mcp_manager is mgr
        assert runner._auto_approve_tools is True

    def test_init_custom_auto_approve(self):
        mgr = _make_mock_mcp_manager()
        runner = InProcessGraphRunner(
            graph_builder=lambda cp: None,
            mcp_manager=mgr,
            auto_approve_tools=False,
        )
        assert runner._auto_approve_tools is False


class TestInProcessGraphRunnerExecution:
    """Test the execute() method and event emission."""

    @pytest.mark.asyncio
    async def test_basic_execution_emits_init_run_started_final(self):
        """A simple graph run should emit init, run.started, and final events."""
        graph = _make_simple_graph(
            final_state={"status": "Completed", "custom_model": "gpt-4"},
        )
        mgr = _make_mock_mcp_manager()
        runner = InProcessGraphRunner(
            graph_builder=lambda cp: graph,
            mcp_manager=mgr,
        )

        events = []
        async for event in runner.execute(
            command_config=MagicMock(name="test_cmd"),
            session_id="sess_1",
            workspace_path="/tmp/test",
            user_request="Hello",
            available_tools={},
        ):
            events.append(event)

        event_types = [e.type for e in events]
        assert SdkEventType.INIT in event_types
        assert SdkEventType.RUN_STARTED in event_types
        assert SdkEventType.FINAL in event_types

        # Final event should be last
        assert events[-1].type == SdkEventType.FINAL
        assert events[-1].data.success is True

    @pytest.mark.asyncio
    async def test_tool_interrupt_emits_tool_events(self):
        """When the graph interrupts for a tool, tool events should be emitted."""
        graph = _make_interrupting_graph(
            final_state={"status": "Completed"},
        )
        tool_result = ToolResult(
            content=[{"type": "text", "text": "file1.py\nfile2.py"}],
            is_error=False,
        )
        mgr = _make_mock_mcp_manager(tool_result=tool_result)
        runner = InProcessGraphRunner(
            graph_builder=lambda cp: graph,
            mcp_manager=mgr,
        )

        events = []
        async for event in runner.execute(
            command_config=MagicMock(name=""),
            session_id="sess_2",
            workspace_path="/tmp/test",
            user_request="List files",
            available_tools={"shell": [{"name": "shell_execute"}]},
        ):
            events.append(event)

        event_types = [e.type for e in events]

        # Should have tool lifecycle events
        assert SdkEventType.TOOL_REQUESTED in event_types
        assert SdkEventType.TOOL_APPROVED in event_types
        assert SdkEventType.TOOL_EXECUTED in event_types
        assert SdkEventType.FINAL in event_types

        # Tool executed event should contain result
        tool_exec = [e for e in events if e.type == SdkEventType.TOOL_EXECUTED][0]
        assert tool_exec.data.tool_name == "shell_execute"
        assert tool_exec.data.result["isError"] is False

        # MCPManager.call_tool should have been called
        mgr.call_tool.assert_awaited_once_with("shell", "shell_execute", {"command": "ls"})

    @pytest.mark.asyncio
    async def test_tool_failure_emits_error_result(self):
        """When a tool execution fails, the error should be captured in tool.executed."""
        graph = _make_interrupting_graph(
            final_state={"status": "Completed"},
        )
        mgr = _make_mock_mcp_manager()
        mgr.call_tool = AsyncMock(side_effect=RuntimeError("connection refused"))

        runner = InProcessGraphRunner(
            graph_builder=lambda cp: graph,
            mcp_manager=mgr,
        )

        events = []
        async for event in runner.execute(
            command_config=MagicMock(name=""),
            session_id="sess_3",
            workspace_path="/tmp/test",
            user_request="Run something",
            available_tools={"shell": [{"name": "shell_execute"}]},
        ):
            events.append(event)

        # Should still have tool.executed with isError=True
        tool_exec = [e for e in events if e.type == SdkEventType.TOOL_EXECUTED][0]
        assert tool_exec.data.result["isError"] is True
        assert "connection refused" in tool_exec.data.result["content"][0]["text"]

    @pytest.mark.asyncio
    async def test_graph_failure_emits_error_and_final(self):
        """When the graph builder raises, error + final should be emitted."""

        def failing_builder(checkpointer):
            raise RuntimeError("Graph construction failed")

        mgr = _make_mock_mcp_manager()
        runner = InProcessGraphRunner(graph_builder=failing_builder, mcp_manager=mgr)

        events = []
        async for event in runner.execute(
            command_config=MagicMock(name=""),
            session_id="sess_4",
            workspace_path="/tmp/test",
            user_request="Fail",
            available_tools={},
        ):
            events.append(event)

        event_types = [e.type for e in events]
        assert SdkEventType.INIT in event_types
        assert SdkEventType.RUN_STARTED in event_types
        assert SdkEventType.ERROR in event_types
        assert SdkEventType.FINAL in event_types

        final = events[-1]
        assert final.data.success is False
        assert "Graph construction failed" in final.data.error

    @pytest.mark.asyncio
    async def test_event_sequence_numbers_are_monotonic(self):
        """Event sequence numbers should be strictly increasing."""
        graph = _make_simple_graph(final_state={"status": "Completed"})
        mgr = _make_mock_mcp_manager()
        runner = InProcessGraphRunner(
            graph_builder=lambda cp: graph,
            mcp_manager=mgr,
        )

        events = []
        async for event in runner.execute(
            command_config=MagicMock(name=""),
            session_id="sess_5",
            workspace_path="/tmp/test",
            user_request="Hello",
            available_tools={},
        ):
            events.append(event)

        seqs = [e.seq for e in events]
        for i in range(1, len(seqs)):
            assert seqs[i] > seqs[i - 1], f"Seq {seqs[i]} not > {seqs[i-1]}"

    @pytest.mark.asyncio
    async def test_all_events_share_same_session_id(self):
        """All events in a run should share the same session_id."""
        graph = _make_simple_graph()
        mgr = _make_mock_mcp_manager()
        runner = InProcessGraphRunner(
            graph_builder=lambda cp: graph,
            mcp_manager=mgr,
        )

        events = []
        async for event in runner.execute(
            command_config=MagicMock(name=""),
            session_id="sess_shared",
            workspace_path="/tmp/test",
            user_request="Hello",
            available_tools={},
        ):
            events.append(event)

        for event in events:
            assert event.session_id == "sess_shared"

    @pytest.mark.asyncio
    async def test_optional_fields_in_initial_state(self):
        """Optional fields (output_schema, custom_model, etc.) should be passed to graph."""
        orchestrator_instances = []
        original_init = FakeGraphOrchestrator.__init__

        def capturing_init(self_orch, graph, session_id, debug=False):
            original_init(self_orch, graph, session_id, debug)
            orchestrator_instances.append(self_orch)

        graph = _make_simple_graph()
        mgr = _make_mock_mcp_manager()
        runner = InProcessGraphRunner(
            graph_builder=lambda cp: graph,
            mcp_manager=mgr,
        )

        with patch.object(FakeGraphOrchestrator, '__init__', capturing_init):
            events = []
            async for event in runner.execute(
                command_config=MagicMock(name=""),
                session_id="sess_6",
                workspace_path="/tmp/test",
                user_request="Hello",
                available_tools={},
                output_schema={"type": "object"},
                custom_model="gpt-4-turbo",
                instructions="Be helpful",
                system_prompt="You are a reviewer",
                execution_strategy="plan",
            ):
                events.append(event)

        assert len(orchestrator_instances) == 1
        orch = orchestrator_instances[0]
        state = orch._initial_state
        assert state is not None
        assert state["output_schema"] == {"type": "object"}
        assert state["custom_model"] == "gpt-4-turbo"
        assert state["instructions"] == "Be helpful"
        assert state["system_prompt"] == "You are a reviewer"
        assert state["execution_strategy"] == "plan"


class TestQodoSDKFromInProcess:
    """Test the QodoSDK.from_in_process factory method."""

    def test_from_in_process_creates_instance(self):
        from qodo import QodoSDK

        sdk = QodoSDK.from_in_process(
            graph_builder=lambda cp: None,
            project_path="/tmp/test",
            model="gpt-4",
        )

        assert sdk._use_in_process is True
        assert sdk._graph_builder is not None
        assert sdk._options.project_path == "/tmp/test"
        assert sdk._options.model == "gpt-4"

    def test_from_in_process_does_not_affect_standard_path(self):
        """Standard SDK instances should not have in-process runner."""
        from qodo import QodoSDK

        sdk = QodoSDK(project_path="/tmp/test")
        assert sdk._use_in_process is False
        assert sdk._in_process_runner is None
        assert sdk._graph_builder is None


class TestInProcessGraphRunnerImports:
    """Test that InProcessGraphRunner is importable from public API."""

    def test_import_from_qodo(self):
        from qodo import InProcessGraphRunner
        assert InProcessGraphRunner is not None

    def test_import_from_api(self):
        from qodo.api import InProcessGraphRunner
        assert InProcessGraphRunner is not None

    def test_import_from_module(self):
        from qodo.api.in_process import InProcessGraphRunner
        assert InProcessGraphRunner is not None
