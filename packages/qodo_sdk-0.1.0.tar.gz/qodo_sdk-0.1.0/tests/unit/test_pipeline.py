"""Tests for Pipeline DSL — builder, runner, gates, and error strategies."""

from __future__ import annotations

import asyncio
from typing import Any, Dict

import pytest

from qodo.errors import PipelineExecutionError
from qodo.sdk.pipeline import (
    Pipeline,
    PipelineBuilder,
    PipelineResult,
    run_pipeline,
    sdk_pipeline,
)
from qodo.sdk.pipeline.types import ParallelGroup, PipelineStep, StepContext


# ---------------------------------------------------------------------------
# Mock SDK
# ---------------------------------------------------------------------------

class MockSDK:
    def __init__(self, run_impl=None):
        self._run_impl = run_impl

    async def run(self, command, **kwargs):
        if self._run_impl:
            return await self._run_impl(command, **kwargs)
        return type(
            "Result",
            (),
            {
                "success": True,
                "model": "mock",
                "result": {"final_output": "mock output"},
                "messages": {"langchain": [], "openai": []},
                "meta": {"tools_auto_approved": True, "subagents_used": False},
            },
        )()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

async def noop_step(ctx: StepContext) -> Dict[str, Any]:
    return {}


async def make_step(key: str, value: Any):
    async def step_fn(ctx: StepContext) -> Dict[str, Any]:
        return {key: value}
    return step_fn


# ---------------------------------------------------------------------------
# TestPipelineBuilder
# ---------------------------------------------------------------------------

class TestPipelineBuilder:
    def test_creates_empty_pipeline(self):
        pipeline = sdk_pipeline().build()
        assert isinstance(pipeline, Pipeline)
        assert len(pipeline.entries) == 0

    def test_step_adds_entries(self):
        pipeline = sdk_pipeline().step("a", noop_step).step("b", noop_step).build()
        assert len(pipeline.entries) == 2
        assert isinstance(pipeline.entries[0], PipelineStep)
        assert pipeline.entries[0].name == "a"
        assert pipeline.entries[1].name == "b"

    def test_parallel_adds_group(self):
        pipeline = sdk_pipeline().parallel([
            {"name": "x", "fn": noop_step},
            {"name": "y", "fn": noop_step},
        ]).build()
        assert len(pipeline.entries) == 1
        entry = pipeline.entries[0]
        assert isinstance(entry, ParallelGroup)
        assert entry.kind == "parallel"
        assert len(entry.steps) == 2

    def test_builder_is_immutable(self):
        b1 = sdk_pipeline()
        b2 = b1.step("a", noop_step)
        b3 = b2.step("b", noop_step)
        assert b1 is not b2
        assert b2 is not b3
        assert isinstance(b1, PipelineBuilder)
        assert isinstance(b2, PipelineBuilder)
        assert len(b1.build().entries) == 0
        assert len(b2.build().entries) == 1
        assert len(b3.build().entries) == 2

    def test_build_returns_frozen_entries(self):
        pipeline = sdk_pipeline().step("a", noop_step).build()
        assert isinstance(pipeline.entries, tuple)


# ---------------------------------------------------------------------------
# TestSequentialSteps
# ---------------------------------------------------------------------------

class TestSequentialSteps:
    async def test_runs_steps_in_order_and_threads_state(self):
        order: list[str] = []

        async def step_a(ctx: StepContext) -> Dict[str, Any]:
            order.append("a")
            return {"from_a": 1}

        async def step_b(ctx: StepContext) -> Dict[str, Any]:
            order.append("b")
            assert ctx.state["from_a"] == 1
            return {"from_b": 2}

        pipeline = sdk_pipeline().step("a", step_a).step("b", step_b).build()
        result = await run_pipeline(MockSDK(), pipeline, {"init": True})

        assert order == ["a", "b"]
        assert result.state["init"] is True
        assert result.state["from_a"] == 1
        assert result.state["from_b"] == 2

    async def test_step_receives_run_that_delegates_to_sdk(self):
        calls: list[str] = []

        async def mock_run(cmd, **kwargs):
            calls.append(cmd)
            return "ok"

        sdk = MockSDK(run_impl=mock_run)

        async def step_fn(ctx: StepContext) -> Dict[str, Any]:
            await ctx.run("test-command")
            return {}

        pipeline = sdk_pipeline().step("s", step_fn).build()
        await run_pipeline(sdk, pipeline, {})
        assert calls == ["test-command"]

    async def test_step_context_includes_step_name(self):
        captured_name = None

        async def step_fn(ctx: StepContext) -> Dict[str, Any]:
            nonlocal captured_name
            captured_name = ctx.step_name
            return {}

        pipeline = sdk_pipeline().step("my-step", step_fn).build()
        await run_pipeline(MockSDK(), pipeline, {})
        assert captured_name == "my-step"

    async def test_empty_pipeline_returns_initial_state(self):
        pipeline = sdk_pipeline().build()
        result = await run_pipeline(MockSDK(), pipeline, {"key": "value"})
        assert result.state == {"key": "value"}
        assert result.steps == []


# ---------------------------------------------------------------------------
# TestParallelSteps
# ---------------------------------------------------------------------------

class TestParallelSteps:
    async def test_parallel_steps_merge_outputs(self):
        async def step_x(ctx: StepContext) -> Dict[str, Any]:
            return {"x": 10}

        async def step_y(ctx: StepContext) -> Dict[str, Any]:
            return {"y": 20}

        pipeline = sdk_pipeline().parallel([
            {"name": "x", "fn": step_x},
            {"name": "y", "fn": step_y},
        ]).build()

        result = await run_pipeline(MockSDK(), pipeline, {})
        assert result.state["x"] == 10
        assert result.state["y"] == 20

    async def test_parallel_steps_receive_same_state_snapshot(self):
        received_states: list[Dict[str, Any]] = []

        async def capture_state(ctx: StepContext) -> Dict[str, Any]:
            received_states.append(dict(ctx.state))
            return {}

        pipeline = sdk_pipeline().parallel([
            {"name": "a", "fn": capture_state},
            {"name": "b", "fn": capture_state},
        ]).build()

        await run_pipeline(MockSDK(), pipeline, {"shared": 42})
        assert len(received_states) == 2
        assert received_states[0] == {"shared": 42}
        assert received_states[1] == {"shared": 42}


# ---------------------------------------------------------------------------
# TestGates
# ---------------------------------------------------------------------------

class TestGates:
    async def test_step_skipped_when_gate_false(self):
        async def step_fn(ctx: StepContext) -> Dict[str, Any]:
            return {"ran": True}

        pipeline = sdk_pipeline().step(
            "gated", step_fn, gate=lambda state: False
        ).build()

        result = await run_pipeline(MockSDK(), pipeline, {})
        assert "ran" not in result.state
        assert len(result.steps) == 1
        assert result.steps[0].status == "skipped"

    async def test_step_executes_when_gate_true(self):
        async def step_fn(ctx: StepContext) -> Dict[str, Any]:
            return {"ran": True}

        pipeline = sdk_pipeline().step(
            "gated", step_fn, gate=lambda state: True
        ).build()

        result = await run_pipeline(MockSDK(), pipeline, {})
        assert result.state["ran"] is True
        assert result.steps[0].status == "completed"

    async def test_async_gate_supported(self):
        async def async_gate(state: Dict[str, Any]) -> bool:
            return state.get("allow", False)

        async def step_fn(ctx: StepContext) -> Dict[str, Any]:
            return {"ran": True}

        pipeline = sdk_pipeline().step("gated", step_fn, gate=async_gate).build()

        result_blocked = await run_pipeline(MockSDK(), pipeline, {"allow": False})
        assert "ran" not in result_blocked.state
        assert result_blocked.steps[0].status == "skipped"

        result_allowed = await run_pipeline(MockSDK(), pipeline, {"allow": True})
        assert result_allowed.state["ran"] is True
        assert result_allowed.steps[0].status == "completed"

    async def test_gate_exception_causes_skip(self):
        def bad_gate(state: Dict[str, Any]) -> bool:
            raise ValueError("gate error")

        async def step_fn(ctx: StepContext) -> Dict[str, Any]:
            return {"ran": True}

        pipeline = sdk_pipeline().step("gated", step_fn, gate=bad_gate).build()

        result = await run_pipeline(MockSDK(), pipeline, {})
        assert "ran" not in result.state
        assert result.steps[0].status == "skipped"

    async def test_parallel_step_with_gate_skipped_individually(self):
        async def step_a(ctx: StepContext) -> Dict[str, Any]:
            return {"a": 1}

        async def step_b(ctx: StepContext) -> Dict[str, Any]:
            return {"b": 2}

        pipeline = sdk_pipeline().parallel([
            {"name": "a", "fn": step_a, "gate": lambda state: True},
            {"name": "b", "fn": step_b, "gate": lambda state: False},
        ]).build()

        result = await run_pipeline(MockSDK(), pipeline, {})
        assert result.state["a"] == 1
        assert "b" not in result.state
        assert len(result.steps) == 2

        statuses = {s.name: s.status for s in result.steps}
        assert statuses["a"] == "completed"
        assert statuses["b"] == "skipped"


# ---------------------------------------------------------------------------
# TestErrorHandling
# ---------------------------------------------------------------------------

class TestErrorHandling:
    async def test_default_throw_aborts_pipeline(self):
        async def bad_step(ctx: StepContext) -> Dict[str, Any]:
            raise RuntimeError("boom")

        async def after_step(ctx: StepContext) -> Dict[str, Any]:
            return {"after": True}

        pipeline = (
            sdk_pipeline()
            .step("bad", bad_step)
            .step("after", after_step)
            .build()
        )

        with pytest.raises(PipelineExecutionError) as exc_info:
            await run_pipeline(MockSDK(), pipeline, {})

        assert exc_info.value.step_name == "bad"
        assert exc_info.value.cause is not None

    async def test_skip_continues_with_existing_state(self):
        async def bad_step(ctx: StepContext) -> Dict[str, Any]:
            raise RuntimeError("boom")

        async def after_step(ctx: StepContext) -> Dict[str, Any]:
            return {"after": True}

        pipeline = (
            sdk_pipeline()
            .step("bad", bad_step, on_error="skip")
            .step("after", after_step)
            .build()
        )

        result = await run_pipeline(MockSDK(), pipeline, {"init": 1})
        assert result.state["init"] == 1
        assert result.state["after"] is True
        assert result.steps[0].status == "skipped"
        assert result.steps[0].error is not None
        assert result.steps[1].status == "completed"

    async def test_custom_recovery_provides_replacement(self):
        async def bad_step(ctx: StepContext) -> Dict[str, Any]:
            raise RuntimeError("boom")

        def recover(err: Exception, state: Dict[str, Any]) -> Dict[str, Any]:
            return {"recovered": True}

        pipeline = sdk_pipeline().step("bad", bad_step, on_error=recover).build()

        result = await run_pipeline(MockSDK(), pipeline, {})
        assert result.state["recovered"] is True
        assert result.steps[0].status == "completed"

    async def test_custom_recovery_that_throws_wraps_error(self):
        async def bad_step(ctx: StepContext) -> Dict[str, Any]:
            raise RuntimeError("original")

        def bad_recovery(err: Exception, state: Dict[str, Any]) -> Dict[str, Any]:
            raise ValueError("recovery failed")

        pipeline = sdk_pipeline().step("bad", bad_step, on_error=bad_recovery).build()

        with pytest.raises(PipelineExecutionError) as exc_info:
            await run_pipeline(MockSDK(), pipeline, {})

        assert "recovery failed" in str(exc_info.value)
        assert exc_info.value.step_name == "bad"

    async def test_parallel_step_failure_aborts_group(self):
        async def good_step(ctx: StepContext) -> Dict[str, Any]:
            return {"good": True}

        async def bad_step(ctx: StepContext) -> Dict[str, Any]:
            raise RuntimeError("parallel boom")

        pipeline = sdk_pipeline().parallel([
            {"name": "good", "fn": good_step},
            {"name": "bad", "fn": bad_step},
        ]).build()

        with pytest.raises(PipelineExecutionError) as exc_info:
            await run_pipeline(MockSDK(), pipeline, {})

        assert exc_info.value.step_name == "bad"

    async def test_parallel_step_with_skip_does_not_abort(self):
        async def good_step(ctx: StepContext) -> Dict[str, Any]:
            return {"good": True}

        async def bad_step(ctx: StepContext) -> Dict[str, Any]:
            raise RuntimeError("parallel boom")

        pipeline = sdk_pipeline().parallel([
            {"name": "good", "fn": good_step},
            {"name": "bad", "fn": bad_step, "on_error": "skip"},
        ]).build()

        result = await run_pipeline(MockSDK(), pipeline, {})
        assert result.state["good"] is True

        statuses = {s.name: s.status for s in result.steps}
        assert statuses["good"] == "completed"
        assert statuses["bad"] == "skipped"


# ---------------------------------------------------------------------------
# TestPipelineExecutionError
# ---------------------------------------------------------------------------

class TestPipelineExecutionError:
    def test_includes_step_name_and_cause(self):
        cause = ValueError("root cause")
        err = PipelineExecutionError(
            "step failed",
            step_name="deploy",
            cause=cause,
        )
        assert err.step_name == "deploy"
        assert err.cause is cause
        assert "step failed" in str(err)


# ---------------------------------------------------------------------------
# TestStepLogTiming
# ---------------------------------------------------------------------------

class TestStepLogTiming:
    async def test_duration_ms_recorded(self):
        async def slow_step(ctx: StepContext) -> Dict[str, Any]:
            await asyncio.sleep(0.05)
            return {}

        pipeline = sdk_pipeline().step("slow", slow_step).build()
        result = await run_pipeline(MockSDK(), pipeline, {})

        assert len(result.steps) == 1
        assert result.steps[0].duration_ms >= 40  # at least ~50ms minus jitter


# ---------------------------------------------------------------------------
# TestMixedPipeline
# ---------------------------------------------------------------------------

class TestMixedPipeline:
    async def test_sequential_parallel_sequential(self):
        order: list[str] = []

        async def step_a(ctx: StepContext) -> Dict[str, Any]:
            order.append("a")
            return {"a": 1}

        async def step_b(ctx: StepContext) -> Dict[str, Any]:
            order.append("b")
            return {"b": 2}

        async def step_c(ctx: StepContext) -> Dict[str, Any]:
            order.append("c")
            return {"c": 3}

        async def step_d(ctx: StepContext) -> Dict[str, Any]:
            order.append("d")
            assert ctx.state["a"] == 1
            assert ctx.state["b"] == 2
            assert ctx.state["c"] == 3
            return {"d": 4}

        pipeline = (
            sdk_pipeline()
            .step("a", step_a)
            .parallel([
                {"name": "b", "fn": step_b},
                {"name": "c", "fn": step_c},
            ])
            .step("d", step_d)
            .build()
        )

        result = await run_pipeline(MockSDK(), pipeline, {})

        assert order[0] == "a"
        assert "d" == order[-1]
        assert set(order[1:3]) == {"b", "c"}

        assert result.state == {"a": 1, "b": 2, "c": 3, "d": 4}
        assert len(result.steps) == 4
