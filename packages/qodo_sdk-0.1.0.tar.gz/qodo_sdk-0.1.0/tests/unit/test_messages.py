"""Tests for message types — mirrors messages.test.ts."""
from __future__ import annotations

import pytest

from qodo.context.message_manager import (
    AIMessage,
    HumanMessage,
    Message,
    MessageManager,
    ToolMessage,
    to_langchain_dict,
    to_openai_chat,
)


class TestInternalMessageTypes:
    """Internal message type construction and properties tests."""

    def test_message_stores_content_and_additional_kwargs(self):
        msg = Message(content="hello", additional_kwargs={"foo": "bar"})
        assert msg.content == "hello"
        assert msg.additional_kwargs == {"foo": "bar"}

    def test_message_defaults_additional_kwargs_to_empty_dict(self):
        msg = Message(content="hello")
        assert msg.additional_kwargs == {}

    def test_human_message_is_instance_of_message(self):
        msg = HumanMessage(content="hi")
        assert isinstance(msg, Message)
        assert isinstance(msg, HumanMessage)
        assert msg.content == "hi"

    def test_human_message_has_user_role(self):
        msg = HumanMessage(content="hi")
        assert msg.role == "user"

    def test_ai_message_is_instance_of_message(self):
        msg = AIMessage(content="response")
        assert isinstance(msg, Message)
        assert isinstance(msg, AIMessage)
        assert msg.content == "response"

    def test_ai_message_has_assistant_role(self):
        msg = AIMessage(content="response")
        assert msg.role == "assistant"

    def test_ai_message_constructed_with_additional_kwargs(self):
        msg = AIMessage(
            content="response",
            additional_kwargs={"id": "ai-1", "type": "progress"},
        )
        assert msg.content == "response"
        assert msg.additional_kwargs == {"id": "ai-1", "type": "progress"}

    def test_ai_message_defaults_tool_calls_to_none(self):
        msg = AIMessage(content="simple")
        assert msg.tool_calls is None

    def test_ai_message_with_tool_calls(self):
        msg = AIMessage(
            content="tool response",
            tool_calls=[
                {
                    "name": "shell_execute",
                    "args": {"cmd": "ls"},
                    "id": "tc1",
                    "type": "tool_call",
                }
            ],
            additional_kwargs={"server_name": "shell"},
        )
        assert msg.content == "tool response"
        assert msg.tool_calls is not None
        assert len(msg.tool_calls) == 1
        assert msg.tool_calls[0]["name"] == "shell_execute"
        assert msg.tool_calls[0]["id"] == "tc1"
        assert msg.additional_kwargs["server_name"] == "shell"

    def test_tool_message_stores_tool_call_id_and_content(self):
        msg = ToolMessage(
            content="file written",
            tool_call_id="tc1",
        )
        assert isinstance(msg, Message)
        assert isinstance(msg, ToolMessage)
        assert msg.tool_call_id == "tc1"
        assert msg.content == "file written"

    def test_tool_message_has_tool_role(self):
        msg = ToolMessage(content="result", tool_call_id="tc2")
        assert msg.role == "tool"

    def test_tool_message_preserves_additional_kwargs(self):
        msg = ToolMessage(
            content="result",
            tool_call_id="tc2",
            additional_kwargs={"server_name": "filesystem"},
        )
        assert msg.additional_kwargs["server_name"] == "filesystem"

    def test_isinstance_checks_are_mutually_exclusive(self):
        human = HumanMessage(content="a")
        ai = AIMessage(content="b")
        tool = ToolMessage(content="e", tool_call_id="d")

        # Each is only instanceof its own class (and Message)
        assert not isinstance(human, AIMessage)
        assert not isinstance(human, ToolMessage)

        assert not isinstance(ai, HumanMessage)
        assert not isinstance(ai, ToolMessage)

        assert not isinstance(tool, HumanMessage)
        assert not isinstance(tool, AIMessage)


class TestToDict:
    """Message to_dict conversion tests."""

    def test_human_message_to_dict(self):
        msg = HumanMessage(content="hello")
        d = msg.to_dict()
        assert d["role"] == "user"
        assert d["content"] == "hello"

    def test_ai_message_to_dict(self):
        msg = AIMessage(content="response")
        d = msg.to_dict()
        assert d["role"] == "assistant"
        assert d["content"] == "response"

    def test_ai_message_to_dict_with_tool_calls(self):
        msg = AIMessage(
            content="reasoning",
            tool_calls=[{"name": "shell", "args": {"cmd": "ls"}, "id": "tc1"}],
        )
        d = msg.to_dict()
        assert d["role"] == "assistant"
        assert "tool_calls" in d
        assert len(d["tool_calls"]) == 1

    def test_tool_message_to_dict(self):
        msg = ToolMessage(content="done", tool_call_id="tc1")
        d = msg.to_dict()
        assert d["role"] == "tool"
        assert d["tool_call_id"] == "tc1"
        assert d["content"] == "done"


class TestToOpenAIChat:
    """to_openai_chat conversion tests."""

    def test_converts_human_message_to_user_role(self):
        result = to_openai_chat([HumanMessage(content="hello")])
        assert result == [{"role": "user", "content": "hello"}]

    def test_converts_ai_message_to_assistant_role(self):
        result = to_openai_chat([AIMessage(content="response")])
        assert result == [{"role": "assistant", "content": "response"}]

    def test_converts_ai_message_with_tool_calls(self):
        msg = AIMessage(
            content="reasoning",
            tool_calls=[{"name": "shell", "args": {"cmd": "ls"}, "id": "tc1"}],
        )
        result = to_openai_chat([msg])
        assert result[0]["role"] == "assistant"
        assert result[0]["tool_calls"] is not None
        assert len(result[0]["tool_calls"]) == 1

    def test_converts_tool_message_to_tool_role(self):
        msg = ToolMessage(content="done", tool_call_id="tc1")
        result = to_openai_chat([msg])
        assert result[0]["role"] == "tool"
        assert result[0]["tool_call_id"] == "tc1"
        assert result[0]["content"] == "done"

    def test_handles_mixed_message_array(self):
        messages = [
            HumanMessage(content="question"),
            AIMessage(content="answer"),
            ToolMessage(content="tool result", tool_call_id="tc1"),
        ]
        result = to_openai_chat(messages)
        assert [r["role"] for r in result] == ["user", "assistant", "tool"]


class TestToLangChainDict:
    """to_langchain_dict conversion tests."""

    def test_maps_human_message_to_dict(self):
        result = to_langchain_dict([HumanMessage(content="hi")])
        assert result[0]["role"] == "user"
        assert result[0]["content"] == "hi"

    def test_maps_ai_message_to_dict_with_tool_calls(self):
        msg = AIMessage(
            content="reasoning",
            tool_calls=[{"name": "run", "args": {"x": 1}, "id": "tc1", "type": "tool_call"}],
            additional_kwargs={"custom": "x"},
        )
        result = to_langchain_dict([msg])
        assert result[0]["role"] == "assistant"
        assert result[0]["content"] == "reasoning"
        assert "tool_calls" in result[0]

    def test_maps_tool_message_to_dict(self):
        msg = ToolMessage(
            content="ok",
            tool_call_id="tc1",
            additional_kwargs={"status": "success"},
        )
        result = to_langchain_dict([msg])
        assert result[0]["role"] == "tool"
        assert result[0]["tool_call_id"] == "tc1"
        assert result[0]["content"] == "ok"


class TestMessageManager:
    """MessageManager core functionality tests."""

    def test_add_message_and_get_messages(self):
        mm = MessageManager()
        mm.add_message(HumanMessage(content="test"))
        messages = mm.get_messages()
        assert len(messages) == 1
        assert messages[0].content == "test"

    def test_get_last_message(self):
        mm = MessageManager()
        mm.add_message(HumanMessage(content="first"))
        mm.add_message(AIMessage(content="second"))
        last = mm.get_last_message()
        assert len(last) == 1
        assert last[0].content == "second"

    def test_get_last_ai_message(self):
        mm = MessageManager()
        mm.add_message(HumanMessage(content="question"))
        mm.add_message(AIMessage(content="answer"))
        mm.add_message(HumanMessage(content="follow up"))
        last_ai = mm.get_last_ai_message()
        assert last_ai is not None
        assert last_ai.content == "answer"

    def test_loading_state(self):
        mm = MessageManager()
        assert mm.get_is_loading() is False
        mm.set_loading(True)
        assert mm.get_is_loading() is True
        mm.set_loading(False)
        assert mm.get_is_loading() is False

    def test_error_state(self):
        mm = MessageManager()
        assert mm.get_error() is None
        mm.set_error("Something went wrong")
        assert mm.get_error() == "Something went wrong"
        mm.set_error(None)
        assert mm.get_error() is None

    def test_reset_clears_all_state(self):
        mm = MessageManager()
        mm.add_message(HumanMessage(content="test"))
        mm.set_loading(True)
        mm.set_error("error")
        mm.reset()
        assert mm.get_messages() == []
        assert mm.get_is_loading() is False
        assert mm.get_error() is None

    def test_message_listener_notification(self):
        mm = MessageManager()
        received = []

        def listener(messages):
            received.append(list(messages))

        mm.add_message_listener(listener)
        mm.add_message(HumanMessage(content="hello"))

        assert len(received) == 1
        assert received[0][0].content == "hello"

    def test_listener_unsubscribe(self):
        mm = MessageManager()
        call_count = 0

        def listener(messages):
            nonlocal call_count
            call_count += 1

        unsubscribe = mm.add_message_listener(listener)
        mm.add_message(HumanMessage(content="first"))
        assert call_count == 1

        unsubscribe()
        mm.add_message(HumanMessage(content="second"))
        assert call_count == 1  # Not incremented after unsubscribe
