"""
Tests for qodo.sdk.middleware — ToolMiddleware protocol and utilities.
"""
from __future__ import annotations

import asyncio
from typing import Any

import pytest

from qodo.errors import QodoToolError, ToolMiddlewareError
from qodo.sdk.middleware import (
    MIDDLEWARE_TIMEOUT_MS,
    PROTECTED_TOOL_FIELDS,
    ToolMiddleware,
    strip_protected_fields,
    with_timeout,
)


# ---------------------------------------------------------------------------
# strip_protected_fields
# ---------------------------------------------------------------------------

class TestStripProtectedFields:
    def test_preserves_protected_fields_from_original(self) -> None:
        original = {"identifier": "abc", "server_name": "srv", "foo": "bar"}
        modified = {"identifier": "CHANGED", "server_name": "CHANGED", "foo": "baz"}
        result = strip_protected_fields(original, modified)
        assert result["identifier"] == "abc"
        assert result["server_name"] == "srv"
        assert result["foo"] == "baz"

    def test_preserves_session_id(self) -> None:
        original = {"session_id": "s1", "data": 1}
        modified = {"session_id": "s2", "data": 2}
        result = strip_protected_fields(original, modified)
        assert result["session_id"] == "s1"
        assert result["data"] == 2

    def test_copies_non_protected_fields(self) -> None:
        original = {"identifier": "abc", "x": 1}
        modified = {"identifier": "CHANGED", "x": 99, "new_field": True}
        result = strip_protected_fields(original, modified)
        assert result["x"] == 99
        assert result["new_field"] is True

    def test_returns_original_when_modified_is_none(self) -> None:
        original = {"identifier": "abc", "foo": "bar"}
        result = strip_protected_fields(original, None)  # type: ignore[arg-type]
        assert result is original

    def test_removes_protected_field_not_in_original(self) -> None:
        original = {"foo": "bar"}
        modified = {"foo": "baz", "identifier": "injected"}
        result = strip_protected_fields(original, modified)
        assert "identifier" not in result
        assert result["foo"] == "baz"

    def test_empty_dicts(self) -> None:
        result = strip_protected_fields({}, {})
        assert result == {}

    def test_original_has_no_protected_fields(self) -> None:
        original = {"a": 1, "b": 2}
        modified = {"a": 10, "b": 20, "c": 30}
        result = strip_protected_fields(original, modified)
        assert result == {"a": 10, "b": 20, "c": 30}

    def test_all_three_protected_fields(self) -> None:
        original = {
            "identifier": "id1",
            "server_name": "srv1",
            "session_id": "sess1",
            "data": "original",
        }
        modified = {
            "identifier": "id2",
            "server_name": "srv2",
            "session_id": "sess2",
            "data": "modified",
        }
        result = strip_protected_fields(original, modified)
        assert result["identifier"] == "id1"
        assert result["server_name"] == "srv1"
        assert result["session_id"] == "sess1"
        assert result["data"] == "modified"

    def test_does_not_mutate_original(self) -> None:
        original = {"identifier": "abc", "foo": "bar"}
        modified = {"identifier": "CHANGED", "foo": "baz"}
        strip_protected_fields(original, modified)
        assert original == {"identifier": "abc", "foo": "bar"}

    def test_does_not_mutate_modified(self) -> None:
        original = {"identifier": "abc"}
        modified = {"identifier": "CHANGED", "foo": "baz"}
        modified_copy = dict(modified)
        strip_protected_fields(original, modified)
        assert modified == modified_copy


# ---------------------------------------------------------------------------
# with_timeout
# ---------------------------------------------------------------------------

class TestWithTimeout:
    async def test_completes_normally(self) -> None:
        async def quick() -> str:
            return "done"

        result = await with_timeout(quick(), timeout_ms=5000, label="quick")
        assert result == "done"

    async def test_raises_on_timeout(self) -> None:
        async def slow() -> None:
            await asyncio.sleep(10)

        with pytest.raises(ToolMiddlewareError, match="timed out"):
            await with_timeout(slow(), timeout_ms=50, label="slow_op")

    async def test_timeout_error_attributes(self) -> None:
        async def slow() -> None:
            await asyncio.sleep(10)

        try:
            await with_timeout(slow(), timeout_ms=50, label="my_mw")
        except ToolMiddlewareError as e:
            assert e.middleware_name == "my_mw"
            assert e.phase == "timeout"
            assert isinstance(e.cause, asyncio.TimeoutError)
        else:
            pytest.fail("Expected ToolMiddlewareError")

    async def test_default_timeout_constant(self) -> None:
        assert MIDDLEWARE_TIMEOUT_MS == 10_000

    async def test_returns_coroutine_result(self) -> None:
        async def returns_42() -> int:
            return 42

        assert await with_timeout(returns_42()) == 42

    async def test_propagates_exception(self) -> None:
        async def raises() -> None:
            raise ValueError("boom")

        with pytest.raises(ValueError, match="boom"):
            await with_timeout(raises(), timeout_ms=5000)

    async def test_zero_timeout_raises(self) -> None:
        async def instant() -> str:
            return "ok"

        # A zero-ms timeout will race — it may or may not complete.
        # We just verify it doesn't hang and returns either a result
        # or raises ToolMiddlewareError.
        try:
            result = await with_timeout(instant(), timeout_ms=0)
            assert result == "ok"
        except ToolMiddlewareError:
            pass  # also acceptable


# ---------------------------------------------------------------------------
# ToolMiddlewareError
# ---------------------------------------------------------------------------

class TestToolMiddlewareError:
    def test_stores_attributes(self) -> None:
        cause = RuntimeError("root")
        err = ToolMiddlewareError(
            "failed",
            middleware_name="MyMW",
            phase="pre_execute",
            cause=cause,
        )
        assert str(err) == "failed"
        assert err.middleware_name == "MyMW"
        assert err.phase == "pre_execute"
        assert err.cause is cause

    def test_is_subclass_of_qodo_tool_error(self) -> None:
        err = ToolMiddlewareError("test")
        assert isinstance(err, QodoToolError)

    def test_default_attributes(self) -> None:
        err = ToolMiddlewareError("msg")
        assert err.middleware_name == ""
        assert err.phase == ""
        assert err.cause is None

    def test_inherits_from_exception(self) -> None:
        err = ToolMiddlewareError("msg")
        assert isinstance(err, Exception)

    def test_catchable_as_qodo_tool_error(self) -> None:
        try:
            raise ToolMiddlewareError("test", middleware_name="A")
        except QodoToolError as e:
            assert isinstance(e, ToolMiddlewareError)


# ---------------------------------------------------------------------------
# PROTECTED_TOOL_FIELDS constant
# ---------------------------------------------------------------------------

class TestProtectedToolFields:
    def test_is_frozenset(self) -> None:
        assert isinstance(PROTECTED_TOOL_FIELDS, frozenset)

    def test_contains_expected_fields(self) -> None:
        assert "identifier" in PROTECTED_TOOL_FIELDS
        assert "server_name" in PROTECTED_TOOL_FIELDS
        assert "session_id" in PROTECTED_TOOL_FIELDS

    def test_has_exactly_three_fields(self) -> None:
        assert len(PROTECTED_TOOL_FIELDS) == 3


# ---------------------------------------------------------------------------
# ToolMiddleware Protocol
# ---------------------------------------------------------------------------

class TestToolMiddlewareProtocol:
    def test_runtime_checkable(self) -> None:
        class MyMW:
            async def pre_execute(
                self, tool_name: str, server_name: str, args: dict[str, Any]
            ) -> dict[str, Any] | None:
                return args

            async def post_execute(
                self, tool_name: str, server_name: str, result: dict[str, Any]
            ) -> dict[str, Any] | None:
                return result

        assert isinstance(MyMW(), ToolMiddleware)

    def test_detects_non_implementation(self) -> None:
        class NotMW:
            pass

        assert not isinstance(NotMW(), ToolMiddleware)

    def test_partial_implementation_pre_only(self) -> None:
        class PreOnly:
            async def pre_execute(
                self, tool_name: str, server_name: str, args: dict[str, Any]
            ) -> dict[str, Any] | None:
                return args

        # Protocol with two methods - partial impl may or may not satisfy
        # depending on runtime_checkable semantics. Just verify no crash.
        _ = isinstance(PreOnly(), ToolMiddleware)

    def test_partial_implementation_post_only(self) -> None:
        class PostOnly:
            async def post_execute(
                self, tool_name: str, server_name: str, result: dict[str, Any]
            ) -> dict[str, Any] | None:
                return result

        _ = isinstance(PostOnly(), ToolMiddleware)

    def test_class_with_both_methods_is_instance(self) -> None:
        class BothMethods:
            async def pre_execute(
                self, tool_name: str, server_name: str, args: dict[str, Any]
            ) -> dict[str, Any] | None:
                return None

            async def post_execute(
                self, tool_name: str, server_name: str, result: dict[str, Any]
            ) -> dict[str, Any] | None:
                return None

        assert isinstance(BothMethods(), ToolMiddleware)
