"""Tests for OpenTelemetry tracing adapter — matches TypeScript SdkTracer behaviour."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

import pytest

from qodo.sdk.events import (
    QodoSdkEvent,
    SdkErrorData,
    SdkEventType,
    SdkFinalData,
    SdkInitData,
    SdkMessageDeltaData,
    SdkProgressData,
    SdkRunStartedData,
    SdkToolApprovedData,
    SdkToolExecutedData,
    SdkToolRequestedData,
    create_sdk_event,
)
from qodo.tracing import (
    OTelAPI,
    SdkTracer,
    SdkTracerOptions,
    create_sdk_tracer,
)


# ---------------------------------------------------------------------------
# Fake OTel implementation matching the new TS-style API surface
# ---------------------------------------------------------------------------


class _SpanStatusCode:
    OK = 0
    ERROR = 2


@dataclass
class FakeContext:
    """Minimal opaque context."""

    parent_span: Optional[FakeSpan] = None


@dataclass
class FakeSpan:
    name: str
    attributes: Dict[str, Any] = field(default_factory=dict)
    status: Optional[Dict[str, Any]] = None
    ended: bool = False
    exceptions: List[Any] = field(default_factory=list)
    events: List[Dict[str, Any]] = field(default_factory=list)
    parent_context: Optional[FakeContext] = None

    def set_attribute(self, key: str, value: Any) -> FakeSpan:
        self.attributes[key] = value
        return self

    def set_status(self, status: Dict[str, Any]) -> FakeSpan:
        self.status = status
        return self

    def record_exception(self, exception: Any) -> None:
        self.exceptions.append(exception)

    def add_event(self, name: str, attributes: Optional[Dict[str, Any]] = None) -> FakeSpan:
        self.events.append({"name": name, "attributes": attributes or {}})
        return self

    def end(self, end_time: Optional[int] = None) -> None:
        self.ended = True


class FakeTracer:
    def __init__(self) -> None:
        self.spans: List[FakeSpan] = []

    def start_span(
        self,
        name: str,
        options: Optional[Dict[str, Any]] = None,
        context: Optional[FakeContext] = None,
    ) -> FakeSpan:
        attrs = (options or {}).get("attributes", {})
        span = FakeSpan(name=name, attributes=dict(attrs), parent_context=context)
        self.spans.append(span)
        return span


class FakeContextAPI:
    def active(self) -> FakeContext:
        return FakeContext()


class FakeTraceAPI:
    def __init__(self) -> None:
        self._tracers: Dict[str, FakeTracer] = {}

    def set_span(self, context: FakeContext, span: FakeSpan) -> FakeContext:
        return FakeContext(parent_span=span)

    def get_tracer(self, name: str, version: Optional[str] = None) -> FakeTracer:
        key = f"{name}:{version}"
        if key not in self._tracers:
            self._tracers[key] = FakeTracer()
        return self._tracers[key]


class FakeOTelAPI:
    def __init__(self) -> None:
        self.trace = FakeTraceAPI()
        self.context = FakeContextAPI()
        self.SpanStatusCode = _SpanStatusCode()

    def get_tracer(self, name: str = "@qodo/sdk", version: Optional[str] = None) -> FakeTracer:
        """Convenience accessor for the tracer returned by trace.get_tracer."""
        return self.trace.get_tracer(name, version)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

RUN_ID = "test-run"


def _make_event(
    event_type: SdkEventType,
    data: Any,
    run_id: str = RUN_ID,
) -> QodoSdkEvent:
    return create_sdk_event(
        event_type=event_type,
        run_id=run_id,
        seq=1,
        session_id="test-session",
        data=data,
    )


def _run_started_event(
    prompt_mode: bool = False,
    dry_run: Optional[bool] = None,
    command: str = "test-command",
    run_id: str = RUN_ID,
) -> QodoSdkEvent:
    return _make_event(
        SdkEventType.RUN_STARTED,
        SdkRunStartedData(
            session_id="test-session",
            command=command,
            prompt_mode=prompt_mode,
            cwd="/tmp",
            agent={"name": "test-agent", "source": "config"},
            tools_auto_approved=False,
            dry_run=dry_run,
        ),
        run_id=run_id,
    )


def _tool_requested_event(
    tool_call_id: str = "tool-1",
    server_name: str = "fs",
    tool_name: str = "read_file",
    reasoning: Optional[str] = None,
    run_id: str = RUN_ID,
) -> QodoSdkEvent:
    return _make_event(
        SdkEventType.TOOL_REQUESTED,
        SdkToolRequestedData(
            tool_call_id=tool_call_id,
            server_name=server_name,
            tool_name=tool_name,
            tool_args={"path": "/tmp/test.txt"},
            pending_approval=False,
            reasoning=reasoning,
        ),
        run_id=run_id,
    )


def _tool_approved_event(
    tool_call_id: str = "tool-1",
    approved: bool = True,
    reason: Optional[str] = None,
    run_id: str = RUN_ID,
) -> QodoSdkEvent:
    return _make_event(
        SdkEventType.TOOL_APPROVED,
        SdkToolApprovedData(
            tool_call_id=tool_call_id,
            approved=approved,
            reason=reason,
        ),
        run_id=run_id,
    )


def _tool_executed_event(
    tool_call_id: str = "tool-1",
    result: Optional[Dict[str, Any]] = None,
    dry_run: Optional[bool] = None,
    run_id: str = RUN_ID,
) -> QodoSdkEvent:
    return _make_event(
        SdkEventType.TOOL_EXECUTED,
        SdkToolExecutedData(
            tool_call_id=tool_call_id,
            server_name="fs",
            tool_name="read_file",
            result=result or {"content": "hello"},
            dry_run=dry_run,
        ),
        run_id=run_id,
    )


def _final_event(
    success: bool = True,
    error: Optional[str] = None,
    meta: Optional[Dict[str, Any]] = None,
    run_id: str = RUN_ID,
) -> QodoSdkEvent:
    return _make_event(
        SdkEventType.FINAL,
        SdkFinalData(
            success=success,
            model="gpt-4",
            result={},
            messages={},
            meta=meta or {},
            error=error,
        ),
        run_id=run_id,
    )


def _error_event(
    message: str = "something went wrong",
    run_id: str = RUN_ID,
) -> QodoSdkEvent:
    return _make_event(
        SdkEventType.ERROR,
        SdkErrorData(message=message),
        run_id=run_id,
    )


def _tracer() -> FakeTracer:
    """Return the default FakeTracer from a FakeOTelAPI."""
    otel = FakeOTelAPI()
    return otel.get_tracer()


# ---------------------------------------------------------------------------
# Factory tests
# ---------------------------------------------------------------------------


class TestFactory:
    def test_create_sdk_tracer_returns_sdk_tracer(self) -> None:
        otel = FakeOTelAPI()
        tracer = create_sdk_tracer(otel)
        assert isinstance(tracer, SdkTracer)

    def test_create_sdk_tracer_accepts_custom_options(self) -> None:
        otel = FakeOTelAPI()
        opts = SdkTracerOptions(root_attributes={"env": "test"})
        tracer = create_sdk_tracer(otel, opts)
        assert isinstance(tracer, SdkTracer)

    def test_custom_tracer_name_and_version(self) -> None:
        otel = FakeOTelAPI()
        opts = SdkTracerOptions(tracer_name="my-tracer", tracer_version="1.2.3")
        tracer = SdkTracer(otel, opts)
        tracer.on_event(_run_started_event())

        # The tracer should have been fetched with the custom name/version
        ft = otel.trace.get_tracer("my-tracer", "1.2.3")
        assert len(ft.spans) == 1

    def test_default_tracer_name_is_qodo_sdk(self) -> None:
        otel = FakeOTelAPI()
        tracer = SdkTracer(otel)
        tracer.on_event(_run_started_event())

        ft = otel.trace.get_tracer("@qodo/sdk", None)
        assert len(ft.spans) == 1


# ---------------------------------------------------------------------------
# Run lifecycle tests
# ---------------------------------------------------------------------------


class TestRunLifecycle:
    def test_run_started_creates_root_span(self) -> None:
        otel = FakeOTelAPI()
        tracer = SdkTracer(otel)
        tracer.on_event(_run_started_event())

        ft = otel.get_tracer()
        assert len(ft.spans) == 1
        span = ft.spans[0]
        assert span.name == "qodo.run test-command"
        assert span.attributes["qodo.run_id"] == RUN_ID
        assert span.attributes["qodo.session_id"] == "test-session"
        assert span.attributes["qodo.command"] == "test-command"
        assert span.attributes["qodo.prompt_mode"] is False
        assert span.attributes["qodo.tools_auto_approved"] is False
        assert span.attributes["qodo.cwd"] == "/tmp"
        assert span.attributes["qodo.agent.source"] == "config"

    def test_run_started_prompt_mode_sets_span_name(self) -> None:
        otel = FakeOTelAPI()
        tracer = SdkTracer(otel)
        tracer.on_event(_run_started_event(prompt_mode=True, command=""))

        ft = otel.get_tracer()
        span = ft.spans[0]
        assert span.name == "qodo.run prompt"
        assert span.attributes["qodo.command"] == "(prompt)"

    def test_run_started_dry_run_sets_attribute(self) -> None:
        otel = FakeOTelAPI()
        tracer = SdkTracer(otel)
        tracer.on_event(_run_started_event(dry_run=True))

        ft = otel.get_tracer()
        span = ft.spans[0]
        assert span.attributes["qodo.dry_run"] is True

    def test_root_attributes_from_options_are_applied(self) -> None:
        otel = FakeOTelAPI()
        opts = SdkTracerOptions(root_attributes={"env": "staging", "team": "platform"})
        tracer = SdkTracer(otel, opts)
        tracer.on_event(_run_started_event())

        ft = otel.get_tracer()
        span = ft.spans[0]
        assert span.attributes["env"] == "staging"
        assert span.attributes["team"] == "platform"

    def test_final_ends_root_span_with_success(self) -> None:
        otel = FakeOTelAPI()
        tracer = SdkTracer(otel)
        tracer.on_event(_run_started_event())
        tracer.on_event(_final_event(success=True))

        ft = otel.get_tracer()
        span = ft.spans[0]
        assert span.ended is True
        assert span.status is not None
        assert span.status["code"] == _SpanStatusCode.OK
        assert span.attributes["qodo.success"] is True
        assert span.attributes["qodo.model"] == "gpt-4"

    def test_final_with_failure_records_error_status(self) -> None:
        otel = FakeOTelAPI()
        tracer = SdkTracer(otel)
        tracer.on_event(_run_started_event())
        tracer.on_event(_final_event(success=False, error="timeout"))

        ft = otel.get_tracer()
        span = ft.spans[0]
        assert span.ended is True
        assert span.status is not None
        assert span.status["code"] == _SpanStatusCode.ERROR
        assert span.status["message"] == "timeout"
        # TS records exception when error is present
        assert len(span.exceptions) == 1
        assert span.exceptions[0] == "timeout"

    def test_final_with_timed_out_sets_attribute(self) -> None:
        otel = FakeOTelAPI()
        tracer = SdkTracer(otel)
        tracer.on_event(_run_started_event())
        tracer.on_event(_final_event(success=False, meta={"timed_out": True}))

        ft = otel.get_tracer()
        span = ft.spans[0]
        assert span.attributes["qodo.timed_out"] is True

    def test_final_with_dry_run_in_meta_sets_attribute(self) -> None:
        otel = FakeOTelAPI()
        tracer = SdkTracer(otel)
        tracer.on_event(_run_started_event())
        tracer.on_event(_final_event(success=True, meta={"dry_run": True}))

        ft = otel.get_tracer()
        span = ft.spans[0]
        assert span.attributes["qodo.dry_run"] is True

    def test_final_removes_run_entry(self) -> None:
        otel = FakeOTelAPI()
        tracer = SdkTracer(otel)
        tracer.on_event(_run_started_event())
        tracer.on_event(_final_event(success=True))
        # Second final for the same run is a no-op
        tracer.on_event(_final_event(success=False, error="should not set"))

        ft = otel.get_tracer()
        assert len(ft.spans) == 1  # only one span created


# ---------------------------------------------------------------------------
# Concurrent runs tests
# ---------------------------------------------------------------------------


class TestConcurrentRuns:
    def test_two_runs_create_separate_root_spans(self) -> None:
        otel = FakeOTelAPI()
        tracer = SdkTracer(otel)
        tracer.on_event(_run_started_event(run_id="run-a", command="cmd-a"))
        tracer.on_event(_run_started_event(run_id="run-b", command="cmd-b"))

        ft = otel.get_tracer()
        assert len(ft.spans) == 2
        assert ft.spans[0].name == "qodo.run cmd-a"
        assert ft.spans[1].name == "qodo.run cmd-b"

    def test_tool_spans_keyed_by_run_id(self) -> None:
        otel = FakeOTelAPI()
        tracer = SdkTracer(otel)
        tracer.on_event(_run_started_event(run_id="run-a"))
        tracer.on_event(_run_started_event(run_id="run-b"))

        # Same tool_call_id in two different runs
        tracer.on_event(_tool_requested_event(tool_call_id="t1", run_id="run-a"))
        tracer.on_event(_tool_requested_event(tool_call_id="t1", run_id="run-b"))

        ft = otel.get_tracer()
        # 2 root + 2 tool = 4 spans
        assert len(ft.spans) == 4

        tracer.on_event(_tool_executed_event(tool_call_id="t1", run_id="run-a"))
        tracer.on_event(_tool_executed_event(tool_call_id="t1", run_id="run-b"))

        assert ft.spans[2].ended is True
        assert ft.spans[3].ended is True

    def test_final_only_ends_its_own_run(self) -> None:
        otel = FakeOTelAPI()
        tracer = SdkTracer(otel)
        tracer.on_event(_run_started_event(run_id="run-a"))
        tracer.on_event(_run_started_event(run_id="run-b"))

        tracer.on_event(_final_event(success=True, run_id="run-a"))

        ft = otel.get_tracer()
        assert ft.spans[0].ended is True   # run-a
        assert ft.spans[1].ended is False  # run-b still open


# ---------------------------------------------------------------------------
# Tool lifecycle tests
# ---------------------------------------------------------------------------


class TestToolLifecycle:
    def test_tool_requested_creates_child_span(self) -> None:
        otel = FakeOTelAPI()
        tracer = SdkTracer(otel)
        tracer.on_event(_run_started_event())
        tracer.on_event(_tool_requested_event())

        ft = otel.get_tracer()
        assert len(ft.spans) == 2
        tool_span = ft.spans[1]
        assert tool_span.name == "tool fs/read_file"
        assert tool_span.attributes["qodo.tool.call_id"] == "tool-1"
        assert tool_span.attributes["qodo.tool.server_name"] == "fs"
        assert tool_span.attributes["qodo.tool.name"] == "read_file"
        assert tool_span.attributes["qodo.tool.pending_approval"] is False

    def test_tool_requested_has_parent_context(self) -> None:
        otel = FakeOTelAPI()
        tracer = SdkTracer(otel)
        tracer.on_event(_run_started_event())
        tracer.on_event(_tool_requested_event())

        ft = otel.get_tracer()
        tool_span = ft.spans[1]
        assert tool_span.parent_context is not None
        # parent context should carry the root span
        assert tool_span.parent_context.parent_span is ft.spans[0]

    def test_tool_requested_with_reasoning_truncates_to_500(self) -> None:
        otel = FakeOTelAPI()
        tracer = SdkTracer(otel)
        tracer.on_event(_run_started_event())
        long_reasoning = "x" * 1000
        tracer.on_event(_tool_requested_event(reasoning=long_reasoning))

        ft = otel.get_tracer()
        tool_span = ft.spans[1]
        assert len(tool_span.attributes["qodo.tool.reasoning"]) == 500

    def test_tool_approved_sets_approval_attribute(self) -> None:
        otel = FakeOTelAPI()
        tracer = SdkTracer(otel)
        tracer.on_event(_run_started_event())
        tracer.on_event(_tool_requested_event())
        tracer.on_event(_tool_approved_event(approved=True))

        ft = otel.get_tracer()
        tool_span = ft.spans[1]
        assert tool_span.attributes["qodo.tool.approved"] is True
        assert tool_span.ended is False  # not ended yet, waiting for executed

    def test_tool_approved_with_reason_sets_approval_reason(self) -> None:
        otel = FakeOTelAPI()
        tracer = SdkTracer(otel)
        tracer.on_event(_run_started_event())
        tracer.on_event(_tool_requested_event())
        tracer.on_event(_tool_approved_event(approved=True, reason="allowlisted"))

        ft = otel.get_tracer()
        tool_span = ft.spans[1]
        assert tool_span.attributes["qodo.tool.approval_reason"] == "allowlisted"

    def test_tool_approved_declined_ends_span_with_ok_declined(self) -> None:
        """TS SDK uses SpanStatusCode.OK with message 'declined', NOT ERROR."""
        otel = FakeOTelAPI()
        tracer = SdkTracer(otel)
        tracer.on_event(_run_started_event())
        tracer.on_event(_tool_requested_event())
        tracer.on_event(_tool_approved_event(approved=False))

        ft = otel.get_tracer()
        tool_span = ft.spans[1]
        assert tool_span.attributes["qodo.tool.approved"] is False
        assert tool_span.ended is True
        assert tool_span.status is not None
        assert tool_span.status["code"] == _SpanStatusCode.OK
        assert tool_span.status["message"] == "declined"

    def test_tool_executed_ends_tool_span_with_ok(self) -> None:
        otel = FakeOTelAPI()
        tracer = SdkTracer(otel)
        tracer.on_event(_run_started_event())
        tracer.on_event(_tool_requested_event())
        tracer.on_event(_tool_executed_event())

        ft = otel.get_tracer()
        tool_span = ft.spans[1]
        assert tool_span.ended is True
        assert tool_span.status is not None
        assert tool_span.status["code"] == _SpanStatusCode.OK
        assert tool_span.attributes["qodo.tool.is_error"] is False

    def test_tool_executed_with_error_records_exception(self) -> None:
        otel = FakeOTelAPI()
        tracer = SdkTracer(otel)
        tracer.on_event(_run_started_event())
        tracer.on_event(_tool_requested_event())
        tracer.on_event(
            _tool_executed_event(result={"isError": True, "content": "permission denied"})
        )

        ft = otel.get_tracer()
        tool_span = ft.spans[1]
        assert tool_span.ended is True
        assert tool_span.status is not None
        assert tool_span.status["code"] == _SpanStatusCode.ERROR
        assert tool_span.status["message"] == "permission denied"
        assert tool_span.attributes["qodo.tool.is_error"] is True
        assert len(tool_span.exceptions) == 1
        assert tool_span.exceptions[0] == "permission denied"

    def test_tool_executed_error_content_truncation(self) -> None:
        """Status message truncated to 500, exception to 1000."""
        otel = FakeOTelAPI()
        tracer = SdkTracer(otel)
        tracer.on_event(_run_started_event())
        tracer.on_event(_tool_requested_event())
        long_content = "e" * 2000
        tracer.on_event(
            _tool_executed_event(result={"isError": True, "content": long_content})
        )

        ft = otel.get_tracer()
        tool_span = ft.spans[1]
        assert len(tool_span.status["message"]) == 500
        assert len(tool_span.exceptions[0]) == 1000

    def test_tool_executed_with_dry_run_sets_attribute(self) -> None:
        otel = FakeOTelAPI()
        tracer = SdkTracer(otel)
        tracer.on_event(_run_started_event())
        tracer.on_event(_tool_requested_event())
        tracer.on_event(_tool_executed_event(dry_run=True))

        ft = otel.get_tracer()
        tool_span = ft.spans[1]
        assert tool_span.attributes["qodo.tool.dry_run"] is True

    def test_multiple_tools_create_separate_spans(self) -> None:
        otel = FakeOTelAPI()
        tracer = SdkTracer(otel)
        tracer.on_event(_run_started_event())
        tracer.on_event(_tool_requested_event(tool_call_id="t1", tool_name="read_file"))
        tracer.on_event(_tool_requested_event(tool_call_id="t2", tool_name="write_file"))
        tracer.on_event(_tool_executed_event(tool_call_id="t1"))
        tracer.on_event(_tool_executed_event(tool_call_id="t2"))

        ft = otel.get_tracer()
        # root + 2 tool spans
        assert len(ft.spans) == 3
        assert ft.spans[1].name == "tool fs/read_file"
        assert ft.spans[2].name == "tool fs/write_file"
        assert ft.spans[1].ended is True
        assert ft.spans[2].ended is True


# ---------------------------------------------------------------------------
# Error events
# ---------------------------------------------------------------------------


class TestErrorEvents:
    def test_error_records_exception_on_root_span(self) -> None:
        otel = FakeOTelAPI()
        tracer = SdkTracer(otel)
        tracer.on_event(_run_started_event())
        tracer.on_event(_error_event("connection lost"))

        ft = otel.get_tracer()
        root_span = ft.spans[0]
        assert len(root_span.exceptions) == 1
        assert root_span.exceptions[0] == "connection lost"

    def test_error_adds_sdk_error_event(self) -> None:
        """TS adds addEvent('sdk.error', { 'error.message': message })."""
        otel = FakeOTelAPI()
        tracer = SdkTracer(otel)
        tracer.on_event(_run_started_event())
        tracer.on_event(_error_event("connection lost"))

        ft = otel.get_tracer()
        root_span = ft.spans[0]
        assert len(root_span.events) == 1
        assert root_span.events[0]["name"] == "sdk.error"
        assert root_span.events[0]["attributes"]["error.message"] == "connection lost"


# ---------------------------------------------------------------------------
# wrap_stream tests
# ---------------------------------------------------------------------------


class TestWrapStream:
    async def test_wrap_stream_yields_all_events_and_calls_on_event(self) -> None:
        otel = FakeOTelAPI()
        tracer = SdkTracer(otel)

        events = [
            _run_started_event(),
            _final_event(success=True),
        ]

        async def fake_stream():
            for e in events:
                yield e

        collected = []
        async for event in tracer.wrap_stream(fake_stream()):
            collected.append(event)

        assert len(collected) == 2
        assert collected[0].type == SdkEventType.RUN_STARTED
        assert collected[1].type == SdkEventType.FINAL
        # Verify on_event was called (root span was created and ended)
        ft = otel.get_tracer()
        assert len(ft.spans) == 1
        assert ft.spans[0].ended is True

    async def test_wrap_stream_calls_flush_on_exit(self) -> None:
        """wrap_stream has try/finally that calls flush()."""
        otel = FakeOTelAPI()
        tracer = SdkTracer(otel)

        events = [
            _run_started_event(),
            _tool_requested_event(),
            # No tool_executed or final -- stream ends abruptly
        ]

        async def fake_stream():
            for e in events:
                yield e

        collected = []
        async for event in tracer.wrap_stream(fake_stream()):
            collected.append(event)

        ft = otel.get_tracer()
        # Both orphaned spans should be ended by flush
        assert ft.spans[0].ended is True  # root
        assert ft.spans[1].ended is True  # tool


# ---------------------------------------------------------------------------
# Flush tests
# ---------------------------------------------------------------------------


class TestFlush:
    def test_flush_ends_orphaned_spans_with_error(self) -> None:
        otel = FakeOTelAPI()
        tracer = SdkTracer(otel)
        tracer.on_event(_run_started_event())
        tracer.on_event(_tool_requested_event(tool_call_id="orphan-1"))
        tracer.on_event(_tool_requested_event(tool_call_id="orphan-2"))

        tracer.flush()

        ft = otel.get_tracer()
        # Tool spans should be ended with error
        tool_span_1 = ft.spans[1]
        tool_span_2 = ft.spans[2]
        assert tool_span_1.ended is True
        assert tool_span_1.status is not None
        assert tool_span_1.status["code"] == _SpanStatusCode.ERROR
        assert tool_span_1.status["message"] == "orphaned"
        assert tool_span_2.ended is True
        assert tool_span_2.status is not None
        assert tool_span_2.status["code"] == _SpanStatusCode.ERROR

        # Root span should be ended with error
        root_span = ft.spans[0]
        assert root_span.ended is True
        assert root_span.status is not None
        assert root_span.status["code"] == _SpanStatusCode.ERROR
        assert root_span.status["message"] == "orphaned"


# ---------------------------------------------------------------------------
# Ignored events
# ---------------------------------------------------------------------------


class TestIgnoredEvents:
    def test_init_does_not_create_spans(self) -> None:
        otel = FakeOTelAPI()
        tracer = SdkTracer(otel)
        tracer.on_event(
            _make_event(
                SdkEventType.INIT,
                SdkInitData(sdk_version="1.0.0"),
            )
        )
        ft = otel.get_tracer()
        assert len(ft.spans) == 0

    def test_message_delta_does_not_create_spans(self) -> None:
        otel = FakeOTelAPI()
        tracer = SdkTracer(otel)
        tracer.on_event(
            _make_event(
                SdkEventType.MESSAGE_DELTA,
                SdkMessageDeltaData(message_id="msg-1", delta="hello"),
            )
        )
        ft = otel.get_tracer()
        assert len(ft.spans) == 0

    def test_progress_does_not_create_spans(self) -> None:
        otel = FakeOTelAPI()
        tracer = SdkTracer(otel)
        tracer.on_event(
            _make_event(
                SdkEventType.PROGRESS,
                SdkProgressData(title="Loading..."),
            )
        )
        ft = otel.get_tracer()
        assert len(ft.spans) == 0


# ---------------------------------------------------------------------------
# Edge cases
# ---------------------------------------------------------------------------


class TestEdgeCases:
    def test_tool_approved_without_prior_requested_is_noop(self) -> None:
        otel = FakeOTelAPI()
        tracer = SdkTracer(otel)
        tracer.on_event(_run_started_event())
        tracer.on_event(_tool_approved_event(tool_call_id="unknown"))

        ft = otel.get_tracer()
        assert len(ft.spans) == 1  # Only root span

    def test_tool_executed_without_prior_requested_is_noop(self) -> None:
        otel = FakeOTelAPI()
        tracer = SdkTracer(otel)
        tracer.on_event(_run_started_event())
        tracer.on_event(_tool_executed_event(tool_call_id="unknown"))

        ft = otel.get_tracer()
        assert len(ft.spans) == 1  # Only root span

    def test_final_without_prior_run_started_is_noop(self) -> None:
        otel = FakeOTelAPI()
        tracer = SdkTracer(otel)
        tracer.on_event(_final_event())

        ft = otel.get_tracer()
        assert len(ft.spans) == 0

    def test_error_without_prior_run_started_is_noop(self) -> None:
        otel = FakeOTelAPI()
        tracer = SdkTracer(otel)
        tracer.on_event(_error_event("some error"))

        ft = otel.get_tracer()
        assert len(ft.spans) == 0

    def test_tool_requested_without_prior_run_started_is_noop(self) -> None:
        otel = FakeOTelAPI()
        tracer = SdkTracer(otel)
        tracer.on_event(_tool_requested_event())

        ft = otel.get_tracer()
        assert len(ft.spans) == 0
