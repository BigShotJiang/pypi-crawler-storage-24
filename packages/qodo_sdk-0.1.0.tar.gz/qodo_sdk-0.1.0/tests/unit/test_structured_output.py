"""Tests for structured output validation utilities."""

from __future__ import annotations

import pytest
from pydantic import BaseModel, ConfigDict, Field

from qodo.errors import QodoError, QodoOutputValidationError
from qodo.sdk.runner.finalize import is_pydantic_model, validate_structured_output


# ── Test models ──────────────────────────────────────────────────────────────

class ScoreOutput(BaseModel):
    score: int
    label: str


class UserOutput(BaseModel):
    name: str
    age: int = 0


class Address(BaseModel):
    street: str
    city: str


class PersonWithAddress(BaseModel):
    name: str
    address: Address


class StrictModel(BaseModel):
    model_config = ConfigDict(strict=True)
    value: int


class PlainClass:
    pass


# ── TestIsPydanticModel ──────────────────────────────────────────────────────

class TestIsPydanticModel:
    """Tests for is_pydantic_model()."""

    def test_returns_true_for_base_model_subclass(self):
        assert is_pydantic_model(ScoreOutput) is True

    def test_returns_true_for_nested_model(self):
        assert is_pydantic_model(PersonWithAddress) is True

    def test_returns_false_for_none(self):
        assert is_pydantic_model(None) is False

    def test_returns_false_for_plain_dict(self):
        assert is_pydantic_model({"score": 1}) is False

    def test_returns_false_for_string(self):
        assert is_pydantic_model("ScoreOutput") is False

    def test_returns_false_for_non_base_model_class(self):
        assert is_pydantic_model(PlainClass) is False

    def test_returns_false_for_instance_not_class(self):
        instance = ScoreOutput(score=1, label="test")
        assert is_pydantic_model(instance) is False

    def test_returns_true_for_model_with_custom_config(self):
        assert is_pydantic_model(StrictModel) is True


# ── TestValidateStructuredOutput ─────────────────────────────────────────────

class TestValidateStructuredOutput:
    """Tests for validate_structured_output()."""

    def test_returns_validated_data_on_valid_input(self):
        result = validate_structured_output(
            ScoreOutput,
            {"score": 42, "label": "good"},
        )
        assert result == {"score": 42, "label": "good"}

    def test_returns_data_with_defaults_applied(self):
        result = validate_structured_output(
            UserOutput,
            {"name": "Alice"},
        )
        assert result == {"name": "Alice", "age": 0}

    def test_raises_on_invalid_input(self):
        with pytest.raises(QodoOutputValidationError):
            validate_structured_output(
                ScoreOutput,
                {"score": "not_a_number", "label": 123},
            )

    def test_error_includes_issue_details(self):
        with pytest.raises(QodoOutputValidationError) as exc_info:
            validate_structured_output(
                ScoreOutput,
                {"score": "bad"},
            )
        err = exc_info.value
        assert len(err.issues) > 0
        paths = [issue["path"] for issue in err.issues]
        # At minimum, "score" should fail, and "label" is missing
        assert any(p for p in paths)

    def test_works_with_nested_models(self):
        result = validate_structured_output(
            PersonWithAddress,
            {"name": "Bob", "address": {"street": "123 Main", "city": "NYC"}},
        )
        assert result == {
            "name": "Bob",
            "address": {"street": "123 Main", "city": "NYC"},
        }

    def test_handles_none_input(self):
        with pytest.raises(QodoOutputValidationError):
            validate_structured_output(ScoreOutput, None)


# ── TestQodoOutputValidationError ────────────────────────────────────────────

class TestQodoOutputValidationError:
    """Tests for QodoOutputValidationError."""

    def test_is_instance_of_qodo_error(self):
        err = QodoOutputValidationError(issues=[], raw_output=None)
        assert isinstance(err, QodoError)

    def test_stores_issues_and_raw_output(self):
        raw = {"score": "bad"}
        issues = [{"path": "score", "message": "Input should be a valid integer"}]
        err = QodoOutputValidationError(issues=issues, raw_output=raw)
        assert err.issues == issues
        assert err.raw_output == raw

    def test_message_summarizes_all_issues(self):
        issues = [
            {"path": "score", "message": "Input should be a valid integer"},
            {"path": "label", "message": "Field required"},
        ]
        err = QodoOutputValidationError(issues=issues, raw_output={})
        msg = str(err)
        assert "score" in msg
        assert "label" in msg
        assert "Structured output validation failed" in msg
