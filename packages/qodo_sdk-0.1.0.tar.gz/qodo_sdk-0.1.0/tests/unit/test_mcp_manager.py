"""Tests for MCPManager — mirrors mcp-manager.test.ts."""
from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from qodo.mcp.mcp_manager import MCPManager
from qodo.mcp.servers_registry import ServerRegistry
from qodo.mcp.types import ServerType, Tool
from qodo.parser.types import MCPConfig
from qodo.session.environment import run_with_environment_async

from tests.helpers.test_env import fresh_env


def _mock_server_data():
    """Mock ServerData to avoid backend calls."""
    mock_sd = MagicMock()
    mock_sd.get_instance.return_value = mock_sd
    mock_sd.get_session_id.return_value = "mock-session-id"
    mock_sd.get_default_model.return_value = "mock-model"
    mock_sd.check_model_input.return_value = None
    mock_sd.fetch_new_session_id = AsyncMock(return_value="mock-new-session")
    mock_sd.get_base_url.return_value = "https://mock.api.qodo.ai"
    mock_sd.get_base_url_source.return_value = "default"
    mock_sd.get_mcp_tools.return_value = {}
    mock_sd.init = AsyncMock(return_value=mock_sd)
    return patch("qodo.session.server_data.ServerData", mock_sd)


class TestInitAndGetInstance:
    """MCPManager init and getInstance tests."""

    async def test_init_creates_environment_scoped_instance(self):
        async def run():
            with _mock_server_data():
                registry = ServerRegistry.init()
                registry.set_no_builtin(True)
                await registry.load_all_servers()
                manager = await MCPManager.init()
                assert manager is not None
                assert MCPManager.get_instance() is manager

        await run_with_environment_async(fresh_env(), run)

    async def test_get_instance_throws_when_not_initialized_in_environment(self):
        async def run():
            with pytest.raises(RuntimeError, match="MCPManager not initialized"):
                MCPManager.get_instance()

        await run_with_environment_async(fresh_env(), run)

    async def test_two_environments_get_independent_mcp_manager_instances(self):
        env1 = fresh_env()
        env2 = fresh_env()

        mgr1 = None
        mgr2 = None

        async def run1():
            nonlocal mgr1
            with _mock_server_data():
                registry = ServerRegistry.init()
                registry.set_no_builtin(True)
                await registry.load_all_servers()
                mgr1 = await MCPManager.init()

        async def run2():
            nonlocal mgr2
            with _mock_server_data():
                registry = ServerRegistry.init()
                registry.set_no_builtin(True)
                await registry.load_all_servers()
                mgr2 = await MCPManager.init()

        await run_with_environment_async(env1, run1)
        await run_with_environment_async(env2, run2)

        assert mgr1 is not mgr2


class TestToolInventory:
    """MCPManager tool inventory tests."""

    async def test_get_all_tools_returns_empty_dict_when_no_servers_loaded(self):
        async def run():
            with _mock_server_data():
                registry = ServerRegistry.init()
                registry.set_no_builtin(True)
                await registry.load_all_servers()
                manager = await MCPManager.init()
                tools = manager.get_all_tools()
                assert len(tools) == 0

        await run_with_environment_async(fresh_env(), run)

    async def test_get_tools_returns_empty_for_unknown_server(self):
        async def run():
            with _mock_server_data():
                registry = ServerRegistry.init()
                registry.set_no_builtin(True)
                await registry.load_all_servers()
                manager = await MCPManager.init()
                tools = manager.get_all_tools()
                assert tools.get("nonexistent", []) == []

        await run_with_environment_async(fresh_env(), run)

    async def test_get_tool_returns_none_for_unknown_server_tool(self):
        async def run():
            with _mock_server_data():
                registry = ServerRegistry.init()
                registry.set_no_builtin(True)
                await registry.load_all_servers()
                manager = await MCPManager.init()
                tools = manager.get_all_tools()
                # No tool for "fs" server
                fs_tools = tools.get("fs", [])
                result = next((t for t in fs_tools if t.name == "read_file"), None)
                assert result is None

        await run_with_environment_async(fresh_env(), run)


class TestGetEnabledTools:
    """MCPManager getEnabledTools tests — filters via availableTools/ignoreTools."""

    def _create_manager_with_tools(self, tools_map):
        """Create an MCPManager with directly injected tools for testing filtering."""
        manager = MCPManager()
        manager._tools = tools_map
        manager._servers = {}
        return manager

    def test_returns_all_tools_when_no_filters(self):
        tools = {
            "filesystem": [
                Tool(name="read_file", description="Read"),
                Tool(name="write_file", description="Write"),
            ],
            "git": [Tool(name="git_status", description="Status")],
        }
        manager = self._create_manager_with_tools(tools)
        enabled = manager.get_enabled_tools()
        assert len(enabled) == 2
        assert len(enabled["filesystem"]) == 2

    def test_filters_to_specific_servers_via_available_tools(self):
        tools = {
            "filesystem": [Tool(name="read_file", description="Read")],
            "git": [Tool(name="git_status", description="Status")],
            "shell": [Tool(name="shell_execute", description="Run")],
        }
        manager = self._create_manager_with_tools(tools)
        enabled = manager.get_enabled_tools(available_tools=["filesystem", "git"])
        assert len(enabled) == 2
        assert "filesystem" in enabled
        assert "git" in enabled
        assert "shell" not in enabled

    def test_filters_to_specific_tools_within_a_server(self):
        tools = {
            "filesystem": [
                Tool(name="read_file", description="Read"),
                Tool(name="write_file", description="Write"),
                Tool(name="delete_files", description="Delete"),
            ],
        }
        manager = self._create_manager_with_tools(tools)
        enabled = manager.get_enabled_tools(
            available_tools=["filesystem.read_file", "filesystem.write_file"]
        )
        assert len(enabled["filesystem"]) == 2
        names = [t.name for t in enabled["filesystem"]]
        assert "read_file" in names
        assert "write_file" in names
        assert "delete_files" not in names

    def test_ignore_tools_removes_entire_server(self):
        tools = {
            "filesystem": [Tool(name="read_file", description="Read")],
            "git": [Tool(name="git_status", description="Status")],
        }
        manager = self._create_manager_with_tools(tools)
        enabled = manager.get_enabled_tools(ignore_tools=["git"])
        assert len(enabled) == 1
        assert "git" not in enabled

    def test_ignore_tools_removes_specific_tools(self):
        tools = {
            "filesystem": [
                Tool(name="read_file", description="Read"),
                Tool(name="write_file", description="Write"),
            ],
        }
        manager = self._create_manager_with_tools(tools)
        enabled = manager.get_enabled_tools(ignore_tools=["filesystem.write_file"])
        assert len(enabled["filesystem"]) == 1
        assert enabled["filesystem"][0].name == "read_file"

    def test_ignore_tools_removes_server_when_all_tools_ignored(self):
        tools = {
            "filesystem": [Tool(name="read_file", description="Read")],
        }
        manager = self._create_manager_with_tools(tools)
        enabled = manager.get_enabled_tools(ignore_tools=["filesystem.read_file"])
        # Server should have empty list (or be removed depending on impl)
        fs_tools = enabled.get("filesystem", [])
        assert len(fs_tools) == 0


class TestAutoApproval:
    """MCPManager auto-approval tests."""

    async def test_set_auto_approve_all_tools_makes_all_tools_auto_approved(self):
        async def run():
            with _mock_server_data():
                registry = ServerRegistry.init()
                registry.set_no_builtin(True)
                await registry.load_all_servers()
                manager = await MCPManager.init()
                manager.set_auto_approve_all_tools(True)
                assert manager.is_auto_approved_tool("anything", "any_tool") is True

        await run_with_environment_async(fresh_env(), run)

    async def test_set_auto_approved_tool_approves_specific_tool(self):
        async def run():
            with _mock_server_data():
                registry = ServerRegistry.init()
                registry.set_no_builtin(True)
                await registry.load_all_servers()
                manager = await MCPManager.init()
                assert manager.is_auto_approved_tool("myServer", "myTool") is False
                manager.set_auto_approved_tool("myServer", "myTool")
                assert manager.is_auto_approved_tool("myServer", "myTool") is True
                # Other tools on same server are still not approved
                assert manager.is_auto_approved_tool("myServer", "otherTool") is False

        await run_with_environment_async(fresh_env(), run)

    @pytest.mark.skip(reason="set_auto_approved_shell_command not yet implemented in Python SDK")
    async def test_set_auto_approved_shell_command_approves_specific_shell_command(self):
        pass


class TestConnectionStates:
    """MCPManager connection states tests."""

    async def test_get_connection_states_returns_empty_when_no_servers(self):
        async def run():
            with _mock_server_data():
                registry = ServerRegistry.init()
                registry.set_no_builtin(True)
                await registry.load_all_servers()
                manager = await MCPManager.init()
                states = manager._connection_states
                assert isinstance(states, dict)
                assert len(states) == 0

        await run_with_environment_async(fresh_env(), run)


class TestDispose:
    """MCPManager dispose tests."""

    async def test_dispose_clears_all_state_without_throwing(self):
        async def run():
            with _mock_server_data():
                registry = ServerRegistry.init()
                registry.set_no_builtin(True)
                await registry.load_all_servers()
                manager = await MCPManager.init()
                # Dispose should not throw even with no active connections
                await manager.dispose()

        await run_with_environment_async(fresh_env(), run)
