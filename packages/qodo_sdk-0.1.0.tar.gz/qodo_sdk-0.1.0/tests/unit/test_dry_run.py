"""Tests for P1.2 — Dry Run Mode."""

from __future__ import annotations

import inspect
from typing import Any, Dict

import pytest

from qodo.mcp.tool_processor import ToolProcessorManager
from qodo.parser.types import CommandConfig
from qodo.sdk.events import SdkFinalData, SdkRunStartedData, SdkToolExecutedData
from qodo.session.session_context import SessionContext


# ---------------------------------------------------------------------------
# TestSessionContextDryRun
# ---------------------------------------------------------------------------


class TestSessionContextDryRun:
    """Tests for SessionContext.is_dry_run()."""

    def test_is_dry_run_returns_false_by_default(self) -> None:
        ctx = SessionContext(CommandConfig(name="test"))
        assert ctx.is_dry_run() is False

    def test_is_dry_run_returns_true_when_flag_set(self) -> None:
        ctx = SessionContext(CommandConfig(name="test"), flags={"dry_run": True})
        assert ctx.is_dry_run() is True

    def test_is_dry_run_handles_missing_flag(self) -> None:
        ctx = SessionContext(CommandConfig(name="test"), flags={"other": "value"})
        assert ctx.is_dry_run() is False


# ---------------------------------------------------------------------------
# TestDryRunMockResponses
# ---------------------------------------------------------------------------


class TestDryRunMockResponses:
    """Tests for ToolProcessorManager.dry_run_tool() mock responses."""

    async def test_filesystem_read_files_mock(self) -> None:
        tpm = ToolProcessorManager()
        result = await tpm.dry_run_tool("read_files", "filesystem", {})
        assert "[DRY RUN]" in result["content"]
        assert result["isError"] is False

    async def test_git_status_mock(self) -> None:
        tpm = ToolProcessorManager()
        result = await tpm.dry_run_tool("git_status", "git", {})
        assert "[DRY RUN]" in result["content"]
        assert "branch" in result["content"].lower()

    async def test_shell_execute_mock(self) -> None:
        tpm = ToolProcessorManager()
        result = await tpm.dry_run_tool("shell_execute", "shell", {})
        assert "[DRY RUN]" in result["content"]
        assert "executed" in result["content"].lower()

    async def test_unknown_tool_mock(self) -> None:
        tpm = ToolProcessorManager()
        result = await tpm.dry_run_tool("some_unknown_tool", "unknown_server", {})
        assert "[DRY RUN]" in result["content"]
        assert "some_unknown_tool" in result["content"]
        assert "unknown_server" in result["content"]

    async def test_mock_result_format(self) -> None:
        tpm = ToolProcessorManager()
        result = await tpm.dry_run_tool("read_files", "filesystem", {"path": "/tmp"})
        assert isinstance(result, dict)
        assert result["isError"] is False
        assert isinstance(result["content"], str)


# ---------------------------------------------------------------------------
# TestDryRunEventFields
# ---------------------------------------------------------------------------


class TestDryRunEventFields:
    """Tests for dry_run fields on event dataclasses."""

    def test_run_started_has_dry_run_field(self) -> None:
        data = SdkRunStartedData(
            session_id="s1",
            command="cmd",
            prompt_mode=False,
            cwd="/tmp",
            agent={},
            tools_auto_approved=True,
            dry_run=True,
        )
        assert data.dry_run is True

    def test_tool_executed_has_dry_run_field(self) -> None:
        data = SdkToolExecutedData(
            tool_call_id="tc1",
            server_name="fs",
            tool_name="read_files",
            result={"isError": False, "content": "ok"},
            dry_run=True,
        )
        assert data.dry_run is True

    def test_final_meta_supports_dry_run(self) -> None:
        data = SdkFinalData(
            success=True,
            model="test-model",
            meta={"dry_run": True},
        )
        assert data.meta["dry_run"] is True


# ---------------------------------------------------------------------------
# TestDryRunOptions
# ---------------------------------------------------------------------------


class TestDryRunOptions:
    """Tests for dry_run parameter on stream() and run()."""

    def test_stream_accepts_dry_run_param(self) -> None:
        from qodo.sdk.qodo_sdk import QodoSDK

        sig = inspect.signature(QodoSDK.stream)
        assert "dry_run" in sig.parameters
        param = sig.parameters["dry_run"]
        assert param.default is None

    def test_run_accepts_dry_run_param(self) -> None:
        from qodo.sdk.qodo_sdk import QodoSDK

        sig = inspect.signature(QodoSDK.run)
        assert "dry_run" in sig.parameters
        param = sig.parameters["dry_run"]
        assert param.default is None

    def test_dry_run_playbook_content(self) -> None:
        """Verify the playbook string contains key phrases by reading source."""
        import ast
        from pathlib import Path

        sdk_path = Path(__file__).resolve().parents[2] / "src" / "qodo" / "sdk" / "qodo_sdk.py"
        source = sdk_path.read_text()
        assert "DRY RUN MODE" in source
        assert "simulated" in source.lower()
        assert "[DRY RUN]" in source
        assert "END DRY RUN MODE" in source
