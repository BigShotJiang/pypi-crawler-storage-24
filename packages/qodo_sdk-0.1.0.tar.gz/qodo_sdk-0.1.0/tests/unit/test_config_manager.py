"""Tests for ConfigManager — mirrors config-manager.test.ts."""
from __future__ import annotations

import pytest

from qodo.config.config_manager import ConfigManager
from qodo.session.environment import (
    EnvironmentServices,
    run_with_environment_async,
)

from tests.helpers.test_env import fresh_env


class TestFormatDetection:
    """ConfigManager format detection tests."""

    async def test_init_with_object_config_does_not_require_filesystem(self):
        env = fresh_env()
        async def run():
            cm = await ConfigManager.init(
                {
                    "commands": {
                        "greet": {"instructions": "Say hello"},
                    },
                },
                is_file_content=True,
            )
            assert cm.has_config() is True
            assert cm.list_commands() == ["greet"]

        await run_with_environment_async(env, run)

    async def test_init_with_string_content_toml_parses_correctly(self):
        toml_content = """
[commands.hello]
instructions = "Say hello"
model = "test-model"
"""
        env = fresh_env()
        async def run():
            cm = await ConfigManager.init(toml_content, is_file_content=True)
            assert cm.has_config() is True
            assert cm.list_commands() == ["hello"]

        await run_with_environment_async(env, run)

    async def test_init_with_string_content_always_parses_as_toml(self):
        toml_content = """
[commands.world]
instructions = "Say world"
model = "another-model"
"""
        env = fresh_env()
        async def run():
            cm = await ConfigManager.init(toml_content, is_file_content=True)
            assert cm.has_config() is True
            assert cm.list_commands() == ["world"]

        await run_with_environment_async(env, run)


class TestCommandResolution:
    """ConfigManager command resolution tests."""

    async def test_get_command_config_returns_command_with_inherited_top_level_model(self):
        env = fresh_env()
        async def run():
            cm = await ConfigManager.init(
                {
                    "model": "top-model",
                    "commands": {
                        "review": {"instructions": "Review code"},
                    },
                },
                is_file_content=True,
            )
            cmd = cm.get_command_config("review")
            assert cmd.model == "top-model"
            assert cmd.instructions == "Review code"
            assert cmd.name == "review"

        await run_with_environment_async(env, run)

    async def test_command_level_model_overrides_top_level_model(self):
        env = fresh_env()
        async def run():
            cm = await ConfigManager.init(
                {
                    "model": "top-model",
                    "commands": {
                        "review": {"instructions": "Review code", "model": "cmd-model"},
                    },
                },
                is_file_content=True,
            )
            cmd = cm.get_command_config("review")
            assert cmd.model == "cmd-model"

        await run_with_environment_async(env, run)

    async def test_get_command_config_inherits_top_level_available_tools(self):
        env = fresh_env()
        async def run():
            cm = await ConfigManager.init(
                {
                    "available_tools": ["filesystem", "git"],
                    "commands": {
                        "test": {"instructions": "Run tests"},
                    },
                },
                is_file_content=True,
            )
            cmd = cm.get_command_config("test")
            assert cmd.available_tools == ["filesystem", "git"]

        await run_with_environment_async(env, run)

    async def test_get_command_config_inherits_top_level_execution_strategy(self):
        env = fresh_env()
        async def run():
            cm = await ConfigManager.init(
                {
                    "execution_strategy": "act",
                    "commands": {
                        "deploy": {"instructions": "Deploy"},
                    },
                },
                is_file_content=True,
            )
            cmd = cm.get_command_config("deploy")
            assert cmd.execution_strategy == "act"

        await run_with_environment_async(env, run)

    async def test_get_command_config_defaults_to_act_when_no_strategy(self):
        env = fresh_env()
        async def run():
            cm = await ConfigManager.init(
                {
                    "commands": {
                        "deploy": {"instructions": "Deploy the app"},
                    },
                },
                is_file_content=True,
            )
            cmd = cm.get_command_config("deploy")
            # SDK object path sets default execution_strategy to 'act'
            assert cmd.execution_strategy == "act"

        await run_with_environment_async(env, run)

    async def test_get_command_config_sets_default_permissions_to_rwx(self):
        env = fresh_env()
        async def run():
            cm = await ConfigManager.init(
                {
                    "commands": {
                        "test": {"instructions": "Test"},
                    },
                },
                is_file_content=True,
            )
            cmd = cm.get_command_config("test")
            assert cmd.permissions == "rwx"

        await run_with_environment_async(env, run)

    async def test_synthesizes_default_command_when_no_commands_configured(self):
        env = fresh_env()
        async def run():
            cm = await ConfigManager.init(
                {"model": "default-model"},
                is_file_content=True,
            )
            assert cm.list_commands() == []
            cmd = cm.get_command_config("")
            assert cmd.model == "default-model"

        await run_with_environment_async(env, run)


class TestGetSingleCommand:
    """ConfigManager getSingleCommand tests."""

    async def test_returns_command_name_when_exactly_one_command(self):
        env = fresh_env()
        async def run():
            cm = await ConfigManager.init(
                {"commands": {"only": {"instructions": "Only one"}}},
                is_file_content=True,
            )
            assert cm.get_single_command() == "only"

        await run_with_environment_async(env, run)

    async def test_returns_none_when_multiple_commands(self):
        env = fresh_env()
        async def run():
            cm = await ConfigManager.init(
                {
                    "commands": {
                        "a": {"instructions": "A"},
                        "b": {"instructions": "B"},
                    },
                },
                is_file_content=True,
            )
            assert cm.get_single_command() is None

        await run_with_environment_async(env, run)


class TestGetMCPServers:
    """ConfigManager getMCPServers tests."""

    async def test_returns_empty_dict_when_no_config(self):
        env = fresh_env()
        async def run():
            cm = await ConfigManager.init({}, is_file_content=True)
            assert cm.get_mcp_servers() == {}

        await run_with_environment_async(env, run)

    async def test_returns_configured_mcp_servers(self):
        env = fresh_env()
        async def run():
            cm = await ConfigManager.init(
                {
                    "mcpServers": {
                        "myServer": {"command": "node server.js"},
                    },
                },
                is_file_content=True,
            )
            servers = cm.get_mcp_servers()
            assert "myServer" in servers
            assert servers["myServer"].command == "node server.js"

        await run_with_environment_async(env, run)


class TestGeneralInstructionsAndSystemPrompt:
    """ConfigManager instructions and system prompt tests."""

    async def test_returns_instructions_and_system_prompt_when_configured(self):
        env = fresh_env()
        async def run():
            cm = await ConfigManager.init(
                {
                    "instructions": "Be helpful",
                    "system_prompt": "You are a coding assistant",
                },
                is_file_content=True,
            )
            assert cm.get_general_instructions() == "Be helpful"
            assert cm.get_system_prompt() == "You are a coding assistant"

        await run_with_environment_async(env, run)

    async def test_returns_none_when_not_configured(self):
        env = fresh_env()
        async def run():
            cm = await ConfigManager.init({}, is_file_content=True)
            assert cm.get_general_instructions() is None
            assert cm.get_system_prompt() is None

        await run_with_environment_async(env, run)


class TestModes:
    """ConfigManager modes tests."""

    async def test_list_modes_returns_mode_names(self):
        env = fresh_env()
        async def run():
            cm = await ConfigManager.init(
                {
                    "modes": {
                        "fast": {"instructions": "Be fast"},
                        "careful": {"instructions": "Be careful"},
                    },
                },
                is_file_content=True,
            )
            assert sorted(cm.list_modes()) == ["careful", "fast"]

        await run_with_environment_async(env, run)

    async def test_get_mode_config_inherits_top_level_model(self):
        env = fresh_env()
        async def run():
            cm = await ConfigManager.init(
                {
                    "model": "top-model",
                    "modes": {
                        "fast": {"instructions": "Be fast"},
                    },
                },
                is_file_content=True,
            )
            mode = cm.get_mode_config("fast")
            assert mode is not None
            assert mode.model == "top-model"

        await run_with_environment_async(env, run)

    @pytest.mark.skip(reason="resolve_mode_as_command not yet implemented in Python SDK")
    async def test_resolve_mode_as_command_creates_command_config(self):
        pass

    @pytest.mark.skip(reason="resolve_mode_as_command not yet implemented in Python SDK")
    async def test_resolve_mode_as_command_throws_for_unknown_mode(self):
        pass


class TestEnvironmentIsolation:
    """ConfigManager environment isolation tests."""

    async def test_two_environments_get_independent_config_manager_instances(self):
        env1 = fresh_env()
        env2 = fresh_env()

        cmds1 = []
        cmds2 = []

        async def run1():
            nonlocal cmds1
            cm = await ConfigManager.init(
                {"commands": {"alpha": {"instructions": "A"}}},
                is_file_content=True,
            )
            cmds1 = cm.list_commands()

        async def run2():
            nonlocal cmds2
            cm = await ConfigManager.init(
                {
                    "commands": {
                        "beta": {"instructions": "B"},
                        "gamma": {"instructions": "C"},
                    },
                },
                is_file_content=True,
            )
            cmds2 = cm.list_commands()

        await run_with_environment_async(env1, run1)
        await run_with_environment_async(env2, run2)

        assert cmds1 == ["alpha"]
        assert sorted(cmds2) == ["beta", "gamma"]


class TestDisableMcpInheritance:
    """ConfigManager disable_mcp inheritance tests."""

    async def test_command_inherits_top_level_disable_mcp(self):
        env = fresh_env()
        async def run():
            cm = await ConfigManager.init(
                {
                    "disable_mcp": True,
                    "commands": {"test": {"instructions": "Test"}},
                },
                is_file_content=True,
            )
            cmd = cm.get_command_config("test")
            assert cmd.disable_mcp is True

        await run_with_environment_async(env, run)

    async def test_command_disable_mcp_is_none_when_top_level_not_set(self):
        env = fresh_env()
        async def run():
            cm = await ConfigManager.init(
                {
                    "commands": {"test": {"instructions": "Test"}},
                },
                is_file_content=True,
            )
            cmd = cm.get_command_config("test")
            assert cmd.disable_mcp is None

        await run_with_environment_async(env, run)
