"""Tests for execution timeout and retry support (P1.5)."""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
from typing import Any, Dict, List, Optional
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from qodo.sdk.events import (
    QodoSdkEvent,
    SdkErrorData,
    SdkEventType,
    SdkFinalData,
    create_sdk_event,
)
from qodo.sdk.qodo_sdk import QodoSDK, QodoSDKOptions, QodoSDKRunResult


def _make_final_event(
    success: bool = True,
    error: Optional[str] = None,
    meta: Optional[Dict[str, Any]] = None,
) -> QodoSdkEvent:
    """Create a mock FINAL event."""
    return create_sdk_event(
        event_type=SdkEventType.FINAL,
        run_id="test-run",
        seq=1,
        session_id="test-session",
        data=SdkFinalData(
            success=success,
            error=error,
            model="test-model",
            result={},
            messages={"langchain": [], "openai": []},
            meta=meta or {"tools_auto_approved": True, "subagents_used": False},
        ),
    )


def _make_error_event(message: str = "test error") -> QodoSdkEvent:
    """Create a mock ERROR event."""
    return create_sdk_event(
        event_type=SdkEventType.ERROR,
        run_id="test-run",
        seq=1,
        session_id="test-session",
        data=SdkErrorData(message=message),
    )


class TestTimeoutOptions:
    """Test that stream() and run() accept the new parameters."""

    def test_stream_accepts_timeout_param(self):
        """Verify stream() signature accepts timeout kwarg."""
        import inspect

        sig = inspect.signature(QodoSDK.stream)
        assert "timeout" in sig.parameters
        param = sig.parameters["timeout"]
        assert param.default is None

    def test_run_accepts_timeout_and_max_retries(self):
        """Verify run() signature accepts both timeout and max_retries kwargs."""
        import inspect

        sig = inspect.signature(QodoSDK.run)
        assert "timeout" in sig.parameters
        assert "max_retries" in sig.parameters
        assert sig.parameters["timeout"].default is None
        assert sig.parameters["max_retries"].default is None

    def test_qodo_sdk_options_default_values(self):
        """Verify QodoSDKOptions defaults are unchanged (no new fields needed)."""
        opts = QodoSDKOptions()
        assert opts.auto_approve_tools is True
        assert opts.debug is False
        assert opts.model is None


class TestTimeoutMechanics:
    """Test timeout task creation, cancellation, and event emission."""

    async def test_timeout_task_created_when_specified(self):
        """When timeout is provided, asyncio.create_task should be called."""
        sdk = QodoSDK(QodoSDKOptions())

        # Prepare SDK so stream() doesn't fail during init
        sdk._active_runs = 0
        final_event = _make_final_event(success=True)

        with patch.object(sdk, "_ensure_initialized", new_callable=AsyncMock) as mock_init:
            mock_init.return_value = {
                "command_name": "",
                "prompt_mode": True,
                "project_path": "/tmp",
                "agent_source": {"source": "default"},
            }
            mock_session = MagicMock()
            mock_session.get_session_id.return_value = "test-sid"
            mock_session.get_model.return_value = "test-model"
            sdk._session_context = mock_session

            mock_core = AsyncMock()
            sdk._core = mock_core

            mock_config = MagicMock()
            mock_config.list_commands.return_value = []
            sdk._config_manager = mock_config

            # Inject a final event so the stream ends
            sdk._event_queue = []

            async def start_side_effect(**kwargs: Any) -> None:
                sdk._push_event(
                    SdkEventType.FINAL,
                    "test-sid",
                    {
                        "success": True,
                        "model": "test-model",
                        "result": {},
                        "messages": {"langchain": [], "openai": []},
                        "meta": {
                            "tools_auto_approved": True,
                            "subagents_used": False,
                        },
                    },
                )

            mock_core.start = AsyncMock(side_effect=start_side_effect)

            with patch("asyncio.create_task", wraps=asyncio.create_task) as mock_ct:
                events: List[QodoSdkEvent] = []
                async for event in sdk.stream("test", timeout=5000):
                    events.append(event)

                # create_task should have been called (for the timeout handler)
                assert mock_ct.called

    async def test_timeout_task_not_created_when_none(self):
        """When timeout is None, no timeout task should be created."""
        sdk = QodoSDK(QodoSDKOptions())
        sdk._active_runs = 0

        with patch.object(sdk, "_ensure_initialized", new_callable=AsyncMock) as mock_init:
            mock_init.return_value = {
                "command_name": "",
                "prompt_mode": True,
                "project_path": "/tmp",
                "agent_source": {"source": "default"},
            }
            mock_session = MagicMock()
            mock_session.get_session_id.return_value = "test-sid"
            mock_session.get_model.return_value = "test-model"
            sdk._session_context = mock_session

            mock_core = AsyncMock()
            sdk._core = mock_core

            mock_config = MagicMock()
            mock_config.list_commands.return_value = []
            sdk._config_manager = mock_config

            async def start_side_effect(**kwargs: Any) -> None:
                sdk._push_event(
                    SdkEventType.FINAL,
                    "test-sid",
                    {
                        "success": True,
                        "model": "test-model",
                        "result": {},
                        "messages": {"langchain": [], "openai": []},
                        "meta": {
                            "tools_auto_approved": True,
                            "subagents_used": False,
                        },
                    },
                )

            mock_core.start = AsyncMock(side_effect=start_side_effect)

            with patch("asyncio.create_task", wraps=asyncio.create_task) as mock_ct:
                events: List[QodoSdkEvent] = []
                async for event in sdk.stream("test", timeout=None):
                    events.append(event)

                # create_task should NOT have been called for timeout
                assert not mock_ct.called

    async def test_timeout_task_cancelled_on_normal_completion(self):
        """Timeout task should be cancelled when the stream finishes normally."""
        sdk = QodoSDK(QodoSDKOptions())
        sdk._active_runs = 0

        with patch.object(sdk, "_ensure_initialized", new_callable=AsyncMock) as mock_init:
            mock_init.return_value = {
                "command_name": "",
                "prompt_mode": True,
                "project_path": "/tmp",
                "agent_source": {"source": "default"},
            }
            mock_session = MagicMock()
            mock_session.get_session_id.return_value = "test-sid"
            mock_session.get_model.return_value = "test-model"
            sdk._session_context = mock_session

            mock_core = AsyncMock()
            sdk._core = mock_core

            mock_config = MagicMock()
            mock_config.list_commands.return_value = []
            sdk._config_manager = mock_config

            async def start_side_effect(**kwargs: Any) -> None:
                sdk._push_event(
                    SdkEventType.FINAL,
                    "test-sid",
                    {
                        "success": True,
                        "model": "test-model",
                        "result": {},
                        "messages": {"langchain": [], "openai": []},
                        "meta": {
                            "tools_auto_approved": True,
                            "subagents_used": False,
                        },
                    },
                )

            mock_core.start = AsyncMock(side_effect=start_side_effect)

            created_tasks: List[asyncio.Task[Any]] = []
            original_create_task = asyncio.create_task

            def tracking_create_task(coro: Any, **kwargs: Any) -> Any:
                task = original_create_task(coro, **kwargs)
                created_tasks.append(task)
                return task

            with patch("asyncio.create_task", side_effect=tracking_create_task):
                async for event in sdk.stream("test", timeout=60000):
                    pass

            # Allow the event loop to process the cancellation
            await asyncio.sleep(0)

            # The timeout task should have been cancelled
            assert len(created_tasks) > 0
            for task in created_tasks:
                assert task.cancelled() or task.done()

    async def test_timeout_emits_error_and_final_events(self):
        """Timeout handler should emit ERROR and FINAL events."""
        sdk = QodoSDK(QodoSDKOptions())
        sdk._active_runs = 0

        with patch.object(sdk, "_ensure_initialized", new_callable=AsyncMock) as mock_init:
            mock_init.return_value = {
                "command_name": "",
                "prompt_mode": True,
                "project_path": "/tmp",
                "agent_source": {"source": "default"},
            }
            mock_session = MagicMock()
            mock_session.get_session_id.return_value = "test-sid"
            mock_session.get_model.return_value = "test-model"
            sdk._session_context = mock_session

            mock_core = AsyncMock()
            mock_core.cancel = MagicMock()
            sdk._core = mock_core

            mock_config = MagicMock()
            mock_config.list_commands.return_value = []
            sdk._config_manager = mock_config

            # Don't push any events from start — let timeout fire
            mock_core.start = AsyncMock()

            events: List[QodoSdkEvent] = []
            # Use a very short timeout (10ms) so the timeout fires quickly
            async for event in sdk.stream("test", timeout=10):
                events.append(event)

        event_types = [e.type for e in events]
        # Should contain RUN_STARTED, ERROR, and FINAL
        assert SdkEventType.ERROR in event_types
        assert SdkEventType.FINAL in event_types

        # Check ERROR message
        error_events = [e for e in events if e.type == SdkEventType.ERROR]
        assert len(error_events) >= 1
        error_data = error_events[-1].data
        error_msg = (
            error_data.message if hasattr(error_data, "message") else error_data.get("message")
        )
        assert "timed out" in error_msg.lower()

    async def test_timeout_meta_includes_timed_out_flag(self):
        """The FINAL event from timeout should have meta.timed_out == True."""
        sdk = QodoSDK(QodoSDKOptions())
        sdk._active_runs = 0

        with patch.object(sdk, "_ensure_initialized", new_callable=AsyncMock) as mock_init:
            mock_init.return_value = {
                "command_name": "",
                "prompt_mode": True,
                "project_path": "/tmp",
                "agent_source": {"source": "default"},
            }
            mock_session = MagicMock()
            mock_session.get_session_id.return_value = "test-sid"
            mock_session.get_model.return_value = "test-model"
            sdk._session_context = mock_session

            mock_core = AsyncMock()
            mock_core.cancel = MagicMock()
            sdk._core = mock_core

            mock_config = MagicMock()
            mock_config.list_commands.return_value = []
            sdk._config_manager = mock_config

            # Don't push any events from start — let timeout fire
            mock_core.start = AsyncMock()

            events: List[QodoSdkEvent] = []
            async for event in sdk.stream("test", timeout=10):
                events.append(event)

        final_events = [e for e in events if e.type == SdkEventType.FINAL]
        assert len(final_events) >= 1
        final_data = final_events[-1].data
        meta = final_data.meta if hasattr(final_data, "meta") else final_data.get("meta", {})
        assert meta.get("timed_out") is True


def _create_sdk_with_stream_results(
    results_per_attempt: List[List[QodoSdkEvent]],
) -> QodoSDK:
    """Create a QodoSDK with mocked stream() that yields predetermined events."""
    sdk = QodoSDK(QodoSDKOptions())
    attempt_index = {"value": 0}

    original_stream = sdk.stream

    async def mock_stream(
        command_or_prompt: str,
        *,
        extra_instructions: Optional[str] = None,
        args: Optional[Dict[str, Any]] = None,
        output_schema: Optional[Any] = None,
        timeout: Optional[int] = None,
        dry_run: Optional[bool] = None,
    ):
        idx = attempt_index["value"]
        attempt_index["value"] += 1
        if idx < len(results_per_attempt):
            for event in results_per_attempt[idx]:
                yield event
        else:
            # Fallback: yield a failure final
            yield _make_final_event(success=False, error="No more attempts configured")

    sdk.stream = mock_stream  # type: ignore[assignment]
    sdk.dispose = AsyncMock()  # type: ignore[assignment]
    return sdk


class TestRetryLogic:
    """Test retry behavior in run()."""

    async def test_no_retry_by_default(self):
        """max_retries=None means only 1 attempt."""
        final = _make_final_event(success=False, error="fail")
        sdk = _create_sdk_with_stream_results([[final], [_make_final_event(success=True)]])

        result = await sdk.run("test", max_retries=None)
        assert not result.success
        assert result.error == "fail"

    async def test_max_retries_zero_means_one_attempt(self):
        """max_retries=0 means only 1 attempt (same as None)."""
        final = _make_final_event(success=False, error="fail")
        sdk = _create_sdk_with_stream_results([[final], [_make_final_event(success=True)]])

        result = await sdk.run("test", max_retries=0)
        assert not result.success
        assert result.error == "fail"

    async def test_max_retries_three_means_four_attempts(self):
        """max_retries=3 should try up to 4 times total."""
        fail1 = _make_final_event(success=False, error="fail1")
        fail2 = _make_final_event(success=False, error="fail2")
        fail3 = _make_final_event(success=False, error="fail3")
        fail4 = _make_final_event(success=False, error="fail4")
        sdk = _create_sdk_with_stream_results([[fail1], [fail2], [fail3], [fail4]])

        result = await sdk.run("test", max_retries=3)
        # All 4 attempts failed, should return the last failure
        assert not result.success
        assert result.error == "fail4"

    async def test_retry_stops_on_success(self):
        """If attempt 2 succeeds, don't try attempt 3."""
        fail = _make_final_event(success=False, error="fail")
        success = _make_final_event(success=True)
        never_reached = _make_final_event(success=False, error="should not reach")
        sdk = _create_sdk_with_stream_results([[fail], [success], [never_reached]])

        result = await sdk.run("test", max_retries=5)
        assert result.success
        # dispose should have been called once (before attempt 2)
        sdk.dispose.assert_awaited_once()  # type: ignore[union-attr]

    async def test_retry_returns_last_failure(self):
        """If all attempts fail, return the last result."""
        fail1 = _make_final_event(success=False, error="error-1")
        fail2 = _make_final_event(success=False, error="error-2")
        fail3 = _make_final_event(success=False, error="error-3")
        sdk = _create_sdk_with_stream_results([[fail1], [fail2], [fail3]])

        result = await sdk.run("test", max_retries=2)
        assert not result.success
        assert result.error == "error-3"
