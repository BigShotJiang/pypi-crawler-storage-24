"""Test that all public API can be imported."""

import pytest


def test_main_imports():
    """Test main package imports."""
    from qodo import (
        __version__,
        QodoSDK,
        QodoSDKOptions,
        QodoSDKRunResult,
        ToolApprovalRequest,
        get_sdk_version,
    )

    assert __version__ is not None
    assert QodoSDK is not None
    assert QodoSDKOptions is not None
    assert QodoSDKRunResult is not None
    assert ToolApprovalRequest is not None
    assert get_sdk_version() == __version__


def test_event_imports():
    """Test event type imports."""
    from qodo import (
        QodoSdkEvent,
        SdkEventType,
        SDK_PROTOCOL_V2,
        match_sdk_event,
        create_sdk_event,
        EventEmitter,
    )

    assert SDK_PROTOCOL_V2 == "qodo.sdk.v2"
    assert SdkEventType.INIT == "sdk.init"
    assert SdkEventType.FINAL == "sdk.final"


def test_config_type_imports():
    """Test config type imports."""
    from qodo import (
        AIAssistantConfig,
        CommandConfig,
        ModeConfig,
        MCPConfig,
        OutputSchema,
        CommandArgument,
    )

    # Test that we can instantiate
    config = AIAssistantConfig()
    assert config is not None

    cmd = CommandConfig(name="test")
    assert cmd.name == "test"


def test_error_imports():
    """Test error class imports."""
    from qodo import (
        QodoError,
        QodoAuthError,
        QodoSchemaError,
        QodoBackendBootstrapError,
        QodoConnectionError,
        QodoToolError,
        QodoConfigError,
        QodoTimeoutError,
        QodoCancelledError,
    )

    # Test inheritance
    assert issubclass(QodoAuthError, QodoError)
    assert issubclass(QodoSchemaError, QodoError)
    assert issubclass(QodoBackendBootstrapError, QodoError)
    assert issubclass(QodoConnectionError, QodoError)
    assert issubclass(QodoToolError, QodoError)
    assert issubclass(QodoConfigError, QodoError)
    assert issubclass(QodoTimeoutError, QodoError)
    assert issubclass(QodoCancelledError, QodoError)


def test_environment_imports():
    """Test environment isolation imports."""
    from qodo import (
        EnvironmentServices,
        EnvironmentContext,
        get_current_environment,
        get_global_environment,
        run_with_environment,
        run_with_environment_async,
        is_sdk_mode,
        is_debug_mode,
    )

    # Test basic functionality
    env = get_current_environment()
    global_env = get_global_environment()
    assert env is global_env  # Outside of SDK context, should be same


def test_sdk_instantiation():
    """Test that QodoSDK can be instantiated."""
    from qodo import QodoSDK, QodoSDKOptions

    # With no options
    sdk = QodoSDK()
    assert sdk is not None

    # With options
    options = QodoSDKOptions(project_path="/tmp/test")
    sdk2 = QodoSDK(options)
    assert sdk2 is not None

    # With kwargs
    sdk3 = QodoSDK(project_path="/tmp/test", debug=True)
    assert sdk3 is not None


def test_event_emitter():
    """Test EventEmitter functionality."""
    from qodo import EventEmitter, SdkEventType

    emitter = EventEmitter(
        run_id="test-run",
        session_id="test-session",
    )

    # Test init event
    event = emitter.init(sdk_version="0.1.0")
    assert event.type == SdkEventType.INIT
    assert event.run_id == "test-run"
    assert event.session_id == "test-session"
    assert event.seq == 1

    # Test message delta event
    event2 = emitter.message_delta(
        message_id="msg-1",
        delta="Hello",
    )
    assert event2.type == SdkEventType.MESSAGE_DELTA
    assert event2.seq == 2
    assert event2.data.delta == "Hello"
