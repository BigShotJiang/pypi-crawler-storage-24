"""
Tests for ToolProcessorManager.get_instance() and environment scoping.
"""
from __future__ import annotations

from typing import Any

import pytest

from qodo.mcp.tool_processor import ToolProcessorManager
from qodo.session.environment import (
    EnvironmentServices,
    get_global_environment,
    run_with_environment_async,
)
from tests.helpers.test_env import fresh_env


class TestGetInstance:
    async def test_returns_none_when_no_tpm(self) -> None:
        env = fresh_env()

        async def check() -> None:
            assert ToolProcessorManager.get_instance() is None

        await run_with_environment_async(env, check)

    async def test_returns_tpm_from_current_env(self) -> None:
        env = fresh_env()
        tpm = ToolProcessorManager()
        env.tool_processor_manager = tpm

        async def check() -> None:
            assert ToolProcessorManager.get_instance() is tpm

        await run_with_environment_async(env, check)

    async def test_falls_back_to_global_env(self) -> None:
        global_env = get_global_environment()
        tpm = ToolProcessorManager()
        old_val = global_env.tool_processor_manager
        global_env.tool_processor_manager = tpm
        try:
            # Without a context-local env, should use global
            assert ToolProcessorManager.get_instance() is tpm
        finally:
            global_env.tool_processor_manager = old_val

    async def test_prefers_current_over_global(self) -> None:
        global_env = get_global_environment()
        global_tpm = ToolProcessorManager()
        local_tpm = ToolProcessorManager()
        old_val = global_env.tool_processor_manager
        global_env.tool_processor_manager = global_tpm

        env = fresh_env()
        env.tool_processor_manager = local_tpm

        async def check() -> None:
            assert ToolProcessorManager.get_instance() is local_tpm

        try:
            await run_with_environment_async(env, check)
        finally:
            global_env.tool_processor_manager = old_val


class TestIntegration:
    async def test_pre_and_post_process(self) -> None:
        class AddFieldMW:
            async def pre_execute(
                self, tool_name: str, server_name: str, args: dict[str, Any]
            ) -> dict[str, Any]:
                return {**args, "injected_pre": True}

            async def post_execute(
                self, tool_name: str, server_name: str, result: dict[str, Any]
            ) -> dict[str, Any]:
                return {**result, "injected_post": True}

        tpm = ToolProcessorManager(middleware=[AddFieldMW()])

        pre = await tpm.pre_process_tool("tool", "srv", {"input": 1})
        assert pre["injected_pre"] is True
        assert pre["input"] == 1

        post = await tpm.post_process_tool("tool", "srv", {"output": 2})
        assert post["injected_post"] is True
        assert post["output"] == 2

    async def test_error_collection_across_phases(self) -> None:
        class FailBoth:
            async def pre_execute(
                self, tool_name: str, server_name: str, args: dict[str, Any]
            ) -> dict[str, Any] | None:
                raise ValueError("pre fail")

            async def post_execute(
                self, tool_name: str, server_name: str, result: dict[str, Any]
            ) -> dict[str, Any] | None:
                raise ValueError("post fail")

        tpm = ToolProcessorManager(middleware=[FailBoth()])
        await tpm.pre_process_tool("t", "s", {})
        await tpm.post_process_tool("t", "s", {})

        errors = tpm.get_errors()
        assert len(errors) == 2
        assert errors[0].phase == "pre_execute"
        assert errors[1].phase == "post_execute"

    async def test_middleware_without_methods(self) -> None:
        """Middleware that has neither pre_execute nor post_execute is a no-op."""

        class EmptyMW:
            pass

        tpm = ToolProcessorManager(middleware=[EmptyMW()])
        pre = await tpm.pre_process_tool("t", "s", {"x": 1})
        post = await tpm.post_process_tool("t", "s", {"y": 2})
        assert pre == {"x": 1}
        assert post == {"y": 2}
        assert len(tpm.get_errors()) == 0

    async def test_get_errors_returns_copy(self) -> None:
        tpm = ToolProcessorManager()
        errors1 = tpm.get_errors()
        errors1.append(None)  # type: ignore[arg-type]
        assert len(tpm.get_errors()) == 0
