"""Tests for SessionContext — mirrors session-context.test.ts."""
from __future__ import annotations

import os
from unittest.mock import MagicMock, patch

import pytest

from qodo.parser.types import CommandConfig
from qodo.session.environment import (
    EnvironmentServices,
    get_current_environment,
    run_with_environment_async,
)
from qodo.session.session_context import SessionContext

from tests.helpers.test_env import create_mock_server_data, fresh_env


def _mock_server_data():
    """Create a patcher that mocks ServerData for session context tests."""
    mock_sd = create_mock_server_data()
    return patch("qodo.session.server_data.ServerData", mock_sd)


class TestNewSessionContext:
    """SessionContext.new_session_context tests."""

    async def test_creates_context_with_command_config(self):
        env = fresh_env()
        async def run():
            with _mock_server_data():
                ctx = await SessionContext.new_session_context(
                    flags={"sdk": True},
                    command=CommandConfig(instructions="Test instructions", permissions="rwx"),
                    general_instructions="General instructions",
                    system_prompt="System prompt",
                )
                assert ctx is not None
                assert ctx.get_command().instructions == "Test instructions"
                assert ctx.get_general_instructions() == "General instructions"
                assert ctx.get_system_prompt() == "System prompt"

        await run_with_environment_async(env, run)

    async def test_registers_context_on_current_environment(self):
        env = fresh_env()
        async def run():
            with _mock_server_data():
                ctx = await SessionContext.new_session_context(
                    flags={"sdk": True},
                    command=CommandConfig(instructions="Test"),
                )
                current_env = get_current_environment()
                assert current_env.session_context is ctx

        await run_with_environment_async(env, run)

    async def test_uses_provided_session_id(self):
        env = fresh_env()
        async def run():
            with _mock_server_data():
                ctx = await SessionContext.new_session_context(
                    flags={"sdk": True},
                    command=CommandConfig(instructions="Test"),
                    session_id="custom-session-123",
                )
                assert ctx.get_session_id() == "custom-session-123"

        await run_with_environment_async(env, run)


class TestPermissions:
    """SessionContext permissions tests."""

    async def test_defaults_to_rwx_permissions(self):
        env = fresh_env()
        async def run():
            with _mock_server_data():
                ctx = await SessionContext.new_session_context(
                    flags={"sdk": True},
                    command=CommandConfig(permissions="rwx"),
                )
                assert ctx.get_permissions() == "rwx"

        await run_with_environment_async(env, run)

    async def test_set_permissions_accepts_valid_permission_strings(self):
        env = fresh_env()
        async def run():
            with _mock_server_data():
                ctx = await SessionContext.new_session_context(
                    flags={"sdk": True},
                    command=CommandConfig(),
                )
                ctx.set_permissions("r")
                assert ctx.get_permissions() == "r"

                ctx.set_permissions("rw")
                assert ctx.get_permissions() == "rw"

                ctx.set_permissions("rx")
                assert ctx.get_permissions() == "rx"

                ctx.set_permissions("-")
                assert ctx.get_permissions() == "-"

        await run_with_environment_async(env, run)

    async def test_set_permissions_rejects_invalid_permission_strings(self):
        env = fresh_env()
        async def run():
            with _mock_server_data():
                ctx = await SessionContext.new_session_context(
                    flags={"sdk": True},
                    command=CommandConfig(permissions="rwx"),
                )
                # Invalid string should be ignored and keep previous value
                ctx.set_permissions("abc")
                assert ctx.get_permissions() == "rwx"

        await run_with_environment_async(env, run)

    async def test_permissions_from_command_config_are_applied(self):
        env = fresh_env()
        async def run():
            with _mock_server_data():
                ctx = await SessionContext.new_session_context(
                    flags={"sdk": True},
                    command=CommandConfig(permissions="r"),
                )
                assert ctx.get_permissions() == "r"

        await run_with_environment_async(env, run)


class TestAccessiblePaths:
    """SessionContext accessible paths tests."""

    async def test_starts_with_no_accessible_paths(self):
        env = fresh_env()
        async def run():
            with _mock_server_data():
                ctx = await SessionContext.new_session_context(
                    flags={"sdk": True},
                    command=CommandConfig(),
                )
                assert ctx.get_accessible_paths() == []

        await run_with_environment_async(env, run)

    async def test_set_accessible_paths_validates_and_stores_valid_paths(self):
        env = fresh_env()
        async def run():
            with _mock_server_data():
                ctx = await SessionContext.new_session_context(
                    flags={"sdk": True},
                    command=CommandConfig(),
                )
                valid_paths = await ctx.set_accessible_paths(["/tmp"])
                assert len(valid_paths) > 0
                assert len(ctx.get_accessible_paths()) > 0

        await run_with_environment_async(env, run)

    async def test_set_accessible_paths_skips_inaccessible_paths(self):
        env = fresh_env()
        async def run():
            with _mock_server_data():
                ctx = await SessionContext.new_session_context(
                    flags={"sdk": True},
                    command=CommandConfig(),
                )
                # The nonexistent path should be skipped
                await ctx.set_accessible_paths(["/nonexistent/path/12345"])

        await run_with_environment_async(env, run)

    async def test_set_accessible_paths_deduplicates_paths(self):
        env = fresh_env()
        async def run():
            with _mock_server_data():
                ctx = await SessionContext.new_session_context(
                    flags={"sdk": True},
                    command=CommandConfig(),
                )
                await ctx.set_accessible_paths(["/tmp", "/tmp"])
                paths = ctx.get_accessible_paths()
                unique = set(paths)
                assert len(paths) == len(unique)

        await run_with_environment_async(env, run)


class TestModel:
    """SessionContext model tests."""

    async def test_uses_default_model_when_not_specified(self):
        env = fresh_env()
        async def run():
            with _mock_server_data():
                ctx = await SessionContext.new_session_context(
                    flags={"sdk": True},
                    command=CommandConfig(),
                )
                assert ctx.get_model() == "mock-model"

        await run_with_environment_async(env, run)

    async def test_uses_flag_model_when_specified(self):
        env = fresh_env()
        async def run():
            with _mock_server_data():
                ctx = await SessionContext.new_session_context(
                    flags={"sdk": True, "model": "custom-model"},
                    command=CommandConfig(),
                )
                assert ctx.get_model() == "custom-model"

        await run_with_environment_async(env, run)

    async def test_set_model_updates_the_model(self):
        env = fresh_env()
        async def run():
            with _mock_server_data():
                ctx = await SessionContext.new_session_context(
                    flags={"sdk": True},
                    command=CommandConfig(),
                )
                ctx.set_model("new-model")
                assert ctx.get_model() == "new-model"

        await run_with_environment_async(env, run)


class TestExecutionStrategy:
    """SessionContext execution strategy tests."""

    async def test_returns_plan_when_plan_flag_is_set(self):
        env = fresh_env()
        async def run():
            with _mock_server_data():
                ctx = await SessionContext.new_session_context(
                    flags={"sdk": True, "plan": True},
                    command=CommandConfig(),
                )
                assert ctx.get_execution_strategy() == "plan"

        await run_with_environment_async(env, run)

    async def test_returns_act_when_act_flag_is_set(self):
        env = fresh_env()
        async def run():
            with _mock_server_data():
                ctx = await SessionContext.new_session_context(
                    flags={"sdk": True, "act": True},
                    command=CommandConfig(),
                )
                assert ctx.get_execution_strategy() == "act"

        await run_with_environment_async(env, run)

    async def test_throws_when_both_plan_and_act_are_set(self):
        env = fresh_env()
        async def run():
            with _mock_server_data():
                ctx = await SessionContext.new_session_context(
                    flags={"sdk": True, "plan": True, "act": True},
                    command=CommandConfig(),
                )
                with pytest.raises(ValueError, match="Cannot specify both"):
                    ctx.get_execution_strategy()

        await run_with_environment_async(env, run)

    async def test_falls_back_to_command_execution_strategy(self):
        env = fresh_env()
        async def run():
            with _mock_server_data():
                ctx = await SessionContext.new_session_context(
                    flags={"sdk": True},
                    command=CommandConfig(execution_strategy="act"),
                )
                assert ctx.get_execution_strategy() == "act"

        await run_with_environment_async(env, run)


class TestEnvironmentIsolation:
    """SessionContext environment isolation tests."""

    async def test_two_environments_get_independent_session_context_instances(self):
        env1 = fresh_env()
        env2 = fresh_env()

        model1 = ""
        model2 = ""

        async def run1():
            nonlocal model1
            with _mock_server_data():
                ctx = await SessionContext.new_session_context(
                    flags={"sdk": True, "model": "model-A"},
                    command=CommandConfig(),
                )
                model1 = ctx.get_model()

        async def run2():
            nonlocal model2
            with _mock_server_data():
                ctx = await SessionContext.new_session_context(
                    flags={"sdk": True, "model": "model-B"},
                    command=CommandConfig(),
                )
                model2 = ctx.get_model()

        await run_with_environment_async(env1, run1)
        await run_with_environment_async(env2, run2)

        assert model1 == "model-A"
        assert model2 == "model-B"


class TestReset:
    """SessionContext reset tests."""

    async def test_reset_clears_accessible_paths_and_execution_cwd(self):
        env = fresh_env()
        async def run():
            with _mock_server_data():
                ctx = await SessionContext.new_session_context(
                    flags={"sdk": True},
                    command=CommandConfig(),
                )
                await ctx.set_accessible_paths(["/tmp"])
                assert len(ctx.get_accessible_paths()) > 0

                ctx.reset()
                assert ctx.get_accessible_paths() == []
                assert ctx.get_execution_cwd() is None

        await run_with_environment_async(env, run)


class TestSerialize:
    """SessionContext serialize tests."""

    async def test_serialize_returns_all_context_fields(self):
        env = fresh_env()
        async def run():
            with _mock_server_data():
                ctx = await SessionContext.new_session_context(
                    flags={"sdk": True, "model": "test-model"},
                    command=CommandConfig(instructions="Do stuff", permissions="rw"),
                    general_instructions="General",
                    system_prompt="System",
                )
                serialized = ctx.serialize()
                assert serialized["model"] == "test-model"
                assert serialized["general_instructions"] == "General"
                assert serialized["system_prompt"] == "System"
                assert serialized["permissions"] == "rw"
                assert serialized["app_type"] == "sdk"
                assert serialized["command"]["instructions"] == "Do stuff"

        await run_with_environment_async(env, run)


class TestPreviousSessionSummarization:
    """SessionContext previous session summarization tests."""

    async def test_add_and_retrieve_summaries(self):
        env = fresh_env()
        async def run():
            with _mock_server_data():
                ctx = await SessionContext.new_session_context(
                    flags={"sdk": True},
                    command=CommandConfig(),
                )
                ctx.add_previous_session_summarization("session-1", "Summary of session 1")
                ctx.add_previous_session_summarization("session-2", "Summary of session 2")

                summaries = ctx.get_previous_sessions_summarization()
                assert len(summaries) == 2
                assert summaries[0] == {"session_id": "session-1", "summary": "Summary of session 1"}
                assert summaries[1] == {"session_id": "session-2", "summary": "Summary of session 2"}

        await run_with_environment_async(env, run)

    async def test_ignores_empty_session_ids_and_summaries(self):
        env = fresh_env()
        async def run():
            with _mock_server_data():
                ctx = await SessionContext.new_session_context(
                    flags={"sdk": True},
                    command=CommandConfig(),
                )
                ctx.add_previous_session_summarization("", "Some summary")
                ctx.add_previous_session_summarization("session-1", "")
                ctx.add_previous_session_summarization("  ", "  ")

                assert ctx.get_previous_sessions_summarization() == []

        await run_with_environment_async(env, run)


class TestDebugMode:
    """SessionContext debug mode tests."""

    async def test_is_debug_mode_returns_true_when_flag_is_set(self):
        env = fresh_env()
        async def run():
            with _mock_server_data():
                ctx = await SessionContext.new_session_context(
                    flags={"sdk": True, "debug": True},
                    command=CommandConfig(),
                )
                assert ctx.is_debug_mode() is True

        await run_with_environment_async(env, run)

    async def test_is_debug_mode_returns_true_when_env_var_is_set(self):
        env = fresh_env()
        orig = os.environ.get("QODO_DEBUG")
        os.environ["QODO_DEBUG"] = "true"
        try:
            async def run():
                with _mock_server_data():
                    ctx = await SessionContext.new_session_context(
                        flags={"sdk": True},
                        command=CommandConfig(),
                    )
                    assert ctx.is_debug_mode() is True

            await run_with_environment_async(env, run)
        finally:
            if orig is not None:
                os.environ["QODO_DEBUG"] = orig
            else:
                os.environ.pop("QODO_DEBUG", None)

    async def test_is_debug_mode_returns_false_when_neither_flag_nor_env_is_set(self):
        env = fresh_env()
        orig = os.environ.get("QODO_DEBUG")
        os.environ.pop("QODO_DEBUG", None)
        try:
            async def run():
                with _mock_server_data():
                    ctx = await SessionContext.new_session_context(
                        flags={"sdk": True},
                        command=CommandConfig(),
                    )
                    assert ctx.is_debug_mode() is False

            await run_with_environment_async(env, run)
        finally:
            if orig is not None:
                os.environ["QODO_DEBUG"] = orig
