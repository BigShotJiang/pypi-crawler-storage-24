"""Test SDK builders (sdk_agent, sdk_command, sdk_args)."""

import pytest
from pydantic import BaseModel, Field

from qodo import (
    sdk_agent,
    sdk_command,
    sdk_args,
    pydantic_output_schema,
    parse_args_with_schema,
    QodoSchemaError,
)


class TestSdkCommand:
    """Tests for sdk_command builder."""

    def test_basic_command(self):
        """Test basic command creation."""
        cmd = sdk_command(
            name="test",
            description="Test command",
            instructions="Do something",
        )

        assert cmd.name == "test"
        assert cmd.description == "Test command"
        assert cmd.instructions == "Do something"
        assert cmd.permissions == "rwx"  # default

    def test_command_with_tools(self):
        """Test command with tool configuration."""
        cmd = sdk_command(
            name="review",
            available_tools=["filesystem", "git"],
            ignore_tools=["shell"],
        )

        assert cmd.available_tools == ["filesystem", "git"]
        assert cmd.ignore_tools == ["shell"]

    def test_command_with_pydantic_args(self):
        """Test command with Pydantic args schema."""

        class ReviewArgs(BaseModel):
            files: list[str] = Field(description="Files to review")
            depth: int = Field(default=1, description="Review depth")

        cmd = sdk_command(name="review", args=ReviewArgs)

        assert cmd.arguments is not None
        assert len(cmd.arguments) == 2

        # Check files argument
        files_arg = next(a for a in cmd.arguments if a.name == "files")
        assert files_arg.type == "array"
        assert files_arg.required is True
        assert files_arg.description == "Files to review"

        # Check depth argument
        depth_arg = next(a for a in cmd.arguments if a.name == "depth")
        assert depth_arg.type == "number"
        assert depth_arg.required is False
        assert depth_arg.default == 1

    def test_command_with_pydantic_output(self):
        """Test command with Pydantic output schema."""

        class ReviewOutput(BaseModel):
            issues: list[str] = Field(description="Found issues")
            score: float = Field(description="Quality score 0-10")

        cmd = sdk_command(name="review", output=ReviewOutput)

        assert cmd.output_schema is not None
        assert cmd.output_schema.type == "json_schema"
        assert cmd.output_schema.json_schema["name"] == "review_output"

    def test_command_with_custom_output_name(self):
        """Test command with custom output schema name."""

        class Output(BaseModel):
            result: str = Field(description="The result")

        cmd = sdk_command(name="test", output=Output, output_name="custom_output")

        assert cmd.output_schema.json_schema["name"] == "custom_output"

    def test_command_output_missing_description_raises(self):
        """Test that output schema missing descriptions raises error."""

        class BadOutput(BaseModel):
            result: str  # Missing description!

        with pytest.raises(QodoSchemaError) as exc_info:
            sdk_command(name="bad", output=BadOutput)

        assert "missing description" in str(exc_info.value).lower()

    def test_command_both_output_and_json_schema_raises(self):
        """Test that providing both output and output_json_schema raises error."""

        class Output(BaseModel):
            result: str = Field(description="Result")

        with pytest.raises(QodoSchemaError) as exc_info:
            sdk_command(
                name="bad",
                output=Output,
                output_json_schema={"type": "object"},
            )

        assert "not both" in str(exc_info.value).lower()


class TestSdkAgent:
    """Tests for sdk_agent builder."""

    def test_basic_agent(self):
        """Test basic agent creation."""
        cmd = sdk_command(name="default", description="Default command")
        agent = sdk_agent(commands={"default": cmd})

        assert agent.commands is not None
        assert "default" in agent.commands
        assert agent.version == "1.0"

    def test_agent_with_config(self):
        """Test agent with full configuration."""
        cmd1 = sdk_command(name="review")
        cmd2 = sdk_command(name="fix")

        agent = sdk_agent(
            commands={"review": cmd1, "fix": cmd2},
            model="gpt-4",
            instructions="You are a helpful assistant.",
            available_tools=["filesystem", "git"],
            execution_strategy="act",
        )

        assert agent.model == "gpt-4"
        assert agent.instructions == "You are a helpful assistant."
        assert agent.available_tools == ["filesystem", "git"]
        assert agent.execution_strategy == "act"
        assert len(agent.commands) == 2


class TestSdkArgs:
    """Tests for sdk_args helper."""

    def test_simple_args(self):
        """Test simple args creation."""
        Args = sdk_args(
            name=str,
            count=int,
            active=bool,
        )

        # Verify it's a Pydantic model
        assert issubclass(Args, BaseModel)

        # Test instantiation
        args = Args(name="test", count=5, active=True)
        assert args.name == "test"
        assert args.count == 5
        assert args.active is True

    def test_args_with_defaults(self):
        """Test args with default values."""
        Args = sdk_args(
            files=(list[str], Field(description="Files")),
            depth=(int, Field(default=1, description="Depth")),
            verbose=(bool, Field(default=False)),
        )

        # Test with defaults
        args = Args(files=["a.py"])
        assert args.files == ["a.py"]
        assert args.depth == 1
        assert args.verbose is False

    def test_args_validation(self):
        """Test that args validation works."""
        Args = sdk_args(name=str, count=int)

        # Invalid type should raise
        with pytest.raises(Exception):
            Args(name="test", count="not_a_number")


class TestSchemas:
    """Tests for schema utilities."""

    def test_pydantic_output_schema(self):
        """Test Pydantic to output schema conversion."""

        class Output(BaseModel):
            result: str = Field(description="The result")
            count: int = Field(description="Item count")

        schema = pydantic_output_schema("test_output", Output)

        assert schema["type"] == "json_schema"
        assert schema["json_schema"]["name"] == "test_output"
        assert schema["json_schema"]["strict"] is True
        assert "properties" in schema["json_schema"]["schema"]

    def test_parse_args_with_schema(self):
        """Test argument parsing with schema."""

        class Args(BaseModel):
            files: list[str]
            depth: int = 1

        # Valid args
        result = parse_args_with_schema(Args, {"files": ["a.py", "b.py"]})
        assert result.files == ["a.py", "b.py"]
        assert result.depth == 1

        # With optional
        result2 = parse_args_with_schema(Args, {"files": ["a.py"], "depth": 3})
        assert result2.depth == 3

    def test_parse_args_invalid_raises(self):
        """Test that invalid args raise QodoSchemaError."""

        class Args(BaseModel):
            files: list[str]

        with pytest.raises(QodoSchemaError) as exc_info:
            parse_args_with_schema(Args, {"files": "not_a_list"})

        assert "Invalid command args" in str(exc_info.value)

    def test_parse_args_none(self):
        """Test parsing None args uses defaults."""

        class Args(BaseModel):
            name: str = "default"

        result = parse_args_with_schema(Args, None)
        assert result.name == "default"
