"""
Tests for AuthProvider — environment-scoped auth state.

Mirrors the TypeScript SDK's tests/auth-provider.test.ts.
"""

from __future__ import annotations

import asyncio
import os
from pathlib import Path
from unittest.mock import patch

import pytest

from qodo.auth import AuthProvider
from qodo.auth.auth import AuthConfig
from qodo.errors import QodoAuthError
from qodo.sdk.qodo_sdk import QodoSDKOptions
from qodo.session.environment import (
    EnvironmentServices,
    get_current_environment,
    get_global_environment,
    run_with_environment,
    run_with_environment_async,
)

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def _clean_env(monkeypatch: pytest.MonkeyPatch) -> None:
    """Ensure QODO_API_KEY is cleared before each test and restored after."""
    monkeypatch.delenv("QODO_API_KEY", raising=False)


# ---------------------------------------------------------------------------
# AuthProvider — core behaviour
# ---------------------------------------------------------------------------


class TestAuthProvider:
    """Tests for AuthProvider class."""

    def test_two_instances_with_different_keys_are_isolated(self) -> None:
        """Test 1: Two AuthProvider instances with different keys are isolated."""
        provider_a = AuthProvider("key-a")
        provider_b = AuthProvider("key-b")

        config_a = provider_a.get_auth_config()
        config_b = provider_b.get_auth_config()

        assert config_a.token == "key-a"
        assert config_b.token == "key-b"
        assert config_a.token != config_b.token

    def test_constructor_reads_from_env_var_when_no_explicit_key(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test 2: Constructor reads from QODO_API_KEY env var when no explicit key."""
        monkeypatch.setenv("QODO_API_KEY", "env-key-123")
        provider = AuthProvider()

        config = provider.get_auth_config()
        assert config.token == "env-key-123"
        assert config.source == "env"

    def test_explicit_api_key_takes_precedence_over_env_var(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test 3: Explicit api_key takes precedence over env var."""
        monkeypatch.setenv("QODO_API_KEY", "env-key")
        provider = AuthProvider("explicit-key")

        config = provider.get_auth_config()
        assert config.token == "explicit-key"

    def test_validate_succeeds_when_key_is_already_set(self) -> None:
        """Test 4: validate() succeeds when key is already set."""
        provider = AuthProvider("valid-key")
        provider.validate()  # should not raise

    def test_validate_raises_when_no_key_and_no_auth_file(self) -> None:
        """Test 5: validate() raises QodoAuthError when no key and no auth file."""
        with patch.object(Path, "exists", return_value=False):
            provider = AuthProvider()
            with pytest.raises(QodoAuthError, match="Qodo API key not found"):
                provider.validate()

    def test_validate_reads_from_auth_file_when_no_env_key(self) -> None:
        """Test 6: validate() reads from ~/.qodo/auth.key when no env key."""
        with (
            patch.object(Path, "exists", return_value=True),
            patch.object(Path, "read_text", return_value="file-key-456\n"),
        ):
            provider = AuthProvider()
            provider.validate()

            config = provider.get_auth_config()
            assert config.token == "file-key-456"
            assert config.source == "file"

    def test_get_auth_config_returns_correct_token_and_source_for_explicit_key(
        self,
    ) -> None:
        """Test 7: get_auth_config() returns correct token and source for explicit key."""
        provider = AuthProvider("my-token")
        config = provider.get_auth_config()

        assert config.token == "my-token"
        assert config.source == "env"

    def test_get_auth_config_returns_empty_token_when_no_key(self) -> None:
        """Test 8: get_auth_config() with no key returns empty token."""
        provider = AuthProvider()
        config = provider.get_auth_config()

        assert config.token == ""
        assert config.source == "env"

    def test_handle_401_error_raises_with_env_source_message(self) -> None:
        """Test 9: handle_401_error() raises with env source message."""
        provider = AuthProvider("some-key")

        with pytest.raises(QodoAuthError, match="Please check your QODO_API_KEY"):
            provider.handle_401_error()

    def test_handle_401_error_raises_with_file_source_message(self) -> None:
        """Test 10: handle_401_error() raises with file source message when key was from file."""
        with (
            patch.object(Path, "exists", return_value=True),
            patch.object(Path, "read_text", return_value="file-key"),
        ):
            provider = AuthProvider()
            provider.validate()

            with pytest.raises(
                QodoAuthError, match="Invalid API key stored in ~/.qodo/auth.key"
            ):
                provider.handle_401_error()

    def test_os_environ_is_never_mutated_by_auth_provider(self) -> None:
        """Test 11: os.environ is never mutated by AuthProvider."""
        assert os.environ.get("QODO_API_KEY") is None

        provider = AuthProvider("my-secret-key")
        provider.validate()
        provider.get_auth_config()

        assert os.environ.get("QODO_API_KEY") is None

    def test_multiple_instances_do_not_share_state(self) -> None:
        """Test 12: Multiple instances don't share state."""
        with patch.object(Path, "exists", return_value=False):
            provider1 = AuthProvider("key-1")
            provider2 = AuthProvider("key-2")
            provider3 = AuthProvider()

            assert provider1.get_auth_config().token == "key-1"
            assert provider2.get_auth_config().token == "key-2"
            assert provider3.get_auth_config().token == ""

            # Validating one should not affect others
            provider1.validate()  # should not raise
            with pytest.raises(QodoAuthError):
                provider3.validate()
            # provider1 still has its key
            assert provider1.get_auth_config().token == "key-1"


# ---------------------------------------------------------------------------
# AuthProvider — environment isolation
# ---------------------------------------------------------------------------


class TestAuthProviderEnvironmentIsolation:
    """Tests for AuthProvider environment isolation via contextvars."""

    async def test_two_concurrent_environments_see_own_auth_provider(self) -> None:
        """Test 13: Two concurrent environments see their own AuthProvider."""
        results: list[str] = []

        async def task_a() -> None:
            await asyncio.sleep(0.01)
            env = get_current_environment()
            results.append(env.auth_provider.get_auth_config().token)

        async def task_b() -> None:
            env = get_current_environment()
            results.append(env.auth_provider.get_auth_config().token)

        env_a = EnvironmentServices(
            sdk_mode=True, auth_provider=AuthProvider("tenant-A-key")
        )
        env_b = EnvironmentServices(
            sdk_mode=True, auth_provider=AuthProvider("tenant-B-key")
        )

        t1 = run_with_environment_async(env_a, task_a)
        t2 = run_with_environment_async(env_b, task_b)
        await asyncio.gather(t1, t2)

        assert "tenant-A-key" in results
        assert "tenant-B-key" in results
        assert len(results) == 2

    def test_environment_without_auth_provider_falls_back_to_none(self) -> None:
        """Test 14: Environment without auth_provider falls back to None."""
        def check() -> None:
            env = get_current_environment()
            assert env.auth_provider is None

        run_with_environment(EnvironmentServices(sdk_mode=True), check)

    async def test_environment_auth_provider_accessible_in_nested_async_calls(
        self,
    ) -> None:
        """Test 15: Environment auth_provider accessible in nested async calls."""
        async def run() -> None:
            async def fetch_auth() -> AuthConfig:
                await asyncio.sleep(0.005)
                return get_current_environment().auth_provider.get_auth_config()

            config = await fetch_auth()
            assert config.token == "nested-key"

        env = EnvironmentServices(
            sdk_mode=True, auth_provider=AuthProvider("nested-key")
        )
        await run_with_environment_async(env, run)

    def test_global_environment_has_no_auth_provider_by_default(self) -> None:
        """Test 16: Global environment has no auth_provider by default."""
        env = get_global_environment()
        assert env.auth_provider is None

    def test_qodo_sdk_options_accepts_api_key(self) -> None:
        """Test 17: QodoSDKOptions accepts api_key."""
        opts = QodoSDKOptions(api_key="my-api-key")
        assert opts.api_key == "my-api-key"

    def test_os_environ_not_mutated_with_file_based_key(self) -> None:
        """Test 18: os.environ not mutated with file-based key."""
        with (
            patch.object(Path, "exists", return_value=True),
            patch.object(Path, "read_text", return_value="file-based-key"),
        ):
            assert os.environ.get("QODO_API_KEY") is None

            provider = AuthProvider()
            provider.validate()

            # Key should be loaded from file
            assert provider.get_auth_config().token == "file-based-key"
            # But os.environ should remain untouched
            assert os.environ.get("QODO_API_KEY") is None

    def test_validate_is_idempotent(self) -> None:
        """Test 19: validate() is idempotent -- calling twice does not change state."""
        provider = AuthProvider("stable-key")
        provider.validate()
        config1 = provider.get_auth_config()
        provider.validate()
        config2 = provider.get_auth_config()

        assert config1.token == config2.token
        assert config1.source == config2.source

    def test_validate_treats_empty_string_from_file_as_missing(self) -> None:
        """Test 20: validate() with empty string key from file treats it as missing."""
        with (
            patch.object(Path, "exists", return_value=True),
            patch.object(Path, "read_text", return_value="  \n  "),
        ):
            provider = AuthProvider()
            # Empty/whitespace key after trim is falsy, should raise
            with pytest.raises(QodoAuthError):
                provider.validate()

    def test_auth_config_is_dataclass(self) -> None:
        """Test 21: AuthConfig returned is a proper dataclass with token and source."""
        provider = AuthProvider("test-key")
        config = provider.get_auth_config()
        assert isinstance(config, AuthConfig)
        assert hasattr(config, "token")
        assert hasattr(config, "source")

    def test_auth_provider_with_none_api_key_reads_env(
        self, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        """Test 22: AuthProvider(None) behaves same as AuthProvider() and reads env."""
        monkeypatch.setenv("QODO_API_KEY", "from-env")
        provider = AuthProvider(None)
        config = provider.get_auth_config()
        assert config.token == "from-env"
        assert config.source == "env"
