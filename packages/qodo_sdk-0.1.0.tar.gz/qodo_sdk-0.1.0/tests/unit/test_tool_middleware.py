"""
Tests for ToolProcessorManager — middleware lifecycle, ordering, timeouts, errors.
"""
from __future__ import annotations

import asyncio
from typing import Any

import pytest

from qodo.errors import ToolMiddlewareError
from qodo.mcp.tool_processor import ToolProcessorManager


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

class PassthroughMiddleware:
    """Middleware that returns args/result unchanged."""

    async def pre_execute(
        self, tool_name: str, server_name: str, args: dict[str, Any]
    ) -> dict[str, Any] | None:
        return args

    async def post_execute(
        self, tool_name: str, server_name: str, result: dict[str, Any]
    ) -> dict[str, Any] | None:
        return result


class ArgsModifyingMiddleware:
    """Middleware that adds a field to args."""

    def __init__(self, key: str, value: Any) -> None:
        self._key = key
        self._value = value

    async def pre_execute(
        self, tool_name: str, server_name: str, args: dict[str, Any]
    ) -> dict[str, Any]:
        args[self._key] = self._value
        return args


class ResultModifyingMiddleware:
    """Middleware that modifies the result."""

    def __init__(self, key: str, value: Any) -> None:
        self._key = key
        self._value = value

    async def post_execute(
        self, tool_name: str, server_name: str, result: dict[str, Any]
    ) -> dict[str, Any]:
        result[self._key] = self._value
        return result


class FailingPreMiddleware:
    """Middleware whose pre_execute raises."""

    async def pre_execute(
        self, tool_name: str, server_name: str, args: dict[str, Any]
    ) -> dict[str, Any] | None:
        raise RuntimeError("pre_execute boom")


class FailingPostMiddleware:
    """Middleware whose post_execute raises."""

    async def post_execute(
        self, tool_name: str, server_name: str, result: dict[str, Any]
    ) -> dict[str, Any] | None:
        raise RuntimeError("post_execute boom")


class SlowMiddleware:
    """Middleware that sleeps longer than the timeout."""

    async def pre_execute(
        self, tool_name: str, server_name: str, args: dict[str, Any]
    ) -> dict[str, Any] | None:
        await asyncio.sleep(30)
        return args

    async def post_execute(
        self, tool_name: str, server_name: str, result: dict[str, Any]
    ) -> dict[str, Any] | None:
        await asyncio.sleep(30)
        return result


class ReturnsNoneMiddleware:
    """Middleware that returns None (no-op)."""

    async def pre_execute(
        self, tool_name: str, server_name: str, args: dict[str, Any]
    ) -> None:
        return None

    async def post_execute(
        self, tool_name: str, server_name: str, result: dict[str, Any]
    ) -> None:
        return None


class OrderTracker:
    """Tracks the order in which middleware is called."""

    calls: list[str] = []

    def __init__(self, name: str) -> None:
        self._name = name

    async def pre_execute(
        self, tool_name: str, server_name: str, args: dict[str, Any]
    ) -> dict[str, Any] | None:
        OrderTracker.calls.append(f"pre:{self._name}")
        return args

    async def post_execute(
        self, tool_name: str, server_name: str, result: dict[str, Any]
    ) -> dict[str, Any] | None:
        OrderTracker.calls.append(f"post:{self._name}")
        return result


# ---------------------------------------------------------------------------
# add_middleware / clear_middleware
# ---------------------------------------------------------------------------

class TestAddClearMiddleware:
    def test_add_middleware(self) -> None:
        tpm = ToolProcessorManager()
        mw = PassthroughMiddleware()
        tpm.add_middleware(mw)
        assert len(tpm._middleware) == 1

    def test_add_multiple_middleware(self) -> None:
        tpm = ToolProcessorManager()
        tpm.add_middleware(PassthroughMiddleware())
        tpm.add_middleware(PassthroughMiddleware())
        assert len(tpm._middleware) == 2

    def test_clear_middleware(self) -> None:
        tpm = ToolProcessorManager(middleware=[PassthroughMiddleware()])
        tpm.clear_middleware()
        assert len(tpm._middleware) == 0

    def test_init_with_middleware_list(self) -> None:
        mws = [PassthroughMiddleware(), PassthroughMiddleware()]
        tpm = ToolProcessorManager(middleware=mws)
        assert len(tpm._middleware) == 2

    def test_init_without_middleware(self) -> None:
        tpm = ToolProcessorManager()
        assert len(tpm._middleware) == 0


# ---------------------------------------------------------------------------
# pre_process_tool
# ---------------------------------------------------------------------------

class TestPreProcess:
    async def test_passthrough(self) -> None:
        tpm = ToolProcessorManager(middleware=[PassthroughMiddleware()])
        result = await tpm.pre_process_tool("tool", "server", {"x": 1})
        assert result == {"x": 1}

    async def test_modifies_args(self) -> None:
        tpm = ToolProcessorManager(
            middleware=[ArgsModifyingMiddleware("added", "yes")]
        )
        result = await tpm.pre_process_tool("tool", "server", {"x": 1})
        assert result["added"] == "yes"
        assert result["x"] == 1

    async def test_runs_in_order(self) -> None:
        OrderTracker.calls = []
        tpm = ToolProcessorManager(
            middleware=[OrderTracker("first"), OrderTracker("second")]
        )
        await tpm.pre_process_tool("tool", "server", {})
        assert OrderTracker.calls == ["pre:first", "pre:second"]

    async def test_protected_field_stripping(self) -> None:
        class InjectsIdentifier:
            async def pre_execute(
                self, tool_name: str, server_name: str, args: dict[str, Any]
            ) -> dict[str, Any]:
                args["identifier"] = "HACKED"
                args["custom"] = "ok"
                return args

        tpm = ToolProcessorManager(middleware=[InjectsIdentifier()])
        result = await tpm.pre_process_tool(
            "tool", "server", {"identifier": "original", "data": 1}
        )
        assert result["identifier"] == "original"
        assert result["custom"] == "ok"

    async def test_returns_none_keeps_original(self) -> None:
        tpm = ToolProcessorManager(middleware=[ReturnsNoneMiddleware()])
        result = await tpm.pre_process_tool("tool", "server", {"x": 1})
        assert result == {"x": 1}

    async def test_no_middleware(self) -> None:
        tpm = ToolProcessorManager()
        result = await tpm.pre_process_tool("tool", "server", {"x": 1})
        assert result == {"x": 1}

    async def test_chained_modifications(self) -> None:
        tpm = ToolProcessorManager(
            middleware=[
                ArgsModifyingMiddleware("a", 1),
                ArgsModifyingMiddleware("b", 2),
            ]
        )
        result = await tpm.pre_process_tool("tool", "server", {})
        assert result["a"] == 1
        assert result["b"] == 2


# ---------------------------------------------------------------------------
# post_process_tool
# ---------------------------------------------------------------------------

class TestPostProcess:
    async def test_passthrough(self) -> None:
        tpm = ToolProcessorManager(middleware=[PassthroughMiddleware()])
        result = await tpm.post_process_tool("tool", "server", {"out": 1})
        assert result == {"out": 1}

    async def test_modifies_result(self) -> None:
        tpm = ToolProcessorManager(
            middleware=[ResultModifyingMiddleware("added", True)]
        )
        result = await tpm.post_process_tool("tool", "server", {"out": 1})
        assert result["added"] is True

    async def test_runs_in_order(self) -> None:
        OrderTracker.calls = []
        tpm = ToolProcessorManager(
            middleware=[OrderTracker("A"), OrderTracker("B")]
        )
        await tpm.post_process_tool("tool", "server", {})
        assert OrderTracker.calls == ["post:A", "post:B"]


# ---------------------------------------------------------------------------
# Timeout protection
# ---------------------------------------------------------------------------

class TestTimeoutProtection:
    async def test_slow_pre_execute_caught(self) -> None:
        tpm = ToolProcessorManager(middleware=[SlowMiddleware()])
        # The default MIDDLEWARE_TIMEOUT_MS is 10s, too slow for tests.
        # We monkeypatch via a fast-timeout middleware instead.
        import qodo.mcp.tool_processor as tp_module

        original = tp_module.MIDDLEWARE_TIMEOUT_MS
        tp_module.MIDDLEWARE_TIMEOUT_MS = 50
        try:
            result = await tpm.pre_process_tool("tool", "server", {"x": 1})
            assert result == {"x": 1}  # original args preserved
            assert len(tpm.get_errors()) == 1
            assert isinstance(tpm.get_errors()[0], ToolMiddlewareError)
        finally:
            tp_module.MIDDLEWARE_TIMEOUT_MS = original

    async def test_slow_post_execute_caught(self) -> None:
        tpm = ToolProcessorManager(middleware=[SlowMiddleware()])
        import qodo.mcp.tool_processor as tp_module

        original = tp_module.MIDDLEWARE_TIMEOUT_MS
        tp_module.MIDDLEWARE_TIMEOUT_MS = 50
        try:
            result = await tpm.post_process_tool("tool", "server", {"out": 1})
            assert result == {"out": 1}
            assert len(tpm.get_errors()) == 1
        finally:
            tp_module.MIDDLEWARE_TIMEOUT_MS = original


# ---------------------------------------------------------------------------
# Error isolation
# ---------------------------------------------------------------------------

class TestErrorIsolation:
    async def test_failing_pre_does_not_block_others(self) -> None:
        tpm = ToolProcessorManager(
            middleware=[
                FailingPreMiddleware(),
                ArgsModifyingMiddleware("survived", True),
            ]
        )
        result = await tpm.pre_process_tool("tool", "server", {"x": 1})
        assert result["survived"] is True
        assert len(tpm.get_errors()) == 1

    async def test_failing_post_does_not_block_others(self) -> None:
        tpm = ToolProcessorManager(
            middleware=[
                FailingPostMiddleware(),
                ResultModifyingMiddleware("survived", True),
            ]
        )
        result = await tpm.post_process_tool("tool", "server", {"out": 1})
        assert result["survived"] is True
        assert len(tpm.get_errors()) == 1

    async def test_errors_accumulate(self) -> None:
        tpm = ToolProcessorManager(
            middleware=[FailingPreMiddleware(), FailingPreMiddleware()]
        )
        await tpm.pre_process_tool("tool", "server", {})
        assert len(tpm.get_errors()) == 2

    async def test_clear_errors(self) -> None:
        tpm = ToolProcessorManager(middleware=[FailingPreMiddleware()])
        await tpm.pre_process_tool("tool", "server", {})
        assert len(tpm.get_errors()) == 1
        tpm.clear_errors()
        assert len(tpm.get_errors()) == 0

    async def test_error_has_correct_phase(self) -> None:
        tpm = ToolProcessorManager(middleware=[FailingPreMiddleware()])
        await tpm.pre_process_tool("tool", "server", {})
        err = tpm.get_errors()[0]
        assert err.phase == "pre_execute"
        assert err.middleware_name == "FailingPreMiddleware"
