"""Tests for the Tool Approval Policy DSL."""
from __future__ import annotations

import pytest

from qodo.sdk.policies import (
    Policy,
    PolicyBuilder,
    PolicyEvalResult,
    PolicyMatcher,
    PolicyOptions,
    PolicyRule,
    glob_match,
    policy_from_rules,
    sdk_policy,
)


# ---------------------------------------------------------------------------
# glob_match
# ---------------------------------------------------------------------------

class TestGlobMatch:
    def test_exact_match(self) -> None:
        assert glob_match("foo", "foo") is True

    def test_case_insensitive(self) -> None:
        assert glob_match("Foo", "foo") is True
        assert glob_match("foo", "FOO") is True

    def test_star_matches_any_chars(self) -> None:
        assert glob_match("*.ts", "file.ts") is True

    def test_star_matches_across_slash(self) -> None:
        assert glob_match("src/*", "src/foo/bar") is True

    def test_double_star_is_alias_for_star(self) -> None:
        assert glob_match("src/**", "src/foo/bar") is True

    def test_double_star_slash_pattern(self) -> None:
        """Trailing slash after ** is skipped for patterns like src/**/file."""
        assert glob_match("src/**/file.ts", "src/deep/nested/file.ts") is True
        assert glob_match("src/**/file.ts", "src/file.ts") is True

    def test_question_mark_matches_single_char(self) -> None:
        assert glob_match("fo?", "foo") is True
        assert glob_match("fo?", "fooo") is False

    def test_special_regex_chars_escaped(self) -> None:
        # dot is literal, not regex wildcard
        assert glob_match("file.ts", "filexts") is False
        assert glob_match("file.ts", "file.ts") is True

    def test_complex_pattern(self) -> None:
        assert glob_match("src/*.test.ts", "src/foo.test.ts") is True
        assert glob_match("src/*.test.ts", "src/deep/foo.test.ts") is True

    def test_empty_pattern_matches_nothing(self) -> None:
        assert glob_match("", "anything") is False
        assert glob_match("", "") is False


# ---------------------------------------------------------------------------
# PolicyBuilder
# ---------------------------------------------------------------------------

class TestPolicyBuilder:
    def test_sdk_policy_returns_builder(self) -> None:
        builder = sdk_policy()
        assert isinstance(builder, PolicyBuilder)

    def test_build_returns_policy(self) -> None:
        policy = sdk_policy().build()
        assert isinstance(policy, Policy)

    def test_approve_adds_rule(self) -> None:
        policy = (
            sdk_policy()
            .approve(PolicyMatcher(tools=["read_file"]))
            .build()
        )
        assert len(policy.rules) == 1
        assert policy.rules[0].decision == "approve"

    def test_deny_adds_rule(self) -> None:
        policy = (
            sdk_policy()
            .deny(PolicyMatcher(tools=["rm"]))
            .build()
        )
        assert len(policy.rules) == 1
        assert policy.rules[0].decision == "deny"

    def test_require_human_adds_rule(self) -> None:
        policy = (
            sdk_policy()
            .require_human(PolicyMatcher(tools=["deploy"]))
            .build()
        )
        assert len(policy.rules) == 1
        assert policy.rules[0].decision == "require_human"

    def test_raw_rule(self) -> None:
        raw = PolicyRule(
            match=PolicyMatcher(tools=["x"]),
            decision="deny",
            name="raw",
        )
        policy = sdk_policy().rule(raw).build()
        assert policy.rules[0] is raw

    def test_default_sets_decision(self) -> None:
        policy = sdk_policy().default("deny").build()
        assert policy.default_decision == "deny"

    def test_default_decision_is_approve(self) -> None:
        policy = sdk_policy().build()
        assert policy.default_decision == "approve"

    def test_rules_maintain_insertion_order(self) -> None:
        policy = (
            sdk_policy()
            .approve(PolicyMatcher(tools=["a"]), name="first")
            .deny(PolicyMatcher(tools=["b"]), name="second")
            .require_human(PolicyMatcher(tools=["c"]), name="third")
            .build()
        )
        assert [r.name for r in policy.rules] == ["first", "second", "third"]

    def test_rules_frozen_after_build(self) -> None:
        policy = sdk_policy().approve(PolicyMatcher(tools=["a"])).build()
        assert isinstance(policy.rules, tuple)

    def test_accept_dict_as_match(self) -> None:
        policy = (
            sdk_policy()
            .approve({"tools": ["read_file"]})
            .build()
        )
        assert isinstance(policy.rules[0].match, PolicyMatcher)
        assert policy.rules[0].match.tools == ["read_file"]


# ---------------------------------------------------------------------------
# policy_from_rules
# ---------------------------------------------------------------------------

class TestPolicyFromRules:
    def test_creates_policy_with_custom_default(self) -> None:
        rules = [
            PolicyRule(
                match=PolicyMatcher(tools=["read_*"]),
                decision="approve",
            )
        ]
        policy = policy_from_rules(rules, default="deny")
        assert isinstance(policy, Policy)
        assert policy.default_decision == "deny"
        assert len(policy.rules) == 1


# ---------------------------------------------------------------------------
# Policy.evaluate_detailed
# ---------------------------------------------------------------------------

class TestEvaluateDetailed:
    def test_matches_tool_name_with_glob(self) -> None:
        policy = (
            sdk_policy()
            .approve(PolicyMatcher(tools=["read_*"]))
            .build()
        )
        result = policy.evaluate_detailed({"tool_name": "read_file", "server_name": "fs"})
        assert result.is_default is False
        assert result.decision == "approve"

    def test_matches_server_name_with_glob(self) -> None:
        policy = (
            sdk_policy()
            .deny(PolicyMatcher(servers=["dangerous_*"]))
            .build()
        )
        result = policy.evaluate_detailed({"tool_name": "any_tool", "server_name": "dangerous_server"})
        assert result.is_default is False
        assert result.decision == "deny"

    def test_matches_both_tool_and_server(self) -> None:
        policy = (
            sdk_policy()
            .approve(PolicyMatcher(tools=["read_*"], servers=["fs"]))
            .build()
        )
        # Both match
        result = policy.evaluate_detailed({"tool_name": "read_file", "server_name": "fs"})
        assert result.is_default is False
        # Tool matches but server doesn't
        result = policy.evaluate_detailed({"tool_name": "read_file", "server_name": "other"})
        assert result.is_default is True

    def test_matches_tool_args_with_glob(self) -> None:
        policy = (
            sdk_policy()
            .approve(
                PolicyMatcher(
                    tools=["write_file"],
                    args={"path": "src/*"},
                )
            )
            .build()
        )
        result = policy.evaluate_detailed(
            {"tool_name": "write_file", "server_name": "fs", "tool_args": {"path": "src/main.py"}}
        )
        assert result.is_default is False
        assert result.decision == "approve"

    def test_args_matching_missing_arg_no_match(self) -> None:
        policy = (
            sdk_policy()
            .approve(
                PolicyMatcher(
                    tools=["write_file"],
                    args={"path": "src/*"},
                )
            )
            .build()
        )
        # tool_args missing the "path" key
        result = policy.evaluate_detailed(
            {"tool_name": "write_file", "server_name": "fs", "tool_args": {"other": "val"}}
        )
        assert result.is_default is True

    def test_first_matching_rule_wins(self) -> None:
        policy = (
            sdk_policy()
            .deny(PolicyMatcher(tools=["rm"]), name="deny-rm")
            .approve(PolicyMatcher(tools=["*"]), name="approve-all")
            .build()
        )
        result = policy.evaluate_detailed({"tool_name": "rm", "server_name": "shell"})
        assert result.decision == "deny"
        assert result.matched_rule is not None
        assert result.matched_rule.name == "deny-rm"

    def test_returns_default_when_no_match(self) -> None:
        policy = sdk_policy().default("deny").build()
        result = policy.evaluate_detailed({"tool_name": "anything", "server_name": "server"})
        assert result.is_default is True
        assert result.decision == "deny"
        assert result.matched_rule is None

    def test_empty_match_does_not_match(self) -> None:
        policy = (
            sdk_policy()
            .approve(PolicyMatcher())  # all fields None
            .build()
        )
        result = policy.evaluate_detailed({"tool_name": "tool", "server_name": "server"})
        assert result.is_default is True

    def test_empty_list_does_not_match(self) -> None:
        policy = (
            sdk_policy()
            .approve(PolicyMatcher(tools=[]))
            .build()
        )
        result = policy.evaluate_detailed({"tool_name": "tool", "server_name": "server"})
        assert result.is_default is True


# ---------------------------------------------------------------------------
# Policy.evaluate
# ---------------------------------------------------------------------------

class TestEvaluate:
    async def test_returns_approved_true_for_approve(self) -> None:
        policy = (
            sdk_policy()
            .approve(PolicyMatcher(tools=["read_*"]))
            .build()
        )
        result = await policy.evaluate({"tool_name": "read_file", "server_name": "fs"})
        assert result["approved"] is True
        assert "reason" not in result

    async def test_returns_approved_false_for_deny(self) -> None:
        policy = (
            sdk_policy()
            .deny(PolicyMatcher(tools=["rm"]))
            .build()
        )
        result = await policy.evaluate({"tool_name": "rm", "server_name": "shell"})
        assert result["approved"] is False

    async def test_returns_approved_false_for_require_human(self) -> None:
        policy = (
            sdk_policy()
            .require_human(PolicyMatcher(tools=["deploy"]))
            .build()
        )
        result = await policy.evaluate({"tool_name": "deploy", "server_name": "ci"})
        assert result["approved"] is False

    async def test_deny_reason_includes_rule_name(self) -> None:
        policy = (
            sdk_policy()
            .deny(PolicyMatcher(tools=["rm"]), name="no-rm")
            .build()
        )
        result = await policy.evaluate({"tool_name": "rm", "server_name": "shell"})
        assert result["reason"] == "Denied by policy rule: no-rm"

    async def test_default_approve_when_no_rules_match(self) -> None:
        policy = sdk_policy().build()
        result = await policy.evaluate({"tool_name": "anything", "server_name": "server"})
        assert result["approved"] is True
        assert "reason" not in result

    async def test_default_deny_when_set(self) -> None:
        policy = sdk_policy().default("deny").build()
        result = await policy.evaluate({"tool_name": "anything", "server_name": "server"})
        assert result["approved"] is False
        assert result["reason"] == "Denied by policy"

    async def test_require_human_reason_includes_rule_name(self) -> None:
        policy = (
            sdk_policy()
            .require_human(PolicyMatcher(tools=["deploy"]), name="needs-approval")
            .build()
        )
        result = await policy.evaluate({"tool_name": "deploy", "server_name": "ci"})
        assert result["reason"] == "Requires human approval: needs-approval"

    async def test_require_human_reason_without_rule_name(self) -> None:
        policy = (
            sdk_policy()
            .require_human(PolicyMatcher(tools=["deploy"]))
            .build()
        )
        result = await policy.evaluate({"tool_name": "deploy", "server_name": "ci"})
        assert result["reason"] == "Requires human approval"


# ---------------------------------------------------------------------------
# Complex scenarios
# ---------------------------------------------------------------------------

class TestComplexScenarios:
    def test_enterprise_governance_pattern(self) -> None:
        """Multiple rules: specific denies, targeted require_human, general approve."""
        policy = (
            sdk_policy()
            .deny(
                PolicyMatcher(tools=["rm", "rmdir"]),
                name="block-destructive",
            )
            .require_human(
                PolicyMatcher(
                    tools=["write_file"],
                    args={"path": "/etc/*"},
                ),
                name="protect-system-dirs",
            )
            .approve(
                PolicyMatcher(tools=["read_*", "list_*"]),
                name="allow-reads",
            )
            .default("require_human")
            .build()
        )

        # Destructive tool blocked
        r = policy.evaluate_detailed({"tool_name": "rm", "server_name": "shell"})
        assert r.decision == "deny"
        assert r.matched_rule is not None and r.matched_rule.name == "block-destructive"

        # Write to /etc requires human
        r = policy.evaluate_detailed(
            {"tool_name": "write_file", "server_name": "fs", "tool_args": {"path": "/etc/passwd"}}
        )
        assert r.decision == "require_human"
        assert r.matched_rule is not None and r.matched_rule.name == "protect-system-dirs"

        # Reads are approved
        r = policy.evaluate_detailed({"tool_name": "read_file", "server_name": "fs"})
        assert r.decision == "approve"

        # Unknown tool gets default (require_human)
        r = policy.evaluate_detailed({"tool_name": "unknown_tool", "server_name": "other"})
        assert r.decision == "require_human"
        assert r.is_default is True

    def test_deny_overrides_approve_via_ordering(self) -> None:
        """A deny rule placed before an approve rule takes precedence."""
        policy = (
            sdk_policy()
            .deny(PolicyMatcher(tools=["write_file"]), name="deny-write")
            .approve(PolicyMatcher(tools=["*"]), name="approve-all")
            .build()
        )

        r = policy.evaluate_detailed({"tool_name": "write_file", "server_name": "fs"})
        assert r.decision == "deny"
        assert r.matched_rule is not None and r.matched_rule.name == "deny-write"

        # Other tools still approved
        r = policy.evaluate_detailed({"tool_name": "read_file", "server_name": "fs"})
        assert r.decision == "approve"
        assert r.matched_rule is not None and r.matched_rule.name == "approve-all"
