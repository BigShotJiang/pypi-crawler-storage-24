"""Tests for artifact management."""

from __future__ import annotations

import json
from datetime import datetime
from typing import Any, Dict
from unittest.mock import AsyncMock

import pytest

from qodo.sdk.artifacts import (
    Artifact,
    ArtifactSerializer,
    ArtifactStore,
    ArtifactStoreOptions,
    JsonSerializer,
    json_serializer,
    with_artifacts,
)
from qodo.sdk.pipeline.types import StepContext


# ---------------------------------------------------------------------------
# jsonSerializer tests
# ---------------------------------------------------------------------------


class TestJsonSerializer:
    def test_serializes_dict_to_json_with_2_space_indent(self) -> None:
        data = {"key": "value", "num": 42}
        result = json_serializer.serialize(data)
        assert result == json.dumps(data, indent=2)

    def test_deserializes_json_back_to_original_data(self) -> None:
        data = {"key": "value", "num": 42}
        serialized = json_serializer.serialize(data)
        assert json_serializer.deserialize(serialized) == data

    def test_content_type_is_application_json(self) -> None:
        assert json_serializer.content_type == "application/json"

    def test_handles_none_lists_nested_dicts(self) -> None:
        data: dict[str, Any] = {
            "none_val": None,
            "list_val": [1, 2, 3],
            "nested": {"a": {"b": "c"}},
        }
        serialized = json_serializer.serialize(data)
        assert json_serializer.deserialize(serialized) == data


# ---------------------------------------------------------------------------
# ArtifactStore basics
# ---------------------------------------------------------------------------


class TestArtifactStoreBasics:
    async def test_stores_and_retrieves_an_artifact(self) -> None:
        store = ArtifactStore()
        await store.set("step1", {"result": 42})
        artifact = store.get("step1")
        assert artifact is not None
        assert artifact.step_name == "step1"
        assert artifact.data == {"result": 42}

    async def test_returns_none_for_nonexistent_step(self) -> None:
        store = ArtifactStore()
        assert store.get("missing") is None

    async def test_overwrites_existing_artifact(self) -> None:
        store = ArtifactStore()
        await store.set("step1", {"v": 1})
        await store.set("step1", {"v": 2})
        artifact = store.get("step1")
        assert artifact is not None
        assert artifact.data == {"v": 2}
        assert store.size == 1

    async def test_created_at_is_valid_iso_timestamp(self) -> None:
        store = ArtifactStore()
        artifact = await store.set("step1", {"x": 1})
        # Should parse without error
        parsed = datetime.fromisoformat(artifact.created_at)
        assert parsed is not None

    async def test_set_returns_the_stored_artifact(self) -> None:
        store = ArtifactStore()
        artifact = await store.set("step1", {"x": 1})
        assert isinstance(artifact, Artifact)
        assert artifact.step_name == "step1"
        assert artifact.data == {"x": 1}
        assert artifact.content_type == "application/json"


# ---------------------------------------------------------------------------
# has
# ---------------------------------------------------------------------------


class TestArtifactStoreHas:
    async def test_returns_true_when_artifact_exists(self) -> None:
        store = ArtifactStore()
        await store.set("step1", {"x": 1})
        assert store.has("step1") is True

    async def test_returns_false_when_not_exists(self) -> None:
        store = ArtifactStore()
        assert store.has("missing") is False


# ---------------------------------------------------------------------------
# all
# ---------------------------------------------------------------------------


class TestArtifactStoreAll:
    async def test_returns_all_artifacts_in_insertion_order(self) -> None:
        store = ArtifactStore()
        await store.set("a", {"v": 1})
        await store.set("b", {"v": 2})
        await store.set("c", {"v": 3})
        artifacts = store.all()
        assert [a.step_name for a in artifacts] == ["a", "b", "c"]

    async def test_returns_empty_list_when_no_artifacts(self) -> None:
        store = ArtifactStore()
        assert store.all() == []


# ---------------------------------------------------------------------------
# step_names
# ---------------------------------------------------------------------------


class TestArtifactStoreStepNames:
    async def test_returns_step_names_in_insertion_order(self) -> None:
        store = ArtifactStore()
        await store.set("alpha", {})
        await store.set("beta", {})
        await store.set("gamma", {})
        assert store.step_names() == ["alpha", "beta", "gamma"]


# ---------------------------------------------------------------------------
# delete
# ---------------------------------------------------------------------------


class TestArtifactStoreDelete:
    async def test_removes_artifact_returns_true(self) -> None:
        store = ArtifactStore()
        await store.set("step1", {"x": 1})
        assert store.delete("step1") is True
        assert store.get("step1") is None

    async def test_returns_false_for_nonexistent_step(self) -> None:
        store = ArtifactStore()
        assert store.delete("missing") is False


# ---------------------------------------------------------------------------
# clear
# ---------------------------------------------------------------------------


class TestArtifactStoreClear:
    async def test_removes_all_artifacts(self) -> None:
        store = ArtifactStore()
        await store.set("a", {})
        await store.set("b", {})
        store.clear()
        assert store.size == 0
        assert store.all() == []


# ---------------------------------------------------------------------------
# size
# ---------------------------------------------------------------------------


class TestArtifactStoreSize:
    async def test_returns_number_of_stored_artifacts(self) -> None:
        store = ArtifactStore()
        assert store.size == 0
        await store.set("a", {})
        assert store.size == 1
        await store.set("b", {})
        assert store.size == 2


# ---------------------------------------------------------------------------
# deserialize
# ---------------------------------------------------------------------------


class TestArtifactStoreDeserialize:
    def test_uses_configured_serializer(self) -> None:
        store = ArtifactStore()
        data = {"key": "value"}
        raw = json.dumps(data, indent=2)
        assert store.deserialize(raw) == data


# ---------------------------------------------------------------------------
# Persistence hook
# ---------------------------------------------------------------------------


class TestPersistenceHook:
    async def test_calls_sync_on_persist_after_set(self) -> None:
        calls: list[Artifact[Any]] = []

        def on_persist(artifact: Artifact[Any]) -> None:
            calls.append(artifact)

        store = ArtifactStore(ArtifactStoreOptions(on_persist=on_persist))
        await store.set("step1", {"x": 1})
        assert len(calls) == 1
        assert calls[0].step_name == "step1"
        assert calls[0].data == {"x": 1}

    async def test_calls_async_on_persist_and_awaits_it(self) -> None:
        calls: list[str] = []

        async def on_persist(artifact: Artifact[Any]) -> None:
            calls.append(artifact.step_name)

        store = ArtifactStore(ArtifactStoreOptions(on_persist=on_persist))
        await store.set("step1", {"x": 1})
        assert calls == ["step1"]

    async def test_sync_persist_errors_are_caught(self) -> None:
        def on_persist(artifact: Artifact[Any]) -> None:
            raise RuntimeError("sync error")

        store = ArtifactStore(ArtifactStoreOptions(on_persist=on_persist))
        artifact = await store.set("step1", {"x": 1})
        assert artifact.step_name == "step1"

    async def test_async_persist_errors_are_caught(self) -> None:
        async def on_persist(artifact: Artifact[Any]) -> None:
            raise RuntimeError("async error")

        store = ArtifactStore(ArtifactStoreOptions(on_persist=on_persist))
        artifact = await store.set("step1", {"x": 1})
        assert artifact.step_name == "step1"


# ---------------------------------------------------------------------------
# get_errors
# ---------------------------------------------------------------------------


class TestGetErrors:
    async def test_returns_empty_list_when_no_errors(self) -> None:
        store = ArtifactStore()
        assert store.get_errors() == []

    async def test_records_sync_persist_error(self) -> None:
        def on_persist(artifact: Artifact[Any]) -> None:
            raise RuntimeError("sync error")

        store = ArtifactStore(ArtifactStoreOptions(on_persist=on_persist))
        await store.set("step1", {"x": 1})

        errors = store.get_errors()
        assert len(errors) == 1
        assert errors[0]["step_name"] == "step1"
        assert isinstance(errors[0]["error"], RuntimeError)
        assert str(errors[0]["error"]) == "sync error"

    async def test_records_async_persist_error(self) -> None:
        async def on_persist(artifact: Artifact[Any]) -> None:
            raise ValueError("async error")

        store = ArtifactStore(ArtifactStoreOptions(on_persist=on_persist))
        await store.set("step1", {"x": 1})

        errors = store.get_errors()
        assert len(errors) == 1
        assert errors[0]["step_name"] == "step1"
        assert isinstance(errors[0]["error"], ValueError)

    async def test_accumulates_multiple_errors(self) -> None:
        call_count = {"n": 0}

        def on_persist(artifact: Artifact[Any]) -> None:
            call_count["n"] += 1
            raise RuntimeError(f"error-{call_count['n']}")

        store = ArtifactStore(ArtifactStoreOptions(on_persist=on_persist))
        await store.set("a", {})
        await store.set("b", {})

        errors = store.get_errors()
        assert len(errors) == 2
        assert errors[0]["step_name"] == "a"
        assert errors[1]["step_name"] == "b"

    async def test_no_errors_when_persist_succeeds(self) -> None:
        def on_persist(artifact: Artifact[Any]) -> None:
            pass  # no error

        store = ArtifactStore(ArtifactStoreOptions(on_persist=on_persist))
        await store.set("step1", {"x": 1})
        assert store.get_errors() == []


# ---------------------------------------------------------------------------
# Custom serializer
# ---------------------------------------------------------------------------


class TestCustomSerializer:
    async def test_uses_custom_serializer_for_set_and_deserialize(self) -> None:
        class CsvSerializer:
            def serialize(self, data: Any) -> str:
                if isinstance(data, dict):
                    keys = ",".join(str(k) for k in data.keys())
                    vals = ",".join(str(v) for v in data.values())
                    return f"{keys}\n{vals}"
                return str(data)

            def deserialize(self, raw: str) -> Any:
                lines = raw.strip().split("\n")
                keys = lines[0].split(",")
                vals = lines[1].split(",")
                return dict(zip(keys, vals))

            @property
            def content_type(self) -> str:
                return "text/csv"

        serializer = CsvSerializer()
        store = ArtifactStore(ArtifactStoreOptions(serializer=serializer))

        artifact = await store.set("step1", {"name": "Alice", "age": "30"})
        assert artifact.content_type == "text/csv"
        assert artifact.serialized == "name,age\nAlice,30"

        deserialized = store.deserialize(artifact.serialized)
        assert deserialized == {"name": "Alice", "age": "30"}


# ---------------------------------------------------------------------------
# with_artifacts
# ---------------------------------------------------------------------------


class TestWithArtifacts:
    async def test_wraps_step_function_and_stores_output(self) -> None:
        store = ArtifactStore()

        async def my_step(ctx: StepContext) -> Dict[str, Any]:
            return {"output": "hello"}

        wrapped = with_artifacts(store, my_step)
        ctx = StepContext(state={}, run=AsyncMock(), step_name="my_step")
        result = await wrapped(ctx)

        assert result == {"output": "hello"}
        assert store.has("my_step")
        assert store.get("my_step") is not None
        assert store.get("my_step").data == {"output": "hello"}  # type: ignore[union-attr]

    async def test_passes_through_step_context_correctly(self) -> None:
        store = ArtifactStore()
        received_ctx: list[StepContext] = []

        async def my_step(ctx: StepContext) -> Dict[str, Any]:
            received_ctx.append(ctx)
            return {"val": ctx.state.get("input", "none")}

        wrapped = with_artifacts(store, my_step)
        ctx = StepContext(state={"input": "test_val"}, run=AsyncMock(), step_name="s1")
        await wrapped(ctx)

        assert len(received_ctx) == 1
        assert received_ctx[0].state == {"input": "test_val"}
        assert received_ctx[0].step_name == "s1"

    async def test_propagates_errors_from_wrapped_function(self) -> None:
        store = ArtifactStore()

        async def failing_step(ctx: StepContext) -> Dict[str, Any]:
            raise ValueError("step failed")

        wrapped = with_artifacts(store, failing_step)
        ctx = StepContext(state={}, run=AsyncMock(), step_name="fail_step")

        with pytest.raises(ValueError, match="step failed"):
            await wrapped(ctx)

        # Artifact should not be stored on failure
        assert not store.has("fail_step")
