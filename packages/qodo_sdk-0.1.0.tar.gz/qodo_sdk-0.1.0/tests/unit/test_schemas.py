"""Tests for schema utilities."""

import json
from typing import Any, Optional, Union

import pytest
from pydantic import BaseModel, Field

# Import directly from the schemas module to avoid full SDK import chain
from qodo.sdk.schemas import (
    CoercibleTypes,
    JsonAny,
    JsonValue,
    json_any_schema,
    json_value_schema,
    pydantic_output_schema,
    zcoerce,
)
from qodo.errors import QodoSchemaError


class TestJsonValueSchema:
    """Tests for json_value_schema()."""

    def test_returns_dict_with_anyof(self):
        """Test that json_value_schema returns proper structure."""
        schema = json_value_schema("Test description")

        assert isinstance(schema, dict)
        assert schema["description"] == "Test description"
        assert "anyOf" in schema
        assert len(schema["anyOf"]) == 4

    def test_includes_all_primitive_types(self):
        """Test that schema includes all primitive JSON types."""
        schema = json_value_schema("Test")

        types = [item["type"] for item in schema["anyOf"]]
        assert "string" in types
        assert "number" in types
        assert "boolean" in types
        assert "null" in types

    def test_no_array_or_object_types(self):
        """Test that json_value_schema excludes complex types."""
        schema = json_value_schema("Test")

        types = [item["type"] for item in schema["anyOf"]]
        assert "array" not in types
        assert "object" not in types


class TestJsonAnySchema:
    """Tests for json_any_schema()."""

    def test_returns_dict_with_anyof(self):
        """Test that json_any_schema returns proper structure."""
        schema = json_any_schema("Test description")

        assert isinstance(schema, dict)
        assert schema["description"] == "Test description"
        assert "anyOf" in schema

    def test_includes_all_types(self):
        """Test that schema includes all JSON types."""
        schema = json_any_schema("Test")

        types = [item.get("type") for item in schema["anyOf"]]
        assert "string" in types
        assert "number" in types
        assert "boolean" in types
        assert "null" in types
        assert "array" in types
        assert "object" in types

    def test_array_has_items_schema(self):
        """Test that array type has items defined."""
        schema = json_any_schema("Test")

        array_schema = next(
            item for item in schema["anyOf"] if item.get("type") == "array"
        )
        assert "items" in array_schema
        assert "anyOf" in array_schema["items"]

    def test_object_has_additional_properties(self):
        """Test that object type has additionalProperties defined."""
        schema = json_any_schema("Test")

        object_schema = next(
            item for item in schema["anyOf"] if item.get("type") == "object"
        )
        assert "additionalProperties" in object_schema
        assert "anyOf" in object_schema["additionalProperties"]


class TestAnyTypeDetection:
    """Tests for Any type detection in pydantic_output_schema."""

    def test_detects_any_type(self):
        """Test that typing.Any is detected."""

        class BadModel(BaseModel):
            data: Any = Field(description="Some data")

        with pytest.raises(QodoSchemaError) as exc_info:
            pydantic_output_schema("test", BadModel)

        assert "typing.Any" in str(exc_info.value)
        assert "data" in str(exc_info.value)

    def test_detects_any_in_list(self):
        """Test that Any in list items is detected."""

        class BadModel(BaseModel):
            items: list[Any] = Field(description="Items")

        with pytest.raises(QodoSchemaError) as exc_info:
            pydantic_output_schema("test", BadModel)

        assert "typing.Any" in str(exc_info.value)

    def test_detects_any_in_dict_value(self):
        """Test that Any in dict values is detected."""

        class BadModel(BaseModel):
            data: dict[str, Any] = Field(description="Data")

        with pytest.raises(QodoSchemaError) as exc_info:
            pydantic_output_schema("test", BadModel)

        assert "typing.Any" in str(exc_info.value)

    def test_detects_any_in_union(self):
        """Test that Any in Union is detected."""

        class BadModel(BaseModel):
            value: Union[str, Any] = Field(description="Value")

        with pytest.raises(QodoSchemaError) as exc_info:
            pydantic_output_schema("test", BadModel)

        assert "typing.Any" in str(exc_info.value)

    def test_detects_any_in_optional(self):
        """Test that Any in Optional is detected."""

        class BadModel(BaseModel):
            value: Optional[Any] = Field(description="Value")

        with pytest.raises(QodoSchemaError) as exc_info:
            pydantic_output_schema("test", BadModel)

        assert "typing.Any" in str(exc_info.value)

    def test_detects_unparameterized_list(self):
        """Test that unparameterized list is detected."""

        class BadModel(BaseModel):
            items: list = Field(description="Items")

        with pytest.raises(QodoSchemaError) as exc_info:
            pydantic_output_schema("test", BadModel)

        assert "unparameterized list" in str(exc_info.value)

    def test_detects_unparameterized_dict(self):
        """Test that unparameterized dict is detected."""

        class BadModel(BaseModel):
            data: dict = Field(description="Data")

        with pytest.raises(QodoSchemaError) as exc_info:
            pydantic_output_schema("test", BadModel)

        assert "unparameterized dict" in str(exc_info.value)

    def test_allows_proper_types(self):
        """Test that proper types work correctly."""

        class GoodModel(BaseModel):
            name: str = Field(description="Name")
            count: int = Field(description="Count")
            items: list[str] = Field(description="Items")
            data: dict[str, int] = Field(description="Data")

        # Should not raise
        schema = pydantic_output_schema("test", GoodModel)
        assert schema is not None


class TestJsonCoercers:
    """Tests for JSON coercion methods."""

    def test_json_array_from_list(self):
        """Test json_array with native list."""
        result = zcoerce.json_array([1, 2, 3])
        assert result == [1, 2, 3]

    def test_json_array_from_string(self):
        """Test json_array with JSON string."""
        result = zcoerce.json_array('[1, 2, 3]')
        assert result == [1, 2, 3]

    def test_json_array_from_string_nested(self):
        """Test json_array with nested JSON string."""
        result = zcoerce.json_array('["a", {"b": 1}]')
        assert result == ["a", {"b": 1}]

    def test_json_array_invalid_json(self):
        """Test json_array with invalid JSON raises error."""
        with pytest.raises(ValueError) as exc_info:
            zcoerce.json_array("not valid json")

        assert "Cannot coerce" in str(exc_info.value)

    def test_json_array_from_object_string(self):
        """Test json_array with object JSON string raises error."""
        with pytest.raises(ValueError):
            zcoerce.json_array('{"key": "value"}')

    def test_json_array_from_number(self):
        """Test json_array with number raises error."""
        with pytest.raises(ValueError) as exc_info:
            zcoerce.json_array(42)

        assert "Cannot coerce" in str(exc_info.value)

    def test_json_object_from_dict(self):
        """Test json_object with native dict."""
        result = zcoerce.json_object({"key": "value"})
        assert result == {"key": "value"}

    def test_json_object_from_string(self):
        """Test json_object with JSON string."""
        result = zcoerce.json_object('{"key": "value"}')
        assert result == {"key": "value"}

    def test_json_object_from_string_nested(self):
        """Test json_object with nested JSON string."""
        result = zcoerce.json_object('{"a": [1, 2], "b": {"c": 3}}')
        assert result == {"a": [1, 2], "b": {"c": 3}}

    def test_json_object_invalid_json(self):
        """Test json_object with invalid JSON raises error."""
        with pytest.raises(ValueError) as exc_info:
            zcoerce.json_object("not valid json")

        assert "Cannot coerce" in str(exc_info.value)

    def test_json_object_from_array_string(self):
        """Test json_object with array JSON string raises error."""
        with pytest.raises(ValueError):
            zcoerce.json_object('[1, 2, 3]')

    def test_json_object_from_number(self):
        """Test json_object with number raises error."""
        with pytest.raises(ValueError) as exc_info:
            zcoerce.json_object(42)

        assert "Cannot coerce" in str(exc_info.value)


class TestExistingCoercers:
    """Tests for existing coercion methods to ensure they still work."""

    def test_boolean_true_values(self):
        """Test boolean coercion for true values."""
        assert zcoerce.boolean(True) is True
        assert zcoerce.boolean("true") is True
        assert zcoerce.boolean("TRUE") is True
        assert zcoerce.boolean("True") is True
        assert zcoerce.boolean("1") is True
        assert zcoerce.boolean("yes") is True
        assert zcoerce.boolean("YES") is True
        assert zcoerce.boolean(1) is True

    def test_boolean_false_values(self):
        """Test boolean coercion for false values."""
        assert zcoerce.boolean(False) is False
        assert zcoerce.boolean("false") is False
        assert zcoerce.boolean("FALSE") is False
        assert zcoerce.boolean("False") is False
        assert zcoerce.boolean("0") is False
        assert zcoerce.boolean("no") is False
        assert zcoerce.boolean("NO") is False
        assert zcoerce.boolean(0) is False

    def test_boolean_invalid(self):
        """Test boolean coercion with invalid value."""
        with pytest.raises(ValueError):
            zcoerce.boolean("maybe")

    def test_number_values(self):
        """Test number coercion."""
        assert zcoerce.number(42) == 42.0
        assert zcoerce.number(3.14) == 3.14
        assert zcoerce.number("42") == 42.0
        assert zcoerce.number("3.14") == 3.14
        assert zcoerce.number("-10") == -10.0

    def test_number_invalid(self):
        """Test number coercion with invalid value."""
        with pytest.raises(ValueError):
            zcoerce.number("not a number")

    def test_integer_values(self):
        """Test integer coercion."""
        assert zcoerce.integer(42) == 42
        assert zcoerce.integer(3.9) == 3  # Truncated
        assert zcoerce.integer("42") == 42
        assert zcoerce.integer("3.9") == 3  # Truncated

    def test_integer_invalid(self):
        """Test integer coercion with invalid value."""
        with pytest.raises(ValueError):
            zcoerce.integer("not an integer")


class TestPydanticOutputSchema:
    """Tests for pydantic_output_schema."""

    def test_basic_schema(self):
        """Test basic schema generation."""

        class Output(BaseModel):
            result: str = Field(description="The result")

        schema = pydantic_output_schema("test_output", Output)

        assert schema["type"] == "json_schema"
        assert schema["json_schema"]["name"] == "test_output"
        assert schema["json_schema"]["strict"] is True
        assert "properties" in schema["json_schema"]["schema"]

    def test_missing_description_raises(self):
        """Test that missing description raises error."""

        class Output(BaseModel):
            result: str  # Missing description

        with pytest.raises(QodoSchemaError) as exc_info:
            pydantic_output_schema("test", Output)

        assert "missing description" in str(exc_info.value).lower()

    def test_non_strict_mode(self):
        """Test non-strict mode."""

        class Output(BaseModel):
            result: str = Field(description="Result")

        schema = pydantic_output_schema("test", Output, strict=False)

        assert schema["json_schema"]["strict"] is False

    def test_complex_schema(self):
        """Test complex nested schema."""

        class Inner(BaseModel):
            value: int = Field(description="Inner value")

        class Output(BaseModel):
            name: str = Field(description="Name")
            items: list[str] = Field(description="Items list")
            data: dict[str, int] = Field(description="Data mapping")
            inner: Inner = Field(description="Inner object")

        schema = pydantic_output_schema("complex", Output)

        assert schema["json_schema"]["name"] == "complex"
        props = schema["json_schema"]["schema"]["properties"]
        assert "name" in props
        assert "items" in props
        assert "data" in props
        assert "inner" in props


class TestSchemaImports:
    """Tests for schema module imports."""

    def test_all_imports_available(self):
        """Test that all schema utilities are importable."""
        from qodo.sdk.schemas import (
            CoercibleTypes,
            JsonAny,
            JsonValue,
            json_any_schema,
            json_value_schema,
            pydantic_output_schema,
            zcoerce,
        )

        assert json_value_schema is not None
        assert json_any_schema is not None
        assert pydantic_output_schema is not None
        assert CoercibleTypes is not None
        assert zcoerce is not None
        assert JsonValue is not None
        assert JsonAny is not None

    def test_zcoerce_is_coercible_types(self):
        """Test that zcoerce is alias for CoercibleTypes."""
        from qodo.sdk.schemas import CoercibleTypes, zcoerce

        assert zcoerce is CoercibleTypes
