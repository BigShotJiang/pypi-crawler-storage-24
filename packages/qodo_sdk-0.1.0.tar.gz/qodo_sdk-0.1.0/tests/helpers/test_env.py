"""
Shared test utilities for qodo SDK tests.

Provides helpers for creating isolated environments and common mocks
used across multiple test files.
"""
from __future__ import annotations

from typing import Any, Callable, Dict, Optional, TypeVar
from unittest.mock import MagicMock

from qodo.session.environment import (
    EnvironmentServices,
    run_with_environment,
    run_with_environment_async,
)

T = TypeVar("T")


def fresh_env(**overrides: Any) -> EnvironmentServices:
    """
    Create a fresh SDK-mode environment for test isolation.
    Each call returns a new object so tests don't share state.
    """
    return EnvironmentServices(sdk_mode=True, **overrides)


async def with_test_env(
    fn: Callable[[], Any],
    **overrides: Any,
) -> Any:
    """
    Run a test callback inside an isolated environment.
    Convenience wrapper around run_with_environment_async + fresh_env.
    """
    return await run_with_environment_async(fresh_env(**overrides), fn)


def create_mock_server_data(overrides: Optional[Dict[str, Any]] = None) -> MagicMock:
    """
    Create a mock ServerData instance that satisfies the interface
    used by SessionContext, ServerRegistry, etc.
    """
    overrides = overrides or {}
    mock = MagicMock()
    mock.get_instance.return_value = mock
    mock.get_session_id.return_value = "mock-session-id"
    mock.get_default_model.return_value = "mock-model"
    mock.check_model_input.return_value = None
    mock.fetch_new_session_id.return_value = "sdk-session-12345"
    mock.get_base_url.return_value = "https://mock.api.qodo.ai"
    mock.get_base_url_source.return_value = "default"
    mock.get_mcp_tools.return_value = {}

    for key, value in overrides.items():
        setattr(mock, key, value)

    return mock
