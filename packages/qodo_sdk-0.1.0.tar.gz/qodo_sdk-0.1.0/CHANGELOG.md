# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.1.0] - 2026-03-08

### Added

- Initial release of the Qodo Python SDK
- `QodoSDK` — async-first SDK with `async with` context manager support
- Streaming (`stream_prompt`) and blocking (`prompt`, `run`) execution modes
- `sdk_agent`, `sdk_command`, `sdk_args` — Pydantic-first builders for agent configuration
- `sdk_pipeline` — fluent builder for multi-step agent workflows with sequential and parallel steps
- `sdk_policy` — declarative tool approval policy DSL with glob matching
- `ArtifactStore` — typed storage for pipeline intermediate results
- `ToolMiddleware` — pre/post execution hooks for tool calls
- `SdkTracer` — Protocol-based OpenTelemetry tracing adapter (no hard dependency)
- Structured output validation with Pydantic v2 models
- Execution timeouts and retry support
- Environment isolation via `contextvars` for multi-instance usage
- MCP tool system with builtin servers (filesystem, git, ripgrep, shell)
- WebSocket-based communication with ready protocol and checkpoint recovery
- Full type annotations with `py.typed` marker (PEP 561)

[Unreleased]: https://github.com/qodo-ai/qodo-py-sdk/compare/v0.1.0...HEAD
[0.1.0]: https://github.com/qodo-ai/qodo-py-sdk/releases/tag/v0.1.0
