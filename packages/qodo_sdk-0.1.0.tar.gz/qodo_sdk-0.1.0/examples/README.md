# Qodo Python SDK Examples

These scripts demonstrate how to use the **Qodo Python SDK**.

## Prerequisites

- Python >= 3.10
- `QODO_API_KEY` set (or `~/.qodo/auth.key`)

Run from repo root:

```bash
uv run python examples/<example>.py
```

> **Notes**
> - These are demos (not tests). They will contact the Qodo backend.
> - You can optionally set `QODO_BASE_URL` or pass `backend_base_url` in code.

## Core

### 1) Streaming (prints deltas)

Uses `SdkEventType` constants + `match_sdk_event` helper.

```bash
uv run python examples/stream_prompt.py
```

### 2) Blocking run (prints final output)

```bash
uv run python examples/run_prompt.py
```

### 3) Agent config defined in code (Pydantic-first)

Uses `sdk_agent()` / `sdk_command()` builders with Pydantic models for args validation and output schema generation.

```bash
uv run python examples/agent_object.py
```

### 4) Command-less agent_object (top-level-only config)

Demonstrates using `agent_object` without defining any `commands`. Useful for prompt-first SDK embedding.

```bash
uv run python examples/agent_object_no_commands.py
```

### 5) Session ID with streaming

Creates a session ID upfront and binds it to streaming prompts for conversation tracking.

```bash
uv run python examples/session_binding.py
```

### 6) Structured output with Pydantic validation

Defines a typed output schema and gets validated JSON back from the agent.

```bash
uv run python examples/structured_output.py
```

## Workflows

### 7) Pipeline DSL

Multi-step agent workflow with typed state threading between steps.

```bash
uv run python examples/pipeline.py
```

### 8) Artifacts

Stores intermediate results from pipeline steps with persistence hooks.

```bash
uv run python examples/artifacts.py
```

## Enterprise

### 9) Tool approval (callback)

Custom imperative tool approval policy using a callback function.

```bash
uv run python examples/approval_policy.py
```

### 10) Tool approval (Policy DSL)

Declarative tool approval policies with the fluent `sdk_policy()` builder. Includes policy evaluation inspection.

```bash
uv run python examples/policy_dsl.py
```

### 11) Tool middleware

Pre/post execution hooks for auditing, logging, and blocking tool calls.

```bash
uv run python examples/tool_middleware.py
```

### 12) OpenTelemetry tracing

Instruments agent runs with OTel spans. Requires `opentelemetry-api` (graceful fallback if not installed).

```bash
pip install opentelemetry-api  # optional peer dep
uv run python examples/opentelemetry.py
```

## Execution Control

### 13) Dry run mode

Preview agent behavior without executing any tools.

```bash
uv run python examples/dry_run.py
```

### 14) Execution timeout

Time limits and retry policies for agent runs.

```bash
uv run python examples/execution_timeout.py
```
