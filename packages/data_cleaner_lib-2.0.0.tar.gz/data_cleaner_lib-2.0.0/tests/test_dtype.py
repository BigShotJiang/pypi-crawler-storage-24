import pandas as pd
from data_cleaner_lib.cleaning.dtype import convert_numeric


def test_numeric_conversion():

    s = pd.Series(["10", "20", "30"])

    result = convert_numeric(s)

    assert str(result.dtype) in ["Int64", "float64"]