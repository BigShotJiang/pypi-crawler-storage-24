import pandas as pd
from data_cleaner_lib.cleaning.outliers import handle_outliers


def test_outlier_detection():

    df = pd.DataFrame({
        "salary": [50000, 51000, 52000, 1000000]
    })

    column_types = {"salary": "numeric"}

    logs = []

    cleaned = handle_outliers(df, column_types, logs)

    assert cleaned["salary"].max() < 1000000