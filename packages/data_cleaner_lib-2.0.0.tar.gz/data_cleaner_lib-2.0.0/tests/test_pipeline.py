import pandas as pd
from data_cleaner_lib import CleanPipeline


def test_prepare_for_eda():

    df = pd.DataFrame({
        "name": ["John", "Jane", None],
        "email": ["john@email.com", "jane@email.com", None],
        "age": [25, 30, None],
        "salary": [50000, 60000, None]
    })

    pipeline = CleanPipeline(df)

    cleaned = pipeline.prepare_for_eda()

    assert cleaned.shape[0] == 3
    assert cleaned["age"].isna().sum() == 0
    assert cleaned["salary"].isna().sum() == 0