import pandas as pd
from data_cleaner_lib.cleaning.missing import fill_numeric


def test_missing_fill_numeric():

    s = pd.Series([10, None, 30])

    result = fill_numeric(s)

    assert result.isna().sum() == 0