import pandas as pd
from data_cleaner_lib.cleaning.text import clean_text


def test_text_cleaning():

    df = pd.DataFrame({
        "name": [" John!! ", "JANE"]
    })

    column_types = {"name": "text"}

    logs = []

    cleaned = clean_text(df, column_types, logs)

    assert cleaned["name"][0] == "john"