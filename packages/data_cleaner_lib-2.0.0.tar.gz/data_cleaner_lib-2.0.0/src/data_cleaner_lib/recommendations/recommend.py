import pandas as pd


def generate_recommendations(df: pd.DataFrame, column_types: dict):
    """
    Generate automatic cleaning recommendations based on dataset inspection.
    """

    recommendations = []

    for col in df.columns:

        series = df[col]

        missing_ratio = series.isna().mean()

        if missing_ratio > 0.1:
            recommendations.append(
                f"{col}: high missing values ({round(missing_ratio*100,2)}%) → consider missing value treatment"
            )

        if column_types.get(col) == "numeric":

            Q1 = series.quantile(0.25)
            Q3 = series.quantile(0.75)
            IQR = Q3 - Q1

            lower = Q1 - 1.5 * IQR
            upper = Q3 + 1.5 * IQR

            outliers = ((series < lower) | (series > upper)).sum()

            if outliers > 0:
                recommendations.append(
                    f"{col}: {outliers} potential outliers detected → consider outlier treatment"
                )

        if column_types.get(col) == "text":

            unique_ratio = series.nunique() / len(series)

            if unique_ratio > 0.9:
                recommendations.append(
                    f"{col}: high cardinality text column → consider encoding or grouping"
                )

    duplicates = df.duplicated().sum()

    if duplicates > 0:
        recommendations.append(
            f"Dataset contains {duplicates} duplicate rows → consider duplicate removal"
        )

    return recommendations