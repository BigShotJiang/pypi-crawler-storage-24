import pandas as pd


TRUE_VALUES = {"true", "1", "yes", "y", "t"}
FALSE_VALUES = {"false", "0", "no", "n", "f"}


def convert_numeric(series: pd.Series) -> pd.Series:
    """
    Convert column to smart numeric:
    - int if no decimals
    - float if decimals exist
    """

    numeric = pd.to_numeric(series, errors="coerce")

    non_na = numeric.dropna()

    if len(non_na) > 0 and (non_na % 1 == 0).all():
        return numeric.astype("Int64")

    return numeric.astype(float)


def convert_datetime(series: pd.Series) -> pd.Series:
    """Convert column to datetime"""
    return pd.to_datetime(series, errors="coerce")


def convert_boolean(series: pd.Series) -> pd.Series:
    """Convert common boolean strings to True/False"""

    def map_bool(x):

        if pd.isna(x):
            return None

        val = str(x).strip().lower()

        if val in TRUE_VALUES:
            return True

        if val in FALSE_VALUES:
            return False

        return None

    return series.apply(map_bool).astype("boolean")


def convert_categorical(series: pd.Series) -> pd.Series:
    """Convert column to categorical dtype"""
    return series.astype("category")


def fix_dtypes(df: pd.DataFrame, column_types: dict, logs: list):
    """
    Fix dataframe dtypes based on detected column types.
    Modifies dataframe internally.
    """

    for col, col_type in column_types.items():

        try:

            if col_type == "numeric":
                df[col] = convert_numeric(df[col])
                logs.append(f"Converted column '{col}' to numeric")

            elif col_type == "datetime":
                df[col] = convert_datetime(df[col])
                logs.append(f"Converted column '{col}' to datetime")

            elif col_type == "boolean":
                df[col] = convert_boolean(df[col])
                logs.append(f"Converted column '{col}' to boolean")

            elif col_type == "categorical":
                df[col] = convert_categorical(df[col])
                logs.append(f"Converted column '{col}' to category")

        except Exception:
            logs.append(f"Warning: failed dtype conversion for '{col}'")

    return df