import pandas as pd


def fill_numeric(series: pd.Series):
    median_value = series.median()

    if pd.api.types.is_integer_dtype(series):
        median_value = int(median_value)

    return series.fillna(median_value)


def fill_categorical(series: pd.Series):
    if series.mode(dropna=True).empty:
        return series
    return series.fillna(series.mode(dropna=True)[0])


def fill_text(series: pd.Series):
    if series.mode(dropna=True).empty:
        return series
    return series.fillna(series.mode(dropna=True)[0])


def fill_datetime(series: pd.Series):
    return series.ffill().bfill()


def handle_missing(df: pd.DataFrame, column_types: dict, logs: list):

    for col, col_type in column_types.items():

        missing_count = df[col].isna().sum()

        if missing_count == 0:
            continue

        try:

            if col_type == "numeric":
                df[col] = fill_numeric(df[col])
                logs.append(f"Filled {missing_count} missing values in '{col}' using median")

            elif col_type == "categorical":
                df[col] = fill_categorical(df[col])
                logs.append(f"Filled {missing_count} missing values in '{col}' using mode")

            elif col_type == "text":
                df[col] = fill_text(df[col])
                logs.append(f"Filled {missing_count} missing values in '{col}' using mode")

            elif col_type == "datetime":
                df[col] = fill_datetime(df[col])
                logs.append(f"Filled {missing_count} missing values in '{col}' using forward/back fill")

        except Exception:
            logs.append(f"Warning: failed missing value handling for '{col}'")

    return df