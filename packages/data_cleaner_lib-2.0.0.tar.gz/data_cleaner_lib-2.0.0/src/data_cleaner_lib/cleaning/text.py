import pandas as pd
import re


EMAIL_PATTERN = r"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$"


def clean_text(df: pd.DataFrame, column_types: dict, logs: list):
    """
    Standardize text columns while safely preserving real email formats.
    """

    for col, col_type in column_types.items():

        if col_type not in ["text", "email"]:
            continue

        try:

            series = df[col].astype(str)

            # basic normalization
            series = series.str.strip()
            series = series.str.lower()
            series = series.str.replace(r"\s+", " ", regex=True)

            # check if column is mostly valid emails
            email_ratio = series.str.match(EMAIL_PATTERN, na=False).mean()

            if email_ratio >= 0.8:
                # treat column as email
                series = series.str.replace(r"\s+", "", regex=True)

            else:
                # normal text cleaning
                series = series.str.replace(r"[^a-z0-9\s]", "", regex=True)

            df[col] = series

            logs.append(f"Standardized text in '{col}'")

        except Exception:
            logs.append(f"Warning: failed text cleaning for '{col}'")

    return df