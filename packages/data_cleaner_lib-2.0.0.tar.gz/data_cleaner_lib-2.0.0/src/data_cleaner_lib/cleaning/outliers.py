import pandas as pd
import numpy as np


def handle_outliers(df: pd.DataFrame, column_types: dict, logs: list, method="iqr"):
    """
    Detect and cap outliers in numeric columns.
    """

    for col, col_type in column_types.items():

        if col_type != "numeric":
            continue

        series = df[col].dropna()

        if series.empty:
            continue

        try:

            if method == "iqr":

                Q1 = series.quantile(0.25)
                Q3 = series.quantile(0.75)
                IQR = Q3 - Q1

                lower = Q1 - 1.5 * IQR
                upper = Q3 + 1.5 * IQR

                before = df[col].copy()

                df[col] = np.clip(df[col], lower, upper)

                capped = (before != df[col]).sum()

                if capped > 0:
                    logs.append(f"Capped {capped} outliers in '{col}' using IQR")

            elif method == "zscore":

                mean = series.mean()
                std = series.std()

                z_scores = (df[col] - mean) / std

                mask = z_scores.abs() > 3

                capped = mask.sum()

                df.loc[mask, col] = series.median()

                if capped > 0:
                    logs.append(f"Replaced {capped} outliers in '{col}' using Z-score")

        except Exception:
            logs.append(f"Warning: failed outlier handling for '{col}'")

    return df