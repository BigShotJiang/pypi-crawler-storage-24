import pandas as pd


def remove_duplicates(df: pd.DataFrame, logs: list, subset=None, keep="first"):
    """
    Remove duplicate rows from dataframe.
    """

    initial_rows = len(df)

    df = df.drop_duplicates(subset=subset, keep=keep)

    removed = initial_rows - len(df)

    if removed > 0:
        logs.append(f"Removed {removed} duplicate rows")
    else:
        logs.append("No duplicate rows found")

    return df