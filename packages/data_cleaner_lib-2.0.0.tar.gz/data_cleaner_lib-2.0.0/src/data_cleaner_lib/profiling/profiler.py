import pandas as pd


def profile_dataset(df: pd.DataFrame, column_types: dict) -> pd.DataFrame:
    """
    Generate a profiling summary of the dataset.

    Parameters
    ----------
    df : pd.DataFrame
        The dataframe to analyze

    column_types : dict
        Output of detect_column_types()

    Returns
    -------
    pd.DataFrame
        Profiling summary
    """

    profile_data = []

    for col in df.columns:

        series = df[col]

        missing_count = series.isna().sum()
        missing_percent = (missing_count / len(series)) * 100

        unique_values = series.nunique(dropna=True)

        col_type = column_types.get(col, "unknown")

        # numeric min/max
        min_value = None
        max_value = None

        if col_type == "numeric":
            min_value = pd.to_numeric(series, errors="coerce").min()
            max_value = pd.to_numeric(series, errors="coerce").max()

        profile_data.append({
            "column": col,
            "dtype": str(series.dtype),
            "detected_type": col_type,
            "missing_count": missing_count,
            "missing_percent": round(missing_percent, 2),
            "unique_values": unique_values,
            "min": min_value,
            "max": max_value
        })

    profile_df = pd.DataFrame(profile_data)

    return profile_df