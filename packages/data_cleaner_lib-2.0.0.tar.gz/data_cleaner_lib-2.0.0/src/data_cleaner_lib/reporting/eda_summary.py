import pandas as pd


def generate_eda_summary(df: pd.DataFrame, column_types: dict):
    """
    Generate an EDA-ready dataset summary.
    """

    summary_rows = []

    for col in df.columns:

        series = df[col]

        col_info = {
            "column": col,
            "detected_type": column_types.get(col, "unknown"),
            "dtype": str(series.dtype),
            "missing_count": series.isna().sum(),
            "missing_percent": round(series.isna().mean() * 100, 2),
            "unique_values": series.nunique()
        }

        if pd.api.types.is_numeric_dtype(series):

            col_info.update({
                "min": series.min(),
                "max": series.max(),
                "mean": round(series.mean(), 2) if series.notna().any() else None,
                "median": series.median()
            })

        else:

            col_info.update({
                "min": None,
                "max": None,
                "mean": None,
                "median": None
            })

        summary_rows.append(col_info)

    summary_df = pd.DataFrame(summary_rows)

    return summary_df