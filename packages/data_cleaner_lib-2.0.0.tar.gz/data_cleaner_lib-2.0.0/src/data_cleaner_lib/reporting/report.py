import pandas as pd


def generate_report(original_df: pd.DataFrame, cleaned_df: pd.DataFrame, logs: list):
    """
    Generate a cleaning summary report.
    """

    report = {}

    report["original_shape"] = original_df.shape
    report["cleaned_shape"] = cleaned_df.shape

    report["rows_removed"] = original_df.shape[0] - cleaned_df.shape[0]

    report["columns"] = list(cleaned_df.columns)

    report["logs"] = logs

    return report