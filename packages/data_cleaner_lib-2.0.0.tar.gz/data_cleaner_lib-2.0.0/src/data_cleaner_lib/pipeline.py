import pandas as pd

from data_cleaner_lib.detection.column_types import detect_column_types
from data_cleaner_lib.profiling.profiler import profile_dataset
from data_cleaner_lib.cleaning.dtype import fix_dtypes
from data_cleaner_lib.cleaning.missing import handle_missing
from data_cleaner_lib.cleaning.duplicates import remove_duplicates
from data_cleaner_lib.cleaning.outliers import handle_outliers
from data_cleaner_lib.cleaning.text import clean_text
from data_cleaner_lib.reporting.report import generate_report
from data_cleaner_lib.quality.quality_score import calculate_quality_score
from data_cleaner_lib.recommendations.recommend import generate_recommendations
from data_cleaner_lib.reporting.eda_summary import generate_eda_summary

class CleanPipeline:
    """
    Main pipeline class for automated dataset preparation.
    """

    def __init__(self, df: pd.DataFrame):

        if not isinstance(df, pd.DataFrame):
            raise TypeError("Input must be a pandas DataFrame")

        self.original_df = df.copy()
        self.df = df.copy()

        self.column_types = {}
        self.logs = []
        self.stats = {}

        self.profile_summary = None

        self._log("Pipeline initialized")

    # -------------------------------
    # Internal logging system
    # -------------------------------

    def _log(self, message: str):
        """Store operation logs"""
        self.logs.append(message)

    # -------------------------------
    # Column Type Detection
    # -------------------------------

    def detect_types(self):
        """Detect column types automatically"""

        self.column_types = detect_column_types(self.df)

        self._log("Column types detected")

        return self

    # -------------------------------
    # Dataset Profiling
    # -------------------------------

    def profile(self):
        """
        Generate dataset profiling summary.
        """

        # Ensure column types exist
        if not self.column_types:
            self.column_types = detect_column_types(self.df)
            self._log("Column types detected")

        self.profile_summary = profile_dataset(self.df, self.column_types)

        self._log("Dataset profiling completed")

        return self.profile_summary
    
    def fix_dtypes(self):
        """
        Standardize dataframe datatypes using detected column types.
        """

        if not self.column_types:
            self.column_types = detect_column_types(self.df)
            self._log("Column types detected")

        self.df = fix_dtypes(self.df, self.column_types, self.logs)

        self._log("Dtype cleaning completed")

        return self


    def handle_missing(self):
        """
        Handle missing values based on column types.
        """

        if not self.column_types:
            self.column_types = detect_column_types(self.df)
            self._log("Column types detected")

        self.df = handle_missing(self.df, self.column_types, self.logs)

        self._log("Missing value handling completed")

        return self

    def remove_duplicates(self, subset=None, keep="first"):
        """
        Remove duplicate rows from the dataframe.
        """

        self.df = remove_duplicates(self.df, self.logs, subset=subset, keep=keep)

        self._log("Duplicate removal completed")

        return self
    
    def handle_outliers(self, method="iqr"):
        """
        Detect and treat outliers in numeric columns.
        """

        if not self.column_types:
            self.column_types = detect_column_types(self.df)
            self._log("Column types detected")

        self.df = handle_outliers(self.df, self.column_types, self.logs, method)

        self._log("Outlier handling completed")

        return self
    
    def clean_text(self):
        """
        Standardize text columns.
        """

        if not self.column_types:
            self.column_types = detect_column_types(self.df)
            self._log("Column types detected")

        self.df = clean_text(self.df, self.column_types, self.logs)

        self._log("Text cleaning completed")

        return self
    
    def report(self):
        """
        Generate cleaning summary report.
        """

        report = generate_report(self.original_df, self.df, self.logs)

        self._log("Cleaning report generated")

        return report

    def prepare_for_eda(self):
        """
        Run the full automated cleaning pipeline.
        """

        self.detect_types()
        self.profile()
        self.fix_dtypes()
        self.handle_missing()
        self.remove_duplicates()
        self.handle_outliers()
        self.clean_text()

        self._log("Automatic EDA preparation completed")

        return self.df
    
    def quality_score(self):
        """
        Calculate dataset quality score.
        """

        score = calculate_quality_score(self.df, self.logs)

        return score
    
    def recommend_cleaning(self):
        """
        Generate cleaning recommendations.
        """

        if not self.column_types:
            self.detect_types()

        recommendations = generate_recommendations(self.df, self.column_types)

        return recommendations

    def eda_summary(self):
        """
        Generate EDA-ready dataset summary.
        """

        if not self.column_types:
            self.detect_types()

        summary = generate_eda_summary(self.df, self.column_types)

        self._log("EDA summary generated")

        return summary

    # -------------------------------
    # View Logs
    # -------------------------------

    def show_logs(self):
        """Return operation logs"""
        return self.logs

    # -------------------------------
    # Return Data
    # -------------------------------

    def get_data(self):
        """Return the current dataframe"""
        return self.df.copy()