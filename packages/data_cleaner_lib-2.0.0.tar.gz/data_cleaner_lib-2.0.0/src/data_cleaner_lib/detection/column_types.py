import pandas as pd
import numpy as np
import re


EMAIL_PATTERN = re.compile(r"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$")


def is_email_series(series: pd.Series, threshold: float = 0.8) -> bool:
    """
    Detect if a column contains email-like values.
    threshold: proportion of values that must match email regex.
    """
    series = series.dropna().astype(str)

    if len(series) == 0:
        return False

    matches = series.str.match(EMAIL_PATTERN)
    return matches.mean() >= threshold

def is_datetime_series(series: pd.Series, threshold: float = 0.8) -> bool:
    """
    Detect datetime columns by attempting conversion.
    """

    # Only attempt detection on object/string columns
    if not pd.api.types.is_object_dtype(series):
        return False

    try:
        converted = pd.to_datetime(series, errors="coerce")
    except Exception:
        return False

    valid_ratio = converted.notna().mean()

    return valid_ratio >= threshold


def is_numeric_series(series: pd.Series, threshold: float = 0.8) -> bool:
    """
    Detect numeric columns even if stored as strings.
    """
    converted = pd.to_numeric(series, errors="coerce")

    valid_ratio = converted.notna().mean()
    return valid_ratio >= threshold


def is_boolean_series(series: pd.Series) -> bool:
    """
    Detect boolean columns including string booleans.
    """
    unique_values = set(series.dropna().astype(str).str.lower().unique())

    boolean_set = {"true", "false", "0", "1", "yes", "no"}

    return unique_values.issubset(boolean_set)


def is_categorical_series(series: pd.Series, unique_ratio_threshold: float = 0.05) -> bool:
    """
    Detect categorical columns based on unique ratio.
    """
    unique_ratio = series.nunique(dropna=True) / len(series)

    return unique_ratio <= unique_ratio_threshold


def detect_column_types(df: pd.DataFrame) -> dict:
    """
    Detect semantic column types for each column in a dataframe.

    Returns:
        dict: {column_name: detected_type}
    """

    column_types = {}

    for col in df.columns:

        series = df[col]

        # Skip nested objects
        if series.apply(lambda x: isinstance(x, (list, dict))).any():
            column_types[col] = "unsupported"
            continue

        # Native numeric dtype
        if pd.api.types.is_numeric_dtype(series):
            column_types[col] = "numeric"
            continue

        # Native datetime dtype
        if pd.api.types.is_datetime64_any_dtype(series):
            column_types[col] = "datetime"
            continue

        # Boolean detection
        if is_boolean_series(series):
            column_types[col] = "boolean"
            continue

        # Email detection
        if is_email_series(series):
            column_types[col] = "email"
            continue

        # Numeric detection (string numbers)
        if is_numeric_series(series):
            column_types[col] = "numeric"
            continue

        # Datetime detection
        if is_datetime_series(series):
            column_types[col] = "datetime"
            continue

        # Categorical detection
        if is_categorical_series(series):
            column_types[col] = "categorical"
            continue

        # Default
        column_types[col] = "text"

    return column_types