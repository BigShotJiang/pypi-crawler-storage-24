import pandas as pd


def calculate_quality_score(df: pd.DataFrame, logs: list):
    """
    Calculate a simple dataset quality score.
    """

    total_cells = df.shape[0] * df.shape[1]

    missing_cells = df.isna().sum().sum()

    missing_ratio = missing_cells / total_cells

    duplicate_ratio = df.duplicated().sum() / df.shape[0]

    score = 100

    score -= missing_ratio * 50
    score -= duplicate_ratio * 30

    score = max(round(score, 2), 0)

    logs.append(f"Data quality score calculated: {score}")

    return score