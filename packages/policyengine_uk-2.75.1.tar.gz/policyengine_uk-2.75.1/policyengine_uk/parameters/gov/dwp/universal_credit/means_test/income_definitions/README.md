# Income definitions
