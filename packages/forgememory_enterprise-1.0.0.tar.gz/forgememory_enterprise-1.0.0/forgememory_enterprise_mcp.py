#!/usr/bin/env python3
"""
ForgeMemory Enterprise MCP Server — Claude Code Integration
Proxies MCP tool calls to ForgeMemory Enterprise REST API at :8201

Usage:
    python3 forgememory_enterprise_mcp.py [--base-url URL]

Env vars (server address — one of the following is required):
    FME_BASE_URL               — Explicit server URL, e.g. https://your-server:8201.
                                  If set, LAN/Tailscale detection is skipped entirely.
                                  This is the recommended option for production.
    FME_LAN_HOST               — LAN hostname/IP for auto-detection (used when
                                  FME_BASE_URL is not set, tried first).
    FME_TAILSCALE_HOST         — Tailscale hostname for auto-detection (used when
                                  FME_BASE_URL is not set, tried as fallback).

Env vars (credentials):
    FORGE_ENTERPRISE_API_KEY   — Required. API key for auth.
    FORGE_ENTERPRISE_TENANT    — Default tenant ID (optional, per-tool override).

Transport: stdio (newline-delimited JSON-RPC 2.0)
Tools: 29 enterprise tools (memory CRUD, agents, audit, admin, GDPR, threads, DSR, compliance, key rotation, entities, facts, stats, conversation log)
"""

import json
import os
import socket
import ssl
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from typing import Any

# NO_FME=1 disables all FME logging — MCP server runs but tools are no-ops
_FME_DISABLED = os.environ.get("NO_FME", "0") == "1"

# SSL context for self-signed certs (Tailscale HTTPS)
_ssl_ctx = ssl.create_default_context()
_ssl_ctx.check_hostname = False
_ssl_ctx.verify_mode = ssl.CERT_NONE

# ── Network Auto-Detection (LAN → Tailscale, 5min cache) ──
# No server addresses are hardcoded. All must be supplied via environment variables.

LAN_HOST = os.environ.get("FME_LAN_HOST", "")
TAILSCALE_HOST = os.environ.get("FME_TAILSCALE_HOST", "")
PORT = int(os.environ.get("FME_PORT", "8201"))
CACHE_TTL = 300

_cached_url: str | None = None
_cached_at: float = 0.0


def _check_host(host: str, port: int, timeout: float) -> bool:
    try:
        s = socket.create_connection((host, port), timeout=timeout)
        s.close()
        return True
    except (OSError, socket.timeout):
        return False


def detect_base_url() -> str:
    """Return the best base URL for the FME server.

    Resolution order:
      1. ``FME_BASE_URL`` env var — used directly, no probing.
      2. ``FME_LAN_HOST`` — probed first (fast LAN path).
      3. ``FME_TAILSCALE_HOST`` — fallback HTTPS path.

    Raises ``ConnectionError`` if no reachable server is found, or if
    neither ``FME_BASE_URL`` nor both host env vars are configured.
    """
    global _cached_url, _cached_at
    now = time.time()
    if _cached_url and (now - _cached_at) < CACHE_TTL:
        return _cached_url

    # Primary: explicit base URL skips all probing.
    explicit = os.environ.get("FME_BASE_URL", "")
    if explicit:
        _cached_url = explicit
        _cached_at = now
        return _cached_url

    # Auto-detection requires both host vars to be set.
    if not LAN_HOST and not TAILSCALE_HOST:
        raise ConnectionError(
            "Cannot reach ForgeMemory Enterprise: no server address configured. "
            "Set FME_BASE_URL (e.g. https://your-server:8201) or both "
            "FME_LAN_HOST and FME_TAILSCALE_HOST environment variables."
        )

    if LAN_HOST and _check_host(LAN_HOST, PORT, timeout=1.5):
        _cached_url = f"https://{LAN_HOST}:{PORT}"
    elif TAILSCALE_HOST and _check_host(TAILSCALE_HOST, PORT, timeout=3.0):
        _cached_url = f"https://{TAILSCALE_HOST}:{PORT}"
    else:
        _cached_url = None
        lan_desc = f"https://{LAN_HOST}:{PORT}" if LAN_HOST else "(LAN_HOST not set)"
        ts_desc = f"https://{TAILSCALE_HOST}:{PORT}" if TAILSCALE_HOST else "(TAILSCALE_HOST not set)"
        raise ConnectionError(
            f"Cannot reach ForgeMemory Enterprise at "
            f"{lan_desc} (LAN) or {ts_desc} (Tailscale). "
            f"Check FME_LAN_HOST, FME_TAILSCALE_HOST, or set FME_BASE_URL directly."
        )

    _cached_at = now
    log(f"Auto-detected FME at {_cached_url}")
    return _cached_url


# ── HTTP Helpers ──

API_KEY = os.environ.get("FORGE_ENTERPRISE_API_KEY", "")
DEFAULT_TENANT = os.environ.get("FORGE_ENTERPRISE_TENANT", "")


def api_call(method: str, path: str, body: dict | None = None) -> dict:
    base = detect_base_url()
    url = f"{base}{path}"

    data = json.dumps(body).encode() if body else None
    headers: dict[str, str] = {"Content-Type": "application/json"}
    if API_KEY:
        headers["Authorization"] = f"Bearer {API_KEY}"

    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    ctx = _ssl_ctx if url.startswith("https://") else None
    try:
        with urllib.request.urlopen(req, timeout=15, context=ctx) as resp:
            return json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        error_body = e.read().decode() if e.fp else str(e)
        return {"error": f"HTTP {e.code}: {error_body}"}
    except urllib.error.URLError as e:
        return {"error": f"Connection failed: {e.reason}"}
    except Exception as e:
        return {"error": str(e)}


# ── Logging ──

def log(msg: str):
    print(f"[fme-mcp] {msg}", file=sys.stderr, flush=True)


# ── MCP Tool Definitions (15 tools) ──

TOOLS = [
    # ── Memory Data Plane ──
    {
        "name": "fme_search_memories",
        "description": "Search memories within a specific tenant. Returns relevant memories ranked by recency, importance, and relevance. Use for recalling past context within an enterprise tenant.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "tenant_id": {"type": "string", "description": "Tenant ID to search within"},
                "query": {"type": "string", "description": "Search query (natural language)"},
                "limit": {"type": "integer", "description": "Max results (default 10)", "default": 10},
                "memory_type": {
                    "type": "string",
                    "enum": ["semantic", "episodic", "procedural"],
                    "description": "Filter by memory type (optional)",
                },
                "detail": {
                    "type": "string",
                    "enum": ["outline", "summary", "full"],
                    "description": "Level of detail to return (default: full). Use 'outline' for L1 topic catalogs, or 'summary' for L2 fast summaries to save tokens.",
                },
            },
            "required": ["tenant_id", "query"],
        },
    },
    {
        "name": "fme_add_memory",
        "description": "Store a new memory in an enterprise tenant. Memories are encrypted at rest and subject to tenant quotas.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "tenant_id": {"type": "string", "description": "Tenant ID to store memory in"},
                "content": {"type": "string", "description": "Memory content to store"},
                "memory_type": {
                    "type": "string",
                    "enum": ["semantic", "episodic", "procedural"],
                    "description": "Memory type (default: semantic)",
                    "default": "semantic",
                },
                "importance": {"type": "integer", "description": "Importance 1-10 (default: 5)", "default": 5},
                "tags": {"type": "string", "description": "Comma-separated tags"},
                "user_id": {"type": "string", "description": "User who created the memory"},
                "client_id": {"type": "string", "description": "Client (data subject) this memory relates to"},
            },
            "required": ["tenant_id", "content"],
        },
    },
    {
        "name": "fme_get_context",
        "description": "Get assembled LLM context from a tenant's memory. Returns relevant memories formatted for prompt injection. Use before responding to questions that benefit from enterprise memory context.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "tenant_id": {"type": "string", "description": "Tenant ID"},
                "query": {"type": "string", "description": "Query to assemble context for"},
                "max_tokens": {"type": "integer", "description": "Max context tokens (default: 500)", "default": 500},
                "detail": {
                    "type": "string",
                    "enum": ["outline", "summary", "full"],
                    "description": "Level of detail to build context from (optional).",
                },
                "context_budget_tokens": {
                    "type": "integer",
                    "description": "Optional token budget for auto-tiering. Replaces max_tokens if used, filling L3 -> L2 -> L1 as space allows.",
                },
            },
            "required": ["tenant_id", "query"],
        },
    },
    {
        "name": "fme_get_memory",
        "description": "Retrieve a specific memory by ID from a tenant.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "tenant_id": {"type": "string", "description": "Tenant ID"},
                "memory_id": {"type": "string", "description": "Memory UUID"},
            },
            "required": ["tenant_id", "memory_id"],
        },
    },
    {
        "name": "fme_get_topics",
        "description": "Get high-level semantic topics from a tenant's memory catalog. Used for Level 1 exploration prior to deep-dive searching.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "tenant_id": {"type": "string", "description": "Tenant ID"},
                "query": {"type": "string", "description": "Topic keyword search (optional)"},
                "limit": {"type": "integer", "description": "Max topics to return (default 10)", "default": 10},
            },
            "required": ["tenant_id"],
        },
    },
    {
        "name": "fme_delete_memory",
        "description": "Delete a specific memory from a tenant. Respects legal holds and writes audit trail.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "tenant_id": {"type": "string", "description": "Tenant ID"},
                "memory_id": {"type": "string", "description": "Memory UUID to delete"},
            },
            "required": ["tenant_id", "memory_id"],
        },
    },
    # ── Agent Registry ──
    {
        "name": "fme_register_agent",
        "description": "Register a new AI agent in the enterprise agent registry. Agents must be registered before they can start sessions or access memories.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "Agent name (unique within org)"},
                "org_id": {"type": "string", "description": "Organization ID"},
                "framework": {
                    "type": "string",
                    "enum": ["crewai", "langgraph", "autogen", "openclaw", "agent_zero", "custom"],
                    "description": "Agent framework",
                },
                "capabilities": {"type": "string", "description": "Comma-separated capability list"},
            },
            "required": ["name", "org_id", "framework"],
        },
    },
    {
        "name": "fme_list_agents",
        "description": "List registered agents, optionally filtered by organization or framework.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "org_id": {"type": "string", "description": "Filter by org ID (optional)"},
                "framework": {"type": "string", "description": "Filter by framework (optional)"},
                "limit": {"type": "integer", "description": "Max results (default 50)", "default": 50},
                "offset": {"type": "integer", "description": "Pagination offset", "default": 0},
            },
        },
    },
    {
        "name": "fme_start_session",
        "description": "Start a new agent session. Sessions track agent activity, enable heartbeat monitoring, and are required for audit logging.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "agent_id": {"type": "string", "description": "Registered agent ID"},
                "tenant_id": {"type": "string", "description": "Tenant the session operates on"},
                "metadata": {"type": "string", "description": "JSON metadata string (optional)"},
            },
            "required": ["agent_id", "tenant_id"],
        },
    },
    {
        "name": "fme_end_session",
        "description": "End an active agent session. Records final status (completed/failed) and duration.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "session_id": {"type": "string", "description": "Session ID to end"},
                "status": {
                    "type": "string",
                    "enum": ["completed", "failed"],
                    "description": "Final session status",
                    "default": "completed",
                },
            },
            "required": ["session_id"],
        },
    },
    # ── Audit ──
    {
        "name": "fme_log_action",
        "description": "Log an agent action to the APPEND-ONLY audit trail. Actions are immutable once written.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "agent_id": {"type": "string", "description": "Agent ID"},
                "session_id": {"type": "string", "description": "Active session ID"},
                "action_type": {
                    "type": "string",
                    "enum": ["tool_call", "memory_read", "memory_write", "delegation", "error"],
                    "description": "Type of action",
                },
                "description": {"type": "string", "description": "Human-readable action description"},
                "result": {"type": "string", "description": "Action result or output summary"},
            },
            "required": ["agent_id", "session_id", "action_type", "description"],
        },
    },
    {
        "name": "fme_log_cost",
        "description": "Record a cost event for budget tracking. Costs are tracked per-agent per-day with configurable budget limits.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "agent_id": {"type": "string", "description": "Agent ID"},
                "amount_cents": {"type": "integer", "description": "Cost in cents (e.g., 150 = $1.50)"},
                "description": {"type": "string", "description": "What the cost was for"},
            },
            "required": ["agent_id", "amount_cents", "description"],
        },
    },
    # ── Tenants ──
    {
        "name": "fme_list_tenants",
        "description": "List all tenants with pagination. Shows tenant name, status, memory count, and quota.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "limit": {"type": "integer", "description": "Max results (default 50)", "default": 50},
                "offset": {"type": "integer", "description": "Pagination offset", "default": 0},
            },
        },
    },
    {
        "name": "fme_get_tenant",
        "description": "Get detailed information about a specific tenant including quota usage.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "tenant_id": {"type": "string", "description": "Tenant ID"},
            },
            "required": ["tenant_id"],
        },
    },
    # ── Admin ──
    {
        "name": "fme_dashboard",
        "description": "Get the enterprise admin dashboard snapshot: top orgs, active agents, memory counts, cost trends, and system health.",
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
    },
    # ── GDPR ──
    {
        "name": "fme_gdpr_erasure",
        "description": "Execute GDPR Article 17 right-to-erasure for a data subject (client). Soft-deletes all memories for the specified client, writes immutable audit trail, and records the data subject request. Blocked if legal hold is active.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "tenant_id": {"type": "string", "description": "Tenant ID containing the data"},
                "client_id": {"type": "string", "description": "Client/data subject ID to erase"},
                "requested_by": {"type": "string", "description": "Who requested the erasure"},
                "reason": {"type": "string", "description": "Reason for erasure request"},
            },
            "required": ["tenant_id", "client_id", "requested_by"],
        },
    },
    # ── Communication Threading ──
    {
        "name": "fme_get_thread",
        "description": "Get all memories grouped under a thread ID, ordered chronologically. Returns a summary (count, earliest/latest timestamps) plus the full memory list. Useful for reconstructing conversation threads, FINRA examination chains, and CRM opportunity histories.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "tenant_id": {"type": "string", "description": "Tenant ID"},
                "thread_id": {"type": "string", "description": "Thread ID to retrieve"},
            },
            "required": ["tenant_id", "thread_id"],
        },
    },
    {
        "name": "fme_link_thread",
        "description": "Link one or more memory IDs to a thread ID. Sets the thread_id field on each memory and updates updated_at. Silently skips memory IDs that do not exist. Returns the count of memories actually linked.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "tenant_id": {"type": "string", "description": "Tenant ID"},
                "thread_id": {"type": "string", "description": "Thread ID to link memories to"},
                "memory_ids": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "List of memory UUIDs to link to the thread",
                },
            },
            "required": ["tenant_id", "thread_id", "memory_ids"],
        },
    },
    # ── DSR Approval Workflow ──
    {
        "name": "fme_create_dsr",
        "description": "Create a Data Subject Request (DSR) under GDPR. Supports erasure (Art. 17), access (Art. 15), rectification (Art. 16), and portability (Art. 20) request types. The DSR enters a pending state awaiting admin approval.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "tenant_id": {"type": "string", "description": "Tenant ID"},
                "request_type": {
                    "type": "string",
                    "enum": ["erasure", "access", "rectification", "portability"],
                    "description": "Type of GDPR data subject request",
                },
                "subject_id": {"type": "string", "description": "ID of the data subject (client)"},
                "reason": {"type": "string", "description": "Reason for the request (optional)"},
            },
            "required": ["tenant_id", "request_type", "subject_id"],
        },
    },
    {
        "name": "fme_list_dsr",
        "description": "List all Data Subject Requests (DSRs) for a tenant, showing request type, subject ID, status (pending/approved/rejected/completed), and timestamps.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "tenant_id": {"type": "string", "description": "Tenant ID"},
            },
            "required": ["tenant_id"],
        },
    },
    {
        "name": "fme_approve_dsr",
        "description": "Approve a pending Data Subject Request (DSR). For erasure requests this triggers soft-deletion of all matching memories. Writes an immutable audit record. Optionally include reviewer notes.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "tenant_id": {"type": "string", "description": "Tenant ID"},
                "dsr_id": {"type": "string", "description": "DSR UUID to approve"},
                "reviewer_notes": {"type": "string", "description": "Optional notes from the reviewer"},
            },
            "required": ["tenant_id", "dsr_id"],
        },
    },
    # ── Compliance Posture ──
    {
        "name": "fme_compliance_posture",
        "description": "Get the overall enterprise compliance posture: a scored summary of controls across encryption, audit logging, retention, access control, and GDPR readiness. Returns an overall score and per-control details. Suitable for Vanta/Drata evidence collection.",
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
    },
    {
        "name": "fme_compliance_evidence",
        "description": "Get structured compliance evidence for external audit platforms (Vanta, Drata, SOC 2). Returns control IDs, descriptions, status (pass/fail/partial), and evidence artifacts that can be attached to compliance reports.",
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
    },
    # ── API Key Rotation ──
    {
        "name": "fme_rotate_key",
        "description": "Rotate an API key. Creates a new key with the same org/role/tenant scope, then sets an expiration on the old key (grace period). Returns the new key plaintext (shown exactly once) plus the old key expiry timestamp. Requires Admin role.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "key_id": {"type": "string", "description": "ID of the API key to rotate"},
                "grace_period_hours": {
                    "type": "integer",
                    "description": "Hours before the old key expires (default: 24)",
                    "default": 24,
                },
            },
            "required": ["key_id"],
        },
    },
    # ── Health ──
    {
        "name": "fme_health_ready",
        "description": "Check the enterprise server readiness probe. Returns status (ready/not_ready) and per-component health checks (database, encryption, pool). Use to verify the server is fully initialised before sending traffic.",
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
    },
    # ── Entities (Knowledge Graph) ──
    {
        "name": "fme_list_entities",
        "description": "List all entities (people, places, things) tracked in a tenant's knowledge graph.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "tenant_id": {"type": "string", "description": "Tenant ID"},
            },
            "required": ["tenant_id"],
        },
    },
    {
        "name": "fme_get_entity",
        "description": "Get detailed information about a specific entity from the knowledge graph, including relationships and associated memories.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "tenant_id": {"type": "string", "description": "Tenant ID"},
                "name": {"type": "string", "description": "Entity name to look up"},
            },
            "required": ["tenant_id", "name"],
        },
    },
    # ── Facts (Semantic Memories) ──
    {
        "name": "fme_list_facts",
        "description": "List all known semantic facts from a tenant. These are long-term memories like user preferences, project decisions, and learned patterns.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "tenant_id": {"type": "string", "description": "Tenant ID"},
                "limit": {"type": "integer", "description": "Max facts to return (default: 20)", "default": 20},
            },
            "required": ["tenant_id"],
        },
    },
    # ── System Stats ──
    {
        "name": "fme_get_stats",
        "description": "Get ForgeMemory Enterprise system statistics: total memories, tenant counts, storage size, and system health.",
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
    },
    # ── Conversation Logging ──
    {
        "name": "fme_log_conversation",
        "description": "Store a conversation exchange as an episodic memory. Use after significant interactions to build long-term recall.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "tenant_id": {"type": "string", "description": "Tenant ID"},
                "user_message": {"type": "string", "description": "The user's message"},
                "assistant_message": {"type": "string", "description": "The assistant's response"},
            },
            "required": ["tenant_id", "user_message", "assistant_message"],
        },
    },
]


# ── Tool Execution ──

def _resolve_tenant(args: dict) -> str:
    """Get tenant_id from args or fall back to DEFAULT_TENANT env var.

    Raises ValueError if neither the call argument nor the environment
    variable is set, so callers get an explicit error instead of silently
    sending an empty string to the server.
    """
    tenant_id = args.get("tenant_id") or DEFAULT_TENANT
    if not tenant_id:
        raise ValueError(
            "tenant_id is required. Pass it as an argument or set the "
            "FORGE_ENTERPRISE_TENANT environment variable."
        )
    return tenant_id


def execute_tool(name: str, args: dict) -> str:
    """Execute a tool and return the result as a JSON string."""

    # ── Memory Data Plane ──
    if name == "fme_search_memories":
        tid = _resolve_tenant(args)
        body: dict[str, Any] = {"query": args["query"], "tenant_id": tid}
        if "limit" in args:
            body["limit"] = args["limit"]
        if "memory_type" in args:
            body["memory_type"] = args["memory_type"]
        if "detail" in args:
            body["detail"] = args["detail"]
        result = api_call("POST", f"/api/v1/tenants/{tid}/memories/search", body)

    elif name == "fme_add_memory":
        tid = _resolve_tenant(args)
        body = {
            "content": args["content"],
            "memory_type": args.get("memory_type", "semantic"),
            "importance": args.get("importance", 5),
        }
        if "tags" in args:
            tags = args["tags"]
            body["tags"] = [t.strip() for t in tags.split(",")] if isinstance(tags, str) else tags
        if "user_id" in args:
            body["user_id"] = args["user_id"]
        if "client_id" in args:
            body["client_id"] = args["client_id"]
        result = api_call("POST", f"/api/v1/tenants/{tid}/memories", body)

    elif name == "fme_get_context":
        tid = _resolve_tenant(args)
        params = f"?query={urllib.parse.quote(args['query'])}"
        if "max_tokens" in args:
            params += f"&max_tokens={args['max_tokens']}"
        if "detail" in args:
            params += f"&detail={args['detail']}"
        if "context_budget_tokens" in args:
            params += f"&context_budget_tokens={args['context_budget_tokens']}"
        result = api_call("GET", f"/api/v1/tenants/{tid}/context{params}")

    elif name == "fme_get_memory":
        tid = _resolve_tenant(args)
        mid = args["memory_id"]
        result = api_call("GET", f"/api/v1/tenants/{tid}/memories/{mid}")

    elif name == "fme_get_topics":
        tid = _resolve_tenant(args)
        params = ""
        param_list = []
        if "query" in args and args["query"]:
            param_list.append(f"query={urllib.parse.quote(args['query'])}")
        if "limit" in args:
            param_list.append(f"limit={args['limit']}")
        if param_list:
            params = "?" + "&".join(param_list)
        result = api_call("GET", f"/api/v1/tenants/{tid}/search/topics{params}")

    elif name == "fme_delete_memory":
        tid = _resolve_tenant(args)
        mid = args["memory_id"]
        result = api_call("DELETE", f"/api/v1/tenants/{tid}/memories/{mid}")

    # ── Agent Registry ──
    elif name == "fme_register_agent":
        body = {
            "name": args["name"],
            "org_id": args["org_id"],
            "framework": args["framework"],
        }
        if "capabilities" in args:
            body["capabilities"] = args["capabilities"]
        result = api_call("POST", "/api/v1/agents", body)

    elif name == "fme_list_agents":
        params_parts = []
        if "org_id" in args:
            params_parts.append(f"org_id={urllib.parse.quote(args['org_id'])}")
        if "framework" in args:
            params_parts.append(f"framework={args['framework']}")
        if "limit" in args:
            params_parts.append(f"limit={args['limit']}")
        if "offset" in args:
            params_parts.append(f"offset={args['offset']}")
        qs = f"?{'&'.join(params_parts)}" if params_parts else ""
        result = api_call("GET", f"/api/v1/agents{qs}")

    elif name == "fme_start_session":
        body = {
            "agent_id": args["agent_id"],
            "tenant_id": args.get("tenant_id", DEFAULT_TENANT),
        }
        if "metadata" in args:
            body["metadata"] = args["metadata"]
        result = api_call("POST", f"/api/v1/agents/{args['agent_id']}/sessions", body)

    elif name == "fme_end_session":
        body = {"status": args.get("status", "completed")}
        result = api_call("POST", f"/api/v1/sessions/{args['session_id']}/end", body)

    # ── Audit ──
    elif name == "fme_log_action":
        body = {
            "agent_id": args["agent_id"],
            "session_id": args["session_id"],
            "action_type": args["action_type"],
            "description": args["description"],
        }
        if "result" in args:
            body["result"] = args["result"]
        result = api_call("POST", f"/api/v1/agents/{args['agent_id']}/actions", body)

    elif name == "fme_log_cost":
        body = {
            "agent_id": args["agent_id"],
            "amount_cents": args["amount_cents"],
            "description": args["description"],
        }
        result = api_call("POST", f"/api/v1/agents/{args['agent_id']}/costs", body)

    # ── Tenants ──
    elif name == "fme_list_tenants":
        params_parts = []
        if "limit" in args:
            params_parts.append(f"limit={args['limit']}")
        if "offset" in args:
            params_parts.append(f"offset={args['offset']}")
        qs = f"?{'&'.join(params_parts)}" if params_parts else ""
        result = api_call("GET", f"/api/v1/tenants{qs}")

    elif name == "fme_get_tenant":
        result = api_call("GET", f"/api/v1/tenants/{args['tenant_id']}")

    # ── Admin ──
    elif name == "fme_dashboard":
        result = api_call("GET", "/api/v1/admin/dashboard")

    # ── GDPR ──
    elif name == "fme_gdpr_erasure":
        tid = _resolve_tenant(args)
        body = {
            "client_id": args["client_id"],
            "requested_by": args["requested_by"],
        }
        if "reason" in args:
            body["reason"] = args["reason"]
        result = api_call("POST", f"/api/v1/tenants/{tid}/gdpr/erasure", body)

    # ── Communication Threading ──
    elif name == "fme_get_thread":
        tid = _resolve_tenant(args)
        thread_id = args["thread_id"]
        result = api_call("GET", f"/api/v1/tenants/{tid}/threads/{thread_id}")

    elif name == "fme_link_thread":
        tid = _resolve_tenant(args)
        body = {
            "thread_id": args["thread_id"],
            "memory_ids": args["memory_ids"],
        }
        result = api_call("POST", f"/api/v1/tenants/{tid}/threads", body)

    # ── DSR Approval Workflow ──
    elif name == "fme_create_dsr":
        tid = _resolve_tenant(args)
        body: dict[str, Any] = {
            "request_type": args["request_type"],
            "subject_id": args["subject_id"],
        }
        if "reason" in args:
            body["reason"] = args["reason"]
        result = api_call("POST", f"/api/v1/tenants/{tid}/dsr/request", body)

    elif name == "fme_list_dsr":
        tid = _resolve_tenant(args)
        result = api_call("GET", f"/api/v1/tenants/{tid}/dsr")

    elif name == "fme_approve_dsr":
        tid = _resolve_tenant(args)
        dsr_id = args["dsr_id"]
        body = {}
        if "reviewer_notes" in args:
            body["reviewer_notes"] = args["reviewer_notes"]
        result = api_call("POST", f"/api/v1/tenants/{tid}/dsr/{dsr_id}/approve", body)

    # ── Compliance Posture ──
    elif name == "fme_compliance_posture":
        result = api_call("GET", "/api/v1/admin/compliance-posture")

    elif name == "fme_compliance_evidence":
        result = api_call("GET", "/api/v1/admin/compliance-evidence")

    # ── API Key Rotation ──
    elif name == "fme_rotate_key":
        key_id = args["key_id"]
        body = {"grace_period_hours": args.get("grace_period_hours", 24)}
        result = api_call("POST", f"/api/v1/api-keys/{key_id}/rotate", body)

    # ── Health ──
    elif name == "fme_health_ready":
        result = api_call("GET", "/health/ready")

    # ── Entities (Knowledge Graph) ──
    elif name == "fme_list_entities":
        tid = _resolve_tenant(args)
        result = api_call("GET", f"/api/v1/tenants/{tid}/entities")

    elif name == "fme_get_entity":
        tid = _resolve_tenant(args)
        entity_name = urllib.parse.quote(args["name"])
        result = api_call("GET", f"/api/v1/tenants/{tid}/entities/{entity_name}")

    # ── Facts (Semantic Memories) ──
    elif name == "fme_list_facts":
        tid = _resolve_tenant(args)
        limit = args.get("limit", 20)
        result = api_call("GET", f"/api/v1/tenants/{tid}/memories?memory_type=semantic&limit={limit}")

    # ── System Stats ──
    elif name == "fme_get_stats":
        result = api_call("GET", "/api/v1/admin/stats")

    # ── Conversation Logging ──
    elif name == "fme_log_conversation":
        tid = _resolve_tenant(args)
        content = f"User: {args['user_message']}\nAssistant: {args['assistant_message']}"
        body = {
            "content": content,
            "memory_type": "episodic",
            "importance": 4,
            "tags": ["conversation-log"],
        }
        result = api_call("POST", f"/api/v1/tenants/{tid}/memories", body)

    else:
        result = {"error": f"Unknown tool: {name}"}

    return json.dumps(result, indent=2)


# ── MCP Protocol Handler ──

SERVER_INFO = {
    "name": "forgememory-enterprise",
    "version": "1.0.0",
}

CAPABILITIES = {
    "tools": {},
}


def handle_request(msg: dict) -> dict | None:
    """Handle an incoming JSON-RPC 2.0 message."""
    method = msg.get("method", "")
    msg_id = msg.get("id")
    params = msg.get("params", {})

    if msg_id is None:
        if method == "notifications/initialized":
            log("Client initialized")
        return None

    if method == "initialize":
        return {
            "jsonrpc": "2.0",
            "id": msg_id,
            "result": {
                "protocolVersion": "2024-11-05",
                "serverInfo": SERVER_INFO,
                "capabilities": CAPABILITIES,
            },
        }

    elif method == "tools/list":
        return {
            "jsonrpc": "2.0",
            "id": msg_id,
            "result": {"tools": TOOLS},
        }

    elif method == "tools/call":
        tool_name = params.get("name", "")
        tool_args = params.get("arguments", {})
        log(f"Calling tool: {tool_name}")

        if _FME_DISABLED:
            return {
                "jsonrpc": "2.0",
                "id": msg_id,
                "result": {
                    "content": [{"type": "text", "text": "(FME logging disabled — NO_FME=1)"}],
                },
            }

        try:
            result_text = execute_tool(tool_name, tool_args)
            return {
                "jsonrpc": "2.0",
                "id": msg_id,
                "result": {
                    "content": [{"type": "text", "text": result_text}],
                },
            }
        except Exception as e:
            log(f"Tool error: {e}")
            return {
                "jsonrpc": "2.0",
                "id": msg_id,
                "result": {
                    "content": [{"type": "text", "text": json.dumps({"error": str(e)})}],
                    "isError": True,
                },
            }

    elif method == "resources/list":
        return {
            "jsonrpc": "2.0",
            "id": msg_id,
            "result": {"resources": []},
        }

    elif method == "ping":
        return {"jsonrpc": "2.0", "id": msg_id, "result": {}}

    else:
        return {
            "jsonrpc": "2.0",
            "id": msg_id,
            "error": {"code": -32601, "message": f"Method not found: {method}"},
        }


def main():
    """Main stdio loop — read JSON-RPC from stdin, write responses to stdout."""
    log("ForgeMemory Enterprise MCP server starting (stdio transport)")

    explicit_url = os.environ.get("FME_BASE_URL", "")
    if explicit_url:
        log(f"Using FME_BASE_URL: {explicit_url}")
    elif LAN_HOST or TAILSCALE_HOST:
        lan_desc = f"http://{LAN_HOST}:{PORT}" if LAN_HOST else "(not set)"
        ts_desc = f"https://{TAILSCALE_HOST}:{PORT}" if TAILSCALE_HOST else "(not set)"
        log(f"Will auto-detect: LAN={lan_desc} / Tailscale={ts_desc}")
    else:
        log(
            "ERROR: No server address configured. "
            "Set FME_BASE_URL or both FME_LAN_HOST and FME_TAILSCALE_HOST."
        )
        sys.exit(1)

    if API_KEY:
        log(f"API key configured ({len(API_KEY)} chars)")
    else:
        log("WARNING: No FORGE_ENTERPRISE_API_KEY set — requests will be unauthenticated")

    if len(sys.argv) > 2 and sys.argv[1] == "--base-url":
        global _cached_url, _cached_at
        _cached_url = sys.argv[2]
        _cached_at = time.time() + 999999
        log(f"Using explicit base URL: {_cached_url}")

    MAX_LINE_BYTES = 10 * 1024 * 1024  # 10 MB — discard oversized messages
    for line in sys.stdin:
        if len(line) > MAX_LINE_BYTES:
            log(f"Oversized message ({len(line)} bytes), discarding")
            continue
        line = line.strip()
        if not line:
            continue

        try:
            msg = json.loads(line)
        except json.JSONDecodeError as e:
            log(f"JSON parse error: {e}")
            error_resp = {
                "jsonrpc": "2.0",
                "id": None,
                "error": {"code": -32700, "message": f"Parse error: {e}"},
            }
            sys.stdout.write(json.dumps(error_resp) + "\n")
            sys.stdout.flush()
            continue

        response = handle_request(msg)
        if response is not None:
            sys.stdout.write(json.dumps(response) + "\n")
            sys.stdout.flush()

    log("stdin closed, shutting down")


if __name__ == "__main__":
    main()
