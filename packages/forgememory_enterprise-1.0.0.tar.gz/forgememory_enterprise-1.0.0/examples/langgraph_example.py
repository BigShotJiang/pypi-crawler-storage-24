"""ForgeMemory Enterprise SDK — LangGraph Integration Example.

Shows how to add memory nodes to a LangGraph workflow.
"""

from forgememory_enterprise import EnterpriseClient
from forgememory_enterprise.adapters.langgraph_adapter import (
    make_memory_context_node,
    make_memory_retrieve_node,
    make_memory_store_node,
)


def main():
    client = EnterpriseClient(api_key="fme_your_api_key_here")
    tenant_id = "tenant-123"

    # Create memory nodes
    retrieve = make_memory_retrieve_node(client, tenant_id, limit=5)
    store = make_memory_store_node(client, tenant_id, source="langgraph-demo")
    context = make_memory_context_node(client, tenant_id, max_tokens=500)

    # Simulate a LangGraph state flowing through nodes
    state = {"query": "What is the project deadline?"}

    # Step 1: Retrieve memories
    state.update(retrieve(state))
    print(f"Memory context: {state.get('memory_context', 'none')}")

    # Step 2: Get assembled context (alternative to raw retrieval)
    state.update(context(state))
    print(f"Assembled context: {state.get('memory_context', 'none')}")

    # Step 3: Store a new memory
    state["memory_to_store"] = "Project deadline is March 15, 2026"
    state.update(store(state))
    print(f"Stored memory ID: {state.get('memory_stored_id')}")

    client.close()


if __name__ == "__main__":
    main()
