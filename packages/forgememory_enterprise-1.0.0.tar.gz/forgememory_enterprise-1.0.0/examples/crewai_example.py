"""ForgeMemory Enterprise SDK — CrewAI Integration Example.

Shows how to use ForgeMemory as a tool in CrewAI crews with audit logging.
"""

from forgememory_enterprise import EnterpriseClient
from forgememory_enterprise.adapters.crewai_adapter import FMECrewObserver, ForgeMemoryTool


def main():
    client = EnterpriseClient(api_key="fme_your_api_key_here")

    # Create a CrewAI-compatible memory tool
    memory_tool = ForgeMemoryTool(client, tenant_id="tenant-123")

    # Use the tool directly (normally CrewAI calls this)
    result = memory_tool.run("search:customer preferences")
    print(f"Search result: {result}")

    result = memory_tool.run("store:Customer prefers email communication")
    print(f"Store result: {result}")

    # Set up audit logging with a session
    with client.session("crewai-agent", "tenant-123") as sess:
        observer = FMECrewObserver(client, "crewai-agent", sess.id)

        # Log tool usage
        observer.on_tool_use("forgememory", "search:preferences")

        # Log LLM calls
        observer.on_llm_call(tokens_in=500, tokens_out=200, cost_usd=0.005)

        print(f"Session {sess.id} completed with audit trail")

    client.close()


if __name__ == "__main__":
    main()
