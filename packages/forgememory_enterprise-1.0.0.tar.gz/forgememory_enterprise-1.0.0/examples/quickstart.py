"""ForgeMemory Enterprise SDK — Quickstart Example.

Demonstrates basic usage: create org, user, tenant, store/search memories.
"""

from forgememory_enterprise import EnterpriseClient
from forgememory_enterprise.types import CreateMemoryRequest


def main():
    # Connect to FME (auto-detects LAN/Tailscale)
    client = EnterpriseClient(api_key="fme_your_api_key_here")

    # Create an organization
    org = client.orgs.create_org("Acme Corp", "acme")
    print(f"Created org: {org.id}")

    # Create a user
    user = client.orgs.create_user(org.id, "alice@acme.com", "Alice", "admin")
    print(f"Created user: {user.id}")

    # Provision a tenant
    tenant = client.orgs.provision(org.id, mode="per_org")
    print(f"Provisioned tenant: {tenant.id}")

    # Store a memory
    mem = client.memory.create(
        tenant.id,
        CreateMemoryRequest(
            content="The Q4 revenue target is $2.5M",
            memory_type="semantic",
            importance=8,
            source="quickstart",
            tags=["finance", "targets"],
        ),
    )
    print(f"Stored memory: {mem.id}")

    # Search memories
    results = client.memory.search(tenant.id, "revenue target", limit=5)
    for r in results:
        print(f"  Found: [{r.memory_type}] {r.content}")

    # Get assembled context for LLM
    ctx = client.memory.context(tenant.id, "What are our financial targets?")
    print(f"\nAssembled context ({ctx.memories_used} memories):")
    print(ctx.context)

    client.close()


if __name__ == "__main__":
    main()
