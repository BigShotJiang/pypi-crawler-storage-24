"""Tests for EnterpriseClient."""

import httpx
import pytest

from forgememory_enterprise import EnterpriseClient
from forgememory_enterprise._network import clear_cache


class TestEnterpriseClient:
    def test_client_creates_with_explicit_url(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, json={"success": True, "data": "ok"})

        transport = httpx.MockTransport(handler)
        client = EnterpriseClient(api_key="test", base_url="http://localhost:8201", transport=transport)
        assert client._client is not None
        client.close()

    def test_client_context_manager(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, json={"success": True, "data": "ok"})

        transport = httpx.MockTransport(handler)
        with EnterpriseClient(api_key="test", base_url="http://localhost:8201", transport=transport) as client:
            assert client._client is not None

    def test_lazy_sub_managers(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, json={"success": True, "data": "ok"})

        transport = httpx.MockTransport(handler)
        client = EnterpriseClient(api_key="test", base_url="http://localhost:8201", transport=transport)

        # All sub-managers should be None initially
        assert client._orgs is None
        assert client._tenants is None
        assert client._api_keys is None
        assert client._agents is None
        assert client._audit is None
        assert client._memory is None
        assert client._admin is None

        # Accessing them should create them
        _ = client.orgs
        _ = client.tenants
        _ = client.api_keys
        _ = client.agents
        _ = client.audit
        _ = client.memory
        _ = client.admin

        assert client._orgs is not None
        assert client._tenants is not None
        assert client._api_keys is not None
        assert client._agents is not None
        assert client._audit is not None
        assert client._memory is not None
        assert client._admin is not None

        client.close()

    def test_api_key_header_set(self):
        received_headers = {}

        def handler(request: httpx.Request) -> httpx.Response:
            received_headers.update(dict(request.headers))
            return httpx.Response(200, json={"success": True, "data": []})

        transport = httpx.MockTransport(handler)
        client = EnterpriseClient(api_key="fme_secret_key", base_url="http://localhost:8201", transport=transport)
        client.orgs.list_orgs()
        assert received_headers.get("x-api-key") == "fme_secret_key"
        client.close()

    def test_session_creates_context(self):
        def handler(request: httpx.Request) -> httpx.Response:
            if "sessions" in str(request.url) and request.method == "POST":
                if "/end" in str(request.url):
                    return httpx.Response(200, json={"success": True, "data": "ended"})
                return httpx.Response(200, json={
                    "success": True,
                    "data": {
                        "id": "sess-1", "agent_id": "a-1", "tenant_id": "t-1",
                        "status": "active", "started_at": "2026-01-01T00:00:00Z",
                        "ended_at": None, "last_heartbeat": "2026-01-01T00:00:00Z",
                        "metadata_json": "{}",
                    },
                })
            return httpx.Response(200, json={"success": True, "data": "ok"})

        transport = httpx.MockTransport(handler)
        client = EnterpriseClient(api_key="test", base_url="http://localhost:8201", transport=transport)
        ctx = client.session("a-1", "t-1", heartbeat_interval=999)
        assert ctx.agent_id == "a-1"
        assert ctx.tenant_id == "t-1"
        client.close()


class TestNetworkDetection:
    def test_clear_cache(self):
        from forgememory_enterprise._network import _cached_base_url, clear_cache
        clear_cache()
        from forgememory_enterprise import _network
        assert _network._cached_base_url is None
        assert _network._cache_expires == 0.0

    def test_detect_raises_on_unreachable(self):
        clear_cache()
        from forgememory_enterprise._network import detect_base_url
        with pytest.raises(ConnectionError):
            detect_base_url(
                port=19999,
                lan_host="192.0.2.1",  # TEST-NET, unreachable
                tailscale_host="192.0.2.2",
                lan_timeout=0.1,
                tailscale_timeout=0.1,
            )
