"""Tests for MemoryClient."""

import json

import httpx
import pytest

from conftest import error_response, make_client, ok_response, sample_memory
from forgememory_enterprise import ForbiddenError, LegalHoldError, NotFoundError
from forgememory_enterprise.types import CreateMemoryRequest, UpdateMemoryRequest


class TestMemoryClient:
    def test_create_memory(self):
        def handler(request: httpx.Request) -> httpx.Response:
            body = json.loads(request.content)
            assert body["content"] == "Test memory"
            assert body["memory_type"] == "semantic"
            return ok_response(sample_memory())

        client = make_client(handler)
        mem = client.memory.create(
            "tenant-1",
            CreateMemoryRequest(content="Test memory"),
        )
        assert mem.id == "mem-1"
        assert mem.content == "Test memory"

    def test_create_memory_with_tags(self):
        received_body = {}

        def handler(request: httpx.Request) -> httpx.Response:
            received_body.update(json.loads(request.content))
            return ok_response(sample_memory())

        client = make_client(handler)
        client.memory.create(
            "tenant-1",
            CreateMemoryRequest(content="Tagged memory", tags=["ai", "memory"]),
        )
        assert received_body["tags"] == ["ai", "memory"]

    def test_get_memory(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response(sample_memory())

        client = make_client(handler)
        mem = client.memory.get("tenant-1", "mem-1")
        assert mem.id == "mem-1"

    def test_get_memory_not_found(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return error_response("Memory not found", 404)

        client = make_client(handler)
        with pytest.raises(NotFoundError):
            client.memory.get("tenant-1", "nonexistent")

    def test_update_memory(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response(sample_memory(content="Updated content"))

        client = make_client(handler)
        mem = client.memory.update(
            "tenant-1", "mem-1",
            UpdateMemoryRequest(content="Updated content"),
        )
        assert mem.content == "Updated content"

    def test_update_memory_legal_hold(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return error_response("Blocked by legal hold", 403)

        client = make_client(handler)
        with pytest.raises(LegalHoldError):
            client.memory.update(
                "tenant-1", "mem-1",
                UpdateMemoryRequest(content="change"),
            )

    def test_delete_memory(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert request.method == "DELETE"
            return ok_response("Memory deleted")

        client = make_client(handler)
        result = client.memory.delete("tenant-1", "mem-1")
        assert result == "Memory deleted"

    def test_search_memories(self):
        def handler(request: httpx.Request) -> httpx.Response:
            body = json.loads(request.content)
            assert body["query"] == "test query"
            assert body["limit"] == 5
            return ok_response([sample_memory(), sample_memory(id="mem-2", content="Another")])

        client = make_client(handler)
        results = client.memory.search("tenant-1", "test query", limit=5)
        assert len(results) == 2

    def test_search_with_filters(self):
        received_body = {}

        def handler(request: httpx.Request) -> httpx.Response:
            received_body.update(json.loads(request.content))
            return ok_response([sample_memory()])

        client = make_client(handler)
        client.memory.search("tenant-1", "query", memory_type="semantic", user_id="user-1")
        assert received_body["memory_type"] == "semantic"
        assert received_body["user_id"] == "user-1"

    def test_context(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response({"context": "Relevant context here", "memories_used": 3})

        client = make_client(handler)
        ctx = client.memory.context("tenant-1", "project status")
        assert ctx.context == "Relevant context here"
        assert ctx.memories_used == 3

    def test_facts(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response([sample_memory(content="Fact 1"), sample_memory(id="mem-2", content="Fact 2")])

        client = make_client(handler)
        facts = client.memory.facts("tenant-1", limit=10)
        assert len(facts) == 2
        assert facts[0].content == "Fact 1"

    def test_forbidden_tenant(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return error_response("No access to tenant", 403)

        client = make_client(handler)
        with pytest.raises(ForbiddenError):
            client.memory.search("restricted-tenant", "query")

    # ── New field tests ────────────────────────────────────────────────────

    def test_create_memory_with_all_new_fields(self):
        """All 7 new fields are forwarded in the request body."""
        received_body = {}

        def handler(request: httpx.Request) -> httpx.Response:
            received_body.update(json.loads(request.content))
            return ok_response(sample_memory(
                client_id="client-abc",
                source_channel="email",
                source_ref="msg-42",
                app="homeforge",
                visibility="team",
                thread_id="thread-1",
                sensitivity="confidential",
            ))

        client = make_client(handler)
        mem = client.memory.create(
            "tenant-1",
            CreateMemoryRequest(
                content="Full-field memory",
                client_id="client-abc",
                source_channel="email",
                source_ref="msg-42",
                app="homeforge",
                visibility="team",
                thread_id="thread-1",
                sensitivity="confidential",
            ),
        )
        # Request body must include the new fields
        assert received_body["client_id"] == "client-abc"
        assert received_body["source_channel"] == "email"
        assert received_body["source_ref"] == "msg-42"
        assert received_body["app"] == "homeforge"
        assert received_body["visibility"] == "team"
        assert received_body["thread_id"] == "thread-1"
        assert received_body["sensitivity"] == "confidential"
        # Response is correctly deserialized
        assert mem.client_id == "client-abc"
        assert mem.source_channel == "email"
        assert mem.source_ref == "msg-42"
        assert mem.app == "homeforge"
        assert mem.visibility == "team"
        assert mem.thread_id == "thread-1"
        assert mem.sensitivity == "confidential"

    def test_create_memory_defaults_omit_none_fields(self):
        """When new optional fields are not set, None values are not sent in request body."""
        received_body = {}

        def handler(request: httpx.Request) -> httpx.Response:
            received_body.update(json.loads(request.content))
            return ok_response(sample_memory())

        client = make_client(handler)
        client.memory.create(
            "tenant-1",
            CreateMemoryRequest(content="Minimal memory"),
        )
        # None-valued optional fields must be stripped from the request
        assert "client_id" not in received_body
        assert "source_channel" not in received_body
        assert "source_ref" not in received_body
        assert "app" not in received_body
        assert "thread_id" not in received_body
        # Fields with non-None defaults must still be present
        assert received_body["visibility"] == "normal"
        assert received_body["sensitivity"] == "internal"

    def test_search_with_new_filter_fields(self):
        """client_id, source_channel, app, visibility, sensitivity are forwarded in search payload."""
        received_body = {}

        def handler(request: httpx.Request) -> httpx.Response:
            received_body.update(json.loads(request.content))
            return ok_response([sample_memory()])

        client = make_client(handler)
        client.memory.search(
            "tenant-1",
            "important events",
            client_id="client-abc",
            source_channel="email",
            app="homeforge",
            visibility="team",
            sensitivity="confidential",
        )
        assert received_body["client_id"] == "client-abc"
        assert received_body["source_channel"] == "email"
        assert received_body["app"] == "homeforge"
        assert received_body["visibility"] == "team"
        assert received_body["sensitivity"] == "confidential"

    def test_search_omits_none_filter_fields(self):
        """New filter fields not supplied are absent from the search request body."""
        received_body = {}

        def handler(request: httpx.Request) -> httpx.Response:
            received_body.update(json.loads(request.content))
            return ok_response([sample_memory()])

        client = make_client(handler)
        client.memory.search("tenant-1", "query")
        assert "client_id" not in received_body
        assert "source_channel" not in received_body
        assert "app" not in received_body
        assert "visibility" not in received_body
        assert "sensitivity" not in received_body

    def test_memory_model_deserializes_all_new_fields(self):
        """Memory.model_validate correctly maps all 7 new fields from a server response dict."""
        server_payload = sample_memory(
            client_id="c-1",
            source_channel="call",
            source_ref="ref-99",
            app="findmystuff",
            visibility="private",
            thread_id="t-55",
            sensitivity="restricted",
        )

        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response(server_payload)

        client = make_client(handler)
        mem = client.memory.get("tenant-1", "mem-1")
        assert mem.client_id == "c-1"
        assert mem.source_channel == "call"
        assert mem.source_ref == "ref-99"
        assert mem.app == "findmystuff"
        assert mem.visibility == "private"
        assert mem.thread_id == "t-55"
        assert mem.sensitivity == "restricted"

    def test_memory_model_new_fields_default_to_none(self):
        """When the server response omits the new fields, Memory model defaults them to None."""
        server_payload = {
            "id": "mem-1", "tenant_id": "tenant-1", "content": "Legacy memory",
            "memory_type": "semantic", "importance": 5, "source": "test",
            "tags": "", "user_id": None, "metadata_json": "{}",
            "content_hash": "abc", "access_count": 0,
            "last_accessed": "2026-01-01T00:00:00Z",
            "created_at": "2026-01-01T00:00:00Z", "updated_at": "2026-01-01T00:00:00Z",
            # new fields intentionally omitted
        }

        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response(server_payload)

        client = make_client(handler)
        mem = client.memory.get("tenant-1", "mem-1")
        assert mem.client_id is None
        assert mem.source_channel is None
        assert mem.source_ref is None
        assert mem.app is None
        assert mem.visibility is None
        assert mem.thread_id is None
        assert mem.sensitivity is None

    # ── Vector search strategy tests ──────────────────────────────────────

    def test_search_with_strategy(self):
        """search_strategy parameter is forwarded in request body."""
        received_body = {}

        def handler(request: httpx.Request) -> httpx.Response:
            received_body.update(json.loads(request.content))
            return ok_response([sample_memory()])

        client = make_client(handler)
        client.memory.search(
            "tenant-1", "test query",
            search_strategy="hybrid_fts5_first",
        )
        assert received_body["search_strategy"] == "hybrid_fts5_first"

    def test_search_without_strategy_omits_field(self):
        """When search_strategy is None, it's not included in the payload."""
        received_body = {}

        def handler(request: httpx.Request) -> httpx.Response:
            received_body.update(json.loads(request.content))
            return ok_response([sample_memory()])

        client = make_client(handler)
        client.memory.search("tenant-1", "test query")
        assert "search_strategy" not in received_body

    def test_search_strategy_vector_only(self):
        """Vector-only strategy is passed correctly."""
        received_body = {}

        def handler(request: httpx.Request) -> httpx.Response:
            received_body.update(json.loads(request.content))
            return ok_response([])

        client = make_client(handler)
        client.memory.search("tenant-1", "query", search_strategy="vector_only")
        assert received_body["search_strategy"] == "vector_only"
