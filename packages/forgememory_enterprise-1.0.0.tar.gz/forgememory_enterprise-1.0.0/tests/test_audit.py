"""Tests for AuditLogger."""

import json

import httpx
import pytest

from conftest import (
    make_client,
    ok_response,
    sample_action,
    sample_cost,
    sample_delegation,
    sample_memory_access,
)
from forgememory_enterprise.types import AgentAuditStats


class TestAuditLogger:
    def test_log_action(self):
        def handler(request: httpx.Request) -> httpx.Response:
            body = json.loads(request.content)
            assert body["action_type"] == "tool_call"
            assert body["tokens_in"] == 100
            return ok_response(sample_action())

        client = make_client(handler)
        action = client.audit.log_action(
            "agent-1", "sess-1", "tool_call", "search", tokens_in=100, tokens_out=50, cost_usd=0.001
        )
        assert action.action_type == "tool_call"
        assert action.tokens_in == 100

    def test_get_session_actions(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response([sample_action(), sample_action(action_type="llm_request")])

        client = make_client(handler)
        actions = client.audit.get_session_actions("sess-1")
        assert len(actions) == 2

    def test_get_session_timeline(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response([sample_action()])

        client = make_client(handler)
        timeline = client.audit.get_session_timeline("sess-1")
        assert len(timeline) == 1

    def test_log_memory_access(self):
        def handler(request: httpx.Request) -> httpx.Response:
            body = json.loads(request.content)
            assert body["access_type"] == "read"
            return ok_response(sample_memory_access())

        client = make_client(handler)
        access = client.audit.log_memory_access(
            "agent-1", "sess-1", "tenant-1", "mem-1", "read"
        )
        assert access.access_type == "read"

    def test_get_agent_memory_access(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response([sample_memory_access()])

        client = make_client(handler)
        accesses = client.audit.get_agent_memory_access("agent-1")
        assert len(accesses) == 1

    def test_get_memory_access_by_memory(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response([sample_memory_access(), sample_memory_access(agent_id="agent-2")])

        client = make_client(handler)
        accesses = client.audit.get_memory_access_by_memory("mem-1")
        assert len(accesses) == 2

    def test_log_delegation(self):
        def handler(request: httpx.Request) -> httpx.Response:
            body = json.loads(request.content)
            assert body["task"] == "summarize document"
            return ok_response(sample_delegation())

        client = make_client(handler)
        delegation = client.audit.log_delegation(
            "agent-1", "agent-2", "sess-1", "summarize document"
        )
        assert delegation.status == "pending"

    def test_complete_delegation(self):
        def handler(request: httpx.Request) -> httpx.Response:
            assert "/complete" in str(request.url)
            return ok_response("Delegation completed")

        client = make_client(handler)
        result = client.audit.complete_delegation(1, status="completed")
        assert result == "Delegation completed"

    def test_get_cost_summary(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response([sample_cost()])

        client = make_client(handler)
        costs = client.audit.get_cost_summary("agent-1")
        assert len(costs) == 1
        assert costs[0].total_cost_usd == 0.01

    def test_audit_stats(self):
        def handler(request: httpx.Request) -> httpx.Response:
            return ok_response({
                "total_actions": 100, "total_memory_accesses": 50,
                "total_delegations": 10, "total_cost_usd": 1.23,
            })

        client = make_client(handler)
        stats = client.audit.stats()
        assert stats.total_actions == 100
        assert stats.total_cost_usd == 1.23
